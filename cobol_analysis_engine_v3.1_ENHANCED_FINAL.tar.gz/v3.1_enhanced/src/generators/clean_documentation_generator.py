"""
Gerador de documentação limpo sem ícones que mostra:
1. Informações extraídas dos arquivos primeiro
2. Enriquecimento pelas IAs depois
3. Prompts e respostas originais no final
"""

import time
from typing import Dict, Any, List, Optional

class CleanDocumentationGenerator:
    """Gerador de documentação limpo e organizado"""
    
    def __init__(self):
        self.prompt_history = []
    
    def generate_documentation(
        self, 
        extracted_data: Dict[str, Any], 
        ai_analyses: Dict[str, Any] = None,
        prompt_history: List[Dict] = None,
        output_path: str = ""
    ) -> str:
        """Gera documentação limpa mostrando dados dos arquivos primeiro"""
        
        if prompt_history:
            self.prompt_history = prompt_history
        
        program_name = extracted_data.get('program_name', 'PROGRAMA_DESCONHECIDO')
        
        # Construir documentação
        doc = self._build_header(program_name, extracted_data)
        doc += self._build_file_information_section(extracted_data)
        doc += self._build_ai_enrichment_section(ai_analyses)
        doc += self._build_consolidated_analysis_section(extracted_data, ai_analyses)
        doc += self._build_transparency_section()
        
        # Salvar arquivo
        if output_path:
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(doc)
        
        return doc
    
    def _build_header(self, program_name: str, extracted_data: Dict[str, Any]) -> str:
        """Constrói cabeçalho do documento"""
        
        timestamp = time.strftime('%d/%m/%Y %H:%M:%S')
        
        return f"""# Análise Detalhada do Programa: {program_name}

**Data da Análise:** {timestamp}  
**Autor:** EDIVALDO-DEDIC/GPTI  
**Data de Criação:** 11/01/11  
**Tipo:** Programa COBOL  

---

"""
    
    def _build_file_information_section(self, extracted_data: Dict[str, Any]) -> str:
        """Constrói seção com informações extraídas dos arquivos"""
        
        section = "## Informações Extraídas dos Arquivos\n\n"
        
        # Informações do programa COBOL
        section += "### Dados do Programa COBOL\n\n"
        
        # Comentários extraídos
        comments = extracted_data.get('comments', {})
        if any(comments.values()):
            section += "**Comentários do Código:**\n"
            
            if comments.get('objective'):
                section += "- Objetivo: " + "; ".join(comments['objective'][:3]) + "\n"
            
            if comments.get('business_rules'):
                section += "- Regras: " + "; ".join(comments['business_rules'][:3]) + "\n"
            
            if comments.get('technical_notes'):
                section += "- Notas Técnicas: " + "; ".join(comments['technical_notes'][:2]) + "\n"
            
            section += "\n"
        
        # Estrutura do programa
        structure = extracted_data.get('structure', {})
        if structure:
            section += "**Estrutura Identificada:**\n"
            
            divisions = structure.get('divisions', [])
            if divisions:
                section += f"- Divisões: {', '.join(divisions)}\n"
            
            sections = structure.get('sections', [])
            if sections:
                section += f"- Seções: {len(sections)} identificadas\n"
            
            paragraphs = structure.get('paragraphs', [])
            if paragraphs:
                section += f"- Parágrafos: {len(paragraphs)} identificados\n"
            
            section += "\n"
        
        # Informações dos copybooks
        copybooks = extracted_data.get('copybooks', {})
        if copybooks:
            section += "### Dados dos Copybooks\n\n"
            section += f"**Total de Copybooks:** {len(copybooks)}\n\n"
            
            for name, info in list(copybooks.items())[:10]:  # Limitar a 10
                section += f"**{name}:**\n"
                section += f"- Descrição: {info.get('description', 'Layout de dados')}\n"
                
                fields = info.get('fields', [])
                if fields:
                    section += f"- Campos: {len(fields)} definidos\n"
                    # Mostrar alguns campos principais
                    main_fields = [f['name'] for f in fields[:5] if 'name' in f]
                    if main_fields:
                        section += f"- Principais: {', '.join(main_fields)}\n"
                
                section += "\n"
        
        section += "---\n\n"
        return section
    
    def _build_ai_enrichment_section(self, ai_analyses: Dict[str, Any]) -> str:
        """Constrói seção com enriquecimento das IAs"""
        
        section = "## Enriquecimento com Análise de IA\n\n"
        
        if not ai_analyses or not any(ai_analyses.values()):
            section += "**Status:** Análise de IA não disponível ou não configurada.\n\n"
            section += "---\n\n"
            return section
        
        # Análise principal
        main_analysis = ai_analyses.get('main_analysis', {})
        if main_analysis:
            section += "### Análise Inteligente\n\n"
            
            # Objetivo identificado pela IA
            objective = main_analysis.get('objective', '')
            if objective:
                section += f"**Objetivo Identificado:** {objective}\n\n"
            
            # Regras de negócio
            business_rules = main_analysis.get('business_rules', [])
            if business_rules:
                section += "**Regras de Negócio Identificadas:**\n"
                for i, rule in enumerate(business_rules[:8], 1):
                    section += f"{i}. {rule}\n"
                section += "\n"
            
            # Análise técnica
            technical_analysis = main_analysis.get('technical_analysis', [])
            if technical_analysis:
                section += "**Aspectos Técnicos:**\n"
                for i, aspect in enumerate(technical_analysis[:6], 1):
                    section += f"{i}. {aspect}\n"
                section += "\n"
            
            # Particularidades
            particularities = main_analysis.get('particularities', [])
            if particularities:
                section += "**Particularidades:**\n"
                for i, particular in enumerate(particularities[:5], 1):
                    section += f"{i}. {particular}\n"
                section += "\n"
        
        section += "---\n\n"
        return section
    
    def _build_consolidated_analysis_section(self, extracted_data: Dict[str, Any], ai_analyses: Dict[str, Any]) -> str:
        """Constrói seção consolidada combinando dados dos arquivos com análise da IA"""
        
        section = "## Análise Consolidada\n\n"
        
        # Resumo executivo
        section += "### Resumo Executivo\n\n"
        
        # Combinar objetivo dos comentários com análise da IA
        comments = extracted_data.get('comments', {})
        ai_objective = ai_analyses.get('main_analysis', {}).get('objective', '') if ai_analyses else ''
        
        if comments.get('objective') or ai_objective:
            section += "**Objetivo do Programa:**\n"
            
            if comments.get('objective'):
                section += f"- Conforme código: {'; '.join(comments['objective'][:2])}\n"
            
            if ai_objective and ai_objective != '; '.join(comments.get('objective', [])[:2]):
                section += f"- Análise IA: {ai_objective}\n"
            
            section += "\n"
        
        # Estatísticas estruturais
        structure = extracted_data.get('structure', {})
        copybooks = extracted_data.get('copybooks', {})
        
        section += "**Estatísticas:**\n"
        section += f"- Copybooks integrados: {len(copybooks) if copybooks else 0}\n"
        section += f"- Divisões identificadas: {len(structure.get('divisions', []))}\n"
        section += f"- Seções mapeadas: {len(structure.get('sections', []))}\n"
        section += f"- Parágrafos analisados: {len(structure.get('paragraphs', []))}\n"
        
        # Status da análise
        ai_available = bool(ai_analyses and ai_analyses.get('main_analysis'))
        section += f"- Análise IA: {'Disponível' if ai_available else 'Não disponível'}\n"
        
        section += "\n---\n\n"
        return section
    
    def _build_transparency_section(self) -> str:
        """Constrói seção de transparência com prompts e respostas"""
        
        section = "## Detalhes da Análise com IA\n\n"
        
        if not self.prompt_history:
            section += "**Status:** Nenhuma interação com IA registrada.\n\n"
            return section
        
        # Mostrar cada análise
        for i, entry in enumerate(self.prompt_history, 1):
            status = "Sucesso" if entry.get('success', False) else "Falha"
            provider = entry.get('provider', 'Desconhecido')
            
            section += f"### Análise {i}: {entry.get('type', 'Análise Geral')}\n\n"
            section += f"**Provedor:** {provider}\n"
            section += f"**Modelo:** {entry.get('model', 'N/A')}\n"
            section += f"**Tempo:** {entry.get('processing_time', 0):.2f}s\n"
            section += f"**Status:** {status}\n\n"
            
            # Prompt enviado (completo)
            prompt = entry.get('prompt', '')
            if prompt:
                section += "**Prompt enviado:**\n```\n"
                section += prompt
                section += "\n```\n\n"
            
            # Resposta recebida (completa e original)
            response = entry.get('response', '')
            if response:
                section += f"**Resposta original do {provider}:**\n```\n"
                section += response
                section += "\n```\n\n"
                
                # Se não conseguir tratar a resposta, preservar o conteúdo original
                if not entry.get('success', False) and response:
                    section += f"**Nota:** Resposta preservada na íntegra para análise manual.\n\n"
            
            section += "---\n\n"
        
        # Resumo das análises
        total_analyses = len(self.prompt_history)
        successful_analyses = len([entry for entry in self.prompt_history if entry.get('success', False)])
        success_rate = (successful_analyses / total_analyses * 100) if total_analyses > 0 else 0
        
        section += "**Resumo das Análises:**\n"
        section += f"- Total de análises: {total_analyses}\n"
        section += f"- Análises bem-sucedidas: {successful_analyses}\n"
        section += f"- Taxa de sucesso: {success_rate:.1f}%\n\n"
        
        return section
