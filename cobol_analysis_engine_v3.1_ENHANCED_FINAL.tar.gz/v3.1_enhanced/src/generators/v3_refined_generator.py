"""
Gerador de Documentação v3.0 - Refinado com Controle de Tokens
Baseado no gerador inteligente v2.0 com melhorias de prompts e controle de custos
"""

import time
import re
from typing import Dict, List, Any, Optional
from datetime import datetime

class V3RefinedGenerator:
    """Gerador de documentação v3.0 com prompts refinados e controle de tokens"""
    
    def __init__(self):
        self.token_stats = {
            'total_tokens_used': 0,
            'total_cost': 0.0,
            'prompts_generated': 0,
            'tokens_saved_by_optimization': 0
        }
    
    def estimate_tokens(self, text: str) -> int:
        """Estima número de tokens baseado em caracteres (aproximação)"""
        # Aproximação: 1 token ≈ 4 caracteres para português
        return len(text) // 4
    
    def estimate_cost(self, tokens: int, model: str = "gpt-4") -> float:
        """Estima custo baseado no número de tokens"""
        # Preços aproximados por 1K tokens (USD)
        prices = {
            "gpt-4": 0.03,
            "gpt-3.5-turbo": 0.002,
            "luzia-chat": 0.001  # Estimativa
        }
        
        price_per_1k = prices.get(model, 0.01)
        return (tokens / 1000) * price_per_1k
    
    def optimize_prompt(self, prompt: str, max_tokens: int = 12000) -> tuple[str, int]:
        """Otimiza prompt se for muito grande"""
        estimated_tokens = self.estimate_tokens(prompt)
        tokens_saved = 0
        
        if estimated_tokens > max_tokens:
            # Estratégias de otimização
            original_length = len(prompt)
            
            # 1. Remover comentários excessivos
            prompt = re.sub(r'(\*.*?\n){3,}', '*[comentários resumidos]\n', prompt, flags=re.DOTALL)
            
            # 2. Resumir seções repetitivas
            prompt = re.sub(r'(MOVE\s+\w+\s+TO\s+\w+\.\s*\n){5,}', 'MOVE [múltiplas operações] TO [campos diversos].\n', prompt)
            
            # 3. Truncar código muito longo mantendo estrutura essencial
            if len(prompt) > max_tokens * 4:  # 4 chars per token
                lines = prompt.split('\n')
                essential_lines = []
                
                for line in lines:
                    if any(keyword in line.upper() for keyword in [
                        'IDENTIFICATION DIVISION', 'PROGRAM-ID', 'ENVIRONMENT DIVISION',
                        'DATA DIVISION', 'WORKING-STORAGE', 'PROCEDURE DIVISION',
                        'COPY', 'INCLUDE', 'PERFORM', 'IF', 'ELSE', 'END-IF'
                    ]):
                        essential_lines.append(line)
                    elif len(essential_lines) < len(lines) * 0.7:  # Manter 70% das linhas
                        essential_lines.append(line)
                
                prompt = '\n'.join(essential_lines)
            
            new_length = len(prompt)
            tokens_saved = self.estimate_tokens(str(original_length - new_length))
            self.token_stats['tokens_saved_by_optimization'] += tokens_saved
            
            print(f"⚡ Prompt otimizado: {original_length:,} → {new_length:,} chars")
            print(f"💡 Tokens economizados: ~{tokens_saved:,}")
        
        return prompt, tokens_saved
    
    def create_refined_prompt(self, program_name: str, cobol_code: str, copybooks: Dict[str, Any]) -> str:
        """Cria prompt refinado seguindo boas práticas de LLM"""
        
        # Análise prévia do código para contexto
        code_analysis = self._analyze_code_structure(cobol_code)
        
        # Prompt estruturado com boas práticas
        prompt = f"""# ANÁLISE COBOL REFINADA v3.0

## CONTEXTO E OBJETIVO
Você é um especialista em análise de sistemas COBOL legados. Sua tarefa é analisar o programa {program_name} e gerar uma documentação técnica completa e profissional.

## INFORMAÇÕES DO PROGRAMA
- **Nome:** {program_name}
- **Complexidade estimada:** {code_analysis['complexity']}
- **Linhas de código:** {code_analysis['lines_of_code']:,}
- **Divisões identificadas:** {', '.join(code_analysis['divisions'])}
- **Copybooks:** {len(copybooks)} identificados

## INSTRUÇÕES ESPECÍFICAS

### 1. FORMATO DE RESPOSTA OBRIGATÓRIO
Responda EXCLUSIVAMENTE em formato JSON estruturado:

```json
{{
    "resumo_executivo": {{
        "objetivo_principal": "string",
        "criticidade_negocio": "Alta|Média|Baixa",
        "impacto_sistema": "string",
        "arquivos_processados": ["lista de arquivos"]
    }},
    "analise_funcional": {{
        "funcionalidades_principais": ["lista de funcionalidades"],
        "regras_negocio": [
            {{
                "regra": "string",
                "condicao": "string", 
                "acao": "string",
                "criticidade": "Alta|Média|Baixa"
            }}
        ],
        "validacoes_identificadas": ["lista de validações"]
    }},
    "estrutura_tecnica": {{
        "working_storage_campos": {code_analysis['ws_fields']},
        "arquivos_entrada": ["lista"],
        "arquivos_saida": ["lista"],
        "operacoes_matematicas": {code_analysis['math_operations']},
        "performs_identificados": {code_analysis['performs']}
    }},
    "aspectos_tecnicos": {{
        "performance": "string",
        "manutenibilidade": "string",
        "pontos_atencao": ["lista"],
        "recomendacoes": ["lista"]
    }},
    "metricas": {{
        "complexidade_ciclomatica": "estimativa",
        "linhas_codigo": {code_analysis['lines_of_code']},
        "numero_paragrafos": {code_analysis['paragraphs']},
        "uso_copybooks": {len(copybooks)}
    }}
}}
```

### 2. DIRETRIZES DE ANÁLISE

**FOQUE EM:**
- Identificar o OBJETIVO REAL do programa
- Extrair REGRAS DE NEGÓCIO específicas
- Detectar VALIDAÇÕES e CONTROLES
- Mapear FLUXO DE DADOS
- Avaliar IMPACTO NO NEGÓCIO

**EVITE:**
- Descrições genéricas
- Repetir código sem análise
- Especulações sem base no código
- Informações irrelevantes

### 3. COPYBOOKS DISPONÍVEIS
"""

        # Adicionar informações dos copybooks
        if copybooks:
            prompt += "\n**Copybooks integrados:**\n"
            for name, info in copybooks.items():
                prompt += f"- {name}: {info.get('description', 'Estrutura de dados')}\n"
        else:
            prompt += "\n*Nenhum copybook fornecido para análise contextual.*\n"

        prompt += f"""

### 4. CÓDIGO FONTE PARA ANÁLISE

```cobol
{cobol_code}
```

## IMPORTANTE
- Analise TODO o código fornecido
- Base suas conclusões APENAS no código apresentado
- Seja ESPECÍFICO e TÉCNICO
- Mantenha FOCO NO NEGÓCIO
- Use o formato JSON OBRIGATÓRIO

Inicie sua análise agora:"""

        # Otimizar prompt se necessário
        optimized_prompt, tokens_saved = self.optimize_prompt(prompt)
        
        # Atualizar estatísticas
        estimated_tokens = self.estimate_tokens(optimized_prompt)
        estimated_cost = self.estimate_cost(estimated_tokens)
        
        self.token_stats['total_tokens_used'] += estimated_tokens
        self.token_stats['total_cost'] += estimated_cost
        self.token_stats['prompts_generated'] += 1
        
        print(f"📊 Prompt gerado: {estimated_tokens:,} tokens")
        print(f"💰 Custo estimado: ${estimated_cost:.4f}")
        
        return optimized_prompt
    
    def _analyze_code_structure(self, cobol_code: str) -> Dict[str, Any]:
        """Análise prévia da estrutura do código"""
        lines = cobol_code.split('\n')
        
        analysis = {
            'lines_of_code': len([l for l in lines if l.strip() and not l.strip().startswith('*')]),
            'complexity': 'Baixa',
            'divisions': [],
            'ws_fields': 0,
            'math_operations': 0,
            'performs': 0,
            'paragraphs': 0
        }
        
        # Identificar divisões
        for line in lines:
            line_upper = line.upper().strip()
            if 'DIVISION' in line_upper:
                division = line_upper.split()[0]
                if division not in analysis['divisions']:
                    analysis['divisions'].append(division)
        
        # Contar elementos
        code_upper = cobol_code.upper()
        analysis['ws_fields'] = len(re.findall(r'^\s*\d+\s+\w+', cobol_code, re.MULTILINE))
        analysis['math_operations'] = len(re.findall(r'(ADD|SUBTRACT|MULTIPLY|DIVIDE|COMPUTE)', code_upper))
        analysis['performs'] = len(re.findall(r'PERFORM\s+\w+', code_upper))
        analysis['paragraphs'] = len(re.findall(r'^\s*\w+\.\s*$', cobol_code, re.MULTILINE))
        
        # Determinar complexidade
        complexity_score = (
            analysis['lines_of_code'] / 100 +
            analysis['math_operations'] / 10 +
            analysis['performs'] / 5 +
            len(analysis['divisions'])
        )
        
        if complexity_score > 20:
            analysis['complexity'] = 'Alta'
        elif complexity_score > 10:
            analysis['complexity'] = 'Média'
        
        return analysis
    
    def generate_v3_documentation(self, program_name: str, cobol_code: str, 
                                 analysis_result: Dict[str, Any], copybooks: Dict[str, Any],
                                 prompt_history: List[Dict[str, Any]]) -> str:
        """Gera documentação v3.0 com controle de tokens"""
        
        timestamp = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        
        # Extrair dados da análise (se disponível)
        ai_analysis = analysis_result.get('analysis_result', {})
        
        doc = f"""# Análise COBOL v3.0: {program_name}

**Data da Análise:** {timestamp}  
**Versão:** COBOL Analysis Engine v3.0  
**Modo:** Refined (Prompts Otimizados + Controle de Tokens)

---

## 📊 Resumo Executivo

"""
        
        # Adicionar análise da IA se disponível
        if ai_analysis and isinstance(ai_analysis, dict):
            resumo = ai_analysis.get('resumo_executivo', {})
            if resumo:
                doc += f"""**Objetivo Principal:** {resumo.get('objetivo_principal', 'Análise baseada na estrutura do código')}

**Criticidade do Negócio:** {resumo.get('criticidade_negocio', 'Média')}

**Impacto no Sistema:** {resumo.get('impacto_sistema', 'Processamento de dados COBOL')}

**Arquivos Processados:** {len(resumo.get('arquivos_processados', []))} identificados

"""
        else:
            # Fallback baseado na análise estrutural
            code_analysis = self._analyze_code_structure(cobol_code)
            doc += f"""**Objetivo Principal:** Programa COBOL {program_name} para processamento de dados

**Criticidade do Negócio:** {code_analysis['complexity']}

**Impacto no Sistema:** Sistema de processamento com {code_analysis['lines_of_code']:,} linhas de código

**Arquivos Processados:** {len(copybooks)} copybooks integrados

"""

        doc += """---

## 🎯 Análise Funcional

"""
        
        # Análise funcional
        if ai_analysis and 'analise_funcional' in ai_analysis:
            funcional = ai_analysis['analise_funcional']
            
            doc += "### Funcionalidades Principais\n"
            for func in funcional.get('funcionalidades_principais', []):
                doc += f"- {func}\n"
            
            doc += "\n### Regras de Negócio Identificadas\n\n"
            doc += "| Regra | Condição | Ação | Criticidade |\n"
            doc += "|-------|----------|------|-------------|\n"
            
            for regra in funcional.get('regras_negocio', []):
                doc += f"| {regra.get('regra', 'N/A')} | {regra.get('condicao', 'N/A')} | {regra.get('acao', 'N/A')} | {regra.get('criticidade', 'Média')} |\n"
            
            doc += "\n### Validações Implementadas\n"
            for validacao in funcional.get('validacoes_identificadas', []):
                doc += f"- {validacao}\n"
        else:
            # Fallback estrutural
            code_analysis = self._analyze_code_structure(cobol_code)
            doc += f"""### Funcionalidades Principais
- Processamento de dados COBOL estruturado
- Manipulação de {code_analysis['ws_fields']} campos de Working Storage
- Execução de {code_analysis['math_operations']} operações matemáticas
- Controle de fluxo com {code_analysis['performs']} PERFORMs

### Estrutura Identificada
- **Linhas de código:** {code_analysis['lines_of_code']:,}
- **Divisões:** {', '.join(code_analysis['divisions'])}
- **Parágrafos:** {code_analysis['paragraphs']}
- **Complexidade:** {code_analysis['complexity']}

"""

        doc += """---

## 🗃️ Estrutura Técnica

"""
        
        # Estrutura técnica
        if ai_analysis and 'estrutura_tecnica' in ai_analysis:
            estrutura = ai_analysis['estrutura_tecnica']
            
            doc += f"""### Working Storage
**Campos identificados:** {estrutura.get('working_storage_campos', 0)}

### Arquivos
**Entrada:** {len(estrutura.get('arquivos_entrada', []))} arquivos  
**Saída:** {len(estrutura.get('arquivos_saida', []))} arquivos

### Operações
**Matemáticas:** {estrutura.get('operacoes_matematicas', 0)}  
**PERFORMs:** {estrutura.get('performs_identificados', 0)}

"""
        
        # Copybooks
        if copybooks:
            doc += "### Copybooks Integrados\n\n"
            doc += "| Nome | Descrição |\n"
            doc += "|------|----------|\n"
            for name, info in copybooks.items():
                desc = info.get('description', 'Estrutura de dados')
                doc += f"| {name} | {desc} |\n"
        
        doc += """---

## 🔧 Aspectos Técnicos

"""
        
        # Aspectos técnicos
        if ai_analysis and 'aspectos_tecnicos' in ai_analysis:
            aspectos = ai_analysis['aspectos_tecnicos']
            
            doc += f"""**Performance:** {aspectos.get('performance', 'Análise baseada na estrutura')}

**Manutenibilidade:** {aspectos.get('manutenibilidade', 'Código estruturado COBOL')}

### Pontos de Atenção
"""
            for ponto in aspectos.get('pontos_atencao', []):
                doc += f"- {ponto}\n"
            
            doc += "\n### Recomendações\n"
            for rec in aspectos.get('recomendacoes', []):
                doc += f"- {rec}\n"
        else:
            doc += """**Performance:** Análise baseada na estrutura do código COBOL

**Manutenibilidade:** Código seguindo padrões COBOL estruturado

### Recomendações Gerais
- Manter documentação atualizada
- Implementar testes de regressão
- Monitorar performance em produção
- Validar regras de negócio periodicamente

"""

        doc += """---

## 📈 Métricas e Controle de Tokens v3.0

"""
        
        # Métricas de tokens
        doc += f"""### Estatísticas de Análise
**Prompts gerados:** {self.token_stats['prompts_generated']}  
**Tokens utilizados:** {self.token_stats['total_tokens_used']:,}  
**Custo estimado:** ${self.token_stats['total_cost']:.4f}  
**Tokens economizados:** {self.token_stats['tokens_saved_by_optimization']:,}  

### Eficiência
"""
        
        if self.token_stats['total_tokens_used'] > 0:
            efficiency = "Alta" if self.token_stats['total_tokens_used'] < 5000 else "Média" if self.token_stats['total_tokens_used'] < 10000 else "Baixa"
            doc += f"**Classificação:** {efficiency}  \n"
            
            if self.token_stats['tokens_saved_by_optimization'] > 0:
                savings_percent = (self.token_stats['tokens_saved_by_optimization'] / 
                                 (self.token_stats['total_tokens_used'] + self.token_stats['tokens_saved_by_optimization'])) * 100
                doc += f"**Economia obtida:** {savings_percent:.1f}%  \n"
        
        doc += """---

## 🔍 Transparência de Análise v3.0

"""
        
        # Histórico de prompts e respostas
        if prompt_history:
            for i, interaction in enumerate(prompt_history, 1):
                doc += f"""### Interação {i}
**Provedor:** {interaction.get('provider', 'N/A')}  
**Modelo:** {interaction.get('model', 'N/A')}  
**Tempo:** {interaction.get('duration', 0):.2f}s  
**Status:** {interaction.get('status', 'N/A')}  
**Tokens estimados:** {self.estimate_tokens(interaction.get('prompt', '')):,}  

**Prompt enviado:**
```
{interaction.get('prompt', 'N/A')[:1000]}{'...' if len(interaction.get('prompt', '')) > 1000 else ''}
```

**Resposta recebida:**
```
{interaction.get('response', 'N/A')[:1000]}{'...' if len(interaction.get('response', '')) > 1000 else ''}
```

---

"""
        else:
            doc += """**Status:** Análise realizada com base na estrutura do código COBOL.

**Método:** Análise estática inteligente sem uso de IA externa.

**Transparência:** Sistema sempre funcional, gerando relatórios de alta qualidade mesmo sem credenciais de IA configuradas.

---

"""

        doc += f"""## 📋 Informações Técnicas

**Sistema:** COBOL Analysis Engine v3.0  
**Modo de análise:** Refined (Prompts Otimizados)  
**Controle de tokens:** Ativo  
**Gerado em:** {timestamp}  
**Arquivo analisado:** {program_name}  

---

*Relatório gerado automaticamente pelo COBOL Analysis Engine v3.0 - Sistema inteligente de análise com controle de tokens e prompts refinados.*
"""
        
        return doc
    
    def get_token_statistics(self) -> Dict[str, Any]:
        """Retorna estatísticas detalhadas de tokens"""
        return {
            'total_tokens_used': self.token_stats['total_tokens_used'],
            'total_cost': self.token_stats['total_cost'],
            'prompts_generated': self.token_stats['prompts_generated'],
            'tokens_saved_by_optimization': self.token_stats['tokens_saved_by_optimization'],
            'average_tokens_per_prompt': (
                self.token_stats['total_tokens_used'] / self.token_stats['prompts_generated']
                if self.token_stats['prompts_generated'] > 0 else 0
            ),
            'efficiency_rating': (
                'Alta' if self.token_stats['total_tokens_used'] < 5000 
                else 'Média' if self.token_stats['total_tokens_used'] < 10000 
                else 'Baixa'
            )
        }
