#!/usr/bin/env python3
"""
Executive Summary Generator - Sistema de Análise COBOL v14.0
Gera resumos executivos claros e objetivos
"""

import logging
from typing import Dict, List, Any
from dataclasses import dataclass

@dataclass
class ExecutiveSummary:
    """Representa um resumo executivo de programa."""
    program_name: str
    one_line_summary: str  # Uma frase explicando o programa
    what_it_does: str      # O que faz
    why_it_exists: str     # Por que existe
    business_impact: str   # Impacto no negócio
    key_numbers: Dict[str, Any]  # Números importantes
    dependencies: List[str]      # Dependências principais
    risks: List[str]            # Riscos identificados

class ExecutiveSummaryGenerator:
    """
    Gerador de Resumos Executivos
    
    Cria resumos claros e objetivos que permitem entender
    rapidamente o que cada programa faz e sua importância.
    """

    def __init__(self):
        self.logger = logging.getLogger(__name__)

    def generate_summary(self, program_name: str, purpose_data: Dict[str, Any],
                        flow_data: Dict[str, Any], 
                        additional_context: Dict[str, Any] = None) -> ExecutiveSummary:
        """
        Gera resumo executivo baseado nos dados de análise.
        """
        self.logger.info(f"Gerando resumo executivo para {program_name}")
        
        # Extrai dados principais
        main_purpose = purpose_data.get('main_purpose', 'Processamento não identificado')
        action_verb = purpose_data.get('action_verb', 'PROCESSAR')
        business_domain = purpose_data.get('business_domain', 'OPERACIONAL')
        input_files = purpose_data.get('input_files', [])
        output_files = purpose_data.get('output_files', [])
        
        # Gera uma frase resumo
        one_line_summary = self._generate_one_line_summary(
            program_name, main_purpose, action_verb, business_domain
        )
        
        # Explica o que faz
        what_it_does = self._explain_what_it_does(
            action_verb, input_files, output_files, flow_data
        )
        
        # Explica por que existe
        why_it_exists = self._explain_why_it_exists(
            business_domain, action_verb, additional_context
        )
        
        # Avalia impacto no negócio
        business_impact = self._assess_business_impact(
            business_domain, input_files, output_files, additional_context
        )
        
        # Extrai números importantes
        key_numbers = self._extract_key_numbers(
            input_files, output_files, additional_context
        )
        
        # Identifica dependências
        dependencies = self._identify_dependencies(
            input_files, output_files, additional_context
        )
        
        # Identifica riscos
        risks = self._identify_risks(
            business_domain, input_files, output_files, additional_context
        )
        
        return ExecutiveSummary(
            program_name=program_name,
            one_line_summary=one_line_summary,
            what_it_does=what_it_does,
            why_it_exists=why_it_exists,
            business_impact=business_impact,
            key_numbers=key_numbers,
            dependencies=dependencies,
            risks=risks
        )

    def _generate_one_line_summary(self, program_name: str, main_purpose: str,
                                  action_verb: str, business_domain: str) -> str:
        """Gera uma frase resumo clara e objetiva."""
        
        # Templates específicos por verbo
        templates = {
            'PARTICIONAR': f"{program_name} quebra arquivos {business_domain} em partes menores para processamento",
            'VALIDAR': f"{program_name} valida dados {business_domain} conforme regras regulamentares",
            'PROCESSAR': f"{program_name} processa informações {business_domain} do sistema",
            'GERAR': f"{program_name} gera relatórios e arquivos {business_domain}",
            'CONVERTER': f"{program_name} converte dados {business_domain} entre formatos",
            'CONSOLIDAR': f"{program_name} consolida informações {business_domain} de múltiplas fontes",
            'ROTEAR': f"{program_name} roteia dados {business_domain} por tipo ou critério específico",
            'EXTRAIR': f"{program_name} extrai informações específicas de dados {business_domain}",
            'ATUALIZAR': f"{program_name} atualiza registros {business_domain} no sistema",
            'RELATORIO': f"{program_name} emite relatórios {business_domain} para gestão"
        }
        
        return templates.get(action_verb, main_purpose)

    def _explain_what_it_does(self, action_verb: str, input_files: List[str],
                             output_files: List[str], flow_data: Dict[str, Any]) -> str:
        """Explica detalhadamente o que o programa faz."""
        
        explanations = []
        
        # Baseado no verbo de ação
        action_explanations = {
            'PARTICIONAR': 'Divide arquivos grandes em arquivos menores',
            'VALIDAR': 'Verifica se os dados atendem às regras de negócio',
            'PROCESSAR': 'Executa transformações nos dados de entrada',
            'GERAR': 'Cria novos arquivos ou relatórios',
            'CONVERTER': 'Transforma dados de um formato para outro',
            'CONSOLIDAR': 'Agrupa informações de várias fontes',
            'ROTEAR': 'Direciona dados para destinos específicos',
            'EXTRAIR': 'Seleciona informações específicas dos dados',
            'ATUALIZAR': 'Modifica registros existentes',
            'RELATORIO': 'Produz relatórios para análise'
        }
        
        base_explanation = action_explanations.get(action_verb, 'Processa dados do sistema')
        explanations.append(base_explanation)
        
        # Adiciona detalhes sobre arquivos
        if input_files:
            if len(input_files) == 1:
                explanations.append(f"Lê dados do arquivo {input_files[0]}")
            else:
                explanations.append(f"Lê dados de {len(input_files)} arquivos de entrada")
        
        if output_files:
            if len(output_files) == 1:
                explanations.append(f"Grava resultados no arquivo {output_files[0]}")
            else:
                explanations.append(f"Grava resultados em {len(output_files)} arquivos de saída")
        
        # Adiciona informações do fluxo
        overall_flow = flow_data.get('overall_flow', '')
        if overall_flow and 'Fluxo' in overall_flow:
            explanations.append(f"Segue o padrão: {overall_flow.replace('Fluxo ', '').lower()}")
        
        return '. '.join(explanations) + '.'

    def _explain_why_it_exists(self, business_domain: str, action_verb: str,
                              additional_context: Dict[str, Any] = None) -> str:
        """Explica por que o programa existe."""
        
        # Justificativas por domínio
        domain_reasons = {
            'BACEN': 'Atender exigências regulamentares do Banco Central',
            'FINANCEIRO': 'Manter controle financeiro e contábil',
            'CONTABIL': 'Gerar informações contábeis obrigatórias',
            'OPERACIONAL': 'Automatizar processos operacionais',
            'REGULATORIO': 'Cumprir obrigações regulamentares'
        }
        
        # Justificativas por ação
        action_reasons = {
            'PARTICIONAR': 'Superar limitações de tamanho de arquivo',
            'VALIDAR': 'Garantir qualidade e integridade dos dados',
            'PROCESSAR': 'Automatizar tarefas manuais',
            'GERAR': 'Fornecer informações para tomada de decisão',
            'CONVERTER': 'Integrar sistemas com formatos diferentes',
            'CONSOLIDAR': 'Centralizar informações dispersas',
            'ROTEAR': 'Otimizar processamento por tipo de dados',
            'EXTRAIR': 'Fornecer dados específicos para análise',
            'ATUALIZAR': 'Manter informações atualizadas',
            'RELATORIO': 'Atender necessidades de gestão e auditoria'
        }
        
        domain_reason = domain_reasons.get(business_domain, 'Atender necessidades do negócio')
        action_reason = action_reasons.get(action_verb, 'Automatizar processos')
        
        return f"{domain_reason} através de {action_reason.lower()}"

    def _assess_business_impact(self, business_domain: str, input_files: List[str],
                               output_files: List[str], 
                               additional_context: Dict[str, Any] = None) -> str:
        """Avalia o impacto no negócio."""
        
        impact_factors = []
        
        # Impacto por domínio
        domain_impacts = {
            'BACEN': 'CRÍTICO - Obrigatório para funcionamento regulamentar',
            'FINANCEIRO': 'ALTO - Essencial para controle financeiro',
            'CONTABIL': 'ALTO - Necessário para fechamento contábil',
            'OPERACIONAL': 'MÉDIO - Importante para eficiência operacional',
            'REGULATORIO': 'CRÍTICO - Obrigatório para compliance'
        }
        
        base_impact = domain_impacts.get(business_domain, 'MÉDIO - Suporte às operações')
        impact_factors.append(base_impact)
        
        # Impacto por volume de arquivos
        total_files = len(input_files) + len(output_files)
        if total_files > 5:
            impact_factors.append('Alto volume de dados processados')
        elif total_files > 2:
            impact_factors.append('Volume moderado de dados')
        
        # Impacto por contexto adicional
        if additional_context:
            if 'daily' in str(additional_context).lower():
                impact_factors.append('Execução diária crítica')
            if 'batch' in str(additional_context).lower():
                impact_factors.append('Processamento em lote essencial')
        
        return '. '.join(impact_factors)

    def _extract_key_numbers(self, input_files: List[str], output_files: List[str],
                            additional_context: Dict[str, Any] = None) -> Dict[str, Any]:
        """Extrai números importantes."""
        
        numbers = {
            'arquivos_entrada': len(input_files),
            'arquivos_saida': len(output_files),
            'total_arquivos': len(input_files) + len(output_files)
        }
        
        # Adiciona números do contexto adicional se disponível
        if additional_context:
            # Procura por números no contexto
            context_str = str(additional_context)
            
            # Padrões comuns
            import re
            
            # Tamanhos de arquivo
            size_matches = re.findall(r'(\d+)\s*(MB|GB|KB)', context_str.upper())
            if size_matches:
                numbers['tamanho_limite'] = f"{size_matches[0][0]} {size_matches[0][1]}"
            
            # Números de registros
            record_matches = re.findall(r'(\d+)\s*(RECORD|REGISTRO)', context_str.upper())
            if record_matches:
                numbers['registros'] = int(record_matches[0][0])
            
            # Tempos
            time_matches = re.findall(r'(\d+)\s*(MINUTE|HORA|SEGUNDO)', context_str.upper())
            if time_matches:
                numbers['tempo_processamento'] = f"{time_matches[0][0]} {time_matches[0][1]}"
        
        return numbers

    def _identify_dependencies(self, input_files: List[str], output_files: List[str],
                              additional_context: Dict[str, Any] = None) -> List[str]:
        """Identifica dependências principais."""
        
        dependencies = []
        
        # Dependências de arquivos de entrada
        if input_files:
            dependencies.append(f"Arquivos de entrada: {', '.join(input_files)}")
        
        # Dependências de sistemas externos (baseado em nomes)
        external_systems = []
        all_files = input_files + output_files
        
        for file in all_files:
            if 'BACEN' in file.upper():
                external_systems.append('Sistema BACEN')
            elif 'STR' in file.upper():
                external_systems.append('Sistema STR')
            elif 'DOC' in file.upper():
                external_systems.append('Sistema de Documentos')
        
        if external_systems:
            dependencies.append(f"Sistemas externos: {', '.join(set(external_systems))}")
        
        # Dependências de horário (se identificadas)
        if additional_context and 'schedule' in str(additional_context).lower():
            dependencies.append('Execução em horário específico')
        
        return dependencies

    def _identify_risks(self, business_domain: str, input_files: List[str],
                       output_files: List[str], 
                       additional_context: Dict[str, Any] = None) -> List[str]:
        """Identifica riscos principais."""
        
        risks = []
        
        # Riscos por domínio
        domain_risks = {
            'BACEN': 'Não conformidade regulamentar',
            'FINANCEIRO': 'Inconsistências financeiras',
            'CONTABIL': 'Erros no fechamento contábil',
            'OPERACIONAL': 'Interrupção de processos',
            'REGULATORIO': 'Penalidades regulamentares'
        }
        
        if business_domain in domain_risks:
            risks.append(domain_risks[business_domain])
        
        # Riscos por volume de arquivos
        if len(input_files) > 3:
            risks.append('Falha em múltiplas fontes de dados')
        
        if len(output_files) > 3:
            risks.append('Impacto em múltiplos sistemas downstream')
        
        # Riscos de performance
        total_files = len(input_files) + len(output_files)
        if total_files > 5:
            risks.append('Gargalo de performance em alto volume')
        
        # Riscos de dependência
        if not input_files:
            risks.append('Dependências de entrada não identificadas')
        
        return risks

    def generate_summary_report(self, summary: ExecutiveSummary) -> str:
        """Gera relatório do resumo executivo em formato markdown."""
        
        report = [
            f"#  Resumo Executivo - {summary.program_name}",
            "",
            f"##  Resumo em Uma Frase",
            f"**{summary.one_line_summary}**",
            "",
            f"##  O Que Faz",
            summary.what_it_does,
            "",
            f"## 💼 Por Que Existe",
            summary.why_it_exists,
            "",
            f"##  Impacto no Negócio",
            summary.business_impact,
            ""
        ]
        
        # Números importantes
        if summary.key_numbers:
            report.extend([
                "##  Números Importantes",
                ""
            ])
            
            for key, value in summary.key_numbers.items():
                key_formatted = key.replace('_', ' ').title()
                report.append(f"- **{key_formatted}:** {value}")
            
            report.append("")
        
        # Dependências
        if summary.dependencies:
            report.extend([
                "## 🔗 Dependências Principais",
                ""
            ])
            
            for dep in summary.dependencies:
                report.append(f"- {dep}")
            
            report.append("")
        
        # Riscos
        if summary.risks:
            report.extend([
                "## ️ Riscos Identificados",
                ""
            ])
            
            for risk in summary.risks:
                report.append(f"- {risk}")
            
            report.append("")
        
        return '\n'.join(report)
