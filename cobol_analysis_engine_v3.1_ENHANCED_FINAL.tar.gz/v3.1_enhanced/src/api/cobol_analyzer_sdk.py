"""
COBOL Analyzer SDK - Interface para Notebooks e Scripts Python
Fornece uma interface simplificada para uso do COBOL Analysis Engine em notebooks Jupyter
"""

import os
import sys
import json
import asyncio
import logging
import pandas as pd
from typing import Dict, List, Any, Optional, Callable, Union
from pathlib import Path
from datetime import datetime
import tempfile
import yaml

# Adicionar o diretório src ao path se necessário
current_dir = os.path.dirname(os.path.abspath(__file__))
src_dir = os.path.dirname(current_dir)
if src_dir not in sys.path:
    sys.path.insert(0, src_dir)

# Importações do sistema principal
from config.config_loader import load_config
from extractors.content_extractor import COBOLContentExtractor
from generators.enriched_documentation_generator import EnrichedDocumentationGenerator

# Importações condicionais
try:
    from core.enhanced_orchestrator import EnhancedMultiAIOrchestrator, ContextExtractor
    MULTI_AI_AVAILABLE = True
except ImportError:
    MULTI_AI_AVAILABLE = False

try:
    from analyzers.business_logic_parser import COBOLBusinessLogicParser
    from analyzers.data_flow_analyzer import COBOLDataFlowAnalyzer
    ENHANCED_MODE_AVAILABLE = True
except ImportError:
    ENHANCED_MODE_AVAILABLE = False

class COBOLAnalyzer:
    """
    SDK principal para análise de código COBOL em notebooks e scripts Python
    
    Exemplo de uso:
    ```python
    from cobol_analyzer_sdk import COBOLAnalyzer
    
    analyzer = COBOLAnalyzer()
    result = analyzer.analyze_file("programa.cbl", mode="enhanced")
    print(result['summary'])
    ```
    """
    
    def __init__(self, config_path: Optional[str] = None, custom_config: Optional[Dict] = None):
        """
        Inicializa o analisador COBOL
        
        Args:
            config_path: Caminho para arquivo de configuração YAML
            custom_config: Configuração customizada como dicionário
        """
        self.logger = logging.getLogger(__name__)
        
        # Carregar configuração
        if custom_config:
            self.config = custom_config
        elif config_path and os.path.exists(config_path):
            self.config = load_config(config_path)
        else:
            # Configuração padrão
            self.config = self._get_default_config()
        
        # Inicializar componentes
        self.content_extractor = COBOLContentExtractor()
        self.enriched_generator = EnrichedDocumentationGenerator()
        
        # Componentes opcionais
        self.orchestrator = None
        self.business_parser = None
        self.data_analyzer = None
        
        if MULTI_AI_AVAILABLE:
            try:
                self.orchestrator = EnhancedMultiAIOrchestrator(self.config)
            except Exception as e:
                self.logger.warning(f"Não foi possível inicializar orquestrador: {e}")
        
        if ENHANCED_MODE_AVAILABLE:
            self.business_parser = COBOLBusinessLogicParser()
            self.data_analyzer = COBOLDataFlowAnalyzer()
        
        # Cache de resultados
        self._cache = {}
        self._enable_cache = self.config.get('cache', {}).get('enabled', True)
    
    def analyze_file(self, 
                    file_path: str, 
                    mode: str = "enhanced", 
                    output_dir: Optional[str] = None,
                    copybooks_path: Optional[str] = None) -> Dict[str, Any]:
        """
        Analisa um arquivo COBOL
        
        Args:
            file_path: Caminho para o arquivo COBOL
            mode: Modo de análise ('traditional', 'multi_ai', 'enhanced')
            output_dir: Diretório para salvar resultados (opcional)
            copybooks_path: Caminho para arquivo BOOKS.txt (opcional)
        
        Returns:
            Dicionário com resultado da análise
        """
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Arquivo não encontrado: {file_path}")
        
        # Verificar cache
        cache_key = f"{file_path}_{mode}_{copybooks_path}"
        if self._enable_cache and cache_key in self._cache:
            return self._cache[cache_key]
        
        try:
            # Extrair dados do programa
            extracted_data = self.content_extractor.extract_from_file(file_path)
            program_name = extracted_data.get('program_name', 
                                            os.path.splitext(os.path.basename(file_path))[0])
            
            # Processar copybooks se fornecido
            copybooks = {}
            if copybooks_path and os.path.exists(copybooks_path):
                copybooks = self._extract_copybooks_from_books(copybooks_path)
                extracted_data['copybooks'] = copybooks
            
            # Executar análise baseada no modo
            if mode in ['multi_ai', 'enhanced'] and self.orchestrator:
                result = asyncio.run(self._analyze_with_ai(
                    extracted_data, copybooks, program_name, mode
                ))
            else:
                result = self._analyze_traditional(extracted_data, program_name)
            
            # Salvar resultado se output_dir fornecido
            if output_dir:
                os.makedirs(output_dir, exist_ok=True)
                report_path = os.path.join(output_dir, f"{program_name}_{mode.upper()}_ANALYSIS.md")
                with open(report_path, 'w', encoding='utf-8') as f:
                    f.write(result['documentation'])
                result['report_path'] = report_path
            
            # Cache do resultado
            if self._enable_cache:
                self._cache[cache_key] = result
            
            return result
            
        except Exception as e:
            error_result = {
                'status': 'error',
                'error': str(e),
                'program_name': os.path.basename(file_path),
                'mode': mode,
                'timestamp': datetime.now().isoformat()
            }
            return error_result
    
    def analyze_code(self, 
                    cobol_code: str, 
                    program_name: str, 
                    mode: str = "enhanced",
                    copybooks: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
        """
        Analisa código COBOL diretamente (sem arquivo)
        
        Args:
            cobol_code: Código COBOL como string
            program_name: Nome do programa
            mode: Modo de análise
            copybooks: Dicionário com copybooks {nome: conteúdo}
        
        Returns:
            Dicionário com resultado da análise
        """
        try:
            # Extrair dados do código
            extracted_data = self.content_extractor.extract_from_content(cobol_code, program_name)
            
            if copybooks:
                extracted_data['copybooks'] = copybooks
            
            # Executar análise
            if mode in ['multi_ai', 'enhanced'] and self.orchestrator:
                result = asyncio.run(self._analyze_with_ai(
                    extracted_data, copybooks or {}, program_name, mode
                ))
            else:
                result = self._analyze_traditional(extracted_data, program_name)
            
            return result
            
        except Exception as e:
            return {
                'status': 'error',
                'error': str(e),
                'program_name': program_name,
                'mode': mode,
                'timestamp': datetime.now().isoformat()
            }
    
    def analyze_batch(self, 
                     fontes_path: str, 
                     books_path: Optional[str] = None,
                     mode: str = "enhanced",
                     output_dir: Optional[str] = None,
                     progress_callback: Optional[Callable] = None,
                     result_callback: Optional[Callable] = None,
                     max_programs: Optional[int] = None) -> List[Dict[str, Any]]:
        """
        Analisa múltiplos programas de um arquivo fontes.txt
        
        Args:
            fontes_path: Caminho para arquivo fontes.txt
            books_path: Caminho para arquivo BOOKS.txt (opcional)
            mode: Modo de análise
            output_dir: Diretório para salvar resultados
            progress_callback: Função chamada a cada programa processado
            result_callback: Função chamada com resultado de cada programa
            max_programs: Máximo de programas a processar (para testes)
        
        Returns:
            Lista com resultados de cada programa
        """
        if not os.path.exists(fontes_path):
            raise FileNotFoundError(f"Arquivo fontes.txt não encontrado: {fontes_path}")
        
        # Extrair programas e copybooks
        programs = self._extract_programs_from_fontes(fontes_path)
        copybooks = {}
        
        if books_path and os.path.exists(books_path):
            copybooks = self._extract_copybooks_from_books(books_path)
        
        # Limitar número de programas se especificado
        if max_programs:
            programs = programs[:max_programs]
        
        results = []
        total_programs = len(programs)
        
        for i, program in enumerate(programs, 1):
            try:
                # Callback de progresso
                if progress_callback:
                    progress_callback(i, total_programs, program['name'])
                
                # Analisar programa
                extracted_data = self.content_extractor.extract_from_content(
                    program['content'], program['name']
                )
                
                if copybooks:
                    extracted_data['copybooks'] = copybooks
                
                # Executar análise
                if mode in ['multi_ai', 'enhanced'] and self.orchestrator:
                    result = asyncio.run(self._analyze_with_ai(
                        extracted_data, copybooks, program['name'], mode
                    ))
                else:
                    result = self._analyze_traditional(extracted_data, program['name'])
                
                # Salvar resultado
                if output_dir:
                    os.makedirs(output_dir, exist_ok=True)
                    report_path = os.path.join(output_dir, f"{program['name']}_{mode.upper()}_ANALYSIS.md")
                    with open(report_path, 'w', encoding='utf-8') as f:
                        f.write(result['documentation'])
                    result['report_path'] = report_path
                
                results.append(result)
                
                # Callback de resultado
                if result_callback:
                    result_callback(program['name'], result)
                
            except Exception as e:
                error_result = {
                    'status': 'error',
                    'error': str(e),
                    'program_name': program['name'],
                    'mode': mode,
                    'timestamp': datetime.now().isoformat()
                }
                results.append(error_result)
        
        # Gerar resumo do lote
        if output_dir:
            self._generate_batch_summary(results, output_dir)
        
        return results
    
    def get_analysis_summary(self, analysis_result: Dict[str, Any]) -> Dict[str, Any]:
        """
        Extrai resumo de uma análise
        
        Args:
            analysis_result: Resultado de uma análise
        
        Returns:
            Dicionário com resumo da análise
        """
        summary = {
            'program_name': analysis_result.get('program_name', 'Unknown'),
            'status': analysis_result.get('status', 'unknown'),
            'mode': analysis_result.get('mode', 'unknown'),
            'timestamp': analysis_result.get('timestamp', 'unknown'),
            'execution_time': analysis_result.get('execution_time', 0),
            'documentation_lines': len(analysis_result.get('documentation', '').split('\n')),
            'file_size_kb': analysis_result.get('file_size_kb', 0)
        }
        
        # Adicionar métricas específicas se disponíveis
        if 'metrics' in analysis_result:
            summary.update(analysis_result['metrics'])
        
        return summary
    
    def export_to_format(self, 
                        analysis_result: Dict[str, Any], 
                        format: str = "pdf",
                        output_path: Optional[str] = None,
                        **kwargs) -> str:
        """
        Exporta resultado para diferentes formatos
        
        Args:
            analysis_result: Resultado da análise
            format: Formato de saída ('pdf', 'html', 'json', 'excel')
            output_path: Caminho de saída (opcional)
            **kwargs: Argumentos adicionais para formatação
        
        Returns:
            Caminho do arquivo gerado
        """
        if not output_path:
            program_name = analysis_result.get('program_name', 'analysis')
            output_path = f"{program_name}.{format}"
        
        if format.lower() == 'pdf':
            return self._export_to_pdf(analysis_result, output_path, **kwargs)
        elif format.lower() == 'html':
            return self._export_to_html(analysis_result, output_path, **kwargs)
        elif format.lower() == 'json':
            return self._export_to_json(analysis_result, output_path, **kwargs)
        elif format.lower() == 'excel':
            return self._export_to_excel(analysis_result, output_path, **kwargs)
        else:
            raise ValueError(f"Formato não suportado: {format}")
    
    def create_comparison_report(self, 
                               results: List[Dict[str, Any]], 
                               output_path: str = "comparison_report.html") -> str:
        """
        Cria relatório comparativo de múltiplas análises
        
        Args:
            results: Lista de resultados de análise
            output_path: Caminho para salvar o relatório
        
        Returns:
            Caminho do relatório gerado
        """
        # Criar DataFrame para comparação
        comparison_data = []
        for result in results:
            summary = self.get_analysis_summary(result)
            comparison_data.append(summary)
        
        df = pd.DataFrame(comparison_data)
        
        # Gerar HTML com gráficos
        html_content = self._generate_comparison_html(df)
        
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        return output_path
    
    def configure_provider(self, provider_name: str, config: Dict[str, Any]):
        """
        Configura um provedor de IA
        
        Args:
            provider_name: Nome do provedor ('openai', 'anthropic', etc.)
            config: Configuração do provedor
        """
        if not self.config.get('ai'):
            self.config['ai'] = {}
        
        self.config['ai'][provider_name] = config
        
        # Reinicializar orquestrador se necessário
        if self.orchestrator:
            self.orchestrator = EnhancedMultiAIOrchestrator(self.config)
    
    def set_custom_prompt(self, analysis_type: str, prompt_template: str):
        """
        Define prompt customizado para um tipo de análise
        
        Args:
            analysis_type: Tipo de análise ('structural', 'business', etc.)
            prompt_template: Template do prompt
        """
        if self.orchestrator and hasattr(self.orchestrator, 'prompt_generator'):
            self.orchestrator.prompt_generator.set_custom_prompt(analysis_type, prompt_template)
    
    def get_available_modes(self) -> List[str]:
        """
        Retorna modos de análise disponíveis
        
        Returns:
            Lista de modos disponíveis
        """
        modes = ['traditional']
        
        if MULTI_AI_AVAILABLE and self.orchestrator:
            modes.append('multi_ai')
        
        if ENHANCED_MODE_AVAILABLE:
            modes.append('enhanced')
        
        return modes
    
    def validate_cobol_syntax(self, cobol_code: str) -> Dict[str, Any]:
        """
        Valida sintaxe básica de código COBOL
        
        Args:
            cobol_code: Código COBOL para validar
        
        Returns:
            Resultado da validação
        """
        validation_result = {
            'is_valid': True,
            'errors': [],
            'warnings': [],
            'suggestions': []
        }
        
        lines = cobol_code.split('\n')
        
        # Verificações básicas
        has_identification = any('IDENTIFICATION DIVISION' in line.upper() for line in lines)
        has_program_id = any('PROGRAM-ID' in line.upper() for line in lines)
        
        if not has_identification:
            validation_result['errors'].append("IDENTIFICATION DIVISION não encontrada")
            validation_result['is_valid'] = False
        
        if not has_program_id:
            validation_result['errors'].append("PROGRAM-ID não encontrado")
            validation_result['is_valid'] = False
        
        return validation_result
    
    # Métodos privados
    
    async def _analyze_with_ai(self, extracted_data: Dict, copybooks: Dict, 
                              program_name: str, mode: str) -> Dict[str, Any]:
        """Executa análise com IA"""
        start_time = datetime.now()
        
        # Criar contexto de análise
        analysis_context = ContextExtractor.extract_from_fontes_batch([
            {
                'name': program_name,
                'content': extracted_data.get('content', '')
            }
        ], copybooks)
        
        # Executar análise
        orchestration_result = await self.orchestrator.analyze_program_with_context(
            cobol_code=extracted_data.get('content', ''),
            context=analysis_context[0],
            extracted_data=extracted_data
        )
        
        # Gerar documentação
        if mode == 'enhanced':
            # Extrair histórico de prompts
            prompt_history = []
            if hasattr(self.orchestrator, 'get_prompt_logger'):
                prompt_logger = self.orchestrator.get_prompt_logger()
                prompt_history = prompt_logger.get_prompts_for_program(program_name)
            
            # Extrair análises das IAs
            ai_analyses = {}
            for domain, result in orchestration_result.get('parallel_results', {}).items():
                if hasattr(result, 'success') and result.success:
                    ai_analyses[domain] = result
            
            documentation = self.enriched_generator.generate_enriched_documentation(
                program_name=program_name,
                cobol_code=extracted_data.get('content', ''),
                extracted_data=extracted_data,
                copybooks=copybooks,
                ai_analyses=ai_analyses,
                prompt_history=prompt_history
            )
        else:
            # Modo multi_ai padrão
            from generators.detailed_report_generator import DetailedReportGenerator
            report_gen = DetailedReportGenerator()
            
            analyses_data = {}
            for domain, result in orchestration_result.get('parallel_results', {}).items():
                if hasattr(result, 'success') and result.success:
                    analyses_data[domain] = getattr(result, 'analysis', {})
            
            documentation = report_gen.generate(extracted_data, analyses_data)
        
        execution_time = (datetime.now() - start_time).total_seconds()
        
        return {
            'status': 'success',
            'program_name': program_name,
            'mode': mode,
            'documentation': documentation,
            'orchestration_result': orchestration_result,
            'execution_time': execution_time,
            'timestamp': datetime.now().isoformat(),
            'file_size_kb': len(extracted_data.get('content', '')) / 1024
        }
    
    def _analyze_traditional(self, extracted_data: Dict, program_name: str) -> Dict[str, Any]:
        """Executa análise tradicional"""
        start_time = datetime.now()
        
        from generators.detailed_report_generator import DetailedReportGenerator
        report_gen = DetailedReportGenerator()
        
        documentation = report_gen.generate(extracted_data, {})
        execution_time = (datetime.now() - start_time).total_seconds()
        
        return {
            'status': 'success',
            'program_name': program_name,
            'mode': 'traditional',
            'documentation': documentation,
            'execution_time': execution_time,
            'timestamp': datetime.now().isoformat(),
            'file_size_kb': len(extracted_data.get('content', '')) / 1024
        }
    
    def _extract_programs_from_fontes(self, fontes_path: str) -> List[Dict[str, str]]:
        """Extrai programas do arquivo fontes.txt"""
        programs = []
        current_program = None
        current_lines = []
        
        with open(fontes_path, 'r', encoding='utf-8', errors='ignore') as f:
            for line in f:
                line = line.rstrip()
                
                if 'VMEMBER NAME' in line or 'MEMBER NAME' in line:
                    if current_program and current_lines:
                        programs.append({
                            'name': current_program,
                            'content': '\n'.join(current_lines)
                        })
                    
                    # Extrair nome do programa
                    if 'VMEMBER NAME' in line:
                        parts = line.split('VMEMBER NAME')
                        if len(parts) > 1:
                            current_program = parts[1].strip()
                    elif 'MEMBER NAME' in line:
                        parts = line.split('MEMBER NAME')
                        if len(parts) > 1:
                            current_program = parts[1].strip()
                    
                    current_lines = []
                
                if current_program:
                    clean_line = line[1:] if line.startswith('V') else line
                    current_lines.append(clean_line)
        
        # Adicionar último programa
        if current_program and current_lines:
            programs.append({
                'name': current_program,
                'content': '\n'.join(current_lines)
            })
        
        return programs
    
    def _extract_copybooks_from_books(self, books_path: str) -> Dict[str, str]:
        """Extrai copybooks do arquivo BOOKS.txt"""
        copybooks = {}
        current_book = None
        current_lines = []
        
        with open(books_path, 'r', encoding='utf-8', errors='ignore') as f:
            for line in f:
                line = line.rstrip()
                
                if 'MEMBER NAME' in line or 'BOOK' in line:
                    if current_book and current_lines:
                        copybooks[current_book] = '\n'.join(current_lines)
                    
                    # Extrair nome do copybook
                    parts = line.split()
                    for i, part in enumerate(parts):
                        if part == 'NAME' and i + 1 < len(parts):
                            current_book = parts[i + 1].strip()
                            break
                    current_lines = []
                
                if current_book:
                    current_lines.append(line)
        
        # Adicionar último copybook
        if current_book and current_lines:
            copybooks[current_book] = '\n'.join(current_lines)
        
        return copybooks
    
    def _generate_batch_summary(self, results: List[Dict], output_dir: str):
        """Gera resumo do processamento em lote"""
        summary_path = os.path.join(output_dir, "BATCH_PROCESSING_SUMMARY.md")
        
        successful = [r for r in results if r['status'] == 'success']
        failed = [r for r in results if r['status'] == 'error']
        
        summary = f"""# Relatório de Processamento em Lote - COBOL Analysis Engine

**Data:** {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}  
**Total de Programas:** {len(results)}  
**Sucessos:** {len(successful)}  
**Falhas:** {len(failed)}  
**Taxa de Sucesso:** {len(successful)/len(results)*100:.1f}%  

---

## Programas Processados com Sucesso

| Programa | Modo | Tempo (s) | Linhas Doc | Tamanho (KB) |
|----------|------|-----------|------------|--------------|
"""
        
        for result in successful:
            summary += f"| {result['program_name']} | {result['mode']} | {result.get('execution_time', 0):.2f} | {len(result.get('documentation', '').split())} | {result.get('file_size_kb', 0):.1f} |\n"
        
        if failed:
            summary += "\n## Programas com Falha\n\n"
            for result in failed:
                summary += f"- **{result['program_name']}**: {result['error']}\n"
        
        with open(summary_path, 'w', encoding='utf-8') as f:
            f.write(summary)
    
    def _export_to_pdf(self, analysis_result: Dict, output_path: str, **kwargs) -> str:
        """Exporta para PDF"""
        try:
            import weasyprint
            
            # Converter Markdown para HTML
            html_content = self._markdown_to_html(analysis_result['documentation'])
            
            # Gerar PDF
            weasyprint.HTML(string=html_content).write_pdf(output_path)
            return output_path
            
        except ImportError:
            raise ImportError("weasyprint não instalado. Execute: pip install weasyprint")
    
    def _export_to_html(self, analysis_result: Dict, output_path: str, **kwargs) -> str:
        """Exporta para HTML"""
        html_content = self._markdown_to_html(analysis_result['documentation'])
        
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        return output_path
    
    def _export_to_json(self, analysis_result: Dict, output_path: str, **kwargs) -> str:
        """Exporta para JSON"""
        # Remover objetos não serializáveis
        clean_result = {
            'program_name': analysis_result.get('program_name'),
            'status': analysis_result.get('status'),
            'mode': analysis_result.get('mode'),
            'timestamp': analysis_result.get('timestamp'),
            'execution_time': analysis_result.get('execution_time'),
            'documentation': analysis_result.get('documentation'),
            'summary': self.get_analysis_summary(analysis_result)
        }
        
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(clean_result, f, indent=2, ensure_ascii=False)
        
        return output_path
    
    def _export_to_excel(self, analysis_result: Dict, output_path: str, **kwargs) -> str:
        """Exporta para Excel"""
        try:
            import openpyxl
            from openpyxl import Workbook
            
            wb = Workbook()
            
            # Aba de resumo
            ws_summary = wb.active
            ws_summary.title = "Resumo"
            
            summary = self.get_analysis_summary(analysis_result)
            row = 1
            for key, value in summary.items():
                ws_summary.cell(row=row, column=1, value=key)
                ws_summary.cell(row=row, column=2, value=str(value))
                row += 1
            
            # Aba de documentação
            ws_doc = wb.create_sheet("Documentação")
            doc_lines = analysis_result.get('documentation', '').split('\n')
            for i, line in enumerate(doc_lines, 1):
                ws_doc.cell(row=i, column=1, value=line)
            
            wb.save(output_path)
            return output_path
            
        except ImportError:
            raise ImportError("openpyxl não instalado. Execute: pip install openpyxl")
    
    def _markdown_to_html(self, markdown_content: str) -> str:
        """Converte Markdown para HTML"""
        try:
            import markdown
            
            html = markdown.markdown(markdown_content, extensions=['tables', 'fenced_code'])
            
            # Template HTML básico
            return f"""
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="utf-8">
                <title>Análise COBOL</title>
                <style>
                    body {{ font-family: Arial, sans-serif; margin: 40px; }}
                    table {{ border-collapse: collapse; width: 100%; }}
                    th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
                    th {{ background-color: #f2f2f2; }}
                    code {{ background-color: #f4f4f4; padding: 2px 4px; }}
                    pre {{ background-color: #f4f4f4; padding: 10px; overflow-x: auto; }}
                </style>
            </head>
            <body>
                {html}
            </body>
            </html>
            """
        except ImportError:
            # Fallback simples sem markdown
            return f"""
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="utf-8">
                <title>Análise COBOL</title>
            </head>
            <body>
                <pre>{markdown_content}</pre>
            </body>
            </html>
            """
    
    def _generate_comparison_html(self, df: pd.DataFrame) -> str:
        """Gera HTML com comparação de resultados"""
        html_content = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8">
            <title>Relatório Comparativo - COBOL Analysis</title>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 40px; }}
                table {{ border-collapse: collapse; width: 100%; margin: 20px 0; }}
                th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
                th {{ background-color: #f2f2f2; }}
                .metric {{ background-color: #e8f4fd; }}
            </style>
        </head>
        <body>
            <h1>Relatório Comparativo de Análises COBOL</h1>
            <p><strong>Data:</strong> {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}</p>
            
            <h2>Resumo Geral</h2>
            <ul>
                <li><strong>Total de Programas:</strong> {len(df)}</li>
                <li><strong>Sucessos:</strong> {len(df[df['status'] == 'success'])}</li>
                <li><strong>Falhas:</strong> {len(df[df['status'] == 'error'])}</li>
                <li><strong>Tempo Médio:</strong> {df['execution_time'].mean():.2f}s</li>
            </ul>
            
            <h2>Detalhes por Programa</h2>
            {df.to_html(classes='comparison-table', escape=False)}
        </body>
        </html>
        """
        return html_content
    
    def _get_default_config(self) -> Dict[str, Any]:
        """Retorna configuração padrão"""
        return {
            'system': {
                'version': '2.0',
                'log_level': 'INFO',
                'timeout_seconds': 300
            },
            'analysis': {
                'default_mode': 'enhanced',
                'max_file_size_mb': 50
            },
            'output': {
                'format': 'markdown',
                'include_prompts': True
            },
            'cache': {
                'enabled': True,
                'ttl_hours': 24
            },
            'ai': {
                'default_provider': 'openai'
            }
        }


# Funções de conveniência para uso direto

def quick_analyze(file_path: str, mode: str = "enhanced") -> Dict[str, Any]:
    """
    Análise rápida de um arquivo COBOL
    
    Args:
        file_path: Caminho para arquivo COBOL
        mode: Modo de análise
    
    Returns:
        Resultado da análise
    """
    analyzer = COBOLAnalyzer()
    return analyzer.analyze_file(file_path, mode)

def analyze_with_copybooks(cobol_file: str, books_file: str, mode: str = "enhanced") -> Dict[str, Any]:
    """
    Análise com copybooks
    
    Args:
        cobol_file: Arquivo COBOL
        books_file: Arquivo BOOKS.txt
        mode: Modo de análise
    
    Returns:
        Resultado da análise
    """
    analyzer = COBOLAnalyzer()
    return analyzer.analyze_file(cobol_file, mode, copybooks_path=books_file)

def batch_analyze(fontes_file: str, books_file: str = None, output_dir: str = "results/") -> List[Dict[str, Any]]:
    """
    Análise em lote
    
    Args:
        fontes_file: Arquivo fontes.txt
        books_file: Arquivo BOOKS.txt (opcional)
        output_dir: Diretório de saída
    
    Returns:
        Lista de resultados
    """
    analyzer = COBOLAnalyzer()
    return analyzer.analyze_batch(fontes_file, books_file, output_dir=output_dir)


# Classe para uso em notebooks Jupyter com widgets

class JupyterCOBOLAnalyzer(COBOLAnalyzer):
    """Versão especializada para notebooks Jupyter com widgets interativos"""
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._setup_jupyter_environment()
    
    def _setup_jupyter_environment(self):
        """Configura ambiente Jupyter"""
        try:
            from IPython.display import display, HTML, Markdown
            from tqdm.notebook import tqdm
            self.display = display
            self.HTML = HTML
            self.Markdown = Markdown
            self.tqdm = tqdm
            self._jupyter_available = True
        except ImportError:
            self._jupyter_available = False
    
    def interactive_analyze(self):
        """Cria interface interativa para análise"""
        if not self._jupyter_available:
            print("Interface interativa requer Jupyter notebook")
            return
        
        try:
            import ipywidgets as widgets
            
            # Widgets
            file_upload = widgets.FileUpload(
                accept='.cbl,.cob,.cobol',
                multiple=False,
                description='Upload COBOL'
            )
            
            mode_dropdown = widgets.Dropdown(
                options=self.get_available_modes(),
                value='enhanced',
                description='Modo:'
            )
            
            analyze_button = widgets.Button(
                description='Analisar',
                button_style='success'
            )
            
            output_area = widgets.Output()
            
            def on_analyze_click(b):
                with output_area:
                    output_area.clear_output()
                    if file_upload.value:
                        # Salvar arquivo temporário
                        content = file_upload.value[0]['content']
                        with tempfile.NamedTemporaryFile(mode='wb', suffix='.cbl', delete=False) as f:
                            f.write(content)
                            temp_path = f.name
                        
                        try:
                            # Analisar
                            result = self.analyze_file(temp_path, mode_dropdown.value)
                            
                            if result['status'] == 'success':
                                print("✅ Análise concluída com sucesso!")
                                
                                # Exibir resumo
                                summary = self.get_analysis_summary(result)
                                summary_df = pd.DataFrame([summary]).T
                                summary_df.columns = ['Valor']
                                self.display(summary_df)
                                
                                # Exibir documentação
                                self.display(self.Markdown(result['documentation']))
                            else:
                                print(f"❌ Erro na análise: {result['error']}")
                        
                        finally:
                            # Limpar arquivo temporário
                            os.unlink(temp_path)
            
            analyze_button.on_click(on_analyze_click)
            
            # Layout
            self.display(widgets.VBox([
                widgets.HBox([file_upload, mode_dropdown]),
                analyze_button,
                output_area
            ]))
            
        except ImportError:
            print("Widgets interativos requerem ipywidgets: pip install ipywidgets")
    
    def display_comparison(self, results: List[Dict[str, Any]]):
        """Exibe comparação visual de resultados"""
        if not self._jupyter_available:
            print("Visualização requer Jupyter notebook")
            return
        
        try:
            import matplotlib.pyplot as plt
            import seaborn as sns
            
            # Criar DataFrame
            df = pd.DataFrame([self.get_analysis_summary(r) for r in results])
            
            # Gráficos
            fig, axes = plt.subplots(2, 2, figsize=(15, 10))
            
            # Status
            df['status'].value_counts().plot(kind='pie', ax=axes[0,0], title='Status das Análises')
            
            # Tempo de execução
            df.plot(x='program_name', y='execution_time', kind='bar', ax=axes[0,1], title='Tempo de Execução')
            axes[0,1].tick_params(axis='x', rotation=45)
            
            # Tamanho dos arquivos
            df.plot(x='program_name', y='file_size_kb', kind='bar', ax=axes[1,0], title='Tamanho dos Arquivos (KB)')
            axes[1,0].tick_params(axis='x', rotation=45)
            
            # Linhas de documentação
            df.plot(x='program_name', y='documentation_lines', kind='bar', ax=axes[1,1], title='Linhas de Documentação')
            axes[1,1].tick_params(axis='x', rotation=45)
            
            plt.tight_layout()
            plt.show()
            
            # Tabela de dados
            self.display(df)
            
        except ImportError:
            print("Visualizações requerem matplotlib e seaborn")
            # Fallback para tabela simples
            df = pd.DataFrame([self.get_analysis_summary(r) for r in results])
            self.display(df)


# Exemplo de uso
if __name__ == "__main__":
    # Teste básico
    analyzer = COBOLAnalyzer()
    print(f"Modos disponíveis: {analyzer.get_available_modes()}")
    
    # Teste de validação
    test_code = """
    IDENTIFICATION DIVISION.
    PROGRAM-ID. TESTE.
    """
    validation = analyzer.validate_cobol_syntax(test_code)
    print(f"Validação: {validation}")
