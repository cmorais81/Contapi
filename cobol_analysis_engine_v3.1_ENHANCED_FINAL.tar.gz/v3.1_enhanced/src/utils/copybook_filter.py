"""
Utilitário para filtrar copybooks por programa COBOL
"""

import re
from typing import Dict, List, Any

def filter_copybooks_for_program(program: Dict[str, Any], all_copybooks: Dict[str, str]) -> Dict[str, str]:
    """
    Filtra copybooks relevantes para um programa específico
    
    Args:
        program: Dicionário com dados do programa (name, content)
        all_copybooks: Dicionário com todos os copybooks disponíveis
        
    Returns:
        Dicionário com copybooks relevantes para o programa
    """
    
    if not all_copybooks:
        return {}
    
    program_content = program.get('content', '')
    if not program_content:
        return {}
    
    relevant_copybooks = {}
    
    # Padrões para identificar copybooks no código COBOL
    copy_patterns = [
        r'COPY\s+([A-Z0-9]+)',
        r'INCLUDE\s+([A-Z0-9]+)',
        r'COPY\s+"([A-Z0-9]+)"',
        r'INCLUDE\s+"([A-Z0-9]+)"'
    ]
    
    # Procurar por referências a copybooks no código
    for pattern in copy_patterns:
        matches = re.findall(pattern, program_content, re.IGNORECASE)
        for match in matches:
            copybook_name = match.upper()
            
            # Procurar copybook exato
            if copybook_name in all_copybooks:
                relevant_copybooks[copybook_name] = all_copybooks[copybook_name]
            else:
                # Procurar por nome similar (sem extensão, etc.)
                for cb_name, cb_content in all_copybooks.items():
                    if copybook_name in cb_name.upper() or cb_name.upper() in copybook_name:
                        relevant_copybooks[cb_name] = cb_content
                        break
    
    # Se não encontrou copybooks específicos, usar heurística baseada no nome do programa
    if not relevant_copybooks:
        program_name = program.get('name', '').upper()
        
        # Procurar copybooks com nomes similares ao programa
        for cb_name, cb_content in all_copybooks.items():
            cb_name_upper = cb_name.upper()
            
            # Verificar se o nome do copybook está relacionado ao programa
            if (program_name[:4] in cb_name_upper or 
                cb_name_upper[:4] in program_name or
                any(part in cb_name_upper for part in program_name.split('_') if len(part) > 2)):
                relevant_copybooks[cb_name] = cb_content
    
    return relevant_copybooks

def get_copybook_usage_stats(program: Dict[str, Any], copybooks: Dict[str, str]) -> Dict[str, Any]:
    """
    Retorna estatísticas de uso de copybooks no programa
    
    Args:
        program: Dicionário com dados do programa
        copybooks: Dicionário com copybooks relevantes
        
    Returns:
        Dicionário com estatísticas de uso
    """
    
    program_content = program.get('content', '')
    stats = {
        'total_copybooks': len(copybooks),
        'copybooks_used': [],
        'copy_statements': 0,
        'include_statements': 0
    }
    
    # Contar statements COPY e INCLUDE
    copy_matches = re.findall(r'COPY\s+', program_content, re.IGNORECASE)
    include_matches = re.findall(r'INCLUDE\s+', program_content, re.IGNORECASE)
    
    stats['copy_statements'] = len(copy_matches)
    stats['include_statements'] = len(include_matches)
    
    # Identificar quais copybooks são realmente usados
    for cb_name in copybooks.keys():
        if cb_name.upper() in program_content.upper():
            stats['copybooks_used'].append(cb_name)
    
    return stats

def create_copybook_summary(copybooks: Dict[str, str]) -> str:
    """
    Cria um resumo dos copybooks para incluir na documentação
    
    Args:
        copybooks: Dicionário com copybooks relevantes
        
    Returns:
        String com resumo formatado dos copybooks
    """
    
    if not copybooks:
        return "Nenhum copybook identificado para este programa."
    
    summary = f"**Copybooks Identificados:** {len(copybooks)}\n\n"
    
    for cb_name, cb_content in copybooks.items():
        lines = cb_content.split('\n')
        non_empty_lines = [line for line in lines if line.strip()]
        
        summary += f"- **{cb_name}**: {len(non_empty_lines)} linhas de definições\n"
        
        # Tentar identificar o tipo de copybook
        if 'PIC' in cb_content.upper():
            summary += f"  - Contém definições de campos de dados\n"
        if 'OCCURS' in cb_content.upper():
            summary += f"  - Contém estruturas repetitivas (arrays)\n"
        if 'REDEFINES' in cb_content.upper():
            summary += f"  - Contém redefinições de campos\n"
        
        summary += "\n"
    
    return summary
