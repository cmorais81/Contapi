"""
Sistema de Cache para Análises COBOL v3.1
Evita reprocessamento desnecessário e melhora performance
"""

import os
import json
import hashlib
import time
from typing import Dict, Any, Optional
from pathlib import Path

class AnalysisCache:
    """Sistema de cache para análises COBOL"""
    
    def __init__(self, cache_dir: str = "cache"):
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(exist_ok=True)
        self.cache_stats = {
            'hits': 0,
            'misses': 0,
            'saves': 0,
            'total_time_saved': 0.0
        }
    
    def _generate_cache_key(self, program_name: str, cobol_code: str, 
                          copybooks: Dict[str, Any], mode: str = "refined") -> str:
        """Gera chave única para o cache baseada no conteúdo"""
        # Criar hash do conteúdo para detectar mudanças
        content_hash = hashlib.md5()
        content_hash.update(program_name.encode('utf-8'))
        content_hash.update(cobol_code.encode('utf-8'))
        content_hash.update(json.dumps(copybooks, sort_keys=True).encode('utf-8'))
        content_hash.update(mode.encode('utf-8'))
        
        return f"{program_name}_{mode}_{content_hash.hexdigest()[:12]}"
    
    def _get_cache_file_path(self, cache_key: str) -> Path:
        """Retorna caminho do arquivo de cache"""
        return self.cache_dir / f"{cache_key}.json"
    
    def get_cached_analysis(self, program_name: str, cobol_code: str, 
                           copybooks: Dict[str, Any], mode: str = "refined",
                           max_age_hours: int = 24) -> Optional[Dict[str, Any]]:
        """Recupera análise do cache se disponível e válida"""
        try:
            cache_key = self._generate_cache_key(program_name, cobol_code, copybooks, mode)
            cache_file = self._get_cache_file_path(cache_key)
            
            if not cache_file.exists():
                self.cache_stats['misses'] += 1
                return None
            
            # Verificar idade do cache
            file_age = time.time() - cache_file.stat().st_mtime
            if file_age > (max_age_hours * 3600):
                print(f"Cache expirado para {program_name} (idade: {file_age/3600:.1f}h)")
                cache_file.unlink()  # Remove cache expirado
                self.cache_stats['misses'] += 1
                return None
            
            # Carregar dados do cache
            with open(cache_file, 'r', encoding='utf-8') as f:
                cached_data = json.load(f)
            
            # Atualizar estatísticas
            self.cache_stats['hits'] += 1
            processing_time = cached_data.get('metadata', {}).get('processing_time', 0)
            self.cache_stats['total_time_saved'] += processing_time
            
            print(f"Cache HIT para {program_name} (economizou {processing_time:.2f}s)")
            return cached_data
            
        except Exception as e:
            print(f"Erro ao acessar cache para {program_name}: {e}")
            self.cache_stats['misses'] += 1
            return None
    
    def save_analysis_to_cache(self, program_name: str, cobol_code: str,
                              copybooks: Dict[str, Any], analysis_result: Dict[str, Any],
                              mode: str = "refined", processing_time: float = 0.0):
        """Salva análise no cache"""
        try:
            cache_key = self._generate_cache_key(program_name, cobol_code, copybooks, mode)
            cache_file = self._get_cache_file_path(cache_key)
            
            # Preparar dados para cache
            cache_data = {
                'program_name': program_name,
                'mode': mode,
                'analysis_result': analysis_result,
                'metadata': {
                    'cached_at': time.time(),
                    'processing_time': processing_time,
                    'cache_key': cache_key,
                    'cobol_lines': len(cobol_code.split('\n')),
                    'copybooks_count': len(copybooks)
                }
            }
            
            # Salvar no cache
            with open(cache_file, 'w', encoding='utf-8') as f:
                json.dump(cache_data, f, indent=2, ensure_ascii=False)
            
            self.cache_stats['saves'] += 1
            print(f"Análise de {program_name} salva no cache ({processing_time:.2f}s)")
            
        except Exception as e:
            print(f"Erro ao salvar cache para {program_name}: {e}")
    
    def clear_cache(self, older_than_hours: int = 0):
        """Limpa cache antigo"""
        cleared_count = 0
        current_time = time.time()
        
        try:
            for cache_file in self.cache_dir.glob("*.json"):
                if older_than_hours > 0:
                    file_age = current_time - cache_file.stat().st_mtime
                    if file_age > (older_than_hours * 3600):
                        cache_file.unlink()
                        cleared_count += 1
                else:
                    cache_file.unlink()
                    cleared_count += 1
            
            print(f"Cache limpo: {cleared_count} arquivos removidos")
            
        except Exception as e:
            print(f"Erro ao limpar cache: {e}")
    
    def get_cache_stats(self) -> Dict[str, Any]:
        """Retorna estatísticas do cache"""
        total_requests = self.cache_stats['hits'] + self.cache_stats['misses']
        hit_rate = (self.cache_stats['hits'] / total_requests * 100) if total_requests > 0 else 0
        
        return {
            'hits': self.cache_stats['hits'],
            'misses': self.cache_stats['misses'],
            'saves': self.cache_stats['saves'],
            'hit_rate': hit_rate,
            'total_time_saved': self.cache_stats['total_time_saved'],
            'cache_files': len(list(self.cache_dir.glob("*.json")))
        }
    
    def get_cache_info(self) -> str:
        """Retorna informações do cache em formato legível"""
        stats = self.get_cache_stats()
        
        info = f"""CACHE DE ANÁLISES - ESTATÍSTICAS
========================================
Requisições atendidas pelo cache: {stats['hits']}
Análises processadas (cache miss): {stats['misses']}
Taxa de acerto: {stats['hit_rate']:.1f}%
Tempo total economizado: {stats['total_time_saved']:.2f}s
Arquivos em cache: {stats['cache_files']}
Análises salvas no cache: {stats['saves']}
========================================"""
        
        return info
