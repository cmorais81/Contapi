"""
Sistema de Paralelização para Análises COBOL v3.1
Processa múltiplos programas simultaneamente para melhor performance
"""

import asyncio
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Dict, List, Any, Callable, Optional
from pathlib import Path

class ParallelProcessor:
    """Sistema de processamento paralelo para análises COBOL"""
    
    def __init__(self, max_workers: int = 4):
        self.max_workers = max_workers
        self.stats = {
            'total_programs': 0,
            'processed_parallel': 0,
            'processed_sequential': 0,
            'total_time': 0.0,
            'parallel_time_saved': 0.0
        }
    
    async def process_programs_parallel(self, programs: List[Dict[str, Any]], 
                                      analysis_function: Callable,
                                      copybooks: Dict[str, Any],
                                      output_dir: str,
                                      mode: str = "refined") -> List[Dict[str, Any]]:
        """Processa programas em paralelo usando asyncio"""
        
        start_time = time.time()
        self.stats['total_programs'] = len(programs)
        
        print(f"Iniciando processamento paralelo de {len(programs)} programas")
        print(f"Workers simultâneos: {min(self.max_workers, len(programs))}")
        
        # Criar semáforo para limitar concorrência
        semaphore = asyncio.Semaphore(self.max_workers)
        
        # Criar tasks para processamento paralelo
        tasks = []
        for i, program in enumerate(programs, 1):
            task = self._process_single_program_async(
                semaphore, program, analysis_function, copybooks, 
                output_dir, mode, i, len(programs)
            )
            tasks.append(task)
        
        # Executar todas as tasks em paralelo
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Processar resultados
        successful_results = []
        failed_results = []
        
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                failed_results.append({
                    'program': programs[i]['name'],
                    'error': str(result),
                    'status': 'failed'
                })
                print(f"ERRO no programa {programs[i]['name']}: {result}")
            else:
                successful_results.append(result)
        
        # Atualizar estatísticas
        end_time = time.time()
        self.stats['total_time'] = end_time - start_time
        self.stats['processed_parallel'] = len(successful_results)
        
        # Estimar tempo que seria gasto sequencialmente
        avg_time_per_program = self.stats['total_time'] / len(programs) * self.max_workers
        estimated_sequential_time = avg_time_per_program * len(programs)
        self.stats['parallel_time_saved'] = max(0, estimated_sequential_time - self.stats['total_time'])
        
        print(f"\nProcessamento paralelo concluído:")
        print(f"Tempo total: {self.stats['total_time']:.2f}s")
        print(f"Programas processados: {len(successful_results)}/{len(programs)}")
        if self.stats['parallel_time_saved'] > 0:
            print(f"Tempo economizado: {self.stats['parallel_time_saved']:.2f}s")
        
        return successful_results + failed_results
    
    async def _process_single_program_async(self, semaphore: asyncio.Semaphore,
                                          program: Dict[str, Any],
                                          analysis_function: Callable,
                                          copybooks: Dict[str, Any],
                                          output_dir: str,
                                          mode: str,
                                          program_index: int,
                                          total_programs: int) -> Dict[str, Any]:
        """Processa um único programa de forma assíncrona"""
        
        async with semaphore:
            start_time = time.time()
            
            try:
                print(f"[{program_index}/{total_programs}] Processando {program['name']} (paralelo)")
                
                # Executar análise (sempre síncrona)
                loop = asyncio.get_event_loop()
                result = await loop.run_in_executor(
                    None,
                    analysis_function,
                    program,
                    copybooks,
                    output_dir,
                    mode
                )
                
                processing_time = time.time() - start_time
                
                return {
                    'name': program['name'],
                    'status': 'success',
                    'processing_time': processing_time,
                    'result': result
                }
                
            except Exception as e:
                processing_time = time.time() - start_time
                print(f"Erro ao processar {program['name']}: {e}")
                
                return {
                    'name': program['name'],
                    'status': 'failed',
                    'processing_time': processing_time,
                    'error': str(e)
                }
    
    def process_programs_threaded(self, programs: List[Dict[str, Any]],
                                 analysis_function: Callable,
                                 copybooks: Dict[str, Any],
                                 output_dir: str,
                                 mode: str = "refined") -> List[Dict[str, Any]]:
        """Processa programas usando ThreadPoolExecutor (para funções síncronas)"""
        
        start_time = time.time()
        self.stats['total_programs'] = len(programs)
        
        print(f"Iniciando processamento com threads de {len(programs)} programas")
        print(f"Threads simultâneas: {min(self.max_workers, len(programs))}")
        
        results = []
        
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            # Submeter todas as tarefas
            future_to_program = {
                executor.submit(
                    self._process_single_program_sync,
                    program, analysis_function, copybooks, output_dir, mode, i, len(programs)
                ): program for i, program in enumerate(programs, 1)
            }
            
            # Coletar resultados conforme completam
            for future in as_completed(future_to_program):
                program = future_to_program[future]
                try:
                    result = future.result()
                    results.append(result)
                except Exception as e:
                    results.append({
                        'name': program['name'],
                        'status': 'failed',
                        'error': str(e)
                    })
                    print(f"Erro ao processar {program['name']}: {e}")
        
        # Atualizar estatísticas
        end_time = time.time()
        self.stats['total_time'] = end_time - start_time
        self.stats['processed_parallel'] = len([r for r in results if r.get('status') == 'success'])
        
        print(f"\nProcessamento com threads concluído:")
        print(f"Tempo total: {self.stats['total_time']:.2f}s")
        print(f"Programas processados: {self.stats['processed_parallel']}/{len(programs)}")
        
        return results
    
    def _process_single_program_sync(self, program: Dict[str, Any],
                                   analysis_function: Callable,
                                   copybooks: Dict[str, Any],
                                   output_dir: str,
                                   mode: str,
                                   program_index: int,
                                   total_programs: int) -> Dict[str, Any]:
        """Processa um único programa de forma síncrona"""
        
        start_time = time.time()
        
        try:
            print(f"[{program_index}/{total_programs}] Processando {program['name']} (thread)")
            
            result = analysis_function(
                program=program,
                copybooks=copybooks,
                output_dir=output_dir,
                mode=mode
            )
            
            processing_time = time.time() - start_time
            
            return {
                'name': program['name'],
                'status': 'success',
                'processing_time': processing_time,
                'result': result
            }
            
        except Exception as e:
            processing_time = time.time() - start_time
            
            return {
                'name': program['name'],
                'status': 'failed',
                'processing_time': processing_time,
                'error': str(e)
            }
    
    def get_performance_stats(self) -> Dict[str, Any]:
        """Retorna estatísticas de performance"""
        return {
            'total_programs': self.stats['total_programs'],
            'processed_parallel': self.stats['processed_parallel'],
            'success_rate': (self.stats['processed_parallel'] / self.stats['total_programs'] * 100) 
                           if self.stats['total_programs'] > 0 else 0,
            'total_time': self.stats['total_time'],
            'avg_time_per_program': (self.stats['total_time'] / self.stats['total_programs']) 
                                   if self.stats['total_programs'] > 0 else 0,
            'parallel_time_saved': self.stats['parallel_time_saved'],
            'max_workers': self.max_workers
        }
    
    def get_performance_report(self) -> str:
        """Retorna relatório de performance em formato legível"""
        stats = self.get_performance_stats()
        
        report = f"""PROCESSAMENTO PARALELO - RELATÓRIO DE PERFORMANCE
========================================================
Total de programas: {stats['total_programs']}
Processados com sucesso: {stats['processed_parallel']}
Taxa de sucesso: {stats['success_rate']:.1f}%
Tempo total: {stats['total_time']:.2f}s
Tempo médio por programa: {stats['avg_time_per_program']:.2f}s
Workers paralelos: {stats['max_workers']}
Tempo economizado: {stats['parallel_time_saved']:.2f}s
========================================================"""
        
        return report
