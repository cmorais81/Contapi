"""
Sistema de captura de prompts e respostas das IAs
COBOL Analysis Engine v2.0
"""

import json
import time
from typing import Dict, Any, List
from datetime import datetime

class PromptResponseLogger:
    """Captura e armazena prompts enviados e respostas recebidas das IAs"""
    
    def __init__(self):
        self.prompt_history: List[Dict[str, Any]] = []
    
    def log_interaction(self, 
                       provider_name: str,
                       prompt_type: str,
                       prompt_sent: str,
                       response_received: str,
                       success: bool = True,
                       execution_time: float = 0.0,
                       tokens_used: int = 0,
                       model_used: str = None) -> None:
        """Registra uma interação completa com uma IA"""
        
        interaction = {
            "timestamp": datetime.now().isoformat(),
            "provider": provider_name,
            "prompt_type": prompt_type,
            "prompt": prompt_sent,
            "response": response_received,
            "success": success,
            "execution_time": execution_time,
            "tokens_used": tokens_used,
            "model": model_used,
            "interaction_id": len(self.prompt_history) + 1
        }
        
        self.prompt_history.append(interaction)
    
    def get_prompt_history(self) -> List[Dict[str, Any]]:
        """Retorna histórico completo de prompts e respostas"""
        return self.prompt_history.copy()
    
    def get_successful_interactions(self) -> List[Dict[str, Any]]:
        """Retorna apenas interações bem-sucedidas"""
        return [interaction for interaction in self.prompt_history if interaction.get('success', False)]
    
    def get_interactions_by_provider(self, provider_name: str) -> List[Dict[str, Any]]:
        """Retorna interações de um provedor específico"""
        return [interaction for interaction in self.prompt_history 
                if interaction.get('provider') == provider_name]
    
    def clear_history(self) -> None:
        """Limpa o histórico de interações"""
        self.prompt_history.clear()
    
    def get_summary(self) -> Dict[str, Any]:
        """Retorna resumo das interações"""
        total_interactions = len(self.prompt_history)
        successful_interactions = len(self.get_successful_interactions())
        
        providers_used = set(interaction.get('provider') for interaction in self.prompt_history)
        
        total_tokens = sum(interaction.get('tokens_used', 0) for interaction in self.prompt_history)
        total_time = sum(interaction.get('execution_time', 0) for interaction in self.prompt_history)
        
        return {
            "total_interactions": total_interactions,
            "successful_interactions": successful_interactions,
            "success_rate": successful_interactions / total_interactions if total_interactions > 0 else 0,
            "providers_used": list(providers_used),
            "total_tokens_used": total_tokens,
            "total_execution_time": total_time,
            "average_response_time": total_time / total_interactions if total_interactions > 0 else 0
        }
    
    def export_to_json(self, filepath: str) -> None:
        """Exporta histórico para arquivo JSON"""
        export_data = {
            "export_timestamp": datetime.now().isoformat(),
            "summary": self.get_summary(),
            "interactions": self.prompt_history
        }
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(export_data, f, indent=2, ensure_ascii=False)
