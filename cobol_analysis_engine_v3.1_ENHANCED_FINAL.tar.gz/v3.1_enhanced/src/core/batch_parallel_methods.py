"""
Métodos para processamento em lote paralelo v3.1
Adiciona funcionalidades de cache e paralelização ao sistema principal
"""

import os
import time
import asyncio
from typing import Dict, List, Any

async def analyze_batch_parallel(self, fontes_file: str, books_file: str = None, 
                               output_dir: str = "resultado", mode: str = "refined") -> List[Dict[str, Any]]:
    """Processa lote de programas com paralelização e cache"""
    
    print(f"COBOL Analysis Engine v3.1 - Processamento Paralelo")
    print("=" * 60)
    
    # Extrair programas do arquivo fontes
    programs = self.extract_programs_from_fontes(fontes_file)
    if not programs:
        print("Nenhum programa encontrado no arquivo fontes")
        return []
    
    # Carregar copybooks se fornecido
    all_copybooks = {}
    if books_file and os.path.exists(books_file):
        all_copybooks = self.extract_copybooks_from_books(books_file)
        print(f"Encontrados {len(all_copybooks)} copybooks")
    
    print(f"Encontrados {len(programs)} programas para análise")
    
    # Verificar cache para cada programa
    cached_results = []
    programs_to_process = []
    
    if self.analysis_cache:
        print("Verificando cache de análises...")
        for program in programs:
            program_copybooks = self.filter_copybooks_for_program(program, all_copybooks)
            
            cached_analysis = self.analysis_cache.get_cached_analysis(
                program_name=program['name'],
                cobol_code=program.get('content', ''),
                copybooks=program_copybooks,
                mode=mode
            )
            
            if cached_analysis:
                # Usar análise do cache
                cached_results.append({
                    'name': program['name'],
                    'status': 'success',
                    'source': 'cache',
                    'processing_time': 0.0,
                    'cached_data': cached_analysis
                })
            else:
                programs_to_process.append(program)
    else:
        programs_to_process = programs
    
    print(f"Programas em cache: {len(cached_results)}")
    print(f"Programas para processar: {len(programs_to_process)}")
    
    # Processar programas restantes em paralelo
    parallel_results = []
    if programs_to_process:
        parallel_results = await self.parallel_processor.process_programs_parallel(
            programs=programs_to_process,
            analysis_function=self._analyze_single_program_with_cache,
            copybooks=all_copybooks,
            output_dir=output_dir,
            mode=mode
        )
    
    # Combinar resultados
    all_results = cached_results + parallel_results
    
    # Gerar relatório de resumo
    await self._generate_batch_summary_v31(all_results, output_dir, mode)
    
    # Exibir estatísticas finais
    self._display_v31_statistics(all_results)
    
    return all_results

async def _analyze_single_program_with_cache(self, program: Dict[str, Any], 
                                           copybooks: Dict[str, Any],
                                           output_dir: str, mode: str) -> Dict[str, Any]:
    """Analisa um programa individual com suporte a cache"""
    
    start_time = time.time()
    program_name = program['name']
    cobol_code = program.get('content', '')
    
    # Filtrar copybooks para este programa
    program_copybooks = self.filter_copybooks_for_program(program, copybooks)
    
    try:
        # Verificar cache primeiro
        if self.analysis_cache:
            cached_analysis = self.analysis_cache.get_cached_analysis(
                program_name=program_name,
                cobol_code=cobol_code,
                copybooks=program_copybooks,
                mode=mode
            )
            
            if cached_analysis:
                # Gerar relatório a partir do cache
                report_path = os.path.join(output_dir, f"{program_name}_REFINED_ANALYSIS.md")
                
                # Usar gerador v3.0 para criar relatório do cache
                if hasattr(self, 'v3_generator') and self.v3_generator:
                    documentation = self.v3_generator.generate_from_cache(
                        cached_data=cached_analysis,
                        program_name=program_name
                    )
                    
                    with open(report_path, 'w', encoding='utf-8') as f:
                        f.write(documentation)
                
                processing_time = time.time() - start_time
                return {
                    'name': program_name,
                    'status': 'success',
                    'source': 'cache',
                    'processing_time': processing_time,
                    'report_path': report_path
                }
        
        # Processar normalmente se não estiver em cache
        if mode == 'refined' and hasattr(self, 'v3_generator') and self.v3_generator:
            report_path = os.path.join(output_dir, f"{program_name}_REFINED_ANALYSIS.md")
            
            # Criar prompt refinado
            refined_prompt = self.v3_generator.create_refined_prompt(
                program_name=program_name,
                cobol_code=cobol_code,
                copybooks=program_copybooks
            )
            
            # Tentar análise com IA
            analysis_result = {}
            prompt_history = []
            
            if hasattr(self, 'unified_analyzer') and self.unified_analyzer:
                try:
                    analysis_result = await self.unified_analyzer.analyze_cobol_program_unified(
                        program_name=program_name,
                        cobol_code=cobol_code,
                        copybooks=program_copybooks
                    )
                    prompt_history = analysis_result.get('prompt_history', [])
                except Exception as e:
                    analysis_result = {'analysis_result': {}}
                    prompt_history = [{
                        'provider': 'Sistema',
                        'model': 'Análise Estrutural',
                        'prompt': refined_prompt,
                        'response': f'Análise baseada na estrutura do código COBOL: {program_name}',
                        'status': 'Fallback',
                        'duration': 0.1
                    }]
            
            # Gerar documentação
            documentation = self.v3_generator.generate_v3_documentation(
                program_name=program_name,
                cobol_code=cobol_code,
                analysis_result=analysis_result,
                copybooks=program_copybooks,
                prompt_history=prompt_history
            )
            
            # Salvar documentação
            with open(report_path, 'w', encoding='utf-8') as f:
                f.write(documentation)
            
            # Salvar no cache
            processing_time = time.time() - start_time
            if self.analysis_cache:
                cache_data = {
                    'analysis_result': analysis_result,
                    'prompt_history': prompt_history,
                    'documentation': documentation,
                    'token_stats': self.v3_generator.get_token_statistics()
                }
                
                self.analysis_cache.save_analysis_to_cache(
                    program_name=program_name,
                    cobol_code=cobol_code,
                    copybooks=program_copybooks,
                    analysis_result=cache_data,
                    mode=mode,
                    processing_time=processing_time
                )
            
            return {
                'name': program_name,
                'status': 'success',
                'source': 'processed',
                'processing_time': processing_time,
                'report_path': report_path
            }
        
        else:
            # Fallback para outros modos
            return await self._analyze_program_fallback(program, copybooks, output_dir, mode)
            
    except Exception as e:
        processing_time = time.time() - start_time
        print(f"Erro ao processar {program_name}: {e}")
        
        return {
            'name': program_name,
            'status': 'failed',
            'source': 'error',
            'processing_time': processing_time,
            'error': str(e)
        }

async def _generate_batch_summary_v31(self, results: List[Dict[str, Any]], 
                                    output_dir: str, mode: str):
    """Gera relatório de resumo v3.1 com estatísticas de cache e paralelização"""
    
    summary_path = os.path.join(output_dir, "BATCH_PROCESSING_SUMMARY.md")
    
    # Calcular estatísticas
    total_programs = len(results)
    successful = len([r for r in results if r.get('status') == 'success'])
    from_cache = len([r for r in results if r.get('source') == 'cache'])
    processed = len([r for r in results if r.get('source') == 'processed'])
    failed = len([r for r in results if r.get('status') == 'failed'])
    
    total_time = sum(r.get('processing_time', 0) for r in results)
    
    # Estatísticas de cache
    cache_stats = {}
    if self.analysis_cache:
        cache_stats = self.analysis_cache.get_cache_stats()
    
    # Estatísticas de paralelização
    parallel_stats = self.parallel_processor.get_performance_stats()
    
    summary = f"""# COBOL Analysis Engine v3.1 - Relatório de Processamento em Lote

**Data:** {time.strftime('%d/%m/%Y %H:%M:%S')}  
**Modo:** {mode.upper()}  
**Processamento:** Paralelo com Cache  

---

## Resumo Executivo

**Total de programas:** {total_programs}  
**Processados com sucesso:** {successful}  
**Obtidos do cache:** {from_cache}  
**Processados novos:** {processed}  
**Falhas:** {failed}  
**Taxa de sucesso:** {(successful/total_programs*100):.1f}%  

**Tempo total:** {total_time:.2f}s  
**Tempo médio por programa:** {(total_time/total_programs):.2f}s  

---

## Estatísticas de Cache

**Taxa de acerto do cache:** {cache_stats.get('hit_rate', 0):.1f}%  
**Tempo economizado pelo cache:** {cache_stats.get('total_time_saved', 0):.2f}s  
**Arquivos em cache:** {cache_stats.get('cache_files', 0)}  

---

## Estatísticas de Paralelização

**Workers paralelos:** {parallel_stats.get('max_workers', 0)}  
**Tempo economizado:** {parallel_stats.get('parallel_time_saved', 0):.2f}s  
**Eficiência paralela:** {parallel_stats.get('success_rate', 0):.1f}%  

---

## Detalhes dos Programas

| Programa | Status | Fonte | Tempo (s) | Observações |
|----------|--------|-------|-----------|-------------|
"""
    
    for result in results:
        status_icon = "✓" if result.get('status') == 'success' else "✗"
        source = result.get('source', 'unknown')
        time_taken = result.get('processing_time', 0)
        notes = result.get('error', '') if result.get('status') == 'failed' else 'OK'
        
        summary += f"| {result['name']} | {status_icon} {result.get('status', 'unknown')} | {source} | {time_taken:.2f} | {notes} |\n"
    
    summary += f"""
---

## Arquivos Gerados

"""
    
    for result in results:
        if result.get('status') == 'success' and 'report_path' in result:
            summary += f"- {result['name']}: `{os.path.basename(result['report_path'])}`\n"
    
    summary += f"""
---

**Sistema:** COBOL Analysis Engine v3.1  
**Funcionalidades:** Cache Inteligente + Processamento Paralelo  
**Performance:** Otimizada para análise de sistemas legados  
"""
    
    # Salvar resumo
    with open(summary_path, 'w', encoding='utf-8') as f:
        f.write(summary)
    
    print(f"Relatório de resumo salvo em: {summary_path}")

def _display_v31_statistics(self, results: List[Dict[str, Any]]):
    """Exibe estatísticas finais v3.1"""
    
    print("\n" + "="*60)
    print("ESTATÍSTICAS FINAIS v3.1")
    print("="*60)
    
    # Estatísticas básicas
    total = len(results)
    successful = len([r for r in results if r.get('status') == 'success'])
    from_cache = len([r for r in results if r.get('source') == 'cache'])
    processed = len([r for r in results if r.get('source') == 'processed'])
    
    print(f"Programas processados: {successful}/{total}")
    print(f"Obtidos do cache: {from_cache}")
    print(f"Processados novos: {processed}")
    print(f"Taxa de sucesso: {(successful/total*100):.1f}%")
    
    # Estatísticas de cache
    if self.analysis_cache:
        cache_stats = self.analysis_cache.get_cache_stats()
        print(f"\nCACHE DE ANÁLISES:")
        print(f"Taxa de acerto: {cache_stats.get('hit_rate', 0):.1f}%")
        print(f"Tempo economizado: {cache_stats.get('total_time_saved', 0):.2f}s")
        print(f"Arquivos em cache: {cache_stats.get('cache_files', 0)}")
    
    # Estatísticas de paralelização
    parallel_stats = self.parallel_processor.get_performance_stats()
    print(f"\nPROCESSAMENTO PARALELO:")
    print(f"Workers utilizados: {parallel_stats.get('max_workers', 0)}")
    print(f"Tempo total: {parallel_stats.get('total_time', 0):.2f}s")
    if parallel_stats.get('parallel_time_saved', 0) > 0:
        print(f"Tempo economizado: {parallel_stats.get('parallel_time_saved', 0):.2f}s")
    
    # Estatísticas v3.0 (tokens)
    if hasattr(self, 'v3_generator') and self.v3_generator:
        token_stats = self.v3_generator.get_token_statistics()
        if token_stats['prompts_generated'] > 0:
            print(f"\nCONTROLE DE TOKENS v3.0:")
            print(f"Total de tokens: {token_stats['total_tokens_used']:,}")
            print(f"Custo estimado: ${token_stats['total_cost']:.4f}")
            print(f"Prompts gerados: {token_stats['prompts_generated']}")
            print(f"Tokens economizados: {token_stats['tokens_saved_by_optimization']:,}")
    
    print("="*60)

def clear_analysis_cache(self):
    """Limpa o cache de análises"""
    if self.analysis_cache:
        self.analysis_cache.clear_cache()
        print("Cache de análises limpo")
    else:
        print("Cache não está habilitado")

# Adicionar métodos à classe principal
def add_v31_methods_to_system():
    """Adiciona métodos v3.1 à classe COBOLAnalysisSystem"""
    
    # Importar a classe
    import sys
    current_module = sys.modules[__name__]
    
    # Adicionar métodos
    setattr(current_module.COBOLAnalysisSystem, 'analyze_batch_parallel', analyze_batch_parallel)
    setattr(current_module.COBOLAnalysisSystem, '_analyze_single_program_with_cache', _analyze_single_program_with_cache)
    setattr(current_module.COBOLAnalysisSystem, '_generate_batch_summary_v31', _generate_batch_summary_v31)
    setattr(current_module.COBOLAnalysisSystem, '_display_v31_statistics', _display_v31_statistics)
    setattr(current_module.COBOLAnalysisSystem, 'clear_analysis_cache', clear_analysis_cache)
