# Documentação Técnica - COBOL Analysis Engine v2.0

## Arquitetura do Sistema

### Visão Geral
O COBOL Analysis Engine v2.0 é um sistema modular projetado para análise inteligente de código COBOL com suporte a múltiplas IAs e geração automática de documentação profissional.

### Princípios de Design
- **Sempre Funcional**: Sistema opera mesmo sem IAs configuradas
- **Modularidade**: Componentes independentes e intercambiáveis
- **Transparência**: Todos os prompts e respostas são preservados
- **Fallback Inteligente**: Degradação graceful em caso de falhas
- **Extensibilidade**: Fácil adição de novos provedores e geradores

## Componentes Principais

### 1. Core (Núcleo)
Responsável pela lógica principal de análise e orquestração.

#### unified_analyzer.py
- **Função**: Analisador principal que coordena todo o processo
- **Responsabilidades**:
  - Extração de dados do código COBOL
  - Coordenação com provedores de IA
  - Geração de relatórios
  - Gerenciamento de fallbacks

#### multi_ai_orchestrator.py
- **Função**: Orquestrador para análises paralelas com múltiplas IAs
- **Responsabilidades**:
  - Distribuição de tarefas entre IAs
  - Validação cruzada de resultados
  - Agregação de análises especializadas

#### intelligent_analyzer.py
- **Função**: Analisador inteligente para modo enhanced
- **Responsabilidades**:
  - Análise estrutural avançada
  - Extração de regras de negócio
  - Identificação de padrões

### 2. Providers (Provedores de IA)
Camada de abstração para diferentes serviços de IA.

#### provider_manager.py
- **Função**: Gerenciador central de provedores
- **Responsabilidades**:
  - Inicialização de provedores
  - Roteamento de requisições
  - Estatísticas e monitoramento
  - Tratamento de falhas

#### luzia_provider.py
- **Função**: Integração com LuzIA (IA brasileira)
- **Características**:
  - Autenticação via client_id/client_secret
  - Suporte a modelos luzia-chat
  - Tratamento de timeouts
  - Parsing de respostas JSON

#### openai_provider.py
- **Função**: Integração com OpenAI
- **Características**:
  - Suporte a GPT-3.5/GPT-4
  - Configuração de temperatura e tokens
  - Rate limiting
  - Tratamento de erros da API

### 3. Generators (Geradores de Documentação)
Responsáveis pela geração de relatórios em diferentes formatos.

#### intelligent_documentation_generator.py
- **Função**: Gerador principal de documentação
- **Características**:
  - Análise estrutural inteligente
  - Extração automática de informações
  - Formatação profissional
  - Transparência de prompts/respostas

### 4. Extractors (Extratores)
Responsáveis pela extração e parsing de código COBOL.

#### cobol_extractor.py
- **Função**: Extração de dados de programas COBOL
- **Características**:
  - Parsing de Working Storage
  - Identificação de copybooks
  - Extração de regras de negócio
  - Análise de fluxo de dados

### 5. Utils (Utilitários)
Componentes de suporte e infraestrutura.

#### enhanced_logger.py
- **Função**: Sistema de logs avançado
- **Características**:
  - Logs estruturados
  - Rotação automática
  - Níveis configuráveis
  - Métricas de performance

#### simple_status_checker.py
- **Função**: Verificador de status de provedores
- **Características**:
  - Teste de conectividade
  - Validação de credenciais
  - Diagnóstico de problemas

## Fluxo de Execução

### 1. Inicialização
```
main.py
├── Carregamento de configurações
├── Inicialização de provedores
├── Verificação de dependências
└── Preparação do ambiente
```

### 2. Análise Individual
```
analyze_single_program()
├── Extração de dados COBOL
├── Carregamento de copybooks
├── Seleção do modo de análise
├── Execução da análise
├── Geração do relatório
└── Salvamento do resultado
```

### 3. Processamento em Lote
```
analyze_batch()
├── Parsing do fontes.txt
├── Carregamento de copybooks
├── Loop de processamento
│   ├── Análise individual
│   ├── Tratamento de erros
│   └── Coleta de estatísticas
├── Geração de resumo
└── Relatório final
```

## Modos de Operação

### Traditional Mode
- **Implementação**: Análise estrutural pura
- **Dependências**: Nenhuma
- **Performance**: ~0.01s por programa
- **Uso**: Fallback e análise rápida

### Enhanced Mode
- **Implementação**: Análise inteligente + IA opcional
- **Dependências**: Opcional (funciona sem IA)
- **Performance**: ~5-15s por programa
- **Uso**: Documentação profissional

### Multi-AI Mode
- **Implementação**: Análise paralela especializada
- **Dependências**: Pelo menos uma IA
- **Performance**: ~10-30s por programa
- **Uso**: Análise profunda e validação cruzada

## Configuração

### Arquivo config.yaml
```yaml
providers:
  luzia:
    client_id: "${LUZIA_CLIENT_ID}"
    client_secret: "${LUZIA_CLIENT_SECRET}"
    model: "luzia-chat"
    temperature: 0.1
    timeout: 30.0
  openai:
    api_key: "${OPENAI_API_KEY}"
    model: "gpt-4"
    temperature: 0.1
    max_tokens: 4000

logging:
  level: "INFO"
  dir: "logs"
  max_file_size: "10MB"
  backup_count: 5

analysis:
  max_prompt_size: 8000
  enable_fallback: true
  preserve_responses: true
```

### Arquivo prompts.yaml
```yaml
analysis_prompts:
  main_analysis: |
    Analise o programa COBOL de forma COMPLETA:
    
    **PROGRAMA:** {program_name}
    **COPYBOOKS:** {copybooks_context}
    **CÓDIGO:** {cobol_code}
    
    Forneça análise detalhada incluindo:
    1. Objetivo e funcionalidade
    2. Regras de negócio
    3. Estruturas de dados
    4. Fluxo de processamento
```

## Tratamento de Erros

### Estratégia de Fallback
1. **Falha de IA**: Usar análise estrutural
2. **Falha de rede**: Modo offline
3. **Falha de parsing**: Análise básica
4. **Falha crítica**: Relatório mínimo

### Códigos de Erro
- **E001**: Arquivo não encontrado
- **E002**: Erro de parsing COBOL
- **E003**: Falha de conectividade IA
- **E004**: Timeout de análise
- **E005**: Erro de configuração

### Logs de Erro
```
2025-09-20 22:55:44,123 - ERROR - [provider_manager:69] - Erro ao inicializar provider luzia: 'str' object has no attribute 'get'
2025-09-20 22:55:44,124 - INFO - [unified_analyzer:156] - Fallback para modo tradicional ativado
```

## Performance e Otimização

### Métricas de Performance
- **Tempo de análise**: Medido por programa
- **Uso de tokens**: Contabilizado por provedor
- **Taxa de sucesso**: Percentual de análises bem-sucedidas
- **Tempo de resposta**: Latência das IAs

### Otimizações Implementadas
- **Cache de copybooks**: Evita reprocessamento
- **Análise paralela**: Múltiplas IAs simultâneas
- **Fallback inteligente**: Degradação sem falha
- **Prompt otimizado**: Redução de tokens

### Limites do Sistema
- **Tamanho máximo de arquivo**: 50MB por programa
- **Número máximo de copybooks**: 100 por análise
- **Timeout padrão**: 30s por requisição IA
- **Tamanho máximo de prompt**: 8000 caracteres

## Segurança

### Proteção de Credenciais
- Uso de variáveis de ambiente
- Não armazenamento em logs
- Configuração via arquivos protegidos

### Validação de Entrada
- Sanitização de caminhos de arquivo
- Validação de formato COBOL
- Limitação de tamanho de entrada

### Logs de Auditoria
- Registro de todas as análises
- Rastreamento de uso de IAs
- Monitoramento de falhas

## Extensibilidade

### Adicionando Novos Provedores
1. Implementar interface BaseProvider
2. Adicionar configuração em config.yaml
3. Registrar no provider_manager.py
4. Implementar testes unitários

### Exemplo de Novo Provedor
```python
class NovoProvider(BaseProvider):
    def __init__(self, config):
        self.api_key = config.get("api_key")
        self.model = config.get("model", "default")
    
    async def analyze(self, request: AIRequest) -> AIResponse:
        # Implementação específica
        pass
    
    async def is_available(self) -> bool:
        # Verificação de disponibilidade
        pass
```

### Adicionando Novos Geradores
1. Implementar interface de geração
2. Definir templates de saída
3. Integrar com unified_analyzer
4. Adicionar testes de formato

## Testes

### Estrutura de Testes
```
tests/
├── unit/
│   ├── test_providers.py
│   ├── test_extractors.py
│   └── test_generators.py
├── integration/
│   ├── test_full_analysis.py
│   └── test_batch_processing.py
└── fixtures/
    ├── sample_programs/
    └── expected_outputs/
```

### Executando Testes
```bash
# Testes unitários
python -m pytest tests/unit/

# Testes de integração
python -m pytest tests/integration/

# Cobertura de código
python -m pytest --cov=src tests/
```

## Monitoramento

### Métricas Coletadas
- Número de análises por dia
- Tempo médio de processamento
- Taxa de sucesso por provedor
- Uso de recursos (CPU, memória)

### Dashboards
- Estatísticas em tempo real
- Histórico de performance
- Alertas de falha
- Uso de tokens por provedor

### Alertas
- Falha de conectividade IA
- Timeout excessivo
- Taxa de erro alta
- Uso excessivo de recursos

## Deployment

### Requisitos de Sistema
- Python 3.11+
- 2GB RAM mínimo
- 1GB espaço em disco
- Conectividade internet (para IAs)

### Instalação em Produção
```bash
# 1. Preparar ambiente
python3.11 -m venv venv
source venv/bin/activate

# 2. Instalar dependências
pip install -r requirements.txt

# 3. Configurar variáveis
export LUZIA_CLIENT_ID="..."
export LUZIA_CLIENT_SECRET="..."

# 4. Testar instalação
python3.11 main.py --status
```

### Docker
```dockerfile
FROM python:3.11-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .
CMD ["python3.11", "main.py", "--help"]
```

## Troubleshooting

### Problemas Comuns

#### 1. Erro de Importação
```
ModuleNotFoundError: No module named 'requests'
```
**Solução**: `pip install -r requirements.txt`

#### 2. Falha de Autenticação
```
Provider luzia não disponível
```
**Solução**: Verificar credenciais com `--status`

#### 3. Timeout de Análise
```
Timeout na análise com LuzIA
```
**Solução**: Aumentar timeout ou usar modo traditional

### Diagnóstico Avançado
```bash
# Logs detalhados
python3.11 main.py programa.cbl -v

# Status completo
python3.11 main.py --status -v

# Verificar conectividade
ping luzia.com.br
```

## Roadmap

### Versão 2.1 (Planejada)
- Suporte a mais provedores de IA
- Cache inteligente de análises
- Interface web opcional
- Exportação para múltiplos formatos

### Versão 2.2 (Futura)
- Análise de performance automática
- Detecção de code smells
- Sugestões de refatoração
- Integração com IDEs

## Contribuição

### Padrões de Código
- PEP 8 para Python
- Type hints obrigatórios
- Docstrings em todas as funções
- Testes para novas funcionalidades

### Processo de Desenvolvimento
1. Fork do repositório
2. Branch para feature
3. Implementação + testes
4. Pull request
5. Code review
6. Merge

---

**Documentação Técnica - COBOL Analysis Engine v2.0**  
**Versão:** 2.0  
**Data:** 20/09/2025  
**Status:** Completa e Atualizada
