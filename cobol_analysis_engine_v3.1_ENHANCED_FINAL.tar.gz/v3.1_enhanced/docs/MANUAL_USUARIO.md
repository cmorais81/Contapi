# Manual do Usuário - COBOL Analysis Engine v1.0

## 1. Introdução

Bem-vindo ao **COBOL Analysis Engine v1.0**, uma ferramenta completa para análise e documentação de programas COBOL. Este manual fornece instruções atualizadas baseadas nas funcionalidades implementadas e testadas.

### 1.1. Funcionalidades Confirmadas

O sistema oferece:

-    **Análise Individual de Programas COBOL** com extração estrutural completa
-    **Processamento em Lote** de arquivos `fontes.txt` com múltiplos programas
-    **Integração de Copybooks** através de arquivos `BOOKS.txt`
-    **Análise Multi-AI** utilizando OpenAI GPT-4 (provedor principal funcional)
-    **Geração de Relatórios Profissionais** em formato Markdown
-    **Sistema de Logging Avançado** com métricas detalhadas
-    **Interface CLI Completa** com todos os parâmetros funcionais

### 1.2. Provedores de IA Disponíveis

**Funcionais:**
-    **OpenAI** (GPT-4.1-mini) - Provedor principal
-    **Enhanced Mock Provider** - Para testes e fallback

**Em Desenvolvimento:**
-      **LuzIA** - Requer configuração adicional
-      **AWS Bedrock** - Requer credenciais AWS válidas
-      **Databricks** - Requer workspace_url
-      **GitHub Copilot** - Requer configuração específica

---

## 2. Instalação e Configuração

### 2.1. Pré-requisitos

- Python 3.11+
- Chave de API do OpenAI (obrigatória para análise multi-AI)

### 2.2. Configuração de Variáveis de Ambiente

```bash
# Obrigatório para análise multi-AI
export OPENAI_API_KEY="sua_chave_openai_aqui"

# Opcionais (para outros provedores)
export LUZIA_API_KEY="sua_chave_luzia"
export AWS_ACCESS_KEY_ID="sua_chave_aws"
export AWS_SECRET_ACCESS_KEY="sua_chave_secreta_aws"
export AWS_REGION="us-east-1"
```

### 2.3. Verificação da Instalação

```bash
# Testar a CLI
python3.11 main.py --help

# Verificar se o sistema está funcionando
python3.11 test_basic_functionality.py
```

---

## 3. Uso da Interface CLI

### 3.1. Sintaxe Básica

```bash
python3.11 main.py <arquivo_entrada> [opções]
```

### 3.2. Parâmetros Disponíveis

- `<arquivo_entrada>`: Arquivo COBOL (.cbl) ou arquivo fontes.txt
- `-o, --output`: Diretório de saída (padrão: analysis_results/)
- `-m, --mode`: Modo de análise (enhanced, multi_ai ou traditional)
- `-b, --books`: Arquivo BOOKS.txt com copybooks
- `-v, --verbose`: Modo verboso para depuração

### 3.3. Exemplos de Uso

#### Análise Individual

```bash
# Análise enhanced (recomendado)
python3.11 main.py programa.cbl -o resultados/ -m enhanced

# Análise multi-AI de um programa
python3.11 main.py programa.cbl -o resultados/ -m multi_ai

# Análise tradicional (mais rápida)
python3.11 main.py programa.cbl -o resultados/ -m traditional

# Com copybooks
python3.11 main.py programa.cbl -o resultados/ -b copybooks.txt -m enhanced
```

#### Processamento em Lote

```bash
# Processar múltiplos programas com modo enhanced (recomendado)
python3.11 main.py fontes.txt -o resultados/ -m enhanced

# Com copybooks integrados
python3.11 main.py fontes.txt -o resultados/ -b BOOKS.txt -m enhanced

# Modo multi_ai para processamento em lote
python3.11 main.py fontes.txt -o resultados/ -b BOOKS.txt -m multi_ai

# Modo tradicional para processamento rápido
python3.11 main.py fontes.txt -o resultados/ -b BOOKS.txt -m traditional
```

---

## 4. Formatos de Entrada

### 4.1. Arquivos COBOL Individuais

Arquivos com extensão `.cbl` contendo código COBOL padrão.

### 4.2. Arquivo fontes.txt

Formato esperado:
```
VMEMBER NAME  PROGRAMA1
 código COBOL do programa 1...

VMEMBER NAME  PROGRAMA2
 código COBOL do programa 2...
```

### 4.3. Arquivo BOOKS.txt

Formato esperado:
```
MEMBER NAME  COPYBOOK1
 conteúdo do copybook 1...

MEMBER NAME  COPYBOOK2
 conteúdo do copybook 2...
```

---

## 5. Saídas Geradas

### 5.1. Relatórios de Análise

**Análise Individual:**
- `PROGRAMA_MULTI_AI_ANALYSIS.md` (modo multi_ai)
- `PROGRAMA_ANALYSIS.md` (modo traditional)

**Processamento em Lote:**
- `PROGRAMA1_MULTI_AI_ANALYSIS.md`
- `PROGRAMA2_MULTI_AI_ANALYSIS.md`
- `BATCH_PROCESSING_SUMMARY.md` (resumo)

### 5.2. Estrutura dos Relatórios

Cada relatório contém:

1. **Cabeçalho** com informações do programa
2. **Resumo Executivo** com estatísticas da análise
3. **Análise Estrutural** (quando disponível)
4. **Análise de Regras de Negócio**
5. **Análise Técnica**
6. **Análise do Modelo de Dados**
7. **Análise de Qualidade**
8. **Resumo Final** com métricas

### 5.3. Arquivos de Log

- `logs/cobol_analysis.log` - Log principal
- `logs/metrics_PROGRAMA_timestamp.json` - Métricas estruturadas

---

## 6. Configuração Avançada

### 6.1. Arquivo config.yaml

Localização: `config/config.yaml`

```yaml
ai:
  providers:
    openai:
      enabled: true
      api_key: "${OPENAI_API_KEY}"
      model: "gpt-4.1-mini"
    
    luzia:
      enabled: false
      api_key: "${LUZIA_API_KEY}"
    
    bedrock:
      enabled: false
      region: "${AWS_REGION}"
    
    databricks:
      enabled: false
      workspace_url: "${DATABRICKS_WORKSPACE_URL}"

logging:
  level: "INFO"
  log_dir: "logs"
```

### 6.2. Habilitando Outros Provedores

Para habilitar provedores adicionais:

1. Configure as variáveis de ambiente necessárias
2. Altere `enabled: true` no config.yaml
3. Teste a conectividade antes do uso

---

## 7. Solução de Problemas

### 7.1. Problemas Comuns

**Erro: "OpenAI API key not found"**
- Solução: Configure `export OPENAI_API_KEY="sua_chave"`

**Erro: "Provider not available"**
- Solução: Verifique se o provedor está habilitado no config.yaml

**Análise muito rápida (< 1s)**
- Causa: Modo traditional ou falha na análise multi-AI
- Solução: Verifique logs e configuração do OpenAI

### 7.2. Modo Verboso

Para depuração detalhada:
```bash
python3.11 main.py arquivo.cbl -o resultados/ -m multi_ai -v
```

### 7.3. Teste de Funcionalidade

Execute o teste básico:
```bash
python3.11 test_basic_functionality.py
```

---

## 8. Performance e Limitações

### 8.1. Tempos Esperados

- **Análise Individual Multi-AI**: 10-25 segundos
- **Análise Traditional**: < 1 segundo
- **Processamento em Lote**: 10-25s por programa

### 8.2. Limitações Conhecidas

- Apenas OpenAI está totalmente funcional
- Copybooks são limitados para evitar timeout
- Análise depende da qualidade do código COBOL

---

## 9. Suporte e Contato

Para suporte técnico ou dúvidas:
- Consulte os logs em `logs/cobol_analysis.log`
- Execute testes básicos com `test_basic_functionality.py`
- Verifique a configuração no `config.yaml`

---

*Manual atualizado em: 20/09/2025*
*Versão do Sistema: v1.0*



## 10. Modo Enhanced: Análise Funcional Completa

O modo `enhanced` é a principal inovação da versão 1.0. Ele vai além da análise estrutural e fornece uma documentação funcional completa do programa COBOL.

### 10.1. O que o Modo Enhanced Oferece?

- **Extração de Objetivos**: Identifica o propósito principal do programa a partir de comentários e da estrutura do código.
- **Análise de Regras de Negócio**: Detecta e documenta validações, roteamentos e controles de processamento.
- **Mapeamento de Fluxo de Dados**: Rastreia como os dados são lidos, transformados e gravados.
- **Identificação de Seções Funcionais**: Mapeia a estrutura funcional do programa, explicando o papel de cada seção.

### 10.2. Quando Usar o Modo Enhanced?

- **Compreensão Rápida**: Para desenvolvedores que precisam entender rapidamente a lógica de um programa legado.
- **Documentação de Negócio**: Para analistas que precisam extrair regras de negócio de código COBOL.
- **Análise de Impacto**: Para arquitetos que precisam avaliar o impacto de mudanças em um sistema.
- **Auditoria e Compliance**: Para auditores que precisam de rastreabilidade completa dos controles de um programa.

### 10.3. Exemplo de Saída do Modo Enhanced

```markdown
# Documentação Funcional: LHAN0542_TESTE

##    Objetivo do Programa

### Propósito Principal
Particionar arquivo BACEN DOC3040, gerando arquivos particionados dinamicamente com respectivos arquivos bastões para transmissão.

##    Regras de Negócio Críticas

### Validações Obrigatórias

**1. Validação condicional: IF WS-REGISTRO-VALIDO = 'S'**
- **Tipo:** validation
- **Condição:** IF WS-REGISTRO-VALIDO = 'S'

##    Fluxo de Processamento Detalhado

### 1. Etapa 1

**Descrição:** OPEN - OPEN INPUT E1DQ0705...

**Entradas:** Dados do arquivo

**Saídas:** Dados processados
```

