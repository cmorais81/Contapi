"""
Command Line Interface for COBOL Documentation Engine.
Following Single Responsibility Principle and clean architecture.
"""

import os
import sys
import argparse
import time
from typing import List, Optional
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn

from .core.engine import DocumentationEngine
from .utils.exceptions import EngineError, FileNotFoundError
from .utils.file_utils import FileManager


class CobolCLI:
    """
    Command Line Interface for COBOL Documentation Engine.
    Following Single Responsibility Principle.
    """
    
    def __init__(self):
        self.console = Console()
        self.engine = DocumentationEngine()
    
    def run(self, args: List[str] = None):
        """Run the CLI with given arguments."""
        parser = self._create_parser()
        parsed_args = parser.parse_args(args)
        
        try:
            if parsed_args.command == 'analyze':
                self._handle_analyze(parsed_args)
            elif parsed_args.command == 'batch':
                self._handle_batch(parsed_args)
            elif parsed_args.command == 'info':
                self._handle_info(parsed_args)
            else:
                parser.print_help()
                
        except KeyboardInterrupt:
            self.console.print("\n[yellow]Operation cancelled by user[/yellow]")
            sys.exit(1)
        except Exception as e:
            self.console.print(f"[red]Error: {e}[/red]")
            sys.exit(1)
    
    def _create_parser(self) -> argparse.ArgumentParser:
        """Create argument parser."""
        parser = argparse.ArgumentParser(
            description="COBOL Documentation Engine - Analyze and document COBOL programs",
            formatter_class=argparse.RawDescriptionHelpFormatter,
            epilog="""
Examples:
  # Analyze single file
  cobol-engine analyze program.cbl --output ./results
  
  # Batch analyze ZIP file
  cobol-engine batch portfolio.zip --output ./analysis --analyzers security_analyzer performance_analyzer
  
  # Get engine information
  cobol-engine info
            """
        )
        
        subparsers = parser.add_subparsers(dest='command', help='Available commands')
        
        # Analyze command
        analyze_parser = subparsers.add_parser('analyze', help='Analyze a single COBOL file')
        analyze_parser.add_argument('file', help='COBOL file to analyze')
        analyze_parser.add_argument('--output', '-o', help='Output directory', default='./output')
        analyze_parser.add_argument('--format', '-f', choices=['json', 'yaml', 'markdown'], 
                                   default='json', help='Output format')
        analyze_parser.add_argument('--analyzers', '-a', nargs='*', 
                                   help='Analyzers to run (default: all available)')
        
        # Batch command
        batch_parser = subparsers.add_parser('batch', help='Batch analyze multiple COBOL files')
        batch_parser.add_argument('source', help='ZIP file or directory containing COBOL files')
        batch_parser.add_argument('--output', '-o', required=True, help='Output directory')
        batch_parser.add_argument('--format', '-f', choices=['json', 'yaml', 'markdown'], 
                                 default='json', help='Output format for individual files')
        batch_parser.add_argument('--analyzers', '-a', nargs='*', 
                                 help='Analyzers to run (default: all available)')
        batch_parser.add_argument('--parallel', action='store_true', default=True,
                                 help='Enable parallel processing (default: True)')
        batch_parser.add_argument('--max-workers', type=int, default=4,
                                 help='Maximum number of parallel workers (default: 4)')
        
        # Info command
        info_parser = subparsers.add_parser('info', help='Show engine information')
        info_parser.add_argument('--analyzers', action='store_true', 
                                help='Show available analyzers')
        info_parser.add_argument('--formatters', action='store_true', 
                                help='Show available formatters')
        
        return parser
    
    def _handle_analyze(self, args):
        """Handle single file analysis."""
        if not os.path.exists(args.file):
            raise FileNotFoundError(f"File not found: {args.file}")
        
        # Prepare analyzers
        analyzers = args.analyzers or self.engine.get_available_analyzers()
        
        self.console.print(f"[blue]Analyzing file:[/blue] {args.file}")
        self.console.print(f"[blue]Analyzers:[/blue] {', '.join(analyzers)}")
        self.console.print(f"[blue]Output format:[/blue] {args.format}")
        
        # Analyze with progress
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=self.console
        ) as progress:
            task = progress.add_task("Analyzing...", total=None)
            
            start_time = time.time()
            result = self.engine.analyze_single_file(args.file, analyzers)
            execution_time = time.time() - start_time
            
            progress.update(task, completed=True)
        
        # Display results
        self._display_single_result(result, execution_time)
        
        # Save results
        FileManager.ensure_directory(args.output)
        
        file_name = os.path.basename(args.file)
        base_name = os.path.splitext(file_name)[0]
        
        formatter = self.engine.formatter_registry.get_formatter(args.format)
        output_file = os.path.join(args.output, f"{base_name}_analysis{formatter.file_extension}")
        
        self.engine.save_result(result, output_file, args.format)
        
        self.console.print(f"\n[green]✅ Analysis complete![/green]")
        self.console.print(f"[blue]Results saved to:[/blue] {output_file}")
    
    def _handle_batch(self, args):
        """Handle batch analysis."""
        if not os.path.exists(args.source):
            raise FileNotFoundError(f"Source not found: {args.source}")
        
        # Prepare analyzers
        analyzers = args.analyzers or self.engine.get_available_analyzers()
        
        self.console.print(f"[blue]Source:[/blue] {args.source}")
        self.console.print(f"[blue]Analyzers:[/blue] {', '.join(analyzers)}")
        self.console.print(f"[blue]Parallel processing:[/blue] {args.parallel}")
        self.console.print(f"[blue]Max workers:[/blue] {args.max_workers}")
        
        # Analyze with progress
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=self.console
        ) as progress:
            task = progress.add_task("Processing batch...", total=None)
            
            start_time = time.time()
            batch_result = self.engine.analyze_batch(
                args.source, 
                analyzers, 
                parallel=args.parallel,
                max_workers=args.max_workers
            )
            execution_time = time.time() - start_time
            
            progress.update(task, completed=True)
        
        # Display results
        self._display_batch_result(batch_result, execution_time)
        
        # Save results
        FileManager.ensure_directory(args.output)
        self.engine.save_batch_result(batch_result, args.output, args.format)
        
        self.console.print(f"\n[green]✅ Batch analysis complete![/green]")
        self.console.print(f"[blue]Results saved to:[/blue] {args.output}")
    
    def _handle_info(self, args):
        """Handle info command."""
        self.console.print(Panel.fit(
            "[bold blue]COBOL Documentation Engine[/bold blue]\n"
            "Version: 2.0.0\n"
            "A modern tool for analyzing and documenting COBOL programs",
            title="Engine Information"
        ))
        
        if args.analyzers or not (args.analyzers or args.formatters):
            self._show_analyzers()
        
        if args.formatters or not (args.analyzers or args.formatters):
            self._show_formatters()
    
    def _show_analyzers(self):
        """Show available analyzers."""
        analyzers = self.engine.get_available_analyzers()
        
        table = Table(title="Available Analyzers")
        table.add_column("Name", style="cyan")
        table.add_column("Description", style="white")
        
        analyzer_descriptions = {
            'security_analyzer': 'Analyzes security vulnerabilities and compliance',
            'performance_analyzer': 'Analyzes performance issues and optimization opportunities'
        }
        
        for analyzer_name in analyzers:
            description = analyzer_descriptions.get(analyzer_name, 'No description available')
            table.add_row(analyzer_name, description)
        
        self.console.print(table)
    
    def _show_formatters(self):
        """Show available formatters."""
        formatters = self.engine.get_available_formatters()
        
        table = Table(title="Available Formatters")
        table.add_column("Name", style="cyan")
        table.add_column("Extension", style="yellow")
        table.add_column("Description", style="white")
        
        formatter_descriptions = {
            'json': 'JavaScript Object Notation - structured data format',
            'yaml': 'YAML Ain\'t Markup Language - human-readable data format',
            'markdown': 'Markdown - formatted text for documentation'
        }
        
        for formatter_name in formatters:
            formatter = self.engine.formatter_registry.get_formatter(formatter_name)
            extension = formatter.file_extension if formatter else 'N/A'
            description = formatter_descriptions.get(formatter_name, 'No description available')
            table.add_row(formatter_name, extension, description)
        
        self.console.print(table)
    
    def _display_single_result(self, result, execution_time: float):
        """Display single analysis result."""
        status = "✅ Success" if result.success else "❌ Failed"
        
        table = Table(title="Analysis Results")
        table.add_column("Metric", style="cyan")
        table.add_column("Value", style="white")
        
        table.add_row("Status", status)
        table.add_row("Program ID", result.program_id)
        table.add_row("Execution Time", f"{execution_time:.2f}s")
        
        if result.success and 'program_info' in result.data:
            info = result.data['program_info']
            table.add_row("Lines of Code", f"{info.get('lines_of_code', 0):,}")
            table.add_row("Variables", str(info.get('variables_count', 0)))
            table.add_row("Complexity", str(info.get('total_complexity', 0)))
        
        # Show analyzer results
        if result.success and 'analyzer_results' in result.data:
            for analyzer_name, analyzer_data in result.data['analyzer_results'].items():
                if analyzer_name == 'security_analyzer':
                    score = analyzer_data.get('security_score', 0)
                    table.add_row("Security Score", f"{score}/100")
                elif analyzer_name == 'performance_analyzer':
                    score = analyzer_data.get('performance_score', 0)
                    table.add_row("Performance Score", f"{score}/100")
        
        self.console.print(table)
        
        # Show errors and warnings
        if result.errors:
            self.console.print("\n[red]Errors:[/red]")
            for error in result.errors:
                self.console.print(f"  • {error}")
        
        if result.warnings:
            self.console.print("\n[yellow]Warnings:[/yellow]")
            for warning in result.warnings:
                self.console.print(f"  • {warning}")
    
    def _display_batch_result(self, batch_result, execution_time: float):
        """Display batch analysis result."""
        table = Table(title="Batch Analysis Results")
        table.add_column("Metric", style="cyan")
        table.add_column("Value", style="white")
        
        table.add_row("Total Files", str(batch_result.total_files))
        table.add_row("Processed Successfully", str(batch_result.processed_files))
        table.add_row("Failed", str(batch_result.failed_files))
        table.add_row("Success Rate", f"{batch_result.get_success_rate():.1f}%")
        table.add_row("Total Lines of Code", f"{batch_result.total_lines:,}")
        table.add_row("Processing Time", f"{execution_time:.2f}s")
        table.add_row("Processing Speed", f"{batch_result.get_files_per_minute():.1f} files/min")
        
        # Show consolidated metrics
        if batch_result.consolidated_metrics:
            metrics = batch_result.consolidated_metrics
            
            if 'average_security_score' in metrics:
                table.add_row("Average Security Score", f"{metrics['average_security_score']:.1f}/100")
            
            if 'average_performance_score' in metrics:
                table.add_row("Average Performance Score", f"{metrics['average_performance_score']:.1f}/100")
            
            table.add_row("Average Complexity", f"{metrics.get('average_complexity', 0):.1f}")
        
        self.console.print(table)


def main():
    """Main entry point."""
    cli = CobolCLI()
    cli.run()


if __name__ == "__main__":
    main()

