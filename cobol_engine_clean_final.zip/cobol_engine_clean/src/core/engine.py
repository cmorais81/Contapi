"""
Main Documentation Engine following SOLID principles.
"""

import os
import time
from typing import List, Dict, Any, Optional
from ..interfaces.analyzer import IAnalyzer
from ..interfaces.parser import IParser
from ..interfaces.formatter import IFormatter
from ..interfaces.processor import IBatchProcessor, IFileExtractor
from .models import CobolProgram, AnalysisResult, BatchResult
from .parser import CobolParser
from ..utils.exceptions import EngineError
from ..utils.file_utils import FileExtractor
from ..analyzers.registry import AnalyzerRegistry
from ..utils.formatters import FormatterRegistry


class DocumentationEngine:
    """
    Main engine for COBOL documentation.
    Following Dependency Inversion Principle - depends on abstractions.
    """
    
    def __init__(self, 
                 parser: IParser = None,
                 file_extractor: IFileExtractor = None):
        """
        Initialize engine with dependencies.
        
        Args:
            parser: COBOL parser implementation
            file_extractor: File extractor implementation
        """
        self.parser = parser or CobolParser()
        self.file_extractor = file_extractor or FileExtractor()
        self.analyzer_registry = AnalyzerRegistry()
        self.formatter_registry = FormatterRegistry()
    
    def analyze_single_file(self, 
                           file_path: str, 
                           analyzers: List[str] = None,
                           output_format: str = "json") -> AnalysisResult:
        """
        Analyze a single COBOL file.
        
        Args:
            file_path: Path to COBOL file
            analyzers: List of analyzer names to run
            output_format: Output format
            
        Returns:
            AnalysisResult
        """
        start_time = time.time()
        
        try:
            # Parse the program
            program = self.parser.parse_file(file_path)
            
            # Create result container
            result = AnalysisResult(
                analyzer_name="engine",
                program_id=program.program_id,
                success=True
            )
            
            # Add basic program information
            result.data['program_info'] = {
                'program_id': program.program_id,
                'file_path': program.file_path,
                'author': program.author,
                'date_written': program.date_written,
                'lines_of_code': program.lines_of_code,
                'variables_count': len(program.variables),
                'sections_count': len(program.sections),
                'paragraphs_count': len(program.paragraphs),
                'files_count': len(program.files),
                'copy_books_count': len(program.copy_books),
                'total_complexity': program.get_total_complexity()
            }
            
            # Run analyzers
            if analyzers:
                result.data['analyzer_results'] = {}
                for analyzer_name in analyzers:
                    analyzer = self.analyzer_registry.get_analyzer(analyzer_name)
                    if analyzer:
                        try:
                            analysis = analyzer.analyze(program)
                            result.data['analyzer_results'][analyzer_name] = analysis.data
                        except Exception as e:
                            result.add_warning(f"Analyzer {analyzer_name} failed: {e}")
            
            result.execution_time = time.time() - start_time
            return result
            
        except Exception as e:
            result = AnalysisResult(
                analyzer_name="engine",
                program_id="unknown",
                success=False
            )
            result.add_error(f"Analysis failed: {e}")
            result.execution_time = time.time() - start_time
            return result
    
    def analyze_batch(self, 
                     source_path: str,
                     analyzers: List[str] = None,
                     parallel: bool = True,
                     max_workers: int = 4) -> BatchResult:
        """
        Analyze multiple COBOL files from ZIP or directory.
        
        Args:
            source_path: Path to ZIP file or directory
            analyzers: List of analyzer names to run
            parallel: Whether to process in parallel
            max_workers: Maximum number of parallel workers
            
        Returns:
            BatchResult
        """
        start_time = time.time()
        
        try:
            # Extract COBOL files
            cobol_files = self.file_extractor.extract_cobol_files(source_path)
            
            if not cobol_files:
                raise EngineError(f"No COBOL files found in {source_path}")
            
            # Create batch result
            batch_result = BatchResult(
                total_files=len(cobol_files),
                processed_files=0,
                failed_files=0,
                total_lines=0,
                processing_time=0.0
            )
            
            # Process files
            if parallel and len(cobol_files) > 1:
                self._process_files_parallel(cobol_files, analyzers, batch_result, max_workers)
            else:
                self._process_files_sequential(cobol_files, analyzers, batch_result)
            
            # Calculate final metrics
            batch_result.processing_time = time.time() - start_time
            self._calculate_consolidated_metrics(batch_result)
            
            return batch_result
            
        except Exception as e:
            batch_result = BatchResult(
                total_files=0,
                processed_files=0,
                failed_files=0,
                total_lines=0,
                processing_time=time.time() - start_time
            )
            raise EngineError(f"Batch analysis failed: {e}") from e
    
    def _process_files_sequential(self, 
                                 file_paths: List[str], 
                                 analyzers: List[str],
                                 batch_result: BatchResult):
        """Process files sequentially."""
        for file_path in file_paths:
            result = self.analyze_single_file(file_path, analyzers)
            batch_result.add_result(file_path, result)
            
            # Update total lines
            if result.success and 'program_info' in result.data:
                batch_result.total_lines += result.data['program_info'].get('lines_of_code', 0)
    
    def _process_files_parallel(self, 
                               file_paths: List[str], 
                               analyzers: List[str],
                               batch_result: BatchResult,
                               max_workers: int):
        """Process files in parallel."""
        from concurrent.futures import ThreadPoolExecutor, as_completed
        
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            # Submit tasks
            future_to_file = {
                executor.submit(self.analyze_single_file, file_path, analyzers): file_path
                for file_path in file_paths
            }
            
            # Collect results
            for future in as_completed(future_to_file):
                file_path = future_to_file[future]
                try:
                    result = future.result()
                    batch_result.add_result(file_path, result)
                    
                    # Update total lines
                    if result.success and 'program_info' in result.data:
                        batch_result.total_lines += result.data['program_info'].get('lines_of_code', 0)
                        
                except Exception as e:
                    error_result = AnalysisResult(
                        analyzer_name="engine",
                        program_id="unknown",
                        success=False
                    )
                    error_result.add_error(f"Processing failed: {e}")
                    batch_result.add_result(file_path, error_result)
    
    def _calculate_consolidated_metrics(self, batch_result: BatchResult):
        """Calculate consolidated metrics for batch result."""
        if not batch_result.results:
            return
        
        # Initialize metrics
        security_scores = []
        performance_scores = []
        total_complexity = 0
        total_variables = 0
        
        # Collect metrics from all results
        for result in batch_result.results.values():
            if not result.success:
                continue
            
            # Basic metrics
            if 'program_info' in result.data:
                total_complexity += result.data['program_info'].get('total_complexity', 0)
                total_variables += result.data['program_info'].get('variables_count', 0)
            
            # Analyzer metrics
            if 'analyzer_results' in result.data:
                analyzer_results = result.data['analyzer_results']
                
                # Security scores
                if 'security_analyzer' in analyzer_results:
                    security_data = analyzer_results['security_analyzer']
                    if 'security_score' in security_data:
                        security_scores.append(security_data['security_score'])
                
                # Performance scores
                if 'performance_analyzer' in analyzer_results:
                    performance_data = analyzer_results['performance_analyzer']
                    if 'performance_score' in performance_data:
                        performance_scores.append(performance_data['performance_score'])
        
        # Calculate consolidated metrics
        batch_result.consolidated_metrics = {
            'success_rate': batch_result.get_success_rate(),
            'files_per_minute': batch_result.get_files_per_minute(),
            'total_complexity': total_complexity,
            'total_variables': total_variables,
            'average_complexity': total_complexity / batch_result.processed_files if batch_result.processed_files > 0 else 0,
            'average_variables': total_variables / batch_result.processed_files if batch_result.processed_files > 0 else 0
        }
        
        # Security metrics
        if security_scores:
            batch_result.consolidated_metrics.update({
                'average_security_score': sum(security_scores) / len(security_scores),
                'min_security_score': min(security_scores),
                'max_security_score': max(security_scores),
                'security_analysis_count': len(security_scores)
            })
        
        # Performance metrics
        if performance_scores:
            batch_result.consolidated_metrics.update({
                'average_performance_score': sum(performance_scores) / len(performance_scores),
                'min_performance_score': min(performance_scores),
                'max_performance_score': max(performance_scores),
                'performance_analysis_count': len(performance_scores)
            })
    
    def format_result(self, result: AnalysisResult, format_name: str) -> str:
        """
        Format analysis result.
        
        Args:
            result: Analysis result to format
            format_name: Format name (json, yaml, markdown)
            
        Returns:
            Formatted string
        """
        formatter = self.formatter_registry.get_formatter(format_name)
        if not formatter:
            raise EngineError(f"Unknown format: {format_name}")
        
        return formatter.format_single_result(result)
    
    def format_batch_result(self, batch_result: BatchResult, format_name: str) -> str:
        """
        Format batch result.
        
        Args:
            batch_result: Batch result to format
            format_name: Format name
            
        Returns:
            Formatted string
        """
        formatter = self.formatter_registry.get_formatter(format_name)
        if not formatter:
            raise EngineError(f"Unknown format: {format_name}")
        
        return formatter.format_batch_result(batch_result)
    
    def save_result(self, 
                   result: AnalysisResult, 
                   output_path: str, 
                   format_name: str = "json"):
        """
        Save analysis result to file.
        
        Args:
            result: Analysis result
            output_path: Output file path
            format_name: Format name
        """
        formatted_content = self.format_result(result, format_name)
        
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(formatted_content)
    
    def save_batch_result(self, 
                         batch_result: BatchResult, 
                         output_dir: str, 
                         format_name: str = "json"):
        """
        Save batch result to directory.
        
        Args:
            batch_result: Batch result
            output_dir: Output directory
            format_name: Format name
        """
        os.makedirs(output_dir, exist_ok=True)
        
        # Save individual results
        for file_path, result in batch_result.results.items():
            file_name = os.path.basename(file_path)
            base_name = os.path.splitext(file_name)[0]
            
            formatter = self.formatter_registry.get_formatter(format_name)
            if formatter:
                output_file = os.path.join(output_dir, f"{base_name}_analysis{formatter.file_extension}")
                self.save_result(result, output_file, format_name)
        
        # Save consolidated report
        consolidated_report = self.format_batch_result(batch_result, "markdown")
        report_path = os.path.join(output_dir, "consolidated_report.md")
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write(consolidated_report)
    
    def get_available_analyzers(self) -> List[str]:
        """Get list of available analyzers."""
        return self.analyzer_registry.get_analyzer_names()
    
    def get_available_formatters(self) -> List[str]:
        """Get list of available formatters."""
        return self.formatter_registry.get_formatter_names()

