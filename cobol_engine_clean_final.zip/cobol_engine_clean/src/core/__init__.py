"""
Core module for COBOL Documentation Engine.
Contains fundamental classes and interfaces following SOLID principles.
"""

from .models import *
from .parser import CobolParser
from .engine import DocumentationEngine

__all__ = [
    'CobolProgram',
    'CobolVariable', 
    'CobolSection',
    'CobolParagraph',
    'CobolParser',
    'DocumentationEngine'
]

