"""
Performance analyzer following SOLID principles.
"""

import re
from typing import Dict, Any, List
from ..interfaces.analyzer import IPerformanceAnalyzer
from ..core.models import CobolProgram, AnalysisResult
from ..utils.exceptions import AnalyzerError


class PerformanceAnalyzer(IPerformanceAnalyzer):
    """
    Performance analyzer implementation.
    Following Single Responsibility Principle - only performance analysis.
    """
    
    def __init__(self):
        self._config = {
            'check_complexity': True,
            'check_loops': True,
            'check_file_operations': True,
            'check_data_movement': True,
            'complexity_thresholds': {
                'low': 10,
                'medium': 20,
                'high': 30
            }
        }
        self._setup_patterns()
    
    def _setup_patterns(self):
        """Setup performance check patterns."""
        self.patterns = {
            'perform_until': re.compile(r'PERFORM\s+.+\s+UNTIL\s+', re.IGNORECASE),
            'perform_times': re.compile(r'PERFORM\s+.+\s+(\d+)\s+TIMES', re.IGNORECASE),
            'goto_statement': re.compile(r'GO\s+TO\s+', re.IGNORECASE),
            'move_statement': re.compile(r'MOVE\s+', re.IGNORECASE),
            'compute_statement': re.compile(r'COMPUTE\s+', re.IGNORECASE),
            'file_operations': re.compile(r'(READ|WRITE|REWRITE|DELETE)\s+', re.IGNORECASE),
            'sort_statement': re.compile(r'SORT\s+', re.IGNORECASE),
            'search_statement': re.compile(r'SEARCH\s+', re.IGNORECASE)
        }
    
    @property
    def name(self) -> str:
        return "performance_analyzer"
    
    @property
    def version(self) -> str:
        return "1.0.0"
    
    def analyze(self, program: CobolProgram) -> AnalysisResult:
        """Analyze program for performance issues."""
        result = AnalysisResult(
            analyzer_name=self.name,
            program_id=program.program_id,
            success=True
        )
        
        try:
            # Perform performance checks
            issues = []
            metrics = {}
            
            if self._config['check_complexity']:
                complexity_issues, complexity_metrics = self._check_complexity(program)
                issues.extend(complexity_issues)
                metrics.update(complexity_metrics)
            
            if self._config['check_loops']:
                loop_issues = self._check_loops(program)
                issues.extend(loop_issues)
            
            if self._config['check_file_operations']:
                file_issues = self._check_file_operations(program)
                issues.extend(file_issues)
            
            if self._config['check_data_movement']:
                data_issues = self._check_data_movement(program)
                issues.extend(data_issues)
            
            # Calculate performance score
            performance_score = self._calculate_performance_score(issues, metrics, program)
            
            # Determine complexity level
            complexity_level = self._determine_complexity_level(metrics.get('total_complexity', 0))
            
            # Store results
            result.data = {
                'performance_score': performance_score,
                'complexity': complexity_level,
                'issues': issues,
                'metrics': metrics,
                'total_issues': len(issues),
                'critical_issues': len([i for i in issues if i['severity'] == 'CRITICAL']),
                'high_issues': len([i for i in issues if i['severity'] == 'HIGH']),
                'medium_issues': len([i for i in issues if i['severity'] == 'MEDIUM']),
                'low_issues': len([i for i in issues if i['severity'] == 'LOW']),
                'optimizations': self._generate_optimizations(issues, metrics)
            }
            
        except Exception as e:
            result.success = False
            result.add_error(f"Performance analysis failed: {e}")
        
        return result
    
    def get_performance_score(self, program: CobolProgram) -> int:
        """Get performance score (0-100)."""
        result = self.analyze(program)
        return result.data.get('performance_score', 0) if result.success else 0
    
    def get_bottlenecks(self, program: CobolProgram) -> list:
        """Get list of performance bottlenecks."""
        result = self.analyze(program)
        return result.data.get('issues', []) if result.success else []
    
    def get_configuration(self) -> Dict[str, Any]:
        """Get analyzer configuration."""
        return self._config.copy()
    
    def set_configuration(self, config: Dict[str, Any]) -> None:
        """Set analyzer configuration."""
        self._config.update(config)
    
    def _check_complexity(self, program: CobolProgram) -> tuple:
        """Check complexity metrics."""
        issues = []
        metrics = {
            'total_complexity': program.get_total_complexity(),
            'max_paragraph_complexity': 0,
            'complex_paragraphs': 0
        }
        
        # Check individual paragraph complexity
        for paragraph in program.paragraphs:
            if paragraph.complexity > metrics['max_paragraph_complexity']:
                metrics['max_paragraph_complexity'] = paragraph.complexity
            
            if paragraph.complexity > self._config['complexity_thresholds']['high']:
                metrics['complex_paragraphs'] += 1
                issues.append({
                    'type': 'HIGH_COMPLEXITY',
                    'severity': 'HIGH',
                    'location': paragraph.name,
                    'description': f'Paragraph {paragraph.name} has high complexity ({paragraph.complexity})',
                    'recommendation': 'Consider breaking down into smaller paragraphs'
                })
            elif paragraph.complexity > self._config['complexity_thresholds']['medium']:
                issues.append({
                    'type': 'MEDIUM_COMPLEXITY',
                    'severity': 'MEDIUM',
                    'location': paragraph.name,
                    'description': f'Paragraph {paragraph.name} has medium complexity ({paragraph.complexity})',
                    'recommendation': 'Review for potential simplification'
                })
        
        return issues, metrics
    
    def _check_loops(self, program: CobolProgram) -> List[Dict[str, Any]]:
        """Check for loop performance issues."""
        issues = []
        
        if program.file_path and program.file_path != "unknown":
            try:
                with open(program.file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                    lines = content.split('\n')
            except:
                return issues
        else:
            return issues
        
        # Check for nested loops
        loop_depth = 0
        max_depth = 0
        
        for line_num, line in enumerate(lines, 1):
            if self.patterns['perform_until'].search(line) or self.patterns['perform_times'].search(line):
                loop_depth += 1
                max_depth = max(max_depth, loop_depth)
                
                if loop_depth > 2:
                    issues.append({
                        'type': 'NESTED_LOOPS',
                        'severity': 'HIGH',
                        'line': line_num,
                        'description': f'Deeply nested loop (depth: {loop_depth})',
                        'recommendation': 'Consider restructuring to reduce nesting'
                    })
            
            # Check for GO TO in loops (can create infinite loops)
            if loop_depth > 0 and self.patterns['goto_statement'].search(line):
                issues.append({
                    'type': 'GOTO_IN_LOOP',
                    'severity': 'MEDIUM',
                    'line': line_num,
                    'description': 'GO TO statement inside loop',
                    'recommendation': 'Replace GO TO with structured programming constructs'
                })
            
            # Simple heuristic to detect end of PERFORM block
            if 'END-PERFORM' in line.upper() or (loop_depth > 0 and line.strip().endswith('.')):
                loop_depth = max(0, loop_depth - 1)
        
        return issues
    
    def _check_file_operations(self, program: CobolProgram) -> List[Dict[str, Any]]:
        """Check for file operation performance issues."""
        issues = []
        
        if program.file_path and program.file_path != "unknown":
            try:
                with open(program.file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                    lines = content.split('\n')
            except:
                return issues
        else:
            return issues
        
        file_ops_count = 0
        
        for line_num, line in enumerate(lines, 1):
            if self.patterns['file_operations'].search(line):
                file_ops_count += 1
        
        # Check for excessive file operations
        if file_ops_count > 100:
            issues.append({
                'type': 'EXCESSIVE_FILE_OPS',
                'severity': 'MEDIUM',
                'description': f'High number of file operations ({file_ops_count})',
                'recommendation': 'Consider batching file operations or using more efficient access methods'
            })
        
        # Check for sequential access on indexed files
        for file_def in program.files:
            if file_def.organization == "INDEXED" and file_def.access_mode == "SEQUENTIAL":
                issues.append({
                    'type': 'INEFFICIENT_ACCESS',
                    'severity': 'MEDIUM',
                    'description': f'Sequential access on indexed file {file_def.name}',
                    'recommendation': 'Consider using DYNAMIC or RANDOM access for indexed files'
                })
        
        return issues
    
    def _check_data_movement(self, program: CobolProgram) -> List[Dict[str, Any]]:
        """Check for data movement performance issues."""
        issues = []
        
        if program.file_path and program.file_path != "unknown":
            try:
                with open(program.file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                    lines = content.split('\n')
            except:
                return issues
        else:
            return issues
        
        move_count = 0
        compute_count = 0
        
        for line_num, line in enumerate(lines, 1):
            if self.patterns['move_statement'].search(line):
                move_count += 1
            elif self.patterns['compute_statement'].search(line):
                compute_count += 1
        
        # Check for excessive MOVE statements
        if move_count > 50:
            issues.append({
                'type': 'EXCESSIVE_MOVES',
                'severity': 'LOW',
                'description': f'High number of MOVE statements ({move_count})',
                'recommendation': 'Review data flow to minimize unnecessary data movement'
            })
        
        # Suggest COMPUTE over multiple arithmetic operations
        if move_count > compute_count * 3:
            issues.append({
                'type': 'INEFFICIENT_ARITHMETIC',
                'severity': 'LOW',
                'description': 'Consider using COMPUTE for complex arithmetic operations',
                'recommendation': 'Replace multiple ADD/SUBTRACT/MULTIPLY/DIVIDE with COMPUTE'
            })
        
        return issues
    
    def _calculate_performance_score(self, issues: List[Dict[str, Any]], metrics: Dict[str, Any], program: CobolProgram) -> int:
        """Calculate performance score based on issues and metrics."""
        base_score = 100
        
        # Deduct points for issues
        severity_weights = {'CRITICAL': 15, 'HIGH': 10, 'MEDIUM': 5, 'LOW': 2}
        for issue in issues:
            severity = issue['severity']
            weight = severity_weights.get(severity, 1)
            base_score -= weight
        
        # Deduct points for high complexity
        total_complexity = metrics.get('total_complexity', 0)
        if total_complexity > 50:
            base_score -= min(20, (total_complexity - 50) // 5)
        
        # Deduct points for large programs (potential performance issues)
        if program.lines_of_code > 1000:
            base_score -= min(10, (program.lines_of_code - 1000) // 200)
        
        return max(0, min(100, base_score))
    
    def _determine_complexity_level(self, total_complexity: int) -> str:
        """Determine complexity level."""
        thresholds = self._config['complexity_thresholds']
        
        if total_complexity <= thresholds['low']:
            return "LOW"
        elif total_complexity <= thresholds['medium']:
            return "MEDIUM"
        elif total_complexity <= thresholds['high']:
            return "HIGH"
        else:
            return "VERY_HIGH"
    
    def _generate_optimizations(self, issues: List[Dict[str, Any]], metrics: Dict[str, Any]) -> List[str]:
        """Generate performance optimization recommendations."""
        optimizations = []
        
        issue_types = set(issue['type'] for issue in issues)
        
        if 'HIGH_COMPLEXITY' in issue_types:
            optimizations.append("Break down complex paragraphs into smaller, focused units")
        
        if 'NESTED_LOOPS' in issue_types:
            optimizations.append("Restructure nested loops to reduce computational complexity")
        
        if 'EXCESSIVE_FILE_OPS' in issue_types:
            optimizations.append("Implement file operation batching or buffering")
        
        if 'INEFFICIENT_ACCESS' in issue_types:
            optimizations.append("Optimize file access methods based on usage patterns")
        
        if 'GOTO_IN_LOOP' in issue_types:
            optimizations.append("Replace GO TO statements with structured programming constructs")
        
        if 'EXCESSIVE_MOVES' in issue_types:
            optimizations.append("Optimize data flow to reduce unnecessary data movement")
        
        if 'INEFFICIENT_ARITHMETIC' in issue_types:
            optimizations.append("Use COMPUTE statements for complex arithmetic operations")
        
        if not optimizations:
            optimizations.append("Performance analysis passed - current implementation is efficient")
        
        return optimizations

