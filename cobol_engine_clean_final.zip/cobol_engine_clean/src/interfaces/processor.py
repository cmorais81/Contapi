"""
Processor interface following Interface Segregation Principle.
"""

from abc import ABC, abstractmethod
from typing import List, Dict, Any
from ..core.models import BatchResult, AnalysisResult


class IProcessor(ABC):
    """
    Interface for file processors.
    Following Single Responsibility Principle.
    """
    
    @abstractmethod
    def process_single_file(self, file_path: str, analyzers: List[str], options: Dict[str, Any]) -> AnalysisResult:
        """
        Process a single COBOL file.
        
        Args:
            file_path: Path to COBOL file
            analyzers: List of analyzer names to run
            options: Processing options
            
        Returns:
            AnalysisResult
        """
        pass
    
    @abstractmethod
    def process_multiple_files(self, file_paths: List[str], analyzers: List[str], options: Dict[str, Any]) -> BatchResult:
        """
        Process multiple COBOL files.
        
        Args:
            file_paths: List of file paths
            analyzers: List of analyzer names to run
            options: Processing options
            
        Returns:
            BatchResult
        """
        pass


class IBatchProcessor(IProcessor):
    """Interface for batch processing."""
    
    @abstractmethod
    def process_zip_file(self, zip_path: str, analyzers: List[str], options: Dict[str, Any]) -> BatchResult:
        """
        Process a ZIP file containing COBOL programs.
        
        Args:
            zip_path: Path to ZIP file
            analyzers: List of analyzer names to run
            options: Processing options
            
        Returns:
            BatchResult
        """
        pass
    
    @abstractmethod
    def process_directory(self, directory_path: str, analyzers: List[str], options: Dict[str, Any]) -> BatchResult:
        """
        Process a directory containing COBOL programs.
        
        Args:
            directory_path: Path to directory
            analyzers: List of analyzer names to run
            options: Processing options
            
        Returns:
            BatchResult
        """
        pass


class IFileExtractor(ABC):
    """Interface for file extraction."""
    
    @abstractmethod
    def extract_cobol_files(self, source_path: str) -> List[str]:
        """
        Extract COBOL files from source.
        
        Args:
            source_path: Path to ZIP file or directory
            
        Returns:
            List of COBOL file paths
        """
        pass
    
    @abstractmethod
    def is_cobol_file(self, file_path: str) -> bool:
        """
        Check if file is a COBOL file.
        
        Args:
            file_path: Path to file
            
        Returns:
            True if file is COBOL
        """
        pass

