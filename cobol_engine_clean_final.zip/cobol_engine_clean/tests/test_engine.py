"""
Tests for the main DocumentationEngine.
"""

import pytest
import os
import tempfile
from src.core.engine import DocumentationEngine
from src.core.models import CobolProgram, AnalysisResult


class TestDocumentationEngine:
    """Test cases for DocumentationEngine."""
    
    def setup_method(self):
        """Setup test environment."""
        self.engine = DocumentationEngine()
        
        # Create a simple COBOL program for testing
        self.test_cobol_content = """
IDENTIFICATION DIVISION.
PROGRAM-ID. TEST-PROGRAM.

DATA DIVISION.
WORKING-STORAGE SECTION.
01  WS-COUNTER    PIC 9(3) VALUE 0.
01  WS-NAME       PIC X(20).

PROCEDURE DIVISION.
MAIN-SECTION.
000-MAIN.
    MOVE "TEST" TO WS-NAME
    ADD 1 TO WS-COUNTER
    DISPLAY WS-NAME
    STOP RUN.
"""
    
    def test_engine_initialization(self):
        """Test engine initializes correctly."""
        assert self.engine is not None
        assert self.engine.parser is not None
        assert self.engine.analyzer_registry is not None
        assert self.engine.formatter_registry is not None
    
    def test_get_available_analyzers(self):
        """Test getting available analyzers."""
        analyzers = self.engine.get_available_analyzers()
        assert isinstance(analyzers, list)
        assert len(analyzers) > 0
        assert 'security_analyzer' in analyzers
        assert 'performance_analyzer' in analyzers
    
    def test_get_available_formatters(self):
        """Test getting available formatters."""
        formatters = self.engine.get_available_formatters()
        assert isinstance(formatters, list)
        assert len(formatters) > 0
        assert 'json' in formatters
        assert 'yaml' in formatters
        assert 'markdown' in formatters
    
    def test_analyze_single_file(self):
        """Test analyzing a single COBOL file."""
        # Create temporary file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.cbl', delete=False) as f:
            f.write(self.test_cobol_content)
            temp_file = f.name
        
        try:
            # Analyze the file
            result = self.engine.analyze_single_file(temp_file)
            
            # Verify result
            assert isinstance(result, AnalysisResult)
            assert result.success is True
            assert result.program_id == "TEST-PROGRAM"
            assert 'program_info' in result.data
            
            # Verify program info
            program_info = result.data['program_info']
            assert program_info['program_id'] == "TEST-PROGRAM"
            assert program_info['variables_count'] >= 0  # Parser may not detect all variables in simple test
            assert program_info['lines_of_code'] > 0
            
        finally:
            # Cleanup
            os.unlink(temp_file)
    
    def test_analyze_single_file_with_analyzers(self):
        """Test analyzing a file with specific analyzers."""
        # Create temporary file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.cbl', delete=False) as f:
            f.write(self.test_cobol_content)
            temp_file = f.name
        
        try:
            # Analyze with specific analyzers
            result = self.engine.analyze_single_file(
                temp_file, 
                analyzers=['security_analyzer', 'performance_analyzer']
            )
            
            # Verify result
            assert result.success is True
            assert 'analyzer_results' in result.data
            
            analyzer_results = result.data['analyzer_results']
            assert 'security_analyzer' in analyzer_results
            assert 'performance_analyzer' in analyzer_results
            
            # Verify security analysis
            security_data = analyzer_results['security_analyzer']
            assert 'security_score' in security_data
            assert isinstance(security_data['security_score'], int)
            assert 0 <= security_data['security_score'] <= 100
            
            # Verify performance analysis
            performance_data = analyzer_results['performance_analyzer']
            assert 'performance_score' in performance_data
            assert isinstance(performance_data['performance_score'], int)
            assert 0 <= performance_data['performance_score'] <= 100
            
        finally:
            # Cleanup
            os.unlink(temp_file)
    
    def test_analyze_nonexistent_file(self):
        """Test analyzing a non-existent file."""
        result = self.engine.analyze_single_file("nonexistent.cbl")
        
        assert result.success is False
        assert len(result.errors) > 0
        assert "not found" in result.errors[0].lower() or "no such file" in result.errors[0].lower()
    
    def test_format_result_json(self):
        """Test formatting result as JSON."""
        # Create temporary file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.cbl', delete=False) as f:
            f.write(self.test_cobol_content)
            temp_file = f.name
        
        try:
            # Analyze and format
            result = self.engine.analyze_single_file(temp_file)
            formatted = self.engine.format_result(result, 'json')
            
            # Verify JSON format
            assert isinstance(formatted, str)
            assert '"program_id"' in formatted
            assert '"success"' in formatted
            assert '"TEST-PROGRAM"' in formatted
            
        finally:
            # Cleanup
            os.unlink(temp_file)
    
    def test_format_result_markdown(self):
        """Test formatting result as Markdown."""
        # Create temporary file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.cbl', delete=False) as f:
            f.write(self.test_cobol_content)
            temp_file = f.name
        
        try:
            # Analyze and format
            result = self.engine.analyze_single_file(temp_file)
            formatted = self.engine.format_result(result, 'markdown')
            
            # Verify Markdown format
            assert isinstance(formatted, str)
            assert '# Analysis Report' in formatted
            assert 'TEST-PROGRAM' in formatted
            assert '## Basic Information' in formatted
            
        finally:
            # Cleanup
            os.unlink(temp_file)
    
    def test_save_result(self):
        """Test saving analysis result to file."""
        # Create temporary file for analysis
        with tempfile.NamedTemporaryFile(mode='w', suffix='.cbl', delete=False) as f:
            f.write(self.test_cobol_content)
            temp_file = f.name
        
        # Create temporary directory for output
        with tempfile.TemporaryDirectory() as temp_dir:
            try:
                # Analyze and save
                result = self.engine.analyze_single_file(temp_file)
                output_file = os.path.join(temp_dir, "test_result.json")
                
                self.engine.save_result(result, output_file, 'json')
                
                # Verify file was created
                assert os.path.exists(output_file)
                
                # Verify file content
                with open(output_file, 'r') as f:
                    content = f.read()
                    assert '"program_id"' in content
                    assert '"TEST-PROGRAM"' in content
                    
            finally:
                # Cleanup
                os.unlink(temp_file)


if __name__ == "__main__":
    pytest.main([__file__])

