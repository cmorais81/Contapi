# COBOL Documentation Engine - Usage Guide

## Quick Start

### 1. Single File Analysis

Analyze a single COBOL program:

```bash
python cobol_engine.py analyze program.cbl --output ./results
```

**Example Output:**
```
Analyzing file: program.cbl
Analyzers: security_analyzer, performance_analyzer
Output format: json

           Analysis Results           
┏━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━┓
┃ Metric            ┃ Value          ┃
┡━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━┩
│ Status            │ ✅ Success     │
│ Program ID        │ SAMPLE-PROGRAM │
│ Security Score    │ 93/100         │
│ Performance Score │ 100/100        │
└───────────────────┴────────────────┘

✅ Analysis complete!
Results saved to: ./results/program_analysis.json
```

### 2. Batch Analysis (ZIP File)

Analyze multiple COBOL programs from a ZIP file:

```bash
python cobol_engine.py batch portfolio.zip --output ./batch_results
```

**Example Output:**
```
Source: portfolio.zip
Analyzers: security_analyzer, performance_analyzer
Parallel processing: True

             Batch Analysis Results              
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━┓
┃ Metric                    ┃ Value             ┃
┡━━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━┩
│ Total Files               │ 25                │
│ Processed Successfully    │ 24                │
│ Failed                    │ 1                 │
│ Success Rate              │ 96.0%             │
│ Average Security Score    │ 87.3/100          │
│ Average Performance Score │ 78.9/100          │
└───────────────────────────┴───────────────────┘

✅ Batch analysis complete!
Results saved to: ./batch_results
```

### 3. Directory Analysis

Analyze all COBOL files in a directory:

```bash
python cobol_engine.py batch /path/to/cobol/files --output ./directory_results
```

## Command Reference

### Analyze Command

```bash
python cobol_engine.py analyze <file> [options]
```

**Options:**
- `--output, -o`: Output directory (default: ./output)
- `--format, -f`: Output format (json, yaml, markdown)
- `--analyzers, -a`: Specific analyzers to run

**Examples:**
```bash
# Basic analysis
python cobol_engine.py analyze program.cbl

# Custom output directory and format
python cobol_engine.py analyze program.cbl --output ./my_results --format markdown

# Run only security analysis
python cobol_engine.py analyze program.cbl --analyzers security_analyzer

# Run multiple specific analyzers
python cobol_engine.py analyze program.cbl --analyzers security_analyzer performance_analyzer
```

### Batch Command

```bash
python cobol_engine.py batch <source> --output <directory> [options]
```

**Options:**
- `--output, -o`: Output directory (required)
- `--format, -f`: Output format for individual files (json, yaml, markdown)
- `--analyzers, -a`: Specific analyzers to run
- `--parallel`: Enable parallel processing (default: True)
- `--max-workers`: Maximum parallel workers (default: 4)

**Examples:**
```bash
# Basic batch analysis
python cobol_engine.py batch portfolio.zip --output ./results

# Sequential processing (for limited resources)
python cobol_engine.py batch portfolio.zip --output ./results --parallel false

# High-performance parallel processing
python cobol_engine.py batch large_portfolio.zip --output ./results --max-workers 8

# Security-focused analysis
python cobol_engine.py batch portfolio.zip --output ./security_audit --analyzers security_analyzer

# Custom format for individual files
python cobol_engine.py batch portfolio.zip --output ./results --format yaml
```

### Info Command

```bash
python cobol_engine.py info [options]
```

**Options:**
- `--analyzers`: Show available analyzers
- `--formatters`: Show available formatters

**Examples:**
```bash
# Show all information
python cobol_engine.py info

# Show only analyzers
python cobol_engine.py info --analyzers

# Show only formatters
python cobol_engine.py info --formatters
```

## Output Formats

### JSON Format

Structured data format ideal for integration with other tools:

```json
{
  "analyzer_name": "engine",
  "program_id": "SAMPLE-PROGRAM",
  "success": true,
  "execution_time": 0.15,
  "data": {
    "program_info": {
      "program_id": "SAMPLE-PROGRAM",
      "lines_of_code": 75,
      "variables_count": 5,
      "total_complexity": 8
    },
    "analyzer_results": {
      "security_analyzer": {
        "security_score": 93,
        "issues": [],
        "compliance_status": "COMPLIANT"
      },
      "performance_analyzer": {
        "performance_score": 100,
        "complexity": "LOW",
        "optimizations": []
      }
    }
  }
}
```

### YAML Format

Human-readable structured format:

```yaml
analyzer_name: engine
program_id: SAMPLE-PROGRAM
success: true
execution_time: 0.15
data:
  program_info:
    program_id: SAMPLE-PROGRAM
    lines_of_code: 75
    variables_count: 5
    total_complexity: 8
  analyzer_results:
    security_analyzer:
      security_score: 93
      compliance_status: COMPLIANT
    performance_analyzer:
      performance_score: 100
      complexity: LOW
```

### Markdown Format

Documentation-ready format:

```markdown
# Analysis Report - SAMPLE-PROGRAM

## Basic Information
- **Program ID**: SAMPLE-PROGRAM
- **Success**: ✅
- **Lines of Code**: 75
- **Variables**: 5
- **Complexity**: 8

## Analysis Results

### Security Analysis
- **Security Score**: 93/100
- **Compliance Status**: COMPLIANT
- **Issues Found**: 0

### Performance Analysis
- **Performance Score**: 100/100
- **Complexity**: LOW
- **Optimizations**: None needed
```

## Batch Processing Results

### Individual Files

Each COBOL file gets its own analysis file:
- `program1_analysis.json`
- `program2_analysis.json`
- `program3_analysis.json`

### Consolidated Report

A summary report in Markdown format:
- `consolidated_report.md`

**Example Consolidated Report:**
```markdown
# Batch Analysis Report

## Summary Statistics
- **Total Files**: 25
- **Processed Successfully**: 24
- **Failed**: 1
- **Success Rate**: 96.0%
- **Total Lines of Code**: 12,500
- **Processing Speed**: 450.2 files/min

## Consolidated Metrics
### Security Analysis
- **Average Security Score**: 87.3/100
- **Best Score**: 98/100
- **Worst Score**: 65/100

### Performance Analysis
- **Average Performance Score**: 78.9/100
- **Best Score**: 95/100
- **Worst Score**: 45/100

## File Results
| File | Status | Program ID | Lines | Security | Performance |
|------|--------|------------|-------|----------|-------------|
| payroll.cbl | ✅ Success | PAYROLL-CALC | 450 | 92/100 | 85/100 |
| customer.cbl | ✅ Success | CUST-MGMT | 320 | 88/100 | 78/100 |
| inventory.cbl | ❌ Failed | - | - | - | - |
```

## Use Cases

### 1. Security Audit

Focus on security analysis for compliance:

```bash
# Security-only analysis
python cobol_engine.py batch system.zip \
  --output ./security_audit \
  --analyzers security_analyzer \
  --format markdown

# Review results
cat ./security_audit/consolidated_report.md
```

### 2. Performance Optimization

Identify performance bottlenecks:

```bash
# Performance-focused analysis
python cobol_engine.py batch critical_batch_jobs.zip \
  --output ./performance_review \
  --analyzers performance_analyzer \
  --max-workers 8

# Find programs with low performance scores
grep -l "performance_score.*[0-4][0-9]" ./performance_review/*.json
```

### 3. Code Quality Assessment

Comprehensive quality review:

```bash
# Full analysis with all analyzers
python cobol_engine.py batch legacy_system.zip \
  --output ./quality_assessment \
  --format yaml

# Generate summary statistics
python -c "
import json, glob
scores = []
for f in glob.glob('./quality_assessment/*.json'):
    with open(f) as file:
        data = json.load(file)
        if 'analyzer_results' in data['data']:
            sec = data['data']['analyzer_results'].get('security_analyzer', {}).get('security_score', 0)
            perf = data['data']['analyzer_results'].get('performance_analyzer', {}).get('performance_score', 0)
            scores.append((sec, perf))

if scores:
    avg_sec = sum(s[0] for s in scores) / len(scores)
    avg_perf = sum(s[1] for s in scores) / len(scores)
    print(f'Average Security Score: {avg_sec:.1f}/100')
    print(f'Average Performance Score: {avg_perf:.1f}/100')
"
```

### 4. Documentation Generation

Create comprehensive documentation:

```bash
# Generate markdown documentation for all programs
python cobol_engine.py batch documentation_source.zip \
  --output ./program_docs \
  --format markdown

# Combine all documentation
cat ./program_docs/*.md > complete_system_documentation.md
```

## Tips and Best Practices

### Performance Optimization

1. **Use parallel processing** for large portfolios:
   ```bash
   --parallel --max-workers 8
   ```

2. **Limit analyzers** for faster processing:
   ```bash
   --analyzers security_analyzer  # Only security
   ```

3. **Process in batches** for very large systems:
   ```bash
   # Split large ZIP into smaller ones
   python cobol_engine.py batch part1.zip --output ./results1
   python cobol_engine.py batch part2.zip --output ./results2
   ```

### Resource Management

1. **Monitor memory usage** with large portfolios
2. **Use sequential processing** on limited resources:
   ```bash
   --parallel false
   ```
3. **Adjust worker count** based on available CPU cores

### Output Organization

1. **Use descriptive output directories**:
   ```bash
   --output ./security_audit_2024_q3
   ```

2. **Separate different analysis types**:
   ```bash
   # Security audit
   python cobol_engine.py batch system.zip --output ./security --analyzers security_analyzer
   
   # Performance review
   python cobol_engine.py batch system.zip --output ./performance --analyzers performance_analyzer
   ```

3. **Archive results** for historical comparison:
   ```bash
   tar -czf analysis_$(date +%Y%m%d).tar.gz ./results/
   ```

## Troubleshooting

### Common Issues

1. **File not found errors**:
   - Verify file paths are correct
   - Check file permissions
   - Ensure COBOL files have correct extensions (.cbl, .cob, .cobol, .txt)

2. **Memory errors with large portfolios**:
   - Reduce `--max-workers`
   - Use `--parallel false`
   - Process in smaller batches

3. **Parsing errors**:
   - Check COBOL syntax
   - Verify file encoding (UTF-8 recommended)
   - Review error messages in output

### Getting Help

```bash
# Show command help
python cobol_engine.py --help
python cobol_engine.py analyze --help
python cobol_engine.py batch --help

# Show engine information
python cobol_engine.py info

# Run with verbose output (if available)
python cobol_engine.py analyze program.cbl --verbose
```

## Integration Examples

### CI/CD Pipeline

```yaml
# .github/workflows/cobol-analysis.yml
name: COBOL Analysis
on: [push, pull_request]

jobs:
  analyze:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Setup Python
        uses: actions/setup-python@v2
        with:
          python-version: '3.11'
      - name: Install dependencies
        run: pip install -r requirements.txt
      - name: Analyze COBOL code
        run: |
          python cobol_engine.py batch ./cobol_src --output ./analysis
          # Fail if security score is too low
          python -c "
          import json, sys
          with open('./analysis/consolidated_report.md') as f:
              content = f.read()
              if 'Average Security Score: ' in content:
                  score = float(content.split('Average Security Score: ')[1].split('/')[0])
                  if score < 80:
                      print(f'Security score {score} below threshold')
                      sys.exit(1)
          "
```

### Automated Reporting

```bash
#!/bin/bash
# weekly_analysis.sh

DATE=$(date +%Y%m%d)
OUTPUT_DIR="./analysis_$DATE"

# Run analysis
python cobol_engine.py batch production_code.zip --output "$OUTPUT_DIR"

# Generate summary email
{
    echo "Weekly COBOL Analysis Report - $DATE"
    echo "=================================="
    echo ""
    cat "$OUTPUT_DIR/consolidated_report.md"
} | mail -s "COBOL Analysis Report $DATE" team@company.com

# Archive results
tar -czf "analysis_$DATE.tar.gz" "$OUTPUT_DIR"
```

This guide covers the essential usage patterns for the COBOL Documentation Engine. For advanced features and customization, refer to the main README.md and source code documentation.

