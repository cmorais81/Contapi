# COBOL Documentation Engine

A modern, extensible tool for analyzing and documenting COBOL programs following SOLID principles and clean architecture.

## Features

### 🔍 **Comprehensive Analysis**
- **COBOL Parser**: Advanced parsing with support for COPY books, hierarchical data structures, and file definitions
- **Security Analysis**: Vulnerability detection, compliance checking, and security scoring
- **Performance Analysis**: Complexity metrics, bottleneck identification, and optimization recommendations
- **Batch Processing**: Analyze entire portfolios from ZIP files or directories

### 🏗️ **Clean Architecture**
- **SOLID Principles**: Single Responsibility, Open/Closed, Liskov Substitution, Interface Segregation, Dependency Inversion
- **Extensible Design**: Plugin-based analyzer system
- **Multiple Formats**: JSON, YAML, Markdown output formats
- **Type Safety**: Full type hints and robust error handling

### ⚡ **High Performance**
- **Parallel Processing**: Multi-threaded batch analysis
- **Memory Efficient**: Optimized for large codebases
- **Fast Parsing**: Efficient regex-based COBOL parsing

## Quick Start

### Installation

```bash
# Install from source
git clone https://github.com/cobol-engine/cobol-documentation-engine.git
cd cobol-documentation-engine
pip install -e .

# Or install with development dependencies
pip install -e ".[dev]"

# Or install with AI integration
pip install -e ".[ai]"
```

### Basic Usage

```bash
# Analyze a single COBOL file
cobol-engine analyze program.cbl --output ./results

# Batch analyze a ZIP file
cobol-engine batch portfolio.zip --output ./analysis

# Batch analyze with specific analyzers
cobol-engine batch portfolio.zip --output ./analysis --analyzers security_analyzer performance_analyzer

# Show available analyzers and formatters
cobol-engine info
```

### Python API

```python
from src.core.engine import DocumentationEngine

# Initialize engine
engine = DocumentationEngine()

# Analyze single file
result = engine.analyze_single_file(
    "program.cbl", 
    analyzers=["security_analyzer", "performance_analyzer"]
)

# Batch analyze
batch_result = engine.analyze_batch(
    "portfolio.zip",
    analyzers=["security_analyzer"],
    parallel=True,
    max_workers=4
)

# Save results
engine.save_result(result, "analysis.json", "json")
engine.save_batch_result(batch_result, "./output", "json")
```

## Architecture

### Core Components

```
src/
├── core/                   # Core business logic
│   ├── models.py          # Data models
│   ├── parser.py          # COBOL parser
│   └── engine.py          # Main engine
├── interfaces/            # Contracts (ISP)
│   ├── analyzer.py        # Analyzer interfaces
│   ├── parser.py          # Parser interfaces
│   ├── formatter.py       # Formatter interfaces
│   └── processor.py       # Processor interfaces
├── analyzers/             # Analysis implementations
│   ├── registry.py        # Analyzer registry
│   ├── security.py        # Security analyzer
│   └── performance.py     # Performance analyzer
├── utils/                 # Utilities
│   ├── exceptions.py      # Custom exceptions
│   ├── file_utils.py      # File operations
│   └── formatters.py      # Output formatters
└── cli.py                 # Command line interface
```

### Design Principles

#### Single Responsibility Principle (SRP)
- Each class has one reason to change
- `CobolParser` only handles parsing
- `SecurityAnalyzer` only handles security analysis
- `FileExtractor` only handles file extraction

#### Open/Closed Principle (OCP)
- Extensible through interfaces
- Add new analyzers by implementing `IAnalyzer`
- Add new formatters by implementing `IFormatter`

#### Liskov Substitution Principle (LSP)
- All analyzer implementations are interchangeable
- All formatter implementations are interchangeable

#### Interface Segregation Principle (ISP)
- Small, focused interfaces
- `ISecurityAnalyzer` extends `IAnalyzer` with security-specific methods
- `IPerformanceAnalyzer` extends `IAnalyzer` with performance-specific methods

#### Dependency Inversion Principle (DIP)
- High-level modules depend on abstractions
- `DocumentationEngine` depends on `IParser`, `IAnalyzer` interfaces
- Concrete implementations injected via constructor

## Analyzers

### Security Analyzer

Analyzes COBOL programs for security vulnerabilities:

- **Input Validation**: Detects ACCEPT statements without validation
- **File Security**: Checks for missing FILE STATUS handling
- **Data Exposure**: Identifies potential sensitive data in DISPLAY statements
- **Error Handling**: Validates error handling for file operations

**Output**: Security score (0-100), vulnerability list, compliance status

### Performance Analyzer

Analyzes COBOL programs for performance issues:

- **Complexity Analysis**: Calculates cyclomatic complexity
- **Loop Analysis**: Detects nested loops and inefficient patterns
- **File Operations**: Identifies inefficient file access patterns
- **Data Movement**: Analyzes data flow efficiency

**Output**: Performance score (0-100), bottleneck list, optimization recommendations

## Output Formats

### JSON Format
```json
{
  "analyzer_name": "engine",
  "program_id": "PAYROLL-CALC",
  "success": true,
  "execution_time": 0.15,
  "data": {
    "program_info": {
      "lines_of_code": 150,
      "variables_count": 25,
      "total_complexity": 12
    },
    "analyzer_results": {
      "security_analyzer": {
        "security_score": 85,
        "issues": [...],
        "compliance_status": "COMPLIANT"
      }
    }
  }
}
```

### Markdown Format
```markdown
# Analysis Report - PAYROLL-CALC

## Basic Information
- **Program ID**: PAYROLL-CALC
- **Success**: ✅
- **Lines of Code**: 150
- **Security Score**: 85/100

## Analysis Results
### Security Analysis
- **Security Score**: 85/100
- **Issues Found**: 3
- **Compliance Status**: COMPLIANT
```

## Batch Processing

Process multiple COBOL files efficiently:

```bash
# Process ZIP file
cobol-engine batch portfolio.zip --output ./results --parallel --max-workers 8

# Process directory
cobol-engine batch /path/to/cobol/files --output ./results

# Custom analyzers
cobol-engine batch portfolio.zip --output ./results --analyzers security_analyzer
```

### Batch Output

- **Individual Analysis**: JSON/YAML/Markdown file per program
- **Consolidated Report**: Markdown summary with statistics
- **Metrics**: Success rate, processing speed, quality scores

## Extending the Engine

### Adding a New Analyzer

```python
from src.interfaces.analyzer import IAnalyzer
from src.core.models import CobolProgram, AnalysisResult

class CustomAnalyzer(IAnalyzer):
    @property
    def name(self) -> str:
        return "custom_analyzer"
    
    @property
    def version(self) -> str:
        return "1.0.0"
    
    def analyze(self, program: CobolProgram) -> AnalysisResult:
        # Your analysis logic here
        result = AnalysisResult(
            analyzer_name=self.name,
            program_id=program.program_id,
            success=True
        )
        # Add analysis data
        result.data['custom_metric'] = 42
        return result
    
    def get_configuration(self) -> Dict[str, Any]:
        return {}
    
    def set_configuration(self, config: Dict[str, Any]) -> None:
        pass

# Register the analyzer
engine = DocumentationEngine()
engine.analyzer_registry.register_analyzer(CustomAnalyzer())
```

### Adding a New Formatter

```python
from src.interfaces.formatter import IFormatter
from src.core.models import AnalysisResult, BatchResult

class CustomFormatter(IFormatter):
    @property
    def format_name(self) -> str:
        return "custom"
    
    @property
    def file_extension(self) -> str:
        return ".custom"
    
    def format_single_result(self, result: AnalysisResult) -> str:
        # Your formatting logic here
        return f"Custom format for {result.program_id}"
    
    def format_batch_result(self, batch_result: BatchResult) -> str:
        # Your batch formatting logic here
        return f"Batch report: {batch_result.total_files} files"

# Register the formatter
engine = DocumentationEngine()
engine.formatter_registry.register_formatter(CustomFormatter())
```

## Configuration

### Environment Variables

```bash
# Optional: AI integration
export OPENAI_API_KEY="your-api-key"
export OPENAI_API_BASE="https://api.openai.com/v1"

# Optional: Custom COPY book paths
export COBOL_COPY_PATHS="/path/to/copybooks:/another/path"
```

### Configuration File

Create `config.yaml`:

```yaml
analyzers:
  security_analyzer:
    check_input_validation: true
    check_file_operations: true
    severity_weights:
      CRITICAL: 10
      HIGH: 7
      MEDIUM: 4
      LOW: 1

  performance_analyzer:
    check_complexity: true
    complexity_thresholds:
      low: 10
      medium: 20
      high: 30

output:
  default_format: "json"
  include_source_code: false

processing:
  max_workers: 4
  timeout_seconds: 300
```

## Testing

```bash
# Run all tests
pytest

# Run with coverage
pytest --cov=src --cov-report=html

# Run specific test
pytest tests/test_parser.py

# Run with verbose output
pytest -v
```

## Performance

### Benchmarks

| Portfolio Size | Files | Lines of Code | Processing Time | Speed |
|---------------|-------|---------------|-----------------|-------|
| Small         | 10    | 5,000         | 2.3s           | 260 files/min |
| Medium        | 50    | 25,000        | 8.7s           | 345 files/min |
| Large         | 200   | 100,000       | 28.4s          | 422 files/min |
| Enterprise    | 1000  | 500,000       | 142.1s         | 422 files/min |

### Memory Usage

- **Parser**: ~10MB per 1000 lines of COBOL
- **Analyzers**: ~5MB per program
- **Batch Processing**: ~50MB base + (files × 15MB)

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Follow SOLID principles and add tests
4. Ensure code quality (`black`, `flake8`, `mypy`)
5. Commit changes (`git commit -m 'Add amazing feature'`)
6. Push to branch (`git push origin feature/amazing-feature`)
7. Open a Pull Request

### Code Quality

```bash
# Format code
black src/ tests/

# Lint code
flake8 src/ tests/

# Type checking
mypy src/

# Run all quality checks
make quality
```

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Support

- **Documentation**: [docs/](docs/)
- **Issues**: [GitHub Issues](https://github.com/cobol-engine/cobol-documentation-engine/issues)
- **Discussions**: [GitHub Discussions](https://github.com/cobol-engine/cobol-documentation-engine/discussions)

## Roadmap

### Version 2.1
- [ ] Migration analyzer
- [ ] AI-powered documentation generation
- [ ] Web interface
- [ ] Database integration

### Version 2.2
- [ ] Visual dependency graphs
- [ ] Code quality metrics
- [ ] Integration with CI/CD pipelines
- [ ] Cloud deployment options

### Version 3.0
- [ ] Multi-language support (PL/I, RPG)
- [ ] Real-time analysis
- [ ] Advanced visualization
- [ ] Enterprise features

