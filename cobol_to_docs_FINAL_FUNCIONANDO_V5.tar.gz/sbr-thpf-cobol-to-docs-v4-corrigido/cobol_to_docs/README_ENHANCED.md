# COBOL Analyzer Enhanced v3.1.0

Sistema avançado de análise e documentação de programas COBOL com tecnologia de IA, agora com **inicialização automática** e **diretórios personalizáveis**.

## Novidades da Versão 3.1.0

### Funcionalidades Principais

- **Inicialização Automática**: Configuração automática do ambiente na primeira execução
- **Diretórios Personalizáveis**: Todos os diretórios podem ser customizados via linha de comando
- **CLI Aprimorado**: Interface de linha de comando mais intuitiva e poderosa
- **Configuração Avançada**: Sistema de configuração flexível com múltiplos arquivos
- **Compatibilidade Total**: Mantém compatibilidade com versões anteriores

### Inicialização Rápida

```bash
# Primeira execução - configuração automática
cobol-to-docs --fontes fontes.txt

# Inicialização manual
cobol-to-docs --init

# Com diretórios personalizados
cobol-to-docs --init --config-dir ./config --data-dir ./dados
```

## Instalação

### Via pip (Recomendado)

```bash
pip install cobol-to-docs
```

### Instalação Local

```bash
git clone <repositorio>
cd cobol_analyzer_EXCELENCIA
pip install -e .
```

## Uso Básico

### Comandos Essenciais

```bash
# Análise básica
cobol-to-docs --fontes fontes.txt

# Análise com copybooks
cobol-to-docs --fontes fontes.txt --books books.txt

# Análise consolidada
cobol-to-docs --fontes fontes.txt --consolidado

# Verificar status
cobol-to-docs --status
```

### Diretórios Personalizados

```bash
# Configuração personalizada
cobol-to-docs --fontes fontes.txt \
  --config-dir /path/to/config \
  --data-dir /path/to/data \
  --logs-dir /path/to/logs

# Mostrar caminhos configurados
cobol-to-docs --show-paths
```

## Estrutura do Projeto

```
cobol_analyzer_EXCELENCIA/
├── main_enhanced.py              # Ponto de entrada aprimorado
├── cli_enhanced.py               # CLI aprimorado
├── cobol_to_docs_enhanced.py     # Wrapper principal
├── config/                       # Configurações
│   ├── config_enhanced.yaml      # Configuração principal v3.1.0
│   └── prompts_enhanced.yaml     # Prompts aprimorados
├── src/                          # Código fonte
│   ├── core/
│   │   ├── config_enhanced.py    # Gerenciador de config aprimorado
│   │   └── local_setup.py        # Sistema de inicialização
│   ├── providers/                # Provedores de IA
│   ├── analyzers/                # Analisadores COBOL
│   ├── generators/               # Geradores de documentação
│   └── rag/                      # Sistema RAG
├── data/                         # Dados RAG (criado automaticamente)
├── logs/                         # Logs (criado automaticamente)
└── examples/                     # Exemplos (criado automaticamente)
```

## Configuração

### Arquivo config_enhanced.yaml

```yaml
# Diretórios personalizáveis
directories:
  config_dir: "config"
  data_dir: "data"
  logs_dir: "logs"
  output_dir: "output"

# Inicialização automática
auto_initialization:
  enabled: true
  create_examples: true
  copy_default_configs: true
  setup_rag_data: true

# Modelos de IA
models:
  default: "enhanced_mock"
  enhanced_mock:
    provider: "enhanced_mock"
    model: "enhanced-mock-gpt-4"
    enabled: true
```

### Prompts Especializados

O sistema oferece conjuntos de prompts para diferentes cenários:

- **original**: Análise padrão básica
- **professional**: Documentação empresarial
- **expert**: Análise para modernização
- **ultra_detailed**: Análise microscópica

```bash
# Usar prompts profissionais
cobol-to-docs --fontes fontes.txt --prompt-set professional
```

## Provedores de IA Suportados

| Provedor | Modelo | Status | Descrição |
|----------|--------|--------|-----------|
| Enhanced Mock | enhanced-mock-gpt-4 | Ativo | Para testes e desenvolvimento |
| Luzia | luzia-gpt-4 | Disponível | Análise profissional |
| OpenAI | gpt-4 | Disponível | Análise avançada |
| Databricks | databricks-dbrx-instruct | Disponível | Análise empresarial |
| AWS Bedrock | claude-3-sonnet | Disponível | Análise detalhada |

```bash
# Verificar status dos provedores
cobol-to-docs --status

# Usar modelo específico
cobol-to-docs --fontes fontes.txt --models "luzia-gpt-4"
```

## Funcionalidades Avançadas

### Sistema RAG (Retrieval Augmented Generation)

O sistema RAG enriquece a análise com conhecimento contextual:

- Base de conhecimento COBOL especializada
- Aprendizado contínuo com análises anteriores
- Relatórios de sessão detalhados

```bash
# Análise com RAG habilitado (padrão)
cobol-to-docs --fontes fontes.txt

# Verificar relatórios RAG
ls data/rag_sessions/
```

### Análises Especializadas

```bash
# Análise consolidada de sistema
cobol-to-docs --fontes fontes.txt --consolidado

# Análise avançada com relatório HTML
cobol-to-docs --fontes fontes.txt --advanced-analysis

# Análise detalhada de procedures
cobol-to-docs --fontes fontes.txt --procedure-detalhada

# Análise para modernização
cobol-to-docs --fontes fontes.txt --modernizacao
```

### Múltiplos Modelos

```bash
# Comparar análises de múltiplos modelos
cobol-to-docs --fontes fontes.txt --models '["enhanced_mock", "luzia-gpt-4"]'

# Seleção automática de modelo
cobol-to-docs --fontes fontes.txt --auto-model
```

## Cenários de Uso

### 1. Desenvolvimento Local

```bash
# Configuração para desenvolvimento
mkdir meu_projeto
cd meu_projeto
cobol-to-docs --init --config-dir ./config --data-dir ./data
```

### 2. Ambiente Corporativo

```bash
# Configuração corporativa
cobol-to-docs --fontes /corp/fontes.txt \
  --config-dir /etc/cobol_analyzer \
  --data-dir /var/lib/cobol_analyzer \
  --logs-dir /var/log/cobol_analyzer
```

### 3. Análise de Projeto Específico

```bash
# Projeto isolado
cobol-to-docs --fontes projeto_fontes.txt \
  --config-dir ./projeto_config \
  --data-dir ./projeto_data \
  --output ./projeto_output
```

### 4. Integração CI/CD

```bash
# Script para pipeline
#!/bin/bash
cobol-to-docs --fontes $CI_FONTES \
  --config-dir $CI_CONFIG \
  --data-dir $CI_DATA \
  --output $CI_OUTPUT \
  --models enhanced_mock \
  --consolidado
```

## Migração de Versões Anteriores

### Migração Automática

```bash
# O sistema detecta versões anteriores automaticamente
cobol-to-docs --fontes fontes.txt
# Perguntará sobre migração na primeira execução
```

### Migração Manual

```bash
# Backup dos dados existentes
cp -r config config_backup
cp -r data data_backup

# Inicializar nova estrutura
cobol-to-docs --init --force-init

# Restaurar configurações personalizadas
# (mesclar manualmente se necessário)
```

## Resolução de Problemas

### Problemas Comuns

**Erro: Diretório não encontrado**
```bash
# Solução: Inicializar ambiente
cobol-to-docs --init
```

**Erro: Configuração inválida**
```bash
# Solução: Verificar configuração
cobol-to-docs --show-paths
cobol-to-docs --init --force-init
```

**Erro: Permissões insuficientes**
```bash
# Solução: Usar diretório alternativo
cobol-to-docs --init --data-dir ~/cobol_data
```

### Logs de Diagnóstico

```bash
# Executar com logging detalhado
cobol-to-docs --fontes fontes.txt --log-level DEBUG

# Verificar logs
tail -f logs/cobol_to_docs_*.log
```

## Exemplos Práticos

### Análise Completa de Sistema

```bash
# Análise completa com todos os recursos
cobol-to-docs --fontes sistema_fontes.txt \
  --books sistema_books.txt \
  --consolidado \
  --advanced-analysis \
  --procedure-detalhada \
  --modernizacao \
  --pdf \
  --models '["enhanced_mock", "luzia-gpt-4"]'
```

### Configuração Docker

```dockerfile
FROM python:3.11
WORKDIR /app
COPY . .
RUN pip install -r requirements.txt

# Configurar diretórios
RUN mkdir -p /data/{config,rag,logs}
RUN python main_enhanced.py --init \
  --config-dir /data/config \
  --data-dir /data/rag \
  --logs-dir /data/logs

ENTRYPOINT ["python", "main_enhanced.py"]
```

### Script de Automação

```bash
#!/bin/bash
# analyze_project.sh

PROJECT=$1
CONFIG_DIR="./configs/$PROJECT"
DATA_DIR="./data/$PROJECT"
OUTPUT_DIR="./output/$PROJECT"

# Inicializar ambiente do projeto
cobol-to-docs --init \
  --config-dir "$CONFIG_DIR" \
  --data-dir "$DATA_DIR" \
  --logs-dir "./logs/$PROJECT"

# Executar análise
cobol-to-docs --fontes "$PROJECT/fontes.txt" \
  --books "$PROJECT/books.txt" \
  --config-dir "$CONFIG_DIR" \
  --data-dir "$DATA_DIR" \
  --output "$OUTPUT_DIR" \
  --consolidado \
  --advanced-analysis
```

## Referência de Parâmetros

### Parâmetros de Diretório (Novos v3.1.0)

| Parâmetro | Descrição | Exemplo |
|-----------|-----------|---------|
| `--config-dir` | Diretório de configuração | `--config-dir ./config` |
| `--data-dir` | Diretório de dados RAG | `--data-dir ./data` |
| `--logs-dir` | Diretório de logs | `--logs-dir ./logs` |
| `--init` | Inicializar ambiente | `--init` |
| `--force-init` | Forçar reinicialização | `--force-init` |
| `--show-paths` | Mostrar caminhos | `--show-paths` |

### Parâmetros de Análise

| Parâmetro | Descrição | Exemplo |
|-----------|-----------|---------|
| `--fontes` | Arquivo com programas COBOL | `--fontes fontes.txt` |
| `--books` | Arquivo com copybooks | `--books books.txt` |
| `--models` | Modelos de IA | `--models "luzia-gpt-4"` |
| `--consolidado` | Análise consolidada | `--consolidado` |
| `--advanced-analysis` | Análise avançada | `--advanced-analysis` |
| `--procedure-detalhada` | Análise detalhada de procedures | `--procedure-detalhada` |
| `--modernizacao` | Análise para modernização | `--modernizacao` |

### Parâmetros de Saída

| Parâmetro | Descrição | Exemplo |
|-----------|-----------|---------|
| `--output` | Diretório de saída | `--output ./output` |
| `--pdf` | Gerar relatórios PDF | `--pdf` |
| `--prompt-set` | Conjunto de prompts | `--prompt-set professional` |

## Arquitetura

### Componentes Principais

- **ConfigManager Enhanced**: Gerenciamento avançado de configuração
- **LocalSetup**: Sistema de inicialização automática
- **CLI Enhanced**: Interface de linha de comando aprimorada
- **RAG Integration**: Sistema de recuperação de conhecimento
- **Provider Manager**: Gerenciamento de provedores de IA
- **Analysis Engine**: Motor de análise COBOL

### Fluxo de Execução

1. **Inicialização**: Verificação e configuração do ambiente
2. **Configuração**: Carregamento de configurações e validação
3. **Análise**: Processamento dos programas COBOL
4. **Geração**: Criação de documentação e relatórios
5. **Finalização**: Limpeza e relatórios de sessão

## Contribuição

### Desenvolvimento

```bash
# Clonar repositório
git clone <repositorio>
cd cobol_analyzer_EXCELENCIA

# Instalar em modo desenvolvimento
pip install -e .

# Executar testes
python test_enhanced_features.py
```

### Estrutura de Testes

- **test_enhanced_features.py**: Testes das novas funcionalidades
- **Testes unitários**: Em desenvolvimento
- **Testes de integração**: Validação completa do sistema

## Licença

Este projeto está licenciado sob os termos da licença MIT.

## Suporte

Para suporte e documentação adicional:

- **Guia de Diretórios**: `GUIA_DIRETORIOS_PERSONALIZADOS.md`
- **Instalação**: `INSTALACAO_PIP.md`
- **Exemplos**: Diretório `examples/`
- **Logs**: Verificar `logs/` para diagnóstico

## Changelog

### v3.1.0 (2025-10-03)
- Inicialização automática de ambiente
- Diretórios personalizáveis via CLI
- CLI aprimorado com comandos de conveniência
- Sistema de configuração avançado
- Prompts especializados aprimorados
- Compatibilidade total com versões anteriores

### v3.0.0
- Sistema RAG integrado
- Múltiplos provedores de IA
- Análise consolidada avançada
- Relatórios HTML profissionais

### v2.0.0
- Análise de múltiplos programas
- Suporte a copybooks
- Geração de documentação automática

### v1.0.0
- Versão inicial
- Análise básica de programas COBOL
- Documentação em Markdown
