#!/usr/bin/env python3
"""
Exemplo Simples - Uso após pip install cobol-to-docs

Este é um exemplo básico de como usar o COBOL Analyzer
como componente programático após instalação via pip.
"""

def exemplo_uso_simples():
    """Exemplo mais simples possível"""
    
    print("🚀 COBOL Analyzer - Uso Programático Simples")
    print("=" * 50)
    
    # Passo 1: Verificar se está instalado
    try:
        import subprocess
        result = subprocess.run(['cobol-to-docs', '--help'], 
                              capture_output=True, text=True)
        if result.returncode == 0:
            print("✅ COBOL Analyzer instalado e funcionando")
        else:
            print("❌ COBOL Analyzer não está funcionando corretamente")
            return False
    except FileNotFoundError:
        print("❌ COBOL Analyzer não está instalado")
        print("💡 Instale com: pip install cobol-to-docs")
        return False
    
    # Passo 2: Inicializar ambiente (se necessário)
    import os
    from pathlib import Path
    
    if not Path(".cobol_analyzer_init").exists():
        print("📁 Inicializando ambiente local...")
        result = subprocess.run(['cobol-to-docs', '--init'], 
                              capture_output=True, text=True)
        if result.returncode == 0:
            print("✅ Ambiente inicializado")
        else:
            print("❌ Falha na inicialização")
            print(f"Erro: {result.stderr}")
            return False
    else:
        print("✅ Ambiente já inicializado")
    
    # Passo 3: Usar programaticamente
    try:
        # Importar após inicialização
        import sys
        sys.path.insert(0, '.')
        
        # Exemplo de programa COBOL
        programa_cobol = """
        IDENTIFICATION DIVISION.
        PROGRAM-ID. EXEMPLO-SIMPLES.
        
        DATA DIVISION.
        WORKING-STORAGE SECTION.
        01 WS-CONTADOR PIC 9(3) VALUE 0.
        01 WS-MENSAGEM PIC X(50) VALUE 'PROGRAMA EXEMPLO FUNCIONANDO'.
        
        PROCEDURE DIVISION.
        INICIO.
            DISPLAY WS-MENSAGEM.
            ADD 1 TO WS-CONTADOR.
            DISPLAY 'CONTADOR: ' WS-CONTADOR.
            STOP RUN.
        """
        
        print("📝 Analisando programa COBOL...")
        
        # Salvar programa em arquivo temporário
        with open("programa_exemplo.cbl", "w") as f:
            f.write(programa_cobol)
        
        # Criar lista de fontes
        with open("fontes.txt", "w") as f:
            f.write("programa_exemplo.cbl\n")
        
        # Executar análise
        result = subprocess.run([
            'cobol-to-docs', 
            '--fontes', 'fontes.txt',
            '--models', 'enhanced_mock'
        ], capture_output=True, text=True)
        
        if result.returncode == 0:
            print("✅ Análise concluída com sucesso!")
            
            # Verificar arquivos de saída
            output_files = list(Path(".").glob("output_*"))
            if output_files:
                print(f"📄 Arquivos gerados: {len(output_files)}")
                for file in output_files[:3]:  # Mostrar apenas os primeiros 3
                    print(f"   - {file}")
            else:
                print("📄 Nenhum arquivo de saída encontrado")
            
            return True
        else:
            print("❌ Falha na análise")
            print(f"Erro: {result.stderr}")
            return False
            
    except Exception as e:
        print(f"❌ Erro durante análise: {e}")
        return False
    
    finally:
        # Limpar arquivos temporários
        for temp_file in ["programa_exemplo.cbl", "fontes.txt"]:
            if Path(temp_file).exists():
                Path(temp_file).unlink()

def exemplo_uso_direto_python():
    """Exemplo usando diretamente as classes Python"""
    
    print("\n🐍 Uso Direto via Classes Python")
    print("=" * 40)
    
    try:
        # Tentar importar componentes
        from src.core.config_enhanced import EnhancedConfigManager
        from src.providers.enhanced_provider_manager import EnhancedProviderManager
        
        print("📦 Importando componentes...")
        
        # Configurar
        config_manager = EnhancedConfigManager()
        provider_manager = EnhancedProviderManager(config_manager.config)
        
        print("✅ Componentes carregados")
        print(f"🤖 Modelo padrão: {config_manager.config.get('models', {}).get('default', 'N/A')}")
        
        # Exemplo de análise simples
        programa_simples = """
        IDENTIFICATION DIVISION.
        PROGRAM-ID. TESTE-DIRETO.
        PROCEDURE DIVISION.
            DISPLAY 'TESTE DIRETO PYTHON'.
            STOP RUN.
        """
        
        print("🔍 Analisando via Python...")
        
        # Aqui você usaria o analisador real
        # Por simplicidade, vamos simular
        resultado_simulado = f"Documentação gerada para programa de {len(programa_simples)} caracteres"
        
        print(f"✅ Resultado: {len(resultado_simulado)} caracteres de documentação")
        
        return True
        
    except ImportError as e:
        print(f"❌ Erro de importação: {e}")
        print("💡 Certifique-se de estar no diretório correto ou que o pacote está instalado")
        return False
    except Exception as e:
        print(f"❌ Erro: {e}")
        return False

def exemplo_integracao_script():
    """Exemplo de integração em script próprio"""
    
    print("\n🔧 Integração em Script Próprio")
    print("=" * 35)
    
    # Simular função que você usaria em seu próprio sistema
    def analisar_cobol_no_meu_sistema(arquivo_cobol, config_personalizada=None):
        """
        Função que você usaria em seu próprio sistema
        para analisar programas COBOL
        """
        
        import subprocess
        import tempfile
        import json
        from pathlib import Path
        
        print(f"🔍 Analisando: {arquivo_cobol}")
        
        try:
            # Criar diretório temporário
            with tempfile.TemporaryDirectory() as temp_dir:
                temp_path = Path(temp_dir)
                
                # Copiar arquivo para temp
                if Path(arquivo_cobol).exists():
                    import shutil
                    shutil.copy(arquivo_cobol, temp_path / Path(arquivo_cobol).name)
                    
                    # Criar lista de fontes
                    fontes_file = temp_path / "fontes.txt"
                    with open(fontes_file, "w") as f:
                        f.write(f"{Path(arquivo_cobol).name}\n")
                    
                    # Executar análise
                    cmd = [
                        'cobol-to-docs',
                        '--fontes', str(fontes_file)
                    ]
                    
                    if config_personalizada:
                        cmd.extend(['--models', config_personalizada.get('modelo', 'enhanced_mock')])
                    
                    result = subprocess.run(cmd, 
                                          cwd=temp_path,
                                          capture_output=True, 
                                          text=True)
                    
                    if result.returncode == 0:
                        # Coletar resultados
                        output_files = list(temp_path.glob("output_*"))
                        
                        resultado = {
                            'status': 'sucesso',
                            'arquivo': arquivo_cobol,
                            'arquivos_gerados': len(output_files),
                            'stdout': result.stdout,
                            'stderr': result.stderr
                        }
                        
                        print(f"✅ Análise concluída: {len(output_files)} arquivos gerados")
                        return resultado
                    else:
                        print(f"❌ Falha na análise: {result.stderr}")
                        return {'status': 'erro', 'erro': result.stderr}
                else:
                    print(f"❌ Arquivo não encontrado: {arquivo_cobol}")
                    return {'status': 'erro', 'erro': 'Arquivo não encontrado'}
                    
        except Exception as e:
            print(f"❌ Erro na integração: {e}")
            return {'status': 'erro', 'erro': str(e)}
    
    # Exemplo de uso da função
    print("📝 Criando arquivo de teste...")
    
    # Criar arquivo de teste
    arquivo_teste = "teste_integracao.cbl"
    with open(arquivo_teste, "w") as f:
        f.write("""
        IDENTIFICATION DIVISION.
        PROGRAM-ID. TESTE-INTEGRACAO.
        
        DATA DIVISION.
        WORKING-STORAGE SECTION.
        01 WS-STATUS PIC X(10) VALUE 'ATIVO'.
        
        PROCEDURE DIVISION.
            DISPLAY 'SISTEMA INTEGRADO FUNCIONANDO'.
            DISPLAY 'STATUS: ' WS-STATUS.
            STOP RUN.
        """)
    
    # Configuração personalizada
    config = {
        'modelo': 'enhanced_mock',
        'detalhado': True
    }
    
    # Usar a função
    resultado = analisar_cobol_no_meu_sistema(arquivo_teste, config)
    
    print(f"📊 Resultado da integração:")
    print(f"   Status: {resultado.get('status', 'N/A')}")
    if resultado.get('status') == 'sucesso':
        print(f"   Arquivos gerados: {resultado.get('arquivos_gerados', 0)}")
    
    # Limpar
    if Path(arquivo_teste).exists():
        Path(arquivo_teste).unlink()
    
    return resultado.get('status') == 'sucesso'

def main():
    """Executa todos os exemplos"""
    
    print("🎯 EXEMPLOS DE USO APÓS PIP INSTALL")
    print("=" * 50)
    print("Pré-requisito: pip install cobol-to-docs")
    print("=" * 50)
    
    exemplos = [
        ("Uso Simples", exemplo_uso_simples),
        ("Uso Direto Python", exemplo_uso_direto_python),
        ("Integração Script", exemplo_integracao_script)
    ]
    
    sucessos = 0
    
    for nome, exemplo in exemplos:
        print(f"\n{'='*20} {nome} {'='*20}")
        try:
            if exemplo():
                sucessos += 1
                print(f"✅ {nome}: SUCESSO")
            else:
                print(f"❌ {nome}: FALHOU")
        except Exception as e:
            print(f"❌ {nome}: ERRO - {e}")
    
    print(f"\n🎉 RESUMO FINAL")
    print(f"✅ Sucessos: {sucessos}/{len(exemplos)}")
    
    if sucessos == len(exemplos):
        print("🎊 Todos os exemplos funcionaram!")
    else:
        print("⚠️  Alguns exemplos falharam - verifique a instalação")
    
    print("\n💡 PRÓXIMOS PASSOS:")
    print("1. Adapte os exemplos para seu caso de uso")
    print("2. Integre com seus sistemas existentes")
    print("3. Personalize configurações conforme necessário")

if __name__ == "__main__":
    main()
