# Guia de Uso Completo - COBOL Analyzer v3.1.0

## Todas as Formas de Uso da Aplicação

### Visão Geral dos Métodos de Uso

O COBOL Analyzer oferece três formas principais de uso:

1. **main.py** - Método original e mais completo
2. **cli.py** - Interface CLI simplificada
3. **cobol-analyzer** - Comando instalado via pip

### 1. Uso via main.py (Método Principal)

#### Sintaxe Básica
```bash
python3 main.py [OPÇÕES] --fontes ARQUIVO_FONTES
```

#### Exemplos Básicos
```bash
# Análise simples
python3 main.py --fontes examples/fontes.txt

# Com modelo específico
python3 main.py --fontes examples/fontes.txt --models enhanced_mock

# Com copybooks
python3 main.py --fontes examples/fontes.txt --books examples/books.txt

# Especificar diretório de saída
python3 main.py --fontes examples/fontes.txt --output minha_analise
```

#### Análises Especializadas
```bash
# Análise consolidada (todos os programas juntos)
python3 main.py --fontes examples/fontes.txt --consolidado

# Análise especializada (técnica profunda)
python3 main.py --fontes examples/fontes.txt --analise-especialista

# Análise de procedures detalhada
python3 main.py --fontes examples/fontes.txt --procedure-detalhada

# Análise de modernização
python3 main.py --fontes examples/fontes.txt --modernizacao

# Análise profunda de regras de negócio
python3 main.py --fontes examples/fontes.txt --deep-analysis

# Extração de fórmulas matemáticas
python3 main.py --fontes examples/fontes.txt --extract-formulas
```

#### Múltiplos Modelos
```bash
# Modelo único
python3 main.py --fontes examples/fontes.txt --models enhanced_mock

# Múltiplos modelos (JSON)
python3 main.py --fontes examples/fontes.txt --models '["enhanced_mock", "gpt-4"]'

# Seleção automática de modelo
python3 main.py --fontes examples/fontes.txt --auto-model

# Comparação de modelos
python3 main.py --fontes examples/fontes.txt --model-comparison
```

#### Relatórios Avançados
```bash
# Relatório único consolidado
python3 main.py --fontes examples/fontes.txt --relatorio-unico

# Análise avançada com HTML
python3 main.py --fontes examples/fontes.txt --advanced-analysis

# Gerar PDFs
python3 main.py --fontes examples/fontes.txt --pdf

# Análise sem comentários
python3 main.py --fontes examples/fontes.txt --no-comments
```

#### Configurações e Debugging
```bash
# Conjunto de prompts específico
python3 main.py --fontes examples/fontes.txt --prompt-set especialista

# Nível de log detalhado
python3 main.py --fontes examples/fontes.txt --log-level DEBUG

# Verificar status dos provedores
python3 main.py --status
```

### 2. Uso via cli.py (Interface Simplificada)

#### Sintaxe
```bash
python3 cli.py [TODAS_AS_OPÇÕES_DO_MAIN.PY]
```

#### Exemplos
```bash
# Funciona exatamente como main.py
python3 cli.py --fontes examples/fontes.txt --models enhanced_mock

# Análise consolidada
python3 cli.py --fontes examples/fontes.txt --consolidado

# Com todas as opções
python3 cli.py --fontes examples/fontes.txt --books examples/books.txt --analise-especialista --pdf
```

### 3. Uso via Comando Instalado (pip install)

#### Após Instalação
```bash
# Instalar primeiro
pip install .

# Usar scripts instalados
main.py --fontes examples/fontes.txt --models enhanced_mock
cli.py --fontes examples/fontes.txt --models enhanced_mock
```

#### Exemplos com Scripts Instalados
```bash
# Análise básica
main.py --fontes examples/fontes.txt
cli.py --fontes examples/fontes.txt

# Análise consolidada
main.py --fontes examples/fontes.txt --consolidado
cli.py --fontes examples/fontes.txt --consolidado

# Status
main.py --status
cli.py --status
```

## Parâmetros Detalhados

### Parâmetros Obrigatórios

| Parâmetro | Descrição | Exemplo |
|-----------|-----------|---------|
| `--fontes` | Arquivo com lista de programas COBOL | `--fontes programas.txt` |

### Parâmetros Opcionais Principais

| Parâmetro | Descrição | Padrão | Exemplo |
|-----------|-----------|--------|---------|
| `--books` | Arquivo com copybooks | Nenhum | `--books copybooks.txt` |
| `--output` | Diretório de saída | `output` | `--output resultado` |
| `--models` | Modelos de IA | `enhanced_mock` | `--models gpt-4` |
| `--prompt-set` | Conjunto de prompts | `default` | `--prompt-set especialista` |
| `--log-level` | Nível de log | `INFO` | `--log-level DEBUG` |

### Parâmetros de Análise

| Parâmetro | Descrição | Uso |
|-----------|-----------|-----|
| `--consolidado` | Análise sistêmica de todos os programas | Análise de sistema completo |
| `--relatorio-unico` | Relatório único consolidado | Visão geral do sistema |
| `--analise-especialista` | Análise técnica profunda | Análise detalhada |
| `--procedure-detalhada` | Foco na PROCEDURE DIVISION | Análise de lógica |
| `--modernizacao` | Análise de modernização | Planejamento de migração |
| `--deep-analysis` | Análise profunda de regras | Extração de regras de negócio |
| `--extract-formulas` | Extração de fórmulas | Identificação de cálculos |
| `--advanced-analysis` | Relatório HTML profissional | Apresentação executiva |

### Parâmetros de Saída

| Parâmetro | Descrição | Uso |
|-----------|-----------|-----|
| `--pdf` | Gerar relatórios PDF | Documentação formal |
| `--no-comments` | Remover comentários | Código limpo |

### Parâmetros de Modelo

| Parâmetro | Descrição | Uso |
|-----------|-----------|-----|
| `--auto-model` | Seleção automática | Otimização automática |
| `--model-comparison` | Comparação de modelos | Avaliação de qualidade |

### Parâmetros de Sistema

| Parâmetro | Descrição | Uso |
|-----------|-----------|-----|
| `--status` | Status dos provedores | Diagnóstico |

## Formatos de Arquivo

### Arquivo de Fontes (--fontes)

#### Formato Simples
```
programa1.cbl
programa2.cbl
programa3.cbl
```

#### Formato Detalhado
```
PROGRAMA: LHAN0542
IDENTIFICACAO: Sistema de Validação
CODIGO:
       IDENTIFICATION DIVISION.
       PROGRAM-ID. LHAN0542.
       ...

PROGRAMA: LHAN0543
IDENTIFICACAO: Processamento de Contas
CODIGO:
       IDENTIFICATION DIVISION.
       PROGRAM-ID. LHAN0543.
       ...
```

### Arquivo de Copybooks (--books)

#### Formato Simples
```
copy1.cpy
copy2.cpy
```

#### Formato Detalhado
```
COPYBOOK: CONTA-LAYOUT
CODIGO:
       01  WS-CONTA-REGISTRO.
           05  WS-CONTA-NUMERO    PIC 9(10).
           05  WS-CONTA-DIGITO    PIC 9(01).

COPYBOOK: CLIENTE-LAYOUT
CODIGO:
       01  WS-CLIENTE-REGISTRO.
           05  WS-CLIENTE-CODIGO  PIC 9(08).
           05  WS-CLIENTE-NOME    PIC X(40).
```

## Modelos de IA Disponíveis

### Modelos Gratuitos/Mock
- `enhanced_mock` - Simulador para testes (não requer API)
- `basic-fallback` - Fallback básico

### Modelos OpenAI
- `gpt-4` - GPT-4 padrão
- `gpt-4-turbo-preview` - GPT-4 Turbo
- `gpt-3.5-turbo` - GPT-3.5 Turbo

### Modelos AWS Bedrock
- `aws-claude-3-5-sonnet` - Claude 3.5 Sonnet
- `aws-claude-3-5-haiku` - Claude 3.5 Haiku
- `amazon-nova-pro-v1` - Amazon Nova Pro

### Modelos Azure
- `azure-gpt-4o-exp` - GPT-4o Experimental

### Modelos Databricks
- `databricks-dbrx-instruct` - DBRX Instruct

## Exemplos de Uso Completos

### Exemplo 1: Análise Básica
```bash
# Preparar arquivos
echo "programa1.cbl" > meus_programas.txt

# Executar análise
python3 main.py --fontes meus_programas.txt --models enhanced_mock --output analise_basica

# Verificar resultados
ls analise_basica/
```

### Exemplo 2: Análise Consolidada de Sistema
```bash
# Preparar lista de programas
cat > sistema_bancario.txt << EOF
LHAN0542.cbl
LHAN0543.cbl
LHAN0544.cbl
EOF

# Executar análise consolidada
python3 main.py --fontes sistema_bancario.txt --consolidado --models enhanced_mock --output sistema_completo

# Verificar análise sistêmica
cat sistema_completo/analise_consolidada_*.md
```

### Exemplo 3: Análise com Copybooks
```bash
# Preparar copybooks
cat > copybooks.txt << EOF
CONTA-LAYOUT.cpy
CLIENTE-LAYOUT.cpy
EOF

# Análise completa
python3 main.py --fontes programas.txt --books copybooks.txt --analise-especialista --output analise_completa
```

### Exemplo 4: Comparação de Modelos
```bash
# Comparar múltiplos modelos
python3 main.py --fontes programas.txt --models '["enhanced_mock", "gpt-4"]' --model-comparison --output comparacao

# Ver relatório comparativo
cat comparacao/relatorio_comparativo_*.md
```

### Exemplo 5: Análise de Modernização
```bash
# Análise focada em modernização
python3 main.py --fontes sistema_legado.txt --modernizacao --advanced-analysis --pdf --output modernizacao

# Relatórios gerados:
# - Análise de modernização
# - Recomendações de migração
# - Relatório HTML/PDF
```

### Exemplo 6: Análise Profunda de Negócio
```bash
# Extração detalhada de regras
python3 main.py --fontes programas_negocio.txt --deep-analysis --extract-formulas --output regras_negocio

# Resultados:
# - Regras de negócio identificadas
# - Fórmulas matemáticas extraídas
# - Documentação funcional
```

## Configuração Avançada

### Arquivo de Configuração Local
```bash
# Criar configuração personalizada
cp config/config.yaml config/config_local.yaml

# Editar configurações
nano config/config_local.yaml
```

### Configuração de Modelos
```yaml
models:
  default: "enhanced_mock"
  fallback: ["gpt-4", "aws-claude-3-5-sonnet"]
  temperature: 0.1
  max_tokens: 8000
```

### Configuração RAG
```yaml
rag:
  enabled: true
  max_context_items: 10
  similarity_threshold: 0.7
  auto_learning: true
```

## Solução de Problemas por Uso

### Problemas com main.py
```bash
# Erro de módulo
export PYTHONPATH=$PYTHONPATH:$(pwd)/src
python3 main.py --help

# Erro de dependência
pip3 install -r requirements.txt --force-reinstall
```

### Problemas com cli.py
```bash
# Mesmo que main.py, pois cli.py chama main.py
python3 cli.py --help
```

### Problemas com comando instalado
```bash
# Reinstalar pacote
pip uninstall cobol-analyzer
pip install .

# Verificar instalação
which cobol-analyzer
cobol-analyzer --help
```

## Dicas de Performance

### Para Arquivos Grandes
```bash
# Usar modelo mais rápido
python3 main.py --fontes arquivos_grandes.txt --models enhanced_mock

# Remover comentários para reduzir tokens
python3 main.py --fontes arquivos_grandes.txt --no-comments
```

### Para Análise em Lote
```bash
# Processamento otimizado
python3 main.py --fontes lote_programas.txt --consolidado --models enhanced_mock
```

### Para Desenvolvimento
```bash
# Usar ambiente virtual
python3 -m venv dev_env
source dev_env/bin/activate
pip install -r requirements.txt
python3 main.py --fontes test.txt --models enhanced_mock --log-level DEBUG
```

---

**Este guia cobre todas as formas de uso do COBOL Analyzer v3.1.0**

Para mais informações, consulte:
- `README.md` - Visão geral
- `MANUAL_INSTALACAO.md` - Instalação detalhada
- `python3 main.py --help` - Ajuda da aplicação
