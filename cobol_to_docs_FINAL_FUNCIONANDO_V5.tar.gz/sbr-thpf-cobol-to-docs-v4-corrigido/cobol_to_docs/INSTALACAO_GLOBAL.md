# Instalação Global do COBOL Analyzer

Este guia mostra como instalar o COBOL Analyzer como um comando global do sistema, permitindo usar `cobol-docs` de qualquer diretório.

## Instalação Rápida

```bash
# 1. Extrair o pacote
tar -xzf COBOL_ANALYZER_v3.1.0_CORRIGIDO_FINAL.tar.gz
cd cobol_analyzer_EXCELENCIA

# 2. Instalar dependências
pip install pyyaml numpy scikit-learn

# 3. Instalar comando global
python3 install_global.py

# 4. Adicionar ao PATH (se necessário)
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc
source ~/.bashrc
```

## Uso do Comando Global

Após a instalação, você pode usar o comando `cobol-docs` de qualquer diretório:

```bash
# Verificar se está funcionando
cobol-docs --help

# Análise básica
cobol-docs --fontes /caminho/para/fontes.txt --models enhanced_mock

# Análise consolidada
cobol-docs --fontes /caminho/para/fontes.txt --consolidado --models enhanced_mock

# Análise com copybooks
cobol-docs --fontes /caminho/para/fontes.txt --books /caminho/para/books.txt --models enhanced_mock

# Verificar status dos provedores
cobol-docs --status
```

## Funcionalidades Disponíveis

O comando `cobol-docs` tem acesso a **todas** as funcionalidades da aplicação:

- ✅ Análise individual e consolidada de programas COBOL
- ✅ Sistema RAG com auto-learning
- ✅ Múltiplos provedores de IA (OpenAI, AWS Claude, Mock, etc.)
- ✅ Análise especializada e de modernização
- ✅ Geração de documentação no padrão DOC-LEGADO PRO
- ✅ Relatórios HTML/PDF
- ✅ Análise de procedures detalhada
- ✅ Extração de fórmulas e cálculos
- ✅ Análise avançada com relatórios consolidados
- ✅ Sistema de custos e logs detalhados
- ✅ Base de conhecimento dinâmica

## Opções de Linha de Comando

```bash
cobol-docs [OPÇÕES]

Opções principais:
  --fontes ARQUIVO          Arquivo com lista de programas COBOL
  --books ARQUIVO           Arquivo com lista de copybooks COBOL
  --output DIRETÓRIO        Diretório de saída (padrão: output)
  --models MODELOS          Modelos de IA a usar
  --consolidado             Análise consolidada de todos os programas
  --analise-especialista    Análise técnica profunda
  --procedure-detalhada     Foco na PROCEDURE DIVISION
  --modernizacao           Análise de modernização e migração
  --pdf                    Gerar relatórios HTML/PDF
  --status                 Verificar status dos provedores
```

## Exemplos Práticos

### Análise Básica
```bash
# Criar arquivo de fontes
echo "PROGRAMA1.CBL" > meus_programas.txt
echo "PROGRAMA2.CBL" >> meus_programas.txt

# Executar análise
cobol-docs --fontes meus_programas.txt --models enhanced_mock
```

### Análise Consolidada com Copybooks
```bash
# Análise completa do sistema
cobol-docs --fontes sistema_fontes.txt \
           --books sistema_books.txt \
           --consolidado \
           --models enhanced_mock \
           --output relatorio_sistema
```

### Análise de Modernização
```bash
# Análise focada em modernização
cobol-docs --fontes legado_fontes.txt \
           --modernizacao \
           --analise-especialista \
           --models enhanced_mock
```

## Desinstalação

Para remover o comando global:

```bash
cd cobol_analyzer_EXCELENCIA
python3 install_global.py uninstall
```

## Solução de Problemas

### Comando não encontrado
Se o comando `cobol-docs` não for encontrado:

1. Verifique se o PATH foi atualizado:
   ```bash
   echo $PATH | grep ".local/bin"
   ```

2. Adicione manualmente ao PATH:
   ```bash
   export PATH="$HOME/.local/bin:$PATH"
   ```

3. Torne permanente:
   ```bash
   echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc
   source ~/.bashrc
   ```

### Erro de dependências
Se houver erro de módulos não encontrados:

```bash
pip install pyyaml numpy scikit-learn requests jinja2 markdown
```

### Erro de permissão
Se houver erro de permissão durante a instalação:

```bash
# Instalar no diretório do usuário (recomendado)
python3 install_global.py

# Ou instalar globalmente (requer sudo)
sudo python3 install_global.py
```

## Vantagens da Instalação Global

- ✅ Comando disponível em qualquer diretório
- ✅ Não precisa navegar até o diretório da aplicação
- ✅ Integração fácil com scripts e automações
- ✅ Experiência de uso similar a ferramentas profissionais
- ✅ Todas as funcionalidades preservadas
- ✅ Performance otimizada

## Suporte

Para problemas ou dúvidas:

1. Verifique se todas as dependências estão instaladas
2. Execute `cobol-docs --status` para verificar os provedores
3. Consulte os logs em `logs/` para diagnóstico detalhado
4. Use `python3 main.py` diretamente como alternativa
