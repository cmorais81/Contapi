#!/usr/bin/env python3
"""
Script para corrigir a instalação do COBOL Analyzer
Garante que o comando cobol-to-docs use o arquivo correto com suporte a --init
"""

import os
import sys
import shutil
import subprocess
from pathlib import Path

def fix_entry_point():
    """Corrige o entry point do cobol-to-docs"""
    
    # Encontrar o script instalado
    script_path = shutil.which('cobol-to-docs')
    if not script_path:
        print("❌ Comando cobol-to-docs não encontrado")
        return False
    
    print(f"📍 Script encontrado em: {script_path}")
    
    # Criar novo conteúdo do script
    new_content = '''#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys
import os
import subprocess
from pathlib import Path

def main():
    """Entry point corrigido para COBOL Analyzer v3.1.0"""
    
    # Verificar se é comando --init
    if '--init' in sys.argv:
        # Encontrar main_enhanced.py
        script_dir = Path(__file__).parent
        
        # Procurar em locais possíveis
        possible_locations = [
            script_dir / "main_enhanced.py",
            Path.cwd() / "main_enhanced.py",
            Path("/usr/local/lib/python3.11/site-packages/main_enhanced.py"),
            Path("/home/ubuntu/cobol_analyzer_EXCELENCIA/main_enhanced.py")
        ]
        
        for main_enhanced in possible_locations:
            if main_enhanced.exists():
                # Substituir --init por --init-local
                args = [arg if arg != '--init' else '--init-local' for arg in sys.argv[1:]]
                cmd = [sys.executable, str(main_enhanced)] + args
                result = subprocess.run(cmd, check=False)
                sys.exit(result.returncode)
        
        print("❌ Erro: main_enhanced.py não encontrado")
        print("💡 Tente executar: python /home/ubuntu/cobol_analyzer_EXCELENCIA/main_enhanced.py --init-local")
        sys.exit(1)
    
    # Para outros comandos, usar main.py original
    try:
        from main import main as main_func
        main_func()
    except ImportError:
        # Fallback para execução direta
        script_dir = Path(__file__).parent
        main_py = script_dir / "main.py"
        
        if not main_py.exists():
            main_py = Path("/home/ubuntu/cobol_analyzer_EXCELENCIA/main.py")
        
        if main_py.exists():
            cmd = [sys.executable, str(main_py)] + sys.argv[1:]
            result = subprocess.run(cmd, check=False)
            sys.exit(result.returncode)
        else:
            print("❌ Erro: main.py não encontrado")
            sys.exit(1)

if __name__ == "__main__":
    main()
'''
    
    try:
        # Fazer backup do script original
        backup_path = script_path + ".backup"
        shutil.copy2(script_path, backup_path)
        print(f"💾 Backup criado: {backup_path}")
        
        # Escrever novo conteúdo
        with open(script_path, 'w') as f:
            f.write(new_content)
        
        # Tornar executável
        os.chmod(script_path, 0o755)
        
        print("✅ Entry point corrigido com sucesso!")
        return True
        
    except Exception as e:
        print(f"❌ Erro ao corrigir entry point: {e}")
        return False

def test_installation():
    """Testa se a instalação está funcionando"""
    
    print("\n🧪 Testando instalação...")
    
    # Teste 1: Comando básico
    try:
        result = subprocess.run(['cobol-to-docs', '--help'], 
                              capture_output=True, text=True, timeout=10)
        if result.returncode == 0:
            print("✅ Comando básico funcionando")
        else:
            print("❌ Comando básico falhou")
            return False
    except Exception as e:
        print(f"❌ Erro no teste básico: {e}")
        return False
    
    # Teste 2: Comando --init
    test_dir = Path("/tmp/test_cobol_init")
    test_dir.mkdir(exist_ok=True)
    
    try:
        os.chdir(str(test_dir))
        result = subprocess.run(['cobol-to-docs', '--init'], 
                              capture_output=True, text=True, timeout=30)
        
        if result.returncode == 0:
            print("✅ Comando --init funcionando")
            
            # Verificar se diretórios foram criados
            expected_dirs = ['config', 'data', 'logs', 'examples']
            created = all((test_dir / d).exists() for d in expected_dirs)
            
            if created:
                print("✅ Diretórios criados corretamente")
                return True
            else:
                print("❌ Diretórios não foram criados")
                return False
        else:
            print(f"❌ Comando --init falhou: {result.stderr}")
            return False
            
    except Exception as e:
        print(f"❌ Erro no teste --init: {e}")
        return False
    finally:
        # Limpar diretório de teste
        try:
            shutil.rmtree(str(test_dir))
        except:
            pass

def main():
    """Função principal"""
    
    print("🔧 COBOL Analyzer - Correção de Instalação v3.1.0")
    print("=" * 50)
    
    # Verificar se está instalado
    if not shutil.which('cobol-to-docs'):
        print("❌ COBOL Analyzer não está instalado")
        print("💡 Execute: pip install .")
        return 1
    
    # Corrigir entry point
    if not fix_entry_point():
        return 1
    
    # Testar instalação
    if not test_installation():
        print("\n❌ Testes falharam")
        print("💡 Tente executar manualmente:")
        print("   python /home/ubuntu/cobol_analyzer_EXCELENCIA/main_enhanced.py --init-local")
        return 1
    
    print("\n🎉 Instalação corrigida com sucesso!")
    print("💡 Agora você pode usar: cobol-to-docs --init")
    
    return 0

if __name__ == "__main__":
    sys.exit(main())
