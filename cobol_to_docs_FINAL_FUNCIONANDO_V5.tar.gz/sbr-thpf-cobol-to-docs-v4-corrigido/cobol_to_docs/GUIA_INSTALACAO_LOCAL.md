# Guia de Instalação Local - COBOL Analyzer v3.1.0

## Para Máquinas Locais (Windows, Mac, Linux)

### Método 1: Instalação Automática (Recomendado)

```bash
# 1. Baixar e extrair o pacote
tar -xzf COBOL_ANALYZER_v3.1.0_INSTALACAO_LOCAL_FINAL.tar.gz
cd cobol_analyzer_EXCELENCIA/

# 2. Executar instalador automático
python install_simples.py

# 3. Testar instalação
cobol-to-docs --init
```

### Método 2: Instalação Manual

```bash
# 1. Extrair pacote
tar -xzf COBOL_ANALYZER_v3.1.0_INSTALACAO_LOCAL_FINAL.tar.gz
cd cobol_analyzer_EXCELENCIA/

# 2. Instalar via pip
pip install .

# 3. Corrigir entry point (se necessário)
python fix_install.py

# 4. Testar
cobol-to-docs --init
```

### Método 3: Execução Direta (Sem Instalação)

```bash
# 1. Extrair pacote
tar -xzf COBOL_ANALYZER_v3.1.0_INSTALACAO_LOCAL_FINAL.tar.gz
cd cobol_analyzer_EXCELENCIA/

# 2. Usar diretamente
python main_enhanced.py --init-local

# 3. Para análises
python main_enhanced.py --fontes fontes.txt
```

## Requisitos

### Sistema Operacional
- ✅ Linux (Ubuntu, CentOS, etc.)
- ✅ macOS (10.14+)
- ✅ Windows (10+)

### Python
- ✅ Python 3.8+
- ✅ pip instalado

### Dependências (instaladas automaticamente)
- pyyaml>=6.0
- requests>=2.28.0
- numpy>=1.21.0
- scikit-learn>=1.0.0
- jinja2>=3.0.0
- markdown>=3.3.0

## Verificação da Instalação

### Teste Básico
```bash
# Verificar se comando está disponível
which cobol-to-docs

# Testar help
cobol-to-docs --help

# Testar inicialização
mkdir teste && cd teste
cobol-to-docs --init
```

### Resultado Esperado
```
teste/
├── .cobol_analyzer_init     # Arquivo de controle
├── config/                  # 8+ arquivos de configuração
├── data/                    # 7+ arquivos base conhecimento
├── logs/                    # Diretório de logs
└── examples/                # Exemplos prontos
```

## Solução de Problemas

### Problema: "cobol-to-docs: command not found"

**Solução 1**: Usar instalador automático
```bash
python install_simples.py
```

**Solução 2**: Adicionar ao PATH
```bash
# Linux/Mac
export PATH=$PATH:/usr/local/bin
echo 'export PATH=$PATH:/usr/local/bin' >> ~/.bashrc

# Windows
# Adicionar C:\Python\Scripts ao PATH do sistema
```

**Solução 3**: Execução direta
```bash
python main_enhanced.py --init-local
```

### Problema: "Permission denied"

**Solução**: Instalar no diretório do usuário
```bash
pip install --user .
# Comando ficará em ~/.local/bin/cobol-to-docs
```

### Problema: "Module not found"

**Solução**: Instalar dependências
```bash
pip install pyyaml requests numpy scikit-learn jinja2 markdown
```

### Problema: "--init not recognized"

**Solução**: Executar correção
```bash
python fix_install.py
```

## Estrutura de Arquivos

### Após Instalação Bem-Sucedida
```
/usr/local/bin/cobol-to-docs              # Comando principal
/usr/local/lib/python3.x/dist-packages/  # Arquivos do pacote
├── main_enhanced.py                      # Motor principal
├── config/                               # Configurações padrão
├── data/                                 # Base conhecimento RAG
└── src/                                  # Código fonte
```

### Após `cobol-to-docs --init`
```
projeto/
├── .cobol_analyzer_init                  # Controle
├── config/                               # Configurações locais
│   ├── config.yaml                       # Config principal
│   ├── config_enhanced.yaml              # Config v3.1.0
│   └── prompts_*.yaml                    # Prompts especializados
├── data/                                 # Base conhecimento local
│   ├── cobol_knowledge_base*.json        # Bases de conhecimento
│   ├── embeddings/                       # Cache embeddings
│   └── sessions/                         # Sessões RAG
├── logs/                                 # Logs do sistema
└── examples/                             # Exemplos prontos
    ├── fontes.txt                        # Lista programas
    ├── books.txt                         # Lista copybooks
    └── PROGRAMA_EXEMPLO.CBL              # Programa exemplo
```

## Comandos Disponíveis

### Inicialização
```bash
# Básica
cobol-to-docs --init

# Personalizada
cobol-to-docs --init --config-dir ./config --data-dir ./data

# Forçar reinicialização
cobol-to-docs --init --force-init
```

### Análise
```bash
# Análise básica
cobol-to-docs --fontes fontes.txt

# Com copybooks
cobol-to-docs --fontes fontes.txt --books books.txt

# Análise consolidada
cobol-to-docs --fontes fontes.txt --consolidado

# Análise avançada
cobol-to-docs --fontes fontes.txt --advanced-analysis
```

### Utilitários
```bash
# Verificar status
cobol-to-docs --status

# Mostrar caminhos
cobol-to-docs --show-paths

# Ajuda completa
cobol-to-docs --help
```

## Exemplos de Uso

### Projeto Novo
```bash
# 1. Criar diretório
mkdir meu_projeto_cobol && cd meu_projeto_cobol

# 2. Inicializar
cobol-to-docs --init

# 3. Adicionar programas
echo "PROGRAMA1.CBL" > fontes.txt
echo "PROGRAMA2.CBL" >> fontes.txt

# 4. Analisar
cobol-to-docs --fontes fontes.txt --consolidado
```

### Projeto Corporativo
```bash
# Configuração corporativa
cobol-to-docs --init \
  --config-dir /etc/cobol_analyzer \
  --data-dir /var/lib/cobol_analyzer \
  --logs-dir /var/log/cobol_analyzer

# Análise de sistema
cobol-to-docs --fontes sistema_fontes.txt \
  --books sistema_books.txt \
  --config-dir /etc/cobol_analyzer \
  --consolidado --advanced-analysis
```

### Múltiplos Projetos
```bash
# Projeto A
mkdir projeto_a && cd projeto_a
cobol-to-docs --init --config-dir ./config_a
cobol-to-docs --fontes fontes_a.txt

# Projeto B
cd ../projeto_b
cobol-to-docs --init --config-dir ./config_b
cobol-to-docs --fontes fontes_b.txt
```

## Desinstalação

### Remover Pacote
```bash
pip uninstall cobol-to-docs
```

### Remover Comando
```bash
sudo rm /usr/local/bin/cobol-to-docs
```

### Limpar Dados (Opcional)
```bash
# Remover configurações globais
rm -rf ~/.cobol_analyzer

# Remover dados de projetos (cuidado!)
# rm -rf */config */data */logs
```

## Suporte

### Logs de Diagnóstico
```bash
# Verificar logs
ls -la logs/cobol_to_docs_*.log

# Ver últimas entradas
tail -f logs/cobol_to_docs_*.log
```

### Informações do Sistema
```bash
# Versão Python
python --version

# Pacotes instalados
pip list | grep cobol

# Localização do comando
which cobol-to-docs
```

### Teste Completo
```bash
# Script de teste
#!/bin/bash
echo "=== Teste de Instalação ==="
which cobol-to-docs && echo "✅ Comando encontrado" || echo "❌ Comando não encontrado"
cobol-to-docs --help > /dev/null && echo "✅ Help funcionando" || echo "❌ Help falhou"

mkdir test_install && cd test_install
cobol-to-docs --init && echo "✅ Init funcionando" || echo "❌ Init falhou"
[ -d "config" ] && echo "✅ Config criado" || echo "❌ Config não criado"
[ -d "data" ] && echo "✅ Data criado" || echo "❌ Data não criado"
cd .. && rm -rf test_install
echo "=== Teste Concluído ==="
```

---

**Versão**: 3.1.0  
**Data**: Outubro 2025  
**Compatibilidade**: Python 3.8+ em Linux, macOS, Windows  
**Status**: Testado e Validado
