#!/usr/bin/env python3
"""
Script de Instalação Global do COBOL Analyzer
Instala o comando cobol-docs como um executável global do sistema
"""

import os
import sys
import shutil
import stat
from pathlib import Path

def create_global_script():
    """Cria o script global cobol-docs"""
    
    # Obter o diretório atual da aplicação
    app_dir = Path(__file__).parent.absolute()
    
    # Conteúdo do script global
    script_content = f'''#!/usr/bin/env python3
"""
COBOL Docs - Comando Global
Ferramenta de análise de código COBOL com IA
"""

import sys
import os
import subprocess
from pathlib import Path

# Diretório da aplicação COBOL Analyzer
APP_DIR = Path("{app_dir}")

def main():
    """Função principal do comando cobol-docs"""
    try:
        # Verificar se o diretório da aplicação existe
        if not APP_DIR.exists():
            print(f"Erro: Diretório da aplicação não encontrado: {{APP_DIR}}")
            print("Execute novamente o script de instalação.")
            return 1
        
        # Mudar para o diretório da aplicação
        original_cwd = os.getcwd()
        os.chdir(str(APP_DIR))
        
        try:
            # Executar o main.py
            cmd = [sys.executable, "main.py"] + sys.argv[1:]
            result = subprocess.call(cmd)
            return result
        finally:
            # Voltar ao diretório original
            os.chdir(original_cwd)
            
    except Exception as e:
        print(f"Erro ao executar COBOL Analyzer: {{e}}")
        print("\\nTente executar diretamente:")
        print(f"  cd {{APP_DIR}}")
        print("  python3 main.py --help")
        return 1

if __name__ == '__main__':
    sys.exit(main())
'''
    
    return script_content

def install_global():
    """Instala o comando cobol-docs globalmente"""
    
    print("🚀 Instalando COBOL Analyzer como comando global...")
    
    # Criar o script
    script_content = create_global_script()
    
    # Diretórios possíveis para instalação
    possible_dirs = [
        Path.home() / ".local" / "bin",  # Usuário local
        Path("/usr/local/bin"),          # Sistema (requer sudo)
        Path("/usr/bin"),                # Sistema (requer sudo)
    ]
    
    # Tentar instalar no diretório do usuário primeiro
    install_dir = None
    for dir_path in possible_dirs:
        try:
            # Criar diretório se não existir
            dir_path.mkdir(parents=True, exist_ok=True)
            
            # Testar se podemos escrever
            test_file = dir_path / "test_write"
            test_file.write_text("test")
            test_file.unlink()
            
            install_dir = dir_path
            break
            
        except (PermissionError, OSError):
            continue
    
    if not install_dir:
        print("❌ Erro: Não foi possível encontrar um diretório de instalação adequado.")
        print("\nTente executar com sudo:")
        print("  sudo python3 install_global.py")
        return False
    
    # Instalar o script
    script_path = install_dir / "cobol-docs"
    
    try:
        # Escrever o script
        script_path.write_text(script_content)
        
        # Tornar executável
        script_path.chmod(script_path.stat().st_mode | stat.S_IEXEC)
        
        print(f"✅ Comando 'cobol-docs' instalado em: {script_path}")
        
        # Verificar se o diretório está no PATH
        path_dirs = os.environ.get('PATH', '').split(':')
        if str(install_dir) not in path_dirs:
            print(f"\n⚠️  ATENÇÃO: Adicione {install_dir} ao seu PATH:")
            print(f"  echo 'export PATH=\"{install_dir}:$PATH\"' >> ~/.bashrc")
            print("  source ~/.bashrc")
        
        print(f"\n🎉 Instalação concluída! Agora você pode usar:")
        print("  cobol-docs --help")
        print("  cobol-docs --fontes examples/fontes.txt --models enhanced_mock")
        
        return True
        
    except Exception as e:
        print(f"❌ Erro ao instalar: {e}")
        return False

def uninstall_global():
    """Remove o comando cobol-docs do sistema"""
    
    print("🗑️  Removendo COBOL Analyzer...")
    
    # Diretórios possíveis onde pode estar instalado
    possible_dirs = [
        Path.home() / ".local" / "bin",
        Path("/usr/local/bin"),
        Path("/usr/bin"),
    ]
    
    removed = False
    for dir_path in possible_dirs:
        script_path = dir_path / "cobol-docs"
        if script_path.exists():
            try:
                script_path.unlink()
                print(f"✅ Removido: {script_path}")
                removed = True
            except Exception as e:
                print(f"❌ Erro ao remover {script_path}: {e}")
    
    if not removed:
        print("ℹ️  Comando 'cobol-docs' não encontrado no sistema.")
    else:
        print("🎉 Desinstalação concluída!")

def main():
    """Função principal"""
    
    if len(sys.argv) > 1 and sys.argv[1] == "uninstall":
        uninstall_global()
    else:
        # Verificar dependências
        try:
            import yaml
            import numpy
            import sklearn
        except ImportError as e:
            print(f"❌ Dependência faltando: {e}")
            print("\nInstale as dependências:")
            print("  pip install pyyaml numpy scikit-learn")
            return 1
        
        install_global()

if __name__ == '__main__':
    main()
