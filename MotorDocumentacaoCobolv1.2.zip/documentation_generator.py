"""
Gerador de documentação Markdown.
Segue o padrão Template Method e princípios SOLID.
"""

import logging
from typing import Dict, Any, List, Optional
from datetime import datetime
from ...domain.entities.cobol_program import CobolProgram
from ...domain.entities.cobol_book import CobolBook
from ...domain.interfaces.documentation_generator import IDocumentationGenerator

class DocumentationGenerator(IDocumentationGenerator):
    """Gerador de documentação Markdown."""
    
    def __init__(self, logger: Optional[logging.Logger] = None):
        """
        Inicializa o gerador.
        
        Args:
            logger: Logger para registrar operações
        """
        self._logger = logger or logging.getLogger(__name__)
    
    def generate_enhanced_program_documentation(self, program: CobolProgram, ai_analyses: Dict[str, Any]) -> str:
        """
        Gera documentação melhorada com análises de IA.
        
        Args:
            program: Programa COBOL
            ai_analyses: Análises de IA por tipo
            
        Returns:
            Documentação em Markdown
        """
        
        content = f"""# Documentação do Programa {program.name}

**Data de Geração**: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}
**Versão do Sistema**: COBOL AI Engine v1.2.0
**Provedor de IA**: Enhanced Mock AI

---

"""
        
        # Adicionar cada análise de IA
        if 'summary' in ai_analyses:
            response = ai_analyses['summary']
            content += f"""## Análise de IA - Resumo Executivo

{response.content}

### Metadados da Análise
- **Provedor**: {response.provider}
- **Modelo**: {response.model}
- **Tokens Utilizados**: {response.tokens_used}
- **Timestamp**: {response.metadata.get('analysis_timestamp', 'N/A')}
- **Confiança**: {response.metadata.get('confidence_score', 0):.2%}

### Prompt Utilizado na Análise
```
{response.metadata.get('prompt_used', 'Prompt não disponível')}
```

---

"""
        
        if 'technical' in ai_analyses:
            response = ai_analyses['technical']
            content += f"""## Análise de IA - Documentação Técnica

{response.content}

### Metadados da Análise
- **Provedor**: {response.provider}
- **Modelo**: {response.model}
- **Tokens Utilizados**: {response.tokens_used}
- **Timestamp**: {response.metadata.get('analysis_timestamp', 'N/A')}
- **Confiança**: {response.metadata.get('confidence_score', 0):.2%}

### Prompt Utilizado na Análise
```
{response.metadata.get('prompt_used', 'Prompt não disponível')}
```

---

"""
        
        if 'functional' in ai_analyses:
            response = ai_analyses['functional']
            content += f"""## Análise de IA - Documentação Funcional

{response.content}

### Metadados da Análise
- **Provedor**: {response.provider}
- **Modelo**: {response.model}
- **Tokens Utilizados**: {response.tokens_used}
- **Timestamp**: {response.metadata.get('analysis_timestamp', 'N/A')}
- **Confiança**: {response.metadata.get('confidence_score', 0):.2%}

### Prompt Utilizado na Análise
```
{response.metadata.get('prompt_used', 'Prompt não disponível')}
```

---

"""
        
        if 'relationships' in ai_analyses:
            response = ai_analyses['relationships']
            content += f"""## Análise de IA - Relacionamentos e Dependências

{response.content}

### Metadados da Análise
- **Provedor**: {response.provider}
- **Modelo**: {response.model}
- **Tokens Utilizados**: {response.tokens_used}
- **Timestamp**: {response.metadata.get('analysis_timestamp', 'N/A')}
- **Confiança**: {response.metadata.get('confidence_score', 0):.2%}

### Prompt Utilizado na Análise
```
{response.metadata.get('prompt_used', 'Prompt não disponível')}
```

---

"""
        
        # Adicionar informações básicas do programa
        content += f"""## Informações Básicas do Programa

### Estrutura do Código
- **Nome**: {program.name}
- **Linhas de Código**: {len(program.source_lines)}
- **Tamanho**: {sum(len(line) for line in program.source_lines)} caracteres

### Divisões COBOL Identificadas
- **Identification Division**: Presente
- **Environment Division**: Presente  
- **Data Division**: Presente
- **Procedure Division**: Presente

### Análise Estrutural
- **Comentários**: {sum(1 for line in program.source_lines if line.strip().startswith('*'))} linhas
- **Statements PERFORM**: {sum(line.upper().count('PERFORM') for line in program.source_lines)}
- **Statements IF**: {sum(line.upper().count('IF ') for line in program.source_lines)}
- **Statements CALL**: {sum(line.upper().count('CALL') for line in program.source_lines)}

---

## Código Fonte (Primeiras 50 linhas)

```cobol
{chr(10).join(program.source_lines[:50])}
{'...' if len(program.source_lines) > 50 else ''}
```

---

*Documentação gerada automaticamente pelo COBOL AI Engine v1.2.0*
*Enhanced Mock AI Provider - Análise avançada com transparência total*
"""
        
        return content
    
    def generate_program_documentation(self, program: CobolProgram, ai_summary: Optional[str] = None) -> str:
        """
        Gera documentação básica do programa.
        
        Args:
            program: Programa COBOL
            ai_summary: Resumo gerado por IA (opcional)
            
        Returns:
            Documentação em Markdown
        """
        
        content = f"""# Documentação do Programa {program.name}

**Data de Geração**: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}

## Informações Básicas
- **Nome**: {program.name}
- **Linhas de Código**: {len(program.source_lines)}
- **Tamanho**: {sum(len(line) for line in program.source_lines)} caracteres

"""
        
        if ai_summary:
            content += f"""## Análise com IA

{ai_summary}

"""
        
        content += f"""## Estrutura do Código

### Divisões COBOL
- Identification Division
- Environment Division  
- Data Division
- Procedure Division

### Estatísticas
- **Comentários**: {sum(1 for line in program.source_lines if line.strip().startswith('*'))} linhas
- **PERFORM statements**: {sum(line.upper().count('PERFORM') for line in program.source_lines)}
- **IF statements**: {sum(line.upper().count('IF ') for line in program.source_lines)}

## Código Fonte (Primeiras 20 linhas)

```cobol
{chr(10).join(program.source_lines[:20])}
```

---

*Documentação gerada pelo COBOL AI Engine*
"""
        
        return content
    
    def generate_consolidated_report(self, programs: List[CobolProgram], books: List[CobolBook], 
                                   analysis_results: Dict[str, Any], ai_analysis: Dict[str, Any]) -> str:
        """
        Gera relatório consolidado.
        
        Args:
            programs: Lista de programas
            books: Lista de books
            analysis_results: Resultados da análise
            ai_analysis: Análise com IA
            
        Returns:
            Relatório em Markdown
        """
        
        content = f"""# Relatório Consolidado - Análise COBOL

**Data de Geração**: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}
**Sistema**: COBOL AI Engine

## Resumo Executivo

### Programas Processados
{len(programs)} programas COBOL analisados:
{chr(10).join([f"- {prog.name}" for prog in programs])}

### Books/Copybooks
{len(books)} books processados

### Sequência de Execução
{' → '.join(analysis_results.get('execution_sequence', []))}

## Relacionamentos Identificados

### Chamadas entre Programas
{chr(10).join([f"- {rel}" for rel in analysis_results.get('program_calls', [])])}

### Dependências de Copybooks
{chr(10).join([f"- {dep}" for dep in analysis_results.get('copybook_dependencies', [])])}

## Análise com IA

### Estatísticas
- **Análises realizadas**: {ai_analysis.get('total_analyses', 0)}
- **Taxa de sucesso**: {ai_analysis.get('success_rate', 0):.1f}%
- **Tokens utilizados**: {ai_analysis.get('total_tokens', 0)}

---

*Relatório gerado pelo COBOL AI Engine*
"""
        
        return content
    
    def generate_documentation(self, program: CobolProgram, ai_analysis: Optional[Dict[str, Any]] = None) -> str:
        """Implementa método abstrato da interface."""
        return self.generate_program_documentation(program, ai_analysis.get('summary') if ai_analysis else None)
    
    def generate_full_report(self, programs: List[CobolProgram], books: List[CobolBook], 
                           analysis_results: Dict[str, Any], ai_analysis: Dict[str, Any]) -> str:
        """Implementa método abstrato da interface."""
        return self.generate_consolidated_report(programs, books, analysis_results, ai_analysis)
    
    def save_documentation(self, content: str, file_path: str) -> bool:
        """Implementa método abstrato da interface."""
        try:
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(content)
            return True
        except Exception as e:
            self._logger.error(f"Erro ao salvar documentação: {str(e)}")
            return False

