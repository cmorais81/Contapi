"""
Entidade para resposta de análise de IA.
"""

from dataclasses import dataclass, field
from typing import Dict, Any, Optional

@dataclass
class AIResponse:
    """Resposta de análise de IA."""
    
    success: bool
    content: Optional[str] = None
    error_message: Optional[str] = None
    provider: Optional[str] = None
    model: Optional[str] = None
    tokens_used: int = 0
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def __post_init__(self):
        """Validação pós-inicialização."""
        if self.success and not self.content:
            raise ValueError("Resposta de sucesso deve ter conteúdo")
        if not self.success and not self.error_message:
            raise ValueError("Resposta de erro deve ter mensagem de erro")

