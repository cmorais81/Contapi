Entidade que representa um programa COBOL.
Segue o princípio Single Responsibility (SRP) do SOLID.
"""

from dataclasses import dataclass, field
from typing import List, Dict, Optional, Set
from datetime import datetime


@dataclass
class CobolProgram:
    """Representa um programa COBOL com suas características e metadados."""
    
    name: str
    author: Optional[str] = None
    date_written: Optional[str] = None
    date_compiled: Optional[str] = None
    objective: Optional[str] = None
    version_history: List[Dict[str, str]] = field(default_factory=list)
    source_lines: List[str] = field(default_factory=list)
    divisions: Dict[str, List[str]] = field(default_factory=dict)
    called_programs: Set[str] = field(default_factory=set)
    used_copybooks: Set[str] = field(default_factory=set)
    file_descriptors: List[str] = field(default_factory=list)
    working_storage: List[str] = field(default_factory=list)
    procedure_division: List[str] = field(default_factory=list)
    comments: List[str] = field(default_factory=list)
    
    def __post_init__(self):
