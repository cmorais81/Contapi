Entidades para configurações de IA.
Segue o princípio Single Responsibility (SRP).
"""

from dataclasses import dataclass, field
from typing import Dict, Any, Optional
from ..interfaces.configuration import IAIConfiguration, AIProviderType


@dataclass
class OpenAIConfiguration(IAIConfiguration):
    """Configuração para OpenAI."""
    
    api_key: str
    model_name: str = "gpt-4"
    api_endpoint: Optional[str] = None
    max_tokens: int = 4000
    temperature: float = 0.3
    organization: Optional[str] = None
    additional_parameters: Dict[str, Any] = field(default_factory=dict)
    
    def get_provider_type(self) -> AIProviderType:
        return AIProviderType.OPENAI
    
    def get_api_key(self) -> Optional[str]:
        return self.api_key
    
    def get_api_endpoint(self) -> Optional[str]:
        return self.api_endpoint or "https://api.openai.com/v1"
