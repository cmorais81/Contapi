"""
Factory para criação de provedores de IA.
Segue o padrão Factory Method e princípios SOLID.
"""

import logging
from typing import Dict, Any, List, Optional
from ...domain.interfaces.ai_provider import IAIProvider, IAIProviderFactory
from ...domain.interfaces.configuration import IAIConfiguration, AIProviderType
from ...domain.entities.exceptions import AIProviderError
from .openai_provider import OpenAIProvider
from .mock_ai_provider import MockAIProvider
from .enhanced_mock_ai_provider import EnhancedMockAIProvider


class AIProviderFactory(IAIProviderFactory):
    """Factory para criação de provedores de IA."""
    
    def __init__(self, logger: Optional[logging.Logger] = None):
        """
        Inicializa a factory.
        
        Args:
            logger: Logger para registrar operações
        """
        self._logger = logger or logging.getLogger(__name__)
        self._providers_registry = {
            AIProviderType.OPENAI.value: self._create_openai_provider,
            AIProviderType.BEDROCK.value: self._create_bedrock_provider,
            "mock_ai": self._create_mock_provider,
            "enhanced_mock_ai": self._create_enhanced_mock_provider,
            # AIProviderType.COPILOT.value: self._create_copilot_provider,  # Implementar se necessário
        }
    
    def create_provider(self, provider_type: str, configuration: IAIConfiguration) -> IAIProvider:
        """
        Cria um provedor de IA.
        
        Args:
            provider_type: Tipo do provedor
            configuration: Configuração do provedor
            
        Returns:
            Instância do provedor
            
        Raises:
            AIProviderError: Provedor não suportado ou erro na criação
        """
        try:
            self._logger.info(f"Criando provedor de IA: {provider_type}")
            
            if provider_type not in self._providers_registry:
                raise AIProviderError(
                    f"Provedor não suportado: {provider_type}",
                    provider=provider_type
                )
            
            # Chama método específico de criação
            creator_method = self._providers_registry[provider_type]
            provider = creator_method(configuration)
            
            self._logger.info(f"Provedor {provider_type} criado com sucesso")
            return provider
            
        except Exception as e:
            if isinstance(e, AIProviderError):
                raise
            
            raise AIProviderError(
                f"Erro criando provedor {provider_type}: {str(e)}",
                provider=provider_type
            )
    
    def get_supported_providers(self) -> List[str]:
        """Retorna lista de provedores suportados."""
        return list(self._providers_registry.keys())
    
    def _create_openai_provider(self, configuration: IAIConfiguration) -> IAIProvider:
        """Cria provedor OpenAI."""
        return OpenAIProvider(configuration, self._logger)
    
    def _create_bedrock_provider(self, configuration: IAIConfiguration) -> IAIProvider:
        """Cria provedor Bedrock."""
        return BedrockProvider(configuration, self._logger)
    
    def _create_mock_provider(self, configuration: IAIConfiguration) -> IAIProvider:
        """Cria provedor Mock AI."""
        return MockAIProvider(configuration, self._logger)
    
    def _create_enhanced_mock_provider(self, configuration: IAIConfiguration) -> IAIProvider:
        """Cria provedor Enhanced Mock AI."""
        return EnhancedMockAIProvider(configuration, self._logger)
    
    def _create_copilot_provider(self, configuration: IAIConfiguration) -> IAIProvider:
        """Cria provedor Copilot (placeholder para implementação futura)."""
        # Implementar quando necessário
        raise AIProviderError("Provedor Copilot ainda não implementado", provider="copilot")
    
    def register_provider(self, provider_type: str, creator_method) -> None:
        """
        Registra um novo tipo de provedor.
        
        Args:
            provider_type: Tipo do provedor
            creator_method: Método para criar o provedor
        """
        self._providers_registry[provider_type] = creator_method
        self._logger.info(f"Provedor {provider_type} registrado na factory")
    
    def unregister_provider(self, provider_type: str) -> None:
        """
        Remove um tipo de provedor.
        
        Args:
            provider_type: Tipo do provedor a ser removido
        """
        if provider_type in self._providers_registry:
            del self._providers_registry[provider_type]
            self._logger.info(f"Provedor {provider_type} removido da factory")


class AIOrchestrator:
    """Orquestrador para múltiplos provedores de IA com fallback."""
    
    def __init__(self, logger: Optional[logging.Logger] = None):
        """
        Inicializa o orquestrador.
        
        Args:
            logger: Logger para registrar operações
        """
        self._logger = logger or logging.getLogger(__name__)
        self._providers: List[tuple[IAIProvider, int]] = []  # (provider, priority)
    
    def add_provider(self, provider: IAIProvider, priority: int = 0) -> None:
        """
        Adiciona provedor ao orquestrador.
        
        Args:
            provider: Provedor a ser adicionado
            priority: Prioridade (maior = mais prioritário)
        """
        self._providers.append((provider, priority))
        # Ordena por prioridade (maior primeiro)
        self._providers.sort(key=lambda x: x[1], reverse=True)
        
        self._logger.info(f"Provedor {provider.get_provider_name()} adicionado com prioridade {priority}")
    
    def remove_provider(self, provider_name: str) -> None:
        """
        Remove provedor do orquestrador.
        
        Args:
            provider_name: Nome do provedor a ser removido
        """
        self._providers = [
            (provider, priority) for provider, priority in self._providers
            if provider.get_provider_name() != provider_name
        ]
        
        self._logger.info(f"Provedor {provider_name} removido do orquestrador")
    
    def get_available_providers(self) -> List[str]:
        """Retorna lista de provedores disponíveis."""
        available = []
        for provider, _ in self._providers:
            if provider.is_available():
                available.append(provider.get_provider_name())
        return available
    
    def process_request(self, request) -> Any:
        """
        Processa solicitação usando provedor primário e fallbacks.
        
        Args:
            request: Solicitação a ser processada
            
        Returns:
            Resposta da IA
            
        Raises:
            AIProviderError: Nenhum provedor disponível
        """
        if not self._providers:
            raise AIProviderError("Nenhum provedor configurado")
        
        last_error = None
        
        for provider, priority in self._providers:
            try:
                if not provider.is_available():
                    self._logger.warning(f"Provedor {provider.get_provider_name()} não disponível")
                    continue
                
                self._logger.info(f"Tentando processar com {provider.get_provider_name()}")
                
                # Tenta processar com o provedor atual
                if hasattr(request, 'analysis_type'):
                    response = provider.analyze_cobol_program(request)
                else:
                    response = provider.generate_documentation(request)
                
                if response.success:
                    self._logger.info(f"Processamento bem-sucedido com {provider.get_provider_name()}")
                    return response
                else:
                    self._logger.warning(f"Falha no processamento com {provider.get_provider_name()}: {response.error_message}")
                    last_error = response.error_message
                    
            except Exception as e:
                self._logger.error(f"Erro com provedor {provider.get_provider_name()}: {str(e)}")
                last_error = str(e)
                continue
        
        # Se chegou aqui, todos os provedores falharam
        raise AIProviderError(
            f"Todos os provedores falharam. Último erro: {last_error}",
            provider="orchestrator"
        )
    
    def get_provider_statistics(self) -> Dict[str, Any]:
        """Retorna estatísticas dos provedores."""
        stats = {
            'total_providers': len(self._providers),
            'available_providers': len(self.get_available_providers()),
            'providers': []
        }
        
        for provider, priority in self._providers:
            provider_stats = {
                'name': provider.get_provider_name(),
                'priority': priority,
                'available': provider.is_available(),
                'supported_models': provider.get_supported_models()
            }
            stats['providers'].append(provider_stats)
        
        return stats

