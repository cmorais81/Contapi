"""
Enhanced Mock AI Provider que simula comportamento realista de OpenAI/Copilot.
Versão 1.2.0 - Análises mais ricas e detalhadas.
"""

import logging
import random
import time
from typing import Dict, Any, List
from src.domain.interfaces.ai_provider import IAIProvider
from src.domain.entities.ai_configuration import OpenAIConfiguration
from src.domain.entities.ai_request import AIRequest
from src.domain.entities.ai_response import AIResponse

class EnhancedMockAIProvider(IAIProvider):
    """
    Provedor Mock AI melhorado que simula comportamento realista de APIs como OpenAI e Copilot.
    Gera análises detalhadas e contextualizadas baseadas no código COBOL real.
    """
    
    def __init__(self, config: OpenAIConfiguration, logger: logging.Logger):
        self.config = config
        self.logger = logger
        self.provider_name = "enhanced_mock_ai"
        
        # Base de conhecimento expandida para programas BACEN
        self.knowledge_base = {
            "LHAN0542": {
                "purpose": "Particionador de arquivos BACEN DOC3040",
                "complexity": "Média",
                "business_context": "Processamento regulatório BACEN",
                "main_functions": [
                    "Leitura sequencial de arquivo DOC3040",
                    "Validação de formato de registros",
                    "Particionamento por volume (10.000 registros)",
                    "Geração de arquivos numerados sequencialmente",
                    "Controle de integridade e auditoria"
                ],
                "business_rules": [
                    "Registros tipo '01', '02', '03' são válidos",
                    "Campo sequencial deve ser numérico",
                    "Data de processamento deve ser válida",
                    "Máximo 10.000 registros por arquivo de saída",
                    "Manter sequência original dos dados"
                ],
                "technical_details": [
                    "Utiliza processamento sequencial otimizado",
                    "Implementa controle de buffer para performance",
                    "Gerencia contadores de registros e arquivos",
                    "Aplica validações em tempo real",
                    "Sistema de logging para auditoria"
                ]
            },
            "LHAN0705": {
                "purpose": "Validador e formatador de dados BACEN",
                "complexity": "Alta",
                "business_context": "Validação regulatória DOC3040",
                "main_functions": [
                    "Validação física e lógica de registros",
                    "Aplicação de regras de negócio BACEN",
                    "Formatação de dados para padrão regulatório",
                    "Geração de relatórios de validação",
                    "Controle de qualidade de dados"
                ],
                "business_rules": [
                    "Aplicar todas as validações DOC3040",
                    "Rejeitar registros com inconsistências",
                    "Gerar relatório de erros detalhado",
                    "Manter histórico de validações",
                    "Garantir conformidade regulatória"
                ],
                "technical_details": [
                    "Múltiplas validações em cascata",
                    "Sistema de cache para performance",
                    "Processamento paralelo de validações",
                    "Otimização para grandes volumes",
                    "Integração com sistema de auditoria"
                ]
            },
            "LHAN0706": {
                "purpose": "Consolidador e sumarizador de dados",
                "complexity": "Alta",
                "business_context": "Consolidação regulatória BACEN",
                "main_functions": [
                    "Consolidação de dados validados",
                    "Geração de totalizadores e estatísticas",
                    "Criação de arquivos de controle",
                    "Sumarização por critérios de negócio",
                    "Preparação para envio ao BACEN"
                ],
                "business_rules": [
                    "Consolidar apenas dados válidos",
                    "Gerar totalizadores por tipo de registro",
                    "Criar controles de integridade",
                    "Aplicar regras de arredondamento",
                    "Validar somatórias e balanços"
                ],
                "technical_details": [
                    "Algoritmos de agregação otimizados",
                    "Controle de precisão numérica",
                    "Sistema de checkpoint para recovery",
                    "Processamento em lotes para eficiência",
                    "Validação cruzada de totais"
                ]
            },
            "LHBR0700": {
                "purpose": "Gerador de relatórios e arquivos de controle",
                "complexity": "Média",
                "business_context": "Relatórios regulatórios BACEN",
                "main_functions": [
                    "Geração de relatórios regulatórios",
                    "Criação de arquivos de controle",
                    "Formatação para padrões BACEN",
                    "Validação de layouts de saída",
                    "Controle de versioning de relatórios"
                ],
                "business_rules": [
                    "Seguir layouts oficiais do BACEN",
                    "Incluir todos os controles obrigatórios",
                    "Validar formatação antes da saída",
                    "Manter histórico de relatórios gerados",
                    "Aplicar assinatura digital quando necessário"
                ],
                "technical_details": [
                    "Templates dinâmicos de relatórios",
                    "Sistema de formatação flexível",
                    "Controle de quebras e totalizações",
                    "Otimização de I/O para grandes relatórios",
                    "Integração com sistema de distribuição"
                ]
            },
            "MZAN6056": {
                "purpose": "Finalizador e limpeza do processo",
                "complexity": "Baixa",
                "business_context": "Housekeeping do processo BACEN",
                "main_functions": [
                    "Limpeza de arquivos temporários",
                    "Backup de arquivos importantes",
                    "Envio de notificações de conclusão",
                    "Atualização de logs de controle",
                    "Preparação para próxima execução"
                ],
                "business_rules": [
                    "Manter backup por período regulatório",
                    "Limpar apenas arquivos temporários",
                    "Notificar conclusão para sistemas dependentes",
                    "Registrar métricas de execução",
                    "Validar integridade antes da limpeza"
                ],
                "technical_details": [
                    "Scripts de limpeza automatizados",
                    "Sistema de backup incremental",
                    "Notificações via email/SMS",
                    "Logging estruturado de atividades",
                    "Verificações de integridade pré-limpeza"
                ]
            }
        }
    
    def analyze_cobol_program(self, request: AIRequest) -> AIResponse:
        """
        Simula análise avançada de programa COBOL com comportamento realista de IA.
        """
        try:
            # Simular tempo de processamento realista
            time.sleep(random.uniform(0.5, 1.5))
            
            program_name = request.program_name
            analysis_type = request.analysis_type
            code_content = request.code_content
            
            self.logger.info(f"Simulando análise IA avançada para: {analysis_type}")
            
            # Gerar prompt específico
            prompt = self._generate_analysis_prompt(analysis_type, program_name, code_content)
            
            # Gerar análise baseada no tipo
            if analysis_type in ['program_summary', 'PROGRAM_SUMMARY']:
                content = self._generate_enhanced_summary(program_name, code_content)
                tokens = random.randint(150, 250)
            elif analysis_type in ['technical_documentation', 'TECHNICAL_DOCUMENTATION']:
                content = self._generate_enhanced_technical_analysis(program_name, code_content)
                tokens = random.randint(400, 600)
            elif analysis_type in ['functional_documentation', 'FUNCTIONAL_DOCUMENTATION']:
                content = self._generate_enhanced_functional_analysis(program_name, code_content)
                tokens = random.randint(450, 650)
            elif analysis_type in ['relationship_analysis', 'RELATIONSHIP_ANALYSIS']:
                content = self._generate_enhanced_relationship_analysis(program_name, code_content)
                tokens = random.randint(200, 350)
            else:
                content = self._generate_general_analysis(program_name, code_content)
                tokens = random.randint(200, 400)
            
            # Criar resposta com metadados enriquecidos
            response = AIResponse(
                success=True,
                content=content,
                provider=self.provider_name,
                model="enhanced-gpt-4-cobol-specialist",
                tokens_used=tokens,
                metadata={
                    'analysis_type': analysis_type,
                    'program_name': program_name,
                    'prompt_used': prompt,
                    'analysis_timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
                    'confidence_score': random.uniform(0.85, 0.98),
                    'processing_time_ms': random.randint(800, 2000)
                }
            )
            
            return response
            
        except Exception as e:
            self.logger.error(f"Erro na análise IA: {str(e)}")
            return AIResponse(
                success=False,
                error_message=f"Erro na análise: {str(e)}",
                provider=self.provider_name
            )
    
    def _generate_enhanced_summary(self, program_name: str, code_content: str) -> str:
        """Gera resumo executivo melhorado."""
        knowledge = self.knowledge_base.get(program_name, {})
        
        return f"""## Resumo Executivo - {program_name}

### Propósito Principal
{knowledge.get('purpose', 'Programa de processamento de dados COBOL')}

### Contexto de Negócio
{knowledge.get('business_context', 'Processamento de dados empresariais')}

### Funcionalidades Principais
{self._format_list(knowledge.get('main_functions', ['Processamento de dados', 'Validações', 'Geração de relatórios']))}

### Avaliação de Complexidade
**Nível**: {knowledge.get('complexity', 'Média')}

**Justificativa**: Baseado na análise do código, este programa apresenta:
- Volume de código: {len(code_content.split(chr(10)))} linhas analisadas
- Estruturas de controle: {self._count_control_structures(code_content)} identificadas
- Validações implementadas: {self._count_validations(code_content)} regras
- Processamento de arquivos: {self._count_file_operations(code_content)} operações

### Posição no Fluxo de Processamento
Este programa executa como parte de uma cadeia de processamento regulatório, integrando-se com outros componentes do sistema BACEN DOC3040 para garantir conformidade e qualidade dos dados.

### Métricas de Qualidade
- **Estruturação**: Bem organizado com divisões COBOL padrão
- **Documentação**: Comentários explicativos presentes
- **Tratamento de Erros**: Controles de exceção implementados
- **Performance**: Otimizado para processamento em lote"""

    def _generate_enhanced_technical_analysis(self, program_name: str, code_content: str) -> str:
        """Gera análise técnica detalhada."""
        knowledge = self.knowledge_base.get(program_name, {})
        
        return f"""## Documentação Técnica Detalhada - {program_name}

### Arquitetura e Estrutura

#### Divisões COBOL Identificadas
- **Identification Division**: Define programa {program_name}
- **Environment Division**: Configuração de arquivos e ambiente
- **Data Division**: Estruturas de dados e variáveis de controle
- **Procedure Division**: Lógica principal de processamento

#### Organização Modular
O programa segue padrões estruturados com separação clara de responsabilidades:
- Módulos de inicialização
- Rotinas de processamento principal
- Procedimentos de validação
- Rotinas de finalização e limpeza

### Lógica e Regras de Negócio Implementadas

#### Procedimentos Principais Identificados
{self._extract_procedures(code_content)}

#### Condições e Validações Críticas
{self._extract_conditions(code_content)}

#### Cálculos e Transformações
{self._extract_calculations(code_content)}

#### Regras de Negócio Específicas
{self._format_list(knowledge.get('business_rules', ['Validações padrão', 'Controles de integridade']))}

### Fluxo Lógico Detalhado

#### Sequência de Execução (5 Etapas)
1. **Inicialização**: Setup de variáveis, abertura de arquivos, validação de parâmetros
2. **Processamento Principal**: Loop de leitura, aplicação de regras, transformações
3. **Validações e Controles**: Verificações de integridade, aplicação de regras de negócio
4. **Geração de Saídas**: Criação de arquivos, relatórios, logs de controle
5. **Finalização**: Fechamento de recursos, estatísticas, limpeza

#### Pontos de Decisão Críticos
- Validação de tipos de registro
- Controle de limites e volumes
- Verificação de condições de negócio
- Tratamento de situações excepcionais

### Aspectos Técnicos Específicos

#### Processamento de Arquivos
- **Estratégia**: Processamento sequencial otimizado
- **Buffer Management**: Controle eficiente de memória
- **I/O Operations**: Otimização de operações de entrada/saída

#### Controles de Performance
{self._format_list(knowledge.get('technical_details', ['Otimização de loops', 'Controle de memória', 'I/O eficiente']))}

#### Tratamento de Erros e Exceções
- Sistema robusto de tratamento de exceções
- Logging detalhado para diagnóstico
- Recovery automático quando possível
- Códigos de retorno padronizados

### Padrões de Codificação Identificados
- **Nomenclatura**: Padrão consistente de variáveis e procedimentos
- **Estruturação**: Organização modular e hierárquica
- **Documentação**: Comentários explicativos em pontos críticos
- **Manutenibilidade**: Código estruturado para facilitar manutenção

### Considerações de Segurança
- Validação rigorosa de dados de entrada
- Controle de acesso a arquivos sensíveis
- Logging de auditoria para rastreabilidade
- Tratamento seguro de informações regulatórias"""

    def _generate_enhanced_functional_analysis(self, program_name: str, code_content: str) -> str:
        """Gera análise funcional de negócio detalhada."""
        knowledge = self.knowledge_base.get(program_name, {})
        
        return f"""## Documentação Funcional de Negócio - {program_name}

### Objetivo Estratégico do Negócio

#### Finalidade Empresarial
{knowledge.get('purpose', 'Processamento de dados críticos para operação')}

#### Valor Agregado ao Processo
Este programa é fundamental para:
- Garantir conformidade regulatória com BACEN
- Manter integridade e qualidade dos dados
- Automatizar processos críticos de negócio
- Reduzir riscos operacionais e regulatórios

#### Contexto no Ecossistema
{knowledge.get('business_context', 'Componente essencial do sistema de processamento')}

### Regras de Negócio Implementadas

#### Regras Principais
{self._format_numbered_list(knowledge.get('business_rules', ['Validações padrão', 'Controles de qualidade']))}

#### Validações de Negócio Aplicadas
- **Validações de Formato**: Verificação de estrutura e tipos de dados
- **Validações Lógicas**: Consistência entre campos relacionados
- **Validações Regulatórias**: Conformidade com normas BACEN
- **Validações de Integridade**: Controles de totalização e balanços

#### Controles de Qualidade
- Verificação de completude dos dados
- Validação de faixas e limites
- Controle de duplicatas
- Verificação de sequência e ordenação

### Fluxo de Processamento de Negócio

#### Etapas do Processo (Visão de Negócio)
1. **Recepção de Dados**: Entrada de informações do sistema fonte
2. **Validação e Enriquecimento**: Aplicação de regras e validações
3. **Processamento e Transformação**: Aplicação da lógica de negócio
4. **Controle de Qualidade**: Verificações finais e validações
5. **Entrega de Resultados**: Geração de saídas para sistemas dependentes

#### Entradas e Saídas por Etapa
- **Entrada**: Arquivos de dados brutos do sistema fonte
- **Processamento**: Aplicação de regras e transformações
- **Saída**: Dados validados e formatados para uso downstream

#### Controles de Qualidade Aplicados
- Verificação de integridade referencial
- Validação de totalizadores
- Controle de reconciliação
- Auditoria de transformações

### Impacto nos Processos Empresariais

#### Sistemas Dependentes
- **Upstream**: Sistemas de origem dos dados
- **Downstream**: Sistemas que consomem os dados processados
- **Paralelos**: Sistemas de controle e auditoria

#### Frequência e Criticidade
- **Frequência de Execução**: Diária (processo batch regulatório)
- **Janela de Processamento**: Período noturno (22h às 06h)
- **Criticidade**: Alta - Impacta cumprimento regulatório
- **SLA**: Conclusão obrigatória antes das 08h

#### Impacto de Falhas
- **Regulatório**: Não conformidade com BACEN
- **Operacional**: Atraso em processos dependentes
- **Financeiro**: Possíveis multas e penalidades
- **Reputacional**: Impacto na imagem institucional

### Métricas de Negócio

#### Indicadores de Performance
- Volume de registros processados
- Taxa de rejeição por validações
- Tempo de processamento
- Disponibilidade do sistema

#### Controles de Auditoria
- Log completo de todas as operações
- Rastreabilidade de transformações
- Histórico de execuções
- Controles de acesso e segurança

### Conformidade Regulatória

#### Normas Aplicáveis
- Circular BACEN DOC3040
- Resoluções do Conselho Monetário Nacional
- Normas de segurança da informação
- Políticas internas de governança

#### Controles de Compliance
- Validação automática de conformidade
- Relatórios de auditoria
- Controles de acesso e segregação
- Documentação de processos"""

    def _generate_enhanced_relationship_analysis(self, program_name: str, code_content: str) -> str:
        """Gera análise detalhada de relacionamentos."""
        
        return f"""## Análise de Relacionamentos e Dependências - {program_name}

### Mapeamento de Dependências

#### Programas Chamados (CALL Statements)
{self._extract_called_programs(code_content)}

#### Copybooks Utilizados (COPY Statements)
{self._extract_copybooks(code_content)}

#### Arquivos e Datasets
{self._extract_file_dependencies(code_content)}

### Análise de Fluxo de Dados

#### Dados de Entrada
- **Fonte Principal**: Arquivos de dados do sistema upstream
- **Formato**: Registros de tamanho fixo/variável
- **Volume Típico**: Milhares a milhões de registros
- **Frequência**: Diária/Semanal conforme cronograma

#### Transformações Aplicadas
- Validação e limpeza de dados
- Aplicação de regras de negócio
- Cálculos e agregações
- Formatação para padrões específicos

#### Dados de Saída
- **Destino**: Sistemas downstream e arquivos de controle
- **Formato**: Conforme especificações regulatórias
- **Controles**: Totalizadores e checksums
- **Distribuição**: Automática via sistema de jobs

### Posicionamento no Ecossistema

#### Cadeia de Processamento
```
Sistema Fonte → {program_name} → Sistema Destino
     ↓              ↓              ↓
  Dados Brutos → Processamento → Dados Validados
```

#### Dependências Upstream
- Sistemas de origem dos dados
- Processos de extração e preparação
- Validações preliminares
- Controles de disponibilidade

#### Dependências Downstream
- Sistemas que consomem os dados processados
- Processos de distribuição
- Relatórios e dashboards
- Sistemas de arquivo e backup

### Análise de Criticidade

#### Impacto de Indisponibilidade
- **Alto**: Bloqueia processos críticos downstream
- **Regulatório**: Impacta cumprimento de prazos
- **Operacional**: Afeta múltiplos sistemas dependentes

#### Estratégias de Contingência
- Processamento manual de emergência
- Sistemas de backup e recovery
- Procedimentos de rollback
- Comunicação com stakeholders

### Integração com Sistemas Externos

#### APIs e Interfaces
- Interfaces de entrada de dados
- APIs de validação externa
- Serviços de notificação
- Sistemas de monitoramento

#### Protocolos de Comunicação
- Transferência de arquivos (FTP/SFTP)
- Mensageria (MQ/Kafka)
- Webservices (REST/SOAP)
- Batch processing

### Monitoramento e Controle

#### Métricas de Relacionamento
- Taxa de sucesso nas integrações
- Tempo de resposta das dependências
- Volume de dados transferidos
- Erros de comunicação

#### Alertas e Notificações
- Falhas em dependências críticas
- Atrasos em processamento
- Problemas de qualidade de dados
- Violações de SLA"""

    def _generate_analysis_prompt(self, analysis_type: str, program_name: str, code_content: str) -> str:
        """Gera prompt específico para o tipo de análise."""
        base_context = f"""
Você é um especialista sênior em análise de sistemas COBOL mainframe com 20+ anos de experiência em documentação técnica e funcional, especializado em sistemas regulatórios bancários.

PROGRAMA: {program_name}
TIPO DE ANÁLISE: {analysis_type}
CONTEXTO: Sistema BACEN DOC3040 - Processamento Regulatório

CÓDIGO COBOL:
```cobol
{code_content[:3000]}{'...' if len(code_content) > 3000 else ''}
```
"""
        
        if analysis_type in ['program_summary', 'PROGRAM_SUMMARY']:
            return base_context + """
TAREFA: Gere um resumo executivo detalhado do programa COBOL analisando:

1. PROPÓSITO ESTRATÉGICO
   - Qual é a função principal deste programa no contexto BACEN?
   - Que problema de negócio específico ele resolve?
   - Como se posiciona na cadeia de valor regulatória?

2. FUNCIONALIDADES PRINCIPAIS
   - Liste as 5-7 principais funcionalidades implementadas
   - Identifique os processos-chave executados
   - Destaque inovações ou particularidades técnicas

3. AVALIAÇÃO DE COMPLEXIDADE
   - Avalie a complexidade: Baixa, Média ou Alta
   - Justifique baseado em: volume de código, lógica, validações, integrações
   - Identifique pontos de maior complexidade técnica

4. CONTEXTO NO FLUXO REGULATÓRIO
   - Como este programa se encaixa no processo BACEN DOC3040?
   - Qual sua posição na cadeia de processamento?
   - Que sistemas dependem deste processamento?

5. MÉTRICAS DE QUALIDADE
   - Avalie estruturação, documentação, tratamento de erros
   - Identifique boas práticas implementadas
   - Sugira pontos de melhoria se aplicável

FORMATO: Markdown estruturado, linguagem técnica mas executiva, foco em valor de negócio.
"""
        
        elif analysis_type in ['technical_documentation', 'TECHNICAL_DOCUMENTATION']:
            return base_context + """
TAREFA: Gere documentação técnica abrangente analisando:

1. ARQUITETURA E ESTRUTURA
   - Divisões COBOL identificadas e sua organização
   - Seções principais (File, Working-Storage, Procedure)
   - Padrões arquiteturais implementados
   - Organização modular e hierárquica

2. LÓGICA E REGRAS DE NEGÓCIO DETALHADAS
   - Procedimentos principais (PERFORM statements) com descrição funcional
   - Condições e validações (IF, EVALUATE, WHEN) com contexto de negócio
   - Cálculos e transformações (COMPUTE, ADD, SUBTRACT) com propósito
   - Regras específicas implementadas com justificativa regulatória

3. FLUXO LÓGICO ESTRUTURADO
   - Sequência de execução detalhada (5-7 etapas principais)
   - Pontos de decisão críticos com impacto no negócio
   - Tratamento de erros e exceções com estratégias de recovery
   - Controles de qualidade e validação implementados

4. ASPECTOS TÉCNICOS AVANÇADOS
   - Estratégias de processamento de arquivos e performance
   - Controles de memória e otimização de recursos
   - Padrões de codificação e boas práticas identificadas
   - Considerações de segurança e auditoria

5. ANÁLISE DE MANUTENIBILIDADE
   - Qualidade do código e estruturação
   - Facilidade de manutenção e extensão
   - Documentação inline e comentários
   - Sugestões de melhorias técnicas

FORMATO: Markdown técnico detalhado, com seções especializadas e exemplos de código quando relevante.
"""
        
        elif analysis_type in ['functional_documentation', 'FUNCTIONAL_DOCUMENTATION']:
            return base_context + """
TAREFA: Gere documentação funcional focada no valor de negócio:

1. OBJETIVO ESTRATÉGICO DO NEGÓCIO
   - Finalidade do programa no contexto empresarial e regulatório
   - Valor agregado ao processo BACEN DOC3040
   - Impacto na conformidade regulatória
   - Contribuição para objetivos organizacionais

2. REGRAS DE NEGÓCIO IMPLEMENTADAS
   - Identifique cada regra de negócio específica com contexto regulatório
   - Descreva validações e controles aplicados com justificativa
   - Mapeie transformações de dados com propósito de negócio
   - Explique exceções e tratamentos especiais

3. FLUXO DE PROCESSAMENTO DE NEGÓCIO
   - Etapas do processo de negócio (5-6 etapas) com valor agregado
   - Entradas e saídas de cada etapa com contexto empresarial
   - Controles de qualidade aplicados com impacto no negócio
   - Pontos de aprovação e validação críticos

4. VALIDAÇÕES E CONTROLES EMPRESARIAIS
   - Verificações de integridade com impacto regulatório
   - Controles de consistência com justificativa de negócio
   - Tratamento de exceções de negócio com procedimentos
   - Auditoria e rastreabilidade para compliance

5. IMPACTO NOS PROCESSOS ORGANIZACIONAIS
   - Como afeta outros sistemas/processos críticos
   - Frequência de execução e janelas de processamento
   - Criticidade para o negócio e impacto de falhas
   - SLAs e acordos de nível de serviço

FORMATO: Markdown focado em aspectos funcionais e de negócio, linguagem acessível para stakeholders não-técnicos.
"""
        
        elif analysis_type in ['relationship_analysis', 'RELATIONSHIP_ANALYSIS']:
            return base_context + """
TAREFA: Analise relacionamentos e dependências de forma abrangente:

1. MAPEAMENTO DE DEPENDÊNCIAS TÉCNICAS
   - Identifique CALL statements com contexto funcional
   - Liste programas invocados com propósito de cada chamada
   - Analise parâmetros passados e dados compartilhados
   - Mapeie hierarquia de chamadas e dependências

2. ANÁLISE DE COPYBOOKS E ESTRUTURAS
   - Identifique COPY statements com finalidade
   - Liste copybooks incluídos com descrição funcional
   - Analise estruturas de dados compartilhadas
   - Mapeie dependências de layout e formato

3. DEPENDÊNCIAS EXTERNAS E RECURSOS
   - Arquivos de entrada e saída com propósito de negócio
   - Tabelas de banco de dados e views utilizadas
   - Recursos do sistema (JCL, procedures, utilities)
   - Interfaces com sistemas externos

4. POSICIONAMENTO NO ECOSSISTEMA
   - Onde se encaixa na cadeia de processamento regulatório
   - Programas predecessores e sucessores com fluxo de dados
   - Dados recebidos e produzidos com contexto de negócio
   - Impacto de falhas em sistemas dependentes

5. ANÁLISE DE CRITICIDADE E CONTINGÊNCIA
   - Avalie criticidade das dependências identificadas
   - Identifique pontos únicos de falha
   - Sugira estratégias de contingência
   - Mapeie impacto de indisponibilidade

FORMATO: Markdown com foco em mapeamento de relacionamentos, diagramas textuais quando aplicável.
"""
        
        else:
            return base_context + f"""
TAREFA: Realize análise abrangente do programa COBOL para o tipo: {analysis_type}

Analise o código fornecido considerando:
- Estrutura e organização técnica
- Lógica implementada e regras de negócio
- Funcionalidades principais e valor agregado
- Relacionamentos e dependências críticas
- Contexto regulatório BACEN DOC3040

FORMATO: Markdown estruturado e profissional, adequado para documentação empresarial.
"""

    def _extract_procedures(self, code_content: str) -> str:
        """Extrai e documenta procedimentos COBOL."""
        procedures = []
        lines = code_content.split('\n')
        
        for line in lines:
            line = line.strip()
            if 'PERFORM' in line.upper() and len(line) > 20:
                procedures.append(f"- **{line[:50]}...**: Procedimento de controle de fluxo")
        
        if not procedures:
            procedures = [
                "- **MAIN-PROCESS**: Controle principal do fluxo de execução",
                "- **INICIALIZAR**: Setup inicial de variáveis e recursos",
                "- **PROCESSAR-DADOS**: Loop principal de processamento",
                "- **VALIDAR-REGISTROS**: Aplicação de regras de validação",
                "- **FINALIZAR**: Limpeza e fechamento de recursos"
            ]
        
        return '\n'.join(procedures[:5])
    
    def _extract_conditions(self, code_content: str) -> str:
        """Extrai e documenta condições COBOL."""
        conditions = []
        lines = code_content.split('\n')
        
        for line in lines:
            line = line.strip()
            if any(keyword in line.upper() for keyword in ['IF ', 'EVALUATE', 'WHEN']) and len(line) > 15:
                conditions.append(f"- **{line[:60]}...**: Validação crítica de negócio")
        
        if not conditions:
            conditions = [
                "- **IF CAMPO-TIPO-REG = '01' OR '02'**: Validação de tipo de registro",
                "- **IF CAMPO-SEQUENCIAL NUMERIC**: Verificação de formato numérico",
                "- **EVALUATE WS-STATUS-ARQUIVO**: Controle de status de arquivo",
                "- **WHEN WS-CONTADOR > WS-LIMITE**: Controle de volume de processamento"
            ]
        
        return '\n'.join(conditions[:4])
    
    def _extract_calculations(self, code_content: str) -> str:
        """Extrai e documenta cálculos COBOL."""
        calculations = []
        lines = code_content.split('\n')
        
        for line in lines:
            line = line.strip()
            if any(keyword in line.upper() for keyword in ['COMPUTE', 'ADD ', 'SUBTRACT', 'MULTIPLY', 'DIVIDE']) and len(line) > 10:
                calculations.append(f"- **{line[:50]}...**: Operação matemática/contabilização")
        
        if not calculations:
            calculations = [
                "- **ADD 1 TO WS-CONTADOR-REG**: Incremento de contador de registros",
                "- **COMPUTE WS-PERCENTUAL = (WS-VALIDOS / WS-TOTAL) * 100**: Cálculo de percentual",
                "- **SUBTRACT WS-REJEITADOS FROM WS-TOTAL**: Cálculo de registros válidos",
                "- **MULTIPLY WS-VALOR BY WS-FATOR**: Aplicação de fator de correção"
            ]
        
        return '\n'.join(calculations[:4])
    
    def _extract_called_programs(self, code_content: str) -> str:
        """Extrai programas chamados."""
        calls = []
        lines = code_content.split('\n')
        
        for line in lines:
            if 'CALL' in line.upper() and "'" in line:
                program = line.split("'")[1] if "'" in line else "PROGRAMA"
                calls.append(f"- **{program}**: Programa utilitário especializado")
        
        if not calls:
            calls = ["- Nenhuma chamada externa identificada no código analisado"]
        
        return '\n'.join(calls[:5])
    
    def _extract_copybooks(self, code_content: str) -> str:
        """Extrai copybooks utilizados."""
        copies = []
        lines = code_content.split('\n')
        
        for line in lines:
            if 'COPY' in line.upper() and len(line.strip()) > 10:
                copybook = line.split()[-1] if line.split() else "COPYBOOK"
                copies.append(f"- **{copybook}**: Layout de dados compartilhado")
        
        if not copies:
            copies = ["- Nenhum copybook identificado no código analisado"]
        
        return '\n'.join(copies[:5])
    
    def _extract_file_dependencies(self, code_content: str) -> str:
        """Extrai dependências de arquivos."""
        files = []
        lines = code_content.split('\n')
        
        for line in lines:
            if any(keyword in line.upper() for keyword in ['SELECT', 'ASSIGN TO']) and len(line) > 20:
                files.append(f"- **{line.strip()[:60]}...**: Definição de arquivo")
        
        if not files:
            files = [
                "- **Arquivo de Entrada**: Dados brutos para processamento",
                "- **Arquivo de Saída**: Dados processados e validados",
                "- **Arquivo de Log**: Controle e auditoria de execução",
                "- **Arquivo de Erro**: Registros rejeitados com motivo"
            ]
        
        return '\n'.join(files[:4])
    
    def _count_control_structures(self, code_content: str) -> int:
        """Conta estruturas de controle."""
        keywords = ['IF', 'PERFORM', 'EVALUATE', 'WHEN', 'UNTIL', 'WHILE']
        count = sum(code_content.upper().count(keyword) for keyword in keywords)
        return max(count, 5)  # Mínimo realista
    
    def _count_validations(self, code_content: str) -> int:
        """Conta validações implementadas."""
        validations = code_content.upper().count('IF') + code_content.upper().count('WHEN')
        return max(validations, 3)  # Mínimo realista
    
    def _count_file_operations(self, code_content: str) -> int:
        """Conta operações de arquivo."""
        operations = ['READ', 'WRITE', 'OPEN', 'CLOSE', 'SELECT']
        count = sum(code_content.upper().count(op) for op in operations)
        return max(count, 4)  # Mínimo realista
    
    def _format_list(self, items: List[str]) -> str:
        """Formata lista com bullets."""
        return '\n'.join([f"- {item}" for item in items])
    
    def _format_numbered_list(self, items: List[str]) -> str:
        """Formata lista numerada."""
        return '\n'.join([f"{i+1}. **{item}**" for i, item in enumerate(items)])
    
    def _generate_general_analysis(self, program_name: str, code_content: str) -> str:
        """Gera análise geral para tipos não específicos."""
        knowledge = self.knowledge_base.get(program_name, {})
        
        return f"""## Análise Geral - {program_name}

### Visão Geral
{knowledge.get('purpose', 'Programa de processamento de dados COBOL')}

### Características Principais
- **Complexidade**: {knowledge.get('complexity', 'Média')}
- **Contexto**: {knowledge.get('business_context', 'Processamento empresarial')}
- **Linhas de Código**: {len(code_content.split())} analisadas

### Funcionalidades Identificadas
{self._format_list(knowledge.get('main_functions', ['Processamento de dados', 'Validações', 'Controles']))}

### Aspectos Técnicos
- Estrutura COBOL padrão implementada
- Controles de erro e validação presentes
- Processamento otimizado para volumes
- Logging e auditoria implementados"""

    def get_provider_info(self) -> Dict[str, Any]:
        """Retorna informações do provedor."""
        return {
            "name": self.provider_name,
            "model": "enhanced-gpt-4-cobol-specialist",
            "version": "1.2.0",
            "capabilities": [
                "Advanced COBOL Analysis",
                "Business Rules Extraction",
                "Technical Documentation",
                "Relationship Mapping",
                "Regulatory Compliance Analysis"
            ],
            "specialization": "BACEN DOC3040 Systems"
        }
    
    def get_provider_name(self) -> str:
        """Retorna nome do provedor."""
        return self.provider_name
    
    def get_supported_models(self) -> List[str]:
        """Retorna modelos suportados."""
        return ["enhanced-gpt-4-cobol-specialist", "enhanced-gpt-3.5-turbo-cobol"]
    
    def is_available(self) -> bool:
        """Verifica se o provedor está disponível."""
        return True
    
    def estimate_cost(self, request: AIRequest) -> float:
        """Estima custo da análise."""
        # Simulação de custo baseado em tokens
        estimated_tokens = len(request.code_content.split()) * 1.5
        cost_per_1k_tokens = 0.03  # Simulação de custo OpenAI
        return (estimated_tokens / 1000) * cost_per_1k_tokens
    
    def generate_documentation(self, request: AIRequest) -> AIResponse:
        """Gera documentação (alias para analyze_cobol_program)."""
        return self.analyze_cobol_program(request)

