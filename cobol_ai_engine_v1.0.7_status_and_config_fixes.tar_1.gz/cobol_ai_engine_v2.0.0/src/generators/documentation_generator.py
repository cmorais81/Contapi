#!/usr/bin/env python3
"""
COBOL AI Engine v1.3.0 - Documentation Generator
Gerador completo de documentação com suporte a faseamento e múltiplos formatos.
"""

import logging
import os
import json
from typing import Dict, Any, List, Optional
from datetime import datetime

from ..parsers.cobol_parser import CobolProgram, CobolBook
from ..providers.base_provider import AIResponse


class DocumentationGenerator:
    """
    Gerador de documentação completo para programas COBOL.
    
    Funcionalidades:
    - Geração de documentação individual por programa
    - Relatório consolidado
    - Suporte a metadados de faseamento
    - Múltiplos formatos de saída
    - Estatísticas detalhadas
    """
    
    def __init__(self, output_dir: str = "output"):
        """
        Inicializa o gerador de documentação.
        
        Args:
            output_dir: Diretório de saída
        """
        self.output_dir = output_dir
        self.logger = logging.getLogger(__name__)
        
        # Criar diretório de saída
        os.makedirs(output_dir, exist_ok=True)
        
        # Criar subdiretório para JSONs das respostas
        self.json_dir = os.path.join(output_dir, "ai_responses")
        os.makedirs(self.json_dir, exist_ok=True)
        
        # Estatísticas
        self.files_generated = 0
        self.total_programs = 0
        self.total_books = 0
        
        self.logger.info(f"Documentation Generator inicializado - Output: {output_dir}")
    
    def generate_program_documentation(self, program: CobolProgram, 
                                     ai_response: AIResponse,
                                     phase_info: Optional[Dict[str, Any]] = None) -> str:
        """
        Gera documentação completa para um programa COBOL.
        
        Args:
            program: Programa COBOL
            ai_response: Resposta da análise de IA
            phase_info: Informações de faseamento (opcional)
            
        Returns:
            Caminho do arquivo gerado
        """
        try:
            # Gerar conteúdo
            content = self._generate_program_content(program, ai_response, phase_info)
            
            # Salvar arquivo principal
            filename = f"{program.name}.md"
            filepath = os.path.join(self.output_dir, filename)
            
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)
            
            # Salvar JSON da resposta da IA para análise
            self._save_ai_response_json(program, ai_response)
            
            self.files_generated += 1
            self.total_programs += 1
            
            self.logger.info(f"Documentação gerada: {filename}")
            return filepath
            
        except Exception as e:
            self.logger.error(f"Erro ao gerar documentação para {program.name}: {e}")
            return ""
    
    def _save_ai_response_json(self, program: CobolProgram, ai_response: AIResponse) -> None:
        """
        Salva o JSON completo da resposta da IA para análise posterior.
        
        Args:
            program: Programa COBOL
            ai_response: Resposta da IA
        """
        try:
            # Preparar dados para serialização
            response_data = {
                "program_name": program.name,
                "timestamp": datetime.now().isoformat(),
                "analysis_metadata": {
                    "success": ai_response.success,
                    "model": ai_response.model,
                    "provider": ai_response.provider,
                    "tokens_used": ai_response.tokens_used,
                    "error_message": ai_response.error_message,
                    "analysis_timestamp": ai_response.timestamp.isoformat() if ai_response.timestamp else None
                },
                "content": {
                    "analysis_result": ai_response.content,
                    "raw_response": ai_response.raw_response if hasattr(ai_response, 'raw_response') else None
                },
                "prompts_used": ai_response.prompts_used if hasattr(ai_response, 'prompts_used') else {},
                "metadata": ai_response.metadata if ai_response.metadata else {},
                "pre_analysis": {
                    "enhanced_comments": [],
                    "logic_flows": [],
                    "business_entities": [],
                    "regulatory_compliance": {},
                    "quality_metrics": {}
                }
            }
            
            # Adicionar pré-análise se disponível
            if hasattr(ai_response, 'pre_analysis') and ai_response.pre_analysis:
                pre_analysis = ai_response.pre_analysis
                response_data["pre_analysis"] = {
                    "enhanced_comments": [
                        {
                            "text": comment.text,
                            "category": comment.category,
                            "confidence": comment.confidence,
                            "business_impact": comment.business_impact
                        } for comment in getattr(pre_analysis, 'enhanced_comments', [])
                    ],
                    "logic_flows": [
                        {
                            "name": flow.name,
                            "type": flow.type,
                            "description": flow.description,
                            "business_purpose": flow.business_purpose,
                            "complexity_score": flow.complexity_score
                        } for flow in getattr(pre_analysis, 'logic_flows', [])
                    ],
                    "business_entities": [
                        {
                            "name": entity.name,
                            "type": entity.type,
                            "attributes": entity.attributes,
                            "regulatory_context": entity.regulatory_context
                        } for entity in getattr(pre_analysis, 'business_entities', [])
                    ],
                    "regulatory_compliance": getattr(pre_analysis, 'regulatory_compliance', {}),
                    "quality_metrics": getattr(pre_analysis, 'quality_metrics', {})
                }
            
            # Adicionar informações do programa
            response_data["program_info"] = {
                "name": program.name,
                "content_length": len(program.content),
                "line_count": len(program.content.split('\n')),
                "divisions": getattr(program, 'divisions', []),
                "sections": getattr(program, 'sections', []),
                "variables": getattr(program, 'variables', [])
            }
            
            # Salvar JSON
            json_filename = f"{program.name}_ai_response.json"
            json_filepath = os.path.join(self.json_dir, json_filename)
            
            with open(json_filepath, 'w', encoding='utf-8') as f:
                json.dump(response_data, f, indent=2, ensure_ascii=False, default=str)
            
            self.logger.info(f"JSON da resposta salvo: {json_filename}")
            
        except Exception as e:
            self.logger.error(f"Erro ao salvar JSON da resposta para {program.name}: {e}")
    
    def _generate_program_content(self, program: CobolProgram, 
                                ai_response: AIResponse,
                                phase_info: Optional[Dict[str, Any]] = None) -> str:
        """
        Gera o conteúdo da documentação para um programa.
        
        Args:
            program: Programa COBOL
            ai_response: Resposta da análise de IA
            phase_info: Informações de faseamento
            
        Returns:
            Conteúdo da documentação em Markdown
        """
        content = f"""# Análise do Programa COBOL: {program.name}

**Data da Análise:** {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}  
**Modelo de IA:** {ai_response.model}  
**Provedor:** {ai_response.provider}  
**Tokens Utilizados:** {ai_response.tokens_used}  

---

## Análise Funcional e Técnica

{ai_response.content}

---

## Transparência e Auditoria

### Informações da Análise

- **Status**: {'Sucesso' if ai_response.success else 'Falha'}
- **Modelo Utilizado**: {ai_response.model}
- **Provedor**: {ai_response.provider}
- **Tokens Processados**: {ai_response.tokens_used}
- **Timestamp**: {ai_response.timestamp.strftime('%d/%m/%Y %H:%M:%S') if ai_response.timestamp else 'N/A'}
- **Qualidade da Análise**: {'Alta' if ai_response.tokens_used > 1000 else 'Média' if ai_response.tokens_used > 500 else 'Básica'}

### Prompts Utilizados na Análise

"""
        
        # Adicionar prompts se disponíveis
        if hasattr(ai_response, 'prompts_used') and ai_response.prompts_used:
            prompts = ai_response.prompts_used
            
            if 'original_prompt' in prompts:
                content += f"""
#### Prompt Principal
```
{prompts['original_prompt'][:1000]}{'...' if len(prompts['original_prompt']) > 1000 else ''}
```
"""
            
            if 'system_prompt' in prompts:
                content += f"""
#### Contexto do Sistema
```
{prompts['system_prompt'][:500]}{'...' if len(prompts['system_prompt']) > 500 else ''}
```
"""
            
            if 'context_information' in prompts:
                context_info = prompts['context_information']
                content += f"""
#### Informações do Programa
- **Modelo Selecionado**: {prompts.get('model_selected', 'N/A')}
- **Copybooks Analisados**: {context_info.get('books_count', 0)}
- **Comentários Identificados**: {context_info.get('pre_analysis_comments', 0)}
- **Fluxos Lógicos**: {context_info.get('pre_analysis_flows', 0)}
- **Entidades de Negócio**: {context_info.get('pre_analysis_entities', 0)}
"""
        
        content += f"""

### Metadados Completos da Análise

- **Provedor**: {ai_response.provider}
- **Modelo**: {ai_response.model}
- **Tokens Processados**: {ai_response.tokens_used}
- **Timestamp**: {ai_response.timestamp.strftime('%Y-%m-%d %H:%M:%S') if ai_response.timestamp else 'N/A'}
- **Status**: {'Sucesso' if ai_response.success else 'Falha'}
- **Qualidade**: {'Excelente' if ai_response.tokens_used > 2000 else 'Boa' if ai_response.tokens_used > 1000 else 'Adequada'}
- **Profundidade**: {'Detalhada' if ai_response.tokens_used > 1500 else 'Padrão'}
- **Cobertura**: {'Total' if ai_response.tokens_used > 1000 else 'Parcial'}

### Arquivos de Análise Gerados

- **Relatório Principal**: `{program.name}.md` (este arquivo)
- **JSON da Resposta**: `ai_responses/{program.name}_ai_response.json`
- **Dados Estruturados**: Disponíveis no arquivo JSON para análise programática

### Metodologia e Limitações

**Processo Estruturado**: Esta análise foi realizada utilizando um processo estruturado de engenharia de prompt, com pré-análise automática do código e contexto enriquecido com informações de copybooks.

**Transparência**: Todos os prompts utilizados estão documentados neste relatório e os dados brutos da resposta estão disponíveis no arquivo JSON correspondente.

**Limitações**: A análise é baseada no conteúdo estático do código e pode não capturar comportamentos dinâmicos ou dependências externas não explícitas.

**Recomendações de Uso**: Para análises críticas, recomenda-se validação manual dos resultados e consulta aos dados estruturados no arquivo JSON.

---

**COBOL AI Engine v1.0.4** - Análise gerada automaticamente com transparência total
"""
        
        return content

    def generate_consolidated_report(self, programs: List[CobolProgram], 
                                   ai_responses: List[AIResponse],
                                   books: List[CobolBook] = None) -> str:
        """
        Gera relatório consolidado de todos os programas analisados.
        
        Args:
            programs: Lista de programas COBOL
            ai_responses: Lista de respostas de IA
            books: Lista de copybooks (opcional)
            
        Returns:
            Caminho do arquivo gerado
        """
        try:
            content = self._generate_consolidated_content(programs, ai_responses, books)
            
            filename = "relatorio_consolidado.md"
            filepath = os.path.join(self.output_dir, filename)
            
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)
            
            self.files_generated += 1
            
            self.logger.info(f"Relatório consolidado gerado: {filename}")
            return filepath
            
        except Exception as e:
            self.logger.error(f"Erro ao gerar relatório consolidado: {e}")
            return ""
    
    def _generate_consolidated_content(self, programs: List[CobolProgram], 
                                     ai_responses: List[AIResponse],
                                     books: List[CobolBook] = None) -> str:
        """
        Gera conteúdo do relatório consolidado.
        
        Args:
            programs: Lista de programas
            ai_responses: Lista de respostas
            books: Lista de copybooks
            
        Returns:
            Conteúdo em Markdown
        """
        successful_responses = [r for r in ai_responses if r.success]
        failed_responses = [r for r in ai_responses if not r.success]
        
        total_tokens = sum(r.tokens_used for r in successful_responses)
        avg_tokens = total_tokens / len(successful_responses) if successful_responses else 0
        
        content = f"""# Relatório Consolidado - Análise COBOL

**Data do Relatório:** {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}  
**Total de Programas:** {len(programs)}  
**Análises Bem-sucedidas:** {len(successful_responses)}  
**Análises com Falha:** {len(failed_responses)}  
**Taxa de Sucesso:** {(len(successful_responses)/len(ai_responses)*100):.1f}%  

---

## Resumo Executivo

**Programas Analisados:** {len(programs)}  
**Copybooks Utilizados:** {len(books) if books else 0}  
**Total de Tokens Processados:** {total_tokens:,}  
**Média de Tokens por Programa:** {avg_tokens:.0f}  

### Estatísticas por Modelo

"""
        
        # Agrupar por modelo
        models_stats = {}
        for response in successful_responses:
            model = response.model
            if model not in models_stats:
                models_stats[model] = {
                    'count': 0,
                    'total_tokens': 0,
                    'avg_tokens': 0
                }
            models_stats[model]['count'] += 1
            models_stats[model]['total_tokens'] += response.tokens_used
        
        for model, stats in models_stats.items():
            stats['avg_tokens'] = stats['total_tokens'] / stats['count']
            content += f"""
**{model}:**
- Análises: {stats['count']}
- Total de Tokens: {stats['total_tokens']:,}
- Média por Análise: {stats['avg_tokens']:.0f}
"""
        
        content += """

## Detalhes por Programa

"""
        
        for i, (program, response) in enumerate(zip(programs, ai_responses), 1):
            status = "✅ Sucesso" if response.success else "❌ Falha"
            content += f"""
### {i}. {program.name}

- **Status:** {status}
- **Modelo:** {response.model}
- **Tokens:** {response.tokens_used if response.success else 'N/A'}
- **Arquivo:** `{program.name}.md`
- **JSON:** `ai_responses/{program.name}_ai_response.json`

"""
        
        if failed_responses:
            content += """
## Análises com Falha

"""
            for response in failed_responses:
                content += f"""
- **Programa:** {getattr(response, 'program_name', 'N/A')}
- **Erro:** {response.error_message}
- **Modelo:** {response.model}

"""
        
        # Analisar programas para recomendações
        high_complexity_programs = [p for p in programs if getattr(p, 'line_count', 0) > 500]
        
        if high_complexity_programs:
            content += """
**Programas de Alta Complexidade:**
"""
            for program in high_complexity_programs[:5]:  # Top 5
                content += f"""
- **{program.name}**: {getattr(program, 'line_count', 0)} linhas
  - Recomendação: Considerar refatoração em módulos menores
  - Prioridade: Alta
  - Benefício: Melhoria na manutenibilidade

"""
        
        content += """
### Oportunidades de Otimização

**Consolidação de Funcionalidades:**
- Identificar funcionalidades duplicadas entre programas
- Criar bibliotecas compartilhadas para lógicas comuns
- Padronizar estruturas de dados similares

**Melhoria de Performance:**
- Revisar algoritmos em programas críticos
- Otimizar acesso a arquivos e datasets
- Implementar cache para dados frequentemente acessados

**Documentação e Governança:**
- Documentar regras de negócio identificadas
- Criar mapeamento de dependências atualizado
- Estabelecer padrões de codificação

### Próximos Passos Recomendados

1. **Análise Detalhada**: Executar análise aprofundada nos programas críticos
2. **Mapeamento Completo**: Documentar todas as dependências funcionais
3. **Plano de Modernização**: Criar roadmap de modernização baseado na criticidade
4. **Testes de Regressão**: Implementar testes para validar mudanças
5. **Monitoramento**: Estabelecer métricas de qualidade e performance

### Arquivos JSON para Análise Programática

Todos os dados estruturados das análises estão disponíveis no diretório `ai_responses/`:

"""
        
        for program in programs:
            content += f"- `{program.name}_ai_response.json`: Dados completos da análise do {program.name}\n"
        
        content += """

Estes arquivos JSON contêm:
- Resposta completa da IA (incluindo dados brutos)
- Prompts utilizados na análise
- Metadados de processamento
- Pré-análise estruturada
- Informações do programa

---

**COBOL AI Engine v1.0.4** - Relatório consolidado com transparência total
"""
        
        return content
