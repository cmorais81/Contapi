#!/usr/bin/env python3
"""
COBOL AI Engine v1.0.6 - Status Checker
Verificador de status e conectividade dos provedores de IA.
"""

import os
import sys
import logging
from typing import Dict, Any, List
from datetime import datetime

def check_providers_status(config_manager, provider_manager) -> None:
    """
    Verifica o status e conectividade de todos os provedores configurados.
    
    Args:
        config_manager: Gerenciador de configuração
        provider_manager: Gerenciador de provedores
    """
    print("=" * 60)
    print("COBOL AI Engine v1.0.6 - Status dos Provedores")
    print("=" * 60)
    print(f"Data/Hora: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}")
    print()
    
    # Verificar configuração geral
    print("📋 CONFIGURAÇÃO GERAL")
    print("-" * 30)
    
    config = config_manager.config
    ai_config = config.get('ai', {})
    default_models = ai_config.get('default_models', [])
    
    print(f"Arquivo de configuração: {config_manager.config_path}")
    print(f"Modelos padrão configurados: {len(default_models)}")
    for model in default_models:
        print(f"  - {model}")
    print()
    
    # Verificar variáveis de ambiente
    print("🔐 VARIÁVEIS DE AMBIENTE")
    print("-" * 30)
    
    env_vars = [
        'LUZIA_CLIENT_ID',
        'LUZIA_CLIENT_SECRET', 
        'OPENAI_API_KEY'
    ]
    
    for var in env_vars:
        value = os.getenv(var)
        if value:
            masked_value = f"{value[:8]}..." if len(value) > 8 else "***"
            print(f"✅ {var}: {masked_value}")
        else:
            print(f"❌ {var}: Não configurada")
    print()
    
    # Verificar provedores configurados
    print("🔌 PROVEDORES CONFIGURADOS")
    print("-" * 30)
    
    providers_config = config.get('providers', {})
    
    for provider_name, provider_config in providers_config.items():
        enabled = provider_config.get('enabled', False)
        status_icon = "✅" if enabled else "⚪"
        
        print(f"{status_icon} {provider_name.upper()}")
        print(f"   Status: {'Habilitado' if enabled else 'Desabilitado'}")
        
        if enabled:
            # Verificar configurações específicas do provedor
            if provider_name == 'luzia':
                check_luzia_config(provider_config)
            elif provider_name == 'openai':
                check_openai_config(provider_config)
            elif provider_name == 'enhanced_mock':
                check_mock_config(provider_config)
            
            # Verificar modelos configurados
            models = provider_config.get('models', {})
            if models:
                print(f"   Modelos configurados: {len(models)}")
                for model_name, model_config in models.items():
                    print(f"     - {model_name}: {model_config.get('name', 'N/A')}")
            else:
                print(f"   ⚠️  Nenhum modelo configurado")
        
        print()
    
    # Testar conectividade
    print("🔍 TESTE DE CONECTIVIDADE")
    print("-" * 30)
    
    test_connectivity(provider_manager, providers_config)
    
    print()
    print("=" * 60)
    print("Status check concluído!")
    print("=" * 60)

def check_luzia_config(config: Dict[str, Any]) -> None:
    """Verifica configuração específica da LuzIA."""
    client_id = config.get('client_id', '')
    client_secret = config.get('client_secret', '')
    auth_url = config.get('auth_url', '')
    api_url = config.get('api_url', '')
    
    # Verificar se as variáveis estão sendo expandidas
    if '${' in client_id:
        env_var = client_id.replace('${', '').replace('}', '')
        actual_value = os.getenv(env_var)
        if actual_value:
            print(f"   ✅ Client ID: Configurado via {env_var}")
        else:
            print(f"   ❌ Client ID: Variável {env_var} não encontrada")
    else:
        print(f"   ⚠️  Client ID: Valor fixo (não recomendado)")
    
    if '${' in client_secret:
        env_var = client_secret.replace('${', '').replace('}', '')
        actual_value = os.getenv(env_var)
        if actual_value:
            print(f"   ✅ Client Secret: Configurado via {env_var}")
        else:
            print(f"   ❌ Client Secret: Variável {env_var} não encontrada")
    else:
        print(f"   ⚠️  Client Secret: Valor fixo (não recomendado)")
    
    if auth_url:
        print(f"   ✅ Auth URL: {auth_url}")
    else:
        print(f"   ❌ Auth URL: Não configurada")
    
    if api_url:
        print(f"   ✅ API URL: {api_url}")
    else:
        print(f"   ❌ API URL: Não configurada")

def check_openai_config(config: Dict[str, Any]) -> None:
    """Verifica configuração específica do OpenAI."""
    api_key = os.getenv('OPENAI_API_KEY')
    
    if api_key:
        print(f"   ✅ API Key: Configurada")
    else:
        print(f"   ❌ API Key: Não configurada")
    
    models = config.get('models', {})
    if models:
        print(f"   ✅ Modelos: {list(models.keys())}")
    else:
        print(f"   ⚠️  Nenhum modelo configurado")

def check_mock_config(config: Dict[str, Any]) -> None:
    """Verifica configuração do provedor mock."""
    print(f"   ✅ Mock Provider: Sempre disponível para testes")
    
    models = config.get('models', {})
    if models:
        print(f"   ✅ Modelos: {list(models.keys())}")

def test_connectivity(provider_manager, providers_config: Dict[str, Any]) -> None:
    """Testa conectividade com os provedores habilitados."""
    
    for provider_name, provider_config in providers_config.items():
        if not provider_config.get('enabled', False):
            continue
        
        print(f"🔍 Testando {provider_name.upper()}...")
        
        try:
            if provider_name == 'luzia':
                result = test_luzia_connectivity(provider_config)
            elif provider_name == 'openai':
                result = test_openai_connectivity(provider_config)
            elif provider_name == 'enhanced_mock':
                result = test_mock_connectivity()
            else:
                result = {"success": False, "message": "Provedor não suportado para teste"}
            
            if result["success"]:
                print(f"   ✅ {result['message']}")
            else:
                print(f"   ❌ {result['message']}")
                
        except Exception as e:
            print(f"   ❌ Erro no teste: {str(e)}")
        
        print()

def test_luzia_connectivity(config: Dict[str, Any]) -> Dict[str, Any]:
    """Testa conectividade com a LuzIA."""
    import requests
    
    # Expandir variáveis de ambiente
    client_id = config.get('client_id', '')
    client_secret = config.get('client_secret', '')
    auth_url = config.get('auth_url', '')
    
    if '${' in client_id:
        env_var = client_id.replace('${', '').replace('}', '')
        client_id = os.getenv(env_var, '')
    
    if '${' in client_secret:
        env_var = client_secret.replace('${', '').replace('}', '')
        client_secret = os.getenv(env_var, '')
    
    if not client_id or not client_secret:
        return {"success": False, "message": "Credenciais não configuradas"}
    
    if not auth_url:
        return {"success": False, "message": "URL de autenticação não configurada"}
    
    try:
        # Teste básico de conectividade (sem autenticação real)
        response = requests.head(auth_url, timeout=10)
        if response.status_code in [200, 401, 405]:  # 401/405 são esperados sem credenciais
            return {"success": True, "message": "Conectividade OK - Endpoint acessível"}
        else:
            return {"success": False, "message": f"Endpoint retornou status {response.status_code}"}
    
    except requests.exceptions.Timeout:
        return {"success": False, "message": "Timeout na conexão"}
    except requests.exceptions.ConnectionError:
        return {"success": False, "message": "Erro de conexão - Endpoint inacessível"}
    except Exception as e:
        return {"success": False, "message": f"Erro inesperado: {str(e)}"}

def test_openai_connectivity(config: Dict[str, Any]) -> Dict[str, Any]:
    """Testa conectividade com OpenAI."""
    api_key = os.getenv('OPENAI_API_KEY')
    
    if not api_key:
        return {"success": False, "message": "API Key não configurada"}
    
    try:
        import openai
        # Teste básico sem fazer chamada real
        return {"success": True, "message": "Configuração OK - API Key presente"}
    except ImportError:
        return {"success": False, "message": "Biblioteca openai não instalada"}
    except Exception as e:
        return {"success": False, "message": f"Erro: {str(e)}"}

def test_mock_connectivity() -> Dict[str, Any]:
    """Testa provedor mock (sempre disponível)."""
    return {"success": True, "message": "Mock provider sempre disponível"}

# Adicionar ao main.py
def add_to_main():
    """Função para ser importada no main.py"""
    return check_providers_status
