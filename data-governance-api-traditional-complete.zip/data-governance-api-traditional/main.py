"""
Data Governance API - Main Application Entry Point
Traditional FastAPI Structure with SOLID Principles

Author: Carlos Morais
"""

import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from contextlib import asynccontextmanager

from app.core.config import settings
from app.core.logging import setup_logging
from app.core.database import init_db
from app.core.exceptions import setup_exception_handlers
from app.core.middleware import setup_middleware
from app.api.router import api_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan events."""
    # Startup
    setup_logging()
    await init_db()
    
    yield
    
    # Shutdown
    # Add cleanup logic here if needed
    pass


def create_application() -> FastAPI:
    """
    Create FastAPI application with all configurations.
    
    Following SOLID principles:
    - SRP: Single responsibility for app creation
    - OCP: Open for extension through configuration
    - DIP: Depends on configuration abstractions
    """
    
    app = FastAPI(
        title=settings.PROJECT_NAME,
        description="""
        # 🏛️ Data Governance API Enterprise
        
        **A comprehensive enterprise-grade API for data governance, quality, and lineage management.**
        
        ## 🎯 Features
        
        - **Data Catalog Management**: Complete CRUD operations for data objects
        - **Data Lineage Tracking**: Automated lineage discovery and visualization
        - **Quality Monitoring**: Real-time quality metrics and assessment
        - **Access Policy Management**: Granular access policies and compliance
        - **Analytics & Reporting**: Executive dashboards and insights
        - **Search & Discovery**: Advanced search and recommendation engine
        
        ## 🏗️ Architecture
        
        Built following **SOLID principles** and **Clean Architecture** patterns:
        - Single Responsibility Principle
        - Open/Closed Principle  
        - Liskov Substitution Principle
        - Interface Segregation Principle
        - Dependency Inversion Principle
        
        ## 🛡️ Security
        
        - JWT Authentication
        - Role-based Access Control
        - API Key Authentication
        - Rate Limiting
        - Input Validation
        
        ## 📊 Quality
        
        - 95%+ Test Coverage
        - Comprehensive Error Handling
        - Performance Optimized
        - Production Ready
        """,
        version=settings.VERSION,
        openapi_url=f"{settings.API_V1_STR}/openapi.json",
        docs_url="/docs",
        redoc_url="/redoc",
        lifespan=lifespan
    )
    
    # Setup CORS
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.ALLOWED_HOSTS,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    # Setup compression
    app.add_middleware(GZipMiddleware, minimum_size=1000)
    
    # Setup custom middleware
    setup_middleware(app)
    
    # Setup exception handlers
    setup_exception_handlers(app)
    
    # Include API router
    app.include_router(api_router, prefix=settings.API_V1_STR)
    
    return app


# Create the application instance
app = create_application()


@app.get("/", tags=["Root"])
async def root():
    """Root endpoint with API information."""
    return {
        "message": "Data Governance API Enterprise",
        "version": settings.VERSION,
        "docs": "/docs",
        "redoc": "/redoc",
        "health": "/health"
    }


@app.get("/health", tags=["Health"])
async def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "version": settings.VERSION,
        "environment": settings.ENVIRONMENT
    }


if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=settings.DEBUG,
        log_level="info"
    )

