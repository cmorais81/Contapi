# 🏛️ Data Governance API - Enterprise Edition

[![Python](https://img.shields.io/badge/Python-3.11+-blue.svg)](https://python.org)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.104+-green.svg)](https://fastapi.tiangolo.com)
[![PostgreSQL](https://img.shields.io/badge/PostgreSQL-15+-blue.svg)](https://postgresql.org)
[![Docker](https://img.shields.io/badge/Docker-Ready-blue.svg)](https://docker.com)
[![SOLID](https://img.shields.io/badge/SOLID-Principles-orange.svg)](https://en.wikipedia.org/wiki/SOLID)
[![OpenAPI](https://img.shields.io/badge/OpenAPI-3.0+-green.svg)](https://swagger.io/specification/)

Uma **API enterprise completa** para governança de dados, implementada seguindo rigorosamente os **princípios SOLID**, com **tratamento avançado de erros**, **documentação OpenAPI abrangente** e **arquitetura escalável**.

## 🎯 **Visão Geral**

A Data Governance API é uma solução completa para gerenciamento, catalogação e governança de dados em ambientes enterprise. Desenvolvida com foco em **qualidade**, **escalabilidade** e **manutenibilidade**, seguindo as melhores práticas da indústria.

### **🏆 Principais Características**

- ✅ **Arquitetura Clean**: Separação clara de responsabilidades
- ✅ **Princípios SOLID**: Implementação rigorosa dos 5 princípios
- ✅ **Tratamento de Erros**: Sistema hierárquico e robusto
- ✅ **Documentação OpenAPI**: Swagger interativo completo
- ✅ **Containerização**: Docker e Docker Compose prontos
- ✅ **Testes Abrangentes**: Cobertura de 95%+
- ✅ **Monitoramento**: Métricas e observabilidade
- ✅ **Segurança**: Autenticação e autorização granular

## 🚀 **Quick Start**

### **Pré-requisitos**

- Python 3.11+
- Docker & Docker Compose
- PostgreSQL 15+ (ou use Docker)
- Redis (ou use Docker)

### **Instalação Rápida com Docker**

```bash
# Clone o repositório
git clone <repository-url>
cd data-governance-api-traditional

# Inicie todos os serviços
docker-compose up -d

# Verifique o status
docker-compose ps

# Acesse a documentação
open http://localhost:8000/docs
```

### **Instalação Local**

```bash
# Clone o repositório
git clone <repository-url>
cd data-governance-api-traditional

# Crie ambiente virtual
python -m venv venv
source venv/bin/activate  # Linux/Mac
# ou
venv\Scripts\activate     # Windows

# Instale dependências
pip install -r requirements.txt

# Configure variáveis de ambiente
cp .env.example .env
# Edite .env com suas configurações

# Execute migrações
alembic upgrade head

# Inicie a aplicação
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

## 📊 **Arquitetura**

### **Estrutura do Projeto**

```
data-governance-api-traditional/
├── app/                          # 📁 Código principal da aplicação
│   ├── api/                      # 🌐 Camada de apresentação (FastAPI)
│   │   ├── endpoints/            # 🔗 Endpoints específicos
│   │   └── router.py             # 🚦 Router principal
│   ├── core/                     # ⚙️ Configurações e utilitários
│   │   ├── config.py             # 🔧 Configurações
│   │   ├── database.py           # 🗄️ Conexão com banco
│   │   ├── exceptions.py         # ❌ Tratamento de erros
│   │   └── logging.py            # 📝 Sistema de logs
│   ├── models/                   # 🏗️ Modelos de dados (SQLAlchemy)
│   ├── repositories/             # 🗃️ Camada de acesso a dados
│   ├── schemas/                  # 📋 DTOs (Pydantic)
│   ├── services/                 # 🔧 Lógica de negócio
│   └── utils/                    # 🛠️ Utilitários
├── tests/                        # 🧪 Testes automatizados
├── docs/                         # 📚 Documentação
├── scripts/                      # 📜 Scripts de automação
├── docker-compose.yml            # 🐳 Orquestração de containers
├── Dockerfile                    # 🐳 Imagem da aplicação
├── requirements.txt              # 📦 Dependências Python
└── README.md                     # 📖 Este arquivo
```

### **Princípios SOLID Implementados**

#### **🎯 Single Responsibility Principle (SRP)**
- Cada classe tem uma única responsabilidade
- Services focados em domínios específicos
- Repositories dedicados a acesso de dados

#### **🔓 Open/Closed Principle (OCP)**
- Extensível através de interfaces
- Novos endpoints sem modificar código existente
- Plugins e extensões suportados

#### **🔄 Liskov Substitution Principle (LSP)**
- Implementações substituíveis
- Interfaces bem definidas
- Polimorfismo respeitado

#### **🎭 Interface Segregation Principle (ISP)**
- Interfaces específicas e focadas
- Clientes dependem apenas do que usam
- Contratos granulares

#### **🔀 Dependency Inversion Principle (DIP)**
- Dependências baseadas em abstrações
- Injeção de dependência implementada
- Baixo acoplamento entre camadas

## 🔧 **Funcionalidades**

### **📊 Data Objects Management**
- ✅ CRUD completo com validações
- ✅ Busca avançada e filtros
- ✅ Classificação de segurança
- ✅ Gestão de metadados
- ✅ Versionamento de schema
- ✅ Analytics de uso

### **📋 Data Contracts**
- ✅ Definição de contratos
- ✅ Validação automática
- ✅ Versionamento
- ✅ Compliance tracking

### **🔗 Data Lineage**
- ✅ Rastreamento de origem
- ✅ Mapeamento de dependências
- ✅ Análise de impacto
- ✅ Visualização de grafos

### **📈 Quality Metrics**
- ✅ Métricas de qualidade
- ✅ Regras customizáveis
- ✅ Alertas automáticos
- ✅ Relatórios históricos

### **🔐 Access Policies**
- ✅ Políticas granulares
- ✅ Mascaramento de dados
- ✅ Auditoria de acesso
- ✅ Compliance automático

### **📊 Analytics & Reporting**
- ✅ Dashboards executivos
- ✅ Relatórios customizados
- ✅ Métricas de governança
- ✅ KPIs de qualidade

### **🔍 Search & Discovery**
- ✅ Busca full-text
- ✅ Busca semântica
- ✅ Catálogo de dados
- ✅ Recomendações

### **🔄 Sync & Integration**
- ✅ Integração Unity Catalog
- ✅ Conectores externos
- ✅ ETL de metadados
- ✅ APIs de sincronização

## 📚 **Documentação da API**

### **Swagger UI Interativo**
Acesse a documentação interativa em: `http://localhost:8000/docs`

### **ReDoc**
Documentação alternativa em: `http://localhost:8000/redoc`

### **OpenAPI Specification**
Especificação JSON em: `http://localhost:8000/openapi.json`

### **Principais Endpoints**

#### **Data Objects**
```http
GET    /api/v1/data-objects/           # Listar objetos
POST   /api/v1/data-objects/           # Criar objeto
GET    /api/v1/data-objects/{id}       # Obter objeto
PUT    /api/v1/data-objects/{id}       # Atualizar objeto
DELETE /api/v1/data-objects/{id}       # Deletar objeto
POST   /api/v1/data-objects/search     # Buscar objetos
POST   /api/v1/data-objects/bulk       # Operações em lote
```

#### **Data Contracts**
```http
GET    /api/v1/data-contracts/         # Listar contratos
POST   /api/v1/data-contracts/         # Criar contrato
GET    /api/v1/data-contracts/{id}     # Obter contrato
PUT    /api/v1/data-contracts/{id}     # Atualizar contrato
POST   /api/v1/data-contracts/{id}/validate  # Validar contrato
```

#### **Quality Metrics**
```http
GET    /api/v1/quality/metrics/        # Listar métricas
POST   /api/v1/quality/rules/          # Criar regra
GET    /api/v1/quality/reports/{id}    # Obter relatório
POST   /api/v1/quality/execute/{id}    # Executar verificação
```

#### **Health Check**
```http
GET    /health                         # Status da aplicação
GET    /health/detailed                # Status detalhado
```

## 🛠️ **Configuração**

### **Variáveis de Ambiente**

```bash
# Database
DATABASE_URL=postgresql://user:pass@localhost:5432/db_name
DATABASE_POOL_SIZE=20
DATABASE_MAX_OVERFLOW=30

# Redis
REDIS_URL=redis://localhost:6379/0
REDIS_POOL_SIZE=10

# Security
SECRET_KEY=your-super-secret-key-change-in-production
ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=30

# Application
ENVIRONMENT=development
LOG_LEVEL=INFO
DEBUG=false
API_V1_STR=/api/v1

# External Services
UNITY_CATALOG_URL=https://your-databricks-workspace
UNITY_CATALOG_TOKEN=your-access-token

# Monitoring
ENABLE_METRICS=true
METRICS_PORT=9090
```

### **Configuração do Banco de Dados**

```sql
-- Criar banco de dados
CREATE DATABASE data_governance;

-- Criar usuário
CREATE USER data_gov_user WITH PASSWORD 'secure_password';

-- Conceder permissões
GRANT ALL PRIVILEGES ON DATABASE data_governance TO data_gov_user;
```

## 🧪 **Testes**

### **Executar Todos os Testes**

```bash
# Testes unitários
pytest tests/unit/ -v

# Testes de integração
pytest tests/integration/ -v

# Todos os testes
pytest -v

# Com cobertura
pytest --cov=app --cov-report=html --cov-report=term
```

### **Testes por Categoria**

```bash
# Testes de endpoints
pytest tests/test_endpoints/ -v

# Testes de services
pytest tests/test_services/ -v

# Testes de repositories
pytest tests/test_repositories/ -v

# Testes de schemas
pytest tests/test_schemas/ -v
```

## 🐳 **Docker**

### **Desenvolvimento**

```bash
# Iniciar serviços de desenvolvimento
docker-compose up -d

# Ver logs
docker-compose logs -f api

# Parar serviços
docker-compose down
```

### **Produção**

```bash
# Build da imagem
docker build -t data-governance-api:latest .

# Executar container
docker run -d \
  --name data-governance-api \
  -p 8000:8000 \
  -e DATABASE_URL=postgresql://... \
  data-governance-api:latest
```

### **Profiles Disponíveis**

```bash
# Com Elasticsearch
docker-compose --profile search up -d

# Com Monitoring
docker-compose --profile monitoring up -d

# Produção com Nginx
docker-compose --profile production up -d

# Todos os serviços
docker-compose --profile search --profile monitoring --profile production up -d
```

## 📊 **Monitoramento**

### **Métricas Disponíveis**

- **Performance**: Tempo de resposta, throughput
- **Errors**: Taxa de erro, tipos de erro
- **Business**: Objetos catalogados, qualidade média
- **Infrastructure**: CPU, memória, conexões DB

### **Dashboards**

- **Grafana**: `http://localhost:3000` (admin/admin)
- **Prometheus**: `http://localhost:9090`
- **Kibana**: `http://localhost:5601`

### **Alertas**

- Alta taxa de erro (>5%)
- Tempo de resposta elevado (>2s)
- Baixa qualidade de dados (<80%)
- Falhas de sincronização

## 🔐 **Segurança**

### **Autenticação**

```python
# Obter token
POST /auth/login
{
  "username": "user@example.com",
  "password": "secure_password"
}

# Usar token
Authorization: Bearer <jwt_token>
```

### **Autorização**

- **RBAC**: Role-Based Access Control
- **Políticas granulares**: Por objeto e operação
- **Auditoria completa**: Todos os acessos logados

### **Classificação de Dados**

- **Public**: Dados públicos
- **Internal**: Uso interno
- **Confidential**: Dados confidenciais
- **Restricted**: Acesso restrito

## 🚀 **Deploy em Produção**

### **Kubernetes**

```yaml
# deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: data-governance-api
spec:
  replicas: 3
  selector:
    matchLabels:
      app: data-governance-api
  template:
    metadata:
      labels:
        app: data-governance-api
    spec:
      containers:
      - name: api
        image: data-governance-api:latest
        ports:
        - containerPort: 8000
        env:
        - name: DATABASE_URL
          valueFrom:
            secretKeyRef:
              name: db-secret
              key: url
```

### **AWS ECS**

```json
{
  "family": "data-governance-api",
  "networkMode": "awsvpc",
  "requiresCompatibilities": ["FARGATE"],
  "cpu": "1024",
  "memory": "2048",
  "containerDefinitions": [
    {
      "name": "api",
      "image": "your-ecr-repo/data-governance-api:latest",
      "portMappings": [
        {
          "containerPort": 8000,
          "protocol": "tcp"
        }
      ]
    }
  ]
}
```

## 🔧 **Troubleshooting**

### **Problemas Comuns**

#### **Erro de Conexão com Banco**
```bash
# Verificar conectividade
docker-compose exec api python -c "from app.core.database import engine; print('DB OK')"

# Verificar logs
docker-compose logs db
```

#### **Erro de Autenticação**
```bash
# Verificar token
curl -H "Authorization: Bearer <token>" http://localhost:8000/auth/verify

# Gerar novo token
curl -X POST http://localhost:8000/auth/login -d '{"username":"user","password":"pass"}'
```

#### **Performance Lenta**
```bash
# Verificar métricas
curl http://localhost:8000/metrics

# Verificar logs de performance
docker-compose logs api | grep "slow_query"
```

### **Logs Importantes**

```bash
# Logs da aplicação
docker-compose logs -f api

# Logs do banco
docker-compose logs -f db

# Logs do Redis
docker-compose logs -f redis

# Todos os logs
docker-compose logs -f
```

## 🤝 **Contribuição**

### **Desenvolvimento**

1. Fork o projeto
2. Crie uma branch: `git checkout -b feature/nova-funcionalidade`
3. Commit suas mudanças: `git commit -m 'Adiciona nova funcionalidade'`
4. Push para a branch: `git push origin feature/nova-funcionalidade`
5. Abra um Pull Request

### **Padrões de Código**

```bash
# Formatação
black app/ tests/

# Linting
flake8 app/ tests/

# Type checking
mypy app/

# Ordenação de imports
isort app/ tests/
```

### **Testes Obrigatórios**

- Cobertura mínima: 90%
- Testes unitários para novos services
- Testes de integração para novos endpoints
- Documentação atualizada

## 📄 **Licença**

Este projeto está licenciado sob a MIT License - veja o arquivo [LICENSE](LICENSE) para detalhes.

## 📞 **Suporte**

- **Email**: support@datagovernance.com
- **Slack**: #data-governance-api
- **Issues**: [GitHub Issues](https://github.com/your-org/data-governance-api/issues)
- **Wiki**: [Project Wiki](https://github.com/your-org/data-governance-api/wiki)

## 🎉 **Agradecimentos**

- FastAPI pela excelente framework
- SQLAlchemy pela robustez do ORM
- Pydantic pela validação de dados
- PostgreSQL pela confiabilidade
- Docker pela containerização
- Comunidade open source

---

**Data Governance API** - Transformando dados em valor através de governança inteligente 🚀

