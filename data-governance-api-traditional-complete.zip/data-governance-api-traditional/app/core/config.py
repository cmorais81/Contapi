"""
Core Configuration Module
Following SOLID principles and enterprise patterns

Author: Carlos Morais
"""

from typing import List, Optional, Any, Dict
from pydantic import BaseSettings, validator, Field
from functools import lru_cache
import os
from pathlib import Path


class Settings(BaseSettings):
    """
    Application settings following SOLID principles.
    
    SRP: Single responsibility for configuration management
    OCP: Open for extension through environment variables
    DIP: Depends on environment abstractions
    """
    
    # Project Information
    PROJECT_NAME: str = "Data Governance API Enterprise"
    VERSION: str = "2.0.0"
    DESCRIPTION: str = "Enterprise-grade API for data governance, quality, and lineage management"
    
    # Environment
    ENVIRONMENT: str = Field(default="development", env="ENVIRONMENT")
    DEBUG: bool = Field(default=True, env="DEBUG")
    
    # API Configuration
    API_V1_STR: str = "/api/v1"
    SECRET_KEY: str = Field(..., env="SECRET_KEY")
    ACCESS_TOKEN_EXPIRE_MINUTES: int = Field(default=60 * 24 * 8, env="ACCESS_TOKEN_EXPIRE_MINUTES")  # 8 days
    
    # CORS
    ALLOWED_HOSTS: List[str] = Field(default=["*"], env="ALLOWED_HOSTS")
    
    # Database Configuration
    DATABASE_URL: str = Field(..., env="DATABASE_URL")
    DATABASE_POOL_SIZE: int = Field(default=20, env="DATABASE_POOL_SIZE")
    DATABASE_MAX_OVERFLOW: int = Field(default=30, env="DATABASE_MAX_OVERFLOW")
    DATABASE_POOL_TIMEOUT: int = Field(default=30, env="DATABASE_POOL_TIMEOUT")
    DATABASE_POOL_RECYCLE: int = Field(default=3600, env="DATABASE_POOL_RECYCLE")
    
    # Redis Configuration
    REDIS_URL: str = Field(default="redis://localhost:6379", env="REDIS_URL")
    REDIS_CACHE_TTL: int = Field(default=3600, env="REDIS_CACHE_TTL")  # 1 hour
    
    # External Services
    DATABRICKS_HOST: Optional[str] = Field(default=None, env="DATABRICKS_HOST")
    DATABRICKS_TOKEN: Optional[str] = Field(default=None, env="DATABRICKS_TOKEN")
    DATABRICKS_CLUSTER_ID: Optional[str] = Field(default=None, env="DATABRICKS_CLUSTER_ID")
    
    # Unity Catalog Configuration
    UNITY_CATALOG_ENABLED: bool = Field(default=False, env="UNITY_CATALOG_ENABLED")
    UNITY_CATALOG_METASTORE: Optional[str] = Field(default=None, env="UNITY_CATALOG_METASTORE")
    
    # Logging Configuration
    LOG_LEVEL: str = Field(default="INFO", env="LOG_LEVEL")
    LOG_FORMAT: str = Field(default="json", env="LOG_FORMAT")  # json or text
    LOG_FILE: Optional[str] = Field(default=None, env="LOG_FILE")
    
    # Security Configuration
    BCRYPT_ROUNDS: int = Field(default=12, env="BCRYPT_ROUNDS")
    JWT_ALGORITHM: str = Field(default="HS256", env="JWT_ALGORITHM")
    
    # Rate Limiting
    RATE_LIMIT_ENABLED: bool = Field(default=True, env="RATE_LIMIT_ENABLED")
    RATE_LIMIT_REQUESTS: int = Field(default=1000, env="RATE_LIMIT_REQUESTS")
    RATE_LIMIT_WINDOW: int = Field(default=3600, env="RATE_LIMIT_WINDOW")  # 1 hour
    
    # Circuit Breaker Configuration
    CIRCUIT_BREAKER_ENABLED: bool = Field(default=True, env="CIRCUIT_BREAKER_ENABLED")
    CIRCUIT_BREAKER_FAILURE_THRESHOLD: int = Field(default=5, env="CIRCUIT_BREAKER_FAILURE_THRESHOLD")
    CIRCUIT_BREAKER_RECOVERY_TIMEOUT: int = Field(default=60, env="CIRCUIT_BREAKER_RECOVERY_TIMEOUT")
    
    # Retry Configuration
    RETRY_MAX_ATTEMPTS: int = Field(default=3, env="RETRY_MAX_ATTEMPTS")
    RETRY_BACKOFF_FACTOR: float = Field(default=2.0, env="RETRY_BACKOFF_FACTOR")
    RETRY_MAX_DELAY: int = Field(default=60, env="RETRY_MAX_DELAY")
    
    # Background Tasks
    CELERY_BROKER_URL: str = Field(default="redis://localhost:6379/0", env="CELERY_BROKER_URL")
    CELERY_RESULT_BACKEND: str = Field(default="redis://localhost:6379/0", env="CELERY_RESULT_BACKEND")
    
    # File Storage
    UPLOAD_DIR: str = Field(default="uploads", env="UPLOAD_DIR")
    MAX_UPLOAD_SIZE: int = Field(default=100 * 1024 * 1024, env="MAX_UPLOAD_SIZE")  # 100MB
    
    # Monitoring
    METRICS_ENABLED: bool = Field(default=True, env="METRICS_ENABLED")
    HEALTH_CHECK_TIMEOUT: int = Field(default=30, env="HEALTH_CHECK_TIMEOUT")
    
    # Data Quality Configuration
    QUALITY_CHECK_ENABLED: bool = Field(default=True, env="QUALITY_CHECK_ENABLED")
    QUALITY_CHECK_INTERVAL: int = Field(default=3600, env="QUALITY_CHECK_INTERVAL")  # 1 hour
    QUALITY_THRESHOLD_WARNING: float = Field(default=0.8, env="QUALITY_THRESHOLD_WARNING")
    QUALITY_THRESHOLD_CRITICAL: float = Field(default=0.6, env="QUALITY_THRESHOLD_CRITICAL")
    
    # Lineage Configuration
    LINEAGE_AUTO_DISCOVERY: bool = Field(default=True, env="LINEAGE_AUTO_DISCOVERY")
    LINEAGE_DISCOVERY_INTERVAL: int = Field(default=7200, env="LINEAGE_DISCOVERY_INTERVAL")  # 2 hours
    LINEAGE_MAX_DEPTH: int = Field(default=10, env="LINEAGE_MAX_DEPTH")
    
    # Compliance Configuration
    COMPLIANCE_FRAMEWORKS: List[str] = Field(
        default=["GDPR", "LGPD", "HIPAA", "SOX"], 
        env="COMPLIANCE_FRAMEWORKS"
    )
    AUDIT_LOG_RETENTION_DAYS: int = Field(default=2555, env="AUDIT_LOG_RETENTION_DAYS")  # 7 years
    
    @validator("ALLOWED_HOSTS", pre=True)
    def parse_allowed_hosts(cls, v):
        """Parse allowed hosts from string or list."""
        if isinstance(v, str):
            return [host.strip() for host in v.split(",")]
        return v
    
    @validator("COMPLIANCE_FRAMEWORKS", pre=True)
    def parse_compliance_frameworks(cls, v):
        """Parse compliance frameworks from string or list."""
        if isinstance(v, str):
            return [framework.strip() for framework in v.split(",")]
        return v
    
    @validator("DATABASE_URL")
    def validate_database_url(cls, v):
        """Validate database URL format."""
        if not v.startswith(("postgresql://", "postgresql+asyncpg://")):
            raise ValueError("DATABASE_URL must be a PostgreSQL URL")
        return v
    
    @validator("SECRET_KEY")
    def validate_secret_key(cls, v):
        """Validate secret key strength."""
        if len(v) < 32:
            raise ValueError("SECRET_KEY must be at least 32 characters long")
        return v
    
    @property
    def database_url_sync(self) -> str:
        """Get synchronous database URL for Alembic."""
        return self.DATABASE_URL.replace("+asyncpg", "")
    
    @property
    def is_production(self) -> bool:
        """Check if running in production environment."""
        return self.ENVIRONMENT.lower() == "production"
    
    @property
    def is_development(self) -> bool:
        """Check if running in development environment."""
        return self.ENVIRONMENT.lower() == "development"
    
    @property
    def is_testing(self) -> bool:
        """Check if running in testing environment."""
        return self.ENVIRONMENT.lower() == "testing"
    
    def get_database_config(self) -> Dict[str, Any]:
        """Get database configuration dictionary."""
        return {
            "url": self.DATABASE_URL,
            "pool_size": self.DATABASE_POOL_SIZE,
            "max_overflow": self.DATABASE_MAX_OVERFLOW,
            "pool_timeout": self.DATABASE_POOL_TIMEOUT,
            "pool_recycle": self.DATABASE_POOL_RECYCLE,
        }
    
    def get_redis_config(self) -> Dict[str, Any]:
        """Get Redis configuration dictionary."""
        return {
            "url": self.REDIS_URL,
            "cache_ttl": self.REDIS_CACHE_TTL,
        }
    
    def get_security_config(self) -> Dict[str, Any]:
        """Get security configuration dictionary."""
        return {
            "secret_key": self.SECRET_KEY,
            "algorithm": self.JWT_ALGORITHM,
            "access_token_expire_minutes": self.ACCESS_TOKEN_EXPIRE_MINUTES,
            "bcrypt_rounds": self.BCRYPT_ROUNDS,
        }
    
    def get_external_services_config(self) -> Dict[str, Any]:
        """Get external services configuration dictionary."""
        return {
            "databricks": {
                "host": self.DATABRICKS_HOST,
                "token": self.DATABRICKS_TOKEN,
                "cluster_id": self.DATABRICKS_CLUSTER_ID,
            },
            "unity_catalog": {
                "enabled": self.UNITY_CATALOG_ENABLED,
                "metastore": self.UNITY_CATALOG_METASTORE,
            }
        }
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = True


class DevelopmentSettings(Settings):
    """Development environment settings."""
    
    ENVIRONMENT: str = "development"
    DEBUG: bool = True
    LOG_LEVEL: str = "DEBUG"


class ProductionSettings(Settings):
    """Production environment settings."""
    
    ENVIRONMENT: str = "production"
    DEBUG: bool = False
    LOG_LEVEL: str = "INFO"
    ALLOWED_HOSTS: List[str] = []  # Must be explicitly set in production


class TestingSettings(Settings):
    """Testing environment settings."""
    
    ENVIRONMENT: str = "testing"
    DEBUG: bool = True
    LOG_LEVEL: str = "DEBUG"
    DATABASE_URL: str = "postgresql+asyncpg://test:test@localhost/test_db"
    REDIS_URL: str = "redis://localhost:6379/1"


@lru_cache()
def get_settings() -> Settings:
    """
    Get application settings with caching.
    
    Following SOLID principles:
    - SRP: Single responsibility for settings retrieval
    - OCP: Open for extension with new environment types
    - DIP: Depends on environment variable abstraction
    """
    environment = os.getenv("ENVIRONMENT", "development").lower()
    
    if environment == "production":
        return ProductionSettings()
    elif environment == "testing":
        return TestingSettings()
    else:
        return DevelopmentSettings()


# Global settings instance
settings = get_settings()

