"""
Data Objects Schemas (DTOs)
Following SOLID principles and Pydantic best practices

Author: Carlos Morais
"""

from typing import List, Optional, Dict, Any, Union
from pydantic import BaseModel, Field, validator, root_validator
from datetime import datetime
from uuid import UUID
from enum import Enum


# Enums for type safety
class DataObjectTypeEnum(str, Enum):
    """Data object types."""
    TABLE = "table"
    VIEW = "view"
    MATERIALIZED_VIEW = "materialized_view"
    FUNCTION = "function"
    PROCEDURE = "procedure"
    DATASET = "dataset"
    FILE = "file"
    API = "api"
    STREAM = "stream"


class SecurityClassificationEnum(str, Enum):
    """Security classification levels."""
    PUBLIC = "public"
    INTERNAL = "internal"
    CONFIDENTIAL = "confidential"
    RESTRICTED = "restricted"


class SensitivityLevelEnum(str, Enum):
    """Data sensitivity levels."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class SearchTypeEnum(str, Enum):
    """Search types."""
    TEXT = "text"
    SEMANTIC = "semantic"
    STRUCTURED = "structured"
    FUZZY = "fuzzy"


class BulkOperationEnum(str, Enum):
    """Bulk operation types."""
    CREATE = "create"
    UPDATE = "update"
    DELETE = "delete"
    IMPORT = "import"


# Base schemas following SOLID principles
class BaseSchema(BaseModel):
    """
    Base schema with common configuration.
    
    SRP: Single responsibility for base configuration
    OCP: Open for extension by other schemas
    """
    
    class Config:
        # Enable ORM mode for SQLAlchemy integration
        from_attributes = True
        # Use enum values instead of names
        use_enum_values = True
        # Validate assignment
        validate_assignment = True
        # Allow population by field name
        allow_population_by_field_name = True
        # JSON encoders for special types
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None,
            UUID: lambda v: str(v) if v else None
        }


class TimestampMixin(BaseModel):
    """
    Mixin for timestamp fields.
    
    SRP: Single responsibility for timestamp handling
    ISP: Interface segregation for timestamp functionality
    """
    
    data_criacao: Optional[datetime] = Field(None, description="Creation timestamp")
    data_atualizacao: Optional[datetime] = Field(None, description="Last update timestamp")


class AuditMixin(BaseModel):
    """
    Mixin for audit fields.
    
    SRP: Single responsibility for audit trail
    ISP: Interface segregation for audit functionality
    """
    
    criado_por: Optional[str] = Field(None, description="Created by user")
    atualizado_por: Optional[str] = Field(None, description="Last updated by user")
    versao: Optional[int] = Field(1, description="Version number")
    ativo: Optional[bool] = Field(True, description="Active status")


# Data Object Schemas
class DataObjectBase(BaseSchema):
    """
    Base data object schema.
    
    SRP: Single responsibility for common data object fields
    OCP: Open for extension by create/update schemas
    """
    
    nome: str = Field(..., min_length=1, max_length=255, description="Object name")
    nome_completo: Optional[str] = Field(None, max_length=500, description="Full qualified name")
    descricao: Optional[str] = Field(None, description="Object description")
    tipo: DataObjectTypeEnum = Field(..., description="Object type")
    formato: Optional[str] = Field(None, max_length=100, description="Data format")
    localizacao: str = Field(..., min_length=1, max_length=500, description="Object location/path")
    tamanho_bytes: Optional[int] = Field(None, ge=0, description="Size in bytes")
    numero_registros: Optional[int] = Field(None, ge=0, description="Number of records")
    
    # Foreign Keys
    data_contract_id: Optional[UUID] = Field(None, description="Associated data contract ID")
    entity_id: Optional[UUID] = Field(None, description="Associated entity ID")
    
    # Classification and Security
    classificacao_seguranca: SecurityClassificationEnum = Field(
        SecurityClassificationEnum.INTERNAL, 
        description="Security classification level"
    )
    nivel_sensibilidade: SensitivityLevelEnum = Field(
        SensitivityLevelEnum.LOW, 
        description="Data sensitivity level"
    )
    tags: Optional[List[str]] = Field(default_factory=list, description="Object tags")
    
    # Technical metadata
    schema_definicao: Optional[Dict[str, Any]] = Field(None, description="Schema definition")
    configuracao_acesso: Optional[Dict[str, Any]] = Field(None, description="Access configuration")
    metadados_tecnicos: Optional[Dict[str, Any]] = Field(None, description="Technical metadata")
    
    @validator('nome')
    def validate_nome(cls, v):
        """Validate object name."""
        if not v or v.isspace():
            raise ValueError('Object name cannot be empty or whitespace')
        
        # Check for invalid characters
        invalid_chars = ['<', '>', ':', '"', '|', '?', '*']
        if any(char in v for char in invalid_chars):
            raise ValueError(f'Object name cannot contain: {", ".join(invalid_chars)}')
        
        return v.strip()
    
    @validator('localizacao')
    def validate_localizacao(cls, v):
        """Validate object location."""
        if not v or v.isspace():
            raise ValueError('Object location cannot be empty or whitespace')
        return v.strip()
    
    @validator('tags')
    def validate_tags(cls, v):
        """Validate tags."""
        if v is None:
            return []
        
        # Remove duplicates and empty tags
        cleaned_tags = list(set(tag.strip() for tag in v if tag and tag.strip()))
        
        # Limit number of tags
        if len(cleaned_tags) > 20:
            raise ValueError('Maximum 20 tags allowed')
        
        # Validate tag format
        for tag in cleaned_tags:
            if len(tag) > 50:
                raise ValueError('Tag length cannot exceed 50 characters')
            if not tag.replace('_', '').replace('-', '').isalnum():
                raise ValueError('Tags can only contain alphanumeric characters, hyphens, and underscores')
        
        return cleaned_tags
    
    @root_validator
    def validate_security_consistency(cls, values):
        """Validate security classification consistency."""
        classificacao = values.get('classificacao_seguranca')
        sensibilidade = values.get('nivel_sensibilidade')
        
        # Business rule: Restricted data must have high or critical sensitivity
        if classificacao == SecurityClassificationEnum.RESTRICTED and sensibilidade not in [SensitivityLevelEnum.HIGH, SensitivityLevelEnum.CRITICAL]:
            raise ValueError('Restricted data must have high or critical sensitivity level')
        
        # Business rule: Critical sensitivity requires at least confidential classification
        if sensibilidade == SensitivityLevelEnum.CRITICAL and classificacao in [SecurityClassificationEnum.PUBLIC, SecurityClassificationEnum.INTERNAL]:
            raise ValueError('Critical sensitivity data must be classified as confidential or restricted')
        
        return values


class DataObjectCreate(DataObjectBase):
    """
    Schema for creating data objects.
    
    SRP: Single responsibility for creation validation
    LSP: Substitutable with base schema
    """
    
    # Override fields that are required for creation
    nome: str = Field(..., min_length=1, max_length=255, description="Object name (required)")
    tipo: DataObjectTypeEnum = Field(..., description="Object type (required)")
    localizacao: str = Field(..., min_length=1, max_length=500, description="Object location (required)")
    
    @root_validator
    def validate_creation_rules(cls, values):
        """Validate business rules for creation."""
        # Call parent validator first
        values = super().validate_security_consistency(values)
        
        # Business rule: Confidential data should have a data contract
        if (values.get('classificacao_seguranca') == SecurityClassificationEnum.CONFIDENTIAL and 
            not values.get('data_contract_id')):
            # This is a warning, not an error - allow creation but log warning
            pass
        
        return values


class DataObjectUpdate(BaseSchema):
    """
    Schema for updating data objects.
    
    SRP: Single responsibility for update validation
    OCP: Open for extension with new update fields
    """
    
    nome: Optional[str] = Field(None, min_length=1, max_length=255, description="Object name")
    nome_completo: Optional[str] = Field(None, max_length=500, description="Full qualified name")
    descricao: Optional[str] = Field(None, description="Object description")
    formato: Optional[str] = Field(None, max_length=100, description="Data format")
    localizacao: Optional[str] = Field(None, min_length=1, max_length=500, description="Object location")
    tamanho_bytes: Optional[int] = Field(None, ge=0, description="Size in bytes")
    numero_registros: Optional[int] = Field(None, ge=0, description="Number of records")
    
    # Foreign Keys
    data_contract_id: Optional[UUID] = Field(None, description="Associated data contract ID")
    entity_id: Optional[UUID] = Field(None, description="Associated entity ID")
    
    # Classification and Security
    classificacao_seguranca: Optional[SecurityClassificationEnum] = Field(None, description="Security classification")
    nivel_sensibilidade: Optional[SensitivityLevelEnum] = Field(None, description="Sensitivity level")
    tags: Optional[List[str]] = Field(None, description="Object tags")
    
    # Technical metadata
    schema_definicao: Optional[Dict[str, Any]] = Field(None, description="Schema definition")
    configuracao_acesso: Optional[Dict[str, Any]] = Field(None, description="Access configuration")
    metadados_tecnicos: Optional[Dict[str, Any]] = Field(None, description="Technical metadata")
    
    @validator('nome')
    def validate_nome(cls, v):
        """Validate object name if provided."""
        if v is not None:
            return DataObjectBase.__validators__['validate_nome'](cls, v)
        return v
    
    @validator('localizacao')
    def validate_localizacao(cls, v):
        """Validate object location if provided."""
        if v is not None:
            return DataObjectBase.__validators__['validate_localizacao'](cls, v)
        return v
    
    @validator('tags')
    def validate_tags(cls, v):
        """Validate tags if provided."""
        if v is not None:
            return DataObjectBase.__validators__['validate_tags'](cls, v)
        return v


class DataObjectResponse(DataObjectBase, TimestampMixin, AuditMixin):
    """
    Schema for data object responses.
    
    SRP: Single responsibility for response formatting
    LSP: Substitutable with base schema
    """
    
    id: UUID = Field(..., description="Unique identifier")
    score_qualidade: Optional[float] = Field(None, ge=0, le=1, description="Quality score (0-1)")
    ultima_verificacao_qualidade: Optional[datetime] = Field(None, description="Last quality check")
    frequencia_uso: Optional[int] = Field(0, ge=0, description="Usage frequency")
    ultimo_acesso: Optional[datetime] = Field(None, description="Last access timestamp")


# Search Schemas
class DataObjectSearchRequest(BaseSchema):
    """
    Schema for search requests.
    
    SRP: Single responsibility for search parameters
    OCP: Open for extension with new search types
    """
    
    query: str = Field(..., min_length=1, max_length=1000, description="Search query")
    search_type: SearchTypeEnum = Field(SearchTypeEnum.TEXT, description="Type of search")
    filters: Optional[Dict[str, Any]] = Field(default_factory=dict, description="Additional filters")
    sort_by: Optional[str] = Field("relevance", description="Sort field")
    sort_order: Optional[str] = Field("desc", regex="^(asc|desc)$", description="Sort order")
    skip: Optional[int] = Field(0, ge=0, description="Number of results to skip")
    limit: Optional[int] = Field(20, ge=1, le=100, description="Maximum results to return")
    include_facets: Optional[bool] = Field(True, description="Include search facets")
    
    @validator('query')
    def validate_query(cls, v):
        """Validate search query."""
        if not v or v.isspace():
            raise ValueError('Search query cannot be empty or whitespace')
        return v.strip()


class SearchFacet(BaseSchema):
    """Search facet information."""
    
    field: str = Field(..., description="Facet field name")
    values: List[Dict[str, Union[str, int]]] = Field(..., description="Facet values and counts")


class DataObjectSearchResult(BaseSchema):
    """Individual search result."""
    
    object: DataObjectResponse = Field(..., description="Data object")
    score: float = Field(..., ge=0, le=1, description="Relevance score")
    highlights: Optional[Dict[str, List[str]]] = Field(None, description="Search highlights")


class DataObjectSearchResponse(BaseSchema):
    """
    Schema for search responses.
    
    SRP: Single responsibility for search result formatting
    """
    
    query: str = Field(..., description="Original search query")
    total_results: int = Field(..., ge=0, description="Total number of results")
    results: List[DataObjectSearchResult] = Field(..., description="Search results")
    facets: Optional[List[SearchFacet]] = Field(None, description="Search facets")
    suggestions: Optional[List[str]] = Field(None, description="Search suggestions")
    execution_time_ms: Optional[int] = Field(None, description="Search execution time")


# Bulk Operation Schemas
class DataObjectBulkItem(BaseSchema):
    """Individual item for bulk operations."""
    
    id: Optional[UUID] = Field(None, description="Object ID (for update/delete)")
    data: Optional[Union[DataObjectCreate, DataObjectUpdate]] = Field(None, description="Object data")
    
    @root_validator
    def validate_bulk_item(cls, values):
        """Validate bulk item based on operation."""
        item_id = values.get('id')
        data = values.get('data')
        
        # For updates and deletes, ID is required
        # For creates, data is required
        # This validation will be context-dependent
        
        return values


class DataObjectBulkRequest(BaseSchema):
    """
    Schema for bulk operation requests.
    
    SRP: Single responsibility for bulk operation parameters
    """
    
    operation: BulkOperationEnum = Field(..., description="Bulk operation type")
    items: List[Union[DataObjectCreate, DataObjectUpdate, UUID]] = Field(
        ..., 
        min_items=1, 
        max_items=1000, 
        description="Items to process"
    )
    force: Optional[bool] = Field(False, description="Force operation (ignore some validations)")
    transaction: Optional[bool] = Field(True, description="Use transaction (rollback on any failure)")
    
    @validator('items')
    def validate_items(cls, v):
        """Validate bulk items."""
        if len(v) > 1000:
            raise ValueError('Maximum 1000 items allowed per bulk operation')
        return v


class DataObjectBulkResponse(BaseSchema):
    """
    Schema for bulk operation responses.
    
    SRP: Single responsibility for bulk result formatting
    """
    
    operation: BulkOperationEnum = Field(..., description="Operation performed")
    total_items: int = Field(..., ge=0, description="Total items processed")
    successful_items: int = Field(..., ge=0, description="Successfully processed items")
    failed_items: int = Field(..., ge=0, description="Failed items")
    results: List[Union[DataObjectResponse, Dict[str, Any]]] = Field(..., description="Operation results")
    errors: List[Dict[str, Any]] = Field(..., description="Error details for failed items")
    execution_time_ms: Optional[int] = Field(None, description="Total execution time")


# Metadata Schemas
class DataObjectMetadataResponse(BaseSchema):
    """
    Schema for detailed metadata responses.
    
    SRP: Single responsibility for metadata formatting
    """
    
    id: UUID = Field(..., description="Object ID")
    nome: str = Field(..., description="Object name")
    technical_metadata: Dict[str, Any] = Field(..., description="Technical metadata")
    business_metadata: Dict[str, Any] = Field(..., description="Business metadata")
    quality_summary: Optional[Dict[str, Any]] = Field(None, description="Quality metrics summary")
    lineage_summary: Optional[Dict[str, Any]] = Field(None, description="Lineage summary")
    usage_stats: Optional[Dict[str, Any]] = Field(None, description="Usage statistics")
    last_updated: datetime = Field(..., description="Last update timestamp")


class DataObjectSchemaResponse(BaseSchema):
    """Schema for object schema responses."""
    
    id: UUID = Field(..., description="Object ID")
    nome: str = Field(..., description="Object name")
    schema_definition: Dict[str, Any] = Field(..., description="Schema definition")
    schema_version: int = Field(..., description="Schema version")
    last_updated: datetime = Field(..., description="Last schema update")


class DataObjectUsageResponse(BaseSchema):
    """Schema for usage statistics responses."""
    
    id: UUID = Field(..., description="Object ID")
    nome: str = Field(..., description="Object name")
    period_days: int = Field(..., description="Statistics period in days")
    total_accesses: int = Field(..., ge=0, description="Total access count")
    unique_users: int = Field(..., ge=0, description="Unique user count")
    avg_daily_accesses: float = Field(..., ge=0, description="Average daily accesses")
    peak_access_day: Optional[datetime] = Field(None, description="Day with most accesses")
    access_trend: str = Field(..., description="Access trend (increasing/decreasing/stable)")


# Classification Schemas
class DataObjectClassificationRequest(BaseSchema):
    """
    Schema for data object classification requests.
    
    SRP: Single responsibility for classification parameters
    """
    
    classificacao_seguranca: SecurityClassificationEnum = Field(..., description="Security classification")
    nivel_sensibilidade: SensitivityLevelEnum = Field(..., description="Sensitivity level")
    categorias_dados: Optional[List[str]] = Field(None, description="Data categories (PII, financial, etc.)")
    frameworks_compliance: Optional[List[str]] = Field(None, description="Compliance frameworks")
    justificativa: Optional[str] = Field(None, max_length=1000, description="Classification justification")
    automatica: Optional[bool] = Field(False, description="Automatic classification flag")
    
    @validator('categorias_dados')
    def validate_categorias_dados(cls, v):
        """Validate data categories."""
        if v is None:
            return []
        
        valid_categories = [
            'PII', 'financial', 'health', 'biometric', 'location', 
            'behavioral', 'demographic', 'contact', 'identification'
        ]
        
        for category in v:
            if category not in valid_categories:
                raise ValueError(f'Invalid data category: {category}. Valid categories: {valid_categories}')
        
        return v
    
    @validator('frameworks_compliance')
    def validate_frameworks_compliance(cls, v):
        """Validate compliance frameworks."""
        if v is None:
            return []
        
        valid_frameworks = ['GDPR', 'LGPD', 'HIPAA', 'SOX', 'PCI-DSS', 'CCPA']
        
        for framework in v:
            if framework not in valid_frameworks:
                raise ValueError(f'Invalid compliance framework: {framework}. Valid frameworks: {valid_frameworks}')
        
        return v


# Error Response Schemas
class ErrorDetail(BaseSchema):
    """Individual error detail."""
    
    field: Optional[str] = Field(None, description="Field that caused the error")
    message: str = Field(..., description="Error message")
    code: Optional[str] = Field(None, description="Error code")


class ErrorResponse(BaseSchema):
    """
    Standardized error response schema.
    
    SRP: Single responsibility for error formatting
    """
    
    detail: str = Field(..., description="Error description")
    error_code: str = Field(..., description="Unique error code")
    error_id: str = Field(..., description="Unique error instance ID")
    timestamp: datetime = Field(..., description="Error timestamp")
    category: str = Field(..., description="Error category")
    severity: str = Field(..., description="Error severity")
    context: Optional[Dict[str, Any]] = Field(None, description="Additional error context")
    errors: Optional[List[ErrorDetail]] = Field(None, description="Detailed error list")
    suggestions: Optional[List[str]] = Field(None, description="Suggested solutions")


# Health Check Schemas
class HealthCheckResponse(BaseSchema):
    """Health check response schema."""
    
    status: str = Field(..., description="Overall health status")
    version: str = Field(..., description="API version")
    environment: str = Field(..., description="Environment name")
    timestamp: datetime = Field(..., description="Check timestamp")
    components: Optional[Dict[str, Dict[str, Any]]] = Field(None, description="Component health details")
    uptime_seconds: Optional[int] = Field(None, description="Uptime in seconds")


# Success Response Schemas
class SuccessResponse(BaseSchema):
    """Generic success response schema."""
    
    message: str = Field(..., description="Success message")
    data: Optional[Dict[str, Any]] = Field(None, description="Additional response data")
    timestamp: datetime = Field(default_factory=datetime.utcnow, description="Response timestamp")

