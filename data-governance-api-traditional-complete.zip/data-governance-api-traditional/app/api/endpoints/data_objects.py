"""
Data Objects API Endpoints
Following SOLID principles and enterprise patterns

Author: Carlos Morais
"""

from typing import List, Optional, Dict, Any
from fastapi import APIRouter, Depends, HTTPException, Query, Path, Body, status
from fastapi.responses import JSONResponse
from sqlalchemy.ext.asyncio import AsyncSession
from uuid import UUID

from app.core.database import get_db
from app.core.exceptions import (
    EntityNotFoundError,
    EntityAlreadyExistsError,
    ValidationError,
    BusinessRuleViolationError
)
from app.schemas.data_objects import (
    DataObjectCreate,
    DataObjectUpdate,
    DataObjectResponse,
    DataObjectSearchRequest,
    DataObjectSearchResponse,
    DataObjectBulkRequest,
    DataObjectBulkResponse,
    DataObjectMetadataResponse,
    DataObjectSchemaResponse,
    DataObjectUsageResponse,
    DataObjectClassificationRequest
)
from app.services.data_objects import DataObjectService
from app.services.auth import get_current_user
from app.models import User

router = APIRouter()


@router.post(
    "/",
    response_model=DataObjectResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create Data Object",
    description="""
    Create a new data object in the governance catalog.
    
    **Features:**
    - Automatic schema validation
    - Metadata enrichment
    - Security classification
    - Audit trail creation
    
    **Business Rules:**
    - Name must be unique within the same location
    - Data contract must exist if specified
    - Entity must exist if specified
    - Classification level must be valid
    
    **Example:**
    ```json
    {
        "nome": "customer_data",
        "descricao": "Customer master data table",
        "tipo": "table",
        "localizacao": "catalog.schema.customer_data",
        "classificacao_seguranca": "confidential",
        "data_contract_id": "123e4567-e89b-12d3-a456-426614174000"
    }
    ```
    """,
    responses={
        201: {"description": "Data object created successfully"},
        400: {"description": "Invalid input data"},
        409: {"description": "Data object already exists"},
        422: {"description": "Validation error"}
    }
)
async def create_data_object(
    data_object: DataObjectCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
) -> DataObjectResponse:
    """
    Create a new data object.
    
    Following SOLID principles:
    - SRP: Single responsibility for object creation
    - DIP: Depends on service abstraction
    """
    try:
        service = DataObjectService(db)
        result = await service.create_data_object(data_object, current_user.id)
        return result
    except EntityAlreadyExistsError as e:
        raise HTTPException(status_code=409, detail=str(e))
    except ValidationError as e:
        raise HTTPException(status_code=422, detail=str(e))
    except BusinessRuleViolationError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.get(
    "/{object_id}",
    response_model=DataObjectResponse,
    summary="Get Data Object",
    description="""
    Retrieve a specific data object by ID.
    
    **Features:**
    - Complete object metadata
    - Related entities information
    - Quality metrics summary
    - Access permissions
    
    **Returns:**
    - Full data object details
    - Associated data contract
    - Entity information
    - Quality score and metrics
    - Usage statistics
    """,
    responses={
        200: {"description": "Data object retrieved successfully"},
        404: {"description": "Data object not found"},
        403: {"description": "Access denied"}
    }
)
async def get_data_object(
    object_id: UUID = Path(..., description="Data object unique identifier"),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
) -> DataObjectResponse:
    """
    Get data object by ID.
    
    Following SOLID principles:
    - SRP: Single responsibility for object retrieval
    - LSP: Substitutable with different retrieval methods
    """
    try:
        service = DataObjectService(db)
        result = await service.get_data_object(object_id, current_user.id)
        return result
    except EntityNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))


@router.put(
    "/{object_id}",
    response_model=DataObjectResponse,
    summary="Update Data Object",
    description="""
    Update an existing data object.
    
    **Features:**
    - Partial updates supported
    - Version control
    - Change tracking
    - Validation enforcement
    
    **Business Rules:**
    - Only authorized users can update
    - Critical fields require approval
    - Schema changes must be validated
    - Audit trail is maintained
    """,
    responses={
        200: {"description": "Data object updated successfully"},
        404: {"description": "Data object not found"},
        400: {"description": "Invalid update data"},
        403: {"description": "Update not authorized"}
    }
)
async def update_data_object(
    object_id: UUID = Path(..., description="Data object unique identifier"),
    data_object: DataObjectUpdate = Body(...),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
) -> DataObjectResponse:
    """
    Update data object.
    
    Following SOLID principles:
    - SRP: Single responsibility for object updates
    - OCP: Open for extension with new update types
    """
    try:
        service = DataObjectService(db)
        result = await service.update_data_object(object_id, data_object, current_user.id)
        return result
    except EntityNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except ValidationError as e:
        raise HTTPException(status_code=422, detail=str(e))
    except BusinessRuleViolationError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.delete(
    "/{object_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete Data Object",
    description="""
    Delete a data object from the catalog.
    
    **Features:**
    - Soft delete by default
    - Dependency checking
    - Cascade options
    - Audit trail preservation
    
    **Business Rules:**
    - Check for dependent objects
    - Preserve lineage relationships
    - Maintain audit history
    - Require proper authorization
    """,
    responses={
        204: {"description": "Data object deleted successfully"},
        404: {"description": "Data object not found"},
        409: {"description": "Cannot delete due to dependencies"},
        403: {"description": "Delete not authorized"}
    }
)
async def delete_data_object(
    object_id: UUID = Path(..., description="Data object unique identifier"),
    force: bool = Query(False, description="Force delete ignoring dependencies"),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Delete data object.
    
    Following SOLID principles:
    - SRP: Single responsibility for object deletion
    - ISP: Interface segregation for delete options
    """
    try:
        service = DataObjectService(db)
        await service.delete_data_object(object_id, current_user.id, force)
        return JSONResponse(
            status_code=204,
            content={"message": "Data object deleted successfully"}
        )
    except EntityNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except BusinessRuleViolationError as e:
        raise HTTPException(status_code=409, detail=str(e))


@router.get(
    "/",
    response_model=List[DataObjectResponse],
    summary="List Data Objects",
    description="""
    List data objects with filtering and pagination.
    
    **Features:**
    - Advanced filtering
    - Sorting options
    - Pagination support
    - Search capabilities
    
    **Filters:**
    - Type (table, view, etc.)
    - Classification level
    - Data contract
    - Entity
    - Quality score range
    - Tags
    """,
    responses={
        200: {"description": "Data objects retrieved successfully"}
    }
)
async def list_data_objects(
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(100, ge=1, le=1000, description="Maximum number of records to return"),
    tipo: Optional[str] = Query(None, description="Filter by object type"),
    classificacao: Optional[str] = Query(None, description="Filter by security classification"),
    data_contract_id: Optional[UUID] = Query(None, description="Filter by data contract"),
    entity_id: Optional[UUID] = Query(None, description="Filter by entity"),
    min_quality_score: Optional[float] = Query(None, ge=0, le=1, description="Minimum quality score"),
    tags: Optional[str] = Query(None, description="Filter by tags (comma-separated)"),
    sort_by: Optional[str] = Query("nome", description="Sort field"),
    sort_order: Optional[str] = Query("asc", regex="^(asc|desc)$", description="Sort order"),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
) -> List[DataObjectResponse]:
    """
    List data objects with filters.
    
    Following SOLID principles:
    - SRP: Single responsibility for object listing
    - OCP: Open for extension with new filters
    """
    service = DataObjectService(db)
    filters = {
        "tipo": tipo,
        "classificacao_seguranca": classificacao,
        "data_contract_id": data_contract_id,
        "entity_id": entity_id,
        "min_quality_score": min_quality_score,
        "tags": tags.split(",") if tags else None
    }
    
    result = await service.list_data_objects(
        skip=skip,
        limit=limit,
        filters=filters,
        sort_by=sort_by,
        sort_order=sort_order,
        user_id=current_user.id
    )
    return result


@router.post(
    "/search",
    response_model=DataObjectSearchResponse,
    summary="Search Data Objects",
    description="""
    Advanced search for data objects.
    
    **Features:**
    - Full-text search
    - Semantic search
    - Faceted search
    - Relevance scoring
    - Search suggestions
    
    **Search Types:**
    - Text: Full-text search in names and descriptions
    - Semantic: AI-powered semantic search
    - Structured: Field-specific search
    - Fuzzy: Typo-tolerant search
    """,
    responses={
        200: {"description": "Search completed successfully"}
    }
)
async def search_data_objects(
    search_request: DataObjectSearchRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
) -> DataObjectSearchResponse:
    """
    Search data objects.
    
    Following SOLID principles:
    - SRP: Single responsibility for search operations
    - OCP: Open for extension with new search types
    """
    service = DataObjectService(db)
    result = await service.search_data_objects(search_request, current_user.id)
    return result


@router.post(
    "/bulk",
    response_model=DataObjectBulkResponse,
    summary="Bulk Operations",
    description="""
    Perform bulk operations on data objects.
    
    **Operations:**
    - Create multiple objects
    - Update multiple objects
    - Delete multiple objects
    - Import from external sources
    
    **Features:**
    - Transaction support
    - Error handling per item
    - Progress tracking
    - Rollback on failure
    """,
    responses={
        200: {"description": "Bulk operation completed"},
        207: {"description": "Bulk operation completed with some errors"}
    }
)
async def bulk_operations(
    bulk_request: DataObjectBulkRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
) -> DataObjectBulkResponse:
    """
    Bulk operations on data objects.
    
    Following SOLID principles:
    - SRP: Single responsibility for bulk operations
    - OCP: Open for extension with new operation types
    """
    service = DataObjectService(db)
    result = await service.bulk_operations(bulk_request, current_user.id)
    return result


@router.get(
    "/{object_id}/metadata",
    response_model=DataObjectMetadataResponse,
    summary="Get Object Metadata",
    description="""
    Get detailed metadata for a data object.
    
    **Includes:**
    - Technical metadata
    - Business metadata
    - Schema information
    - Statistics
    - Lineage summary
    """,
    responses={
        200: {"description": "Metadata retrieved successfully"},
        404: {"description": "Data object not found"}
    }
)
async def get_object_metadata(
    object_id: UUID = Path(..., description="Data object unique identifier"),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
) -> DataObjectMetadataResponse:
    """Get object metadata."""
    try:
        service = DataObjectService(db)
        result = await service.get_object_metadata(object_id, current_user.id)
        return result
    except EntityNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))


@router.put(
    "/{object_id}/metadata",
    response_model=DataObjectMetadataResponse,
    summary="Update Object Metadata",
    description="""
    Update metadata for a data object.
    
    **Features:**
    - Selective metadata updates
    - Version control
    - Validation
    - Audit trail
    """,
    responses={
        200: {"description": "Metadata updated successfully"},
        404: {"description": "Data object not found"},
        422: {"description": "Invalid metadata"}
    }
)
async def update_object_metadata(
    object_id: UUID = Path(..., description="Data object unique identifier"),
    metadata: Dict[str, Any] = Body(..., description="Metadata to update"),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
) -> DataObjectMetadataResponse:
    """Update object metadata."""
    try:
        service = DataObjectService(db)
        result = await service.update_object_metadata(object_id, metadata, current_user.id)
        return result
    except EntityNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except ValidationError as e:
        raise HTTPException(status_code=422, detail=str(e))


@router.get(
    "/{object_id}/schema",
    response_model=DataObjectSchemaResponse,
    summary="Get Object Schema",
    description="""
    Get schema definition for a data object.
    
    **Features:**
    - Complete schema structure
    - Column metadata
    - Data types
    - Constraints
    - Relationships
    """,
    responses={
        200: {"description": "Schema retrieved successfully"},
        404: {"description": "Data object not found"}
    }
)
async def get_object_schema(
    object_id: UUID = Path(..., description="Data object unique identifier"),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
) -> DataObjectSchemaResponse:
    """Get object schema."""
    try:
        service = DataObjectService(db)
        result = await service.get_object_schema(object_id, current_user.id)
        return result
    except EntityNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))


@router.put(
    "/{object_id}/schema",
    response_model=DataObjectSchemaResponse,
    summary="Update Object Schema",
    description="""
    Update schema definition for a data object.
    
    **Features:**
    - Schema evolution tracking
    - Compatibility validation
    - Impact analysis
    - Version management
    """,
    responses={
        200: {"description": "Schema updated successfully"},
        404: {"description": "Data object not found"},
        422: {"description": "Invalid schema"}
    }
)
async def update_object_schema(
    object_id: UUID = Path(..., description="Data object unique identifier"),
    schema: Dict[str, Any] = Body(..., description="Schema definition"),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
) -> DataObjectSchemaResponse:
    """Update object schema."""
    try:
        service = DataObjectService(db)
        result = await service.update_object_schema(object_id, schema, current_user.id)
        return result
    except EntityNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except ValidationError as e:
        raise HTTPException(status_code=422, detail=str(e))


@router.get(
    "/{object_id}/usage",
    response_model=DataObjectUsageResponse,
    summary="Get Usage Statistics",
    description="""
    Get usage statistics for a data object.
    
    **Metrics:**
    - Access frequency
    - User patterns
    - Query patterns
    - Performance metrics
    - Popularity trends
    """,
    responses={
        200: {"description": "Usage statistics retrieved successfully"},
        404: {"description": "Data object not found"}
    }
)
async def get_object_usage(
    object_id: UUID = Path(..., description="Data object unique identifier"),
    days: int = Query(30, ge=1, le=365, description="Number of days for statistics"),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
) -> DataObjectUsageResponse:
    """Get object usage statistics."""
    try:
        service = DataObjectService(db)
        result = await service.get_object_usage(object_id, days, current_user.id)
        return result
    except EntityNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))


@router.get(
    "/popular",
    response_model=List[DataObjectResponse],
    summary="Get Popular Objects",
    description="""
    Get most popular data objects.
    
    **Ranking Factors:**
    - Access frequency
    - User count
    - Query volume
    - Recent activity
    """,
    responses={
        200: {"description": "Popular objects retrieved successfully"}
    }
)
async def get_popular_objects(
    limit: int = Query(10, ge=1, le=100, description="Number of objects to return"),
    days: int = Query(30, ge=1, le=365, description="Time period for popularity calculation"),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
) -> List[DataObjectResponse]:
    """Get popular objects."""
    service = DataObjectService(db)
    result = await service.get_popular_objects(limit, days, current_user.id)
    return result


@router.get(
    "/recent",
    response_model=List[DataObjectResponse],
    summary="Get Recent Activity",
    description="""
    Get recently created or updated data objects.
    
    **Activity Types:**
    - Recently created
    - Recently updated
    - Recently accessed
    - Recent schema changes
    """,
    responses={
        200: {"description": "Recent activity retrieved successfully"}
    }
)
async def get_recent_activity(
    limit: int = Query(10, ge=1, le=100, description="Number of objects to return"),
    activity_type: str = Query("updated", regex="^(created|updated|accessed|schema_changed)$", description="Type of activity"),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
) -> List[DataObjectResponse]:
    """Get recent activity."""
    service = DataObjectService(db)
    result = await service.get_recent_activity(limit, activity_type, current_user.id)
    return result


@router.post(
    "/{object_id}/classify",
    response_model=DataObjectResponse,
    summary="Classify Data Object",
    description="""
    Classify a data object for security and governance.
    
    **Classification Types:**
    - Security level (public, internal, confidential, restricted)
    - Sensitivity level (low, medium, high, critical)
    - Data categories (PII, financial, health, etc.)
    - Compliance frameworks (GDPR, LGPD, HIPAA, etc.)
    
    **Features:**
    - Automatic classification suggestions
    - Manual override capability
    - Audit trail
    - Policy enforcement
    """,
    responses={
        200: {"description": "Object classified successfully"},
        404: {"description": "Data object not found"},
        422: {"description": "Invalid classification"}
    }
)
async def classify_data_object(
    object_id: UUID = Path(..., description="Data object unique identifier"),
    classification: DataObjectClassificationRequest = Body(...),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
) -> DataObjectResponse:
    """Classify data object."""
    try:
        service = DataObjectService(db)
        result = await service.classify_data_object(object_id, classification, current_user.id)
        return result
    except EntityNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except ValidationError as e:
        raise HTTPException(status_code=422, detail=str(e))

