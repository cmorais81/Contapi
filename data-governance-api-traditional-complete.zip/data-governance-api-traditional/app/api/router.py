"""
Main API Router
Following SOLID principles and enterprise patterns

Author: Carlos Morais
"""

from fastapi import APIRouter
from app.api.endpoints import (
    data_contracts,
    data_objects,
    data_lineage,
    quality_metrics,
    access_policies,
    analytics,
    search,
    sync,
    health
)

# Main API router
api_router = APIRouter()

# Include all endpoint routers
api_router.include_router(
    health.router,
    prefix="/health",
    tags=["Health Check"]
)

api_router.include_router(
    data_contracts.router,
    prefix="/data-contracts",
    tags=["Data Contracts"]
)

api_router.include_router(
    data_objects.router,
    prefix="/data-objects",
    tags=["Data Objects"]
)

api_router.include_router(
    data_lineage.router,
    prefix="/lineage",
    tags=["Data Lineage"]
)

api_router.include_router(
    quality_metrics.router,
    prefix="/quality",
    tags=["Quality Metrics"]
)

api_router.include_router(
    access_policies.router,
    prefix="/policies",
    tags=["Access Policies"]
)

api_router.include_router(
    analytics.router,
    prefix="/analytics",
    tags=["Analytics & Reporting"]
)

api_router.include_router(
    search.router,
    prefix="/search",
    tags=["Search & Discovery"]
)

api_router.include_router(
    sync.router,
    prefix="/sync",
    tags=["Sync & Integration"]
)

