"""
Data Objects Service
Following SOLID principles and enterprise patterns

Author: Carlos Morais
"""

from typing import List, Optional, Dict, Any
from uuid import UUID
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, or_, func, desc, asc
from sqlalchemy.orm import selectinload
from datetime import datetime, timedelta

from app.models import DataObject, DataContract, Entity, QualityMetric, AccessLog
from app.repositories.data_objects import DataObjectRepository
from app.repositories.data_contracts import DataContractRepository
from app.repositories.entities import EntityRepository
from app.schemas.data_objects import (
    DataObjectCreate,
    DataObjectUpdate,
    DataObjectResponse,
    DataObjectSearchRequest,
    DataObjectSearchResponse,
    DataObjectBulkRequest,
    DataObjectBulkResponse,
    DataObjectMetadataResponse,
    DataObjectSchemaResponse,
    DataObjectUsageResponse,
    DataObjectClassificationRequest
)
from app.core.exceptions import (
    EntityNotFoundError,
    EntityAlreadyExistsError,
    ValidationError,
    BusinessRuleViolationError,
    AuthorizationError
)
from app.core.logging import get_logger
from app.services.auth import AuthService
from app.services.quality import QualityService
from app.services.lineage import LineageService
from app.services.search import SearchService

logger = get_logger(__name__)


class DataObjectService:
    """
    Data Object Service implementing SOLID principles.
    
    SRP: Single responsibility for data object business logic
    OCP: Open for extension with new operations
    LSP: Substitutable with different implementations
    ISP: Interface segregation for different client needs
    DIP: Depends on repository abstractions
    """
    
    def __init__(self, db: AsyncSession):
        """
        Initialize service with dependencies.
        
        Following DIP: Depends on abstractions, not concretions
        """
        self.db = db
        self.data_object_repo = DataObjectRepository(db)
        self.data_contract_repo = DataContractRepository(db)
        self.entity_repo = EntityRepository(db)
        self.auth_service = AuthService(db)
        self.quality_service = QualityService(db)
        self.lineage_service = LineageService(db)
        self.search_service = SearchService(db)
    
    async def create_data_object(
        self, 
        data_object_data: DataObjectCreate, 
        user_id: str
    ) -> DataObjectResponse:
        """
        Create a new data object.
        
        Following SRP: Single responsibility for object creation
        Business Rules:
        - Name must be unique within location
        - Data contract must exist if specified
        - Entity must exist if specified
        - User must have create permissions
        """
        logger.info(f"Creating data object: {data_object_data.nome}", extra={"user_id": user_id})
        
        # Validate authorization
        if not await self.auth_service.can_create_data_object(user_id):
            raise AuthorizationError("User not authorized to create data objects")
        
        # Check if object already exists
        existing = await self.data_object_repo.get_by_name_and_location(
            data_object_data.nome, 
            data_object_data.localizacao
        )
        if existing:
            raise EntityAlreadyExistsError(
                f"Data object '{data_object_data.nome}' already exists at location '{data_object_data.localizacao}'"
            )
        
        # Validate data contract if specified
        if data_object_data.data_contract_id:
            data_contract = await self.data_contract_repo.get_by_id(data_object_data.data_contract_id)
            if not data_contract:
                raise ValidationError(f"Data contract {data_object_data.data_contract_id} not found")
            
            # Check if contract is active
            if data_contract.status != "active":
                raise BusinessRuleViolationError(f"Data contract must be active, current status: {data_contract.status}")
        
        # Validate entity if specified
        if data_object_data.entity_id:
            entity = await self.entity_repo.get_by_id(data_object_data.entity_id)
            if not entity:
                raise ValidationError(f"Entity {data_object_data.entity_id} not found")
        
        # Validate business rules
        await self._validate_business_rules(data_object_data)
        
        # Create the object
        data_object = await self.data_object_repo.create(data_object_data, user_id)
        
        # Initialize quality metrics
        await self.quality_service.initialize_quality_metrics(data_object.id)
        
        # Discover lineage if enabled
        await self.lineage_service.discover_lineage(data_object.id)
        
        # Index for search
        await self.search_service.index_data_object(data_object.id)
        
        logger.info(f"Data object created successfully: {data_object.id}", extra={"user_id": user_id})
        
        return await self._build_response(data_object)
    
    async def get_data_object(self, object_id: UUID, user_id: str) -> DataObjectResponse:
        """
        Get data object by ID.
        
        Following SRP: Single responsibility for object retrieval
        """
        logger.debug(f"Retrieving data object: {object_id}", extra={"user_id": user_id})
        
        data_object = await self.data_object_repo.get_by_id(object_id)
        if not data_object:
            raise EntityNotFoundError(f"Data object {object_id} not found")
        
        # Check authorization
        if not await self.auth_service.can_read_data_object(user_id, object_id):
            raise AuthorizationError("User not authorized to read this data object")
        
        # Log access
        await self._log_access(object_id, user_id, "read")
        
        return await self._build_response(data_object)
    
    async def update_data_object(
        self, 
        object_id: UUID, 
        update_data: DataObjectUpdate, 
        user_id: str
    ) -> DataObjectResponse:
        """
        Update data object.
        
        Following SRP: Single responsibility for object updates
        """
        logger.info(f"Updating data object: {object_id}", extra={"user_id": user_id})
        
        data_object = await self.data_object_repo.get_by_id(object_id)
        if not data_object:
            raise EntityNotFoundError(f"Data object {object_id} not found")
        
        # Check authorization
        if not await self.auth_service.can_update_data_object(user_id, object_id):
            raise AuthorizationError("User not authorized to update this data object")
        
        # Validate update data
        await self._validate_update_rules(data_object, update_data, user_id)
        
        # Update the object
        updated_object = await self.data_object_repo.update(object_id, update_data, user_id)
        
        # Update quality metrics if schema changed
        if update_data.schema_definicao:
            await self.quality_service.update_quality_metrics(object_id)
        
        # Update lineage if location changed
        if update_data.localizacao and update_data.localizacao != data_object.localizacao:
            await self.lineage_service.update_lineage(object_id)
        
        # Re-index for search
        await self.search_service.reindex_data_object(object_id)
        
        # Log access
        await self._log_access(object_id, user_id, "update")
        
        logger.info(f"Data object updated successfully: {object_id}", extra={"user_id": user_id})
        
        return await self._build_response(updated_object)
    
    async def delete_data_object(self, object_id: UUID, user_id: str, force: bool = False):
        """
        Delete data object.
        
        Following SRP: Single responsibility for object deletion
        """
        logger.info(f"Deleting data object: {object_id}", extra={"user_id": user_id, "force": force})
        
        data_object = await self.data_object_repo.get_by_id(object_id)
        if not data_object:
            raise EntityNotFoundError(f"Data object {object_id} not found")
        
        # Check authorization
        if not await self.auth_service.can_delete_data_object(user_id, object_id):
            raise AuthorizationError("User not authorized to delete this data object")
        
        # Check dependencies unless force delete
        if not force:
            dependencies = await self.lineage_service.get_dependencies(object_id)
            if dependencies:
                raise BusinessRuleViolationError(
                    f"Cannot delete data object with {len(dependencies)} dependencies. Use force=true to override."
                )
        
        # Soft delete the object
        await self.data_object_repo.soft_delete(object_id, user_id)
        
        # Remove from search index
        await self.search_service.remove_from_index(object_id)
        
        # Log access
        await self._log_access(object_id, user_id, "delete")
        
        logger.info(f"Data object deleted successfully: {object_id}", extra={"user_id": user_id})
    
    async def list_data_objects(
        self,
        skip: int = 0,
        limit: int = 100,
        filters: Optional[Dict[str, Any]] = None,
        sort_by: str = "nome",
        sort_order: str = "asc",
        user_id: str = None
    ) -> List[DataObjectResponse]:
        """
        List data objects with filtering and pagination.
        
        Following SRP: Single responsibility for object listing
        """
        logger.debug(f"Listing data objects", extra={
            "user_id": user_id, 
            "skip": skip, 
            "limit": limit, 
            "filters": filters
        })
        
        # Get accessible objects for user
        accessible_ids = await self.auth_service.get_accessible_data_objects(user_id)
        
        # Apply filters and get objects
        data_objects = await self.data_object_repo.list_with_filters(
            skip=skip,
            limit=limit,
            filters=filters,
            sort_by=sort_by,
            sort_order=sort_order,
            accessible_ids=accessible_ids
        )
        
        # Build responses
        responses = []
        for obj in data_objects:
            response = await self._build_response(obj)
            responses.append(response)
        
        return responses
    
    async def search_data_objects(
        self, 
        search_request: DataObjectSearchRequest, 
        user_id: str
    ) -> DataObjectSearchResponse:
        """
        Search data objects.
        
        Following SRP: Single responsibility for search operations
        """
        logger.info(f"Searching data objects", extra={
            "user_id": user_id, 
            "query": search_request.query,
            "search_type": search_request.search_type
        })
        
        # Get accessible objects for user
        accessible_ids = await self.auth_service.get_accessible_data_objects(user_id)
        
        # Perform search
        search_results = await self.search_service.search_data_objects(
            search_request, 
            accessible_ids
        )
        
        return search_results
    
    async def bulk_operations(
        self, 
        bulk_request: DataObjectBulkRequest, 
        user_id: str
    ) -> DataObjectBulkResponse:
        """
        Perform bulk operations.
        
        Following SRP: Single responsibility for bulk operations
        """
        logger.info(f"Performing bulk operation: {bulk_request.operation}", extra={
            "user_id": user_id, 
            "item_count": len(bulk_request.items)
        })
        
        results = []
        errors = []
        
        for item in bulk_request.items:
            try:
                if bulk_request.operation == "create":
                    result = await self.create_data_object(item, user_id)
                    results.append(result)
                elif bulk_request.operation == "update":
                    result = await self.update_data_object(item.id, item, user_id)
                    results.append(result)
                elif bulk_request.operation == "delete":
                    await self.delete_data_object(item.id, user_id, bulk_request.force)
                    results.append({"id": item.id, "status": "deleted"})
                else:
                    raise ValidationError(f"Unknown operation: {bulk_request.operation}")
            
            except Exception as e:
                error = {
                    "item": item.dict() if hasattr(item, 'dict') else str(item),
                    "error": str(e),
                    "error_type": type(e).__name__
                }
                errors.append(error)
                logger.error(f"Bulk operation error", extra={"error": error, "user_id": user_id})
        
        return DataObjectBulkResponse(
            operation=bulk_request.operation,
            total_items=len(bulk_request.items),
            successful_items=len(results),
            failed_items=len(errors),
            results=results,
            errors=errors
        )
    
    async def get_object_metadata(self, object_id: UUID, user_id: str) -> DataObjectMetadataResponse:
        """Get detailed metadata for object."""
        data_object = await self.data_object_repo.get_by_id(object_id)
        if not data_object:
            raise EntityNotFoundError(f"Data object {object_id} not found")
        
        if not await self.auth_service.can_read_data_object(user_id, object_id):
            raise AuthorizationError("User not authorized to read this data object")
        
        # Get additional metadata
        quality_summary = await self.quality_service.get_quality_summary(object_id)
        lineage_summary = await self.lineage_service.get_lineage_summary(object_id)
        usage_stats = await self._get_usage_stats(object_id, 30)
        
        return DataObjectMetadataResponse(
            id=data_object.id,
            nome=data_object.nome,
            technical_metadata=data_object.metadados_tecnicos or {},
            business_metadata={
                "descricao": data_object.descricao,
                "tags": data_object.tags or [],
                "classificacao_seguranca": data_object.classificacao_seguranca,
                "nivel_sensibilidade": data_object.nivel_sensibilidade
            },
            quality_summary=quality_summary,
            lineage_summary=lineage_summary,
            usage_stats=usage_stats,
            last_updated=data_object.data_atualizacao
        )
    
    async def update_object_metadata(
        self, 
        object_id: UUID, 
        metadata: Dict[str, Any], 
        user_id: str
    ) -> DataObjectMetadataResponse:
        """Update object metadata."""
        data_object = await self.data_object_repo.get_by_id(object_id)
        if not data_object:
            raise EntityNotFoundError(f"Data object {object_id} not found")
        
        if not await self.auth_service.can_update_data_object(user_id, object_id):
            raise AuthorizationError("User not authorized to update this data object")
        
        # Update metadata
        await self.data_object_repo.update_metadata(object_id, metadata, user_id)
        
        # Re-index for search
        await self.search_service.reindex_data_object(object_id)
        
        return await self.get_object_metadata(object_id, user_id)
    
    async def get_object_schema(self, object_id: UUID, user_id: str) -> DataObjectSchemaResponse:
        """Get object schema."""
        data_object = await self.data_object_repo.get_by_id(object_id)
        if not data_object:
            raise EntityNotFoundError(f"Data object {object_id} not found")
        
        if not await self.auth_service.can_read_data_object(user_id, object_id):
            raise AuthorizationError("User not authorized to read this data object")
        
        return DataObjectSchemaResponse(
            id=data_object.id,
            nome=data_object.nome,
            schema_definition=data_object.schema_definicao or {},
            schema_version=data_object.versao,
            last_updated=data_object.data_atualizacao
        )
    
    async def update_object_schema(
        self, 
        object_id: UUID, 
        schema: Dict[str, Any], 
        user_id: str
    ) -> DataObjectSchemaResponse:
        """Update object schema."""
        data_object = await self.data_object_repo.get_by_id(object_id)
        if not data_object:
            raise EntityNotFoundError(f"Data object {object_id} not found")
        
        if not await self.auth_service.can_update_data_object(user_id, object_id):
            raise AuthorizationError("User not authorized to update this data object")
        
        # Validate schema compatibility
        await self._validate_schema_compatibility(data_object.schema_definicao, schema)
        
        # Update schema
        await self.data_object_repo.update_schema(object_id, schema, user_id)
        
        # Update quality metrics
        await self.quality_service.update_quality_metrics(object_id)
        
        return await self.get_object_schema(object_id, user_id)
    
    async def get_object_usage(self, object_id: UUID, days: int, user_id: str) -> DataObjectUsageResponse:
        """Get object usage statistics."""
        data_object = await self.data_object_repo.get_by_id(object_id)
        if not data_object:
            raise EntityNotFoundError(f"Data object {object_id} not found")
        
        if not await self.auth_service.can_read_data_object(user_id, object_id):
            raise AuthorizationError("User not authorized to read this data object")
        
        usage_stats = await self._get_usage_stats(object_id, days)
        
        return DataObjectUsageResponse(
            id=data_object.id,
            nome=data_object.nome,
            period_days=days,
            **usage_stats
        )
    
    async def get_popular_objects(self, limit: int, days: int, user_id: str) -> List[DataObjectResponse]:
        """Get popular objects."""
        accessible_ids = await self.auth_service.get_accessible_data_objects(user_id)
        popular_objects = await self.data_object_repo.get_popular_objects(limit, days, accessible_ids)
        
        responses = []
        for obj in popular_objects:
            response = await self._build_response(obj)
            responses.append(response)
        
        return responses
    
    async def get_recent_activity(self, limit: int, activity_type: str, user_id: str) -> List[DataObjectResponse]:
        """Get recent activity."""
        accessible_ids = await self.auth_service.get_accessible_data_objects(user_id)
        recent_objects = await self.data_object_repo.get_recent_activity(limit, activity_type, accessible_ids)
        
        responses = []
        for obj in recent_objects:
            response = await self._build_response(obj)
            responses.append(response)
        
        return responses
    
    async def classify_data_object(
        self, 
        object_id: UUID, 
        classification: DataObjectClassificationRequest, 
        user_id: str
    ) -> DataObjectResponse:
        """Classify data object."""
        data_object = await self.data_object_repo.get_by_id(object_id)
        if not data_object:
            raise EntityNotFoundError(f"Data object {object_id} not found")
        
        if not await self.auth_service.can_classify_data_object(user_id, object_id):
            raise AuthorizationError("User not authorized to classify this data object")
        
        # Apply classification
        await self.data_object_repo.update_classification(object_id, classification, user_id)
        
        # Update access policies based on classification
        await self.auth_service.update_access_policies_for_classification(object_id, classification)
        
        # Re-index for search
        await self.search_service.reindex_data_object(object_id)
        
        updated_object = await self.data_object_repo.get_by_id(object_id)
        return await self._build_response(updated_object)
    
    # Private helper methods
    async def _validate_business_rules(self, data_object_data: DataObjectCreate):
        """Validate business rules for data object creation."""
        # Rule: Confidential data must have a data contract
        if (data_object_data.classificacao_seguranca == "confidential" and 
            not data_object_data.data_contract_id):
            raise BusinessRuleViolationError(
                "Confidential data objects must be associated with a data contract"
            )
        
        # Rule: High sensitivity data must have an entity
        if (data_object_data.nivel_sensibilidade == "high" and 
            not data_object_data.entity_id):
            raise BusinessRuleViolationError(
                "High sensitivity data objects must be associated with an entity"
            )
    
    async def _validate_update_rules(self, data_object: DataObject, update_data: DataObjectUpdate, user_id: str):
        """Validate business rules for data object updates."""
        # Rule: Cannot downgrade security classification without approval
        if (update_data.classificacao_seguranca and 
            self._is_security_downgrade(data_object.classificacao_seguranca, update_data.classificacao_seguranca)):
            
            has_approval = await self.auth_service.has_security_downgrade_approval(user_id, data_object.id)
            if not has_approval:
                raise BusinessRuleViolationError(
                    "Security classification downgrade requires approval"
                )
    
    async def _validate_schema_compatibility(self, current_schema: Dict[str, Any], new_schema: Dict[str, Any]):
        """Validate schema compatibility."""
        # Implement schema compatibility validation logic
        # This is a simplified version - in practice, you'd have more sophisticated validation
        if current_schema and new_schema:
            current_columns = set(current_schema.get("columns", {}).keys())
            new_columns = set(new_schema.get("columns", {}).keys())
            
            # Check for removed columns
            removed_columns = current_columns - new_columns
            if removed_columns:
                raise ValidationError(f"Cannot remove columns: {removed_columns}")
    
    def _is_security_downgrade(self, current: str, new: str) -> bool:
        """Check if security classification is being downgraded."""
        levels = {"public": 1, "internal": 2, "confidential": 3, "restricted": 4}
        return levels.get(new, 0) < levels.get(current, 0)
    
    async def _build_response(self, data_object: DataObject) -> DataObjectResponse:
        """Build response object from data object entity."""
        # Get related data
        quality_score = await self.quality_service.get_current_quality_score(data_object.id)
        
        return DataObjectResponse(
            id=data_object.id,
            nome=data_object.nome,
            nome_completo=data_object.nome_completo,
            descricao=data_object.descricao,
            tipo=data_object.tipo,
            formato=data_object.formato,
            localizacao=data_object.localizacao,
            tamanho_bytes=data_object.tamanho_bytes,
            numero_registros=data_object.numero_registros,
            data_contract_id=data_object.data_contract_id,
            entity_id=data_object.entity_id,
            classificacao_seguranca=data_object.classificacao_seguranca,
            nivel_sensibilidade=data_object.nivel_sensibilidade,
            tags=data_object.tags or [],
            schema_definicao=data_object.schema_definicao,
            score_qualidade=quality_score,
            ultima_verificacao_qualidade=data_object.ultima_verificacao_qualidade,
            frequencia_uso=data_object.frequencia_uso,
            ultimo_acesso=data_object.ultimo_acesso,
            data_criacao=data_object.data_criacao,
            data_atualizacao=data_object.data_atualizacao,
            criado_por=data_object.criado_por,
            atualizado_por=data_object.atualizado_por,
            versao=data_object.versao,
            ativo=data_object.ativo
        )
    
    async def _log_access(self, object_id: UUID, user_id: str, action: str):
        """Log access to data object."""
        # This would typically be handled by a separate audit service
        # For now, we'll just log it
        logger.info(f"Data object access logged", extra={
            "object_id": str(object_id),
            "user_id": user_id,
            "action": action,
            "timestamp": datetime.utcnow().isoformat()
        })
    
    async def _get_usage_stats(self, object_id: UUID, days: int) -> Dict[str, Any]:
        """Get usage statistics for object."""
        # This would query the access logs and compute statistics
        # For now, return mock data
        return {
            "total_accesses": 0,
            "unique_users": 0,
            "avg_daily_accesses": 0.0,
            "peak_access_day": None,
            "access_trend": "stable"
        }

