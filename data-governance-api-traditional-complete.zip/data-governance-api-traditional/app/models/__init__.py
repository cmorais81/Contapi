"""
Data Models for Data Governance API
Following SOLID principles and enterprise patterns

Author: Carlos Morais
"""

from sqlalchemy import (
    Column, Integer, String, Text, DateTime, Boolean, Float, JSON,
    ForeignKey, Index, UniqueConstraint, CheckConstraint, Enum as SQLEnum
)
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship, validates
from sqlalchemy.dialects.postgresql import UUID, JSONB
from datetime import datetime
from typing import Optional, Dict, Any, List
import uuid
import enum


# Base class for all models
Base = declarative_base()


class TimestampMixin:
    """
    Mixin for timestamp fields following SOLID principles.
    
    SRP: Single responsibility for timestamp management
    OCP: Open for extension with additional timestamp fields
    """
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    data_criacao = Column(DateTime, default=datetime.utcnow, nullable=False)
    data_atualizacao = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)


class AuditMixin:
    """
    Mixin for audit fields following SOLID principles.
    
    SRP: Single responsibility for audit trail
    ISP: Interface segregation for audit functionality
    """
    
    criado_por = Column(String(255), nullable=True)
    atualizado_por = Column(String(255), nullable=True)
    versao = Column(Integer, default=1, nullable=False)
    ativo = Column(Boolean, default=True, nullable=False)


# Enums for type safety
class DataObjectType(enum.Enum):
    """Data object types."""
    TABLE = "table"
    VIEW = "view"
    MATERIALIZED_VIEW = "materialized_view"
    FUNCTION = "function"
    PROCEDURE = "procedure"
    DATASET = "dataset"
    FILE = "file"
    API = "api"
    STREAM = "stream"


class QualityStatus(enum.Enum):
    """Quality status levels."""
    EXCELLENT = "excellent"
    GOOD = "good"
    FAIR = "fair"
    POOR = "poor"
    UNKNOWN = "unknown"


class PolicyType(enum.Enum):
    """Access policy types."""
    ALLOW = "allow"
    DENY = "deny"
    MASK = "mask"
    FILTER = "filter"
    AUDIT = "audit"


class LineageType(enum.Enum):
    """Lineage relationship types."""
    DIRECT = "direct"
    DERIVED = "derived"
    AGGREGATED = "aggregated"
    TRANSFORMED = "transformed"
    COPIED = "copied"
    REFERENCED = "referenced"


# Core Models
class DataContract(Base, TimestampMixin, AuditMixin):
    """
    Data Contract model following SOLID principles.
    
    SRP: Single responsibility for data contract management
    OCP: Open for extension with new contract types
    """
    
    __tablename__ = "data_contracts"
    
    nome = Column(String(255), nullable=False)
    descricao = Column(Text)
    versao_contrato = Column(String(50), nullable=False)
    status = Column(String(50), default="draft", nullable=False)
    proprietario = Column(String(255), nullable=False)
    aprovador = Column(String(255))
    data_aprovacao = Column(DateTime)
    data_vigencia_inicio = Column(DateTime)
    data_vigencia_fim = Column(DateTime)
    
    # JSON fields for flexibility
    especificacao = Column(JSONB)
    metadados = Column(JSONB)
    configuracao = Column(JSONB)
    
    # Relationships
    data_objects = relationship("DataObject", back_populates="data_contract")
    quality_rules = relationship("QualityRule", back_populates="data_contract")
    
    # Constraints
    __table_args__ = (
        UniqueConstraint('nome', 'versao_contrato', name='uq_contract_name_version'),
        CheckConstraint("status IN ('draft', 'active', 'deprecated', 'retired')", name='ck_contract_status'),
        Index('ix_data_contracts_nome', 'nome'),
        Index('ix_data_contracts_status', 'status'),
        Index('ix_data_contracts_proprietario', 'proprietario'),
    )
    
    @validates('status')
    def validate_status(self, key, status):
        """Validate contract status."""
        valid_statuses = ['draft', 'active', 'deprecated', 'retired']
        if status not in valid_statuses:
            raise ValueError(f"Status must be one of: {valid_statuses}")
        return status


class Entity(Base, TimestampMixin, AuditMixin):
    """
    Entity model for business entities.
    
    SRP: Single responsibility for entity management
    LSP: Substitutable with other entity types
    """
    
    __tablename__ = "entities"
    
    nome = Column(String(255), nullable=False, unique=True)
    descricao = Column(Text)
    dominio = Column(String(255), nullable=False)
    categoria = Column(String(255))
    criticidade = Column(String(50), default="medium")
    proprietario_negocio = Column(String(255))
    proprietario_tecnico = Column(String(255))
    
    # JSON fields
    atributos = Column(JSONB)
    regras_negocio = Column(JSONB)
    glossario = Column(JSONB)
    
    # Relationships
    data_objects = relationship("DataObject", back_populates="entity")
    
    # Constraints
    __table_args__ = (
        CheckConstraint("criticidade IN ('low', 'medium', 'high', 'critical')", name='ck_entity_criticidade'),
        Index('ix_entities_nome', 'nome'),
        Index('ix_entities_dominio', 'dominio'),
        Index('ix_entities_criticidade', 'criticidade'),
    )


class DataObject(Base, TimestampMixin, AuditMixin):
    """
    Data Object model for data assets.
    
    SRP: Single responsibility for data object management
    OCP: Open for extension with new object types
    """
    
    __tablename__ = "data_objects"
    
    nome = Column(String(255), nullable=False)
    nome_completo = Column(String(500))
    descricao = Column(Text)
    tipo = Column(SQLEnum(DataObjectType), nullable=False)
    formato = Column(String(100))
    localizacao = Column(String(500))
    tamanho_bytes = Column(Integer)
    numero_registros = Column(Integer)
    
    # Foreign Keys
    data_contract_id = Column(UUID(as_uuid=True), ForeignKey("data_contracts.id"))
    entity_id = Column(UUID(as_uuid=True), ForeignKey("entities.id"))
    
    # Classification and Security
    classificacao_seguranca = Column(String(50), default="internal")
    nivel_sensibilidade = Column(String(50), default="low")
    tags = Column(JSONB)
    
    # Technical metadata
    schema_definicao = Column(JSONB)
    configuracao_acesso = Column(JSONB)
    metadados_tecnicos = Column(JSONB)
    
    # Quality and Usage
    score_qualidade = Column(Float)
    ultima_verificacao_qualidade = Column(DateTime)
    frequencia_uso = Column(Integer, default=0)
    ultimo_acesso = Column(DateTime)
    
    # Relationships
    data_contract = relationship("DataContract", back_populates="data_objects")
    entity = relationship("Entity", back_populates="data_objects")
    quality_metrics = relationship("QualityMetric", back_populates="data_object")
    lineage_source = relationship("DataLineage", foreign_keys="DataLineage.source_object_id", back_populates="source_object")
    lineage_target = relationship("DataLineage", foreign_keys="DataLineage.target_object_id", back_populates="target_object")
    access_logs = relationship("AccessLog", back_populates="data_object")
    
    # Constraints
    __table_args__ = (
        UniqueConstraint('nome', 'localizacao', name='uq_object_name_location'),
        CheckConstraint("classificacao_seguranca IN ('public', 'internal', 'confidential', 'restricted')", name='ck_object_classification'),
        CheckConstraint("nivel_sensibilidade IN ('low', 'medium', 'high', 'critical')", name='ck_object_sensitivity'),
        CheckConstraint("score_qualidade >= 0 AND score_qualidade <= 1", name='ck_object_quality_score'),
        Index('ix_data_objects_nome', 'nome'),
        Index('ix_data_objects_tipo', 'tipo'),
        Index('ix_data_objects_classificacao', 'classificacao_seguranca'),
        Index('ix_data_objects_qualidade', 'score_qualidade'),
    )


class DataLineage(Base, TimestampMixin, AuditMixin):
    """
    Data Lineage model for tracking data flow.
    
    SRP: Single responsibility for lineage tracking
    OCP: Open for extension with new lineage types
    """
    
    __tablename__ = "data_lineage"
    
    # Source and Target objects
    source_object_id = Column(UUID(as_uuid=True), ForeignKey("data_objects.id"), nullable=False)
    target_object_id = Column(UUID(as_uuid=True), ForeignKey("data_objects.id"), nullable=False)
    
    # Lineage metadata
    tipo_relacao = Column(SQLEnum(LineageType), nullable=False)
    descricao = Column(Text)
    confianca = Column(Float, default=1.0)  # Confidence score 0-1
    
    # Process information
    processo_origem = Column(String(255))
    ferramenta_origem = Column(String(255))
    timestamp_descoberta = Column(DateTime, default=datetime.utcnow)
    
    # Technical details
    transformacao = Column(JSONB)  # Transformation logic
    dependencias = Column(JSONB)   # Dependencies information
    metadados_processo = Column(JSONB)
    
    # Relationships
    source_object = relationship("DataObject", foreign_keys=[source_object_id], back_populates="lineage_source")
    target_object = relationship("DataObject", foreign_keys=[target_object_id], back_populates="lineage_target")
    
    # Constraints
    __table_args__ = (
        UniqueConstraint('source_object_id', 'target_object_id', 'tipo_relacao', name='uq_lineage_source_target_type'),
        CheckConstraint("confianca >= 0 AND confianca <= 1", name='ck_lineage_confidence'),
        CheckConstraint("source_object_id != target_object_id", name='ck_lineage_no_self_reference'),
        Index('ix_lineage_source', 'source_object_id'),
        Index('ix_lineage_target', 'target_object_id'),
        Index('ix_lineage_tipo', 'tipo_relacao'),
        Index('ix_lineage_confianca', 'confianca'),
    )


class QualityRule(Base, TimestampMixin, AuditMixin):
    """
    Quality Rule model for data quality management.
    
    SRP: Single responsibility for quality rule definition
    OCP: Open for extension with new rule types
    """
    
    __tablename__ = "quality_rules"
    
    nome = Column(String(255), nullable=False)
    descricao = Column(Text)
    categoria = Column(String(100), nullable=False)
    tipo_regra = Column(String(100), nullable=False)
    severidade = Column(String(50), default="medium")
    
    # Rule definition
    definicao_regra = Column(JSONB, nullable=False)
    parametros = Column(JSONB)
    threshold_warning = Column(Float)
    threshold_critical = Column(Float)
    
    # Execution configuration
    frequencia_execucao = Column(String(100))
    ativa = Column(Boolean, default=True)
    
    # Foreign Keys
    data_contract_id = Column(UUID(as_uuid=True), ForeignKey("data_contracts.id"))
    
    # Relationships
    data_contract = relationship("DataContract", back_populates="quality_rules")
    quality_metrics = relationship("QualityMetric", back_populates="quality_rule")
    
    # Constraints
    __table_args__ = (
        CheckConstraint("severidade IN ('low', 'medium', 'high', 'critical')", name='ck_rule_severity'),
        CheckConstraint("threshold_warning >= 0 AND threshold_warning <= 1", name='ck_rule_warning_threshold'),
        CheckConstraint("threshold_critical >= 0 AND threshold_critical <= 1", name='ck_rule_critical_threshold'),
        Index('ix_quality_rules_nome', 'nome'),
        Index('ix_quality_rules_categoria', 'categoria'),
        Index('ix_quality_rules_severidade', 'severidade'),
        Index('ix_quality_rules_ativa', 'ativa'),
    )


class QualityMetric(Base, TimestampMixin, AuditMixin):
    """
    Quality Metric model for storing quality measurements.
    
    SRP: Single responsibility for quality metric storage
    LSP: Substitutable with different metric types
    """
    
    __tablename__ = "quality_metrics"
    
    # Foreign Keys
    data_object_id = Column(UUID(as_uuid=True), ForeignKey("data_objects.id"), nullable=False)
    quality_rule_id = Column(UUID(as_uuid=True), ForeignKey("quality_rules.id"))
    
    # Metric data
    nome_metrica = Column(String(255), nullable=False)
    valor = Column(Float, nullable=False)
    valor_esperado = Column(Float)
    unidade = Column(String(50))
    status = Column(SQLEnum(QualityStatus), nullable=False)
    
    # Execution details
    timestamp_execucao = Column(DateTime, default=datetime.utcnow)
    duracao_execucao_ms = Column(Integer)
    
    # Context and metadata
    contexto_execucao = Column(JSONB)
    detalhes_falha = Column(JSONB)
    metadados_metrica = Column(JSONB)
    
    # Relationships
    data_object = relationship("DataObject", back_populates="quality_metrics")
    quality_rule = relationship("QualityRule", back_populates="quality_metrics")
    
    # Constraints
    __table_args__ = (
        Index('ix_quality_metrics_object', 'data_object_id'),
        Index('ix_quality_metrics_rule', 'quality_rule_id'),
        Index('ix_quality_metrics_status', 'status'),
        Index('ix_quality_metrics_timestamp', 'timestamp_execucao'),
        Index('ix_quality_metrics_nome', 'nome_metrica'),
    )


class AccessPolicy(Base, TimestampMixin, AuditMixin):
    """
    Access Policy model for data governance.
    
    SRP: Single responsibility for access policy management
    OCP: Open for extension with new policy types
    """
    
    __tablename__ = "access_policies"
    
    nome = Column(String(255), nullable=False, unique=True)
    descricao = Column(Text)
    tipo_politica = Column(SQLEnum(PolicyType), nullable=False)
    prioridade = Column(Integer, default=100)
    
    # Policy definition
    condicoes = Column(JSONB, nullable=False)
    acoes = Column(JSONB, nullable=False)
    recursos = Column(JSONB)  # Target resources
    
    # Compliance and audit
    framework_compliance = Column(JSONB)  # GDPR, LGPD, etc.
    justificativa = Column(Text)
    
    # Execution
    ativa = Column(Boolean, default=True)
    data_vigencia_inicio = Column(DateTime)
    data_vigencia_fim = Column(DateTime)
    
    # Relationships
    access_logs = relationship("AccessLog", back_populates="access_policy")
    
    # Constraints
    __table_args__ = (
        CheckConstraint("prioridade >= 0 AND prioridade <= 1000", name='ck_policy_priority'),
        Index('ix_access_policies_nome', 'nome'),
        Index('ix_access_policies_tipo', 'tipo_politica'),
        Index('ix_access_policies_prioridade', 'prioridade'),
        Index('ix_access_policies_ativa', 'ativa'),
    )


class AccessLog(Base, TimestampMixin):
    """
    Access Log model for audit trail.
    
    SRP: Single responsibility for access logging
    ISP: Interface segregation for audit functionality
    """
    
    __tablename__ = "access_logs"
    
    # Foreign Keys
    data_object_id = Column(UUID(as_uuid=True), ForeignKey("data_objects.id"), nullable=False)
    access_policy_id = Column(UUID(as_uuid=True), ForeignKey("access_policies.id"))
    
    # Access details
    usuario = Column(String(255), nullable=False)
    acao = Column(String(100), nullable=False)
    resultado = Column(String(50), nullable=False)  # allowed, denied, masked
    
    # Context
    ip_origem = Column(String(45))  # IPv6 compatible
    user_agent = Column(String(500))
    aplicacao = Column(String(255))
    
    # Technical details
    timestamp_acesso = Column(DateTime, default=datetime.utcnow)
    duracao_ms = Column(Integer)
    bytes_transferidos = Column(Integer)
    
    # Metadata
    contexto_adicional = Column(JSONB)
    detalhes_erro = Column(JSONB)
    
    # Relationships
    data_object = relationship("DataObject", back_populates="access_logs")
    access_policy = relationship("AccessPolicy", back_populates="access_logs")
    
    # Constraints
    __table_args__ = (
        CheckConstraint("resultado IN ('allowed', 'denied', 'masked', 'error')", name='ck_access_result'),
        Index('ix_access_logs_object', 'data_object_id'),
        Index('ix_access_logs_usuario', 'usuario'),
        Index('ix_access_logs_acao', 'acao'),
        Index('ix_access_logs_resultado', 'resultado'),
        Index('ix_access_logs_timestamp', 'timestamp_acesso'),
        Index('ix_access_logs_ip', 'ip_origem'),
    )


class SystemMetric(Base, TimestampMixin):
    """
    System Metric model for monitoring and analytics.
    
    SRP: Single responsibility for system metrics
    OCP: Open for extension with new metric types
    """
    
    __tablename__ = "system_metrics"
    
    nome_metrica = Column(String(255), nullable=False)
    categoria = Column(String(100), nullable=False)
    valor = Column(Float, nullable=False)
    unidade = Column(String(50))
    
    # Context
    componente = Column(String(255))
    ambiente = Column(String(100))
    tags = Column(JSONB)
    
    # Timing
    timestamp_coleta = Column(DateTime, default=datetime.utcnow)
    
    # Constraints
    __table_args__ = (
        Index('ix_system_metrics_nome', 'nome_metrica'),
        Index('ix_system_metrics_categoria', 'categoria'),
        Index('ix_system_metrics_timestamp', 'timestamp_coleta'),
        Index('ix_system_metrics_componente', 'componente'),
    )


# Additional utility models
class Configuration(Base, TimestampMixin, AuditMixin):
    """
    Configuration model for system settings.
    
    SRP: Single responsibility for configuration management
    OCP: Open for extension with new configuration types
    """
    
    __tablename__ = "configurations"
    
    chave = Column(String(255), nullable=False, unique=True)
    valor = Column(Text, nullable=False)
    descricao = Column(Text)
    categoria = Column(String(100))
    tipo_valor = Column(String(50), default="string")  # string, integer, float, boolean, json
    
    # Validation
    valor_padrao = Column(Text)
    validacao_regex = Column(String(500))
    valores_permitidos = Column(JSONB)
    
    # Security
    sensivel = Column(Boolean, default=False)
    criptografado = Column(Boolean, default=False)
    
    # Constraints
    __table_args__ = (
        CheckConstraint("tipo_valor IN ('string', 'integer', 'float', 'boolean', 'json')", name='ck_config_type'),
        Index('ix_configurations_chave', 'chave'),
        Index('ix_configurations_categoria', 'categoria'),
    )


# Create all indexes and constraints
def create_additional_indexes(engine):
    """Create additional performance indexes."""
    from sqlalchemy import text
    
    with engine.connect() as conn:
        # Composite indexes for common queries
        conn.execute(text("""
            CREATE INDEX IF NOT EXISTS ix_data_objects_contract_entity 
            ON data_objects(data_contract_id, entity_id);
        """))
        
        conn.execute(text("""
            CREATE INDEX IF NOT EXISTS ix_quality_metrics_object_timestamp 
            ON quality_metrics(data_object_id, timestamp_execucao DESC);
        """))
        
        conn.execute(text("""
            CREATE INDEX IF NOT EXISTS ix_access_logs_user_timestamp 
            ON access_logs(usuario, timestamp_acesso DESC);
        """))
        
        conn.execute(text("""
            CREATE INDEX IF NOT EXISTS ix_lineage_discovery_timestamp 
            ON data_lineage(timestamp_descoberta DESC);
        """))
        
        # Partial indexes for active records
        conn.execute(text("""
            CREATE INDEX IF NOT EXISTS ix_data_objects_active 
            ON data_objects(id) WHERE ativo = true;
        """))
        
        conn.execute(text("""
            CREATE INDEX IF NOT EXISTS ix_quality_rules_active 
            ON quality_rules(id) WHERE ativa = true;
        """))
        
        conn.execute(text("""
            CREATE INDEX IF NOT EXISTS ix_access_policies_active 
            ON access_policies(id) WHERE ativa = true;
        """))
        
        conn.commit()

