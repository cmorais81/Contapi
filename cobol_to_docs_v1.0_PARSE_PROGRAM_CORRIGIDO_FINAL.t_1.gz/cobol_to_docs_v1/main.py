#!/usr/bin/env python3
"""
COBOL to Docs v1.0 - Sistema de Análise e Documentação de Programas COBOL
Autor: Carlos Morais
Data: Setembro 2025

Sistema completo para análise automatizada de programas COBOL com geração
de documentação técnica profissional usando IA.
"""

import argparse
import logging
import os
import sys
import json
import time
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.core.config import ConfigManager
from src.core.prompt_manager_dual import DualPromptManager
from src.core.token_manager import TokenManager
from src.providers.enhanced_provider_manager import EnhancedProviderManager
from src.parsers.cobol_parser import COBOLParser
from src.generators.documentation_generator import DocumentationGenerator
from src.utils.html_generator import HTMLReportGenerator
from src.analyzers.enhanced_cobol_analyzer import EnhancedCOBOLAnalyzer
from handle_prompt_generation import handle_prompt_generation

def setup_logging(log_level: str = "INFO") -> None:
    """Configura o sistema de logging."""
    log_dir = "logs"
    os.makedirs(log_dir, exist_ok=True)
    
    log_file = os.path.join(log_dir, f"cobol_to_docs_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
    
    logging.basicConfig(
        level=getattr(logging, log_level.upper()),
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file, encoding='utf-8'),
            logging.StreamHandler(sys.stdout)
        ]
    )

def parse_models_argument(models_str: str) -> List[str]:
    """Parse do argumento models que pode ser string ou lista JSON."""
    if not models_str:
        return []
    
    models_str = models_str.strip()
    
    # Se começa com [ é uma lista JSON
    if models_str.startswith('['):
        try:
            models = json.loads(models_str)
            return models if isinstance(models, list) else [models]
        except json.JSONDecodeError:
            print(f"Erro: Formato JSON inválido para models: {models_str}")
            sys.exit(1)
    else:
        # String simples
        return [models_str]

def read_file_list(file_path: str) -> List[str]:
    """Lê lista de arquivos de um arquivo texto."""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            files = [line.strip() for line in f if line.strip() and not line.startswith('#')]
        return files
    except FileNotFoundError:
        print(f"Erro: Arquivo não encontrado: {file_path}")
        sys.exit(1)
    except Exception as e:
        print(f"Erro ao ler arquivo {file_path}: {e}")
        sys.exit(1)

def validate_files(files: List[str]) -> List[str]:
    """Valida se os arquivos existem."""
    valid_files = []
    for file_path in files:
        if os.path.exists(file_path):
            valid_files.append(file_path)
        else:
            print(f"Aviso: Arquivo não encontrado: {file_path}")
    
    if not valid_files:
        print("Erro: Nenhum arquivo válido encontrado")
        sys.exit(1)
    
    return valid_files

def read_cobol_file(file_path: str) -> str:
    """Lê conteúdo de um arquivo COBOL."""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            return f.read()
    except UnicodeDecodeError:
        try:
            with open(file_path, 'r', encoding='latin-1') as f:
                return f.read()
        except Exception as e:
            print(f"Erro ao ler arquivo {file_path}: {e}")
            return ""
    except Exception as e:
        print(f"Erro ao ler arquivo {file_path}: {e}")
        return ""

def analyze_program_with_model(program_path: str, program_content: str, model: str, 
                             config_manager: ConfigManager, prompt_set: str, 
                             base_output_dir: str, is_multi_model: bool = False) -> Dict[str, Any]:
    """Analisa um programa COBOL com um modelo específico."""
    
    # Criar diretório específico do modelo se multi-modelo
    if is_multi_model:
        model_output_dir = os.path.join(base_output_dir, f"model_{model.replace('/', '_').replace('-', '_')}")
        os.makedirs(model_output_dir, exist_ok=True)
    else:
        model_output_dir = base_output_dir
    
    # Inicializar componentes específicos para o modelo
    # Verificar se há arquivo de prompts personalizado
    custom_prompts_file = None
    if hasattr(config_manager, '_custom_prompts_file'):
        custom_prompts_file = config_manager._custom_prompts_file
    
    prompt_manager = DualPromptManager(config_manager.config, prompt_set, custom_prompts_file)
    provider_manager = EnhancedProviderManager(config_manager.config)
    doc_generator = DocumentationGenerator(model_output_dir)
    
    # Parse do programa COBOL
    parser = COBOLParser()
    parsed_program = parser.parse_program(program_content, program_path)
    
    # Análise com IA
    analyzer = EnhancedCOBOLAnalyzer(provider_manager, prompt_manager)
    
    start_time = time.time()
    analysis_result = analyzer.analyze_program(parsed_program, model)
    analysis_time = time.time() - start_time
    
    if not analysis_result.success:
        print(f"Falha na análise com modelo {model}: {analysis_result.error_message}")
        return {
            'success': False,
            'model': model,
            'error': analysis_result.error_message,
            'tokens_used': 0,
            'analysis_time': analysis_time
        }
    
    # Gerar documentação
    doc_result = doc_generator.generate_documentation(
        parsed_program, 
        analysis_result.content,
        analysis_result.tokens_used
    )
    
    return {
        'success': True,
        'model': model,
        'tokens_used': analysis_result.tokens_used,
        'analysis_time': analysis_time,
        'output_dir': model_output_dir,
        'files_generated': doc_result.get('files_generated', [])
    }

def generate_comparative_report(results: List[Dict[str, Any]], output_dir: str, models: List[str]) -> None:
    """Gera relatório comparativo entre modelos."""
    
    report_path = os.path.join(output_dir, "relatorio_comparativo_modelos.md")
    
    successful_results = [r for r in results if r['success']]
    failed_results = [r for r in results if not r['success']]
    
    total_tokens = sum(r['tokens_used'] for r in successful_results)
    total_time = sum(r['analysis_time'] for r in results)
    
    with open(report_path, 'w', encoding='utf-8') as f:
        f.write("# Relatório Comparativo de Modelos - COBOL to Docs v1.0\n\n")
        f.write(f"**Autor:** Carlos Morais\n")
        f.write(f"**Data:** {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}\n\n")
        
        f.write("## Resumo Executivo\n\n")
        f.write(f"- **Modelos testados:** {len(models)}\n")
        f.write(f"- **Análises bem-sucedidas:** {len(successful_results)}\n")
        f.write(f"- **Análises falharam:** {len(failed_results)}\n")
        f.write(f"- **Taxa de sucesso:** {(len(successful_results)/len(results)*100):.1f}%\n")
        f.write(f"- **Total de tokens utilizados:** {total_tokens:,}\n")
        f.write(f"- **Tempo total de processamento:** {total_time:.2f}s\n\n")
        
        f.write("## Resultados por Modelo\n\n")
        f.write("| Modelo | Status | Tokens | Tempo (s) | Diretório |\n")
        f.write("|--------|--------|--------|-----------|----------|\n")
        
        for result in results:
            status = "Sucesso" if result['success'] else "Falha"
            tokens = f"{result['tokens_used']:,}" if result['success'] else "N/A"
            time_str = f"{result['analysis_time']:.2f}"
            directory = result.get('output_dir', 'N/A')
            
            f.write(f"| {result['model']} | {status} | {tokens} | {time_str} | {directory} |\n")
        
        if failed_results:
            f.write("\n## Análises com Falha\n\n")
            for result in failed_results:
                f.write(f"### {result['model']}\n")
                f.write(f"**Erro:** {result['error']}\n\n")
        
        f.write("\n## Recomendações\n\n")
        if successful_results:
            best_model = min(successful_results, key=lambda x: x['analysis_time'])
            f.write(f"- **Modelo mais rápido:** {best_model['model']} ({best_model['analysis_time']:.2f}s)\n")
            
            if len(successful_results) > 1:
                most_tokens = max(successful_results, key=lambda x: x['tokens_used'])
                f.write(f"- **Modelo mais detalhado:** {most_tokens['model']} ({most_tokens['tokens_used']:,} tokens)\n")
        
        f.write(f"\n---\n*Relatório gerado pelo COBOL to Docs v1.0 - Autor: Carlos Morais*\n")

def process_cobol_files(args, config_manager: ConfigManager, provider_manager: EnhancedProviderManager) -> None:
    """Processa os arquivos COBOL especificados."""
    
    # Ler lista de arquivos COBOL
    cobol_files = read_file_list(args.fontes)
    cobol_files = validate_files(cobol_files)
    
    # Ler lista de copybooks se especificado
    copybook_files = []
    if args.books:
        print(f"Carregando copybooks de: {args.books}")
        copybook_files = read_file_list(args.books)
        copybook_files = validate_files(copybook_files)
        print(f"Copybooks encontrados: {len(copybook_files)}")
    
    # Combinar arquivos para processamento
    all_files = cobol_files + copybook_files
    
    # Parse dos modelos
    if args.models:
        models = parse_models_argument(args.models)
    else:
        ai_config = config_manager.config.get('ai', {})
        models = ai_config.get('default_models', ['aws-claude-3.7'])
    
    is_multi_model = len(models) > 1
    
    print(f"\nCOBOL to Docs v1.0 - Iniciando processamento")
    print(f"Autor: Carlos Morais")
    print(f"Programas COBOL: {len(cobol_files)}")
    if copybook_files:
        print(f"Copybooks: {len(copybook_files)}")
    print(f"Total de arquivos: {len(all_files)}")
    print(f"Modelos: {', '.join(models)}")
    print(f"Diretório de saída: {args.output}")
    print("=" * 60)
    
    # Criar diretório de saída
    os.makedirs(args.output, exist_ok=True)
    
    all_results = []
    programs = []
    
    # Processar cada arquivo (programas + copybooks)
    for file_path in all_files:
        print(f"\nProcessando: {file_path}")
        
        program_content = read_cobol_file(file_path)
        if not program_content.strip():
            print(f"Aviso: Arquivo vazio ou não legível: {file_path}")
            continue
        
        programs.append(file_path)
        
        # Processar com cada modelo
        for model in models:
            print(f"  Analisando com modelo: {model}")
            
            result = analyze_program_with_model(
                file_path, program_content, model, config_manager, 
                args.prompt_set, args.output, is_multi_model
            )
            
            all_results.append(result)
            
            if result['success']:
                print(f"    Sucesso - Tokens: {result['tokens_used']:,}, Tempo: {result['analysis_time']:.2f}s")
            else:
                print(f"    Falha: {result['error']}")
    
    # Gerar relatório HTML se solicitado
    if args.pdf and all_results:
        print(f"\nGerando relatórios HTML otimizados para PDF...")
        html_generator = HTMLReportGenerator()
        
        for result in all_results:
            if result['success']:
                html_generator.generate_html_reports(result['output_dir'])
    
    # Gerar relatório comparativo se multi-modelo
    if is_multi_model:
        print(f"\nGerando relatório comparativo de modelos...")
        generate_comparative_report(all_results, args.output, models)
    
    # Estatísticas finais
    successful_analyses = len([r for r in all_results if r['success']])
    total_tokens = sum(r['tokens_used'] for r in all_results if r['success'])
    processing_time = sum(r['analysis_time'] for r in all_results)
    
    print("\n" + "=" * 60)
    print("PROCESSAMENTO CONCLUÍDO")
    print(f"Programas processados: {len(programs)}")
    print(f"Modelos utilizados: {len(models)} ({', '.join(models)})")
    print(f"Análises bem-sucedidas: {successful_analyses}/{len(all_results)}")
    print(f"Taxa de sucesso geral: {(successful_analyses/len(all_results)*100):.1f}%")
    print(f"Total de tokens utilizados: {total_tokens:,}")
    print(f"Tempo total de processamento: {processing_time:.2f}s")
    print(f"Documentação gerada em: {args.output}")
    
    if is_multi_model:
        print(f"Relatório comparativo: {args.output}/relatorio_comparativo_modelos.md")

def main():
    """Função principal para executar o script."""
    parser = argparse.ArgumentParser(
        description='COBOL to Docs v1.0 - Sistema de Análise e Documentação de Programas COBOL',
        epilog='Autor: Carlos Morais - Sistema completo para documentação automatizada de COBOL'
    )
    parser.add_argument('--fontes', help='Caminho para o arquivo de fontes COBOL (ex: fontes.txt)')
    parser.add_argument('--books', help='Caminho para o arquivo de copybooks COBOL (ex: books.txt) - opcional')
    parser.add_argument('--output', default='output', help='Diretório de saída para a documentação')
    parser.add_argument('--config', default='config/config.yaml', help='Arquivo de configuração principal')
    parser.add_argument('--models', help='(Opcional) Sobrescrever modelos da configuração. Formato: "modelo" ou ["modelo1","modelo2"]')
    parser.add_argument('--pdf', action='store_true', help='Gera relatórios HTML otimizados para conversão PDF via navegador')
    parser.add_argument('--log', default='INFO', help='Nível de log (DEBUG, INFO, WARNING, ERROR)')
    parser.add_argument('--status', action='store_true', help='Verifica status e conectividade dos provedores de IA configurados')
    parser.add_argument('--prompt-set', choices=['original', 'doc_legado_pro'], 
                        default='original', help='Conjunto de prompts a usar (original ou doc_legado_pro)')
    parser.add_argument('--prompts-file', help='Arquivo YAML de prompts personalizado (gerado via generate_prompts.py)')
    parser.add_argument('--generate-prompts', help='Gerar prompts YAML a partir de arquivo de texto')
    parser.add_argument('--generate-prompts-interactive', action='store_true', 
                        help='Gerar prompts YAML em modo interativo')

    args = parser.parse_args()

    setup_logging(args.log)
    
    try:
        # Verificar se é comando de geração de prompts
        if args.generate_prompts or args.generate_prompts_interactive:
            handle_prompt_generation(args)
            return
            
        config_manager = ConfigManager(args.config)
        
        # Configurar arquivo de prompts personalizado se especificado
        if args.prompts_file:
            if not os.path.exists(args.prompts_file):
                print(f"Erro: Arquivo de prompts não encontrado: {args.prompts_file}")
                print("   Use: python3 generate_prompts.py --input texto.txt --output prompts.yaml")
                sys.exit(1)
            config_manager._custom_prompts_file = args.prompts_file
            print(f"Usando arquivo de prompts personalizado: {args.prompts_file}")
        
        # Log da configuração inicial
        ai_config = config_manager.config.get('ai', {})
        primary_provider = ai_config.get('primary_provider', 'não definido')
        default_models = ai_config.get('default_models', [])
        
        print(f"\nCOBOL to Docs v1.0 - Iniciando análise")
        print(f"Autor: Carlos Morais")
        print(f"Provider primário configurado: {primary_provider}")
        print(f"Modelos padrão: {', '.join(default_models)}")
        print(f"Arquivo de prompts: {ai_config.get('prompt', {}).get('prompts_file', 'config/prompts.yaml')}")
        
        # Verificar credenciais LuzIA se for o provider primário
        if primary_provider == 'luzia':
            import os
            client_id = os.getenv('LUZIA_CLIENT_ID')
            client_secret = os.getenv('LUZIA_CLIENT_SECRET')
            
            if not client_id or not client_secret:
                print(f"\nAVISO: Provider primário é LuzIA mas credenciais não estão definidas!")
                print(f"   LUZIA_CLIENT_ID: {'OK' if client_id else 'NÃO DEFINIDO'}")
                print(f"   LUZIA_CLIENT_SECRET: {'OK' if client_secret else 'NÃO DEFINIDO'}")
                print(f"   Sistema usará providers de fallback (enhanced_mock, basic)")
                print(f"\n   Para usar LuzIA, defina as variáveis:")
                print(f"   export LUZIA_CLIENT_ID='seu_client_id'")
                print(f"   export LUZIA_CLIENT_SECRET='seu_client_secret'")
            else:
                print(f"Credenciais LuzIA encontradas")
        
        print("=" * 60)
        
        provider_manager = EnhancedProviderManager(config_manager.config)
        
        # Verificar se é comando de status
        if args.status:
            print("\nSTATUS DOS PROVEDORES")
            print("=" * 30)
            available_providers = provider_manager.get_available_providers()
            
            if not available_providers:
                print("Nenhum provider disponível")
                return
            
            for provider_name in available_providers:
                provider_status = provider_manager.get_provider_status(provider_name)
                status = "Disponível" if provider_status.get('available', False) else "Indisponível"
                print(f"{provider_name}: {status}")
            return
        
        # Validar argumentos obrigatórios para análise
        if not args.fontes:
            print("Erro: --fontes é obrigatório para análise de programas")
            print("Use --status para verificar conectividade dos provedores")
            sys.exit(1)
        
        process_cobol_files(args, config_manager, provider_manager)
    except Exception as e:
        logging.error(f"Uma falha crítica ocorreu: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
