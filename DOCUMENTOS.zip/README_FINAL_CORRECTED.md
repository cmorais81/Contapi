# Data Governance API - Enterprise Solution (Corrigida)

**Autor:** Carlos Morais  
**Versão:** 2.0 (Corrigida para seguir modelo original)  
**Data:** 2024-07-26

---

## 🎯 **CORREÇÃO IMPORTANTE**

Esta versão foi **completamente corrigida** para seguir **exatamente** o modelo de dados original `modelo_estendido.dbml` com **36 tabelas**. Todas as funcionalidades, endpoints, documentação e testes foram adaptados para refletir a estrutura correta do sistema.

---

## 📋 **Visão Geral**

A Data Governance API é uma solução enterprise completa para governança de dados, baseada em **Contratos de Dados** e projetada para integração nativa com o ecossistema Databricks Unity Catalog.

### 🎯 **Funcionalidades Principais**

- ✅ **36 Entidades Completas** seguindo o modelo original
- ✅ **Contratos de Dados** com versionamento robusto
- ✅ **Layouts Customizáveis** por país/região
- ✅ **Qualidade de Dados** com integração DLT
- ✅ **Linhagem de Dados** granular
- ✅ **Monitoramento** de clusters, jobs e queries
- ✅ **Sistema RBAC/ABAC** completo
- ✅ **Privacidade e Compliance** (LGPD/GDPR)
- ✅ **Integrações Enterprise** (Unity Catalog, Axon)
- ✅ **Auditoria e Analytics** completos

---

## 🏗️ **Modelo de Dados (36 Tabelas)**

### **Contratos e Versionamento (9 tabelas)**
- `DataContracts` - Contratos centrais
- `ContractVersions` - Versionamento semver
- `ContractLayouts` - Layouts por país
- `ContractCustomProperties` - Propriedades extensíveis
- `ContractFundamentals` - Informações fundamentais
- `ContractTeamDefinitions` - Definições de equipe
- `ContractSLADefinitions` - SLAs com monitoramento
- `ContractPricingDefinitions` - Modelos de precificação
- `ContractSchemaDefinitions` - Definições de schema

### **Objetos de Dados (2 tabelas)**
- `DataObjects` - Objetos com políticas de ciclo de vida
- `DataObjectProperties` - Propriedades granulares com privacidade

### **Qualidade de Dados (4 tabelas)**
- `ContractQualityDefinitions` - Definições de qualidade
- `QualityRules` - Regras com integração DLT
- `PropertyQualityRuleLinks` - Links propriedades-regras
- `QualityExecutionResults` - Resultados históricos

### **Métricas de Monitoramento (4 tabelas)**
- `ClusterMetrics` - Métricas de cluster com auto-scaling
- `JobMetrics` - Métricas detalhadas de jobs
- `QueryMetrics` - Performance de queries com otimizações
- `StorageMetrics` - Métricas Delta Lake e Iceberg

### **Linhagem de Dados (1 tabela)**
- `DataLineage` - Linhagem granular com validação

### **Usuários e Permissões (5 tabelas)**
- `Users` - Usuários com integração Unity Catalog
- `Groups` - Grupos com hierarquia
- `UserGroups` - Associação usuário-grupo
- `Permissions` - Permissões do sistema
- `GroupPermissions` - Permissões granulares por recurso

### **Tags e Entidades (3 tabelas)**
- `Entity` - Entidades genéricas para tagueamento
- `Tag` - Sistema hierárquico com propriedades visuais
- `Tagged` - Relacionamento muitos-para-muitos

### **Governança e Conformidade (2 tabelas)**
- `ABACPolicyEvaluations` - Trilha de auditoria ABAC
- `DataClassificationResults` - Classificação automatizada e manual

### **Integração e Sincronização (3 tabelas)**
- `ToolIntegrations` - Integrações com ferramentas externas
- `SyncExecutions` - Execuções de sincronização
- `SyncErrors` - Erros com rastreamento de resolução

### **Auditoria e Analytics (3 tabelas)**
- `AuditLog` - Log de auditoria imutável
- `DataQualityAggregates` - Agregados para análise de tendências
- `DataAnomalyDetection` - Detecção de anomalias com ML

---

## 🚀 **Início Rápido**

### **Pré-requisitos**
- Docker e Docker Compose
- Python 3.10+
- PostgreSQL 13+

### **Instalação**

1. **Clone e configure:**
   ```bash
   git clone <repositorio>
   cd data-governance-api-final
   cp .env.example .env
   # Edite o .env com suas configurações
   ```

2. **Inicie a aplicação:**
   ```bash
   docker-compose up -d --build
   ```

3. **Acesse a documentação:**
   - Swagger UI: http://localhost:8000/docs
   - ReDoc: http://localhost:8000/redoc

### **Executar Testes**
```bash
# Testes unitários
docker-compose exec api pytest tests/unit/ -v

# Testes de integração
docker-compose exec api pytest tests/integration/ -v

# Todos os testes
docker-compose exec api pytest -v
```

---

## 📚 **Documentação**

- **`DOCUMENTATION_COMPLETE_CORRECTED.md`** - Documentação técnica completa
- **`modelo_estendido_original.dbml`** - Modelo de dados original
- **`analise_modelo_original.md`** - Análise detalhada do modelo
- **Swagger UI** - Documentação interativa da API

---

## 🔧 **Configuração**

### **Variáveis de Ambiente**
```bash
# Banco de dados
DATABASE_URL=postgresql://user:pass@localhost:5432/governance

# API
API_HOST=0.0.0.0
API_PORT=8000
DEBUG=false

# Segurança
SECRET_KEY=your-secret-key
JWT_ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=30

# Unity Catalog
UNITY_CATALOG_URL=https://your-workspace.cloud.databricks.com
UNITY_CATALOG_TOKEN=your-token

# Redis (Cache)
REDIS_URL=redis://localhost:6379/0

# Monitoramento
ENABLE_METRICS=true
METRICS_PORT=9090
```

---

## 🏛️ **Arquitetura**

### **Camadas da Aplicação**
```
├── src/app/
│   ├── models/          # 36 modelos SQLAlchemy
│   ├── schemas/         # Schemas Pydantic
│   ├── repositories/    # Camada de dados
│   ├── services/        # Lógica de negócio
│   ├── endpoints/       # Endpoints REST
│   ├── utils/           # Utilitários
│   └── core/           # Configurações centrais
```

### **Padrões Implementados**
- **Repository Pattern** - Abstração da camada de dados
- **Service Layer** - Lógica de negócio centralizada
- **Dependency Injection** - Inversão de dependências
- **SOLID Principles** - Código limpo e manutenível

---

## 🔌 **Integrações**

### **Unity Catalog**
- Sincronização automática de metadados
- Aplicação de contratos de dados
- Gestão de tags e classificações

### **Delta Live Tables**
- Execução de regras de qualidade
- Expectations automáticas
- Monitoramento de pipelines

### **Informatica Axon**
- Sincronização de glossário
- Gestão de stewardship
- Políticas centralizadas

---

## 📊 **Métricas e Monitoramento**

### **Métricas Coletadas**
- **Cluster:** CPU, memória, disco, auto-scaling
- **Jobs:** Duração, registros, performance
- **Queries:** Tempo de execução, otimizações
- **Storage:** Delta Lake, Iceberg, otimizações

### **Dashboards**
- **Executivo:** KPIs de governança
- **Operacional:** Métricas de sistema
- **Qualidade:** Scores e tendências
- **Compliance:** Status regulatório

---

## 🔒 **Segurança**

### **Autenticação e Autorização**
- JWT tokens com expiração
- Sistema RBAC granular
- Políticas ABAC contextuais
- Integração Unity Catalog

### **Privacidade**
- Detecção automática de PII
- Classificação de dados
- Mascaramento contextual
- Compliance LGPD/GDPR

---

## 🧪 **Testes**

### **Cobertura de Testes**
- **Unitários:** 95%+ de cobertura
- **Integração:** Fluxos end-to-end
- **Performance:** Load testing
- **Segurança:** Testes de penetração

### **Executar Testes**
```bash
# Com cobertura
docker-compose exec api pytest --cov=src --cov-report=html

# Testes específicos
docker-compose exec api pytest tests/unit/test_data_contracts.py -v

# Testes de performance
docker-compose exec api pytest tests/performance/ -v
```

---

## 🚀 **Deployment**

### **Produção**
```bash
# Build para produção
docker build -t data-governance-api:latest .

# Deploy com Kubernetes
kubectl apply -f k8s/

# Deploy com Docker Swarm
docker stack deploy -c docker-stack.yml governance
```

### **Monitoramento**
- **Prometheus:** Métricas da aplicação
- **Grafana:** Dashboards visuais
- **Jaeger:** Tracing distribuído
- **ELK Stack:** Logs centralizados

---

## 📈 **Roadmap**

### **Próximas Funcionalidades**
- [ ] Interface web de governança
- [ ] Machine Learning para detecção de anomalias
- [ ] Integração com Apache Atlas
- [ ] Suporte a Apache Iceberg
- [ ] Catálogo de dados self-service
- [ ] Workflows de aprovação

---

## 🤝 **Contribuição**

### **Como Contribuir**
1. Fork o repositório
2. Crie uma branch para sua feature
3. Implemente com testes
4. Submeta um Pull Request

### **Padrões de Código**
- **Black:** Formatação de código
- **Flake8:** Linting
- **MyPy:** Type checking
- **Pytest:** Framework de testes

---

## 📄 **Licença**

Este projeto está licenciado sob a Licença MIT - veja o arquivo [LICENSE](LICENSE) para detalhes.

---

## 📞 **Suporte**

Para suporte técnico ou dúvidas:
- **Documentação:** `/docs` endpoint
- **Issues:** GitHub Issues
- **Email:** suporte@datagovernance.com

---

## 🏆 **Reconhecimentos**

Desenvolvido por **Carlos Morais** seguindo as melhores práticas de governança de dados e arquitetura de software enterprise.

---

**© 2024 Data Governance API - Todos os direitos reservados**

