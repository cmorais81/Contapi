# Análise de Fontes de Dados para Motor de Load - Data Governance API

**Autor:** Carlos Morais  
**Data:** Dezembro 2024  
**Versão:** 1.0  

## Visão Geral

Este documento apresenta uma análise completa das fontes de dados necessárias para alimentar o modelo de governança de dados com 36 tabelas, identificando o que pode ser coletado automaticamente via Unity Catalog, Azure APIs, e o que precisa ser fornecido manualmente.

## Modelo de Dados - 36 Tabelas Analisadas

### Grupo 1: Contratos e Versionamento (4 tabelas)

#### 1.1 data_contracts
**Fonte de Dados:** Híbrida (Automática + Manual)

**Campos Automáticos (Unity Catalog):**
- `unity_catalog_name` - Disponível via UC API
- `unity_catalog_schema` - Disponível via UC API  
- `unity_catalog_table` - Disponível via UC API
- `data_location` - Disponível via UC table properties
- `data_format` - Detectável via UC table info
- `table_format` - Disponível via UC (delta, iceberg)

**Campos Manuais (Requer Input):**
- `contract_name` - Definido pelo usuário
- `contract_description` - Definido pelo usuário
- `contract_owner` - Pode usar UC owner ou manual
- `business_domain` - Requer classificação manual
- `abac_policy_id` - Configuração manual
- `monitoring_enabled` - Configuração manual
- `alert_threshold_percent` - Configuração manual
- `contract_status` - Workflow manual

**Cobertura Automática:** 40% | **Manual:** 60%

#### 1.2 contract_versions
**Fonte de Dados:** Híbrida (Git + Manual)

**Campos Automáticos:**
- `schema_version` - Detectável via UC schema evolution
- `delta_lake_enabled` - Detectável via table properties
- `iceberg_enabled` - Detectável via table properties

**Campos Manuais:**
- `version_number` - Versionamento semântico manual
- `version_description` - Descrição manual
- `is_breaking_change` - Análise manual
- `approved_by` - Workflow de aprovação
- `approval_date` - Workflow de aprovação

**Cobertura Automática:** 30% | **Manual:** 70%

#### 1.3 contract_layouts
**Fonte de Dados:** Manual

**Todos os campos requerem configuração manual:**
- Templates por país/região
- Configurações de layout
- Conteúdo customizado

**Cobertura Automática:** 0% | **Manual:** 100%

#### 1.4 contract_custom_properties
**Fonte de Dados:** Híbrida

**Campos Automáticos (UC Properties):**
- Propriedades de tabela do Unity Catalog
- Tags e metadados existentes

**Campos Manuais:**
- Propriedades customizadas específicas do negócio

**Cobertura Automática:** 50% | **Manual:** 50%

### Grupo 2: Componentes Modulares (5 tabelas)

#### 2.1 contract_fundamentals
**Fonte de Dados:** Manual
- Informações de negócio específicas
- Definições de domínio
- Classificações de dados

**Cobertura Automática:** 10% | **Manual:** 90%

#### 2.2 contract_team_definitions
**Fonte de Dados:** Azure AD + Manual

**Campos Automáticos (Azure AD):**
- `team_lead_email` - Via Azure AD API
- `team_members` - Via Azure AD groups
- `contact_info` - Via Azure AD profiles

**Campos Manuais:**
- Responsabilidades específicas
- Definições de papel

**Cobertura Automática:** 60% | **Manual:** 40%

#### 2.3 contract_sla_definitions
**Fonte de Dados:** Manual + Monitoramento

**Campos Automáticos:**
- Métricas de performance atuais
- Histórico de disponibilidade

**Campos Manuais:**
- Definições de SLA
- Thresholds de negócio

**Cobertura Automática:** 30% | **Manual:** 70%

#### 2.4 contract_pricing_definitions
**Fonte de Dados:** Manual + Azure Cost Management

**Campos Automáticos (Azure APIs):**
- Custos de armazenamento
- Custos de compute
- Métricas de uso

**Campos Manuais:**
- Modelos de precificação
- Políticas de cobrança

**Cobertura Automática:** 40% | **Manual:** 60%

#### 2.5 contract_schema_definitions
**Fonte de Dados:** Unity Catalog (Automático)

**Campos Automáticos (UC Schema Registry):**
- Definições de schema
- Tipos de dados
- Constraints
- Evolução de schema

**Cobertura Automática:** 90% | **Manual:** 10%

### Grupo 3: Objetos de Dados (2 tabelas)

#### 3.1 data_objects
**Fonte de Dados:** Unity Catalog (Automático)

**Campos Automáticos (UC Catalog):**
- `object_name` - Nome da tabela/view
- `object_type` - Tipo (table, view, function)
- `schema_name` - Schema container
- `catalog_name` - Catalog container
- `storage_location` - Localização física
- `data_format` - Formato dos dados
- `table_format` - Delta, Iceberg, etc.
- `row_count` - Estatísticas da tabela
- `size_bytes` - Tamanho em bytes
- `last_modified` - Última modificação

**Campos Manuais:**
- `business_description` - Descrição de negócio
- `data_classification` - Classificação de sensibilidade
- `retention_policy` - Política de retenção
- `backup_policy` - Política de backup

**Cobertura Automática:** 70% | **Manual:** 30%

#### 3.2 data_object_properties
**Fonte de Dados:** Unity Catalog (Automático)

**Campos Automáticos (UC Column Info):**
- `property_name` - Nome da coluna
- `data_type` - Tipo de dados
- `is_nullable` - Permite null
- `default_value` - Valor padrão
- `column_position` - Posição na tabela
- `column_comment` - Comentário da coluna

**Campos Manuais:**
- `is_pii` - Classificação PII
- `masking_rule` - Regra de mascaramento
- `business_definition` - Definição de negócio

**Cobertura Automática:** 60% | **Manual:** 40%

### Grupo 4: Qualidade de Dados (4 tabelas)

#### 4.1 contract_quality_definitions
**Fonte de Dados:** Manual + Great Expectations

**Campos Automáticos:**
- Regras básicas de qualidade detectáveis
- Estatísticas de dados

**Campos Manuais:**
- Definições de qualidade específicas
- Thresholds de negócio

**Cobertura Automática:** 30% | **Manual:** 70%

#### 4.2 quality_rules
**Fonte de Dados:** Great Expectations + Manual

**Campos Automáticos (Data Profiling):**
- Regras de completeness
- Regras de uniqueness
- Regras de format (detectáveis)

**Campos Manuais:**
- Regras de negócio específicas
- Validações customizadas

**Cobertura Automática:** 50% | **Manual:** 50%

#### 4.3 property_quality_rule_links
**Fonte de Dados:** Automático (Inferência)

**Campos Automáticos:**
- Links baseados em análise de schema
- Associações por tipo de dados

**Cobertura Automática:** 80% | **Manual:** 20%

#### 4.4 quality_execution_results
**Fonte de Dados:** Automático (Execução)

**Campos Automáticos:**
- Resultados de execução de regras
- Métricas de qualidade
- Histórico de execuções

**Cobertura Automática:** 100% | **Manual:** 0%

### Grupo 5: Métricas de Monitoramento (4 tabelas)

#### 5.1 cluster_metrics
**Fonte de Dados:** Databricks APIs (Automático)

**Campos Automáticos (Databricks Cluster API):**
- `cluster_id` - ID do cluster
- `cluster_name` - Nome do cluster
- `cluster_state` - Estado atual
- `driver_node_type` - Tipo do nó driver
- `worker_node_type` - Tipo dos workers
- `num_workers` - Número de workers
- `autoscale_min_workers` - Min workers autoscale
- `autoscale_max_workers` - Max workers autoscale
- `spark_version` - Versão do Spark
- `runtime_engine` - Engine de runtime
- `total_uptime_seconds` - Tempo total ativo
- `total_cost_usd` - Custo total
- `cpu_utilization_percent` - Utilização CPU
- `memory_utilization_percent` - Utilização memória
- `disk_utilization_percent` - Utilização disco

**Cobertura Automática:** 100% | **Manual:** 0%

#### 5.2 job_metrics
**Fonte de Dados:** Databricks APIs (Automático)

**Campos Automáticos (Databricks Jobs API):**
- `job_id` - ID do job
- `job_name` - Nome do job
- `run_id` - ID da execução
- `job_type` - Tipo do job
- `cluster_id` - Cluster utilizado
- `start_time` - Início da execução
- `end_time` - Fim da execução
- `duration_seconds` - Duração em segundos
- `job_status` - Status da execução
- `error_message` - Mensagem de erro
- `input_records` - Registros de entrada
- `output_records` - Registros de saída
- `bytes_read` - Bytes lidos
- `bytes_written` - Bytes escritos
- `shuffle_read_bytes` - Bytes shuffle read
- `shuffle_write_bytes` - Bytes shuffle write

**Cobertura Automática:** 100% | **Manual:** 0%

#### 5.3 query_metrics
**Fonte de Dados:** Databricks SQL APIs (Automático)

**Campos Automáticos (SQL Analytics API):**
- `query_id` - ID da query
- `query_text` - Texto da query
- `user_name` - Usuário executor
- `warehouse_id` - Warehouse utilizado
- `execution_time_ms` - Tempo de execução
- `queue_time_ms` - Tempo na fila
- `rows_returned` - Linhas retornadas
- `bytes_scanned` - Bytes escaneados
- `cache_hit_ratio` - Taxa de cache hit
- `query_status` - Status da query

**Cobertura Automática:** 100% | **Manual:** 0%

#### 5.4 storage_metrics
**Fonte de Dados:** Unity Catalog + Azure Storage (Automático)

**Campos Automáticos:**
- `storage_location` - Localização do storage
- `total_size_bytes` - Tamanho total
- `file_count` - Número de arquivos
- `partition_count` - Número de partições
- `compression_ratio` - Taxa de compressão
- `storage_tier` - Tier de armazenamento
- `last_accessed` - Último acesso
- `access_frequency` - Frequência de acesso

**Cobertura Automática:** 100% | **Manual:** 0%

### Grupo 6: Linhagem de Dados (1 tabela)

#### 6.1 data_lineage
**Fonte de Dados:** Unity Catalog + Spark Lineage (Automático)

**Campos Automáticos (UC Lineage API):**
- `source_object_id` - Objeto fonte
- `target_object_id` - Objeto destino
- `lineage_type` - Tipo de linhagem
- `transformation_logic` - Lógica de transformação
- `job_id` - Job que criou a linhagem
- `execution_time` - Tempo de execução

**Cobertura Automática:** 90% | **Manual:** 10%

### Grupo 7: Usuários e Permissões (5 tabelas)

#### 7.1 users
**Fonte de Dados:** Azure AD + Unity Catalog (Automático)

**Campos Automáticos (Azure AD API):**
- `user_name` - Nome do usuário
- `email` - Email do usuário
- `display_name` - Nome de exibição
- `department` - Departamento
- `job_title` - Cargo
- `manager_email` - Email do gerente
- `is_active` - Status ativo
- `last_login` - Último login

**Cobertura Automática:** 90% | **Manual:** 10%

#### 7.2 groups
**Fonte de Dados:** Azure AD (Automático)

**Campos Automáticos (Azure AD Groups):**
- `group_name` - Nome do grupo
- `group_description` - Descrição
- `group_type` - Tipo do grupo
- `member_count` - Número de membros

**Cobertura Automática:** 100% | **Manual:** 0%

#### 7.3 user_groups
**Fonte de Dados:** Azure AD (Automático)

**Campos Automáticos:**
- Associações usuário-grupo via Azure AD

**Cobertura Automática:** 100% | **Manual:** 0%

#### 7.4 permissions
**Fonte de Dados:** Unity Catalog (Automático)

**Campos Automáticos (UC Permissions):**
- Permissões do Unity Catalog
- Grants e privilégios

**Cobertura Automática:** 80% | **Manual:** 20%

#### 7.5 group_permissions
**Fonte de Dados:** Unity Catalog (Automático)

**Campos Automáticos:**
- Permissões por grupo no UC

**Cobertura Automática:** 80% | **Manual:** 20%

### Grupo 8: Tags e Entidades (3 tabelas)

#### 8.1 entity
**Fonte de Dados:** Unity Catalog (Automático)

**Campos Automáticos:**
- Entidades do catálogo
- Metadados de objetos

**Cobertura Automática:** 70% | **Manual:** 30%

#### 8.2 tag
**Fonte de Dados:** Unity Catalog + Manual

**Campos Automáticos (UC Tags):**
- Tags existentes no UC
- Hierarquia de tags

**Campos Manuais:**
- Tags customizadas de negócio
- Propriedades visuais

**Cobertura Automática:** 60% | **Manual:** 40%

#### 8.3 tagged
**Fonte de Dados:** Unity Catalog (Automático)

**Campos Automáticos:**
- Relacionamentos tag-objeto no UC

**Cobertura Automática:** 90% | **Manual:** 10%

### Grupo 9: Governança e Conformidade (2 tabelas)

#### 9.1 abac_policy_evaluations
**Fonte de Dados:** Manual + Logs

**Campos Automáticos:**
- Logs de avaliação de políticas
- Resultados de execução

**Campos Manuais:**
- Definições de políticas ABAC
- Regras de negócio

**Cobertura Automática:** 40% | **Manual:** 60%

#### 9.2 data_classification_results
**Fonte de Dados:** Azure Purview + Manual

**Campos Automáticos (Purview API):**
- Classificações automáticas
- Detecção de PII
- Scores de confiança

**Campos Manuais:**
- Validação manual de classificações
- Classificações específicas do negócio

**Cobertura Automática:** 70% | **Manual:** 30%

### Grupo 10: Integração e Sincronização (3 tabelas)

#### 10.1 tool_integrations
**Fonte de Dados:** Manual + APIs

**Campos Automáticos:**
- Status de conexão com ferramentas
- Métricas de integração

**Campos Manuais:**
- Configurações de integração
- Credenciais e endpoints

**Cobertura Automática:** 30% | **Manual:** 70%

#### 10.2 sync_executions
**Fonte de Dados:** Automático (Logs)

**Campos Automáticos:**
- Logs de execução de sincronização
- Métricas de performance
- Status de execução

**Cobertura Automática:** 100% | **Manual:** 0%

#### 10.3 sync_errors
**Fonte de Dados:** Automático (Logs)

**Campos Automáticos:**
- Erros de sincronização
- Stack traces
- Contexto de erro

**Cobertura Automática:** 100% | **Manual:** 0%

### Grupo 11: Auditoria e Analytics (3 tabelas)

#### 11.1 audit_log
**Fonte de Dados:** Databricks + Azure (Automático)

**Campos Automáticos:**
- Logs de auditoria do Databricks
- Logs de acesso do Azure
- Eventos de sistema

**Cobertura Automática:** 95% | **Manual:** 5%

#### 11.2 data_quality_aggregates
**Fonte de Dados:** Automático (Cálculo)

**Campos Automáticos:**
- Agregações de métricas de qualidade
- Tendências históricas
- Scores consolidados

**Cobertura Automática:** 100% | **Manual:** 0%

#### 11.3 data_anomaly_detection
**Fonte de Dados:** Machine Learning (Automático)

**Campos Automáticos:**
- Detecção automática de anomalias
- Scores de anomalia
- Padrões identificados

**Cobertura Automática:** 90% | **Manual:** 10%

## Resumo de Cobertura por Fonte

### Fontes Automáticas Disponíveis

#### Unity Catalog APIs
- **Cobertura:** 15 tabelas (42%)
- **Dados:** Metadados de catálogo, schema, tabelas, colunas, permissões, tags, linhagem
- **Qualidade:** Alta (dados estruturados e confiáveis)

#### Databricks APIs
- **Cobertura:** 8 tabelas (22%)  
- **Dados:** Métricas de cluster, jobs, queries, logs de auditoria
- **Qualidade:** Alta (métricas precisas)

#### Azure APIs
- **Cobertura:** 6 tabelas (17%)
- **Dados:** Azure AD (usuários, grupos), Cost Management, Purview
- **Qualidade:** Alta (dados corporativos)

#### Logs e Monitoramento
- **Cobertura:** 4 tabelas (11%)
- **Dados:** Execuções, erros, auditoria, anomalias
- **Qualidade:** Alta (dados operacionais)

### Dados Manuais Necessários

#### Configurações de Negócio
- **Tabelas:** 12 (33%)
- **Dados:** Contratos, layouts, SLAs, políticas, classificações
- **Esforço:** Alto (requer conhecimento de negócio)

#### Definições Customizadas  
- **Tabelas:** 8 (22%)
- **Dados:** Propriedades customizadas, regras de qualidade, integrações
- **Esforço:** Médio (configuração técnica)

## Estratégia de Coleta de Dados

### Fase 1: Dados Automáticos (70% do modelo)
1. **Unity Catalog** - Metadados de catálogo
2. **Databricks APIs** - Métricas operacionais  
3. **Azure APIs** - Dados corporativos
4. **Logs** - Dados de execução

### Fase 2: Dados Semi-Automáticos (20% do modelo)
1. **Inferência** - Classificações baseadas em padrões
2. **Detecção** - PII e dados sensíveis
3. **Análise** - Qualidade e anomalias

### Fase 3: Dados Manuais (10% do modelo)
1. **Configuração** - Políticas e regras de negócio
2. **Validação** - Classificações e definições
3. **Customização** - Layouts e templates

## Conclusão

O motor de load pode automatizar **70-80%** da coleta de dados, focando nos **20-30%** que requerem input manual ou validação humana. Esta abordagem garante eficiência na coleta mantendo a qualidade e relevância dos dados de governança.

