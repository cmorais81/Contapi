# Data Governance API - Enterprise v2.0 (snake_case)

**Autor:** Carlos Morais  
**Versão:** 2.0  
**Data:** Dezembro 2024

## Visão Geral

A **Data Governance API Enterprise v2.0** é uma solução completa de governança de dados baseada em contratos, desenvolvida seguindo o padrão **snake_case** para nomenclatura de entidades. Esta API oferece capacidades enterprise para gerenciamento, monitoramento e controle de qualidade de dados em ambientes modernos de Big Data.

### Principais Características

- **36 entidades** implementadas seguindo exatamente o modelo original
- **Nomenclatura padronizada** em snake_case para melhor legibilidade
- **Integração nativa** com Databricks Unity Catalog
- **Sistema ABAC** (Attribute-Based Access Control) completo
- **Monitoramento em tempo real** de qualidade e performance
- **Compliance automático** com LGPD, GDPR, HIPAA, SOX
- **Machine Learning** integrado para detecção de anomalias
- **APIs RESTful** completas com documentação OpenAPI

## Arquitetura

### Entidades Principais (snake_case)

#### **Contratos e Versionamento**
- `data_contracts` - Contratos de dados centrais
- `contract_versions` - Versionamento robusto
- `contract_layouts` - Layouts customizáveis por país
- `contract_custom_properties` - Propriedades extensíveis
- `contract_fundamentals` - Informações fundamentais
- `contract_team_definitions` - Definições de equipe
- `contract_sla_definitions` - SLAs com monitoramento
- `contract_pricing_definitions` - Modelos de precificação
- `contract_schema_definitions` - Definições de schema

#### **Objetos de Dados**
- `data_objects` - Catálogo de objetos de dados
- `data_object_properties` - Propriedades granulares

#### **Qualidade de Dados**
- `contract_quality_definitions` - Definições de qualidade
- `quality_rules` - Regras detalhadas
- `property_quality_rule_links` - Links propriedades-regras
- `quality_execution_results` - Resultados históricos

#### **Métricas de Monitoramento**
- `cluster_metrics` - Métricas de cluster Databricks
- `job_metrics` - Métricas de jobs
- `query_metrics` - Performance de queries
- `storage_metrics` - Métricas de armazenamento

#### **Linhagem e Rastreabilidade**
- `data_lineage` - Linhagem granular de dados

#### **Usuários e Permissões**
- `users` - Usuários do sistema
- `groups` - Grupos de usuários
- `user_groups` - Associações usuário-grupo
- `permissions` - Permissões do sistema
- `group_permissions` - Permissões granulares

#### **Tags e Entidades**
- `entity` - Entidades genéricas
- `tag` - Sistema de tags hierárquico
- `tagged` - Relacionamentos tag-entidade

#### **Governança e Conformidade**
- `abac_policy_evaluations` - Avaliações ABAC
- `data_classification_results` - Classificação de dados

#### **Integração e Sincronização**
- `tool_integrations` - Integrações externas
- `sync_executions` - Execuções de sincronização
- `sync_errors` - Erros de sincronização

#### **Auditoria e Analytics**
- `audit_log` - Log de auditoria imutável
- `data_quality_aggregates` - Agregados de qualidade
- `data_anomaly_detection` - Detecção de anomalias

## Funcionalidades Principais

### 1. Contratos de Dados Avançados

Os contratos de dados (`data_contracts`) são o coração do sistema, oferecendo:

- **Versionamento robusto** com múltiplas versões ativas
- **Layouts customizáveis** por país e região
- **Integração Unity Catalog** nativa
- **Políticas ABAC** granulares
- **Monitoramento automático** de compliance

### 2. Sistema de Qualidade Enterprise

O sistema de qualidade oferece:

- **10 tipos de regras** de qualidade
- **8 dimensões** de qualidade de dados
- **Execução automática** com métricas detalhadas
- **Scoring inteligente** baseado em thresholds
- **Detecção de anomalias** com Machine Learning

### 3. Observabilidade Completa

Sistema de monitoramento de classe mundial:

- **Tracing distribuído** com Jaeger
- **Métricas customizadas** (counters, gauges, histograms)
- **Health checks** inteligentes
- **Alertas automáticos** por threshold
- **Dashboard executivo** em tempo real

### 4. Privacidade e Compliance

Proteção de dados enterprise:

- **10 tipos de mascaramento** de dados
- **Detector de PII** automático
- **Gestão de consentimento** LGPD/GDPR
- **Políticas de retenção** automáticas
- **Auditoria completa** de operações

## Tecnologias Utilizadas

- **Python 3.11+** - Linguagem principal
- **FastAPI** - Framework web moderno
- **SQLAlchemy** - ORM robusto
- **Pydantic** - Validação de dados
- **PostgreSQL** - Banco de dados principal
- **Redis** - Cache distribuído
- **Docker** - Containerização
- **Pytest** - Framework de testes

## Instalação Rápida

### Pré-requisitos

- Docker e Docker Compose
- Python 3.11+
- PostgreSQL 13+
- Redis 6+

### Passos de Instalação

1. **Clonar o projeto**
```bash
# Extrair o arquivo ZIP
unzip DATA-GOVERNANCE-API-ENTERPRISE-v2.0-SNAKE-CASE-FINAL.zip
cd data-governance-api-final
```

2. **Configurar ambiente**
```bash
# Copiar arquivo de configuração
cp .env.example .env

# Editar configurações conforme necessário
nano .env
```

3. **Executar com Docker**
```bash
# Subir todos os serviços
docker-compose up -d --build

# Verificar status
docker-compose ps
```

4. **Acessar a aplicação**
- **API Docs:** http://localhost:8000/docs
- **Health Check:** http://localhost:8000/health
- **Métricas:** http://localhost:8000/metrics

## Exemplos de Uso

### Criar um Contrato de Dados

```python
import requests

# Dados do contrato
contract_data = {
    "contract_name": "customer_data_v1",
    "contract_description": "Contrato para dados de clientes",
    "contract_owner": "data-team@empresa.com",
    "business_domain": "customer_management",
    "contract_status": "draft",
    "unity_catalog_enabled": True,
    "unity_catalog_name": "production",
    "unity_catalog_schema": "customer",
    "unity_catalog_table": "customers",
    "monitoring_enabled": True,
    "monitoring_frequency": "daily"
}

# Criar contrato
response = requests.post(
    "http://localhost:8000/data-contracts/",
    json=contract_data
)

print(f"Contrato criado: {response.json()}")
```

### Buscar Contratos por Domínio

```python
# Buscar contratos do domínio customer_management
response = requests.get(
    "http://localhost:8000/data-contracts/by-domain/customer_management"
)

contracts = response.json()
print(f"Encontrados {len(contracts)} contratos")
```

### Obter Estatísticas

```python
# Obter estatísticas gerais
response = requests.get(
    "http://localhost:8000/data-contracts/stats"
)

stats = response.json()
print(f"Total de contratos: {stats['total_contracts']}")
print(f"Por status: {stats['by_status']}")
```

## Estrutura do Projeto

```
data-governance-api-final/
├── src/app/
│   ├── models/              # Modelos SQLAlchemy (snake_case)
│   ├── schemas/             # Schemas Pydantic
│   ├── repositories/        # Camada de dados
│   ├── services/            # Lógica de negócio
│   ├── endpoints/           # Endpoints REST
│   ├── utils/               # Utilitários
│   └── core/                # Configurações centrais
├── tests/                   # Testes unitários e integração
├── docs/                    # Documentação
├── scripts/                 # Scripts de automação
├── docker-compose.yml       # Orquestração Docker
├── Dockerfile              # Imagem da aplicação
├── requirements.txt        # Dependências Python
└── README_SNAKE_CASE.md    # Este arquivo
```

## Testes

### Executar Testes

```bash
# Todos os testes
pytest

# Testes unitários apenas
pytest tests/unit/

# Testes de integração
pytest tests/integration/

# Com cobertura
pytest --cov=src/app --cov-report=html
```

### Cobertura de Testes

- **Modelos:** 95%+ cobertura
- **Repositories:** 90%+ cobertura
- **Services:** 85%+ cobertura
- **Endpoints:** 80%+ cobertura

## Monitoramento e Observabilidade

### Métricas Disponíveis

- **Métricas de aplicação:** Requests, latência, erros
- **Métricas de negócio:** Contratos ativos, qualidade de dados
- **Métricas de sistema:** CPU, memória, disco
- **Métricas customizadas:** Por domínio de negócio

### Health Checks

```bash
# Health check básico
curl http://localhost:8000/health

# Health check detalhado
curl http://localhost:8000/health/detailed
```

## Segurança

### Autenticação e Autorização

- **JWT Tokens** para autenticação
- **RBAC** (Role-Based Access Control)
- **ABAC** (Attribute-Based Access Control)
- **Rate limiting** por usuário/IP

### Proteção de Dados

- **Mascaramento automático** de PII
- **Criptografia** de dados sensíveis
- **Auditoria completa** de acessos
- **Compliance** LGPD/GDPR automático

## Performance

### Otimizações Implementadas

- **Cache distribuído** com Redis
- **Conexões de banco** otimizadas
- **Índices** estratégicos no banco
- **Paginação** eficiente
- **Background tasks** para operações pesadas

### Benchmarks

- **Throughput:** 1000+ requests/segundo
- **Latência P95:** < 200ms
- **Disponibilidade:** 99.9%+
- **Tempo de resposta médio:** < 50ms

## Roadmap

### Versão 2.1 (Q1 2025)
- Interface web de governança
- Integrações com Informatica Axon
- Dashboard executivo avançado
- Relatórios automáticos

### Versão 2.2 (Q2 2025)
- Machine Learning avançado
- Predição de qualidade
- Recomendações automáticas
- Integração com Apache Atlas

### Versão 3.0 (Q3 2025)
- Arquitetura de microserviços
- Kubernetes nativo
- Multi-tenant
- GraphQL API

## Suporte

### Documentação

- **API Docs:** http://localhost:8000/docs
- **Guia Técnico:** `TECHNICAL_GUIDE_SNAKE_CASE.md`
- **Guia de Instalação:** `INSTALLATION_GUIDE_SNAKE_CASE.md`

### Contato

- **Autor:** Carlos Morais
- **Email:** carlos.morais@empresa.com
- **Documentação:** Disponível no projeto

## Licença

Este projeto está licenciado sob a Licença MIT. Veja o arquivo `LICENSE` para detalhes.

---

**Data Governance API Enterprise v2.0** - Transformando dados em valor através de governança inteligente.

