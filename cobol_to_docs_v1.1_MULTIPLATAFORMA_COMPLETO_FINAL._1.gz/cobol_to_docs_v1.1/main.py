#!/usr/bin/env python3
"""
COBOL to Docs v1.1 - Sistema de Análise e Documentação de Programas COBOL
Autor: Carlos Morais
Data: Setembro 2025

Sistema completo para análise automatizada de programas COBOL com geração
de documentação técnica profissional usando IA.

FUNCIONALIDADE COMPLETA RESTAURADA:
- Processamento de múltiplos programas COBOL
- Suporte a múltiplos modelos de IA
- Análise de copybooks complementares
- Geração de relatórios comparativos
- Detecção automática de código COBOL
"""

import argparse
import logging
import os
import sys
import json
import time
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.core.config import ConfigManager
from src.core.prompt_manager_dual import DualPromptManager
from src.providers.enhanced_provider_manager import EnhancedProviderManager
from src.parsers.cobol_parser_original import COBOLParser, CobolProgram, CobolBook
from src.analyzers.enhanced_cobol_analyzer import EnhancedCOBOLAnalyzer
from src.generators.documentation_generator import DocumentationGenerator
from src.utils.html_generator import HTMLReportGenerator

def setup_logging(log_level: str = "INFO") -> None:
    """Configura o sistema de logging."""
    log_dir = "logs"
    os.makedirs(log_dir, exist_ok=True)
    
    log_file = os.path.join(log_dir, f"cobol_to_docs_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
    
    logging.basicConfig(
        level=getattr(logging, log_level.upper()),
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file, encoding='utf-8'),
            logging.StreamHandler(sys.stdout)
        ]
    )

def parse_models_argument(models_str: str) -> List[str]:
    """Parse do argumento models que pode ser string ou lista JSON."""
    if not models_str:
        return []
    
    models_str = models_str.strip()
    
    # Se começa com [ é uma lista JSON
    if models_str.startswith('['):
        try:
            models = json.loads(models_str)
            return models if isinstance(models, list) else [models]
        except json.JSONDecodeError:
            print(f"Erro: Formato JSON inválido para models: {models_str}")
            sys.exit(1)
    else:
        # String simples
        return [models_str]

def analyze_program_with_model(program: CobolProgram, books: List[CobolBook], 
                             model: str, output_dir: str, config_manager: ConfigManager,
                             is_multi_model: bool = False, prompt_set: str = "original") -> Dict[str, Any]:
    """Analisa um programa COBOL com um modelo específico."""
    logger = logging.getLogger(__name__)
    
    # Criar diretório específico do modelo se multi-modelo
    if is_multi_model:
        model_output_dir = os.path.join(output_dir, f"model_{model.replace('/', '_').replace('-', '_')}")
        os.makedirs(model_output_dir, exist_ok=True)
    else:
        model_output_dir = output_dir
    
    try:
        # Inicializar componentes específicos para o modelo
        prompt_manager = DualPromptManager(config_manager.config, prompt_set)
        provider_manager = EnhancedProviderManager(config_manager.config)
        doc_generator = DocumentationGenerator(model_output_dir)
        
        # Análise com IA
        analyzer = EnhancedCOBOLAnalyzer(provider_manager, prompt_manager)
        
        start_time = time.time()
        analysis_result = analyzer.analyze_program(program, model)
        analysis_time = time.time() - start_time
        
        if not analysis_result.success:
            logger.error(f"Falha na análise de {program.name} com modelo {model}: {analysis_result.error_message}")
            return {
                'success': False,
                'program_name': program.name,
                'model': model,
                'error': analysis_result.error_message,
                'tokens_used': 0,
                'analysis_time': analysis_time,
                'output_dir': model_output_dir
            }
        
        # Gerar documentação
        from src.providers.base_provider import AIResponse
        ai_response = AIResponse(
            success=True,
            content=analysis_result.content,
            tokens_used=analysis_result.tokens_used,
            model=analysis_result.model_used
        )
        
        doc_result = doc_generator.generate_program_documentation(program, ai_response)
        
        logger.info(f"Análise de {program.name} com {model} bem-sucedida.")
        logger.info(f"Tokens utilizados: {analysis_result.tokens_used}")
        logger.info(f"Modelo utilizado: {analysis_result.model_used}")
        
        return {
            'success': True,
            'program_name': program.name,
            'model': model,
            'tokens_used': analysis_result.tokens_used,
            'analysis_time': analysis_time,
            'output_dir': model_output_dir,
            'files_generated': [doc_result] if doc_result else [],
            'response': analysis_result
        }
        
    except Exception as e:
        logger.error(f"Erro na análise de {program.name} com modelo {model}: {str(e)}")
        return {
            'success': False,
            'program_name': program.name,
            'model': model,
            'error': str(e),
            'tokens_used': 0,
            'analysis_time': 0,
            'output_dir': model_output_dir
        }

def generate_comparative_report(programs: List[CobolProgram], all_results: List[Dict[str, Any]], output_dir: str) -> None:
    """Gera relatório comparativo entre modelos."""
    logger = logging.getLogger(__name__)
    
    try:
        report_path = os.path.join(output_dir, "relatorio_comparativo_modelos.md")
        
        # Agrupar resultados por modelo
        models_used = list(set(r['model'] for r in all_results))
        results_by_model = {model: [r for r in all_results if r['model'] == model] for model in models_used}
        
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write("# Relatório Comparativo de Modelos\n\n")
            f.write(f"**Data:** {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}\n")
            f.write(f"**Programas Analisados:** {len(programs)}\n")
            f.write(f"**Modelos Utilizados:** {len(models_used)}\n\n")
            
            # Resumo geral
            f.write("## Resumo Geral\n\n")
            f.write("| Modelo | Sucessos | Falhas | Taxa de Sucesso | Tokens Médios |\n")
            f.write("|--------|----------|--------|-----------------|---------------|\n")
            
            for model in models_used:
                model_results = results_by_model[model]
                successes = sum(1 for r in model_results if r['success'])
                failures = len(model_results) - successes
                success_rate = (successes / len(model_results)) * 100 if model_results else 0
                avg_tokens = sum(r.get('tokens_used', 0) for r in model_results if r['success']) / max(successes, 1)
                
                f.write(f"| {model} | {successes} | {failures} | {success_rate:.1f}% | {avg_tokens:.0f} |\n")
            
            f.write("\n")
            
            # Detalhes por programa
            f.write("## Detalhes por Programa\n\n")
            
            for program in programs:
                f.write(f"### {program.name}\n\n")
                
                program_results = [r for r in all_results if r.get('program_name') == program.name]
                
                if program_results:
                    f.write("| Modelo | Status | Tokens | Qualidade | Diretório |\n")
                    f.write("|--------|--------|--------|-----------|----------|\n")
                    
                    for result in program_results:
                        status = "Sucesso" if result['success'] else "Falha"
                        tokens = result.get('tokens_used', 0)
                        quality = "Alta" if tokens > 2000 else "Média" if tokens > 1000 else "Baixa"
                        output_dir_name = os.path.basename(result['output_dir'])
                        
                        f.write(f"| {result['model']} | {status} | {tokens} | {quality} | {output_dir_name} |\n")
                    
                    f.write("\n")
                else:
                    f.write("Nenhum resultado encontrado para este programa.\n\n")
            
            # Recomendações
            f.write("## Recomendações\n\n")
            
            # Encontrar melhor modelo por taxa de sucesso
            best_model = max(models_used, key=lambda m: sum(1 for r in results_by_model[m] if r['success']) / len(results_by_model[m]))
            f.write(f"**Modelo Recomendado:** {best_model} (melhor taxa de sucesso)\n\n")
            
            # Encontrar modelo com mais tokens em média
            highest_tokens_model = max(models_used, key=lambda m: sum(r.get('tokens_used', 0) for r in results_by_model[m] if r['success']) / max(sum(1 for r in results_by_model[m] if r['success']), 1))
            f.write(f"**Modelo Mais Detalhado:** {highest_tokens_model} (maior média de tokens)\n\n")
            
            f.write("### Uso Recomendado por Cenário\n\n")
            f.write("- **Análise Rápida:** Use o modelo com melhor taxa de sucesso\n")
            f.write("- **Análise Detalhada:** Use o modelo com maior média de tokens\n")
            f.write("- **Análise Crítica:** Execute com múltiplos modelos e compare resultados\n")
            f.write("- **Produção:** Use o modelo mais estável baseado nas estatísticas\n\n")
            
            f.write("---\n")
            f.write("**Relatório gerado automaticamente pelo COBOL to Docs v1.1**\n")
        
        logger.info(f"Relatório comparativo gerado: {report_path}")
        
    except Exception as e:
        logger.error(f"Erro ao gerar relatório comparativo: {e}")

def process_cobol_files(args, config_manager: ConfigManager) -> None:
    """Processa arquivos COBOL com funcionalidade completa restaurada."""
    logger = logging.getLogger(__name__)
    
    # Parse dos modelos
    if hasattr(args, 'models') and args.models:
        models = parse_models_argument(args.models)
    else:
        ai_config = config_manager.config.get('ai', {})
        models = ai_config.get('default_models', ['aws-claude-3.7'])
    
    # Inicializar parser
    parser = COBOLParser()
    
    logger.info("=== INICIANDO PROCESSAMENTO COMPLETO ===")
    logger.info(f"Modelos selecionados: {models}")
    logger.info(f"Arquivo de fontes: {args.fontes}")
    if args.books:
        logger.info(f"Arquivo de books: {args.books}")
    logger.info(f"Diretório de saída: {args.output}")
    
    start_time = time.time()
    
    try:
        # Parse do arquivo principal
        programs, books = parser.parse_file(args.fontes)
        
        # Parse de copybooks adicionais se especificado
        if args.books and os.path.exists(args.books):
            _, additional_books = parser.parse_file(args.books)
            books.extend(additional_books)
        
        logger.info(f"Programas encontrados: {len(programs)}, Books encontrados: {len(books)}")
        
        if not programs:
            print("Nenhum programa encontrado para análise.")
            return
            
    except Exception as e:
        logger.error(f"Erro ao parsear arquivos: {str(e)}")
        return
    
    # Criar diretório de saída
    os.makedirs(args.output, exist_ok=True)
    
    all_results = []
    is_multi_model = len(models) > 1
    
    print(f"\nCOBOL to Docs v1.1 - Iniciando processamento")
    print(f"Autor: Carlos Morais")
    print(f"Programas COBOL: {len(programs)}")
    if books:
        print(f"Copybooks: {len(books)}")
    print(f"Modelos: {', '.join(models)}")
    print(f"Diretório de saída: {args.output}")
    print("=" * 60)
    
    # Processamento baseado no número de modelos
    if not is_multi_model:
        # Modelo único - estrutura simples
        model = models[0]
        for i, program in enumerate(programs, 1):
            print(f"Analisando programa {i}/{len(programs)}: {program.name}")
            
            result = analyze_program_with_model(
                program, books, model, args.output, config_manager, is_multi_model, args.prompt_set
            )
            
            all_results.append(result)
    else:
        # Múltiplos modelos - estrutura com diretórios separados
        total_analyses = len(programs) * len(models)
        current_analysis = 0
        
        for i, program in enumerate(programs, 1):
            logger.info(f"\nPrograma {i}/{len(programs)}: {program.name}")
            
            for j, model in enumerate(models, 1):
                current_analysis += 1
                print(f"Analisando {program.name} com {model} ({current_analysis}/{total_analyses})")
                
                result = analyze_program_with_model(
                    program, books, model, args.output, config_manager, is_multi_model, args.prompt_set
                )
                
                all_results.append(result)
    
    # Gerar relatório comparativo se múltiplos modelos
    if is_multi_model:
        generate_comparative_report(programs, all_results, args.output)
    
    # Estatísticas finais
    processing_time = time.time() - start_time
    successful_analyses = sum(1 for r in all_results if r['success'])
    total_tokens = sum(r.get('tokens_used', 0) for r in all_results if r['success'])
    
    print()
    print("=" * 60)
    print("PROCESSAMENTO CONCLUÍDO")
    print(f"Programas processados: {len(programs)}")
    print(f"Modelos utilizados: {len(models)} ({', '.join(models)})")
    print(f"Análises bem-sucedidas: {successful_analyses}/{len(all_results)}")
    print(f"Taxa de sucesso geral: {(successful_analyses/len(all_results)*100):.1f}%")
    print(f"Total de tokens utilizados: {total_tokens:,}")
    print(f"Tempo total de processamento: {processing_time:.2f}s")
    print(f"Documentação gerada em: {args.output}")
    if is_multi_model:
        print(f"Relatório comparativo: {os.path.join(args.output, 'relatorio_comparativo_modelos.md')}")

def main():
    """Função principal."""
    parser = argparse.ArgumentParser(
        description="COBOL to Docs v1.1 - Análise e Documentação de Programas COBOL",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Exemplos de uso:
  python main.py --fontes examples/fontes.txt
  python main.py --fontes examples/fontes.txt --books examples/books.txt
  python main.py --fontes examples/fontes.txt --models '["aws-claude-3.7", "enhanced_mock"]'
  python main.py --status
        """
    )
    
    parser.add_argument('--fontes', type=str, help='Arquivo com programas COBOL')
    parser.add_argument('--books', type=str, help='Arquivo com copybooks COBOL')
    parser.add_argument('--output', type=str, default='output', help='Diretório de saída')
    parser.add_argument('--models', type=str, help='Modelos de IA (string ou JSON array)')
    parser.add_argument('--prompt-set', type=str, default='original', help='Conjunto de prompts')
    parser.add_argument('--log-level', type=str, default='INFO', help='Nível de log')
    parser.add_argument('--status', action='store_true', help='Verificar status dos provedores')
    
    args = parser.parse_args()
    
    # Configurar logging
    setup_logging(args.log_level)
    logger = logging.getLogger(__name__)
    
    try:
        # Carregar configuração
        config_manager = ConfigManager()
        
        # Verificar status se solicitado
        if args.status:
            provider_manager = EnhancedProviderManager(config_manager.config)
            print("=== STATUS DOS PROVEDORES ===")
            for name, available in provider_manager.get_provider_status().items():
                status = "Disponível" if available else "Indisponível"
                print(f"{name}: {status}")
            return
        
        # Validar argumentos
        if not args.fontes:
            print("Erro: --fontes é obrigatório")
            parser.print_help()
            return
        
        if not os.path.exists(args.fontes):
            print(f"Erro: Arquivo não encontrado: {args.fontes}")
            return
        
        # Processar arquivos COBOL
        process_cobol_files(args, config_manager)
        
    except KeyboardInterrupt:
        print("\nProcessamento interrompido pelo usuário.")
    except Exception as e:
        logger.error(f"Erro fatal: {str(e)}")
        print(f"Erro: {str(e)}")

if __name__ == "__main__":
    main()
