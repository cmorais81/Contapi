#!/usr/bin/env python3.11
# -*- coding: utf-8 -*-
"""
Sistema de Análise COBOL v2.2.2 - GitHub Copilot Provider
Provider para integração com GitHub Copilot API

Autor:  análise
Data: 17 de Setembro de 2025
"""

import logging
import time
import json
import requests
from typing import Dict, Any, Optional
from .base_provider import BaseProvider, AIRequest, AIResponse


class CopilotProvider(BaseProvider):
    """
    Provider para GitHub Copilot API.
    
    Funcionalidades:
    - Integração com Copilot Chat API
    - Análise de código especializada
    - Suporte a múltiplos modelos
    - Rate limiting e retry automático
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Inicializa o provider do GitHub Copilot.
        
        Args:
            config: Configuração do provider
        """
        super().__init__(config)
        self.logger = logging.getLogger(__name__)
        
        # Configurações específicas do Copilot
        self.api_token = config.get('api_token', '')
        self.api_url = config.get('api_url', 'https://api.githubcopilot.com/chat/completions')
        self.model = config.get('model', 'gpt-4')
        self.organization = config.get('organization', '')
        
        # Configurações de request
        self.max_tokens = config.get('max_tokens', 8000)
        self.temperature = config.get('temperature', 0.1)
        self.timeout = config.get('timeout', 120)
        
        # Configurações de retry
        retry_config = config.get('retry', {})
        self.max_retries = retry_config.get('max_attempts', 3)
        self.base_delay = retry_config.get('base_delay', 1.0)
        self.max_delay = retry_config.get('max_delay', 30.0)
        self.backoff_multiplier = retry_config.get('backoff_multiplier', 2.0)
        
        # Rate limiting
        self.requests_per_minute = config.get('requests_per_minute', 20)
        self.last_request_time = 0
        self.request_count = 0
        self.request_times = []
        
        # Estatísticas
        self.stats = {
            'total_requests': 0,
            'successful_requests': 0,
            'failed_requests': 0,
            'total_tokens': 0,
            'average_response_time': 0,
            'last_error': None
        }
        
        self.logger.info(f"Copilot Provider inicializado - Modelo: {self.model}")
        self.logger.info(f"Max tokens: {self.max_tokens}, Temperature: {self.temperature}")
        self.logger.info(f"Rate limit: {self.requests_per_minute} req/min")
    
    def is_available(self) -> bool:
        """Verifica se o provider está disponível."""
        if not self.api_token:
            self.logger.warning("Copilot API token não configurado")
            return False
        
        try:
            # Teste simples de conectividade
            headers = self._get_headers()
            response = requests.get(
                'https://api.github.com/user',
                headers=headers,
                timeout=10
            )
            return response.status_code == 200
        except Exception as e:
            self.logger.error(f"Erro ao verificar disponibilidade do Copilot: {e}")
            return False
    
    def analyze(self, request: AIRequest) -> AIResponse:
        """
        Realiza análise usando GitHub Copilot.
        
        Args:
            request: Requisição de análise
            
        Returns:
            Resposta da análise
        """
        start_time = time.time()
        self.stats['total_requests'] += 1
        
        try:
            # Rate limiting
            self._enforce_rate_limit()
            
            # Preparar payload
            payload = self._prepare_payload(request)
            
            # Executar request com retry
            response_data = self._execute_with_retry(payload)
            
            if response_data:
                # Processar resposta
                content = self._extract_content(response_data)
                tokens_used = self._extract_token_count(response_data)
                
                # Atualizar estatísticas
                response_time = time.time() - start_time
                self._update_stats(True, tokens_used, response_time)
                
                self.logger.info(f"Análise Copilot concluída: {tokens_used} tokens, {response_time:.2f}s")
                
                return AIResponse(
                    success=True,
                    content=content,
                    tokens_used=tokens_used,
                    model=self.model,
                    provider="copilot",
                    response_time=response_time
                )
            else:
                self._update_stats(False, 0, time.time() - start_time)
                return AIResponse(
                    success=False,
                    content="",
                    tokens_used=0,
                    model=self.model,
                    provider="copilot",
                    error_message="Falha na comunicação com Copilot"
                )
                
        except Exception as e:
            self.logger.error(f"Erro na análise Copilot: {e}")
            self._update_stats(False, 0, time.time() - start_time)
            return AIResponse(
                success=False,
                content="",
                tokens_used=0,
                model=self.model,
                provider="copilot",
                error_message=str(e)
            )
    
    def _get_headers(self) -> Dict[str, str]:
        """Prepara headers para requisição."""
        headers = {
            'Authorization': f'Bearer {self.api_token}',
            'Content-Type': 'application/json',
            'User-Agent': 'COBOL-AI-Engine/2.2.2',
            'Accept': 'application/json'
        }
        
        if self.organization:
            headers['OpenAI-Organization'] = self.organization
            
        return headers
    
    def _prepare_payload(self, request: AIRequest) -> Dict[str, Any]:
        """Prepara payload para a API do Copilot."""
        
        # Preparar mensagens no formato do Copilot
        messages = []
        
        # System message se fornecido
        if hasattr(request, 'system_prompt') and request.system_prompt:
            messages.append({
                "role": "system",
                "content": request.system_prompt
            })
        
        # User message principal
        messages.append({
            "role": "user",
            "content": request.prompt
        })
        
        payload = {
            "model": self.model,
            "messages": messages,
            "max_tokens": min(request.max_tokens or self.max_tokens, self.max_tokens),
            "temperature": request.temperature if hasattr(request, 'temperature') else self.temperature,
            "stream": False,
            "top_p": 1.0,
            "frequency_penalty": 0,
            "presence_penalty": 0
        }
        
        return payload
    
    def _execute_with_retry(self, payload: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Executa requisição com retry automático."""
        
        headers = self._get_headers()
        last_exception = None
        
        for attempt in range(self.max_retries + 1):
            try:
                self.logger.debug(f"Tentativa {attempt + 1}/{self.max_retries + 1} para Copilot")
                
                response = requests.post(
                    self.api_url,
                    headers=headers,
                    json=payload,
                    timeout=self.timeout
                )
                
                if response.status_code == 200:
                    return response.json()
                elif response.status_code == 429:
                    # Rate limit - aguardar mais tempo
                    retry_after = int(response.headers.get('Retry-After', 60))
                    self.logger.warning(f"Rate limit Copilot - aguardando {retry_after}s")
                    time.sleep(retry_after)
                    continue
                elif response.status_code in [401, 403]:
                    # Erro de autenticação - não retry
                    self.logger.error(f"Erro de autenticação Copilot: {response.status_code}")
                    self.stats['last_error'] = f"Auth error: {response.status_code}"
                    return None
                else:
                    # Outros erros HTTP
                    self.logger.warning(f"Erro HTTP Copilot: {response.status_code} - {response.text}")
                    last_exception = Exception(f"HTTP {response.status_code}: {response.text}")
                    
            except requests.exceptions.Timeout:
                self.logger.warning(f"Timeout na tentativa {attempt + 1} para Copilot")
                last_exception = Exception("Request timeout")
                
            except requests.exceptions.ConnectionError:
                self.logger.warning(f"Erro de conexão na tentativa {attempt + 1} para Copilot")
                last_exception = Exception("Connection error")
                
            except Exception as e:
                self.logger.warning(f"Erro na tentativa {attempt + 1} para Copilot: {e}")
                last_exception = e
            
            # Aguardar antes da próxima tentativa
            if attempt < self.max_retries:
                delay = min(self.base_delay * (self.backoff_multiplier ** attempt), self.max_delay)
                self.logger.debug(f"Aguardando {delay:.1f}s antes da próxima tentativa")
                time.sleep(delay)
        
        # Todas as tentativas falharam
        error_msg = str(last_exception) if last_exception else "Todas as tentativas falharam"
        self.logger.error(f"Falha definitiva na comunicação com Copilot: {error_msg}")
        self.stats['last_error'] = error_msg
        return None
    
    def _extract_content(self, response_data: Dict[str, Any]) -> str:
        """Extrai conteúdo da resposta do Copilot."""
        try:
            choices = response_data.get('choices', [])
            if choices:
                message = choices[0].get('message', {})
                content = message.get('content', '')
                return content.strip()
            return ""
        except Exception as e:
            self.logger.error(f"Erro ao extrair conteúdo da resposta Copilot: {e}")
            return ""
    
    def _extract_token_count(self, response_data: Dict[str, Any]) -> int:
        """Extrai contagem de tokens da resposta."""
        try:
            usage = response_data.get('usage', {})
            return usage.get('total_tokens', 0)
        except Exception as e:
            self.logger.debug(f"Erro ao extrair tokens da resposta Copilot: {e}")
            return 0
    
    def _enforce_rate_limit(self):
        """Aplica rate limiting."""
        current_time = time.time()
        
        # Limpar requests antigos (mais de 1 minuto)
        self.request_times = [t for t in self.request_times if current_time - t < 60]
        
        # Verificar se excedeu o limite
        if len(self.request_times) >= self.requests_per_minute:
            sleep_time = 60 - (current_time - self.request_times[0])
            if sleep_time > 0:
                self.logger.info(f"Rate limit Copilot - aguardando {sleep_time:.1f}s")
                time.sleep(sleep_time)
        
        # Registrar esta requisição
        self.request_times.append(current_time)
    
    def _update_stats(self, success: bool, tokens: int, response_time: float):
        """Atualiza estatísticas do provider."""
        if success:
            self.stats['successful_requests'] += 1
            self.stats['total_tokens'] += tokens
        else:
            self.stats['failed_requests'] += 1
        
        # Atualizar tempo médio de resposta
        total_requests = self.stats['successful_requests'] + self.stats['failed_requests']
        if total_requests > 0:
            current_avg = self.stats['average_response_time']
            self.stats['average_response_time'] = (current_avg * (total_requests - 1) + response_time) / total_requests
    
    def get_statistics(self) -> Dict[str, Any]:
        """Retorna estatísticas do provider."""
        return {
            **self.stats,
            'provider': 'copilot',
            'model': self.model,
            'rate_limit': f"{self.requests_per_minute} req/min",
            'max_tokens': self.max_tokens,
            'temperature': self.temperature,
            'success_rate': (
                self.stats['successful_requests'] / max(self.stats['total_requests'], 1) * 100
            )
        }
    
    def get_provider_info(self) -> Dict[str, Any]:
        """Retorna informações do provider."""
        return {
            'name': 'GitHub Copilot',
            'version': '2.2.2',
            'model': self.model,
            'max_tokens': self.max_tokens,
            'temperature': self.temperature,
            'rate_limit': f"{self.requests_per_minute} req/min",
            'features': [
                'Code analysis',
                'Documentation generation',
                'Pattern recognition',
                'Best practices suggestions',
                'Multi-language support'
            ],
            'specialties': [
                'Code understanding',
                'Refactoring suggestions',
                'Modern patterns',
                'Migration guidance',
                'Technical documentation'
            ]
        }
