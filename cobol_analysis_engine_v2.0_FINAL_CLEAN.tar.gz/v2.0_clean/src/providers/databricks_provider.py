"""
Provedor Databricks para Sistema de Análise COBOL.
Integração com Databricks Model Serving para análise de código COBOL.
"""

import os
import json
import logging
from typing import Dict, Any, Optional
from datetime import datetime

try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False

from .base_provider import BaseProvider, AIRequest, AIResponse


class DatabricksProvider(BaseProvider):
    """
    Provedor Databricks com integração completa para Model Serving.
    
    Funcionalidades implementadas:
    - Autenticação via Personal Access Token
    - Integração com Databricks Model Serving
    - Suporte a múltiplos modelos (Foundation Models)
    - Rate limiting e controle de tokens
    - Tratamento robusto de erros
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Inicializa o provedor Databricks.
        
        Args:
            config: Configuração do provedor
        """
        super().__init__(config)
        
        # Verificar dependências
        if not REQUESTS_AVAILABLE:
            raise ImportError("requests é necessário para o DatabricksProvider")
        
        # Configurações do Databricks
        self.workspace_url = config.get('workspace_url', os.getenv('DATABRICKS_WORKSPACE_URL'))
        self.access_token = config.get('access_token', os.getenv('DATABRICKS_ACCESS_TOKEN'))
        self.model_endpoint = config.get('model_endpoint', 'databricks-meta-llama-3-1-405b-instruct')
        self.model_name = config.get('model', 'llama-3.1-405b-instruct')
        
        # Parâmetros do modelo
        self.temperature = config.get('temperature', 0.1)
        self.max_tokens = config.get('max_tokens', 4000)
        self.timeout = config.get('timeout', 120)
        
        # Controle de tokens
        self.max_tokens_per_request = config.get('max_tokens_per_request', 4000)
        self.max_tokens_per_hour = config.get('max_tokens_per_hour', 100000)
        self.max_tokens_per_day = config.get('max_tokens_per_day', 500000)
        
        # Configurar logger
        self.logger = logging.getLogger(f"DatabricksProvider")
        
        # Validar configuração
        if not self.workspace_url:
            raise ValueError("workspace_url é obrigatório para DatabricksProvider")
        if not self.access_token:
            raise ValueError("access_token é obrigatório para DatabricksProvider")
        
        # Headers para requisições
        self.headers = {
            'Authorization': f'Bearer {self.access_token}',
            'Content-Type': 'application/json'
        }
        
        # URL da API
        self.api_url = f"{self.workspace_url.rstrip('/')}/serving-endpoints/{self.model_endpoint}/invocations"
        
        self.logger.info(f"Databricks Provider inicializado - Modelo: {self.model_name}")
    
    def is_available(self) -> bool:
        """
        Verifica se o provedor está disponível.
        
        Returns:
            True se disponível, False caso contrário
        """
        try:
            # Fazer uma requisição de teste simples
            test_url = f"{self.workspace_url.rstrip('/')}/api/2.0/clusters/list"
            response = requests.get(
                test_url,
                headers=self.headers,
                timeout=10
            )
            return response.status_code in [200, 403]  # 403 é ok, significa que auth funcionou
        except Exception as e:
            self.logger.debug(f"Databricks não disponível: {e}")
            return False
    
    def analyze(self, request: AIRequest) -> AIResponse:
        """
        Realiza análise usando o modelo Databricks.
        
        Args:
            request: Requisição de análise
            
        Returns:
            Resposta da análise
        """
        try:
            # Carregar system prompt do arquivo de configuração
            from ..core.config import ConfigManager
            config_manager = ConfigManager("config/config_unified.yaml")
            system_prompt = config_manager.get_system_prompt()
            
            # Preparar prompt
            prompt = self._prepare_prompt(request)
            
            # Preparar payload
            payload = {
                "messages": [
                    {
                        "role": "system",
                        "content": system_prompt
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                "temperature": self.temperature,
                "max_tokens": min(self.max_tokens, self.max_tokens_per_request)
            }
            
            self.logger.debug(f"Enviando requisição para Databricks: {self.model_endpoint}")
            
            # Fazer requisição
            response = requests.post(
                self.api_url,
                headers=self.headers,
                json=payload,
                timeout=self.timeout
            )
            
            if response.status_code == 200:
                result = response.json()
                
                # Extrair resposta
                if 'choices' in result and len(result['choices']) > 0:
                    content = result['choices'][0]['message']['content']
                    
                    # Calcular tokens (estimativa)
                    tokens_used = self._estimate_tokens(prompt + content)
                    
                    return AIResponse(
                        success=True,
                        content=content,
                        tokens_used=tokens_used,
                        model=self.model_name,
                        provider="databricks",
                        timestamp=datetime.now(),
                        metadata={
                            'endpoint': self.model_endpoint,
                            'workspace_url': self.workspace_url,
                            'temperature': self.temperature,
                            'max_tokens': self.max_tokens
                        }
                    )
                else:
                    raise Exception("Resposta inválida do Databricks")
            
            else:
                error_msg = f"Erro HTTP {response.status_code}: {response.text}"
                self.logger.error(f"Erro na requisição Databricks: {error_msg}")
                
                return AIResponse(
                    success=False,
                    content="",
                    tokens_used=0,
                    model=self.model_name,
                    provider="databricks",
                    timestamp=datetime.now(),
                    error_message=error_msg
                )
                
        except Exception as e:
            error_msg = f"Erro no DatabricksProvider: {str(e)}"
            self.logger.error(error_msg)
            
            return AIResponse(
                success=False,
                content="",
                tokens_used=0,
                model=self.model_name,
                provider="databricks",
                timestamp=datetime.now(),
                error_message=error_msg
            )
    
    def _prepare_prompt(self, request: AIRequest) -> str:
        """
        Prepara o prompt para o modelo Databricks.
        
        Args:
            request: Requisição de análise
            
        Returns:
            Prompt formatado
        """
        prompt = f"""Você é um especialista em análise de código COBOL. Analise o seguinte programa COBOL e forneça uma análise detalhada.

PROGRAMA: {request.program_name}

CÓDIGO COBOL:
```cobol
{request.program_code}
```

PERGUNTA: {request.prompt}

Por favor, forneça uma análise técnica detalhada, incluindo:
1. Funcionalidade principal do programa
2. Estruturas de dados utilizadas
3. Lógica de negócio implementada
4. Arquivos e datasets manipulados
5. Possíveis melhorias ou observações

Responda em português brasileiro de forma clara e estruturada."""

        return prompt
    
    def _estimate_tokens(self, text: str) -> int:
        """
        Estima o número de tokens em um texto.
        
        Args:
            text: Texto para estimar
            
        Returns:
            Número estimado de tokens
        """
        # Estimativa simples: ~4 caracteres por token
        return len(text) // 4
    
    def get_model_info(self) -> Dict[str, Any]:
        """
        Retorna informações sobre o modelo.
        
        Returns:
            Informações do modelo
        """
        return {
            'provider': 'databricks',
            'model': self.model_name,
            'endpoint': self.model_endpoint,
            'workspace_url': self.workspace_url,
            'max_tokens': self.max_tokens,
            'temperature': self.temperature,
            'timeout': self.timeout
        }

