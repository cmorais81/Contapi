import re
import logging
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass

@dataclass
class FieldDefinition:
    name: str
    level: int
    start_position: int
    length: int
    storage_length: int
    data_type: str
    picture_clause: str
    occurs: Optional[int] = None
    redefines: Optional[str] = None
    value: Optional[str] = None
    usage: Optional[str] = None

class ImprovedRecordLayoutParser:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.field_pattern = re.compile(
            r'^\s*(\d{2})\s+([A-Z0-9\-_]+)(?:\s+REDEFINES\s+([A-Z0-9\-_]+))?\s*'
            r'(?:PIC\s+([X9SVZ\(\)\.\-\+]+))?\s*'
            r'(?:OCCURS\s+(\d+))?\s*'
            r'(?:USAGE\s+IS\s+)?(COMPUTATIONAL-3|COMP-3|COMPUTATIONAL|COMP)?\s*\.?\s*$',
            re.IGNORECASE
        )

    def parse(self, lines: List[str]) -> Dict[str, List[FieldDefinition]]:
        layouts = {}
        in_data_division = False
        current_record_name = None
        current_fields = []
        field_map = {}

        for line in lines:
            if 'DATA DIVISION' in line.upper():
                in_data_division = True
                continue
            if 'PROCEDURE DIVISION' in line.upper():
                break
            if not in_data_division:
                continue

            clean_line = line[6:].strip()
            if not clean_line or clean_line.startswith('*'):
                continue

            match = self.field_pattern.match(clean_line)
            if not match:
                continue

            level, name, redefines, pic_clause, occurs, usage = match.groups()
            level = int(level)

            if level == 1:
                if current_record_name and current_fields:
                    layouts[current_record_name] = self._calculate_positions(current_fields)
                current_record_name = name
                current_fields = []
                field_map = {}

            if not current_record_name:
                continue

            field = self._create_field_definition(level, name, redefines, pic_clause, occurs, usage, field_map)
            current_fields.append(field)
            field_map[name] = field

        if current_record_name and current_fields:
            layouts[current_record_name] = self._calculate_positions(current_fields)

        return layouts

    def _create_field_definition(self, level, name, redefines, pic_clause, occurs, usage, field_map):
        pic_clause = pic_clause or ''
        usage = usage or ''
        occurs = int(occurs) if occurs else None

        data_type, length = self._analyze_picture_clause(pic_clause)
        storage_length = self._calculate_storage_length(pic_clause, usage)

        if occurs:
            length *= occurs
            storage_length *= occurs

        return FieldDefinition(
            name=name, level=level, start_position=0, length=length, storage_length=storage_length,
            data_type=data_type, picture_clause=pic_clause, occurs=occurs, redefines=redefines, value=None, usage=usage
        )

    def _calculate_positions(self, fields: List[FieldDefinition]) -> List[FieldDefinition]:
        position = 1
        for i, field in enumerate(fields):
            if field.redefines:
                redefined_field = next((f for f in fields if f.name == field.redefines), None)
                if redefined_field:
                    field.start_position = redefined_field.start_position
                else:
                    field.start_position = -1 # Error case
            else:
                field.start_position = position
                position += field.storage_length
        return fields

    def _analyze_picture_clause(self, pic_clause: str) -> Tuple[str, int]:
        pic_clean = pic_clause.upper().strip()
        if not pic_clean:
            return 'group', 0

        if 'X' in pic_clean:
            data_type = 'alphanumeric'
        elif '9' in pic_clean:
            data_type = 'numeric'
        elif 'A' in pic_clean:
            data_type = 'alphabetic'
        else:
            data_type = 'unknown'

        match = re.search(r'\((\d+)\)', pic_clean)
        if match:
            length = int(match.group(1))
        else:
            length = len(pic_clean.replace('S', '').replace('V', ''))

        return data_type, length

    def _calculate_storage_length(self, pic_clause: str, usage: str) -> int:
        pic_clause = pic_clause.upper()
        usage = usage.upper()

        if 'COMP-3' in usage or 'COMPUTATIONAL-3' in usage:
            match = re.findall(r'9', pic_clause)
            num_digits = len(match)
            return (num_digits // 2) + 1

        if '(' in pic_clause:
            match = re.search(r'\((\d+)\)', pic_clause)
            return int(match.group(1)) if match else 0
        else:
            return len(pic_clause.replace('S', '').replace('V', ''))

