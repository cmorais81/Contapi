# COBOL AI Engine v2.7.0 - Manual dos Provedores

## Visão Geral

O COBOL AI Engine v2.7.0 suporta 6 provedores diferentes de IA para análise de código COBOL:

1. **LuzIA Real** - Para ambiente corporativo Santander
2. **Databricks** - Para análise com Foundation Models via Databricks
3. **AWS Bedrock** - Para análise com Amazon Bedrock
4. **Enhanced Mock** - Provedor simulado avançado (sempre disponível)
5. **Basic** - Provedor básico de fallback (nunca falha)
6. **LuzIA Mock** - Provedor simulado LuzIA

## Provedores Disponíveis

### 1. LuzIA Real

**Descrição**: Integração com o ambiente corporativo LuzIA do Santander.

**Configuração**:
```yaml
luzia_real:
  enabled: true
  client_id: "${LUZIA_CLIENT_ID}"
  client_secret: "${LUZIA_CLIENT_SECRET}"
  model: "azure-gpt-4o-mini"
  api_base: "https://prd-api-aws.santanderbr.dev.corp"
  auth_url: "https://login.azure.pass.santanderbr.pre.corp/auth/realms/corp/protocol/openid-connect/token"
  api_url: "https://prd-api-aws.santanderbr.dev.corp/genai_services/v1/pipelines/submit"
  client_header_id: "1e63be7f-631c-44c1-acbe-5f4f5b26680e"
  temperature: 0.0
  timeout: 180
```

**Variáveis de Ambiente**:
```bash
export LUZIA_CLIENT_ID="seu_client_id"
export LUZIA_CLIENT_SECRET="seu_client_secret"
```

**Uso**:
```bash
python main.py --config config/config_luzia_real.yaml --fontes examples/fontes.txt --output resultado
```

### 2. Databricks

**Descrição**: Integração com Databricks Model Serving para Foundation Models.

**Configuração**:
```yaml
databricks:
  enabled: true
  workspace_url: "${DATABRICKS_WORKSPACE_URL}"
  access_token: "${DATABRICKS_ACCESS_TOKEN}"
  model_endpoint: "databricks-meta-llama-3-1-405b-instruct"
  model: "llama-3.1-405b-instruct"
  temperature: 0.1
  max_tokens: 4000
  timeout: 120
```

**Variáveis de Ambiente**:
```bash
export DATABRICKS_WORKSPACE_URL="https://seu-workspace.cloud.databricks.com"
export DATABRICKS_ACCESS_TOKEN="seu_personal_access_token"
```

**Uso**:
```bash
python main.py --config config/config_databricks.yaml --fontes examples/fontes.txt --output resultado
```

### 3. AWS Bedrock

**Descrição**: Integração com Amazon Bedrock para Foundation Models.

**Configuração**:
```yaml
bedrock:
  enabled: true
  region: "${AWS_REGION:-us-east-1}"
  access_key_id: "${AWS_ACCESS_KEY_ID}"
  secret_access_key: "${AWS_SECRET_ACCESS_KEY}"
  session_token: "${AWS_SESSION_TOKEN}"
  model_id: "anthropic.claude-3-sonnet-20240229-v1:0"
  model: "claude-3-sonnet"
  temperature: 0.1
  max_tokens: 4000
```

**Variáveis de Ambiente**:
```bash
export AWS_REGION="us-east-1"
export AWS_ACCESS_KEY_ID="seu_access_key"
export AWS_SECRET_ACCESS_KEY="seu_secret_key"
# Opcional para sessões temporárias
export AWS_SESSION_TOKEN="seu_session_token"
```

**Uso**:
```bash
python main.py --config config/config_bedrock.yaml --fontes examples/fontes.txt --output resultado
```

### 4. Enhanced Mock

**Descrição**: Provedor simulado avançado que sempre funciona.

**Configuração**:
```yaml
enhanced_mock:
  enabled: true
  response_delay: 0.1
  enable_phasing: true
  max_tokens_per_phase: 2000
  simulate_realistic_tokens: true
  cobol_analysis_enabled: true
```

**Uso**: Habilitado por padrão em todas as configurações.

### 5. Basic

**Descrição**: Provedor básico de fallback que nunca falha.

**Configuração**:
```yaml
basic:
  enabled: true
  max_tokens: 1000
  response_delay: 0.05
```

**Uso**: Sempre habilitado como fallback final.

### 6. LuzIA Mock

**Descrição**: Provedor simulado que imita o comportamento do LuzIA Real.

**Configuração**:
```yaml
luzia:
  enabled: true
  response_delay: 0.2
  simulate_auth: true
```

## Configurações Pré-definidas

### config_safe.yaml
- **Provedores**: Enhanced Mock + Basic
- **Uso**: Sempre funciona, ideal para testes
- **Comando**: `--config config/config_safe.yaml`

### config_databricks.yaml
- **Provedores**: Databricks + Enhanced Mock + Basic
- **Uso**: Análise com Databricks como primário
- **Comando**: `--config config/config_databricks.yaml`

### config_bedrock.yaml
- **Provedores**: Bedrock + Enhanced Mock + Basic
- **Uso**: Análise com AWS Bedrock como primário
- **Comando**: `--config config/config_bedrock.yaml`

### config_luzia_real.yaml
- **Provedores**: LuzIA Real + Enhanced Mock + Basic
- **Uso**: Ambiente corporativo Santander
- **Comando**: `--config config/config_luzia_real.yaml`

### config_complete.yaml
- **Provedores**: Todos disponíveis (desabilitados por padrão)
- **Uso**: Configuração completa para customização
- **Comando**: `--config config/config_complete.yaml`

## Modelos Suportados

### Databricks
- Llama 3.1 405B Instruct
- Llama 3.1 70B Instruct
- Llama 3.1 8B Instruct
- Outros Foundation Models disponíveis

### AWS Bedrock
- **Claude**: anthropic.claude-3-sonnet-20240229-v1:0
- **Claude Haiku**: anthropic.claude-3-haiku-20240307-v1:0
- **Llama**: meta.llama3-70b-instruct-v1:0
- **Titan**: amazon.titan-text-express-v1

### LuzIA Real
- Azure GPT-4o Mini
- Azure GPT-4o
- Outros modelos disponíveis no ambiente

## Autenticação

### Databricks
- **Método**: Personal Access Token
- **Configuração**: Via variáveis de ambiente ou arquivo de configuração
- **Documentação**: [Databricks Authentication](https://docs.databricks.com/dev-tools/auth.html)

### AWS Bedrock
- **Método**: AWS Credentials (Access Key + Secret Key)
- **Configuração**: Via AWS CLI, variáveis de ambiente ou IAM roles
- **Documentação**: [AWS Bedrock Authentication](https://docs.aws.amazon.com/bedrock/latest/userguide/security-iam.html)

### LuzIA Real
- **Método**: OAuth2 Client Credentials
- **Configuração**: Via variáveis de ambiente corporativas
- **Documentação**: Consulte documentação interna do Santander

## Troubleshooting

### Databricks
```bash
# Testar conectividade
curl -H "Authorization: Bearer $DATABRICKS_ACCESS_TOKEN" \
     "$DATABRICKS_WORKSPACE_URL/api/2.0/clusters/list"
```

### AWS Bedrock
```bash
# Testar credenciais
aws bedrock list-foundation-models --region us-east-1
```

### LuzIA Real
```bash
# Verificar variáveis
echo $LUZIA_CLIENT_ID
echo $LUZIA_CLIENT_SECRET
```

## Fallback e Redundância

O sistema implementa fallback automático:

1. **Provedor Primário**: Definido na configuração
2. **Provedores de Fallback**: Lista ordenada de alternativas
3. **Fallback Final**: Sempre Enhanced Mock + Basic

Exemplo de configuração de fallback:
```yaml
ai:
  primary_provider: "databricks"
  fallback_providers: 
    - "bedrock"
    - "luzia_real"
    - "enhanced_mock"
    - "basic"
```

## Monitoramento

### Logs
- Cada provedor gera logs específicos
- Nível de log configurável (DEBUG, INFO, WARNING, ERROR)
- Logs incluem tokens utilizados e tempo de resposta

### Métricas
- Tokens utilizados por provedor
- Taxa de sucesso por provedor
- Tempo médio de resposta
- Número de fallbacks executados

### Status
```bash
# Ver status de todos os provedores
python main.py --config config/config_complete.yaml --status
```

