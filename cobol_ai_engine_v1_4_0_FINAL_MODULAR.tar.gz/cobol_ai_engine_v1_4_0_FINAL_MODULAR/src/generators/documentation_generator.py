#!/usr/bin/env python3
"""
COBOL AI Engine v1.0.8 - Documentation Generator
Gerador de documentação para análises de programas COBOL com transparência total.
"""

import os
import json
import logging
from datetime import datetime
from typing import Dict, Any, Optional, List

from parsers.cobol_parser import CobolProgram
from providers.base_provider import AIResponse


class DocumentationGenerator:
    """Gerador de documentação para análises COBOL."""
    
    def __init__(self, output_dir: str = "output"):
        """
        Inicializa o gerador de documentação.
        
        Args:
            output_dir: Diretório base para saída
        """
        self.output_dir = output_dir
        self.logger = logging.getLogger(__name__)
        self.files_generated = 0
        self.total_programs = 0
        
        # Criar diretórios necessários
        os.makedirs(output_dir, exist_ok=True)
        
        # Diretório para JSONs das respostas
        self.json_dir = os.path.join(output_dir, "ai_responses")
        os.makedirs(self.json_dir, exist_ok=True)
        
        # Diretório para JSONs dos requests
        self.request_dir = os.path.join(output_dir, "ai_requests")
        os.makedirs(self.request_dir, exist_ok=True)
    
    def generate_program_documentation(self, program: CobolProgram, 
                                     ai_response: AIResponse,
                                     phase_info: Optional[Dict[str, Any]] = None) -> str:
        """
        Gera documentação completa para um programa COBOL.
        
        Args:
            program: Programa COBOL analisado
            ai_response: Resposta da análise de IA
            phase_info: Informações de faseamento (opcional)
            
        Returns:
            Caminho do arquivo gerado
        """
        try:
            # Gerar conteúdo da documentação
            content = self._generate_program_content(program, ai_response, phase_info)
            
            # Definir nome do arquivo
            filename = f"{program.name}.md"
            filepath = os.path.join(self.output_dir, filename)
            
            # Escrever arquivo
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)
            
            
            self.files_generated += 1
            self.total_programs += 1
            
            self.logger.info(f"Documentação gerada: {filename}")
            return filepath
            
        except Exception as e:
            self.logger.error(f"Erro ao gerar documentação para {program.name}: {e}")
            raise
    
    def _save_ai_response_json(self, program: CobolProgram, response: AIResponse) -> None:
        """Salva a resposta da IA em formato JSON para auditoria."""
        try:
            # Preparar dados da resposta
            response_data = {
                "program_name": program.name,
                "timestamp": datetime.now().isoformat(),
                "provider": response.provider,
                "model": response.model,
                "success": response.success,
                "tokens_used": response.tokens_used,
                "response_time": getattr(response, 'response_time', 0),
                "content": response.content,
                "error_message": response.error_message,
                "metadata": response.metadata,
                "pre_analysis": getattr(response, 'pre_analysis', {}),
                "prompts_used": getattr(response, 'prompts_used', {}),
                "quality_score": getattr(response, 'quality_score', 0),
                "analysis_depth": getattr(response, 'analysis_depth', 'standard')
            }
            
            # Salvar JSON
            json_filename = f"{program.name}_ai_response.json"
            json_filepath = os.path.join(self.json_dir, json_filename)
            
            with open(json_filepath, 'w', encoding='utf-8') as f:
                json.dump(response_data, f, indent=2, ensure_ascii=False, default=str)
            
            self.logger.info(f"JSON da resposta salvo: {json_filename}")
            
        except Exception as e:
            self.logger.error(f"Erro ao salvar JSON da resposta para {program.name}: {e}")
    
    def _save_ai_request_json(self, program: CobolProgram, response: AIResponse) -> None:
        """Salva o request enviado ao provedor em formato JSON para auditoria."""
        try:
            # Extrair dados do request dos metadados da resposta
            request_data = {
                "program_name": program.name,
                "timestamp": datetime.now().isoformat(),
                "provider": response.provider,
                "model": response.model,
                "request_payload": getattr(response, 'request_payload', {}),
                "prompts_sent": getattr(response, 'prompts_used', {}),
                "headers": getattr(response, 'request_headers', {}),
                "endpoint": getattr(response, 'endpoint_used', ''),
                "method": getattr(response, 'http_method', 'POST'),
                "request_size": len(str(getattr(response, 'request_payload', {}))),
                "configuration": {
                    "temperature": getattr(response, 'temperature', 0.1),
                    "max_tokens": getattr(response, 'max_tokens', 4000),
                    "timeout": getattr(response, 'timeout', 120)
                }
            }
            
            # Salvar JSON do request
            json_filename = f"{program.name}_ai_request.json"
            json_filepath = os.path.join(self.request_dir, json_filename)
            
            with open(json_filepath, 'w', encoding='utf-8') as f:
                json.dump(request_data, f, indent=2, ensure_ascii=False, default=str)
            
            self.logger.info(f"JSON do request salvo: {json_filename}")
            
        except Exception as e:
            self.logger.error(f"Erro ao salvar JSON do request para {program.name}: {e}")
    
    def _generate_program_content(self, program: CobolProgram, 
                                ai_response: AIResponse,
                                phase_info: Optional[Dict[str, Any]] = None) -> str:
        """
        Gera o conteúdo da documentação para um programa.
        
        Args:
            program: Programa COBOL
            ai_response: Resposta da análise de IA
            phase_info: Informações de faseamento
            
        Returns:
            Conteúdo da documentação em Markdown
        """
        content = f"""# Análise do Programa COBOL: {program.name}

**Data da Análise:** {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}  
**Modelo de IA:** {ai_response.model}  
**Provedor:** {ai_response.provider}  
**Tokens Utilizados:** {ai_response.tokens_used}  

---

## Análise Funcional e Técnica

{ai_response.content}

---

## Transparência e Auditoria

### Informações da Análise

**Status da Análise:** {self._get_status_text(ai_response.success)}  
**Tempo de Processamento:** {getattr(ai_response, 'response_time', 0):.2f} segundos  
**Qualidade da Análise:** {self._get_quality_text(getattr(ai_response, 'quality_score', 0))}  
**Profundidade:** {getattr(ai_response, 'analysis_depth', 'Padrão').title()}  

### Prompts Utilizados na Análise

#### Prompt Principal
```
{self._get_main_prompt(ai_response)}
```

#### Contexto do Sistema
```
{self._get_system_context(ai_response)}
```

#### Informações do Programa
- **Nome:** {program.name}
- **Tamanho:** {len(program.content)} caracteres
- **Linhas:** {len(program.content.split(chr(10)))} linhas

### Metadados da Análise

**Provedor Utilizado:** {ai_response.provider}  
**Modelo:** {ai_response.model}  
**Total de Tokens:** {ai_response.tokens_used}  
**Timestamp:** {datetime.now().isoformat()}  
**Sucesso:** {'Sim' if ai_response.success else 'Não'}  

{self._generate_error_section(ai_response)}

### Metodologia Aplicada

Este programa foi analisado utilizando um processo estruturado em duas etapas:

1. **Análise Geral:** A IA assume o papel de um programador COBOL experiente e realiza uma análise arquitetural completa
2. **Questões Específicas:** Responde a questões detalhadas sobre funcionalidade, estrutura, regras de negócio e qualidade

### Limitações e Considerações

- Esta análise é baseada em processamento automatizado de linguagem natural
- Recomenda-se validação por especialista COBOL para sistemas críticos
- A qualidade da análise depende da clareza e completude do código fonte
- Comentários e documentação no código melhoram significativamente a precisão

---

**Relatório gerado automaticamente pelo COBOL AI Engine v1.0.8**
"""
        return content
    
    def _get_status_text(self, success: bool) -> str:
        """Retorna texto do status da análise."""
        return "[SUCESSO]" if success else "[FALHA]"
    
    def _get_quality_text(self, quality_score: float) -> str:
        """Retorna texto da qualidade baseado no score."""
        if quality_score >= 0.8:
            return "Excelente"
        elif quality_score >= 0.6:
            return "Boa"
        elif quality_score >= 0.4:
            return "Média"
        else:
            return "Baixa"
    
    def _get_main_prompt(self, ai_response: AIResponse) -> str:
        """Extrai o prompt principal dos metadados."""
        prompts = getattr(ai_response, 'prompts_used', {})
        return prompts.get('main_prompt', 'Prompt não disponível')
    
    def _get_system_context(self, ai_response: AIResponse) -> str:
        """Extrai o contexto do sistema dos metadados."""
        prompts = getattr(ai_response, 'prompts_used', {})
        return prompts.get('system_context', 'Contexto não disponível')
    
    def _generate_error_section(self, ai_response: AIResponse) -> str:
        """Gera seção de erro se houver."""
        if not ai_response.success and ai_response.error_message:
            return f"""
### Erro na Análise

**Mensagem de Erro:** {ai_response.error_message}  
**Código de Erro:** {getattr(ai_response, 'error_code', 'N/A')}  

"""
        return ""
    
    def get_generation_stats(self) -> Dict[str, Any]:
        """Retorna estatísticas de geração."""
        return {
            "files_generated": self.files_generated,
            "total_programs": self.total_programs,
            "output_directory": self.output_dir,
            "json_responses_dir": self.json_dir,
            "json_requests_dir": self.request_dir
        }
    def _save_ai_request_json(self, response, output_dir):
        """Salva o request enviado ao provedor em formato JSON para auditoria."""
        try:
            # Criar diretório para requests se não existir
            request_dir = os.path.join(output_dir, "ai_requests")
            os.makedirs(request_dir, exist_ok=True)
            
            # Extrair dados do request dos metadados da resposta
            request_data = {
                "program_name": getattr(response, 'program_name', 'unknown'),
                "timestamp": datetime.now().isoformat(),
                "provider": response.provider,
                "model": response.model,
                "request_payload": getattr(response, 'request_payload', {}),
                "prompts_sent": getattr(response, 'prompts_used', {}),
                "headers": getattr(response, 'request_headers', {}),
                "endpoint": getattr(response, 'endpoint_used', ''),
                "method": getattr(response, 'http_method', 'POST'),
                "request_size": len(str(getattr(response, 'request_payload', {}))),
                "configuration": {
                    "temperature": getattr(response, 'temperature', 0.1),
                    "max_tokens": getattr(response, 'max_tokens', 4000),
                    "timeout": getattr(response, 'timeout', 120)
                }
            }
            
            # Salvar JSON do request
            program_name = getattr(response, 'program_name', 'unknown')
            json_filename = f"{program_name}_ai_request.json"
            json_filepath = os.path.join(request_dir, json_filename)
            
            with open(json_filepath, 'w', encoding='utf-8') as f:
                json.dump(request_data, f, indent=2, ensure_ascii=False, default=str)
            
            self.logger.info(f"JSON do request salvo: {json_filename}")
            
        except Exception as e:
            self.logger.error(f"Erro ao salvar JSON do request: {e}")
