#!/usr/bin/env python3
"""
COBOL AI Engine v1.4.0 - Sistema de Análise de Programas COBOL

Sistema completo de análise de programas COBOL com IA, usando arquitetura modular.
Inclui todas as correções implementadas e mantém a interface original.

CORREÇÕES v1.4.0:
✅ Renovação automática de token (HTTP 401)
✅ Tratamento de HTTP 201 e 202
✅ Sistema de auditoria completo
✅ Interface original mantida

USO:
python main.py --fontes examples/fontes.txt --books examples/BOOKS.txt --output minha_analise --pdf
python main.py --status
"""

import argparse
import json
import logging
import os
import sys
import time
from datetime import datetime
from typing import List, Dict, Any, Optional

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

# Importações dos módulos
from src.core.config import ConfigManager
from src.core.token_manager import TokenManager
from src.providers.luzia_provider_enhanced import LuziaProviderEnhanced
from src.parsers.cobol_parser import COBOLParser
from src.generators.documentation_generator_enhanced import EnhancedDocumentationGenerator
from src.utils.audit_logger import AuditLogger
from src.utils.html_generator import HTMLReportGenerator

class COBOLProgram:
    """Representa um programa COBOL."""
    def __init__(self, name: str, content: str):
        self.name = name
        self.content = content

def setup_logging(log_level: str = "INFO") -> None:
    """Configura o sistema de logging."""
    log_dir = "logs"
    os.makedirs(log_dir, exist_ok=True)
    
    log_file = os.path.join(log_dir, f"cobol_ai_engine_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
    
    logging.basicConfig(
        level=getattr(logging, log_level.upper()),
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file, encoding='utf-8'),
            logging.StreamHandler(sys.stdout)
        ]
    )

def load_cobol_programs(fontes_file: str) -> List[COBOLProgram]:
    """Carrega programas COBOL do arquivo de fontes."""
    logger = logging.getLogger(__name__)
    
    if not os.path.exists(fontes_file):
        raise FileNotFoundError(f"Arquivo de fontes não encontrado: {fontes_file}")
    
    logger.info(f"Carregando programas COBOL de: {fontes_file}")
    
    parser = COBOLParser()
    programs, _ = parser.parse_file(fontes_file)
    
    logger.info(f"Total de programas encontrados: {len(programs)}")
    
    return programs

def load_copybooks(books_file: Optional[str]) -> List[str]:
    """Carrega copybooks se fornecido."""
    logger = logging.getLogger(__name__)
    
    if not books_file:
        logger.info("Nenhum arquivo de copybooks fornecido")
        return []
    
    if not os.path.exists(books_file):
        logger.warning(f"Arquivo de copybooks não encontrado: {books_file}")
        return []
    
    logger.info(f"Carregando copybooks de: {books_file}")
    
    try:
        parser = COBOLParser()
        _, books = parser.parse_file(books_file)
        
        # Converter para lista de strings
        books_content = []
        for book in books:
            if hasattr(book, 'content'):
                books_content.append(book.content)
            else:
                books_content.append(str(book))
        
        logger.info(f"Total de copybooks encontrados: {len(books_content)}")
        return books_content
        
    except Exception as e:
        logger.error(f"Erro ao carregar copybooks: {e}")
        return []

def check_credentials() -> tuple:
    """Verifica e obtém credenciais LuzIA."""
    client_id = os.getenv('LUZIA_CLIENT_ID')
    client_secret = os.getenv('LUZIA_CLIENT_SECRET')
    
    if not client_id or not client_secret:
        print("❌ Credenciais LuzIA não configuradas!")
        print("\nConfigure as variáveis de ambiente:")
        print("export LUZIA_CLIENT_ID=\"seu_client_id\"")
        print("export LUZIA_CLIENT_SECRET=\"seu_client_secret\"")
        print("\nOu use um arquivo .env")
        return None, None
    
    return client_id, client_secret

def check_providers_status() -> None:
    """Verifica status dos provedores."""
    print("=== VERIFICAÇÃO DE STATUS DOS PROVEDORES ===\n")
    
    client_id, client_secret = check_credentials()
    
    if not client_id or not client_secret:
        return
    
    try:
        # Inicializar configuração
        config_manager = ConfigManager()
        
        # Criar provedor LuzIA
        provider = LuziaProviderEnhanced(config_manager.config)
        
        print("Testando conectividade LuzIA...")
        if provider.test_connectivity():
            print("  ✅ LuzIA: Conectividade OK")
        else:
            print("  ❌ LuzIA: Falha na conectividade")
        
        print("\n=== VERIFICAÇÃO CONCLUÍDA ===")
        
    except Exception as e:
        print(f"❌ Erro na verificação: {e}")

def save_analysis_result(program: COBOLProgram, analysis: str, output_dir: str, 
                        generate_html: bool = False, tokens_used: int = 0) -> None:
    """Salva resultado da análise."""
    
    # Criar diretórios necessários
    reports_dir = os.path.join(output_dir, 'reports')
    requests_dir = os.path.join(output_dir, 'requests')
    responses_dir = os.path.join(output_dir, 'responses')
    metadata_dir = os.path.join(output_dir, 'metadata')
    
    for dir_path in [reports_dir, requests_dir, responses_dir, metadata_dir]:
        os.makedirs(dir_path, exist_ok=True)
    
    # Salvar relatório principal em Markdown
    report_file = os.path.join(reports_dir, f"{program.name}.md")
    with open(report_file, 'w', encoding='utf-8') as f:
        f.write(analysis)
    
    # Gerar HTML se solicitado (para conversão PDF)
    if generate_html:
        try:
            html_generator = HTMLReportGenerator()
            html_file = os.path.join(reports_dir, f"{program.name}.html")
            html_content = html_generator.generate_html_report(analysis, program.name)
            with open(html_file, 'w', encoding='utf-8') as f:
                f.write(html_content)
        except Exception as e:
            logging.warning(f"Erro ao gerar HTML para {program.name}: {e}")
    
    # Salvar metadados
    metadata = {
        'program_name': program.name,
        'analysis_date': datetime.now().isoformat(),
        'content_hash': hash(program.content),
        'success': True,
        'html_generated': generate_html,
        'tokens_used': tokens_used
    }
    
    metadata_file = os.path.join(metadata_dir, f"{program.name}_metadata.json")
    with open(metadata_file, 'w', encoding='utf-8') as f:
        json.dump(metadata, f, indent=2, ensure_ascii=False)

def process_cobol_files(args: argparse.Namespace) -> None:
    """Processa os arquivos COBOL."""
    logger = logging.getLogger(__name__)
    start_time = time.time()
    
    # Verificar credenciais
    client_id, client_secret = check_credentials()
    if not client_id or not client_secret:
        sys.exit(1)
    
    try:
        # Inicializar componentes
        config_manager = ConfigManager()
        provider = LuziaProviderEnhanced(config_manager.config)
        audit_logger = AuditLogger(args.output)
        
        # Carregar programas e copybooks
        programs = load_cobol_programs(args.fontes)
        books = load_copybooks(args.books)
        
        if not programs:
            print("❌ Nenhum programa COBOL encontrado")
            sys.exit(1)
        
        # Iniciar sessão de auditoria
        session_id = audit_logger.start_session(len(programs))
        
        print(f"🚀 Iniciando análise de {len(programs)} programas...")
        print("=" * 60)
        
        all_results = []
        
        for i, program in enumerate(programs, 1):
            print(f"\n[ {i:2d}/{len(programs)} ] Analisando {program.name}...")
            
            start_analysis = time.time()
            
            # Registrar requisição na auditoria
            request_id = audit_logger.log_request(
                program_name=program.name,
                provider="luzia_enhanced",
                program_content=program.content,
                books_content=books
            )
            
            try:
                # Criar prompt para análise
                prompt = create_analysis_prompt(program.content, books)
                
                # Realizar análise usando o provedor aprimorado
                from src.providers.base_provider import AIRequest
                request = AIRequest(
                    prompt=prompt,
                    program_name=program.name,
                    program_code=program.content,
                    context={
                        "books": books,
                        "model_selected": "aws-claude-3-5-sonnet"
                    }
                )
                
                response = provider.analyze(request)
                
                processing_time = time.time() - start_analysis
                
                if response.success:
                    # Registrar resposta na auditoria
                    audit_logger.log_response(
                        request_id=request_id,
                        status_code=200,
                        response_content=response.content,
                        processing_time_ms=int(processing_time * 1000),
                        tokens_used=response.tokens_used,
                        success=True
                    )
                    
                    # Salvar resultado
                    save_analysis_result(program, response.content, args.output, 
                                       args.pdf, response.tokens_used)
                    
                    print(f"        ✅ Sucesso ({processing_time:.0f}ms, {response.tokens_used} tokens)")
                    
                    all_results.append({
                        'program': program.name,
                        'success': True,
                        'processing_time': processing_time,
                        'tokens_used': response.tokens_used
                    })
                    
                else:
                    # Registrar falha na auditoria
                    audit_logger.log_response(
                        request_id=request_id,
                        status_code=500,
                        response_content="",
                        processing_time_ms=int(processing_time * 1000),
                        tokens_used=0,
                        success=False,
                        error_message=response.error_message
                    )
                    
                    print(f"        ❌ Erro: {response.error_message}")
                    
                    all_results.append({
                        'program': program.name,
                        'success': False,
                        'processing_time': processing_time,
                        'tokens_used': 0,
                        'error': response.error_message
                    })
                
            except Exception as e:
                processing_time = time.time() - start_analysis
                error_msg = str(e)
                
                # Registrar exceção na auditoria
                audit_logger.log_response(
                    request_id=request_id,
                    status_code=500,
                    response_content="",
                    processing_time_ms=int(processing_time * 1000),
                    tokens_used=0,
                    success=False,
                    error_message=error_msg
                )
                
                print(f"        ❌ Exceção: {error_msg}")
                
                all_results.append({
                    'program': program.name,
                    'success': False,
                    'processing_time': processing_time,
                    'tokens_used': 0,
                    'error': error_msg
                })
            
            # Mostrar progresso
            successes = sum(1 for r in all_results if r['success'])
            progress = (i / len(programs)) * 100
            print(f"        📊 Progresso: {progress:.1f}% ({successes} sucessos, {i - successes} erros)")
        
        # Finalizar sessão de auditoria
        audit_logger.end_session(session_id)
        
        # Estatísticas finais
        processing_time = time.time() - start_time
        successful_analyses = sum(1 for r in all_results if r['success'])
        total_tokens = sum(r.get('tokens_used', 0) for r in all_results if r['success'])
        
        print("\n" + "=" * 60)
        print("📋 RELATÓRIO FINAL")
        print("=" * 60)
        print(f"Programas processados: {len(programs)}")
        print(f"Análises bem-sucedidas: {successful_analyses}/{len(all_results)}")
        print(f"Taxa de sucesso geral: {(successful_analyses/len(all_results)*100):.1f}%")
        print(f"Total de tokens utilizados: {total_tokens}")
        print(f"Tempo total de processamento: {processing_time:.2f}s")
        print(f"Documentação gerada em: {args.output}")
        
        # Mostrar informações de auditoria
        audit_report_path = os.path.join(args.output, 'audit', f'audit_report_session_{session_id}.md')
        if os.path.exists(audit_report_path):
            print(f"Relatório de auditoria: {audit_report_path}")
        
        # Gerar HTML adicional se solicitado
        if args.pdf:
            try:
                html_generator = HTMLReportGenerator()
                html_files = html_generator.generate_html_reports(args.output)
                if html_files:
                    print(f"\n=== RELATÓRIOS HTML GERADOS ===")
                    for html_file in html_files:
                        print(f"HTML: {html_file}")
                    print("\nPara converter para PDF:")
                    print("1. Abra o arquivo HTML no navegador")
                    print("2. Pressione Ctrl+P (Windows/Linux) ou Cmd+P (Mac)")
                    print("3. Selecione 'Salvar como PDF'")
            except Exception as e:
                logger.warning(f"Erro ao gerar relatórios HTML: {e}")
        
    except Exception as e:
        logger.error(f"Erro crítico no processamento: {e}")
        print(f"\n❌ Erro crítico: {e}")
        sys.exit(1)

def create_analysis_prompt(program_content: str, books_content: List[str] = None) -> str:
    """Cria prompt para análise do programa COBOL."""
    
    prompt = f"""Analise o seguinte programa COBOL e forneça uma documentação completa e detalhada:

PROGRAMA COBOL:
```cobol
{program_content}
```
"""
    
    if books_content:
        prompt += f"""
COPYBOOKS RELACIONADOS:
```cobol
{chr(10).join(books_content)}
```
"""
    
    prompt += """
Forneça uma análise completa incluindo:

1. **Identificação do Programa**
   - Nome do programa
   - Propósito e funcionalidade principal
   - Autor e data (se disponível)

2. **Estrutura e Organização**
   - Divisões utilizadas
   - Seções principais
   - Organização do código

3. **Análise de Dados**
   - Variáveis de working-storage
   - Estruturas de dados
   - Copybooks utilizados
   - Arquivos e registros

4. **Lógica de Processamento**
   - Fluxo principal do programa
   - Parágrafos e seções de processamento
   - Condições e loops
   - Cálculos e transformações

5. **Análise de Arquivos**
   - Arquivos de entrada e saída
   - Estrutura dos registros
   - Modos de acesso

6. **Dependências e Integrações**
   - Copybooks incluídos
   - Programas chamados
   - Recursos externos

7. **Qualidade e Manutenibilidade**
   - Boas práticas utilizadas
   - Pontos de atenção
   - Sugestões de melhoria

8. **Resumo Executivo**
   - Funcionalidade principal
   - Complexidade
   - Importância no sistema

Formate a resposta em Markdown com seções bem organizadas e exemplos quando relevante.
"""
    
    return prompt

def main():
    """Função principal para executar o script."""
    parser = argparse.ArgumentParser(
        description='COBOL AI Engine v1.4.0 - Sistema de Análise de Programas COBOL',
        epilog="""
Exemplos de uso:
  python main.py --fontes examples/fontes.txt --output minha_analise
  python main.py --fontes examples/fontes.txt --books examples/BOOKS.txt --output analise_completa --pdf
  python main.py --status
        """,
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    parser.add_argument('--fontes', 
                       help='Caminho para o arquivo de fontes COBOL (ex: fontes.txt)')
    parser.add_argument('--books', 
                       help='Caminho para o arquivo de copybooks (opcional)')
    parser.add_argument('--output', default='output', 
                       help='Diretório de saída para a documentação (padrão: output)')
    parser.add_argument('--pdf', action='store_true', 
                       help='Gera relatórios HTML otimizados para conversão PDF via navegador')
    parser.add_argument('--log', default='INFO', 
                       help='Nível de log (DEBUG, INFO, WARNING, ERROR)')
    parser.add_argument('--status', action='store_true', 
                       help='Verifica status e conectividade dos provedores de IA configurados')

    args = parser.parse_args()

    # Mostrar banner
    print("=" * 60)
    print("COBOL AI Engine v1.4.0 - Sistema de Análise de Programas COBOL")
    print("Arquitetura modular com todas as correções implementadas")
    print("=" * 60)

    setup_logging(args.log)
    
    try:
        # Verificar se é comando de status
        if args.status:
            check_providers_status()
            return
        
        # Validar argumentos obrigatórios para análise
        if not args.fontes:
            print("\n❌ Erro: --fontes é obrigatório para análise de programas")
            print("💡 Use --status para verificar conectividade dos provedores")
            print("\nExemplos:")
            print("  python main.py --fontes examples/fontes.txt --output minha_analise")
            print("  python main.py --status")
            sys.exit(1)
        
        process_cobol_files(args)
        
    except Exception as e:
        logging.error(f"Uma falha crítica ocorreu: {e}")
        print(f"\n❌ Erro crítico: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
