#!/usr/bin/env python3
"""
Script simplificado para remover ícones dos arquivos
"""

import os
import re
import glob

def clean_file(filepath):
    """Remove ícones de um arquivo"""
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Remover emojis comuns
        content = re.sub(r'[]', '', content)
        
        # Salvar arquivo limpo
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        
        print(f"Limpo: {filepath}")
        
    except Exception as e:
        print(f"Erro ao limpar {filepath}: {e}")

def main():
    """Função principal"""
    # Arquivos a serem limpos
    patterns = [
        "*.md",
        "*.py",
        "*.yaml",
        "*.yml",
        "*.txt",
        "src/**/*.py",
        "config/**/*.yaml",
        "docs/**/*.md"
    ]
    
    for pattern in patterns:
        for filepath in glob.glob(pattern, recursive=True):
            if os.path.isfile(filepath):
                clean_file(filepath)

if __name__ == "__main__":
    main()
