#!/usr/bin/env python3

from setuptools import setup, find_packages
from setuptools.command.install import install
import os
import shutil
from pathlib import Path

class CustomInstallCommand(install):
    """Comando de instalação customizado que copia todos os arquivos necessários"""
    
    def run(self):
        # Executar instalação padrão
        install.run(self)
        
        # Copiar arquivos necessários para o site-packages
        try:
            # Encontrar o diretório de instalação
            install_dir = Path(self.install_lib)
            
            # Copiar diretório src
            src_source = Path("src")
            src_dest = install_dir / "src"
            if src_source.exists():
                if src_dest.exists():
                    shutil.rmtree(src_dest)
                shutil.copytree(src_source, src_dest)
                print(f"✅ Copiado diretório src para {src_dest}")
            
            # Copiar diretórios de configuração e dados
            for dir_name in ["config", "examples", "data", "prompts"]:
                source_dir = Path(dir_name)
                dest_dir = install_dir / dir_name
                if source_dir.exists():
                    if dest_dir.exists():
                        shutil.rmtree(dest_dir)
                    shutil.copytree(source_dir, dest_dir)
                    print(f"✅ Copiado diretório {dir_name} para {dest_dir}")
            
        except Exception as e:
            print(f"⚠️  Aviso: Erro ao copiar arquivos: {e}")

# Ler o README
try:
    with open("README.md", "r", encoding="utf-8") as fh:
        long_description = fh.read()
except:
    long_description = "COBOL Analyzer - Ferramenta de análise de código COBOL com IA"

setup(
    name="cobol-to-docs",
    version="3.1.0",
    author="COBOL Analyzer Team",
    description="Ferramenta de análise de código COBOL com tecnologia de IA",
    long_description=long_description,
    long_description_content_type="text/markdown",
    
    # Usar comando de instalação customizado
    cmdclass={
        'install': CustomInstallCommand,
    },
    
    # Incluir apenas os scripts principais
    py_modules=[
        "main", 
        "main_enhanced",
        "cli", 
        "cli_enhanced",
        "cobol_to_docs",
        "cobol_to_docs_enhanced",
        "install_global"
    ],
    
    # Incluir todos os arquivos Python como scripts executáveis
    scripts=[
        "main.py", 
        "main_enhanced.py",
        "cli.py", 
        "cli_enhanced.py",
        "cobol_to_docs.py",
        "cobol_to_docs_enhanced.py",
        "install_global.py"
    ],
    
    # Entry points para comandos globais
    entry_points={
        "console_scripts": [
            "cobol-analyzer=cobol_to_docs_enhanced:main",
            "cobol-to-docs=cobol_to_docs_enhanced:main",
        ],
    },
    
    # Incluir todos os arquivos necessários
    package_data={
        "": ["*"],
    },
    
    include_package_data=True,
    
    # Dependências essenciais
    install_requires=[
        "pyyaml>=6.0",
        "requests>=2.28.0",
        "numpy>=1.21.0",
        "scikit-learn>=1.0.0",
        "jinja2>=3.0.0",
        "markdown>=3.3.0",
    ],
    
    # Metadados básicos
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.8",
    zip_safe=False,
)
