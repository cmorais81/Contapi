#!/usr/bin/env python3
"""
COBOL to Docs - Entry Point Principal
Wrapper que funciona tanto localmente quanto após instalação via pip
"""

import sys
import os
import subprocess
from pathlib import Path
import importlib.util

def setup_python_path():
    """Configura o PYTHONPATH para incluir os módulos necessários"""
    
    # Diretório do script atual
    script_dir = Path(__file__).parent.absolute()
    
    # Adicionar diretórios ao sys.path
    paths_to_add = [
        str(script_dir),
        str(script_dir / "src") if (script_dir / "src").exists() else None,
    ]
    
    # Procurar por instalação via pip
    try:
        import site
        for site_dir in site.getsitepackages() + [site.getusersitepackages()]:
            if site_dir:
                site_path = Path(site_dir)
                # Procurar por arquivos do cobol analyzer
                if (site_path / "main.py").exists():
                    paths_to_add.append(str(site_path))
                if (site_path / "src").exists():
                    paths_to_add.append(str(site_path / "src"))
    except:
        pass
    
    # Adicionar ao sys.path
    for path in paths_to_add:
        if path and path not in sys.path:
            sys.path.insert(0, path)

def find_and_run_main():
    """Encontra e executa o main.py"""
    
    # Configurar PYTHONPATH
    setup_python_path()
    
    # Método 1: Tentar importar main diretamente
    try:
        import main
        if hasattr(main, 'main'):
            return main.main()
        else:
            # Se não tem função main, executar como script
            exec(open("main.py").read())
            return 0
    except ImportError:
        pass
    except Exception as e:
        print(f"Erro ao importar main: {e}")
    
    # Método 2: Executar main.py como subprocess no diretório correto
    script_dir = Path(__file__).parent
    main_py = script_dir / "main.py"
    
    if main_py.exists():
        try:
            # Mudar para o diretório do script
            original_cwd = os.getcwd()
            os.chdir(str(script_dir))
            
            try:
                cmd = [sys.executable, "main.py"] + sys.argv[1:]
                return subprocess.call(cmd)
            finally:
                os.chdir(original_cwd)
        except Exception as e:
            print(f"Erro ao executar main.py: {e}")
    
    # Método 3: Procurar main.py em locais de instalação
    try:
        import site
        for site_dir in site.getsitepackages() + [site.getusersitepackages()]:
            if site_dir:
                site_path = Path(site_dir)
                main_py = site_path / "main.py"
                if main_py.exists():
                    try:
                        original_cwd = os.getcwd()
                        os.chdir(str(site_path))
                        
                        try:
                            cmd = [sys.executable, "main.py"] + sys.argv[1:]
                            return subprocess.call(cmd)
                        finally:
                            os.chdir(original_cwd)
                    except Exception as e:
                        continue
    except:
        pass
    
    # Método 4: Procurar no diretório atual
    current_dir = Path.cwd()
    main_py = current_dir / "main.py"
    if main_py.exists():
        try:
            cmd = [sys.executable, "main.py"] + sys.argv[1:]
            return subprocess.call(cmd)
        except Exception as e:
            print(f"Erro ao executar main.py no diretório atual: {e}")
    
    return None

def main():
    """Função principal do wrapper"""
    
    try:
        result = find_and_run_main()
        
        if result is not None:
            return result
        
        # Se chegou aqui, não conseguiu executar
        print("❌ Erro: Não foi possível encontrar ou executar o COBOL Analyzer")
        print("\n🔧 Soluções:")
        print("1. Execute no diretório da aplicação:")
        print("   cd cobol_analyzer_EXCELENCIA")
        print("   python3 main.py --help")
        print("\n2. Use a instalação global:")
        print("   python3 install_global.py")
        print("   cobol-docs --help")
        print("\n3. Reinstale o pacote:")
        print("   pip uninstall cobol-analyzer -y")
        print("   pip install .")
        print("\n4. Verifique se as dependências estão instaladas:")
        print("   pip install pyyaml numpy scikit-learn")
        
        return 1
        
    except KeyboardInterrupt:
        print("\n⚠️  Operação cancelada pelo usuário")
        return 130
    except Exception as e:
        print(f"❌ Erro inesperado: {e}")
        print("\n🔧 Tente executar diretamente:")
        print("  python3 main.py --help")
        return 1

if __name__ == '__main__':
    sys.exit(main())
