"""
Mixins for common model functionality.
"""

from datetime import datetime
from typing import Optional

from sqlalchemy import Boolean, Column, DateTime, String, Text
from sqlalchemy.sql import func


class TimestampMixin:
    """Mixin for timestamp fields."""

    data_criacao = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
        doc="Creation timestamp"
    )

    data_atualizacao = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
        doc="Last update timestamp"
    )


class StatusMixin:
    """Mixin for status tracking."""

    is_active = Column(
        Boolean,
        default=True,
        nullable=False,
        doc="Whether the record is active"
    )


class DescriptionMixin:
    """Mixin for description fields."""

    description = Column(
        Text,
        doc="Description of the entity"
    )


class NameMixin:
    """Mixin for name fields."""

    name = Column(
        String(255),
        nullable=False,
        doc="Name of the entity"
    )


class UnityMixin:
    """Mixin for Unity Catalog integration fields."""

    unity_catalog_name = Column(
        String(255),
        doc="Unity Catalog name"
    )

    unity_catalog_schema = Column(
        String(255),
        doc="Unity Catalog schema"
    )

    unity_catalog_table = Column(
        String(255),
        doc="Unity Catalog table"
    )


class ExternalSystemMixin:
    """Mixin for external system integration."""

    external_system_id = Column(
        String(255),
        doc="ID in external system"
    )

    external_system_type = Column(
        String(100),
        doc="Type of external system"
    )

    external_url = Column(
        String(500),
        doc="URL in external system"
    )


class AuditMixin:
    """Mixin for audit fields."""

    created_by = Column(
        String(255),
        doc="User who created the record"
    )

    updated_by = Column(
        String(255),
        doc="User who last updated the record"
    )

    approved_by = Column(
        String(255),
        doc="User who approved the record"
    )

    approval_date = Column(
        DateTime(timezone=True),
        doc="Date of approval"
    )


class ValidationMixin:
    """Mixin for validation fields."""

    validation_status = Column(
        String(50),
        default="pending",
        doc="Validation status: pending, valid, invalid"
    )

    validated_by = Column(
        String(255),
        doc="User who validated the record"
    )

    validation_date = Column(
        DateTime(timezone=True),
        doc="Date of validation"
    )

    confidence_score = Column(
        String(10),  # Using String to handle numeric as text
        doc="Confidence score (0-1)"
    )


class MetricsMixin:
    """Mixin for metrics tracking."""

    metric_timestamp = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        doc="Timestamp of the metric"
    )

    execution_duration_ms = Column(
        String(20),  # Using String to handle integer as text
        doc="Execution duration in milliseconds"
    )


class QualityMixin:
    """Mixin for data quality fields."""

    quality_score = Column(
        String(10),  # Using String to handle numeric as text
        doc="Quality score (0-100)"
    )

    quality_threshold = Column(
        String(10),  # Using String to handle numeric as text
        doc="Quality threshold"
    )

    auto_remediation = Column(
        Boolean,
        default=False,
        doc="Auto remediation enabled"
    )

