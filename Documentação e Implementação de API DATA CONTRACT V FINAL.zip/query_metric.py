"""
Query Metric model.
"""

from sqlalchemy import Column, DateTime, ForeignKey, String, Text
from sqlalchemy.dialects.postgresql import UUID as PostgresUUID
from sqlalchemy.orm import relationship

from app.models.base import BaseModel
from app.models.mixins import MetricsMixin


class QueryMetric(BaseModel, MetricsMixin):
    """
    Query Metric model.
    
    SQL query performance metrics.
    """

    __tablename__ = "query_metrics"

    # Foreign key to contract
    contract_id = Column(
        PostgresUUID(as_uuid=True),
        ForeignKey("data_contracts.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
        doc="Reference to contract"
    )

    # Query identification
    query_id = Column(
        String(255),
        nullable=False,
        index=True,
        doc="Query ID"
    )

    query_hash = Column(
        String(255),
        index=True,
        doc="Query hash for deduplication"
    )

    query_text = Column(
        Text,
        doc="SQL query text"
    )

    # Execution details
    query_status = Column(
        String(50),
        nullable=False,
        index=True,
        doc="Query status: running, succeeded, failed, cancelled"
    )

    start_time = Column(
        DateTime(timezone=True),
        doc="Query start time"
    )

    end_time = Column(
        DateTime(timezone=True),
        doc="Query end time"
    )

    # Performance metrics
    rows_returned = Column(
        String(20),  # Using String to handle integer as text
        doc="Number of rows returned"
    )

    bytes_scanned = Column(
        String(20),  # Using String to handle integer as text
        doc="Bytes scanned"
    )

    bytes_returned = Column(
        String(20),  # Using String to handle integer as text
        doc="Bytes returned"
    )

    # Resource usage
    cpu_time_ms = Column(
        String(20),  # Using String to handle integer as text
        doc="CPU time in milliseconds"
    )

    peak_memory_bytes = Column(
        String(20),  # Using String to handle integer as text
        doc="Peak memory usage in bytes"
    )

    spill_to_disk_bytes = Column(
        String(20),  # Using String to handle integer as text
        doc="Spill to disk in bytes"
    )

    # User and session info
    user_name = Column(
        String(255),
        index=True,
        doc="User who executed the query"
    )

    session_id = Column(
        String(255),
        doc="Session ID"
    )

    warehouse_id = Column(
        String(255),
        doc="Warehouse/cluster ID"
    )

    # Relationships
    contract = relationship(
        "DataContract",
        back_populates="query_metrics"
    )

    def __repr__(self) -> str:
        return f"<QueryMetric(query_id={self.query_id}, status={self.query_status})>"

