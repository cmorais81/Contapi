"""
Contract Layout model.
"""

from sqlalchemy import Boolean, Column, ForeignKey, String, Text
from sqlalchemy.dialects.postgresql import UUID as PostgresUUID
from sqlalchemy.orm import relationship

from app.models.base import BaseModel


class ContractLayout(BaseModel):
    """
    Contract Layout model.
    
    Customizable layouts by country/region for contracts.
    """

    __tablename__ = "contract_layouts"

    # Foreign key to contract
    contract_id = Column(
        PostgresUUID(as_uuid=True),
        ForeignKey("data_contracts.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
        doc="Reference to contract"
    )

    # Layout identification
    layout_name = Column(
        String(255),
        nullable=False,
        doc="Layout name"
    )

    layout_description = Column(
        Text,
        doc="Layout description"
    )

    # Geographic configuration
    country_code = Column(
        String(2),
        doc="Country code (ISO 3166-1 alpha-2)"
    )

    region_code = Column(
        String(10),
        doc="Region code"
    )

    # Layout configuration
    layout_type = Column(
        String(50),
        nullable=False,
        doc="Type: yaml, json, pdf, html, markdown"
    )

    template_content = Column(
        Text,
        doc="Template content"
    )

    is_default = Column(
        Boolean,
        default=False,
        doc="Default layout for country/region"
    )

    # Status
    layout_status = Column(
        String(50),
        default="active",
        index=True,
        doc="Status: active, inactive, deprecated"
    )

    # Relationships
    contract = relationship(
        "DataContract",
        back_populates="layouts"
    )

    def __repr__(self) -> str:
        return f"<ContractLayout(name={self.layout_name}, type={self.layout_type})>"

