"""
Data Quality Aggregate model.
"""

from sqlalchemy import Column, ForeignKey, String
from sqlalchemy.dialects.postgresql import UUID as PostgresUUID
from sqlalchemy.orm import relationship

from app.models.base import BaseModel
from app.models.mixins import MetricsMixin, QualityMixin


class DataQualityAggregate(BaseModel, MetricsMixin, QualityMixin):
    """
    Data Quality Aggregate model.
    
    Aggregated quality metrics for contracts.
    """

    __tablename__ = "data_quality_aggregates"

    # Foreign key to contract
    contract_id = Column(
        PostgresUUID(as_uuid=True),
        ForeignKey("data_contracts.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
        doc="Reference to contract"
    )

    # Aggregation details
    aggregation_period = Column(
        String(50),
        nullable=False,
        doc="Aggregation period: hourly, daily, weekly, monthly"
    )

    aggregation_date = Column(
        String(20),  # Using String to handle date as text
        nullable=False,
        index=True,
        doc="Date of aggregation (YYYY-MM-DD)"
    )

    # Quality metrics
    total_rules_executed = Column(
        String(10),  # Using String to handle integer as text
        doc="Total quality rules executed"
    )

    rules_passed = Column(
        String(10),  # Using String to handle integer as text
        doc="Number of rules that passed"
    )

    rules_failed = Column(
        String(10),  # Using String to handle integer as text
        doc="Number of rules that failed"
    )

    total_records_validated = Column(
        String(20),  # Using String to handle integer as text
        doc="Total records validated"
    )

    records_passed = Column(
        String(20),  # Using String to handle integer as text
        doc="Records that passed validation"
    )

    records_failed = Column(
        String(20),  # Using String to handle integer as text
        doc="Records that failed validation"
    )

    # Relationships
    contract = relationship(
        "DataContract",
        back_populates="quality_aggregates"
    )

    def __repr__(self) -> str:
        return f"<DataQualityAggregate(period={self.aggregation_period}, date={self.aggregation_date})>"

