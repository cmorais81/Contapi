# Estrutura Detalhada do Projeto - Data Governance API

**Seguindo Padrões OpenAPI 3.0+ e Melhores Práticas**

## Estrutura Completa do Projeto

```
data-governance-api/
├── README.md                           # Documentação principal
├── pyproject.toml                      # Configuração do projeto (PEP 518)
├── requirements.txt                    # Dependências (compatibilidade)
├── requirements-dev.txt                # Dependências de desenvolvimento
├── .env.example                        # Exemplo de variáveis de ambiente
├── .gitignore                          # Arquivos ignorados pelo Git
├── Makefile                            # Comandos automatizados
├── docker-compose.yml                  # Orquestração local
├── Dockerfile                          # Container da aplicação
├── alembic.ini                         # Configuração do Alembic
├── pytest.ini                          # Configuração do pytest
├── .pre-commit-config.yaml            # Hooks de pre-commit
├── openapi.json                        # Especificação OpenAPI gerada
│
├── app/                                # Código principal da aplicação
│   ├── __init__.py
│   ├── main.py                         # Ponto de entrada FastAPI
│   ├── version.py                      # Versionamento da API
│   │
│   ├── api/                            # Camada de API (Controllers)
│   │   ├── __init__.py
│   │   ├── deps.py                     # Dependências globais
│   │   ├── errors/                     # Handlers de erro
│   │   │   ├── __init__.py
│   │   │   ├── http_error.py
│   │   │   ├── validation_error.py
│   │   │   └── business_error.py
│   │   │
│   │   └── v1/                         # API versão 1
│   │       ├── __init__.py
│   │       ├── router.py               # Router principal v1
│   │       │
│   │       └── endpoints/              # Endpoints organizados por domínio
│   │           ├── __init__.py
│   │           │
│   │           ├── contracts/          # Contratos de dados
│   │           │   ├── __init__.py
│   │           │   ├── data_contracts.py
│   │           │   ├── contract_versions.py
│   │           │   ├── contract_layouts.py
│   │           │   └── contract_properties.py
│   │           │
│   │           ├── components/         # Componentes modulares
│   │           │   ├── __init__.py
│   │           │   ├── fundamentals.py
│   │           │   ├── team_definitions.py
│   │           │   ├── sla_definitions.py
│   │           │   ├── pricing_definitions.py
│   │           │   └── schema_definitions.py
│   │           │
│   │           ├── data_objects/       # Objetos de dados
│   │           │   ├── __init__.py
│   │           │   ├── data_objects.py
│   │           │   └── data_object_properties.py
│   │           │
│   │           ├── quality/            # Qualidade de dados
│   │           │   ├── __init__.py
│   │           │   ├── quality_definitions.py
│   │           │   ├── quality_rules.py
│   │           │   ├── rule_links.py
│   │           │   └── execution_results.py
│   │           │
│   │           ├── metrics/            # Métricas de monitoramento
│   │           │   ├── __init__.py
│   │           │   ├── cluster_metrics.py
│   │           │   ├── job_metrics.py
│   │           │   ├── query_metrics.py
│   │           │   └── storage_metrics.py
│   │           │
│   │           ├── lineage/            # Linhagem de dados
│   │           │   ├── __init__.py
│   │           │   ├── data_lineage.py
│   │           │   ├── external_metadata.py
│   │           │   ├── external_relationships.py
│   │           │   └── column_mappings.py
│   │           │
│   │           ├── users/              # Usuários e permissões
│   │           │   ├── __init__.py
│   │           │   ├── users.py
│   │           │   ├── groups.py
│   │           │   ├── permissions.py
│   │           │   └── auth.py
│   │           │
│   │           ├── tags/               # Tags e entidades
│   │           │   ├── __init__.py
│   │           │   ├── entities.py
│   │           │   ├── tags.py
│   │           │   └── tagged.py
│   │           │
│   │           ├── governance/         # Governança e conformidade
│   │           │   ├── __init__.py
│   │           │   ├── abac_policies.py
│   │           │   └── data_classification.py
│   │           │
│   │           ├── integrations/       # Integrações
│   │           │   ├── __init__.py
│   │           │   ├── tool_integrations.py
│   │           │   ├── sync_executions.py
│   │           │   └── sync_errors.py
│   │           │
│   │           ├── audit/              # Auditoria e analytics
│   │           │   ├── __init__.py
│   │           │   ├── audit_logs.py
│   │           │   ├── quality_aggregates.py
│   │           │   └── anomaly_detection.py
│   │           │
│   │           └── admin/              # Administração
│   │               ├── __init__.py
│   │               ├── health.py
│   │               ├── metrics.py
│   │               └── system.py
│   │
│   ├── core/                           # Configurações centrais
│   │   ├── __init__.py
│   │   ├── config.py                   # Configurações da aplicação
│   │   ├── database.py                 # Configuração do banco
│   │   ├── security.py                 # Autenticação e autorização
│   │   ├── logging.py                  # Configuração de logs
│   │   ├── exceptions.py               # Exceções customizadas
│   │   ├── middleware.py               # Middlewares customizados
│   │   └── events.py                   # Event handlers
│   │
│   ├── models/                         # Modelos SQLAlchemy
│   │   ├── __init__.py
│   │   ├── base.py                     # Classe base para modelos
│   │   ├── mixins.py                   # Mixins reutilizáveis
│   │   │
│   │   ├── contracts/                  # Modelos de contratos
│   │   │   ├── __init__.py
│   │   │   ├── data_contract.py
│   │   │   ├── contract_version.py
│   │   │   ├── contract_layout.py
│   │   │   └── contract_custom_property.py
│   │   │
│   │   ├── components/                 # Modelos de componentes
│   │   │   ├── __init__.py
│   │   │   ├── contract_fundamental.py
│   │   │   ├── contract_team_definition.py
│   │   │   ├── contract_sla_definition.py
│   │   │   ├── contract_pricing_definition.py
│   │   │   └── contract_schema_definition.py
│   │   │
│   │   ├── data_objects/               # Modelos de objetos de dados
│   │   │   ├── __init__.py
│   │   │   ├── data_object.py
│   │   │   └── data_object_property.py
│   │   │
│   │   ├── quality/                    # Modelos de qualidade
│   │   │   ├── __init__.py
│   │   │   ├── contract_quality_definition.py
│   │   │   ├── quality_rule.py
│   │   │   ├── property_quality_rule_link.py
│   │   │   └── quality_execution_result.py
│   │   │
│   │   ├── metrics/                    # Modelos de métricas
│   │   │   ├── __init__.py
│   │   │   ├── cluster_metric.py
│   │   │   ├── job_metric.py
│   │   │   ├── query_metric.py
│   │   │   └── storage_metric.py
│   │   │
│   │   ├── lineage/                    # Modelos de linhagem
│   │   │   ├── __init__.py
│   │   │   ├── data_lineage.py
│   │   │   ├── external_metadata_object.py
│   │   │   ├── external_lineage_relationship.py
│   │   │   ├── external_column_mapping.py
│   │   │   └── external_system_integration.py
│   │   │
│   │   ├── users/                      # Modelos de usuários
│   │   │   ├── __init__.py
│   │   │   ├── user.py
│   │   │   ├── group.py
│   │   │   ├── user_group.py
│   │   │   ├── permission.py
│   │   │   └── group_permission.py
│   │   │
│   │   ├── tags/                       # Modelos de tags
│   │   │   ├── __init__.py
│   │   │   ├── entity.py
│   │   │   ├── tag.py
│   │   │   └── tagged.py
│   │   │
│   │   ├── governance/                 # Modelos de governança
│   │   │   ├── __init__.py
│   │   │   ├── abac_policy_evaluation.py
│   │   │   └── data_classification_result.py
│   │   │
│   │   ├── integrations/               # Modelos de integrações
│   │   │   ├── __init__.py
│   │   │   ├── tool_integration.py
│   │   │   ├── sync_execution.py
│   │   │   └── sync_error.py
│   │   │
│   │   └── audit/                      # Modelos de auditoria
│   │       ├── __init__.py
│   │       ├── audit_log.py
│   │       ├── data_quality_aggregate.py
│   │       └── data_anomaly_detection.py
│   │
│   ├── schemas/                        # Schemas Pydantic (OpenAPI)
│   │   ├── __init__.py
│   │   ├── base.py                     # Schemas base
│   │   ├── common.py                   # Schemas comuns
│   │   │
│   │   ├── contracts/                  # Schemas de contratos
│   │   │   ├── __init__.py
│   │   │   ├── data_contract.py        # DataContractCreate, DataContractUpdate, DataContractResponse
│   │   │   ├── contract_version.py
│   │   │   ├── contract_layout.py
│   │   │   └── contract_custom_property.py
│   │   │
│   │   ├── components/                 # Schemas de componentes
│   │   │   ├── __init__.py
│   │   │   ├── contract_fundamental.py
│   │   │   ├── contract_team_definition.py
│   │   │   ├── contract_sla_definition.py
│   │   │   ├── contract_pricing_definition.py
│   │   │   └── contract_schema_definition.py
│   │   │
│   │   ├── data_objects/               # Schemas de objetos de dados
│   │   │   ├── __init__.py
│   │   │   ├── data_object.py
│   │   │   └── data_object_property.py
│   │   │
│   │   ├── quality/                    # Schemas de qualidade
│   │   │   ├── __init__.py
│   │   │   ├── contract_quality_definition.py
│   │   │   ├── quality_rule.py
│   │   │   ├── property_quality_rule_link.py
│   │   │   └── quality_execution_result.py
│   │   │
│   │   ├── metrics/                    # Schemas de métricas
│   │   │   ├── __init__.py
│   │   │   ├── cluster_metric.py
│   │   │   ├── job_metric.py
│   │   │   ├── query_metric.py
│   │   │   └── storage_metric.py
│   │   │
│   │   ├── lineage/                    # Schemas de linhagem
│   │   │   ├── __init__.py
│   │   │   ├── data_lineage.py
│   │   │   ├── external_metadata_object.py
│   │   │   ├── external_lineage_relationship.py
│   │   │   ├── external_column_mapping.py
│   │   │   └── external_system_integration.py
│   │   │
│   │   ├── users/                      # Schemas de usuários
│   │   │   ├── __init__.py
│   │   │   ├── user.py
│   │   │   ├── group.py
│   │   │   ├── user_group.py
│   │   │   ├── permission.py
│   │   │   ├── group_permission.py
│   │   │   └── auth.py
│   │   │
│   │   ├── tags/                       # Schemas de tags
│   │   │   ├── __init__.py
│   │   │   ├── entity.py
│   │   │   ├── tag.py
│   │   │   └── tagged.py
│   │   │
│   │   ├── governance/                 # Schemas de governança
│   │   │   ├── __init__.py
│   │   │   ├── abac_policy_evaluation.py
│   │   │   └── data_classification_result.py
│   │   │
│   │   ├── integrations/               # Schemas de integrações
│   │   │   ├── __init__.py
│   │   │   ├── tool_integration.py
│   │   │   ├── sync_execution.py
│   │   │   └── sync_error.py
│   │   │
│   │   ├── audit/                      # Schemas de auditoria
│   │   │   ├── __init__.py
│   │   │   ├── audit_log.py
│   │   │   ├── data_quality_aggregate.py
│   │   │   └── data_anomaly_detection.py
│   │   │
│   │   └── responses/                  # Schemas de resposta padronizados
│   │       ├── __init__.py
│   │       ├── base.py                 # BaseResponse, PaginatedResponse
│   │       ├── error.py                # ErrorResponse, ValidationErrorResponse
│   │       └── success.py              # SuccessResponse, CreatedResponse
│   │
│   ├── services/                       # Lógica de negócio (Business Logic)
│   │   ├── __init__.py
│   │   ├── base.py                     # Serviço base
│   │   │
│   │   ├── contracts/                  # Serviços de contratos
│   │   │   ├── __init__.py
│   │   │   ├── data_contract_service.py
│   │   │   ├── contract_version_service.py
│   │   │   ├── contract_layout_service.py
│   │   │   └── contract_property_service.py
│   │   │
│   │   ├── components/                 # Serviços de componentes
│   │   │   ├── __init__.py
│   │   │   ├── fundamental_service.py
│   │   │   ├── team_definition_service.py
│   │   │   ├── sla_definition_service.py
│   │   │   ├── pricing_definition_service.py
│   │   │   └── schema_definition_service.py
│   │   │
│   │   ├── data_objects/               # Serviços de objetos de dados
│   │   │   ├── __init__.py
│   │   │   ├── data_object_service.py
│   │   │   └── data_object_property_service.py
│   │   │
│   │   ├── quality/                    # Serviços de qualidade
│   │   │   ├── __init__.py
│   │   │   ├── quality_definition_service.py
│   │   │   ├── quality_rule_service.py
│   │   │   ├── rule_link_service.py
│   │   │   └── execution_result_service.py
│   │   │
│   │   ├── metrics/                    # Serviços de métricas
│   │   │   ├── __init__.py
│   │   │   ├── cluster_metric_service.py
│   │   │   ├── job_metric_service.py
│   │   │   ├── query_metric_service.py
│   │   │   └── storage_metric_service.py
│   │   │
│   │   ├── lineage/                    # Serviços de linhagem
│   │   │   ├── __init__.py
│   │   │   ├── data_lineage_service.py
│   │   │   ├── external_metadata_service.py
│   │   │   ├── external_relationship_service.py
│   │   │   └── column_mapping_service.py
│   │   │
│   │   ├── users/                      # Serviços de usuários
│   │   │   ├── __init__.py
│   │   │   ├── user_service.py
│   │   │   ├── group_service.py
│   │   │   ├── permission_service.py
│   │   │   └── auth_service.py
│   │   │
│   │   ├── tags/                       # Serviços de tags
│   │   │   ├── __init__.py
│   │   │   ├── entity_service.py
│   │   │   ├── tag_service.py
│   │   │   └── tagged_service.py
│   │   │
│   │   ├── governance/                 # Serviços de governança
│   │   │   ├── __init__.py
│   │   │   ├── abac_policy_service.py
│   │   │   └── data_classification_service.py
│   │   │
│   │   ├── integrations/               # Serviços de integrações
│   │   │   ├── __init__.py
│   │   │   ├── tool_integration_service.py
│   │   │   ├── sync_execution_service.py
│   │   │   └── sync_error_service.py
│   │   │
│   │   └── audit/                      # Serviços de auditoria
│   │       ├── __init__.py
│   │       ├── audit_log_service.py
│   │       ├── quality_aggregate_service.py
│   │       └── anomaly_detection_service.py
│   │
│   ├── repositories/                   # Camada de acesso a dados (Data Access)
│   │   ├── __init__.py
│   │   ├── base.py                     # Repository base com CRUD genérico
│   │   │
│   │   ├── contracts/                  # Repositories de contratos
│   │   │   ├── __init__.py
│   │   │   ├── data_contract_repository.py
│   │   │   ├── contract_version_repository.py
│   │   │   ├── contract_layout_repository.py
│   │   │   └── contract_property_repository.py
│   │   │
│   │   ├── components/                 # Repositories de componentes
│   │   │   ├── __init__.py
│   │   │   ├── fundamental_repository.py
│   │   │   ├── team_definition_repository.py
│   │   │   ├── sla_definition_repository.py
│   │   │   ├── pricing_definition_repository.py
│   │   │   └── schema_definition_repository.py
│   │   │
│   │   ├── data_objects/               # Repositories de objetos de dados
│   │   │   ├── __init__.py
│   │   │   ├── data_object_repository.py
│   │   │   └── data_object_property_repository.py
│   │   │
│   │   ├── quality/                    # Repositories de qualidade
│   │   │   ├── __init__.py
│   │   │   ├── quality_definition_repository.py
│   │   │   ├── quality_rule_repository.py
│   │   │   ├── rule_link_repository.py
│   │   │   └── execution_result_repository.py
│   │   │
│   │   ├── metrics/                    # Repositories de métricas
│   │   │   ├── __init__.py
│   │   │   ├── cluster_metric_repository.py
│   │   │   ├── job_metric_repository.py
│   │   │   ├── query_metric_repository.py
│   │   │   └── storage_metric_repository.py
│   │   │
│   │   ├── lineage/                    # Repositories de linhagem
│   │   │   ├── __init__.py
│   │   │   ├── data_lineage_repository.py
│   │   │   ├── external_metadata_repository.py
│   │   │   ├── external_relationship_repository.py
│   │   │   └── column_mapping_repository.py
│   │   │
│   │   ├── users/                      # Repositories de usuários
│   │   │   ├── __init__.py
│   │   │   ├── user_repository.py
│   │   │   ├── group_repository.py
│   │   │   ├── permission_repository.py
│   │   │   └── auth_repository.py
│   │   │
│   │   ├── tags/                       # Repositories de tags
│   │   │   ├── __init__.py
│   │   │   ├── entity_repository.py
│   │   │   ├── tag_repository.py
│   │   │   └── tagged_repository.py
│   │   │
│   │   ├── governance/                 # Repositories de governança
│   │   │   ├── __init__.py
│   │   │   ├── abac_policy_repository.py
│   │   │   └── data_classification_repository.py
│   │   │
│   │   ├── integrations/               # Repositories de integrações
│   │   │   ├── __init__.py
│   │   │   ├── tool_integration_repository.py
│   │   │   ├── sync_execution_repository.py
│   │   │   └── sync_error_repository.py
│   │   │
│   │   └── audit/                      # Repositories de auditoria
│   │       ├── __init__.py
│   │       ├── audit_log_repository.py
│   │       ├── quality_aggregate_repository.py
│   │       └── anomaly_detection_repository.py
│   │
│   └── utils/                          # Utilitários
│       ├── __init__.py
│       ├── datetime.py                 # Utilitários de data/hora
│       ├── validators.py               # Validadores customizados
│       ├── formatters.py               # Formatadores de dados
│       ├── constants.py                # Constantes da aplicação
│       ├── enums.py                    # Enumerações
│       └── helpers.py                  # Funções auxiliares
│
├── migrations/                         # Migrações Alembic
│   ├── versions/                       # Arquivos de migração
│   ├── env.py                          # Configuração do ambiente
│   ├── script.py.mako                  # Template de migração
│   └── README
│
├── tests/                              # Testes
│   ├── __init__.py
│   ├── conftest.py                     # Configurações globais de teste
│   ├── test_main.py                    # Testes da aplicação principal
│   │
│   ├── fixtures/                       # Fixtures reutilizáveis
│   │   ├── __init__.py
│   │   ├── database.py                 # Fixtures de banco
│   │   ├── auth.py                     # Fixtures de autenticação
│   │   └── data.py                     # Fixtures de dados
│   │
│   ├── factories/                      # Factories para criação de dados
│   │   ├── __init__.py
│   │   ├── base.py                     # Factory base
│   │   ├── contracts.py                # Factories de contratos
│   │   ├── data_objects.py             # Factories de objetos de dados
│   │   ├── quality.py                  # Factories de qualidade
│   │   ├── metrics.py                  # Factories de métricas
│   │   ├── lineage.py                  # Factories de linhagem
│   │   ├── users.py                    # Factories de usuários
│   │   ├── tags.py                     # Factories de tags
│   │   ├── governance.py               # Factories de governança
│   │   ├── integrations.py             # Factories de integrações
│   │   └── audit.py                    # Factories de auditoria
│   │
│   ├── unit/                           # Testes unitários
│   │   ├── __init__.py
│   │   ├── test_core/                  # Testes do core
│   │   ├── test_models/                # Testes dos modelos
│   │   ├── test_schemas/               # Testes dos schemas
│   │   ├── test_services/              # Testes dos serviços
│   │   ├── test_repositories/          # Testes dos repositories
│   │   └── test_utils/                 # Testes dos utilitários
│   │
│   ├── integration/                    # Testes de integração
│   │   ├── __init__.py
│   │   ├── test_api/                   # Testes dos endpoints
│   │   │   ├── __init__.py
│   │   │   ├── test_contracts/
│   │   │   ├── test_components/
│   │   │   ├── test_data_objects/
│   │   │   ├── test_quality/
│   │   │   ├── test_metrics/
│   │   │   ├── test_lineage/
│   │   │   ├── test_users/
│   │   │   ├── test_tags/
│   │   │   ├── test_governance/
│   │   │   ├── test_integrations/
│   │   │   ├── test_audit/
│   │   │   └── test_admin/
│   │   │
│   │   └── test_database/              # Testes de banco de dados
│   │       ├── __init__.py
│   │       ├── test_migrations.py
│   │       └── test_relationships.py
│   │
│   └── e2e/                            # Testes end-to-end
│       ├── __init__.py
│       ├── test_workflows/             # Testes de workflows completos
│       └── test_scenarios/             # Testes de cenários de uso
│
├── docs/                               # Documentação
│   ├── index.md                        # Página inicial
│   ├── getting-started.md              # Guia de início rápido
│   ├── installation.md                 # Guia de instalação
│   │
│   ├── api/                            # Documentação da API
│   │   ├── overview.md                 # Visão geral da API
│   │   ├── authentication.md           # Autenticação
│   │   ├── pagination.md               # Paginação
│   │   ├── filtering.md                # Filtros
│   │   ├── sorting.md                  # Ordenação
│   │   ├── error-handling.md           # Tratamento de erros
│   │   └── rate-limiting.md            # Rate limiting
│   │
│   ├── user/                           # Documentação do usuário
│   │   ├── contracts.md                # Guia de contratos
│   │   ├── data-objects.md             # Guia de objetos de dados
│   │   ├── quality.md                  # Guia de qualidade
│   │   ├── lineage.md                  # Guia de linhagem
│   │   └── governance.md               # Guia de governança
│   │
│   ├── developer/                      # Documentação do desenvolvedor
│   │   ├── architecture.md             # Arquitetura do sistema
│   │   ├── database.md                 # Esquema do banco de dados
│   │   ├── testing.md                  # Guia de testes
│   │   ├── contributing.md             # Guia de contribuição
│   │   └── deployment.md               # Guia de deployment
│   │
│   └── deployment/                     # Documentação de deployment
│       ├── local-windows.md            # Deployment local Windows
│       ├── azure-aks.md                # Deployment Azure AKS
│       ├── docker.md                   # Deployment Docker
│       └── monitoring.md               # Monitoramento
│
├── scripts/                            # Scripts de automação
│   ├── windows/                        # Scripts Windows PowerShell
│   │   ├── setup-local-env.ps1         # Setup ambiente local
│   │   ├── start-api.ps1               # Iniciar API
│   │   ├── run-tests.ps1               # Executar testes
│   │   ├── populate-data.ps1           # Popular dados mock
│   │   ├── backup-db.ps1               # Backup do banco
│   │   └── restore-db.ps1              # Restore do banco
│   │
│   ├── azure/                          # Scripts Azure AKS
│   │   ├── deploy-to-aks.ps1           # Deploy para AKS
│   │   ├── update-api.ps1              # Atualizar API
│   │   ├── scale-api.ps1               # Escalar API
│   │   ├── monitor-api.ps1             # Monitorar API
│   │   ├── setup-aks.ps1               # Setup cluster AKS
│   │   └── teardown-aks.ps1            # Destruir cluster AKS
│   │
│   ├── data/                           # Scripts de dados
│   │   ├── generate-mock-data.py       # Gerar dados mock
│   │   ├── import-unity-catalog.py     # Importar do Unity Catalog
│   │   ├── export-contracts.py         # Exportar contratos
│   │   └── validate-data.py            # Validar dados
│   │
│   └── database/                       # Scripts de banco
│       ├── create-db.sql               # Criar banco
│       ├── seed-data.sql               # Dados iniciais
│       ├── backup.sh                   # Backup
│       └── restore.sh                  # Restore
│
├── docker/                             # Configurações Docker
│   ├── Dockerfile.api                  # Container da API
│   ├── Dockerfile.worker              # Container de workers
│   ├── docker-compose.yml             # Orquestração local
│   ├── docker-compose.prod.yml        # Orquestração produção
│   └── nginx.conf                      # Configuração Nginx
│
├── k8s/                                # Manifests Kubernetes
│   ├── namespace.yaml                  # Namespace
│   ├── configmap.yaml                  # ConfigMaps
│   ├── secret.yaml                     # Secrets
│   ├── deployment.yaml                 # Deployment da API
│   ├── service.yaml                    # Service
│   ├── ingress.yaml                    # Ingress
│   ├── hpa.yaml                        # Horizontal Pod Autoscaler
│   └── pdb.yaml                        # Pod Disruption Budget
│
├── helm/                               # Helm Charts
│   ├── Chart.yaml                      # Metadados do chart
│   ├── values.yaml                     # Valores padrão
│   ├── values-dev.yaml                 # Valores desenvolvimento
│   ├── values-prod.yaml                # Valores produção
│   └── templates/                      # Templates Kubernetes
│       ├── deployment.yaml
│       ├── service.yaml
│       ├── ingress.yaml
│       ├── configmap.yaml
│       └── secret.yaml
│
├── mock_data/                          # Dados mock
│   ├── contracts/                      # Dados de contratos
│   │   ├── data_contracts.json
│   │   ├── contract_versions.json
│   │   ├── contract_layouts.json
│   │   └── contract_properties.json
│   │
│   ├── components/                     # Dados de componentes
│   ├── data_objects/                   # Dados de objetos
│   ├── quality/                        # Dados de qualidade
│   ├── metrics/                        # Dados de métricas
│   ├── lineage/                        # Dados de linhagem
│   ├── users/                          # Dados de usuários
│   ├── tags/                           # Dados de tags
│   ├── governance/                     # Dados de governança
│   ├── integrations/                   # Dados de integrações
│   ├── audit/                          # Dados de auditoria
│   │
│   └── scenarios/                      # Cenários de teste
│       ├── basic-setup.json            # Setup básico
│       ├── enterprise-setup.json       # Setup empresarial
│       └── demo-setup.json             # Setup demonstração
│
└── monitoring/                         # Configurações de monitoramento
    ├── prometheus/                     # Configurações Prometheus
    │   ├── prometheus.yml
    │   └── rules.yml
    │
    ├── grafana/                        # Dashboards Grafana
    │   ├── dashboards/
    │   └── provisioning/
    │
    └── alerts/                         # Configurações de alertas
        ├── alertmanager.yml
        └── rules/
```

## Padrões OpenAPI Implementados

### 1. Especificação OpenAPI 3.0+
```python
# app/main.py
from fastapi import FastAPI
from fastapi.openapi.utils import get_openapi

app = FastAPI(
    title="Data Governance API",
    description="API completa para governança de dados baseada em contratos",
    version="1.0.0",
    openapi_version="3.0.3",
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json"
)

def custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema
    
    openapi_schema = get_openapi(
        title="Data Governance API",
        version="1.0.0",
        description="API RESTful para gerenciamento completo de governança de dados",
        routes=app.routes,
    )
    
    # Adicionar informações customizadas
    openapi_schema["info"]["contact"] = {
        "name": "Data Governance Team",
        "email": "data-governance@company.com"
    }
    
    openapi_schema["info"]["license"] = {
        "name": "MIT",
        "url": "https://opensource.org/licenses/MIT"
    }
    
    # Adicionar servidores
    openapi_schema["servers"] = [
        {"url": "http://localhost:8000", "description": "Desenvolvimento"},
        {"url": "https://api-dev.company.com", "description": "Desenvolvimento"},
        {"url": "https://api.company.com", "description": "Produção"}
    ]
    
    app.openapi_schema = openapi_schema
    return app.openapi_schema

app.openapi = custom_openapi
```

### 2. Schemas Pydantic Padronizados
```python
# app/schemas/base.py
from typing import Generic, TypeVar, Optional, List
from pydantic import BaseModel, Field
from datetime import datetime
from uuid import UUID

T = TypeVar('T')

class BaseSchema(BaseModel):
    """Schema base com configurações padrão"""
    
    class Config:
        from_attributes = True
        json_encoders = {
            datetime: lambda v: v.isoformat(),
            UUID: lambda v: str(v)
        }

class TimestampMixin(BaseModel):
    """Mixin para campos de timestamp"""
    data_criacao: datetime = Field(..., description="Data de criação do registro")
    data_atualizacao: datetime = Field(..., description="Data da última atualização")

class PaginatedResponse(BaseModel, Generic[T]):
    """Resposta paginada padronizada"""
    items: List[T] = Field(..., description="Lista de itens")
    total: int = Field(..., description="Total de itens", ge=0)
    page: int = Field(..., description="Página atual", ge=1)
    size: int = Field(..., description="Tamanho da página", ge=1, le=100)
    pages: int = Field(..., description="Total de páginas", ge=1)
    
    class Config:
        schema_extra = {
            "example": {
                "items": [],
                "total": 100,
                "page": 1,
                "size": 20,
                "pages": 5
            }
        }

class ErrorResponse(BaseModel):
    """Resposta de erro padronizada"""
    error: str = Field(..., description="Tipo do erro")
    message: str = Field(..., description="Mensagem do erro")
    details: Optional[dict] = Field(None, description="Detalhes adicionais do erro")
    timestamp: datetime = Field(default_factory=datetime.utcnow, description="Timestamp do erro")
    
    class Config:
        schema_extra = {
            "example": {
                "error": "ValidationError",
                "message": "Dados de entrada inválidos",
                "details": {"field": "contract_name", "issue": "Campo obrigatório"},
                "timestamp": "2025-07-02T10:30:00Z"
            }
        }
```

### 3. Endpoints com Documentação Completa
```python
# app/api/v1/endpoints/contracts/data_contracts.py
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, Path, status
from fastapi.responses import JSONResponse
from uuid import UUID

from app.schemas.contracts.data_contract import (
    DataContractCreate,
    DataContractUpdate,
    DataContractResponse,
    DataContractListResponse
)
from app.schemas.responses.base import PaginatedResponse, ErrorResponse
from app.services.contracts.data_contract_service import DataContractService
from app.api.deps import get_current_user, get_data_contract_service

router = APIRouter(prefix="/contracts", tags=["Data Contracts"])

@router.post(
    "/",
    response_model=DataContractResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Criar novo contrato de dados",
    description="Cria um novo contrato de dados com todas as configurações necessárias",
    responses={
        201: {"description": "Contrato criado com sucesso"},
        400: {"model": ErrorResponse, "description": "Dados de entrada inválidos"},
        401: {"model": ErrorResponse, "description": "Não autorizado"},
        409: {"model": ErrorResponse, "description": "Contrato já existe"}
    }
)
async def create_data_contract(
    contract_data: DataContractCreate = Body(
        ...,
        description="Dados do contrato a ser criado",
        example={
            "contract_name": "customer_data_contract",
            "contract_description": "Contrato para dados de clientes",
            "contract_owner": "data-team@company.com",
            "business_domain": "sales",
            "unity_catalog_name": "main_catalog",
            "unity_catalog_schema": "customer_schema",
            "data_format": "delta",
            "monitoring_enabled": True
        }
    ),
    current_user: dict = Depends(get_current_user),
    service: DataContractService = Depends(get_data_contract_service)
) -> DataContractResponse:
    """
    Criar um novo contrato de dados.
    
    Este endpoint permite criar um novo contrato de dados com todas as
    configurações necessárias para governança e monitoramento.
    
    **Parâmetros:**
    - **contract_name**: Nome único do contrato (obrigatório)
    - **contract_description**: Descrição detalhada do contrato
    - **contract_owner**: Email do proprietário responsável
    - **business_domain**: Domínio de negócio (vendas, marketing, etc.)
    - **unity_catalog_name**: Nome do catálogo no Unity Catalog
    - **data_format**: Formato dos dados (delta, parquet, json, etc.)
    - **monitoring_enabled**: Habilitar monitoramento de qualidade
    
    **Retorna:**
    - Contrato criado com ID único e timestamps
    """
    try:
        contract = await service.create_contract(contract_data, current_user["user_id"])
        return DataContractResponse.from_orm(contract)
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error": "ValidationError", "message": str(e)}
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={"error": "InternalError", "message": "Erro interno do servidor"}
        )

@router.get(
    "/",
    response_model=PaginatedResponse[DataContractListResponse],
    summary="Listar contratos de dados",
    description="Lista todos os contratos de dados com paginação e filtros",
    responses={
        200: {"description": "Lista de contratos retornada com sucesso"},
        401: {"model": ErrorResponse, "description": "Não autorizado"}
    }
)
async def list_data_contracts(
    page: int = Query(1, ge=1, description="Número da página"),
    size: int = Query(20, ge=1, le=100, description="Tamanho da página"),
    business_domain: Optional[str] = Query(None, description="Filtrar por domínio de negócio"),
    contract_status: Optional[str] = Query(None, description="Filtrar por status do contrato"),
    search: Optional[str] = Query(None, description="Buscar por nome ou descrição"),
    sort_by: Optional[str] = Query("data_criacao", description="Campo para ordenação"),
    sort_order: Optional[str] = Query("desc", regex="^(asc|desc)$", description="Ordem de classificação"),
    current_user: dict = Depends(get_current_user),
    service: DataContractService = Depends(get_data_contract_service)
) -> PaginatedResponse[DataContractListResponse]:
    """
    Listar contratos de dados com paginação e filtros.
    
    **Filtros disponíveis:**
    - **business_domain**: Filtrar por domínio de negócio
    - **contract_status**: Filtrar por status (draft, active, deprecated, archived)
    - **search**: Busca textual em nome e descrição
    
    **Ordenação:**
    - **sort_by**: Campo para ordenação (data_criacao, contract_name, etc.)
    - **sort_order**: Ordem (asc ou desc)
    
    **Paginação:**
    - **page**: Número da página (mínimo 1)
    - **size**: Itens por página (1-100)
    """
    filters = {
        "business_domain": business_domain,
        "contract_status": contract_status,
        "search": search
    }
    
    result = await service.list_contracts(
        page=page,
        size=size,
        filters=filters,
        sort_by=sort_by,
        sort_order=sort_order,
        user_id=current_user["user_id"]
    )
    
    return PaginatedResponse(
        items=[DataContractListResponse.from_orm(item) for item in result.items],
        total=result.total,
        page=page,
        size=size,
        pages=result.pages
    )

@router.get(
    "/{contract_id}",
    response_model=DataContractResponse,
    summary="Obter contrato por ID",
    description="Retorna um contrato específico pelo seu ID",
    responses={
        200: {"description": "Contrato encontrado"},
        404: {"model": ErrorResponse, "description": "Contrato não encontrado"},
        401: {"model": ErrorResponse, "description": "Não autorizado"}
    }
)
async def get_data_contract(
    contract_id: UUID = Path(..., description="ID único do contrato"),
    current_user: dict = Depends(get_current_user),
    service: DataContractService = Depends(get_data_contract_service)
) -> DataContractResponse:
    """
    Obter um contrato específico pelo ID.
    
    **Parâmetros:**
    - **contract_id**: ID único do contrato (UUID)
    
    **Retorna:**
    - Dados completos do contrato
    """
    contract = await service.get_contract_by_id(contract_id, current_user["user_id"])
    if not contract:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"error": "NotFound", "message": "Contrato não encontrado"}
        )
    
    return DataContractResponse.from_orm(contract)
```

### 4. Tratamento de Erros Padronizado
```python
# app/core/exceptions.py
from typing import Any, Dict, Optional
from fastapi import HTTPException, status

class DataGovernanceException(Exception):
    """Exceção base para o sistema de governança"""
    
    def __init__(
        self,
        message: str,
        error_code: str = "UNKNOWN_ERROR",
        details: Optional[Dict[str, Any]] = None
    ):
        self.message = message
        self.error_code = error_code
        self.details = details or {}
        super().__init__(self.message)

class ValidationError(DataGovernanceException):
    """Erro de validação de dados"""
    
    def __init__(self, message: str, field: str = None, details: Dict[str, Any] = None):
        super().__init__(
            message=message,
            error_code="VALIDATION_ERROR",
            details={"field": field, **(details or {})}
        )

class NotFoundError(DataGovernanceException):
    """Erro quando recurso não é encontrado"""
    
    def __init__(self, resource: str, identifier: str):
        super().__init__(
            message=f"{resource} não encontrado",
            error_code="NOT_FOUND",
            details={"resource": resource, "identifier": identifier}
        )

class ConflictError(DataGovernanceException):
    """Erro de conflito (recurso já existe)"""
    
    def __init__(self, resource: str, field: str, value: str):
        super().__init__(
            message=f"{resource} já existe",
            error_code="CONFLICT",
            details={"resource": resource, "field": field, "value": value}
        )

# app/api/errors/handlers.py
from fastapi import Request, HTTPException
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException

from app.core.exceptions import DataGovernanceException
from app.schemas.responses.error import ErrorResponse

async def data_governance_exception_handler(
    request: Request, 
    exc: DataGovernanceException
) -> JSONResponse:
    """Handler para exceções customizadas"""
    
    status_code_map = {
        "VALIDATION_ERROR": 400,
        "NOT_FOUND": 404,
        "CONFLICT": 409,
        "UNAUTHORIZED": 401,
        "FORBIDDEN": 403
    }
    
    status_code = status_code_map.get(exc.error_code, 500)
    
    return JSONResponse(
        status_code=status_code,
        content=ErrorResponse(
            error=exc.error_code,
            message=exc.message,
            details=exc.details
        ).dict()
    )

async def validation_exception_handler(
    request: Request, 
    exc: RequestValidationError
) -> JSONResponse:
    """Handler para erros de validação do Pydantic"""
    
    return JSONResponse(
        status_code=422,
        content=ErrorResponse(
            error="VALIDATION_ERROR",
            message="Dados de entrada inválidos",
            details={"validation_errors": exc.errors()}
        ).dict()
    )

async def http_exception_handler(
    request: Request, 
    exc: StarletteHTTPException
) -> JSONResponse:
    """Handler para exceções HTTP padrão"""
    
    return JSONResponse(
        status_code=exc.status_code,
        content=ErrorResponse(
            error="HTTP_ERROR",
            message=exc.detail,
            details={"status_code": exc.status_code}
        ).dict()
    )
```

### 5. Autenticação e Autorização
```python
# app/core/security.py
from typing import Optional
from datetime import datetime, timedelta
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import JWTError, jwt
from passlib.context import CryptContext

from app.core.config import settings
from app.schemas.users.auth import TokenData

security = HTTPBearer()
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    """Criar token JWT"""
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)
    return encoded_jwt

async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security)
) -> dict:
    """Obter usuário atual do token JWT"""
    
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    
    try:
        payload = jwt.decode(
            credentials.credentials, 
            settings.SECRET_KEY, 
            algorithms=[settings.ALGORITHM]
        )
        username: str = payload.get("sub")
        if username is None:
            raise credentials_exception
        token_data = TokenData(username=username)
    except JWTError:
        raise credentials_exception
    
    # Aqui você buscaria o usuário no banco de dados
    # user = await user_service.get_user_by_username(token_data.username)
    # if user is None:
    #     raise credentials_exception
    
    return {"user_id": "user-uuid", "username": username}
```

Esta estrutura garante:

1. **Padrões OpenAPI 3.0+** completos
2. **Documentação automática** com Swagger/ReDoc
3. **Schemas Pydantic** bem definidos
4. **Tratamento de erros** padronizado
5. **Autenticação JWT** robusta
6. **Arquitetura limpa** com separação de responsabilidades
7. **Testes abrangentes** organizados
8. **Deployment automatizado** para Windows e Azure

Posso prosseguir com a implementação desta estrutura?

