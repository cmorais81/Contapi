"""
Data Anomaly Detection model.
"""

from sqlalchemy import Boolean, Column, ForeignKey, String, Text
from sqlalchemy.dialects.postgresql import UUID as PostgresUUID
from sqlalchemy.orm import relationship

from app.models.base import BaseModel
from app.models.mixins import MetricsMixin, ValidationMixin


class DataAnomalyDetection(BaseModel, MetricsMixin, ValidationMixin):
    """
    Data Anomaly Detection model.
    
    Automated anomaly detection results.
    """

    __tablename__ = "data_anomaly_detections"

    # Foreign key to contract
    contract_id = Column(
        PostgresUUID(as_uuid=True),
        ForeignKey("data_contracts.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
        doc="Reference to contract"
    )

    # Anomaly identification
    anomaly_type = Column(
        String(100),
        nullable=False,
        index=True,
        doc="Type: statistical, pattern, volume, freshness, schema"
    )

    anomaly_description = Column(
        Text,
        doc="Description of the anomaly"
    )

    # Detection details
    detection_method = Column(
        String(100),
        doc="Detection method: z-score, isolation_forest, lstm, rule_based"
    )

    affected_table = Column(
        String(255),
        index=True,
        doc="Affected table"
    )

    affected_column = Column(
        String(255),
        doc="Affected column"
    )

    # Severity and impact
    severity_level = Column(
        String(50),
        nullable=False,
        index=True,
        doc="Severity: low, medium, high, critical"
    )

    impact_assessment = Column(
        Text,
        doc="Impact assessment"
    )

    # Anomaly metrics
    anomaly_score = Column(
        String(10),  # Using String to handle numeric as text
        doc="Anomaly score (0-1)"
    )

    threshold_value = Column(
        String(50),  # Using String to handle numeric as text
        doc="Threshold value that was exceeded"
    )

    actual_value = Column(
        String(50),  # Using String to handle numeric as text
        doc="Actual value detected"
    )

    expected_range = Column(
        String(100),
        doc="Expected value range"
    )

    # Status and resolution
    anomaly_status = Column(
        String(50),
        default="open",
        index=True,
        doc="Status: open, investigating, resolved, false_positive"
    )

    resolution_notes = Column(
        Text,
        doc="Resolution notes"
    )

    is_false_positive = Column(
        Boolean,
        default=False,
        doc="Marked as false positive"
    )

    # Relationships
    contract = relationship(
        "DataContract",
        back_populates="anomaly_detections"
    )

    def __repr__(self) -> str:
        return f"<DataAnomalyDetection(type={self.anomaly_type}, severity={self.severity_level})>"

