"""
Contract Quality Definition model.
"""

from sqlalchemy import Boolean, Column, ForeignKey, String, Text
from sqlalchemy.dialects.postgresql import UUID as PostgresUUID
from sqlalchemy.orm import relationship

from app.models.base import BaseModel
from app.models.mixins import QualityMixin


class ContractQualityDefinition(BaseModel, QualityMixin):
    """
    Contract Quality Definition model.
    
    Quality definitions and expectations for contracts.
    """

    __tablename__ = "contract_quality_definitions"

    # Foreign key to contract
    contract_id = Column(
        PostgresUUID(as_uuid=True),
        ForeignKey("data_contracts.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
        doc="Reference to contract"
    )

    # Quality definition
    quality_dimension = Column(
        String(100),
        nullable=False,
        doc="Quality dimension: completeness, accuracy, consistency, timeliness, validity"
    )

    quality_description = Column(
        Text,
        doc="Quality requirement description"
    )

    measurement_method = Column(
        String(100),
        doc="How quality is measured"
    )

    # Thresholds
    warning_threshold = Column(
        String(10),  # Using String to handle numeric as text
        doc="Warning threshold (0-100)"
    )

    critical_threshold = Column(
        String(10),  # Using String to handle numeric as text
        doc="Critical threshold (0-100)"
    )

    # Actions
    remediation_action = Column(
        Text,
        doc="Remediation action when threshold is breached"
    )

    notification_recipients = Column(
        Text,
        doc="Notification recipients (JSON array)"
    )

    # Relationships
    contract = relationship(
        "DataContract",
        back_populates="quality_definitions"
    )

    def __repr__(self) -> str:
        return f"<ContractQualityDefinition(dimension={self.quality_dimension})>"

