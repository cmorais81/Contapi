"""
Lineage Graph model.
"""

from sqlalchemy import Column, String, Text
from sqlalchemy.dialects.postgresql import UUID as PostgresUUID

from app.models.base import BaseModel


class LineageGraph(BaseModel):
    """
    Lineage Graph model.
    
    Precomputed lineage graphs for performance.
    """

    __tablename__ = "lineage_graphs"

    # Graph identification
    root_object_id = Column(
        PostgresUUID(as_uuid=True),
        nullable=False,
        index=True,
        doc="Root object ID for the graph"
    )

    root_object_type = Column(
        String(50),
        nullable=False,
        doc="Root object type: internal, external"
    )

    graph_type = Column(
        String(50),
        nullable=False,
        index=True,
        doc="Graph type: upstream, downstream, full"
    )

    # Graph data
    graph_data = Column(
        Text,
        nullable=False,
        doc="Graph data as JSON"
    )

    node_count = Column(
        String(10),  # Using String to handle integer as text
        doc="Number of nodes in graph"
    )

    edge_count = Column(
        String(10),  # Using String to handle integer as text
        doc="Number of edges in graph"
    )

    max_depth = Column(
        String(10),  # Using String to handle integer as text
        doc="Maximum depth of the graph"
    )

    # Metadata
    graph_version = Column(
        String(50),
        doc="Graph version for cache invalidation"
    )

    computation_time_ms = Column(
        String(20),  # Using String to handle integer as text
        doc="Time taken to compute graph in milliseconds"
    )

    # Status
    graph_status = Column(
        String(50),
        default="valid",
        index=True,
        doc="Status: valid, stale, computing, error"
    )

    def __repr__(self) -> str:
        return f"<LineageGraph(root_id={self.root_object_id}, type={self.graph_type}, status={self.graph_status})>"

