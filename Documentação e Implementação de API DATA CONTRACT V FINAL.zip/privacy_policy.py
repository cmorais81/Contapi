"""
Privacy Policy model.

Desenvolvido por Carlos Morais - Julho 2025
"""

from sqlalchemy import Boolean, Column, DateTime, Enum, String, Text, UUID
from sqlalchemy.orm import relationship
import enum

from app.models.base import BaseModel
from app.models.mixins import TimestampMixin


class PolicyType(enum.Enum):
    """Tipos de política de privacidade."""
    DATA_COLLECTION = "data_collection"
    DATA_PROCESSING = "data_processing"
    DATA_SHARING = "data_sharing"
    DATA_RETENTION = "data_retention"
    DATA_DELETION = "data_deletion"
    CONSENT_MANAGEMENT = "consent_management"
    ACCESS_CONTROL = "access_control"
    CROSS_BORDER_TRANSFER = "cross_border_transfer"


class PolicyStatus(enum.Enum):
    """Status da política."""
    DRAFT = "draft"
    UNDER_REVIEW = "under_review"
    APPROVED = "approved"
    ACTIVE = "active"
    SUSPENDED = "suspended"
    DEPRECATED = "deprecated"


class PrivacyPolicy(BaseModel, TimestampMixin):
    """
    Modelo para políticas de privacidade.
    
    Gerencia políticas de privacidade e proteção de dados,
    incluindo regras de coleta, processamento, compartilhamento
    e retenção de dados pessoais.
    """
    
    __tablename__ = "privacy_policies"
    
    # Identificação
    policy_id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        server_default="gen_random_uuid()",
        comment="Identificador único da política"
    )
    
    policy_name = Column(
        String(255),
        nullable=False,
        comment="Nome da política"
    )
    
    policy_type = Column(
        Enum(PolicyType),
        nullable=False,
        comment="Tipo da política"
    )
    
    # Conteúdo da política
    policy_description = Column(
        Text,
        comment="Descrição da política"
    )
    
    policy_content = Column(
        Text,
        nullable=False,
        comment="Conteúdo detalhado da política"
    )
    
    policy_rules = Column(
        Text,
        comment="Regras específicas (JSON)"
    )
    
    # Aplicabilidade
    applicable_data_types = Column(
        Text,
        comment="Tipos de dados aplicáveis (JSON array)"
    )
    
    applicable_jurisdictions = Column(
        Text,
        comment="Jurisdições aplicáveis (JSON array)"
    )
    
    applicable_regulations = Column(
        Text,
        comment="Regulamentações aplicáveis (GDPR, LGPD, CCPA, etc.)"
    )
    
    # Gestão da política
    policy_owner = Column(
        String(255),
        nullable=False,
        comment="Proprietário da política"
    )
    
    approved_by = Column(
        String(255),
        comment="Aprovado por"
    )
    
    approval_date = Column(
        DateTime,
        comment="Data de aprovação"
    )
    
    # Versionamento
    version = Column(
        String(20),
        default="1.0",
        comment="Versão da política"
    )
    
    previous_version_id = Column(
        UUID(as_uuid=True),
        comment="ID da versão anterior"
    )
    
    # Vigência
    effective_date = Column(
        DateTime,
        comment="Data de vigência"
    )
    
    expiration_date = Column(
        DateTime,
        comment="Data de expiração"
    )
    
    # Status e controle
    status = Column(
        Enum(PolicyStatus),
        default=PolicyStatus.DRAFT,
        nullable=False,
        comment="Status da política"
    )
    
    is_mandatory = Column(
        Boolean,
        default=True,
        comment="Política obrigatória"
    )
    
    requires_consent = Column(
        Boolean,
        default=False,
        comment="Requer consentimento explícito"
    )
    
    # Monitoramento
    last_review_date = Column(
        DateTime,
        comment="Data da última revisão"
    )
    
    next_review_date = Column(
        DateTime,
        comment="Data da próxima revisão"
    )
    
    review_frequency_days = Column(
        String(10),
        default="365",
        comment="Frequência de revisão em dias"
    )
    
    # Relacionamentos
    consent_records = relationship(
        "ConsentRecord",
        back_populates="policy",
        cascade="all, delete-orphan"
    )
    
    def __repr__(self) -> str:
        return f"<PrivacyPolicy(id={self.policy_id}, name='{self.policy_name}', type={self.policy_type.value})>"
    
    @property
    def is_active(self) -> bool:
        """Verifica se a política está ativa."""
        return self.status == PolicyStatus.ACTIVE
    
    @property
    def is_expired(self) -> bool:
        """Verifica se a política está expirada."""
        if not self.expiration_date:
            return False
        from datetime import datetime
        return datetime.utcnow() > self.expiration_date
    
    @property
    def needs_review(self) -> bool:
        """Verifica se a política precisa de revisão."""
        if not self.next_review_date:
            return False
        from datetime import datetime
        return datetime.utcnow() > self.next_review_date
    
    def get_applicable_data_types(self) -> list:
        """
        Retorna lista de tipos de dados aplicáveis.
        
        Returns:
            Lista de tipos de dados
        """
        import json
        if not self.applicable_data_types:
            return []
        try:
            return json.loads(self.applicable_data_types)
        except:
            return []
    
    def get_applicable_jurisdictions(self) -> list:
        """
        Retorna lista de jurisdições aplicáveis.
        
        Returns:
            Lista de jurisdições
        """
        import json
        if not self.applicable_jurisdictions:
            return []
        try:
            return json.loads(self.applicable_jurisdictions)
        except:
            return []
    
    def get_policy_rules(self) -> dict:
        """
        Retorna regras da política como dicionário.
        
        Returns:
            Dicionário com regras da política
        """
        import json
        if not self.policy_rules:
            return {}
        try:
            return json.loads(self.policy_rules)
        except:
            return {}
    
    def is_applicable_to_data_type(self, data_type: str) -> bool:
        """
        Verifica se a política se aplica a um tipo de dados.
        
        Args:
            data_type: Tipo de dados a verificar
            
        Returns:
            True se aplicável, False caso contrário
        """
        applicable_types = self.get_applicable_data_types()
        return not applicable_types or data_type in applicable_types
    
    def is_applicable_to_jurisdiction(self, jurisdiction: str) -> bool:
        """
        Verifica se a política se aplica a uma jurisdição.
        
        Args:
            jurisdiction: Jurisdição a verificar
            
        Returns:
            True se aplicável, False caso contrário
        """
        applicable_jurisdictions = self.get_applicable_jurisdictions()
        return not applicable_jurisdictions or jurisdiction in applicable_jurisdictions

