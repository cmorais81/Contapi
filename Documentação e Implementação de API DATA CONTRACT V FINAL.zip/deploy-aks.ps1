# Data Governance API - Azure AKS Deployment Script
# PowerShell Script for deploying the application to Azure Kubernetes Service

param(
    [Parameter(Mandatory=$true)]
    [string]$ResourceGroupName,
    
    [Parameter(Mandatory=$true)]
    [string]$ClusterName,
    
    [Parameter(Mandatory=$false)]
    [string]$Location = "East US",
    
    [Parameter(Mandatory=$false)]
    [ValidateSet("development", "staging", "production")]
    [string]$Environment = "development",
    
    [Parameter(Mandatory=$false)]
    [string]$ContainerRegistry = "",
    
    [Parameter(Mandatory=$false)]
    [string]$DatabaseServer = "",
    
    [Parameter(Mandatory=$false)]
    [switch]$CreateInfrastructure,
    
    [Parameter(Mandatory=$false)]
    [switch]$BuildAndPush,
    
    [Parameter(Mandatory=$false)]
    [switch]$DeployOnly,
    
    [Parameter(Mandatory=$false)]
    [switch]$UpdateSecrets,
    
    [Parameter(Mandatory=$false)]
    [switch]$Verbose
)

# Enable verbose output if requested
if ($Verbose) {
    $VerbosePreference = "Continue"
}

# Color functions for better output
function Write-Success {
    param([string]$Message)
    Write-Host "✅ $Message" -ForegroundColor Green
}

function Write-Info {
    param([string]$Message)
    Write-Host "ℹ️  $Message" -ForegroundColor Cyan
}

function Write-Warning {
    param([string]$Message)
    Write-Host "⚠️  $Message" -ForegroundColor Yellow
}

function Write-Error {
    param([string]$Message)
    Write-Host "❌ $Message" -ForegroundColor Red
}

function Write-Step {
    param([string]$Message)
    Write-Host "`n🔄 $Message" -ForegroundColor Blue
}

# Function to check if a command exists
function Test-Command {
    param([string]$Command)
    try {
        Get-Command $Command -ErrorAction Stop | Out-Null
        return $true
    }
    catch {
        return $false
    }
}

# Function to validate prerequisites
function Test-Prerequisites {
    Write-Step "Validating prerequisites"
    
    # Check Azure CLI
    if (-not (Test-Command "az")) {
        Write-Error "Azure CLI is not installed. Please install it from https://docs.microsoft.com/en-us/cli/azure/install-azure-cli"
        exit 1
    }
    
    # Check kubectl
    if (-not (Test-Command "kubectl")) {
        Write-Error "kubectl is not installed. Please install it from https://kubernetes.io/docs/tasks/tools/"
        exit 1
    }
    
    # Check Docker
    if (-not (Test-Command "docker")) {
        Write-Error "Docker is not installed. Please install Docker Desktop."
        exit 1
    }
    
    # Check Helm
    if (-not (Test-Command "helm")) {
        Write-Warning "Helm is not installed. Installing Helm..."
        Install-Helm
    }
    
    # Check Azure CLI login
    try {
        $account = az account show --query "name" -o tsv 2>$null
        if (-not $account) {
            Write-Error "Not logged in to Azure. Please run 'az login' first."
            exit 1
        }
        Write-Info "Logged in to Azure account: $account"
    }
    catch {
        Write-Error "Failed to verify Azure login. Please run 'az login' first."
        exit 1
    }
    
    Write-Success "Prerequisites validation passed"
}

# Function to install Helm
function Install-Helm {
    try {
        if ($IsWindows) {
            choco install kubernetes-helm -y
        }
        else {
            # For Linux/Mac
            curl https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash
        }
        Write-Success "Helm installed successfully"
    }
    catch {
        Write-Error "Failed to install Helm. Please install it manually from https://helm.sh/docs/intro/install/"
        exit 1
    }
}

# Function to create Azure infrastructure
function New-AzureInfrastructure {
    param(
        [string]$ResourceGroupName,
        [string]$ClusterName,
        [string]$Location,
        [string]$Environment
    )
    
    Write-Step "Creating Azure infrastructure"
    
    try {
        # Create resource group
        Write-Info "Creating resource group: $ResourceGroupName"
        az group create --name $ResourceGroupName --location $Location
        
        # Create Container Registry
        $acrName = "$($ClusterName.ToLower())acr"
        Write-Info "Creating Azure Container Registry: $acrName"
        az acr create --resource-group $ResourceGroupName --name $acrName --sku Basic --admin-enabled true
        
        # Create AKS cluster
        Write-Info "Creating AKS cluster: $ClusterName (this may take 10-15 minutes)"
        az aks create `
            --resource-group $ResourceGroupName `
            --name $ClusterName `
            --node-count 2 `
            --node-vm-size Standard_B2s `
            --enable-addons monitoring `
            --attach-acr $acrName `
            --generate-ssh-keys
        
        # Create Azure Database for PostgreSQL
        $dbServerName = "$($ClusterName.ToLower())-db"
        Write-Info "Creating Azure Database for PostgreSQL: $dbServerName"
        az postgres server create `
            --resource-group $ResourceGroupName `
            --name $dbServerName `
            --location $Location `
            --admin-user pgadmin `
            --admin-password "DataGov123!" `
            --sku-name B_Gen5_1 `
            --version 13
        
        # Configure firewall rule for Azure services
        az postgres server firewall-rule create `
            --resource-group $ResourceGroupName `
            --server $dbServerName `
            --name AllowAzureServices `
            --start-ip-address 0.0.0.0 `
            --end-ip-address 0.0.0.0
        
        # Create database
        az postgres db create `
            --resource-group $ResourceGroupName `
            --server-name $dbServerName `
            --name data_governance
        
        Write-Success "Azure infrastructure created successfully"
        
        # Set global variables for later use
        $script:ContainerRegistry = "$acrName.azurecr.io"
        $script:DatabaseServer = "$dbServerName.postgres.database.azure.com"
        
    }
    catch {
        Write-Error "Failed to create Azure infrastructure: $($_.Exception.Message)"
        exit 1
    }
}

# Function to build and push Docker image
function Build-AndPushImage {
    param(
        [string]$ContainerRegistry,
        [string]$Environment
    )
    
    Write-Step "Building and pushing Docker image"
    
    try {
        # Login to ACR
        $acrName = $ContainerRegistry.Split('.')[0]
        az acr login --name $acrName
        
        # Build image
        $imageTag = "data-governance-api:$Environment-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
        $fullImageName = "$ContainerRegistry/$imageTag"
        
        Write-Info "Building image: $fullImageName"
        docker build -t $fullImageName .
        
        # Push image
        Write-Info "Pushing image to registry"
        docker push $fullImageName
        
        Write-Success "Image built and pushed successfully: $fullImageName"
        
        # Set global variable for later use
        $script:ImageName = $fullImageName
        
    }
    catch {
        Write-Error "Failed to build and push image: $($_.Exception.Message)"
        exit 1
    }
}

# Function to get AKS credentials
function Get-AKSCredentials {
    param(
        [string]$ResourceGroupName,
        [string]$ClusterName
    )
    
    Write-Step "Getting AKS credentials"
    
    try {
        az aks get-credentials --resource-group $ResourceGroupName --name $ClusterName --overwrite-existing
        Write-Success "AKS credentials configured"
    }
    catch {
        Write-Error "Failed to get AKS credentials: $($_.Exception.Message)"
        exit 1
    }
}

# Function to create Kubernetes namespace
function New-KubernetesNamespace {
    param([string]$Environment)
    
    Write-Step "Creating Kubernetes namespace"
    
    try {
        $namespace = "data-governance-$Environment"
        kubectl create namespace $namespace --dry-run=client -o yaml | kubectl apply -f -
        Write-Success "Namespace created: $namespace"
        
        # Set as current context
        kubectl config set-context --current --namespace=$namespace
        
        return $namespace
    }
    catch {
        Write-Error "Failed to create namespace: $($_.Exception.Message)"
        exit 1
    }
}

# Function to create Kubernetes secrets
function New-KubernetesSecrets {
    param(
        [string]$Namespace,
        [string]$DatabaseServer,
        [string]$Environment
    )
    
    Write-Step "Creating Kubernetes secrets"
    
    try {
        # Database connection secret
        $dbConnectionString = "postgresql://pgadmin:DataGov123!@$DatabaseServer:5432/data_governance"
        kubectl create secret generic db-secret `
            --from-literal=DATABASE_URL=$dbConnectionString `
            --namespace=$Namespace `
            --dry-run=client -o yaml | kubectl apply -f -
        
        # API secrets
        $secretKey = [System.Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes((New-Guid).ToString()))
        kubectl create secret generic api-secret `
            --from-literal=SECRET_KEY=$secretKey `
            --from-literal=JWT_ALGORITHM=HS256 `
            --from-literal=JWT_EXPIRE_MINUTES=30 `
            --namespace=$Namespace `
            --dry-run=client -o yaml | kubectl apply -f -
        
        Write-Success "Kubernetes secrets created"
    }
    catch {
        Write-Error "Failed to create secrets: $($_.Exception.Message)"
        exit 1
    }
}

# Function to create Kubernetes manifests
function New-KubernetesManifests {
    param(
        [string]$ImageName,
        [string]$Environment,
        [string]$Namespace
    )
    
    Write-Step "Creating Kubernetes manifests"
    
    $manifestsDir = "deployment/azure/manifests"
    if (-not (Test-Path $manifestsDir)) {
        New-Item -ItemType Directory -Path $manifestsDir -Force | Out-Null
    }
    
    # Deployment manifest
    $deploymentManifest = @"
apiVersion: apps/v1
kind: Deployment
metadata:
  name: data-governance-api
  namespace: $Namespace
  labels:
    app: data-governance-api
    environment: $Environment
spec:
  replicas: 2
  selector:
    matchLabels:
      app: data-governance-api
  template:
    metadata:
      labels:
        app: data-governance-api
        environment: $Environment
    spec:
      containers:
      - name: api
        image: $ImageName
        ports:
        - containerPort: 8000
        env:
        - name: ENVIRONMENT
          value: "$Environment"
        - name: API_HOST
          value: "0.0.0.0"
        - name: API_PORT
          value: "8000"
        - name: LOG_LEVEL
          value: "INFO"
        - name: DATABASE_URL
          valueFrom:
            secretKeyRef:
              name: db-secret
              key: DATABASE_URL
        - name: SECRET_KEY
          valueFrom:
            secretKeyRef:
              name: api-secret
              key: SECRET_KEY
        - name: JWT_ALGORITHM
          valueFrom:
            secretKeyRef:
              name: api-secret
              key: JWT_ALGORITHM
        - name: JWT_EXPIRE_MINUTES
          valueFrom:
            secretKeyRef:
              name: api-secret
              key: JWT_EXPIRE_MINUTES
        resources:
          requests:
            memory: "256Mi"
            cpu: "250m"
          limits:
            memory: "512Mi"
            cpu: "500m"
        livenessProbe:
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 5
          periodSeconds: 5
---
apiVersion: v1
kind: Service
metadata:
  name: data-governance-api-service
  namespace: $Namespace
  labels:
    app: data-governance-api
spec:
  selector:
    app: data-governance-api
  ports:
  - protocol: TCP
    port: 80
    targetPort: 8000
  type: ClusterIP
---
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: data-governance-api-ingress
  namespace: $Namespace
  annotations:
    kubernetes.io/ingress.class: addon-http-application-routing
    nginx.ingress.kubernetes.io/rewrite-target: /
spec:
  rules:
  - host: data-governance-$Environment.$(az aks show --resource-group $ResourceGroupName --name $ClusterName --query addonProfiles.httpApplicationRouting.config.HTTPApplicationRoutingZoneName -o tsv)
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: data-governance-api-service
            port:
              number: 80
"@
    
    $deploymentManifest | Out-File -FilePath "$manifestsDir/deployment.yaml" -Encoding UTF8
    
    # ConfigMap for application configuration
    $configMapManifest = @"
apiVersion: v1
kind: ConfigMap
metadata:
  name: data-governance-config
  namespace: $Namespace
data:
  API_DOCS_ENABLED: "true"
  CORS_ORIGINS: "*"
  METRICS_ENABLED: "true"
  CACHE_ENABLED: "true"
"@
    
    $configMapManifest | Out-File -FilePath "$manifestsDir/configmap.yaml" -Encoding UTF8
    
    Write-Success "Kubernetes manifests created in $manifestsDir"
}

# Function to deploy to Kubernetes
function Deploy-ToKubernetes {
    param([string]$ManifestsDir)
    
    Write-Step "Deploying to Kubernetes"
    
    try {
        # Apply ConfigMap first
        kubectl apply -f "$ManifestsDir/configmap.yaml"
        
        # Apply deployment and service
        kubectl apply -f "$ManifestsDir/deployment.yaml"
        
        Write-Success "Application deployed to Kubernetes"
        
        # Wait for deployment to be ready
        Write-Info "Waiting for deployment to be ready..."
        kubectl wait --for=condition=available --timeout=300s deployment/data-governance-api
        
        Write-Success "Deployment is ready"
        
    }
    catch {
        Write-Error "Failed to deploy to Kubernetes: $($_.Exception.Message)"
        exit 1
    }
}

# Function to run database migrations
function Invoke-DatabaseMigrations {
    param([string]$Namespace)
    
    Write-Step "Running database migrations"
    
    try {
        # Create a job to run migrations
        $migrationJob = @"
apiVersion: batch/v1
kind: Job
metadata:
  name: db-migration-$(Get-Date -Format 'yyyymmdd-hhmmss')
  namespace: $Namespace
spec:
  template:
    spec:
      containers:
      - name: migration
        image: $script:ImageName
        command: ["alembic", "upgrade", "head"]
        env:
        - name: DATABASE_URL
          valueFrom:
            secretKeyRef:
              name: db-secret
              key: DATABASE_URL
      restartPolicy: Never
  backoffLimit: 3
"@
        
        $migrationJob | kubectl apply -f -
        
        Write-Info "Migration job created. Waiting for completion..."
        
        # Wait for job to complete
        $jobName = kubectl get jobs -o name | Where-Object { $_ -match "db-migration" } | Select-Object -Last 1
        if ($jobName) {
            kubectl wait --for=condition=complete --timeout=300s $jobName
            Write-Success "Database migrations completed"
        }
        else {
            Write-Warning "Could not find migration job"
        }
        
    }
    catch {
        Write-Error "Failed to run database migrations: $($_.Exception.Message)"
        Write-Info "You can run migrations manually by connecting to a pod and running: alembic upgrade head"
    }
}

# Function to show deployment information
function Show-DeploymentInfo {
    param(
        [string]$ResourceGroupName,
        [string]$ClusterName,
        [string]$Environment,
        [string]$Namespace
    )
    
    Write-Host "`n🎉 Deployment completed successfully!" -ForegroundColor Green
    Write-Host "================================================================" -ForegroundColor Green
    
    Write-Info "Environment: $Environment"
    Write-Info "Resource Group: $ResourceGroupName"
    Write-Info "AKS Cluster: $ClusterName"
    Write-Info "Namespace: $Namespace"
    
    # Get ingress URL
    try {
        $ingressHost = kubectl get ingress data-governance-api-ingress -o jsonpath='{.spec.rules[0].host}' 2>$null
        if ($ingressHost) {
            Write-Info "Application URL: http://$ingressHost"
            Write-Info "API Documentation: http://$ingressHost/docs"
            Write-Info "Health Check: http://$ingressHost/health"
        }
        else {
            Write-Warning "Ingress URL not available yet. It may take a few minutes to provision."
        }
    }
    catch {
        Write-Warning "Could not retrieve ingress URL"
    }
    
    Write-Host "`nUseful commands:" -ForegroundColor Yellow
    Write-Info "View pods: kubectl get pods -n $Namespace"
    Write-Info "View services: kubectl get services -n $Namespace"
    Write-Info "View logs: kubectl logs -f deployment/data-governance-api -n $Namespace"
    Write-Info "Scale deployment: kubectl scale deployment data-governance-api --replicas=3 -n $Namespace"
    Write-Info "Port forward (for testing): kubectl port-forward service/data-governance-api-service 8000:80 -n $Namespace"
    
    Write-Host "`nResource Status:" -ForegroundColor Yellow
    try {
        kubectl get all -n $Namespace
    }
    catch {
        Write-Warning "Could not retrieve resource status"
    }
}

# Main execution function
function Main {
    Write-Host "🚀 Data Governance API - Azure AKS Deployment" -ForegroundColor Magenta
    Write-Host "======================================================" -ForegroundColor Magenta
    
    try {
        # Validate prerequisites
        Test-Prerequisites
        
        # Set default values if not provided
        if (-not $ContainerRegistry -and -not $CreateInfrastructure) {
            $ContainerRegistry = "$($ClusterName.ToLower())acr.azurecr.io"
        }
        
        if (-not $DatabaseServer -and -not $CreateInfrastructure) {
            $DatabaseServer = "$($ClusterName.ToLower())-db.postgres.database.azure.com"
        }
        
        # Create infrastructure if requested
        if ($CreateInfrastructure) {
            New-AzureInfrastructure -ResourceGroupName $ResourceGroupName -ClusterName $ClusterName -Location $Location -Environment $Environment
        }
        
        # Build and push image if requested
        if ($BuildAndPush -or $CreateInfrastructure) {
            Build-AndPushImage -ContainerRegistry $ContainerRegistry -Environment $Environment
        }
        
        # Get AKS credentials
        Get-AKSCredentials -ResourceGroupName $ResourceGroupName -ClusterName $ClusterName
        
        # Create namespace
        $namespace = New-KubernetesNamespace -Environment $Environment
        
        # Create or update secrets
        if ($UpdateSecrets -or $CreateInfrastructure -or -not $DeployOnly) {
            New-KubernetesSecrets -Namespace $namespace -DatabaseServer $DatabaseServer -Environment $Environment
        }
        
        # Create manifests and deploy
        if (-not $DeployOnly -or $CreateInfrastructure) {
            if (-not $script:ImageName) {
                $script:ImageName = "$ContainerRegistry/data-governance-api:$Environment-latest"
            }
            New-KubernetesManifests -ImageName $script:ImageName -Environment $Environment -Namespace $namespace
        }
        
        # Deploy to Kubernetes
        Deploy-ToKubernetes -ManifestsDir "deployment/azure/manifests"
        
        # Run database migrations
        Invoke-DatabaseMigrations -Namespace $namespace
        
        # Show deployment information
        Show-DeploymentInfo -ResourceGroupName $ResourceGroupName -ClusterName $ClusterName -Environment $Environment -Namespace $namespace
        
    }
    catch {
        Write-Error "Deployment failed: $($_.Exception.Message)"
        exit 1
    }
}

# Show help if required parameters are missing
if (-not $ResourceGroupName -or -not $ClusterName) {
    Write-Host "Data Governance API - Azure AKS Deployment Script" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "Usage:" -ForegroundColor Yellow
    Write-Host "  .\deploy-aks.ps1 -ResourceGroupName <rg-name> -ClusterName <cluster-name> [options]"
    Write-Host ""
    Write-Host "Required Parameters:" -ForegroundColor Yellow
    Write-Host "  -ResourceGroupName    Azure resource group name"
    Write-Host "  -ClusterName          AKS cluster name"
    Write-Host ""
    Write-Host "Optional Parameters:" -ForegroundColor Yellow
    Write-Host "  -Location             Azure region (default: East US)"
    Write-Host "  -Environment          Target environment (development, staging, production)"
    Write-Host "  -ContainerRegistry    Container registry URL (auto-detected if not provided)"
    Write-Host "  -DatabaseServer       Database server URL (auto-detected if not provided)"
    Write-Host "  -CreateInfrastructure Create all Azure resources"
    Write-Host "  -BuildAndPush         Build and push Docker image"
    Write-Host "  -DeployOnly           Deploy existing image without building"
    Write-Host "  -UpdateSecrets        Update Kubernetes secrets"
    Write-Host "  -Verbose              Enable verbose output"
    Write-Host ""
    Write-Host "Examples:" -ForegroundColor Yellow
    Write-Host "  # Create everything from scratch"
    Write-Host "  .\deploy-aks.ps1 -ResourceGroupName 'rg-datagovernance' -ClusterName 'aks-datagovernance' -CreateInfrastructure"
    Write-Host ""
    Write-Host "  # Deploy to existing infrastructure"
    Write-Host "  .\deploy-aks.ps1 -ResourceGroupName 'rg-datagovernance' -ClusterName 'aks-datagovernance' -BuildAndPush"
    Write-Host ""
    Write-Host "  # Deploy existing image"
    Write-Host "  .\deploy-aks.ps1 -ResourceGroupName 'rg-datagovernance' -ClusterName 'aks-datagovernance' -DeployOnly"
    exit 0
}

# Run main function
Main

