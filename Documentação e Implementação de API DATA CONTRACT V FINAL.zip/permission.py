"""
Permission model.
"""

from sqlalchemy import Boolean, Column, String, Text

from app.models.base import BaseModel


class Permission(BaseModel):
    """
    Permission model.
    
    System permissions for fine-grained access control.
    """

    __tablename__ = "permissions"

    # Permission definition
    permission_name = Column(
        String(255),
        nullable=False,
        unique=True,
        index=True,
        doc="Unique permission name"
    )

    permission_description = Column(
        Text,
        doc="Permission description"
    )

    # Permission categorization
    resource_type = Column(
        String(100),
        nullable=False,
        index=True,
        doc="Resource type: contract, user, role, quality, lineage, metric"
    )

    action_type = Column(
        String(50),
        nullable=False,
        index=True,
        doc="Action type: create, read, update, delete, execute, approve"
    )

    # Permission properties
    is_system_permission = Column(
        Boolean,
        default=False,
        doc="System-defined permission (cannot be deleted)"
    )

    is_active = Column(
        Boolean,
        default=True,
        doc="Permission is active"
    )

    # ABAC support
    attribute_conditions = Column(
        Text,
        doc="Attribute-based conditions as JSON"
    )

    context_conditions = Column(
        Text,
        doc="Context-based conditions as JSON"
    )

    def __repr__(self) -> str:
        return f"<Permission(name={self.permission_name}, resource={self.resource_type}, action={self.action_type})>"

