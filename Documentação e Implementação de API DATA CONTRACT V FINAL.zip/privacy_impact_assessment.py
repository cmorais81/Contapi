"""
Privacy Impact Assessment model.

Desenvolvido por Carlos Morais - Julho 2025
"""

from sqlalchemy import Boolean, Column, String, Text, UUID

from app.models.base import BaseModel
from app.models.mixins import TimestampMixin


class PrivacyImpactAssessment(BaseModel, TimestampMixin):
    """
    Modelo para avaliação de impacto de privacidade.
    """
    
    __tablename__ = "privacy_impact_assessments"
    
    assessment_id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        server_default="gen_random_uuid()",
        comment="Identificador único da avaliação"
    )
    
    assessment_name = Column(
        String(255),
        nullable=False,
        comment="Nome da avaliação"
    )
    
    description = Column(
        Text,
        comment="Descrição da avaliação"
    )
    
    is_active = Column(
        Boolean,
        default=True,
        comment="Avaliação ativa"
    )

