"""
Entity model.

Desenvolvido por Carlos Morais (carlos.morais@f1rst.com.br)
Julho 2025
"""

from sqlalchemy import Column, Integer, String, Text, DateTime, Boolean, JSON, ForeignKey
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from app.models.base import BaseModel


class Entity(BaseModel):
    """
    Modelo para entidades unificadas.
    
    Representa qualquer objeto que pode ser taggeado no sistema:
    contratos, tabelas, colunas, usuários, etc.
    """
    __tablename__ = "entities"

    entity_id = Column(Integer, primary_key=True, index=True)
    entity_name = Column(String(255), nullable=False, index=True)
    entity_type = Column(String(100), nullable=False)  # contract, table, column, user, etc
    entity_description = Column(Text)
    
    # Referência ao objeto real
    reference_id = Column(Integer)  # ID do objeto referenciado
    reference_table = Column(String(100))  # Nome da tabela referenciada
    
    # Relacionamento com contratos (se aplicável)
    data_contract_id = Column(Integer, ForeignKey("data_contracts.contract_id"), nullable=True)
    
    # Metadados
    metadata = Column(JSON)
    properties = Column(JSON)
    
    # Status
    is_active = Column(Boolean, default=True)
    
    # Auditoria
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    created_by = Column(String(255), nullable=False)
    updated_by = Column(String(255))
    
    # Relacionamentos
    data_contract = relationship("DataContract", foreign_keys=[data_contract_id])
    tagged_associations = relationship("Tagged", back_populates="entity", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<Entity(id={self.entity_id}, name='{self.entity_name}', type='{self.entity_type}')>"
    
    @property
    def tags(self):
        """Retorna todas as tags associadas a esta entidade."""
        return [tagged.tag for tagged in self.tagged_associations if tagged.tag]

