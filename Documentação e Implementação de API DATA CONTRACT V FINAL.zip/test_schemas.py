"""
Unit tests for Pydantic schemas.
"""

import pytest
from datetime import datetime
from uuid import uuid4
from pydantic import ValidationError

from app.schemas.base import (
    BaseSchema,
    PaginationMeta,
    PaginatedResponse,
    ErrorResponse,
    SuccessResponse,
    HealthCheckResponse
)
from app.schemas.contracts import (
    DataContractCreate,
    DataContractUpdate,
    DataContractRead,
    DataContractQueryParams
)


class TestBaseSchemas:
    """Test base Pydantic schemas."""
    
    def test_pagination_meta(self):
        """Test PaginationMeta schema."""
        meta = PaginationMeta(
            page=1,
            size=20,
            total=100,
            pages=5,
            has_next=True,
            has_prev=False
        )
        
        assert meta.page == 1
        assert meta.size == 20
        assert meta.total == 100
        assert meta.pages == 5
        assert meta.has_next is True
        assert meta.has_prev is False
    
    def test_pagination_meta_validation(self):
        """Test PaginationMeta validation."""
        # Test invalid page (less than 1)
        with pytest.raises(ValidationError):
            PaginationMeta(
                page=0,
                size=20,
                total=100,
                pages=5,
                has_next=True,
                has_prev=False
            )
        
        # Test invalid size (greater than 1000)
        with pytest.raises(ValidationError):
            PaginationMeta(
                page=1,
                size=1001,
                total=100,
                pages=5,
                has_next=True,
                has_prev=False
            )
    
    def test_error_response(self):
        """Test ErrorResponse schema."""
        error = ErrorResponse(
            error="ValidationError",
            message="Invalid input data"
        )
        
        assert error.error == "ValidationError"
        assert error.message == "Invalid input data"
        assert isinstance(error.timestamp, datetime)
    
    def test_success_response(self):
        """Test SuccessResponse schema."""
        success = SuccessResponse(
            message="Operation completed successfully"
        )
        
        assert success.success is True
        assert success.message == "Operation completed successfully"
        assert isinstance(success.timestamp, datetime)
    
    def test_health_check_response(self):
        """Test HealthCheckResponse schema."""
        health = HealthCheckResponse(
            status="healthy",
            version="1.0.0",
            services={"database": "healthy", "cache": "healthy"}
        )
        
        assert health.status == "healthy"
        assert health.version == "1.0.0"
        assert health.services["database"] == "healthy"
        assert isinstance(health.timestamp, datetime)


class TestDataContractSchemas:
    """Test DataContract Pydantic schemas."""
    
    def test_data_contract_create(self):
        """Test DataContractCreate schema."""
        contract_data = {
            "contract_name": "test_contract",
            "contract_description": "Test contract description",
            "contract_owner": "test@example.com",
            "business_domain": "testing",
            "data_format": "delta",
            "table_format": "delta",
            "contract_status": "draft"
        }
        
        contract = DataContractCreate(**contract_data)
        
        assert contract.contract_name == "test_contract"
        assert contract.contract_description == "Test contract description"
        assert contract.contract_owner == "test@example.com"
        assert contract.business_domain == "testing"
        assert contract.data_format == "delta"
        assert contract.table_format == "delta"
        assert contract.contract_status == "draft"
    
    def test_data_contract_create_validation(self):
        """Test DataContractCreate validation."""
        # Test invalid contract status
        with pytest.raises(ValidationError) as exc_info:
            DataContractCreate(
                contract_name="test_contract",
                contract_status="invalid_status"
            )
        
        assert "Status must be one of" in str(exc_info.value)
        
        # Test invalid data format
        with pytest.raises(ValidationError) as exc_info:
            DataContractCreate(
                contract_name="test_contract",
                data_format="invalid_format"
            )
        
        assert "Data format must be one of" in str(exc_info.value)
        
        # Test invalid table format
        with pytest.raises(ValidationError) as exc_info:
            DataContractCreate(
                contract_name="test_contract",
                table_format="invalid_format"
            )
        
        assert "Table format must be one of" in str(exc_info.value)
    
    def test_data_contract_create_required_fields(self):
        """Test DataContractCreate required fields."""
        # Test missing contract_name
        with pytest.raises(ValidationError):
            DataContractCreate()
        
        # Test with only required field
        contract = DataContractCreate(contract_name="test_contract")
        assert contract.contract_name == "test_contract"
        assert contract.contract_status == "draft"  # default value
    
    def test_data_contract_update(self):
        """Test DataContractUpdate schema."""
        update_data = {
            "contract_description": "Updated description",
            "business_domain": "updated_domain",
            "monitoring_enabled": False
        }
        
        contract_update = DataContractUpdate(**update_data)
        
        assert contract_update.contract_description == "Updated description"
        assert contract_update.business_domain == "updated_domain"
        assert contract_update.monitoring_enabled is False
    
    def test_data_contract_update_optional_fields(self):
        """Test DataContractUpdate with all fields optional."""
        # Should work with no fields
        contract_update = DataContractUpdate()
        
        # All fields should be None by default
        assert contract_update.contract_description is None
        assert contract_update.business_domain is None
        assert contract_update.monitoring_enabled is None
    
    def test_data_contract_read(self):
        """Test DataContractRead schema."""
        contract_data = {
            "id": uuid4(),
            "contract_name": "test_contract",
            "contract_description": "Test description",
            "contract_status": "active",
            "data_criacao": datetime.utcnow(),
            "data_atualizacao": datetime.utcnow(),
            "versions_count": 3,
            "layouts_count": 2
        }
        
        contract = DataContractRead(**contract_data)
        
        assert contract.contract_name == "test_contract"
        assert contract.versions_count == 3
        assert contract.layouts_count == 2
        assert isinstance(contract.id, type(uuid4()))
    
    def test_data_contract_query_params(self):
        """Test DataContractQueryParams schema."""
        params = DataContractQueryParams(
            page=2,
            size=50,
            business_domain="sales",
            data_format="delta",
            monitoring_enabled=True,
            search="customer"
        )
        
        assert params.page == 2
        assert params.size == 50
        assert params.business_domain == "sales"
        assert params.data_format == "delta"
        assert params.monitoring_enabled is True
        assert params.search == "customer"
    
    def test_data_contract_query_params_defaults(self):
        """Test DataContractQueryParams default values."""
        params = DataContractQueryParams()
        
        assert params.page == 1
        assert params.size == 20
        assert params.sort_by == "data_criacao"
        assert params.sort_order == "desc"


class TestSchemaValidation:
    """Test schema validation features."""
    
    def test_string_strip_whitespace(self):
        """Test that string fields strip whitespace."""
        contract = DataContractCreate(
            contract_name="  test_contract  ",
            contract_description="  Test description  "
        )
        
        assert contract.contract_name == "test_contract"
        assert contract.contract_description == "Test description"
    
    def test_field_length_validation(self):
        """Test field length validation."""
        # Test contract_name max length
        with pytest.raises(ValidationError):
            DataContractCreate(
                contract_name="x" * 256  # Exceeds max_length=255
            )
        
        # Test contract_description max length
        with pytest.raises(ValidationError):
            DataContractCreate(
                contract_name="test",
                contract_description="x" * 5001  # Exceeds max_length=5000
            )
    
    def test_field_examples(self):
        """Test that schema examples are valid."""
        # Test the example from DataContractCreate
        example_data = {
            "contract_name": "customer_data_contract",
            "contract_description": "Contract for customer data management and governance",
            "contract_owner": "data-team@company.com",
            "business_domain": "sales",
            "data_location": "s3://data-lake/customer/",
            "data_format": "delta",
            "table_format": "delta",
            "unity_catalog_name": "main_catalog",
            "unity_catalog_schema": "customer_schema",
            "unity_catalog_table": "customer_table",
            "abac_enabled": True,
            "monitoring_enabled": True,
            "alert_threshold_percent": "80",
            "contract_status": "draft"
        }
        
        # Should not raise validation error
        contract = DataContractCreate(**example_data)
        assert contract.contract_name == "customer_data_contract"
    
    def test_model_config(self):
        """Test model configuration settings."""
        contract = DataContractCreate(contract_name="test")
        
        # Test from_attributes is enabled
        assert contract.model_config["from_attributes"] is True
        
        # Test validate_assignment is enabled
        assert contract.model_config["validate_assignment"] is True

