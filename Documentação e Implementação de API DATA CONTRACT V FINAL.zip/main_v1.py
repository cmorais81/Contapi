"""
Data Governance API - Main Application

Desenvolvido por Carlos Morais (carlos.morais@f1rst.com.br)
Julho 2025
"""

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import time

from app.core.config_v1 import settings
from app.api.v1.api_v1 import api_router

# Criar aplicação FastAPI
app = FastAPI(
    title=settings.PROJECT_NAME,
    description="""
    API completa para governança de dados baseada em contratos.
    
    Desenvolvida por Carlos Morais para gestão empresarial de dados,
    incluindo contratos, qualidade, linhagem, privacidade e monitoramento.
    
    **Funcionalidades Principais:**
    - Gestão de Contratos de Dados
    - Monitoramento de Qualidade
    - Rastreamento de Linhagem
    - Controle de Privacidade
    - Análise de Performance
    - Sistema de Tags e Entidades
    """,
    version=settings.VERSION,
    openapi_url=f"{settings.API_V1_STR}/openapi.json",
    docs_url="/docs",
    redoc_url="/redoc",
    contact={
        "name": "Carlos Morais",
        "email": "carlos.morais@f1rst.com.br",
    },
    license_info={
        "name": "Proprietary",
        "url": "https://f1rst.com.br/license",
    },
)

# Configurar CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.BACKEND_CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Middleware para logging de requests
@app.middleware("http")
async def log_requests(request: Request, call_next):
    """Middleware para logging de requests."""
    start_time = time.time()
    
    response = await call_next(request)
    
    process_time = time.time() - start_time
    response.headers["X-Process-Time"] = str(process_time)
    
    return response


# Handler para exceções globais
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """Handler global para exceções."""
    return JSONResponse(
        status_code=500,
        content={
            "detail": "Erro interno do servidor",
            "error_type": type(exc).__name__,
            "path": str(request.url.path)
        }
    )


# Incluir routers da API
app.include_router(api_router, prefix=settings.API_V1_STR)


# Endpoint de health check
@app.get("/health", tags=["Health"])
async def health_check():
    """
    Endpoint de verificação de saúde da API.
    
    Retorna status da aplicação e informações básicas.
    """
    return {
        "status": "healthy",
        "service": settings.PROJECT_NAME,
        "version": settings.VERSION,
        "environment": settings.ENVIRONMENT,
        "timestamp": time.time()
    }


# Endpoint raiz
@app.get("/", tags=["Root"])
async def root():
    """
    Endpoint raiz da API.
    
    Retorna informações básicas sobre a API.
    """
    return {
        "message": "Data Governance API",
        "version": settings.VERSION,
        "docs": "/docs",
        "redoc": "/redoc",
        "health": "/health",
        "api": settings.API_V1_STR,
        "author": "Carlos Morais",
        "email": "carlos.morais@f1rst.com.br"
    }


if __name__ == "__main__":
    import uvicorn
    
    uvicorn.run(
        "app.main_v1:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )

