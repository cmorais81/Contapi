"""
Data Contract endpoints.

Desenvolvido por Carlos Morais (carlos.morais@f1rst.com.br)
Julho 2025
"""

from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.schemas.contracts.data_contract_v1 import (
    DataContractCreate,
    DataContractUpdate,
    DataContractResponse,
    DataContractList
)
from app.services.contracts.data_contract_service_v1 import DataContractService

router = APIRouter(prefix="/contracts", tags=["Data Contracts"])


@router.post(
    "/",
    response_model=DataContractResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Criar novo contrato de dados",
    description="Cria um novo contrato de dados com todas as especificações necessárias."
)
async def create_data_contract(
    contract: DataContractCreate,
    db: Session = Depends(get_db)
) -> DataContractResponse:
    """
    Cria um novo contrato de dados.
    
    - **contract_name**: Nome único do contrato
    - **contract_owner**: Proprietário responsável
    - **domain**: Domínio de negócio
    - **schema_definition**: Definição do schema dos dados
    - **quality_rules**: Regras de qualidade aplicáveis
    """
    service = DataContractService(db)
    return await service.create_contract(contract)


@router.get(
    "/",
    response_model=List[DataContractList],
    summary="Listar contratos de dados",
    description="Lista todos os contratos de dados com filtros opcionais."
)
async def list_data_contracts(
    skip: int = Query(0, ge=0, description="Número de registros para pular"),
    limit: int = Query(100, ge=1, le=1000, description="Número máximo de registros"),
    domain: Optional[str] = Query(None, description="Filtrar por domínio"),
    status: Optional[str] = Query(None, description="Filtrar por status"),
    owner: Optional[str] = Query(None, description="Filtrar por proprietário"),
    db: Session = Depends(get_db)
) -> List[DataContractList]:
    """
    Lista contratos de dados com paginação e filtros.
    
    Filtros disponíveis:
    - **domain**: Filtrar por domínio específico
    - **status**: Filtrar por status (draft, active, deprecated)
    - **owner**: Filtrar por proprietário
    """
    service = DataContractService(db)
    return await service.list_contracts(
        skip=skip,
        limit=limit,
        domain=domain,
        status=status,
        owner=owner
    )


@router.get(
    "/{contract_id}",
    response_model=DataContractResponse,
    summary="Obter contrato de dados",
    description="Obtém detalhes completos de um contrato de dados específico."
)
async def get_data_contract(
    contract_id: int,
    db: Session = Depends(get_db)
) -> DataContractResponse:
    """
    Obtém um contrato de dados específico pelo ID.
    
    - **contract_id**: ID único do contrato
    """
    service = DataContractService(db)
    contract = await service.get_contract(contract_id)
    if not contract:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Contrato com ID {contract_id} não encontrado"
        )
    return contract


@router.put(
    "/{contract_id}",
    response_model=DataContractResponse,
    summary="Atualizar contrato de dados",
    description="Atualiza um contrato de dados existente."
)
async def update_data_contract(
    contract_id: int,
    contract_update: DataContractUpdate,
    db: Session = Depends(get_db)
) -> DataContractResponse:
    """
    Atualiza um contrato de dados existente.
    
    - **contract_id**: ID único do contrato
    - Apenas campos fornecidos serão atualizados
    """
    service = DataContractService(db)
    contract = await service.update_contract(contract_id, contract_update)
    if not contract:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Contrato com ID {contract_id} não encontrado"
        )
    return contract


@router.delete(
    "/{contract_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Excluir contrato de dados",
    description="Exclui um contrato de dados (soft delete)."
)
async def delete_data_contract(
    contract_id: int,
    db: Session = Depends(get_db)
):
    """
    Exclui um contrato de dados (soft delete).
    
    - **contract_id**: ID único do contrato
    """
    service = DataContractService(db)
    success = await service.delete_contract(contract_id)
    if not success:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Contrato com ID {contract_id} não encontrado"
        )


@router.post(
    "/{contract_id}/activate",
    response_model=DataContractResponse,
    summary="Ativar contrato de dados",
    description="Ativa um contrato de dados para uso em produção."
)
async def activate_data_contract(
    contract_id: int,
    db: Session = Depends(get_db)
) -> DataContractResponse:
    """
    Ativa um contrato de dados.
    
    - **contract_id**: ID único do contrato
    """
    service = DataContractService(db)
    contract = await service.activate_contract(contract_id)
    if not contract:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Contrato com ID {contract_id} não encontrado"
        )
    return contract


@router.post(
    "/{contract_id}/validate",
    summary="Validar contrato de dados",
    description="Valida a estrutura e regras de um contrato de dados."
)
async def validate_data_contract(
    contract_id: int,
    db: Session = Depends(get_db)
):
    """
    Valida um contrato de dados.
    
    - **contract_id**: ID único do contrato
    """
    service = DataContractService(db)
    validation_result = await service.validate_contract(contract_id)
    if validation_result is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Contrato com ID {contract_id} não encontrado"
        )
    return validation_result

