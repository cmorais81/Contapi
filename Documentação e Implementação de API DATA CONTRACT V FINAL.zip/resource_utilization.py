"""
Resource Utilization model.

Desenvolvido por Carlos Morais - Julho 2025
"""

from sqlalchemy import Column, String, Text, UUID

from app.models.base import BaseModel
from app.models.mixins import TimestampMixin


class ResourceUtilization(BaseModel, TimestampMixin):
    """
    Modelo para utilização de recursos.
    """
    
    __tablename__ = "resource_utilization"
    
    utilization_id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        server_default="gen_random_uuid()",
        comment="Identificador único da utilização"
    )
    
    resource_name = Column(
        String(255),
        nullable=False,
        comment="Nome do recurso"
    )
    
    description = Column(
        Text,
        comment="Descrição da utilização"
    )
    
    utilization_percentage = Column(
        String(10),
        comment="Percentual de utilização"
    )

