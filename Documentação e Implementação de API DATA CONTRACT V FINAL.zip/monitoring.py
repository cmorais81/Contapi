"""
Advanced Monitoring endpoints.

Desenvolvido por Carlos Morais - Julho 2025
"""

from datetime import datetime, timedelta
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.models.monitoring.query_performance import QueryPerformance, PerformanceLevel
from app.models.monitoring.performance_alert import PerformanceAlert, AlertSeverity
from app.schemas.base import PaginatedResponse

router = APIRouter()


@router.get(
    "/queries/problematic",
    summary="Listar Queries Problemáticas",
    description="Retorna lista de queries com problemas de performance ou alto custo",
    response_description="Lista de queries problemáticas com métricas detalhadas"
)
async def get_problematic_queries(
    db: Session = Depends(get_db),
    hours_back: int = Query(24, description="Horas para análise retrospectiva"),
    min_execution_time: Optional[float] = Query(None, description="Tempo mínimo de execução em segundos"),
    min_cost: Optional[float] = Query(None, description="Custo mínimo em USD"),
    performance_level: Optional[str] = Query(None, description="Nível de performance (slow, very_slow)"),
    limit: int = Query(100, le=1000, description="Limite de resultados"),
    offset: int = Query(0, description="Offset para paginação")
):
    """
    Identifica e retorna queries problemáticas baseado em critérios de performance.
    
    Analisa queries executadas nas últimas horas especificadas e identifica
    aquelas com problemas de performance, alto custo ou padrões anômalos.
    """
    
    # Calcular período de análise
    end_time = datetime.utcnow()
    start_time = end_time - timedelta(hours=hours_back)
    
    # Construir query base
    query = db.query(QueryPerformance).filter(
        QueryPerformance.query_start_time >= start_time,
        QueryPerformance.query_start_time <= end_time
    )
    
    # Aplicar filtros
    if min_execution_time:
        query = query.filter(
            QueryPerformance.execution_time_ms >= str(int(min_execution_time * 1000))
        )
    
    if min_cost:
        query = query.filter(
            QueryPerformance.total_cost_usd >= str(min_cost)
        )
    
    if performance_level:
        if performance_level == "slow":
            query = query.filter(QueryPerformance.performance_level == PerformanceLevel.SLOW)
        elif performance_level == "very_slow":
            query = query.filter(QueryPerformance.performance_level == PerformanceLevel.VERY_SLOW)
    
    # Filtrar apenas queries problemáticas
    query = query.filter(
        (QueryPerformance.is_slow_query == True) |
        (QueryPerformance.is_expensive_query == True) |
        (QueryPerformance.performance_level.in_([PerformanceLevel.SLOW, PerformanceLevel.VERY_SLOW]))
    )
    
    # Ordenar por tempo de execução decrescente
    query = query.order_by(QueryPerformance.execution_time_ms.desc())
    
    # Aplicar paginação
    total = query.count()
    queries = query.offset(offset).limit(limit).all()
    
    # Preparar resposta
    results = []
    for q in queries:
        result = {
            "query_id": q.query_id,
            "query_hash": q.query_hash,
            "query_type": q.query_type.value if q.query_type else None,
            "user_id": q.user_id,
            "database_name": q.database_name,
            "execution_time_seconds": q.execution_time_seconds,
            "performance_level": q.performance_level.value if q.performance_level else None,
            "total_cost_usd": q.total_cost_usd,
            "peak_memory_mb": q.peak_memory_mb,
            "bytes_read": q.bytes_read,
            "rows_read": q.rows_read,
            "is_slow_query": q.is_slow_query,
            "is_expensive_query": q.is_expensive_query,
            "query_start_time": q.query_start_time.isoformat() if q.query_start_time else None,
            "tables_accessed": q.get_tables_accessed(),
            "optimization_suggestions": q.get_optimization_suggestions(),
            "efficiency_score": q.calculate_efficiency_score(),
            "query_text_preview": q.query_text[:200] + "..." if q.query_text and len(q.query_text) > 200 else q.query_text
        }
        results.append(result)
    
    return PaginatedResponse(
        items=results,
        total=total,
        page=offset // limit + 1,
        size=limit,
        pages=(total + limit - 1) // limit
    )


@router.get(
    "/queries/cost-analysis",
    summary="Análise de Custos de Queries",
    description="Análise detalhada de custos de processamento por query, usuário e período",
    response_description="Relatório de análise de custos com breakdowns detalhados"
)
async def get_cost_analysis(
    db: Session = Depends(get_db),
    hours_back: int = Query(24, description="Horas para análise retrospectiva"),
    group_by: str = Query("user", description="Agrupar por: user, database, query_type, hour"),
    min_cost: float = Query(0.01, description="Custo mínimo para incluir na análise"),
    top_n: int = Query(20, description="Top N resultados por grupo")
):
    """
    Realiza análise detalhada de custos de processamento.
    
    Agrupa e analisa custos por diferentes dimensões, identificando
    os maiores consumidores de recursos e oportunidades de otimização.
    """
    
    # Calcular período de análise
    end_time = datetime.utcnow()
    start_time = end_time - timedelta(hours=hours_back)
    
    # Query base para análise de custos
    base_query = db.query(QueryPerformance).filter(
        QueryPerformance.query_start_time >= start_time,
        QueryPerformance.query_start_time <= end_time,
        QueryPerformance.total_cost_usd.isnot(None),
        QueryPerformance.total_cost_usd != "0"
    )
    
    # Análise por diferentes agrupamentos
    if group_by == "user":
        # Análise por usuário
        from sqlalchemy import func
        
        user_costs = db.query(
            QueryPerformance.user_id,
            func.count(QueryPerformance.query_id).label("query_count"),
            func.sum(func.cast(QueryPerformance.total_cost_usd, db.Float)).label("total_cost"),
            func.avg(func.cast(QueryPerformance.total_cost_usd, db.Float)).label("avg_cost"),
            func.max(func.cast(QueryPerformance.total_cost_usd, db.Float)).label("max_cost"),
            func.sum(func.cast(QueryPerformance.execution_time_ms, db.Float)).label("total_time_ms")
        ).filter(
            QueryPerformance.query_start_time >= start_time,
            QueryPerformance.query_start_time <= end_time,
            QueryPerformance.total_cost_usd.isnot(None)
        ).group_by(
            QueryPerformance.user_id
        ).having(
            func.sum(func.cast(QueryPerformance.total_cost_usd, db.Float)) >= min_cost
        ).order_by(
            func.sum(func.cast(QueryPerformance.total_cost_usd, db.Float)).desc()
        ).limit(top_n).all()
        
        results = []
        for row in user_costs:
            results.append({
                "user_id": row.user_id,
                "query_count": row.query_count,
                "total_cost_usd": round(float(row.total_cost or 0), 4),
                "average_cost_usd": round(float(row.avg_cost or 0), 4),
                "max_cost_usd": round(float(row.max_cost or 0), 4),
                "total_execution_time_hours": round(float(row.total_time_ms or 0) / 3600000, 2),
                "cost_per_hour": round(float(row.total_cost or 0) / max(float(row.total_time_ms or 1) / 3600000, 0.001), 2)
            })
    
    elif group_by == "database":
        # Análise por banco de dados
        from sqlalchemy import func
        
        db_costs = db.query(
            QueryPerformance.database_name,
            func.count(QueryPerformance.query_id).label("query_count"),
            func.sum(func.cast(QueryPerformance.total_cost_usd, db.Float)).label("total_cost"),
            func.avg(func.cast(QueryPerformance.total_cost_usd, db.Float)).label("avg_cost"),
            func.count(func.distinct(QueryPerformance.user_id)).label("unique_users")
        ).filter(
            QueryPerformance.query_start_time >= start_time,
            QueryPerformance.query_start_time <= end_time,
            QueryPerformance.total_cost_usd.isnot(None)
        ).group_by(
            QueryPerformance.database_name
        ).having(
            func.sum(func.cast(QueryPerformance.total_cost_usd, db.Float)) >= min_cost
        ).order_by(
            func.sum(func.cast(QueryPerformance.total_cost_usd, db.Float)).desc()
        ).limit(top_n).all()
        
        results = []
        for row in db_costs:
            results.append({
                "database_name": row.database_name,
                "query_count": row.query_count,
                "total_cost_usd": round(float(row.total_cost or 0), 4),
                "average_cost_usd": round(float(row.avg_cost or 0), 4),
                "unique_users": row.unique_users
            })
    
    elif group_by == "query_type":
        # Análise por tipo de query
        from sqlalchemy import func
        
        type_costs = db.query(
            QueryPerformance.query_type,
            func.count(QueryPerformance.query_id).label("query_count"),
            func.sum(func.cast(QueryPerformance.total_cost_usd, db.Float)).label("total_cost"),
            func.avg(func.cast(QueryPerformance.total_cost_usd, db.Float)).label("avg_cost"),
            func.avg(func.cast(QueryPerformance.execution_time_ms, db.Float)).label("avg_time_ms")
        ).filter(
            QueryPerformance.query_start_time >= start_time,
            QueryPerformance.query_start_time <= end_time,
            QueryPerformance.total_cost_usd.isnot(None),
            QueryPerformance.query_type.isnot(None)
        ).group_by(
            QueryPerformance.query_type
        ).having(
            func.sum(func.cast(QueryPerformance.total_cost_usd, db.Float)) >= min_cost
        ).order_by(
            func.sum(func.cast(QueryPerformance.total_cost_usd, db.Float)).desc()
        ).limit(top_n).all()
        
        results = []
        for row in type_costs:
            results.append({
                "query_type": row.query_type.value if row.query_type else "unknown",
                "query_count": row.query_count,
                "total_cost_usd": round(float(row.total_cost or 0), 4),
                "average_cost_usd": round(float(row.avg_cost or 0), 4),
                "average_execution_time_seconds": round(float(row.avg_time_ms or 0) / 1000, 2)
            })
    
    else:
        # Análise por hora (timeline)
        from sqlalchemy import func
        
        hourly_costs = db.query(
            func.date_trunc('hour', QueryPerformance.query_start_time).label("hour"),
            func.count(QueryPerformance.query_id).label("query_count"),
            func.sum(func.cast(QueryPerformance.total_cost_usd, db.Float)).label("total_cost"),
            func.avg(func.cast(QueryPerformance.total_cost_usd, db.Float)).label("avg_cost")
        ).filter(
            QueryPerformance.query_start_time >= start_time,
            QueryPerformance.query_start_time <= end_time,
            QueryPerformance.total_cost_usd.isnot(None)
        ).group_by(
            func.date_trunc('hour', QueryPerformance.query_start_time)
        ).order_by(
            func.date_trunc('hour', QueryPerformance.query_start_time)
        ).all()
        
        results = []
        for row in hourly_costs:
            results.append({
                "hour": row.hour.isoformat() if row.hour else None,
                "query_count": row.query_count,
                "total_cost_usd": round(float(row.total_cost or 0), 4),
                "average_cost_usd": round(float(row.avg_cost or 0), 4)
            })
    
    # Calcular estatísticas gerais
    total_queries = base_query.count()
    total_cost = db.query(
        func.sum(func.cast(QueryPerformance.total_cost_usd, db.Float))
    ).filter(
        QueryPerformance.query_start_time >= start_time,
        QueryPerformance.query_start_time <= end_time,
        QueryPerformance.total_cost_usd.isnot(None)
    ).scalar() or 0
    
    return {
        "analysis_period": {
            "start_time": start_time.isoformat(),
            "end_time": end_time.isoformat(),
            "hours_analyzed": hours_back
        },
        "summary": {
            "total_queries": total_queries,
            "total_cost_usd": round(float(total_cost), 4),
            "average_cost_per_query": round(float(total_cost) / max(total_queries, 1), 4),
            "group_by": group_by,
            "results_count": len(results)
        },
        "results": results
    }


@router.get(
    "/queries/{query_id}/performance",
    summary="Detalhes de Performance de Query",
    description="Retorna análise detalhada de performance para uma query específica",
    response_description="Métricas detalhadas de performance e recomendações"
)
async def get_query_performance_details(
    query_id: str,
    db: Session = Depends(get_db)
):
    """
    Retorna análise detalhada de performance para uma query específica.
    
    Inclui métricas completas, plano de execução, sugestões de otimização
    e comparação com execuções históricas da mesma query.
    """
    
    # Buscar performance da query
    performance = db.query(QueryPerformance).filter(
        QueryPerformance.query_id == query_id
    ).first()
    
    if not performance:
        raise HTTPException(status_code=404, detail="Query performance not found")
    
    # Buscar execuções históricas da mesma query (por hash)
    historical_executions = []
    if performance.query_hash:
        historical = db.query(QueryPerformance).filter(
            QueryPerformance.query_hash == performance.query_hash,
            QueryPerformance.query_id != query_id
        ).order_by(QueryPerformance.query_start_time.desc()).limit(10).all()
        
        for h in historical:
            historical_executions.append({
                "query_id": h.query_id,
                "execution_time_seconds": h.execution_time_seconds,
                "total_cost_usd": h.total_cost_usd,
                "performance_level": h.performance_level.value if h.performance_level else None,
                "query_start_time": h.query_start_time.isoformat() if h.query_start_time else None
            })
    
    # Buscar alertas relacionados
    alerts = db.query(PerformanceAlert).filter(
        PerformanceAlert.query_performance_id == performance.performance_id
    ).all()
    
    alert_summaries = [alert.get_alert_summary() for alert in alerts]
    
    return {
        "query_performance": performance.generate_performance_summary(),
        "detailed_metrics": {
            "execution_time_ms": performance.execution_time_ms,
            "compilation_time_ms": performance.compilation_time_ms,
            "planning_time_ms": performance.planning_time_ms,
            "cpu_time_ms": performance.cpu_time_ms,
            "peak_memory_mb": performance.peak_memory_mb,
            "spilled_memory_mb": performance.spilled_memory_mb,
            "bytes_read": performance.bytes_read,
            "bytes_written": performance.bytes_written,
            "rows_read": performance.rows_read,
            "rows_written": performance.rows_written,
            "shuffle_bytes": performance.shuffle_bytes,
            "network_bytes": performance.network_bytes
        },
        "cost_breakdown": {
            "compute_cost_usd": performance.compute_cost_usd,
            "storage_cost_usd": performance.storage_cost_usd,
            "total_cost_usd": performance.total_cost_usd
        },
        "execution_context": {
            "user_id": performance.user_id,
            "application_name": performance.application_name,
            "database_name": performance.database_name,
            "schema_name": performance.schema_name,
            "cluster_id": performance.cluster_id,
            "warehouse_id": performance.warehouse_id
        },
        "execution_plan": performance.get_execution_plan(),
        "tables_accessed": performance.get_tables_accessed(),
        "optimization_suggestions": performance.get_optimization_suggestions(),
        "historical_executions": historical_executions,
        "related_alerts": alert_summaries,
        "query_text": performance.query_text
    }


@router.get(
    "/alerts/performance",
    summary="Alertas de Performance",
    description="Lista alertas de performance ativos e históricos",
    response_description="Lista de alertas com filtros e paginação"
)
async def get_performance_alerts(
    db: Session = Depends(get_db),
    status: Optional[str] = Query(None, description="Status do alerta (open, acknowledged, resolved)"),
    severity: Optional[str] = Query(None, description="Severidade (low, medium, high, critical)"),
    alert_type: Optional[str] = Query(None, description="Tipo do alerta"),
    hours_back: int = Query(24, description="Horas para busca retrospectiva"),
    limit: int = Query(50, le=200, description="Limite de resultados"),
    offset: int = Query(0, description="Offset para paginação")
):
    """
    Lista alertas de performance com filtros avançados.
    
    Permite filtrar por status, severidade, tipo e período,
    facilitando o monitoramento e gestão de alertas.
    """
    
    # Calcular período de análise
    end_time = datetime.utcnow()
    start_time = end_time - timedelta(hours=hours_back)
    
    # Construir query
    query = db.query(PerformanceAlert).filter(
        PerformanceAlert.created_at >= start_time,
        PerformanceAlert.created_at <= end_time
    )
    
    # Aplicar filtros
    if status:
        from app.models.monitoring.performance_alert import AlertStatus
        try:
            status_enum = AlertStatus(status)
            query = query.filter(PerformanceAlert.status == status_enum)
        except ValueError:
            raise HTTPException(status_code=400, detail=f"Invalid status: {status}")
    
    if severity:
        try:
            severity_enum = AlertSeverity(severity)
            query = query.filter(PerformanceAlert.severity == severity_enum)
        except ValueError:
            raise HTTPException(status_code=400, detail=f"Invalid severity: {severity}")
    
    if alert_type:
        from app.models.monitoring.performance_alert import AlertType
        try:
            type_enum = AlertType(alert_type)
            query = query.filter(PerformanceAlert.alert_type == type_enum)
        except ValueError:
            raise HTTPException(status_code=400, detail=f"Invalid alert_type: {alert_type}")
    
    # Ordenar por prioridade e data
    query = query.order_by(
        PerformanceAlert.severity.desc(),
        PerformanceAlert.created_at.desc()
    )
    
    # Aplicar paginação
    total = query.count()
    alerts = query.offset(offset).limit(limit).all()
    
    # Preparar resposta
    results = [alert.get_alert_summary() for alert in alerts]
    
    return PaginatedResponse(
        items=results,
        total=total,
        page=offset // limit + 1,
        size=limit,
        pages=(total + limit - 1) // limit
    )

