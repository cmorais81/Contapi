"""
Contract Layout model.

Desenvolvido por Carlos Morais (carlos.morais@f1rst.com.br)
Julho 2025
"""

from sqlalchemy import Column, Integer, String, Text, DateTime, JSON, ForeignKey
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from app.models.base import BaseModel


class ContractLayout(BaseModel):
    """Modelo para layouts de contratos de dados."""
    __tablename__ = "contract_layouts"

    layout_id = Column(Integer, primary_key=True, index=True)
    contract_id = Column(Integer, ForeignKey("data_contracts.contract_id"), nullable=False)
    layout_name = Column(String(255), nullable=False)
    layout_type = Column(String(50), nullable=False)  # json, avro, parquet, etc
    layout_definition = Column(JSON)
    
    # Auditoria
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    created_by = Column(String(255), nullable=False)
    
    # Relacionamentos
    contract = relationship("DataContract", back_populates="layouts")
    
    def __repr__(self):
        return f"<ContractLayout(id={self.layout_id}, name='{self.layout_name}', type='{self.layout_type}')>"

