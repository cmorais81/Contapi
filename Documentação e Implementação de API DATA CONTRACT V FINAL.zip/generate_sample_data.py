"""
Generate sample data files for testing and demonstration.
"""

import json
import csv
from pathlib import Path
from typing import Dict, List

from scripts.factories import MockDataGenerator


def create_sample_data_directory():
    """Create sample data directory structure."""
    base_dir = Path("sample_data")
    base_dir.mkdir(exist_ok=True)
    
    subdirs = ["contracts", "users", "quality", "lineage", "metrics", "governance"]
    for subdir in subdirs:
        (base_dir / subdir).mkdir(exist_ok=True)
    
    return base_dir


def generate_json_files(data: Dict[str, List], base_dir: Path):
    """Generate JSON files for each data type."""
    print("Generating JSON files...")
    
    # Contracts
    contracts_data = []
    for contract in data["contracts"]:
        contracts_data.append({
            "contract_name": contract.contract_name,
            "contract_description": contract.contract_description,
            "contract_owner": contract.contract_owner,
            "business_domain": contract.business_domain,
            "data_location": contract.data_location,
            "data_format": contract.data_format,
            "table_format": contract.table_format,
            "unity_catalog_name": contract.unity_catalog_name,
            "unity_catalog_schema": contract.unity_catalog_schema,
            "unity_catalog_table": contract.unity_catalog_table,
            "abac_enabled": contract.abac_enabled,
            "monitoring_enabled": contract.monitoring_enabled,
            "alert_threshold_percent": contract.alert_threshold_percent,
            "contract_status": contract.contract_status
        })
    
    with open(base_dir / "contracts" / "sample_contracts.json", "w") as f:
        json.dump(contracts_data, f, indent=2)
    
    # Users
    users_data = []
    for user in data["users"]:
        users_data.append({
            "username": user.username,
            "email": user.email,
            "full_name": user.full_name,
            "department": user.department,
            "job_title": user.job_title,
            "phone_number": user.phone_number,
            "is_active": user.is_active,
            "is_superuser": user.is_superuser
        })
    
    with open(base_dir / "users" / "sample_users.json", "w") as f:
        json.dump(users_data, f, indent=2)
    
    # Quality Rules
    quality_data = []
    for rule in data["quality_rules"]:
        quality_data.append({
            "rule_name": rule.rule_name,
            "rule_description": rule.rule_description,
            "rule_type": rule.rule_type,
            "rule_category": rule.rule_category,
            "rule_logic": rule.rule_logic,
            "severity_level": rule.severity_level,
            "is_enabled": rule.is_enabled,
            "rule_status": rule.rule_status
        })
    
    with open(base_dir / "quality" / "sample_quality_rules.json", "w") as f:
        json.dump(quality_data, f, indent=2)
    
    # External Objects
    lineage_data = []
    for obj in data["external_objects"]:
        lineage_data.append({
            "object_name": obj.object_name,
            "object_description": obj.object_description,
            "entity_type": obj.entity_type,
            "system_type": obj.system_type,
            "workspace_name": obj.workspace_name,
            "owner_email": obj.owner_email,
            "object_status": obj.object_status
        })
    
    with open(base_dir / "lineage" / "sample_external_objects.json", "w") as f:
        json.dump(lineage_data, f, indent=2)
    
    # Metrics
    metrics_data = {
        "cluster_metrics": [],
        "storage_metrics": []
    }
    
    for metric in data["cluster_metrics"]:
        metrics_data["cluster_metrics"].append({
            "cluster_id": metric.cluster_id,
            "cluster_name": metric.cluster_name,
            "cluster_type": metric.cluster_type,
            "node_count": metric.node_count,
            "cpu_cores_total": metric.cpu_cores_total,
            "memory_gb_total": metric.memory_gb_total,
            "cpu_utilization_percent": metric.cpu_utilization_percent,
            "memory_utilization_percent": metric.memory_utilization_percent,
            "uptime_hours": metric.uptime_hours,
            "cost_per_hour_usd": metric.cost_per_hour_usd
        })
    
    for metric in data["storage_metrics"]:
        metrics_data["storage_metrics"].append({
            "storage_location": metric.storage_location,
            "table_name": metric.table_name,
            "total_size_bytes": metric.total_size_bytes,
            "compressed_size_bytes": metric.compressed_size_bytes,
            "file_count": metric.file_count,
            "row_count": metric.row_count,
            "compression_ratio": metric.compression_ratio,
            "storage_cost_usd": metric.storage_cost_usd
        })
    
    with open(base_dir / "metrics" / "sample_metrics.json", "w") as f:
        json.dump(metrics_data, f, indent=2)
    
    # Governance Policies
    governance_data = []
    for policy in data["policies"]:
        governance_data.append({
            "policy_name": policy.policy_name,
            "policy_description": policy.policy_description,
            "policy_type": policy.policy_type,
            "policy_category": policy.policy_category,
            "policy_rules": policy.policy_rules,
            "enforcement_level": policy.enforcement_level,
            "policy_status": policy.policy_status,
            "is_mandatory": policy.is_mandatory
        })
    
    with open(base_dir / "governance" / "sample_policies.json", "w") as f:
        json.dump(governance_data, f, indent=2)
    
    print(f"Generated JSON files in {base_dir}")


def generate_csv_files(data: Dict[str, List], base_dir: Path):
    """Generate CSV files for each data type."""
    print("Generating CSV files...")
    
    # Contracts CSV
    with open(base_dir / "contracts" / "sample_contracts.csv", "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([
            "contract_name", "contract_description", "contract_owner", "business_domain",
            "data_location", "data_format", "table_format", "unity_catalog_name",
            "unity_catalog_schema", "unity_catalog_table", "abac_enabled",
            "monitoring_enabled", "alert_threshold_percent", "contract_status"
        ])
        
        for contract in data["contracts"]:
            writer.writerow([
                contract.contract_name, contract.contract_description, contract.contract_owner,
                contract.business_domain, contract.data_location, contract.data_format,
                contract.table_format, contract.unity_catalog_name, contract.unity_catalog_schema,
                contract.unity_catalog_table, contract.abac_enabled, contract.monitoring_enabled,
                contract.alert_threshold_percent, contract.contract_status
            ])
    
    # Users CSV
    with open(base_dir / "users" / "sample_users.csv", "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([
            "username", "email", "full_name", "department", "job_title",
            "phone_number", "is_active", "is_superuser"
        ])
        
        for user in data["users"]:
            writer.writerow([
                user.username, user.email, user.full_name, user.department,
                user.job_title, user.phone_number, user.is_active, user.is_superuser
            ])
    
    # Quality Rules CSV
    with open(base_dir / "quality" / "sample_quality_rules.csv", "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([
            "rule_name", "rule_description", "rule_type", "rule_category",
            "rule_logic", "severity_level", "is_enabled", "rule_status"
        ])
        
        for rule in data["quality_rules"]:
            writer.writerow([
                rule.rule_name, rule.rule_description, rule.rule_type, rule.rule_category,
                rule.rule_logic, rule.severity_level, rule.is_enabled, rule.rule_status
            ])
    
    print(f"Generated CSV files in {base_dir}")


def generate_api_examples(base_dir: Path):
    """Generate API request/response examples."""
    print("Generating API examples...")
    
    api_dir = base_dir / "api_examples"
    api_dir.mkdir(exist_ok=True)
    
    # Contract creation example
    contract_create_example = {
        "request": {
            "method": "POST",
            "url": "/api/v1/contracts/",
            "headers": {
                "Content-Type": "application/json"
            },
            "body": {
                "contract_name": "customer_data_contract",
                "contract_description": "Contract for customer data management and governance",
                "contract_owner": "data-team@company.com",
                "business_domain": "sales",
                "data_location": "s3://data-lake/customer/",
                "data_format": "delta",
                "table_format": "delta",
                "unity_catalog_name": "main_catalog",
                "unity_catalog_schema": "customer_schema",
                "unity_catalog_table": "customer_table",
                "abac_enabled": True,
                "monitoring_enabled": True,
                "alert_threshold_percent": "80",
                "contract_status": "draft"
            }
        },
        "response": {
            "status_code": 201,
            "body": {
                "id": "123e4567-e89b-12d3-a456-426614174000",
                "contract_name": "customer_data_contract",
                "contract_description": "Contract for customer data management and governance",
                "contract_owner": "data-team@company.com",
                "business_domain": "sales",
                "contract_status": "draft",
                "data_criacao": "2024-01-01T00:00:00Z",
                "data_atualizacao": "2024-01-01T00:00:00Z"
            }
        }
    }
    
    with open(api_dir / "contract_create_example.json", "w") as f:
        json.dump(contract_create_example, f, indent=2)
    
    # Contract list example
    contract_list_example = {
        "request": {
            "method": "GET",
            "url": "/api/v1/contracts/?page=1&size=20&business_domain=sales",
            "headers": {}
        },
        "response": {
            "status_code": 200,
            "body": {
                "items": [
                    {
                        "id": "123e4567-e89b-12d3-a456-426614174000",
                        "contract_name": "customer_data_contract",
                        "contract_description": "Contract for customer data management",
                        "contract_owner": "data-team@company.com",
                        "business_domain": "sales",
                        "contract_status": "active",
                        "data_criacao": "2024-01-01T00:00:00Z",
                        "data_atualizacao": "2024-01-01T00:00:00Z"
                    }
                ],
                "meta": {
                    "page": 1,
                    "size": 20,
                    "total": 100,
                    "pages": 5,
                    "has_next": True,
                    "has_prev": False
                }
            }
        }
    }
    
    with open(api_dir / "contract_list_example.json", "w") as f:
        json.dump(contract_list_example, f, indent=2)
    
    print(f"Generated API examples in {api_dir}")


def generate_readme(base_dir: Path):
    """Generate README file for sample data."""
    readme_content = """# Sample Data for Data Governance API

This directory contains sample data files for testing and demonstration purposes.

## Directory Structure

- `contracts/` - Sample data contracts
- `users/` - Sample user accounts and roles
- `quality/` - Sample quality rules and metrics
- `lineage/` - Sample external lineage objects
- `metrics/` - Sample performance and usage metrics
- `governance/` - Sample governance policies
- `api_examples/` - Sample API request/response examples

## File Formats

Each directory contains data in multiple formats:
- `.json` - JSON format for API testing
- `.csv` - CSV format for data import/export

## Usage

### Loading Data into Database

Use the population script to load all sample data:

```bash
python scripts/populate_db.py
```

### API Testing

Use the JSON files in `api_examples/` to test API endpoints with tools like:
- Postman
- curl
- HTTPie
- Insomnia

### Data Import

Use the CSV files to import data into external systems or for bulk operations.

## Data Statistics

The sample data includes:
- 50 users across different departments
- 10 roles with various permissions
- 100 data contracts covering multiple business domains
- 200 quality rules for data validation
- 150 external lineage objects from various systems
- 30 tags for data classification
- 25 governance policies for compliance
- 15 integration configurations
- 250+ metrics records

## Customization

To generate custom sample data:

1. Modify the factories in `scripts/factories.py`
2. Adjust the counts in `scripts/generate_sample_data.py`
3. Run the generation script:

```bash
python scripts/generate_sample_data.py
```

## Notes

- All data is randomly generated and not based on real systems
- Email addresses and names are fictional
- Use this data for testing and development only
- Do not use in production environments
"""
    
    with open(base_dir / "README.md", "w") as f:
        f.write(readme_content)
    
    print(f"Generated README in {base_dir}")


def main():
    """Main function to generate all sample data."""
    print("🎯 Generating Sample Data for Data Governance API")
    print("=" * 60)
    
    # Create directory structure
    base_dir = create_sample_data_directory()
    print(f"Created sample data directory: {base_dir}")
    
    # Generate mock data
    generator = MockDataGenerator()
    data = generator.generate_all_data()
    
    print(f"\nGenerated mock data:")
    summary = generator.get_summary()
    for entity_type, count in summary.items():
        if entity_type != "total_records":
            print(f"  - {entity_type}: {count} records")
    print(f"  - Total: {summary['total_records']} records")
    
    # Generate files
    generate_json_files(data, base_dir)
    generate_csv_files(data, base_dir)
    generate_api_examples(base_dir)
    generate_readme(base_dir)
    
    print(f"\n✅ Sample data generation completed!")
    print(f"📁 Files generated in: {base_dir.absolute()}")
    print(f"\nNext steps:")
    print(f"1. Review the generated data in {base_dir}")
    print(f"2. Load data into database: python scripts/populate_db.py")
    print(f"3. Start the API server: python -m app.main")
    print(f"4. Test with sample data using the API examples")


if __name__ == "__main__":
    main()

