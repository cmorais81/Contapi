# Data Governance API - Windows Development Environment Setup
# PowerShell Script for setting up development environment on Windows

param(
    [Parameter(Mandatory=$false)]
    [string]$PythonVersion = "3.11",
    
    [Parameter(Mandatory=$false)]
    [string]$ProjectPath = "C:\dev\data-governance-api",
    
    [Parameter(Mandatory=$false)]
    [switch]$SkipPython,
    
    [Parameter(Mandatory=$false)]
    [switch]$SkipDocker,
    
    [Parameter(Mandatory=$false)]
    [switch]$SkipDatabase,
    
    [Parameter(Mandatory=$false)]
    [switch]$Verbose
)

# Enable verbose output if requested
if ($Verbose) {
    $VerbosePreference = "Continue"
}

# Color functions for better output
function Write-Success {
    param([string]$Message)
    Write-Host "✅ $Message" -ForegroundColor Green
}

function Write-Info {
    param([string]$Message)
    Write-Host "ℹ️  $Message" -ForegroundColor Cyan
}

function Write-Warning {
    param([string]$Message)
    Write-Host "⚠️  $Message" -ForegroundColor Yellow
}

function Write-Error {
    param([string]$Message)
    Write-Host "❌ $Message" -ForegroundColor Red
}

function Write-Step {
    param([string]$Message)
    Write-Host "`n🔄 $Message" -ForegroundColor Blue
}

# Function to check if running as administrator
function Test-Administrator {
    $currentUser = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($currentUser)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

# Function to check if a command exists
function Test-Command {
    param([string]$Command)
    try {
        Get-Command $Command -ErrorAction Stop | Out-Null
        return $true
    }
    catch {
        return $false
    }
}

# Function to install Chocolatey
function Install-Chocolatey {
    Write-Step "Installing Chocolatey package manager"
    
    if (Test-Command "choco") {
        Write-Info "Chocolatey is already installed"
        return
    }
    
    try {
        Set-ExecutionPolicy Bypass -Scope Process -Force
        [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072
        Invoke-Expression ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))
        Write-Success "Chocolatey installed successfully"
    }
    catch {
        Write-Error "Failed to install Chocolatey: $($_.Exception.Message)"
        exit 1
    }
}

# Function to install Python
function Install-Python {
    param([string]$Version)
    
    Write-Step "Installing Python $Version"
    
    if (Test-Command "python") {
        $currentVersion = python --version 2>&1
        Write-Info "Python is already installed: $currentVersion"
        
        # Check if version matches
        if ($currentVersion -match $Version) {
            Write-Success "Python $Version is already installed"
            return
        }
        else {
            Write-Warning "Different Python version detected. Installing Python $Version alongside existing installation"
        }
    }
    
    try {
        choco install python --version=$Version -y
        Write-Success "Python $Version installed successfully"
        
        # Refresh environment variables
        $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")
    }
    catch {
        Write-Error "Failed to install Python: $($_.Exception.Message)"
        exit 1
    }
}

# Function to install Git
function Install-Git {
    Write-Step "Installing Git"
    
    if (Test-Command "git") {
        Write-Info "Git is already installed"
        return
    }
    
    try {
        choco install git -y
        Write-Success "Git installed successfully"
        
        # Refresh environment variables
        $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")
    }
    catch {
        Write-Error "Failed to install Git: $($_.Exception.Message)"
        exit 1
    }
}

# Function to install Docker Desktop
function Install-Docker {
    Write-Step "Installing Docker Desktop"
    
    if (Test-Command "docker") {
        Write-Info "Docker is already installed"
        return
    }
    
    try {
        choco install docker-desktop -y
        Write-Success "Docker Desktop installed successfully"
        Write-Warning "Please restart your computer and start Docker Desktop manually before continuing"
    }
    catch {
        Write-Error "Failed to install Docker Desktop: $($_.Exception.Message)"
        exit 1
    }
}

# Function to install PostgreSQL
function Install-PostgreSQL {
    Write-Step "Installing PostgreSQL"
    
    if (Test-Command "psql") {
        Write-Info "PostgreSQL is already installed"
        return
    }
    
    try {
        choco install postgresql13 --params '/Password:postgres123' -y
        Write-Success "PostgreSQL installed successfully"
        Write-Info "Default password for postgres user: postgres123"
        
        # Refresh environment variables
        $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")
    }
    catch {
        Write-Error "Failed to install PostgreSQL: $($_.Exception.Message)"
        exit 1
    }
}

# Function to setup project directory
function Setup-ProjectDirectory {
    param([string]$Path)
    
    Write-Step "Setting up project directory at $Path"
    
    if (Test-Path $Path) {
        Write-Info "Project directory already exists"
    }
    else {
        try {
            New-Item -ItemType Directory -Path $Path -Force | Out-Null
            Write-Success "Project directory created"
        }
        catch {
            Write-Error "Failed to create project directory: $($_.Exception.Message)"
            exit 1
        }
    }
    
    Set-Location $Path
    Write-Info "Changed to project directory: $Path"
}

# Function to create Python virtual environment
function Setup-VirtualEnvironment {
    param([string]$ProjectPath)
    
    Write-Step "Setting up Python virtual environment"
    
    $venvPath = Join-Path $ProjectPath "venv"
    
    if (Test-Path $venvPath) {
        Write-Info "Virtual environment already exists"
    }
    else {
        try {
            python -m venv $venvPath
            Write-Success "Virtual environment created"
        }
        catch {
            Write-Error "Failed to create virtual environment: $($_.Exception.Message)"
            exit 1
        }
    }
    
    # Activate virtual environment
    $activateScript = Join-Path $venvPath "Scripts\Activate.ps1"
    if (Test-Path $activateScript) {
        try {
            & $activateScript
            Write-Success "Virtual environment activated"
        }
        catch {
            Write-Error "Failed to activate virtual environment: $($_.Exception.Message)"
            exit 1
        }
    }
}

# Function to install Python dependencies
function Install-Dependencies {
    Write-Step "Installing Python dependencies"
    
    try {
        # Upgrade pip first
        python -m pip install --upgrade pip
        
        # Install development dependencies
        if (Test-Path "requirements-dev.txt") {
            pip install -r requirements-dev.txt
            Write-Success "Development dependencies installed"
        }
        elseif (Test-Path "requirements.txt") {
            pip install -r requirements.txt
            Write-Success "Dependencies installed"
        }
        else {
            Write-Warning "No requirements file found. Installing basic dependencies"
            pip install fastapi uvicorn sqlalchemy psycopg2-binary alembic pytest
        }
    }
    catch {
        Write-Error "Failed to install dependencies: $($_.Exception.Message)"
        exit 1
    }
}

# Function to setup environment variables
function Setup-Environment {
    param([string]$ProjectPath)
    
    Write-Step "Setting up environment variables"
    
    $envFile = Join-Path $ProjectPath ".env"
    $envExampleFile = Join-Path $ProjectPath ".env.example"
    
    if (Test-Path $envFile) {
        Write-Info "Environment file already exists"
    }
    elseif (Test-Path $envExampleFile) {
        try {
            Copy-Item $envExampleFile $envFile
            Write-Success "Environment file created from example"
            Write-Info "Please edit .env file with your specific configuration"
        }
        catch {
            Write-Error "Failed to copy environment file: $($_.Exception.Message)"
        }
    }
    else {
        # Create basic .env file
        $envContent = @"
# Data Governance API Environment Configuration

# Database Configuration
DATABASE_URL=postgresql://postgres:postgres123@localhost:5432/data_governance
TEST_DATABASE_URL=postgresql://postgres:postgres123@localhost:5432/data_governance_test

# API Configuration
API_HOST=0.0.0.0
API_PORT=8000
API_DOCS_ENABLED=true

# Security Configuration
SECRET_KEY=your-secret-key-here-change-in-production
JWT_ALGORITHM=HS256
JWT_EXPIRE_MINUTES=30

# Environment
ENVIRONMENT=development
LOG_LEVEL=DEBUG

# External Integrations (Optional)
UNITY_CATALOG_URL=
UNITY_CATALOG_TOKEN=
TABLEAU_SERVER_URL=
TABLEAU_USERNAME=
TABLEAU_PASSWORD=
"@
        
        try {
            $envContent | Out-File -FilePath $envFile -Encoding UTF8
            Write-Success "Basic environment file created"
            Write-Warning "Please update the SECRET_KEY and other configuration values in .env file"
        }
        catch {
            Write-Error "Failed to create environment file: $($_.Exception.Message)"
        }
    }
}

# Function to setup database
function Setup-Database {
    Write-Step "Setting up database"
    
    try {
        # Check if PostgreSQL service is running
        $service = Get-Service -Name "postgresql*" -ErrorAction SilentlyContinue
        if ($service -and $service.Status -ne "Running") {
            Start-Service $service.Name
            Write-Info "Started PostgreSQL service"
        }
        
        # Create database
        $createDbScript = @"
CREATE DATABASE data_governance;
CREATE DATABASE data_governance_test;
"@
        
        $createDbScript | psql -U postgres -h localhost
        Write-Success "Databases created successfully"
    }
    catch {
        Write-Warning "Database setup failed. You may need to create databases manually:"
        Write-Info "  createdb -U postgres data_governance"
        Write-Info "  createdb -U postgres data_governance_test"
    }
}

# Function to run database migrations
function Run-Migrations {
    Write-Step "Running database migrations"
    
    try {
        if (Test-Path "alembic.ini") {
            alembic upgrade head
            Write-Success "Database migrations completed"
        }
        else {
            Write-Warning "Alembic configuration not found. Skipping migrations"
        }
    }
    catch {
        Write-Error "Failed to run migrations: $($_.Exception.Message)"
        Write-Info "You can run migrations manually later with: alembic upgrade head"
    }
}

# Function to install development tools
function Install-DevTools {
    Write-Step "Installing development tools"
    
    try {
        # Install VS Code if not present
        if (-not (Test-Command "code")) {
            choco install vscode -y
            Write-Success "VS Code installed"
        }
        
        # Install Windows Terminal if not present
        if (-not (Get-AppxPackage -Name "Microsoft.WindowsTerminal" -ErrorAction SilentlyContinue)) {
            choco install microsoft-windows-terminal -y
            Write-Success "Windows Terminal installed"
        }
        
        # Install PyCharm Community (optional)
        Write-Info "To install PyCharm Community Edition, run: choco install pycharm-community"
        
    }
    catch {
        Write-Warning "Some development tools installation failed: $($_.Exception.Message)"
    }
}

# Function to create useful scripts
function Create-Scripts {
    param([string]$ProjectPath)
    
    Write-Step "Creating utility scripts"
    
    $scriptsDir = Join-Path $ProjectPath "scripts\windows"
    if (-not (Test-Path $scriptsDir)) {
        New-Item -ItemType Directory -Path $scriptsDir -Force | Out-Null
    }
    
    # Create start script
    $startScript = @"
# Start Data Governance API Development Server
# Run this script from the project root directory

# Activate virtual environment
& .\venv\Scripts\Activate.ps1

# Start the development server
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
"@
    
    $startScript | Out-File -FilePath (Join-Path $scriptsDir "start-dev-server.ps1") -Encoding UTF8
    
    # Create test script
    $testScript = @"
# Run tests for Data Governance API
# Run this script from the project root directory

# Activate virtual environment
& .\venv\Scripts\Activate.ps1

# Run tests with coverage
pytest --cov=app --cov-report=html --cov-report=term-missing
"@
    
    $testScript | Out-File -FilePath (Join-Path $scriptsDir "run-tests.ps1") -Encoding UTF8
    
    # Create database reset script
    $dbResetScript = @"
# Reset database and run migrations
# Run this script from the project root directory

# Activate virtual environment
& .\venv\Scripts\Activate.ps1

# Drop and recreate databases
psql -U postgres -h localhost -c "DROP DATABASE IF EXISTS data_governance;"
psql -U postgres -h localhost -c "DROP DATABASE IF EXISTS data_governance_test;"
psql -U postgres -h localhost -c "CREATE DATABASE data_governance;"
psql -U postgres -h localhost -c "CREATE DATABASE data_governance_test;"

# Run migrations
alembic upgrade head

# Populate with sample data
python scripts/populate_db.py
"@
    
    $dbResetScript | Out-File -FilePath (Join-Path $scriptsDir "reset-database.ps1") -Encoding UTF8
    
    Write-Success "Utility scripts created in scripts\windows\"
}

# Main execution
function Main {
    Write-Host "🚀 Data Governance API - Windows Development Environment Setup" -ForegroundColor Magenta
    Write-Host "================================================================" -ForegroundColor Magenta
    
    # Check if running as administrator
    if (-not (Test-Administrator)) {
        Write-Error "This script requires administrator privileges. Please run PowerShell as Administrator."
        exit 1
    }
    
    try {
        # Install Chocolatey
        Install-Chocolatey
        
        # Install Python
        if (-not $SkipPython) {
            Install-Python -Version $PythonVersion
        }
        
        # Install Git
        Install-Git
        
        # Install Docker
        if (-not $SkipDocker) {
            Install-Docker
        }
        
        # Install PostgreSQL
        if (-not $SkipDatabase) {
            Install-PostgreSQL
        }
        
        # Setup project directory
        Setup-ProjectDirectory -Path $ProjectPath
        
        # Setup virtual environment
        Setup-VirtualEnvironment -ProjectPath $ProjectPath
        
        # Install dependencies
        Install-Dependencies
        
        # Setup environment variables
        Setup-Environment -ProjectPath $ProjectPath
        
        # Setup database
        if (-not $SkipDatabase) {
            Setup-Database
            Run-Migrations
        }
        
        # Install development tools
        Install-DevTools
        
        # Create utility scripts
        Create-Scripts -ProjectPath $ProjectPath
        
        Write-Host "`n🎉 Setup completed successfully!" -ForegroundColor Green
        Write-Host "================================================================" -ForegroundColor Green
        
        Write-Info "Next steps:"
        Write-Info "1. Edit .env file with your configuration"
        Write-Info "2. Start the development server: .\scripts\windows\start-dev-server.ps1"
        Write-Info "3. Open browser to http://localhost:8000/docs for API documentation"
        Write-Info "4. Run tests: .\scripts\windows\run-tests.ps1"
        
        if (-not $SkipDocker) {
            Write-Warning "Don't forget to start Docker Desktop before using Docker features"
        }
        
    }
    catch {
        Write-Error "Setup failed: $($_.Exception.Message)"
        exit 1
    }
}

# Run main function
Main

