"""
Quality Rule Service for Data Governance API.

Contains business logic for quality rule operations with exemplary business rules.

Author: Carlos Morais <carlos.morais@f1rst.com.br>
Date: July 2025
"""

from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any
from uuid import UUID
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, func

from app.models.quality.quality_rule import QualityRule
from app.models.quality.quality_execution import QualityExecution
from app.schemas.quality.quality_rule import (
    QualityRuleCreate,
    QualityRuleUpdate,
    QualityRuleQueryParams
)
from app.core.exceptions import (
    BusinessRuleViolationError,
    ResourceNotFoundError,
    ValidationError
)


class QualityRuleService:
    """
    Quality Rule Service with exemplary business rules.
    
    Demonstrates comprehensive business logic patterns for
    data governance operations.
    """
    
    def __init__(self, db: Session):
        self.db = db
    
    def create_quality_rule(self, rule_data: QualityRuleCreate, created_by: str) -> QualityRule:
        """
        Create a new quality rule with business validation.
        
        Business Rules:
        1. Rule ID must be unique within the data source
        2. Critical rules require approval
        3. SQL rules must be validated
        4. Threshold values must be reasonable
        5. Execution frequency must align with data refresh
        """
        
        # Business Rule 1: Check for duplicate rule ID in same data source
        existing_rule = self.db.query(QualityRule).filter(
            and_(
                QualityRule.rule_id == rule_data.rule_id,
                QualityRule.data_source == rule_data.data_source,
                QualityRule.ativo == True
            )
        ).first()
        
        if existing_rule:
            raise BusinessRuleViolationError(
                f"Rule ID '{rule_data.rule_id}' already exists for data source '{rule_data.data_source}'"
            )
        
        # Business Rule 2: Critical rules require special validation
        if rule_data.severity == "critical":
            self._validate_critical_rule(rule_data)
        
        # Business Rule 3: Validate SQL rules
        if rule_data.rule_type in ["sql", "custom_sql"]:
            self._validate_sql_rule(rule_data.rule_definition)
        
        # Business Rule 4: Validate threshold values
        if rule_data.threshold_value is not None:
            self._validate_threshold_value(rule_data)
        
        # Business Rule 5: Validate execution frequency
        self._validate_execution_frequency(rule_data)
        
        # Create the rule
        rule = QualityRule(
            rule_id=rule_data.rule_id,
            name=rule_data.name,
            description=rule_data.description,
            rule_type=rule_data.rule_type,
            category=rule_data.category,
            severity=rule_data.severity,
            data_source=rule_data.data_source,
            database_name=rule_data.database_name,
            schema_name=rule_data.schema_name,
            table_name=rule_data.table_name,
            column_name=rule_data.column_name,
            rule_definition=rule_data.rule_definition,
            rule_logic=rule_data.rule_logic,
            threshold_value=rule_data.threshold_value,
            threshold_operator=rule_data.threshold_operator,
            execution_frequency=rule_data.execution_frequency,
            execution_schedule=rule_data.execution_schedule,
            rule_config=rule_data.rule_config,
            proprietario=rule_data.proprietario,
            responsavel_tecnico=rule_data.responsavel_tecnico,
            criado_por=created_by,
            is_enabled=True,
            execution_count=0
        )
        
        self.db.add(rule)
        self.db.commit()
        self.db.refresh(rule)
        
        return rule
    
    def update_quality_rule(self, rule_id: UUID, rule_data: QualityRuleUpdate, updated_by: str) -> QualityRule:
        """
        Update a quality rule with business validation.
        
        Business Rules:
        1. Cannot disable critical rules without approval
        2. Cannot change rule type of executed rules
        3. Threshold changes require impact analysis
        4. Frequency changes affect scheduling
        """
        
        rule = self.get_quality_rule(rule_id)
        
        # Business Rule 1: Critical rules cannot be disabled without approval
        if rule_data.is_enabled is False and rule.severity == "critical":
            if not self._has_approval_for_critical_disable(rule, updated_by):
                raise BusinessRuleViolationError(
                    "Disabling critical rules requires approval from data governance team"
                )
        
        # Business Rule 2: Cannot change rule type if rule has executions
        if rule_data.rule_definition and rule.execution_count > 0:
            if self._is_significant_rule_change(rule.rule_definition, rule_data.rule_definition):
                raise BusinessRuleViolationError(
                    "Cannot make significant changes to rules that have been executed. Create a new version instead."
                )
        
        # Business Rule 3: Threshold changes require impact analysis
        if rule_data.threshold_value and rule_data.threshold_value != rule.threshold_value:
            impact = self._analyze_threshold_impact(rule, rule_data.threshold_value)
            if impact["risk_level"] == "high":
                raise BusinessRuleViolationError(
                    f"Threshold change has high impact: {impact['reason']}. Requires approval."
                )
        
        # Apply updates
        for field, value in rule_data.dict(exclude_unset=True).items():
            setattr(rule, field, value)
        
        rule.atualizado_por = updated_by
        rule.data_atualizacao = datetime.utcnow()
        
        self.db.commit()
        self.db.refresh(rule)
        
        return rule
    
    def execute_quality_rule(self, rule_id: UUID, execution_config: Optional[Dict] = None) -> QualityExecution:
        """
        Execute a quality rule with business logic.
        
        Business Rules:
        1. Rule must be enabled
        2. Check execution frequency limits
        3. Validate execution prerequisites
        4. Handle concurrent executions
        """
        
        rule = self.get_quality_rule(rule_id)
        
        # Business Rule 1: Rule must be enabled
        if not rule.is_enabled:
            raise BusinessRuleViolationError(f"Rule '{rule.name}' is disabled and cannot be executed")
        
        # Business Rule 2: Check execution frequency limits
        if not self._can_execute_now(rule):
            raise BusinessRuleViolationError(
                f"Rule '{rule.name}' cannot be executed yet. Next execution allowed at {rule.next_execution}"
            )
        
        # Business Rule 3: Validate prerequisites
        prerequisites = self._check_execution_prerequisites(rule)
        if not prerequisites["can_execute"]:
            raise BusinessRuleViolationError(f"Prerequisites not met: {prerequisites['reason']}")
        
        # Business Rule 4: Handle concurrent executions
        running_execution = self._get_running_execution(rule)
        if running_execution:
            raise BusinessRuleViolationError(
                f"Rule '{rule.name}' is already being executed (execution_id: {running_execution.execution_id})"
            )
        
        # Create execution record
        execution = QualityExecution(
            execution_id=f"exec_{rule.rule_id}_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}",
            rule_id=rule.id,
            execution_type="manual",
            execution_mode=execution_config.get("mode", "full") if execution_config else "full",
            data_source=rule.data_source,
            dataset_name=rule.database_name,
            table_name=rule.table_name,
            execution_status="pending",
            execution_config=execution_config,
            criado_por="system"
        )
        
        self.db.add(execution)
        
        # Update rule statistics
        rule.execution_count += 1
        rule.last_execution = datetime.utcnow()
        
        self.db.commit()
        self.db.refresh(execution)
        
        return execution
    
    def get_quality_rule(self, rule_id: UUID) -> QualityRule:
        """Get quality rule by ID with business validation."""
        
        rule = self.db.query(QualityRule).filter(
            and_(QualityRule.id == rule_id, QualityRule.ativo == True)
        ).first()
        
        if not rule:
            raise ResourceNotFoundError(f"Quality rule with ID {rule_id} not found")
        
        return rule
    
    def list_quality_rules(self, params: QualityRuleQueryParams) -> List[QualityRule]:
        """List quality rules with business filtering."""
        
        query = self.db.query(QualityRule).filter(QualityRule.ativo == True)
        
        # Apply business filters
        if params.rule_type:
            query = query.filter(QualityRule.rule_type == params.rule_type)
        
        if params.severity:
            query = query.filter(QualityRule.severity == params.severity)
        
        if params.data_source:
            query = query.filter(QualityRule.data_source == params.data_source)
        
        if params.is_enabled is not None:
            query = query.filter(QualityRule.is_enabled == params.is_enabled)
        
        # Business logic: Prioritize critical rules
        query = query.order_by(
            func.case(
                (QualityRule.severity == "critical", 1),
                (QualityRule.severity == "high", 2),
                (QualityRule.severity == "medium", 3),
                else_=4
            ),
            QualityRule.name
        )
        
        if params.skip:
            query = query.offset(params.skip)
        
        if params.limit:
            query = query.limit(params.limit)
        
        return query.all()
    
    def get_rule_health_score(self, rule_id: UUID) -> Dict[str, Any]:
        """
        Calculate rule health score based on business metrics.
        
        Business Logic:
        - Success rate weight: 40%
        - Execution frequency adherence: 30%
        - Data freshness impact: 20%
        - Error trend: 10%
        """
        
        rule = self.get_quality_rule(rule_id)
        
        # Get recent executions (last 30 days)
        recent_executions = self.db.query(QualityExecution).filter(
            and_(
                QualityExecution.rule_id == rule.id,
                QualityExecution.started_at >= datetime.utcnow() - timedelta(days=30)
            )
        ).all()
        
        if not recent_executions:
            return {
                "health_score": 0.0,
                "status": "no_data",
                "metrics": {},
                "recommendations": ["Execute rule to establish baseline metrics"]
            }
        
        # Calculate metrics
        success_rate = self._calculate_success_rate(recent_executions)
        frequency_adherence = self._calculate_frequency_adherence(rule, recent_executions)
        data_freshness = self._calculate_data_freshness_impact(rule)
        error_trend = self._calculate_error_trend(recent_executions)
        
        # Calculate weighted health score
        health_score = (
            success_rate * 0.4 +
            frequency_adherence * 0.3 +
            data_freshness * 0.2 +
            error_trend * 0.1
        )
        
        # Determine status
        if health_score >= 0.9:
            status = "excellent"
        elif health_score >= 0.7:
            status = "good"
        elif health_score >= 0.5:
            status = "fair"
        else:
            status = "poor"
        
        # Generate recommendations
        recommendations = self._generate_health_recommendations(
            rule, success_rate, frequency_adherence, data_freshness, error_trend
        )
        
        return {
            "health_score": round(health_score, 3),
            "status": status,
            "metrics": {
                "success_rate": round(success_rate, 3),
                "frequency_adherence": round(frequency_adherence, 3),
                "data_freshness": round(data_freshness, 3),
                "error_trend": round(error_trend, 3)
            },
            "recommendations": recommendations
        }
    
    # Private helper methods for business logic
    
    def _validate_critical_rule(self, rule_data: QualityRuleCreate):
        """Validate critical rule requirements."""
        
        if not rule_data.proprietario:
            raise ValidationError("Critical rules must have a business owner")
        
        if not rule_data.responsavel_tecnico:
            raise ValidationError("Critical rules must have a technical owner")
        
        if not rule_data.rule_logic:
            raise ValidationError("Critical rules must have documented business logic")
    
    def _validate_sql_rule(self, sql: str):
        """Validate SQL rule definition."""
        
        # Basic SQL validation
        sql_lower = sql.lower().strip()
        
        # Check for dangerous operations
        dangerous_keywords = ["drop", "delete", "truncate", "alter", "create", "insert", "update"]
        for keyword in dangerous_keywords:
            if keyword in sql_lower:
                raise ValidationError(f"SQL rules cannot contain '{keyword}' operations")
        
        # Must be a SELECT statement
        if not sql_lower.startswith("select"):
            raise ValidationError("SQL rules must be SELECT statements")
    
    def _validate_threshold_value(self, rule_data: QualityRuleCreate):
        """Validate threshold values based on rule type."""
        
        if rule_data.rule_type == "completeness" and not (0 <= rule_data.threshold_value <= 1):
            raise ValidationError("Completeness threshold must be between 0 and 1")
        
        if rule_data.rule_type == "uniqueness" and not (0 <= rule_data.threshold_value <= 1):
            raise ValidationError("Uniqueness threshold must be between 0 and 1")
        
        if rule_data.rule_type == "validity" and not (0 <= rule_data.threshold_value <= 1):
            raise ValidationError("Validity threshold must be between 0 and 1")
    
    def _validate_execution_frequency(self, rule_data: QualityRuleCreate):
        """Validate execution frequency against business rules."""
        
        # Critical rules should run at least daily
        if rule_data.severity == "critical" and rule_data.execution_frequency not in ["hourly", "daily"]:
            raise ValidationError("Critical rules must execute at least daily")
        
        # High volume tables should not run too frequently
        if rule_data.execution_frequency == "hourly":
            # This would typically check table size/volume from metadata
            pass  # Placeholder for volume check
    
    def _has_approval_for_critical_disable(self, rule: QualityRule, user: str) -> bool:
        """Check if user has approval to disable critical rules."""
        # This would integrate with approval workflow system
        # For demo purposes, assume certain users have approval
        approved_users = ["admin", "data_governance_lead", "dpo"]
        return user in approved_users
    
    def _is_significant_rule_change(self, old_definition: str, new_definition: str) -> bool:
        """Determine if rule change is significant."""
        # Simple heuristic - more than 50% change in content
        if not old_definition or not new_definition:
            return True
        
        # Calculate similarity (simplified)
        old_words = set(old_definition.lower().split())
        new_words = set(new_definition.lower().split())
        
        if len(old_words) == 0:
            return True
        
        similarity = len(old_words.intersection(new_words)) / len(old_words.union(new_words))
        return similarity < 0.5
    
    def _analyze_threshold_impact(self, rule: QualityRule, new_threshold: float) -> Dict[str, Any]:
        """Analyze impact of threshold changes."""
        
        if not rule.threshold_value:
            return {"risk_level": "low", "reason": "No previous threshold to compare"}
        
        change_percent = abs(new_threshold - rule.threshold_value) / rule.threshold_value
        
        if change_percent > 0.5:  # More than 50% change
            return {
                "risk_level": "high",
                "reason": f"Threshold change of {change_percent:.1%} may significantly affect rule behavior"
            }
        elif change_percent > 0.2:  # More than 20% change
            return {
                "risk_level": "medium",
                "reason": f"Moderate threshold change of {change_percent:.1%}"
            }
        else:
            return {
                "risk_level": "low",
                "reason": f"Minor threshold change of {change_percent:.1%}"
            }
    
    def _can_execute_now(self, rule: QualityRule) -> bool:
        """Check if rule can be executed based on frequency limits."""
        
        if not rule.last_execution:
            return True
        
        frequency_map = {
            "hourly": timedelta(hours=1),
            "daily": timedelta(days=1),
            "weekly": timedelta(weeks=1),
            "monthly": timedelta(days=30)
        }
        
        min_interval = frequency_map.get(rule.execution_frequency, timedelta(hours=1))
        return datetime.utcnow() - rule.last_execution >= min_interval
    
    def _check_execution_prerequisites(self, rule: QualityRule) -> Dict[str, Any]:
        """Check if all prerequisites for execution are met."""
        
        # Check if data source is available
        # This would integrate with data source monitoring
        
        # Check if table exists and is accessible
        # This would integrate with metadata catalog
        
        # For demo purposes, assume prerequisites are met
        return {"can_execute": True, "reason": "All prerequisites met"}
    
    def _get_running_execution(self, rule: QualityRule) -> Optional[QualityExecution]:
        """Get currently running execution for the rule."""
        
        return self.db.query(QualityExecution).filter(
            and_(
                QualityExecution.rule_id == rule.id,
                QualityExecution.execution_status.in_(["pending", "running"])
            )
        ).first()
    
    def _calculate_success_rate(self, executions: List[QualityExecution]) -> float:
        """Calculate success rate from executions."""
        
        if not executions:
            return 0.0
        
        successful = sum(1 for e in executions if e.execution_status == "completed" and not e.error_message)
        return successful / len(executions)
    
    def _calculate_frequency_adherence(self, rule: QualityRule, executions: List[QualityExecution]) -> float:
        """Calculate how well the rule adheres to its execution frequency."""
        
        # Simplified calculation - in practice would be more sophisticated
        expected_executions = self._calculate_expected_executions(rule)
        actual_executions = len(executions)
        
        if expected_executions == 0:
            return 1.0
        
        adherence = min(actual_executions / expected_executions, 1.0)
        return adherence
    
    def _calculate_expected_executions(self, rule: QualityRule) -> int:
        """Calculate expected number of executions in the last 30 days."""
        
        frequency_map = {
            "hourly": 24 * 30,  # 720 executions
            "daily": 30,        # 30 executions
            "weekly": 4,        # 4 executions
            "monthly": 1        # 1 execution
        }
        
        return frequency_map.get(rule.execution_frequency, 30)
    
    def _calculate_data_freshness_impact(self, rule: QualityRule) -> float:
        """Calculate impact of data freshness on rule effectiveness."""
        
        # This would integrate with data freshness monitoring
        # For demo purposes, return a reasonable score
        return 0.8
    
    def _calculate_error_trend(self, executions: List[QualityExecution]) -> float:
        """Calculate error trend (improving = higher score)."""
        
        if len(executions) < 2:
            return 0.5
        
        # Sort by execution time
        sorted_executions = sorted(executions, key=lambda x: x.started_at or datetime.min)
        
        # Calculate error rate for first and second half
        mid_point = len(sorted_executions) // 2
        first_half = sorted_executions[:mid_point]
        second_half = sorted_executions[mid_point:]
        
        first_error_rate = sum(1 for e in first_half if e.error_message) / len(first_half)
        second_error_rate = sum(1 for e in second_half if e.error_message) / len(second_half)
        
        # If error rate is decreasing, trend is good
        if first_error_rate > second_error_rate:
            return 0.8  # Improving
        elif first_error_rate == second_error_rate:
            return 0.6  # Stable
        else:
            return 0.3  # Degrading
    
    def _generate_health_recommendations(self, rule: QualityRule, success_rate: float, 
                                       frequency_adherence: float, data_freshness: float, 
                                       error_trend: float) -> List[str]:
        """Generate health improvement recommendations."""
        
        recommendations = []
        
        if success_rate < 0.8:
            recommendations.append("Review rule definition - low success rate indicates potential issues")
        
        if frequency_adherence < 0.7:
            recommendations.append("Adjust execution schedule or investigate execution failures")
        
        if data_freshness < 0.6:
            recommendations.append("Check data source freshness - stale data affects rule effectiveness")
        
        if error_trend < 0.5:
            recommendations.append("Investigate increasing error rate - may indicate data quality degradation")
        
        if rule.severity == "critical" and success_rate < 0.95:
            recommendations.append("Critical rule requires immediate attention due to low success rate")
        
        if not recommendations:
            recommendations.append("Rule is performing well - continue monitoring")
        
        return recommendations

