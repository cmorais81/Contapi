# Data Governance API

[![Python](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/downloads/)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.104+-green.svg)](https://fastapi.tiangolo.com/)
[![License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)
[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)
[![Tests](https://img.shields.io/badge/tests-passing-green.svg)](tests/)
[![Coverage](https://img.shields.io/badge/coverage-90%25+-green.svg)](htmlcov/)

API completa para governança de dados baseada em contratos, desenvolvida por Carlos Morais com integração Unity Catalog e suporte a external lineage.

## 🚀 Características Principais

- **Contratos de Dados Versionados**: Gestão completa de contratos com múltiplas versões ativas
- **External Lineage**: Integração com Tableau, PowerBI, Salesforce e outros sistemas externos
- **Unity Catalog Integration**: Sincronização automática com Azure Databricks Unity Catalog
- **Qualidade de Dados**: Monitoramento automático e regras de qualidade configuráveis
- **RBAC/ABAC**: Sistema granular de permissões e controle de acesso
- **OpenAPI 3.0+**: Documentação Swagger automática e padrões REST
- **Arquitetura Limpa**: Princípios SOLID e separação de responsabilidades
- **Testes Abrangentes**: Cobertura >90% com testes unitários, integração e E2E
- **Deployment Automatizado**: Scripts para Windows PowerShell e Azure AKS

## 📋 Índice

- [Instalação](#-instalação)
- [Configuração](#-configuração)
- [Uso](#-uso)
- [API Documentation](#-api-documentation)
- [Desenvolvimento](#-desenvolvimento)
- [Testes](#-testes)
- [Deployment](#-deployment)
- [Monitoramento](#-monitoramento)
- [Contribuição](#-contribuição)
- [Licença](#-licença)

## 🛠 Instalação

### Pré-requisitos

- Python 3.11+
- PostgreSQL 15+
- Docker (opcional)
- Azure CLI (para deployment AKS)

### Instalação Local

```bash
# Clonar repositório
git clone https://github.com/company/data-governance-api.git
cd data-governance-api

# Criar ambiente virtual
python -m venv venv
source venv/bin/activate  # Linux/Mac
# ou
venv\Scripts\activate     # Windows

# Instalar dependências
make install-dev

# Configurar ambiente
cp .env.example .env
# Editar .env com suas configurações

# Setup do banco de dados
make db-upgrade
make db-seed

# Executar aplicação
make run
```

### Instalação com Docker

```bash
# Subir ambiente completo
make docker-compose-up

# Verificar status
docker-compose ps
```

## ⚙️ Configuração

### Variáveis de Ambiente

Copie `.env.example` para `.env` e configure:

```bash
# Database
DATABASE_URL="postgresql+asyncpg://user:pass@localhost:5432/data_governance"

# Security
SECRET_KEY="your-super-secret-key"
ACCESS_TOKEN_EXPIRE_MINUTES=30

# Unity Catalog
UNITY_CATALOG_URL="https://your-databricks-workspace.cloud.databricks.com"
UNITY_CATALOG_TOKEN="your-databricks-token"

# External Systems
TABLEAU_SERVER_URL="https://your-tableau-server.com"
POWERBI_TENANT_ID="your-powerbi-tenant-id"
```

### Configuração do Banco de Dados

```bash
# Aplicar migrações
make db-upgrade

# Popular com dados iniciais
make db-seed

# Criar usuário admin
make create-user EMAIL=admin@company.com
```

## 🎯 Uso

### Executar Aplicação

```bash
# Desenvolvimento
make run-dev

# Produção
make run-prod
```

A API estará disponível em:
- **API**: http://localhost:8000
- **Swagger UI**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc
- **Health Check**: http://localhost:8000/health

### Comandos Principais

```bash
# Desenvolvimento
make dev-setup          # Setup completo para desenvolvimento
make test               # Executar todos os testes
make quality            # Verificações de qualidade
make docs               # Gerar documentação

# Dados
make generate-mock-data # Gerar dados mock
make import-unity-catalog # Importar do Unity Catalog
make backup             # Backup do banco
make restore            # Restaurar backup

# Deployment
make deploy-local       # Deploy local (Windows)
make deploy-azure       # Deploy Azure AKS
```

## 📚 API Documentation

### Endpoints Principais

#### Contratos de Dados
```http
GET    /api/v1/contracts              # Listar contratos
POST   /api/v1/contracts              # Criar contrato
GET    /api/v1/contracts/{id}         # Obter contrato
PUT    /api/v1/contracts/{id}         # Atualizar contrato
DELETE /api/v1/contracts/{id}         # Deletar contrato
```

#### External Lineage
```http
GET    /api/v1/lineage/external       # Listar objetos externos
POST   /api/v1/lineage/external       # Criar objeto externo
POST   /api/v1/lineage/relationships  # Criar relacionamento
GET    /api/v1/lineage/graph/{id}     # Visualizar grafo de linhagem
```

#### Qualidade de Dados
```http
GET    /api/v1/quality/rules          # Listar regras de qualidade
POST   /api/v1/quality/rules          # Criar regra
POST   /api/v1/quality/execute        # Executar verificação
GET    /api/v1/quality/results        # Resultados de execução
```

### Autenticação

```bash
# Obter token
curl -X POST "http://localhost:8000/api/v1/auth/login" \
     -H "Content-Type: application/json" \
     -d '{"username": "admin", "password": "password"}'

# Usar token
curl -H "Authorization: Bearer YOUR_TOKEN" \
     "http://localhost:8000/api/v1/contracts"
```

### Exemplos de Uso

#### Criar Contrato de Dados

```python
import httpx

# Criar contrato
contract_data = {
    "contract_name": "customer_data_contract",
    "contract_description": "Contrato para dados de clientes",
    "business_domain": "sales",
    "unity_catalog_name": "main_catalog",
    "unity_catalog_schema": "customer_schema",
    "data_format": "delta",
    "monitoring_enabled": True
}

response = httpx.post(
    "http://localhost:8000/api/v1/contracts",
    json=contract_data,
    headers={"Authorization": f"Bearer {token}"}
)
```

#### Configurar External Lineage

```python
# Criar objeto externo (Tableau Dashboard)
external_object = {
    "object_name": "sales_dashboard",
    "system_type": "tableau",
    "entity_type": "dashboard",
    "external_url": "https://tableau.company.com/views/sales",
    "custom_properties": {
        "workbook": "Sales Analytics",
        "project": "Finance"
    }
}

response = httpx.post(
    "http://localhost:8000/api/v1/lineage/external",
    json=external_object,
    headers={"Authorization": f"Bearer {token}"}
)

# Criar relacionamento de linhagem
relationship = {
    "source_type": "internal",
    "source_object_id": "customer_table_id",
    "target_type": "external", 
    "target_object_id": external_object["id"],
    "relationship_type": "downstream",
    "transformation_description": "Agregação de vendas por cliente"
}

httpx.post(
    "http://localhost:8000/api/v1/lineage/relationships",
    json=relationship,
    headers={"Authorization": f"Bearer {token}"}
)
```

## 🔧 Desenvolvimento

### Estrutura do Projeto

```
data-governance-api/
├── app/                    # Código da aplicação
│   ├── api/               # Endpoints da API
│   ├── core/              # Configurações centrais
│   ├── models/            # Modelos SQLAlchemy
│   ├── schemas/           # Schemas Pydantic
│   ├── services/          # Lógica de negócio
│   ├── repositories/      # Acesso a dados
│   └── utils/             # Utilitários
├── tests/                 # Testes
├── docs/                  # Documentação
├── scripts/               # Scripts de automação
├── docker/                # Configurações Docker
├── k8s/                   # Manifests Kubernetes
└── monitoring/            # Configurações de monitoramento
```

### Padrões de Código

- **Arquitetura**: Clean Architecture com separação de camadas
- **Formatação**: Black + isort
- **Linting**: flake8 + mypy
- **Testes**: pytest com >90% cobertura
- **Documentação**: Docstrings + Sphinx

### Workflow de Desenvolvimento

```bash
# 1. Criar branch
git checkout -b feature/nova-funcionalidade

# 2. Desenvolver
make dev-setup
# ... código ...

# 3. Verificar qualidade
make quality
make test

# 4. Commit
git add .
git commit -m "feat: adicionar nova funcionalidade"

# 5. Push e PR
git push origin feature/nova-funcionalidade
```

## 🧪 Testes

### Executar Testes

```bash
# Todos os testes
make test

# Por tipo
make test-unit           # Testes unitários
make test-integration    # Testes de integração
make test-e2e           # Testes end-to-end

# Com cobertura
make test-coverage

# Modo watch
make test-watch
```

### Estrutura de Testes

- **Unit Tests**: Testam componentes isolados
- **Integration Tests**: Testam integração entre componentes
- **E2E Tests**: Testam fluxos completos da API
- **Performance Tests**: Testes de carga e benchmark

### Exemplo de Teste

```python
# tests/unit/test_services/test_contracts/test_data_contract_service.py
import pytest
from app.services.contracts.data_contract_service import DataContractService

@pytest.mark.asyncio
async def test_create_contract(db_session, contract_factory):
    service = DataContractService(db_session)
    contract_data = contract_factory.build()
    
    result = await service.create_contract(contract_data, user_id="test-user")
    
    assert result.contract_name == contract_data.contract_name
    assert result.contract_status == "draft"
```

## 🚀 Deployment

### Windows PowerShell (Local)

```powershell
# Setup ambiente local
.\scripts\windows\setup-local-env.ps1

# Iniciar API
.\scripts\windows\start-api.ps1

# Popular dados
.\scripts\windows\populate-data.ps1
```

### Azure AKS

```bash
# Deploy no AKS
make deploy-azure

# Verificar status
kubectl get pods -n data-governance

# Port forward para teste
make k8s-port-forward
```

### Docker

```bash
# Build e run
make docker-build
make docker-run

# Com compose
make docker-compose-up
```

### Helm

```bash
# Instalar
make helm-install

# Atualizar
make helm-upgrade

# Configurar valores
helm install data-governance-api helm/ \
  --set image.tag=v1.0.0 \
  --set database.host=postgres.company.com
```

## 📊 Monitoramento

### Métricas

- **Prometheus**: Métricas da aplicação
- **Grafana**: Dashboards e visualizações
- **Health Checks**: Verificações de saúde

```bash
# Subir stack de monitoramento
make monitoring

# Acessar dashboards
# Grafana: http://localhost:3000
# Prometheus: http://localhost:9090
```

### Logs

```bash
# Ver logs da aplicação
docker-compose logs -f api

# Logs estruturados em JSON
tail -f logs/app.log | jq
```

### Alertas

- Configurações no `monitoring/alerts/`
- Integração com Slack/Teams
- Alertas de qualidade de dados
- Monitoramento de SLA

## 🤝 Contribuição

### Como Contribuir

1. Fork o projeto
2. Crie uma branch (`git checkout -b feature/AmazingFeature`)
3. Commit suas mudanças (`git commit -m 'Add some AmazingFeature'`)
4. Push para a branch (`git push origin feature/AmazingFeature`)
5. Abra um Pull Request

### Diretrizes

- Siga os padrões de código estabelecidos
- Adicione testes para novas funcionalidades
- Atualize a documentação quando necessário
- Mantenha cobertura de testes >90%

### Reportar Bugs

Use o [GitHub Issues](https://github.com/company/data-governance-api/issues) para reportar bugs.

## 📄 Licença

Este projeto está licenciado sob a Licença MIT - veja o arquivo [LICENSE](LICENSE) para detalhes.

## 📞 Suporte

- **Documentação**: [docs/](docs/)
- **Issues**: [GitHub Issues](https://github.com/company/data-governance-api/issues)
- **Email**: data-governance@company.com
- **Slack**: #data-governance

## 🙏 Agradecimentos

- [FastAPI](https://fastapi.tiangolo.com/) - Framework web moderno
- [SQLAlchemy](https://www.sqlalchemy.org/) - ORM Python
- [Pydantic](https://pydantic-docs.helpmanual.io/) - Validação de dados
- [Unity Catalog](https://docs.databricks.com/data-governance/unity-catalog/) - Governança de dados

---

**Data Governance API** - Transformando dados em valor através de governança inteligente 🚀

