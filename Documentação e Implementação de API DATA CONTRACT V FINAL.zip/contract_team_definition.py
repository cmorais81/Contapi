"""
Contract Team Definition model.
"""

from sqlalchemy import Column, ForeignKey, String, Text
from sqlalchemy.dialects.postgresql import UUID as PostgresUUID
from sqlalchemy.orm import relationship

from app.models.base import BaseModel


class ContractTeamDefinition(BaseModel):
    """
    Contract Team Definition model.
    
    Team definitions and responsibilities.
    """

    __tablename__ = "contract_team_definitions"

    # Foreign key to contract
    contract_id = Column(
        PostgresUUID(as_uuid=True),
        ForeignKey("data_contracts.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
        doc="Reference to contract"
    )

    # Role definition
    role_name = Column(
        String(255),
        nullable=False,
        doc="Role/function name"
    )

    role_description = Column(
        Text,
        doc="Description of responsibilities"
    )

    contact_info = Column(
        Text,
        doc="Contact information"
    )

    escalation_path = Column(
        Text,
        doc="Escalation path"
    )

    availability_sla = Column(
        Text,
        doc="Team availability SLA"
    )

    # Relationships
    contract = relationship(
        "DataContract",
        back_populates="team_definitions"
    )

    def __repr__(self) -> str:
        return f"<ContractTeamDefinition(role={self.role_name})>"

