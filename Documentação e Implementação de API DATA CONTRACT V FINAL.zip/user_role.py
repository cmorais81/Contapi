"""
User Role model.
"""

from sqlalchemy import Column, DateTime, ForeignKey, String
from sqlalchemy.dialects.postgresql import UUID as PostgresUUID
from sqlalchemy.orm import relationship

from app.models.base import BaseModel


class UserRole(BaseModel):
    """
    User Role model.
    
    Many-to-many relationship between users and roles.
    """

    __tablename__ = "user_roles"

    # Foreign keys
    user_id = Column(
        PostgresUUID(as_uuid=True),
        ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
        doc="Reference to user"
    )

    role_id = Column(
        PostgresUUID(as_uuid=True),
        ForeignKey("roles.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
        doc="Reference to role"
    )

    # Assignment details
    assigned_by = Column(
        String(255),
        doc="User who assigned the role"
    )

    assigned_at = Column(
        DateTime(timezone=True),
        doc="Role assignment timestamp"
    )

    expires_at = Column(
        DateTime(timezone=True),
        doc="Role expiration timestamp"
    )

    # Context
    assignment_reason = Column(
        String(500),
        doc="Reason for role assignment"
    )

    # Relationships
    user = relationship(
        "User",
        back_populates="user_roles"
    )

    role = relationship(
        "Role",
        back_populates="user_roles"
    )

    def __repr__(self) -> str:
        return f"<UserRole(user_id={self.user_id}, role_id={self.role_id})>"

