"""
Custom exceptions for Data Governance API.

Desenvolvido por Carlos Morais (carlos.morais@f1rst.com.br)
Julho 2025
"""

from typing import Any, Dict, Optional


class DataGovernanceException(Exception):
    """Base exception for Data Governance API."""
    
    def __init__(
        self,
        message: str,
        error_code: str = None,
        details: Dict[str, Any] = None
    ):
        self.message = message
        self.error_code = error_code
        self.details = details or {}
        super().__init__(self.message)


class ValidationError(DataGovernanceException):
    """Validation error."""
    pass


class NotFoundError(DataGovernanceException):
    """Resource not found error."""
    pass


class ConflictError(DataGovernanceException):
    """Resource conflict error."""
    pass


class AuthenticationError(DataGovernanceException):
    """Authentication error."""
    pass


class AuthorizationError(DataGovernanceException):
    """Authorization error."""
    pass


class ExternalServiceError(DataGovernanceException):
    """External service error."""
    pass


class DataQualityError(DataGovernanceException):
    """Data quality error."""
    pass


class PrivacyComplianceError(DataGovernanceException):
    """Privacy compliance error."""
    pass


class LineageError(DataGovernanceException):
    """Data lineage error."""
    pass


class ContractError(DataGovernanceException):
    """Data contract error."""
    pass

