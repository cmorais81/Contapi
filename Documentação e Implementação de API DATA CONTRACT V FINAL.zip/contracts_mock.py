"""
Mock data generation for Data Contracts domain.

Generates realistic test data for data contracts and contract versions.

Author: Carlos Morais <carlos.morais@f1rst.com.br>
Date: July 2025
"""

import uuid
from datetime import datetime, timedelta
from typing import List, Dict, Any
from faker import Faker
import random

fake = Faker('pt_BR')


def generate_data_contracts(count: int = 20) -> List[Dict[str, Any]]:
    """Generate mock data contracts."""
    
    contracts = []
    domains = ["finance", "marketing", "sales", "operations", "hr", "customer", "product"]
    criticalities = ["low", "medium", "high", "critical"]
    statuses = ["draft", "review", "approved", "active", "deprecated"]
    security_classifications = ["public", "internal", "confidential", "restricted"]
    update_frequencies = ["real-time", "hourly", "daily", "weekly", "monthly"]
    
    systems = [
        "salesforce", "sap", "oracle_erp", "snowflake", "databricks",
        "tableau", "powerbi", "kafka", "airflow", "dbt"
    ]
    
    for i in range(count):
        contract_id = f"DC-{fake.random_int(1000, 9999)}"
        domain = random.choice(domains)
        producer = random.choice(systems)
        consumers = random.sample(systems, random.randint(1, 3))
        
        # Generate realistic schema
        schema_definition = generate_schema_definition(domain)
        
        # Generate SLA requirements
        sla_requirements = {
            "availability": round(random.uniform(95.0, 99.9), 2),
            "response_time_ms": random.randint(100, 5000),
            "throughput_rps": random.randint(10, 1000),
            "data_freshness_minutes": random.randint(5, 1440)
        }
        
        # Generate quality requirements
        quality_requirements = {
            "completeness_threshold": round(random.uniform(0.85, 0.99), 2),
            "accuracy_threshold": round(random.uniform(0.90, 0.99), 2),
            "uniqueness_threshold": round(random.uniform(0.95, 1.0), 2),
            "timeliness_threshold": round(random.uniform(0.80, 0.95), 2)
        }
        
        contract = {
            "id": str(uuid.uuid4()),
            "contract_id": contract_id,
            "name": f"{domain.title()} Data Contract - {fake.company()}",
            "description": fake.text(max_nb_chars=500),
            "version": f"{random.randint(1, 5)}.{random.randint(0, 9)}.{random.randint(0, 9)}",
            "domain": domain,
            "data_product_name": f"{domain}_{fake.word()}_{fake.word()}",
            "producer_system": producer,
            "consumer_systems": consumers,
            "schema_definition": schema_definition,
            "sla_requirements": sla_requirements,
            "quality_requirements": quality_requirements,
            "security_classification": random.choice(security_classifications),
            "retention_policy": f"{random.randint(1, 7)} years",
            "update_frequency": random.choice(update_frequencies),
            "criticality": random.choice(criticalities),
            "business_purpose": fake.text(max_nb_chars=300),
            "contact_info": {
                "business_owner": fake.name(),
                "technical_owner": fake.name(),
                "email": fake.email(),
                "slack_channel": f"#{domain}-data"
            },
            "tags": random.sample([
                "pii", "financial", "customer", "operational", "analytics",
                "real-time", "batch", "streaming", "gdpr", "lgpd"
            ], random.randint(2, 5)),
            "proprietario": fake.name(),
            "responsavel_tecnico": fake.name(),
            "status": random.choice(statuses),
            "approval_status": "approved" if random.random() > 0.2 else "pending",
            "activated_at": fake.date_time_between(start_date='-1y', end_date='now') if random.random() > 0.3 else None,
            "activated_by": fake.name() if random.random() > 0.3 else None,
            "ativo": True,
            "criado_por": fake.name(),
            "atualizado_por": fake.name(),
            "data_criacao": fake.date_time_between(start_date='-2y', end_date='-1m'),
            "data_atualizacao": fake.date_time_between(start_date='-1m', end_date='now')
        }
        
        contracts.append(contract)
    
    return contracts


def generate_contract_versions(contracts: List[Dict], versions_per_contract: int = 3) -> List[Dict[str, Any]]:
    """Generate mock contract versions."""
    
    versions = []
    
    for contract in contracts:
        for version_num in range(1, versions_per_contract + 1):
            version = {
                "id": str(uuid.uuid4()),
                "contract_id": contract["id"],
                "version_number": f"{version_num}.0.0",
                "schema_definition": contract["schema_definition"],
                "sla_requirements": contract["sla_requirements"],
                "quality_requirements": contract["quality_requirements"],
                "change_notes": fake.text(max_nb_chars=200),
                "is_current": version_num == versions_per_contract,
                "ativo": True,
                "criado_por": fake.name(),
                "data_criacao": fake.date_time_between(
                    start_date=contract["data_criacao"],
                    end_date=contract["data_atualizacao"]
                )
            }
            versions.append(version)
    
    return versions


def generate_schema_definition(domain: str) -> Dict[str, Any]:
    """Generate realistic schema definition based on domain."""
    
    base_fields = [
        {"name": "id", "type": "string", "required": True, "description": "Unique identifier"},
        {"name": "created_at", "type": "timestamp", "required": True, "description": "Creation timestamp"},
        {"name": "updated_at", "type": "timestamp", "required": True, "description": "Last update timestamp"}
    ]
    
    domain_fields = {
        "finance": [
            {"name": "transaction_id", "type": "string", "required": True, "description": "Transaction identifier"},
            {"name": "amount", "type": "decimal", "required": True, "description": "Transaction amount"},
            {"name": "currency", "type": "string", "required": True, "description": "Currency code"},
            {"name": "account_id", "type": "string", "required": True, "description": "Account identifier"},
            {"name": "transaction_type", "type": "string", "required": True, "description": "Type of transaction"},
            {"name": "status", "type": "string", "required": True, "description": "Transaction status"}
        ],
        "marketing": [
            {"name": "campaign_id", "type": "string", "required": True, "description": "Campaign identifier"},
            {"name": "customer_id", "type": "string", "required": True, "description": "Customer identifier"},
            {"name": "channel", "type": "string", "required": True, "description": "Marketing channel"},
            {"name": "impression_count", "type": "integer", "required": False, "description": "Number of impressions"},
            {"name": "click_count", "type": "integer", "required": False, "description": "Number of clicks"},
            {"name": "conversion_value", "type": "decimal", "required": False, "description": "Conversion value"}
        ],
        "sales": [
            {"name": "order_id", "type": "string", "required": True, "description": "Order identifier"},
            {"name": "customer_id", "type": "string", "required": True, "description": "Customer identifier"},
            {"name": "product_id", "type": "string", "required": True, "description": "Product identifier"},
            {"name": "quantity", "type": "integer", "required": True, "description": "Quantity ordered"},
            {"name": "unit_price", "type": "decimal", "required": True, "description": "Unit price"},
            {"name": "total_amount", "type": "decimal", "required": True, "description": "Total order amount"}
        ],
        "customer": [
            {"name": "customer_id", "type": "string", "required": True, "description": "Customer identifier"},
            {"name": "email", "type": "string", "required": True, "description": "Customer email", "pii": True},
            {"name": "phone", "type": "string", "required": False, "description": "Customer phone", "pii": True},
            {"name": "first_name", "type": "string", "required": True, "description": "First name", "pii": True},
            {"name": "last_name", "type": "string", "required": True, "description": "Last name", "pii": True},
            {"name": "birth_date", "type": "date", "required": False, "description": "Birth date", "pii": True}
        ]
    }
    
    fields = base_fields + domain_fields.get(domain, [
        {"name": "data_field_1", "type": "string", "required": True, "description": "Generic data field 1"},
        {"name": "data_field_2", "type": "integer", "required": False, "description": "Generic data field 2"},
        {"name": "data_field_3", "type": "decimal", "required": False, "description": "Generic data field 3"}
    ])
    
    return {
        "type": "object",
        "fields": fields,
        "version": "1.0",
        "format": "json"
    }


def generate_mock_contracts_sql() -> str:
    """Generate SQL INSERT statements for mock contracts."""
    
    contracts = generate_data_contracts(20)
    versions = generate_contract_versions(contracts, 2)
    
    sql_statements = []
    
    # Generate contract INSERT statements
    sql_statements.append("-- Data Contracts Mock Data")
    sql_statements.append("INSERT INTO data_contracts (")
    sql_statements.append("    id, contract_id, name, description, version, domain,")
    sql_statements.append("    data_product_name, producer_system, consumer_systems,")
    sql_statements.append("    schema_definition, sla_requirements, quality_requirements,")
    sql_statements.append("    security_classification, retention_policy, update_frequency,")
    sql_statements.append("    criticality, business_purpose, contact_info, tags,")
    sql_statements.append("    proprietario, responsavel_tecnico, status, approval_status,")
    sql_statements.append("    activated_at, activated_by, ativo, criado_por, atualizado_por,")
    sql_statements.append("    data_criacao, data_atualizacao")
    sql_statements.append(") VALUES")
    
    contract_values = []
    for contract in contracts:
        values = f"""(
    '{contract["id"]}', '{contract["contract_id"]}', '{contract["name"]}',
    '{contract["description"]}', '{contract["version"]}', '{contract["domain"]}',
    '{contract["data_product_name"]}', '{contract["producer_system"]}',
    '{contract["consumer_systems"]}'::jsonb,
    '{str(contract["schema_definition"]).replace("'", "''")}'::jsonb,
    '{str(contract["sla_requirements"]).replace("'", "''")}'::jsonb,
    '{str(contract["quality_requirements"]).replace("'", "''")}'::jsonb,
    '{contract["security_classification"]}', '{contract["retention_policy"]}',
    '{contract["update_frequency"]}', '{contract["criticality"]}',
    '{contract["business_purpose"]}',
    '{str(contract["contact_info"]).replace("'", "''")}'::jsonb,
    '{contract["tags"]}'::jsonb,
    '{contract["proprietario"]}', '{contract["responsavel_tecnico"]}',
    '{contract["status"]}', '{contract["approval_status"]}',
    {'NULL' if not contract["activated_at"] else f"'{contract['activated_at']}'"},
    {'NULL' if not contract["activated_by"] else f"'{contract['activated_by']}'"},
    {contract["ativo"]}, '{contract["criado_por"]}', '{contract["atualizado_por"]}',
    '{contract["data_criacao"]}', '{contract["data_atualizacao"]}'
)"""
        contract_values.append(values)
    
    sql_statements.append(",\n".join(contract_values))
    sql_statements.append(";\n")
    
    # Generate contract versions INSERT statements
    sql_statements.append("-- Contract Versions Mock Data")
    sql_statements.append("INSERT INTO contract_versions (")
    sql_statements.append("    id, contract_id, version_number, schema_definition,")
    sql_statements.append("    sla_requirements, quality_requirements, change_notes,")
    sql_statements.append("    is_current, ativo, criado_por, data_criacao")
    sql_statements.append(") VALUES")
    
    version_values = []
    for version in versions:
        values = f"""(
    '{version["id"]}', '{version["contract_id"]}', '{version["version_number"]}',
    '{str(version["schema_definition"]).replace("'", "''")}'::jsonb,
    '{str(version["sla_requirements"]).replace("'", "''")}'::jsonb,
    '{str(version["quality_requirements"]).replace("'", "''")}'::jsonb,
    '{version["change_notes"]}', {version["is_current"]}, {version["ativo"]},
    '{version["criado_por"]}', '{version["data_criacao"]}'
)"""
        version_values.append(values)
    
    sql_statements.append(",\n".join(version_values))
    sql_statements.append(";\n")
    
    return "\n".join(sql_statements)


if __name__ == "__main__":
    # Generate and print sample data
    contracts = generate_data_contracts(5)
    print("Sample Data Contracts:")
    for contract in contracts:
        print(f"- {contract['name']} ({contract['contract_id']})")
    
    print(f"\nGenerated {len(contracts)} contracts")
    
    # Generate SQL
    sql = generate_mock_contracts_sql()
    print(f"\nSQL length: {len(sql)} characters")

