"""
Governance Policy endpoints.
"""

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db

router = APIRouter()


@router.get("/policies", summary="List governance policies")
async def list_policies(db: AsyncSession = Depends(get_db)):
    """List all governance policies."""
    return {"message": "Policy listing not yet implemented"}


@router.post("/policies", summary="Create governance policy")
async def create_policy(db: AsyncSession = Depends(get_db)):
    """Create a new governance policy."""
    raise HTTPException(status_code=status.HTTP_501_NOT_IMPLEMENTED, detail="Policy creation not yet implemented")


@router.post("/policies/{policy_id}/activate", summary="Activate policy")
async def activate_policy(policy_id: str, db: AsyncSession = Depends(get_db)):
    """Activate a governance policy."""
    raise HTTPException(status_code=status.HTTP_501_NOT_IMPLEMENTED, detail="Policy activation not yet implemented")


@router.post("/validate", summary="Validate compliance")
async def validate_compliance(db: AsyncSession = Depends(get_db)):
    """Validate compliance against policies."""
    raise HTTPException(status_code=status.HTTP_501_NOT_IMPLEMENTED, detail="Compliance validation not yet implemented")

