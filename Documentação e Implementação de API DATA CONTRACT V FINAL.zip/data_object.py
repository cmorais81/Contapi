"""
Data Object model.
"""

from sqlalchemy import Boolean, Column, ForeignKey, String, Text
from sqlalchemy.dialects.postgresql import UUID as PostgresUUID
from sqlalchemy.orm import relationship

from app.models.base import BaseModel
from app.models.mixins import UnityMixin


class DataObject(BaseModel, UnityMixin):
    """
    Data Object model.
    
    Data objects within contracts (tables, views, etc.).
    """

    __tablename__ = "data_objects"

    # Foreign key to contract
    contract_id = Column(
        PostgresUUID(as_uuid=True),
        ForeignKey("data_contracts.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
        doc="Reference to contract"
    )

    # Object identification
    object_name = Column(
        String(255),
        nullable=False,
        doc="Data object name"
    )

    object_description = Column(
        Text,
        doc="Object description"
    )

    object_type = Column(
        String(50),
        nullable=False,
        doc="Type: table, view, materialized_view, stream"
    )

    # Physical properties
    physical_location = Column(
        String(500),
        doc="Physical storage location"
    )

    partition_columns = Column(
        Text,
        doc="Partition columns (JSON array)"
    )

    clustering_columns = Column(
        Text,
        doc="Clustering columns (JSON array)"
    )

    # Configuration
    is_partitioned = Column(
        Boolean,
        default=False,
        doc="Is partitioned table"
    )

    is_clustered = Column(
        Boolean,
        default=False,
        doc="Is clustered table"
    )

    retention_days = Column(
        String(10),  # Using String to handle integer as text
        doc="Data retention in days"
    )

    # Relationships
    contract = relationship(
        "DataContract",
        back_populates="data_objects"
    )

    fields = relationship(
        "DataObjectField",
        back_populates="data_object",
        cascade="all, delete-orphan"
    )

    def __repr__(self) -> str:
        return f"<DataObject(name={self.object_name}, type={self.object_type})>"

