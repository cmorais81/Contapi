# Guia de Setup Local - PyCharm Professional (Windows)

**Versão:** 2.0  
**Data:** Julho 2025  
**Autor:** Carlos Morais (carlos.morais@f1rst.com.br)  
**Ambiente:** Windows + PyCharm Professional

## Visão Geral

Este guia foi desenvolvido especificamente para ambientes corporativos Windows com restrições de instalação, utilizando PyCharm Professional para maximizar a produtividade e minimizar configurações complexas no sistema operacional.

## Pré-requisitos Mínimos

### Software Essencial (Solicitar ao TI se necessário)
- **PyCharm Professional** 2023.1+ (licença corporativa)
- **Docker Desktop** para Windows (essencial para banco de dados)
- **Git** para Windows (geralmente já disponível)
- **Python 3.11+** (pode usar o bundled do PyCharm)

### Verificação de Ambiente
```powershell
# Verificar se Docker está disponível
docker --version

# Verificar se Git está disponível  
git --version

# Verificar se Python está disponível
python --version
```

## Configuração Passo a Passo

### 1. Clonagem do Projeto

```powershell
# Criar diretório de trabalho
mkdir C:\dev\data-governance-api
cd C:\dev\data-governance-api

# Clonar o repositório
git clone <repository-url> .
```

### 2. Configuração do PyCharm Professional

#### 2.1 Abrir o Projeto
1. Abrir PyCharm Professional
2. **File** → **Open** → Selecionar `C:\dev\data-governance-api`
3. Aguardar indexação automática

#### 2.2 Configurar Python Interpreter
1. **File** → **Settings** → **Project** → **Python Interpreter**
2. Clicar em **⚙️** → **Add...**
3. Selecionar **Virtualenv Environment** → **New environment**
4. **Location:** `C:\dev\data-governance-api\venv`
5. **Base interpreter:** Python 3.11+ (usar bundled se necessário)
6. ✅ **Inherit global site-packages** (desmarcar)
7. ✅ **Make available to all projects** (marcar)
8. Clicar **OK**

#### 2.3 Instalar Dependências
```bash
# No terminal integrado do PyCharm (Alt+F12)
pip install --upgrade pip
pip install -r requirements.txt
pip install -r requirements-dev.txt
```

### 3. Configuração do Banco de Dados (Docker)

#### 3.1 Iniciar PostgreSQL via Docker
```powershell
# No terminal do PyCharm ou PowerShell
docker run --name postgres-governance ^
  -e POSTGRES_DB=data_governance ^
  -e POSTGRES_USER=governance_user ^
  -e POSTGRES_PASSWORD=governance_pass ^
  -p 5432:5432 ^
  -d postgres:15
```

#### 3.2 Verificar Conexão
```powershell
# Verificar se container está rodando
docker ps

# Testar conexão
docker exec -it postgres-governance psql -U governance_user -d data_governance -c "\dt"
```

### 4. Configuração de Variáveis de Ambiente

#### 4.1 Criar arquivo .env
Criar arquivo `.env` na raiz do projeto:

```env
# Database Configuration
DATABASE_URL=postgresql://governance_user:governance_pass@localhost:5432/data_governance
TEST_DATABASE_URL=sqlite:///./test.db

# API Configuration
PROJECT_NAME=Data Governance API
VERSION=2.0.0
DESCRIPTION=API completa para governança de dados
API_V1_STR=/api/v1
SECRET_KEY=your-super-secret-key-change-in-production
ACCESS_TOKEN_EXPIRE_MINUTES=30

# CORS Configuration
BACKEND_CORS_ORIGINS=["http://localhost:3000","http://localhost:8000","http://localhost:8080"]

# Environment
ENVIRONMENT=development
DEBUG=true
TESTING=false

# Logging
LOG_LEVEL=INFO
LOG_FORMAT=detailed

# External Services
DATABRICKS_HOST=
DATABRICKS_TOKEN=
UNITY_CATALOG_ENABLED=false

# Monitoring
ENABLE_METRICS=true
METRICS_PORT=9090
```

#### 4.2 Configurar no PyCharm
1. **Run** → **Edit Configurations...**
2. Clicar **+** → **Python**
3. **Name:** `Data Governance API`
4. **Script path:** `C:\dev\data-governance-api\app\main.py`
5. **Environment variables:** Clicar **📁** e adicionar:
   - `PYTHONPATH=C:\dev\data-governance-api`
   - Ou usar **EnvFile plugin** para carregar `.env`

### 5. Configuração do Database no PyCharm

#### 5.1 Adicionar Data Source
1. **View** → **Tool Windows** → **Database**
2. Clicar **+** → **Data Source** → **PostgreSQL**
3. **Host:** `localhost`
4. **Port:** `5432`
5. **Database:** `data_governance`
6. **User:** `governance_user`
7. **Password:** `governance_pass`
8. **Test Connection** → **OK**

#### 5.2 Executar Migrations
```bash
# No terminal do PyCharm
alembic upgrade head
```

### 6. Configuração de Debug e Run

#### 6.1 Configuração de Run
1. **Run** → **Edit Configurations...**
2. Configuração criada anteriormente
3. **Module name:** `uvicorn`
4. **Parameters:** `app.main:app --host 0.0.0.0 --port 8000 --reload`
5. **Working directory:** `C:\dev\data-governance-api`

#### 6.2 Configuração de Debug
1. Mesma configuração acima
2. Adicionar breakpoints no código
3. **Debug** → **Debug 'Data Governance API'**

### 7. Configuração de Testes

#### 7.1 Configurar Test Runner
1. **File** → **Settings** → **Tools** → **Python Integrated Tools**
2. **Default test runner:** `pytest`
3. **pytest arguments:** `-v --tb=short`

#### 7.2 Executar Testes
```bash
# Todos os testes
pytest

# Testes específicos
pytest tests/unit/
pytest tests/integration/

# Com cobertura
pytest --cov=app --cov-report=html
```

### 8. Plugins Recomendados do PyCharm

#### 8.1 Plugins Essenciais
- **EnvFile** - Carregamento automático de .env
- **Database Navigator** - Melhor suporte a SQL
- **Docker** - Integração com Docker
- **Requirements** - Gerenciamento de dependências
- **Pydantic** - Suporte a schemas Pydantic

#### 8.2 Instalação de Plugins
1. **File** → **Settings** → **Plugins**
2. **Marketplace** → Buscar plugin → **Install**
3. Reiniciar PyCharm se necessário

### 9. Configuração de Code Style

#### 9.1 Configurar Black (Formatação)
1. **File** → **Settings** → **Tools** → **External Tools**
2. **+** → **Add**
3. **Name:** `Black`
4. **Program:** `$PyInterpreterDirectory$/black`
5. **Arguments:** `$FilePath$`
6. **Working directory:** `$ProjectFileDir$`

#### 9.2 Configurar Flake8 (Linting)
1. **File** → **Settings** → **Tools** → **External Tools**
2. **+** → **Add**
3. **Name:** `Flake8`
4. **Program:** `$PyInterpreterDirectory$/flake8`
5. **Arguments:** `$FilePath$`

### 10. Workflow de Desenvolvimento

#### 10.1 Rotina Diária
```bash
# 1. Iniciar banco de dados
docker start postgres-governance

# 2. Ativar ambiente virtual (automático no PyCharm)
# 3. Executar aplicação
# Run → Run 'Data Governance API'

# 4. Acessar documentação
# http://localhost:8000/docs
```

#### 10.2 Comandos Úteis
```bash
# Atualizar dependências
pip install -r requirements.txt

# Executar migrations
alembic upgrade head

# Gerar nova migration
alembic revision --autogenerate -m "Description"

# Executar testes
pytest tests/

# Verificar cobertura
pytest --cov=app

# Formatar código
black app/

# Verificar linting
flake8 app/
```

### 11. Troubleshooting Comum

#### 11.1 Problemas de Importação
```python
# Se houver erro de importação, adicionar ao PYTHONPATH
import sys
sys.path.append('C:/dev/data-governance-api')
```

#### 11.2 Problemas de Banco
```bash
# Recriar banco se necessário
docker stop postgres-governance
docker rm postgres-governance
# Executar comando de criação novamente
```

#### 11.3 Problemas de Dependências
```bash
# Limpar cache pip
pip cache purge

# Reinstalar dependências
pip uninstall -r requirements.txt -y
pip install -r requirements.txt
```

### 12. Configuração de Proxy Corporativo

#### 12.1 Configurar Pip para Proxy
```bash
# Criar/editar arquivo pip.conf
mkdir %APPDATA%\pip
echo [global] > %APPDATA%\pip\pip.conf
echo proxy = http://proxy.company.com:8080 >> %APPDATA%\pip\pip.conf
```

#### 12.2 Configurar Git para Proxy
```bash
git config --global http.proxy http://proxy.company.com:8080
git config --global https.proxy http://proxy.company.com:8080
```

### 13. Estrutura de Arquivos no PyCharm

```
data-governance-api/
├── 📁 app/                     # Código principal
│   ├── 📁 api/                 # Endpoints FastAPI
│   ├── 📁 core/                # Configurações
│   ├── 📁 models/              # Modelos SQLAlchemy
│   ├── 📁 schemas/             # Schemas Pydantic
│   └── 📄 main.py              # Ponto de entrada
├── 📁 tests/                   # Testes automatizados
├── 📁 docs/                    # Documentação
├── 📁 scripts/                 # Scripts utilitários
├── 📄 .env                     # Variáveis de ambiente
├── 📄 requirements.txt         # Dependências
└── 📄 README.md               # Documentação principal
```

### 14. Atalhos Úteis do PyCharm

| Ação | Atalho |
|------|--------|
| Executar aplicação | `Shift+F10` |
| Debug aplicação | `Shift+F9` |
| Terminal integrado | `Alt+F12` |
| Buscar arquivos | `Ctrl+Shift+N` |
| Buscar em arquivos | `Ctrl+Shift+F` |
| Refatorar | `Ctrl+Alt+Shift+T` |
| Formatar código | `Ctrl+Alt+L` |
| Executar testes | `Ctrl+Shift+F10` |

### 15. Monitoramento e Logs

#### 15.1 Visualizar Logs
```bash
# Logs da aplicação
tail -f logs/app.log

# Logs do Docker
docker logs postgres-governance
```

#### 15.2 Métricas de Performance
- Acessar: `http://localhost:8000/metrics`
- Prometheus: `http://localhost:9090` (se configurado)

### 16. Backup e Versionamento

#### 16.1 Backup do Banco
```bash
# Backup
docker exec postgres-governance pg_dump -U governance_user data_governance > backup.sql

# Restore
docker exec -i postgres-governance psql -U governance_user data_governance < backup.sql
```

#### 16.2 Versionamento com Git
```bash
# Commit diário
git add .
git commit -m "feat: implementação de funcionalidade X"
git push origin main
```

## Conclusão

Este setup foi otimizado para ambientes corporativos Windows com restrições, utilizando PyCharm Professional para maximizar a produtividade. O uso do Docker para o banco de dados elimina a necessidade de instalações complexas no SO, enquanto o PyCharm gerencia todo o ambiente Python de forma isolada.

### Suporte
- **Email:** carlos.morais@f1rst.com.br
- **Documentação:** `/docs/`
- **Issues:** Repositório Git

---

**Desenvolvido por Carlos Morais - Julho 2025**

