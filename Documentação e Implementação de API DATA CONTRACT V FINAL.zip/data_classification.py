"""
Data Classification model.

Desenvolvido por Carlos Morais - Julho 2025
"""

from sqlalchemy import Boolean, Column, Enum, ForeignKey, String, Text, UUID
from sqlalchemy.orm import relationship
import enum

from app.models.base import BaseModel
from app.models.mixins import TimestampMixin


class ClassificationLevel(enum.Enum):
    """Níveis de classificação de dados."""
    PUBLIC = "public"
    INTERNAL = "internal"
    CONFIDENTIAL = "confidential"
    RESTRICTED = "restricted"
    TOP_SECRET = "top_secret"


class SensitivityType(enum.Enum):
    """Tipos de sensibilidade de dados."""
    PII = "pii"  # Personally Identifiable Information
    PHI = "phi"  # Protected Health Information
    PCI = "pci"  # Payment Card Industry
    FINANCIAL = "financial"
    BIOMETRIC = "biometric"
    BEHAVIORAL = "behavioral"
    LOCATION = "location"
    COMMUNICATION = "communication"
    NONE = "none"


class DataClassification(BaseModel, TimestampMixin):
    """
    Modelo para classificação de dados sensíveis.
    
    Gerencia a classificação de privacidade e sensibilidade de dados,
    incluindo identificação de PII, PHI, dados financeiros e outros
    tipos de informações sensíveis conforme regulamentações.
    """
    
    __tablename__ = "data_classifications"
    
    # Identificação
    classification_id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        server_default="gen_random_uuid()",
        comment="Identificador único da classificação"
    )
    
    # Referência ao objeto classificado
    entity_id = Column(
        UUID(as_uuid=True),
        ForeignKey("entities.entity_id"),
        nullable=False,
        comment="Referência à entidade classificada"
    )
    
    # Classificação de segurança
    classification_level = Column(
        Enum(ClassificationLevel),
        nullable=False,
        default=ClassificationLevel.INTERNAL,
        comment="Nível de classificação de segurança"
    )
    
    # Tipo de sensibilidade
    sensitivity_type = Column(
        Enum(SensitivityType),
        nullable=False,
        default=SensitivityType.NONE,
        comment="Tipo de sensibilidade dos dados"
    )
    
    # Detalhes da classificação
    classification_reason = Column(
        Text,
        comment="Razão da classificação"
    )
    
    data_categories = Column(
        Text,
        comment="Categorias de dados (JSON array)"
    )
    
    # Regulamentações aplicáveis
    applicable_regulations = Column(
        Text,
        comment="Regulamentações aplicáveis (GDPR, LGPD, CCPA, etc.)"
    )
    
    # Metadados de classificação
    classified_by = Column(
        String(255),
        nullable=False,
        comment="Usuário que realizou a classificação"
    )
    
    classification_method = Column(
        String(50),
        default="manual",
        comment="Método de classificação: manual, automatic, ml_assisted"
    )
    
    confidence_score = Column(
        String(10),
        comment="Score de confiança da classificação (0.0-1.0)"
    )
    
    # Controles de acesso
    requires_encryption = Column(
        Boolean,
        default=False,
        comment="Requer criptografia"
    )
    
    requires_masking = Column(
        Boolean,
        default=False,
        comment="Requer mascaramento"
    )
    
    requires_audit = Column(
        Boolean,
        default=True,
        comment="Requer auditoria de acesso"
    )
    
    # Retenção e expurgo
    retention_period_days = Column(
        String(10),
        comment="Período de retenção em dias"
    )
    
    auto_purge_enabled = Column(
        Boolean,
        default=False,
        comment="Expurgo automático habilitado"
    )
    
    # Status
    is_active = Column(
        Boolean,
        default=True,
        nullable=False,
        comment="Classificação ativa"
    )
    
    requires_review = Column(
        Boolean,
        default=False,
        comment="Requer revisão"
    )
    
    # Relacionamentos
    entity = relationship(
        "Entity",
        back_populates="classifications"
    )
    
    masking_rules = relationship(
        "DataMaskingRule",
        back_populates="classification",
        cascade="all, delete-orphan"
    )
    
    def __repr__(self) -> str:
        return f"<DataClassification(id={self.classification_id}, level={self.classification_level.value}, type={self.sensitivity_type.value})>"
    
    @property
    def is_sensitive(self) -> bool:
        """Verifica se os dados são considerados sensíveis."""
        return self.sensitivity_type != SensitivityType.NONE
    
    @property
    def is_personal_data(self) -> bool:
        """Verifica se são dados pessoais (PII/PHI)."""
        return self.sensitivity_type in [SensitivityType.PII, SensitivityType.PHI]
    
    @property
    def requires_gdpr_compliance(self) -> bool:
        """Verifica se requer compliance com GDPR."""
        return (
            self.is_personal_data and 
            "GDPR" in (self.applicable_regulations or "")
        )
    
    @property
    def requires_lgpd_compliance(self) -> bool:
        """Verifica se requer compliance com LGPD."""
        return (
            self.is_personal_data and 
            "LGPD" in (self.applicable_regulations or "")
        )
    
    def get_required_controls(self) -> list:
        """
        Retorna lista de controles necessários baseados na classificação.
        
        Returns:
            Lista de controles de segurança necessários
        """
        controls = []
        
        if self.requires_encryption:
            controls.append("encryption")
        
        if self.requires_masking:
            controls.append("masking")
        
        if self.requires_audit:
            controls.append("audit_logging")
        
        if self.classification_level in [ClassificationLevel.CONFIDENTIAL, ClassificationLevel.RESTRICTED]:
            controls.append("access_control")
        
        if self.is_personal_data:
            controls.append("consent_management")
            controls.append("data_subject_rights")
        
        return controls
    
    def calculate_risk_score(self) -> float:
        """
        Calcula score de risco baseado na classificação.
        
        Returns:
            Score de risco de 0.0 (baixo) a 1.0 (alto)
        """
        base_score = 0.0
        
        # Score baseado no nível de classificação
        level_scores = {
            ClassificationLevel.PUBLIC: 0.1,
            ClassificationLevel.INTERNAL: 0.3,
            ClassificationLevel.CONFIDENTIAL: 0.6,
            ClassificationLevel.RESTRICTED: 0.8,
            ClassificationLevel.TOP_SECRET: 1.0
        }
        base_score += level_scores.get(self.classification_level, 0.3)
        
        # Score baseado no tipo de sensibilidade
        sensitivity_scores = {
            SensitivityType.NONE: 0.0,
            SensitivityType.BEHAVIORAL: 0.2,
            SensitivityType.LOCATION: 0.3,
            SensitivityType.COMMUNICATION: 0.4,
            SensitivityType.FINANCIAL: 0.6,
            SensitivityType.PCI: 0.7,
            SensitivityType.PII: 0.8,
            SensitivityType.PHI: 0.9,
            SensitivityType.BIOMETRIC: 1.0
        }
        base_score += sensitivity_scores.get(self.sensitivity_type, 0.0)
        
        # Normalizar para 0.0-1.0
        return min(base_score / 2.0, 1.0)

