#!/usr/bin/env python3
"""
Health Check Script for Data Governance API.

Performs comprehensive health checks on all system components.

Author: Carlos Morais <carlos.morais@f1rst.com.br>
Date: July 2025
"""

import asyncio
import json
import logging
import sys
import time
from datetime import datetime
from typing import Dict, List, Any, Optional
import aiohttp
import asyncpg
import psutil
from pathlib import Path

# Add project root to path
sys.path.append(str(Path(__file__).parent.parent.parent))

from app.core.config import settings
from app.core.database import get_database_url


class HealthChecker:
    """Comprehensive health checker for Data Governance API."""
    
    def __init__(self):
        self.results = {}
        self.start_time = time.time()
        self.logger = self._setup_logging()
    
    def _setup_logging(self) -> logging.Logger:
        """Setup logging configuration."""
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        return logging.getLogger(__name__)
    
    async def run_all_checks(self) -> Dict[str, Any]:
        """Run all health checks."""
        self.logger.info("Starting comprehensive health check...")
        
        checks = [
            ("system", self.check_system_resources),
            ("database", self.check_database),
            ("api", self.check_api_endpoints),
            ("dependencies", self.check_external_dependencies),
            ("data_quality", self.check_data_quality),
            ("security", self.check_security),
            ("performance", self.check_performance)
        ]
        
        for check_name, check_func in checks:
            try:
                self.logger.info(f"Running {check_name} check...")
                result = await check_func()
                self.results[check_name] = result
                status = "✅ PASS" if result["status"] == "healthy" else "❌ FAIL"
                self.logger.info(f"{check_name} check: {status}")
            except Exception as e:
                self.logger.error(f"Error in {check_name} check: {str(e)}")
                self.results[check_name] = {
                    "status": "error",
                    "message": str(e),
                    "timestamp": datetime.utcnow().isoformat()
                }
        
        # Generate overall health status
        overall_status = self._calculate_overall_status()
        
        health_report = {
            "overall_status": overall_status,
            "timestamp": datetime.utcnow().isoformat(),
            "duration_seconds": round(time.time() - self.start_time, 2),
            "checks": self.results,
            "summary": self._generate_summary()
        }
        
        self.logger.info(f"Health check completed. Overall status: {overall_status}")
        return health_report
    
    async def check_system_resources(self) -> Dict[str, Any]:
        """Check system resource utilization."""
        try:
            # CPU usage
            cpu_percent = psutil.cpu_percent(interval=1)
            
            # Memory usage
            memory = psutil.virtual_memory()
            memory_percent = memory.percent
            
            # Disk usage
            disk = psutil.disk_usage('/')
            disk_percent = disk.percent
            
            # Load average (Unix only)
            try:
                load_avg = psutil.getloadavg()
            except AttributeError:
                load_avg = None
            
            # Network stats
            network = psutil.net_io_counters()
            
            # Process count
            process_count = len(psutil.pids())
            
            # Determine status
            status = "healthy"
            issues = []
            
            if cpu_percent > 80:
                status = "warning"
                issues.append(f"High CPU usage: {cpu_percent}%")
            
            if memory_percent > 85:
                status = "critical"
                issues.append(f"High memory usage: {memory_percent}%")
            
            if disk_percent > 90:
                status = "critical"
                issues.append(f"High disk usage: {disk_percent}%")
            
            return {
                "status": status,
                "message": "System resources check completed",
                "details": {
                    "cpu_percent": cpu_percent,
                    "memory_percent": memory_percent,
                    "memory_total_gb": round(memory.total / (1024**3), 2),
                    "memory_available_gb": round(memory.available / (1024**3), 2),
                    "disk_percent": disk_percent,
                    "disk_total_gb": round(disk.total / (1024**3), 2),
                    "disk_free_gb": round(disk.free / (1024**3), 2),
                    "load_average": load_avg,
                    "process_count": process_count,
                    "network_bytes_sent": network.bytes_sent,
                    "network_bytes_recv": network.bytes_recv
                },
                "issues": issues,
                "timestamp": datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            return {
                "status": "error",
                "message": f"System check failed: {str(e)}",
                "timestamp": datetime.utcnow().isoformat()
            }
    
    async def check_database(self) -> Dict[str, Any]:
        """Check database connectivity and health."""
        try:
            database_url = get_database_url()
            
            # Test connection
            conn = await asyncpg.connect(database_url)
            
            # Check database version
            version = await conn.fetchval("SELECT version()")
            
            # Check database size
            db_size_query = """
                SELECT pg_size_pretty(pg_database_size(current_database())) as size,
                       pg_database_size(current_database()) as size_bytes
            """
            db_size = await conn.fetchrow(db_size_query)
            
            # Check active connections
            connections_query = """
                SELECT count(*) as active_connections,
                       max_conn.setting::int as max_connections
                FROM pg_stat_activity,
                     (SELECT setting FROM pg_settings WHERE name = 'max_connections') max_conn
                WHERE state = 'active'
                GROUP BY max_conn.setting
            """
            connections = await conn.fetchrow(connections_query)
            
            # Check table counts
            table_count_query = """
                SELECT schemaname, count(*) as table_count
                FROM pg_tables 
                WHERE schemaname NOT IN ('information_schema', 'pg_catalog')
                GROUP BY schemaname
            """
            table_counts = await conn.fetch(table_count_query)
            
            # Check for long-running queries
            long_queries_query = """
                SELECT count(*) as long_running_queries
                FROM pg_stat_activity 
                WHERE state = 'active' 
                AND now() - query_start > interval '5 minutes'
            """
            long_queries = await conn.fetchval(long_queries_query)
            
            await conn.close()
            
            # Determine status
            status = "healthy"
            issues = []
            
            if connections and connections['active_connections'] > connections['max_connections'] * 0.8:
                status = "warning"
                issues.append("High connection usage")
            
            if long_queries > 0:
                status = "warning"
                issues.append(f"{long_queries} long-running queries detected")
            
            return {
                "status": status,
                "message": "Database connectivity check passed",
                "details": {
                    "version": version,
                    "database_size": db_size['size'] if db_size else "Unknown",
                    "database_size_bytes": db_size['size_bytes'] if db_size else 0,
                    "active_connections": connections['active_connections'] if connections else 0,
                    "max_connections": connections['max_connections'] if connections else 0,
                    "table_counts": dict(table_counts) if table_counts else {},
                    "long_running_queries": long_queries
                },
                "issues": issues,
                "timestamp": datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            return {
                "status": "critical",
                "message": f"Database check failed: {str(e)}",
                "timestamp": datetime.utcnow().isoformat()
            }
    
    async def check_api_endpoints(self) -> Dict[str, Any]:
        """Check API endpoint availability and response times."""
        try:
            base_url = f"http://localhost:{settings.PORT}"
            
            endpoints = [
                {"path": "/", "method": "GET", "expected_status": 200},
                {"path": "/health", "method": "GET", "expected_status": 200},
                {"path": "/docs", "method": "GET", "expected_status": 200},
                {"path": "/api/v1/contracts", "method": "GET", "expected_status": [200, 401]},
                {"path": "/api/v1/quality/rules", "method": "GET", "expected_status": [200, 401]},
            ]
            
            results = []
            total_response_time = 0
            
            async with aiohttp.ClientSession() as session:
                for endpoint in endpoints:
                    start_time = time.time()
                    try:
                        async with session.request(
                            endpoint["method"],
                            f"{base_url}{endpoint['path']}",
                            timeout=aiohttp.ClientTimeout(total=10)
                        ) as response:
                            response_time = round((time.time() - start_time) * 1000, 2)
                            total_response_time += response_time
                            
                            expected_statuses = endpoint["expected_status"]
                            if isinstance(expected_statuses, int):
                                expected_statuses = [expected_statuses]
                            
                            status = "healthy" if response.status in expected_statuses else "warning"
                            
                            results.append({
                                "endpoint": endpoint["path"],
                                "method": endpoint["method"],
                                "status_code": response.status,
                                "response_time_ms": response_time,
                                "status": status
                            })
                            
                    except Exception as e:
                        results.append({
                            "endpoint": endpoint["path"],
                            "method": endpoint["method"],
                            "error": str(e),
                            "status": "critical"
                        })
            
            # Determine overall status
            failed_endpoints = [r for r in results if r.get("status") == "critical"]
            slow_endpoints = [r for r in results if r.get("response_time_ms", 0) > 5000]
            
            if failed_endpoints:
                status = "critical"
                issues = [f"Failed endpoints: {len(failed_endpoints)}"]
            elif slow_endpoints:
                status = "warning"
                issues = [f"Slow endpoints: {len(slow_endpoints)}"]
            else:
                status = "healthy"
                issues = []
            
            avg_response_time = round(total_response_time / len(results), 2) if results else 0
            
            return {
                "status": status,
                "message": "API endpoints check completed",
                "details": {
                    "endpoints_checked": len(endpoints),
                    "successful_endpoints": len([r for r in results if r.get("status") == "healthy"]),
                    "failed_endpoints": len(failed_endpoints),
                    "average_response_time_ms": avg_response_time,
                    "endpoint_results": results
                },
                "issues": issues,
                "timestamp": datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            return {
                "status": "error",
                "message": f"API check failed: {str(e)}",
                "timestamp": datetime.utcnow().isoformat()
            }
    
    async def check_external_dependencies(self) -> Dict[str, Any]:
        """Check external service dependencies."""
        try:
            dependencies = []
            
            # Check if external services are configured
            if hasattr(settings, 'UNITY_CATALOG_ENABLED') and settings.UNITY_CATALOG_ENABLED:
                dependencies.append({
                    "name": "Unity Catalog",
                    "url": getattr(settings, 'UNITY_CATALOG_URL', None),
                    "required": True
                })
            
            if hasattr(settings, 'TABLEAU_ENABLED') and settings.TABLEAU_ENABLED:
                dependencies.append({
                    "name": "Tableau",
                    "url": getattr(settings, 'TABLEAU_URL', None),
                    "required": False
                })
            
            # Add other dependencies
            dependencies.extend([
                {
                    "name": "DNS Resolution",
                    "url": "8.8.8.8",
                    "required": True,
                    "type": "ping"
                }
            ])
            
            results = []
            
            async with aiohttp.ClientSession() as session:
                for dep in dependencies:
                    if not dep.get("url"):
                        results.append({
                            "name": dep["name"],
                            "status": "skipped",
                            "message": "Not configured"
                        })
                        continue
                    
                    try:
                        if dep.get("type") == "ping":
                            # Simple connectivity check
                            import subprocess
                            result = subprocess.run(
                                ["ping", "-c", "1", dep["url"]], 
                                capture_output=True, 
                                timeout=5
                            )
                            status = "healthy" if result.returncode == 0 else "critical"
                            message = "Reachable" if result.returncode == 0 else "Unreachable"
                        else:
                            # HTTP check
                            async with session.get(
                                dep["url"], 
                                timeout=aiohttp.ClientTimeout(total=10)
                            ) as response:
                                status = "healthy" if response.status < 400 else "warning"
                                message = f"HTTP {response.status}"
                        
                        results.append({
                            "name": dep["name"],
                            "url": dep["url"],
                            "status": status,
                            "message": message,
                            "required": dep["required"]
                        })
                        
                    except Exception as e:
                        status = "critical" if dep["required"] else "warning"
                        results.append({
                            "name": dep["name"],
                            "url": dep["url"],
                            "status": status,
                            "message": str(e),
                            "required": dep["required"]
                        })
            
            # Determine overall status
            critical_failures = [r for r in results if r["status"] == "critical"]
            
            if critical_failures:
                status = "critical"
                issues = [f"Critical dependency failures: {len(critical_failures)}"]
            else:
                status = "healthy"
                issues = []
            
            return {
                "status": status,
                "message": "External dependencies check completed",
                "details": {
                    "dependencies_checked": len(dependencies),
                    "healthy_dependencies": len([r for r in results if r["status"] == "healthy"]),
                    "failed_dependencies": len(critical_failures),
                    "dependency_results": results
                },
                "issues": issues,
                "timestamp": datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            return {
                "status": "error",
                "message": f"Dependencies check failed: {str(e)}",
                "timestamp": datetime.utcnow().isoformat()
            }
    
    async def check_data_quality(self) -> Dict[str, Any]:
        """Check data quality metrics."""
        try:
            database_url = get_database_url()
            conn = await asyncpg.connect(database_url)
            
            # Check for recent quality rule executions
            recent_executions_query = """
                SELECT COUNT(*) as total_executions,
                       COUNT(CASE WHEN execution_status = 'completed' THEN 1 END) as completed,
                       COUNT(CASE WHEN execution_status = 'failed' THEN 1 END) as failed,
                       AVG(CASE WHEN success_rate IS NOT NULL THEN success_rate END) as avg_success_rate
                FROM quality_executions 
                WHERE started_at >= NOW() - INTERVAL '24 hours'
            """
            
            try:
                executions = await conn.fetchrow(recent_executions_query)
            except:
                # Table might not exist yet
                executions = None
            
            # Check data contract compliance
            contract_compliance_query = """
                SELECT COUNT(*) as total_contracts,
                       COUNT(CASE WHEN status = 'active' THEN 1 END) as active_contracts,
                       COUNT(CASE WHEN approval_status = 'approved' THEN 1 END) as approved_contracts
                FROM data_contracts 
                WHERE ativo = true
            """
            
            try:
                contracts = await conn.fetchrow(contract_compliance_query)
            except:
                # Table might not exist yet
                contracts = None
            
            await conn.close()
            
            # Determine status
            status = "healthy"
            issues = []
            
            if executions and executions['total_executions'] > 0:
                failure_rate = executions['failed'] / executions['total_executions']
                if failure_rate > 0.1:  # More than 10% failures
                    status = "warning"
                    issues.append(f"High quality check failure rate: {failure_rate:.1%}")
                
                if executions['avg_success_rate'] and executions['avg_success_rate'] < 0.9:
                    status = "warning"
                    issues.append(f"Low average success rate: {executions['avg_success_rate']:.1%}")
            
            return {
                "status": status,
                "message": "Data quality check completed",
                "details": {
                    "quality_executions_24h": executions['total_executions'] if executions else 0,
                    "completed_executions": executions['completed'] if executions else 0,
                    "failed_executions": executions['failed'] if executions else 0,
                    "avg_success_rate": round(executions['avg_success_rate'], 3) if executions and executions['avg_success_rate'] else None,
                    "total_contracts": contracts['total_contracts'] if contracts else 0,
                    "active_contracts": contracts['active_contracts'] if contracts else 0,
                    "approved_contracts": contracts['approved_contracts'] if contracts else 0
                },
                "issues": issues,
                "timestamp": datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            return {
                "status": "error",
                "message": f"Data quality check failed: {str(e)}",
                "timestamp": datetime.utcnow().isoformat()
            }
    
    async def check_security(self) -> Dict[str, Any]:
        """Check security-related metrics."""
        try:
            database_url = get_database_url()
            conn = await asyncpg.connect(database_url)
            
            # Check for recent failed login attempts
            failed_logins_query = """
                SELECT COUNT(*) as failed_logins_24h
                FROM users 
                WHERE failed_login_attempts > 0 
                AND data_atualizacao >= NOW() - INTERVAL '24 hours'
            """
            
            try:
                failed_logins = await conn.fetchval(failed_logins_query)
            except:
                failed_logins = 0
            
            # Check for locked accounts
            locked_accounts_query = """
                SELECT COUNT(*) as locked_accounts
                FROM users 
                WHERE account_locked = true AND ativo = true
            """
            
            try:
                locked_accounts = await conn.fetchval(locked_accounts_query)
            except:
                locked_accounts = 0
            
            # Check 2FA adoption
            two_fa_query = """
                SELECT COUNT(*) as total_users,
                       COUNT(CASE WHEN two_factor_enabled = true THEN 1 END) as two_fa_enabled
                FROM users 
                WHERE is_active = true
            """
            
            try:
                two_fa_stats = await conn.fetchrow(two_fa_query)
            except:
                two_fa_stats = None
            
            await conn.close()
            
            # Determine status
            status = "healthy"
            issues = []
            
            if failed_logins > 10:
                status = "warning"
                issues.append(f"High number of failed logins: {failed_logins}")
            
            if locked_accounts > 5:
                status = "warning"
                issues.append(f"Multiple locked accounts: {locked_accounts}")
            
            if two_fa_stats and two_fa_stats['total_users'] > 0:
                two_fa_rate = two_fa_stats['two_fa_enabled'] / two_fa_stats['total_users']
                if two_fa_rate < 0.8:  # Less than 80% 2FA adoption
                    status = "warning"
                    issues.append(f"Low 2FA adoption rate: {two_fa_rate:.1%}")
            
            return {
                "status": status,
                "message": "Security check completed",
                "details": {
                    "failed_logins_24h": failed_logins,
                    "locked_accounts": locked_accounts,
                    "total_active_users": two_fa_stats['total_users'] if two_fa_stats else 0,
                    "two_fa_enabled_users": two_fa_stats['two_fa_enabled'] if two_fa_stats else 0,
                    "two_fa_adoption_rate": round(two_fa_stats['two_fa_enabled'] / two_fa_stats['total_users'], 3) if two_fa_stats and two_fa_stats['total_users'] > 0 else 0
                },
                "issues": issues,
                "timestamp": datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            return {
                "status": "error",
                "message": f"Security check failed: {str(e)}",
                "timestamp": datetime.utcnow().isoformat()
            }
    
    async def check_performance(self) -> Dict[str, Any]:
        """Check system performance metrics."""
        try:
            # Check API response times (already done in API check)
            # Check database query performance
            database_url = get_database_url()
            conn = await asyncpg.connect(database_url)
            
            # Check slow queries
            slow_queries_query = """
                SELECT COUNT(*) as slow_queries
                FROM pg_stat_statements 
                WHERE mean_time > 1000  -- queries taking more than 1 second on average
                LIMIT 1
            """
            
            try:
                slow_queries = await conn.fetchval(slow_queries_query)
            except:
                # pg_stat_statements might not be enabled
                slow_queries = 0
            
            # Check cache hit ratio
            cache_hit_query = """
                SELECT 
                    round(
                        sum(blks_hit) * 100.0 / sum(blks_hit + blks_read), 2
                    ) as cache_hit_ratio
                FROM pg_stat_database
                WHERE datname = current_database()
            """
            
            try:
                cache_hit_ratio = await conn.fetchval(cache_hit_query)
            except:
                cache_hit_ratio = None
            
            await conn.close()
            
            # Determine status
            status = "healthy"
            issues = []
            
            if slow_queries > 5:
                status = "warning"
                issues.append(f"Multiple slow queries detected: {slow_queries}")
            
            if cache_hit_ratio and cache_hit_ratio < 95:
                status = "warning"
                issues.append(f"Low cache hit ratio: {cache_hit_ratio}%")
            
            return {
                "status": status,
                "message": "Performance check completed",
                "details": {
                    "slow_queries": slow_queries,
                    "cache_hit_ratio": cache_hit_ratio
                },
                "issues": issues,
                "timestamp": datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            return {
                "status": "error",
                "message": f"Performance check failed: {str(e)}",
                "timestamp": datetime.utcnow().isoformat()
            }
    
    def _calculate_overall_status(self) -> str:
        """Calculate overall health status."""
        statuses = [check.get("status", "error") for check in self.results.values()]
        
        if "critical" in statuses:
            return "critical"
        elif "error" in statuses:
            return "error"
        elif "warning" in statuses:
            return "warning"
        else:
            return "healthy"
    
    def _generate_summary(self) -> Dict[str, Any]:
        """Generate health check summary."""
        total_checks = len(self.results)
        healthy_checks = len([c for c in self.results.values() if c.get("status") == "healthy"])
        warning_checks = len([c for c in self.results.values() if c.get("status") == "warning"])
        critical_checks = len([c for c in self.results.values() if c.get("status") == "critical"])
        error_checks = len([c for c in self.results.values() if c.get("status") == "error"])
        
        all_issues = []
        for check in self.results.values():
            if "issues" in check:
                all_issues.extend(check["issues"])
        
        return {
            "total_checks": total_checks,
            "healthy_checks": healthy_checks,
            "warning_checks": warning_checks,
            "critical_checks": critical_checks,
            "error_checks": error_checks,
            "health_score": round((healthy_checks / total_checks) * 100, 1) if total_checks > 0 else 0,
            "total_issues": len(all_issues),
            "top_issues": all_issues[:5]  # Top 5 issues
        }


async def main():
    """Main function to run health checks."""
    checker = HealthChecker()
    
    try:
        results = await checker.run_all_checks()
        
        # Print results
        print(json.dumps(results, indent=2, default=str))
        
        # Exit with appropriate code
        if results["overall_status"] in ["critical", "error"]:
            sys.exit(1)
        elif results["overall_status"] == "warning":
            sys.exit(2)
        else:
            sys.exit(0)
            
    except Exception as e:
        print(f"Health check failed: {str(e)}")
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())

