"""
Contract Custom Property model.

Desenvolvido por Carlos Morais (carlos.morais@f1rst.com.br)
Julho 2025
"""

from sqlalchemy import Column, Integer, String, Text, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from app.models.base import BaseModel


class ContractCustomProperty(BaseModel):
    """Modelo para propriedades customizadas de contratos."""
    __tablename__ = "contract_custom_properties"

    property_id = Column(Integer, primary_key=True, index=True)
    contract_id = Column(Integer, ForeignKey("data_contracts.contract_id"), nullable=False)
    property_name = Column(String(255), nullable=False)
    property_value = Column(Text)
    property_type = Column(String(50), default="string")
    
    # Auditoria
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    created_by = Column(String(255), nullable=False)
    
    # Relacionamentos
    contract = relationship("DataContract", back_populates="custom_properties")
    
    def __repr__(self):
        return f"<ContractCustomProperty(id={self.property_id}, name='{self.property_name}')>"

