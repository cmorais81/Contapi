"""
Performance Alert model.

Desenvolvido por Carlos Morais - Julho 2025
"""

from sqlalchemy import Boolean, Column, DateTime, Enum, ForeignKey, String, Text, UUID
from sqlalchemy.orm import relationship
import enum

from app.models.base import BaseModel
from app.models.mixins import TimestampMixin


class AlertSeverity(enum.Enum):
    """Severidade do alerta."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class AlertType(enum.Enum):
    """Tipos de alerta."""
    SLOW_QUERY = "slow_query"
    HIGH_COST = "high_cost"
    MEMORY_SPILL = "memory_spill"
    TIMEOUT = "timeout"
    FAILED_QUERY = "failed_query"
    RESOURCE_EXHAUSTION = "resource_exhaustion"
    UNUSUAL_PATTERN = "unusual_pattern"


class AlertStatus(enum.Enum):
    """Status do alerta."""
    OPEN = "open"
    ACKNOWLEDGED = "acknowledged"
    RESOLVED = "resolved"
    SUPPRESSED = "suppressed"


class PerformanceAlert(BaseModel, TimestampMixin):
    """
    Modelo para alertas de performance.
    
    Gerencia alertas automáticos baseados em métricas de performance,
    identificando queries problemáticas, custos elevados e padrões
    anômalos que requerem atenção.
    """
    
    __tablename__ = "performance_alerts"
    
    # Identificação
    alert_id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        server_default="gen_random_uuid()",
        comment="Identificador único do alerta"
    )
    
    # Referências
    query_performance_id = Column(
        UUID(as_uuid=True),
        ForeignKey("query_performance.performance_id"),
        comment="Referência à análise de performance"
    )
    
    # Configuração do alerta
    alert_type = Column(
        Enum(AlertType),
        nullable=False,
        comment="Tipo do alerta"
    )
    
    severity = Column(
        Enum(AlertSeverity),
        nullable=False,
        comment="Severidade do alerta"
    )
    
    # Detalhes do alerta
    alert_title = Column(
        String(255),
        nullable=False,
        comment="Título do alerta"
    )
    
    alert_description = Column(
        Text,
        comment="Descrição detalhada do alerta"
    )
    
    # Métricas que dispararam o alerta
    threshold_value = Column(
        String(50),
        comment="Valor do threshold configurado"
    )
    
    actual_value = Column(
        String(50),
        comment="Valor real que disparou o alerta"
    )
    
    metric_name = Column(
        String(100),
        comment="Nome da métrica monitorada"
    )
    
    # Contexto
    affected_resources = Column(
        Text,
        comment="Recursos afetados (JSON array)"
    )
    
    impact_assessment = Column(
        Text,
        comment="Avaliação de impacto"
    )
    
    # Status e resolução
    status = Column(
        Enum(AlertStatus),
        default=AlertStatus.OPEN,
        nullable=False,
        comment="Status do alerta"
    )
    
    acknowledged_at = Column(
        DateTime,
        comment="Data/hora de reconhecimento"
    )
    
    acknowledged_by = Column(
        String(255),
        comment="Usuário que reconheceu"
    )
    
    resolved_at = Column(
        DateTime,
        comment="Data/hora de resolução"
    )
    
    resolved_by = Column(
        String(255),
        comment="Usuário que resolveu"
    )
    
    resolution_notes = Column(
        Text,
        comment="Notas de resolução"
    )
    
    # Ações recomendadas
    recommended_actions = Column(
        Text,
        comment="Ações recomendadas (JSON array)"
    )
    
    auto_resolution_attempted = Column(
        Boolean,
        default=False,
        comment="Tentativa de resolução automática"
    )
    
    # Notificações
    notification_sent = Column(
        Boolean,
        default=False,
        comment="Notificação enviada"
    )
    
    notification_channels = Column(
        Text,
        comment="Canais de notificação utilizados (JSON array)"
    )
    
    # Supressão
    suppressed_until = Column(
        DateTime,
        comment="Suprimido até data/hora"
    )
    
    suppression_reason = Column(
        Text,
        comment="Razão da supressão"
    )
    
    # Relacionamentos
    query_performance = relationship(
        "QueryPerformance",
        back_populates="alerts"
    )
    
    def __repr__(self) -> str:
        return f"<PerformanceAlert(id={self.alert_id}, type={self.alert_type.value}, severity={self.severity.value})>"
    
    @property
    def is_open(self) -> bool:
        """Verifica se o alerta está aberto."""
        return self.status == AlertStatus.OPEN
    
    @property
    def is_critical(self) -> bool:
        """Verifica se o alerta é crítico."""
        return self.severity == AlertSeverity.CRITICAL
    
    @property
    def is_suppressed(self) -> bool:
        """Verifica se o alerta está suprimido."""
        if self.status == AlertStatus.SUPPRESSED:
            return True
        
        if self.suppressed_until:
            from datetime import datetime
            return datetime.utcnow() < self.suppressed_until
        
        return False
    
    def get_affected_resources(self) -> list:
        """
        Retorna lista de recursos afetados.
        
        Returns:
            Lista de recursos
        """
        import json
        if not self.affected_resources:
            return []
        try:
            return json.loads(self.affected_resources)
        except:
            return []
    
    def get_recommended_actions(self) -> list:
        """
        Retorna lista de ações recomendadas.
        
        Returns:
            Lista de ações
        """
        import json
        if not self.recommended_actions:
            return []
        try:
            return json.loads(self.recommended_actions)
        except:
            return []
    
    def get_notification_channels(self) -> list:
        """
        Retorna lista de canais de notificação.
        
        Returns:
            Lista de canais
        """
        import json
        if not self.notification_channels:
            return []
        try:
            return json.loads(self.notification_channels)
        except:
            return []
    
    def acknowledge(self, user_id: str, notes: str = None):
        """
        Reconhece o alerta.
        
        Args:
            user_id: ID do usuário que reconheceu
            notes: Notas opcionais
        """
        from datetime import datetime
        
        self.status = AlertStatus.ACKNOWLEDGED
        self.acknowledged_at = datetime.utcnow()
        self.acknowledged_by = user_id
        
        if notes:
            self.resolution_notes = notes
    
    def resolve(self, user_id: str, notes: str = None):
        """
        Resolve o alerta.
        
        Args:
            user_id: ID do usuário que resolveu
            notes: Notas de resolução
        """
        from datetime import datetime
        
        self.status = AlertStatus.RESOLVED
        self.resolved_at = datetime.utcnow()
        self.resolved_by = user_id
        
        if notes:
            self.resolution_notes = notes
    
    def suppress(self, duration_hours: int = 24, reason: str = None):
        """
        Suprime o alerta por um período.
        
        Args:
            duration_hours: Duração da supressão em horas
            reason: Razão da supressão
        """
        from datetime import datetime, timedelta
        
        self.status = AlertStatus.SUPPRESSED
        self.suppressed_until = datetime.utcnow() + timedelta(hours=duration_hours)
        
        if reason:
            self.suppression_reason = reason
    
    def calculate_priority_score(self) -> int:
        """
        Calcula score de prioridade do alerta.
        
        Returns:
            Score de prioridade (1-100)
        """
        base_score = 0
        
        # Score baseado na severidade
        severity_scores = {
            AlertSeverity.LOW: 10,
            AlertSeverity.MEDIUM: 30,
            AlertSeverity.HIGH: 60,
            AlertSeverity.CRITICAL: 90
        }
        base_score += severity_scores.get(self.severity, 10)
        
        # Score baseado no tipo
        type_scores = {
            AlertType.FAILED_QUERY: 20,
            AlertType.TIMEOUT: 15,
            AlertType.SLOW_QUERY: 10,
            AlertType.HIGH_COST: 15,
            AlertType.MEMORY_SPILL: 10,
            AlertType.RESOURCE_EXHAUSTION: 25,
            AlertType.UNUSUAL_PATTERN: 5
        }
        base_score += type_scores.get(self.alert_type, 5)
        
        return min(base_score, 100)
    
    def get_alert_summary(self) -> dict:
        """
        Retorna resumo do alerta.
        
        Returns:
            Dicionário com resumo
        """
        return {
            "alert_id": str(self.alert_id),
            "type": self.alert_type.value,
            "severity": self.severity.value,
            "status": self.status.value,
            "title": self.alert_title,
            "priority_score": self.calculate_priority_score(),
            "is_suppressed": self.is_suppressed,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "threshold_value": self.threshold_value,
            "actual_value": self.actual_value,
            "metric_name": self.metric_name
        }

