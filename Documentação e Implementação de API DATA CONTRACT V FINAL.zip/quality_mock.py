"""
Mock data generation for Quality domain.

Generates realistic test data for quality rules, executions, and results.

Author: Carlos Morais <carlos.morais@f1rst.com.br>
Date: July 2025
"""

import uuid
from datetime import datetime, timedelta
from typing import List, Dict, Any
from faker import Faker
import random

fake = Faker('pt_BR')


def generate_quality_rules(count: int = 30) -> List[Dict[str, Any]]:
    """Generate mock quality rules."""
    
    rules = []
    rule_types = [
        "completeness", "uniqueness", "validity", "consistency", 
        "accuracy", "timeliness", "referential_integrity", "format_compliance"
    ]
    categories = [
        "data_quality", "business_rules", "compliance", "technical_validation",
        "data_integrity", "performance", "security", "governance"
    ]
    severities = ["low", "medium", "high", "critical"]
    frequencies = ["hourly", "daily", "weekly", "monthly"]
    
    data_sources = ["snowflake", "databricks", "redshift", "bigquery", "postgres", "mysql"]
    databases = ["prod_db", "staging_db", "analytics_db", "warehouse_db"]
    schemas = ["public", "finance", "marketing", "sales", "customer", "operations"]
    
    tables = [
        "customers", "orders", "products", "transactions", "campaigns",
        "users", "accounts", "payments", "inventory", "shipments"
    ]
    
    for i in range(count):
        rule_id = f"QR-{fake.random_int(1000, 9999)}"
        rule_type = random.choice(rule_types)
        category = random.choice(categories)
        data_source = random.choice(data_sources)
        database = random.choice(databases)
        schema = random.choice(schemas)
        table = random.choice(tables)
        
        # Generate rule definition based on type
        rule_definition = generate_rule_definition(rule_type, table)
        
        # Generate threshold based on rule type
        threshold_value, threshold_operator = generate_threshold(rule_type)
        
        rule = {
            "id": str(uuid.uuid4()),
            "rule_id": rule_id,
            "name": f"{rule_type.title()} Check - {table.title()}",
            "description": fake.text(max_nb_chars=300),
            "rule_type": rule_type,
            "category": category,
            "severity": random.choice(severities),
            "data_source": data_source,
            "database_name": database,
            "schema_name": schema,
            "table_name": table,
            "column_name": random.choice([None, "email", "phone", "amount", "date", "status"]),
            "rule_definition": rule_definition,
            "rule_logic": fake.text(max_nb_chars=200),
            "threshold_value": threshold_value,
            "threshold_operator": threshold_operator,
            "execution_frequency": random.choice(frequencies),
            "execution_schedule": generate_cron_schedule(random.choice(frequencies)),
            "is_enabled": random.choice([True, True, True, False]),  # 75% enabled
            "execution_count": random.randint(0, 100),
            "last_execution": fake.date_time_between(start_date='-30d', end_date='now') if random.random() > 0.2 else None,
            "last_result": random.choice(["passed", "failed", "error"]) if random.random() > 0.2 else None,
            "success_rate": round(random.uniform(0.7, 0.99), 3),
            "rule_config": generate_rule_config(rule_type),
            "proprietario": fake.name(),
            "responsavel_tecnico": fake.name(),
            "ativo": True,
            "criado_por": fake.name(),
            "atualizado_por": fake.name(),
            "data_criacao": fake.date_time_between(start_date='-1y', end_date='-1m'),
            "data_atualizacao": fake.date_time_between(start_date='-1m', end_date='now')
        }
        
        rules.append(rule)
    
    return rules


def generate_quality_executions(rules: List[Dict], executions_per_rule: int = 5) -> List[Dict[str, Any]]:
    """Generate mock quality executions."""
    
    executions = []
    execution_types = ["scheduled", "manual", "triggered"]
    execution_modes = ["full", "incremental", "sample"]
    execution_statuses = ["pending", "running", "completed", "failed", "cancelled"]
    
    for rule in rules:
        for exec_num in range(executions_per_rule):
            execution_id = f"exec_{rule['rule_id']}_{fake.random_int(1000, 9999)}"
            
            started_at = fake.date_time_between(start_date='-30d', end_date='now')
            duration = random.randint(30, 3600)  # 30 seconds to 1 hour
            completed_at = started_at + timedelta(seconds=duration)
            
            status = random.choice(execution_statuses)
            if status in ["pending", "running"]:
                completed_at = None
                duration = None
            
            # Generate realistic metrics
            total_records = random.randint(1000, 1000000)
            if status == "completed":
                passed_records = random.randint(int(total_records * 0.7), total_records)
                failed_records = total_records - passed_records
                success_rate = passed_records / total_records
                quality_score = round(random.uniform(0.7, 0.99), 3)
            else:
                passed_records = None
                failed_records = None
                success_rate = None
                quality_score = None
            
            execution = {
                "id": str(uuid.uuid4()),
                "execution_id": execution_id,
                "rule_id": rule["id"],
                "execution_type": random.choice(execution_types),
                "execution_mode": random.choice(execution_modes),
                "data_source": rule["data_source"],
                "dataset_name": rule["database_name"],
                "table_name": rule["table_name"],
                "started_at": started_at,
                "completed_at": completed_at,
                "duration_seconds": duration,
                "total_records": total_records,
                "passed_records": passed_records,
                "failed_records": failed_records,
                "success_rate": success_rate,
                "quality_score": quality_score,
                "execution_status": status,
                "error_message": fake.text(max_nb_chars=200) if status == "failed" else None,
                "error_details": {"error_code": "QE001", "details": fake.text()} if status == "failed" else None,
                "cpu_usage": round(random.uniform(10, 90), 2) if status == "completed" else None,
                "memory_usage": round(random.uniform(20, 80), 2) if status == "completed" else None,
                "io_operations": random.randint(100, 10000) if status == "completed" else None,
                "execution_config": generate_execution_config(),
                "result_summary": generate_result_summary() if status == "completed" else None,
                "result_details": generate_result_details() if status == "completed" else None,
                "sample_size": random.randint(1000, 10000) if random.random() > 0.7 else None,
                "sample_method": random.choice(["random", "systematic", "stratified"]) if random.random() > 0.7 else None,
                "notifications_sent": random.choice([True, False]),
                "ativo": True,
                "criado_por": "system",
                "data_criacao": started_at
            }
            
            executions.append(execution)
    
    return executions


def generate_quality_results(executions: List[Dict], results_per_execution: int = 10) -> List[Dict[str, Any]]:
    """Generate mock quality results."""
    
    results = []
    check_types = [
        "null_check", "format_check", "range_check", "uniqueness_check",
        "referential_check", "pattern_check", "business_rule_check"
    ]
    severities = ["low", "medium", "high", "critical"]
    resolution_statuses = ["open", "investigating", "resolved", "ignored"]
    
    for execution in executions:
        if execution["execution_status"] != "completed":
            continue
            
        for result_num in range(results_per_execution):
            result_id = f"result_{execution['execution_id']}_{result_num}"
            check_type = random.choice(check_types)
            passed = random.choice([True, True, True, False])  # 75% pass rate
            
            result = {
                "id": str(uuid.uuid4()),
                "result_id": result_id,
                "execution_id": execution["id"],
                "rule_id": execution["rule_id"],
                "check_name": f"{check_type.replace('_', ' ').title()}",
                "check_type": check_type,
                "passed": passed,
                "severity": random.choice(severities),
                "record_id": f"rec_{fake.random_int(1000, 9999)}",
                "record_key": fake.uuid4(),
                "expected_value": fake.word() if random.random() > 0.5 else None,
                "actual_value": fake.word() if random.random() > 0.5 else None,
                "threshold_value": round(random.uniform(0.8, 0.99), 3) if random.random() > 0.5 else None,
                "deviation": round(random.uniform(-0.1, 0.1), 3) if not passed else None,
                "confidence_score": round(random.uniform(0.7, 0.99), 3),
                "error_message": fake.text(max_nb_chars=100) if not passed else None,
                "error_code": f"QR{fake.random_int(100, 999)}" if not passed else None,
                "column_name": random.choice(["email", "phone", "amount", "date", "status"]),
                "table_name": execution["table_name"],
                "schema_name": execution["dataset_name"],
                "check_timestamp": execution["started_at"] + timedelta(minutes=random.randint(1, 60)),
                "context_data": generate_context_data(),
                "is_anomaly": random.choice([True, False]) if not passed else False,
                "anomaly_score": round(random.uniform(0.7, 0.99), 3) if not passed and random.random() > 0.5 else None,
                "anomaly_type": random.choice(["outlier", "pattern", "trend"]) if not passed and random.random() > 0.5 else None,
                "business_impact": random.choice(["low", "medium", "high"]) if not passed else None,
                "technical_impact": random.choice(["low", "medium", "high"]) if not passed else None,
                "resolution_status": random.choice(resolution_statuses) if not passed else "resolved",
                "resolution_notes": fake.text(max_nb_chars=200) if not passed and random.random() > 0.5 else None,
                "resolved_at": fake.date_time_between(start_date=execution["started_at"], end_date='now') if not passed and random.random() > 0.3 else None,
                "resolved_by": fake.name() if not passed and random.random() > 0.3 else None,
                "ativo": True,
                "criado_por": "system",
                "data_criacao": execution["started_at"]
            }
            
            results.append(result)
    
    return results


def generate_rule_definition(rule_type: str, table: str) -> str:
    """Generate realistic rule definition based on type."""
    
    definitions = {
        "completeness": f"SELECT COUNT(*) as total, COUNT(CASE WHEN column_name IS NOT NULL THEN 1 END) as non_null FROM {table}",
        "uniqueness": f"SELECT COUNT(*) as total, COUNT(DISTINCT column_name) as unique_count FROM {table}",
        "validity": f"SELECT COUNT(*) as total, COUNT(CASE WHEN column_name ~ '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{{2,}}$' THEN 1 END) as valid FROM {table}",
        "consistency": f"SELECT COUNT(*) FROM {table} WHERE status IN ('active', 'inactive', 'pending')",
        "accuracy": f"SELECT AVG(CASE WHEN amount > 0 THEN 1 ELSE 0 END) as accuracy FROM {table}",
        "timeliness": f"SELECT COUNT(*) FROM {table} WHERE created_at >= CURRENT_DATE - INTERVAL '1 day'",
        "referential_integrity": f"SELECT COUNT(*) FROM {table} t LEFT JOIN reference_table r ON t.ref_id = r.id WHERE r.id IS NULL",
        "format_compliance": f"SELECT COUNT(*) as total, COUNT(CASE WHEN phone ~ '^\\+?[1-9]\\d{{1,14}}$' THEN 1 END) as valid FROM {table}"
    }
    
    return definitions.get(rule_type, f"SELECT COUNT(*) FROM {table}")


def generate_threshold(rule_type: str) -> tuple:
    """Generate realistic threshold value and operator."""
    
    thresholds = {
        "completeness": (0.95, ">="),
        "uniqueness": (0.99, ">="),
        "validity": (0.90, ">="),
        "consistency": (0.95, ">="),
        "accuracy": (0.85, ">="),
        "timeliness": (0.80, ">="),
        "referential_integrity": (0, "="),
        "format_compliance": (0.90, ">=")
    }
    
    return thresholds.get(rule_type, (0.90, ">="))


def generate_cron_schedule(frequency: str) -> str:
    """Generate cron schedule based on frequency."""
    
    schedules = {
        "hourly": "0 * * * *",
        "daily": "0 2 * * *",
        "weekly": "0 2 * * 1",
        "monthly": "0 2 1 * *"
    }
    
    return schedules.get(frequency, "0 2 * * *")


def generate_rule_config(rule_type: str) -> Dict[str, Any]:
    """Generate rule configuration."""
    
    return {
        "timeout_seconds": random.randint(300, 3600),
        "retry_count": random.randint(1, 3),
        "notification_enabled": random.choice([True, False]),
        "alert_threshold": round(random.uniform(0.8, 0.95), 2),
        "sampling_enabled": random.choice([True, False]),
        "parallel_execution": random.choice([True, False])
    }


def generate_execution_config() -> Dict[str, Any]:
    """Generate execution configuration."""
    
    return {
        "mode": random.choice(["full", "incremental", "sample"]),
        "timeout": random.randint(300, 3600),
        "parallel_workers": random.randint(1, 8),
        "memory_limit_mb": random.randint(512, 4096),
        "enable_caching": random.choice([True, False])
    }


def generate_result_summary() -> Dict[str, Any]:
    """Generate result summary."""
    
    return {
        "total_checks": random.randint(5, 20),
        "passed_checks": random.randint(3, 18),
        "failed_checks": random.randint(0, 5),
        "critical_issues": random.randint(0, 2),
        "warnings": random.randint(0, 5),
        "execution_time_ms": random.randint(1000, 60000)
    }


def generate_result_details() -> Dict[str, Any]:
    """Generate detailed results."""
    
    return {
        "check_details": [
            {
                "check_name": "null_check",
                "status": "passed",
                "message": "No null values found"
            },
            {
                "check_name": "format_check", 
                "status": "failed",
                "message": "Invalid email format detected"
            }
        ],
        "performance_metrics": {
            "rows_processed": random.randint(1000, 100000),
            "processing_rate": random.randint(100, 1000),
            "memory_peak_mb": random.randint(100, 1000)
        }
    }


def generate_context_data() -> Dict[str, Any]:
    """Generate context data."""
    
    return {
        "table_size": random.randint(1000, 1000000),
        "last_updated": fake.date_time_between(start_date='-7d', end_date='now').isoformat(),
        "data_source_version": f"{random.randint(1, 5)}.{random.randint(0, 9)}",
        "partition_info": f"date={fake.date()}",
        "schema_version": f"{random.randint(1, 3)}.0"
    }


def generate_mock_quality_sql() -> str:
    """Generate SQL INSERT statements for mock quality data."""
    
    rules = generate_quality_rules(15)
    executions = generate_quality_executions(rules, 3)
    results = generate_quality_results(executions, 5)
    
    sql_statements = []
    
    # Quality Rules
    sql_statements.append("-- Quality Rules Mock Data")
    sql_statements.append("INSERT INTO quality_rules (")
    sql_statements.append("    id, rule_id, name, description, rule_type, category, severity,")
    sql_statements.append("    data_source, database_name, schema_name, table_name, column_name,")
    sql_statements.append("    rule_definition, rule_logic, threshold_value, threshold_operator,")
    sql_statements.append("    execution_frequency, execution_schedule, is_enabled, execution_count,")
    sql_statements.append("    last_execution, last_result, success_rate, rule_config,")
    sql_statements.append("    proprietario, responsavel_tecnico, ativo, criado_por, atualizado_por,")
    sql_statements.append("    data_criacao, data_atualizacao")
    sql_statements.append(") VALUES")
    
    rule_values = []
    for rule in rules:
        values = f"""(
    '{rule["id"]}', '{rule["rule_id"]}', '{rule["name"]}', '{rule["description"]}',
    '{rule["rule_type"]}', '{rule["category"]}', '{rule["severity"]}',
    '{rule["data_source"]}', '{rule["database_name"]}', '{rule["schema_name"]}',
    '{rule["table_name"]}', {'NULL' if not rule["column_name"] else f"'{rule['column_name']}'"},
    '{rule["rule_definition"]}', '{rule["rule_logic"]}',
    {rule["threshold_value"]}, '{rule["threshold_operator"]}',
    '{rule["execution_frequency"]}', '{rule["execution_schedule"]}',
    {rule["is_enabled"]}, {rule["execution_count"]},
    {'NULL' if not rule["last_execution"] else f"'{rule['last_execution']}'"},
    {'NULL' if not rule["last_result"] else f"'{rule['last_result']}'"},
    {rule["success_rate"]}, '{str(rule["rule_config"]).replace("'", "''")}'::jsonb,
    '{rule["proprietario"]}', '{rule["responsavel_tecnico"]}', {rule["ativo"]},
    '{rule["criado_por"]}', '{rule["atualizado_por"]}',
    '{rule["data_criacao"]}', '{rule["data_atualizacao"]}'
)"""
        rule_values.append(values)
    
    sql_statements.append(",\n".join(rule_values))
    sql_statements.append(";\n")
    
    return "\n".join(sql_statements)


if __name__ == "__main__":
    # Generate and print sample data
    rules = generate_quality_rules(5)
    print("Sample Quality Rules:")
    for rule in rules:
        print(f"- {rule['name']} ({rule['rule_id']}) - {rule['rule_type']}")
    
    executions = generate_quality_executions(rules, 2)
    print(f"\nGenerated {len(rules)} rules and {len(executions)} executions")
    
    # Generate SQL
    sql = generate_mock_quality_sql()
    print(f"\nSQL length: {len(sql)} characters")

