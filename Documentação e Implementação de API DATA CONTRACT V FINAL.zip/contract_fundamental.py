"""
Contract Fundamental model.
"""

from sqlalchemy import Column, ForeignKey, Text
from sqlalchemy.dialects.postgresql import UUID as PostgresUUID
from sqlalchemy.orm import relationship

from app.models.base import BaseModel


class ContractFundamental(BaseModel):
    """
    Contract Fundamental model.
    
    Fundamental and contextual information of the contract.
    """

    __tablename__ = "contract_fundamentals"

    # Foreign key to contract
    contract_id = Column(
        PostgresUUID(as_uuid=True),
        ForeignKey("data_contracts.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
        doc="Reference to contract"
    )

    # Fundamental information
    purpose = Column(
        Text,
        doc="Purpose and objective of the contract"
    )

    scope = Column(
        Text,
        doc="Scope of application"
    )

    assumptions = Column(
        Text,
        doc="Assumptions and suppositions"
    )

    limitations = Column(
        Text,
        doc="Known limitations"
    )

    dependencies = Column(
        Text,
        doc="External dependencies"
    )

    # Relationships
    contract = relationship(
        "DataContract",
        back_populates="fundamentals"
    )

    def __repr__(self) -> str:
        return f"<ContractFundamental(contract_id={self.contract_id})>"

