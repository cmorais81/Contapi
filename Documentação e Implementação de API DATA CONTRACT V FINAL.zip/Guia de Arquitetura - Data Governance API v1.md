# Guia de Arquitetura - Data Governance API v1

**Versão:** 1.0.0  
**Autor:** Carlos Morais (carlos.morais@f1rst.com.br)  
**Data:** Julho 2025

## Visão Geral da Arquitetura

A Data Governance API foi desenvolvida seguindo os princípios de **Clean Architecture** e **Domain-Driven Design (DDD)**, organizando o código em domínios de negócio bem definidos. Esta abordagem garante alta manutenibilidade, testabilidade e escalabilidade.

## Estrutura de Pastas Detalhada

### 📁 **Raiz do Projeto**

```
data-governance-api-v1/
├── app/                    # Código fonte principal da aplicação
├── tests/                  # Testes automatizados organizados por domínio
├── docs/                   # Documentação técnica e de usuário
├── scripts/                # Scripts de automação e deployment
├── deployment/             # Configurações de deployment (Windows/Azure)
├── migrations/             # Migrations do banco de dados (Alembic)
├── requirements.txt        # Dependências Python
├── pyproject.toml         # Configuração do projeto Python
├── docker-compose.yml     # Configuração Docker para desenvolvimento
├── Dockerfile             # Imagem Docker da aplicação
└── README_v1.md           # Documentação principal
```

### 📁 **app/ - Código Fonte Principal**

#### **Justificativa da Organização por Domínios:**

A estrutura foi organizada seguindo **Domain-Driven Design**, onde cada pasta representa um domínio de negócio específico. Isso oferece:

- **Coesão Alta**: Código relacionado fica junto
- **Acoplamento Baixo**: Domínios são independentes
- **Manutenibilidade**: Fácil localização e modificação
- **Escalabilidade**: Novos domínios podem ser adicionados facilmente
- **Testabilidade**: Testes organizados por contexto de negócio

```
app/
├── core/                   # Configurações centrais e infraestrutura
├── models/                 # Modelos SQLAlchemy organizados por domínio
├── schemas/                # Schemas Pydantic organizados por domínio
├── api/                    # Endpoints FastAPI organizados por domínio
├── services/               # Lógica de negócio organizada por domínio
├── utils/                  # Utilitários compartilhados
└── main_v1.py             # Aplicação principal FastAPI
```

### 📁 **core/ - Infraestrutura Central**

**Justificativa:** Centraliza configurações e componentes de infraestrutura que são compartilhados por toda a aplicação.

```
core/
├── config_v1.py           # Configurações da aplicação (settings)
├── database_v1.py         # Configuração do banco de dados
├── security_v1.py         # Autenticação e autorização
├── exceptions_v1.py       # Exceções customizadas
└── middleware_v1.py       # Middlewares customizados
```

**Por que separar?**
- **Reutilização**: Componentes usados em múltiplos domínios
- **Configuração Centralizada**: Single source of truth
- **Segurança**: Isolamento de componentes críticos
- **Manutenção**: Mudanças de infraestrutura em local único

### 📁 **models/ - Modelos de Dados por Domínio**

**Justificativa:** Organização por domínio de negócio facilita compreensão e manutenção dos modelos de dados.

```
models/
├── contracts/              # Modelos de contratos de dados
│   ├── data_contract_v1.py
│   ├── contract_version_v1.py
│   ├── contract_layout_v1.py
│   └── contract_custom_property_v1.py
├── quality/                # Modelos de qualidade de dados
│   ├── quality_rule_v1.py
│   ├── quality_execution_v1.py
│   ├── quality_result_v1.py
│   └── data_quality_aggregate_v1.py
├── lineage/                # Modelos de linhagem de dados
├── entities/               # Modelos de entidades e tags
├── users/                  # Modelos de usuários e permissões
├── privacy/                # Modelos de privacidade e compliance
├── monitoring/             # Modelos de monitoramento e métricas
├── governance/             # Modelos de políticas de governança
├── integrations/           # Modelos de integrações externas
├── audit/                  # Modelos de auditoria e logs
└── base_v1.py             # Modelo base com funcionalidades comuns
```

**Benefícios da Organização:**
- **Contexto de Negócio**: Modelos agrupados por função
- **Relacionamentos Claros**: Dependências dentro do domínio
- **Evolução Independente**: Domínios podem evoluir separadamente
- **Compreensão Facilitada**: Desenvolvedores focam em um domínio

### 📁 **schemas/ - Validação e Serialização por Domínio**

**Justificativa:** Schemas Pydantic organizados por domínio garantem validação consistente e documentação automática da API.

```
schemas/
├── contracts/              # Schemas para contratos de dados
│   └── data_contract_v1.py # Create, Update, Response, List schemas
├── quality/                # Schemas para qualidade de dados
├── lineage/                # Schemas para linhagem de dados
├── entities/               # Schemas para entidades e tags
├── users/                  # Schemas para usuários e autenticação
├── privacy/                # Schemas para privacidade e compliance
├── monitoring/             # Schemas para monitoramento e métricas
├── governance/             # Schemas para políticas de governança
├── integrations/           # Schemas para integrações externas
├── audit/                  # Schemas para auditoria e logs
└── base_v1.py             # Schemas base e utilitários
```

**Vantagens:**
- **Validação Automática**: Pydantic valida dados de entrada
- **Documentação OpenAPI**: Schemas geram documentação automática
- **Type Safety**: Tipagem forte em Python
- **Serialização Consistente**: Formato padronizado de resposta

### 📁 **api/ - Endpoints Organizados por Domínio**

**Justificativa:** Endpoints organizados por domínio facilitam navegação na documentação e manutenção do código.

```
api/
└── v1/                     # Versão 1 da API
    ├── endpoints/          # Endpoints organizados por domínio
    │   ├── contracts/      # Endpoints de contratos
    │   │   └── data_contracts_v1.py
    │   ├── quality/        # Endpoints de qualidade
    │   ├── lineage/        # Endpoints de linhagem
    │   ├── entities/       # Endpoints de entidades
    │   ├── users/          # Endpoints de usuários
    │   ├── privacy/        # Endpoints de privacidade
    │   ├── monitoring/     # Endpoints de monitoramento
    │   ├── governance/     # Endpoints de governança
    │   ├── integrations/   # Endpoints de integrações
    │   └── audit/          # Endpoints de auditoria
    └── api_v1.py          # Router principal da API v1
```

**Benefícios:**
- **Documentação Organizada**: Swagger agrupa por tags
- **Manutenção Focada**: Mudanças isoladas por domínio
- **Versionamento**: Suporte a múltiplas versões da API
- **Responsabilidade Única**: Cada endpoint tem função específica

### 📁 **services/ - Lógica de Negócio por Domínio**

**Justificativa:** Services implementam a lógica de negócio complexa, mantendo controllers (endpoints) simples e focados.

```
services/
├── contracts/              # Lógica de negócio para contratos
│   └── data_contract_service_v1.py
├── quality/                # Lógica de negócio para qualidade
├── lineage/                # Lógica de negócio para linhagem
├── entities/               # Lógica de negócio para entidades
├── users/                  # Lógica de negócio para usuários
├── privacy/                # Lógica de negócio para privacidade
├── monitoring/             # Lógica de negócio para monitoramento
├── governance/             # Lógica de negócio para governança
├── integrations/           # Lógica de negócio para integrações
└── audit/                  # Lógica de negócio para auditoria
```

**Vantagens:**
- **Separação de Responsabilidades**: Controllers vs Business Logic
- **Reutilização**: Services podem ser usados por múltiplos endpoints
- **Testabilidade**: Lógica de negócio isolada e testável
- **Complexidade Gerenciada**: Operações complexas em local apropriado

### 📁 **tests/ - Testes Organizados por Domínio**

**Justificativa:** Testes organizados por domínio facilitam execução seletiva e manutenção.

```
tests/
├── unit/                   # Testes unitários por domínio
│   ├── contracts/
│   ├── quality/
│   ├── lineage/
│   └── ...
├── integration/            # Testes de integração por domínio
│   ├── contracts/
│   ├── quality/
│   └── ...
├── e2e/                    # Testes end-to-end
├── fixtures/               # Fixtures compartilhadas
└── conftest.py            # Configuração pytest
```

**Benefícios:**
- **Execução Seletiva**: Testar apenas domínio modificado
- **Isolamento**: Falhas não afetam outros domínios
- **Cobertura Organizada**: Métricas por domínio
- **Manutenção Facilitada**: Testes próximos ao código testado

## Princípios Arquiteturais Aplicados

### 1. **Domain-Driven Design (DDD)**
- **Domínios Bem Definidos**: Cada pasta representa um contexto de negócio
- **Linguagem Ubíqua**: Nomenclatura consistente entre código e negócio
- **Bounded Contexts**: Limites claros entre domínios

### 2. **Clean Architecture**
- **Dependências Invertidas**: Core não depende de detalhes
- **Separação de Camadas**: Models, Services, Controllers, Schemas
- **Testabilidade**: Cada camada pode ser testada isoladamente

### 3. **SOLID Principles**
- **Single Responsibility**: Cada classe/módulo tem uma responsabilidade
- **Open/Closed**: Extensível sem modificar código existente
- **Liskov Substitution**: Subtipos substituíveis
- **Interface Segregation**: Interfaces específicas
- **Dependency Inversion**: Depender de abstrações

### 4. **API-First Design**
- **OpenAPI 3.0+**: Especificação completa da API
- **Documentação Automática**: Swagger/ReDoc gerados automaticamente
- **Versionamento**: Suporte a múltiplas versões
- **Padronização**: Responses e errors consistentes

## Benefícios da Arquitetura Escolhida

### **Para Desenvolvedores:**
- **Navegação Intuitiva**: Fácil localização de código
- **Contexto Claro**: Entendimento rápido do domínio
- **Manutenção Simplificada**: Mudanças isoladas
- **Onboarding Rápido**: Estrutura autoexplicativa

### **Para o Negócio:**
- **Time to Market**: Desenvolvimento paralelo por domínios
- **Qualidade**: Testes organizados e abrangentes
- **Escalabilidade**: Adição de novos domínios sem impacto
- **Manutenibilidade**: Custos reduzidos de manutenção

### **Para Operações:**
- **Monitoramento**: Métricas por domínio
- **Deployment**: Deploy independente por funcionalidade
- **Troubleshooting**: Isolamento de problemas
- **Performance**: Otimização focada

## Padrões de Nomenclatura

### **Arquivos:**
- **Sufixo _v1**: Versionamento claro (ex: `data_contract_v1.py`)
- **Snake_case**: Padrão Python (ex: `quality_rule_v1.py`)
- **Descritivo**: Nome indica função (ex: `data_contract_service_v1.py`)

### **Classes:**
- **PascalCase**: Padrão Python (ex: `DataContract`)
- **Sufixos Descritivos**: Service, Schema, Response (ex: `DataContractService`)

### **Variáveis e Funções:**
- **Snake_case**: Padrão Python (ex: `contract_id`)
- **Verbos para Funções**: create_contract, validate_schema

## Evolução e Extensibilidade

### **Adicionando Novo Domínio:**
1. Criar pasta em `models/novo_dominio/`
2. Criar pasta em `schemas/novo_dominio/`
3. Criar pasta em `api/v1/endpoints/novo_dominio/`
4. Criar pasta em `services/novo_dominio/`
5. Criar pasta em `tests/unit/novo_dominio/`
6. Atualizar router principal

### **Versionamento da API:**
- **Pasta v2**: Nova versão sem quebrar v1
- **Backward Compatibility**: Manter versões anteriores
- **Deprecation**: Processo gradual de descontinuação

Esta arquitetura garante que a Data Governance API seja robusta, escalável e facilmente mantida por equipes de desenvolvimento de qualquer tamanho.

