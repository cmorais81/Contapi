"""
Integration endpoints.
"""

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db

router = APIRouter()


@router.get("/", summary="List integrations")
async def list_integrations(db: AsyncSession = Depends(get_db)):
    """List all integration configurations."""
    return {"message": "Integration listing not yet implemented"}


@router.post("/", summary="Create integration")
async def create_integration(db: AsyncSession = Depends(get_db)):
    """Create a new integration configuration."""
    raise HTTPException(status_code=status.HTTP_501_NOT_IMPLEMENTED, detail="Integration creation not yet implemented")


@router.post("/{integration_id}/sync", summary="Trigger sync")
async def trigger_sync(integration_id: str, db: AsyncSession = Depends(get_db)):
    """Trigger synchronization for an integration."""
    raise HTTPException(status_code=status.HTTP_501_NOT_IMPLEMENTED, detail="Sync trigger not yet implemented")


@router.get("/{integration_id}/status", summary="Get sync status")
async def get_sync_status(integration_id: str, db: AsyncSession = Depends(get_db)):
    """Get synchronization status for an integration."""
    return {"message": "Sync status not yet implemented"}

