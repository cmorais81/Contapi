"""
Job Metric model.
"""

from sqlalchemy import Column, DateTime, ForeignKey, String
from sqlalchemy.dialects.postgresql import UUID as PostgresUUID
from sqlalchemy.orm import relationship

from app.models.base import BaseModel
from app.models.mixins import MetricsMixin


class JobMetric(BaseModel, MetricsMixin):
    """
    Job Metric model.
    
    Databricks job execution metrics.
    """

    __tablename__ = "job_metrics"

    # Foreign key to contract
    contract_id = Column(
        PostgresUUID(as_uuid=True),
        ForeignKey("data_contracts.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
        doc="Reference to contract"
    )

    # Job identification
    job_id = Column(
        String(255),
        nullable=False,
        index=True,
        doc="Databricks job ID"
    )

    job_name = Column(
        String(255),
        doc="Job name"
    )

    run_id = Column(
        String(255),
        nullable=False,
        index=True,
        doc="Job run ID"
    )

    # Execution details
    job_status = Column(
        String(50),
        nullable=False,
        index=True,
        doc="Job status: running, succeeded, failed, cancelled"
    )

    start_time = Column(
        DateTime(timezone=True),
        doc="Job start time"
    )

    end_time = Column(
        DateTime(timezone=True),
        doc="Job end time"
    )

    # Performance metrics
    records_processed = Column(
        String(20),  # Using String to handle integer as text
        doc="Number of records processed"
    )

    bytes_processed = Column(
        String(20),  # Using String to handle integer as text
        doc="Bytes processed"
    )

    shuffle_read_bytes = Column(
        String(20),  # Using String to handle integer as text
        doc="Shuffle read bytes"
    )

    shuffle_write_bytes = Column(
        String(20),  # Using String to handle integer as text
        doc="Shuffle write bytes"
    )

    # Resource usage
    executor_count = Column(
        String(10),  # Using String to handle integer as text
        doc="Number of executors"
    )

    total_cores = Column(
        String(10),  # Using String to handle integer as text
        doc="Total cores used"
    )

    total_memory_gb = Column(
        String(20),  # Using String to handle numeric as text
        doc="Total memory in GB"
    )

    # Cost metrics
    dbu_consumption = Column(
        String(20),  # Using String to handle numeric as text
        doc="DBU consumption"
    )

    cost_usd = Column(
        String(20),  # Using String to handle numeric as text
        doc="Cost in USD"
    )

    # Relationships
    contract = relationship(
        "DataContract",
        back_populates="job_metrics"
    )

    def __repr__(self) -> str:
        return f"<JobMetric(job_id={self.job_id}, run_id={self.run_id}, status={self.job_status})>"

