"""
Contract SLA Definition model.
"""

from sqlalchemy import Column, ForeignKey, String, Text
from sqlalchemy.dialects.postgresql import UUID as PostgresUUID
from sqlalchemy.orm import relationship

from app.models.base import BaseModel


class ContractSLADefinition(BaseModel):
    """
    Contract SLA Definition model.
    
    Service Level Agreement definitions.
    """

    __tablename__ = "contract_sla_definitions"

    # Foreign key to contract
    contract_id = Column(
        PostgresUUID(as_uuid=True),
        ForeignKey("data_contracts.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
        doc="Reference to contract"
    )

    # SLA definition
    sla_name = Column(
        String(255),
        nullable=False,
        doc="SLA name"
    )

    sla_description = Column(
        Text,
        doc="SLA description"
    )

    availability_target = Column(
        String(10),  # Using String to handle numeric as text
        doc="Availability target (percentage)"
    )

    response_time_target = Column(
        String(20),  # Using String to handle numeric as text
        doc="Response time target (milliseconds)"
    )

    throughput_target = Column(
        String(20),  # Using String to handle numeric as text
        doc="Throughput target (requests/second)"
    )

    recovery_time_objective = Column(
        String(20),  # Using String to handle numeric as text
        doc="Recovery time objective (minutes)"
    )

    recovery_point_objective = Column(
        String(20),  # Using String to handle numeric as text
        doc="Recovery point objective (minutes)"
    )

    # Relationships
    contract = relationship(
        "DataContract",
        back_populates="sla_definitions"
    )

    def __repr__(self) -> str:
        return f"<ContractSLADefinition(name={self.sla_name})>"

