"""
Quality Execution model.
"""

from sqlalchemy import Column, DateTime, ForeignKey, String, Text
from sqlalchemy.dialects.postgresql import UUID as PostgresUUID
from sqlalchemy.orm import relationship

from app.models.base import BaseModel
from app.models.mixins import MetricsMixin


class QualityExecution(BaseModel, MetricsMixin):
    """
    Quality Execution model.
    
    Execution instances of quality rules.
    """

    __tablename__ = "quality_executions"

    # Foreign key to quality rule
    quality_rule_id = Column(
        PostgresUUID(as_uuid=True),
        ForeignKey("quality_rules.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
        doc="Reference to quality rule"
    )

    # Execution information
    execution_status = Column(
        String(50),
        nullable=False,
        index=True,
        doc="Status: running, completed, failed, cancelled"
    )

    start_time = Column(
        DateTime(timezone=True),
        doc="Execution start time"
    )

    end_time = Column(
        DateTime(timezone=True),
        doc="Execution end time"
    )

    # Results summary
    total_records = Column(
        String(20),  # Using String to handle integer as text
        doc="Total records processed"
    )

    passed_records = Column(
        String(20),  # Using String to handle integer as text
        doc="Records that passed validation"
    )

    failed_records = Column(
        String(20),  # Using String to handle integer as text
        doc="Records that failed validation"
    )

    # Error handling
    error_message = Column(
        Text,
        doc="Error message if execution failed"
    )

    error_details = Column(
        Text,
        doc="Detailed error information"
    )

    # Relationships
    quality_rule = relationship(
        "QualityRule",
        back_populates="executions"
    )

    results = relationship(
        "QualityResult",
        back_populates="execution",
        cascade="all, delete-orphan"
    )

    def __repr__(self) -> str:
        return f"<QualityExecution(status={self.execution_status}, rule_id={self.quality_rule_id})>"

