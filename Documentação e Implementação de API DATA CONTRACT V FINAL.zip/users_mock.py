"""
Mock data generation for Users domain.

Generates realistic test data for users, roles, and user-role assignments.

Author: Carlos Morais <carlos.morais@f1rst.com.br>
Date: July 2025
"""

import uuid
from datetime import datetime, timedelta
from typing import List, Dict, Any
from faker import Faker
import random

fake = Faker('pt_BR')


def generate_roles(count: int = 15) -> List[Dict[str, Any]]:
    """Generate mock roles."""
    
    base_roles = [
        {
            "name": "admin",
            "display_name": "System Administrator",
            "description": "Full system access and administration privileges",
            "level": 1,
            "permissions": ["*"]
        },
        {
            "name": "data_governance_lead",
            "display_name": "Data Governance Lead",
            "description": "Lead data governance initiatives and policies",
            "level": 2,
            "permissions": ["governance.*", "contracts.*", "quality.*", "audit.read"]
        },
        {
            "name": "data_steward",
            "display_name": "Data Steward",
            "description": "Manage data quality and governance for specific domains",
            "level": 3,
            "permissions": ["contracts.read", "contracts.update", "quality.*", "entities.*"]
        },
        {
            "name": "data_analyst",
            "display_name": "Data Analyst",
            "description": "Analyze data and create reports",
            "level": 4,
            "permissions": ["contracts.read", "quality.read", "metrics.read", "entities.read"]
        },
        {
            "name": "data_engineer",
            "display_name": "Data Engineer",
            "description": "Build and maintain data pipelines",
            "level": 4,
            "permissions": ["contracts.read", "quality.read", "lineage.*", "integrations.*"]
        },
        {
            "name": "business_user",
            "display_name": "Business User",
            "description": "Access business data and reports",
            "level": 5,
            "permissions": ["contracts.read", "entities.read", "metrics.read"]
        },
        {
            "name": "compliance_officer",
            "display_name": "Compliance Officer",
            "description": "Ensure regulatory compliance",
            "level": 3,
            "permissions": ["governance.*", "privacy.*", "audit.*", "contracts.read"]
        },
        {
            "name": "security_analyst",
            "display_name": "Security Analyst",
            "description": "Monitor and manage data security",
            "level": 3,
            "permissions": ["privacy.*", "audit.*", "users.read", "governance.read"]
        }
    ]
    
    roles = []
    
    # Add base roles
    for i, base_role in enumerate(base_roles):
        role = {
            "id": str(uuid.uuid4()),
            "role_id": f"ROLE-{i+1:03d}",
            "name": base_role["name"],
            "display_name": base_role["display_name"],
            "description": base_role["description"],
            "role_type": "system" if base_role["name"] in ["admin"] else "business",
            "level": base_role["level"],
            "permissions": base_role["permissions"],
            "is_system_role": base_role["name"] in ["admin", "data_governance_lead"],
            "is_active": True,
            "max_users": random.randint(5, 50) if base_role["name"] != "admin" else 3,
            "approval_required": base_role["level"] <= 3,
            "role_metadata": {
                "department": random.choice(["IT", "Data", "Business", "Compliance"]),
                "cost_center": f"CC-{fake.random_int(1000, 9999)}",
                "created_by_system": True
            },
            "ativo": True,
            "criado_por": "system",
            "atualizado_por": "system",
            "data_criacao": fake.date_time_between(start_date='-2y', end_date='-1y'),
            "data_atualizacao": fake.date_time_between(start_date='-1y', end_date='-1m')
        }
        roles.append(role)
    
    # Add additional custom roles
    custom_role_names = [
        "domain_owner", "project_manager", "external_auditor", 
        "vendor_user", "read_only_user", "power_user", "guest_user"
    ]
    
    for i, role_name in enumerate(custom_role_names):
        if len(roles) >= count:
            break
            
        role = {
            "id": str(uuid.uuid4()),
            "role_id": f"ROLE-{len(roles)+1:03d}",
            "name": role_name,
            "display_name": role_name.replace("_", " ").title(),
            "description": fake.text(max_nb_chars=200),
            "role_type": "custom",
            "level": random.randint(3, 6),
            "permissions": generate_custom_permissions(),
            "is_system_role": False,
            "is_active": random.choice([True, True, True, False]),  # 75% active
            "max_users": random.randint(5, 30),
            "approval_required": random.choice([True, False]),
            "role_metadata": {
                "department": random.choice(["IT", "Data", "Business", "Compliance", "External"]),
                "cost_center": f"CC-{fake.random_int(1000, 9999)}",
                "created_by_system": False
            },
            "ativo": True,
            "criado_por": fake.name(),
            "atualizado_por": fake.name(),
            "data_criacao": fake.date_time_between(start_date='-1y', end_date='-1m'),
            "data_atualizacao": fake.date_time_between(start_date='-1m', end_date='now')
        }
        roles.append(role)
    
    return roles


def generate_users(count: int = 50) -> List[Dict[str, Any]]:
    """Generate mock users."""
    
    users = []
    departments = ["IT", "Data Engineering", "Analytics", "Business Intelligence", 
                  "Compliance", "Security", "Finance", "Marketing", "Sales", "Operations"]
    
    for i in range(count):
        first_name = fake.first_name()
        last_name = fake.last_name()
        username = f"{first_name.lower()}.{last_name.lower()}"
        email = f"{username}@{fake.domain_name()}"
        
        user = {
            "id": str(uuid.uuid4()),
            "user_id": f"USR-{i+1:04d}",
            "username": username,
            "email": email,
            "first_name": first_name,
            "last_name": last_name,
            "display_name": f"{first_name} {last_name}",
            "department": random.choice(departments),
            "job_title": fake.job(),
            "manager_email": fake.email() if random.random() > 0.3 else None,
            "phone": fake.phone_number() if random.random() > 0.4 else None,
            "location": fake.city(),
            "timezone": random.choice(["America/Sao_Paulo", "America/New_York", "Europe/London", "Asia/Tokyo"]),
            "language": random.choice(["pt-BR", "en-US", "es-ES"]),
            "is_active": random.choice([True, True, True, False]),  # 75% active
            "is_verified": random.choice([True, True, False]),  # 67% verified
            "is_external": random.choice([True, False, False, False]),  # 25% external
            "password_hash": fake.sha256(),
            "password_changed_at": fake.date_time_between(start_date='-6m', end_date='now'),
            "failed_login_attempts": random.randint(0, 3),
            "last_login": fake.date_time_between(start_date='-30d', end_date='now') if random.random() > 0.2 else None,
            "last_activity": fake.date_time_between(start_date='-7d', end_date='now') if random.random() > 0.1 else None,
            "account_locked": random.choice([True, False, False, False, False]),  # 20% locked
            "locked_until": fake.date_time_between(start_date='now', end_date='+1d') if random.random() > 0.9 else None,
            "two_factor_enabled": random.choice([True, True, False]),  # 67% 2FA enabled
            "two_factor_secret": fake.uuid4() if random.random() > 0.3 else None,
            "session_timeout_minutes": random.choice([30, 60, 120, 240]),
            "preferences": generate_user_preferences(),
            "user_metadata": {
                "employee_id": f"EMP-{fake.random_int(10000, 99999)}",
                "hire_date": fake.date_between(start_date='-5y', end_date='-1m').isoformat(),
                "cost_center": f"CC-{fake.random_int(1000, 9999)}",
                "security_clearance": random.choice(["public", "internal", "confidential", "restricted"])
            },
            "ativo": True,
            "criado_por": "system",
            "atualizado_por": fake.name(),
            "data_criacao": fake.date_time_between(start_date='-2y', end_date='-1m'),
            "data_atualizacao": fake.date_time_between(start_date='-1m', end_date='now')
        }
        
        users.append(user)
    
    return users


def generate_user_roles(users: List[Dict], roles: List[Dict]) -> List[Dict[str, Any]]:
    """Generate mock user-role assignments."""
    
    user_roles = []
    assignment_reasons = [
        "Initial role assignment", "Role change request", "Department transfer",
        "Project assignment", "Temporary access", "Compliance requirement"
    ]
    
    for user in users:
        # Each user gets 1-3 roles
        num_roles = random.randint(1, 3)
        assigned_roles = random.sample(roles, min(num_roles, len(roles)))
        
        for role in assigned_roles:
            # Skip if role is inactive
            if not role["is_active"]:
                continue
                
            assigned_at = fake.date_time_between(
                start_date=user["data_criacao"],
                end_date=user["data_atualizacao"]
            )
            
            # Some assignments are temporary
            is_temporary = random.choice([True, False, False, False])  # 25% temporary
            expires_at = None
            if is_temporary:
                expires_at = fake.date_time_between(start_date='now', end_date='+6m')
            
            user_role = {
                "id": str(uuid.uuid4()),
                "assignment_id": f"UA-{fake.random_int(10000, 99999)}",
                "user_id": user["id"],
                "role_id": role["id"],
                "assigned_by": fake.name(),
                "assigned_at": assigned_at,
                "assignment_reason": random.choice(assignment_reasons),
                "is_active": random.choice([True, True, True, False]),  # 75% active
                "is_temporary": is_temporary,
                "expires_at": expires_at,
                "approved_by": fake.name() if role["approval_required"] else None,
                "approved_at": assigned_at + timedelta(hours=random.randint(1, 48)) if role["approval_required"] else None,
                "revoked_by": fake.name() if random.random() > 0.9 else None,
                "revoked_at": fake.date_time_between(start_date=assigned_at, end_date='now') if random.random() > 0.9 else None,
                "revocation_reason": "Access no longer needed" if random.random() > 0.9 else None,
                "last_used": fake.date_time_between(start_date=assigned_at, end_date='now') if random.random() > 0.2 else None,
                "usage_count": random.randint(0, 100),
                "assignment_metadata": {
                    "source": random.choice(["manual", "automated", "bulk_import"]),
                    "project": fake.word() if random.random() > 0.5 else None,
                    "justification": fake.text(max_nb_chars=200)
                },
                "ativo": True,
                "criado_por": fake.name(),
                "data_criacao": assigned_at
            }
            
            user_roles.append(user_role)
    
    return user_roles


def generate_custom_permissions() -> List[str]:
    """Generate custom permissions for roles."""
    
    all_permissions = [
        "contracts.read", "contracts.create", "contracts.update", "contracts.delete",
        "quality.read", "quality.create", "quality.update", "quality.delete",
        "entities.read", "entities.create", "entities.update", "entities.delete",
        "users.read", "users.create", "users.update", "users.delete",
        "roles.read", "roles.create", "roles.update", "roles.delete",
        "governance.read", "governance.create", "governance.update", "governance.delete",
        "privacy.read", "privacy.create", "privacy.update", "privacy.delete",
        "audit.read", "audit.create", "metrics.read", "lineage.read",
        "integrations.read", "integrations.create", "integrations.update",
        "tags.read", "tags.create", "tags.update", "tags.delete"
    ]
    
    # Return random subset of permissions
    num_permissions = random.randint(3, 10)
    return random.sample(all_permissions, num_permissions)


def generate_user_preferences() -> Dict[str, Any]:
    """Generate user preferences."""
    
    return {
        "theme": random.choice(["light", "dark", "auto"]),
        "notifications": {
            "email": random.choice([True, False]),
            "browser": random.choice([True, False]),
            "slack": random.choice([True, False])
        },
        "dashboard": {
            "default_view": random.choice(["overview", "contracts", "quality", "metrics"]),
            "refresh_interval": random.choice([30, 60, 300, 600])
        },
        "data_export": {
            "default_format": random.choice(["csv", "excel", "json"]),
            "include_metadata": random.choice([True, False])
        },
        "privacy": {
            "show_profile": random.choice([True, False]),
            "allow_tracking": random.choice([True, False])
        }
    }


def generate_mock_users_sql() -> str:
    """Generate SQL INSERT statements for mock users data."""
    
    roles = generate_roles(12)
    users = generate_users(30)
    user_roles = generate_user_roles(users, roles)
    
    sql_statements = []
    
    # Roles
    sql_statements.append("-- Roles Mock Data")
    sql_statements.append("INSERT INTO roles (")
    sql_statements.append("    id, role_id, name, display_name, description, role_type, level,")
    sql_statements.append("    permissions, is_system_role, is_active, max_users, approval_required,")
    sql_statements.append("    role_metadata, ativo, criado_por, atualizado_por, data_criacao, data_atualizacao")
    sql_statements.append(") VALUES")
    
    role_values = []
    for role in roles:
        values = f"""(
    '{role["id"]}', '{role["role_id"]}', '{role["name"]}', '{role["display_name"]}',
    '{role["description"]}', '{role["role_type"]}', {role["level"]},
    '{role["permissions"]}'::jsonb, {role["is_system_role"]}, {role["is_active"]},
    {role["max_users"]}, {role["approval_required"]},
    '{str(role["role_metadata"]).replace("'", "''")}'::jsonb,
    {role["ativo"]}, '{role["criado_por"]}', '{role["atualizado_por"]}',
    '{role["data_criacao"]}', '{role["data_atualizacao"]}'
)"""
        role_values.append(values)
    
    sql_statements.append(",\n".join(role_values))
    sql_statements.append(";\n")
    
    # Users
    sql_statements.append("-- Users Mock Data")
    sql_statements.append("INSERT INTO users (")
    sql_statements.append("    id, user_id, username, email, first_name, last_name, display_name,")
    sql_statements.append("    department, job_title, manager_email, phone, location, timezone, language,")
    sql_statements.append("    is_active, is_verified, is_external, password_hash, password_changed_at,")
    sql_statements.append("    failed_login_attempts, last_login, last_activity, account_locked, locked_until,")
    sql_statements.append("    two_factor_enabled, two_factor_secret, session_timeout_minutes,")
    sql_statements.append("    preferences, user_metadata, ativo, criado_por, atualizado_por,")
    sql_statements.append("    data_criacao, data_atualizacao")
    sql_statements.append(") VALUES")
    
    user_values = []
    for user in users:
        values = f"""(
    '{user["id"]}', '{user["user_id"]}', '{user["username"]}', '{user["email"]}',
    '{user["first_name"]}', '{user["last_name"]}', '{user["display_name"]}',
    '{user["department"]}', '{user["job_title"]}',
    {'NULL' if not user["manager_email"] else f"'{user['manager_email']}'"},
    {'NULL' if not user["phone"] else f"'{user['phone']}'"},
    '{user["location"]}', '{user["timezone"]}', '{user["language"]}',
    {user["is_active"]}, {user["is_verified"]}, {user["is_external"]},
    '{user["password_hash"]}', '{user["password_changed_at"]}',
    {user["failed_login_attempts"]},
    {'NULL' if not user["last_login"] else f"'{user['last_login']}'"},
    {'NULL' if not user["last_activity"] else f"'{user['last_activity']}'"},
    {user["account_locked"]},
    {'NULL' if not user["locked_until"] else f"'{user['locked_until']}'"},
    {user["two_factor_enabled"]},
    {'NULL' if not user["two_factor_secret"] else f"'{user['two_factor_secret']}'"},
    {user["session_timeout_minutes"]},
    '{str(user["preferences"]).replace("'", "''")}'::jsonb,
    '{str(user["user_metadata"]).replace("'", "''")}'::jsonb,
    {user["ativo"]}, '{user["criado_por"]}', '{user["atualizado_por"]}',
    '{user["data_criacao"]}', '{user["data_atualizacao"]}'
)"""
        user_values.append(values)
    
    sql_statements.append(",\n".join(user_values))
    sql_statements.append(";\n")
    
    return "\n".join(sql_statements)


if __name__ == "__main__":
    # Generate and print sample data
    roles = generate_roles(8)
    users = generate_users(10)
    user_roles = generate_user_roles(users, roles)
    
    print("Sample Roles:")
    for role in roles[:5]:
        print(f"- {role['display_name']} ({role['name']}) - Level {role['level']}")
    
    print(f"\nSample Users:")
    for user in users[:5]:
        print(f"- {user['display_name']} ({user['username']}) - {user['department']}")
    
    print(f"\nGenerated {len(roles)} roles, {len(users)} users, {len(user_roles)} assignments")
    
    # Generate SQL
    sql = generate_mock_users_sql()
    print(f"\nSQL length: {len(sql)} characters")

