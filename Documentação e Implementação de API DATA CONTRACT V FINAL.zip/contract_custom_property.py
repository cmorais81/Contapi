"""
Contract Custom Property model.
"""

from sqlalchemy import Boolean, Column, ForeignKey, String, Text
from sqlalchemy.dialects.postgresql import UUID as PostgresUUID
from sqlalchemy.orm import relationship

from app.models.base import BaseModel


class ContractCustomProperty(BaseModel):
    """
    Contract Custom Property model.
    
    Extensible custom properties for contracts.
    """

    __tablename__ = "contract_custom_properties"

    # Foreign key to contract
    contract_id = Column(
        PostgresUUID(as_uuid=True),
        ForeignKey("data_contracts.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
        doc="Reference to contract"
    )

    # Property definition
    property_name = Column(
        String(255),
        nullable=False,
        doc="Custom property name"
    )

    property_value = Column(
        Text,
        doc="Property value"
    )

    property_type = Column(
        String(50),
        doc="Type: string, number, boolean, json, date"
    )

    is_required = Column(
        Boolean,
        default=False,
        doc="Required property"
    )

    property_description = Column(
        Text,
        doc="Property description"
    )

    # Relationships
    contract = relationship(
        "DataContract",
        back_populates="custom_properties"
    )

    def __repr__(self) -> str:
        return f"<ContractCustomProperty(name={self.property_name}, type={self.property_type})>"

