"""
Data Contract model.

Desenvolvido por Carlos Morais (carlos.morais@f1rst.com.br)
Julho 2025
"""

from sqlalchemy import Column, Integer, String, Text, DateTime, Boolean, JSON
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from app.models.base import BaseModel


class DataContract(BaseModel):
    """
    Modelo para contratos de dados.
    
    Representa um contrato de dados que define estrutura, qualidade
    e semântica dos dados entre produtores e consumidores.
    """
    __tablename__ = "data_contracts"

    # Campos principais
    contract_id = Column(Integer, primary_key=True, index=True)
    contract_name = Column(String(255), nullable=False, index=True)
    contract_description = Column(Text)
    contract_owner = Column(String(255), nullable=False)
    contract_status = Column(String(50), nullable=False, default="draft")
    
    # Metadados do contrato
    domain = Column(String(100), nullable=False)
    data_source = Column(String(255))
    data_destination = Column(String(255))
    frequency = Column(String(50))
    
    # Configurações
    schema_definition = Column(JSON)
    quality_rules = Column(JSON)
    sla_definition = Column(JSON)
    pricing_model = Column(JSON)
    
    # Versionamento
    version = Column(String(20), nullable=False, default="1.0.0")
    is_active = Column(Boolean, default=True)
    
    # Auditoria
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    created_by = Column(String(255), nullable=False)
    updated_by = Column(String(255))
    
    # Relacionamentos
    versions = relationship("ContractVersion", back_populates="contract", cascade="all, delete-orphan")
    layouts = relationship("ContractLayout", back_populates="contract", cascade="all, delete-orphan")
    custom_properties = relationship("ContractCustomProperty", back_populates="contract", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<DataContract(id={self.contract_id}, name='{self.contract_name}', version='{self.version}')>"
    
    @property
    def full_name(self):
        """Retorna nome completo do contrato com domínio."""
        return f"{self.domain}.{self.contract_name}"
    
    def is_valid(self):
        """Verifica se o contrato está válido."""
        return self.contract_status == "active" and self.is_active
    
    def get_latest_version(self):
        """Retorna a versão mais recente do contrato."""
        if self.versions:
            return max(self.versions, key=lambda v: v.version_number)
        return None

