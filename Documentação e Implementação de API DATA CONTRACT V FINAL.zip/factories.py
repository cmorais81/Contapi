"""
Factory classes for generating mock data.
"""

import random
from datetime import datetime, timedelta
from typing import Dict, List, Optional
from uuid import uuid4

import factory
from factory import Faker, LazyAttribute, SubFactory
from faker import Faker as FakerInstance

from app.models.contracts import DataContract, ContractVersion, ContractLayout, ContractCustomProperty
from app.models.components import (
    ContractFundamental, ContractTeamDefinition, ContractSLADefinition,
    ContractPricingDefinition, ContractSchemaDefinition
)
from app.models.data_objects import DataObject, DataObjectField, ContractQualityDefinition
from app.models.quality import QualityRule, QualityExecution, QualityResult, DataQualityAggregate
from app.models.metrics import ClusterMetric, JobMetric, QueryMetric, StorageMetric, DataAnomalyDetection
from app.models.lineage import ExternalLineageObject, LineageRelationship, LineageGraph
from app.models.users import User, Role, Permission, UserRole
from app.models.tags import Tag, TagAssignment
from app.models.governance import GovernancePolicy
from app.models.integrations import IntegrationConfig
from app.models.audit import AuditLog, SystemConfiguration

# Initialize Faker
fake = FakerInstance()

# Custom providers
class DataGovernanceProvider(factory.Provider):
    """Custom provider for data governance specific data."""
    
    business_domains = [
        "sales", "marketing", "finance", "operations", "hr", "customer_service",
        "product", "engineering", "legal", "compliance", "analytics"
    ]
    
    data_formats = ["delta", "iceberg", "parquet", "json", "csv", "avro"]
    table_formats = ["delta", "iceberg", "hudi"]
    contract_statuses = ["draft", "active", "deprecated", "archived"]
    
    quality_rule_types = [
        "completeness", "uniqueness", "validity", "consistency", "accuracy",
        "timeliness", "integrity", "conformity"
    ]
    
    severity_levels = ["low", "medium", "high", "critical"]
    
    system_types = [
        "tableau", "powerbi", "salesforce", "snowflake", "databricks",
        "unity_catalog", "informatica", "collibra", "alation"
    ]
    
    entity_types = [
        "dashboard", "report", "dataset", "model", "pipeline", "table",
        "view", "notebook", "job", "workflow"
    ]
    
    def business_domain(self):
        return self.random_element(self.business_domains)
    
    def data_format(self):
        return self.random_element(self.data_formats)
    
    def table_format(self):
        return self.random_element(self.table_formats)
    
    def contract_status(self):
        return self.random_element(self.contract_statuses)
    
    def quality_rule_type(self):
        return self.random_element(self.quality_rule_types)
    
    def severity_level(self):
        return self.random_element(self.severity_levels)
    
    def system_type(self):
        return self.random_element(self.system_types)
    
    def entity_type(self):
        return self.random_element(self.entity_types)

# Register custom provider
factory.Faker.add_provider(DataGovernanceProvider)


class UserFactory(factory.Factory):
    """Factory for User model."""
    
    class Meta:
        model = User
    
    username = Faker('user_name')
    email = Faker('email')
    full_name = Faker('name')
    department = Faker('business_domain')
    job_title = LazyAttribute(lambda obj: fake.random_element([
        "Data Engineer", "Data Scientist", "Data Analyst", "Data Architect",
        "Product Manager", "Software Engineer", "Business Analyst", "DevOps Engineer"
    ]))
    phone_number = Faker('phone_number')
    is_active = True
    is_superuser = False
    failed_login_attempts = "0"


class RoleFactory(factory.Factory):
    """Factory for Role model."""
    
    class Meta:
        model = Role
    
    role_name = LazyAttribute(lambda obj: fake.random_element([
        "data_admin", "data_steward", "data_analyst", "data_engineer",
        "business_user", "compliance_officer", "system_admin"
    ]))
    role_description = Faker('text', max_nb_chars=200)
    is_system_role = False
    is_active = True
    role_level = "1"


class DataContractFactory(factory.Factory):
    """Factory for DataContract model."""
    
    class Meta:
        model = DataContract
    
    contract_name = LazyAttribute(lambda obj: f"{fake.word()}_{fake.business_domain()}_contract")
    contract_description = Faker('text', max_nb_chars=500)
    contract_owner = Faker('email')
    business_domain = Faker('business_domain')
    data_location = LazyAttribute(lambda obj: f"s3://data-lake/{obj.business_domain}/{fake.word()}/")
    data_format = Faker('data_format')
    table_format = Faker('table_format')
    unity_catalog_name = LazyAttribute(lambda obj: f"{obj.business_domain}_catalog")
    unity_catalog_schema = LazyAttribute(lambda obj: f"{obj.business_domain}_schema")
    unity_catalog_table = LazyAttribute(lambda obj: f"{fake.word()}_table")
    abac_enabled = Faker('boolean', chance_of_getting_true=30)
    monitoring_enabled = Faker('boolean', chance_of_getting_true=80)
    alert_threshold_percent = LazyAttribute(lambda obj: str(random.randint(70, 95)))
    contract_status = Faker('contract_status')


class QualityRuleFactory(factory.Factory):
    """Factory for QualityRule model."""
    
    class Meta:
        model = QualityRule
    
    rule_name = LazyAttribute(lambda obj: f"{fake.quality_rule_type()}_{fake.word()}_rule")
    rule_description = Faker('text', max_nb_chars=300)
    rule_type = Faker('quality_rule_type')
    rule_category = "data_quality"
    rule_logic = LazyAttribute(lambda obj: fake.random_element([
        "COUNT(*) > 0",
        "COUNT(DISTINCT column_name) = COUNT(column_name)",
        "column_name IS NOT NULL",
        "column_name REGEXP '^[A-Za-z0-9]+$'",
        "LENGTH(column_name) BETWEEN 1 AND 255"
    ]))
    severity_level = Faker('severity_level')
    is_enabled = Faker('boolean', chance_of_getting_true=85)
    rule_status = "active"


class ExternalLineageObjectFactory(factory.Factory):
    """Factory for ExternalLineageObject model."""
    
    class Meta:
        model = ExternalLineageObject
    
    object_name = LazyAttribute(lambda obj: f"{fake.word()}_{obj.entity_type}")
    object_description = Faker('text', max_nb_chars=300)
    entity_type = Faker('entity_type')
    system_type = Faker('system_type')
    workspace_name = LazyAttribute(lambda obj: f"{fake.word()}_workspace")
    owner_email = Faker('email')
    object_status = "active"


class TagFactory(factory.Factory):
    """Factory for Tag model."""
    
    class Meta:
        model = Tag
    
    tag_name = LazyAttribute(lambda obj: fake.random_element([
        "pii", "sensitive", "public", "confidential", "financial", "customer",
        "product", "marketing", "sales", "operational", "regulatory", "gdpr"
    ]))
    tag_description = Faker('text', max_nb_chars=200)
    tag_category = LazyAttribute(lambda obj: fake.random_element([
        "security", "compliance", "business", "technical", "quality"
    ]))
    tag_type = "classification"
    color_code = Faker('hex_color')
    is_active = True
    is_system_tag = False
    usage_count = LazyAttribute(lambda obj: str(random.randint(0, 100)))


class GovernancePolicyFactory(factory.Factory):
    """Factory for GovernancePolicy model."""
    
    class Meta:
        model = GovernancePolicy
    
    policy_name = LazyAttribute(lambda obj: f"{fake.word()}_policy")
    policy_description = Faker('text', max_nb_chars=500)
    policy_type = LazyAttribute(lambda obj: fake.random_element([
        "data_access", "data_retention", "data_quality", "data_privacy"
    ]))
    policy_category = LazyAttribute(lambda obj: fake.random_element([
        "security", "compliance", "operational", "business"
    ]))
    policy_rules = '{"access_level": "restricted", "retention_days": 2555}'
    enforcement_level = LazyAttribute(lambda obj: fake.random_element([
        "advisory", "warning", "blocking"
    ]))
    policy_status = "active"
    is_mandatory = Faker('boolean', chance_of_getting_true=40)


class IntegrationConfigFactory(factory.Factory):
    """Factory for IntegrationConfig model."""
    
    class Meta:
        model = IntegrationConfig
    
    integration_name = LazyAttribute(lambda obj: f"{fake.system_type()}_integration")
    integration_description = Faker('text', max_nb_chars=300)
    system_type = Faker('system_type')
    system_version = LazyAttribute(lambda obj: f"{random.randint(1, 5)}.{random.randint(0, 9)}")
    endpoint_url = Faker('url')
    authentication_type = LazyAttribute(lambda obj: fake.random_element([
        "oauth2", "api_key", "basic", "certificate"
    ]))
    sync_enabled = Faker('boolean', chance_of_getting_true=80)
    sync_frequency = LazyAttribute(lambda obj: fake.random_element([
        "real-time", "hourly", "daily", "weekly"
    ]))
    integration_status = "active"


class ClusterMetricFactory(factory.Factory):
    """Factory for ClusterMetric model."""
    
    class Meta:
        model = ClusterMetric
    
    cluster_id = LazyAttribute(lambda obj: f"cluster_{fake.random_int(1000, 9999)}")
    cluster_name = LazyAttribute(lambda obj: f"{fake.word()}_cluster")
    cluster_type = LazyAttribute(lambda obj: fake.random_element([
        "interactive", "job", "pool", "serverless"
    ]))
    node_count = LazyAttribute(lambda obj: str(random.randint(1, 20)))
    cpu_cores_total = LazyAttribute(lambda obj: str(random.randint(4, 160)))
    memory_gb_total = LazyAttribute(lambda obj: str(random.randint(16, 640)))
    cpu_utilization_percent = LazyAttribute(lambda obj: str(random.randint(10, 95)))
    memory_utilization_percent = LazyAttribute(lambda obj: str(random.randint(20, 90)))
    uptime_hours = LazyAttribute(lambda obj: str(random.randint(1, 720)))
    cost_per_hour_usd = LazyAttribute(lambda obj: str(round(random.uniform(0.5, 50.0), 2)))


class StorageMetricFactory(factory.Factory):
    """Factory for StorageMetric model."""
    
    class Meta:
        model = StorageMetric
    
    storage_location = LazyAttribute(lambda obj: f"s3://data-lake/{fake.word()}/")
    table_name = LazyAttribute(lambda obj: f"{fake.word()}_table")
    total_size_bytes = LazyAttribute(lambda obj: str(random.randint(1000000, 1000000000000)))
    compressed_size_bytes = LazyAttribute(lambda obj: str(int(int(obj.total_size_bytes) * 0.3)))
    file_count = LazyAttribute(lambda obj: str(random.randint(1, 10000)))
    row_count = LazyAttribute(lambda obj: str(random.randint(1000, 100000000)))
    compression_ratio = LazyAttribute(lambda obj: str(round(random.uniform(0.2, 0.8), 2)))
    storage_cost_usd = LazyAttribute(lambda obj: str(round(random.uniform(10.0, 10000.0), 2)))


# Data generation utilities
class MockDataGenerator:
    """Utility class for generating mock data."""
    
    def __init__(self):
        self.users = []
        self.roles = []
        self.contracts = []
        self.quality_rules = []
        self.external_objects = []
        self.tags = []
        self.policies = []
        self.integrations = []
        self.metrics = []
    
    def generate_users(self, count: int = 50) -> List[User]:
        """Generate mock users."""
        self.users = UserFactory.build_batch(count)
        return self.users
    
    def generate_roles(self, count: int = 10) -> List[Role]:
        """Generate mock roles."""
        self.roles = RoleFactory.build_batch(count)
        return self.roles
    
    def generate_contracts(self, count: int = 100) -> List[DataContract]:
        """Generate mock data contracts."""
        self.contracts = DataContractFactory.build_batch(count)
        return self.contracts
    
    def generate_quality_rules(self, count: int = 200) -> List[QualityRule]:
        """Generate mock quality rules."""
        self.quality_rules = QualityRuleFactory.build_batch(count)
        return self.quality_rules
    
    def generate_external_objects(self, count: int = 150) -> List[ExternalLineageObject]:
        """Generate mock external lineage objects."""
        self.external_objects = ExternalLineageObjectFactory.build_batch(count)
        return self.external_objects
    
    def generate_tags(self, count: int = 30) -> List[Tag]:
        """Generate mock tags."""
        self.tags = TagFactory.build_batch(count)
        return self.tags
    
    def generate_policies(self, count: int = 25) -> List[GovernancePolicy]:
        """Generate mock governance policies."""
        self.policies = GovernancePolicyFactory.build_batch(count)
        return self.policies
    
    def generate_integrations(self, count: int = 15) -> List[IntegrationConfig]:
        """Generate mock integration configurations."""
        self.integrations = IntegrationConfigFactory.build_batch(count)
        return self.integrations
    
    def generate_cluster_metrics(self, count: int = 50) -> List[ClusterMetric]:
        """Generate mock cluster metrics."""
        return ClusterMetricFactory.build_batch(count)
    
    def generate_storage_metrics(self, count: int = 200) -> List[StorageMetric]:
        """Generate mock storage metrics."""
        return StorageMetricFactory.build_batch(count)
    
    def generate_all_data(self) -> Dict[str, List]:
        """Generate all mock data."""
        return {
            "users": self.generate_users(50),
            "roles": self.generate_roles(10),
            "contracts": self.generate_contracts(100),
            "quality_rules": self.generate_quality_rules(200),
            "external_objects": self.generate_external_objects(150),
            "tags": self.generate_tags(30),
            "policies": self.generate_policies(25),
            "integrations": self.generate_integrations(15),
            "cluster_metrics": self.generate_cluster_metrics(50),
            "storage_metrics": self.generate_storage_metrics(200)
        }
    
    def get_summary(self) -> Dict[str, int]:
        """Get summary of generated data."""
        return {
            "users": len(self.users),
            "roles": len(self.roles),
            "contracts": len(self.contracts),
            "quality_rules": len(self.quality_rules),
            "external_objects": len(self.external_objects),
            "tags": len(self.tags),
            "policies": len(self.policies),
            "integrations": len(self.integrations),
            "total_records": (
                len(self.users) + len(self.roles) + len(self.contracts) +
                len(self.quality_rules) + len(self.external_objects) +
                len(self.tags) + len(self.policies) + len(self.integrations)
            )
        }

