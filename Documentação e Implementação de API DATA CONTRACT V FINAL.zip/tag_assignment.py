"""
Tag Assignment model.
"""

from sqlalchemy import Column, ForeignKey, String, Text
from sqlalchemy.dialects.postgresql import UUID as PostgresUUID
from sqlalchemy.orm import relationship

from app.models.base import BaseModel


class TagAssignment(BaseModel):
    """
    Tag Assignment model.
    
    Assignment of tags to various entities.
    """

    __tablename__ = "tag_assignments"

    # Foreign key to tag
    tag_id = Column(
        PostgresUUID(as_uuid=True),
        ForeignKey("tags.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
        doc="Reference to tag"
    )

    # Target entity
    entity_type = Column(
        String(100),
        nullable=False,
        index=True,
        doc="Entity type: contract, data_object, user, quality_rule, external_object"
    )

    entity_id = Column(
        PostgresUUID(as_uuid=True),
        nullable=False,
        index=True,
        doc="Entity ID"
    )

    entity_name = Column(
        String(255),
        doc="Entity name for reference"
    )

    # Assignment details
    assigned_by = Column(
        String(255),
        doc="User who assigned the tag"
    )

    assignment_reason = Column(
        Text,
        doc="Reason for tag assignment"
    )

    # Context
    assignment_context = Column(
        Text,
        doc="Additional context as JSON"
    )

    confidence_score = Column(
        String(10),  # Using String to handle numeric as text
        doc="Confidence score for automated assignments (0-1)"
    )

    # Relationships
    tag = relationship(
        "Tag",
        back_populates="assignments"
    )

    def __repr__(self) -> str:
        return f"<TagAssignment(tag_id={self.tag_id}, entity_type={self.entity_type}, entity_id={self.entity_id})>"

