"""
Database population script with mock data.
"""

import asyncio
import sys
from pathlib import Path

# Add project root to path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text

from app.core.database import get_async_engine, get_async_session
from app.models import Base
from scripts.factories import MockDataGenerator


async def create_tables():
    """Create all database tables."""
    engine = get_async_engine()
    
    async with engine.begin() as conn:
        # Drop all tables first
        await conn.run_sync(Base.metadata.drop_all)
        print("Dropped all existing tables")
        
        # Create all tables
        await conn.run_sync(Base.metadata.create_all)
        print("Created all tables")


async def populate_database():
    """Populate database with mock data."""
    print("Starting database population...")
    
    # Create tables
    await create_tables()
    
    # Generate mock data
    generator = MockDataGenerator()
    data = generator.generate_all_data()
    
    print(f"Generated mock data:")
    for entity_type, entities in data.items():
        print(f"  - {entity_type}: {len(entities)} records")
    
    # Get database session
    async with get_async_session() as session:
        try:
            # Add users first (they might be referenced by other entities)
            print("\nInserting users...")
            for user in data["users"]:
                session.add(user)
            await session.commit()
            print(f"Inserted {len(data['users'])} users")
            
            # Add roles
            print("Inserting roles...")
            for role in data["roles"]:
                session.add(role)
            await session.commit()
            print(f"Inserted {len(data['roles'])} roles")
            
            # Add contracts
            print("Inserting contracts...")
            for contract in data["contracts"]:
                session.add(contract)
            await session.commit()
            print(f"Inserted {len(data['contracts'])} contracts")
            
            # Add quality rules
            print("Inserting quality rules...")
            for rule in data["quality_rules"]:
                session.add(rule)
            await session.commit()
            print(f"Inserted {len(data['quality_rules'])} quality rules")
            
            # Add external objects
            print("Inserting external objects...")
            for obj in data["external_objects"]:
                session.add(obj)
            await session.commit()
            print(f"Inserted {len(data['external_objects'])} external objects")
            
            # Add tags
            print("Inserting tags...")
            for tag in data["tags"]:
                session.add(tag)
            await session.commit()
            print(f"Inserted {len(data['tags'])} tags")
            
            # Add policies
            print("Inserting policies...")
            for policy in data["policies"]:
                session.add(policy)
            await session.commit()
            print(f"Inserted {len(data['policies'])} policies")
            
            # Add integrations
            print("Inserting integrations...")
            for integration in data["integrations"]:
                session.add(integration)
            await session.commit()
            print(f"Inserted {len(data['integrations'])} integrations")
            
            # Add metrics (these need contract references)
            print("Inserting cluster metrics...")
            for metric in data["cluster_metrics"]:
                # Assign random contract
                if data["contracts"]:
                    metric.contract_id = data["contracts"][0].id
                session.add(metric)
            await session.commit()
            print(f"Inserted {len(data['cluster_metrics'])} cluster metrics")
            
            print("Inserting storage metrics...")
            for metric in data["storage_metrics"]:
                # Assign random contract
                if data["contracts"]:
                    metric.contract_id = data["contracts"][0].id
                session.add(metric)
            await session.commit()
            print(f"Inserted {len(data['storage_metrics'])} storage metrics")
            
            print("\n✅ Database population completed successfully!")
            
            # Print summary
            summary = generator.get_summary()
            print(f"\nSummary:")
            print(f"Total records inserted: {summary['total_records'] + len(data['cluster_metrics']) + len(data['storage_metrics'])}")
            
        except Exception as e:
            print(f"❌ Error during population: {e}")
            await session.rollback()
            raise


async def verify_data():
    """Verify that data was inserted correctly."""
    print("\nVerifying data insertion...")
    
    async with get_async_session() as session:
        # Check each table
        tables = [
            ("users", "SELECT COUNT(*) FROM users"),
            ("roles", "SELECT COUNT(*) FROM roles"),
            ("data_contracts", "SELECT COUNT(*) FROM data_contracts"),
            ("quality_rules", "SELECT COUNT(*) FROM quality_rules"),
            ("external_lineage_objects", "SELECT COUNT(*) FROM external_lineage_objects"),
            ("tags", "SELECT COUNT(*) FROM tags"),
            ("governance_policies", "SELECT COUNT(*) FROM governance_policies"),
            ("integration_configs", "SELECT COUNT(*) FROM integration_configs"),
            ("cluster_metrics", "SELECT COUNT(*) FROM cluster_metrics"),
            ("storage_metrics", "SELECT COUNT(*) FROM storage_metrics")
        ]
        
        total_records = 0
        for table_name, query in tables:
            result = await session.execute(text(query))
            count = result.scalar()
            print(f"  {table_name}: {count} records")
            total_records += count
        
        print(f"\nTotal records in database: {total_records}")
        
        # Test some sample queries
        print("\nSample data verification:")
        
        # Check contracts by status
        result = await session.execute(
            text("SELECT contract_status, COUNT(*) FROM data_contracts GROUP BY contract_status")
        )
        print("  Contracts by status:")
        for row in result:
            print(f"    {row[0]}: {row[1]}")
        
        # Check quality rules by type
        result = await session.execute(
            text("SELECT rule_type, COUNT(*) FROM quality_rules GROUP BY rule_type")
        )
        print("  Quality rules by type:")
        for row in result:
            print(f"    {row[0]}: {row[1]}")
        
        # Check external objects by system
        result = await session.execute(
            text("SELECT system_type, COUNT(*) FROM external_lineage_objects GROUP BY system_type")
        )
        print("  External objects by system:")
        for row in result:
            print(f"    {row[0]}: {row[1]}")


async def main():
    """Main function."""
    print("🚀 Data Governance API - Database Population Script")
    print("=" * 60)
    
    try:
        await populate_database()
        await verify_data()
        
        print("\n🎉 Database population completed successfully!")
        print("\nYou can now start the API server and explore the data:")
        print("  python -m app.main")
        print("  or")
        print("  uvicorn app.main:app --reload")
        
    except Exception as e:
        print(f"\n❌ Population failed: {e}")
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())

