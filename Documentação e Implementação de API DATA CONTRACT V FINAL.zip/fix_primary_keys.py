#!/usr/bin/env python3
"""
Script to fix missing primary keys in SQLAlchemy models.
"""

import os
import re
from pathlib import Path

def fix_primary_key(file_path):
    """Add primary key to a model file if missing."""
    
    with open(file_path, 'r') as f:
        content = f.read()
    
    # Check if already has primary key
    if 'primary_key=True' in content:
        print(f"✅ {file_path} already has primary key")
        return
    
    # Find the class definition and __tablename__
    class_match = re.search(r'class\s+(\w+)\(.*Base.*\):', content)
    if not class_match:
        print(f"❌ Could not find class definition in {file_path}")
        return
    
    tablename_match = re.search(r'__tablename__\s*=\s*["\']([^"\']+)["\']', content)
    if not tablename_match:
        print(f"❌ Could not find __tablename__ in {file_path}")
        return
    
    # Find the position after __allow_unmapped__ = True
    allow_unmapped_match = re.search(r'(__allow_unmapped__\s*=\s*True\s*\n)', content)
    if not allow_unmapped_match:
        print(f"❌ Could not find __allow_unmapped__ in {file_path}")
        return
    
    # Insert primary key definition
    primary_key_code = '''
    # Primary key
    id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        comment="Primary key"
    )
'''
    
    # Insert after __allow_unmapped__
    insert_pos = allow_unmapped_match.end()
    new_content = content[:insert_pos] + primary_key_code + content[insert_pos:]
    
    # Ensure imports are present
    if 'from sqlalchemy.dialects.postgresql import UUID' not in new_content:
        # Find import section and add UUID import
        import_match = re.search(r'(from sqlalchemy import[^\n]+)', new_content)
        if import_match:
            import_line = import_match.group(1)
            if 'UUID' not in import_line:
                new_import_line = import_line.replace('from sqlalchemy import', 'from sqlalchemy import') + '\nfrom sqlalchemy.dialects.postgresql import UUID'
                new_content = new_content.replace(import_line, new_import_line)
    
    if 'import uuid' not in new_content:
        # Add uuid import after other imports
        import_section_end = re.search(r'(from app\.models\..*\n)', new_content)
        if import_section_end:
            insert_pos = import_section_end.end()
            new_content = new_content[:insert_pos] + 'import uuid\n' + new_content[insert_pos:]
    
    # Write back to file
    with open(file_path, 'w') as f:
        f.write(new_content)
    
    print(f"✅ Added primary key to {file_path}")

def main():
    """Fix all model files."""
    
    models_dir = Path("app/models")
    
    # Find all Python files with models
    model_files = []
    for root, dirs, files in os.walk(models_dir):
        for file in files:
            if file.endswith('.py') and file != '__init__.py':
                file_path = Path(root) / file
                model_files.append(file_path)
    
    print(f"Found {len(model_files)} model files")
    
    for file_path in model_files:
        try:
            fix_primary_key(file_path)
        except Exception as e:
            print(f"❌ Error fixing {file_path}: {e}")

if __name__ == "__main__":
    main()

