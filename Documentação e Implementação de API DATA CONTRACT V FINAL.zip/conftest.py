"""
Pytest configuration and fixtures for Data Governance API tests.
"""

import asyncio
import os
from typing import AsyncGenerator, Generator
from uuid import uuid4

import pytest
import pytest_asyncio
from fastapi.testclient import TestClient
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.core.config import Settings
from app.core.database import get_db
from app.main import app
from app.models import Base

# Test database URL
TEST_DATABASE_URL = "sqlite+aiosqlite:///./test.db"

# Test settings
test_settings = Settings(
    DATABASE_URL=TEST_DATABASE_URL,
    ENVIRONMENT="testing",
    API_DOCS_ENABLED=True,
    CACHE_ENABLED=False,
    METRICS_ENABLED=False,
    LOG_LEVEL="DEBUG"
)

# Create test engine
test_engine = create_async_engine(
    TEST_DATABASE_URL,
    connect_args={"check_same_thread": False},
    poolclass=StaticPool,
    echo=False
)

# Create test session factory
TestSessionLocal = sessionmaker(
    test_engine,
    class_=AsyncSession,
    expire_on_commit=False
)


@pytest.fixture(scope="session")
def event_loop() -> Generator:
    """Create an instance of the default event loop for the test session."""
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()


@pytest_asyncio.fixture(scope="function")
async def db_session() -> AsyncGenerator[AsyncSession, None]:
    """Create a test database session."""
    # Create tables
    async with test_engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    
    # Create session
    async with TestSessionLocal() as session:
        yield session
    
    # Drop tables
    async with test_engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)


@pytest.fixture
def client(db_session: AsyncSession) -> TestClient:
    """Create a test client with database dependency override."""
    def override_get_db():
        return db_session
    
    app.dependency_overrides[get_db] = override_get_db
    
    with TestClient(app) as test_client:
        yield test_client
    
    app.dependency_overrides.clear()


@pytest_asyncio.fixture
async def async_client(db_session: AsyncSession) -> AsyncGenerator[AsyncClient, None]:
    """Create an async test client."""
    def override_get_db():
        return db_session
    
    app.dependency_overrides[get_db] = override_get_db
    
    async with AsyncClient(app=app, base_url="http://test") as ac:
        yield ac
    
    app.dependency_overrides.clear()


@pytest.fixture
def sample_contract_data():
    """Sample data contract data for testing."""
    return {
        "contract_name": f"test_contract_{uuid4().hex[:8]}",
        "contract_description": "Test contract for unit testing",
        "contract_owner": "test@example.com",
        "business_domain": "testing",
        "data_location": "s3://test-bucket/data/",
        "data_format": "delta",
        "table_format": "delta",
        "unity_catalog_name": "test_catalog",
        "unity_catalog_schema": "test_schema",
        "unity_catalog_table": "test_table",
        "abac_enabled": True,
        "monitoring_enabled": True,
        "alert_threshold_percent": "80",
        "contract_status": "draft"
    }


@pytest.fixture
def sample_user_data():
    """Sample user data for testing."""
    return {
        "username": f"testuser_{uuid4().hex[:8]}",
        "email": f"test_{uuid4().hex[:8]}@example.com",
        "full_name": "Test User",
        "department": "Engineering",
        "job_title": "Data Engineer",
        "is_active": True,
        "is_superuser": False
    }


@pytest.fixture
def sample_quality_rule_data():
    """Sample quality rule data for testing."""
    return {
        "rule_name": f"test_rule_{uuid4().hex[:8]}",
        "rule_description": "Test quality rule",
        "rule_type": "completeness",
        "rule_category": "data_quality",
        "rule_logic": "COUNT(*) > 0",
        "severity_level": "high",
        "is_enabled": True
    }


@pytest.fixture
def sample_external_object_data():
    """Sample external lineage object data for testing."""
    return {
        "object_name": f"test_dashboard_{uuid4().hex[:8]}",
        "object_description": "Test dashboard for lineage",
        "entity_type": "dashboard",
        "system_type": "tableau",
        "workspace_name": "test_workspace",
        "owner_email": "owner@example.com",
        "object_status": "active"
    }


@pytest.fixture
def sample_tag_data():
    """Sample tag data for testing."""
    return {
        "tag_name": f"test_tag_{uuid4().hex[:8]}",
        "tag_description": "Test tag for categorization",
        "tag_category": "business",
        "tag_type": "classification",
        "color_code": "#FF5733",
        "is_active": True
    }


@pytest.fixture
def sample_governance_policy_data():
    """Sample governance policy data for testing."""
    return {
        "policy_name": f"test_policy_{uuid4().hex[:8]}",
        "policy_description": "Test governance policy",
        "policy_type": "data_access",
        "policy_category": "security",
        "policy_rules": '{"access_level": "restricted"}',
        "enforcement_level": "blocking",
        "policy_status": "draft",
        "is_mandatory": True
    }


@pytest.fixture
def sample_integration_config_data():
    """Sample integration config data for testing."""
    return {
        "integration_name": f"test_integration_{uuid4().hex[:8]}",
        "integration_description": "Test integration configuration",
        "system_type": "unity_catalog",
        "system_version": "1.0",
        "endpoint_url": "https://test.databricks.com",
        "authentication_type": "oauth2",
        "sync_enabled": True,
        "sync_frequency": "daily",
        "integration_status": "active"
    }


# Test utilities
class TestUtils:
    """Utility functions for testing."""
    
    @staticmethod
    def assert_response_structure(response_data: dict, expected_keys: list):
        """Assert that response has expected structure."""
        for key in expected_keys:
            assert key in response_data, f"Missing key: {key}"
    
    @staticmethod
    def assert_pagination_meta(meta: dict):
        """Assert pagination metadata structure."""
        required_keys = ["page", "size", "total", "pages", "has_next", "has_prev"]
        for key in required_keys:
            assert key in meta, f"Missing pagination key: {key}"
        
        assert isinstance(meta["page"], int)
        assert isinstance(meta["size"], int)
        assert isinstance(meta["total"], int)
        assert isinstance(meta["pages"], int)
        assert isinstance(meta["has_next"], bool)
        assert isinstance(meta["has_prev"], bool)
    
    @staticmethod
    def assert_error_response(response_data: dict):
        """Assert error response structure."""
        required_keys = ["error", "message", "timestamp"]
        for key in required_keys:
            assert key in response_data, f"Missing error key: {key}"


@pytest.fixture
def test_utils():
    """Test utilities fixture."""
    return TestUtils

