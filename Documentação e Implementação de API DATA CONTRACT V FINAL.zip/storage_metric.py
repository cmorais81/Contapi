"""
Storage Metric model.
"""

from sqlalchemy import Column, ForeignKey, String
from sqlalchemy.dialects.postgresql import UUID as PostgresUUID
from sqlalchemy.orm import relationship

from app.models.base import BaseModel
from app.models.mixins import MetricsMixin


class StorageMetric(BaseModel, MetricsMixin):
    """
    Storage Metric model.
    
    Data storage metrics and statistics.
    """

    __tablename__ = "storage_metrics"

    # Foreign key to contract
    contract_id = Column(
        PostgresUUID(as_uuid=True),
        ForeignKey("data_contracts.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
        doc="Reference to contract"
    )

    # Storage identification
    storage_location = Column(
        String(500),
        nullable=False,
        doc="Storage location path"
    )

    table_name = Column(
        String(255),
        index=True,
        doc="Table name"
    )

    # Size metrics
    total_size_bytes = Column(
        String(20),  # Using String to handle integer as text
        doc="Total size in bytes"
    )

    compressed_size_bytes = Column(
        String(20),  # Using String to handle integer as text
        doc="Compressed size in bytes"
    )

    uncompressed_size_bytes = Column(
        String(20),  # Using String to handle integer as text
        doc="Uncompressed size in bytes"
    )

    # File metrics
    file_count = Column(
        String(10),  # Using String to handle integer as text
        doc="Number of files"
    )

    partition_count = Column(
        String(10),  # Using String to handle integer as text
        doc="Number of partitions"
    )

    # Row metrics
    row_count = Column(
        String(20),  # Using String to handle integer as text
        doc="Number of rows"
    )

    avg_row_size_bytes = Column(
        String(20),  # Using String to handle numeric as text
        doc="Average row size in bytes"
    )

    # Performance metrics
    compression_ratio = Column(
        String(10),  # Using String to handle numeric as text
        doc="Compression ratio"
    )

    read_throughput_mbps = Column(
        String(20),  # Using String to handle numeric as text
        doc="Read throughput in Mbps"
    )

    write_throughput_mbps = Column(
        String(20),  # Using String to handle numeric as text
        doc="Write throughput in Mbps"
    )

    # Cost metrics
    storage_cost_usd = Column(
        String(20),  # Using String to handle numeric as text
        doc="Storage cost in USD"
    )

    # Relationships
    contract = relationship(
        "DataContract",
        back_populates="storage_metrics"
    )

    def __repr__(self) -> str:
        return f"<StorageMetric(table={self.table_name}, size_bytes={self.total_size_bytes})>"

