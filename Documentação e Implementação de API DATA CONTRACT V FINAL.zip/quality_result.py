"""
Quality Result model.
"""

from sqlalchemy import Boolean, Column, ForeignKey, String, Text
from sqlalchemy.dialects.postgresql import UUID as PostgresUUID
from sqlalchemy.orm import relationship

from app.models.base import BaseModel


class QualityResult(BaseModel):
    """
    Quality Result model.
    
    Detailed results of quality rule executions.
    """

    __tablename__ = "quality_results"

    # Foreign key to execution
    execution_id = Column(
        PostgresUUID(as_uuid=True),
        ForeignKey("quality_executions.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
        doc="Reference to execution"
    )

    # Result details
    record_identifier = Column(
        String(255),
        doc="Identifier of the record that was validated"
    )

    validation_passed = Column(
        Boolean,
        nullable=False,
        index=True,
        doc="Whether validation passed"
    )

    actual_value = Column(
        Text,
        doc="Actual value found"
    )

    expected_value = Column(
        Text,
        doc="Expected value"
    )

    # Error details
    error_code = Column(
        String(50),
        doc="Error code if validation failed"
    )

    error_message = Column(
        Text,
        doc="Error message if validation failed"
    )

    # Relationships
    execution = relationship(
        "QualityExecution",
        back_populates="results"
    )

    def __repr__(self) -> str:
        return f"<QualityResult(passed={self.validation_passed}, record={self.record_identifier})>"

