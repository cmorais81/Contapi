"""
Role model.
"""

from sqlalchemy import Boolean, Column, String, Text
from sqlalchemy.orm import relationship

from app.models.base import BaseModel


class Role(BaseModel):
    """
    Role model.
    
    User roles for RBAC (Role-Based Access Control).
    """

    __tablename__ = "roles"

    # Role definition
    role_name = Column(
        String(255),
        nullable=False,
        unique=True,
        index=True,
        doc="Unique role name"
    )

    role_description = Column(
        Text,
        doc="Role description"
    )

    # Role properties
    is_system_role = Column(
        Boolean,
        default=False,
        doc="System-defined role (cannot be deleted)"
    )

    is_active = Column(
        Boolean,
        default=True,
        doc="Role is active"
    )

    # Hierarchy
    parent_role_id = Column(
        String(255),  # Using String to handle UUID as text
        doc="Parent role for hierarchy"
    )

    role_level = Column(
        String(10),  # Using String to handle integer as text
        default="1",
        doc="Role level in hierarchy"
    )

    # Permissions (JSON array)
    permissions = Column(
        Text,
        doc="Permissions as JSON array"
    )

    # Relationships
    user_roles = relationship(
        "UserRole",
        back_populates="role",
        cascade="all, delete-orphan"
    )

    def __repr__(self) -> str:
        return f"<Role(name={self.role_name}, active={self.is_active})>"

