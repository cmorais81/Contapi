"""
Data Contract Service.

Desenvolvido por Carlos Morais (carlos.morais@f1rst.com.br)
Julho 2025
"""

from typing import List, Optional
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_

from app.models.contracts.data_contract_v1 import DataContract
from app.schemas.contracts.data_contract_v1 import (
    DataContractCreate,
    DataContractUpdate,
    DataContractResponse,
    DataContractList
)


class DataContractService:
    """
    Service para operações de contratos de dados.
    
    Implementa a lógica de negócio para gestão de contratos,
    incluindo validação, versionamento e ativação.
    """
    
    def __init__(self, db: Session):
        self.db = db
    
    async def create_contract(self, contract_data: DataContractCreate) -> DataContractResponse:
        """
        Cria um novo contrato de dados.
        
        Args:
            contract_data: Dados do contrato a ser criado
            
        Returns:
            DataContractResponse: Contrato criado
        """
        # Verificar se já existe contrato com mesmo nome no domínio
        existing = self.db.query(DataContract).filter(
            and_(
                DataContract.contract_name == contract_data.contract_name,
                DataContract.domain == contract_data.domain,
                DataContract.is_active == True
            )
        ).first()
        
        if existing:
            raise ValueError(f"Já existe um contrato ativo com nome '{contract_data.contract_name}' no domínio '{contract_data.domain}'")
        
        # Criar novo contrato
        db_contract = DataContract(**contract_data.model_dump())
        self.db.add(db_contract)
        self.db.commit()
        self.db.refresh(db_contract)
        
        return DataContractResponse.model_validate(db_contract)
    
    async def get_contract(self, contract_id: int) -> Optional[DataContractResponse]:
        """
        Obtém um contrato específico.
        
        Args:
            contract_id: ID do contrato
            
        Returns:
            DataContractResponse ou None se não encontrado
        """
        contract = self.db.query(DataContract).filter(
            DataContract.contract_id == contract_id
        ).first()
        
        if contract:
            return DataContractResponse.model_validate(contract)
        return None
    
    async def list_contracts(
        self,
        skip: int = 0,
        limit: int = 100,
        domain: Optional[str] = None,
        status: Optional[str] = None,
        owner: Optional[str] = None
    ) -> List[DataContractList]:
        """
        Lista contratos com filtros opcionais.
        
        Args:
            skip: Número de registros para pular
            limit: Número máximo de registros
            domain: Filtro por domínio
            status: Filtro por status
            owner: Filtro por proprietário
            
        Returns:
            Lista de contratos
        """
        query = self.db.query(DataContract)
        
        # Aplicar filtros
        if domain:
            query = query.filter(DataContract.domain == domain)
        if status:
            query = query.filter(DataContract.contract_status == status)
        if owner:
            query = query.filter(DataContract.contract_owner.ilike(f"%{owner}%"))
        
        # Paginação
        contracts = query.offset(skip).limit(limit).all()
        
        return [DataContractList.model_validate(contract) for contract in contracts]
    
    async def update_contract(
        self,
        contract_id: int,
        contract_update: DataContractUpdate
    ) -> Optional[DataContractResponse]:
        """
        Atualiza um contrato existente.
        
        Args:
            contract_id: ID do contrato
            contract_update: Dados para atualização
            
        Returns:
            DataContractResponse ou None se não encontrado
        """
        contract = self.db.query(DataContract).filter(
            DataContract.contract_id == contract_id
        ).first()
        
        if not contract:
            return None
        
        # Atualizar apenas campos fornecidos
        update_data = contract_update.model_dump(exclude_unset=True)
        for field, value in update_data.items():
            setattr(contract, field, value)
        
        self.db.commit()
        self.db.refresh(contract)
        
        return DataContractResponse.model_validate(contract)
    
    async def delete_contract(self, contract_id: int) -> bool:
        """
        Exclui um contrato (soft delete).
        
        Args:
            contract_id: ID do contrato
            
        Returns:
            True se excluído com sucesso, False se não encontrado
        """
        contract = self.db.query(DataContract).filter(
            DataContract.contract_id == contract_id
        ).first()
        
        if not contract:
            return False
        
        # Soft delete
        contract.is_active = False
        contract.contract_status = "deleted"
        
        self.db.commit()
        return True
    
    async def activate_contract(self, contract_id: int) -> Optional[DataContractResponse]:
        """
        Ativa um contrato para uso em produção.
        
        Args:
            contract_id: ID do contrato
            
        Returns:
            DataContractResponse ou None se não encontrado
        """
        contract = self.db.query(DataContract).filter(
            DataContract.contract_id == contract_id
        ).first()
        
        if not contract:
            return None
        
        # Validar se contrato pode ser ativado
        if not self._can_activate_contract(contract):
            raise ValueError("Contrato não pode ser ativado: validação falhou")
        
        contract.contract_status = "active"
        contract.is_active = True
        
        self.db.commit()
        self.db.refresh(contract)
        
        return DataContractResponse.model_validate(contract)
    
    async def validate_contract(self, contract_id: int) -> Optional[dict]:
        """
        Valida a estrutura e regras de um contrato.
        
        Args:
            contract_id: ID do contrato
            
        Returns:
            Resultado da validação ou None se não encontrado
        """
        contract = self.db.query(DataContract).filter(
            DataContract.contract_id == contract_id
        ).first()
        
        if not contract:
            return None
        
        validation_result = {
            "contract_id": contract_id,
            "is_valid": True,
            "errors": [],
            "warnings": []
        }
        
        # Validações básicas
        if not contract.schema_definition:
            validation_result["warnings"].append("Schema definition não definido")
        
        if not contract.quality_rules:
            validation_result["warnings"].append("Regras de qualidade não definidas")
        
        if not contract.sla_definition:
            validation_result["warnings"].append("SLA não definido")
        
        # Validar schema se presente
        if contract.schema_definition:
            schema_validation = self._validate_schema(contract.schema_definition)
            if not schema_validation["is_valid"]:
                validation_result["is_valid"] = False
                validation_result["errors"].extend(schema_validation["errors"])
        
        return validation_result
    
    def _can_activate_contract(self, contract: DataContract) -> bool:
        """
        Verifica se um contrato pode ser ativado.
        
        Args:
            contract: Instância do contrato
            
        Returns:
            True se pode ser ativado
        """
        # Verificações básicas
        if not contract.schema_definition:
            return False
        
        if not contract.contract_owner:
            return False
        
        return True
    
    def _validate_schema(self, schema_definition: dict) -> dict:
        """
        Valida a definição do schema.
        
        Args:
            schema_definition: Definição do schema
            
        Returns:
            Resultado da validação
        """
        result = {
            "is_valid": True,
            "errors": []
        }
        
        # Validações básicas do schema
        if not isinstance(schema_definition, dict):
            result["is_valid"] = False
            result["errors"].append("Schema deve ser um objeto JSON válido")
            return result
        
        if "fields" not in schema_definition:
            result["is_valid"] = False
            result["errors"].append("Schema deve conter campo 'fields'")
        
        return result

