"""
System Configuration model.
"""

from sqlalchemy import Boolean, Column, String, Text

from app.models.base import BaseModel


class SystemConfiguration(BaseModel):
    """
    System Configuration model.
    
    System-wide configuration settings.
    """

    __tablename__ = "system_configurations"

    # Configuration identification
    config_key = Column(
        String(255),
        nullable=False,
        unique=True,
        index=True,
        doc="Unique configuration key"
    )

    config_description = Column(
        Text,
        doc="Configuration description"
    )

    # Configuration value
    config_value = Column(
        Text,
        doc="Configuration value"
    )

    config_type = Column(
        String(50),
        nullable=False,
        doc="Value type: string, integer, boolean, json, encrypted"
    )

    default_value = Column(
        Text,
        doc="Default value"
    )

    # Configuration properties
    is_encrypted = Column(
        Boolean,
        default=False,
        doc="Value is encrypted"
    )

    is_system_config = Column(
        Boolean,
        default=False,
        doc="System configuration (cannot be deleted)"
    )

    is_user_configurable = Column(
        Boolean,
        default=True,
        doc="Can be configured by users"
    )

    requires_restart = Column(
        Boolean,
        default=False,
        doc="Requires system restart to take effect"
    )

    # Categorization
    config_category = Column(
        String(100),
        index=True,
        doc="Category: database, security, integration, monitoring, ui"
    )

    config_group = Column(
        String(100),
        doc="Configuration group"
    )

    # Validation
    validation_rules = Column(
        Text,
        doc="Validation rules as JSON"
    )

    allowed_values = Column(
        Text,
        doc="Allowed values as JSON array"
    )

    # Change tracking
    last_modified_by = Column(
        String(255),
        doc="User who last modified the configuration"
    )

    change_reason = Column(
        Text,
        doc="Reason for the change"
    )

    # Status
    config_status = Column(
        String(50),
        default="active",
        index=True,
        doc="Status: active, inactive, deprecated"
    )

    def __repr__(self) -> str:
        return f"<SystemConfiguration(key={self.config_key}, category={self.config_category})>"

