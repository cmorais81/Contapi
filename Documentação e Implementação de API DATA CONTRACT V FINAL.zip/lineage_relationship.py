"""
Lineage Relationship model.
"""

from sqlalchemy import Column, ForeignKey, String, Text
from sqlalchemy.dialects.postgresql import UUID as PostgresUUID
from sqlalchemy.orm import relationship

from app.models.base import BaseModel
from app.models.mixins import ValidationMixin


class LineageRelationship(BaseModel, ValidationMixin):
    """
    Lineage Relationship model.
    
    Relationships between internal and external objects.
    """

    __tablename__ = "lineage_relationships"

    # Source object
    source_type = Column(
        String(50),
        nullable=False,
        index=True,
        doc="Source type: internal, external"
    )

    source_object_id = Column(
        PostgresUUID(as_uuid=True),
        nullable=False,
        index=True,
        doc="Source object ID (internal or external)"
    )

    source_object_name = Column(
        String(255),
        doc="Source object name for reference"
    )

    # Target object
    target_type = Column(
        String(50),
        nullable=False,
        index=True,
        doc="Target type: internal, external"
    )

    target_object_id = Column(
        PostgresUUID(as_uuid=True),
        nullable=False,
        index=True,
        doc="Target object ID (internal or external)"
    )

    target_object_name = Column(
        String(255),
        doc="Target object name for reference"
    )

    # Relationship details
    relationship_type = Column(
        String(100),
        nullable=False,
        index=True,
        doc="Type: upstream, downstream, bidirectional, derived_from, feeds_into"
    )

    transformation_description = Column(
        Text,
        doc="Description of transformation between objects"
    )

    transformation_logic = Column(
        Text,
        doc="Transformation logic (SQL, code, etc.)"
    )

    # Metadata
    relationship_strength = Column(
        String(10),  # Using String to handle numeric as text
        doc="Relationship strength (0-1)"
    )

    data_flow_frequency = Column(
        String(50),
        doc="Data flow frequency: real-time, hourly, daily, weekly, monthly"
    )

    # Status
    relationship_status = Column(
        String(50),
        default="active",
        index=True,
        doc="Status: active, inactive, deprecated"
    )

    # Relationships (conditional based on type)
    source_external_object = relationship(
        "ExternalLineageObject",
        foreign_keys=[source_object_id],
        back_populates="source_relationships",
        primaryjoin="and_(LineageRelationship.source_object_id == ExternalLineageObject.id, LineageRelationship.source_type == 'external')",
        viewonly=True
    )

    target_external_object = relationship(
        "ExternalLineageObject",
        foreign_keys=[target_object_id],
        back_populates="target_relationships",
        primaryjoin="and_(LineageRelationship.target_object_id == ExternalLineageObject.id, LineageRelationship.target_type == 'external')",
        viewonly=True
    )

    def __repr__(self) -> str:
        return f"<LineageRelationship(type={self.relationship_type}, source={self.source_object_name}, target={self.target_object_name})>"

