# Data Governance API - Local Deployment Script
# PowerShell Script for deploying the application locally using Docker

param(
    [Parameter(Mandatory=$false)]
    [ValidateSet("development", "staging", "production")]
    [string]$Environment = "development",
    
    [Parameter(Mandatory=$false)]
    [switch]$Build,
    
    [Parameter(Mandatory=$false)]
    [switch]$Clean,
    
    [Parameter(Mandatory=$false)]
    [switch]$Logs,
    
    [Parameter(Mandatory=$false)]
    [switch]$Stop,
    
    [Parameter(Mandatory=$false)]
    [switch]$Restart,
    
    [Parameter(Mandatory=$false)]
    [switch]$Verbose
)

# Enable verbose output if requested
if ($Verbose) {
    $VerbosePreference = "Continue"
}

# Color functions for better output
function Write-Success {
    param([string]$Message)
    Write-Host "✅ $Message" -ForegroundColor Green
}

function Write-Info {
    param([string]$Message)
    Write-Host "ℹ️  $Message" -ForegroundColor Cyan
}

function Write-Warning {
    param([string]$Message)
    Write-Host "⚠️  $Message" -ForegroundColor Yellow
}

function Write-Error {
    param([string]$Message)
    Write-Host "❌ $Message" -ForegroundColor Red
}

function Write-Step {
    param([string]$Message)
    Write-Host "`n🔄 $Message" -ForegroundColor Blue
}

# Function to check if Docker is running
function Test-DockerRunning {
    try {
        docker info | Out-Null
        return $true
    }
    catch {
        return $false
    }
}

# Function to check if a command exists
function Test-Command {
    param([string]$Command)
    try {
        Get-Command $Command -ErrorAction Stop | Out-Null
        return $true
    }
    catch {
        return $false
    }
}

# Function to validate environment
function Test-Environment {
    Write-Step "Validating environment"
    
    # Check if Docker is installed
    if (-not (Test-Command "docker")) {
        Write-Error "Docker is not installed. Please install Docker Desktop first."
        exit 1
    }
    
    # Check if Docker is running
    if (-not (Test-DockerRunning)) {
        Write-Error "Docker is not running. Please start Docker Desktop."
        exit 1
    }
    
    # Check if docker-compose is available
    if (-not (Test-Command "docker-compose")) {
        Write-Error "docker-compose is not available. Please ensure Docker Desktop is properly installed."
        exit 1
    }
    
    # Check if we're in the project root
    if (-not (Test-Path "docker-compose.yml")) {
        Write-Error "docker-compose.yml not found. Please run this script from the project root directory."
        exit 1
    }
    
    Write-Success "Environment validation passed"
}

# Function to setup environment file
function Setup-EnvironmentFile {
    param([string]$Environment)
    
    Write-Step "Setting up environment file for $Environment"
    
    $envFile = ".env"
    $envExampleFile = ".env.example"
    
    if (-not (Test-Path $envFile)) {
        if (Test-Path $envExampleFile) {
            Copy-Item $envExampleFile $envFile
            Write-Success "Environment file created from example"
        }
        else {
            Write-Warning "No environment file found. Creating basic configuration."
            Create-BasicEnvFile -Environment $Environment
        }
    }
    else {
        Write-Info "Environment file already exists"
    }
    
    # Update environment-specific settings
    Update-EnvironmentSettings -Environment $Environment
}

# Function to create basic environment file
function Create-BasicEnvFile {
    param([string]$Environment)
    
    $envContent = @"
# Data Governance API Environment Configuration
# Environment: $Environment

# Database Configuration
DATABASE_URL=postgresql://postgres:postgres123@db:5432/data_governance
TEST_DATABASE_URL=postgresql://postgres:postgres123@db:5432/data_governance_test

# API Configuration
API_HOST=0.0.0.0
API_PORT=8000
API_DOCS_ENABLED=true

# Security Configuration
SECRET_KEY=dev-secret-key-change-in-production
JWT_ALGORITHM=HS256
JWT_EXPIRE_MINUTES=30

# Environment
ENVIRONMENT=$Environment
LOG_LEVEL=DEBUG

# Docker Configuration
POSTGRES_DB=data_governance
POSTGRES_USER=postgres
POSTGRES_PASSWORD=postgres123

# External Integrations (Optional)
UNITY_CATALOG_URL=
UNITY_CATALOG_TOKEN=
TABLEAU_SERVER_URL=
TABLEAU_USERNAME=
TABLEAU_PASSWORD=
"@
    
    $envContent | Out-File -FilePath ".env" -Encoding UTF8
    Write-Success "Basic environment file created"
}

# Function to update environment-specific settings
function Update-EnvironmentSettings {
    param([string]$Environment)
    
    $envContent = Get-Content ".env"
    
    switch ($Environment) {
        "development" {
            $envContent = $envContent -replace "LOG_LEVEL=.*", "LOG_LEVEL=DEBUG"
            $envContent = $envContent -replace "API_DOCS_ENABLED=.*", "API_DOCS_ENABLED=true"
        }
        "staging" {
            $envContent = $envContent -replace "LOG_LEVEL=.*", "LOG_LEVEL=INFO"
            $envContent = $envContent -replace "API_DOCS_ENABLED=.*", "API_DOCS_ENABLED=true"
        }
        "production" {
            $envContent = $envContent -replace "LOG_LEVEL=.*", "LOG_LEVEL=WARNING"
            $envContent = $envContent -replace "API_DOCS_ENABLED=.*", "API_DOCS_ENABLED=false"
            Write-Warning "Production environment detected. Please ensure SECRET_KEY is properly configured!"
        }
    }
    
    $envContent | Out-File -FilePath ".env" -Encoding UTF8
    Write-Info "Environment settings updated for $Environment"
}

# Function to build Docker images
function Build-Images {
    Write-Step "Building Docker images"
    
    try {
        docker-compose build --no-cache
        Write-Success "Docker images built successfully"
    }
    catch {
        Write-Error "Failed to build Docker images: $($_.Exception.Message)"
        exit 1
    }
}

# Function to start services
function Start-Services {
    param([string]$Environment)
    
    Write-Step "Starting services for $Environment environment"
    
    try {
        # Start services in detached mode
        docker-compose up -d
        
        Write-Success "Services started successfully"
        
        # Wait for services to be ready
        Write-Info "Waiting for services to be ready..."
        Start-Sleep -Seconds 10
        
        # Check service health
        Check-ServiceHealth
        
    }
    catch {
        Write-Error "Failed to start services: $($_.Exception.Message)"
        exit 1
    }
}

# Function to check service health
function Check-ServiceHealth {
    Write-Step "Checking service health"
    
    $maxRetries = 30
    $retryCount = 0
    
    while ($retryCount -lt $maxRetries) {
        try {
            $response = Invoke-WebRequest -Uri "http://localhost:8000/health" -TimeoutSec 5 -ErrorAction Stop
            if ($response.StatusCode -eq 200) {
                Write-Success "API service is healthy"
                break
            }
        }
        catch {
            $retryCount++
            if ($retryCount -eq $maxRetries) {
                Write-Error "API service failed to start properly"
                Show-ServiceLogs
                exit 1
            }
            Write-Info "Waiting for API service... (attempt $retryCount/$maxRetries)"
            Start-Sleep -Seconds 2
        }
    }
    
    # Check database connectivity
    try {
        $dbCheck = docker-compose exec -T db psql -U postgres -d data_governance -c "SELECT 1;" 2>$null
        if ($LASTEXITCODE -eq 0) {
            Write-Success "Database is accessible"
        }
        else {
            Write-Warning "Database connectivity check failed"
        }
    }
    catch {
        Write-Warning "Could not verify database connectivity"
    }
}

# Function to stop services
function Stop-Services {
    Write-Step "Stopping services"
    
    try {
        docker-compose down
        Write-Success "Services stopped successfully"
    }
    catch {
        Write-Error "Failed to stop services: $($_.Exception.Message)"
    }
}

# Function to restart services
function Restart-Services {
    param([string]$Environment)
    
    Write-Step "Restarting services"
    
    Stop-Services
    Start-Sleep -Seconds 2
    Start-Services -Environment $Environment
}

# Function to clean up
function Clean-Environment {
    Write-Step "Cleaning up Docker environment"
    
    try {
        # Stop and remove containers
        docker-compose down -v --remove-orphans
        
        # Remove images
        $images = docker images "data-governance-api*" -q
        if ($images) {
            docker rmi $images -f
        }
        
        # Remove unused volumes
        docker volume prune -f
        
        Write-Success "Environment cleaned up successfully"
    }
    catch {
        Write-Error "Failed to clean up environment: $($_.Exception.Message)"
    }
}

# Function to show logs
function Show-ServiceLogs {
    Write-Step "Showing service logs"
    
    try {
        docker-compose logs --tail=50 -f
    }
    catch {
        Write-Error "Failed to show logs: $($_.Exception.Message)"
    }
}

# Function to run database migrations
function Run-DatabaseMigrations {
    Write-Step "Running database migrations"
    
    try {
        # Wait for database to be ready
        Start-Sleep -Seconds 5
        
        # Run migrations
        docker-compose exec api alembic upgrade head
        Write-Success "Database migrations completed"
        
        # Populate with sample data (optional)
        $populateChoice = Read-Host "Do you want to populate the database with sample data? (y/N)"
        if ($populateChoice -eq "y" -or $populateChoice -eq "Y") {
            docker-compose exec api python scripts/populate_db.py
            Write-Success "Sample data populated"
        }
    }
    catch {
        Write-Error "Failed to run database migrations: $($_.Exception.Message)"
        Write-Info "You can run migrations manually with: docker-compose exec api alembic upgrade head"
    }
}

# Function to show deployment information
function Show-DeploymentInfo {
    param([string]$Environment)
    
    Write-Host "`n🎉 Deployment completed successfully!" -ForegroundColor Green
    Write-Host "================================================================" -ForegroundColor Green
    
    Write-Info "Environment: $Environment"
    Write-Info "API URL: http://localhost:8000"
    Write-Info "API Documentation: http://localhost:8000/docs"
    Write-Info "ReDoc Documentation: http://localhost:8000/redoc"
    Write-Info "Health Check: http://localhost:8000/health"
    
    Write-Host "`nUseful commands:" -ForegroundColor Yellow
    Write-Info "View logs: docker-compose logs -f"
    Write-Info "Stop services: docker-compose down"
    Write-Info "Restart services: docker-compose restart"
    Write-Info "Access API container: docker-compose exec api bash"
    Write-Info "Access database: docker-compose exec db psql -U postgres -d data_governance"
    
    Write-Host "`nService Status:" -ForegroundColor Yellow
    try {
        docker-compose ps
    }
    catch {
        Write-Warning "Could not retrieve service status"
    }
}

# Main execution function
function Main {
    Write-Host "🚀 Data Governance API - Local Deployment" -ForegroundColor Magenta
    Write-Host "================================================" -ForegroundColor Magenta
    
    try {
        # Handle stop command
        if ($Stop) {
            Stop-Services
            return
        }
        
        # Handle clean command
        if ($Clean) {
            Clean-Environment
            return
        }
        
        # Handle logs command
        if ($Logs) {
            Show-ServiceLogs
            return
        }
        
        # Validate environment
        Test-Environment
        
        # Setup environment file
        Setup-EnvironmentFile -Environment $Environment
        
        # Handle restart command
        if ($Restart) {
            Restart-Services -Environment $Environment
            Show-DeploymentInfo -Environment $Environment
            return
        }
        
        # Build images if requested
        if ($Build) {
            Build-Images
        }
        
        # Start services
        Start-Services -Environment $Environment
        
        # Run database migrations
        Run-DatabaseMigrations
        
        # Show deployment information
        Show-DeploymentInfo -Environment $Environment
        
    }
    catch {
        Write-Error "Deployment failed: $($_.Exception.Message)"
        exit 1
    }
}

# Show help if no parameters
if ($args.Count -eq 0 -and -not $PSBoundParameters.Count) {
    Write-Host "Data Governance API - Local Deployment Script" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "Usage:" -ForegroundColor Yellow
    Write-Host "  .\deploy-local.ps1 [-Environment <env>] [-Build] [-Clean] [-Logs] [-Stop] [-Restart]"
    Write-Host ""
    Write-Host "Parameters:" -ForegroundColor Yellow
    Write-Host "  -Environment    Target environment (development, staging, production). Default: development"
    Write-Host "  -Build          Force rebuild of Docker images"
    Write-Host "  -Clean          Clean up Docker environment (stop containers, remove images)"
    Write-Host "  -Logs           Show service logs"
    Write-Host "  -Stop           Stop all services"
    Write-Host "  -Restart        Restart all services"
    Write-Host "  -Verbose        Enable verbose output"
    Write-Host ""
    Write-Host "Examples:" -ForegroundColor Yellow
    Write-Host "  .\deploy-local.ps1                          # Deploy in development mode"
    Write-Host "  .\deploy-local.ps1 -Environment staging     # Deploy in staging mode"
    Write-Host "  .\deploy-local.ps1 -Build                   # Force rebuild and deploy"
    Write-Host "  .\deploy-local.ps1 -Stop                    # Stop all services"
    Write-Host "  .\deploy-local.ps1 -Clean                   # Clean up environment"
    Write-Host "  .\deploy-local.ps1 -Logs                    # Show logs"
    exit 0
}

# Run main function
Main

