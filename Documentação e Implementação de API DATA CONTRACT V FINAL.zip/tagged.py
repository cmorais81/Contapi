"""
Tagged schemas.

Desenvolvido por Carlos Morais - Julho 2025
"""

from datetime import datetime
from typing import Optional
from uuid import UUID

from pydantic import Field, validator

from app.schemas.base import BaseSchema


class TaggedBase(BaseSchema):
    """Schema base para associações tag-entidade."""
    
    entity_id: UUID = Field(
        ...,
        description="ID da entidade"
    )
    
    tag_id: UUID = Field(
        ...,
        description="ID da tag"
    )
    
    tag_value: Optional[str] = Field(
        None,
        description="Valor da tag, se aplicável",
        examples=["High", "2024-12-31", "john.doe@company.com"]
    )
    
    tagged_by: str = Field(
        ...,
        description="Usuário que aplicou a tag",
        examples=["carlos.morais", "data.steward@company.com"]
    )
    
    tag_reason: Optional[str] = Field(
        None,
        description="Razão da aplicação da tag",
        examples=["Contém dados pessoais", "Classificação automática", "Revisão de compliance"]
    )
    
    is_active: bool = Field(
        True,
        description="Associação ativa"
    )


class TaggedCreate(TaggedBase):
    """Schema para criação de associação tag-entidade."""
    
    @validator('tagged_by')
    def validate_tagged_by(cls, v):
        if len(v.strip()) < 2:
            raise ValueError('Campo tagged_by deve ter pelo menos 2 caracteres')
        return v.strip()


class TaggedUpdate(BaseSchema):
    """Schema para atualização de associação tag-entidade."""
    
    tag_value: Optional[str] = Field(
        None,
        description="Valor da tag"
    )
    
    tag_reason: Optional[str] = Field(
        None,
        description="Razão da aplicação/atualização"
    )
    
    is_active: Optional[bool] = Field(
        None,
        description="Associação ativa"
    )


class TaggedResponse(TaggedBase):
    """Schema de resposta para associação tag-entidade."""
    
    tagged_id: UUID = Field(
        ...,
        description="Identificador único da associação"
    )
    
    data_criacao: datetime = Field(
        ...,
        description="Data de criação"
    )
    
    data_atualizacao: datetime = Field(
        ...,
        description="Data da última atualização"
    )
    
    class Config:
        from_attributes = True


class TaggedWithDetails(TaggedResponse):
    """Schema de associação com detalhes da tag e entidade."""
    
    # Detalhes da tag
    tag_name: str = Field(
        ...,
        description="Nome da tag"
    )
    
    tag_description: Optional[str] = Field(
        None,
        description="Descrição da tag"
    )
    
    tag_category: Optional[str] = Field(
        None,
        description="Categoria da tag"
    )
    
    tag_color: Optional[str] = Field(
        None,
        description="Cor da tag"
    )
    
    tag_icon: Optional[str] = Field(
        None,
        description="Ícone da tag"
    )
    
    # Detalhes da entidade
    entity_name: str = Field(
        ...,
        description="Nome da entidade"
    )
    
    entity_type: str = Field(
        ...,
        description="Tipo da entidade"
    )
    
    entity_description: Optional[str] = Field(
        None,
        description="Descrição da entidade"
    )


class TaggedBulkCreate(BaseSchema):
    """Schema para criação em lote de associações."""
    
    entity_ids: list[UUID] = Field(
        ...,
        description="Lista de IDs das entidades",
        min_items=1,
        max_items=100
    )
    
    tag_id: UUID = Field(
        ...,
        description="ID da tag a ser aplicada"
    )
    
    tag_value: Optional[str] = Field(
        None,
        description="Valor da tag para todas as entidades"
    )
    
    tagged_by: str = Field(
        ...,
        description="Usuário que está aplicando as tags"
    )
    
    tag_reason: Optional[str] = Field(
        None,
        description="Razão da aplicação em lote"
    )


class TaggedBulkUpdate(BaseSchema):
    """Schema para atualização em lote de associações."""
    
    tagged_ids: list[UUID] = Field(
        ...,
        description="Lista de IDs das associações",
        min_items=1,
        max_items=100
    )
    
    tag_value: Optional[str] = Field(
        None,
        description="Novo valor da tag"
    )
    
    tag_reason: Optional[str] = Field(
        None,
        description="Razão da atualização"
    )
    
    is_active: Optional[bool] = Field(
        None,
        description="Status ativo"
    )


class TaggedSearch(BaseSchema):
    """Schema para busca de associações tag-entidade."""
    
    entity_id: Optional[UUID] = Field(
        None,
        description="Filtro por entidade"
    )
    
    tag_id: Optional[UUID] = Field(
        None,
        description="Filtro por tag"
    )
    
    tag_name: Optional[str] = Field(
        None,
        description="Filtro por nome da tag"
    )
    
    tag_category: Optional[str] = Field(
        None,
        description="Filtro por categoria da tag"
    )
    
    entity_type: Optional[str] = Field(
        None,
        description="Filtro por tipo da entidade"
    )
    
    tagged_by: Optional[str] = Field(
        None,
        description="Filtro por usuário que aplicou"
    )
    
    is_active: Optional[bool] = Field(
        True,
        description="Filtro por associações ativas"
    )
    
    include_details: bool = Field(
        False,
        description="Incluir detalhes da tag e entidade"
    )


class TaggedStats(BaseSchema):
    """Estatísticas de associações tag-entidade."""
    
    total_associations: int = Field(
        0,
        description="Total de associações"
    )
    
    active_associations: int = Field(
        0,
        description="Associações ativas"
    )
    
    unique_entities: int = Field(
        0,
        description="Entidades únicas com tags"
    )
    
    unique_tags: int = Field(
        0,
        description="Tags únicas aplicadas"
    )
    
    top_tags: list[dict] = Field(
        default_factory=list,
        description="Tags mais utilizadas"
    )
    
    top_taggers: list[dict] = Field(
        default_factory=list,
        description="Usuários que mais aplicam tags"
    )
    
    recent_activity: list[dict] = Field(
        default_factory=list,
        description="Atividade recente"
    )

