"""
User model.
"""

from sqlalchemy import Boolean, Column, DateTime, String
from sqlalchemy.orm import relationship

from app.models.base import BaseModel


class User(BaseModel):
    """
    User model.
    
    System users with authentication and authorization.
    """

    __tablename__ = "users"

    # Basic information
    username = Column(
        String(255),
        nullable=False,
        unique=True,
        index=True,
        doc="Unique username"
    )

    email = Column(
        String(255),
        nullable=False,
        unique=True,
        index=True,
        doc="User email address"
    )

    full_name = Column(
        String(255),
        doc="User full name"
    )

    # Authentication
    hashed_password = Column(
        String(255),
        doc="Hashed password"
    )

    is_active = Column(
        Boolean,
        default=True,
        doc="User is active"
    )

    is_superuser = Column(
        Boolean,
        default=False,
        doc="User has superuser privileges"
    )

    # Profile information
    department = Column(
        String(255),
        doc="User department"
    )

    job_title = Column(
        String(255),
        doc="Job title"
    )

    phone_number = Column(
        String(50),
        doc="Phone number"
    )

    # Authentication tracking
    last_login = Column(
        DateTime(timezone=True),
        doc="Last login timestamp"
    )

    failed_login_attempts = Column(
        String(10),  # Using String to handle integer as text
        default="0",
        doc="Failed login attempts counter"
    )

    password_changed_at = Column(
        DateTime(timezone=True),
        doc="Password last changed timestamp"
    )

    # External integration
    azure_ad_object_id = Column(
        String(255),
        unique=True,
        doc="Azure AD object ID"
    )

    external_user_id = Column(
        String(255),
        doc="External system user ID"
    )

    # Relationships
    user_roles = relationship(
        "UserRole",
        back_populates="user",
        cascade="all, delete-orphan"
    )

    def __repr__(self) -> str:
        return f"<User(username={self.username}, email={self.email})>"

