"""
Cost Analysis model.

Desenvolvido por Carlos Morais - Julho 2025
"""

from sqlalchemy import Column, String, Text, UUID

from app.models.base import BaseModel
from app.models.mixins import TimestampMixin


class CostAnalysis(BaseModel, TimestampMixin):
    """
    Modelo para análise de custos.
    """
    
    __tablename__ = "cost_analysis"
    
    analysis_id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        server_default="gen_random_uuid()",
        comment="Identificador único da análise"
    )
    
    analysis_name = Column(
        String(255),
        nullable=False,
        comment="Nome da análise"
    )
    
    description = Column(
        Text,
        comment="Descrição da análise"
    )
    
    total_cost_usd = Column(
        String(20),
        comment="Custo total em USD"
    )

