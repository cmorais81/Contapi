"""
Integration Config model.
"""

from sqlalchemy import Boolean, Column, String, Text

from app.models.base import BaseModel


class IntegrationConfig(BaseModel):
    """
    Integration Config model.
    
    Configuration for external system integrations.
    """

    __tablename__ = "integration_configs"

    # Integration identification
    integration_name = Column(
        String(255),
        nullable=False,
        unique=True,
        index=True,
        doc="Unique integration name"
    )

    integration_description = Column(
        Text,
        doc="Integration description"
    )

    # System details
    system_type = Column(
        String(100),
        nullable=False,
        index=True,
        doc="System type: unity_catalog, tableau, powerbi, salesforce, snowflake"
    )

    system_version = Column(
        String(50),
        doc="System version"
    )

    # Connection details
    endpoint_url = Column(
        String(500),
        doc="System endpoint URL"
    )

    authentication_type = Column(
        String(50),
        doc="Authentication type: oauth2, api_key, basic, certificate"
    )

    connection_config = Column(
        Text,
        doc="Connection configuration as JSON (encrypted)"
    )

    # Sync configuration
    sync_enabled = Column(
        Boolean,
        default=True,
        doc="Synchronization enabled"
    )

    sync_frequency = Column(
        String(50),
        doc="Sync frequency: real-time, hourly, daily, weekly"
    )

    last_sync_timestamp = Column(
        String(30),  # Using String to handle timestamp as text
        doc="Last synchronization timestamp"
    )

    sync_status = Column(
        String(50),
        default="pending",
        index=True,
        doc="Sync status: pending, running, completed, failed"
    )

    # Data mapping
    field_mappings = Column(
        Text,
        doc="Field mappings as JSON"
    )

    transformation_rules = Column(
        Text,
        doc="Data transformation rules as JSON"
    )

    # Error handling
    retry_count = Column(
        String(10),  # Using String to handle integer as text
        default="0",
        doc="Retry count for failed syncs"
    )

    max_retries = Column(
        String(10),  # Using String to handle integer as text
        default="3",
        doc="Maximum retry attempts"
    )

    error_threshold = Column(
        String(10),  # Using String to handle integer as text
        default="5",
        doc="Error threshold before disabling"
    )

    # Status
    integration_status = Column(
        String(50),
        default="active",
        index=True,
        doc="Status: active, inactive, error, maintenance"
    )

    def __repr__(self) -> str:
        return f"<IntegrationConfig(name={self.integration_name}, system={self.system_type}, status={self.integration_status})>"

