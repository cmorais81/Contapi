"""
External Lineage Object model.
"""

from sqlalchemy import Column, String, Text
from sqlalchemy.orm import relationship

from app.models.base import BaseModel
from app.models.mixins import ExternalSystemMixin


class ExternalLineageObject(BaseModel, ExternalSystemMixin):
    """
    External Lineage Object model.
    
    External objects for lineage tracking (Tableau, PowerBI, etc.).
    """

    __tablename__ = "external_lineage_objects"

    # Object identification
    object_name = Column(
        String(255),
        nullable=False,
        index=True,
        doc="External object name"
    )

    object_description = Column(
        Text,
        doc="Object description"
    )

    entity_type = Column(
        String(100),
        nullable=False,
        index=True,
        doc="Entity type: dashboard, report, dataset, model, pipeline"
    )

    # System-specific properties
    system_type = Column(
        String(100),
        nullable=False,
        index=True,
        doc="System type: tableau, powerbi, salesforce, snowflake, databricks"
    )

    workspace_name = Column(
        String(255),
        doc="Workspace or project name"
    )

    owner_email = Column(
        String(255),
        doc="Owner email address"
    )

    # Custom properties (JSON)
    custom_properties = Column(
        Text,
        doc="Custom properties as JSON"
    )

    # Status
    object_status = Column(
        String(50),
        default="active",
        index=True,
        doc="Status: active, inactive, deprecated, archived"
    )

    # Relationships
    source_relationships = relationship(
        "LineageRelationship",
        foreign_keys="LineageRelationship.source_object_id",
        back_populates="source_external_object",
        cascade="all, delete-orphan"
    )

    target_relationships = relationship(
        "LineageRelationship",
        foreign_keys="LineageRelationship.target_object_id",
        back_populates="target_external_object",
        cascade="all, delete-orphan"
    )

    def __repr__(self) -> str:
        return f"<ExternalLineageObject(name={self.object_name}, type={self.entity_type}, system={self.system_type})>"

