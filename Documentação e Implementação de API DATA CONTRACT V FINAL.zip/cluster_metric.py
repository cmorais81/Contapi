"""
Cluster Metric model.
"""

from sqlalchemy import Column, ForeignKey, String
from sqlalchemy.dialects.postgresql import UUID as PostgresUUID
from sqlalchemy.orm import relationship

from app.models.base import BaseModel
from app.models.mixins import MetricsMixin


class ClusterMetric(BaseModel, MetricsMixin):
    """
    Cluster Metric model.
    
    Databricks cluster performance metrics.
    """

    __tablename__ = "cluster_metrics"

    # Foreign key to contract
    contract_id = Column(
        PostgresUUID(as_uuid=True),
        ForeignKey("data_contracts.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
        doc="Reference to contract"
    )

    # Cluster identification
    cluster_id = Column(
        String(255),
        nullable=False,
        index=True,
        doc="Databricks cluster ID"
    )

    cluster_name = Column(
        String(255),
        doc="Cluster name"
    )

    # Performance metrics
    cpu_utilization_percent = Column(
        String(10),  # Using String to handle numeric as text
        doc="CPU utilization percentage"
    )

    memory_utilization_percent = Column(
        String(10),  # Using String to handle numeric as text
        doc="Memory utilization percentage"
    )

    disk_utilization_percent = Column(
        String(10),  # Using String to handle numeric as text
        doc="Disk utilization percentage"
    )

    network_io_mbps = Column(
        String(20),  # Using String to handle numeric as text
        doc="Network I/O in Mbps"
    )

    # Cluster status
    cluster_state = Column(
        String(50),
        doc="Cluster state: running, terminated, pending, error"
    )

    node_count = Column(
        String(10),  # Using String to handle integer as text
        doc="Number of nodes in cluster"
    )

    driver_node_type = Column(
        String(100),
        doc="Driver node type"
    )

    worker_node_type = Column(
        String(100),
        doc="Worker node type"
    )

    # Cost metrics
    dbu_consumption = Column(
        String(20),  # Using String to handle numeric as text
        doc="DBU consumption"
    )

    cost_usd = Column(
        String(20),  # Using String to handle numeric as text
        doc="Cost in USD"
    )

    # Relationships
    contract = relationship(
        "DataContract",
        back_populates="cluster_metrics"
    )

    def __repr__(self) -> str:
        return f"<ClusterMetric(cluster_id={self.cluster_id}, state={self.cluster_state})>"

