"""
Unit tests for SQLAlchemy models.
"""

import pytest
from datetime import datetime
from uuid import uuid4

from app.models.contracts import DataContract
from app.models.users import User, Role
from app.models.quality import QualityRule
from app.models.lineage import ExternalLineageObject
from app.models.tags import Tag


class TestDataContractModel:
    """Test DataContract model."""
    
    def test_create_data_contract(self):
        """Test creating a DataContract instance."""
        contract = DataContract(
            contract_name="test_contract",
            contract_description="Test contract description",
            contract_owner="test@example.com",
            business_domain="testing",
            contract_status="draft"
        )
        
        assert contract.contract_name == "test_contract"
        assert contract.contract_description == "Test contract description"
        assert contract.contract_owner == "test@example.com"
        assert contract.business_domain == "testing"
        assert contract.contract_status == "draft"
    
    def test_data_contract_defaults(self):
        """Test DataContract default values."""
        contract = DataContract(
            contract_name="test_contract"
        )
        
        assert contract.abac_enabled is False
        assert contract.monitoring_enabled is True
        assert contract.contract_status == "draft"
    
    def test_data_contract_repr(self):
        """Test DataContract string representation."""
        contract = DataContract(
            contract_name="test_contract",
            business_domain="testing"
        )
        
        repr_str = repr(contract)
        assert "test_contract" in repr_str
        assert "testing" in repr_str


class TestUserModel:
    """Test User model."""
    
    def test_create_user(self):
        """Test creating a User instance."""
        user = User(
            username="testuser",
            email="test@example.com",
            full_name="Test User",
            is_active=True,
            is_superuser=False
        )
        
        assert user.username == "testuser"
        assert user.email == "test@example.com"
        assert user.full_name == "Test User"
        assert user.is_active is True
        assert user.is_superuser is False
    
    def test_user_defaults(self):
        """Test User default values."""
        user = User(
            username="testuser",
            email="test@example.com"
        )
        
        assert user.is_active is True
        assert user.is_superuser is False
        assert user.failed_login_attempts == "0"
    
    def test_user_repr(self):
        """Test User string representation."""
        user = User(
            username="testuser",
            email="test@example.com"
        )
        
        repr_str = repr(user)
        assert "testuser" in repr_str
        assert "test@example.com" in repr_str


class TestRoleModel:
    """Test Role model."""
    
    def test_create_role(self):
        """Test creating a Role instance."""
        role = Role(
            role_name="data_analyst",
            role_description="Data analyst role",
            is_system_role=False,
            is_active=True
        )
        
        assert role.role_name == "data_analyst"
        assert role.role_description == "Data analyst role"
        assert role.is_system_role is False
        assert role.is_active is True
    
    def test_role_defaults(self):
        """Test Role default values."""
        role = Role(
            role_name="test_role"
        )
        
        assert role.is_system_role is False
        assert role.is_active is True
        assert role.role_level == "1"
    
    def test_role_repr(self):
        """Test Role string representation."""
        role = Role(
            role_name="test_role",
            is_active=True
        )
        
        repr_str = repr(role)
        assert "test_role" in repr_str
        assert "True" in repr_str


class TestQualityRuleModel:
    """Test QualityRule model."""
    
    def test_create_quality_rule(self):
        """Test creating a QualityRule instance."""
        rule = QualityRule(
            rule_name="completeness_check",
            rule_description="Check data completeness",
            rule_type="completeness",
            rule_category="data_quality",
            severity_level="high",
            is_enabled=True
        )
        
        assert rule.rule_name == "completeness_check"
        assert rule.rule_description == "Check data completeness"
        assert rule.rule_type == "completeness"
        assert rule.rule_category == "data_quality"
        assert rule.severity_level == "high"
        assert rule.is_enabled is True
    
    def test_quality_rule_defaults(self):
        """Test QualityRule default values."""
        rule = QualityRule(
            rule_name="test_rule",
            rule_type="completeness"
        )
        
        assert rule.is_enabled is True
        assert rule.rule_status == "active"
    
    def test_quality_rule_repr(self):
        """Test QualityRule string representation."""
        rule = QualityRule(
            rule_name="test_rule",
            rule_type="completeness"
        )
        
        repr_str = repr(rule)
        assert "test_rule" in repr_str
        assert "completeness" in repr_str


class TestExternalLineageObjectModel:
    """Test ExternalLineageObject model."""
    
    def test_create_external_object(self):
        """Test creating an ExternalLineageObject instance."""
        obj = ExternalLineageObject(
            object_name="sales_dashboard",
            object_description="Sales performance dashboard",
            entity_type="dashboard",
            system_type="tableau",
            workspace_name="sales_workspace",
            owner_email="sales@example.com"
        )
        
        assert obj.object_name == "sales_dashboard"
        assert obj.object_description == "Sales performance dashboard"
        assert obj.entity_type == "dashboard"
        assert obj.system_type == "tableau"
        assert obj.workspace_name == "sales_workspace"
        assert obj.owner_email == "sales@example.com"
    
    def test_external_object_defaults(self):
        """Test ExternalLineageObject default values."""
        obj = ExternalLineageObject(
            object_name="test_object",
            entity_type="dashboard",
            system_type="tableau"
        )
        
        assert obj.object_status == "active"
    
    def test_external_object_repr(self):
        """Test ExternalLineageObject string representation."""
        obj = ExternalLineageObject(
            object_name="test_object",
            entity_type="dashboard",
            system_type="tableau"
        )
        
        repr_str = repr(obj)
        assert "test_object" in repr_str
        assert "dashboard" in repr_str
        assert "tableau" in repr_str


class TestTagModel:
    """Test Tag model."""
    
    def test_create_tag(self):
        """Test creating a Tag instance."""
        tag = Tag(
            tag_name="sensitive_data",
            tag_description="Contains sensitive information",
            tag_category="security",
            tag_type="classification",
            color_code="#FF0000"
        )
        
        assert tag.tag_name == "sensitive_data"
        assert tag.tag_description == "Contains sensitive information"
        assert tag.tag_category == "security"
        assert tag.tag_type == "classification"
        assert tag.color_code == "#FF0000"
    
    def test_tag_defaults(self):
        """Test Tag default values."""
        tag = Tag(
            tag_name="test_tag"
        )
        
        assert tag.is_active is True
        assert tag.is_system_tag is False
        assert tag.usage_count == "0"
        assert tag.tag_level == "1"
    
    def test_tag_repr(self):
        """Test Tag string representation."""
        tag = Tag(
            tag_name="test_tag",
            tag_category="business"
        )
        
        repr_str = repr(tag)
        assert "test_tag" in repr_str
        assert "business" in repr_str


class TestModelMixins:
    """Test model mixins functionality."""
    
    def test_timestamp_mixin(self):
        """Test that models have timestamp fields."""
        contract = DataContract(
            contract_name="test_contract"
        )
        
        # These fields should exist (set by database)
        assert hasattr(contract, 'data_criacao')
        assert hasattr(contract, 'data_atualizacao')
    
    def test_base_model_id(self):
        """Test that models have UUID ID field."""
        contract = DataContract(
            contract_name="test_contract"
        )
        
        assert hasattr(contract, 'id')
        # ID will be set when saved to database
    
    def test_model_table_names(self):
        """Test that models have correct table names."""
        assert DataContract.__tablename__ == "data_contracts"
        assert User.__tablename__ == "users"
        assert Role.__tablename__ == "roles"
        assert QualityRule.__tablename__ == "quality_rules"
        assert ExternalLineageObject.__tablename__ == "external_lineage_objects"
        assert Tag.__tablename__ == "tags"

