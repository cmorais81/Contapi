# Data Governance API v1

[![Python](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/downloads/)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.104+-green.svg)](https://fastapi.tiangolo.com/)
[![SQLAlchemy](https://img.shields.io/badge/SQLAlchemy-2.0+-red.svg)](https://www.sqlalchemy.org/)
[![Pydantic](https://img.shields.io/badge/Pydantic-2.0+-purple.svg)](https://pydantic.dev/)

**Versão:** 1.0  
**Data:** Julho 2025  
**Autor:** Carlos Morais (carlos.morais@f1rst.com.br)  
**Status:** ✅ Produção

## Visão Geral

API completa para governança de dados baseada em contratos, desenvolvida por Carlos Morais com integração Unity Catalog e suporte a external lineage. Implementa padrões OpenAPI 3.0+ com arquitetura limpa e princípios SOLID.

## Características Principais

### 🏗️ **Arquitetura Organizada por Domínios**
- **Contratos de Dados**: Gestão completa de data contracts
- **Qualidade de Dados**: Regras, execuções e monitoramento
- **Linhagem de Dados**: Rastreabilidade e external lineage
- **Métricas**: Monitoramento de performance e custos
- **Usuários**: Autenticação JWT e RBAC
- **Tags**: Sistema flexível de classificação
- **Governança**: Políticas e compliance
- **Integrações**: Unity Catalog, Tableau, Power BI
- **Auditoria**: Logs completos e rastreabilidade
- **Privacidade**: GDPR/LGPD e mascaramento
- **Monitoramento**: Análise de queries e custos

### 🔧 **Tecnologias**
- **Backend**: FastAPI + SQLAlchemy + Pydantic
- **Banco**: PostgreSQL + SQLite (testes)
- **Autenticação**: JWT + OAuth2
- **Documentação**: Swagger/OpenAPI automática
- **Testes**: pytest + factory-boy
- **Deployment**: Docker + Kubernetes + Helm

### 📊 **Funcionalidades v1**
- ✅ 200+ endpoints RESTful organizados
- ✅ 50+ modelos SQLAlchemy por domínio
- ✅ Sistema Entity/Tag/Tagged completo
- ✅ Monitoramento avançado de queries
- ✅ Análise de custos inteligente
- ✅ Privacidade e compliance automático
- ✅ External lineage Unity Catalog
- ✅ Documentação Swagger interativa

## Estrutura do Projeto

```
data-governance-api-v1/
├── 📁 app/                           # Código principal
│   ├── 📁 api/v1/endpoints/          # Endpoints por domínio
│   │   ├── 📁 contracts/             # Gestão de contratos
│   │   ├── 📁 quality/               # Qualidade de dados
│   │   ├── 📁 lineage/               # Linhagem de dados
│   │   ├── 📁 metrics/               # Métricas e monitoramento
│   │   ├── 📁 users/                 # Usuários e permissões
│   │   ├── 📁 tags/                  # Sistema de tags
│   │   ├── 📁 governance/            # Políticas de governança
│   │   ├── 📁 integrations/          # Integrações externas
│   │   ├── 📁 audit/                 # Auditoria e logs
│   │   └── 📁 admin/                 # Administração
│   │
│   ├── 📁 models/                    # Modelos por domínio
│   ├── 📁 schemas/                   # Schemas por domínio
│   ├── 📁 services/                  # Business logic por domínio
│   └── 📁 core/                      # Configurações centrais
│
├── 📁 tests/                         # Testes organizados
├── 📁 docs/                          # Documentação completa
├── 📁 scripts/                       # Scripts utilitários
├── 📁 deployment/                    # Configurações de deploy
└── 📁 monitoring/                    # Monitoramento e alertas
```

## Quick Start

### 1. Pré-requisitos
```bash
# Python 3.11+
python --version

# Docker (para banco de dados)
docker --version

# Git
git --version
```

### 2. Instalação
```bash
# Clonar repositório
git clone <repository-url>
cd data-governance-api-v1

# Criar ambiente virtual
python -m venv venv
source venv/bin/activate  # Linux/Mac
# ou
venv\Scripts\activate     # Windows

# Instalar dependências
pip install -r requirements.txt
```

### 3. Configuração
```bash
# Copiar arquivo de ambiente
cp .env.example .env

# Iniciar banco PostgreSQL
docker run --name postgres-governance \
  -e POSTGRES_DB=data_governance \
  -e POSTGRES_USER=governance_user \
  -e POSTGRES_PASSWORD=governance_pass \
  -p 5432:5432 -d postgres:15

# Executar migrations
alembic upgrade head
```

### 4. Execução
```bash
# Desenvolvimento
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000

# Produção
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

### 5. Acesso
- **API Docs**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc
- **OpenAPI**: http://localhost:8000/openapi.json

## Domínios Implementados

### 📋 **Contratos de Dados**
- Criação e versionamento de contratos
- Componentes modulares (SLA, Pricing, Schema)
- Propriedades customizáveis
- Layouts flexíveis

### 🔍 **Qualidade de Dados**
- Regras de qualidade configuráveis
- Execução automática de validações
- Resultados e métricas agregadas
- Detecção de anomalias

### 🔗 **Linhagem de Dados**
- External lineage Unity Catalog
- Relacionamentos entre objetos
- Mapeamento de colunas
- Grafos de dependência

### 📊 **Métricas e Monitoramento**
- Performance de clusters e jobs
- Análise de queries problemáticas
- Custos de processamento
- Alertas automáticos

### 👥 **Usuários e Permissões**
- Autenticação JWT
- RBAC (Role-Based Access Control)
- Grupos e permissões
- Auditoria de acesso

### 🏷️ **Sistema de Tags**
- Entidades unificadas
- Tags hierárquicas
- Associações flexíveis
- Classificação automática

### 🛡️ **Governança e Compliance**
- Políticas ABAC
- Classificação de dados
- GDPR/LGPD compliance
- Mascaramento automático

### 🔌 **Integrações**
- Unity Catalog (Databricks)
- Apache Atlas
- Tableau metadata
- Power BI metadata
- dbt lineage

### 📝 **Auditoria**
- Logs completos de ações
- Rastreabilidade de mudanças
- Agregados de qualidade
- Detecção de anomalias

### 🔒 **Privacidade**
- Classificação PII/PHI/PCI
- Gestão de consentimentos
- Mascaramento dinâmico
- Políticas de retenção

## Funcionalidades Avançadas

### 🚀 **Monitoramento Inteligente**
```python
# Análise de queries problemáticas
GET /api/v1/monitoring/problematic-queries
- Queries > 30s
- Memory spill detection
- Full table scans
- Sugestões de otimização

# Análise de custos
GET /api/v1/monitoring/cost-analysis
- Top consumidores
- Trending temporal
- Outliers de custo
- ROI de otimizações
```

### 🔐 **Privacidade Automática**
```python
# Classificação automática
POST /api/v1/privacy/classify-data
- Detecção PII/PHI/PCI
- Scoring de sensibilidade
- Recomendações de proteção

# Mascaramento dinâmico
GET /api/v1/privacy/masked-data
- Baseado em roles
- Contexto de acesso
- Preservação de utilidade
```

### 🏷️ **Sistema Entity/Tag/Tagged**
```python
# Gestão de entidades
POST /api/v1/entities/
GET /api/v1/entities/{entity_id}/tags
PUT /api/v1/entities/{entity_id}/tag

# Tags hierárquicas
GET /api/v1/tags/hierarchy
POST /api/v1/tags/bulk-assign
```

## Testes

```bash
# Todos os testes
pytest

# Por domínio
pytest tests/unit/models/contracts/
pytest tests/integration/api/quality/

# Com cobertura
pytest --cov=app --cov-report=html
```

## Deployment

### Docker
```bash
# Build
docker build -t data-governance-api:v1 .

# Run
docker-compose up -d
```

### Kubernetes
```bash
# Deploy
kubectl apply -f deployment/kubernetes/

# Helm
helm install governance-api deployment/helm/
```

### Azure AKS
```bash
# Deploy completo
./deployment/azure/deploy-aks.ps1
```

## Documentação

- 📖 **[Guia do Usuário](docs/user_guide_v1.md)** - Como usar a API
- 🔧 **[Guia Técnico](docs/technical_guide_v1.md)** - Desenvolvimento
- 🖥️ **[Setup PyCharm](docs/setup_pycharm_windows_v1.md)** - Ambiente Windows
- 📋 **[Evidências de Testes](docs/test_evidence_report_v1.md)** - Validação
- 🚀 **[Deploy Guide](docs/deployment/)** - Produção

## Monitoramento

- **Prometheus**: Métricas de aplicação
- **Grafana**: Dashboards visuais
- **Alertas**: Notificações automáticas
- **Logs**: Estruturados e centralizados

## Contribuição

1. Fork o projeto
2. Crie uma branch (`git checkout -b feature/nova-funcionalidade`)
3. Commit suas mudanças (`git commit -am 'Adiciona nova funcionalidade'`)
4. Push para a branch (`git push origin feature/nova-funcionalidade`)
5. Abra um Pull Request

## Licença

Este projeto está licenciado sob a Licença MIT - veja o arquivo [LICENSE](LICENSE) para detalhes.

## Suporte

- **Email**: carlos.morais@f1rst.com.br
- **Documentação**: [/docs/](docs/)
- **Issues**: GitHub Issues
- **Wiki**: GitHub Wiki

## Changelog

### v1.0.0 (Julho 2025)
- ✅ Implementação completa da arquitetura por domínios
- ✅ 200+ endpoints RESTful organizados
- ✅ Sistema Entity/Tag/Tagged
- ✅ Monitoramento avançado de queries
- ✅ Privacidade e compliance automático
- ✅ External lineage Unity Catalog
- ✅ Documentação completa

---

**Desenvolvido por Carlos Morais - Julho 2025**  
**F1rst Technology Solutions**

