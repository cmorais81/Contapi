"""
Consent Management model.

Desenvolvido por Carlos Morais - Julho 2025
"""

from sqlalchemy import Boolean, Column, DateTime, Enum, ForeignKey, String, Text, UUID
from sqlalchemy.orm import relationship
import enum

from app.models.base import BaseModel
from app.models.mixins import TimestampMixin


class ConsentStatus(enum.Enum):
    """Status do consentimento."""
    PENDING = "pending"
    GRANTED = "granted"
    DENIED = "denied"
    WITHDRAWN = "withdrawn"
    EXPIRED = "expired"


class ConsentType(enum.Enum):
    """Tipos de consentimento."""
    EXPLICIT = "explicit"  # Consentimento explícito
    IMPLIED = "implied"    # Consentimento implícito
    OPT_IN = "opt_in"     # Opt-in
    OPT_OUT = "opt_out"   # Opt-out
    LEGITIMATE_INTEREST = "legitimate_interest"  # Interesse legítimo


class ConsentRecord(BaseModel, TimestampMixin):
    """
    Modelo para gerenciamento de consentimento.
    
    Gerencia registros de consentimento para processamento
    de dados pessoais, incluindo coleta, armazenamento,
    processamento e compartilhamento de dados.
    """
    
    __tablename__ = "consent_records"
    
    # Identificação
    consent_id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        server_default="gen_random_uuid()",
        comment="Identificador único do consentimento"
    )
    
    # Referências
    policy_id = Column(
        UUID(as_uuid=True),
        ForeignKey("privacy_policies.policy_id"),
        nullable=False,
        comment="Referência à política de privacidade"
    )
    
    # Dados do titular
    data_subject_id = Column(
        String(255),
        nullable=False,
        comment="Identificador do titular dos dados"
    )
    
    data_subject_email = Column(
        String(255),
        comment="Email do titular dos dados"
    )
    
    data_subject_name = Column(
        String(255),
        comment="Nome do titular dos dados"
    )
    
    # Detalhes do consentimento
    consent_type = Column(
        Enum(ConsentType),
        nullable=False,
        default=ConsentType.EXPLICIT,
        comment="Tipo de consentimento"
    )
    
    consent_purpose = Column(
        Text,
        nullable=False,
        comment="Finalidade do consentimento"
    )
    
    data_categories = Column(
        Text,
        comment="Categorias de dados (JSON array)"
    )
    
    processing_activities = Column(
        Text,
        comment="Atividades de processamento (JSON array)"
    )
    
    # Status e datas
    status = Column(
        Enum(ConsentStatus),
        default=ConsentStatus.PENDING,
        nullable=False,
        comment="Status do consentimento"
    )
    
    granted_date = Column(
        DateTime,
        comment="Data de concessão do consentimento"
    )
    
    withdrawn_date = Column(
        DateTime,
        comment="Data de retirada do consentimento"
    )
    
    expiration_date = Column(
        DateTime,
        comment="Data de expiração do consentimento"
    )
    
    # Metadados de coleta
    collection_method = Column(
        String(100),
        comment="Método de coleta (web_form, api, phone, etc.)"
    )
    
    collection_source = Column(
        String(255),
        comment="Fonte da coleta"
    )
    
    ip_address = Column(
        String(45),
        comment="Endereço IP da coleta"
    )
    
    user_agent = Column(
        Text,
        comment="User agent do navegador"
    )
    
    # Evidências
    consent_evidence = Column(
        Text,
        comment="Evidências do consentimento (JSON)"
    )
    
    consent_text = Column(
        Text,
        comment="Texto do consentimento apresentado"
    )
    
    # Controle de versão
    consent_version = Column(
        String(20),
        comment="Versão do consentimento"
    )
    
    # Terceiros
    third_parties = Column(
        Text,
        comment="Terceiros com quem os dados podem ser compartilhados (JSON)"
    )
    
    # Localização
    jurisdiction = Column(
        String(10),
        comment="Jurisdição aplicável (BR, EU, US, etc.)"
    )
    
    # Relacionamentos
    policy = relationship(
        "PrivacyPolicy",
        back_populates="consent_records"
    )
    
    def __repr__(self) -> str:
        return f"<ConsentRecord(id={self.consent_id}, subject={self.data_subject_id}, status={self.status.value})>"
    
    @property
    def is_valid(self) -> bool:
        """Verifica se o consentimento é válido."""
        return (
            self.status == ConsentStatus.GRANTED and
            not self.is_expired and
            not self.is_withdrawn
        )
    
    @property
    def is_expired(self) -> bool:
        """Verifica se o consentimento está expirado."""
        if not self.expiration_date:
            return False
        from datetime import datetime
        return datetime.utcnow() > self.expiration_date
    
    @property
    def is_withdrawn(self) -> bool:
        """Verifica se o consentimento foi retirado."""
        return self.status == ConsentStatus.WITHDRAWN
    
    def get_data_categories(self) -> list:
        """
        Retorna lista de categorias de dados.
        
        Returns:
            Lista de categorias de dados
        """
        import json
        if not self.data_categories:
            return []
        try:
            return json.loads(self.data_categories)
        except:
            return []
    
    def get_processing_activities(self) -> list:
        """
        Retorna lista de atividades de processamento.
        
        Returns:
            Lista de atividades de processamento
        """
        import json
        if not self.processing_activities:
            return []
        try:
            return json.loads(self.processing_activities)
        except:
            return []
    
    def get_third_parties(self) -> list:
        """
        Retorna lista de terceiros.
        
        Returns:
            Lista de terceiros
        """
        import json
        if not self.third_parties:
            return []
        try:
            return json.loads(self.third_parties)
        except:
            return []
    
    def get_consent_evidence(self) -> dict:
        """
        Retorna evidências do consentimento.
        
        Returns:
            Dicionário com evidências
        """
        import json
        if not self.consent_evidence:
            return {}
        try:
            return json.loads(self.consent_evidence)
        except:
            return {}
    
    def grant_consent(self, evidence: dict = None):
        """
        Concede o consentimento.
        
        Args:
            evidence: Evidências adicionais do consentimento
        """
        from datetime import datetime
        
        self.status = ConsentStatus.GRANTED
        self.granted_date = datetime.utcnow()
        
        if evidence:
            import json
            existing_evidence = self.get_consent_evidence()
            existing_evidence.update(evidence)
            self.consent_evidence = json.dumps(existing_evidence)
    
    def withdraw_consent(self, reason: str = None):
        """
        Retira o consentimento.
        
        Args:
            reason: Razão da retirada
        """
        from datetime import datetime
        
        self.status = ConsentStatus.WITHDRAWN
        self.withdrawn_date = datetime.utcnow()
        
        if reason:
            evidence = self.get_consent_evidence()
            evidence['withdrawal_reason'] = reason
            evidence['withdrawal_date'] = datetime.utcnow().isoformat()
            import json
            self.consent_evidence = json.dumps(evidence)
    
    def check_expiration(self):
        """Verifica e atualiza status se expirado."""
        if self.is_expired and self.status == ConsentStatus.GRANTED:
            self.status = ConsentStatus.EXPIRED

