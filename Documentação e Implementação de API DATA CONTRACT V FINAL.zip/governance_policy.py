"""
Governance Policy model.
"""

from sqlalchemy import Boolean, Column, String, Text

from app.models.base import BaseModel


class GovernancePolicy(BaseModel):
    """
    Governance Policy model.
    
    Data governance policies and rules.
    """

    __tablename__ = "governance_policies"

    # Policy definition
    policy_name = Column(
        String(255),
        nullable=False,
        unique=True,
        index=True,
        doc="Unique policy name"
    )

    policy_description = Column(
        Text,
        doc="Policy description"
    )

    # Policy categorization
    policy_type = Column(
        String(100),
        nullable=False,
        index=True,
        doc="Policy type: data_access, data_retention, data_quality, data_privacy"
    )

    policy_category = Column(
        String(100),
        index=True,
        doc="Policy category: security, compliance, operational, business"
    )

    # Policy content
    policy_rules = Column(
        Text,
        nullable=False,
        doc="Policy rules as JSON"
    )

    enforcement_level = Column(
        String(50),
        nullable=False,
        doc="Enforcement level: advisory, warning, blocking"
    )

    # Scope
    scope_definition = Column(
        Text,
        doc="Policy scope definition as JSON"
    )

    applicable_entities = Column(
        Text,
        doc="Applicable entities as JSON array"
    )

    # Status
    policy_status = Column(
        String(50),
        default="draft",
        index=True,
        doc="Status: draft, active, deprecated, archived"
    )

    is_mandatory = Column(
        Boolean,
        default=False,
        doc="Policy is mandatory"
    )

    # Compliance
    regulatory_framework = Column(
        String(255),
        doc="Regulatory framework: GDPR, CCPA, SOX, HIPAA"
    )

    compliance_requirements = Column(
        Text,
        doc="Compliance requirements as JSON"
    )

    # Approval
    approved_by = Column(
        String(255),
        doc="User who approved the policy"
    )

    approval_date = Column(
        String(20),  # Using String to handle date as text
        doc="Policy approval date"
    )

    effective_date = Column(
        String(20),  # Using String to handle date as text
        doc="Policy effective date"
    )

    expiration_date = Column(
        String(20),  # Using String to handle date as text
        doc="Policy expiration date"
    )

    def __repr__(self) -> str:
        return f"<GovernancePolicy(name={self.policy_name}, type={self.policy_type}, status={self.policy_status})>"

