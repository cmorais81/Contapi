"""
Data Contract Service for Data Governance API.

Contains business logic for data contract operations with exemplary business rules.

Author: Carlos Morais <carlos.morais@f1rst.com.br>
Date: July 2025
"""

from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any
from uuid import UUID
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, func

from app.models.contracts.data_contract import DataContract
from app.models.contracts.contract_version import ContractVersion
from app.schemas.contracts.data_contract import (
    DataContractCreate,
    DataContractUpdate,
    DataContractQueryParams
)
from app.core.exceptions import (
    BusinessRuleViolationError,
    ResourceNotFoundError,
    ValidationError
)


class DataContractService:
    """
    Data Contract Service with exemplary business rules.
    
    Demonstrates comprehensive business logic patterns for
    data contract lifecycle management.
    """
    
    def __init__(self, db: Session):
        self.db = db
    
    def create_data_contract(self, contract_data: DataContractCreate, created_by: str) -> DataContract:
        """
        Create a new data contract with business validation.
        
        Business Rules:
        1. Contract ID must be unique within domain
        2. Producer and consumer must be valid entities
        3. SLA requirements must be realistic
        4. Schema must be valid and versioned
        5. Critical contracts require approval workflow
        """
        
        # Business Rule 1: Check for duplicate contract ID in domain
        existing_contract = self.db.query(DataContract).filter(
            and_(
                DataContract.contract_id == contract_data.contract_id,
                DataContract.domain == contract_data.domain,
                DataContract.ativo == True
            )
        ).first()
        
        if existing_contract:
            raise BusinessRuleViolationError(
                f"Contract ID '{contract_data.contract_id}' already exists in domain '{contract_data.domain}'"
            )
        
        # Business Rule 2: Validate producer and consumer
        self._validate_contract_parties(contract_data)
        
        # Business Rule 3: Validate SLA requirements
        if contract_data.sla_requirements:
            self._validate_sla_requirements(contract_data.sla_requirements)
        
        # Business Rule 4: Validate schema
        if contract_data.schema_definition:
            self._validate_schema_definition(contract_data.schema_definition)
        
        # Business Rule 5: Critical contracts require approval
        if contract_data.criticality == "critical":
            self._validate_critical_contract(contract_data)
        
        # Create the contract
        contract = DataContract(
            contract_id=contract_data.contract_id,
            name=contract_data.name,
            description=contract_data.description,
            version=contract_data.version or "1.0.0",
            domain=contract_data.domain,
            data_product_name=contract_data.data_product_name,
            producer_system=contract_data.producer_system,
            consumer_systems=contract_data.consumer_systems,
            schema_definition=contract_data.schema_definition,
            sla_requirements=contract_data.sla_requirements,
            quality_requirements=contract_data.quality_requirements,
            security_classification=contract_data.security_classification,
            retention_policy=contract_data.retention_policy,
            update_frequency=contract_data.update_frequency,
            criticality=contract_data.criticality,
            business_purpose=contract_data.business_purpose,
            contact_info=contract_data.contact_info,
            tags=contract_data.tags,
            proprietario=contract_data.proprietario,
            responsavel_tecnico=contract_data.responsavel_tecnico,
            criado_por=created_by,
            status="draft",
            approval_status="pending" if contract_data.criticality == "critical" else "approved"
        )
        
        self.db.add(contract)
        self.db.commit()
        self.db.refresh(contract)
        
        # Create initial version
        self._create_contract_version(contract, created_by, "Initial version")
        
        return contract
    
    def update_data_contract(self, contract_id: UUID, contract_data: DataContractUpdate, updated_by: str) -> DataContract:
        """
        Update a data contract with business validation.
        
        Business Rules:
        1. Cannot modify active contracts without versioning
        2. Breaking changes require new major version
        3. Schema changes must be backward compatible
        4. SLA downgrades require consumer approval
        5. Status transitions must follow workflow
        """
        
        contract = self.get_data_contract(contract_id)
        
        # Business Rule 1: Active contracts require versioning for changes
        if contract.status == "active" and self._has_breaking_changes(contract, contract_data):
            raise BusinessRuleViolationError(
                "Breaking changes to active contracts require creating a new version"
            )
        
        # Business Rule 2: Validate schema compatibility
        if contract_data.schema_definition:
            compatibility = self._check_schema_compatibility(
                contract.schema_definition, 
                contract_data.schema_definition
            )
            if not compatibility["is_compatible"]:
                raise BusinessRuleViolationError(
                    f"Schema change is not backward compatible: {compatibility['reason']}"
                )
        
        # Business Rule 3: SLA downgrades require approval
        if contract_data.sla_requirements:
            if self._is_sla_downgrade(contract.sla_requirements, contract_data.sla_requirements):
                if not self._has_consumer_approval(contract, updated_by):
                    raise BusinessRuleViolationError(
                        "SLA downgrades require approval from all consumers"
                    )
        
        # Business Rule 4: Validate status transitions
        if contract_data.status and contract_data.status != contract.status:
            if not self._is_valid_status_transition(contract.status, contract_data.status):
                raise BusinessRuleViolationError(
                    f"Invalid status transition from '{contract.status}' to '{contract_data.status}'"
                )
        
        # Apply updates
        for field, value in contract_data.dict(exclude_unset=True).items():
            setattr(contract, field, value)
        
        contract.atualizado_por = updated_by
        contract.data_atualizacao = datetime.utcnow()
        
        # Create version if significant changes
        if self._requires_versioning(contract, contract_data):
            self._create_contract_version(contract, updated_by, "Updated contract")
        
        self.db.commit()
        self.db.refresh(contract)
        
        return contract
    
    def activate_contract(self, contract_id: UUID, activated_by: str) -> DataContract:
        """
        Activate a data contract with business validation.
        
        Business Rules:
        1. Contract must be approved
        2. All dependencies must be satisfied
        3. Producer system must be ready
        4. Quality rules must be in place
        """
        
        contract = self.get_data_contract(contract_id)
        
        # Business Rule 1: Must be approved
        if contract.approval_status != "approved":
            raise BusinessRuleViolationError(
                f"Contract must be approved before activation. Current status: {contract.approval_status}"
            )
        
        # Business Rule 2: Check dependencies
        dependencies = self._check_contract_dependencies(contract)
        if not dependencies["all_satisfied"]:
            raise BusinessRuleViolationError(
                f"Contract dependencies not satisfied: {dependencies['missing']}"
            )
        
        # Business Rule 3: Validate producer readiness
        producer_status = self._check_producer_readiness(contract)
        if not producer_status["ready"]:
            raise BusinessRuleViolationError(
                f"Producer system not ready: {producer_status['reason']}"
            )
        
        # Business Rule 4: Quality rules must be in place
        quality_check = self._validate_quality_rules(contract)
        if not quality_check["valid"]:
            raise BusinessRuleViolationError(
                f"Quality rules validation failed: {quality_check['reason']}"
            )
        
        # Activate contract
        contract.status = "active"
        contract.activated_at = datetime.utcnow()
        contract.activated_by = activated_by
        contract.atualizado_por = activated_by
        contract.data_atualizacao = datetime.utcnow()
        
        self.db.commit()
        self.db.refresh(contract)
        
        return contract
    
    def get_data_contract(self, contract_id: UUID) -> DataContract:
        """Get data contract by ID with business validation."""
        
        contract = self.db.query(DataContract).filter(
            and_(DataContract.id == contract_id, DataContract.ativo == True)
        ).first()
        
        if not contract:
            raise ResourceNotFoundError(f"Data contract with ID {contract_id} not found")
        
        return contract
    
    def list_data_contracts(self, params: DataContractQueryParams) -> List[DataContract]:
        """List data contracts with business filtering."""
        
        query = self.db.query(DataContract).filter(DataContract.ativo == True)
        
        # Apply business filters
        if params.domain:
            query = query.filter(DataContract.domain == params.domain)
        
        if params.status:
            query = query.filter(DataContract.status == params.status)
        
        if params.criticality:
            query = query.filter(DataContract.criticality == params.criticality)
        
        if params.producer_system:
            query = query.filter(DataContract.producer_system == params.producer_system)
        
        # Business logic: Prioritize critical contracts
        query = query.order_by(
            func.case(
                (DataContract.criticality == "critical", 1),
                (DataContract.criticality == "high", 2),
                (DataContract.criticality == "medium", 3),
                else_=4
            ),
            DataContract.name
        )
        
        if params.skip:
            query = query.offset(params.skip)
        
        if params.limit:
            query = query.limit(params.limit)
        
        return query.all()
    
    def get_contract_compliance_score(self, contract_id: UUID) -> Dict[str, Any]:
        """
        Calculate contract compliance score based on business metrics.
        
        Business Logic:
        - SLA adherence: 30%
        - Quality metrics: 25%
        - Schema compliance: 20%
        - Documentation completeness: 15%
        - Security compliance: 10%
        """
        
        contract = self.get_data_contract(contract_id)
        
        # Calculate individual scores
        sla_score = self._calculate_sla_adherence(contract)
        quality_score = self._calculate_quality_metrics(contract)
        schema_score = self._calculate_schema_compliance(contract)
        documentation_score = self._calculate_documentation_completeness(contract)
        security_score = self._calculate_security_compliance(contract)
        
        # Calculate weighted compliance score
        compliance_score = (
            sla_score * 0.30 +
            quality_score * 0.25 +
            schema_score * 0.20 +
            documentation_score * 0.15 +
            security_score * 0.10
        )
        
        # Determine compliance level
        if compliance_score >= 0.95:
            level = "excellent"
        elif compliance_score >= 0.85:
            level = "good"
        elif compliance_score >= 0.70:
            level = "acceptable"
        else:
            level = "needs_improvement"
        
        # Generate recommendations
        recommendations = self._generate_compliance_recommendations(
            contract, sla_score, quality_score, schema_score, 
            documentation_score, security_score
        )
        
        return {
            "compliance_score": round(compliance_score, 3),
            "compliance_level": level,
            "scores": {
                "sla_adherence": round(sla_score, 3),
                "quality_metrics": round(quality_score, 3),
                "schema_compliance": round(schema_score, 3),
                "documentation_completeness": round(documentation_score, 3),
                "security_compliance": round(security_score, 3)
            },
            "recommendations": recommendations
        }
    
    # Private helper methods for business logic
    
    def _validate_contract_parties(self, contract_data: DataContractCreate):
        """Validate producer and consumer systems."""
        
        if not contract_data.producer_system:
            raise ValidationError("Producer system is required")
        
        if not contract_data.consumer_systems:
            raise ValidationError("At least one consumer system is required")
        
        # Validate system existence (would integrate with system registry)
        # For demo purposes, assume validation passes
    
    def _validate_sla_requirements(self, sla_requirements: Dict[str, Any]):
        """Validate SLA requirements are realistic."""
        
        if "availability" in sla_requirements:
            availability = sla_requirements["availability"]
            if not isinstance(availability, (int, float)) or not (0 <= availability <= 100):
                raise ValidationError("Availability must be between 0 and 100")
        
        if "response_time_ms" in sla_requirements:
            response_time = sla_requirements["response_time_ms"]
            if not isinstance(response_time, (int, float)) or response_time <= 0:
                raise ValidationError("Response time must be positive")
        
        if "throughput_rps" in sla_requirements:
            throughput = sla_requirements["throughput_rps"]
            if not isinstance(throughput, (int, float)) or throughput <= 0:
                raise ValidationError("Throughput must be positive")
    
    def _validate_schema_definition(self, schema_definition: Dict[str, Any]):
        """Validate schema definition structure."""
        
        if not isinstance(schema_definition, dict):
            raise ValidationError("Schema definition must be a valid JSON object")
        
        if "fields" not in schema_definition:
            raise ValidationError("Schema definition must contain 'fields'")
        
        fields = schema_definition["fields"]
        if not isinstance(fields, list) or len(fields) == 0:
            raise ValidationError("Schema must have at least one field")
        
        # Validate each field
        for field in fields:
            if not isinstance(field, dict):
                raise ValidationError("Each field must be an object")
            
            if "name" not in field or "type" not in field:
                raise ValidationError("Each field must have 'name' and 'type'")
    
    def _validate_critical_contract(self, contract_data: DataContractCreate):
        """Validate critical contract requirements."""
        
        if not contract_data.proprietario:
            raise ValidationError("Critical contracts must have a business owner")
        
        if not contract_data.responsavel_tecnico:
            raise ValidationError("Critical contracts must have a technical owner")
        
        if not contract_data.business_purpose:
            raise ValidationError("Critical contracts must have documented business purpose")
        
        if not contract_data.quality_requirements:
            raise ValidationError("Critical contracts must have quality requirements")
    
    def _has_breaking_changes(self, contract: DataContract, update_data: DataContractUpdate) -> bool:
        """Determine if update contains breaking changes."""
        
        breaking_fields = ["schema_definition", "sla_requirements", "security_classification"]
        
        for field in breaking_fields:
            if hasattr(update_data, field) and getattr(update_data, field) is not None:
                return True
        
        return False
    
    def _check_schema_compatibility(self, old_schema: Dict, new_schema: Dict) -> Dict[str, Any]:
        """Check if schema change is backward compatible."""
        
        if not old_schema or not new_schema:
            return {"is_compatible": True, "reason": "No schema to compare"}
        
        old_fields = {f["name"]: f for f in old_schema.get("fields", [])}
        new_fields = {f["name"]: f for f in new_schema.get("fields", [])}
        
        # Check for removed fields
        removed_fields = set(old_fields.keys()) - set(new_fields.keys())
        if removed_fields:
            return {
                "is_compatible": False,
                "reason": f"Fields removed: {list(removed_fields)}"
            }
        
        # Check for type changes
        for field_name in old_fields:
            if field_name in new_fields:
                old_type = old_fields[field_name].get("type")
                new_type = new_fields[field_name].get("type")
                if old_type != new_type:
                    return {
                        "is_compatible": False,
                        "reason": f"Type changed for field '{field_name}': {old_type} -> {new_type}"
                    }
        
        return {"is_compatible": True, "reason": "Schema is backward compatible"}
    
    def _is_sla_downgrade(self, old_sla: Dict, new_sla: Dict) -> bool:
        """Check if SLA change is a downgrade."""
        
        if not old_sla or not new_sla:
            return False
        
        # Check availability downgrade
        old_availability = old_sla.get("availability", 0)
        new_availability = new_sla.get("availability", 0)
        if new_availability < old_availability:
            return True
        
        # Check response time increase
        old_response_time = old_sla.get("response_time_ms", float('inf'))
        new_response_time = new_sla.get("response_time_ms", float('inf'))
        if new_response_time > old_response_time:
            return True
        
        # Check throughput decrease
        old_throughput = old_sla.get("throughput_rps", 0)
        new_throughput = new_sla.get("throughput_rps", 0)
        if new_throughput < old_throughput:
            return True
        
        return False
    
    def _has_consumer_approval(self, contract: DataContract, user: str) -> bool:
        """Check if user has consumer approval authority."""
        # This would integrate with approval workflow system
        # For demo purposes, assume certain users have approval
        approved_users = ["admin", "product_owner", "consumer_lead"]
        return user in approved_users
    
    def _is_valid_status_transition(self, current_status: str, new_status: str) -> bool:
        """Validate status transition according to workflow."""
        
        valid_transitions = {
            "draft": ["review", "cancelled"],
            "review": ["approved", "rejected", "draft"],
            "approved": ["active", "cancelled"],
            "active": ["deprecated", "suspended"],
            "deprecated": ["retired"],
            "suspended": ["active", "deprecated"],
            "rejected": ["draft"],
            "cancelled": [],
            "retired": []
        }
        
        return new_status in valid_transitions.get(current_status, [])
    
    def _requires_versioning(self, contract: DataContract, update_data: DataContractUpdate) -> bool:
        """Determine if changes require creating a new version."""
        
        versioning_fields = ["schema_definition", "sla_requirements", "quality_requirements"]
        
        for field in versioning_fields:
            if hasattr(update_data, field) and getattr(update_data, field) is not None:
                return True
        
        return False
    
    def _create_contract_version(self, contract: DataContract, created_by: str, notes: str):
        """Create a new contract version."""
        
        version = ContractVersion(
            contract_id=contract.id,
            version_number=contract.version,
            schema_definition=contract.schema_definition,
            sla_requirements=contract.sla_requirements,
            quality_requirements=contract.quality_requirements,
            change_notes=notes,
            criado_por=created_by
        )
        
        self.db.add(version)
    
    def _check_contract_dependencies(self, contract: DataContract) -> Dict[str, Any]:
        """Check if all contract dependencies are satisfied."""
        
        # This would check dependencies like:
        # - Required data sources are available
        # - Dependent contracts are active
        # - Infrastructure is provisioned
        
        # For demo purposes, assume dependencies are satisfied
        return {"all_satisfied": True, "missing": []}
    
    def _check_producer_readiness(self, contract: DataContract) -> Dict[str, Any]:
        """Check if producer system is ready."""
        
        # This would check:
        # - System health
        # - Data availability
        # - API endpoints
        # - Monitoring setup
        
        # For demo purposes, assume producer is ready
        return {"ready": True, "reason": "Producer system is operational"}
    
    def _validate_quality_rules(self, contract: DataContract) -> Dict[str, Any]:
        """Validate that quality rules are in place."""
        
        if not contract.quality_requirements:
            return {"valid": False, "reason": "No quality requirements defined"}
        
        # This would check:
        # - Quality rules are configured
        # - Monitoring is set up
        # - Thresholds are defined
        
        # For demo purposes, assume quality rules are valid
        return {"valid": True, "reason": "Quality rules are properly configured"}
    
    def _calculate_sla_adherence(self, contract: DataContract) -> float:
        """Calculate SLA adherence score."""
        # This would integrate with monitoring systems
        # For demo purposes, return a reasonable score
        return 0.95
    
    def _calculate_quality_metrics(self, contract: DataContract) -> float:
        """Calculate quality metrics score."""
        # This would integrate with quality monitoring
        # For demo purposes, return a reasonable score
        return 0.88
    
    def _calculate_schema_compliance(self, contract: DataContract) -> float:
        """Calculate schema compliance score."""
        # This would check schema validation results
        # For demo purposes, return a reasonable score
        return 0.92
    
    def _calculate_documentation_completeness(self, contract: DataContract) -> float:
        """Calculate documentation completeness score."""
        
        score = 0.0
        total_fields = 10  # Total number of documentation fields
        
        # Check required documentation fields
        if contract.description:
            score += 1
        if contract.business_purpose:
            score += 1
        if contract.contact_info:
            score += 1
        if contract.schema_definition:
            score += 1
        if contract.sla_requirements:
            score += 1
        if contract.quality_requirements:
            score += 1
        if contract.security_classification:
            score += 1
        if contract.retention_policy:
            score += 1
        if contract.update_frequency:
            score += 1
        if contract.tags:
            score += 1
        
        return score / total_fields
    
    def _calculate_security_compliance(self, contract: DataContract) -> float:
        """Calculate security compliance score."""
        
        if not contract.security_classification:
            return 0.5
        
        # This would integrate with security scanning
        # For demo purposes, return a reasonable score
        return 0.85
    
    def _generate_compliance_recommendations(self, contract: DataContract, sla_score: float,
                                           quality_score: float, schema_score: float,
                                           documentation_score: float, security_score: float) -> List[str]:
        """Generate compliance improvement recommendations."""
        
        recommendations = []
        
        if sla_score < 0.9:
            recommendations.append("Review SLA adherence - consider adjusting requirements or improving system performance")
        
        if quality_score < 0.8:
            recommendations.append("Improve data quality monitoring and implement additional quality rules")
        
        if schema_score < 0.9:
            recommendations.append("Address schema validation issues and ensure compliance with contract definition")
        
        if documentation_score < 0.8:
            recommendations.append("Complete missing documentation fields to improve contract clarity")
        
        if security_score < 0.8:
            recommendations.append("Review security classification and implement additional security controls")
        
        if contract.criticality == "critical" and any(score < 0.95 for score in [sla_score, quality_score, schema_score]):
            recommendations.append("Critical contract requires immediate attention to meet compliance standards")
        
        if not recommendations:
            recommendations.append("Contract is meeting all compliance requirements - continue monitoring")
        
        return recommendations

