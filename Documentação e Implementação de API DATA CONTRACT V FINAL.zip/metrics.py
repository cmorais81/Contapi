"""
Metrics endpoints.
"""

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db

router = APIRouter()


@router.get("/cluster", summary="Get cluster metrics")
async def get_cluster_metrics(db: AsyncSession = Depends(get_db)):
    """Get Databricks cluster metrics."""
    return {"message": "Cluster metrics not yet implemented"}


@router.get("/jobs", summary="Get job metrics")
async def get_job_metrics(db: AsyncSession = Depends(get_db)):
    """Get Databricks job metrics."""
    return {"message": "Job metrics not yet implemented"}


@router.get("/queries", summary="Get query metrics")
async def get_query_metrics(db: AsyncSession = Depends(get_db)):
    """Get SQL query metrics."""
    return {"message": "Query metrics not yet implemented"}


@router.get("/storage", summary="Get storage metrics")
async def get_storage_metrics(db: AsyncSession = Depends(get_db)):
    """Get data storage metrics."""
    return {"message": "Storage metrics not yet implemented"}


@router.get("/anomalies", summary="Get anomaly detections")
async def get_anomaly_detections(db: AsyncSession = Depends(get_db)):
    """Get data anomaly detections."""
    return {"message": "Anomaly detections not yet implemented"}

