"""
Audit Log model.
"""

from sqlalchemy import Column, String, Text
from sqlalchemy.dialects.postgresql import UUID as PostgresUUID

from app.models.base import BaseModel


class AuditLog(BaseModel):
    """
    Audit Log model.
    
    Comprehensive audit logging for all system activities.
    """

    __tablename__ = "audit_logs"

    # Event identification
    event_type = Column(
        String(100),
        nullable=False,
        index=True,
        doc="Event type: create, update, delete, access, login, logout"
    )

    event_category = Column(
        String(100),
        index=True,
        doc="Event category: authentication, authorization, data_access, configuration"
    )

    event_description = Column(
        Text,
        doc="Human-readable event description"
    )

    # Actor information
    user_id = Column(
        PostgresUUID(as_uuid=True),
        index=True,
        doc="User who performed the action"
    )

    username = Column(
        String(255),
        index=True,
        doc="Username for reference"
    )

    user_ip_address = Column(
        String(45),
        doc="User IP address (IPv4/IPv6)"
    )

    user_agent = Column(
        Text,
        doc="User agent string"
    )

    # Target information
    target_type = Column(
        String(100),
        index=True,
        doc="Target type: contract, user, role, quality_rule, etc."
    )

    target_id = Column(
        PostgresUUID(as_uuid=True),
        index=True,
        doc="Target entity ID"
    )

    target_name = Column(
        String(255),
        doc="Target entity name for reference"
    )

    # Change details
    old_values = Column(
        Text,
        doc="Previous values as JSON"
    )

    new_values = Column(
        Text,
        doc="New values as JSON"
    )

    changed_fields = Column(
        Text,
        doc="List of changed fields as JSON array"
    )

    # Request details
    request_id = Column(
        String(255),
        index=True,
        doc="Request ID for correlation"
    )

    session_id = Column(
        String(255),
        index=True,
        doc="Session ID"
    )

    api_endpoint = Column(
        String(500),
        doc="API endpoint accessed"
    )

    http_method = Column(
        String(10),
        doc="HTTP method: GET, POST, PUT, DELETE"
    )

    # Result information
    operation_result = Column(
        String(50),
        nullable=False,
        index=True,
        doc="Result: success, failure, partial"
    )

    error_code = Column(
        String(50),
        doc="Error code if operation failed"
    )

    error_message = Column(
        Text,
        doc="Error message if operation failed"
    )

    # Performance
    response_time_ms = Column(
        String(20),  # Using String to handle integer as text
        doc="Response time in milliseconds"
    )

    # Compliance
    compliance_tags = Column(
        Text,
        doc="Compliance tags as JSON array"
    )

    retention_period_days = Column(
        String(10),  # Using String to handle integer as text
        default="2555",  # 7 years
        doc="Retention period in days"
    )

    def __repr__(self) -> str:
        return f"<AuditLog(event_type={self.event_type}, user={self.username}, result={self.operation_result})>"

