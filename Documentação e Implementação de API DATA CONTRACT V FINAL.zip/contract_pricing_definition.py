"""
Contract Pricing Definition model.
"""

from sqlalchemy import Column, ForeignKey, String, Text
from sqlalchemy.dialects.postgresql import UUID as PostgresUUID
from sqlalchemy.orm import relationship

from app.models.base import BaseModel


class ContractPricingDefinition(BaseModel):
    """
    Contract Pricing Definition model.
    
    Pricing and cost definitions.
    """

    __tablename__ = "contract_pricing_definitions"

    # Foreign key to contract
    contract_id = Column(
        PostgresUUID(as_uuid=True),
        ForeignKey("data_contracts.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
        doc="Reference to contract"
    )

    # Pricing definition
    pricing_model = Column(
        String(100),
        doc="Pricing model: fixed, usage-based, tiered, freemium"
    )

    base_cost = Column(
        String(20),  # Using String to handle numeric as text
        doc="Base cost"
    )

    cost_per_unit = Column(
        String(20),  # Using String to handle numeric as text
        doc="Cost per unit"
    )

    unit_type = Column(
        String(50),
        doc="Unit type: GB, TB, requests, users"
    )

    billing_frequency = Column(
        String(50),
        doc="Billing frequency: monthly, quarterly, annually"
    )

    cost_breakdown = Column(
        Text,
        doc="Detailed cost breakdown"
    )

    # Relationships
    contract = relationship(
        "DataContract",
        back_populates="pricing_definitions"
    )

    def __repr__(self) -> str:
        return f"<ContractPricingDefinition(model={self.pricing_model})>"

