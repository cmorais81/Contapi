"""
Tests for main application endpoints.
"""

import pytest
from fastapi.testclient import TestClient


class TestMainEndpoints:
    """Test main application endpoints."""
    
    def test_root_endpoint(self, client: TestClient):
        """Test root endpoint returns API information."""
        response = client.get("/")
        
        assert response.status_code == 200
        data = response.json()
        
        assert "name" in data
        assert "version" in data
        assert "description" in data
        assert "docs_url" in data
        assert "api_url" in data
    
    def test_health_check(self, client: TestClient):
        """Test health check endpoint."""
        response = client.get("/health")
        
        assert response.status_code == 200
        data = response.json()
        
        assert data["status"] == "healthy"
        assert "version" in data
        assert "timestamp" in data
        assert "services" in data
        assert isinstance(data["services"], dict)
    
    def test_health_check_services(self, client: TestClient):
        """Test health check includes service status."""
        response = client.get("/health")
        data = response.json()
        
        services = data["services"]
        assert "database" in services
        assert services["database"] == "healthy"
    
    def test_metrics_endpoint_disabled(self, client: TestClient):
        """Test metrics endpoint when disabled."""
        response = client.get("/metrics")
        
        # Should return 404 when metrics are disabled in test environment
        assert response.status_code == 404
    
    def test_cors_headers(self, client: TestClient):
        """Test CORS headers are present."""
        response = client.options("/health")
        
        # FastAPI automatically handles OPTIONS requests
        assert response.status_code in [200, 405]  # 405 if OPTIONS not explicitly defined
    
    def test_request_id_header(self, client: TestClient):
        """Test that request ID is added to response headers."""
        response = client.get("/health")
        
        assert "X-Request-ID" in response.headers
        assert response.headers["X-Request-ID"].startswith("req_")


class TestAPIDocumentation:
    """Test API documentation endpoints."""
    
    def test_openapi_schema(self, client: TestClient):
        """Test OpenAPI schema is accessible."""
        response = client.get("/api/v1/openapi.json")
        
        assert response.status_code == 200
        schema = response.json()
        
        assert "openapi" in schema
        assert "info" in schema
        assert "paths" in schema
        assert schema["info"]["title"] == "Data Governance API"
    
    def test_swagger_docs(self, client: TestClient):
        """Test Swagger documentation is accessible."""
        response = client.get("/docs")
        
        assert response.status_code == 200
        assert "text/html" in response.headers["content-type"]
    
    def test_redoc_docs(self, client: TestClient):
        """Test ReDoc documentation is accessible."""
        response = client.get("/redoc")
        
        assert response.status_code == 200
        assert "text/html" in response.headers["content-type"]
    
    def test_openapi_tags(self, client: TestClient):
        """Test OpenAPI schema includes all expected tags."""
        response = client.get("/api/v1/openapi.json")
        schema = response.json()
        
        expected_tags = [
            "health", "contracts", "quality", "lineage", "metrics",
            "users", "tags", "governance", "integrations", "audit", "admin"
        ]
        
        schema_tags = [tag["name"] for tag in schema.get("tags", [])]
        
        for tag in expected_tags:
            assert tag in schema_tags, f"Missing tag: {tag}"


class TestErrorHandling:
    """Test error handling and middleware."""
    
    def test_404_error(self, client: TestClient):
        """Test 404 error handling."""
        response = client.get("/nonexistent-endpoint")
        
        assert response.status_code == 404
        data = response.json()
        
        assert "detail" in data
    
    def test_method_not_allowed(self, client: TestClient):
        """Test 405 method not allowed error."""
        response = client.post("/health")
        
        assert response.status_code == 405
        data = response.json()
        
        assert "detail" in data
    
    def test_request_validation_error(self, client: TestClient):
        """Test request validation error handling."""
        # Try to create a contract with invalid data
        response = client.post("/api/v1/contracts/", json={"invalid": "data"})
        
        # Should return validation error
        assert response.status_code in [400, 422]  # 422 for validation errors
    
    def test_internal_server_error_handling(self, client: TestClient):
        """Test internal server error handling."""
        # This would require mocking an internal error
        # For now, just verify the error response structure exists
        pass


class TestMiddleware:
    """Test middleware functionality."""
    
    def test_logging_middleware(self, client: TestClient):
        """Test that logging middleware adds request ID."""
        response = client.get("/health")
        
        assert "X-Request-ID" in response.headers
        request_id = response.headers["X-Request-ID"]
        assert request_id.startswith("req_")
        assert len(request_id) > 4  # Should have timestamp
    
    def test_cors_middleware(self, client: TestClient):
        """Test CORS middleware configuration."""
        # Test preflight request
        response = client.options(
            "/api/v1/contracts/",
            headers={
                "Origin": "http://localhost:3000",
                "Access-Control-Request-Method": "GET",
                "Access-Control-Request-Headers": "Content-Type"
            }
        )
        
        # Should handle CORS properly
        assert response.status_code in [200, 405]
    
    def test_request_timing(self, client: TestClient):
        """Test that request timing is tracked."""
        response = client.get("/health")
        
        # Request should complete successfully
        assert response.status_code == 200
        
        # Timing would be logged but not exposed in headers
        # This test verifies the middleware doesn't break requests

