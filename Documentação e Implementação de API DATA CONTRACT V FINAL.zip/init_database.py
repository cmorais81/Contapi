#!/usr/bin/env python3
"""
Database Initialization Script for Data Governance API.

Initializes database schema, creates initial data, and populates with mock data.

Author: Carlos Morais <carlos.morais@f1rst.com.br>
Date: July 2025
"""

import asyncio
import sys
import logging
import argparse
from pathlib import Path
from typing import Dict, Any, List
import asyncpg
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker

# Add project root to path
sys.path.append(str(Path(__file__).parent.parent.parent))

from app.core.config import settings
from app.core.database import get_database_url, Base
from app.models import *  # Import all models
from scripts.mock_data.contracts_mock import generate_data_contracts, generate_contract_versions
from scripts.mock_data.quality_mock import generate_quality_rules, generate_quality_executions, generate_quality_results
from scripts.mock_data.users_mock import generate_roles, generate_users, generate_user_roles


class DatabaseInitializer:
    """Database initialization and population manager."""
    
    def __init__(self, database_url: str = None):
        self.database_url = database_url or get_database_url()
        self.engine = create_engine(self.database_url)
        self.SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=self.engine)
        self.logger = self._setup_logging()
    
    def _setup_logging(self) -> logging.Logger:
        """Setup logging configuration."""
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        return logging.getLogger(__name__)
    
    async def initialize_database(self, drop_existing: bool = False, populate_mock: bool = True) -> Dict[str, Any]:
        """Initialize database with schema and data."""
        
        self.logger.info("🚀 Starting database initialization...")
        
        results = {
            "status": "success",
            "steps": {},
            "errors": []
        }
        
        try:
            # Step 1: Check database connectivity
            self.logger.info("1️⃣ Checking database connectivity...")
            connectivity_result = await self._check_connectivity()
            results["steps"]["connectivity"] = connectivity_result
            
            if not connectivity_result["success"]:
                results["status"] = "failed"
                return results
            
            # Step 2: Drop existing tables if requested
            if drop_existing:
                self.logger.info("2️⃣ Dropping existing tables...")
                drop_result = self._drop_tables()
                results["steps"]["drop_tables"] = drop_result
            
            # Step 3: Create database schema
            self.logger.info("3️⃣ Creating database schema...")
            schema_result = self._create_schema()
            results["steps"]["create_schema"] = schema_result
            
            # Step 4: Create initial system data
            self.logger.info("4️⃣ Creating initial system data...")
            initial_data_result = await self._create_initial_data()
            results["steps"]["initial_data"] = initial_data_result
            
            # Step 5: Populate with mock data if requested
            if populate_mock:
                self.logger.info("5️⃣ Populating with mock data...")
                mock_data_result = await self._populate_mock_data()
                results["steps"]["mock_data"] = mock_data_result
            
            # Step 6: Verify database state
            self.logger.info("6️⃣ Verifying database state...")
            verification_result = await self._verify_database()
            results["steps"]["verification"] = verification_result
            
            self.logger.info("✅ Database initialization completed successfully!")
            
        except Exception as e:
            self.logger.error(f"❌ Database initialization failed: {str(e)}")
            results["status"] = "failed"
            results["errors"].append(str(e))
        
        return results
    
    async def _check_connectivity(self) -> Dict[str, Any]:
        """Check database connectivity."""
        try:
            conn = await asyncpg.connect(self.database_url)
            
            # Test basic query
            version = await conn.fetchval("SELECT version()")
            
            # Check if database exists
            db_name = await conn.fetchval("SELECT current_database()")
            
            await conn.close()
            
            return {
                "success": True,
                "database_name": db_name,
                "postgresql_version": version,
                "message": "Database connectivity verified"
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "message": "Failed to connect to database"
            }
    
    def _drop_tables(self) -> Dict[str, Any]:
        """Drop existing tables."""
        try:
            # Drop all tables in reverse order of dependencies
            with self.engine.begin() as conn:
                # Get all table names
                result = conn.execute(text("""
                    SELECT tablename FROM pg_tables 
                    WHERE schemaname = 'public' 
                    AND tablename NOT LIKE 'pg_%'
                    AND tablename != 'information_schema'
                """))
                
                tables = [row[0] for row in result]
                
                # Drop tables with CASCADE to handle dependencies
                for table in tables:
                    conn.execute(text(f"DROP TABLE IF EXISTS {table} CASCADE"))
                
                # Drop alembic version table if exists
                conn.execute(text("DROP TABLE IF EXISTS alembic_version CASCADE"))
            
            return {
                "success": True,
                "tables_dropped": len(tables),
                "message": f"Dropped {len(tables)} tables"
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "message": "Failed to drop tables"
            }
    
    def _create_schema(self) -> Dict[str, Any]:
        """Create database schema."""
        try:
            # Create all tables
            Base.metadata.create_all(bind=self.engine)
            
            # Get created table names
            with self.engine.begin() as conn:
                result = conn.execute(text("""
                    SELECT tablename FROM pg_tables 
                    WHERE schemaname = 'public' 
                    AND tablename NOT LIKE 'pg_%'
                """))
                
                tables = [row[0] for row in result]
            
            return {
                "success": True,
                "tables_created": len(tables),
                "table_names": sorted(tables),
                "message": f"Created {len(tables)} tables"
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "message": "Failed to create schema"
            }
    
    async def _create_initial_data(self) -> Dict[str, Any]:
        """Create initial system data."""
        try:
            db = self.SessionLocal()
            
            created_items = {
                "roles": 0,
                "users": 0,
                "system_configs": 0
            }
            
            # Create system roles if they don't exist
            from app.models.users.role import Role
            
            system_roles = [
                {
                    "role_id": "ROLE-001",
                    "name": "admin",
                    "display_name": "System Administrator",
                    "description": "Full system access and administration privileges",
                    "role_type": "system",
                    "level": 1,
                    "permissions": ["*"],
                    "is_system_role": True,
                    "is_active": True,
                    "max_users": 3,
                    "approval_required": False,
                    "role_metadata": {"created_by_system": True},
                    "criado_por": "system",
                    "atualizado_por": "system"
                },
                {
                    "role_id": "ROLE-002",
                    "name": "data_governance_lead",
                    "display_name": "Data Governance Lead",
                    "description": "Lead data governance initiatives and policies",
                    "role_type": "system",
                    "level": 2,
                    "permissions": ["governance.*", "contracts.*", "quality.*", "audit.read"],
                    "is_system_role": True,
                    "is_active": True,
                    "max_users": 5,
                    "approval_required": True,
                    "role_metadata": {"created_by_system": True},
                    "criado_por": "system",
                    "atualizado_por": "system"
                }
            ]
            
            for role_data in system_roles:
                existing_role = db.query(Role).filter(Role.name == role_data["name"]).first()
                if not existing_role:
                    role = Role(**role_data)
                    db.add(role)
                    created_items["roles"] += 1
            
            # Create system admin user if it doesn't exist
            from app.models.users.user import User
            
            admin_user_data = {
                "user_id": "USR-0001",
                "username": "admin",
                "email": "admin@datagovernance.local",
                "first_name": "System",
                "last_name": "Administrator",
                "display_name": "System Administrator",
                "department": "IT",
                "job_title": "System Administrator",
                "is_active": True,
                "is_verified": True,
                "is_external": False,
                "password_hash": "hashed_password_here",  # Should be properly hashed
                "two_factor_enabled": True,
                "session_timeout_minutes": 60,
                "preferences": {
                    "theme": "light",
                    "notifications": {"email": True, "browser": True},
                    "dashboard": {"default_view": "overview"}
                },
                "user_metadata": {
                    "employee_id": "EMP-00001",
                    "security_clearance": "restricted"
                },
                "criado_por": "system",
                "atualizado_por": "system"
            }
            
            existing_admin = db.query(User).filter(User.username == "admin").first()
            if not existing_admin:
                admin_user = User(**admin_user_data)
                db.add(admin_user)
                created_items["users"] += 1
            
            # Create system configuration entries
            from app.models.audit.system_configuration import SystemConfiguration
            
            system_configs = [
                {
                    "config_key": "api_version",
                    "config_value": "1.0.0",
                    "description": "Current API version",
                    "config_type": "system",
                    "is_encrypted": False,
                    "is_active": True,
                    "criado_por": "system"
                },
                {
                    "config_key": "max_login_attempts",
                    "config_value": "5",
                    "description": "Maximum failed login attempts before account lock",
                    "config_type": "security",
                    "is_encrypted": False,
                    "is_active": True,
                    "criado_por": "system"
                },
                {
                    "config_key": "session_timeout_minutes",
                    "config_value": "60",
                    "description": "Default session timeout in minutes",
                    "config_type": "security",
                    "is_encrypted": False,
                    "is_active": True,
                    "criado_por": "system"
                }
            ]
            
            for config_data in system_configs:
                existing_config = db.query(SystemConfiguration).filter(
                    SystemConfiguration.config_key == config_data["config_key"]
                ).first()
                if not existing_config:
                    config = SystemConfiguration(**config_data)
                    db.add(config)
                    created_items["system_configs"] += 1
            
            db.commit()
            db.close()
            
            return {
                "success": True,
                "created_items": created_items,
                "message": "Initial system data created successfully"
            }
            
        except Exception as e:
            if 'db' in locals():
                db.rollback()
                db.close()
            return {
                "success": False,
                "error": str(e),
                "message": "Failed to create initial data"
            }
    
    async def _populate_mock_data(self) -> Dict[str, Any]:
        """Populate database with mock data."""
        try:
            db = self.SessionLocal()
            
            populated_items = {
                "roles": 0,
                "users": 0,
                "user_roles": 0,
                "data_contracts": 0,
                "contract_versions": 0,
                "quality_rules": 0,
                "quality_executions": 0,
                "quality_results": 0
            }
            
            # Import models
            from app.models.users.role import Role
            from app.models.users.user import User
            from app.models.users.user_role import UserRole
            from app.models.contracts.data_contract import DataContract
            from app.models.contracts.contract_version import ContractVersion
            from app.models.quality.quality_rule import QualityRule
            from app.models.quality.quality_execution import QualityExecution
            from app.models.quality.quality_result import QualityResult
            
            # Generate and insert roles
            self.logger.info("Generating roles...")
            roles_data = generate_roles(10)
            for role_data in roles_data:
                # Skip if role already exists
                existing_role = db.query(Role).filter(Role.name == role_data["name"]).first()
                if not existing_role:
                    role_data.pop("id")  # Remove UUID, let SQLAlchemy generate
                    role = Role(**role_data)
                    db.add(role)
                    populated_items["roles"] += 1
            
            db.commit()
            
            # Generate and insert users
            self.logger.info("Generating users...")
            users_data = generate_users(25)
            for user_data in users_data:
                # Skip if user already exists
                existing_user = db.query(User).filter(User.username == user_data["username"]).first()
                if not existing_user:
                    user_data.pop("id")  # Remove UUID, let SQLAlchemy generate
                    user = User(**user_data)
                    db.add(user)
                    populated_items["users"] += 1
            
            db.commit()
            
            # Generate and insert user roles
            self.logger.info("Generating user role assignments...")
            # Get actual users and roles from database
            db_users = db.query(User).all()
            db_roles = db.query(Role).all()
            
            if db_users and db_roles:
                user_roles_data = generate_user_roles(
                    [{"id": str(u.id)} for u in db_users],
                    [{"id": str(r.id)} for r in db_roles]
                )
                
                for user_role_data in user_roles_data:
                    user_role_data.pop("id")  # Remove UUID, let SQLAlchemy generate
                    user_role = UserRole(**user_role_data)
                    db.add(user_role)
                    populated_items["user_roles"] += 1
            
            db.commit()
            
            # Generate and insert data contracts
            self.logger.info("Generating data contracts...")
            contracts_data = generate_data_contracts(15)
            contract_ids = []
            
            for contract_data in contracts_data:
                contract_id = contract_data.pop("id")
                contract = DataContract(**contract_data)
                db.add(contract)
                db.flush()  # Get the generated ID
                contract_ids.append(str(contract.id))
                populated_items["data_contracts"] += 1
            
            db.commit()
            
            # Generate and insert contract versions
            self.logger.info("Generating contract versions...")
            # Get actual contracts from database
            db_contracts = db.query(DataContract).all()
            
            if db_contracts:
                versions_data = generate_contract_versions(
                    [{"id": str(c.id)} for c in db_contracts], 2
                )
                
                for version_data in versions_data:
                    version_data.pop("id")  # Remove UUID, let SQLAlchemy generate
                    version = ContractVersion(**version_data)
                    db.add(version)
                    populated_items["contract_versions"] += 1
            
            db.commit()
            
            # Generate and insert quality rules
            self.logger.info("Generating quality rules...")
            quality_rules_data = generate_quality_rules(20)
            quality_rule_ids = []
            
            for rule_data in quality_rules_data:
                rule_id = rule_data.pop("id")
                rule = QualityRule(**rule_data)
                db.add(rule)
                db.flush()  # Get the generated ID
                quality_rule_ids.append(str(rule.id))
                populated_items["quality_rules"] += 1
            
            db.commit()
            
            # Generate and insert quality executions
            self.logger.info("Generating quality executions...")
            # Get actual quality rules from database
            db_quality_rules = db.query(QualityRule).all()
            
            if db_quality_rules:
                executions_data = generate_quality_executions(
                    [{"id": str(r.id)} for r in db_quality_rules], 3
                )
                execution_ids = []
                
                for execution_data in executions_data:
                    execution_id = execution_data.pop("id")
                    execution = QualityExecution(**execution_data)
                    db.add(execution)
                    db.flush()  # Get the generated ID
                    execution_ids.append(str(execution.id))
                    populated_items["quality_executions"] += 1
                
                db.commit()
                
                # Generate and insert quality results
                self.logger.info("Generating quality results...")
                # Get actual quality executions from database
                db_executions = db.query(QualityExecution).all()
                
                if db_executions:
                    results_data = generate_quality_results(
                        [{"id": str(e.id), "rule_id": str(e.rule_id)} for e in db_executions], 5
                    )
                    
                    for result_data in results_data:
                        result_data.pop("id")  # Remove UUID, let SQLAlchemy generate
                        result = QualityResult(**result_data)
                        db.add(result)
                        populated_items["quality_results"] += 1
                
                db.commit()
            
            db.close()
            
            return {
                "success": True,
                "populated_items": populated_items,
                "message": "Mock data populated successfully"
            }
            
        except Exception as e:
            if 'db' in locals():
                db.rollback()
                db.close()
            return {
                "success": False,
                "error": str(e),
                "message": "Failed to populate mock data"
            }
    
    async def _verify_database(self) -> Dict[str, Any]:
        """Verify database state after initialization."""
        try:
            conn = await asyncpg.connect(self.database_url)
            
            # Get table counts
            tables_query = """
                SELECT 
                    schemaname,
                    tablename,
                    n_tup_ins as row_count
                FROM pg_stat_user_tables 
                WHERE schemaname = 'public'
                ORDER BY tablename
            """
            
            tables_result = await conn.fetch(tables_query)
            table_counts = {row['tablename']: row['row_count'] for row in tables_result}
            
            # Get database size
            size_query = "SELECT pg_size_pretty(pg_database_size(current_database())) as size"
            db_size = await conn.fetchval(size_query)
            
            # Check for any constraint violations
            constraints_query = """
                SELECT COUNT(*) as constraint_violations
                FROM information_schema.table_constraints 
                WHERE constraint_type = 'CHECK' 
                AND table_schema = 'public'
            """
            
            constraint_count = await conn.fetchval(constraints_query)
            
            await conn.close()
            
            # Calculate total rows
            total_rows = sum(table_counts.values())
            
            return {
                "success": True,
                "database_size": db_size,
                "total_tables": len(table_counts),
                "total_rows": total_rows,
                "table_counts": table_counts,
                "constraint_count": constraint_count,
                "message": f"Database verified: {len(table_counts)} tables, {total_rows} total rows"
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "message": "Failed to verify database"
            }
    
    async def reset_database(self) -> Dict[str, Any]:
        """Reset database by dropping and recreating everything."""
        self.logger.info("🔄 Resetting database...")
        return await self.initialize_database(drop_existing=True, populate_mock=True)
    
    async def populate_additional_mock_data(self, domain: str, count: int = 10) -> Dict[str, Any]:
        """Populate additional mock data for specific domain."""
        self.logger.info(f"📊 Populating additional {domain} mock data...")
        
        # This would be extended to support all 12 domains
        supported_domains = ["contracts", "quality", "users"]
        
        if domain not in supported_domains:
            return {
                "success": False,
                "error": f"Domain '{domain}' not supported. Supported: {supported_domains}",
                "message": "Unsupported domain"
            }
        
        # Implementation would call specific mock data generators
        return {
            "success": True,
            "message": f"Additional {domain} mock data populated"
        }


async def main():
    """Main function for database initialization."""
    parser = argparse.ArgumentParser(description="Data Governance API Database Initializer")
    parser.add_argument("--action", choices=["init", "reset", "verify"], default="init",
                       help="Action to perform")
    parser.add_argument("--drop-existing", action="store_true",
                       help="Drop existing tables before creating")
    parser.add_argument("--no-mock-data", action="store_true",
                       help="Skip mock data population")
    parser.add_argument("--database-url",
                       help="Database URL (overrides environment)")
    parser.add_argument("--verbose", action="store_true",
                       help="Enable verbose logging")
    
    args = parser.parse_args()
    
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    initializer = DatabaseInitializer(args.database_url)
    
    try:
        if args.action == "init":
            result = await initializer.initialize_database(
                drop_existing=args.drop_existing,
                populate_mock=not args.no_mock_data
            )
        elif args.action == "reset":
            result = await initializer.reset_database()
        elif args.action == "verify":
            result = await initializer._verify_database()
        
        # Print results
        print(f"\n{'='*50}")
        print(f"Database {args.action.upper()} Results")
        print(f"{'='*50}")
        print(f"Status: {result['status'].upper()}")
        
        if result['status'] == 'success':
            if 'steps' in result:
                for step_name, step_result in result['steps'].items():
                    if step_result.get('success', True):
                        print(f"✅ {step_name}: {step_result.get('message', 'Completed')}")
                    else:
                        print(f"❌ {step_name}: {step_result.get('message', 'Failed')}")
            
            if 'message' in result:
                print(f"📝 {result['message']}")
        else:
            print(f"❌ Errors: {result.get('errors', [])}")
        
        print(f"{'='*50}\n")
        
        # Exit with appropriate code
        if result['status'] == 'success':
            sys.exit(0)
        else:
            sys.exit(1)
            
    except Exception as e:
        print(f"❌ Database initialization failed: {str(e)}")
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())

