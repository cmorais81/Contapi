"""
Data Masking Rule model.

Desenvolvido por Carlos Morais - Julho 2025
"""

from sqlalchemy import Boolean, Column, Enum, ForeignKey, String, Text, UUID
from sqlalchemy.orm import relationship
import enum

from app.models.base import BaseModel
from app.models.mixins import TimestampMixin


class MaskingType(enum.Enum):
    """Tipos de mascaramento."""
    FULL_MASK = "full_mask"           # Mascaramento completo
    PARTIAL_MASK = "partial_mask"     # Mascaramento parcial
    TOKENIZATION = "tokenization"     # Tokenização
    ENCRYPTION = "encryption"         # Criptografia
    HASHING = "hashing"              # Hash
    REDACTION = "redaction"          # Redação/remoção
    SUBSTITUTION = "substitution"     # Substituição
    SHUFFLING = "shuffling"          # Embaralhamento
    NULL_OUT = "null_out"            # Anulação
    SYNTHETIC = "synthetic"          # Dados sintéticos


class MaskingMethod(enum.Enum):
    """Métodos de mascaramento."""
    STATIC = "static"                # Mascaramento estático
    DYNAMIC = "dynamic"              # Mascaramento dinâmico
    FORMAT_PRESERVING = "format_preserving"  # Preserva formato
    DETERMINISTIC = "deterministic"   # Determinístico
    RANDOM = "random"                # Aleatório


class DataMaskingRule(BaseModel, TimestampMixin):
    """
    Modelo para regras de mascaramento de dados.
    
    Define regras para mascaramento e anonimização de dados
    sensíveis, incluindo diferentes técnicas de mascaramento
    baseadas na classificação e contexto dos dados.
    """
    
    __tablename__ = "data_masking_rules"
    
    # Identificação
    rule_id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        server_default="gen_random_uuid()",
        comment="Identificador único da regra"
    )
    
    rule_name = Column(
        String(255),
        nullable=False,
        comment="Nome da regra de mascaramento"
    )
    
    # Referências
    classification_id = Column(
        UUID(as_uuid=True),
        ForeignKey("data_classifications.classification_id"),
        comment="Referência à classificação de dados"
    )
    
    entity_id = Column(
        UUID(as_uuid=True),
        ForeignKey("entities.entity_id"),
        comment="Referência à entidade (campo/coluna específica)"
    )
    
    # Configuração do mascaramento
    masking_type = Column(
        Enum(MaskingType),
        nullable=False,
        comment="Tipo de mascaramento"
    )
    
    masking_method = Column(
        Enum(MaskingMethod),
        nullable=False,
        default=MaskingMethod.STATIC,
        comment="Método de mascaramento"
    )
    
    # Padrões e configurações
    mask_pattern = Column(
        String(255),
        comment="Padrão de mascaramento (ex: XXX-XX-XXXX)"
    )
    
    mask_character = Column(
        String(1),
        default="*",
        comment="Caractere de mascaramento"
    )
    
    preserve_format = Column(
        Boolean,
        default=True,
        comment="Preservar formato original"
    )
    
    preserve_length = Column(
        Boolean,
        default=True,
        comment="Preservar comprimento original"
    )
    
    # Configurações específicas
    partial_mask_start = Column(
        String(10),
        comment="Posição inicial para mascaramento parcial"
    )
    
    partial_mask_end = Column(
        String(10),
        comment="Posição final para mascaramento parcial"
    )
    
    substitution_values = Column(
        Text,
        comment="Valores de substituição (JSON array)"
    )
    
    # Configurações de criptografia
    encryption_algorithm = Column(
        String(50),
        comment="Algoritmo de criptografia (AES-256, etc.)"
    )
    
    encryption_key_id = Column(
        String(255),
        comment="ID da chave de criptografia"
    )
    
    # Configurações de tokenização
    token_format = Column(
        String(100),
        comment="Formato do token"
    )
    
    token_vault_id = Column(
        String(255),
        comment="ID do cofre de tokens"
    )
    
    # Aplicabilidade
    applicable_environments = Column(
        Text,
        comment="Ambientes aplicáveis (JSON array)"
    )
    
    applicable_roles = Column(
        Text,
        comment="Roles que veem dados mascarados (JSON array)"
    )
    
    # Exceções
    exception_conditions = Column(
        Text,
        comment="Condições de exceção (JSON)"
    )
    
    bypass_roles = Column(
        Text,
        comment="Roles que podem ver dados não mascarados (JSON array)"
    )
    
    # Controle e auditoria
    created_by = Column(
        String(255),
        nullable=False,
        comment="Criado por"
    )
    
    approved_by = Column(
        String(255),
        comment="Aprovado por"
    )
    
    is_active = Column(
        Boolean,
        default=True,
        nullable=False,
        comment="Regra ativa"
    )
    
    requires_approval = Column(
        Boolean,
        default=True,
        comment="Requer aprovação para mudanças"
    )
    
    # Performance
    performance_impact = Column(
        String(20),
        comment="Impacto na performance (low, medium, high)"
    )
    
    cache_enabled = Column(
        Boolean,
        default=False,
        comment="Cache de valores mascarados habilitado"
    )
    
    # Relacionamentos
    classification = relationship(
        "DataClassification",
        back_populates="masking_rules"
    )
    
    entity = relationship(
        "Entity"
    )
    
    def __repr__(self) -> str:
        return f"<DataMaskingRule(id={self.rule_id}, name='{self.rule_name}', type={self.masking_type.value})>"
    
    def get_applicable_environments(self) -> list:
        """
        Retorna lista de ambientes aplicáveis.
        
        Returns:
            Lista de ambientes
        """
        import json
        if not self.applicable_environments:
            return []
        try:
            return json.loads(self.applicable_environments)
        except:
            return []
    
    def get_applicable_roles(self) -> list:
        """
        Retorna lista de roles aplicáveis.
        
        Returns:
            Lista de roles
        """
        import json
        if not self.applicable_roles:
            return []
        try:
            return json.loads(self.applicable_roles)
        except:
            return []
    
    def get_bypass_roles(self) -> list:
        """
        Retorna lista de roles que podem ver dados não mascarados.
        
        Returns:
            Lista de roles de bypass
        """
        import json
        if not self.bypass_roles:
            return []
        try:
            return json.loads(self.bypass_roles)
        except:
            return []
    
    def get_substitution_values(self) -> list:
        """
        Retorna lista de valores de substituição.
        
        Returns:
            Lista de valores
        """
        import json
        if not self.substitution_values:
            return []
        try:
            return json.loads(self.substitution_values)
        except:
            return []
    
    def is_applicable_to_environment(self, environment: str) -> bool:
        """
        Verifica se a regra se aplica a um ambiente.
        
        Args:
            environment: Ambiente a verificar
            
        Returns:
            True se aplicável, False caso contrário
        """
        applicable_envs = self.get_applicable_environments()
        return not applicable_envs or environment in applicable_envs
    
    def is_applicable_to_role(self, role: str) -> bool:
        """
        Verifica se a regra se aplica a um role.
        
        Args:
            role: Role a verificar
            
        Returns:
            True se aplicável, False caso contrário
        """
        applicable_roles = self.get_applicable_roles()
        return not applicable_roles or role in applicable_roles
    
    def can_bypass_masking(self, role: str) -> bool:
        """
        Verifica se um role pode ver dados não mascarados.
        
        Args:
            role: Role a verificar
            
        Returns:
            True se pode fazer bypass, False caso contrário
        """
        bypass_roles = self.get_bypass_roles()
        return role in bypass_roles
    
    def generate_mask_preview(self, sample_value: str) -> str:
        """
        Gera preview do mascaramento para um valor de exemplo.
        
        Args:
            sample_value: Valor de exemplo
            
        Returns:
            Valor mascarado para preview
        """
        if not sample_value:
            return ""
        
        if self.masking_type == MaskingType.FULL_MASK:
            if self.preserve_length:
                return self.mask_character * len(sample_value)
            else:
                return self.mask_character * 8
        
        elif self.masking_type == MaskingType.PARTIAL_MASK:
            start = int(self.partial_mask_start or 0)
            end = int(self.partial_mask_end or len(sample_value))
            
            masked = list(sample_value)
            for i in range(start, min(end, len(masked))):
                masked[i] = self.mask_character
            
            return ''.join(masked)
        
        elif self.masking_type == MaskingType.REDACTION:
            return "[REDACTED]"
        
        elif self.masking_type == MaskingType.NULL_OUT:
            return ""
        
        elif self.masking_type == MaskingType.SUBSTITUTION:
            substitutions = self.get_substitution_values()
            if substitutions:
                import random
                return random.choice(substitutions)
        
        # Para outros tipos, retorna placeholder
        return f"[{self.masking_type.value.upper()}]"

