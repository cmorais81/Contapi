"""
Query Performance model.

Desenvolvido por Carlos Morais - Julho 2025
"""

from sqlalchemy import Boolean, Column, DateTime, Enum, String, Text, UUID
from sqlalchemy.orm import relationship
import enum

from app.models.base import BaseModel
from app.models.mixins import TimestampMixin


class QueryStatus(enum.Enum):
    """Status da query."""
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    TIMEOUT = "timeout"


class QueryType(enum.Enum):
    """Tipos de query."""
    SELECT = "select"
    INSERT = "insert"
    UPDATE = "update"
    DELETE = "delete"
    CREATE = "create"
    DROP = "drop"
    ALTER = "alter"
    MERGE = "merge"
    COPY = "copy"
    ANALYZE = "analyze"


class PerformanceLevel(enum.Enum):
    """Níveis de performance."""
    EXCELLENT = "excellent"    # < 1s
    GOOD = "good"             # 1-5s
    ACCEPTABLE = "acceptable"  # 5-30s
    SLOW = "slow"             # 30s-5min
    VERY_SLOW = "very_slow"   # > 5min


class QueryPerformance(BaseModel, TimestampMixin):
    """
    Modelo para análise de performance de queries.
    
    Captura e analisa métricas de performance de queries SQL,
    identificando gargalos, queries custosas e oportunidades
    de otimização para melhorar eficiência e reduzir custos.
    """
    
    __tablename__ = "query_performance"
    
    # Identificação
    performance_id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        server_default="gen_random_uuid()",
        comment="Identificador único da análise"
    )
    
    query_id = Column(
        String(255),
        nullable=False,
        comment="ID único da query no sistema"
    )
    
    # Metadados da query
    query_text = Column(
        Text,
        comment="Texto da query SQL"
    )
    
    query_hash = Column(
        String(64),
        comment="Hash da query para agrupamento"
    )
    
    query_type = Column(
        Enum(QueryType),
        comment="Tipo da query"
    )
    
    # Contexto de execução
    user_id = Column(
        String(255),
        comment="Usuário que executou a query"
    )
    
    application_name = Column(
        String(255),
        comment="Nome da aplicação"
    )
    
    database_name = Column(
        String(255),
        comment="Nome do banco de dados"
    )
    
    schema_name = Column(
        String(255),
        comment="Nome do schema"
    )
    
    cluster_id = Column(
        String(255),
        comment="ID do cluster Databricks"
    )
    
    warehouse_id = Column(
        String(255),
        comment="ID do warehouse"
    )
    
    # Timestamps de execução
    query_start_time = Column(
        DateTime,
        comment="Início da execução"
    )
    
    query_end_time = Column(
        DateTime,
        comment="Fim da execução"
    )
    
    # Métricas de performance
    execution_time_ms = Column(
        String(20),
        comment="Tempo de execução em milissegundos"
    )
    
    compilation_time_ms = Column(
        String(20),
        comment="Tempo de compilação em milissegundos"
    )
    
    planning_time_ms = Column(
        String(20),
        comment="Tempo de planejamento em milissegundos"
    )
    
    # Métricas de recursos
    cpu_time_ms = Column(
        String(20),
        comment="Tempo de CPU em milissegundos"
    )
    
    peak_memory_mb = Column(
        String(20),
        comment="Pico de memória em MB"
    )
    
    spilled_memory_mb = Column(
        String(20),
        comment="Memória derramada para disco em MB"
    )
    
    # Métricas de I/O
    bytes_read = Column(
        String(20),
        comment="Bytes lidos"
    )
    
    bytes_written = Column(
        String(20),
        comment="Bytes escritos"
    )
    
    rows_read = Column(
        String(20),
        comment="Linhas lidas"
    )
    
    rows_written = Column(
        String(20),
        comment="Linhas escritas"
    )
    
    files_read = Column(
        String(20),
        comment="Arquivos lidos"
    )
    
    # Métricas de rede
    shuffle_bytes = Column(
        String(20),
        comment="Bytes transferidos via shuffle"
    )
    
    network_bytes = Column(
        String(20),
        comment="Bytes transferidos via rede"
    )
    
    # Status e resultado
    status = Column(
        Enum(QueryStatus),
        nullable=False,
        comment="Status da execução"
    )
    
    error_message = Column(
        Text,
        comment="Mensagem de erro, se houver"
    )
    
    # Análise de performance
    performance_level = Column(
        Enum(PerformanceLevel),
        comment="Nível de performance classificado"
    )
    
    is_slow_query = Column(
        Boolean,
        default=False,
        comment="Query considerada lenta"
    )
    
    is_expensive_query = Column(
        Boolean,
        default=False,
        comment="Query considerada custosa"
    )
    
    # Custos
    compute_cost_usd = Column(
        String(20),
        comment="Custo de computação em USD"
    )
    
    storage_cost_usd = Column(
        String(20),
        comment="Custo de armazenamento em USD"
    )
    
    total_cost_usd = Column(
        String(20),
        comment="Custo total em USD"
    )
    
    # Plano de execução
    execution_plan = Column(
        Text,
        comment="Plano de execução (JSON)"
    )
    
    # Tabelas acessadas
    tables_accessed = Column(
        Text,
        comment="Tabelas acessadas (JSON array)"
    )
    
    # Recomendações
    optimization_suggestions = Column(
        Text,
        comment="Sugestões de otimização (JSON)"
    )
    
    # Relacionamentos
    alerts = relationship(
        "PerformanceAlert",
        back_populates="query_performance",
        cascade="all, delete-orphan"
    )
    
    def __repr__(self) -> str:
        return f"<QueryPerformance(id={self.performance_id}, query_id='{self.query_id}', level={self.performance_level})>"
    
    @property
    def execution_time_seconds(self) -> float:
        """Retorna tempo de execução em segundos."""
        if self.execution_time_ms:
            try:
                return float(self.execution_time_ms) / 1000.0
            except:
                pass
        return 0.0
    
    @property
    def is_problematic(self) -> bool:
        """Verifica se a query é problemática."""
        return (
            self.is_slow_query or 
            self.is_expensive_query or
            self.performance_level in [PerformanceLevel.SLOW, PerformanceLevel.VERY_SLOW]
        )
    
    def get_tables_accessed(self) -> list:
        """
        Retorna lista de tabelas acessadas.
        
        Returns:
            Lista de tabelas
        """
        import json
        if not self.tables_accessed:
            return []
        try:
            return json.loads(self.tables_accessed)
        except:
            return []
    
    def get_optimization_suggestions(self) -> list:
        """
        Retorna sugestões de otimização.
        
        Returns:
            Lista de sugestões
        """
        import json
        if not self.optimization_suggestions:
            return []
        try:
            return json.loads(self.optimization_suggestions)
        except:
            return []
    
    def get_execution_plan(self) -> dict:
        """
        Retorna plano de execução.
        
        Returns:
            Dicionário com plano de execução
        """
        import json
        if not self.execution_plan:
            return {}
        try:
            return json.loads(self.execution_plan)
        except:
            return {}
    
    def classify_performance(self):
        """Classifica o nível de performance baseado no tempo de execução."""
        exec_time = self.execution_time_seconds
        
        if exec_time < 1:
            self.performance_level = PerformanceLevel.EXCELLENT
        elif exec_time < 5:
            self.performance_level = PerformanceLevel.GOOD
        elif exec_time < 30:
            self.performance_level = PerformanceLevel.ACCEPTABLE
        elif exec_time < 300:  # 5 minutos
            self.performance_level = PerformanceLevel.SLOW
            self.is_slow_query = True
        else:
            self.performance_level = PerformanceLevel.VERY_SLOW
            self.is_slow_query = True
    
    def calculate_efficiency_score(self) -> float:
        """
        Calcula score de eficiência da query.
        
        Returns:
            Score de 0.0 (ineficiente) a 1.0 (muito eficiente)
        """
        score = 1.0
        
        # Penalizar por tempo de execução
        exec_time = self.execution_time_seconds
        if exec_time > 300:  # > 5 min
            score -= 0.5
        elif exec_time > 30:  # > 30s
            score -= 0.3
        elif exec_time > 5:   # > 5s
            score -= 0.1
        
        # Penalizar por uso de memória
        if self.spilled_memory_mb:
            try:
                spilled = float(self.spilled_memory_mb)
                if spilled > 0:
                    score -= 0.2  # Memória derramada é ineficiente
            except:
                pass
        
        # Penalizar por alto custo
        if self.total_cost_usd:
            try:
                cost = float(self.total_cost_usd)
                if cost > 10:  # > $10
                    score -= 0.2
                elif cost > 1:  # > $1
                    score -= 0.1
            except:
                pass
        
        return max(0.0, score)
    
    def generate_performance_summary(self) -> dict:
        """
        Gera resumo de performance.
        
        Returns:
            Dicionário com resumo
        """
        return {
            "query_id": self.query_id,
            "execution_time_seconds": self.execution_time_seconds,
            "performance_level": self.performance_level.value if self.performance_level else None,
            "is_problematic": self.is_problematic,
            "efficiency_score": self.calculate_efficiency_score(),
            "total_cost_usd": self.total_cost_usd,
            "rows_processed": self.rows_read,
            "bytes_processed": self.bytes_read,
            "tables_count": len(self.get_tables_accessed()),
            "suggestions_count": len(self.get_optimization_suggestions())
        }

