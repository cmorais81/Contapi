"""
Tag schemas.

Desenvolvido por Carlos Morais - Julho 2025
"""

from datetime import datetime
from typing import List, Optional
from uuid import UUID

from pydantic import Field, validator

from app.schemas.base import BaseSchema


class TagBase(BaseSchema):
    """Schema base para tags."""
    
    tag_name: str = Field(
        ...,
        description="Nome único da tag",
        examples=["PII", "Sensitive Data", "Business Critical", "GDPR"]
    )
    
    tag_description: Optional[str] = Field(
        None,
        description="Descrição da tag",
        examples=["Dados pessoais identificáveis", "Informações sensíveis da empresa"]
    )
    
    tag_category: Optional[str] = Field(
        None,
        description="Categoria da tag",
        examples=["privacy", "business", "technical", "compliance", "quality"]
    )
    
    tag_color: Optional[str] = Field(
        None,
        pattern="^#[0-9A-Fa-f]{6}$",
        description="Cor da tag em formato hex",
        examples=["#FF5733", "#33FF57", "#3357FF"]
    )
    
    tag_icon: Optional[str] = Field(
        None,
        description="Ícone da tag",
        examples=["shield", "lock", "star", "warning"]
    )
    
    parent_tag_id: Optional[UUID] = Field(
        None,
        description="ID da tag pai (para hierarquia)"
    )
    
    is_system_tag: bool = Field(
        False,
        description="Tag do sistema (não editável)"
    )
    
    is_active: bool = Field(
        True,
        description="Tag ativa"
    )


class TagCreate(TagBase):
    """Schema para criação de tag."""
    
    @validator('tag_category')
    def validate_category(cls, v):
        if v is not None:
            valid_categories = ['privacy', 'business', 'technical', 'compliance', 'quality', 'security']
            if v not in valid_categories:
                raise ValueError(f'Categoria deve ser uma de: {", ".join(valid_categories)}')
        return v
    
    @validator('tag_name')
    def validate_tag_name(cls, v):
        if len(v.strip()) < 2:
            raise ValueError('Nome da tag deve ter pelo menos 2 caracteres')
        return v.strip()


class TagUpdate(BaseSchema):
    """Schema para atualização de tag."""
    
    tag_name: Optional[str] = Field(
        None,
        description="Nome da tag"
    )
    
    tag_description: Optional[str] = Field(
        None,
        description="Descrição da tag"
    )
    
    tag_category: Optional[str] = Field(
        None,
        description="Categoria da tag"
    )
    
    tag_color: Optional[str] = Field(
        None,
        pattern="^#[0-9A-Fa-f]{6}$",
        description="Cor da tag em formato hex"
    )
    
    tag_icon: Optional[str] = Field(
        None,
        description="Ícone da tag"
    )
    
    parent_tag_id: Optional[UUID] = Field(
        None,
        description="ID da tag pai"
    )
    
    is_active: Optional[bool] = Field(
        None,
        description="Tag ativa"
    )
    
    @validator('tag_category')
    def validate_category(cls, v):
        if v is not None:
            valid_categories = ['privacy', 'business', 'technical', 'compliance', 'quality', 'security']
            if v not in valid_categories:
                raise ValueError(f'Categoria deve ser uma de: {", ".join(valid_categories)}')
        return v


class TagResponse(TagBase):
    """Schema de resposta para tag."""
    
    tag_id: UUID = Field(
        ...,
        description="Identificador único da tag"
    )
    
    data_criacao: datetime = Field(
        ...,
        description="Data de criação"
    )
    
    data_atualizacao: datetime = Field(
        ...,
        description="Data da última atualização"
    )
    
    full_path: Optional[str] = Field(
        None,
        description="Caminho completo na hierarquia",
        examples=["Privacy > PII", "Business > Critical > Customer Data"]
    )
    
    class Config:
        from_attributes = True


class TagChild(BaseSchema):
    """Schema para tag filha na hierarquia."""
    
    tag_id: UUID
    tag_name: str
    tag_description: Optional[str]
    tag_category: Optional[str]
    tag_color: Optional[str]
    is_active: bool


class TagWithChildren(TagResponse):
    """Schema de tag com suas tags filhas."""
    
    child_tags: List[TagChild] = Field(
        default_factory=list,
        description="Tags filhas"
    )
    
    entity_count: int = Field(
        0,
        description="Número de entidades com esta tag"
    )


class TagHierarchy(BaseSchema):
    """Schema para hierarquia completa de tags."""
    
    tag_id: UUID
    tag_name: str
    tag_description: Optional[str]
    tag_category: Optional[str]
    tag_color: Optional[str]
    level: int = Field(
        0,
        description="Nível na hierarquia (0 = raiz)"
    )
    children: List['TagHierarchy'] = Field(
        default_factory=list,
        description="Tags filhas"
    )
    
    class Config:
        from_attributes = True


class TagStats(BaseSchema):
    """Estatísticas de uso de tags."""
    
    tag_id: UUID
    tag_name: str
    tag_category: Optional[str]
    total_entities: int = Field(
        0,
        description="Total de entidades com esta tag"
    )
    active_entities: int = Field(
        0,
        description="Entidades ativas com esta tag"
    )
    entity_types: dict = Field(
        default_factory=dict,
        description="Distribuição por tipo de entidade"
    )
    recent_usage: int = Field(
        0,
        description="Uso nos últimos 30 dias"
    )


class TagSearch(BaseSchema):
    """Schema para busca de tags."""
    
    tag_name: Optional[str] = Field(
        None,
        description="Filtro por nome da tag"
    )
    
    tag_category: Optional[str] = Field(
        None,
        description="Filtro por categoria"
    )
    
    parent_tag_id: Optional[UUID] = Field(
        None,
        description="Filtro por tag pai"
    )
    
    is_system_tag: Optional[bool] = Field(
        None,
        description="Filtro por tags do sistema"
    )
    
    is_active: Optional[bool] = Field(
        True,
        description="Filtro por tags ativas"
    )
    
    include_children: bool = Field(
        False,
        description="Incluir tags filhas"
    )
    
    include_stats: bool = Field(
        False,
        description="Incluir estatísticas de uso"
    )


# Permitir referências circulares
TagHierarchy.model_rebuild()

