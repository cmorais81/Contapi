"""
Contract Schema Definition model.
"""

from sqlalchemy import Column, ForeignKey, String, Text
from sqlalchemy.dialects.postgresql import UUID as PostgresUUID
from sqlalchemy.orm import relationship

from app.models.base import BaseModel


class ContractSchemaDefinition(BaseModel):
    """
    Contract Schema Definition model.
    
    Data schema definitions and structure.
    """

    __tablename__ = "contract_schema_definitions"

    # Foreign key to contract
    contract_id = Column(
        PostgresUUID(as_uuid=True),
        ForeignKey("data_contracts.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
        doc="Reference to contract"
    )

    # Schema definition
    schema_name = Column(
        String(255),
        nullable=False,
        doc="Schema name"
    )

    schema_version = Column(
        String(50),
        doc="Schema version"
    )

    schema_format = Column(
        String(50),
        doc="Schema format: avro, json-schema, protobuf, parquet"
    )

    schema_content = Column(
        Text,
        doc="Schema definition content"
    )

    evolution_strategy = Column(
        String(50),
        doc="Schema evolution strategy: backward, forward, full"
    )

    # Relationships
    contract = relationship(
        "DataContract",
        back_populates="schema_definitions"
    )

    def __repr__(self) -> str:
        return f"<ContractSchemaDefinition(name={self.schema_name}, version={self.schema_version})>"

