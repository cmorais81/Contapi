"""
Contract Version model.

Desenvolvido por Carlos Morais (carlos.morais@f1rst.com.br)
Julho 2025
"""

from sqlalchemy import Column, Integer, String, Text, DateTime, Boolean, JSON, ForeignKey
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from app.models.base import BaseModel


class ContractVersion(BaseModel):
    """
    Modelo para versionamento de contratos de dados.
    
    Mantém histórico de todas as versões de um contrato,
    permitindo rollback e auditoria de mudanças.
    """
    __tablename__ = "contract_versions"

    # Campos principais
    version_id = Column(Integer, primary_key=True, index=True)
    contract_id = Column(Integer, ForeignKey("data_contracts.contract_id"), nullable=False)
    version_number = Column(String(20), nullable=False)
    version_description = Column(Text)
    
    # Status da versão
    status = Column(String(50), nullable=False, default="draft")
    is_current = Column(Boolean, default=False)
    
    # Conteúdo da versão
    schema_snapshot = Column(JSON)
    quality_rules_snapshot = Column(JSON)
    sla_snapshot = Column(JSON)
    pricing_snapshot = Column(JSON)
    
    # Metadados de mudança
    change_type = Column(String(50))  # major, minor, patch
    breaking_changes = Column(Boolean, default=False)
    migration_notes = Column(Text)
    
    # Aprovação
    approved_by = Column(String(255))
    approved_at = Column(DateTime(timezone=True))
    approval_notes = Column(Text)
    
    # Auditoria
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    created_by = Column(String(255), nullable=False)
    updated_by = Column(String(255))
    
    # Relacionamentos
    contract = relationship("DataContract", back_populates="versions")
    
    def __repr__(self):
        return f"<ContractVersion(id={self.version_id}, contract_id={self.contract_id}, version='{self.version_number}')>"
    
    @property
    def is_approved(self):
        """Verifica se a versão foi aprovada."""
        return self.approved_by is not None and self.approved_at is not None
    
    def approve(self, approved_by: str, notes: str = None):
        """Aprova a versão do contrato."""
        self.approved_by = approved_by
        self.approved_at = func.now()
        self.approval_notes = notes
        self.status = "approved"
    
    def set_as_current(self):
        """Define esta versão como a atual."""
        # Remove flag current de outras versões
        for version in self.contract.versions:
            version.is_current = False
        
        # Define esta como atual
        self.is_current = True
        self.status = "active"

