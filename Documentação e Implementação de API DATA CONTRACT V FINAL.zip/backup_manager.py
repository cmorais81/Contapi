#!/usr/bin/env python3
"""
Backup Manager Script for Data Governance API.

Automated backup and restore functionality for database and configurations.

Author: Carlos Morais <carlos.morais@f1rst.com.br>
Date: July 2025
"""

import os
import sys
import json
import logging
import subprocess
import gzip
import shutil
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Any, Optional
import boto3
from botocore.exceptions import ClientError

# Add project root to path
sys.path.append(str(Path(__file__).parent.parent.parent))

from app.core.config import settings


class BackupManager:
    """Comprehensive backup manager for Data Governance API."""
    
    def __init__(self, backup_dir: str = "/tmp/backups"):
        self.backup_dir = Path(backup_dir)
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        self.logger = self._setup_logging()
        
        # AWS S3 configuration (optional)
        self.s3_client = None
        if hasattr(settings, 'AWS_ACCESS_KEY_ID') and settings.AWS_ACCESS_KEY_ID:
            try:
                self.s3_client = boto3.client(
                    's3',
                    aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
                    aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY,
                    region_name=getattr(settings, 'AWS_REGION', 'us-east-1')
                )
                self.s3_bucket = getattr(settings, 'BACKUP_S3_BUCKET', None)
            except Exception as e:
                self.logger.warning(f"Failed to initialize S3 client: {e}")
    
    def _setup_logging(self) -> logging.Logger:
        """Setup logging configuration."""
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        return logging.getLogger(__name__)
    
    def create_full_backup(self, include_s3: bool = True) -> Dict[str, Any]:
        """Create a full system backup."""
        timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        backup_name = f"full_backup_{timestamp}"
        backup_path = self.backup_dir / backup_name
        backup_path.mkdir(parents=True, exist_ok=True)
        
        self.logger.info(f"Starting full backup: {backup_name}")
        
        results = {
            "backup_name": backup_name,
            "timestamp": timestamp,
            "backup_path": str(backup_path),
            "components": {}
        }
        
        try:
            # 1. Database backup
            self.logger.info("Creating database backup...")
            db_result = self._backup_database(backup_path)
            results["components"]["database"] = db_result
            
            # 2. Configuration backup
            self.logger.info("Creating configuration backup...")
            config_result = self._backup_configurations(backup_path)
            results["components"]["configurations"] = config_result
            
            # 3. Application logs backup
            self.logger.info("Creating logs backup...")
            logs_result = self._backup_logs(backup_path)
            results["components"]["logs"] = logs_result
            
            # 4. Static files backup
            self.logger.info("Creating static files backup...")
            static_result = self._backup_static_files(backup_path)
            results["components"]["static_files"] = static_result
            
            # 5. Create backup manifest
            manifest = self._create_backup_manifest(results)
            manifest_path = backup_path / "backup_manifest.json"
            with open(manifest_path, 'w') as f:
                json.dump(manifest, f, indent=2, default=str)
            
            # 6. Compress backup
            self.logger.info("Compressing backup...")
            compressed_path = self._compress_backup(backup_path)
            results["compressed_path"] = str(compressed_path)
            results["compressed_size_mb"] = round(compressed_path.stat().st_size / (1024*1024), 2)
            
            # 7. Upload to S3 if configured
            if include_s3 and self.s3_client and self.s3_bucket:
                self.logger.info("Uploading backup to S3...")
                s3_result = self._upload_to_s3(compressed_path)
                results["s3_upload"] = s3_result
            
            # 8. Cleanup old backups
            self._cleanup_old_backups()
            
            results["status"] = "success"
            results["duration_seconds"] = (datetime.utcnow() - datetime.strptime(timestamp, "%Y%m%d_%H%M%S")).total_seconds()
            
            self.logger.info(f"Full backup completed successfully: {backup_name}")
            
        except Exception as e:
            self.logger.error(f"Backup failed: {str(e)}")
            results["status"] = "failed"
            results["error"] = str(e)
        
        return results
    
    def _backup_database(self, backup_path: Path) -> Dict[str, Any]:
        """Backup PostgreSQL database."""
        try:
            db_backup_path = backup_path / "database"
            db_backup_path.mkdir(exist_ok=True)
            
            # Database connection parameters
            db_host = getattr(settings, 'DATABASE_HOST', 'localhost')
            db_port = getattr(settings, 'DATABASE_PORT', 5432)
            db_name = getattr(settings, 'DATABASE_NAME', 'data_governance')
            db_user = getattr(settings, 'DATABASE_USER', 'postgres')
            
            # Set PGPASSWORD environment variable
            env = os.environ.copy()
            env['PGPASSWORD'] = getattr(settings, 'DATABASE_PASSWORD', '')
            
            # Full database dump
            dump_file = db_backup_path / f"{db_name}_full.sql"
            dump_cmd = [
                'pg_dump',
                '-h', db_host,
                '-p', str(db_port),
                '-U', db_user,
                '-d', db_name,
                '--verbose',
                '--no-password',
                '--format=custom',
                '--file', str(dump_file)
            ]
            
            result = subprocess.run(dump_cmd, env=env, capture_output=True, text=True)
            
            if result.returncode != 0:
                raise Exception(f"pg_dump failed: {result.stderr}")
            
            # Schema-only dump
            schema_file = db_backup_path / f"{db_name}_schema.sql"
            schema_cmd = [
                'pg_dump',
                '-h', db_host,
                '-p', str(db_port),
                '-U', db_user,
                '-d', db_name,
                '--schema-only',
                '--no-password',
                '--file', str(schema_file)
            ]
            
            subprocess.run(schema_cmd, env=env, capture_output=True, text=True)
            
            # Data-only dump for critical tables
            critical_tables = [
                'data_contracts', 'contract_versions', 'quality_rules',
                'users', 'roles', 'user_roles'
            ]
            
            for table in critical_tables:
                table_file = db_backup_path / f"{table}_data.sql"
                table_cmd = [
                    'pg_dump',
                    '-h', db_host,
                    '-p', str(db_port),
                    '-U', db_user,
                    '-d', db_name,
                    '--data-only',
                    '--table', table,
                    '--no-password',
                    '--file', str(table_file)
                ]
                subprocess.run(table_cmd, env=env, capture_output=True, text=True)
            
            # Get database statistics
            stats = self._get_database_stats()
            
            return {
                "status": "success",
                "dump_file": str(dump_file),
                "dump_size_mb": round(dump_file.stat().st_size / (1024*1024), 2),
                "schema_file": str(schema_file),
                "critical_tables_backed_up": len(critical_tables),
                "database_stats": stats
            }
            
        except Exception as e:
            return {
                "status": "failed",
                "error": str(e)
            }
    
    def _backup_configurations(self, backup_path: Path) -> Dict[str, Any]:
        """Backup configuration files."""
        try:
            config_backup_path = backup_path / "configurations"
            config_backup_path.mkdir(exist_ok=True)
            
            # Application configuration files
            config_files = [
                ".env",
                ".env.example",
                "alembic.ini",
                "pyproject.toml",
                "requirements.txt",
                "requirements-dev.txt",
                "docker-compose.yml",
                "Dockerfile"
            ]
            
            project_root = Path(__file__).parent.parent.parent
            backed_up_files = []
            
            for config_file in config_files:
                source_path = project_root / config_file
                if source_path.exists():
                    dest_path = config_backup_path / config_file
                    shutil.copy2(source_path, dest_path)
                    backed_up_files.append(config_file)
            
            # Backup entire app/core directory (configurations)
            core_backup_path = config_backup_path / "app_core"
            core_source_path = project_root / "app" / "core"
            if core_source_path.exists():
                shutil.copytree(core_source_path, core_backup_path)
            
            # Create configuration summary
            config_summary = {
                "environment": getattr(settings, 'ENVIRONMENT', 'unknown'),
                "database_url_masked": self._mask_sensitive_data(getattr(settings, 'DATABASE_URL', '')),
                "debug_mode": getattr(settings, 'DEBUG', False),
                "api_version": getattr(settings, 'API_VERSION', '1.0.0'),
                "backup_timestamp": datetime.utcnow().isoformat()
            }
            
            summary_path = config_backup_path / "config_summary.json"
            with open(summary_path, 'w') as f:
                json.dump(config_summary, f, indent=2)
            
            return {
                "status": "success",
                "backed_up_files": backed_up_files,
                "config_summary_file": str(summary_path)
            }
            
        except Exception as e:
            return {
                "status": "failed",
                "error": str(e)
            }
    
    def _backup_logs(self, backup_path: Path) -> Dict[str, Any]:
        """Backup application logs."""
        try:
            logs_backup_path = backup_path / "logs"
            logs_backup_path.mkdir(exist_ok=True)
            
            # Common log locations
            log_locations = [
                "/var/log/data-governance-api/",
                "./logs/",
                "/tmp/logs/",
                "/app/logs/"
            ]
            
            backed_up_logs = []
            
            for log_location in log_locations:
                log_path = Path(log_location)
                if log_path.exists() and log_path.is_dir():
                    for log_file in log_path.glob("*.log*"):
                        if log_file.is_file():
                            dest_file = logs_backup_path / log_file.name
                            shutil.copy2(log_file, dest_file)
                            backed_up_logs.append(str(log_file))
            
            # Compress logs
            if backed_up_logs:
                for log_file in logs_backup_path.glob("*.log"):
                    with open(log_file, 'rb') as f_in:
                        with gzip.open(f"{log_file}.gz", 'wb') as f_out:
                            shutil.copyfileobj(f_in, f_out)
                    log_file.unlink()  # Remove uncompressed file
            
            return {
                "status": "success",
                "backed_up_logs": len(backed_up_logs),
                "log_files": backed_up_logs
            }
            
        except Exception as e:
            return {
                "status": "failed",
                "error": str(e)
            }
    
    def _backup_static_files(self, backup_path: Path) -> Dict[str, Any]:
        """Backup static files and uploads."""
        try:
            static_backup_path = backup_path / "static_files"
            static_backup_path.mkdir(exist_ok=True)
            
            project_root = Path(__file__).parent.parent.parent
            
            # Backup directories that might contain user uploads or generated files
            static_dirs = [
                "uploads",
                "static",
                "media",
                "exports"
            ]
            
            backed_up_dirs = []
            
            for static_dir in static_dirs:
                source_path = project_root / static_dir
                if source_path.exists() and source_path.is_dir():
                    dest_path = static_backup_path / static_dir
                    shutil.copytree(source_path, dest_path)
                    backed_up_dirs.append(static_dir)
            
            return {
                "status": "success",
                "backed_up_directories": backed_up_dirs
            }
            
        except Exception as e:
            return {
                "status": "failed",
                "error": str(e)
            }
    
    def _create_backup_manifest(self, backup_results: Dict[str, Any]) -> Dict[str, Any]:
        """Create backup manifest with metadata."""
        return {
            "backup_version": "1.0",
            "created_at": datetime.utcnow().isoformat(),
            "created_by": "backup_manager",
            "backup_type": "full",
            "application_version": getattr(settings, 'API_VERSION', '1.0.0'),
            "environment": getattr(settings, 'ENVIRONMENT', 'unknown'),
            "components": backup_results.get("components", {}),
            "system_info": {
                "hostname": os.uname().nodename,
                "platform": os.uname().sysname,
                "python_version": sys.version
            }
        }
    
    def _compress_backup(self, backup_path: Path) -> Path:
        """Compress backup directory."""
        compressed_path = backup_path.with_suffix('.tar.gz')
        
        # Create tar.gz archive
        shutil.make_archive(
            str(backup_path),
            'gztar',
            str(backup_path.parent),
            str(backup_path.name)
        )
        
        # Remove uncompressed directory
        shutil.rmtree(backup_path)
        
        return compressed_path
    
    def _upload_to_s3(self, backup_file: Path) -> Dict[str, Any]:
        """Upload backup to S3."""
        try:
            if not self.s3_client or not self.s3_bucket:
                return {"status": "skipped", "reason": "S3 not configured"}
            
            s3_key = f"backups/{backup_file.name}"
            
            self.s3_client.upload_file(
                str(backup_file),
                self.s3_bucket,
                s3_key,
                ExtraArgs={
                    'ServerSideEncryption': 'AES256',
                    'Metadata': {
                        'backup-type': 'full',
                        'created-at': datetime.utcnow().isoformat()
                    }
                }
            )
            
            return {
                "status": "success",
                "s3_bucket": self.s3_bucket,
                "s3_key": s3_key,
                "s3_url": f"s3://{self.s3_bucket}/{s3_key}"
            }
            
        except ClientError as e:
            return {
                "status": "failed",
                "error": str(e)
            }
    
    def _cleanup_old_backups(self, retention_days: int = 30):
        """Clean up old backup files."""
        try:
            cutoff_date = datetime.utcnow() - timedelta(days=retention_days)
            
            # Clean up local backups
            for backup_file in self.backup_dir.glob("full_backup_*.tar.gz"):
                if backup_file.stat().st_mtime < cutoff_date.timestamp():
                    backup_file.unlink()
                    self.logger.info(f"Deleted old backup: {backup_file.name}")
            
            # Clean up S3 backups if configured
            if self.s3_client and self.s3_bucket:
                try:
                    response = self.s3_client.list_objects_v2(
                        Bucket=self.s3_bucket,
                        Prefix="backups/"
                    )
                    
                    for obj in response.get('Contents', []):
                        if obj['LastModified'].replace(tzinfo=None) < cutoff_date:
                            self.s3_client.delete_object(
                                Bucket=self.s3_bucket,
                                Key=obj['Key']
                            )
                            self.logger.info(f"Deleted old S3 backup: {obj['Key']}")
                            
                except ClientError as e:
                    self.logger.warning(f"Failed to cleanup S3 backups: {e}")
            
        except Exception as e:
            self.logger.warning(f"Backup cleanup failed: {e}")
    
    def _get_database_stats(self) -> Dict[str, Any]:
        """Get database statistics."""
        try:
            import asyncpg
            import asyncio
            
            async def get_stats():
                from app.core.database import get_database_url
                conn = await asyncpg.connect(get_database_url())
                
                # Get table counts
                tables_query = """
                    SELECT schemaname, tablename, n_tup_ins, n_tup_upd, n_tup_del
                    FROM pg_stat_user_tables
                    ORDER BY n_tup_ins DESC
                    LIMIT 10
                """
                tables = await conn.fetch(tables_query)
                
                # Get database size
                size_query = "SELECT pg_size_pretty(pg_database_size(current_database()))"
                db_size = await conn.fetchval(size_query)
                
                await conn.close()
                
                return {
                    "database_size": db_size,
                    "top_tables": [dict(row) for row in tables]
                }
            
            return asyncio.run(get_stats())
            
        except Exception as e:
            return {"error": str(e)}
    
    def _mask_sensitive_data(self, data: str) -> str:
        """Mask sensitive information in configuration data."""
        if not data:
            return data
        
        # Mask passwords in database URLs
        if "://" in data and "@" in data:
            parts = data.split("://")
            if len(parts) == 2:
                protocol = parts[0]
                rest = parts[1]
                if "@" in rest:
                    auth_part, host_part = rest.split("@", 1)
                    if ":" in auth_part:
                        user, _ = auth_part.split(":", 1)
                        return f"{protocol}://{user}:***@{host_part}"
        
        return data
    
    def restore_backup(self, backup_file: str, components: List[str] = None) -> Dict[str, Any]:
        """Restore from backup file."""
        self.logger.info(f"Starting restore from backup: {backup_file}")
        
        # Implementation would include:
        # 1. Extract backup archive
        # 2. Validate backup manifest
        # 3. Restore selected components
        # 4. Verify restoration
        
        # This is a placeholder for the restore functionality
        return {
            "status": "not_implemented",
            "message": "Restore functionality to be implemented"
        }


def main():
    """Main function for backup operations."""
    import argparse
    
    parser = argparse.ArgumentParser(description="Data Governance API Backup Manager")
    parser.add_argument("--action", choices=["backup", "restore"], default="backup",
                       help="Action to perform")
    parser.add_argument("--backup-dir", default="/tmp/backups",
                       help="Backup directory")
    parser.add_argument("--no-s3", action="store_true",
                       help="Skip S3 upload")
    parser.add_argument("--restore-file", 
                       help="Backup file to restore from")
    
    args = parser.parse_args()
    
    backup_manager = BackupManager(args.backup_dir)
    
    if args.action == "backup":
        result = backup_manager.create_full_backup(include_s3=not args.no_s3)
        print(json.dumps(result, indent=2, default=str))
        
        if result["status"] == "success":
            sys.exit(0)
        else:
            sys.exit(1)
            
    elif args.action == "restore":
        if not args.restore_file:
            print("Error: --restore-file is required for restore action")
            sys.exit(1)
        
        result = backup_manager.restore_backup(args.restore_file)
        print(json.dumps(result, indent=2, default=str))
        
        if result["status"] == "success":
            sys.exit(0)
        else:
            sys.exit(1)


if __name__ == "__main__":
    main()

