"""
Entity model.

Desenvolvido por Carlos Morais - Julho 2025
"""

from sqlalchemy import Boolean, Column, String, Text, UUID
from sqlalchemy.orm import relationship

from app.models.base import BaseModel
from app.models.mixins import TimestampMixin


class Entity(BaseModel, TimestampMixin):
    """
    Modelo para entidades que podem ser taggeadas no sistema.
    
    Representa qualquer objeto que pode receber tags, incluindo:
    - Contratos de dados
    - Objetos de dados
    - Catálogos Unity Catalog
    - Schemas e tabelas
    - Colunas específicas
    """
    
    __tablename__ = "entities"
    
    # Identificação
    entity_id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        server_default="gen_random_uuid()",
        comment="Identificador único da entidade"
    )
    
    entity_name = Column(
        Text,
        nullable=False,
        comment="Nome da entidade"
    )
    
    entity_type = Column(
        String(50),
        nullable=False,
        comment="Tipo: catalog, schema, table, column, contract, data_object"
    )
    
    entity_description = Column(
        Text,
        comment="Descrição da entidade"
    )
    
    # Referência ao objeto real
    object_reference_type = Column(
        String(50),
        comment="Tipo do objeto referenciado (data_contracts, data_objects, etc.)"
    )
    
    object_reference_id = Column(
        UUID(as_uuid=True),
        comment="ID do objeto referenciado"
    )
    
    # Metadados Unity Catalog
    unity_catalog_path = Column(
        Text,
        comment="Caminho completo no Unity Catalog"
    )
    
    unity_catalog_type = Column(
        String(50),
        comment="Tipo no Unity Catalog"
    )
    
    # Controle
    is_active = Column(
        Boolean,
        default=True,
        nullable=False,
        comment="Entidade ativa"
    )
    
    # Relacionamentos
    tags = relationship(
        "Tagged",
        back_populates="entity",
        cascade="all, delete-orphan"
    )
    
    def __repr__(self) -> str:
        return f"<Entity(id={self.entity_id}, name='{self.entity_name}', type='{self.entity_type}')>"
    
    @property
    def active_tags(self):
        """Retorna apenas as tags ativas desta entidade."""
        return [tagged for tagged in self.tags if tagged.is_active]
    
    def add_tag(self, tag_id: UUID, tagged_by: str, tag_value: str = None, tag_reason: str = None):
        """
        Adiciona uma tag a esta entidade.
        
        Args:
            tag_id: ID da tag a ser adicionada
            tagged_by: Usuário que está aplicando a tag
            tag_value: Valor da tag, se aplicável
            tag_reason: Razão da aplicação da tag
        """
        from .tagged import Tagged
        
        tagged = Tagged(
            entity_id=self.entity_id,
            tag_id=tag_id,
            tagged_by=tagged_by,
            tag_value=tag_value,
            tag_reason=tag_reason
        )
        self.tags.append(tagged)
        return tagged
    
    def remove_tag(self, tag_id: UUID):
        """
        Remove uma tag desta entidade (marca como inativa).
        
        Args:
            tag_id: ID da tag a ser removida
        """
        for tagged in self.tags:
            if tagged.tag_id == tag_id and tagged.is_active:
                tagged.is_active = False
                break

