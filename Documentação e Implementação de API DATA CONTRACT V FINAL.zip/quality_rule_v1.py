"""
Quality Rule model.

Desenvolvido por Carlos Morais (carlos.morais@f1rst.com.br)
Julho 2025
"""

from sqlalchemy import Column, Integer, String, Text, DateTime, Boolean, JSON, Float
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from enum import Enum

from app.models.base import BaseModel


class RuleType(str, Enum):
    """Tipos de regras de qualidade."""
    COMPLETENESS = "completeness"
    ACCURACY = "accuracy"
    CONSISTENCY = "consistency"
    VALIDITY = "validity"
    UNIQUENESS = "uniqueness"
    TIMELINESS = "timeliness"


class QualityRule(BaseModel):
    """
    Modelo para regras de qualidade de dados.
    
    Define regras que serão aplicadas aos dados para
    garantir qualidade e conformidade.
    """
    __tablename__ = "quality_rules"

    rule_id = Column(Integer, primary_key=True, index=True)
    rule_name = Column(String(255), nullable=False, index=True)
    rule_description = Column(Text)
    rule_type = Column(String(50), nullable=False)
    
    # Configuração da regra
    target_table = Column(String(255))
    target_column = Column(String(255))
    rule_expression = Column(Text, nullable=False)
    threshold_value = Column(Float)
    
    # Status e configurações
    is_active = Column(Boolean, default=True)
    severity = Column(String(20), default="medium")  # low, medium, high, critical
    auto_fix = Column(Boolean, default=False)
    
    # Metadados
    tags = Column(JSON)
    metadata = Column(JSON)
    
    # Auditoria
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    created_by = Column(String(255), nullable=False)
    updated_by = Column(String(255))
    
    # Relacionamentos
    executions = relationship("QualityExecution", back_populates="rule", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<QualityRule(id={self.rule_id}, name='{self.rule_name}', type='{self.rule_type}')>"

