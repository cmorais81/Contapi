"""
Data Profiling model.

Desenvolvido por Carlos Morais - Julho 2025
"""

from sqlalchemy import Boolean, Column, DateTime, Enum, ForeignKey, String, Text, UUID
from sqlalchemy.orm import relationship
import enum

from app.models.base import BaseModel
from app.models.mixins import TimestampMixin


class ProfilingStatus(enum.Enum):
    """Status do profiling."""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class ProfilingType(enum.Enum):
    """Tipos de profiling."""
    FULL = "full"                    # Profiling completo
    INCREMENTAL = "incremental"      # Profiling incremental
    SAMPLE = "sample"               # Profiling de amostra
    SCHEMA_ONLY = "schema_only"     # Apenas estrutura
    STATISTICAL = "statistical"     # Apenas estatísticas
    PATTERN = "pattern"             # Análise de padrões


class DataProfiling(BaseModel, TimestampMixin):
    """
    Modelo para profiling de dados.
    
    Gerencia execuções de profiling de dados para análise
    de qualidade, estrutura, padrões e estatísticas dos dados.
    """
    
    __tablename__ = "data_profiling"
    
    # Identificação
    profiling_id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        server_default="gen_random_uuid()",
        comment="Identificador único do profiling"
    )
    
    profiling_name = Column(
        String(255),
        nullable=False,
        comment="Nome do profiling"
    )
    
    # Referências
    entity_id = Column(
        UUID(as_uuid=True),
        ForeignKey("entities.entity_id"),
        nullable=False,
        comment="Referência à entidade analisada"
    )
    
    contract_id = Column(
        UUID(as_uuid=True),
        ForeignKey("data_contracts.contract_id"),
        comment="Referência ao contrato de dados"
    )
    
    # Configuração do profiling
    profiling_type = Column(
        Enum(ProfilingType),
        nullable=False,
        default=ProfilingType.FULL,
        comment="Tipo de profiling"
    )
    
    sample_size = Column(
        String(20),
        comment="Tamanho da amostra (número ou percentual)"
    )
    
    sample_method = Column(
        String(50),
        comment="Método de amostragem (random, systematic, stratified)"
    )
    
    # Configurações de análise
    analyze_nulls = Column(
        Boolean,
        default=True,
        comment="Analisar valores nulos"
    )
    
    analyze_duplicates = Column(
        Boolean,
        default=True,
        comment="Analisar duplicatas"
    )
    
    analyze_patterns = Column(
        Boolean,
        default=True,
        comment="Analisar padrões de dados"
    )
    
    analyze_distributions = Column(
        Boolean,
        default=True,
        comment="Analisar distribuições estatísticas"
    )
    
    analyze_outliers = Column(
        Boolean,
        default=True,
        comment="Analisar outliers"
    )
    
    # Execução
    status = Column(
        Enum(ProfilingStatus),
        default=ProfilingStatus.PENDING,
        nullable=False,
        comment="Status da execução"
    )
    
    started_at = Column(
        DateTime,
        comment="Data/hora de início"
    )
    
    completed_at = Column(
        DateTime,
        comment="Data/hora de conclusão"
    )
    
    duration_seconds = Column(
        String(20),
        comment="Duração em segundos"
    )
    
    # Resultados básicos
    total_rows = Column(
        String(20),
        comment="Total de linhas analisadas"
    )
    
    total_columns = Column(
        String(10),
        comment="Total de colunas analisadas"
    )
    
    null_percentage = Column(
        String(10),
        comment="Percentual de valores nulos"
    )
    
    duplicate_percentage = Column(
        String(10),
        comment="Percentual de duplicatas"
    )
    
    # Resultados detalhados (JSON)
    column_statistics = Column(
        Text,
        comment="Estatísticas por coluna (JSON)"
    )
    
    data_patterns = Column(
        Text,
        comment="Padrões identificados (JSON)"
    )
    
    quality_issues = Column(
        Text,
        comment="Problemas de qualidade encontrados (JSON)"
    )
    
    recommendations = Column(
        Text,
        comment="Recomendações de melhoria (JSON)"
    )
    
    # Metadados de execução
    executed_by = Column(
        String(255),
        comment="Usuário que executou"
    )
    
    execution_environment = Column(
        String(100),
        comment="Ambiente de execução"
    )
    
    execution_config = Column(
        Text,
        comment="Configuração de execução (JSON)"
    )
    
    # Controle de qualidade
    quality_score = Column(
        String(10),
        comment="Score de qualidade geral (0.0-1.0)"
    )
    
    completeness_score = Column(
        String(10),
        comment="Score de completude"
    )
    
    consistency_score = Column(
        String(10),
        comment="Score de consistência"
    )
    
    accuracy_score = Column(
        String(10),
        comment="Score de acurácia"
    )
    
    # Relacionamentos
    entity = relationship(
        "Entity"
    )
    
    contract = relationship(
        "DataContract"
    )
    
    def __repr__(self) -> str:
        return f"<DataProfiling(id={self.profiling_id}, name='{self.profiling_name}', status={self.status.value})>"
    
    @property
    def is_completed(self) -> bool:
        """Verifica se o profiling foi concluído."""
        return self.status == ProfilingStatus.COMPLETED
    
    @property
    def is_running(self) -> bool:
        """Verifica se o profiling está em execução."""
        return self.status == ProfilingStatus.RUNNING
    
    @property
    def has_quality_issues(self) -> bool:
        """Verifica se foram encontrados problemas de qualidade."""
        issues = self.get_quality_issues()
        return len(issues) > 0
    
    def get_column_statistics(self) -> dict:
        """
        Retorna estatísticas por coluna.
        
        Returns:
            Dicionário com estatísticas por coluna
        """
        import json
        if not self.column_statistics:
            return {}
        try:
            return json.loads(self.column_statistics)
        except:
            return {}
    
    def get_data_patterns(self) -> dict:
        """
        Retorna padrões identificados.
        
        Returns:
            Dicionário com padrões de dados
        """
        import json
        if not self.data_patterns:
            return {}
        try:
            return json.loads(self.data_patterns)
        except:
            return {}
    
    def get_quality_issues(self) -> list:
        """
        Retorna problemas de qualidade encontrados.
        
        Returns:
            Lista de problemas de qualidade
        """
        import json
        if not self.quality_issues:
            return []
        try:
            return json.loads(self.quality_issues)
        except:
            return []
    
    def get_recommendations(self) -> list:
        """
        Retorna recomendações de melhoria.
        
        Returns:
            Lista de recomendações
        """
        import json
        if not self.recommendations:
            return []
        try:
            return json.loads(self.recommendations)
        except:
            return []
    
    def calculate_overall_quality_score(self) -> float:
        """
        Calcula score geral de qualidade.
        
        Returns:
            Score de qualidade de 0.0 a 1.0
        """
        scores = []
        
        if self.completeness_score:
            try:
                scores.append(float(self.completeness_score))
            except:
                pass
        
        if self.consistency_score:
            try:
                scores.append(float(self.consistency_score))
            except:
                pass
        
        if self.accuracy_score:
            try:
                scores.append(float(self.accuracy_score))
            except:
                pass
        
        if scores:
            return sum(scores) / len(scores)
        
        return 0.0
    
    def get_execution_summary(self) -> dict:
        """
        Retorna resumo da execução.
        
        Returns:
            Dicionário com resumo da execução
        """
        return {
            "profiling_id": str(self.profiling_id),
            "name": self.profiling_name,
            "type": self.profiling_type.value,
            "status": self.status.value,
            "duration_seconds": self.duration_seconds,
            "total_rows": self.total_rows,
            "total_columns": self.total_columns,
            "quality_score": self.quality_score,
            "issues_found": len(self.get_quality_issues()),
            "recommendations_count": len(self.get_recommendations())
        }

