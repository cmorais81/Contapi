"""
API v1 router configuration.
"""

from fastapi import APIRouter

from app.api.v1.endpoints import (
    contracts,
    quality,
    lineage,
    metrics,
    users,
    tags,
    governance,
    integrations,
    audit,
    admin
)

api_router = APIRouter()

# Include all endpoint routers
api_router.include_router(
    contracts.router,
    prefix="/contracts",
    tags=["contracts"]
)

api_router.include_router(
    quality.router,
    prefix="/quality",
    tags=["quality"]
)

api_router.include_router(
    lineage.router,
    prefix="/lineage",
    tags=["lineage"]
)

api_router.include_router(
    metrics.router,
    prefix="/metrics",
    tags=["metrics"]
)

api_router.include_router(
    users.router,
    prefix="/users",
    tags=["users"]
)

api_router.include_router(
    tags.router,
    prefix="/tags",
    tags=["tags"]
)

api_router.include_router(
    governance.router,
    prefix="/governance",
    tags=["governance"]
)

api_router.include_router(
    integrations.router,
    prefix="/integrations",
    tags=["integrations"]
)

api_router.include_router(
    audit.router,
    prefix="/audit",
    tags=["audit"]
)

api_router.include_router(
    admin.router,
    prefix="/admin",
    tags=["admin"]
)

