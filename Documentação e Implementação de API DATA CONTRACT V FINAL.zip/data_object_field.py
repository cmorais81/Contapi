"""
Data Object Field model.
"""

from sqlalchemy import Boolean, Column, ForeignKey, String, Text
from sqlalchemy.dialects.postgresql import UUID as PostgresUUID
from sqlalchemy.orm import relationship

from app.models.base import BaseModel


class DataObjectField(BaseModel):
    """
    Data Object Field model.
    
    Fields/columns within data objects.
    """

    __tablename__ = "data_object_fields"

    # Foreign key to data object
    data_object_id = Column(
        PostgresUUID(as_uuid=True),
        ForeignKey("data_objects.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
        doc="Reference to data object"
    )

    # Field definition
    field_name = Column(
        String(255),
        nullable=False,
        doc="Field name"
    )

    field_description = Column(
        Text,
        doc="Field description"
    )

    data_type = Column(
        String(100),
        nullable=False,
        doc="Data type: string, integer, decimal, boolean, date, timestamp"
    )

    # Constraints
    is_nullable = Column(
        Boolean,
        default=True,
        doc="Field allows null values"
    )

    is_primary_key = Column(
        Boolean,
        default=False,
        doc="Is primary key field"
    )

    is_foreign_key = Column(
        Boolean,
        default=False,
        doc="Is foreign key field"
    )

    # Validation
    max_length = Column(
        String(10),  # Using String to handle integer as text
        doc="Maximum length for string fields"
    )

    min_value = Column(
        String(50),  # Using String to handle numeric as text
        doc="Minimum value for numeric fields"
    )

    max_value = Column(
        String(50),  # Using String to handle numeric as text
        doc="Maximum value for numeric fields"
    )

    default_value = Column(
        Text,
        doc="Default value"
    )

    # Privacy and security
    is_pii = Column(
        Boolean,
        default=False,
        doc="Contains personally identifiable information"
    )

    masking_rule = Column(
        String(100),
        doc="Data masking rule"
    )

    # Relationships
    data_object = relationship(
        "DataObject",
        back_populates="fields"
    )

    def __repr__(self) -> str:
        return f"<DataObjectField(name={self.field_name}, type={self.data_type})>"

