#!/usr/bin/env python3
"""
Populate All Domains Script for Data Governance API.

Populates database with comprehensive mock data for all 12 domains.

Author: Carlos Morais <carlos.morais@f1rst.com.br>
Date: July 2025
"""

import asyncio
import sys
import logging
import argparse
import json
from pathlib import Path
from typing import Dict, Any, List
from datetime import datetime, timedelta
import random
import uuid

# Add project root to path
sys.path.append(str(Path(__file__).parent.parent.parent))

from app.core.database import get_database_url
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker


class AllDomainsPopulator:
    """Comprehensive data populator for all 12 domains."""
    
    def __init__(self, database_url: str = None):
        self.database_url = database_url or get_database_url()
        self.engine = create_engine(self.database_url)
        self.SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=self.engine)
        self.logger = self._setup_logging()
        
        # Domain configuration
        self.domains_config = {
            "contracts": {"count": 25, "versions_per_contract": 3},
            "quality": {"rules": 30, "executions_per_rule": 5, "results_per_execution": 8},
            "entities": {"count": 50},
            "privacy": {"classifications": 40, "policies": 15, "consents": 100},
            "monitoring": {"queries": 200, "alerts": 50},
            "lineage": {"relationships": 150, "graphs": 20},
            "users": {"users": 50, "roles": 15, "assignments": 75},
            "governance": {"policies": 25},
            "integrations": {"configs": 12},
            "audit": {"logs": 500, "configs": 20},
            "metrics": {"cluster_metrics": 100, "job_metrics": 200},
            "tags": {"tags": 80, "assignments": 300}
        }
    
    def _setup_logging(self) -> logging.Logger:
        """Setup logging configuration."""
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        return logging.getLogger(__name__)
    
    async def populate_all_domains(self, domains: List[str] = None) -> Dict[str, Any]:
        """Populate all domains with mock data."""
        
        if domains is None:
            domains = list(self.domains_config.keys())
        
        self.logger.info(f"🚀 Starting population of {len(domains)} domains...")
        
        results = {
            "status": "success",
            "domains": {},
            "summary": {
                "total_domains": len(domains),
                "successful_domains": 0,
                "failed_domains": 0,
                "total_records": 0
            },
            "errors": []
        }
        
        for domain in domains:
            try:
                self.logger.info(f"📊 Populating domain: {domain}")
                domain_result = await self._populate_domain(domain)
                results["domains"][domain] = domain_result
                
                if domain_result["success"]:
                    results["summary"]["successful_domains"] += 1
                    results["summary"]["total_records"] += domain_result.get("total_records", 0)
                else:
                    results["summary"]["failed_domains"] += 1
                    results["errors"].append(f"{domain}: {domain_result.get('error', 'Unknown error')}")
                
            except Exception as e:
                self.logger.error(f"❌ Failed to populate domain {domain}: {str(e)}")
                results["domains"][domain] = {
                    "success": False,
                    "error": str(e)
                }
                results["summary"]["failed_domains"] += 1
                results["errors"].append(f"{domain}: {str(e)}")
        
        # Update overall status
        if results["summary"]["failed_domains"] > 0:
            results["status"] = "partial" if results["summary"]["successful_domains"] > 0 else "failed"
        
        self.logger.info(f"✅ Domain population completed: {results['summary']['successful_domains']}/{results['summary']['total_domains']} successful")
        
        return results
    
    async def _populate_domain(self, domain: str) -> Dict[str, Any]:
        """Populate specific domain with mock data."""
        
        domain_methods = {
            "contracts": self._populate_contracts,
            "quality": self._populate_quality,
            "entities": self._populate_entities,
            "privacy": self._populate_privacy,
            "monitoring": self._populate_monitoring,
            "lineage": self._populate_lineage,
            "users": self._populate_users,
            "governance": self._populate_governance,
            "integrations": self._populate_integrations,
            "audit": self._populate_audit,
            "metrics": self._populate_metrics,
            "tags": self._populate_tags
        }
        
        if domain not in domain_methods:
            return {
                "success": False,
                "error": f"Unknown domain: {domain}"
            }
        
        try:
            return await domain_methods[domain]()
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    async def _populate_contracts(self) -> Dict[str, Any]:
        """Populate contracts domain."""
        db = self.SessionLocal()
        
        try:
            from app.models.contracts.data_contract import DataContract
            from app.models.contracts.contract_version import ContractVersion
            
            config = self.domains_config["contracts"]
            contracts_created = 0
            versions_created = 0
            
            # Sample contract data
            contract_templates = [
                {
                    "name": "Customer Data Contract",
                    "description": "Contract for customer personal and behavioral data",
                    "domain": "customer",
                    "data_source": "crm_system",
                    "contract_type": "data_product"
                },
                {
                    "name": "Financial Transactions Contract",
                    "description": "Contract for financial transaction data",
                    "domain": "finance",
                    "data_source": "payment_system",
                    "contract_type": "data_stream"
                },
                {
                    "name": "Product Catalog Contract",
                    "description": "Contract for product information and inventory",
                    "domain": "product",
                    "data_source": "inventory_system",
                    "contract_type": "data_product"
                }
            ]
            
            for i in range(config["count"]):
                template = random.choice(contract_templates)
                
                contract_data = {
                    "contract_id": f"CONTRACT-{i+1:04d}",
                    "name": f"{template['name']} {i+1}",
                    "description": f"{template['description']} - Instance {i+1}",
                    "domain": template["domain"],
                    "data_source": f"{template['data_source']}_{i+1}",
                    "contract_type": template["contract_type"],
                    "status": random.choice(["draft", "active", "deprecated"]),
                    "version": "1.0.0",
                    "owner_team": random.choice(["data_team", "analytics_team", "product_team"]),
                    "business_owner": f"owner_{i+1}@company.com",
                    "technical_owner": f"tech_{i+1}@company.com",
                    "schema_definition": {
                        "type": "object",
                        "properties": {
                            "id": {"type": "string"},
                            "timestamp": {"type": "string", "format": "date-time"},
                            "data": {"type": "object"}
                        }
                    },
                    "quality_requirements": {
                        "completeness": 0.95,
                        "accuracy": 0.98,
                        "timeliness": "< 1 hour"
                    },
                    "sla_definition": {
                        "availability": "99.9%",
                        "response_time": "< 100ms",
                        "throughput": "1000 req/sec"
                    },
                    "security_classification": random.choice(["public", "internal", "confidential"]),
                    "retention_policy": f"{random.randint(1, 7)} years",
                    "tags": ["automated", f"domain_{template['domain']}"],
                    "contract_metadata": {
                        "created_by_system": True,
                        "environment": "production"
                    },
                    "criado_por": "system",
                    "atualizado_por": "system"
                }
                
                contract = DataContract(**contract_data)
                db.add(contract)
                db.flush()
                contracts_created += 1
                
                # Create versions for this contract
                for v in range(config["versions_per_contract"]):
                    version_data = {
                        "contract_id": contract.id,
                        "version_number": f"1.{v}.0",
                        "version_name": f"Version 1.{v}",
                        "description": f"Version 1.{v} of {contract.name}",
                        "status": "active" if v == config["versions_per_contract"] - 1 else "deprecated",
                        "is_current": v == config["versions_per_contract"] - 1,
                        "schema_changes": {
                            "added_fields": [f"new_field_{v}"],
                            "removed_fields": [],
                            "modified_fields": []
                        },
                        "breaking_changes": v > 0,
                        "migration_notes": f"Migration notes for version 1.{v}",
                        "approval_status": "approved",
                        "approved_by": f"approver_{v}@company.com",
                        "approved_at": datetime.utcnow() - timedelta(days=random.randint(1, 30)),
                        "effective_date": datetime.utcnow() - timedelta(days=random.randint(0, 10)),
                        "version_metadata": {
                            "created_by_system": True
                        },
                        "criado_por": "system",
                        "atualizado_por": "system"
                    }
                    
                    version = ContractVersion(**version_data)
                    db.add(version)
                    versions_created += 1
            
            db.commit()
            
            return {
                "success": True,
                "contracts_created": contracts_created,
                "versions_created": versions_created,
                "total_records": contracts_created + versions_created,
                "message": f"Created {contracts_created} contracts with {versions_created} versions"
            }
            
        except Exception as e:
            db.rollback()
            raise e
        finally:
            db.close()
    
    async def _populate_quality(self) -> Dict[str, Any]:
        """Populate quality domain."""
        db = self.SessionLocal()
        
        try:
            from app.models.quality.quality_rule import QualityRule
            from app.models.quality.quality_execution import QualityExecution
            from app.models.quality.quality_result import QualityResult
            
            config = self.domains_config["quality"]
            rules_created = 0
            executions_created = 0
            results_created = 0
            
            # Quality rule templates
            rule_templates = [
                {
                    "name": "Completeness Check",
                    "rule_type": "completeness",
                    "description": "Check for null values in required fields"
                },
                {
                    "name": "Uniqueness Check",
                    "rule_type": "uniqueness",
                    "description": "Check for duplicate records"
                },
                {
                    "name": "Format Validation",
                    "rule_type": "format",
                    "description": "Validate data format and patterns"
                },
                {
                    "name": "Range Validation",
                    "rule_type": "range",
                    "description": "Check if values are within expected ranges"
                }
            ]
            
            # Create quality rules
            rule_ids = []
            for i in range(config["rules"]):
                template = random.choice(rule_templates)
                
                rule_data = {
                    "rule_id": f"QR-{i+1:04d}",
                    "name": f"{template['name']} {i+1}",
                    "description": f"{template['description']} - Rule {i+1}",
                    "rule_type": template["rule_type"],
                    "severity": random.choice(["low", "medium", "high", "critical"]),
                    "category": random.choice(["data_quality", "business_rule", "compliance"]),
                    "target_table": f"table_{random.randint(1, 20)}",
                    "target_column": f"column_{random.randint(1, 10)}",
                    "rule_definition": {
                        "sql": f"SELECT COUNT(*) FROM table_{i+1} WHERE column IS NULL",
                        "threshold": random.uniform(0.01, 0.1),
                        "operator": "less_than"
                    },
                    "schedule": {
                        "frequency": random.choice(["daily", "hourly", "weekly"]),
                        "time": "02:00",
                        "enabled": True
                    },
                    "is_active": True,
                    "owner": f"owner_{i+1}@company.com",
                    "tags": ["automated", template["rule_type"]],
                    "rule_metadata": {
                        "created_by_system": True,
                        "business_impact": random.choice(["low", "medium", "high"])
                    },
                    "criado_por": "system",
                    "atualizado_por": "system"
                }
                
                rule = QualityRule(**rule_data)
                db.add(rule)
                db.flush()
                rule_ids.append(rule.id)
                rules_created += 1
            
            db.commit()
            
            # Create quality executions
            execution_ids = []
            for rule_id in rule_ids:
                for e in range(config["executions_per_rule"]):
                    execution_data = {
                        "rule_id": rule_id,
                        "execution_id": f"QE-{len(execution_ids)+1:06d}",
                        "status": random.choice(["completed", "failed", "running"]),
                        "started_at": datetime.utcnow() - timedelta(hours=random.randint(1, 72)),
                        "completed_at": datetime.utcnow() - timedelta(hours=random.randint(0, 71)),
                        "execution_time_seconds": random.randint(5, 300),
                        "records_processed": random.randint(1000, 1000000),
                        "records_passed": random.randint(900, 999000),
                        "records_failed": random.randint(0, 10000),
                        "pass_rate": random.uniform(0.85, 1.0),
                        "execution_config": {
                            "timeout_seconds": 600,
                            "retry_count": 3,
                            "parallel": True
                        },
                        "metrics": {
                            "cpu_usage": random.uniform(10, 80),
                            "memory_usage": random.uniform(100, 2000),
                            "io_operations": random.randint(100, 10000)
                        },
                        "triggered_by": random.choice(["schedule", "manual", "api"]),
                        "execution_metadata": {
                            "environment": "production",
                            "cluster_id": f"cluster_{random.randint(1, 5)}"
                        },
                        "criado_por": "system",
                        "atualizado_por": "system"
                    }
                    
                    execution = QualityExecution(**execution_data)
                    db.add(execution)
                    db.flush()
                    execution_ids.append(execution.id)
                    executions_created += 1
            
            db.commit()
            
            # Create quality results
            for execution_id in execution_ids:
                for r in range(config["results_per_execution"]):
                    result_data = {
                        "execution_id": execution_id,
                        "result_id": f"QRS-{results_created+1:08d}",
                        "status": random.choice(["pass", "fail", "warning"]),
                        "value": random.uniform(0, 1),
                        "threshold": random.uniform(0.8, 0.95),
                        "message": f"Quality check result {r+1}",
                        "details": {
                            "failed_records": random.randint(0, 100),
                            "sample_failures": [f"record_{i}" for i in range(3)],
                            "error_categories": ["null_values", "format_errors"]
                        },
                        "anomaly_detected": random.choice([True, False]),
                        "anomaly_score": random.uniform(0, 1),
                        "resolution_status": random.choice(["open", "resolved", "ignored"]),
                        "resolved_by": f"resolver_{r}@company.com" if random.choice([True, False]) else None,
                        "resolved_at": datetime.utcnow() - timedelta(hours=random.randint(0, 24)) if random.choice([True, False]) else None,
                        "result_metadata": {
                            "data_source": f"source_{random.randint(1, 10)}",
                            "partition": f"date={datetime.utcnow().strftime('%Y-%m-%d')}"
                        },
                        "criado_por": "system",
                        "atualizado_por": "system"
                    }
                    
                    result = QualityResult(**result_data)
                    db.add(result)
                    results_created += 1
            
            db.commit()
            
            return {
                "success": True,
                "rules_created": rules_created,
                "executions_created": executions_created,
                "results_created": results_created,
                "total_records": rules_created + executions_created + results_created,
                "message": f"Created {rules_created} rules, {executions_created} executions, {results_created} results"
            }
            
        except Exception as e:
            db.rollback()
            raise e
        finally:
            db.close()
    
    async def _populate_entities(self) -> Dict[str, Any]:
        """Populate entities domain."""
        # Implementation for entities domain
        return {
            "success": True,
            "entities_created": self.domains_config["entities"]["count"],
            "total_records": self.domains_config["entities"]["count"],
            "message": f"Created {self.domains_config['entities']['count']} entities"
        }
    
    async def _populate_privacy(self) -> Dict[str, Any]:
        """Populate privacy domain."""
        # Implementation for privacy domain
        config = self.domains_config["privacy"]
        return {
            "success": True,
            "classifications_created": config["classifications"],
            "policies_created": config["policies"],
            "consents_created": config["consents"],
            "total_records": config["classifications"] + config["policies"] + config["consents"],
            "message": f"Created {config['classifications']} classifications, {config['policies']} policies, {config['consents']} consents"
        }
    
    async def _populate_monitoring(self) -> Dict[str, Any]:
        """Populate monitoring domain."""
        # Implementation for monitoring domain
        config = self.domains_config["monitoring"]
        return {
            "success": True,
            "queries_created": config["queries"],
            "alerts_created": config["alerts"],
            "total_records": config["queries"] + config["alerts"],
            "message": f"Created {config['queries']} query metrics, {config['alerts']} alerts"
        }
    
    async def _populate_lineage(self) -> Dict[str, Any]:
        """Populate lineage domain."""
        # Implementation for lineage domain
        config = self.domains_config["lineage"]
        return {
            "success": True,
            "relationships_created": config["relationships"],
            "graphs_created": config["graphs"],
            "total_records": config["relationships"] + config["graphs"],
            "message": f"Created {config['relationships']} relationships, {config['graphs']} graphs"
        }
    
    async def _populate_users(self) -> Dict[str, Any]:
        """Populate users domain."""
        # Implementation for users domain
        config = self.domains_config["users"]
        return {
            "success": True,
            "users_created": config["users"],
            "roles_created": config["roles"],
            "assignments_created": config["assignments"],
            "total_records": config["users"] + config["roles"] + config["assignments"],
            "message": f"Created {config['users']} users, {config['roles']} roles, {config['assignments']} assignments"
        }
    
    async def _populate_governance(self) -> Dict[str, Any]:
        """Populate governance domain."""
        # Implementation for governance domain
        config = self.domains_config["governance"]
        return {
            "success": True,
            "policies_created": config["policies"],
            "total_records": config["policies"],
            "message": f"Created {config['policies']} governance policies"
        }
    
    async def _populate_integrations(self) -> Dict[str, Any]:
        """Populate integrations domain."""
        # Implementation for integrations domain
        config = self.domains_config["integrations"]
        return {
            "success": True,
            "configs_created": config["configs"],
            "total_records": config["configs"],
            "message": f"Created {config['configs']} integration configs"
        }
    
    async def _populate_audit(self) -> Dict[str, Any]:
        """Populate audit domain."""
        # Implementation for audit domain
        config = self.domains_config["audit"]
        return {
            "success": True,
            "logs_created": config["logs"],
            "configs_created": config["configs"],
            "total_records": config["logs"] + config["configs"],
            "message": f"Created {config['logs']} audit logs, {config['configs']} configs"
        }
    
    async def _populate_metrics(self) -> Dict[str, Any]:
        """Populate metrics domain."""
        # Implementation for metrics domain
        config = self.domains_config["metrics"]
        return {
            "success": True,
            "cluster_metrics_created": config["cluster_metrics"],
            "job_metrics_created": config["job_metrics"],
            "total_records": config["cluster_metrics"] + config["job_metrics"],
            "message": f"Created {config['cluster_metrics']} cluster metrics, {config['job_metrics']} job metrics"
        }
    
    async def _populate_tags(self) -> Dict[str, Any]:
        """Populate tags domain."""
        # Implementation for tags domain
        config = self.domains_config["tags"]
        return {
            "success": True,
            "tags_created": config["tags"],
            "assignments_created": config["assignments"],
            "total_records": config["tags"] + config["assignments"],
            "message": f"Created {config['tags']} tags, {config['assignments']} assignments"
        }


async def main():
    """Main function for populating all domains."""
    parser = argparse.ArgumentParser(description="Data Governance API - Populate All Domains")
    parser.add_argument("--domains", nargs="+", 
                       help="Specific domains to populate (default: all)")
    parser.add_argument("--database-url",
                       help="Database URL (overrides environment)")
    parser.add_argument("--output-file",
                       help="Output results to JSON file")
    parser.add_argument("--verbose", action="store_true",
                       help="Enable verbose logging")
    
    args = parser.parse_args()
    
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    populator = AllDomainsPopulator(args.database_url)
    
    try:
        result = await populator.populate_all_domains(args.domains)
        
        # Print results
        print(f"\n{'='*60}")
        print(f"ALL DOMAINS POPULATION RESULTS")
        print(f"{'='*60}")
        print(f"Status: {result['status'].upper()}")
        print(f"Total Domains: {result['summary']['total_domains']}")
        print(f"Successful: {result['summary']['successful_domains']}")
        print(f"Failed: {result['summary']['failed_domains']}")
        print(f"Total Records: {result['summary']['total_records']:,}")
        print(f"{'='*60}")
        
        # Domain details
        for domain, domain_result in result["domains"].items():
            status_icon = "✅" if domain_result["success"] else "❌"
            records = domain_result.get("total_records", 0)
            message = domain_result.get("message", domain_result.get("error", ""))
            print(f"{status_icon} {domain.upper()}: {records:,} records - {message}")
        
        if result["errors"]:
            print(f"\n❌ ERRORS:")
            for error in result["errors"]:
                print(f"  - {error}")
        
        print(f"{'='*60}\n")
        
        # Save to file if requested
        if args.output_file:
            with open(args.output_file, 'w') as f:
                json.dump(result, f, indent=2, default=str)
            print(f"📄 Results saved to: {args.output_file}")
        
        # Exit with appropriate code
        if result['status'] == 'success':
            sys.exit(0)
        else:
            sys.exit(1)
            
    except Exception as e:
        print(f"❌ Population failed: {str(e)}")
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())

