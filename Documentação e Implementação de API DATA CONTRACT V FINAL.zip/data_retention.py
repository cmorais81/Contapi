"""
Data Retention Policy model.

Desenvolvido por Carlos Morais - Julho 2025
"""

from sqlalchemy import Boolean, Column, String, Text, UUID

from app.models.base import BaseModel
from app.models.mixins import TimestampMixin


class DataRetentionPolicy(BaseModel, TimestampMixin):
    """
    Modelo para políticas de retenção de dados.
    """
    
    __tablename__ = "data_retention_policies"
    
    policy_id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        server_default="gen_random_uuid()",
        comment="Identificador único da política"
    )
    
    policy_name = Column(
        String(255),
        nullable=False,
        comment="Nome da política"
    )
    
    description = Column(
        Text,
        comment="Descrição da política"
    )
    
    retention_period_days = Column(
        String(10),
        comment="Período de retenção em dias"
    )
    
    is_active = Column(
        Boolean,
        default=True,
        comment="Política ativa"
    )

