import logging
import time
import json
from typing import Dict, Any
from .base_provider import BaseProvider, AIRequest, AIResponse

class EnhancedMockProvider(BaseProvider):
    """
    Provedor Mock Aprimorado para simular respostas de IA.
    Útil para testes de integração e desenvolvimento sem custos de API.
    """
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.logger = logging.getLogger(self.__class__.__name__)
        self.model = config.get("model", "enhanced_mock_gpt_4")
        self.timeout = config.get("timeout", 1)
        self.logger.info(f"Enhanced Mock Provider configurado: modelo={self.model}, timeout={self.timeout}s")

    def is_available(self) -> bool:
        """Mock provider is always available."""
        return True

    def analyze(self, request: AIRequest) -> AIResponse:
        """
        Simula uma chamada de API e retorna uma resposta mock.
        """
        self.logger.info(f"Simulando análise para modelo {request.model} com Enhanced Mock Provider.")
        
        # Simula o tempo de resposta
        time.sleep(0.1) 

        # Conteúdo de resposta mock
        mock_content = f"""
# Análise Técnica do Programa COBOL {request.program_name}

## 1. Visão Geral
O programa **{request.program_name}** é um exemplo simples de COBOL.

## 2. Estrutura
- **PROGRAM-ID**: {request.program_name}
- **Divisões**: IDENTIFICATION, DATA, PROCEDURE.

## 3. Lógica de Negócio
A lógica principal é exibir duas mensagens de "Hello from" usando as variáveis WS-VAR-A (do copybook) e WS-VAR-B (local).

## 4. Copybooks
- **TESTCOPY**: Contém a variável WS-VAR-A.

## 5. Variáveis Chave
- **WS-VAR-A**: PIC X(10) VALUE 'COPYBOOK'.
- **WS-VAR-B**: PIC X(10) VALUE 'TEST'.

## 6. Observações
Análise simulada com sucesso usando o modelo **{request.model}** do provedor **Enhanced Mock**.
"""
        
        # Simula o uso de tokens
        tokens_used = len(request.prompt) // 4 + len(mock_content) // 4
        
        return AIResponse(
            success=True,
            content=mock_content,
            tokens_used=tokens_used,
            model=request.model,
            provider="enhanced_mock",
            error_message="",
            response_time=0.1
        )
