#!/usr/bin/env python3
"""
Meta-Analysis Module

Este módulo é responsável por gerar um relatório de meta-análise de todos os
documentos de análise gerados pela aplicação.
"""

import os
import logging
import json
from typing import List, Dict, Any

from src.core.config import ConfigManager
from src.core.prompt_manager_dual import DualPromptManager
from src.providers.enhanced_provider_manager import EnhancedProviderManager
from src.providers.base_provider import AIRequest

logger = logging.getLogger(__name__)

def find_analysis_files(output_dir: str) -> List[str]:
    """Encontra todos os arquivos de análise gerados no diretório de saída."""
    logger.info(f"Buscando arquivos de análise em: {os.path.abspath(output_dir)}")
    analysis_files = []
    if not os.path.isdir(output_dir):
        logger.error(f"O diretório de saída não existe: {output_dir}")
        return analysis_files

    for root, _, files in os.walk(output_dir):
        # Ignorar o diretório de meta_analise
        if os.path.basename(root) == "meta_analise":
            continue

        logger.debug(f"Verificando o diretório: {root}")
        for file in files:
            if file.endswith((".md", ".html", ".json")):
                file_path = os.path.join(root, file)
                logger.info(f"Arquivo de análise encontrado: {file_path}")
                analysis_files.append(file_path)
    return analysis_files

def read_analysis_file(file_path: str) -> str:
    """Lê o conteúdo de um arquivo de análise."""
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            return f.read()
    except Exception as e:
        logger.error(f"Erro ao ler o arquivo {file_path}: {e}")
        return ""

def generate_meta_analysis_report(output_dir: str, meta_output_dir: str, config_manager: ConfigManager) -> None:
    """Gera o relatório de meta-análise."""
    logger.info(f"Iniciando a geração do relatório de meta-análise do diretório: {output_dir}")
    
    analysis_files = find_analysis_files(output_dir)
    logger.info(f"Encontrados {len(analysis_files)} arquivos de análise para processar.")

    file_contents = []
    for file_path in analysis_files:
        content = read_analysis_file(file_path)
        if content:
            file_contents.append({"path": file_path, "content": content})

    if not file_contents:
        logger.warning("Nenhum arquivo de análise encontrado para gerar o relatório de meta-análise.")
        return

    # Preparar o prompt para a meta-análise
    prompt_manager = DualPromptManager(config_manager.config, "doc_legado_pro")
    provider_manager = EnhancedProviderManager(config_manager.config)

    # Criar um prompt que envia o conteúdo de todos os arquivos
    full_content = "\n\n---\n\n".join([f'Arquivo: {item["path"]}\n\n{item["content"]}' for item in file_contents])
    main_prompt = prompt_manager.generate_base_prompt(
        program_name="META-ANÁLISE",
        program_code=full_content
    )

    # Chamar o provedor de IA para gerar a meta-análise
    analysis_result = provider_manager.analyze_with_model(
        model_name="enhanced_mock",
        request=AIRequest(
            prompt=main_prompt,
            program_name="META-ANÁLISE",
            program_code=full_content,
            context={}
        )
    )

    meta_report_path = os.path.join(meta_output_dir, "relatorio_meta_analise.md")
    if analysis_result.success:
        with open(meta_report_path, "w", encoding="utf-8") as f:
            f.write("# Relatório de Meta-Análise\n\n")
            f.write(f"**Diretório de Análise:** `{output_dir}`\n")
            f.write(f"**Total de Arquivos Analisados:** {len(analysis_files)}\n\n")
            f.write("## Análise Consolidada\n\n")
            f.write(analysis_result.content)
        logger.info(f"Relatório de meta-análise gerado com sucesso em: {meta_report_path}")
    else:
        error_message = f"Falha ao gerar o relatório de meta-análise: {analysis_result.error_message}"
        logger.error(error_message)
        with open(meta_report_path, "w", encoding="utf-8") as f:
            f.write(f"# Erro na Geração do Relatório de Meta-Análise\n\n{error_message}")

