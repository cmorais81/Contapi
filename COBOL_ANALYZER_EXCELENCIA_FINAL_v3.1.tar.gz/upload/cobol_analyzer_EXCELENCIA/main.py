#!/usr/bin/env python3
"""
COBOL to Docs v1.0 - Sistema de Análise e Documentação de Programas COBOL
Autor: Carlos Morais
Data: Setembro 2025

Sistema completo para análise automatizada de programas COBOL com geração
de documentação técnica profissional usando IA.

FUNCIONALIDADE COMPLETA RESTAURADA:
- Processamento de múltiplos programas COBOL
- Suporte a múltiplos modelos de IA
- Análise de copybooks complementares
- Geração de relatórios comparativos
- Detecção automática de código COBOL
"""

import argparse
import logging
import os
import sys
import json
import time
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.core.config import ConfigManager
from src.core.prompt_manager_dual import DualPromptManager
from src.providers.enhanced_provider_manager import EnhancedProviderManager
from src.parsers.cobol_parser_original import COBOLParser, CobolProgram, CobolBook
from src.analyzers.enhanced_cobol_analyzer import EnhancedCOBOLAnalyzer
from src.analyzers.consolidated_analyzer import ConsolidatedAnalyzer
from src.generators.documentation_generator import DocumentationGenerator
from src.utils.html_generator import HTMLReportGenerator
from src.utils.cost_calculator import CostCalculator
from src.rag.rag_integration import RAGIntegration
from src.core.intelligent_model_selector import IntelligentModelSelector
from src.analytics.consolidated_analysis import (
    process_advanced_consolidated_analysis,
    process_detailed_business_analysis
)

def setup_logging(log_level: str = "INFO") -> None:
    """Configura o sistema de logging."""
    log_dir = "logs"
    os.makedirs(log_dir, exist_ok=True)
    
    log_file = os.path.join(log_dir, f"cobol_to_docs_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
    
    logging.basicConfig(
        level=getattr(logging, log_level.upper()),
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file, encoding='utf-8'),
            logging.StreamHandler(sys.stdout)
        ]
    )

def parse_models_argument(models_str: str) -> List[str]:
    """Parse do argumento models que pode ser string ou lista JSON."""
    if not models_str:
        return []
    
    models_str = models_str.strip()
    
    # Se começa com [ é uma lista JSON
    if models_str.startswith('['):
        try:
            models = json.loads(models_str)
            return models if isinstance(models, list) else [models]
        except json.JSONDecodeError:
            print(f"Erro: Formato JSON inválido para models: {models_str}")
            sys.exit(1)
    else:
        # String simples
        return [models_str]

def analyze_program_with_model(program: CobolProgram, books: List[CobolBook], model: str, output_dir: str, config_manager: ConfigManager, is_multi_model: bool, prompt_set: str, cost_calculator: CostCalculator, rag_integration=None, args=None) -> Dict[str, Any]:
    """Analisa um programa COBOL com um modelo específico."""
    logger = logging.getLogger(__name__)
    
    # Criar diretório específico do modelo se multi-modelo
    if is_multi_model:
        model_output_dir = os.path.join(output_dir, f"model_{model.replace('/', '_').replace('-', '_')}")
        os.makedirs(model_output_dir, exist_ok=True)
    else:
        model_output_dir = output_dir
    
    try:
        # Inicializar componentes específicos para o modelo
        prompt_manager = DualPromptManager(config_manager.config, prompt_set)
        provider_manager = EnhancedProviderManager(config_manager.config)
        doc_generator = DocumentationGenerator(model_output_dir)
        
        # Análise com IA (passando RAG integration)
        # Inicializar analisador
        analyzer = EnhancedCOBOLAnalyzer(provider_manager, prompt_manager, rag_integration)
    
        # Remoção de comentários se solicitado ou se há muitos comentários
        if args:
            from src.utils.cobol_preprocessor import COBOLPreprocessor
            preprocessor = COBOLPreprocessor()
            
            has_many_comments = preprocessor.has_comments(program.content)
            logger.info(f"Verificando comentários em {program.name}: no_comments={getattr(args, 'no_comments', False)}, has_many_comments={has_many_comments}")
            
            if hasattr(args, 'no_comments') and (args.no_comments or has_many_comments):
                if args.no_comments:
                    logger.info(f"Remoção de comentários solicitada para {program.name}")
                else:
                    logger.info(f"Muitos comentários detectados em {program.name} - removendo para análise focada")
                
                original_content = program.content
                program.content, removed_comments = preprocessor.remove_comments(program.content)
                logger.info(f"Removidos {removed_comments} comentários de {program.name}")
            else:
                logger.info(f"Mantendo comentários em {program.name}")
        
        start_time = time.time()
        
        # Log do provider que será usado
        logger.info(f"*** PROVIDER SELECIONADO: {model} ***")
        logger.info(f"Iniciando análise de {program.name} com provider {model}")
        
        analysis_result = analyzer.analyze_program(program, model)
        analysis_time = time.time() - start_time
        
        # Log do provider efetivamente usado
        provider_usado = getattr(analysis_result, 'provider_used', model)
        logger.info(f"*** ANÁLISE CONCLUÍDA COM PROVIDER: {provider_usado} ***")
        
        if not analysis_result.success:
            error_msg = f"ERRO na análise de {program.name} com modelo {model}: {analysis_result.error_message}"
            logger.error(error_msg)
            print(f"\n❌ {error_msg}")
            print(f"   Programa: {program.name}")
            print(f"   Modelo solicitado: {model}")
            print(f"   Tempo decorrido: {analysis_time:.2f}s")
            print(f"   Detalhes do erro: {analysis_result.error_message}")
            return {
                'success': False,
                'program_name': program.name,
                'model': model,
                'error': analysis_result.error_message,
                'tokens_used': 0,
                'analysis_time': analysis_time,
                'output_dir': model_output_dir
            }
        
        # Calcular custos
        cost_info = cost_calculator.tokens_analytics(
            {'usage': [{'total_tokens': analysis_result.tokens_used}]},
            analysis_result.model_used
        )
        
        # Gerar documentação
        from src.providers.base_provider import AIResponse
        
        # Obter prompts utilizados do prompt_manager
        prompts_used = {
            'system_prompt': prompt_manager.get_system_prompt(),
            'original_prompt': getattr(analysis_result, 'original_prompt', 'Prompt gerado dinamicamente'),
            'main_prompt': getattr(analysis_result, 'prompt_used', 'Prompt principal não disponível')
        }
        
        ai_response = AIResponse(
            success=True,
            content=analysis_result.content,
            tokens_used=analysis_result.tokens_used,
            model=analysis_result.model_used,
            provider=getattr(analysis_result, 'provider_used', 'enhanced_mock'),
            prompts_used=prompts_used,
            response_time=analysis_time
        )
        
        doc_result = doc_generator.generate_program_documentation(program, ai_response)
        
        logger.info(f"Análise de {program.name} com {model} bem-sucedida.")
        logger.info(f"Tokens utilizados: {analysis_result.tokens_used:,}")
        logger.info(f"Custo: ${cost_info['cost']:.4f}")
        logger.info(f"Modelo utilizado: {analysis_result.model_used}")
        
        # Auto-learning: Adicionar análise bem-sucedida à base de conhecimento
        if rag_integration and hasattr(rag_integration, 'add_program_analysis_to_knowledge_base'):
            try:
                rag_integration.add_program_analysis_to_knowledge_base(
                    program.name,
                    analysis_result.content,
                    program.content
                )
                logger.info(f"Auto-learning: Conhecimento do programa {program.name} adicionado à base RAG")
            except Exception as e:
                logger.warning(f"Auto-learning falhou para {program.name}: {e}")
        
        return {
            'success': True,
            'program_name': program.name,
            'model': model,
            'tokens_used': analysis_result.tokens_used,
            'analysis_time': analysis_time,
            'output_dir': model_output_dir,
            'files_generated': [doc_result] if doc_result else [],
            'response': analysis_result
        }
        
    except Exception as e:
        logger.error(f"Erro na análise de {program.name} com modelo {model}: {str(e)}")
        return {
            'success': False,
            'program_name': program.name,
            'model': model,
            'error': str(e),
            'tokens_used': 0,
            'analysis_time': 0,
            'output_dir': model_output_dir
        }

def generate_comparative_report(programs: List[CobolProgram], all_results: List[Dict[str, Any]], output_dir: str) -> None:
    """Gera relatório comparativo entre modelos."""
    logger = logging.getLogger(__name__)
    
    try:
        report_path = os.path.join(output_dir, "relatorio_comparativo_modelos.md")
        
        # Agrupar resultados por modelo
        models_used = list(set(r['model'] for r in all_results))
        results_by_model = {model: [r for r in all_results if r['model'] == model] for model in models_used}
        
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write("# Relatório Comparativo de Modelos\n\n")
            f.write(f"**Data:** {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}\n")
            f.write(f"**Programas Analisados:** {len(programs)}\n")
            f.write(f"**Modelos Utilizados:** {len(models_used)}\n\n")
            
            # Resumo geral
            f.write("## Resumo Geral\n\n")
            f.write("| Modelo | Sucessos | Falhas | Taxa de Sucesso | Tokens Médios |\n")
            f.write("|--------|----------|--------|-----------------|---------------|\n")
            
            for model in models_used:
                model_results = results_by_model[model]
                successes = sum(1 for r in model_results if r['success'])
                failures = len(model_results) - successes
                success_rate = (successes / len(model_results)) * 100 if model_results else 0
                avg_tokens = sum(r.get('tokens_used', 0) for r in model_results if r['success']) / max(successes, 1)
                
                f.write(f"| {model} | {successes} | {failures} | {success_rate:.1f}% | {avg_tokens:.0f} |\n")
            
            f.write("\n")
            
            # Detalhes por programa
            f.write("## Detalhes por Programa\n\n")
            
            for program in programs:
                f.write(f"### {program.name}\n\n")
                
                program_results = [r for r in all_results if r.get('program_name') == program.name]
                
                if program_results:
                    f.write("| Modelo | Status | Tokens | Qualidade | Diretório |\n")
                    f.write("|--------|--------|--------|-----------|----------|\n")
                    
                    for result in program_results:
                        status = "Sucesso" if result['success'] else "Falha"
                        tokens = result.get('tokens_used', 0)
                        quality = "Alta" if tokens > 2000 else "Média" if tokens > 1000 else "Baixa"
                        output_dir_name = os.path.basename(result['output_dir'])
                        
                        f.write(f"| {result['model']} | {status} | {tokens} | {quality} | {output_dir_name} |\n")
                    
                    f.write("\n")
                else:
                    f.write("Nenhum resultado encontrado para este programa.\n\n")
            
            # Recomendações
            f.write("## Recomendações\n\n")
            
            # Encontrar melhor modelo por taxa de sucesso
            best_model = max(models_used, key=lambda m: sum(1 for r in results_by_model[m] if r['success']) / len(results_by_model[m]))
            f.write(f"**Modelo Recomendado:** {best_model} (melhor taxa de sucesso)\n\n")
            
            # Encontrar modelo com mais tokens em média
            highest_tokens_model = max(models_used, key=lambda m: sum(r.get('tokens_used', 0) for r in results_by_model[m] if r['success']) / max(sum(1 for r in results_by_model[m] if r['success']), 1))
            f.write(f"**Modelo Mais Detalhado:** {highest_tokens_model} (maior média de tokens)\n\n")
            
            f.write("### Uso Recomendado por Cenário\n\n")
            f.write("- **Análise Rápida:** Use o modelo com melhor taxa de sucesso\n")
            f.write("- **Análise Detalhada:** Use o modelo com maior média de tokens\n")
            f.write("- **Análise Crítica:** Execute com múltiplos modelos e compare resultados\n")
            f.write("- **Produção:** Use o modelo mais estável baseado nas estatísticas\n\n")
            
            f.write("---\n")
            f.write("**Relatório gerado automaticamente pelo COBOL to Docs v1.1**\n")
        
        logger.info(f"Relatório comparativo gerado: {report_path}")
        
    except Exception as e:
        logger.error(f"Erro ao gerar relatório comparativo: {e}")

def get_models_from_providers(config_manager: ConfigManager) -> List[str]:
    """Obtém lista de modelos dos providers configurados."""
    models = []
    providers_config = config_manager.config.get('providers', {})
    
    # Iterar pelos providers habilitados
    for provider_name, provider_config in providers_config.items():
        if provider_config.get('enabled', False):
            provider_models = provider_config.get('models', {})
            
            # Adicionar modelos do provider
            for model_key, model_config in provider_models.items():
                model_name = model_config.get('name')
                if model_name:
                    models.append(model_name)
    
    # Se nenhum modelo encontrado, usar fallback
    if not models:
        logger = logging.getLogger(__name__)
        logger.warning("Nenhum modelo encontrado nos providers, usando fallback")
        models = ['enhanced_mock']  # Fallback seguro
    
    return models

def process_cobol_files(args, config_manager: ConfigManager, cost_calculator: CostCalculator, rag_integration) -> None:
    """Processa arquivos COBOL com funcionalidade completa restaurada."""
    logger = logging.getLogger(__name__)
    
    # Inicializar seletor inteligente de modelos
    model_selector = IntelligentModelSelector()
    
    # Determinar modelos a usar
    if hasattr(args, 'models') and args.models:
        models = parse_models_argument(args.models)
        logger.info(f"Modelos especificados pelo usuário: {models}")
    else:
        # Obter modelos dos providers configurados
        models = ["enhanced_mock"]
        logger.info(f"Modelos obtidos dos providers: {models}")
    
    # Inicializar parser
    parser = COBOLParser()
    
    # Verificar modo de operação
    if args.consolidado:
        logger.info("=== MODO ANÁLISE CONSOLIDADA SISTÊMICA ===")
        process_consolidated_analysis(args, config_manager, cost_calculator, parser, models)
        return
    
    if args.relatorio_unico:
        logger.info("=== MODO RELATÓRIO ÚNICO CONSOLIDADO ===")
        process_consolidated_report(args, config_manager, cost_calculator, parser, models)
        return
    
    # Verificar se deve usar análise especializada
    if args.analise_especialista or args.procedure_detalhada or args.modernizacao:
        logger.info("=== MODO ANÁLISE ESPECIALIZADA ===")
        process_expert_analysis(args, config_manager, cost_calculator, parser, models)
        return
    
    # Verificar se deve usar a análise avançada
    if args.advanced:
        logger.info("=== MODO ANÁLISE AVANÇADA ===")
        process_advanced_analysis(args, config_manager, cost_calculator, parser, models)
        return

    # Modo padrão: análise individual
    logger.info("=== MODO ANÁLISE INDIVIDUAL ===")
    
    # Carregar programas COBOL
    logger.info(f"Carregando programas de: {args.fontes}")
    programs, _ = parser.parse_file(args.fontes)
    logger.info(f"Encontrados {len(programs)} programas para análise.")
    
    # Carregar copybooks se especificado
    books = []
    if args.books:
        logger.info(f"Carregando copybooks de: {args.books}")
        _, books_result = parser.parse_file(args.books)
        books = books_result
        logger.info(f"Encontrados {len(books)} copybooks.")
    
    # Criar diretório de saída
    os.makedirs(args.output, exist_ok=True)
    
    # Processar cada programa com cada modelo
    all_results = []
    total_start_time = time.time()
    
    is_multi_model = len(models) > 1
    
    for program in programs:
        for model in models:
            result = analyze_program_with_model(
                program, books, model, args.output, config_manager, is_multi_model, args.prompt_set, cost_calculator, rag_integration, args
            )
            all_results.append(result)
    
    # Gerar relatório comparativo se múltiplos modelos
    if is_multi_model:
        generate_comparative_report(programs, all_results, args.output)
    
    # Resumo final
    total_time = time.time() - total_start_time
    successful_analyses = sum(1 for r in all_results if r['success'])
    total_analyses = len(all_results)
    success_rate = (successful_analyses / total_analyses) * 100 if total_analyses > 0 else 0
    total_tokens = sum(r.get('tokens_used', 0) for r in all_results)
    
    # Calcular custo total a partir do cost_calculator
    total_cost = cost_calculator.get_cost_summary().get('total_cost', 0.0)
    
    # Obter modelos que tiveram sucesso
    successful_models = sorted(list(set(r['model'] for r in all_results if r['success'])))
    
    # Estatísticas finais para o usuário
    print("=" * 60)
    print("PROCESSAMENTO CONCLUÍDO")
    print(f"Programas processados: {len(programs)}")
    print(f"Modelos utilizados: {len(successful_models)} ({', '.join(successful_models)})")
    print(f"Análises bem-sucedidas: {successful_analyses}/{total_analyses}")
    print(f"Taxa de sucesso geral: {success_rate:.1f}%")
    print(f"Total de tokens utilizados: {total_tokens:,}")
    print(f"Custo total: ${total_cost:.4f}")
    print(f"Tempo total de processamento: {total_time:.2f}s")
    print(f"Documentação gerada em: {args.output}")
    print(f"Relatório de custos: {os.path.join(args.output, 'relatorio_custos.txt')}")
    if is_multi_model:
        print(f"Relatório comparativo: {os.path.join(args.output, 'relatorio_comparativo_modelos.md')}")

    # Gerar relatório de custos
    cost_report = cost_calculator.format_cost_report()
    cost_report_file = os.path.join(args.output, "relatorio_custos.txt")
    with open(cost_report_file, 'w', encoding='utf-8') as f:
        f.write(cost_report)
    
    # Gerar HTML/PDF se solicitado
    if args.pdf:
        print("\nGerando relatórios HTML/PDF...")
        generate_html_reports(args.output, programs, all_results, is_multi_model)

def main():
    """Função principal que orquestra a análise."""
    parser = argparse.ArgumentParser(description="COBOL to Docs - Análise e Documentação de COBOL com IA")

    # Argumentos principais
    parser.add_argument("--fontes", required=False, help="Arquivo com a lista de programas COBOL a serem analisados.")
    parser.add_argument("--output", default="output", help="Diretório de saída para a documentação gerada.")
    parser.add_argument("--books", help="Arquivo com a lista de copybooks a serem incluídos na análise.")
    parser.add_argument("--config", default="config/config.yaml", help="Caminho para o arquivo de configuração YAML.")
    parser.add_argument("--models", help="Modelos de IA a serem usados (string ou lista JSON). Ex: 'gpt-4.1-mini' ou '[\"gpt-4.1-mini\", \"gemini-2.5-flash\"]'")
    parser.add_argument("--prompt_set", default="doc_legado_pro", help="Conjunto de prompts a ser usado (ex: original, doc_legado_pro)")
    parser.add_argument("--log_level", default="INFO", help="Nível de log (DEBUG, INFO, WARNING, ERROR)")
    parser.add_argument("--pdf", action="store_true", help="Gerar relatórios em formato PDF (além de Markdown e HTML)")
    parser.add_argument('--no-comments', action='store_true', help='Remove comentários do código antes da análise')

    # Argumentos para modos de análise avançados
    parser.add_argument("--consolidado", action="store_true", help="Executa a análise consolidada de todos os programas.")
    parser.add_argument("--relatorio_unico", action="store_true", help="Gera um relatório único consolidado para todo o sistema.")
    parser.add_argument("--analise_especialista", action="store_true", help="Executa análise técnica profunda com prompts de especialista.")
    parser.add_argument("--procedure_detalhada", action="store_true", help="Gera análise detalhada da PROCEDURE DIVISION.")
    parser.add_argument("--modernizacao", action="store_true", help="Gera recomendações de modernização e refatoração.")
    parser.add_argument("--advanced", action="store_true", help='Executar análise avançada com relatório consolidado HTML profissional')
    
    parser.add_argument(
        "--rel_analise",
        action="store_true",
        help="Gera um relatório de meta-análise de todos os documentos gerados."
    )

    args = parser.parse_args()
    
    # Configurar logging
    setup_logging(args.log_level)

    # Instanciar o ConfigManager
    config_manager = ConfigManager(args.config)

    # Chamar a função de meta-análise se o argumento for fornecido
    if args.rel_analise:
        from src.analytics.meta_analysis import generate_meta_analysis_report
        logger = logging.getLogger(__name__)
        logger.info("Iniciando a geração do relatório de meta-análise.")
        meta_output_dir = os.path.join(args.output, "meta_analise")
        os.makedirs(meta_output_dir, exist_ok=True)
        generate_meta_analysis_report(args.output, meta_output_dir, config_manager)
        logger.info("Relatório de meta-análise gerado.")
        # Encerrar o programa após gerar o relatório de meta-análise
        sys.exit(0)

    logger = logging.getLogger(__name__)
    
    try:
        # Inicializar calculadora de custos
        cost_calculator = CostCalculator()
        
        # Inicializar RAG Integration
        rag_integration = RAGIntegration(config_manager.config.get('rag', {}))
        
        # Processar arquivos COBOL
        process_cobol_files(args, config_manager, cost_calculator, rag_integration)
        
    except Exception as e:
        logger.critical(f"Erro fatal na execução: {e}", exc_info=True)
        sys.exit(1)

if __name__ == "__main__":
    main()

