"""
OpenAI Provider - COBOL AI Engine v14.0
Provedor para integração com OpenAI GPT-4
"""

import os
import json
import logging
import requests
from typing import Dict, Any, Optional
from .base_provider import BaseLLMProvider

class OpenAIProvider(BaseLLMProvider):
    """Provedor para OpenAI GPT-4"""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.api_key = config.get('api_key') or os.getenv('OPENAI_API_KEY')
        self.base_url = config.get('base_url', 'https://api.openai.com/v1')
        self.headers = {
            'Authorization': f'Bearer {self.api_key}',
            'Content-Type': 'application/json'
        }
        
    def is_available(self) -> bool:
        """Verifica se o provedor está disponível"""
        if not self.api_key:
            self.logger.warning("OpenAI API key não configurada")
            return False
        
        try:
            # Teste simples de conectividade
            response = requests.get(
                f"{self.base_url}/models",
                headers=self.headers,
                timeout=10
            )
            return response.status_code == 200
        except Exception as e:
            self.logger.warning(f"OpenAI não disponível: {e}")
            return False
    
    def generate_response(self, prompt: str, context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Gera resposta usando OpenAI GPT-4"""
        
        if not self.is_available():
            return self.format_error_response(Exception("OpenAI não disponível"))
        
        try:
            # Preparar payload
            payload = {
                "model": self.model,
                "messages": [
                    {
                        "role": "system",
                        "content": "Você é um especialista em análise de código COBOL com mais de 20 anos de experiência em sistemas bancários e financeiros."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                "temperature": self.temperature,
                "max_tokens": self.max_tokens
            }
            
            # Fazer requisição
            response = requests.post(
                f"{self.base_url}/chat/completions",
                headers=self.headers,
                json=payload,
                timeout=self.timeout
            )
            
            if response.status_code == 200:
                data = response.json()
                
                return {
                    'response': data['choices'][0]['message']['content'],
                    'tokens_used': data.get('usage', {}).get('total_tokens', 0),
                    'success': True,
                    'provider': 'OpenAI',
                    'model': self.model
                }
            else:
                error_msg = f"OpenAI API erro {response.status_code}: {response.text}"
                return self.format_error_response(Exception(error_msg))
                
        except requests.exceptions.Timeout:
            return self.format_error_response(Exception("Timeout na requisição OpenAI"))
        except requests.exceptions.RequestException as e:
            return self.format_error_response(Exception(f"Erro de rede OpenAI: {e}"))
        except Exception as e:
            return self.format_error_response(e)
    
    def get_provider_info(self) -> Dict[str, Any]:
        """Retorna informações sobre o provedor OpenAI"""
        info = super().get_provider_info()
        info.update({
            'provider_type': 'OpenAI',
            'api_available': self.is_available(),
            'base_url': self.base_url
        })
        return info
