"""
Provider Manager - COBOL AI Engine v14.0
Gerenciador de múltiplos provedores LLM com fallback
"""

import logging
from typing import Dict, Any, List, Optional
from .base_provider import BaseLLMProvider
from .openai_provider import OpenAIProvider
from .copilot_provider import CopilotProvider
from .luzia_provider import LuziaProvider
from .enhanced_mock_provider import EnhancedMockProvider

class ProviderManager:
    """Gerenciador de múltiplos provedores LLM"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Configurações gerais
        self.primary_provider = config.get('primary_provider', 'enhanced_mock')
        self.fallback_providers = config.get('fallback_providers', ['enhanced_mock'])
        
        # Inicializar provedores
        self.providers = {}
        self._initialize_providers()
        
    def _initialize_providers(self):
        """Inicializa todos os provedores configurados"""
        
        providers_config = self.config.get('providers', {})
        
        # Mapeamento de nomes para classes
        provider_classes = {
            'openai': OpenAIProvider,
            'copilot': CopilotProvider,
            'luzia': LuziaProvider,
            'enhanced_mock': EnhancedMockProvider
        }
        
        # Inicializar cada provedor configurado
        for provider_name, provider_config in providers_config.items():
            if provider_name in provider_classes and provider_config.get('enabled', False):
                try:
                    provider_class = provider_classes[provider_name]
                    provider_instance = provider_class(provider_config)
                    self.providers[provider_name] = provider_instance
                    self.logger.info(f"Provedor {provider_name} inicializado")
                except Exception as e:
                    self.logger.error(f"Erro ao inicializar provedor {provider_name}: {e}")
    
    def get_available_providers(self) -> List[str]:
        """Retorna lista de provedores disponíveis"""
        available = []
        for name, provider in self.providers.items():
            if provider.is_available():
                available.append(name)
        return available
    
    def get_provider(self, provider_name: str) -> Optional[BaseLLMProvider]:
        """Retorna um provedor específico"""
        return self.providers.get(provider_name)
    
    def generate_response(self, prompt: str, context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Gera resposta usando o provedor primário com fallback automático
        """
        
        # Lista de provedores para tentar (primário + fallbacks)
        providers_to_try = [self.primary_provider] + self.fallback_providers
        
        # Remover duplicatas mantendo ordem
        providers_to_try = list(dict.fromkeys(providers_to_try))
        
        last_error = None
        
        for provider_name in providers_to_try:
            provider = self.providers.get(provider_name)
            
            if not provider:
                self.logger.warning(f"Provedor {provider_name} não encontrado")
                continue
            
            if not provider.is_available():
                self.logger.warning(f"Provedor {provider_name} não disponível")
                continue
            
            try:
                self.logger.info(f"Tentando provedor {provider_name}")
                response = provider.generate_response(prompt, context)
                
                if response.get('success', False):
                    self.logger.info(f"Resposta gerada com sucesso usando {provider_name}")
                    response['provider_used'] = provider_name
                    return response
                else:
                    self.logger.warning(f"Provedor {provider_name} retornou erro: {response.get('error')}")
                    last_error = response.get('error', 'Erro desconhecido')
                    
            except Exception as e:
                self.logger.error(f"Erro ao usar provedor {provider_name}: {e}")
                last_error = str(e)
                continue
        
        # Se chegou aqui, todos os provedores falharam
        return {
            'response': f"Todos os provedores falharam. Último erro: {last_error}",
            'tokens_used': 0,
            'success': False,
            'error': f"Falha em todos os provedores. Último erro: {last_error}",
            'provider_used': 'none'
        }
    
    def get_provider_status(self) -> Dict[str, Any]:
        """Retorna status de todos os provedores"""
        status = {}
        
        for name, provider in self.providers.items():
            try:
                info = provider.get_provider_info()
                info['available'] = provider.is_available()
                status[name] = info
            except Exception as e:
                status[name] = {
                    'name': name,
                    'available': False,
                    'error': str(e)
                }
        
        return {
            'primary_provider': self.primary_provider,
            'fallback_providers': self.fallback_providers,
            'available_providers': self.get_available_providers(),
            'providers': status
        }
    
    def test_all_providers(self) -> Dict[str, Any]:
        """Testa todos os provedores com um prompt simples"""
        test_prompt = "Teste de conectividade. Responda apenas 'OK'."
        results = {}
        
        for name, provider in self.providers.items():
            try:
                start_time = time.time()
                response = provider.generate_response(test_prompt)
                end_time = time.time()
                
                results[name] = {
                    'success': response.get('success', False),
                    'response_time': end_time - start_time,
                    'tokens_used': response.get('tokens_used', 0),
                    'error': response.get('error')
                }
            except Exception as e:
                results[name] = {
                    'success': False,
                    'response_time': 0,
                    'tokens_used': 0,
                    'error': str(e)
                }
        
        return results
