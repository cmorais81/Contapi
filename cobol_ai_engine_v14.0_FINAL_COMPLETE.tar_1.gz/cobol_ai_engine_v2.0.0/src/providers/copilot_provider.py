"""
GitHub Copilot Provider - COBOL AI Engine v14.0
Provedor para integração com GitHub Copilot
"""

import os
import json
import logging
import requests
from typing import Dict, Any, Optional
from .base_provider import BaseLLMProvider

class CopilotProvider(BaseLLMProvider):
    """Provedor para GitHub Copilot"""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.api_key = config.get('api_key') or os.getenv('GITHUB_TOKEN')
        self.base_url = config.get('base_url', 'https://api.githubcopilot.com/chat/completions')
        self.headers = {
            'Authorization': f'Bearer {self.api_key}',
            'Content-Type': 'application/json',
            'Editor-Version': 'vscode/1.83.0',
            'Editor-Plugin-Version': 'copilot-chat/0.8.0',
            'User-Agent': 'GitHubCopilotChat/0.8.0'
        }
        
    def is_available(self) -> bool:
        """Verifica se o provedor está disponível"""
        if not self.api_key:
            self.logger.warning("GitHub token não configurado")
            return False
        
        try:
            # Teste simples de conectividade
            test_payload = {
                "model": "gpt-4",
                "messages": [{"role": "user", "content": "test"}],
                "max_tokens": 1
            }
            
            response = requests.post(
                self.base_url,
                headers=self.headers,
                json=test_payload,
                timeout=10
            )
            return response.status_code in [200, 400]  # 400 pode ser esperado para teste
        except Exception as e:
            self.logger.warning(f"Copilot não disponível: {e}")
            return False
    
    def generate_response(self, prompt: str, context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Gera resposta usando GitHub Copilot"""
        
        if not self.is_available():
            return self.format_error_response(Exception("GitHub Copilot não disponível"))
        
        try:
            # Preparar payload
            payload = {
                "model": self.model,
                "messages": [
                    {
                        "role": "system",
                        "content": "Você é um especialista em análise de código COBOL com foco em sistemas bancários e financeiros. Forneça análises detalhadas e precisas."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                "temperature": self.temperature,
                "max_tokens": self.max_tokens,
                "stream": False
            }
            
            # Fazer requisição
            response = requests.post(
                self.base_url,
                headers=self.headers,
                json=payload,
                timeout=self.timeout
            )
            
            if response.status_code == 200:
                data = response.json()
                
                return {
                    'response': data['choices'][0]['message']['content'],
                    'tokens_used': data.get('usage', {}).get('total_tokens', 0),
                    'success': True,
                    'provider': 'GitHub Copilot',
                    'model': self.model
                }
            else:
                error_msg = f"Copilot API erro {response.status_code}: {response.text}"
                return self.format_error_response(Exception(error_msg))
                
        except requests.exceptions.Timeout:
            return self.format_error_response(Exception("Timeout na requisição Copilot"))
        except requests.exceptions.RequestException as e:
            return self.format_error_response(Exception(f"Erro de rede Copilot: {e}"))
        except Exception as e:
            return self.format_error_response(e)
    
    def get_provider_info(self) -> Dict[str, Any]:
        """Retorna informações sobre o provedor Copilot"""
        info = super().get_provider_info()
        info.update({
            'provider_type': 'GitHub Copilot',
            'api_available': self.is_available(),
            'base_url': self.base_url
        })
        return info
