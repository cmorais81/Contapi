"""
Base Provider - COBOL AI Engine v14.0
Classe base para todos os provedores de LLM
"""

import logging
from abc import ABC, abstractmethod
from typing import Dict, Any, Optional

class BaseLLMProvider(ABC):
    """Classe base para todos os provedores de LLM"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.logger = logging.getLogger(self.__class__.__name__)
        self.model = config.get('model', 'unknown')
        self.temperature = config.get('temperature', 0.1)
        self.max_tokens = config.get('max_tokens', 4000)
        self.timeout = config.get('timeout', 120)
        
    @abstractmethod
    def generate_response(self, prompt: str, context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Gera resposta usando o provedor específico
        
        Args:
            prompt: Prompt para o LLM
            context: Contexto adicional opcional
            
        Returns:
            Dict com response, tokens_used, etc.
        """
        pass
    
    @abstractmethod
    def is_available(self) -> bool:
        """Verifica se o provedor está disponível"""
        pass
    
    def get_provider_info(self) -> Dict[str, Any]:
        """Retorna informações sobre o provedor"""
        return {
            'name': self.__class__.__name__,
            'model': self.model,
            'temperature': self.temperature,
            'max_tokens': self.max_tokens,
            'timeout': self.timeout
        }
    
    def validate_response(self, response: Dict[str, Any]) -> bool:
        """Valida se a resposta está no formato esperado"""
        required_fields = ['response', 'tokens_used', 'success']
        return all(field in response for field in required_fields)
    
    def format_error_response(self, error: Exception) -> Dict[str, Any]:
        """Formata resposta de erro padrão"""
        return {
            'response': f"Erro no provedor {self.__class__.__name__}: {str(error)}",
            'tokens_used': 0,
            'success': False,
            'error': str(error),
            'provider': self.__class__.__name__
        }
