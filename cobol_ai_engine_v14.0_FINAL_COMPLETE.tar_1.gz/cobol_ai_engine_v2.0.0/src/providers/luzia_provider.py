"""
LuzIA Provider - COBOL AI Engine v14.0
Provedor para integração com LuzIA (Claude 3.5 Sonnet via AWS)
"""

import json
import logging
import requests
import time
from typing import Dict, Any, Optional
from .base_provider import BaseLLMProvider

class LuziaProvider(BaseLLMProvider):
    """Provedor para LuzIA (Claude 3.5 Sonnet)"""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.client_id = config.get('client_id')
        self.client_secret = config.get('client_secret')
        self.auth_url = config.get('auth_url')
        self.api_url = config.get('api_url')
        self.access_token = None
        self.token_expires_at = 0
        
        # Configurações de retry
        retry_config = config.get('retry', {})
        self.max_attempts = retry_config.get('max_attempts', 3)
        self.base_delay = retry_config.get('base_delay', 2.0)
        self.max_delay = retry_config.get('max_delay', 30.0)
        self.backoff_multiplier = retry_config.get('backoff_multiplier', 2.0)
        
    def _get_access_token(self) -> bool:
        """Obtém token de acesso OAuth2"""
        try:
            if self.access_token and time.time() < self.token_expires_at:
                return True
            
            payload = {
                'grant_type': 'client_credentials',
                'client_id': self.client_id,
                'client_secret': self.client_secret
            }
            
            response = requests.post(
                self.auth_url,
                data=payload,
                timeout=30
            )
            
            if response.status_code == 200:
                data = response.json()
                self.access_token = data['access_token']
                expires_in = data.get('expires_in', 3600)
                self.token_expires_at = time.time() + expires_in - 60  # 1 min buffer
                return True
            else:
                self.logger.error(f"Erro ao obter token LuzIA: {response.status_code}")
                return False
                
        except Exception as e:
            self.logger.error(f"Erro na autenticação LuzIA: {e}")
            return False
    
    def is_available(self) -> bool:
        """Verifica se o provedor está disponível"""
        if not all([self.client_id, self.client_secret, self.auth_url, self.api_url]):
            self.logger.warning("Configuração LuzIA incompleta")
            return False
        
        return self._get_access_token()
    
    def generate_response(self, prompt: str, context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Gera resposta usando LuzIA"""
        
        if not self.is_available():
            return self.format_error_response(Exception("LuzIA não disponível"))
        
        for attempt in range(self.max_attempts):
            try:
                headers = {
                    'Authorization': f'Bearer {self.access_token}',
                    'Content-Type': 'application/json'
                }
                
                payload = {
                    "model": self.model,
                    "messages": [
                        {
                            "role": "system",
                            "content": "Você é um especialista sênior em análise de código COBOL com mais de 20 anos de experiência em sistemas bancários, financeiros e de mainframe."
                        },
                        {
                            "role": "user",
                            "content": prompt
                        }
                    ],
                    "temperature": self.temperature,
                    "max_tokens": self.max_tokens
                }
                
                response = requests.post(
                    f"{self.api_url}/chat/completions",
                    headers=headers,
                    json=payload,
                    timeout=self.timeout
                )
                
                if response.status_code == 200:
                    data = response.json()
                    
                    return {
                        'response': data['choices'][0]['message']['content'],
                        'tokens_used': data.get('usage', {}).get('total_tokens', 0),
                        'success': True,
                        'provider': 'LuzIA',
                        'model': self.model
                    }
                elif response.status_code == 401:
                    # Token expirado, tentar renovar
                    self.access_token = None
                    if self._get_access_token():
                        continue  # Tentar novamente
                    else:
                        return self.format_error_response(Exception("Falha na renovação do token"))
                else:
                    error_msg = f"LuzIA API erro {response.status_code}: {response.text}"
                    return self.format_error_response(Exception(error_msg))
                    
            except requests.exceptions.Timeout:
                if attempt < self.max_attempts - 1:
                    delay = min(self.base_delay * (self.backoff_multiplier ** attempt), self.max_delay)
                    time.sleep(delay)
                    continue
                return self.format_error_response(Exception("Timeout na requisição LuzIA"))
            except requests.exceptions.RequestException as e:
                if attempt < self.max_attempts - 1:
                    delay = min(self.base_delay * (self.backoff_multiplier ** attempt), self.max_delay)
                    time.sleep(delay)
                    continue
                return self.format_error_response(Exception(f"Erro de rede LuzIA: {e}"))
            except Exception as e:
                return self.format_error_response(e)
        
        return self.format_error_response(Exception("Máximo de tentativas excedido"))
    
    def get_provider_info(self) -> Dict[str, Any]:
        """Retorna informações sobre o provedor LuzIA"""
        info = super().get_provider_info()
        info.update({
            'provider_type': 'LuzIA (Claude 3.5 Sonnet)',
            'api_available': self.is_available(),
            'api_url': self.api_url,
            'has_token': bool(self.access_token)
        })
        return info
