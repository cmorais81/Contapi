"""
Enhanced Mock Provider - COBOL AI Engine v14.0
Provedor mock inteligente para testes e fallback
"""

import time
import random
import logging
from typing import Dict, Any, Optional
from .base_provider import BaseLLMProvider

class EnhancedMockProvider(BaseLLMProvider):
    """Provedor mock inteligente para análise COBOL"""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.response_delay = config.get('response_delay', 0.1)
        self.enable_phasing = config.get('enable_phasing', True)
        self.max_tokens_per_phase = config.get('max_tokens_per_phase', 2000)
        self.simulate_realistic_tokens = config.get('simulate_realistic_tokens', True)
        self.cobol_analysis_enabled = config.get('cobol_analysis_enabled', True)
        self.code_extraction_enabled = config.get('code_extraction_enabled', True)
        self.specific_responses = config.get('specific_responses', True)
        
    def is_available(self) -> bool:
        """Mock provider está sempre disponível"""
        return True
    
    def _generate_cobol_analysis(self, prompt: str) -> str:
        """Gera análise específica para COBOL baseada no prompt"""
        
        # Detectar tipo de análise baseado no prompt
        if "propósito" in prompt.lower() or "purpose" in prompt.lower():
            return self._generate_purpose_analysis(prompt)
        elif "fluxo" in prompt.lower() or "flow" in prompt.lower():
            return self._generate_flow_analysis(prompt)
        elif "resumo" in prompt.lower() or "summary" in prompt.lower():
            return self._generate_executive_summary(prompt)
        else:
            return self._generate_general_analysis(prompt)
    
    def _generate_purpose_analysis(self, prompt: str) -> str:
        """Gera análise de propósito específica"""
        
        # Detectar programa no prompt
        program_name = "PROGRAMA"
        if "LHAN0542" in prompt:
            program_name = "LHAN0542"
            return f"{program_name} quebra arquivos BACEN em partes menores para processamento"
        elif "LHAN0705" in prompt:
            program_name = "LHAN0705"
            return f"{program_name} processa informações BACEN do sistema"
        elif "LHAN0706" in prompt:
            program_name = "LHAN0706"
            return f"{program_name} valida dados BACEN conforme regras regulamentares"
        elif "LHBR0700" in prompt:
            program_name = "LHBR0700"
            return f"{program_name} converte dados OPERACIONAL entre formatos"
        elif "MZAN6056" in prompt:
            program_name = "MZAN6056"
            return f"{program_name} converte dados BACEN entre formatos"
        else:
            return f"{program_name} processa informações OPERACIONAL do sistema"
    
    def _generate_flow_analysis(self, prompt: str) -> str:
        """Gera análise de fluxo específica"""
        
        if "LHAN0542" in prompt:
            return """
            ENTRADA: Múltiplos arquivos BACEN (E1, E2, E3, E4, E5)
            PROCESSAMENTO: Particionar arquivos grandes em partes menores
            SAÍDA: Arquivos particionados (S1, S2, S3)
            
            Fluxo detalhado:
            1. Lê arquivos de entrada sequencialmente
            2. Aplica regras de particionamento por tamanho
            3. Distribui registros conforme tipo
            4. Grava arquivos de saída organizados
            """
        else:
            return """
            ENTRADA: Arquivos de dados do sistema
            PROCESSAMENTO: Transformação e validação
            SAÍDA: Dados processados e relatórios
            
            Fluxo básico de processamento identificado.
            """
    
    def _generate_executive_summary(self, prompt: str) -> str:
        """Gera resumo executivo específico"""
        
        if "LHAN0542" in prompt:
            return """
            ## Resumo Executivo - LHAN0542
            
            **Propósito:** Particionador de arquivos BACEN para atender limites regulamentares
            
            **Funcionalidade Principal:**
            - Processa arquivos BACEN DOC3040 de grande volume
            - Divide em partes menores respeitando limite de 4GB
            - Mantém integridade dos dados durante particionamento
            
            **Impacto no Negócio:**
            - CRÍTICO: Obrigatório para compliance regulamentar
            - Permite processamento de volumes grandes
            - Evita rejeições por tamanho de arquivo
            
            **Complexidade:** MÉDIA - Lógica de particionamento bem definida
            **Manutenibilidade:** BOA - Código estruturado e documentado
            """
        else:
            return """
            ## Resumo Executivo
            
            **Propósito:** Processamento de dados operacionais
            **Funcionalidade:** Transformação e validação de informações
            **Impacto:** Suporte às operações do sistema
            **Complexidade:** MÉDIA
            **Manutenibilidade:** ADEQUADA
            """
    
    def _generate_general_analysis(self, prompt: str) -> str:
        """Gera análise geral"""
        return """
        Análise COBOL realizada com base no código fornecido.
        
        O programa implementa funcionalidades de processamento de dados
        com foco em transformação e validação de informações.
        
        Estrutura típica de programa COBOL mainframe identificada.
        """
    
    def generate_response(self, prompt: str, context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Gera resposta mock inteligente"""
        
        # Simular delay realístico
        if self.response_delay > 0:
            time.sleep(self.response_delay)
        
        try:
            # Gerar resposta específica para COBOL
            if self.cobol_analysis_enabled and any(keyword in prompt.lower() for keyword in ['cobol', 'programa', 'lhan', 'mzan']):
                response_text = self._generate_cobol_analysis(prompt)
            else:
                response_text = "Análise mock gerada com base no prompt fornecido."
            
            # Simular tokens usados de forma realística
            if self.simulate_realistic_tokens:
                tokens_used = len(response_text.split()) * 1.3  # Aproximação realística
                tokens_used = int(tokens_used)
            else:
                tokens_used = random.randint(100, 1000)
            
            return {
                'response': response_text,
                'tokens_used': tokens_used,
                'success': True,
                'provider': 'Enhanced Mock',
                'model': self.model,
                'mock_analysis': True
            }
            
        except Exception as e:
            return self.format_error_response(e)
    
    def get_provider_info(self) -> Dict[str, Any]:
        """Retorna informações sobre o provedor mock"""
        info = super().get_provider_info()
        info.update({
            'provider_type': 'Enhanced Mock',
            'api_available': True,
            'cobol_analysis_enabled': self.cobol_analysis_enabled,
            'specific_responses': self.specific_responses
        })
        return info
