"""
COBOL AI Engine v14.0 - Módulo Utils
Utilitários e ferramentas auxiliares.
"""

# Importações essenciais para v14.0
from .extract_programs import extract_programs_from_fontes
from .extract_books import extract_books_from_file

__all__ = ['extract_programs_from_fontes', 'extract_books_from_file']
