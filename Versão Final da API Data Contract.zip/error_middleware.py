"""
Middleware de Tratamento de Erros
API de Governança de Dados V1.3
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

import logging
import traceback
import time
from typing import Callable, Dict, Any
from fastapi import Request, Response, HTTPException
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp
from sqlalchemy.exc import SQLAlchemyError, IntegrityError
from pydantic import ValidationError

logger = logging.getLogger(__name__)

class ErrorHandlingMiddleware(BaseHTTPMiddleware):
    """Middleware para tratamento centralizado de erros"""
    
    def __init__(self, app: ASGIApp, debug: bool = False):
        super().__init__(app)
        self.debug = debug
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """Processa requisição com tratamento de erros centralizado"""
        try:
            response = await call_next(request)
            return response
            
        except HTTPException as e:
            # HTTPException já tratada pelo FastAPI
            return await self._handle_http_exception(request, e)
            
        except ValidationError as e:
            # Erro de validação Pydantic
            return await self._handle_validation_error(request, e)
            
        except SQLAlchemyError as e:
            # Erro de banco de dados
            return await self._handle_database_error(request, e)
            
        except Exception as e:
            # Erro genérico não tratado
            return await self._handle_generic_error(request, e)
    
    async def _handle_http_exception(self, request: Request, exc: HTTPException) -> JSONResponse:
        """Trata HTTPException do FastAPI"""
        request_id = getattr(request.state, 'request_id', 'unknown')
        
        logger.warning(
            f"HTTP Exception [{request_id}]: {exc.status_code} - {exc.detail}",
            extra={
                "request_id": request_id,
                "status_code": exc.status_code,
                "detail": exc.detail,
                "path": request.url.path,
                "method": request.method
            }
        )
        
        return JSONResponse(
            status_code=exc.status_code,
            content={
                "error": "HTTP Error",
                "status_code": exc.status_code,
                "message": exc.detail,
                "request_id": request_id,
                "path": request.url.path,
                "timestamp": self._get_timestamp()
            },
            headers={"X-Request-ID": request_id}
        )
    
    async def _handle_validation_error(self, request: Request, exc: ValidationError) -> JSONResponse:
        """Trata erros de validação Pydantic"""
        request_id = getattr(request.state, 'request_id', 'unknown')
        
        # Formatar erros de validação
        validation_errors = []
        for error in exc.errors():
            validation_errors.append({
                "field": " -> ".join(str(loc) for loc in error["loc"]),
                "message": error["msg"],
                "type": error["type"],
                "input": error.get("input")
            })
        
        logger.warning(
            f"Validation Error [{request_id}]: {len(validation_errors)} validation errors",
            extra={
                "request_id": request_id,
                "validation_errors": validation_errors,
                "path": request.url.path,
                "method": request.method
            }
        )
        
        return JSONResponse(
            status_code=422,
            content={
                "error": "Validation Error",
                "status_code": 422,
                "message": "Request validation failed",
                "validation_errors": validation_errors,
                "request_id": request_id,
                "path": request.url.path,
                "timestamp": self._get_timestamp()
            },
            headers={"X-Request-ID": request_id}
        )
    
    async def _handle_database_error(self, request: Request, exc: SQLAlchemyError) -> JSONResponse:
        """Trata erros de banco de dados"""
        request_id = getattr(request.state, 'request_id', 'unknown')
        
        # Determinar tipo específico de erro
        if isinstance(exc, IntegrityError):
            status_code = 409
            error_type = "Integrity Error"
            message = "Data integrity constraint violation"
        else:
            status_code = 500
            error_type = "Database Error"
            message = "Database operation failed"
        
        logger.error(
            f"Database Error [{request_id}]: {type(exc).__name__} - {str(exc)}",
            extra={
                "request_id": request_id,
                "error_type": type(exc).__name__,
                "error_message": str(exc),
                "path": request.url.path,
                "method": request.method
            },
            exc_info=True
        )
        
        return JSONResponse(
            status_code=status_code,
            content={
                "error": error_type,
                "status_code": status_code,
                "message": message,
                "request_id": request_id,
                "path": request.url.path,
                "timestamp": self._get_timestamp(),
                "details": str(exc) if self.debug else None
            },
            headers={"X-Request-ID": request_id}
        )
    
    async def _handle_generic_error(self, request: Request, exc: Exception) -> JSONResponse:
        """Trata erros genéricos não capturados"""
        request_id = getattr(request.state, 'request_id', 'unknown')
        
        logger.error(
            f"Unhandled Error [{request_id}]: {type(exc).__name__} - {str(exc)}",
            extra={
                "request_id": request_id,
                "error_type": type(exc).__name__,
                "error_message": str(exc),
                "path": request.url.path,
                "method": request.method,
                "traceback": traceback.format_exc() if self.debug else None
            },
            exc_info=True
        )
        
        return JSONResponse(
            status_code=500,
            content={
                "error": "Internal Server Error",
                "status_code": 500,
                "message": "An unexpected error occurred",
                "request_id": request_id,
                "path": request.url.path,
                "timestamp": self._get_timestamp(),
                "details": {
                    "error_type": type(exc).__name__,
                    "error_message": str(exc),
                    "traceback": traceback.format_exc()
                } if self.debug else None
            },
            headers={"X-Request-ID": request_id}
        )
    
    def _get_timestamp(self) -> str:
        """Obtém timestamp atual em formato ISO"""
        from datetime import datetime
        return datetime.utcnow().isoformat() + "Z"

class SecurityMiddleware(BaseHTTPMiddleware):
    """Middleware para headers de segurança"""
    
    def __init__(self, app: ASGIApp):
        super().__init__(app)
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """Adiciona headers de segurança"""
        response = await call_next(request)
        
        # Headers de segurança
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["X-XSS-Protection"] = "1; mode=block"
        response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        response.headers["Content-Security-Policy"] = "default-src 'self'"
        
        return response

class RateLimitMiddleware(BaseHTTPMiddleware):
    """Middleware básico de rate limiting"""
    
    def __init__(self, app: ASGIApp, requests_per_minute: int = 60):
        super().__init__(app)
        self.requests_per_minute = requests_per_minute
        self.request_counts = {}
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """Aplica rate limiting básico por IP"""
        client_ip = self._get_client_ip(request)
        current_time = int(time.time() / 60)  # Minuto atual
        
        # Limpar contadores antigos
        self.request_counts = {
            key: value for key, value in self.request_counts.items()
            if key[1] >= current_time - 1
        }
        
        # Verificar limite
        key = (client_ip, current_time)
        current_count = self.request_counts.get(key, 0)
        
        if current_count >= self.requests_per_minute:
            return JSONResponse(
                status_code=429,
                content={
                    "error": "Rate Limit Exceeded",
                    "status_code": 429,
                    "message": f"Too many requests. Limit: {self.requests_per_minute} per minute",
                    "retry_after": 60
                },
                headers={"Retry-After": "60"}
            )
        
        # Incrementar contador
        self.request_counts[key] = current_count + 1
        
        response = await call_next(request)
        
        # Adicionar headers de rate limit
        response.headers["X-RateLimit-Limit"] = str(self.requests_per_minute)
        response.headers["X-RateLimit-Remaining"] = str(self.requests_per_minute - current_count - 1)
        response.headers["X-RateLimit-Reset"] = str((current_time + 1) * 60)
        
        return response
    
    def _get_client_ip(self, request: Request) -> str:
        """Obtém IP do cliente"""
        forwarded_for = request.headers.get("X-Forwarded-For")
        if forwarded_for:
            return forwarded_for.split(",")[0].strip()
        return request.client.host if request.client else "unknown"

