"""
Serviço de Gerenciamento de Tags
API de Governança de Dados V2.0
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from typing import List, Optional, Dict, Any
from sqlalchemy.orm import Session
from datetime import datetime

from ..dtos.common import PaginationParams, FilterParams, SortParams
from ...database.models.tags import Tag, TagCategory, TagHierarchy
from ...database.models.entities import EntityTag
from ...database.repositories.base import BaseRepository

class TagService:
    """Serviço para gerenciamento de tags e categorização"""
    
    def __init__(self, db: Session):
        self.db = db
        self.tag_repo = BaseRepository(Tag, db)
        self.category_repo = BaseRepository(TagCategory, db)
        self.entity_tag_repo = BaseRepository(EntityTag, db)
        self.hierarchy_repo = BaseRepository(TagHierarchy, db)
    
    # Métodos para Tags
    def create_tag(self, tag_data: Dict[str, Any]) -> Tag:
        """Cria nova tag"""
        tag = Tag(**tag_data)
        self.db.add(tag)
        self.db.commit()
        self.db.refresh(tag)
        return tag
    
    def get_tag_by_id(self, tag_id: str) -> Optional[Tag]:
        """Obtém tag por ID"""
        return self.tag_repo.get_by_id(tag_id)
    
    def get_tags_by_category(self, category_id: str) -> List[Tag]:
        """Obtém tags por categoria"""
        return self.db.query(Tag).filter(
            Tag.category_id == category_id,
            Tag.is_active == True
        ).all()
    
    def search_tags(self, query: str, limit: int = 50) -> List[Tag]:
        """Busca tags por nome ou descrição"""
        return self.db.query(Tag).filter(
            Tag.name.ilike(f'%{query}%') | Tag.description.ilike(f'%{query}%'),
            Tag.is_active == True
        ).limit(limit).all()
    
    def get_popular_tags(self, limit: int = 20) -> List[Dict[str, Any]]:
        """Obtém tags mais utilizadas"""
        from sqlalchemy import func
        
        result = self.db.query(
            Tag.id,
            Tag.name,
            Tag.color,
            func.count(EntityTag.entity_id).label('usage_count')
        ).join(EntityTag).filter(
            Tag.is_active == True
        ).group_by(Tag.id, Tag.name, Tag.color).order_by(
            func.count(EntityTag.entity_id).desc()
        ).limit(limit).all()
        
        return [
            {
                'id': row.id,
                'name': row.name,
                'color': row.color,
                'usage_count': row.usage_count
            }
            for row in result
        ]
    
    def update_tag(self, tag_id: str, tag_data: Dict[str, Any]) -> Optional[Tag]:
        """Atualiza tag"""
        tag = self.get_tag_by_id(tag_id)
        if tag:
            for key, value in tag_data.items():
                setattr(tag, key, value)
            tag.updated_at = datetime.utcnow()
            self.db.commit()
            self.db.refresh(tag)
        return tag
    
    def delete_tag(self, tag_id: str) -> bool:
        """Remove tag (soft delete)"""
        tag = self.get_tag_by_id(tag_id)
        if tag:
            tag.is_active = False
            tag.updated_at = datetime.utcnow()
            self.db.commit()
            return True
        return False
    
    # Métodos para Categorias
    def create_category(self, category_data: Dict[str, Any]) -> TagCategory:
        """Cria nova categoria de tags"""
        category = TagCategory(**category_data)
        self.db.add(category)
        self.db.commit()
        self.db.refresh(category)
        return category
    
    def get_categories(self) -> List[TagCategory]:
        """Obtém todas as categorias ativas"""
        return self.db.query(TagCategory).filter(
            TagCategory.is_active == True
        ).order_by(TagCategory.name).all()
    
    def get_category_by_id(self, category_id: str) -> Optional[TagCategory]:
        """Obtém categoria por ID"""
        return self.category_repo.get_by_id(category_id)
    
    def update_category(self, category_id: str, category_data: Dict[str, Any]) -> Optional[TagCategory]:
        """Atualiza categoria"""
        category = self.get_category_by_id(category_id)
        if category:
            for key, value in category_data.items():
                setattr(category, key, value)
            category.updated_at = datetime.utcnow()
            self.db.commit()
            self.db.refresh(category)
        return category
    
    # Métodos para Associação Entidade-Tag
    def tag_entity(self, entity_id: str, tag_id: str, tagged_by: str) -> EntityTag:
        """Associa tag a uma entidade"""
        # Verifica se já existe a associação
        existing = self.db.query(EntityTag).filter(
            EntityTag.entity_id == entity_id,
            EntityTag.tag_id == tag_id
        ).first()
        
        if existing:
            return existing
        
        entity_tag = EntityTag(
            entity_id=entity_id,
            tag_id=tag_id,
            tagged_by=tagged_by,
            tagged_at=datetime.utcnow()
        )
        self.db.add(entity_tag)
        self.db.commit()
        self.db.refresh(entity_tag)
        return entity_tag
    
    def untag_entity(self, entity_id: str, tag_id: str) -> bool:
        """Remove tag de uma entidade"""
        entity_tag = self.db.query(EntityTag).filter(
            EntityTag.entity_id == entity_id,
            EntityTag.tag_id == tag_id
        ).first()
        
        if entity_tag:
            self.db.delete(entity_tag)
            self.db.commit()
            return True
        return False
    
    def get_entity_tags(self, entity_id: str) -> List[Tag]:
        """Obtém todas as tags de uma entidade"""
        return self.db.query(Tag).join(EntityTag).filter(
            EntityTag.entity_id == entity_id,
            Tag.is_active == True
        ).all()
    
    def get_entities_by_tag(self, tag_id: str) -> List[str]:
        """Obtém entidades que possuem uma tag específica"""
        result = self.db.query(EntityTag.entity_id).filter(
            EntityTag.tag_id == tag_id
        ).all()
        return [row.entity_id for row in result]
    
    def bulk_tag_entities(self, entity_ids: List[str], tag_id: str, tagged_by: str) -> List[EntityTag]:
        """Aplica tag a múltiplas entidades"""
        entity_tags = []
        for entity_id in entity_ids:
            entity_tag = self.tag_entity(entity_id, tag_id, tagged_by)
            entity_tags.append(entity_tag)
        return entity_tags
    
    def bulk_untag_entities(self, entity_ids: List[str], tag_id: str) -> int:
        """Remove tag de múltiplas entidades"""
        count = self.db.query(EntityTag).filter(
            EntityTag.entity_id.in_(entity_ids),
            EntityTag.tag_id == tag_id
        ).delete(synchronize_session=False)
        self.db.commit()
        return count
    
    # Métodos para Hierarquia
    def create_tag_hierarchy(self, parent_tag_id: str, child_tag_id: str) -> TagHierarchy:
        """Cria relação hierárquica entre tags"""
        hierarchy = TagHierarchy(
            parent_tag_id=parent_tag_id,
            child_tag_id=child_tag_id
        )
        self.db.add(hierarchy)
        self.db.commit()
        self.db.refresh(hierarchy)
        return hierarchy
    
    def get_tag_children(self, tag_id: str) -> List[Tag]:
        """Obtém tags filhas de uma tag"""
        return self.db.query(Tag).join(
            TagHierarchy, Tag.id == TagHierarchy.child_tag_id
        ).filter(
            TagHierarchy.parent_tag_id == tag_id,
            Tag.is_active == True
        ).all()
    
    def get_tag_parents(self, tag_id: str) -> List[Tag]:
        """Obtém tags pais de uma tag"""
        return self.db.query(Tag).join(
            TagHierarchy, Tag.id == TagHierarchy.parent_tag_id
        ).filter(
            TagHierarchy.child_tag_id == tag_id,
            Tag.is_active == True
        ).all()
    
    def get_tag_tree(self, root_tag_id: str) -> Dict[str, Any]:
        """Obtém árvore completa de tags a partir de uma raiz"""
        def build_tree(tag_id: str, visited: set = None) -> Dict[str, Any]:
            if visited is None:
                visited = set()
            
            if tag_id in visited:
                return None  # Evita loops infinitos
            
            visited.add(tag_id)
            tag = self.get_tag_by_id(tag_id)
            if not tag:
                return None
            
            children = self.get_tag_children(tag_id)
            tree = {
                'id': tag.id,
                'name': tag.name,
                'description': tag.description,
                'color': tag.color,
                'children': []
            }
            
            for child in children:
                child_tree = build_tree(child.id, visited.copy())
                if child_tree:
                    tree['children'].append(child_tree)
            
            return tree
        
        return build_tree(root_tag_id)
    
    # Métodos de análise
    def get_tag_statistics(self) -> Dict[str, Any]:
        """Obtém estatísticas gerais de tags"""
        from sqlalchemy import func
        
        total_tags = self.db.query(func.count(Tag.id)).filter(Tag.is_active == True).scalar()
        total_categories = self.db.query(func.count(TagCategory.id)).filter(TagCategory.is_active == True).scalar()
        total_associations = self.db.query(func.count(EntityTag.id)).scalar()
        
        most_used_tag = self.db.query(
            Tag.name,
            func.count(EntityTag.entity_id).label('usage_count')
        ).join(EntityTag).filter(
            Tag.is_active == True
        ).group_by(Tag.id, Tag.name).order_by(
            func.count(EntityTag.entity_id).desc()
        ).first()
        
        return {
            'total_tags': total_tags or 0,
            'total_categories': total_categories or 0,
            'total_associations': total_associations or 0,
            'most_used_tag': {
                'name': most_used_tag.name if most_used_tag else None,
                'usage_count': most_used_tag.usage_count if most_used_tag else 0
            },
            'generated_at': datetime.utcnow().isoformat()
        }
    
    def get_tag_usage_trends(self, days: int = 30) -> List[Dict[str, Any]]:
        """Obtém tendências de uso de tags"""
        from sqlalchemy import func
        from datetime import timedelta
        
        start_date = datetime.utcnow() - timedelta(days=days)
        
        result = self.db.query(
            Tag.name,
            func.count(EntityTag.entity_id).label('usage_count'),
            func.max(EntityTag.tagged_at).label('last_used')
        ).join(EntityTag).filter(
            Tag.is_active == True,
            EntityTag.tagged_at >= start_date
        ).group_by(Tag.id, Tag.name).order_by(
            func.count(EntityTag.entity_id).desc()
        ).limit(20).all()
        
        return [
            {
                'tag_name': row.name,
                'usage_count': row.usage_count,
                'last_used': row.last_used.isoformat() if row.last_used else None
            }
            for row in result
        ]
    
    def suggest_tags(self, entity_id: str, limit: int = 10) -> List[Dict[str, Any]]:
        """Sugere tags para uma entidade baseado em similaridade"""
        # Implementação simplificada - pode ser melhorada com ML
        existing_tags = self.get_entity_tags(entity_id)
        existing_tag_ids = [tag.id for tag in existing_tags]
        
        if not existing_tag_ids:
            # Se não há tags, retorna as mais populares
            return self.get_popular_tags(limit)
        
        # Busca entidades similares (que compartilham tags)
        from sqlalchemy import func
        
        similar_entities = self.db.query(
            EntityTag.entity_id,
            func.count(EntityTag.tag_id).label('common_tags')
        ).filter(
            EntityTag.tag_id.in_(existing_tag_ids),
            EntityTag.entity_id != entity_id
        ).group_by(EntityTag.entity_id).order_by(
            func.count(EntityTag.tag_id).desc()
        ).limit(10).all()
        
        if not similar_entities:
            return []
        
        similar_entity_ids = [row.entity_id for row in similar_entities]
        
        # Busca tags usadas por entidades similares
        suggested = self.db.query(
            Tag.id,
            Tag.name,
            Tag.description,
            Tag.color,
            func.count(EntityTag.entity_id).label('relevance_score')
        ).join(EntityTag).filter(
            EntityTag.entity_id.in_(similar_entity_ids),
            ~Tag.id.in_(existing_tag_ids),
            Tag.is_active == True
        ).group_by(Tag.id, Tag.name, Tag.description, Tag.color).order_by(
            func.count(EntityTag.entity_id).desc()
        ).limit(limit).all()
        
        return [
            {
                'id': row.id,
                'name': row.name,
                'description': row.description,
                'color': row.color,
                'relevance_score': row.relevance_score
            }
            for row in suggested
        ]

