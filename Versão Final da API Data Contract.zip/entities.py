Modelos de Entidades e Catálogo de Dados
API de Governança de Dados V1.9
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from sqlalchemy import Column, String, Text, Boolean, Integer, DateTime, ForeignKey, Enum as SQLEnum, Float
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import relationship
from enum import Enum
from ..base import Base

class EntityType(Enum):
    TABLE = "table"
    VIEW = "view"
    DATASET = "dataset"
    API = "api"
    FILE = "file"
    STREAM = "stream"

class DataType(Enum):
    STRING = "string"
    INTEGER = "integer"
    FLOAT = "float"
    BOOLEAN = "boolean"
    DATE = "date"
    DATETIME = "datetime"
    JSON = "json"
    BINARY = "binary"

class RelationshipType(Enum):
    ONE_TO_ONE = "one_to_one"
    ONE_TO_MANY = "one_to_many"
    MANY_TO_MANY = "many_to_many"
    PARENT_CHILD = "parent_child"
    DEPENDENCY = "dependency"

class Entity(Base):
    """Entidades do catálogo de dados (tabelas, views, datasets, etc.)"""
    __tablename__ = 'entities'
    __table_args__ = {'extend_existing': True}
    
    name = Column(String(255), nullable=False, comment='Nome da entidade')
    display_name = Column(String(255), comment='Nome de exibição amigável')
    description = Column(Text, comment='Descrição detalhada da entidade')
    entity_type = Column(SQLEnum(EntityType), nullable=False, comment='Tipo da entidade')
    
    # Localização
    database_name = Column(String(255), comment='Nome do banco de dados')
    schema_name = Column(String(255), comment='Nome do schema')