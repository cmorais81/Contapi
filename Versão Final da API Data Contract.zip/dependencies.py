"""
Dependências da API
API de Governança de Dados V1.5
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from typing import AsyncGenerator, Dict, Optional, Any
from uuid import UUID
import logging

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

logger = logging.getLogger(__name__)

# Security
security = HTTPBearer()

# Simulação de sessão de banco de dados
class MockSession:
    """Sessão simulada para desenvolvimento"""
    def __init__(self):
        self.data = {}
        logger.info("MockSession criada")
    
    async def close(self):
        logger.info("MockSession fechada")

async def get_db_session() -> MockSession:
    """Dependency para obter sessão do banco de dados (simulada)"""
    try:
        session = MockSession()
        logger.info("Sessão de banco simulada criada")
        return session
    except Exception as e:
        logger.error(f"Erro ao criar sessão de banco: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

# Importações seguras dos serviços
try:
    from application.services.data_contract_service import DataContractService
except ImportError:
    logger.warning("DataContractService não pôde ser importado")
    DataContractService = None

try:
    from application.services.domain_service import DomainService
except ImportError:
    logger.warning("DomainService não pôde ser importado")
    DomainService = None

try:
    from application.services.lineage_service import LineageService
except ImportError:
    logger.warning("LineageService não pôde ser importado")
    LineageService = None

try:
    from application.services.quality_service import QualityService
except ImportError:
    logger.warning("QualityService não pôde ser importado")
    QualityService = None

try:
    from application.services.policy_service import PolicyService
except ImportError:
    logger.warning("PolicyService não pôde ser importado")
    PolicyService = None

try:
    from application.services.stewardship_service import StewardshipService
except ImportError:
    logger.warning("StewardshipService não pôde ser importado")
    StewardshipService = None

# Factories para serviços
def get_data_contract_service() -> Any:
    """Factory para DataContractService"""
    if DataContractService:
        return DataContractService()
    else:
        logger.warning("DataContractService não disponível, retornando mock")
        return MockService("DataContractService")

def get_domain_service() -> Any:
    """Factory para DomainService"""
    if DomainService:
        return DomainService()
    else:
        logger.warning("DomainService não disponível, retornando mock")
        return MockService("DomainService")

def get_lineage_service() -> Any:
    """Factory para LineageService"""
    if LineageService:
        return LineageService()
    else:
        logger.warning("LineageService não disponível, retornando mock")
        return MockService("LineageService")

def get_quality_service() -> Any:
    """Factory para QualityService"""
    if QualityService:
        return QualityService()
    else:
        logger.warning("QualityService não disponível, retornando mock")
        return MockService("QualityService")

def get_policy_service() -> Any:
    """Factory para PolicyService"""
    if PolicyService:
        return PolicyService()
    else:
        logger.warning("PolicyService não disponível, retornando mock")
        return MockService("PolicyService")

def get_stewardship_service() -> Any:
    """Factory para StewardshipService"""
    if StewardshipService:
        return StewardshipService()
    else:
        logger.warning("StewardshipService não disponível, retornando mock")
        return MockService("StewardshipService")

class MockService:
    """Serviço mock para desenvolvimento"""
    def __init__(self, service_name: str):
        self.service_name = service_name
        logger.info(f"MockService criado para {service_name}")
    
    async def __getattr__(self, name):
        """Retorna método mock para qualquer chamada"""
        async def mock_method(*args, **kwargs):
            logger.info(f"Método mock {name} chamado em {self.service_name}")
            return {
                "message": f"Mock response from {self.service_name}.{name}",
                "service": self.service_name,
                "method": name,
                "args": args,
                "kwargs": kwargs,
                "author": "Carlos Morais",
                "email": "carlos.morais@f1rst.com.br"
            }
        return mock_method

# Dependency para autenticação (simulada)
async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)) -> Dict[str, Any]:
    """Dependency para obter usuário atual (simulado)"""
    try:
        # Simulação de autenticação
        user = {
            "id": "user_123",
            "username": "carlos.morais",
            "email": "carlos.morais@f1rst.com.br",
            "roles": ["admin", "data_steward"],
            "permissions": ["read", "write", "admin"],
            "organization": "F1rst"
        }
        logger.info(f"Usuário autenticado: {user['username']}")
        return user
    except Exception as e:
        logger.error(f"Erro na autenticação: {e}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token inválido",
            headers={"WWW-Authenticate": "Bearer"},
        )

# Dependency para paginação
class PaginationParams:
    """Parâmetros de paginação"""
    def __init__(self, limit: int = 100, offset: int = 0):
        self.limit = min(limit, 1000)  # Máximo 1000 itens
        self.offset = max(offset, 0)   # Mínimo 0

def get_pagination_params(limit: int = 100, offset: int = 0) -> PaginationParams:
    """Dependency para parâmetros de paginação"""
    return PaginationParams(limit=limit, offset=offset)

# Dependency para validação de UUID
def validate_uuid(uuid_str: str) -> UUID:
    """Valida e converte string para UUID"""
    try:
        return UUID(uuid_str)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"UUID inválido: {uuid_str}"
        )

# Dependency para headers de auditoria
def get_audit_headers() -> Dict[str, str]:
    """Retorna headers de auditoria"""
    return {
        "X-API-Version": "1.5.0",
        "X-Author": "Carlos Morais",
        "X-Author-Email": "carlos.morais@f1rst.com.br",
        "X-Organization": "F1rst"
    }


# Dependency para usuário ativo
async def get_current_active_user(current_user: Dict[str, Any] = Depends(get_current_user)) -> Dict[str, Any]:
    """Dependency para obter usuário ativo atual"""
    try:
        # Verificar se usuário está ativo
        if not current_user.get("is_active", True):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Usuário inativo"
            )
        
        logger.info(f"Usuário ativo verificado: {current_user['username']}")
        return current_user
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro na verificação de usuário ativo: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro interno do servidor"
        )

# Dependency para verificação de permissões
def require_permission(permission: str):
    """Factory para dependency de verificação de permissão"""
    async def check_permission(current_user: Dict[str, Any] = Depends(get_current_active_user)) -> Dict[str, Any]:
        user_permissions = current_user.get("permissions", [])
        if permission not in user_permissions and "admin" not in user_permissions:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Permissão necessária: {permission}"
            )
        return current_user
    return check_permission

# Dependency para verificação de role
def require_role(role: str):
    """Factory para dependency de verificação de role"""
    async def check_role(current_user: Dict[str, Any] = Depends(get_current_active_user)) -> Dict[str, Any]:
        user_roles = current_user.get("roles", [])
        if role not in user_roles and "admin" not in user_roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Role necessária: {role}"
            )
        return current_user
    return check_role


# Importações seguras dos serviços adicionais
try:
    from application.services.analytics_service import AnalyticsService
except ImportError:
    logger.warning("AnalyticsService não pôde ser importado")
    AnalyticsService = None

try:
    from application.services.discovery_service import DiscoveryService
except ImportError:
    logger.warning("DiscoveryService não pôde ser importado")
    DiscoveryService = None

try:
    from application.services.workflow_service import WorkflowService
except ImportError:
    logger.warning("WorkflowService não pôde ser importado")
    WorkflowService = None

try:
    from application.services.notification_service import NotificationService
except ImportError:
    logger.warning("NotificationService não pôde ser importado")
    NotificationService = None

try:
    from application.services.security_service import SecurityService
except ImportError:
    logger.warning("SecurityService não pôde ser importado")
    SecurityService = None

try:
    from application.services.performance_service import PerformanceService
except ImportError:
    logger.warning("PerformanceService não pôde ser importado")
    PerformanceService = None

try:
    from application.services.tag_service import TagService
except ImportError:
    logger.warning("TagService não pôde ser importado")
    TagService = None

# Factories para serviços adicionais
def get_analytics_service() -> Any:
    """Factory para AnalyticsService"""
    if AnalyticsService:
        return AnalyticsService()
    else:
        logger.warning("AnalyticsService não disponível, retornando mock")
        return MockService("AnalyticsService")

def get_discovery_service() -> Any:
    """Factory para DiscoveryService"""
    if DiscoveryService:
        return DiscoveryService()
    else:
        logger.warning("DiscoveryService não disponível, retornando mock")
        return MockService("DiscoveryService")

def get_workflow_service() -> Any:
    """Factory para WorkflowService"""
    if WorkflowService:
        return WorkflowService()
    else:
        logger.warning("WorkflowService não disponível, retornando mock")
        return MockService("WorkflowService")

def get_notification_service() -> Any:
    """Factory para NotificationService"""
    if NotificationService:
        return NotificationService()
    else:
        logger.warning("NotificationService não disponível, retornando mock")
        return MockService("NotificationService")

def get_security_service() -> Any:
    """Factory para SecurityService"""
    if SecurityService:
        return SecurityService()
    else:
        logger.warning("SecurityService não disponível, retornando mock")
        return MockService("SecurityService")

def get_performance_service() -> Any:
    """Factory para PerformanceService"""
    if PerformanceService:
        return PerformanceService()
    else:
        logger.warning("PerformanceService não disponível, retornando mock")
        return MockService("PerformanceService")

def get_tag_service() -> Any:
    """Factory para TagService"""
    if TagService:
        return TagService()
    else:
        logger.warning("TagService não disponível, retornando mock")
        return MockService("TagService")

# Dependency para validação de paginação
def validate_pagination(limit: int = 100, offset: int = 0) -> PaginationParams:
    """Valida e retorna parâmetros de paginação"""
    return PaginationParams(limit=min(limit, 1000), offset=max(offset, 0))

