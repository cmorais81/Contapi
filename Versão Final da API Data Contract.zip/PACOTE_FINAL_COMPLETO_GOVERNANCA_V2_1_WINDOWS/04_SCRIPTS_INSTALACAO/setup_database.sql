-- Script de Setup do Banco de Dados - Solução de Governança V1.0
-- Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
-- Organização: F1rst Technology Solutions
-- Cliente: Banco Santander
-- Data: Julho 2025
-- Versão: 1.0.0 Final

-- Configurações iniciais
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

-- Criar extensões necessárias
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";
CREATE EXTENSION IF NOT EXISTS "btree_gin";

-- Criar schemas
CREATE SCHEMA IF NOT EXISTS governance;
CREATE SCHEMA IF NOT EXISTS audit;
CREATE SCHEMA IF NOT EXISTS monitoring;

-- Configurar search_path
SET search_path = governance, public;

-- Função para atualizar timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Função para gerar IDs únicos
CREATE OR REPLACE FUNCTION generate_unique_id(prefix TEXT DEFAULT '')
RETURNS TEXT AS $$
BEGIN
    RETURN prefix || '_' || EXTRACT(EPOCH FROM NOW())::BIGINT || '_' || FLOOR(RANDOM() * 1000000)::BIGINT;
END;
$$ language 'plpgsql';

-- Tabela de configurações do sistema
CREATE TABLE IF NOT EXISTS governance.system_config (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    config_key VARCHAR(255) NOT NULL UNIQUE,
    config_value TEXT NOT NULL,
    config_type VARCHAR(50) DEFAULT 'string',
    description TEXT,
    is_encrypted BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Inserir configurações padrão
INSERT INTO governance.system_config (config_key, config_value, config_type, description) VALUES
('sync_interval_minutes', '20', 'integer', 'Intervalo de sincronização em minutos'),
('unity_catalog_sync_enabled', 'true', 'boolean', 'Habilitar sincronização Unity Catalog'),
('axon_sync_enabled', 'true', 'boolean', 'Habilitar sincronização Informatica Axon'),
('datahub_sync_enabled', 'true', 'boolean', 'Habilitar sincronização DataHub'),
('ml_training_enabled', 'true', 'boolean', 'Habilitar treinamento de modelos ML'),
('anomaly_detection_threshold', '0.1', 'float', 'Threshold para detecção de anomalias'),
('backup_enabled', 'true', 'boolean', 'Habilitar backup automático'),
('backup_interval_hours', '6', 'integer', 'Intervalo de backup em horas'),
('backup_retention_days', '30', 'integer', 'Retenção de backups em dias'),
('quality_check_enabled', 'true', 'boolean', 'Habilitar verificações de qualidade'),
('lineage_discovery_enabled', 'true', 'boolean', 'Habilitar descoberta de lineage'),
('compliance_monitoring_enabled', 'true', 'boolean', 'Habilitar monitoramento de compliance')
ON CONFLICT (config_key) DO NOTHING;

-- Tabela de auditoria
CREATE TABLE IF NOT EXISTS audit.audit_log (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    table_name VARCHAR(255) NOT NULL,
    operation VARCHAR(10) NOT NULL,
    old_values JSONB,
    new_values JSONB,
    user_id UUID,
    user_email VARCHAR(255),
    ip_address INET,
    user_agent TEXT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    session_id VARCHAR(255)
);

-- Índices para auditoria
CREATE INDEX IF NOT EXISTS idx_audit_log_table_name ON audit.audit_log(table_name);
CREATE INDEX IF NOT EXISTS idx_audit_log_operation ON audit.audit_log(operation);
CREATE INDEX IF NOT EXISTS idx_audit_log_user_id ON audit.audit_log(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_log_timestamp ON audit.audit_log(timestamp);

-- Função de auditoria
CREATE OR REPLACE FUNCTION audit.audit_trigger()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'DELETE' THEN
        INSERT INTO audit.audit_log (table_name, operation, old_values)
        VALUES (TG_TABLE_NAME, TG_OP, row_to_json(OLD));
        RETURN OLD;
    ELSIF TG_OP = 'UPDATE' THEN
        INSERT INTO audit.audit_log (table_name, operation, old_values, new_values)
        VALUES (TG_TABLE_NAME, TG_OP, row_to_json(OLD), row_to_json(NEW));
        RETURN NEW;
    ELSIF TG_OP = 'INSERT' THEN
        INSERT INTO audit.audit_log (table_name, operation, new_values)
        VALUES (TG_TABLE_NAME, TG_OP, row_to_json(NEW));
        RETURN NEW;
    END IF;
    RETURN NULL;
END;
$$ language 'plpgsql';

-- Tabela de métricas de monitoramento
CREATE TABLE IF NOT EXISTS monitoring.metrics (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    metric_name VARCHAR(255) NOT NULL,
    metric_value NUMERIC NOT NULL,
    metric_type VARCHAR(50) DEFAULT 'gauge',
    labels JSONB DEFAULT '{}',
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Índices para métricas
CREATE INDEX IF NOT EXISTS idx_metrics_name ON monitoring.metrics(metric_name);
CREATE INDEX IF NOT EXISTS idx_metrics_timestamp ON monitoring.metrics(timestamp);
CREATE INDEX IF NOT EXISTS idx_metrics_labels ON monitoring.metrics USING GIN(labels);

-- Tabela de jobs de sincronização
CREATE TABLE IF NOT EXISTS governance.sync_jobs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    job_name VARCHAR(255) NOT NULL,
    connector_type VARCHAR(100) NOT NULL,
    status VARCHAR(50) DEFAULT 'pending',
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    error_message TEXT,
    records_processed INTEGER DEFAULT 0,
    records_success INTEGER DEFAULT 0,
    records_failed INTEGER DEFAULT 0,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Índices para sync jobs
CREATE INDEX IF NOT EXISTS idx_sync_jobs_status ON governance.sync_jobs(status);
CREATE INDEX IF NOT EXISTS idx_sync_jobs_connector_type ON governance.sync_jobs(connector_type);
CREATE INDEX IF NOT EXISTS idx_sync_jobs_created_at ON governance.sync_jobs(created_at);

-- Trigger para updated_at
CREATE TRIGGER update_sync_jobs_updated_at
    BEFORE UPDATE ON governance.sync_jobs
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Tabela de health checks
CREATE TABLE IF NOT EXISTS monitoring.health_checks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    service_name VARCHAR(255) NOT NULL,
    status VARCHAR(50) NOT NULL,
    response_time_ms INTEGER,
    error_message TEXT,
    metadata JSONB DEFAULT '{}',
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Índices para health checks
CREATE INDEX IF NOT EXISTS idx_health_checks_service ON monitoring.health_checks(service_name);
CREATE INDEX IF NOT EXISTS idx_health_checks_status ON monitoring.health_checks(status);
CREATE INDEX IF NOT EXISTS idx_health_checks_timestamp ON monitoring.health_checks(timestamp);

-- View para configurações ativas
CREATE OR REPLACE VIEW governance.active_config AS
SELECT 
    config_key,
    CASE 
        WHEN config_type = 'boolean' THEN config_value::boolean::text
        WHEN config_type = 'integer' THEN config_value::integer::text
        WHEN config_type = 'float' THEN config_value::numeric::text
        ELSE config_value
    END as config_value,
    config_type,
    description,
    updated_at
FROM governance.system_config
ORDER BY config_key;

-- View para estatísticas de sincronização
CREATE OR REPLACE VIEW governance.sync_stats AS
SELECT 
    connector_type,
    COUNT(*) as total_jobs,
    COUNT(*) FILTER (WHERE status = 'completed') as completed_jobs,
    COUNT(*) FILTER (WHERE status = 'failed') as failed_jobs,
    COUNT(*) FILTER (WHERE status = 'running') as running_jobs,
    AVG(EXTRACT(EPOCH FROM (completed_at - started_at))) as avg_duration_seconds,
    SUM(records_processed) as total_records_processed,
    SUM(records_success) as total_records_success,
    SUM(records_failed) as total_records_failed,
    MAX(created_at) as last_job_created
FROM governance.sync_jobs
GROUP BY connector_type;

-- View para métricas de saúde do sistema
CREATE OR REPLACE VIEW monitoring.system_health AS
SELECT 
    service_name,
    COUNT(*) as total_checks,
    COUNT(*) FILTER (WHERE status = 'healthy') as healthy_checks,
    COUNT(*) FILTER (WHERE status = 'unhealthy') as unhealthy_checks,
    AVG(response_time_ms) as avg_response_time_ms,
    MAX(timestamp) as last_check_time,
    CASE 
        WHEN COUNT(*) FILTER (WHERE status = 'healthy' AND timestamp > NOW() - INTERVAL '5 minutes') > 0 
        THEN 'healthy'
        ELSE 'unhealthy'
    END as current_status
FROM monitoring.health_checks
WHERE timestamp > NOW() - INTERVAL '1 hour'
GROUP BY service_name;

-- Função para limpar dados antigos
CREATE OR REPLACE FUNCTION governance.cleanup_old_data()
RETURNS void AS $$
BEGIN
    -- Limpar logs de auditoria antigos (> 90 dias)
    DELETE FROM audit.audit_log 
    WHERE timestamp < NOW() - INTERVAL '90 days';
    
    -- Limpar métricas antigas (> 30 dias)
    DELETE FROM monitoring.metrics 
    WHERE timestamp < NOW() - INTERVAL '30 days';
    
    -- Limpar health checks antigos (> 7 dias)
    DELETE FROM monitoring.health_checks 
    WHERE timestamp < NOW() - INTERVAL '7 days';
    
    -- Limpar jobs de sincronização antigos (> 30 dias)
    DELETE FROM governance.sync_jobs 
    WHERE created_at < NOW() - INTERVAL '30 days' 
    AND status IN ('completed', 'failed');
    
    -- Vacuum para recuperar espaço
    VACUUM ANALYZE;
END;
$$ language 'plpgsql';

-- Função para obter configuração
CREATE OR REPLACE FUNCTION governance.get_config(key_name TEXT)
RETURNS TEXT AS $$
DECLARE
    result TEXT;
BEGIN
    SELECT config_value INTO result
    FROM governance.system_config
    WHERE config_key = key_name;
    
    RETURN result;
END;
$$ language 'plpgsql';

-- Função para definir configuração
CREATE OR REPLACE FUNCTION governance.set_config(key_name TEXT, value_text TEXT, type_name TEXT DEFAULT 'string')
RETURNS void AS $$
BEGIN
    INSERT INTO governance.system_config (config_key, config_value, config_type)
    VALUES (key_name, value_text, type_name)
    ON CONFLICT (config_key) 
    DO UPDATE SET 
        config_value = EXCLUDED.config_value,
        config_type = EXCLUDED.config_type,
        updated_at = CURRENT_TIMESTAMP;
END;
$$ language 'plpgsql';

-- Função para registrar métrica
CREATE OR REPLACE FUNCTION monitoring.record_metric(
    name TEXT, 
    value NUMERIC, 
    type TEXT DEFAULT 'gauge',
    labels JSONB DEFAULT '{}'
)
RETURNS void AS $$
BEGIN
    INSERT INTO monitoring.metrics (metric_name, metric_value, metric_type, labels)
    VALUES (name, value, type, labels);
END;
$$ language 'plpgsql';

-- Função para health check
CREATE OR REPLACE FUNCTION monitoring.record_health_check(
    service TEXT,
    status TEXT,
    response_time INTEGER DEFAULT NULL,
    error TEXT DEFAULT NULL,
    metadata JSONB DEFAULT '{}'
)
RETURNS void AS $$
BEGIN
    INSERT INTO monitoring.health_checks (service_name, status, response_time_ms, error_message, metadata)
    VALUES (service, status, response_time, error, metadata);
END;
$$ language 'plpgsql';

-- Criar usuário para aplicação (se não existir)
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'governance_app') THEN
        CREATE ROLE governance_app LOGIN PASSWORD 'governance_app_password';
    END IF;
END
$$;

-- Conceder permissões
GRANT USAGE ON SCHEMA governance TO governance_app;
GRANT USAGE ON SCHEMA audit TO governance_app;
GRANT USAGE ON SCHEMA monitoring TO governance_app;

GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA governance TO governance_app;
GRANT SELECT, INSERT ON ALL TABLES IN SCHEMA audit TO governance_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA monitoring TO governance_app;

GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA governance TO governance_app;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA audit TO governance_app;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA monitoring TO governance_app;

-- Configurar permissões padrão para objetos futuros
ALTER DEFAULT PRIVILEGES IN SCHEMA governance GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO governance_app;
ALTER DEFAULT PRIVILEGES IN SCHEMA audit GRANT SELECT, INSERT ON TABLES TO governance_app;
ALTER DEFAULT PRIVILEGES IN SCHEMA monitoring GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO governance_app;

-- Criar job de limpeza automática (executar diariamente)
-- Nota: Requer extensão pg_cron para funcionar automaticamente
-- SELECT cron.schedule('cleanup-old-data', '0 2 * * *', 'SELECT governance.cleanup_old_data();');

-- Inserir dados iniciais de teste
INSERT INTO monitoring.health_checks (service_name, status, response_time_ms) VALUES
('governance-api', 'healthy', 150),
('postgresql', 'healthy', 25),
('unity-catalog-connector', 'healthy', 300),
('axon-connector', 'healthy', 450),
('datahub-connector', 'healthy', 200);

INSERT INTO monitoring.metrics (metric_name, metric_value, metric_type, labels) VALUES
('api_requests_total', 1000, 'counter', '{"endpoint": "/api/v1/entities"}'),
('api_response_time_seconds', 0.150, 'histogram', '{"endpoint": "/api/v1/entities"}'),
('database_connections_active', 5, 'gauge', '{"database": "governanca_dados"}'),
('sync_jobs_total', 50, 'counter', '{"connector": "unity_catalog"}'),
('quality_rules_executed', 892, 'counter', '{"status": "success"}');

-- Comentários nas tabelas principais
COMMENT ON SCHEMA governance IS 'Schema principal para dados de governança';
COMMENT ON SCHEMA audit IS 'Schema para logs de auditoria';
COMMENT ON SCHEMA monitoring IS 'Schema para métricas e monitoramento';

COMMENT ON TABLE governance.system_config IS 'Configurações do sistema parametrizáveis';
COMMENT ON TABLE audit.audit_log IS 'Log de auditoria de todas as operações';
COMMENT ON TABLE monitoring.metrics IS 'Métricas de performance e uso';
COMMENT ON TABLE governance.sync_jobs IS 'Jobs de sincronização com sistemas externos';
COMMENT ON TABLE monitoring.health_checks IS 'Verificações de saúde dos serviços';

-- Finalização
SELECT 'Setup do banco de dados concluído com sucesso!' as status;
SELECT 'Configuração de sincronização: ' || governance.get_config('sync_interval_minutes') || ' minutos' as sync_config;

