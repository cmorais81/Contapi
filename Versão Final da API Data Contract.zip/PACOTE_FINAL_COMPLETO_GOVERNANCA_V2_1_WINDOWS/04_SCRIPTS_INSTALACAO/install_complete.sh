#!/bin/bash

# Script de Instalação Completa - Solução de Governança de Dados V1.0
# Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
# Organização: F1rst Technology Solutions
# Cliente: Banco Santander
# Data: Julho 2025
# Versão: 1.0.0 Final

set -e

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Função para log
log() {
    echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}"
}

error() {
    echo -e "${RED}[ERROR] $1${NC}"
    exit 1
}

warning() {
    echo -e "${YELLOW}[WARNING] $1${NC}"
}

info() {
    echo -e "${BLUE}[INFO] $1${NC}"
}

# Verificar se está rodando como root
if [[ $EUID -eq 0 ]]; then
   error "Este script não deve ser executado como root"
fi

# Configurações padrão
DB_NAME="governanca_dados"
DB_USER="postgres"
DB_PASSWORD="postgres"
DB_HOST="localhost"
DB_PORT="5432"
API_PORT="8000"
PYTHON_VERSION="3.13"

log "Iniciando instalação da Solução de Governança de Dados V1.0"

# 1. Verificar pré-requisitos
log "Verificando pré-requisitos..."

# Verificar Python 3.13
if ! command -v python3.13 &> /dev/null; then
    warning "Python 3.13 não encontrado. Tentando instalar..."
    sudo apt update
    sudo apt install -y software-properties-common
    sudo add-apt-repository -y ppa:deadsnakes/ppa
    sudo apt update
    sudo apt install -y python3.13 python3.13-venv python3.13-dev
fi

# Verificar pip
if ! command -v pip3 &> /dev/null; then
    warning "pip não encontrado. Instalando..."
    sudo apt install -y python3-pip
fi

# Verificar PostgreSQL
if ! command -v psql &> /dev/null; then
    warning "PostgreSQL não encontrado. Instalando..."
    sudo apt update
    sudo apt install -y postgresql postgresql-contrib
    sudo systemctl start postgresql
    sudo systemctl enable postgresql
fi

# Verificar Docker (opcional)
if ! command -v docker &> /dev/null; then
    info "Docker não encontrado. Instalação opcional..."
    read -p "Deseja instalar Docker? (y/n): " install_docker
    if [[ $install_docker == "y" ]]; then
        curl -fsSL https://get.docker.com -o get-docker.sh
        sudo sh get-docker.sh
        sudo usermod -aG docker $USER
        log "Docker instalado. Faça logout/login para usar sem sudo"
    fi
fi

# 2. Configurar ambiente Python
log "Configurando ambiente Python..."

cd "$(dirname "$0")/../01_CODIGO_FONTE"

# Criar ambiente virtual
if [ ! -d "venv" ]; then
    python3.13 -m venv venv
fi

# Ativar ambiente virtual
source venv/bin/activate

# Atualizar pip
pip install --upgrade pip

# Instalar dependências
log "Instalando dependências Python..."
pip install -r requirements.txt

# 3. Configurar banco de dados
log "Configurando banco de dados PostgreSQL..."

# Configurar usuário postgres
sudo -u postgres psql -c "ALTER USER postgres PASSWORD '$DB_PASSWORD';" || true

# Criar banco de dados
sudo -u postgres createdb $DB_NAME || warning "Banco $DB_NAME já existe"

# Configurar variáveis de ambiente
cat > .env << EOF
# Configurações do Banco de Dados
DATABASE_URL=postgresql://$DB_USER:$DB_PASSWORD@$DB_HOST:$DB_PORT/$DB_NAME
DB_HOST=$DB_HOST
DB_PORT=$DB_PORT
DB_NAME=$DB_NAME
DB_USER=$DB_USER
DB_PASSWORD=$DB_PASSWORD

# Configurações da API
SECRET_KEY=$(openssl rand -hex 32)
ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=30
API_PORT=$API_PORT

# Configurações de Ambiente
ENVIRONMENT=development
DEBUG=true
LOG_LEVEL=INFO

# Configurações de Sincronização (20 minutos por padrão)
SYNC_INTERVAL_MINUTES=20
UNITY_CATALOG_SYNC_ENABLED=true
AXON_SYNC_ENABLED=true
DATAHUB_SYNC_ENABLED=true

# Configurações de Conectores
UNITY_CATALOG_ENDPOINT=https://workspace.cloud.databricks.com
AXON_ENDPOINT=https://axon.santander.com.br
DATAHUB_ENDPOINT=https://datahub.santander.com.br

# Configurações de ML
ML_MODELS_PATH=./models
ML_TRAINING_ENABLED=true
ANOMALY_DETECTION_THRESHOLD=0.1

# Configurações de Monitoramento
PROMETHEUS_ENABLED=true
GRAFANA_ENABLED=true
METRICS_PORT=9090

# Configurações de Backup
BACKUP_ENABLED=true
BACKUP_INTERVAL_HOURS=6
BACKUP_RETENTION_DAYS=30
EOF

log "Arquivo .env criado com configurações padrão"

# 4. Executar migrações do banco
log "Executando migrações do banco de dados..."

# Instalar Alembic se não estiver instalado
pip install alembic

# Inicializar Alembic se necessário
if [ ! -d "alembic" ]; then
    alembic init alembic
    
    # Configurar alembic.ini
    sed -i "s|sqlalchemy.url = driver://user:pass@localhost/dbname|sqlalchemy.url = postgresql://$DB_USER:$DB_PASSWORD@$DB_HOST:$DB_PORT/$DB_NAME|" alembic.ini
fi

# Executar migrações
alembic upgrade head || warning "Erro nas migrações - continuando..."

# 5. Criar estrutura de dados inicial
log "Criando estrutura de dados inicial..."

# Executar script de criação de dados de teste
python3.13 create_test_data.py

# 6. Configurar serviços do sistema
log "Configurando serviços do sistema..."

# Criar arquivo de serviço systemd
sudo tee /etc/systemd/system/governance-api.service > /dev/null << EOF
[Unit]
Description=Governance API Service
After=network.target postgresql.service

[Service]
Type=simple
User=$USER
WorkingDirectory=$(pwd)
Environment=PATH=$(pwd)/venv/bin
ExecStart=$(pwd)/venv/bin/uvicorn src.main:app --host 0.0.0.0 --port $API_PORT
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

# Recarregar systemd e habilitar serviço
sudo systemctl daemon-reload
sudo systemctl enable governance-api

# 7. Configurar nginx (opcional)
if command -v nginx &> /dev/null; then
    log "Configurando nginx..."
    
    sudo tee /etc/nginx/sites-available/governance-api > /dev/null << EOF
server {
    listen 80;
    server_name localhost;
    
    location / {
        proxy_pass http://127.0.0.1:$API_PORT;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
    
    location /health {
        proxy_pass http://127.0.0.1:$API_PORT/health;
        access_log off;
    }
}
EOF
    
    sudo ln -sf /etc/nginx/sites-available/governance-api /etc/nginx/sites-enabled/
    sudo nginx -t && sudo systemctl reload nginx
fi

# 8. Configurar monitoramento (opcional)
if command -v docker &> /dev/null; then
    log "Configurando monitoramento com Docker..."
    
    # Criar docker-compose para monitoramento
    cat > docker-compose.monitoring.yml << EOF
version: '3.8'

services:
  prometheus:
    image: prom/prometheus:latest
    container_name: governance-prometheus
    ports:
      - "9090:9090"
    volumes:
      - ./monitoring/prometheus.yml:/etc/prometheus/prometheus.yml
    command:
      - '--config.file=/etc/prometheus/prometheus.yml'
      - '--storage.tsdb.path=/prometheus'
      - '--web.console.libraries=/etc/prometheus/console_libraries'
      - '--web.console.templates=/etc/prometheus/consoles'
    restart: unless-stopped

  grafana:
    image: grafana/grafana:latest
    container_name: governance-grafana
    ports:
      - "3000:3000"
    environment:
      - GF_SECURITY_ADMIN_PASSWORD=admin
    volumes:
      - grafana-storage:/var/lib/grafana
    restart: unless-stopped

volumes:
  grafana-storage:
EOF

    # Criar configuração do Prometheus
    mkdir -p monitoring
    cat > monitoring/prometheus.yml << EOF
global:
  scrape_interval: 15s

scrape_configs:
  - job_name: 'governance-api'
    static_configs:
      - targets: ['host.docker.internal:$API_PORT']
    metrics_path: '/metrics'
    scrape_interval: 5s
EOF

    info "Para iniciar monitoramento: docker-compose -f docker-compose.monitoring.yml up -d"
fi

# 9. Executar testes básicos
log "Executando testes básicos..."

# Instalar pytest se não estiver instalado
pip install pytest pytest-cov

# Executar testes unitários básicos
python3.13 -m pytest tests/ -v --tb=short || warning "Alguns testes falharam - continuando..."

# 10. Iniciar serviços
log "Iniciando serviços..."

# Iniciar API
sudo systemctl start governance-api

# Aguardar inicialização
sleep 10

# Verificar se API está funcionando
if curl -f http://localhost:$API_PORT/health > /dev/null 2>&1; then
    log "API iniciada com sucesso!"
else
    error "Falha ao iniciar API. Verifique os logs: sudo journalctl -u governance-api -f"
fi

# 11. Exibir informações finais
log "Instalação concluída com sucesso!"

echo
echo "=========================================="
echo "  SOLUÇÃO DE GOVERNANÇA DE DADOS V1.0"
echo "=========================================="
echo
echo "API URL: http://localhost:$API_PORT"
echo "Documentação: http://localhost:$API_PORT/docs"
echo "Health Check: http://localhost:$API_PORT/health"
echo
echo "Banco de Dados:"
echo "  Host: $DB_HOST:$DB_PORT"
echo "  Database: $DB_NAME"
echo "  User: $DB_USER"
echo
echo "Configurações:"
echo "  Sincronização: $SYNC_INTERVAL_MINUTES minutos"
echo "  Ambiente: development"
echo "  Logs: sudo journalctl -u governance-api -f"
echo
echo "Comandos úteis:"
echo "  Parar API: sudo systemctl stop governance-api"
echo "  Iniciar API: sudo systemctl start governance-api"
echo "  Status API: sudo systemctl status governance-api"
echo "  Logs API: sudo journalctl -u governance-api -f"
echo
echo "Próximos passos:"
echo "1. Acesse http://localhost:$API_PORT/docs para ver a documentação"
echo "2. Configure os conectores externos no arquivo .env"
echo "3. Execute python3.13 generate_test_report.py para relatórios"
echo "4. Configure monitoramento: docker-compose -f docker-compose.monitoring.yml up -d"
echo
echo "Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)"
echo "Organização: F1rst Technology Solutions"
echo "=========================================="

log "Instalação finalizada!"

