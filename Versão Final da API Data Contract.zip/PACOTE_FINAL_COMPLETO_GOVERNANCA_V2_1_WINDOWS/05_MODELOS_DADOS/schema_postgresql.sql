-- Schema PostgreSQL - Solução de Governança de Dados V1.0
-- Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
-- Organização: F1rst Technology Solutions
-- Cliente: Banco Santander
-- Data: Julho 2025
-- Versão: 1.0.0 Final
-- Total: 58 tabelas organizadas por módulos

-- Configurações iniciais
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

-- Criar extensões necessárias
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================================================
-- MÓDULO 1: AUTENTICAÇÃO E AUTORIZAÇÃO (5 tabelas)
-- ============================================================================

-- Tabela de usuários
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(255) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    is_superuser BOOLEAN DEFAULT FALSE,
    last_login TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de sessões de usuário
CREATE TABLE user_sessions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    session_token VARCHAR(255) UNIQUE NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    ip_address INET,
    user_agent TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de roles de segurança
CREATE TABLE security_roles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) UNIQUE NOT NULL,
    description TEXT,
    permissions JSONB DEFAULT '[]',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de relacionamento usuário-role
CREATE TABLE user_roles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    role_id UUID NOT NULL REFERENCES security_roles(id) ON DELETE CASCADE,
    granted_by UUID REFERENCES users(id),
    granted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP,
    UNIQUE(user_id, role_id)
);

-- Tabela de API keys
CREATE TABLE api_keys (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    key_name VARCHAR(255) NOT NULL,
    key_hash VARCHAR(255) UNIQUE NOT NULL,
    permissions JSONB DEFAULT '[]',
    is_active BOOLEAN DEFAULT TRUE,
    expires_at TIMESTAMP,
    last_used TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- MÓDULO 2: CONTRATOS DE DADOS (3 tabelas)
-- ============================================================================

-- Tabela de contratos de dados
CREATE TABLE data_contracts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    version VARCHAR(50) NOT NULL,
    description TEXT,
    owner_id UUID NOT NULL REFERENCES users(id),
    status VARCHAR(50) DEFAULT 'draft',
    contract_schema JSONB NOT NULL,
    sla_requirements JSONB DEFAULT '{}',
    data_classification VARCHAR(50),
    retention_policy JSONB DEFAULT '{}',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(name, version)
);

-- Tabela de versões de contratos
CREATE TABLE contract_versions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    contract_id UUID NOT NULL REFERENCES data_contracts(id) ON DELETE CASCADE,
    version_number VARCHAR(50) NOT NULL,
    changes_summary TEXT,
    schema_diff JSONB,
    created_by UUID NOT NULL REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de aprovações de contratos
CREATE TABLE contract_approvals (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    contract_id UUID NOT NULL REFERENCES data_contracts(id) ON DELETE CASCADE,
    approver_id UUID NOT NULL REFERENCES users(id),
    approval_status VARCHAR(50) NOT NULL,
    comments TEXT,
    approved_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- MÓDULO 3: ENTIDADES E CATÁLOGO (6 tabelas)
-- ============================================================================

-- Tabela de entidades
CREATE TABLE entities (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    entity_type VARCHAR(100) NOT NULL,
    description TEXT,
    owner_id UUID REFERENCES users(id),
    source_system VARCHAR(255),
    database_name VARCHAR(255),
    schema_name VARCHAR(255),
    table_name VARCHAR(255),
    full_path TEXT,
    metadata JSONB DEFAULT '{}',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de atributos de entidades
CREATE TABLE entity_attributes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    entity_id UUID NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    data_type VARCHAR(100),
    is_nullable BOOLEAN DEFAULT TRUE,
    is_primary_key BOOLEAN DEFAULT FALSE,
    description TEXT,
    business_rules JSONB DEFAULT '[]',
    sensitivity_level VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de relacionamentos entre entidades
CREATE TABLE entity_relationships (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    source_entity_id UUID NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
    target_entity_id UUID NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
    relationship_type VARCHAR(100) NOT NULL,
    description TEXT,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de tags de entidades
CREATE TABLE entity_tags (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    entity_id UUID NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
    tag_name VARCHAR(255) NOT NULL,
    tag_value VARCHAR(255),
    tag_type VARCHAR(100) DEFAULT 'custom',
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(entity_id, tag_name)
);

-- Tabela de estatísticas de uso de entidades
CREATE TABLE entity_usage_stats (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    entity_id UUID NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
    access_count INTEGER DEFAULT 0,
    last_accessed TIMESTAMP,
    accessed_by UUID REFERENCES users(id),
    access_type VARCHAR(100),
    query_complexity VARCHAR(50),
    recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de entradas do catálogo
CREATE TABLE catalog_entries (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    entity_id UUID NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
    title VARCHAR(255) NOT NULL,
    summary TEXT,
    documentation TEXT,
    business_glossary JSONB DEFAULT '{}',
    technical_metadata JSONB DEFAULT '{}',
    is_published BOOLEAN DEFAULT FALSE,
    published_by UUID REFERENCES users(id),
    published_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- MÓDULO 4: QUALIDADE DE DADOS (3 tabelas)
-- ============================================================================

-- Tabela de regras de qualidade
CREATE TABLE quality_rules (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    rule_type VARCHAR(100) NOT NULL,
    entity_id UUID REFERENCES entities(id),
    attribute_name VARCHAR(255),
    rule_definition JSONB NOT NULL,
    threshold_config JSONB DEFAULT '{}',
    is_active BOOLEAN DEFAULT TRUE,
    severity VARCHAR(50) DEFAULT 'medium',
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de métricas de qualidade
CREATE TABLE quality_metrics (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    rule_id UUID NOT NULL REFERENCES quality_rules(id) ON DELETE CASCADE,
    entity_id UUID NOT NULL REFERENCES entities(id),
    metric_name VARCHAR(255) NOT NULL,
    metric_value NUMERIC NOT NULL,
    threshold_value NUMERIC,
    status VARCHAR(50) NOT NULL,
    execution_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    metadata JSONB DEFAULT '{}'
);

-- Tabela de issues de qualidade de dados
CREATE TABLE data_quality_issues (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    rule_id UUID NOT NULL REFERENCES quality_rules(id),
    entity_id UUID NOT NULL REFERENCES entities(id),
    issue_type VARCHAR(100) NOT NULL,
    severity VARCHAR(50) NOT NULL,
    description TEXT,
    affected_records INTEGER,
    sample_data JSONB,
    status VARCHAR(50) DEFAULT 'open',
    assigned_to UUID REFERENCES users(id),
    resolved_at TIMESTAMP,
    resolution_notes TEXT,
    detected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- MÓDULO 5: LINEAGE DE DADOS (3 tabelas)
-- ============================================================================

-- Tabela de lineage de dados
CREATE TABLE data_lineage (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    source_entity_id UUID NOT NULL REFERENCES entities(id),
    target_entity_id UUID NOT NULL REFERENCES entities(id),
    lineage_type VARCHAR(100) NOT NULL,
    transformation_logic TEXT,
    confidence_score NUMERIC DEFAULT 1.0,
    discovered_method VARCHAR(100),
    metadata JSONB DEFAULT '{}',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de lineage de atributos
CREATE TABLE lineage_attributes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    lineage_id UUID NOT NULL REFERENCES data_lineage(id) ON DELETE CASCADE,
    source_attribute VARCHAR(255),
    target_attribute VARCHAR(255),
    transformation_rule TEXT,
    confidence_score NUMERIC DEFAULT 1.0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de análise de impacto
CREATE TABLE impact_analysis (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    entity_id UUID NOT NULL REFERENCES entities(id),
    analysis_type VARCHAR(100) NOT NULL,
    impact_scope VARCHAR(100),
    affected_entities JSONB DEFAULT '[]',
    impact_score NUMERIC,
    analysis_results JSONB DEFAULT '{}',
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- MÓDULO 6: POLÍTICAS DE GOVERNANÇA (3 tabelas)
-- ============================================================================

-- Tabela de políticas de governança
CREATE TABLE governance_policies (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    policy_type VARCHAR(100) NOT NULL,
    scope VARCHAR(100),
    policy_rules JSONB NOT NULL,
    compliance_framework VARCHAR(100),
    enforcement_level VARCHAR(50) DEFAULT 'warning',
    is_active BOOLEAN DEFAULT TRUE,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de violações de políticas
CREATE TABLE policy_violations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    policy_id UUID NOT NULL REFERENCES governance_policies(id),
    entity_id UUID REFERENCES entities(id),
    violation_type VARCHAR(100) NOT NULL,
    severity VARCHAR(50) NOT NULL,
    description TEXT,
    violation_details JSONB DEFAULT '{}',
    status VARCHAR(50) DEFAULT 'open',
    assigned_to UUID REFERENCES users(id),
    resolved_at TIMESTAMP,
    resolution_notes TEXT,
    detected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de relatórios de compliance
CREATE TABLE compliance_reports (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    report_name VARCHAR(255) NOT NULL,
    framework VARCHAR(100) NOT NULL,
    report_period_start DATE NOT NULL,
    report_period_end DATE NOT NULL,
    compliance_score NUMERIC,
    total_policies INTEGER,
    compliant_policies INTEGER,
    violations_count INTEGER,
    report_data JSONB DEFAULT '{}',
    generated_by UUID REFERENCES users(id),
    generated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- MÓDULO 7: DATA STEWARDSHIP (3 tabelas)
-- ============================================================================

-- Tabela de data stewards
CREATE TABLE data_stewards (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id),
    steward_type VARCHAR(100) NOT NULL,
    expertise_areas JSONB DEFAULT '[]',
    responsibility_scope VARCHAR(255),
    contact_info JSONB DEFAULT '{}',
    is_active BOOLEAN DEFAULT TRUE,
    appointed_by UUID REFERENCES users(id),
    appointed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de atribuições de stewardship
CREATE TABLE steward_assignments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    steward_id UUID NOT NULL REFERENCES data_stewards(id),
    entity_id UUID NOT NULL REFERENCES entities(id),
    assignment_type VARCHAR(100) NOT NULL,
    responsibilities JSONB DEFAULT '[]',
    priority VARCHAR(50) DEFAULT 'medium',
    assigned_by UUID REFERENCES users(id),
    assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP,
    UNIQUE(steward_id, entity_id)
);

-- Tabela de atividades de stewardship
CREATE TABLE steward_activities (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    steward_id UUID NOT NULL REFERENCES data_stewards(id),
    entity_id UUID REFERENCES entities(id),
    activity_type VARCHAR(100) NOT NULL,
    description TEXT,
    activity_details JSONB DEFAULT '{}',
    status VARCHAR(50) DEFAULT 'completed',
    effort_hours NUMERIC,
    performed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- MÓDULO 8: TAGS E CLASSIFICAÇÃO (2 tabelas)
-- ============================================================================

-- Tabela de tags
CREATE TABLE tags (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) UNIQUE NOT NULL,
    description TEXT,
    tag_category VARCHAR(100),
    color VARCHAR(7),
    icon VARCHAR(100),
    is_system_tag BOOLEAN DEFAULT FALSE,
    parent_tag_id UUID REFERENCES tags(id),
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de hierarquia de tags
CREATE TABLE tag_hierarchy (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    parent_tag_id UUID NOT NULL REFERENCES tags(id),
    child_tag_id UUID NOT NULL REFERENCES tags(id),
    hierarchy_level INTEGER DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(parent_tag_id, child_tag_id)
);

-- ============================================================================
-- MÓDULO 9: WORKFLOWS (3 tabelas)
-- ============================================================================

-- Tabela de definições de workflow
CREATE TABLE workflow_definitions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    workflow_type VARCHAR(100) NOT NULL,
    definition JSONB NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    version VARCHAR(50) DEFAULT '1.0',
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de instâncias de workflow
CREATE TABLE workflow_instances (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    definition_id UUID NOT NULL REFERENCES workflow_definitions(id),
    entity_id UUID REFERENCES entities(id),
    status VARCHAR(50) DEFAULT 'running',
    current_step VARCHAR(255),
    input_data JSONB DEFAULT '{}',
    output_data JSONB DEFAULT '{}',
    error_message TEXT,
    started_by UUID REFERENCES users(id),
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP
);

-- Tabela de steps de workflow
CREATE TABLE workflow_steps (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    instance_id UUID NOT NULL REFERENCES workflow_instances(id) ON DELETE CASCADE,
    step_name VARCHAR(255) NOT NULL,
    step_type VARCHAR(100) NOT NULL,
    status VARCHAR(50) DEFAULT 'pending',
    input_data JSONB DEFAULT '{}',
    output_data JSONB DEFAULT '{}',
    error_message TEXT,
    assigned_to UUID REFERENCES users(id),
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- MÓDULO 10: NOTIFICAÇÕES (3 tabelas)
-- ============================================================================

-- Tabela de notificações
CREATE TABLE notifications (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    recipient_id UUID NOT NULL REFERENCES users(id),
    notification_type VARCHAR(100) NOT NULL,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    priority VARCHAR(50) DEFAULT 'medium',
    channel VARCHAR(50) DEFAULT 'email',
    status VARCHAR(50) DEFAULT 'pending',
    metadata JSONB DEFAULT '{}',
    sent_at TIMESTAMP,
    read_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de preferências de notificação
CREATE TABLE notification_preferences (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id),
    notification_type VARCHAR(100) NOT NULL,
    channel VARCHAR(50) NOT NULL,
    is_enabled BOOLEAN DEFAULT TRUE,
    frequency VARCHAR(50) DEFAULT 'immediate',
    quiet_hours_start TIME,
    quiet_hours_end TIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, notification_type, channel)
);

-- Tabela de regras de alerta
CREATE TABLE alert_rules (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    rule_type VARCHAR(100) NOT NULL,
    condition_config JSONB NOT NULL,
    notification_config JSONB NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    cooldown_minutes INTEGER DEFAULT 60,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- MÓDULO 11: INTEGRAÇÕES EXTERNAS (3 tabelas)
-- ============================================================================

-- Tabela de integrações externas
CREATE TABLE external_integrations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    integration_type VARCHAR(100) NOT NULL,
    endpoint_url VARCHAR(500),
    authentication_config JSONB DEFAULT '{}',
    sync_config JSONB DEFAULT '{}',
    is_active BOOLEAN DEFAULT TRUE,
    last_sync_at TIMESTAMP,
    next_sync_at TIMESTAMP,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de mapeamentos de integração
CREATE TABLE integration_mappings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    integration_id UUID NOT NULL REFERENCES external_integrations(id) ON DELETE CASCADE,
    source_field VARCHAR(255) NOT NULL,
    target_field VARCHAR(255) NOT NULL,
    transformation_rule TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de jobs de sincronização
CREATE TABLE sync_jobs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    integration_id UUID NOT NULL REFERENCES external_integrations(id),
    job_type VARCHAR(100) NOT NULL,
    status VARCHAR(50) DEFAULT 'pending',
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    records_processed INTEGER DEFAULT 0,
    records_success INTEGER DEFAULT 0,
    records_failed INTEGER DEFAULT 0,
    error_message TEXT,
    job_metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- MÓDULO 12: CONFIGURAÇÕES DO SISTEMA (3 tabelas)
-- ============================================================================

-- Tabela de configurações do sistema
CREATE TABLE system_configurations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    config_key VARCHAR(255) UNIQUE NOT NULL,
    config_value TEXT NOT NULL,
    config_type VARCHAR(50) DEFAULT 'string',
    description TEXT,
    is_encrypted BOOLEAN DEFAULT FALSE,
    is_system_config BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de feature flags
CREATE TABLE feature_flags (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    flag_name VARCHAR(255) UNIQUE NOT NULL,
    description TEXT,
    is_enabled BOOLEAN DEFAULT FALSE,
    rollout_percentage INTEGER DEFAULT 0,
    target_users JSONB DEFAULT '[]',
    conditions JSONB DEFAULT '{}',
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de dashboards de monitoramento
CREATE TABLE monitoring_dashboards (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    dashboard_type VARCHAR(100) NOT NULL,
    config JSONB NOT NULL,
    is_public BOOLEAN DEFAULT FALSE,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- MÓDULO 13: BACKUP E RECUPERAÇÃO (3 tabelas)
-- ============================================================================

-- Tabela de políticas de backup
CREATE TABLE backup_policies (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    backup_type VARCHAR(100) NOT NULL,
    schedule_config JSONB NOT NULL,
    retention_config JSONB NOT NULL,
    storage_config JSONB NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de execuções de backup
CREATE TABLE backup_executions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    policy_id UUID NOT NULL REFERENCES backup_policies(id),
    backup_name VARCHAR(255) NOT NULL,
    status VARCHAR(50) DEFAULT 'running',
    backup_size_bytes BIGINT,
    backup_location VARCHAR(500),
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP,
    error_message TEXT,
    metadata JSONB DEFAULT '{}'
);

-- Tabela de planos de disaster recovery
CREATE TABLE disaster_recovery_plans (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    plan_type VARCHAR(100) NOT NULL,
    rto_minutes INTEGER,
    rpo_minutes INTEGER,
    recovery_procedures JSONB NOT NULL,
    test_schedule JSONB DEFAULT '{}',
    last_tested_at TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- MÓDULO 14: RETENÇÃO E EXPURGO (2 tabelas)
-- ============================================================================

-- Tabela de políticas de retenção de dados
CREATE TABLE data_retention_policies (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    entity_id UUID REFERENCES entities(id),
    retention_period_days INTEGER NOT NULL,
    retention_criteria JSONB DEFAULT '{}',
    action_on_expiry VARCHAR(100) DEFAULT 'archive',
    is_active BOOLEAN DEFAULT TRUE,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de log de deleção de dados
CREATE TABLE data_deletion_log (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    policy_id UUID NOT NULL REFERENCES data_retention_policies(id),
    entity_id UUID REFERENCES entities(id),
    deletion_type VARCHAR(100) NOT NULL,
    records_deleted INTEGER,
    deletion_criteria JSONB DEFAULT '{}',
    executed_by UUID REFERENCES users(id),
    executed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    metadata JSONB DEFAULT '{}'
);

-- ============================================================================
-- MÓDULO 15: PERFORMANCE E MÉTRICAS (3 tabelas)
-- ============================================================================

-- Tabela de métricas de performance
CREATE TABLE performance_metrics (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    metric_name VARCHAR(255) NOT NULL,
    metric_type VARCHAR(100) NOT NULL,
    metric_value NUMERIC NOT NULL,
    entity_id UUID REFERENCES entities(id),
    labels JSONB DEFAULT '{}',
    recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de métricas de negócio
CREATE TABLE business_metrics (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    metric_name VARCHAR(255) NOT NULL,
    metric_category VARCHAR(100),
    metric_value NUMERIC NOT NULL,
    target_value NUMERIC,
    unit VARCHAR(50),
    calculation_method TEXT,
    data_sources JSONB DEFAULT '[]',
    calculated_by UUID REFERENCES users(id),
    calculated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de cálculos de métricas
CREATE TABLE metric_calculations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    metric_id UUID REFERENCES business_metrics(id),
    calculation_date DATE NOT NULL,
    input_data JSONB DEFAULT '{}',
    calculation_result NUMERIC,
    calculation_status VARCHAR(50) DEFAULT 'completed',
    execution_time_ms INTEGER,
    error_message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- MÓDULO 16: MASCARAMENTO DE DADOS (1 tabela)
-- ============================================================================

-- Tabela de regras de mascaramento de dados
CREATE TABLE data_masking_rules (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    entity_id UUID NOT NULL REFERENCES entities(id),
    attribute_name VARCHAR(255) NOT NULL,
    masking_type VARCHAR(100) NOT NULL,
    masking_config JSONB NOT NULL,
    conditions JSONB DEFAULT '{}',
    is_active BOOLEAN DEFAULT TRUE,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- MÓDULO 17: GESTÃO DE TEMPERATURA (3 tabelas)
-- ============================================================================

-- Tabela de políticas de temperatura de dados
CREATE TABLE data_temperature_policies (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    entity_id UUID REFERENCES entities(id),
    temperature_rules JSONB NOT NULL,
    storage_tiers JSONB NOT NULL,
    migration_schedule JSONB DEFAULT '{}',
    is_active BOOLEAN DEFAULT TRUE,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de migrações de storage
CREATE TABLE storage_migrations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    policy_id UUID NOT NULL REFERENCES data_temperature_policies(id),
    entity_id UUID NOT NULL REFERENCES entities(id),
    source_tier VARCHAR(100) NOT NULL,
    target_tier VARCHAR(100) NOT NULL,
    migration_status VARCHAR(50) DEFAULT 'pending',
    data_size_bytes BIGINT,
    cost_savings NUMERIC,
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    error_message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de padrões de acesso a dados
CREATE TABLE data_access_patterns (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    entity_id UUID NOT NULL REFERENCES entities(id),
    access_frequency VARCHAR(100),
    last_access_date DATE,
    access_count_30d INTEGER DEFAULT 0,
    access_count_90d INTEGER DEFAULT 0,
    access_count_365d INTEGER DEFAULT 0,
    average_query_time_ms INTEGER,
    data_temperature VARCHAR(50),
    calculated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- MÓDULO 18: DOMÍNIOS DE DADOS (1 tabela)
-- ============================================================================

-- Tabela de domínios
CREATE TABLE domains (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) UNIQUE NOT NULL,
    description TEXT,
    domain_owner_id UUID REFERENCES users(id),
    business_area VARCHAR(255),
    governance_model JSONB DEFAULT '{}',
    data_products JSONB DEFAULT '[]',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- MÓDULO 19: GLOSSÁRIO DE NEGÓCIO (1 tabela)
-- ============================================================================

-- Tabela de glossário
CREATE TABLE glossary (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    term VARCHAR(255) UNIQUE NOT NULL,
    definition TEXT NOT NULL,
    business_context TEXT,
    synonyms JSONB DEFAULT '[]',
    related_terms JSONB DEFAULT '[]',
    domain_id UUID REFERENCES domains(id),
    owner_id UUID REFERENCES users(id),
    status VARCHAR(50) DEFAULT 'draft',
    approved_by UUID REFERENCES users(id),
    approved_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- MÓDULO 20: ANALYTICS E BUSCA (2 tabelas)
-- ============================================================================

-- Tabela de consultas de analytics
CREATE TABLE analytics_queries (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    query_name VARCHAR(255),
    query_text TEXT NOT NULL,
    query_type VARCHAR(100),
    executed_by UUID REFERENCES users(id),
    execution_time_ms INTEGER,
    result_count INTEGER,
    entities_accessed JSONB DEFAULT '[]',
    executed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de índices de busca
CREATE TABLE search_indexes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    entity_id UUID NOT NULL REFERENCES entities(id),
    searchable_content TEXT NOT NULL,
    content_type VARCHAR(100),
    boost_factor NUMERIC DEFAULT 1.0,
    last_indexed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    index_version VARCHAR(50) DEFAULT '1.0'
);

-- ============================================================================
-- MÓDULO 21: AUDITORIA (2 tabelas)
-- ============================================================================

-- Tabela de log de auditoria
CREATE TABLE audit_log (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    table_name VARCHAR(255) NOT NULL,
    record_id UUID,
    operation VARCHAR(50) NOT NULL,
    old_values JSONB,
    new_values JSONB,
    user_id UUID REFERENCES users(id),
    ip_address INET,
    user_agent TEXT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de trilha de auditoria
CREATE TABLE audit_trail (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    entity_id UUID REFERENCES entities(id),
    action VARCHAR(255) NOT NULL,
    action_details JSONB DEFAULT '{}',
    performed_by UUID REFERENCES users(id),
    performed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ip_address INET,
    session_id VARCHAR(255)
);

-- ============================================================================
-- ÍNDICES PARA PERFORMANCE
-- ============================================================================

-- Índices para autenticação
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_user_sessions_token ON user_sessions(session_token);
CREATE INDEX idx_user_sessions_user_id ON user_sessions(user_id);
CREATE INDEX idx_api_keys_hash ON api_keys(key_hash);

-- Índices para entidades
CREATE INDEX idx_entities_name ON entities(name);
CREATE INDEX idx_entities_type ON entities(entity_type);
CREATE INDEX idx_entities_owner ON entities(owner_id);
CREATE INDEX idx_entity_attributes_entity_id ON entity_attributes(entity_id);

-- Índices para qualidade
CREATE INDEX idx_quality_rules_entity_id ON quality_rules(entity_id);
CREATE INDEX idx_quality_metrics_rule_id ON quality_metrics(rule_id);
CREATE INDEX idx_quality_issues_entity_id ON data_quality_issues(entity_id);

-- Índices para lineage
CREATE INDEX idx_lineage_source ON data_lineage(source_entity_id);
CREATE INDEX idx_lineage_target ON data_lineage(target_entity_id);

-- Índices para auditoria
CREATE INDEX idx_audit_log_table_name ON audit_log(table_name);
CREATE INDEX idx_audit_log_timestamp ON audit_log(timestamp);
CREATE INDEX idx_audit_trail_entity_id ON audit_trail(entity_id);

-- Índices para performance
CREATE INDEX idx_performance_metrics_name ON performance_metrics(metric_name);
CREATE INDEX idx_performance_metrics_recorded_at ON performance_metrics(recorded_at);

-- Índices para busca
CREATE INDEX idx_search_indexes_entity_id ON search_indexes(entity_id);
CREATE INDEX idx_search_content_gin ON search_indexes USING gin(to_tsvector('portuguese', searchable_content));

-- ============================================================================
-- TRIGGERS PARA AUDITORIA AUTOMÁTICA
-- ============================================================================

-- Função para trigger de auditoria
CREATE OR REPLACE FUNCTION audit_trigger_function()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'DELETE' THEN
        INSERT INTO audit_log (table_name, record_id, operation, old_values)
        VALUES (TG_TABLE_NAME, OLD.id, TG_OP, row_to_json(OLD));
        RETURN OLD;
    ELSIF TG_OP = 'UPDATE' THEN
        INSERT INTO audit_log (table_name, record_id, operation, old_values, new_values)
        VALUES (TG_TABLE_NAME, NEW.id, TG_OP, row_to_json(OLD), row_to_json(NEW));
        RETURN NEW;
    ELSIF TG_OP = 'INSERT' THEN
        INSERT INTO audit_log (table_name, record_id, operation, new_values)
        VALUES (TG_TABLE_NAME, NEW.id, TG_OP, row_to_json(NEW));
        RETURN NEW;
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Aplicar triggers de auditoria nas tabelas principais
CREATE TRIGGER audit_users AFTER INSERT OR UPDATE OR DELETE ON users
    FOR EACH ROW EXECUTE FUNCTION audit_trigger_function();

CREATE TRIGGER audit_entities AFTER INSERT OR UPDATE OR DELETE ON entities
    FOR EACH ROW EXECUTE FUNCTION audit_trigger_function();

CREATE TRIGGER audit_data_contracts AFTER INSERT OR UPDATE OR DELETE ON data_contracts
    FOR EACH ROW EXECUTE FUNCTION audit_trigger_function();

-- ============================================================================
-- INSERÇÃO DE DADOS INICIAIS
-- ============================================================================

-- Inserir configurações padrão do sistema
INSERT INTO system_configurations (config_key, config_value, config_type, description, is_system_config) VALUES
('sync_interval_minutes', '20', 'integer', 'Intervalo de sincronização padrão em minutos', true),
('unity_catalog_sync_enabled', 'true', 'boolean', 'Habilitar sincronização com Unity Catalog', true),
('axon_sync_enabled', 'true', 'boolean', 'Habilitar sincronização com Informatica Axon', true),
('datahub_sync_enabled', 'true', 'boolean', 'Habilitar sincronização com DataHub', true),
('quality_check_frequency_minutes', '60', 'integer', 'Frequência de verificação de qualidade em minutos', true),
('backup_retention_days', '30', 'integer', 'Retenção de backups em dias', true),
('max_concurrent_sync_jobs', '5', 'integer', 'Máximo de jobs de sincronização simultâneos', true);

-- Inserir roles padrão
INSERT INTO security_roles (name, description, permissions) VALUES
('admin', 'Administrador do sistema', '["*"]'),
('data_steward', 'Data Steward', '["entities:read", "entities:write", "quality:read", "quality:write"]'),
('data_analyst', 'Analista de Dados', '["entities:read", "catalog:read", "analytics:read"]'),
('compliance_officer', 'Oficial de Compliance', '["policies:read", "policies:write", "compliance:read"]'),
('viewer', 'Visualizador', '["entities:read", "catalog:read"]');

-- Inserir tags padrão do sistema
INSERT INTO tags (name, description, tag_category, color, is_system_tag) VALUES
('PII', 'Informação Pessoal Identificável', 'sensitivity', '#FF0000', true),
('Confidential', 'Dados Confidenciais', 'sensitivity', '#FF6600', true),
('Public', 'Dados Públicos', 'sensitivity', '#00FF00', true),
('Financial', 'Dados Financeiros', 'domain', '#0066FF', true),
('Customer', 'Dados de Cliente', 'domain', '#6600FF', true),
('Product', 'Dados de Produto', 'domain', '#FF00FF', true);

-- Comentários nas tabelas
COMMENT ON TABLE users IS 'Usuários do sistema de governança';
COMMENT ON TABLE entities IS 'Entidades de dados catalogadas';
COMMENT ON TABLE data_contracts IS 'Contratos de dados definidos';
COMMENT ON TABLE quality_rules IS 'Regras de qualidade de dados';
COMMENT ON TABLE data_lineage IS 'Relacionamentos de lineage entre entidades';
COMMENT ON TABLE governance_policies IS 'Políticas de governança aplicadas';

-- Finalização
SELECT 'Schema PostgreSQL criado com sucesso! Total: 58 tabelas implementadas.' as status;

