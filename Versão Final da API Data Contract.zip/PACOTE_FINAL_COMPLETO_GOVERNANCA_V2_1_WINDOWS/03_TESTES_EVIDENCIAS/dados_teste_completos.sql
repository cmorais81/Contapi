-- Script SQL Completo para Dados de Teste
-- Solução de Governança de Dados V1.0
-- Data: Julho 2025
-- Organização: F1rst

-- Limpar dados existentes
DELETE FROM user_roles;
DELETE FROM api_keys;
DELETE FROM user_sessions;
DELETE FROM users;
DELETE FROM security_roles;
DELETE FROM contract_approvals;
DELETE FROM contract_versions;
DELETE FROM data_contracts;
DELETE FROM entity_usage_stats;
DELETE FROM entity_tags;
DELETE FROM entity_relationships;
DELETE FROM entity_attributes;
DELETE FROM entities;
DELETE FROM catalog_entries;
DELETE FROM data_quality_issues;
DELETE FROM quality_metrics;
DELETE FROM quality_rules;
DELETE FROM impact_analysis;
DELETE FROM lineage_attributes;
DELETE FROM data_lineage;
DELETE FROM compliance_reports;
DELETE FROM policy_violations;
DELETE FROM governance_policies;
DELETE FROM steward_activities;
DELETE FROM steward_assignments;
DELETE FROM data_stewards;
DELETE FROM tag_hierarchy;
DELETE FROM tags;
DELETE FROM workflow_steps;
DELETE FROM workflow_instances;
DELETE FROM workflow_definitions;
DELETE FROM alert_rules;
DELETE FROM notification_preferences;
DELETE FROM notifications;
DELETE FROM sync_jobs;
DELETE FROM integration_mappings;
DELETE FROM external_integrations;
DELETE FROM monitoring_dashboards;
DELETE FROM feature_flags;
DELETE FROM system_configurations;

-- 1. CONFIGURAÇÕES DO SISTEMA
INSERT INTO system_configurations (config_key, config_value, description, config_type, is_active) VALUES
('sync_interval_minutes', '20', 'Intervalo de sincronização em minutos', 'integer', true),
('max_concurrent_syncs', '5', 'Máximo de sincronizações simultâneas', 'integer', true),
('quality_check_interval', '30', 'Intervalo de verificação de qualidade em minutos', 'integer', true),
('backup_retention_days', '90', 'Dias de retenção de backup', 'integer', true),
('log_level', 'INFO', 'Nível de log da aplicação', 'string', true),
('enable_ml_recommendations', 'true', 'Habilitar recomendações de ML', 'boolean', true),
('max_lineage_depth', '10', 'Profundidade máxima de lineage', 'integer', true),
('notification_cooldown_minutes', '60', 'Tempo de cooldown para notificações', 'integer', true),
('api_rate_limit_per_minute', '1000', 'Limite de requisições por minuto', 'integer', true),
('session_timeout_hours', '8', 'Timeout de sessão em horas', 'integer', true),
('enable_audit_log', 'true', 'Habilitar log de auditoria', 'boolean', true);

-- 2. ROLES DE SEGURANÇA
INSERT INTO security_roles (role_name, description, permissions) VALUES
('admin', 'Administrador do sistema', '["read", "write", "delete", "admin"]'),
('data_steward', 'Responsável pela qualidade dos dados', '["read", "write", "quality_manage"]'),
('data_analyst', 'Analista de dados', '["read", "discover", "analyze"]'),
('compliance_officer', 'Oficial de compliance', '["read", "compliance_manage", "audit"]'),
('data_engineer', 'Engenheiro de dados', '["read", "write", "integrate", "pipeline"]');

-- 3. USUÁRIOS
INSERT INTO users (email, full_name, department, organization, is_active, password_hash) VALUES
('carlos.morais@f1rst.com', 'Carlos Morais', 'Engenharia de Dados', 'F1rst', true, '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhM8/PI.B4t9dAuThuS.Em'),
('ana.silva@f1rst.com', 'Ana Silva', 'Governança de Dados', 'F1rst', true, '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhM8/PI.B4t9dAuThuS.Em'),
('pedro.santos@f1rst.com', 'Pedro Santos', 'Analytics', 'F1rst', true, '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhM8/PI.B4t9dAuThuS.Em'),
('maria.costa@f1rst.com', 'Maria Costa', 'Compliance', 'F1rst', true, '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhM8/PI.B4t9dAuThuS.Em'),
('joao.oliveira@f1rst.com', 'João Oliveira', 'Engenharia de Dados', 'F1rst', true, '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhM8/PI.B4t9dAuThuS.Em'),
('lucia.ferreira@f1rst.com', 'Lúcia Ferreira', 'Governança de Dados', 'F1rst', true, '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhM8/PI.B4t9dAuThuS.Em');

-- 4. ASSOCIAÇÕES DE ROLES
INSERT INTO user_roles (user_id, role_id) VALUES
((SELECT id FROM users WHERE email = 'carlos.morais@f1rst.com'), (SELECT id FROM security_roles WHERE role_name = 'admin')),
((SELECT id FROM users WHERE email = 'ana.silva@f1rst.com'), (SELECT id FROM security_roles WHERE role_name = 'data_steward')),
((SELECT id FROM users WHERE email = 'pedro.santos@f1rst.com'), (SELECT id FROM security_roles WHERE role_name = 'data_analyst')),
((SELECT id FROM users WHERE email = 'maria.costa@f1rst.com'), (SELECT id FROM security_roles WHERE role_name = 'compliance_officer')),
((SELECT id FROM users WHERE email = 'joao.oliveira@f1rst.com'), (SELECT id FROM security_roles WHERE role_name = 'data_engineer')),
((SELECT id FROM users WHERE email = 'lucia.ferreira@f1rst.com'), (SELECT id FROM security_roles WHERE role_name = 'data_steward'));

-- 5. API KEYS
INSERT INTO api_keys (key_name, key_hash, user_id, permissions, is_active) VALUES
('Unity Catalog Integration', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhM8/PI.B4t9dAuThuS.Em', 
 (SELECT id FROM users WHERE email = 'carlos.morais@f1rst.com'), '["read", "write", "integrate"]', true),
('Axon Connector', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhM8/PI.B4t9dAuThuS.Em',
 (SELECT id FROM users WHERE email = 'joao.oliveira@f1rst.com'), '["read", "write", "integrate"]', true),
('Quality Engine', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhM8/PI.B4t9dAuThuS.Em',
 (SELECT id FROM users WHERE email = 'ana.silva@f1rst.com'), '["read", "quality_manage"]', true);

-- 6. CONTRATOS DE DADOS (MÚLTIPLOS COM VERSÕES)
INSERT INTO data_contracts (name, description, owner_id, business_domain, data_domain, status) VALUES
('Contrato Dados Transações Bancárias', 'Contrato para dados de transações do sistema bancário', 
 (SELECT id FROM users WHERE email = 'ana.silva@f1rst.com'), 'Banking', 'Transactions', 'active'),
('Contrato Dados Clientes PF', 'Contrato para dados de clientes pessoa física',
 (SELECT id FROM users WHERE email = 'lucia.ferreira@f1rst.com'), 'Banking', 'Customers', 'active'),
('Contrato Dados Produtos Financeiros', 'Contrato para dados de produtos e serviços financeiros',
 (SELECT id FROM users WHERE email = 'ana.silva@f1rst.com'), 'Banking', 'Products', 'active'),
('Contrato Dados Compliance LGPD', 'Contrato para dados de compliance e auditoria LGPD',
 (SELECT id FROM users WHERE email = 'maria.costa@f1rst.com'), 'Compliance', 'Audit', 'active'),
('Contrato Dados Analytics', 'Contrato para dados de analytics e métricas de negócio',
 (SELECT id FROM users WHERE email = 'pedro.santos@f1rst.com'), 'Analytics', 'Metrics', 'draft');

-- 7. VERSÕES DOS CONTRATOS (MÚLTIPLAS VERSÕES ATIVAS)
INSERT INTO contract_versions (contract_id, version_number, schema_definition, sla_requirements, quality_requirements, status) VALUES
-- Contrato Transações - Versão 1.0 (ativa)
((SELECT id FROM data_contracts WHERE name = 'Contrato Dados Transações Bancárias'), '1.0',
 '{"type": "object", "properties": {"transaction_id": {"type": "string"}, "amount": {"type": "number"}, "currency": {"type": "string"}, "timestamp": {"type": "string", "format": "datetime"}}}',
 '{"availability": "99.9%", "latency": "< 100ms", "throughput": "> 1000 tps"}',
 '{"completeness": "> 99%", "accuracy": "> 98%", "consistency": "> 99%"}', 'active'),
-- Contrato Transações - Versão 1.1 (ativa - múltiplas versões ativas)
((SELECT id FROM data_contracts WHERE name = 'Contrato Dados Transações Bancárias'), '1.1',
 '{"type": "object", "properties": {"transaction_id": {"type": "string"}, "amount": {"type": "number"}, "currency": {"type": "string"}, "timestamp": {"type": "string", "format": "datetime"}, "merchant_id": {"type": "string"}}}',
 '{"availability": "99.95%", "latency": "< 80ms", "throughput": "> 1500 tps"}',
 '{"completeness": "> 99.5%", "accuracy": "> 99%", "consistency": "> 99.5%"}', 'active'),
-- Contrato Clientes PF - Versão 1.0 (ativa)
((SELECT id FROM data_contracts WHERE name = 'Contrato Dados Clientes PF'), '1.0',
 '{"type": "object", "properties": {"customer_id": {"type": "string"}, "cpf": {"type": "string"}, "name": {"type": "string"}, "email": {"type": "string"}, "phone": {"type": "string"}}}',
 '{"availability": "99.9%", "latency": "< 200ms", "throughput": "> 500 tps"}',
 '{"completeness": "> 98%", "accuracy": "> 99%", "consistency": "> 98%"}', 'active'),
-- Contrato Clientes PF - Versão 2.0 (ativa - versão com LGPD)
((SELECT id FROM data_contracts WHERE name = 'Contrato Dados Clientes PF'), '2.0',
 '{"type": "object", "properties": {"customer_id": {"type": "string"}, "cpf": {"type": "string", "pii": true}, "name": {"type": "string", "pii": true}, "email": {"type": "string", "pii": true}, "phone": {"type": "string", "pii": true}, "consent_date": {"type": "string", "format": "datetime"}}}',
 '{"availability": "99.95%", "latency": "< 150ms", "throughput": "> 800 tps"}',
 '{"completeness": "> 99%", "accuracy": "> 99.5%", "consistency": "> 99%", "privacy": "LGPD compliant"}', 'active'),
-- Contrato Produtos - Versão 1.0 (ativa)
((SELECT id FROM data_contracts WHERE name = 'Contrato Dados Produtos Financeiros'), '1.0',
 '{"type": "object", "properties": {"product_id": {"type": "string"}, "product_name": {"type": "string"}, "category": {"type": "string"}, "interest_rate": {"type": "number"}}}',
 '{"availability": "99.8%", "latency": "< 300ms", "throughput": "> 200 tps"}',
 '{"completeness": "> 95%", "accuracy": "> 98%", "consistency": "> 97%"}', 'active'),
-- Contrato Compliance - Versão 1.0 (ativa)
((SELECT id FROM data_contracts WHERE name = 'Contrato Dados Compliance LGPD'), '1.0',
 '{"type": "object", "properties": {"audit_id": {"type": "string"}, "event_type": {"type": "string"}, "user_id": {"type": "string"}, "timestamp": {"type": "string", "format": "datetime"}, "data_subject": {"type": "string"}}}',
 '{"availability": "99.99%", "latency": "< 50ms", "throughput": "> 100 tps"}',
 '{"completeness": "> 100%", "accuracy": "> 100%", "consistency": "> 100%", "retention": "7 years"}', 'active'),
-- Contrato Analytics - Versão 1.0 (draft)
((SELECT id FROM data_contracts WHERE name = 'Contrato Dados Analytics'), '1.0',
 '{"type": "object", "properties": {"metric_id": {"type": "string"}, "metric_name": {"type": "string"}, "value": {"type": "number"}, "dimension": {"type": "string"}, "timestamp": {"type": "string", "format": "datetime"}}}',
 '{"availability": "99.5%", "latency": "< 500ms", "throughput": "> 50 tps"}',
 '{"completeness": "> 90%", "accuracy": "> 95%", "consistency": "> 90%"}', 'draft');

-- 8. APROVAÇÕES DOS CONTRATOS
INSERT INTO contract_approvals (contract_version_id, approver_id, approval_status, comments) VALUES
-- Aprovações para Transações V1.0
((SELECT id FROM contract_versions WHERE version_number = '1.0' AND contract_id = (SELECT id FROM data_contracts WHERE name = 'Contrato Dados Transações Bancárias')),
 (SELECT id FROM users WHERE email = 'carlos.morais@f1rst.com'), 'approved', 'Contrato aprovado para produção'),
-- Aprovações para Transações V1.1
((SELECT id FROM contract_versions WHERE version_number = '1.1' AND contract_id = (SELECT id FROM data_contracts WHERE name = 'Contrato Dados Transações Bancárias')),
 (SELECT id FROM users WHERE email = 'carlos.morais@f1rst.com'), 'approved', 'Nova versão com merchant_id aprovada'),
-- Aprovações para Clientes V1.0
((SELECT id FROM contract_versions WHERE version_number = '1.0' AND contract_id = (SELECT id FROM data_contracts WHERE name = 'Contrato Dados Clientes PF')),
 (SELECT id FROM users WHERE email = 'ana.silva@f1rst.com'), 'approved', 'Contrato base aprovado'),
-- Aprovações para Clientes V2.0
((SELECT id FROM contract_versions WHERE version_number = '2.0' AND contract_id = (SELECT id FROM data_contracts WHERE name = 'Contrato Dados Clientes PF')),
 (SELECT id FROM users WHERE email = 'maria.costa@f1rst.com'), 'approved', 'Versão LGPD compliant aprovada'),
-- Aprovações para Produtos
((SELECT id FROM contract_versions WHERE version_number = '1.0' AND contract_id = (SELECT id FROM data_contracts WHERE name = 'Contrato Dados Produtos Financeiros')),
 (SELECT id FROM users WHERE email = 'ana.silva@f1rst.com'), 'approved', 'Contrato de produtos aprovado'),
-- Aprovações para Compliance
((SELECT id FROM contract_versions WHERE version_number = '1.0' AND contract_id = (SELECT id FROM data_contracts WHERE name = 'Contrato Dados Compliance LGPD')),
 (SELECT id FROM users WHERE email = 'maria.costa@f1rst.com'), 'approved', 'Contrato de compliance crítico aprovado');

-- 9. ENTIDADES DO CATÁLOGO
INSERT INTO entities (name, description, entity_type, database_name, schema_name, table_name, owner_id, business_domain, technical_domain, sensitivity_level, data_classification) VALUES
('Transações Bancárias', 'Tabela principal de transações do sistema bancário', 'table', 'banking_prod', 'transactions', 'tb_transactions', 
 (SELECT id FROM users WHERE email = 'carlos.morais@f1rst.com'), 'Banking', 'Core Banking', 'high', 'confidential'),
('Clientes Pessoa Física', 'Dados de clientes pessoa física', 'table', 'banking_prod', 'customers', 'tb_customers_pf',
 (SELECT id FROM users WHERE email = 'ana.silva@f1rst.com'), 'Banking', 'Customer Management', 'high', 'restricted'),
('Produtos Financeiros', 'Catálogo de produtos e serviços financeiros', 'table', 'banking_prod', 'products', 'tb_products',
 (SELECT id FROM users WHERE email = 'pedro.santos@f1rst.com'), 'Banking', 'Product Management', 'medium', 'internal'),
('Auditoria LGPD', 'Log de auditoria para compliance LGPD', 'table', 'compliance_prod', 'audit', 'tb_lgpd_audit',
 (SELECT id FROM users WHERE email = 'maria.costa@f1rst.com'), 'Compliance', 'Audit', 'high', 'restricted'),
('Métricas de Negócio', 'Métricas e KPIs de negócio', 'view', 'analytics_prod', 'metrics', 'vw_business_metrics',
 (SELECT id FROM users WHERE email = 'pedro.santos@f1rst.com'), 'Analytics', 'Business Intelligence', 'medium', 'internal'),
('Dados de Risco', 'Dados de análise de risco de crédito', 'table', 'risk_prod', 'analysis', 'tb_credit_risk',
 (SELECT id FROM users WHERE email = 'joao.oliveira@f1rst.com'), 'Risk Management', 'Credit Analysis', 'high', 'confidential'),
('Histórico Transações', 'Dados históricos de transações para analytics', 'table', 'analytics_prod', 'history', 'tb_transaction_history',
 (SELECT id FROM users WHERE email = 'pedro.santos@f1rst.com'), 'Analytics', 'Data Warehouse', 'medium', 'internal');

-- 10. ATRIBUTOS DAS ENTIDADES
INSERT INTO entity_attributes (entity_id, attribute_name, data_type, is_nullable, is_primary_key, description, business_rules, sensitivity_level) VALUES
-- Atributos Transações
((SELECT id FROM entities WHERE name = 'Transações Bancárias'), 'transaction_id', 'VARCHAR(50)', false, true, 'Identificador único da transação', 'Formato: TXN-YYYYMMDD-NNNNNN', 'low'),
((SELECT id FROM entities WHERE name = 'Transações Bancárias'), 'customer_id', 'VARCHAR(20)', false, false, 'ID do cliente', 'FK para tb_customers_pf', 'medium'),
((SELECT id FROM entities WHERE name = 'Transações Bancárias'), 'amount', 'DECIMAL(15,2)', false, false, 'Valor da transação', 'Sempre positivo, máximo 1.000.000', 'medium'),
((SELECT id FROM entities WHERE name = 'Transações Bancárias'), 'currency', 'VARCHAR(3)', false, false, 'Moeda da transação', 'Código ISO 4217 (BRL, USD, EUR)', 'low'),
((SELECT id FROM entities WHERE name = 'Transações Bancárias'), 'transaction_date', 'TIMESTAMP', false, false, 'Data e hora da transação', 'UTC timezone', 'low'),
((SELECT id FROM entities WHERE name = 'Transações Bancárias'), 'merchant_id', 'VARCHAR(20)', true, false, 'ID do estabelecimento', 'Opcional para transferências', 'medium'),
-- Atributos Clientes
((SELECT id FROM entities WHERE name = 'Clientes Pessoa Física'), 'customer_id', 'VARCHAR(20)', false, true, 'Identificador único do cliente', 'Formato: CLI-NNNNNNNN', 'low'),
((SELECT id FROM entities WHERE name = 'Clientes Pessoa Física'), 'cpf', 'VARCHAR(11)', false, false, 'CPF do cliente', 'Apenas números, validação algoritmo', 'high'),
((SELECT id FROM entities WHERE name = 'Clientes Pessoa Física'), 'full_name', 'VARCHAR(200)', false, false, 'Nome completo', 'Mínimo 2 palavras', 'high'),
((SELECT id FROM entities WHERE name = 'Clientes Pessoa Física'), 'email', 'VARCHAR(100)', false, false, 'Email principal', 'Formato válido, único', 'high'),
((SELECT id FROM entities WHERE name = 'Clientes Pessoa Física'), 'phone', 'VARCHAR(15)', true, false, 'Telefone principal', 'Formato: +55NNNNNNNNNN', 'medium'),
((SELECT id FROM entities WHERE name = 'Clientes Pessoa Física'), 'birth_date', 'DATE', false, false, 'Data de nascimento', 'Idade mínima 18 anos', 'high'),
-- Atributos Produtos
((SELECT id FROM entities WHERE name = 'Produtos Financeiros'), 'product_id', 'VARCHAR(20)', false, true, 'ID do produto', 'Formato: PRD-NNNNNN', 'low'),
((SELECT id FROM entities WHERE name = 'Produtos Financeiros'), 'product_name', 'VARCHAR(100)', false, false, 'Nome do produto', 'Único por categoria', 'low'),
((SELECT id FROM entities WHERE name = 'Produtos Financeiros'), 'category', 'VARCHAR(50)', false, false, 'Categoria do produto', 'Conta, Cartão, Empréstimo, Investimento', 'low'),
((SELECT id FROM entities WHERE name = 'Produtos Financeiros'), 'interest_rate', 'DECIMAL(5,4)', true, false, 'Taxa de juros', 'Percentual anual, 0-100%', 'medium');

-- 11. RELACIONAMENTOS ENTRE ENTIDADES
INSERT INTO entity_relationships (source_entity_id, target_entity_id, relationship_type, description, cardinality) VALUES
((SELECT id FROM entities WHERE name = 'Transações Bancárias'), (SELECT id FROM entities WHERE name = 'Clientes Pessoa Física'), 'foreign_key', 'Transação pertence a um cliente', 'many_to_one'),
((SELECT id FROM entities WHERE name = 'Clientes Pessoa Física'), (SELECT id FROM entities WHERE name = 'Auditoria LGPD'), 'foreign_key', 'Cliente tem logs de auditoria', 'one_to_many'),
((SELECT id FROM entities WHERE name = 'Transações Bancárias'), (SELECT id FROM entities WHERE name = 'Histórico Transações'), 'derived', 'Histórico derivado das transações', 'one_to_one');

-- 12. TAGS DE CLASSIFICAÇÃO
INSERT INTO tags (name, description, color, icon, tag_type, is_system_tag) VALUES
('PII', 'Informação Pessoal Identificável', '#FF6B6B', 'shield', 'classification', true),
('LGPD', 'Dados sujeitos à LGPD', '#4ECDC4', 'legal', 'compliance', true),
('Financeiro', 'Dados financeiros sensíveis', '#45B7D1', 'dollar', 'business', false),
('Transacional', 'Dados de transações', '#96CEB4', 'exchange', 'business', false),
('Analytics', 'Dados para análise', '#FFEAA7', 'chart', 'usage', false),
('Crítico', 'Dados críticos para negócio', '#FD79A8', 'alert', 'priority', true),
('Histórico', 'Dados históricos', '#A29BFE', 'clock', 'temporal', false);

-- 13. ASSOCIAÇÕES DE TAGS
INSERT INTO entity_tags (entity_id, tag_id) VALUES
-- Transações
((SELECT id FROM entities WHERE name = 'Transações Bancárias'), (SELECT id FROM tags WHERE name = 'Financeiro')),
((SELECT id FROM entities WHERE name = 'Transações Bancárias'), (SELECT id FROM tags WHERE name = 'Transacional')),
((SELECT id FROM entities WHERE name = 'Transações Bancárias'), (SELECT id FROM tags WHERE name = 'Crítico')),
-- Clientes
((SELECT id FROM entities WHERE name = 'Clientes Pessoa Física'), (SELECT id FROM tags WHERE name = 'PII')),
((SELECT id FROM entities WHERE name = 'Clientes Pessoa Física'), (SELECT id FROM tags WHERE name = 'LGPD')),
((SELECT id FROM entities WHERE name = 'Clientes Pessoa Física'), (SELECT id FROM tags WHERE name = 'Crítico')),
-- Produtos
((SELECT id FROM entities WHERE name = 'Produtos Financeiros'), (SELECT id FROM tags WHERE name = 'Financeiro')),
-- Auditoria
((SELECT id FROM entities WHERE name = 'Auditoria LGPD'), (SELECT id FROM tags WHERE name = 'LGPD')),
((SELECT id FROM entities WHERE name = 'Auditoria LGPD'), (SELECT id FROM tags WHERE name = 'Crítico')),
-- Métricas
((SELECT id FROM entities WHERE name = 'Métricas de Negócio'), (SELECT id FROM tags WHERE name = 'Analytics')),
-- Histórico
((SELECT id FROM entities WHERE name = 'Histórico Transações'), (SELECT id FROM tags WHERE name = 'Histórico')),
((SELECT id FROM entities WHERE name = 'Histórico Transações'), (SELECT id FROM tags WHERE name = 'Analytics'));

-- 14. REGRAS DE QUALIDADE
INSERT INTO quality_rules (name, description, rule_type, entity_id, attribute_name, rule_definition, severity, is_active) VALUES
('Validação CPF', 'Validação de formato e algoritmo do CPF', 'format', 
 (SELECT id FROM entities WHERE name = 'Clientes Pessoa Física'), 'cpf', 
 '{"pattern": "^[0-9]{11}$", "algorithm": "cpf_validation"}', 'high', true),
('Email Válido', 'Validação de formato de email', 'format',
 (SELECT id FROM entities WHERE name = 'Clientes Pessoa Física'), 'email',
 '{"pattern": "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$"}', 'medium', true),
('Valor Transação Positivo', 'Valor da transação deve ser positivo', 'range',
 (SELECT id FROM entities WHERE name = 'Transações Bancárias'), 'amount',
 '{"min": 0.01, "max": 1000000}', 'high', true),
('Completude Nome', 'Nome deve estar preenchido', 'completeness',
 (SELECT id FROM entities WHERE name = 'Clientes Pessoa Física'), 'full_name',
 '{"required": true, "min_length": 5}', 'high', true),
('Moeda Válida', 'Código de moeda deve ser válido', 'enum',
 (SELECT id FROM entities WHERE name = 'Transações Bancárias'), 'currency',
 '{"allowed_values": ["BRL", "USD", "EUR"]}', 'medium', true),
('Data Nascimento Válida', 'Cliente deve ser maior de idade', 'range',
 (SELECT id FROM entities WHERE name = 'Clientes Pessoa Física'), 'birth_date',
 '{"max_date": "today-18years"}', 'high', true);

-- 15. MÉTRICAS DE QUALIDADE
INSERT INTO quality_metrics (entity_id, attribute_name, metric_type, metric_value, total_records, measurement_date, rule_id) VALUES
-- Métricas Clientes
((SELECT id FROM entities WHERE name = 'Clientes Pessoa Física'), 'cpf', 'validity', 98.5, 125000, CURRENT_TIMESTAMP,
 (SELECT id FROM quality_rules WHERE name = 'Validação CPF')),
((SELECT id FROM entities WHERE name = 'Clientes Pessoa Física'), 'email', 'validity', 97.2, 125000, CURRENT_TIMESTAMP,
 (SELECT id FROM quality_rules WHERE name = 'Email Válido')),
((SELECT id FROM entities WHERE name = 'Clientes Pessoa Física'), 'full_name', 'completeness', 99.8, 125000, CURRENT_TIMESTAMP,
 (SELECT id FROM quality_rules WHERE name = 'Completude Nome')),
-- Métricas Transações
((SELECT id FROM entities WHERE name = 'Transações Bancárias'), 'amount', 'validity', 99.9, 2500000, CURRENT_TIMESTAMP,
 (SELECT id FROM quality_rules WHERE name = 'Valor Transação Positivo')),
((SELECT id FROM entities WHERE name = 'Transações Bancárias'), 'currency', 'validity', 100.0, 2500000, CURRENT_TIMESTAMP,
 (SELECT id FROM quality_rules WHERE name = 'Moeda Válida'));

-- 16. ISSUES DE QUALIDADE
INSERT INTO data_quality_issues (entity_id, attribute_name, issue_type, description, severity, status, detected_date, rule_id) VALUES
((SELECT id FROM entities WHERE name = 'Clientes Pessoa Física'), 'cpf', 'invalid_format', 'CPF com formato inválido encontrado', 'high', 'open', CURRENT_TIMESTAMP - INTERVAL '2 days',
 (SELECT id FROM quality_rules WHERE name = 'Validação CPF')),
((SELECT id FROM entities WHERE name = 'Clientes Pessoa Física'), 'email', 'invalid_format', 'Email com formato inválido', 'medium', 'resolved', CURRENT_TIMESTAMP - INTERVAL '1 day',
 (SELECT id FROM quality_rules WHERE name = 'Email Válido')),
((SELECT id FROM entities WHERE name = 'Transações Bancárias'), 'amount', 'out_of_range', 'Valor de transação fora do range permitido', 'high', 'open', CURRENT_TIMESTAMP - INTERVAL '3 hours',
 (SELECT id FROM quality_rules WHERE name = 'Valor Transação Positivo'));

-- 17. LINEAGE DE DADOS
INSERT INTO data_lineage (source_entity_id, target_entity_id, lineage_type, transformation_logic, confidence_score, detected_date) VALUES
((SELECT id FROM entities WHERE name = 'Transações Bancárias'), (SELECT id FROM entities WHERE name = 'Histórico Transações'), 'direct', 
 'INSERT INTO tb_transaction_history SELECT * FROM tb_transactions WHERE transaction_date < CURRENT_DATE - INTERVAL ''30 days''', 95.0, CURRENT_TIMESTAMP),
((SELECT id FROM entities WHERE name = 'Clientes Pessoa Física'), (SELECT id FROM entities WHERE name = 'Métricas de Negócio'), 'aggregation',
 'SELECT COUNT(*) as total_customers, AVG(EXTRACT(YEAR FROM CURRENT_DATE) - EXTRACT(YEAR FROM birth_date)) as avg_age FROM tb_customers_pf', 90.0, CURRENT_TIMESTAMP),
((SELECT id FROM entities WHERE name = 'Transações Bancárias'), (SELECT id FROM entities WHERE name = 'Métricas de Negócio'), 'aggregation',
 'SELECT SUM(amount) as total_volume, COUNT(*) as total_transactions FROM tb_transactions WHERE transaction_date >= CURRENT_DATE', 92.0, CURRENT_TIMESTAMP);

-- 18. LINEAGE DE ATRIBUTOS
INSERT INTO lineage_attributes (lineage_id, source_attribute, target_attribute, transformation_rule) VALUES
((SELECT id FROM data_lineage WHERE source_entity_id = (SELECT id FROM entities WHERE name = 'Transações Bancárias') AND target_entity_id = (SELECT id FROM entities WHERE name = 'Histórico Transações')),
 'transaction_id', 'transaction_id', 'DIRECT_COPY'),
((SELECT id FROM data_lineage WHERE source_entity_id = (SELECT id FROM entities WHERE name = 'Transações Bancárias') AND target_entity_id = (SELECT id FROM entities WHERE name = 'Histórico Transações')),
 'amount', 'amount', 'DIRECT_COPY'),
((SELECT id FROM data_lineage WHERE source_entity_id = (SELECT id FROM entities WHERE name = 'Clientes Pessoa Física') AND target_entity_id = (SELECT id FROM entities WHERE name = 'Métricas de Negócio')),
 'customer_id', 'total_customers', 'COUNT(*)');

-- 19. POLÍTICAS DE GOVERNANÇA
INSERT INTO governance_policies (name, description, policy_type, scope, compliance_framework, policy_rules, severity, is_active) VALUES
('Política LGPD Dados Pessoais', 'Política de proteção de dados pessoais conforme LGPD', 'privacy', 'organization', 'LGPD',
 '{"data_retention": "5 years", "consent_required": true, "anonymization": "required_after_retention", "access_control": "strict"}', 'high', true),
('Política Retenção Dados Financeiros', 'Política de retenção para dados financeiros', 'retention', 'domain', 'BACEN',
 '{"retention_period": "10 years", "backup_required": true, "archive_after": "2 years", "deletion_approval": "required"}', 'high', true),
('Política Qualidade Dados Críticos', 'Política de qualidade para dados críticos de negócio', 'quality', 'entity', 'Internal',
 '{"min_completeness": 99, "min_accuracy": 98, "max_staleness": "1 hour", "validation_required": true}', 'high', true),
('Política Acesso Dados Sensíveis', 'Política de controle de acesso a dados sensíveis', 'access', 'attribute', 'SOX',
 '{"role_based_access": true, "audit_required": true, "encryption_required": true, "masking_for_non_prod": true}', 'high', true);

-- 20. VIOLAÇÕES DE POLÍTICAS
INSERT INTO policy_violations (policy_id, entity_id, violation_type, description, severity, status, detected_date) VALUES
((SELECT id FROM governance_policies WHERE name = 'Política LGPD Dados Pessoais'), 
 (SELECT id FROM entities WHERE name = 'Clientes Pessoa Física'), 'data_retention', 
 'Dados pessoais retidos além do período permitido', 'high', 'open', CURRENT_TIMESTAMP - INTERVAL '1 day'),
((SELECT id FROM governance_policies WHERE name = 'Política Qualidade Dados Críticos'),
 (SELECT id FROM entities WHERE name = 'Transações Bancárias'), 'quality_threshold',
 'Qualidade dos dados abaixo do threshold mínimo', 'medium', 'in_progress', CURRENT_TIMESTAMP - INTERVAL '6 hours'),
((SELECT id FROM governance_policies WHERE name = 'Política Acesso Dados Sensíveis'),
 (SELECT id FROM entities WHERE name = 'Clientes Pessoa Física'), 'unauthorized_access',
 'Acesso não autorizado detectado', 'high', 'resolved', CURRENT_TIMESTAMP - INTERVAL '2 days');

-- 21. DATA STEWARDS
INSERT INTO data_stewards (user_id, expertise_areas, certification_level, contact_info) VALUES
((SELECT id FROM users WHERE email = 'ana.silva@f1rst.com'), '["Data Quality", "LGPD Compliance", "Banking Domain"]', 'senior', 
 '{"phone": "+5511999887766", "slack": "@ana.silva", "teams": "ana.silva@f1rst.com"}'),
((SELECT id FROM users WHERE email = 'lucia.ferreira@f1rst.com'), '["Customer Data", "Data Privacy", "Audit"]', 'senior',
 '{"phone": "+5511999887755", "slack": "@lucia.ferreira", "teams": "lucia.ferreira@f1rst.com"}'),
((SELECT id FROM users WHERE email = 'maria.costa@f1rst.com'), '["Compliance", "Risk Management", "Regulatory"]', 'expert',
 '{"phone": "+5511999887744", "slack": "@maria.costa", "teams": "maria.costa@f1rst.com"}');

-- 22. ATRIBUIÇÕES DE STEWARDSHIP
INSERT INTO steward_assignments (steward_id, entity_id, assignment_type, responsibility_level, start_date) VALUES
((SELECT id FROM data_stewards WHERE user_id = (SELECT id FROM users WHERE email = 'ana.silva@f1rst.com')),
 (SELECT id FROM entities WHERE name = 'Transações Bancárias'), 'primary', 'full', CURRENT_DATE - INTERVAL '6 months'),
((SELECT id FROM data_stewards WHERE user_id = (SELECT id FROM users WHERE email = 'lucia.ferreira@f1rst.com')),
 (SELECT id FROM entities WHERE name = 'Clientes Pessoa Física'), 'primary', 'full', CURRENT_DATE - INTERVAL '1 year'),
((SELECT id FROM data_stewards WHERE user_id = (SELECT id FROM users WHERE email = 'maria.costa@f1rst.com')),
 (SELECT id FROM entities WHERE name = 'Auditoria LGPD'), 'primary', 'full', CURRENT_DATE - INTERVAL '8 months'),
((SELECT id FROM data_stewards WHERE user_id = (SELECT id FROM users WHERE email = 'ana.silva@f1rst.com')),
 (SELECT id FROM entities WHERE name = 'Produtos Financeiros'), 'secondary', 'quality_only', CURRENT_DATE - INTERVAL '3 months');

-- 23. ATIVIDADES DE STEWARDSHIP
INSERT INTO steward_activities (steward_id, entity_id, activity_type, description, impact_level, activity_date) VALUES
((SELECT id FROM data_stewards WHERE user_id = (SELECT id FROM users WHERE email = 'ana.silva@f1rst.com')),
 (SELECT id FROM entities WHERE name = 'Transações Bancárias'), 'quality_improvement',
 'Implementação de nova regra de validação para valores de transação', 'high', CURRENT_TIMESTAMP - INTERVAL '2 days'),
((SELECT id FROM data_stewards WHERE user_id = (SELECT id FROM users WHERE email = 'lucia.ferreira@f1rst.com')),
 (SELECT id FROM entities WHERE name = 'Clientes Pessoa Física'), 'compliance_review',
 'Revisão de compliance LGPD para dados de clientes', 'high', CURRENT_TIMESTAMP - INTERVAL '1 week'),
((SELECT id FROM data_stewards WHERE user_id = (SELECT id FROM users WHERE email = 'maria.costa@f1rst.com')),
 (SELECT id FROM entities WHERE name = 'Auditoria LGPD'), 'policy_update',
 'Atualização de política de retenção de dados de auditoria', 'medium', CURRENT_TIMESTAMP - INTERVAL '3 days');

-- 24. INTEGRAÇÕES EXTERNAS
INSERT INTO external_integrations (name, integration_type, endpoint_url, authentication_config, sync_schedule, is_active, health_status) VALUES
('Unity Catalog Databricks', 'unity_catalog', 'https://workspace.cloud.databricks.com', 
 '{"auth_type": "bearer_token", "token_endpoint": "/api/2.0/token"}', '*/20 * * * *', true, 'healthy'),
('Informatica Axon', 'axon', 'https://axon.informatica.com/api/v1',
 '{"auth_type": "oauth2", "client_id": "axon_client", "scope": "metadata:read"}', '*/20 * * * *', true, 'healthy'),
('DataHub LinkedIn', 'datahub', 'https://datahub.f1rst.com/api/v1',
 '{"auth_type": "api_key", "key_header": "X-API-Key"}', '*/20 * * * *', true, 'warning');

-- 25. MAPEAMENTOS DE INTEGRAÇÃO
INSERT INTO integration_mappings (integration_id, source_path, target_entity_id, mapping_rules, is_active) VALUES
((SELECT id FROM external_integrations WHERE name = 'Unity Catalog Databricks'),
 'banking_prod.transactions.tb_transactions', (SELECT id FROM entities WHERE name = 'Transações Bancárias'),
 '{"column_mappings": {"id": "transaction_id", "valor": "amount", "data_transacao": "transaction_date"}}', true),
((SELECT id FROM external_integrations WHERE name = 'Unity Catalog Databricks'),
 'banking_prod.customers.tb_customers_pf', (SELECT id FROM entities WHERE name = 'Clientes Pessoa Física'),
 '{"column_mappings": {"id": "customer_id", "documento": "cpf", "nome_completo": "full_name"}}', true),
((SELECT id FROM external_integrations WHERE name = 'Informatica Axon'),
 '/metadata/tables/banking/transactions', (SELECT id FROM entities WHERE name = 'Transações Bancárias'),
 '{"metadata_sync": true, "lineage_sync": true, "quality_sync": false}', true);

-- 26. JOBS DE SINCRONIZAÇÃO
INSERT INTO sync_jobs (integration_id, job_type, status, start_time, end_time, records_processed, errors_count, job_details) VALUES
((SELECT id FROM external_integrations WHERE name = 'Unity Catalog Databricks'), 'metadata_sync', 'completed',
 CURRENT_TIMESTAMP - INTERVAL '25 minutes', CURRENT_TIMESTAMP - INTERVAL '23 minutes', 1250, 0,
 '{"tables_synced": 15, "columns_synced": 180, "lineage_discovered": 8}'),
((SELECT id FROM external_integrations WHERE name = 'Informatica Axon'), 'metadata_sync', 'completed',
 CURRENT_TIMESTAMP - INTERVAL '22 minutes', CURRENT_TIMESTAMP - INTERVAL '20 minutes', 850, 2,
 '{"assets_synced": 12, "relationships_synced": 25, "warnings": ["timeout on 2 assets"]}'),
((SELECT id FROM external_integrations WHERE name = 'DataHub LinkedIn'), 'lineage_sync', 'running',
 CURRENT_TIMESTAMP - INTERVAL '5 minutes', NULL, 0, 0,
 '{"progress": "45%", "current_entity": "tb_customers_pf"}');

-- 27. NOTIFICAÇÕES
INSERT INTO notifications (user_id, notification_type, title, message, priority, status, created_date) VALUES
((SELECT id FROM users WHERE email = 'ana.silva@f1rst.com'), 'quality_alert',
 'Alerta de Qualidade - Transações', 'Detectada queda na qualidade dos dados de transações (97.2%)', 'high', 'unread', CURRENT_TIMESTAMP - INTERVAL '2 hours'),
((SELECT id FROM users WHERE email = 'maria.costa@f1rst.com'), 'compliance_alert',
 'Violação LGPD Detectada', 'Dados pessoais retidos além do período permitido', 'high', 'read', CURRENT_TIMESTAMP - INTERVAL '1 day'),
((SELECT id FROM users WHERE email = 'carlos.morais@f1rst.com'), 'system_alert',
 'Sincronização Unity Catalog', 'Sincronização com Unity Catalog concluída com sucesso', 'medium', 'read', CURRENT_TIMESTAMP - INTERVAL '25 minutes'),
((SELECT id FROM users WHERE email = 'lucia.ferreira@f1rst.com'), 'workflow_notification',
 'Aprovação Pendente', 'Contrato de dados aguardando sua aprovação', 'medium', 'unread', CURRENT_TIMESTAMP - INTERVAL '4 hours');

-- 28. PREFERÊNCIAS DE NOTIFICAÇÃO
INSERT INTO notification_preferences (user_id, notification_type, channel, is_enabled, frequency) VALUES
((SELECT id FROM users WHERE email = 'ana.silva@f1rst.com'), 'quality_alert', 'email', true, 'immediate'),
((SELECT id FROM users WHERE email = 'ana.silva@f1rst.com'), 'quality_alert', 'slack', true, 'immediate'),
((SELECT id FROM users WHERE email = 'maria.costa@f1rst.com'), 'compliance_alert', 'email', true, 'immediate'),
((SELECT id FROM users WHERE email = 'maria.costa@f1rst.com'), 'compliance_alert', 'teams', true, 'immediate'),
((SELECT id FROM users WHERE email = 'carlos.morais@f1rst.com'), 'system_alert', 'email', true, 'daily_digest'),
((SELECT id FROM users WHERE email = 'pedro.santos@f1rst.com'), 'workflow_notification', 'email', true, 'immediate');

-- Commit das transações
COMMIT;

-- Verificação final dos dados inseridos
SELECT 'Configurações do Sistema' as tabela, COUNT(*) as registros FROM system_configurations
UNION ALL
SELECT 'Usuários', COUNT(*) FROM users
UNION ALL
SELECT 'Contratos de Dados', COUNT(*) FROM data_contracts
UNION ALL
SELECT 'Versões de Contratos', COUNT(*) FROM contract_versions
UNION ALL
SELECT 'Entidades', COUNT(*) FROM entities
UNION ALL
SELECT 'Atributos de Entidades', COUNT(*) FROM entity_attributes
UNION ALL
SELECT 'Regras de Qualidade', COUNT(*) FROM quality_rules
UNION ALL
SELECT 'Métricas de Qualidade', COUNT(*) FROM quality_metrics
UNION ALL
SELECT 'Lineage de Dados', COUNT(*) FROM data_lineage
UNION ALL
SELECT 'Políticas de Governança', COUNT(*) FROM governance_policies
UNION ALL
SELECT 'Data Stewards', COUNT(*) FROM data_stewards
UNION ALL
SELECT 'Integrações Externas', COUNT(*) FROM external_integrations
UNION ALL
SELECT 'Notificações', COUNT(*) FROM notifications
ORDER BY tabela;

