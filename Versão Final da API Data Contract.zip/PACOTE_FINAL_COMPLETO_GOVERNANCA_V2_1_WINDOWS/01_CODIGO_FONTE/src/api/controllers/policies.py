"""
Controller de Políticas de Governança - V2.2 com Banco de Dados
API de Governança de Dados V2.2
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from fastapi import APIRouter, HTTPException, Depends, Query
from typing import List, Optional, Dict, Any
from uuid import UUID
from sqlalchemy.orm import Session
import logging

from src.database.connection import get_database_session
from src.database.models.policies import GovernancePolicy, PolicyViolation, ComplianceReport
from src.database.repositories.base import BaseRepository

logger = logging.getLogger(__name__)

# Criar router
router = APIRouter()

def get_policy_repository(db: Session = Depends(get_database_session)) -> BaseRepository[GovernancePolicy]:
    """Dependency para obter repository de políticas"""
    return BaseRepository(GovernancePolicy, db)

def get_violation_repository(db: Session = Depends(get_database_session)) -> BaseRepository[PolicyViolation]:
    """Dependency para obter repository de violações"""
    return BaseRepository(PolicyViolation, db)

def get_compliance_repository(db: Session = Depends(get_database_session)) -> BaseRepository[ComplianceReport]:
    """Dependency para obter repository de compliance"""
    return BaseRepository(ComplianceReport, db)

# ========================================
# POLÍTICAS DE GOVERNANÇA
# ========================================

@router.get("/policies", summary="Listar políticas de governança")
async def list_policies(
    limit: int = Query(100, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    policy_type: Optional[str] = Query(None, description="Filtrar por tipo"),
    category: Optional[str] = Query(None, description="Filtrar por categoria"),
    status: Optional[str] = Query(None, description="Filtrar por status"),
    compliance_framework: Optional[str] = Query(None, description="Filtrar por framework"),
    repository: BaseRepository[GovernancePolicy] = Depends(get_policy_repository)
):
    """
    Lista políticas de governança de dados.
    
    Tipos de política suportados:
    - data_quality: Qualidade de dados
    - data_security: Segurança de dados
    - data_privacy: Privacidade de dados
    - data_retention: Retenção de dados
    - data_access: Controle de acesso
    - data_classification: Classificação de dados
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        # Aplicar filtros
        filters = {}
        if policy_type:
            filters['policy_type'] = policy_type
        if category:
            filters['category'] = category
        if status:
            filters['status'] = status
        if compliance_framework:
            filters['compliance_framework'] = compliance_framework
        
        # Buscar políticas
        policies = repository.search(
            filters=filters,
            limit=limit,
            offset=offset,
            sort_by='name',
            sort_order='asc'
        )
        
        total = repository.count(filters)
        
        logger.info(f"Listando {len(policies)} políticas de {total} total")
        
        return {
            "policies": [policy.to_dict() for policy in policies],
            "total": total,
            "limit": limit,
            "offset": offset,
            "filters": {
                "policy_type": policy_type,
                "category": category,
                "status": status,
                "compliance_framework": compliance_framework
            },
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except Exception as e:
        logger.error(f"Erro ao listar políticas: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.post("/policies", summary="Criar política de governança")
async def create_policy(
    policy_data: Dict[str, Any],
    repository: BaseRepository[GovernancePolicy] = Depends(get_policy_repository)
):
    """
    Cria uma nova política de governança.
    
    Campos obrigatórios:
    - name: Nome da política
    - policy_type: Tipo da política
    - category: Categoria da política
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        # Validar dados obrigatórios
        required_fields = ['name', 'policy_type', 'category']
        for field in required_fields:
            if field not in policy_data:
                raise HTTPException(status_code=400, detail=f"Campo {field} é obrigatório")
        
        # Verificar se já existe política com mesmo nome
        existing = repository.find_one_by(name=policy_data['name'])
        if existing:
            raise HTTPException(status_code=409, detail="Política com este nome já existe")
        
        # Criar política
        policy = repository.create(**policy_data)
        
        logger.info(f"Política criada: {policy.id} - {policy.name}")
        
        return {
            "policy": policy.to_dict(),
            "message": "Política criada com sucesso",
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao criar política: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.get("/policies/{policy_id}", summary="Obter política específica")
async def get_policy(
    policy_id: UUID,
    include_violations: bool = Query(False, description="Incluir violações"),
    repository: BaseRepository[GovernancePolicy] = Depends(get_policy_repository),
    violation_repository: BaseRepository[PolicyViolation] = Depends(get_violation_repository)
):
    """
    Obtém uma política específica por ID.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        policy = repository.get_by_id(policy_id)
        
        if not policy:
            raise HTTPException(status_code=404, detail="Política não encontrada")
        
        result = policy.to_dict()
        
        # Incluir violações se solicitado
        if include_violations:
            violations = violation_repository.find_by(policy_id=policy_id)
            result['violations'] = [violation.to_dict() for violation in violations]
        
        logger.info(f"Política encontrada: {policy_id}")
        
        return {
            "policy": result,
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao obter política {policy_id}: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.put("/policies/{policy_id}/activate", summary="Ativar política")
async def activate_policy(
    policy_id: UUID,
    repository: BaseRepository[GovernancePolicy] = Depends(get_policy_repository)
):
    """
    Ativa uma política de governança.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        policy = repository.get_by_id(policy_id)
        
        if not policy:
            raise HTTPException(status_code=404, detail="Política não encontrada")
        
        # Atualizar status
        updated_policy = repository.update(policy_id, {"status": "active"})
        
        logger.info(f"Política ativada: {policy_id}")
        
        return {
            "policy": updated_policy.to_dict(),
            "message": "Política ativada com sucesso",
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao ativar política {policy_id}: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

# ========================================
# VIOLAÇÕES DE POLÍTICAS
# ========================================

@router.get("/policies/violations", summary="Listar violações de políticas")
async def list_violations(
    limit: int = Query(100, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    policy_id: Optional[UUID] = Query(None, description="Filtrar por política"),
    entity_id: Optional[UUID] = Query(None, description="Filtrar por entidade"),
    severity: Optional[str] = Query(None, description="Filtrar por severidade"),
    status: Optional[str] = Query(None, description="Filtrar por status"),
    repository: BaseRepository[PolicyViolation] = Depends(get_violation_repository)
):
    """
    Lista violações de políticas de governança.
    
    Severidades suportadas:
    - low: Baixa
    - medium: Média
    - high: Alta
    - critical: Crítica
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        # Aplicar filtros
        filters = {}
        if policy_id:
            filters['policy_id'] = policy_id
        if entity_id:
            filters['entity_id'] = entity_id
        if severity:
            filters['severity'] = severity
        if status:
            filters['status'] = status
        
        # Buscar violações
        violations = repository.search(
            filters=filters,
            limit=limit,
            offset=offset,
            sort_by='detected_at',
            sort_order='desc'
        )
        
        total = repository.count(filters)
        
        logger.info(f"Listando {len(violations)} violações de {total} total")
        
        return {
            "violations": [violation.to_dict() for violation in violations],
            "total": total,
            "limit": limit,
            "offset": offset,
            "filters": {
                "policy_id": str(policy_id) if policy_id else None,
                "entity_id": str(entity_id) if entity_id else None,
                "severity": severity,
                "status": status
            },
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except Exception as e:
        logger.error(f"Erro ao listar violações: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.post("/policies/violations", summary="Reportar violação de política")
async def report_violation(
    violation_data: Dict[str, Any],
    repository: BaseRepository[PolicyViolation] = Depends(get_violation_repository)
):
    """
    Reporta uma nova violação de política.
    
    Campos obrigatórios:
    - policy_id: ID da política violada
    - entity_id: ID da entidade com violação
    - severity: Severidade da violação
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        # Validar dados obrigatórios
        required_fields = ['policy_id', 'entity_id', 'severity']
        for field in required_fields:
            if field not in violation_data:
                raise HTTPException(status_code=400, detail=f"Campo {field} é obrigatório")
        
        # Criar violação
        violation = repository.create(**violation_data)
        
        logger.info(f"Violação reportada: {violation.id}")
        
        return {
            "violation": violation.to_dict(),
            "message": "Violação reportada com sucesso",
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao reportar violação: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.put("/policies/violations/{violation_id}/resolve", summary="Resolver violação")
async def resolve_violation(
    violation_id: UUID,
    resolution_data: Dict[str, Any],
    repository: BaseRepository[PolicyViolation] = Depends(get_violation_repository)
):
    """
    Resolve uma violação de política.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        violation = repository.get_by_id(violation_id)
        
        if not violation:
            raise HTTPException(status_code=404, detail="Violação não encontrada")
        
        # Atualizar violação
        update_data = {
            "status": "resolved",
            "resolution_notes": resolution_data.get("resolution_notes"),
            "resolved_by": resolution_data.get("resolved_by")
        }
        
        updated_violation = repository.update(violation_id, update_data)
        
        logger.info(f"Violação resolvida: {violation_id}")
        
        return {
            "violation": updated_violation.to_dict(),
            "message": "Violação resolvida com sucesso",
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao resolver violação {violation_id}: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

# ========================================
# RELATÓRIOS DE COMPLIANCE
# ========================================

@router.get("/policies/compliance-reports", summary="Listar relatórios de compliance")
async def list_compliance_reports(
    limit: int = Query(100, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    framework: Optional[str] = Query(None, description="Filtrar por framework"),
    status: Optional[str] = Query(None, description="Filtrar por status"),
    repository: BaseRepository[ComplianceReport] = Depends(get_compliance_repository)
):
    """
    Lista relatórios de compliance.
    
    Frameworks suportados:
    - LGPD: Lei Geral de Proteção de Dados
    - GDPR: General Data Protection Regulation
    - SOX: Sarbanes-Oxley Act
    - HIPAA: Health Insurance Portability and Accountability Act
    - PCI_DSS: Payment Card Industry Data Security Standard
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        # Aplicar filtros
        filters = {}
        if framework:
            filters['compliance_framework'] = framework
        if status:
            filters['status'] = status
        
        # Buscar relatórios
        reports = repository.search(
            filters=filters,
            limit=limit,
            offset=offset,
            sort_by='report_period_end',
            sort_order='desc'
        )
        
        total = repository.count(filters)
        
        logger.info(f"Listando {len(reports)} relatórios de compliance de {total} total")
        
        return {
            "compliance_reports": [report.to_dict() for report in reports],
            "total": total,
            "limit": limit,
            "offset": offset,
            "filters": {
                "framework": framework,
                "status": status
            },
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except Exception as e:
        logger.error(f"Erro ao listar relatórios de compliance: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.post("/policies/compliance-reports", summary="Gerar relatório de compliance")
async def generate_compliance_report(
    report_request: Dict[str, Any],
    repository: BaseRepository[ComplianceReport] = Depends(get_compliance_repository)
):
    """
    Gera um novo relatório de compliance.
    
    Campos obrigatórios:
    - compliance_framework: Framework de compliance
    - report_period_start: Início do período
    - report_period_end: Fim do período
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        # Validar dados obrigatórios
        required_fields = ['compliance_framework', 'report_period_start', 'report_period_end']
        for field in required_fields:
            if field not in report_request:
                raise HTTPException(status_code=400, detail=f"Campo {field} é obrigatório")
        
        # Criar relatório
        report = repository.create(**report_request)
        
        # TODO: Implementar geração real do relatório
        # Por enquanto, criar resultado mock
        report.status = "completed"
        report.total_policies_evaluated = 25
        report.compliant_policies = 22
        report.non_compliant_policies = 3
        report.compliance_score = 88.0
        report.findings = {
            "compliant": ["Data encryption implemented", "Access controls in place"],
            "non_compliant": ["Missing data retention policy", "Incomplete audit logs"],
            "recommendations": ["Implement automated data retention", "Enhance audit logging"]
        }
        
        repository.update(report.id, {
            "status": report.status,
            "total_policies_evaluated": report.total_policies_evaluated,
            "compliant_policies": report.compliant_policies,
            "non_compliant_policies": report.non_compliant_policies,
            "compliance_score": report.compliance_score,
            "findings": report.findings
        })
        
        logger.info(f"Relatório de compliance gerado: {report.id}")
        
        return {
            "compliance_report": report.to_dict(),
            "message": "Relatório de compliance gerado com sucesso",
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao gerar relatório de compliance: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

