"""
Controller para Domínios de Negócio
"""

from typing import List, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status
from fastapi.responses import JSONResponse

from src.application.dtos.domains import (
    DomainCreateDTO,
    DomainResponseDTO,
    DomainUpdateDTO,
    DomainSearchDTO,
    DomainHierarchyDTO,
    DomainStatsDTO,
)
from src.application.dtos.common import PaginatedResponse, PaginationParams
from src.application.services.domain_service import DomainService
from src.domain.exceptions import BusinessRuleViolation, EntityNotFoundError
from src.api.dependencies import get_current_active_user, get_domain_service, validate_pagination

router = APIRouter(prefix="/api/v1/domains", tags=["Domains"])


@router.post(
    "/",
    response_model=DomainResponseDTO,
    status_code=status.HTTP_201_CREATED,
    summary="Criar domínio de negócio",
    description="Cria um novo domínio de negócio no sistema"
)
async def create_domain(
    domain_data: DomainCreateDTO,
    service: DomainService = Depends(get_domain_service),
    current_user: dict = Depends(get_current_active_user)
) -> DomainResponseDTO:
    """Cria um novo domínio de negócio"""
    try:
        return await service.create_domain(domain_data, current_user["id"])
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.get(
    "/",
    response_model=PaginatedResponse[DomainResponseDTO],
    summary="Listar domínios de negócio",
    description="Lista todos os domínios de negócio com paginação"
)
async def list_domains(
    pagination: PaginationParams = Depends(validate_pagination),
    domain_type: Optional[str] = Query(None, description="Filtro por tipo de domínio"),
    is_active: Optional[bool] = Query(None, description="Filtro por status ativo"),
    parent_domain_id: Optional[UUID] = Query(None, description="Filtro por domínio pai"),
    service: DomainService = Depends(get_domain_service),
    current_user: dict = Depends(get_current_active_user)
) -> PaginatedResponse[DomainResponseDTO]:
    """Lista domínios com filtros e paginação"""
    filters = {
        "domain_type": domain_type,
        "is_active": is_active,
        "parent_domain_id": parent_domain_id
    }
    # Remove filtros None
    filters = {k: v for k, v in filters.items() if v is not None}
    
    return await service.list_domains(pagination, filters)


@router.get(
    "/{domain_id}",
    response_model=DomainResponseDTO,
    summary="Buscar domínio de negócio",
    description="Busca um domínio específico por ID"
)
async def get_domain(
    domain_id: UUID,
    service: DomainService = Depends(get_domain_service),
    current_user: dict = Depends(get_current_active_user)
) -> DomainResponseDTO:
    """Busca um domínio específico"""
    try:
        return await service.get_domain(domain_id)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.put(
    "/{domain_id}",
    response_model=DomainResponseDTO,
    summary="Atualizar domínio de negócio",
    description="Atualiza um domínio existente"
)
async def update_domain(
    domain_id: UUID,
    domain_data: DomainUpdateDTO,
    service: DomainService = Depends(get_domain_service),
    current_user: dict = Depends(get_current_active_user)
) -> DomainResponseDTO:
    """Atualiza um domínio existente"""
    try:
        return await service.update_domain(domain_id, domain_data, current_user["id"])
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.delete(
    "/{domain_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Deletar domínio de negócio",
    description="Remove um domínio do sistema (soft delete)"
)
async def delete_domain(
    domain_id: UUID,
    service: DomainService = Depends(get_domain_service),
    current_user: dict = Depends(get_current_active_user)
):
    """Remove um domínio (soft delete)"""
    try:
        await service.delete_domain(domain_id, current_user["id"])
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get(
    "/{domain_id}/children",
    response_model=List[DomainResponseDTO],
    summary="Listar subdomínios",
    description="Lista todos os subdomínios de um domínio específico"
)
async def get_domain_children(
    domain_id: UUID,
    include_inactive: bool = Query(False, description="Incluir domínios inativos"),
    service: DomainService = Depends(get_domain_service),
    current_user: dict = Depends(get_current_active_user)
) -> List[DomainResponseDTO]:
    """Lista subdomínios de um domínio"""
    try:
        return await service.get_domain_children(domain_id, include_inactive)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.get(
    "/{domain_id}/entities",
    response_model=PaginatedResponse,
    summary="Listar entidades do domínio",
    description="Lista todas as entidades pertencentes a um domínio"
)
async def get_domain_entities(
    domain_id: UUID,
    pagination: PaginationParams = Depends(validate_pagination),
    include_inactive: bool = Query(False, description="Incluir entidades inativas"),
    service: DomainService = Depends(get_domain_service),
    current_user: dict = Depends(get_current_active_user)
) -> PaginatedResponse:
    """Lista entidades de um domínio"""
    try:
        return await service.get_domain_entities(domain_id, pagination, include_inactive)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.post(
    "/search",
    response_model=PaginatedResponse[DomainResponseDTO],
    summary="Busca avançada de domínios",
    description="Realiza busca avançada de domínios com múltiplos critérios"
)
async def search_domains(
    search_criteria: DomainSearchDTO,
    pagination: PaginationParams = Depends(validate_pagination),
    service: DomainService = Depends(get_domain_service),
    current_user: dict = Depends(get_current_active_user)
) -> PaginatedResponse[DomainResponseDTO]:
    """Busca avançada de domínios"""
    return await service.search_domains(search_criteria, pagination)


@router.get(
    "/{domain_id}/hierarchy",
    response_model=DomainHierarchyDTO,
    summary="Obter hierarquia do domínio",
    description="Retorna a hierarquia completa de um domínio (pais e filhos)"
)
async def get_domain_hierarchy(
    domain_id: UUID,
    max_depth: int = Query(5, ge=1, le=10, description="Profundidade máxima da hierarquia"),
    service: DomainService = Depends(get_domain_service),
    current_user: dict = Depends(get_current_active_user)
) -> DomainHierarchyDTO:
    """Obtém hierarquia completa do domínio"""
    try:
        return await service.get_domain_hierarchy(domain_id, max_depth)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.get(
    "/{domain_id}/stats",
    response_model=DomainStatsDTO,
    summary="Estatísticas do domínio",
    description="Retorna estatísticas detalhadas de um domínio"
)
async def get_domain_stats(
    domain_id: UUID,
    service: DomainService = Depends(get_domain_service),
    current_user: dict = Depends(get_current_active_user)
) -> DomainStatsDTO:
    """Obtém estatísticas do domínio"""
    try:
        return await service.get_domain_stats(domain_id)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.get(
    "/tree/all",
    response_model=List[DomainHierarchyDTO],
    summary="Árvore completa de domínios",
    description="Retorna a árvore hierárquica completa de todos os domínios"
)
async def get_domains_tree(
    include_inactive: bool = Query(False, description="Incluir domínios inativos"),
    service: DomainService = Depends(get_domain_service),
    current_user: dict = Depends(get_current_active_user)
) -> List[DomainHierarchyDTO]:
    """Obtém árvore completa de domínios"""
    return await service.get_domains_tree(include_inactive)

