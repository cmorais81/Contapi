"""
Controller para Descoberta e Catálogo
"""

from typing import List, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status
from fastapi.responses import JSONResponse

from src.application.dtos.discovery import (
    CatalogSearchDTO,
    SearchResponseDTO,
    RecommendationDTO,
    CatalogStatsDTO,
    DataDiscoveryRequestDTO,
    DiscoveryResultDTO,
    PopularContentDTO,
    SimilarContentDTO,
    BrowseResponseDTO,
    SearchScope,
    SearchResultType,
)
from src.application.dtos import PaginatedResponse, PaginationParams
from src.application.services.discovery_service import DiscoveryService
from src.domain.exceptions import BusinessRuleViolation, EntityNotFoundError
from src.api.dependencies import get_current_active_user, get_discovery_service, validate_pagination

router = APIRouter(prefix="/api/v1/catalog", tags=["Discovery & Catalog"])


@router.post(
    "/search",
    response_model=SearchResponseDTO,
    summary="Busca no catálogo",
    description="Realiza busca inteligente no catálogo de dados"
)
async def search_catalog(
    search_request: CatalogSearchDTO,
    service: DiscoveryService = Depends(get_discovery_service),
    current_user: dict = Depends(get_current_active_user)
) -> SearchResponseDTO:
    """Busca no catálogo de dados"""
    try:
        return await service.search_catalog(search_request)
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get(
    "/search/suggestions",
    response_model=List[str],
    summary="Sugestões de busca",
    description="Retorna sugestões baseadas no termo parcial"
)
async def get_search_suggestions(
    query: str = Query(..., min_length=2, description="Termo parcial para sugestões"),
    limit: int = Query(10, ge=1, le=50, description="Número máximo de sugestões"),
    service: DiscoveryService = Depends(get_discovery_service),
    current_user: dict = Depends(get_current_active_user)
) -> List[str]:
    """Obtém sugestões de busca"""
    return await service.get_search_suggestions(query, limit)


@router.get(
    "/browse",
    response_model=BrowseResponseDTO,
    summary="Navegar catálogo",
    description="Navega hierarquicamente pelo catálogo"
)
async def browse_catalog(
    path: str = Query("/", description="Caminho para navegar"),
    node_type: Optional[str] = Query(None, description="Filtro por tipo de nó"),
    service: DiscoveryService = Depends(get_discovery_service),
    current_user: dict = Depends(get_current_active_user)
) -> BrowseResponseDTO:
    """Navega pelo catálogo"""
    try:
        return await service.browse_catalog(path, node_type)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.get(
    "/recommendations/{entity_id}",
    response_model=List[RecommendationDTO],
    summary="Recomendações para entidade",
    description="Retorna recomendações baseadas em uma entidade"
)
async def get_entity_recommendations(
    entity_id: UUID,
    recommendation_types: Optional[str] = Query(
        None, 
        description="Tipos de recomendação (separados por vírgula)"
    ),
    limit: int = Query(10, ge=1, le=50, description="Número máximo de recomendações"),
    service: DiscoveryService = Depends(get_discovery_service),
    current_user: dict = Depends(get_current_active_user)
) -> List[RecommendationDTO]:
    """Obtém recomendações para entidade"""
    try:
        types = recommendation_types.split(",") if recommendation_types else None
        return await service.get_entity_recommendations(entity_id, types, limit)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.get(
    "/popular",
    response_model=List[PopularContentDTO],
    summary="Conteúdo popular",
    description="Lista conteúdo mais popular no catálogo"
)
async def get_popular_content(
    content_type: Optional[str] = Query(None, description="Tipo de conteúdo"),
    domain: Optional[str] = Query(None, description="Filtro por domínio"),
    period_days: int = Query(30, ge=1, le=365, description="Período em dias"),
    limit: int = Query(20, ge=1, le=100, description="Número máximo de itens"),
    service: DiscoveryService = Depends(get_discovery_service),
    current_user: dict = Depends(get_current_active_user)
) -> List[PopularContentDTO]:
    """Lista conteúdo popular"""
    filters = {
        "content_type": content_type,
        "domain": domain,
        "period_days": period_days
    }
    filters = {k: v for k, v in filters.items() if v is not None}
    
    return await service.get_popular_content(filters, limit)


@router.get(
    "/similar/{entity_id}",
    response_model=List[SimilarContentDTO],
    summary="Conteúdo similar",
    description="Encontra conteúdo similar a uma entidade"
)
async def get_similar_content(
    entity_id: UUID,
    similarity_threshold: float = Query(0.7, ge=0, le=1, description="Limite de similaridade"),
    limit: int = Query(10, ge=1, le=50, description="Número máximo de itens"),
    service: DiscoveryService = Depends(get_discovery_service),
    current_user: dict = Depends(get_current_active_user)
) -> List[SimilarContentDTO]:
    """Encontra conteúdo similar"""
    try:
        return await service.get_similar_content(entity_id, similarity_threshold, limit)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.get(
    "/stats",
    response_model=CatalogStatsDTO,
    summary="Estatísticas do catálogo",
    description="Retorna estatísticas gerais do catálogo"
)
async def get_catalog_stats(
    service: DiscoveryService = Depends(get_discovery_service),
    current_user: dict = Depends(get_current_active_user)
) -> CatalogStatsDTO:
    """Obtém estatísticas do catálogo"""
    return await service.get_catalog_stats()


@router.post(
    "/discovery",
    response_model=dict,
    status_code=status.HTTP_202_ACCEPTED,
    summary="Iniciar descoberta",
    description="Inicia processo de descoberta automática de dados"
)
async def start_data_discovery(
    discovery_request: DataDiscoveryRequestDTO,
    service: DiscoveryService = Depends(get_discovery_service),
    current_user: dict = Depends(get_current_active_user)
) -> dict:
    """Inicia descoberta de dados"""
    try:
        discovery_id = await service.start_data_discovery(discovery_request, current_user["id"])
        return {
            "message": "Data discovery started successfully",
            "discovery_id": discovery_id,
            "status": "running"
        }
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get(
    "/discovery/{discovery_id}",
    response_model=DiscoveryResultDTO,
    summary="Status da descoberta",
    description="Verifica status de um processo de descoberta"
)
async def get_discovery_status(
    discovery_id: UUID,
    service: DiscoveryService = Depends(get_discovery_service),
    current_user: dict = Depends(get_current_active_user)
) -> DiscoveryResultDTO:
    """Obtém status da descoberta"""
    try:
        return await service.get_discovery_status(discovery_id)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.get(
    "/recent",
    response_model=List[dict],
    summary="Conteúdo recente",
    description="Lista conteúdo adicionado recentemente"
)
async def get_recent_content(
    days: int = Query(7, ge=1, le=90, description="Número de dias"),
    content_type: Optional[str] = Query(None, description="Tipo de conteúdo"),
    limit: int = Query(20, ge=1, le=100, description="Número máximo de itens"),
    service: DiscoveryService = Depends(get_discovery_service),
    current_user: dict = Depends(get_current_active_user)
) -> List[dict]:
    """Lista conteúdo recente"""
    filters = {
        "days": days,
        "content_type": content_type
    }
    filters = {k: v for k, v in filters.items() if v is not None}
    
    return await service.get_recent_content(filters, limit)


@router.get(
    "/trending",
    response_model=List[dict],
    summary="Conteúdo em tendência",
    description="Lista conteúdo com crescimento de uso"
)
async def get_trending_content(
    period_days: int = Query(7, ge=1, le=90, description="Período para análise"),
    min_growth_rate: float = Query(0.1, ge=0, description="Taxa mínima de crescimento"),
    limit: int = Query(15, ge=1, le=50, description="Número máximo de itens"),
    service: DiscoveryService = Depends(get_discovery_service),
    current_user: dict = Depends(get_current_active_user)
) -> List[dict]:
    """Lista conteúdo em tendência"""
    return await service.get_trending_content(period_days, min_growth_rate, limit)


# Advanced search endpoints
@router.get(
    "/search/facets",
    response_model=List[dict],
    summary="Facetas disponíveis",
    description="Lista facetas disponíveis para filtros de busca"
)
async def get_search_facets(
    scope: SearchScope = Query(SearchScope.ALL, description="Escopo das facetas"),
    service: DiscoveryService = Depends(get_discovery_service),
    current_user: dict = Depends(get_current_active_user)
) -> List[dict]:
    """Obtém facetas de busca"""
    return await service.get_search_facets(scope)


@router.get(
    "/search/history",
    response_model=List[dict],
    summary="Histórico de buscas",
    description="Lista histórico de buscas do usuário"
)
async def get_search_history(
    limit: int = Query(20, ge=1, le=100, description="Número máximo de itens"),
    service: DiscoveryService = Depends(get_discovery_service),
    current_user: dict = Depends(get_current_active_user)
) -> List[dict]:
    """Obtém histórico de buscas"""
    return await service.get_search_history(current_user["id"], limit)


@router.post(
    "/favorites/{entity_id}",
    response_model=dict,
    summary="Adicionar aos favoritos",
    description="Adiciona entidade aos favoritos do usuário"
)
async def add_to_favorites(
    entity_id: UUID,
    service: DiscoveryService = Depends(get_discovery_service),
    current_user: dict = Depends(get_current_active_user)
) -> dict:
    """Adiciona aos favoritos"""
    try:
        await service.add_to_favorites(current_user["id"], entity_id)
        return {"message": "Added to favorites successfully"}
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get(
    "/favorites",
    response_model=List[dict],
    summary="Listar favoritos",
    description="Lista favoritos do usuário"
)
async def get_favorites(
    service: DiscoveryService = Depends(get_discovery_service),
    current_user: dict = Depends(get_current_active_user)
) -> List[dict]:
    """Lista favoritos do usuário"""
    return await service.get_user_favorites(current_user["id"])

