"""
Serviço de Contratos de Dados Completo
API de Governança de Dados V2.2
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from typing import List, Optional, Dict, Any, Union
from datetime import datetime
from uuid import UUID, uuid4
import logging

# Imports dos DTOs com fallback seguro
try:
    from src.application.dtos.contracts import (
        DataContractCreateDTO,
        DataContractUpdateDTO,
        DataContractResponseDTO,
        ContractVersionCreateDTO,
        ContractVersionResponseDTO,
        ContractApprovalCreateDTO,
        ContractApprovalResponseDTO,
        ContractSearchDTO,
        ContractStatsDTO,
        EntityCreateDTO,
        EntityUpdateDTO,
        EntityResponseDTO,
        QualityRuleCreateDTO,
        QualityRuleUpdateDTO,
        QualityRuleResponseDTO
    )
except ImportError as e:
    logging.warning(f"Não foi possível importar DTOs de contratos: {e}")
    # Fallback para DTOs básicos
    from typing import Dict, Any
    DataContractCreateDTO = Dict[str, Any]
    DataContractUpdateDTO = Dict[str, Any]
    DataContractResponseDTO = Dict[str, Any]
    ContractVersionCreateDTO = Dict[str, Any]
    ContractVersionResponseDTO = Dict[str, Any]
    ContractApprovalCreateDTO = Dict[str, Any]
    ContractApprovalResponseDTO = Dict[str, Any]
    ContractSearchDTO = Dict[str, Any]
    ContractStatsDTO = Dict[str, Any]
    EntityCreateDTO = Dict[str, Any]
    EntityUpdateDTO = Dict[str, Any]
    EntityResponseDTO = Dict[str, Any]
    QualityRuleCreateDTO = Dict[str, Any]
    QualityRuleUpdateDTO = Dict[str, Any]
    QualityRuleResponseDTO = Dict[str, Any]

# Imports de common DTOs com fallback
try:
    from src.application.dtos.common import PaginatedResponse, PaginationParams
except ImportError:
    PaginatedResponse = Dict[str, Any]
    PaginationParams = Dict[str, Any]

logger = logging.getLogger(__name__)


class ContractService:
    """Serviço completo para gerenciamento de contratos de dados"""
    
    def __init__(self):
        self.contracts = {}
        self.versions = {}
        self.approvals = {}
        self.entities = {}
        self.quality_rules = {}
        logger.info("ContractService inicializado com sucesso")
    
    # === MÉTODOS DE CONTRATOS ===
    
    async def create_contract(self, contract_data: Union[DataContractCreateDTO, Dict[str, Any]]) -> DataContractResponseDTO:
        """Cria um novo contrato de dados"""
        try:
            if hasattr(contract_data, 'dict'):
                data = contract_data.dict()
            else:
                data = contract_data
            
            contract_id = uuid4()
            contract = {
                'id': contract_id,
                'name': data.get('name', 'Unnamed Contract'),
                'description': data.get('description', ''),
                'contract_type': data.get('contract_type', 'database'),
                'version': data.get('version', '1.0.0'),
                'status': 'active',
                'schema_definition': data.get('schema_definition', {}),
                'quality_rules': data.get('quality_rules', []),
                'sla_requirements': data.get('sla_requirements', {}),
                'data_owner': data.get('data_owner'),
                'steward': data.get('steward'),
                'tags': data.get('tags', []),
                'metadata': data.get('metadata', {}),
                'created_at': datetime.utcnow(),
                'updated_at': datetime.utcnow(),
                'created_by': data.get('created_by', 'system'),
                'updated_by': data.get('updated_by', 'system')
            }
            
            self.contracts[str(contract_id)] = contract
            logger.info(f"Contrato criado com sucesso: {contract['name']} (ID: {contract_id})")
            
            return contract
            
        except Exception as e:
            logger.error(f"Erro ao criar contrato: {e}")
            raise
    
    async def get_contract(self, contract_id: Union[str, UUID]) -> Optional[DataContractResponseDTO]:
        """Busca um contrato por ID"""
        try:
            contract = self.contracts.get(str(contract_id))
            if contract:
                logger.info(f"Contrato encontrado: {contract_id}")
                return contract
            else:
                logger.warning(f"Contrato não encontrado: {contract_id}")
                return None
                
        except Exception as e:
            logger.error(f"Erro ao buscar contrato {contract_id}: {e}")
            raise
    
    async def update_contract(self, contract_id: Union[str, UUID], update_data: Union[DataContractUpdateDTO, Dict[str, Any]]) -> Optional[DataContractResponseDTO]:
        """Atualiza um contrato existente"""
        try:
            contract = self.contracts.get(str(contract_id))
            if not contract:
                logger.warning(f"Contrato não encontrado para atualização: {contract_id}")
                return None
            
            if hasattr(update_data, 'dict'):
                data = update_data.dict(exclude_unset=True)
            else:
                data = {k: v for k, v in update_data.items() if v is not None}
            
            # Atualizar campos
            for key, value in data.items():
                if key in contract:
                    contract[key] = value
            
            contract['updated_at'] = datetime.utcnow()
            contract['updated_by'] = data.get('updated_by', 'system')
            
            logger.info(f"Contrato atualizado com sucesso: {contract_id}")
            return contract
            
        except Exception as e:
            logger.error(f"Erro ao atualizar contrato {contract_id}: {e}")
            raise
    
    async def delete_contract(self, contract_id: Union[str, UUID]) -> bool:
        """Remove um contrato"""
        try:
            if str(contract_id) in self.contracts:
                del self.contracts[str(contract_id)]
                logger.info(f"Contrato removido com sucesso: {contract_id}")
                return True
            else:
                logger.warning(f"Contrato não encontrado para remoção: {contract_id}")
                return False
                
        except Exception as e:
            logger.error(f"Erro ao remover contrato {contract_id}: {e}")
            raise
    
    async def list_contracts(self, pagination: Optional[PaginationParams] = None, search: Optional[ContractSearchDTO] = None) -> PaginatedResponse:
        """Lista contratos com paginação e filtros"""
        try:
            contracts = list(self.contracts.values())
            
            # Aplicar filtros se fornecidos
            if search:
                if hasattr(search, 'dict'):
                    filters = search.dict(exclude_unset=True)
                else:
                    filters = search
                
                if filters.get('name'):
                    contracts = [c for c in contracts if filters['name'].lower() in c['name'].lower()]
                
                if filters.get('contract_type'):
                    contracts = [c for c in contracts if c['contract_type'] == filters['contract_type']]
                
                if filters.get('status'):
                    contracts = [c for c in contracts if c['status'] == filters['status']]
                
                if filters.get('data_owner'):
                    contracts = [c for c in contracts if c.get('data_owner') == filters['data_owner']]
            
            # Aplicar paginação
            total = len(contracts)
            if pagination:
                if hasattr(pagination, 'dict'):
                    page_data = pagination.dict()
                else:
                    page_data = pagination
                
                page = page_data.get('page', 1)
                size = page_data.get('size', 10)
                start = (page - 1) * size
                end = start + size
                contracts = contracts[start:end]
            
            logger.info(f"Listagem de contratos retornada: {len(contracts)} de {total}")
            
            return {
                'items': contracts,
                'total': total,
                'page': pagination.get('page', 1) if pagination else 1,
                'size': pagination.get('size', 10) if pagination else len(contracts),
                'pages': (total + (pagination.get('size', 10) if pagination else len(contracts)) - 1) // (pagination.get('size', 10) if pagination else len(contracts))
            }
            
        except Exception as e:
            logger.error(f"Erro ao listar contratos: {e}")
            raise
    
    # === MÉTODOS DE VERSÕES ===
    
    async def create_version(self, version_data: Union[ContractVersionCreateDTO, Dict[str, Any]]) -> ContractVersionResponseDTO:
        """Cria uma nova versão de contrato"""
        try:
            if hasattr(version_data, 'dict'):
                data = version_data.dict()
            else:
                data = version_data
            
            version_id = uuid4()
            version = {
                'id': version_id,
                'contract_id': data['contract_id'],
                'version': data['version'],
                'schema_definition': data['schema_definition'],
                'changes_description': data.get('changes_description'),
                'breaking_changes': data.get('breaking_changes', False),
                'migration_notes': data.get('migration_notes'),
                'is_active': False,
                'created_at': datetime.utcnow(),
                'created_by': data.get('created_by', 'system')
            }
            
            self.versions[str(version_id)] = version
            logger.info(f"Versão criada com sucesso: {version['version']} para contrato {data['contract_id']}")
            
            return version
            
        except Exception as e:
            logger.error(f"Erro ao criar versão: {e}")
            raise
    
    async def activate_version(self, version_id: Union[str, UUID]) -> bool:
        """Ativa uma versão específica"""
        try:
            version = self.versions.get(str(version_id))
            if not version:
                return False
            
            # Desativar outras versões do mesmo contrato
            contract_id = version['contract_id']
            for v in self.versions.values():
                if v['contract_id'] == contract_id:
                    v['is_active'] = False
            
            # Ativar a versão solicitada
            version['is_active'] = True
            logger.info(f"Versão ativada: {version_id}")
            
            return True
            
        except Exception as e:
            logger.error(f"Erro ao ativar versão {version_id}: {e}")
            raise
    
    # === MÉTODOS DE APROVAÇÕES ===
    
    async def create_approval(self, approval_data: Union[ContractApprovalCreateDTO, Dict[str, Any]]) -> ContractApprovalResponseDTO:
        """Cria uma solicitação de aprovação"""
        try:
            if hasattr(approval_data, 'dict'):
                data = approval_data.dict()
            else:
                data = approval_data
            
            approval_id = uuid4()
            approval = {
                'id': approval_id,
                'contract_id': data['contract_id'],
                'version_id': data.get('version_id'),
                'approver_email': data['approver_email'],
                'approval_type': data['approval_type'],
                'status': 'pending',
                'comments': data.get('comments'),
                'approved_at': None,
                'created_at': datetime.utcnow()
            }
            
            self.approvals[str(approval_id)] = approval
            logger.info(f"Aprovação criada: {approval_id} para contrato {data['contract_id']}")
            
            return approval
            
        except Exception as e:
            logger.error(f"Erro ao criar aprovação: {e}")
            raise
    
    async def approve_contract(self, approval_id: Union[str, UUID], comments: Optional[str] = None) -> bool:
        """Aprova um contrato"""
        try:
            approval = self.approvals.get(str(approval_id))
            if not approval:
                return False
            
            approval['status'] = 'approved'
            approval['approved_at'] = datetime.utcnow()
            if comments:
                approval['comments'] = comments
            
            logger.info(f"Contrato aprovado: {approval_id}")
            return True
            
        except Exception as e:
            logger.error(f"Erro ao aprovar contrato {approval_id}: {e}")
            raise
    
    # === MÉTODOS DE ENTIDADES ===
    
    async def create_entity(self, entity_data: Union[EntityCreateDTO, Dict[str, Any]]) -> EntityResponseDTO:
        """Cria uma nova entidade"""
        try:
            if hasattr(entity_data, 'dict'):
                data = entity_data.dict()
            else:
                data = entity_data
            
            entity_id = uuid4()
            entity = {
                'id': entity_id,
                'name': data['name'],
                'description': data.get('description'),
                'entity_type': data['entity_type'],
                'schema_definition': data.get('schema_definition', {}),
                'data_source': data.get('data_source'),
                'owner': data.get('owner'),
                'steward': data.get('steward'),
                'tags': data.get('tags', []),
                'metadata': data.get('metadata', {}),
                'created_at': datetime.utcnow(),
                'updated_at': datetime.utcnow()
            }
            
            self.entities[str(entity_id)] = entity
            logger.info(f"Entidade criada: {entity['name']} (ID: {entity_id})")
            
            return entity
            
        except Exception as e:
            logger.error(f"Erro ao criar entidade: {e}")
            raise
    
    # === MÉTODOS DE QUALIDADE ===
    
    async def create_quality_rule(self, rule_data: Union[QualityRuleCreateDTO, Dict[str, Any]]) -> QualityRuleResponseDTO:
        """Cria uma nova regra de qualidade"""
        try:
            if hasattr(rule_data, 'dict'):
                data = rule_data.dict()
            else:
                data = rule_data
            
            rule_id = uuid4()
            rule = {
                'id': rule_id,
                'name': data['name'],
                'description': data.get('description'),
                'rule_type': data['rule_type'],
                'entity_id': data.get('entity_id'),
                'field_name': data.get('field_name'),
                'rule_definition': data['rule_definition'],
                'severity': data.get('severity', 'medium'),
                'is_active': data.get('is_active', True),
                'created_at': datetime.utcnow(),
                'updated_at': datetime.utcnow()
            }
            
            self.quality_rules[str(rule_id)] = rule
            logger.info(f"Regra de qualidade criada: {rule['name']} (ID: {rule_id})")
            
            return rule
            
        except Exception as e:
            logger.error(f"Erro ao criar regra de qualidade: {e}")
            raise
    
    # === MÉTODOS DE ESTATÍSTICAS ===
    
    async def get_contract_stats(self) -> ContractStatsDTO:
        """Retorna estatísticas dos contratos"""
        try:
            contracts = list(self.contracts.values())
            
            stats = {
                'total_contracts': len(contracts),
                'active_contracts': len([c for c in contracts if c['status'] == 'active']),
                'draft_contracts': len([c for c in contracts if c['status'] == 'draft']),
                'deprecated_contracts': len([c for c in contracts if c['status'] == 'deprecated']),
                'contracts_by_type': {},
                'contracts_by_owner': {},
                'recent_changes': 0
            }
            
            # Estatísticas por tipo
            for contract in contracts:
                contract_type = contract.get('contract_type', 'unknown')
                stats['contracts_by_type'][contract_type] = stats['contracts_by_type'].get(contract_type, 0) + 1
            
            # Estatísticas por proprietário
            for contract in contracts:
                owner = contract.get('data_owner', 'unknown')
                stats['contracts_by_owner'][owner] = stats['contracts_by_owner'].get(owner, 0) + 1
            
            # Mudanças recentes (últimos 30 dias)
            from datetime import timedelta
            thirty_days_ago = datetime.utcnow() - timedelta(days=30)
            stats['recent_changes'] = len([c for c in contracts if c['updated_at'] > thirty_days_ago])
            
            logger.info("Estatísticas de contratos calculadas")
            return stats
            
        except Exception as e:
            logger.error(f"Erro ao calcular estatísticas: {e}")
            raise
    
    # === MÉTODOS DE VALIDAÇÃO ===
    
    async def validate_contract_schema(self, schema: Dict[str, Any]) -> Dict[str, Any]:
        """Valida o schema de um contrato"""
        try:
            validation_result = {
                'is_valid': True,
                'errors': [],
                'warnings': []
            }
            
            # Validações básicas
            if not schema:
                validation_result['is_valid'] = False
                validation_result['errors'].append("Schema não pode estar vazio")
            
            if not schema.get('type'):
                validation_result['warnings'].append("Tipo do schema não especificado")
            
            if not schema.get('properties'):
                validation_result['warnings'].append("Propriedades do schema não especificadas")
            
            logger.info(f"Validação de schema concluída: {'válido' if validation_result['is_valid'] else 'inválido'}")
            return validation_result
            
        except Exception as e:
            logger.error(f"Erro ao validar schema: {e}")
            raise
    
    # === MÉTODOS DE HEALTH CHECK ===
    
    async def health_check(self) -> Dict[str, Any]:
        """Verifica a saúde do serviço"""
        try:
            return {
                'status': 'healthy',
                'contracts_count': len(self.contracts),
                'versions_count': len(self.versions),
                'approvals_count': len(self.approvals),
                'entities_count': len(self.entities),
                'quality_rules_count': len(self.quality_rules),
                'timestamp': datetime.utcnow().isoformat()
            }
        except Exception as e:
            logger.error(f"Erro no health check: {e}")
            return {
                'status': 'unhealthy',
                'error': str(e),
                'timestamp': datetime.utcnow().isoformat()
            }


# Instância global do serviço
contract_service = ContractService()

