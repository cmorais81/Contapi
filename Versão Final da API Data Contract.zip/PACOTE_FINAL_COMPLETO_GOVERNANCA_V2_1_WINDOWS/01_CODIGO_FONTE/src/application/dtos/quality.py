from typing import TypeVar
"""
DTOs para Qualidade de Dados
API de Governança de Dados V1.6
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from datetime import datetime
from typing import List, Optional, Dict, Any
from uuid import UUID
from enum import Enum

from pydantic import BaseModel, Field


class QualityRuleType(str, Enum):
    """Tipos de regras de qualidade"""
    COMPLETENESS = "completeness"
    ACCURACY = "accuracy"
    CONSISTENCY = "consistency"
    TIMELINESS = "timeliness"
    VALIDITY = "validity"
    UNIQUENESS = "uniqueness"


class QualityRuleStatus(str, Enum):
    """Status das regras de qualidade"""
    ACTIVE = "active"
    INACTIVE = "inactive"
    DRAFT = "draft"
    DEPRECATED = "deprecated"


class IncidentSeverity(str, Enum):
    """Severidade dos incidentes"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class IncidentStatus(str, Enum):
    """Status dos incidentes"""
    OPEN = "open"
    IN_PROGRESS = "in_progress"
    RESOLVED = "resolved"
    CLOSED = "closed"


# ========================================
# QUALITY RULES DTOs
# ========================================

class QualityRuleCreateDTO(BaseModel):
    """DTO para criação de regra de qualidade"""
    name: str = Field(..., min_length=1, max_length=255, description="Nome da regra")
    description: Optional[str] = Field(None, description="Descrição da regra")
    rule_type: QualityRuleType = Field(..., description="Tipo da regra")
    entity_id: UUID = Field(..., description="ID da entidade")
    column_name: Optional[str] = Field(None, description="Nome da coluna")
    rule_expression: str = Field(..., description="Expressão da regra")
    threshold: Optional[float] = Field(None, ge=0, le=100, description="Limite de aceitação (%)")
    severity: IncidentSeverity = Field(default=IncidentSeverity.MEDIUM, description="Severidade")
    is_active: bool = Field(default=True, description="Regra ativa")
    schedule_cron: Optional[str] = Field(None, description="Agendamento cron")
    tags: Optional[List[str]] = Field(default=[], description="Tags da regra")
    metadata: Optional[Dict[str, Any]] = Field(default={}, description="Metadados adicionais")


class QualityRuleUpdateDTO(BaseModel):
    """DTO para atualização de regra de qualidade"""
    name: Optional[str] = Field(None, min_length=1, max_length=255, description="Nome da regra")
    description: Optional[str] = Field(None, description="Descrição da regra")
    rule_expression: Optional[str] = Field(None, description="Expressão da regra")
    threshold: Optional[float] = Field(None, ge=0, le=100, description="Limite de aceitação (%)")
    severity: Optional[IncidentSeverity] = Field(None, description="Severidade")
    is_active: Optional[bool] = Field(None, description="Regra ativa")
    schedule_cron: Optional[str] = Field(None, description="Agendamento cron")
    tags: Optional[List[str]] = Field(None, description="Tags da regra")
    metadata: Optional[Dict[str, Any]] = Field(None, description="Metadados adicionais")


class QualityRuleResponseDTO(BaseModel):
    """DTO para resposta de regra de qualidade"""
    id: UUID = Field(..., description="ID da regra")
    name: str = Field(..., description="Nome da regra")
    description: Optional[str] = Field(None, description="Descrição da regra")
    rule_type: QualityRuleType = Field(..., description="Tipo da regra")
    entity_id: UUID = Field(..., description="ID da entidade")
    entity_name: Optional[str] = Field(None, description="Nome da entidade")
    column_name: Optional[str] = Field(None, description="Nome da coluna")
    rule_expression: str = Field(..., description="Expressão da regra")
    threshold: Optional[float] = Field(None, description="Limite de aceitação (%)")
    severity: IncidentSeverity = Field(..., description="Severidade")
    status: QualityRuleStatus = Field(..., description="Status da regra")
    is_active: bool = Field(..., description="Regra ativa")
    schedule_cron: Optional[str] = Field(None, description="Agendamento cron")
    last_execution: Optional[datetime] = Field(None, description="Última execução")
    next_execution: Optional[datetime] = Field(None, description="Próxima execução")
    success_rate: Optional[float] = Field(None, description="Taxa de sucesso (%)")
    tags: List[str] = Field(default=[], description="Tags da regra")
    metadata: Dict[str, Any] = Field(default={}, description="Metadados adicionais")
    created_by: str = Field(..., description="Criado por")
    created_at: datetime = Field(..., description="Data de criação")
    updated_by: Optional[str] = Field(None, description="Atualizado por")
    updated_at: Optional[datetime] = Field(None, description="Data de atualização")


# ========================================
# QUALITY METRICS DTOs
# ========================================

class QualityMetricResponseDTO(BaseModel):
    """DTO para resposta de métricas de qualidade"""
    entity_id: UUID = Field(..., description="ID da entidade")
    entity_name: str = Field(..., description="Nome da entidade")
    domain_id: Optional[UUID] = Field(None, description="ID do domínio")
    domain_name: Optional[str] = Field(None, description="Nome do domínio")
    
    # Métricas principais
    completeness: float = Field(..., ge=0, le=100, description="Completude (%)")
    accuracy: float = Field(..., ge=0, le=100, description="Precisão (%)")
    consistency: float = Field(..., ge=0, le=100, description="Consistência (%)")
    timeliness: float = Field(..., ge=0, le=100, description="Pontualidade (%)")
    validity: float = Field(..., ge=0, le=100, description="Validade (%)")
    uniqueness: float = Field(..., ge=0, le=100, description="Unicidade (%)")
    
    # Métricas agregadas
    overall_score: float = Field(..., ge=0, le=100, description="Score geral (%)")
    quality_grade: str = Field(..., description="Nota de qualidade (A-F)")
    
    # Detalhes por coluna
    column_metrics: Optional[Dict[str, Dict[str, float]]] = Field(
        default={}, description="Métricas por coluna"
    )
    
    # Histórico
    trend: Optional[str] = Field(None, description="Tendência (improving/stable/declining)")
    previous_score: Optional[float] = Field(None, description="Score anterior")
    
    # Metadados
    total_records: int = Field(..., ge=0, description="Total de registros")
    records_with_issues: int = Field(..., ge=0, description="Registros com problemas")
    active_rules: int = Field(..., ge=0, description="Regras ativas")
    
    calculated_at: datetime = Field(..., description="Data do cálculo")
    calculated_by: str = Field(..., description="Calculado por")


# ========================================
# QUALITY INCIDENTS DTOs
# ========================================

class QualityIncidentCreateDTO(BaseModel):
    """DTO para criação de incidente de qualidade"""
    rule_id: UUID = Field(..., description="ID da regra violada")
    entity_id: UUID = Field(..., description="ID da entidade")
    severity: IncidentSeverity = Field(..., description="Severidade do incidente")
    title: str = Field(..., min_length=1, max_length=255, description="Título do incidente")
    description: str = Field(..., description="Descrição detalhada")
    affected_records: int = Field(..., ge=0, description="Registros afetados")
    sample_data: Optional[Dict[str, Any]] = Field(default={}, description="Amostra de dados")
    detection_method: str = Field(default="automated", description="Método de detecção")
    tags: Optional[List[str]] = Field(default=[], description="Tags do incidente")
    metadata: Optional[Dict[str, Any]] = Field(default={}, description="Metadados adicionais")


class QualityIncidentUpdateDTO(BaseModel):
    """DTO para atualização de incidente de qualidade"""
    status: Optional[IncidentStatus] = Field(None, description="Status do incidente")
    severity: Optional[IncidentSeverity] = Field(None, description="Severidade do incidente")
    title: Optional[str] = Field(None, min_length=1, max_length=255, description="Título")
    description: Optional[str] = Field(None, description="Descrição detalhada")
    resolution_notes: Optional[str] = Field(None, description="Notas de resolução")
    assigned_to: Optional[str] = Field(None, description="Responsável pela resolução")
    tags: Optional[List[str]] = Field(None, description="Tags do incidente")
    metadata: Optional[Dict[str, Any]] = Field(None, description="Metadados adicionais")


class QualityIncidentResponseDTO(BaseModel):
    """DTO para resposta de incidente de qualidade"""
    id: UUID = Field(..., description="ID do incidente")
    rule_id: UUID = Field(..., description="ID da regra violada")
    rule_name: str = Field(..., description="Nome da regra")
    entity_id: UUID = Field(..., description="ID da entidade")
    entity_name: str = Field(..., description="Nome da entidade")
    severity: IncidentSeverity = Field(..., description="Severidade do incidente")
    status: IncidentStatus = Field(..., description="Status do incidente")
    title: str = Field(..., description="Título do incidente")
    description: str = Field(..., description="Descrição detalhada")
    affected_records: int = Field(..., description="Registros afetados")
    sample_data: Dict[str, Any] = Field(default={}, description="Amostra de dados")
    detection_method: str = Field(..., description="Método de detecção")
    resolution_notes: Optional[str] = Field(None, description="Notas de resolução")
    assigned_to: Optional[str] = Field(None, description="Responsável pela resolução")
    tags: List[str] = Field(default=[], description="Tags do incidente")
    metadata: Dict[str, Any] = Field(default={}, description="Metadados adicionais")
    
    # Timestamps
    detected_at: datetime = Field(..., description="Data de detecção")
    acknowledged_at: Optional[datetime] = Field(None, description="Data de reconhecimento")
    resolved_at: Optional[datetime] = Field(None, description="Data de resolução")
    closed_at: Optional[datetime] = Field(None, description="Data de fechamento")
    
    # Auditoria
    created_by: str = Field(..., description="Criado por")
    created_at: datetime = Field(..., description="Data de criação")
    updated_by: Optional[str] = Field(None, description="Atualizado por")
    updated_at: Optional[datetime] = Field(None, description="Data de atualização")


# ========================================
# PAGINATION DTOs
# ========================================

class QualityRuleListResponseDTO(BaseModel):
    """DTO para lista paginada de regras de qualidade"""
    items: List[QualityRuleResponseDTO] = Field(..., description="Lista de regras")
    total: int = Field(..., ge=0, description="Total de itens")
    page: int = Field(..., ge=1, description="Página atual")
    size: int = Field(..., ge=1, description="Tamanho da página")
    pages: int = Field(..., ge=1, description="Total de páginas")


class QualityIncidentListResponseDTO(BaseModel):
    """DTO para lista paginada de incidentes de qualidade"""
    items: List[QualityIncidentResponseDTO] = Field(..., description="Lista de incidentes")
    total: int = Field(..., ge=0, description="Total de itens")
    page: int = Field(..., ge=1, description="Página atual")
    size: int = Field(..., ge=1, description="Tamanho da página")
    pages: int = Field(..., ge=1, description="Total de páginas")


# ========================================
# DASHBOARD DTOs
# ========================================

class QualityDashboardDTO(BaseModel):
    """DTO para dashboard de qualidade"""
    summary: Dict[str, Any] = Field(..., description="Resumo geral")
    metrics_by_domain: List[Dict[str, Any]] = Field(..., description="Métricas por domínio")
    recent_incidents: List[QualityIncidentResponseDTO] = Field(..., description="Incidentes recentes")
    trending_rules: List[Dict[str, Any]] = Field(..., description="Regras em tendência")
    quality_trends: Dict[str, List[float]] = Field(..., description="Tendências de qualidade")
    generated_at: datetime = Field(..., description="Data de geração")
    generated_by: str = Field(..., description="Gerado por")


# Exportar todos os DTOs
__all__ = [
    # Enums
    "QualityRuleType",
    "QualityRuleStatus", 
    "IncidentSeverity",
    "IncidentStatus",
    
    # Quality Rules
    "QualityRuleCreateDTO",
    "QualityRuleUpdateDTO",
    "QualityRuleResponseDTO",
    "QualityRuleListResponseDTO",
    
    # Quality Metrics
    "QualityMetricResponseDTO",
    
    # Quality Incidents
    "QualityIncidentCreateDTO",
    "QualityIncidentUpdateDTO", 
    "QualityIncidentResponseDTO",
    "QualityIncidentListResponseDTO",
    
    # Dashboard
    "QualityDashboardDTO"
]

