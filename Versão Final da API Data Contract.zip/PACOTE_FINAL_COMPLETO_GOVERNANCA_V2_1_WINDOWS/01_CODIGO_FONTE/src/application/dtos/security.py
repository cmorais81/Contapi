from typing import TypeVar
"""
DTOs para Segurança Avançada
"""

from datetime import datetime
from enum import Enum
from typing import Dict, List, Optional, Union
from uuid import UUID

from pydantic import BaseModel, Field


class PermissionType(str, Enum):
    """Tipo de permissão"""
    READ = "read"
    WRITE = "write"
    DELETE = "delete"
    EXECUTE = "execute"
    ADMIN = "admin"
    APPROVE = "approve"
    AUDIT = "audit"


class ResourceType(str, Enum):
    """Tipo de recurso"""
    ENTITY = "entity"
    DOMAIN = "domain"
    CONTRACT = "contract"
    POLICY = "policy"
    WORKFLOW = "workflow"
    INTEGRATION = "integration"
    SYSTEM = "system"
    ALL = "all"


class AccessLevel(str, Enum):
    """Nível de acesso"""
    NONE = "none"
    READ_ONLY = "read_only"
    READ_WRITE = "read_write"
    FULL_ACCESS = "full_access"
    ADMIN = "admin"


class EncryptionAlgorithm(str, Enum):
    """Algoritmo de criptografia"""
    AES_256 = "aes_256"
    RSA_2048 = "rsa_2048"
    RSA_4096 = "rsa_4096"
    ECDSA = "ecdsa"
    CHACHA20 = "chacha20"


class KeyStatus(str, Enum):
    """Status da chave"""
    ACTIVE = "active"
    INACTIVE = "inactive"
    EXPIRED = "expired"
    REVOKED = "revoked"
    PENDING = "pending"


class RoleCreateDTO(BaseModel):
    """DTO para criação de papel"""
    name: str = Field(..., min_length=1, max_length=100)
    description: str
    permissions: List[str] = Field(min_items=1)
    resource_types: List[ResourceType] = Field(min_items=1)
    is_system_role: bool = Field(default=False)
    parent_role_id: Optional[UUID] = None
    metadata: Dict = Field(default_factory=dict)

    class Config:
        json_schema_extra = {
            "example": {
                "name": "Data Steward",
                "description": "Role for data stewards with entity management permissions",
                "permissions": ["read", "write", "approve"],
                "resource_types": ["entity", "domain", "contract"],
                "is_system_role": False,
                "parent_role_id": None,
                "metadata": {"department": "data_governance"}
            }
        }


class RoleResponseDTO(BaseModel):
    """DTO para resposta de papel"""
    id: UUID
    name: str
    description: str
    permissions: List[str]
    resource_types: List[ResourceType]
    is_system_role: bool
    parent_role_id: Optional[UUID] = None
    parent_role_name: Optional[str] = None
    child_roles: List[Dict] = Field(default_factory=list)
    user_count: int = Field(default=0)
    is_active: bool
    created_by: UUID
    created_at: datetime
    updated_at: datetime
    metadata: Dict

    class Config:
        from_attributes = True


class PermissionCreateDTO(BaseModel):
    """DTO para criação de permissão"""
    name: str = Field(..., min_length=1, max_length=100)
    description: str
    permission_type: PermissionType
    resource_type: ResourceType
    actions: List[str] = Field(min_items=1)
    conditions: Dict = Field(default_factory=dict)
    is_system_permission: bool = Field(default=False)
    metadata: Dict = Field(default_factory=dict)

    class Config:
        json_schema_extra = {
            "example": {
                "name": "Entity Read Permission",
                "description": "Permission to read entity metadata",
                "permission_type": "read",
                "resource_type": "entity",
                "actions": ["view_metadata", "view_lineage", "view_quality"],
                "conditions": {
                    "classification_level": ["public", "internal"],
                    "domain_access": True
                },
                "is_system_permission": True,
                "metadata": {"category": "data_access"}
            }
        }


class PermissionResponseDTO(BaseModel):
    """DTO para resposta de permissão"""
    id: UUID
    name: str
    description: str
    permission_type: PermissionType
    resource_type: ResourceType
    actions: List[str]
    conditions: Dict
    is_system_permission: bool
    usage_count: int = Field(default=0)
    is_active: bool
    created_by: UUID
    created_at: datetime
    updated_at: datetime
    metadata: Dict

    class Config:
        from_attributes = True


class AccessControlCreateDTO(BaseModel):
    """DTO para criação de controle de acesso"""
    user_id: UUID
    resource_type: ResourceType
    resource_id: Optional[UUID] = None
    access_level: AccessLevel
    permissions: List[str] = Field(default_factory=list)
    conditions: Dict = Field(default_factory=dict)
    expires_at: Optional[datetime] = None
    granted_by: UUID
    reason: str
    metadata: Dict = Field(default_factory=dict)

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "123e4567-e89b-12d3-a456-426614174000",
                "resource_type": "entity",
                "resource_id": "456e7890-e89b-12d3-a456-426614174000",
                "access_level": "read_write",
                "permissions": ["read", "write", "approve"],
                "conditions": {
                    "time_based": True,
                    "ip_restrictions": ["192.168.1.0/24"],
                    "mfa_required": True
                },
                "expires_at": "2025-12-31T23:59:59Z",
                "granted_by": "789e0123-e89b-12d3-a456-426614174000",
                "reason": "Project assignment for Q1 2025",
                "metadata": {"project_code": "PROJ-2025-001"}
            }
        }


class AccessControlResponseDTO(BaseModel):
    """DTO para resposta de controle de acesso"""
    id: UUID
    user_id: UUID
    user_name: str
    user_email: str
    resource_type: ResourceType
    resource_id: Optional[UUID]
    resource_name: Optional[str]
    access_level: AccessLevel
    permissions: List[str]
    conditions: Dict
    is_active: bool
    expires_at: Optional[datetime]
    granted_by: UUID
    granted_by_name: str
    reason: str
    last_accessed: Optional[datetime] = None
    access_count: int = Field(default=0)
    created_at: datetime
    updated_at: datetime
    metadata: Dict

    class Config:
        from_attributes = True


class AccessLogDTO(BaseModel):
    """DTO para log de acesso"""
    id: UUID
    user_id: UUID
    user_name: str
    user_email: str
    action: str
    resource_type: ResourceType
    resource_id: Optional[UUID]
    resource_name: Optional[str]
    access_granted: bool
    ip_address: str
    user_agent: str
    session_id: Optional[str]
    request_method: str
    request_path: str
    response_status: int
    response_time_ms: int
    error_message: Optional[str] = None
    risk_score: float = Field(ge=0, le=1)
    geolocation: Dict = Field(default_factory=dict)
    timestamp: datetime
    metadata: Dict = Field(default_factory=dict)

    class Config:
        from_attributes = True


class EncryptionKeyCreateDTO(BaseModel):
    """DTO para criação de chave de criptografia"""
    name: str = Field(..., min_length=1, max_length=100)
    description: str
    algorithm: EncryptionAlgorithm
    key_size: int = Field(ge=128, le=4096)
    purpose: str  # encryption, signing, key_exchange
    usage_restrictions: List[str] = Field(default_factory=list)
    expires_at: Optional[datetime] = None
    auto_rotate: bool = Field(default=True)
    rotation_interval_days: int = Field(default=90, ge=1, le=365)
    metadata: Dict = Field(default_factory=dict)

    class Config:
        json_schema_extra = {
            "example": {
                "name": "Data Encryption Key",
                "description": "Master key for encrypting sensitive data",
                "algorithm": "aes_256",
                "key_size": 256,
                "purpose": "encryption",
                "usage_restrictions": ["data_encryption", "backup_encryption"],
                "expires_at": "2026-01-15T00:00:00Z",
                "auto_rotate": True,
                "rotation_interval_days": 90,
                "metadata": {"environment": "production"}
            }
        }


class EncryptionKeyResponseDTO(BaseModel):
    """DTO para resposta de chave de criptografia"""
    id: UUID
    name: str
    description: str
    algorithm: EncryptionAlgorithm
    key_size: int
    purpose: str
    status: KeyStatus
    usage_restrictions: List[str]
    key_fingerprint: str
    expires_at: Optional[datetime]
    auto_rotate: bool
    rotation_interval_days: int
    last_rotated: Optional[datetime] = None
    next_rotation: Optional[datetime] = None
    usage_count: int = Field(default=0)
    created_by: UUID
    created_at: datetime
    updated_at: datetime
    metadata: Dict

    class Config:
        from_attributes = True


class SecurityComplianceReportDTO(BaseModel):
    """DTO para relatório de compliance de segurança"""
    report_id: UUID
    report_type: str  # security_audit, compliance_check, risk_assessment
    scope: Dict = Field(default_factory=dict)
    compliance_frameworks: List[str] = Field(default_factory=list)
    overall_score: float = Field(ge=0, le=100)
    risk_level: str  # low, medium, high, critical
    findings: List[Dict] = Field(default_factory=list)
    recommendations: List[Dict] = Field(default_factory=list)
    remediation_plan: Dict = Field(default_factory=dict)
    metrics: Dict = Field(default_factory=dict)
    period_start: datetime
    period_end: datetime
    generated_by: UUID
    generated_at: datetime
    metadata: Dict = Field(default_factory=dict)

    class Config:
        json_schema_extra = {
            "example": {
                "report_id": "123e4567-e89b-12d3-a456-426614174000",
                "report_type": "security_audit",
                "scope": {
                    "users": 150,
                    "roles": 25,
                    "permissions": 100,
                    "resources": 500
                },
                "compliance_frameworks": ["SOC2", "ISO27001", "GDPR"],
                "overall_score": 85.5,
                "risk_level": "medium",
                "findings": [
                    {
                        "category": "access_control",
                        "severity": "medium",
                        "description": "5 users with excessive permissions",
                        "count": 5
                    }
                ],
                "recommendations": [
                    {
                        "priority": "high",
                        "category": "access_control",
                        "description": "Review and reduce excessive permissions",
                        "estimated_effort": "2 days"
                    }
                ],
                "remediation_plan": {
                    "total_items": 8,
                    "high_priority": 3,
                    "estimated_completion": "2025-02-15"
                },
                "metrics": {
                    "privileged_users": 12,
                    "inactive_users": 8,
                    "password_compliance": 0.95,
                    "mfa_adoption": 0.78
                },
                "period_start": "2025-01-01T00:00:00Z",
                "period_end": "2025-01-14T23:59:59Z",
                "generated_by": "456e7890-e89b-12d3-a456-426614174000",
                "generated_at": "2025-01-15T10:00:00Z",
                "metadata": {"automated": True, "version": "1.0"}
            }
        }


class SecurityMetricsDTO(BaseModel):
    """DTO para métricas de segurança"""
    total_users: int
    active_users: int
    privileged_users: int
    inactive_users: int
    total_roles: int
    custom_roles: int
    system_roles: int
    total_permissions: int
    access_violations: int
    failed_logins: int
    successful_logins: int
    mfa_enabled_users: int
    password_compliance_rate: float = Field(ge=0, le=1)
    encryption_coverage: float = Field(ge=0, le=1)
    audit_log_retention_days: int
    security_incidents: int
    resolved_incidents: int
    avg_incident_resolution_hours: float
    risk_score: float = Field(ge=0, le=100)
    compliance_score: float = Field(ge=0, le=100)
    period_start: datetime
    period_end: datetime

    class Config:
        json_schema_extra = {
            "example": {
                "total_users": 150,
                "active_users": 142,
                "privileged_users": 12,
                "inactive_users": 8,
                "total_roles": 25,
                "custom_roles": 15,
                "system_roles": 10,
                "total_permissions": 100,
                "access_violations": 3,
                "failed_logins": 45,
                "successful_logins": 2850,
                "mfa_enabled_users": 117,
                "password_compliance_rate": 0.95,
                "encryption_coverage": 0.98,
                "audit_log_retention_days": 365,
                "security_incidents": 2,
                "resolved_incidents": 2,
                "avg_incident_resolution_hours": 4.5,
                "risk_score": 25.5,
                "compliance_score": 85.5,
                "period_start": "2025-01-01T00:00:00Z",
                "period_end": "2025-01-14T23:59:59Z"
            }
        }


class UserRoleAssignmentDTO(BaseModel):
    """DTO para atribuição de papel a usuário"""
    user_id: UUID
    role_ids: List[UUID] = Field(min_items=1)
    expires_at: Optional[datetime] = None
    assigned_by: UUID
    reason: str
    metadata: Dict = Field(default_factory=dict)

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "123e4567-e89b-12d3-a456-426614174000",
                "role_ids": ["456e7890-e89b-12d3-a456-426614174000"],
                "expires_at": "2025-12-31T23:59:59Z",
                "assigned_by": "789e0123-e89b-12d3-a456-426614174000",
                "reason": "New team member assignment",
                "metadata": {"department": "data_analytics"}
            }
        }

