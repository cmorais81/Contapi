"""
DTOs Comuns
API de Governança de Dados V1.2
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from typing import Optional, List, Any, Dict, TypeVar, Generic
from datetime import datetime
from pydantic import BaseModel, Field

T = TypeVar('T')

class PaginatedResponse(BaseModel, Generic[T]):
    """Resposta paginada padrão para listas"""
    
    items: List[T] = Field(..., description="Lista de itens")
    total: int = Field(..., description="Total de itens")
    page: int = Field(default=1, description="Página atual")
    page_size: int = Field(default=20, description="Tamanho da página")
    total_pages: int = Field(..., description="Total de páginas")
    has_next: bool = Field(..., description="Tem próxima página")
    has_previous: bool = Field(..., description="Tem página anterior")
    
    class Config:
        json_encoders = {
            # Adicionar encoders personalizados se necessário
        }
    
    @classmethod
    def create(cls, items: List[T], total: int, page: int = 1, page_size: int = 20):
        """Cria uma resposta paginada"""
        total_pages = (total + page_size - 1) // page_size
        has_next = page < total_pages
        has_previous = page > 1
        
        return cls(
            items=items,
            total=total,
            page=page,
            page_size=page_size,
            total_pages=total_pages,
            has_next=has_next,
            has_previous=has_previous
        )

class BaseResponseDTO(BaseModel):
    """DTO base para respostas"""
    
    success: bool = Field(default=True, description="Sucesso da operação")
    message: Optional[str] = Field(default=None, description="Mensagem da resposta")
    timestamp: str = Field(..., description="Timestamp da resposta")
    author: str = Field(default="Carlos Morais", description="Autor da resposta")
    email: str = Field(default="carlos.morais@f1rst.com.br", description="Email do autor")

class ErrorResponseDTO(BaseModel):
    """DTO para respostas de erro"""
    
    success: bool = Field(default=False, description="Sucesso da operação")
    error: str = Field(..., description="Mensagem de erro")
    error_code: Optional[str] = Field(default=None, description="Código do erro")
    details: Optional[dict] = Field(default=None, description="Detalhes do erro")
    timestamp: str = Field(..., description="Timestamp do erro")
    author: str = Field(default="Carlos Morais", description="Autor da resposta")
    email: str = Field(default="carlos.morais@f1rst.com.br", description="Email do autor")

class HealthCheckResponseDTO(BaseModel):
    """DTO para resposta de health check"""
    
    status: str = Field(..., description="Status da aplicação")
    timestamp: str = Field(..., description="Timestamp da verificação")
    version: str = Field(..., description="Versão da aplicação")
    python_version: str = Field(..., description="Versão do Python")
    platform: str = Field(..., description="Plataforma do sistema")
    author: str = Field(default="Carlos Morais", description="Autor da aplicação")
    email: str = Field(default="carlos.morais@f1rst.com.br", description="Email do autor")
    organization: str = Field(default="F1rst", description="Organização")

class MetricsResponseDTO(BaseModel):
    """DTO para resposta de métricas"""
    
    metric_name: str = Field(..., description="Nome da métrica")
    metric_value: float = Field(..., description="Valor da métrica")
    metric_unit: Optional[str] = Field(default=None, description="Unidade da métrica")
    timestamp: str = Field(..., description="Timestamp da métrica")
    tags: Optional[dict] = Field(default=None, description="Tags da métrica")
    author: str = Field(default="Carlos Morais", description="Autor da métrica")
    email: str = Field(default="carlos.morais@f1rst.com.br", description="Email do autor")

class StatusResponseDTO(BaseModel):
    """DTO para resposta de status"""
    
    component: str = Field(..., description="Nome do componente")
    status: str = Field(..., description="Status do componente")
    details: Optional[dict] = Field(default=None, description="Detalhes do status")
    last_check: str = Field(..., description="Última verificação")
    author: str = Field(default="Carlos Morais", description="Autor da verificação")
    email: str = Field(default="carlos.morais@f1rst.com.br", description="Email do autor")

__all__ = [
    'PaginatedResponse',
    'BaseResponseDTO',
    'ErrorResponseDTO', 
    'HealthCheckResponseDTO',
    'MetricsResponseDTO',
    'StatusResponseDTO',
    'PaginationParams',
    'FilterParams',
    'SortParams'
]


class PaginationParams(BaseModel):
    """Parâmetros de paginação para listagens"""
    page: int = Field(default=1, ge=1, description="Número da página (começando em 1)")
    page_size: int = Field(default=20, ge=1, le=100, description="Tamanho da página (máximo 100)")
    sort_by: Optional[str] = Field(default=None, description="Campo para ordenação")
    sort_order: Optional[str] = Field(default="asc", pattern="^(asc|desc)$", description="Ordem de classificação")
    
    class Config:
        schema_extra = {
            "example": {
                "page": 1,
                "page_size": 20,
                "sort_by": "created_at",
                "sort_order": "desc"
            }
        }

class FilterParams(BaseModel):
    """Parâmetros de filtro genéricos"""
    search: Optional[str] = Field(default=None, description="Termo de busca geral")
    status: Optional[str] = Field(default=None, description="Filtro por status")
    created_after: Optional[datetime] = Field(default=None, description="Criado após esta data")
    created_before: Optional[datetime] = Field(default=None, description="Criado antes desta data")
    tags: Optional[List[str]] = Field(default=None, description="Filtro por tags")
    
    class Config:
        schema_extra = {
            "example": {
                "search": "contrato",
                "status": "active",
                "created_after": "2025-01-01T00:00:00Z",
                "tags": ["production", "critical"]
            }
        }

class SortParams(BaseModel):
    """Parâmetros de ordenação"""
    field: str = Field(description="Campo para ordenação")
    direction: str = Field(default="asc", pattern="^(asc|desc)$", description="Direção da ordenação")
    
    class Config:
        schema_extra = {
            "example": {
                "field": "name",
                "direction": "asc"
            }
        }

