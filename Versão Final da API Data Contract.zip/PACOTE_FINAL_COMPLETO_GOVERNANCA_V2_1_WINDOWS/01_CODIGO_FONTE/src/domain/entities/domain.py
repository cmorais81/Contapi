"""
Entidade de Domínio para Domínios de Negócio
"""

from datetime import datetime
from typing import Optional
from uuid import UUID, uuid4

from src.domain.value_objects import Version


class Domain:
    """Entidade que representa um domínio de negócio"""

    def __init__(
        self,
        name: str,
        display_name: str,
        description: Optional[str] = None,
        parent_domain_id: Optional[UUID] = None,
        domain_type: str = "business",
        business_owner: Optional[str] = None,
        technical_owner: Optional[str] = None,
        is_active: bool = True,
        created_by: Optional[UUID] = None,
        updated_by: Optional[UUID] = None,
        id: Optional[UUID] = None,
        created_at: Optional[datetime] = None,
        updated_at: Optional[datetime] = None
    ):
        self.id = id or uuid4()
        self.name = name
        self.display_name = display_name
        self.description = description
        self.parent_domain_id = parent_domain_id
        self.domain_type = domain_type
        self.business_owner = business_owner
        self.technical_owner = technical_owner
        self.is_active = is_active
        self.created_by = created_by
        self.updated_by = updated_by
        self.created_at = created_at or datetime.utcnow()
        self.updated_at = updated_at or datetime.utcnow()

        # Validações
        self._validate()

    def _validate(self):
        """Valida a entidade"""
        if not self.name or not self.name.strip():
            raise ValueError("Domain name cannot be empty")
        
        if not self.display_name or not self.display_name.strip():
            raise ValueError("Domain display name cannot be empty")
        
        if len(self.name) > 255:
            raise ValueError("Domain name cannot exceed 255 characters")
        
        if len(self.display_name) > 255:
            raise ValueError("Domain display name cannot exceed 255 characters")
        
        if self.description and len(self.description) > 1000:
            raise ValueError("Domain description cannot exceed 1000 characters")
        
        valid_types = ["business", "technical", "application", "data"]
        if self.domain_type not in valid_types:
            raise ValueError(f"Domain type must be one of: {valid_types}")

    def update_display_name(self, display_name: str):
        """Atualiza o nome de exibição"""
        if not display_name or not display_name.strip():
            raise ValueError("Display name cannot be empty")
        
        self.display_name = display_name
        self.updated_at = datetime.utcnow()

    def update_description(self, description: Optional[str]):
        """Atualiza a descrição"""
        if description and len(description) > 1000:
            raise ValueError("Description cannot exceed 1000 characters")
        
        self.description = description
        self.updated_at = datetime.utcnow()

    def set_parent_domain(self, parent_domain_id: Optional[UUID]):
        """Define o domínio pai"""
        if parent_domain_id == self.id:
            raise ValueError("Domain cannot be its own parent")
        
        self.parent_domain_id = parent_domain_id
        self.updated_at = datetime.utcnow()

    def assign_business_owner(self, business_owner: str):
        """Atribui responsável de negócio"""
        self.business_owner = business_owner
        self.updated_at = datetime.utcnow()

    def assign_technical_owner(self, technical_owner: str):
        """Atribui responsável técnico"""
        self.technical_owner = technical_owner
        self.updated_at = datetime.utcnow()

    def activate(self):
        """Ativa o domínio"""
        self.is_active = True
        self.updated_at = datetime.utcnow()

    def deactivate(self):
        """Desativa o domínio"""
        self.is_active = False
        self.updated_at = datetime.utcnow()

    def is_root_domain(self) -> bool:
        """Verifica se é um domínio raiz"""
        return self.parent_domain_id is None

    def can_have_children(self) -> bool:
        """Verifica se pode ter subdomínios"""
        return self.is_active

    def __str__(self):
        return f"Domain(id={self.id}, name={self.name}, display_name={self.display_name})"

    def __repr__(self):
        return self.__str__()

    def __eq__(self, other):
        if not isinstance(other, Domain):
            return False
        return self.id == other.id

    def __hash__(self):
        return hash(self.id)

