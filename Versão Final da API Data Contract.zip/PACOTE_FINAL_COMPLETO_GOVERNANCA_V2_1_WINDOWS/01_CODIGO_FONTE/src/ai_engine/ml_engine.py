"""
Engine Principal de Machine Learning
API de Governança de Dados V3.0
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

import asyncio
import numpy as np
import pandas as pd
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime, timedelta
from dataclasses import dataclass
import logging
import joblib
import json
from pathlib import Path

# ML Libraries
from sklearn.ensemble import IsolationForest, RandomForestClassifier
from sklearn.cluster import DBSCAN, KMeans
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score
import openai

logger = logging.getLogger(__name__)

@dataclass
class MLModel:
    """Modelo de Machine Learning"""
    id: str
    name: str
    model_type: str  # anomaly_detection, classification, clustering, regression
    algorithm: str
    version: str
    accuracy: float
    created_at: datetime
    last_trained: datetime
    model_path: str
    metadata: Dict[str, Any]
    status: str  # training, ready, deprecated

@dataclass
class Prediction:
    """Resultado de predição"""
    model_id: str
    input_data: Dict[str, Any]
    prediction: Any
    confidence: float
    timestamp: datetime
    explanation: Optional[str] = None

class MLEngine:
    """
    Engine principal de Machine Learning para governança de dados.
    
    Funcionalidades:
    - Treinamento automático de modelos
    - Detecção de anomalias
    - Classificação automática
    - Predição de qualidade
    - Análise de padrões
    - Recomendações inteligentes
    """
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.models: Dict[str, MLModel] = {}
        self.scalers: Dict[str, StandardScaler] = {}
        self.encoders: Dict[str, LabelEncoder] = {}
        
        # Configurações
        self.models_path = Path(config.get('models_path', '/var/models/governanca'))
        self.models_path.mkdir(parents=True, exist_ok=True)
        
        # OpenAI para explicações
        self.openai_client = openai.AsyncOpenAI(
            api_key=config.get('openai_api_key'),
            base_url=config.get('openai_api_base')
        )
        
        # Cache de predições
        self.predictions_cache = {}
        
        logger.info("Engine de ML inicializada")
    
    async def initialize(self):
        """Inicializa a engine de ML"""
        try:
            # Carregar modelos existentes
            await self._load_existing_models()
            
            # Treinar modelos iniciais se necessário
            await self._train_initial_models()
            
            logger.info("Engine de ML inicializada com sucesso")
            
        except Exception as e:
            logger.error(f"Erro ao inicializar engine de ML: {e}")
            raise
    
    async def train_anomaly_detection_model(self, data: pd.DataFrame, model_name: str = "anomaly_detector") -> MLModel:
        """Treina modelo de detecção de anomalias"""
        try:
            logger.info(f"Treinando modelo de detecção de anomalias: {model_name}")
            
            # Preparar dados
            X = self._prepare_features(data)
            
            # Normalizar dados
            scaler = StandardScaler()
            X_scaled = scaler.fit_transform(X)
            
            # Treinar modelo Isolation Forest
            model = IsolationForest(
                contamination=0.1,  # 10% de anomalias esperadas
                random_state=42,
                n_estimators=100
            )
            
            model.fit(X_scaled)
            
            # Avaliar modelo
            predictions = model.predict(X_scaled)
            anomaly_ratio = np.sum(predictions == -1) / len(predictions)
            
            # Salvar modelo
            model_id = f"{model_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            model_path = self.models_path / f"{model_id}.joblib"
            scaler_path = self.models_path / f"{model_id}_scaler.joblib"
            
            joblib.dump(model, model_path)
            joblib.dump(scaler, scaler_path)
            
            # Criar registro do modelo
            ml_model = MLModel(
                id=model_id,
                name=model_name,
                model_type="anomaly_detection",
                algorithm="isolation_forest",
                version="1.0",
                accuracy=1.0 - anomaly_ratio,  # Aproximação
                created_at=datetime.now(),
                last_trained=datetime.now(),
                model_path=str(model_path),
                metadata={
                    "contamination": 0.1,
                    "n_estimators": 100,
                    "features": list(X.columns),
                    "training_samples": len(X),
                    "anomaly_ratio": anomaly_ratio
                },
                status="ready"
            )
            
            self.models[model_id] = ml_model
            self.scalers[model_id] = scaler
            
            logger.info(f"Modelo de anomalias treinado: {model_id} (anomalias: {anomaly_ratio:.2%})")
            return ml_model
            
        except Exception as e:
            logger.error(f"Erro ao treinar modelo de anomalias: {e}")
            raise
    
    async def train_classification_model(self, data: pd.DataFrame, target_column: str, model_name: str = "classifier") -> MLModel:
        """Treina modelo de classificação"""
        try:
            logger.info(f"Treinando modelo de classificação: {model_name}")
            
            # Preparar dados
            X = self._prepare_features(data.drop(columns=[target_column]))
            y = data[target_column]
            
            # Codificar labels
            label_encoder = LabelEncoder()
            y_encoded = label_encoder.fit_transform(y)
            
            # Dividir dados
            X_train, X_test, y_train, y_test = train_test_split(
                X, y_encoded, test_size=0.2, random_state=42, stratify=y_encoded
            )
            
            # Normalizar dados
            scaler = StandardScaler()
            X_train_scaled = scaler.fit_transform(X_train)
            X_test_scaled = scaler.transform(X_test)
            
            # Treinar modelo Random Forest
            model = RandomForestClassifier(
                n_estimators=100,
                random_state=42,
                max_depth=10
            )
            
            model.fit(X_train_scaled, y_train)
            
            # Avaliar modelo
            y_pred = model.predict(X_test_scaled)
            accuracy = accuracy_score(y_test, y_pred)
            
            # Salvar modelo
            model_id = f"{model_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            model_path = self.models_path / f"{model_id}.joblib"
            scaler_path = self.models_path / f"{model_id}_scaler.joblib"
            encoder_path = self.models_path / f"{model_id}_encoder.joblib"
            
            joblib.dump(model, model_path)
            joblib.dump(scaler, scaler_path)
            joblib.dump(label_encoder, encoder_path)
            
            # Criar registro do modelo
            ml_model = MLModel(
                id=model_id,
                name=model_name,
                model_type="classification",
                algorithm="random_forest",
                version="1.0",
                accuracy=accuracy,
                created_at=datetime.now(),
                last_trained=datetime.now(),
                model_path=str(model_path),
                metadata={
                    "n_estimators": 100,
                    "max_depth": 10,
                    "features": list(X.columns),
                    "classes": list(label_encoder.classes_),
                    "training_samples": len(X_train),
                    "test_accuracy": accuracy,
                    "target_column": target_column
                },
                status="ready"
            )
            
            self.models[model_id] = ml_model
            self.scalers[model_id] = scaler
            self.encoders[model_id] = label_encoder
            
            logger.info(f"Modelo de classificação treinado: {model_id} (acurácia: {accuracy:.2%})")
            return ml_model
            
        except Exception as e:
            logger.error(f"Erro ao treinar modelo de classificação: {e}")
            raise
    
    async def predict_anomaly(self, model_id: str, data: Dict[str, Any]) -> Prediction:
        """Prediz se os dados são anômalos"""
        try:
            if model_id not in self.models:
                raise ValueError(f"Modelo não encontrado: {model_id}")
            
            ml_model = self.models[model_id]
            
            if ml_model.model_type != "anomaly_detection":
                raise ValueError(f"Modelo não é de detecção de anomalias: {model_id}")
            
            # Carregar modelo e scaler
            model = joblib.load(ml_model.model_path)
            scaler = self.scalers[model_id]
            
            # Preparar dados
            df = pd.DataFrame([data])
            X = self._prepare_features(df)
            X_scaled = scaler.transform(X)
            
            # Fazer predição
            prediction = model.predict(X_scaled)[0]
            anomaly_score = model.decision_function(X_scaled)[0]
            
            # Converter para resultado interpretável
            is_anomaly = prediction == -1
            confidence = abs(anomaly_score)
            
            # Gerar explicação
            explanation = await self._generate_anomaly_explanation(data, is_anomaly, anomaly_score)
            
            result = Prediction(
                model_id=model_id,
                input_data=data,
                prediction=is_anomaly,
                confidence=confidence,
                timestamp=datetime.now(),
                explanation=explanation
            )
            
            # Cache da predição
            self.predictions_cache[f"{model_id}_{datetime.now().timestamp()}"] = result
            
            return result
            
        except Exception as e:
            logger.error(f"Erro na predição de anomalia: {e}")
            raise
    
    async def predict_classification(self, model_id: str, data: Dict[str, Any]) -> Prediction:
        """Prediz classificação dos dados"""
        try:
            if model_id not in self.models:
                raise ValueError(f"Modelo não encontrado: {model_id}")
            
            ml_model = self.models[model_id]
            
            if ml_model.model_type != "classification":
                raise ValueError(f"Modelo não é de classificação: {model_id}")
            
            # Carregar modelo, scaler e encoder
            model = joblib.load(ml_model.model_path)
            scaler = self.scalers[model_id]
            encoder = self.encoders[model_id]
            
            # Preparar dados
            df = pd.DataFrame([data])
            X = self._prepare_features(df)
            X_scaled = scaler.transform(X)
            
            # Fazer predição
            prediction_encoded = model.predict(X_scaled)[0]
            prediction_proba = model.predict_proba(X_scaled)[0]
            
            # Decodificar predição
            prediction = encoder.inverse_transform([prediction_encoded])[0]
            confidence = max(prediction_proba)
            
            # Gerar explicação
            explanation = await self._generate_classification_explanation(
                data, prediction, confidence, ml_model.metadata.get('features', [])
            )
            
            result = Prediction(
                model_id=model_id,
                input_data=data,
                prediction=prediction,
                confidence=confidence,
                timestamp=datetime.now(),
                explanation=explanation
            )
            
            # Cache da predição
            self.predictions_cache[f"{model_id}_{datetime.now().timestamp()}"] = result
            
            return result
            
        except Exception as e:
            logger.error(f"Erro na predição de classificação: {e}")
            raise
    
    async def analyze_data_patterns(self, data: pd.DataFrame) -> Dict[str, Any]:
        """Analisa padrões nos dados"""
        try:
            logger.info("Analisando padrões nos dados")
            
            patterns = {
                'timestamp': datetime.now().isoformat(),
                'total_records': len(data),
                'columns': list(data.columns),
                'data_types': data.dtypes.to_dict(),
                'missing_values': data.isnull().sum().to_dict(),
                'statistics': {},
                'correlations': {},
                'clusters': {},
                'anomalies': {}
            }
            
            # Estatísticas descritivas
            numeric_columns = data.select_dtypes(include=[np.number]).columns
            if len(numeric_columns) > 0:
                patterns['statistics'] = data[numeric_columns].describe().to_dict()
            
            # Correlações
            if len(numeric_columns) > 1:
                corr_matrix = data[numeric_columns].corr()
                patterns['correlations'] = corr_matrix.to_dict()
            
            # Clustering (se houver dados suficientes)
            if len(data) > 10 and len(numeric_columns) > 1:
                X = data[numeric_columns].fillna(0)
                scaler = StandardScaler()
                X_scaled = scaler.fit_transform(X)
                
                # K-means clustering
                kmeans = KMeans(n_clusters=min(5, len(data)//2), random_state=42)
                clusters = kmeans.fit_predict(X_scaled)
                
                patterns['clusters'] = {
                    'n_clusters': len(np.unique(clusters)),
                    'cluster_sizes': np.bincount(clusters).tolist(),
                    'cluster_centers': kmeans.cluster_centers_.tolist()
                }
            
            # Detecção de anomalias simples
            if len(data) > 10 and len(numeric_columns) > 0:
                X = data[numeric_columns].fillna(0)
                scaler = StandardScaler()
                X_scaled = scaler.fit_transform(X)
                
                isolation_forest = IsolationForest(contamination=0.1, random_state=42)
                anomalies = isolation_forest.fit_predict(X_scaled)
                
                patterns['anomalies'] = {
                    'total_anomalies': np.sum(anomalies == -1),
                    'anomaly_ratio': np.sum(anomalies == -1) / len(anomalies),
                    'anomaly_indices': np.where(anomalies == -1)[0].tolist()
                }
            
            return patterns
            
        except Exception as e:
            logger.error(f"Erro na análise de padrões: {e}")
            return {}
    
    async def generate_recommendations(self, entity_data: Dict[str, Any], context: str = "general") -> List[Dict[str, Any]]:
        """Gera recomendações inteligentes"""
        try:
            logger.info(f"Gerando recomendações para contexto: {context}")
            
            recommendations = []
            
            # Análise baseada em regras
            rule_based_recs = await self._generate_rule_based_recommendations(entity_data, context)
            recommendations.extend(rule_based_recs)
            
            # Recomendações baseadas em ML (se houver modelos treinados)
            ml_based_recs = await self._generate_ml_based_recommendations(entity_data, context)
            recommendations.extend(ml_based_recs)
            
            # Recomendações baseadas em IA generativa
            ai_based_recs = await self._generate_ai_based_recommendations(entity_data, context)
            recommendations.extend(ai_based_recs)
            
            # Ordenar por prioridade e confiança
            recommendations.sort(key=lambda x: (x.get('priority', 0), x.get('confidence', 0)), reverse=True)
            
            return recommendations[:10]  # Top 10 recomendações
            
        except Exception as e:
            logger.error(f"Erro ao gerar recomendações: {e}")
            return []
    
    def _prepare_features(self, data: pd.DataFrame) -> pd.DataFrame:
        """Prepara features para ML"""
        # Selecionar apenas colunas numéricas
        numeric_data = data.select_dtypes(include=[np.number])
        
        # Preencher valores nulos
        numeric_data = numeric_data.fillna(0)
        
        return numeric_data
    
    async def _generate_anomaly_explanation(self, data: Dict[str, Any], is_anomaly: bool, score: float) -> str:
        """Gera explicação para detecção de anomalia"""
        try:
            if not self.openai_client:
                return f"Anomalia detectada: {is_anomaly} (score: {score:.3f})"
            
            prompt = f"""
            Analise os seguintes dados e explique por que {'foram' if is_anomaly else 'não foram'} classificados como anômalos:
            
            Dados: {json.dumps(data, indent=2)}
            Score de anomalia: {score:.3f}
            
            Forneça uma explicação clara e técnica em português.
            """
            
            response = await self.openai_client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=[{"role": "user", "content": prompt}],
                max_tokens=200,
                temperature=0.3
            )
            
            return response.choices[0].message.content.strip()
            
        except Exception as e:
            logger.error(f"Erro ao gerar explicação de anomalia: {e}")
            return f"Anomalia detectada: {is_anomaly} (score: {score:.3f})"
    
    async def _generate_classification_explanation(self, data: Dict[str, Any], prediction: str, confidence: float, features: List[str]) -> str:
        """Gera explicação para classificação"""
        try:
            if not self.openai_client:
                return f"Classificado como: {prediction} (confiança: {confidence:.2%})"
            
            prompt = f"""
            Explique por que os seguintes dados foram classificados como "{prediction}":
            
            Dados: {json.dumps(data, indent=2)}
            Confiança: {confidence:.2%}
            Features utilizadas: {features}
            
            Forneça uma explicação clara e técnica em português.
            """
            
            response = await self.openai_client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=[{"role": "user", "content": prompt}],
                max_tokens=200,
                temperature=0.3
            )
            
            return response.choices[0].message.content.strip()
            
        except Exception as e:
            logger.error(f"Erro ao gerar explicação de classificação: {e}")
            return f"Classificado como: {prediction} (confiança: {confidence:.2%})"
    
    async def _generate_rule_based_recommendations(self, entity_data: Dict[str, Any], context: str) -> List[Dict[str, Any]]:
        """Gera recomendações baseadas em regras"""
        recommendations = []
        
        # Regras para qualidade de dados
        if context in ["quality", "general"]:
            # Verificar completude
            if entity_data.get('completeness_score', 100) < 80:
                recommendations.append({
                    'type': 'quality_improvement',
                    'title': 'Melhorar Completude dos Dados',
                    'description': 'A completude dos dados está abaixo de 80%. Considere implementar validações obrigatórias.',
                    'priority': 8,
                    'confidence': 0.9,
                    'action': 'add_validation_rules'
                })
            
            # Verificar consistência
            if entity_data.get('consistency_score', 100) < 70:
                recommendations.append({
                    'type': 'quality_improvement',
                    'title': 'Melhorar Consistência dos Dados',
                    'description': 'Inconsistências detectadas nos dados. Revisar regras de negócio.',
                    'priority': 7,
                    'confidence': 0.85,
                    'action': 'review_business_rules'
                })
        
        # Regras para governança
        if context in ["governance", "general"]:
            # Verificar classificação de dados
            if not entity_data.get('data_classification'):
                recommendations.append({
                    'type': 'governance',
                    'title': 'Classificar Dados Sensíveis',
                    'description': 'Dados não classificados. Aplicar classificação de sensibilidade.',
                    'priority': 9,
                    'confidence': 0.95,
                    'action': 'classify_data'
                })
            
            # Verificar políticas de retenção
            if not entity_data.get('retention_policy'):
                recommendations.append({
                    'type': 'governance',
                    'title': 'Definir Política de Retenção',
                    'description': 'Nenhuma política de retenção definida. Configurar ciclo de vida dos dados.',
                    'priority': 6,
                    'confidence': 0.8,
                    'action': 'set_retention_policy'
                })
        
        return recommendations
    
    async def _generate_ml_based_recommendations(self, entity_data: Dict[str, Any], context: str) -> List[Dict[str, Any]]:
        """Gera recomendações baseadas em ML"""
        recommendations = []
        
        # Se houver modelos de classificação treinados, usar para recomendar ações
        classification_models = [m for m in self.models.values() if m.model_type == "classification" and m.status == "ready"]
        
        for model in classification_models[:2]:  # Usar até 2 modelos
            try:
                prediction = await self.predict_classification(model.id, entity_data)
                
                if prediction.confidence > 0.7:
                    recommendations.append({
                        'type': 'ml_prediction',
                        'title': f'Recomendação baseada em {model.name}',
                        'description': f'Modelo prevê: {prediction.prediction}',
                        'priority': int(prediction.confidence * 10),
                        'confidence': prediction.confidence,
                        'action': f'apply_{prediction.prediction.lower().replace(" ", "_")}',
                        'model_id': model.id
                    })
                    
            except Exception as e:
                logger.warning(f"Erro ao usar modelo {model.id} para recomendação: {e}")
        
        return recommendations
    
    async def _generate_ai_based_recommendations(self, entity_data: Dict[str, Any], context: str) -> List[Dict[str, Any]]:
        """Gera recomendações baseadas em IA generativa"""
        try:
            if not self.openai_client:
                return []
            
            prompt = f"""
            Como especialista em governança de dados, analise os seguintes dados e forneça 3 recomendações específicas:
            
            Contexto: {context}
            Dados da entidade: {json.dumps(entity_data, indent=2)}
            
            Para cada recomendação, forneça:
            1. Título (máximo 50 caracteres)
            2. Descrição (máximo 100 caracteres)
            3. Prioridade (1-10)
            4. Ação recomendada
            
            Responda em formato JSON válido.
            """
            
            response = await self.openai_client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=[{"role": "user", "content": prompt}],
                max_tokens=500,
                temperature=0.5
            )
            
            # Tentar parsear resposta JSON
            try:
                ai_recommendations = json.loads(response.choices[0].message.content)
                
                recommendations = []
                for rec in ai_recommendations.get('recommendations', []):
                    recommendations.append({
                        'type': 'ai_generated',
                        'title': rec.get('title', 'Recomendação IA'),
                        'description': rec.get('description', 'Recomendação gerada por IA'),
                        'priority': rec.get('priority', 5),
                        'confidence': 0.7,
                        'action': rec.get('action', 'review_manually')
                    })
                
                return recommendations
                
            except json.JSONDecodeError:
                logger.warning("Resposta da IA não está em formato JSON válido")
                return []
                
        except Exception as e:
            logger.error(f"Erro ao gerar recomendações com IA: {e}")
            return []
    
    async def _load_existing_models(self):
        """Carrega modelos existentes"""
        try:
            models_config_file = self.models_path / 'models_config.json'
            
            if models_config_file.exists():
                with open(models_config_file, 'r') as f:
                    models_config = json.load(f)
                
                for model_data in models_config:
                    model = MLModel(**model_data)
                    self.models[model.id] = model
                    
                    # Carregar scaler se existir
                    scaler_path = self.models_path / f"{model.id}_scaler.joblib"
                    if scaler_path.exists():
                        self.scalers[model.id] = joblib.load(scaler_path)
                    
                    # Carregar encoder se existir
                    encoder_path = self.models_path / f"{model.id}_encoder.joblib"
                    if encoder_path.exists():
                        self.encoders[model.id] = joblib.load(encoder_path)
                
                logger.info(f"Carregados {len(self.models)} modelos existentes")
            
        except Exception as e:
            logger.error(f"Erro ao carregar modelos existentes: {e}")
    
    async def _train_initial_models(self):
        """Treina modelos iniciais se necessário"""
        try:
            # Se não houver modelos, treinar modelos básicos com dados sintéticos
            if not self.models:
                logger.info("Treinando modelos iniciais com dados sintéticos")
                
                # Dados sintéticos para detecção de anomalias
                np.random.seed(42)
                normal_data = np.random.normal(0, 1, (1000, 5))
                anomaly_data = np.random.normal(3, 1, (100, 5))
                
                synthetic_data = pd.DataFrame(
                    np.vstack([normal_data, anomaly_data]),
                    columns=['feature_1', 'feature_2', 'feature_3', 'feature_4', 'feature_5']
                )
                
                await self.train_anomaly_detection_model(synthetic_data, "initial_anomaly_detector")
                
                # Dados sintéticos para classificação
                classification_data = synthetic_data.copy()
                classification_data['category'] = ['normal'] * 1000 + ['anomaly'] * 100
                
                await self.train_classification_model(classification_data, 'category', "initial_classifier")
                
                logger.info("Modelos iniciais treinados com sucesso")
            
        except Exception as e:
            logger.error(f"Erro ao treinar modelos iniciais: {e}")
    
    async def save_models_config(self):
        """Salva configuração dos modelos"""
        try:
            models_config = []
            
            for model in self.models.values():
                models_config.append({
                    'id': model.id,
                    'name': model.name,
                    'model_type': model.model_type,
                    'algorithm': model.algorithm,
                    'version': model.version,
                    'accuracy': model.accuracy,
                    'created_at': model.created_at.isoformat(),
                    'last_trained': model.last_trained.isoformat(),
                    'model_path': model.model_path,
                    'metadata': model.metadata,
                    'status': model.status
                })
            
            models_config_file = self.models_path / 'models_config.json'
            with open(models_config_file, 'w') as f:
                json.dump(models_config, f, indent=2)
            
        except Exception as e:
            logger.error(f"Erro ao salvar configuração dos modelos: {e}")
    
    async def get_models_status(self) -> Dict[str, Any]:
        """Obtém status dos modelos"""
        return {
            'total_models': len(self.models),
            'models_by_type': {
                model_type: len([m for m in self.models.values() if m.model_type == model_type])
                for model_type in set(m.model_type for m in self.models.values())
            },
            'models_by_status': {
                status: len([m for m in self.models.values() if m.status == status])
                for status in set(m.status for m in self.models.values())
            },
            'models': [
                {
                    'id': model.id,
                    'name': model.name,
                    'type': model.model_type,
                    'algorithm': model.algorithm,
                    'accuracy': model.accuracy,
                    'status': model.status,
                    'last_trained': model.last_trained.isoformat()
                }
                for model in self.models.values()
            ]
        }
    
    async def cleanup(self):
        """Limpa recursos"""
        try:
            await self.save_models_config()
            logger.info("Recursos de ML limpos")
            
        except Exception as e:
            logger.error(f"Erro ao limpar recursos de ML: {e}")

# Instância global da engine de ML
ml_engine_instance = None

async def get_ml_engine_instance(config: Dict[str, Any] = None) -> MLEngine:
    """Obtém instância singleton da engine de ML"""
    global ml_engine_instance
    
    if ml_engine_instance is None:
        if config is None:
            config = {}
        
        ml_engine_instance = MLEngine(config)
        await ml_engine_instance.initialize()
    
    return ml_engine_instance

