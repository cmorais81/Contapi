"""
Modelos de Autenticação e Controle de Acesso
API de Governança de Dados V1.9
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from sqlalchemy import Column, String, Boolean, Integer, DateTime, Text, ForeignKey
from sqlalchemy.dialects.postgresql import UUID, INET, JSONB
from sqlalchemy.orm import relationship
from ..base import Base

class User(Base):
    """Tabela principal de usuários do sistema com controle de acesso e auditoria"""
    __tablename__ = 'users'
    __table_args__ = {'extend_existing': True}
    __table_args__ = {'extend_existing': True}
    
    username = Column(String(255), unique=True, nullable=False, comment='Nome de usuário único no sistema')
    email = Column(String(255), unique=True, nullable=False, comment='Email para autenticação e notificações')
    hashed_password = Column(Text, nullable=False, comment='Senha criptografada com bcrypt')
    full_name = Column(Text, comment='Nome completo do usuário')
    department = Column(Text, comment='Departamento ou área de atuação')
    job_title = Column(Text, comment='Cargo ou função do usuário')
    phone = Column(Text, comment='Telefone de contato')
    is_active = Column(Boolean, default=True, comment='Status ativo/inativo do usuário')
    is_admin = Column(Boolean, default=False, comment='Permissões administrativas')
    last_login = Column(DateTime(timezone=True), comment='Último acesso ao sistema')
    password_changed_at = Column(DateTime(timezone=True), comment='Data da última alteração de senha')
    failed_login_attempts = Column(Integer, default=0, comment='Tentativas de login falhadas')
    locked_until = Column(DateTime(timezone=True), comment='Data até quando a conta está bloqueada')
    preferences = Column(JSONB, comment='Preferências do usuário em formato JSON')
    
    # Relacionamentos
    sessions = relationship("UserSession", back_populates="user", cascade="all, delete-orphan")
    roles = relationship("UserRole", back_populates="user", cascade="all, delete-orphan")
    api_keys = relationship("ApiKey", back_populates="user", cascade="all, delete-orphan")

class UserSession(Base):
    """Controle de sessões ativas dos usuários"""
    __tablename__ = 'user_sessions'
    __table_args__ = {'extend_existing': True}
    __table_args__ = {'extend_existing': True}
    
    user_id = Column(UUID(as_uuid=True), ForeignKey('users.id'), nullable=False)
    session_token = Column(Text, unique=True, nullable=False, comment='Token único da sessão')
    ip_address = Column(INET, comment='Endereço IP da sessão')
    user_agent = Column(Text, comment='Informações do navegador/cliente')
    is_active = Column(Boolean, default=True, comment='Status da sessão')
    expires_at = Column(DateTime(timezone=True), nullable=False, comment='Data de expiração da sessão')
    last_activity = Column(DateTime(timezone=True), comment='Última atividade na sessão')
    
    # Relacionamentos
    user = relationship("User", back_populates="sessions")

class SecurityRole(Base):
    """Definição de papéis de segurança e permissões"""
    __tablename__ = 'security_roles'
    __table_args__ = {'extend_existing': True}
    
    name = Column(String(255), unique=True, nullable=False, comment='Nome único do papel de segurança')
    description = Column(Text, comment='Descrição detalhada do papel')
    permissions = Column(JSONB, comment='Permissões em formato JSON')
    is_system_role = Column(Boolean, default=False, comment='Papel do sistema não editável')
    created_by = Column(UUID(as_uuid=True), ForeignKey('users.id'))
    
    # Relacionamentos
    user_roles = relationship("UserRole", back_populates="role", cascade="all, delete-orphan")
    creator = relationship("User", foreign_keys=[created_by])

class UserRole(Base):
    """Associação entre usuários e papéis de segurança"""
    __tablename__ = 'user_roles'
    __table_args__ = {'extend_existing': True}
    
    user_id = Column(UUID(as_uuid=True), ForeignKey('users.id'), nullable=False)
    role_id = Column(UUID(as_uuid=True), ForeignKey('security_roles.id'), nullable=False)
    granted_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Usuário que concedeu o papel')
    granted_at = Column(DateTime(timezone=True), nullable=False, comment='Data de concessão do papel')
    expires_at = Column(DateTime(timezone=True), comment='Data de expiração do papel')
    is_active = Column(Boolean, default=True, comment='Status ativo do papel')
    
    # Relacionamentos
    user = relationship("User", back_populates="roles", foreign_keys=[user_id])
    role = relationship("SecurityRole", back_populates="user_roles")
    granter = relationship("User", foreign_keys=[granted_by])

class ApiKey(Base):
    """Chaves de API para autenticação de sistemas externos"""
    __tablename__ = 'api_keys'
    __table_args__ = {'extend_existing': True}
    
    user_id = Column(UUID(as_uuid=True), ForeignKey('users.id'), nullable=False)
    key_name = Column(String(255), nullable=False, comment='Nome identificador da chave')
    key_hash = Column(Text, nullable=False, comment='Hash da chave de API')
    key_prefix = Column(String(20), nullable=False, comment='Prefixo visível da chave')
    permissions = Column(JSONB, comment='Permissões específicas da chave')
    is_active = Column(Boolean, default=True, comment='Status ativo da chave')
    last_used = Column(DateTime(timezone=True), comment='Último uso da chave')
    expires_at = Column(DateTime(timezone=True), comment='Data de expiração da chave')
    usage_count = Column(Integer, default=0, comment='Contador de uso da chave')
    rate_limit = Column(Integer, comment='Limite de requisições por minuto')
    allowed_ips = Column(JSONB, comment='IPs permitidos para usar a chave')
    
    # Relacionamentos
    user = relationship("User", back_populates="api_keys")


class Role(Base):
    """Roles de segurança e controle de acesso"""
    __tablename__ = 'roles'
    __table_args__ = {'extend_existing': True}
    __table_args__ = {'extend_existing': True}
    
    name = Column(String(100), unique=True, nullable=False, comment='Nome único do role')
    description = Column(Text, comment='Descrição detalhada do role')
    permissions = Column(JSONB, comment='Permissões específicas em formato JSON')
    is_active = Column(Boolean, default=True, comment='Status ativo/inativo do role')
    is_system = Column(Boolean, default=False, comment='Role do sistema (não editável)')
    
    # Relacionamentos
    user_roles = relationship("UserRole", back_populates="role", cascade="all, delete-orphan")

class UserRole(Base):
    """Associação entre usuários e roles"""
    __tablename__ = 'user_roles'
    __table_args__ = {'extend_existing': True}
    __table_args__ = {'extend_existing': True}
    
    user_id = Column(UUID(as_uuid=True), ForeignKey('users.id'), nullable=False)
    role_id = Column(UUID(as_uuid=True), ForeignKey('roles.id'), nullable=False)
    granted_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Usuário que concedeu o role')
    granted_at = Column(DateTime(timezone=True), comment='Data de concessão do role')
    expires_at = Column(DateTime(timezone=True), comment='Data de expiração do role')
    is_active = Column(Boolean, default=True, comment='Status ativo/inativo da associação')
    
    # Relacionamentos
    user = relationship("User", back_populates="roles", foreign_keys=[user_id])
    role = relationship("Role", back_populates="user_roles")
    granted_by_user = relationship("User", foreign_keys=[granted_by])

class ApiKey(Base):
    """Chaves de API para acesso programático"""
    __tablename__ = 'api_keys'
    __table_args__ = {'extend_existing': True}
    __table_args__ = {'extend_existing': True}
    
    user_id = Column(UUID(as_uuid=True), ForeignKey('users.id'), nullable=False)
    name = Column(String(100), nullable=False, comment='Nome identificador da API key')
    key_hash = Column(Text, nullable=False, comment='Hash da chave de API')
    permissions = Column(JSONB, comment='Permissões específicas da API key')
    is_active = Column(Boolean, default=True, comment='Status ativo/inativo da chave')
    last_used = Column(DateTime(timezone=True), comment='Último uso da API key')
    expires_at = Column(DateTime(timezone=True), comment='Data de expiração da chave')
    usage_count = Column(Integer, default=0, comment='Contador de uso da chave')
    rate_limit = Column(Integer, comment='Limite de requisições por minuto')
    
    # Relacionamentos
    user = relationship("User", back_populates="api_keys")

