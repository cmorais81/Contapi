"""
Modelo de Mascaramento de Dados
API de Governança de Dados V2.2
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from sqlalchemy import Column, String, Text, Boolean, Integer, DateTime, ForeignKey, Enum as SQLEnum
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import relationship
from enum import Enum
from ..base import Base

class MaskingType(Enum):
    STATIC = "static"
    DYNAMIC = "dynamic"
    FORMAT_PRESERVING = "format_preserving"
    TOKENIZATION = "tokenization"
    ENCRYPTION = "encryption"
    REDACTION = "redaction"
    SUBSTITUTION = "substitution"
    SHUFFLING = "shuffling"
    NULL_OUT = "null_out"
    CUSTOM = "custom"

class DataCategory(Enum):
    PII = "pii"  # Personally Identifiable Information
    PHI = "phi"  # Protected Health Information
    PCI = "pci"  # Payment Card Industry
    FINANCIAL = "financial"
    SENSITIVE = "sensitive"
    CONFIDENTIAL = "confidential"
    PUBLIC = "public"
    INTERNAL = "internal"

class MaskingStatus(Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    TESTING = "testing"
    DEPRECATED = "deprecated"
    ERROR = "error"

class EnvironmentType(Enum):
    PRODUCTION = "production"
    STAGING = "staging"
    DEVELOPMENT = "development"
    TESTING = "testing"
    SANDBOX = "sandbox"

class DataMaskingRule(Base):
    """Regras de mascaramento de dados"""
    __tablename__ = 'data_masking_rules'
    __table_args__ = {'extend_existing': True}
    
    name = Column(String(255), nullable=False, comment='Nome da regra de mascaramento')
    description = Column(Text, comment='Descrição da regra')
    
    # Configurações da regra
    masking_type = Column(SQLEnum(MaskingType), nullable=False, comment='Tipo de mascaramento')
    data_category = Column(SQLEnum(DataCategory), nullable=False, comment='Categoria dos dados')
    
    # Escopo da regra
    entity_id = Column(UUID(as_uuid=True), ForeignKey('entities.id'), comment='Entidade alvo')
    attribute_pattern = Column(String(255), comment='Padrão de atributos (regex)')
    data_type_filter = Column(JSONB, comment='Filtros por tipo de dados')
    
    # Configurações de mascaramento
    masking_function = Column(String(255), comment='Função de mascaramento')
    masking_parameters = Column(JSONB, comment='Parâmetros da função')
    preserve_format = Column(Boolean, default=False, comment='Preservar formato original')
    preserve_length = Column(Boolean, default=False, comment='Preservar comprimento')
    
    # Configurações específicas por tipo
    static_value = Column(String(255), comment='Valor estático para substituição')
    encryption_key_id = Column(String(255), comment='ID da chave de criptografia')
    tokenization_format = Column(String(100), comment='Formato de tokenização')
    
    # Configurações de substituição
    substitution_dictionary = Column(JSONB, comment='Dicionário de substituições')
    substitution_source = Column(String(255), comment='Fonte dos dados de substituição')
    
    # Configurações de redação
    redaction_character = Column(String(1), default='*', comment='Caractere de redação')
    partial_masking = Column(Boolean, default=False, comment='Mascaramento parcial')
    visible_characters = Column(Integer, comment='Caracteres visíveis (início/fim)')
    
    # Ambientes aplicáveis
    target_environments = Column(JSONB, comment='Ambientes onde aplicar')
    exclude_environments = Column(JSONB, comment='Ambientes para excluir')
    
    # Condições de aplicação
    conditional_logic = Column(Text, comment='Lógica condicional para aplicação')
    user_role_exceptions = Column(JSONB, comment='Papéis de usuário com exceção')
    time_based_rules = Column(JSONB, comment='Regras baseadas em tempo')
    
    # Configurações de performance
    batch_size = Column(Integer, default=1000, comment='Tamanho do lote para processamento')
    parallel_processing = Column(Boolean, default=False, comment='Processamento paralelo')
    cache_masked_values = Column(Boolean, default=False, comment='Cache de valores mascarados')
    
    # Auditoria e compliance
    compliance_requirements = Column(JSONB, comment='Requisitos de compliance')
    audit_level = Column(String(50), default='standard', comment='Nível de auditoria')
    log_access_attempts = Column(Boolean, default=True, comment='Log de tentativas de acesso')
    
    # Configurações de reversibilidade
    is_reversible = Column(Boolean, default=False, comment='Mascaramento reversível')
    reversal_key_id = Column(String(255), comment='ID da chave de reversão')
    reversal_conditions = Column(JSONB, comment='Condições para reversão')
    
    # Validação e testes
    validation_rules = Column(JSONB, comment='Regras de validação')
    test_data_samples = Column(JSONB, comment='Amostras de dados para teste')
    quality_checks = Column(JSONB, comment='Verificações de qualidade')
    
    # Status e execução
    status = Column(SQLEnum(MaskingStatus), default=MaskingStatus.INACTIVE, comment='Status da regra')
    last_applied_at = Column(DateTime(timezone=True), comment='Última aplicação')
    next_scheduled_run = Column(DateTime(timezone=True), comment='Próxima execução agendada')
    
    # Estatísticas
    records_processed = Column(Integer, default=0, comment='Registros processados')
    success_rate = Column(Float, comment='Taxa de sucesso')
    average_processing_time = Column(Float, comment='Tempo médio de processamento')
    
    # Metadados
    created_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), nullable=False, comment='Criador da regra')
    approved_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Aprovador da regra')
    approved_at = Column(DateTime(timezone=True), comment='Data de aprovação')
    
    # Configurações de notificação
    notify_on_failure = Column(Boolean, default=True, comment='Notificar em falha')
    notification_recipients = Column(JSONB, comment='Destinatários das notificações')
    
    # Integração com ferramentas externas
    databricks_policy_id = Column(String(255), comment='ID da política no Databricks')
    external_tool_config = Column(JSONB, comment='Configuração de ferramentas externas')
    
    # Relacionamentos
    entity = relationship("Entity")
    creator = relationship("User", foreign_keys=[created_by])
    approver = relationship("User", foreign_keys=[approved_by])

