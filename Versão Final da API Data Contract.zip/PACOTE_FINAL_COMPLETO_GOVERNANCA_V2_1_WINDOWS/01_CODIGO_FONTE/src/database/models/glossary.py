"""
Modelo de Glossário de Negócio
API de Governança de Dados V2.3
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from sqlalchemy import Column, String, Text, Boolean, DateTime, ForeignKey, JSON, Integer
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from datetime import datetime
import uuid

from src.database.base import BaseModel

class BusinessGlossary(BaseModel):
    """
    Modelo para Glossário de Negócio
    
    Gerencia definições de termos de negócio, conceitos e vocabulário
    organizacional para garantir entendimento comum dos dados.
    """
    __tablename__ = 'business_glossary'
    __table_args__ = {'extend_existing': True}
    
    # Identificação
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    term = Column(String(255), nullable=False, index=True, comment="Nome do termo")
    category = Column(String(100), nullable=False, index=True, comment="Categoria do termo")
    
    # Definições
    definition = Column(Text, nullable=False, comment="Definição completa do termo")
    business_definition = Column(Text, comment="Definição de negócio específica")
    technical_definition = Column(Text, comment="Definição técnica específica")
    
    # Contexto
    domain = Column(String(100), index=True, comment="Domínio de negócio")
    subdomain = Column(String(100), comment="Subdomínio específico")
    business_area = Column(String(100), comment="Área de negócio responsável")
    
    # Relacionamentos
    synonyms = Column(JSON, comment="Lista de sinônimos")
    related_terms = Column(JSON, comment="Termos relacionados")
    acronyms = Column(JSON, comment="Acrônimos e abreviações")
    
    # Exemplos e uso
    examples = Column(JSON, comment="Exemplos de uso do termo")
    usage_context = Column(Text, comment="Contexto de uso")
    business_rules = Column(JSON, comment="Regras de negócio associadas")
    
    # Responsabilidade
    business_owner = Column(String(255), comment="Responsável de negócio")
    technical_owner = Column(String(255), comment="Responsável técnico")
    steward = Column(String(255), comment="Data steward responsável")
    
    # Status e aprovação
    status = Column(String(50), nullable=False, default='draft', index=True,
                   comment="Status: draft, review, approved, deprecated")
    approval_status = Column(String(50), default='pending',
                           comment="Status de aprovação: pending, approved, rejected")
    approved_by = Column(String(255), comment="Aprovado por")
    approved_at = Column(DateTime, comment="Data de aprovação")
    
    # Versionamento
    version = Column(String(20), nullable=False, default='1.0', comment="Versão do termo")
    previous_version_id = Column(UUID(as_uuid=True), ForeignKey('business_glossary.id'),
                                comment="Versão anterior")
    change_reason = Column(Text, comment="Motivo da mudança")
    
    # Qualidade e confiança
    confidence_score = Column(Integer, default=100, comment="Score de confiança (0-100)")
    quality_score = Column(Integer, comment="Score de qualidade da definição")
    completeness_score = Column(Integer, comment="Score de completude")
    
    # Uso e popularidade
    usage_count = Column(Integer, default=0, comment="Número de usos")
    search_count = Column(Integer, default=0, comment="Número de buscas")
    last_accessed = Column(DateTime, comment="Último acesso")
    
    # Compliance e regulamentação
    regulatory_classification = Column(String(100), comment="Classificação regulatória")
    compliance_frameworks = Column(JSON, comment="Frameworks de compliance")
    sensitivity_level = Column(String(50), comment="Nível de sensibilidade")
    
    # Metadados de origem
    source_system = Column(String(255), comment="Sistema de origem")
    source_reference = Column(String(500), comment="Referência na origem")
    external_references = Column(JSON, comment="Referências externas")
    
    # Configurações
    is_active = Column(Boolean, default=True, nullable=False, comment="Termo ativo")
    is_public = Column(Boolean, default=True, comment="Visível publicamente")
    requires_approval = Column(Boolean, default=True, comment="Requer aprovação")
    
    # Auditoria automática (herdada de BaseModel)
    # created_at, updated_at, created_by, updated_by
    
    # Relacionamentos SQLAlchemy
    previous_version = relationship("BusinessGlossary", remote_side=[id])
    
    def __repr__(self):
        return f"<BusinessGlossary(id={self.id}, term='{self.term}', category='{self.category}')>"
    
    def to_dict(self):
        """Converte o modelo para dicionário"""
        return {
            'id': str(self.id),
            'term': self.term,
            'category': self.category,
            'definition': self.definition,
            'business_definition': self.business_definition,
            'technical_definition': self.technical_definition,
            'domain': self.domain,
            'subdomain': self.subdomain,
            'business_area': self.business_area,
            'synonyms': self.synonyms,
            'related_terms': self.related_terms,
            'acronyms': self.acronyms,
            'examples': self.examples,
            'usage_context': self.usage_context,
            'business_rules': self.business_rules,
            'business_owner': self.business_owner,
            'technical_owner': self.technical_owner,
            'steward': self.steward,
            'status': self.status,
            'approval_status': self.approval_status,
            'approved_by': self.approved_by,
            'approved_at': self.approved_at.isoformat() if self.approved_at else None,
            'version': self.version,
            'previous_version_id': str(self.previous_version_id) if self.previous_version_id else None,
            'change_reason': self.change_reason,
            'confidence_score': self.confidence_score,
            'quality_score': self.quality_score,
            'completeness_score': self.completeness_score,
            'usage_count': self.usage_count,
            'search_count': self.search_count,
            'last_accessed': self.last_accessed.isoformat() if self.last_accessed else None,
            'regulatory_classification': self.regulatory_classification,
            'compliance_frameworks': self.compliance_frameworks,
            'sensitivity_level': self.sensitivity_level,
            'source_system': self.source_system,
            'source_reference': self.source_reference,
            'external_references': self.external_references,
            'is_active': self.is_active,
            'is_public': self.is_public,
            'requires_approval': self.requires_approval,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'created_by': self.created_by,
            'updated_by': self.updated_by
        }
    
    @classmethod
    def get_categories(cls):
        """Retorna categorias disponíveis"""
        return [
            'business_concept',
            'technical_term',
            'metric',
            'kpi',
            'dimension',
            'measure',
            'entity',
            'attribute',
            'process',
            'system',
            'regulation',
            'compliance'
        ]
    
    @classmethod
    def get_domains(cls):
        """Retorna domínios disponíveis"""
        return [
            'finance',
            'risk',
            'customer',
            'product',
            'operations',
            'marketing',
            'sales',
            'hr',
            'technology',
            'compliance',
            'regulatory',
            'data'
        ]
    
    @classmethod
    def get_status_options(cls):
        """Retorna opções de status"""
        return [
            'draft',
            'review',
            'approved',
            'deprecated',
            'archived'
        ]
    
    def approve(self, approved_by: str):
        """Aprova o termo"""
        self.approval_status = 'approved'
        self.approved_by = approved_by
        self.approved_at = datetime.now()
        self.status = 'approved'
    
    def deprecate(self, reason: str = None):
        """Deprecia o termo"""
        self.status = 'deprecated'
        self.is_active = False
        if reason:
            self.change_reason = reason
    
    def increment_usage(self):
        """Incrementa contador de uso"""
        self.usage_count = (self.usage_count or 0) + 1
        self.last_accessed = datetime.now()
    
    def increment_search(self):
        """Incrementa contador de busca"""
        self.search_count = (self.search_count or 0) + 1
    
    def calculate_quality_score(self):
        """Calcula score de qualidade baseado na completude"""
        score = 0
        total_fields = 10
        
        # Campos obrigatórios
        if self.definition: score += 1
        if self.category: score += 1
        if self.domain: score += 1
        if self.business_owner: score += 1
        
        # Campos opcionais importantes
        if self.business_definition: score += 1
        if self.examples: score += 1
        if self.usage_context: score += 1
        if self.synonyms: score += 1
        if self.related_terms: score += 1
        if self.business_rules: score += 1
        
        self.quality_score = int((score / total_fields) * 100)
        return self.quality_score

