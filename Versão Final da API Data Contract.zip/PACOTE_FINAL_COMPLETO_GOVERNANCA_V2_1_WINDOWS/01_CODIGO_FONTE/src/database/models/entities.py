"""
Modelos de Entidades e Catálogo de Dados
API de Governança de Dados V1.9
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from sqlalchemy import Column, String, Text, Boolean, Integer, DateTime, ForeignKey, Enum as SQLEnum, Float
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import relationship
from enum import Enum
from ..base import Base

class EntityType(Enum):
    TABLE = "table"
    VIEW = "view"
    DATASET = "dataset"
    API = "api"
    FILE = "file"
    STREAM = "stream"

class DataType(Enum):
    STRING = "string"
    INTEGER = "integer"
    FLOAT = "float"
    BOOLEAN = "boolean"
    DATE = "date"
    DATETIME = "datetime"
    JSON = "json"
    BINARY = "binary"

class RelationshipType(Enum):
    ONE_TO_ONE = "one_to_one"
    ONE_TO_MANY = "one_to_many"
    MANY_TO_MANY = "many_to_many"
    PARENT_CHILD = "parent_child"
    DEPENDENCY = "dependency"

class Entity(Base):
    """Entidades do catálogo de dados (tabelas, views, datasets, etc.)"""
    __tablename__ = 'entities'
    __table_args__ = {'extend_existing': True}
    
    name = Column(String(255), nullable=False, comment='Nome da entidade')
    display_name = Column(String(255), comment='Nome de exibição amigável')
    description = Column(Text, comment='Descrição detalhada da entidade')
    entity_type = Column(SQLEnum(EntityType), nullable=False, comment='Tipo da entidade')
    
    # Localização
    database_name = Column(String(255), comment='Nome do banco de dados')
    schema_name = Column(String(255), comment='Nome do schema')
    table_name = Column(String(255), comment='Nome da tabela')
    full_path = Column(Text, comment='Caminho completo da entidade')
    
    # Metadados técnicos
    row_count = Column(Integer, comment='Número de linhas')
    size_bytes = Column(Integer, comment='Tamanho em bytes')
    last_updated = Column(DateTime(timezone=True), comment='Última atualização dos dados')
    
    # Classificação e governança
    data_classification = Column(String(100), comment='Classificação dos dados')
    sensitivity_level = Column(String(50), comment='Nível de sensibilidade')
    retention_period = Column(Integer, comment='Período de retenção em dias')
    
    # Proprietário e stewardship
    owner_id = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Proprietário da entidade')
    steward_id = Column(UUID(as_uuid=True), ForeignKey('data_stewards.id'), comment='Data steward responsável')
    
    # Status e qualidade
    is_active = Column(Boolean, default=True, comment='Status ativo da entidade')
    quality_score = Column(Float, comment='Score de qualidade (0-100)')
    
    # Metadados adicionais
    business_context = Column(Text, comment='Contexto de negócio')
    technical_notes = Column(Text, comment='Notas técnicas')
    tags = Column(JSONB, comment='Tags associadas')
    custom_properties = Column(JSONB, comment='Propriedades customizadas')
    
    # Relacionamentos
    owner = relationship("User", foreign_keys=[owner_id])
    steward = relationship("DataSteward", foreign_keys=[steward_id])
    attributes = relationship("EntityAttribute", back_populates="entity", cascade="all, delete-orphan")
    relationships_as_source = relationship("EntityRelationship", foreign_keys="EntityRelationship.source_entity_id", back_populates="source_entity")
    relationships_as_target = relationship("EntityRelationship", foreign_keys="EntityRelationship.target_entity_id", back_populates="target_entity")
    tags_association = relationship("EntityTag", back_populates="entity", cascade="all, delete-orphan")
    usage_stats = relationship("EntityUsageStats", back_populates="entity", cascade="all, delete-orphan")

class EntityAttribute(Base):
    """Atributos/colunas das entidades"""
    __tablename__ = 'entity_attributes'
    __table_args__ = {'extend_existing': True}
    
    entity_id = Column(UUID(as_uuid=True), ForeignKey('entities.id'), nullable=False)
    name = Column(String(255), nullable=False, comment='Nome do atributo')
    display_name = Column(String(255), comment='Nome de exibição')
    description = Column(Text, comment='Descrição do atributo')
    
    # Tipo e estrutura
    data_type = Column(SQLEnum(DataType), nullable=False, comment='Tipo de dados')
    max_length = Column(Integer, comment='Tamanho máximo')
    precision = Column(Integer, comment='Precisão para números')
    scale = Column(Integer, comment='Escala para números')
    
    # Constraints
    is_nullable = Column(Boolean, default=True, comment='Permite valores nulos')
    is_primary_key = Column(Boolean, default=False, comment='É chave primária')
    is_foreign_key = Column(Boolean, default=False, comment='É chave estrangeira')
    is_unique = Column(Boolean, default=False, comment='Tem constraint de unicidade')
    
    # Valores padrão e exemplos
    default_value = Column(Text, comment='Valor padrão')
    sample_values = Column(JSONB, comment='Valores de exemplo')
    
    # Classificação e governança
    data_classification = Column(String(100), comment='Classificação do atributo')
    is_pii = Column(Boolean, default=False, comment='Contém informação pessoal identificável')
    masking_rule = Column(String(255), comment='Regra de mascaramento')
    
    # Qualidade
    completeness_score = Column(Float, comment='Score de completude (0-100)')
    uniqueness_score = Column(Float, comment='Score de unicidade (0-100)')
    
    # Posição e ordem
    ordinal_position = Column(Integer, comment='Posição ordinal na entidade')
    
    # Relacionamentos
    entity = relationship("Entity", back_populates="attributes")

class EntityRelationship(Base):
    """Relacionamentos entre entidades"""
    __tablename__ = 'entity_relationships'
    __table_args__ = {'extend_existing': True}
    
    source_entity_id = Column(UUID(as_uuid=True), ForeignKey('entities.id'), nullable=False)
    target_entity_id = Column(UUID(as_uuid=True), ForeignKey('entities.id'), nullable=False)
    relationship_type = Column(SQLEnum(RelationshipType), nullable=False, comment='Tipo de relacionamento')
    
    # Detalhes do relacionamento
    name = Column(String(255), comment='Nome do relacionamento')
    description = Column(Text, comment='Descrição do relacionamento')
    source_columns = Column(JSONB, comment='Colunas da entidade origem')
    target_columns = Column(JSONB, comment='Colunas da entidade destino')
    
    # Metadados
    is_active = Column(Boolean, default=True, comment='Relacionamento ativo')
    confidence_score = Column(Float, comment='Confiança na detecção (0-100)')
    detected_automatically = Column(Boolean, default=False, comment='Detectado automaticamente')
    
    # Relacionamentos
    source_entity = relationship("Entity", foreign_keys=[source_entity_id], back_populates="relationships_as_source")
    target_entity = relationship("Entity", foreign_keys=[target_entity_id], back_populates="relationships_as_target")

class EntityTag(Base):
    """Associação entre entidades e tags"""
    __tablename__ = 'entity_tags'
    __table_args__ = {'extend_existing': True}
    
    entity_id = Column(UUID(as_uuid=True), ForeignKey('entities.id'), nullable=False)
    tag_id = Column(UUID(as_uuid=True), ForeignKey('tags.id'), nullable=False)
    tagged_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Usuário que aplicou a tag')
    confidence_score = Column(Float, comment='Confiança na aplicação da tag')
    is_auto_generated = Column(Boolean, default=False, comment='Tag aplicada automaticamente')
    
    # Relacionamentos
    entity = relationship("Entity", back_populates="tags_association")
    tag = relationship("Tag")
    tagger = relationship("User", foreign_keys=[tagged_by])

class EntityUsageStats(Base):
    """Estatísticas de uso das entidades"""
    __tablename__ = 'entity_usage_stats'
    __table_args__ = {'extend_existing': True}
    
    entity_id = Column(UUID(as_uuid=True), ForeignKey('entities.id'), nullable=False)
    date = Column(DateTime(timezone=True), nullable=False, comment='Data da estatística')
    
    # Métricas de uso
    query_count = Column(Integer, default=0, comment='Número de queries')
    unique_users = Column(Integer, default=0, comment='Usuários únicos')
    data_volume_read = Column(Integer, comment='Volume de dados lido em bytes')
    avg_query_time = Column(Float, comment='Tempo médio de query em segundos')
    
    # Métricas de qualidade
    quality_score = Column(Float, comment='Score de qualidade do dia')
    error_count = Column(Integer, default=0, comment='Número de erros')
    
    # Relacionamentos
    entity = relationship("Entity", back_populates="usage_stats")

class CatalogEntry(Base):
    """Entradas do catálogo de dados com metadados enriquecidos"""
    __tablename__ = 'catalog_entries'
    __table_args__ = {'extend_existing': True}
    
    entity_id = Column(UUID(as_uuid=True), ForeignKey('entities.id'), nullable=False)
    
    # Metadados de descoberta
    title = Column(String(500), comment='Título para busca')
    summary = Column(Text, comment='Resumo executivo')
    keywords = Column(JSONB, comment='Palavras-chave para busca')
    
    # Contexto de negócio
    business_purpose = Column(Text, comment='Propósito de negócio')
    use_cases = Column(JSONB, comment='Casos de uso')
    business_rules = Column(Text, comment='Regras de negócio')
    
    # Metadados técnicos
    source_system = Column(String(255), comment='Sistema de origem')
    update_frequency = Column(String(100), comment='Frequência de atualização')
    data_freshness = Column(DateTime(timezone=True), comment='Frescor dos dados')
    
    # Qualidade e confiabilidade
    reliability_score = Column(Float, comment='Score de confiabilidade')
    popularity_score = Column(Float, comment='Score de popularidade')
    
    # Status de publicação
    is_published = Column(Boolean, default=False, comment='Publicado no catálogo')
    published_at = Column(DateTime(timezone=True), comment='Data de publicação')
    published_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Usuário que publicou')
    
    # Relacionamentos
    entity = relationship("Entity")
    publisher = relationship("User", foreign_keys=[published_by])

