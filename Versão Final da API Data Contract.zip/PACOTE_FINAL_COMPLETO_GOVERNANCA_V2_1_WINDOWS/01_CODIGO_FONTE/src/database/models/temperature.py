"""
Modelos de Gestão de Temperatura de Dados
API de Governança de Dados V2.2
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from sqlalchemy import Column, String, Text, Boolean, Integer, DateTime, ForeignKey, Enum as SQLEnum, Float
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import relationship
from enum import Enum
from ..base import Base

class TemperatureLevel(Enum):
    HOT = "hot"      # Dados acessados frequentemente
    WARM = "warm"    # Dados acessados ocasionalmente
    COOL = "cool"    # Dados acessados raramente
    COLD = "cold"    # Dados arquivados
    FROZEN = "frozen" # Dados para retenção legal

class StorageTier(Enum):
    PREMIUM = "premium"        # SSD de alta performance
    STANDARD = "standard"      # SSD padrão
    COOL = "cool"             # Storage de acesso infrequente
    ARCHIVE = "archive"       # Storage de arquivo
    DEEP_ARCHIVE = "deep_archive" # Archive de longo prazo

class MigrationStatus(Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    SCHEDULED = "scheduled"

class AccessPattern(Enum):
    FREQUENT = "frequent"      # Acesso diário
    REGULAR = "regular"        # Acesso semanal
    OCCASIONAL = "occasional"  # Acesso mensal
    RARE = "rare"             # Acesso trimestral
    ARCHIVE = "archive"       # Acesso anual ou menos

class DataTemperaturePolicy(Base):
    """Políticas de temperatura de dados"""
    __tablename__ = 'data_temperature_policies'
    __table_args__ = {'extend_existing': True}
    
    name = Column(String(255), nullable=False, comment='Nome da política de temperatura')
    description = Column(Text, comment='Descrição da política')
    
    # Configurações da política
    entity_filters = Column(JSONB, comment='Filtros de entidades aplicáveis')
    data_age_criteria = Column(JSONB, comment='Critérios baseados em idade dos dados')
    access_pattern_criteria = Column(JSONB, comment='Critérios baseados em padrão de acesso')
    
    # Regras de temperatura
    hot_criteria = Column(JSONB, comment='Critérios para dados HOT')
    warm_criteria = Column(JSONB, comment='Critérios para dados WARM')
    cool_criteria = Column(JSONB, comment='Critérios para dados COOL')
    cold_criteria = Column(JSONB, comment='Critérios para dados COLD')
    frozen_criteria = Column(JSONB, comment='Critérios para dados FROZEN')
    
    # Configurações de migração automática
    auto_migration_enabled = Column(Boolean, default=True, comment='Migração automática habilitada')
    migration_schedule = Column(String(255), comment='Agendamento de migração (cron)')
    
    # Limites de custo
    cost_optimization_enabled = Column(Boolean, default=True, comment='Otimização de custo habilitada')
    max_monthly_cost = Column(Float, comment='Custo máximo mensal')
    cost_alert_threshold = Column(Float, comment='Limite para alerta de custo')
    
    # Configurações de retenção
    retention_rules = Column(JSONB, comment='Regras de retenção por temperatura')
    compliance_requirements = Column(JSONB, comment='Requisitos de compliance')
    
    # Status
    is_active = Column(Boolean, default=True, comment='Política ativa')
    
    # Metadados
    created_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), nullable=False, comment='Criador da política')
    last_execution = Column(DateTime(timezone=True), comment='Última execução')
    next_execution = Column(DateTime(timezone=True), comment='Próxima execução')
    
    # Relacionamentos
    creator = relationship("User", foreign_keys=[created_by])
    migrations = relationship("StorageMigration", back_populates="policy", cascade="all, delete-orphan")

class StorageMigration(Base):
    """Migrações de storage"""
    __tablename__ = 'storage_migrations'
    __table_args__ = {'extend_existing': True}
    
    policy_id = Column(UUID(as_uuid=True), ForeignKey('data_temperature_policies.id'), comment='Política aplicada')
    entity_id = Column(UUID(as_uuid=True), ForeignKey('entities.id'), nullable=False, comment='Entidade migrada')
    
    # Configurações da migração
    migration_type = Column(String(100), comment='Tipo de migração (temperature_change, cost_optimization)')
    
    # Estado anterior e novo
    source_temperature = Column(SQLEnum(TemperatureLevel), comment='Temperatura de origem')
    target_temperature = Column(SQLEnum(TemperatureLevel), nullable=False, comment='Temperatura de destino')
    source_storage_tier = Column(SQLEnum(StorageTier), comment='Tier de storage de origem')
    target_storage_tier = Column(SQLEnum(StorageTier), nullable=False, comment='Tier de storage de destino')
    
    # Status da migração
    status = Column(SQLEnum(MigrationStatus), default=MigrationStatus.PENDING, comment='Status da migração')
    
    # Dados da migração
    data_size_bytes = Column(Integer, comment='Tamanho dos dados em bytes')
    estimated_duration = Column(Integer, comment='Duração estimada em minutos')
    actual_duration = Column(Integer, comment='Duração real em minutos')
    
    # Custos
    source_monthly_cost = Column(Float, comment='Custo mensal no storage de origem')
    target_monthly_cost = Column(Float, comment='Custo mensal no storage de destino')
    migration_cost = Column(Float, comment='Custo da migração')
    estimated_savings = Column(Float, comment='Economia estimada mensal')
    
    # Execução
    scheduled_at = Column(DateTime(timezone=True), comment='Data agendada')
    started_at = Column(DateTime(timezone=True), comment='Data de início')
    completed_at = Column(DateTime(timezone=True), comment='Data de conclusão')
    
    # Logs e erros
    execution_log = Column(JSONB, comment='Log de execução')
    error_details = Column(Text, comment='Detalhes de erros')
    
    # Validação
    pre_migration_checksum = Column(String(255), comment='Checksum antes da migração')
    post_migration_checksum = Column(String(255), comment='Checksum após migração')
    data_integrity_verified = Column(Boolean, comment='Integridade dos dados verificada')
    
    # Metadados
    triggered_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Usuário que disparou')
    trigger_reason = Column(Text, comment='Motivo da migração')
    
    # Relacionamentos
    policy = relationship("DataTemperaturePolicy", back_populates="migrations")
    entity = relationship("Entity")
    trigger_user = relationship("User", foreign_keys=[triggered_by])

class DataAccessPattern(Base):
    """Padrões de acesso aos dados"""
    __tablename__ = 'data_access_patterns'
    __table_args__ = {'extend_existing': True}
    
    entity_id = Column(UUID(as_uuid=True), ForeignKey('entities.id'), nullable=False, comment='Entidade monitorada')
    
    # Período de análise
    analysis_period_start = Column(DateTime(timezone=True), nullable=False, comment='Início do período')
    analysis_period_end = Column(DateTime(timezone=True), nullable=False, comment='Fim do período')
    
    # Estatísticas de acesso
    total_accesses = Column(Integer, default=0, comment='Total de acessos')
    unique_users = Column(Integer, default=0, comment='Usuários únicos')
    unique_applications = Column(Integer, default=0, comment='Aplicações únicas')
    
    # Padrões temporais
    access_pattern = Column(SQLEnum(AccessPattern), comment='Padrão de acesso identificado')
    peak_access_hours = Column(JSONB, comment='Horários de pico de acesso')
    access_frequency_days = Column(Float, comment='Frequência de acesso em dias')
    
    # Análise de uso
    read_operations = Column(Integer, default=0, comment='Operações de leitura')
    write_operations = Column(Integer, default=0, comment='Operações de escrita')
    data_volume_read = Column(Integer, comment='Volume de dados lido (bytes)')
    data_volume_written = Column(Integer, comment='Volume de dados escrito (bytes)')
    
    # Performance
    average_query_time = Column(Float, comment='Tempo médio de query (ms)')
    slow_queries_count = Column(Integer, default=0, comment='Número de queries lentas')
    cache_hit_rate = Column(Float, comment='Taxa de acerto do cache')
    
    # Análise de usuários
    top_users = Column(JSONB, comment='Top usuários por acesso')
    user_access_patterns = Column(JSONB, comment='Padrões de acesso por usuário')
    department_usage = Column(JSONB, comment='Uso por departamento')
    
    # Análise de aplicações
    top_applications = Column(JSONB, comment='Top aplicações por acesso')
    api_usage_stats = Column(JSONB, comment='Estatísticas de uso de API')
    integration_patterns = Column(JSONB, comment='Padrões de integração')
    
    # Recomendações
    temperature_recommendation = Column(SQLEnum(TemperatureLevel), comment='Temperatura recomendada')
    storage_tier_recommendation = Column(SQLEnum(StorageTier), comment='Tier de storage recomendado')
    optimization_suggestions = Column(JSONB, comment='Sugestões de otimização')
    
    # Custos
    current_storage_cost = Column(Float, comment='Custo atual de storage')
    recommended_storage_cost = Column(Float, comment='Custo recomendado')
    potential_savings = Column(Float, comment='Economia potencial')
    
    # Qualidade da análise
    data_completeness = Column(Float, comment='Completude dos dados de análise')
    confidence_score = Column(Float, comment='Score de confiança da análise')
    analysis_notes = Column(Text, comment='Notas da análise')
    
    # Metadados
    analyzed_by = Column(String(255), comment='Sistema/usuário que fez a análise')
    analysis_version = Column(String(50), comment='Versão do algoritmo de análise')
    
    # Relacionamentos
    entity = relationship("Entity")

