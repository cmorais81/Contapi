#!/bin/bash
# Script de Deploy para AKS Azure
# API de Governança de Dados V2.2
# Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)

set -e

echo "============================================================"
echo "Deploy API de Governança de Dados V2.2 para AKS Azure"
echo "Desenvolvido por: Carlos Morais"
echo "Email: carlos.morais@f1rst.com.br"
echo "Organização: F1rst"
echo "============================================================"

# Variáveis
RESOURCE_GROUP="rg-governance-prod"
AKS_CLUSTER="aks-governance-cluster"
ACR_NAME="acrgovernance"
IMAGE_NAME="governance-api"
IMAGE_TAG="v2.2"

echo "🔍 Verificando pré-requisitos..."

# Verificar Azure CLI
if ! command -v az &> /dev/null; then
    echo "❌ Azure CLI não encontrado. Instale: https://docs.microsoft.com/en-us/cli/azure/install-azure-cli"
    exit 1
fi

# Verificar kubectl
if ! command -v kubectl &> /dev/null; then
    echo "❌ kubectl não encontrado. Instale: https://kubernetes.io/docs/tasks/tools/"
    exit 1
fi

# Verificar Docker
if ! command -v docker &> /dev/null; then
    echo "❌ Docker não encontrado. Instale: https://docs.docker.com/get-docker/"
    exit 1
fi

echo "✅ Pré-requisitos verificados"

echo "🔐 Fazendo login no Azure..."
az login

echo "📦 Fazendo login no Azure Container Registry..."
az acr login --name $ACR_NAME

echo "🏗️ Construindo imagem Docker..."
docker build -t $ACR_NAME.azurecr.io/$IMAGE_NAME:$IMAGE_TAG .
docker build -t $ACR_NAME.azurecr.io/$IMAGE_NAME:latest .

echo "📤 Enviando imagem para ACR..."
docker push $ACR_NAME.azurecr.io/$IMAGE_NAME:$IMAGE_TAG
docker push $ACR_NAME.azurecr.io/$IMAGE_NAME:latest

echo "🔗 Conectando ao cluster AKS..."
az aks get-credentials --resource-group $RESOURCE_GROUP --name $AKS_CLUSTER

echo "🚀 Aplicando manifestos Kubernetes..."
kubectl apply -f kubernetes/

echo "⏳ Aguardando deployment..."
kubectl rollout status deployment/governance-api

echo "🔍 Verificando status dos pods..."
kubectl get pods -l app=governance-api

echo "🌐 Verificando serviços..."
kubectl get services

echo "📊 Verificando ingress..."
kubectl get ingress

echo "✅ Deploy concluído com sucesso!"
echo ""
echo "📋 Comandos úteis:"
echo "   Ver logs: kubectl logs -l app=governance-api"
echo "   Ver pods: kubectl get pods"
echo "   Ver status: kubectl get all"
echo "   Health check: curl https://governance-api.santander.com.br/health"
echo ""
echo "🎉 API de Governança de Dados V2.2 está rodando no AKS!"

