# Guia Completo de Consultas - Modelo de Dados de Governança

**Desenvolvido por:** Carlos Morais (carlos.morais@f1rst.com.br)  
**Organização:** F1rst Technology Solutions  
**Cliente:** Banco Santander  
**Data:** Janeiro 2025  
**Versão:** 3.0.0 Final  

## 1. VISÃO GERAL DAS CONSULTAS

Este documento apresenta todas as possibilidades de consultas disponíveis no modelo de dados de governança, organizadas por módulo e tipo de consulta. Cada consulta inclui exemplos em SQL e endpoints da API correspondentes.

### 1.1 Tipos de Consultas Disponíveis
- **Consultas Básicas:** CRUD simples por tabela
- **Consultas Relacionais:** Joins entre tabelas relacionadas
- **Consultas Analíticas:** Agregações e métricas
- **Consultas de Auditoria:** Histórico e rastreabilidade
- **Consultas de Performance:** Otimizações e estatísticas
- **Consultas de Compliance:** Relatórios regulatórios

### 1.2 Estrutura do Modelo (58 Tabelas)
- **Módulo Autenticação:** 5 tabelas
- **Módulo Contratos:** 3 tabelas
- **Módulo Entidades:** 6 tabelas
- **Módulo Qualidade:** 3 tabelas
- **Módulo Lineage:** 3 tabelas
- **Módulo Políticas:** 3 tabelas
- **Módulo Stewardship:** 3 tabelas
- **Outros Módulos:** 32 tabelas

## 2. CONSULTAS POR MÓDULO

### 2.1 MÓDULO DE AUTENTICAÇÃO

#### 2.1.1 Consultas Básicas - Usuários

**Listar todos os usuários ativos:**
```sql
SELECT u.id, u.username, u.email, u.full_name, u.department, u.created_at
FROM users u 
WHERE u.is_active = true
ORDER BY u.created_at DESC;
```
**API:** `GET /api/v1/auth/users?active=true`

**Buscar usuário por email:**
```sql
SELECT u.*, sr.role_name 
FROM users u
JOIN user_roles ur ON u.id = ur.user_id
JOIN security_roles sr ON ur.role_id = sr.id
WHERE u.email = 'carlos.morais@f1rst.com.br';
```
**API:** `GET /api/v1/auth/users?email=carlos.morais@f1rst.com.br`

**Usuários por departamento:**
```sql
SELECT department, COUNT(*) as total_users,
       COUNT(CASE WHEN is_active THEN 1 END) as active_users
FROM users 
GROUP BY department
ORDER BY total_users DESC;
```
**API:** `GET /api/v1/auth/users/stats?group_by=department`

#### 2.1.2 Consultas de Sessões e Segurança

**Sessões ativas por usuário:**
```sql
SELECT u.username, us.session_token, us.created_at, us.expires_at,
       us.ip_address, us.user_agent
FROM user_sessions us
JOIN users u ON us.user_id = u.id
WHERE us.expires_at > NOW()
ORDER BY us.created_at DESC;
```
**API:** `GET /api/v1/auth/sessions?active=true`

**Histórico de logins por período:**
```sql
SELECT DATE(us.created_at) as login_date,
       COUNT(*) as total_logins,
       COUNT(DISTINCT us.user_id) as unique_users
FROM user_sessions us
WHERE us.created_at >= '2025-01-01'
GROUP BY DATE(us.created_at)
ORDER BY login_date DESC;
```
**API:** `GET /api/v1/auth/analytics/logins?start_date=2025-01-01`

**Usuários com múltiplas roles:**
```sql
SELECT u.username, u.email, 
       STRING_AGG(sr.role_name, ', ') as roles
FROM users u
JOIN user_roles ur ON u.id = ur.user_id
JOIN security_roles sr ON ur.role_id = sr.id
GROUP BY u.id, u.username, u.email
HAVING COUNT(ur.role_id) > 1;
```
**API:** `GET /api/v1/auth/users?multiple_roles=true`

### 2.2 MÓDULO DE CONTRATOS DE DADOS

#### 2.2.1 Consultas Básicas - Contratos

**Listar contratos por status:**
```sql
SELECT dc.id, dc.name, dc.description, dc.status, dc.version,
       u.username as created_by, dc.created_at
FROM data_contracts dc
JOIN users u ON dc.created_by = u.id
WHERE dc.status = 'APPROVED'
ORDER BY dc.created_at DESC;
```
**API:** `GET /api/v1/contracts?status=APPROVED`

**Contratos com suas versões:**
```sql
SELECT dc.name, dc.current_version,
       cv.version_number, cv.schema_definition, cv.created_at,
       u.username as version_author
FROM data_contracts dc
JOIN contract_versions cv ON dc.id = cv.contract_id
JOIN users u ON cv.created_by = u.id
ORDER BY dc.name, cv.version_number DESC;
```
**API:** `GET /api/v1/contracts/{id}/versions`

**Contratos pendentes de aprovação:**
```sql
SELECT dc.name, dc.description, dc.created_at,
       u1.username as created_by,
       ca.approval_status, ca.comments,
       u2.username as approver
FROM data_contracts dc
JOIN users u1 ON dc.created_by = u1.id
LEFT JOIN contract_approvals ca ON dc.id = ca.contract_id
LEFT JOIN users u2 ON ca.approved_by = u2.id
WHERE dc.status = 'PENDING_APPROVAL';
```
**API:** `GET /api/v1/contracts?status=PENDING_APPROVAL&include_approvals=true`

#### 2.2.2 Consultas Analíticas - Contratos

**Estatísticas de contratos por período:**
```sql
SELECT DATE_TRUNC('month', created_at) as month,
       COUNT(*) as total_contracts,
       COUNT(CASE WHEN status = 'APPROVED' THEN 1 END) as approved,
       COUNT(CASE WHEN status = 'REJECTED' THEN 1 END) as rejected,
       COUNT(CASE WHEN status = 'PENDING_APPROVAL' THEN 1 END) as pending
FROM data_contracts
WHERE created_at >= '2024-01-01'
GROUP BY DATE_TRUNC('month', created_at)
ORDER BY month DESC;
```
**API:** `GET /api/v1/contracts/analytics?period=monthly&start_date=2024-01-01`

**Tempo médio de aprovação:**
```sql
SELECT AVG(EXTRACT(EPOCH FROM (ca.approved_at - dc.created_at))/3600) as avg_approval_hours,
       MIN(EXTRACT(EPOCH FROM (ca.approved_at - dc.created_at))/3600) as min_approval_hours,
       MAX(EXTRACT(EPOCH FROM (ca.approved_at - dc.created_at))/3600) as max_approval_hours
FROM data_contracts dc
JOIN contract_approvals ca ON dc.id = ca.contract_id
WHERE ca.approval_status = 'APPROVED'
  AND ca.approved_at IS NOT NULL;
```
**API:** `GET /api/v1/contracts/analytics/approval-time`

### 2.3 MÓDULO DE ENTIDADES

#### 2.3.1 Consultas Básicas - Entidades

**Catálogo completo de entidades:**
```sql
SELECT e.id, e.name, e.description, e.entity_type, e.source_system,
       e.sensitivity_level, e.created_at,
       COUNT(ea.id) as total_attributes
FROM entities e
LEFT JOIN entity_attributes ea ON e.id = ea.entity_id
GROUP BY e.id, e.name, e.description, e.entity_type, e.source_system, e.sensitivity_level, e.created_at
ORDER BY e.name;
```
**API:** `GET /api/v1/entities?include_attributes_count=true`

**Entidades por sistema de origem:**
```sql
SELECT source_system, 
       COUNT(*) as total_entities,
       COUNT(CASE WHEN sensitivity_level = 'HIGH' THEN 1 END) as high_sensitivity,
       COUNT(CASE WHEN sensitivity_level = 'MEDIUM' THEN 1 END) as medium_sensitivity,
       COUNT(CASE WHEN sensitivity_level = 'LOW' THEN 1 END) as low_sensitivity
FROM entities
GROUP BY source_system
ORDER BY total_entities DESC;
```
**API:** `GET /api/v1/entities/analytics?group_by=source_system`

**Entidades com atributos PII:**
```sql
SELECT e.name as entity_name, e.source_system,
       ea.name as attribute_name, ea.data_type, ea.is_pii
FROM entities e
JOIN entity_attributes ea ON e.id = ea.entity_id
WHERE ea.is_pii = true
ORDER BY e.name, ea.name;
```
**API:** `GET /api/v1/entities?pii_only=true&include_attributes=true`

#### 2.3.2 Consultas de Relacionamentos

**Mapa de relacionamentos entre entidades:**
```sql
SELECT e1.name as source_entity,
       e2.name as target_entity,
       er.relationship_type,
       er.description
FROM entity_relationships er
JOIN entities e1 ON er.source_entity_id = e1.id
JOIN entities e2 ON er.target_entity_id = e2.id
ORDER BY e1.name, e2.name;
```
**API:** `GET /api/v1/entities/relationships`

**Entidades mais conectadas:**
```sql
SELECT e.name, e.entity_type,
       COUNT(DISTINCT er1.target_entity_id) as outgoing_connections,
       COUNT(DISTINCT er2.source_entity_id) as incoming_connections,
       (COUNT(DISTINCT er1.target_entity_id) + COUNT(DISTINCT er2.source_entity_id)) as total_connections
FROM entities e
LEFT JOIN entity_relationships er1 ON e.id = er1.source_entity_id
LEFT JOIN entity_relationships er2 ON e.id = er2.target_entity_id
GROUP BY e.id, e.name, e.entity_type
ORDER BY total_connections DESC
LIMIT 10;
```
**API:** `GET /api/v1/entities/analytics/most-connected?limit=10`

#### 2.3.3 Consultas de Tags e Classificação

**Entidades por tag:**
```sql
SELECT t.name as tag_name, t.color,
       COUNT(et.entity_id) as entities_count,
       STRING_AGG(e.name, ', ' ORDER BY e.name) as entities
FROM tags t
JOIN entity_tags et ON t.id = et.tag_id
JOIN entities e ON et.entity_id = e.id
GROUP BY t.id, t.name, t.color
ORDER BY entities_count DESC;
```
**API:** `GET /api/v1/tags?include_entities_count=true`

**Hierarquia de tags:**
```sql
WITH RECURSIVE tag_hierarchy AS (
    SELECT id, name, parent_tag_id, 0 as level, name as path
    FROM tags WHERE parent_tag_id IS NULL
    
    UNION ALL
    
    SELECT t.id, t.name, t.parent_tag_id, th.level + 1,
           th.path || ' > ' || t.name
    FROM tags t
    JOIN tag_hierarchy th ON t.parent_tag_id = th.id
)
SELECT * FROM tag_hierarchy ORDER BY path;
```
**API:** `GET /api/v1/tags/hierarchy`

### 2.4 MÓDULO DE QUALIDADE DE DADOS

#### 2.4.1 Consultas de Regras de Qualidade

**Regras de qualidade por entidade:**
```sql
SELECT e.name as entity_name,
       qr.rule_name, qr.rule_type, qr.severity,
       qr.rule_definition, qr.is_active
FROM quality_rules qr
JOIN entities e ON qr.entity_id = e.id
WHERE qr.is_active = true
ORDER BY e.name, qr.severity DESC;
```
**API:** `GET /api/v1/quality/rules?include_entity=true&active=true`

**Regras por tipo e severidade:**
```sql
SELECT rule_type, severity,
       COUNT(*) as total_rules,
       COUNT(CASE WHEN is_active THEN 1 END) as active_rules
FROM quality_rules
GROUP BY rule_type, severity
ORDER BY rule_type, 
         CASE severity 
           WHEN 'CRITICAL' THEN 1 
           WHEN 'HIGH' THEN 2 
           WHEN 'MEDIUM' THEN 3 
           WHEN 'LOW' THEN 4 
         END;
```
**API:** `GET /api/v1/quality/rules/analytics?group_by=type,severity`

#### 2.4.2 Consultas de Métricas de Qualidade

**Dashboard de qualidade por entidade:**
```sql
SELECT e.name as entity_name,
       AVG(qm.completeness_score) as avg_completeness,
       AVG(qm.consistency_score) as avg_consistency,
       AVG(qm.validity_score) as avg_validity,
       AVG(qm.accuracy_score) as avg_accuracy,
       COUNT(qm.id) as total_measurements
FROM entities e
JOIN quality_metrics qm ON e.id = qm.entity_id
WHERE qm.measured_at >= CURRENT_DATE - INTERVAL '30 days'
GROUP BY e.id, e.name
ORDER BY (AVG(qm.completeness_score) + AVG(qm.consistency_score) + 
          AVG(qm.validity_score) + AVG(qm.accuracy_score)) / 4 DESC;
```
**API:** `GET /api/v1/quality/dashboard?period=30days`

**Tendência de qualidade ao longo do tempo:**
```sql
SELECT DATE(qm.measured_at) as measurement_date,
       AVG(qm.completeness_score) as avg_completeness,
       AVG(qm.consistency_score) as avg_consistency,
       AVG(qm.validity_score) as avg_validity,
       AVG(qm.accuracy_score) as avg_accuracy
FROM quality_metrics qm
WHERE qm.measured_at >= CURRENT_DATE - INTERVAL '90 days'
GROUP BY DATE(qm.measured_at)
ORDER BY measurement_date;
```
**API:** `GET /api/v1/quality/trends?period=90days`

#### 2.4.3 Consultas de Issues de Qualidade

**Issues críticos em aberto:**
```sql
SELECT e.name as entity_name,
       dqi.issue_type, dqi.severity, dqi.description,
       dqi.detected_at, dqi.status,
       u.username as assigned_to
FROM data_quality_issues dqi
JOIN entities e ON dqi.entity_id = e.id
LEFT JOIN users u ON dqi.assigned_to = u.id
WHERE dqi.status IN ('OPEN', 'IN_PROGRESS')
  AND dqi.severity = 'CRITICAL'
ORDER BY dqi.detected_at DESC;
```
**API:** `GET /api/v1/quality/issues?status=OPEN,IN_PROGRESS&severity=CRITICAL`

**Estatísticas de resolução de issues:**
```sql
SELECT issue_type, severity,
       COUNT(*) as total_issues,
       COUNT(CASE WHEN status = 'RESOLVED' THEN 1 END) as resolved,
       COUNT(CASE WHEN status = 'OPEN' THEN 1 END) as open,
       AVG(CASE WHEN resolved_at IS NOT NULL 
           THEN EXTRACT(EPOCH FROM (resolved_at - detected_at))/3600 
           END) as avg_resolution_hours
FROM data_quality_issues
WHERE detected_at >= CURRENT_DATE - INTERVAL '30 days'
GROUP BY issue_type, severity
ORDER BY total_issues DESC;
```
**API:** `GET /api/v1/quality/issues/analytics?period=30days`

### 2.5 MÓDULO DE LINEAGE DE DADOS

#### 2.5.1 Consultas de Lineage Básico

**Lineage upstream de uma entidade:**
```sql
WITH RECURSIVE upstream_lineage AS (
    SELECT dl.source_entity_id, dl.target_entity_id, 1 as level,
           e.name as source_name
    FROM data_lineage dl
    JOIN entities e ON dl.source_entity_id = e.id
    WHERE dl.target_entity_id = $1  -- ID da entidade de interesse
    
    UNION ALL
    
    SELECT dl.source_entity_id, dl.target_entity_id, ul.level + 1,
           e.name as source_name
    FROM data_lineage dl
    JOIN upstream_lineage ul ON dl.target_entity_id = ul.source_entity_id
    JOIN entities e ON dl.source_entity_id = e.id
    WHERE ul.level < 10  -- Limite de profundidade
)
SELECT DISTINCT ul.source_entity_id, ul.source_name, ul.level
FROM upstream_lineage ul
ORDER BY ul.level, ul.source_name;
```
**API:** `GET /api/v1/lineage/upstream/{entity_id}?depth=10`

**Lineage downstream de uma entidade:**
```sql
WITH RECURSIVE downstream_lineage AS (
    SELECT dl.source_entity_id, dl.target_entity_id, 1 as level,
           e.name as target_name
    FROM data_lineage dl
    JOIN entities e ON dl.target_entity_id = e.id
    WHERE dl.source_entity_id = $1  -- ID da entidade de interesse
    
    UNION ALL
    
    SELECT dl.source_entity_id, dl.target_entity_id, dl.level + 1,
           e.name as target_name
    FROM data_lineage dl
    JOIN downstream_lineage dl ON dl.source_entity_id = dl.target_entity_id
    JOIN entities e ON dl.target_entity_id = e.id
    WHERE dl.level < 10  -- Limite de profundidade
)
SELECT DISTINCT dl.target_entity_id, dl.target_name, dl.level
FROM downstream_lineage dl
ORDER BY dl.level, dl.target_name;
```
**API:** `GET /api/v1/lineage/downstream/{entity_id}?depth=10`

#### 2.5.2 Consultas de Lineage de Atributos

**Lineage de atributos específicos:**
```sql
SELECT e1.name as source_entity, la.source_attribute,
       e2.name as target_entity, la.target_attribute,
       la.transformation_logic, la.confidence_score
FROM lineage_attributes la
JOIN entities e1 ON la.source_entity_id = e1.id
JOIN entities e2 ON la.target_entity_id = e2.id
WHERE la.source_attribute = 'customer_id'
   OR la.target_attribute = 'customer_id'
ORDER BY la.confidence_score DESC;
```
**API:** `GET /api/v1/lineage/attributes?attribute=customer_id`

**Mapa completo de transformações:**
```sql
SELECT e1.name as source_entity, la.source_attribute,
       e2.name as target_entity, la.target_attribute,
       la.transformation_logic,
       CASE 
         WHEN la.confidence_score >= 0.9 THEN 'HIGH'
         WHEN la.confidence_score >= 0.7 THEN 'MEDIUM'
         ELSE 'LOW'
       END as confidence_level
FROM lineage_attributes la
JOIN entities e1 ON la.source_entity_id = e1.id
JOIN entities e2 ON la.target_entity_id = e2.id
WHERE la.transformation_logic IS NOT NULL
ORDER BY la.confidence_score DESC;
```
**API:** `GET /api/v1/lineage/transformations?include_confidence=true`

#### 2.5.3 Consultas de Análise de Impacto

**Análise de impacto para mudanças:**
```sql
SELECT ia.analysis_id, ia.change_description,
       e.name as affected_entity,
       ia.impact_level, ia.estimated_effort_hours,
       ia.risk_assessment, ia.created_at
FROM impact_analysis ia
JOIN entities e ON ia.affected_entity_id = e.id
WHERE ia.source_entity_id = $1  -- ID da entidade que será alterada
ORDER BY 
  CASE ia.impact_level 
    WHEN 'CRITICAL' THEN 1 
    WHEN 'HIGH' THEN 2 
    WHEN 'MEDIUM' THEN 3 
    WHEN 'LOW' THEN 4 
  END,
  ia.estimated_effort_hours DESC;
```
**API:** `POST /api/v1/lineage/impact-analysis`

### 2.6 MÓDULO DE POLÍTICAS DE GOVERNANÇA

#### 2.6.1 Consultas de Políticas

**Políticas por framework de compliance:**
```sql
SELECT compliance_framework,
       COUNT(*) as total_policies,
       COUNT(CASE WHEN is_active THEN 1 END) as active_policies,
       STRING_AGG(policy_name, ', ' ORDER BY policy_name) as policies
FROM governance_policies
GROUP BY compliance_framework
ORDER BY total_policies DESC;
```
**API:** `GET /api/v1/policies?group_by=compliance_framework`

**Políticas aplicáveis a uma entidade:**
```sql
SELECT gp.policy_name, gp.policy_type, gp.compliance_framework,
       gp.description, gp.enforcement_level
FROM governance_policies gp
JOIN entities e ON (gp.scope = 'ALL' OR gp.scope = e.entity_type)
WHERE e.id = $1  -- ID da entidade
  AND gp.is_active = true
ORDER BY 
  CASE gp.enforcement_level 
    WHEN 'MANDATORY' THEN 1 
    WHEN 'RECOMMENDED' THEN 2 
    WHEN 'OPTIONAL' THEN 3 
  END;
```
**API:** `GET /api/v1/entities/{id}/policies`

#### 2.6.2 Consultas de Violações

**Violações críticas em aberto:**
```sql
SELECT e.name as entity_name,
       gp.policy_name, gp.compliance_framework,
       pv.violation_type, pv.severity, pv.description,
       pv.detected_at, pv.status,
       u.username as assigned_to
FROM policy_violations pv
JOIN entities e ON pv.entity_id = e.id
JOIN governance_policies gp ON pv.policy_id = gp.id
LEFT JOIN users u ON pv.assigned_to = u.id
WHERE pv.status IN ('OPEN', 'IN_PROGRESS')
  AND pv.severity = 'CRITICAL'
ORDER BY pv.detected_at DESC;
```
**API:** `GET /api/v1/policies/violations?status=OPEN,IN_PROGRESS&severity=CRITICAL`

**Relatório de compliance por framework:**
```sql
SELECT gp.compliance_framework,
       COUNT(DISTINCT gp.id) as total_policies,
       COUNT(DISTINCT pv.id) as total_violations,
       COUNT(DISTINCT CASE WHEN pv.status = 'RESOLVED' THEN pv.id END) as resolved_violations,
       ROUND(
         COUNT(DISTINCT CASE WHEN pv.status = 'RESOLVED' THEN pv.id END) * 100.0 / 
         NULLIF(COUNT(DISTINCT pv.id), 0), 2
       ) as compliance_rate
FROM governance_policies gp
LEFT JOIN policy_violations pv ON gp.id = pv.policy_id
WHERE gp.is_active = true
GROUP BY gp.compliance_framework
ORDER BY compliance_rate DESC;
```
**API:** `GET /api/v1/policies/compliance-report`

### 2.7 MÓDULO DE DATA STEWARDSHIP

#### 2.7.1 Consultas de Stewards

**Stewards por domínio de expertise:**
```sql
SELECT ds.name, ds.email, ds.department,
       ds.expertise_domain, ds.expertise_level,
       COUNT(sa.id) as total_assignments,
       COUNT(CASE WHEN sa.status = 'ACTIVE' THEN 1 END) as active_assignments
FROM data_stewards ds
LEFT JOIN steward_assignments sa ON ds.id = sa.steward_id
GROUP BY ds.id, ds.name, ds.email, ds.department, ds.expertise_domain, ds.expertise_level
ORDER BY ds.expertise_domain, ds.expertise_level DESC;
```
**API:** `GET /api/v1/stewardship/stewards?include_assignments=true`

**Carga de trabalho dos stewards:**
```sql
SELECT ds.name, ds.email,
       COUNT(sa.id) as total_assignments,
       COUNT(CASE WHEN sa.priority = 'HIGH' THEN 1 END) as high_priority,
       COUNT(CASE WHEN sa.priority = 'CRITICAL' THEN 1 END) as critical,
       AVG(sa.estimated_effort_hours) as avg_effort_hours
FROM data_stewards ds
JOIN steward_assignments sa ON ds.id = sa.steward_id
WHERE sa.status = 'ACTIVE'
GROUP BY ds.id, ds.name, ds.email
ORDER BY critical DESC, high_priority DESC, total_assignments DESC;
```
**API:** `GET /api/v1/stewardship/workload`

#### 2.7.2 Consultas de Atividades

**Atividades recentes de stewardship:**
```sql
SELECT ds.name as steward_name,
       e.name as entity_name,
       sa_act.activity_type, sa_act.description,
       sa_act.performed_at, sa_act.effort_hours
FROM steward_activities sa_act
JOIN data_stewards ds ON sa_act.steward_id = ds.id
JOIN entities e ON sa_act.entity_id = e.id
WHERE sa_act.performed_at >= CURRENT_DATE - INTERVAL '7 days'
ORDER BY sa_act.performed_at DESC;
```
**API:** `GET /api/v1/stewardship/activities?period=7days`

**Métricas de produtividade dos stewards:**
```sql
SELECT ds.name, ds.expertise_domain,
       COUNT(sa_act.id) as total_activities,
       SUM(sa_act.effort_hours) as total_effort_hours,
       AVG(sa_act.effort_hours) as avg_effort_per_activity,
       COUNT(DISTINCT sa_act.entity_id) as entities_managed
FROM data_stewards ds
JOIN steward_activities sa_act ON ds.id = sa_act.steward_id
WHERE sa_act.performed_at >= CURRENT_DATE - INTERVAL '30 days'
GROUP BY ds.id, ds.name, ds.expertise_domain
ORDER BY total_activities DESC;
```
**API:** `GET /api/v1/stewardship/metrics?period=30days`

### 2.8 CONSULTAS AVANÇADAS E ANALÍTICAS

#### 2.8.1 Consultas Cross-Module

**Dashboard executivo completo:**
```sql
SELECT 
  (SELECT COUNT(*) FROM entities) as total_entities,
  (SELECT COUNT(*) FROM data_contracts WHERE status = 'APPROVED') as approved_contracts,
  (SELECT AVG(completeness_score) FROM quality_metrics 
   WHERE measured_at >= CURRENT_DATE - INTERVAL '7 days') as avg_quality_score,
  (SELECT COUNT(*) FROM policy_violations WHERE status = 'OPEN') as open_violations,
  (SELECT COUNT(*) FROM data_stewards WHERE is_active = true) as active_stewards,
  (SELECT COUNT(*) FROM external_integrations WHERE status = 'ACTIVE') as active_integrations;
```
**API:** `GET /api/v1/dashboard/executive`

**Relatório de governança por entidade:**
```sql
SELECT e.name as entity_name, e.source_system, e.sensitivity_level,
       dc.name as contract_name, dc.status as contract_status,
       AVG(qm.completeness_score) as avg_quality,
       COUNT(pv.id) as total_violations,
       ds.name as assigned_steward
FROM entities e
LEFT JOIN data_contracts dc ON e.contract_id = dc.id
LEFT JOIN quality_metrics qm ON e.id = qm.entity_id 
  AND qm.measured_at >= CURRENT_DATE - INTERVAL '30 days'
LEFT JOIN policy_violations pv ON e.id = pv.entity_id AND pv.status = 'OPEN'
LEFT JOIN steward_assignments sa ON e.id = sa.entity_id AND sa.status = 'ACTIVE'
LEFT JOIN data_stewards ds ON sa.steward_id = ds.id
GROUP BY e.id, e.name, e.source_system, e.sensitivity_level, 
         dc.name, dc.status, ds.name
ORDER BY total_violations DESC, avg_quality ASC;
```
**API:** `GET /api/v1/entities/governance-report`

#### 2.8.2 Consultas de Performance e Otimização

**Entidades mais acessadas:**
```sql
SELECT e.name, e.entity_type, e.source_system,
       eus.access_count, eus.last_accessed,
       eus.unique_users, eus.avg_query_time_ms
FROM entities e
JOIN entity_usage_stats eus ON e.id = eus.entity_id
WHERE eus.period_start >= CURRENT_DATE - INTERVAL '30 days'
ORDER BY eus.access_count DESC
LIMIT 20;
```
**API:** `GET /api/v1/entities/usage-stats?period=30days&limit=20`

**Análise de performance de queries:**
```sql
SELECT sa.query_pattern, sa.search_term,
       COUNT(*) as search_count,
       AVG(sa.response_time_ms) as avg_response_time,
       COUNT(DISTINCT sa.user_id) as unique_users
FROM search_analytics sa
WHERE sa.searched_at >= CURRENT_DATE - INTERVAL '7 days'
GROUP BY sa.query_pattern, sa.search_term
ORDER BY search_count DESC
LIMIT 50;
```
**API:** `GET /api/v1/analytics/search-performance?period=7days`

#### 2.8.3 Consultas de Auditoria e Compliance

**Trilha de auditoria completa:**
```sql
SELECT al.action_type, al.table_name, al.record_id,
       al.old_values, al.new_values,
       u.username as performed_by,
       al.performed_at, al.ip_address
FROM audit_logs al
JOIN users u ON al.user_id = u.id
WHERE al.performed_at >= CURRENT_DATE - INTERVAL '24 hours'
ORDER BY al.performed_at DESC;
```
**API:** `GET /api/v1/audit/logs?period=24hours`

**Relatório de compliance LGPD:**
```sql
SELECT e.name as entity_name,
       COUNT(CASE WHEN ea.is_pii THEN 1 END) as pii_attributes,
       CASE WHEN dmr.id IS NOT NULL THEN 'MASKED' ELSE 'NOT_MASKED' END as masking_status,
       CASE WHEN drp.id IS NOT NULL THEN 'HAS_RETENTION' ELSE 'NO_RETENTION' END as retention_status,
       COUNT(pv.id) as lgpd_violations
FROM entities e
LEFT JOIN entity_attributes ea ON e.id = ea.entity_id
LEFT JOIN data_masking_rules dmr ON e.id = dmr.entity_id AND dmr.is_active = true
LEFT JOIN data_retention_policies drp ON e.id = drp.entity_id AND drp.is_active = true
LEFT JOIN policy_violations pv ON e.id = pv.entity_id 
  AND pv.policy_id IN (SELECT id FROM governance_policies WHERE compliance_framework = 'LGPD')
  AND pv.status = 'OPEN'
GROUP BY e.id, e.name, dmr.id, drp.id
HAVING COUNT(CASE WHEN ea.is_pii THEN 1 END) > 0
ORDER BY lgpd_violations DESC, pii_attributes DESC;
```
**API:** `GET /api/v1/compliance/lgpd-report`

## 3. CONSULTAS ESPECIALIZADAS POR CASO DE USO

### 3.1 Descoberta de Dados

**Busca inteligente por termo:**
```sql
SELECT 'entity' as result_type, e.name, e.description, e.source_system,
       ts_rank(to_tsvector('portuguese', e.name || ' ' || COALESCE(e.description, '')), 
                plainto_tsquery('portuguese', $1)) as relevance
FROM entities e
WHERE to_tsvector('portuguese', e.name || ' ' || COALESCE(e.description, '')) 
      @@ plainto_tsquery('portuguese', $1)

UNION ALL

SELECT 'attribute' as result_type, 
       e.name || '.' || ea.name as name, 
       ea.description, e.source_system,
       ts_rank(to_tsvector('portuguese', ea.name || ' ' || COALESCE(ea.description, '')), 
                plainto_tsquery('portuguese', $1)) as relevance
FROM entity_attributes ea
JOIN entities e ON ea.entity_id = e.id
WHERE to_tsvector('portuguese', ea.name || ' ' || COALESCE(ea.description, '')) 
      @@ plainto_tsquery('portuguese', $1)

ORDER BY relevance DESC
LIMIT 50;
```
**API:** `GET /api/v1/search?q={term}&limit=50`

### 3.2 Análise de Qualidade

**Score de qualidade consolidado:**
```sql
WITH quality_scores AS (
  SELECT e.id, e.name,
         AVG(qm.completeness_score) as completeness,
         AVG(qm.consistency_score) as consistency,
         AVG(qm.validity_score) as validity,
         AVG(qm.accuracy_score) as accuracy
  FROM entities e
  JOIN quality_metrics qm ON e.id = qm.entity_id
  WHERE qm.measured_at >= CURRENT_DATE - INTERVAL '7 days'
  GROUP BY e.id, e.name
)
SELECT name,
       ROUND((completeness + consistency + validity + accuracy) / 4, 2) as overall_score,
       ROUND(completeness, 2) as completeness,
       ROUND(consistency, 2) as consistency,
       ROUND(validity, 2) as validity,
       ROUND(accuracy, 2) as accuracy,
       CASE 
         WHEN (completeness + consistency + validity + accuracy) / 4 >= 0.9 THEN 'EXCELLENT'
         WHEN (completeness + consistency + validity + accuracy) / 4 >= 0.8 THEN 'GOOD'
         WHEN (completeness + consistency + validity + accuracy) / 4 >= 0.7 THEN 'FAIR'
         ELSE 'POOR'
       END as quality_grade
FROM quality_scores
ORDER BY overall_score DESC;
```
**API:** `GET /api/v1/quality/consolidated-scores?period=7days`

### 3.3 Gestão de Temperatura de Dados

**Análise de temperatura e custos:**
```sql
SELECT e.name as entity_name, e.source_system,
       dap.access_frequency, dap.last_access_date,
       dtp.hot_tier_days, dtp.warm_tier_days, dtp.cold_tier_days,
       CASE 
         WHEN dap.last_access_date >= CURRENT_DATE - INTERVAL '30 days' THEN 'HOT'
         WHEN dap.last_access_date >= CURRENT_DATE - INTERVAL '90 days' THEN 'WARM'
         ELSE 'COLD'
       END as current_temperature,
       sm.source_tier, sm.target_tier, sm.migration_date,
       pm.storage_cost_monthly
FROM entities e
JOIN data_access_patterns dap ON e.id = dap.entity_id
JOIN data_temperature_policies dtp ON e.id = dtp.entity_id
LEFT JOIN storage_migrations sm ON e.id = sm.entity_id 
  AND sm.migration_date >= CURRENT_DATE - INTERVAL '30 days'
LEFT JOIN performance_metrics pm ON e.id = pm.entity_id
  AND pm.metric_type = 'STORAGE_COST'
ORDER BY pm.storage_cost_monthly DESC NULLS LAST;
```
**API:** `GET /api/v1/temperature/analysis?include_costs=true`

## 4. ENDPOINTS DA API ORGANIZADOS

### 4.1 Endpoints de Consulta por Módulo

#### Autenticação (8 endpoints)
- `GET /api/v1/auth/users` - Listar usuários
- `GET /api/v1/auth/users/{id}` - Obter usuário específico
- `GET /api/v1/auth/sessions` - Listar sessões ativas
- `GET /api/v1/auth/roles` - Listar roles
- `GET /api/v1/auth/permissions` - Listar permissões
- `GET /api/v1/auth/analytics/logins` - Analytics de login
- `GET /api/v1/auth/audit` - Auditoria de acesso
- `GET /api/v1/auth/health` - Status do módulo

#### Contratos (12 endpoints)
- `GET /api/v1/contracts` - Listar contratos
- `GET /api/v1/contracts/{id}` - Obter contrato específico
- `GET /api/v1/contracts/{id}/versions` - Versões do contrato
- `GET /api/v1/contracts/search` - Buscar contratos
- `GET /api/v1/contracts/analytics` - Analytics de contratos
- `GET /api/v1/contracts/stats` - Estatísticas
- `GET /api/v1/contracts/pending-approval` - Pendentes
- `GET /api/v1/contracts/by-status` - Por status
- `GET /api/v1/contracts/by-author` - Por autor
- `GET /api/v1/contracts/approval-time` - Tempo aprovação
- `GET /api/v1/contracts/compliance` - Compliance
- `GET /api/v1/contracts/health` - Status do módulo

#### Entidades (15 endpoints)
- `GET /api/v1/entities` - Listar entidades
- `GET /api/v1/entities/{id}` - Obter entidade específica
- `GET /api/v1/entities/{id}/attributes` - Atributos
- `GET /api/v1/entities/{id}/relationships` - Relacionamentos
- `GET /api/v1/entities/{id}/tags` - Tags
- `GET /api/v1/entities/{id}/quality` - Qualidade
- `GET /api/v1/entities/{id}/lineage` - Lineage
- `GET /api/v1/entities/{id}/policies` - Políticas aplicáveis
- `GET /api/v1/entities/search` - Buscar entidades
- `GET /api/v1/entities/discover` - Descobrir entidades
- `GET /api/v1/entities/analytics` - Analytics
- `GET /api/v1/entities/usage-stats` - Estatísticas de uso
- `GET /api/v1/entities/governance-report` - Relatório governança
- `GET /api/v1/entities/pii` - Entidades com PII
- `GET /api/v1/entities/health` - Status do módulo

### 4.2 Endpoints de Relatórios Executivos

#### Dashboard Principal
- `GET /api/v1/dashboard/executive` - Dashboard executivo
- `GET /api/v1/dashboard/quality` - Dashboard qualidade
- `GET /api/v1/dashboard/compliance` - Dashboard compliance
- `GET /api/v1/dashboard/stewardship` - Dashboard stewardship
- `GET /api/v1/dashboard/lineage` - Dashboard lineage

#### Relatórios de Compliance
- `GET /api/v1/compliance/lgpd-report` - Relatório LGPD
- `GET /api/v1/compliance/gdpr-report` - Relatório GDPR
- `GET /api/v1/compliance/sox-report` - Relatório SOX
- `GET /api/v1/compliance/bacen-report` - Relatório BACEN
- `GET /api/v1/compliance/summary` - Resumo compliance

#### Analytics Avançados
- `GET /api/v1/analytics/search-performance` - Performance busca
- `GET /api/v1/analytics/user-behavior` - Comportamento usuário
- `GET /api/v1/analytics/data-usage` - Uso de dados
- `GET /api/v1/analytics/quality-trends` - Tendências qualidade
- `GET /api/v1/analytics/cost-optimization` - Otimização custos

## 5. EXEMPLOS DE CONSULTAS COMPLEXAS

### 5.1 Consulta de Impacto de Mudança

```sql
-- Análise completa de impacto para mudança em uma entidade
WITH RECURSIVE impact_tree AS (
    -- Nível 0: Entidade origem
    SELECT e.id, e.name, 0 as level, 'SOURCE' as impact_type,
           e.sensitivity_level, e.source_system
    FROM entities e WHERE e.id = $1
    
    UNION ALL
    
    -- Níveis subsequentes: Entidades impactadas
    SELECT e.id, e.name, it.level + 1, 'DOWNSTREAM' as impact_type,
           e.sensitivity_level, e.source_system
    FROM entities e
    JOIN data_lineage dl ON e.id = dl.target_entity_id
    JOIN impact_tree it ON dl.source_entity_id = it.id
    WHERE it.level < 5
),
quality_impact AS (
    SELECT it.id, it.name, it.level,
           AVG(qm.completeness_score) as avg_quality,
           COUNT(dqi.id) as open_issues
    FROM impact_tree it
    LEFT JOIN quality_metrics qm ON it.id = qm.entity_id
      AND qm.measured_at >= CURRENT_DATE - INTERVAL '7 days'
    LEFT JOIN data_quality_issues dqi ON it.id = dqi.entity_id
      AND dqi.status = 'OPEN'
    GROUP BY it.id, it.name, it.level
),
steward_impact AS (
    SELECT it.id, ds.name as steward_name, ds.email
    FROM impact_tree it
    JOIN steward_assignments sa ON it.id = sa.entity_id AND sa.status = 'ACTIVE'
    JOIN data_stewards ds ON sa.steward_id = ds.id
)
SELECT it.name as entity_name, it.level, it.impact_type,
       it.sensitivity_level, it.source_system,
       qi.avg_quality, qi.open_issues,
       si.steward_name, si.email as steward_email,
       COUNT(DISTINCT pv.id) as policy_violations
FROM impact_tree it
LEFT JOIN quality_impact qi ON it.id = qi.id
LEFT JOIN steward_impact si ON it.id = si.id
LEFT JOIN policy_violations pv ON it.id = pv.entity_id AND pv.status = 'OPEN'
GROUP BY it.id, it.name, it.level, it.impact_type, it.sensitivity_level, 
         it.source_system, qi.avg_quality, qi.open_issues, si.steward_name, si.email
ORDER BY it.level, it.name;
```

### 5.2 Consulta de Otimização de Custos

```sql
-- Análise de otimização de custos por temperatura de dados
WITH cost_analysis AS (
    SELECT e.id, e.name, e.source_system,
           dap.access_frequency, dap.last_access_date,
           pm.storage_cost_monthly,
           CASE 
             WHEN dap.last_access_date >= CURRENT_DATE - INTERVAL '7 days' THEN 'HOT'
             WHEN dap.last_access_date >= CURRENT_DATE - INTERVAL '30 days' THEN 'WARM'
             WHEN dap.last_access_date >= CURRENT_DATE - INTERVAL '90 days' THEN 'COOL'
             ELSE 'COLD'
           END as recommended_tier,
           CASE 
             WHEN dap.last_access_date >= CURRENT_DATE - INTERVAL '7 days' THEN pm.storage_cost_monthly
             WHEN dap.last_access_date >= CURRENT_DATE - INTERVAL '30 days' THEN pm.storage_cost_monthly * 0.7
             WHEN dap.last_access_date >= CURRENT_DATE - INTERVAL '90 days' THEN pm.storage_cost_monthly * 0.4
             ELSE pm.storage_cost_monthly * 0.1
           END as optimized_cost
    FROM entities e
    JOIN data_access_patterns dap ON e.id = dap.entity_id
    JOIN performance_metrics pm ON e.id = pm.entity_id 
      AND pm.metric_type = 'STORAGE_COST'
    WHERE pm.measured_at >= CURRENT_DATE - INTERVAL '30 days'
)
SELECT name, source_system, recommended_tier,
       ROUND(storage_cost_monthly, 2) as current_cost,
       ROUND(optimized_cost, 2) as optimized_cost,
       ROUND(storage_cost_monthly - optimized_cost, 2) as potential_savings,
       ROUND(((storage_cost_monthly - optimized_cost) / storage_cost_monthly) * 100, 1) as savings_percentage,
       access_frequency, last_access_date
FROM cost_analysis
WHERE storage_cost_monthly > optimized_cost
ORDER BY potential_savings DESC;
```

## 6. CONCLUSÃO

Este guia apresenta mais de 100 consultas diferentes organizadas por módulo e caso de uso, cobrindo:

- **Consultas Básicas:** CRUD e listagens simples
- **Consultas Relacionais:** Joins complexos entre módulos
- **Consultas Analíticas:** Agregações e métricas
- **Consultas de Auditoria:** Rastreabilidade e compliance
- **Consultas de Performance:** Otimizações e estatísticas
- **Consultas Especializadas:** Casos de uso específicos

Cada consulta inclui:
- **SQL completo** pronto para execução
- **Endpoint da API** correspondente
- **Parâmetros** e filtros disponíveis
- **Casos de uso** recomendados

O modelo de dados suporta consultas desde simples listagens até análises complexas de impacto e otimização, fornecendo uma base sólida para governança de dados enterprise.

---

**Responsável:** Carlos Morais (carlos.morais@f1rst.com.br)  
**Organização:** F1rst Technology Solutions  
**Total de Consultas:** 100+  
**Cobertura:** 58 tabelas, 114 endpoints

