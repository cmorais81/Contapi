"""
Repositório de Entidades
API de Governança de Dados V1.3
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from typing import List, Optional, Dict, Any
from sqlalchemy.orm import Session
from sqlalchemy import func, and_, or_
from uuid import UUID

from database.models.entities import Entity, EntityAttribute, EntityRelationship
from database.repositories.base import BaseRepository

class EntityRepository(BaseRepository[Entity]):
    """Repositório para operações com entidades de dados"""
    
    def __init__(self, db: Session):
        super().__init__(Entity, db)
    
    def get_by_name(self, name: str) -> Optional[Entity]:
        """Busca entidade por nome"""
        return self.db.query(Entity).filter(Entity.name == name).first()
    
    def get_by_schema(self, schema_name: str) -> List[Entity]:
        """Busca entidades por schema"""
        return self.db.query(Entity).filter(Entity.schema_name == schema_name).all()
    
    def get_by_type(self, entity_type: str) -> List[Entity]:
        """Busca entidades por tipo"""
        return self.db.query(Entity).filter(Entity.entity_type == entity_type).all()
    
    def search_entities(
        self, 
        search_term: Optional[str] = None,
        entity_type: Optional[str] = None,
        schema_name: Optional[str] = None,
        tags: Optional[List[str]] = None,
        limit: int = 50,
        offset: int = 0
    ) -> List[Entity]:
        """Busca entidades com filtros avançados"""
        query = self.db.query(Entity)
        
        if search_term:
            query = query.filter(
                or_(
                    Entity.name.ilike(f"%{search_term}%"),
                    Entity.description.ilike(f"%{search_term}%")
                )
            )
        
        if entity_type:
            query = query.filter(Entity.entity_type == entity_type)
        
        if schema_name:
            query = query.filter(Entity.schema_name == schema_name)
        
        if tags:
            # Assumindo que tags são armazenadas como JSON array
            for tag in tags:
                query = query.filter(Entity.tags.contains([tag]))
        
        return query.offset(offset).limit(limit).all()
    
    def get_entity_with_attributes(self, entity_id: UUID) -> Optional[Entity]:
        """Busca entidade com seus atributos"""
        return self.db.query(Entity).filter(Entity.id == entity_id).first()
    
    def get_entity_relationships(self, entity_id: UUID) -> List[EntityRelationship]:
        """Busca relacionamentos de uma entidade"""
        return self.db.query(EntityRelationship).filter(
            or_(
                EntityRelationship.source_entity_id == entity_id,
                EntityRelationship.target_entity_id == entity_id
            )
        ).all()
    
    def get_entities_by_steward(self, steward_id: UUID) -> List[Entity]:
        """Busca entidades por steward responsável"""
        return self.db.query(Entity).filter(Entity.steward_id == steward_id).all()
    
    def get_entities_by_domain(self, domain_id: UUID) -> List[Entity]:
        """Busca entidades por domínio"""
        return self.db.query(Entity).filter(Entity.domain_id == domain_id).all()
    
    def count_entities_by_type(self) -> Dict[str, int]:
        """Conta entidades por tipo"""
        result = self.db.query(
            Entity.entity_type,
            func.count(Entity.id).label('count')
        ).group_by(Entity.entity_type).all()
        
        return {row.entity_type: row.count for row in result}
    
    def get_recently_updated(self, days: int = 7, limit: int = 20) -> List[Entity]:
        """Busca entidades atualizadas recentemente"""
        from datetime import datetime, timedelta
        cutoff_date = datetime.utcnow() - timedelta(days=days)
        
        return self.db.query(Entity).filter(
            Entity.updated_at >= cutoff_date
        ).order_by(Entity.updated_at.desc()).limit(limit).all()
    
    def get_entities_without_steward(self) -> List[Entity]:
        """Busca entidades sem steward atribuído"""
        return self.db.query(Entity).filter(Entity.steward_id.is_(None)).all()
    
    def update_entity_quality_score(self, entity_id: UUID, quality_score: float) -> bool:
        """Atualiza score de qualidade da entidade"""
        try:
            entity = self.get_by_id(entity_id)
            if entity:
                entity.quality_score = quality_score
                self.db.commit()
                return True
            return False
        except Exception:
            self.db.rollback()
            return False

class EntityAttributeRepository(BaseRepository[EntityAttribute]):
    """Repositório para operações com atributos de entidades"""
    
    def __init__(self, db: Session):
        super().__init__(EntityAttribute, db)
    
    def get_by_entity(self, entity_id: UUID) -> List[EntityAttribute]:
        """Busca atributos por entidade"""
        return self.db.query(EntityAttribute).filter(
            EntityAttribute.entity_id == entity_id
        ).order_by(EntityAttribute.position).all()
    
    def get_by_name_and_entity(self, entity_id: UUID, attribute_name: str) -> Optional[EntityAttribute]:
        """Busca atributo específico de uma entidade"""
        return self.db.query(EntityAttribute).filter(
            and_(
                EntityAttribute.entity_id == entity_id,
                EntityAttribute.name == attribute_name
            )
        ).first()
    
    def get_sensitive_attributes(self) -> List[EntityAttribute]:
        """Busca atributos marcados como sensíveis"""
        return self.db.query(EntityAttribute).filter(
            EntityAttribute.is_sensitive == True
        ).all()
    
    def get_primary_keys(self, entity_id: UUID) -> List[EntityAttribute]:
        """Busca atributos que são chaves primárias"""
        return self.db.query(EntityAttribute).filter(
            and_(
                EntityAttribute.entity_id == entity_id,
                EntityAttribute.is_primary_key == True
            )
        ).all()

class EntityRelationshipRepository(BaseRepository[EntityRelationship]):
    """Repositório para operações com relacionamentos entre entidades"""
    
    def __init__(self, db: Session):
        super().__init__(EntityRelationship, db)
    
    def get_by_source_entity(self, source_entity_id: UUID) -> List[EntityRelationship]:
        """Busca relacionamentos onde a entidade é origem"""
        return self.db.query(EntityRelationship).filter(
            EntityRelationship.source_entity_id == source_entity_id
        ).all()
    
    def get_by_target_entity(self, target_entity_id: UUID) -> List[EntityRelationship]:
        """Busca relacionamentos onde a entidade é destino"""
        return self.db.query(EntityRelationship).filter(
            EntityRelationship.target_entity_id == target_entity_id
        ).all()
    
    def get_by_type(self, relationship_type: str) -> List[EntityRelationship]:
        """Busca relacionamentos por tipo"""
        return self.db.query(EntityRelationship).filter(
            EntityRelationship.relationship_type == relationship_type
        ).all()
    
    def get_relationship_chain(
        self, 
        start_entity_id: UUID, 
        end_entity_id: UUID,
        max_depth: int = 5
    ) -> List[List[EntityRelationship]]:
        """Busca cadeias de relacionamentos entre duas entidades"""
        # Implementação simplificada - pode ser expandida com algoritmo de busca em grafo
        direct_relationships = self.db.query(EntityRelationship).filter(
            and_(
                EntityRelationship.source_entity_id == start_entity_id,
                EntityRelationship.target_entity_id == end_entity_id
            )
        ).all()
        
        return [direct_relationships] if direct_relationships else []

