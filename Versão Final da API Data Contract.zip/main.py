            "Instalar dependências faltantes se necessário",
            "Verificar estrutura de diretórios",
            "Confirmar compatibilidade Python 3.13"
        ]
    }

# Incluir routers dos controllers disponíveis
routers_included = []
routers_failed = []

for controller_name, controller_module in controllers.items():
    try:
        if hasattr(controller_module, 'router'):
            app.include_router(
                controller_module.router, 
                prefix="/api/v1", 
                tags=[controller_name.title()]
            )
            routers_included.append(controller_name)
            logger.info(f"✓ Router {controller_name} incluído com sucesso")
        else:
            routers_failed.append(f"{controller_name}: router não encontrado")
            logger.warning(f"✗ Controller {controller_name} não possui router")
    except Exception as e:
        routers_failed.append(f"{controller_name}: {str(e)}")
        logger.error(f"✗ Erro ao incluir router {controller_name}: {e}")

logger.info(f"Routers incluídos: {len(routers_included)}")
logger.info(f"Routers falharam: {len(routers_failed)}")

# Middleware para adicionar headers de autor e diagnóstico
@app.middleware("http")
async def add_diagnostic_headers(request: Request, call_next):
    """Adiciona headers com informações de diagnóstico"""
    response = await call_next(request)
    response.headers["X-Author"] = "Carlos Morais"
    response.headers["X-Author-Email"] = "carlos.morais@f1rst.com.br"
    response.headers["X-Organization"] = "F1rst"
    response.headers["X-API-Version"] = "1.5.0"
    response.headers["X-Python-Version"] = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    response.headers["X-Platform"] = sys.platform
    response.headers["X-Modules-Loaded"] = str(len(modules_loaded))
    response.headers["X-Controllers-Loaded"] = str(len(controllers_loaded))
    response.headers["X-Routers-Included"] = str(len(routers_included))
    response.headers["X-Modules-Failed"] = str(len(modules_failed))
    response.headers["X-Controllers-Failed"] = str(len(controllers_failed))
    response.headers["X-Routers-Failed"] = str(len(routers_failed))
    return response

# Endpoint para listar controllers e routers