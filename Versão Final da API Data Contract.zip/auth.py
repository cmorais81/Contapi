"""
Controller de Autenticação Enterprise - V2.3 com Banco de Dados
API de Governança de Dados V2.3
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from fastapi import APIRouter, HTTPException, Depends, Query, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from typing import List, Optional, Dict, Any
from uuid import UUID
from sqlalchemy.orm import Session
from datetime import datetime, timedelta
import logging
import jwt
import bcrypt
import secrets

from database.connection import get_database_session
from database.models.auth import User, UserSession, SecurityRole, UserRole, ApiKey
from database.repositories.base import BaseRepository

logger = logging.getLogger(__name__)

# Configurações de segurança
SECRET_KEY = "your-secret-key-here"  # TODO: Mover para variável de ambiente
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

# Criar router e security
router = APIRouter()
security = HTTPBearer()

def get_user_repository(db: Session = Depends(get_database_session)) -> BaseRepository[User]:
    """Dependency para obter repository de usuários"""
    return BaseRepository(User, db)

def get_session_repository(db: Session = Depends(get_database_session)) -> BaseRepository[UserSession]:
    """Dependency para obter repository de sessões"""
    return BaseRepository(UserSession, db)

def get_role_repository(db: Session = Depends(get_database_session)) -> BaseRepository[SecurityRole]:
    """Dependency para obter repository de roles"""
    return BaseRepository(SecurityRole, db)

def get_user_role_repository(db: Session = Depends(get_database_session)) -> BaseRepository[UserRole]:
    """Dependency para obter repository de user roles"""
    return BaseRepository(UserRole, db)

def get_api_key_repository(db: Session = Depends(get_database_session)) -> BaseRepository[ApiKey]:
    """Dependency para obter repository de API keys"""
    return BaseRepository(ApiKey, db)

# ========================================
# UTILITÁRIOS DE AUTENTICAÇÃO
# ========================================

def hash_password(password: str) -> str:
    """Hash da senha usando bcrypt"""
    salt = bcrypt.gensalt()
    return bcrypt.hashpw(password.encode('utf-8'), salt).decode('utf-8')

def verify_password(password: str, hashed: str) -> bool:
    """Verifica senha contra hash"""
    return bcrypt.checkpw(password.encode('utf-8'), hashed.encode('utf-8'))

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    """Cria token JWT"""
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

def verify_token(token: str) -> Dict[str, Any]:
    """Verifica e decodifica token JWT"""
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return payload
    except jwt.PyJWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token inválido",
            headers={"WWW-Authenticate": "Bearer"},
        )

async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    user_repository: BaseRepository[User] = Depends(get_user_repository)
) -> User:
    """Obtém usuário atual baseado no token"""
    payload = verify_token(credentials.credentials)
    user_id = payload.get("sub")
    if user_id is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token inválido",
        )
    
    user = user_repository.get_by_id(user_id)
    if user is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Usuário não encontrado",
        )
    
    return user

# ========================================
# AUTENTICAÇÃO
# ========================================

@router.post("/auth/login", summary="Login de usuário")
async def login(
    login_data: Dict[str, Any],
    user_repository: BaseRepository[User] = Depends(get_user_repository),
    session_repository: BaseRepository[UserSession] = Depends(get_session_repository)
):
    """
    Autentica usuário e retorna token de acesso.
    
    Campos obrigatórios:
    - username: Nome de usuário ou email
    - password: Senha
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        username = login_data.get("username")
        password = login_data.get("password")
        
        if not username or not password:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Username e password são obrigatórios"
            )
        
        # Buscar usuário por username ou email
        user = user_repository.find_one_by(username=username)
        if not user:
            user = user_repository.find_one_by(email=username)
        
        if not user or not verify_password(password, user.password_hash):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Credenciais inválidas"
            )
        
        if not user.is_active:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Usuário inativo"
            )
        
        # Criar token de acesso
        access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
        access_token = create_access_token(
            data={"sub": str(user.id), "username": user.username},
            expires_delta=access_token_expires
        )
        
        # Criar sessão
        session_data = {
            "user_id": user.id,
            "session_token": access_token,
            "expires_at": datetime.utcnow() + access_token_expires,
            "ip_address": login_data.get("ip_address"),
            "user_agent": login_data.get("user_agent")
        }
        session = session_repository.create(**session_data)
        
        # Atualizar último login
        user_repository.update(user.id, {
            "last_login": datetime.utcnow(),
            "login_count": (user.login_count or 0) + 1
        })
        
        logger.info(f"Login bem-sucedido: {user.username}")
        
        return {
            "access_token": access_token,
            "token_type": "bearer",
            "expires_in": ACCESS_TOKEN_EXPIRE_MINUTES * 60,
            "user": {
                "id": str(user.id),
                "username": user.username,
                "email": user.email,
                "full_name": user.full_name,
                "department": user.department
            },
            "session_id": str(session.id),
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro no login: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.post("/auth/logout", summary="Logout de usuário")
async def logout(
    current_user: User = Depends(get_current_user),
    session_repository: BaseRepository[UserSession] = Depends(get_session_repository)
):
    """
    Faz logout do usuário e invalida a sessão.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        # Invalidar todas as sessões ativas do usuário
        active_sessions = session_repository.find_by(
            user_id=current_user.id,
            is_active=True
        )
        
        for session in active_sessions:
            session_repository.update(session.id, {
                "is_active": False,
                "logged_out_at": datetime.utcnow()
            })
        
        logger.info(f"Logout realizado: {current_user.username}")
        
        return {
            "message": "Logout realizado com sucesso",
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except Exception as e:
        logger.error(f"Erro no logout: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.get("/auth/me", summary="Obter usuário atual")
async def get_current_user_info(
    current_user: User = Depends(get_current_user),
    user_role_repository: BaseRepository[UserRole] = Depends(get_user_role_repository),
    role_repository: BaseRepository[SecurityRole] = Depends(get_role_repository)
):
    """
    Obtém informações do usuário autenticado.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        # Obter roles do usuário
        user_roles = user_role_repository.find_by(user_id=current_user.id)
        roles = []
        
        for user_role in user_roles:
            role = role_repository.get_by_id(user_role.role_id)
            if role:
                roles.append({
                    "id": str(role.id),
                    "name": role.role_name,
                    "description": role.description,
                    "permissions": role.permissions
                })
        
        user_info = current_user.to_dict()
        user_info['roles'] = roles
        
        return {
            "user": user_info,
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except Exception as e:
        logger.error(f"Erro ao obter informações do usuário: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

# ========================================
# GESTÃO DE USUÁRIOS
# ========================================

@router.get("/auth/users", summary="Listar usuários")
async def list_users(
    limit: int = Query(100, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    department: Optional[str] = Query(None, description="Filtrar por departamento"),
    is_active: Optional[bool] = Query(None, description="Filtrar por status"),
    current_user: User = Depends(get_current_user),
    repository: BaseRepository[User] = Depends(get_user_repository)
):
    """
    Lista usuários do sistema.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        # TODO: Verificar permissões do usuário atual
        
        # Aplicar filtros
        filters = {}
        if department:
            filters['department'] = department
        if is_active is not None:
            filters['is_active'] = is_active
        
        # Buscar usuários
        users = repository.search(
            filters=filters,
            limit=limit,
            offset=offset,
            sort_by='username',
            sort_order='asc'
        )
        
        total = repository.count(filters)
        
        # Remover informações sensíveis
        safe_users = []
        for user in users:
            user_dict = user.to_dict()
            user_dict.pop('password_hash', None)
            safe_users.append(user_dict)
        
        logger.info(f"Listando {len(users)} usuários de {total} total")
        
        return {
            "users": safe_users,
            "total": total,
            "limit": limit,
            "offset": offset,
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except Exception as e:
        logger.error(f"Erro ao listar usuários: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.post("/auth/users", summary="Criar usuário")
async def create_user(
    user_data: Dict[str, Any],
    current_user: User = Depends(get_current_user),
    repository: BaseRepository[User] = Depends(get_user_repository)
):
    """
    Cria um novo usuário.
    
    Campos obrigatórios:
    - username: Nome de usuário
    - email: Email
    - password: Senha
    - full_name: Nome completo
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        # TODO: Verificar permissões do usuário atual
        
        # Validar dados obrigatórios
        required_fields = ['username', 'email', 'password', 'full_name']
        for field in required_fields:
            if field not in user_data:
                raise HTTPException(status_code=400, detail=f"Campo {field} é obrigatório")
        
        # Verificar se username já existe
        existing_username = repository.find_one_by(username=user_data['username'])
        if existing_username:
            raise HTTPException(status_code=409, detail="Username já existe")
        
        # Verificar se email já existe
        existing_email = repository.find_one_by(email=user_data['email'])
        if existing_email:
            raise HTTPException(status_code=409, detail="Email já existe")
        
        # Hash da senha
        user_data['password_hash'] = hash_password(user_data.pop('password'))
        
        # Criar usuário
        user = repository.create(**user_data)
        
        # Remover hash da resposta
        user_dict = user.to_dict()
        user_dict.pop('password_hash', None)
        
        logger.info(f"Usuário criado: {user.username}")
        
        return {
            "user": user_dict,
            "message": "Usuário criado com sucesso",
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao criar usuário: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

# ========================================
# GESTÃO DE ROLES
# ========================================

@router.get("/auth/roles", summary="Listar roles de segurança")
async def list_roles(
    limit: int = Query(100, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    current_user: User = Depends(get_current_user),
    repository: BaseRepository[SecurityRole] = Depends(get_role_repository)
):
    """
    Lista roles de segurança.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        # Buscar roles
        roles = repository.search(
            limit=limit,
            offset=offset,
            sort_by='role_name',
            sort_order='asc'
        )
        
        total = repository.count({})
        
        logger.info(f"Listando {len(roles)} roles de {total} total")
        
        return {
            "roles": [role.to_dict() for role in roles],
            "total": total,
            "limit": limit,
            "offset": offset,
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except Exception as e:
        logger.error(f"Erro ao listar roles: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.post("/auth/roles", summary="Criar role de segurança")
async def create_role(
    role_data: Dict[str, Any],
    current_user: User = Depends(get_current_user),
    repository: BaseRepository[SecurityRole] = Depends(get_role_repository)
):
    """
    Cria um novo role de segurança.
    
    Campos obrigatórios:
    - role_name: Nome do role
    - description: Descrição
    - permissions: Lista de permissões
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        # TODO: Verificar permissões do usuário atual
        
        # Validar dados obrigatórios
        required_fields = ['role_name', 'description', 'permissions']
        for field in required_fields:
            if field not in role_data:
                raise HTTPException(status_code=400, detail=f"Campo {field} é obrigatório")
        
        # Verificar se role já existe
        existing = repository.find_one_by(role_name=role_data['role_name'])
        if existing:
            raise HTTPException(status_code=409, detail="Role com este nome já existe")
        
        # Criar role
        role = repository.create(**role_data)
        
        logger.info(f"Role criado: {role.role_name}")
        
        return {
            "role": role.to_dict(),
            "message": "Role criado com sucesso",
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao criar role: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

# ========================================
# API KEYS
# ========================================

@router.get("/auth/api-keys", summary="Listar API keys")
async def list_api_keys(
    limit: int = Query(100, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    current_user: User = Depends(get_current_user),
    repository: BaseRepository[ApiKey] = Depends(get_api_key_repository)
):
    """
    Lista API keys do usuário.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        # Buscar API keys do usuário
        api_keys = repository.find_by(user_id=current_user.id)
        
        # Remover chaves sensíveis
        safe_keys = []
        for key in api_keys:
            key_dict = key.to_dict()
            # Mostrar apenas os últimos 4 caracteres
            if key_dict.get('key_hash'):
                key_dict['key_preview'] = '****' + key_dict['key_hash'][-4:]
            key_dict.pop('key_hash', None)
            safe_keys.append(key_dict)
        
        logger.info(f"Listando {len(api_keys)} API keys")
        
        return {
            "api_keys": safe_keys,
            "total": len(api_keys),
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except Exception as e:
        logger.error(f"Erro ao listar API keys: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.post("/auth/api-keys", summary="Criar API key")
async def create_api_key(
    key_data: Dict[str, Any],
    current_user: User = Depends(get_current_user),
    repository: BaseRepository[ApiKey] = Depends(get_api_key_repository)
):
    """
    Cria uma nova API key.
    
    Campos obrigatórios:
    - name: Nome da API key
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        # Gerar chave aleatória
        api_key = secrets.token_urlsafe(32)
        key_hash = hash_password(api_key)
        
        # Preparar dados
        key_data.update({
            'user_id': current_user.id,
            'key_hash': key_hash
        })
        
        # Criar API key
        api_key_obj = repository.create(**key_data)
        
        # Retornar chave apenas uma vez
        result = api_key_obj.to_dict()
        result['api_key'] = api_key  # Mostrar chave completa apenas na criação
        result.pop('key_hash', None)
        
        logger.info(f"API key criada: {api_key_obj.name}")
        
        return {
            "api_key_info": result,
            "message": "API key criada com sucesso. Guarde a chave em local seguro, ela não será mostrada novamente.",
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except Exception as e:
        logger.error(f"Erro ao criar API key: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")



# Função para obter usuário ativo atual
async def get_current_active_user(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: Session = Depends(get_database_session)
) -> User:
    """
    Obtém o usuário ativo atual baseado no token JWT
    
    Args:
        credentials: Credenciais HTTP Bearer
        db: Sessão do banco de dados
        
    Returns:
        User: Usuário autenticado e ativo
        
    Raises:
        HTTPException: Se token inválido ou usuário inativo
    """
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    
    try:
        # Decodificar token JWT
        token = credentials.credentials
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        
        if username is None:
            raise credentials_exception
            
    except jwt.JWTError:
        raise credentials_exception
    
    # Buscar usuário no banco de dados
    user_repo = BaseRepository(User, db)
    user = user_repo.get_by_field("username", username)
    
    if user is None:
        raise credentials_exception
        
    # Verificar se usuário está ativo
    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Inactive user"
        )
    
    return user

def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verifica se a senha está correta"""
    return bcrypt.checkpw(plain_password.encode('utf-8'), hashed_password.encode('utf-8'))

def get_password_hash(password: str) -> str:
    """Gera hash da senha"""
    salt = bcrypt.gensalt()
    return bcrypt.hashpw(password.encode('utf-8'), salt).decode('utf-8')

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    """Cria token de acesso JWT"""
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

def authenticate_user(db: Session, username: str, password: str) -> Optional[User]:
    """Autentica usuário com username e senha"""
    user_repo = BaseRepository(User, db)
    user = user_repo.get_by_field("username", username)
    
    if not user:
        return None
    if not verify_password(password, user.password_hash):
        return None
    return user

