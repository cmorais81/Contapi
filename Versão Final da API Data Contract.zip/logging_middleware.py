"""
Middleware de Logging Avançado
API de Governança de Dados V1.3
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

import time
import uuid
import json
import logging
from typing import Callable, Dict, Any
from fastapi import Request, Response
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp

logger = logging.getLogger(__name__)

class LoggingMiddleware(BaseHTTPMiddleware):
    """Middleware para logging detalhado de requisições e respostas"""
    
    def __init__(
        self,
        app: ASGIApp,
        log_requests: bool = True,
        log_responses: bool = True,
        log_body: bool = False,
        exclude_paths: list = None
    ):
        super().__init__(app)
        self.log_requests = log_requests
        self.log_responses = log_responses
        self.log_body = log_body
        self.exclude_paths = exclude_paths or ["/health", "/docs", "/openapi.json"]
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """Processa requisição e resposta com logging detalhado"""
        
        # Gerar ID único para a requisição
        request_id = str(uuid.uuid4())
        request.state.request_id = request_id
        
        # Verificar se deve fazer log desta rota
        if any(path in str(request.url.path) for path in self.exclude_paths):
            return await call_next(request)
        
        # Capturar dados da requisição
        start_time = time.time()
        request_data = await self._extract_request_data(request)
        
        # Log da requisição
        if self.log_requests:
            logger.info(
                f"REQUEST [{request_id}] {request.method} {request.url.path}",
                extra={
                    "request_id": request_id,
                    "method": request.method,
                    "path": request.url.path,
                    "query_params": dict(request.query_params),
                    "headers": dict(request.headers),
                    "client_ip": self._get_client_ip(request),
                    "user_agent": request.headers.get("user-agent"),
                    "request_data": request_data if self.log_body else None
                }
            )
        
        try:
            # Processar requisição
            response = await call_next(request)
            
            # Calcular tempo de processamento
            process_time = time.time() - start_time
            
            # Capturar dados da resposta
            response_data = await self._extract_response_data(response)
            
            # Log da resposta
            if self.log_responses:
                logger.info(
                    f"RESPONSE [{request_id}] {response.status_code} - {process_time:.3f}s",
                    extra={
                        "request_id": request_id,
                        "status_code": response.status_code,
                        "process_time": process_time,
                        "response_headers": dict(response.headers),
                        "response_data": response_data if self.log_body else None
                    }
                )
            
            # Adicionar headers de rastreamento
            response.headers["X-Request-ID"] = request_id
            response.headers["X-Process-Time"] = f"{process_time:.3f}"
            
            return response
            
        except Exception as e:
            # Log de erro
            process_time = time.time() - start_time
            logger.error(
                f"ERROR [{request_id}] {str(e)} - {process_time:.3f}s",
                extra={
                    "request_id": request_id,
                    "error": str(e),
                    "error_type": type(e).__name__,
                    "process_time": process_time
                },
                exc_info=True
            )
            
            # Retornar resposta de erro
            return JSONResponse(
                status_code=500,
                content={
                    "error": "Internal Server Error",
                    "request_id": request_id,
                    "message": "An unexpected error occurred"
                },
                headers={"X-Request-ID": request_id}
            )
    
    async def _extract_request_data(self, request: Request) -> Dict[str, Any]:
        """Extrai dados da requisição para logging"""
        try:
            if request.method in ["POST", "PUT", "PATCH"]:
                content_type = request.headers.get("content-type", "")
                
                if "application/json" in content_type:
                    body = await request.body()
                    if body:
                        return json.loads(body.decode())
                elif "application/x-www-form-urlencoded" in content_type:
                    form = await request.form()
                    return dict(form)
            
            return {}
        except Exception as e:
            logger.warning(f"Failed to extract request data: {e}")
            return {"error": "Failed to parse request body"}
    
    async def _extract_response_data(self, response: Response) -> Dict[str, Any]:
        """Extrai dados da resposta para logging"""
        try:
            if hasattr(response, 'body') and response.body:
                content_type = response.headers.get("content-type", "")
                
                if "application/json" in content_type:
                    body = response.body.decode() if isinstance(response.body, bytes) else response.body
                    return json.loads(body)
            
            return {}
        except Exception as e:
            logger.warning(f"Failed to extract response data: {e}")
            return {"error": "Failed to parse response body"}
    
    def _get_client_ip(self, request: Request) -> str:
        """Obtém IP real do cliente considerando proxies"""
        # Verificar headers de proxy
        forwarded_for = request.headers.get("X-Forwarded-For")
        if forwarded_for:
            return forwarded_for.split(",")[0].strip()
        
        real_ip = request.headers.get("X-Real-IP")
        if real_ip:
            return real_ip
        
        # IP direto
        return request.client.host if request.client else "unknown"

class PerformanceLoggingMiddleware(BaseHTTPMiddleware):
    """Middleware específico para logging de performance"""
    
    def __init__(self, app: ASGIApp, slow_request_threshold: float = 1.0):
        super().__init__(app)
        self.slow_request_threshold = slow_request_threshold
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """Monitora performance das requisições"""
        start_time = time.time()
        
        response = await call_next(request)
        
        process_time = time.time() - start_time
        
        # Log de requisições lentas
        if process_time > self.slow_request_threshold:
            logger.warning(
                f"SLOW REQUEST: {request.method} {request.url.path} took {process_time:.3f}s",
                extra={
                    "method": request.method,
                    "path": request.url.path,
                    "process_time": process_time,
                    "threshold": self.slow_request_threshold,
                    "status_code": response.status_code
                }
            )
        
        return response

