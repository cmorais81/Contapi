# COBOL AI Engine v2.0.0 - Documentação de Exemplos

**Data:** 13/09/2025

## Visão Geral

Esta documentação fornece exemplos práticos de como usar o COBOL AI Engine v2.0.0 em diferentes cenários. Os exemplos abrangem desde a análise simples de um trecho de código até workflows completos em notebooks Jupyter.

Todos os exemplos de código estão disponíveis no arquivo `examples/notebook_examples.py` e podem ser executados diretamente em um ambiente Python ou importados em um notebook.

## Estrutura dos Exemplos

O arquivo `examples/notebook_examples.py` contém uma série de funções, cada uma demonstrando uma funcionalidade específica da API programática. Ao final, há uma função `executar_todos_exemplos()` que executa todos os cenários em sequência.

### Como Executar os Exemplos

1. **Via Linha de Comando:**

   Você pode executar o arquivo de exemplos diretamente do seu terminal:

   ```bash
   # Navegue até o diretório do projeto
   cd cobol_ai_engine_v2.0.0

   # Execute o script de exemplos
   python3 examples/notebook_examples.py
   ```

   O script irá solicitar a confirmação para executar todos os exemplos.

2. **Em um Notebook Jupyter:**

   Esta é a maneira recomendada de explorar os exemplos, pois permite interagir com os resultados de cada etapa.

   ```python
   # Em uma célula do seu notebook:

   # 1. Adicione o diretório do projeto ao path
   import sys
   sys.path.append("/caminho/para/cobol_ai_engine_v2.0.0")

   # 2. Importe o módulo de exemplos
   from examples import notebook_examples as ne

   # 3. Execute um exemplo específico
   resultado = ne.exemplo_analise_simples()

   # Ou execute todos os exemplos de uma vez
   resultados_completos = ne.executar_todos_exemplos()
   ```

## Detalhes dos Exemplos

### Exemplo 1: Análise Simples de Código

- **Função:** `exemplo_analise_simples()`
- **Objetivo:** Demonstrar a maneira mais rápida de analisar um trecho de código COBOL usando a função de conveniência `analyze_cobol()`.
- **O que faz:**
  1. Define um pequeno programa COBOL como uma string.
  2. Chama `cae.analyze_cobol()` para analisá-lo.
  3. Imprime a documentação gerada no console.

### Exemplo 2: Análise de Arquivo

- **Função:** `exemplo_analise_arquivo()`
- **Objetivo:** Mostrar como analisar um arquivo COBOL existente no sistema de arquivos.
- **O que faz:**
  1. Define o caminho para um arquivo de exemplo (`examples/programa_exemplo.cbl`).
  2. Chama `cae.analyze_cobol_file()` para processar o arquivo.
  3. Exibe a documentação resultante.

### Exemplo 3: Uso Avançado com a Classe `COBOLAnalyzer`

- **Função:** `exemplo_uso_avancado()`
- **Objetivo:** Demonstrar o uso da classe `COBOLAnalyzer` para ter mais controle sobre o processo.
- **O que faz:**
  1. Cria uma instância de `COBOLAnalyzer`.
  2. Usa métodos como `get_available_providers()` e `get_provider_status()` para inspecionar o ambiente.
  3. Analisa um código COBOL mais complexo.
  4. Exibe a documentação e os metadados (como tokens usados e tempo de processamento).

### Exemplo 4: Análise de Múltiplos Arquivos

- **Função:** `exemplo_multiplos_arquivos()`
- **Objetivo:** Mostrar como analisar vários arquivos COBOL em uma única chamada.
- **O que faz:**
  1. Cria uma lista de caminhos de arquivos.
  2. Se os arquivos não existirem, eles são criados para garantir que o exemplo funcione.
  3. Chama `analyzer.analyze_multiple_files()`.
  4. Exibe um resumo dos resultados e um preview da documentação de cada programa.

### Exemplo 5: Análise de Diretório

- **Função:** `exemplo_analise_diretorio()`
- **Objetivo:** Demonstrar como analisar todos os arquivos COBOL dentro de um diretório.
- **O que faz:**
  1. Especifica um diretório (`examples/`).
  2. Chama `analyzer.analyze_directory()` para encontrar e analisar todos os arquivos `.cbl` e `.cob`.
  3. Exibe um resumo dos programas encontrados e o status da análise de cada um.

### Exemplo 6: Geração de Relatório

- **Função:** `exemplo_relatorio()`
- **Objetivo:** Mostrar como gerar um relatório consolidado a partir dos resultados de múltiplas análises.
- **O que faz:**
  1. Executa a análise de um diretório para obter um conjunto de resultados.
  2. Chama `analyzer.generate_report()` duas vezes:
     - A primeira para gerar um relatório em formato **Markdown** (`relatorio_cobol.md`).
     - A segunda para gerar um relatório em formato **PDF** (`relatorio_cobol.pdf`).
  3. Exibe um preview do relatório Markdown e informa se a geração do PDF foi bem-sucedida.

### Exemplo 7: Configuração de Provedores

- **Função:** `exemplo_configuracao_provedores()`
- **Objetivo:** Demonstrar como interagir com os provedores de IA, como listar, verificar status e alternar entre eles.
- **O que faz:**
  1. Lista os provedores disponíveis usando `cae.list_providers()`.
  2. Cria um analisador e verifica o provedor atual.
  3. Tenta alternar para o provedor `openai` usando `analyzer.set_provider()`.
  4. Se a troca for bem-sucedida, tenta fazer uma análise com o novo provedor.
  5. Se falhar (por falta de credenciais), ele volta para o provedor `enhanced_mock`.

### Exemplo 8: Workflow Completo

- **Função:** `exemplo_workflow_completo()`
- **Objetivo:** Simular um fluxo de trabalho completo, combinando todos os exemplos anteriores.
- **O que faz:**
  1. Configura o ambiente.
  2. Executa análises simples e avançadas.
  3. Analisa múltiplos arquivos e um diretório inteiro.
  4. Gera relatórios em Markdown e PDF.
  5. Exibe um resumo final com os artefatos gerados.

## Guia Rápido para Notebooks

O arquivo de exemplos também contém uma função `mostrar_instrucoes_notebook()` que imprime um guia rápido formatado para ser fácil de ler em um notebook. Você pode usá-lo como uma referência rápida enquanto trabalha.

```python
import cobol_ai_engine as cae

# Exibe o guia rápido
cae.quick_start_guide()
```

Este guia cobre os casos de uso mais comuns e fornece snippets de código prontos para serem usados.

## Conclusão

Os exemplos fornecidos são um excelente ponto de partida para entender o poder e a flexibilidade do COBOL AI Engine v2.0.0. Recomendamos fortemente que você execute o `exemplo_workflow_completo()` em um notebook para ver todas as funcionalidades em ação e interagir com os resultados.

