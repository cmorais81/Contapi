#!/usr/bin/env python3
"""
Sistema de Prompts Adaptativos para Análise CADOC
Seleciona e adapta prompts baseado na complexidade e tipo de código COBOL
"""

import re
import yaml
import logging
from typing import Dict, List, Optional, Tuple
from pathlib import Path
from dataclasses import dataclass

@dataclass
class PromptRecommendation:
    """Recomendação de prompt com justificativa"""
    prompt_template: str
    analysis_type: str
    focus_areas: List[str]
    reasoning: str
    confidence: float

class AdaptivePromptManager:
    """Gerenciador de prompts adaptativos baseado na complexidade do código"""
    
    def __init__(self, config_dir: str = "config"):
        self.logger = logging.getLogger(__name__)
        self.config_dir = Path(config_dir)
        
        # Carregar prompts especializados
        self.deep_prompts = self._load_deep_prompts()
        
        # Padrões para identificação de domínios CADOC
        self.cadoc_domain_patterns = {
            "document_classification": {
                "patterns": [
                    r"CLASSIF|CATEGORIA|TIPO[-_]DOC",
                    r"DOCUMENT[-_]TYPE|DOC[-_]CLASS",
                    r"CATEGORIZ|CLASSIFY",
                    r"PATTERN[-_]MATCH|RECONHEC"
                ],
                "weight": 0.3,
                "description": "Classificação e categorização de documentos"
            },
            "workflow_approval": {
                "patterns": [
                    r"APROVACAO|APPROVAL|WORKFLOW",
                    r"STATUS[-_]DOC|ESTADO",
                    r"HIERARQUIA|ESCALACAO",
                    r"PENDING|APPROVED|REJECTED"
                ],
                "weight": 0.25,
                "description": "Workflows de aprovação e estados de documento"
            },
            "retention_archival": {
                "patterns": [
                    r"RETENCAO|RETENTION|ARQUIVO",
                    r"PURGA|DESTRUICAO|DELETE",
                    r"MIGRACAO|MIGRATION|NIVEL",
                    r"PRAZO|DEADLINE|EXPIR"
                ],
                "weight": 0.25,
                "description": "Retenção, arquivamento e ciclo de vida"
            },
            "quality_control": {
                "patterns": [
                    r"QUALIDADE|QUALITY|VALIDACAO",
                    r"CONTROLE|CONTROL|CHECK",
                    r"REJEICAO|REJECT|ERROR",
                    r"CONFORMIDADE|COMPLIANCE"
                ],
                "weight": 0.2,
                "description": "Controle de qualidade e validação"
            },
            "audit_security": {
                "patterns": [
                    r"AUDITORIA|AUDIT|LOG",
                    r"SEGURANCA|SECURITY|CRIPTOGRAF",
                    r"RASTREAB|TRACK|TRAIL",
                    r"INTEGRIDADE|INTEGRITY"
                ],
                "weight": 0.15,
                "description": "Auditoria, segurança e rastreabilidade"
            },
            "integration_systems": {
                "patterns": [
                    r"INTEGRAC|INTERFACE|API",
                    r"REPOSITORIO|REPOSITORY",
                    r"CORE[-_]BANKING|MAINFRAME",
                    r"SYNC|TRANSFER|EXCHANGE"
                ],
                "weight": 0.15,
                "description": "Integrações e interfaces sistêmicas"
            }
        }
        
        # Padrões de complexidade técnica
        self.technical_complexity_patterns = {
            "high_complexity": {
                "patterns": [
                    r"EXEC\s+SQL.*END-EXEC",  # SQL embebido
                    r"CALL\s+['\"][\w-]+['\"].*USING",  # Chamadas complexas
                    r"EVALUATE.*WHEN.*WHEN.*WHEN",  # Múltiplas condições
                    r"SEARCH\s+ALL.*VARYING",  # Busca binária
                    r"SORT.*USING.*GIVING",  # Ordenação complexa
                    r"PERFORM.*UNTIL.*VARYING",  # Loops aninhados
                ],
                "weight": 0.4,
                "min_occurrences": 2
            },
            "medium_complexity": {
                "patterns": [
                    r"IF.*THEN.*ELSE.*END-IF",  # Condicionais estruturadas
                    r"STRING.*DELIMITED.*INTO",  # Manipulação de strings
                    r"COMPUTE.*=.*[\+\-\*/]",  # Cálculos
                    r"REDEFINES|OCCURS.*TIMES",  # Estruturas de dados
                ],
                "weight": 0.3,
                "min_occurrences": 3
            },
            "low_complexity": {
                "patterns": [
                    r"MOVE.*TO",  # Movimentações simples
                    r"DISPLAY|ACCEPT",  # I/O básico
                    r"OPEN|CLOSE|READ|WRITE",  # Operações de arquivo
                ],
                "weight": 0.1,
                "min_occurrences": 5
            }
        }
    
    def _load_deep_prompts(self) -> Dict:
        """Carrega prompts especializados para análise profunda"""
        try:
            prompts_file = self.config_dir / "prompts_cadoc_deep_analysis.yaml"
            if prompts_file.exists():
                with open(prompts_file, 'r', encoding='utf-8') as f:
                    return yaml.safe_load(f)
            else:
                self.logger.warning(f"Arquivo de prompts profundos não encontrado: {prompts_file}")
                return {}
        except Exception as e:
            self.logger.error(f"Erro ao carregar prompts profundos: {e}")
            return {}
    
    def analyze_code_domain(self, cobol_code: str) -> Dict[str, float]:
        """Analisa o domínio CADOC do código"""
        domain_scores = {}
        
        for domain, config in self.cadoc_domain_patterns.items():
            score = 0.0
            total_matches = 0
            
            for pattern in config["patterns"]:
                matches = len(re.findall(pattern, cobol_code, re.IGNORECASE))
                total_matches += matches
            
            # Normalizar por tamanho do código
            code_lines = len(cobol_code.split('\n'))
            normalized_score = (total_matches / max(code_lines, 1)) * config["weight"]
            
            domain_scores[domain] = min(normalized_score, 1.0)
        
        return domain_scores
    
    def analyze_technical_complexity(self, cobol_code: str) -> Tuple[str, float]:
        """Analisa a complexidade técnica do código"""
        complexity_scores = {}
        
        for level, config in self.technical_complexity_patterns.items():
            total_matches = 0
            
            for pattern in config["patterns"]:
                matches = len(re.findall(pattern, cobol_code, re.IGNORECASE | re.DOTALL))
                total_matches += matches
            
            # Verificar se atende o mínimo de ocorrências
            if total_matches >= config["min_occurrences"]:
                complexity_scores[level] = total_matches * config["weight"]
            else:
                complexity_scores[level] = 0.0
        
        # Determinar nível de complexidade dominante
        if complexity_scores["high_complexity"] > 0.5:
            return "high_complexity", complexity_scores["high_complexity"]
        elif complexity_scores["medium_complexity"] > 0.3:
            return "medium_complexity", complexity_scores["medium_complexity"]
        else:
            return "low_complexity", complexity_scores["low_complexity"]
    
    def select_optimal_prompt(self, cobol_code: str, model_name: str) -> PromptRecommendation:
        """Seleciona o prompt ótimo baseado no código e modelo"""
        
        # Analisar domínio CADOC
        domain_scores = self.analyze_code_domain(cobol_code)
        primary_domain = max(domain_scores.items(), key=lambda x: x[1])
        
        # Analisar complexidade técnica
        complexity_level, complexity_score = self.analyze_technical_complexity(cobol_code)
        
        # Selecionar prompt baseado no modelo e análise
        prompt_template = self._get_prompt_for_model_and_domain(
            model_name, primary_domain[0], complexity_level
        )
        
        # Determinar áreas de foco
        focus_areas = self._get_focus_areas(domain_scores, complexity_level)
        
        # Gerar justificativa
        reasoning = self._generate_prompt_reasoning(
            primary_domain, complexity_level, complexity_score, model_name
        )
        
        # Calcular confiança
        confidence = self._calculate_confidence(domain_scores, complexity_score)
        
        return PromptRecommendation(
            prompt_template=prompt_template,
            analysis_type=f"{primary_domain[0]}_{complexity_level}",
            focus_areas=focus_areas,
            reasoning=reasoning,
            confidence=confidence
        )
    
    def _get_prompt_for_model_and_domain(self, model_name: str, domain: str, complexity: str) -> str:
        """Obtém prompt específico para modelo, domínio e complexidade"""
        
        # Tentar prompt específico do modelo
        if model_name in self.deep_prompts.get("deep_analysis_prompts", {}):
            model_prompt = self.deep_prompts["deep_analysis_prompts"][model_name]
            base_prompt = model_prompt.get("system_prompt", "")
            
            # Adicionar foco específico se disponível
            if "analysis_focus" in model_prompt:
                base_prompt += "\n\n" + model_prompt["analysis_focus"]
        else:
            # Usar prompt genérico profundo
            base_prompt = self.deep_prompts.get("system_prompt_deep_cadoc", "")
        
        # Adicionar template específico do domínio se disponível
        domain_templates = self.deep_prompts.get("domain_analysis_templates", {})
        if domain in domain_templates:
            domain_prompt = domain_templates[domain].get("prompt", "")
            base_prompt += "\n\n" + domain_prompt
        
        # Adicionar configuração de complexidade
        complexity_config = self.deep_prompts.get("complexity_analysis", {})
        if complexity in complexity_config:
            complexity_areas = complexity_config[complexity].get("focus_areas", [])
            if complexity_areas:
                base_prompt += f"\n\nFOCO ESPECÍFICO PARA {complexity.upper()}:\n"
                for area in complexity_areas:
                    base_prompt += f"- {area}\n"
        
        return base_prompt
    
    def _get_focus_areas(self, domain_scores: Dict[str, float], complexity: str) -> List[str]:
        """Determina áreas de foco baseado na análise"""
        focus_areas = []
        
        # Adicionar domínios com score significativo
        for domain, score in domain_scores.items():
            if score > 0.1:  # Threshold mínimo
                domain_info = self.cadoc_domain_patterns[domain]
                focus_areas.append(domain_info["description"])
        
        # Adicionar foco de complexidade
        complexity_config = self.deep_prompts.get("complexity_analysis", {})
        if complexity in complexity_config:
            complexity_areas = complexity_config[complexity].get("focus_areas", [])
            focus_areas.extend(complexity_areas)
        
        return focus_areas
    
    def _generate_prompt_reasoning(self, primary_domain: Tuple[str, float], 
                                 complexity_level: str, complexity_score: float, 
                                 model_name: str) -> str:
        """Gera justificativa para seleção do prompt"""
        
        domain_name, domain_score = primary_domain
        domain_desc = self.cadoc_domain_patterns[domain_name]["description"]
        
        reasoning_parts = [
            f"Domínio principal identificado: {domain_desc} (score: {domain_score:.3f})",
            f"Complexidade técnica: {complexity_level} (score: {complexity_score:.3f})",
            f"Modelo selecionado: {model_name}",
            f"Prompt adaptado para análise especializada em {domain_name}"
        ]
        
        return " | ".join(reasoning_parts)
    
    def _calculate_confidence(self, domain_scores: Dict[str, float], 
                            complexity_score: float) -> float:
        """Calcula confiança na seleção do prompt"""
        
        # Confiança baseada no score do domínio principal
        max_domain_score = max(domain_scores.values()) if domain_scores else 0.0
        
        # Confiança baseada na complexidade
        complexity_confidence = min(complexity_score, 1.0)
        
        # Confiança combinada
        combined_confidence = (max_domain_score * 0.6) + (complexity_confidence * 0.4)
        
        return min(combined_confidence, 1.0)
    
    def get_domain_analysis_summary(self, cobol_code: str) -> Dict:
        """Retorna resumo da análise de domínio"""
        
        domain_scores = self.analyze_code_domain(cobol_code)
        complexity_level, complexity_score = self.analyze_technical_complexity(cobol_code)
        
        return {
            "domain_scores": domain_scores,
            "primary_domain": max(domain_scores.items(), key=lambda x: x[1]) if domain_scores else ("unknown", 0.0),
            "complexity_level": complexity_level,
            "complexity_score": complexity_score,
            "recommended_analysis_type": f"{max(domain_scores.items(), key=lambda x: x[1])[0]}_{complexity_level}" if domain_scores else "generic_analysis"
        }
    
    def generate_adaptive_prompt(self, cobol_code: str, model_name: str, 
                               rag_context: str = "") -> str:
        """Gera prompt adaptativo completo"""
        
        recommendation = self.select_optimal_prompt(cobol_code, model_name)
        
        # Substituir contexto RAG no template
        adaptive_prompt = recommendation.prompt_template.replace("{rag_context}", rag_context)
        
        # Adicionar instruções específicas baseadas nas áreas de foco
        if recommendation.focus_areas:
            adaptive_prompt += "\n\nÁREAS DE FOCO IDENTIFICADAS:\n"
            for area in recommendation.focus_areas:
                adaptive_prompt += f"- {area}\n"
        
        # Adicionar instruções de saída estruturada
        output_structure = self.deep_prompts.get("output_structure_deep", {})
        if output_structure and "sections" in output_structure:
            adaptive_prompt += "\n\nESTRUTURA DE SAÍDA OBRIGATÓRIA:\n"
            for section in output_structure["sections"]:
                adaptive_prompt += f"\n## {section['title']}\n"
                adaptive_prompt += f"Foco: {section['focus']}\n"
        
        return adaptive_prompt

def create_adaptive_prompt_manager(config_dir: str = "config") -> AdaptivePromptManager:
    """Factory function para criar o gerenciador de prompts adaptativos"""
    return AdaptivePromptManager(config_dir)

# Exemplo de uso
if __name__ == "__main__":
    manager = create_adaptive_prompt_manager()
    
    # Código de exemplo
    sample_code = """
    IDENTIFICATION DIVISION.
    PROGRAM-ID. CADOC-CLASSIFIER.
    
    DATA DIVISION.
    WORKING-STORAGE SECTION.
    01 WS-DOCUMENT-REC.
       05 WS-DOC-ID        PIC X(20).
       05 WS-DOC-TYPE      PIC X(10).
       05 WS-DOC-STATUS    PIC X(02).
       05 WS-QUALITY-SCORE PIC 9(03)V99.
    
    PROCEDURE DIVISION.
    MAIN-PROCESS.
        PERFORM CLASSIFY-DOCUMENTS
        UNTIL WS-EOF = 'Y'.
        
    CLASSIFY-DOCUMENTS.
        EVALUATE WS-DOC-TYPE
            WHEN 'CHEQUE'
                PERFORM VALIDATE-CHEQUE-QUALITY
                IF WS-QUALITY-SCORE > 85.00
                    MOVE 'APPROVED' TO WS-DOC-STATUS
                ELSE
                    MOVE 'REJECTED' TO WS-DOC-STATUS
                END-IF
            WHEN 'CONTRATO'
                PERFORM VALIDATE-CONTRACT-COMPLIANCE
                PERFORM CHECK-APPROVAL-WORKFLOW
            WHEN OTHER
                PERFORM GENERIC-CLASSIFICATION
        END-EVALUATE.
        
        PERFORM AUDIT-LOG-ENTRY.
    """
    
    # Analisar domínio
    summary = manager.get_domain_analysis_summary(sample_code)
    print("Análise de Domínio:")
    print(f"  Domínio principal: {summary['primary_domain']}")
    print(f"  Complexidade: {summary['complexity_level']}")
    print(f"  Tipo de análise recomendado: {summary['recommended_analysis_type']}")
    
    # Gerar prompt adaptativo
    recommendation = manager.select_optimal_prompt(sample_code, "aws_claude_3_5_sonnet")
    print(f"\nRecomendação de Prompt:")
    print(f"  Tipo de análise: {recommendation.analysis_type}")
    print(f"  Confiança: {recommendation.confidence:.1%}")
    print(f"  Justificativa: {recommendation.reasoning}")
    print(f"  Áreas de foco: {recommendation.focus_areas}")
