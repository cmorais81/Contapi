# Guia de Referência Rápida - COBOL Analyzer v3.1.0

## Comandos Essenciais

### Instalação
```bash
tar -xzf SBR_THPF_COBOL_TO_DOCS_v3.1.0_FINAL.tar.gz
cd sbr-thpf-cobol-to-docs/
pip install -r requirements.txt
pip install .
```

### Inicialização de Projeto
```bash
mkdir meu_projeto && cd meu_projeto
python /caminho/para/cobol_to_docs/runner/cobol_to_docs_simple.py --init
```

### Verificação do Sistema
```bash
python /caminho/para/cobol_to_docs/runner/main.py --status
```

## Análises Básicas

### Análise Simples
```bash
python /caminho/para/cobol_to_docs/runner/main.py \
  --fontes programas.txt \
  --models enhanced_mock
```

### Análise com Copybooks
```bash
python /caminho/para/cobol_to_docs/runner/main.py \
  --fontes programas.txt \
  --books copybooks.txt \
  --models luzia
```

### Análise de Programa Individual
```bash
python /caminho/para/cobol_to_docs/runner/main.py \
  --fontes programa.cbl \
  --models enhanced_mock
```

## Análises Avançadas

### Análise Consolidada
```bash
python /caminho/para/cobol_to_docs/runner/main.py \
  --fontes programas.txt \
  --consolidado \
  --models luzia
```

### Análise Especializada
```bash
python /caminho/para/cobol_to_docs/runner/main.py \
  --fontes programas.txt \
  --analise-especialista \
  --models luzia
```

### Análise para Modernização
```bash
python /caminho/para/cobol_to_docs/runner/main.py \
  --fontes programas.txt \
  --modernizacao \
  --models luzia
```

### Geração de PDF
```bash
python /caminho/para/cobol_to_docs/runner/main.py \
  --fontes programas.txt \
  --pdf \
  --models luzia
```

## Configuração de Provedores

### Luzia (Santander)
```bash
export LUZIA_CLIENT_ID="seu_client_id"
export LUZIA_CLIENT_SECRET="seu_client_secret"
```

### GitHub Copilot
```bash
export GITHUB_TOKEN="seu_github_token"
```

### OpenAI
```bash
export OPENAI_API_KEY="sua_api_key"
```

### AWS Bedrock
```bash
export AWS_ACCESS_KEY_ID="sua_access_key"
export AWS_SECRET_ACCESS_KEY="sua_secret_key"
export AWS_REGION="us-east-1"
```

## Modelos Disponíveis

| Modelo | Comando | Uso Recomendado |
|--------|---------|-----------------|
| enhanced_mock | `--models enhanced_mock` | Desenvolvimento e testes |
| luzia | `--models luzia` | Produção (Santander) |
| github_copilot | `--models github_copilot` | Análises rápidas |
| openai | `--models openai` | Análises detalhadas |
| bedrock | `--models bedrock` | Infraestrutura AWS |

## Estrutura de Arquivos

### Entrada
```
meu_projeto/
├── programas.txt        # Lista de programas COBOL
├── copybooks.txt        # Lista de copybooks (opcional)
└── programa.cbl         # Programa individual
```

### Saída
```
meu_projeto/
├── output/
│   ├── PROGRAMA_analise_funcional.md
│   ├── ai_requests/
│   ├── ai_responses/
│   └── relatorio_custos.txt
└── logs/
    ├── cobol_to_docs_*.log
    ├── rag_session_report_*.txt
    └── rag_detailed_log_*.json
```

## Opções Principais

### Argumentos Obrigatórios
- `--fontes ARQUIVO` - Lista de programas COBOL
- `--models MODELO` - Modelo de IA a usar

### Argumentos Opcionais
- `--books ARQUIVO` - Lista de copybooks
- `--output DIRETORIO` - Diretório de saída
- `--consolidado` - Análise consolidada
- `--analise-especialista` - Análise especializada
- `--modernizacao` - Análise para modernização
- `--pdf` - Gerar PDF
- `--log-level NIVEL` - Nível de logging

## Solução Rápida de Problemas

### Erro de Credenciais
```bash
# Use enhanced_mock para testes
--models enhanced_mock
```

### Erro de Importação
```bash
pip install . --force-reinstall
```

### Erro de Arquivo Não Encontrado
```bash
# Use caminhos absolutos
--fontes /caminho/completo/programas.txt
```

### Logs Detalhados
```bash
--log-level DEBUG
```

## Testes

### Executar Todos os Testes
```bash
python -m pytest cobol_to_docs/tests/ -v
```

### Testar Componente Específico
```bash
python -m pytest cobol_to_docs/tests/test_cobol_parser.py -v
```

## Exemplos Práticos

### Análise de Exemplo Incluído
```bash
python /caminho/para/cobol_to_docs/runner/main.py \
  --fontes examples/fontes.txt \
  --models enhanced_mock
```

### Análise com Múltiplos Modelos
```bash
python /caminho/para/cobol_to_docs/runner/main.py \
  --fontes programas.txt \
  --models '["luzia", "github_copilot"]'
```

### Análise com Saída Personalizada
```bash
python /caminho/para/cobol_to_docs/runner/main.py \
  --fontes programas.txt \
  --output minha_analise \
  --models luzia
```

## Códigos de Saída

| Código | Significado |
|--------|-------------|
| 0 | Sucesso |
| 1 | Erro geral |
| 2 | Erro de configuração |
| 3 | Arquivo não encontrado |
| 4 | Erro de credenciais |
| 5 | Erro de rede |

## Arquivos de Configuração

### Principal
- `config/config.yaml` - Configuração geral

### Prompts
- `config/prompts_enhanced.yaml` - Prompts gerais
- `config/prompts_especialista.yaml` - Prompts especializados

### Dados
- `data/cobol_knowledge_base.json` - Base de conhecimento
- `data/cobol_embeddings.pkl` - Cache de embeddings

## Limites Importantes

- Tamanho máximo por programa: 10MB
- Máximo de programas por análise: 100
- Timeout por requisição: 300 segundos
- Tokens máximos por requisição: 32,000

## Suporte

### Documentação Completa
- `MANUAL_USUARIO_COMPLETO.md` - Manual detalhado
- `INSTALACAO_E_USO.md` - Guia de instalação
- `README.md` - Visão geral

### Exemplos
- `examples/` - Programas e copybooks exemplo
- `examples/INICIO_RAPIDO.md` - Tutorial básico

---

**COBOL Analyzer v3.1.0**  
Guia de Referência Rápida  
Outubro 2025
