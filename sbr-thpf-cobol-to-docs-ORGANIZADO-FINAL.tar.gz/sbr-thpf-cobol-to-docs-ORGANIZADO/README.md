# COBOL Analyzer v3.1.0

Sistema profissional de análise e documentação automatizada de programas COBOL utilizando Inteligência Artificial.

## Visão Geral

O COBOL Analyzer automatiza a análise de código COBOL legado, gerando documentação técnica detalhada através de múltiplos provedores de IA, incluindo sistema RAG inteligente para aprendizado contínuo.

## Estrutura do Projeto

```
sbr-thpf-cobol-to-docs/
├── .editorconfig          # Configuração do editor
├── .gitignore            # Arquivos ignorados pelo Git
├── catalog.properties    # Propriedades do catálogo
├── CHANGELOG.md          # Histórico de mudanças
├── LICENSE              # Licença do projeto
├── Pipfile              # Dependências Pipenv
├── Pipfile.lock         # Lock das dependências
├── pytest.ini           # Configuração de testes
├── README.md            # Esta documentação
├── requirements.txt     # Dependências pip
├── setup.py             # Configuração de instalação
└── cobol_to_docs/       # Aplicação principal
    ├── config/          # Configurações e prompts
    ├── data/            # Base de conhecimento RAG
    ├── examples/        # Exemplos e tutoriais
    ├── runner/          # Scripts de execução
    ├── src/             # Código fonte modular
    └── tests/           # Testes unitários
```

## Características Principais

### Análise Inteligente
- Análise automatizada de programas COBOL e copybooks
- Identificação de regras de negócio e fluxos de processamento
- Mapeamento de estruturas de dados e arquivos
- Detecção de padrões e dependências

### Sistema RAG Avançado
- Base de conhecimento especializada em COBOL
- Enriquecimento de contexto automático
- Aprendizado contínuo e cache inteligente
- 48 itens de conhecimento pré-carregados

### Múltiplos Provedores de IA
- **Luzia** (Santander) - aws-claude-3-5-sonnet
- **GitHub Copilot** - gpt-4o
- **OpenAI** - gpt-4, gpt-4-turbo
- **AWS Bedrock** - Claude, Titan
- **Enhanced Mock** - Para desenvolvimento e testes

### Geração de Documentação
- Análise funcional detalhada em Markdown
- Relatórios de custos e performance
- Logs detalhados de operações RAG
- Exportação para PDF (opcional)

## Instalação

### Pré-requisitos
- Python 3.8 ou superior
- pip ou pipenv
- 2GB de espaço em disco
- Conexão com internet

### Instalação via pip
```bash
# Extrair o pacote
tar -xzf SBR_THPF_COBOL_TO_DOCS_v3.1.0_FINAL.tar.gz
cd sbr-thpf-cobol-to-docs/

# Instalar dependências e o pacote
pip install -r requirements.txt
pip install .
```

### Instalação via Pipenv (Recomendado)
```bash
# Extrair o pacote
tar -xzf SBR_THPF_COBOL_TO_DOCS_v3.1.0_FINAL.tar.gz
cd sbr-thpf-cobol-to-docs/

# Instalar com Pipenv
pipenv install
pipenv shell
```

## Inicialização de Projeto

### Comando de Inicialização
Para usar o COBOL Analyzer em qualquer pasta:

```bash
# Criar e entrar em sua pasta de projeto
mkdir meu_projeto_cobol
cd meu_projeto_cobol

# Inicializar projeto (copia todos os arquivos necessários)
python /caminho/para/cobol_to_docs/runner/cobol_to_docs_simple.py --init
```

### Arquivos Copiados Automaticamente
O comando `--init` copia automaticamente:
- **config/** - 8 arquivos de configuração e prompts
- **data/** - 7+ arquivos da base de conhecimento RAG
- **examples/** - 13 arquivos de exemplos e tutoriais
- **Diretórios de trabalho** - logs/, output/, temp/
- **Template** - fontes_exemplo.txt

## Uso Básico

### Verificar Status do Sistema
```bash
python /caminho/para/cobol_to_docs/runner/main.py --status
```

### Análise de Programas COBOL

#### Análise Básica
```bash
# Usar exemplos incluídos
python /caminho/para/cobol_to_docs/runner/main.py --fontes examples/fontes.txt --models enhanced_mock
```

#### Análise com Copybooks
```bash
python /caminho/para/cobol_to_docs/runner/main.py --fontes programas.txt --books copybooks.txt --models luzia
```

#### Análise de Programa Individual
```bash
python /caminho/para/cobol_to_docs/runner/main.py --fontes examples/programa_exemplo.cbl --models enhanced_mock
```

## Configuração de Provedores

### Luzia (Santander - Recomendado)
```bash
export LUZIA_CLIENT_ID="seu_client_id"
export LUZIA_CLIENT_SECRET="seu_client_secret"
```

### GitHub Copilot
```bash
export GITHUB_TOKEN="seu_github_token"
```

### OpenAI
```bash
export OPENAI_API_KEY="sua_api_key"
```

### AWS Bedrock
```bash
export AWS_ACCESS_KEY_ID="sua_access_key"
export AWS_SECRET_ACCESS_KEY="sua_secret_key"
export AWS_REGION="us-east-1"
```

## Funcionalidades Avançadas

### Tipos de Análise

#### Análise Consolidada
```bash
python /caminho/para/cobol_to_docs/runner/main.py --fontes programas.txt --consolidado --models luzia
```

#### Análise Especializada
```bash
python /caminho/para/cobol_to_docs/runner/main.py --fontes programas.txt --analise-especialista --models luzia
```

#### Análise para Modernização
```bash
python /caminho/para/cobol_to_docs/runner/main.py --fontes programas.txt --modernizacao --models luzia
```

#### Geração de PDF
```bash
python /caminho/para/cobol_to_docs/runner/main.py --fontes programas.txt --pdf --models luzia
```

## Sistema RAG

### Funcionalidades
- Base de conhecimento COBOL especializada
- Enriquecimento automático de contexto
- Cache inteligente de embeddings
- Logs detalhados de operações

### Estatísticas
- 48 itens na base de conhecimento
- 142 embeddings pré-calculados
- Suporte a múltiplos formatos de entrada
- Sistema de aprendizado automático

## Arquivos de Saída

### Documentação Gerada
- `output/PROGRAMA_analise_funcional.md` - Análise de cada programa
- `output/relatorio_custos.txt` - Relatório de custos e tokens
- `output/ai_requests/` - Requisições enviadas para IA
- `output/ai_responses/` - Respostas recebidas da IA

### Logs do Sistema
- `logs/cobol_to_docs_*.log` - Logs principais da aplicação
- `logs/rag_session_report_*.txt` - Relatórios de sessões RAG
- `logs/rag_detailed_log_*.json` - Logs detalhados do sistema RAG
- `logs/rag_operations_*.log` - Operações do sistema RAG

## Desenvolvimento

### Testes Unitários
```bash
python -m pytest cobol_to_docs/tests/ -v
```

### Estrutura Modular
- **analyzers/** - Analisadores COBOL
- **providers/** - Provedores de IA
- **parsers/** - Parsers de código
- **generators/** - Geradores de documentação
- **rag/** - Sistema RAG
- **utils/** - Utilitários

## Exemplos Incluídos

### Programas COBOL
- `examples/programa_exemplo.cbl` - Programa básico de cálculo de juros
- `examples/SISTEMA_LH.cbl` - Sistema completo de processamento
- `examples/fontes.txt` - Lista de 5 programas para análise

### Copybooks
- `examples/copybook_cliente.cpy` - Estrutura de dados de cliente
- `examples/copybook_conta.cpy` - Estrutura de dados de conta
- `examples/copybook_transacao.cpy` - Estrutura de dados de transação

### Documentação
- `examples/INICIO_RAPIDO.md` - Guia de início rápido
- `examples/COBOL_to_Docs_Tutorial.ipynb` - Tutorial interativo Jupyter
- `examples/README.md` - Documentação dos exemplos

## Dependências Principais

### Core
- pyyaml >= 6.0 - Configuração YAML
- requests >= 2.28.0 - Requisições HTTP
- jinja2 >= 3.0.0 - Templates

### IA e RAG
- scikit-learn >= 1.0.0 - Machine Learning
- numpy >= 1.21.0 - Computação numérica
- sentence-transformers >= 2.2.0 - Embeddings
- openai >= 1.0.0 - API OpenAI

### Documentação
- markdown >= 3.3.0 - Processamento Markdown
- weasyprint >= 54.0 - Geração PDF
- reportlab >= 3.6.0 - Relatórios PDF

### Análise de Dados
- pandas >= 1.3.0 - Manipulação de dados
- openpyxl >= 3.0.0 - Planilhas Excel

## Solução de Problemas

### Problemas Comuns

#### Erro de Credenciais
```
Erro: Failed to resolve 'login.azure.paas.santanderbr.pre.corp'
```
**Solução**: Configure as credenciais do provedor ou use `enhanced_mock` para testes.

#### Erro de Configuração
```
Erro: Modelo gpt-4 não está configurado no sistema
```
**Solução**: Configure a API key do provedor ou use um modelo disponível.

#### Erro de Importação
```
ModuleNotFoundError: No module named 'cobol_to_docs'
```
**Solução**: Reinstale o pacote com `pip install .` no diretório do projeto.

### Logs de Diagnóstico
Para diagnóstico detalhado:
```bash
python /caminho/para/cobol_to_docs/runner/main.py --log-level DEBUG --fontes programas.txt --models enhanced_mock
```

## Licença

Este projeto está licenciado sob a licença MIT. Consulte o arquivo `LICENSE` para mais detalhes.

## Suporte

Para suporte técnico e documentação adicional:
- Consulte `INSTALACAO_E_USO.md` para guia detalhado de instalação
- Veja `examples/` para exemplos práticos de uso
- Execute testes com `pytest cobol_to_docs/tests/` para validação

## Changelog

Consulte `CHANGELOG.md` para histórico completo de mudanças e atualizações da versão.

---

**COBOL Analyzer v3.1.0**  
Ferramenta profissional para análise de código COBOL com IA  
Desenvolvido pela equipe COBOL Analyzer - Outubro 2025
