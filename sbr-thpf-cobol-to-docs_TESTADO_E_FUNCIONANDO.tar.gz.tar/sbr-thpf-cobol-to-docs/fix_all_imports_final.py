import os
import re

def fix_imports_in_file(file_path):
    with open(file_path, 'r') as f:
        content = f.read()
    
    # Get the directory structure to understand proper imports
    rel_path = os.path.relpath(file_path, 'src')
    dir_parts = os.path.dirname(rel_path).split(os.sep) if os.path.dirname(rel_path) != '.' else []
    
    lines = content.split('\n')
    fixed_lines = []
    
    for line in lines:
        if line.strip().startswith('from ') and ' import ' in line:
            # Skip already correct imports
            if any(line.startswith(f'from {module}.') for module in ['core', 'providers', 'analyzers', 'generators', 'parsers', 'utils', 'rag', 'reports', 'templates', 'prompts']):
                fixed_lines.append(line)
                continue
            
            # Fix imports that need module prefixes
            match = re.match(r'from ([a-zA-Z_][a-zA-Z0-9_]*) import', line)
            if match:
                module = match.group(1)
                
                # Check if this module exists in known directories
                possible_modules = ['core', 'providers', 'analyzers', 'generators', 'parsers', 'utils', 'rag', 'reports', 'templates', 'prompts']
                
                for mod_dir in possible_modules:
                    module_file = f'src/{mod_dir}/{module}.py'
                    if os.path.exists(module_file):
                        line = line.replace(f'from {module} import', f'from {mod_dir}.{module} import')
                        break
        
        fixed_lines.append(line)
    
    content = '\n'.join(fixed_lines)
    
    with open(file_path, 'w') as f:
        f.write(content)
    print(f"Fixed imports in {file_path}")

# Fix all Python files in src
for root, dirs, files in os.walk('src'):
    for file in files:
        if file.endswith('.py'):
            file_path = os.path.join(root, file)
            fix_imports_in_file(file_path)

print("All imports fixed!")
