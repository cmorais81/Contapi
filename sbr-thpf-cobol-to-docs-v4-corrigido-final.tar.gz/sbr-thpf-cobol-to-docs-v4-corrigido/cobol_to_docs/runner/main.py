#!/usr/bin/env python3
"""
COBOL to Docs - Main Runner
Sistema de análise de programas COBOL com IA
"""

import argparse
import os
import logging
import json
import datetime
import sys
from pathlib import Path

# Adicionar o diretório raiz do projeto ao sys.path
current_dir = Path(__file__).resolve().parent
project_root = current_dir.parent.parent  # sbr-thpf-cobol-to-docs-v4-corrigido
sys.path.insert(0, str(project_root))

# Imports diretos dos módulos
sys.path.insert(0, str(current_dir.parent / "src"))

from core.config import ConfigManager
from core.enhanced_prompt_manager import EnhancedPromptManager
from providers.provider_manager import ProviderManager
from parsers.cobol_parser import COBOLParser
from utils.enhanced_response_formatter import EnhancedResponseFormatter

# Configurar logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def create_output_structure(base_output_dir: str, analysis_name: str, model_display_name: str):
    """
    Cria a estrutura de diretórios para a saída, seguindo o padrão:
    output_dir/analysis_name/model_display_name/
    """
    model_output_dir = Path(base_output_dir) / analysis_name / model_display_name
    model_output_dir.mkdir(parents=True, exist_ok=True)
    
    # Pastas ai_requests e ai_responses dentro da pasta do modelo
    (model_output_dir / "ai_requests").mkdir(parents=True, exist_ok=True)
    (model_output_dir / "ai_responses").mkdir(parents=True, exist_ok=True)
    
    return model_output_dir

def load_html_template():
    """
    Carrega o template HTML profissional
    """
    template_path = Path(__file__).parent.parent / "templates" / "report_template.html"
    if template_path.exists():
        with open(template_path, 'r', encoding='utf-8') as f:
            return f.read()
    else:
        # Template HTML básico como fallback
        return """
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Análise COBOL - {{program_name}}</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 0; padding: 20px; background-color: #f5f5f5; }
        .container { max-width: 1200px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .header { border-bottom: 3px solid #2c3e50; padding-bottom: 20px; margin-bottom: 30px; }
        .header h1 { color: #2c3e50; margin: 0; font-size: 2.5em; }
        .header .meta { color: #7f8c8d; margin-top: 10px; }
        .content { line-height: 1.6; color: #2c3e50; }
        .content h2 { color: #3498db; border-left: 4px solid #3498db; padding-left: 15px; }
        .content h3 { color: #e74c3c; }
        .content pre { background: #ecf0f1; padding: 15px; border-radius: 5px; overflow-x: auto; }
        .content code { background: #ecf0f1; padding: 2px 5px; border-radius: 3px; }
        .footer { margin-top: 40px; padding-top: 20px; border-top: 1px solid #bdc3c7; text-align: center; color: #7f8c8d; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Análise Funcional - {{program_name}}</h1>
            <div class="meta">
                <strong>Modelo:</strong> {{model_name}} | 
                <strong>Data:</strong> {{timestamp}}
            </div>
        </div>
        <div class="content">
            {{analysis_content}}
        </div>
        <div class="footer">
            <p>Relatório gerado automaticamente pelo COBOL Analyzer</p>
        </div>
    </div>
</body>
</html>
        """

def render_html_template(template_content, program_name, model_name, timestamp, analysis_content):
    """
    Renderiza o template HTML com os dados fornecidos
    """
    return template_content.replace('{{program_name}}', program_name) \
                          .replace('{{model_name}}', model_name) \
                          .replace('{{timestamp}}', timestamp) \
                          .replace('{{analysis_content}}', analysis_content)

def main():
    parser = argparse.ArgumentParser(description="Processa programas COBOL para gerar documentação.")
    parser.add_argument("--fontes", required=True, help="Caminho para o arquivo fontes.txt")
    parser.add_argument("--books", required=True, help="Caminho para o arquivo BOOKS.txt")
    parser.add_argument("--output", default="output", help="Diretório de saída para os resultados")
    parser.add_argument("--analysis-name", default="analise_geral", help="Nome da pasta intermediária para a análise")
    parser.add_argument("--html", action="store_true", help="Gera saída em formato HTML")
    parser.add_argument("--config-dir", help="Diretório contendo config.yaml")
    parser.add_argument("--prompts-yaml", help="Caminho para um arquivo prompts.yaml customizado")

    args = parser.parse_args()

    logger.info("=== COBOL TO DOCS - INICIANDO PROCESSAMENTO ===")
    logger.info(f"Fontes: {args.fontes}")
    logger.info(f"Books: {args.books}")
    logger.info(f"Output: {args.output}")
    logger.info(f"Analysis name: {args.analysis_name}")
    logger.info(f"HTML: {args.html}")
    logger.info(f"Config dir: {args.config_dir}")
    logger.info(f"Prompts YAML: {args.prompts_yaml}")

    # Inicializar ConfigManager com caminhos personalizados
    try:
        config_manager = ConfigManager(config_dir=args.config_dir, prompts_file=args.prompts_yaml)
        config = config_manager.get_config()
        prompt_config = config_manager.get_prompt_config()

        logger.info(f"Config carregado: {bool(config)}")
        logger.info(f"Prompt config carregado: {bool(prompt_config)}")
        
        if prompt_config:
            logger.info(f"Arquivo de prompts: {prompt_config.get('yaml_file', 'N/A')}")
            logger.info(f"Tamanho do prompt: {len(prompt_config.get('full_prompt', ''))} caracteres")
            
            # Verificar conteúdo BIAN
            full_prompt = prompt_config.get('full_prompt', '')
            bian_count = full_prompt.lower().count('bian')
            logger.info(f"Referências BIAN no prompt: {bian_count}")

        if not prompt_config:
            logger.error("Nenhum prompt YAML válido foi carregado. Certifique-se de que prompts.yaml existe e está bem formatado.")
            return

    except Exception as e:
        logger.error(f"Erro ao inicializar ConfigManager: {e}")
        return

    # Inicializar ProviderManager
    try:
        provider_manager = ProviderManager(config)
        logger.info("ProviderManager inicializado com sucesso")
    except Exception as e:
        logger.error(f"Erro ao inicializar ProviderManager: {e}")
        return

    # Carregar e parsear programas COBOL
    try:
        cobol_parser = COBOLParser()
        
        # Ler a lista de arquivos COBOL do fontes.txt
        cobol_file_paths = []
        with open(args.fontes, 'r', encoding='utf-8') as f:
            for line in f:
                file_name = line.strip()
                if file_name:
                    # Assumindo que os arquivos COBOL estão no mesmo diretório do fontes.txt
                    file_path = os.path.join(os.path.dirname(args.fontes), file_name)
                    cobol_file_paths.append(file_path)

        programs_data = {}
        all_programs = []
        for cobol_file_path in cobol_file_paths:
            try:
                # O parser.parse_file já lida com o conteúdo do arquivo e retorna uma lista de programas
                programs_in_file, _ = cobol_parser.parse_file(cobol_file_path)
                all_programs.extend(programs_in_file)
                logger.info(f"Programas COBOL carregados de: {cobol_file_path}")
            except Exception as e:
                logger.error(f"Erro ao carregar programa COBOL {cobol_file_path}: {e}")

        for program in all_programs:
            programs_data[program.name] = program.content

        # Parsear o arquivo BOOKS.txt como copybooks
        _, books = cobol_parser.parse_file(args.books)

        # Criar conteúdo de copybooks
        copybooks_content = "\n".join([f"=== COPYBOOK {book.name} ===\n{book.content}" for book in books])
        
        logger.info(f"Programas encontrados: {list(programs_data.keys())}")

        if not programs_data:
            logger.error("Nenhum programa COBOL encontrado para processar.")
            return

    except Exception as e:
        logger.error(f"Erro ao parsear programas COBOL: {e}")
        return

    # Carregar template HTML
    html_template = load_html_template()

    # Processar cada programa com cada modelo configurado
    try:
        configured_models = config_manager.get_configured_models()
        logger.info(f"Modelos configurados: {len(configured_models)}")
        
        for model_info in configured_models:
            logger.info(f"Modelo: {model_info}")

        if not configured_models:
            logger.error("Nenhum modelo de IA configurado ou habilitado. Verifique seu config.yaml.")
            return

    except Exception as e:
        logger.error(f"Erro ao obter modelos configurados: {e}")
        return

    # Processar cada programa
    for program_name, program_content in programs_data.items():
        logger.info(f"=== PROCESSANDO PROGRAMA: {program_name} ===")

        for model_info in configured_models:
            model_display_name = model_info["display_name"]
            logger.info(f"  Usando modelo: {model_display_name}")

            try:
                # Criar estrutura de saída para o modelo
                model_output_dir = create_output_structure(args.output, args.analysis_name, model_display_name)

                # Gerar prompt completo
                enhanced_prompt_manager = EnhancedPromptManager(prompt_config)
                full_prompt_content = enhanced_prompt_manager.create_complete_analysis_prompt(
                    program_name=program_name,
                    cobol_code=program_content,
                    copybooks_content=copybooks_content
                )

                # Montar payload da requisição
                request_payload = {
                    "provider": model_info["provider"],
                    "model": model_info["name"],
                    "input": {
                        "query": [
                            {"role": "system", "content": prompt_config["system_prompt"]},
                            {"role": "user", "content": full_prompt_content}
                        ]
                    },
                    "config": model_info["config"],
                    "program_name": program_name,
                    "cobol_code_length": len(program_content),
                    "copybooks_length": len(copybooks_content),
                    "custom_prompt_used": True if args.prompts_yaml else False,
                    "prompts_yaml_file": prompt_config.get("yaml_file", "N/A"),
                    "full_prompt_sent": full_prompt_content,
                    "bian_references": full_prompt_content.lower().count('bian')
                }

                logger.info(f"  Request payload preparado. BIAN refs: {request_payload['bian_references']}")

                # Enviar requisição ao provedor
                # Criar AIRequest
                from providers.base_provider import AIRequest
                ai_request = AIRequest(
                    prompt=full_prompt_content,
                    program_name=program_name,
                    program_code=program_content
                )
                
                # Enviar requisição
                response = provider_manager.analyze_with_specific_provider(model_info["provider"], ai_request)
                response_content = response.content
                tokens_used = response.tokens_used
                logger.info(f"  Resposta recebida. Tokens usados: {tokens_used}")

                # Formatar resposta
                formatter = EnhancedResponseFormatter()
                formatted_response = response_content

                # Salvar arquivos
                # 1. Análise Markdown
                md_output_path = model_output_dir / f"{program_name}_analise_funcional.md"
                with open(md_output_path, "w", encoding="utf-8") as f:
                    f.write(formatted_response)
                logger.info(f"  Análise Markdown salva: {md_output_path}")

                # 2. Request JSON
                request_json_path = model_output_dir / "ai_requests" / f"{program_name}_ai_request.json"
                with open(request_json_path, "w", encoding="utf-8") as f:
                    json.dump(request_payload, f, indent=2, ensure_ascii=False)
                logger.info(f"  Request JSON salvo: {request_json_path}")

                # 3. Response JSON
                response_json_path = model_output_dir / "ai_responses" / f"{program_name}_ai_response.json"
                with open(response_json_path, "w", encoding="utf-8") as f:
                    response_dict = {
                        "success": response.success,
                        "content": response.content,
                        "tokens_used": response.tokens_used,
                        "model": response.model,
                        "provider": response.provider,
                        "timestamp": response.timestamp.isoformat() if response.timestamp else None,
                        "error_message": response.error_message,
                        "metadata": response.metadata,
                        "response_time": response.response_time
                    }
                    json.dump(response_dict, f, indent=2, ensure_ascii=False)
                logger.info(f"  Response JSON salvo: {response_json_path}")

                # 4. HTML se solicitado
                if args.html:
                    html_output_path = model_output_dir / f"{program_name}_analise_funcional.html"
                    rendered_html = render_html_template(
                        html_template,
                        program_name,
                        model_display_name,
                        datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                        formatted_response
                    )
                    with open(html_output_path, "w", encoding="utf-8") as f:
                        f.write(rendered_html)
                    logger.info(f"  Análise HTML salva: {html_output_path}")

            except Exception as e:
                logger.error(f"Erro ao processar programa {program_name} com modelo {model_display_name}: {e}")
                import traceback
                traceback.print_exc()

    logger.info("=== PROCESSAMENTO CONCLUÍDO ===")

if __name__ == "__main__":
    main()

