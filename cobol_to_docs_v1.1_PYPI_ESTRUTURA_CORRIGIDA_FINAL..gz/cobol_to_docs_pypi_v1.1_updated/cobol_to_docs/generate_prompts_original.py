#!/usr/bin/env python3
"""
Gerador de Prompts YAML - COBOL to Docs v1.0
Autor: Carlos Morais
Data: Setembro 2025

Script de linha de comando para converter texto livre em prompts YAML otimizados
"""

import argparse
import sys
import os
import logging
from pathlib import Path
from datetime import datetime

# Imports do pacote
try:
    from .generators.prompt_generator import PromptGenerator
except ImportError:
    from generators.prompt_generator import PromptGenerator

def setup_logging(log_level: str = "INFO") -> None:
    """Configura o sistema de logging."""
    log_dir = "logs"
    os.makedirs(log_dir, exist_ok=True)
    
    log_file = os.path.join(log_dir, f"prompt_generator_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
    
    logging.basicConfig(
        level=getattr(logging, log_level.upper()),
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file, encoding='utf-8'),
            logging.StreamHandler(sys.stdout)
        ]
    )

def print_banner():
    """Exibe banner do gerador de prompts."""
    print("=" * 70)
    print("GERADOR DE PROMPTS YAML - COBOL TO DOCS v1.0")
    print("Autor: Carlos Morais")
    print("Converte texto livre em prompts YAML otimizados para análise COBOL")
    print("=" * 70)
    print()

def validate_input_file(file_path: str) -> bool:
    """Valida arquivo de entrada."""
    path = Path(file_path)
    
    if not path.exists():
        print(f"Erro: Arquivo não encontrado: {file_path}")
        return False
    
    if not path.is_file():
        print(f"Erro: Caminho não é um arquivo: {file_path}")
        return False
    
    if path.stat().st_size == 0:
        print(f"Erro: Arquivo está vazio: {file_path}")
        return False
    
    if path.stat().st_size > 50000:  # 50KB limit
        print(f"Aviso: Arquivo muito grande ({path.stat().st_size} bytes). Recomendado < 50KB")
    
    return True

def preview_input(file_path: str, max_chars: int = 500):
    """Exibe preview do arquivo de entrada."""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        print(f"PREVIEW DO ARQUIVO DE ENTRADA:")
        print(f"Arquivo: {file_path}")
        print(f"Tamanho: {len(content)} caracteres")
        print("-" * 50)
        
        if len(content) > max_chars:
            print(content[:max_chars] + "...")
            print(f"\n[... mais {len(content) - max_chars} caracteres]")
        else:
            print(content)
        
        print("-" * 50)
        print()
        
    except Exception as e:
        print(f"Erro ao ler arquivo: {e}")

def generate_prompts_interactive():
    """Modo interativo para geração de prompts."""
    print("MODO INTERATIVO")
    print("Digite ou cole seu texto abaixo. Digite 'FIM' em uma linha separada para finalizar:")
    print()
    
    lines = []
    while True:
        try:
            line = input()
            if line.strip().upper() == 'FIM':
                break
            lines.append(line)
        except KeyboardInterrupt:
            print("\n\nOperação cancelada pelo usuário")
            return None
    
    text = '\n'.join(lines).strip()
    
    if not text:
        print("Nenhum texto fornecido")
        return None
    
    print(f"\nTexto capturado: {len(text)} caracteres")
    return text

def main():
    """Função principal."""
    parser = argparse.ArgumentParser(
        description='Gerador de Prompts YAML - Converte texto livre em prompts otimizados',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Exemplos de uso:

  # Gerar prompts a partir de arquivo
  python3 generate_prompts.py --input requisitos.txt --output meus_prompts.yaml

  # Modo interativo
  python3 generate_prompts.py --interactive

  # Validar prompts existentes
  python3 generate_prompts.py --validate prompts_gerados.yaml

  # Verificar status do sistema
  python3 generate_prompts.py --status

  # Gerar com preview
  python3 generate_prompts.py --input texto.txt --preview --output resultado.yaml

Autor: Carlos Morais
        """
    )
    
    parser.add_argument('--input', '-i', help='Arquivo de texto para converter em prompts')
    parser.add_argument('--output', '-o', help='Arquivo YAML de saída (opcional)')
    parser.add_argument('--interactive', action='store_true', help='Modo interativo para entrada de texto')
    parser.add_argument('--validate', help='Validar arquivo YAML de prompts existente')
    parser.add_argument('--status', action='store_true', help='Verificar status do sistema')
    parser.add_argument('--preview', action='store_true', help='Exibir preview do arquivo de entrada')
    parser.add_argument('--config', default='config/config.yaml', help='Arquivo de configuração')
    parser.add_argument('--log', default='INFO', help='Nível de log (DEBUG, INFO, WARNING, ERROR)')
    
    args = parser.parse_args()
    
    # Configurar logging
    setup_logging(args.log)
    
    # Exibir banner
    print_banner()
    
    try:
        # Inicializar gerador
        print("Inicializando gerador de prompts...")
        generator = PromptGenerator(args.config)
        print("Gerador inicializado com sucesso")
        print()
        
        # Verificar status se solicitado
        if args.status:
            print("STATUS DO SISTEMA:")
            status = generator.get_status()
            
            for key, value in status.items():
                icon = "OK" if value else "ERRO"
                if key == 'error':
                    icon = "ERRO"
                print(f"{icon} {key}: {value}")
            
            print()
            return
        
        # Validar arquivo se solicitado
        if args.validate:
            print(f"VALIDANDO ARQUIVO: {args.validate}")
            validation = generator.validate_generated_prompts(args.validate)
            
            if validation['valid']:
                print("Arquivo YAML válido!")
                print(f"Estatísticas:")
                print(f"  - Perguntas de análise: {validation['total_questions']}")
                print(f"  - Modelos configurados: {validation['total_models']}")
                print(f"  - Tamanho do arquivo: {validation['file_size']} bytes")
            else:
                print("Arquivo YAML inválido!")
                if 'missing_sections' in validation:
                    print(f"  - Seções faltando: {validation['missing_sections']}")
                if 'error' in validation:
                    print(f"  - Erro: {validation['error']}")
            
            print()
            return
        
        # Modo interativo
        if args.interactive:
            input_text = generate_prompts_interactive()
            if not input_text:
                return
            
            # Gerar nome de arquivo baseado na data
            if not args.output:
                timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                args.output = f"prompts_interativo_{timestamp}.yaml"
        
        # Modo arquivo
        elif args.input:
            if not validate_input_file(args.input):
                return
            
            if args.preview:
                preview_input(args.input)
                
                response = input("Continuar com a geração? (s/N): ").strip().lower()
                if response not in ['s', 'sim', 'y', 'yes']:
                    print("Operação cancelada pelo usuário")
                    return
                print()
            
            # Gerar nome de arquivo se não especificado
            if not args.output:
                input_path = Path(args.input)
                args.output = f"{input_path.stem}_prompts.yaml"
            
            print(f"Processando arquivo: {args.input}")
            result = generator.generate_from_file(args.input, args.output)
        
        else:
            print("Erro: Especifique --input, --interactive, --validate ou --status")
            parser.print_help()
            return
        
        # Processar modo interativo
        if args.interactive:
            print("Gerando prompts YAML otimizados...")
            result = generator.generate_prompt_yaml(input_text, args.output)
        
        # Exibir resultados
        if result['success']:
            print("GERAÇÃO CONCLUÍDA COM SUCESSO!")
            print()
            print("ESTATÍSTICAS:")
            stats = result.get('statistics', {})
            print(f"  - Texto de entrada: {stats.get('input_length', 0)} caracteres")
            print(f"  - Texto limpo: {stats.get('clean_length', 0)} caracteres")
            print(f"  - YAML gerado: {stats.get('output_length', 0)} caracteres")
            print(f"  - Seções YAML: {stats.get('yaml_sections', 0)}")
            print(f"  - Tokens utilizados: {result.get('tokens_used', 0)}")
            print(f"  - Tempo de geração: {result.get('generation_time', 0):.2f}s")
            
            if result.get('output_file'):
                print(f"  - Arquivo salvo: {result['output_file']}")
            
            print()
            print("PRÓXIMOS PASSOS:")
            print("1. Revise o arquivo YAML gerado")
            print("2. Teste os prompts com um programa COBOL")
            print("3. Ajuste conforme necessário")
            print("4. Use com: python3 main.py --prompts-file seu_arquivo.yaml")
            
        else:
            print("ERRO NA GERAÇÃO:")
            print(f"  {result.get('error', 'Erro desconhecido')}")
            
    except KeyboardInterrupt:
        print("\n\nOperação cancelada pelo usuário")
    except Exception as e:
        print(f"\nErro inesperado: {e}")
        logging.error(f"Erro inesperado: {e}", exc_info=True)

if __name__ == "__main__":
    main()
