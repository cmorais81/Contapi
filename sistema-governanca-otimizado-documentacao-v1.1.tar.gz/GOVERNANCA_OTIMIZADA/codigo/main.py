#!/usr/bin/env python3
"""
Sistema de Governança de Dados V2.0 - Executor Principal
Execução unificada de todos os 31 microserviços
"""

import os
import sys
import time
import signal
import subprocess
import threading
import logging
from pathlib import Path
from typing import Dict, List, Optional
import psutil
import requests

# Configuração de logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/main_system.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger('GovernanceSystem')

class MicroserviceManager:
    """Gerenciador de microserviços do sistema de governança"""
    
    def __init__(self):
        self.services = {}
        self.processes = {}
        self.running = False
        self.base_port = 8000
        
        # Configuração dos microserviços
        self.service_config = {
            # Camada Estratégica
            'api-gateway': {'port': 8000, 'priority': 1, 'dependencies': []},
            'identity-service': {'port': 8001, 'priority': 1, 'dependencies': []},
            'governance-service': {'port': 8002, 'priority': 1, 'dependencies': ['identity-service']},
            'security-service': {'port': 8003, 'priority': 1, 'dependencies': ['identity-service']},
            'monitoring-service': {'port': 8004, 'priority': 1, 'dependencies': []},
            
            # Camada Operacional
            'catalog-service': {'port': 8005, 'priority': 2, 'dependencies': ['identity-service']},
            'contract-service': {'port': 8006, 'priority': 2, 'dependencies': ['catalog-service']},
            'quality-service': {'port': 8007, 'priority': 2, 'dependencies': ['catalog-service']},
            'audit-service': {'port': 8008, 'priority': 2, 'dependencies': ['identity-service']},
            'workflow-service': {'port': 8009, 'priority': 2, 'dependencies': ['identity-service']},
            'analytics-service': {'port': 8010, 'priority': 2, 'dependencies': ['catalog-service']},
            'stewardship-service': {'port': 8011, 'priority': 2, 'dependencies': ['catalog-service']},
            'domain-service': {'port': 8012, 'priority': 2, 'dependencies': ['governance-service']},
            'notification-service': {'port': 8013, 'priority': 2, 'dependencies': ['identity-service']},
            'lineage-service': {'port': 8014, 'priority': 2, 'dependencies': ['catalog-service']},
            'layout-service': {'port': 8015, 'priority': 2, 'dependencies': ['identity-service']},
            'glossary-service': {'port': 8016, 'priority': 2, 'dependencies': ['catalog-service']},
            
            # Camada Técnica
            'auto-discovery-service': {'port': 8017, 'priority': 3, 'dependencies': ['catalog-service']},
            'data-discovery-service': {'port': 8018, 'priority': 3, 'dependencies': ['catalog-service']},
            'data-masking-service': {'port': 8019, 'priority': 3, 'dependencies': ['security-service']},
            'backup-service': {'port': 8020, 'priority': 3, 'dependencies': ['monitoring-service']},
            'cache-service': {'port': 8021, 'priority': 3, 'dependencies': []},
            'message-queue-service': {'port': 8022, 'priority': 3, 'dependencies': []},
            'rate-limiting-service': {'port': 8023, 'priority': 3, 'dependencies': ['api-gateway']},
            'external-integration-service': {'port': 8024, 'priority': 3, 'dependencies': ['security-service']},
            'tag-management-service': {'port': 8025, 'priority': 3, 'dependencies': ['catalog-service']},
            'databricks-integration-service': {'port': 8026, 'priority': 3, 'dependencies': ['catalog-service']},
            'discovery-service': {'port': 8027, 'priority': 3, 'dependencies': ['catalog-service']},
            'masking-service': {'port': 8028, 'priority': 3, 'dependencies': ['security-service']},
            'automation-engine-service': {'port': 8029, 'priority': 3, 'dependencies': ['workflow-service']},
            'ai-service': {'port': 8030, 'priority': 3, 'dependencies': ['analytics-service']},
        }
    
    def check_prerequisites(self) -> bool:
        """Verifica pré-requisitos do sistema"""
        logger.info("Verificando pré-requisitos do sistema...")
        
        # Verificar PostgreSQL
        try:
            import psycopg2
            conn = psycopg2.connect(
                host=os.getenv('DB_HOST', 'localhost'),
                port=os.getenv('DB_PORT', '5432'),
                database=os.getenv('DB_NAME', 'governance_system'),
                user=os.getenv('DB_USER', 'governance_user'),
                password=os.getenv('DB_PASSWORD', 'secure_password')
            )
            conn.close()
            logger.info("PostgreSQL: Conectado com sucesso")
        except Exception as e:
            logger.error(f"PostgreSQL: Erro de conexão - {e}")
            return False
        
        # Verificar Redis
        try:
            import redis
            r = redis.Redis(
                host=os.getenv('REDIS_HOST', 'localhost'),
                port=int(os.getenv('REDIS_PORT', '6379')),
                db=int(os.getenv('REDIS_DB', '0'))
            )
            r.ping()
            logger.info("Redis: Conectado com sucesso")
        except Exception as e:
            logger.error(f"Redis: Erro de conexão - {e}")
            return False
        
        # Verificar portas disponíveis
        for service, config in self.service_config.items():
            port = config['port']
            if self.is_port_in_use(port):
                logger.warning(f"Porta {port} já está em uso (serviço: {service})")
        
        return True
    
    def is_port_in_use(self, port: int) -> bool:
        """Verifica se uma porta está em uso"""
        for conn in psutil.net_connections():
            if conn.laddr.port == port:
                return True
        return False
    
    def start_service(self, service_name: str) -> bool:
        """Inicia um microserviço específico"""
        if service_name not in self.service_config:
            logger.error(f"Serviço desconhecido: {service_name}")
            return False
        
        service_path = Path(f"apps/{service_name}")
        if not service_path.exists():
            logger.error(f"Diretório do serviço não encontrado: {service_path}")
            return False
        
        # Procurar pelo arquivo main.py
        main_file = None
        for possible_main in ['main.py', 'src/main.py', 'app.py', 'src/app.py']:
            main_path = service_path / possible_main
            if main_path.exists():
                main_file = main_path
                break
        
        if not main_file:
            logger.error(f"Arquivo main.py não encontrado para {service_name}")
            return False
        
        config = self.service_config[service_name]
        port = config['port']
        
        # Configurar variáveis de ambiente
        env = os.environ.copy()
        env.update({
            'SERVICE_NAME': service_name,
            'SERVICE_PORT': str(port),
            'DATABASE_URL': os.getenv('DATABASE_URL', 'postgresql://governance_user:secure_password@localhost:5432/governance_system'),
            'REDIS_URL': os.getenv('REDIS_URL', 'redis://localhost:6379/0'),
        })
        
        try:
            # Iniciar processo
            cmd = [sys.executable, str(main_file)]
            process = subprocess.Popen(
                cmd,
                cwd=str(self.root_dir),  # Usar root_dir em vez de service_path
                env=env,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            self.processes[service_name] = process
            logger.info(f"Serviço {service_name} iniciado na porta {port} (PID: {process.pid})")
            
            # Aguardar um pouco para o serviço inicializar
            time.sleep(2)
            
            # Verificar se o processo ainda está rodando
            if process.poll() is None:
                return True
            else:
                stdout, stderr = process.communicate()
                logger.error(f"Serviço {service_name} falhou ao iniciar:")
                logger.error(f"STDOUT: {stdout}")
                logger.error(f"STDERR: {stderr}")
                return False
                
        except Exception as e:
            logger.error(f"Erro ao iniciar {service_name}: {e}")
            return False
    
    def stop_service(self, service_name: str) -> bool:
        """Para um microserviço específico"""
        if service_name not in self.processes:
            return True
        
        process = self.processes[service_name]
        try:
            # Tentar parada graceful
            process.terminate()
            process.wait(timeout=10)
            logger.info(f"Serviço {service_name} parado graciosamente")
        except subprocess.TimeoutExpired:
            # Forçar parada se necessário
            process.kill()
            process.wait()
            logger.warning(f"Serviço {service_name} foi forçado a parar")
        except Exception as e:
            logger.error(f"Erro ao parar {service_name}: {e}")
            return False
        
        del self.processes[service_name]
        return True
    
    def check_service_health(self, service_name: str) -> bool:
        """Verifica saúde de um serviço"""
        if service_name not in self.service_config:
            return False
        
        port = self.service_config[service_name]['port']
        try:
            response = requests.get(f"http://localhost:{port}/health", timeout=5)
            return response.status_code == 200
        except:
            return False
    
    def start_all_services(self) -> bool:
        """Inicia todos os microserviços em ordem de prioridade"""
        logger.info("Iniciando todos os microserviços...")
        
        # Agrupar por prioridade
        services_by_priority = {}
        for service, config in self.service_config.items():
            priority = config['priority']
            if priority not in services_by_priority:
                services_by_priority[priority] = []
            services_by_priority[priority].append(service)
        
        # Iniciar por prioridade
        for priority in sorted(services_by_priority.keys()):
            logger.info(f"Iniciando serviços de prioridade {priority}...")
            
            for service in services_by_priority[priority]:
                if self.start_service(service):
                    logger.info(f"✓ {service} iniciado com sucesso")
                else:
                    logger.error(f"✗ Falha ao iniciar {service}")
                    return False
                
                # Aguardar entre inicializações
                time.sleep(1)
            
            # Aguardar estabilização da camada
            time.sleep(3)
        
        self.running = True
        logger.info("Todos os microserviços foram iniciados!")
        return True
    
    def stop_all_services(self):
        """Para todos os microserviços"""
        logger.info("Parando todos os microserviços...")
        
        # Parar em ordem reversa de prioridade
        services_by_priority = {}
        for service, config in self.service_config.items():
            priority = config['priority']
            if priority not in services_by_priority:
                services_by_priority[priority] = []
            services_by_priority[priority].append(service)
        
        for priority in sorted(services_by_priority.keys(), reverse=True):
            for service in services_by_priority[priority]:
                if service in self.processes:
                    self.stop_service(service)
                    logger.info(f"✓ {service} parado")
        
        self.running = False
        logger.info("Todos os microserviços foram parados!")
    
    def monitor_services(self):
        """Monitora saúde dos serviços e reinicia se necessário"""
        while self.running:
            try:
                for service_name in list(self.processes.keys()):
                    process = self.processes[service_name]
                    
                    # Verificar se processo ainda está rodando
                    if process.poll() is not None:
                        logger.warning(f"Serviço {service_name} parou inesperadamente. Reiniciando...")
                        del self.processes[service_name]
                        self.start_service(service_name)
                
                time.sleep(30)  # Verificar a cada 30 segundos
                
            except Exception as e:
                logger.error(f"Erro no monitoramento: {e}")
                time.sleep(10)
    
    def print_status(self):
        """Exibe status dos serviços"""
        print("\n" + "="*80)
        print("STATUS DOS MICROSERVIÇOS")
        print("="*80)
        
        for service, config in self.service_config.items():
            port = config['port']
            if service in self.processes:
                process = self.processes[service]
                if process.poll() is None:
                    status = "RODANDO"
                    health = "OK" if self.check_service_health(service) else "ERRO"
                else:
                    status = "PARADO"
                    health = "N/A"
            else:
                status = "NÃO INICIADO"
                health = "N/A"
            
            print(f"{service:35} | Porta: {port:5} | Status: {status:12} | Saúde: {health}")
        
        print("="*80)
        print(f"Total de serviços: {len(self.service_config)}")
        print(f"Serviços rodando: {len([s for s in self.processes.values() if s.poll() is None])}")
        print("="*80)

def signal_handler(signum, frame):
    """Handler para sinais do sistema"""
    logger.info("Recebido sinal de parada. Parando sistema...")
    if 'manager' in globals():
        manager.stop_all_services()
    sys.exit(0)

def main():
    """Função principal"""
    global manager
    
    print("="*80)
    print("SISTEMA DE GOVERNANÇA DE DADOS V2.0")
    print("Executor Principal - 31 Microserviços")
    print("="*80)
    
    # Configurar handlers de sinal
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # Criar diretório de logs se não existir
    os.makedirs('logs', exist_ok=True)
    
    # Inicializar gerenciador
    manager = MicroserviceManager()
    
    # Verificar pré-requisitos
    if not manager.check_prerequisites():
        logger.error("Pré-requisitos não atendidos. Abortando...")
        sys.exit(1)
    
    # Iniciar todos os serviços
    if not manager.start_all_services():
        logger.error("Falha ao iniciar todos os serviços. Abortando...")
        manager.stop_all_services()
        sys.exit(1)
    
    # Iniciar monitoramento em thread separada
    monitor_thread = threading.Thread(target=manager.monitor_services, daemon=True)
    monitor_thread.start()
    
    # Exibir status inicial
    manager.print_status()
    
    print("\nSistema iniciado com sucesso!")
    print("Pressione Ctrl+C para parar todos os serviços")
    print("\nEndpoints principais:")
    print("- API Gateway: http://localhost:8000")
    print("- Identity Service: http://localhost:8001")
    print("- Catalog Service: http://localhost:8005")
    print("- Contract Service: http://localhost:8006")
    print("- Quality Service: http://localhost:8007")
    
    try:
        # Loop principal
        while manager.running:
            time.sleep(10)
            
            # Verificar se algum processo crítico parou
            critical_services = ['api-gateway', 'identity-service']
            for service in critical_services:
                if service in manager.processes:
                    process = manager.processes[service]
                    if process.poll() is not None:
                        logger.error(f"Serviço crítico {service} parou. Parando sistema...")
                        manager.stop_all_services()
                        sys.exit(1)
    
    except KeyboardInterrupt:
        logger.info("Interrupção do usuário detectada")
    
    finally:
        manager.stop_all_services()

if __name__ == "__main__":
    main()

