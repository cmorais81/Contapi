#!/usr/bin/env python3
"""
Script para Criar Scripts de Banco de Dados
Gera scripts SQL de criação e população do banco baseado no modelo DBML
"""

import re
from pathlib import Path
from typing import Dict, List, Tuple, Optional
from datetime import datetime


class DatabaseScriptGenerator:
    """Gerador de scripts de banco de dados"""
    
    def __init__(self, dbml_file: str):
        self.dbml_file = Path(dbml_file)
        self.dbml_content = ""
        self.tables = []
        self.scripts_dir = self.dbml_file.parent / "scripts"
        
    def read_dbml_file(self):
        """Ler arquivo DBML"""
        with open(self.dbml_file, 'r', encoding='utf-8') as f:
            self.dbml_content = f.read()
        print(f"Arquivo DBML lido: {len(self.dbml_content)} caracteres")
    
    def parse_dbml_tables(self) -> List[Dict]:
        """Extrair informações das tabelas do DBML"""
        print("Extraindo informações das tabelas...")
        
        # Padrão para encontrar tabelas completas
        table_pattern = r'Table\s+(\w+)\s*\{([^}]+)\}'
        
        tables = []
        matches = re.finditer(table_pattern, self.dbml_content, re.DOTALL)
        
        for match in matches:
            table_name = match.group(1)
            table_content = match.group(2)
            
            # Extrair colunas
            columns = self.parse_table_columns(table_content)
            
            table_info = {
                'name': table_name,
                'columns': columns,
                'content': table_content
            }
            
            tables.append(table_info)
            print(f"  Tabela: {table_name} - {len(columns)} colunas")
        
        print(f"Total de tabelas extraídas: {len(tables)}")
        return tables
    
    def parse_table_columns(self, table_content: str) -> List[Dict]:
        """Extrair colunas de uma tabela"""
        columns = []
        
        # Padrão para linhas de coluna
        column_pattern = r'^\s*(\w+)\s+(\w+(?:\(\d+\))?)\s*(\[.*?\])?\s*(?://.*)?$'
        
        lines = table_content.strip().split('\n')
        for line in lines:
            line = line.strip()
            if not line or line.startswith('//') or line.startswith('Note:'):
                continue
            
            # Padrão mais flexível para colunas
            match = re.match(r'^\s*(\w+)\s+(\w+(?:\(\d+\))?)\s*(.*?)(?://.*)?$', line)
            if match:
                column_name = match.group(1)
                column_type = match.group(2)
                attributes = match.group(3).strip()
                
                # Analisar atributos
                is_primary_key = 'primary key' in attributes
                is_not_null = 'not null' in attributes or is_primary_key
                is_unique = 'unique' in attributes
                default_value = None
                
                # Extrair valor padrão
                default_match = re.search(r'default:\s*`([^`]+)`', attributes)
                if default_match:
                    default_value = default_match.group(1)
                
                column_info = {
                    'name': column_name,
                    'type': column_type,
                    'primary_key': is_primary_key,
                    'not_null': is_not_null,
                    'unique': is_unique,
                    'default': default_value,
                    'attributes': attributes
                }
                
                columns.append(column_info)
        
        return columns
    
    def dbml_type_to_sql(self, dbml_type: str) -> str:
        """Converter tipo DBML para SQL PostgreSQL"""
        type_mapping = {
            'uuid': 'UUID',
            'text': 'TEXT',
            'varchar': 'TEXT',  # Já convertido para text
            'int': 'INTEGER',
            'integer': 'INTEGER',
            'bigint': 'BIGINT',
            'boolean': 'BOOLEAN',
            'timestamptz': 'TIMESTAMPTZ',
            'timestamp': 'TIMESTAMPTZ',  # Já convertido
            'date': 'DATE',
            'time': 'TIME',
            'decimal': 'DECIMAL',
            'numeric': 'NUMERIC',
            'float': 'FLOAT',
            'double': 'DOUBLE PRECISION',
            'json': 'JSON',
            'jsonb': 'JSONB'
        }
        
        # Remover parâmetros de tamanho se existirem
        base_type = re.sub(r'\(\d+\)', '', dbml_type.lower())
        
        return type_mapping.get(base_type, dbml_type.upper())
    
    def generate_create_table_sql(self, table: Dict) -> str:
        """Gerar SQL de criação de uma tabela"""
        table_name = table['name']
        columns = table['columns']
        
        sql_lines = [f"CREATE TABLE {table_name} ("]
        
        column_definitions = []
        
        for column in columns:
            col_name = column['name']
            col_type = self.dbml_type_to_sql(column['type'])
            
            # Construir definição da coluna
            col_def = f"    {col_name} {col_type}"
            
            # Adicionar constraints
            if column['primary_key']:
                col_def += " PRIMARY KEY"
            elif column['not_null']:
                col_def += " NOT NULL"
            
            if column['unique'] and not column['primary_key']:
                col_def += " UNIQUE"
            
            # Adicionar valor padrão
            if column['default']:
                if column['default'] in ['now()', 'gen_random_uuid()']:
                    col_def += f" DEFAULT {column['default']}"
                else:
                    col_def += f" DEFAULT '{column['default']}'"
            
            column_definitions.append(col_def)
        
        sql_lines.append(",\n".join(column_definitions))
        sql_lines.append(");")
        
        return "\n".join(sql_lines)
    
    def generate_create_database_script(self) -> str:
        """Gerar script completo de criação do banco"""
        print("Gerando script de criação do banco...")
        
        script_lines = [
            "-- Script de Criação do Banco de Dados",
            "-- Sistema de Governança de Dados V1.0",
            f"-- Gerado em: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            "-- Total de tabelas: 43",
            "",
            "-- Extensões necessárias",
            "CREATE EXTENSION IF NOT EXISTS \"uuid-ossp\";",
            "CREATE EXTENSION IF NOT EXISTS \"pg_trgm\";",
            "",
            "-- Configurações de timezone",
            "SET timezone = 'UTC';",
            "",
        ]
        
        # Agrupar tabelas por categoria
        table_groups = {
            'Identidade e Acesso': ['users', 'user_sessions', 'roles', 'permissions', 'user_roles'],
            'Catálogo e Metadados': ['data_sources', 'datasets', 'dataset_columns', 'metadata_tags'],
            'Contratos de Dados': ['data_contracts', 'contract_versions', 'contract_schemas', 'contract_sla_metrics'],
            'Qualidade e Monitoramento': ['quality_rules', 'quality_checks', 'quality_results', 'data_profiling', 'anomaly_detection'],
            'Governança e Políticas': ['governance_policies', 'policy_rules', 'compliance_frameworks', 'policy_violations'],
            'Linhagem e Rastreamento': ['data_lineage', 'lineage_relationships', 'impact_analysis', 'change_tracking'],
            'Compliance e Auditoria': ['audit_logs', 'compliance_reports', 'data_retention_policies', 'data_deletion_logs'],
            'Workflow e Aprovação': ['workflows', 'workflow_steps', 'workflow_executions', 'approvals'],
            'Notificações e Alertas': ['notification_templates', 'notifications', 'alert_rules', 'alerts'],
            'Configuração do Sistema': ['system_settings', 'integration_configs', 'masking_rules', 'data_classification_rules', 'system_health_metrics']
        }
        
        # Criar tabelas por grupo
        for group_name, table_names in table_groups.items():
            script_lines.append(f"-- =====================================================")
            script_lines.append(f"-- {group_name.upper()}")
            script_lines.append(f"-- =====================================================")
            script_lines.append("")
            
            for table_name in table_names:
                # Encontrar tabela nos dados extraídos
                table_data = next((t for t in self.tables if t['name'] == table_name), None)
                if table_data:
                    table_sql = self.generate_create_table_sql(table_data)
                    script_lines.append(table_sql)
                    script_lines.append("")
                else:
                    script_lines.append(f"-- ERRO: Tabela {table_name} não encontrada no modelo DBML")
                    script_lines.append("")
        
        # Adicionar índices importantes
        script_lines.extend([
            "-- =====================================================",
            "-- ÍNDICES PARA PERFORMANCE",
            "-- =====================================================",
            "",
            "-- Índices para campos de auditoria",
            "CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_users_created_at ON users(created_at);",
            "CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_audit_logs_created_at ON audit_logs(created_at);",
            "CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_data_contracts_created_at ON data_contracts(created_at);",
            "",
            "-- Índices para busca de texto",
            "CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_datasets_name_gin ON datasets USING gin(name gin_trgm_ops);",
            "CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_data_sources_name_gin ON data_sources USING gin(name gin_trgm_ops);",
            "",
            "-- Índices para relacionamentos",
            "CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_user_roles_user_id ON user_roles(user_id);",
            "CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_user_roles_role_id ON user_roles(role_id);",
            "CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_contract_versions_contract_id ON contract_versions(contract_id);",
            "",
        ])
        
        # Adicionar comentários nas tabelas
        script_lines.extend([
            "-- =====================================================",
            "-- COMENTÁRIOS NAS TABELAS",
            "-- =====================================================",
            "",
            "COMMENT ON TABLE users IS 'Usuários do sistema de governança';",
            "COMMENT ON TABLE data_contracts IS 'Contratos de dados com SLAs e versionamento';",
            "COMMENT ON TABLE audit_logs IS 'Logs de auditoria de todas as operações';",
            "COMMENT ON TABLE quality_rules IS 'Regras de qualidade de dados configuráveis';",
            "COMMENT ON TABLE data_lineage IS 'Linhagem e rastreamento de dados';",
            "",
        ])
        
        script_lines.append("-- Script de criação concluído com sucesso!")
        
        return "\n".join(script_lines)
    
    def generate_sample_data_script(self) -> str:
        """Gerar script de dados de exemplo"""
        print("Gerando script de dados de exemplo...")
        
        script_lines = [
            "-- Script de Dados de Exemplo",
            "-- Sistema de Governança de Dados V1.0",
            f"-- Gerado em: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            "",
            "-- Desabilitar triggers temporariamente para inserção em lote",
            "SET session_replication_role = replica;",
            "",
        ]
        
        # Dados de exemplo por tabela
        sample_data = {
            'roles': [
                "('admin', 'Administrador do Sistema', 'Acesso completo ao sistema')",
                "('data_steward', 'Steward de Dados', 'Responsável pela qualidade dos dados')",
                "('analyst', 'Analista de Dados', 'Acesso de leitura e análise')",
                "('viewer', 'Visualizador', 'Acesso somente leitura')"
            ],
            'permissions': [
                "('create_contract', 'Criar Contratos', 'Permissão para criar novos contratos de dados')",
                "('edit_contract', 'Editar Contratos', 'Permissão para editar contratos existentes')",
                "('view_audit', 'Visualizar Auditoria', 'Permissão para visualizar logs de auditoria')",
                "('manage_users', 'Gerenciar Usuários', 'Permissão para gerenciar usuários do sistema')",
                "('configure_quality', 'Configurar Qualidade', 'Permissão para configurar regras de qualidade')"
            ],
            'users': [
                "('admin@empresa.com', 'admin', '$2b$12$hash_admin', 'Administrador Sistema', 'TI', 'Administrador')",
                "('steward@empresa.com', 'steward', '$2b$12$hash_steward', 'João Silva', 'Dados', 'Data Steward')",
                "('analyst@empresa.com', 'analyst', '$2b$12$hash_analyst', 'Maria Santos', 'Analytics', 'Analista Senior')",
                "('viewer@empresa.com', 'viewer', '$2b$12$hash_viewer', 'Pedro Costa', 'Negócios', 'Consultor')"
            ],
            'compliance_frameworks': [
                "('GDPR', 'General Data Protection Regulation', 'Regulamento Geral de Proteção de Dados da UE', true)",
                "('LGPD', 'Lei Geral de Proteção de Dados', 'Lei brasileira de proteção de dados pessoais', true)",
                "('SOX', 'Sarbanes-Oxley Act', 'Lei americana para controles financeiros', true)",
                "('HIPAA', 'Health Insurance Portability and Accountability Act', 'Lei americana para dados de saúde', false)"
            ],
            'data_sources': [
                "('PostgreSQL Produção', 'postgresql', 'postgresql://prod.empresa.com:5432/main', 'Banco principal de produção', 'production')",
                "('Data Lake S3', 's3', 's3://empresa-datalake/', 'Data Lake corporativo na AWS', 'production')",
                "('Databricks', 'databricks', 'https://empresa.cloud.databricks.com', 'Plataforma de analytics', 'production')",
                "('API CRM', 'api', 'https://api.crm.empresa.com/v1', 'API do sistema CRM', 'production')"
            ],
            'governance_policies': [
                "('Política de Qualidade', 'Dados devem ter qualidade mínima de 95%', 'quality', true)",
                "('Política de Retenção', 'Dados pessoais devem ser excluídos após 5 anos', 'retention', true)",
                "('Política de Acesso', 'Acesso a dados sensíveis requer aprovação', 'access', true)",
                "('Política de Backup', 'Backup diário de dados críticos', 'backup', true)"
            ]
        }
        
        # Gerar INSERTs
        for table_name, records in sample_data.items():
            script_lines.append(f"-- Dados para tabela {table_name}")
            
            # Obter colunas da tabela (exceto id, created_at, updated_at)
            table_data = next((t for t in self.tables if t['name'] == table_name), None)
            if table_data:
                columns = [col['name'] for col in table_data['columns'] 
                          if col['name'] not in ['id', 'created_at', 'updated_at']]
                
                if columns:
                    columns_str = ', '.join(columns)
                    script_lines.append(f"INSERT INTO {table_name} ({columns_str}) VALUES")
                    
                    for i, record in enumerate(records):
                        comma = "," if i < len(records) - 1 else ";"
                        script_lines.append(f"    {record}{comma}")
                    
                    script_lines.append("")
            else:
                script_lines.append(f"-- ERRO: Tabela {table_name} não encontrada")
                script_lines.append("")
        
        script_lines.extend([
            "-- Reabilitar triggers",
            "SET session_replication_role = DEFAULT;",
            "",
            "-- Atualizar sequências",
            "SELECT setval(pg_get_serial_sequence('users', 'id'), (SELECT MAX(id) FROM users));",
            "SELECT setval(pg_get_serial_sequence('roles', 'id'), (SELECT MAX(id) FROM roles));",
            "SELECT setval(pg_get_serial_sequence('permissions', 'id'), (SELECT MAX(id) FROM permissions));",
            "",
            "-- Script de dados de exemplo concluído!",
        ])
        
        return "\n".join(script_lines)
    
    def generate_migration_script(self) -> str:
        """Gerar script de migração/atualização"""
        script_lines = [
            "-- Script de Migração/Atualização",
            "-- Sistema de Governança de Dados V1.0",
            f"-- Gerado em: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            "",
            "-- Verificar se o banco já existe",
            "DO $$",
            "BEGIN",
            "    IF NOT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'users') THEN",
            "        RAISE NOTICE 'Banco novo detectado. Execute primeiro o script de criação.';",
            "    ELSE",
            "        RAISE NOTICE 'Banco existente detectado. Aplicando migrações...';",
            "    END IF;",
            "END $$;",
            "",
            "-- Adicionar colunas de auditoria se não existirem",
            "DO $$",
            "DECLARE",
            "    table_name TEXT;",
            "    table_names TEXT[] := ARRAY[",
        ]
        
        # Lista de todas as tabelas
        table_list = [f"'{table['name']}'" for table in self.tables]
        script_lines.append("        " + ",\n        ".join(table_list))
        
        script_lines.extend([
            "    ];",
            "BEGIN",
            "    FOREACH table_name IN ARRAY table_names LOOP",
            "        -- Adicionar created_at se não existir",
            "        IF NOT EXISTS (",
            "            SELECT 1 FROM information_schema.columns",
            "            WHERE table_name = table_name AND column_name = 'created_at'",
            "        ) THEN",
            "            EXECUTE format('ALTER TABLE %I ADD COLUMN created_at TIMESTAMPTZ DEFAULT now()', table_name);",
            "            RAISE NOTICE 'Adicionada coluna created_at na tabela %', table_name;",
            "        END IF;",
            "",
            "        -- Adicionar updated_at se não existir",
            "        IF NOT EXISTS (",
            "            SELECT 1 FROM information_schema.columns",
            "            WHERE table_name = table_name AND column_name = 'updated_at'",
            "        ) THEN",
            "            EXECUTE format('ALTER TABLE %I ADD COLUMN updated_at TIMESTAMPTZ DEFAULT now()', table_name);",
            "            RAISE NOTICE 'Adicionada coluna updated_at na tabela %', table_name;",
            "        END IF;",
            "    END LOOP;",
            "END $$;",
            "",
            "-- Criar função para atualizar updated_at automaticamente",
            "CREATE OR REPLACE FUNCTION update_updated_at_column()",
            "RETURNS TRIGGER AS $$",
            "BEGIN",
            "    NEW.updated_at = now();",
            "    RETURN NEW;",
            "END;",
            "$$ language 'plpgsql';",
            "",
            "-- Criar triggers para todas as tabelas",
            "DO $$",
            "DECLARE",
            "    table_name TEXT;",
            "    table_names TEXT[] := ARRAY[",
        ])
        
        script_lines.append("        " + ",\n        ".join(table_list))
        
        script_lines.extend([
            "    ];",
            "BEGIN",
            "    FOREACH table_name IN ARRAY table_names LOOP",
            "        EXECUTE format(",
            "            'CREATE TRIGGER trigger_update_%I_updated_at ' ||",
            "            'BEFORE UPDATE ON %I ' ||",
            "            'FOR EACH ROW EXECUTE FUNCTION update_updated_at_column()',",
            "            table_name, table_name",
            "        );",
            "        RAISE NOTICE 'Trigger criado para tabela %', table_name;",
            "    END LOOP;",
            "EXCEPTION",
            "    WHEN duplicate_object THEN",
            "        RAISE NOTICE 'Triggers já existem, pulando criação.';",
            "END $$;",
            "",
            "-- Script de migração concluído!",
        ])
        
        return "\n".join(script_lines)
    
    def create_all_scripts(self):
        """Criar todos os scripts de banco de dados"""
        print("GERAÇÃO DE SCRIPTS DE BANCO DE DADOS")
        print("=" * 50)
        
        # Ler e processar DBML
        self.read_dbml_file()
        self.tables = self.parse_dbml_tables()
        
        # Criar diretório de scripts
        self.scripts_dir.mkdir(exist_ok=True)
        
        # Gerar script de criação
        create_script = self.generate_create_database_script()
        create_file = self.scripts_dir / "01_create_database.sql"
        with open(create_file, 'w', encoding='utf-8') as f:
            f.write(create_script)
        print(f"Script de criação salvo: {create_file}")
        
        # Gerar script de dados de exemplo
        sample_script = self.generate_sample_data_script()
        sample_file = self.scripts_dir / "02_sample_data.sql"
        with open(sample_file, 'w', encoding='utf-8') as f:
            f.write(sample_script)
        print(f"Script de dados de exemplo salvo: {sample_file}")
        
        # Gerar script de migração
        migration_script = self.generate_migration_script()
        migration_file = self.scripts_dir / "03_migration.sql"
        with open(migration_file, 'w', encoding='utf-8') as f:
            f.write(migration_script)
        print(f"Script de migração salvo: {migration_file}")
        
        # Criar script de execução
        self.create_execution_script()
        
        print(f"\nSUCESSO: Todos os scripts foram gerados em {self.scripts_dir}")
        print(f"Total de tabelas processadas: {len(self.tables)}")
        
        return True
    
    def create_execution_script(self):
        """Criar script de execução dos scripts SQL"""
        exec_script = self.scripts_dir / "run_scripts.sh"
        
        script_content = f"""#!/bin/bash
# Script de Execução dos Scripts de Banco de Dados
# Sistema de Governança de Dados V1.0

set -e  # Parar em caso de erro

# Configurações do banco
DB_HOST="${{DB_HOST:-localhost}}"
DB_PORT="${{DB_PORT:-5432}}"
DB_NAME="${{DB_NAME:-governance_system}}"
DB_USER="${{DB_USER:-governance_user}}"

echo "Executando scripts de banco de dados..."
echo "Host: $DB_HOST:$DB_PORT"
echo "Database: $DB_NAME"
echo "User: $DB_USER"
echo

# Verificar se psql está disponível
if ! command -v psql &> /dev/null; then
    echo "ERRO: psql não encontrado. Instale o PostgreSQL client."
    exit 1
fi

# Função para executar script SQL
execute_sql() {{
    local script_file=$1
    local description=$2
    
    echo "Executando: $description"
    echo "Arquivo: $script_file"
    
    if [ -f "$script_file" ]; then
        psql -h "$DB_HOST" -p "$DB_PORT" -d "$DB_NAME" -U "$DB_USER" -f "$script_file"
        echo "✓ $description concluído com sucesso"
        echo
    else
        echo "✗ ERRO: Arquivo $script_file não encontrado"
        exit 1
    fi
}}

# Executar scripts na ordem correta
echo "Iniciando execução dos scripts..."
echo

execute_sql "01_create_database.sql" "Criação das tabelas"
execute_sql "02_sample_data.sql" "Inserção de dados de exemplo"
execute_sql "03_migration.sql" "Aplicação de migrações"

echo "Todos os scripts foram executados com sucesso!"
echo "O banco de dados está pronto para uso."
"""
        
        with open(exec_script, 'w', encoding='utf-8') as f:
            f.write(script_content)
        
        # Tornar executável
        exec_script.chmod(0o755)
        
        print(f"Script de execução criado: {exec_script}")


def main():
    # Localizar arquivo DBML
    dbml_file = "database/modelo_estendido.dbml"
    
    if not Path(dbml_file).exists():
        print(f"ERRO: Arquivo {dbml_file} não encontrado!")
        return False
    
    # Gerar scripts
    generator = DatabaseScriptGenerator(dbml_file)
    success = generator.create_all_scripts()
    
    if success:
        print("\nSUCESSO: Scripts de banco de dados gerados com sucesso!")
        print("Para executar:")
        print("1. Configure as variáveis de ambiente (DB_HOST, DB_PORT, etc.)")
        print("2. Execute: cd database/scripts && ./run_scripts.sh")
    
    return success


if __name__ == "__main__":
    main()

