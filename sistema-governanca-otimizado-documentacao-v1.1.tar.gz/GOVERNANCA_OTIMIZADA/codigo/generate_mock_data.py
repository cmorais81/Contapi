#!/usr/bin/env python3
"""
Gerador de Dados Mock Realistas para Camada de Governança de Dados
Gera dados de teste para todas as 43 tabelas do modelo DBML
"""

import json
import random
import uuid
from datetime import datetime, timedelta
from typing import Dict, List, Any
import os
import psycopg2
from faker import Faker

class MockDataGenerator:
    def __init__(self):
        self.fake = Faker(['pt_BR', 'en_US'])
        self.output_dir = "mock_data"
        os.makedirs(self.output_dir, exist_ok=True)
        
        # Configurações de banco
        self.db_config = {
            'host': 'localhost',
            'database': 'governance_system',
            'user': 'governance_user',
            'password': 'governance_pass'
        }
        
        # Dados de referência
        self.domains = ['Finance', 'Marketing', 'Sales', 'Operations', 'HR', 'IT', 'Legal', 'Compliance']
        self.data_types = ['STRING', 'INTEGER', 'FLOAT', 'BOOLEAN', 'DATE', 'TIMESTAMP', 'JSON', 'ARRAY']
        self.quality_dimensions = ['Completeness', 'Accuracy', 'Consistency', 'Validity', 'Timeliness', 'Uniqueness']
        self.frameworks = ['GDPR', 'SOX', 'PCI-DSS', 'HIPAA', 'CCPA', 'LGPD', 'Basel III', 'IFRS']
        
        # Contadores para IDs
        self.counters = {}
        
    def get_next_id(self, table: str) -> int:
        """Gera próximo ID sequencial para uma tabela"""
        if table not in self.counters:
            self.counters[table] = 1
        else:
            self.counters[table] += 1
        return self.counters[table]
    
    def generate_timestamp(self, days_back: int = 365) -> str:
        """Gera timestamp aleatório"""
        if days_back < 0:
            # Para datas futuras
            start_date = datetime.now()
            end_date = datetime.now() + timedelta(days=abs(days_back))
        else:
            # Para datas passadas
            start_date = datetime.now() - timedelta(days=days_back)
            end_date = datetime.now()
        
        total_seconds = int((end_date - start_date).total_seconds())
        if total_seconds <= 0:
            return datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        random_date = start_date + timedelta(
            seconds=random.randint(0, total_seconds)
        )
        return random_date.strftime('%Y-%m-%d %H:%M:%S')
    
    def generate_users(self, count: int = 100) -> List[Dict]:
        """Gera dados para tabela users"""
        users = []
        for _ in range(count):
            user = {
                'id': self.get_next_id('users'),
                'username': self.fake.user_name(),
                'email': self.fake.email(),
                'full_name': self.fake.name(),
                'department': random.choice(self.domains),
                'role': random.choice(['Analyst', 'Manager', 'Director', 'Admin', 'Viewer']),
                'is_active': random.choice([True, False]),
                'last_login': self.generate_timestamp(30),
                'created_at': self.generate_timestamp(),
                'updated_at': self.generate_timestamp(30)
            }
            users.append(user)
        return users
    
    def generate_data_domains(self, count: int = 20) -> List[Dict]:
        """Gera dados para tabela data_domains"""
        domains = []
        for i, domain_name in enumerate(self.domains * 3):  # Repetir para ter mais dados
            if i >= count:
                break
            domain = {
                'id': self.get_next_id('data_domains'),
                'name': f"{domain_name}_Domain_{i+1}",
                'description': f"Domain for {domain_name} related data and processes",
                'owner_id': random.randint(1, 100),
                'parent_domain_id': random.choice([None, random.randint(1, max(1, i))]),
                'is_active': True,
                'created_at': self.generate_timestamp(),
                'updated_at': self.generate_timestamp(30)
            }
            domains.append(domain)
        return domains
    
    def generate_data_contracts(self, count: int = 50) -> List[Dict]:
        """Gera dados para tabela data_contracts"""
        contracts = []
        for _ in range(count):
            contract = {
                'id': self.get_next_id('data_contracts'),
                'name': f"Contract_{self.fake.word()}_{random.randint(1000, 9999)}",
                'version': f"{random.randint(1, 5)}.{random.randint(0, 9)}.{random.randint(0, 9)}",
                'description': self.fake.text(max_nb_chars=200),
                'domain_id': random.randint(1, 20),
                'owner_id': random.randint(1, 100),
                'status': random.choice(['DRAFT', 'ACTIVE', 'DEPRECATED', 'RETIRED']),
                'schema_definition': json.dumps({
                    'type': 'object',
                    'properties': {
                        'id': {'type': 'integer'},
                        'name': {'type': 'string'},
                        'value': {'type': 'number'}
                    }
                }),
                'sla_requirements': json.dumps({
                    'availability': '99.9%',
                    'response_time': '< 2s',
                    'data_freshness': '< 1h'
                }),
                'effective_date': self.generate_timestamp(90),
                'expiration_date': self.generate_timestamp(-30),  # Futuro
                'created_at': self.generate_timestamp(),
                'updated_at': self.generate_timestamp(30)
            }
            contracts.append(contract)
        return contracts
    
    def generate_datasets(self, count: int = 200) -> List[Dict]:
        """Gera dados para tabela datasets"""
        datasets = []
        for _ in range(count):
            dataset = {
                'id': self.get_next_id('datasets'),
                'name': f"dataset_{self.fake.word()}_{random.randint(100, 999)}",
                'description': self.fake.text(max_nb_chars=300),
                'domain_id': random.randint(1, 20),
                'owner_id': random.randint(1, 100),
                'steward_id': random.randint(1, 100),
                'source_system': random.choice(['SAP', 'Salesforce', 'Oracle', 'MySQL', 'MongoDB', 'Kafka']),
                'location': f"s3://data-lake/raw/{self.fake.word()}/",
                'format': random.choice(['PARQUET', 'JSON', 'CSV', 'AVRO', 'DELTA']),
                'size_bytes': random.randint(1024, 1073741824),  # 1KB to 1GB
                'row_count': random.randint(100, 1000000),
                'schema_version': f"{random.randint(1, 3)}.{random.randint(0, 9)}",
                'classification': random.choice(['PUBLIC', 'INTERNAL', 'CONFIDENTIAL', 'RESTRICTED']),
                'tags': json.dumps(random.sample(['finance', 'customer', 'product', 'sales', 'marketing'], k=random.randint(1, 3))),
                'is_active': random.choice([True, False]),
                'last_updated': self.generate_timestamp(7),
                'created_at': self.generate_timestamp(),
                'updated_at': self.generate_timestamp(30)
            }
            datasets.append(dataset)
        return datasets
    
    def generate_data_quality_rules(self, count: int = 150) -> List[Dict]:
        """Gera dados para tabela data_quality_rules"""
        rules = []
        rule_types = ['NOT_NULL', 'UNIQUE', 'RANGE', 'PATTERN', 'REFERENCE', 'CUSTOM']
        
        for _ in range(count):
            rule = {
                'id': self.get_next_id('data_quality_rules'),
                'name': f"rule_{self.fake.word()}_{random.randint(100, 999)}",
                'description': f"Quality rule for {random.choice(self.quality_dimensions).lower()} validation",
                'rule_type': random.choice(rule_types),
                'dataset_id': random.randint(1, 200),
                'column_name': random.choice(['id', 'name', 'email', 'amount', 'date', 'status']),
                'rule_definition': json.dumps({
                    'condition': 'NOT NULL',
                    'threshold': random.uniform(0.8, 1.0),
                    'parameters': {'min_value': 0, 'max_value': 1000}
                }),
                'severity': random.choice(['LOW', 'MEDIUM', 'HIGH', 'CRITICAL']),
                'is_active': True,
                'created_by': random.randint(1, 100),
                'created_at': self.generate_timestamp(),
                'updated_at': self.generate_timestamp(30)
            }
            rules.append(rule)
        return rules
    
    def generate_quality_checks(self, count: int = 500) -> List[Dict]:
        """Gera dados para tabela quality_checks"""
        checks = []
        for _ in range(count):
            check = {
                'id': self.get_next_id('quality_checks'),
                'rule_id': random.randint(1, 150),
                'dataset_id': random.randint(1, 200),
                'execution_time': self.generate_timestamp(30),
                'status': random.choice(['PASSED', 'FAILED', 'WARNING', 'ERROR']),
                'score': round(random.uniform(0.0, 1.0), 3),
                'records_checked': random.randint(100, 100000),
                'records_failed': random.randint(0, 1000),
                'error_message': self.fake.sentence() if random.choice([True, False]) else None,
                'execution_duration_ms': random.randint(100, 30000),
                'created_at': self.generate_timestamp(),
                'updated_at': self.generate_timestamp(30)
            }
            checks.append(check)
        return checks
    
    def generate_lineage_nodes(self, count: int = 300) -> List[Dict]:
        """Gera dados para tabela lineage_nodes"""
        nodes = []
        node_types = ['TABLE', 'VIEW', 'COLUMN', 'TRANSFORMATION', 'REPORT', 'API']
        
        for _ in range(count):
            node = {
                'id': self.get_next_id('lineage_nodes'),
                'name': f"node_{self.fake.word()}_{random.randint(100, 999)}",
                'type': random.choice(node_types),
                'dataset_id': random.randint(1, 200),
                'system_name': random.choice(['Databricks', 'Snowflake', 'BigQuery', 'Redshift', 'Spark']),
                'location': f"catalog.schema.{self.fake.word()}",
                'metadata': json.dumps({
                    'columns': random.randint(5, 50),
                    'rows': random.randint(1000, 1000000),
                    'last_modified': self.generate_timestamp(7)
                }),
                'is_active': True,
                'created_at': self.generate_timestamp(),
                'updated_at': self.generate_timestamp(30)
            }
            nodes.append(node)
        return nodes
    
    def generate_lineage_edges(self, count: int = 400) -> List[Dict]:
        """Gera dados para tabela lineage_edges"""
        edges = []
        for _ in range(count):
            source_id = random.randint(1, 300)
            target_id = random.randint(1, 300)
            
            # Evitar self-loops
            while target_id == source_id:
                target_id = random.randint(1, 300)
            
            edge = {
                'id': self.get_next_id('lineage_edges'),
                'source_node_id': source_id,
                'target_node_id': target_id,
                'relationship_type': random.choice(['DERIVES_FROM', 'TRANSFORMS_TO', 'AGGREGATES', 'JOINS', 'FILTERS']),
                'transformation_logic': self.fake.sentence(),
                'confidence_score': round(random.uniform(0.7, 1.0), 2),
                'created_at': self.generate_timestamp(),
                'updated_at': self.generate_timestamp(30)
            }
            edges.append(edge)
        return edges
    
    def generate_governance_policies(self, count: int = 80) -> List[Dict]:
        """Gera dados para tabela governance_policies"""
        policies = []
        policy_types = ['ACCESS_CONTROL', 'DATA_RETENTION', 'DATA_CLASSIFICATION', 'PRIVACY', 'QUALITY']
        
        for _ in range(count):
            policy = {
                'id': self.get_next_id('governance_policies'),
                'name': f"policy_{self.fake.word()}_{random.randint(100, 999)}",
                'description': self.fake.text(max_nb_chars=200),
                'type': random.choice(policy_types),
                'domain_id': random.randint(1, 20),
                'owner_id': random.randint(1, 100),
                'policy_definition': json.dumps({
                    'rules': [
                        {'condition': 'classification = CONFIDENTIAL', 'action': 'REQUIRE_APPROVAL'},
                        {'condition': 'age > 7 years', 'action': 'ARCHIVE'}
                    ]
                }),
                'enforcement_level': random.choice(['ADVISORY', 'MANDATORY', 'BLOCKING']),
                'is_active': True,
                'effective_date': self.generate_timestamp(90),
                'review_date': self.generate_timestamp(-30),  # Futuro
                'created_at': self.generate_timestamp(),
                'updated_at': self.generate_timestamp(30)
            }
            policies.append(policy)
        return policies
    
    def generate_compliance_frameworks(self, count: int = 15) -> List[Dict]:
        """Gera dados para tabela compliance_frameworks"""
        frameworks = []
        for i, framework_name in enumerate(self.frameworks):
            if i >= count:
                break
            framework = {
                'id': self.get_next_id('compliance_frameworks'),
                'name': framework_name,
                'description': f"Compliance framework for {framework_name} regulations",
                'version': f"{random.randint(1, 3)}.{random.randint(0, 9)}",
                'authority': self.fake.company(),
                'requirements': json.dumps([
                    f"Requirement {i+1}: {self.fake.sentence()}" for i in range(random.randint(3, 8))
                ]),
                'is_active': True,
                'created_at': self.generate_timestamp(),
                'updated_at': self.generate_timestamp(30)
            }
            frameworks.append(framework)
        return frameworks
    
    def generate_audit_logs(self, count: int = 1000) -> List[Dict]:
        """Gera dados para tabela audit_logs"""
        logs = []
        actions = ['CREATE', 'READ', 'UPDATE', 'DELETE', 'APPROVE', 'REJECT', 'EXECUTE']
        resources = ['CONTRACT', 'DATASET', 'POLICY', 'RULE', 'USER', 'DOMAIN']
        
        for _ in range(count):
            log = {
                'id': self.get_next_id('audit_logs'),
                'user_id': random.randint(1, 100),
                'action': random.choice(actions),
                'resource_type': random.choice(resources),
                'resource_id': random.randint(1, 1000),
                'details': json.dumps({
                    'ip_address': self.fake.ipv4(),
                    'user_agent': self.fake.user_agent(),
                    'session_id': str(uuid.uuid4())
                }),
                'result': random.choice(['SUCCESS', 'FAILURE', 'PARTIAL']),
                'timestamp': self.generate_timestamp(90),
                'created_at': self.generate_timestamp(),
                'updated_at': self.generate_timestamp(30)
            }
            logs.append(log)
        return logs
    
    def generate_all_mock_data(self) -> Dict[str, List[Dict]]:
        """Gera todos os dados mock"""
        print("Gerando dados mock para todas as tabelas...")
        
        mock_data = {
            'users': self.generate_users(100),
            'data_domains': self.generate_data_domains(20),
            'data_contracts': self.generate_data_contracts(50),
            'datasets': self.generate_datasets(200),
            'data_quality_rules': self.generate_data_quality_rules(150),
            'quality_checks': self.generate_quality_checks(500),
            'lineage_nodes': self.generate_lineage_nodes(300),
            'lineage_edges': self.generate_lineage_edges(400),
            'governance_policies': self.generate_governance_policies(80),
            'compliance_frameworks': self.generate_compliance_frameworks(15),
            'audit_logs': self.generate_audit_logs(1000)
        }
        
        # Adicionar mais tabelas conforme necessário
        additional_tables = [
            'data_stewards', 'access_requests', 'workflow_instances', 'notifications',
            'metadata_attributes', 'security_classifications', 'integration_configs',
            'analytics_reports', 'monitoring_metrics', 'configuration_settings',
            'scheduled_jobs', 'search_indexes', 'migration_plans', 'validation_results',
            'discovery_scans', 'transformation_rules', 'backup_policies', 'privacy_requests',
            'compliance_assessments', 'version_history', 'test_cases', 'documentation_pages',
            'performance_metrics', 'deployment_configs', 'report_templates'
        ]
        
        for table in additional_tables:
            mock_data[table] = self.generate_generic_table_data(table, random.randint(20, 100))
        
        return mock_data
    
    def generate_generic_table_data(self, table_name: str, count: int) -> List[Dict]:
        """Gera dados genéricos para tabelas adicionais"""
        data = []
        for _ in range(count):
            record = {
                'id': self.get_next_id(table_name),
                'name': f"{table_name}_{self.fake.word()}_{random.randint(100, 999)}",
                'description': self.fake.text(max_nb_chars=150),
                'status': random.choice(['ACTIVE', 'INACTIVE', 'PENDING', 'COMPLETED']),
                'created_at': self.generate_timestamp(),
                'updated_at': self.generate_timestamp(30)
            }
            data.append(record)
        return data
    
    def save_mock_data(self, mock_data: Dict[str, List[Dict]]):
        """Salva os dados mock em arquivos JSON"""
        print("Salvando dados mock em arquivos...")
        
        # Salvar cada tabela em arquivo separado
        for table_name, data in mock_data.items():
            filename = f"{self.output_dir}/{table_name}.json"
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False, default=str)
            print(f"Salvo: {filename} ({len(data)} registros)")
        
        # Salvar arquivo consolidado
        consolidated_file = f"{self.output_dir}/all_mock_data.json"
        with open(consolidated_file, 'w', encoding='utf-8') as f:
            json.dump(mock_data, f, indent=2, ensure_ascii=False, default=str)
        
        # Gerar estatísticas
        stats = {
            'total_tables': len(mock_data),
            'total_records': sum(len(data) for data in mock_data.values()),
            'tables': {table: len(data) for table, data in mock_data.items()},
            'generated_at': datetime.now().isoformat()
        }
        
        stats_file = f"{self.output_dir}/mock_data_stats.json"
        with open(stats_file, 'w', encoding='utf-8') as f:
            json.dump(stats, f, indent=2, ensure_ascii=False)
        
        print(f"\nEstatísticas:")
        print(f"- Total de tabelas: {stats['total_tables']}")
        print(f"- Total de registros: {stats['total_records']}")
        print(f"- Arquivos salvos em: {self.output_dir}/")
    
    def generate_sql_inserts(self, mock_data: Dict[str, List[Dict]]):
        """Gera scripts SQL de INSERT"""
        print("Gerando scripts SQL de INSERT...")
        
        sql_file = f"{self.output_dir}/insert_mock_data.sql"
        with open(sql_file, 'w', encoding='utf-8') as f:
            f.write("-- Script de INSERT para dados mock\n")
            f.write("-- Gerado automaticamente\n\n")
            f.write("BEGIN;\n\n")
            
            for table_name, records in mock_data.items():
                if not records:
                    continue
                
                f.write(f"-- Inserindo dados em {table_name}\n")
                
                # Obter colunas do primeiro registro
                columns = list(records[0].keys())
                columns_str = ', '.join(columns)
                
                for record in records:
                    values = []
                    for col in columns:
                        value = record[col]
                        if value is None:
                            values.append('NULL')
                        elif isinstance(value, str):
                            # Escapar aspas simples
                            escaped_value = value.replace("'", "''")
                            values.append(f"'{escaped_value}'")
                        elif isinstance(value, bool):
                            values.append('TRUE' if value else 'FALSE')
                        elif isinstance(value, (dict, list)):
                            # JSON
                            json_str = json.dumps(value).replace("'", "''")
                            values.append(f"'{json_str}'")
                        else:
                            values.append(str(value))
                    
                    values_str = ', '.join(values)
                    f.write(f"INSERT INTO {table_name} ({columns_str}) VALUES ({values_str});\n")
                
                f.write(f"\n")
            
            f.write("COMMIT;\n")
        
        print(f"Script SQL salvo em: {sql_file}")
    
    def test_database_connection(self) -> bool:
        """Testa conexão com o banco de dados"""
        try:
            conn = psycopg2.connect(**self.db_config)
            cursor = conn.cursor()
            cursor.execute("SELECT version();")
            version = cursor.fetchone()
            print(f"Conexão com PostgreSQL estabelecida: {version[0]}")
            cursor.close()
            conn.close()
            return True
        except Exception as e:
            print(f"Erro ao conectar com o banco: {e}")
            return False
    
    def load_data_to_database(self, mock_data: Dict[str, List[Dict]]):
        """Carrega dados mock no banco de dados"""
        if not self.test_database_connection():
            print("Não foi possível conectar ao banco. Dados salvos apenas em arquivos.")
            return
        
        print("Carregando dados mock no banco de dados...")
        
        try:
            conn = psycopg2.connect(**self.db_config)
            cursor = conn.cursor()
            
            # Desabilitar constraints temporariamente
            cursor.execute("SET session_replication_role = replica;")
            
            for table_name, records in mock_data.items():
                if not records:
                    continue
                
                print(f"Carregando {len(records)} registros em {table_name}...")
                
                # Verificar se a tabela existe
                cursor.execute("""
                    SELECT EXISTS (
                        SELECT FROM information_schema.tables 
                        WHERE table_name = %s
                    );
                """, (table_name,))
                
                if not cursor.fetchone()[0]:
                    print(f"Tabela {table_name} não existe. Pulando...")
                    continue
                
                # Inserir dados
                columns = list(records[0].keys())
                placeholders = ', '.join(['%s'] * len(columns))
                insert_sql = f"INSERT INTO {table_name} ({', '.join(columns)}) VALUES ({placeholders})"
                
                for record in records:
                    values = [record[col] for col in columns]
                    try:
                        cursor.execute(insert_sql, values)
                    except Exception as e:
                        print(f"Erro ao inserir em {table_name}: {e}")
                        continue
            
            # Reabilitar constraints
            cursor.execute("SET session_replication_role = DEFAULT;")
            
            conn.commit()
            cursor.close()
            conn.close()
            
            print("Dados carregados com sucesso no banco de dados!")
            
        except Exception as e:
            print(f"Erro ao carregar dados no banco: {e}")

def main():
    """Função principal"""
    generator = MockDataGenerator()
    
    print("Iniciando geração de dados mock...")
    
    # Gerar dados
    mock_data = generator.generate_all_mock_data()
    
    # Salvar em arquivos
    generator.save_mock_data(mock_data)
    
    # Gerar scripts SQL
    generator.generate_sql_inserts(mock_data)
    
    # Tentar carregar no banco (opcional)
    generator.load_data_to_database(mock_data)
    
    print("\nGeração de dados mock concluída!")
    print(f"Arquivos salvos em: {generator.output_dir}/")
    
    return True

if __name__ == "__main__":
    main()

