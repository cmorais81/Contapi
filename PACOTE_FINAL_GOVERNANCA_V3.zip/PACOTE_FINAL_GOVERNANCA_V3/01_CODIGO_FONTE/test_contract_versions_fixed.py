#!/usr/bin/env python3
"""
Teste de Versionamento de Contratos de Dados - Versão Corrigida
Desenvolvido por: Carlos Morais
Data: Janeiro 2025
"""

import requests
import json
import uuid
from datetime import datetime
import time

class ContractVersionTester:
    def __init__(self, base_url="http://localhost:8001"):
        self.base_url = base_url
        self.headers = {"Content-Type": "application/json"}
        self.test_results = []
        
    def log_result(self, test_name, success, details):
        """Log do resultado do teste"""
        result = {
            "test_name": test_name,
            "success": success,
            "details": details,
            "timestamp": datetime.now().isoformat()
        }
        self.test_results.append(result)
        status = "✅" if success else "❌"
        print(f"{status} {test_name}: {details}")
    
    def create_contract_v1(self):
        """Criar contrato versão 1.0"""
        contract_data = {
            "name": "customer_data_contract_v1",
            "description": "Contrato de dados de clientes - Versão 1.0",
            "domain": "customer_domain",
            "steward": "data_team",
            "status": "active",
            "unity_catalog_path": "prod.customer.customer_data_v1",
            "schema_definition": {
                "type": "object",
                "properties": {
                    "customer_id": {
                        "type": "integer",
                        "description": "ID único do cliente"
                    },
                    "name": {
                        "type": "string",
                        "description": "Nome completo do cliente"
                    },
                    "email": {
                        "type": "string",
                        "format": "email",
                        "description": "Email do cliente"
                    },
                    "created_at": {
                        "type": "string",
                        "format": "date-time",
                        "description": "Data de criação do registro"
                    }
                },
                "required": ["customer_id", "name", "email"]
            },
            "quality_rules": [
                {
                    "field": "email",
                    "rule": "format_validation",
                    "description": "Email deve ter formato válido"
                },
                {
                    "field": "customer_id",
                    "rule": "uniqueness",
                    "description": "ID do cliente deve ser único"
                }
            ],
            "sla_definition": {
                "availability": "99.9%",
                "freshness": "24h",
                "completeness": "95%"
            }
        }
        
        try:
            response = requests.post(
                f"{self.base_url}/api/v1/contracts/",
                headers=self.headers,
                json=contract_data,
                timeout=10
            )
            
            if response.status_code in [200, 201]:
                contract = response.json()
                contract_id = contract.get('id')
                self.log_result("Criar Contrato V1", True, f"Contrato V1 criado: {contract_id}")
                return contract_id
            else:
                self.log_result("Criar Contrato V1", False, f"Status: {response.status_code} - {response.text}")
                return None
                
        except Exception as e:
            self.log_result("Criar Contrato V1", False, f"Erro: {str(e)}")
            return None
    
    def create_contract_v2(self):
        """Criar contrato versão 2.0 (evolução)"""
        contract_data = {
            "name": "customer_data_contract_v2",
            "description": "Contrato de dados de clientes - Versão 2.0 (Evoluído)",
            "domain": "customer_domain",
            "steward": "data_team",
            "status": "active",
            "unity_catalog_path": "prod.customer.customer_data_v2",
            "schema_definition": {
                "type": "object",
                "properties": {
                    "customer_id": {
                        "type": "integer",
                        "description": "ID único do cliente"
                    },
                    "name": {
                        "type": "string",
                        "description": "Nome completo do cliente"
                    },
                    "email": {
                        "type": "string",
                        "format": "email",
                        "description": "Email do cliente"
                    },
                    "phone": {
                        "type": "string",
                        "description": "Telefone do cliente (novo campo)"
                    },
                    "address": {
                        "type": "object",
                        "properties": {
                            "street": {"type": "string"},
                            "city": {"type": "string"},
                            "country": {"type": "string"},
                            "postal_code": {"type": "string"}
                        },
                        "description": "Endereço completo do cliente (novo campo)"
                    },
                    "status": {
                        "type": "string",
                        "enum": ["active", "inactive", "suspended"],
                        "description": "Status do cliente (novo campo)"
                    },
                    "created_at": {
                        "type": "string",
                        "format": "date-time",
                        "description": "Data de criação do registro"
                    },
                    "updated_at": {
                        "type": "string",
                        "format": "date-time",
                        "description": "Data de última atualização (novo campo)"
                    }
                },
                "required": ["customer_id", "name", "email", "status"]
            },
            "quality_rules": [
                {
                    "field": "email",
                    "rule": "format_validation",
                    "description": "Email deve ter formato válido"
                },
                {
                    "field": "customer_id",
                    "rule": "uniqueness",
                    "description": "ID do cliente deve ser único"
                },
                {
                    "field": "phone",
                    "rule": "format_validation",
                    "description": "Telefone deve ter formato válido (novo)"
                },
                {
                    "field": "status",
                    "rule": "enum_validation",
                    "description": "Status deve ser um dos valores permitidos (novo)"
                }
            ],
            "sla_definition": {
                "availability": "99.95%",
                "freshness": "12h",
                "completeness": "98%",
                "accuracy": "99%"
            }
        }
        
        try:
            response = requests.post(
                f"{self.base_url}/api/v1/contracts/",
                headers=self.headers,
                json=contract_data,
                timeout=10
            )
            
            if response.status_code in [200, 201]:
                contract = response.json()
                contract_id = contract.get('id')
                self.log_result("Criar Contrato V2", True, f"Contrato V2 criado: {contract_id}")
                return contract_id
            else:
                self.log_result("Criar Contrato V2", False, f"Status: {response.status_code} - {response.text}")
                return None
                
        except Exception as e:
            self.log_result("Criar Contrato V2", False, f"Erro: {str(e)}")
            return None
    
    def test_contract_retrieval(self, contract_id, version):
        """Testar recuperação do contrato"""
        try:
            response = requests.get(
                f"{self.base_url}/api/v1/contracts/{contract_id}",
                headers=self.headers,
                timeout=10
            )
            
            if response.status_code == 200:
                contract = response.json()
                self.log_result(f"Recuperar Contrato {version}", True, f"Contrato recuperado: {contract.get('name', 'N/A')}")
                return contract
            else:
                self.log_result(f"Recuperar Contrato {version}", False, f"Status: {response.status_code}")
                return None
                
        except Exception as e:
            self.log_result(f"Recuperar Contrato {version}", False, f"Erro: {str(e)}")
            return None
    
    def test_contract_validation(self, contract_id, version):
        """Testar validação do contrato"""
        try:
            response = requests.post(
                f"{self.base_url}/api/v1/contracts/{contract_id}/validate",
                headers=self.headers,
                timeout=10
            )
            
            if response.status_code == 200:
                validation = response.json()
                self.log_result(f"Validar Contrato {version}", True, f"Validação: {validation.get('status', 'N/A')}")
                return validation
            else:
                self.log_result(f"Validar Contrato {version}", False, f"Status: {response.status_code}")
                return None
                
        except Exception as e:
            self.log_result(f"Validar Contrato {version}", False, f"Erro: {str(e)}")
            return None
    
    def test_odcs_export(self, contract_id, version):
        """Testar exportação ODCS"""
        try:
            response = requests.get(
                f"{self.base_url}/api/v1/contracts/{contract_id}/odcs",
                headers=self.headers,
                timeout=10
            )
            
            if response.status_code == 200:
                odcs_data = response.json()
                self.log_result(f"Exportar ODCS {version}", True, f"ODCS exportado com sucesso")
                return odcs_data
            else:
                self.log_result(f"Exportar ODCS {version}", False, f"Status: {response.status_code}")
                return None
                
        except Exception as e:
            self.log_result(f"Exportar ODCS {version}", False, f"Erro: {str(e)}")
            return None
    
    def test_contracts_listing(self):
        """Testar listagem de contratos"""
        try:
            response = requests.get(
                f"{self.base_url}/api/v1/contracts/",
                headers=self.headers,
                timeout=10
            )
            
            if response.status_code == 200:
                contracts = response.json()
                count = len(contracts) if isinstance(contracts, list) else 0
                self.log_result("Listar Contratos", True, f"Encontrados {count} contratos")
                return contracts
            else:
                self.log_result("Listar Contratos", False, f"Status: {response.status_code}")
                return None
                
        except Exception as e:
            self.log_result("Listar Contratos", False, f"Erro: {str(e)}")
            return None
    
    def compare_contract_versions(self, contract_v1_id, contract_v2_id):
        """Comparar as duas versões de contrato"""
        print("\n🔍 COMPARAÇÃO ENTRE VERSÕES:")
        print("-" * 40)
        
        # Recuperar ambos os contratos
        contract_v1 = self.test_contract_retrieval(contract_v1_id, "V1")
        contract_v2 = self.test_contract_retrieval(contract_v2_id, "V2")
        
        if contract_v1 and contract_v2:
            # Comparar schemas
            schema_v1 = contract_v1.get('schema_definition', {}).get('properties', {})
            schema_v2 = contract_v2.get('schema_definition', {}).get('properties', {})
            
            fields_v1 = set(schema_v1.keys())
            fields_v2 = set(schema_v2.keys())
            
            new_fields = fields_v2 - fields_v1
            removed_fields = fields_v1 - fields_v2
            common_fields = fields_v1 & fields_v2
            
            print(f"📊 Campos V1: {len(fields_v1)} ({', '.join(fields_v1)})")
            print(f"📊 Campos V2: {len(fields_v2)} ({', '.join(fields_v2)})")
            print(f"🆕 Novos campos: {len(new_fields)} ({', '.join(new_fields)})")
            print(f"❌ Campos removidos: {len(removed_fields)} ({', '.join(removed_fields)})")
            print(f"🔄 Campos comuns: {len(common_fields)}")
            
            # Comparar regras de qualidade
            rules_v1 = len(contract_v1.get('quality_rules', []))
            rules_v2 = len(contract_v2.get('quality_rules', []))
            
            print(f"📋 Regras V1: {rules_v1}")
            print(f"📋 Regras V2: {rules_v2}")
            
            # Comparar SLAs
            sla_v1 = contract_v1.get('sla_definition', {})
            sla_v2 = contract_v2.get('sla_definition', {})
            
            print(f"⚡ SLA V1: {sla_v1}")
            print(f"⚡ SLA V2: {sla_v2}")
            
            self.log_result("Comparação de Versões", True, f"V1: {len(fields_v1)} campos, V2: {len(fields_v2)} campos")
        else:
            self.log_result("Comparação de Versões", False, "Não foi possível recuperar ambos os contratos")
    
    def run_all_tests(self):
        """Executar todos os testes de versionamento"""
        print("🚀 Iniciando Testes de Versionamento de Contratos")
        print("=" * 60)
        
        # 1. Criar contrato V1
        contract_v1_id = self.create_contract_v1()
        
        # 2. Criar contrato V2
        contract_v2_id = self.create_contract_v2()
        
        # 3. Testar listagem
        self.test_contracts_listing()
        
        # 4. Testar validação (se os contratos foram criados)
        if contract_v1_id:
            self.test_contract_validation(contract_v1_id, "V1")
            self.test_odcs_export(contract_v1_id, "V1")
        
        if contract_v2_id:
            self.test_contract_validation(contract_v2_id, "V2")
            self.test_odcs_export(contract_v2_id, "V2")
        
        # 5. Comparar versões
        if contract_v1_id and contract_v2_id:
            self.compare_contract_versions(contract_v1_id, contract_v2_id)
        
        # Gerar relatório
        self.generate_report()
        
        return True
    
    def generate_report(self):
        """Gerar relatório dos testes"""
        print("\n" + "=" * 60)
        print("📊 RELATÓRIO DE TESTES DE VERSIONAMENTO")
        print("=" * 60)
        
        total_tests = len(self.test_results)
        successful_tests = sum(1 for result in self.test_results if result['success'])
        failed_tests = total_tests - successful_tests
        
        print(f"📋 Total de Testes: {total_tests}")
        print(f"✅ Sucessos: {successful_tests}")
        print(f"❌ Falhas: {failed_tests}")
        print(f"📊 Taxa de Sucesso: {(successful_tests/total_tests)*100:.1f}%")
        
        print("\n📝 Detalhes dos Testes:")
        for result in self.test_results:
            status = "✅" if result['success'] else "❌"
            print(f"  {status} {result['test_name']}: {result['details']}")
        
        # Salvar relatório em arquivo
        report_data = {
            "summary": {
                "total_tests": total_tests,
                "successful_tests": successful_tests,
                "failed_tests": failed_tests,
                "success_rate": (successful_tests/total_tests)*100 if total_tests > 0 else 0
            },
            "test_results": self.test_results,
            "generated_at": datetime.now().isoformat()
        }
        
        with open("contract_version_test_report.json", "w") as f:
            json.dump(report_data, f, indent=2)
        
        print(f"\n📁 Relatório salvo em: contract_version_test_report.json")

def main():
    """Função principal"""
    tester = ContractVersionTester()
    
    # Verificar se API está disponível
    try:
        response = requests.get(f"{tester.base_url}/health", timeout=5)
        if response.status_code != 200:
            print("❌ API não está disponível. Verifique se está rodando.")
            return
        print("✅ API está disponível e respondendo")
    except Exception as e:
        print(f"❌ Erro ao conectar com a API: {e}")
        return
    
    # Executar testes
    success = tester.run_all_tests()
    
    if success:
        print("\n🎉 Testes de versionamento concluídos!")
    else:
        print("\n⚠️ Testes concluídos com problemas.")

if __name__ == "__main__":
    main()

