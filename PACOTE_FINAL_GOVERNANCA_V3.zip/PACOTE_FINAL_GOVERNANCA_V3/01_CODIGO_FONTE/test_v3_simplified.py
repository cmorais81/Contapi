#!/usr/bin/env python3
"""
Testes simplificados para API de Governança V3.0
Foco em validação de estrutura e funcionalidades básicas
"""

import json
import requests
import time
from datetime import datetime, timezone
from typing import Dict, List, Any


class GovernanceAPIV3SimplifiedTester:
    """Testador simplificado para API V3.0"""
    
    def __init__(self, base_url: str = "http://localhost:8001"):
        self.base_url = base_url
        self.session = requests.Session()
        self.test_results = []
    
    def log_test(self, test_name: str, status: str, details: str = "", duration_ms: int = 0):
        """Log de resultado de teste"""
        result = {
            "test_name": test_name,
            "status": status,
            "details": details,
            "duration_ms": duration_ms,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
        self.test_results.append(result)
        
        status_emoji = "✅" if status == "PASS" else "❌" if status == "FAIL" else "⚠️"
        print(f"{status_emoji} {test_name}: {status} ({duration_ms}ms)")
        if details:
            print(f"   {details}")
    
    def test_api_health(self) -> bool:
        """Teste de saúde da API"""
        start_time = time.time()
        
        try:
            response = self.session.get(f"{self.base_url}/health", timeout=10)
            duration = int((time.time() - start_time) * 1000)
            
            if response.status_code == 200:
                health_data = response.json()
                self.log_test(
                    "API Health Check", 
                    "PASS", 
                    f"API V3 respondendo: {health_data.get('status', 'unknown')}",
                    duration
                )
                return True
            else:
                self.log_test(
                    "API Health Check", 
                    "FAIL", 
                    f"Status code: {response.status_code}",
                    duration
                )
                return False
                
        except Exception as e:
            duration = int((time.time() - start_time) * 1000)
            self.log_test(
                "API Health Check", 
                "FAIL", 
                f"Erro de conexão: {str(e)}",
                duration
            )
            return False
    
    def test_openapi_schema(self) -> bool:
        """Teste do schema OpenAPI V3"""
        start_time = time.time()
        
        try:
            response = self.session.get(f"{self.base_url}/openapi.json", timeout=10)
            duration = int((time.time() - start_time) * 1000)
            
            if response.status_code == 200:
                openapi_data = response.json()
                
                # Verificar estrutura básica
                required_keys = ["openapi", "info", "paths"]
                missing_keys = [k for k in required_keys if k not in openapi_data]
                
                if missing_keys:
                    self.log_test(
                        "OpenAPI Schema V3", 
                        "FAIL", 
                        f"Chaves faltando: {missing_keys}",
                        duration
                    )
                    return False
                
                # Contar endpoints
                paths_count = len(openapi_data.get("paths", {}))
                
                self.log_test(
                    "OpenAPI Schema V3", 
                    "PASS", 
                    f"Schema válido com {paths_count} endpoints",
                    duration
                )
                return True
            else:
                self.log_test(
                    "OpenAPI Schema V3", 
                    "FAIL", 
                    f"Status code: {response.status_code}",
                    duration
                )
                return False
                
        except Exception as e:
            duration = int((time.time() - start_time) * 1000)
            self.log_test(
                "OpenAPI Schema V3", 
                "FAIL", 
                f"Erro: {str(e)}",
                duration
            )
            return False
    
    def test_docs_interface(self) -> bool:
        """Teste da interface de documentação"""
        start_time = time.time()
        
        try:
            response = self.session.get(f"{self.base_url}/docs", timeout=10)
            duration = int((time.time() - start_time) * 1000)
            
            if response.status_code == 200:
                # Verificar se é HTML válido
                content = response.text
                if "<html" in content.lower() and "swagger" in content.lower():
                    self.log_test(
                        "Documentation Interface", 
                        "PASS", 
                        "Interface Swagger UI carregada",
                        duration
                    )
                    return True
                else:
                    self.log_test(
                        "Documentation Interface", 
                        "FAIL", 
                        "Conteúdo HTML inválido",
                        duration
                    )
                    return False
            else:
                self.log_test(
                    "Documentation Interface", 
                    "FAIL", 
                    f"Status code: {response.status_code}",
                    duration
                )
                return False
                
        except Exception as e:
            duration = int((time.time() - start_time) * 1000)
            self.log_test(
                "Documentation Interface", 
                "FAIL", 
                f"Erro: {str(e)}",
                duration
            )
            return False
    
    def test_v3_data_models(self) -> bool:
        """Teste de validação dos modelos de dados V3"""
        start_time = time.time()
        
        try:
            # Simular estruturas de dados V3
            v3_models = {
                "Domain": {
                    "required_fields": ["id", "name", "display_name", "created_at", "updated_at"],
                    "field_types": {
                        "name": "text",
                        "display_name": "text", 
                        "description": "text",
                        "created_at": "timestamptz",
                        "updated_at": "timestamptz"
                    }
                },
                "Entity": {
                    "required_fields": ["id", "name", "domain_id", "created_at", "updated_at"],
                    "field_types": {
                        "name": "text",
                        "display_name": "text",
                        "description": "text",
                        "entity_type": "text",
                        "created_at": "timestamptz",
                        "updated_at": "timestamptz"
                    }
                },
                "DataContract": {
                    "required_fields": ["id", "name", "version", "domain_id", "owner_id", "created_at", "updated_at"],
                    "field_types": {
                        "name": "text",
                        "display_name": "text",
                        "description": "text",
                        "version": "text",
                        "contract_type": "text",
                        "status": "text",
                        "created_at": "timestamptz",
                        "updated_at": "timestamptz"
                    }
                }
            }
            
            # Validar que todos os modelos têm campos obrigatórios V3
            validation_errors = []
            
            for model_name, model_spec in v3_models.items():
                required_audit_fields = ["created_at", "updated_at"]
                missing_audit = [f for f in required_audit_fields if f not in model_spec["required_fields"]]
                
                if missing_audit:
                    validation_errors.append(f"{model_name}: faltam {missing_audit}")
                
                # Verificar tipos de dados
                for field, expected_type in model_spec["field_types"].items():
                    if field.endswith("_at") and expected_type != "timestamptz":
                        validation_errors.append(f"{model_name}.{field}: deveria ser timestamptz")
                    elif field in ["name", "description", "display_name"] and expected_type != "text":
                        validation_errors.append(f"{model_name}.{field}: deveria ser text")
            
            duration = int((time.time() - start_time) * 1000)
            
            if not validation_errors:
                self.log_test(
                    "V3 Data Models", 
                    "PASS", 
                    f"Modelos V3 validados: {len(v3_models)} modelos conformes",
                    duration
                )
                return True
            else:
                self.log_test(
                    "V3 Data Models", 
                    "FAIL", 
                    f"Erros de validação: {validation_errors}",
                    duration
                )
                return False
                
        except Exception as e:
            duration = int((time.time() - start_time) * 1000)
            self.log_test(
                "V3 Data Models", 
                "FAIL", 
                f"Erro na validação: {str(e)}",
                duration
            )
            return False
    
    def test_v3_contract_evolution(self) -> bool:
        """Teste de evolução de contratos V2.1 → V3.0"""
        start_time = time.time()
        
        try:
            # Simular evolução de contrato
            contract_v21 = {
                "name": "customer_profile",
                "version": "2.1.0",
                "schema": {
                    "customer_id": {"type": "varchar(50)"},
                    "name": {"type": "varchar(255)"},
                    "email": {"type": "varchar(255)"},
                    "created_date": {"type": "timestamp"}
                }
            }
            
            contract_v30 = {
                "name": "customer_profile", 
                "version": "3.0.0",
                "schema": {
                    "customer_id": {"type": "text"},
                    "name": {"type": "text"},
                    "email": {"type": "text"},
                    "created_at": {"type": "timestamptz"},
                    "updated_at": {"type": "timestamptz"}
                },
                "breaking_changes": True,
                "migration_notes": "Padronizações V3: varchar→text, timestamp→timestamptz, +updated_at"
            }
            
            # Validar evolução
            evolution_checks = []
            
            # 1. Verificar se campos varchar foram convertidos para text
            v21_varchar_fields = [k for k, v in contract_v21["schema"].items() if "varchar" in v["type"]]
            v30_text_fields = [k for k, v in contract_v30["schema"].items() if v["type"] == "text"]
            
            if len(v30_text_fields) >= len(v21_varchar_fields):
                evolution_checks.append("✅ varchar → text")
            else:
                evolution_checks.append("❌ varchar → text")
            
            # 2. Verificar se timestamp foi convertido para timestamptz
            v21_timestamp_fields = [k for k, v in contract_v21["schema"].items() if "timestamp" in v["type"]]
            v30_timestamptz_fields = [k for k, v in contract_v30["schema"].items() if v["type"] == "timestamptz"]
            
            if len(v30_timestamptz_fields) >= len(v21_timestamp_fields):
                evolution_checks.append("✅ timestamp → timestamptz")
            else:
                evolution_checks.append("❌ timestamp → timestamptz")
            
            # 3. Verificar se updated_at foi adicionado
            if "updated_at" in contract_v30["schema"]:
                evolution_checks.append("✅ +updated_at")
            else:
                evolution_checks.append("❌ +updated_at")
            
            # 4. Verificar se breaking changes estão marcados
            if contract_v30.get("breaking_changes", False):
                evolution_checks.append("✅ breaking_changes=true")
            else:
                evolution_checks.append("❌ breaking_changes=false")
            
            duration = int((time.time() - start_time) * 1000)
            
            failed_checks = [c for c in evolution_checks if c.startswith("❌")]
            
            if not failed_checks:
                self.log_test(
                    "V3 Contract Evolution", 
                    "PASS", 
                    f"Evolução V2.1→V3.0 validada: {', '.join(evolution_checks)}",
                    duration
                )
                return True
            else:
                self.log_test(
                    "V3 Contract Evolution", 
                    "FAIL", 
                    f"Falhas na evolução: {failed_checks}",
                    duration
                )
                return False
                
        except Exception as e:
            duration = int((time.time() - start_time) * 1000)
            self.log_test(
                "V3 Contract Evolution", 
                "FAIL", 
                f"Erro na evolução: {str(e)}",
                duration
            )
            return False
    
    def test_v3_performance_baseline(self) -> bool:
        """Teste de baseline de performance V3"""
        start_time = time.time()
        
        try:
            # Teste de múltiplas requisições para health check
            response_times = []
            
            for i in range(20):
                req_start = time.time()
                response = self.session.get(f"{self.base_url}/health", timeout=5)
                req_duration = (time.time() - req_start) * 1000
                response_times.append(req_duration)
                
                if response.status_code != 200:
                    break
            
            if len(response_times) < 10:
                duration = int((time.time() - start_time) * 1000)
                self.log_test(
                    "V3 Performance Baseline", 
                    "FAIL", 
                    "Não foi possível completar requisições suficientes",
                    duration
                )
                return False
            
            avg_response_time = sum(response_times) / len(response_times)
            max_response_time = max(response_times)
            min_response_time = min(response_times)
            p95_response_time = sorted(response_times)[int(len(response_times) * 0.95)]
            
            duration = int((time.time() - start_time) * 1000)
            
            # Critérios de performance V3
            performance_criteria = {
                "avg_under_250ms": avg_response_time < 250,
                "p95_under_500ms": p95_response_time < 500,
                "max_under_1000ms": max_response_time < 1000
            }
            
            failed_criteria = [k for k, v in performance_criteria.items() if not v]
            
            if not failed_criteria:
                self.log_test(
                    "V3 Performance Baseline", 
                    "PASS", 
                    f"Performance OK - Avg:{avg_response_time:.1f}ms P95:{p95_response_time:.1f}ms Max:{max_response_time:.1f}ms",
                    duration
                )
                return True
            else:
                self.log_test(
                    "V3 Performance Baseline", 
                    "WARN", 
                    f"Performance degradada - {failed_criteria} - Avg:{avg_response_time:.1f}ms",
                    duration
                )
                return False
                
        except Exception as e:
            duration = int((time.time() - start_time) * 1000)
            self.log_test(
                "V3 Performance Baseline", 
                "FAIL", 
                f"Erro no teste: {str(e)}",
                duration
            )
            return False
    
    def run_all_tests(self) -> Dict[str, Any]:
        """Executar todos os testes simplificados V3"""
        print("🚀 Iniciando testes simplificados da API de Governança V3.0...")
        print("=" * 65)
        
        start_time = time.time()
        
        # Lista de testes a executar
        tests = [
            ("API Health Check", self.test_api_health),
            ("OpenAPI Schema V3", self.test_openapi_schema),
            ("Documentation Interface", self.test_docs_interface),
            ("V3 Data Models", self.test_v3_data_models),
            ("V3 Contract Evolution", self.test_v3_contract_evolution),
            ("V3 Performance Baseline", self.test_v3_performance_baseline)
        ]
        
        passed_tests = 0
        failed_tests = 0
        warning_tests = 0
        
        for test_name, test_func in tests:
            try:
                result = test_func()
                if result:
                    passed_tests += 1
                else:
                    # Verificar se foi warning
                    last_result = self.test_results[-1]
                    if last_result["status"] == "WARN":
                        warning_tests += 1
                    else:
                        failed_tests += 1
            except Exception as e:
                failed_tests += 1
                self.log_test(test_name, "FAIL", f"Exceção: {str(e)}")
        
        total_duration = int((time.time() - start_time) * 1000)
        
        # Resumo dos resultados
        print("\n" + "=" * 65)
        print("📊 RESUMO DOS TESTES SIMPLIFICADOS V3.0")
        print("=" * 65)
        print(f"✅ Testes aprovados: {passed_tests}")
        print(f"⚠️  Testes com warning: {warning_tests}")
        print(f"❌ Testes falharam: {failed_tests}")
        print(f"⏱️  Tempo total: {total_duration}ms")
        
        success_rate = (passed_tests / len(tests)) * 100
        print(f"📈 Taxa de sucesso: {success_rate:.1f}%")
        
        # Determinar status geral
        if failed_tests == 0:
            overall_status = "PASS"
            print("🎉 TODOS OS TESTES PASSARAM!")
        elif success_rate >= 80:
            overall_status = "WARN"
            print("⚠️  MAIORIA DOS TESTES PASSOU (com warnings)")
        else:
            overall_status = "FAIL"
            print("❌ VÁRIOS TESTES FALHARAM")
        
        # Salvar relatório
        report = {
            "version": "3.0",
            "test_type": "simplified",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "overall_status": overall_status,
            "summary": {
                "total_tests": len(tests),
                "passed": passed_tests,
                "warnings": warning_tests,
                "failed": failed_tests,
                "success_rate": success_rate,
                "total_duration_ms": total_duration
            },
            "test_results": self.test_results
        }
        
        return report


def main():
    """Função principal"""
    print("🔧 Testador Simplificado da API de Governança de Dados V3.0")
    print("Desenvolvido por Carlos Morais")
    print()
    
    # Configurar testador
    tester = GovernanceAPIV3SimplifiedTester()
    
    # Executar testes
    report = tester.run_all_tests()
    
    # Salvar relatório
    report_file = f"governance_api_v3_simplified_test_report_{int(time.time())}.json"
    with open(report_file, 'w', encoding='utf-8') as f:
        json.dump(report, f, indent=2, ensure_ascii=False)
    
    print(f"\n📄 Relatório salvo em: {report_file}")
    
    # Retornar código de saída
    if report["overall_status"] == "PASS":
        return 0
    elif report["overall_status"] == "WARN":
        return 1
    else:
        return 2


if __name__ == "__main__":
    exit(main())

