# Documentação Completa dos Endpoints

## Visão Geral

A API de Governança de Dados oferece 112+ endpoints organizados em módulos funcionais para gestão completa de governança de dados baseada no modelo ODCS v3.0.2.

## Autenticação

Todos os endpoints (exceto health checks) requerem autenticação JWT:

```http
Authorization: Bearer <jwt_token>
```

### Obter Token
```http
POST /api/v1/auth/login
Content-Type: application/json

{
    "username": "user@example.com",
    "password": "password"
}
```

## 📋 Contratos de Dados (Data Contracts)

### Gestão de Contratos

#### Listar Contratos
```http
GET /api/v1/contracts
Query Parameters:
- page: int = 1
- size: int = 20
- status: str (optional)
- owner: str (optional)
- search: str (optional)
```

#### Criar Contrato
```http
POST /api/v1/contracts
Content-Type: application/json

{
    "name": "Customer Data Contract",
    "description": "Contrato para dados de clientes",
    "version": "1.0.0",
    "owner": "data-team@company.com",
    "schema": {
        "type": "object",
        "properties": {
            "customer_id": {"type": "string"},
            "name": {"type": "string"},
            "email": {"type": "string"}
        }
    },
    "quality_rules": [
        {
            "field": "email",
            "rule_type": "format",
            "parameters": {"pattern": "email"}
        }
    ],
    "sla": {
        "availability": 99.9,
        "response_time_ms": 100
    }
}
```

#### Obter Contrato
```http
GET /api/v1/contracts/{contract_id}
```

#### Atualizar Contrato
```http
PUT /api/v1/contracts/{contract_id}
Content-Type: application/json
```

#### Excluir Contrato
```http
DELETE /api/v1/contracts/{contract_id}
```

### Versionamento

#### Listar Versões
```http
GET /api/v1/contracts/{contract_id}/versions
```

#### Criar Nova Versão
```http
POST /api/v1/contracts/{contract_id}/versions
Content-Type: application/json

{
    "version": "1.1.0",
    "changes": "Adicionado campo phone",
    "schema": {...}
}
```

#### Ativar Versão
```http
POST /api/v1/contracts/{contract_id}/versions/{version}/activate
```

### Validação e Conformidade

#### Validar Dados
```http
POST /api/v1/contracts/{contract_id}/validate
Content-Type: application/json

{
    "data": {
        "customer_id": "123",
        "name": "João Silva",
        "email": "joao@example.com"
    }
}
```

#### Relatório de Conformidade
```http
GET /api/v1/contracts/{contract_id}/compliance
Query Parameters:
- start_date: date
- end_date: date
```

## 🏗️ Entidades (Entities)

### Gestão de Entidades

#### Listar Entidades
```http
GET /api/v1/entities
Query Parameters:
- page: int = 1
- size: int = 20
- type: str (optional)
- domain: str (optional)
- search: str (optional)
```

#### Criar Entidade
```http
POST /api/v1/entities
Content-Type: application/json

{
    "name": "Customer",
    "type": "table",
    "domain": "sales",
    "description": "Tabela de clientes",
    "schema": {
        "columns": [
            {
                "name": "id",
                "type": "integer",
                "primary_key": true
            },
            {
                "name": "name",
                "type": "varchar",
                "length": 255,
                "nullable": false
            }
        ]
    },
    "tags": ["pii", "customer-data"],
    "owner": "sales-team@company.com"
}
```

#### Obter Entidade
```http
GET /api/v1/entities/{entity_id}
```

#### Atualizar Entidade
```http
PUT /api/v1/entities/{entity_id}
```

#### Excluir Entidade
```http
DELETE /api/v1/entities/{entity_id}
```

### Linhagem de Dados

#### Obter Linhagem Upstream
```http
GET /api/v1/entities/{entity_id}/lineage/upstream
Query Parameters:
- depth: int = 3
- include_columns: bool = false
```

#### Obter Linhagem Downstream
```http
GET /api/v1/entities/{entity_id}/lineage/downstream
Query Parameters:
- depth: int = 3
- include_columns: bool = false
```

#### Obter Linhagem Completa
```http
GET /api/v1/entities/{entity_id}/lineage/full
```

### Relacionamentos

#### Listar Relacionamentos
```http
GET /api/v1/entities/{entity_id}/relationships
```

#### Criar Relacionamento
```http
POST /api/v1/entities/{entity_id}/relationships
Content-Type: application/json

{
    "target_entity_id": "456",
    "relationship_type": "foreign_key",
    "source_columns": ["customer_id"],
    "target_columns": ["id"]
}
```

## 🎯 Qualidade de Dados (Quality)

### Regras de Qualidade

#### Listar Regras
```http
GET /api/v1/quality/rules
Query Parameters:
- entity_id: str (optional)
- rule_type: str (optional)
- status: str (optional)
```

#### Criar Regra
```http
POST /api/v1/quality/rules
Content-Type: application/json

{
    "name": "Email Format Validation",
    "entity_id": "123",
    "column": "email",
    "rule_type": "format",
    "parameters": {
        "pattern": "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$"
    },
    "severity": "error",
    "description": "Validar formato de email"
}
```

#### Executar Regra
```http
POST /api/v1/quality/rules/{rule_id}/execute
Content-Type: application/json

{
    "sample_size": 1000,
    "async": true
}
```

### Métricas de Qualidade

#### Obter Métricas
```http
GET /api/v1/quality/metrics
Query Parameters:
- entity_id: str (optional)
- start_date: date
- end_date: date
- metric_type: str (optional)
```

#### Calcular Métricas
```http
POST /api/v1/quality/metrics/calculate
Content-Type: application/json

{
    "entity_id": "123",
    "metrics": ["completeness", "uniqueness", "validity"],
    "async": true
}
```

### Relatórios de Qualidade

#### Gerar Relatório
```http
POST /api/v1/quality/reports
Content-Type: application/json

{
    "name": "Monthly Quality Report",
    "entities": ["123", "456"],
    "start_date": "2024-01-01",
    "end_date": "2024-01-31",
    "format": "pdf"
}
```

#### Listar Relatórios
```http
GET /api/v1/quality/reports
```

#### Download Relatório
```http
GET /api/v1/quality/reports/{report_id}/download
```

## 🛡️ Governança (Governance)

### Políticas

#### Listar Políticas
```http
GET /api/v1/governance/policies
Query Parameters:
- type: str (optional)
- status: str (optional)
- domain: str (optional)
```

#### Criar Política
```http
POST /api/v1/governance/policies
Content-Type: application/json

{
    "name": "PII Data Access Policy",
    "type": "access_control",
    "description": "Política de acesso a dados PII",
    "rules": [
        {
            "condition": "data.tags.contains('pii')",
            "action": "require_approval",
            "approvers": ["dpo@company.com"]
        }
    ],
    "domains": ["sales", "marketing"]
}
```

### Conformidade

#### Verificar Conformidade
```http
GET /api/v1/governance/compliance
Query Parameters:
- entity_id: str (optional)
- policy_id: str (optional)
- start_date: date
- end_date: date
```

#### Relatório de Conformidade
```http
POST /api/v1/governance/compliance/report
Content-Type: application/json

{
    "scope": "organization",
    "regulations": ["gdpr", "lgpd"],
    "start_date": "2024-01-01",
    "end_date": "2024-01-31"
}
```

### Classificação de Dados

#### Classificar Entidade
```http
POST /api/v1/governance/classification
Content-Type: application/json

{
    "entity_id": "123",
    "classification": "confidential",
    "tags": ["pii", "financial"],
    "reason": "Contém dados pessoais e financeiros"
}
```

#### Obter Classificação
```http
GET /api/v1/entities/{entity_id}/classification
```

## 🔍 Catálogo de Dados (Catalog)

### Busca e Descoberta

#### Buscar no Catálogo
```http
GET /api/v1/catalog/search
Query Parameters:
- q: str (query)
- type: str (optional)
- domain: str (optional)
- tags: str (optional)
- page: int = 1
- size: int = 20
```

#### Busca Avançada
```http
POST /api/v1/catalog/search/advanced
Content-Type: application/json

{
    "query": "customer data",
    "filters": {
        "type": ["table", "view"],
        "domain": ["sales"],
        "tags": ["pii"],
        "owner": "sales-team@company.com"
    },
    "sort": [
        {"field": "relevance", "order": "desc"},
        {"field": "updated_at", "order": "desc"}
    ]
}
```

### Metadados

#### Obter Metadados
```http
GET /api/v1/catalog/metadata/{entity_id}
```

#### Atualizar Metadados
```http
PUT /api/v1/catalog/metadata/{entity_id}
Content-Type: application/json

{
    "description": "Nova descrição",
    "tags": ["updated", "reviewed"],
    "custom_properties": {
        "business_owner": "John Doe",
        "update_frequency": "daily"
    }
}
```

## 📊 Monitoramento (Monitoring)

### Health Checks

#### Status Geral
```http
GET /health
```

#### Status do Banco
```http
GET /health/database
```

#### Status do Cache
```http
GET /health/redis
```

#### Status Detalhado
```http
GET /health/detailed
```

### Métricas

#### Métricas Prometheus
```http
GET /metrics
```

#### Métricas Customizadas
```http
GET /api/v1/monitoring/metrics
Query Parameters:
- metric: str
- start_time: datetime
- end_time: datetime
- step: str
```

### Alertas

#### Listar Alertas
```http
GET /api/v1/monitoring/alerts
Query Parameters:
- status: str (optional)
- severity: str (optional)
- start_date: date
- end_date: date
```

#### Criar Alerta
```http
POST /api/v1/monitoring/alerts
Content-Type: application/json

{
    "name": "High Error Rate",
    "condition": "error_rate > 0.05",
    "severity": "critical",
    "notification_channels": ["email", "slack"]
}
```

## 🔗 Integrações (Integrations)

### Unity Catalog

#### Sincronizar com Unity Catalog
```http
POST /api/v1/integrations/unity-catalog/sync
Content-Type: application/json

{
    "catalog": "main",
    "schema": "sales",
    "full_sync": false
}
```

#### Status da Sincronização
```http
GET /api/v1/integrations/unity-catalog/sync/status
```

### Webhooks

#### Listar Webhooks
```http
GET /api/v1/integrations/webhooks
```

#### Criar Webhook
```http
POST /api/v1/integrations/webhooks
Content-Type: application/json

{
    "name": "Quality Alert Webhook",
    "url": "https://api.example.com/webhooks/quality",
    "events": ["quality.rule.failed", "quality.metric.threshold"],
    "secret": "webhook_secret_key"
}
```

## 📈 Analytics e Relatórios

### Dashboards

#### Listar Dashboards
```http
GET /api/v1/analytics/dashboards
```

#### Obter Dashboard
```http
GET /api/v1/analytics/dashboards/{dashboard_id}
```

### Relatórios

#### Gerar Relatório Executivo
```http
POST /api/v1/analytics/reports/executive
Content-Type: application/json

{
    "period": "monthly",
    "start_date": "2024-01-01",
    "end_date": "2024-01-31",
    "include_trends": true
}
```

#### Relatório de Uso
```http
GET /api/v1/analytics/usage
Query Parameters:
- start_date: date
- end_date: date
- granularity: str (daily, weekly, monthly)
```

## 🔐 Administração (Admin)

### Usuários

#### Listar Usuários
```http
GET /api/v1/admin/users
```

#### Criar Usuário
```http
POST /api/v1/admin/users
Content-Type: application/json

{
    "email": "user@example.com",
    "name": "João Silva",
    "role": "data_analyst",
    "permissions": ["read_contracts", "write_entities"]
}
```

### Configurações

#### Obter Configurações
```http
GET /api/v1/admin/settings
```

#### Atualizar Configurações
```http
PUT /api/v1/admin/settings
Content-Type: application/json

{
    "max_file_size": "100MB",
    "cache_ttl": 3600,
    "notification_settings": {
        "email_enabled": true,
        "slack_enabled": false
    }
}
```

## 📝 Auditoria (Audit)

### Logs de Auditoria

#### Listar Logs
```http
GET /api/v1/audit/logs
Query Parameters:
- user_id: str (optional)
- action: str (optional)
- resource_type: str (optional)
- start_date: date
- end_date: date
- page: int = 1
- size: int = 20
```

#### Obter Log Específico
```http
GET /api/v1/audit/logs/{log_id}
```

### Trilha de Auditoria

#### Trilha de Entidade
```http
GET /api/v1/audit/trail/{entity_id}
Query Parameters:
- start_date: date
- end_date: date
```

## 🚨 Códigos de Status HTTP

- `200 OK` - Sucesso
- `201 Created` - Recurso criado
- `204 No Content` - Sucesso sem conteúdo
- `400 Bad Request` - Dados inválidos
- `401 Unauthorized` - Não autenticado
- `403 Forbidden` - Sem permissão
- `404 Not Found` - Recurso não encontrado
- `409 Conflict` - Conflito de dados
- `422 Unprocessable Entity` - Erro de validação
- `429 Too Many Requests` - Rate limit excedido
- `500 Internal Server Error` - Erro interno

## 📋 Formatos de Resposta

### Sucesso
```json
{
    "success": true,
    "data": {...},
    "metadata": {
        "timestamp": "2024-01-15T10:30:00Z",
        "version": "1.0.0"
    }
}
```

### Lista Paginada
```json
{
    "success": true,
    "data": [...],
    "pagination": {
        "page": 1,
        "size": 20,
        "total": 150,
        "pages": 8
    }
}
```

### Erro
```json
{
    "success": false,
    "error": {
        "code": "VALIDATION_ERROR",
        "message": "Dados inválidos",
        "details": {
            "field": "email",
            "reason": "Formato inválido"
        }
    },
    "timestamp": "2024-01-15T10:30:00Z"
}
```

## 🔧 Rate Limiting

- **Limite padrão**: 1000 requests/hora por IP
- **Limite autenticado**: 5000 requests/hora por usuário
- **Headers de resposta**:
  - `X-RateLimit-Limit`: Limite total
  - `X-RateLimit-Remaining`: Requests restantes
  - `X-RateLimit-Reset`: Timestamp do reset

## 📚 Exemplos de Uso

### Fluxo Completo: Criar e Validar Contrato

1. **Criar contrato**:
```bash
curl -X POST http://localhost:8000/api/v1/contracts \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Customer Contract",
    "version": "1.0.0",
    "schema": {...}
  }'
```

2. **Validar dados**:
```bash
curl -X POST http://localhost:8000/api/v1/contracts/123/validate \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "data": {
      "customer_id": "123",
      "name": "João",
      "email": "joao@example.com"
    }
  }'
```

3. **Verificar conformidade**:
```bash
curl -X GET "http://localhost:8000/api/v1/contracts/123/compliance?start_date=2024-01-01&end_date=2024-01-31" \
  -H "Authorization: Bearer $TOKEN"
```

Esta documentação cobre todos os 112+ endpoints da API de Governança de Dados. Para mais detalhes, consulte a documentação interativa em `/docs` quando o servidor estiver executando.

