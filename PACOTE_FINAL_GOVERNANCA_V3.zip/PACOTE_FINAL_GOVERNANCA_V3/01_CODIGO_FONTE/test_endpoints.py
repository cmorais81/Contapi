#!/usr/bin/env python3
"""
Script para testar todos os endpoints da API de Governança
"""
import asyncio
import json
import sys
import time
from pathlib import Path
from typing import Dict, List, Any

import httpx
from rich.console import Console
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TextColumn

# Adicionar src ao path
sys.path.insert(0, str(Path(__file__).parent / "src"))

console = Console()


class EndpointTester:
    """Testador de endpoints da API"""
    
    def __init__(self, base_url: str = "http://localhost:8000"):
        self.base_url = base_url
        self.client = httpx.AsyncClient(timeout=30.0)
        self.results = []
        self.auth_token = None
    
    async def setup_auth(self) -> bool:
        """Configura autenticação (mock para testes)"""
        # Para testes, vamos usar um token mock
        self.auth_token = "test-token-for-endpoints"
        return True
    
    def get_headers(self) -> Dict[str, str]:
        """Retorna headers com autenticação"""
        headers = {"Content-Type": "application/json"}
        if self.auth_token:
            headers["Authorization"] = f"Bearer {self.auth_token}"
        return headers
    
    async def test_endpoint(self, method: str, path: str, data: Dict = None, 
                          expected_status: int = 200, description: str = "") -> Dict:
        """Testa um endpoint específico"""
        url = f"{self.base_url}{path}"
        
        try:
            if method.upper() == "GET":
                response = await self.client.get(url, headers=self.get_headers())
            elif method.upper() == "POST":
                response = await self.client.post(url, headers=self.get_headers(), json=data)
            elif method.upper() == "PUT":
                response = await self.client.put(url, headers=self.get_headers(), json=data)
            elif method.upper() == "DELETE":
                response = await self.client.delete(url, headers=self.get_headers())
            else:
                raise ValueError(f"Método HTTP não suportado: {method}")
            
            # Verificar se resposta é JSON válida
            try:
                response_data = response.json()
            except:
                response_data = {"raw_response": response.text}
            
            result = {
                "method": method.upper(),
                "path": path,
                "description": description,
                "status_code": response.status_code,
                "expected_status": expected_status,
                "success": response.status_code == expected_status,
                "response_time": response.elapsed.total_seconds(),
                "response_data": response_data,
                "error": None
            }
            
        except Exception as e:
            result = {
                "method": method.upper(),
                "path": path,
                "description": description,
                "status_code": 0,
                "expected_status": expected_status,
                "success": False,
                "response_time": 0,
                "response_data": None,
                "error": str(e)
            }
        
        self.results.append(result)
        return result
    
    async def test_health_endpoints(self):
        """Testa endpoints de health check"""
        console.print("\n🏥 [bold blue]Testando Health Endpoints[/bold blue]")
        
        await self.test_endpoint("GET", "/health", description="Health check geral")
        await self.test_endpoint("GET", "/health/database", description="Health check do banco")
        await self.test_endpoint("GET", "/health/redis", description="Health check do Redis")
        await self.test_endpoint("GET", "/metrics", description="Métricas Prometheus")
    
    async def test_contract_endpoints(self):
        """Testa endpoints de contratos de dados"""
        console.print("\n📋 [bold blue]Testando Contract Endpoints[/bold blue]")
        
        # Listar contratos
        await self.test_endpoint("GET", "/api/v1/contracts", description="Listar contratos")
        await self.test_endpoint("GET", "/api/v1/contracts?page=1&size=10", description="Listar contratos paginados")
        
        # Criar contrato
        contract_data = {
            "name": "Test Contract API",
            "description": "Contrato de teste via API",
            "version": "1.0.0",
            "contract_type": "api",
            "owner_email": "test@example.com",
            "schema_definition": {
                "type": "object",
                "properties": {
                    "id": {"type": "string"},
                    "name": {"type": "string"}
                }
            },
            "sla_availability": 99.9,
            "sla_response_time": 100
        }
        
        create_result = await self.test_endpoint("POST", "/api/v1/contracts", 
                                               data=contract_data, expected_status=201,
                                               description="Criar contrato")
        
        # Se criação foi bem-sucedida, testar outros endpoints
        if create_result["success"] and create_result["response_data"]:
            contract_id = create_result["response_data"].get("data", {}).get("id")
            if contract_id:
                await self.test_endpoint("GET", f"/api/v1/contracts/{contract_id}", 
                                       description="Obter contrato específico")
                
                # Atualizar contrato
                update_data = {"description": "Descrição atualizada via API"}
                await self.test_endpoint("PUT", f"/api/v1/contracts/{contract_id}", 
                                       data=update_data, description="Atualizar contrato")
                
                # Validar dados
                validation_data = {
                    "data": {
                        "id": "123",
                        "name": "Test Item"
                    }
                }
                await self.test_endpoint("POST", f"/api/v1/contracts/{contract_id}/validate", 
                                       data=validation_data, description="Validar dados do contrato")
                
                # Versões
                await self.test_endpoint("GET", f"/api/v1/contracts/{contract_id}/versions", 
                                       description="Listar versões do contrato")
                
                # Conformidade
                await self.test_endpoint("GET", f"/api/v1/contracts/{contract_id}/compliance", 
                                       description="Relatório de conformidade")
    
    async def test_entity_endpoints(self):
        """Testa endpoints de entidades"""
        console.print("\n🏗️ [bold blue]Testando Entity Endpoints[/bold blue]")
        
        # Listar entidades
        await self.test_endpoint("GET", "/api/v1/entities", description="Listar entidades")
        await self.test_endpoint("GET", "/api/v1/entities?domain=sales", description="Listar entidades por domínio")
        
        # Criar entidade
        entity_data = {
            "name": "test_entity_api",
            "display_name": "Test Entity API",
            "description": "Entidade de teste via API",
            "entity_type": "table",
            "domain": "test",
            "owner_email": "test@example.com",
            "schema_name": "test_schema",
            "table_name": "test_table",
            "unity_catalog_path": "catalog.test.test_table"
        }
        
        create_result = await self.test_endpoint("POST", "/api/v1/entities", 
                                               data=entity_data, expected_status=201,
                                               description="Criar entidade")
        
        # Se criação foi bem-sucedida, testar outros endpoints
        if create_result["success"] and create_result["response_data"]:
            entity_id = create_result["response_data"].get("data", {}).get("id")
            if entity_id:
                await self.test_endpoint("GET", f"/api/v1/entities/{entity_id}", 
                                       description="Obter entidade específica")
                
                # Linhagem
                await self.test_endpoint("GET", f"/api/v1/entities/{entity_id}/lineage/upstream", 
                                       description="Linhagem upstream")
                await self.test_endpoint("GET", f"/api/v1/entities/{entity_id}/lineage/downstream", 
                                       description="Linhagem downstream")
                
                # Relacionamentos
                await self.test_endpoint("GET", f"/api/v1/entities/{entity_id}/relationships", 
                                       description="Relacionamentos da entidade")
                
                # Classificação
                await self.test_endpoint("GET", f"/api/v1/entities/{entity_id}/classification", 
                                       description="Classificação da entidade")
    
    async def test_quality_endpoints(self):
        """Testa endpoints de qualidade"""
        console.print("\n🎯 [bold blue]Testando Quality Endpoints[/bold blue]")
        
        # Regras de qualidade
        await self.test_endpoint("GET", "/api/v1/quality/rules", description="Listar regras de qualidade")
        
        # Criar regra
        rule_data = {
            "name": "Test Quality Rule",
            "description": "Regra de teste via API",
            "rule_type": "not_null",
            "column_name": "id",
            "parameters": {},
            "severity": "error"
        }
        
        create_result = await self.test_endpoint("POST", "/api/v1/quality/rules", 
                                               data=rule_data, expected_status=201,
                                               description="Criar regra de qualidade")
        
        # Métricas
        await self.test_endpoint("GET", "/api/v1/quality/metrics", description="Obter métricas de qualidade")
        
        # Calcular métricas
        metrics_data = {
            "entity_id": "test-entity-id",
            "metrics": ["completeness", "uniqueness"],
            "async": False
        }
        await self.test_endpoint("POST", "/api/v1/quality/metrics/calculate", 
                               data=metrics_data, description="Calcular métricas")
        
        # Relatórios
        await self.test_endpoint("GET", "/api/v1/quality/reports", description="Listar relatórios de qualidade")
    
    async def test_governance_endpoints(self):
        """Testa endpoints de governança"""
        console.print("\n🛡️ [bold blue]Testando Governance Endpoints[/bold blue]")
        
        # Políticas
        await self.test_endpoint("GET", "/api/v1/governance/policies", description="Listar políticas")
        
        # Criar política
        policy_data = {
            "name": "Test Policy",
            "type": "access_control",
            "description": "Política de teste via API",
            "rules": [
                {
                    "condition": "data.classification == 'confidential'",
                    "action": "require_approval"
                }
            ]
        }
        
        await self.test_endpoint("POST", "/api/v1/governance/policies", 
                               data=policy_data, expected_status=201,
                               description="Criar política")
        
        # Conformidade
        await self.test_endpoint("GET", "/api/v1/governance/compliance", description="Verificar conformidade")
        
        # Classificação
        classification_data = {
            "entity_id": "test-entity-id",
            "classification": "confidential",
            "tags": ["pii", "financial"],
            "reason": "Contém dados pessoais e financeiros"
        }
        await self.test_endpoint("POST", "/api/v1/governance/classification", 
                               data=classification_data, description="Classificar entidade")
    
    async def test_catalog_endpoints(self):
        """Testa endpoints do catálogo"""
        console.print("\n🔍 [bold blue]Testando Catalog Endpoints[/bold blue]")
        
        # Busca simples
        await self.test_endpoint("GET", "/api/v1/catalog/search?q=customer", 
                               description="Buscar no catálogo")
        
        # Busca avançada
        search_data = {
            "query": "customer data",
            "filters": {
                "type": ["table"],
                "domain": ["sales"]
            }
        }
        await self.test_endpoint("POST", "/api/v1/catalog/search/advanced", 
                               data=search_data, description="Busca avançada")
    
    async def test_monitoring_endpoints(self):
        """Testa endpoints de monitoramento"""
        console.print("\n📊 [bold blue]Testando Monitoring Endpoints[/bold blue]")
        
        # Métricas customizadas
        await self.test_endpoint("GET", "/api/v1/monitoring/metrics?metric=request_count", 
                               description="Métricas customizadas")
        
        # Alertas
        await self.test_endpoint("GET", "/api/v1/monitoring/alerts", description="Listar alertas")
        
        # Criar alerta
        alert_data = {
            "name": "Test Alert",
            "condition": "error_rate > 0.05",
            "severity": "warning",
            "notification_channels": ["email"]
        }
        await self.test_endpoint("POST", "/api/v1/monitoring/alerts", 
                               data=alert_data, expected_status=201,
                               description="Criar alerta")
    
    async def test_admin_endpoints(self):
        """Testa endpoints de administração"""
        console.print("\n🔐 [bold blue]Testando Admin Endpoints[/bold blue]")
        
        # Usuários
        await self.test_endpoint("GET", "/api/v1/admin/users", description="Listar usuários")
        
        # Configurações
        await self.test_endpoint("GET", "/api/v1/admin/settings", description="Obter configurações")
    
    async def test_audit_endpoints(self):
        """Testa endpoints de auditoria"""
        console.print("\n📝 [bold blue]Testando Audit Endpoints[/bold blue]")
        
        # Logs de auditoria
        await self.test_endpoint("GET", "/api/v1/audit/logs", description="Listar logs de auditoria")
        await self.test_endpoint("GET", "/api/v1/audit/logs?action=create", 
                               description="Filtrar logs por ação")
    
    async def run_all_tests(self):
        """Executa todos os testes"""
        console.print("[bold green]🚀 Iniciando Testes de Endpoints da API[/bold green]")
        console.print(f"Base URL: {self.base_url}")
        
        # Setup
        await self.setup_auth()
        
        # Executar testes por categoria
        await self.test_health_endpoints()
        await self.test_contract_endpoints()
        await self.test_entity_endpoints()
        await self.test_quality_endpoints()
        await self.test_governance_endpoints()
        await self.test_catalog_endpoints()
        await self.test_monitoring_endpoints()
        await self.test_admin_endpoints()
        await self.test_audit_endpoints()
        
        # Fechar cliente
        await self.client.aclose()
    
    def generate_report(self) -> str:
        """Gera relatório dos testes"""
        total_tests = len(self.results)
        successful_tests = sum(1 for r in self.results if r["success"])
        failed_tests = total_tests - successful_tests
        
        # Tabela de resumo
        table = Table(title="📊 Resumo dos Testes de Endpoints")
        table.add_column("Métrica", style="cyan")
        table.add_column("Valor", style="magenta")
        
        table.add_row("Total de Testes", str(total_tests))
        table.add_row("Sucessos", f"[green]{successful_tests}[/green]")
        table.add_row("Falhas", f"[red]{failed_tests}[/red]")
        table.add_row("Taxa de Sucesso", f"{(successful_tests/total_tests*100):.1f}%")
        
        console.print(table)
        
        # Tabela detalhada
        detail_table = Table(title="📋 Detalhes dos Testes")
        detail_table.add_column("Método", style="cyan")
        detail_table.add_column("Endpoint", style="blue")
        detail_table.add_column("Status", style="magenta")
        detail_table.add_column("Tempo (s)", style="yellow")
        detail_table.add_column("Resultado", style="green")
        
        for result in self.results:
            status_color = "green" if result["success"] else "red"
            status_text = f"[{status_color}]{result['status_code']}[/{status_color}]"
            result_text = "✅" if result["success"] else "❌"
            
            detail_table.add_row(
                result["method"],
                result["path"],
                status_text,
                f"{result['response_time']:.3f}",
                result_text
            )
        
        console.print(detail_table)
        
        # Falhas detalhadas
        failures = [r for r in self.results if not r["success"]]
        if failures:
            console.print("\n[bold red]❌ Falhas Detalhadas:[/bold red]")
            for failure in failures:
                console.print(f"  • {failure['method']} {failure['path']}")
                console.print(f"    Status: {failure['status_code']} (esperado: {failure['expected_status']})")
                if failure['error']:
                    console.print(f"    Erro: {failure['error']}")
                console.print()
        
        return f"Testes concluídos: {successful_tests}/{total_tests} sucessos"


async def main():
    """Função principal"""
    import argparse
    
    parser = argparse.ArgumentParser(description="Testar endpoints da API de Governança")
    parser.add_argument("--url", default="http://localhost:8000", 
                       help="URL base da API (padrão: http://localhost:8000)")
    parser.add_argument("--output", help="Arquivo para salvar relatório JSON")
    
    args = parser.parse_args()
    
    # Executar testes
    tester = EndpointTester(args.url)
    
    try:
        await tester.run_all_tests()
        summary = tester.generate_report()
        
        # Salvar relatório se solicitado
        if args.output:
            with open(args.output, 'w') as f:
                json.dump(tester.results, f, indent=2, default=str)
            console.print(f"\n💾 Relatório salvo em: {args.output}")
        
        console.print(f"\n✅ {summary}")
        
    except KeyboardInterrupt:
        console.print("\n❌ Testes interrompidos pelo usuário")
    except Exception as e:
        console.print(f"\n❌ Erro durante os testes: {e}")


if __name__ == "__main__":
    asyncio.run(main())

