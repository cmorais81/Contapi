import requests
import json

def test_api():
    base_url = "http://localhost:8001"
    
    # Test health
    try:
        response = requests.get(f"{base_url}/health", timeout=5)
        print(f"✅ Health: {response.status_code} - {response.json()}")
    except Exception as e:
        print(f"❌ Health failed: {e}")
        return False
    
    # Test docs
    try:
        response = requests.get(f"{base_url}/docs", timeout=5)
        print(f"✅ Docs: {response.status_code}")
    except Exception as e:
        print(f"❌ Docs failed: {e}")
    
    # Test openapi
    try:
        response = requests.get(f"{base_url}/openapi.json", timeout=5)
        print(f"✅ OpenAPI: {response.status_code}")
    except Exception as e:
        print(f"❌ OpenAPI failed: {e}")
    
    return True

if __name__ == "__main__":
    print("🧪 Teste Rápido da API")
    if test_api():
        print("✅ API está funcionando!")
    else:
        print("❌ API com problemas!")

