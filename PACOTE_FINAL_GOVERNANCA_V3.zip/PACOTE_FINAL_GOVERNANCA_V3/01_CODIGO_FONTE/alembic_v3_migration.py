"""
Script de migração V2.1 → V3.0
Padronizações: created_at/updated_at obrigatórios, varchar→text, timestamp→timestamptz
"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers
revision = 'v3_0_standardization'
down_revision = 'v2_1_final'
branch_labels = None
depends_on = None


def upgrade():
    """Migração para V3.0 - Padronizações"""
    
    # Lista de todas as tabelas que precisam ser atualizadas
    tables_to_update = [
        'users', 'audit_logs', 'rate_limit_policies', 'rate_limit_violations',
        'domains', 'entities', 'entity_attributes', 'data_contracts', 
        'contract_versions', 'quality_rules', 'quality_metrics', 
        'quality_incidents', 'lineage_relationships', 'attribute_lineage',
        'tags', 'entity_tags', 'business_glossary', 'usage_metrics',
        'workflows', 'workflow_instances', 'external_references',
        'integration_configs', 'performance_metrics', 'system_health',
        'cache_entries', 'query_optimization', 'notifications',
        'alert_rules', 'alert_instances', 'system_configurations'
    ]
    
    print("🚀 Iniciando migração V2.1 → V3.0...")
    
    # 1. Adicionar campos created_at/updated_at onde não existem
    print("📅 Adicionando campos created_at/updated_at...")
    
    for table in tables_to_update:
        # Verificar se a tabela existe
        try:
            # Adicionar created_at se não existir
            op.add_column(table, sa.Column(
                'created_at', 
                sa.DateTime(timezone=True), 
                server_default=sa.func.now(),
                nullable=False
            ))
            print(f"  ✅ Adicionado created_at em {table}")
        except Exception as e:
            print(f"  ⚠️  created_at já existe em {table}: {e}")
        
        try:
            # Adicionar updated_at se não existir
            op.add_column(table, sa.Column(
                'updated_at', 
                sa.DateTime(timezone=True), 
                server_default=sa.func.now(),
                nullable=False
            ))
            print(f"  ✅ Adicionado updated_at em {table}")
        except Exception as e:
            print(f"  ⚠️  updated_at já existe em {table}: {e}")
    
    # 2. Converter varchar para text
    print("📝 Convertendo varchar → text...")
    
    varchar_conversions = {
        'users': ['username', 'email', 'full_name', 'hashed_password'],
        'audit_logs': ['event_type', 'resource_type', 'resource_id', 'action', 
                      'user_agent', 'endpoint', 'http_method', 'session_id'],
        'rate_limit_policies': ['name', 'description', 'user_role', 'endpoint_pattern'],
        'rate_limit_violations': ['endpoint', 'limit_type', 'time_window'],
        'domains': ['name', 'display_name', 'description', 'domain_type', 'status'],
        'entities': ['name', 'display_name', 'description', 'entity_type', 
                    'data_classification', 'unity_catalog_path', 'physical_location', 'status'],
        'entity_attributes': ['name', 'display_name', 'description', 'data_type',
                             'default_value', 'format_pattern', 'business_rules', 'data_classification'],
        'data_contracts': ['name', 'display_name', 'description', 'version',
                          'contract_type', 'status', 'data_classification'],
        'contract_versions': ['version', 'description', 'migration_notes', 'changelog'],
        'quality_rules': ['name', 'description', 'rule_type', 'severity', 'schedule_expression'],
        'quality_metrics': ['status'],
        'quality_incidents': ['incident_type', 'severity', 'status', 'title',
                             'description', 'resolution_notes', 'impact_assessment', 'root_cause'],
        'lineage_relationships': ['relationship_type', 'transformation_logic',
                                 'pipeline_name', 'pipeline_id', 'discovered_method'],
        'attribute_lineage': ['transformation_type', 'transformation_logic'],
        'tags': ['name', 'display_name', 'description', 'tag_type', 'category', 'color', 'icon'],
        'business_glossary': ['term', 'definition', 'description', 'category',
                             'status', 'business_context', 'technical_context'],
        'usage_metrics': ['access_type', 'access_method', 'query_hash',
                         'error_message', 'user_agent', 'session_id'],
        'workflows': ['name', 'description', 'workflow_type'],
        'workflow_instances': ['resource_type', 'status', 'current_step'],
        'external_references': ['name', 'reference_type', 'connection_string',
                               'status', 'test_result'],
        'integration_configs': ['integration_name', 'integration_type',
                               'endpoint_url', 'sync_frequency', 'last_sync_status'],
        'performance_metrics': ['metric_name', 'metric_type', 'unit',
                               'resource_type', 'resource_id'],
        'system_health': ['component_name', 'component_type', 'status'],
        'cache_entries': ['cache_key'],
        'query_optimization': ['query_hash', 'original_query', 'optimized_query'],
        'notifications': ['notification_type', 'title', 'message', 'priority',
                         'status', 'resource_type', 'action_url'],
        'alert_rules': ['name', 'description', 'rule_type', 'condition_expression', 'severity'],
        'alert_instances': ['status', 'message'],
        'system_configurations': ['config_key', 'config_type', 'description']
    }
    
    for table, columns in varchar_conversions.items():
        for column in columns:
            try:
                op.alter_column(table, column, type_=sa.Text())
                print(f"  ✅ Convertido {table}.{column} para TEXT")
            except Exception as e:
                print(f"  ⚠️  Erro ao converter {table}.{column}: {e}")
    
    # 3. Converter timestamp para timestamptz
    print("🕐 Convertendo timestamp → timestamptz...")
    
    timestamp_conversions = {
        'users': ['last_login'],
        'audit_logs': [],  # já são timestamptz
        'rate_limit_violations': ['violation_time'],
        'entities': ['last_accessed_at'],
        'quality_metrics': ['measured_at'],
        'quality_incidents': ['detected_at', 'resolved_at'],
        'usage_metrics': ['accessed_at'],
        'workflow_instances': ['started_at', 'completed_at'],
        'external_references': ['last_tested_at'],
        'integration_configs': ['last_sync_at'],
        'performance_metrics': ['measured_at'],
        'system_health': ['last_check_at'],
        'cache_entries': ['last_accessed_at', 'expires_at'],
        'query_optimization': ['last_used_at'],
        'notifications': ['read_at', 'expires_at'],
        'alert_instances': ['triggered_at', 'resolved_at', 'acknowledged_at'],
        'contract_versions': ['approved_at', 'retirement_date']
    }
    
    for table, columns in timestamp_conversions.items():
        for column in columns:
            try:
                op.alter_column(table, column, type_=sa.DateTime(timezone=True))
                print(f"  ✅ Convertido {table}.{column} para TIMESTAMPTZ")
            except Exception as e:
                print(f"  ⚠️  Erro ao converter {table}.{column}: {e}")
    
    # 4. Adicionar indexes para created_at/updated_at
    print("📊 Adicionando indexes para campos de auditoria...")
    
    for table in tables_to_update:
        try:
            op.create_index(f'idx_{table}_created_at', table, ['created_at'])
            print(f"  ✅ Index criado para {table}.created_at")
        except Exception as e:
            print(f"  ⚠️  Index já existe para {table}.created_at: {e}")
        
        try:
            op.create_index(f'idx_{table}_updated_at', table, ['updated_at'])
            print(f"  ✅ Index criado para {table}.updated_at")
        except Exception as e:
            print(f"  ⚠️  Index já existe para {table}.updated_at: {e}")
    
    # 5. Atualizar triggers para updated_at
    print("⚡ Criando triggers para updated_at...")
    
    # Função para atualizar updated_at
    op.execute("""
        CREATE OR REPLACE FUNCTION update_updated_at_column()
        RETURNS TRIGGER AS $$
        BEGIN
            NEW.updated_at = NOW();
            RETURN NEW;
        END;
        $$ language 'plpgsql';
    """)
    
    # Criar triggers para todas as tabelas
    for table in tables_to_update:
        try:
            op.execute(f"""
                CREATE TRIGGER update_{table}_updated_at 
                BEFORE UPDATE ON {table} 
                FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
            """)
            print(f"  ✅ Trigger criado para {table}")
        except Exception as e:
            print(f"  ⚠️  Trigger já existe para {table}: {e}")
    
    print("🎉 Migração V3.0 concluída com sucesso!")


def downgrade():
    """Reverter migração V3.0 → V2.1"""
    
    print("⬇️  Revertendo migração V3.0 → V2.1...")
    
    tables_to_revert = [
        'users', 'audit_logs', 'rate_limit_policies', 'rate_limit_violations',
        'domains', 'entities', 'entity_attributes', 'data_contracts', 
        'contract_versions', 'quality_rules', 'quality_metrics', 
        'quality_incidents', 'lineage_relationships', 'attribute_lineage',
        'tags', 'entity_tags', 'business_glossary', 'usage_metrics',
        'workflows', 'workflow_instances', 'external_references',
        'integration_configs', 'performance_metrics', 'system_health',
        'cache_entries', 'query_optimization', 'notifications',
        'alert_rules', 'alert_instances', 'system_configurations'
    ]
    
    # 1. Remover triggers
    print("🗑️  Removendo triggers...")
    for table in tables_to_revert:
        try:
            op.execute(f"DROP TRIGGER IF EXISTS update_{table}_updated_at ON {table};")
            print(f"  ✅ Trigger removido de {table}")
        except Exception as e:
            print(f"  ⚠️  Erro ao remover trigger de {table}: {e}")
    
    # Remover função
    op.execute("DROP FUNCTION IF EXISTS update_updated_at_column();")
    
    # 2. Remover indexes
    print("📊 Removendo indexes...")
    for table in tables_to_revert:
        try:
            op.drop_index(f'idx_{table}_created_at')
            op.drop_index(f'idx_{table}_updated_at')
            print(f"  ✅ Indexes removidos de {table}")
        except Exception as e:
            print(f"  ⚠️  Erro ao remover indexes de {table}: {e}")
    
    # 3. Reverter tipos de dados (opcional - pode causar perda de dados)
    print("⚠️  ATENÇÃO: Reversão de tipos pode causar perda de dados!")
    print("⚠️  Recomenda-se manter os tipos padronizados.")
    
    print("✅ Reversão concluída!")


if __name__ == "__main__":
    print("Script de migração V2.1 → V3.0")
    print("Execute via Alembic: alembic upgrade head")

