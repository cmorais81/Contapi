# ========================================
# Script de Testes - API Governança
# Desenvolvido por Carlos Morais
# ========================================

param(
    [Parameter(Mandatory=$false)]
    [string]$TestType = "all",  # all, unit, integration, load, performance
    
    [Parameter(Mandatory=$false)]
    [string]$ApiUrl = "http://localhost:8000",
    
    [Parameter(Mandatory=$false)]
    [int]$LoadTestUsers = 50,
    
    [Parameter(Mandatory=$false)]
    [int]$LoadTestDuration = 300
)

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Testes - API Governança de Dados" -ForegroundColor Cyan
Write-Host "  Desenvolvido por Carlos Morais" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Verificar se Python está disponível
Write-Host "🔍 Verificando ambiente..." -ForegroundColor Yellow
try {
    $pythonVersion = python --version 2>&1
    Write-Host "✅ Python: $pythonVersion" -ForegroundColor Green
} catch {
    Write-Host "❌ Python não encontrado!" -ForegroundColor Red
    exit 1
}

# Verificar se API está rodando
Write-Host "🌐 Verificando API..." -ForegroundColor Yellow
try {
    $response = Invoke-RestMethod -Uri "$ApiUrl/health" -TimeoutSec 5
    if ($response.status -eq "healthy") {
        Write-Host "✅ API está respondendo" -ForegroundColor Green
    } else {
        Write-Host "⚠️  API responde mas status não é 'healthy'" -ForegroundColor Yellow
    }
} catch {
    Write-Host "❌ API não está respondendo em $ApiUrl" -ForegroundColor Red
    Write-Host "   Inicie a API primeiro com: .\scripts\windows\run.ps1" -ForegroundColor Yellow
    exit 1
}

# Definir variáveis de ambiente
$env:PYTHONPATH = "$PWD\src"
$env:API_BASE_URL = $ApiUrl

Write-Host ""
Write-Host "📋 Configuração dos testes:" -ForegroundColor Cyan
Write-Host "   Tipo: $TestType" -ForegroundColor White
Write-Host "   API URL: $ApiUrl" -ForegroundColor White
Write-Host "   Usuários (load test): $LoadTestUsers" -ForegroundColor White
Write-Host "   Duração (load test): $LoadTestDuration segundos" -ForegroundColor White
Write-Host ""

# Função para executar testes unitários
function Run-UnitTests {
    Write-Host "🧪 Executando testes unitários..." -ForegroundColor Yellow
    
    try {
        python -m pytest tests/unit/ -v --tb=short --cov=src --cov-report=html --cov-report=term
        
        if ($LASTEXITCODE -eq 0) {
            Write-Host "✅ Testes unitários concluídos com sucesso!" -ForegroundColor Green
        } else {
            Write-Host "❌ Alguns testes unitários falharam" -ForegroundColor Red
        }
    } catch {
        Write-Host "❌ Erro ao executar testes unitários: $_" -ForegroundColor Red
    }
}

# Função para executar testes de integração
function Run-IntegrationTests {
    Write-Host "🔗 Executando testes de integração..." -ForegroundColor Yellow
    
    try {
        python -m pytest tests/integration/ -v --tb=short
        
        if ($LASTEXITCODE -eq 0) {
            Write-Host "✅ Testes de integração concluídos com sucesso!" -ForegroundColor Green
        } else {
            Write-Host "❌ Alguns testes de integração falharam" -ForegroundColor Red
        }
    } catch {
        Write-Host "❌ Erro ao executar testes de integração: $_" -ForegroundColor Red
    }
}

# Função para executar testes de carga
function Run-LoadTests {
    Write-Host "⚡ Executando testes de carga..." -ForegroundColor Yellow
    Write-Host "   Usuários concorrentes: $LoadTestUsers" -ForegroundColor White
    Write-Host "   Duração: $LoadTestDuration segundos" -ForegroundColor White
    Write-Host ""
    
    try {
        # Configurar parâmetros do teste de carga
        $env:LOAD_TEST_USERS = $LoadTestUsers
        $env:LOAD_TEST_DURATION = $LoadTestDuration
        $env:LOAD_TEST_BASE_URL = $ApiUrl
        
        python tests/load_testing.py
        
        if ($LASTEXITCODE -eq 0) {
            Write-Host "✅ Testes de carga concluídos!" -ForegroundColor Green
            
            # Mostrar arquivos de resultado
            $resultFiles = Get-ChildItem -Name "load_test_results_*.json" | Sort-Object -Descending | Select-Object -First 1
            if ($resultFiles) {
                Write-Host "📄 Resultados salvos em: $resultFiles" -ForegroundColor Cyan
            }
        } else {
            Write-Host "❌ Testes de carga falharam" -ForegroundColor Red
        }
    } catch {
        Write-Host "❌ Erro ao executar testes de carga: $_" -ForegroundColor Red
    }
}

# Função para executar testes de performance
function Run-PerformanceTests {
    Write-Host "🚀 Executando testes de performance..." -ForegroundColor Yellow
    
    try {
        # Teste de endpoints críticos
        $endpoints = @(
            "/health",
            "/api/v1/contracts",
            "/api/v1/entities", 
            "/api/v1/quality/rules",
            "/docs"
        )
        
        Write-Host "📊 Testando performance dos endpoints..." -ForegroundColor White
        
        $results = @()
        
        foreach ($endpoint in $endpoints) {
            $url = "$ApiUrl$endpoint"
            Write-Host "   Testando: $endpoint" -ForegroundColor Gray
            
            # Fazer 10 requisições e medir tempo
            $times = @()
            for ($i = 1; $i -le 10; $i++) {
                $start = Get-Date
                try {
                    Invoke-RestMethod -Uri $url -TimeoutSec 10 | Out-Null
                    $end = Get-Date
                    $duration = ($end - $start).TotalMilliseconds
                    $times += $duration
                } catch {
                    Write-Host "     ❌ Falha na requisição $i" -ForegroundColor Red
                }
            }
            
            if ($times.Count -gt 0) {
                $avgTime = ($times | Measure-Object -Average).Average
                $maxTime = ($times | Measure-Object -Maximum).Maximum
                $minTime = ($times | Measure-Object -Minimum).Minimum
                
                Write-Host "     ✅ Média: $([math]::Round($avgTime, 1))ms | Min: $([math]::Round($minTime, 1))ms | Max: $([math]::Round($maxTime, 1))ms" -ForegroundColor Green
                
                $results += [PSCustomObject]@{
                    Endpoint = $endpoint
                    AvgTime = [math]::Round($avgTime, 1)
                    MinTime = [math]::Round($minTime, 1)
                    MaxTime = [math]::Round($maxTime, 1)
                    Requests = $times.Count
                }
            }
        }
        
        # Salvar resultados
        $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
        $results | ConvertTo-Json | Out-File "performance_test_results_$timestamp.json" -Encoding UTF8
        
        Write-Host ""
        Write-Host "✅ Testes de performance concluídos!" -ForegroundColor Green
        Write-Host "📄 Resultados salvos em: performance_test_results_$timestamp.json" -ForegroundColor Cyan
        
    } catch {
        Write-Host "❌ Erro ao executar testes de performance: $_" -ForegroundColor Red
    }
}

# Função para testar rate limiting
function Test-RateLimiting {
    Write-Host "🔒 Testando rate limiting..." -ForegroundColor Yellow
    
    try {
        $endpoint = "$ApiUrl/api/v1/contracts"
        $requestCount = 0
        $rateLimitHit = $false
        $startTime = Get-Date
        
        Write-Host "   Fazendo requisições rápidas para testar limite..." -ForegroundColor White
        
        # Fazer muitas requisições rapidamente
        for ($i = 1; $i -le 200; $i++) {
            try {
                $response = Invoke-WebRequest -Uri $endpoint -TimeoutSec 5 -ErrorAction Stop
                $requestCount++
                
                if ($i % 20 -eq 0) {
                    Write-Host "     Requisições: $requestCount" -ForegroundColor Gray
                }
                
            } catch {
                if ($_.Exception.Response.StatusCode -eq 429) {
                    $rateLimitHit = $true
                    $endTime = Get-Date
                    $duration = ($endTime - $startTime).TotalSeconds
                    
                    Write-Host "     ✅ Rate limit ativado após $requestCount requisições em $([math]::Round($duration, 1))s" -ForegroundColor Green
                    break
                } else {
                    Write-Host "     ❌ Erro inesperado: $($_.Exception.Message)" -ForegroundColor Red
                }
            }
            
            # Pequena pausa para não sobrecarregar
            Start-Sleep -Milliseconds 50
        }
        
        if ($rateLimitHit) {
            Write-Host "✅ Rate limiting está funcionando corretamente!" -ForegroundColor Green
        } else {
            Write-Host "⚠️  Rate limiting não foi ativado (pode estar desabilitado)" -ForegroundColor Yellow
        }
        
    } catch {
        Write-Host "❌ Erro ao testar rate limiting: $_" -ForegroundColor Red
    }
}

# Função para testar audit logs
function Test-AuditLogs {
    Write-Host "📝 Testando audit logs..." -ForegroundColor Yellow
    
    try {
        # Fazer algumas operações que devem gerar logs
        $operations = @(
            @{ Method = "GET"; Endpoint = "/api/v1/contracts" },
            @{ Method = "GET"; Endpoint = "/api/v1/entities" },
            @{ Method = "GET"; Endpoint = "/api/v1/audit/logs" }
        )
        
        Write-Host "   Executando operações para gerar logs..." -ForegroundColor White
        
        foreach ($op in $operations) {
            $url = "$ApiUrl$($op.Endpoint)"
            try {
                if ($op.Method -eq "GET") {
                    Invoke-RestMethod -Uri $url -TimeoutSec 10 | Out-Null
                }
                Write-Host "     ✅ $($op.Method) $($op.Endpoint)" -ForegroundColor Green
            } catch {
                Write-Host "     ❌ $($op.Method) $($op.Endpoint): $($_.Exception.Message)" -ForegroundColor Red
            }
        }
        
        # Verificar se logs foram criados
        Start-Sleep 2
        
        try {
            $logsResponse = Invoke-RestMethod -Uri "$ApiUrl/api/v1/audit/logs?limit=10" -TimeoutSec 10
            
            if ($logsResponse -and $logsResponse.Count -gt 0) {
                Write-Host "✅ Audit logs estão sendo gerados corretamente!" -ForegroundColor Green
                Write-Host "   Logs encontrados: $($logsResponse.Count)" -ForegroundColor White
            } else {
                Write-Host "⚠️  Nenhum audit log encontrado" -ForegroundColor Yellow
            }
        } catch {
            Write-Host "❌ Erro ao verificar audit logs: $($_.Exception.Message)" -ForegroundColor Red
        }
        
    } catch {
        Write-Host "❌ Erro ao testar audit logs: $_" -ForegroundColor Red
    }
}

# Executar testes baseado no tipo
Write-Host "🚀 Iniciando execução dos testes..." -ForegroundColor Cyan
Write-Host ""

switch ($TestType.ToLower()) {
    "unit" {
        Run-UnitTests
    }
    "integration" {
        Run-IntegrationTests
    }
    "load" {
        Run-LoadTests
    }
    "performance" {
        Run-PerformanceTests
    }
    "rate" {
        Test-RateLimiting
    }
    "audit" {
        Test-AuditLogs
    }
    "all" {
        Write-Host "📋 Executando todos os tipos de teste..." -ForegroundColor Cyan
        Write-Host ""
        
        Run-UnitTests
        Write-Host ""
        
        Run-IntegrationTests
        Write-Host ""
        
        Run-PerformanceTests
        Write-Host ""
        
        Test-RateLimiting
        Write-Host ""
        
        Test-AuditLogs
        Write-Host ""
        
        # Load test por último (mais demorado)
        Write-Host "⚠️  Teste de carga será executado por último (pode demorar)..." -ForegroundColor Yellow
        $continue = Read-Host "Continuar com teste de carga? (s/N)"
        
        if ($continue -eq "s" -or $continue -eq "S") {
            Write-Host ""
            Run-LoadTests
        } else {
            Write-Host "⏭️  Teste de carga pulado" -ForegroundColor Yellow
        }
    }
    default {
        Write-Host "❌ Tipo de teste inválido: $TestType" -ForegroundColor Red
        Write-Host "   Tipos válidos: all, unit, integration, load, performance, rate, audit" -ForegroundColor Yellow
        exit 1
    }
}

Write-Host ""
Write-Host "🎉 Execução de testes concluída!" -ForegroundColor Green
Write-Host ""
Write-Host "📁 Arquivos gerados:" -ForegroundColor Cyan

# Listar arquivos de resultado
$resultFiles = @(
    "htmlcov/index.html",
    "load_test_results_*.json",
    "performance_test_results_*.json"
)

foreach ($pattern in $resultFiles) {
    $files = Get-ChildItem -Name $pattern -ErrorAction SilentlyContinue
    foreach ($file in $files) {
        Write-Host "   • $file" -ForegroundColor White
    }
}

Write-Host ""
pause

