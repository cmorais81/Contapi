# ========================================
# Setup Load Balancer - API Governança
# Desenvolvido por Carlos Morais
# ========================================

param(
    [Parameter(Mandatory=$false)]
    [int]$Instances = 3,
    
    [Parameter(Mandatory=$false)]
    [int]$StartPort = 8000,
    
    [Parameter(Mandatory=$false)]
    [string]$Strategy = "least_connections"
)

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Setup Load Balancer - API Governança" -ForegroundColor Cyan
Write-Host "  Desenvolvido por Carlos Morais" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Verificar se está executando como administrador
if (-NOT ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    Write-Host "❌ Este script precisa ser executado como Administrador!" -ForegroundColor Red
    Write-Host "   Clique com botão direito no PowerShell e selecione 'Executar como administrador'" -ForegroundColor Yellow
    pause
    exit 1
}

# Verificar se Python está instalado
Write-Host "🔍 Verificando Python..." -ForegroundColor Yellow
try {
    $pythonVersion = python --version 2>&1
    if ($pythonVersion -match "Python 3\.1[4-9]") {
        Write-Host "✅ Python encontrado: $pythonVersion" -ForegroundColor Green
    } else {
        Write-Host "❌ Python 3.14+ não encontrado!" -ForegroundColor Red
        Write-Host "   Instale Python 3.14+ de https://python.org" -ForegroundColor Yellow
        pause
        exit 1
    }
} catch {
    Write-Host "❌ Python não encontrado no PATH!" -ForegroundColor Red
    pause
    exit 1
}

# Verificar se nginx está disponível (opcional)
Write-Host "🔍 Verificando nginx..." -ForegroundColor Yellow
try {
    $nginxVersion = nginx -v 2>&1
    Write-Host "✅ Nginx encontrado: $nginxVersion" -ForegroundColor Green
    $useNginx = $true
} catch {
    Write-Host "⚠️  Nginx não encontrado - usando load balancer interno" -ForegroundColor Yellow
    $useNginx = $false
}

# Criar diretórios necessários
Write-Host "📁 Criando estrutura de diretórios..." -ForegroundColor Yellow
$dirs = @(
    "logs",
    "config\nginx",
    "config\instances",
    "scripts\instances",
    "data\ssl"
)

foreach ($dir in $dirs) {
    if (!(Test-Path $dir)) {
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
        Write-Host "   ✅ Criado: $dir" -ForegroundColor Green
    }
}

# Configurar instâncias da API
Write-Host "⚙️  Configurando $Instances instâncias da API..." -ForegroundColor Yellow

for ($i = 0; $i -lt $Instances; $i++) {
    $port = $StartPort + $i
    $instanceName = "instance_$i"
    
    # Criar arquivo de configuração da instância
    $configContent = @"
# Configuração da Instância $i
# Porta: $port

DATABASE_URL=sqlite:///./data/governance_$instanceName.db
REDIS_URL=redis://localhost:6379/$i
API_PORT=$port
API_HOST=0.0.0.0
INSTANCE_ID=$instanceName
LOAD_BALANCER_STRATEGY=$Strategy
ENABLE_METRICS=true
ENABLE_HEALTH_CHECK=true
LOG_LEVEL=INFO
"@
    
    $configPath = "config\instances\$instanceName.env"
    $configContent | Out-File -FilePath $configPath -Encoding UTF8
    Write-Host "   ✅ Configuração criada: $configPath" -ForegroundColor Green
    
    # Criar script de inicialização da instância
    $startScript = @"
# Script de inicialização - Instância $i
# Porta: $port

Write-Host "🚀 Iniciando Instância $i na porta $port..." -ForegroundColor Cyan

# Definir variáveis de ambiente
`$env:PYTHONPATH = "`$PWD\src"
`$env:API_PORT = "$port"
`$env:INSTANCE_ID = "$instanceName"

# Carregar configurações específicas da instância
if (Test-Path "config\instances\$instanceName.env") {
    Get-Content "config\instances\$instanceName.env" | ForEach-Object {
        if (`$_ -match "^([^=]+)=(.*)$") {
            [Environment]::SetEnvironmentVariable(`$matches[1], `$matches[2], "Process")
        }
    }
}

# Iniciar API
try {
    Write-Host "📡 Iniciando servidor na porta $port..." -ForegroundColor Yellow
    python -m uvicorn main:app --host 0.0.0.0 --port $port --reload --log-level info
} catch {
    Write-Host "❌ Erro ao iniciar instância $i`: `$_" -ForegroundColor Red
    pause
}
"@
    
    $scriptPath = "scripts\instances\start_$instanceName.ps1"
    $startScript | Out-File -FilePath $scriptPath -Encoding UTF8
    Write-Host "   ✅ Script criado: $scriptPath" -ForegroundColor Green
}

# Configurar nginx se disponível
if ($useNginx) {
    Write-Host "🌐 Configurando nginx..." -ForegroundColor Yellow
    
    # Copiar configuração nginx
    $nginxConfigSource = "config\nginx.conf"
    $nginxConfigDest = "config\nginx\governance-api.conf"
    
    if (Test-Path $nginxConfigSource) {
        Copy-Item $nginxConfigSource $nginxConfigDest
        
        # Atualizar configuração com as portas das instâncias
        $nginxConfig = Get-Content $nginxConfigDest
        $upstreamSection = ""
        
        for ($i = 0; $i -lt $Instances; $i++) {
            $port = $StartPort + $i
            $weight = if ($i -eq ($Instances - 1)) { 2 } else { 3 }
            $backup = if ($i -eq ($Instances - 1)) { " backup" } else { "" }
            $upstreamSection += "    server 127.0.0.1:$port weight=$weight max_fails=3 fail_timeout=30s$backup;`n"
        }
        
        # Substituir seção upstream
        $nginxConfig = $nginxConfig -replace "(?s)upstream governance_api_backend \{.*?\}", "upstream governance_api_backend {`n    least_conn;`n$upstreamSection    keepalive 32;`n}"
        
        $nginxConfig | Out-File -FilePath $nginxConfigDest -Encoding UTF8
        Write-Host "   ✅ Configuração nginx atualizada" -ForegroundColor Green
    }
}

# Criar script de inicialização do load balancer
Write-Host "⚖️  Criando script de load balancer..." -ForegroundColor Yellow

$loadBalancerScript = @"
# ========================================
# Load Balancer - API Governança
# Desenvolvido por Carlos Morais
# ========================================

Write-Host "⚖️  Iniciando Load Balancer..." -ForegroundColor Cyan
Write-Host "   Estratégia: $Strategy" -ForegroundColor Yellow
Write-Host "   Instâncias: $Instances" -ForegroundColor Yellow
Write-Host "   Portas: $StartPort-$($StartPort + $Instances - 1)" -ForegroundColor Yellow
Write-Host ""

# Função para iniciar instância em background
function Start-APIInstance {
    param([int]`$InstanceNumber, [int]`$Port)
    
    `$instanceName = "instance_`$InstanceNumber"
    `$scriptPath = "scripts\instances\start_`$instanceName.ps1"
    
    if (Test-Path `$scriptPath) {
        Write-Host "🚀 Iniciando `$instanceName na porta `$Port..." -ForegroundColor Green
        
        # Iniciar em nova janela do PowerShell
        Start-Process powershell -ArgumentList "-NoExit", "-File", "`$scriptPath" -WindowStyle Minimized
        
        Start-Sleep 2
    } else {
        Write-Host "❌ Script não encontrado: `$scriptPath" -ForegroundColor Red
    }
}

# Iniciar todas as instâncias
for (`$i = 0; `$i -lt $Instances; `$i++) {
    `$port = $StartPort + `$i
    Start-APIInstance -InstanceNumber `$i -Port `$port
}

Write-Host ""
Write-Host "⏳ Aguardando instâncias iniciarem..." -ForegroundColor Yellow
Start-Sleep 10

# Verificar se instâncias estão respondendo
Write-Host "🔍 Verificando saúde das instâncias..." -ForegroundColor Yellow

for (`$i = 0; `$i -lt $Instances; `$i++) {
    `$port = $StartPort + `$i
    try {
        `$response = Invoke-RestMethod -Uri "http://localhost:`$port/health" -TimeoutSec 5
        if (`$response.status -eq "healthy") {
            Write-Host "   ✅ Instância `$i (porta `$port): Saudável" -ForegroundColor Green
        } else {
            Write-Host "   ⚠️  Instância `$i (porta `$port): Status desconhecido" -ForegroundColor Yellow
        }
    } catch {
        Write-Host "   ❌ Instância `$i (porta `$port): Não responde" -ForegroundColor Red
    }
}

Write-Host ""
if ($useNginx) {
    Write-Host "🌐 Para usar nginx como load balancer:" -ForegroundColor Cyan
    Write-Host "   1. Copie config\nginx\governance-api.conf para nginx/conf.d/" -ForegroundColor White
    Write-Host "   2. Reinicie nginx" -ForegroundColor White
    Write-Host "   3. Acesse: http://localhost" -ForegroundColor White
} else {
    Write-Host "🔗 Endpoints disponíveis:" -ForegroundColor Cyan
    for (`$i = 0; `$i -lt $Instances; `$i++) {
        `$port = $StartPort + `$i
        Write-Host "   • Instância `$i: http://localhost:`$port" -ForegroundColor White
        Write-Host "   • Swagger `$i: http://localhost:`$port/docs" -ForegroundColor White
    }
}

Write-Host ""
Write-Host "📊 Monitoramento:" -ForegroundColor Cyan
Write-Host "   • Métricas: http://localhost:$StartPort/metrics" -ForegroundColor White
Write-Host "   • Health: http://localhost:$StartPort/health" -ForegroundColor White
Write-Host "   • Logs: .\logs\" -ForegroundColor White

Write-Host ""
Write-Host "✅ Load Balancer configurado com sucesso!" -ForegroundColor Green
Write-Host "   Pressione Ctrl+C para parar todas as instâncias" -ForegroundColor Yellow

# Manter script rodando
try {
    while (`$true) {
        Start-Sleep 30
        
        # Verificar se alguma instância caiu
        `$downInstances = 0
        for (`$i = 0; `$i -lt $Instances; `$i++) {
            `$port = $StartPort + `$i
            try {
                Invoke-RestMethod -Uri "http://localhost:`$port/health" -TimeoutSec 2 | Out-Null
            } catch {
                `$downInstances++
            }
        }
        
        if (`$downInstances -gt 0) {
            Write-Host "⚠️  `$downInstances instância(s) não respondem" -ForegroundColor Yellow
        }
    }
} catch {
    Write-Host ""
    Write-Host "🛑 Parando load balancer..." -ForegroundColor Red
    
    # Parar todas as instâncias (seria necessário implementar)
    Write-Host "   Para parar manualmente, feche as janelas das instâncias" -ForegroundColor Yellow
}
"@

$loadBalancerScript | Out-File -FilePath "scripts\start_load_balancer.ps1" -Encoding UTF8
Write-Host "   ✅ Script criado: scripts\start_load_balancer.ps1" -ForegroundColor Green

# Criar script de monitoramento
$monitoringScript = @"
# Script de Monitoramento - Load Balancer
# Desenvolvido por Carlos Morais

Write-Host "📊 Monitor Load Balancer - API Governança" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan

while (`$true) {
    Clear-Host
    Write-Host "📊 Monitor Load Balancer - $(Get-Date)" -ForegroundColor Cyan
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host ""
    
    `$totalRequests = 0
    `$healthyInstances = 0
    
    for (`$i = 0; `$i -lt $Instances; `$i++) {
        `$port = $StartPort + `$i
        `$instanceName = "Instância `$i"
        
        try {
            `$health = Invoke-RestMethod -Uri "http://localhost:`$port/health" -TimeoutSec 3
            `$metrics = Invoke-RestMethod -Uri "http://localhost:`$port/metrics" -TimeoutSec 3 -ErrorAction SilentlyContinue
            
            Write-Host "✅ `$instanceName (:`$port)" -ForegroundColor Green
            Write-Host "   Status: `$(`$health.status)" -ForegroundColor White
            
            if (`$metrics) {
                Write-Host "   Requests: `$(`$metrics.total_requests)" -ForegroundColor White
                Write-Host "   Avg Response: `$(`$metrics.avg_response_time)ms" -ForegroundColor White
                `$totalRequests += `$metrics.total_requests
            }
            
            `$healthyInstances++
            
        } catch {
            Write-Host "❌ `$instanceName (:`$port)" -ForegroundColor Red
            Write-Host "   Status: Offline" -ForegroundColor Red
        }
        
        Write-Host ""
    }
    
    Write-Host "📈 Resumo:" -ForegroundColor Yellow
    Write-Host "   Instâncias Saudáveis: `$healthyInstances/$Instances" -ForegroundColor White
    Write-Host "   Total de Requests: `$totalRequests" -ForegroundColor White
    Write-Host "   Estratégia: $Strategy" -ForegroundColor White
    
    Write-Host ""
    Write-Host "Pressione Ctrl+C para sair..." -ForegroundColor Gray
    
    Start-Sleep 10
}
"@

$monitoringScript | Out-File -FilePath "scripts\monitor_load_balancer.ps1" -Encoding UTF8
Write-Host "   ✅ Script criado: scripts\monitor_load_balancer.ps1" -ForegroundColor Green

Write-Host ""
Write-Host "🎉 Setup do Load Balancer concluído!" -ForegroundColor Green
Write-Host ""
Write-Host "📋 Próximos passos:" -ForegroundColor Cyan
Write-Host "   1. Execute: .\scripts\start_load_balancer.ps1" -ForegroundColor White
Write-Host "   2. Monitore: .\scripts\monitor_load_balancer.ps1" -ForegroundColor White
Write-Host "   3. Teste: http://localhost:$StartPort/docs" -ForegroundColor White
Write-Host ""
Write-Host "📁 Arquivos criados:" -ForegroundColor Yellow
Write-Host "   • $Instances configurações de instância em config\instances\" -ForegroundColor White
Write-Host "   • $Instances scripts de inicialização em scripts\instances\" -ForegroundColor White
Write-Host "   • Script principal: scripts\start_load_balancer.ps1" -ForegroundColor White
Write-Host "   • Script de monitoramento: scripts\monitor_load_balancer.ps1" -ForegroundColor White
if ($useNginx) {
    Write-Host "   • Configuração nginx: config\nginx\governance-api.conf" -ForegroundColor White
}

Write-Host ""
pause

