"""
Circuit Breaker Pattern para resiliência
"""

import asyncio
import time
from enum import Enum
from typing import Any, Callable, Optional, TypeVar

from config.settings import get_settings
from domain.exceptions import CircuitBreakerOpenError

T = TypeVar('T')
settings = get_settings()


class CircuitBreakerState(Enum):
    """Estados do circuit breaker"""
    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


class CircuitBreaker:
    """Implementação do Circuit Breaker Pattern"""
    
    def __init__(
        self,
        failure_threshold: int = None,
        recovery_timeout: int = None,
        expected_exception: type = Exception
    ):
        self.failure_threshold = failure_threshold or settings.circuit_breaker_failure_threshold
        self.recovery_timeout = recovery_timeout or settings.circuit_breaker_recovery_timeout
        self.expected_exception = expected_exception
        
        self.failure_count = 0
        self.last_failure_time = None
        self.state = CircuitBreakerState.CLOSED
        self._lock = asyncio.Lock()
    
    async def call(self, func: Callable[..., T], *args, **kwargs) -> T:
        """Executa função com circuit breaker"""
        async with self._lock:
            if self.state == CircuitBreakerState.OPEN:
                if self._should_attempt_reset():
                    self.state = CircuitBreakerState.HALF_OPEN
                else:
                    raise CircuitBreakerOpenError(
                        f"Circuit breaker is open. Last failure: {self.last_failure_time}"
                    )
            
            try:
                result = await func(*args, **kwargs) if asyncio.iscoroutinefunction(func) else func(*args, **kwargs)
                self._on_success()
                return result
            
            except self.expected_exception as e:
                self._on_failure()
                raise e
    
    def _should_attempt_reset(self) -> bool:
        """Verifica se deve tentar resetar o circuit breaker"""
        if self.last_failure_time is None:
            return True
        
        return time.time() - self.last_failure_time >= self.recovery_timeout
    
    def _on_success(self):
        """Callback para sucesso"""
        self.failure_count = 0
        self.state = CircuitBreakerState.CLOSED
    
    def _on_failure(self):
        """Callback para falha"""
        self.failure_count += 1
        self.last_failure_time = time.time()
        
        if self.failure_count >= self.failure_threshold:
            self.state = CircuitBreakerState.OPEN
    
    @property
    def is_open(self) -> bool:
        """Verifica se circuit breaker está aberto"""
        return self.state == CircuitBreakerState.OPEN
    
    @property
    def is_half_open(self) -> bool:
        """Verifica se circuit breaker está meio aberto"""
        return self.state == CircuitBreakerState.HALF_OPEN
    
    @property
    def is_closed(self) -> bool:
        """Verifica se circuit breaker está fechado"""
        return self.state == CircuitBreakerState.CLOSED
    
    def reset(self):
        """Reseta o circuit breaker"""
        self.failure_count = 0
        self.last_failure_time = None
        self.state = CircuitBreakerState.CLOSED
    
    def get_stats(self) -> dict:
        """Retorna estatísticas do circuit breaker"""
        return {
            "state": self.state.value,
            "failure_count": self.failure_count,
            "failure_threshold": self.failure_threshold,
            "last_failure_time": self.last_failure_time,
            "recovery_timeout": self.recovery_timeout
        }


def circuit_breaker(
    failure_threshold: int = None,
    recovery_timeout: int = None,
    expected_exception: type = Exception
):
    """Decorator para circuit breaker"""
    
    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        cb = CircuitBreaker(failure_threshold, recovery_timeout, expected_exception)
        
        async def async_wrapper(*args, **kwargs) -> T:
            return await cb.call(func, *args, **kwargs)
        
        def sync_wrapper(*args, **kwargs) -> T:
            return asyncio.run(cb.call(func, *args, **kwargs))
        
        if asyncio.iscoroutinefunction(func):
            return async_wrapper
        else:
            return sync_wrapper
    
    return decorator


class CircuitBreakerRegistry:
    """Registry para gerenciar múltiplos circuit breakers"""
    
    def __init__(self):
        self._breakers = {}
    
    def get_breaker(
        self,
        name: str,
        failure_threshold: int = None,
        recovery_timeout: int = None,
        expected_exception: type = Exception
    ) -> CircuitBreaker:
        """Obtém ou cria um circuit breaker"""
        if name not in self._breakers:
            self._breakers[name] = CircuitBreaker(
                failure_threshold, recovery_timeout, expected_exception
            )
        return self._breakers[name]
    
    def get_all_stats(self) -> dict:
        """Retorna estatísticas de todos os circuit breakers"""
        return {
            name: breaker.get_stats()
            for name, breaker in self._breakers.items()
        }
    
    def reset_all(self):
        """Reseta todos os circuit breakers"""
        for breaker in self._breakers.values():
            breaker.reset()
    
    def reset_breaker(self, name: str):
        """Reseta um circuit breaker específico"""
        if name in self._breakers:
            self._breakers[name].reset()


# Instância global do registry
circuit_breaker_registry = CircuitBreakerRegistry()

