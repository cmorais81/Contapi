"""
External Integrations - Clientes para sistemas externos
"""

