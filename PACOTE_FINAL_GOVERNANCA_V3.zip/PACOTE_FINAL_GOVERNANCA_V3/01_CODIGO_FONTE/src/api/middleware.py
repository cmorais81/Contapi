"""
Middleware para a API
"""

import time
from typing import Callable
from uuid import uuid4

from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.middleware.base import RequestResponseEndpoint

from config.settings import get_settings

settings = get_settings()


class RequestLoggingMiddleware(BaseHTTPMiddleware):
    """Middleware para logging de requisições"""
    
    async def dispatch(
        self, 
        request: Request, 
        call_next: RequestResponseEndpoint
    ) -> Response:
        # Gerar ID único para a requisição
        request_id = str(uuid4())
        request.state.request_id = request_id
        
        # Capturar tempo de início
        start_time = time.time()
        
        # Adicionar headers de request ID
        response = await call_next(request)
        
        # Calcular tempo de processamento
        process_time = time.time() - start_time
        
        # Adicionar headers de resposta
        response.headers["X-Request-ID"] = request_id
        response.headers["X-Process-Time"] = str(process_time)
        
        # Log da requisição (em produção, usar logger estruturado)
        if settings.log_level == "DEBUG":
            print(f"Request {request_id}: {request.method} {request.url} - "
                  f"{response.status_code} - {process_time:.3f}s")
        
        return response


class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    """Middleware para headers de segurança"""
    
    async def dispatch(
        self, 
        request: Request, 
        call_next: RequestResponseEndpoint
    ) -> Response:
        response = await call_next(request)
        
        # Headers de segurança
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["X-XSS-Protection"] = "1; mode=block"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        
        # CSP para APIs (mais restritivo)
        response.headers["Content-Security-Policy"] = (
            "default-src 'none'; "
            "script-src 'self'; "
            "style-src 'self' 'unsafe-inline'; "
            "img-src 'self' data:; "
            "connect-src 'self'"
        )
        
        return response


class RateLimitMiddleware(BaseHTTPMiddleware):
    """Middleware básico de rate limiting"""
    
    def __init__(self, app, calls: int = 100, period: int = 60):
        super().__init__(app)
        self.calls = calls
        self.period = period
        self.clients = {}
    
    async def dispatch(
        self, 
        request: Request, 
        call_next: RequestResponseEndpoint
    ) -> Response:
        if not settings.rate_limit_enabled:
            return await call_next(request)
        
        # Obter IP do cliente
        client_ip = request.client.host
        current_time = time.time()
        
        # Limpar entradas antigas
        self.clients = {
            ip: timestamps for ip, timestamps in self.clients.items()
            if any(t > current_time - self.period for t in timestamps)
        }
        
        # Verificar rate limit
        if client_ip in self.clients:
            # Filtrar timestamps dentro do período
            self.clients[client_ip] = [
                t for t in self.clients[client_ip]
                if t > current_time - self.period
            ]
            
            if len(self.clients[client_ip]) >= self.calls:
                from fastapi import HTTPException, status
                raise HTTPException(
                    status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                    detail="Rate limit exceeded"
                )
        else:
            self.clients[client_ip] = []
        
        # Adicionar timestamp atual
        self.clients[client_ip].append(current_time)
        
        return await call_next(request)


class ErrorHandlingMiddleware(BaseHTTPMiddleware):
    """Middleware para tratamento de erros"""
    
    async def dispatch(
        self, 
        request: Request, 
        call_next: RequestResponseEndpoint
    ) -> Response:
        try:
            return await call_next(request)
        except Exception as exc:
            # Em produção, usar logger estruturado
            print(f"Unhandled error: {exc}")
            
            from fastapi import HTTPException, status
            from fastapi.responses import JSONResponse
            
            # Retornar erro genérico para não vazar informações
            return JSONResponse(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                content={
                    "error": "InternalServerError",
                    "message": "An internal error occurred",
                    "request_id": getattr(request.state, "request_id", None)
                }
            )

