# 🔍 Guia Completo de Consultas - API de Governança de Dados V2.1

**Desenvolvido por:** Carlos Morais  
**Data:** Janeiro 2025  
**Versão:** 2.1 Final  
**Modelo:** 56 tabelas organizadas em 12 domínios funcionais

---

## 📋 Índice

1. [Visão Geral das Consultas](#visão-geral-das-consultas)
2. [Consultas por Domínio Funcional](#consultas-por-domínio-funcional)
3. [Consultas de Governança](#consultas-de-governança)
4. [Consultas de Qualidade](#consultas-de-qualidade)
5. [Consultas de Lineage](#consultas-de-lineage)
6. [Consultas de Auditoria](#consultas-de-auditoria)
7. [Consultas de Performance](#consultas-de-performance)
8. [Consultas Analíticas](#consultas-analíticas)
9. [Consultas de Compliance](#consultas-de-compliance)
10. [Consultas Avançadas](#consultas-avançadas)
11. [APIs e Endpoints](#apis-e-endpoints)
12. [Casos de Uso Práticos](#casos-de-uso-práticos)

---

## 🎯 Visão Geral das Consultas

### Tipos de Consultas Suportadas

#### **📊 Por Categoria**
```
🔍 DESCOBERTA E CATÁLOGO:
├─ Busca de entidades por critérios
├─ Exploração de domínios e hierarquias
├─ Descoberta de dados relacionados
└─ Análise de uso e popularidade

📋 GOVERNANÇA E COMPLIANCE:
├─ Status de contratos e aprovações
├─ Verificação de políticas
├─ Rastreamento de mudanças
└─ Relatórios de compliance

🎯 QUALIDADE DE DADOS:
├─ Métricas de qualidade por dimensão
├─ Identificação de problemas
├─ Tendências e alertas
└─ Análise de incidentes

🔗 LINEAGE E RELACIONAMENTOS:
├─ Rastreamento upstream/downstream
├─ Análise de impacto
├─ Mapeamento de dependências
└─ Visualização de fluxos

📈 ANALYTICS E MÉTRICAS:
├─ Uso de dados e sistemas
├─ Performance e otimização
├─ Tendências e padrões
└─ ROI de governança
```

#### **🎯 Por Público-Alvo**
```
👥 USUÁRIOS DE NEGÓCIO:
├─ "Quais dados temos sobre clientes?"
├─ "Onde encontro dados de vendas?"
├─ "Qual a qualidade dos dados de produto?"
└─ "Quem é responsável por estes dados?"

🔧 EQUIPES TÉCNICAS:
├─ "Qual o lineage desta tabela?"
├─ "Que sistemas são impactados por mudanças?"
├─ "Quais são as regras de qualidade ativas?"
└─ "Como está a performance das consultas?"

📊 DATA STEWARDS:
├─ "Quais entidades precisam de atenção?"
├─ "Onde temos problemas de qualidade?"
├─ "Quais contratos estão vencendo?"
└─ "Como está a adoção da governança?"

🏢 GESTORES E EXECUTIVOS:
├─ "Qual o ROI da governança de dados?"
├─ "Estamos em compliance?"
├─ "Quais são os riscos de dados?"
└─ "Como melhorar a qualidade?"
```

### Estrutura das Consultas

#### **SQL Direto (Banco de Dados)**
```sql
-- Acesso direto ao PostgreSQL
SELECT * FROM entities WHERE domain_id = 'customer_domain';
```

#### **API REST (Aplicação)**
```bash
# Via endpoints da API
GET /api/v1/entities?domain=customer&status=active
```

#### **GraphQL (Consultas Complexas)**
```graphql
# Consultas relacionais complexas
query {
  entities(domain: "customer") {
    name
    attributes {
      name
      dataType
    }
    qualityRules {
      name
      status
    }
  }
}
```

---


## 🏗️ Consultas por Domínio Funcional

### 1. 🔐 Domínio: Autenticação e Usuários

#### **Gestão de Usuários**
```sql
-- Listar usuários ativos
SELECT 
    username,
    email,
    full_name,
    is_admin,
    last_login,
    created_at
FROM users 
WHERE is_active = true
ORDER BY last_login DESC;

-- Usuários que não fazem login há mais de 30 dias
SELECT 
    username,
    email,
    last_login,
    EXTRACT(DAYS FROM NOW() - last_login) as days_since_login
FROM users 
WHERE last_login < NOW() - INTERVAL '30 days'
    AND is_active = true
ORDER BY last_login ASC;

-- Usuários com tentativas de login falhadas
SELECT 
    username,
    email,
    failed_login_attempts,
    locked_until
FROM users 
WHERE failed_login_attempts > 0
ORDER BY failed_login_attempts DESC;
```

#### **Análise de Tokens**
```sql
-- Tokens ativos por usuário
SELECT 
    u.username,
    COUNT(t.id) as active_tokens,
    MAX(t.expires_at) as latest_expiration
FROM users u
LEFT JOIN user_tokens t ON u.id = t.user_id 
WHERE t.is_revoked = false 
    AND t.expires_at > NOW()
GROUP BY u.id, u.username
ORDER BY active_tokens DESC;

-- Tokens expirados para limpeza
SELECT 
    token_type,
    COUNT(*) as expired_count,
    MIN(expires_at) as oldest_expiration
FROM user_tokens 
WHERE expires_at < NOW()
GROUP BY token_type;
```

#### **API Endpoints**
```bash
# Listar usuários
GET /api/v1/users?active=true&limit=50

# Buscar usuário específico
GET /api/v1/users/{user_id}

# Estatísticas de login
GET /api/v1/users/stats/login

# Tokens ativos
GET /api/v1/users/{user_id}/tokens?active=true
```

### 2. 📊 Domínio: Audit Logs e Compliance

#### **Análise de Auditoria**
```sql
-- Ações por usuário nas últimas 24 horas
SELECT 
    u.username,
    al.event_type,
    al.resource_type,
    COUNT(*) as action_count,
    MAX(al.created_at) as last_action
FROM audit_logs al
JOIN users u ON al.user_id = u.id
WHERE al.created_at >= NOW() - INTERVAL '24 hours'
GROUP BY u.username, al.event_type, al.resource_type
ORDER BY action_count DESC;

-- Mudanças em contratos críticos
SELECT 
    al.resource_id,
    al.action,
    al.old_values->>'name' as old_name,
    al.new_values->>'name' as new_name,
    u.username,
    al.created_at
FROM audit_logs al
JOIN users u ON al.user_id = u.id
WHERE al.resource_type = 'contract'
    AND al.event_type = 'UPDATE'
    AND al.created_at >= NOW() - INTERVAL '7 days'
ORDER BY al.created_at DESC;

-- Tentativas de acesso negadas
SELECT 
    al.ip_address,
    al.endpoint,
    al.status_code,
    COUNT(*) as failed_attempts,
    MAX(al.created_at) as last_attempt
FROM audit_logs al
WHERE al.status_code IN (401, 403, 404)
    AND al.created_at >= NOW() - INTERVAL '24 hours'
GROUP BY al.ip_address, al.endpoint, al.status_code
HAVING COUNT(*) > 5
ORDER BY failed_attempts DESC;
```

#### **Compliance e Retenção**
```sql
-- Logs elegíveis para arquivamento
SELECT 
    arp.policy_name,
    COUNT(al.id) as logs_count,
    MIN(al.created_at) as oldest_log,
    arp.retention_days
FROM audit_logs al
JOIN audit_log_retention_policies arp ON al.resource_type = ANY(arp.resource_types)
WHERE al.created_at < NOW() - (arp.retention_days || ' days')::INTERVAL
    AND arp.is_active = true
GROUP BY arp.policy_name, arp.retention_days;

-- Relatório de compliance por período
SELECT 
    DATE_TRUNC('day', created_at) as log_date,
    event_type,
    resource_type,
    COUNT(*) as event_count
FROM audit_logs 
WHERE created_at >= NOW() - INTERVAL '30 days'
GROUP BY DATE_TRUNC('day', created_at), event_type, resource_type
ORDER BY log_date DESC, event_count DESC;
```

#### **API Endpoints**
```bash
# Buscar logs de auditoria
GET /api/v1/audit/logs?user_id={id}&event_type=UPDATE&limit=100

# Logs por recurso
GET /api/v1/audit/logs?resource_type=contract&resource_id={id}

# Estatísticas de auditoria
GET /api/v1/audit/stats?period=7d

# Relatório de compliance
GET /api/v1/audit/compliance-report?start_date=2025-01-01&end_date=2025-01-07
```

### 3. ⚡ Domínio: Rate Limiting e Controle

#### **Análise de Rate Limiting**
```sql
-- Políticas mais violadas
SELECT 
    rlp.policy_name,
    COUNT(rlv.id) as violation_count,
    AVG(rlv.requests_count) as avg_requests,
    MAX(rlv.created_at) as last_violation
FROM rate_limit_violations rlv
JOIN rate_limit_policies rlp ON rlv.policy_id = rlp.id
WHERE rlv.created_at >= NOW() - INTERVAL '24 hours'
GROUP BY rlp.policy_name
ORDER BY violation_count DESC;

-- IPs com mais violações
SELECT 
    ip_address,
    COUNT(*) as violation_count,
    COUNT(DISTINCT policy_id) as policies_violated,
    MAX(created_at) as last_violation,
    MAX(blocked_until) as blocked_until
FROM rate_limit_violations 
WHERE created_at >= NOW() - INTERVAL '7 days'
GROUP BY ip_address
ORDER BY violation_count DESC
LIMIT 20;

-- Usuários que excedem limites frequentemente
SELECT 
    u.username,
    u.email,
    COUNT(rlv.id) as violation_count,
    STRING_AGG(DISTINCT rlp.policy_name, ', ') as violated_policies
FROM rate_limit_violations rlv
JOIN rate_limit_policies rlp ON rlv.policy_id = rlp.id
LEFT JOIN users u ON rlv.user_id = u.id
WHERE rlv.created_at >= NOW() - INTERVAL '30 days'
    AND u.id IS NOT NULL
GROUP BY u.username, u.email
HAVING COUNT(rlv.id) > 10
ORDER BY violation_count DESC;
```

#### **Monitoramento de Políticas**
```sql
-- Efetividade das políticas
SELECT 
    rlp.policy_name,
    rlp.requests_per_minute,
    rlp.requests_per_hour,
    COUNT(rlv.id) as violations_last_24h,
    CASE 
        WHEN COUNT(rlv.id) = 0 THEN 'Effective'
        WHEN COUNT(rlv.id) < 10 THEN 'Mostly Effective'
        WHEN COUNT(rlv.id) < 50 THEN 'Needs Adjustment'
        ELSE 'Ineffective'
    END as effectiveness
FROM rate_limit_policies rlp
LEFT JOIN rate_limit_violations rlv ON rlp.id = rlv.policy_id 
    AND rlv.created_at >= NOW() - INTERVAL '24 hours'
WHERE rlp.is_active = true
GROUP BY rlp.id, rlp.policy_name, rlp.requests_per_minute, rlp.requests_per_hour
ORDER BY violations_last_24h DESC;
```

#### **API Endpoints**
```bash
# Listar políticas de rate limiting
GET /api/v1/rate-limits/policies?active=true

# Violações por IP
GET /api/v1/rate-limits/violations?ip_address={ip}&period=24h

# Status de rate limiting para usuário
GET /api/v1/rate-limits/status/{user_id}

# Estatísticas de violações
GET /api/v1/rate-limits/stats?period=7d
```

### 4. 📈 Domínio: Performance e Monitoramento

#### **Análise de Performance**
```sql
-- Endpoints mais lentos
SELECT 
    endpoint,
    http_method,
    COUNT(*) as request_count,
    AVG(value_numeric) as avg_response_time_ms,
    PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY value_numeric) as p95_response_time,
    MAX(value_numeric) as max_response_time
FROM performance_metrics 
WHERE metric_name = 'response_time'
    AND timestamp >= NOW() - INTERVAL '24 hours'
GROUP BY endpoint, http_method
ORDER BY avg_response_time_ms DESC
LIMIT 20;

-- Queries mais lentas no banco
SELECT 
    query_hash,
    COUNT(*) as execution_count,
    AVG(execution_time_ms) as avg_execution_time,
    MAX(execution_time_ms) as max_execution_time,
    AVG(rows_examined) as avg_rows_examined,
    STRING_AGG(DISTINCT table_names::text, ', ') as tables_involved
FROM database_performance_logs 
WHERE created_at >= NOW() - INTERVAL '24 hours'
GROUP BY query_hash
ORDER BY avg_execution_time DESC
LIMIT 15;

-- Tendência de performance por hora
SELECT 
    DATE_TRUNC('hour', timestamp) as hour,
    AVG(value_numeric) as avg_response_time,
    COUNT(*) as request_count
FROM performance_metrics 
WHERE metric_name = 'response_time'
    AND timestamp >= NOW() - INTERVAL '7 days'
GROUP BY DATE_TRUNC('hour', timestamp)
ORDER BY hour;
```

#### **Monitoramento de Recursos**
```sql
-- Uso de memória e CPU
SELECT 
    DATE_TRUNC('minute', timestamp) as minute,
    AVG(CASE WHEN metric_name = 'memory_usage' THEN value_numeric END) as avg_memory_mb,
    AVG(CASE WHEN metric_name = 'cpu_usage' THEN value_numeric END) as avg_cpu_percent,
    AVG(CASE WHEN metric_name = 'active_connections' THEN value_numeric END) as avg_connections
FROM performance_metrics 
WHERE metric_name IN ('memory_usage', 'cpu_usage', 'active_connections')
    AND timestamp >= NOW() - INTERVAL '1 hour'
GROUP BY DATE_TRUNC('minute', timestamp)
ORDER BY minute DESC;
```

#### **API Endpoints**
```bash
# Métricas de performance
GET /api/v1/metrics/performance?period=24h&metric=response_time

# Queries lentas
GET /api/v1/metrics/database/slow-queries?limit=20

# Status do sistema
GET /api/v1/system/health

# Métricas em tempo real
GET /api/v1/metrics/realtime
```

### 5. 🏗️ Domínio: Domains e Organizações

#### **Hierarquia de Domínios**
```sql
-- Estrutura hierárquica completa
WITH RECURSIVE domain_hierarchy AS (
    -- Domínios raiz
    SELECT 
        id,
        name,
        description,
        parent_domain_id,
        steward_id,
        0 as level,
        name as path
    FROM domains 
    WHERE parent_domain_id IS NULL
    
    UNION ALL
    
    -- Subdomínios
    SELECT 
        d.id,
        d.name,
        d.description,
        d.parent_domain_id,
        d.steward_id,
        dh.level + 1,
        dh.path || ' > ' || d.name
    FROM domains d
    JOIN domain_hierarchy dh ON d.parent_domain_id = dh.id
)
SELECT 
    REPEAT('  ', level) || name as indented_name,
    path,
    level,
    (SELECT COUNT(*) FROM entities WHERE domain_id = domain_hierarchy.id) as entity_count,
    u.username as steward_name
FROM domain_hierarchy
LEFT JOIN users u ON domain_hierarchy.steward_id = u.id
ORDER BY path;

-- Domínios com mais entidades
SELECT 
    d.name as domain_name,
    d.description,
    COUNT(e.id) as entity_count,
    u.username as steward,
    d.status
FROM domains d
LEFT JOIN entities e ON d.id = e.domain_id
LEFT JOIN users u ON d.steward_id = u.id
GROUP BY d.id, d.name, d.description, u.username, d.status
ORDER BY entity_count DESC;
```

#### **Análise de Responsabilidades**
```sql
-- Carga de trabalho por Data Steward
SELECT 
    u.username as steward,
    u.email,
    COUNT(DISTINCT d.id) as domains_managed,
    COUNT(DISTINCT e.id) as entities_managed,
    COUNT(DISTINCT qr.id) as quality_rules_managed
FROM users u
LEFT JOIN domains d ON u.id = d.steward_id
LEFT JOIN entities e ON u.id = e.steward_id
LEFT JOIN quality_rules qr ON u.id = qr.created_by
WHERE u.is_active = true
GROUP BY u.id, u.username, u.email
HAVING COUNT(DISTINCT d.id) > 0 OR COUNT(DISTINCT e.id) > 0
ORDER BY entities_managed DESC;
```

#### **API Endpoints**
```bash
# Listar domínios
GET /api/v1/domains?include_hierarchy=true

# Domínio específico com entidades
GET /api/v1/domains/{domain_id}?include_entities=true

# Buscar domínios
GET /api/v1/domains/search?q=customer&steward={user_id}

# Estatísticas por domínio
GET /api/v1/domains/{domain_id}/stats
```

### 6. 📊 Domínio: Entidades e Atributos

#### **Descoberta de Entidades**
```sql
-- Busca textual em entidades
SELECT 
    e.name,
    e.display_name,
    e.description,
    d.name as domain_name,
    e.entity_type,
    e.data_classification,
    e.unity_catalog_path,
    u.username as owner
FROM entities e
JOIN domains d ON e.domain_id = d.id
LEFT JOIN users u ON e.owner_id = u.id
WHERE (
    e.name ILIKE '%customer%' 
    OR e.description ILIKE '%customer%'
    OR e.display_name ILIKE '%customer%'
)
AND e.status = 'active'
ORDER BY e.name;

-- Entidades por classificação de dados
SELECT 
    data_classification,
    COUNT(*) as entity_count,
    COUNT(CASE WHEN last_accessed_at > NOW() - INTERVAL '30 days' THEN 1 END) as recently_accessed,
    COUNT(CASE WHEN last_accessed_at IS NULL THEN 1 END) as never_accessed
FROM entities 
WHERE status = 'active'
GROUP BY data_classification
ORDER BY entity_count DESC;

-- Entidades órfãs (sem atributos documentados)
SELECT 
    e.name,
    e.display_name,
    d.name as domain_name,
    e.created_at,
    COUNT(ea.id) as attribute_count
FROM entities e
JOIN domains d ON e.domain_id = d.id
LEFT JOIN entity_attributes ea ON e.id = ea.entity_id
GROUP BY e.id, e.name, e.display_name, d.name, e.created_at
HAVING COUNT(ea.id) = 0
ORDER BY e.created_at DESC;
```

#### **Análise de Atributos**
```sql
-- Atributos com informações pessoais (PII)
SELECT 
    e.name as entity_name,
    ea.name as attribute_name,
    ea.description,
    ea.data_type,
    ea.masking_rule,
    ea.data_classification
FROM entity_attributes ea
JOIN entities e ON ea.entity_id = e.id
WHERE ea.is_pii = true
ORDER BY e.name, ea.name;

-- Distribuição de tipos de dados
SELECT 
    data_type,
    COUNT(*) as attribute_count,
    COUNT(CASE WHEN is_nullable = false THEN 1 END) as required_count,
    COUNT(CASE WHEN is_pii = true THEN 1 END) as pii_count
FROM entity_attributes 
GROUP BY data_type
ORDER BY attribute_count DESC;

-- Atributos sem documentação adequada
SELECT 
    e.name as entity_name,
    ea.name as attribute_name,
    ea.data_type,
    CASE 
        WHEN ea.description IS NULL OR LENGTH(ea.description) < 10 THEN 'Missing Description'
        WHEN ea.business_rules IS NULL THEN 'Missing Business Rules'
        WHEN ea.is_pii IS NULL THEN 'PII Classification Missing'
        ELSE 'OK'
    END as documentation_issue
FROM entity_attributes ea
JOIN entities e ON ea.entity_id = e.id
WHERE ea.description IS NULL 
    OR LENGTH(ea.description) < 10
    OR (ea.is_pii IS NULL AND ea.data_type IN ('string', 'varchar'))
ORDER BY e.name, ea.name;
```

#### **API Endpoints**
```bash
# Buscar entidades
GET /api/v1/entities/search?q=customer&domain=sales&classification=confidential

# Entidade específica com atributos
GET /api/v1/entities/{entity_id}?include_attributes=true

# Atributos PII
GET /api/v1/entities/attributes?pii=true&limit=100

# Sincronizar com Unity Catalog
POST /api/v1/entities/{entity_id}/sync
```

---


### 7. 📜 Domínio: Contratos de Dados

#### **Gestão de Contratos**
```sql
-- Contratos ativos por domínio
SELECT 
    d.name as domain_name,
    COUNT(dc.id) as active_contracts,
    COUNT(CASE WHEN dc.created_at > NOW() - INTERVAL '30 days' THEN 1 END) as new_contracts,
    STRING_AGG(DISTINCT dc.contract_type, ', ') as contract_types
FROM data_contracts dc
JOIN domains d ON dc.domain_id = d.id
WHERE dc.status = 'active'
GROUP BY d.name
ORDER BY active_contracts DESC;

-- Contratos por versão
SELECT 
    dc.name as contract_name,
    dc.version as current_version,
    COUNT(cv.id) as total_versions,
    MAX(cv.created_at) as last_version_date,
    CASE 
        WHEN COUNT(cv.id) = 1 THEN 'New Contract'
        WHEN MAX(cv.created_at) > NOW() - INTERVAL '30 days' THEN 'Recently Updated'
        ELSE 'Stable'
    END as version_status
FROM data_contracts dc
LEFT JOIN contract_versions cv ON dc.id = cv.contract_id
WHERE dc.status = 'active'
GROUP BY dc.id, dc.name, dc.version
ORDER BY total_versions DESC;

-- Contratos próximos ao vencimento
SELECT 
    dc.name,
    dc.version,
    cv.retirement_date,
    EXTRACT(DAYS FROM cv.retirement_date - NOW()) as days_until_retirement,
    u.username as owner
FROM data_contracts dc
JOIN contract_versions cv ON dc.id = cv.contract_id AND cv.is_active = true
LEFT JOIN users u ON dc.owner_id = u.id
WHERE cv.retirement_date IS NOT NULL
    AND cv.retirement_date <= NOW() + INTERVAL '90 days'
ORDER BY cv.retirement_date ASC;
```

#### **Análise de Versionamento**
```sql
-- Contratos com breaking changes
SELECT 
    dc.name as contract_name,
    cv.version,
    cv.description as change_description,
    cv.breaking_changes,
    cv.migration_notes,
    cv.created_at
FROM data_contracts dc
JOIN contract_versions cv ON dc.id = cv.contract_id
WHERE cv.breaking_changes = true
    AND cv.created_at >= NOW() - INTERVAL '6 months'
ORDER BY cv.created_at DESC;

-- Evolução de contratos ao longo do tempo
SELECT 
    DATE_TRUNC('month', cv.created_at) as month,
    COUNT(*) as new_versions,
    COUNT(CASE WHEN cv.breaking_changes = true THEN 1 END) as breaking_changes,
    COUNT(DISTINCT cv.contract_id) as contracts_updated
FROM contract_versions cv
WHERE cv.created_at >= NOW() - INTERVAL '12 months'
GROUP BY DATE_TRUNC('month', cv.created_at)
ORDER BY month;
```

#### **API Endpoints**
```bash
# Listar contratos
GET /api/v1/contracts?domain={domain_id}&status=active

# Contrato específico com versões
GET /api/v1/contracts/{contract_id}?include_versions=true

# Validar schema de contrato
POST /api/v1/contracts/{contract_id}/validate

# Criar nova versão
POST /api/v1/contracts/{contract_id}/versions
```

### 8. 🎯 Domínio: Qualidade de Dados

#### **Métricas de Qualidade**
```sql
-- Score de qualidade por entidade
SELECT 
    e.name as entity_name,
    COUNT(qr.id) as total_rules,
    COUNT(CASE WHEN qm.status = 'passed' THEN 1 END) as passed_rules,
    ROUND(
        COUNT(CASE WHEN qm.status = 'passed' THEN 1 END) * 100.0 / 
        NULLIF(COUNT(qr.id), 0), 2
    ) as quality_score_percent,
    MAX(qm.measured_at) as last_measurement
FROM entities e
LEFT JOIN quality_rules qr ON e.id = qr.entity_id AND qr.is_active = true
LEFT JOIN quality_metrics qm ON qr.id = qm.rule_id 
    AND qm.measured_at >= NOW() - INTERVAL '24 hours'
WHERE e.status = 'active'
GROUP BY e.id, e.name
HAVING COUNT(qr.id) > 0
ORDER BY quality_score_percent DESC;

-- Regras de qualidade mais violadas
SELECT 
    qr.name as rule_name,
    qr.rule_type,
    e.name as entity_name,
    COUNT(qm.id) as total_executions,
    COUNT(CASE WHEN qm.status IN ('warning', 'critical', 'failed') THEN 1 END) as violations,
    ROUND(
        COUNT(CASE WHEN qm.status IN ('warning', 'critical', 'failed') THEN 1 END) * 100.0 / 
        NULLIF(COUNT(qm.id), 0), 2
    ) as violation_rate_percent
FROM quality_rules qr
JOIN entities e ON qr.entity_id = e.id
LEFT JOIN quality_metrics qm ON qr.id = qm.rule_id
    AND qm.measured_at >= NOW() - INTERVAL '7 days'
WHERE qr.is_active = true
GROUP BY qr.id, qr.name, qr.rule_type, e.name
HAVING COUNT(qm.id) > 0
ORDER BY violation_rate_percent DESC
LIMIT 20;

-- Tendência de qualidade ao longo do tempo
SELECT 
    DATE_TRUNC('day', qm.measured_at) as measurement_date,
    qr.rule_type,
    AVG(qm.metric_value) as avg_quality_score,
    COUNT(*) as measurements
FROM quality_metrics qm
JOIN quality_rules qr ON qm.rule_id = qr.id
WHERE qm.measured_at >= NOW() - INTERVAL '30 days'
GROUP BY DATE_TRUNC('day', qm.measured_at), qr.rule_type
ORDER BY measurement_date DESC, qr.rule_type;
```

#### **Gestão de Incidentes**
```sql
-- Incidentes abertos por severidade
SELECT 
    severity,
    COUNT(*) as incident_count,
    AVG(EXTRACT(HOURS FROM NOW() - detected_at)) as avg_age_hours,
    COUNT(CASE WHEN assigned_to IS NOT NULL THEN 1 END) as assigned_count
FROM quality_incidents 
WHERE status IN ('open', 'investigating')
GROUP BY severity
ORDER BY 
    CASE severity 
        WHEN 'critical' THEN 1 
        WHEN 'high' THEN 2 
        WHEN 'medium' THEN 3 
        ELSE 4 
    END;

-- Incidentes por entidade
SELECT 
    e.name as entity_name,
    COUNT(qi.id) as total_incidents,
    COUNT(CASE WHEN qi.status IN ('open', 'investigating') THEN 1 END) as open_incidents,
    MAX(qi.detected_at) as last_incident,
    STRING_AGG(DISTINCT qi.severity, ', ') as severities
FROM quality_incidents qi
JOIN entities e ON qi.entity_id = e.id
WHERE qi.detected_at >= NOW() - INTERVAL '30 days'
GROUP BY e.id, e.name
ORDER BY total_incidents DESC;

-- Tempo médio de resolução por tipo
SELECT 
    incident_type,
    severity,
    COUNT(*) as resolved_incidents,
    AVG(EXTRACT(HOURS FROM resolved_at - detected_at)) as avg_resolution_hours,
    PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY EXTRACT(HOURS FROM resolved_at - detected_at)) as median_resolution_hours
FROM quality_incidents 
WHERE status = 'resolved'
    AND resolved_at >= NOW() - INTERVAL '90 days'
GROUP BY incident_type, severity
ORDER BY incident_type, 
    CASE severity 
        WHEN 'critical' THEN 1 
        WHEN 'high' THEN 2 
        WHEN 'medium' THEN 3 
        ELSE 4 
    END;
```

#### **API Endpoints**
```bash
# Métricas de qualidade
GET /api/v1/quality/metrics?entity_id={id}&period=7d

# Regras de qualidade
GET /api/v1/quality/rules?entity_id={id}&active=true

# Incidentes de qualidade
GET /api/v1/quality/incidents?status=open&severity=critical

# Executar regra de qualidade
POST /api/v1/quality/rules/{rule_id}/execute

# Dashboard de qualidade
GET /api/v1/quality/dashboard?domain={domain_id}
```

### 9. 🔗 Domínio: Lineage e Relacionamentos

#### **Análise de Lineage**
```sql
-- Lineage upstream (de onde vêm os dados)
WITH RECURSIVE upstream_lineage AS (
    -- Ponto de partida
    SELECT 
        lr.source_entity_id,
        lr.target_entity_id,
        e_source.name as source_name,
        e_target.name as target_name,
        lr.relationship_type,
        1 as level
    FROM lineage_relationships lr
    JOIN entities e_source ON lr.source_entity_id = e_source.id
    JOIN entities e_target ON lr.target_entity_id = e_target.id
    WHERE lr.target_entity_id = 'target_entity_uuid_here'
        AND lr.is_active = true
    
    UNION ALL
    
    -- Recursão upstream
    SELECT 
        lr.source_entity_id,
        lr.target_entity_id,
        e_source.name,
        e_target.name,
        lr.relationship_type,
        ul.level + 1
    FROM lineage_relationships lr
    JOIN entities e_source ON lr.source_entity_id = e_source.id
    JOIN entities e_target ON lr.target_entity_id = e_target.id
    JOIN upstream_lineage ul ON lr.target_entity_id = ul.source_entity_id
    WHERE lr.is_active = true AND ul.level < 10  -- Evitar loops infinitos
)
SELECT 
    REPEAT('  ', level - 1) || source_name as indented_source,
    target_name,
    relationship_type,
    level
FROM upstream_lineage
ORDER BY level, source_name;

-- Lineage downstream (para onde vão os dados)
WITH RECURSIVE downstream_lineage AS (
    -- Ponto de partida
    SELECT 
        lr.source_entity_id,
        lr.target_entity_id,
        e_source.name as source_name,
        e_target.name as target_name,
        lr.relationship_type,
        1 as level
    FROM lineage_relationships lr
    JOIN entities e_source ON lr.source_entity_id = e_source.id
    JOIN entities e_target ON lr.target_entity_id = e_target.id
    WHERE lr.source_entity_id = 'source_entity_uuid_here'
        AND lr.is_active = true
    
    UNION ALL
    
    -- Recursão downstream
    SELECT 
        lr.source_entity_id,
        lr.target_entity_id,
        e_source.name,
        e_target.name,
        lr.relationship_type,
        dl.level + 1
    FROM lineage_relationships lr
    JOIN entities e_source ON lr.source_entity_id = e_source.id
    JOIN entities e_target ON lr.target_entity_id = e_target.id
    JOIN downstream_lineage dl ON lr.source_entity_id = dl.target_entity_id
    WHERE lr.is_active = true AND dl.level < 10
)
SELECT 
    source_name,
    REPEAT('  ', level - 1) || target_name as indented_target,
    relationship_type,
    level
FROM downstream_lineage
ORDER BY level, target_name;

-- Análise de impacto (entidades mais conectadas)
SELECT 
    e.name as entity_name,
    COUNT(DISTINCT lr_in.source_entity_id) as upstream_count,
    COUNT(DISTINCT lr_out.target_entity_id) as downstream_count,
    COUNT(DISTINCT lr_in.source_entity_id) + COUNT(DISTINCT lr_out.target_entity_id) as total_connections,
    CASE 
        WHEN COUNT(DISTINCT lr_out.target_entity_id) > 10 THEN 'High Impact Source'
        WHEN COUNT(DISTINCT lr_in.source_entity_id) > 10 THEN 'Complex Derived'
        WHEN COUNT(DISTINCT lr_in.source_entity_id) + COUNT(DISTINCT lr_out.target_entity_id) > 15 THEN 'Hub Entity'
        ELSE 'Standard'
    END as impact_category
FROM entities e
LEFT JOIN lineage_relationships lr_in ON e.id = lr_in.target_entity_id AND lr_in.is_active = true
LEFT JOIN lineage_relationships lr_out ON e.id = lr_out.source_entity_id AND lr_out.is_active = true
WHERE e.status = 'active'
GROUP BY e.id, e.name
ORDER BY total_connections DESC;
```

#### **Lineage de Atributos**
```sql
-- Rastreamento granular de campos
SELECT 
    e_source.name as source_entity,
    ea_source.name as source_attribute,
    e_target.name as target_entity,
    ea_target.name as target_attribute,
    al.transformation_type,
    al.transformation_logic,
    lr.pipeline_name
FROM attribute_lineage al
JOIN entity_attributes ea_source ON al.source_attribute_id = ea_source.id
JOIN entity_attributes ea_target ON al.target_attribute_id = ea_target.id
JOIN entities e_source ON ea_source.entity_id = e_source.id
JOIN entities e_target ON ea_target.entity_id = e_target.id
LEFT JOIN lineage_relationships lr ON al.lineage_relationship_id = lr.id
WHERE al.is_active = true
    AND (e_source.name ILIKE '%customer%' OR e_target.name ILIKE '%customer%')
ORDER BY e_source.name, ea_source.name;
```

#### **API Endpoints**
```bash
# Lineage upstream
GET /api/v1/entities/{entity_id}/lineage/upstream?levels=5

# Lineage downstream  
GET /api/v1/entities/{entity_id}/lineage/downstream?levels=5

# Análise de impacto
GET /api/v1/entities/{entity_id}/impact-analysis

# Lineage de atributos
GET /api/v1/entities/{entity_id}/attributes/{attr_id}/lineage

# Visualização de lineage
GET /api/v1/lineage/graph?entity_id={id}&format=json
```

### 10. 📚 Domínio: Referências Externas

#### **Gestão de Integrações**
```sql
-- Status das integrações externas
SELECT 
    name,
    reference_type,
    status,
    last_tested_at,
    EXTRACT(HOURS FROM NOW() - last_tested_at) as hours_since_test,
    CASE 
        WHEN last_tested_at IS NULL THEN 'Never Tested'
        WHEN last_tested_at < NOW() - INTERVAL '24 hours' THEN 'Needs Testing'
        WHEN status = 'active' THEN 'Healthy'
        ELSE 'Attention Required'
    END as health_status
FROM external_references
ORDER BY 
    CASE status WHEN 'active' THEN 1 ELSE 2 END,
    last_tested_at DESC NULLS LAST;

-- Integrações por tipo
SELECT 
    reference_type,
    COUNT(*) as total_integrations,
    COUNT(CASE WHEN status = 'active' THEN 1 END) as active_integrations,
    AVG(EXTRACT(HOURS FROM NOW() - last_tested_at)) as avg_hours_since_test
FROM external_references
GROUP BY reference_type
ORDER BY total_integrations DESC;
```

#### **Configurações de Integração**
```sql
-- Status de sincronização
SELECT 
    ic.integration_name,
    ic.integration_type,
    ic.sync_frequency,
    ic.last_sync_at,
    ic.last_sync_status,
    EXTRACT(HOURS FROM NOW() - ic.last_sync_at) as hours_since_sync,
    CASE 
        WHEN ic.last_sync_status = 'success' AND ic.last_sync_at > NOW() - INTERVAL '24 hours' THEN 'Healthy'
        WHEN ic.last_sync_status = 'failed' THEN 'Failed'
        WHEN ic.last_sync_at < NOW() - INTERVAL '48 hours' THEN 'Stale'
        ELSE 'Warning'
    END as sync_health
FROM integration_configs ic
WHERE ic.is_active = true
ORDER BY 
    CASE ic.last_sync_status WHEN 'success' THEN 1 ELSE 2 END,
    ic.last_sync_at DESC;
```

#### **API Endpoints**
```bash
# Listar referências externas
GET /api/v1/external-references?type=unity_catalog&status=active

# Testar conectividade
POST /api/v1/external-references/{ref_id}/test

# Configurações de integração
GET /api/v1/integrations/configs?active=true

# Sincronizar integração
POST /api/v1/integrations/{integration_id}/sync
```

---


## 📈 Consultas Analíticas Avançadas

### 1. 🎯 ROI e Valor da Governança

#### **Métricas de Adoção**
```sql
-- Adoção da governança ao longo do tempo
SELECT 
    DATE_TRUNC('month', created_at) as month,
    'Entities' as metric_type,
    COUNT(*) as monthly_count,
    SUM(COUNT(*)) OVER (ORDER BY DATE_TRUNC('month', created_at)) as cumulative_count
FROM entities
WHERE created_at >= NOW() - INTERVAL '12 months'
GROUP BY DATE_TRUNC('month', created_at)

UNION ALL

SELECT 
    DATE_TRUNC('month', created_at) as month,
    'Contracts' as metric_type,
    COUNT(*) as monthly_count,
    SUM(COUNT(*)) OVER (ORDER BY DATE_TRUNC('month', created_at)) as cumulative_count
FROM data_contracts
WHERE created_at >= NOW() - INTERVAL '12 months'
GROUP BY DATE_TRUNC('month', created_at)

UNION ALL

SELECT 
    DATE_TRUNC('month', created_at) as month,
    'Quality Rules' as metric_type,
    COUNT(*) as monthly_count,
    SUM(COUNT(*)) OVER (ORDER BY DATE_TRUNC('month', created_at)) as cumulative_count
FROM quality_rules
WHERE created_at >= NOW() - INTERVAL '12 months'
GROUP BY DATE_TRUNC('month', created_at)

ORDER BY month, metric_type;

-- Tempo médio para onboarding de dados
SELECT 
    d.name as domain_name,
    COUNT(e.id) as entities_onboarded,
    AVG(EXTRACT(DAYS FROM e.updated_at - e.created_at)) as avg_days_to_document,
    AVG(EXTRACT(DAYS FROM dc.created_at - e.created_at)) as avg_days_to_contract
FROM entities e
JOIN domains d ON e.domain_id = d.id
LEFT JOIN data_contracts dc ON e.id = dc.entity_id
WHERE e.created_at >= NOW() - INTERVAL '6 months'
GROUP BY d.id, d.name
HAVING COUNT(e.id) > 5
ORDER BY avg_days_to_document;
```

#### **Impacto na Qualidade**
```sql
-- Melhoria de qualidade após implementação de regras
WITH quality_before_after AS (
    SELECT 
        qr.entity_id,
        qr.id as rule_id,
        qr.created_at as rule_created,
        AVG(CASE WHEN qm.measured_at < qr.created_at + INTERVAL '7 days' 
                 THEN qm.metric_value END) as quality_before,
        AVG(CASE WHEN qm.measured_at > qr.created_at + INTERVAL '30 days' 
                 THEN qm.metric_value END) as quality_after
    FROM quality_rules qr
    LEFT JOIN quality_metrics qm ON qr.id = qm.rule_id
    WHERE qr.created_at >= NOW() - INTERVAL '6 months'
    GROUP BY qr.entity_id, qr.id, qr.created_at
    HAVING AVG(CASE WHEN qm.measured_at < qr.created_at + INTERVAL '7 days' 
                    THEN qm.metric_value END) IS NOT NULL
       AND AVG(CASE WHEN qm.measured_at > qr.created_at + INTERVAL '30 days' 
                    THEN qm.metric_value END) IS NOT NULL
)
SELECT 
    e.name as entity_name,
    COUNT(qba.rule_id) as rules_implemented,
    AVG(qba.quality_before) as avg_quality_before,
    AVG(qba.quality_after) as avg_quality_after,
    AVG(qba.quality_after - qba.quality_before) as avg_improvement,
    CASE 
        WHEN AVG(qba.quality_after - qba.quality_before) > 10 THEN 'Significant Improvement'
        WHEN AVG(qba.quality_after - qba.quality_before) > 5 THEN 'Moderate Improvement'
        WHEN AVG(qba.quality_after - qba.quality_before) > 0 THEN 'Slight Improvement'
        ELSE 'No Improvement'
    END as improvement_category
FROM quality_before_after qba
JOIN entities e ON qba.entity_id = e.id
GROUP BY e.id, e.name
ORDER BY avg_improvement DESC;
```

### 2. 🔍 Análise de Uso e Comportamento

#### **Padrões de Acesso**
```sql
-- Entidades mais acessadas por período
SELECT 
    e.name as entity_name,
    d.name as domain_name,
    COUNT(um.id) as total_accesses,
    COUNT(DISTINCT um.user_id) as unique_users,
    COUNT(DISTINCT DATE_TRUNC('day', um.accessed_at)) as active_days,
    AVG(um.execution_time_ms) as avg_execution_time,
    SUM(um.bytes_transferred) as total_bytes_transferred
FROM usage_metrics um
JOIN entities e ON um.entity_id = e.id
JOIN domains d ON e.domain_id = d.id
WHERE um.accessed_at >= NOW() - INTERVAL '30 days'
    AND um.success = true
GROUP BY e.id, e.name, d.name
ORDER BY total_accesses DESC
LIMIT 20;

-- Análise de sazonalidade de uso
SELECT 
    EXTRACT(HOUR FROM accessed_at) as hour_of_day,
    EXTRACT(DOW FROM accessed_at) as day_of_week,
    COUNT(*) as access_count,
    AVG(execution_time_ms) as avg_response_time
FROM usage_metrics
WHERE accessed_at >= NOW() - INTERVAL '30 days'
    AND success = true
GROUP BY EXTRACT(HOUR FROM accessed_at), EXTRACT(DOW FROM accessed_at)
ORDER BY day_of_week, hour_of_day;

-- Usuários mais ativos
SELECT 
    u.username,
    u.email,
    COUNT(um.id) as total_accesses,
    COUNT(DISTINCT um.entity_id) as unique_entities_accessed,
    COUNT(DISTINCT DATE_TRUNC('day', um.accessed_at)) as active_days,
    MAX(um.accessed_at) as last_access,
    STRING_AGG(DISTINCT um.access_type, ', ') as access_types
FROM usage_metrics um
JOIN users u ON um.user_id = u.id
WHERE um.accessed_at >= NOW() - INTERVAL '30 days'
GROUP BY u.id, u.username, u.email
ORDER BY total_accesses DESC
LIMIT 15;
```

#### **Análise de Performance**
```sql
-- Queries mais executadas e sua performance
SELECT 
    um.query_hash,
    COUNT(*) as execution_count,
    AVG(um.execution_time_ms) as avg_execution_time,
    PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY um.execution_time_ms) as p95_execution_time,
    COUNT(DISTINCT um.user_id) as unique_users,
    COUNT(DISTINCT um.entity_id) as unique_entities,
    MAX(um.accessed_at) as last_execution
FROM usage_metrics um
WHERE um.accessed_at >= NOW() - INTERVAL '7 days'
    AND um.query_hash IS NOT NULL
    AND um.success = true
GROUP BY um.query_hash
HAVING COUNT(*) > 10
ORDER BY execution_count DESC
LIMIT 20;

-- Entidades com problemas de performance
SELECT 
    e.name as entity_name,
    COUNT(um.id) as total_accesses,
    AVG(um.execution_time_ms) as avg_execution_time,
    PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY um.execution_time_ms) as p95_execution_time,
    COUNT(CASE WHEN um.execution_time_ms > 5000 THEN 1 END) as slow_queries,
    ROUND(
        COUNT(CASE WHEN um.execution_time_ms > 5000 THEN 1 END) * 100.0 / 
        NULLIF(COUNT(um.id), 0), 2
    ) as slow_query_percentage
FROM usage_metrics um
JOIN entities e ON um.entity_id = e.id
WHERE um.accessed_at >= NOW() - INTERVAL '7 days'
    AND um.success = true
GROUP BY e.id, e.name
HAVING COUNT(um.id) > 50
ORDER BY slow_query_percentage DESC, avg_execution_time DESC;
```

### 3. 🏷️ Análise de Tags e Classificação

#### **Efetividade do Sistema de Tags**
```sql
-- Tags mais utilizadas
SELECT 
    t.name as tag_name,
    t.tag_type,
    t.category,
    COUNT(et.entity_id) as entities_tagged,
    t.usage_count,
    ROUND(
        COUNT(CASE WHEN et.is_auto_generated = true THEN 1 END) * 100.0 / 
        NULLIF(COUNT(et.entity_id), 0), 2
    ) as auto_generated_percentage
FROM tags t
LEFT JOIN entity_tags et ON t.id = et.tag_id
GROUP BY t.id, t.name, t.tag_type, t.category, t.usage_count
ORDER BY entities_tagged DESC;

-- Entidades sem tags adequadas
SELECT 
    e.name as entity_name,
    d.name as domain_name,
    e.data_classification,
    COUNT(et.tag_id) as tag_count,
    CASE 
        WHEN COUNT(et.tag_id) = 0 THEN 'No Tags'
        WHEN COUNT(et.tag_id) < 3 THEN 'Under Tagged'
        WHEN COUNT(et.tag_id) > 10 THEN 'Over Tagged'
        ELSE 'Well Tagged'
    END as tagging_status
FROM entities e
JOIN domains d ON e.domain_id = d.id
LEFT JOIN entity_tags et ON e.id = et.entity_id
WHERE e.status = 'active'
GROUP BY e.id, e.name, d.name, e.data_classification
ORDER BY tag_count ASC, e.name;

-- Análise de classificação de dados
SELECT 
    data_classification,
    COUNT(*) as entity_count,
    COUNT(CASE WHEN last_accessed_at > NOW() - INTERVAL '30 days' THEN 1 END) as recently_accessed,
    AVG(
        (SELECT COUNT(*) FROM entity_tags et WHERE et.entity_id = entities.id)
    ) as avg_tags_per_entity,
    COUNT(
        CASE WHEN (SELECT COUNT(*) FROM quality_rules qr WHERE qr.entity_id = entities.id AND qr.is_active = true) > 0 
             THEN 1 END
    ) as entities_with_quality_rules
FROM entities
WHERE status = 'active'
GROUP BY data_classification
ORDER BY 
    CASE data_classification 
        WHEN 'restricted' THEN 1 
        WHEN 'confidential' THEN 2 
        WHEN 'internal' THEN 3 
        WHEN 'public' THEN 4 
        ELSE 5 
    END;
```

### 4. 📋 Análise do Glossário de Negócio

#### **Cobertura e Uso do Glossário**
```sql
-- Termos mais referenciados
SELECT 
    bg.term,
    bg.category,
    bg.status,
    LENGTH(bg.definition) as definition_length,
    ARRAY_LENGTH(bg.synonyms, 1) as synonym_count,
    ARRAY_LENGTH(bg.related_terms, 1) as related_terms_count,
    u.username as owner
FROM business_glossary bg
LEFT JOIN users u ON bg.owner_id = u.id
WHERE bg.status = 'active'
ORDER BY related_terms_count DESC NULLS LAST, synonym_count DESC NULLS LAST;

-- Cobertura do glossário por domínio
SELECT 
    d.name as domain_name,
    COUNT(bg.id) as glossary_terms,
    COUNT(e.id) as total_entities,
    ROUND(COUNT(bg.id) * 1.0 / NULLIF(COUNT(e.id), 0), 2) as terms_per_entity_ratio
FROM domains d
LEFT JOIN business_glossary bg ON d.id = bg.domain_id
LEFT JOIN entities e ON d.id = e.domain_id
GROUP BY d.id, d.name
ORDER BY terms_per_entity_ratio DESC;
```

### 5. 🔄 Análise de Workflows

#### **Eficiência dos Workflows**
```sql
-- Performance dos workflows de aprovação
SELECT 
    w.name as workflow_name,
    w.workflow_type,
    COUNT(wi.id) as total_instances,
    COUNT(CASE WHEN wi.status = 'approved' THEN 1 END) as approved_count,
    COUNT(CASE WHEN wi.status = 'rejected' THEN 1 END) as rejected_count,
    AVG(EXTRACT(HOURS FROM wi.completed_at - wi.started_at)) as avg_completion_hours,
    PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY EXTRACT(HOURS FROM wi.completed_at - wi.started_at)) as median_completion_hours
FROM workflows w
LEFT JOIN workflow_instances wi ON w.id = wi.workflow_id
WHERE wi.started_at >= NOW() - INTERVAL '90 days'
    AND wi.completed_at IS NOT NULL
GROUP BY w.id, w.name, w.workflow_type
ORDER BY total_instances DESC;

-- Gargalos nos workflows
SELECT 
    wi.current_approver,
    u.username as approver_name,
    COUNT(*) as pending_approvals,
    AVG(EXTRACT(HOURS FROM NOW() - wi.started_at)) as avg_pending_hours,
    MAX(EXTRACT(HOURS FROM NOW() - wi.started_at)) as max_pending_hours
FROM workflow_instances wi
LEFT JOIN users u ON wi.current_approver = u.id
WHERE wi.status IN ('pending', 'in_progress')
GROUP BY wi.current_approver, u.username
ORDER BY pending_approvals DESC;
```

## 🎯 Casos de Uso Práticos

### 1. 🔍 Descoberta de Dados para Analistas

**Cenário:** Um analista de negócios precisa encontrar dados sobre comportamento de clientes para um projeto de segmentação.

```sql
-- Busca inicial por entidades relacionadas a clientes
SELECT 
    e.name,
    e.display_name,
    e.description,
    d.name as domain_name,
    e.unity_catalog_path,
    u.username as owner,
    STRING_AGG(t.name, ', ') as tags
FROM entities e
JOIN domains d ON e.domain_id = d.id
LEFT JOIN users u ON e.owner_id = u.id
LEFT JOIN entity_tags et ON e.id = et.entity_id
LEFT JOIN tags t ON et.tag_id = t.id
WHERE (
    e.name ILIKE '%customer%' 
    OR e.name ILIKE '%behavior%'
    OR e.description ILIKE '%customer%'
    OR e.description ILIKE '%behavior%'
    OR t.name IN ('customer-facing', 'behavioral-data', 'analytics')
)
AND e.status = 'active'
AND e.data_classification IN ('public', 'internal')
GROUP BY e.id, e.name, e.display_name, e.description, d.name, e.unity_catalog_path, u.username
ORDER BY e.name;
```

**API Equivalente:**
```bash
GET /api/v1/entities/search?q=customer+behavior&classification=public,internal&include_tags=true
```

### 2. 🎯 Análise de Impacto para Mudanças

**Cenário:** Uma equipe técnica precisa entender o impacto de modificar a estrutura da tabela `customer_profile`.

```sql
-- Análise completa de impacto downstream
WITH RECURSIVE impact_analysis AS (
    -- Entidade inicial
    SELECT 
        e.id as entity_id,
        e.name as entity_name,
        0 as level,
        'source' as impact_type
    FROM entities e 
    WHERE e.name = 'customer_profile'
    
    UNION ALL
    
    -- Entidades impactadas (downstream)
    SELECT 
        e.id,
        e.name,
        ia.level + 1,
        'downstream'
    FROM lineage_relationships lr
    JOIN entities e ON lr.target_entity_id = e.id
    JOIN impact_analysis ia ON lr.source_entity_id = ia.entity_id
    WHERE lr.is_active = true AND ia.level < 5
)
SELECT 
    ia.entity_name,
    ia.level,
    ia.impact_type,
    d.name as domain_name,
    e.entity_type,
    u.username as owner,
    COUNT(DISTINCT dc.id) as active_contracts,
    COUNT(DISTINCT qr.id) as quality_rules,
    COUNT(DISTINCT um.user_id) as active_users_last_30d
FROM impact_analysis ia
JOIN entities e ON ia.entity_id = e.id
JOIN domains d ON e.domain_id = d.id
LEFT JOIN users u ON e.owner_id = u.id
LEFT JOIN data_contracts dc ON e.id = dc.entity_id AND dc.status = 'active'
LEFT JOIN quality_rules qr ON e.id = qr.entity_id AND qr.is_active = true
LEFT JOIN usage_metrics um ON e.id = um.entity_id 
    AND um.accessed_at >= NOW() - INTERVAL '30 days'
GROUP BY ia.entity_name, ia.level, ia.impact_type, d.name, e.entity_type, u.username
ORDER BY ia.level, ia.entity_name;
```

**API Equivalente:**
```bash
GET /api/v1/entities/customer_profile/impact-analysis?include_usage=true&include_contracts=true
```

### 3. 📊 Relatório de Qualidade para Data Stewards

**Cenário:** Um Data Steward precisa de um relatório completo sobre a qualidade dos dados em seu domínio.

```sql
-- Relatório completo de qualidade por domínio
SELECT 
    d.name as domain_name,
    e.name as entity_name,
    COUNT(qr.id) as total_quality_rules,
    COUNT(CASE WHEN qr.is_active = true THEN 1 END) as active_rules,
    ROUND(
        AVG(CASE WHEN qm.measured_at >= NOW() - INTERVAL '24 hours' 
                 THEN qm.metric_value END), 2
    ) as avg_quality_score_24h,
    COUNT(CASE WHEN qi.status IN ('open', 'investigating') THEN 1 END) as open_incidents,
    MAX(qm.measured_at) as last_quality_check,
    STRING_AGG(
        CASE WHEN qm.status IN ('warning', 'critical', 'failed') 
             THEN qr.name END, ', '
    ) as failing_rules
FROM domains d
JOIN entities e ON d.id = e.domain_id
LEFT JOIN quality_rules qr ON e.id = qr.entity_id
LEFT JOIN quality_metrics qm ON qr.id = qm.rule_id
LEFT JOIN quality_incidents qi ON e.id = qi.entity_id
WHERE d.steward_id = 'steward_user_id_here'
    AND e.status = 'active'
GROUP BY d.id, d.name, e.id, e.name
ORDER BY avg_quality_score_24h ASC NULLS LAST, open_incidents DESC;
```

**API Equivalente:**
```bash
GET /api/v1/quality/dashboard?steward_id={user_id}&include_incidents=true&period=24h
```

### 4. 🔒 Auditoria de Compliance

**Cenário:** Equipe de compliance precisa verificar acesso a dados sensíveis nos últimos 30 dias.

```sql
-- Auditoria de acesso a dados sensíveis
SELECT 
    e.name as entity_name,
    e.data_classification,
    u.username,
    u.email,
    COUNT(um.id) as access_count,
    MIN(um.accessed_at) as first_access,
    MAX(um.accessed_at) as last_access,
    STRING_AGG(DISTINCT um.access_type, ', ') as access_types,
    STRING_AGG(DISTINCT um.access_method, ', ') as access_methods,
    COUNT(CASE WHEN um.success = false THEN 1 END) as failed_attempts
FROM entities e
JOIN usage_metrics um ON e.id = um.entity_id
JOIN users u ON um.user_id = u.id
WHERE e.data_classification IN ('confidential', 'restricted')
    AND um.accessed_at >= NOW() - INTERVAL '30 days'
GROUP BY e.id, e.name, e.data_classification, u.id, u.username, u.email
ORDER BY e.data_classification, access_count DESC;
```

**API Equivalente:**
```bash
GET /api/v1/audit/sensitive-data-access?period=30d&classification=confidential,restricted
```

### 5. 📈 Análise de ROI da Governança

**Cenário:** Executivos querem entender o retorno do investimento em governança de dados.

```sql
-- Métricas de ROI da governança
WITH governance_metrics AS (
    SELECT 
        'Data Quality Improvement' as metric_name,
        ROUND(
            (SELECT AVG(metric_value) FROM quality_metrics 
             WHERE measured_at >= NOW() - INTERVAL '30 days') -
            (SELECT AVG(metric_value) FROM quality_metrics 
             WHERE measured_at BETWEEN NOW() - INTERVAL '12 months' AND NOW() - INTERVAL '11 months'),
            2
        ) as improvement_value,
        '%' as unit
    
    UNION ALL
    
    SELECT 
        'Incident Reduction',
        ROUND(
            (SELECT COUNT(*) FROM quality_incidents 
             WHERE detected_at BETWEEN NOW() - INTERVAL '12 months' AND NOW() - INTERVAL '11 months') -
            (SELECT COUNT(*) FROM quality_incidents 
             WHERE detected_at >= NOW() - INTERVAL '30 days') * 12.0,
            0
        ),
        'incidents/year'
    
    UNION ALL
    
    SELECT 
        'Data Discovery Efficiency',
        ROUND(
            (SELECT AVG(EXTRACT(MINUTES FROM response_time)) 
             FROM (SELECT MIN(accessed_at) - MIN(created_at) as response_time
                   FROM entities e 
                   JOIN usage_metrics um ON e.id = um.entity_id
                   WHERE e.created_at >= NOW() - INTERVAL '6 months'
                   GROUP BY e.id) discovery_times),
            1
        ),
        'minutes to first use'
    
    UNION ALL
    
    SELECT 
        'Compliance Readiness',
        ROUND(
            COUNT(CASE WHEN e.data_classification IS NOT NULL 
                       AND EXISTS(SELECT 1 FROM quality_rules qr WHERE qr.entity_id = e.id)
                       THEN 1 END) * 100.0 / COUNT(*),
            1
        ),
        '%'
    FROM entities e WHERE e.status = 'active'
)
SELECT * FROM governance_metrics;
```

**API Equivalente:**
```bash
GET /api/v1/analytics/roi-metrics?period=12m&include_trends=true
```

---

