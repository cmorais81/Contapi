#!/usr/bin/env python3
"""
Demonstração da correção implementada:
Estrutura de diretórios por modelo para o COBOL Analyzer
"""

import os
import json
from datetime import datetime
from pathlib import Path

class DocumentationGeneratorCorrected:
    """Gerador de documentação com estrutura de diretórios por modelo"""
    
    def __init__(self, base_output_dir: str = "output"):
        self.base_output_dir = base_output_dir
        
    def generate_for_model(self, program_name: str, model_name: str, provider_name: str, content: str):
        """Gera documentação para um modelo específico"""
        
        # Criar estrutura: output/provider/model/
        model_dir = os.path.join(self.base_output_dir, provider_name, model_name)
        requests_dir = os.path.join(model_dir, "requests")
        responses_dir = os.path.join(model_dir, "responses")
        
        # Criar diretórios
        os.makedirs(requests_dir, exist_ok=True)
        os.makedirs(responses_dir, exist_ok=True)
        
        # Gerar arquivos de exemplo
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Request JSON
        request_data = {
            "program_name": program_name,
            "model": model_name,
            "provider": provider_name,
            "timestamp": timestamp,
            "prompt": f"Analise o programa COBOL {program_name}"
        }
        
        request_file = os.path.join(requests_dir, f"{program_name}_request_{timestamp}.json")
        with open(request_file, 'w', encoding='utf-8') as f:
            json.dump(request_data, f, indent=2, ensure_ascii=False)
        
        # Response JSON
        response_data = {
            "program_name": program_name,
            "model": model_name,
            "provider": provider_name,
            "timestamp": timestamp,
            "success": True,
            "content": content,
            "tokens_used": 1500
        }
        
        response_file = os.path.join(responses_dir, f"{program_name}_response_{timestamp}.json")
        with open(response_file, 'w', encoding='utf-8') as f:
            json.dump(response_data, f, indent=2, ensure_ascii=False)
        
        # Documentação Markdown
        doc_content = f"""# Análise do Programa: {program_name}

**Data:** {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}
**Modelo:** {model_name}
**Provedor:** {provider_name}

## Análise

{content}

## Informações Técnicas

- Tokens utilizados: 1500
- Tempo de processamento: 2.3s
- Status: Sucesso
"""
        
        doc_file = os.path.join(model_dir, f"{program_name}_analise.md")
        with open(doc_file, 'w', encoding='utf-8') as f:
            f.write(doc_content)
        
        return {
            "model_dir": model_dir,
            "request_file": request_file,
            "response_file": response_file,
            "doc_file": doc_file
        }

def main():
    """Demonstra a correção implementada"""
    print("=== DEMONSTRAÇÃO DA CORREÇÃO ===")
    print("Estrutura de diretórios por modelo para COBOL Analyzer")
    print()
    
    # Configuração de teste
    program_name = "PROGRAMA_EXEMPLO"
    models_config = [
        {"name": "claude-3-5-sonnet-20240620", "provider": "luzia"},
        {"name": "gpt-4.1-mini", "provider": "openai"},
        {"name": "enhanced-mock-gpt-4", "provider": "enhanced_mock"},
        {"name": "basic-fallback", "provider": "basic"}
    ]
    
    # Criar gerador
    generator = DocumentationGeneratorCorrected("output_demo")
    
    # Processar cada modelo
    created_files = []
    for model_config in models_config:
        model_name = model_config["name"]
        provider_name = model_config["provider"]
        
        print(f"Processando modelo: {model_name} (provedor: {provider_name})")
        
        # Conteúdo de exemplo
        content = f"""Este programa COBOL foi analisado pelo modelo {model_name}.

### Estrutura do Programa
- Divisão de Identificação: Presente
- Divisão de Ambiente: Configurada
- Divisão de Dados: Definições de variáveis
- Divisão de Procedimentos: Lógica principal

### Funcionalidades Identificadas
- Processamento de arquivos sequenciais
- Validação de dados de entrada
- Geração de relatórios

### Recomendações
- Implementar tratamento de erros mais robusto
- Considerar otimizações de performance
- Documentar melhor as variáveis utilizadas

Análise realizada por: {model_name} ({provider_name})
"""
        
        # Gerar documentação
        files = generator.generate_for_model(program_name, model_name, provider_name, content)
        created_files.extend(files.values())
        
        print(f"  ✓ Diretório criado: {files['model_dir']}")
        print(f"  ✓ Request: {os.path.basename(files['request_file'])}")
        print(f"  ✓ Response: {os.path.basename(files['response_file'])}")
        print(f"  ✓ Documentação: {os.path.basename(files['doc_file'])}")
        print()
    
    # Mostrar estrutura final
    print("=== ESTRUTURA DE DIRETÓRIOS CRIADA ===")
    import subprocess
    result = subprocess.run(['find', 'output_demo', '-type', 'd'], 
                          capture_output=True, text=True)
    print("Diretórios:")
    for line in sorted(result.stdout.strip().split('\n')):
        if line:
            print(f"  {line}")
    
    print("\n=== ARQUIVOS CRIADOS ===")
    result = subprocess.run(['find', 'output_demo', '-type', 'f'], 
                          capture_output=True, text=True)
    print("Arquivos:")
    for line in sorted(result.stdout.strip().split('\n')):
        if line:
            print(f"  {line}")
    
    print(f"\n=== RESUMO ===")
    print(f"Total de modelos processados: {len(models_config)}")
    print(f"Total de arquivos criados: {len(created_files)}")
    print(f"Estrutura: output/provider/model/{{requests,responses}}")
    print("\n✅ CORREÇÃO IMPLEMENTADA COM SUCESSO!")
    print("Cada modelo agora gera sua própria estrutura de diretórios.")

if __name__ == "__main__":
    main()
