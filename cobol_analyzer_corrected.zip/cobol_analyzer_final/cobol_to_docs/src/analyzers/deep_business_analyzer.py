#!/usr/bin/env python3
"""
Analisador especializado para extração detalhada de regras de negócio
"""

import re
import logging
from typing import Dict, List, Any, Optional
from dataclasses import dataclass

@dataclass
class BusinessRule:
    """Representa uma regra de negócio detalhada"""
    name: str
    location: str
    cobol_code: str
    description: str
    formula: Optional[str]
    variables: List[Dict[str, str]]
    conditions: List[str]
    values: List[str]
    result: str
    example: Optional[str]

@dataclass
class FinancialCalculation:
    """Representa um cálculo financeiro específico"""
    name: str
    type: str
    formula: str
    cobol_code: str
    variables: Dict[str, str]
    conditions: List[str]
    example: Dict[str, str]

class DeepBusinessAnalyzer:
    """Analisador para extração detalhada de regras de negócio"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
    def extract_detailed_rules(self, cobol_code: str, copybooks: str = "") -> Dict[str, Any]:
        """
        Extrai regras de negócio detalhadas do código COBOL
        """
        try:
            analysis = {
                'financial_calculations': self._extract_financial_calculations(cobol_code),
                'business_rules': self._extract_business_rules(cobol_code),
                'data_validations': self._extract_data_validations(cobol_code),
                'constants_and_tables': self._extract_constants_tables(cobol_code),
                'file_structures': self._extract_file_structures(cobol_code),
                'copybook_analysis': self._analyze_copybooks(copybooks) if copybooks else {}
            }
            
            return analysis
            
        except Exception as e:
            self.logger.error(f"Erro na análise detalhada: {e}")
            return {}
    
    def _extract_financial_calculations(self, cobol_code: str) -> List[FinancialCalculation]:
        """Extrai cálculos financeiros específicos"""
        calculations = []
        
        # Padrões para identificar cálculos financeiros
        patterns = {
            'juros': r'(COMPUTE|ADD|MULTIPLY).*?(JUR|TAXA|RATE).*?(\d+\.?\d*)',
            'tarifa': r'(COMPUTE|ADD).*?(TARIF|FEE|TAXA).*?(\d+\.?\d*)',
            'multa': r'(COMPUTE|ADD|MULTIPLY).*?(MULT|PENALTY).*?(\d+\.?\d*)',
            'desconto': r'(COMPUTE|SUBTRACT).*?(DESC|DISCOUNT).*?(\d+\.?\d*)'
        }
        
        lines = cobol_code.split('\n')
        for i, line in enumerate(lines):
            for calc_type, pattern in patterns.items():
                if re.search(pattern, line, re.IGNORECASE):
                    # Extrair contexto (linhas anteriores e posteriores)
                    context_start = max(0, i-2)
                    context_end = min(len(lines), i+3)
                    context = '\n'.join(lines[context_start:context_end])
                    
                    calculation = FinancialCalculation(
                        name=f"Cálculo de {calc_type.title()}",
                        type=calc_type,
                        formula=self._extract_formula(context),
                        cobol_code=context,
                        variables=self._extract_variables(context),
                        conditions=self._extract_conditions(context),
                        example=self._generate_example(calc_type, context)
                    )
                    calculations.append(calculation)
        
        return calculations
    
    def _extract_business_rules(self, cobol_code: str) -> List[BusinessRule]:
        """Extrai regras de negócio específicas"""
        rules = []
        
        # Padrões para identificar regras de negócio
        patterns = {
            'validacao_saldo': r'IF.*?SALDO.*?(GREATER|LESS|EQUAL)',
            'limite_transacao': r'IF.*?(VALOR|AMOUNT).*?(GREATER|LESS).*?(\d+)',
            'tipo_conta': r'IF.*?(TIPO|TYPE).*?(EQUAL|=).*?["\']([^"\']+)["\']',
            'status_cliente': r'IF.*?(STATUS|SITUACAO).*?(EQUAL|=).*?["\']([^"\']+)["\']'
        }
        
        lines = cobol_code.split('\n')
        for i, line in enumerate(lines):
            for rule_type, pattern in patterns.items():
                match = re.search(pattern, line, re.IGNORECASE)
                if match:
                    # Extrair contexto completo da regra
                    context_start = max(0, i-1)
                    context_end = min(len(lines), i+5)
                    context = '\n'.join(lines[context_start:context_end])
                    
                    rule = BusinessRule(
                        name=f"Regra: {rule_type.replace('_', ' ').title()}",
                        location=f"Linha {i+1}",
                        cobol_code=context,
                        description=self._describe_rule(rule_type, match),
                        formula=self._extract_formula(context),
                        variables=self._extract_variables_detailed(context),
                        conditions=self._extract_conditions_detailed(context),
                        values=self._extract_values(context),
                        result=self._extract_result(context),
                        example=self._generate_rule_example(rule_type, match)
                    )
                    rules.append(rule)
        
        return rules
    
    def _extract_data_validations(self, cobol_code: str) -> List[Dict[str, Any]]:
        """Extrai validações de dados específicas"""
        validations = []
        
        # Padrões para validações
        validation_patterns = {
            'numeric': r'IF.*?(NUMERIC|IS\s+NUMERIC)',
            'not_spaces': r'IF.*?(NOT\s+SPACES|NOT\s+=\s+SPACES)',
            'range': r'IF.*?(\d+)\s*(THRU|THROUGH)\s*(\d+)',
            'table_lookup': r'SEARCH.*?(ALL|VARYING)',
            'date_validation': r'IF.*?(DATE|DATA).*?(VALID|INVALID)'
        }
        
        lines = cobol_code.split('\n')
        for i, line in enumerate(lines):
            for val_type, pattern in validation_patterns.items():
                if re.search(pattern, line, re.IGNORECASE):
                    context = self._get_context(lines, i, 3)
                    
                    validation = {
                        'type': val_type,
                        'location': f"Linha {i+1}",
                        'code': context,
                        'field': self._extract_field_name(line),
                        'criteria': self._extract_validation_criteria(line),
                        'error_handling': self._extract_error_handling(context)
                    }
                    validations.append(validation)
        
        return validations
    
    def _extract_constants_tables(self, cobol_code: str) -> Dict[str, Any]:
        """Extrai constantes e tabelas com valores específicos"""
        constants = {}
        tables = {}
        
        # Extrair constantes (VALUE clauses)
        value_pattern = r'(\w+)\s+PIC\s+[X9V\(\)]+\s+VALUE\s+(["\']?[^.\s]+["\']?)'
        for match in re.finditer(value_pattern, cobol_code, re.IGNORECASE):
            field_name = match.group(1)
            value = match.group(2).strip('\'"')
            constants[field_name] = value
        
        # Extrair tabelas (OCCURS clauses)
        occurs_pattern = r'(\w+)\s+.*?OCCURS\s+(\d+)'
        for match in re.finditer(occurs_pattern, cobol_code, re.IGNORECASE):
            table_name = match.group(1)
            size = match.group(2)
            tables[table_name] = {'size': size, 'structure': self._extract_table_structure(cobol_code, table_name)}
        
        return {'constants': constants, 'tables': tables}
    
    def _extract_file_structures(self, cobol_code: str) -> List[Dict[str, Any]]:
        """Extrai estruturas de arquivos detalhadas"""
        files = []
        
        # Padrões para identificar arquivos
        file_patterns = {
            'fd': r'FD\s+(\w+)',
            'select': r'SELECT\s+(\w+)\s+ASSIGN\s+TO\s+([^\s.]+)'
        }
        
        for pattern_type, pattern in file_patterns.items():
            for match in re.finditer(pattern, cobol_code, re.IGNORECASE):
                file_name = match.group(1)
                
                file_info = {
                    'name': file_name,
                    'type': pattern_type,
                    'structure': self._extract_record_structure(cobol_code, file_name),
                    'access_method': self._extract_access_method(cobol_code, file_name),
                    'key_fields': self._extract_key_fields(cobol_code, file_name)
                }
                files.append(file_info)
        
        return files
    
    def _analyze_copybooks(self, copybooks: str) -> Dict[str, Any]:
        """Analisa copybooks em detalhes"""
        if not copybooks:
            return {}
        
        analysis = {}
        
        # Dividir copybooks por seções
        copybook_sections = re.split(r'\n\s*COPY\s+(\w+)', copybooks, flags=re.IGNORECASE)
        
        for i in range(1, len(copybook_sections), 2):
            if i+1 < len(copybook_sections):
                copybook_name = copybook_sections[i]
                copybook_content = copybook_sections[i+1]
                
                analysis[copybook_name] = {
                    'structures': self._extract_data_structures(copybook_content),
                    'constants': self._extract_constants_from_copybook(copybook_content),
                    'tables': self._extract_tables_from_copybook(copybook_content)
                }
        
        return analysis
    
    # Métodos auxiliares para extração detalhada
    
    def _extract_formula(self, context: str) -> Optional[str]:
        """Extrai fórmula matemática do contexto"""
        compute_pattern = r'COMPUTE\s+(\w+)\s*=\s*([^.]+)'
        match = re.search(compute_pattern, context, re.IGNORECASE)
        return match.group(2).strip() if match else None
    
    def _extract_variables(self, context: str) -> Dict[str, str]:
        """Extrai variáveis e seus tipos"""
        variables = {}
        
        # Padrão para identificar variáveis com PIC
        pic_pattern = r'(\w+)\s+PIC\s+([X9V\(\)S]+)'
        for match in re.finditer(pic_pattern, context, re.IGNORECASE):
            var_name = match.group(1)
            pic_clause = match.group(2)
            variables[var_name] = pic_clause
        
        return variables
    
    def _extract_variables_detailed(self, context: str) -> List[Dict[str, str]]:
        """Extrai variáveis com detalhes completos"""
        variables = []
        
        pic_pattern = r'(\w+)\s+PIC\s+([X9V\(\)S]+)(?:\s+VALUE\s+([^.\s]+))?'
        for match in re.finditer(pic_pattern, context, re.IGNORECASE):
            variable = {
                'name': match.group(1),
                'picture': match.group(2),
                'value': match.group(3) if match.group(3) else None,
                'type': self._determine_data_type(match.group(2))
            }
            variables.append(variable)
        
        return variables
    
    def _extract_conditions(self, context: str) -> List[str]:
        """Extrai condições IF/WHEN"""
        conditions = []
        
        condition_patterns = [
            r'IF\s+([^THEN]+)',
            r'WHEN\s+([^THEN]+)',
            r'EVALUATE\s+([^WHEN]+)'
        ]
        
        for pattern in condition_patterns:
            for match in re.finditer(pattern, context, re.IGNORECASE):
                conditions.append(match.group(1).strip())
        
        return conditions
    
    def _extract_conditions_detailed(self, context: str) -> List[str]:
        """Extrai condições com mais detalhes"""
        conditions = []
        
        # Padrões mais específicos para condições
        patterns = [
            r'IF\s+([^THEN]+)(?:\s+THEN)?',
            r'WHEN\s+([^PERFORM^MOVE^COMPUTE^ADD^SUBTRACT]+)',
            r'EVALUATE\s+([^WHEN]+)'
        ]
        
        for pattern in patterns:
            for match in re.finditer(pattern, context, re.IGNORECASE | re.MULTILINE):
                condition = match.group(1).strip()
                if condition and len(condition) > 3:  # Evitar condições muito curtas
                    conditions.append(condition)
        
        return conditions
    
    def _extract_values(self, context: str) -> List[str]:
        """Extrai valores numéricos e literais"""
        values = []
        
        # Padrões para valores
        value_patterns = [
            r'(\d+\.?\d*)',  # Números
            r'["\']([^"\']+)["\']',  # Strings
            r'VALUE\s+([^.\s]+)'  # Cláusulas VALUE
        ]
        
        for pattern in value_patterns:
            for match in re.finditer(pattern, context):
                value = match.group(1) if pattern.startswith('VALUE') else match.group(0)
                if value not in values:
                    values.append(value)
        
        return values
    
    def _extract_result(self, context: str) -> str:
        """Extrai o resultado de um cálculo ou operação"""
        # Procurar por COMPUTE, MOVE, ADD, etc.
        result_patterns = [
            r'COMPUTE\s+(\w+)',
            r'MOVE\s+[^TO]+TO\s+(\w+)',
            r'ADD\s+[^TO]+TO\s+(\w+)',
            r'SUBTRACT\s+[^FROM]+FROM\s+(\w+)'
        ]
        
        for pattern in result_patterns:
            match = re.search(pattern, context, re.IGNORECASE)
            if match:
                return match.group(1)
        
        return "Resultado não identificado"
    
    def _generate_example(self, calc_type: str, context: str) -> Dict[str, str]:
        """Gera exemplo prático para cálculo"""
        examples = {
            'juros': {
                'principal': 'R$ 1.000,00',
                'taxa': '2,5% a.m.',
                'prazo': '30 dias',
                'resultado': 'R$ 25,00'
            },
            'tarifa': {
                'valor_transacao': 'R$ 500,00',
                'tipo': 'TED',
                'tarifa': 'R$ 8,50',
                'resultado': 'R$ 8,50'
            },
            'multa': {
                'valor_devido': 'R$ 100,00',
                'dias_atraso': '5 dias',
                'percentual': '2%',
                'resultado': 'R$ 2,00'
            }
        }
        
        return examples.get(calc_type, {'exemplo': 'Não disponível'})
    
    def _generate_rule_example(self, rule_type: str, match) -> Optional[str]:
        """Gera exemplo para regra de negócio"""
        examples = {
            'validacao_saldo': 'Se saldo < R$ 100,00, bloquear transação',
            'limite_transacao': 'Se valor > R$ 5.000,00, exigir autorização',
            'tipo_conta': f'Se tipo conta = "{match.group(3) if match.lastindex >= 3 else "N/A"}", aplicar regra específica',
            'status_cliente': f'Se status = "{match.group(3) if match.lastindex >= 3 else "N/A"}", permitir operação'
        }
        
        return examples.get(rule_type)
    
    def _get_context(self, lines: List[str], line_index: int, context_size: int) -> str:
        """Obtém contexto ao redor de uma linha"""
        start = max(0, line_index - context_size)
        end = min(len(lines), line_index + context_size + 1)
        return '\n'.join(lines[start:end])
    
    def _determine_data_type(self, pic_clause: str) -> str:
        """Determina tipo de dados baseado na cláusula PIC"""
        if re.search(r'9', pic_clause):
            if re.search(r'V', pic_clause):
                return 'Numérico com decimais'
            else:
                return 'Numérico inteiro'
        elif re.search(r'X', pic_clause):
            return 'Alfanumérico'
        elif re.search(r'S', pic_clause):
            return 'Numérico com sinal'
        else:
            return 'Tipo não identificado'
    
    # Métodos auxiliares adicionais (implementação básica)
    
    def _describe_rule(self, rule_type: str, match) -> str:
        """Descreve uma regra de negócio"""
        descriptions = {
            'validacao_saldo': 'Validação de saldo suficiente para transação',
            'limite_transacao': 'Controle de limite por valor de transação',
            'tipo_conta': 'Validação baseada no tipo de conta',
            'status_cliente': 'Controle baseado no status do cliente'
        }
        return descriptions.get(rule_type, 'Regra de negócio não categorizada')
    
    def _extract_field_name(self, line: str) -> str:
        """Extrai nome do campo de uma linha"""
        # Implementação simplificada
        words = line.split()
        for word in words:
            if re.match(r'^[A-Z][A-Z0-9-]*$', word):
                return word
        return 'Campo não identificado'
    
    def _extract_validation_criteria(self, line: str) -> str:
        """Extrai critério de validação"""
        return line.strip()
    
    def _extract_error_handling(self, context: str) -> str:
        """Extrai tratamento de erro"""
        if 'PERFORM' in context.upper():
            return 'Executa rotina de erro'
        elif 'MOVE' in context.upper():
            return 'Define código/mensagem de erro'
        else:
            return 'Tratamento não identificado'
    
    def _extract_table_structure(self, cobol_code: str, table_name: str) -> str:
        """Extrai estrutura de tabela"""
        return f"Estrutura da tabela {table_name} (análise detalhada necessária)"
    
    def _extract_record_structure(self, cobol_code: str, file_name: str) -> str:
        """Extrai estrutura de registro"""
        return f"Estrutura do arquivo {file_name} (análise detalhada necessária)"
    
    def _extract_access_method(self, cobol_code: str, file_name: str) -> str:
        """Extrai método de acesso"""
        if 'INDEXED' in cobol_code.upper():
            return 'Indexado'
        elif 'SEQUENTIAL' in cobol_code.upper():
            return 'Sequencial'
        else:
            return 'Não identificado'
    
    def _extract_key_fields(self, cobol_code: str, file_name: str) -> List[str]:
        """Extrai campos chave"""
        keys = []
        key_pattern = r'RECORD\s+KEY\s+IS\s+(\w+)'
        for match in re.finditer(key_pattern, cobol_code, re.IGNORECASE):
            keys.append(match.group(1))
        return keys
    
    def _extract_data_structures(self, copybook_content: str) -> Dict[str, Any]:
        """Extrai estruturas de dados do copybook"""
        return {'estruturas': 'Análise detalhada necessária'}
    
    def _extract_constants_from_copybook(self, copybook_content: str) -> Dict[str, str]:
        """Extrai constantes do copybook"""
        return {}
    
    def _extract_tables_from_copybook(self, copybook_content: str) -> Dict[str, Any]:
        """Extrai tabelas do copybook"""
        return {}
