#!/usr/bin/env python3
"""
Analisador Profissional de COBOL
Baseado no feedback de especialista sênior para gerar análises detalhadas e técnicas
"""

import re
import logging
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass
from pathlib import Path

@dataclass
class BusinessRule:
    """Representa uma regra de negócio identificada"""
    id: str
    name: str
    description: str
    location: str
    cobol_code: str
    formula: Optional[str] = None
    variables: List[str] = None
    conditions: List[str] = None
    values: List[str] = None
    business_impact: str = "Médio"
    technical_complexity: str = "Média"
    modernization_priority: str = "Média"

@dataclass
class DataStructure:
    """Representa uma estrutura de dados COBOL"""
    name: str
    level: str
    pic_clause: str
    usage: str
    description: str
    copybook_source: Optional[str] = None

@dataclass
class IntegrationInterface:
    """Representa uma interface ou integração"""
    name: str
    type: str  # FILE, DB2, CICS, etc.
    direction: str  # INPUT, OUTPUT, BIDIRECTIONAL
    description: str
    technical_details: str

class ProfessionalCOBOLAnalyzer:
    """
    Analisador profissional de código COBOL que gera análises detalhadas
    seguindo padrões de qualidade de especialistas sênior
    """
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
    def analyze_program_comprehensive(self, program: Any, copybooks: Dict[str, str] = None) -> Dict[str, Any]:
        """
        Realiza análise abrangente de um programa COBOL
        """
        self.logger.info(f"Iniciando análise profissional do programa {program.name}")
        
        analysis = {
            "program_info": self._extract_program_info(program),
            "business_rules": self._identify_business_rules(program),
            "data_structures": self._analyze_data_structures(program, copybooks),
            "integration_interfaces": self._identify_integrations(program),
            "file_operations": self._analyze_file_operations(program),
            "database_operations": self._analyze_database_operations(program),
            "conditional_logic": self._analyze_conditional_logic(program),
            "calculations": self._identify_calculations(program),
            "error_handling": self._analyze_error_handling(program),
            "performance_considerations": self._analyze_performance(program),
            "modernization_assessment": self._assess_modernization_needs(program),
            "technical_debt": self._identify_technical_debt(program),
            "code_quality_metrics": self._calculate_quality_metrics(program)
        }
        
        return analysis
    
    def _extract_program_info(self, program: Any) -> Dict[str, Any]:
        """Extrai informações básicas do programa"""
        lines = program.content.split('\n')
        
        # Identificar divisões
        divisions = {
            "identification": self._find_division_content(lines, "IDENTIFICATION DIVISION"),
            "environment": self._find_division_content(lines, "ENVIRONMENT DIVISION"),
            "data": self._find_division_content(lines, "DATA DIVISION"),
            "procedure": self._find_division_content(lines, "PROCEDURE DIVISION")
        }
        
        # Extrair informações do programa
        program_id = self._extract_program_id(lines)
        author = self._extract_author(lines)
        date_written = self._extract_date_written(lines)
        
        return {
            "program_id": program_id,
            "author": author,
            "date_written": date_written,
            "total_lines": len(lines),
            "divisions": divisions,
            "complexity_indicators": {
                "nested_ifs": self._count_nested_structures(lines, "IF"),
                "perform_statements": self._count_statements(lines, "PERFORM"),
                "goto_statements": self._count_statements(lines, "GO TO"),
                "evaluate_statements": self._count_statements(lines, "EVALUATE")
            }
        }
    
    def _identify_business_rules(self, program: Any) -> List[BusinessRule]:
        """Identifica regras de negócio específicas"""
        lines = program.content.split('\n')
        business_rules = []
        
        # Procurar por padrões de regras de negócio
        for i, line in enumerate(lines):
            line_upper = line.strip().upper()
            
            # Regras baseadas em IF com valores específicos
            if 'IF ' in line_upper and any(op in line_upper for op in ['=', '>', '<', 'EQUAL', 'GREATER', 'LESS']):
                rule = self._extract_conditional_rule(lines, i, program.name)
                if rule:
                    business_rules.append(rule)
            
            # Regras baseadas em EVALUATE
            elif 'EVALUATE ' in line_upper:
                rule = self._extract_evaluate_rule(lines, i, program.name)
                if rule:
                    business_rules.append(rule)
            
            # Regras baseadas em cálculos específicos
            elif any(calc in line_upper for calc in ['COMPUTE', 'ADD', 'SUBTRACT', 'MULTIPLY', 'DIVIDE']):
                rule = self._extract_calculation_rule(lines, i, program.name)
                if rule:
                    business_rules.append(rule)
        
        return business_rules
    
    def _analyze_data_structures(self, program: Any, copybooks: Dict[str, str] = None) -> Dict[str, Any]:
        """Analisa estruturas de dados incluindo copybooks"""
        lines = program.content.split('\n')
        
        # Identificar COPY statements
        copy_statements = []
        for i, line in enumerate(lines):
            if 'COPY ' in line.upper():
                copy_name = self._extract_copy_name(line)
                copy_statements.append({
                    "line": i + 1,
                    "copybook": copy_name,
                    "statement": line.strip()
                })
        
        # Analisar estruturas de dados locais
        data_structures = self._extract_data_structures(lines)
        
        # Analisar copybooks se fornecidos
        copybook_analysis = {}
        if copybooks:
            for copy_name in [cs["copybook"] for cs in copy_statements]:
                if copy_name in copybooks:
                    copybook_analysis[copy_name] = self._analyze_copybook_structure(copybooks[copy_name])
        
        return {
            "copy_statements": copy_statements,
            "local_data_structures": data_structures,
            "copybook_analysis": copybook_analysis,
            "data_flow": self._analyze_data_flow(lines),
            "working_storage_usage": self._analyze_working_storage(lines)
        }
    
    def _identify_integrations(self, program: Any) -> List[IntegrationInterface]:
        """Identifica integrações e interfaces"""
        lines = program.content.split('\n')
        integrations = []
        
        for i, line in enumerate(lines):
            line_upper = line.strip().upper()
            
            # Identificar operações de arquivo
            if any(op in line_upper for op in ['OPEN ', 'READ ', 'WRITE ', 'CLOSE ']):
                integration = self._extract_file_integration(lines, i)
                if integration:
                    integrations.append(integration)
            
            # Identificar chamadas DB2
            elif 'EXEC SQL' in line_upper:
                integration = self._extract_db2_integration(lines, i)
                if integration:
                    integrations.append(integration)
            
            # Identificar chamadas CICS
            elif 'EXEC CICS' in line_upper:
                integration = self._extract_cics_integration(lines, i)
                if integration:
                    integrations.append(integration)
            
            # Identificar CALL statements
            elif 'CALL ' in line_upper:
                integration = self._extract_program_call(lines, i)
                if integration:
                    integrations.append(integration)
        
        return integrations
    
    def _analyze_file_operations(self, program: Any) -> Dict[str, Any]:
        """Analisa operações de arquivo detalhadamente"""
        lines = program.content.split('\n')
        
        file_operations = {
            "file_definitions": [],
            "open_operations": [],
            "read_operations": [],
            "write_operations": [],
            "close_operations": [],
            "file_status_handling": []
        }
        
        # Analisar cada tipo de operação
        for i, line in enumerate(lines):
            line_upper = line.strip().upper()
            
            if 'SELECT ' in line_upper and 'ASSIGN TO' in line_upper:
                file_def = self._extract_file_definition(line)
                file_operations["file_definitions"].append(file_def)
            
            elif 'OPEN ' in line_upper:
                open_op = self._extract_file_operation(lines, i, "OPEN")
                file_operations["open_operations"].append(open_op)
            
            elif 'READ ' in line_upper:
                read_op = self._extract_file_operation(lines, i, "READ")
                file_operations["read_operations"].append(read_op)
            
            elif 'WRITE ' in line_upper:
                write_op = self._extract_file_operation(lines, i, "WRITE")
                file_operations["write_operations"].append(write_op)
            
            elif 'CLOSE ' in line_upper:
                close_op = self._extract_file_operation(lines, i, "CLOSE")
                file_operations["close_operations"].append(close_op)
        
        return file_operations
    
    def _analyze_database_operations(self, program: Any) -> Dict[str, Any]:
        """Analisa operações de banco de dados"""
        lines = program.content.split('\n')
        
        db_operations = {
            "sql_statements": [],
            "cursors": [],
            "transactions": [],
            "error_handling": []
        }
        
        in_sql_block = False
        sql_block = []
        
        for i, line in enumerate(lines):
            line_upper = line.strip().upper()
            
            if 'EXEC SQL' in line_upper:
                in_sql_block = True
                sql_block = [line.strip()]
            elif 'END-EXEC' in line_upper and in_sql_block:
                sql_block.append(line.strip())
                sql_statement = self._parse_sql_statement(sql_block, i)
                db_operations["sql_statements"].append(sql_statement)
                in_sql_block = False
                sql_block = []
            elif in_sql_block:
                sql_block.append(line.strip())
        
        return db_operations
    
    def _analyze_conditional_logic(self, program: Any) -> Dict[str, Any]:
        """Analisa lógica condicional complexa"""
        lines = program.content.split('\n')
        
        conditional_logic = {
            "if_statements": [],
            "evaluate_statements": [],
            "nested_conditions": [],
            "complex_conditions": []
        }
        
        for i, line in enumerate(lines):
            line_upper = line.strip().upper()
            
            if 'IF ' in line_upper:
                if_analysis = self._analyze_if_statement(lines, i)
                conditional_logic["if_statements"].append(if_analysis)
            
            elif 'EVALUATE ' in line_upper:
                evaluate_analysis = self._analyze_evaluate_statement(lines, i)
                conditional_logic["evaluate_statements"].append(evaluate_analysis)
        
        return conditional_logic
    
    def _identify_calculations(self, program: Any) -> List[Dict[str, Any]]:
        """Identifica e analisa cálculos específicos"""
        lines = program.content.split('\n')
        calculations = []
        
        for i, line in enumerate(lines):
            line_upper = line.strip().upper()
            
            if any(calc in line_upper for calc in ['COMPUTE', 'ADD', 'SUBTRACT', 'MULTIPLY', 'DIVIDE']):
                calc_analysis = self._analyze_calculation(lines, i)
                if calc_analysis:
                    calculations.append(calc_analysis)
        
        return calculations
    
    def _analyze_error_handling(self, program: Any) -> Dict[str, Any]:
        """Analisa tratamento de erros"""
        lines = program.content.split('\n')
        
        error_handling = {
            "file_status_checks": [],
            "sql_error_handling": [],
            "invalid_key_handling": [],
            "at_end_handling": [],
            "exception_handling": []
        }
        
        for i, line in enumerate(lines):
            line_upper = line.strip().upper()
            
            if 'FILE-STATUS' in line_upper or 'WS-FILE-STATUS' in line_upper:
                error_handling["file_status_checks"].append({
                    "line": i + 1,
                    "code": line.strip(),
                    "type": "File Status Check"
                })
            
            elif 'SQLCODE' in line_upper or 'SQLSTATE' in line_upper:
                error_handling["sql_error_handling"].append({
                    "line": i + 1,
                    "code": line.strip(),
                    "type": "SQL Error Handling"
                })
            
            elif 'INVALID KEY' in line_upper:
                error_handling["invalid_key_handling"].append({
                    "line": i + 1,
                    "code": line.strip(),
                    "type": "Invalid Key Handling"
                })
            
            elif 'AT END' in line_upper:
                error_handling["at_end_handling"].append({
                    "line": i + 1,
                    "code": line.strip(),
                    "type": "End of File Handling"
                })
        
        return error_handling
    
    def _analyze_performance(self, program: Any) -> Dict[str, Any]:
        """Analisa considerações de performance"""
        lines = program.content.split('\n')
        
        performance_issues = []
        performance_optimizations = []
        
        for i, line in enumerate(lines):
            line_upper = line.strip().upper()
            
            # Identificar possíveis problemas de performance
            if 'GO TO' in line_upper:
                performance_issues.append({
                    "line": i + 1,
                    "issue": "GO TO statement - pode impactar legibilidade e performance",
                    "severity": "Medium",
                    "recommendation": "Considerar refatoração com PERFORM"
                })
            
            elif line_upper.count('PERFORM') > 1:
                performance_issues.append({
                    "line": i + 1,
                    "issue": "Múltiplos PERFORM na mesma linha",
                    "severity": "Low",
                    "recommendation": "Considerar separar em linhas diferentes"
                })
        
        return {
            "performance_issues": performance_issues,
            "performance_optimizations": performance_optimizations,
            "complexity_metrics": self._calculate_complexity_metrics(lines)
        }
    
    def _assess_modernization_needs(self, program: Any) -> Dict[str, Any]:
        """Avalia necessidades de modernização"""
        lines = program.content.split('\n')
        
        modernization_indicators = {
            "obsolete_features": [],
            "modernization_opportunities": [],
            "priority_score": 0,
            "effort_estimate": "Medium"
        }
        
        # Identificar recursos obsoletos
        for i, line in enumerate(lines):
            line_upper = line.strip().upper()
            
            if 'GO TO' in line_upper:
                modernization_indicators["obsolete_features"].append({
                    "feature": "GO TO statement",
                    "line": i + 1,
                    "recommendation": "Refatorar usando estruturas estruturadas"
                })
            
            elif 'ALTER' in line_upper:
                modernization_indicators["obsolete_features"].append({
                    "feature": "ALTER statement",
                    "line": i + 1,
                    "recommendation": "Eliminar uso de ALTER"
                })
        
        # Calcular score de prioridade
        priority_score = len(modernization_indicators["obsolete_features"]) * 10
        modernization_indicators["priority_score"] = min(100, priority_score)
        
        return modernization_indicators
    
    def _identify_technical_debt(self, program: Any) -> Dict[str, Any]:
        """Identifica débito técnico"""
        lines = program.content.split('\n')
        
        technical_debt = {
            "hardcoded_values": [],
            "magic_numbers": [],
            "duplicate_code": [],
            "complex_procedures": [],
            "debt_score": 0
        }
        
        # Identificar valores hardcoded
        for i, line in enumerate(lines):
            # Procurar por números mágicos e strings hardcoded
            if re.search(r'\b\d{2,}\b', line) and not line.strip().startswith('*'):
                technical_debt["magic_numbers"].append({
                    "line": i + 1,
                    "code": line.strip(),
                    "recommendation": "Considerar usar constantes nomeadas"
                })
        
        return technical_debt
    
    def _calculate_quality_metrics(self, program: Any) -> Dict[str, Any]:
        """Calcula métricas de qualidade do código"""
        lines = program.content.split('\n')
        
        # Filtrar comentários e linhas vazias
        code_lines = [line for line in lines if line.strip() and not line.strip().startswith('*')]
        comment_lines = [line for line in lines if line.strip().startswith('*')]
        
        return {
            "total_lines": len(lines),
            "code_lines": len(code_lines),
            "comment_lines": len(comment_lines),
            "comment_ratio": len(comment_lines) / len(lines) if lines else 0,
            "cyclomatic_complexity": self._calculate_cyclomatic_complexity(lines),
            "maintainability_index": self._calculate_maintainability_index(lines),
            "code_duplication": self._detect_code_duplication(lines)
        }
    
    # Métodos auxiliares (implementações simplificadas)
    def _find_division_content(self, lines: List[str], division: str) -> Dict[str, Any]:
        """Encontra conteúdo de uma divisão específica"""
        return {"found": any(division in line.upper() for line in lines)}
    
    def _extract_program_id(self, lines: List[str]) -> str:
        """Extrai ID do programa"""
        for line in lines:
            if 'PROGRAM-ID' in line.upper():
                return line.split('.')[0].split()[-1] if '.' in line else "Unknown"
        return "Unknown"
    
    def _extract_author(self, lines: List[str]) -> str:
        """Extrai autor do programa"""
        for line in lines:
            if 'AUTHOR' in line.upper():
                return line.split('AUTHOR')[-1].strip().rstrip('.') if 'AUTHOR' in line.upper() else "Unknown"
        return "Unknown"
    
    def _extract_date_written(self, lines: List[str]) -> str:
        """Extrai data de criação"""
        for line in lines:
            if 'DATE-WRITTEN' in line.upper():
                return line.split('DATE-WRITTEN')[-1].strip().rstrip('.') if 'DATE-WRITTEN' in line.upper() else "Unknown"
        return "Unknown"
    
    def _count_nested_structures(self, lines: List[str], structure: str) -> int:
        """Conta estruturas aninhadas"""
        return sum(1 for line in lines if structure in line.upper())
    
    def _count_statements(self, lines: List[str], statement: str) -> int:
        """Conta declarações específicas"""
        return sum(1 for line in lines if statement in line.upper())
    
    def _calculate_cyclomatic_complexity(self, lines: List[str]) -> int:
        """Calcula complexidade ciclomática"""
        decision_points = 0
        for line in lines:
            line_upper = line.upper()
            decision_points += line_upper.count('IF ')
            decision_points += line_upper.count('EVALUATE ')
            decision_points += line_upper.count('PERFORM ')
            decision_points += line_upper.count('WHEN ')
        return decision_points + 1
    
    def _calculate_maintainability_index(self, lines: List[str]) -> float:
        """Calcula índice de manutenibilidade"""
        # Implementação simplificada
        complexity = self._calculate_cyclomatic_complexity(lines)
        loc = len([line for line in lines if line.strip() and not line.strip().startswith('*')])
        
        # Fórmula simplificada do índice de manutenibilidade
        if loc > 0:
            maintainability = max(0, 171 - 5.2 * (complexity / loc * 100) - 0.23 * complexity - 16.2 * (loc / 1000))
            return min(100, maintainability)
        return 100
    
    def _detect_code_duplication(self, lines: List[str]) -> Dict[str, Any]:
        """Detecta duplicação de código"""
        # Implementação simplificada
        return {"detected": False, "duplicated_blocks": []}
    
    # Métodos de extração específicos (implementações simplificadas)
    def _extract_conditional_rule(self, lines: List[str], line_index: int, program_name: str) -> Optional[BusinessRule]:
        """Extrai regra condicional"""
        line = lines[line_index].strip()
        return BusinessRule(
            id=f"BR_{program_name}_{line_index:03d}",
            name=f"Regra Condicional Linha {line_index + 1}",
            description=f"Condição identificada: {line}",
            location=f"Linha {line_index + 1}",
            cobol_code=line,
            conditions=[line]
        )
    
    def _extract_evaluate_rule(self, lines: List[str], line_index: int, program_name: str) -> Optional[BusinessRule]:
        """Extrai regra EVALUATE"""
        line = lines[line_index].strip()
        return BusinessRule(
            id=f"BR_{program_name}_{line_index:03d}",
            name=f"Regra EVALUATE Linha {line_index + 1}",
            description=f"Estrutura EVALUATE identificada: {line}",
            location=f"Linha {line_index + 1}",
            cobol_code=line
        )
    
    def _extract_calculation_rule(self, lines: List[str], line_index: int, program_name: str) -> Optional[BusinessRule]:
        """Extrai regra de cálculo"""
        line = lines[line_index].strip()
        return BusinessRule(
            id=f"BR_{program_name}_{line_index:03d}",
            name=f"Cálculo Linha {line_index + 1}",
            description=f"Operação matemática identificada: {line}",
            location=f"Linha {line_index + 1}",
            cobol_code=line,
            formula=line
        )
    
    # Implementações simplificadas dos demais métodos
    def _extract_copy_name(self, line: str) -> str:
        """Extrai nome do copybook"""
        parts = line.upper().split('COPY')
        if len(parts) > 1:
            return parts[1].strip().split()[0].rstrip('.')
        return "Unknown"
    
    def _extract_data_structures(self, lines: List[str]) -> List[DataStructure]:
        """Extrai estruturas de dados"""
        return []
    
    def _analyze_copybook_structure(self, copybook_content: str) -> Dict[str, Any]:
        """Analisa estrutura de copybook"""
        return {"analyzed": True}
    
    def _analyze_data_flow(self, lines: List[str]) -> Dict[str, Any]:
        """Analisa fluxo de dados"""
        return {"analyzed": True}
    
    def _analyze_working_storage(self, lines: List[str]) -> Dict[str, Any]:
        """Analisa working storage"""
        return {"analyzed": True}
    
    def _extract_file_integration(self, lines: List[str], line_index: int) -> Optional[IntegrationInterface]:
        """Extrai integração de arquivo"""
        return None
    
    def _extract_db2_integration(self, lines: List[str], line_index: int) -> Optional[IntegrationInterface]:
        """Extrai integração DB2"""
        return None
    
    def _extract_cics_integration(self, lines: List[str], line_index: int) -> Optional[IntegrationInterface]:
        """Extrai integração CICS"""
        return None
    
    def _extract_program_call(self, lines: List[str], line_index: int) -> Optional[IntegrationInterface]:
        """Extrai chamada de programa"""
        return None
    
    def _extract_file_definition(self, line: str) -> Dict[str, Any]:
        """Extrai definição de arquivo"""
        return {"line": line}
    
    def _extract_file_operation(self, lines: List[str], line_index: int, operation: str) -> Dict[str, Any]:
        """Extrai operação de arquivo"""
        return {"operation": operation, "line": line_index + 1}
    
    def _parse_sql_statement(self, sql_block: List[str], line_index: int) -> Dict[str, Any]:
        """Analisa declaração SQL"""
        return {"sql": " ".join(sql_block), "line": line_index + 1}
    
    def _analyze_if_statement(self, lines: List[str], line_index: int) -> Dict[str, Any]:
        """Analisa declaração IF"""
        return {"line": line_index + 1, "condition": lines[line_index].strip()}
    
    def _analyze_evaluate_statement(self, lines: List[str], line_index: int) -> Dict[str, Any]:
        """Analisa declaração EVALUATE"""
        return {"line": line_index + 1, "evaluate": lines[line_index].strip()}
    
    def _analyze_calculation(self, lines: List[str], line_index: int) -> Optional[Dict[str, Any]]:
        """Analisa cálculo"""
        return {"line": line_index + 1, "calculation": lines[line_index].strip()}
    
    def _calculate_complexity_metrics(self, lines: List[str]) -> Dict[str, Any]:
        """Calcula métricas de complexidade"""
        return {"complexity": "Medium"}
