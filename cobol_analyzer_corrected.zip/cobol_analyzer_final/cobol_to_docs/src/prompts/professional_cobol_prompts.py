#!/usr/bin/env python3
"""
Prompts Profissionais para Análise COBOL
Prompts otimizados baseados no feedback de especialista sênior
"""

class ProfessionalCOBOLPrompts:
    """
    Classe contendo prompts profissionais e técnicos para análise de código COBOL
    """
    
    @staticmethod
    def get_comprehensive_analysis_prompt(program_name: str, program_content: str, copybooks: str = "") -> str:
        """
        Prompt principal para análise abrangente de programa COBOL
        """
        return f"""Você é um especialista sênior em COBOL com mais de 20 anos de experiência em análise de sistemas legados. 
Analise o programa COBOL a seguir de forma técnica e detalhada, seguindo os padrões de qualidade empresarial.

PROGRAMA: {program_name}

COPYBOOKS RELACIONADOS:
{copybooks if copybooks else "Nenhum copybook fornecido"}

CÓDIGO COBOL:
{program_content}

INSTRUÇÕES PARA ANÁLISE PROFISSIONAL:

1. REGRAS DE NEGÓCIO IDENTIFICADAS:
   - Identifique TODAS as regras de negócio específicas
   - Para cada regra, forneça: localização (linha), descrição técnica, valores específicos, fórmulas
   - Classifique por criticidade: ALTA, MÉDIA, BAIXA
   - Identifique validações de dados, cálculos financeiros, lógica condicional

2. ESTRUTURAS DE DADOS:
   - Liste TODOS os copybooks utilizados (COPY statements)
   - Identifique estruturas de Working Storage Section
   - Analise File Section e Linkage Section
   - Mapeie relacionamentos entre estruturas

3. INTEGRAÇÕES E INTERFACES:
   - Identifique operações de arquivo (OPEN, READ, WRITE, CLOSE)
   - Detecte chamadas SQL (EXEC SQL)
   - Identifique chamadas CICS (EXEC CICS)
   - Liste chamadas para outros programas (CALL statements)
   - Analise interfaces desativadas ou comentadas

4. OPERAÇÕES DE BANCO DE DADOS:
   - Liste todas as operações SQL
   - Identifique cursors e transações
   - Analise tratamento de SQLCODE/SQLSTATE
   - Verifique commits e rollbacks

5. LÓGICA CONDICIONAL COMPLEXA:
   - Analise estruturas IF-THEN-ELSE aninhadas
   - Examine statements EVALUATE/WHEN
   - Identifique condições complexas com múltiplos operadores
   - Conte níveis de aninhamento

6. CÁLCULOS E FÓRMULAS:
   - Liste TODAS as operações matemáticas (COMPUTE, ADD, SUBTRACT, MULTIPLY, DIVIDE)
   - Extraia fórmulas específicas e valores
   - Identifique constantes e números mágicos
   - Analise precisão numérica (PIC clauses)

7. TRATAMENTO DE ERROS:
   - Verifique tratamento de File Status
   - Analise tratamento de erros SQL
   - Identifique INVALID KEY, AT END, NOT AT END
   - Examine rotinas de erro customizadas

8. CONSIDERAÇÕES DE PERFORMANCE:
   - Identifique possíveis gargalos
   - Analise uso de índices em operações de arquivo
   - Verifique otimizações de loop
   - Identifique operações custosas

9. AVALIAÇÃO DE MODERNIZAÇÃO:
   - Identifique recursos obsoletos (GO TO, ALTER)
   - Avalie complexidade ciclomática
   - Sugira refatorações prioritárias
   - Estime esforço de modernização

10. DÉBITO TÉCNICO:
    - Identifique código duplicado
    - Liste valores hardcoded
    - Analise nomenclatura inconsistente
    - Verifique documentação inadequada

FORMATO DE RESPOSTA ESPERADO:

## ANÁLISE TÉCNICA DETALHADA - {program_name}

### 1. INFORMAÇÕES DO PROGRAMA
- **Autor**: [extrair do código]
- **Data de Criação**: [extrair do código]
- **Propósito**: [inferir do código e comentários]
- **Complexidade**: [avaliar: BAIXA/MÉDIA/ALTA]

### 2. REGRAS DE NEGÓCIO (Criticidade: ALTA/MÉDIA/BAIXA)
[Para cada regra identificada:]
- **RN-001**: [Descrição técnica] - Linha X - Criticidade: ALTA
  - Código: `[trecho específico]`
  - Valores: [valores específicos encontrados]
  - Fórmula: [se aplicável]

### 3. ESTRUTURAS DE DADOS
- **Copybooks**: [listar todos os COPY statements]
- **Working Storage**: [principais estruturas]
- **File Section**: [arquivos definidos]
- **Linkage Section**: [parâmetros]

### 4. INTEGRAÇÕES E INTERFACES
- **Arquivos**: [operações de arquivo identificadas]
- **Base de Dados**: [operações SQL]
- **CICS**: [transações CICS]
- **Programas**: [chamadas CALL]

### 5. OPERAÇÕES DE BANCO DE DADOS
[Listar todas as operações SQL com detalhes]

### 6. LÓGICA CONDICIONAL
- **Complexidade Ciclomática**: [calcular]
- **IFs Aninhados**: [contar níveis]
- **EVALUATE Statements**: [listar]

### 7. CÁLCULOS IDENTIFICADOS
[Para cada cálculo:]
- **Linha X**: `[código]` - [descrição do cálculo]

### 8. TRATAMENTO DE ERROS
- **File Status**: [verificações encontradas]
- **SQL Errors**: [tratamento SQLCODE]
- **Outros**: [tratamentos customizados]

### 9. CONSIDERAÇÕES DE PERFORMANCE
- **Problemas Identificados**: [listar com severidade]
- **Recomendações**: [sugestões específicas]

### 10. MODERNIZAÇÃO E DÉBITO TÉCNICO
- **Prioridade de Modernização**: [ALTA/MÉDIA/BAIXA]
- **Recursos Obsoletos**: [GO TO, ALTER, etc.]
- **Débito Técnico**: [problemas identificados]
- **Esforço Estimado**: [horas/dias]

### 11. RECOMENDAÇÕES ESPECÍFICAS
1. **Imediatas**: [ações prioritárias]
2. **Médio Prazo**: [melhorias recomendadas]
3. **Longo Prazo**: [modernização completa]

SEJA ESPECÍFICO, TÉCNICO E DETALHADO. Use terminologia COBOL correta e forneça exemplos de código quando relevante.
Foque em aspectos que um especialista sênior consideraria críticos para manutenção e modernização do sistema."""

    @staticmethod
    def get_business_rules_extraction_prompt(program_name: str, program_content: str) -> str:
        """
        Prompt específico para extração de regras de negócio
        """
        return f"""Como especialista sênior em COBOL, extraia TODAS as regras de negócio do programa {program_name}.

CÓDIGO:
{program_content}

FOQUE EM:
1. Validações de dados (IF conditions com valores específicos)
2. Cálculos financeiros (COMPUTE, ADD, SUBTRACT, MULTIPLY, DIVIDE)
3. Lógica condicional de negócio (EVALUATE, nested IFs)
4. Constantes e valores hardcoded
5. Fórmulas matemáticas específicas

FORMATO DE RESPOSTA:
Para cada regra encontrada, forneça:
- **ID**: RN-XXX
- **Linha**: número da linha
- **Tipo**: [Validação/Cálculo/Lógica/Constante]
- **Descrição**: descrição técnica detalhada
- **Código**: trecho específico do COBOL
- **Valores**: valores específicos utilizados
- **Criticidade**: ALTA/MÉDIA/BAIXA
- **Impacto**: descrição do impacto no negócio

Seja extremamente detalhado e técnico."""

    @staticmethod
    def get_integration_analysis_prompt(program_name: str, program_content: str) -> str:
        """
        Prompt específico para análise de integrações
        """
        return f"""Analise TODAS as integrações e interfaces do programa COBOL {program_name}.

CÓDIGO:
{program_content}

IDENTIFIQUE:
1. **Operações de Arquivo**:
   - SELECT/ASSIGN statements
   - OPEN/CLOSE operations
   - READ/WRITE operations
   - File status handling

2. **Operações de Banco de Dados**:
   - EXEC SQL statements
   - Cursors (DECLARE, OPEN, FETCH, CLOSE)
   - Transações (COMMIT, ROLLBACK)
   - Error handling (SQLCODE, SQLSTATE)

3. **Transações CICS**:
   - EXEC CICS statements
   - Screen handling
   - File operations via CICS

4. **Chamadas de Programa**:
   - CALL statements
   - Parâmetros passados
   - Programas chamados

5. **Interfaces Desativadas**:
   - Código comentado com integrações
   - Interfaces obsoletas

FORMATO DETALHADO:
Para cada integração:
- **Tipo**: [Arquivo/DB2/CICS/Programa]
- **Nome**: nome do recurso
- **Operação**: tipo de operação
- **Localização**: linha no código
- **Status**: [Ativa/Desativada/Comentada]
- **Detalhes Técnicos**: especificações técnicas"""

    @staticmethod
    def get_performance_analysis_prompt(program_name: str, program_content: str) -> str:
        """
        Prompt específico para análise de performance
        """
        return f"""Analise as considerações de performance do programa COBOL {program_name}.

CÓDIGO:
{program_content}

ANALISE:
1. **Gargalos Potenciais**:
   - Loops aninhados
   - Operações de I/O repetitivas
   - Processamento sequencial desnecessário

2. **Otimizações Possíveis**:
   - Uso eficiente de índices
   - Minimização de I/O
   - Estruturas de dados otimizadas

3. **Problemas de Código**:
   - GO TO statements (impacto na performance)
   - Código duplicado
   - Operações custosas em loops

4. **Métricas de Complexidade**:
   - Complexidade ciclomática
   - Profundidade de aninhamento
   - Número de pontos de decisão

CLASSIFIQUE PROBLEMAS:
- **CRÍTICO**: impacto severo na performance
- **ALTO**: impacto significativo
- **MÉDIO**: impacto moderado
- **BAIXO**: impacto mínimo

Forneça recomendações específicas para cada problema identificado."""

    @staticmethod
    def get_modernization_assessment_prompt(program_name: str, program_content: str) -> str:
        """
        Prompt específico para avaliação de modernização
        """
        return f"""Avalie as necessidades de modernização do programa COBOL {program_name}.

CÓDIGO:
{program_content}

AVALIE:
1. **Recursos Obsoletos**:
   - GO TO statements
   - ALTER statements
   - Práticas desatualizadas

2. **Oportunidades de Modernização**:
   - Estruturação de código
   - Eliminação de código duplicado
   - Melhoria na legibilidade

3. **Prioridade de Modernização**:
   - ALTA: requer ação imediata
   - MÉDIA: pode ser planejada
   - BAIXA: melhoria desejável

4. **Esforço Estimado**:
   - Horas/dias necessários
   - Complexidade da refatoração
   - Riscos envolvidos

5. **Roadmap de Modernização**:
   - Fase 1: correções críticas
   - Fase 2: melhorias estruturais
   - Fase 3: otimizações avançadas

Seja específico sobre o que modernizar e como."""

    @staticmethod
    def get_cost_estimation_prompt(program_name: str, lines_of_code: int, complexity: str) -> str:
        """
        Prompt para estimativa de custos de modernização
        """
        return f"""Como especialista em modernização de sistemas COBOL, estime os custos para modernizar o programa {program_name}.

DADOS DO PROGRAMA:
- Nome: {program_name}
- Linhas de Código: {lines_of_code}
- Complexidade: {complexity}

ESTIME:
1. **Análise Detalhada**: horas necessárias
2. **Refatoração**: esforço em horas/dias
3. **Testes**: tempo para validação
4. **Documentação**: esforço para documentar
5. **Treinamento**: tempo para capacitar equipe

FORNEÇA:
- Estimativa em horas
- Custo em R$ (considerando R$ 150/hora)
- Cronograma sugerido
- Riscos e contingências
- ROI esperado"""

    @staticmethod
    def get_quality_metrics_prompt(program_name: str, program_content: str) -> str:
        """
        Prompt para cálculo de métricas de qualidade
        """
        return f"""Calcule as métricas de qualidade do código COBOL {program_name}.

CÓDIGO:
{program_content}

CALCULE:
1. **Complexidade Ciclomática**: número de caminhos independentes
2. **Profundidade de Aninhamento**: níveis máximos de IF/PERFORM
3. **Linhas de Código Efetivas**: excluindo comentários e linhas vazias
4. **Proporção de Comentários**: comentários vs código
5. **Índice de Manutenibilidade**: baseado em complexidade e tamanho
6. **Duplicação de Código**: blocos similares identificados
7. **Cobertura de Tratamento de Erro**: % de operações com tratamento

CLASSIFIQUE QUALIDADE:
- **EXCELENTE**: 90-100 pontos
- **BOA**: 70-89 pontos
- **REGULAR**: 50-69 pontos
- **RUIM**: 0-49 pontos

Forneça justificativa técnica para cada métrica."""
