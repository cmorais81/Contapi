"""
Módulo Analytics - Análises Consolidadas e Avançadas
Fornece funcionalidades de análise consolidada e relatórios avançados.
"""

from .consolidated_analysis import (
    process_advanced_consolidated_analysis,
    process_detailed_business_analysis
)

__all__ = [
    'process_advanced_consolidated_analysis',
    'process_detailed_business_analysis'
]
