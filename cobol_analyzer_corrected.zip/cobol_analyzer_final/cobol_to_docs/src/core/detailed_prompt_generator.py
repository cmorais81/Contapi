#!/usr/bin/env python3
"""
Gerador de prompts específicos para análise detalhada de regras de negócio
"""

import logging
import yaml
from typing import Dict, Any, List, Optional
from pathlib import Path

class DetailedPromptGenerator:
    """Gerador de prompts para análise detalhada"""
    
    def __init__(self, config_dir: str = "config"):
        self.logger = logging.getLogger(__name__)
        self.config_dir = Path(config_dir)
        self.deep_prompts = self._load_deep_prompts()
    
    def _load_deep_prompts(self) -> Dict[str, Any]:
        """Carrega prompts para análise detalhada"""
        try:
            prompts_file = self.config_dir / "prompts_deep_business_rules.yaml"
            if prompts_file.exists():
                with open(prompts_file, 'r', encoding='utf-8') as f:
                    return yaml.safe_load(f)
            else:
                self.logger.warning(f"Arquivo de prompts detalhados não encontrado: {prompts_file}")
                return {}
        except Exception as e:
            self.logger.error(f"Erro ao carregar prompts detalhados: {e}")
            return {}
    
    def generate_detailed_analysis_prompt(self, cobol_code: str, copybooks: str = "", 
                                        extract_formulas: bool = False) -> str:
        """
        Gera prompt para análise detalhada de regras de negócio
        """
        try:
            if not self.deep_prompts:
                return self._generate_fallback_detailed_prompt(cobol_code, copybooks, extract_formulas)
            
            # Selecionar prompt baseado no tipo de análise
            if extract_formulas:
                prompt_template = self.deep_prompts['prompts']['financial_calculations']
            else:
                prompt_template = self.deep_prompts['prompts']['deep_business_analysis']
            
            # Construir prompt completo
            system_prompt = prompt_template['system']
            user_prompt = prompt_template['user'].format(
                cobol_code=cobol_code,
                copybooks=copybooks if copybooks else "Nenhum copybook fornecido"
            )
            
            return f"{system_prompt}\n\n{user_prompt}"
            
        except Exception as e:
            self.logger.error(f"Erro ao gerar prompt detalhado: {e}")
            return self._generate_fallback_detailed_prompt(cobol_code, copybooks, extract_formulas)
    
    def generate_business_rules_prompt(self, cobol_code: str, copybooks: str = "") -> str:
        """
        Gera prompt específico para extração de regras de negócio
        """
        try:
            if 'business_rule_extraction' in self.deep_prompts.get('prompts', {}):
                prompt_template = self.deep_prompts['prompts']['business_rule_extraction']
                
                system_prompt = prompt_template['system']
                user_prompt = prompt_template['user'].format(cobol_code=cobol_code)
                
                return f"{system_prompt}\n\n{user_prompt}"
            else:
                return self._generate_fallback_business_rules_prompt(cobol_code, copybooks)
                
        except Exception as e:
            self.logger.error(f"Erro ao gerar prompt de regras de negócio: {e}")
            return self._generate_fallback_business_rules_prompt(cobol_code, copybooks)
    
    def generate_financial_calculations_prompt(self, cobol_code: str, copybooks: str = "") -> str:
        """
        Gera prompt específico para extração de cálculos financeiros
        """
        try:
            if 'financial_calculations' in self.deep_prompts.get('prompts', {}):
                prompt_template = self.deep_prompts['prompts']['financial_calculations']
                
                system_prompt = prompt_template['system']
                user_prompt = prompt_template['user'].format(cobol_code=cobol_code)
                
                return f"{system_prompt}\n\n{user_prompt}"
            else:
                return self._generate_fallback_financial_prompt(cobol_code, copybooks)
                
        except Exception as e:
            self.logger.error(f"Erro ao gerar prompt de cálculos financeiros: {e}")
            return self._generate_fallback_financial_prompt(cobol_code, copybooks)
    
    def generate_data_validation_prompt(self, cobol_code: str, copybooks: str = "") -> str:
        """
        Gera prompt específico para extração de validações de dados
        """
        try:
            if 'data_validation_rules' in self.deep_prompts.get('prompts', {}):
                prompt_template = self.deep_prompts['prompts']['data_validation_rules']
                
                system_prompt = prompt_template['system']
                user_prompt = prompt_template['user'].format(cobol_code=cobol_code)
                
                return f"{system_prompt}\n\n{user_prompt}"
            else:
                return self._generate_fallback_validation_prompt(cobol_code, copybooks)
                
        except Exception as e:
            self.logger.error(f"Erro ao gerar prompt de validações: {e}")
            return self._generate_fallback_validation_prompt(cobol_code, copybooks)
    
    def generate_copybook_analysis_prompt(self, copybooks: str) -> str:
        """
        Gera prompt específico para análise detalhada de copybooks
        """
        try:
            if 'detailed_copybook_analysis' in self.deep_prompts.get('prompts', {}):
                prompt_template = self.deep_prompts['prompts']['detailed_copybook_analysis']
                
                system_prompt = prompt_template['system']
                user_prompt = prompt_template['user'].format(copybooks=copybooks)
                
                return f"{system_prompt}\n\n{user_prompt}"
            else:
                return self._generate_fallback_copybook_prompt(copybooks)
                
        except Exception as e:
            self.logger.error(f"Erro ao gerar prompt de copybooks: {e}")
            return self._generate_fallback_copybook_prompt(copybooks)
    
    def _generate_fallback_detailed_prompt(self, cobol_code: str, copybooks: str, 
                                         extract_formulas: bool) -> str:
        """Gera prompt de fallback para análise detalhada"""
        focus = "cálculos financeiros e fórmulas matemáticas" if extract_formulas else "regras de negócio"
        
        return f"""
Você é um especialista em análise de código COBOL bancário.

IMPORTANTE: Forneça análise DETALHADA com valores específicos, não respostas genéricas.

Analise este código COBOL e extraia TODAS as {focus} com DETALHES ESPECÍFICOS:

CÓDIGO COBOL:
{cobol_code}

COPYBOOKS:
{copybooks if copybooks else "Nenhum copybook fornecido"}

Para CADA regra/cálculo encontrado, especifique:
- VALORES NUMÉRICOS exatos (tarifas, limites, percentuais)
- FÓRMULAS DE CÁLCULO completas
- CONDIÇÕES específicas (IF, WHEN, EVALUATE)
- CAMPOS e variáveis utilizados com PIC
- CONSTANTES e literais do código

Exemplo de resposta esperada:
- Tarifa TED: R$ 8,50 (campo TARIFA-TED PIC 9(3)V99 VALUE 8.50)
- Limite diário: R$ 5.000,00 (campo LIMITE-DIARIO PIC 9(7)V99)
- Cálculo de juros: JUROS = PRINCIPAL * TAXA * DIAS / 30
"""
    
    def _generate_fallback_business_rules_prompt(self, cobol_code: str, copybooks: str) -> str:
        """Gera prompt de fallback para regras de negócio"""
        return f"""
Extraia TODAS as regras de negócio específicas deste código COBOL:

{cobol_code}

Para cada regra, forneça:
- Nome da regra
- Localização no código (linha)
- Condições específicas
- Valores exatos
- Campos envolvidos
- Exemplo prático
"""
    
    def _generate_fallback_financial_prompt(self, cobol_code: str, copybooks: str) -> str:
        """Gera prompt de fallback para cálculos financeiros"""
        return f"""
Identifique TODOS os cálculos financeiros neste código COBOL:

{cobol_code}

Para cada cálculo, especifique:
- Tipo de cálculo (juros, tarifa, multa, etc.)
- Fórmula matemática exata
- Variáveis envolvidas com PIC
- Valores/taxas específicos
- Exemplo numérico
"""
    
    def _generate_fallback_validation_prompt(self, cobol_code: str, copybooks: str) -> str:
        """Gera prompt de fallback para validações"""
        return f"""
Identifique TODAS as validações de dados neste código COBOL:

{cobol_code}

Para cada validação, especifique:
- Campo validado
- Tipo de validação
- Critérios específicos
- Valores aceitos/rejeitados
- Mensagens de erro
"""
    
    def _generate_fallback_copybook_prompt(self, copybooks: str) -> str:
        """Gera prompt de fallback para copybooks"""
        return f"""
Analise estes copybooks em detalhes:

{copybooks}

Para cada copybook, extraia:
- Estruturas de dados completas
- Tabelas internas com valores
- Constantes definidas
- Relacionamentos entre campos
"""
    
    def get_available_prompt_types(self) -> List[str]:
        """Retorna tipos de prompts disponíveis"""
        if not self.deep_prompts:
            return ['fallback']
        
        return list(self.deep_prompts.get('prompts', {}).keys())
    
    def is_detailed_analysis_available(self) -> bool:
        """Verifica se análise detalhada está disponível"""
        return bool(self.deep_prompts and 'prompts' in self.deep_prompts)
