
"""
COBOL AI Engine v2.6.0 - Módulo Core
Componentes centrais do sistema.
"""

from .config import ConfigManager
from .prompt_manager import PromptManager

__all__ = ['ConfigManager', 'PromptManager']

