#!/usr/bin/env python3
"""
Módulo de configuração local automática para COBOL Analyzer
Cria estrutura de diretórios e arquivos necessários localmente
"""

import os
import shutil
import json
import yaml
from pathlib import Path
import logging

class LocalSetup:
    """Gerencia a configuração local automática do COBOL Analyzer"""
    
    def __init__(self, base_dir=None):
        """
        Inicializa o setup local
        
        Args:
            base_dir: Diretório base para criar a estrutura (padrão: diretório atual)
        """
        self.base_dir = Path(base_dir) if base_dir else Path.cwd()
        self.logger = logging.getLogger(__name__)
        
    def setup_local_environment(self, config_dir=None, data_dir=None, logs_dir=None):
        """
        Configura o ambiente local criando diretórios e arquivos necessários
        
        Args:
            config_dir: Diretório para configurações (padrão: ./config)
            data_dir: Diretório para dados RAG (padrão: ./data)
            logs_dir: Diretório para logs (padrão: ./logs)
            
        Returns:
            dict: Caminhos dos diretórios criados
        """
        # Definir diretórios padrão
        config_path = Path(config_dir) if config_dir else self.base_dir / "config"
        data_path = Path(data_dir) if data_dir else self.base_dir / "data"
        logs_path = Path(logs_dir) if logs_dir else self.base_dir / "logs"
        
        # Criar estrutura de diretórios
        directories = {
            'config': config_path,
            'data': data_path,
            'logs': logs_path,
            'examples': self.base_dir / "examples"
        }
        
        created_dirs = []
        for name, path in directories.items():
            if not path.exists():
                path.mkdir(parents=True, exist_ok=True)
                created_dirs.append(str(path))
                self.logger.info(f"Diretório criado: {path}")
        
        # Copiar arquivos de configuração padrão
        self._copy_default_configs(config_path)
        
        # Copiar dados RAG padrão
        self._copy_default_rag_data(data_path)
        
        # Criar exemplos básicos
        self._create_examples(self.base_dir / "examples")
        
        # Criar arquivo de inicialização
        self._create_init_marker(self.base_dir)
        
        return {
            'config_dir': str(config_path),
            'data_dir': str(data_path),
            'logs_dir': str(logs_path),
            'examples_dir': str(self.base_dir / "examples"),
            'created_directories': created_dirs
        }
    
    def _copy_default_configs(self, config_dir):
        """Copia arquivos de configuração padrão"""
        try:
            # Tentar encontrar configurações do pacote instalado
            package_config = self._find_package_resource("config")
            
            if package_config and package_config.exists():
                # Copiar do pacote instalado
                for config_file in package_config.glob("*.yaml"):
                    dest_file = config_dir / config_file.name
                    if not dest_file.exists():
                        shutil.copy2(config_file, dest_file)
                        self.logger.info(f"Configuração copiada: {dest_file}")
            else:
                # Criar configuração básica
                self._create_basic_config(config_dir)
                
        except Exception as e:
            self.logger.warning(f"Erro ao copiar configurações: {e}")
            self._create_basic_config(config_dir)
    
    def _copy_default_rag_data(self, data_dir):
        """Copia dados RAG padrão"""
        try:
            # Tentar encontrar dados do pacote instalado
            package_data = self._find_package_resource("data")
            
            if package_data and package_data.exists():
                # Copiar dados RAG do pacote
                for data_file in package_data.glob("*.json"):
                    dest_file = data_dir / data_file.name
                    if not dest_file.exists():
                        shutil.copy2(data_file, dest_file)
                        self.logger.info(f"Dados RAG copiados: {dest_file}")
            
            # Criar estrutura básica de dados RAG
            rag_dirs = ['embeddings', 'knowledge_base', 'sessions']
            for rag_dir in rag_dirs:
                rag_path = data_dir / rag_dir
                rag_path.mkdir(exist_ok=True)
            
            # Criar base de conhecimento inicial se não existir
            kb_file = data_dir / "cobol_knowledge_base.json"
            if not kb_file.exists():
                self._create_initial_knowledge_base(kb_file)
                
        except Exception as e:
            self.logger.warning(f"Erro ao copiar dados RAG: {e}")
            self._create_initial_knowledge_base(data_dir / "cobol_knowledge_base.json")
    
    def _create_examples(self, examples_dir):
        """Cria arquivos de exemplo"""
        try:
            # Arquivo de fontes de exemplo
            fontes_file = examples_dir / "fontes.txt"
            if not fontes_file.exists():
                with open(fontes_file, 'w', encoding='utf-8') as f:
                    f.write("# Lista de programas COBOL para análise\n")
                    f.write("# Um programa por linha\n")
                    f.write("# Exemplo:\n")
                    f.write("# PROGRAMA1.CBL\n")
                    f.write("# PROGRAMA2.CBL\n")
            
            # Arquivo de copybooks de exemplo
            books_file = examples_dir / "books.txt"
            if not books_file.exists():
                with open(books_file, 'w', encoding='utf-8') as f:
                    f.write("# Lista de copybooks COBOL\n")
                    f.write("# Um copybook por linha\n")
                    f.write("# Exemplo:\n")
                    f.write("# COPYBOOK1.CPY\n")
                    f.write("# COPYBOOK2.CPY\n")
            
            # Programa COBOL de exemplo
            programa_exemplo = examples_dir / "PROGRAMA_EXEMPLO.CBL"
            if not programa_exemplo.exists():
                with open(programa_exemplo, 'w', encoding='utf-8') as f:
                    f.write("""       IDENTIFICATION DIVISION.
       PROGRAM-ID. PROGRAMA-EXEMPLO.
       
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-CONTADOR    PIC 9(3) VALUE ZERO.
       01  WS-TOTAL       PIC 9(5) VALUE ZERO.
       
       PROCEDURE DIVISION.
       MAIN-PROCESS.
           PERFORM VARYING WS-CONTADOR FROM 1 BY 1 
                   UNTIL WS-CONTADOR > 100
               ADD WS-CONTADOR TO WS-TOTAL
           END-PERFORM.
           
           DISPLAY 'TOTAL CALCULADO: ' WS-TOTAL.
           STOP RUN.
""")
            
            self.logger.info(f"Exemplos criados em: {examples_dir}")
            
        except Exception as e:
            self.logger.warning(f"Erro ao criar exemplos: {e}")
    
    def _create_basic_config(self, config_dir):
        """Cria configuração básica"""
        config_file = config_dir / "config.yaml"
        if not config_file.exists():
            basic_config = {
                'models': {
                    'default': 'enhanced_mock',
                    'enhanced_mock': {
                        'provider': 'enhanced_mock',
                        'model': 'enhanced-mock-gpt-4',
                        'enabled': True
                    }
                },
                'output': {
                    'default_dir': 'output',
                    'generate_pdf': False,
                    'generate_html': True
                },
                'rag': {
                    'enabled': True,
                    'knowledge_base_file': 'data/cobol_knowledge_base.json',
                    'max_items': 10
                },
                'logging': {
                    'level': 'INFO',
                    'file': 'logs/cobol_analyzer.log'
                }
            }
            
            with open(config_file, 'w', encoding='utf-8') as f:
                yaml.dump(basic_config, f, default_flow_style=False, allow_unicode=True)
            
            self.logger.info(f"Configuração básica criada: {config_file}")
    
    def _create_initial_knowledge_base(self, kb_file):
        """Cria base de conhecimento inicial"""
        initial_kb = {
            "metadata": {
                "version": "1.0",
                "created": "auto-generated",
                "description": "Base de conhecimento COBOL inicial"
            },
            "knowledge_items": [
                {
                    "id": "kb_0001",
                    "type": "cobol_concept",
                    "title": "IDENTIFICATION DIVISION",
                    "content": "A IDENTIFICATION DIVISION é obrigatória e identifica o programa COBOL.",
                    "tags": ["division", "identification", "program-id"],
                    "relevance_score": 0.9
                },
                {
                    "id": "kb_0002", 
                    "type": "cobol_concept",
                    "title": "DATA DIVISION",
                    "content": "A DATA DIVISION define as estruturas de dados usadas pelo programa.",
                    "tags": ["division", "data", "working-storage"],
                    "relevance_score": 0.9
                },
                {
                    "id": "kb_0003",
                    "type": "cobol_concept", 
                    "title": "PROCEDURE DIVISION",
                    "content": "A PROCEDURE DIVISION contém a lógica executável do programa COBOL.",
                    "tags": ["division", "procedure", "logic"],
                    "relevance_score": 0.9
                }
            ]
        }
        
        with open(kb_file, 'w', encoding='utf-8') as f:
            json.dump(initial_kb, f, indent=2, ensure_ascii=False)
        
        self.logger.info(f"Base de conhecimento inicial criada: {kb_file}")
    
    def _find_package_resource(self, resource_name):
        """Encontra recursos do pacote instalado"""
        try:
            import site
            for site_dir in site.getsitepackages() + [site.getusersitepackages()]:
                if site_dir:
                    resource_path = Path(site_dir) / resource_name
                    if resource_path.exists():
                        return resource_path
            return None
        except:
            return None
    
    def _create_init_marker(self, base_dir):
        """Cria marcador de inicialização"""
        marker_file = base_dir / ".cobol_analyzer_init"
        with open(marker_file, 'w') as f:
            f.write("COBOL Analyzer initialized successfully\n")
    
    def is_initialized(self, base_dir=None):
        """Verifica se o ambiente já foi inicializado"""
        check_dir = Path(base_dir) if base_dir else self.base_dir
        return (check_dir / ".cobol_analyzer_init").exists()
    
    def get_local_paths(self, config_dir=None, data_dir=None, logs_dir=None):
        """Retorna os caminhos locais configurados"""
        return {
            'config_dir': config_dir or str(self.base_dir / "config"),
            'data_dir': data_dir or str(self.base_dir / "data"), 
            'logs_dir': logs_dir or str(self.base_dir / "logs"),
            'examples_dir': str(self.base_dir / "examples")
        }


def auto_setup_environment(config_dir=None, data_dir=None, logs_dir=None, force=False):
    """
    Função utilitária para configuração automática do ambiente
    
    Args:
        config_dir: Diretório personalizado para configurações
        data_dir: Diretório personalizado para dados RAG
        logs_dir: Diretório personalizado para logs
        force: Forçar reconfiguração mesmo se já inicializado
        
    Returns:
        dict: Informações sobre a configuração realizada
    """
    setup = LocalSetup()
    
    if not setup.is_initialized() or force:
        print(" Configurando ambiente local do COBOL Analyzer...")
        result = setup.setup_local_environment(config_dir, data_dir, logs_dir)
        
        print(" Ambiente configurado com sucesso!")
        print(f" Configurações: {result['config_dir']}")
        print(f" Dados RAG: {result['data_dir']}")
        print(f" Logs: {result['logs_dir']}")
        print(f" Exemplos: {result['examples_dir']}")
        
        if result['created_directories']:
            print(f" Diretórios criados: {len(result['created_directories'])}")
        
        return result
    else:
        print(" Ambiente já configurado.")
        return setup.get_local_paths(config_dir, data_dir, logs_dir)


if __name__ == "__main__":
    # Teste da configuração automática
    auto_setup_environment()
