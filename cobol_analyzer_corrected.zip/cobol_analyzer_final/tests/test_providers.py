"""
Testes unitários para os providers de IA
"""

import pytest
import os
from unittest.mock import Mock, patch

import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'cobol_to_docs', 'src'))

from cobol_to_docs.src.providers.enhanced_mock_provider import EnhancedMockProvider
from cobol_to_docs.src.providers.base_provider import AIRequest, AIResponse
from cobol_to_docs.src.providers.enhanced_provider_manager import EnhancedProviderManager


class TestEnhancedMockProvider:
    """Testes para o Enhanced Mock Provider"""
    
    def setup_method(self):
        """Setup para cada teste"""
        config = {
            'timeout': 5,
            'verify_ssl': False,
            'models': {
                'enhanced_mock': {
                    'name': 'enhanced-mock-gpt-4',
                    'max_tokens': 8192,
                    'temperature': 0.1
                }
            }
        }
        self.provider = EnhancedMockProvider(config)
    
    def test_provider_initialization(self):
        """Testa inicialização do provider"""
        assert self.provider is not None
        assert self.provider.name == "enhanced_mock"
    
    def test_analyze_request(self):
        """Testa análise com request"""
        request = AIRequest(
            prompt="Analise este código COBOL: DISPLAY 'HELLO'.",
            program_name="TEST",
            max_tokens=1000,
            temperature=0.1
        )
        
        response = self.provider.analyze(request)
        
        assert isinstance(response, AIResponse)
        assert response.success is True
        assert response.content is not None
        assert len(response.content) > 0
        assert response.tokens_used > 0
    
    def test_analyze_with_empty_prompt(self):
        """Testa análise com prompt vazio"""
        request = AIRequest(
            prompt="",
            program_name="TEST",
            max_tokens=1000,
            temperature=0.1
        )
        
        response = self.provider.analyze(request)
        
        # O mock provider deve lidar com prompts vazios
        assert isinstance(response, AIResponse)
    
    def test_analyze_cobol_method(self):
        """Testa método analyze com código COBOL"""
        cobol_code = """
        IDENTIFICATION DIVISION.
        PROGRAM-ID. TEST-PROGRAM.
        
        PROCEDURE DIVISION.
        DISPLAY 'HELLO WORLD'.
        STOP RUN.
        """
        
        request = AIRequest(
            prompt=f"Analise este programa COBOL:\n{cobol_code}",
            program_name="TEST-PROGRAM",
            program_code=cobol_code,
            max_tokens=1000,
            temperature=0.1
        )
        
        response = self.provider.analyze(request)
        
        assert isinstance(response, AIResponse)
        assert response.success is True
        assert response.content is not None


class TestEnhancedProviderManager:
    """Testes para o Enhanced Provider Manager"""
    
    def setup_method(self):
        """Setup para cada teste"""
        self.config = {
            'ai': {
                'primary_provider': 'enhanced_mock',
                'fallback_providers': ['basic']
            },
            'providers': {
                'enhanced_mock': {
                    'enabled': True,
                    'timeout': 5,
                    'models': {
                        'enhanced_mock': {
                            'name': 'enhanced-mock-gpt-4',
                            'max_tokens': 8192
                        }
                    }
                },
                'basic': {
                    'enabled': True,
                    'timeout': 1,
                    'models': {
                        'basic_fallback': {
                            'name': 'basic-fallback',
                            'max_tokens': 4096
                        }
                    }
                }
            }
        }
    
    def test_provider_manager_initialization(self):
        """Testa inicialização do provider manager"""
        manager = EnhancedProviderManager(self.config)
        assert manager is not None
        assert len(manager.providers) > 0
    
    def test_analyze_with_model(self):
        """Testa análise com modelo específico"""
        manager = EnhancedProviderManager(self.config)
        
        request = AIRequest(
            prompt="Teste de análise",
            program_name="TEST",
            max_tokens=1000
        )
        
        # Testar com modelo mock
        response = manager.analyze_with_model('enhanced-mock-gpt-4', request)
        
        assert isinstance(response, AIResponse)
    
    def test_get_available_models(self):
        """Testa obtenção de modelos disponíveis"""
        manager = EnhancedProviderManager(self.config)
        
        models = manager.get_available_models()
        
        assert isinstance(models, list)
        assert len(models) > 0
    
    def test_provider_fallback(self):
        """Testa fallback entre providers"""
        # Configurar um provider que falha
        config_with_failure = self.config.copy()
        config_with_failure['providers']['failing_provider'] = {
            'enabled': True,
            'timeout': 1,
            'models': {
                'failing_model': {
                    'name': 'failing-model',
                    'max_tokens': 1000
                }
            }
        }
        
        manager = EnhancedProviderManager(config_with_failure)
        
        request = AIRequest(
            prompt="Teste de fallback",
            program_name="TEST",
            max_tokens=1000
        )
        
        # Deve usar fallback se o provider principal falhar
        response = manager.analyze(request)
        assert isinstance(response, AIResponse)


if __name__ == '__main__':
    pytest.main([__file__])
