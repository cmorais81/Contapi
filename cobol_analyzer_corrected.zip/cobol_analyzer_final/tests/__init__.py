"""
Pacote de testes para COBOL Analyzer
"""
