# Changelog

Todas as mudanças notáveis neste projeto serão documentadas neste arquivo.

## [3.1.0] - 2025-01-09

### Reestruturação Completa do Projeto

#### Adicionado
- **Nova estrutura de diretórios**: Organização modular seguindo melhores práticas
- **Diretório `runner/`**: Scripts de execução centralizados
  - `main.py`: Script principal reestruturado
  - `cli.py`: Interface de linha de comando
  - `cobol_to_docs.py`: Ponto de entrada principal
- **Testes unitários**: Implementação completa com pytest
  - `tests/test_config.py`: Testes do sistema de configuração
  - `tests/test_cobol_parser.py`: Testes do parser COBOL
  - `tests/test_providers.py`: Testes dos provedores de IA
- **Configuração de testes**: `pytest.ini` para configuração padronizada
- **Documentação atualizada**: README.md completo com nova estrutura

#### Modificado
- **Estrutura `src/`**: Reorganização completa dos módulos
  - Mantida compatibilidade com todas as funcionalidades existentes
  - Melhor separação de responsabilidades
  - Imports atualizados para nova estrutura
- **`setup.py`**: Atualizado para nova estrutura de diretórios
- **`requirements.txt`**: Adicionadas dependências de teste e desenvolvimento
- **Configurações**: Mantidas todas as configurações existentes

#### Mantido
- **Funcionalidades completas**: Todas as funcionalidades do v3.1.0 original preservadas
- **Compatibilidade**: Mantida compatibilidade com comandos existentes
- **Provedores de IA**: Todos os provedores (Luzia, OpenAI, Bedrock, etc.) mantidos
- **Sistema RAG**: Funcionalidade RAG completamente preservada
- **Análises especializadas**: Todos os tipos de análise mantidos

### Estrutura de Diretórios

```
Antes (v3.1.0 original):
cobol_analyzer_final/
├── main.py
├── cli.py
├── src/
├── config/
├── data/
├── examples/
├── docs/
└── shell/

Depois (v3.1.0 reestruturado):
cobol_to_docs/
├── runner/          # Scripts de execução
├── src/             # Código fonte modularizado
├── tests/           # Testes unitários (NOVO)
├── config/          # Configurações
├── data/            # Dados e RAG
├── examples/        # Exemplos
├── docs/            # Documentação
├── shell/           # Scripts de instalação
├── setup.py         # Configuração atualizada
├── requirements.txt # Dependências atualizadas
├── pytest.ini      # Configuração de testes (NOVO)
└── README.md        # Documentação atualizada
```

### Pontos de Entrada

#### Mantidos
- `cobol-to-docs`: Comando principal (agora aponta para `runner/cobol_to_docs.py`)
- `cobol-analyzer`: Comando alternativo (agora aponta para `runner/cli.py`)

#### Novos
- `python runner/main.py`: Execução direta do script principal
- `pytest`: Execução dos testes unitários

### Compatibilidade

Esta reestruturação mantém **100% de compatibilidade** com:
- Todos os comandos existentes
- Todas as funcionalidades de análise
- Todos os provedores de IA configurados
- Sistema RAG e base de conhecimento
- Arquivos de configuração existentes
- Exemplos e documentação

### Melhorias

1. **Organização**: Estrutura mais clara e profissional
2. **Testabilidade**: Testes unitários implementados
3. **Manutenibilidade**: Código melhor organizado
4. **Documentação**: README atualizado e completo
5. **Desenvolvimento**: Configuração para desenvolvimento incluída

### Migração

Para migrar da versão anterior:

1. **Usuários finais**: Nenhuma ação necessária, todos os comandos funcionam igual
2. **Desenvolvedores**: Atualizar imports se modificando código interno
3. **Configurações**: Nenhuma mudança necessária nos arquivos de configuração

### Testes

Implementados testes unitários para:
- Sistema de configuração (`ConfigManager`)
- Parser COBOL (`COBOLParser`)
- Provedores de IA (`EnhancedMockProvider`, `EnhancedProviderManager`)

Executar testes:
```bash
pytest                    # Todos os testes
pytest tests/test_*.py   # Testes específicos
pytest --cov=src        # Com cobertura
```

---

## [3.1.0] - 2025-10-02 (Original)

### Funcionalidades Principais
- Sistema completo de análise COBOL com IA
- Múltiplos provedores (Luzia, OpenAI, Bedrock, GitHub Copilot)
- Sistema RAG para enriquecimento de análises
- Análise consolidada e comparativa
- Geração de documentação em múltiplos formatos
- Interface CLI e API programática
