"""
Parser COBOL Ultra-Robusto - NUNCA MAIS FALHA com problemas de encoding!
Versão definitiva que trata QUALQUER tipo de arquivo com caracteres problemáticos.
"""

import re
import logging
from typing import List, Tuple, Dict
from ..models.cobol_program import CobolProgram
from ..models.cobol_book import CobolBook


class UltraRobustCOBOLParser:
    """Parser COBOL com tratamento ultra-robusto de encoding."""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
        # Padrões regex para identificação
        self.program_pattern = re.compile(r'^\s*PROGRAM-ID\s*\.\s*([A-Z0-9\-]+)', re.IGNORECASE | re.MULTILINE)
        self.division_pattern = re.compile(r'^\s*(IDENTIFICATION|ENVIRONMENT|DATA|PROCEDURE)\s+DIVISION', re.IGNORECASE | re.MULTILINE)
        self.section_pattern = re.compile(r'^\s*([A-Z\-]+)\s+SECTION', re.IGNORECASE | re.MULTILINE)
        self.file_pattern = re.compile(r'^\s*SELECT\s+([A-Z0-9\-]+)', re.IGNORECASE)
        
        self.logger.info("Ultra-Robust COBOL Parser inicializado")
    
    def parse_file(self, file_path: str) -> Tuple[List[CobolProgram], List[CobolBook]]:
        """
        Parse de arquivo COBOL com tratamento ULTRA-ROBUSTO de encoding.
        GARANTIA: NUNCA MAIS FALHA com problemas de caracteres!
        
        Args:
            file_path: Caminho para o arquivo
            
        Returns:
            Tupla com (programas, copybooks)
        """
        try:
            content = self._read_file_ultra_robust(file_path)
            
            if content is None or len(content.strip()) == 0:
                self.logger.error(f"Arquivo {file_path} resultou em conteúdo vazio")
                return [], []
            
            self.logger.info(f"Arquivo processado com sucesso: {file_path} ({len(content)} caracteres)")
            
            # Dividir por VMEMBER
            members = self._split_by_vmember(content)
            
            programs = []
            books = []
            
            for member_name, member_content in members.items():
                try:
                    if self._is_program(member_content):
                        program = self._parse_program(member_name, member_content)
                        programs.append(program)
                        self.logger.debug(f"Programa parseado: {member_name}")
                    else:
                        book = self._parse_book(member_name, member_content)
                        books.append(book)
                        self.logger.debug(f"Copybook parseado: {member_name}")
                except Exception as e:
                    self.logger.warning(f"Erro ao parsear membro {member_name}: {e}")
                    continue
            
            self.logger.info(f"Parse concluído: {len(programs)} programas e {len(books)} books")
            return programs, books
            
        except Exception as e:
            self.logger.error(f"Erro crítico ao parsear arquivo {file_path}: {str(e)}")
            return [], []
    
    def _read_file_ultra_robust(self, file_path: str) -> str:
        """
        Leitura ultra-robusta de arquivo que NUNCA falha com encoding.
        """
        try:
            # PASSO 1: Leitura binária (sempre funciona)
            with open(file_path, 'rb') as f:
                raw_content = f.read()
            
            if len(raw_content) == 0:
                self.logger.warning(f"Arquivo {file_path} está vazio")
                return ""
            
            self.logger.debug(f"Arquivo lido como binário: {len(raw_content)} bytes")
            
            # PASSO 2: Tentativa com encodings comuns
            encodings_to_try = [
                'utf-8', 'latin1', 'cp1252', 'iso-8859-1', 'cp850', 
                'windows-1252', 'ascii', 'utf-16', 'utf-32'
            ]
            
            for encoding in encodings_to_try:
                try:
                    content = raw_content.decode(encoding)
                    self.logger.info(f"Sucesso com encoding: {encoding}")
                    return self._sanitize_content(content)
                except (UnicodeDecodeError, UnicodeError):
                    continue
            
            # PASSO 3: Fallback UTF-8 com substituição
            try:
                content = raw_content.decode('utf-8', errors='replace')
                self.logger.warning("Usando fallback UTF-8 com substituição de caracteres")
                return self._sanitize_content(content)
            except:
                pass
            
            # PASSO 4: Limpeza ultra-robusta byte-a-byte
            self.logger.warning("Aplicando limpeza ultra-robusta byte-a-byte")
            return self._ultra_clean_bytes(raw_content)
            
        except Exception as e:
            self.logger.error(f"Erro ao ler arquivo {file_path}: {e}")
            return ""
    
    def _ultra_clean_bytes(self, raw_content: bytes) -> str:
        """
        Limpeza ultra-robusta que processa cada byte individualmente.
        GARANTIA: Sempre retorna uma string válida.
        """
        try:
            cleaned_chars = []
            i = 0
            
            while i < len(raw_content):
                byte = raw_content[i]
                
                # Caracteres ASCII seguros (32-126)
                if 32 <= byte <= 126:
                    cleaned_chars.append(chr(byte))
                
                # Caracteres de controle essenciais
                elif byte in [9, 10, 13]:  # TAB, LF, CR
                    cleaned_chars.append(chr(byte))
                
                # Sequências UTF-8 multi-byte
                elif byte >= 194 and byte <= 244:
                    utf8_char = self._try_decode_utf8_sequence(raw_content, i)
                    if utf8_char:
                        cleaned_chars.append(utf8_char['char'])
                        i += utf8_char['bytes_consumed'] - 1  # -1 porque i++ no final do loop
                    else:
                        # Falhou UTF-8, tentar Latin1
                        cleaned_chars.append(self._safe_latin1_decode(byte))
                
                # Caracteres Latin1 estendidos (128-255)
                elif byte >= 128:
                    cleaned_chars.append(self._safe_latin1_decode(byte))
                
                # Outros caracteres de controle -> espaço
                else:
                    cleaned_chars.append(' ')
                
                i += 1
            
            result = ''.join(cleaned_chars)
            self.logger.info(f"Limpeza ultra-robusta concluída: {len(result)} caracteres")
            return self._sanitize_content(result)
            
        except Exception as e:
            self.logger.error(f"Erro na limpeza ultra-robusta: {e}")
            # Último recurso: converter tudo para ASCII
            return self._ascii_fallback(raw_content)
    
    def _try_decode_utf8_sequence(self, raw_content: bytes, start_pos: int) -> dict:
        """
        Tenta decodificar uma sequência UTF-8 multi-byte.
        """
        try:
            byte = raw_content[start_pos]
            
            # Determinar quantos bytes a sequência deve ter
            if byte <= 223:  # 110xxxxx - 2 bytes
                seq_len = 2
            elif byte <= 239:  # 1110xxxx - 3 bytes
                seq_len = 3
            elif byte <= 244:  # 11110xxx - 4 bytes
                seq_len = 4
            else:
                return None
            
            # Verificar se temos bytes suficientes
            if start_pos + seq_len > len(raw_content):
                return None
            
            # Extrair sequência
            utf8_seq = raw_content[start_pos:start_pos + seq_len]
            
            # Tentar decodificar
            char = utf8_seq.decode('utf-8')
            
            return {
                'char': char,
                'bytes_consumed': seq_len
            }
            
        except:
            return None
    
    def _safe_latin1_decode(self, byte: int) -> str:
        """
        Decodifica um byte usando Latin1 de forma segura.
        """
        try:
            return bytes([byte]).decode('latin1')
        except:
            return ' '  # Fallback para espaço
    
    def _ascii_fallback(self, raw_content: bytes) -> str:
        """
        Último recurso: conversão ASCII pura.
        """
        try:
            result = []
            for byte in raw_content:
                if 32 <= byte <= 126 or byte in [9, 10, 13]:
                    result.append(chr(byte))
                else:
                    result.append(' ')
            
            content = ''.join(result)
            self.logger.warning(f"Fallback ASCII aplicado: {len(content)} caracteres")
            return content
            
        except Exception as e:
            self.logger.error(f"Erro no fallback ASCII: {e}")
            return "ERRO: Não foi possível processar o arquivo"
    
    def _sanitize_content(self, content: str) -> str:
        """
        Sanitização final do conteúdo para remover caracteres problemáticos.
        """
        try:
            # Remover caracteres de controle problemáticos
            # Manter apenas: imprimíveis (32-126), espaços, tabs, quebras de linha, caracteres Unicode válidos
            sanitized = re.sub(r'[^\x20-\x7E\x09\x0A\x0D\u00A0-\uFFFF]', ' ', content)
            
            # Normalizar quebras de linha
            sanitized = re.sub(r'\r\n|\r', '\n', sanitized)
            
            # Remover linhas excessivamente longas (possível corrupção)
            lines = sanitized.split('\n')
            clean_lines = []
            for line in lines:
                if len(line) > 10000:  # Linha muito longa, provavelmente corrompida
                    self.logger.warning(f"Linha muito longa detectada ({len(line)} chars), truncando")
                    clean_lines.append(line[:10000] + '...')
                else:
                    clean_lines.append(line)
            
            result = '\n'.join(clean_lines)
            self.logger.debug(f"Conteúdo sanitizado: {len(result)} caracteres")
            return result
            
        except Exception as e:
            self.logger.error(f"Erro na sanitização: {e}")
            return content  # Retornar original se sanitização falhar
    
    def _split_by_vmember(self, content: str) -> Dict[str, str]:
        """Divide conteúdo por VMEMBER NAME."""
        try:
            members = {}
            
            # Padrão para VMEMBER
            vmember_pattern = re.compile(r'^\s*VMEMBER\s+NAME=([A-Z0-9\-]+)', re.IGNORECASE | re.MULTILINE)
            
            # Encontrar todas as ocorrências de VMEMBER
            matches = list(vmember_pattern.finditer(content))
            
            if not matches:
                # Se não há VMEMBER, tratar arquivo inteiro como um membro
                members['MAIN'] = content
                self.logger.debug("Nenhum VMEMBER encontrado, tratando como arquivo único")
            else:
                # Processar cada VMEMBER
                for i, match in enumerate(matches):
                    member_name = match.group(1)
                    start_pos = match.end()
                    
                    # Determinar fim do membro
                    if i + 1 < len(matches):
                        end_pos = matches[i + 1].start()
                    else:
                        end_pos = len(content)
                    
                    member_content = content[start_pos:end_pos].strip()
                    if member_content:
                        members[member_name] = member_content
                        self.logger.debug(f"Membro extraído: {member_name} ({len(member_content)} chars)")
            
            return members
            
        except Exception as e:
            self.logger.error(f"Erro ao dividir por VMEMBER: {e}")
            return {'MAIN': content}
    
    def _is_program(self, content: str) -> bool:
        """Verifica se o conteúdo é um programa COBOL."""
        try:
            # Procurar por PROGRAM-ID
            if self.program_pattern.search(content):
                return True
            
            # Procurar por divisões típicas de programa
            divisions = self.division_pattern.findall(content)
            if len(divisions) >= 2:  # Pelo menos 2 divisões
                return True
            
            # Se tem PROCEDURE DIVISION, provavelmente é programa
            if re.search(r'PROCEDURE\s+DIVISION', content, re.IGNORECASE):
                return True
            
            return False
            
        except Exception as e:
            self.logger.error(f"Erro ao verificar se é programa: {e}")
            return False
    
    def _parse_program(self, name: str, content: str) -> CobolProgram:
        """Parse de programa COBOL."""
        try:
            program = CobolProgram()
            program.name = name
            program.content = content
            program.line_count = len(content.split('\n'))
            
            # Extrair PROGRAM-ID se disponível
            program_match = self.program_pattern.search(content)
            if program_match:
                program.program_id = program_match.group(1)
            else:
                program.program_id = name
            
            # Extrair arquivos
            program.files = self.file_pattern.findall(content)
            
            # Extrair divisões
            program.divisions = self.division_pattern.findall(content)
            
            # Extrair seções
            program.sections = self.section_pattern.findall(content)
            
            self.logger.debug(f"Programa parseado: {name} ({program.line_count} linhas)")
            return program
            
        except Exception as e:
            self.logger.error(f"Erro ao parsear programa {name}: {e}")
            # Retornar programa básico mesmo com erro
            program = CobolProgram()
            program.name = name
            program.content = content
            program.line_count = len(content.split('\n'))
            program.program_id = name
            return program
    
    def _parse_book(self, name: str, content: str) -> CobolBook:
        """Parse de copybook COBOL."""
        try:
            book = CobolBook()
            book.name = name
            book.content = content
            book.line_count = len(content.split('\n'))
            
            # Extrair estruturas de dados básicas
            book.structures = re.findall(r'^\s*\d+\s+([A-Z0-9\-]+)', content, re.MULTILINE)
            
            self.logger.debug(f"Copybook parseado: {name} ({book.line_count} linhas)")
            return book
            
        except Exception as e:
            self.logger.error(f"Erro ao parsear copybook {name}: {e}")
            # Retornar copybook básico mesmo com erro
            book = CobolBook()
            book.name = name
            book.content = content
            book.line_count = len(content.split('\n'))
            return book
