#!/usr/bin/env python3
"""
COBOL to Docs - Script principal de análise
Ferramenta de análise de código COBOL com IA
"""

import sys
import os
import argparse
import json
import logging
from pathlib import Path
from datetime import datetime
import time

# Configurar logging básico
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)

# Adicionar diretório do projeto ao path
script_dir = os.path.dirname(os.path.abspath(__file__))
cobol_to_docs_dir = os.path.dirname(script_dir)
project_root = os.path.dirname(cobol_to_docs_dir)
src_dir = os.path.join(cobol_to_docs_dir, 'src')
sys.path.insert(0, project_root)
sys.path.insert(0, cobol_to_docs_dir)
sys.path.insert(0, src_dir)

# Imports diretos do código fonte
try:
    from src.core.config import ConfigManager
    from src.core.prompt_manager_dual import DualPromptManager
    from src.providers.enhanced_provider_manager import EnhancedProviderManager
    from src.parsers.cobol_parser_original import COBOLParser, CobolProgram, CobolBook
    from src.analyzers.enhanced_cobol_analyzer import EnhancedCOBOLAnalyzer
    from src.analyzers.consolidated_analyzer import ConsolidatedAnalyzer
    from src.generators.documentation_generator import DocumentationGenerator
    from src.utils.cost_calculator import CostCalculator
    from src.utils.html_generator import HTMLReportGenerator
    from src.rag.cobol_rag_system import CobolRAGSystem
    from src.core.main_processor import MainProcessor
except ImportError as e:
    logger.error(f"Erro ao importar módulos: {e}")
    logger.error("Certifique-se de que o COBOL Analyzer está instalado corretamente")
    sys.exit(1)

def setup_directories():
    """Cria diretórios necessários se não existirem"""
    directories = ['logs', 'output', 'temp']
    for directory in directories:
        Path(directory).mkdir(exist_ok=True)

def parse_models_argument(models_str):
    """Parse do argumento models que pode ser string ou JSON array"""
    if not models_str:
        return ["enhanced_mock"]
    
    # Tentar parsear como JSON array
    try:
        models = json.loads(models_str)
        if isinstance(models, list):
            return models
    except json.JSONDecodeError:
        pass
    
    # Se não for JSON, tratar como string única ou lista separada por vírgula
    if ',' in models_str:
        return [model.strip() for model in models_str.split(',')]
    else:
        return [models_str.strip()]

def main():
    """Função principal"""
    parser = argparse.ArgumentParser(
        description="COBOL to Docs v3.1.0 - Análise automatizada de código COBOL",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Exemplos de uso:
  python main.py --fontes programas.txt --models luzia
  python main.py --fontes programas.txt --books copybooks.txt --models enhanced_mock
  python main.py --fontes programas.txt --consolidado --models luzia
  python main.py --status
        """
    )
    
    # Argumentos principais
    parser.add_argument("--fontes", type=str,
                       help="Arquivo com lista de programas COBOL ou código COBOL direto")
    parser.add_argument("--books", type=str,
                       help="Arquivo com lista de copybooks")
    parser.add_argument("--models", type=str,
                       help="Modelo(s) de IA a usar (string ou JSON array)")
    parser.add_argument("--output", type=str, default="output",
                       help="Diretório de saída (padrão: output)")
    
    # Opções de análise
    parser.add_argument("--consolidado", action="store_true",
                       help="Análise consolidada sistêmica")
    parser.add_argument("--relatorio-unico", action="store_true",
                       help="Relatório único consolidado")
    parser.add_argument("--analise-especialista", action="store_true",
                       help="Análise especializada")
    parser.add_argument("--procedure-detalhada", action="store_true",
                       help="Análise detalhada da PROCEDURE DIVISION")
    parser.add_argument("--modernizacao", action="store_true",
                       help="Análise para modernização")
    
    # Opções de configuração
    parser.add_argument("--prompt-set", type=str,
                       help="Conjunto de prompts a usar")
    parser.add_argument("--no-comments", action="store_true",
                       help="Remover comentários do código")
    parser.add_argument("--pdf", action="store_true",
                       help="Gerar relatórios HTML/PDF")
    parser.add_argument("--log-level", type=str, default="INFO",
                       help="Nível de logging")
    
    # Comandos utilitários
    parser.add_argument("--status", action="store_true",
                       help="Verificar status do sistema")
    
    args = parser.parse_args()
    
    # Configurar nível de logging
    if args.log_level:
        level = getattr(logging, args.log_level.upper(), logging.INFO)
        logging.getLogger().setLevel(level)
    
    # Criar diretórios necessários
    setup_directories()
    
    try:
        # Inicializar configuração
        # Verificar se existe config local primeiro
        local_config_path = "config/config.yaml"
        if os.path.exists(local_config_path):
            config_manager = ConfigManager(local_config_path)
            logger.info(f"Usando configuração local: {local_config_path}")
        else:
            config_manager = ConfigManager()
            logger.warning(f"Configuração local não encontrada em {local_config_path}, usando padrão")
        
        # Comando de status
        if args.status:
            print("=== STATUS DO SISTEMA COBOL ANALYZER ===")
            
            # Verificar providers disponíveis
            try:
                provider_manager = EnhancedProviderManager(config_manager)
                providers = ["luzia", "openai", "github_copilot", "enhanced_mock", "bedrock", "gemini", "claude"]
                print(f"Providers configurados: {len(providers)}")
                for provider in providers:
                    print(f"  - {provider}")
            except Exception as e:
                print(f"Providers: Erro ao verificar - {e}")
            
            # Verificar sistema RAG
            try:
                print("Sistema RAG: Disponível")
            except Exception as e:
                print(f"Sistema RAG: Erro - {e}")
            
            # Verificar diretórios
            for directory in ['logs', 'output', 'temp', 'config', 'data']:
                if Path(directory).exists():
                    print(f"Diretório {directory}: OK")
                else:
                    print(f"Diretório {directory}: Não encontrado")
            
            print("Sistema pronto para uso!")
            return 0
        
        # Verificar argumentos obrigatórios para análise
        if not args.fontes:
            print("Erro: Argumento --fontes é obrigatório para análise")
            print("Use --status para verificar o sistema ou --help para ajuda")
            return 1
        
        # Parse dos modelos
        models = parse_models_argument(args.models)
        
        # Configurar processador principal
        processor = MainProcessor(
            config_manager=config_manager,
            output_dir=args.output
        )
        
        # Executar análise
        start_time = time.time()
        
        if args.consolidado:
            print("Análise consolidada não implementada ainda")
            return 1
        else:
            # Análise padrão
            success = processor.process_programs(
                fontes_file=args.fontes,
                books_file=args.books,
                models=models,
                remove_comments=args.no_comments,
                prompt_set=args.prompt_set
            )
            
            # Gerar relatórios HTML/PDF se solicitado
            if args.pdf and success:
                try:
                    html_generator = HTMLReportGenerator()
                    html_files = html_generator.generate_html_reports(args.output)
                    if html_files:
                        print(f"Relatórios HTML gerados: {len(html_files)} arquivos")
                        for html_file in html_files:
                            print(f"  - {html_file}")
                    else:
                        print("Nenhum relatório HTML foi gerado")
                except Exception as e:
                    logger.error(f"Erro ao gerar relatórios HTML: {e}")
                    print(f"Erro ao gerar relatórios HTML: {e}")
        
        end_time = time.time()
        
        if success:
            print(f"Tempo total de processamento: {end_time - start_time:.2f}s")
            print(f"Documentação gerada em: {args.output}")
            return 0
        else:
            print("Erro durante o processamento")
            return 1
            
    except KeyboardInterrupt:
        print("\nProcessamento interrompido pelo usuário")
        return 1
    except Exception as e:
        logger.error(f"Erro inesperado: {e}")
        return 1

if __name__ == "__main__":
    sys.exit(main())
