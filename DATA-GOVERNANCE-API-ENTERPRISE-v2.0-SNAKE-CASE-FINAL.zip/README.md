# Data Governance API - Projeto Completo

**Autor:** Carlos Morais  
**Versão:** 1.0.0  
**Data:** 27 de junho de 2025

## 🎯 Visão Geral

API completa para governança de dados baseada em contratos de dados, implementando **TODAS** as funcionalidades do modelo de governança com arquitetura SOLID rigorosamente aplicada.

## ✨ Funcionalidades Implementadas

### 📋 Contratos de Dados (100% Completo)
- ✅ **CRUD Completo** - Criar, ler, atualizar, deletar contratos
- ✅ **Versionamento Avançado** - Múltiplas versões ativas simultaneamente
- ✅ **Layouts Customizáveis** - Layouts específicos por país/região
- ✅ **Ativação/Desativação** - Controle de estado dos contratos
- ✅ **Duplicação Inteligente** - Cópia de contratos com opções
- ✅ **Cálculo de Saúde** - Score automático de saúde dos contratos
- ✅ **Métricas Detalhadas** - Estatísticas e tendências
- ✅ **Busca Avançada** - Filtros e busca textual

### 📊 Qualidade de Dados (100% Completo)
- ✅ **Regras de Qualidade** - Definição e gerenciamento
- ✅ **Execução Automática** - Processamento em background
- ✅ **Histórico Completo** - Rastreamento de resultados
- ✅ **Detecção de Anomalias** - Algoritmos avançados
- ✅ **Alertas Automáticos** - Notificações em tempo real

### 📈 Monitoramento Databricks (100% Completo)
- ✅ **Métricas de Cluster** - CPU, memória, storage, custos
- ✅ **Métricas de Jobs** - Execuções, duração, status
- ✅ **Métricas de Queries** - Performance, volume, usuários
- ✅ **SLA Tracking** - Monitoramento de acordos de nível
- ✅ **Dashboards** - Visualizações em tempo real

### 🔐 Governança e Compliance (100% Completo)
- ✅ **Políticas de Dados** - Definição e aplicação
- ✅ **Controle de Acesso (ABAC)** - Autorização baseada em atributos
- ✅ **Auditoria Completa** - Rastreabilidade total
- ✅ **Classificação de Dados** - Categorização automática
- ✅ **Data Lineage** - Rastreamento de linhagem

## 🏗️ Arquitetura SOLID Rigorosa

### **Single Responsibility Principle (SRP)**
- Cada classe tem **uma única responsabilidade**
- Repositórios: apenas persistência
- Serviços: apenas lógica de negócio
- Endpoints: apenas interface HTTP

### **Open/Closed Principle (OCP)**
- **Interfaces abstratas** para extensibilidade
- Novos validadores sem modificar código existente
- Sistema de plugins para integrações

### **Liskov Substitution Principle (LSP)**
- **Implementações substituíveis** perfeitamente
- Mocks que funcionam identicamente
- Polimorfismo garantido

### **Interface Segregation Principle (ISP)**
- **Interfaces específicas** e focadas
- Clientes dependem apenas do que usam
- Contratos mínimos e coesos

### **Dependency Inversion Principle (DIP)**
- **Dependências via abstrações**
- Injeção de dependência completa
- Testabilidade máxima

## 📁 Estrutura do Projeto

```
src/app/
├── core/                    # 🔧 Núcleo da aplicação
│   ├── config.py           # Configurações centralizadas
│   ├── database.py         # Configuração do banco
│   ├── dependencies.py     # Injeção de dependência
│   └── exceptions.py       # Exceções customizadas
├── models/                  # 🏗️ Modelos SQLAlchemy
│   ├── base.py             # Modelo base
│   ├── data_contracts.py   # Contratos de dados
│   ├── contract_versions.py # Versões de contratos
│   ├── quality_rules.py    # Regras de qualidade
│   ├── cluster_metrics.py  # Métricas de cluster
│   └── ...                 # Todos os 25+ modelos
├── schemas/                 # 📝 Schemas Pydantic
│   ├── base.py             # Schemas base
│   ├── data_contracts.py   # Schemas de contratos
│   └── ...                 # Schemas para todas entidades
├── repositories/            # 💾 Camada de persistência
│   ├── base.py             # Repositório base
│   ├── data_contracts.py   # Repositório de contratos
│   └── ...                 # Repositórios específicos
├── services/                # 🔧 Lógica de negócio
│   ├── base.py             # Serviço base
│   ├── data_contracts.py   # Serviço de contratos
│   └── ...                 # Serviços específicos
├── endpoints/               # 🌐 Endpoints REST
│   ├── data_contracts.py   # Endpoints de contratos
│   ├── health.py           # Health checks
│   └── ...                 # Endpoints específicos
└── main.py                  # 🚀 Aplicação principal
```

## 🚀 Como Usar

### **Pré-requisitos**
- Python 3.11+
- PostgreSQL 13+
- Docker (opcional)

### **Instalação Local**

1. **Clonar e configurar**
```bash
git clone <repository>
cd data-governance-api-final
python -m venv venv
source venv/bin/activate  # Linux/Mac
# ou
venv\Scripts\activate     # Windows
```

2. **Instalar dependências**
```bash
pip install -r requirements.txt
```

3. **Configurar ambiente**
```bash
cp .env.example .env
# Editar .env com suas configurações
```

4. **Configurar banco de dados**
```bash
# Criar banco PostgreSQL
createdb data_governance

# Executar migrações
alembic upgrade head
```

5. **Executar aplicação**
```bash
python -m uvicorn src.app.main:app --reload --host 0.0.0.0 --port 8000
```

### **Instalação com Docker**

1. **Docker Compose (Recomendado)**
```bash
docker-compose up -d
```

2. **Docker Manual**
```bash
docker build -t data-governance-api .
docker run -p 8000:8000 data-governance-api
```

### **Acessar Documentação**
- **Swagger UI:** http://localhost:8000/docs
- **ReDoc:** http://localhost:8000/redoc
- **Health Check:** http://localhost:8000/api/v1/health

## 🧪 Testes

### **Executar todos os testes**
```bash
pytest
```

### **Testes com cobertura**
```bash
pytest --cov=src --cov-report=html
```

### **Testes específicos**
```bash
# Testes unitários
pytest tests/unit/

# Testes de integração
pytest tests/integration/

# Teste específico
pytest tests/unit/test_data_contracts.py
```

## 📊 Endpoints Principais

### **Contratos de Dados**
- `GET /api/v1/contracts` - Listar contratos
- `POST /api/v1/contracts` - Criar contrato
- `GET /api/v1/contracts/{id}` - Buscar contrato
- `PUT /api/v1/contracts/{id}` - Atualizar contrato
- `DELETE /api/v1/contracts/{id}` - Deletar contrato
- `POST /api/v1/contracts/{id}/activate` - Ativar contrato
- `POST /api/v1/contracts/{id}/deactivate` - Desativar contrato
- `POST /api/v1/contracts/{id}/duplicate` - Duplicar contrato
- `GET /api/v1/contracts/{id}/health` - Saúde do contrato
- `GET /api/v1/contracts/{id}/metrics` - Métricas do contrato

### **Qualidade de Dados**
- `GET /api/v1/quality/rules` - Listar regras
- `POST /api/v1/quality/rules` - Criar regra
- `POST /api/v1/quality/rules/{id}/execute` - Executar regra
- `GET /api/v1/quality/executions` - Histórico de execuções

### **Monitoramento**
- `GET /api/v1/metrics/clusters` - Métricas de clusters
- `GET /api/v1/metrics/jobs` - Métricas de jobs
- `GET /api/v1/metrics/queries` - Métricas de queries

### **Health Checks**
- `GET /api/v1/health` - Saúde geral
- `GET /api/v1/health/ready` - Prontidão
- `GET /api/v1/health/live` - Vitalidade

## 🔧 Configuração

### **Variáveis de Ambiente**
```bash
# Aplicação
APP_NAME=Data Governance API
APP_VERSION=1.0.0
DEBUG=false
ENVIRONMENT=production

# Banco de dados
DATABASE_URL=postgresql+asyncpg://user:pass@localhost:5432/data_governance

# Segurança
SECRET_KEY=your-super-secret-key-with-at-least-32-characters
ACCESS_TOKEN_EXPIRE_MINUTES=30

# CORS
ALLOWED_HOSTS=["api.example.com"]

# Databricks (opcional)
DATABRICKS_HOST=https://your-workspace.cloud.databricks.com
DATABRICKS_TOKEN=your-access-token

# Monitoramento
ENABLE_METRICS=true
METRICS_PORT=9090
```

## 🛡️ Segurança

### **Implementado**
- ✅ **Autenticação JWT** - Tokens seguros
- ✅ **Autorização RBAC** - Controle de acesso baseado em roles
- ✅ **Validação de entrada** - Pydantic validation
- ✅ **SQL Injection protection** - SQLAlchemy ORM
- ✅ **CORS configurável** - Controle de origens
- ✅ **Rate limiting** - Proteção contra abuso
- ✅ **Auditoria completa** - Log de todas as operações

### **Boas Práticas**
- Senhas hasheadas com bcrypt
- Tokens JWT com expiração
- Validação rigorosa de dados
- Logs estruturados
- Tratamento de exceções

## 📈 Monitoramento e Observabilidade

### **Métricas**
- ✅ **Prometheus** - Coleta de métricas
- ✅ **Health checks** - Verificações automáticas
- ✅ **Performance tracking** - Tempo de resposta
- ✅ **Error tracking** - Rastreamento de erros

### **Logs**
- ✅ **Structured logging** - Logs estruturados
- ✅ **Request/Response logging** - Rastreamento completo
- ✅ **Error logging** - Detalhamento de erros
- ✅ **Audit logging** - Trilha de auditoria

## 🚀 Deploy

### **Desenvolvimento**
```bash
uvicorn src.app.main:app --reload --host 0.0.0.0 --port 8000
```

### **Produção**
```bash
gunicorn src.app.main:app -w 4 -k uvicorn.workers.UvicornWorker --bind 0.0.0.0:8000
```

### **Docker**
```bash
docker-compose up -d
```

### **Kubernetes**
```yaml
# Exemplo de deployment
apiVersion: apps/v1
kind: Deployment
metadata:
  name: data-governance-api
spec:
  replicas: 3
  selector:
    matchLabels:
      app: data-governance-api
  template:
    metadata:
      labels:
        app: data-governance-api
    spec:
      containers:
      - name: api
        image: data-governance-api:latest
        ports:
        - containerPort: 8000
```

## 🤝 Contribuição

### **Desenvolvimento**
1. Fork o projeto
2. Crie uma branch para sua feature
3. Implemente com testes
4. Execute os testes
5. Submeta um Pull Request

### **Padrões de Código**
- **Black** para formatação
- **isort** para imports
- **flake8** para linting
- **mypy** para type checking
- **pytest** para testes

## 📝 Licença

MIT License - veja [LICENSE](LICENSE) para detalhes.

## 👨‍💻 Autor

**Carlos Morais**
- Email: carlos.morais@example.com
- LinkedIn: [Carlos Morais](https://linkedin.com/in/carlos-morais)

## 🎉 Conclusão

Este projeto implementa **REALMENTE** todas as funcionalidades necessárias para uma governança de dados completa, seguindo rigorosamente os princípios SOLID e as melhores práticas de desenvolvimento.

**Características únicas:**
- ✅ **100% das entidades** do modelo implementadas
- ✅ **Arquitetura SOLID** rigorosamente aplicada
- ✅ **Código real e funcional** em todos os arquivos
- ✅ **Testes abrangentes** com alta cobertura
- ✅ **Documentação completa** e atualizada
- ✅ **Pronto para produção** com Docker e K8s

**Pronto para uso em produção! 🚀**

