"""
Utilitários de Segurança para Data Governance API
Autor: Carlos Morais

Módulo com funções de segurança, criptografia, autenticação
e autorização para proteção de dados sensíveis.
"""

import hashlib
import secrets
import base64
import hmac
import jwt
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Union
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
import bcrypt
import re

from .exceptions import SecurityError, AuthenticationError, AuthorizationError


class PasswordManager:
    """Gerenciador de senhas com hash seguro"""
    
    @staticmethod
    def hash_password(password: str) -> str:
        """
        Gera hash seguro da senha
        
        Args:
            password: Senha em texto plano
            
        Returns:
            Hash da senha
        """
        salt = bcrypt.gensalt()
        hashed = bcrypt.hashpw(password.encode('utf-8'), salt)
        return hashed.decode('utf-8')
    
    @staticmethod
    def verify_password(password: str, hashed: str) -> bool:
        """
        Verifica senha contra hash
        
        Args:
            password: Senha em texto plano
            hashed: Hash armazenado
            
        Returns:
            True se senha correta
        """
        try:
            return bcrypt.checkpw(password.encode('utf-8'), hashed.encode('utf-8'))
        except Exception:
            return False
    
    @staticmethod
    def generate_password(length: int = 12) -> str:
        """
        Gera senha aleatória segura
        
        Args:
            length: Comprimento da senha
            
        Returns:
            Senha gerada
        """
        alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*"
        password = ''.join(secrets.choice(alphabet) for _ in range(length))
        
        # Garantir que tem pelo menos um de cada tipo
        if not re.search(r'[a-z]', password):
            password = password[:-1] + secrets.choice('abcdefghijklmnopqrstuvwxyz')
        if not re.search(r'[A-Z]', password):
            password = password[:-1] + secrets.choice('ABCDEFGHIJKLMNOPQRSTUVWXYZ')
        if not re.search(r'\d', password):
            password = password[:-1] + secrets.choice('0123456789')
        if not re.search(r'[!@#$%^&*]', password):
            password = password[:-1] + secrets.choice('!@#$%^&*')
        
        return password


class TokenManager:
    """Gerenciador de tokens JWT"""
    
    def __init__(self, secret_key: str, algorithm: str = "HS256"):
        self.secret_key = secret_key
        self.algorithm = algorithm
    
    def generate_token(self, payload: Dict[str, Any], expires_in: int = 3600) -> str:
        """
        Gera token JWT
        
        Args:
            payload: Dados para incluir no token
            expires_in: Tempo de expiração em segundos
            
        Returns:
            Token JWT
        """
        now = datetime.utcnow()
        payload.update({
            'iat': now,
            'exp': now + timedelta(seconds=expires_in),
            'jti': secrets.token_urlsafe(16)  # JWT ID único
        })
        
        return jwt.encode(payload, self.secret_key, algorithm=self.algorithm)
    
    def verify_token(self, token: str) -> Dict[str, Any]:
        """
        Verifica e decodifica token JWT
        
        Args:
            token: Token para verificar
            
        Returns:
            Payload decodificado
            
        Raises:
            AuthenticationError: Se token inválido
        """
        try:
            payload = jwt.decode(token, self.secret_key, algorithms=[self.algorithm])
            return payload
        except jwt.ExpiredSignatureError:
            raise AuthenticationError("Token expirado")
        except jwt.InvalidTokenError:
            raise AuthenticationError("Token inválido")
    
    def refresh_token(self, token: str, expires_in: int = 3600) -> str:
        """
        Renova token JWT
        
        Args:
            token: Token atual
            expires_in: Novo tempo de expiração
            
        Returns:
            Novo token
        """
        payload = self.verify_token(token)
        
        # Remove campos de controle
        payload.pop('iat', None)
        payload.pop('exp', None)
        payload.pop('jti', None)
        
        return self.generate_token(payload, expires_in)


class DataEncryption:
    """Criptografia de dados sensíveis"""
    
    def __init__(self, key: Optional[bytes] = None):
        if key is None:
            key = Fernet.generate_key()
        self.cipher = Fernet(key)
        self.key = key
    
    @classmethod
    def from_password(cls, password: str, salt: Optional[bytes] = None):
        """
        Cria instância a partir de senha
        
        Args:
            password: Senha para derivar chave
            salt: Salt para derivação (gerado se None)
            
        Returns:
            Instância de DataEncryption
        """
        if salt is None:
            salt = secrets.token_bytes(16)
        
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100000,
        )
        key = base64.urlsafe_b64encode(kdf.derive(password.encode()))
        
        instance = cls(key)
        instance.salt = salt
        return instance
    
    def encrypt(self, data: Union[str, bytes]) -> bytes:
        """
        Criptografa dados
        
        Args:
            data: Dados para criptografar
            
        Returns:
            Dados criptografados
        """
        if isinstance(data, str):
            data = data.encode('utf-8')
        
        return self.cipher.encrypt(data)
    
    def decrypt(self, encrypted_data: bytes) -> str:
        """
        Descriptografa dados
        
        Args:
            encrypted_data: Dados criptografados
            
        Returns:
            Dados descriptografados
        """
        try:
            decrypted = self.cipher.decrypt(encrypted_data)
            return decrypted.decode('utf-8')
        except Exception as e:
            raise SecurityError("Falha na descriptografia", str(e))
    
    def encrypt_dict(self, data: Dict[str, Any], fields_to_encrypt: List[str]) -> Dict[str, Any]:
        """
        Criptografa campos específicos de um dicionário
        
        Args:
            data: Dicionário com dados
            fields_to_encrypt: Lista de campos para criptografar
            
        Returns:
            Dicionário com campos criptografados
        """
        encrypted_data = data.copy()
        
        for field in fields_to_encrypt:
            if field in encrypted_data and encrypted_data[field] is not None:
                encrypted_value = self.encrypt(str(encrypted_data[field]))
                encrypted_data[field] = base64.b64encode(encrypted_value).decode('utf-8')
        
        return encrypted_data
    
    def decrypt_dict(self, data: Dict[str, Any], fields_to_decrypt: List[str]) -> Dict[str, Any]:
        """
        Descriptografa campos específicos de um dicionário
        
        Args:
            data: Dicionário com dados criptografados
            fields_to_decrypt: Lista de campos para descriptografar
            
        Returns:
            Dicionário com campos descriptografados
        """
        decrypted_data = data.copy()
        
        for field in fields_to_decrypt:
            if field in decrypted_data and decrypted_data[field] is not None:
                try:
                    encrypted_value = base64.b64decode(decrypted_data[field])
                    decrypted_data[field] = self.decrypt(encrypted_value)
                except Exception:
                    # Se falhar na descriptografia, mantém valor original
                    pass
        
        return decrypted_data


class DataMasking:
    """Mascaramento de dados sensíveis"""
    
    @staticmethod
    def mask_email(email: str) -> str:
        """
        Mascara email preservando formato
        
        Args:
            email: Email para mascarar
            
        Returns:
            Email mascarado
        """
        if '@' not in email:
            return email
        
        local, domain = email.split('@', 1)
        
        if len(local) <= 2:
            masked_local = '*' * len(local)
        else:
            masked_local = local[0] + '*' * (len(local) - 2) + local[-1]
        
        return f"{masked_local}@{domain}"
    
    @staticmethod
    def mask_phone(phone: str) -> str:
        """
        Mascara telefone
        
        Args:
            phone: Telefone para mascarar
            
        Returns:
            Telefone mascarado
        """
        digits_only = re.sub(r'\D', '', phone)
        
        if len(digits_only) >= 10:
            return f"({digits_only[:2]}) *****-{digits_only[-4:]}"
        else:
            return '*' * len(phone)
    
    @staticmethod
    def mask_cpf(cpf: str) -> str:
        """
        Mascara CPF
        
        Args:
            cpf: CPF para mascarar
            
        Returns:
            CPF mascarado
        """
        digits_only = re.sub(r'\D', '', cpf)
        
        if len(digits_only) == 11:
            return f"***.***.***-{digits_only[-2:]}"
        else:
            return '*' * len(cpf)
    
    @staticmethod
    def mask_credit_card(card: str) -> str:
        """
        Mascara cartão de crédito
        
        Args:
            card: Número do cartão
            
        Returns:
            Cartão mascarado
        """
        digits_only = re.sub(r'\D', '', card)
        
        if len(digits_only) >= 12:
            return f"****-****-****-{digits_only[-4:]}"
        else:
            return '*' * len(card)
    
    @staticmethod
    def mask_custom(value: str, pattern: str) -> str:
        """
        Mascara valor com padrão customizado
        
        Args:
            value: Valor para mascarar
            pattern: Padrão de mascaramento (X = manter, * = mascarar)
            
        Returns:
            Valor mascarado
        """
        if len(pattern) != len(value):
            return '*' * len(value)
        
        masked = ''
        for i, char in enumerate(value):
            if pattern[i] == 'X':
                masked += char
            else:
                masked += '*'
        
        return masked


class AccessControl:
    """Controle de acesso e autorização"""
    
    @staticmethod
    def check_permission(user_permissions: List[str], required_permission: str) -> bool:
        """
        Verifica se usuário tem permissão
        
        Args:
            user_permissions: Permissões do usuário
            required_permission: Permissão necessária
            
        Returns:
            True se tem permissão
        """
        # Verifica permissão exata
        if required_permission in user_permissions:
            return True
        
        # Verifica permissões wildcard
        for permission in user_permissions:
            if permission.endswith('*'):
                prefix = permission[:-1]
                if required_permission.startswith(prefix):
                    return True
        
        return False
    
    @staticmethod
    def check_resource_access(user_id: str, resource_id: str, action: str, 
                            permissions: Dict[str, List[str]]) -> bool:
        """
        Verifica acesso a recurso específico
        
        Args:
            user_id: ID do usuário
            resource_id: ID do recurso
            action: Ação desejada
            permissions: Mapa de permissões por recurso
            
        Returns:
            True se tem acesso
        """
        resource_permissions = permissions.get(resource_id, [])
        required_permission = f"{action}:{resource_id}"
        
        return AccessControl.check_permission(resource_permissions, required_permission)
    
    @staticmethod
    def filter_accessible_resources(user_permissions: List[str], resources: List[Dict[str, Any]], 
                                  action: str = "read") -> List[Dict[str, Any]]:
        """
        Filtra recursos acessíveis pelo usuário
        
        Args:
            user_permissions: Permissões do usuário
            resources: Lista de recursos
            action: Ação desejada
            
        Returns:
            Lista de recursos acessíveis
        """
        accessible = []
        
        for resource in resources:
            resource_id = resource.get('id')
            if resource_id:
                required_permission = f"{action}:{resource_id}"
                if AccessControl.check_permission(user_permissions, required_permission):
                    accessible.append(resource)
        
        return accessible


class SecurityAudit:
    """Auditoria de segurança"""
    
    @staticmethod
    def log_security_event(event_type: str, user_id: str, resource: str, 
                          details: Dict[str, Any], ip_address: str = None):
        """
        Registra evento de segurança
        
        Args:
            event_type: Tipo do evento
            user_id: ID do usuário
            resource: Recurso acessado
            details: Detalhes do evento
            ip_address: Endereço IP
        """
        event = {
            'timestamp': datetime.utcnow().isoformat(),
            'event_type': event_type,
            'user_id': user_id,
            'resource': resource,
            'ip_address': ip_address,
            'details': details
        }
        
        # Aqui seria implementada a persistência do log
        print(f"SECURITY_EVENT: {event}")
    
    @staticmethod
    def detect_suspicious_activity(user_id: str, recent_events: List[Dict[str, Any]]) -> List[str]:
        """
        Detecta atividade suspeita
        
        Args:
            user_id: ID do usuário
            recent_events: Eventos recentes
            
        Returns:
            Lista de alertas de segurança
        """
        alerts = []
        
        # Detectar múltiplas tentativas de login falhadas
        failed_logins = [e for e in recent_events if e.get('event_type') == 'login_failed']
        if len(failed_logins) >= 5:
            alerts.append("Múltiplas tentativas de login falhadas")
        
        # Detectar acesso de IPs diferentes
        ips = set(e.get('ip_address') for e in recent_events if e.get('ip_address'))
        if len(ips) > 3:
            alerts.append("Acesso de múltiplos endereços IP")
        
        # Detectar atividade fora do horário normal
        now = datetime.utcnow()
        if now.hour < 6 or now.hour > 22:
            alerts.append("Atividade fora do horário comercial")
        
        return alerts


def generate_api_key(length: int = 32) -> str:
    """
    Gera chave de API segura
    
    Args:
        length: Comprimento da chave
        
    Returns:
        Chave de API
    """
    return secrets.token_urlsafe(length)


def generate_csrf_token() -> str:
    """
    Gera token CSRF
    
    Returns:
        Token CSRF
    """
    return secrets.token_urlsafe(32)


def verify_csrf_token(token: str, expected: str) -> bool:
    """
    Verifica token CSRF
    
    Args:
        token: Token recebido
        expected: Token esperado
        
    Returns:
        True se válido
    """
    return hmac.compare_digest(token, expected)


def sanitize_input(input_data: str) -> str:
    """
    Sanitiza entrada para prevenir ataques
    
    Args:
        input_data: Dados de entrada
        
    Returns:
        Dados sanitizados
    """
    # Remove caracteres perigosos
    sanitized = re.sub(r'[<>"\';\\]', '', input_data)
    
    # Remove scripts
    sanitized = re.sub(r'<script.*?</script>', '', sanitized, flags=re.IGNORECASE | re.DOTALL)
    
    # Remove eventos JavaScript
    sanitized = re.sub(r'on\w+\s*=', '', sanitized, flags=re.IGNORECASE)
    
    return sanitized.strip()


def validate_ip_address(ip: str, allowed_ranges: List[str] = None) -> bool:
    """
    Valida endereço IP contra ranges permitidos
    
    Args:
        ip: Endereço IP
        allowed_ranges: Ranges permitidos (CIDR)
        
    Returns:
        True se IP permitido
    """
    import ipaddress
    
    if not allowed_ranges:
        return True
    
    try:
        ip_obj = ipaddress.ip_address(ip)
        
        for range_str in allowed_ranges:
            network = ipaddress.ip_network(range_str, strict=False)
            if ip_obj in network:
                return True
        
        return False
    except ValueError:
        return False


# Instâncias globais para uso na aplicação
password_manager = PasswordManager()
token_manager = TokenManager("your-secret-key-here")  # Deve vir de configuração
data_encryption = DataEncryption()
data_masking = DataMasking()
access_control = AccessControl()
security_audit = SecurityAudit()

