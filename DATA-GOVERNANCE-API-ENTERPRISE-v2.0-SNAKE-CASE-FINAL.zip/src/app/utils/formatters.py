"""
Formatadores para Data Governance API
Autor: Carlos Morais

Módulo com formatadores para diferentes tipos de dados,
datas, números, moedas e outros formatos de saída.
"""

import re
from datetime import datetime, timedelta
from decimal import Decimal
from typing import Any, Dict, List, Optional, Union
import json


def format_datetime(dt: datetime, format_type: str = "iso") -> str:
    """
    Formata datetime para diferentes formatos
    
    Args:
        dt: Datetime para formatar
        format_type: Tipo de formato (iso, br, us, timestamp)
        
    Returns:
        String formatada
    """
    if format_type == "iso":
        return dt.isoformat()
    elif format_type == "br":
        return dt.strftime("%d/%m/%Y %H:%M:%S")
    elif format_type == "us":
        return dt.strftime("%m/%d/%Y %I:%M:%S %p")
    elif format_type == "timestamp":
        return str(int(dt.timestamp()))
    elif format_type == "human":
        return format_relative_time(dt)
    else:
        return dt.isoformat()


def format_relative_time(dt: datetime) -> str:
    """
    Formata datetime como tempo relativo (ex: "2 horas atrás")
    
    Args:
        dt: Datetime para formatar
        
    Returns:
        String com tempo relativo
    """
    now = datetime.utcnow()
    diff = now - dt
    
    if diff.days > 0:
        if diff.days == 1:
            return "1 dia atrás"
        elif diff.days < 30:
            return f"{diff.days} dias atrás"
        elif diff.days < 365:
            months = diff.days // 30
            return f"{months} {'mês' if months == 1 else 'meses'} atrás"
        else:
            years = diff.days // 365
            return f"{years} {'ano' if years == 1 else 'anos'} atrás"
    
    hours = diff.seconds // 3600
    if hours > 0:
        return f"{hours} {'hora' if hours == 1 else 'horas'} atrás"
    
    minutes = (diff.seconds % 3600) // 60
    if minutes > 0:
        return f"{minutes} {'minuto' if minutes == 1 else 'minutos'} atrás"
    
    return "agora mesmo"


def format_currency(amount: Union[float, Decimal], currency: str = "BRL") -> str:
    """
    Formata valor monetário
    
    Args:
        amount: Valor para formatar
        currency: Código da moeda (BRL, USD, EUR)
        
    Returns:
        String formatada com moeda
    """
    if currency == "BRL":
        return f"R$ {amount:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    elif currency == "USD":
        return f"$ {amount:,.2f}"
    elif currency == "EUR":
        return f"€ {amount:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    else:
        return f"{currency} {amount:,.2f}"


def format_percentage(value: Union[float, int], decimals: int = 1) -> str:
    """
    Formata valor como percentual
    
    Args:
        value: Valor para formatar (0-100)
        decimals: Número de casas decimais
        
    Returns:
        String formatada como percentual
    """
    return f"{value:.{decimals}f}%"


def format_file_size(size_bytes: int) -> str:
    """
    Formata tamanho de arquivo em formato legível
    
    Args:
        size_bytes: Tamanho em bytes
        
    Returns:
        String formatada (ex: "1.5 MB")
    """
    if size_bytes == 0:
        return "0 B"
    
    size_names = ["B", "KB", "MB", "GB", "TB", "PB"]
    i = 0
    size = float(size_bytes)
    
    while size >= 1024.0 and i < len(size_names) - 1:
        size /= 1024.0
        i += 1
    
    return f"{size:.1f} {size_names[i]}"


def format_duration(seconds: Union[int, float]) -> str:
    """
    Formata duração em formato legível
    
    Args:
        seconds: Duração em segundos
        
    Returns:
        String formatada (ex: "2h 30m 15s")
    """
    if seconds < 60:
        return f"{seconds:.1f}s"
    
    minutes = int(seconds // 60)
    remaining_seconds = int(seconds % 60)
    
    if minutes < 60:
        if remaining_seconds > 0:
            return f"{minutes}m {remaining_seconds}s"
        return f"{minutes}m"
    
    hours = minutes // 60
    remaining_minutes = minutes % 60
    
    if hours < 24:
        parts = [f"{hours}h"]
        if remaining_minutes > 0:
            parts.append(f"{remaining_minutes}m")
        if remaining_seconds > 0:
            parts.append(f"{remaining_seconds}s")
        return " ".join(parts)
    
    days = hours // 24
    remaining_hours = hours % 24
    
    parts = [f"{days}d"]
    if remaining_hours > 0:
        parts.append(f"{remaining_hours}h")
    if remaining_minutes > 0:
        parts.append(f"{remaining_minutes}m")
    
    return " ".join(parts)


def format_number(number: Union[int, float], format_type: str = "default") -> str:
    """
    Formata números em diferentes formatos
    
    Args:
        number: Número para formatar
        format_type: Tipo de formato (default, compact, scientific)
        
    Returns:
        String formatada
    """
    if format_type == "compact":
        if abs(number) >= 1_000_000_000:
            return f"{number/1_000_000_000:.1f}B"
        elif abs(number) >= 1_000_000:
            return f"{number/1_000_000:.1f}M"
        elif abs(number) >= 1_000:
            return f"{number/1_000:.1f}K"
        else:
            return str(number)
    elif format_type == "scientific":
        return f"{number:.2e}"
    else:
        return f"{number:,}".replace(",", ".")


def format_json(data: Dict[str, Any], indent: int = 2) -> str:
    """
    Formata JSON de forma legível
    
    Args:
        data: Dados para formatar
        indent: Indentação
        
    Returns:
        JSON formatado
    """
    return json.dumps(data, indent=indent, ensure_ascii=False, default=str)


def format_sql_query(query: str) -> str:
    """
    Formata query SQL de forma legível
    
    Args:
        query: Query SQL
        
    Returns:
        Query formatada
    """
    # Palavras-chave SQL para formatação
    keywords = [
        "SELECT", "FROM", "WHERE", "JOIN", "INNER JOIN", "LEFT JOIN", "RIGHT JOIN",
        "GROUP BY", "ORDER BY", "HAVING", "UNION", "INSERT", "UPDATE", "DELETE",
        "CREATE", "ALTER", "DROP", "AND", "OR", "NOT", "IN", "EXISTS", "CASE",
        "WHEN", "THEN", "ELSE", "END", "AS", "ON", "DISTINCT", "COUNT", "SUM",
        "AVG", "MIN", "MAX"
    ]
    
    formatted_query = query
    
    # Adicionar quebras de linha antes de palavras-chave principais
    main_keywords = ["SELECT", "FROM", "WHERE", "GROUP BY", "ORDER BY", "HAVING"]
    for keyword in main_keywords:
        formatted_query = re.sub(
            f"\\b{keyword}\\b", 
            f"\n{keyword}", 
            formatted_query, 
            flags=re.IGNORECASE
        )
    
    # Remover espaços extras e quebras de linha desnecessárias
    lines = [line.strip() for line in formatted_query.split('\n') if line.strip()]
    
    return '\n'.join(lines)


def format_table_name(table_name: str, format_type: str = "display") -> str:
    """
    Formata nome de tabela para diferentes contextos
    
    Args:
        table_name: Nome da tabela
        format_type: Tipo de formato (display, technical, unity_catalog)
        
    Returns:
        Nome formatado
    """
    if format_type == "display":
        # Converte snake_case para Title Case
        return table_name.replace("_", " ").title()
    elif format_type == "technical":
        # Mantém formato técnico
        return table_name.lower()
    elif format_type == "unity_catalog":
        # Formato para Unity Catalog (catalog.schema.table)
        parts = table_name.split(".")
        if len(parts) == 3:
            return table_name
        elif len(parts) == 2:
            return f"default.{table_name}"
        else:
            return f"default.default.{table_name}"
    else:
        return table_name


def format_column_name(column_name: str, format_type: str = "display") -> str:
    """
    Formata nome de coluna para diferentes contextos
    
    Args:
        column_name: Nome da coluna
        format_type: Tipo de formato (display, technical)
        
    Returns:
        Nome formatado
    """
    if format_type == "display":
        # Converte snake_case para Title Case
        return column_name.replace("_", " ").title()
    else:
        return column_name.lower()


def format_data_type(data_type: str, format_type: str = "display") -> str:
    """
    Formata tipo de dados para diferentes contextos
    
    Args:
        data_type: Tipo de dados
        format_type: Tipo de formato (display, technical)
        
    Returns:
        Tipo formatado
    """
    type_mapping = {
        "varchar": "Texto Variável",
        "text": "Texto",
        "int": "Número Inteiro",
        "bigint": "Número Grande",
        "decimal": "Número Decimal",
        "float": "Número Decimal",
        "boolean": "Verdadeiro/Falso",
        "timestamp": "Data e Hora",
        "date": "Data",
        "uuid": "Identificador Único",
        "json": "JSON",
        "array": "Lista"
    }
    
    if format_type == "display":
        return type_mapping.get(data_type.lower(), data_type.title())
    else:
        return data_type.lower()


def format_status(status: str, format_type: str = "display") -> str:
    """
    Formata status para diferentes contextos
    
    Args:
        status: Status
        format_type: Tipo de formato (display, badge, icon)
        
    Returns:
        Status formatado
    """
    status_mapping = {
        "ativo": {"display": "Ativo", "badge": "success", "icon": "✅"},
        "inativo": {"display": "Inativo", "badge": "secondary", "icon": "⏸️"},
        "rascunho": {"display": "Rascunho", "badge": "warning", "icon": "📝"},
        "depreciado": {"display": "Depreciado", "badge": "danger", "icon": "⚠️"},
        "pendente": {"display": "Pendente", "badge": "info", "icon": "⏳"},
        "erro": {"display": "Erro", "badge": "danger", "icon": "❌"},
        "sucesso": {"display": "Sucesso", "badge": "success", "icon": "✅"}
    }
    
    status_info = status_mapping.get(status.lower(), {
        "display": status.title(),
        "badge": "secondary",
        "icon": "❓"
    })
    
    return status_info.get(format_type, status_info["display"])


def format_health_score(score: float) -> Dict[str, Any]:
    """
    Formata score de saúde com cor e descrição
    
    Args:
        score: Score de 0 a 100
        
    Returns:
        Dict com score formatado, cor e descrição
    """
    if score >= 90:
        return {
            "score": f"{score:.1f}%",
            "color": "green",
            "level": "Excelente",
            "description": "Dados em excelente estado"
        }
    elif score >= 75:
        return {
            "score": f"{score:.1f}%",
            "color": "blue",
            "level": "Bom",
            "description": "Dados em bom estado"
        }
    elif score >= 60:
        return {
            "score": f"{score:.1f}%",
            "color": "yellow",
            "level": "Regular",
            "description": "Dados precisam de atenção"
        }
    elif score >= 40:
        return {
            "score": f"{score:.1f}%",
            "color": "orange",
            "level": "Ruim",
            "description": "Dados com problemas significativos"
        }
    else:
        return {
            "score": f"{score:.1f}%",
            "color": "red",
            "level": "Crítico",
            "description": "Dados em estado crítico"
        }


def format_compliance_status(frameworks: List[str], violations: int = 0) -> Dict[str, Any]:
    """
    Formata status de compliance
    
    Args:
        frameworks: Lista de frameworks de compliance
        violations: Número de violações
        
    Returns:
        Dict com status de compliance formatado
    """
    if violations == 0:
        return {
            "status": "Conforme",
            "color": "green",
            "icon": "✅",
            "frameworks": frameworks,
            "violations": violations,
            "description": f"Conforme com {', '.join(frameworks)}"
        }
    elif violations <= 5:
        return {
            "status": "Atenção",
            "color": "yellow",
            "icon": "⚠️",
            "frameworks": frameworks,
            "violations": violations,
            "description": f"{violations} violações encontradas"
        }
    else:
        return {
            "status": "Não Conforme",
            "color": "red",
            "icon": "❌",
            "frameworks": frameworks,
            "violations": violations,
            "description": f"{violations} violações críticas"
        }


def sanitize_filename(filename: str) -> str:
    """
    Sanitiza nome de arquivo removendo caracteres inválidos
    
    Args:
        filename: Nome do arquivo
        
    Returns:
        Nome sanitizado
    """
    # Remove caracteres inválidos
    sanitized = re.sub(r'[<>:"/\\|?*]', '_', filename)
    
    # Remove espaços extras
    sanitized = re.sub(r'\s+', '_', sanitized)
    
    # Remove underscores consecutivos
    sanitized = re.sub(r'_+', '_', sanitized)
    
    # Remove underscores no início e fim
    sanitized = sanitized.strip('_')
    
    return sanitized


def truncate_text(text: str, max_length: int = 100, suffix: str = "...") -> str:
    """
    Trunca texto mantendo palavras completas
    
    Args:
        text: Texto para truncar
        max_length: Comprimento máximo
        suffix: Sufixo para texto truncado
        
    Returns:
        Texto truncado
    """
    if len(text) <= max_length:
        return text
    
    # Encontra o último espaço antes do limite
    truncated = text[:max_length - len(suffix)]
    last_space = truncated.rfind(' ')
    
    if last_space > 0:
        truncated = truncated[:last_space]
    
    return truncated + suffix

