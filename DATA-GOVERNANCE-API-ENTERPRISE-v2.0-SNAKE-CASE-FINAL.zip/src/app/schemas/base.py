"""
Schemas base para Data Governance API
Seguindo exatamente o modelo_estendido.dbml original
Autor: Carlos Morais
"""

from datetime import datetime
from typing import Optional
from uuid import UUID

from pydantic import BaseModel, Field


class BaseSchema(BaseModel):
    """Schema base para todas as entidades"""
    
    data_criacao: Optional[datetime] = Field(
        None,
        description="Timestamp de criação do registro"
    )
    
    data_atualizacao: Optional[datetime] = Field(
        None,
        description="Timestamp da última atualização"
    )
    
    class Config:
        from_attributes = True
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None,
            UUID: lambda v: str(v) if v else None
        }


class BaseCreateSchema(BaseModel):
    """Schema base para criação de entidades"""
    
    class Config:
        from_attributes = True


class BaseUpdateSchema(BaseModel):
    """Schema base para atualização de entidades"""
    
    class Config:
        from_attributes = True


class PaginationParams(BaseModel):
    """Parâmetros de paginação"""
    
    page: int = Field(1, ge=1, description="Número da página")
    size: int = Field(20, ge=1, le=100, description="Tamanho da página")
    
    @property
    def offset(self) -> int:
        return (self.page - 1) * self.size


class PaginatedResponse(BaseModel):
    """Resposta paginada"""
    
    items: list
    total: int
    page: int
    size: int
    pages: int
    
    @classmethod
    def create(cls, items: list, total: int, page: int, size: int):
        pages = (total + size - 1) // size
        return cls(
            items=items,
            total=total,
            page=page,
            size=size,
            pages=pages
        )

