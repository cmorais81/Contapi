"""
Schemas para data_contracts seguindo modelo original
Autor: Carlos Morais
"""

from pydantic import BaseModel, Field, ConfigDict
from typing import Optional
from uuid import UUID
from datetime import datetime

from .base import BaseSchema, BaseCreateSchema, BaseUpdateSchema


class DataContractsBase(BaseSchema):
    """Schema base para data_contracts"""
    contract_name: str = Field(..., description="Nome único do contrato")
    contract_description: Optional[str] = Field(None, description="Descrição detalhada do contrato")
    contract_owner: Optional[str] = Field(None, description="Proprietário responsável pelo contrato")
    business_domain: Optional[str] = Field(None, description="Domínio de negócio do contrato")
    contract_status: Optional[str] = Field("draft", description="Status do contrato")
    unity_catalog_enabled: Optional[bool] = Field(False, description="Integração Unity Catalog habilitada")
    unity_catalog_name: Optional[str] = Field(None, description="Nome do catálogo no Unity Catalog")
    unity_catalog_schema: Optional[str] = Field(None, description="Schema no Unity Catalog")
    unity_catalog_table: Optional[str] = Field(None, description="Tabela no Unity Catalog")
    abac_enabled: Optional[bool] = Field(False, description="ABAC habilitado")
    abac_policy: Optional[str] = Field(None, description="Política ABAC em JSON")
    monitoring_enabled: Optional[bool] = Field(True, description="Monitoramento ativo")
    monitoring_frequency: Optional[str] = Field("daily", description="Frequência de monitoramento")


class DataContractsCreate(BaseCreateSchema, DataContractsBase):
    """Schema para criação de data_contracts"""
    pass


class DataContractsUpdate(BaseUpdateSchema, DataContractsBase):
    """Schema para atualização de data_contracts"""
    contract_name: Optional[str] = Field(None, description="Nome único do contrato")


class DataContracts(DataContractsBase):
    """Schema completo para data_contracts"""
    model_config = ConfigDict(from_attributes=True)
    
    contract_id: UUID = Field(..., description="Identificador único do contrato")
    data_criacao: datetime = Field(..., description="Data de criação")
    data_atualizacao: datetime = Field(..., description="Data de atualização")


class DataContractsSummary(BaseModel):
    """Schema resumido para listagens de data_contracts"""
    model_config = ConfigDict(from_attributes=True)
    
    contract_id: UUID = Field(..., description="Identificador único do contrato")
    contract_name: str = Field(..., description="Nome único do contrato")
    contract_owner: Optional[str] = Field(None, description="Proprietário responsável")
    business_domain: Optional[str] = Field(None, description="Domínio de negócio")
    contract_status: Optional[str] = Field(None, description="Status do contrato")
    unity_catalog_enabled: Optional[bool] = Field(None, description="Unity Catalog habilitado")
    monitoring_enabled: Optional[bool] = Field(None, description="Monitoramento ativo")
    data_criacao: datetime = Field(..., description="Data de criação")
    data_atualizacao: datetime = Field(..., description="Data de atualização")
