"""
Modelos para Data Governance API
Autor: Carlos Morais
"""

from .base import BaseEntity

# Contratos e Versionamento
from .data_contracts import DataContracts
from .contract_versions import ContractVersions
from .contract_layouts import ContractLayouts
from .contract_custom_properties import ContractCustomProperties
from .contract_fundamentals import ContractFundamentals
from .contract_team_definitions import ContractTeamDefinitions
from .contract_sla_definitions import ContractSlaDefinitions
from .contract_pricing_definitions import ContractPricingDefinitions
from .contract_schema_definitions import ContractSchemaDefinitions

# Objetos de Dados
from .data_objects import DataObjects
from .data_object_properties import DataObjectProperties

# Qualidade de Dados
from .contract_quality_definitions import ContractQualityDefinitions
from .quality_rules import QualityRules
from .property_quality_rule_links import PropertyQualityRuleLinks
from .quality_execution_results import QualityExecutionResults

# Métricas de Monitoramento
from .cluster_metrics import ClusterMetrics
from .job_metrics import JobMetrics
from .query_metrics import QueryMetrics
from .storage_metrics import StorageMetrics

# Linhagem de Dados
from .data_lineage import DataLineage

# Usuários e Permissões
from .users import Users
from .groups import Groups
from .user_groups import UserGroups
from .permissions import Permissions
from .group_permissions import GroupPermissions

# Tags e Entidades
from .entity import Entity
from .tag import Tag
from .tagged import Tagged

# Governança e Conformidade
from .abac_policy_evaluations import AbacPolicyEvaluations
from .data_classification_results import DataClassificationResults

# Integração e Sincronização
from .tool_integrations import ToolIntegrations
from .sync_executions import SyncExecutions
from .sync_errors import SyncErrors

# Auditoria e Analytics
from .audit_log import AuditLog
from .data_quality_aggregates import DataQualityAggregates
from .data_anomaly_detection import DataAnomalyDetection

__all__ = [
    # Base
    "BaseEntity",
    
    # Contratos e Versionamento
    "DataContracts",
    "ContractVersions", 
    "ContractLayouts",
    "ContractCustomProperties",
    "ContractFundamentals",
    "ContractTeamDefinitions",
    "ContractSlaDefinitions",
    "ContractPricingDefinitions",
    "ContractSchemaDefinitions",
    
    # Objetos de Dados
    "DataObjects",
    "DataObjectProperties",
    
    # Qualidade de Dados
    "ContractQualityDefinitions",
    "QualityRules",
    "PropertyQualityRuleLinks", 
    "QualityExecutionResults",
    
    # Métricas de Monitoramento
    "ClusterMetrics",
    "JobMetrics",
    "QueryMetrics",
    "StorageMetrics",
    
    # Linhagem de Dados
    "DataLineage",
    
    # Usuários e Permissões
    "Users",
    "Groups",
    "UserGroups",
    "Permissions",
    "GroupPermissions",
    
    # Tags e Entidades
    "Entity",
    "Tag",
    "Tagged",
    
    # Governança e Conformidade
    "AbacPolicyEvaluations",
    "DataClassificationResults",
    
    # Integração e Sincronização
    "ToolIntegrations",
    "SyncExecutions",
    "SyncErrors",
    
    # Auditoria e Analytics
    "AuditLog",
    "DataQualityAggregates",
    "DataAnomalyDetection",
]
