"""
Modelo ContractTeamDefinitions para Data Governance API
Seguindo exatamente o modelo_estendido.dbml original
Autor: Carlos Morais
"""

from sqlalchemy import Column, ForeignKey, Text
from sqlalchemy.dialects.postgresql import JSON, UUID
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship

from .base import BaseEntity


class ContractTeamDefinitions(BaseEntity):
    """
    Funções da equipe e canais de comunicação para governança do contrato
    """
    
    __tablename__ = "ContractTeamDefinitions"
    
    # Chave primária UUID conforme modelo original
    team_definition_id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        default=func.gen_random_uuid(),
        nullable=False,
        comment='Identificador único da definição de equipe'
    )
    
    # Relacionamento com versão
    version_id = Column(
        UUID(as_uuid=True),
        ForeignKey('ContractVersions.version_id'),
        nullable=False,
        comment='Referência à versão do contrato'
    )
    
    # Definição da função
    role_type = Column(
        Text,
        nullable=False,
        comment='Tipo de função (Proprietário de Dados, Steward de Dados, Contato Técnico, Especialista de Negócio, Contato de Suporte)'
    )
    
    # Informações de contato
    contact_name = Column(
        Text,
        comment='Nome da pessoa, grupo ou service desk'
    )
    
    contact_email = Column(
        Text,
        comment='Endereço de email para contato'
    )
    
    contact_channel_type = Column(
        Text,
        comment='Tipo de canal de comunicação (Slack, Teams, Jira, Telefone)'
    )
    
    contact_channel_details = Column(
        Text,
        comment='Detalhes do canal (nome do canal, chave do projeto, número de telefone)'
    )
    
    responsibilities = Column(
        Text,
        comment='Responsabilidades principais ou escopo de suporte'
    )
    
    # Integração com gerenciamento de usuários
    user_id = Column(
        UUID(as_uuid=True),
        comment='Referência ao usuário do sistema se aplicável'
    )
    
    group_id = Column(
        UUID(as_uuid=True),
        comment='Referência ao grupo do sistema se aplicável'
    )
    
    # Integração com Plataforma de Dados
    unity_catalog_principal = Column(
        Text,
        comment='Principal do Unity Catalog para controle de acesso'
    )
    
    abac_attributes = Column(
        JSON,
        comment='Atributos ABAC para esta função'
    )
    
    # Relacionamentos
    version = relationship("ContractVersions", back_populates="team_definitions")
    
    def __repr__(self):
        return f"<ContractTeamDefinitions(team_definition_id={self.team_definition_id}, role={self.role_type})>"

