"""
Modelo ContractFundamentals para Data Governance API
Seguindo exatamente o modelo_estendido.dbml original
Autor: Carlos Morais
"""

from sqlalchemy import Column, ForeignKey, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship

from .base import BaseEntity


class ContractFundamentals(BaseEntity):
    """
    Informações fundamentais e metadados para uma versão específica do contrato
    """
    
    __tablename__ = "ContractFundamentals"
    
    # Chave primária UUID conforme modelo original
    fundamentals_id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        default=func.gen_random_uuid(),
        nullable=False,
        comment='Identificador único dos fundamentos'
    )
    
    # Relacionamento único com versão
    version_id = Column(
        UUID(as_uuid=True),
        ForeignKey('ContractVersions.version_id'),
        unique=True,
        nullable=False,
        comment='Referência única à versão do contrato'
    )
    
    # Informações fundamentais
    contract_name = Column(
        Text,
        nullable=False,
        comment='Nome legível do contrato'
    )
    
    domain = Column(
        Text,
        comment='Domínio de negócio'
    )
    
    sub_domain = Column(
        Text,
        comment='Sub-domínio opcional'
    )
    
    contract_description = Column(
        Text,
        comment='Descrição detalhada'
    )
    
    business_purpose = Column(
        Text,
        comment='Propósito de negócio e proposta de valor'
    )
    
    data_classification = Column(
        Text,
        comment='Nível geral de classificação de dados'
    )
    
    # Conformidade e regulamentação
    regulatory_framework = Column(
        Text,
        comment='Framework regulatório aplicável (GDPR, LGPD, HIPAA, etc.)'
    )
    
    compliance_requirements = Column(
        Text,
        comment='Requisitos específicos de conformidade'
    )
    
    data_residency_requirements = Column(
        Text,
        comment='Requisitos de residência e soberania de dados'
    )
    
    # Relacionamentos
    version = relationship("ContractVersions", back_populates="fundamentals")
    
    def __repr__(self):
        return f"<ContractFundamentals(fundamentals_id={self.fundamentals_id}, name={self.contract_name})>"

