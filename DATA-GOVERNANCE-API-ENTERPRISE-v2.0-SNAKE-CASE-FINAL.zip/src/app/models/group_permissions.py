"""
Modelo GroupPermissions para Data Governance API
Seguindo exatamente o modelo_estendido.dbml original
Autor: Carlos Morais
"""

from sqlalchemy import Column, ForeignKey, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship

from .base import BaseEntity


class GroupPermissions(BaseEntity):
    """
    Permissões de grupo com granularidade em nível de recurso
    """
    
    __tablename__ = "GroupPermissions"
    
    # Chave primária composta conforme modelo original
    group_id = Column(
        UUID(as_uuid=True),
        ForeignKey('Groups.group_id'),
        primary_key=True,
        nullable=False,
        comment='Referência ao grupo'
    )
    
    permission_id = Column(
        UUID(as_uuid=True),
        ForeignKey('Permissions.permission_id'),
        primary_key=True,
        nullable=False,
        comment='Referência à permissão'
    )
    
    # Granularidade de recurso
    resource_type = Column(
        Text,
        comment='Tipo de recurso (contrato, objeto_dados, regra_qualidade)'
    )
    
    resource_id = Column(
        UUID(as_uuid=True),
        comment='ID específico do recurso'
    )
    
    # Relacionamentos
    group = relationship("Groups", back_populates="group_permissions")
    permission = relationship("Permissions", back_populates="group_permissions")
    
    def __repr__(self):
        return f"<GroupPermissions(group_id={self.group_id}, permission_id={self.permission_id})>"

