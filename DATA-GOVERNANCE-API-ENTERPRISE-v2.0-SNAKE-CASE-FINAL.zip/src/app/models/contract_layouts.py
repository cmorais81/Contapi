"""
Modelo ContractLayouts para Data Governance API
Seguindo exatamente o modelo_estendido.dbml original
Autor: Carlos Morais
"""

from sqlalchemy import Boolean, Column, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func

from .base import BaseEntity


class ContractLayouts(BaseEntity):
    """
    Define diferentes layouts de apresentação ou templates de exportação para contratos de dados
    """
    
    __tablename__ = "ContractLayouts"
    
    # Chave primária UUID conforme modelo original
    layout_id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        default=func.gen_random_uuid(),
        nullable=False,
        comment='Identificador único do layout'
    )
    
    # Informações do layout
    layout_name = Column(
        Text,
        unique=True,
        nullable=False,
        comment='Nome do layout (ex: YAML Padrão, Resumo PDF, Especificação Técnica)'
    )
    
    layout_description = Column(
        Text,
        comment='Descrição do layout e seu propósito'
    )
    
    template_definition = Column(
        Text,
        comment='String de template, caminho do arquivo ou configuração para geração do layout'
    )
    
    layout_type = Column(
        Text,
        comment='Tipo: yaml, json, pdf, html, markdown'
    )
    
    is_default = Column(
        Boolean,
        default=False,
        comment='Se este é o layout padrão'
    )
    
    def __repr__(self):
        return f"<ContractLayouts(layout_id={self.layout_id}, name={self.layout_name})>"

