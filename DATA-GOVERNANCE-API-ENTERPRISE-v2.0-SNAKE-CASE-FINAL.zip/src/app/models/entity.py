"""
Modelo Entity para Data Governance API
Seguindo exatamente o modelo_estendido.dbml original
Autor: Carlos Morais
"""

from sqlalchemy import Boolean, Column, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship

from .base import BaseEntity


class Entity(BaseEntity):
    """
    Gerenciamento genérico de entidades para tagueamento flexível
    """
    
    __tablename__ = "Entity"
    
    # Chave primária UUID conforme modelo original
    entity_id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        default=func.gen_random_uuid(),
        nullable=False,
        comment='Identificador único da entidade'
    )
    
    # Informações da entidade
    entity_name = Column(
        Text,
        nullable=False,
        comment='Nome da entidade'
    )
    
    entity_type = Column(
        Text,
        nullable=False,
        comment='Tipo da entidade (contrato, objeto_dados, propriedade, regra)'
    )
    
    is_versionable = Column(
        Boolean,
        default=False,
        comment='Se a entidade suporta versionamento'
    )
    
    # Relacionamentos
    tagged_entities = relationship("Tagged", back_populates="entity")
    
    def __repr__(self):
        return f"<Entity(entity_id={self.entity_id}, name={self.entity_name}, type={self.entity_type})>"

