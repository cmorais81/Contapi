"""
Modelo ContractSchemaDefinitions para Data Governance API
Seguindo exatamente o modelo_estendido.dbml original
Autor: Carlos Morais
"""

from sqlalchemy import Column, ForeignKey, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship

from .base import BaseEntity


class ContractSchemaDefinitions(BaseEntity):
    """
    Container de nível superior para definição de schema de uma versão específica do contrato
    """
    
    __tablename__ = "ContractSchemaDefinitions"
    
    # Chave primária UUID conforme modelo original
    schema_definition_id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        default=func.gen_random_uuid(),
        nullable=False,
        comment='Identificador único da definição de schema'
    )
    
    # Relacionamento único com versão
    version_id = Column(
        UUID(as_uuid=True),
        ForeignKey('ContractVersions.version_id'),
        unique=True,
        nullable=False,
        comment='Referência única à versão do contrato'
    )
    
    # Informações do schema
    schema_name = Column(
        Text,
        comment='Nome do schema'
    )
    
    schema_description = Column(
        Text,
        comment='Descrição do schema'
    )
    
    schema_language = Column(
        Text,
        comment='Linguagem do schema (Avro, Protobuf, JSONSchema, SQL DDL)'
    )
    
    schema_format = Column(
        Text,
        comment='Formato do schema (json, avro, proto, sql)'
    )
    
    # Integração com Plataforma de Dados
    unity_catalog_schema_id = Column(
        UUID(as_uuid=True),
        comment='Referência do schema do Unity Catalog'
    )
    
    delta_table_schema_hash = Column(
        Text,
        comment='Hash do schema da tabela Delta para detecção de mudanças'
    )
    
    iceberg_schema_id = Column(
        UUID(as_uuid=True),
        comment='ID do schema Iceberg'
    )
    
    # Relacionamentos
    version = relationship("ContractVersions", back_populates="schema_definition")
    data_objects = relationship("DataObjects", back_populates="schema_definition")
    
    def __repr__(self):
        return f"<ContractSchemaDefinitions(schema_definition_id={self.schema_definition_id}, name={self.schema_name})>"

