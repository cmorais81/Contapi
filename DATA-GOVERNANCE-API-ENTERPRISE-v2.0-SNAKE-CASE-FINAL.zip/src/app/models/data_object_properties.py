"""
Modelo DataObjectProperties para Data Governance API
Seguindo exatamente o modelo_estendido.dbml original
Autor: Carlos Morais
"""

from sqlalchemy import Boolean, Column, ForeignKey, Integer, Numeric, Text
from sqlalchemy.dialects.postgresql import JSON, UUID
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship

from .base import BaseEntity


class DataObjectProperties(BaseEntity):
    """
    Definições granulares de propriedades com métricas aprimoradas de privacidade, classificação e qualidade
    """
    
    __tablename__ = "DataObjectProperties"
    
    # Chave primária UUID conforme modelo original
    property_id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        default=func.gen_random_uuid(),
        nullable=False,
        comment='Identificador único da propriedade'
    )
    
    # Relacionamento com objeto de dados
    data_object_id = Column(
        UUID(as_uuid=True),
        ForeignKey('DataObjects.data_object_id'),
        nullable=False,
        comment='Referência ao objeto de dados'
    )
    
    # Informações básicas da propriedade
    property_name = Column(
        Text,
        nullable=False,
        comment='Nome da coluna/campo'
    )
    
    ordinal_position = Column(
        Integer,
        comment='Ordem dentro do objeto de dados'
    )
    
    business_name = Column(
        Text,
        comment='Nome amigável para negócio'
    )
    
    property_description = Column(
        Text,
        comment='Descrição detalhada da propriedade'
    )
    
    # Tipos de dados
    logical_type = Column(
        Text,
        nullable=False,
        comment='Tipo lógico de dados (string, integer, boolean, timestamp, decimal, array, object)'
    )
    
    physical_type = Column(
        Text,
        comment='Tipo físico de armazenamento (VARCHAR(255), INT, BIGINT, DECIMAL(18,2))'
    )
    
    # Restrições e validação
    is_nullable = Column(
        Boolean,
        default=True,
        comment='Se a propriedade pode ser nula'
    )
    
    is_primary_key = Column(
        Boolean,
        default=False,
        comment='Se a propriedade faz parte da chave primária'
    )
    
    is_unique = Column(
        Boolean,
        default=False,
        comment='Se os valores devem ser únicos'
    )
    
    default_value = Column(
        Text,
        comment='Valor padrão para a propriedade'
    )
    
    example_value = Column(
        Text,
        comment='Valor de exemplo para a propriedade'
    )
    
    # Privacidade e classificação (Aprimorado V4.0)
    classification_tag = Column(
        Text,
        comment='Classificação de dados (público, interno, confidencial, restrito)'
    )
    
    is_pii = Column(
        Boolean,
        default=False,
        comment='Flag de Informação Pessoalmente Identificável'
    )
    
    is_gdpr_relevant = Column(
        Boolean,
        default=False,
        comment='Flag de relevância GDPR'
    )
    
    is_lgpd_relevant = Column(
        Boolean,
        default=False,
        comment='Flag de relevância LGPD'
    )
    
    is_hipaa_relevant = Column(
        Boolean,
        default=False,
        comment='Flag de relevância HIPAA'
    )
    
    is_pci_relevant = Column(
        Boolean,
        default=False,
        comment='Flag de relevância PCI DSS'
    )
    
    # Governança de dados
    data_steward = Column(
        Text,
        comment='Steward de dados responsável por esta propriedade'
    )
    
    business_glossary_term = Column(
        Text,
        comment='Referência do termo do glossário de negócio'
    )
    
    tags = Column(
        Text,
        comment='Array JSON ou tags separadas por vírgula'
    )
    
    # Integração com Plataforma de Dados
    unity_catalog_column_id = Column(
        UUID(as_uuid=True),
        comment='Referência da coluna do Unity Catalog'
    )
    
    delta_column_stats = Column(
        JSON,
        comment='Estatísticas da coluna da tabela Delta'
    )
    
    column_lineage_id = Column(
        UUID(as_uuid=True),
        comment='Referência do lineage da coluna'
    )
    
    # Qualidade e monitoramento
    quality_score = Column(
        Numeric,
        comment='Pontuação atual de qualidade (0-100)'
    )
    
    completeness_percentage = Column(
        Numeric,
        comment='Porcentagem de completude dos dados'
    )
    
    uniqueness_percentage = Column(
        Numeric,
        comment='Porcentagem de unicidade dos dados'
    )
    
    validity_percentage = Column(
        Numeric,
        comment='Porcentagem de validade dos dados'
    )
    
    # Relacionamentos
    data_object = relationship("DataObjects", back_populates="properties")
    
    def __repr__(self):
        return f"<DataObjectProperties(property_id={self.property_id}, name={self.property_name})>"

