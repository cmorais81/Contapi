"""
Repository para data_contracts seguindo modelo original
Autor: Carlos Morais
"""

from typing import List, Optional, Dict, Any
from uuid import UUID
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, func

from .base import BaseRepository
from ..models.data_contracts import DataContracts
from ..utils.exceptions import EntityNotFoundError


class DataContractsRepository(BaseRepository[DataContracts]):
    """Repository para data_contracts"""

    def __init__(self, db: Session):
        super().__init__(DataContracts, db)

    async def get_by_name(self, contract_name: str) -> Optional[DataContracts]:
        """Busca contrato por nome único"""
        return self.db.query(self.model).filter(
            self.model.contract_name == contract_name
        ).first()

    async def get_by_domain(self, business_domain: str, skip: int = 0, limit: int = 100) -> List[DataContracts]:
        """Busca contratos por domínio de negócio"""
        return self.db.query(self.model).filter(
            self.model.business_domain == business_domain
        ).offset(skip).limit(limit).all()

    async def get_by_owner(self, contract_owner: str, skip: int = 0, limit: int = 100) -> List[DataContracts]:
        """Busca contratos por proprietário"""
        return self.db.query(self.model).filter(
            self.model.contract_owner == contract_owner
        ).offset(skip).limit(limit).all()

    async def get_by_status(self, contract_status: str, skip: int = 0, limit: int = 100) -> List[DataContracts]:
        """Busca contratos por status"""
        return self.db.query(self.model).filter(
            self.model.contract_status == contract_status
        ).offset(skip).limit(limit).all()

    async def get_unity_catalog_enabled(self, skip: int = 0, limit: int = 100) -> List[DataContracts]:
        """Busca contratos com Unity Catalog habilitado"""
        return self.db.query(self.model).filter(
            self.model.unity_catalog_enabled == True
        ).offset(skip).limit(limit).all()

    async def get_abac_enabled(self, skip: int = 0, limit: int = 100) -> List[DataContracts]:
        """Busca contratos com ABAC habilitado"""
        return self.db.query(self.model).filter(
            self.model.abac_enabled == True
        ).offset(skip).limit(limit).all()

    async def get_monitoring_enabled(self, skip: int = 0, limit: int = 100) -> List[DataContracts]:
        """Busca contratos com monitoramento habilitado"""
        return self.db.query(self.model).filter(
            self.model.monitoring_enabled == True
        ).offset(skip).limit(limit).all()

    async def search_text(self, search_term: str, skip: int = 0, limit: int = 100) -> List[DataContracts]:
        """Busca textual em múltiplos campos"""
        search_filter = or_(
            self.model.contract_name.ilike(f"%{search_term}%"),
            self.model.contract_description.ilike(f"%{search_term}%"),
            self.model.contract_owner.ilike(f"%{search_term}%"),
            self.model.business_domain.ilike(f"%{search_term}%")
        )
        
        return self.db.query(self.model).filter(search_filter).offset(skip).limit(limit).all()

    async def get_stats(self) -> Dict[str, Any]:
        """Retorna estatísticas dos contratos"""
        total = self.db.query(func.count(self.model.contract_id)).scalar()
        
        by_status = self.db.query(
            self.model.contract_status,
            func.count(self.model.contract_id)
        ).group_by(self.model.contract_status).all()
        
        by_domain = self.db.query(
            self.model.business_domain,
            func.count(self.model.contract_id)
        ).group_by(self.model.business_domain).all()
        
        unity_catalog_count = self.db.query(func.count(self.model.contract_id)).filter(
            self.model.unity_catalog_enabled == True
        ).scalar()
        
        abac_count = self.db.query(func.count(self.model.contract_id)).filter(
            self.model.abac_enabled == True
        ).scalar()
        
        monitoring_count = self.db.query(func.count(self.model.contract_id)).filter(
            self.model.monitoring_enabled == True
        ).scalar()

        return {
            "total_contracts": total,
            "by_status": dict(by_status),
            "by_domain": dict(by_domain),
            "unity_catalog_enabled": unity_catalog_count,
            "abac_enabled": abac_count,
            "monitoring_enabled": monitoring_count
        }

    async def name_exists(self, contract_name: str, exclude_id: Optional[UUID] = None) -> bool:
        """Verifica se nome do contrato já existe"""
        query = self.db.query(self.model).filter(self.model.contract_name == contract_name)
        
        if exclude_id:
            query = query.filter(self.model.contract_id != exclude_id)
            
        return query.first() is not None
