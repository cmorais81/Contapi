"""
Integrações para Data Governance API
Autor: Carlos Morais

Módulo para integrações com sistemas externos de governança.
"""

from .unity_catalog import UnityCatalogIntegration
from .informatica_axon import InformaticaAxonIntegration
from .databricks import DatabricksIntegration

__all__ = [
    "UnityCatalogIntegration",
    "InformaticaAxonIntegration", 
    "DatabricksIntegration"
]

