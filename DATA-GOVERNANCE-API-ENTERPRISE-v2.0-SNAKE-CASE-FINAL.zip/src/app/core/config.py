"""
Configurações da aplicação
Autor: Carlos Morais

Configurações centralizadas usando Pydantic Settings.
"""

import os
from typing import List, Optional

from pydantic import Field, validator
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Configurações da aplicação"""
    
    # Configurações básicas da aplicação
    APP_NAME: str = Field(default="Data Governance API", description="Nome da aplicação")
    APP_VERSION: str = Field(default="1.0.0", description="Versão da aplicação")
    DEBUG: bool = Field(default=False, description="Modo debug")
    ENVIRONMENT: str = Field(default="development", description="Ambiente de execução")
    
    # Configurações do servidor
    HOST: str = Field(default="0.0.0.0", description="Host do servidor")
    PORT: int = Field(default=8000, description="Porta do servidor")
    WORKERS: int = Field(default=1, description="Número de workers")
    
    # Configurações do banco de dados
    DATABASE_URL: str = Field(
        default="postgresql+asyncpg://postgres:postgres@localhost:5432/data_governance",
        description="URL de conexão com o banco de dados"
    )
    DATABASE_ECHO: bool = Field(default=False, description="Log de queries SQL")
    DATABASE_POOL_SIZE: int = Field(default=10, description="Tamanho do pool de conexões")
    DATABASE_MAX_OVERFLOW: int = Field(default=20, description="Máximo de conexões extras")
    
    # Configurações de segurança
    SECRET_KEY: str = Field(
        default="your-secret-key-change-in-production",
        description="Chave secreta para JWT"
    )
    ACCESS_TOKEN_EXPIRE_MINUTES: int = Field(
        default=30,
        description="Tempo de expiração do token de acesso em minutos"
    )
    ALGORITHM: str = Field(default="HS256", description="Algoritmo para JWT")
    
    # Configurações de CORS
    ALLOWED_HOSTS: List[str] = Field(
        default=["*"],
        description="Hosts permitidos para CORS"
    )
    ALLOWED_ORIGINS: List[str] = Field(
        default=["http://localhost:3000", "http://localhost:8080"],
        description="Origens permitidas para CORS"
    )
    
    # Configurações de logging
    LOG_LEVEL: str = Field(default="INFO", description="Nível de log")
    LOG_FORMAT: str = Field(
        default="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        description="Formato do log"
    )
    
    # Configurações do Databricks (para integrações futuras)
    DATABRICKS_HOST: Optional[str] = Field(
        default=None,
        description="Host do Databricks"
    )
    DATABRICKS_TOKEN: Optional[str] = Field(
        default=None,
        description="Token de acesso do Databricks"
    )
    
    # Configurações do Unity Catalog
    UNITY_CATALOG_ENABLED: bool = Field(
        default=False,
        description="Habilitar integração com Unity Catalog"
    )
    
    # Configurações de cache (Redis)
    REDIS_URL: Optional[str] = Field(
        default=None,
        description="URL do Redis para cache"
    )
    CACHE_TTL: int = Field(
        default=300,
        description="TTL padrão do cache em segundos"
    )
    
    # Configurações de monitoramento
    ENABLE_METRICS: bool = Field(
        default=True,
        description="Habilitar coleta de métricas"
    )
    METRICS_PORT: int = Field(
        default=9090,
        description="Porta para métricas Prometheus"
    )
    
    # Configurações de health check
    HEALTH_CHECK_INTERVAL: int = Field(
        default=30,
        description="Intervalo de health check em segundos"
    )
    
    # Configurações de paginação
    DEFAULT_PAGE_SIZE: int = Field(
        default=100,
        description="Tamanho padrão da página"
    )
    MAX_PAGE_SIZE: int = Field(
        default=1000,
        description="Tamanho máximo da página"
    )
    
    # Configurações de rate limiting
    RATE_LIMIT_ENABLED: bool = Field(
        default=True,
        description="Habilitar rate limiting"
    )
    RATE_LIMIT_REQUESTS: int = Field(
        default=100,
        description="Número de requests por minuto"
    )
    
    # Configurações de backup
    BACKUP_ENABLED: bool = Field(
        default=False,
        description="Habilitar backup automático"
    )
    BACKUP_INTERVAL_HOURS: int = Field(
        default=24,
        description="Intervalo de backup em horas"
    )
    
    # Configurações de notificações
    EMAIL_ENABLED: bool = Field(
        default=False,
        description="Habilitar notificações por email"
    )
    SMTP_HOST: Optional[str] = Field(
        default=None,
        description="Host do servidor SMTP"
    )
    SMTP_PORT: int = Field(
        default=587,
        description="Porta do servidor SMTP"
    )
    SMTP_USERNAME: Optional[str] = Field(
        default=None,
        description="Usuário do SMTP"
    )
    SMTP_PASSWORD: Optional[str] = Field(
        default=None,
        description="Senha do SMTP"
    )
    
    # Configurações de qualidade de dados
    QUALITY_CHECK_ENABLED: bool = Field(
        default=True,
        description="Habilitar verificações de qualidade"
    )
    QUALITY_CHECK_INTERVAL_MINUTES: int = Field(
        default=60,
        description="Intervalo de verificação de qualidade em minutos"
    )
    
    # Configurações de auditoria
    AUDIT_ENABLED: bool = Field(
        default=True,
        description="Habilitar auditoria"
    )
    AUDIT_RETENTION_DAYS: int = Field(
        default=365,
        description="Retenção de logs de auditoria em dias"
    )
    
    @validator("DATABASE_URL")
    def validate_database_url(cls, v):
        """Valida URL do banco de dados"""
        if not v:
            raise ValueError("DATABASE_URL é obrigatória")
        if not v.startswith(("postgresql://", "postgresql+asyncpg://")):
            raise ValueError("DATABASE_URL deve ser PostgreSQL")
        return v
    
    @validator("SECRET_KEY")
    def validate_secret_key(cls, v):
        """Valida chave secreta"""
        if len(v) < 32:
            raise ValueError("SECRET_KEY deve ter pelo menos 32 caracteres")
        return v
    
    @validator("LOG_LEVEL")
    def validate_log_level(cls, v):
        """Valida nível de log"""
        valid_levels = ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
        if v.upper() not in valid_levels:
            raise ValueError(f"LOG_LEVEL deve ser um de: {valid_levels}")
        return v.upper()
    
    @validator("ENVIRONMENT")
    def validate_environment(cls, v):
        """Valida ambiente"""
        valid_envs = ["development", "testing", "staging", "production"]
        if v.lower() not in valid_envs:
            raise ValueError(f"ENVIRONMENT deve ser um de: {valid_envs}")
        return v.lower()
    
    class Config:
        """Configuração do Pydantic"""
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = True
        
        # Exemplos para documentação
        schema_extra = {
            "example": {
                "APP_NAME": "Data Governance API",
                "APP_VERSION": "1.0.0",
                "DEBUG": False,
                "ENVIRONMENT": "production",
                "DATABASE_URL": "postgresql+asyncpg://user:pass@localhost:5432/db",
                "SECRET_KEY": "your-super-secret-key-with-at-least-32-characters",
                "ALLOWED_HOSTS": ["api.example.com"],
                "LOG_LEVEL": "INFO"
            }
        }


# Instância global das configurações
settings = Settings()


def get_settings() -> Settings:
    """
    Retorna instância das configurações
    
    Returns:
        Configurações da aplicação
    """
    return settings


# Configurações específicas por ambiente
class DevelopmentSettings(Settings):
    """Configurações para desenvolvimento"""
    DEBUG: bool = True
    LOG_LEVEL: str = "DEBUG"
    DATABASE_ECHO: bool = True


class TestingSettings(Settings):
    """Configurações para testes"""
    DEBUG: bool = True
    LOG_LEVEL: str = "DEBUG"
    DATABASE_URL: str = "postgresql+asyncpg://postgres:postgres@localhost:5432/test_data_governance"


class ProductionSettings(Settings):
    """Configurações para produção"""
    DEBUG: bool = False
    LOG_LEVEL: str = "INFO"
    DATABASE_ECHO: bool = False


def get_settings_by_environment(env: str) -> Settings:
    """
    Retorna configurações específicas por ambiente
    
    Args:
        env: Nome do ambiente
        
    Returns:
        Configurações específicas do ambiente
    """
    settings_map = {
        "development": DevelopmentSettings,
        "testing": TestingSettings,
        "production": ProductionSettings
    }
    
    settings_class = settings_map.get(env.lower(), Settings)
    return settings_class()

