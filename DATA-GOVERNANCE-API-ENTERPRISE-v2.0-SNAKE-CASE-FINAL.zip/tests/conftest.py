"""
Configuração de testes para Data Governance API
Seguindo exatamente o modelo_estendido.dbml original
Autor: Carlos Morais
"""

import asyncio
import pytest
import pytest_asyncio
from typing import AsyncGenerator, Generator
from uuid import uuid4

from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker
from fastapi.testclient import TestClient

from src.app.main import app
from src.app.models.base import BaseEntity
from src.app.core.dependencies import get_db


# Configuração do banco de teste
TEST_DATABASE_URL = "sqlite+aiosqlite:///./test.db"

# Engine de teste
test_engine = create_async_engine(
    TEST_DATABASE_URL,
    echo=False,
    future=True
)

# Session de teste
TestSessionLocal = sessionmaker(
    test_engine,
    class_=AsyncSession,
    expire_on_commit=False
)


@pytest.fixture(scope="session")
def event_loop() -> Generator:
    """Cria event loop para testes assíncronos"""
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()


@pytest_asyncio.fixture
async def db_session() -> AsyncGenerator[AsyncSession, None]:
    """Cria sessão de banco de dados para testes"""
    
    # Criar todas as tabelas
    async with test_engine.begin() as conn:
        await conn.run_sync(BaseEntity.metadata.create_all)
    
    # Criar sessão
    async with TestSessionLocal() as session:
        yield session
    
    # Limpar todas as tabelas após o teste
    async with test_engine.begin() as conn:
        await conn.run_sync(BaseEntity.metadata.drop_all)


@pytest.fixture
def client(db_session: AsyncSession) -> TestClient:
    """Cria cliente de teste FastAPI"""
    
    def override_get_db():
        return db_session
    
    app.dependency_overrides[get_db] = override_get_db
    
    with TestClient(app) as test_client:
        yield test_client
    
    app.dependency_overrides.clear()


# Fixtures para dados de teste

@pytest.fixture
def sample_contract_data():
    """Dados de exemplo para contrato"""
    return {
        "contract_name": f"test_contract_{uuid4().hex[:8]}",
        "contract_description": "Contrato de teste para validação",
        "contract_owner": "test_owner",
        "business_domain": "test_domain",
        "unity_catalog_name": "test_catalog",
        "unity_catalog_schema": "test_schema", 
        "unity_catalog_table": "test_table",
        "data_location": "/test/location",
        "data_format": "delta",
        "table_format": "delta",
        "abac_enabled": True,
        "monitoring_enabled": True,
        "alert_threshold_percent": 95.0,
        "contract_status": "draft"
    }


@pytest.fixture
def sample_contract_version_data():
    """Dados de exemplo para versão de contrato"""
    return {
        "version_number": "1.0.0",
        "version_description": "Versão inicial do contrato",
        "schema_version": "1.0",
        "is_breaking_change": False,
        "approved_by": "test_approver",
        "approval_date": "2024-01-01T00:00:00Z",
        "delta_lake_enabled": True,
        "iceberg_enabled": False,
        "version_status": "draft"
    }


@pytest.fixture
def sample_layout_data():
    """Dados de exemplo para layout de contrato"""
    return {
        "layout_name": f"test_layout_{uuid4().hex[:8]}",
        "layout_description": "Layout de teste",
        "country_code": "BR",
        "region_code": "SA",
        "layout_type": "yaml",
        "template_content": "test: template",
        "is_default": False,
        "layout_status": "active"
    }


@pytest.fixture
def sample_data_object_data():
    """Dados de exemplo para objeto de dados"""
    return {
        "object_name": f"test_object_{uuid4().hex[:8]}",
        "object_description": "Objeto de teste",
        "object_type": "table",
        "business_domain": "test_domain",
        "data_classification": "internal",
        "contains_pii": False,
        "retention_period_days": 365,
        "purge_enabled": True,
        "backup_enabled": True,
        "object_status": "active"
    }


@pytest.fixture
def sample_quality_rule_data():
    """Dados de exemplo para regra de qualidade"""
    return {
        "rule_name": f"test_rule_{uuid4().hex[:8]}",
        "rule_description": "Regra de teste",
        "rule_type": "completeness",
        "rule_category": "data_quality",
        "rule_expression": "column IS NOT NULL",
        "severity_level": "high",
        "is_active": True,
        "dlt_enabled": True,
        "auto_remediation": False
    }


# Utilitários para testes

class TestDataFactory:
    """Factory para criar dados de teste"""
    
    @staticmethod
    def create_contract_data(**overrides):
        """Cria dados de contrato com overrides opcionais"""
        base_data = {
            "contract_name": f"test_contract_{uuid4().hex[:8]}",
            "contract_description": "Contrato de teste",
            "contract_owner": "test_owner",
            "business_domain": "test_domain",
            "contract_status": "draft"
        }
        base_data.update(overrides)
        return base_data
    
    @staticmethod
    def create_version_data(contract_id, **overrides):
        """Cria dados de versão com overrides opcionais"""
        base_data = {
            "contract_id": contract_id,
            "version_number": "1.0.0",
            "version_description": "Versão de teste",
            "schema_version": "1.0",
            "is_breaking_change": False,
            "version_status": "draft"
        }
        base_data.update(overrides)
        return base_data
    
    @staticmethod
    def create_layout_data(contract_id, **overrides):
        """Cria dados de layout com overrides opcionais"""
        base_data = {
            "contract_id": contract_id,
            "layout_name": f"test_layout_{uuid4().hex[:8]}",
            "layout_description": "Layout de teste",
            "country_code": "BR",
            "layout_type": "yaml",
            "template_content": "test: template",
            "is_default": False,
            "layout_status": "active"
        }
        base_data.update(overrides)
        return base_data


# Marcadores para categorizar testes

def pytest_configure(config):
    """Configuração de marcadores de teste"""
    config.addinivalue_line("markers", "unit: marca testes unitários")
    config.addinivalue_line("markers", "integration: marca testes de integração")
    config.addinivalue_line("markers", "slow: marca testes lentos")
    config.addinivalue_line("markers", "database: marca testes que usam banco de dados")
    config.addinivalue_line("markers", "api: marca testes de API/endpoints")

