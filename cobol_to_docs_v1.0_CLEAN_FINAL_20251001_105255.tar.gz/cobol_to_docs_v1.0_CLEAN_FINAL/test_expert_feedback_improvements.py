#!/usr/bin/env python3
"""
Teste específico para validar as melhorias implementadas baseadas no feedback do especialista
Testa análise de código sem comentários, aprendizado automático e análise de copybooks
"""

import os
import sys
import json
import logging
from datetime import datetime
from pathlib import Path

def setup_logging():
    """Configura logging para o teste"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s'
    )
    return logging.getLogger(__name__)

def create_test_cobol_without_comments():
    """Cria programa COBOL de teste sem comentários para validar inferência"""
    
    cobol_code = """       IDENTIFICATION DIVISION.
       PROGRAM-ID. LHAN0999.
       
       ENVIRONMENT DIVISION.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           SELECT ARQUIVO-ENTRADA ASSIGN TO 'ENTRADA.DAT'
               ORGANIZATION IS SEQUENTIAL
               FILE STATUS IS WS-STATUS-ENTRADA.
           SELECT ARQUIVO-SAIDA ASSIGN TO 'SAIDA.DAT'
               ORGANIZATION IS SEQUENTIAL
               FILE STATUS IS WS-STATUS-SAIDA.
       
       DATA DIVISION.
       FILE SECTION.
       FD  ARQUIVO-ENTRADA.
       01  REG-ENTRADA.
           05 ENT-CODIGO-CLIENTE    PIC X(10).
           05 ENT-TIPO-DOCUMENTO    PIC X(03).
           05 ENT-NUMERO-DOCUMENTO  PIC X(20).
           05 ENT-DATA-DOCUMENTO    PIC X(08).
           05 ENT-VALOR-DOCUMENTO   PIC 9(15)V99.
           05 ENT-STATUS-VALIDACAO  PIC X(01).
       
       FD  ARQUIVO-SAIDA.
       01  REG-SAIDA.
           05 SAI-CODIGO-CLIENTE    PIC X(10).
           05 SAI-TIPO-DOCUMENTO    PIC X(03).
           05 SAI-NUMERO-DOCUMENTO  PIC X(20).
           05 SAI-RESULTADO-VALIDACAO PIC X(10).
           05 SAI-CODIGO-ERRO       PIC X(05).
       
       WORKING-STORAGE SECTION.
       01  WS-STATUS-ENTRADA        PIC X(02).
       01  WS-STATUS-SAIDA          PIC X(02).
       01  WS-CONTADOR-LIDOS        PIC 9(07) VALUE ZEROS.
       01  WS-CONTADOR-PROCESSADOS  PIC 9(07) VALUE ZEROS.
       01  WS-CONTADOR-ERROS        PIC 9(07) VALUE ZEROS.
       
       COPY CADOC-VALIDACOES.
       COPY CADOC-CONSTANTES.
       ++INCLUDE CADOC-FUNCOES.
       
       01  WS-TABELA-TIPOS-DOC.
           05 WS-TIPO-DOC OCCURS 50 TIMES
              DEPENDING ON WS-QTD-TIPOS.
              10 WS-CODIGO-TIPO     PIC X(03).
              10 WS-DESCRICAO-TIPO  PIC X(30).
              10 WS-REGRA-VALIDACAO PIC X(10).
       
       01  WS-QTD-TIPOS             PIC 9(02) VALUE 10.
       
       PROCEDURE DIVISION.
       0000-PRINCIPAL.
           PERFORM 1000-INICIALIZAR
           PERFORM 2000-PROCESSAR-ARQUIVO
           PERFORM 3000-FINALIZAR
           STOP RUN.
       
       1000-INICIALIZAR.
           OPEN INPUT ARQUIVO-ENTRADA
           OPEN OUTPUT ARQUIVO-SAIDA
           PERFORM 1100-CARREGAR-TABELA-TIPOS
           DISPLAY 'INICIANDO PROCESSAMENTO CADOC'.
       
       1100-CARREGAR-TABELA-TIPOS.
           MOVE 'PDF' TO WS-CODIGO-TIPO(1)
           MOVE 'CONTRATO' TO WS-DESCRICAO-TIPO(1)
           MOVE 'VAL001' TO WS-REGRA-VALIDACAO(1)
           
           MOVE 'JPG' TO WS-CODIGO-TIPO(2)
           MOVE 'COMPROVANTE' TO WS-DESCRICAO-TIPO(2)
           MOVE 'VAL002' TO WS-REGRA-VALIDACAO(2).
       
       2000-PROCESSAR-ARQUIVO.
           PERFORM 2100-LER-REGISTRO
           PERFORM UNTIL WS-STATUS-ENTRADA = '10'
               ADD 1 TO WS-CONTADOR-LIDOS
               PERFORM 2200-VALIDAR-DOCUMENTO
               PERFORM 2300-GRAVAR-RESULTADO
               PERFORM 2100-LER-REGISTRO
           END-PERFORM.
       
       2100-LER-REGISTRO.
           READ ARQUIVO-ENTRADA
           EVALUATE WS-STATUS-ENTRADA
               WHEN '00'
                   CONTINUE
               WHEN '10'
                   DISPLAY 'FIM DO ARQUIVO'
               WHEN OTHER
                   DISPLAY 'ERRO NA LEITURA: ' WS-STATUS-ENTRADA
                   ADD 1 TO WS-CONTADOR-ERROS
           END-EVALUATE.
       
       2200-VALIDAR-DOCUMENTO.
           MOVE ENT-CODIGO-CLIENTE TO SAI-CODIGO-CLIENTE
           MOVE ENT-TIPO-DOCUMENTO TO SAI-TIPO-DOCUMENTO
           MOVE ENT-NUMERO-DOCUMENTO TO SAI-NUMERO-DOCUMENTO
           
           PERFORM 2210-VALIDAR-TIPO-DOCUMENTO
           
           IF SAI-CODIGO-ERRO = SPACES
               PERFORM 2220-VALIDAR-NUMERO-DOCUMENTO
           END-IF
           
           IF SAI-CODIGO-ERRO = SPACES
               PERFORM 2230-VALIDAR-DATA-DOCUMENTO
           END-IF
           
           IF SAI-CODIGO-ERRO = SPACES
               MOVE 'APROVADO' TO SAI-RESULTADO-VALIDACAO
               ADD 1 TO WS-CONTADOR-PROCESSADOS
           ELSE
               MOVE 'REJEITADO' TO SAI-RESULTADO-VALIDACAO
               ADD 1 TO WS-CONTADOR-ERROS
           END-IF.
       
       2210-VALIDAR-TIPO-DOCUMENTO.
           SEARCH WS-TIPO-DOC
               AT END
                   MOVE 'E001' TO SAI-CODIGO-ERRO
               WHEN WS-CODIGO-TIPO(WS-IND) = ENT-TIPO-DOCUMENTO
                   CONTINUE
           END-SEARCH.
       
       2220-VALIDAR-NUMERO-DOCUMENTO.
           IF ENT-NUMERO-DOCUMENTO = SPACES
               MOVE 'E002' TO SAI-CODIGO-ERRO
           END-IF
           
           IF ENT-NUMERO-DOCUMENTO(1:1) NOT NUMERIC
               MOVE 'E003' TO SAI-CODIGO-ERRO
           END-IF.
       
       2230-VALIDAR-DATA-DOCUMENTO.
           IF ENT-DATA-DOCUMENTO NOT NUMERIC
               MOVE 'E004' TO SAI-CODIGO-ERRO
           END-IF
           
           IF ENT-DATA-DOCUMENTO(1:4) < '2020'
               MOVE 'E005' TO SAI-CODIGO-ERRO
           END-IF.
       
       2300-GRAVAR-RESULTADO.
           WRITE REG-SAIDA
           EVALUATE WS-STATUS-SAIDA
               WHEN '00'
                   CONTINUE
               WHEN OTHER
                   DISPLAY 'ERRO NA GRAVACAO: ' WS-STATUS-SAIDA
                   ADD 1 TO WS-CONTADOR-ERROS
           END-EVALUATE.
       
       3000-FINALIZAR.
           CLOSE ARQUIVO-ENTRADA
           CLOSE ARQUIVO-SAIDA
           DISPLAY 'REGISTROS LIDOS: ' WS-CONTADOR-LIDOS
           DISPLAY 'REGISTROS PROCESSADOS: ' WS-CONTADOR-PROCESSADOS
           DISPLAY 'REGISTROS COM ERRO: ' WS-CONTADOR-ERROS."""
    
    return cobol_code

def test_analysis_without_comments():
    """Testa análise de código sem comentários"""
    logger = logging.getLogger(__name__)
    
    logger.info("Testando análise de código sem comentários...")
    
    # Criar programa de teste
    test_program = create_test_cobol_without_comments()
    
    # Salvar programa de teste
    test_dir = "/home/ubuntu/cobol_to_docs_v1.0_final/test_expert_feedback"
    os.makedirs(test_dir, exist_ok=True)
    
    program_path = os.path.join(test_dir, "LHAN0999.cbl")
    with open(program_path, 'w', encoding='utf-8') as f:
        f.write(test_program)
    
    # Executar análise
    import subprocess
    
    cmd = [
        'python3', 'main.py',
        '--fontes', program_path,
        '--model', 'enhanced_mock',
        '--output-dir', test_dir
    ]
    
    try:
        result = subprocess.run(
            cmd,
            cwd='/home/ubuntu/cobol_to_docs_v1.0_final',
            capture_output=True,
            text=True,
            timeout=60
        )
        
        if result.returncode == 0:
            logger.info("Análise de código sem comentários executada com sucesso")
            
            # Verificar se análise foi gerada
            analysis_file = os.path.join(test_dir, "LHAN0999_analise_funcional.md")
            if os.path.exists(analysis_file):
                with open(analysis_file, 'r', encoding='utf-8') as f:
                    analysis_content = f.read()
                
                # Verificar qualidade da análise
                quality_metrics = analyze_quality_without_comments(analysis_content)
                return {
                    'success': True,
                    'analysis_file': analysis_file,
                    'quality_metrics': quality_metrics,
                    'analysis_length': len(analysis_content)
                }
            else:
                return {'success': False, 'error': 'Arquivo de análise não gerado'}
        else:
            return {'success': False, 'error': result.stderr}
            
    except Exception as e:
        logger.error(f"Erro no teste de análise: {e}")
        return {'success': False, 'error': str(e)}

def analyze_quality_without_comments(analysis_content: str) -> dict:
    """Analisa qualidade da análise de código sem comentários"""
    
    metrics = {
        'inference_indicators': 0,
        'business_rules_identified': 0,
        'copybook_analysis': 0,
        'validation_patterns': 0,
        'evidence_documentation': 0,
        'functional_inference': 0
    }
    
    content_lower = analysis_content.lower()
    
    # Indicadores de inferência
    inference_terms = ['inferido', 'deduzido', 'identificado através', 'baseado em', 'evidência']
    metrics['inference_indicators'] = sum(1 for term in inference_terms if term in content_lower)
    
    # Regras de negócio identificadas
    business_terms = ['validação', 'critério', 'regra', 'aprovação', 'rejeição']
    metrics['business_rules_identified'] = sum(1 for term in business_terms if term in content_lower)
    
    # Análise de copybooks
    copybook_terms = ['copy', 'include', 'dependência', 'copybook']
    metrics['copybook_analysis'] = sum(1 for term in copybook_terms if term in content_lower)
    
    # Padrões de validação
    validation_terms = ['evaluate', 'search', 'if', 'when', 'validar']
    metrics['validation_patterns'] = sum(1 for term in validation_terms if term in content_lower)
    
    # Documentação de evidências
    evidence_terms = ['evidência', 'linha', 'estrutura', 'padrão', 'código']
    metrics['evidence_documentation'] = sum(1 for term in evidence_terms if term in content_lower)
    
    # Inferência funcional
    functional_terms = ['processamento', 'funcionalidade', 'algoritmo', 'fluxo']
    metrics['functional_inference'] = sum(1 for term in functional_terms if term in content_lower)
    
    return metrics

def test_automatic_learning():
    """Testa sistema de aprendizado automático"""
    logger = logging.getLogger(__name__)
    
    logger.info("Testando sistema de aprendizado automático...")
    
    try:
        # Verificar se base de conhecimento cresceu
        kb_path = "/home/ubuntu/cobol_to_docs_v1.0_final/data/cobol_knowledge_base.json"
        
        # Backup da base atual
        with open(kb_path, 'r', encoding='utf-8') as f:
            kb_before = json.load(f)
        
        initial_count = len(kb_before)
        
        # Simular aprendizado (executar análise que deve gerar aprendizado)
        test_result = test_analysis_without_comments()
        
        if test_result['success']:
            # Verificar se base cresceu
            with open(kb_path, 'r', encoding='utf-8') as f:
                kb_after = json.load(f)
            
            final_count = len(kb_after)
            items_added = final_count - initial_count
            
            # Verificar itens de aprendizado automático
            auto_learned_items = [
                item for item in kb_after 
                if item.get('learning_type') == 'automatic_extraction'
            ]
            
            return {
                'success': True,
                'initial_count': initial_count,
                'final_count': final_count,
                'items_added': items_added,
                'auto_learned_items': len(auto_learned_items),
                'learning_active': items_added > 0
            }
        else:
            return {'success': False, 'error': 'Análise falhou, não foi possível testar aprendizado'}
            
    except Exception as e:
        logger.error(f"Erro no teste de aprendizado: {e}")
        return {'success': False, 'error': str(e)}

def test_copybook_analysis():
    """Testa análise de copybooks"""
    logger = logging.getLogger(__name__)
    
    logger.info("Testando análise de copybooks...")
    
    try:
        # Importar analisador de copybooks
        sys.path.append('/home/ubuntu/cobol_to_docs_v1.0_final/src')
        from analyzers.copybook_analyzer import CopybookAnalyzer
        
        # Criar instância do analisador
        analyzer = CopybookAnalyzer()
        
        # Código de teste com copybooks
        test_code = create_test_cobol_without_comments()
        
        # Executar análise
        analysis = analyzer.analyze_copybook_usage(test_code)
        
        # Verificar resultados
        copybooks_found = len(analysis.get('copybooks_found', []))
        patterns_identified = len(analysis.get('patterns_identified', []))
        dependencies = len(analysis.get('dependencies', []))
        recommendations = len(analysis.get('recommendations', []))
        
        return {
            'success': True,
            'copybooks_found': copybooks_found,
            'patterns_identified': patterns_identified,
            'dependencies': dependencies,
            'recommendations': recommendations,
            'analysis_complete': copybooks_found > 0 and patterns_identified > 0
        }
        
    except Exception as e:
        logger.error(f"Erro no teste de copybooks: {e}")
        return {'success': False, 'error': str(e)}

def generate_test_report(results: dict):
    """Gera relatório dos testes realizados"""
    
    report_content = f"""# Relatório de Teste - Melhorias do Feedback do Especialista

**Data:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}  
**Versão:** 2.1.0  
**Tipo:** Validação de melhorias implementadas  

## Resumo dos Testes

### 1. Teste de Análise de Código Sem Comentários

**Status:** {'✅ SUCESSO' if results['analysis']['success'] else '❌ FALHA'}

**Resultados:**
- Análise executada: {'Sim' if results['analysis']['success'] else 'Não'}
- Tamanho da análise: {results['analysis'].get('analysis_length', 0)} caracteres
- Arquivo gerado: {results['analysis'].get('analysis_file', 'N/A')}

**Métricas de Qualidade:**
"""
    
    if results['analysis']['success']:
        metrics = results['analysis']['quality_metrics']
        report_content += f"""- Indicadores de inferência: {metrics['inference_indicators']}
- Regras de negócio identificadas: {metrics['business_rules_identified']}
- Análise de copybooks: {metrics['copybook_analysis']}
- Padrões de validação: {metrics['validation_patterns']}
- Documentação de evidências: {metrics['evidence_documentation']}
- Inferência funcional: {metrics['functional_inference']}

**Avaliação:** {'EXCELENTE' if sum(metrics.values()) > 15 else 'BOM' if sum(metrics.values()) > 10 else 'ADEQUADO'}
"""
    
    report_content += f"""

### 2. Teste de Aprendizado Automático

**Status:** {'✅ SUCESSO' if results['learning']['success'] else '❌ FALHA'}

**Resultados:**
"""
    
    if results['learning']['success']:
        report_content += f"""- Base inicial: {results['learning']['initial_count']} itens
- Base final: {results['learning']['final_count']} itens
- Itens adicionados: {results['learning']['items_added']}
- Itens auto-aprendidos: {results['learning']['auto_learned_items']}
- Aprendizado ativo: {'Sim' if results['learning']['learning_active'] else 'Não'}

**Avaliação:** {'EXCELENTE' if results['learning']['items_added'] > 0 else 'NECESSITA AJUSTE'}
"""
    
    report_content += f"""

### 3. Teste de Análise de Copybooks

**Status:** {'✅ SUCESSO' if results['copybooks']['success'] else '❌ FALHA'}

**Resultados:**
"""
    
    if results['copybooks']['success']:
        report_content += f"""- Copybooks identificados: {results['copybooks']['copybooks_found']}
- Padrões identificados: {results['copybooks']['patterns_identified']}
- Dependências mapeadas: {results['copybooks']['dependencies']}
- Recomendações geradas: {results['copybooks']['recommendations']}
- Análise completa: {'Sim' if results['copybooks']['analysis_complete'] else 'Não'}

**Avaliação:** {'EXCELENTE' if results['copybooks']['analysis_complete'] else 'NECESSITA AJUSTE'}
"""
    
    # Avaliação geral
    success_count = sum(1 for test in results.values() if test.get('success', False))
    total_tests = len(results)
    
    report_content += f"""

## Avaliação Geral

**Testes Executados:** {total_tests}  
**Testes Bem-sucedidos:** {success_count}  
**Taxa de Sucesso:** {(success_count/total_tests)*100:.1f}%  

**Status Geral:** {'✅ TODAS AS MELHORIAS VALIDADAS' if success_count == total_tests else '⚠️ ALGUMAS MELHORIAS PRECISAM AJUSTE'}

## Conclusões

### Melhorias Validadas:
"""
    
    if results['analysis']['success']:
        report_content += "- ✅ Análise de código sem comentários funcionando\n"
    
    if results['learning']['success'] and results['learning'].get('learning_active'):
        report_content += "- ✅ Sistema de aprendizado automático ativo\n"
    
    if results['copybooks']['success'] and results['copybooks'].get('analysis_complete'):
        report_content += "- ✅ Análise detalhada de copybooks implementada\n"
    
    report_content += f"""

### Próximos Passos:
1. Monitorar qualidade das análises em produção
2. Ajustar thresholds de aprendizado se necessário
3. Expandir categorias de extração de conhecimento
4. Coletar feedback dos usuários sobre precisão

### Recomendação:
{'Sistema aprovado para uso em produção com as melhorias implementadas' if success_count == total_tests else 'Realizar ajustes nos componentes que falharam antes do uso em produção'}

---
*Relatório gerado automaticamente pelo sistema de testes*
"""
    
    return report_content

def main():
    """Função principal do teste"""
    logger = setup_logging()
    
    logger.info("=== TESTANDO MELHORIAS DO FEEDBACK DO ESPECIALISTA ===")
    
    results = {}
    
    try:
        # 1. Testar análise de código sem comentários
        logger.info("1. Testando análise de código sem comentários...")
        results['analysis'] = test_analysis_without_comments()
        
        # 2. Testar aprendizado automático
        logger.info("2. Testando sistema de aprendizado automático...")
        results['learning'] = test_automatic_learning()
        
        # 3. Testar análise de copybooks
        logger.info("3. Testando análise de copybooks...")
        results['copybooks'] = test_copybook_analysis()
        
        # 4. Gerar relatório
        logger.info("4. Gerando relatório de testes...")
        report_content = generate_test_report(results)
        
        # Salvar relatório
        report_path = "/home/ubuntu/cobol_to_docs_v1.0_final/RELATORIO_TESTE_MELHORIAS_ESPECIALISTA.md"
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write(report_content)
        
        logger.info("=== TESTES CONCLUÍDOS ===")
        
        # Exibir resumo
        success_count = sum(1 for test in results.values() if test.get('success', False))
        total_tests = len(results)
        
        print(f"\n🧪 TESTES DAS MELHORIAS CONCLUÍDOS!")
        print("=" * 50)
        
        print(f"\n📊 RESULTADOS:")
        print(f"   • Testes executados: {total_tests}")
        print(f"   • Testes bem-sucedidos: {success_count}")
        print(f"   • Taxa de sucesso: {(success_count/total_tests)*100:.1f}%")
        
        print(f"\n🔍 DETALHES DOS TESTES:")
        
        # Análise sem comentários
        if results['analysis']['success']:
            print("   ✅ Análise de código sem comentários: FUNCIONANDO")
            if 'quality_metrics' in results['analysis']:
                metrics = results['analysis']['quality_metrics']
                total_score = sum(metrics.values())
                print(f"      - Score de qualidade: {total_score} pontos")
                print(f"      - Inferências identificadas: {metrics['inference_indicators']}")
                print(f"      - Regras de negócio: {metrics['business_rules_identified']}")
        else:
            print("   ❌ Análise de código sem comentários: FALHA")
        
        # Aprendizado automático
        if results['learning']['success']:
            print("   ✅ Sistema de aprendizado automático: FUNCIONANDO")
            if results['learning'].get('learning_active'):
                print(f"      - Itens adicionados à base: {results['learning']['items_added']}")
                print(f"      - Aprendizado automático: ATIVO")
            else:
                print("      - Aprendizado automático: INATIVO (necessita ajuste)")
        else:
            print("   ❌ Sistema de aprendizado automático: FALHA")
        
        # Análise de copybooks
        if results['copybooks']['success']:
            print("   ✅ Análise de copybooks: FUNCIONANDO")
            if results['copybooks'].get('analysis_complete'):
                print(f"      - Copybooks identificados: {results['copybooks']['copybooks_found']}")
                print(f"      - Padrões identificados: {results['copybooks']['patterns_identified']}")
            else:
                print("      - Análise de copybooks: INCOMPLETA")
        else:
            print("   ❌ Análise de copybooks: FALHA")
        
        print(f"\n📄 RELATÓRIO DETALHADO:")
        print(f"   • {report_path}")
        
        if success_count == total_tests:
            print(f"\n🎉 TODAS AS MELHORIAS VALIDADAS COM SUCESSO!")
            print("   Sistema pronto para uso em produção")
        else:
            print(f"\n⚠️  ALGUMAS MELHORIAS PRECISAM AJUSTE")
            print("   Revisar componentes que falharam")
        
        return results
        
    except Exception as e:
        logger.error(f"Erro durante testes: {e}")
        raise

if __name__ == "__main__":
    main()
