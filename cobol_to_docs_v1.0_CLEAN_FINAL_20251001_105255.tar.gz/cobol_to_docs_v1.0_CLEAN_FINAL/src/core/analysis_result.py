"""
Classe para representar o resultado de uma análise
"""

from typing import Optional
from datetime import datetime

class AnalysisResult:
    """Representa o resultado de uma análise de programa COBOL"""
    
    def __init__(self, 
                 success: bool,
                 content: str = "",
                 error_message: str = "",
                 tokens_used: int = 0,
                 model_used: str = "",
                 analysis_time: float = 0.0,
                 provider: str = ""):
        """
        Inicializa um resultado de análise
        
        Args:
            success: Se a análise foi bem-sucedida
            content: Conteúdo da análise gerada
            error_message: Mensagem de erro (se houver)
            tokens_used: Número de tokens utilizados
            model_used: Modelo de IA utilizado
            analysis_time: Tempo de análise em segundos
            provider: Provider utilizado
        """
        self.success = success
        self.content = content
        self.error_message = error_message
        self.tokens_used = tokens_used
        self.model_used = model_used
        self.analysis_time = analysis_time
        self.provider = provider
        self.timestamp = datetime.now()
    
    def get_content_length(self) -> int:
        """Retorna o tamanho do conteúdo gerado"""
        return len(self.content)
    
    def get_sections_count(self) -> int:
        """Retorna o número de seções identificadas (linhas que começam com #)"""
        return len([line for line in self.content.split('\n') if line.strip().startswith('#')])
    
    def has_error(self) -> bool:
        """Verifica se houve erro na análise"""
        return not self.success or bool(self.error_message)
    
    def get_summary(self) -> dict:
        """Retorna um resumo do resultado"""
        return {
            'success': self.success,
            'content_length': self.get_content_length(),
            'sections_count': self.get_sections_count(),
            'tokens_used': self.tokens_used,
            'model_used': self.model_used,
            'analysis_time': self.analysis_time,
            'provider': self.provider,
            'timestamp': self.timestamp.isoformat(),
            'has_error': self.has_error()
        }
    
    def __str__(self) -> str:
        status = "SUCCESS" if self.success else "FAILED"
        return f"AnalysisResult(status={status}, content_length={self.get_content_length()}, model={self.model_used})"
    
    def __repr__(self) -> str:
        return self.__str__()
