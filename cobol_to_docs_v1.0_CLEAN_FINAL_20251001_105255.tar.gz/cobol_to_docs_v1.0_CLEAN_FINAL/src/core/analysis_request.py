"""
Classe para requisições de análise - Versão Final Limpa
"""

from typing import Dict, Any, Optional
from datetime import datetime

class AnalysisRequest:
    """Requisição de análise de programa COBOL - Compatível com todos os providers"""
    
    def __init__(self, program_content: str, program_name: str, model: str,
                 prompt: str, analysis_type: str = 'individual', **kwargs):
        # Atributos principais
        self.program_content = program_content
        self.program_code = program_content  # Alias para compatibilidade
        self.program_name = program_name
        self.model = model
        self.prompt = prompt
        self.analysis_type = analysis_type
        self.timestamp = datetime.now()
        
        # Atributos para providers específicos
        self.temperature = kwargs.get('temperature', 0.7)
        self.max_tokens = kwargs.get('max_tokens', 4000)
        self.top_p = kwargs.get('top_p', 0.9)
        self.context = kwargs.get('context', {})  # Para Enhanced Mock
        
        # Outros atributos
        self.metadata = kwargs
        self.request_id = f"req_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte para dicionário"""
        return {
            'program_content': self.program_content,
            'program_code': self.program_code,
            'program_name': self.program_name,
            'model': self.model,
            'prompt': self.prompt,
            'analysis_type': self.analysis_type,
            'temperature': self.temperature,
            'max_tokens': self.max_tokens,
            'top_p': self.top_p,
            'context': self.context,
            'timestamp': self.timestamp.isoformat(),
            'request_id': self.request_id,
            'metadata': self.metadata
        }
