"""
Analisador especializado de copybooks COBOL
Identifica e analisa dependências, estruturas compartilhadas e padrões
"""

import re
import logging
from typing import Dict, List, Any, Optional, Tuple
from pathlib import Path

class CopybookAnalyzer:
    """Analisador especializado para copybooks COBOL"""
    
    def __init__(self):
        self.logger = logging.getLogger('CopybookAnalyzer')
        
    def analyze_copybook_usage(self, program_content: str) -> Dict[str, Any]:
        """
        Analisa uso de copybooks no programa
        
        Args:
            program_content: Conteúdo do programa COBOL
            
        Returns:
            Dicionário com análise de copybooks
        """
        try:
            analysis = {
                'copybooks_found': [],
                'copy_statements': [],
                'include_statements': [],
                'patterns_identified': [],
                'dependencies': [],
                'recommendations': []
            }
            
            # Identificar statements COPY
            copy_patterns = [
                r'COPY\s+([A-Z0-9\-_]+)',
                r'COPY\s+"([^"]+)"',
                r"COPY\s+'([^']+)'",
                r'\+\+INCLUDE\s+([A-Z0-9\-_]+)',
                r'\+\+INCLUDE\s+"([^"]+)"'
            ]
            
            for pattern in copy_patterns:
                matches = re.finditer(pattern, program_content, re.IGNORECASE | re.MULTILINE)
                for match in matches:
                    copybook_name = match.group(1)
                    statement_type = 'COPY' if 'COPY' in match.group(0).upper() else 'INCLUDE'
                    
                    copybook_info = {
                        'name': copybook_name,
                        'type': statement_type,
                        'line_context': self._get_line_context(program_content, match.start()),
                        'usage_pattern': self._identify_usage_pattern(program_content, match)
                    }
                    
                    if statement_type == 'COPY':
                        analysis['copy_statements'].append(copybook_info)
                    else:
                        analysis['include_statements'].append(copybook_info)
                    
                    if copybook_name not in analysis['copybooks_found']:
                        analysis['copybooks_found'].append(copybook_name)
            
            # Analisar padrões de uso
            analysis['patterns_identified'] = self._analyze_usage_patterns(analysis)
            
            # Identificar dependências
            analysis['dependencies'] = self._analyze_dependencies(analysis)
            
            # Gerar recomendações
            analysis['recommendations'] = self._generate_recommendations(analysis)
            
            return analysis
            
        except Exception as e:
            self.logger.error(f"Erro na análise de copybooks: {e}")
            return {}
    
    def _get_line_context(self, content: str, position: int) -> Dict[str, Any]:
        """Obtém contexto da linha onde o copybook é usado"""
        lines = content[:position].split('\n')
        line_number = len(lines)
        
        # Identificar seção onde está localizado
        section = self._identify_section(content, position)
        
        return {
            'line_number': line_number,
            'section': section,
            'context_lines': lines[-3:] if len(lines) >= 3 else lines
        }
    
    def _identify_section(self, content: str, position: int) -> str:
        """Identifica em que seção do programa o copybook está"""
        content_before = content[:position].upper()
        
        sections = [
            ('WORKING-STORAGE SECTION', 'WORKING-STORAGE'),
            ('FILE SECTION', 'FILE'),
            ('LINKAGE SECTION', 'LINKAGE'),
            ('LOCAL-STORAGE SECTION', 'LOCAL-STORAGE'),
            ('PROCEDURE DIVISION', 'PROCEDURE'),
            ('DATA DIVISION', 'DATA'),
            ('ENVIRONMENT DIVISION', 'ENVIRONMENT')
        ]
        
        current_section = 'UNKNOWN'
        for section_marker, section_name in sections:
            if section_marker in content_before:
                last_pos = content_before.rfind(section_marker)
                if last_pos >= 0:
                    current_section = section_name
        
        return current_section
    
    def _identify_usage_pattern(self, content: str, match) -> str:
        """Identifica padrão de uso do copybook"""
        context = content[max(0, match.start()-100):match.end()+100].upper()
        
        patterns = {
            'DATA_STRUCTURE': ['01 ', '05 ', '10 ', 'PIC ', 'OCCURS'],
            'FILE_DEFINITION': ['FD ', 'SELECT', 'ASSIGN'],
            'WORKING_STORAGE': ['77 ', '01 ', 'VALUE'],
            'PROCEDURE_CODE': ['PERFORM', 'CALL', 'IF', 'MOVE'],
            'CONSTANTS': ['VALUE', 'CONSTANT', '88 ']
        }
        
        for pattern_name, keywords in patterns.items():
            if any(keyword in context for keyword in keywords):
                return pattern_name
        
        return 'GENERAL'
    
    def _analyze_usage_patterns(self, analysis: Dict) -> List[Dict]:
        """Analisa padrões de uso dos copybooks"""
        patterns = []
        
        # Agrupar por tipo de uso
        usage_by_pattern = {}
        for copy_info in analysis['copy_statements']:
            pattern = copy_info['usage_pattern']
            if pattern not in usage_by_pattern:
                usage_by_pattern[pattern] = []
            usage_by_pattern[pattern].append(copy_info)
        
        for pattern, copies in usage_by_pattern.items():
            patterns.append({
                'pattern_type': pattern,
                'count': len(copies),
                'copybooks': [c['name'] for c in copies],
                'description': self._get_pattern_description(pattern)
            })
        
        return patterns
    
    def _get_pattern_description(self, pattern: str) -> str:
        """Retorna descrição do padrão de uso"""
        descriptions = {
            'DATA_STRUCTURE': 'Copybooks usados para definir estruturas de dados',
            'FILE_DEFINITION': 'Copybooks usados para definições de arquivos',
            'WORKING_STORAGE': 'Copybooks usados em working-storage',
            'PROCEDURE_CODE': 'Copybooks usados em código procedural',
            'CONSTANTS': 'Copybooks usados para constantes e valores',
            'GENERAL': 'Uso geral de copybooks'
        }
        return descriptions.get(pattern, 'Padrão não identificado')
    
    def _analyze_dependencies(self, analysis: Dict) -> List[Dict]:
        """Analisa dependências entre copybooks"""
        dependencies = []
        
        for copybook in analysis['copybooks_found']:
            dependency = {
                'copybook': copybook,
                'dependency_type': 'EXTERNAL',
                'critical_level': self._assess_criticality(copybook, analysis),
                'usage_sections': self._get_usage_sections(copybook, analysis)
            }
            dependencies.append(dependency)
        
        return dependencies
    
    def _assess_criticality(self, copybook: str, analysis: Dict) -> str:
        """Avalia criticidade da dependência"""
        usage_count = sum(1 for copy_info in analysis['copy_statements'] 
                         if copy_info['name'] == copybook)
        
        if usage_count > 3:
            return 'HIGH'
        elif usage_count > 1:
            return 'MEDIUM'
        else:
            return 'LOW'
    
    def _get_usage_sections(self, copybook: str, analysis: Dict) -> List[str]:
        """Obtém seções onde o copybook é usado"""
        sections = []
        for copy_info in analysis['copy_statements']:
            if copy_info['name'] == copybook:
                section = copy_info['line_context']['section']
                if section not in sections:
                    sections.append(section)
        return sections
    
    def _generate_recommendations(self, analysis: Dict) -> List[str]:
        """Gera recomendações baseadas na análise"""
        recommendations = []
        
        # Verificar uso excessivo de copybooks
        if len(analysis['copybooks_found']) > 10:
            recommendations.append(
                "Considere revisar o uso de copybooks - muitas dependências podem impactar manutenibilidade"
            )
        
        # Verificar padrões de uso
        for pattern in analysis['patterns_identified']:
            if pattern['count'] > 5 and pattern['pattern_type'] == 'DATA_STRUCTURE':
                recommendations.append(
                    f"Alto uso de copybooks para estruturas de dados ({pattern['count']}) - "
                    "considere consolidação para melhor organização"
                )
        
        # Verificar dependências críticas
        critical_deps = [dep for dep in analysis['dependencies'] 
                        if dep['critical_level'] == 'HIGH']
        if critical_deps:
            recommendations.append(
                f"Dependências críticas identificadas: {[dep['copybook'] for dep in critical_deps]} - "
                "documentar e monitorar mudanças"
            )
        
        return recommendations

def create_copybook_knowledge_items(analysis: Dict) -> List[Dict]:
    """Cria itens de conhecimento baseados na análise de copybooks"""
    knowledge_items = []
    
    if analysis.get('patterns_identified'):
        for pattern in analysis['patterns_identified']:
            if pattern['count'] > 1:  # Apenas padrões significativos
                knowledge_item = {
                    'id': f"copybook_pattern_{pattern['pattern_type'].lower()}",
                    'title': f"Padrão de Uso de Copybook: {pattern['pattern_type']}",
                    'content': f"{pattern['description']}. Identificados {pattern['count']} copybooks com este padrão: {', '.join(pattern['copybooks'])}",
                    'category': 'Padrões de Copybook',
                    'keywords': ['copybook', pattern['pattern_type'].lower(), 'dependência'],
                    'cobol_constructs': ['COPY'],
                    'domain': 'Estruturas de Código',
                    'complexity_level': 'intermediario',
                    'created_at': datetime.now().isoformat()
                }
                knowledge_items.append(knowledge_item)
    
    return knowledge_items
