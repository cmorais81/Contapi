#!/usr/bin/env python3
"""
Teste real de execução do sistema com todas as correções implementadas
"""

import os
import sys
import json
import subprocess
import logging
from datetime import datetime
from pathlib import Path

def setup_logging():
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
    return logging.getLogger(__name__)

def create_test_cobol_program():
    """Cria programa COBOL de teste sem comentários"""
    
    cobol_code = """       IDENTIFICATION DIVISION.
       PROGRAM-ID. TESTPROG.
       
       ENVIRONMENT DIVISION.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           SELECT ARQUIVO-ENTRADA ASSIGN TO 'ENTRADA.DAT'
               ORGANIZATION IS SEQUENTIAL
               FILE STATUS IS WS-STATUS-ENTRADA.
           SELECT ARQUIVO-SAIDA ASSIGN TO 'SAIDA.DAT'
               ORGANIZATION IS SEQUENTIAL
               FILE STATUS IS WS-STATUS-SAIDA.
       
       DATA DIVISION.
       FILE SECTION.
       FD  ARQUIVO-ENTRADA.
       01  REG-ENTRADA.
           05 ENT-CODIGO-CLIENTE    PIC X(10).
           05 ENT-TIPO-DOCUMENTO    PIC X(03).
           05 ENT-NUMERO-DOCUMENTO  PIC X(20).
           05 ENT-DATA-DOCUMENTO    PIC X(08).
           05 ENT-VALOR-DOCUMENTO   PIC 9(15)V99.
           05 ENT-STATUS-VALIDACAO  PIC X(01).
       
       FD  ARQUIVO-SAIDA.
       01  REG-SAIDA.
           05 SAI-CODIGO-CLIENTE    PIC X(10).
           05 SAI-TIPO-DOCUMENTO    PIC X(03).
           05 SAI-NUMERO-DOCUMENTO  PIC X(20).
           05 SAI-RESULTADO-VALIDACAO PIC X(10).
           05 SAI-CODIGO-ERRO       PIC X(05).
       
       WORKING-STORAGE SECTION.
       01  WS-STATUS-ENTRADA        PIC X(02).
       01  WS-STATUS-SAIDA          PIC X(02).
       01  WS-CONTADOR-LIDOS        PIC 9(07) VALUE ZEROS.
       01  WS-CONTADOR-PROCESSADOS  PIC 9(07) VALUE ZEROS.
       01  WS-CONTADOR-ERROS        PIC 9(07) VALUE ZEROS.
       
       COPY CADOC-VALIDACOES.
       COPY CADOC-CONSTANTES.
       ++INCLUDE CADOC-FUNCOES.
       
       01  WS-TABELA-TIPOS-DOC.
           05 WS-TIPO-DOC OCCURS 50 TIMES
              DEPENDING ON WS-QTD-TIPOS.
              10 WS-CODIGO-TIPO     PIC X(03).
              10 WS-DESCRICAO-TIPO  PIC X(30).
              10 WS-REGRA-VALIDACAO PIC X(10).
       
       01  WS-QTD-TIPOS             PIC 9(02) VALUE 10.
       
       PROCEDURE DIVISION.
       0000-PRINCIPAL.
           PERFORM 1000-INICIALIZAR
           PERFORM 2000-PROCESSAR-ARQUIVO
           PERFORM 3000-FINALIZAR
           STOP RUN.
       
       1000-INICIALIZAR.
           OPEN INPUT ARQUIVO-ENTRADA
           OPEN OUTPUT ARQUIVO-SAIDA
           PERFORM 1100-CARREGAR-TABELA-TIPOS
           DISPLAY 'INICIANDO PROCESSAMENTO CADOC'.
       
       1100-CARREGAR-TABELA-TIPOS.
           MOVE 'PDF' TO WS-CODIGO-TIPO(1)
           MOVE 'CONTRATO' TO WS-DESCRICAO-TIPO(1)
           MOVE 'VAL001' TO WS-REGRA-VALIDACAO(1)
           
           MOVE 'JPG' TO WS-CODIGO-TIPO(2)
           MOVE 'COMPROVANTE' TO WS-DESCRICAO-TIPO(2)
           MOVE 'VAL002' TO WS-REGRA-VALIDACAO(2).
       
       2000-PROCESSAR-ARQUIVO.
           PERFORM 2100-LER-REGISTRO
           PERFORM UNTIL WS-STATUS-ENTRADA = '10'
               ADD 1 TO WS-CONTADOR-LIDOS
               PERFORM 2200-VALIDAR-DOCUMENTO
               PERFORM 2300-GRAVAR-RESULTADO
               PERFORM 2100-LER-REGISTRO
           END-PERFORM.
       
       2100-LER-REGISTRO.
           READ ARQUIVO-ENTRADA
           EVALUATE WS-STATUS-ENTRADA
               WHEN '00'
                   CONTINUE
               WHEN '10'
                   DISPLAY 'FIM DO ARQUIVO'
               WHEN OTHER
                   DISPLAY 'ERRO NA LEITURA: ' WS-STATUS-ENTRADA
                   ADD 1 TO WS-CONTADOR-ERROS
           END-EVALUATE.
       
       2200-VALIDAR-DOCUMENTO.
           MOVE ENT-CODIGO-CLIENTE TO SAI-CODIGO-CLIENTE
           MOVE ENT-TIPO-DOCUMENTO TO SAI-TIPO-DOCUMENTO
           MOVE ENT-NUMERO-DOCUMENTO TO SAI-NUMERO-DOCUMENTO
           
           PERFORM 2210-VALIDAR-TIPO-DOCUMENTO
           
           IF SAI-CODIGO-ERRO = SPACES
               PERFORM 2220-VALIDAR-NUMERO-DOCUMENTO
           END-IF
           
           IF SAI-CODIGO-ERRO = SPACES
               PERFORM 2230-VALIDAR-DATA-DOCUMENTO
           END-IF
           
           IF SAI-CODIGO-ERRO = SPACES
               MOVE 'APROVADO' TO SAI-RESULTADO-VALIDACAO
               ADD 1 TO WS-CONTADOR-PROCESSADOS
           ELSE
               MOVE 'REJEITADO' TO SAI-RESULTADO-VALIDACAO
               ADD 1 TO WS-CONTADOR-ERROS
           END-IF.
       
       2210-VALIDAR-TIPO-DOCUMENTO.
           SEARCH WS-TIPO-DOC
               AT END
                   MOVE 'E001' TO SAI-CODIGO-ERRO
               WHEN WS-CODIGO-TIPO(WS-IND) = ENT-TIPO-DOCUMENTO
                   CONTINUE
           END-SEARCH.
       
       2220-VALIDAR-NUMERO-DOCUMENTO.
           IF ENT-NUMERO-DOCUMENTO = SPACES
               MOVE 'E002' TO SAI-CODIGO-ERRO
           END-IF
           
           IF ENT-NUMERO-DOCUMENTO(1:1) NOT NUMERIC
               MOVE 'E003' TO SAI-CODIGO-ERRO
           END-IF.
       
       2230-VALIDAR-DATA-DOCUMENTO.
           IF ENT-DATA-DOCUMENTO NOT NUMERIC
               MOVE 'E004' TO SAI-CODIGO-ERRO
           END-IF
           
           IF ENT-DATA-DOCUMENTO(1:4) < '2020'
               MOVE 'E005' TO SAI-CODIGO-ERRO
           END-IF.
       
       2300-GRAVAR-RESULTADO.
           WRITE REG-SAIDA
           EVALUATE WS-STATUS-SAIDA
               WHEN '00'
                   CONTINUE
               WHEN OTHER
                   DISPLAY 'ERRO NA GRAVACAO: ' WS-STATUS-SAIDA
                   ADD 1 TO WS-CONTADOR-ERROS
           END-EVALUATE.
       
       3000-FINALIZAR.
           CLOSE ARQUIVO-ENTRADA
           CLOSE ARQUIVO-SAIDA
           DISPLAY 'REGISTROS LIDOS: ' WS-CONTADOR-LIDOS
           DISPLAY 'REGISTROS PROCESSADOS: ' WS-CONTADOR-PROCESSADOS
           DISPLAY 'REGISTROS COM ERRO: ' WS-CONTADOR-ERROS."""
    
    return cobol_code

def test_real_system_execution():
    """Testa execução real do sistema"""
    logger = logging.getLogger(__name__)
    
    logger.info("Iniciando teste real de execução...")
    
    # Criar diretório de teste
    test_dir = "/home/ubuntu/cobol_to_docs_v1.0_final/teste_execucao_real"
    os.makedirs(test_dir, exist_ok=True)
    
    # Criar programa de teste
    program_content = create_test_cobol_program()
    program_path = os.path.join(test_dir, "TESTPROG.cbl")
    
    with open(program_path, 'w', encoding='utf-8') as f:
        f.write(program_content)
    
    logger.info(f"Programa de teste criado: {program_path}")
    
    # Executar análise
    cmd = [
        'python3', 'main.py',
        '--fontes', program_path,
        '--models', 'enhanced_mock',
        '--output', test_dir
    ]
    
    try:
        logger.info(f"Executando comando: {' '.join(cmd)}")
        
        result = subprocess.run(
            cmd,
            cwd='/home/ubuntu/cobol_to_docs_v1.0_final',
            capture_output=True,
            text=True,
            timeout=120
        )
        
        logger.info(f"Código de retorno: {result.returncode}")
        logger.info(f"Stdout: {result.stdout}")
        
        if result.stderr:
            logger.warning(f"Stderr: {result.stderr}")
        
        # Verificar arquivos gerados
        expected_files = [
            "TESTPROG_analise_funcional.md",
            "ai_requests/TESTPROG_ai_request.json",
            "ai_responses/TESTPROG_ai_response.json"
        ]
        
        files_found = []
        files_missing = []
        
        for expected_file in expected_files:
            file_path = os.path.join(test_dir, expected_file)
            if os.path.exists(file_path):
                files_found.append(expected_file)
                logger.info(f"Arquivo encontrado: {expected_file}")
            else:
                files_missing.append(expected_file)
                logger.warning(f"Arquivo não encontrado: {expected_file}")
        
        # Analisar qualidade da análise gerada
        analysis_file = os.path.join(test_dir, "TESTPROG_analise_funcional.md")
        analysis_quality = {}
        
        if os.path.exists(analysis_file):
            with open(analysis_file, 'r', encoding='utf-8') as f:
                analysis_content = f.read()
            
            analysis_quality = {
                'total_length': len(analysis_content),
                'sections_count': len([line for line in analysis_content.split('\n') if line.startswith('#')]),
                'has_copybook_analysis': 'COPYBOOK' in analysis_content.upper(),
                'has_business_rules': 'REGRAS DE NEGÓCIO' in analysis_content.upper() or 'VALIDAÇÃO' in analysis_content.upper(),
                'has_inference_indicators': any(term in analysis_content.lower() for term in ['inferido', 'deduzido', 'identificado através']),
                'mentions_cadoc': 'CADOC' in analysis_content.upper(),
                'has_evidence_documentation': 'evidência' in analysis_content.lower() or 'baseado em' in analysis_content.lower()
            }
            
            logger.info(f"Qualidade da análise: {analysis_quality}")
        
        return {
            'success': result.returncode == 0,
            'files_found': files_found,
            'files_missing': files_missing,
            'analysis_quality': analysis_quality,
            'stdout': result.stdout,
            'stderr': result.stderr,
            'test_dir': test_dir
        }
        
    except subprocess.TimeoutExpired:
        logger.error("Timeout na execução do teste")
        return {'success': False, 'error': 'Timeout'}
    except Exception as e:
        logger.error(f"Erro na execução do teste: {e}")
        return {'success': False, 'error': str(e)}

def generate_execution_report(test_result):
    """Gera relatório da execução real"""
    
    report_content = f"""# Relatório de Execução Real - Sistema Corrigido

**Data:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}  
**Tipo:** Teste de execução real com correções implementadas  

## Resumo da Execução

**Status:** {'✅ SUCESSO' if test_result['success'] else '❌ FALHA'}

### Arquivos Gerados

**Arquivos Encontrados:**
"""
    
    for file_found in test_result.get('files_found', []):
        report_content += f"- ✅ {file_found}\n"
    
    report_content += "\n**Arquivos Não Encontrados:**\n"
    
    for file_missing in test_result.get('files_missing', []):
        report_content += f"- ❌ {file_missing}\n"
    
    if 'analysis_quality' in test_result:
        quality = test_result['analysis_quality']
        report_content += f"""

### Qualidade da Análise Gerada

- **Tamanho total:** {quality.get('total_length', 0)} caracteres
- **Seções identificadas:** {quality.get('sections_count', 0)}
- **Análise de copybooks:** {'Sim' if quality.get('has_copybook_analysis') else 'Não'}
- **Regras de negócio:** {'Sim' if quality.get('has_business_rules') else 'Não'}
- **Indicadores de inferência:** {'Sim' if quality.get('has_inference_indicators') else 'Não'}
- **Menções CADOC:** {'Sim' if quality.get('mentions_cadoc') else 'Não'}
- **Documentação de evidências:** {'Sim' if quality.get('has_evidence_documentation') else 'Não'}

### Avaliação da Qualidade

**Score de Qualidade:** {sum(1 for v in quality.values() if isinstance(v, bool) and v)}/6

**Nível:** {'EXCELENTE' if sum(1 for v in quality.values() if isinstance(v, bool) and v) >= 5 else 'BOM' if sum(1 for v in quality.values() if isinstance(v, bool) and v) >= 3 else 'NECESSITA MELHORIA'}
"""
    
    report_content += f"""

### Logs de Execução

**Stdout:**
```
{test_result.get('stdout', 'N/A')}
```

**Stderr:**
```
{test_result.get('stderr', 'N/A')}
```

### Diretório de Teste

**Localização:** {test_result.get('test_dir', 'N/A')}

## Conclusões

### Correções Validadas:

"""
    
    if test_result['success']:
        report_content += "- ✅ Sistema executa sem erros\n"
    
    if 'TESTPROG_analise_funcional.md' in test_result.get('files_found', []):
        report_content += "- ✅ Análise funcional gerada\n"
    
    if 'ai_requests/TESTPROG_ai_request.json' in test_result.get('files_found', []):
        report_content += "- ✅ Arquivo de request gerado\n"
    
    if 'ai_responses/TESTPROG_ai_response.json' in test_result.get('files_found', []):
        report_content += "- ✅ Arquivo de response gerado\n"
    
    if test_result.get('analysis_quality', {}).get('has_copybook_analysis'):
        report_content += "- ✅ Análise de copybooks implementada\n"
    
    if test_result.get('analysis_quality', {}).get('has_inference_indicators'):
        report_content += "- ✅ Indicadores de inferência presentes\n"
    
    report_content += f"""

### Status Final:

{'✅ SISTEMA FUNCIONANDO CORRETAMENTE' if test_result['success'] and len(test_result.get('files_found', [])) >= 2 else '⚠️ SISTEMA PRECISA DE AJUSTES'}

### Próximos Passos:

1. {'Validar qualidade das análises geradas' if test_result['success'] else 'Corrigir erros de execução'}
2. {'Testar com mais programas COBOL' if test_result['success'] else 'Verificar logs de erro'}
3. {'Monitorar aprendizado automático' if test_result['success'] else 'Revisar configurações'}

---
*Relatório gerado pelo sistema de teste de execução real*
"""
    
    return report_content

def main():
    """Função principal do teste"""
    logger = setup_logging()
    
    logger.info("=== TESTE DE EXECUÇÃO REAL DO SISTEMA CORRIGIDO ===")
    
    try:
        # Executar teste real
        test_result = test_real_system_execution()
        
        # Gerar relatório
        report_content = generate_execution_report(test_result)
        
        # Salvar relatório
        report_path = "/home/ubuntu/cobol_to_docs_v1.0_final/RELATORIO_EXECUCAO_REAL.md"
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write(report_content)
        
        logger.info("=== TESTE DE EXECUÇÃO CONCLUÍDO ===")
        
        # Exibir resumo
        print(f"\n🧪 TESTE DE EXECUÇÃO REAL CONCLUÍDO!")
        print("=" * 50)
        
        print(f"\n📊 RESULTADOS:")
        print(f"   • Execução: {'✅ SUCESSO' if test_result['success'] else '❌ FALHA'}")
        print(f"   • Arquivos gerados: {len(test_result.get('files_found', []))}")
        print(f"   • Arquivos esperados: 3")
        
        if 'analysis_quality' in test_result:
            quality_score = sum(1 for v in test_result['analysis_quality'].values() if isinstance(v, bool) and v)
            print(f"   • Score de qualidade: {quality_score}/6")
        
        print(f"\n📄 RELATÓRIO COMPLETO:")
        print(f"   • {report_path}")
        
        print(f"\n📁 DIRETÓRIO DE TESTE:")
        print(f"   • {test_result.get('test_dir', 'N/A')}")
        
        return test_result
        
    except Exception as e:
        logger.error(f"Erro durante teste: {e}")
        raise

if __name__ == "__main__":
    main()
