"""
TBR GDP Core - Data Governance API

A comprehensive data governance platform providing:
- Data catalog and asset management
- Quality monitoring and validation
- Compliance and audit trails
- Data lineage tracking
- Contract management
- Integration with Databricks Unity Catalog and Informatica Axon

Version: 2.0.0
Author: Manus AI
"""

__version__ = "2.0.0"
__author__ = "Manus AI"
__email__ = "dev@manus.ai"
__description__ = "TBR GDP Core - Data Governance API"

# Package metadata
__all__ = [
    "__version__",
    "__author__",
    "__email__",
    "__description__",
]

