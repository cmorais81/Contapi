# TBR GDP Core - Data Governance API
# Windows Installation Script
# Version: 2.0.0
# Author: Manus AI

param(
    [string]$PythonVersion = "3.11",
    [string]$PostgreSQLVersion = "15",
    [switch]$SkipDependencies,
    [switch]$DevMode,
    [switch]$Verbose
)

# Set error action preference
$ErrorActionPreference = "Stop"

# Enable verbose output if requested
if ($Verbose) {
    $VerbosePreference = "Continue"
}

# Colors for output
$Colors = @{
    Red = "Red"
    Green = "Green"
    Yellow = "Yellow"
    Blue = "Blue"
    Cyan = "Cyan"
    Magenta = "Magenta"
}

function Write-ColorOutput {
    param(
        [string]$Message,
        [string]$Color = "White"
    )
    Write-Host $Message -ForegroundColor $Color
}

function Write-Header {
    param([string]$Title)
    Write-Host ""
    Write-ColorOutput "=" * 60 -Color $Colors.Blue
    Write-ColorOutput " $Title" -Color $Colors.Blue
    Write-ColorOutput "=" * 60 -Color $Colors.Blue
    Write-Host ""
}

function Write-Step {
    param([string]$Message)
    Write-ColorOutput "[INFO] $Message" -Color $Colors.Green
}

function Write-Warning {
    param([string]$Message)
    Write-ColorOutput "[WARNING] $Message" -Color $Colors.Yellow
}

function Write-Error {
    param([string]$Message)
    Write-ColorOutput "[ERROR] $Message" -Color $Colors.Red
}

function Test-Administrator {
    $currentUser = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($currentUser)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Test-CommandExists {
    param([string]$Command)
    try {
        Get-Command $Command -ErrorAction Stop | Out-Null
        return $true
    }
    catch {
        return $false
    }
}

function Install-Chocolatey {
    Write-Step "Installing Chocolatey package manager..."
    
    if (Test-CommandExists "choco") {
        Write-Step "Chocolatey is already installed."
        return
    }
    
    try {
        Set-ExecutionPolicy Bypass -Scope Process -Force
        [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072
        Invoke-Expression ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))
        
        # Refresh environment variables
        $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")
        
        Write-Step "Chocolatey installed successfully."
    }
    catch {
        Write-Error "Failed to install Chocolatey: $($_.Exception.Message)"
        throw
    }
}

function Install-Python {
    Write-Step "Installing Python $PythonVersion..."
    
    if (Test-CommandExists "python") {
        $pythonVersionOutput = python --version 2>&1
        Write-Step "Python is already installed: $pythonVersionOutput"
        return
    }
    
    try {
        choco install python --version=$PythonVersion -y
        
        # Refresh environment variables
        $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")
        
        Write-Step "Python $PythonVersion installed successfully."
    }
    catch {
        Write-Error "Failed to install Python: $($_.Exception.Message)"
        throw
    }
}

function Install-PostgreSQL {
    Write-Step "Installing PostgreSQL $PostgreSQLVersion..."
    
    if (Test-CommandExists "psql") {
        Write-Step "PostgreSQL is already installed."
        return
    }
    
    try {
        choco install postgresql$PostgreSQLVersion --params '/Password:postgres123' -y
        
        # Refresh environment variables
        $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")
        
        Write-Step "PostgreSQL $PostgreSQLVersion installed successfully."
        Write-Warning "Default password for postgres user is: postgres123"
        Write-Warning "Please change this password in production!"
    }
    catch {
        Write-Error "Failed to install PostgreSQL: $($_.Exception.Message)"
        throw
    }
}

function Install-Git {
    Write-Step "Installing Git..."
    
    if (Test-CommandExists "git") {
        Write-Step "Git is already installed."
        return
    }
    
    try {
        choco install git -y
        
        # Refresh environment variables
        $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")
        
        Write-Step "Git installed successfully."
    }
    catch {
        Write-Error "Failed to install Git: $($_.Exception.Message)"
        throw
    }
}

function Create-VirtualEnvironment {
    Write-Step "Creating Python virtual environment..."
    
    $venvPath = ".\venv"
    
    if (Test-Path $venvPath) {
        Write-Step "Virtual environment already exists."
        return
    }
    
    try {
        python -m venv $venvPath
        Write-Step "Virtual environment created successfully."
    }
    catch {
        Write-Error "Failed to create virtual environment: $($_.Exception.Message)"
        throw
    }
}

function Activate-VirtualEnvironment {
    Write-Step "Activating virtual environment..."
    
    $activateScript = ".\venv\Scripts\Activate.ps1"
    
    if (-not (Test-Path $activateScript)) {
        Write-Error "Virtual environment activation script not found: $activateScript"
        throw
    }
    
    try {
        & $activateScript
        Write-Step "Virtual environment activated."
    }
    catch {
        Write-Error "Failed to activate virtual environment: $($_.Exception.Message)"
        throw
    }
}

function Install-PythonDependencies {
    Write-Step "Installing Python dependencies..."
    
    try {
        # Upgrade pip first
        python -m pip install --upgrade pip
        
        # Install the package in development mode
        if ($DevMode) {
            python -m pip install -e ".[dev,databricks,informatica,monitoring]"
        }
        else {
            python -m pip install -e ".[databricks,informatica]"
        }
        
        Write-Step "Python dependencies installed successfully."
    }
    catch {
        Write-Error "Failed to install Python dependencies: $($_.Exception.Message)"
        throw
    }
}

function Create-DatabaseUser {
    Write-Step "Creating database user..."
    
    try {
        # Set PGPASSWORD environment variable
        $env:PGPASSWORD = "postgres123"
        
        # Create user if not exists
        $createUserSQL = @"
DO `$`$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'tbr_gdpcore_user') THEN
        CREATE USER tbr_gdpcore_user WITH PASSWORD 'tbr_gdpcore_pass';
    END IF;
END
`$`$;
"@
        
        $createUserSQL | psql -h localhost -U postgres -d postgres
        
        Write-Step "Database user created successfully."
    }
    catch {
        Write-Warning "Failed to create database user. You may need to create it manually."
        Write-Warning "SQL: CREATE USER tbr_gdpcore_user WITH PASSWORD 'tbr_gdpcore_pass';"
    }
}

function Create-Database {
    Write-Step "Creating database..."
    
    try {
        # Set PGPASSWORD environment variable
        $env:PGPASSWORD = "postgres123"
        
        # Check if database exists
        $dbExists = psql -h localhost -U postgres -d postgres -tAc "SELECT 1 FROM pg_database WHERE datname='tbr_gdpcore_dtgovapi'"
        
        if ($dbExists -eq "1") {
            Write-Step "Database already exists."
        }
        else {
            # Create database
            createdb -h localhost -U postgres tbr_gdpcore_dtgovapi
            
            # Grant privileges
            $grantSQL = @"
GRANT ALL PRIVILEGES ON DATABASE tbr_gdpcore_dtgovapi TO tbr_gdpcore_user;
"@
            $grantSQL | psql -h localhost -U postgres -d tbr_gdpcore_dtgovapi
            
            Write-Step "Database created successfully."
        }
    }
    catch {
        Write-Error "Failed to create database: $($_.Exception.Message)"
        Write-Warning "You may need to create the database manually:"
        Write-Warning "createdb -h localhost -U postgres tbr_gdpcore_dtgovapi"
        throw
    }
}

function Create-ConfigurationFile {
    Write-Step "Creating configuration file..."
    
    $configDir = ".\config"
    $envFile = "$configDir\.env"
    $templateFile = "$configDir\.env.template"
    
    # Create config directory if it doesn't exist
    if (-not (Test-Path $configDir)) {
        New-Item -ItemType Directory -Path $configDir | Out-Null
    }
    
    # Create .env file from template if it doesn't exist
    if (-not (Test-Path $envFile)) {
        if (Test-Path $templateFile) {
            Copy-Item $templateFile $envFile
        }
        else {
            # Create basic .env file
            $envContent = @"
# TBR GDP Core Configuration
# Database Configuration
DATABASE_URL=postgresql://tbr_gdpcore_user:tbr_gdpcore_pass@localhost:5432/tbr_gdpcore_dtgovapi
DATABASE_ECHO=false

# API Configuration
API_HOST=0.0.0.0
API_PORT=8000
API_DEBUG=true
API_RELOAD=true

# Security
SECRET_KEY=your-secret-key-change-this-in-production
JWT_SECRET_KEY=your-jwt-secret-change-this-in-production
JWT_ALGORITHM=HS256
JWT_EXPIRE_MINUTES=30

# External Integrations
DATABRICKS_HOST=
DATABRICKS_TOKEN=
INFORMATICA_AXON_URL=
INFORMATICA_AXON_TOKEN=

# Logging
LOG_LEVEL=INFO
LOG_FORMAT=json

# Redis (optional)
REDIS_URL=redis://localhost:6379/0
"@
            $envContent | Out-File -FilePath $envFile -Encoding UTF8
        }
        
        Write-Step "Configuration file created: $envFile"
        Write-Warning "Please review and update the configuration file with your specific settings."
    }
    else {
        Write-Step "Configuration file already exists: $envFile"
    }
}

function Run-DatabaseMigrations {
    Write-Step "Running database migrations..."
    
    try {
        # Run Alembic migrations
        alembic upgrade head
        Write-Step "Database migrations completed successfully."
    }
    catch {
        Write-Warning "Failed to run database migrations: $($_.Exception.Message)"
        Write-Warning "You may need to run migrations manually: alembic upgrade head"
    }
}

function Create-PyCharmConfiguration {
    Write-Step "Creating PyCharm configuration..."
    
    $ideaDir = ".\.idea"
    $runConfigDir = "$ideaDir\runConfigurations"
    
    # Create directories
    if (-not (Test-Path $ideaDir)) {
        New-Item -ItemType Directory -Path $ideaDir | Out-Null
    }
    if (-not (Test-Path $runConfigDir)) {
        New-Item -ItemType Directory -Path $runConfigDir | Out-Null
    }
    
    # API Server configuration
    $apiServerConfig = @"
<component name="ProjectRunConfigurationManager">
  <configuration default="false" name="API Server" type="PythonConfigurationType" factoryName="Python">
    <module name="tbr-gdpcore-dtgovapi" />
    <option name="INTERPRETER_OPTIONS" value="" />
    <option name="PARENT_ENVS" value="true" />
    <envs>
      <env name="PYTHONUNBUFFERED" value="1" />
    </envs>
    <option name="SDK_HOME" value="`$PROJECT_DIR`$/venv/Scripts/python.exe" />
    <option name="WORKING_DIRECTORY" value="`$PROJECT_DIR`$" />
    <option name="IS_MODULE_SDK" value="false" />
    <option name="ADD_CONTENT_ROOTS" value="true" />
    <option name="ADD_SOURCE_ROOTS" value="true" />
    <EXTENSION ID="PythonCoverageRunConfigurationExtension" runner="coverage.py" />
    <option name="SCRIPT_NAME" value="-m" />
    <option name="PARAMETERS" value="uvicorn tbr_gdpcore_dtgovapi.main:app --reload --host 0.0.0.0 --port 8000" />
    <option name="SHOW_COMMAND_LINE" value="false" />
    <option name="EMULATE_TERMINAL" value="false" />
    <option name="MODULE_MODE" value="true" />
    <option name="REDIRECT_INPUT" value="false" />
    <option name="INPUT_FILE" value="" />
    <method v="2" />
  </configuration>
</component>
"@
    
    $apiServerConfig | Out-File -FilePath "$runConfigDir\API_Server.xml" -Encoding UTF8
    
    # Database Migration configuration
    $migrationConfig = @"
<component name="ProjectRunConfigurationManager">
  <configuration default="false" name="Database Migration" type="PythonConfigurationType" factoryName="Python">
    <module name="tbr-gdpcore-dtgovapi" />
    <option name="INTERPRETER_OPTIONS" value="" />
    <option name="PARENT_ENVS" value="true" />
    <envs>
      <env name="PYTHONUNBUFFERED" value="1" />
    </envs>
    <option name="SDK_HOME" value="`$PROJECT_DIR`$/venv/Scripts/python.exe" />
    <option name="WORKING_DIRECTORY" value="`$PROJECT_DIR`$" />
    <option name="IS_MODULE_SDK" value="false" />
    <option name="ADD_CONTENT_ROOTS" value="true" />
    <option name="ADD_SOURCE_ROOTS" value="true" />
    <EXTENSION ID="PythonCoverageRunConfigurationExtension" runner="coverage.py" />
    <option name="SCRIPT_NAME" value="-m" />
    <option name="PARAMETERS" value="alembic upgrade head" />
    <option name="SHOW_COMMAND_LINE" value="false" />
    <option name="EMULATE_TERMINAL" value="false" />
    <option name="MODULE_MODE" value="true" />
    <option name="REDIRECT_INPUT" value="false" />
    <option name="INPUT_FILE" value="" />
    <method v="2" />
  </configuration>
</component>
"@
    
    $migrationConfig | Out-File -FilePath "$runConfigDir\Database_Migration.xml" -Encoding UTF8
    
    # Tests configuration
    $testsConfig = @"
<component name="ProjectRunConfigurationManager">
  <configuration default="false" name="Tests" type="tests" factoryName="py.test">
    <module name="tbr-gdpcore-dtgovapi" />
    <option name="INTERPRETER_OPTIONS" value="" />
    <option name="PARENT_ENVS" value="true" />
    <option name="SDK_HOME" value="`$PROJECT_DIR`$/venv/Scripts/python.exe" />
    <option name="WORKING_DIRECTORY" value="`$PROJECT_DIR`$" />
    <option name="IS_MODULE_SDK" value="false" />
    <option name="ADD_CONTENT_ROOTS" value="true" />
    <option name="ADD_SOURCE_ROOTS" value="true" />
    <EXTENSION ID="PythonCoverageRunConfigurationExtension" runner="coverage.py" />
    <option name="_new_keywords" value="&quot;&quot;" />
    <option name="_new_parameters" value="&quot;&quot;" />
    <option name="_new_additionalArguments" value="&quot;&quot;" />
    <option name="_new_target" value="&quot;`$PROJECT_DIR`$/tests&quot;" />
    <option name="_new_targetType" value="&quot;PATH&quot;" />
    <method v="2" />
  </configuration>
</component>
"@
    
    $testsConfig | Out-File -FilePath "$runConfigDir\Tests.xml" -Encoding UTF8
    
    Write-Step "PyCharm run configurations created successfully."
}

function Test-Installation {
    Write-Step "Testing installation..."
    
    try {
        # Test Python import
        python -c "import tbr_gdpcore_dtgovapi; print('Package import successful')"
        
        # Test database connection
        python -c "
from tbr_gdpcore_dtgovapi.core.database import get_database_url
from sqlalchemy import create_engine, text
engine = create_engine(get_database_url())
with engine.connect() as conn:
    result = conn.execute(text('SELECT 1'))
    print('Database connection successful')
"
        
        Write-Step "Installation test completed successfully."
    }
    catch {
        Write-Warning "Installation test failed: $($_.Exception.Message)"
        Write-Warning "Please check the configuration and try running the tests manually."
    }
}

function Show-NextSteps {
    Write-Header "Installation Complete!"
    
    Write-ColorOutput "Next steps:" -Color $Colors.Yellow
    Write-Host ""
    Write-ColorOutput "1. Review configuration file:" -Color $Colors.Cyan
    Write-Host "   .\config\.env"
    Write-Host ""
    Write-ColorOutput "2. Open project in PyCharm:" -Color $Colors.Cyan
    Write-Host "   - File -> Open -> Select this folder"
    Write-Host "   - Configure Python interpreter: .\venv\Scripts\python.exe"
    Write-Host ""
    Write-ColorOutput "3. Run the API server:" -Color $Colors.Cyan
    Write-Host "   - Use 'API Server' run configuration in PyCharm"
    Write-Host "   - Or run: .\venv\Scripts\Activate.ps1; uvicorn tbr_gdpcore_dtgovapi.main:app --reload"
    Write-Host ""
    Write-ColorOutput "4. Access the API documentation:" -Color $Colors.Cyan
    Write-Host "   - Swagger UI: http://localhost:8000/docs"
    Write-Host "   - ReDoc: http://localhost:8000/redoc"
    Write-Host ""
    Write-ColorOutput "5. Run tests:" -Color $Colors.Cyan
    Write-Host "   - Use 'Tests' run configuration in PyCharm"
    Write-Host "   - Or run: .\venv\Scripts\Activate.ps1; pytest"
    Write-Host ""
    Write-ColorOutput "For more information, see:" -Color $Colors.Magenta
    Write-Host "   - README.md"
    Write-Host "   - docs/setup/windows-pycharm.md"
    Write-Host ""
}

# Main installation function
function Main {
    Write-Header "TBR GDP Core - Data Governance API Installation"
    Write-ColorOutput "Version: 2.0.0" -Color $Colors.Blue
    Write-ColorOutput "Author: Manus AI" -Color $Colors.Blue
    Write-Host ""
    
    # Check if running as administrator
    if (-not (Test-Administrator)) {
        Write-Warning "This script should be run as Administrator for best results."
        Write-Warning "Some features may not work properly without administrator privileges."
        $continue = Read-Host "Continue anyway? (y/N)"
        if ($continue -ne "y" -and $continue -ne "Y") {
            Write-ColorOutput "Installation cancelled." -Color $Colors.Red
            exit 1
        }
    }
    
    try {
        # Install dependencies
        if (-not $SkipDependencies) {
            Install-Chocolatey
            Install-Python
            Install-PostgreSQL
            Install-Git
        }
        
        # Setup Python environment
        Create-VirtualEnvironment
        Activate-VirtualEnvironment
        Install-PythonDependencies
        
        # Setup database
        Create-DatabaseUser
        Create-Database
        
        # Create configuration
        Create-ConfigurationFile
        
        # Run migrations
        Run-DatabaseMigrations
        
        # Create PyCharm configuration
        Create-PyCharmConfiguration
        
        # Test installation
        Test-Installation
        
        # Show next steps
        Show-NextSteps
        
        Write-ColorOutput "Installation completed successfully!" -Color $Colors.Green
    }
    catch {
        Write-Error "Installation failed: $($_.Exception.Message)"
        Write-ColorOutput "Please check the error messages above and try again." -Color $Colors.Red
        exit 1
    }
}

# Run main function
Main

