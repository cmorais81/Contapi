"""
TBR GDP Core - Health Check Endpoints
"""

import asyncio
import platform
import sys
from datetime import datetime, timezone
from typing import Dict, Any

import psutil
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
import structlog

from tbr_gdpcore_dtgovapi.core.config import get_settings
from tbr_gdpcore_dtgovapi.core.database import check_database_health, get_database_stats

logger = structlog.get_logger(__name__)
router = APIRouter()
settings = get_settings()


class HealthResponse(BaseModel):
    """Health check response model"""
    status: str
    timestamp: datetime
    version: str
    uptime_seconds: float
    checks: Dict[str, Any]


class SystemInfo(BaseModel):
    """System information model"""
    python_version: str
    platform: str
    architecture: str
    hostname: str
    cpu_count: int
    memory_total_gb: float
    memory_available_gb: float
    memory_usage_percent: float
    disk_usage_percent: float


class DatabaseStats(BaseModel):
    """Database statistics model"""
    status: str
    response_time_ms: float
    table_counts: Dict[str, int]


# Store startup time
startup_time = datetime.now(timezone.utc)


@router.get("/", response_model=HealthResponse)
async def health_check():
    """
    Basic health check endpoint
    
    Returns the overall health status of the application including:
    - Application status
    - Database connectivity
    - System resources
    - Uptime information
    """
    try:
        current_time = datetime.now(timezone.utc)
        uptime = (current_time - startup_time).total_seconds()
        
        # Check database health
        db_health = await check_database_health()
        
        # Check system resources
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        
        # Determine overall status
        overall_status = "healthy"
        checks = {
            "database": db_health,
            "memory": {
                "status": "healthy" if memory.percent < 90 else "warning",
                "usage_percent": memory.percent,
                "available_gb": round(memory.available / (1024**3), 2)
            },
            "disk": {
                "status": "healthy" if disk.percent < 90 else "warning", 
                "usage_percent": disk.percent,
                "free_gb": round(disk.free / (1024**3), 2)
            }
        }
        
        # Check if any component is unhealthy
        if db_health["status"] != "healthy":
            overall_status = "unhealthy"
        elif any(check.get("status") == "warning" for check in checks.values() if isinstance(check, dict)):
            overall_status = "warning"
        
        return HealthResponse(
            status=overall_status,
            timestamp=current_time,
            version="2.0.0",
            uptime_seconds=uptime,
            checks=checks
        )
        
    except Exception as e:
        logger.error("Health check failed", error=str(e))
        raise HTTPException(status_code=503, detail="Health check failed")


@router.get("/ready")
async def readiness_check():
    """
    Readiness check endpoint for Kubernetes
    
    Returns 200 if the application is ready to serve traffic
    """
    try:
        # Check database connectivity
        db_health = await check_database_health()
        
        if db_health["status"] != "healthy":
            raise HTTPException(status_code=503, detail="Database not ready")
        
        return {"status": "ready", "timestamp": datetime.now(timezone.utc)}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Readiness check failed", error=str(e))
        raise HTTPException(status_code=503, detail="Application not ready")


@router.get("/live")
async def liveness_check():
    """
    Liveness check endpoint for Kubernetes
    
    Returns 200 if the application is alive (basic functionality)
    """
    return {
        "status": "alive",
        "timestamp": datetime.now(timezone.utc),
        "uptime_seconds": (datetime.now(timezone.utc) - startup_time).total_seconds()
    }


@router.get("/system", response_model=SystemInfo)
async def system_info():
    """
    Get detailed system information
    
    Returns comprehensive system metrics and information
    """
    try:
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        
        return SystemInfo(
            python_version=sys.version,
            platform=platform.platform(),
            architecture=platform.architecture()[0],
            hostname=platform.node(),
            cpu_count=psutil.cpu_count(),
            memory_total_gb=round(memory.total / (1024**3), 2),
            memory_available_gb=round(memory.available / (1024**3), 2),
            memory_usage_percent=memory.percent,
            disk_usage_percent=disk.percent
        )
        
    except Exception as e:
        logger.error("Failed to get system info", error=str(e))
        raise HTTPException(status_code=500, detail="Failed to get system information")


@router.get("/database", response_model=DatabaseStats)
async def database_status():
    """
    Get detailed database status and statistics
    
    Returns database connectivity status and table counts
    """
    try:
        # Check database health
        db_health = await check_database_health()
        
        # Get table statistics
        table_stats = await get_database_stats()
        
        return DatabaseStats(
            status=db_health["status"],
            response_time_ms=db_health.get("response_time_ms", 0),
            table_counts=table_stats
        )
        
    except Exception as e:
        logger.error("Failed to get database status", error=str(e))
        raise HTTPException(status_code=500, detail="Failed to get database status")


@router.get("/config")
async def configuration_info():
    """
    Get non-sensitive configuration information
    
    Returns current application configuration (excluding secrets)
    """
    try:
        return {
            "api_host": settings.API_HOST,
            "api_port": settings.API_PORT,
            "api_debug": settings.API_DEBUG,
            "log_level": settings.LOG_LEVEL,
            "database_echo": settings.DATABASE_ECHO,
            "cors_origins": settings.CORS_ORIGINS,
            "metrics_enabled": settings.METRICS_ENABLED,
            "sync_enabled": settings.SYNC_ENABLED,
            "sync_interval_minutes": settings.SYNC_INTERVAL_MINUTES,
            "cache_enabled": settings.CACHE_ENABLED,
            "cache_ttl": settings.CACHE_TTL,
            "dev_mode": settings.DEV_MODE,
            "integrations": {
                "databricks_configured": bool(settings.DATABRICKS_HOST),
                "informatica_configured": bool(settings.INFORMATICA_AXON_URL),
                "redis_configured": bool(settings.REDIS_URL),
                "smtp_configured": bool(settings.SMTP_HOST)
            }
        }
        
    except Exception as e:
        logger.error("Failed to get configuration info", error=str(e))
        raise HTTPException(status_code=500, detail="Failed to get configuration information")


@router.get("/version")
async def version_info():
    """
    Get application version information
    
    Returns version details and build information
    """
    return {
        "version": "2.0.0",
        "name": "TBR GDP Core - Data Governance API",
        "description": "Comprehensive data governance platform",
        "author": "Manus AI",
        "python_version": sys.version_info[:3],
        "build_date": "2025-01-07",
        "git_commit": "latest",  # This would be populated by CI/CD
        "environment": "development" if settings.DEV_MODE else "production"
    }

