"""
TBR GDP Core - Database Configuration and Management
"""

import asyncio
from contextlib import asynccontextmanager
from typing import AsyncGenerator, Optional

from sqlalchemy import create_engine, MetaData, text
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine, async_sessionmaker
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.pool import StaticPool
import structlog

from tbr_gdpcore_dtgovapi.core.config import get_settings, is_testing

logger = structlog.get_logger(__name__)

# Get settings
settings = get_settings()

# Database URL conversion for async
def get_async_database_url() -> str:
    """Convert sync database URL to async"""
    url = settings.DATABASE_URL
    if url.startswith("postgresql://"):
        return url.replace("postgresql://", "postgresql+asyncpg://", 1)
    elif url.startswith("sqlite://"):
        return url.replace("sqlite://", "sqlite+aiosqlite://", 1)
    return url

# Create engines
if is_testing():
    # Use in-memory SQLite for testing
    SQLALCHEMY_DATABASE_URL = "sqlite+aiosqlite:///:memory:"
    async_engine = create_async_engine(
        SQLALCHEMY_DATABASE_URL,
        echo=settings.DATABASE_ECHO,
        poolclass=StaticPool,
        connect_args={"check_same_thread": False}
    )
    sync_engine = create_engine(
        "sqlite:///:memory:",
        echo=settings.DATABASE_ECHO,
        poolclass=StaticPool,
        connect_args={"check_same_thread": False}
    )
else:
    # Use PostgreSQL for production/development
    async_engine = create_async_engine(
        get_async_database_url(),
        echo=settings.DATABASE_ECHO,
        pool_size=settings.DATABASE_POOL_SIZE,
        max_overflow=settings.DATABASE_MAX_OVERFLOW,
        pool_pre_ping=True,
        pool_recycle=3600,
    )
    sync_engine = create_engine(
        settings.DATABASE_URL,
        echo=settings.DATABASE_ECHO,
        pool_size=settings.DATABASE_POOL_SIZE,
        max_overflow=settings.DATABASE_MAX_OVERFLOW,
        pool_pre_ping=True,
        pool_recycle=3600,
    )

# Create session makers
AsyncSessionLocal = async_sessionmaker(
    bind=async_engine,
    class_=AsyncSession,
    expire_on_commit=False,
    autocommit=False,
    autoflush=False,
)

SessionLocal = sessionmaker(
    bind=sync_engine,
    autocommit=False,
    autoflush=False,
)

# Create declarative base
Base = declarative_base()

# Metadata for migrations
metadata = MetaData(
    naming_convention={
        "ix": "ix_%(column_0_label)s",
        "uq": "uq_%(table_name)s_%(column_0_name)s",
        "ck": "ck_%(table_name)s_%(constraint_name)s",
        "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
        "pk": "pk_%(table_name)s"
    }
)

Base.metadata = metadata


# Database session dependency
async def get_async_session() -> AsyncGenerator[AsyncSession, None]:
    """Get async database session"""
    async with AsyncSessionLocal() as session:
        try:
            yield session
        except Exception as e:
            await session.rollback()
            logger.error("Database session error", error=str(e))
            raise
        finally:
            await session.close()


def get_sync_session() -> Session:
    """Get sync database session"""
    session = SessionLocal()
    try:
        return session
    except Exception as e:
        session.rollback()
        logger.error("Database session error", error=str(e))
        raise
    finally:
        session.close()


@asynccontextmanager
async def get_session() -> AsyncGenerator[AsyncSession, None]:
    """Context manager for database session"""
    async with AsyncSessionLocal() as session:
        try:
            yield session
            await session.commit()
        except Exception as e:
            await session.rollback()
            logger.error("Database transaction error", error=str(e))
            raise
        finally:
            await session.close()


# Database initialization
async def init_database():
    """Initialize database"""
    try:
        logger.info("Initializing database connection")
        
        # Test connection
        async with async_engine.begin() as conn:
            # Enable UUID extension for PostgreSQL
            if not is_testing():
                try:
                    await conn.execute(text('CREATE EXTENSION IF NOT EXISTS "uuid-ossp"'))
                    logger.info("UUID extension enabled")
                except Exception as e:
                    logger.warning("Could not enable UUID extension", error=str(e))
            
            # Test basic query
            result = await conn.execute(text("SELECT 1"))
            assert result.scalar() == 1
            
        logger.info("Database connection established successfully")
        
    except Exception as e:
        logger.error("Failed to initialize database", error=str(e))
        raise


async def close_database():
    """Close database connections"""
    try:
        logger.info("Closing database connections")
        await async_engine.dispose()
        sync_engine.dispose()
        logger.info("Database connections closed")
    except Exception as e:
        logger.error("Error closing database connections", error=str(e))


# Health check
async def check_database_health() -> dict:
    """Check database health"""
    try:
        async with async_engine.begin() as conn:
            start_time = asyncio.get_event_loop().time()
            await conn.execute(text("SELECT 1"))
            end_time = asyncio.get_event_loop().time()
            
            response_time = (end_time - start_time) * 1000  # Convert to milliseconds
            
            return {
                "status": "healthy",
                "response_time_ms": round(response_time, 2),
                "database_url": settings.DATABASE_URL.split("@")[1] if "@" in settings.DATABASE_URL else "unknown"
            }
    except Exception as e:
        logger.error("Database health check failed", error=str(e))
        return {
            "status": "unhealthy",
            "error": str(e),
            "database_url": settings.DATABASE_URL.split("@")[1] if "@" in settings.DATABASE_URL else "unknown"
        }


# Database utilities
async def execute_raw_sql(sql: str, params: Optional[dict] = None) -> list:
    """Execute raw SQL query"""
    async with get_session() as session:
        result = await session.execute(text(sql), params or {})
        return result.fetchall()


async def get_table_count(table_name: str) -> int:
    """Get count of records in a table"""
    async with get_session() as session:
        result = await session.execute(text(f"SELECT COUNT(*) FROM {table_name}"))
        return result.scalar()


async def get_database_stats() -> dict:
    """Get database statistics"""
    try:
        stats = {}
        
        # Core tables
        core_tables = [
            "data_catalogs",
            "data_schemas", 
            "data_assets",
            "data_columns",
            "business_domains",
            "business_terms",
            "data_processes",
            "data_lineage",
            "data_quality_rules",
            "data_quality_executions",
            "data_quality_metrics",
            "users",
            "data_owners",
            "data_stewards"
        ]
        
        for table in core_tables:
            try:
                count = await get_table_count(table)
                stats[table] = count
            except Exception as e:
                logger.warning(f"Could not get count for table {table}", error=str(e))
                stats[table] = -1
        
        return stats
        
    except Exception as e:
        logger.error("Failed to get database stats", error=str(e))
        return {"error": str(e)}


# Transaction decorator
def transactional(func):
    """Decorator for transactional operations"""
    async def wrapper(*args, **kwargs):
        async with get_session() as session:
            try:
                result = await func(session, *args, **kwargs)
                await session.commit()
                return result
            except Exception as e:
                await session.rollback()
                logger.error("Transaction failed", error=str(e), function=func.__name__)
                raise
    return wrapper


# Database migration utilities
def get_migration_engine():
    """Get engine for Alembic migrations"""
    return sync_engine


def get_migration_url():
    """Get database URL for Alembic migrations"""
    return settings.DATABASE_URL

