#!/bin/bash

# Data Governance Package Installation Script
# Version: 2.0
# Author: Manus AI
# Description: Automated installation script for data governance package

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
DB_HOST=${DB_HOST:-localhost}
DB_PORT=${DB_PORT:-5432}
DB_NAME=${DB_NAME:-data_governance}
DB_USER=${DB_USER:-postgres}
DB_PASSWORD=${DB_PASSWORD:-}
INSTALL_DIR=${INSTALL_DIR:-/opt/data_governance}

echo -e "${BLUE}=== Data Governance Package Installation ===${NC}"
echo -e "${BLUE}Version: 2.0${NC}"
echo -e "${BLUE}Author: Manus AI${NC}"
echo ""

# Function to print status messages
print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Function to check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Check prerequisites
check_prerequisites() {
    print_status "Checking prerequisites..."
    
    # Check for PostgreSQL client
    if ! command_exists psql; then
        print_error "PostgreSQL client (psql) is required but not installed."
        print_status "Please install PostgreSQL client and try again."
        exit 1
    fi
    
    # Check for Python
    if ! command_exists python3; then
        print_error "Python 3 is required but not installed."
        exit 1
    fi
    
    # Check for pip
    if ! command_exists pip3; then
        print_error "pip3 is required but not installed."
        exit 1
    fi
    
    print_status "Prerequisites check completed successfully."
}

# Create database schema
create_database_schema() {
    print_status "Creating database schema..."
    
    # Check if database exists
    if ! PGPASSWORD=$DB_PASSWORD psql -h $DB_HOST -p $DB_PORT -U $DB_USER -lqt | cut -d \| -f 1 | grep -qw $DB_NAME; then
        print_status "Creating database: $DB_NAME"
        PGPASSWORD=$DB_PASSWORD createdb -h $DB_HOST -p $DB_PORT -U $DB_USER $DB_NAME
    else
        print_status "Database $DB_NAME already exists."
    fi
    
    # Execute DBML schema (converted to SQL)
    print_status "Creating tables from DBML schema..."
    
    # Note: In a real implementation, you would convert the DBML to SQL
    # For now, we'll create a placeholder
    cat > /tmp/schema.sql << 'EOF'
-- Data Governance Schema
-- This is a placeholder - in production, convert the DBML to SQL

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create schemas
CREATE SCHEMA IF NOT EXISTS governance;
CREATE SCHEMA IF NOT EXISTS metadata;
CREATE SCHEMA IF NOT EXISTS quality;
CREATE SCHEMA IF NOT EXISTS compliance;

-- Set search path
SET search_path TO governance, metadata, quality, compliance, public;

-- Example table creation (replace with actual DBML conversion)
CREATE TABLE IF NOT EXISTS data_catalogs (
    id VARCHAR(36) PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL UNIQUE,
    display_name VARCHAR(255),
    description TEXT,
    catalog_type VARCHAR(50) NOT NULL,
    connection_string VARCHAR(500),
    configuration_json TEXT,
    is_default BOOLEAN DEFAULT FALSE,
    status VARCHAR(20) DEFAULT 'active',
    data_criacao TIMESTAMP DEFAULT NOW() NOT NULL,
    data_atualizacao TIMESTAMP DEFAULT NOW() NOT NULL
);

-- Add more tables here based on the DBML model...

COMMENT ON TABLE data_catalogs IS 'Data catalogs management table';
EOF
    
    PGPASSWORD=$DB_PASSWORD psql -h $DB_HOST -p $DB_PORT -U $DB_USER -d $DB_NAME -f /tmp/schema.sql
    rm /tmp/schema.sql
    
    print_status "Database schema created successfully."
}

# Install Python dependencies
install_python_dependencies() {
    print_status "Installing Python dependencies..."
    
    cat > /tmp/requirements.txt << 'EOF'
psycopg2-binary>=2.9.0
sqlalchemy>=1.4.0
pydantic>=1.8.0
fastapi>=0.68.0
uvicorn>=0.15.0
pandas>=1.3.0
numpy>=1.21.0
requests>=2.26.0
pyyaml>=5.4.0
python-dotenv>=0.19.0
alembic>=1.7.0
pytest>=6.2.0
black>=21.7.0
flake8>=3.9.0
EOF
    
    pip3 install -r /tmp/requirements.txt
    rm /tmp/requirements.txt
    
    print_status "Python dependencies installed successfully."
}

# Create configuration files
create_configuration() {
    print_status "Creating configuration files..."
    
    # Create main configuration directory
    mkdir -p $INSTALL_DIR/config
    
    # Create environment configuration
    cat > $INSTALL_DIR/config/.env.template << EOF
# Data Governance Configuration Template
# Copy this file to .env and update with your values

# Database Configuration
DB_HOST=$DB_HOST
DB_PORT=$DB_PORT
DB_NAME=$DB_NAME
DB_USER=$DB_USER
DB_PASSWORD=your_password_here

# Application Configuration
APP_NAME=Data Governance Platform
APP_VERSION=2.0
DEBUG=false
LOG_LEVEL=INFO

# Security Configuration
SECRET_KEY=your_secret_key_here
JWT_SECRET=your_jwt_secret_here
JWT_EXPIRATION_HOURS=24

# External System Integration
DATABRICKS_HOST=
DATABRICKS_TOKEN=
INFORMATICA_AXON_URL=
INFORMATICA_AXON_TOKEN=

# Monitoring Configuration
ENABLE_METRICS=true
METRICS_PORT=9090
HEALTH_CHECK_INTERVAL=60

# Notification Configuration
SMTP_HOST=
SMTP_PORT=587
SMTP_USER=
SMTP_PASSWORD=
SLACK_WEBHOOK_URL=

# Storage Configuration
FILE_STORAGE_PATH=/var/lib/data_governance/files
BACKUP_PATH=/var/lib/data_governance/backups
LOG_PATH=/var/log/data_governance
EOF
    
    # Create logging configuration
    cat > $INSTALL_DIR/config/logging.yaml << 'EOF'
version: 1
disable_existing_loggers: false

formatters:
  standard:
    format: '%(asctime)s [%(levelname)s] %(name)s: %(message)s'
  detailed:
    format: '%(asctime)s [%(levelname)s] %(name)s [%(filename)s:%(lineno)d]: %(message)s'

handlers:
  console:
    class: logging.StreamHandler
    level: INFO
    formatter: standard
    stream: ext://sys.stdout
  
  file:
    class: logging.handlers.RotatingFileHandler
    level: DEBUG
    formatter: detailed
    filename: /var/log/data_governance/app.log
    maxBytes: 10485760  # 10MB
    backupCount: 5
  
  error_file:
    class: logging.handlers.RotatingFileHandler
    level: ERROR
    formatter: detailed
    filename: /var/log/data_governance/error.log
    maxBytes: 10485760  # 10MB
    backupCount: 5

loggers:
  data_governance:
    level: DEBUG
    handlers: [console, file, error_file]
    propagate: false

root:
  level: INFO
  handlers: [console, file]
EOF
    
    print_status "Configuration files created successfully."
}

# Create systemd service
create_systemd_service() {
    print_status "Creating systemd service..."
    
    cat > /tmp/data-governance.service << EOF
[Unit]
Description=Data Governance Platform
After=network.target postgresql.service
Requires=postgresql.service

[Service]
Type=simple
User=data-governance
Group=data-governance
WorkingDirectory=$INSTALL_DIR
Environment=PATH=/usr/local/bin:/usr/bin:/bin
Environment=PYTHONPATH=$INSTALL_DIR
ExecStart=/usr/bin/python3 -m data_governance.main
ExecReload=/bin/kill -HUP \$MAINPID
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF
    
    if [ -d "/etc/systemd/system" ]; then
        sudo mv /tmp/data-governance.service /etc/systemd/system/
        sudo systemctl daemon-reload
        print_status "Systemd service created successfully."
    else
        print_warning "Systemd not available. Service file saved to /tmp/data-governance.service"
    fi
}

# Create user and directories
setup_user_and_directories() {
    print_status "Setting up user and directories..."
    
    # Create user if it doesn't exist
    if ! id "data-governance" &>/dev/null; then
        sudo useradd -r -s /bin/false data-governance
        print_status "Created user: data-governance"
    fi
    
    # Create directories
    sudo mkdir -p $INSTALL_DIR
    sudo mkdir -p /var/lib/data_governance/{files,backups}
    sudo mkdir -p /var/log/data_governance
    
    # Set permissions
    sudo chown -R data-governance:data-governance $INSTALL_DIR
    sudo chown -R data-governance:data-governance /var/lib/data_governance
    sudo chown -R data-governance:data-governance /var/log/data_governance
    
    print_status "User and directories setup completed."
}

# Install validation scripts
install_validation_scripts() {
    print_status "Installing validation scripts..."
    
    mkdir -p $INSTALL_DIR/scripts/validation
    
    cat > $INSTALL_DIR/scripts/validation/validate_installation.py << 'EOF'
#!/usr/bin/env python3
"""
Data Governance Installation Validation Script
"""

import os
import sys
import psycopg2
from psycopg2 import sql
import yaml
from dotenv import load_dotenv

def load_config():
    """Load configuration from environment file."""
    env_path = os.path.join(os.path.dirname(__file__), '../../config/.env')
    if os.path.exists(env_path):
        load_dotenv(env_path)
    return {
        'db_host': os.getenv('DB_HOST', 'localhost'),
        'db_port': os.getenv('DB_PORT', '5432'),
        'db_name': os.getenv('DB_NAME', 'data_governance'),
        'db_user': os.getenv('DB_USER', 'postgres'),
        'db_password': os.getenv('DB_PASSWORD', ''),
    }

def test_database_connection(config):
    """Test database connection and schema."""
    try:
        conn = psycopg2.connect(
            host=config['db_host'],
            port=config['db_port'],
            database=config['db_name'],
            user=config['db_user'],
            password=config['db_password']
        )
        
        cursor = conn.cursor()
        
        # Test basic connectivity
        cursor.execute("SELECT version();")
        version = cursor.fetchone()
        print(f"✓ Database connection successful: {version[0]}")
        
        # Test schema existence
        cursor.execute("""
            SELECT table_name 
            FROM information_schema.tables 
            WHERE table_schema = 'public' 
            AND table_name = 'data_catalogs'
        """)
        
        if cursor.fetchone():
            print("✓ Database schema exists")
        else:
            print("✗ Database schema not found")
            return False
        
        cursor.close()
        conn.close()
        return True
        
    except Exception as e:
        print(f"✗ Database connection failed: {e}")
        return False

def test_file_permissions():
    """Test file permissions and directory structure."""
    directories = [
        '/var/lib/data_governance',
        '/var/log/data_governance',
        '/opt/data_governance'
    ]
    
    for directory in directories:
        if os.path.exists(directory):
            if os.access(directory, os.R_OK | os.W_OK):
                print(f"✓ Directory accessible: {directory}")
            else:
                print(f"✗ Directory not accessible: {directory}")
                return False
        else:
            print(f"✗ Directory not found: {directory}")
            return False
    
    return True

def main():
    """Main validation function."""
    print("Data Governance Installation Validation")
    print("=" * 40)
    
    config = load_config()
    
    # Test database
    db_ok = test_database_connection(config)
    
    # Test file permissions
    files_ok = test_file_permissions()
    
    # Overall result
    if db_ok and files_ok:
        print("\n✓ Installation validation successful!")
        return 0
    else:
        print("\n✗ Installation validation failed!")
        return 1

if __name__ == "__main__":
    sys.exit(main())
EOF
    
    chmod +x $INSTALL_DIR/scripts/validation/validate_installation.py
    
    print_status "Validation scripts installed successfully."
}

# Main installation function
main() {
    echo -e "${BLUE}Starting installation process...${NC}"
    
    # Check if running as root for system-level operations
    if [[ $EUID -eq 0 ]]; then
        print_warning "Running as root. This is recommended for system-wide installation."
    else
        print_warning "Not running as root. Some operations may require sudo."
    fi
    
    # Run installation steps
    check_prerequisites
    setup_user_and_directories
    create_configuration
    install_python_dependencies
    create_database_schema
    install_validation_scripts
    create_systemd_service
    
    echo ""
    echo -e "${GREEN}=== Installation completed successfully! ===${NC}"
    echo ""
    echo -e "${YELLOW}Next steps:${NC}"
    echo "1. Copy $INSTALL_DIR/config/.env.template to $INSTALL_DIR/config/.env"
    echo "2. Update the configuration values in .env file"
    echo "3. Run validation: python3 $INSTALL_DIR/scripts/validation/validate_installation.py"
    echo "4. Start the service: sudo systemctl start data-governance"
    echo "5. Enable auto-start: sudo systemctl enable data-governance"
    echo ""
    echo -e "${BLUE}For more information, see the documentation in docs/ directory.${NC}"
}

# Run main function
main "$@"

