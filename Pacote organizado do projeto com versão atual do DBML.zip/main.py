"""
TBR GDP Core - Data Governance API
Main FastAPI application module
"""

import logging
import sys
from contextlib import asynccontextmanager
from typing import Dict, Any

import uvicorn
from fastapi import FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.responses import JSONResponse
from prometheus_client import generate_latest, CONTENT_TYPE_LATEST
import structlog

from tbr_gdpcore_dtgovapi.core.config import get_settings
from tbr_gdpcore_dtgovapi.core.database import init_database, close_database
from tbr_gdpcore_dtgovapi.api.endpoints import (
    health,
    catalogs,
    assets,
    quality,
    lineage,
    governance,
    contracts,
    monitoring,
    users,
    auth
)

# Configure structured logging
structlog.configure(
    processors=[
        structlog.stdlib.filter_by_level,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.add_log_level,
        structlog.stdlib.PositionalArgumentsFormatter(),
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        structlog.processors.UnicodeDecoder(),
        structlog.processors.JSONRenderer()
    ],
    context_class=dict,
    logger_factory=structlog.stdlib.LoggerFactory(),
    wrapper_class=structlog.stdlib.BoundLogger,
    cache_logger_on_first_use=True,
)

logger = structlog.get_logger(__name__)

# Get application settings
settings = get_settings()


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan manager"""
    # Startup
    logger.info("Starting TBR GDP Core API", version="2.0.0")
    
    try:
        # Initialize database
        await init_database()
        logger.info("Database initialized successfully")
        
        # Additional startup tasks can be added here
        # - Initialize external integrations
        # - Start background tasks
        # - Load configuration
        
        yield
        
    except Exception as e:
        logger.error("Failed to start application", error=str(e))
        raise
    finally:
        # Shutdown
        logger.info("Shutting down TBR GDP Core API")
        await close_database()
        logger.info("Database connections closed")


# Create FastAPI application
app = FastAPI(
    title="TBR GDP Core - Data Governance API",
    description="""
    ## TBR GDP Core - Data Governance API
    
    A comprehensive data governance platform providing:
    
    ### Core Features
    - **Data Catalog**: Centralized metadata management
    - **Quality Monitoring**: Real-time data quality assessment
    - **Compliance**: Regulatory compliance tracking
    - **Data Lineage**: End-to-end data flow tracking
    - **Contracts**: Data contract management and SLA monitoring
    - **Access Control**: Fine-grained permission management
    
    ### Integrations
    - **Databricks Unity Catalog**: Native integration
    - **Informatica Axon**: Glossary and policy sync
    - **Multiple Cloud Providers**: AWS, Azure, GCP support
    
    ### API Features
    - **RESTful API**: Standard HTTP methods
    - **Authentication**: JWT-based security
    - **Rate Limiting**: Request throttling
    - **Monitoring**: Prometheus metrics
    - **Documentation**: Interactive API docs
    
    For more information, visit our [documentation](https://github.com/manus-ai/tbr-gdpcore-dtgovapi).
    """,
    version="2.0.0",
    contact={
        "name": "Manus AI",
        "email": "dev@manus.ai",
        "url": "https://manus.ai",
    },
    license_info={
        "name": "MIT License",
        "url": "https://opensource.org/licenses/MIT",
    },
    openapi_tags=[
        {
            "name": "health",
            "description": "Health check and system status endpoints"
        },
        {
            "name": "auth",
            "description": "Authentication and authorization"
        },
        {
            "name": "catalogs",
            "description": "Data catalog management"
        },
        {
            "name": "assets",
            "description": "Data asset operations"
        },
        {
            "name": "quality",
            "description": "Data quality monitoring and rules"
        },
        {
            "name": "lineage",
            "description": "Data lineage tracking"
        },
        {
            "name": "governance",
            "description": "Governance policies and compliance"
        },
        {
            "name": "contracts",
            "description": "Data contracts and SLA management"
        },
        {
            "name": "monitoring",
            "description": "Monitoring, alerts, and incidents"
        },
        {
            "name": "users",
            "description": "User and permission management"
        }
    ],
    lifespan=lifespan,
    docs_url="/docs" if settings.API_DEBUG else None,
    redoc_url="/redoc" if settings.API_DEBUG else None,
)

# Add middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.add_middleware(
    TrustedHostMiddleware,
    allowed_hosts=settings.ALLOWED_HOSTS
)


# Custom middleware for request logging
@app.middleware("http")
async def log_requests(request: Request, call_next):
    """Log all HTTP requests"""
    start_time = request.state.start_time = request.headers.get("x-request-start")
    
    # Log request
    logger.info(
        "Request started",
        method=request.method,
        url=str(request.url),
        client_ip=request.client.host if request.client else None,
        user_agent=request.headers.get("user-agent"),
    )
    
    try:
        response = await call_next(request)
        
        # Log response
        logger.info(
            "Request completed",
            method=request.method,
            url=str(request.url),
            status_code=response.status_code,
            client_ip=request.client.host if request.client else None,
        )
        
        return response
        
    except Exception as e:
        logger.error(
            "Request failed",
            method=request.method,
            url=str(request.url),
            error=str(e),
            client_ip=request.client.host if request.client else None,
        )
        raise


# Exception handlers
@app.exception_handler(404)
async def not_found_handler(request: Request, exc):
    """Handle 404 errors"""
    return JSONResponse(
        status_code=404,
        content={
            "error": "Not Found",
            "message": "The requested resource was not found",
            "path": str(request.url.path)
        }
    )


@app.exception_handler(500)
async def internal_error_handler(request: Request, exc):
    """Handle 500 errors"""
    logger.error("Internal server error", error=str(exc), path=str(request.url.path))
    return JSONResponse(
        status_code=500,
        content={
            "error": "Internal Server Error",
            "message": "An unexpected error occurred"
        }
    )


# Prometheus metrics endpoint
@app.get("/metrics", include_in_schema=False)
async def metrics():
    """Prometheus metrics endpoint"""
    return Response(
        content=generate_latest(),
        media_type=CONTENT_TYPE_LATEST
    )


# Include API routers
app.include_router(health.router, prefix="/health", tags=["health"])
app.include_router(auth.router, prefix="/auth", tags=["auth"])
app.include_router(catalogs.router, prefix="/api/v1/catalogs", tags=["catalogs"])
app.include_router(assets.router, prefix="/api/v1/assets", tags=["assets"])
app.include_router(quality.router, prefix="/api/v1/quality", tags=["quality"])
app.include_router(lineage.router, prefix="/api/v1/lineage", tags=["lineage"])
app.include_router(governance.router, prefix="/api/v1/governance", tags=["governance"])
app.include_router(contracts.router, prefix="/api/v1/contracts", tags=["contracts"])
app.include_router(monitoring.router, prefix="/api/v1/monitoring", tags=["monitoring"])
app.include_router(users.router, prefix="/api/v1/users", tags=["users"])


# Root endpoint
@app.get("/", include_in_schema=False)
async def root():
    """Root endpoint with API information"""
    return {
        "name": "TBR GDP Core - Data Governance API",
        "version": "2.0.0",
        "description": "Comprehensive data governance platform",
        "docs_url": "/docs",
        "redoc_url": "/redoc",
        "health_url": "/health",
        "metrics_url": "/metrics",
        "api_base": "/api/v1"
    }


def run_server():
    """Run the FastAPI server"""
    uvicorn.run(
        "tbr_gdpcore_dtgovapi.main:app",
        host=settings.API_HOST,
        port=settings.API_PORT,
        reload=settings.API_RELOAD,
        log_level=settings.LOG_LEVEL.lower(),
        access_log=True,
    )


if __name__ == "__main__":
    run_server()

