# TBR GDP Core - Setup Local no Windows com PyCharm

## Visão Geral

Este guia fornece instruções detalhadas para configurar e executar o **TBR GDP Core - Data Governance API** localmente no Windows usando PyCharm como IDE principal. O projeto foi otimizado para desenvolvimento local sem necessidade de Docker.

## Pré-requisitos

### Software Necessário

1. **Windows 10/11** (64-bit)
2. **Python 3.8+** - [Download Python](https://www.python.org/downloads/windows/)
3. **PostgreSQL 12+** - [Download PostgreSQL](https://www.postgresql.org/download/windows/)
4. **PyCharm Professional ou Community** - [Download PyCharm](https://www.jetbrains.com/pycharm/download/#section=windows)
5. **Git for Windows** - [Download Git](https://git-scm.com/download/win)

### Verificação de Pré-requisitos

Abra o PowerShell como Administrador e execute:

```powershell
# Verificar Python
python --version

# Verificar PostgreSQL
psql --version

# Verificar Git
git --version
```

## Instalação Automática

### Opção 1: Script de Instalação Automática

1. **Clone o repositório**:
   ```powershell
   git clone https://github.com/manus-ai/tbr-gdpcore-dtgovapi.git
   cd tbr-gdpcore-dtgovapi
   ```

2. **Execute o script de instalação**:
   ```powershell
   Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
   .\scripts\windows\setup\install.ps1
   ```

3. **Aguarde a conclusão** (pode levar 10-15 minutos)

O script irá:
- Instalar dependências via Chocolatey (se necessário)
- Criar ambiente virtual Python
- Instalar dependências do projeto
- Configurar banco de dados PostgreSQL
- Criar configurações do PyCharm
- Executar migrações iniciais
- Carregar dados de teste

## Instalação Manual

### Passo 1: Configuração do Python

1. **Instalar Python**:
   - Baixe Python 3.11 do site oficial
   - **IMPORTANTE**: Marque "Add Python to PATH" durante a instalação
   - Verifique a instalação: `python --version`

2. **Criar ambiente virtual**:
   ```powershell
   cd tbr-gdpcore-dtgovapi
   python -m venv venv
   ```

3. **Ativar ambiente virtual**:
   ```powershell
   .\venv\Scripts\Activate.ps1
   ```

   > **Nota**: Se houver erro de execução de scripts, execute:
   > ```powershell
   > Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
   > ```

### Passo 2: Configuração do PostgreSQL

1. **Instalar PostgreSQL**:
   - Baixe PostgreSQL 15 do site oficial
   - Durante a instalação, defina senha para usuário `postgres`
   - Anote a porta (padrão: 5432)

2. **Criar banco de dados**:
   ```powershell
   # Conectar ao PostgreSQL
   psql -U postgres -h localhost

   # Criar usuário e banco
   CREATE USER tbr_gdpcore_user WITH PASSWORD 'tbr_gdpcore_pass';
   CREATE DATABASE tbr_gdpcore_dtgovapi OWNER tbr_gdpcore_user;
   GRANT ALL PRIVILEGES ON DATABASE tbr_gdpcore_dtgovapi TO tbr_gdpcore_user;
   \q
   ```

### Passo 3: Configuração do Projeto

1. **Instalar dependências**:
   ```powershell
   # Certificar que o ambiente virtual está ativo
   .\venv\Scripts\Activate.ps1
   
   # Atualizar pip
   python -m pip install --upgrade pip
   
   # Instalar projeto em modo desenvolvimento
   pip install -e ".[dev,databricks,informatica]"
   ```

2. **Configurar variáveis de ambiente**:
   ```powershell
   # Copiar template de configuração
   copy config\.env.template config\.env
   
   # Editar arquivo .env
   notepad config\.env
   ```

   **Configuração mínima no arquivo `.env`**:
   ```env
   # Database Configuration
   DATABASE_URL=postgresql://tbr_gdpcore_user:tbr_gdpcore_pass@localhost:5432/tbr_gdpcore_dtgovapi
   DATABASE_ECHO=false

   # API Configuration
   API_HOST=0.0.0.0
   API_PORT=8000
   API_DEBUG=true
   API_RELOAD=true

   # Security (altere em produção)
   SECRET_KEY=dev-secret-key-change-in-production
   JWT_SECRET_KEY=dev-jwt-secret-change-in-production
   JWT_ALGORITHM=HS256
   JWT_EXPIRE_MINUTES=30

   # Logging
   LOG_LEVEL=INFO
   LOG_FORMAT=json
   ```

3. **Executar migrações do banco**:
   ```powershell
   alembic upgrade head
   ```

4. **Carregar dados de teste**:
   ```powershell
   psql -U tbr_gdpcore_user -h localhost -d tbr_gdpcore_dtgovapi -f data\mock\sample_data.sql
   ```

## Configuração do PyCharm

### Passo 1: Abrir Projeto

1. **Abrir PyCharm**
2. **File → Open**
3. **Selecionar pasta** `tbr-gdpcore-dtgovapi`
4. **Aguardar indexação** do projeto

### Passo 2: Configurar Interpretador Python

1. **File → Settings** (Ctrl+Alt+S)
2. **Project → Python Interpreter**
3. **Add Interpreter → Existing Environment**
4. **Selecionar**: `.\venv\Scripts\python.exe`
5. **Apply → OK**

### Passo 3: Configurar Estrutura do Projeto

1. **File → Settings → Project → Project Structure**
2. **Marcar `src` como Sources Root** (botão "Sources")
3. **Marcar `tests` como Test Sources Root** (botão "Tests")
4. **Apply → OK**

### Passo 4: Configurações de Execução

O projeto inclui configurações pré-definidas em `.idea/runConfigurations/`:

#### Configuração "API Server"
- **Executa**: Servidor FastAPI em modo desenvolvimento
- **Comando**: `uvicorn tbr_gdpcore_dtgovapi.main:app --reload --host 0.0.0.0 --port 8000`
- **Acesso**: http://localhost:8000

#### Configuração "Database Migration"
- **Executa**: Migrações do banco de dados
- **Comando**: `alembic upgrade head`

#### Configuração "Tests"
- **Executa**: Todos os testes do projeto
- **Comando**: `pytest`

#### Configuração "Seed Database"
- **Executa**: Carrega dados de teste
- **Comando**: Script personalizado para carregar dados

### Passo 5: Configurar Debugging

1. **Run → Edit Configurations**
2. **Selecionar "API Server"**
3. **Marcar "Debug"** para habilitar breakpoints
4. **Apply → OK**

## Executando o Projeto

### Método 1: Via PyCharm (Recomendado)

1. **Selecionar configuração "API Server"** na barra superior
2. **Clicar no botão Run** (▶️) ou **Debug** (🐛)
3. **Aguardar inicialização** (logs aparecerão no console)
4. **Acessar aplicação**:
   - API: http://localhost:8000
   - Documentação: http://localhost:8000/docs
   - ReDoc: http://localhost:8000/redoc

### Método 2: Via Terminal

```powershell
# Ativar ambiente virtual
.\venv\Scripts\Activate.ps1

# Executar servidor
uvicorn tbr_gdpcore_dtgovapi.main:app --reload --host 0.0.0.0 --port 8000
```

### Método 3: Via Comando Personalizado

```powershell
# Ativar ambiente virtual
.\venv\Scripts\Activate.ps1

# Usar comando personalizado
tbr-gdpcore-server
```

## Verificação da Instalação

### 1. Health Check

Acesse: http://localhost:8000/health

Resposta esperada:
```json
{
  "status": "healthy",
  "timestamp": "2025-01-07T12:00:00Z",
  "version": "2.0.0",
  "uptime_seconds": 30.5,
  "checks": {
    "database": {
      "status": "healthy",
      "response_time_ms": 15.2
    }
  }
}
```

### 2. Documentação da API

Acesse: http://localhost:8000/docs

Deve exibir a interface Swagger com todos os endpoints disponíveis.

### 3. Teste de Banco de Dados

```powershell
# Via PyCharm: usar configuração "Tests"
# Via terminal:
.\venv\Scripts\Activate.ps1
pytest tests/test_database.py -v
```

## Desenvolvimento

### Estrutura de Arquivos

```
tbr-gdpcore-dtgovapi/
├── src/tbr_gdpcore_dtgovapi/    # Código fonte principal
│   ├── api/                     # Endpoints da API
│   │   └── endpoints/           # Módulos de endpoints
│   ├── core/                    # Configurações e database
│   ├── services/                # Lógica de negócio
│   └── utils/                   # Utilitários
├── database/                    # Schemas e migrações
│   ├── schemas/                 # Arquivos DBML e SQL
│   └── migrations/              # Migrações Alembic
├── tests/                       # Testes automatizados
├── docs/                        # Documentação
├── scripts/windows/             # Scripts PowerShell
├── config/                      # Configurações
└── data/mock/                   # Dados de teste
```

### Fluxo de Desenvolvimento

1. **Criar nova branch**:
   ```powershell
   git checkout -b feature/nova-funcionalidade
   ```

2. **Desenvolver funcionalidade**:
   - Usar PyCharm para edição
   - Executar testes frequentemente
   - Usar debugger quando necessário

3. **Executar testes**:
   ```powershell
   # Via PyCharm: configuração "Tests"
   # Via terminal:
   pytest
   ```

4. **Verificar qualidade do código**:
   ```powershell
   # Formatação
   black src/ tests/
   isort src/ tests/
   
   # Linting
   flake8 src/ tests/
   mypy src/
   ```

5. **Commit e push**:
   ```powershell
   git add .
   git commit -m "feat: adicionar nova funcionalidade"
   git push origin feature/nova-funcionalidade
   ```

### Debugging

#### Configurar Breakpoints

1. **Clicar na margem esquerda** do editor (linha desejada)
2. **Executar em modo Debug** (🐛)
3. **Usar controles de debug**:
   - **Step Over** (F8): Próxima linha
   - **Step Into** (F7): Entrar na função
   - **Step Out** (Shift+F8): Sair da função
   - **Resume** (F9): Continuar execução

#### Debug Console

- **Avaliar expressões** durante debug
- **Modificar variáveis** em tempo real
- **Executar código Python** no contexto atual

### Hot Reload

O servidor FastAPI suporta hot reload automático:
- **Salvar arquivo** → **Servidor reinicia automaticamente**
- **Mudanças refletidas** imediatamente no navegador
- **Logs de reload** aparecem no console do PyCharm

## Banco de Dados

### Migrações

```powershell
# Criar nova migração
alembic revision --autogenerate -m "Descrição da mudança"

# Aplicar migrações
alembic upgrade head

# Reverter migração
alembic downgrade -1

# Ver histórico
alembic history
```

### Dados de Teste

```powershell
# Carregar dados de teste
.\scripts\windows\database\seed.ps1

# Limpar e recarregar
.\scripts\windows\database\reset.ps1

# Backup do banco
.\scripts\windows\database\backup.ps1
```

### Acesso Direto ao Banco

```powershell
# Via psql
psql -U tbr_gdpcore_user -h localhost -d tbr_gdpcore_dtgovapi

# Via PyCharm Database Tool
# View → Tool Windows → Database
# Adicionar PostgreSQL datasource
```

## Testes

### Executar Testes

```powershell
# Todos os testes
pytest

# Testes específicos
pytest tests/unit/
pytest tests/integration/

# Com cobertura
pytest --cov=src/tbr_gdpcore_dtgovapi --cov-report=html

# Testes específicos
pytest tests/unit/test_api.py::test_health_check -v
```

### Configuração de Testes no PyCharm

1. **Run → Edit Configurations**
2. **Add → Python tests → pytest**
3. **Target**: `tests`
4. **Working directory**: Raiz do projeto
5. **Python interpreter**: Ambiente virtual
6. **Apply → OK**

### Debugging de Testes

1. **Colocar breakpoint** no teste
2. **Clicar com botão direito** no teste
3. **Debug 'test_name'**

## Integrações Externas

### Databricks Unity Catalog

1. **Configurar no `.env`**:
   ```env
   DATABRICKS_HOST=https://your-workspace.cloud.databricks.com
   DATABRICKS_TOKEN=your-access-token
   ```

2. **Testar conexão**:
   ```python
   from tbr_gdpcore_dtgovapi.services.databricks import DatabricksService
   
   service = DatabricksService()
   catalogs = await service.list_catalogs()
   ```

### Informatica Axon

1. **Configurar no `.env`**:
   ```env
   INFORMATICA_AXON_URL=https://your-axon-instance.com
   INFORMATICA_AXON_TOKEN=your-api-token
   ```

2. **Testar conexão**:
   ```python
   from tbr_gdpcore_dtgovapi.services.informatica import InformaticaService
   
   service = InformaticaService()
   glossary = await service.get_glossary()
   ```

## Monitoramento e Logs

### Logs da Aplicação

```powershell
# Ver logs em tempo real (se configurado arquivo)
Get-Content logs\app.log -Wait

# Filtrar logs por nível
Select-String -Path logs\app.log -Pattern "ERROR"
```

### Métricas Prometheus

- **Endpoint**: http://localhost:8000/metrics
- **Formato**: Prometheus metrics
- **Inclui**: Métricas de aplicação e sistema

### Health Checks

- **Basic**: http://localhost:8000/health
- **Readiness**: http://localhost:8000/health/ready
- **Liveness**: http://localhost:8000/health/live
- **Database**: http://localhost:8000/health/database

## Solução de Problemas

### Problemas Comuns

#### 1. Erro de Importação de Módulos

**Problema**: `ModuleNotFoundError: No module named 'tbr_gdpcore_dtgovapi'`

**Solução**:
```powershell
# Verificar se está no ambiente virtual
.\venv\Scripts\Activate.ps1

# Reinstalar em modo desenvolvimento
pip install -e .

# Verificar PYTHONPATH no PyCharm
# File → Settings → Project → Project Structure
# Marcar 'src' como Sources Root
```

#### 2. Erro de Conexão com Banco

**Problema**: `could not connect to server: Connection refused`

**Solução**:
```powershell
# Verificar se PostgreSQL está rodando
Get-Service postgresql*

# Iniciar serviço se necessário
Start-Service postgresql-x64-15

# Verificar configuração no .env
# DATABASE_URL=postgresql://user:pass@localhost:5432/dbname
```

#### 3. Erro de Permissão de Script

**Problema**: `execution of scripts is disabled on this system`

**Solução**:
```powershell
# Executar como Administrador
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser

# Ou temporariamente
Set-ExecutionPolicy -ExecutionPolicy Bypass -Scope Process
```

#### 4. Porta 8000 em Uso

**Problema**: `[Errno 10048] Only one usage of each socket address`

**Solução**:
```powershell
# Encontrar processo usando a porta
netstat -ano | findstr :8000

# Matar processo (substitua PID)
taskkill /PID <PID> /F

# Ou usar porta diferente no .env
API_PORT=8001
```

#### 5. Erro de Migração de Banco

**Problema**: `Target database is not up to date`

**Solução**:
```powershell
# Verificar status das migrações
alembic current

# Aplicar migrações pendentes
alembic upgrade head

# Se houver conflito, resolver manualmente
alembic merge heads
```

### Logs de Debug

Para habilitar logs detalhados, configure no `.env`:

```env
LOG_LEVEL=DEBUG
DATABASE_ECHO=true
API_DEBUG=true
```

### Verificação de Saúde do Sistema

Execute o script de diagnóstico:

```powershell
.\scripts\windows\development\diagnose.ps1
```

Este script verifica:
- Versões de software
- Conectividade de banco
- Configurações do projeto
- Status dos serviços

## Performance e Otimização

### Configurações de Performance

1. **Banco de Dados**:
   ```env
   DATABASE_POOL_SIZE=10
   DATABASE_MAX_OVERFLOW=20
   DATABASE_ECHO=false  # Desabilitar em produção
   ```

2. **API**:
   ```env
   API_RELOAD=false     # Desabilitar em produção
   API_DEBUG=false      # Desabilitar em produção
   ```

3. **Cache**:
   ```env
   CACHE_ENABLED=true
   CACHE_TTL=300
   REDIS_URL=redis://localhost:6379/0  # Opcional
   ```

### Monitoramento de Performance

- **Métricas**: http://localhost:8000/metrics
- **Profiling**: Usar PyCharm Profiler
- **Database**: Monitorar queries lentas

## Backup e Recuperação

### Backup do Banco de Dados

```powershell
# Backup completo
pg_dump -U tbr_gdpcore_user -h localhost tbr_gdpcore_dtgovapi > backup.sql

# Backup com compressão
pg_dump -U tbr_gdpcore_user -h localhost -Fc tbr_gdpcore_dtgovapi > backup.dump
```

### Restauração

```powershell
# Restaurar de SQL
psql -U tbr_gdpcore_user -h localhost -d tbr_gdpcore_dtgovapi < backup.sql

# Restaurar de dump
pg_restore -U tbr_gdpcore_user -h localhost -d tbr_gdpcore_dtgovapi backup.dump
```

## Próximos Passos

Após configurar o ambiente local:

1. **Explorar a API**: http://localhost:8000/docs
2. **Executar testes**: Verificar funcionamento
3. **Revisar código**: Entender arquitetura
4. **Desenvolver funcionalidades**: Seguir padrões estabelecidos
5. **Contribuir**: Seguir guia de contribuição

## Suporte

Para problemas não cobertos neste guia:

- **Issues**: [GitHub Issues](https://github.com/manus-ai/tbr-gdpcore-dtgovapi/issues)
- **Discussões**: [GitHub Discussions](https://github.com/manus-ai/tbr-gdpcore-dtgovapi/discussions)
- **Email**: suporte@manus.ai
- **Documentação**: [Wiki do Projeto](https://github.com/manus-ai/tbr-gdpcore-dtgovapi/wiki)

