# TBR GDP Core - Database Seed Script
# Load sample data for development and testing

param(
    [string]$DatabaseUrl = $env:DATABASE_URL,
    [switch]$Force,
    [switch]$Verbose
)

$ErrorActionPreference = "Stop"

if ($Verbose) {
    $VerbosePreference = "Continue"
}

function Write-Info {
    param([string]$Message)
    Write-Host "[INFO] $Message" -ForegroundColor Green
}

function Write-Warning {
    param([string]$Message)
    Write-Host "[WARNING] $Message" -ForegroundColor Yellow
}

function Write-Error {
    param([string]$Message)
    Write-Host "[ERROR] $Message" -ForegroundColor Red
}

function Test-DatabaseConnection {
    param([string]$Url)
    
    try {
        # Parse database URL
        if ($Url -match "postgresql://([^:]+):([^@]+)@([^:]+):(\d+)/(.+)") {
            $username = $matches[1]
            $password = $matches[2]
            $host = $matches[3]
            $port = $matches[4]
            $database = $matches[5]
            
            # Set password environment variable
            $env:PGPASSWORD = $password
            
            # Test connection
            $result = psql -h $host -p $port -U $username -d $database -c "SELECT 1;" 2>&1
            
            if ($LASTEXITCODE -eq 0) {
                return $true
            } else {
                Write-Error "Database connection failed: $result"
                return $false
            }
        } else {
            Write-Error "Invalid database URL format"
            return $false
        }
    }
    catch {
        Write-Error "Error testing database connection: $($_.Exception.Message)"
        return $false
    }
}

function Load-SampleData {
    param([string]$Url)
    
    try {
        # Parse database URL
        if ($Url -match "postgresql://([^:]+):([^@]+)@([^:]+):(\d+)/(.+)") {
            $username = $matches[1]
            $password = $matches[2]
            $host = $matches[3]
            $port = $matches[4]
            $database = $matches[5]
            
            # Set password environment variable
            $env:PGPASSWORD = $password
            
            # Path to sample data file
            $sampleDataFile = "data\mock\sample_data.sql"
            
            if (-not (Test-Path $sampleDataFile)) {
                Write-Error "Sample data file not found: $sampleDataFile"
                return $false
            }
            
            Write-Info "Loading sample data from $sampleDataFile..."
            
            # Load sample data
            $result = psql -h $host -p $port -U $username -d $database -f $sampleDataFile 2>&1
            
            if ($LASTEXITCODE -eq 0) {
                Write-Info "Sample data loaded successfully"
                return $true
            } else {
                Write-Error "Failed to load sample data: $result"
                return $false
            }
        } else {
            Write-Error "Invalid database URL format"
            return $false
        }
    }
    catch {
        Write-Error "Error loading sample data: $($_.Exception.Message)"
        return $false
    }
}

function Check-ExistingData {
    param([string]$Url)
    
    try {
        # Parse database URL
        if ($Url -match "postgresql://([^:]+):([^@]+)@([^:]+):(\d+)/(.+)") {
            $username = $matches[1]
            $password = $matches[2]
            $host = $matches[3]
            $port = $matches[4]
            $database = $matches[5]
            
            # Set password environment variable
            $env:PGPASSWORD = $password
            
            # Check if users table has data
            $result = psql -h $host -p $port -U $username -d $database -tAc "SELECT COUNT(*) FROM users;" 2>&1
            
            if ($LASTEXITCODE -eq 0) {
                $count = [int]$result.Trim()
                return $count -gt 0
            } else {
                # Table might not exist yet
                return $false
            }
        } else {
            Write-Error "Invalid database URL format"
            return $false
        }
    }
    catch {
        # Assume no data if there's an error
        return $false
    }
}

# Main execution
Write-Host ""
Write-Host "TBR GDP Core - Database Seed Script" -ForegroundColor Blue
Write-Host "===================================" -ForegroundColor Blue
Write-Host ""

# Check if database URL is provided
if (-not $DatabaseUrl) {
    # Try to get from config file
    $envFile = "config\.env"
    if (Test-Path $envFile) {
        Write-Info "Reading database URL from $envFile..."
        $content = Get-Content $envFile
        foreach ($line in $content) {
            if ($line -match "^DATABASE_URL=(.+)$") {
                $DatabaseUrl = $matches[1]
                break
            }
        }
    }
    
    if (-not $DatabaseUrl) {
        Write-Error "Database URL not provided. Set DATABASE_URL environment variable or use -DatabaseUrl parameter."
        exit 1
    }
}

Write-Info "Using database URL: $($DatabaseUrl -replace '://[^:]+:[^@]+@', '://***:***@')"

# Test database connection
Write-Info "Testing database connection..."
if (-not (Test-DatabaseConnection -Url $DatabaseUrl)) {
    Write-Error "Cannot connect to database. Please check your configuration."
    exit 1
}

Write-Info "Database connection successful"

# Check for existing data
if (-not $Force) {
    Write-Info "Checking for existing data..."
    if (Check-ExistingData -Url $DatabaseUrl) {
        Write-Warning "Database already contains data."
        $response = Read-Host "Do you want to continue and potentially duplicate data? (y/N)"
        if ($response -ne "y" -and $response -ne "Y") {
            Write-Info "Operation cancelled. Use -Force to skip this check."
            exit 0
        }
    }
}

# Load sample data
Write-Info "Loading sample data..."
if (Load-SampleData -Url $DatabaseUrl) {
    Write-Host ""
    Write-Host "Sample data loaded successfully!" -ForegroundColor Green
    Write-Host ""
    Write-Info "You can now:"
    Write-Host "  - Start the API server: .\venv\Scripts\Activate.ps1; uvicorn tbr_gdpcore_dtgovapi.main:app --reload"
    Write-Host "  - Access the API docs: http://localhost:8000/docs"
    Write-Host "  - Run tests: pytest"
    Write-Host ""
} else {
    Write-Error "Failed to load sample data"
    exit 1
}

