# TBR GDP Core - Data Governance API

[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.104+-green.svg)](https://fastapi.tiangolo.com/)
[![PostgreSQL](https://img.shields.io/badge/PostgreSQL-12+-blue.svg)](https://www.postgresql.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## Visão Geral

O **TBR GDP Core - Data Governance API** é uma solução completa para governança de dados que oferece:

- 🏗️ **Modelo de Dados Robusto**: 36 tabelas cobrindo todos os aspectos de governança
- 🔗 **Integrações Nativas**: Databricks Unity Catalog e Informatica Axon
- 📊 **Qualidade de Dados**: Sistema avançado de monitoramento e validação
- 📋 **Contratos de Dados**: Gestão completa de SLAs e acordos
- 🔒 **Compliance**: Suporte a GDPR, CCPA, HIPAA, SOX
- 🔍 **Linhagem**: Rastreamento completo de origem e destino dos dados
- 📈 **Monitoramento**: Alertas e métricas em tempo real

## Estrutura do Projeto

```
tbr-gdpcore-dtgovapi/
├── src/tbr_gdpcore_dtgovapi/    # Código fonte principal
│   ├── api/                     # Endpoints da API
│   ├── core/                    # Configurações e database
│   ├── services/                # Lógica de negócio
│   └── utils/                   # Utilitários
├── database/                    # Schemas e migrações
│   ├── schemas/                 # Arquivos DBML e SQL
│   ├── migrations/              # Migrações Alembic
│   └── seeds/                   # Dados iniciais
├── scripts/                     # Scripts de automação
│   ├── windows/                 # Scripts PowerShell para Windows
│   └── database/                # Scripts de banco de dados
├── config/                      # Configurações
├── data/                        # Dados de teste e exemplos
├── tests/                       # Testes automatizados
└── docs/                        # Documentação
```

## 🚀 Setup Local no Windows com PyCharm

### Pré-requisitos

1. **Python 3.8+** - [Download](https://www.python.org/downloads/)
2. **PostgreSQL 12+** - [Download](https://www.postgresql.org/download/windows/)
3. **PyCharm Professional/Community** - [Download](https://www.jetbrains.com/pycharm/)
4. **Git** - [Download](https://git-scm.com/download/win)

### Instalação Rápida

1. **Clone o projeto**:
   ```powershell
   git clone https://github.com/manus-ai/tbr-gdpcore-dtgovapi.git
   cd tbr-gdpcore-dtgovapi
   ```

2. **Execute o script de setup**:
   ```powershell
   .\scripts\windows\setup\install.ps1
   ```

3. **Configure o PyCharm**:
   - Abra o projeto no PyCharm
   - Configure o interpretador Python (venv criado automaticamente)
   - Execute as configurações de run/debug incluídas

### Setup Manual Detalhado

#### 1. Configuração do Ambiente Python

```powershell
# Criar ambiente virtual
python -m venv venv

# Ativar ambiente virtual
.\venv\Scripts\Activate.ps1

# Instalar dependências
pip install -e ".[dev,databricks,informatica]"
```

#### 2. Configuração do Banco de Dados

```powershell
# Criar banco de dados PostgreSQL
createdb -U postgres tbr_gdpcore_dtgovapi

# Executar migrações
.\scripts\windows\database\migrate.ps1

# Carregar dados de teste
.\scripts\windows\database\seed.ps1
```

#### 3. Configuração do Ambiente

```powershell
# Copiar arquivo de configuração
copy config\.env.template config\.env

# Editar configurações no arquivo .env
notepad config\.env
```

#### 4. Configuração do PyCharm

1. **Abrir Projeto**:
   - File → Open → Selecionar pasta `tbr-gdpcore-dtgovapi`

2. **Configurar Interpretador**:
   - File → Settings → Project → Python Interpreter
   - Add Interpreter → Existing Environment
   - Selecionar: `.\venv\Scripts\python.exe`

3. **Configurar Run/Debug**:
   - As configurações estão em `.idea/runConfigurations/`
   - Configurações disponíveis:
     - `API Server` - Executar servidor FastAPI
     - `Database Migration` - Executar migrações
     - `Tests` - Executar testes
     - `Seed Database` - Carregar dados de teste

4. **Configurar Estrutura do Projeto**:
   - File → Settings → Project → Project Structure
   - Marcar `src` como Sources Root
   - Marcar `tests` como Test Sources Root

## 🔧 Configuração

### Arquivo .env

```env
# Database Configuration
DATABASE_URL=postgresql://postgres:password@localhost:5432/tbr_gdpcore_dtgovapi
DATABASE_ECHO=false

# API Configuration
API_HOST=0.0.0.0
API_PORT=8000
API_DEBUG=true
API_RELOAD=true

# Security
SECRET_KEY=your-secret-key-here
JWT_SECRET_KEY=your-jwt-secret-here
JWT_ALGORITHM=HS256
JWT_EXPIRE_MINUTES=30

# External Integrations
DATABRICKS_HOST=
DATABRICKS_TOKEN=
INFORMATICA_AXON_URL=
INFORMATICA_AXON_TOKEN=

# Logging
LOG_LEVEL=INFO
LOG_FORMAT=json

# Redis (opcional)
REDIS_URL=redis://localhost:6379/0
```

## 🏃‍♂️ Executando o Projeto

### Via PyCharm

1. **Servidor API**:
   - Selecionar configuração "API Server"
   - Clicar em Run (Ctrl+Shift+F10)
   - Acessar: http://localhost:8000

2. **Documentação da API**:
   - Swagger UI: http://localhost:8000/docs
   - ReDoc: http://localhost:8000/redoc

### Via Linha de Comando

```powershell
# Ativar ambiente virtual
.\venv\Scripts\Activate.ps1

# Executar servidor de desenvolvimento
uvicorn tbr_gdpcore_dtgovapi.main:app --reload --host 0.0.0.0 --port 8000

# Ou usar o comando personalizado
tbr-gdpcore-server
```

## 🧪 Executando Testes

### Via PyCharm

1. Selecionar configuração "Tests"
2. Clicar em Run
3. Ver resultados na aba Test Results

### Via Linha de Comando

```powershell
# Todos os testes
pytest

# Testes unitários apenas
pytest tests/unit

# Testes com cobertura
pytest --cov=src/tbr_gdpcore_dtgovapi --cov-report=html

# Testes específicos
pytest tests/unit/test_api.py::test_health_check
```

## 📊 Banco de Dados

### Migrações

```powershell
# Criar nova migração
alembic revision --autogenerate -m "Descrição da mudança"

# Aplicar migrações
alembic upgrade head

# Reverter migração
alembic downgrade -1

# Ver histórico
alembic history
```

### Dados de Teste

```powershell
# Carregar dados de teste
.\scripts\windows\database\seed.ps1

# Limpar e recarregar
.\scripts\windows\database\reset.ps1
```

## 🔗 Integrações

### Databricks Unity Catalog

```python
from tbr_gdpcore_dtgovapi.services.databricks import DatabricksService

# Configurar conexão
databricks = DatabricksService(
    host="your-databricks-host",
    token="your-token"
)

# Sincronizar catálogos
await databricks.sync_catalogs()
```

### Informatica Axon

```python
from tbr_gdpcore_dtgovapi.services.informatica import InformaticaService

# Configurar conexão
informatica = InformaticaService(
    url="your-axon-url",
    token="your-token"
)

# Sincronizar glossário
await informatica.sync_glossary()
```

## 📚 Documentação

- **Setup Local**: [docs/setup/windows-pycharm.md](docs/setup/windows-pycharm.md)
- **API Reference**: [docs/api/README.md](docs/api/README.md)
- **Guia do Usuário**: [docs/user/README.md](docs/user/README.md)
- **Modelo de Dados**: [database/schemas/README.md](database/schemas/README.md)

## 🛠️ Desenvolvimento

### Configuração do Ambiente de Desenvolvimento

```powershell
# Instalar hooks de pre-commit
pre-commit install

# Executar formatação
black src/ tests/
isort src/ tests/

# Executar linting
flake8 src/ tests/
mypy src/
```

### Estrutura de Commits

```
feat: adicionar nova funcionalidade
fix: corrigir bug
docs: atualizar documentação
style: formatação de código
refactor: refatoração
test: adicionar testes
chore: tarefas de manutenção
```

## 🚀 Deploy

### Desenvolvimento Local

```powershell
# Executar com hot reload
uvicorn tbr_gdpcore_dtgovapi.main:app --reload
```

### Produção

```powershell
# Executar com Gunicorn (Linux/Mac)
gunicorn tbr_gdpcore_dtgovapi.main:app -w 4 -k uvicorn.workers.UvicornWorker

# Executar com Uvicorn (Windows)
uvicorn tbr_gdpcore_dtgovapi.main:app --workers 4
```

## 📈 Monitoramento

### Métricas

- **Health Check**: `/health`
- **Metrics**: `/metrics` (Prometheus format)
- **Status**: `/status`

### Logs

```powershell
# Ver logs em tempo real
Get-Content logs\app.log -Wait

# Filtrar logs por nível
Select-String -Path logs\app.log -Pattern "ERROR"
```

## 🤝 Contribuição

1. Fork o projeto
2. Criar branch para feature (`git checkout -b feature/nova-funcionalidade`)
3. Commit das mudanças (`git commit -am 'Adicionar nova funcionalidade'`)
4. Push para branch (`git push origin feature/nova-funcionalidade`)
5. Criar Pull Request

## 📄 Licença

Este projeto está licenciado sob a Licença MIT - veja o arquivo [LICENSE](LICENSE) para detalhes.

## 🆘 Suporte

- **Issues**: [GitHub Issues](https://github.com/manus-ai/tbr-gdpcore-dtgovapi/issues)
- **Discussões**: [GitHub Discussions](https://github.com/manus-ai/tbr-gdpcore-dtgovapi/discussions)
- **Email**: suporte@manus.ai
- **Documentação**: [Wiki](https://github.com/manus-ai/tbr-gdpcore-dtgovapi/wiki)

## 🏆 Funcionalidades Principais

### ✅ Implementado

- [x] API REST completa com FastAPI
- [x] Modelo de dados com 36 tabelas
- [x] Sistema de autenticação e autorização
- [x] Integração com PostgreSQL
- [x] Migrações automáticas com Alembic
- [x] Testes automatizados
- [x] Documentação interativa (Swagger/ReDoc)
- [x] Logging estruturado
- [x] Configuração via variáveis de ambiente
- [x] Scripts de setup para Windows
- [x] Configuração para PyCharm

### 🚧 Em Desenvolvimento

- [ ] Interface web (React)
- [ ] Integração completa com Databricks
- [ ] Integração completa com Informatica Axon
- [ ] Sistema de notificações
- [ ] Dashboard executivo
- [ ] Relatórios avançados

### 📋 Roadmap

- [ ] Suporte a múltiplas clouds
- [ ] Machine Learning Governance
- [ ] Data Mesh support
- [ ] Real-time monitoring
- [ ] Advanced analytics

