-- TBR GDP Core - Sample Data for Testing
-- Version: 2.0.0
-- Description: Mock data for development and testing

-- Enable UUID extension (PostgreSQL)
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Insert sample users
INSERT INTO users (id, username, email, full_name, first_name, last_name, department, job_title, is_active, is_admin) VALUES
('550e8400-e29b-41d4-a716-446655440001', 'admin', 'admin@tbr.com', 'System Administrator', 'System', 'Administrator', 'IT', 'System Administrator', true, true),
('550e8400-e29b-41d4-a716-446655440002', 'john.doe', 'john.doe@tbr.com', 'John Doe', 'John', 'Doe', 'Data Engineering', 'Senior Data Engineer', true, false),
('550e8400-e29b-41d4-a716-446655440003', 'jane.smith', 'jane.smith@tbr.com', 'Jane Smith', 'Jane', 'Smith', 'Data Science', 'Data Scientist', true, false),
('550e8400-e29b-41d4-a716-446655440004', 'bob.wilson', 'bob.wilson@tbr.com', 'Bob Wilson', 'Bob', 'Wilson', 'Business Intelligence', 'BI Analyst', true, false),
('550e8400-e29b-41d4-a716-446655440005', 'alice.brown', 'alice.brown@tbr.com', 'Alice Brown', 'Alice', 'Brown', 'Compliance', 'Compliance Officer', true, false);

-- Insert sample data owners
INSERT INTO data_owners (id, user_id, owner_type, responsibilities, authority_level, is_active) VALUES
('660e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440002', 'technical', 'Technical ownership of data assets', 'high', true),
('660e8400-e29b-41d4-a716-446655440002', '550e8400-e29b-41d4-a716-446655440003', 'business', 'Business ownership and decision making', 'high', true),
('660e8400-e29b-41d4-a716-446655440003', '550e8400-e29b-41d4-a716-446655440004', 'domain', 'Domain-specific data ownership', 'medium', true);

-- Insert sample data stewards
INSERT INTO data_stewards (id, user_id, specialization, responsibilities, is_active) VALUES
('770e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440002', 'Data Quality', 'Ensuring data quality and integrity', true),
('770e8400-e29b-41d4-a716-446655440002', '550e8400-e29b-41d4-a716-446655440003', 'Metadata Management', 'Managing metadata and documentation', true),
('770e8400-e29b-41d4-a716-446655440003', '550e8400-e29b-41d4-a716-446655440005', 'Compliance', 'Ensuring regulatory compliance', true);

-- Insert sample business domains
INSERT INTO business_domains (id, name, display_name, description, owner_id, steward_id, status) VALUES
('880e8400-e29b-41d4-a716-446655440001', 'customer', 'Customer Domain', 'Customer-related data and processes', '660e8400-e29b-41d4-a716-446655440002', '770e8400-e29b-41d4-a716-446655440002', 'active'),
('880e8400-e29b-41d4-a716-446655440002', 'product', 'Product Domain', 'Product catalog and inventory data', '660e8400-e29b-41d4-a716-446655440001', '770e8400-e29b-41d4-a716-446655440001', 'active'),
('880e8400-e29b-41d4-a716-446655440003', 'finance', 'Finance Domain', 'Financial data and transactions', '660e8400-e29b-41d4-a716-446655440003', '770e8400-e29b-41d4-a716-446655440003', 'active'),
('880e8400-e29b-41d4-a716-446655440004', 'marketing', 'Marketing Domain', 'Marketing campaigns and analytics', '660e8400-e29b-41d4-a716-446655440002', '770e8400-e29b-41d4-a716-446655440002', 'active');

-- Insert sample business terms
INSERT INTO business_terms (id, name, display_name, definition, context, domain_id, owner_id, steward_id, status) VALUES
('990e8400-e29b-41d4-a716-446655440001', 'customer_id', 'Customer ID', 'Unique identifier for a customer in the system', 'Used across all customer-related processes', '880e8400-e29b-41d4-a716-446655440001', '660e8400-e29b-41d4-a716-446655440002', '770e8400-e29b-41d4-a716-446655440002', 'approved'),
('990e8400-e29b-41d4-a716-446655440002', 'product_sku', 'Product SKU', 'Stock Keeping Unit - unique product identifier', 'Used for inventory management and sales tracking', '880e8400-e29b-41d4-a716-446655440002', '660e8400-e29b-41d4-a716-446655440001', '770e8400-e29b-41d4-a716-446655440001', 'approved'),
('990e8400-e29b-41d4-a716-446655440003', 'revenue', 'Revenue', 'Total income generated from sales', 'Calculated as quantity * unit_price', '880e8400-e29b-41d4-a716-446655440003', '660e8400-e29b-41d4-a716-446655440003', '770e8400-e29b-41d4-a716-446655440003', 'approved'),
('990e8400-e29b-41d4-a716-446655440004', 'campaign_id', 'Campaign ID', 'Unique identifier for marketing campaigns', 'Used to track campaign performance and ROI', '880e8400-e29b-41d4-a716-446655440004', '660e8400-e29b-41d4-a716-446655440002', '770e8400-e29b-41d4-a716-446655440002', 'approved');

-- Insert sample data classifications
INSERT INTO data_classifications (id, name, display_name, description, level, is_pii, is_sensitive) VALUES
('aa0e8400-e29b-41d4-a716-446655440001', 'public', 'Public', 'Data that can be freely shared', 1, false, false),
('aa0e8400-e29b-41d4-a716-446655440002', 'internal', 'Internal', 'Data for internal use only', 2, false, false),
('aa0e8400-e29b-41d4-a716-446655440003', 'confidential', 'Confidential', 'Sensitive business data', 3, false, true),
('aa0e8400-e29b-41d4-a716-446655440004', 'restricted', 'Restricted', 'Highly sensitive data with access restrictions', 4, true, true),
('aa0e8400-e29b-41d4-a716-446655440005', 'top_secret', 'Top Secret', 'Most sensitive data requiring special handling', 5, true, true);

-- Insert sample retention policies
INSERT INTO retention_policies (id, name, display_name, description, retention_period_days, policy_type, owner_id, steward_id, status) VALUES
('bb0e8400-e29b-41d4-a716-446655440001', 'customer_data_retention', 'Customer Data Retention', 'Retention policy for customer personal data', 2555, 'legal', '660e8400-e29b-41d4-a716-446655440002', '770e8400-e29b-41d4-a716-446655440003', 'active'),
('bb0e8400-e29b-41d4-a716-446655440002', 'transaction_data_retention', 'Transaction Data Retention', 'Retention policy for financial transaction data', 3650, 'regulatory', '660e8400-e29b-41d4-a716-446655440003', '770e8400-e29b-41d4-a716-446655440003', 'active'),
('bb0e8400-e29b-41d4-a716-446655440003', 'log_data_retention', 'Log Data Retention', 'Retention policy for system and application logs', 365, 'technical', '660e8400-e29b-41d4-a716-446655440001', '770e8400-e29b-41d4-a716-446655440001', 'active');

-- Insert sample data catalogs
INSERT INTO data_catalogs (id, name, display_name, description, catalog_type, is_default, status) VALUES
('cc0e8400-e29b-41d4-a716-446655440001', 'production_catalog', 'Production Data Catalog', 'Main production data catalog', 'unity_catalog', true, 'active'),
('cc0e8400-e29b-41d4-a716-446655440002', 'staging_catalog', 'Staging Data Catalog', 'Staging environment data catalog', 'unity_catalog', false, 'active'),
('cc0e8400-e29b-41d4-a716-446655440003', 'development_catalog', 'Development Data Catalog', 'Development environment data catalog', 'hive_metastore', false, 'active');

-- Insert sample data schemas
INSERT INTO data_schemas (id, catalog_id, name, display_name, description, owner_id, status) VALUES
('dd0e8400-e29b-41d4-a716-446655440001', 'cc0e8400-e29b-41d4-a716-446655440001', 'customer_data', 'Customer Data Schema', 'Schema containing customer-related tables', '660e8400-e29b-41d4-a716-446655440002', 'active'),
('dd0e8400-e29b-41d4-a716-446655440002', 'cc0e8400-e29b-41d4-a716-446655440001', 'product_data', 'Product Data Schema', 'Schema containing product catalog tables', '660e8400-e29b-41d4-a716-446655440001', 'active'),
('dd0e8400-e29b-41d4-a716-446655440003', 'cc0e8400-e29b-41d4-a716-446655440001', 'finance_data', 'Finance Data Schema', 'Schema containing financial data tables', '660e8400-e29b-41d4-a716-446655440003', 'active'),
('dd0e8400-e29b-41d4-a716-446655440004', 'cc0e8400-e29b-41d4-a716-446655440002', 'staging_data', 'Staging Data Schema', 'Schema for staging data processing', '660e8400-e29b-41d4-a716-446655440001', 'active');

-- Insert sample data assets
INSERT INTO data_assets (id, catalog_id, schema_id, name, display_name, description, asset_type, owner_id, steward_id, classification_id, retention_policy_id, status, business_criticality) VALUES
('ee0e8400-e29b-41d4-a716-446655440001', 'cc0e8400-e29b-41d4-a716-446655440001', 'dd0e8400-e29b-41d4-a716-446655440001', 'customers', 'Customer Table', 'Main customer information table', 'table', '660e8400-e29b-41d4-a716-446655440002', '770e8400-e29b-41d4-a716-446655440002', 'aa0e8400-e29b-41d4-a716-446655440004', 'bb0e8400-e29b-41d4-a716-446655440001', 'active', 'critical'),
('ee0e8400-e29b-41d4-a716-446655440002', 'cc0e8400-e29b-41d4-a716-446655440001', 'dd0e8400-e29b-41d4-a716-446655440002', 'products', 'Product Table', 'Product catalog and inventory table', 'table', '660e8400-e29b-41d4-a716-446655440001', '770e8400-e29b-41d4-a716-446655440001', 'aa0e8400-e29b-41d4-a716-446655440002', 'bb0e8400-e29b-41d4-a716-446655440003', 'active', 'high'),
('ee0e8400-e29b-41d4-a716-446655440003', 'cc0e8400-e29b-41d4-a716-446655440001', 'dd0e8400-e29b-41d4-a716-446655440003', 'transactions', 'Transaction Table', 'Financial transaction records', 'table', '660e8400-e29b-41d4-a716-446655440003', '770e8400-e29b-41d4-a716-446655440003', 'aa0e8400-e29b-41d4-a716-446655440003', 'bb0e8400-e29b-41d4-a716-446655440002', 'active', 'critical'),
('ee0e8400-e29b-41d4-a716-446655440004', 'cc0e8400-e29b-41d4-a716-446655440001', 'dd0e8400-e29b-41d4-a716-446655440001', 'customer_orders', 'Customer Orders View', 'View combining customer and order data', 'view', '660e8400-e29b-41d4-a716-446655440002', '770e8400-e29b-41d4-a716-446655440002', 'aa0e8400-e29b-41d4-a716-446655440003', 'bb0e8400-e29b-41d4-a716-446655440001', 'active', 'high');

-- Insert sample data columns
INSERT INTO data_columns (id, asset_id, name, display_name, description, data_type, is_nullable, is_primary_key, position, classification_id, business_term_id, is_pii) VALUES
-- Customers table columns
('ff0e8400-e29b-41d4-a716-446655440001', 'ee0e8400-e29b-41d4-a716-446655440001', 'customer_id', 'Customer ID', 'Unique customer identifier', 'varchar(36)', false, true, 1, 'aa0e8400-e29b-41d4-a716-446655440002', '990e8400-e29b-41d4-a716-446655440001', false),
('ff0e8400-e29b-41d4-a716-446655440002', 'ee0e8400-e29b-41d4-a716-446655440001', 'first_name', 'First Name', 'Customer first name', 'varchar(100)', false, false, 2, 'aa0e8400-e29b-41d4-a716-446655440004', null, true),
('ff0e8400-e29b-41d4-a716-446655440003', 'ee0e8400-e29b-41d4-a716-446655440001', 'last_name', 'Last Name', 'Customer last name', 'varchar(100)', false, false, 3, 'aa0e8400-e29b-41d4-a716-446655440004', null, true),
('ff0e8400-e29b-41d4-a716-446655440004', 'ee0e8400-e29b-41d4-a716-446655440001', 'email', 'Email Address', 'Customer email address', 'varchar(255)', false, false, 4, 'aa0e8400-e29b-41d4-a716-446655440004', null, true),
('ff0e8400-e29b-41d4-a716-446655440005', 'ee0e8400-e29b-41d4-a716-446655440001', 'phone', 'Phone Number', 'Customer phone number', 'varchar(20)', true, false, 5, 'aa0e8400-e29b-41d4-a716-446655440004', null, true),
-- Products table columns
('ff0e8400-e29b-41d4-a716-446655440006', 'ee0e8400-e29b-41d4-a716-446655440002', 'product_id', 'Product ID', 'Unique product identifier', 'varchar(36)', false, true, 1, 'aa0e8400-e29b-41d4-a716-446655440002', null, false),
('ff0e8400-e29b-41d4-a716-446655440007', 'ee0e8400-e29b-41d4-a716-446655440002', 'sku', 'SKU', 'Product stock keeping unit', 'varchar(50)', false, false, 2, 'aa0e8400-e29b-41d4-a716-446655440002', '990e8400-e29b-41d4-a716-446655440002', false),
('ff0e8400-e29b-41d4-a716-446655440008', 'ee0e8400-e29b-41d4-a716-446655440002', 'name', 'Product Name', 'Product display name', 'varchar(255)', false, false, 3, 'aa0e8400-e29b-41d4-a716-446655440002', null, false),
('ff0e8400-e29b-41d4-a716-446655440009', 'ee0e8400-e29b-41d4-a716-446655440002', 'price', 'Price', 'Product unit price', 'decimal(10,2)', false, false, 4, 'aa0e8400-e29b-41d4-a716-446655440002', null, false);

-- Insert sample data processes
INSERT INTO data_processes (id, name, display_name, description, process_type, technology, owner_id, steward_id, status, business_criticality) VALUES
('110e8400-e29b-41d4-a716-446655440001', 'customer_etl', 'Customer Data ETL', 'Extract, transform, and load customer data', 'etl', 'databricks', '660e8400-e29b-41d4-a716-446655440001', '770e8400-e29b-41d4-a716-446655440001', 'active', 'critical'),
('110e8400-e29b-41d4-a716-446655440002', 'product_sync', 'Product Data Sync', 'Synchronize product data from external systems', 'elt', 'airflow', '660e8400-e29b-41d4-a716-446655440001', '770e8400-e29b-41d4-a716-446655440001', 'active', 'high'),
('110e8400-e29b-41d4-a716-446655440003', 'transaction_stream', 'Transaction Stream Processing', 'Real-time transaction data processing', 'streaming', 'kafka', '660e8400-e29b-41d4-a716-446655440003', '770e8400-e29b-41d4-a716-446655440003', 'active', 'critical');

-- Insert sample data quality rules
INSERT INTO data_quality_rules (id, name, display_name, description, rule_type, asset_id, column_id, rule_expression, severity, is_active, owner_id, steward_id) VALUES
('220e8400-e29b-41d4-a716-446655440001', 'customer_email_format', 'Customer Email Format Check', 'Validate customer email format', 'validity', 'ee0e8400-e29b-41d4-a716-446655440001', 'ff0e8400-e29b-41d4-a716-446655440004', 'email LIKE ''%@%.%''', 'high', true, '660e8400-e29b-41d4-a716-446655440002', '770e8400-e29b-41d4-a716-446655440001'),
('220e8400-e29b-41d4-a716-446655440002', 'customer_name_completeness', 'Customer Name Completeness', 'Check that customer names are not null', 'completeness', 'ee0e8400-e29b-41d4-a716-446655440001', null, 'first_name IS NOT NULL AND last_name IS NOT NULL', 'critical', true, '660e8400-e29b-41d4-a716-446655440002', '770e8400-e29b-41d4-a716-446655440001'),
('220e8400-e29b-41d4-a716-446655440003', 'product_price_validity', 'Product Price Validity', 'Ensure product prices are positive', 'validity', 'ee0e8400-e29b-41d4-a716-446655440002', 'ff0e8400-e29b-41d4-a716-446655440009', 'price > 0', 'high', true, '660e8400-e29b-41d4-a716-446655440001', '770e8400-e29b-41d4-a716-446655440001');

-- Insert sample compliance frameworks
INSERT INTO compliance_frameworks (id, name, display_name, description, framework_type, jurisdiction, is_active) VALUES
('330e8400-e29b-41d4-a716-446655440001', 'gdpr', 'GDPR', 'General Data Protection Regulation', 'gdpr', 'European Union', true),
('330e8400-e29b-41d4-a716-446655440002', 'ccpa', 'CCPA', 'California Consumer Privacy Act', 'ccpa', 'California, USA', true),
('330e8400-e29b-41d4-a716-446655440003', 'sox', 'SOX', 'Sarbanes-Oxley Act', 'sox', 'United States', true);

-- Insert sample external systems
INSERT INTO external_systems (id, name, display_name, description, system_type, vendor, is_active, owner_id, steward_id) VALUES
('440e8400-e29b-41d4-a716-446655440001', 'databricks_prod', 'Databricks Production', 'Production Databricks workspace', 'databricks', 'Databricks', true, '660e8400-e29b-41d4-a716-446655440001', '770e8400-e29b-41d4-a716-446655440001'),
('440e8400-e29b-41d4-a716-446655440002', 'informatica_axon', 'Informatica Axon', 'Informatica Axon governance platform', 'informatica', 'Informatica', true, '660e8400-e29b-41d4-a716-446655440002', '770e8400-e29b-41d4-a716-446655440002'),
('440e8400-e29b-41d4-a716-446655440003', 'snowflake_dw', 'Snowflake Data Warehouse', 'Snowflake data warehouse', 'snowflake', 'Snowflake', true, '660e8400-e29b-41d4-a716-446655440003', '770e8400-e29b-41d4-a716-446655440003');

-- Insert sample SLAs
INSERT INTO service_level_agreements (id, name, display_name, description, sla_type, target_value, unit, owner_id, steward_id, status) VALUES
('550e8400-e29b-41d4-a716-446655440101', 'data_freshness_sla', 'Data Freshness SLA', 'Data must be updated within 4 hours', 'freshness', 4.0, 'hours', '660e8400-e29b-41d4-a716-446655440001', '770e8400-e29b-41d4-a716-446655440001', 'active'),
('550e8400-e29b-41d4-a716-446655440102', 'data_quality_sla', 'Data Quality SLA', 'Data quality score must be above 95%', 'quality', 95.0, 'percentage', '660e8400-e29b-41d4-a716-446655440002', '770e8400-e29b-41d4-a716-446655440001', 'active'),
('550e8400-e29b-41d4-a716-446655440103', 'api_availability_sla', 'API Availability SLA', 'API must be available 99.9% of the time', 'availability', 99.9, 'percentage', '660e8400-e29b-41d4-a716-446655440001', '770e8400-e29b-41d4-a716-446655440001', 'active');

-- Insert sample data contracts
INSERT INTO data_contracts (id, name, display_name, description, version, asset_id, provider_id, consumer_id, contract_type, sla_id, status) VALUES
('660e8400-e29b-41d4-a716-446655440101', 'customer_data_contract', 'Customer Data Contract', 'Contract for customer data access', '1.0', 'ee0e8400-e29b-41d4-a716-446655440001', '660e8400-e29b-41d4-a716-446655440002', '660e8400-e29b-41d4-a716-446655440003', 'dataset', '550e8400-e29b-41d4-a716-446655440102', 'active'),
('660e8400-e29b-41d4-a716-446655440102', 'product_api_contract', 'Product API Contract', 'Contract for product API access', '2.1', 'ee0e8400-e29b-41d4-a716-446655440002', '660e8400-e29b-41d4-a716-446655440001', '660e8400-e29b-41d4-a716-446655440002', 'api', '550e8400-e29b-41d4-a716-446655440101', 'active');

-- Insert sample monitoring alerts
INSERT INTO monitoring_alerts (id, name, display_name, description, alert_type, asset_id, severity, is_active, owner_id, steward_id) VALUES
('770e8400-e29b-41d4-a716-446655440101', 'customer_data_quality_alert', 'Customer Data Quality Alert', 'Alert when customer data quality drops below threshold', 'quality', 'ee0e8400-e29b-41d4-a716-446655440001', 'high', true, '660e8400-e29b-41d4-a716-446655440002', '770e8400-e29b-41d4-a716-446655440001'),
('770e8400-e29b-41d4-a716-446655440102', 'product_availability_alert', 'Product Data Availability Alert', 'Alert when product data is not available', 'availability', 'ee0e8400-e29b-41d4-a716-446655440002', 'critical', true, '660e8400-e29b-41d4-a716-446655440001', '770e8400-e29b-41d4-a716-446655440001');

-- Insert sample quality metrics (recent data)
INSERT INTO data_quality_metrics (id, asset_id, metric_date, completeness_score, accuracy_score, consistency_score, validity_score, uniqueness_score, overall_score, total_records) VALUES
('880e8400-e29b-41d4-a716-446655440101', 'ee0e8400-e29b-41d4-a716-446655440001', CURRENT_DATE - INTERVAL '1 day', 98.5, 96.2, 99.1, 97.8, 99.9, 98.3, 150000),
('880e8400-e29b-41d4-a716-446655440102', 'ee0e8400-e29b-41d4-a716-446655440001', CURRENT_DATE, 98.7, 96.5, 99.2, 98.1, 99.9, 98.5, 151200),
('880e8400-e29b-41d4-a716-446655440103', 'ee0e8400-e29b-41d4-a716-446655440002', CURRENT_DATE - INTERVAL '1 day', 99.2, 98.1, 97.5, 99.0, 98.8, 98.5, 25000),
('880e8400-e29b-41d4-a716-446655440104', 'ee0e8400-e29b-41d4-a716-446655440002', CURRENT_DATE, 99.1, 98.3, 97.8, 99.2, 98.9, 98.7, 25150);

-- Insert sample access permissions
INSERT INTO access_permissions (id, user_id, asset_id, permission_type, granted_by, granted_at, justification, is_active) VALUES
('990e8400-e29b-41d4-a716-446655440101', '550e8400-e29b-41d4-a716-446655440003', 'ee0e8400-e29b-41d4-a716-446655440001', 'read', '550e8400-e29b-41d4-a716-446655440001', CURRENT_TIMESTAMP, 'Data science analysis requirements', true),
('990e8400-e29b-41d4-a716-446655440102', '550e8400-e29b-41d4-a716-446655440004', 'ee0e8400-e29b-41d4-a716-446655440002', 'read', '550e8400-e29b-41d4-a716-446655440001', CURRENT_TIMESTAMP, 'Business intelligence reporting', true),
('990e8400-e29b-41d4-a716-446655440103', '550e8400-e29b-41d4-a716-446655440002', 'ee0e8400-e29b-41d4-a716-446655440001', 'write', '550e8400-e29b-41d4-a716-446655440001', CURRENT_TIMESTAMP, 'Data engineering maintenance', true);

-- Insert sample audit logs (recent activity)
INSERT INTO audit_logs (id, entity_type, entity_id, action, user_id, timestamp, old_values, new_values, reason) VALUES
('aa0e8400-e29b-41d4-a716-446655440101', 'data_assets', 'ee0e8400-e29b-41d4-a716-446655440001', 'update', '550e8400-e29b-41d4-a716-446655440002', CURRENT_TIMESTAMP - INTERVAL '2 hours', '{"description": "Customer information table"}', '{"description": "Main customer information table"}', 'Updated description for clarity'),
('aa0e8400-e29b-41d4-a716-446655440102', 'data_quality_rules', '220e8400-e29b-41d4-a716-446655440001', 'create', '550e8400-e29b-41d4-a716-446655440002', CURRENT_TIMESTAMP - INTERVAL '1 day', null, '{"name": "customer_email_format", "severity": "high"}', 'Added new email validation rule'),
('aa0e8400-e29b-41d4-a716-446655440103', 'access_permissions', '990e8400-e29b-41d4-a716-446655440101', 'create', '550e8400-e29b-41d4-a716-446655440001', CURRENT_TIMESTAMP - INTERVAL '3 hours', null, '{"user_id": "550e8400-e29b-41d4-a716-446655440003", "permission_type": "read"}', 'Granted read access for data science team');

-- Update counts and statistics
UPDATE data_schemas SET asset_count = (SELECT COUNT(*) FROM data_assets WHERE schema_id = data_schemas.id);
UPDATE data_catalogs SET last_sync_at = CURRENT_TIMESTAMP;
UPDATE business_domains SET term_count = (SELECT COUNT(*) FROM business_terms WHERE domain_id = business_domains.id);
UPDATE data_owners SET asset_count = (SELECT COUNT(*) FROM data_assets WHERE owner_id = data_owners.id);
UPDATE data_stewards SET asset_count = (SELECT COUNT(*) FROM data_assets WHERE steward_id = data_stewards.id);

-- Create some sample lineage relationships
INSERT INTO data_lineage (id, source_asset_id, target_asset_id, lineage_type, transformation_logic, process_id, confidence_score, discovery_method, is_active) VALUES
('bb0e8400-e29b-41d4-a716-446655440101', 'ee0e8400-e29b-41d4-a716-446655440001', 'ee0e8400-e29b-41d4-a716-446655440004', 'direct', 'Direct join between customers and orders', '110e8400-e29b-41d4-a716-446655440001', 0.95, 'automated', true),
('bb0e8400-e29b-41d4-a716-446655440102', 'ee0e8400-e29b-41d4-a716-446655440002', 'ee0e8400-e29b-41d4-a716-446655440004', 'direct', 'Product information lookup', '110e8400-e29b-41d4-a716-446655440002', 0.98, 'automated', true);

COMMIT;

