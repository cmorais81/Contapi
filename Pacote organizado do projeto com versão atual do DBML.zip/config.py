"""
TBR GDP Core - Configuration Management
"""

import os
from functools import lru_cache
from typing import List, Optional

from pydantic import Field, validator
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Application settings"""
    
    # API Configuration
    API_HOST: str = Field(default="0.0.0.0", description="API host")
    API_PORT: int = Field(default=8000, description="API port")
    API_DEBUG: bool = Field(default=False, description="Debug mode")
    API_RELOAD: bool = Field(default=False, description="Auto-reload on changes")
    
    # Database Configuration
    DATABASE_URL: str = Field(
        default="postgresql://tbr_gdpcore_user:tbr_gdpcore_pass@localhost:5432/tbr_gdpcore_dtgovapi",
        description="Database connection URL"
    )
    DATABASE_ECHO: bool = Field(default=False, description="Echo SQL queries")
    DATABASE_POOL_SIZE: int = Field(default=10, description="Database connection pool size")
    DATABASE_MAX_OVERFLOW: int = Field(default=20, description="Database max overflow connections")
    
    # Security Configuration
    SECRET_KEY: str = Field(default="your-secret-key-change-this", description="Application secret key")
    JWT_SECRET_KEY: str = Field(default="your-jwt-secret-change-this", description="JWT secret key")
    JWT_ALGORITHM: str = Field(default="HS256", description="JWT algorithm")
    JWT_EXPIRE_MINUTES: int = Field(default=30, description="JWT expiration time in minutes")
    
    # CORS Configuration
    CORS_ORIGINS: List[str] = Field(
        default=["http://localhost:3000", "http://localhost:8080", "http://127.0.0.1:3000"],
        description="Allowed CORS origins"
    )
    ALLOWED_HOSTS: List[str] = Field(
        default=["localhost", "127.0.0.1", "0.0.0.0"],
        description="Allowed hosts"
    )
    
    # External Integrations
    DATABRICKS_HOST: Optional[str] = Field(default=None, description="Databricks workspace URL")
    DATABRICKS_TOKEN: Optional[str] = Field(default=None, description="Databricks access token")
    DATABRICKS_WAREHOUSE_ID: Optional[str] = Field(default=None, description="Databricks SQL warehouse ID")
    
    INFORMATICA_AXON_URL: Optional[str] = Field(default=None, description="Informatica Axon URL")
    INFORMATICA_AXON_TOKEN: Optional[str] = Field(default=None, description="Informatica Axon token")
    INFORMATICA_AXON_USERNAME: Optional[str] = Field(default=None, description="Informatica Axon username")
    INFORMATICA_AXON_PASSWORD: Optional[str] = Field(default=None, description="Informatica Axon password")
    
    # Redis Configuration (optional)
    REDIS_URL: Optional[str] = Field(default=None, description="Redis connection URL")
    REDIS_PASSWORD: Optional[str] = Field(default=None, description="Redis password")
    REDIS_DB: int = Field(default=0, description="Redis database number")
    
    # Logging Configuration
    LOG_LEVEL: str = Field(default="INFO", description="Logging level")
    LOG_FORMAT: str = Field(default="json", description="Log format: json or text")
    LOG_FILE: Optional[str] = Field(default=None, description="Log file path")
    
    # Monitoring Configuration
    METRICS_ENABLED: bool = Field(default=True, description="Enable Prometheus metrics")
    HEALTH_CHECK_INTERVAL: int = Field(default=60, description="Health check interval in seconds")
    
    # Data Quality Configuration
    QUALITY_CHECK_BATCH_SIZE: int = Field(default=1000, description="Quality check batch size")
    QUALITY_RETENTION_DAYS: int = Field(default=90, description="Quality metrics retention in days")
    
    # Sync Configuration
    SYNC_ENABLED: bool = Field(default=True, description="Enable external system synchronization")
    SYNC_INTERVAL_MINUTES: int = Field(default=60, description="Sync interval in minutes")
    SYNC_BATCH_SIZE: int = Field(default=100, description="Sync batch size")
    
    # File Storage Configuration
    STORAGE_TYPE: str = Field(default="local", description="Storage type: local, s3, azure, gcs")
    STORAGE_PATH: str = Field(default="./storage", description="Local storage path")
    STORAGE_BUCKET: Optional[str] = Field(default=None, description="Cloud storage bucket")
    
    # Email Configuration (optional)
    SMTP_HOST: Optional[str] = Field(default=None, description="SMTP server host")
    SMTP_PORT: int = Field(default=587, description="SMTP server port")
    SMTP_USERNAME: Optional[str] = Field(default=None, description="SMTP username")
    SMTP_PASSWORD: Optional[str] = Field(default=None, description="SMTP password")
    SMTP_USE_TLS: bool = Field(default=True, description="Use TLS for SMTP")
    
    # Notification Configuration
    SLACK_WEBHOOK_URL: Optional[str] = Field(default=None, description="Slack webhook URL")
    TEAMS_WEBHOOK_URL: Optional[str] = Field(default=None, description="Microsoft Teams webhook URL")
    
    # Rate Limiting Configuration
    RATE_LIMIT_ENABLED: bool = Field(default=True, description="Enable rate limiting")
    RATE_LIMIT_REQUESTS: int = Field(default=100, description="Rate limit requests per minute")
    RATE_LIMIT_WINDOW: int = Field(default=60, description="Rate limit window in seconds")
    
    # Cache Configuration
    CACHE_ENABLED: bool = Field(default=True, description="Enable caching")
    CACHE_TTL: int = Field(default=300, description="Cache TTL in seconds")
    
    # Development Configuration
    DEV_MODE: bool = Field(default=False, description="Development mode")
    MOCK_EXTERNAL_SERVICES: bool = Field(default=False, description="Mock external services")
    
    @validator("LOG_LEVEL")
    def validate_log_level(cls, v):
        """Validate log level"""
        valid_levels = ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
        if v.upper() not in valid_levels:
            raise ValueError(f"LOG_LEVEL must be one of {valid_levels}")
        return v.upper()
    
    @validator("LOG_FORMAT")
    def validate_log_format(cls, v):
        """Validate log format"""
        valid_formats = ["json", "text"]
        if v.lower() not in valid_formats:
            raise ValueError(f"LOG_FORMAT must be one of {valid_formats}")
        return v.lower()
    
    @validator("STORAGE_TYPE")
    def validate_storage_type(cls, v):
        """Validate storage type"""
        valid_types = ["local", "s3", "azure", "gcs"]
        if v.lower() not in valid_types:
            raise ValueError(f"STORAGE_TYPE must be one of {valid_types}")
        return v.lower()
    
    @validator("JWT_ALGORITHM")
    def validate_jwt_algorithm(cls, v):
        """Validate JWT algorithm"""
        valid_algorithms = ["HS256", "HS384", "HS512", "RS256", "RS384", "RS512"]
        if v not in valid_algorithms:
            raise ValueError(f"JWT_ALGORITHM must be one of {valid_algorithms}")
        return v
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = True


@lru_cache()
def get_settings() -> Settings:
    """Get cached application settings"""
    return Settings()


def get_database_url() -> str:
    """Get database URL from settings"""
    settings = get_settings()
    return settings.DATABASE_URL


def is_development() -> bool:
    """Check if running in development mode"""
    settings = get_settings()
    return settings.DEV_MODE or settings.API_DEBUG


def is_testing() -> bool:
    """Check if running in testing mode"""
    return os.getenv("TESTING", "false").lower() == "true"

