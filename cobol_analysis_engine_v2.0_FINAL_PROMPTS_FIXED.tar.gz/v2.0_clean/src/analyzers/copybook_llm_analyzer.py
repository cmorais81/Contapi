import re
import logging
from typing import Dict, Any, List, Tuple

class CopybookLLMAnalyzer:
    """
    Analisador que combina copybooks do books.txt com LLM para simular
    e documentar completamente os arquivos de entrada que não foram detectados.
    """

    def __init__(self, llm_provider: Any = None):
        self.logger = logging.getLogger(__name__)
        self.llm_provider = llm_provider

    def analyze_missing_files(self, program_name: str, resolved_code: str, 
                            copybooks_content: str, detected_files: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analisa arquivos de entrada não detectados usando copybooks e LLM.
        """
        self.logger.info(f"Analisando arquivos não detectados para {program_name}")

        # 1. Identifica arquivos de entrada mencionados no código
        mentioned_files = self._extract_mentioned_files(resolved_code)
        
        # 2. Identifica copybooks relevantes
        relevant_copybooks = self._find_relevant_copybooks(resolved_code, copybooks_content)
        
        # 3. Gera prompt para LLM simular os arquivos
        simulation_prompt = self._generate_simulation_prompt(
            program_name, resolved_code, mentioned_files, relevant_copybooks
        )
        
        # 4. Processa resposta do LLM (ou simula se não disponível)
        if self.llm_provider:
            llm_response = self.llm_provider.generate_text(simulation_prompt)
            simulated_files = self._parse_llm_response(llm_response)
        else:
            # Fallback: simulação baseada em regras
            simulated_files = self._simulate_files_with_rules(mentioned_files, relevant_copybooks)
        
        return {
            "mentioned_files": mentioned_files,
            "relevant_copybooks": relevant_copybooks,
            "simulated_input_files": simulated_files,
            "simulation_method": "llm" if self.llm_provider else "rules"
        }

    def _extract_mentioned_files(self, code: str) -> List[Dict[str, str]]:
        """Extrai todos os arquivos mencionados no código."""
        files = []
        lines = code.split('\n')
        
        for line in lines:
            line = line.strip()
            
            # SELECT statements
            select_match = re.search(r'SELECT\s+(\w+)\s+ASSIGN\s+(\w+)', line)
            if select_match:
                logical_name = select_match.group(1)
                physical_name = select_match.group(2)
                
                # Determina se é entrada baseado no padrão de nomenclatura
                file_type = "input" if any(logical_name.endswith(suffix) for suffix in ['E1', 'E2', 'E3', 'E4', 'E5']) else "output"
                
                files.append({
                    "logical_name": logical_name,
                    "physical_name": physical_name,
                    "type": file_type,
                    "source": "SELECT"
                })
            
            # FD statements
            fd_match = re.search(r'FD\s+(\w+)', line)
            if fd_match:
                fd_name = fd_match.group(1)
                
                # Verifica se já foi capturado no SELECT
                if not any(f["logical_name"] == fd_name for f in files):
                    file_type = "input" if any(fd_name.endswith(suffix) for suffix in ['E1', 'E2', 'E3', 'E4', 'E5']) else "output"
                    files.append({
                        "logical_name": fd_name,
                        "physical_name": fd_name,
                        "type": file_type,
                        "source": "FD"
                    })
            
            # COPY statements
            copy_match = re.search(r'COPY\s+(\w+)', line)
            if copy_match:
                copybook_name = copy_match.group(1)
                files.append({
                    "logical_name": copybook_name,
                    "physical_name": copybook_name,
                    "type": "copybook",
                    "source": "COPY"
                })
        
        return files

    def _find_relevant_copybooks(self, code: str, copybooks_content: str) -> Dict[str, str]:
        """Encontra copybooks relevantes no books.txt."""
        relevant_books = {}
        
        # Extrai nomes de copybooks mencionados no código
        copy_statements = re.findall(r'COPY\s+(\w+)', code)
        
        # Procura cada copybook no books.txt
        for copybook_name in copy_statements:
            copybook_content = self._extract_copybook_content(copybook_name, copybooks_content)
            if copybook_content:
                relevant_books[copybook_name] = copybook_content
        
        return relevant_books

    def _extract_copybook_content(self, copybook_name: str, books_content: str) -> str:
        """Extrai o conteúdo de um copybook específico do books.txt."""
        lines = books_content.split('\n')
        content_lines = []
        capturing = False
        
        for line in lines:
            # Procura pelo início do copybook
            if f"VMEMBER NAME  {copybook_name}" in line:
                capturing = True
                continue
            
            # Para quando encontrar outro VMEMBER
            if capturing and "VMEMBER NAME" in line and copybook_name not in line:
                break
            
            # Captura o conteúdo
            if capturing and line.startswith('V'):
                # Remove o prefixo 'V' e adiciona à lista
                content_lines.append(line[1:])
        
        return '\n'.join(content_lines)

    def _generate_simulation_prompt(self, program_name: str, code: str, 
                                  mentioned_files: List[Dict], 
                                  copybooks: Dict[str, str]) -> str:
        """Gera um prompt detalhado para o LLM simular os arquivos de entrada."""
        
        input_files = [f for f in mentioned_files if f["type"] == "input"]
        
        prompt = f"""# SIMULAÇÃO DE ARQUIVOS DE ENTRADA - PROGRAMA {program_name}

Você é um especialista em COBOL com 30 anos de experiência. Sua tarefa é analisar este programa COBOL e simular COMPLETAMENTE os arquivos de entrada que não foram detectados automaticamente.

## CÓDIGO DO PROGRAMA:
```cobol
{code[:3000]}...
```

## ARQUIVOS DE ENTRADA IDENTIFICADOS:
{self._format_files_for_prompt(input_files)}

## COPYBOOKS DISPONÍVEIS:
{self._format_copybooks_for_prompt(copybooks)}

## TAREFA:

Para cada arquivo de entrada identificado, forneça uma simulação COMPLETA em formato YAML:

```yaml
input_files:
  - logical_name: "LHS542E1"
    physical_name: "LHS542E1"
    record_size: 999
    format: "fixed"
    description: "Descrição específica do arquivo baseada no código"
    fields:
      - name: "CAMPO1"
        position: 1
        length: 15
        type: "numeric"
        picture: "9(15)"
        usage: "DISPLAY"
        description: "Descrição do campo baseada no uso no programa"
      - name: "CAMPO2"
        position: 16
        length: 3
        type: "numeric"
        picture: "9(03)"
        usage: "DISPLAY"
        description: "Descrição do campo"
    business_purpose: "Propósito específico deste arquivo no contexto do programa"
    processing_logic: "Como este arquivo é processado no programa"
```

## INSTRUÇÕES ESPECÍFICAS:

1. **ANALISE O CÓDIGO:** Identifique como cada arquivo é usado no programa
2. **USE OS COPYBOOKS:** Se um arquivo usa COPY, incorpore a estrutura do copybook
3. **CALCULE POSIÇÕES:** Determine posições exatas dos campos baseado nos PICs
4. **DETERMINE PROPÓSITO:** Explique para que serve cada arquivo no contexto do programa
5. **SEJA ESPECÍFICO:** Não use descrições genéricas, baseie-se no código real

**IMPORTANTE:** Forneça informações PRECISAS que permitam a um programador reimplementar o processamento destes arquivos perfeitamente.
"""
        return prompt

    def _format_files_for_prompt(self, files: List[Dict]) -> str:
        """Formata a lista de arquivos para o prompt."""
        if not files:
            return "Nenhum arquivo de entrada identificado automaticamente."
        
        result = []
        for file_info in files:
            result.append(f"- {file_info['logical_name']} ({file_info['type']}) - Fonte: {file_info['source']}")
        
        return '\n'.join(result)

    def _format_copybooks_for_prompt(self, copybooks: Dict[str, str]) -> str:
        """Formata os copybooks para o prompt."""
        if not copybooks:
            return "Nenhum copybook relevante encontrado."
        
        result = []
        for name, content in copybooks.items():
            # Limita o conteúdo para não sobrecarregar o prompt
            limited_content = content[:500] + "..." if len(content) > 500 else content
            result.append(f"### {name}:\n```cobol\n{limited_content}\n```")
        
        return '\n'.join(result)

    def _parse_llm_response(self, response: str) -> List[Dict[str, Any]]:
        """Processa a resposta do LLM."""
        try:
            # Extrai o conteúdo YAML
            yaml_match = re.search(r"```yaml\n(.*?)\n```", response, re.DOTALL)
            if yaml_match:
                import yaml
                parsed = yaml.safe_load(yaml_match.group(1))
                return parsed.get("input_files", [])
            else:
                self.logger.warning("Resposta do LLM não contém YAML válido")
                return []
        except Exception as e:
            self.logger.error(f"Erro ao processar resposta do LLM: {e}")
            return []

    def _simulate_files_with_rules(self, mentioned_files: List[Dict], 
                                 copybooks: Dict[str, str]) -> List[Dict[str, Any]]:
        """Simulação baseada em regras quando LLM não está disponível."""
        simulated_files = []
        
        input_files = [f for f in mentioned_files if f["type"] == "input"]
        
        for file_info in input_files:
            logical_name = file_info["logical_name"]
            
            # Simulação baseada em padrões conhecidos
            simulated_file = {
                "logical_name": logical_name,
                "physical_name": file_info["physical_name"],
                "record_size": self._estimate_record_size(logical_name),
                "format": "fixed",
                "description": self._generate_file_description(logical_name),
                "fields": self._simulate_fields(logical_name, copybooks),
                "business_purpose": self._determine_business_purpose(logical_name),
                "processing_logic": "Arquivo processado sequencialmente pelo programa"
            }
            
            simulated_files.append(simulated_file)
        
        return simulated_files

    def _estimate_record_size(self, logical_name: str) -> int:
        """Estima o tamanho do registro baseado no padrão do nome."""
        # Padrões conhecidos para diferentes tipos de arquivo
        size_patterns = {
            "E1": 80,   # Arquivo de controle
            "E2": 100,  # Arquivo de parâmetros
            "E3": 80,   # Arquivo de dados
            "E4": 80,   # Arquivo de relacionamento
            "E5": 154   # Arquivo de responsável (baseado no comentário do código)
        }
        
        for suffix, size in size_patterns.items():
            if logical_name.endswith(suffix):
                return size
        
        return 80  # Default

    def _generate_file_description(self, logical_name: str) -> str:
        """Gera descrição do arquivo baseada no nome."""
        descriptions = {
            "E1": "Arquivo de controle com totais e parâmetros de processamento",
            "E2": "Arquivo de parâmetros de cliente e remessa",
            "E3": "Arquivo de dados principais para processamento",
            "E4": "Arquivo de relacionamento e quantidades",
            "E5": "Arquivo de dados do responsável (CADOC3040)"
        }
        
        for suffix, desc in descriptions.items():
            if logical_name.endswith(suffix):
                return desc
        
        return "Arquivo de entrada para processamento"

    def _simulate_fields(self, logical_name: str, copybooks: Dict[str, str]) -> List[Dict[str, Any]]:
        """Simula campos do arquivo baseado em padrões."""
        # Se há copybook relevante, tenta extrair campos dele
        for copybook_name, content in copybooks.items():
            if copybook_name in logical_name or logical_name in copybook_name:
                return self._extract_fields_from_copybook(content)
        
        # Simulação baseada em padrões conhecidos
        field_patterns = {
            "E1": [
                {"name": "TOT-LIDOS", "position": 1, "length": 15, "type": "numeric", "picture": "9(15)", "description": "Total de registros lidos"},
                {"name": "TOT-PARTIC", "position": 16, "length": 3, "type": "numeric", "picture": "9(03)", "description": "Total de partições"}
            ],
            "E2": [
                {"name": "ID-CLIENTE", "position": 1, "length": 6, "type": "alphanumeric", "picture": "X(06)", "description": "Identificação do cliente"},
                {"name": "NR-REMESSA", "position": 52, "length": 1, "type": "numeric", "picture": "9(01)", "description": "Número da remessa"},
                {"name": "NR-PARTE", "position": 62, "length": 1, "type": "numeric", "picture": "9(01)", "description": "Número da parte"},
                {"name": "TP-ARQUIVO", "position": 65, "length": 10, "type": "alphanumeric", "picture": "X(10)", "description": "Tipo do arquivo"}
            ],
            "E3": [
                {"name": "REGISTRO-E3", "position": 1, "length": 80, "type": "alphanumeric", "picture": "X(80)", "description": "Registro completo do arquivo E3"}
            ],
            "E4": [
                {"name": "RELA-IDT", "position": 1, "length": 5, "type": "alphanumeric", "picture": "X(05)", "description": "Identificação do relacionamento"},
                {"name": "RELA-QTDE", "position": 6, "length": 15, "type": "numeric", "picture": "9(15)", "description": "Quantidade do relacionamento"}
            ]
        }
        
        for suffix, fields in field_patterns.items():
            if logical_name.endswith(suffix):
                return fields
        
        return [{"name": "REGISTRO-COMPLETO", "position": 1, "length": 80, "type": "alphanumeric", "picture": "X(80)", "description": "Registro completo"}]

    def _extract_fields_from_copybook(self, copybook_content: str) -> List[Dict[str, Any]]:
        """Extrai campos de um copybook."""
        fields = []
        lines = copybook_content.split('\n')
        
        for line in lines:
            line = line.strip()
            
            # Procura por definições de campo
            field_match = re.search(r'(\d+)\s+(\w+)\s+PIC\s+([X9V\(\)]+)', line)
            if field_match:
                level = int(field_match.group(1))
                name = field_match.group(2)
                picture = field_match.group(3)
                
                if level == 5:  # Apenas campos de nível 05
                    fields.append({
                        "name": name,
                        "position": len(fields) * 10 + 1,  # Estimativa
                        "length": self._calculate_pic_length(picture),
                        "type": "numeric" if "9" in picture else "alphanumeric",
                        "picture": picture,
                        "description": f"Campo {name} do copybook"
                    })
        
        return fields

    def _calculate_pic_length(self, picture: str) -> int:
        """Calcula o tamanho baseado na cláusula PIC."""
        if '(' in picture and ')' in picture:
            match = re.search(r'\((\d+)\)', picture)
            if match:
                return int(match.group(1))
        
        return len(re.findall(r'[X9V]', picture))

    def _determine_business_purpose(self, logical_name: str) -> str:
        """Determina o propósito de negócio do arquivo."""
        purposes = {
            "E1": "Controle de processamento e totalizadores",
            "E2": "Parâmetros de cliente e configuração de remessa",
            "E3": "Dados principais para particionamento",
            "E4": "Relacionamentos e quantidades para validação",
            "E5": "Dados do responsável para compliance CADOC3040"
        }
        
        for suffix, purpose in purposes.items():
            if logical_name.endswith(suffix):
                return purpose
        
        return "Dados de entrada para processamento do programa"
