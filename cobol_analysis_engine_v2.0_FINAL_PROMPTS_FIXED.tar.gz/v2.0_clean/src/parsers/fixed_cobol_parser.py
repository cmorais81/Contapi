"""
Parser COBOL Corrigido - Extrai dados reais do código COBOL
Versão 6.0 - Focado em resultados práticos
"""

import re
import logging
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass

@dataclass
class COBOLFile:
    """Representa um arquivo COBOL"""
    name: str
    type: str  # INPUT, OUTPUT, UPDATE
    record_name: str
    record_size: int
    description: str

@dataclass
class COBOLField:
    """Representa um campo COBOL"""
    name: str
    level: int
    picture: str
    size: int
    type: str  # NUMERIC, ALPHANUMERIC, etc.
    position: int
    description: str

@dataclass
class COBOLParagraph:
    """Representa um parágrafo COBOL"""
    name: str
    section: str
    lines: List[str]
    purpose: str
    calls_to: List[str]
    called_by: List[str]

@dataclass
class COBOLProgram:
    """Representa um programa COBOL completo"""
    program_id: str
    author: str
    date_written: str
    purpose: str
    files: List[COBOLFile]
    fields: List[COBOLField]
    paragraphs: List[COBOLParagraph]
    business_logic: Dict[str, Any]
    validation_rules: List[str]
    processing_flow: List[str]

class FixedCOBOLParser:
    """Parser COBOL que realmente extrai dados úteis"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
    def parse_program(self, cobol_lines: List[str]) -> COBOLProgram:
        """
        Analisa um programa COBOL completo e extrai todas as informações úteis
        
        Args:
            cobol_lines: Lista de linhas do código COBOL
            
        Returns:
            COBOLProgram com todas as informações extraídas
        """
        self.logger.info("Iniciando análise completa do programa COBOL")
        
        # Extrair informações básicas
        program_id = self._extract_program_id(cobol_lines)
        author = self._extract_author(cobol_lines)
        date_written = self._extract_date_written(cobol_lines)
        purpose = self._extract_purpose(cobol_lines)
        
        # Extrair arquivos
        files = self._extract_files(cobol_lines)
        
        # Extrair campos da WORKING-STORAGE
        fields = self._extract_working_storage_fields(cobol_lines)
        
        # Extrair parágrafos e lógica
        paragraphs = self._extract_paragraphs(cobol_lines)
        
        # Extrair lógica de negócio
        business_logic = self._extract_business_logic(cobol_lines)
        
        # Extrair regras de validação
        validation_rules = self._extract_validation_rules(cobol_lines)
        
        # Extrair fluxo de processamento
        processing_flow = self._extract_processing_flow(cobol_lines)
        
        program = COBOLProgram(
            program_id=program_id,
            author=author,
            date_written=date_written,
            purpose=purpose,
            files=files,
            fields=fields,
            paragraphs=paragraphs,
            business_logic=business_logic,
            validation_rules=validation_rules,
            processing_flow=processing_flow
        )
        
        self.logger.info(f"Análise concluída: {len(files)} arquivos, {len(fields)} campos, {len(paragraphs)} parágrafos")
        return program
    
    def _extract_program_id(self, lines: List[str]) -> str:
        """Extrai o PROGRAM-ID"""
        for line in lines:
            if 'PROGRAM-ID' in line.upper():
                match = re.search(r'PROGRAM-ID\.\s*(\w+)', line.upper())
                if match:
                    return match.group(1)
        return "UNKNOWN"
    
    def _extract_author(self, lines: List[str]) -> str:
        """Extrai o AUTHOR"""
        for line in lines:
            if 'AUTHOR' in line.upper():
                match = re.search(r'AUTHOR\.\s*(.+)', line)
                if match:
                    return match.group(1).strip()
        return "UNKNOWN"
    
    def _extract_date_written(self, lines: List[str]) -> str:
        """Extrai o DATE-WRITTEN"""
        for line in lines:
            if 'DATE-WRITTEN' in line.upper():
                match = re.search(r'DATE-WRITTEN\.\s*(.+)', line)
                if match:
                    return match.group(1).strip()
        return "UNKNOWN"
    
    def _extract_purpose(self, lines: List[str]) -> str:
        """Extrai o propósito do programa dos comentários"""
        purpose_lines = []
        in_purpose_section = False
        
        for line in lines:
            line_clean = line.strip()
            if 'OBJETIVO DO PROGRAMA' in line_clean:
                in_purpose_section = True
                continue
            elif in_purpose_section and line_clean.startswith('*'):
                if '***' in line_clean and 'OBJETIVO' not in line_clean:
                    break
                purpose_lines.append(line_clean.replace('*', '').strip())
            elif in_purpose_section and not line_clean.startswith('*'):
                break
        
        return ' '.join(purpose_lines) if purpose_lines else "Propósito não identificado"
    
    def _extract_files(self, lines: List[str]) -> List[COBOLFile]:
        """Extrai informações dos arquivos"""
        files = []
        current_file = None
        
        for i, line in enumerate(lines):
            line_clean = line.strip().upper()
            
            # SELECT statements
            if 'SELECT' in line_clean and 'ASSIGN' in line_clean:
                match = re.search(r'SELECT\s+(\w+)', line_clean)
                if match:
                    file_name = match.group(1)
                    file_type = self._determine_file_type(file_name, lines)
                    
                    # Procurar FD correspondente
                    record_info = self._find_fd_info(file_name, lines)
                    
                    files.append(COBOLFile(
                        name=file_name,
                        type=file_type,
                        record_name=record_info['record_name'],
                        record_size=record_info['record_size'],
                        description=record_info['description']
                    ))
        
        return files
    
    def _determine_file_type(self, file_name: str, lines: List[str]) -> str:
        """Determina o tipo do arquivo baseado no uso"""
        for line in lines:
            line_upper = line.upper()
            if f'OPEN INPUT {file_name}' in line_upper:
                return "INPUT"
            elif f'OPEN OUTPUT {file_name}' in line_upper:
                return "OUTPUT"
            elif f'OPEN I-O {file_name}' in line_upper:
                return "UPDATE"
        return "UNKNOWN"
    
    def _find_fd_info(self, file_name: str, lines: List[str]) -> Dict[str, Any]:
        """Encontra informações do FD para um arquivo"""
        info = {
            'record_name': 'UNKNOWN',
            'record_size': 0,
            'description': 'Registro não identificado'
        }
        
        for i, line in enumerate(lines):
            if f'FD  {file_name}' in line.upper():
                # Procurar RECORD CONTAINS
                for j in range(i, min(i+5, len(lines))):
                    if 'RECORD CONTAINS' in lines[j].upper():
                        match = re.search(r'RECORD CONTAINS\s+(\d+)', lines[j].upper())
                        if match:
                            info['record_size'] = int(match.group(1))
                
                # Procurar 01 level
                for j in range(i+1, min(i+10, len(lines))):
                    if lines[j].strip().startswith('01'):
                        match = re.search(r'01\s+(\w+)', lines[j])
                        if match:
                            info['record_name'] = match.group(1)
                            break
                break
        
        return info
    
    def _extract_working_storage_fields(self, lines: List[str]) -> List[COBOLField]:
        """Extrai campos da WORKING-STORAGE SECTION"""
        fields = []
        in_working_storage = False
        current_position = 1
        
        for line in lines:
            line_clean = line.strip()
            
            if 'WORKING-STORAGE' in line_clean.upper():
                in_working_storage = True
                continue
            elif 'PROCEDURE' in line_clean.upper():
                in_working_storage = False
                break
            
            if in_working_storage and line_clean and not line_clean.startswith('*'):
                # Procurar definições de campo (05, 10, 15, etc.)
                match = re.search(r'(\d{2})\s+(\w+(?:-\w+)*)\s+PIC\s+([X9V\(\)]+)', line_clean.upper())
                if match:
                    level = int(match.group(1))
                    field_name = match.group(2)
                    picture = match.group(3)
                    
                    field_size = self._calculate_field_size(picture)
                    field_type = self._determine_field_type(picture)
                    
                    fields.append(COBOLField(
                        name=field_name,
                        level=level,
                        picture=picture,
                        size=field_size,
                        type=field_type,
                        position=current_position,
                        description=f"Campo {field_type.lower()} de {field_size} caracteres"
                    ))
                    
                    current_position += field_size
        
        return fields
    
    def _calculate_field_size(self, picture: str) -> int:
        """Calcula o tamanho de um campo baseado na cláusula PICTURE"""
        if '(' in picture and ')' in picture:
            match = re.search(r'\((\d+)\)', picture)
            if match:
                return int(match.group(1))
        return len(picture.replace('X', '').replace('9', '').replace('V', ''))
    
    def _determine_field_type(self, picture: str) -> str:
        """Determina o tipo do campo baseado na cláusula PICTURE"""
        if '9' in picture:
            return "NUMERIC"
        elif 'X' in picture:
            return "ALPHANUMERIC"
        else:
            return "UNKNOWN"
    
    def _extract_paragraphs(self, lines: List[str]) -> List[COBOLParagraph]:
        """Extrai parágrafos da PROCEDURE DIVISION"""
        paragraphs = []
        current_paragraph = None
        current_section = "MAIN"
        in_procedure = False
        
        for line in lines:
            line_clean = line.strip()
            
            if 'PROCEDURE' in line_clean.upper() and 'DIVISION' in line_clean.upper():
                in_procedure = True
                continue
            
            if not in_procedure:
                continue
            
            # Identificar seções
            if 'SECTION' in line_clean.upper() and not line_clean.startswith('*'):
                current_section = line_clean.replace('SECTION.', '').strip()
                continue
            
            # Identificar parágrafos
            if line_clean and not line_clean.startswith('*') and line_clean.endswith('.') and not any(keyword in line_clean.upper() for keyword in ['PERFORM', 'MOVE', 'IF', 'DISPLAY', 'OPEN', 'CLOSE', 'READ', 'WRITE']):
                # Finalizar parágrafo anterior
                if current_paragraph:
                    paragraphs.append(current_paragraph)
                
                # Iniciar novo parágrafo
                paragraph_name = line_clean.replace('.', '').strip()
                current_paragraph = COBOLParagraph(
                    name=paragraph_name,
                    section=current_section,
                    lines=[],
                    purpose=self._determine_paragraph_purpose(paragraph_name),
                    calls_to=[],
                    called_by=[]
                )
            elif current_paragraph and line_clean and not line_clean.startswith('*'):
                current_paragraph.lines.append(line_clean)
                
                # Identificar PERFORM calls
                if 'PERFORM' in line_clean.upper():
                    match = re.search(r'PERFORM\s+(\w+(?:-\w+)*)', line_clean.upper())
                    if match:
                        called_paragraph = match.group(1)
                        current_paragraph.calls_to.append(called_paragraph)
        
        # Adicionar último parágrafo
        if current_paragraph:
            paragraphs.append(current_paragraph)
        
        return paragraphs
    
    def _determine_paragraph_purpose(self, paragraph_name: str) -> str:
        """Determina o propósito de um parágrafo baseado no nome"""
        name_upper = paragraph_name.upper()
        
        if 'INICIALIZAR' in name_upper or 'INICIO' in name_upper:
            return "Inicialização do programa"
        elif 'PROCESSAR' in name_upper or 'PROCESS' in name_upper:
            return "Processamento principal"
        elif 'FINALIZAR' in name_upper or 'FIM' in name_upper:
            return "Finalização do programa"
        elif 'LER' in name_upper or 'READ' in name_upper:
            return "Leitura de dados"
        elif 'GRAVAR' in name_upper or 'WRITE' in name_upper:
            return "Gravação de dados"
        elif 'VALIDAR' in name_upper or 'VALID' in name_upper:
            return "Validação de dados"
        elif 'ROTEAR' in name_upper or 'ROUTE' in name_upper:
            return "Roteamento de dados"
        else:
            return "Processamento específico"
    
    def _extract_business_logic(self, lines: List[str]) -> Dict[str, Any]:
        """Extrai a lógica de negócio do programa"""
        logic = {
            'main_purpose': 'Particionamento de arquivo',
            'input_validation': [],
            'routing_logic': {},
            'file_management': {},
            'counters': []
        }
        
        for line in lines:
            line_clean = line.strip().upper()
            
            # Validações
            if 'NOT NUMERIC' in line_clean:
                logic['input_validation'].append("Validação de campo numérico")
            elif 'SPACES' in line_clean and 'IF' in line_clean:
                logic['input_validation'].append("Validação de campo não vazio")
            
            # Lógica de roteamento
            if 'EVALUATE' in line_clean:
                logic['routing_logic']['type'] = 'EVALUATE statement'
            elif 'WHEN' in line_clean:
                match = re.search(r"WHEN\s+'(\w+)'", line_clean)
                if match:
                    value = match.group(1)
                    logic['routing_logic'][value] = f"Roteamento para tipo {value}"
            
            # Contadores
            if 'ADD 1 TO' in line_clean:
                match = re.search(r'ADD 1 TO\s+(\w+(?:-\w+)*)', line_clean)
                if match:
                    counter = match.group(1)
                    logic['counters'].append(counter)
        
        return logic
    
    def _extract_validation_rules(self, lines: List[str]) -> List[str]:
        """Extrai regras de validação específicas"""
        rules = []
        
        for line in lines:
            line_clean = line.strip()
            
            if 'NOT NUMERIC' in line_clean.upper():
                rules.append("Campo deve ser numérico")
            elif 'SPACES' in line_clean.upper() and 'IF' in line_clean.upper():
                rules.append("Campo não pode estar vazio")
            elif 'NOT =' in line_clean and any(val in line_clean for val in ["'01'", "'02'", "'03'"]):
                rules.append("Tipo de registro deve ser 01, 02 ou 03")
        
        return rules
    
    def _extract_processing_flow(self, lines: List[str]) -> List[str]:
        """Extrai o fluxo de processamento principal"""
        flow = []
        
        for line in lines:
            line_clean = line.strip().upper()
            
            if 'PERFORM' in line_clean and any(keyword in line_clean for keyword in ['INICIALIZAR', 'PROCESSAR', 'FINALIZAR']):
                if 'INICIALIZAR' in line_clean:
                    flow.append("1. Inicialização (abertura de arquivos)")
                elif 'PROCESSAR' in line_clean:
                    flow.append("2. Processamento principal (leitura e roteamento)")
                elif 'FINALIZAR' in line_clean:
                    flow.append("3. Finalização (fechamento de arquivos)")
        
        if not flow:
            flow = [
                "1. Inicialização do programa",
                "2. Processamento de registros",
                "3. Finalização e estatísticas"
            ]
        
        return flow
