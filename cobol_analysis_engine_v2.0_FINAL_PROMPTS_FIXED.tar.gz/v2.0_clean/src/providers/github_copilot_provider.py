'''
Provedor GitHub Copilot para Sistema de Análise COBOL.
'''

import os
import httpx
import logging
from typing import Dict, Any
from .base_provider import BaseProvider, AIRequest, AIResponse

class GitHubCopilotProvider(BaseProvider):
    """
    Provedor para o GitHub Copilot.
    """

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        provider_config = config.get('ai', {}).get('providers', {}).get('github_copilot', {})
        self.token = provider_config.get("token") or os.getenv("GITHUB_TOKEN")
        self.api_url = "https://api.github.com/copilot/completions"
        self.logger = logging.getLogger(__name__)

    async def analyze(self, request: AIRequest) -> AIResponse:
        if not self.token:
            return self.create_error_response("Token do GitHub não configurado.", request)

        headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json"
        }
        data = {
            "prompt": request.prompt,
            "max_tokens": request.max_tokens
        }

        try:
            async with httpx.AsyncClient() as client:
                response = await client.post(self.api_url, headers=headers, json=data)
                response.raise_for_status()
                response_data = response.json()
                content = response_data.get("choices", [{}])[0].get("text", "")
                return self.create_success_response(content, 0, request) # Copilot API não informa tokens
        except httpx.HTTPStatusError as e:
            error_message = f"Erro na API do GitHub Copilot: {e}"
            self.logger.error(error_message)
            return self.create_error_response(error_message, request)

    async def is_available(self) -> bool:
        return self.token is not None

    async def get_status(self) -> Dict[str, Any]:
        return {
            "provider": "github_copilot",
            "status": "ready" if self.token else "unconfigured",
            "authenticated": bool(self.token)
        }

