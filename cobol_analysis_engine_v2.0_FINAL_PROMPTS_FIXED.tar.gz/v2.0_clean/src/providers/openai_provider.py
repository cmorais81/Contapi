'''
Provedor OpenAI para Sistema de Análise COBOL.
Integração com OpenAI GPT para análise de código COBOL.
'''

import os
import logging
from typing import Dict, Any

try:
    from openai import AsyncOpenAI
    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False

from .base_provider import BaseProvider, AIRequest, AIResponse

class OpenAIProvider(BaseProvider):
    '''
    Provedor OpenAI com integração completa para GPT.
    '''
    
    def __init__(self, config: Dict[str, Any]):
        '''
        Inicializa o provedor OpenAI.
        '''
        super().__init__(config)
        
        if not OPENAI_AVAILABLE:
            raise Exception("Biblioteca 'openai' não está instalada. Execute: pip install openai")
        
        self.api_key = os.getenv('OPENAI_API_KEY')
        self.model_name = config.get('model', 'gpt-4')
        self.temperature = config.get('temperature', 0.1)
        self.max_tokens = config.get('max_tokens', 4000)
        self.timeout = config.get('timeout', 60)
        
        if not self.api_key:
            raise Exception("API key do OpenAI não configurada.")
        
        self.client = AsyncOpenAI(
            api_key=self.api_key,
        )
        
        self.logger.info(f"OpenAI Provider inicializado - Modelo: {self.model_name}")
    
    async def is_available(self) -> bool:
        '''
        Verifica se o provedor está disponível.
        '''
        return self.enabled and self.api_key is not None
    
    async def analyze(self, request: AIRequest) -> AIResponse:
        '''
        Realiza análise usando OpenAI.
        '''
        try:
            messages = [
                {"role": "system", "content": "Você é um especialista em análise de código COBOL."},
                {"role": "user", "content": request.prompt}
            ]
            
            response = await self.client.chat.completions.create(
                model=self.model_name,
                messages=messages,
                temperature=self.temperature,
                max_tokens=self.max_tokens,
                timeout=self.timeout
            )
            
            content = response.choices[0].message.content
            tokens_used = response.usage.total_tokens
            
            return AIResponse(
                content=content,
                tokens_used=tokens_used,
                provider="openai",
                model=self.model_name,
                success=True,
            )
            
        except Exception as e:
            self.logger.error(f"Erro na análise OpenAI: {str(e)}")
            return AIResponse(
                content=f"Erro na análise OpenAI: {str(e)}",
                tokens_used=0,
                provider="openai",
                model=self.model_name,
                success=False,
                error_message=str(e)
            )
    
    async def get_status(self) -> Dict[str, Any]:
        '''
        Retorna status detalhado do provedor.
        '''
        return {
            'provider': 'OpenAI',
            'available': await self.is_available(),
            'model': self.model_name,
        }

