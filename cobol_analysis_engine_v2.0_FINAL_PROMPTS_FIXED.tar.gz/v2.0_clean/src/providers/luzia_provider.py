"""
LuziaProvider - Baseado no exemplo funcional teste.py
"""

import os
import requests
import time
import logging
import asyncio
from typing import Dict, Any, Optional
from .base_provider import BaseProvider, AIRequest, AIResponse

class LuziaProvider(BaseProvider):
    """Provider para LuzIA baseado no exemplo funcional"""

    def __init__(self, config):
        # Configuração simples baseada no exemplo funcional
        self.client_id = os.getenv("LUZIA_CLIENT_ID", "VISITOR-CHAT-FLOW-SALE-7d7e6f1156")
        self.client_secret = os.getenv("LUZIA_CLIENT_SECRET")
        
        # URLs conforme exemplo funcional
        self.auth_url = "https://luzia.com.br/api/v1/auth/token"
        self.api_url = "https://luzia.com.br/api/v1/chat/send"
        
        self.logger = logging.getLogger("LuziaProvider")
        self.last_error = None

    def get_token(self):
        """Obter token conforme exemplo funcional"""
        try:
            response = requests.post(
                self.auth_url,
                json={
                    "grant_type": "client_credentials",
                    "client_id": self.client_id,
                    "client_secret": self.client_secret
                }
            )
            if response.status_code == 200:
                return response.json().get("access_token")
            else:
                self.last_error = f"Erro de autenticação: {response.status_code}"
                return None
        except Exception as e:
            self.last_error = str(e)
            self.logger.error(f"Erro ao obter token: {e}")
            return None

    def send_message(self, message, conversation_id=None):
        """Enviar mensagem conforme exemplo funcional"""
        token = self.get_token()
        if not token:
            return None
            
        try:
            response = requests.post(
                self.api_url,
                headers={"Authorization": f"Bearer {token}"},
                json={
                    "prompt_type": "application/json-for-structured",
                    "client_id": self.client_id,
                    "text_server": message
                }
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                self.last_error = f"Erro na API: {response.status_code}"
                return None
                
        except Exception as e:
            self.last_error = str(e)
            self.logger.error(f"Erro ao enviar mensagem: {e}")
            return None

    def analyze(self, request: AIRequest) -> AIResponse:
        """Análise usando LuzIA conforme exemplo funcional"""
        start_time = time.time()
        
        try:
            # Enviar mensagem para LuzIA
            response_data = self.send_message(request.prompt)
            execution_time = time.time() - start_time
            
            if response_data:
                # Extrair conteúdo da resposta
                content = response_data.get('output', response_data.get('content', str(response_data)))
                
                return AIResponse(
                    success=True,
                    content=content,
                    provider="luzia",
                    model="luzia-chat",
                    tokens_used=0,
                    execution_time=execution_time
                )
            else:
                return AIResponse(
                    success=False,
                    content=f"Erro na chamada LuzIA: {self.last_error}",
                    provider="luzia",
                    model="luzia-chat",
                    tokens_used=0,
                    error_message=self.last_error,
                    execution_time=execution_time
                )
                
        except Exception as e:
            execution_time = time.time() - start_time
            error_msg = str(e)
            
            return AIResponse(
                success=False,
                content=f"Erro na análise: {error_msg}",
                provider="luzia",
                model="luzia-chat",
                tokens_used=0,
                error_message=error_msg,
                execution_time=execution_time
            )

    async def analyze_async(self, prompt: str) -> AIResponse:
        """Método assíncrono para análise"""
        # Executar o método síncrono em thread separada para não bloquear
        loop = asyncio.get_event_loop()
        request = AIRequest(prompt=prompt)
        
        try:
            # Executar em executor para não bloquear o loop
            response = await loop.run_in_executor(None, self.analyze, request)
            return response
        except Exception as e:
            return AIResponse(
                success=False,
                content=f"Erro na análise assíncrona: {str(e)}",
                provider="luzia",
                model="luzia-chat",
                tokens_used=0,
                error_message=str(e),
                execution_time=0
            )

    async def is_available(self) -> bool:
        """Verificar se LuzIA está disponível"""
        token = self.get_token()
        return token is not None

    async def get_status(self) -> Dict[str, Any]:
        """Status do provider LuzIA"""
        token = self.get_token()
        return {
            "provider": "luzia",
            "available": token is not None,
            "authenticated": token is not None,
            "model": "luzia-chat",
            "endpoint": self.api_url,
            "auth_endpoint": self.auth_url,
            "status": "ready" if token else "auth_failed",
            "last_error": self.last_error
        }
