"""
Enhanced Multi-AI Orchestrator com Sistema de Prompts Contextualizados
Integra o sistema de prompts LuzIA com informações de contexto
"""

import asyncio
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
from datetime import datetime

from core.multi_ai_orchestrator import MultiAIOrchestrator
from src.providers.provider_manager import ProviderManager
from prompts.luzia_prompts import LuziaPromptGenerator, PromptResponseLogger

@dataclass
class AnalysisContext:
    """Contexto enriquecido para análise"""
    program_name: str
    position_in_batch: Optional[int] = None
    total_programs: Optional[int] = None
    file_size: Optional[int] = None
    system_context: Optional[str] = None
    related_programs: Optional[List[str]] = None
    copybooks: Optional[Dict[str, str]] = None

class EnhancedMultiAIOrchestrator(MultiAIOrchestrator):
    """Orquestrador aprimorado com prompts contextualizados"""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.provider_manager = ProviderManager(config)
        self.providers = self.provider_manager.providers
        self.prompt_generator = LuziaPromptGenerator()
        self.prompt_logger = PromptResponseLogger()
        self.logger = logging.getLogger(__name__)
    
    async def analyze_program_with_context(self,
                                         cobol_code: str,
                                         context: AnalysisContext,
                                         extracted_data: Dict) -> Dict:
        """Análise de programa com contexto enriquecido"""
        
        self.logger.info(f"Iniciando análise contextualizada para {context.program_name}")
        
        # Gerar contexto do programa
        program_context = self._build_program_context(context)
        
        # Executar análise padrão
        standard_result = await self.analyze_program(
            cobol_code=cobol_code,
            copybooks=context.copybooks or {},
            program_name=context.program_name,
            extracted_data=extracted_data
        )
        
        # Executar análises contextualizadas adicionais
        contextual_analyses = await self._run_contextual_analyses(
            cobol_code, context, program_context
        )
        
        # Combinar resultados
        enhanced_result = self._combine_results(standard_result, contextual_analyses)
        
        return enhanced_result
    
    def _build_program_context(self, context: AnalysisContext) -> Dict:
        """Constrói contexto do programa para os prompts"""
        
        program_context = {
            'program_name': context.program_name
        }
        
        if context.position_in_batch and context.total_programs:
            program_context['position_in_batch'] = f"{context.position_in_batch}/{context.total_programs}"
        
        if context.file_size:
            program_context['file_size'] = context.file_size
        
        if context.system_context:
            program_context['system_context'] = context.system_context
        
        program_context['creation_date'] = datetime.now().strftime("%Y-%m-%d")
        
        return program_context
    
    async def _run_contextual_analyses(self,
                                     cobol_code: str,
                                     context: AnalysisContext,
                                     program_context: Dict) -> Dict:
        """Executa análises contextualizadas com prompts enriquecidos"""
        
        contextual_results = {}
        
        # Análise funcional enriquecida
        if self._should_run_enhanced_analysis():
            enhanced_prompt = self.prompt_generator.generate_enhanced_prompt(
                program_name=context.program_name,
                cobol_code=cobol_code,
                program_context=program_context,
                copybooks=context.copybooks,
                related_programs=context.related_programs
            )
            
            enhanced_response = await self._execute_enhanced_analysis(enhanced_prompt)
            
            # Registrar prompt e resposta
            self.prompt_logger.log_prompt_response(
                provider="enhanced_analysis",
                prompt_type="functional_analysis",
                prompt=enhanced_prompt,
                response=enhanced_response,
                program_name=context.program_name
            )
            
            contextual_results['enhanced_functional'] = enhanced_response
        
        # Análise de regras de negócio específica
        business_rules_prompt = self.prompt_generator.generate_business_rules_prompt(
            program_name=context.program_name,
            cobol_code=cobol_code
        )
        
        business_rules_response = await self._execute_business_rules_analysis(business_rules_prompt)
        
        # Registrar prompt e resposta
        self.prompt_logger.log_prompt_response(
            provider="business_rules_analysis",
            prompt_type="business_rules_extraction",
            prompt=business_rules_prompt,
            response=business_rules_response,
            program_name=context.program_name
        )
        
        contextual_results['business_rules'] = business_rules_response
        
        return contextual_results
    
    async def _execute_enhanced_analysis(self, prompt: str) -> str:
        """Executa análise funcional enriquecida"""
        
        # Usar o provedor OpenAI para análise enriquecida
        if 'openai' in self.providers and self.providers['openai'].enabled:
            try:
                response = await self.providers['openai'].analyze_async(
                    cobol_code="",  # O código já está no prompt
                    analysis_type="enhanced_functional",
                    custom_prompt=prompt
                )
                return response.analysis if hasattr(response, 'analysis') else str(response)
            except Exception as e:
                self.logger.error(f"Erro na análise enriquecida: {e}")
                return f"Erro na análise enriquecida: {str(e)}"
        
        return "Análise enriquecida não disponível (OpenAI não configurado)"
    
    async def _execute_business_rules_analysis(self, prompt: str) -> str:
        """Executa análise específica de regras de negócio"""
        
        # Usar o provedor OpenAI para análise de regras
        if 'openai' in self.providers and self.providers['openai'].enabled:
            try:
                response = await self.providers['openai'].analyze_async(
                    cobol_code="",  # O código já está no prompt
                    analysis_type="business_rules",
                    custom_prompt=prompt
                )
                return response.analysis if hasattr(response, 'analysis') else str(response)
            except Exception as e:
                self.logger.error(f"Erro na análise de regras de negócio: {e}")
                return f"Erro na análise de regras de negócio: {str(e)}"
        
        return "Análise de regras de negócio não disponível (OpenAI não configurado)"
    
    def _should_run_enhanced_analysis(self) -> bool:
        """Determina se deve executar análise enriquecida"""
        
        # Executar análise enriquecida se OpenAI estiver disponível
        return ('openai' in self.providers and 
                self.providers['openai'].enabled)
    
    def _combine_results(self, standard_result: Dict, contextual_analyses: Dict) -> Dict:
        """Combina resultados padrão com análises contextualizadas"""
        
        enhanced_result = standard_result.copy()
        
        # Adicionar análises contextualizadas
        if 'contextual_analyses' not in enhanced_result:
            enhanced_result['contextual_analyses'] = {}
        
        enhanced_result['contextual_analyses'].update(contextual_analyses)
        
        # Adicionar informações de prompts
        enhanced_result['prompt_history'] = self.prompt_logger.prompt_history
        
        return enhanced_result
    
    def get_prompt_logger(self) -> PromptResponseLogger:
        """Retorna o logger de prompts para uso externo"""
        return self.prompt_logger

class ContextExtractor:
    """Extrator de contexto para programas COBOL"""
    
    @staticmethod
    def extract_from_fontes_batch(programs: List[Dict], 
                                copybooks: Optional[Dict] = None) -> List[AnalysisContext]:
        """Extrai contexto de um lote de programas do fontes.txt"""
        
        contexts = []
        total_programs = len(programs)
        
        # Extrair nomes de programas relacionados
        related_programs = [prog['name'] for prog in programs]
        
        for i, program in enumerate(programs, 1):
            context = AnalysisContext(
                program_name=program['name'],
                position_in_batch=i,
                total_programs=total_programs,
                file_size=len(program['content'].split('\n')),
                system_context=ContextExtractor._identify_system_context(program['name']),
                related_programs=[name for name in related_programs if name != program['name']],
                copybooks=copybooks
            )
            contexts.append(context)
        
        return contexts
    
    @staticmethod
    def _identify_system_context(program_name: str) -> str:
        """Identifica contexto do sistema baseado no nome do programa"""
        
        # Padrões comuns de nomenclatura
        if program_name.startswith('LH'):
            return "Sistema de Liquidação e Custódia"
        elif program_name.startswith('MZ'):
            return "Sistema de Movimentação"
        elif program_name.startswith('BR'):
            return "Sistema de Relatórios Brasil"
        elif program_name.startswith('DQ'):
            return "Sistema de Qualidade de Dados"
        else:
            return "Sistema Mainframe Genérico"
