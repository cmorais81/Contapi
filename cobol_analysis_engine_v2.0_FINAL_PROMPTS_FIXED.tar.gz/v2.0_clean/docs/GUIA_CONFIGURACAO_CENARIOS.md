# Guia de Configuração por Cenários - COBOL Analysis Engine v2.0

**Versão:** 2.0  
**Data:** Setembro 2025  

---

## Índice

1. [Configurações por Ambiente](#configurações-por-ambiente)
2. [Configurações por Tipo de Sistema](#configurações-por-tipo-de-sistema)
3. [Configurações por Objetivo](#configurações-por-objetivo)
4. [Configurações de Performance](#configurações-de-performance)
5. [Configurações de Segurança](#configurações-de-segurança)
6. [Templates de Configuração](#templates-de-configuração)

---

## Configurações por Ambiente

### Desenvolvimento Local

```yaml
# config/development.yaml
system:
  version: "2.0"
  log_level: "DEBUG"
  max_concurrent_analyses: 2
  timeout_seconds: 600

analysis:
  default_mode: "enhanced"
  enable_cross_validation: false
  enable_clarity_engine: false
  max_file_size_mb: 10

output:
  format: "markdown"
  include_prompts: true
  include_raw_responses: true
  generate_pdf: false

cache:
  enabled: true
  directory: "cache/"
  ttl_hours: 1
  max_size_mb: 100

logging:
  level: "DEBUG"
  file: "logs/dev_analysis.log"
  max_size_mb: 10
  backup_count: 3

ai:
  default_provider: "openai"
  specialized_ais:
    structural:
      provider: "openai"
      model: "gpt-3.5-turbo"
      temperature: 0.1
      max_tokens: 2000
```

**Comandos para desenvolvimento:**
```bash
# Análise rápida para testes
python main.py programa.cbl -c config/development.yaml -m traditional

# Análise completa com debug
python main.py programa.cbl -c config/development.yaml -m enhanced --verbose
```

### Teste/Homologação

```yaml
# config/testing.yaml
system:
  version: "2.0"
  log_level: "INFO"
  max_concurrent_analyses: 4
  timeout_seconds: 300

analysis:
  default_mode: "multi_ai"
  enable_cross_validation: true
  enable_clarity_engine: true
  max_file_size_mb: 25

output:
  format: "markdown"
  include_prompts: false
  include_raw_responses: false
  generate_pdf: true

cache:
  enabled: true
  directory: "/tmp/cobol_cache"
  ttl_hours: 12
  max_size_mb: 500

logging:
  level: "INFO"
  file: "/var/log/cobol_analysis/testing.log"
  max_size_mb: 50
  backup_count: 5

ai:
  default_provider: "openai"
  specialized_ais:
    structural:
      provider: "openai"
      model: "gpt-4-turbo"
      temperature: 0.1
      max_tokens: 3000
```

**Comandos para teste:**
```bash
# Teste de lote com validação
python main.py fontes.txt -c config/testing.yaml -b BOOKS.txt -m multi_ai

# Teste de performance
time python main.py fontes.txt -c config/testing.yaml --max-workers 4
```

### Produção

```yaml
# config/production.yaml
system:
  version: "2.0"
  log_level: "WARNING"
  max_concurrent_analyses: 8
  timeout_seconds: 180

analysis:
  default_mode: "enhanced"
  enable_cross_validation: true
  enable_clarity_engine: true
  max_file_size_mb: 50

output:
  format: "markdown"
  include_prompts: false
  include_raw_responses: false
  generate_pdf: true

cache:
  enabled: true
  directory: "/opt/cobol_analysis/cache"
  ttl_hours: 24
  max_size_mb: 2000

logging:
  level: "WARNING"
  file: "/var/log/cobol_analysis/production.log"
  max_size_mb: 100
  backup_count: 10

ai:
  default_provider: "openai"
  specialized_ais:
    structural:
      provider: "openai"
      model: "gpt-4-turbo"
      temperature: 0.05
      max_tokens: 4000
    business:
      provider: "openai"
      model: "gpt-4-turbo"
      temperature: 0.1
      max_tokens: 4000

# Configurações de monitoramento
monitoring:
  enabled: true
  metrics_endpoint: "http://prometheus:9090"
  alert_webhook: "https://alerts.empresa.com/webhook"
```

**Comandos para produção:**
```bash
# Processamento em lote otimizado
python main.py fontes.txt -c config/production.yaml -b BOOKS.txt \
  --max-workers 8 --quiet --output /dados/analises/

# Monitoramento de saúde
python main.py --health-check -c config/production.yaml
```

---

## Configurações por Tipo de Sistema

### Sistema Bancário

```yaml
# config/banking.yaml
system:
  version: "2.0"
  log_level: "INFO"
  max_concurrent_analyses: 6
  timeout_seconds: 300

analysis:
  default_mode: "enhanced"
  enable_cross_validation: true
  enable_clarity_engine: true
  max_file_size_mb: 100
  
  # Configurações específicas para bancos
  focus_areas:
    - "compliance_bancario"
    - "validacoes_financeiras"
    - "controles_auditoria"
    - "processamento_transacoes"

output:
  format: "markdown"
  include_prompts: true
  include_raw_responses: true
  generate_pdf: true
  
  # Templates específicos para bancos
  template: "banking_template"

ai:
  default_provider: "openai"
  specialized_ais:
    structural:
      provider: "openai"
      model: "gpt-4-turbo"
      temperature: 0.05
      max_tokens: 4000
      system_prompt: |
        Você é um especialista em sistemas bancários COBOL.
        Foque em aspectos de compliance, segurança e auditoria.
    
    business:
      provider: "openai"
      model: "gpt-4-turbo"
      temperature: 0.1
      max_tokens: 4000
      system_prompt: |
        Analise regras de negócio bancário, validações financeiras
        e controles regulatórios. Identifique riscos operacionais.

# Configurações de compliance
compliance:
  enabled: true
  standards:
    - "BACEN"
    - "SOX"
    - "BASEL_III"
  
  validation_rules:
    - "monetary_precision"
    - "audit_trails"
    - "data_encryption"
```

**Comandos para sistemas bancários:**
```bash
# Análise com foco em compliance
python main.py sistema_bancario/ -c config/banking.yaml \
  --filter-programs "LH*,BR*" --include-compliance-report

# Auditoria completa
python main.py fontes.txt -c config/banking.yaml \
  --audit-mode --generate-compliance-report
```

### Sistema de Seguros

```yaml
# config/insurance.yaml
system:
  version: "2.0"
  log_level: "INFO"

analysis:
  focus_areas:
    - "calculos_atuariais"
    - "processamento_sinistros"
    - "validacoes_susep"
    - "gestao_riscos"

ai:
  specialized_ais:
    business:
      system_prompt: |
        Especialista em sistemas de seguros COBOL.
        Foque em cálculos atuariais, processamento de sinistros
        e conformidade com regulamentações SUSEP.

compliance:
  standards:
    - "SUSEP"
    - "CNSP"
    - "LGPD"
```

### Sistema de Telecomunicações

```yaml
# config/telecom.yaml
analysis:
  focus_areas:
    - "processamento_cdr"
    - "tarifacao"
    - "billing"
    - "performance_rede"

ai:
  specialized_ais:
    technical:
      system_prompt: |
        Especialista em sistemas de telecomunicações COBOL.
        Foque em processamento de CDR, tarifação e billing.
```

---

## Configurações por Objetivo

### Migração de Sistema

```yaml
# config/migration.yaml
system:
  version: "2.0"
  log_level: "INFO"

analysis:
  default_mode: "enhanced"
  enable_cross_validation: true
  
  # Configurações específicas para migração
  migration_focus:
    - "dependencies_mapping"
    - "data_flow_analysis"
    - "business_rules_extraction"
    - "modernization_opportunities"

output:
  format: "markdown"
  include_prompts: true
  generate_pdf: true
  
  # Templates específicos para migração
  template: "migration_template"
  
  # Relatórios adicionais
  additional_reports:
    - "dependency_matrix"
    - "complexity_assessment"
    - "modernization_roadmap"

ai:
  specialized_ais:
    migration_analyzer:
      provider: "openai"
      model: "gpt-4-turbo"
      temperature: 0.1
      system_prompt: |
        Você é um especialista em migração de sistemas COBOL.
        Analise o código focando em:
        1. Dependências entre programas
        2. Complexidade de migração
        3. Oportunidades de modernização
        4. Riscos de migração
        5. Estratégias de refatoração

# Configurações de migração
migration:
  enabled: true
  target_platform: "java_spring"
  assessment_criteria:
    - "complexity_score"
    - "dependency_count"
    - "business_criticality"
    - "modernization_effort"
```

**Comandos para migração:**
```bash
# Análise completa para migração
python main.py sistema_legado/ -c config/migration.yaml \
  --generate-migration-report --include-dependency-matrix

# Avaliação de complexidade
python main.py fontes.txt -c config/migration.yaml \
  --complexity-assessment --modernization-roadmap
```

### Auditoria de Código

```yaml
# config/audit.yaml
analysis:
  default_mode: "enhanced"
  
  audit_focus:
    - "code_quality"
    - "security_vulnerabilities"
    - "performance_issues"
    - "compliance_violations"
    - "best_practices"

ai:
  specialized_ais:
    security_analyzer:
      provider: "openai"
      model: "gpt-4-turbo"
      system_prompt: |
        Você é um auditor de segurança especializado em COBOL.
        Identifique vulnerabilidades, violações de compliance
        e oportunidades de melhoria de segurança.
    
    quality_analyzer:
      provider: "openai"
      model: "gpt-4-turbo"
      system_prompt: |
        Analise a qualidade do código COBOL focando em:
        - Manutenibilidade
        - Legibilidade
        - Aderência a padrões
        - Complexidade ciclomática

audit:
  enabled: true
  standards:
    - "ISO_27001"
    - "COBIT"
    - "ITIL"
  
  quality_metrics:
    - "cyclomatic_complexity"
    - "maintainability_index"
    - "code_coverage"
    - "technical_debt"
```

### Documentação Técnica

```yaml
# config/documentation.yaml
analysis:
  default_mode: "enhanced"
  
  documentation_focus:
    - "api_documentation"
    - "business_rules"
    - "data_dictionary"
    - "process_flows"

output:
  format: "markdown"
  template: "technical_documentation"
  
  additional_outputs:
    - "api_specs"
    - "data_dictionary"
    - "process_diagrams"
    - "user_manual"

ai:
  specialized_ais:
    documentation_generator:
      provider: "openai"
      model: "gpt-4-turbo"
      system_prompt: |
        Gere documentação técnica clara e abrangente.
        Inclua diagramas, exemplos e explicações detalhadas.
```

---

## Configurações de Performance

### Alta Performance

```yaml
# config/high_performance.yaml
system:
  max_concurrent_analyses: 16
  timeout_seconds: 120

analysis:
  default_mode: "multi_ai"
  enable_cross_validation: false
  enable_clarity_engine: false

cache:
  enabled: true
  directory: "/dev/shm/cobol_cache"  # RAM disk
  ttl_hours: 48
  max_size_mb: 4000

ai:
  specialized_ais:
    structural:
      model: "gpt-3.5-turbo"  # Modelo mais rápido
      max_tokens: 2000
      timeout: 30

# Configurações de paralelização
parallel:
  enabled: true
  max_workers: 16
  batch_size: 10
  queue_size: 100
```

**Comandos para alta performance:**
```bash
# Processamento paralelo máximo
python main.py fontes.txt -c config/high_performance.yaml \
  --max-workers 16 --batch-size 10 --no-validation

# Análise rápida em lote
python main.py fontes.txt -c config/high_performance.yaml \
  -m traditional --no-cache --quiet
```

### Baixo Consumo de Recursos

```yaml
# config/low_resource.yaml
system:
  max_concurrent_analyses: 1
  timeout_seconds: 600

analysis:
  default_mode: "traditional"
  max_file_size_mb: 5

cache:
  enabled: false

ai:
  specialized_ais:
    structural:
      model: "gpt-3.5-turbo"
      max_tokens: 1000
      temperature: 0.1

# Configurações de memória
memory:
  max_memory_mb: 512
  gc_threshold: 100
  streaming_mode: true
```

---

## Configurações de Segurança

### Ambiente Seguro

```yaml
# config/secure.yaml
system:
  log_level: "ERROR"  # Logs mínimos

security:
  enabled: true
  
  # Criptografia
  encryption:
    enabled: true
    algorithm: "AES-256"
    key_rotation: true
  
  # Controle de acesso
  access_control:
    enabled: true
    require_authentication: true
    role_based: true
  
  # Auditoria
  audit:
    enabled: true
    log_all_operations: true
    sensitive_data_masking: true

# Configurações de rede
network:
  proxy:
    enabled: true
    url: "https://proxy.empresa.com:8080"
    authentication: true
  
  ssl:
    verify_certificates: true
    min_tls_version: "1.2"

# Configurações de dados
data:
  anonymization:
    enabled: true
    mask_sensitive_fields: true
  
  retention:
    max_days: 90
    auto_cleanup: true
```

### Compliance LGPD

```yaml
# config/lgpd.yaml
compliance:
  lgpd:
    enabled: true
    
    data_protection:
      anonymization: true
      pseudonymization: true
      encryption_at_rest: true
      encryption_in_transit: true
    
    audit:
      data_access_logging: true
      consent_tracking: true
      breach_detection: true
    
    rights:
      data_portability: true
      right_to_erasure: true
      right_to_rectification: true

data:
  classification:
    enabled: true
    levels:
      - "public"
      - "internal"
      - "confidential"
      - "restricted"
  
  handling:
    sensitive_data_detection: true
    automatic_classification: true
    retention_policies: true
```

---

## Templates de Configuração

### Template Base

```yaml
# config/template_base.yaml
system:
  version: "2.0"
  log_level: "INFO"
  max_concurrent_analyses: 4
  timeout_seconds: 300

analysis:
  default_mode: "enhanced"
  enable_cross_validation: true
  enable_clarity_engine: true
  max_file_size_mb: 50

output:
  format: "markdown"
  include_prompts: false
  include_raw_responses: false
  generate_pdf: false

cache:
  enabled: true
  directory: "cache/"
  ttl_hours: 24
  max_size_mb: 1000

logging:
  level: "INFO"
  file: "logs/cobol_analysis.log"
  max_size_mb: 100
  backup_count: 5

ai:
  default_provider: "openai"
  specialized_ais:
    structural:
      provider: "openai"
      model: "gpt-4-turbo"
      temperature: 0.1
      max_tokens: 4000
```

### Template para CI/CD

```yaml
# config/cicd.yaml
system:
  log_level: "WARNING"
  max_concurrent_analyses: 8
  timeout_seconds: 180

analysis:
  default_mode: "multi_ai"
  enable_cross_validation: false
  max_file_size_mb: 25

output:
  format: "json"
  include_prompts: false
  include_raw_responses: false

cache:
  enabled: true
  directory: "/tmp/ci_cache"
  ttl_hours: 1

logging:
  level: "WARNING"
  file: "/tmp/ci_analysis.log"

# Configurações específicas para CI/CD
ci:
  enabled: true
  fail_on_error: true
  quality_gates:
    min_quality_score: 80
    max_complexity: 10
    max_technical_debt: 5
  
  reports:
    junit_xml: true
    sonarqube: true
    coverage: true
```

**Comandos para CI/CD:**
```bash
# Pipeline de análise
python main.py fontes.txt -c config/cicd.yaml \
  --output reports/ --format json --fail-on-error

# Verificação de qualidade
python main.py programa.cbl -c config/cicd.yaml \
  --quality-gate --min-score 80
```

### Template para Desenvolvimento

```yaml
# config/dev_template.yaml
system:
  log_level: "DEBUG"
  max_concurrent_analyses: 2
  timeout_seconds: 600

analysis:
  default_mode: "enhanced"
  enable_cross_validation: false
  max_file_size_mb: 10

output:
  format: "markdown"
  include_prompts: true
  include_raw_responses: true

cache:
  enabled: true
  ttl_hours: 1

logging:
  level: "DEBUG"
  file: "dev_analysis.log"

# Configurações de desenvolvimento
development:
  hot_reload: true
  auto_analysis: true
  interactive_mode: true
  
  debugging:
    enabled: true
    breakpoints: true
    step_by_step: true
```

---

## Uso dos Templates

### Copiar e Personalizar

```bash
# Copiar template base
cp config/template_base.yaml config/minha_config.yaml

# Editar conforme necessário
nano config/minha_config.yaml

# Usar configuração personalizada
python main.py programa.cbl -c config/minha_config.yaml
```

### Herança de Configurações

```yaml
# config/minha_config.yaml
# Herdar de template base
extends: "template_base.yaml"

# Sobrescrever apenas o necessário
system:
  log_level: "DEBUG"

analysis:
  default_mode: "traditional"

# Adicionar configurações específicas
custom:
  empresa: "Minha Empresa"
  projeto: "Modernização COBOL"
```

### Configuração por Variáveis de Ambiente

```yaml
# config/env_config.yaml
system:
  log_level: "${COBOL_LOG_LEVEL:-INFO}"
  max_concurrent_analyses: "${COBOL_MAX_WORKERS:-4}"

ai:
  openai:
    api_key: "${OPENAI_API_KEY}"
    model: "${OPENAI_MODEL:-gpt-4-turbo}"

cache:
  directory: "${COBOL_CACHE_DIR:-cache/}"
```

```bash
# Configurar via variáveis de ambiente
export COBOL_LOG_LEVEL="DEBUG"
export COBOL_MAX_WORKERS="8"
export OPENAI_API_KEY="sk-..."

# Usar configuração
python main.py programa.cbl -c config/env_config.yaml
```

---

## Conclusão

Este guia fornece configurações otimizadas para diferentes cenários de uso do COBOL Analysis Engine v2.0. Escolha o template mais adequado ao seu caso e personalize conforme necessário.

### Recomendações Gerais

1. **Desenvolvimento**: Use `config/development.yaml` com logs detalhados
2. **Teste**: Use `config/testing.yaml` com validação cruzada
3. **Produção**: Use `config/production.yaml` otimizado para performance
4. **Migração**: Use `config/migration.yaml` com foco em dependências
5. **Auditoria**: Use `config/audit.yaml` com análise de segurança

### Próximos Passos

1. Escolha o template adequado ao seu cenário
2. Personalize as configurações conforme necessário
3. Teste em ambiente de desenvolvimento
4. Valide em ambiente de teste
5. Implante em produção com monitoramento

Para suporte adicional, consulte o manual completo ou a documentação técnica.

---

**Versão:** 2.0  
**Última Atualização:** Setembro 2025  
**Compatibilidade:** COBOL Analysis Engine v2.0+
