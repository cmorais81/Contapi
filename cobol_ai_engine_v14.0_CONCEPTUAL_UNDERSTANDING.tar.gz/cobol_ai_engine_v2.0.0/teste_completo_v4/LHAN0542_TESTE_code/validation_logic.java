// Validation Logic
public class RecordValidator {

    public static class ValidationResult {
        private boolean valid;
        private String errorMessage;

        public ValidationResult(boolean valid, String errorMessage) {
            this.valid = valid;
            this.errorMessage = errorMessage;
        }

        public boolean isValid() { return valid; }
        public String getErrorMessage() { return errorMessage; }
    }

    public static ValidationResult validateRecord(Object record) {
        List<String> errors = new ArrayList<>();

        // Validate WS-TIPO-REGISTRO
        if (errors.isEmpty()) {
            return new ValidationResult(true, null);
        } else {
            return new ValidationResult(false, String.join("; ", errors));
        }
    }

    private static boolean isNumeric(String value) {
        if (value == null || value.trim().isEmpty()) return false;
        try {
            Double.parseDouble(value.trim());
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    private static boolean isSpaces(String value) {
        return value == null || value.trim().isEmpty();
    }

    private static boolean isZero(String value) {
        return "0".equals(value) || "0.0".equals(value) || "0.00".equals(value);
    }

}

