# Relatório Consolidado Aprimorado - Análise COBOL

**Data de Geração:** 17/09/2025 14:15:04  
**Versão do Sistema:** COBOL AI Engine v2.2.0 Enhanced  
**Tipo de Análise:** Análise Descritiva Aprofundada

## Resumo Executivo da Análise Aprimorada

### Estatísticas Gerais
- **Total de Programas Analisados:** 5
- **Análises Bem-sucedidas:** 0
- **Análises com Falha:** 5
- **Taxa de Sucesso:** 0.0%
- **Total de Tokens Utilizados:** 0
- **Tempo de Processamento:** 0.00 segundos

### Funcionalidades Aprimoradas Utilizadas
- **Análise Detalhada:** True
- **Contexto de Negócio:** True
- **Profundidade Técnica:** maximum

## Detalhamento por Programa

