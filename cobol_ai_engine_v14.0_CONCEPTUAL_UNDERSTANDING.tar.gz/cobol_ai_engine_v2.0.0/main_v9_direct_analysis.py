import os
import logging
import argparse
from datetime import datetime
from typing import Dict, Any, List

# Importar os componentes necessários
from src.parsers.multi_program_cobol_parser import MultiProgramCobolParser
from src.parsers.final_record_layout_parser import FinalRecordLayoutParser
from src.parsers.final_cobol_structure_analyzer import FinalCOBOLStructureAnalyzer
from src.analyzers.direct_code_analyzer import DirectCodeAnalyzer
from src.generators.advanced_documentation_generator import AdvancedDocumentationGenerator

class COBOLAIEngineV9:
    """
    COBOL AI Engine v9.0 - Análise Direta Completa
    
    Realiza análise completa e detalhada do código COBOL sem dependência de LLM,
    garantindo resultados consistentes e precisos para reimplementação.
    """

    def __init__(self, programs_dir: str, books_dir: str, output_dir: str):
        self.logger = logging.getLogger(__name__)
        self.programs_dir = programs_dir
        self.output_dir = output_dir

        if not os.path.exists(self.output_dir):
            os.makedirs(self.output_dir)

        # Inicializar componentes
        self.multi_parser = MultiProgramCobolParser(books_dir)
        self.layout_parser = FinalRecordLayoutParser()
        self.structure_analyzer = FinalCOBOLStructureAnalyzer()
        self.direct_analyzer = DirectCodeAnalyzer()
        self.doc_generator = AdvancedDocumentationGenerator()

        self.logger.info("COBOL AI Engine v9.0 - Análise Direta Completa inicializado")

    def analyze_program(self, program_path: str, program_name: str) -> Dict[str, Any]:
        """Realiza análise completa de um programa individual."""
        self.logger.info(f"=== Iniciando análise direta completa: {program_name} ===")

        try:
            # 1. Parse do programa e resolução de COPYs
            self.logger.info("Fase 1: Parsing e resolução de copybooks")
            resolved_code_lines = self.multi_parser.parse(program_path)
            resolved_code_str = "".join(resolved_code_lines)

            # 2. Análise Estrutural
            self.logger.info("Fase 2: Análise estrutural")
            structural_analysis = self.structure_analyzer.analyze(resolved_code_lines)

            # 3. Análise de Layout de Registro
            self.logger.info("Fase 3: Análise de layouts de registro")
            record_layouts = self.layout_parser.parse(resolved_code_lines)

            # 4. Análise Direta Completa (sem LLM)
            self.logger.info("Fase 4: Análise direta completa do código")
            direct_analysis = self.direct_analyzer.analyze(program_name, resolved_code_str)

            # 5. Montar resultados completos
            analysis_results = {
                "program_name": program_name,
                "resolved_code": resolved_code_str,
                "structural_analysis": structural_analysis,
                "record_layouts": record_layouts,
                "functional_analysis": direct_analysis,
                "analysis_timestamp": datetime.now().isoformat(),
                "engine_version": "9.0"
            }

            self.logger.info(f"Análise de {program_name} concluída com sucesso")
            return analysis_results

        except Exception as e:
            self.logger.error(f"Erro na análise do programa {program_name}: {e}", exc_info=True)
            return {
                "program_name": program_name,
                "error": str(e),
                "analysis_timestamp": datetime.now().isoformat(),
                "engine_version": "9.0"
            }

    def generate_documentation(self, analysis_results: Dict[str, Any], target_language: str = "java") -> str:
        """Gera documentação avançada baseada na análise direta."""
        program_name = analysis_results.get("program_name", "UNKNOWN")
        
        if "error" in analysis_results:
            return f"""# Erro na Análise: {program_name}

**Erro:** {analysis_results['error']}
**Data:** {analysis_results.get('analysis_timestamp', 'N/A')}
**Versão:** {analysis_results.get('engine_version', 'N/A')}

A análise deste programa falhou. Verifique o código-fonte e tente novamente.
"""

        return self.doc_generator.generate(analysis_results, target_language)

    def run_batch_analysis(self, target_language: str = "java"):
        """Executa análise em lote de todos os programas."""
        self.logger.info(f"Iniciando análise em lote - diretório: {self.programs_dir}")
        
        program_files = [f for f in os.listdir(self.programs_dir) if f.endswith(".cbl")]
        total_programs = len(program_files)
        
        self.logger.info(f"Encontrados {total_programs} programas para análise")

        results_summary = []

        for i, program_file in enumerate(program_files, 1):
            program_path = os.path.join(self.programs_dir, program_file)
            program_name = os.path.splitext(program_file)[0]
            
            self.logger.info(f"[{i}/{total_programs}] Processando: {program_name}")

            # Análise do programa
            analysis_results = self.analyze_program(program_path, program_name)
            
            # Geração de documentação
            documentation = self.generate_documentation(analysis_results, target_language)
            
            # Salvar documentação
            doc_file_path = os.path.join(self.output_dir, f"{program_name}_DOCS_v9.md")
            with open(doc_file_path, "w", encoding="utf-8") as f:
                f.write(documentation)
            
            # Salvar análise completa em JSON para debug
            import json
            json_file_path = os.path.join(self.output_dir, f"{program_name}_ANALYSIS_v9.json")
            with open(json_file_path, "w", encoding="utf-8") as f:
                json.dump(analysis_results, f, indent=2, ensure_ascii=False, default=str)

            success = "error" not in analysis_results
            results_summary.append({
                "program": program_name,
                "success": success,
                "doc_file": doc_file_path,
                "json_file": json_file_path
            })

            status = "✓ Sucesso" if success else "✗ Erro"
            self.logger.info(f"[{i}/{total_programs}] {program_name}: {status}")

        # Gerar relatório consolidado
        self._generate_consolidated_report(results_summary)
        
        self.logger.info("Análise em lote concluída")
        return results_summary

    def _generate_consolidated_report(self, results_summary: List[Dict]):
        """Gera um relatório consolidado de todos os programas analisados."""
        report_path = os.path.join(self.output_dir, "RELATORIO_CONSOLIDADO_v9.md")
        
        with open(report_path, "w", encoding="utf-8") as f:
            f.write("# Relatório Consolidado - COBOL AI Engine v9.0\n\n")
            f.write(f"**Data da Análise:** {datetime.now().strftime('%d/%m/%Y %H:%M')}\n")
            f.write(f"**Versão:** 9.0 - Análise Direta Completa\n")
            f.write(f"**Método:** Análise direta do código-fonte sem dependência de LLM\n\n")
            
            successful = sum(1 for r in results_summary if r["success"])
            total = len(results_summary)
            
            f.write(f"## Resumo da Execução\n\n")
            f.write(f"- **Total de Programas:** {total}\n")
            f.write(f"- **Analisados com Sucesso:** {successful}\n")
            f.write(f"- **Falhas:** {total - successful}\n")
            f.write(f"- **Taxa de Sucesso:** {(successful/total*100):.1f}%\n\n")
            
            f.write("## Melhorias da Versão 9.0\n\n")
            f.write("- **Análise Direta:** Extração de informações sem dependência de LLM\n")
            f.write("- **Detecção de Arquivos:** Identificação automática de arquivos de entrada e saída\n")
            f.write("- **Estruturas de Dados:** Mapeamento completo da WORKING-STORAGE\n")
            f.write("- **Lógica de Negócio:** Análise de parágrafos e fluxo de controle\n")
            f.write("- **Constantes:** Extração de valores e literais do programa\n")
            f.write("- **Performance:** Identificação de considerações de otimização\n\n")
            
            f.write("## Programas Analisados\n\n")
            f.write("| Programa | Status | Documentação | Análise JSON |\n")
            f.write("|---|---|---|---|\n")
            
            for result in results_summary:
                status = "✓ Sucesso" if result["success"] else "✗ Erro"
                doc_file = os.path.basename(result["doc_file"])
                json_file = os.path.basename(result["json_file"])
                f.write(f"| {result['program']} | {status} | [{doc_file}](./{doc_file}) | [{json_file}](./{json_file}) |\n")

        self.logger.info(f"Relatório consolidado salvo em: {report_path}")

if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO, 
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )

    parser = argparse.ArgumentParser(description="COBOL AI Engine v9.0 - Análise Direta Completa")
    parser.add_argument("--programs-dir", type=str, 
                       default="/home/ubuntu/cobol_ai_engine_v2.0.0/extracted_programs", 
                       help="Diretório com os programas COBOL extraídos")
    parser.add_argument("--books-dir", type=str, 
                       default="/home/ubuntu/cobol_ai_engine_v2.0.0/extracted_books", 
                       help="Diretório com os copybooks extraídos")
    parser.add_argument("--output-dir", type=str, 
                       default="/home/ubuntu/cobol_ai_engine_v2.0.0/direct_analysis_results_v9", 
                       help="Diretório para salvar os resultados")
    parser.add_argument("--target-language", type=str, default="java", 
                       choices=["java", "python"], 
                       help="Linguagem alvo para o guia de implementação")
    
    args = parser.parse_args()

    engine = COBOLAIEngineV9(args.programs_dir, args.books_dir, args.output_dir)
    results = engine.run_batch_analysis(args.target_language)
    
    print(f"\n=== Análise Concluída ===")
    print(f"Resultados salvos em: {args.output_dir}")
    print(f"Programas processados: {len(results)}")
    successful = sum(1 for r in results if r["success"])
    print(f"Taxa de sucesso: {(successful/len(results)*100):.1f}%")
    
    # Mostra estatísticas detalhadas
    print(f"\n=== Estatísticas Detalhadas ===")
    for result in results:
        status = "✓" if result["success"] else "✗"
        print(f"{status} {result['program']}")
