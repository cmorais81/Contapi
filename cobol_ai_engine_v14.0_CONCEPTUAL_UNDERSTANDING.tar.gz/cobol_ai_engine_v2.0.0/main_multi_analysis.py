import os
import logging
import argparse
from datetime import datetime

# Importar os parsers e analisadores necessários
from src.parsers.multi_program_cobol_parser import MultiProgramCobolParser
from src.parsers.final_record_layout_parser import FinalRecordLayoutParser
from src.parsers.final_cobol_structure_analyzer import FinalCOBOLStructureAnalyzer
from src.analyzers.semantic_analyzer import SemanticAnalyzer
from src.generators.improved_documentation_generator import ImprovedDocumentationGenerator
from src.providers.luzia_provider_aws import LuziaAWSProvider

class MultiProgramAnalysisEngine:
    def __init__(self, programs_dir: str, books_dir: str, output_dir: str):
        self.logger = logging.getLogger(__name__)
        self.programs_dir = programs_dir
        self.output_dir = output_dir

        if not os.path.exists(self.output_dir):
            os.makedirs(self.output_dir)

        # Inicializar componentes
        self.multi_parser = MultiProgramCobolParser(books_dir)
        self.layout_parser = FinalRecordLayoutParser()
        self.structure_analyzer = FinalCOBOLStructureAnalyzer()
        
        # Configurar o provedor e o analisador semântico
        luzia_config = {"model_id": "anthropic.claude-3-5-sonnet-20240620-v1:0"}
        self.llm_provider = LuziaAWSProvider(config=luzia_config)
        self.semantic_analyzer = SemanticAnalyzer(self.llm_provider)
        
        self.doc_generator = ImprovedDocumentationGenerator()

    def run_analysis(self):
        self.logger.info(f"Iniciando análise de múltiplos programas em: {self.programs_dir}")
        program_files = [f for f in os.listdir(self.programs_dir) if f.endswith(".cbl")]

        for program_file in program_files:
            program_path = os.path.join(self.programs_dir, program_file)
            program_name = os.path.splitext(program_file)[0]
            self.logger.info(f"--- Analisando programa: {program_name} ---")

            try:
                # 1. Parse do programa e resolução de COPYs
                resolved_code_lines = self.multi_parser.parse(program_path)
                resolved_code_str = "".join(resolved_code_lines)

                # 2. Análise Estrutural
                structural_analysis = self.structure_analyzer.analyze(resolved_code_lines)

                # 3. Análise de Layout de Registro
                record_layouts = self.layout_parser.parse(resolved_code_lines)

                # 4. Análise Semântica com LLM
                semantic_analysis = self.semantic_analyzer.analyze(program_name, resolved_code_str, structural_analysis)

                # 5. Montar os resultados da análise
                analysis_results = {
                    "program_name": program_name,
                    "structural_analysis": structural_analysis,
                    "record_layouts": record_layouts,
                    "functional_analysis": semantic_analysis, # Agora vem da análise semântica
                }

                # 6. Geração de Documentação
                documentation = self.doc_generator.generate(analysis_results)
                doc_file_path = os.path.join(self.output_dir, f"{program_name}_DOCS_v7.md")
                with open(doc_file_path, "w", encoding="utf-8") as f:
                    f.write(documentation)
                self.logger.info(f"Documentação para {program_name} salva em: {doc_file_path}")

            except Exception as e:
                self.logger.error(f"Erro ao analisar o programa {program_name}: {e}", exc_info=True)

        self.logger.info("Análise de múltiplos programas concluída.")

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')

    parser = argparse.ArgumentParser(description="COBOL AI Engine - Análise de Múltiplos Programas v7")
    parser.add_argument("--programs-dir", type=str, default="/home/ubuntu/cobol_ai_engine_v2.0.0/extracted_programs", help="Diretório com os programas COBOL extraídos.")
    parser.add_argument("--books-dir", type=str, default="/home/ubuntu/cobol_ai_engine_v2.0.0/extracted_books", help="Diretório com os copybooks extraídos.")
    parser.add_argument("--output-dir", type=str, default="/home/ubuntu/cobol_ai_engine_v2.0.0/multi_program_analysis_results_v7", help="Diretório para salvar os resultados da análise.")
    args = parser.parse_args()

    engine = MultiProgramAnalysisEngine(args.programs_dir, args.books_dir, args.output_dir)
    engine.run_analysis()

