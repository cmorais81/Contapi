# Relatório de Completude de Processamento

**Data de Geração:** 13/09/2025 17:46:39  
**Versão do Sistema:** COBOL AI Engine v2.0.0

---

## Resumo Executivo

Este relatório apresenta a análise de completude do processamento de programas COBOL, 
garantindo que todos os programas listados no arquivo de entrada foram processados corretamente.

### Estatísticas Gerais

| Métrica | Valor |
|---------|-------|
| **Total de Programas** | 2863 |
| **Programas Encontrados** | 5 |
| **Programas Parseados** | 5 |
| **Programas Analisados** | 0 |
| **Programas Documentados** | 0 |
| **Programas com Erro** | 0 |
| **Percentual de Completude** | 0.0% |

---

## Status de Processamento

###  Programas Processados com Sucesso
*Nenhum programa nesta categoria*


### ⚠ Programas Não Encontrados
- **----+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----8**
- **VMEMBER NAME  LHAN0542**
- **V       IDENTIFICATION                  DIVISION**
- **V      *---------------------------------------------------------------***
- **V       PROGRAM-ID.     LHAN0542**
- **GPTI**
- **11**
- **V       DATE-COMPILED**
- **V      *REMARKS**
- **V      ******************** OBJETIVO DO PROGRAMA *************************
- **V      *** PARTICIONAR ARQUIVO BACEN DOC3040                          ****
- **V      **  SERAO GERADOS ARQUIVOS PARTICIONADOS DINAMICAMENTE         ****
- **TRANSMISSAO            ****
- **V      *******************************************************************
- **V      **      *          *          *                                ****
- **V      **VERSAO*   DATA   *  AUTOR   *            MOTIVO              ****
- **11 * EDIVALDO * NOVO                           ****
- **14 * MARCELLO * - PARTICIONAMENTO 4000 MB      ****
- **V689542**      *          *          * - LIMITE PARTICOES:            ****
- **V689542**      *          *          ***
- **V689542**      *          *          * - ADAPTACAO > 10 PARTES        ****
- **V689542**      *          *          * - NOVO FD LHS542S3 (DENE0530)  ****
- **15 *  ROBERTO * PROJETO DADOS RESPONSAVEL       ***
- **VRESPON*       *          *          * INCLUSAO DE TRATAM PARA TAB     ***
- **VRESPON*       *          *          * MZTCM530-DADOS RESPONS CADOC3040***
- **VSPR004*       *          *          * TRATAMENTO DE CADOC VAZIO       ***
- **VSPR004*       *          *          * ALOCACAO DINAMICA               ***
- **VSPRT11*       *          *          * TRATAMENTO DE CADOC BNDES       ***
- **VSPRT18*       *          *          * TRATAMENTO RESPONSAVEL          ***
- **VSPRT18*       *          *          * CADOC BNDES                     ***
- **VSPRT18*       *          *          *                                 ***
- **VSPRT60*       *          *  CABRAL  * RECOMPILACAO BOOK MZTCM530      ***
- **VSPRT60*       *          *          * MZM530-FONE-RESP E XML1-DOCI-TEL***
- **11 POSICOES             ***
- **25***
- **VSPRT82*       *          *          * METODAPPE="C" METODDIFTJE="S"   ***
- **V       ENVIRONMENT                     DIVISION**
- **V      ***
- **V       CONFIGURATION              SECTION**
- **V       SPECIAL-NAMES**
- **V           DECIMAL-POINT  IS COMMA**
- **V       INPUT-OUTPUT               SECTION**
- **V       FILE-CONTROL**
- **V           SELECT  LHS542E1  ASSIGN  LHS542E1**
- **V                   FILE      STATUS  IS  FS-LH542E1**
- **V           SELECT  LHS542E2  ASSIGN  LHS542E2**
- **V                   FILE      STATUS  IS  FS-LH542E2**
- **V           SELECT  LHS542E3  ASSIGN  LHS542E3**
- **V                   FILE      STATUS  IS  FS-LH542E3**
- **V           SELECT  LHS542E4  ASSIGN  LHS542E4**
- **V                   FILE      STATUS  IS  FS-LH542E4**
- **VRESPON     SELECT  LHS542E5  ASSIGN  TO  LHS542E5**
- **VRESPON             FILE      STATUS  IS  FS-LH542E5**
- **V           SELECT  LHS542S1  ASSIGN  LHS542S1**
- **V                   FILE      STATUS  IS  FS-LH542S1**
- **V           SELECT  LHS542S2  ASSIGN  LHS542S2**
- **V                   FILE      STATUS  IS  FS-LH542S2**
- **V           SELECT  LHS542S3  ASSIGN  LHS542S3**
- **V       DATA                            DIVISION**
- **V       FILE                       SECTION**
- **V       FD  LHS542E1                                                      000730**
- **V           BLOCK 0 RECORDS**
- **V           RECORDING MODE F**
- **V      *                                                                   000760**
- **V       01  REG-ENT1542**
- **V           05  TOT-LIDOS           PIC  9(015)**
- **V           05  TOT-PARTIC          PIC  9(003)**
- **V           05  FILLER              PIC  X(062)**
- **V       FD  LHS542E2                                                      000730**
- **V       01  REG-ENT2542**
- **V           05  ID-CLIENTE          PIC  X(006)**
- **V           05  FILLER              PIC  X(045)**
- **V           05  NR-REMESSA          PIC  9(001)**
- **V           05  FILLER              PIC  X(009)**
- **V           05  NR-PARTE            PIC  9(001)**
- **V           05  FILLER              PIC  X(002)**
- **V           05  TP-ARQUIVO          PIC  X(010)**
- **V           05  FILLER              PIC  X(026)**
- **V       FD  LHS542E3                                                      000730**
- **V       01  REG-ENT3542             PIC  X(080)**
- **V       FD  LHS542E4                                                      000730**
- **V       01  REG-ENTE04**
- **V           05  RELA-IDT            PIC  X(005)**
- **V           05  RELA-QTDE           PIC  9(015)**
- **V           05  FILLER              PIC  X(060)**
- **VRESPON*----------------------------------------------------------------***
- **VRESPON* ENTRADA: LHS542E5                                              ***
- **15  ***
- **VRESPON*    ARQUIVO  : LHS542E5                                         ***
- **VRESPON*    DESCRICAO: DADOS DO RESPONSAVEL CADOC3040                   ***
- **VRESPON*    TIPO     : SEQUENCIAL                                       ***
- **VRESPON*    TAM.REG**
- **VRESPON FD  LHS542E5**
- **VRESPON     RECORD  CONTAINS    154 CHARACTERS**
- **VRESPON     BLOCK   CONTAINS    0    RECORDS**
- **VRESPON     RECORDING MODE      F**
- **VRESPON     COPY    MZTCM530**
- **V**
- **V       FD  LHS542S1                                                      000730**
- **V       01  REG-SAI1542             PIC  X(100)**
- **V       FD  LHS542S2                                                      000730**
- **V       01  REG-SAI2542             PIC  X(080)**
- **V689542 FD  LHS542S3                                                      000730**
- **V689542     BLOCK 0 RECORDS**
- **V689542     RECORDING MODE F**
- **V689542*                                                                   000760**
- **V689542 01  REG-SAI3542**
- **V689542     03  S3-L1**
- **V689542         05  FILLER          PIC  X(011)**
- **V689542         05  S3-L1-SEQ-N2    PIC  X(002)**
- **V689542         05  FILLER          PIC  X(003)**
- **V689542         05  S3-L1-LETRA     PIC  X(001)**
- **V689542         05  FILLER          PIC  X(063)**
- **V689542     03  S3-L2               REDEFINES    S3-L1**
- **V689542         05  S3-L2-FECHA     PIC  X(002)**
- **V689542         05  FILLER          PIC  X(078)**
- **V       WORKING-STORAGE            SECTION**
- **V       01 WS-AREA-TRABALHO**
- **V689542    03 WS-TEMP**
- **V             05 WFIM-LH542E2            PIC  X(003) VALUE SPACES**
- **V             05 WFIM-LH542E4            PIC  X(003) VALUE SPACES**
- **VRESPON       05 WFIM-LH542E5            PIC  X(003) VALUE SPACES**
- **V             05 FS-LH542E1              PIC  X(002) VALUE SPACES**
- **V             05 FS-LH542E2              PIC  X(002) VALUE SPACES**
- **V             05 FS-LH542E3              PIC  X(002) VALUE SPACES**
- **V             05 FS-LH542E4              PIC  X(002) VALUE SPACES**
- **VRESPON       05 FS-LH542E5              PIC  X(002) VALUE SPACES**
- **V             05 FS-LH542S1              PIC  X(002) VALUE SPACES**
- **V             05 FS-LH542S2              PIC  X(002) VALUE SPACES**
- **V             05 WTOT-PART               PIC  9(003) VALUE ZEROS**
- **V689542       05 WMAX-PART               PIC  9(012)**
- **V             05 WTOT-LID                PIC  9(015) VALUE ZEROS**
- **V             05 WTOT-REGIS              PIC  9(015) VALUE ZEROS**
- **V             05 WTOT-GRAV               PIC  9(015) VALUE ZEROS**
- **V             05 WTOT-CLI                PIC  9(015) VALUE ZEROS**
- **V             05 WS-RELA-QTDE            PIC  9(015) VALUE ZEROS**
- **DOC3040>'**
- **V             05 WRETURN                 PIC  9(004) VALUE ZEROS**
- **V             05 WFLAG-CABEC             PIC  X(003) VALUE SPACES**
- **V             05 WSV-PARTE               PIC  9(003) VALUE ZEROS**
- **V689542       05 WSV-PARTE-DEZENA        REDEFINES   WSV-PARTE**
- **V689542          10 FILLER               PIC  9(001)**
- **V689542          10 WSV-PARTE-D          PIC  9(002)**
- **V689542       05 WSV-PARTE-UNIDADE       REDEFINES   WSV-PARTE**
- **V689542          10 FILLER               PIC  9(002)**
- **V689542          10 WSV-PARTE-U          PIC  9(001)**
- **V             05 WSV-TPARQ-AUX           PIC  X(010) VALUE SPACES**
- **V689542    03 WS-CABECS**
- **V             05 WSV-CABEC1              PIC  X(100) VALUE SPACES**
- **V             05 WSV-CABEC2**
- **V                10 FILLER               PIC  X(051) VALUE SPACES**
- **V                10 WSV-REMES-AUX        PIC  9(001) VALUE ZEROS**
- **V                10 FILLER               PIC  X(009) VALUE SPACES**
- **V689542*         10 WSV-PARTE-AUX        PIC  9(001) VALUE ZEROS**
- **V689542*         10 FILLER               PIC  X(002) VALUE SPACES**
- **V689542*         10 WSV-TPARQ            PIC  X(010) VALUE SPACES**
- **V689542*         10 FILLER               PIC  X(015) VALUE SPACES**
- **V689542*         10 WSV-TOTCLI           PIC  9(009) VALUE ZEROS**
- **V689542          10 WSV-C2               PIC  X(039)**
- **V689542*---      CONTINUACAO FINAL DO CABEC2 - PARTE 1 A 9**
- **V689542       05 WSV-C2-P1**
- **V689542          10 WSV-C2-PAR-P1A       PIC  9(001)**
- **V689542          10 WSV-C2-PAR-P1B       PIC  X(001)**
- **V689542          10 FILLER               PIC  X(001) VALUE SPACES**
- **V689542          10 WSV-C2-TPARQ-P1      PIC  X(010)**
- **V689542          10 WSV-C2-TOTCLI-P1A    PIC  X(010)**
- **V689542          10 WSV-C2-TOTCLI-P1B    PIC  9(009)**
- **V689542          10 WSV-C2-TOTCLI-P1C    PIC  X(001)**
- **V689542          10 FILLER               PIC  X(006)**
- **V689542*---      CONTINUACAO FINAL DO CABEC2 - PARTE 10 EM DIANTE**
- **V689542       05 WSV-C2-P2**
- **V689542          10 WSV-C2-PAR-P2A       PIC  9(002)**
- **V689542          10 WSV-C2-PAR-P2B       PIC  X(001)**
- **V689542          10 WSV-C2-TPARQ-P2      PIC  X(010)**
- **V689542          10 WSV-C2-TOTCLI-P2A    PIC  X(010)**
- **V689542          10 WSV-C2-TOTCLI-P2B    PIC  9(009)**
- **V689542          10 WSV-C2-TOTCLI-P2C    PIC  X(001)**
- **V689542          10 FILLER               PIC  X(005)**
- **V689542***
- **VRESPON       05 WSV-CABEC3              PIC  X(100)**
- **VRESPON       05 WSV-CABEC3-R REDEFINES  WSV-CABEC3**
- **VRESPON          10    C1-CABEC3              PIC  X(010)**
- **VRESPON          10    XML1-DOCI-NM           PIC  X(020)**
- **VRESPON          10    C2-CABEC3              PIC  X(013)**
- **VSPRT60          10    XML1-DOCI-EM           PIC  X(033)**
- **VRESPON          10    C3-CABEC3              PIC  X(011)**
- **VSPRT60          10    XML1-DOCI-TEL          PIC  X(011)**
- **VRESPON          10    C4-CABEC3              PIC  X(002)**
- **VRESPON          10    FILLER                 PIC  X(009)**
- **VSPRT82       05 WSV-CABEC4**
- **VSPRT82          10    C1-CABEC4              PIC  X(014)    VALUE**
- **VSPRT82                'METODAPPE="C" '**
- **VSPRT82          10    C2-CABEC4              PIC  X(016)    VALUE**
- **VSPRT82                'METODDIFTJE="S">'**
- **VSPRT82          10    FILLER                 PIC  X(070)    VALUE**
- **VSPRT82                SPACES**
- **V689542    03 WS-DRAM0082**
- **V             05 WDRAM0082               PIC  X(008) VALUE 'DRAM0082'**
- **V             05 WARQ-DDNAME1            PIC  X(008) VALUE 'LHS542S1'**
- **V             05 WARQ-DDNAME2            PIC  X(008) VALUE 'LHS542S2'**
- **V             05 WARQ-DSN-SEQ**
- **V                10 WARQ-DSN-SEQ-N       PIC  9(002) VALUE ZEROS**
- **V                10 WARQ-DSN-SEQ-X       PIC  X(001) VALUE SPACES**
- **V689542       05 WARQ-DSN-SEQ-N3         PIC  9(003) VALUE ZEROS**
- **V             05 WARQ-DSN-AUX            PIC  X(044) VALUE SPACES**
- **V             05 WARQ-DSNAME1            PIC  X(044) VALUE SPACES**
- **V             05 WARQ-DSNAME2            PIC  X(044) VALUE SPACES**
- **V             05 WARQ-NEW                PIC  X(003) VALUE 'NEW'**
- **V             05 WARQ-OLD                PIC  X(003) VALUE 'OLD'**
- **V             05 WARQ-CATLG              PIC  X(007) VALUE 'CATLG  '**
- **V             05 WARQ-DELETE             PIC  X(007) VALUE 'DELETE '**
- **V             05 WARQ-KEEP               PIC  X(007) VALUE 'KEEP   '**
- **V             05 WARQ-TYPE-SPACE         PIC  X(003) VALUE 'CYL'**
- **V             05 WARQ-SPACE-PRIM         PIC  9(002) VALUE 90**
- **V             05 WARQ-SPACE-SEC          PIC  9(002) VALUE 90**
- **V             05 WARQ-SPACE-RLSE         PIC  X(004) VALUE 'RLSE'**
- **V             05 WARQ-UNIT               PIC  X(005) VALUE 'SYSDA'**
- **V             05 WARQ-DATA-EXP           PIC  9(005) VALUE ZEROS**
- **V             05 WARQ-DCB-BLKSIZE        PIC  9(005) VALUE 30000**
- **V             05 WARQ-DCB-LRECL          PIC  9(005) VALUE ZEROS**
- **V             05 WARQ-DCB-BUFNO          PIC  9(002) VALUE 15**
- **V             05 WARQ-DCB-DSORG          PIC  X(003) VALUE 'PS'**
- **V             05 WARQ-DCB-RECFM          PIC  X(003) VALUE 'FB'**
- **V             05 WARQ-FREE               PIC  X(004) VALUE 'FREE'**
- **V689542    03 CT-CONSTANTES**
- **V689542       05 CT-DENE0530-L1          PIC  X(080)**
- **V689542                                  VALUE 'DENE0530 R=  ,L= '**
- ***'**
- **VRESPON    03 CH-RESP                    PIC  X(004) VALUE SPACES**
- **V      *-------- AREAS  AUXILIARES DA SUB-ROTINA (DRAM0082)  ----------***
- **V       01  WAREA-82**
- **V       ++INCLUDE  DRR00082**
- **V       LINKAGE                          SECTION**
- **V          01 LK-PARM**
- **V             03 PARM-TAM           PIC 9(04) COMP**
- **VSPRT11       03 PARM-EMP           PIC X(04)**
- **V             03 PARM-DAT           PIC 9(06)**
- **V       PROCEDURE                       DIVISION  USING  LK-PARM**
- **V       PRINCIPAL                  SECTION**
- **V           PERFORM     1-INICIO**
- **V           PERFORM     2-PROCESSA  UNTIL**
- **V                                   WFIM-LH542E2  EQUAL  'SIM'**
- **V           PERFORM     4-FIM**
- **V           GOBACK**
- **V       1-INICIO                   SECTION**
- **V           OPEN  INPUT  LHS542E1**
- **V                        LHS542E2**
- **V                        LHS542E3**
- **V                        LHS542E4**
- **VRESPON                  LHS542E5**
- **V689542     OPEN  OUTPUT LHS542S3**
- **V      *--- TRATAMENTO PARM - EMPRESA + DATABA + AMBIENTE**
- **V689542     IF  PARM-TAM  NOT EQUAL  10**
- **V               DISPLAY 'LHAN0542 - TAMANHO DO PARM INVALIDO'**
- **V               PERFORM  9-FIM-ANORMAL                                   FJAN0173**
- **V           ELSE**
- **VSPRT11*        IF  PARM-EMP  NOT NUMERIC**
- **VSPRT11*            DISPLAY 'LHAN0542 - PARM EMPRESA NAO NUMERICO'**
- **VSPRT11*            PERFORM  9-FIM-ANORMAL                               FJAN0173**
- **VSPRT11*        END-IF**
- **V               IF  PARM-DAT  NOT NUMERIC**
- **V                   DISPLAY 'LHAN0542 - PARM DATA NAO NUMERICO'**
- **V                   PERFORM  9-FIM-ANORMAL                               FJAN0173**
- **V               END-IF**
- **V           END-IF**
- **V      *--- TRATAMENTO ENTRADA 1 - TAMANHO DOC 3040 + QTE PARTICOES**
- **V           PERFORM 31-LEITURA-LHS542E1**
- **V           IF  FS-LH542E1  EQUAL  '10'                                  FJAN0173**
- **V               DISPLAY 'LHS542E1 -  ARQUIVO LHS542E1 VAZIO'             FJAN0173**
- **V689542*    MOVE    TOT-PARTIC    TO  WTOT-PART**
- **V      *--- TRATAMENTO POR EMPRESA, ALEM DE ATRIBUICAO "DEPARA" LETRA:**
- **V      *    - PARTICOES E TAMANHOS MAXIMOS POR EMPRESA:**
- **V      *      . 0033  : 15 PARTICOES - 62.914.560**
- **V      *      . 1508  :  3 PARTICOES - 12.582.912**
- **V      *      . DEMAIS:  1 PARTICAO  -  4.194.304**
- **V      *    - SE TAMANHO DOC 3040 FOR > 90%, EMITE RC = 93 (ALERTA)**
- **V689542     MOVE     1                 TO      WTOT-PART**
- **V689542     MOVE     80000000000       TO      WMAX-PART**
- **V689542     COMPUTE  TOT-LIDOS          =      TOT-LIDOS   *   100**
- **V689542     EVALUATE PARM-EMP**
- **V689542         WHEN '0033'**
- **V689542               MOVE    'A'      TO    WARQ-DSN-SEQ-X**
- **V689542               MOVE    15       TO    WTOT-PART**
- **15**
- **V689542               IF   TOT-LIDOS         GREATER   56623104000**
- **V689542                    DISPLAY 'DOC 3040 ACIMA DE 90%'**
- **V689542                    MOVE    93  TO    RETURN-CODE**
- **V689542               END-IF**
- **V689542         WHEN '1505'**
- **V689542               MOVE    'B'      TO      WARQ-DSN-SEQ-X**
- **V689542         WHEN '1506'**
- **V689542               MOVE    'C'      TO      WARQ-DSN-SEQ-X**
- **V689542*        WHEN '1507'**
- **V689542         WHEN 'BNDS'**
- **V689542               MOVE    'D'      TO      WARQ-DSN-SEQ-X**
- **V689542         WHEN '1508'**
- **V689542               MOVE    'E'      TO      WARQ-DSN-SEQ-X**
- **V689542               MOVE    3        TO      WTOT-PART**
- **3**
- **V689542               IF   TOT-LIDOS         GREATER   11324620800**
- **V689542         WHEN '1510'**
- **V689542               MOVE    'F'      TO      WARQ-DSN-SEQ-X**
- **V689542         WHEN '1513'**
- **V689542               MOVE    'G'      TO      WARQ-DSN-SEQ-X**
- **V689542         WHEN '6500'**
- **V689542               MOVE    'H'      TO      WARQ-DSN-SEQ-X**
- **V689542         WHEN OTHER**
- **V689542               DISPLAY 'PARM EMPRESA INCORRETO: ' PARM-EMP        FJAN0173**
- **V689542               MOVE    90       TO      RETURN-CODE**
- **V689542               PERFORM  9-FIM-ANORMAL                             FJAN0173**
- **V689542     END-EVALUATE**
- **V689542     IF   TOT-LIDOS   GREATER  3774873600  AND**
- **V689542         (PARM-EMP    NOT EQUAL '0033' AND '1508')**
- **V689542          DISPLAY 'DOC 3040 ACIMA DE 90%'**
- **V689542          MOVE    93  TO     RETURN-CODE**
- **V689542     END-IF**
- **V      *--- TRATAMENTO ENTRADA 4 - TOTAL CLIENTES**
- **V           PERFORM 34-LEITURA-LHS542E4**
- **V           IF  FS-LH542E4  EQUAL  '10'                                  FJAN0173**
- **V               DISPLAY 'LHS542E4 -  ARQUIVO LHS542E4 VAZIO'             FJAN0173**
- **VSPR004         DISPLAY 'FIM NORMAL SEM EMISS¶O DE CADOC 3040 DA EMPRESA'FJAN0173**
- **VSPR004         PERFORM  4-FIM                                           FJAN0173**
- **VSPR004*        PERFORM  9-FIM-ANORMAL                                   FJAN0173**
- **VSPR004     IF  RELA-QTDE  EQUAL ZEROS                                   FJAN0173**
- **VSPR004         DISPLAY 'LHS542E4 -  ARQUIVO CLIENTE ZERADO'             FJAN0173**
- **VSPR004         DISPLAY 'FIM NORMAL SEM CADOC 3040 DA EMPRESA'           FJAN0173**
- **VSPR004*        PERFORM  4-FIM                                           FJAN0173**
- **V           PERFORM 35-PROC-LHS542E4 UNTIL**
- **V                   WFIM-LH542E4  EQUAL  'SIM'**
- **VSPR004     IF  RELA-QTDE  GREATER ZEROS                                 FJAN0173**
- **V      *--- TRATAMENTO ENTRADA 2 - ARQUIVO DE DADOS**
- **V                PERFORM 32-LEITURA-LHS542E2**
- **V                IF  FS-LH542E2  EQUAL  '10'                             FJAN0173**
- **V                    DISPLAY 'LHS542E2 -  ARQUIVO LHS542E2 VAZIO'        FJAN0173**
- **V                    PERFORM  9-FIM-ANORMAL                              FJAN0173**
- **V                END-IF**
- **V               IF  WSV-CABEC1  EQUAL  SPACES                            FJAN0173**
- **V                   DISPLAY 'LHS542E2 -  ARQUIVO LHS542E2 SEM HEADER'    FJAN0173**
- **V               PERFORM 32-LEITURA-LHS542E2**
- **VSPR004     END-IF**
- **V           DISPLAY '***------------------ LHAN0542 ----------------***'**
- **V      *--- TRATAMENTO ENTRADA 3 - SYSIN: DSN DADOS E BASTAO**
- **CARREGAR DSN ARQUIVO DADOS**
- **V           PERFORM  33-LEITURA-LHS542E3**
- **V689542*--- IDENTIFICAR AMBIENTE DE PROCESSAMENTO**
- **V           MOVE     REG-ENT3542     TO  WARQ-DSNAME1**
- **VRESPON*--- OBTEM DADOS DO RESPONSAVEL CADOC3040**
- **VRESPON     PERFORM 35-LEITURA-LHS542E5**
- **VRESPON     IF      WFIM-LH542E5 EQUAL 'SIM'**
- **VRESPON             DISPLAY 'ARQUIVO LHS542E5 VAZIO'**
- **VRESPON             PERFORM 9-FIM-ANORMAL**
- **VRESPON     END-IF**
- **V           IF      PARM-EMP             EQUAL  'BNDS'**
- **V             IF    MZM530-TABELA        EQUAL  'M530'**
- **V                   PERFORM 35-LEITURA-LHS542E5**
- **VRESPON        IF   MZM530-TABELA   NOT  EQUAL  'BNDS'**
- **VRESPON             DISPLAY 'RESPONSAVEL BNDES NAO ENCONTRADO'**
- **VRESPON        END-IF**
- **VRESPON       END-IF**
- **VRESPON     MOVE    'NOMERESP="'            TO  C1-CABEC3**
- **VRESPON     MOVE    MZM530-NOME-RESP        TO  XML1-DOCI-NM**
- **VRESPON     MOVE    '" EMAILRESP="'         TO  C2-CABEC3**
- **VRESPON     MOVE    MZM530-EMAIL-RESP       TO  XML1-DOCI-EM**
- **VRESPON     MOVE    '" TELRESP="'           TO  C3-CABEC3**
- **VRESPON     MOVE    MZM530-FONE-RESP        TO  XML1-DOCI-TEL**
- **VRESPON*    MOVE    '">'                    TO  C4-CABEC3**
- **VSPRT82     MOVE    '" '                    TO  C4-CABEC3**
- **V               PERFORM  21-ALOCA-LHS542S1**
- **VSPR004     ELSE**
- **VSPR004         PERFORM  40-ALOCA-VAZIO**
- **CARREGAR DSN ARQUIVO BASTAO**
- **V           MOVE     REG-ENT3542     TO  WARQ-DSNAME2**
- **V       1-INICIO-SAI.              EXIT**
- **V       2-PROCESSA                 SECTION**
- **V689542*--- GRAVA POR PARTE O LIMITE CALCULADO NA SECAO 1-INICIO, MAIS**
- **CLI>**
- **V           PERFORM 24-GERA-ARQ-DINAMICO**
- **CLI>'      AND**
- **V689542                    WTOT-REGIS   >  WMAX-PART)   OR**
- **V                          WFIM-LH542E2 = 'SIM'**
- **V689542*--- PROCEDIMENTOS DE FIM DE PARTE E INICIO DA PROXIMA**
- **DOC3040>**
- **V689542*    - DISPLAY E ZERAR VARIAVEIS DE TOTAIS**
- **V689542*    - LIBERA ALOCACAO DINAMICA E GERA NOVA SE NAO FOR FIM DE**
- **V689542*      ARQUIVO LH542E2**
- **V689542     IF  WFIM-LH542E2 NOT EQUAL 'SIM'**
- **CLI>'**
- **V689542             WRITE   REG-SAI1542  FROM  REG-ENT2542**
- **V689542             COMPUTE WTOT-GRAV    =     WTOT-GRAV + 1**
- **V689542         END-IF**
- **V689542     MOVE    WDOC3040     TO    REG-SAI1542**
- **V689542     WRITE   REG-SAI1542**
- **V689542     COMPUTE WTOT-GRAV    =     WTOT-GRAV + 1**
- **V           PERFORM 25-DISPLAY-TOTAIS**
- **V           MOVE    ZEROS        TO    WTOT-LID**
- **V                                      WTOT-REGIS**
- **V                                      WTOT-GRAV**
- **V                                      WTOT-CLI**
- **V           PERFORM 26-LIBERA-LHS542S1**
- **V689542     PERFORM 27-GRAVA-LHS542S3**
- **V      *--- SE NAO FOR FIM DA ENTRADA E2, TESTA SE ALCANCOU LIMITES DE**
- **V      *    PARTICOES ANTES DE PROSSEGUIR**
- **V689542         EVALUATE PARM-EMP**
- **V689542             WHEN '0033'**
- **V689542                  IF  WARQ-DSN-SEQ-N3  EQUAL  15**
- **V689542                      MOVE    95       TO     RETURN-CODE**
- **V689542                  END-IF**
- **V689542             WHEN '1508'**
- **V689542                  IF  WARQ-DSN-SEQ-N3  EQUAL  3**
- **V689542             WHEN OTHER**
- **V689542                  IF  WARQ-DSN-SEQ-N3  EQUAL  1**
- **V689542         END-EVALUATE**
- **V689542         IF  RETURN-CODE EQUAL 95**
- **V689542             DISPLAY '*-----------------------------------------*'**
- **V689542             DISPLAY '*                                         *'**
- **V689542             DISPLAY '*     ALERTA  ALERTA  ALERTA ALERTA       *'**
- **V689542             DISPLAY '*   GERACAO ARQUIVO DINAMICO EXCEDIDO     *'**
- **V689542             PERFORM 4-FIM**
- **V689542         PERFORM 32-LEITURA-LHS542E2**
- **V689542         PERFORM 21-ALOCA-LHS542S1**
- **V689542*    IF  WFIM-LH542E2 NOT EQUAL 'SIM'**
- **V689542*            WRITE   REG-SAI1542  FROM  REG-ENT2542**
- **V689542*            COMPUTE WTOT-GRAV = WTOT-GRAV + 1**
- **V689542*        END-IF**
- **V689542*    END-IF**
- **V689542*    IF  WFIM-LH542E2  =  'SIM'**
- **V689542*        MOVE    WDOC3040 TO REG-SAI1542**
- **V689542*        WRITE   REG-SAI1542**
- **V689542*        COMPUTE WTOT-GRAV = WTOT-GRAV + 1**
- **V689542*        PERFORM 25-DISPLAY-TOTAIS**
- **V689542*        GO   TO 2-PROCESSA-SAI**
- **V       2-PROCESSA-SAI.            EXIT**
- **V       21-ALOCA-LHS542S1          SECTION**
- **V           ADD      1                       TO  WARQ-DSN-SEQ-N**
- **V689542                                          WARQ-DSN-SEQ-N3**
- **V689542*    IF  PARM-EMP  EQUAL  '0033'**
- **V689542*        MOVE  'A'                    TO  WARQ-DSN-SEQ-X**
- **V689542*    ELSE**
- **V689542*     IF  PARM-EMP  EQUAL  '1505'**
- **V689542*         MOVE  'B'                   TO  WARQ-DSN-SEQ-X**
- **V689542*     ELSE**
- **V689542*      IF  PARM-EMP  EQUAL  '1506'**
- **V689542*          MOVE  'C'                  TO  WARQ-DSN-SEQ-X**
- **V689542*      ELSE**
- **V689542*       IF  PARM-EMP  EQUAL  '1507'**
- **V689542*           MOVE  'D'                 TO  WARQ-DSN-SEQ-X**
- **V689542*       ELSE**
- **V689542*        IF  PARM-EMP  EQUAL  '1508'**
- **V689542*            MOVE  'E'                TO  WARQ-DSN-SEQ-X**
- **V689542*        ELSE**
- **V689542*         IF  PARM-EMP  EQUAL  '1510'**
- **V689542*             MOVE  'F'               TO  WARQ-DSN-SEQ-X**
- **V689542*         ELSE**
- **V689542*          IF  PARM-EMP  EQUAL  '1513'**
- **V689542*              MOVE  'G'              TO  WARQ-DSN-SEQ-X**
- **V689542*          ELSE**
- **V689542*          IF  PARM-EMP  EQUAL  '6500'**
- **V689542*              MOVE  'H'              TO  WARQ-DSN-SEQ-X**
- **V689542*         END-IF**
- **V689542*       END-IF**
- **V689542*      END-IF**
- **V689542*     END-IF**
- **VOLIVA *    IF  WARQ-DSN-SEQ-N  EQUAL  10**
- **VOLIVA *        MOVE ZEROS                   TO  WARQ-DSN-SEQ-N**
- **VOLIVA *    END-IF**
- **V           MOVE     WARQ-DSNAME1            TO  WARQ-DSN-AUX**
- **V           INSPECT  WARQ-DSN-AUX**
- **V                    REPLACING ALL '&EMP'    BY  PARM-EMP**
- **V689542*--- PARA AS EMPRESAS 0033 E 1508, SEQUENCIA NUMERICA DE 3 BYTES**
- **V689542*    DEMAIS EMPRESAS, 2 BYTES + 1 LETRA**
- **V689542     IF  PARM-EMP   EQUAL  '0033'  OR  '1508'**
- **V689542         INSPECT  WARQ-DSN-AUX**
- **V689542                  REPLACING ALL '&SW'     BY  WARQ-DSN-SEQ-N3**
- **V689542     ELSE**
- **V               INSPECT  WARQ-DSN-AUX**
- **V                        REPLACING ALL '&S'      BY  WARQ-DSN-SEQ-N**
- **V                        REPLACING ALL 'W'       BY  WARQ-DSN-SEQ-X**
- **V                    REPLACING ALL '&DATA**
- **V      ***> TENTA EXCLUIR O ARQUIVO ANTES DE ALOCAR (REPROCESSAMENTO)**
- **V      ***> ALOCANDO-O COM (OLD,DELETE,KEEP)**
- **V      ***> SE CONSEGUIR ALOCAR, ABRE E FECHA O ARQUIVO, EXCLUINDO-O**
- **V      ***> SE NAO CONSEGUIR ALOCAR, O ARQUIVO NAO EXISTE**
- **V           MOVE     SPACES                  TO  WAREA-82**
- **V           MOVE     1                       TO  W82-OPCAO**
- **V           MOVE     WARQ-OLD                TO  W82-DISP1**
- **V           MOVE     WARQ-DELETE             TO  W82-DISP2**
- **V           MOVE     WARQ-KEEP               TO  W82-DISP3**
- **V           MOVE     WARQ-DDNAME1            TO  W82-DDNAME**
- **V           MOVE     WARQ-DSN-AUX            TO  W82-DSNAME**
- **V           MOVE     WARQ-FREE               TO  W82-FREE-EQUAL-CLOSE**
- **V           CALL     WDRAM0082            USING  WAREA-82**
- **V           IF  W82-CODRET  EQUAL  ZEROS**
- **V               OPEN  OUTPUT  LHS542S1**
- **V               CLOSE         LHS542S1**
- **V      ***> ALOCA DINAMICAMENTE O ARQUIVO**
- **V           MOVE     WARQ-NEW                TO  W82-DISP1**
- **V           MOVE     WARQ-CATLG              TO  W82-DISP2**
- **V           MOVE     WARQ-DELETE             TO  W82-DISP3**
- **V           MOVE     WARQ-TYPE-SPACE         TO  W82-TYPE-SPACE**
- **V           MOVE     WARQ-SPACE-PRIM         TO  W82-SPACE-PRIM**
- **V           MOVE     WARQ-SPACE-SEC          TO  W82-SPACE-SEC**
- **V           MOVE     WARQ-SPACE-RLSE         TO  W82-SPACE-RLSE**
- **V           MOVE     WARQ-UNIT               TO  W82-UNIT**
- **V           MOVE     WARQ-DATA-EXP           TO  W82-DATA-EXPIRATION**
- **V           MOVE     WARQ-DCB-BLKSIZE        TO  W82-DCB-BLKSIZE**
- **V           MOVE     100                     TO  WARQ-DCB-LRECL**
- **V           MOVE     WARQ-DCB-LRECL          TO  W82-DCB-LRECL**
- **V           MOVE     WARQ-DCB-RECFM          TO  W82-DCB-RECFM**
- **V           MOVE     WARQ-DCB-BUFNO          TO  W82-DCB-BUFNO**
- **V           MOVE     WARQ-DCB-DSORG          TO  W82-DCB-DSORG**
- **V           IF  W82-CODRET  NOT EQUAL  ZEROS**
- **ALOCACAO LHS542S1'FJAN0173**
- **V               DISPLAY W82-MENSERRO                                     FJAN0173**
- **V           OPEN  OUTPUT  LHS542S1**
- **V           PERFORM 23-GERA-CABECALHO**
- **V       21-ALOCA-LHS542S1-SAI.     EXIT**
- **V       22-ALOCA-LHS542S2          SECTION**
- **V           MOVE     WARQ-DSNAME2            TO  WARQ-DSN-AUX**
- **V689542     IF  PARM-EMP   EQUAL   '0033'  OR  '1508'**
- **V           MOVE     WARQ-DDNAME2            TO  W82-DDNAME**
- **V               OPEN  OUTPUT  LHS542S2**
- **V               CLOSE         LHS542S2**
- **V           MOVE     80                      TO  WARQ-DCB-LRECL**
- **V           CALL     WDRAM0082  USING  WAREA-82**
- **ALOCACAO LHS542S2'FJAN0173**
- **V           OPEN  OUTPUT  LHS542S2**
- **V      *                                                                 FJAN0173**
- **V       22-ALOCA-LHS542S2-SAI.     EXIT**
- **V       23-GERA-CABECALHO          SECTION**
- **V689542*--- GRAVA CABEC1**
- **V           WRITE   REG-SAI1542  FROM  WSV-CABEC1**
- **V           COMPUTE WTOT-GRAV    =     WTOT-GRAV + 1**
- **V689542*--- GRAVA CABEC2**
- **V689542*    - UNICA OU ULTIMA PARTE: ASSINALA TAG TPARQ=F**
- **V689542*    - PARTE DE 1 A 9       : POSICOES NORMAIS**
- **V689542*    - PARTE 10 EM DIANTE   : UMA POSICAO A DIREITA**
- **V           IF  WSV-PARTE  EQUAL WTOT-PART**
- **V               MOVE     WSV-TPARQ-AUX     TO WSV-C2-TPARQ-P1**
- **V689542     IF  WSV-PARTE  LESS THAN 10**
- **V689542         MOVE     WSV-PARTE-U       TO WSV-C2-PAR-P1A**
- **V689542         MOVE     WSV-C2-P1         TO WSV-C2**
- **V689542         IF  WSV-PARTE  EQUAL 10**
- **V689542             MOVE SPACES            TO WSV-C2-P2**
- **V689542             MOVE WSV-C2-PAR-P1B    TO WSV-C2-PAR-P2B**
- **V689542             MOVE WSV-C2-TPARQ-P1   TO WSV-C2-TPARQ-P2**
- **V689542             MOVE WSV-C2-TOTCLI-P1A TO WSV-C2-TOTCLI-P2A**
- **V689542             MOVE WSV-C2-TOTCLI-P1B TO WSV-C2-TOTCLI-P2B**
- **V689542             MOVE WSV-C2-TOTCLI-P1C TO WSV-C2-TOTCLI-P2C**
- **V689542         MOVE     WSV-PARTE-D       TO WSV-C2-PAR-P2A**
- **V689542         MOVE     WSV-C2-TPARQ-P1   TO WSV-C2-TPARQ-P2**
- **V689542         MOVE     WSV-C2-P2         TO WSV-C2**
- **V           WRITE   REG-SAI1542  FROM  WSV-CABEC2**
- **V689542*    COMPUTE WSV-PARTE-AUX =    WSV-PARTE-AUX + 1**
- **V689542*--- GRAVA CABEC3**
- **V           WRITE   REG-SAI1542  FROM  WSV-CABEC3**
- **VSPRT82*--- GRAVA CABEC4**
- **V           WRITE   REG-SAI1542  FROM  WSV-CABEC4**
- **V           ADD          1                TO WSV-PARTE**
- **V       23-GERA-CABECALHO-SAI.     EXIT**
- **V       24-GERA-ARQ-DINAMICO       SECTION**
- **V           WRITE   REG-SAI1542  FROM  REG-ENT2542**
- **V           COMPUTE WTOT-GRAV = WTOT-GRAV + 1**
- **V           PERFORM 32-LEITURA-LHS542E2**
- **V       24-GERA-ARQ-DINAMICO-SAI.  EXIT**
- **V       25-DISPLAY-TOTAIS          SECTION**
- **V           DISPLAY '***                                            ***'**
- **V           DISPLAY '*** GERADO ARQUIVO DINAMICO                    ***'**
- **V           DISPLAY '*** ' WARQ-DSN-AUX**
- **V           DISPLAY '*** '**
- **V           DISPLAY '***   TOTAL LIDOS    = ' WTOT-LID**
- **V           DISPLAY '***   TOTAL GRAVADOS = ' WTOT-GRAV**
- **V           DISPLAY '***   TOTAL CLIENTES = ' WTOT-CLI**
- **V       25-DISPLAY-TOTAIS-SAI.     EXIT**
- **V       26-LIBERA-LHS542S1         SECTION**
- **V           CLOSE  LHS542S1                                              FJAN0173**
- **V           MOVE    SPACES                   TO  WAREA-82**
- **V           MOVE    2                        TO  W82-OPCAO**
- **V           MOVE    WARQ-DDNAME1             TO  W82-DDNAME**
- **V           CALL    WDRAM0082  USING  WAREA-82**
- **LIBERACAO LHS542S1'FJAN0173**
- **V               DISPLAY  W82-MENSERRO                                    FJAN0173**
- **V           PERFORM 22-ALOCA-LHS542S2**
- **V           DISPLAY '*** ARQUIVO BASTAO CORRESPONDENTE              ***'**
- **V           DISPLAY '***--------------------------------------------***'**
- **V           CLOSE  LHS542S2**
- **V       26-LIBERA-LHS542S1-SAI.    EXIT**
- **V689542 27-GRAVA-LHS542S3          SECTION**
- **V689542     MOVE    CT-DENE0530-L1   TO   S3-L1**
- **V689542     MOVE    WARQ-DSN-SEQ-N   TO   S3-L1-SEQ-N2**
- **V689542     MOVE    WARQ-DSN-SEQ-X   TO   S3-L1-LETRA**
- **V689542     WRITE   REG-SAI3542**
- **V689542     MOVE    CT-DENE0530-L2   TO   S3-L2**
- **V689542**
- **V689542 27-GRAVA-LHS542S3-SAI.     EXIT**
- **V       31-LEITURA-LHS542E1        SECTION**
- **V           READ  LHS542E1                                               FJAN0173**
- **V           IF  FS-LH542E1  NOT EQUAL  '00' AND '10'                     FJAN0173**
- **V               DISPLAY 'LHAN0542 -  ERRO DE LEITURA DO ARQUIVO LHE542E1'FJAN0173**
- **V               DISPLAY '            FILE STATUS = ' FS-LH542E1          FJAN0173**
- **V       31-LEITURA-EDQ542E1-SAI.    EXIT**
- **V       32-LEITURA-LHS542E2        SECTION**
- **V           READ  LHS542E2                                               FJAN0173**
- **V           IF  FS-LH542E2  NOT EQUAL  '00' AND '10'                     FJAN0173**
- **V               DISPLAY 'LHAN0542 -  ERRO DE LEITURA DO ARQUIVO LHE542E2'FJAN0173**
- **V               DISPLAY '            FILE STATUS = ' FS-LH542E2          FJAN0173**
- **V           ELSE                                                         FJAN0173**
- **V               IF  FS-LH542E2  EQUAL  '10'                              FJAN0173**
- **V                   MOVE  'SIM'  TO  WFIM-LH542E2                        FJAN0173**
- **V                   GO TO  32-LEITURA-EDQ542E2-SAI**
- **V           IF  ID-CLIENTE  NOT EQUAL  '<?XML '**
- **V               COMPUTE WTOT-LID   = WTOT-LID + 1**
- **V               COMPUTE WTOT-REGIS = WTOT-REGIS + 100**
- **V               IF  WFLAG-CABEC  EQUAL  SPACES                           FJAN0173**
- **V689542*---         SALVA CABECALHO 1**
- **V                   MOVE    REG-ENT2542  TO  WSV-CABEC1**
- **V689542*---         SALVA CABECALHO 2**
- **V                   PERFORM 32-LEITURA-LHS542E2**
- **V                   MOVE    TP-ARQUIVO   TO  WSV-TPARQ-AUX**
- **V689542*            MOVE    NR-PARTE     TO  WSV-PARTE-AUX**
- **V689542             MOVE    1            TO  WSV-PARTE**
- **V                   MOVE    SPACES       TO  TP-ARQUIVO**
- **V                   MOVE    REG-ENT2542  TO  WSV-CABEC2**
- **V689542             MOVE    WSV-C2       TO  WSV-C2-P1**
- **V                   MOVE    1            TO  WSV-REMES-AUX**
- **V689542             MOVE  WS-RELA-QTDE   TO  WSV-C2-TOTCLI-P1B**
- **V689542*---         SALVA CABECALHO 3**
- **VRESPON*            MOVE    REG-ENT2542  TO  WSV-CABEC3**
- **V                   MOVE    'SIM'                   TO  WFLAG-CABEC**
- **V               ELSE**
- **V               COMPUTE  WTOT-CLI  = WTOT-CLI + 1**
- **V       32-LEITURA-EDQ542E2-SAI.    EXIT**
- **V       33-LEITURA-LHS542E3        SECTION**
- **V           READ  LHS542E3                                               FJAN0173**
- **V           IF  FS-LH542E3  NOT EQUAL  '00'                              FJAN0173**
- **V               DISPLAY 'LHAN0542 -  ERRO DE LEITURA DO ARQUIVO LHE542E3'FJAN0173**
- **V               DISPLAY '            FILE STATUS = ' FS-LH542E3          FJAN0173**
- **V       33-LEITURA-EDQ542E3-SAI.    EXIT**
- **V       34-LEITURA-LHS542E4        SECTION**
- **V           READ  LHS542E4                                               FJAN0173**
- **V                          AT END MOVE 'SIM' TO WFIM-LH542E4**
- **V       34-LEITURA-EDQ542E4-SAI.    EXIT**
- **VRESPON*---------------------------------------------------------------***
- **VRESPON 35-LEITURA-LHS542E5        SECTION**
- **VRESPON***
- **VRESPON     READ  LHS542E5                                               FJAN0173**
- **VRESPON                    AT END MOVE 'SIM' TO WFIM-LH542E5**
- **VRESPON 35-LEITURA-EDQ542E5-SAI.    EXIT**
- **V       35-PROC-LHS542E4        SECTION**
- **V           ADD    RELA-QTDE    TO WS-RELA-QTDE**
- **V                                                                        FJAN0173**
- **V       35-PROC-EDQ542E4-SAI.    EXIT**
- **VSPR004* ALOCACAO DE SAIDA PARA ARQUIVOS VAZIOS**
- **VSPR004*---------------------------------------------------------------***
- **VSPR004 40-ALOCA-VAZIO          SECTION**
- **VSPR004     ADD      1                       TO  WARQ-DSN-SEQ-N**
- **VSPR004                                          WARQ-DSN-SEQ-N3**
- **VSPR004***
- **VSPR004     MOVE     WARQ-DSNAME1            TO  WARQ-DSN-AUX**
- **VSPR004     INSPECT  WARQ-DSN-AUX**
- **VSPR004              REPLACING ALL '&EMP'    BY  PARM-EMP**
- **VSPR004*--- PARA AS EMPRESAS 0033 E 1508, SEQUENCIA NUMERICA DE 3 BYTES**
- **VSPR004*    DEMAIS EMPRESAS, 2 BYTES + 1 LETRA**
- **VSPR004     IF  PARM-EMP   EQUAL  '0033'  OR  '1508'**
- **VSPR004         INSPECT  WARQ-DSN-AUX**
- **VSPR004                  REPLACING ALL '&SW'     BY  WARQ-DSN-SEQ-N3**
- **VSPR004                  REPLACING ALL '&S'      BY  WARQ-DSN-SEQ-N**
- **VSPR004                  REPLACING ALL 'W'       BY  WARQ-DSN-SEQ-X**
- **VSPR004              REPLACING ALL '&DATA**
- **VSPR004***> TENTA EXCLUIR O ARQUIVO ANTES DE ALOCAR (REPROCESSAMENTO)**
- **VSPR004***> ALOCANDO-O COM (OLD,DELETE,KEEP)**
- **VSPR004***> SE CONSEGUIR ALOCAR, ABRE E FECHA O ARQUIVO, EXCLUINDO-O**
- **VSPR004***> SE NAO CONSEGUIR ALOCAR, O ARQUIVO NAO EXISTE**
- **VSPR004     MOVE     SPACES                  TO  WAREA-82**
- **VSPR004     MOVE     1                       TO  W82-OPCAO**
- **VSPR004     MOVE     WARQ-OLD                TO  W82-DISP1**
- **VSPR004     MOVE     WARQ-DELETE             TO  W82-DISP2**
- **VSPR004     MOVE     WARQ-KEEP               TO  W82-DISP3**
- **VSPR004     MOVE     WARQ-DDNAME1            TO  W82-DDNAME**
- **VSPR004     MOVE     WARQ-DSN-AUX            TO  W82-DSNAME**
- **VSPR004     MOVE     WARQ-FREE               TO  W82-FREE-EQUAL-CLOSE**
- **VSPR004**
- **VSPR004     CALL     WDRAM0082            USING  WAREA-82**
- **VSPR004     IF  W82-CODRET  EQUAL  ZEROS**
- **VSPR004         OPEN  OUTPUT  LHS542S1**
- **VSPR004         CLOSE         LHS542S1**
- **VSPR004***> ALOCA DINAMICAMENTE O ARQUIVO**
- **VSPR004     MOVE     WARQ-NEW                TO  W82-DISP1**
- **VSPR004     MOVE     WARQ-CATLG              TO  W82-DISP2**
- **VSPR004     MOVE     WARQ-DELETE             TO  W82-DISP3**
- **VSPR004     MOVE     WARQ-TYPE-SPACE         TO  W82-TYPE-SPACE**
- **VSPR004     MOVE     WARQ-SPACE-PRIM         TO  W82-SPACE-PRIM**
- **VSPR004     MOVE     WARQ-SPACE-SEC          TO  W82-SPACE-SEC**
- **VSPR004     MOVE     WARQ-SPACE-RLSE         TO  W82-SPACE-RLSE**
- **VSPR004     MOVE     WARQ-UNIT               TO  W82-UNIT**
- **VSPR004     MOVE     WARQ-DATA-EXP           TO  W82-DATA-EXPIRATION**
- **VSPR004     MOVE     WARQ-DCB-BLKSIZE        TO  W82-DCB-BLKSIZE**
- **VSPR004     MOVE     100                     TO  WARQ-DCB-LRECL**
- **VSPR004     MOVE     WARQ-DCB-LRECL          TO  W82-DCB-LRECL**
- **VSPR004     MOVE     WARQ-DCB-RECFM          TO  W82-DCB-RECFM**
- **VSPR004     MOVE     WARQ-DCB-BUFNO          TO  W82-DCB-BUFNO**
- **VSPR004     MOVE     WARQ-DCB-DSORG          TO  W82-DCB-DSORG**
- **VSPR004     IF  W82-CODRET  NOT EQUAL  ZEROS**
- **VSPR004         DISPLAY W82-MENSERRO                                     FJAN0173**
- **VSPR004         PERFORM  9-FIM-ANORMAL                                   FJAN0173**
- **VSPR004     OPEN  OUTPUT  LHS542S1**
- **VSPR004     CLOSE  LHS542S1**
- **VSPR004*********************************************
- **VSPR004*   ALOCA ARQUIVO BASTAO**
- **VSPR004***************************************************
- **VSPR004     PERFORM  33-LEITURA-LHS542E3**
- **VSPR004     MOVE     REG-ENT3542     TO  WARQ-DSNAME2**
- **VSPR004     MOVE    SPACES                   TO  WAREA-82**
- **VSPR004     MOVE    2                        TO  W82-OPCAO**
- **VSPR004     MOVE    WARQ-DDNAME1             TO  W82-DDNAME**
- **VSPR004     CALL    WDRAM0082  USING  WAREA-82**
- **VSPR004*                                                                 FJAN0173**
- **VSPR004         DISPLAY  W82-MENSERRO                                    FJAN0173**
- **VSPR004     PERFORM 22-ALOCA-LHS542S2**
- **VSPR004     DISPLAY '*** ARQUIVO BASTAO CORRESPONDENTE              ***'**
- **VSPR004     DISPLAY '*** ' WARQ-DSN-AUX**
- **VSPR004     DISPLAY '***                                            ***'**
- **VSPR004     DISPLAY '***--------------------------------------------***'**
- **VSPR004     CLOSE  LHS542S2**
- **VSPR004 40-ALOCA-VAZIO-SAI.      EXIT**
- **V       4-FIM                      SECTION**
- **V           CLOSE  LHS542E1                                               002540**
- **V                  LHS542E2                                               002540**
- **V                  LHS542E3                                               002540**
- **V                  LHS542E4                                               002540**
- **VRESPON            LHS542E5                                               002540**
- **V689542            LHS542S3                                               002540**
- **V           IF  FS-LH542E1  NOT EQUAL  ZEROS**
- **V               DISPLAY  'LHAN0542 -  ERRO NO FECHAMENTO LHS542E1'       FJAN0173**
- **V               DISPLAY  '            FILE STATUS = '  FS-LH542E1**
- **V               MOVE  4444                   TO  RETURN-CODE**
- **V           IF  FS-LH542E2  NOT EQUAL  ZEROS**
- **V               DISPLAY  'LHAN0542 -  ERRO NO FECHAMENTO LHS542E2'       FJAN0173**
- **V               DISPLAY  '            FILE STATUS = '  FS-LH542E2**
- **V           IF  FS-LH542E3  NOT EQUAL  ZEROS**
- **V               DISPLAY  'LHAN0542 -  ERRO NO FECHAMENTO LHS542E3'       FJAN0173**
- **V               DISPLAY  '            FILE STATUS = '  FS-LH542E3**
- **V           IF  FS-LH542E4  NOT EQUAL  ZEROS**
- **V               DISPLAY  'LHAN0542 -  ERRO NO FECHAMENTO LHS542E4'       FJAN0173**
- **V               DISPLAY  '            FILE STATUS = '  FS-LH542E4**
- **VRESPON     IF  FS-LH542E5  NOT EQUAL  ZEROS**
- **VRESPON         DISPLAY  'LHAN0542 -  ERRO NO FECHAMENTO LHS542E5'       FJAN0173**
- **VRESPON         DISPLAY  '            FILE STATUS = '  FS-LH542E5**
- **VRESPON         MOVE  4444                   TO  RETURN-CODE**
- **VRESPON         PERFORM  9-FIM-ANORMAL                                   FJAN0173**
- **V689542*    CLOSE  LHS542S1                                               002540**
- **V689542*    MOVE    SPACES                   TO  WAREA-82**
- **V689542*    MOVE    2                        TO  W82-OPCAO**
- **V689542*    MOVE    WARQ-DDNAME1             TO  W82-DDNAME**
- **V689542*    CALL    WDRAM0082  USING  WAREA-82**
- **V689542*    IF  W82-CODRET  NOT EQUAL  ZEROS**
- **V689542*        DISPLAY W82-MENSERRO                                     FJAN0173**
- **V689542*        PERFORM  9-FIM-ANORMAL                                   FJAN0173**
- **V689542*    PERFORM 22-ALOCA-LHS542S2**
- **V689542*    DISPLAY '*** ARQUIVO BASTAO CORRESPONDENTE              ***'**
- **V689542*    DISPLAY '*** ' WARQ-DSN-AUX**
- **V689542*    DISPLAY '***                                            ***'**
- **V689542*    DISPLAY '***--------------------------------------------***'**
- **V689542*    CLOSE  LHS542S2                                              FJAN0173**
- **V689542*    IF  WRETURN  EQUAL  4**
- **V689542*        MOVE  WRETURN                TO  RETURN-CODE**
- **V       4-FIM-SAI.                 EXIT**
- **V       9-FIM-ANORMAL              SECTION**
- **V               DISPLAY 'LHAN0542 -  ERRO NO FECHAMENTO LHS542E1'        FJAN0173**
- **V               DISPLAY '            FILE STATUS = '  FS-LH542E1**
- **V               DISPLAY 'LHAN0542 -  ERRO NO FECHAMENTO LHS542E2'        FJAN0173**
- **V               DISPLAY '            FILE STATUS = '  FS-LH542E2**
- **V               DISPLAY 'LHAN0542 -  ERRO NO FECHAMENTO LHS542E3'        FJAN0173**
- **V               DISPLAY '            FILE STATUS = '  FS-LH542E3**
- **V           MOVE  4444  TO  RETURN-CODE**
- **V       9-FIM-ANORMAL-SAI.         EXIT**
- **VMEMBER NAME  LHAN0705**
- **V       IDENTIFICATION DIVISION**
- **V       PROGRAM-ID.     LHAN0705**
- **V       AUTHOR.         T520Q6S**
- **2013**
- **V      **                                                              ***
- **V      *        OBJETIVO:  VALIDACAO FISICA E LOGICA DE ARQUIVO        ***
- **V      *                   RECEBIDO DA AREA DE RISCOS SOLVENCIA COM    ***
- **V      *                   OPERACOES MARCADAS COMO COMPULSORIO         ***
- **V      *                                                               ***
- **V      *  INPUT  :                                                     ***
- **V      *  ARQUIVO ENTRADA    -> E1DQ0705   -  ARQUIVO LH VIA MICRO     ***
- **V      *  ARQUIVO SAIDA      -> S1DQ0705   -  ARQUIVO LH PROC**
- **VSPRT76*  ARQUIVO SAIDA      -> S2DQ0705   -  ARQUIVO ERRO             ***
- **V      *                    M A N U T E N C A O                        ***
- **V      *   DATA    USUARIO   DESCRICAO                                 ***
- **V      * 13-05-14  ROBERTO   ACEITAR ARQUIVO VAZIO                     ***
- **V697665* 22-09-14  MARCELLO  OPERACOES DESCONSIGNADAS                  ***
- **V  ||  *                     - UNIFICACAO BOOKS LHCE0430 E LHCE0431    ***
- **V  ||  *                     - VALIDACOES:                             ***
- **SUBMOD                            ***
- **SUBTIPO              ***
- **SUBMOD CONTRA INFO. ADIC**
- **V  ||  *                       - DATAS                                 ***
- **CNPJ                  ***
- **V  ||  *                       - VALORES E PERCENTUAIS NUMERICOS       ***
- **V  ||  *                       - FORMATO CONTRATO                      ***
- **V  ||  *                       - FORMATO COD**
- **V  ||  *                       - FORMATO NUC3                          ***
- **DESCONSIG**
- **V  ||  *                       - FORMATO CHASSI                        ***
- **V  ||  *                     - QTE MAXIMA DE INCONSISTENCIAS ASSINALA- ***
- **V  ||  *                       DAS IGUAL A 10, APESAR DE INDICAR ATE   ***
- **V697665*                       30 OCORRENCIAS ATRAVES DE WORKING       ***
- **VCORBAN* 21-10-16 - ROBERTO  - INCLUSAO DE TATICO PARA CORRESPONDENTE  ***
- **VCORBAN*                       BANCARIO TP-REG=5,TPINFO=16,SBINFO=01   ***
- **VCORBAN*                       CD-INFO=CNPJ DO CORRESPONDENTE          ***
- **VCORBAN*                       EMERGENCIAL - COMPILAR COM BOOK ALTERADO***
- **VV00001* 10-02-17 - ADELMO   - RECOMPILA§¥O BOOK LHCP3402              ***
- **VCMP01 * 07-04-17 - CRISTIANE  RECOMPILAR BOOK LHCP3402 INF**
- **VMANO1 * 19-07-17 - JMANOEL    RECOMPILAR BOOK LHCP3402 ANEXO 03       ***
- **VMANO2 * 05-10-17 - JMANOEL    RECOMPILAR BOOK LHCP3402 ANEXO 03-1803  ***
- **VOLIVA1* 07-08-18 - OLIVEIRA   SICOR; CADIP E COLATERAL FINANCEIRO     ***
- **VADELMO* 04-07-19 - ADELMO     ECOXX - CAMPO DE INDEXADOR COMP         ***
- **BOOK LHCP3402         ***
- **BOOK LHCP3402                  ***
- **VSPRT04*  TRATAMENTO DE TIPO DE INFORMA§¥O 06                          ***
- **VXPRT06*  TRATAMENTO DE FGI                                            ***
- **BOOK LHCP3402------------------***
- **VXPRT07*---------------------------------------------------------------***
- **VSPRT09*- TRATAMENTO DE INFORMA§¥O ADICIONAO 1408                      ***
- **VSPRT09*- 14 "(NR) APLICA§¥O REGULATÌRIA VINCULA§¥O LEGAL E REGULATÌRIA***
- **VSPRT09*-   01 CUMPRIMENTO DE DIRECIONAMENTO OBRIGATÌRIO DE DEPÌSITOS £***
- **VSPRT09*-      MICRO FINANCAS                                          ***
- **VSPRT09*-   02 CUMPRIMENTO DE EXIGIBILIDADES DO CR©DITO RURAL MCR      ***
- **VSPRT09*-   03 REDU§¥O DE RECOLHIMENTO COMPULSÌRIO SOBRE RECURSOS VISTA***
- **VSPRT09*-      PROGRAMAS DE INVESTIMENTO                               ***
- **VSPRT09*-   04 REDU§¥O DE RECOLHIMENTO COMPULSÌRIO SOBRE RECURSOS VISTA***
- **VSPRT09*-      ESPECIFICO DE CREDITO RURAL                             ***
- **VSPRT09*-   05 CUMPRIMENTO DE DIRECIONAMENTO OBRIGATÌRIO DE DEPÌSITOS  ***
- **VSPRT09*-      DE POUPAN§A LIVRE                                       ***
- **VSPRT09*-   06 REDU§¥O DE RECOLHIMENTO COMPULSÌRIO SOBRE RECURSOS  A   ***
- **VSPRT09*-      PRAZO                                                   ***
- **VSPRT09*-   07 TRANSFERIDAS AO BANCO CENTRAL EM OPERA§¥O DE REDESCONTO ***
- **VSPRT09*-      OU EMPRESTIMO                                           ***
- **VSPRT09*-   08 OUTRO USO REGULATÌRIO                                   ***
- **VSPRT09*-      (NR) ANEXO 37: TIPO DE USO REGULATÌRIO                  ***
- **VSPRT09*-      DOM­NIO DESCRI§¥O                                       ***
- **VSPRT09*-      01 OPERA§ÍES CONTRATADAS NO ¡MBITO DO PRONAMPE          ***
- **VSPRT09*-         LEI 13990  PROGRAMA NACIONAL DE APOIO                ***
- **VSPRT09*-         AS MICROEMPRESAS E EMPRESAS DE PEQUENO PORTE)        ***
- **VSPRT09*-      02 OPERA§ÍES CONCEDIDAS NO ¡MBITO DO FGI PEAC           ***
- **VSPRT09*-         MEDIDA PROVISÌRIA NÌ 975 - PROGRAMA                  ***
- **VSPRT09*-         EMERGENCIAL DE ACESSO A CR©DITO                      ***
- **VSPRT09*-      03 OPERA§ÍES CONTRATADAS NO ¡MBITO DA CIRCULAR NÌ 4**
- **VSPRT09*-         DEDU§ÍES SOBRE AS EXIGIBILIDADES DOS RECURSOS DE DEPÌ***
- **VSPRT09*-         SITOS EM POUPAN¸A                                    ***
- **VSPRT09*-      04 OPERA§ÍES CONTRATADAS NO ¡MBITO DO CGPE              ***
- **VSPRT09*-         RESOLU§¥O NÌ 4**
- **VSPRT09*-         PROGRAMA DE CAPITAL GIRO PARA PRESERVA§¥O DE EMPRESA****
- **VSPRT09*-      99 OUTROS                                               ***
- **VSPRT17*---------------------------------------------------------------***
- **21 - RECOMNPILACAO BOOK - LIMITES                          ***
- **03  | T520Q6S    |  GRAVITY - DESCOMISSING VSAM        ***
- **VGRAVIT*             | T520Q6S    |  DESCONTINUAR MZV5002A              ***
- **VGRAVIT*             | T520Q6S    |  DATA-BASE                          ***
- **VSPRT74*---------------------------------------------------------------***
- **VSPRT74*  SPRINT 74 - RECOMPILAR BOOK LHCP3402 ANEXO 35 E 37           ***
- **VSPRT76*  SPRINT 76 -|CABRAL      |MELHORIAS:                           ***
- **VSPRT76*                          |ARQUIVO VAZIO 'STOP' O PROCESSAMENTO ***
- **MZ***
- **MOD   ***
- **VSPRT76*                          |SE ERRO , GERA RC = 1 ACIONA GESTOR  ***
- **VSPRT76*                          |GERA S2DQ0709 ARQ REJEITADOS GESTOR  ***
- **VSPRT76*----------------------------------------------------------------***
- **VSPRT77* SPRINT77 - INCLUIR TRATAMENTO DE TATICO PARA INFO ADIC 1701    ***
- **VSPRT77*----------------------------------------------------------------***
- **V      *================================================================***
- **V       ENVIRONMENT       DIVISION**
- **V       CONFIGURATION     SECTION**
- **V       SPECIAL-NAMES.    DECIMAL-POINT IS COMMA**
- **V       INPUT-OUTPUT      SECTION**
- **V           SELECT  E1DQ0705            ASSIGN  TO  E1DQ0705**
- **V           SELECT  S1DQ0705            ASSIGN  TO  S1DQ0705**
- **VSPRT76     SELECT  S2DQ0705            ASSIGN  TO  S2DQ0705**
- **VGRAV  *    SELECT  MZV5002E            ASSIGN  TO MZV5002E**
- **VGRAV  *            ORGANIZATION        INDEXED**
- **VGRAV  *            ACCESS              SEQUENTIAL**
- **VGRAV  *            RECORD KEY          CHAVE-5002**
- **VGRAV  *            FILE STATUS         FS-MZV5002E**
- **V       DATA    DIVISION**
- **V       FILE SECTION**
- **V      *     ARQUIVO DE OPERACOES MARCADAS COMPULSORIO - RECEBIDA DE**
- **V      *     ARQUIVO RECEBIDO DE RISCOS SOLVENCIA**
- **V       FD  E1DQ0705**
- **V           LABEL     RECORD        STANDARD**
- **V           BLOCK   CONTAINS        0     RECORDS**
- **V           RECORD    CONTAINS    260     CHARACTERS**
- **V           RECORDING MODE IS F**
- **V697665 01  REG-E1DQ0705          PIC  X(260)**
- **V      *     ARQUIVO DE OPERACOES MARCADAS COMPULSORIO - APOS VALIDACAO**
- **V       FD  S1DQ0705**
- **V       01  REG-S1DQ0705          PIC  X(260)**
- **VSPRT76*---------------------------------------------------------------***
- **V  !!  *     ARQUIVO DE OPERACOES REJEITADOS - ERROS**
- **V  !!  *---------------------------------------------------------------***
- **V  !!**
- **V  !!   FD  S2DQ0705**
- **V  !!       LABEL     RECORD        STANDARD**
- **V  !!       BLOCK   CONTAINS        0     RECORDS**
- **V  !!       RECORD    CONTAINS    260     CHARACTERS**
- **V  !!       RECORDING MODE IS F**
- **VSPRT76 01  REG-S2DQ0705          PIC  X(260)**
- **VGRAV  *---------------------------------------------------------------***
- **VGRAV  * ARQ COM INFORMACOES DE DATA BASE QUE ESTA SENDO EXECUTADO**
- **VGRAV  ***
- **VGRAV  *FD  MZV5002E**
- **VGRAV  *01  REG-MZCE5002**
- **VGRAV  *    ++INCLUDE MZCE5002**
- **V      *----------------------------------------------------------------***
- **V       WORKING-STORAGE   SECTION**
- **V       01  CT-CONTROLES**
- **V         05  FS-MZV5002E                    PIC 9(002)    VALUE ZEROS**
- **V         05  CT-FIM                         PIC X(001)    VALUE 'N'**
- **V         05  PGMNAME                        PIC X(008) VALUE 'LHAN0705'**
- **V         05  CT-MZ9CV001                    PIC X(008) VALUE 'MZ9CV001'**
- **V         05  CT-DRAM0018                    PIC X(008) VALUE 'DRAM0018'**
- **V697665   05  CT-DRAM0152                    PIC X(008) VALUE 'DRAM0152'**
- **V  ||     05  CT-DRAM0022                    PIC X(008) VALUE 'DRAM0022'**
- **V  ||     05  CT-DRAM0038                    PIC X(008) VALUE 'DRAM0038'**
- **V  ||     05  CT-LHBR0700                    PIC X(008) VALUE 'LHBR0700'**
- **V  ||     05  CT-2ASTER                      PIC X(002)    VALUE '**'**
- **V  ||     05  CT-MAIS                        PIC X(001)    VALUE '+'**
- **V697665   05  CT-HIFEN                       PIC X(001)    VALUE '-'**
- **V         05  STCODE                         PIC 9(002)    VALUE 99**
- **V         05  CT-INICIO                      PIC X(001)    VALUE 'S'**
- **V         05  CT-CANCELA                     PIC X(001)    VALUE 'N'**
- **V         05  CT-ERRO                        PIC X(001)    VALUE 'N'**
- **V         05  CT-SIM                         PIC X(001)    VALUE 'S'**
- **V         05  CT-NAO                         PIC X(001)    VALUE 'N'**
- **V         05  CT-MENS-ERRO                   PIC X(031)**
- **V                               VALUE 'REGISTRO REJEITADO'**
- **V         05  CT-MENS-OK                     PIC X(031)**
- **V                               VALUE 'REGISTRO VALIDO'**
- **V         05  CT-X-0                         PIC X(001)    VALUE '0'**
- **V         05  CT-X-1                         PIC X(001)    VALUE '1'**
- **V         05  CT-X-9                         PIC X(001)    VALUE '9'**
- **V         05  CT-00                          PIC 9(002)    VALUE 00**
- **V         05  CT-01                          PIC 9(002)    VALUE 01**
- **V         05  CT-02                          PIC 9(002)    VALUE 02**
- **V         05  CT-03                          PIC 9(002)    VALUE 03**
- **V         05  CT-04                          PIC 9(002)    VALUE 04**
- **V         05  CT-05                          PIC 9(002)    VALUE 05**
- **V         05  CT-06                          PIC 9(002)    VALUE 06**
- **V         05  CT-07                          PIC 9(002)    VALUE 07**
- **V         05  CT-08                          PIC 9(002)    VALUE 08**
- **V         05  CT-09                          PIC 9(002)    VALUE 09**
- **V         05  CT-10                          PIC 9(002)    VALUE 10**
- **V         05  CT-11                          PIC 9(002)    VALUE 11**
- **V         05  CT-12                          PIC 9(002)    VALUE 12**
- **V         05  CT-13                          PIC 9(002)    VALUE 13**
- **V         05  CT-14                          PIC 9(002)    VALUE 14**
- **V         05  CT-15                          PIC 9(002)    VALUE 15**
- **V         05  CT-16                          PIC 9(002)    VALUE 16**
- **V         05  CT-17                          PIC 9(002)    VALUE 17**
- **V         05  CT-18                          PIC 9(002)    VALUE 18**
- **V         05  CT-19                          PIC 9(002)    VALUE 19**
- **V         05  CT-20                          PIC 9(002)    VALUE 20**
- **V         05  CT-21                          PIC 9(002)    VALUE 21**
- **V         05  CT-22                          PIC 9(002)    VALUE 22**
- **VSPRT76 01  WS-CHAVES**
- **VSPRT76     02  WS-CHAVE-E1**
- **VSPRT76     05  E1-CD-ITF               PIC X(004)    VALUE SPACES**
- **VSPRT76     05  E1-NR-OPR-X             PIC X(033)    VALUE SPACES**
- **VSPRT76     05  E1-MOD-X                PIC X(004)    VALUE SPACES**
- **VSPRT76 01  WS-CHAVE-E1-ANT             PIC X(041)    VALUE SPACES**
- **V      *AREA DE BOOK DE ENTRADA**
- **V       01  WS-E1DQ0705**
- **V       ++INCLUDE LHCE0430**
- **V      *AREA DE BOOK DE SAIDA**
- **V697665*01  WS-S1DQ0705**
- **V697665*++INCLUDE LHCE0431**
- **V697665*----------------------------------------------------------------***
- **V  ||  * BOOKS**
- **V  ||  *----------------------------------------------------------------***
- **V  ||  ***
- **V  ||  *--- ANEXOS SCR3040**
- **V  ||       COPY LHCP3402**
- **V  ||  *--- LINKAGE LHBR0700**
- **V  ||   01  LI-LHCE0700**
- **V  ||       COPY LHCE0700**
- **V      * ACUMULADORES**
- **V       01  AC-ACUMULADORES**
- **V           03  AC-RG-LIDO                   PIC 9(009)    VALUE ZEROS**
- **V           03  AC-RG-ERRO                   PIC 9(009)    VALUE ZEROS**
- **V           03  AC-RG-VALI                   PIC 9(009)    VALUE ZEROS**
- **V           03  AC-RG-GRAV                   PIC 9(009)    VALUE ZEROS**
- **V      ****  AREA DE TRATAMENTO DE DATAS**
- **V       01 WK-DTCORRENTE                     PIC 9(006)**
- **V       01 FILLER            REDEFINES       WK-DTCORRENTE**
- **V          03 WK-AACORR                      PIC 9(002)**
- **V          03 WK-MMCORR                      PIC 9(002)**
- **V          03 WK-DDCORR                      PIC 9(002)**
- **V       01 WK-DTA-PROC                       PIC 9(008)**
- **V       01 FILLER            REDEFINES       WK-DTA-PROC**
- **V          03 WK-SEC-PROC                    PIC 9(002)**
- **V          03 WK-ANO-PROC                    PIC 9(002)**
- **V          03 WK-MES-PROC                    PIC 9(002)**
- **V          03 WK-DIA-PROC                    PIC 9(002)**
- **V       01  WK-DATA-BASE                PIC 9(008)    VALUE ZEROS**
- **VSPRT77 01  WK-DT-REESTRU-NUM**
- **VSPRT77     03   WK-AA-REESTRU-NUM          PIC  X(004)**
- **VSPRT77     03   WK-MM-REESTRU-NUM          PIC  X(002)**
- **VSPRT77     03   WK-DD-REESTRU-NUM          PIC  X(002)**
- **V       01  VARIAVEIS**
- **V         05  WK-TP-REG                   PIC X(001)     VALUE SPACES**
- **VECCOX *  05  WK-IND1                     PIC 9(003)     VALUE ZEROS**
- **VECCOX    05  WK-IND1                     PIC S9(4) COMP VALUE ZEROS**
- **V697665   05  WK-CONTRATO                 PIC X(033)**
- **V  ||     05  WK-TIPOSUB                  PIC 9(004)**
- **V  ||     05  WK-CD-RETORNO               PIC 9(002) OCCURS 30**
- **V  ||  *--- AREA PARA LHCP3402**
- **V  ||   01 WK-LHCP3402**
- **V  ||      03 WK-CD-MOD                      PIC 9(004) VALUE ZEROS**
- **V  ||      03 WK-CD-INFO-ADIC                PIC 9(004) VALUE ZEROS**
- **V  ||  *--- AREA PARA DRAM0152 - VALIDACAO DE DATA**
- **V  ||   01 WK-DRAM0152**
- **V  ||      03 WK-0152-DATA                   PIC 9(008)**
- **V  ||      03 WK-0152-RET                    PIC 9(001)**
- **V  ||  *--- AREA PARA DRAM0022 - VALIDACAO DE CPF**
- **V  ||   01 WK-DRAM0022**
- **V  ||      03 WK-0022-OPCAO                  PIC 9(001)**
- **V  ||      03 WK-0022-CPF                    PIC 9(011)**
- **V  ||  *--- AREA PARA DRAM0038 - VALIDACAO DE CNPJ**
- **V  ||   01 WK-DRAM0038**
- **V  ||      03 WK-0038-CNPJ                   PIC 9(014)**
- **V  ||      03 FILLER               REDEFINES WK-0038-CNPJ**
- **V  ||         05 WK-0038-RAIZ-FILIAL         PIC 9(012)**
- **V  ||         05 WK-0038-DIGITO              PIC X(002)**
- **V  ||  *---**
- **V  ||  *--- SWITCHES**
- **V  ||   01 SW-SWITCHES**
- **V  ||      05 SW-MODSUB                      PIC X(001) VALUE 'S'**
- **V  ||         88 SW-MODSUB-OK                           VALUE 'S'**
- **V  ||         88 SW-MODSUB-NOK                          VALUE 'N'**
- **V  ||      05 SW-TIPOSUB                     PIC X(001) VALUE 'S'**
- **V  ||         88 SW-TIPOSUB-OK                          VALUE 'S'**
- **V697665       88 SW-TIPOSUB-NOK                         VALUE 'N'**
- **CHAMAR A SUB-ROTINA 'MZ9CV001'**
- **VGRAV  *----------------------------------------------------------------***
- **VGRAV  *    AREA PARA MENSAGEM DE ERRO EM ACESSO A TABELA               ***
- **VGRAV   01         WS-MSG-TABELA**
- **VGRAV       03     FILLER               PIC  X(022) VALUE**
- **VGRAV              'ERRO MZ9CV001 TABELA '**
- **VGRAV       03     WS-TABELA            PIC  X(003)**
- **VGRAV       03     FILLER               PIC  X(005) VALUE   ' ACC '**
- **VGRAV       03      WS-ACC               PIC  X(001)**
- **VGRAV       03     FILLER               PIC  X(005) VALUE   ' RET '**
- **VGRAV       03     WS-STATUS            PIC  X(002)**
- **VGRAV       03     FILLER               PIC  X(005) VALUE   ' SQL '**
- **VGRAV       03     WS-SQLCODE           PIC  S9(005)**
- **VGRAV       03     FILLER               PIC  X(005) VALUE   ' ERR '**
- **VGRAV       03     WS-SQLERRT           PIC  9(005)**
- **VGRAV       03     FILLER               PIC  X(001) VALUE   ' '**
- **VGRAV       03     WS-SQLERRM           PIC  X(020)**
- **VGRAV**
- **V      *    AREA PARA COPY DOS BOOKS**
- **VGRAV  *--- DETALHE  MZV5002E**
- **VGRAV   01  REG-MZTC5001**
- **VGRAV   ++INCLUDE MZTC5001**
- **VGRAV  *================================================================***
- **VGRAV  *           AREAS DE SUBROTINA                                  ***
- **VGRAV   ++INCLUDE MZTCL000**
- **VGRAV   ++INCLUDE MZTCL040**
- **V      *   PROCESSAMENTO DO PROGRAMA**
- **V       PROCEDURE   DIVISION**
- **V       R000-PRINCIPAL                  SECTION**
- **V           PERFORM  R100-INICIO**
- **V           PERFORM  R200-PROCESSAMENTO UNTIL  CT-FIM EQUAL CT-SIM**
- **V           PERFORM  R900-FIM**
- **V      *    ROTINA  DE  INICIO                                         ***
- **V       R100-INICIO                     SECTION**
- **V           MOVE ZEROS TO AC-RG-LIDO**
- **V                         AC-RG-ERRO**
- **V                         AC-RG-VALI**
- **V                         AC-RG-GRAV**
- **V           DISPLAY '********************************************'**
- **V           DISPLAY '**         PROGRAMA LHAN0705              **'**
- **V           DISPLAY '**   VALIDACAO FISICA DO ARQUIVO DE       **'**
- **V           DISPLAY '**   ENTRADA - RECEBIDO DA AREA DE CAC    **'**
- **V           ACCEPT   WK-DTCORRENTE    FROM     DATE**
- **V           MOVE     WK-AACORR        TO       WK-ANO-PROC**
- **V           MOVE     WK-MMCORR        TO       WK-MES-PROC**
- **V           MOVE     WK-DDCORR        TO       WK-DIA-PROC**
- **V           IF       WK-AACORR        GREATER  50**
- **V                    MOVE   19        TO       WK-SEC-PROC**
- **V                    MOVE   20        TO       WK-SEC-PROC**
- **VGRAV  *    CHAMADA A ROTINA GEN¾RICA MZ9CV001 -      TABELA  V111      ***
- **VGRAV       MOVE  SPACES                  TO  CHAVEH-5001**
- **VGRAV       MOVE  ZEROS                   TO  TPREG-5001**
- **VGRAV       MOVE  ZEROS                   TO  ZEROS-5001**
- **VGRAV       MOVE  'S'                TO      MZL0-TIPOACC**
- **VGRAV       MOVE  MZTC5001           TO      MZL0-MZDT001**
- **VGRAV       CALL  CT-MZ9CV001        USING   MZTCL000**
- **VGRAV       IF    MZL0-CDRETORN   EQUAL           '00'**
- **VGRAV             MOVE  MZL0-MZDT001    TO  MZTC5001**
- **VGRAV             MOVE  DATA-BASE-5002  TO  WK-DATA-BASE**
- **VGRAV             DISPLAY '*-------------------------------------------*'**
- **VGRAV             DISPLAY '*    PROGRAMA LHAN0705 - CALL MZ - DATA BASE*'**
- **VGRAV             DISPLAY '*  *  DT BASE DO SIST**
- **VGRAV       ELSE**
- **VGRAV             MOVE  MZL0-TABELA        TO   WS-TABELA**
- **VGRAV             MOVE  MZL0-TIPOACC       TO   WS-ACC**
- **VGRAV             MOVE  MZL0-CDRETORN      TO   WS-STATUS**
- **VGRAV             MOVE  MZL0-SQLCODE       TO   WS-SQLCODE**
- **VGRAV             MOVE  MZL0-SQLERRM-TAM   TO   WS-SQLERRT**
- **VGRAV             MOVE  MZL0-SQLERRM-DATA  TO   WS-SQLERRM**
- **VGRAV             DISPLAY '*********************************************'**
- **VGRAV             DISPLAY '    PROGRAMA LHAN0705  -   CANCELADO         '**
- **VGRAV             DISPLAY '  '**
- **VGRAV             DISPLAY '      ERRO DE LEITURA DE TABELA         '**
- **VGRAV             DISPLAY '  '   WS-MSG-TABELA**
- **VGRAV             GO TO  R990-CANCELA**
- **VGRAV       END-IF**
- **V      *-------- ABERTURA DO ARQUIVO DE DATA BASE**
- **VGRAV  *    OPEN INPUT  MZV5002E**
- **VGRAV  *    IF  FS-MZV5002E  NOT EQUAL  '00' AND '97'**
- **VGRAV  *        DISPLAY '***********************************************'**
- **VGRAV  *        DISPLAY '      PROGRAMA LHAN0705  -   CANCELADO         '**
- **VGRAV  *        DISPLAY '  '**
- **VGRAV  *        DISPLAY '        ERRO NA ABERTURA DO VSAM MZV5002'**
- **VGRAV  *        DISPLAY '        FILE STATUS        -> ' FS-MZV5002E**
- **VGRAV  *        MOVE 'S'   TO  CT-CANCELA**
- **VGRAV  *        PERFORM  R990-CANCELA**
- **VGRAV  *    END-IF**
- **VGRAV  *-------- ACESSAR DATA BASE DO SISTEMA**
- **VGRAV  *    READ  MZV5002E**
- **VGRAV  *    IF  FS-MZV5002E  NOT EQUAL  '00'**
- **VGRAV  *        DISPLAY '        ERRO DE LEITURA DO HEADER MZV5002E'**
- **VGRAV  *    ELSE**
- **VGRAV  *      IF  CHAVE-5002  NOT EQUAL  ZEROS**
- **VGRAV  *        DISPLAY '        ARQUIVO MZV5002E SEM HEADER'**
- **VGRAV  *      ELSE**
- **VGRAV  *        MOVE  DATA-BASE-5002  TO  WK-DATA-BASE**
- **VGRAV  *        DISPLAY '*  DT BASE DO SIST**
- **VGRAV  *      END-IF**
- **V      *-------- ABERTURA OS ARQUIVOS**
- **V           OPEN INPUT  E1DQ0705**
- **V                OUTPUT S1DQ0705**
- **VSPRT76                 S2DQ0705**
- **V      *-------- LEITURA DO ARQUIVO DE ENTRADA**
- **V           PERFORM R110-LER-E1DQ0705**
- **VSPRT76*    IF CT-FIM    EQUAL   'S'**
- **VSPRT76*       GO TO     R100-EXIT**
- **VSPRT76*    END-IF**
- **VSPRT76     IF CT-FIM    EQUAL   'S'**
- **V  !!          DISPLAY '***********************************************'**
- **V  !!          DISPLAY '      PROGRAMA LHAN0709  -   CANCELADO         '**
- **V  !!          DISPLAY '                                               '**
- **V  !!          DISPLAY '   ARQUIVO REMESSA OPERACOES TATICO   VAZIO    '**
- **V  !!          DISPLAY '   ACIONAR GESTOR DO LH                        '**
- **V  !!          DISPLAY '   ARQUIVO VAZIO                               '**
- **V  !!          MOVE 'S'   TO  CT-CANCELA**
- **V  !!          PERFORM  R990-CANCELA**
- **VSPRT76     END-IF**
- **V      *-------- PRIMEIRO REGISTRO NAO E HEADER**
- **V           IF WK-TP-REG                NOT EQUAL CT-X-0**
- **V697665*       INITIALIZE LHCE0430-RETORNO**
- **V              PERFORM VARYING WK-IND1 FROM 1 BY 1**
- **V                UNTIL WK-IND1 GREATER 10**
- **V                 MOVE ZEROS        TO  LHCE0430-CD-RETORNO(WK-IND1)**
- **V              END-PERFORM**
- **V              MOVE CT-10           TO  LHCE0430-CD-RETORNO(01)**
- **V              MOVE CT-MENS-ERRO    TO  LHCE0430-TX-MENSAGEM**
- **V              ADD   CT-01          TO  AC-RG-ERRO**
- **V              MOVE  CT-SIM         TO  CT-ERRO**
- **VSPRT76        PERFORM  R600-GRAVA-SAIDA2-ERRO**
- **V              DISPLAY '***********************************************'**
- **V              DISPLAY '      PROGRAMA LHAN0705  -   CANCELADO         '**
- **V              DISPLAY '                                               '**
- **V              DISPLAY '        TESTE DE PRIMEIRO REGISTRO             '**
- **V              DISPLAY '        PRIMEIRO REGISTRO NAO E HEADER         '**
- **GESTOR  '**
- **V              MOVE 'S'   TO  CT-CANCELA**
- **V              PERFORM  R990-CANCELA**
- **V       R100-EXIT.     EXIT**
- **V      *    ROTINA PARA LEITURA DO ARQUIVO DE ENTRADA                  ***
- **V       R110-LER-E1DQ0705               SECTION**
- **V697665     READ  E1DQ0705 INTO LHCE0430-ENTRADA**
- **V             AT END**
- **V                 MOVE CT-SIM   TO  CT-FIM**
- **V           END-READ**
- **V           IF  CT-FIM  EQUAL  CT-NAO**
- **V               ADD          +1             TO  AC-RG-LIDO**
- **V               MOVE LHCE0430-TP-REG        TO  WK-TP-REG**
- **VSPRT76         MOVE LHCE0430-CD-ITF        TO  E1-CD-ITF**
- **VSPRT76         MOVE LHCE0430-NR-OPR-X      TO  E1-NR-OPR-X**
- **VSPRT76         MOVE LHCE0430-CD-MOD-CTR    TO  E1-MOD-X**
- **V       R110-EXIT.   EXIT**
- **V      *    ROTINA  DE  PROCESSAMENTO                                  ***
- **V       R200-PROCESSAMENTO              SECTION**
- **V697665     PERFORM   R201-REINCIALIZA**
- **V           EVALUATE  WK-TP-REG**
- **V               WHEN  CT-X-0**
- **V                     PERFORM  R210-VALIDA-HEADER**
- **V               WHEN  CT-X-9**
- **V                     PERFORM  R220-VALIDA-TRAILLER**
- **V               WHEN  OTHER**
- **V                     PERFORM  R230-VALIDA-DETALHE**
- **V           END-EVALUATE**
- **VSPRT76     MOVE WS-CHAVE-E1   TO   WS-CHAVE-E1-ANT**
- **V           IF CT-FIM  EQUAL CT-SIM AND WK-TP-REG  NOT EQUAL CT-X-9**
- **V              INITIALIZE LHCE0430-RETORNO**
- **V697665*       MOVE CT-10           TO  LHCE0430-CD-RETORNO(01)**
- **V              PERFORM  R600-GRAVA-SAIDA2-ERRO**
- **V       R200-EXIT.   EXIT**
- **V697665*---------------------------------------------------------------***
- **V  ||  * REINICIALIZA VARIAVEIS A CADA REGISTRO**
- **V  ||  *---------------------------------------------------------------***
- **V  ||   R201-REINCIALIZA**
- **V  ||  *--- AREA DE RETORNO**
- **V  ||       PERFORM VARYING WK-IND1 FROM 1 BY 1**
- **V  ||         UNTIL WK-IND1 GREATER 10**
- **V  ||         MOVE  ZEROS           TO  LHCE0430-CD-RETORNO(WK-IND1)**
- **V  ||       END-PERFORM**
- **V  ||**
- **V  ||       MOVE SPACES             TO  LHCE0430-TX-MENSAGEM**
- **V  ||  *--- AREA TEMPORARIA DE CONSISTENCIA**
- **V  ||         UNTIL WK-IND1 GREATER 30**
- **V  ||         MOVE  ZEROS           TO  WK-CD-RETORNO(WK-IND1)**
- **V  ||       SET  LHCE0700-CD-RET-OK TO  TRUE**
- **V  ||       SET  SW-MODSUB-OK       TO  TRUE**
- **V  ||       SET  SW-TIPOSUB-OK      TO  TRUE**
- **V  ||       MOVE CT-NAO             TO  CT-ERRO**
- **V  ||       MOVE CT-01              TO  WK-IND1**
- **V  ||       MOVE CT-MENS-OK         TO  LHCE0430-TX-MENSAGEM**
- **V  ||       MOVE ZEROS              TO  WK-0152-RET**
- **V  ||                                   WK-0022-OPCAO**
- **V  ||       MOVE SPACES             TO  WK-0038-DIGITO**
- **V697665***
- **V      *    ROTINA  DE  VALIDACAO FISICA DO ARQUIVO DE ENTRADA         ***
- **V       R210-VALIDA-HEADER                 SECTION**
- **V697665     MOVE     LHCE0430-DT-BSE    TO  WK-0152-DATA**
- **V697665     PERFORM  R300-VALIDA-DATA**
- **VSPRT76     IF  LHCE0430-DT-BSE  NOT EQUAL  WK-DATA-BASE**
- **V  !!           MOVE  CT-11             TO  WK-CD-RETORNO(WK-IND1)**
- **V  !!           ADD   CT-01             TO  WK-IND1**
- **V  !!           MOVE  CT-SIM            TO  CT-ERRO**
- **VSPRT76*--- VALIDACAO FINAL DO REGISTRO**
- **V  !!  *    QUANTIDADE MAXIMA DE ERROS NO ARQUIVO PARA USUARIO IGUAL A 10**
- **V  !!  ***
- **V  !!       IF CT-ERRO               EQUAL  CT-NAO**
- **V  !!          MOVE   CT-MENS-OK        TO  LHCE0430-TX-MENSAGEM**
- **V  !!          ADD    CT-01             TO  AC-RG-VALI**
- **V  !!          PERFORM  R500-GRAVA-SAIDA1-OK**
- **V  !!       ELSE**
- **V  !!          PERFORM VARYING WK-IND1 FROM 1 BY 1**
- **V  !!            UNTIL WK-IND1 GREATER 10**
- **V  !!             MOVE WK-CD-RETORNO(WK-IND1)**
- **V  !!                                   TO LHCE0430-CD-RETORNO(WK-IND1)**
- **V  !!          END-PERFORM**
- **V  !!          MOVE   CT-MENS-ERRO      TO  LHCE0430-TX-MENSAGEM**
- **V  !!          ADD    CT-01             TO  AC-RG-ERRO**
- **V  !!          PERFORM  R600-GRAVA-SAIDA2-ERRO**
- **V       R210-EXIT.   EXIT**
- **V      *    ROTINA  DE  VALIDACAO FISICA DO REGISTRO TRAILER           ***
- **V       R220-VALIDA-TRAILLER                SECTION**
- **V       R220-EXIT.   EXIT**
- **V       R230-VALIDA-DETALHE                SECTION**
- **V  ||  *--- VALIDACAO TIPO REGISTRO**
- **V           IF  LHCE0430-TP-REG        NOT NUMERIC**
- **V           OR  LHCE0430-TP-REG        NOT EQUAL CT-01**
- **V               MOVE  CT-10             TO  WK-CD-RETORNO(WK-IND1)**
- **V               MOVE  CT-SIM            TO  CT-ERRO**
- **V               ADD   CT-01             TO  WK-IND1**
- **V  ||  *--- VALIDACAO DATA BASE**
- **V  ||       MOVE     LHCE0430-DT-BSE    TO  WK-0152-DATA**
- **V  ||       PERFORM  R300-VALIDA-DATA**
- **V  ||  *--- VALIDACAO CODIGO INTERFACE**
- **V           IF  LHCE0430-CD-ITF      EQUAL SPACES**
- **V           OR  LHCE0430-CD-ITF      EQUAL LOW-VALUES**
- **V           OR  LHCE0430-CD-ITF      EQUAL HIGH-VALUES**
- **V697665         MOVE  CT-12             TO  WK-CD-RETORNO(WK-IND1)**
- **V  ||  *--- VALIDACAO TIPO PESSOA E NUMERO DOCUMENTO**
- **V  ||       EVALUATE LHCE0430-TP-PES**
- **V  ||           WHEN CT-01**
- **V  ||                MOVE  LHCE0430-CD-CIC     TO  WK-0022-CPF**
- **V  ||                MOVE  CT-02               TO  WK-0022-OPCAO**
- **V  ||                PERFORM  R305-VALIDA-CPF**
- **V  ||           WHEN CT-02**
- **V  ||                MOVE  LHCE0430-CD-CIC     TO  WK-0038-CNPJ**
- **V  ||                PERFORM  R310-VALIDA-CNPJ**
- **V  ||           WHEN OTHER**
- **V  ||                MOVE  CT-13               TO  WK-CD-RETORNO(WK-IND1)**
- **V  ||                ADD   CT-01               TO  WK-IND1**
- **V  ||                MOVE  CT-SIM              TO  CT-ERRO**
- **V  ||       END-EVALUATE**
- **V  ||  *--- VALIDACAO OPERACAO - CONTRATO**
- **V  ||       MOVE    LHCE0430-NR-OPR-X   TO  WK-CONTRATO**
- **V  ||       PERFORM R315-VALIDA-CONTRATO**
- **SUBMODALIDADE**
- **V  ||       MOVE    LHCE0430-CD-MOD-CTR TO  WK-CD-MOD**
- **V  ||       PERFORM R320-VALIDA-MODSUB**
- **MODALIDADE**
- **V  !!       IF  WS-CHAVE-E1   EQUAL     WS-CHAVE-E1-ANT**
- **V  !!           MOVE  CT-15             TO  WK-CD-RETORNO(WK-IND1)**
- **SUBTIPO INFORMACAO ADICIONAL**
- **V  ||       MOVE    LHCE0430-TP-SB-INFO TO  WK-CD-INFO-ADIC**
- **V  ||       PERFORM R325-VALIDA-TIPOSUB**
- **V  ||  *--- VALIDACAO COMBINACAO TIPO SUBTIPO CONTRA MOD**
- **V  ||  *    SE AS PROPRIAS ESTIVEREM OK**
- **V  ||       IF  SW-MODSUB-OK    AND     SW-TIPOSUB-OK**
- **V  ||           MOVE  CT-01             TO  LHCE0700-NR-OPCAO**
- **V  ||           MOVE  LHCE0430-TP-SB-INFO**
- **V  ||                                   TO  LHCE0700-TX-OP1-TIPOSUBTIPO**
- **V  ||           MOVE  LHCE0430-CD-MOD-CTR**
- **V  ||                                   TO  LHCE0700-TX-OP1-MODSUBMOD**
- **V  ||           IF  LHCE0430-TP-SB-INFO(1:2) EQUAL 18 OR 19**
- **V  ||               MOVE  '9999'**
- **V  ||           END-IF**
- **V  ||           CALL  CT-LHBR0700    USING  LI-LHCE0700**
- **VSPRT04         MOVE  ZEROS   TO  LHCE0700-CD-RET**
- **V  ||           IF  NOT   LHCE0700-CD-RET-OK**
- **V  ||               MOVE  CT-18         TO  WK-CD-RETORNO(WK-IND1)**
- **V  ||               ADD   CT-01         TO  WK-IND1**
- **V  ||               MOVE  CT-SIM        TO  CT-ERRO**
- **V  ||       END-IF**
- **V  ||  *--- VALIDACAO DE CAMPOS OBRIGATORIOS, POR TIPO DE INFO. ADIC**
- **V  ||  *    DE ACORDO COM ANEXO 26 DO LEIAUTE SCR3040**
- **V  ||       EVALUATE LHCE0430-TP-INFO-ADIC**
- **V  ||                PERFORM T001-TRATA-TIPO-01**
- **V  ||                PERFORM T002-TRATA-TIPO-02**
- **V  ||           WHEN CT-03**
- **V  ||                PERFORM T003-TRATA-TIPO-03**
- **V  ||           WHEN CT-04**
- **V  ||                PERFORM T004-TRATA-TIPO-04**
- **VSPRT04         WHEN CT-06**
- **VSPRT04              PERFORM T006-TRATA-TIPO-06**
- **V  ||           WHEN CT-07**
- **V  ||                PERFORM T007-TRATA-TIPO-07**
- **V  ||           WHEN CT-10**
- **V  ||                PERFORM T010-TRATA-TIPO-10**
- **V  ||           WHEN CT-11**
- **V  ||                PERFORM T011-TRATA-TIPO-11**
- **V  ||           WHEN CT-12**
- **V  ||                PERFORM T012-TRATA-TIPO-12**
- **VSPRT09**
- **VSPRT09         WHEN CT-14**
- **VSPRT09              PERFORM T014-TRATA-TIPO-14**
- **V  ||           WHEN CT-15**
- **V  ||                PERFORM T015-TRATA-TIPO-15**
- **VCORBAN         WHEN CT-16**
- **VCORBAN              PERFORM T015-TRATA-TIPO-15**
- **VSPRT77         WHEN CT-17**
- **VSPRT77              PERFORM T017-TRATA-TIPO-17**
- **VOLIVA1         WHEN CT-18**
- **VOLIVA1              PERFORM T018-TRATA-TIPO-18**
- **VOLIVA1         WHEN CT-19**
- **VOLIVA1              PERFORM T019-TRATA-TIPO-19**
- **V  ||                CONTINUE**
- **V697665     END-EVALUATE**
- **V  ||  *--- VALIDACAO FINAL DO REGISTRO**
- **V  ||  *    QUANTIDADE MAXIMA DE ERROS NO ARQUIVO PARA USUARIO IGUAL A 10**
- **V           IF CT-ERRO               EQUAL  CT-NAO**
- **V              MOVE   CT-MENS-OK        TO  LHCE0430-TX-MENSAGEM**
- **V              ADD    CT-01             TO  AC-RG-VALI**
- **VSPRT76        PERFORM  R500-GRAVA-SAIDA1-OK**
- **V697665        PERFORM VARYING WK-IND1 FROM 1 BY 1**
- **V  ||            UNTIL WK-IND1 GREATER 10**
- **V  ||             MOVE WK-CD-RETORNO(WK-IND1)**
- **V  ||                                   TO LHCE0430-CD-RETORNO(WK-IND1)**
- **V697665        END-PERFORM**
- **V              MOVE   CT-MENS-ERRO      TO  LHCE0430-TX-MENSAGEM**
- **V              ADD    CT-01             TO  AC-RG-ERRO**
- **V       R230-EXIT.   EXIT**
- **V  ||  * VALIDACAO DE DATA**
- **V  ||   R300-VALIDA-DATA**
- **V  ||       CALL CT-DRAM0152         USING  WK-DRAM0152**
- **V  ||       IF  WK-0152-RET      NOT EQUAL  ZEROS**
- **V  ||           MOVE  CT-11             TO  WK-CD-RETORNO(WK-IND1)**
- **V  ||           ADD   CT-01             TO  WK-IND1**
- **V  ||           MOVE  CT-SIM            TO  CT-ERRO**
- **V  ||  * VALIDACAO DE CPF**
- **V  ||   R305-VALIDA-CPF**
- **V  ||       CALL CT-DRAM0022         USING  WK-DRAM0022**
- **V  ||       IF  WK-0022-OPCAO    NOT EQUAL  ZEROS**
- **V  ||           MOVE  CT-14             TO  WK-CD-RETORNO(WK-IND1)**
- **V  ||  * VALIDACAO DE CNPJ**
- **V  ||   R310-VALIDA-CNPJ**
- **V  ||       CALL CT-DRAM0038         USING  WK-DRAM0038**
- **V  ||       IF  WK-0038-DIGITO       EQUAL  CT-2ASTER**
- **V  ||  * VALIDACAO DE CONTRATO**
- **V  ||   R315-VALIDA-CONTRATO**
- **V  ||       IF  WK-CONTRATO          EQUAL SPACES**
- **V  ||       OR  WK-CONTRATO          EQUAL LOW-VALUES**
- **V  ||       OR  WK-CONTRATO          EQUAL HIGH-VALUES**
- **V  ||           MOVE  CT-15             TO  WK-CD-RETORNO(WK-IND1)**
- **V  ||   R320-VALIDA-MODSUB**
- **V  ||       SEARCH ALL ANEXO-03**
- **V  ||           AT END**
- **V  ||              MOVE CT-16            TO  WK-CD-RETORNO(WK-IND1)**
- **V  ||              MOVE CT-SIM           TO  CT-ERRO**
- **V  ||              ADD  CT-01            TO  WK-IND1**
- **V  ||              SET  SW-MODSUB-NOK    TO  TRUE**
- **V  ||         WHEN TB-INDX-03(INDX03) EQUAL  WK-CD-MOD**
- **V  ||              CONTINUE**
- **V  ||   R325-VALIDA-TIPOSUB**
- **V  ||       SEARCH ALL ANEXO-26**
- **V  ||              MOVE CT-17            TO  WK-CD-RETORNO(WK-IND1)**
- **V  ||              SET  SW-TIPOSUB-NOK   TO  TRUE**
- **V  ||         WHEN TB-INDX-26(INDX26) EQUAL  WK-CD-INFO-ADIC**
- **V  ||  * VALIDACAO DE VALOR**
- **V  ||   R330-VALIDA-VALOR**
- **V  ||       IF LHCE0430-VL-INFO-ADIC-SINAL**
- **V  ||                             NOT EQUAL  CT-HIFEN AND SPACES AND**
- **V  ||                                        CT-MAIS**
- **V  ||              MOVE CT-19            TO  WK-CD-RETORNO(WK-IND1)**
- **V  ||       IF LHCE0430-VL-INFO-ADIC    NOT NUMERIC**
- **V  ||       OR LHCE0430-VL-INFO-ADIC  EQUAL ZEROS**
- **V  ||  * VALIDACAO DE PERCENTUAL**
- **V  ||   R335-VALIDA-PERCENTUAL**
- **V  ||       IF LHCE0430-PC-INFO-ADIC-SINAL**
- **V  ||       IF LHCE0430-PC-INFO-ADIC    NOT NUMERIC**
- **V  ||       OR LHCE0430-PC-INFO-ADIC  EQUAL ZEROS**
- **V  ||  * VALIDACAO CAMPO CD-INFO-ADIC**
- **V  ||   R340-VALIDA-CD-INFO-ADIC**
- **V  ||       IF  LHCE0430-CD-INFO-ADIC EQUAL SPACES**
- **V  ||       OR  LHCE0430-CD-INFO-ADIC EQUAL LOW-VALUES**
- **V  ||       OR  LHCE0430-CD-INFO-ADIC EQUAL HIGH-VALUES**
- **V  ||           MOVE  CT-19              TO  WK-CD-RETORNO(WK-IND1)**
- **V  ||           MOVE  CT-SIM             TO  CT-ERRO**
- **V  ||           ADD   CT-01              TO  WK-IND1**
- **V      * ROTINA DE GRAVACAO DO ARQUIVO DE SAIDA1 - OK                  ***
- **VSPRT76 R500-GRAVA-SAIDA1-OK            SECTION**
- **V           ADD      CT-01        TO    AC-RG-GRAV**
- **V697665     WRITE  REG-S1DQ0705  FROM WS-E1DQ0705**
- **V       R500-EXIT.    EXIT**
- **V  !!  * ROTINA DE GRAVACAO DO ARQUIVO DE SAIDA 2 - ERRO               ***
- **V  !!   R600-GRAVA-SAIDA2-ERRO          SECTION**
- **V  !!       WRITE  REG-S2DQ0705  FROM WS-E1DQ0705**
- **VSPRT76 R600-EXIT.    EXIT**
- **V      *    ROTINA  DE  FINALIZACAO                                    ***
- **V       R900-FIM                        SECTION**
- **V           CLOSE E1DQ0705**
- **V                 S1DQ0705**
- **VSPRT76           S2DQ0705**
- **VGRAV  *          MZV5002E**
- **V           DISPLAY '***********************************************'**
- **V           DISPLAY '**      TERMINO DO PROGRAMA LHAN0705         **'**
- **V           DISPLAY '**                                           **'**
- **V           DISPLAY '** REG.  LIDOS     E1DQ0705  -> ' AC-RG-LIDO**
- **V           DISPLAY '** REG.  VALIDOS             -> ' AC-RG-VALI**
- **V           DISPLAY '** REG.  ERROS               -> ' AC-RG-ERRO**
- **V           DISPLAY '** REG.  GRAVADOS  S1DQ0705  -> ' AC-RG-VALI**
- **VSPRT76     DISPLAY '** REG.  GRAVADOS  S2DQ0705  -> ' AC-RG-ERRO**
- **V           DISPLAY '   PROGRAMA EXECUTADO COM SUCESSO              '**
- **VSPRT76     IF  AC-RG-ERRO  EQUAL ZEROS**
- **V  !!           MOVE  ZEROS       TO  RETURN-CODE**
- **V  !!           MOVE  CT-01       TO  RETURN-CODE**
- **V  !!           DISPLAY '***********************************************'**
- **V  !!           DISPLAY '**  INCONSITENCIA NO MOVIMENTO DO TATICO  !! **'**
- **V  !!           DISPLAY '**  SCHEDULAGEM FAVOR ACIONAR O RESPONSAVEL  **'**
- **CORRECAO DO ARQUIVO*'**
- **V  !!           DISPLAY '**  E REENVIO AO LH**
- **V       R999-EXIT.  EXIT**
- **V      *    ROTINA  DE  CANCELAMENTO  DO  SISTEMA                      ***
- **V       R990-CANCELA                    SECTION**
- **V           CALL  CT-DRAM0018              USING     PGMNAME      STCODE**
- **V  ||  * SECTIONS DE TRATAMENTO E VALIDACAO DE CONTEUDO DE CAMPOS POR**
- **V  ||  * TIPO DE INFORMACAO ADICIONAL**
- **V  ||  * OBS**
- **V  ||  *       ESTA PREVISTO CPF**
- **V  ||  *       POR ENQUANTO, AREA GESTORA NAO PREENCHE NO ARQUIVO TATICO**
- **V  ||  *       O CAMPO LHCE0430-ID1-TP-PES, ASSUME SEMPRE CNPJ**
- **V  ||  * TRATAMENTO TIPO 01**
- **V  ||   T001-TRATA-TIPO-01**
- **V  ||       MOVE    LHCE0430-CD1-DATA        TO  WK-0152-DATA**
- **V  ||       PERFORM R300-VALIDA-DATA**
- **V  ||       IF  LHCE0430-SB-INFO-ADIC NOT EQUAL  CT-05**
- **V  ||           MOVE    LHCE0430-ID2-CNPJ    TO  WK-0038-CNPJ**
- **V  ||           PERFORM R310-VALIDA-CNPJ**
- **V  ||       PERFORM R330-VALIDA-VALOR**
- **V  ||       PERFORM R335-VALIDA-PERCENTUAL**
- **V  ||  * TRATAMENTO TIPO 02**
- **V  ||   T002-TRATA-TIPO-02**
- **V  ||       MOVE    LHCE0430-ID2-CNPJ        TO  WK-0038-CNPJ**
- **V  ||       PERFORM R310-VALIDA-CNPJ**
- **V  ||  * TRATAMENTO TIPO 03**
- **V  ||   T003-TRATA-TIPO-03**
- **V  ||       MOVE    CT-03                    TO  WK-CD-RETORNO(WK-IND1)**
- **V  ||       ADD     CT-01                    TO  WK-IND1**
- **V  ||       MOVE    CT-SIM                   TO  CT-ERRO**
- **V  ||  * TRATAMENTO TIPO 04**
- **V  ||   T004-TRATA-TIPO-04**
- **V  ||       EVALUATE LHCE0430-SB-INFO-ADIC**
- **V  ||  * 0401: SE SITUACAO = 1 ENTAO CD-INFO =  SPACES**
- **V  ||  *       SENAO                 CD-INFO <> SPACES**
- **V  ||                EVALUATE LHCE0430-ID1-SITUACAO**
- **V  ||                    WHEN CT-X-1**
- **V  ||                         IF LHCE0430-CD-INFO-ADIC NOT EQUAL  SPACES**
- **V  ||                            MOVE  CT-19                  TO**
- **V  ||                                  WK-CD-RETORNO(WK-IND1)**
- **V  ||                            ADD   CT-01                  TO  WK-IND1**
- **V  ||                            MOVE  CT-SIM                 TO  CT-ERRO**
- **V  ||                         END-IF**
- **V  ||                    WHEN SPACES**
- **V  ||                         PERFORM R340-VALIDA-CD-INFO-ADIC**
- **V  ||                    WHEN OTHER**
- **V  ||                         MOVE  CT-19                     TO**
- **V  ||                               WK-CD-RETORNO(WK-IND1)**
- **V  ||                         ADD   CT-01                     TO  WK-IND1**
- **V  ||                         MOVE  CT-SIM                    TO  CT-ERRO**
- **V  ||                END-EVALUATE**
- **V  ||           WHEN CT-05**
- **V  ||           WHEN CT-06**
- **V  ||                PERFORM R340-VALIDA-CD-INFO-ADIC**
- **V  ||                IF  LHCE0430-SB-INFO-ADIC  NOT EQUAL CT-03**
- **V  ||                    MOVE    LHCE0430-ID1-DATA     TO WK-0152-DATA**
- **V  ||                    PERFORM R300-VALIDA-DATA**
- **V  ||                END-IF**
- **VSPRT04*---------------------------------------------------------------***
- **VSPRT04* TRATAMENTO TIPO 06**
- **VSPRT04 T006-TRATA-TIPO-06**
- **VSPRT04**
- **VSPRT04***
- **VSPRT04     IF  LHCE0430-CD-INFO-ADIC EQUAL SPACES**
- **VSPRT04     OR  LHCE0430-CD-INFO-ADIC EQUAL LOW-VALUES**
- **VSPRT04     OR  LHCE0430-CD-INFO-ADIC EQUAL HIGH-VALUES**
- **VSPRT04     OR  LHCE0430-CD-INFO-ADIC(1:2)  NOT EQUAL '01' AND '02'**
- **VSPRT04         MOVE  CT-20              TO  WK-CD-RETORNO(WK-IND1)**
- **VSPRT04         MOVE  CT-SIM             TO  CT-ERRO**
- **VSPRT04         ADD   CT-01              TO  WK-IND1**
- **VSPRT04     END-IF**
- **VSPRT04     IF  LHCE0430-ID-INFO-ADIC EQUAL SPACES**
- **VSPRT04     OR  LHCE0430-ID-INFO-ADIC EQUAL LOW-VALUES**
- **VSPRT04     OR  LHCE0430-ID-INFO-ADIC EQUAL HIGH-VALUES**
- **VSPRT04         MOVE  CT-21              TO  WK-CD-RETORNO(WK-IND1)**
- **V  ||  * TRATAMENTO TIPO 07**
- **V  ||   T007-TRATA-TIPO-07**
- **V  ||  * TRATAMENTO TIPO 10**
- **V  ||   T010-TRATA-TIPO-10**
- **V           DISPLAY  'TIPO-10 ' LHCE0430-ID2-CNPJ ' ' WK-0038-CNPJ**
- **V           DISPLAY  'TIPO-10   WK-DRAM0038 ' WK-DRAM0038**
- **V           DISPLAY  'R310       WK-DRAM0038 ' WK-DRAM0038**
- **V           DISPLAY  'R310    '  WK-0038-RAIZ-FILIAL ' ' WK-0038-DIGITO**
- **V  ||  * TRATAMENTO TIPO 11**
- **V  ||   T011-TRATA-TIPO-11**
- **V  ||       PERFORM R340-VALIDA-CD-INFO-ADIC**
- **V  ||  * TRATAMENTO TIPO 12**
- **V  ||   T012-TRATA-TIPO-12**
- **V  ||                MOVE    LHCE0430-CD1-DATA      TO  WK-0152-DATA**
- **V  ||                PERFORM R300-VALIDA-DATA**
- **V  ||                MOVE    LHCE0430-CD-MOD-CTR    TO  WK-CD-MOD**
- **V  ||                PERFORM R320-VALIDA-MODSUB**
- **V  ||                PERFORM R330-VALIDA-VALOR**
- **V  ||                PERFORM R335-VALIDA-PERCENTUAL**
- **V  ||                MOVE    LHCE0430-CD1-CONTRATO  TO  WK-CONTRATO**
- **V  ||                PERFORM R315-VALIDA-CONTRATO**
- **V  ||                MOVE    LHCE0430-ID2-CNPJ      TO  WK-0038-CNPJ**
- **V  ||                PERFORM R310-VALIDA-CNPJ**
- **VSPRT09*---------------------------------------------------------------***
- **VSPRT09* TRATAMENTO TIPO 14**
- **VSPRT09 T014-TRATA-TIPO-14**
- **VSPRT09     EVALUATE LHCE0430-SB-INFO-ADIC**
- **VSPRT09         WHEN CT-08**
- **VSPRT09           IF  LHCE0430-ID-INFO-ADIC EQUAL SPACES**
- **VSPRT09           OR  LHCE0430-ID-INFO-ADIC EQUAL LOW-VALUES**
- **VSPRT09           OR  LHCE0430-ID-INFO-ADIC EQUAL HIGH-VALUES**
- **VSPRT09           OR  LHCE0430-ID-INFO-ADIC(1:2)  NOT EQUAL '01' AND '02'**
- **VSPRT09                                                 AND '03' AND '04'**
- **VSPRT74                                                 AND '05' AND '06'**
- **VSPRT74                                                 AND '07' AND '08'**
- **VSPRT74                                                 AND '09' AND '10'**
- **VSPRT09                                                 AND '99'**
- **VSPRT09             MOVE  CT-22              TO  WK-CD-RETORNO(WK-IND1)**
- **VSPRT09             MOVE  CT-SIM             TO  CT-ERRO**
- **VSPRT09             ADD   CT-01              TO  WK-IND1**
- **VSPRT09            END-IF**
- **VSPRT09         WHEN OTHER**
- **VSPRT09             CONTINUE**
- **VSPRT09     END-EVALUATE**
- **VSPRT09***
- **V  ||  * TRATAMENTO TIPO 15**
- **V  ||   T015-TRATA-TIPO-15**
- **V  ||       EVALUATE LHCE0430-CD1-SITUACAO**
- **V  ||           WHEN CT-X-1**
- **2014**
- **V  ||  * PASSOU A PERMITIR PREENCHIMENTO DO CNPJ MESMO QUANDO SIT=1**
- **V  ||  * POR ISSO, ACIMA ESTAH CONTINUE E ABAIXO INIBIDO**
- **V  ||  *             IF LHCE0430-ID2-CNPJ  NOT EQUAL  ZEROS**
- **V  ||  *                MOVE  CT-19            TO  WK-CD-RETORNO(WK-IND1)**
- **V  ||  *                ADD   CT-01            TO  WK-IND1**
- **V  ||  *                MOVE  CT-SIM           TO  CT-ERRO**
- **V  ||  *             END-IF**
- **V  ||           WHEN SPACES**
- **V  ||                MOVE    LHCE0430-ID2-CNPJ TO  WK-0038-CNPJ**
- **V  ||                MOVE  CT-19               TO  WK-CD-RETORNO(WK-IND1)**
- **V  ||  * TRATAMENTO TIPO 17**
- **VSPRT77 T017-TRATA-TIPO-17**
- **VSPRT77**
- **V      *    REESTRUTURA§¥O - INF ADICIONAL 1701**
- **V           IF LHCE0430-SB-INFO-ADIC  NOT EQUAL 01**
- **VSPRT77        MOVE  CT-17              TO  WK-CD-RETORNO(WK-IND1)**
- **VSPRT77        MOVE  CT-SIM             TO  CT-ERRO**
- **VSPRT77        ADD   CT-01              TO  WK-IND1**
- **VSPRT77     ELSE**
- **VSPRT77        IF   LHCE0430-CD2-DATA-ANO  NOT NUMERIC   OR**
- **VSPRT77             LHCE0430-CD2-DATA-ANO  EQUAL ZEROS   OR**
- **VSPRT77             LHCE0430-CD2-DATA-MES  NOT NUMERIC   OR**
- **VSPRT77             LHCE0430-CD2-DATA-MES  EQUAL ZEROS   OR**
- **VSPRT77             LHCE0430-CD2-DATA-DIA  NOT NUMERIC   OR**
- **VSPRT77             LHCE0430-CD2-DATA-DIA  EQUAL ZEROS   OR**
- **VSPRT77             LHCE0430-CD2-BARRA1    NOT EQUAL '-' OR**
- **VSPRT77             LHCE0430-CD2-BARRA2    NOT EQUAL '-'**
- **VSPRT77             MOVE  CT-11              TO  WK-CD-RETORNO(WK-IND1)**
- **VSPRT77             MOVE  CT-SIM             TO  CT-ERRO**
- **VSPRT77             ADD   CT-01              TO  WK-IND1**
- **VSPRT77        ELSE**
- **VSPRT77             MOVE LHCE0430-CD2-DATA-ANO   TO    WK-AA-REESTRU-NUM**
- **VSPRT77             MOVE LHCE0430-CD2-DATA-MES   TO    WK-MM-REESTRU-NUM**
- **VSPRT77             MOVE LHCE0430-CD2-DATA-DIA   TO    WK-DD-REESTRU-NUM**
- **VSPRT77             MOVE WK-DT-REESTRU-NUM         TO WK-0152-DATA**
- **VSPRT77             CALL  CT-DRAM0152  USING  WK-DRAM0152**
- **VSPRT77             IF  WK-0152-RET  NOT EQUAL 0**
- **VSPRT77                 MOVE  CT-11            TO  WK-CD-RETORNO(WK-IND1)**
- **VSPRT77                 MOVE  CT-SIM             TO  CT-ERRO**
- **VSPRT77                 ADD   CT-01              TO  WK-IND1**
- **VSPRT77             END-IF**
- **VSPRT77        END-IF**
- **VSPRT77        IF LHCE0430-ID1-MOTIVO          NOT EQUAL SPACES AND**
- **VSPRT77           LHCE0430-ID1-MOTIVO          NOT EQUAL ZEROS  AND**
- **VSPRT77           LHCE0430-ID1-MOTIVO          NOT EQUAL '01'   AND**
- **VSPRT77           LHCE0430-ID1-MOTIVO          NOT EQUAL '02'**
- **VSPRT77              MOVE  CT-19            TO  WK-CD-RETORNO(WK-IND1)**
- **VSPRT77              MOVE  CT-SIM             TO  CT-ERRO**
- **VSPRT77              ADD   CT-01              TO  WK-IND1**
- **VSPRT77     END-IF**
- **VSPRT77***
- **V  ||  * TRATAMENTO TIPO 18**
- **V  ||   T018-TRATA-TIPO-18**
- **V  ||   T019-TRATA-TIPO-19**
- **V  ||       IF LHCE0430-SB-INFO-ADIC EQUAL 99**
- **V  ||          PERFORM R340-VALIDA-CD-INFO-ADIC**
- **VMEMBER NAME  LHAN0706**
- **V       PROGRAM-ID.    LHAN0706**
- **V       AUTHOR.        T520Q6S**
- **V      **OBJETIVO: CRIAR REGISTRO DE INFORMACAO ADICIONAL TIPO 14      ***
- **V      *           PARA OPERACOES COM BENEFICIO DO COMPULSORIO         ***
- **V      *           INFORMADOS EM ARQUIVO GERADO POR RISCOS SOLVENCIA   ***
- **V      * ARQUIVOS:                                                     ***
- **V      *  INPUT                                                        ***
- **V      *   DDNAME        DESC                   BOOK                   ***
- **V      *  E1DQ0706   -  MOVTO RECEBIDO ORIGEM   LHCE0400               ***
- **V697665*  E2DQ0706   -  MOVTO RECEBIDO CONNECT  LHCE0430               ***
- **V      *  OUTPUT                                                       ***
- **V      *  S1DQ0706   -  MOVTO FORMATADO OK      LHCE0400               ***
- **V697665*  S2DQ0706   -  MOVTO CONNECT - RETORNO LHCE0430               ***
- **V      *                   M A N U T E N C A O                         ***
- **V      *   DATA    USUARIO    DESCRICAO                                ***
- **VV001  * 12052014  ROBERTO    ACEITAR E2DQ0706 VAZIO                   ***
- **V697665* 22092014  MARCELLO   OPERACOES DESCONSIGNADAS                 ***
- **V  ||  *                      - UNIFICACAO BOOKS LHCE0430 E LHCE0431   ***
- **V  ||  *                      - MATCH ENTRE ORIGENS E TATICO INFO ADIC**
- **V  ||  *                        - PREVALECE DA ORIGEM                  ***
- **SUBTIPO CONTRA NATUREZA ***
- **V  ||  *                      - TEMPORARIO: "-" NA POSICAO 100 DO      ***
- **V  ||  *                        CAMPO LHCE0400-TX-INFO-ADIC PARA INDI- ***
- **V697665*                        CAR QUE A ORIGEM E DO TATICO           ***
- **VCORBAN* 21102016  ROBERTO    PROJ INCL CORRESP BANCARIO NO CADOC3040  ***
- **VCORBAN*                      TP-INFO=16,SB-INFO=01,ID-INFO=CNPJ       ***
- **V1350  *   072019  ADELMO     INFO ADIC PARA MOD 1350                 ***
- **VSPRT04*   100520  ADELMO     INFO ADIC PARA MOD 06XX                 ***
- **VSPRT74*   300424  CABRAL     INFO ADIC = 24 - RWA                    ***
- **VSPRT77*   240724  ADELMO     INFO ADIC PARA MOD 1701                 ***
- **V           SELECT  E1DQ0706            ASSIGN  TO  E1DQ0706**
- **V           SELECT  E2DQ0706            ASSIGN  TO  E2DQ0706**
- **V           SELECT  S1DQ0706            ASSIGN  TO  S1DQ0706**
- **V           SELECT  S2DQ0706            ASSIGN  TO  S2DQ0706**
- **V      * ARQ COM OPERACOES DE RISCO A SEREM FORMATADAS**
- **V       FD  E1DQ0706**
- **V           LABEL     RECORD        IS              STANDARD**
- **V           BLOCK     CONTAINS        0             RECORDS**
- **V           RECORD    CONTAINS      550             CHARACTERS**
- **V       01  REG-E1DQ0706               PIC X(550)**
- **V      * ARQ COM OPERACOES DE RISCO A SEREM FORMATADAS ADICIONAL 14**
- **V       FD  E2DQ0706**
- **V697665     RECORD    CONTAINS      260             CHARACTERS**
- **V       01  REG-E2DQ0706                PIC X(260)**
- **V      * ARQ**
- **V       FD  S1DQ0706**
- **V           BLOCK     CONTAINS        0               RECORDS**
- **V       01  REG-S1DQ0706                 PIC X(550)**
- **V       FD  S2DQ0706**
- **V       01  REG-S2DQ0706                 PIC X(260)**
- **V       01  WS-LHCE0400**
- **V           ++INCLUDE LHCE0400**
- **V       01  WS-LHCE0400-AUX**
- **V697665 01  WS-LHCE0430**
- **V  ||       ++INCLUDE LHCE0430**
- **SUB E NAT**
- **V697665     COPY LHCE0700**
- **V       01  WS-VARIAVEIS**
- **V           05  FS-MZV5002E             PIC 9(002)    VALUE ZEROS**
- **V           05  STCODE                      PIC 9(002)    VALUE 99**
- **V           05  WS-JOBNAME              PIC X(008)    VALUE SPACES**
- **V           05  WDT-BSE                 PIC 9(008)    VALUE ZEROS**
- **V           05  PGMNAME                 PIC X(008)    VALUE 'LHAN0706'**
- **V           05  CT-DRAM0018             PIC X(008)    VALUE 'DRAM0018'**
- **V697665     05  CT-LHBR0700             PIC X(008)    VALUE 'LHBR0700'**
- **V  ||       05  CT-SA                   PIC X(002)    VALUE 'SA'**
- **V  ||       05  CT-X-1                  PIC X(001)    VALUE '1'**
- **V  ||       05  CT-01                   PIC 9(002)    VALUE 01**
- **V  ||       05  CT-02                   PIC 9(002)    VALUE 02**
- **V  ||       05  CT-03                   PIC 9(002)    VALUE 03**
- **V  ||       05  CT-04                   PIC 9(002)    VALUE 04**
- **V  ||       05  CT-05                   PIC 9(002)    VALUE 05**
- **V  ||       05  CT-06                   PIC 9(002)    VALUE 06**
- **V  ||       05  CT-07                   PIC 9(002)    VALUE 07**
- **V  ||       05  CT-08                   PIC 9(002)    VALUE 08**
- **V  ||       05  CT-09                   PIC 9(002)    VALUE 09**
- **V  ||       05  CT-10                   PIC 9(002)    VALUE 10**
- **V  ||       05  CT-11                   PIC 9(002)    VALUE 11**
- **V  ||       05  CT-12                   PIC 9(002)    VALUE 12**
- **V  ||       05  CT-13                   PIC 9(002)    VALUE 13**
- **V  ||       05  CT-14                   PIC 9(002)    VALUE 14**
- **V  ||       05  CT-15                   PIC 9(002)    VALUE 15**
- **V  ||       05  CT-16                   PIC 9(002)    VALUE 16**
- **V  ||       05  CT-17                   PIC 9(002)    VALUE 17**
- **V  ||       05  CT-18                   PIC 9(002)    VALUE 18**
- **V  ||       05  CT-19                   PIC 9(002)    VALUE 19**
- **V  ||       05  CT-20                   PIC 9(002)    VALUE 20**
- **VSPRT74     05  CT-24                   PIC 9(002)    VALUE 24**
- **V697665     05  CT-HIFEN                PIC X(001)    VALUE '-'**
- **V           05  WK-FIM-E1               PIC X(001)    VALUE 'N'**
- **V           05  WK-FIM-E2               PIC X(001)    VALUE 'N'**
- **V           05  WK-DESPREZA-E2          PIC X(001)    VALUE 'N'**
- **V           05  CT-SIM                  PIC X(001)    VALUE 'S'**
- **V697665*    05  WS-GRAVA-S1DQ0706       PIC X(001)    VALUE 'N'**
- **V697665     05  WS-CD-NAT-CTR           PIC 9(002)**
- **VCORBAN     05  WS-CNPJ-CORRESP**
- **VCORBAN      10 WS-CNPJ-ZERO            PIC 9(001)**
- **VCORBAN      10 WS-CNPJ-14              PIC 9(014)**
- **VCORBAN     05  WS-CNPJ-CORRESP-N REDEFINES WS-CNPJ-CORRESP**
- **VCORBAN                                 PIC 9(015)**
- **V       01  WS-CHAVES**
- **V           02  WS-CHAVE-E1**
- **V             05  E1-CD-ITF               PIC X(004)    VALUE SPACES**
- **V             05  E1-NR-OPR-X             PIC X(033)    VALUE SPACES**
- **V             05  E1-MOD-X                PIC X(002)    VALUE SPACES**
- **V           02  WS-QUEBRA-E1              PIC X(039)**
- **V           02  WS-CHAVE-E2**
- **V             05  E2-CD-ITF               PIC X(004)    VALUE SPACES**
- **V             05  E2-NR-OPR-X             PIC X(033)    VALUE SPACES**
- **V             05  E2-MOD-X                PIC X(002)    VALUE SPACES**
- **V697665     02  WS-QUEBRA-E2              PIC X(039)**
- **V           03  AC-LIDOS-E1             PIC 9(009)    VALUE ZEROS**
- **V           03  AC-LIDOS-E2             PIC 9(009)    VALUE ZEROS**
- **V           03  AC-ERRADOS-E2           PIC 9(009)    VALUE ZEROS**
- **V           03  AC-SEMCORR-E2           PIC 9(009)    VALUE ZEROS**
- **V           03  AC-ORIGEM-E2            PIC 9(009)    VALUE ZEROS**
- **V           03  AC-INCLUIDO-S1          PIC 9(009)    VALUE ZEROS**
- **V           03  AC-GRAVADOS-S1          PIC 9(009)    VALUE ZEROS**
- **V           03  AC-GRAVADOS-S2          PIC 9(009)    VALUE ZEROS**
- **V1350       03  AC-FALTA-1350           PIC 9(009)    VALUE ZEROS**
- **V697665     03  AC-NATINCO-E2           PIC 9(009)    VALUE ZEROS**
- **V  ||       03  AC-TP-QT                PIC S9(04) COMP  VALUE ZEROS**
- **V  ||   01  ME-MENSAGENS**
- **V  ||  *               ----+----1----+----2----+----3----+----4**
- **V  ||       03  ME-INFO-OK              PIC X(040)**
- **V  ||           VALUE 'OK - INFO. GERADA '**
- **V  ||       03  ME-INFO-ORIG            PIC X(040)**
- **V  ||           VALUE 'INFO ADIC DA ORIGEM'**
- **V  ||       03  ME-INFO-SCORR           PIC X(040)**
- **V  ||           VALUE 'NOK-SEM CORRESPONDENTE'**
- **V  ||       03  ME-INFO-SCORR-CLI-MOD   PIC X(040)**
- **MOD'**
- **V  ||       03  ME-INFO-NAT-INVAL       PIC X(040)**
- **V  ||           VALUE 'INFO ADIC NATUREZA INVALIDA'**
- **V  ||   01  SW-SWITCHES**
- **V  ||       03  SW-DOC-MODSUB           PIC X(001)    VALUE 'S'**
- **V  ||           88  SW-DOC-MODSUB-SIM                 VALUE 'S'**
- **V  ||           88  SW-DOC-MODSUB-NAO                 VALUE 'N'**
- **V  ||   01  TB-INTERNA**
- **V  ||       05  TB-TIPO-SUB**
- **V  ||           10  TB-GR-TIPO-SUB   OCCURS 20 TIMES INDEXED BY IN-TP**
- **V697665             15  TB-EL-TP        PIC X(004)**
- **V      ***** AREAS PARA DISPLAY DE VERSAO DO PROGRAMA**
- **V       01          WS-CURRENT-DATE     PIC  X(19)**
- **V       01          FILLER  REDEFINES  WS-CURRENT-DATE**
- **V         03        WS-SYSTEM-DATE      PIC  9(08)**
- **V         03        FILLER  REDEFINES  WS-SYSTEM-DATE**
- **V           05      WS-SYSTEM-DATE-YYYY PIC  9(04)**
- **V           05      WS-SYSTEM-DATE-MM   PIC  9(02)**
- **V           05      WS-SYSTEM-DATE-DD   PIC  9(02)**
- **V         03        WS-SYSTEM-TIME      PIC  9(07)**
- **V         03        FILLER  REDEFINES  WS-SYSTEM-TIME**
- **V           05      WS-SYSTEM-TIME-HH   PIC  9(02)**
- **V           05      WS-SYSTEM-TIME-MM   PIC  9(02)**
- **V           05      WS-SYSTEM-TIME-SS   PIC  9(02)**
- **V           05      WS-SYSTEM-TIME-T    PIC  9(01)**
- **V         03        FILLER              PIC  X(04)**
- **'**
- **V       01          FILLER  REDEFINES  WS-DATA-SIST**
- **V         03        WS-DATA-SIST-DD     PIC  9(02)**
- **V         03        FILLER              PIC  X(01)**
- **V         03        WS-DATA-SIST-MM     PIC  9(02)**
- **V         03        WS-DATA-SIST-AAAA   PIC  9(04)**
- **V       01          WS-HORA-SIST        PIC  X(08)  VALUE  '  :  :  '**
- **V       01          FILLER  REDEFINES  WS-HORA-SIST**
- **V         03        WS-HORA-SIST-HH     PIC  9(02)**
- **V         03        WS-HORA-SIST-MM     PIC  9(02)**
- **V         03        WS-HORA-SIST-SS     PIC  9(02)**
- **V       01          WS-COMPILATION-DATE**
- **V         03        WS-COMP-DATE        PIC  X(08) VALUE  SPACES**
- **V         03        FILLER  REDEFINES  WS-COMP-DATE**
- **V           05      WS-COMP-DATE-MM     PIC  9(02)**
- **V           05      FILLER              PIC  X(01)**
- **V           05      WS-COMP-DATE-DD     PIC  9(02)**
- **V           05      WS-COMP-DATE-YY     PIC  9(02)**
- **V         03        WS-COMP-TIME        PIC  X(08) VALUE  SPACES**
- **V       01          FILLER  REDEFINES  WS-DATA-COMP**
- **V         03        WS-DATA-COMP-DD     PIC  9(02)**
- **V         03        WS-DATA-COMP-MM     PIC  9(02)**
- **V         03        WS-DATA-COMP-AA     PIC  9(02)**
- **V       01          WK-DATA-BASE        PIC  9(08)**
- **V       01          FILLER  REDEFINES  WK-DATA-BASE**
- **V         03        WK-DATA-BASE-AAAA   PIC  9(04)**
- **V         03        WK-DATA-BASE-MM     PIC  9(02)**
- **V         03        WK-DATA-BASE-DD     PIC  9(02)**
- **V697665        THRU  R100-EXIT**
- **V697665     PERFORM  R200-PROCESSAMENTO**
- **V697665        THRU  R200-EXIT**
- **V697665        UNTIL WK-FIM-E1  EQUAL 'S'**
- **V697665          AND WK-FIM-E2  EQUAL 'S'**
- **V           PERFORM  R800-FINALIZACAO**
- **V      ****** MONTA AREA PARA MOSTRAR DATA E HORA DE COMPILACAO**
- **V           MOVE  FUNCTION  CURRENT-DATE  TO  WS-CURRENT-DATE**
- **V           MOVE  WS-SYSTEM-DATE-YYYY     TO  WS-DATA-SIST-AAAA**
- **V           MOVE  WS-SYSTEM-DATE-MM       TO  WS-DATA-SIST-MM**
- **V           MOVE  WS-SYSTEM-DATE-DD       TO  WS-DATA-SIST-DD**
- **V           MOVE  WS-SYSTEM-TIME-HH       TO  WS-HORA-SIST-HH**
- **V           MOVE  WS-SYSTEM-TIME-MM       TO  WS-HORA-SIST-MM**
- **V           MOVE  WS-SYSTEM-TIME-SS       TO  WS-HORA-SIST-SS**
- **V           MOVE  WHEN-COMPILED           TO  WS-COMPILATION-DATE**
- **V           MOVE  WS-COMP-DATE-MM         TO  WS-DATA-COMP-MM**
- **V           MOVE  WS-COMP-DATE-DD         TO  WS-DATA-COMP-DD**
- **V           MOVE  WS-COMP-DATE-YY         TO  WS-DATA-COMP-AA**
- **V           DISPLAY '**         PROGRAMA LHAN0706              **'**
- **V           DISPLAY '*  DATA DO SISTEMA ...**
- **V           DISPLAY '*  HORA DO SISTEMA ...**
- **V           DISPLAY '*  DATA DE COMPILACAO**
- **V           DISPLAY '*  HORA DE COMPILACAO**
- **V           DISPLAY '**************************************'**
- **V      *-------- ABERTURA DOS ARQUIVOS SEQUENCIAIS**
- **V           OPEN INPUT  E1DQ0706**
- **V                       E2DQ0706**
- **V                OUTPUT S1DQ0706**
- **V                       S2DQ0706**
- **V      *-------- LEITURA DO ARQUIVO DE ENTRADA (HEADER DO ARQUIVO)**
- **V           PERFORM R110-LER-E1DQ0706**
- **V697665        THRU R110-EXIT**
- **V           IF  WK-FIM-E1  EQUAL  'S'**
- **V               DISPLAY '***********************************************'**
- **V               DISPLAY '      PROGRAMA LHAN0706  -   CANCELADO         '**
- **V               DISPLAY '  '**
- **V               DISPLAY '        ARQUIVO E1DQ0706 ESTA VAZIO'**
- **V               GO TO  R990-CANCELA**
- **V           DISPLAY '*  DATA BASE OPERACOES : '**
- **V           DISPLAY LHCE0400-DT-BSE OF WS-LHCE0400  '    *'**
- **V           PERFORM R120-CONTROLE-E2DQ0706**
- **V697665        THRU R120-EXIT**
- **VV001  *    IF  WK-FIM-E2  EQUAL  'S'**
- **VV001  *        DISPLAY '***********************************************'**
- **VV001  *        DISPLAY '      PROGRAMA LHAN0706  -   CANCELADO         '**
- **VV001  *        DISPLAY '  '**
- **VV001  *        DISPLAY '        ARQUIVO E2DQ0706 ESTA VAZIO OU SEM     '**
- **VV001  *        DISPLAY '        OU ARQUIVO SEM REGISTRO VALIDO         '**
- **VV001  *        GO TO  R990-CANCELA**
- **VV001  *    END-IF**
- **V           DISPLAY '*  DATA BASE MARCACAO  : '**
- **V697665     DISPLAY LHCE0430-DT-BSE   '    *'**
- **V      *  LER OPERACOES DE RISCO                                       ***
- **V       R110-LER-E1DQ0706               SECTION**
- **V           IF WK-FIM-E1  EQUAL 'S'**
- **V              GO TO R110-EXIT**
- **V           READ  E1DQ0706 INTO WS-LHCE0400**
- **V              MOVE 'S'                 TO WK-FIM-E1**
- **V           IF WK-FIM-E1 NOT EQUAL 'S'**
- **V              MOVE  LHCE0400-CD-ITF   OF WS-LHCE0400  TO  E1-CD-ITF**
- **V              MOVE  LHCE0400-NR-OPR-X OF WS-LHCE0400  TO  E1-NR-OPR-X**
- **V              MOVE  LHCE0400-CD-DMN-MDL-CTR-X OF WS-LHCE0400**
- **V                                                      TO  E1-MOD-X**
- **V              ADD  1   TO  AC-LIDOS-E1**
- **V              MOVE  HIGH-VALUES        TO  E1-CD-ITF**
- **V              MOVE  HIGH-VALUES        TO  E1-NR-OPR-X**
- **V              MOVE  HIGH-VALUES        TO  E1-MOD-X**
- **V       R110-EXIT.     EXIT**
- **V      *  CONTROLA LEITURA DE MARCACAO DE OPERACOES                    ***
- **V       R120-CONTROLE-E2DQ0706          SECTION**
- **V       R120-CONTROLE-INICIO**
- **V           IF WK-FIM-E2  EQUAL 'S'**
- **V              GO TO R120-EXIT**
- **V           PERFORM  R125-LER-E2DQ0706**
- **V697665        THRU  R125-EXIT**
- **V           MOVE 'N'  TO WK-DESPREZA-E2**
- **V           IF WK-FIM-E2  NOT EQUAL 'S'**
- **V697665        IF LHCE0430-CD-RETORNO (01) NOT EQUAL ZEROS**
- **V                 MOVE 'S'  TO WK-DESPREZA-E2**
- **V                 ADD 1 TO AC-ERRADOS-E2**
- **V                 PERFORM  R510-GRAVA-S2DQ0706**
- **V697665              THRU  R510-EXIT**
- **V              ELSE**
- **V697665           IF  LHCE0430-TP-REG     NOT EQUAL  1**
- **V                     MOVE 'S'  TO WK-DESPREZA-E2**
- **V                     PERFORM  R510-GRAVA-S2DQ0706**
- **V697665                  THRU  R510-EXIT**
- **V                 END-IF**
- **V              END-IF**
- **V              IF WK-DESPREZA-E2  EQUAL 'S'**
- **V                 GO TO R120-CONTROLE-INICIO**
- **V       R120-EXIT.     EXIT**
- **V       R125-LER-E2DQ0706               SECTION**
- **V697665     READ  E2DQ0706 INTO  WS-LHCE0430**
- **V                MOVE 'S'                  TO WK-FIM-E2**
- **V           IF WK-FIM-E2 NOT EQUAL 'S'**
- **V697665        MOVE  LHCE0430-CD-ITF          TO  E2-CD-ITF**
- **V  ||          MOVE  LHCE0430-NR-OPR-X        TO  E2-NR-OPR-X**
- **V697665        MOVE  LHCE0430-CD-MOD-CTR(1:2) TO  E2-MOD-X**
- **V              ADD  1   TO  AC-LIDOS-E2**
- **V              MOVE  HIGH-VALUES        TO  E2-CD-ITF**
- **V              MOVE  HIGH-VALUES        TO  E2-NR-OPR-X**
- **V              MOVE  HIGH-VALUES        TO  E2-MOD-X**
- **V       R125-EXIT.     EXIT**
- **V      ********************************************************************
- **V697665     SET  SW-DOC-MODSUB-NAO   TO    TRUE**
- **V697665     EVALUATE TRUE**
- **V  ||          WHEN  WS-CHAVE-E1  EQUAL    WS-CHAVE-E2**
- **V  ||                PERFORM R201-TRATA-IGUAIS**
- **V  ||                   THRU R201-EXIT**
- **V  ||          WHEN  WS-CHAVE-E1  GREATER  WS-CHAVE-E2**
- **V  ||                PERFORM R301-TATICO-INEXISTE-E1**
- **V  ||                   THRU R301-EXIT**
- **V  ||          WHEN OTHER**
- **V  ||                IF (LHCE0400-TP-REG OF WS-LHCE0400  EQUAL CT-01) AND**
- **V  ||                   (LHCE0400-CD-MOD-CTR OF WS-LHCE0400 = 1350)   AND**
- **V  ||                   (LHCE0400-CD-NAT-CTR OF WS-LHCE0400 = CT-01)**
- **V1350                ADD     1               TO AC-FALTA-1350**
- **V1350                DISPLAY 'LHAN0706 MOD 1350 NAT 01 SEM ADIC '**
- **V1350 -                      'SIST:' LHCE0400-CD-ITF OF WS-LHCE0400**
- **V1350 -                      ' OPER:' LHCE0400-NR-OPR-X OF WS-LHCE0400**
- **V  ||                PERFORM R401-SALVA-E1DQ0706-S1**
- **V  ||                   THRU R401-EXIT**
- **V       R200-EXIT.     EXIT**
- **V  ||  * TRATA IGUAIS**
- **V  ||   R201-TRATA-IGUAIS               SECTION**
- **V  ||  *    REAPROVEITA SECTION R401 PARA ASSEGURAR DESCARGA DA OPERACAO**
- **V697665*    EM S1, DEPOIS DECIDE SE GRAVA E2-TATICO EM S1**
- **V           IF (LHCE0430-CD-CIC       EQUAL  LHCE0400-CD-CIC**
- **V                                        OF  WS-LHCE0400)         AND**
- **V              (LHCE0430-CD-MOD-CTR   EQUAL  LHCE0400-CD-MOD-CTR**
- **V                                        OF  WS-LHCE0400)**
- **V697665         SET SW-DOC-MODSUB-SIM    TO  TRUE**
- **V  ||       PERFORM R401-SALVA-E1DQ0706-S1**
- **V  ||          THRU R401-EXIT**
- **V  ||  *    AVALIAR SE ENTRADA TATICO E2 DEVE GRAVAR S1**
- **V  ||       MOVE WS-CHAVE-E2             TO  WS-QUEBRA-E2**
- **V  ||       PERFORM R210-ANALISE-E2DQ0706**
- **V  ||          THRU R210-EXIT**
- **V  ||         UNTIL WS-CHAVE-E2   NOT EQUAL  WS-QUEBRA-E2**
- **V  ||   R201-EXIT.     EXIT**
- **V  ||  * AVALIAR SE ENTRADA TATICO E2 DEVE GRAVAR S1**
- **V  ||   R210-ANALISE-E2DQ0706           SECTION**
- **V  ||  *    SE SW-DOC-MODSUB-SIM**
- **V  ||  *    - VERIFICAR COMPATIBILIDADE TIPO SUBTIPO INFO. ADIC**
- **V  ||  *      - SE COMBINACAO OK**
- **V  ||  *        - TATICO CONTRA TABELA MEMORIA DA ORIGEM:**
- **V  ||  *          - SE NAO EXISTIR, SECTION R211 PARA GRAVAR S1 E S2**
- **V  ||  *          - SE     EXISTIR, INFO ADIC DA ORIGEM E GRAVAR  S2**
- **V  ||  *      - OUTRAS SITUACOES: TIPO SUBTIPO INFO. ADIC. NAT**
- **MOD. SUBMOD**
- **V  ||       IF SW-DOC-MODSUB-SIM**
- **V  ||          MOVE  CT-02                  TO LHCE0700-NR-OPCAO**
- **V  ||          MOVE  LHCE0430-TP-SB-INFO    TO LHCE0700-TX-OP2-TIPOSUB**
- **V  ||          MOVE  WS-CD-NAT-CTR          TO LHCE0700-TX-OP2-NAT**
- **V  ||          CALL  CT-LHBR0700         USING LI-LHCE0700**
- **VSPRT04        MOVE  ZEROS                  TO LHCE0700-CD-RET**
- **V  ||          IF LHCE0700-CD-RET-OK**
- **V  ||             SET    IN-TP              TO CT-01**
- **V  ||             SEARCH TB-GR-TIPO-SUB**
- **V  ||                 AT END**
- **V  ||                    PERFORM R211-GRAVA-E2DQ0706-S1**
- **V  ||                       THRU R211-EXIT**
- **V  ||               WHEN TB-EL-TP(IN-TP) EQUAL LHCE0430-TP-SB-INFO**
- **V  ||                    MOVE  CT-01        TO LHCE0430-CD-RETORNO(01)**
- **V  ||                    MOVE  ME-INFO-ORIG TO LHCE0430-TX-MENSAGEM**
- **V  ||                    PERFORM R510-GRAVA-S2DQ0706**
- **V  ||                       THRU R510-EXIT**
- **V  ||             END-SEARCH**
- **V  ||          ELSE**
- **V  ||             MOVE  CT-04             TO LHCE0430-CD-RETORNO(01)**
- **V  ||             MOVE  ME-INFO-NAT-INVAL TO LHCE0430-TX-MENSAGEM**
- **V  ||             MOVE  WS-CD-NAT-CTR     TO LHCE0430-TX-MENSAGEM(30:02)**
- **V  ||             ADD   CT-01             TO AC-NATINCO-E2**
- **V  ||             PERFORM R510-GRAVA-S2DQ0706**
- **V  ||                THRU R510-EXIT**
- **V  ||          END-IF**
- **V  ||       ELSE**
- **V  ||          MOVE CT-03                      TO LHCE0430-CD-RETORNO(01)**
- **V  ||          MOVE ME-INFO-SCORR-CLI-MOD      TO LHCE0430-TX-MENSAGEM**
- **V  ||          PERFORM  R510-GRAVA-S2DQ0706**
- **V  ||             THRU  R510-EXIT**
- **V  ||          ADD      CT-01                  TO AC-SEMCORR-E2**
- **V  ||  *       PERFORM  R120-CONTROLE-E2DQ0706**
- **V  ||  *          THRU  R120-EXIT**
- **V  ||  *    REINICIALIZA TABELA INTERNA PARA NOVA OPERACAO**
- **V  ||       MOVE     ZEROS   TO   TB-TIPO-SUB**
- **V  ||       PERFORM  R120-CONTROLE-E2DQ0706**
- **V  ||          THRU  R120-EXIT**
- **V  ||   R210-EXIT.     EXIT**
- **V  ||  * GRAVA TATICO EM S1 E S2**
- **V  ||   R211-GRAVA-E2DQ0706-S1          SECTION**
- **V  ||       MOVE  LHCE0430-TP-INFO-ADIC  TO**
- **V  ||             LHCE0400-TP-INFO-ADIC  OF  WS-LHCE0400-AUX**
- **V  ||       MOVE  LHCE0430-SB-INFO-ADIC  TO**
- **V  ||             LHCE0400-SB-INFO-ADIC  OF  WS-LHCE0400-AUX**
- **V  ||       MOVE  SPACES                 TO**
- **V  ||             LHCE0400-CD-INFO-ADIC  OF  WS-LHCE0400-AUX**
- **V  ||             LHCE0400-ID-INFO-ADIC  OF  WS-LHCE0400-AUX**
- **V  ||             LHCE0400-TX-INFO-ADIC  OF  WS-LHCE0400-AUX**
- **V  ||       MOVE  ZEROS                  TO**
- **V  ||             LHCE0400-VL-INFO-ADIC  OF  WS-LHCE0400-AUX**
- **V  ||             LHCE0400-PC-INFO-ADIC  OF  WS-LHCE0400-AUX**
- **V  ||             LHCE0400-QT-INFO-ADIC  OF  WS-LHCE0400-AUX**
- **V  ||  * TEMPORARIO-INICIO**
- **V  ||       MOVE  CT-HIFEN               TO**
- **V  ||             LHCE0400-TX-INFO-ADIC  OF  WS-LHCE0400-AUX(100:001)**
- **V  ||  * TEMPORARIO-FIM**
- **V  ||                PERFORM T001-GRAVA-TIPO-01**
- **V  ||                   THRU T001-EXIT**
- **V  ||                PERFORM T002-GRAVA-TIPO-02**
- **V  ||                   THRU T002-EXIT**
- **V  ||  *        WHEN CT-03                       TIPO NAO PREVISTO**
- **V  ||  *             PERFORM T003-GRAVA-TIPO-03**
- **V  ||  *                THRU T003-EXIT**
- **V  ||                PERFORM T004-GRAVA-TIPO-04**
- **V  ||                   THRU T004-EXIT**
- **VSPRT04              PERFORM T006-GRAVA-TIPO-06**
- **VSPRT04                 THRU T006-EXIT**
- **V  ||                PERFORM T007-GRAVA-TIPO-07**
- **V  ||                   THRU T007-EXIT**
- **V  ||                PERFORM T010-GRAVA-TIPO-10**
- **V  ||                   THRU T010-EXIT**
- **V  ||                PERFORM T011-GRAVA-TIPO-11**
- **V  ||                   THRU T011-EXIT**
- **V  ||                PERFORM T012-GRAVA-TIPO-12**
- **V  ||                   THRU T012-EXIT**
- **VSPRT09              PERFORM T014-GRAVA-TIPO-14**
- **VSPRT09                 THRU T014-EXIT**
- **V  ||                PERFORM T015-GRAVA-TIPO-15**
- **V  ||                   THRU T015-EXIT**
- **VCORBAN              PERFORM T016-GRAVA-TIPO-16**
- **VCORBAN                 THRU T016-EXIT**
- **VSPRT77              PERFORM T017-GRAVA-TIPO-17**
- **VSPRT77                 THRU T017-EXIT**
- **VOLIVA1              PERFORM T018-GRAVA-TIPO-18**
- **VOLIVA1                 THRU T018-EXIT**
- **VOLIVA1              PERFORM T019-GRAVA-TIPO-19**
- **VOLIVA1                 THRU T019-EXIT**
- **VSPRT74         WHEN CT-24**
- **VSPRT74              PERFORM T024-GRAVA-TIPO-24**
- **VSPRT74                 THRU T024-EXIT**
- **V  ||       MOVE    WS-LHCE0400-AUX      TO  REG-S1DQ0706**
- **V  ||       PERFORM R500-GRAVA-S1DQ0706**
- **V  ||          THRU R500-EXIT**
- **V  ||       MOVE    ZEROS                TO  LHCE0430-CD-RETORNO(01)**
- **V  ||       MOVE    ME-INFO-OK           TO  LHCE0430-TX-MENSAGEM**
- **V  ||       PERFORM R510-GRAVA-S2DQ0706**
- **V  ||          THRU R510-EXIT**
- **V  ||       ADD     CT-01                TO  AC-INCLUIDO-S1**
- **V  ||   R211-EXIT.     EXIT**
- **V  ||  * TRATA MAIOR - TATICO NAO EXISTE EM E1**
- **V  ||   R301-TATICO-INEXISTE-E1         SECTION**
- **V  ||       MOVE    CT-02                TO  LHCE0430-CD-RETORNO(01)**
- **V697665     MOVE    ME-INFO-SCORR        TO  LHCE0430-TX-MENSAGEM**
- **V           PERFORM R510-GRAVA-S2DQ0706**
- **V              THRU R510-EXIT**
- **V           ADD     CT-01                TO  AC-SEMCORR-E2**
- **V              THRU R120-EXIT**
- **V  ||   R301-EXIT.     EXIT**
- **V  ||  * GRAVA E1 EM S1**
- **V  ||  * - SE SW-DOC-MODSUB-SIM SIGNIFICA QUE ENCONTROU TATICO PARA**
- **V  ||  *   PROCESSAMENTO, SALVA MODELO DO REGISTRO E DECIDE SE GRAVA**
- **V  ||  *   TATICO NA SAIDA S1 NA SECTION R402**
- **V       R401-SALVA-E1DQ0706-S1          SECTION**
- **SUBTIPO INFO. ADIC**
- **V697665     MOVE ZEROS                       TO  AC-TP-QT**
- **V           MOVE WS-CHAVE-E1                 TO  WS-QUEBRA-E1**
- **V           PERFORM**
- **V             UNTIL  WS-CHAVE-E1      NOT EQUAL  WS-QUEBRA-E1**
- **V697665              IF  SW-DOC-MODSUB-SIM**
- **V  ||                    PERFORM  R402-PREPARA-TATICO**
- **V  ||                       THRU  R402-EXIT**
- **V697665              END-IF**
- **V                    MOVE     WS-LHCE0400    TO  REG-S1DQ0706**
- **V                    PERFORM  R500-GRAVA-S1DQ0706**
- **V                       THRU  R500-EXIT**
- **V                    PERFORM  R110-LER-E1DQ0706**
- **V                       THRU  R110-EXIT**
- **V           END-PERFORM**
- **V       R401-EXIT.     EXIT**
- **V      * EM CASO DE MATCH, PREPARA REGISTRO TIPO 5 PARA GRAVACAO TATICO**
- **V       R402-PREPARA-TATICO             SECTION**
- **V697665*--- SALVA MODELO PARA REGISTRO TIPO 5**
- **V  ||  *    LHCE0400-CD-NAT-CTR EM WORKING PARA VERIFICAR COMPATIBILIDADE**
- **V697665*    ENTRE TATICO TIPO SUBTIPO INFO. AD**
- **V           IF  LHCE0400-TP-REG OF WS-LHCE0400  EQUAL CT-01**
- **V697665         MOVE  LHCE0400-CD-NAT-CTR   OF WS-LHCE0400**
- **V697665                                     TO WS-CD-NAT-CTR**
- **V               MOVE  WS-LHCE0400           TO WS-LHCE0400-AUX**
- **V               MOVE  CT-05                 TO**
- **V                     LHCE0400-TP-REG       OF WS-LHCE0400-AUX**
- **V               MOVE  SPACES                TO**
- **V                     LHCE0400-DET005       OF WS-LHCE0400-AUX(137:399)**
- **V                     LHCE0400-CD-INFO-ADIC OF WS-LHCE0400-AUX**
- **V                     LHCE0400-ID-INFO-ADIC OF WS-LHCE0400-AUX**
- **V                     LHCE0400-TX-INFO-ADIC OF WS-LHCE0400-AUX**
- **V               MOVE  ZEROS                 TO**
- **V                     LHCE0400-VL-INFO-ADIC OF WS-LHCE0400-AUX**
- **V                     LHCE0400-PC-INFO-ADIC OF WS-LHCE0400-AUX**
- **V                     LHCE0400-QT-INFO-ADIC OF WS-LHCE0400-AUX**
- **V  ||  * GUARDA EM TABELA MEMORIA TIPO SUBTIPO VINDO DA ORIGEM**
- **V  ||  * SEM REPETICAO**
- **V  ||       IF (LHCE0400-TP-REG OF WS-LHCE0400)     EQUAL CT-05**
- **V  ||          SET    IN-TP                     TO CT-01**
- **V  ||          SEARCH TB-GR-TIPO-SUB**
- **V  ||              AT END**
- **V  ||                 ADD  CT-01                TO AC-TP-QT**
- **V  ||                 MOVE WS-LHCE0400(137:004) TO TB-EL-TP(AC-TP-QT)**
- **V  ||            WHEN TB-EL-TP(IN-TP)        EQUAL WS-LHCE0400(137:004)**
- **V  ||                 CONTINUE**
- **V  ||           END-SEARCH**
- **V697665     END-IF**
- **V       R402-EXIT.     EXIT**
- **V      *   GRAVA ARQUIVO DE OPERACOES                                  ***
- **V       R500-GRAVA-S1DQ0706             SECTION**
- **V           WRITE  REG-S1DQ0706**
- **V           ADD    1                     TO AC-GRAVADOS-S1**
- **V       R500-EXIT.     EXIT**
- **V      *   GRAVA ARQUIVO DE REGISTROS                                  ***
- **V       R510-GRAVA-S2DQ0706             SECTION**
- **V697665     WRITE  REG-S2DQ0706        FROM WS-LHCE0430**
- **V           ADD    1                     TO AC-GRAVADOS-S2**
- **V       R510-EXIT.     EXIT**
- **V      *  ROTINA DE FINALIZACAO                                        ***
- **V       R800-FINALIZACAO                SECTION**
- **V           CLOSE E1DQ0706**
- **V                 E2DQ0706**
- **V                 S1DQ0706**
- **V                 S2DQ0706**
- **V           DISPLAY '**     TERMINO DO PROGRAMA LHAN0706 OK       **'**
- **V           DISPLAY '***OPERACOES***********************************'**
- **V           DISPLAY '** TOT REG.LIDOS      E1DQ0706   : ' AC-LIDOS-E1**
- **V           DISPLAY '** TOT REG.GRAVADOS   S1DQ0706   : ' AC-GRAVADOS-S1**
- **V           DISPLAY '***MARCACAO************************************'**
- **V           DISPLAY '** TOT REG.LIDOS      E2DQ0706   : ' AC-LIDOS-E2**
- **V           DISPLAY '** TOT REG.GRAVADOS   S2DQ0706   : ' AC-GRAVADOS-S2**
- **V           DISPLAY '***DETALHE MARCACAO****************************'**
- **V           DISPLAY '** TOT REG.DESPREZADOS           : ' AC-ERRADOS-E2**
- **V           DISPLAY '** TOT REG**
- **V697665     DISPLAY '** TOT REG.NATUREZA INCOMPATIVEL : ' AC-NATINCO-E2**
- **V           DISPLAY '** TOT REG.SEM CORRESPONDENTE    : ' AC-SEMCORR-E2**
- **V           DISPLAY '** TOT REG.GERADOS PELA ORIGEM   : ' AC-ORIGEM-E2**
- **V           DISPLAY '** TOT REG.INCLUIDOS             : ' AC-INCLUIDO-S1**
- **V           CALL  CT-DRAM0018          USING     PGMNAME      STCODE**
- **V      * TRATAMENTO E GRAVACAO DO TATICO, DE ACORDO COM TIPO INFO. ADIC**
- **V  ||  * GRAVA TIPO 01**
- **V  ||   T001-GRAVA-TIPO-01              SECTION**
- **V  ||       PERFORM  U010-CD-INFO-ADIC-DATA**
- **V  ||          THRU  U010-EXIT**
- **V  ||       IF  LHCE0430-SB-INFO-ADIC  NOT EQUAL  CT-05**
- **V  ||           PERFORM  U020-ID-INFO-ADIC-CNPJ**
- **V  ||              THRU  U020-EXIT**
- **V  ||       PERFORM  U030-VL-INFO-ADIC**
- **V  ||          THRU  U030-EXIT**
- **V  ||       PERFORM  U040-PC-INFO-ADIC**
- **V  ||          THRU  U040-EXIT**
- **V  ||   T001-EXIT.     EXIT**
- **V  ||  * GRAVA TIPO 02**
- **V  ||   T002-GRAVA-TIPO-02              SECTION**
- **V  ||       PERFORM  U020-ID-INFO-ADIC-CNPJ**
- **V  ||          THRU  U020-EXIT**
- **V  ||   T002-EXIT.     EXIT**
- **V  ||  * GRAVA TIPO 04**
- **V  ||   T004-GRAVA-TIPO-04              SECTION**
- **V  ||  *    SUBTIPO 01: SE SITUACAO EM ID = 1, DOC EM CD = BRANCOS**
- **V  ||  *    SUBTIPO 03: NAO HA DATA EM ID**
- **V  ||  *    TODOS, EXCETO CONDICIONAL NO SUBTIPO 01: CODIGO EM CD**
- **V  ||       EVALUATE  LHCE0430-SB-INFO-ADIC**
- **V  ||           WHEN  CT-01**
- **V  ||                 IF  LHCE0430-ID1-SITUACAO      EQUAL  CT-X-1**
- **V  ||                     PERFORM  U023-ID-INFO-ADIC-SITUACAO**
- **V  ||                        THRU  U023-EXIT**
- **V  ||                 ELSE**
- **V  ||                     PERFORM  U011-CD-INFO-ADIC-FULL**
- **V  ||                        THRU  U011-EXIT**
- **V  ||                 END-IF**
- **V  ||           WHEN  OTHER**
- **V  ||                 PERFORM U011-CD-INFO-ADIC-FULL**
- **V  ||                    THRU U011-EXIT**
- **V  ||                 IF  LHCE0430-SB-INFO-ADIC  NOT EQUAL  CT-03**
- **V  ||                     PERFORM  U021-ID-INFO-ADIC-DATA**
- **V  ||                        THRU  U021-EXIT**
- **V  ||   T004-EXIT.     EXIT**
- **VSPRT04* GRAVA TIPO 06**
- **VSPRT04 T006-GRAVA-TIPO-06              SECTION**
- **VSPRT04     MOVE  LHCE0430-CD-INFO-ADIC(1:2)  TO LHCE0400-ID-INFO-ADIC**
- **VSPRT04                                       OF  WS-LHCE0400-AUX**
- **VSPRT04     MOVE  LHCE0430-ID-INFO-ADIC(1:14)  TO LHCE0400-CD-INFO-ADIC**
- **VSPRT04 T006-EXIT.     EXIT**
- **V  ||  * GRAVA TIPO 07**
- **V  ||   T007-GRAVA-TIPO-07              SECTION**
- **V  ||   T007-EXIT.     EXIT**
- **V  ||  * GRAVA TIPO 10**
- **V  ||   T010-GRAVA-TIPO-10              SECTION**
- **V  ||   T010-EXIT.     EXIT**
- **V  ||  * GRAVA TIPO 11**
- **V  ||   T011-GRAVA-TIPO-11              SECTION**
- **V  ||       PERFORM  U011-CD-INFO-ADIC-FULL**
- **V  ||          THRU  U011-EXIT**
- **V  ||   T011-EXIT.     EXIT**
- **V  ||  * GRAVA TIPO 12**
- **V  ||   T012-GRAVA-TIPO-12              SECTION**
- **V  ||                 PERFORM  U010-CD-INFO-ADIC-DATA**
- **V  ||                    THRU  U010-EXIT**
- **V  ||                 PERFORM  U022-ID-INFO-ADIC-MODSUB**
- **V  ||                    THRU  U022-EXIT**
- **V  ||                 PERFORM  U030-VL-INFO-ADIC**
- **V  ||                    THRU  U030-EXIT**
- **V  ||                 PERFORM  U040-PC-INFO-ADIC**
- **V  ||                    THRU  U040-EXIT**
- **V  ||           WHEN  CT-02**
- **V  ||                 PERFORM  U012-CD-INFO-ADIC-CONTR**
- **V  ||                    THRU  U012-EXIT**
- **V  ||           WHEN  CT-03**
- **V  ||                 PERFORM  U020-ID-INFO-ADIC-CNPJ**
- **V  ||                    THRU  U020-EXIT**
- **V  ||   T012-EXIT.     EXIT**
- **VSPRT09* GRAVA TIPO 14**
- **VSPRT09 T014-GRAVA-TIPO-14              SECTION**
- **VSPRT09     IF  LHCE0430-SB-INFO-ADIC  EQUAL  CT-08**
- **VSPRT09        MOVE  LHCE0430-ID-INFO-ADIC(1:2) TO LHCE0400-ID-INFO-ADIC**
- **VSPRT09                                         OF WS-LHCE0400-AUX**
- **VSPRT09     END-IF**
- **VSPRT09 T014-EXIT.     EXIT**
- **V  ||  * GRAVA TIPO 15**
- **V  ||   T015-GRAVA-TIPO-15              SECTION**
- **V  ||  *    SE SITUACAO EM CD = 1, DOC EM ID = BRANCOS**
- **V  ||       IF  LHCE0430-CD1-SITUACAO      EQUAL  CT-X-1**
- **V  ||           PERFORM  U013-CD-INFO-ADIC-SITUACAO**
- **V  ||              THRU  U013-EXIT**
- **V  ||   T015-EXIT.     EXIT**
- **VCORBAN*---------------------------------------------------------------***
- **VCORBAN* GRAVA TIPO 16**
- **VCORBAN T016-GRAVA-TIPO-16              SECTION**
- **VCORBAN**
- **VCORBAN     IF  LHCE0430-ID1-TP-PES  NOT EQUAL  CT-01 AND CT-02**
- **VCORBAN         MOVE   CT-02                TO  LHCE0430-ID1-TP-PES**
- **VCORBAN     END-IF**
- **VCORBAN     MOVE  LHCE0430-ID1-TP-PES       TO  LHCE0400-TP-PES-CED**
- **VCORBAN                                     OF  WS-LHCE0400-AUX**
- **VCORBAN     MOVE  ZEROS                     TO  WS-CNPJ-ZERO**
- **VCORBAN     MOVE  LHCE0430-ID1-NR-DOC       TO  WS-CNPJ-14**
- **VCORBAN     MOVE  WS-CNPJ-CORRESP-N         TO  LHCE0400-CD-CPFCNPJ-CED**
- **VCORBAN***
- **VCORBAN T016-EXIT.     EXIT**
- **VSPRT77* GRAVA TIPO 17**
- **VSPRT77*---------------------------------------------------------------***
- **VSPRT77 T017-GRAVA-TIPO-17              SECTION**
- **VSPRT77     MOVE  LHCE0430-CD2-DATA         TO  LHCE0400-CD-INFO-ADIC**
- **VSPRT77                                     OF  WS-LHCE0400-AUX**
- **VSPRT77     MOVE  LHCE0430-ID1-DOC(1:2)     TO  LHCE0400-ID-INFO-ADIC**
- **VSPRT77 T017-EXIT.     EXIT**
- **V      * GRAVA TIPO 18**
- **V       T018-GRAVA-TIPO-18              SECTION**
- **V           MOVE  LHCE0430-CD1-REFBACEN     TO  LHCE0400-CD-INFO-ADIC**
- **V                                           OF  WS-LHCE0400-AUX**
- **V       T018-EXIT.     EXIT**
- **V      * GRAVA TIPO 19**
- **V       T019-GRAVA-TIPO-19              SECTION**
- **V           IF LHCE0430-SB-INFO-ADIC  EQUAL 99**
- **V              MOVE  LHCE0430-CD1-REFBACEN TO  LHCE0400-CD-INFO-ADIC**
- **V                                          OF  WS-LHCE0400-AUX**
- **V       T019-EXIT.     EXIT**
- **V  ||  * GRAVA TIPO 24**
- **V  ||   T024-GRAVA-TIPO-24              SECTION**
- **V  ||       IF LHCE0430-SB-INFO-ADIC  EQUAL 05 OR 06**
- **V  ||          MOVE  LHCE0430-CD-INFO-ADIC(1:2) TO  LHCE0400-CD-INFO-ADIC**
- **V  ||                                           OF  WS-LHCE0400-AUX**
- **VSPRT74 T024-EXIT.     EXIT**
- **V  ||  * MOVIMENTACOES POR CAMPO DO TATICO**
- **V  ||  * FORMATO DATA NO CAMPO CD-INFO-ADIC**
- **V  ||   U010-CD-INFO-ADIC-DATA          SECTION**
- **V  ||       MOVE  LHCE0430-CD1-DATA         TO  LHCE0400-CD-INFO-ADIC**
- **V  ||                                       OF  WS-LHCE0400-AUX**
- **V  ||   U010-EXIT.     EXIT**
- **V  ||  * FORMATO FULL NO CAMPO CD-INFO-ADIC**
- **V  ||   U011-CD-INFO-ADIC-FULL          SECTION**
- **V  ||       MOVE  LHCE0430-CD-INFO-ADIC     TO  LHCE0400-CD-INFO-ADIC**
- **V  ||   U011-EXIT.     EXIT**
- **V  ||  * FORMATO CONTRATO NO CAMPO CD-INFO-ADIC**
- **V  ||   U012-CD-INFO-ADIC-CONTR         SECTION**
- **V  ||       MOVE LHCE0430-CD1-CONTRATO      TO LHCE0400-CD-INFO-ADIC**
- **V  ||                                       OF WS-LHCE0400-AUX**
- **V  ||   U012-EXIT.     EXIT**
- **V  ||  * FORMATO SITUACAO NO CAMPO CD-INFO-ADIC**
- **V  ||   U013-CD-INFO-ADIC-SITUACAO      SECTION**
- **V  ||       MOVE LHCE0430-CD1-SITUACAO      TO LHCE0400-CD-INFO-ADIC**
- **V  ||   U013-EXIT.     EXIT**
- **V  ||  * FORMATO DOC NO CAMPO ID-INFO-ADIC**
- **V  ||   U020-ID-INFO-ADIC-CNPJ          SECTION**
- **V  ||  * NO ARQUIVO TATICO NAO EH OBRIGATORIO INFORMAR TIPO DE PESSOA**
- **V  ||  * POR ISSO TORNA MANDATORIO IGUAL A 02 QUANDO NAO VIER 01 NEM 02**
- **V  ||  * PORQUE ESTAH PREVISTO SOMENTE CNPJ**
- **V  ||  * FUTURAMENTE, SE NO ARQUIVO TATICO VIER 01 OU 02, O CODIGO PREVE**
- **V  ||  * A MOVIMENTACAO NATURALMENTE DO VALOR**
- **V  ||       IF  LHCE0430-ID1-TP-PES  NOT EQUAL  CT-01 AND CT-02**
- **V  ||           MOVE   CT-02                TO  LHCE0430-ID1-TP-PES**
- **V  ||       MOVE  LHCE0430-ID1-TP-PES       TO  LHCE0400-TP-PES-CED**
- **V  ||       MOVE  LHCE0430-ID1-NR-DOC       TO  LHCE0400-CD-CPFCNPJ-CED**
- **V  ||       IF  LHCE0430-ID1-TP-PES      EQUAL  CT-02**
- **V  ||           MOVE LHCE0430-ID2-CNPJ-RAIZ TO  LHCE0400-ID-INFO-ADIC**
- **V  ||   U020-EXIT.     EXIT**
- **V  ||  * FORMATO DATA NO CAMPO ID-INFO-ADIC**
- **V  ||   U021-ID-INFO-ADIC-DATA          SECTION**
- **V  ||       MOVE LHCE0430-ID1-DATA          TO LHCE0400-ID-INFO-ADIC**
- **V  ||   U021-EXIT.     EXIT**
- **V  ||  * FORMATO XXXX NO CAMPO ID-INFO-ADIC**
- **V  ||   U022-ID-INFO-ADIC-MODSUB        SECTION**
- **V  ||       MOVE LHCE0430-ID1-MODSUB        TO LHCE0400-ID-INFO-ADIC**
- **V  ||   U022-EXIT.     EXIT**
- **V  ||  * FORMATO SITUACAO NO CAMPO ID-INFO-ADIC**
- **V  ||   U023-ID-INFO-ADIC-SITUACAO      SECTION**
- **V  ||       MOVE LHCE0430-ID1-SITUACAO      TO LHCE0400-ID-INFO-ADIC**
- **V  ||   U023-EXIT.     EXIT**
- **V  ||  * FORMATO VALOR NO CAMPO VL-INFO-ADIC**
- **V  ||   U030-VL-INFO-ADIC               SECTION**
- **V  ||       MOVE    LHCE0430-VL-INFO-ADIC     TO  LHCE0400-VL-INFO-ADIC**
- **V  ||                                         OF  WS-LHCE0400-AUX**
- **V  ||       IF LHCE0430-VL-INFO-ADIC-SINAL EQUAL  CT-HIFEN**
- **V  ||          COMPUTE LHCE0400-VL-INFO-ADIC  OF  WS-LHCE0400-AUX =**
- **V  ||                  LHCE0430-VL-INFO-ADIC   *  -1**
- **V  ||   U030-EXIT.     EXIT**
- **V  ||  * FORMATO PERCENTUAL NO CAMPO PC-INFO-ADIC**
- **V  ||   U040-PC-INFO-ADIC               SECTION**
- **V  ||       MOVE    LHCE0430-PC-INFO-ADIC     TO  LHCE0400-PC-INFO-ADIC**
- **V  ||          COMPUTE LHCE0400-PC-INFO-ADIC  OF  WS-LHCE0400-AUX =**
- **V  ||                  LHCE0430-PC-INFO-ADIC   *  -1**
- **V  ||   U040-EXIT.     EXIT**
- **VMEMBER NAME  LHBR0700**
- **V       PROGRAM-ID.    LHBR0700**
- **V       AUTHOR.        MARCELLO KOJIMA - RESOURCE**
- **V      *  OBJETIVO - VALIDACAO COMBINACOES DE ACORDO COM A OPCAO**
- **V      *             - TIPO SUBTIPO CONTRA MODALIDADE SUBMODALIDADE**
- **V      *             - TIPO SUBTIPO CONTRA NATUREZA**
- **V      *  OBS**
- **V      *  1) PARA OS SERVICOS 01 E 02:**
- **V      *     - PRIMEIRO VERIFICA SE O TIPO E SUBTIPO DEVEM SER TRATADOS**
- **V      *       - CASO NAO ESTEJA NAS LISTAS DAS TABELAS INTERNAS, TODAS**
- **V      *         COMBINACOES SAO ACEITAS**
- **V      *       - CASO ESTEJA, ENTAO VERIFICA SE A COMBINACAO EXISTE**
- **V      *         - SE EXISTIR, ENTAO EH VALIDA**
- **V      *                 A L T E R A C O E S**
- **V      *--------------+----------+--------------------------------------***
- **V      *     NOME     |   DATA   |       DESCRICAO**
- **19  |MODALIDADE 1350 - ACEITAR NAT 01**
- **V1350  *              |          |MODALIDADE 1350 - ACEITAR INFO 1002**
- **V       ENVIRONMENT DIVISION**
- **V       CONFIGURATION                   SECTION**
- **V                            DECIMAL-POINT  IS  COMMA**
- **V       DATA        DIVISION**
- **V       WORKING-STORAGE                 SECTION**
- **V      *--- CONSTANTES**
- **V       01          CT-CONSTANTES**
- **V           05      CT-LHBR0700         PIC  X(08)  VALUE 'LHBR0700'**
- **V           05      CT-XX               PIC  X(02)  VALUE 'XX'**
- **V           05      CT-01               PIC  9(02)  VALUE  01**
- **V           05      CT-02               PIC  9(02)  VALUE  02**
- **V           05      CT-08               PIC  9(02)  VALUE  08**
- **V           05      CT-09               PIC  9(02)  VALUE  09**
- **V           05      CT-15               PIC  9(02)  VALUE  15**
- **V           05      CT-16               PIC  9(02)  VALUE  16**
- **V           05      CT-1402             PIC  9(04)  VALUE  1402**
- **V           05      CT-1404             PIC  9(04)  VALUE  1404**
- **V           05      CT-1405             PIC  9(04)  VALUE  1405**
- **V      *--- VARIAVEIS GERAIS**
- **V      *    CLONE DA AREA DE ENTRADA, BOOK LHCE0700**
- **V           03 WS-TX-ENTRADA            PIC  X(08)**
- **V           03 WS-TX-OPCAO1             REDEFINES  WS-TX-ENTRADA**
- **V              05 WS-TX-OP1-TIPOSUBTIPO**
- **V                 07 WS-TX-OP1-TP       PIC  X(02)**
- **V                 07 WS-TX-OP1-TPSUB    PIC  X(02)**
- **V              05 WS-TX-OP1-MODSUBMOD**
- **V                 07 WS-TX-OP1-MOD      PIC  X(02)**
- **V                 07 WS-TX-OP1-MODSUB   PIC  X(02)**
- **V           03 WS-TX-OPCAO2             REDEFINES  WS-TX-ENTRADA**
- **V              05 WS-TX-OP2-TPSUBNAT**
- **V                 07 WS-TX-OP2-TP       PIC  X(02)**
- **V                 07 WS-TX-OP2-TPSUB    PIC  X(02)**
- **V                 07 WS-TX-OP2-NAT      PIC  X(02)**
- **V              05 FILLER                PIC  X(02)**
- **V      *--- TABELA INTERNA**
- **V       01 TB-TABELAS**
- **V      *---**
- **V      *--- OPCAO 01: TIPO SUB CONTRA MOD**
- **V      *--- OBS**
- **V      *---       SERA FEITO TRATAMENTO QUANDO RECEBER LINK DO CHAMADOR**
- **V           05  TB-OP1-COMB**
- **V               10  FILLER**
- **V                   15  FILLER PIC X(08) VALUE '02010404'**
- **V                   15  FILLER PIC X(08) VALUE '12011511'**
- **V                   15  FILLER PIC X(08) VALUE '12011512'**
- **V                   15  FILLER PIC X(08) VALUE '12012001'**
- **V                   15  FILLER PIC X(08) VALUE '12012002'**
- **V                   15  FILLER PIC X(08) VALUE '12031512'**
- **V                   15  FILLER PIC X(08) VALUE '14010212'**
- **V                   15  FILLER PIC X(08) VALUE '14010403'**
- **V                   15  FILLER PIC X(08) VALUE '140208XX'**
- **V                   15  FILLER PIC X(08) VALUE '14021512'**
- **V                   15  FILLER PIC X(08) VALUE '140216XX'**
- **V                   15  FILLER PIC X(08) VALUE '140408XX'**
- **V                   15  FILLER PIC X(08) VALUE '14041512'**
- **V                   15  FILLER PIC X(08) VALUE '140416XX'**
- **V                   15  FILLER PIC X(08) VALUE '140509XX'**
- **V                   15  FILLER PIC X(08) VALUE '14051350'**
- **V                   15  FILLER PIC X(08) VALUE '14051512'**
- **V                   15  FILLER PIC X(08) VALUE '140516XX'**
- **V                   15  FILLER PIC X(08) VALUE '15XX0202'**
- **V                   15  FILLER PIC X(08) VALUE '18019999'**
- **V                   15  FILLER PIC X(08) VALUE '18029999'**
- **V                   15  FILLER PIC X(08) VALUE '19019999'**
- **V                   15  FILLER PIC X(08) VALUE '19029999'**
- **V                   15  FILLER PIC X(08) VALUE '19039999'**
- **V                   15  FILLER PIC X(08) VALUE '19049999'**
- **V                   15  FILLER PIC X(08) VALUE '19989999'**
- **V                   15  FILLER PIC X(08) VALUE '19999999'**
- **V           05  TB-TIPOS-VAL01  REDEFINES TB-OP1-COMB**
- **V               10  TB-GR-TIPOS01 OCCURS 27 INDEXED BY IN-OPC01A**
- **V                   15  TB-EL-TIPOS01       PIC X(04)**
- **V                   15  FILLER              PIC X(04)**
- **V           05  TB-COMB-TP-MOD  REDEFINES TB-OP1-COMB**
- **V               10  TB-TIPO-MODAL OCCURS 27 INDEXED BY IN-OPC01B**
- **V                   15  TB-TP-MOD           PIC X(08)**
- **V      *--- OPCAO 02 - BAT 2: TIPO SUB CONTRA NATUREZA**
- **V           05  TB-OP2-COMB**
- **V                   15  FILLER PIC X(06) VALUE '010104'**
- **V                   15  FILLER PIC X(06) VALUE '010211'**
- **V                   15  FILLER PIC X(06) VALUE '010311'**
- **V                   15  FILLER PIC X(06) VALUE '010411'**
- **V                   15  FILLER PIC X(06) VALUE '010504'**
- **V                   15  FILLER PIC X(06) VALUE '070105'**
- **V                   15  FILLER PIC X(06) VALUE '070213'**
- **V                   15  FILLER PIC X(06) VALUE '070214'**
- **V                   15  FILLER PIC X(06) VALUE '070215'**
- **V                   15  FILLER PIC X(06) VALUE '070313'**
- **V                   15  FILLER PIC X(06) VALUE '070314'**
- **V                   15  FILLER PIC X(06) VALUE '070315'**
- **V                   15  FILLER PIC X(06) VALUE '070413'**
- **V                   15  FILLER PIC X(06) VALUE '070414'**
- **V                   15  FILLER PIC X(06) VALUE '070415'**
- **V                   15  FILLER PIC X(06) VALUE '070513'**
- **V                   15  FILLER PIC X(06) VALUE '070514'**
- **V                   15  FILLER PIC X(06) VALUE '070515'**
- **V                   15  FILLER PIC X(06) VALUE '070613'**
- **V                   15  FILLER PIC X(06) VALUE '070614'**
- **V                   15  FILLER PIC X(06) VALUE '070615'**
- **V                   15  FILLER PIC X(06) VALUE '070713'**
- **V                   15  FILLER PIC X(06) VALUE '070714'**
- **V                   15  FILLER PIC X(06) VALUE '070715'**
- **V                   15  FILLER PIC X(06) VALUE '100102'**
- **V1350               15  FILLER PIC X(06) VALUE '100201'**
- **V                   15  FILLER PIC X(06) VALUE '100203'**
- **V                   15  FILLER PIC X(06) VALUE '100312'**
- **V                   15  FILLER PIC X(06) VALUE '100316'**
- **V                   15  FILLER PIC X(06) VALUE '121213'**
- **V                   15  FILLER PIC X(06) VALUE '121214'**
- **V                   15  FILLER PIC X(06) VALUE '121215'**
- **V           05  TB-TIPOS-VAL02  REDEFINES TB-OP2-COMB**
- **V1350  *        10  TB-GR-TIPOS02 OCCURS 31 INDEXED BY IN-OPC02A**
- **V1350           10  TB-GR-TIPOS02 OCCURS 32 INDEXED BY IN-OPC02A**
- **V                   15  TB-EL-TIPOS02       PIC X(04)**
- **V                   15  FILLER              PIC X(02)**
- **V           05  TB-COMB-TP-NAT REDEFINES TB-OP2-COMB**
- **V1350  *        10  TB-TIPO-NAT   OCCURS 31 INDEXED BY IN-OPC02B**
- **V1350           10  TB-TIPO-NAT   OCCURS 32 INDEXED BY IN-OPC02B**
- **V                   15  TB-TP-NAT           PIC X(06)**
- **V      *--- BOOKS**
- **V       LINKAGE                         SECTION**
- **V       01 LI-LHCE0700**
- **V           COPY LHCE0700**
- **V       PROCEDURE DIVISION     USING    LI-LHCE0700**
- **V      *--- CONTROLE PRINCIPAL**
- **V       R000-PRINCIPAL SECTION**
- **V           PERFORM R100-INICIO**
- **V           PERFORM R200-PROCESSA**
- **V           PERFORM R300-FINAL**
- **V      *--- PROCEDIMENTOS INICIAIS**
- **V       R100-INICIO**
- **V      *--- UNICO PONTO SETUP OK, A SEQUENCIA DECIDE QDO MUDAR ESTADO**
- **V           SET   LHCE0700-CD-RET-OK   TO TRUE**
- **V      *--- VALIDACAO DA OPCAO E DA AREA DE ENTRADA**
- **V           EVALUATE LHCE0700-NR-OPCAO**
- **V               WHEN CT-01**
- **V                    IF LHCE0700-TX-OPCAO1             NOT NUMERIC**
- **V                    OR LHCE0700-TX-OPCAO1           EQUAL ZEROS**
- **V                       SET     LHCE0700-CD-RET-ERR     TO TRUE**
- **V                       PERFORM R300-FINAL**
- **V                    END-IF**
- **V               WHEN CT-02**
- **V                    IF LHCE0700-TX-OP2-TIPOSUB        NOT NUMERIC**
- **V                    OR LHCE0700-TX-OP2-TIPOSUB      EQUAL ZEROS**
- **V                    IF LHCE0700-TX-OP2-NAT            NOT NUMERIC**
- **V                    OR LHCE0700-TX-OP2-NAT          EQUAL ZEROS**
- **V               WHEN OTHER**
- **V                    SET     LHCE0700-CD-RET-ERR        TO TRUE**
- **V                    PERFORM R300-FINAL**
- **V      *--- LINHAS GERAIS PROCESSAMENTO**
- **V       R200-PROCESSA**
- **V           MOVE     LHCE0700-TX-ENTRADA TO WS-TX-ENTRADA**
- **V                    PERFORM R210-PROCESSA-OPCAO-01**
- **V                    PERFORM R220-PROCESSA-OPCAO-02**
- **V                    CONTINUE**
- **V      *--- PROCESSA OPCAO 01 - TIPO SUBTIPO CONTRA MODAL**
- **V       R210-PROCESSA-OPCAO-01**
- **V      *    TRATAMENTO PARA CONVERTER PARA "XX" QUANDO FOR ACEITO**
- **V      *    QUALQUER VALOR**
- **V           EVALUATE TRUE**
- **V               WHEN WS-TX-OP1-TIPOSUBTIPO   EQUAL CT-1402   AND**
- **V                    WS-TX-OP1-MOD           EQUAL CT-08**
- **V                    WS-TX-OP1-MOD           EQUAL CT-16**
- **V               WHEN WS-TX-OP1-TIPOSUBTIPO   EQUAL CT-1404   AND**
- **V               WHEN WS-TX-OP1-TIPOSUBTIPO   EQUAL CT-1405   AND**
- **V                    WS-TX-OP1-MOD           EQUAL CT-09**
- **V                    MOVE   CT-XX               TO WS-TX-OP1-MODSUB**
- **V               WHEN WS-TX-OP1-TP            EQUAL CT-15**
- **V                    MOVE   CT-XX               TO WS-TX-OP1-TPSUB**
- **V      *    SE ENCONTRAR TIPO NA LISTA "A", VERIFICA SE A COMBINACAO COM**
- **V      *    MODALIDADE EH VALIDA NA LISTA "B"**
- **V           SET    IN-OPC01A   TO   CT-01**
- **V+---->     SEARCH TB-GR-TIPOS01**
- **V|**
- **V|              AT END**
- **V|                 CONTINUE**
- **V|            WHEN TB-EL-TIPOS01(IN-OPC01A) EQUAL WS-TX-OP1-TIPOSUBTIPO**
- **V|                 SET    IN-OPC01B   TO   CT-01**
- **V| +-->            SEARCH TB-TIPO-MODAL**
- **V| |**
- **V| |                   AT END**
- **V| |                      SET     LHCE0700-CD-RET-NOK  TO  TRUE**
- **V| |                 WHEN TB-TP-MOD(IN-OPC01B) EQUAL WS-TX-OPCAO1**
- **V| |                      CONTINUE**
- **V| +-->            END-SEARCH**
- **V+---->     END-SEARCH**
- **V      *--- PROCESSA OPCAO 02 - TIPO SUBTIPO CONTRA NATUREZA**
- **V       R220-PROCESSA-OPCAO-02**
- **V      *    NATUREZA EH VALIDA NA LISTA "B"**
- **V           SET    IN-OPC02A   TO   CT-01**
- **V+---->     SEARCH TB-GR-TIPOS02**
- **V|            WHEN TB-EL-TIPOS02(IN-OPC02A)  EQUAL WS-TX-OP1-TIPOSUBTIPO**
- **V|                 SET    IN-OPC02B   TO   CT-01**
- **V| +-->            SEARCH TB-TIPO-NAT**
- **V| |                 WHEN TB-TP-NAT(IN-OPC02B) EQUAL WS-TX-OP2-TPSUBNAT**
- **V       R300-FINAL**
- **VMEMBER NAME  MZAN6056**
- **V       PROGRAM-ID.    MZAN6056**
- **V      * OBJETIVOS DO PROGRAMA:                                         ***
- **V      *    - RECUPERAR INFORMACOES DA OPERACAO NO MQ12 DO MES ANTERIOR ***
- **V      * ALTERACOES:                                                    ***
- **V      * -------------------------------------------------------------- ***
- **V      * AUTOR       DATA        OBJETIVO                               ***
- **2014  ACERTO ERRO FINANCEIRA                 ***
- **2014  CAMPOS NOVOS FLUXO FINANCEIRO          ***
- **2015  INCLUSAO DA INTERFACE MP, NA           ***
- **VVS002 *                         RECUPERACAO DE INFORMACOES NO MQ12**
- **V      *-----------------------------------------------------------------**
- **VNVRGAC*                                                                ***
- **15   VECTOR        PROJETO NOVAS REGRAS DE ACORDO          ***
- **VNVRGAC*                        INCLUSAO DE NOVAS VARIAVEIS NO BOOK**
- **VNVRGAC*                        MZCE5113, AUMENTANDO SEU TAMANHO PARA   ***
- **VNVRGAC*                        1600 BYTES**
- **VNVRGAC*                        ESTE PROGRAMA NAO FOI ALTERADO          ***
- **VNVRGAC*                        EFETUAMOS APENAS UMA COMPILACAO PARA    ***
- **VNVRGAC*                        INCORPORAR A NOVA VERSAO DO BOOK        ***
- **VNVRGAC*                        MZCE5113**
- **2016  RECOMPIL MZCE5113                      ***
- **2016  ALTERAR "MP" PARA M1, M3, M4 E M5      ***
- **2018  ACERTO RATING REFERENCIA DO LY         ***
- **2019  INCLUSAO DO CAMPO DE PARCELAS PAGAS    ***
- **VSPRT28*                         DO MES ANTERIOR                        ***
- **2019  NAO CANCELAR POR AQUIVO VAZIO          ***
- **2019  RATING MES ANTERIOR AJUSTADO           ***
- **2019  EXPANSAO DO BOOK 6001                  ***
- **2021  AUDITORIA DO GR                        ***
- **2021  INCLUSAO DA NOVA SIGLA MP06 (M6)       ***
- **2025  INCLUSAO PLARD ON01 - O1               ***
- **V       CONFIGURATION SECTION**
- **V           DECIMAL-POINT  IS  COMMA**
- **V       INPUT-OUTPUT SECTION**
- **V           SELECT E1DQ6056 ASSIGN E1DQ6056**
- **V           SELECT E2DQ6056 ASSIGN E2DQ6056**
- **V           SELECT S1DQ6056 ASSIGN S1DQ6056**
- **V       DATA DIVISION**
- **V       FD  E1DQ6056**
- **V           LABEL RECORD           STANDARD**
- **V           BLOCK                  0 RECORDS**
- **V           RECORDING MODE         F**
- **V       01        REG-E1DQ6056**
- **V       ++INCLUDE MZCE6001**
- **V       FD  E2DQ6056**
- **V       01        REG-E2DQ6056**
- **V       ++INCLUDE MZCE5113**
- **V       FD  S1DQ6056**
- **VCMP04  01          REG-S1DQ6056        PIC  X(2000)**
- **V       WORKING-STORAGE SECTION**
- **V       77          AC-LIDOS-E1DQ6056   PIC  9(10)  VALUE  ZEROS**
- **V       77          AC-LIDOS-E2DQ6056   PIC  9(10)  VALUE  ZEROS**
- **V       77          AC-GRAVADOS         PIC  9(10)  VALUE  ZEROS**
- **V       01          WS-CHAVE-E1DQ6056**
- **V         03        WS-NRO-OPR-6001     PIC  X(33)**
- **V         03        WS-CD-HB-6001       PIC  9(04)**
- **V         03        WS-CD-SIS-6001      PIC  X(02)**
- **V         03        WS-CD-EMP-6001      PIC  9(04)**
- **V      *  03        WS-ST-ACD-6001      PIC  9(01)**
- **V       01          WS-CHAVE-E2DQ6056**
- **V         03        WS-NRO-OPR-5113     PIC  X(33)**
- **V         03        WS-CD-HB-5113       PIC  9(04)**
- **V         03        WS-CD-SIS-5113      PIC  X(02)**
- **V         03        WS-CD-EMP-5113      PIC  9(04)**
- **V      *  03        WS-ST-ACD-5113      PIC  9(01)**
- **V       01          FILLER  REDEFINES  WS-DT-ACORDO-MZ13**
- **V         03        WS-MES-ACO-MZ13     PIC  9(02)**
- **V         03        WS-DIA-ACO-MZ13     PIC  9(02)**
- **V         03        WS-ANO-ACO-MZ13     PIC  9(04)**
- **V       01          WS-DT-ACORDO        PIC  9(08)**
- **V       01          FILLER  REDEFINES  WS-DT-ACORDO**
- **V         03        WS-ANO-ACORDO       PIC  9(04)**
- **V         03        WS-MES-ACORDO       PIC  9(02)**
- **V         03        WS-DIA-ACORDO       PIC  9(02)**
- **V       PROCEDURE DIVISION**
- **V      *           M  O  D  U  L  O         M  E  S  T  R  E            ***
- **V       000-00-MODULO-MESTRE  SECTION**
- **V           PERFORM  800-00-INICIALIZA**
- **V           PERFORM  100-00-PROCESSAMENTO**
- **V               UNTIL  WS-CHAVE-E1DQ6056  EQUAL HIGH-VALUES**
- **V           PERFORM  700-00-FINALIZA**
- **V       000-99-FIM**
- **V           EXIT**
- **V           EJECT**
- **V      *             P  R  O  C  E  S  S  A  M  E  N  T  O              ***
- **V       100-00-PROCESSAMENTO  SECTION**
- **VVS003      IF  CD-SIS-ORI-6001        EQUAL  'LY' OR 'M1' OR 'M3'**
- **VVS003                                             OR 'M4' OR 'M5'**
- **VCMP05                                             OR 'GR' OR 'M6'**
- **VPLARD                                             OR 'O1'**
- **V               IF  WS-CHAVE-E1DQ6056  EQUAL  WS-CHAVE-E2DQ6056**
- **V                   PERFORM  110-00-MOVER-CAMPOS**
- **V                   PERFORM  500-00-GRAVA-S1DQ6056**
- **V                   PERFORM  610-00-LE-E1DQ6056**
- **V                   PERFORM  620-00-LE-E2DQ6056**
- **V                   IF  WS-CHAVE-E1DQ6056  LESS  WS-CHAVE-E2DQ6056**
- **V                       PERFORM  120-00-ZERAR-CAMPOS**
- **V                       PERFORM  500-00-GRAVA-S1DQ6056**
- **V                       PERFORM  610-00-LE-E1DQ6056**
- **V                   ELSE**
- **V                       PERFORM  620-00-LE-E2DQ6056**
- **V                   END-IF**
- **V               PERFORM  120-00-ZERAR-CAMPOS**
- **V               PERFORM  500-00-GRAVA-S1DQ6056**
- **V               PERFORM  610-00-LE-E1DQ6056**
- **V       100-99-EXIT**
- **V      * MOVIMENTAR CAMPOS DO MQ12 MES-ANT PARA O MOVIMENTO ATUAL       ***
- **V       110-00-MOVER-CAMPOS   SECTION**
- **V           MOVE  QT-DIA-ATR-MZ13    TO QT-ATR-ACO-MES-ANT-6001**
- **V           MOVE  PC-AMO-RENEG-MZ13  TO PC-PAG-ACO-MES-ANT-6001**
- **V           MOVE  IN-ACORDO-MZ13     TO ST-ACD-MES-ANT-6001**
- **VSPRT28     MOVE  QT-PARC-PAG-ACD-MZ13 TO PAR-PAG-ACD-MES-ANT-6001**
- **VCMP05      MOVE  CD-RGR-RAT-OPE-MZ13  TO CD-RGR-RAT-OPE-ANT-6001**
- **V           MOVE  DT-ACORDO-MZ13     TO WS-DT-ACORDO-MZ13**
- **V           MOVE  WS-DIA-ACO-MZ13    TO WS-DIA-ACORDO**
- **V           MOVE  WS-MES-ACO-MZ13    TO WS-MES-ACORDO**
- **V           MOVE  WS-ANO-ACO-MZ13    TO WS-ANO-ACORDO**
- **V           IF    WS-DT-ACORDO    EQUAL DT-ACO-6001  AND**
- **VCMP02           (CD-RAT-REFER-MZ13 NOT LESS 01      AND**
- **VCMP02            CD-RAT-REFER-MZ13 NOT GREATER 09)**
- **V                 MOVE 'S'               TO  IN-MSM-ACO-6001**
- **V                 MOVE CD-RAT-REFER-MZ13 TO  CD-RAT-REF-6001**
- **V                 MOVE 'N'               TO  IN-MSM-ACO-6001**
- **V                 EVALUATE CD-RAT-CAC-MZ13**
- **V                     WHEN 'AA'**
- **V                          MOVE 09       TO  CD-RAT-REF-6001**
- **V                     WHEN 'A '**
- **V                          MOVE 08       TO  CD-RAT-REF-6001**
- **V                     WHEN 'B '**
- **V                          MOVE 07       TO  CD-RAT-REF-6001**
- **V                     WHEN 'C '**
- **V                          MOVE 06       TO  CD-RAT-REF-6001**
- **V                     WHEN 'D '**
- **V                          MOVE 05       TO  CD-RAT-REF-6001**
- **V                     WHEN 'E '**
- **V                          MOVE 04       TO  CD-RAT-REF-6001**
- **V                     WHEN 'F '**
- **V                          MOVE 03       TO  CD-RAT-REF-6001**
- **V                     WHEN 'G '**
- **V                          MOVE 02       TO  CD-RAT-REF-6001**
- **V                     WHEN 'H '**
- **V                          MOVE 01       TO  CD-RAT-REF-6001**
- **V                     WHEN    OTHER**
- **V                 END-EVALUATE**
- **V           PERFORM  630-00-CONVERTE-RATING**
- **V       110-99-EXIT**
- **V      * INICIALIZA CAMPOS DO MQ12 MES-ANT PARA O MOVIMENTO ATUAL       ***
- **V       120-00-ZERAR-CAMPOS   SECTION**
- **VCMP01      IF  CD-CLF-MESANT-6001   EQUAL ZEROS**
- **VCMP01          MOVE  99             TO CD-CLF-MESANT-6001**
- **VCMP01      END-IF**
- **V           MOVE  ZEROS              TO QT-ATR-ACO-MES-ANT-6001**
- **V                                       PC-PAG-ACO-MES-ANT-6001**
- **V                                       ST-ACD-MES-ANT-6001**
- **V                                       PAR-PAG-ACD-MES-ANT-6001**
- **VCMP05      MOVE  SPACES             TO CD-RGR-RAT-OPE-ANT-6001**
- **VCMP05      IF  CD-SIS-ORI-6001  EQUAL  'GR'  AND**
- **VCMP05          CD-TIP-NEG-6001  NOT EQUAL  ZEROS**
- **VCMP05          MOVE  05             TO CD-CLF-MESANT-6001**
- **VCMP05                                  CD-RAT-REF-6001**
- **VCMP05      END-IF**
- **V           IF  CD-SIS-ORI-6001  EQUAL  'LY'**
- **V               MOVE  05                 TO CD-RAT-REF-6001**
- **V       120-99-EXIT**
- **V      *               ROTINA  DE  GRAVACAO  DO  ARQUIVO                ***
- **V       500-00-GRAVA-S1DQ6056  SECTION**
- **V           WRITE  REG-S1DQ6056  FROM  REG-E1DQ6056**
- **V           ADD  1  TO  AC-GRAVADOS**
- **V       500-99-EXIT**
- **V      *            ROTINA  DE  LEITURA  DO  ARQUIVO  DE INTERFACE      ***
- **V       610-00-LE-E1DQ6056  SECTION**
- **V           READ  E1DQ6056**
- **V               AT  END  MOVE  HIGH-VALUES  TO  WS-CHAVE-E1DQ6056**
- **V           IF WS-CHAVE-E1DQ6056 NOT EQUAL HIGH-VALUES**
- **V              ADD   1                 TO  AC-LIDOS-E1DQ6056**
- **V              MOVE  NR-OPR-6001       TO  WS-NRO-OPR-6001**
- **V              MOVE  CD-HB-6001        TO  WS-CD-HB-6001**
- **V              MOVE  CD-SIS-ORI-6001   TO  WS-CD-SIS-6001**
- **V              MOVE  CD-EMP-6001       TO  WS-CD-EMP-6001**
- **V      *       MOVE  ST-ACD-6001       TO  WS-ST-ACD-6001**
- **V       610-99-EXIT**
- **V      *            ROTINA  DE  LEITURA  DO  ARQUIVO  DO  MZ            ***
- **V       620-00-LE-E2DQ6056 SECTION**
- **V           READ  E2DQ6056**
- **V               AT  END  MOVE  HIGH-VALUES  TO  WS-CHAVE-E2DQ6056**
- **V           IF   WS-CHAVE-E2DQ6056 NOT EQUAL HIGH-VALUES**
- **V                ADD        1            TO  AC-LIDOS-E2DQ6056**
- **V                MOVE  CD-OPR-CDT-MZ13   TO  WS-NRO-OPR-5113**
- **V                MOVE  CD-PS-MZ13        TO  WS-CD-HB-5113**
- **V                MOVE  CD-SIS-MZ13       TO  WS-CD-SIS-5113**
- **V                MOVE  CD-EMP-MZ13       TO  WS-CD-EMP-5113**
- **V      *         MOVE  IN-ACORDO-MZ13    TO  WS-ST-ACD-5113**
- **V       620-99-EXIT**
- **V      *    CONVERTER RATING DE ALFA NUMERICO PARA NUMERICO             ***
- **V       630-00-CONVERTE-RATING  SECTION**
- **VCMP03      IF  CD-RAT-OPER-AJUSTADO-MZ13          EQUAL 'AA'**
- **VCMP03 *    IF  CD-CLF-OPR-MZ13  EQUAL 'AA'**
- **V               MOVE 09                            TO CD-CLF-MESANT-6001**
- **VCMP03       IF CD-RAT-OPER-AJUSTADO-MZ13          EQUAL 'A '**
- **V               MOVE 08                            TO CD-CLF-MESANT-6001**
- **V            ELSE**
- **VCMP03        IF CD-RAT-OPER-AJUSTADO-MZ13         EQUAL 'B '**
- **V                MOVE 07                           TO CD-CLF-MESANT-6001**
- **V             ELSE**
- **VCMP03         IF CD-RAT-OPER-AJUSTADO-MZ13        EQUAL 'C '**
- **V                 MOVE 06                          TO CD-CLF-MESANT-6001**
- **VCMP03          IF CD-RAT-OPER-AJUSTADO-MZ13       EQUAL 'D '**
- **V                  MOVE 05                         TO CD-CLF-MESANT-6001**
- **VCMP03           IF CD-RAT-OPER-AJUSTADO-MZ13      EQUAL 'E '**
- **V                   MOVE 04                        TO CD-CLF-MESANT-6001**
- **V                ELSE**
- **VCMP03              IF CD-RAT-OPER-AJUSTADO-MZ13   EQUAL 'F '**
- **V                      MOVE 03                     TO CD-CLF-MESANT-6001**
- **VCMP03               IF CD-RAT-OPER-AJUSTADO-MZ13  EQUAL 'G '**
- **V                       MOVE 02                    TO CD-CLF-MESANT-6001**
- **V                    ELSE**
- **VCMP03                IF CD-RAT-OPER-AJUSTADO-MZ13 EQUAL 'H '**
- **V                        MOVE 01         TO CD-CLF-MESANT-6001**
- **V                     ELSE**
- **V                        MOVE 99         TO CD-CLF-MESANT-6001**
- **V                     END-IF**
- **V             END-IF**
- **V            END-IF**
- **VCMP05      IF  CD-SIS-ORI-6001               EQUAL  'GR'  AND**
- **VCMP05          CD-TIP-NEG-6001           NOT EQUAL  ZEROS**
- **VCMP05          IF  DT-REN-CTR-6001(1:6)  NOT EQUAL  DT-BSE-6001(1:6)**
- **VCMP05              EVALUATE CD-RAT-CAC-MZ13**
- **VCMP05                WHEN 'AA'**
- **VCMP05                      MOVE 09       TO  CD-CLF-MESANT-6001**
- **VCMP05                WHEN 'A '**
- **VCMP05                      MOVE 08       TO  CD-CLF-MESANT-6001**
- **VCMP05                WHEN 'B '**
- **VCMP05                      MOVE 07       TO  CD-CLF-MESANT-6001**
- **VCMP05                WHEN 'C '**
- **VCMP05                      MOVE 06       TO  CD-CLF-MESANT-6001**
- **VCMP05                WHEN 'D '**
- **VCMP05                      MOVE 05       TO  CD-CLF-MESANT-6001**
- **VCMP05                WHEN 'E '**
- **VCMP05                      MOVE 04       TO  CD-CLF-MESANT-6001**
- **VCMP05                WHEN 'F '**
- **VCMP05                      MOVE 03       TO  CD-CLF-MESANT-6001**
- **VCMP05                WHEN 'G '**
- **VCMP05                      MOVE 02       TO  CD-CLF-MESANT-6001**
- **VCMP05                WHEN 'H '**
- **VCMP05                      MOVE 01       TO  CD-CLF-MESANT-6001**
- **VCMP05                WHEN    OTHER**
- **VCMP05                      MOVE 99       TO  CD-CLF-MESANT-6001**
- **VCMP05              END-IF**
- **V       630-99-EXIT**
- **V      *           F   I   N   A   L   I   Z   A   C   A   O            ***
- **V       700-00-FINALIZA  SECTION**
- **V           CLOSE  E1DQ6056**
- **V                  E2DQ6056**
- **V                  S1DQ6056**
- **V           DISPLAY '*********************************************'**
- **V           DISPLAY 'REGISTROS LIDOS E1DQ6056 ....**
- **V           DISPLAY 'REGISTROS LIDOS E2DQ6056 ....**
- **V           DISPLAY 'REGISTROS GRAVADOS ..........**
- **V           DISPLAY '*** PROGRAMA MZAN6055 ***'**
- **V           DISPLAY '***  TERMINO  NORMAL  ***'**
- **V           DISPLAY '*************************'**
- **V           STOP RUN**
- **V       700-99-EXIT**
- **V      *       I   N   I   C   I   A   L   I   Z   A   C   A   O        ***
- **V       800-00-INICIALIZA  SECTION**
- **V           DISPLAY '*         PROGRAMA  MZAN6056         *'**
- **V           OPEN  INPUT   E1DQ6056**
- **V                         E2DQ6056**
- **V                 OUTPUT  S1DQ6056**
- **V           PERFORM  610-00-LE-E1DQ6056**
- **V           IF  WS-CHAVE-E1DQ6056 EQUAL HIGH-VALUES**
- **V               DISPLAY  '*********************************'**
- **V               DISPLAY  '**  A  T  E  N  C  A  O  !  !  **'**
- **V               DISPLAY  'ARQUIVO E1DQ6056 VAZIO'**
- **V               DISPLAY  '*********************'**
- **V               DISPLAY  '* PROGRAMA MZAN6055 *'**
- **VSPRT31         DISPLAY  '*  TERMINO  NORMAL  *'**
- **VSPRT31         PERFORM  700-00-FINALIZA**
- **VSPRT31*        PERFORM  900-00-FIM-ANORMAL**
- **V           PERFORM  620-00-LE-E2DQ6056**
- **V           IF  WS-CHAVE-E2DQ6056 EQUAL HIGH-VALUES**
- **V               DISPLAY  'ARQUIVO E2DQ6056 VAZIO'**
- **V               DISPLAY  '* PROGRAMA MZAN6056 *'**
- **V               DISPLAY  '*  TERMINO ANORMAL  *'**
- **V               PERFORM  900-00-FIM-ANORMAL**
- **V       800-99-FIM**
- **V      *   T   E   R   M   I   N   O        A   N   O   R   M   A   L   ***
- **V       900-00-FIM-ANORMAL SECTION**
- **V           STOP  RUN**
- **V       900-99-EXIT**


### ⚠ Programas Não Parseados
*Nenhum programa nesta categoria*


### ⚠ Programas Não Analisados
- **LHAN0542**
- **LHAN0705**
- **LHAN0706**
- **LHBR0700**
- **MZAN6056**


### ⚠ Programas Não Documentados
*Nenhum programa nesta categoria*


###  Programas com Erro
*Nenhum programa com erro*


---

## Análise de Dependências

### Estatísticas de Dependências

| Tipo de Dependência | Quantidade |
|---------------------|------------|
| FILE | 29 |
| COPY | 6 |
| CALL | 19 |
| **Total** | **54** |

### Detalhamento de Dependências

| Programa Origem | Programa Destino | Tipo | Linha | Contexto |
|-----------------|------------------|------|-------|----------|
| LHAN0542 | LHS542S3 | FILE | 25 | V689542**      *          *          * - NOVO FD L... |
| LHAN0542 | LHS542E5 | FILE | 67 | VRESPON     SELECT  LHS542E5  ASSIGN  TO  LHS542E5... |
| LHAN0542 | LHS542E1 | FILE | 83 | V       FD  LHS542E1                              ... |
| LHAN0542 | LHS542E2 | FILE | 92 | V       FD  LHS542E2                              ... |
| LHAN0542 | LHS542E3 | FILE | 106 | V       FD  LHS542E3                              ... |
| LHAN0542 | LHS542E4 | FILE | 112 | V       FD  LHS542E4                              ... |
| LHAN0542 | LHS542E5 | FILE | 130 | VRESPON FD  LHS542E5... |
| LHAN0542 | MZTCM530 | COPY | 134 | VRESPON     COPY    MZTCM530.... |
| LHAN0542 | LHS542S1 | FILE | 136 | V       FD  LHS542S1                              ... |
| LHAN0542 | LHS542S2 | FILE | 142 | V       FD  LHS542S2                              ... |
| LHAN0542 | LHS542S3 | FILE | 148 | V689542 FD  LHS542S3                              ... |
| LHAN0542 | WDRAM0082 | CALL | 678 | V           CALL     WDRAM0082            USING  W... |
| LHAN0542 | WDRAM0082 | CALL | 708 | V           CALL     WDRAM0082            USING  W... |
| LHAN0542 | WDRAM0082 | CALL | 753 | V           CALL     WDRAM0082            USING  W... |
| LHAN0542 | WDRAM0082 | CALL | 782 | V           CALL     WDRAM0082  USING  WAREA-82... |
| LHAN0542 | WDRAM0082 | CALL | 901 | V           CALL    WDRAM0082  USING  WAREA-82... |
| LHAN0542 | WDRAM0082 | CALL | 1101 | VSPR004     CALL     WDRAM0082            USING  W... |
| LHAN0542 | WDRAM0082 | CALL | 1131 | VSPR004     CALL     WDRAM0082            USING  W... |
| LHAN0542 | WDRAM0082 | CALL | 1152 | VSPR004     CALL    WDRAM0082  USING  WAREA-82... |
| LHAN0542 | WDRAM0082 | CALL | 1223 | V689542*    CALL    WDRAM0082  USING  WAREA-82... |
| ... | ... | ... | ... | *+34 dependências* |


---

## Detalhes dos Programas

| Programa | Encontrado | Parseado | Analisado | Documentado | Tamanho | Linhas |
|----------|------------|----------|-----------|-------------|---------|--------|
| ----+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----8 |  |  |  |  | N/A | N/A |
| VMEMBER NAME  LHAN0542 |  |  |  |  | N/A | N/A |
| V       IDENTIFICATION                  DIVISION |  |  |  |  | N/A | N/A |
| V      *---------------------------------------------------------------* |  |  |  |  | N/A | N/A |
| V       PROGRAM-ID.     LHAN0542 |  |  |  |  | N/A | N/A |
| GPTI |  |  |  |  | N/A | N/A |
| 11 |  |  |  |  | N/A | N/A |
| V       DATE-COMPILED |  |  |  |  | N/A | N/A |
| V      *REMARKS |  |  |  |  | N/A | N/A |
| V      ******************** OBJETIVO DO PROGRAMA *********************** |  |  |  |  | N/A | N/A |
| V      *** PARTICIONAR ARQUIVO BACEN DOC3040                          ** |  |  |  |  | N/A | N/A |
| V      **  SERAO GERADOS ARQUIVOS PARTICIONADOS DINAMICAMENTE         ** |  |  |  |  | N/A | N/A |
| TRANSMISSAO            ** |  |  |  |  | N/A | N/A |
| V      ***************************************************************** |  |  |  |  | N/A | N/A |
| V      **      *          *          *                                ** |  |  |  |  | N/A | N/A |
| V      **VERSAO*   DATA   *  AUTOR   *            MOTIVO              ** |  |  |  |  | N/A | N/A |
| 11 * EDIVALDO * NOVO                           ** |  |  |  |  | N/A | N/A |
| 14 * MARCELLO * - PARTICIONAMENTO 4000 MB      ** |  |  |  |  | N/A | N/A |
| V689542**      *          *          * - LIMITE PARTICOES:            ** |  |  |  |  | N/A | N/A |
| V689542**      *          *          * |  |  |  |  | N/A | N/A |
| V689542**      *          *          * - ADAPTACAO > 10 PARTES        ** |  |  |  |  | N/A | N/A |
| V689542**      *          *          * - NOVO FD LHS542S3 (DENE0530)  ** |  |  |  |  | N/A | N/A |
| 15 *  ROBERTO * PROJETO DADOS RESPONSAVEL       * |  |  |  |  | N/A | N/A |
| VRESPON*       *          *          * INCLUSAO DE TRATAM PARA TAB     * |  |  |  |  | N/A | N/A |
| VRESPON*       *          *          * MZTCM530-DADOS RESPONS CADOC3040* |  |  |  |  | N/A | N/A |
| VSPR004*       *          *          * TRATAMENTO DE CADOC VAZIO       * |  |  |  |  | N/A | N/A |
| VSPR004*       *          *          * ALOCACAO DINAMICA               * |  |  |  |  | N/A | N/A |
| VSPRT11*       *          *          * TRATAMENTO DE CADOC BNDES       * |  |  |  |  | N/A | N/A |
| VSPRT18*       *          *          * TRATAMENTO RESPONSAVEL          * |  |  |  |  | N/A | N/A |
| VSPRT18*       *          *          * CADOC BNDES                     * |  |  |  |  | N/A | N/A |
| VSPRT18*       *          *          *                                 * |  |  |  |  | N/A | N/A |
| VSPRT60*       *          *  CABRAL  * RECOMPILACAO BOOK MZTCM530      * |  |  |  |  | N/A | N/A |
| VSPRT60*       *          *          * MZM530-FONE-RESP E XML1-DOCI-TEL* |  |  |  |  | N/A | N/A |
| 11 POSICOES             * |  |  |  |  | N/A | N/A |
| 25* |  |  |  |  | N/A | N/A |
| VSPRT82*       *          *          * METODAPPE="C" METODDIFTJE="S"   * |  |  |  |  | N/A | N/A |
| V       ENVIRONMENT                     DIVISION |  |  |  |  | N/A | N/A |
| V      * |  |  |  |  | N/A | N/A |
| V       CONFIGURATION              SECTION |  |  |  |  | N/A | N/A |
| V       SPECIAL-NAMES |  |  |  |  | N/A | N/A |
| V           DECIMAL-POINT  IS COMMA |  |  |  |  | N/A | N/A |
| V       INPUT-OUTPUT               SECTION |  |  |  |  | N/A | N/A |
| V       FILE-CONTROL |  |  |  |  | N/A | N/A |
| V           SELECT  LHS542E1  ASSIGN  LHS542E1 |  |  |  |  | N/A | N/A |
| V                   FILE      STATUS  IS  FS-LH542E1 |  |  |  |  | N/A | N/A |
| V           SELECT  LHS542E2  ASSIGN  LHS542E2 |  |  |  |  | N/A | N/A |
| V                   FILE      STATUS  IS  FS-LH542E2 |  |  |  |  | N/A | N/A |
| V           SELECT  LHS542E3  ASSIGN  LHS542E3 |  |  |  |  | N/A | N/A |
| V                   FILE      STATUS  IS  FS-LH542E3 |  |  |  |  | N/A | N/A |
| V           SELECT  LHS542E4  ASSIGN  LHS542E4 |  |  |  |  | N/A | N/A |
| V                   FILE      STATUS  IS  FS-LH542E4 |  |  |  |  | N/A | N/A |
| VRESPON     SELECT  LHS542E5  ASSIGN  TO  LHS542E5 |  |  |  |  | N/A | N/A |
| VRESPON             FILE      STATUS  IS  FS-LH542E5 |  |  |  |  | N/A | N/A |
| V           SELECT  LHS542S1  ASSIGN  LHS542S1 |  |  |  |  | N/A | N/A |
| V                   FILE      STATUS  IS  FS-LH542S1 |  |  |  |  | N/A | N/A |
| V           SELECT  LHS542S2  ASSIGN  LHS542S2 |  |  |  |  | N/A | N/A |
| V                   FILE      STATUS  IS  FS-LH542S2 |  |  |  |  | N/A | N/A |
| V           SELECT  LHS542S3  ASSIGN  LHS542S3 |  |  |  |  | N/A | N/A |
| V       DATA                            DIVISION |  |  |  |  | N/A | N/A |
| V       FILE                       SECTION |  |  |  |  | N/A | N/A |
| V       FD  LHS542E1                                                      000730 |  |  |  |  | N/A | N/A |
| V           BLOCK 0 RECORDS |  |  |  |  | N/A | N/A |
| V           RECORDING MODE F |  |  |  |  | N/A | N/A |
| V      *                                                                   000760 |  |  |  |  | N/A | N/A |
| V       01  REG-ENT1542 |  |  |  |  | N/A | N/A |
| V           05  TOT-LIDOS           PIC  9(015) |  |  |  |  | N/A | N/A |
| V           05  TOT-PARTIC          PIC  9(003) |  |  |  |  | N/A | N/A |
| V           05  FILLER              PIC  X(062) |  |  |  |  | N/A | N/A |
| V       FD  LHS542E2                                                      000730 |  |  |  |  | N/A | N/A |
| V       01  REG-ENT2542 |  |  |  |  | N/A | N/A |
| V           05  ID-CLIENTE          PIC  X(006) |  |  |  |  | N/A | N/A |
| V           05  FILLER              PIC  X(045) |  |  |  |  | N/A | N/A |
| V           05  NR-REMESSA          PIC  9(001) |  |  |  |  | N/A | N/A |
| V           05  FILLER              PIC  X(009) |  |  |  |  | N/A | N/A |
| V           05  NR-PARTE            PIC  9(001) |  |  |  |  | N/A | N/A |
| V           05  FILLER              PIC  X(002) |  |  |  |  | N/A | N/A |
| V           05  TP-ARQUIVO          PIC  X(010) |  |  |  |  | N/A | N/A |
| V           05  FILLER              PIC  X(026) |  |  |  |  | N/A | N/A |
| V       FD  LHS542E3                                                      000730 |  |  |  |  | N/A | N/A |
| V       01  REG-ENT3542             PIC  X(080) |  |  |  |  | N/A | N/A |
| V       FD  LHS542E4                                                      000730 |  |  |  |  | N/A | N/A |
| V       01  REG-ENTE04 |  |  |  |  | N/A | N/A |
| V           05  RELA-IDT            PIC  X(005) |  |  |  |  | N/A | N/A |
| V           05  RELA-QTDE           PIC  9(015) |  |  |  |  | N/A | N/A |
| V           05  FILLER              PIC  X(060) |  |  |  |  | N/A | N/A |
| VRESPON*----------------------------------------------------------------* |  |  |  |  | N/A | N/A |
| VRESPON* ENTRADA: LHS542E5                                              * |  |  |  |  | N/A | N/A |
| 15  * |  |  |  |  | N/A | N/A |
| VRESPON*    ARQUIVO  : LHS542E5                                         * |  |  |  |  | N/A | N/A |
| VRESPON*    DESCRICAO: DADOS DO RESPONSAVEL CADOC3040                   * |  |  |  |  | N/A | N/A |
| VRESPON*    TIPO     : SEQUENCIAL                                       * |  |  |  |  | N/A | N/A |
| VRESPON*    TAM.REG |  |  |  |  | N/A | N/A |
| VRESPON FD  LHS542E5 |  |  |  |  | N/A | N/A |
| VRESPON     RECORD  CONTAINS    154 CHARACTERS |  |  |  |  | N/A | N/A |
| VRESPON     BLOCK   CONTAINS    0    RECORDS |  |  |  |  | N/A | N/A |
| VRESPON     RECORDING MODE      F |  |  |  |  | N/A | N/A |
| VRESPON     COPY    MZTCM530 |  |  |  |  | N/A | N/A |
| V |  |  |  |  | N/A | N/A |
| V       FD  LHS542S1                                                      000730 |  |  |  |  | N/A | N/A |
| V       01  REG-SAI1542             PIC  X(100) |  |  |  |  | N/A | N/A |
| V       FD  LHS542S2                                                      000730 |  |  |  |  | N/A | N/A |
| V       01  REG-SAI2542             PIC  X(080) |  |  |  |  | N/A | N/A |
| V689542 FD  LHS542S3                                                      000730 |  |  |  |  | N/A | N/A |
| V689542     BLOCK 0 RECORDS |  |  |  |  | N/A | N/A |
| V689542     RECORDING MODE F |  |  |  |  | N/A | N/A |
| V689542*                                                                   000760 |  |  |  |  | N/A | N/A |
| V689542 01  REG-SAI3542 |  |  |  |  | N/A | N/A |
| V689542     03  S3-L1 |  |  |  |  | N/A | N/A |
| V689542         05  FILLER          PIC  X(011) |  |  |  |  | N/A | N/A |
| V689542         05  S3-L1-SEQ-N2    PIC  X(002) |  |  |  |  | N/A | N/A |
| V689542         05  FILLER          PIC  X(003) |  |  |  |  | N/A | N/A |
| V689542         05  S3-L1-LETRA     PIC  X(001) |  |  |  |  | N/A | N/A |
| V689542         05  FILLER          PIC  X(063) |  |  |  |  | N/A | N/A |
| V689542     03  S3-L2               REDEFINES    S3-L1 |  |  |  |  | N/A | N/A |
| V689542         05  S3-L2-FECHA     PIC  X(002) |  |  |  |  | N/A | N/A |
| V689542         05  FILLER          PIC  X(078) |  |  |  |  | N/A | N/A |
| V       WORKING-STORAGE            SECTION |  |  |  |  | N/A | N/A |
| V       01 WS-AREA-TRABALHO |  |  |  |  | N/A | N/A |
| V689542    03 WS-TEMP |  |  |  |  | N/A | N/A |
| V             05 WFIM-LH542E2            PIC  X(003) VALUE SPACES |  |  |  |  | N/A | N/A |
| V             05 WFIM-LH542E4            PIC  X(003) VALUE SPACES |  |  |  |  | N/A | N/A |
| VRESPON       05 WFIM-LH542E5            PIC  X(003) VALUE SPACES |  |  |  |  | N/A | N/A |
| V             05 FS-LH542E1              PIC  X(002) VALUE SPACES |  |  |  |  | N/A | N/A |
| V             05 FS-LH542E2              PIC  X(002) VALUE SPACES |  |  |  |  | N/A | N/A |
| V             05 FS-LH542E3              PIC  X(002) VALUE SPACES |  |  |  |  | N/A | N/A |
| V             05 FS-LH542E4              PIC  X(002) VALUE SPACES |  |  |  |  | N/A | N/A |
| VRESPON       05 FS-LH542E5              PIC  X(002) VALUE SPACES |  |  |  |  | N/A | N/A |
| V             05 FS-LH542S1              PIC  X(002) VALUE SPACES |  |  |  |  | N/A | N/A |
| V             05 FS-LH542S2              PIC  X(002) VALUE SPACES |  |  |  |  | N/A | N/A |
| V             05 WTOT-PART               PIC  9(003) VALUE ZEROS |  |  |  |  | N/A | N/A |
| V689542       05 WMAX-PART               PIC  9(012) |  |  |  |  | N/A | N/A |
| V             05 WTOT-LID                PIC  9(015) VALUE ZEROS |  |  |  |  | N/A | N/A |
| V             05 WTOT-REGIS              PIC  9(015) VALUE ZEROS |  |  |  |  | N/A | N/A |
| V             05 WTOT-GRAV               PIC  9(015) VALUE ZEROS |  |  |  |  | N/A | N/A |
| V             05 WTOT-CLI                PIC  9(015) VALUE ZEROS |  |  |  |  | N/A | N/A |
| V             05 WS-RELA-QTDE            PIC  9(015) VALUE ZEROS |  |  |  |  | N/A | N/A |
| DOC3040>' |  |  |  |  | N/A | N/A |
| V             05 WRETURN                 PIC  9(004) VALUE ZEROS |  |  |  |  | N/A | N/A |
| V             05 WFLAG-CABEC             PIC  X(003) VALUE SPACES |  |  |  |  | N/A | N/A |
| V             05 WSV-PARTE               PIC  9(003) VALUE ZEROS |  |  |  |  | N/A | N/A |
| V689542       05 WSV-PARTE-DEZENA        REDEFINES   WSV-PARTE |  |  |  |  | N/A | N/A |
| V689542          10 FILLER               PIC  9(001) |  |  |  |  | N/A | N/A |
| V689542          10 WSV-PARTE-D          PIC  9(002) |  |  |  |  | N/A | N/A |
| V689542       05 WSV-PARTE-UNIDADE       REDEFINES   WSV-PARTE |  |  |  |  | N/A | N/A |
| V689542          10 FILLER               PIC  9(002) |  |  |  |  | N/A | N/A |
| V689542          10 WSV-PARTE-U          PIC  9(001) |  |  |  |  | N/A | N/A |
| V             05 WSV-TPARQ-AUX           PIC  X(010) VALUE SPACES |  |  |  |  | N/A | N/A |
| V689542    03 WS-CABECS |  |  |  |  | N/A | N/A |
| V             05 WSV-CABEC1              PIC  X(100) VALUE SPACES |  |  |  |  | N/A | N/A |
| V             05 WSV-CABEC2 |  |  |  |  | N/A | N/A |
| V                10 FILLER               PIC  X(051) VALUE SPACES |  |  |  |  | N/A | N/A |
| V                10 WSV-REMES-AUX        PIC  9(001) VALUE ZEROS |  |  |  |  | N/A | N/A |
| V                10 FILLER               PIC  X(009) VALUE SPACES |  |  |  |  | N/A | N/A |
| V689542*         10 WSV-PARTE-AUX        PIC  9(001) VALUE ZEROS |  |  |  |  | N/A | N/A |
| V689542*         10 FILLER               PIC  X(002) VALUE SPACES |  |  |  |  | N/A | N/A |
| V689542*         10 WSV-TPARQ            PIC  X(010) VALUE SPACES |  |  |  |  | N/A | N/A |
| V689542*         10 FILLER               PIC  X(015) VALUE SPACES |  |  |  |  | N/A | N/A |
| V689542*         10 WSV-TOTCLI           PIC  9(009) VALUE ZEROS |  |  |  |  | N/A | N/A |
| V689542          10 WSV-C2               PIC  X(039) |  |  |  |  | N/A | N/A |
| V689542*---      CONTINUACAO FINAL DO CABEC2 - PARTE 1 A 9 |  |  |  |  | N/A | N/A |
| V689542       05 WSV-C2-P1 |  |  |  |  | N/A | N/A |
| V689542          10 WSV-C2-PAR-P1A       PIC  9(001) |  |  |  |  | N/A | N/A |
| V689542          10 WSV-C2-PAR-P1B       PIC  X(001) |  |  |  |  | N/A | N/A |
| V689542          10 FILLER               PIC  X(001) VALUE SPACES |  |  |  |  | N/A | N/A |
| V689542          10 WSV-C2-TPARQ-P1      PIC  X(010) |  |  |  |  | N/A | N/A |
| V689542          10 WSV-C2-TOTCLI-P1A    PIC  X(010) |  |  |  |  | N/A | N/A |
| V689542          10 WSV-C2-TOTCLI-P1B    PIC  9(009) |  |  |  |  | N/A | N/A |
| V689542          10 WSV-C2-TOTCLI-P1C    PIC  X(001) |  |  |  |  | N/A | N/A |
| V689542          10 FILLER               PIC  X(006) |  |  |  |  | N/A | N/A |
| V689542*---      CONTINUACAO FINAL DO CABEC2 - PARTE 10 EM DIANTE |  |  |  |  | N/A | N/A |
| V689542       05 WSV-C2-P2 |  |  |  |  | N/A | N/A |
| V689542          10 WSV-C2-PAR-P2A       PIC  9(002) |  |  |  |  | N/A | N/A |
| V689542          10 WSV-C2-PAR-P2B       PIC  X(001) |  |  |  |  | N/A | N/A |
| V689542          10 WSV-C2-TPARQ-P2      PIC  X(010) |  |  |  |  | N/A | N/A |
| V689542          10 WSV-C2-TOTCLI-P2A    PIC  X(010) |  |  |  |  | N/A | N/A |
| V689542          10 WSV-C2-TOTCLI-P2B    PIC  9(009) |  |  |  |  | N/A | N/A |
| V689542          10 WSV-C2-TOTCLI-P2C    PIC  X(001) |  |  |  |  | N/A | N/A |
| V689542          10 FILLER               PIC  X(005) |  |  |  |  | N/A | N/A |
| V689542* |  |  |  |  | N/A | N/A |
| VRESPON       05 WSV-CABEC3              PIC  X(100) |  |  |  |  | N/A | N/A |
| VRESPON       05 WSV-CABEC3-R REDEFINES  WSV-CABEC3 |  |  |  |  | N/A | N/A |
| VRESPON          10    C1-CABEC3              PIC  X(010) |  |  |  |  | N/A | N/A |
| VRESPON          10    XML1-DOCI-NM           PIC  X(020) |  |  |  |  | N/A | N/A |
| VRESPON          10    C2-CABEC3              PIC  X(013) |  |  |  |  | N/A | N/A |
| VSPRT60          10    XML1-DOCI-EM           PIC  X(033) |  |  |  |  | N/A | N/A |
| VRESPON          10    C3-CABEC3              PIC  X(011) |  |  |  |  | N/A | N/A |
| VSPRT60          10    XML1-DOCI-TEL          PIC  X(011) |  |  |  |  | N/A | N/A |
| VRESPON          10    C4-CABEC3              PIC  X(002) |  |  |  |  | N/A | N/A |
| VRESPON          10    FILLER                 PIC  X(009) |  |  |  |  | N/A | N/A |
| VSPRT82       05 WSV-CABEC4 |  |  |  |  | N/A | N/A |
| VSPRT82          10    C1-CABEC4              PIC  X(014)    VALUE |  |  |  |  | N/A | N/A |
| VSPRT82                'METODAPPE="C" ' |  |  |  |  | N/A | N/A |
| VSPRT82          10    C2-CABEC4              PIC  X(016)    VALUE |  |  |  |  | N/A | N/A |
| VSPRT82                'METODDIFTJE="S">' |  |  |  |  | N/A | N/A |
| VSPRT82          10    FILLER                 PIC  X(070)    VALUE |  |  |  |  | N/A | N/A |
| VSPRT82                SPACES |  |  |  |  | N/A | N/A |
| V689542    03 WS-DRAM0082 |  |  |  |  | N/A | N/A |
| V             05 WDRAM0082               PIC  X(008) VALUE 'DRAM0082' |  |  |  |  | N/A | N/A |
| V             05 WARQ-DDNAME1            PIC  X(008) VALUE 'LHS542S1' |  |  |  |  | N/A | N/A |
| V             05 WARQ-DDNAME2            PIC  X(008) VALUE 'LHS542S2' |  |  |  |  | N/A | N/A |
| V             05 WARQ-DSN-SEQ |  |  |  |  | N/A | N/A |
| V                10 WARQ-DSN-SEQ-N       PIC  9(002) VALUE ZEROS |  |  |  |  | N/A | N/A |
| V                10 WARQ-DSN-SEQ-X       PIC  X(001) VALUE SPACES |  |  |  |  | N/A | N/A |
| V689542       05 WARQ-DSN-SEQ-N3         PIC  9(003) VALUE ZEROS |  |  |  |  | N/A | N/A |
| V             05 WARQ-DSN-AUX            PIC  X(044) VALUE SPACES |  |  |  |  | N/A | N/A |
| V             05 WARQ-DSNAME1            PIC  X(044) VALUE SPACES |  |  |  |  | N/A | N/A |
| V             05 WARQ-DSNAME2            PIC  X(044) VALUE SPACES |  |  |  |  | N/A | N/A |
| V             05 WARQ-NEW                PIC  X(003) VALUE 'NEW' |  |  |  |  | N/A | N/A |
| V             05 WARQ-OLD                PIC  X(003) VALUE 'OLD' |  |  |  |  | N/A | N/A |
| V             05 WARQ-CATLG              PIC  X(007) VALUE 'CATLG  ' |  |  |  |  | N/A | N/A |
| V             05 WARQ-DELETE             PIC  X(007) VALUE 'DELETE ' |  |  |  |  | N/A | N/A |
| V             05 WARQ-KEEP               PIC  X(007) VALUE 'KEEP   ' |  |  |  |  | N/A | N/A |
| V             05 WARQ-TYPE-SPACE         PIC  X(003) VALUE 'CYL' |  |  |  |  | N/A | N/A |
| V             05 WARQ-SPACE-PRIM         PIC  9(002) VALUE 90 |  |  |  |  | N/A | N/A |
| V             05 WARQ-SPACE-SEC          PIC  9(002) VALUE 90 |  |  |  |  | N/A | N/A |
| V             05 WARQ-SPACE-RLSE         PIC  X(004) VALUE 'RLSE' |  |  |  |  | N/A | N/A |
| V             05 WARQ-UNIT               PIC  X(005) VALUE 'SYSDA' |  |  |  |  | N/A | N/A |
| V             05 WARQ-DATA-EXP           PIC  9(005) VALUE ZEROS |  |  |  |  | N/A | N/A |
| V             05 WARQ-DCB-BLKSIZE        PIC  9(005) VALUE 30000 |  |  |  |  | N/A | N/A |
| V             05 WARQ-DCB-LRECL          PIC  9(005) VALUE ZEROS |  |  |  |  | N/A | N/A |
| V             05 WARQ-DCB-BUFNO          PIC  9(002) VALUE 15 |  |  |  |  | N/A | N/A |
| V             05 WARQ-DCB-DSORG          PIC  X(003) VALUE 'PS' |  |  |  |  | N/A | N/A |
| V             05 WARQ-DCB-RECFM          PIC  X(003) VALUE 'FB' |  |  |  |  | N/A | N/A |
| V             05 WARQ-FREE               PIC  X(004) VALUE 'FREE' |  |  |  |  | N/A | N/A |
| V689542    03 CT-CONSTANTES |  |  |  |  | N/A | N/A |
| V689542       05 CT-DENE0530-L1          PIC  X(080) |  |  |  |  | N/A | N/A |
| V689542                                  VALUE 'DENE0530 R=  ,L= ' |  |  |  |  | N/A | N/A |
| *' |  |  |  |  | N/A | N/A |
| VRESPON    03 CH-RESP                    PIC  X(004) VALUE SPACES |  |  |  |  | N/A | N/A |
| V      *-------- AREAS  AUXILIARES DA SUB-ROTINA (DRAM0082)  ----------* |  |  |  |  | N/A | N/A |
| V       01  WAREA-82 |  |  |  |  | N/A | N/A |
| V       ++INCLUDE  DRR00082 |  |  |  |  | N/A | N/A |
| V       LINKAGE                          SECTION |  |  |  |  | N/A | N/A |
| V          01 LK-PARM |  |  |  |  | N/A | N/A |
| V             03 PARM-TAM           PIC 9(04) COMP |  |  |  |  | N/A | N/A |
| VSPRT11       03 PARM-EMP           PIC X(04) |  |  |  |  | N/A | N/A |
| V             03 PARM-DAT           PIC 9(06) |  |  |  |  | N/A | N/A |
| V       PROCEDURE                       DIVISION  USING  LK-PARM |  |  |  |  | N/A | N/A |
| V       PRINCIPAL                  SECTION |  |  |  |  | N/A | N/A |
| V           PERFORM     1-INICIO |  |  |  |  | N/A | N/A |
| V           PERFORM     2-PROCESSA  UNTIL |  |  |  |  | N/A | N/A |
| V                                   WFIM-LH542E2  EQUAL  'SIM' |  |  |  |  | N/A | N/A |
| V           PERFORM     4-FIM |  |  |  |  | N/A | N/A |
| V           GOBACK |  |  |  |  | N/A | N/A |
| V       1-INICIO                   SECTION |  |  |  |  | N/A | N/A |
| V           OPEN  INPUT  LHS542E1 |  |  |  |  | N/A | N/A |
| V                        LHS542E2 |  |  |  |  | N/A | N/A |
| V                        LHS542E3 |  |  |  |  | N/A | N/A |
| V                        LHS542E4 |  |  |  |  | N/A | N/A |
| VRESPON                  LHS542E5 |  |  |  |  | N/A | N/A |
| V689542     OPEN  OUTPUT LHS542S3 |  |  |  |  | N/A | N/A |
| V      *--- TRATAMENTO PARM - EMPRESA + DATABA + AMBIENTE |  |  |  |  | N/A | N/A |
| V689542     IF  PARM-TAM  NOT EQUAL  10 |  |  |  |  | N/A | N/A |
| V               DISPLAY 'LHAN0542 - TAMANHO DO PARM INVALIDO' |  |  |  |  | N/A | N/A |
| V               PERFORM  9-FIM-ANORMAL                                   FJAN0173 |  |  |  |  | N/A | N/A |
| V           ELSE |  |  |  |  | N/A | N/A |
| VSPRT11*        IF  PARM-EMP  NOT NUMERIC |  |  |  |  | N/A | N/A |
| VSPRT11*            DISPLAY 'LHAN0542 - PARM EMPRESA NAO NUMERICO' |  |  |  |  | N/A | N/A |
| VSPRT11*            PERFORM  9-FIM-ANORMAL                               FJAN0173 |  |  |  |  | N/A | N/A |
| VSPRT11*        END-IF |  |  |  |  | N/A | N/A |
| V               IF  PARM-DAT  NOT NUMERIC |  |  |  |  | N/A | N/A |
| V                   DISPLAY 'LHAN0542 - PARM DATA NAO NUMERICO' |  |  |  |  | N/A | N/A |
| V                   PERFORM  9-FIM-ANORMAL                               FJAN0173 |  |  |  |  | N/A | N/A |
| V               END-IF |  |  |  |  | N/A | N/A |
| V           END-IF |  |  |  |  | N/A | N/A |
| V      *--- TRATAMENTO ENTRADA 1 - TAMANHO DOC 3040 + QTE PARTICOES |  |  |  |  | N/A | N/A |
| V           PERFORM 31-LEITURA-LHS542E1 |  |  |  |  | N/A | N/A |
| V           IF  FS-LH542E1  EQUAL  '10'                                  FJAN0173 |  |  |  |  | N/A | N/A |
| V               DISPLAY 'LHS542E1 -  ARQUIVO LHS542E1 VAZIO'             FJAN0173 |  |  |  |  | N/A | N/A |
| V689542*    MOVE    TOT-PARTIC    TO  WTOT-PART |  |  |  |  | N/A | N/A |
| V      *--- TRATAMENTO POR EMPRESA, ALEM DE ATRIBUICAO "DEPARA" LETRA: |  |  |  |  | N/A | N/A |
| V      *    - PARTICOES E TAMANHOS MAXIMOS POR EMPRESA: |  |  |  |  | N/A | N/A |
| V      *      . 0033  : 15 PARTICOES - 62.914.560 |  |  |  |  | N/A | N/A |
| V      *      . 1508  :  3 PARTICOES - 12.582.912 |  |  |  |  | N/A | N/A |
| V      *      . DEMAIS:  1 PARTICAO  -  4.194.304 |  |  |  |  | N/A | N/A |
| V      *    - SE TAMANHO DOC 3040 FOR > 90%, EMITE RC = 93 (ALERTA) |  |  |  |  | N/A | N/A |
| V689542     MOVE     1                 TO      WTOT-PART |  |  |  |  | N/A | N/A |
| V689542     MOVE     80000000000       TO      WMAX-PART |  |  |  |  | N/A | N/A |
| V689542     COMPUTE  TOT-LIDOS          =      TOT-LIDOS   *   100 |  |  |  |  | N/A | N/A |
| V689542     EVALUATE PARM-EMP |  |  |  |  | N/A | N/A |
| V689542         WHEN '0033' |  |  |  |  | N/A | N/A |
| V689542               MOVE    'A'      TO    WARQ-DSN-SEQ-X |  |  |  |  | N/A | N/A |
| V689542               MOVE    15       TO    WTOT-PART |  |  |  |  | N/A | N/A |
| 15 |  |  |  |  | N/A | N/A |
| V689542               IF   TOT-LIDOS         GREATER   56623104000 |  |  |  |  | N/A | N/A |
| V689542                    DISPLAY 'DOC 3040 ACIMA DE 90%' |  |  |  |  | N/A | N/A |
| V689542                    MOVE    93  TO    RETURN-CODE |  |  |  |  | N/A | N/A |
| V689542               END-IF |  |  |  |  | N/A | N/A |
| V689542         WHEN '1505' |  |  |  |  | N/A | N/A |
| V689542               MOVE    'B'      TO      WARQ-DSN-SEQ-X |  |  |  |  | N/A | N/A |
| V689542         WHEN '1506' |  |  |  |  | N/A | N/A |
| V689542               MOVE    'C'      TO      WARQ-DSN-SEQ-X |  |  |  |  | N/A | N/A |
| V689542*        WHEN '1507' |  |  |  |  | N/A | N/A |
| V689542         WHEN 'BNDS' |  |  |  |  | N/A | N/A |
| V689542               MOVE    'D'      TO      WARQ-DSN-SEQ-X |  |  |  |  | N/A | N/A |
| V689542         WHEN '1508' |  |  |  |  | N/A | N/A |
| V689542               MOVE    'E'      TO      WARQ-DSN-SEQ-X |  |  |  |  | N/A | N/A |
| V689542               MOVE    3        TO      WTOT-PART |  |  |  |  | N/A | N/A |
| 3 |  |  |  |  | N/A | N/A |
| V689542               IF   TOT-LIDOS         GREATER   11324620800 |  |  |  |  | N/A | N/A |
| V689542         WHEN '1510' |  |  |  |  | N/A | N/A |
| V689542               MOVE    'F'      TO      WARQ-DSN-SEQ-X |  |  |  |  | N/A | N/A |
| V689542         WHEN '1513' |  |  |  |  | N/A | N/A |
| V689542               MOVE    'G'      TO      WARQ-DSN-SEQ-X |  |  |  |  | N/A | N/A |
| V689542         WHEN '6500' |  |  |  |  | N/A | N/A |
| V689542               MOVE    'H'      TO      WARQ-DSN-SEQ-X |  |  |  |  | N/A | N/A |
| V689542         WHEN OTHER |  |  |  |  | N/A | N/A |
| V689542               DISPLAY 'PARM EMPRESA INCORRETO: ' PARM-EMP        FJAN0173 |  |  |  |  | N/A | N/A |
| V689542               MOVE    90       TO      RETURN-CODE |  |  |  |  | N/A | N/A |
| V689542               PERFORM  9-FIM-ANORMAL                             FJAN0173 |  |  |  |  | N/A | N/A |
| V689542     END-EVALUATE |  |  |  |  | N/A | N/A |
| V689542     IF   TOT-LIDOS   GREATER  3774873600  AND |  |  |  |  | N/A | N/A |
| V689542         (PARM-EMP    NOT EQUAL '0033' AND '1508') |  |  |  |  | N/A | N/A |
| V689542          DISPLAY 'DOC 3040 ACIMA DE 90%' |  |  |  |  | N/A | N/A |
| V689542          MOVE    93  TO     RETURN-CODE |  |  |  |  | N/A | N/A |
| V689542     END-IF |  |  |  |  | N/A | N/A |
| V      *--- TRATAMENTO ENTRADA 4 - TOTAL CLIENTES |  |  |  |  | N/A | N/A |
| V           PERFORM 34-LEITURA-LHS542E4 |  |  |  |  | N/A | N/A |
| V           IF  FS-LH542E4  EQUAL  '10'                                  FJAN0173 |  |  |  |  | N/A | N/A |
| V               DISPLAY 'LHS542E4 -  ARQUIVO LHS542E4 VAZIO'             FJAN0173 |  |  |  |  | N/A | N/A |
| VSPR004         DISPLAY 'FIM NORMAL SEM EMISS¶O DE CADOC 3040 DA EMPRESA'FJAN0173 |  |  |  |  | N/A | N/A |
| VSPR004         PERFORM  4-FIM                                           FJAN0173 |  |  |  |  | N/A | N/A |
| VSPR004*        PERFORM  9-FIM-ANORMAL                                   FJAN0173 |  |  |  |  | N/A | N/A |
| VSPR004     IF  RELA-QTDE  EQUAL ZEROS                                   FJAN0173 |  |  |  |  | N/A | N/A |
| VSPR004         DISPLAY 'LHS542E4 -  ARQUIVO CLIENTE ZERADO'             FJAN0173 |  |  |  |  | N/A | N/A |
| VSPR004         DISPLAY 'FIM NORMAL SEM CADOC 3040 DA EMPRESA'           FJAN0173 |  |  |  |  | N/A | N/A |
| VSPR004*        PERFORM  4-FIM                                           FJAN0173 |  |  |  |  | N/A | N/A |
| V           PERFORM 35-PROC-LHS542E4 UNTIL |  |  |  |  | N/A | N/A |
| V                   WFIM-LH542E4  EQUAL  'SIM' |  |  |  |  | N/A | N/A |
| VSPR004     IF  RELA-QTDE  GREATER ZEROS                                 FJAN0173 |  |  |  |  | N/A | N/A |
| V      *--- TRATAMENTO ENTRADA 2 - ARQUIVO DE DADOS |  |  |  |  | N/A | N/A |
| V                PERFORM 32-LEITURA-LHS542E2 |  |  |  |  | N/A | N/A |
| V                IF  FS-LH542E2  EQUAL  '10'                             FJAN0173 |  |  |  |  | N/A | N/A |
| V                    DISPLAY 'LHS542E2 -  ARQUIVO LHS542E2 VAZIO'        FJAN0173 |  |  |  |  | N/A | N/A |
| V                    PERFORM  9-FIM-ANORMAL                              FJAN0173 |  |  |  |  | N/A | N/A |
| V                END-IF |  |  |  |  | N/A | N/A |
| V               IF  WSV-CABEC1  EQUAL  SPACES                            FJAN0173 |  |  |  |  | N/A | N/A |
| V                   DISPLAY 'LHS542E2 -  ARQUIVO LHS542E2 SEM HEADER'    FJAN0173 |  |  |  |  | N/A | N/A |
| V               PERFORM 32-LEITURA-LHS542E2 |  |  |  |  | N/A | N/A |
| VSPR004     END-IF |  |  |  |  | N/A | N/A |
| V           DISPLAY '***------------------ LHAN0542 ----------------***' |  |  |  |  | N/A | N/A |
| V      *--- TRATAMENTO ENTRADA 3 - SYSIN: DSN DADOS E BASTAO |  |  |  |  | N/A | N/A |
| CARREGAR DSN ARQUIVO DADOS |  |  |  |  | N/A | N/A |
| V           PERFORM  33-LEITURA-LHS542E3 |  |  |  |  | N/A | N/A |
| V689542*--- IDENTIFICAR AMBIENTE DE PROCESSAMENTO |  |  |  |  | N/A | N/A |
| V           MOVE     REG-ENT3542     TO  WARQ-DSNAME1 |  |  |  |  | N/A | N/A |
| VRESPON*--- OBTEM DADOS DO RESPONSAVEL CADOC3040 |  |  |  |  | N/A | N/A |
| VRESPON     PERFORM 35-LEITURA-LHS542E5 |  |  |  |  | N/A | N/A |
| VRESPON     IF      WFIM-LH542E5 EQUAL 'SIM' |  |  |  |  | N/A | N/A |
| VRESPON             DISPLAY 'ARQUIVO LHS542E5 VAZIO' |  |  |  |  | N/A | N/A |
| VRESPON             PERFORM 9-FIM-ANORMAL |  |  |  |  | N/A | N/A |
| VRESPON     END-IF |  |  |  |  | N/A | N/A |
| V           IF      PARM-EMP             EQUAL  'BNDS' |  |  |  |  | N/A | N/A |
| V             IF    MZM530-TABELA        EQUAL  'M530' |  |  |  |  | N/A | N/A |
| V                   PERFORM 35-LEITURA-LHS542E5 |  |  |  |  | N/A | N/A |
| VRESPON        IF   MZM530-TABELA   NOT  EQUAL  'BNDS' |  |  |  |  | N/A | N/A |
| VRESPON             DISPLAY 'RESPONSAVEL BNDES NAO ENCONTRADO' |  |  |  |  | N/A | N/A |
| VRESPON        END-IF |  |  |  |  | N/A | N/A |
| VRESPON       END-IF |  |  |  |  | N/A | N/A |
| VRESPON     MOVE    'NOMERESP="'            TO  C1-CABEC3 |  |  |  |  | N/A | N/A |
| VRESPON     MOVE    MZM530-NOME-RESP        TO  XML1-DOCI-NM |  |  |  |  | N/A | N/A |
| VRESPON     MOVE    '" EMAILRESP="'         TO  C2-CABEC3 |  |  |  |  | N/A | N/A |
| VRESPON     MOVE    MZM530-EMAIL-RESP       TO  XML1-DOCI-EM |  |  |  |  | N/A | N/A |
| VRESPON     MOVE    '" TELRESP="'           TO  C3-CABEC3 |  |  |  |  | N/A | N/A |
| VRESPON     MOVE    MZM530-FONE-RESP        TO  XML1-DOCI-TEL |  |  |  |  | N/A | N/A |
| VRESPON*    MOVE    '">'                    TO  C4-CABEC3 |  |  |  |  | N/A | N/A |
| VSPRT82     MOVE    '" '                    TO  C4-CABEC3 |  |  |  |  | N/A | N/A |
| V               PERFORM  21-ALOCA-LHS542S1 |  |  |  |  | N/A | N/A |
| VSPR004     ELSE |  |  |  |  | N/A | N/A |
| VSPR004         PERFORM  40-ALOCA-VAZIO |  |  |  |  | N/A | N/A |
| CARREGAR DSN ARQUIVO BASTAO |  |  |  |  | N/A | N/A |
| V           MOVE     REG-ENT3542     TO  WARQ-DSNAME2 |  |  |  |  | N/A | N/A |
| V       1-INICIO-SAI.              EXIT |  |  |  |  | N/A | N/A |
| V       2-PROCESSA                 SECTION |  |  |  |  | N/A | N/A |
| V689542*--- GRAVA POR PARTE O LIMITE CALCULADO NA SECAO 1-INICIO, MAIS |  |  |  |  | N/A | N/A |
| CLI> |  |  |  |  | N/A | N/A |
| V           PERFORM 24-GERA-ARQ-DINAMICO |  |  |  |  | N/A | N/A |
| CLI>'      AND |  |  |  |  | N/A | N/A |
| V689542                    WTOT-REGIS   >  WMAX-PART)   OR |  |  |  |  | N/A | N/A |
| V                          WFIM-LH542E2 = 'SIM' |  |  |  |  | N/A | N/A |
| V689542*--- PROCEDIMENTOS DE FIM DE PARTE E INICIO DA PROXIMA |  |  |  |  | N/A | N/A |
| DOC3040> |  |  |  |  | N/A | N/A |
| V689542*    - DISPLAY E ZERAR VARIAVEIS DE TOTAIS |  |  |  |  | N/A | N/A |
| V689542*    - LIBERA ALOCACAO DINAMICA E GERA NOVA SE NAO FOR FIM DE |  |  |  |  | N/A | N/A |
| V689542*      ARQUIVO LH542E2 |  |  |  |  | N/A | N/A |
| V689542     IF  WFIM-LH542E2 NOT EQUAL 'SIM' |  |  |  |  | N/A | N/A |
| CLI>' |  |  |  |  | N/A | N/A |
| V689542             WRITE   REG-SAI1542  FROM  REG-ENT2542 |  |  |  |  | N/A | N/A |
| V689542             COMPUTE WTOT-GRAV    =     WTOT-GRAV + 1 |  |  |  |  | N/A | N/A |
| V689542         END-IF |  |  |  |  | N/A | N/A |
| V689542     MOVE    WDOC3040     TO    REG-SAI1542 |  |  |  |  | N/A | N/A |
| V689542     WRITE   REG-SAI1542 |  |  |  |  | N/A | N/A |
| V689542     COMPUTE WTOT-GRAV    =     WTOT-GRAV + 1 |  |  |  |  | N/A | N/A |
| V           PERFORM 25-DISPLAY-TOTAIS |  |  |  |  | N/A | N/A |
| V           MOVE    ZEROS        TO    WTOT-LID |  |  |  |  | N/A | N/A |
| V                                      WTOT-REGIS |  |  |  |  | N/A | N/A |
| V                                      WTOT-GRAV |  |  |  |  | N/A | N/A |
| V                                      WTOT-CLI |  |  |  |  | N/A | N/A |
| V           PERFORM 26-LIBERA-LHS542S1 |  |  |  |  | N/A | N/A |
| V689542     PERFORM 27-GRAVA-LHS542S3 |  |  |  |  | N/A | N/A |
| V      *--- SE NAO FOR FIM DA ENTRADA E2, TESTA SE ALCANCOU LIMITES DE |  |  |  |  | N/A | N/A |
| V      *    PARTICOES ANTES DE PROSSEGUIR |  |  |  |  | N/A | N/A |
| V689542         EVALUATE PARM-EMP |  |  |  |  | N/A | N/A |
| V689542             WHEN '0033' |  |  |  |  | N/A | N/A |
| V689542                  IF  WARQ-DSN-SEQ-N3  EQUAL  15 |  |  |  |  | N/A | N/A |
| V689542                      MOVE    95       TO     RETURN-CODE |  |  |  |  | N/A | N/A |
| V689542                  END-IF |  |  |  |  | N/A | N/A |
| V689542             WHEN '1508' |  |  |  |  | N/A | N/A |
| V689542                  IF  WARQ-DSN-SEQ-N3  EQUAL  3 |  |  |  |  | N/A | N/A |
| V689542             WHEN OTHER |  |  |  |  | N/A | N/A |
| V689542                  IF  WARQ-DSN-SEQ-N3  EQUAL  1 |  |  |  |  | N/A | N/A |
| V689542         END-EVALUATE |  |  |  |  | N/A | N/A |
| V689542         IF  RETURN-CODE EQUAL 95 |  |  |  |  | N/A | N/A |
| V689542             DISPLAY '*-----------------------------------------*' |  |  |  |  | N/A | N/A |
| V689542             DISPLAY '*                                         *' |  |  |  |  | N/A | N/A |
| V689542             DISPLAY '*     ALERTA  ALERTA  ALERTA ALERTA       *' |  |  |  |  | N/A | N/A |
| V689542             DISPLAY '*   GERACAO ARQUIVO DINAMICO EXCEDIDO     *' |  |  |  |  | N/A | N/A |
| V689542             PERFORM 4-FIM |  |  |  |  | N/A | N/A |
| V689542         PERFORM 32-LEITURA-LHS542E2 |  |  |  |  | N/A | N/A |
| V689542         PERFORM 21-ALOCA-LHS542S1 |  |  |  |  | N/A | N/A |
| V689542*    IF  WFIM-LH542E2 NOT EQUAL 'SIM' |  |  |  |  | N/A | N/A |
| V689542*            WRITE   REG-SAI1542  FROM  REG-ENT2542 |  |  |  |  | N/A | N/A |
| V689542*            COMPUTE WTOT-GRAV = WTOT-GRAV + 1 |  |  |  |  | N/A | N/A |
| V689542*        END-IF |  |  |  |  | N/A | N/A |
| V689542*    END-IF |  |  |  |  | N/A | N/A |
| V689542*    IF  WFIM-LH542E2  =  'SIM' |  |  |  |  | N/A | N/A |
| V689542*        MOVE    WDOC3040 TO REG-SAI1542 |  |  |  |  | N/A | N/A |
| V689542*        WRITE   REG-SAI1542 |  |  |  |  | N/A | N/A |
| V689542*        COMPUTE WTOT-GRAV = WTOT-GRAV + 1 |  |  |  |  | N/A | N/A |
| V689542*        PERFORM 25-DISPLAY-TOTAIS |  |  |  |  | N/A | N/A |
| V689542*        GO   TO 2-PROCESSA-SAI |  |  |  |  | N/A | N/A |
| V       2-PROCESSA-SAI.            EXIT |  |  |  |  | N/A | N/A |
| V       21-ALOCA-LHS542S1          SECTION |  |  |  |  | N/A | N/A |
| V           ADD      1                       TO  WARQ-DSN-SEQ-N |  |  |  |  | N/A | N/A |
| V689542                                          WARQ-DSN-SEQ-N3 |  |  |  |  | N/A | N/A |
| V689542*    IF  PARM-EMP  EQUAL  '0033' |  |  |  |  | N/A | N/A |
| V689542*        MOVE  'A'                    TO  WARQ-DSN-SEQ-X |  |  |  |  | N/A | N/A |
| V689542*    ELSE |  |  |  |  | N/A | N/A |
| V689542*     IF  PARM-EMP  EQUAL  '1505' |  |  |  |  | N/A | N/A |
| V689542*         MOVE  'B'                   TO  WARQ-DSN-SEQ-X |  |  |  |  | N/A | N/A |
| V689542*     ELSE |  |  |  |  | N/A | N/A |
| V689542*      IF  PARM-EMP  EQUAL  '1506' |  |  |  |  | N/A | N/A |
| V689542*          MOVE  'C'                  TO  WARQ-DSN-SEQ-X |  |  |  |  | N/A | N/A |
| V689542*      ELSE |  |  |  |  | N/A | N/A |
| V689542*       IF  PARM-EMP  EQUAL  '1507' |  |  |  |  | N/A | N/A |
| V689542*           MOVE  'D'                 TO  WARQ-DSN-SEQ-X |  |  |  |  | N/A | N/A |
| V689542*       ELSE |  |  |  |  | N/A | N/A |
| V689542*        IF  PARM-EMP  EQUAL  '1508' |  |  |  |  | N/A | N/A |
| V689542*            MOVE  'E'                TO  WARQ-DSN-SEQ-X |  |  |  |  | N/A | N/A |
| V689542*        ELSE |  |  |  |  | N/A | N/A |
| V689542*         IF  PARM-EMP  EQUAL  '1510' |  |  |  |  | N/A | N/A |
| V689542*             MOVE  'F'               TO  WARQ-DSN-SEQ-X |  |  |  |  | N/A | N/A |
| V689542*         ELSE |  |  |  |  | N/A | N/A |
| V689542*          IF  PARM-EMP  EQUAL  '1513' |  |  |  |  | N/A | N/A |
| V689542*              MOVE  'G'              TO  WARQ-DSN-SEQ-X |  |  |  |  | N/A | N/A |
| V689542*          ELSE |  |  |  |  | N/A | N/A |
| V689542*          IF  PARM-EMP  EQUAL  '6500' |  |  |  |  | N/A | N/A |
| V689542*              MOVE  'H'              TO  WARQ-DSN-SEQ-X |  |  |  |  | N/A | N/A |
| V689542*         END-IF |  |  |  |  | N/A | N/A |
| V689542*       END-IF |  |  |  |  | N/A | N/A |
| V689542*      END-IF |  |  |  |  | N/A | N/A |
| V689542*     END-IF |  |  |  |  | N/A | N/A |
| VOLIVA *    IF  WARQ-DSN-SEQ-N  EQUAL  10 |  |  |  |  | N/A | N/A |
| VOLIVA *        MOVE ZEROS                   TO  WARQ-DSN-SEQ-N |  |  |  |  | N/A | N/A |
| VOLIVA *    END-IF |  |  |  |  | N/A | N/A |
| V           MOVE     WARQ-DSNAME1            TO  WARQ-DSN-AUX |  |  |  |  | N/A | N/A |
| V           INSPECT  WARQ-DSN-AUX |  |  |  |  | N/A | N/A |
| V                    REPLACING ALL '&EMP'    BY  PARM-EMP |  |  |  |  | N/A | N/A |
| V689542*--- PARA AS EMPRESAS 0033 E 1508, SEQUENCIA NUMERICA DE 3 BYTES |  |  |  |  | N/A | N/A |
| V689542*    DEMAIS EMPRESAS, 2 BYTES + 1 LETRA |  |  |  |  | N/A | N/A |
| V689542     IF  PARM-EMP   EQUAL  '0033'  OR  '1508' |  |  |  |  | N/A | N/A |
| V689542         INSPECT  WARQ-DSN-AUX |  |  |  |  | N/A | N/A |
| V689542                  REPLACING ALL '&SW'     BY  WARQ-DSN-SEQ-N3 |  |  |  |  | N/A | N/A |
| V689542     ELSE |  |  |  |  | N/A | N/A |
| V               INSPECT  WARQ-DSN-AUX |  |  |  |  | N/A | N/A |
| V                        REPLACING ALL '&S'      BY  WARQ-DSN-SEQ-N |  |  |  |  | N/A | N/A |
| V                        REPLACING ALL 'W'       BY  WARQ-DSN-SEQ-X |  |  |  |  | N/A | N/A |
| V                    REPLACING ALL '&DATA |  |  |  |  | N/A | N/A |
| V      ***> TENTA EXCLUIR O ARQUIVO ANTES DE ALOCAR (REPROCESSAMENTO) |  |  |  |  | N/A | N/A |
| V      ***> ALOCANDO-O COM (OLD,DELETE,KEEP) |  |  |  |  | N/A | N/A |
| V      ***> SE CONSEGUIR ALOCAR, ABRE E FECHA O ARQUIVO, EXCLUINDO-O |  |  |  |  | N/A | N/A |
| V      ***> SE NAO CONSEGUIR ALOCAR, O ARQUIVO NAO EXISTE |  |  |  |  | N/A | N/A |
| V           MOVE     SPACES                  TO  WAREA-82 |  |  |  |  | N/A | N/A |
| V           MOVE     1                       TO  W82-OPCAO |  |  |  |  | N/A | N/A |
| V           MOVE     WARQ-OLD                TO  W82-DISP1 |  |  |  |  | N/A | N/A |
| V           MOVE     WARQ-DELETE             TO  W82-DISP2 |  |  |  |  | N/A | N/A |
| V           MOVE     WARQ-KEEP               TO  W82-DISP3 |  |  |  |  | N/A | N/A |
| V           MOVE     WARQ-DDNAME1            TO  W82-DDNAME |  |  |  |  | N/A | N/A |
| V           MOVE     WARQ-DSN-AUX            TO  W82-DSNAME |  |  |  |  | N/A | N/A |
| V           MOVE     WARQ-FREE               TO  W82-FREE-EQUAL-CLOSE |  |  |  |  | N/A | N/A |
| V           CALL     WDRAM0082            USING  WAREA-82 |  |  |  |  | N/A | N/A |
| V           IF  W82-CODRET  EQUAL  ZEROS |  |  |  |  | N/A | N/A |
| V               OPEN  OUTPUT  LHS542S1 |  |  |  |  | N/A | N/A |
| V               CLOSE         LHS542S1 |  |  |  |  | N/A | N/A |
| V      ***> ALOCA DINAMICAMENTE O ARQUIVO |  |  |  |  | N/A | N/A |
| V           MOVE     WARQ-NEW                TO  W82-DISP1 |  |  |  |  | N/A | N/A |
| V           MOVE     WARQ-CATLG              TO  W82-DISP2 |  |  |  |  | N/A | N/A |
| V           MOVE     WARQ-DELETE             TO  W82-DISP3 |  |  |  |  | N/A | N/A |
| V           MOVE     WARQ-TYPE-SPACE         TO  W82-TYPE-SPACE |  |  |  |  | N/A | N/A |
| V           MOVE     WARQ-SPACE-PRIM         TO  W82-SPACE-PRIM |  |  |  |  | N/A | N/A |
| V           MOVE     WARQ-SPACE-SEC          TO  W82-SPACE-SEC |  |  |  |  | N/A | N/A |
| V           MOVE     WARQ-SPACE-RLSE         TO  W82-SPACE-RLSE |  |  |  |  | N/A | N/A |
| V           MOVE     WARQ-UNIT               TO  W82-UNIT |  |  |  |  | N/A | N/A |
| V           MOVE     WARQ-DATA-EXP           TO  W82-DATA-EXPIRATION |  |  |  |  | N/A | N/A |
| V           MOVE     WARQ-DCB-BLKSIZE        TO  W82-DCB-BLKSIZE |  |  |  |  | N/A | N/A |
| V           MOVE     100                     TO  WARQ-DCB-LRECL |  |  |  |  | N/A | N/A |
| V           MOVE     WARQ-DCB-LRECL          TO  W82-DCB-LRECL |  |  |  |  | N/A | N/A |
| V           MOVE     WARQ-DCB-RECFM          TO  W82-DCB-RECFM |  |  |  |  | N/A | N/A |
| V           MOVE     WARQ-DCB-BUFNO          TO  W82-DCB-BUFNO |  |  |  |  | N/A | N/A |
| V           MOVE     WARQ-DCB-DSORG          TO  W82-DCB-DSORG |  |  |  |  | N/A | N/A |
| V           IF  W82-CODRET  NOT EQUAL  ZEROS |  |  |  |  | N/A | N/A |
| ALOCACAO LHS542S1'FJAN0173 |  |  |  |  | N/A | N/A |
| V               DISPLAY W82-MENSERRO                                     FJAN0173 |  |  |  |  | N/A | N/A |
| V           OPEN  OUTPUT  LHS542S1 |  |  |  |  | N/A | N/A |
| V           PERFORM 23-GERA-CABECALHO |  |  |  |  | N/A | N/A |
| V       21-ALOCA-LHS542S1-SAI.     EXIT |  |  |  |  | N/A | N/A |
| V       22-ALOCA-LHS542S2          SECTION |  |  |  |  | N/A | N/A |
| V           MOVE     WARQ-DSNAME2            TO  WARQ-DSN-AUX |  |  |  |  | N/A | N/A |
| V689542     IF  PARM-EMP   EQUAL   '0033'  OR  '1508' |  |  |  |  | N/A | N/A |
| V           MOVE     WARQ-DDNAME2            TO  W82-DDNAME |  |  |  |  | N/A | N/A |
| V               OPEN  OUTPUT  LHS542S2 |  |  |  |  | N/A | N/A |
| V               CLOSE         LHS542S2 |  |  |  |  | N/A | N/A |
| V           MOVE     80                      TO  WARQ-DCB-LRECL |  |  |  |  | N/A | N/A |
| V           CALL     WDRAM0082  USING  WAREA-82 |  |  |  |  | N/A | N/A |
| ALOCACAO LHS542S2'FJAN0173 |  |  |  |  | N/A | N/A |
| V           OPEN  OUTPUT  LHS542S2 |  |  |  |  | N/A | N/A |
| V      *                                                                 FJAN0173 |  |  |  |  | N/A | N/A |
| V       22-ALOCA-LHS542S2-SAI.     EXIT |  |  |  |  | N/A | N/A |
| V       23-GERA-CABECALHO          SECTION |  |  |  |  | N/A | N/A |
| V689542*--- GRAVA CABEC1 |  |  |  |  | N/A | N/A |
| V           WRITE   REG-SAI1542  FROM  WSV-CABEC1 |  |  |  |  | N/A | N/A |
| V           COMPUTE WTOT-GRAV    =     WTOT-GRAV + 1 |  |  |  |  | N/A | N/A |
| V689542*--- GRAVA CABEC2 |  |  |  |  | N/A | N/A |
| V689542*    - UNICA OU ULTIMA PARTE: ASSINALA TAG TPARQ=F |  |  |  |  | N/A | N/A |
| V689542*    - PARTE DE 1 A 9       : POSICOES NORMAIS |  |  |  |  | N/A | N/A |
| V689542*    - PARTE 10 EM DIANTE   : UMA POSICAO A DIREITA |  |  |  |  | N/A | N/A |
| V           IF  WSV-PARTE  EQUAL WTOT-PART |  |  |  |  | N/A | N/A |
| V               MOVE     WSV-TPARQ-AUX     TO WSV-C2-TPARQ-P1 |  |  |  |  | N/A | N/A |
| V689542     IF  WSV-PARTE  LESS THAN 10 |  |  |  |  | N/A | N/A |
| V689542         MOVE     WSV-PARTE-U       TO WSV-C2-PAR-P1A |  |  |  |  | N/A | N/A |
| V689542         MOVE     WSV-C2-P1         TO WSV-C2 |  |  |  |  | N/A | N/A |
| V689542         IF  WSV-PARTE  EQUAL 10 |  |  |  |  | N/A | N/A |
| V689542             MOVE SPACES            TO WSV-C2-P2 |  |  |  |  | N/A | N/A |
| V689542             MOVE WSV-C2-PAR-P1B    TO WSV-C2-PAR-P2B |  |  |  |  | N/A | N/A |
| V689542             MOVE WSV-C2-TPARQ-P1   TO WSV-C2-TPARQ-P2 |  |  |  |  | N/A | N/A |
| V689542             MOVE WSV-C2-TOTCLI-P1A TO WSV-C2-TOTCLI-P2A |  |  |  |  | N/A | N/A |
| V689542             MOVE WSV-C2-TOTCLI-P1B TO WSV-C2-TOTCLI-P2B |  |  |  |  | N/A | N/A |
| V689542             MOVE WSV-C2-TOTCLI-P1C TO WSV-C2-TOTCLI-P2C |  |  |  |  | N/A | N/A |
| V689542         MOVE     WSV-PARTE-D       TO WSV-C2-PAR-P2A |  |  |  |  | N/A | N/A |
| V689542         MOVE     WSV-C2-TPARQ-P1   TO WSV-C2-TPARQ-P2 |  |  |  |  | N/A | N/A |
| V689542         MOVE     WSV-C2-P2         TO WSV-C2 |  |  |  |  | N/A | N/A |
| V           WRITE   REG-SAI1542  FROM  WSV-CABEC2 |  |  |  |  | N/A | N/A |
| V689542*    COMPUTE WSV-PARTE-AUX =    WSV-PARTE-AUX + 1 |  |  |  |  | N/A | N/A |
| V689542*--- GRAVA CABEC3 |  |  |  |  | N/A | N/A |
| V           WRITE   REG-SAI1542  FROM  WSV-CABEC3 |  |  |  |  | N/A | N/A |
| VSPRT82*--- GRAVA CABEC4 |  |  |  |  | N/A | N/A |
| V           WRITE   REG-SAI1542  FROM  WSV-CABEC4 |  |  |  |  | N/A | N/A |
| V           ADD          1                TO WSV-PARTE |  |  |  |  | N/A | N/A |
| V       23-GERA-CABECALHO-SAI.     EXIT |  |  |  |  | N/A | N/A |
| V       24-GERA-ARQ-DINAMICO       SECTION |  |  |  |  | N/A | N/A |
| V           WRITE   REG-SAI1542  FROM  REG-ENT2542 |  |  |  |  | N/A | N/A |
| V           COMPUTE WTOT-GRAV = WTOT-GRAV + 1 |  |  |  |  | N/A | N/A |
| V           PERFORM 32-LEITURA-LHS542E2 |  |  |  |  | N/A | N/A |
| V       24-GERA-ARQ-DINAMICO-SAI.  EXIT |  |  |  |  | N/A | N/A |
| V       25-DISPLAY-TOTAIS          SECTION |  |  |  |  | N/A | N/A |
| V           DISPLAY '***                                            ***' |  |  |  |  | N/A | N/A |
| V           DISPLAY '*** GERADO ARQUIVO DINAMICO                    ***' |  |  |  |  | N/A | N/A |
| V           DISPLAY '*** ' WARQ-DSN-AUX |  |  |  |  | N/A | N/A |
| V           DISPLAY '*** ' |  |  |  |  | N/A | N/A |
| V           DISPLAY '***   TOTAL LIDOS    = ' WTOT-LID |  |  |  |  | N/A | N/A |
| V           DISPLAY '***   TOTAL GRAVADOS = ' WTOT-GRAV |  |  |  |  | N/A | N/A |
| V           DISPLAY '***   TOTAL CLIENTES = ' WTOT-CLI |  |  |  |  | N/A | N/A |
| V       25-DISPLAY-TOTAIS-SAI.     EXIT |  |  |  |  | N/A | N/A |
| V       26-LIBERA-LHS542S1         SECTION |  |  |  |  | N/A | N/A |
| V           CLOSE  LHS542S1                                              FJAN0173 |  |  |  |  | N/A | N/A |
| V           MOVE    SPACES                   TO  WAREA-82 |  |  |  |  | N/A | N/A |
| V           MOVE    2                        TO  W82-OPCAO |  |  |  |  | N/A | N/A |
| V           MOVE    WARQ-DDNAME1             TO  W82-DDNAME |  |  |  |  | N/A | N/A |
| V           CALL    WDRAM0082  USING  WAREA-82 |  |  |  |  | N/A | N/A |
| LIBERACAO LHS542S1'FJAN0173 |  |  |  |  | N/A | N/A |
| V               DISPLAY  W82-MENSERRO                                    FJAN0173 |  |  |  |  | N/A | N/A |
| V           PERFORM 22-ALOCA-LHS542S2 |  |  |  |  | N/A | N/A |
| V           DISPLAY '*** ARQUIVO BASTAO CORRESPONDENTE              ***' |  |  |  |  | N/A | N/A |
| V           DISPLAY '***--------------------------------------------***' |  |  |  |  | N/A | N/A |
| V           CLOSE  LHS542S2 |  |  |  |  | N/A | N/A |
| V       26-LIBERA-LHS542S1-SAI.    EXIT |  |  |  |  | N/A | N/A |
| V689542 27-GRAVA-LHS542S3          SECTION |  |  |  |  | N/A | N/A |
| V689542     MOVE    CT-DENE0530-L1   TO   S3-L1 |  |  |  |  | N/A | N/A |
| V689542     MOVE    WARQ-DSN-SEQ-N   TO   S3-L1-SEQ-N2 |  |  |  |  | N/A | N/A |
| V689542     MOVE    WARQ-DSN-SEQ-X   TO   S3-L1-LETRA |  |  |  |  | N/A | N/A |
| V689542     WRITE   REG-SAI3542 |  |  |  |  | N/A | N/A |
| V689542     MOVE    CT-DENE0530-L2   TO   S3-L2 |  |  |  |  | N/A | N/A |
| V689542 |  |  |  |  | N/A | N/A |
| V689542 27-GRAVA-LHS542S3-SAI.     EXIT |  |  |  |  | N/A | N/A |
| V       31-LEITURA-LHS542E1        SECTION |  |  |  |  | N/A | N/A |
| V           READ  LHS542E1                                               FJAN0173 |  |  |  |  | N/A | N/A |
| V           IF  FS-LH542E1  NOT EQUAL  '00' AND '10'                     FJAN0173 |  |  |  |  | N/A | N/A |
| V               DISPLAY 'LHAN0542 -  ERRO DE LEITURA DO ARQUIVO LHE542E1'FJAN0173 |  |  |  |  | N/A | N/A |
| V               DISPLAY '            FILE STATUS = ' FS-LH542E1          FJAN0173 |  |  |  |  | N/A | N/A |
| V       31-LEITURA-EDQ542E1-SAI.    EXIT |  |  |  |  | N/A | N/A |
| V       32-LEITURA-LHS542E2        SECTION |  |  |  |  | N/A | N/A |
| V           READ  LHS542E2                                               FJAN0173 |  |  |  |  | N/A | N/A |
| V           IF  FS-LH542E2  NOT EQUAL  '00' AND '10'                     FJAN0173 |  |  |  |  | N/A | N/A |
| V               DISPLAY 'LHAN0542 -  ERRO DE LEITURA DO ARQUIVO LHE542E2'FJAN0173 |  |  |  |  | N/A | N/A |
| V               DISPLAY '            FILE STATUS = ' FS-LH542E2          FJAN0173 |  |  |  |  | N/A | N/A |
| V           ELSE                                                         FJAN0173 |  |  |  |  | N/A | N/A |
| V               IF  FS-LH542E2  EQUAL  '10'                              FJAN0173 |  |  |  |  | N/A | N/A |
| V                   MOVE  'SIM'  TO  WFIM-LH542E2                        FJAN0173 |  |  |  |  | N/A | N/A |
| V                   GO TO  32-LEITURA-EDQ542E2-SAI |  |  |  |  | N/A | N/A |
| V           IF  ID-CLIENTE  NOT EQUAL  '<?XML ' |  |  |  |  | N/A | N/A |
| V               COMPUTE WTOT-LID   = WTOT-LID + 1 |  |  |  |  | N/A | N/A |
| V               COMPUTE WTOT-REGIS = WTOT-REGIS + 100 |  |  |  |  | N/A | N/A |
| V               IF  WFLAG-CABEC  EQUAL  SPACES                           FJAN0173 |  |  |  |  | N/A | N/A |
| V689542*---         SALVA CABECALHO 1 |  |  |  |  | N/A | N/A |
| V                   MOVE    REG-ENT2542  TO  WSV-CABEC1 |  |  |  |  | N/A | N/A |
| V689542*---         SALVA CABECALHO 2 |  |  |  |  | N/A | N/A |
| V                   PERFORM 32-LEITURA-LHS542E2 |  |  |  |  | N/A | N/A |
| V                   MOVE    TP-ARQUIVO   TO  WSV-TPARQ-AUX |  |  |  |  | N/A | N/A |
| V689542*            MOVE    NR-PARTE     TO  WSV-PARTE-AUX |  |  |  |  | N/A | N/A |
| V689542             MOVE    1            TO  WSV-PARTE |  |  |  |  | N/A | N/A |
| V                   MOVE    SPACES       TO  TP-ARQUIVO |  |  |  |  | N/A | N/A |
| V                   MOVE    REG-ENT2542  TO  WSV-CABEC2 |  |  |  |  | N/A | N/A |
| V689542             MOVE    WSV-C2       TO  WSV-C2-P1 |  |  |  |  | N/A | N/A |
| V                   MOVE    1            TO  WSV-REMES-AUX |  |  |  |  | N/A | N/A |
| V689542             MOVE  WS-RELA-QTDE   TO  WSV-C2-TOTCLI-P1B |  |  |  |  | N/A | N/A |
| V689542*---         SALVA CABECALHO 3 |  |  |  |  | N/A | N/A |
| VRESPON*            MOVE    REG-ENT2542  TO  WSV-CABEC3 |  |  |  |  | N/A | N/A |
| V                   MOVE    'SIM'                   TO  WFLAG-CABEC |  |  |  |  | N/A | N/A |
| V               ELSE |  |  |  |  | N/A | N/A |
| V               COMPUTE  WTOT-CLI  = WTOT-CLI + 1 |  |  |  |  | N/A | N/A |
| V       32-LEITURA-EDQ542E2-SAI.    EXIT |  |  |  |  | N/A | N/A |
| V       33-LEITURA-LHS542E3        SECTION |  |  |  |  | N/A | N/A |
| V           READ  LHS542E3                                               FJAN0173 |  |  |  |  | N/A | N/A |
| V           IF  FS-LH542E3  NOT EQUAL  '00'                              FJAN0173 |  |  |  |  | N/A | N/A |
| V               DISPLAY 'LHAN0542 -  ERRO DE LEITURA DO ARQUIVO LHE542E3'FJAN0173 |  |  |  |  | N/A | N/A |
| V               DISPLAY '            FILE STATUS = ' FS-LH542E3          FJAN0173 |  |  |  |  | N/A | N/A |
| V       33-LEITURA-EDQ542E3-SAI.    EXIT |  |  |  |  | N/A | N/A |
| V       34-LEITURA-LHS542E4        SECTION |  |  |  |  | N/A | N/A |
| V           READ  LHS542E4                                               FJAN0173 |  |  |  |  | N/A | N/A |
| V                          AT END MOVE 'SIM' TO WFIM-LH542E4 |  |  |  |  | N/A | N/A |
| V       34-LEITURA-EDQ542E4-SAI.    EXIT |  |  |  |  | N/A | N/A |
| VRESPON*---------------------------------------------------------------* |  |  |  |  | N/A | N/A |
| VRESPON 35-LEITURA-LHS542E5        SECTION |  |  |  |  | N/A | N/A |
| VRESPON* |  |  |  |  | N/A | N/A |
| VRESPON     READ  LHS542E5                                               FJAN0173 |  |  |  |  | N/A | N/A |
| VRESPON                    AT END MOVE 'SIM' TO WFIM-LH542E5 |  |  |  |  | N/A | N/A |
| VRESPON 35-LEITURA-EDQ542E5-SAI.    EXIT |  |  |  |  | N/A | N/A |
| V       35-PROC-LHS542E4        SECTION |  |  |  |  | N/A | N/A |
| V           ADD    RELA-QTDE    TO WS-RELA-QTDE |  |  |  |  | N/A | N/A |
| V                                                                        FJAN0173 |  |  |  |  | N/A | N/A |
| V       35-PROC-EDQ542E4-SAI.    EXIT |  |  |  |  | N/A | N/A |
| VSPR004* ALOCACAO DE SAIDA PARA ARQUIVOS VAZIOS |  |  |  |  | N/A | N/A |
| VSPR004*---------------------------------------------------------------* |  |  |  |  | N/A | N/A |
| VSPR004 40-ALOCA-VAZIO          SECTION |  |  |  |  | N/A | N/A |
| VSPR004     ADD      1                       TO  WARQ-DSN-SEQ-N |  |  |  |  | N/A | N/A |
| VSPR004                                          WARQ-DSN-SEQ-N3 |  |  |  |  | N/A | N/A |
| VSPR004* |  |  |  |  | N/A | N/A |
| VSPR004     MOVE     WARQ-DSNAME1            TO  WARQ-DSN-AUX |  |  |  |  | N/A | N/A |
| VSPR004     INSPECT  WARQ-DSN-AUX |  |  |  |  | N/A | N/A |
| VSPR004              REPLACING ALL '&EMP'    BY  PARM-EMP |  |  |  |  | N/A | N/A |
| VSPR004*--- PARA AS EMPRESAS 0033 E 1508, SEQUENCIA NUMERICA DE 3 BYTES |  |  |  |  | N/A | N/A |
| VSPR004*    DEMAIS EMPRESAS, 2 BYTES + 1 LETRA |  |  |  |  | N/A | N/A |
| VSPR004     IF  PARM-EMP   EQUAL  '0033'  OR  '1508' |  |  |  |  | N/A | N/A |
| VSPR004         INSPECT  WARQ-DSN-AUX |  |  |  |  | N/A | N/A |
| VSPR004                  REPLACING ALL '&SW'     BY  WARQ-DSN-SEQ-N3 |  |  |  |  | N/A | N/A |
| VSPR004                  REPLACING ALL '&S'      BY  WARQ-DSN-SEQ-N |  |  |  |  | N/A | N/A |
| VSPR004                  REPLACING ALL 'W'       BY  WARQ-DSN-SEQ-X |  |  |  |  | N/A | N/A |
| VSPR004              REPLACING ALL '&DATA |  |  |  |  | N/A | N/A |
| VSPR004***> TENTA EXCLUIR O ARQUIVO ANTES DE ALOCAR (REPROCESSAMENTO) |  |  |  |  | N/A | N/A |
| VSPR004***> ALOCANDO-O COM (OLD,DELETE,KEEP) |  |  |  |  | N/A | N/A |
| VSPR004***> SE CONSEGUIR ALOCAR, ABRE E FECHA O ARQUIVO, EXCLUINDO-O |  |  |  |  | N/A | N/A |
| VSPR004***> SE NAO CONSEGUIR ALOCAR, O ARQUIVO NAO EXISTE |  |  |  |  | N/A | N/A |
| VSPR004     MOVE     SPACES                  TO  WAREA-82 |  |  |  |  | N/A | N/A |
| VSPR004     MOVE     1                       TO  W82-OPCAO |  |  |  |  | N/A | N/A |
| VSPR004     MOVE     WARQ-OLD                TO  W82-DISP1 |  |  |  |  | N/A | N/A |
| VSPR004     MOVE     WARQ-DELETE             TO  W82-DISP2 |  |  |  |  | N/A | N/A |
| VSPR004     MOVE     WARQ-KEEP               TO  W82-DISP3 |  |  |  |  | N/A | N/A |
| VSPR004     MOVE     WARQ-DDNAME1            TO  W82-DDNAME |  |  |  |  | N/A | N/A |
| VSPR004     MOVE     WARQ-DSN-AUX            TO  W82-DSNAME |  |  |  |  | N/A | N/A |
| VSPR004     MOVE     WARQ-FREE               TO  W82-FREE-EQUAL-CLOSE |  |  |  |  | N/A | N/A |
| VSPR004 |  |  |  |  | N/A | N/A |
| VSPR004     CALL     WDRAM0082            USING  WAREA-82 |  |  |  |  | N/A | N/A |
| VSPR004     IF  W82-CODRET  EQUAL  ZEROS |  |  |  |  | N/A | N/A |
| VSPR004         OPEN  OUTPUT  LHS542S1 |  |  |  |  | N/A | N/A |
| VSPR004         CLOSE         LHS542S1 |  |  |  |  | N/A | N/A |
| VSPR004***> ALOCA DINAMICAMENTE O ARQUIVO |  |  |  |  | N/A | N/A |
| VSPR004     MOVE     WARQ-NEW                TO  W82-DISP1 |  |  |  |  | N/A | N/A |
| VSPR004     MOVE     WARQ-CATLG              TO  W82-DISP2 |  |  |  |  | N/A | N/A |
| VSPR004     MOVE     WARQ-DELETE             TO  W82-DISP3 |  |  |  |  | N/A | N/A |
| VSPR004     MOVE     WARQ-TYPE-SPACE         TO  W82-TYPE-SPACE |  |  |  |  | N/A | N/A |
| VSPR004     MOVE     WARQ-SPACE-PRIM         TO  W82-SPACE-PRIM |  |  |  |  | N/A | N/A |
| VSPR004     MOVE     WARQ-SPACE-SEC          TO  W82-SPACE-SEC |  |  |  |  | N/A | N/A |
| VSPR004     MOVE     WARQ-SPACE-RLSE         TO  W82-SPACE-RLSE |  |  |  |  | N/A | N/A |
| VSPR004     MOVE     WARQ-UNIT               TO  W82-UNIT |  |  |  |  | N/A | N/A |
| VSPR004     MOVE     WARQ-DATA-EXP           TO  W82-DATA-EXPIRATION |  |  |  |  | N/A | N/A |
| VSPR004     MOVE     WARQ-DCB-BLKSIZE        TO  W82-DCB-BLKSIZE |  |  |  |  | N/A | N/A |
| VSPR004     MOVE     100                     TO  WARQ-DCB-LRECL |  |  |  |  | N/A | N/A |
| VSPR004     MOVE     WARQ-DCB-LRECL          TO  W82-DCB-LRECL |  |  |  |  | N/A | N/A |
| VSPR004     MOVE     WARQ-DCB-RECFM          TO  W82-DCB-RECFM |  |  |  |  | N/A | N/A |
| VSPR004     MOVE     WARQ-DCB-BUFNO          TO  W82-DCB-BUFNO |  |  |  |  | N/A | N/A |
| VSPR004     MOVE     WARQ-DCB-DSORG          TO  W82-DCB-DSORG |  |  |  |  | N/A | N/A |
| VSPR004     IF  W82-CODRET  NOT EQUAL  ZEROS |  |  |  |  | N/A | N/A |
| VSPR004         DISPLAY W82-MENSERRO                                     FJAN0173 |  |  |  |  | N/A | N/A |
| VSPR004         PERFORM  9-FIM-ANORMAL                                   FJAN0173 |  |  |  |  | N/A | N/A |
| VSPR004     OPEN  OUTPUT  LHS542S1 |  |  |  |  | N/A | N/A |
| VSPR004     CLOSE  LHS542S1 |  |  |  |  | N/A | N/A |
| VSPR004******************************************* |  |  |  |  | N/A | N/A |
| VSPR004*   ALOCA ARQUIVO BASTAO |  |  |  |  | N/A | N/A |
| VSPR004************************************************* |  |  |  |  | N/A | N/A |
| VSPR004     PERFORM  33-LEITURA-LHS542E3 |  |  |  |  | N/A | N/A |
| VSPR004     MOVE     REG-ENT3542     TO  WARQ-DSNAME2 |  |  |  |  | N/A | N/A |
| VSPR004     MOVE    SPACES                   TO  WAREA-82 |  |  |  |  | N/A | N/A |
| VSPR004     MOVE    2                        TO  W82-OPCAO |  |  |  |  | N/A | N/A |
| VSPR004     MOVE    WARQ-DDNAME1             TO  W82-DDNAME |  |  |  |  | N/A | N/A |
| VSPR004     CALL    WDRAM0082  USING  WAREA-82 |  |  |  |  | N/A | N/A |
| VSPR004*                                                                 FJAN0173 |  |  |  |  | N/A | N/A |
| VSPR004         DISPLAY  W82-MENSERRO                                    FJAN0173 |  |  |  |  | N/A | N/A |
| VSPR004     PERFORM 22-ALOCA-LHS542S2 |  |  |  |  | N/A | N/A |
| VSPR004     DISPLAY '*** ARQUIVO BASTAO CORRESPONDENTE              ***' |  |  |  |  | N/A | N/A |
| VSPR004     DISPLAY '*** ' WARQ-DSN-AUX |  |  |  |  | N/A | N/A |
| VSPR004     DISPLAY '***                                            ***' |  |  |  |  | N/A | N/A |
| VSPR004     DISPLAY '***--------------------------------------------***' |  |  |  |  | N/A | N/A |
| VSPR004     CLOSE  LHS542S2 |  |  |  |  | N/A | N/A |
| VSPR004 40-ALOCA-VAZIO-SAI.      EXIT |  |  |  |  | N/A | N/A |
| V       4-FIM                      SECTION |  |  |  |  | N/A | N/A |
| V           CLOSE  LHS542E1                                               002540 |  |  |  |  | N/A | N/A |
| V                  LHS542E2                                               002540 |  |  |  |  | N/A | N/A |
| V                  LHS542E3                                               002540 |  |  |  |  | N/A | N/A |
| V                  LHS542E4                                               002540 |  |  |  |  | N/A | N/A |
| VRESPON            LHS542E5                                               002540 |  |  |  |  | N/A | N/A |
| V689542            LHS542S3                                               002540 |  |  |  |  | N/A | N/A |
| V           IF  FS-LH542E1  NOT EQUAL  ZEROS |  |  |  |  | N/A | N/A |
| V               DISPLAY  'LHAN0542 -  ERRO NO FECHAMENTO LHS542E1'       FJAN0173 |  |  |  |  | N/A | N/A |
| V               DISPLAY  '            FILE STATUS = '  FS-LH542E1 |  |  |  |  | N/A | N/A |
| V               MOVE  4444                   TO  RETURN-CODE |  |  |  |  | N/A | N/A |
| V           IF  FS-LH542E2  NOT EQUAL  ZEROS |  |  |  |  | N/A | N/A |
| V               DISPLAY  'LHAN0542 -  ERRO NO FECHAMENTO LHS542E2'       FJAN0173 |  |  |  |  | N/A | N/A |
| V               DISPLAY  '            FILE STATUS = '  FS-LH542E2 |  |  |  |  | N/A | N/A |
| V           IF  FS-LH542E3  NOT EQUAL  ZEROS |  |  |  |  | N/A | N/A |
| V               DISPLAY  'LHAN0542 -  ERRO NO FECHAMENTO LHS542E3'       FJAN0173 |  |  |  |  | N/A | N/A |
| V               DISPLAY  '            FILE STATUS = '  FS-LH542E3 |  |  |  |  | N/A | N/A |
| V           IF  FS-LH542E4  NOT EQUAL  ZEROS |  |  |  |  | N/A | N/A |
| V               DISPLAY  'LHAN0542 -  ERRO NO FECHAMENTO LHS542E4'       FJAN0173 |  |  |  |  | N/A | N/A |
| V               DISPLAY  '            FILE STATUS = '  FS-LH542E4 |  |  |  |  | N/A | N/A |
| VRESPON     IF  FS-LH542E5  NOT EQUAL  ZEROS |  |  |  |  | N/A | N/A |
| VRESPON         DISPLAY  'LHAN0542 -  ERRO NO FECHAMENTO LHS542E5'       FJAN0173 |  |  |  |  | N/A | N/A |
| VRESPON         DISPLAY  '            FILE STATUS = '  FS-LH542E5 |  |  |  |  | N/A | N/A |
| VRESPON         MOVE  4444                   TO  RETURN-CODE |  |  |  |  | N/A | N/A |
| VRESPON         PERFORM  9-FIM-ANORMAL                                   FJAN0173 |  |  |  |  | N/A | N/A |
| V689542*    CLOSE  LHS542S1                                               002540 |  |  |  |  | N/A | N/A |
| V689542*    MOVE    SPACES                   TO  WAREA-82 |  |  |  |  | N/A | N/A |
| V689542*    MOVE    2                        TO  W82-OPCAO |  |  |  |  | N/A | N/A |
| V689542*    MOVE    WARQ-DDNAME1             TO  W82-DDNAME |  |  |  |  | N/A | N/A |
| V689542*    CALL    WDRAM0082  USING  WAREA-82 |  |  |  |  | N/A | N/A |
| V689542*    IF  W82-CODRET  NOT EQUAL  ZEROS |  |  |  |  | N/A | N/A |
| V689542*        DISPLAY W82-MENSERRO                                     FJAN0173 |  |  |  |  | N/A | N/A |
| V689542*        PERFORM  9-FIM-ANORMAL                                   FJAN0173 |  |  |  |  | N/A | N/A |
| V689542*    PERFORM 22-ALOCA-LHS542S2 |  |  |  |  | N/A | N/A |
| V689542*    DISPLAY '*** ARQUIVO BASTAO CORRESPONDENTE              ***' |  |  |  |  | N/A | N/A |
| V689542*    DISPLAY '*** ' WARQ-DSN-AUX |  |  |  |  | N/A | N/A |
| V689542*    DISPLAY '***                                            ***' |  |  |  |  | N/A | N/A |
| V689542*    DISPLAY '***--------------------------------------------***' |  |  |  |  | N/A | N/A |
| V689542*    CLOSE  LHS542S2                                              FJAN0173 |  |  |  |  | N/A | N/A |
| V689542*    IF  WRETURN  EQUAL  4 |  |  |  |  | N/A | N/A |
| V689542*        MOVE  WRETURN                TO  RETURN-CODE |  |  |  |  | N/A | N/A |
| V       4-FIM-SAI.                 EXIT |  |  |  |  | N/A | N/A |
| V       9-FIM-ANORMAL              SECTION |  |  |  |  | N/A | N/A |
| V               DISPLAY 'LHAN0542 -  ERRO NO FECHAMENTO LHS542E1'        FJAN0173 |  |  |  |  | N/A | N/A |
| V               DISPLAY '            FILE STATUS = '  FS-LH542E1 |  |  |  |  | N/A | N/A |
| V               DISPLAY 'LHAN0542 -  ERRO NO FECHAMENTO LHS542E2'        FJAN0173 |  |  |  |  | N/A | N/A |
| V               DISPLAY '            FILE STATUS = '  FS-LH542E2 |  |  |  |  | N/A | N/A |
| V               DISPLAY 'LHAN0542 -  ERRO NO FECHAMENTO LHS542E3'        FJAN0173 |  |  |  |  | N/A | N/A |
| V               DISPLAY '            FILE STATUS = '  FS-LH542E3 |  |  |  |  | N/A | N/A |
| V           MOVE  4444  TO  RETURN-CODE |  |  |  |  | N/A | N/A |
| V       9-FIM-ANORMAL-SAI.         EXIT |  |  |  |  | N/A | N/A |
| VMEMBER NAME  LHAN0705 |  |  |  |  | N/A | N/A |
| V       IDENTIFICATION DIVISION |  |  |  |  | N/A | N/A |
| V       PROGRAM-ID.     LHAN0705 |  |  |  |  | N/A | N/A |
| V       AUTHOR.         T520Q6S |  |  |  |  | N/A | N/A |
| 2013 |  |  |  |  | N/A | N/A |
| V      **                                                              * |  |  |  |  | N/A | N/A |
| V      *        OBJETIVO:  VALIDACAO FISICA E LOGICA DE ARQUIVO        * |  |  |  |  | N/A | N/A |
| V      *                   RECEBIDO DA AREA DE RISCOS SOLVENCIA COM    * |  |  |  |  | N/A | N/A |
| V      *                   OPERACOES MARCADAS COMO COMPULSORIO         * |  |  |  |  | N/A | N/A |
| V      *                                                               * |  |  |  |  | N/A | N/A |
| V      *  INPUT  :                                                     * |  |  |  |  | N/A | N/A |
| V      *  ARQUIVO ENTRADA    -> E1DQ0705   -  ARQUIVO LH VIA MICRO     * |  |  |  |  | N/A | N/A |
| V      *  ARQUIVO SAIDA      -> S1DQ0705   -  ARQUIVO LH PROC |  |  |  |  | N/A | N/A |
| VSPRT76*  ARQUIVO SAIDA      -> S2DQ0705   -  ARQUIVO ERRO             * |  |  |  |  | N/A | N/A |
| V      *                    M A N U T E N C A O                        * |  |  |  |  | N/A | N/A |
| V      *   DATA    USUARIO   DESCRICAO                                 * |  |  |  |  | N/A | N/A |
| V      * 13-05-14  ROBERTO   ACEITAR ARQUIVO VAZIO                     * |  |  |  |  | N/A | N/A |
| V697665* 22-09-14  MARCELLO  OPERACOES DESCONSIGNADAS                  * |  |  |  |  | N/A | N/A |
| V  ||  *                     - UNIFICACAO BOOKS LHCE0430 E LHCE0431    * |  |  |  |  | N/A | N/A |
| V  ||  *                     - VALIDACOES:                             * |  |  |  |  | N/A | N/A |
| SUBMOD                            * |  |  |  |  | N/A | N/A |
| SUBTIPO              * |  |  |  |  | N/A | N/A |
| SUBMOD CONTRA INFO. ADIC |  |  |  |  | N/A | N/A |
| V  ||  *                       - DATAS                                 * |  |  |  |  | N/A | N/A |
| CNPJ                  * |  |  |  |  | N/A | N/A |
| V  ||  *                       - VALORES E PERCENTUAIS NUMERICOS       * |  |  |  |  | N/A | N/A |
| V  ||  *                       - FORMATO CONTRATO                      * |  |  |  |  | N/A | N/A |
| V  ||  *                       - FORMATO COD |  |  |  |  | N/A | N/A |
| V  ||  *                       - FORMATO NUC3                          * |  |  |  |  | N/A | N/A |
| DESCONSIG |  |  |  |  | N/A | N/A |
| V  ||  *                       - FORMATO CHASSI                        * |  |  |  |  | N/A | N/A |
| V  ||  *                     - QTE MAXIMA DE INCONSISTENCIAS ASSINALA- * |  |  |  |  | N/A | N/A |
| V  ||  *                       DAS IGUAL A 10, APESAR DE INDICAR ATE   * |  |  |  |  | N/A | N/A |
| V697665*                       30 OCORRENCIAS ATRAVES DE WORKING       * |  |  |  |  | N/A | N/A |
| VCORBAN* 21-10-16 - ROBERTO  - INCLUSAO DE TATICO PARA CORRESPONDENTE  * |  |  |  |  | N/A | N/A |
| VCORBAN*                       BANCARIO TP-REG=5,TPINFO=16,SBINFO=01   * |  |  |  |  | N/A | N/A |
| VCORBAN*                       CD-INFO=CNPJ DO CORRESPONDENTE          * |  |  |  |  | N/A | N/A |
| VCORBAN*                       EMERGENCIAL - COMPILAR COM BOOK ALTERADO* |  |  |  |  | N/A | N/A |
| VV00001* 10-02-17 - ADELMO   - RECOMPILA§¥O BOOK LHCP3402              * |  |  |  |  | N/A | N/A |
| VCMP01 * 07-04-17 - CRISTIANE  RECOMPILAR BOOK LHCP3402 INF |  |  |  |  | N/A | N/A |
| VMANO1 * 19-07-17 - JMANOEL    RECOMPILAR BOOK LHCP3402 ANEXO 03       * |  |  |  |  | N/A | N/A |
| VMANO2 * 05-10-17 - JMANOEL    RECOMPILAR BOOK LHCP3402 ANEXO 03-1803  * |  |  |  |  | N/A | N/A |
| VOLIVA1* 07-08-18 - OLIVEIRA   SICOR; CADIP E COLATERAL FINANCEIRO     * |  |  |  |  | N/A | N/A |
| VADELMO* 04-07-19 - ADELMO     ECOXX - CAMPO DE INDEXADOR COMP         * |  |  |  |  | N/A | N/A |
| BOOK LHCP3402         * |  |  |  |  | N/A | N/A |
| BOOK LHCP3402                  * |  |  |  |  | N/A | N/A |
| VSPRT04*  TRATAMENTO DE TIPO DE INFORMA§¥O 06                          * |  |  |  |  | N/A | N/A |
| VXPRT06*  TRATAMENTO DE FGI                                            * |  |  |  |  | N/A | N/A |
| BOOK LHCP3402------------------* |  |  |  |  | N/A | N/A |
| VXPRT07*---------------------------------------------------------------* |  |  |  |  | N/A | N/A |
| VSPRT09*- TRATAMENTO DE INFORMA§¥O ADICIONAO 1408                      * |  |  |  |  | N/A | N/A |
| VSPRT09*- 14 "(NR) APLICA§¥O REGULATÌRIA VINCULA§¥O LEGAL E REGULATÌRIA* |  |  |  |  | N/A | N/A |
| VSPRT09*-   01 CUMPRIMENTO DE DIRECIONAMENTO OBRIGATÌRIO DE DEPÌSITOS £* |  |  |  |  | N/A | N/A |
| VSPRT09*-      MICRO FINANCAS                                          * |  |  |  |  | N/A | N/A |
| VSPRT09*-   02 CUMPRIMENTO DE EXIGIBILIDADES DO CR©DITO RURAL MCR      * |  |  |  |  | N/A | N/A |
| VSPRT09*-   03 REDU§¥O DE RECOLHIMENTO COMPULSÌRIO SOBRE RECURSOS VISTA* |  |  |  |  | N/A | N/A |
| VSPRT09*-      PROGRAMAS DE INVESTIMENTO                               * |  |  |  |  | N/A | N/A |
| VSPRT09*-   04 REDU§¥O DE RECOLHIMENTO COMPULSÌRIO SOBRE RECURSOS VISTA* |  |  |  |  | N/A | N/A |
| VSPRT09*-      ESPECIFICO DE CREDITO RURAL                             * |  |  |  |  | N/A | N/A |
| VSPRT09*-   05 CUMPRIMENTO DE DIRECIONAMENTO OBRIGATÌRIO DE DEPÌSITOS  * |  |  |  |  | N/A | N/A |
| VSPRT09*-      DE POUPAN§A LIVRE                                       * |  |  |  |  | N/A | N/A |
| VSPRT09*-   06 REDU§¥O DE RECOLHIMENTO COMPULSÌRIO SOBRE RECURSOS  A   * |  |  |  |  | N/A | N/A |
| VSPRT09*-      PRAZO                                                   * |  |  |  |  | N/A | N/A |
| VSPRT09*-   07 TRANSFERIDAS AO BANCO CENTRAL EM OPERA§¥O DE REDESCONTO * |  |  |  |  | N/A | N/A |
| VSPRT09*-      OU EMPRESTIMO                                           * |  |  |  |  | N/A | N/A |
| VSPRT09*-   08 OUTRO USO REGULATÌRIO                                   * |  |  |  |  | N/A | N/A |
| VSPRT09*-      (NR) ANEXO 37: TIPO DE USO REGULATÌRIO                  * |  |  |  |  | N/A | N/A |
| VSPRT09*-      DOM­NIO DESCRI§¥O                                       * |  |  |  |  | N/A | N/A |
| VSPRT09*-      01 OPERA§ÍES CONTRATADAS NO ¡MBITO DO PRONAMPE          * |  |  |  |  | N/A | N/A |
| VSPRT09*-         LEI 13990  PROGRAMA NACIONAL DE APOIO                * |  |  |  |  | N/A | N/A |
| VSPRT09*-         AS MICROEMPRESAS E EMPRESAS DE PEQUENO PORTE)        * |  |  |  |  | N/A | N/A |
| VSPRT09*-      02 OPERA§ÍES CONCEDIDAS NO ¡MBITO DO FGI PEAC           * |  |  |  |  | N/A | N/A |
| VSPRT09*-         MEDIDA PROVISÌRIA NÌ 975 - PROGRAMA                  * |  |  |  |  | N/A | N/A |
| VSPRT09*-         EMERGENCIAL DE ACESSO A CR©DITO                      * |  |  |  |  | N/A | N/A |
| VSPRT09*-      03 OPERA§ÍES CONTRATADAS NO ¡MBITO DA CIRCULAR NÌ 4 |  |  |  |  | N/A | N/A |
| VSPRT09*-         DEDU§ÍES SOBRE AS EXIGIBILIDADES DOS RECURSOS DE DEPÌ* |  |  |  |  | N/A | N/A |
| VSPRT09*-         SITOS EM POUPAN¸A                                    * |  |  |  |  | N/A | N/A |
| VSPRT09*-      04 OPERA§ÍES CONTRATADAS NO ¡MBITO DO CGPE              * |  |  |  |  | N/A | N/A |
| VSPRT09*-         RESOLU§¥O NÌ 4 |  |  |  |  | N/A | N/A |
| VSPRT09*-         PROGRAMA DE CAPITAL GIRO PARA PRESERVA§¥O DE EMPRESA** |  |  |  |  | N/A | N/A |
| VSPRT09*-      99 OUTROS                                               * |  |  |  |  | N/A | N/A |
| VSPRT17*---------------------------------------------------------------* |  |  |  |  | N/A | N/A |
| 21 - RECOMNPILACAO BOOK - LIMITES                          * |  |  |  |  | N/A | N/A |
| 03  | T520Q6S    |  GRAVITY - DESCOMISSING VSAM        * |  |  |  |  | N/A | N/A |
| VGRAVIT*             | T520Q6S    |  DESCONTINUAR MZV5002A              * |  |  |  |  | N/A | N/A |
| VGRAVIT*             | T520Q6S    |  DATA-BASE                          * |  |  |  |  | N/A | N/A |
| VSPRT74*---------------------------------------------------------------* |  |  |  |  | N/A | N/A |
| VSPRT74*  SPRINT 74 - RECOMPILAR BOOK LHCP3402 ANEXO 35 E 37           * |  |  |  |  | N/A | N/A |
| VSPRT76*  SPRINT 76 -|CABRAL      |MELHORIAS:                           * |  |  |  |  | N/A | N/A |
| VSPRT76*                          |ARQUIVO VAZIO 'STOP' O PROCESSAMENTO * |  |  |  |  | N/A | N/A |
| MZ* |  |  |  |  | N/A | N/A |
| MOD   * |  |  |  |  | N/A | N/A |
| VSPRT76*                          |SE ERRO , GERA RC = 1 ACIONA GESTOR  * |  |  |  |  | N/A | N/A |
| VSPRT76*                          |GERA S2DQ0709 ARQ REJEITADOS GESTOR  * |  |  |  |  | N/A | N/A |
| VSPRT76*----------------------------------------------------------------* |  |  |  |  | N/A | N/A |
| VSPRT77* SPRINT77 - INCLUIR TRATAMENTO DE TATICO PARA INFO ADIC 1701    * |  |  |  |  | N/A | N/A |
| VSPRT77*----------------------------------------------------------------* |  |  |  |  | N/A | N/A |
| V      *================================================================* |  |  |  |  | N/A | N/A |
| V       ENVIRONMENT       DIVISION |  |  |  |  | N/A | N/A |
| V       CONFIGURATION     SECTION |  |  |  |  | N/A | N/A |
| V       SPECIAL-NAMES.    DECIMAL-POINT IS COMMA |  |  |  |  | N/A | N/A |
| V       INPUT-OUTPUT      SECTION |  |  |  |  | N/A | N/A |
| V           SELECT  E1DQ0705            ASSIGN  TO  E1DQ0705 |  |  |  |  | N/A | N/A |
| V           SELECT  S1DQ0705            ASSIGN  TO  S1DQ0705 |  |  |  |  | N/A | N/A |
| VSPRT76     SELECT  S2DQ0705            ASSIGN  TO  S2DQ0705 |  |  |  |  | N/A | N/A |
| VGRAV  *    SELECT  MZV5002E            ASSIGN  TO MZV5002E |  |  |  |  | N/A | N/A |
| VGRAV  *            ORGANIZATION        INDEXED |  |  |  |  | N/A | N/A |
| VGRAV  *            ACCESS              SEQUENTIAL |  |  |  |  | N/A | N/A |
| VGRAV  *            RECORD KEY          CHAVE-5002 |  |  |  |  | N/A | N/A |
| VGRAV  *            FILE STATUS         FS-MZV5002E |  |  |  |  | N/A | N/A |
| V       DATA    DIVISION |  |  |  |  | N/A | N/A |
| V       FILE SECTION |  |  |  |  | N/A | N/A |
| V      *     ARQUIVO DE OPERACOES MARCADAS COMPULSORIO - RECEBIDA DE |  |  |  |  | N/A | N/A |
| V      *     ARQUIVO RECEBIDO DE RISCOS SOLVENCIA |  |  |  |  | N/A | N/A |
| V       FD  E1DQ0705 |  |  |  |  | N/A | N/A |
| V           LABEL     RECORD        STANDARD |  |  |  |  | N/A | N/A |
| V           BLOCK   CONTAINS        0     RECORDS |  |  |  |  | N/A | N/A |
| V           RECORD    CONTAINS    260     CHARACTERS |  |  |  |  | N/A | N/A |
| V           RECORDING MODE IS F |  |  |  |  | N/A | N/A |
| V697665 01  REG-E1DQ0705          PIC  X(260) |  |  |  |  | N/A | N/A |
| V      *     ARQUIVO DE OPERACOES MARCADAS COMPULSORIO - APOS VALIDACAO |  |  |  |  | N/A | N/A |
| V       FD  S1DQ0705 |  |  |  |  | N/A | N/A |
| V       01  REG-S1DQ0705          PIC  X(260) |  |  |  |  | N/A | N/A |
| VSPRT76*---------------------------------------------------------------* |  |  |  |  | N/A | N/A |
| V  !!  *     ARQUIVO DE OPERACOES REJEITADOS - ERROS |  |  |  |  | N/A | N/A |
| V  !!  *---------------------------------------------------------------* |  |  |  |  | N/A | N/A |
| V  !! |  |  |  |  | N/A | N/A |
| V  !!   FD  S2DQ0705 |  |  |  |  | N/A | N/A |
| V  !!       LABEL     RECORD        STANDARD |  |  |  |  | N/A | N/A |
| V  !!       BLOCK   CONTAINS        0     RECORDS |  |  |  |  | N/A | N/A |
| V  !!       RECORD    CONTAINS    260     CHARACTERS |  |  |  |  | N/A | N/A |
| V  !!       RECORDING MODE IS F |  |  |  |  | N/A | N/A |
| VSPRT76 01  REG-S2DQ0705          PIC  X(260) |  |  |  |  | N/A | N/A |
| VGRAV  *---------------------------------------------------------------* |  |  |  |  | N/A | N/A |
| VGRAV  * ARQ COM INFORMACOES DE DATA BASE QUE ESTA SENDO EXECUTADO |  |  |  |  | N/A | N/A |
| VGRAV  * |  |  |  |  | N/A | N/A |
| VGRAV  *FD  MZV5002E |  |  |  |  | N/A | N/A |
| VGRAV  *01  REG-MZCE5002 |  |  |  |  | N/A | N/A |
| VGRAV  *    ++INCLUDE MZCE5002 |  |  |  |  | N/A | N/A |
| V      *----------------------------------------------------------------* |  |  |  |  | N/A | N/A |
| V       WORKING-STORAGE   SECTION |  |  |  |  | N/A | N/A |
| V       01  CT-CONTROLES |  |  |  |  | N/A | N/A |
| V         05  FS-MZV5002E                    PIC 9(002)    VALUE ZEROS |  |  |  |  | N/A | N/A |
| V         05  CT-FIM                         PIC X(001)    VALUE 'N' |  |  |  |  | N/A | N/A |
| V         05  PGMNAME                        PIC X(008) VALUE 'LHAN0705' |  |  |  |  | N/A | N/A |
| V         05  CT-MZ9CV001                    PIC X(008) VALUE 'MZ9CV001' |  |  |  |  | N/A | N/A |
| V         05  CT-DRAM0018                    PIC X(008) VALUE 'DRAM0018' |  |  |  |  | N/A | N/A |
| V697665   05  CT-DRAM0152                    PIC X(008) VALUE 'DRAM0152' |  |  |  |  | N/A | N/A |
| V  ||     05  CT-DRAM0022                    PIC X(008) VALUE 'DRAM0022' |  |  |  |  | N/A | N/A |
| V  ||     05  CT-DRAM0038                    PIC X(008) VALUE 'DRAM0038' |  |  |  |  | N/A | N/A |
| V  ||     05  CT-LHBR0700                    PIC X(008) VALUE 'LHBR0700' |  |  |  |  | N/A | N/A |
| V  ||     05  CT-2ASTER                      PIC X(002)    VALUE '**' |  |  |  |  | N/A | N/A |
| V  ||     05  CT-MAIS                        PIC X(001)    VALUE '+' |  |  |  |  | N/A | N/A |
| V697665   05  CT-HIFEN                       PIC X(001)    VALUE '-' |  |  |  |  | N/A | N/A |
| V         05  STCODE                         PIC 9(002)    VALUE 99 |  |  |  |  | N/A | N/A |
| V         05  CT-INICIO                      PIC X(001)    VALUE 'S' |  |  |  |  | N/A | N/A |
| V         05  CT-CANCELA                     PIC X(001)    VALUE 'N' |  |  |  |  | N/A | N/A |
| V         05  CT-ERRO                        PIC X(001)    VALUE 'N' |  |  |  |  | N/A | N/A |
| V         05  CT-SIM                         PIC X(001)    VALUE 'S' |  |  |  |  | N/A | N/A |
| V         05  CT-NAO                         PIC X(001)    VALUE 'N' |  |  |  |  | N/A | N/A |
| V         05  CT-MENS-ERRO                   PIC X(031) |  |  |  |  | N/A | N/A |
| V                               VALUE 'REGISTRO REJEITADO' |  |  |  |  | N/A | N/A |
| V         05  CT-MENS-OK                     PIC X(031) |  |  |  |  | N/A | N/A |
| V                               VALUE 'REGISTRO VALIDO' |  |  |  |  | N/A | N/A |
| V         05  CT-X-0                         PIC X(001)    VALUE '0' |  |  |  |  | N/A | N/A |
| V         05  CT-X-1                         PIC X(001)    VALUE '1' |  |  |  |  | N/A | N/A |
| V         05  CT-X-9                         PIC X(001)    VALUE '9' |  |  |  |  | N/A | N/A |
| V         05  CT-00                          PIC 9(002)    VALUE 00 |  |  |  |  | N/A | N/A |
| V         05  CT-01                          PIC 9(002)    VALUE 01 |  |  |  |  | N/A | N/A |
| V         05  CT-02                          PIC 9(002)    VALUE 02 |  |  |  |  | N/A | N/A |
| V         05  CT-03                          PIC 9(002)    VALUE 03 |  |  |  |  | N/A | N/A |
| V         05  CT-04                          PIC 9(002)    VALUE 04 |  |  |  |  | N/A | N/A |
| V         05  CT-05                          PIC 9(002)    VALUE 05 |  |  |  |  | N/A | N/A |
| V         05  CT-06                          PIC 9(002)    VALUE 06 |  |  |  |  | N/A | N/A |
| V         05  CT-07                          PIC 9(002)    VALUE 07 |  |  |  |  | N/A | N/A |
| V         05  CT-08                          PIC 9(002)    VALUE 08 |  |  |  |  | N/A | N/A |
| V         05  CT-09                          PIC 9(002)    VALUE 09 |  |  |  |  | N/A | N/A |
| V         05  CT-10                          PIC 9(002)    VALUE 10 |  |  |  |  | N/A | N/A |
| V         05  CT-11                          PIC 9(002)    VALUE 11 |  |  |  |  | N/A | N/A |
| V         05  CT-12                          PIC 9(002)    VALUE 12 |  |  |  |  | N/A | N/A |
| V         05  CT-13                          PIC 9(002)    VALUE 13 |  |  |  |  | N/A | N/A |
| V         05  CT-14                          PIC 9(002)    VALUE 14 |  |  |  |  | N/A | N/A |
| V         05  CT-15                          PIC 9(002)    VALUE 15 |  |  |  |  | N/A | N/A |
| V         05  CT-16                          PIC 9(002)    VALUE 16 |  |  |  |  | N/A | N/A |
| V         05  CT-17                          PIC 9(002)    VALUE 17 |  |  |  |  | N/A | N/A |
| V         05  CT-18                          PIC 9(002)    VALUE 18 |  |  |  |  | N/A | N/A |
| V         05  CT-19                          PIC 9(002)    VALUE 19 |  |  |  |  | N/A | N/A |
| V         05  CT-20                          PIC 9(002)    VALUE 20 |  |  |  |  | N/A | N/A |
| V         05  CT-21                          PIC 9(002)    VALUE 21 |  |  |  |  | N/A | N/A |
| V         05  CT-22                          PIC 9(002)    VALUE 22 |  |  |  |  | N/A | N/A |
| VSPRT76 01  WS-CHAVES |  |  |  |  | N/A | N/A |
| VSPRT76     02  WS-CHAVE-E1 |  |  |  |  | N/A | N/A |
| VSPRT76     05  E1-CD-ITF               PIC X(004)    VALUE SPACES |  |  |  |  | N/A | N/A |
| VSPRT76     05  E1-NR-OPR-X             PIC X(033)    VALUE SPACES |  |  |  |  | N/A | N/A |
| VSPRT76     05  E1-MOD-X                PIC X(004)    VALUE SPACES |  |  |  |  | N/A | N/A |
| VSPRT76 01  WS-CHAVE-E1-ANT             PIC X(041)    VALUE SPACES |  |  |  |  | N/A | N/A |
| V      *AREA DE BOOK DE ENTRADA |  |  |  |  | N/A | N/A |
| V       01  WS-E1DQ0705 |  |  |  |  | N/A | N/A |
| V       ++INCLUDE LHCE0430 |  |  |  |  | N/A | N/A |
| V      *AREA DE BOOK DE SAIDA |  |  |  |  | N/A | N/A |
| V697665*01  WS-S1DQ0705 |  |  |  |  | N/A | N/A |
| V697665*++INCLUDE LHCE0431 |  |  |  |  | N/A | N/A |
| V697665*----------------------------------------------------------------* |  |  |  |  | N/A | N/A |
| V  ||  * BOOKS |  |  |  |  | N/A | N/A |
| V  ||  *----------------------------------------------------------------* |  |  |  |  | N/A | N/A |
| V  ||  * |  |  |  |  | N/A | N/A |
| V  ||  *--- ANEXOS SCR3040 |  |  |  |  | N/A | N/A |
| V  ||       COPY LHCP3402 |  |  |  |  | N/A | N/A |
| V  ||  *--- LINKAGE LHBR0700 |  |  |  |  | N/A | N/A |
| V  ||   01  LI-LHCE0700 |  |  |  |  | N/A | N/A |
| V  ||       COPY LHCE0700 |  |  |  |  | N/A | N/A |
| V      * ACUMULADORES |  |  |  |  | N/A | N/A |
| V       01  AC-ACUMULADORES |  |  |  |  | N/A | N/A |
| V           03  AC-RG-LIDO                   PIC 9(009)    VALUE ZEROS |  |  |  |  | N/A | N/A |
| V           03  AC-RG-ERRO                   PIC 9(009)    VALUE ZEROS |  |  |  |  | N/A | N/A |
| V           03  AC-RG-VALI                   PIC 9(009)    VALUE ZEROS |  |  |  |  | N/A | N/A |
| V           03  AC-RG-GRAV                   PIC 9(009)    VALUE ZEROS |  |  |  |  | N/A | N/A |
| V      ****  AREA DE TRATAMENTO DE DATAS |  |  |  |  | N/A | N/A |
| V       01 WK-DTCORRENTE                     PIC 9(006) |  |  |  |  | N/A | N/A |
| V       01 FILLER            REDEFINES       WK-DTCORRENTE |  |  |  |  | N/A | N/A |
| V          03 WK-AACORR                      PIC 9(002) |  |  |  |  | N/A | N/A |
| V          03 WK-MMCORR                      PIC 9(002) |  |  |  |  | N/A | N/A |
| V          03 WK-DDCORR                      PIC 9(002) |  |  |  |  | N/A | N/A |
| V       01 WK-DTA-PROC                       PIC 9(008) |  |  |  |  | N/A | N/A |
| V       01 FILLER            REDEFINES       WK-DTA-PROC |  |  |  |  | N/A | N/A |
| V          03 WK-SEC-PROC                    PIC 9(002) |  |  |  |  | N/A | N/A |
| V          03 WK-ANO-PROC                    PIC 9(002) |  |  |  |  | N/A | N/A |
| V          03 WK-MES-PROC                    PIC 9(002) |  |  |  |  | N/A | N/A |
| V          03 WK-DIA-PROC                    PIC 9(002) |  |  |  |  | N/A | N/A |
| V       01  WK-DATA-BASE                PIC 9(008)    VALUE ZEROS |  |  |  |  | N/A | N/A |
| VSPRT77 01  WK-DT-REESTRU-NUM |  |  |  |  | N/A | N/A |
| VSPRT77     03   WK-AA-REESTRU-NUM          PIC  X(004) |  |  |  |  | N/A | N/A |
| VSPRT77     03   WK-MM-REESTRU-NUM          PIC  X(002) |  |  |  |  | N/A | N/A |
| VSPRT77     03   WK-DD-REESTRU-NUM          PIC  X(002) |  |  |  |  | N/A | N/A |
| V       01  VARIAVEIS |  |  |  |  | N/A | N/A |
| V         05  WK-TP-REG                   PIC X(001)     VALUE SPACES |  |  |  |  | N/A | N/A |
| VECCOX *  05  WK-IND1                     PIC 9(003)     VALUE ZEROS |  |  |  |  | N/A | N/A |
| VECCOX    05  WK-IND1                     PIC S9(4) COMP VALUE ZEROS |  |  |  |  | N/A | N/A |
| V697665   05  WK-CONTRATO                 PIC X(033) |  |  |  |  | N/A | N/A |
| V  ||     05  WK-TIPOSUB                  PIC 9(004) |  |  |  |  | N/A | N/A |
| V  ||     05  WK-CD-RETORNO               PIC 9(002) OCCURS 30 |  |  |  |  | N/A | N/A |
| V  ||  *--- AREA PARA LHCP3402 |  |  |  |  | N/A | N/A |
| V  ||   01 WK-LHCP3402 |  |  |  |  | N/A | N/A |
| V  ||      03 WK-CD-MOD                      PIC 9(004) VALUE ZEROS |  |  |  |  | N/A | N/A |
| V  ||      03 WK-CD-INFO-ADIC                PIC 9(004) VALUE ZEROS |  |  |  |  | N/A | N/A |
| V  ||  *--- AREA PARA DRAM0152 - VALIDACAO DE DATA |  |  |  |  | N/A | N/A |
| V  ||   01 WK-DRAM0152 |  |  |  |  | N/A | N/A |
| V  ||      03 WK-0152-DATA                   PIC 9(008) |  |  |  |  | N/A | N/A |
| V  ||      03 WK-0152-RET                    PIC 9(001) |  |  |  |  | N/A | N/A |
| V  ||  *--- AREA PARA DRAM0022 - VALIDACAO DE CPF |  |  |  |  | N/A | N/A |
| V  ||   01 WK-DRAM0022 |  |  |  |  | N/A | N/A |
| V  ||      03 WK-0022-OPCAO                  PIC 9(001) |  |  |  |  | N/A | N/A |
| V  ||      03 WK-0022-CPF                    PIC 9(011) |  |  |  |  | N/A | N/A |
| V  ||  *--- AREA PARA DRAM0038 - VALIDACAO DE CNPJ |  |  |  |  | N/A | N/A |
| V  ||   01 WK-DRAM0038 |  |  |  |  | N/A | N/A |
| V  ||      03 WK-0038-CNPJ                   PIC 9(014) |  |  |  |  | N/A | N/A |
| V  ||      03 FILLER               REDEFINES WK-0038-CNPJ |  |  |  |  | N/A | N/A |
| V  ||         05 WK-0038-RAIZ-FILIAL         PIC 9(012) |  |  |  |  | N/A | N/A |
| V  ||         05 WK-0038-DIGITO              PIC X(002) |  |  |  |  | N/A | N/A |
| V  ||  *--- |  |  |  |  | N/A | N/A |
| V  ||  *--- SWITCHES |  |  |  |  | N/A | N/A |
| V  ||   01 SW-SWITCHES |  |  |  |  | N/A | N/A |
| V  ||      05 SW-MODSUB                      PIC X(001) VALUE 'S' |  |  |  |  | N/A | N/A |
| V  ||         88 SW-MODSUB-OK                           VALUE 'S' |  |  |  |  | N/A | N/A |
| V  ||         88 SW-MODSUB-NOK                          VALUE 'N' |  |  |  |  | N/A | N/A |
| V  ||      05 SW-TIPOSUB                     PIC X(001) VALUE 'S' |  |  |  |  | N/A | N/A |
| V  ||         88 SW-TIPOSUB-OK                          VALUE 'S' |  |  |  |  | N/A | N/A |
| V697665       88 SW-TIPOSUB-NOK                         VALUE 'N' |  |  |  |  | N/A | N/A |
| CHAMAR A SUB-ROTINA 'MZ9CV001' |  |  |  |  | N/A | N/A |
| VGRAV  *----------------------------------------------------------------* |  |  |  |  | N/A | N/A |
| VGRAV  *    AREA PARA MENSAGEM DE ERRO EM ACESSO A TABELA               * |  |  |  |  | N/A | N/A |
| VGRAV   01         WS-MSG-TABELA |  |  |  |  | N/A | N/A |
| VGRAV       03     FILLER               PIC  X(022) VALUE |  |  |  |  | N/A | N/A |
| VGRAV              'ERRO MZ9CV001 TABELA ' |  |  |  |  | N/A | N/A |
| VGRAV       03     WS-TABELA            PIC  X(003) |  |  |  |  | N/A | N/A |
| VGRAV       03     FILLER               PIC  X(005) VALUE   ' ACC ' |  |  |  |  | N/A | N/A |
| VGRAV       03      WS-ACC               PIC  X(001) |  |  |  |  | N/A | N/A |
| VGRAV       03     FILLER               PIC  X(005) VALUE   ' RET ' |  |  |  |  | N/A | N/A |
| VGRAV       03     WS-STATUS            PIC  X(002) |  |  |  |  | N/A | N/A |
| VGRAV       03     FILLER               PIC  X(005) VALUE   ' SQL ' |  |  |  |  | N/A | N/A |
| VGRAV       03     WS-SQLCODE           PIC  S9(005) |  |  |  |  | N/A | N/A |
| VGRAV       03     FILLER               PIC  X(005) VALUE   ' ERR ' |  |  |  |  | N/A | N/A |
| VGRAV       03     WS-SQLERRT           PIC  9(005) |  |  |  |  | N/A | N/A |
| VGRAV       03     FILLER               PIC  X(001) VALUE   ' ' |  |  |  |  | N/A | N/A |
| VGRAV       03     WS-SQLERRM           PIC  X(020) |  |  |  |  | N/A | N/A |
| VGRAV |  |  |  |  | N/A | N/A |
| V      *    AREA PARA COPY DOS BOOKS |  |  |  |  | N/A | N/A |
| VGRAV  *--- DETALHE  MZV5002E |  |  |  |  | N/A | N/A |
| VGRAV   01  REG-MZTC5001 |  |  |  |  | N/A | N/A |
| VGRAV   ++INCLUDE MZTC5001 |  |  |  |  | N/A | N/A |
| VGRAV  *================================================================* |  |  |  |  | N/A | N/A |
| VGRAV  *           AREAS DE SUBROTINA                                  * |  |  |  |  | N/A | N/A |
| VGRAV   ++INCLUDE MZTCL000 |  |  |  |  | N/A | N/A |
| VGRAV   ++INCLUDE MZTCL040 |  |  |  |  | N/A | N/A |
| V      *   PROCESSAMENTO DO PROGRAMA |  |  |  |  | N/A | N/A |
| V       PROCEDURE   DIVISION |  |  |  |  | N/A | N/A |
| V       R000-PRINCIPAL                  SECTION |  |  |  |  | N/A | N/A |
| V           PERFORM  R100-INICIO |  |  |  |  | N/A | N/A |
| V           PERFORM  R200-PROCESSAMENTO UNTIL  CT-FIM EQUAL CT-SIM |  |  |  |  | N/A | N/A |
| V           PERFORM  R900-FIM |  |  |  |  | N/A | N/A |
| V      *    ROTINA  DE  INICIO                                         * |  |  |  |  | N/A | N/A |
| V       R100-INICIO                     SECTION |  |  |  |  | N/A | N/A |
| V           MOVE ZEROS TO AC-RG-LIDO |  |  |  |  | N/A | N/A |
| V                         AC-RG-ERRO |  |  |  |  | N/A | N/A |
| V                         AC-RG-VALI |  |  |  |  | N/A | N/A |
| V                         AC-RG-GRAV |  |  |  |  | N/A | N/A |
| V           DISPLAY '********************************************' |  |  |  |  | N/A | N/A |
| V           DISPLAY '**         PROGRAMA LHAN0705              **' |  |  |  |  | N/A | N/A |
| V           DISPLAY '**   VALIDACAO FISICA DO ARQUIVO DE       **' |  |  |  |  | N/A | N/A |
| V           DISPLAY '**   ENTRADA - RECEBIDO DA AREA DE CAC    **' |  |  |  |  | N/A | N/A |
| V           ACCEPT   WK-DTCORRENTE    FROM     DATE |  |  |  |  | N/A | N/A |
| V           MOVE     WK-AACORR        TO       WK-ANO-PROC |  |  |  |  | N/A | N/A |
| V           MOVE     WK-MMCORR        TO       WK-MES-PROC |  |  |  |  | N/A | N/A |
| V           MOVE     WK-DDCORR        TO       WK-DIA-PROC |  |  |  |  | N/A | N/A |
| V           IF       WK-AACORR        GREATER  50 |  |  |  |  | N/A | N/A |
| V                    MOVE   19        TO       WK-SEC-PROC |  |  |  |  | N/A | N/A |
| V                    MOVE   20        TO       WK-SEC-PROC |  |  |  |  | N/A | N/A |
| VGRAV  *    CHAMADA A ROTINA GEN¾RICA MZ9CV001 -      TABELA  V111      * |  |  |  |  | N/A | N/A |
| VGRAV       MOVE  SPACES                  TO  CHAVEH-5001 |  |  |  |  | N/A | N/A |
| VGRAV       MOVE  ZEROS                   TO  TPREG-5001 |  |  |  |  | N/A | N/A |
| VGRAV       MOVE  ZEROS                   TO  ZEROS-5001 |  |  |  |  | N/A | N/A |
| VGRAV       MOVE  'S'                TO      MZL0-TIPOACC |  |  |  |  | N/A | N/A |
| VGRAV       MOVE  MZTC5001           TO      MZL0-MZDT001 |  |  |  |  | N/A | N/A |
| VGRAV       CALL  CT-MZ9CV001        USING   MZTCL000 |  |  |  |  | N/A | N/A |
| VGRAV       IF    MZL0-CDRETORN   EQUAL           '00' |  |  |  |  | N/A | N/A |
| VGRAV             MOVE  MZL0-MZDT001    TO  MZTC5001 |  |  |  |  | N/A | N/A |
| VGRAV             MOVE  DATA-BASE-5002  TO  WK-DATA-BASE |  |  |  |  | N/A | N/A |
| VGRAV             DISPLAY '*-------------------------------------------*' |  |  |  |  | N/A | N/A |
| VGRAV             DISPLAY '*    PROGRAMA LHAN0705 - CALL MZ - DATA BASE*' |  |  |  |  | N/A | N/A |
| VGRAV             DISPLAY '*  *  DT BASE DO SIST |  |  |  |  | N/A | N/A |
| VGRAV       ELSE |  |  |  |  | N/A | N/A |
| VGRAV             MOVE  MZL0-TABELA        TO   WS-TABELA |  |  |  |  | N/A | N/A |
| VGRAV             MOVE  MZL0-TIPOACC       TO   WS-ACC |  |  |  |  | N/A | N/A |
| VGRAV             MOVE  MZL0-CDRETORN      TO   WS-STATUS |  |  |  |  | N/A | N/A |
| VGRAV             MOVE  MZL0-SQLCODE       TO   WS-SQLCODE |  |  |  |  | N/A | N/A |
| VGRAV             MOVE  MZL0-SQLERRM-TAM   TO   WS-SQLERRT |  |  |  |  | N/A | N/A |
| VGRAV             MOVE  MZL0-SQLERRM-DATA  TO   WS-SQLERRM |  |  |  |  | N/A | N/A |
| VGRAV             DISPLAY '*********************************************' |  |  |  |  | N/A | N/A |
| VGRAV             DISPLAY '    PROGRAMA LHAN0705  -   CANCELADO         ' |  |  |  |  | N/A | N/A |
| VGRAV             DISPLAY '  ' |  |  |  |  | N/A | N/A |
| VGRAV             DISPLAY '      ERRO DE LEITURA DE TABELA         ' |  |  |  |  | N/A | N/A |
| VGRAV             DISPLAY '  '   WS-MSG-TABELA |  |  |  |  | N/A | N/A |
| VGRAV             GO TO  R990-CANCELA |  |  |  |  | N/A | N/A |
| VGRAV       END-IF |  |  |  |  | N/A | N/A |
| V      *-------- ABERTURA DO ARQUIVO DE DATA BASE |  |  |  |  | N/A | N/A |
| VGRAV  *    OPEN INPUT  MZV5002E |  |  |  |  | N/A | N/A |
| VGRAV  *    IF  FS-MZV5002E  NOT EQUAL  '00' AND '97' |  |  |  |  | N/A | N/A |
| VGRAV  *        DISPLAY '***********************************************' |  |  |  |  | N/A | N/A |
| VGRAV  *        DISPLAY '      PROGRAMA LHAN0705  -   CANCELADO         ' |  |  |  |  | N/A | N/A |
| VGRAV  *        DISPLAY '  ' |  |  |  |  | N/A | N/A |
| VGRAV  *        DISPLAY '        ERRO NA ABERTURA DO VSAM MZV5002' |  |  |  |  | N/A | N/A |
| VGRAV  *        DISPLAY '        FILE STATUS        -> ' FS-MZV5002E |  |  |  |  | N/A | N/A |
| VGRAV  *        MOVE 'S'   TO  CT-CANCELA |  |  |  |  | N/A | N/A |
| VGRAV  *        PERFORM  R990-CANCELA |  |  |  |  | N/A | N/A |
| VGRAV  *    END-IF |  |  |  |  | N/A | N/A |
| VGRAV  *-------- ACESSAR DATA BASE DO SISTEMA |  |  |  |  | N/A | N/A |
| VGRAV  *    READ  MZV5002E |  |  |  |  | N/A | N/A |
| VGRAV  *    IF  FS-MZV5002E  NOT EQUAL  '00' |  |  |  |  | N/A | N/A |
| VGRAV  *        DISPLAY '        ERRO DE LEITURA DO HEADER MZV5002E' |  |  |  |  | N/A | N/A |
| VGRAV  *    ELSE |  |  |  |  | N/A | N/A |
| VGRAV  *      IF  CHAVE-5002  NOT EQUAL  ZEROS |  |  |  |  | N/A | N/A |
| VGRAV  *        DISPLAY '        ARQUIVO MZV5002E SEM HEADER' |  |  |  |  | N/A | N/A |
| VGRAV  *      ELSE |  |  |  |  | N/A | N/A |
| VGRAV  *        MOVE  DATA-BASE-5002  TO  WK-DATA-BASE |  |  |  |  | N/A | N/A |
| VGRAV  *        DISPLAY '*  DT BASE DO SIST |  |  |  |  | N/A | N/A |
| VGRAV  *      END-IF |  |  |  |  | N/A | N/A |
| V      *-------- ABERTURA OS ARQUIVOS |  |  |  |  | N/A | N/A |
| V           OPEN INPUT  E1DQ0705 |  |  |  |  | N/A | N/A |
| V                OUTPUT S1DQ0705 |  |  |  |  | N/A | N/A |
| VSPRT76                 S2DQ0705 |  |  |  |  | N/A | N/A |
| V      *-------- LEITURA DO ARQUIVO DE ENTRADA |  |  |  |  | N/A | N/A |
| V           PERFORM R110-LER-E1DQ0705 |  |  |  |  | N/A | N/A |
| VSPRT76*    IF CT-FIM    EQUAL   'S' |  |  |  |  | N/A | N/A |
| VSPRT76*       GO TO     R100-EXIT |  |  |  |  | N/A | N/A |
| VSPRT76*    END-IF |  |  |  |  | N/A | N/A |
| VSPRT76     IF CT-FIM    EQUAL   'S' |  |  |  |  | N/A | N/A |
| V  !!          DISPLAY '***********************************************' |  |  |  |  | N/A | N/A |
| V  !!          DISPLAY '      PROGRAMA LHAN0709  -   CANCELADO         ' |  |  |  |  | N/A | N/A |
| V  !!          DISPLAY '                                               ' |  |  |  |  | N/A | N/A |
| V  !!          DISPLAY '   ARQUIVO REMESSA OPERACOES TATICO   VAZIO    ' |  |  |  |  | N/A | N/A |
| V  !!          DISPLAY '   ACIONAR GESTOR DO LH                        ' |  |  |  |  | N/A | N/A |
| V  !!          DISPLAY '   ARQUIVO VAZIO                               ' |  |  |  |  | N/A | N/A |
| V  !!          MOVE 'S'   TO  CT-CANCELA |  |  |  |  | N/A | N/A |
| V  !!          PERFORM  R990-CANCELA |  |  |  |  | N/A | N/A |
| VSPRT76     END-IF |  |  |  |  | N/A | N/A |
| V      *-------- PRIMEIRO REGISTRO NAO E HEADER |  |  |  |  | N/A | N/A |
| V           IF WK-TP-REG                NOT EQUAL CT-X-0 |  |  |  |  | N/A | N/A |
| V697665*       INITIALIZE LHCE0430-RETORNO |  |  |  |  | N/A | N/A |
| V              PERFORM VARYING WK-IND1 FROM 1 BY 1 |  |  |  |  | N/A | N/A |
| V                UNTIL WK-IND1 GREATER 10 |  |  |  |  | N/A | N/A |
| V                 MOVE ZEROS        TO  LHCE0430-CD-RETORNO(WK-IND1) |  |  |  |  | N/A | N/A |
| V              END-PERFORM |  |  |  |  | N/A | N/A |
| V              MOVE CT-10           TO  LHCE0430-CD-RETORNO(01) |  |  |  |  | N/A | N/A |
| V              MOVE CT-MENS-ERRO    TO  LHCE0430-TX-MENSAGEM |  |  |  |  | N/A | N/A |
| V              ADD   CT-01          TO  AC-RG-ERRO |  |  |  |  | N/A | N/A |
| V              MOVE  CT-SIM         TO  CT-ERRO |  |  |  |  | N/A | N/A |
| VSPRT76        PERFORM  R600-GRAVA-SAIDA2-ERRO |  |  |  |  | N/A | N/A |
| V              DISPLAY '***********************************************' |  |  |  |  | N/A | N/A |
| V              DISPLAY '      PROGRAMA LHAN0705  -   CANCELADO         ' |  |  |  |  | N/A | N/A |
| V              DISPLAY '                                               ' |  |  |  |  | N/A | N/A |
| V              DISPLAY '        TESTE DE PRIMEIRO REGISTRO             ' |  |  |  |  | N/A | N/A |
| V              DISPLAY '        PRIMEIRO REGISTRO NAO E HEADER         ' |  |  |  |  | N/A | N/A |
| GESTOR  ' |  |  |  |  | N/A | N/A |
| V              MOVE 'S'   TO  CT-CANCELA |  |  |  |  | N/A | N/A |
| V              PERFORM  R990-CANCELA |  |  |  |  | N/A | N/A |
| V       R100-EXIT.     EXIT |  |  |  |  | N/A | N/A |
| V      *    ROTINA PARA LEITURA DO ARQUIVO DE ENTRADA                  * |  |  |  |  | N/A | N/A |
| V       R110-LER-E1DQ0705               SECTION |  |  |  |  | N/A | N/A |
| V697665     READ  E1DQ0705 INTO LHCE0430-ENTRADA |  |  |  |  | N/A | N/A |
| V             AT END |  |  |  |  | N/A | N/A |
| V                 MOVE CT-SIM   TO  CT-FIM |  |  |  |  | N/A | N/A |
| V           END-READ |  |  |  |  | N/A | N/A |
| V           IF  CT-FIM  EQUAL  CT-NAO |  |  |  |  | N/A | N/A |
| V               ADD          +1             TO  AC-RG-LIDO |  |  |  |  | N/A | N/A |
| V               MOVE LHCE0430-TP-REG        TO  WK-TP-REG |  |  |  |  | N/A | N/A |
| VSPRT76         MOVE LHCE0430-CD-ITF        TO  E1-CD-ITF |  |  |  |  | N/A | N/A |
| VSPRT76         MOVE LHCE0430-NR-OPR-X      TO  E1-NR-OPR-X |  |  |  |  | N/A | N/A |
| VSPRT76         MOVE LHCE0430-CD-MOD-CTR    TO  E1-MOD-X |  |  |  |  | N/A | N/A |
| V       R110-EXIT.   EXIT |  |  |  |  | N/A | N/A |
| V      *    ROTINA  DE  PROCESSAMENTO                                  * |  |  |  |  | N/A | N/A |
| V       R200-PROCESSAMENTO              SECTION |  |  |  |  | N/A | N/A |
| V697665     PERFORM   R201-REINCIALIZA |  |  |  |  | N/A | N/A |
| V           EVALUATE  WK-TP-REG |  |  |  |  | N/A | N/A |
| V               WHEN  CT-X-0 |  |  |  |  | N/A | N/A |
| V                     PERFORM  R210-VALIDA-HEADER |  |  |  |  | N/A | N/A |
| V               WHEN  CT-X-9 |  |  |  |  | N/A | N/A |
| V                     PERFORM  R220-VALIDA-TRAILLER |  |  |  |  | N/A | N/A |
| V               WHEN  OTHER |  |  |  |  | N/A | N/A |
| V                     PERFORM  R230-VALIDA-DETALHE |  |  |  |  | N/A | N/A |
| V           END-EVALUATE |  |  |  |  | N/A | N/A |
| VSPRT76     MOVE WS-CHAVE-E1   TO   WS-CHAVE-E1-ANT |  |  |  |  | N/A | N/A |
| V           IF CT-FIM  EQUAL CT-SIM AND WK-TP-REG  NOT EQUAL CT-X-9 |  |  |  |  | N/A | N/A |
| V              INITIALIZE LHCE0430-RETORNO |  |  |  |  | N/A | N/A |
| V697665*       MOVE CT-10           TO  LHCE0430-CD-RETORNO(01) |  |  |  |  | N/A | N/A |
| V              PERFORM  R600-GRAVA-SAIDA2-ERRO |  |  |  |  | N/A | N/A |
| V       R200-EXIT.   EXIT |  |  |  |  | N/A | N/A |
| V697665*---------------------------------------------------------------* |  |  |  |  | N/A | N/A |
| V  ||  * REINICIALIZA VARIAVEIS A CADA REGISTRO |  |  |  |  | N/A | N/A |
| V  ||  *---------------------------------------------------------------* |  |  |  |  | N/A | N/A |
| V  ||   R201-REINCIALIZA |  |  |  |  | N/A | N/A |
| V  ||  *--- AREA DE RETORNO |  |  |  |  | N/A | N/A |
| V  ||       PERFORM VARYING WK-IND1 FROM 1 BY 1 |  |  |  |  | N/A | N/A |
| V  ||         UNTIL WK-IND1 GREATER 10 |  |  |  |  | N/A | N/A |
| V  ||         MOVE  ZEROS           TO  LHCE0430-CD-RETORNO(WK-IND1) |  |  |  |  | N/A | N/A |
| V  ||       END-PERFORM |  |  |  |  | N/A | N/A |
| V  || |  |  |  |  | N/A | N/A |
| V  ||       MOVE SPACES             TO  LHCE0430-TX-MENSAGEM |  |  |  |  | N/A | N/A |
| V  ||  *--- AREA TEMPORARIA DE CONSISTENCIA |  |  |  |  | N/A | N/A |
| V  ||         UNTIL WK-IND1 GREATER 30 |  |  |  |  | N/A | N/A |
| V  ||         MOVE  ZEROS           TO  WK-CD-RETORNO(WK-IND1) |  |  |  |  | N/A | N/A |
| V  ||       SET  LHCE0700-CD-RET-OK TO  TRUE |  |  |  |  | N/A | N/A |
| V  ||       SET  SW-MODSUB-OK       TO  TRUE |  |  |  |  | N/A | N/A |
| V  ||       SET  SW-TIPOSUB-OK      TO  TRUE |  |  |  |  | N/A | N/A |
| V  ||       MOVE CT-NAO             TO  CT-ERRO |  |  |  |  | N/A | N/A |
| V  ||       MOVE CT-01              TO  WK-IND1 |  |  |  |  | N/A | N/A |
| V  ||       MOVE CT-MENS-OK         TO  LHCE0430-TX-MENSAGEM |  |  |  |  | N/A | N/A |
| V  ||       MOVE ZEROS              TO  WK-0152-RET |  |  |  |  | N/A | N/A |
| V  ||                                   WK-0022-OPCAO |  |  |  |  | N/A | N/A |
| V  ||       MOVE SPACES             TO  WK-0038-DIGITO |  |  |  |  | N/A | N/A |
| V697665* |  |  |  |  | N/A | N/A |
| V      *    ROTINA  DE  VALIDACAO FISICA DO ARQUIVO DE ENTRADA         * |  |  |  |  | N/A | N/A |
| V       R210-VALIDA-HEADER                 SECTION |  |  |  |  | N/A | N/A |
| V697665     MOVE     LHCE0430-DT-BSE    TO  WK-0152-DATA |  |  |  |  | N/A | N/A |
| V697665     PERFORM  R300-VALIDA-DATA |  |  |  |  | N/A | N/A |
| VSPRT76     IF  LHCE0430-DT-BSE  NOT EQUAL  WK-DATA-BASE |  |  |  |  | N/A | N/A |
| V  !!           MOVE  CT-11             TO  WK-CD-RETORNO(WK-IND1) |  |  |  |  | N/A | N/A |
| V  !!           ADD   CT-01             TO  WK-IND1 |  |  |  |  | N/A | N/A |
| V  !!           MOVE  CT-SIM            TO  CT-ERRO |  |  |  |  | N/A | N/A |
| VSPRT76*--- VALIDACAO FINAL DO REGISTRO |  |  |  |  | N/A | N/A |
| V  !!  *    QUANTIDADE MAXIMA DE ERROS NO ARQUIVO PARA USUARIO IGUAL A 10 |  |  |  |  | N/A | N/A |
| V  !!  * |  |  |  |  | N/A | N/A |
| V  !!       IF CT-ERRO               EQUAL  CT-NAO |  |  |  |  | N/A | N/A |
| V  !!          MOVE   CT-MENS-OK        TO  LHCE0430-TX-MENSAGEM |  |  |  |  | N/A | N/A |
| V  !!          ADD    CT-01             TO  AC-RG-VALI |  |  |  |  | N/A | N/A |
| V  !!          PERFORM  R500-GRAVA-SAIDA1-OK |  |  |  |  | N/A | N/A |
| V  !!       ELSE |  |  |  |  | N/A | N/A |
| V  !!          PERFORM VARYING WK-IND1 FROM 1 BY 1 |  |  |  |  | N/A | N/A |
| V  !!            UNTIL WK-IND1 GREATER 10 |  |  |  |  | N/A | N/A |
| V  !!             MOVE WK-CD-RETORNO(WK-IND1) |  |  |  |  | N/A | N/A |
| V  !!                                   TO LHCE0430-CD-RETORNO(WK-IND1) |  |  |  |  | N/A | N/A |
| V  !!          END-PERFORM |  |  |  |  | N/A | N/A |
| V  !!          MOVE   CT-MENS-ERRO      TO  LHCE0430-TX-MENSAGEM |  |  |  |  | N/A | N/A |
| V  !!          ADD    CT-01             TO  AC-RG-ERRO |  |  |  |  | N/A | N/A |
| V  !!          PERFORM  R600-GRAVA-SAIDA2-ERRO |  |  |  |  | N/A | N/A |
| V       R210-EXIT.   EXIT |  |  |  |  | N/A | N/A |
| V      *    ROTINA  DE  VALIDACAO FISICA DO REGISTRO TRAILER           * |  |  |  |  | N/A | N/A |
| V       R220-VALIDA-TRAILLER                SECTION |  |  |  |  | N/A | N/A |
| V       R220-EXIT.   EXIT |  |  |  |  | N/A | N/A |
| V       R230-VALIDA-DETALHE                SECTION |  |  |  |  | N/A | N/A |
| V  ||  *--- VALIDACAO TIPO REGISTRO |  |  |  |  | N/A | N/A |
| V           IF  LHCE0430-TP-REG        NOT NUMERIC |  |  |  |  | N/A | N/A |
| V           OR  LHCE0430-TP-REG        NOT EQUAL CT-01 |  |  |  |  | N/A | N/A |
| V               MOVE  CT-10             TO  WK-CD-RETORNO(WK-IND1) |  |  |  |  | N/A | N/A |
| V               MOVE  CT-SIM            TO  CT-ERRO |  |  |  |  | N/A | N/A |
| V               ADD   CT-01             TO  WK-IND1 |  |  |  |  | N/A | N/A |
| V  ||  *--- VALIDACAO DATA BASE |  |  |  |  | N/A | N/A |
| V  ||       MOVE     LHCE0430-DT-BSE    TO  WK-0152-DATA |  |  |  |  | N/A | N/A |
| V  ||       PERFORM  R300-VALIDA-DATA |  |  |  |  | N/A | N/A |
| V  ||  *--- VALIDACAO CODIGO INTERFACE |  |  |  |  | N/A | N/A |
| V           IF  LHCE0430-CD-ITF      EQUAL SPACES |  |  |  |  | N/A | N/A |
| V           OR  LHCE0430-CD-ITF      EQUAL LOW-VALUES |  |  |  |  | N/A | N/A |
| V           OR  LHCE0430-CD-ITF      EQUAL HIGH-VALUES |  |  |  |  | N/A | N/A |
| V697665         MOVE  CT-12             TO  WK-CD-RETORNO(WK-IND1) |  |  |  |  | N/A | N/A |
| V  ||  *--- VALIDACAO TIPO PESSOA E NUMERO DOCUMENTO |  |  |  |  | N/A | N/A |
| V  ||       EVALUATE LHCE0430-TP-PES |  |  |  |  | N/A | N/A |
| V  ||           WHEN CT-01 |  |  |  |  | N/A | N/A |
| V  ||                MOVE  LHCE0430-CD-CIC     TO  WK-0022-CPF |  |  |  |  | N/A | N/A |
| V  ||                MOVE  CT-02               TO  WK-0022-OPCAO |  |  |  |  | N/A | N/A |
| V  ||                PERFORM  R305-VALIDA-CPF |  |  |  |  | N/A | N/A |
| V  ||           WHEN CT-02 |  |  |  |  | N/A | N/A |
| V  ||                MOVE  LHCE0430-CD-CIC     TO  WK-0038-CNPJ |  |  |  |  | N/A | N/A |
| V  ||                PERFORM  R310-VALIDA-CNPJ |  |  |  |  | N/A | N/A |
| V  ||           WHEN OTHER |  |  |  |  | N/A | N/A |
| V  ||                MOVE  CT-13               TO  WK-CD-RETORNO(WK-IND1) |  |  |  |  | N/A | N/A |
| V  ||                ADD   CT-01               TO  WK-IND1 |  |  |  |  | N/A | N/A |
| V  ||                MOVE  CT-SIM              TO  CT-ERRO |  |  |  |  | N/A | N/A |
| V  ||       END-EVALUATE |  |  |  |  | N/A | N/A |
| V  ||  *--- VALIDACAO OPERACAO - CONTRATO |  |  |  |  | N/A | N/A |
| V  ||       MOVE    LHCE0430-NR-OPR-X   TO  WK-CONTRATO |  |  |  |  | N/A | N/A |
| V  ||       PERFORM R315-VALIDA-CONTRATO |  |  |  |  | N/A | N/A |
| SUBMODALIDADE |  |  |  |  | N/A | N/A |
| V  ||       MOVE    LHCE0430-CD-MOD-CTR TO  WK-CD-MOD |  |  |  |  | N/A | N/A |
| V  ||       PERFORM R320-VALIDA-MODSUB |  |  |  |  | N/A | N/A |
| MODALIDADE |  |  |  |  | N/A | N/A |
| V  !!       IF  WS-CHAVE-E1   EQUAL     WS-CHAVE-E1-ANT |  |  |  |  | N/A | N/A |
| V  !!           MOVE  CT-15             TO  WK-CD-RETORNO(WK-IND1) |  |  |  |  | N/A | N/A |
| SUBTIPO INFORMACAO ADICIONAL |  |  |  |  | N/A | N/A |
| V  ||       MOVE    LHCE0430-TP-SB-INFO TO  WK-CD-INFO-ADIC |  |  |  |  | N/A | N/A |
| V  ||       PERFORM R325-VALIDA-TIPOSUB |  |  |  |  | N/A | N/A |
| V  ||  *--- VALIDACAO COMBINACAO TIPO SUBTIPO CONTRA MOD |  |  |  |  | N/A | N/A |
| V  ||  *    SE AS PROPRIAS ESTIVEREM OK |  |  |  |  | N/A | N/A |
| V  ||       IF  SW-MODSUB-OK    AND     SW-TIPOSUB-OK |  |  |  |  | N/A | N/A |
| V  ||           MOVE  CT-01             TO  LHCE0700-NR-OPCAO |  |  |  |  | N/A | N/A |
| V  ||           MOVE  LHCE0430-TP-SB-INFO |  |  |  |  | N/A | N/A |
| V  ||                                   TO  LHCE0700-TX-OP1-TIPOSUBTIPO |  |  |  |  | N/A | N/A |
| V  ||           MOVE  LHCE0430-CD-MOD-CTR |  |  |  |  | N/A | N/A |
| V  ||                                   TO  LHCE0700-TX-OP1-MODSUBMOD |  |  |  |  | N/A | N/A |
| V  ||           IF  LHCE0430-TP-SB-INFO(1:2) EQUAL 18 OR 19 |  |  |  |  | N/A | N/A |
| V  ||               MOVE  '9999' |  |  |  |  | N/A | N/A |
| V  ||           END-IF |  |  |  |  | N/A | N/A |
| V  ||           CALL  CT-LHBR0700    USING  LI-LHCE0700 |  |  |  |  | N/A | N/A |
| VSPRT04         MOVE  ZEROS   TO  LHCE0700-CD-RET |  |  |  |  | N/A | N/A |
| V  ||           IF  NOT   LHCE0700-CD-RET-OK |  |  |  |  | N/A | N/A |
| V  ||               MOVE  CT-18         TO  WK-CD-RETORNO(WK-IND1) |  |  |  |  | N/A | N/A |
| V  ||               ADD   CT-01         TO  WK-IND1 |  |  |  |  | N/A | N/A |
| V  ||               MOVE  CT-SIM        TO  CT-ERRO |  |  |  |  | N/A | N/A |
| V  ||       END-IF |  |  |  |  | N/A | N/A |
| V  ||  *--- VALIDACAO DE CAMPOS OBRIGATORIOS, POR TIPO DE INFO. ADIC |  |  |  |  | N/A | N/A |
| V  ||  *    DE ACORDO COM ANEXO 26 DO LEIAUTE SCR3040 |  |  |  |  | N/A | N/A |
| V  ||       EVALUATE LHCE0430-TP-INFO-ADIC |  |  |  |  | N/A | N/A |
| V  ||                PERFORM T001-TRATA-TIPO-01 |  |  |  |  | N/A | N/A |
| V  ||                PERFORM T002-TRATA-TIPO-02 |  |  |  |  | N/A | N/A |
| V  ||           WHEN CT-03 |  |  |  |  | N/A | N/A |
| V  ||                PERFORM T003-TRATA-TIPO-03 |  |  |  |  | N/A | N/A |
| V  ||           WHEN CT-04 |  |  |  |  | N/A | N/A |
| V  ||                PERFORM T004-TRATA-TIPO-04 |  |  |  |  | N/A | N/A |
| VSPRT04         WHEN CT-06 |  |  |  |  | N/A | N/A |
| VSPRT04              PERFORM T006-TRATA-TIPO-06 |  |  |  |  | N/A | N/A |
| V  ||           WHEN CT-07 |  |  |  |  | N/A | N/A |
| V  ||                PERFORM T007-TRATA-TIPO-07 |  |  |  |  | N/A | N/A |
| V  ||           WHEN CT-10 |  |  |  |  | N/A | N/A |
| V  ||                PERFORM T010-TRATA-TIPO-10 |  |  |  |  | N/A | N/A |
| V  ||           WHEN CT-11 |  |  |  |  | N/A | N/A |
| V  ||                PERFORM T011-TRATA-TIPO-11 |  |  |  |  | N/A | N/A |
| V  ||           WHEN CT-12 |  |  |  |  | N/A | N/A |
| V  ||                PERFORM T012-TRATA-TIPO-12 |  |  |  |  | N/A | N/A |
| VSPRT09 |  |  |  |  | N/A | N/A |
| VSPRT09         WHEN CT-14 |  |  |  |  | N/A | N/A |
| VSPRT09              PERFORM T014-TRATA-TIPO-14 |  |  |  |  | N/A | N/A |
| V  ||           WHEN CT-15 |  |  |  |  | N/A | N/A |
| V  ||                PERFORM T015-TRATA-TIPO-15 |  |  |  |  | N/A | N/A |
| VCORBAN         WHEN CT-16 |  |  |  |  | N/A | N/A |
| VCORBAN              PERFORM T015-TRATA-TIPO-15 |  |  |  |  | N/A | N/A |
| VSPRT77         WHEN CT-17 |  |  |  |  | N/A | N/A |
| VSPRT77              PERFORM T017-TRATA-TIPO-17 |  |  |  |  | N/A | N/A |
| VOLIVA1         WHEN CT-18 |  |  |  |  | N/A | N/A |
| VOLIVA1              PERFORM T018-TRATA-TIPO-18 |  |  |  |  | N/A | N/A |
| VOLIVA1         WHEN CT-19 |  |  |  |  | N/A | N/A |
| VOLIVA1              PERFORM T019-TRATA-TIPO-19 |  |  |  |  | N/A | N/A |
| V  ||                CONTINUE |  |  |  |  | N/A | N/A |
| V697665     END-EVALUATE |  |  |  |  | N/A | N/A |
| V  ||  *--- VALIDACAO FINAL DO REGISTRO |  |  |  |  | N/A | N/A |
| V  ||  *    QUANTIDADE MAXIMA DE ERROS NO ARQUIVO PARA USUARIO IGUAL A 10 |  |  |  |  | N/A | N/A |
| V           IF CT-ERRO               EQUAL  CT-NAO |  |  |  |  | N/A | N/A |
| V              MOVE   CT-MENS-OK        TO  LHCE0430-TX-MENSAGEM |  |  |  |  | N/A | N/A |
| V              ADD    CT-01             TO  AC-RG-VALI |  |  |  |  | N/A | N/A |
| VSPRT76        PERFORM  R500-GRAVA-SAIDA1-OK |  |  |  |  | N/A | N/A |
| V697665        PERFORM VARYING WK-IND1 FROM 1 BY 1 |  |  |  |  | N/A | N/A |
| V  ||            UNTIL WK-IND1 GREATER 10 |  |  |  |  | N/A | N/A |
| V  ||             MOVE WK-CD-RETORNO(WK-IND1) |  |  |  |  | N/A | N/A |
| V  ||                                   TO LHCE0430-CD-RETORNO(WK-IND1) |  |  |  |  | N/A | N/A |
| V697665        END-PERFORM |  |  |  |  | N/A | N/A |
| V              MOVE   CT-MENS-ERRO      TO  LHCE0430-TX-MENSAGEM |  |  |  |  | N/A | N/A |
| V              ADD    CT-01             TO  AC-RG-ERRO |  |  |  |  | N/A | N/A |
| V       R230-EXIT.   EXIT |  |  |  |  | N/A | N/A |
| V  ||  * VALIDACAO DE DATA |  |  |  |  | N/A | N/A |
| V  ||   R300-VALIDA-DATA |  |  |  |  | N/A | N/A |
| V  ||       CALL CT-DRAM0152         USING  WK-DRAM0152 |  |  |  |  | N/A | N/A |
| V  ||       IF  WK-0152-RET      NOT EQUAL  ZEROS |  |  |  |  | N/A | N/A |
| V  ||           MOVE  CT-11             TO  WK-CD-RETORNO(WK-IND1) |  |  |  |  | N/A | N/A |
| V  ||           ADD   CT-01             TO  WK-IND1 |  |  |  |  | N/A | N/A |
| V  ||           MOVE  CT-SIM            TO  CT-ERRO |  |  |  |  | N/A | N/A |
| V  ||  * VALIDACAO DE CPF |  |  |  |  | N/A | N/A |
| V  ||   R305-VALIDA-CPF |  |  |  |  | N/A | N/A |
| V  ||       CALL CT-DRAM0022         USING  WK-DRAM0022 |  |  |  |  | N/A | N/A |
| V  ||       IF  WK-0022-OPCAO    NOT EQUAL  ZEROS |  |  |  |  | N/A | N/A |
| V  ||           MOVE  CT-14             TO  WK-CD-RETORNO(WK-IND1) |  |  |  |  | N/A | N/A |
| V  ||  * VALIDACAO DE CNPJ |  |  |  |  | N/A | N/A |
| V  ||   R310-VALIDA-CNPJ |  |  |  |  | N/A | N/A |
| V  ||       CALL CT-DRAM0038         USING  WK-DRAM0038 |  |  |  |  | N/A | N/A |
| V  ||       IF  WK-0038-DIGITO       EQUAL  CT-2ASTER |  |  |  |  | N/A | N/A |
| V  ||  * VALIDACAO DE CONTRATO |  |  |  |  | N/A | N/A |
| V  ||   R315-VALIDA-CONTRATO |  |  |  |  | N/A | N/A |
| V  ||       IF  WK-CONTRATO          EQUAL SPACES |  |  |  |  | N/A | N/A |
| V  ||       OR  WK-CONTRATO          EQUAL LOW-VALUES |  |  |  |  | N/A | N/A |
| V  ||       OR  WK-CONTRATO          EQUAL HIGH-VALUES |  |  |  |  | N/A | N/A |
| V  ||           MOVE  CT-15             TO  WK-CD-RETORNO(WK-IND1) |  |  |  |  | N/A | N/A |
| V  ||   R320-VALIDA-MODSUB |  |  |  |  | N/A | N/A |
| V  ||       SEARCH ALL ANEXO-03 |  |  |  |  | N/A | N/A |
| V  ||           AT END |  |  |  |  | N/A | N/A |
| V  ||              MOVE CT-16            TO  WK-CD-RETORNO(WK-IND1) |  |  |  |  | N/A | N/A |
| V  ||              MOVE CT-SIM           TO  CT-ERRO |  |  |  |  | N/A | N/A |
| V  ||              ADD  CT-01            TO  WK-IND1 |  |  |  |  | N/A | N/A |
| V  ||              SET  SW-MODSUB-NOK    TO  TRUE |  |  |  |  | N/A | N/A |
| V  ||         WHEN TB-INDX-03(INDX03) EQUAL  WK-CD-MOD |  |  |  |  | N/A | N/A |
| V  ||              CONTINUE |  |  |  |  | N/A | N/A |
| V  ||   R325-VALIDA-TIPOSUB |  |  |  |  | N/A | N/A |
| V  ||       SEARCH ALL ANEXO-26 |  |  |  |  | N/A | N/A |
| V  ||              MOVE CT-17            TO  WK-CD-RETORNO(WK-IND1) |  |  |  |  | N/A | N/A |
| V  ||              SET  SW-TIPOSUB-NOK   TO  TRUE |  |  |  |  | N/A | N/A |
| V  ||         WHEN TB-INDX-26(INDX26) EQUAL  WK-CD-INFO-ADIC |  |  |  |  | N/A | N/A |
| V  ||  * VALIDACAO DE VALOR |  |  |  |  | N/A | N/A |
| V  ||   R330-VALIDA-VALOR |  |  |  |  | N/A | N/A |
| V  ||       IF LHCE0430-VL-INFO-ADIC-SINAL |  |  |  |  | N/A | N/A |
| V  ||                             NOT EQUAL  CT-HIFEN AND SPACES AND |  |  |  |  | N/A | N/A |
| V  ||                                        CT-MAIS |  |  |  |  | N/A | N/A |
| V  ||              MOVE CT-19            TO  WK-CD-RETORNO(WK-IND1) |  |  |  |  | N/A | N/A |
| V  ||       IF LHCE0430-VL-INFO-ADIC    NOT NUMERIC |  |  |  |  | N/A | N/A |
| V  ||       OR LHCE0430-VL-INFO-ADIC  EQUAL ZEROS |  |  |  |  | N/A | N/A |
| V  ||  * VALIDACAO DE PERCENTUAL |  |  |  |  | N/A | N/A |
| V  ||   R335-VALIDA-PERCENTUAL |  |  |  |  | N/A | N/A |
| V  ||       IF LHCE0430-PC-INFO-ADIC-SINAL |  |  |  |  | N/A | N/A |
| V  ||       IF LHCE0430-PC-INFO-ADIC    NOT NUMERIC |  |  |  |  | N/A | N/A |
| V  ||       OR LHCE0430-PC-INFO-ADIC  EQUAL ZEROS |  |  |  |  | N/A | N/A |
| V  ||  * VALIDACAO CAMPO CD-INFO-ADIC |  |  |  |  | N/A | N/A |
| V  ||   R340-VALIDA-CD-INFO-ADIC |  |  |  |  | N/A | N/A |
| V  ||       IF  LHCE0430-CD-INFO-ADIC EQUAL SPACES |  |  |  |  | N/A | N/A |
| V  ||       OR  LHCE0430-CD-INFO-ADIC EQUAL LOW-VALUES |  |  |  |  | N/A | N/A |
| V  ||       OR  LHCE0430-CD-INFO-ADIC EQUAL HIGH-VALUES |  |  |  |  | N/A | N/A |
| V  ||           MOVE  CT-19              TO  WK-CD-RETORNO(WK-IND1) |  |  |  |  | N/A | N/A |
| V  ||           MOVE  CT-SIM             TO  CT-ERRO |  |  |  |  | N/A | N/A |
| V  ||           ADD   CT-01              TO  WK-IND1 |  |  |  |  | N/A | N/A |
| V      * ROTINA DE GRAVACAO DO ARQUIVO DE SAIDA1 - OK                  * |  |  |  |  | N/A | N/A |
| VSPRT76 R500-GRAVA-SAIDA1-OK            SECTION |  |  |  |  | N/A | N/A |
| V           ADD      CT-01        TO    AC-RG-GRAV |  |  |  |  | N/A | N/A |
| V697665     WRITE  REG-S1DQ0705  FROM WS-E1DQ0705 |  |  |  |  | N/A | N/A |
| V       R500-EXIT.    EXIT |  |  |  |  | N/A | N/A |
| V  !!  * ROTINA DE GRAVACAO DO ARQUIVO DE SAIDA 2 - ERRO               * |  |  |  |  | N/A | N/A |
| V  !!   R600-GRAVA-SAIDA2-ERRO          SECTION |  |  |  |  | N/A | N/A |
| V  !!       WRITE  REG-S2DQ0705  FROM WS-E1DQ0705 |  |  |  |  | N/A | N/A |
| VSPRT76 R600-EXIT.    EXIT |  |  |  |  | N/A | N/A |
| V      *    ROTINA  DE  FINALIZACAO                                    * |  |  |  |  | N/A | N/A |
| V       R900-FIM                        SECTION |  |  |  |  | N/A | N/A |
| V           CLOSE E1DQ0705 |  |  |  |  | N/A | N/A |
| V                 S1DQ0705 |  |  |  |  | N/A | N/A |
| VSPRT76           S2DQ0705 |  |  |  |  | N/A | N/A |
| VGRAV  *          MZV5002E |  |  |  |  | N/A | N/A |
| V           DISPLAY '***********************************************' |  |  |  |  | N/A | N/A |
| V           DISPLAY '**      TERMINO DO PROGRAMA LHAN0705         **' |  |  |  |  | N/A | N/A |
| V           DISPLAY '**                                           **' |  |  |  |  | N/A | N/A |
| V           DISPLAY '** REG.  LIDOS     E1DQ0705  -> ' AC-RG-LIDO |  |  |  |  | N/A | N/A |
| V           DISPLAY '** REG.  VALIDOS             -> ' AC-RG-VALI |  |  |  |  | N/A | N/A |
| V           DISPLAY '** REG.  ERROS               -> ' AC-RG-ERRO |  |  |  |  | N/A | N/A |
| V           DISPLAY '** REG.  GRAVADOS  S1DQ0705  -> ' AC-RG-VALI |  |  |  |  | N/A | N/A |
| VSPRT76     DISPLAY '** REG.  GRAVADOS  S2DQ0705  -> ' AC-RG-ERRO |  |  |  |  | N/A | N/A |
| V           DISPLAY '   PROGRAMA EXECUTADO COM SUCESSO              ' |  |  |  |  | N/A | N/A |
| VSPRT76     IF  AC-RG-ERRO  EQUAL ZEROS |  |  |  |  | N/A | N/A |
| V  !!           MOVE  ZEROS       TO  RETURN-CODE |  |  |  |  | N/A | N/A |
| V  !!           MOVE  CT-01       TO  RETURN-CODE |  |  |  |  | N/A | N/A |
| V  !!           DISPLAY '***********************************************' |  |  |  |  | N/A | N/A |
| V  !!           DISPLAY '**  INCONSITENCIA NO MOVIMENTO DO TATICO  !! **' |  |  |  |  | N/A | N/A |
| V  !!           DISPLAY '**  SCHEDULAGEM FAVOR ACIONAR O RESPONSAVEL  **' |  |  |  |  | N/A | N/A |
| CORRECAO DO ARQUIVO*' |  |  |  |  | N/A | N/A |
| V  !!           DISPLAY '**  E REENVIO AO LH |  |  |  |  | N/A | N/A |
| V       R999-EXIT.  EXIT |  |  |  |  | N/A | N/A |
| V      *    ROTINA  DE  CANCELAMENTO  DO  SISTEMA                      * |  |  |  |  | N/A | N/A |
| V       R990-CANCELA                    SECTION |  |  |  |  | N/A | N/A |
| V           CALL  CT-DRAM0018              USING     PGMNAME      STCODE |  |  |  |  | N/A | N/A |
| V  ||  * SECTIONS DE TRATAMENTO E VALIDACAO DE CONTEUDO DE CAMPOS POR |  |  |  |  | N/A | N/A |
| V  ||  * TIPO DE INFORMACAO ADICIONAL |  |  |  |  | N/A | N/A |
| V  ||  * OBS |  |  |  |  | N/A | N/A |
| V  ||  *       ESTA PREVISTO CPF |  |  |  |  | N/A | N/A |
| V  ||  *       POR ENQUANTO, AREA GESTORA NAO PREENCHE NO ARQUIVO TATICO |  |  |  |  | N/A | N/A |
| V  ||  *       O CAMPO LHCE0430-ID1-TP-PES, ASSUME SEMPRE CNPJ |  |  |  |  | N/A | N/A |
| V  ||  * TRATAMENTO TIPO 01 |  |  |  |  | N/A | N/A |
| V  ||   T001-TRATA-TIPO-01 |  |  |  |  | N/A | N/A |
| V  ||       MOVE    LHCE0430-CD1-DATA        TO  WK-0152-DATA |  |  |  |  | N/A | N/A |
| V  ||       PERFORM R300-VALIDA-DATA |  |  |  |  | N/A | N/A |
| V  ||       IF  LHCE0430-SB-INFO-ADIC NOT EQUAL  CT-05 |  |  |  |  | N/A | N/A |
| V  ||           MOVE    LHCE0430-ID2-CNPJ    TO  WK-0038-CNPJ |  |  |  |  | N/A | N/A |
| V  ||           PERFORM R310-VALIDA-CNPJ |  |  |  |  | N/A | N/A |
| V  ||       PERFORM R330-VALIDA-VALOR |  |  |  |  | N/A | N/A |
| V  ||       PERFORM R335-VALIDA-PERCENTUAL |  |  |  |  | N/A | N/A |
| V  ||  * TRATAMENTO TIPO 02 |  |  |  |  | N/A | N/A |
| V  ||   T002-TRATA-TIPO-02 |  |  |  |  | N/A | N/A |
| V  ||       MOVE    LHCE0430-ID2-CNPJ        TO  WK-0038-CNPJ |  |  |  |  | N/A | N/A |
| V  ||       PERFORM R310-VALIDA-CNPJ |  |  |  |  | N/A | N/A |
| V  ||  * TRATAMENTO TIPO 03 |  |  |  |  | N/A | N/A |
| V  ||   T003-TRATA-TIPO-03 |  |  |  |  | N/A | N/A |
| V  ||       MOVE    CT-03                    TO  WK-CD-RETORNO(WK-IND1) |  |  |  |  | N/A | N/A |
| V  ||       ADD     CT-01                    TO  WK-IND1 |  |  |  |  | N/A | N/A |
| V  ||       MOVE    CT-SIM                   TO  CT-ERRO |  |  |  |  | N/A | N/A |
| V  ||  * TRATAMENTO TIPO 04 |  |  |  |  | N/A | N/A |
| V  ||   T004-TRATA-TIPO-04 |  |  |  |  | N/A | N/A |
| V  ||       EVALUATE LHCE0430-SB-INFO-ADIC |  |  |  |  | N/A | N/A |
| V  ||  * 0401: SE SITUACAO = 1 ENTAO CD-INFO =  SPACES |  |  |  |  | N/A | N/A |
| V  ||  *       SENAO                 CD-INFO <> SPACES |  |  |  |  | N/A | N/A |
| V  ||                EVALUATE LHCE0430-ID1-SITUACAO |  |  |  |  | N/A | N/A |
| V  ||                    WHEN CT-X-1 |  |  |  |  | N/A | N/A |
| V  ||                         IF LHCE0430-CD-INFO-ADIC NOT EQUAL  SPACES |  |  |  |  | N/A | N/A |
| V  ||                            MOVE  CT-19                  TO |  |  |  |  | N/A | N/A |
| V  ||                                  WK-CD-RETORNO(WK-IND1) |  |  |  |  | N/A | N/A |
| V  ||                            ADD   CT-01                  TO  WK-IND1 |  |  |  |  | N/A | N/A |
| V  ||                            MOVE  CT-SIM                 TO  CT-ERRO |  |  |  |  | N/A | N/A |
| V  ||                         END-IF |  |  |  |  | N/A | N/A |
| V  ||                    WHEN SPACES |  |  |  |  | N/A | N/A |
| V  ||                         PERFORM R340-VALIDA-CD-INFO-ADIC |  |  |  |  | N/A | N/A |
| V  ||                    WHEN OTHER |  |  |  |  | N/A | N/A |
| V  ||                         MOVE  CT-19                     TO |  |  |  |  | N/A | N/A |
| V  ||                               WK-CD-RETORNO(WK-IND1) |  |  |  |  | N/A | N/A |
| V  ||                         ADD   CT-01                     TO  WK-IND1 |  |  |  |  | N/A | N/A |
| V  ||                         MOVE  CT-SIM                    TO  CT-ERRO |  |  |  |  | N/A | N/A |
| V  ||                END-EVALUATE |  |  |  |  | N/A | N/A |
| V  ||           WHEN CT-05 |  |  |  |  | N/A | N/A |
| V  ||           WHEN CT-06 |  |  |  |  | N/A | N/A |
| V  ||                PERFORM R340-VALIDA-CD-INFO-ADIC |  |  |  |  | N/A | N/A |
| V  ||                IF  LHCE0430-SB-INFO-ADIC  NOT EQUAL CT-03 |  |  |  |  | N/A | N/A |
| V  ||                    MOVE    LHCE0430-ID1-DATA     TO WK-0152-DATA |  |  |  |  | N/A | N/A |
| V  ||                    PERFORM R300-VALIDA-DATA |  |  |  |  | N/A | N/A |
| V  ||                END-IF |  |  |  |  | N/A | N/A |
| VSPRT04*---------------------------------------------------------------* |  |  |  |  | N/A | N/A |
| VSPRT04* TRATAMENTO TIPO 06 |  |  |  |  | N/A | N/A |
| VSPRT04 T006-TRATA-TIPO-06 |  |  |  |  | N/A | N/A |
| VSPRT04 |  |  |  |  | N/A | N/A |
| VSPRT04* |  |  |  |  | N/A | N/A |
| VSPRT04     IF  LHCE0430-CD-INFO-ADIC EQUAL SPACES |  |  |  |  | N/A | N/A |
| VSPRT04     OR  LHCE0430-CD-INFO-ADIC EQUAL LOW-VALUES |  |  |  |  | N/A | N/A |
| VSPRT04     OR  LHCE0430-CD-INFO-ADIC EQUAL HIGH-VALUES |  |  |  |  | N/A | N/A |
| VSPRT04     OR  LHCE0430-CD-INFO-ADIC(1:2)  NOT EQUAL '01' AND '02' |  |  |  |  | N/A | N/A |
| VSPRT04         MOVE  CT-20              TO  WK-CD-RETORNO(WK-IND1) |  |  |  |  | N/A | N/A |
| VSPRT04         MOVE  CT-SIM             TO  CT-ERRO |  |  |  |  | N/A | N/A |
| VSPRT04         ADD   CT-01              TO  WK-IND1 |  |  |  |  | N/A | N/A |
| VSPRT04     END-IF |  |  |  |  | N/A | N/A |
| VSPRT04     IF  LHCE0430-ID-INFO-ADIC EQUAL SPACES |  |  |  |  | N/A | N/A |
| VSPRT04     OR  LHCE0430-ID-INFO-ADIC EQUAL LOW-VALUES |  |  |  |  | N/A | N/A |
| VSPRT04     OR  LHCE0430-ID-INFO-ADIC EQUAL HIGH-VALUES |  |  |  |  | N/A | N/A |
| VSPRT04         MOVE  CT-21              TO  WK-CD-RETORNO(WK-IND1) |  |  |  |  | N/A | N/A |
| V  ||  * TRATAMENTO TIPO 07 |  |  |  |  | N/A | N/A |
| V  ||   T007-TRATA-TIPO-07 |  |  |  |  | N/A | N/A |
| V  ||  * TRATAMENTO TIPO 10 |  |  |  |  | N/A | N/A |
| V  ||   T010-TRATA-TIPO-10 |  |  |  |  | N/A | N/A |
| V           DISPLAY  'TIPO-10 ' LHCE0430-ID2-CNPJ ' ' WK-0038-CNPJ |  |  |  |  | N/A | N/A |
| V           DISPLAY  'TIPO-10   WK-DRAM0038 ' WK-DRAM0038 |  |  |  |  | N/A | N/A |
| V           DISPLAY  'R310       WK-DRAM0038 ' WK-DRAM0038 |  |  |  |  | N/A | N/A |
| V           DISPLAY  'R310    '  WK-0038-RAIZ-FILIAL ' ' WK-0038-DIGITO |  |  |  |  | N/A | N/A |
| V  ||  * TRATAMENTO TIPO 11 |  |  |  |  | N/A | N/A |
| V  ||   T011-TRATA-TIPO-11 |  |  |  |  | N/A | N/A |
| V  ||       PERFORM R340-VALIDA-CD-INFO-ADIC |  |  |  |  | N/A | N/A |
| V  ||  * TRATAMENTO TIPO 12 |  |  |  |  | N/A | N/A |
| V  ||   T012-TRATA-TIPO-12 |  |  |  |  | N/A | N/A |
| V  ||                MOVE    LHCE0430-CD1-DATA      TO  WK-0152-DATA |  |  |  |  | N/A | N/A |
| V  ||                PERFORM R300-VALIDA-DATA |  |  |  |  | N/A | N/A |
| V  ||                MOVE    LHCE0430-CD-MOD-CTR    TO  WK-CD-MOD |  |  |  |  | N/A | N/A |
| V  ||                PERFORM R320-VALIDA-MODSUB |  |  |  |  | N/A | N/A |
| V  ||                PERFORM R330-VALIDA-VALOR |  |  |  |  | N/A | N/A |
| V  ||                PERFORM R335-VALIDA-PERCENTUAL |  |  |  |  | N/A | N/A |
| V  ||                MOVE    LHCE0430-CD1-CONTRATO  TO  WK-CONTRATO |  |  |  |  | N/A | N/A |
| V  ||                PERFORM R315-VALIDA-CONTRATO |  |  |  |  | N/A | N/A |
| V  ||                MOVE    LHCE0430-ID2-CNPJ      TO  WK-0038-CNPJ |  |  |  |  | N/A | N/A |
| V  ||                PERFORM R310-VALIDA-CNPJ |  |  |  |  | N/A | N/A |
| VSPRT09*---------------------------------------------------------------* |  |  |  |  | N/A | N/A |
| VSPRT09* TRATAMENTO TIPO 14 |  |  |  |  | N/A | N/A |
| VSPRT09 T014-TRATA-TIPO-14 |  |  |  |  | N/A | N/A |
| VSPRT09     EVALUATE LHCE0430-SB-INFO-ADIC |  |  |  |  | N/A | N/A |
| VSPRT09         WHEN CT-08 |  |  |  |  | N/A | N/A |
| VSPRT09           IF  LHCE0430-ID-INFO-ADIC EQUAL SPACES |  |  |  |  | N/A | N/A |
| VSPRT09           OR  LHCE0430-ID-INFO-ADIC EQUAL LOW-VALUES |  |  |  |  | N/A | N/A |
| VSPRT09           OR  LHCE0430-ID-INFO-ADIC EQUAL HIGH-VALUES |  |  |  |  | N/A | N/A |
| VSPRT09           OR  LHCE0430-ID-INFO-ADIC(1:2)  NOT EQUAL '01' AND '02' |  |  |  |  | N/A | N/A |
| VSPRT09                                                 AND '03' AND '04' |  |  |  |  | N/A | N/A |
| VSPRT74                                                 AND '05' AND '06' |  |  |  |  | N/A | N/A |
| VSPRT74                                                 AND '07' AND '08' |  |  |  |  | N/A | N/A |
| VSPRT74                                                 AND '09' AND '10' |  |  |  |  | N/A | N/A |
| VSPRT09                                                 AND '99' |  |  |  |  | N/A | N/A |
| VSPRT09             MOVE  CT-22              TO  WK-CD-RETORNO(WK-IND1) |  |  |  |  | N/A | N/A |
| VSPRT09             MOVE  CT-SIM             TO  CT-ERRO |  |  |  |  | N/A | N/A |
| VSPRT09             ADD   CT-01              TO  WK-IND1 |  |  |  |  | N/A | N/A |
| VSPRT09            END-IF |  |  |  |  | N/A | N/A |
| VSPRT09         WHEN OTHER |  |  |  |  | N/A | N/A |
| VSPRT09             CONTINUE |  |  |  |  | N/A | N/A |
| VSPRT09     END-EVALUATE |  |  |  |  | N/A | N/A |
| VSPRT09* |  |  |  |  | N/A | N/A |
| V  ||  * TRATAMENTO TIPO 15 |  |  |  |  | N/A | N/A |
| V  ||   T015-TRATA-TIPO-15 |  |  |  |  | N/A | N/A |
| V  ||       EVALUATE LHCE0430-CD1-SITUACAO |  |  |  |  | N/A | N/A |
| V  ||           WHEN CT-X-1 |  |  |  |  | N/A | N/A |
| 2014 |  |  |  |  | N/A | N/A |
| V  ||  * PASSOU A PERMITIR PREENCHIMENTO DO CNPJ MESMO QUANDO SIT=1 |  |  |  |  | N/A | N/A |
| V  ||  * POR ISSO, ACIMA ESTAH CONTINUE E ABAIXO INIBIDO |  |  |  |  | N/A | N/A |
| V  ||  *             IF LHCE0430-ID2-CNPJ  NOT EQUAL  ZEROS |  |  |  |  | N/A | N/A |
| V  ||  *                MOVE  CT-19            TO  WK-CD-RETORNO(WK-IND1) |  |  |  |  | N/A | N/A |
| V  ||  *                ADD   CT-01            TO  WK-IND1 |  |  |  |  | N/A | N/A |
| V  ||  *                MOVE  CT-SIM           TO  CT-ERRO |  |  |  |  | N/A | N/A |
| V  ||  *             END-IF |  |  |  |  | N/A | N/A |
| V  ||           WHEN SPACES |  |  |  |  | N/A | N/A |
| V  ||                MOVE    LHCE0430-ID2-CNPJ TO  WK-0038-CNPJ |  |  |  |  | N/A | N/A |
| V  ||                MOVE  CT-19               TO  WK-CD-RETORNO(WK-IND1) |  |  |  |  | N/A | N/A |
| V  ||  * TRATAMENTO TIPO 17 |  |  |  |  | N/A | N/A |
| VSPRT77 T017-TRATA-TIPO-17 |  |  |  |  | N/A | N/A |
| VSPRT77 |  |  |  |  | N/A | N/A |
| V      *    REESTRUTURA§¥O - INF ADICIONAL 1701 |  |  |  |  | N/A | N/A |
| V           IF LHCE0430-SB-INFO-ADIC  NOT EQUAL 01 |  |  |  |  | N/A | N/A |
| VSPRT77        MOVE  CT-17              TO  WK-CD-RETORNO(WK-IND1) |  |  |  |  | N/A | N/A |
| VSPRT77        MOVE  CT-SIM             TO  CT-ERRO |  |  |  |  | N/A | N/A |
| VSPRT77        ADD   CT-01              TO  WK-IND1 |  |  |  |  | N/A | N/A |
| VSPRT77     ELSE |  |  |  |  | N/A | N/A |
| VSPRT77        IF   LHCE0430-CD2-DATA-ANO  NOT NUMERIC   OR |  |  |  |  | N/A | N/A |
| VSPRT77             LHCE0430-CD2-DATA-ANO  EQUAL ZEROS   OR |  |  |  |  | N/A | N/A |
| VSPRT77             LHCE0430-CD2-DATA-MES  NOT NUMERIC   OR |  |  |  |  | N/A | N/A |
| VSPRT77             LHCE0430-CD2-DATA-MES  EQUAL ZEROS   OR |  |  |  |  | N/A | N/A |
| VSPRT77             LHCE0430-CD2-DATA-DIA  NOT NUMERIC   OR |  |  |  |  | N/A | N/A |
| VSPRT77             LHCE0430-CD2-DATA-DIA  EQUAL ZEROS   OR |  |  |  |  | N/A | N/A |
| VSPRT77             LHCE0430-CD2-BARRA1    NOT EQUAL '-' OR |  |  |  |  | N/A | N/A |
| VSPRT77             LHCE0430-CD2-BARRA2    NOT EQUAL '-' |  |  |  |  | N/A | N/A |
| VSPRT77             MOVE  CT-11              TO  WK-CD-RETORNO(WK-IND1) |  |  |  |  | N/A | N/A |
| VSPRT77             MOVE  CT-SIM             TO  CT-ERRO |  |  |  |  | N/A | N/A |
| VSPRT77             ADD   CT-01              TO  WK-IND1 |  |  |  |  | N/A | N/A |
| VSPRT77        ELSE |  |  |  |  | N/A | N/A |
| VSPRT77             MOVE LHCE0430-CD2-DATA-ANO   TO    WK-AA-REESTRU-NUM |  |  |  |  | N/A | N/A |
| VSPRT77             MOVE LHCE0430-CD2-DATA-MES   TO    WK-MM-REESTRU-NUM |  |  |  |  | N/A | N/A |
| VSPRT77             MOVE LHCE0430-CD2-DATA-DIA   TO    WK-DD-REESTRU-NUM |  |  |  |  | N/A | N/A |
| VSPRT77             MOVE WK-DT-REESTRU-NUM         TO WK-0152-DATA |  |  |  |  | N/A | N/A |
| VSPRT77             CALL  CT-DRAM0152  USING  WK-DRAM0152 |  |  |  |  | N/A | N/A |
| VSPRT77             IF  WK-0152-RET  NOT EQUAL 0 |  |  |  |  | N/A | N/A |
| VSPRT77                 MOVE  CT-11            TO  WK-CD-RETORNO(WK-IND1) |  |  |  |  | N/A | N/A |
| VSPRT77                 MOVE  CT-SIM             TO  CT-ERRO |  |  |  |  | N/A | N/A |
| VSPRT77                 ADD   CT-01              TO  WK-IND1 |  |  |  |  | N/A | N/A |
| VSPRT77             END-IF |  |  |  |  | N/A | N/A |
| VSPRT77        END-IF |  |  |  |  | N/A | N/A |
| VSPRT77        IF LHCE0430-ID1-MOTIVO          NOT EQUAL SPACES AND |  |  |  |  | N/A | N/A |
| VSPRT77           LHCE0430-ID1-MOTIVO          NOT EQUAL ZEROS  AND |  |  |  |  | N/A | N/A |
| VSPRT77           LHCE0430-ID1-MOTIVO          NOT EQUAL '01'   AND |  |  |  |  | N/A | N/A |
| VSPRT77           LHCE0430-ID1-MOTIVO          NOT EQUAL '02' |  |  |  |  | N/A | N/A |
| VSPRT77              MOVE  CT-19            TO  WK-CD-RETORNO(WK-IND1) |  |  |  |  | N/A | N/A |
| VSPRT77              MOVE  CT-SIM             TO  CT-ERRO |  |  |  |  | N/A | N/A |
| VSPRT77              ADD   CT-01              TO  WK-IND1 |  |  |  |  | N/A | N/A |
| VSPRT77     END-IF |  |  |  |  | N/A | N/A |
| VSPRT77* |  |  |  |  | N/A | N/A |
| V  ||  * TRATAMENTO TIPO 18 |  |  |  |  | N/A | N/A |
| V  ||   T018-TRATA-TIPO-18 |  |  |  |  | N/A | N/A |
| V  ||   T019-TRATA-TIPO-19 |  |  |  |  | N/A | N/A |
| V  ||       IF LHCE0430-SB-INFO-ADIC EQUAL 99 |  |  |  |  | N/A | N/A |
| V  ||          PERFORM R340-VALIDA-CD-INFO-ADIC |  |  |  |  | N/A | N/A |
| VMEMBER NAME  LHAN0706 |  |  |  |  | N/A | N/A |
| V       PROGRAM-ID.    LHAN0706 |  |  |  |  | N/A | N/A |
| V       AUTHOR.        T520Q6S |  |  |  |  | N/A | N/A |
| V      **OBJETIVO: CRIAR REGISTRO DE INFORMACAO ADICIONAL TIPO 14      * |  |  |  |  | N/A | N/A |
| V      *           PARA OPERACOES COM BENEFICIO DO COMPULSORIO         * |  |  |  |  | N/A | N/A |
| V      *           INFORMADOS EM ARQUIVO GERADO POR RISCOS SOLVENCIA   * |  |  |  |  | N/A | N/A |
| V      * ARQUIVOS:                                                     * |  |  |  |  | N/A | N/A |
| V      *  INPUT                                                        * |  |  |  |  | N/A | N/A |
| V      *   DDNAME        DESC                   BOOK                   * |  |  |  |  | N/A | N/A |
| V      *  E1DQ0706   -  MOVTO RECEBIDO ORIGEM   LHCE0400               * |  |  |  |  | N/A | N/A |
| V697665*  E2DQ0706   -  MOVTO RECEBIDO CONNECT  LHCE0430               * |  |  |  |  | N/A | N/A |
| V      *  OUTPUT                                                       * |  |  |  |  | N/A | N/A |
| V      *  S1DQ0706   -  MOVTO FORMATADO OK      LHCE0400               * |  |  |  |  | N/A | N/A |
| V697665*  S2DQ0706   -  MOVTO CONNECT - RETORNO LHCE0430               * |  |  |  |  | N/A | N/A |
| V      *                   M A N U T E N C A O                         * |  |  |  |  | N/A | N/A |
| V      *   DATA    USUARIO    DESCRICAO                                * |  |  |  |  | N/A | N/A |
| VV001  * 12052014  ROBERTO    ACEITAR E2DQ0706 VAZIO                   * |  |  |  |  | N/A | N/A |
| V697665* 22092014  MARCELLO   OPERACOES DESCONSIGNADAS                 * |  |  |  |  | N/A | N/A |
| V  ||  *                      - UNIFICACAO BOOKS LHCE0430 E LHCE0431   * |  |  |  |  | N/A | N/A |
| V  ||  *                      - MATCH ENTRE ORIGENS E TATICO INFO ADIC |  |  |  |  | N/A | N/A |
| V  ||  *                        - PREVALECE DA ORIGEM                  * |  |  |  |  | N/A | N/A |
| SUBTIPO CONTRA NATUREZA * |  |  |  |  | N/A | N/A |
| V  ||  *                      - TEMPORARIO: "-" NA POSICAO 100 DO      * |  |  |  |  | N/A | N/A |
| V  ||  *                        CAMPO LHCE0400-TX-INFO-ADIC PARA INDI- * |  |  |  |  | N/A | N/A |
| V697665*                        CAR QUE A ORIGEM E DO TATICO           * |  |  |  |  | N/A | N/A |
| VCORBAN* 21102016  ROBERTO    PROJ INCL CORRESP BANCARIO NO CADOC3040  * |  |  |  |  | N/A | N/A |
| VCORBAN*                      TP-INFO=16,SB-INFO=01,ID-INFO=CNPJ       * |  |  |  |  | N/A | N/A |
| V1350  *   072019  ADELMO     INFO ADIC PARA MOD 1350                 * |  |  |  |  | N/A | N/A |
| VSPRT04*   100520  ADELMO     INFO ADIC PARA MOD 06XX                 * |  |  |  |  | N/A | N/A |
| VSPRT74*   300424  CABRAL     INFO ADIC = 24 - RWA                    * |  |  |  |  | N/A | N/A |
| VSPRT77*   240724  ADELMO     INFO ADIC PARA MOD 1701                 * |  |  |  |  | N/A | N/A |
| V           SELECT  E1DQ0706            ASSIGN  TO  E1DQ0706 |  |  |  |  | N/A | N/A |
| V           SELECT  E2DQ0706            ASSIGN  TO  E2DQ0706 |  |  |  |  | N/A | N/A |
| V           SELECT  S1DQ0706            ASSIGN  TO  S1DQ0706 |  |  |  |  | N/A | N/A |
| V           SELECT  S2DQ0706            ASSIGN  TO  S2DQ0706 |  |  |  |  | N/A | N/A |
| V      * ARQ COM OPERACOES DE RISCO A SEREM FORMATADAS |  |  |  |  | N/A | N/A |
| V       FD  E1DQ0706 |  |  |  |  | N/A | N/A |
| V           LABEL     RECORD        IS              STANDARD |  |  |  |  | N/A | N/A |
| V           BLOCK     CONTAINS        0             RECORDS |  |  |  |  | N/A | N/A |
| V           RECORD    CONTAINS      550             CHARACTERS |  |  |  |  | N/A | N/A |
| V       01  REG-E1DQ0706               PIC X(550) |  |  |  |  | N/A | N/A |
| V      * ARQ COM OPERACOES DE RISCO A SEREM FORMATADAS ADICIONAL 14 |  |  |  |  | N/A | N/A |
| V       FD  E2DQ0706 |  |  |  |  | N/A | N/A |
| V697665     RECORD    CONTAINS      260             CHARACTERS |  |  |  |  | N/A | N/A |
| V       01  REG-E2DQ0706                PIC X(260) |  |  |  |  | N/A | N/A |
| V      * ARQ |  |  |  |  | N/A | N/A |
| V       FD  S1DQ0706 |  |  |  |  | N/A | N/A |
| V           BLOCK     CONTAINS        0               RECORDS |  |  |  |  | N/A | N/A |
| V       01  REG-S1DQ0706                 PIC X(550) |  |  |  |  | N/A | N/A |
| V       FD  S2DQ0706 |  |  |  |  | N/A | N/A |
| V       01  REG-S2DQ0706                 PIC X(260) |  |  |  |  | N/A | N/A |
| V       01  WS-LHCE0400 |  |  |  |  | N/A | N/A |
| V           ++INCLUDE LHCE0400 |  |  |  |  | N/A | N/A |
| V       01  WS-LHCE0400-AUX |  |  |  |  | N/A | N/A |
| V697665 01  WS-LHCE0430 |  |  |  |  | N/A | N/A |
| V  ||       ++INCLUDE LHCE0430 |  |  |  |  | N/A | N/A |
| SUB E NAT |  |  |  |  | N/A | N/A |
| V697665     COPY LHCE0700 |  |  |  |  | N/A | N/A |
| V       01  WS-VARIAVEIS |  |  |  |  | N/A | N/A |
| V           05  FS-MZV5002E             PIC 9(002)    VALUE ZEROS |  |  |  |  | N/A | N/A |
| V           05  STCODE                      PIC 9(002)    VALUE 99 |  |  |  |  | N/A | N/A |
| V           05  WS-JOBNAME              PIC X(008)    VALUE SPACES |  |  |  |  | N/A | N/A |
| V           05  WDT-BSE                 PIC 9(008)    VALUE ZEROS |  |  |  |  | N/A | N/A |
| V           05  PGMNAME                 PIC X(008)    VALUE 'LHAN0706' |  |  |  |  | N/A | N/A |
| V           05  CT-DRAM0018             PIC X(008)    VALUE 'DRAM0018' |  |  |  |  | N/A | N/A |
| V697665     05  CT-LHBR0700             PIC X(008)    VALUE 'LHBR0700' |  |  |  |  | N/A | N/A |
| V  ||       05  CT-SA                   PIC X(002)    VALUE 'SA' |  |  |  |  | N/A | N/A |
| V  ||       05  CT-X-1                  PIC X(001)    VALUE '1' |  |  |  |  | N/A | N/A |
| V  ||       05  CT-01                   PIC 9(002)    VALUE 01 |  |  |  |  | N/A | N/A |
| V  ||       05  CT-02                   PIC 9(002)    VALUE 02 |  |  |  |  | N/A | N/A |
| V  ||       05  CT-03                   PIC 9(002)    VALUE 03 |  |  |  |  | N/A | N/A |
| V  ||       05  CT-04                   PIC 9(002)    VALUE 04 |  |  |  |  | N/A | N/A |
| V  ||       05  CT-05                   PIC 9(002)    VALUE 05 |  |  |  |  | N/A | N/A |
| V  ||       05  CT-06                   PIC 9(002)    VALUE 06 |  |  |  |  | N/A | N/A |
| V  ||       05  CT-07                   PIC 9(002)    VALUE 07 |  |  |  |  | N/A | N/A |
| V  ||       05  CT-08                   PIC 9(002)    VALUE 08 |  |  |  |  | N/A | N/A |
| V  ||       05  CT-09                   PIC 9(002)    VALUE 09 |  |  |  |  | N/A | N/A |
| V  ||       05  CT-10                   PIC 9(002)    VALUE 10 |  |  |  |  | N/A | N/A |
| V  ||       05  CT-11                   PIC 9(002)    VALUE 11 |  |  |  |  | N/A | N/A |
| V  ||       05  CT-12                   PIC 9(002)    VALUE 12 |  |  |  |  | N/A | N/A |
| V  ||       05  CT-13                   PIC 9(002)    VALUE 13 |  |  |  |  | N/A | N/A |
| V  ||       05  CT-14                   PIC 9(002)    VALUE 14 |  |  |  |  | N/A | N/A |
| V  ||       05  CT-15                   PIC 9(002)    VALUE 15 |  |  |  |  | N/A | N/A |
| V  ||       05  CT-16                   PIC 9(002)    VALUE 16 |  |  |  |  | N/A | N/A |
| V  ||       05  CT-17                   PIC 9(002)    VALUE 17 |  |  |  |  | N/A | N/A |
| V  ||       05  CT-18                   PIC 9(002)    VALUE 18 |  |  |  |  | N/A | N/A |
| V  ||       05  CT-19                   PIC 9(002)    VALUE 19 |  |  |  |  | N/A | N/A |
| V  ||       05  CT-20                   PIC 9(002)    VALUE 20 |  |  |  |  | N/A | N/A |
| VSPRT74     05  CT-24                   PIC 9(002)    VALUE 24 |  |  |  |  | N/A | N/A |
| V697665     05  CT-HIFEN                PIC X(001)    VALUE '-' |  |  |  |  | N/A | N/A |
| V           05  WK-FIM-E1               PIC X(001)    VALUE 'N' |  |  |  |  | N/A | N/A |
| V           05  WK-FIM-E2               PIC X(001)    VALUE 'N' |  |  |  |  | N/A | N/A |
| V           05  WK-DESPREZA-E2          PIC X(001)    VALUE 'N' |  |  |  |  | N/A | N/A |
| V           05  CT-SIM                  PIC X(001)    VALUE 'S' |  |  |  |  | N/A | N/A |
| V697665*    05  WS-GRAVA-S1DQ0706       PIC X(001)    VALUE 'N' |  |  |  |  | N/A | N/A |
| V697665     05  WS-CD-NAT-CTR           PIC 9(002) |  |  |  |  | N/A | N/A |
| VCORBAN     05  WS-CNPJ-CORRESP |  |  |  |  | N/A | N/A |
| VCORBAN      10 WS-CNPJ-ZERO            PIC 9(001) |  |  |  |  | N/A | N/A |
| VCORBAN      10 WS-CNPJ-14              PIC 9(014) |  |  |  |  | N/A | N/A |
| VCORBAN     05  WS-CNPJ-CORRESP-N REDEFINES WS-CNPJ-CORRESP |  |  |  |  | N/A | N/A |
| VCORBAN                                 PIC 9(015) |  |  |  |  | N/A | N/A |
| V       01  WS-CHAVES |  |  |  |  | N/A | N/A |
| V           02  WS-CHAVE-E1 |  |  |  |  | N/A | N/A |
| V             05  E1-CD-ITF               PIC X(004)    VALUE SPACES |  |  |  |  | N/A | N/A |
| V             05  E1-NR-OPR-X             PIC X(033)    VALUE SPACES |  |  |  |  | N/A | N/A |
| V             05  E1-MOD-X                PIC X(002)    VALUE SPACES |  |  |  |  | N/A | N/A |
| V           02  WS-QUEBRA-E1              PIC X(039) |  |  |  |  | N/A | N/A |
| V           02  WS-CHAVE-E2 |  |  |  |  | N/A | N/A |
| V             05  E2-CD-ITF               PIC X(004)    VALUE SPACES |  |  |  |  | N/A | N/A |
| V             05  E2-NR-OPR-X             PIC X(033)    VALUE SPACES |  |  |  |  | N/A | N/A |
| V             05  E2-MOD-X                PIC X(002)    VALUE SPACES |  |  |  |  | N/A | N/A |
| V697665     02  WS-QUEBRA-E2              PIC X(039) |  |  |  |  | N/A | N/A |
| V           03  AC-LIDOS-E1             PIC 9(009)    VALUE ZEROS |  |  |  |  | N/A | N/A |
| V           03  AC-LIDOS-E2             PIC 9(009)    VALUE ZEROS |  |  |  |  | N/A | N/A |
| V           03  AC-ERRADOS-E2           PIC 9(009)    VALUE ZEROS |  |  |  |  | N/A | N/A |
| V           03  AC-SEMCORR-E2           PIC 9(009)    VALUE ZEROS |  |  |  |  | N/A | N/A |
| V           03  AC-ORIGEM-E2            PIC 9(009)    VALUE ZEROS |  |  |  |  | N/A | N/A |
| V           03  AC-INCLUIDO-S1          PIC 9(009)    VALUE ZEROS |  |  |  |  | N/A | N/A |
| V           03  AC-GRAVADOS-S1          PIC 9(009)    VALUE ZEROS |  |  |  |  | N/A | N/A |
| V           03  AC-GRAVADOS-S2          PIC 9(009)    VALUE ZEROS |  |  |  |  | N/A | N/A |
| V1350       03  AC-FALTA-1350           PIC 9(009)    VALUE ZEROS |  |  |  |  | N/A | N/A |
| V697665     03  AC-NATINCO-E2           PIC 9(009)    VALUE ZEROS |  |  |  |  | N/A | N/A |
| V  ||       03  AC-TP-QT                PIC S9(04) COMP  VALUE ZEROS |  |  |  |  | N/A | N/A |
| V  ||   01  ME-MENSAGENS |  |  |  |  | N/A | N/A |
| V  ||  *               ----+----1----+----2----+----3----+----4 |  |  |  |  | N/A | N/A |
| V  ||       03  ME-INFO-OK              PIC X(040) |  |  |  |  | N/A | N/A |
| V  ||           VALUE 'OK - INFO. GERADA ' |  |  |  |  | N/A | N/A |
| V  ||       03  ME-INFO-ORIG            PIC X(040) |  |  |  |  | N/A | N/A |
| V  ||           VALUE 'INFO ADIC DA ORIGEM' |  |  |  |  | N/A | N/A |
| V  ||       03  ME-INFO-SCORR           PIC X(040) |  |  |  |  | N/A | N/A |
| V  ||           VALUE 'NOK-SEM CORRESPONDENTE' |  |  |  |  | N/A | N/A |
| V  ||       03  ME-INFO-SCORR-CLI-MOD   PIC X(040) |  |  |  |  | N/A | N/A |
| MOD' |  |  |  |  | N/A | N/A |
| V  ||       03  ME-INFO-NAT-INVAL       PIC X(040) |  |  |  |  | N/A | N/A |
| V  ||           VALUE 'INFO ADIC NATUREZA INVALIDA' |  |  |  |  | N/A | N/A |
| V  ||   01  SW-SWITCHES |  |  |  |  | N/A | N/A |
| V  ||       03  SW-DOC-MODSUB           PIC X(001)    VALUE 'S' |  |  |  |  | N/A | N/A |
| V  ||           88  SW-DOC-MODSUB-SIM                 VALUE 'S' |  |  |  |  | N/A | N/A |
| V  ||           88  SW-DOC-MODSUB-NAO                 VALUE 'N' |  |  |  |  | N/A | N/A |
| V  ||   01  TB-INTERNA |  |  |  |  | N/A | N/A |
| V  ||       05  TB-TIPO-SUB |  |  |  |  | N/A | N/A |
| V  ||           10  TB-GR-TIPO-SUB   OCCURS 20 TIMES INDEXED BY IN-TP |  |  |  |  | N/A | N/A |
| V697665             15  TB-EL-TP        PIC X(004) |  |  |  |  | N/A | N/A |
| V      ***** AREAS PARA DISPLAY DE VERSAO DO PROGRAMA |  |  |  |  | N/A | N/A |
| V       01          WS-CURRENT-DATE     PIC  X(19) |  |  |  |  | N/A | N/A |
| V       01          FILLER  REDEFINES  WS-CURRENT-DATE |  |  |  |  | N/A | N/A |
| V         03        WS-SYSTEM-DATE      PIC  9(08) |  |  |  |  | N/A | N/A |
| V         03        FILLER  REDEFINES  WS-SYSTEM-DATE |  |  |  |  | N/A | N/A |
| V           05      WS-SYSTEM-DATE-YYYY PIC  9(04) |  |  |  |  | N/A | N/A |
| V           05      WS-SYSTEM-DATE-MM   PIC  9(02) |  |  |  |  | N/A | N/A |
| V           05      WS-SYSTEM-DATE-DD   PIC  9(02) |  |  |  |  | N/A | N/A |
| V         03        WS-SYSTEM-TIME      PIC  9(07) |  |  |  |  | N/A | N/A |
| V         03        FILLER  REDEFINES  WS-SYSTEM-TIME |  |  |  |  | N/A | N/A |
| V           05      WS-SYSTEM-TIME-HH   PIC  9(02) |  |  |  |  | N/A | N/A |
| V           05      WS-SYSTEM-TIME-MM   PIC  9(02) |  |  |  |  | N/A | N/A |
| V           05      WS-SYSTEM-TIME-SS   PIC  9(02) |  |  |  |  | N/A | N/A |
| V           05      WS-SYSTEM-TIME-T    PIC  9(01) |  |  |  |  | N/A | N/A |
| V         03        FILLER              PIC  X(04) |  |  |  |  | N/A | N/A |
| ' |  |  |  |  | N/A | N/A |
| V       01          FILLER  REDEFINES  WS-DATA-SIST |  |  |  |  | N/A | N/A |
| V         03        WS-DATA-SIST-DD     PIC  9(02) |  |  |  |  | N/A | N/A |
| V         03        FILLER              PIC  X(01) |  |  |  |  | N/A | N/A |
| V         03        WS-DATA-SIST-MM     PIC  9(02) |  |  |  |  | N/A | N/A |
| V         03        WS-DATA-SIST-AAAA   PIC  9(04) |  |  |  |  | N/A | N/A |
| V       01          WS-HORA-SIST        PIC  X(08)  VALUE  '  :  :  ' |  |  |  |  | N/A | N/A |
| V       01          FILLER  REDEFINES  WS-HORA-SIST |  |  |  |  | N/A | N/A |
| V         03        WS-HORA-SIST-HH     PIC  9(02) |  |  |  |  | N/A | N/A |
| V         03        WS-HORA-SIST-MM     PIC  9(02) |  |  |  |  | N/A | N/A |
| V         03        WS-HORA-SIST-SS     PIC  9(02) |  |  |  |  | N/A | N/A |
| V       01          WS-COMPILATION-DATE |  |  |  |  | N/A | N/A |
| V         03        WS-COMP-DATE        PIC  X(08) VALUE  SPACES |  |  |  |  | N/A | N/A |
| V         03        FILLER  REDEFINES  WS-COMP-DATE |  |  |  |  | N/A | N/A |
| V           05      WS-COMP-DATE-MM     PIC  9(02) |  |  |  |  | N/A | N/A |
| V           05      FILLER              PIC  X(01) |  |  |  |  | N/A | N/A |
| V           05      WS-COMP-DATE-DD     PIC  9(02) |  |  |  |  | N/A | N/A |
| V           05      WS-COMP-DATE-YY     PIC  9(02) |  |  |  |  | N/A | N/A |
| V         03        WS-COMP-TIME        PIC  X(08) VALUE  SPACES |  |  |  |  | N/A | N/A |
| V       01          FILLER  REDEFINES  WS-DATA-COMP |  |  |  |  | N/A | N/A |
| V         03        WS-DATA-COMP-DD     PIC  9(02) |  |  |  |  | N/A | N/A |
| V         03        WS-DATA-COMP-MM     PIC  9(02) |  |  |  |  | N/A | N/A |
| V         03        WS-DATA-COMP-AA     PIC  9(02) |  |  |  |  | N/A | N/A |
| V       01          WK-DATA-BASE        PIC  9(08) |  |  |  |  | N/A | N/A |
| V       01          FILLER  REDEFINES  WK-DATA-BASE |  |  |  |  | N/A | N/A |
| V         03        WK-DATA-BASE-AAAA   PIC  9(04) |  |  |  |  | N/A | N/A |
| V         03        WK-DATA-BASE-MM     PIC  9(02) |  |  |  |  | N/A | N/A |
| V         03        WK-DATA-BASE-DD     PIC  9(02) |  |  |  |  | N/A | N/A |
| V697665        THRU  R100-EXIT |  |  |  |  | N/A | N/A |
| V697665     PERFORM  R200-PROCESSAMENTO |  |  |  |  | N/A | N/A |
| V697665        THRU  R200-EXIT |  |  |  |  | N/A | N/A |
| V697665        UNTIL WK-FIM-E1  EQUAL 'S' |  |  |  |  | N/A | N/A |
| V697665          AND WK-FIM-E2  EQUAL 'S' |  |  |  |  | N/A | N/A |
| V           PERFORM  R800-FINALIZACAO |  |  |  |  | N/A | N/A |
| V      ****** MONTA AREA PARA MOSTRAR DATA E HORA DE COMPILACAO |  |  |  |  | N/A | N/A |
| V           MOVE  FUNCTION  CURRENT-DATE  TO  WS-CURRENT-DATE |  |  |  |  | N/A | N/A |
| V           MOVE  WS-SYSTEM-DATE-YYYY     TO  WS-DATA-SIST-AAAA |  |  |  |  | N/A | N/A |
| V           MOVE  WS-SYSTEM-DATE-MM       TO  WS-DATA-SIST-MM |  |  |  |  | N/A | N/A |
| V           MOVE  WS-SYSTEM-DATE-DD       TO  WS-DATA-SIST-DD |  |  |  |  | N/A | N/A |
| V           MOVE  WS-SYSTEM-TIME-HH       TO  WS-HORA-SIST-HH |  |  |  |  | N/A | N/A |
| V           MOVE  WS-SYSTEM-TIME-MM       TO  WS-HORA-SIST-MM |  |  |  |  | N/A | N/A |
| V           MOVE  WS-SYSTEM-TIME-SS       TO  WS-HORA-SIST-SS |  |  |  |  | N/A | N/A |
| V           MOVE  WHEN-COMPILED           TO  WS-COMPILATION-DATE |  |  |  |  | N/A | N/A |
| V           MOVE  WS-COMP-DATE-MM         TO  WS-DATA-COMP-MM |  |  |  |  | N/A | N/A |
| V           MOVE  WS-COMP-DATE-DD         TO  WS-DATA-COMP-DD |  |  |  |  | N/A | N/A |
| V           MOVE  WS-COMP-DATE-YY         TO  WS-DATA-COMP-AA |  |  |  |  | N/A | N/A |
| V           DISPLAY '**         PROGRAMA LHAN0706              **' |  |  |  |  | N/A | N/A |
| V           DISPLAY '*  DATA DO SISTEMA ... |  |  |  |  | N/A | N/A |
| V           DISPLAY '*  HORA DO SISTEMA ... |  |  |  |  | N/A | N/A |
| V           DISPLAY '*  DATA DE COMPILACAO |  |  |  |  | N/A | N/A |
| V           DISPLAY '*  HORA DE COMPILACAO |  |  |  |  | N/A | N/A |
| V           DISPLAY '**************************************' |  |  |  |  | N/A | N/A |
| V      *-------- ABERTURA DOS ARQUIVOS SEQUENCIAIS |  |  |  |  | N/A | N/A |
| V           OPEN INPUT  E1DQ0706 |  |  |  |  | N/A | N/A |
| V                       E2DQ0706 |  |  |  |  | N/A | N/A |
| V                OUTPUT S1DQ0706 |  |  |  |  | N/A | N/A |
| V                       S2DQ0706 |  |  |  |  | N/A | N/A |
| V      *-------- LEITURA DO ARQUIVO DE ENTRADA (HEADER DO ARQUIVO) |  |  |  |  | N/A | N/A |
| V           PERFORM R110-LER-E1DQ0706 |  |  |  |  | N/A | N/A |
| V697665        THRU R110-EXIT |  |  |  |  | N/A | N/A |
| V           IF  WK-FIM-E1  EQUAL  'S' |  |  |  |  | N/A | N/A |
| V               DISPLAY '***********************************************' |  |  |  |  | N/A | N/A |
| V               DISPLAY '      PROGRAMA LHAN0706  -   CANCELADO         ' |  |  |  |  | N/A | N/A |
| V               DISPLAY '  ' |  |  |  |  | N/A | N/A |
| V               DISPLAY '        ARQUIVO E1DQ0706 ESTA VAZIO' |  |  |  |  | N/A | N/A |
| V               GO TO  R990-CANCELA |  |  |  |  | N/A | N/A |
| V           DISPLAY '*  DATA BASE OPERACOES : ' |  |  |  |  | N/A | N/A |
| V           DISPLAY LHCE0400-DT-BSE OF WS-LHCE0400  '    *' |  |  |  |  | N/A | N/A |
| V           PERFORM R120-CONTROLE-E2DQ0706 |  |  |  |  | N/A | N/A |
| V697665        THRU R120-EXIT |  |  |  |  | N/A | N/A |
| VV001  *    IF  WK-FIM-E2  EQUAL  'S' |  |  |  |  | N/A | N/A |
| VV001  *        DISPLAY '***********************************************' |  |  |  |  | N/A | N/A |
| VV001  *        DISPLAY '      PROGRAMA LHAN0706  -   CANCELADO         ' |  |  |  |  | N/A | N/A |
| VV001  *        DISPLAY '  ' |  |  |  |  | N/A | N/A |
| VV001  *        DISPLAY '        ARQUIVO E2DQ0706 ESTA VAZIO OU SEM     ' |  |  |  |  | N/A | N/A |
| VV001  *        DISPLAY '        OU ARQUIVO SEM REGISTRO VALIDO         ' |  |  |  |  | N/A | N/A |
| VV001  *        GO TO  R990-CANCELA |  |  |  |  | N/A | N/A |
| VV001  *    END-IF |  |  |  |  | N/A | N/A |
| V           DISPLAY '*  DATA BASE MARCACAO  : ' |  |  |  |  | N/A | N/A |
| V697665     DISPLAY LHCE0430-DT-BSE   '    *' |  |  |  |  | N/A | N/A |
| V      *  LER OPERACOES DE RISCO                                       * |  |  |  |  | N/A | N/A |
| V       R110-LER-E1DQ0706               SECTION |  |  |  |  | N/A | N/A |
| V           IF WK-FIM-E1  EQUAL 'S' |  |  |  |  | N/A | N/A |
| V              GO TO R110-EXIT |  |  |  |  | N/A | N/A |
| V           READ  E1DQ0706 INTO WS-LHCE0400 |  |  |  |  | N/A | N/A |
| V              MOVE 'S'                 TO WK-FIM-E1 |  |  |  |  | N/A | N/A |
| V           IF WK-FIM-E1 NOT EQUAL 'S' |  |  |  |  | N/A | N/A |
| V              MOVE  LHCE0400-CD-ITF   OF WS-LHCE0400  TO  E1-CD-ITF |  |  |  |  | N/A | N/A |
| V              MOVE  LHCE0400-NR-OPR-X OF WS-LHCE0400  TO  E1-NR-OPR-X |  |  |  |  | N/A | N/A |
| V              MOVE  LHCE0400-CD-DMN-MDL-CTR-X OF WS-LHCE0400 |  |  |  |  | N/A | N/A |
| V                                                      TO  E1-MOD-X |  |  |  |  | N/A | N/A |
| V              ADD  1   TO  AC-LIDOS-E1 |  |  |  |  | N/A | N/A |
| V              MOVE  HIGH-VALUES        TO  E1-CD-ITF |  |  |  |  | N/A | N/A |
| V              MOVE  HIGH-VALUES        TO  E1-NR-OPR-X |  |  |  |  | N/A | N/A |
| V              MOVE  HIGH-VALUES        TO  E1-MOD-X |  |  |  |  | N/A | N/A |
| V       R110-EXIT.     EXIT |  |  |  |  | N/A | N/A |
| V      *  CONTROLA LEITURA DE MARCACAO DE OPERACOES                    * |  |  |  |  | N/A | N/A |
| V       R120-CONTROLE-E2DQ0706          SECTION |  |  |  |  | N/A | N/A |
| V       R120-CONTROLE-INICIO |  |  |  |  | N/A | N/A |
| V           IF WK-FIM-E2  EQUAL 'S' |  |  |  |  | N/A | N/A |
| V              GO TO R120-EXIT |  |  |  |  | N/A | N/A |
| V           PERFORM  R125-LER-E2DQ0706 |  |  |  |  | N/A | N/A |
| V697665        THRU  R125-EXIT |  |  |  |  | N/A | N/A |
| V           MOVE 'N'  TO WK-DESPREZA-E2 |  |  |  |  | N/A | N/A |
| V           IF WK-FIM-E2  NOT EQUAL 'S' |  |  |  |  | N/A | N/A |
| V697665        IF LHCE0430-CD-RETORNO (01) NOT EQUAL ZEROS |  |  |  |  | N/A | N/A |
| V                 MOVE 'S'  TO WK-DESPREZA-E2 |  |  |  |  | N/A | N/A |
| V                 ADD 1 TO AC-ERRADOS-E2 |  |  |  |  | N/A | N/A |
| V                 PERFORM  R510-GRAVA-S2DQ0706 |  |  |  |  | N/A | N/A |
| V697665              THRU  R510-EXIT |  |  |  |  | N/A | N/A |
| V              ELSE |  |  |  |  | N/A | N/A |
| V697665           IF  LHCE0430-TP-REG     NOT EQUAL  1 |  |  |  |  | N/A | N/A |
| V                     MOVE 'S'  TO WK-DESPREZA-E2 |  |  |  |  | N/A | N/A |
| V                     PERFORM  R510-GRAVA-S2DQ0706 |  |  |  |  | N/A | N/A |
| V697665                  THRU  R510-EXIT |  |  |  |  | N/A | N/A |
| V                 END-IF |  |  |  |  | N/A | N/A |
| V              END-IF |  |  |  |  | N/A | N/A |
| V              IF WK-DESPREZA-E2  EQUAL 'S' |  |  |  |  | N/A | N/A |
| V                 GO TO R120-CONTROLE-INICIO |  |  |  |  | N/A | N/A |
| V       R120-EXIT.     EXIT |  |  |  |  | N/A | N/A |
| V       R125-LER-E2DQ0706               SECTION |  |  |  |  | N/A | N/A |
| V697665     READ  E2DQ0706 INTO  WS-LHCE0430 |  |  |  |  | N/A | N/A |
| V                MOVE 'S'                  TO WK-FIM-E2 |  |  |  |  | N/A | N/A |
| V           IF WK-FIM-E2 NOT EQUAL 'S' |  |  |  |  | N/A | N/A |
| V697665        MOVE  LHCE0430-CD-ITF          TO  E2-CD-ITF |  |  |  |  | N/A | N/A |
| V  ||          MOVE  LHCE0430-NR-OPR-X        TO  E2-NR-OPR-X |  |  |  |  | N/A | N/A |
| V697665        MOVE  LHCE0430-CD-MOD-CTR(1:2) TO  E2-MOD-X |  |  |  |  | N/A | N/A |
| V              ADD  1   TO  AC-LIDOS-E2 |  |  |  |  | N/A | N/A |
| V              MOVE  HIGH-VALUES        TO  E2-CD-ITF |  |  |  |  | N/A | N/A |
| V              MOVE  HIGH-VALUES        TO  E2-NR-OPR-X |  |  |  |  | N/A | N/A |
| V              MOVE  HIGH-VALUES        TO  E2-MOD-X |  |  |  |  | N/A | N/A |
| V       R125-EXIT.     EXIT |  |  |  |  | N/A | N/A |
| V      ****************************************************************** |  |  |  |  | N/A | N/A |
| V697665     SET  SW-DOC-MODSUB-NAO   TO    TRUE |  |  |  |  | N/A | N/A |
| V697665     EVALUATE TRUE |  |  |  |  | N/A | N/A |
| V  ||          WHEN  WS-CHAVE-E1  EQUAL    WS-CHAVE-E2 |  |  |  |  | N/A | N/A |
| V  ||                PERFORM R201-TRATA-IGUAIS |  |  |  |  | N/A | N/A |
| V  ||                   THRU R201-EXIT |  |  |  |  | N/A | N/A |
| V  ||          WHEN  WS-CHAVE-E1  GREATER  WS-CHAVE-E2 |  |  |  |  | N/A | N/A |
| V  ||                PERFORM R301-TATICO-INEXISTE-E1 |  |  |  |  | N/A | N/A |
| V  ||                   THRU R301-EXIT |  |  |  |  | N/A | N/A |
| V  ||          WHEN OTHER |  |  |  |  | N/A | N/A |
| V  ||                IF (LHCE0400-TP-REG OF WS-LHCE0400  EQUAL CT-01) AND |  |  |  |  | N/A | N/A |
| V  ||                   (LHCE0400-CD-MOD-CTR OF WS-LHCE0400 = 1350)   AND |  |  |  |  | N/A | N/A |
| V  ||                   (LHCE0400-CD-NAT-CTR OF WS-LHCE0400 = CT-01) |  |  |  |  | N/A | N/A |
| V1350                ADD     1               TO AC-FALTA-1350 |  |  |  |  | N/A | N/A |
| V1350                DISPLAY 'LHAN0706 MOD 1350 NAT 01 SEM ADIC ' |  |  |  |  | N/A | N/A |
| V1350 -                      'SIST:' LHCE0400-CD-ITF OF WS-LHCE0400 |  |  |  |  | N/A | N/A |
| V1350 -                      ' OPER:' LHCE0400-NR-OPR-X OF WS-LHCE0400 |  |  |  |  | N/A | N/A |
| V  ||                PERFORM R401-SALVA-E1DQ0706-S1 |  |  |  |  | N/A | N/A |
| V  ||                   THRU R401-EXIT |  |  |  |  | N/A | N/A |
| V       R200-EXIT.     EXIT |  |  |  |  | N/A | N/A |
| V  ||  * TRATA IGUAIS |  |  |  |  | N/A | N/A |
| V  ||   R201-TRATA-IGUAIS               SECTION |  |  |  |  | N/A | N/A |
| V  ||  *    REAPROVEITA SECTION R401 PARA ASSEGURAR DESCARGA DA OPERACAO |  |  |  |  | N/A | N/A |
| V697665*    EM S1, DEPOIS DECIDE SE GRAVA E2-TATICO EM S1 |  |  |  |  | N/A | N/A |
| V           IF (LHCE0430-CD-CIC       EQUAL  LHCE0400-CD-CIC |  |  |  |  | N/A | N/A |
| V                                        OF  WS-LHCE0400)         AND |  |  |  |  | N/A | N/A |
| V              (LHCE0430-CD-MOD-CTR   EQUAL  LHCE0400-CD-MOD-CTR |  |  |  |  | N/A | N/A |
| V                                        OF  WS-LHCE0400) |  |  |  |  | N/A | N/A |
| V697665         SET SW-DOC-MODSUB-SIM    TO  TRUE |  |  |  |  | N/A | N/A |
| V  ||       PERFORM R401-SALVA-E1DQ0706-S1 |  |  |  |  | N/A | N/A |
| V  ||          THRU R401-EXIT |  |  |  |  | N/A | N/A |
| V  ||  *    AVALIAR SE ENTRADA TATICO E2 DEVE GRAVAR S1 |  |  |  |  | N/A | N/A |
| V  ||       MOVE WS-CHAVE-E2             TO  WS-QUEBRA-E2 |  |  |  |  | N/A | N/A |
| V  ||       PERFORM R210-ANALISE-E2DQ0706 |  |  |  |  | N/A | N/A |
| V  ||          THRU R210-EXIT |  |  |  |  | N/A | N/A |
| V  ||         UNTIL WS-CHAVE-E2   NOT EQUAL  WS-QUEBRA-E2 |  |  |  |  | N/A | N/A |
| V  ||   R201-EXIT.     EXIT |  |  |  |  | N/A | N/A |
| V  ||  * AVALIAR SE ENTRADA TATICO E2 DEVE GRAVAR S1 |  |  |  |  | N/A | N/A |
| V  ||   R210-ANALISE-E2DQ0706           SECTION |  |  |  |  | N/A | N/A |
| V  ||  *    SE SW-DOC-MODSUB-SIM |  |  |  |  | N/A | N/A |
| V  ||  *    - VERIFICAR COMPATIBILIDADE TIPO SUBTIPO INFO. ADIC |  |  |  |  | N/A | N/A |
| V  ||  *      - SE COMBINACAO OK |  |  |  |  | N/A | N/A |
| V  ||  *        - TATICO CONTRA TABELA MEMORIA DA ORIGEM: |  |  |  |  | N/A | N/A |
| V  ||  *          - SE NAO EXISTIR, SECTION R211 PARA GRAVAR S1 E S2 |  |  |  |  | N/A | N/A |
| V  ||  *          - SE     EXISTIR, INFO ADIC DA ORIGEM E GRAVAR  S2 |  |  |  |  | N/A | N/A |
| V  ||  *      - OUTRAS SITUACOES: TIPO SUBTIPO INFO. ADIC. NAT |  |  |  |  | N/A | N/A |
| MOD. SUBMOD |  |  |  |  | N/A | N/A |
| V  ||       IF SW-DOC-MODSUB-SIM |  |  |  |  | N/A | N/A |
| V  ||          MOVE  CT-02                  TO LHCE0700-NR-OPCAO |  |  |  |  | N/A | N/A |
| V  ||          MOVE  LHCE0430-TP-SB-INFO    TO LHCE0700-TX-OP2-TIPOSUB |  |  |  |  | N/A | N/A |
| V  ||          MOVE  WS-CD-NAT-CTR          TO LHCE0700-TX-OP2-NAT |  |  |  |  | N/A | N/A |
| V  ||          CALL  CT-LHBR0700         USING LI-LHCE0700 |  |  |  |  | N/A | N/A |
| VSPRT04        MOVE  ZEROS                  TO LHCE0700-CD-RET |  |  |  |  | N/A | N/A |
| V  ||          IF LHCE0700-CD-RET-OK |  |  |  |  | N/A | N/A |
| V  ||             SET    IN-TP              TO CT-01 |  |  |  |  | N/A | N/A |
| V  ||             SEARCH TB-GR-TIPO-SUB |  |  |  |  | N/A | N/A |
| V  ||                 AT END |  |  |  |  | N/A | N/A |
| V  ||                    PERFORM R211-GRAVA-E2DQ0706-S1 |  |  |  |  | N/A | N/A |
| V  ||                       THRU R211-EXIT |  |  |  |  | N/A | N/A |
| V  ||               WHEN TB-EL-TP(IN-TP) EQUAL LHCE0430-TP-SB-INFO |  |  |  |  | N/A | N/A |
| V  ||                    MOVE  CT-01        TO LHCE0430-CD-RETORNO(01) |  |  |  |  | N/A | N/A |
| V  ||                    MOVE  ME-INFO-ORIG TO LHCE0430-TX-MENSAGEM |  |  |  |  | N/A | N/A |
| V  ||                    PERFORM R510-GRAVA-S2DQ0706 |  |  |  |  | N/A | N/A |
| V  ||                       THRU R510-EXIT |  |  |  |  | N/A | N/A |
| V  ||             END-SEARCH |  |  |  |  | N/A | N/A |
| V  ||          ELSE |  |  |  |  | N/A | N/A |
| V  ||             MOVE  CT-04             TO LHCE0430-CD-RETORNO(01) |  |  |  |  | N/A | N/A |
| V  ||             MOVE  ME-INFO-NAT-INVAL TO LHCE0430-TX-MENSAGEM |  |  |  |  | N/A | N/A |
| V  ||             MOVE  WS-CD-NAT-CTR     TO LHCE0430-TX-MENSAGEM(30:02) |  |  |  |  | N/A | N/A |
| V  ||             ADD   CT-01             TO AC-NATINCO-E2 |  |  |  |  | N/A | N/A |
| V  ||             PERFORM R510-GRAVA-S2DQ0706 |  |  |  |  | N/A | N/A |
| V  ||                THRU R510-EXIT |  |  |  |  | N/A | N/A |
| V  ||          END-IF |  |  |  |  | N/A | N/A |
| V  ||       ELSE |  |  |  |  | N/A | N/A |
| V  ||          MOVE CT-03                      TO LHCE0430-CD-RETORNO(01) |  |  |  |  | N/A | N/A |
| V  ||          MOVE ME-INFO-SCORR-CLI-MOD      TO LHCE0430-TX-MENSAGEM |  |  |  |  | N/A | N/A |
| V  ||          PERFORM  R510-GRAVA-S2DQ0706 |  |  |  |  | N/A | N/A |
| V  ||             THRU  R510-EXIT |  |  |  |  | N/A | N/A |
| V  ||          ADD      CT-01                  TO AC-SEMCORR-E2 |  |  |  |  | N/A | N/A |
| V  ||  *       PERFORM  R120-CONTROLE-E2DQ0706 |  |  |  |  | N/A | N/A |
| V  ||  *          THRU  R120-EXIT |  |  |  |  | N/A | N/A |
| V  ||  *    REINICIALIZA TABELA INTERNA PARA NOVA OPERACAO |  |  |  |  | N/A | N/A |
| V  ||       MOVE     ZEROS   TO   TB-TIPO-SUB |  |  |  |  | N/A | N/A |
| V  ||       PERFORM  R120-CONTROLE-E2DQ0706 |  |  |  |  | N/A | N/A |
| V  ||          THRU  R120-EXIT |  |  |  |  | N/A | N/A |
| V  ||   R210-EXIT.     EXIT |  |  |  |  | N/A | N/A |
| V  ||  * GRAVA TATICO EM S1 E S2 |  |  |  |  | N/A | N/A |
| V  ||   R211-GRAVA-E2DQ0706-S1          SECTION |  |  |  |  | N/A | N/A |
| V  ||       MOVE  LHCE0430-TP-INFO-ADIC  TO |  |  |  |  | N/A | N/A |
| V  ||             LHCE0400-TP-INFO-ADIC  OF  WS-LHCE0400-AUX |  |  |  |  | N/A | N/A |
| V  ||       MOVE  LHCE0430-SB-INFO-ADIC  TO |  |  |  |  | N/A | N/A |
| V  ||             LHCE0400-SB-INFO-ADIC  OF  WS-LHCE0400-AUX |  |  |  |  | N/A | N/A |
| V  ||       MOVE  SPACES                 TO |  |  |  |  | N/A | N/A |
| V  ||             LHCE0400-CD-INFO-ADIC  OF  WS-LHCE0400-AUX |  |  |  |  | N/A | N/A |
| V  ||             LHCE0400-ID-INFO-ADIC  OF  WS-LHCE0400-AUX |  |  |  |  | N/A | N/A |
| V  ||             LHCE0400-TX-INFO-ADIC  OF  WS-LHCE0400-AUX |  |  |  |  | N/A | N/A |
| V  ||       MOVE  ZEROS                  TO |  |  |  |  | N/A | N/A |
| V  ||             LHCE0400-VL-INFO-ADIC  OF  WS-LHCE0400-AUX |  |  |  |  | N/A | N/A |
| V  ||             LHCE0400-PC-INFO-ADIC  OF  WS-LHCE0400-AUX |  |  |  |  | N/A | N/A |
| V  ||             LHCE0400-QT-INFO-ADIC  OF  WS-LHCE0400-AUX |  |  |  |  | N/A | N/A |
| V  ||  * TEMPORARIO-INICIO |  |  |  |  | N/A | N/A |
| V  ||       MOVE  CT-HIFEN               TO |  |  |  |  | N/A | N/A |
| V  ||             LHCE0400-TX-INFO-ADIC  OF  WS-LHCE0400-AUX(100:001) |  |  |  |  | N/A | N/A |
| V  ||  * TEMPORARIO-FIM |  |  |  |  | N/A | N/A |
| V  ||                PERFORM T001-GRAVA-TIPO-01 |  |  |  |  | N/A | N/A |
| V  ||                   THRU T001-EXIT |  |  |  |  | N/A | N/A |
| V  ||                PERFORM T002-GRAVA-TIPO-02 |  |  |  |  | N/A | N/A |
| V  ||                   THRU T002-EXIT |  |  |  |  | N/A | N/A |
| V  ||  *        WHEN CT-03                       TIPO NAO PREVISTO |  |  |  |  | N/A | N/A |
| V  ||  *             PERFORM T003-GRAVA-TIPO-03 |  |  |  |  | N/A | N/A |
| V  ||  *                THRU T003-EXIT |  |  |  |  | N/A | N/A |
| V  ||                PERFORM T004-GRAVA-TIPO-04 |  |  |  |  | N/A | N/A |
| V  ||                   THRU T004-EXIT |  |  |  |  | N/A | N/A |
| VSPRT04              PERFORM T006-GRAVA-TIPO-06 |  |  |  |  | N/A | N/A |
| VSPRT04                 THRU T006-EXIT |  |  |  |  | N/A | N/A |
| V  ||                PERFORM T007-GRAVA-TIPO-07 |  |  |  |  | N/A | N/A |
| V  ||                   THRU T007-EXIT |  |  |  |  | N/A | N/A |
| V  ||                PERFORM T010-GRAVA-TIPO-10 |  |  |  |  | N/A | N/A |
| V  ||                   THRU T010-EXIT |  |  |  |  | N/A | N/A |
| V  ||                PERFORM T011-GRAVA-TIPO-11 |  |  |  |  | N/A | N/A |
| V  ||                   THRU T011-EXIT |  |  |  |  | N/A | N/A |
| V  ||                PERFORM T012-GRAVA-TIPO-12 |  |  |  |  | N/A | N/A |
| V  ||                   THRU T012-EXIT |  |  |  |  | N/A | N/A |
| VSPRT09              PERFORM T014-GRAVA-TIPO-14 |  |  |  |  | N/A | N/A |
| VSPRT09                 THRU T014-EXIT |  |  |  |  | N/A | N/A |
| V  ||                PERFORM T015-GRAVA-TIPO-15 |  |  |  |  | N/A | N/A |
| V  ||                   THRU T015-EXIT |  |  |  |  | N/A | N/A |
| VCORBAN              PERFORM T016-GRAVA-TIPO-16 |  |  |  |  | N/A | N/A |
| VCORBAN                 THRU T016-EXIT |  |  |  |  | N/A | N/A |
| VSPRT77              PERFORM T017-GRAVA-TIPO-17 |  |  |  |  | N/A | N/A |
| VSPRT77                 THRU T017-EXIT |  |  |  |  | N/A | N/A |
| VOLIVA1              PERFORM T018-GRAVA-TIPO-18 |  |  |  |  | N/A | N/A |
| VOLIVA1                 THRU T018-EXIT |  |  |  |  | N/A | N/A |
| VOLIVA1              PERFORM T019-GRAVA-TIPO-19 |  |  |  |  | N/A | N/A |
| VOLIVA1                 THRU T019-EXIT |  |  |  |  | N/A | N/A |
| VSPRT74         WHEN CT-24 |  |  |  |  | N/A | N/A |
| VSPRT74              PERFORM T024-GRAVA-TIPO-24 |  |  |  |  | N/A | N/A |
| VSPRT74                 THRU T024-EXIT |  |  |  |  | N/A | N/A |
| V  ||       MOVE    WS-LHCE0400-AUX      TO  REG-S1DQ0706 |  |  |  |  | N/A | N/A |
| V  ||       PERFORM R500-GRAVA-S1DQ0706 |  |  |  |  | N/A | N/A |
| V  ||          THRU R500-EXIT |  |  |  |  | N/A | N/A |
| V  ||       MOVE    ZEROS                TO  LHCE0430-CD-RETORNO(01) |  |  |  |  | N/A | N/A |
| V  ||       MOVE    ME-INFO-OK           TO  LHCE0430-TX-MENSAGEM |  |  |  |  | N/A | N/A |
| V  ||       PERFORM R510-GRAVA-S2DQ0706 |  |  |  |  | N/A | N/A |
| V  ||          THRU R510-EXIT |  |  |  |  | N/A | N/A |
| V  ||       ADD     CT-01                TO  AC-INCLUIDO-S1 |  |  |  |  | N/A | N/A |
| V  ||   R211-EXIT.     EXIT |  |  |  |  | N/A | N/A |
| V  ||  * TRATA MAIOR - TATICO NAO EXISTE EM E1 |  |  |  |  | N/A | N/A |
| V  ||   R301-TATICO-INEXISTE-E1         SECTION |  |  |  |  | N/A | N/A |
| V  ||       MOVE    CT-02                TO  LHCE0430-CD-RETORNO(01) |  |  |  |  | N/A | N/A |
| V697665     MOVE    ME-INFO-SCORR        TO  LHCE0430-TX-MENSAGEM |  |  |  |  | N/A | N/A |
| V           PERFORM R510-GRAVA-S2DQ0706 |  |  |  |  | N/A | N/A |
| V              THRU R510-EXIT |  |  |  |  | N/A | N/A |
| V           ADD     CT-01                TO  AC-SEMCORR-E2 |  |  |  |  | N/A | N/A |
| V              THRU R120-EXIT |  |  |  |  | N/A | N/A |
| V  ||   R301-EXIT.     EXIT |  |  |  |  | N/A | N/A |
| V  ||  * GRAVA E1 EM S1 |  |  |  |  | N/A | N/A |
| V  ||  * - SE SW-DOC-MODSUB-SIM SIGNIFICA QUE ENCONTROU TATICO PARA |  |  |  |  | N/A | N/A |
| V  ||  *   PROCESSAMENTO, SALVA MODELO DO REGISTRO E DECIDE SE GRAVA |  |  |  |  | N/A | N/A |
| V  ||  *   TATICO NA SAIDA S1 NA SECTION R402 |  |  |  |  | N/A | N/A |
| V       R401-SALVA-E1DQ0706-S1          SECTION |  |  |  |  | N/A | N/A |
| SUBTIPO INFO. ADIC |  |  |  |  | N/A | N/A |
| V697665     MOVE ZEROS                       TO  AC-TP-QT |  |  |  |  | N/A | N/A |
| V           MOVE WS-CHAVE-E1                 TO  WS-QUEBRA-E1 |  |  |  |  | N/A | N/A |
| V           PERFORM |  |  |  |  | N/A | N/A |
| V             UNTIL  WS-CHAVE-E1      NOT EQUAL  WS-QUEBRA-E1 |  |  |  |  | N/A | N/A |
| V697665              IF  SW-DOC-MODSUB-SIM |  |  |  |  | N/A | N/A |
| V  ||                    PERFORM  R402-PREPARA-TATICO |  |  |  |  | N/A | N/A |
| V  ||                       THRU  R402-EXIT |  |  |  |  | N/A | N/A |
| V697665              END-IF |  |  |  |  | N/A | N/A |
| V                    MOVE     WS-LHCE0400    TO  REG-S1DQ0706 |  |  |  |  | N/A | N/A |
| V                    PERFORM  R500-GRAVA-S1DQ0706 |  |  |  |  | N/A | N/A |
| V                       THRU  R500-EXIT |  |  |  |  | N/A | N/A |
| V                    PERFORM  R110-LER-E1DQ0706 |  |  |  |  | N/A | N/A |
| V                       THRU  R110-EXIT |  |  |  |  | N/A | N/A |
| V           END-PERFORM |  |  |  |  | N/A | N/A |
| V       R401-EXIT.     EXIT |  |  |  |  | N/A | N/A |
| V      * EM CASO DE MATCH, PREPARA REGISTRO TIPO 5 PARA GRAVACAO TATICO |  |  |  |  | N/A | N/A |
| V       R402-PREPARA-TATICO             SECTION |  |  |  |  | N/A | N/A |
| V697665*--- SALVA MODELO PARA REGISTRO TIPO 5 |  |  |  |  | N/A | N/A |
| V  ||  *    LHCE0400-CD-NAT-CTR EM WORKING PARA VERIFICAR COMPATIBILIDADE |  |  |  |  | N/A | N/A |
| V697665*    ENTRE TATICO TIPO SUBTIPO INFO. AD |  |  |  |  | N/A | N/A |
| V           IF  LHCE0400-TP-REG OF WS-LHCE0400  EQUAL CT-01 |  |  |  |  | N/A | N/A |
| V697665         MOVE  LHCE0400-CD-NAT-CTR   OF WS-LHCE0400 |  |  |  |  | N/A | N/A |
| V697665                                     TO WS-CD-NAT-CTR |  |  |  |  | N/A | N/A |
| V               MOVE  WS-LHCE0400           TO WS-LHCE0400-AUX |  |  |  |  | N/A | N/A |
| V               MOVE  CT-05                 TO |  |  |  |  | N/A | N/A |
| V                     LHCE0400-TP-REG       OF WS-LHCE0400-AUX |  |  |  |  | N/A | N/A |
| V               MOVE  SPACES                TO |  |  |  |  | N/A | N/A |
| V                     LHCE0400-DET005       OF WS-LHCE0400-AUX(137:399) |  |  |  |  | N/A | N/A |
| V                     LHCE0400-CD-INFO-ADIC OF WS-LHCE0400-AUX |  |  |  |  | N/A | N/A |
| V                     LHCE0400-ID-INFO-ADIC OF WS-LHCE0400-AUX |  |  |  |  | N/A | N/A |
| V                     LHCE0400-TX-INFO-ADIC OF WS-LHCE0400-AUX |  |  |  |  | N/A | N/A |
| V               MOVE  ZEROS                 TO |  |  |  |  | N/A | N/A |
| V                     LHCE0400-VL-INFO-ADIC OF WS-LHCE0400-AUX |  |  |  |  | N/A | N/A |
| V                     LHCE0400-PC-INFO-ADIC OF WS-LHCE0400-AUX |  |  |  |  | N/A | N/A |
| V                     LHCE0400-QT-INFO-ADIC OF WS-LHCE0400-AUX |  |  |  |  | N/A | N/A |
| V  ||  * GUARDA EM TABELA MEMORIA TIPO SUBTIPO VINDO DA ORIGEM |  |  |  |  | N/A | N/A |
| V  ||  * SEM REPETICAO |  |  |  |  | N/A | N/A |
| V  ||       IF (LHCE0400-TP-REG OF WS-LHCE0400)     EQUAL CT-05 |  |  |  |  | N/A | N/A |
| V  ||          SET    IN-TP                     TO CT-01 |  |  |  |  | N/A | N/A |
| V  ||          SEARCH TB-GR-TIPO-SUB |  |  |  |  | N/A | N/A |
| V  ||              AT END |  |  |  |  | N/A | N/A |
| V  ||                 ADD  CT-01                TO AC-TP-QT |  |  |  |  | N/A | N/A |
| V  ||                 MOVE WS-LHCE0400(137:004) TO TB-EL-TP(AC-TP-QT) |  |  |  |  | N/A | N/A |
| V  ||            WHEN TB-EL-TP(IN-TP)        EQUAL WS-LHCE0400(137:004) |  |  |  |  | N/A | N/A |
| V  ||                 CONTINUE |  |  |  |  | N/A | N/A |
| V  ||           END-SEARCH |  |  |  |  | N/A | N/A |
| V697665     END-IF |  |  |  |  | N/A | N/A |
| V       R402-EXIT.     EXIT |  |  |  |  | N/A | N/A |
| V      *   GRAVA ARQUIVO DE OPERACOES                                  * |  |  |  |  | N/A | N/A |
| V       R500-GRAVA-S1DQ0706             SECTION |  |  |  |  | N/A | N/A |
| V           WRITE  REG-S1DQ0706 |  |  |  |  | N/A | N/A |
| V           ADD    1                     TO AC-GRAVADOS-S1 |  |  |  |  | N/A | N/A |
| V       R500-EXIT.     EXIT |  |  |  |  | N/A | N/A |
| V      *   GRAVA ARQUIVO DE REGISTROS                                  * |  |  |  |  | N/A | N/A |
| V       R510-GRAVA-S2DQ0706             SECTION |  |  |  |  | N/A | N/A |
| V697665     WRITE  REG-S2DQ0706        FROM WS-LHCE0430 |  |  |  |  | N/A | N/A |
| V           ADD    1                     TO AC-GRAVADOS-S2 |  |  |  |  | N/A | N/A |
| V       R510-EXIT.     EXIT |  |  |  |  | N/A | N/A |
| V      *  ROTINA DE FINALIZACAO                                        * |  |  |  |  | N/A | N/A |
| V       R800-FINALIZACAO                SECTION |  |  |  |  | N/A | N/A |
| V           CLOSE E1DQ0706 |  |  |  |  | N/A | N/A |
| V                 E2DQ0706 |  |  |  |  | N/A | N/A |
| V                 S1DQ0706 |  |  |  |  | N/A | N/A |
| V                 S2DQ0706 |  |  |  |  | N/A | N/A |
| V           DISPLAY '**     TERMINO DO PROGRAMA LHAN0706 OK       **' |  |  |  |  | N/A | N/A |
| V           DISPLAY '***OPERACOES***********************************' |  |  |  |  | N/A | N/A |
| V           DISPLAY '** TOT REG.LIDOS      E1DQ0706   : ' AC-LIDOS-E1 |  |  |  |  | N/A | N/A |
| V           DISPLAY '** TOT REG.GRAVADOS   S1DQ0706   : ' AC-GRAVADOS-S1 |  |  |  |  | N/A | N/A |
| V           DISPLAY '***MARCACAO************************************' |  |  |  |  | N/A | N/A |
| V           DISPLAY '** TOT REG.LIDOS      E2DQ0706   : ' AC-LIDOS-E2 |  |  |  |  | N/A | N/A |
| V           DISPLAY '** TOT REG.GRAVADOS   S2DQ0706   : ' AC-GRAVADOS-S2 |  |  |  |  | N/A | N/A |
| V           DISPLAY '***DETALHE MARCACAO****************************' |  |  |  |  | N/A | N/A |
| V           DISPLAY '** TOT REG.DESPREZADOS           : ' AC-ERRADOS-E2 |  |  |  |  | N/A | N/A |
| V           DISPLAY '** TOT REG |  |  |  |  | N/A | N/A |
| V697665     DISPLAY '** TOT REG.NATUREZA INCOMPATIVEL : ' AC-NATINCO-E2 |  |  |  |  | N/A | N/A |
| V           DISPLAY '** TOT REG.SEM CORRESPONDENTE    : ' AC-SEMCORR-E2 |  |  |  |  | N/A | N/A |
| V           DISPLAY '** TOT REG.GERADOS PELA ORIGEM   : ' AC-ORIGEM-E2 |  |  |  |  | N/A | N/A |
| V           DISPLAY '** TOT REG.INCLUIDOS             : ' AC-INCLUIDO-S1 |  |  |  |  | N/A | N/A |
| V           CALL  CT-DRAM0018          USING     PGMNAME      STCODE |  |  |  |  | N/A | N/A |
| V      * TRATAMENTO E GRAVACAO DO TATICO, DE ACORDO COM TIPO INFO. ADIC |  |  |  |  | N/A | N/A |
| V  ||  * GRAVA TIPO 01 |  |  |  |  | N/A | N/A |
| V  ||   T001-GRAVA-TIPO-01              SECTION |  |  |  |  | N/A | N/A |
| V  ||       PERFORM  U010-CD-INFO-ADIC-DATA |  |  |  |  | N/A | N/A |
| V  ||          THRU  U010-EXIT |  |  |  |  | N/A | N/A |
| V  ||       IF  LHCE0430-SB-INFO-ADIC  NOT EQUAL  CT-05 |  |  |  |  | N/A | N/A |
| V  ||           PERFORM  U020-ID-INFO-ADIC-CNPJ |  |  |  |  | N/A | N/A |
| V  ||              THRU  U020-EXIT |  |  |  |  | N/A | N/A |
| V  ||       PERFORM  U030-VL-INFO-ADIC |  |  |  |  | N/A | N/A |
| V  ||          THRU  U030-EXIT |  |  |  |  | N/A | N/A |
| V  ||       PERFORM  U040-PC-INFO-ADIC |  |  |  |  | N/A | N/A |
| V  ||          THRU  U040-EXIT |  |  |  |  | N/A | N/A |
| V  ||   T001-EXIT.     EXIT |  |  |  |  | N/A | N/A |
| V  ||  * GRAVA TIPO 02 |  |  |  |  | N/A | N/A |
| V  ||   T002-GRAVA-TIPO-02              SECTION |  |  |  |  | N/A | N/A |
| V  ||       PERFORM  U020-ID-INFO-ADIC-CNPJ |  |  |  |  | N/A | N/A |
| V  ||          THRU  U020-EXIT |  |  |  |  | N/A | N/A |
| V  ||   T002-EXIT.     EXIT |  |  |  |  | N/A | N/A |
| V  ||  * GRAVA TIPO 04 |  |  |  |  | N/A | N/A |
| V  ||   T004-GRAVA-TIPO-04              SECTION |  |  |  |  | N/A | N/A |
| V  ||  *    SUBTIPO 01: SE SITUACAO EM ID = 1, DOC EM CD = BRANCOS |  |  |  |  | N/A | N/A |
| V  ||  *    SUBTIPO 03: NAO HA DATA EM ID |  |  |  |  | N/A | N/A |
| V  ||  *    TODOS, EXCETO CONDICIONAL NO SUBTIPO 01: CODIGO EM CD |  |  |  |  | N/A | N/A |
| V  ||       EVALUATE  LHCE0430-SB-INFO-ADIC |  |  |  |  | N/A | N/A |
| V  ||           WHEN  CT-01 |  |  |  |  | N/A | N/A |
| V  ||                 IF  LHCE0430-ID1-SITUACAO      EQUAL  CT-X-1 |  |  |  |  | N/A | N/A |
| V  ||                     PERFORM  U023-ID-INFO-ADIC-SITUACAO |  |  |  |  | N/A | N/A |
| V  ||                        THRU  U023-EXIT |  |  |  |  | N/A | N/A |
| V  ||                 ELSE |  |  |  |  | N/A | N/A |
| V  ||                     PERFORM  U011-CD-INFO-ADIC-FULL |  |  |  |  | N/A | N/A |
| V  ||                        THRU  U011-EXIT |  |  |  |  | N/A | N/A |
| V  ||                 END-IF |  |  |  |  | N/A | N/A |
| V  ||           WHEN  OTHER |  |  |  |  | N/A | N/A |
| V  ||                 PERFORM U011-CD-INFO-ADIC-FULL |  |  |  |  | N/A | N/A |
| V  ||                    THRU U011-EXIT |  |  |  |  | N/A | N/A |
| V  ||                 IF  LHCE0430-SB-INFO-ADIC  NOT EQUAL  CT-03 |  |  |  |  | N/A | N/A |
| V  ||                     PERFORM  U021-ID-INFO-ADIC-DATA |  |  |  |  | N/A | N/A |
| V  ||                        THRU  U021-EXIT |  |  |  |  | N/A | N/A |
| V  ||   T004-EXIT.     EXIT |  |  |  |  | N/A | N/A |
| VSPRT04* GRAVA TIPO 06 |  |  |  |  | N/A | N/A |
| VSPRT04 T006-GRAVA-TIPO-06              SECTION |  |  |  |  | N/A | N/A |
| VSPRT04     MOVE  LHCE0430-CD-INFO-ADIC(1:2)  TO LHCE0400-ID-INFO-ADIC |  |  |  |  | N/A | N/A |
| VSPRT04                                       OF  WS-LHCE0400-AUX |  |  |  |  | N/A | N/A |
| VSPRT04     MOVE  LHCE0430-ID-INFO-ADIC(1:14)  TO LHCE0400-CD-INFO-ADIC |  |  |  |  | N/A | N/A |
| VSPRT04 T006-EXIT.     EXIT |  |  |  |  | N/A | N/A |
| V  ||  * GRAVA TIPO 07 |  |  |  |  | N/A | N/A |
| V  ||   T007-GRAVA-TIPO-07              SECTION |  |  |  |  | N/A | N/A |
| V  ||   T007-EXIT.     EXIT |  |  |  |  | N/A | N/A |
| V  ||  * GRAVA TIPO 10 |  |  |  |  | N/A | N/A |
| V  ||   T010-GRAVA-TIPO-10              SECTION |  |  |  |  | N/A | N/A |
| V  ||   T010-EXIT.     EXIT |  |  |  |  | N/A | N/A |
| V  ||  * GRAVA TIPO 11 |  |  |  |  | N/A | N/A |
| V  ||   T011-GRAVA-TIPO-11              SECTION |  |  |  |  | N/A | N/A |
| V  ||       PERFORM  U011-CD-INFO-ADIC-FULL |  |  |  |  | N/A | N/A |
| V  ||          THRU  U011-EXIT |  |  |  |  | N/A | N/A |
| V  ||   T011-EXIT.     EXIT |  |  |  |  | N/A | N/A |
| V  ||  * GRAVA TIPO 12 |  |  |  |  | N/A | N/A |
| V  ||   T012-GRAVA-TIPO-12              SECTION |  |  |  |  | N/A | N/A |
| V  ||                 PERFORM  U010-CD-INFO-ADIC-DATA |  |  |  |  | N/A | N/A |
| V  ||                    THRU  U010-EXIT |  |  |  |  | N/A | N/A |
| V  ||                 PERFORM  U022-ID-INFO-ADIC-MODSUB |  |  |  |  | N/A | N/A |
| V  ||                    THRU  U022-EXIT |  |  |  |  | N/A | N/A |
| V  ||                 PERFORM  U030-VL-INFO-ADIC |  |  |  |  | N/A | N/A |
| V  ||                    THRU  U030-EXIT |  |  |  |  | N/A | N/A |
| V  ||                 PERFORM  U040-PC-INFO-ADIC |  |  |  |  | N/A | N/A |
| V  ||                    THRU  U040-EXIT |  |  |  |  | N/A | N/A |
| V  ||           WHEN  CT-02 |  |  |  |  | N/A | N/A |
| V  ||                 PERFORM  U012-CD-INFO-ADIC-CONTR |  |  |  |  | N/A | N/A |
| V  ||                    THRU  U012-EXIT |  |  |  |  | N/A | N/A |
| V  ||           WHEN  CT-03 |  |  |  |  | N/A | N/A |
| V  ||                 PERFORM  U020-ID-INFO-ADIC-CNPJ |  |  |  |  | N/A | N/A |
| V  ||                    THRU  U020-EXIT |  |  |  |  | N/A | N/A |
| V  ||   T012-EXIT.     EXIT |  |  |  |  | N/A | N/A |
| VSPRT09* GRAVA TIPO 14 |  |  |  |  | N/A | N/A |
| VSPRT09 T014-GRAVA-TIPO-14              SECTION |  |  |  |  | N/A | N/A |
| VSPRT09     IF  LHCE0430-SB-INFO-ADIC  EQUAL  CT-08 |  |  |  |  | N/A | N/A |
| VSPRT09        MOVE  LHCE0430-ID-INFO-ADIC(1:2) TO LHCE0400-ID-INFO-ADIC |  |  |  |  | N/A | N/A |
| VSPRT09                                         OF WS-LHCE0400-AUX |  |  |  |  | N/A | N/A |
| VSPRT09     END-IF |  |  |  |  | N/A | N/A |
| VSPRT09 T014-EXIT.     EXIT |  |  |  |  | N/A | N/A |
| V  ||  * GRAVA TIPO 15 |  |  |  |  | N/A | N/A |
| V  ||   T015-GRAVA-TIPO-15              SECTION |  |  |  |  | N/A | N/A |
| V  ||  *    SE SITUACAO EM CD = 1, DOC EM ID = BRANCOS |  |  |  |  | N/A | N/A |
| V  ||       IF  LHCE0430-CD1-SITUACAO      EQUAL  CT-X-1 |  |  |  |  | N/A | N/A |
| V  ||           PERFORM  U013-CD-INFO-ADIC-SITUACAO |  |  |  |  | N/A | N/A |
| V  ||              THRU  U013-EXIT |  |  |  |  | N/A | N/A |
| V  ||   T015-EXIT.     EXIT |  |  |  |  | N/A | N/A |
| VCORBAN*---------------------------------------------------------------* |  |  |  |  | N/A | N/A |
| VCORBAN* GRAVA TIPO 16 |  |  |  |  | N/A | N/A |
| VCORBAN T016-GRAVA-TIPO-16              SECTION |  |  |  |  | N/A | N/A |
| VCORBAN |  |  |  |  | N/A | N/A |
| VCORBAN     IF  LHCE0430-ID1-TP-PES  NOT EQUAL  CT-01 AND CT-02 |  |  |  |  | N/A | N/A |
| VCORBAN         MOVE   CT-02                TO  LHCE0430-ID1-TP-PES |  |  |  |  | N/A | N/A |
| VCORBAN     END-IF |  |  |  |  | N/A | N/A |
| VCORBAN     MOVE  LHCE0430-ID1-TP-PES       TO  LHCE0400-TP-PES-CED |  |  |  |  | N/A | N/A |
| VCORBAN                                     OF  WS-LHCE0400-AUX |  |  |  |  | N/A | N/A |
| VCORBAN     MOVE  ZEROS                     TO  WS-CNPJ-ZERO |  |  |  |  | N/A | N/A |
| VCORBAN     MOVE  LHCE0430-ID1-NR-DOC       TO  WS-CNPJ-14 |  |  |  |  | N/A | N/A |
| VCORBAN     MOVE  WS-CNPJ-CORRESP-N         TO  LHCE0400-CD-CPFCNPJ-CED |  |  |  |  | N/A | N/A |
| VCORBAN* |  |  |  |  | N/A | N/A |
| VCORBAN T016-EXIT.     EXIT |  |  |  |  | N/A | N/A |
| VSPRT77* GRAVA TIPO 17 |  |  |  |  | N/A | N/A |
| VSPRT77*---------------------------------------------------------------* |  |  |  |  | N/A | N/A |
| VSPRT77 T017-GRAVA-TIPO-17              SECTION |  |  |  |  | N/A | N/A |
| VSPRT77     MOVE  LHCE0430-CD2-DATA         TO  LHCE0400-CD-INFO-ADIC |  |  |  |  | N/A | N/A |
| VSPRT77                                     OF  WS-LHCE0400-AUX |  |  |  |  | N/A | N/A |
| VSPRT77     MOVE  LHCE0430-ID1-DOC(1:2)     TO  LHCE0400-ID-INFO-ADIC |  |  |  |  | N/A | N/A |
| VSPRT77 T017-EXIT.     EXIT |  |  |  |  | N/A | N/A |
| V      * GRAVA TIPO 18 |  |  |  |  | N/A | N/A |
| V       T018-GRAVA-TIPO-18              SECTION |  |  |  |  | N/A | N/A |
| V           MOVE  LHCE0430-CD1-REFBACEN     TO  LHCE0400-CD-INFO-ADIC |  |  |  |  | N/A | N/A |
| V                                           OF  WS-LHCE0400-AUX |  |  |  |  | N/A | N/A |
| V       T018-EXIT.     EXIT |  |  |  |  | N/A | N/A |
| V      * GRAVA TIPO 19 |  |  |  |  | N/A | N/A |
| V       T019-GRAVA-TIPO-19              SECTION |  |  |  |  | N/A | N/A |
| V           IF LHCE0430-SB-INFO-ADIC  EQUAL 99 |  |  |  |  | N/A | N/A |
| V              MOVE  LHCE0430-CD1-REFBACEN TO  LHCE0400-CD-INFO-ADIC |  |  |  |  | N/A | N/A |
| V                                          OF  WS-LHCE0400-AUX |  |  |  |  | N/A | N/A |
| V       T019-EXIT.     EXIT |  |  |  |  | N/A | N/A |
| V  ||  * GRAVA TIPO 24 |  |  |  |  | N/A | N/A |
| V  ||   T024-GRAVA-TIPO-24              SECTION |  |  |  |  | N/A | N/A |
| V  ||       IF LHCE0430-SB-INFO-ADIC  EQUAL 05 OR 06 |  |  |  |  | N/A | N/A |
| V  ||          MOVE  LHCE0430-CD-INFO-ADIC(1:2) TO  LHCE0400-CD-INFO-ADIC |  |  |  |  | N/A | N/A |
| V  ||                                           OF  WS-LHCE0400-AUX |  |  |  |  | N/A | N/A |
| VSPRT74 T024-EXIT.     EXIT |  |  |  |  | N/A | N/A |
| V  ||  * MOVIMENTACOES POR CAMPO DO TATICO |  |  |  |  | N/A | N/A |
| V  ||  * FORMATO DATA NO CAMPO CD-INFO-ADIC |  |  |  |  | N/A | N/A |
| V  ||   U010-CD-INFO-ADIC-DATA          SECTION |  |  |  |  | N/A | N/A |
| V  ||       MOVE  LHCE0430-CD1-DATA         TO  LHCE0400-CD-INFO-ADIC |  |  |  |  | N/A | N/A |
| V  ||                                       OF  WS-LHCE0400-AUX |  |  |  |  | N/A | N/A |
| V  ||   U010-EXIT.     EXIT |  |  |  |  | N/A | N/A |
| V  ||  * FORMATO FULL NO CAMPO CD-INFO-ADIC |  |  |  |  | N/A | N/A |
| V  ||   U011-CD-INFO-ADIC-FULL          SECTION |  |  |  |  | N/A | N/A |
| V  ||       MOVE  LHCE0430-CD-INFO-ADIC     TO  LHCE0400-CD-INFO-ADIC |  |  |  |  | N/A | N/A |
| V  ||   U011-EXIT.     EXIT |  |  |  |  | N/A | N/A |
| V  ||  * FORMATO CONTRATO NO CAMPO CD-INFO-ADIC |  |  |  |  | N/A | N/A |
| V  ||   U012-CD-INFO-ADIC-CONTR         SECTION |  |  |  |  | N/A | N/A |
| V  ||       MOVE LHCE0430-CD1-CONTRATO      TO LHCE0400-CD-INFO-ADIC |  |  |  |  | N/A | N/A |
| V  ||                                       OF WS-LHCE0400-AUX |  |  |  |  | N/A | N/A |
| V  ||   U012-EXIT.     EXIT |  |  |  |  | N/A | N/A |
| V  ||  * FORMATO SITUACAO NO CAMPO CD-INFO-ADIC |  |  |  |  | N/A | N/A |
| V  ||   U013-CD-INFO-ADIC-SITUACAO      SECTION |  |  |  |  | N/A | N/A |
| V  ||       MOVE LHCE0430-CD1-SITUACAO      TO LHCE0400-CD-INFO-ADIC |  |  |  |  | N/A | N/A |
| V  ||   U013-EXIT.     EXIT |  |  |  |  | N/A | N/A |
| V  ||  * FORMATO DOC NO CAMPO ID-INFO-ADIC |  |  |  |  | N/A | N/A |
| V  ||   U020-ID-INFO-ADIC-CNPJ          SECTION |  |  |  |  | N/A | N/A |
| V  ||  * NO ARQUIVO TATICO NAO EH OBRIGATORIO INFORMAR TIPO DE PESSOA |  |  |  |  | N/A | N/A |
| V  ||  * POR ISSO TORNA MANDATORIO IGUAL A 02 QUANDO NAO VIER 01 NEM 02 |  |  |  |  | N/A | N/A |
| V  ||  * PORQUE ESTAH PREVISTO SOMENTE CNPJ |  |  |  |  | N/A | N/A |
| V  ||  * FUTURAMENTE, SE NO ARQUIVO TATICO VIER 01 OU 02, O CODIGO PREVE |  |  |  |  | N/A | N/A |
| V  ||  * A MOVIMENTACAO NATURALMENTE DO VALOR |  |  |  |  | N/A | N/A |
| V  ||       IF  LHCE0430-ID1-TP-PES  NOT EQUAL  CT-01 AND CT-02 |  |  |  |  | N/A | N/A |
| V  ||           MOVE   CT-02                TO  LHCE0430-ID1-TP-PES |  |  |  |  | N/A | N/A |
| V  ||       MOVE  LHCE0430-ID1-TP-PES       TO  LHCE0400-TP-PES-CED |  |  |  |  | N/A | N/A |
| V  ||       MOVE  LHCE0430-ID1-NR-DOC       TO  LHCE0400-CD-CPFCNPJ-CED |  |  |  |  | N/A | N/A |
| V  ||       IF  LHCE0430-ID1-TP-PES      EQUAL  CT-02 |  |  |  |  | N/A | N/A |
| V  ||           MOVE LHCE0430-ID2-CNPJ-RAIZ TO  LHCE0400-ID-INFO-ADIC |  |  |  |  | N/A | N/A |
| V  ||   U020-EXIT.     EXIT |  |  |  |  | N/A | N/A |
| V  ||  * FORMATO DATA NO CAMPO ID-INFO-ADIC |  |  |  |  | N/A | N/A |
| V  ||   U021-ID-INFO-ADIC-DATA          SECTION |  |  |  |  | N/A | N/A |
| V  ||       MOVE LHCE0430-ID1-DATA          TO LHCE0400-ID-INFO-ADIC |  |  |  |  | N/A | N/A |
| V  ||   U021-EXIT.     EXIT |  |  |  |  | N/A | N/A |
| V  ||  * FORMATO XXXX NO CAMPO ID-INFO-ADIC |  |  |  |  | N/A | N/A |
| V  ||   U022-ID-INFO-ADIC-MODSUB        SECTION |  |  |  |  | N/A | N/A |
| V  ||       MOVE LHCE0430-ID1-MODSUB        TO LHCE0400-ID-INFO-ADIC |  |  |  |  | N/A | N/A |
| V  ||   U022-EXIT.     EXIT |  |  |  |  | N/A | N/A |
| V  ||  * FORMATO SITUACAO NO CAMPO ID-INFO-ADIC |  |  |  |  | N/A | N/A |
| V  ||   U023-ID-INFO-ADIC-SITUACAO      SECTION |  |  |  |  | N/A | N/A |
| V  ||       MOVE LHCE0430-ID1-SITUACAO      TO LHCE0400-ID-INFO-ADIC |  |  |  |  | N/A | N/A |
| V  ||   U023-EXIT.     EXIT |  |  |  |  | N/A | N/A |
| V  ||  * FORMATO VALOR NO CAMPO VL-INFO-ADIC |  |  |  |  | N/A | N/A |
| V  ||   U030-VL-INFO-ADIC               SECTION |  |  |  |  | N/A | N/A |
| V  ||       MOVE    LHCE0430-VL-INFO-ADIC     TO  LHCE0400-VL-INFO-ADIC |  |  |  |  | N/A | N/A |
| V  ||                                         OF  WS-LHCE0400-AUX |  |  |  |  | N/A | N/A |
| V  ||       IF LHCE0430-VL-INFO-ADIC-SINAL EQUAL  CT-HIFEN |  |  |  |  | N/A | N/A |
| V  ||          COMPUTE LHCE0400-VL-INFO-ADIC  OF  WS-LHCE0400-AUX = |  |  |  |  | N/A | N/A |
| V  ||                  LHCE0430-VL-INFO-ADIC   *  -1 |  |  |  |  | N/A | N/A |
| V  ||   U030-EXIT.     EXIT |  |  |  |  | N/A | N/A |
| V  ||  * FORMATO PERCENTUAL NO CAMPO PC-INFO-ADIC |  |  |  |  | N/A | N/A |
| V  ||   U040-PC-INFO-ADIC               SECTION |  |  |  |  | N/A | N/A |
| V  ||       MOVE    LHCE0430-PC-INFO-ADIC     TO  LHCE0400-PC-INFO-ADIC |  |  |  |  | N/A | N/A |
| V  ||          COMPUTE LHCE0400-PC-INFO-ADIC  OF  WS-LHCE0400-AUX = |  |  |  |  | N/A | N/A |
| V  ||                  LHCE0430-PC-INFO-ADIC   *  -1 |  |  |  |  | N/A | N/A |
| V  ||   U040-EXIT.     EXIT |  |  |  |  | N/A | N/A |
| VMEMBER NAME  LHBR0700 |  |  |  |  | N/A | N/A |
| V       PROGRAM-ID.    LHBR0700 |  |  |  |  | N/A | N/A |
| V       AUTHOR.        MARCELLO KOJIMA - RESOURCE |  |  |  |  | N/A | N/A |
| V      *  OBJETIVO - VALIDACAO COMBINACOES DE ACORDO COM A OPCAO |  |  |  |  | N/A | N/A |
| V      *             - TIPO SUBTIPO CONTRA MODALIDADE SUBMODALIDADE |  |  |  |  | N/A | N/A |
| V      *             - TIPO SUBTIPO CONTRA NATUREZA |  |  |  |  | N/A | N/A |
| V      *  OBS |  |  |  |  | N/A | N/A |
| V      *  1) PARA OS SERVICOS 01 E 02: |  |  |  |  | N/A | N/A |
| V      *     - PRIMEIRO VERIFICA SE O TIPO E SUBTIPO DEVEM SER TRATADOS |  |  |  |  | N/A | N/A |
| V      *       - CASO NAO ESTEJA NAS LISTAS DAS TABELAS INTERNAS, TODAS |  |  |  |  | N/A | N/A |
| V      *         COMBINACOES SAO ACEITAS |  |  |  |  | N/A | N/A |
| V      *       - CASO ESTEJA, ENTAO VERIFICA SE A COMBINACAO EXISTE |  |  |  |  | N/A | N/A |
| V      *         - SE EXISTIR, ENTAO EH VALIDA |  |  |  |  | N/A | N/A |
| V      *                 A L T E R A C O E S |  |  |  |  | N/A | N/A |
| V      *--------------+----------+--------------------------------------* |  |  |  |  | N/A | N/A |
| V      *     NOME     |   DATA   |       DESCRICAO |  |  |  |  | N/A | N/A |
| 19  |MODALIDADE 1350 - ACEITAR NAT 01 |  |  |  |  | N/A | N/A |
| V1350  *              |          |MODALIDADE 1350 - ACEITAR INFO 1002 |  |  |  |  | N/A | N/A |
| V       ENVIRONMENT DIVISION |  |  |  |  | N/A | N/A |
| V       CONFIGURATION                   SECTION |  |  |  |  | N/A | N/A |
| V                            DECIMAL-POINT  IS  COMMA |  |  |  |  | N/A | N/A |
| V       DATA        DIVISION |  |  |  |  | N/A | N/A |
| V       WORKING-STORAGE                 SECTION |  |  |  |  | N/A | N/A |
| V      *--- CONSTANTES |  |  |  |  | N/A | N/A |
| V       01          CT-CONSTANTES |  |  |  |  | N/A | N/A |
| V           05      CT-LHBR0700         PIC  X(08)  VALUE 'LHBR0700' |  |  |  |  | N/A | N/A |
| V           05      CT-XX               PIC  X(02)  VALUE 'XX' |  |  |  |  | N/A | N/A |
| V           05      CT-01               PIC  9(02)  VALUE  01 |  |  |  |  | N/A | N/A |
| V           05      CT-02               PIC  9(02)  VALUE  02 |  |  |  |  | N/A | N/A |
| V           05      CT-08               PIC  9(02)  VALUE  08 |  |  |  |  | N/A | N/A |
| V           05      CT-09               PIC  9(02)  VALUE  09 |  |  |  |  | N/A | N/A |
| V           05      CT-15               PIC  9(02)  VALUE  15 |  |  |  |  | N/A | N/A |
| V           05      CT-16               PIC  9(02)  VALUE  16 |  |  |  |  | N/A | N/A |
| V           05      CT-1402             PIC  9(04)  VALUE  1402 |  |  |  |  | N/A | N/A |
| V           05      CT-1404             PIC  9(04)  VALUE  1404 |  |  |  |  | N/A | N/A |
| V           05      CT-1405             PIC  9(04)  VALUE  1405 |  |  |  |  | N/A | N/A |
| V      *--- VARIAVEIS GERAIS |  |  |  |  | N/A | N/A |
| V      *    CLONE DA AREA DE ENTRADA, BOOK LHCE0700 |  |  |  |  | N/A | N/A |
| V           03 WS-TX-ENTRADA            PIC  X(08) |  |  |  |  | N/A | N/A |
| V           03 WS-TX-OPCAO1             REDEFINES  WS-TX-ENTRADA |  |  |  |  | N/A | N/A |
| V              05 WS-TX-OP1-TIPOSUBTIPO |  |  |  |  | N/A | N/A |
| V                 07 WS-TX-OP1-TP       PIC  X(02) |  |  |  |  | N/A | N/A |
| V                 07 WS-TX-OP1-TPSUB    PIC  X(02) |  |  |  |  | N/A | N/A |
| V              05 WS-TX-OP1-MODSUBMOD |  |  |  |  | N/A | N/A |
| V                 07 WS-TX-OP1-MOD      PIC  X(02) |  |  |  |  | N/A | N/A |
| V                 07 WS-TX-OP1-MODSUB   PIC  X(02) |  |  |  |  | N/A | N/A |
| V           03 WS-TX-OPCAO2             REDEFINES  WS-TX-ENTRADA |  |  |  |  | N/A | N/A |
| V              05 WS-TX-OP2-TPSUBNAT |  |  |  |  | N/A | N/A |
| V                 07 WS-TX-OP2-TP       PIC  X(02) |  |  |  |  | N/A | N/A |
| V                 07 WS-TX-OP2-TPSUB    PIC  X(02) |  |  |  |  | N/A | N/A |
| V                 07 WS-TX-OP2-NAT      PIC  X(02) |  |  |  |  | N/A | N/A |
| V              05 FILLER                PIC  X(02) |  |  |  |  | N/A | N/A |
| V      *--- TABELA INTERNA |  |  |  |  | N/A | N/A |
| V       01 TB-TABELAS |  |  |  |  | N/A | N/A |
| V      *--- |  |  |  |  | N/A | N/A |
| V      *--- OPCAO 01: TIPO SUB CONTRA MOD |  |  |  |  | N/A | N/A |
| V      *--- OBS |  |  |  |  | N/A | N/A |
| V      *---       SERA FEITO TRATAMENTO QUANDO RECEBER LINK DO CHAMADOR |  |  |  |  | N/A | N/A |
| V           05  TB-OP1-COMB |  |  |  |  | N/A | N/A |
| V               10  FILLER |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(08) VALUE '02010404' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(08) VALUE '12011511' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(08) VALUE '12011512' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(08) VALUE '12012001' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(08) VALUE '12012002' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(08) VALUE '12031512' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(08) VALUE '14010212' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(08) VALUE '14010403' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(08) VALUE '140208XX' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(08) VALUE '14021512' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(08) VALUE '140216XX' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(08) VALUE '140408XX' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(08) VALUE '14041512' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(08) VALUE '140416XX' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(08) VALUE '140509XX' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(08) VALUE '14051350' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(08) VALUE '14051512' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(08) VALUE '140516XX' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(08) VALUE '15XX0202' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(08) VALUE '18019999' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(08) VALUE '18029999' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(08) VALUE '19019999' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(08) VALUE '19029999' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(08) VALUE '19039999' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(08) VALUE '19049999' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(08) VALUE '19989999' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(08) VALUE '19999999' |  |  |  |  | N/A | N/A |
| V           05  TB-TIPOS-VAL01  REDEFINES TB-OP1-COMB |  |  |  |  | N/A | N/A |
| V               10  TB-GR-TIPOS01 OCCURS 27 INDEXED BY IN-OPC01A |  |  |  |  | N/A | N/A |
| V                   15  TB-EL-TIPOS01       PIC X(04) |  |  |  |  | N/A | N/A |
| V                   15  FILLER              PIC X(04) |  |  |  |  | N/A | N/A |
| V           05  TB-COMB-TP-MOD  REDEFINES TB-OP1-COMB |  |  |  |  | N/A | N/A |
| V               10  TB-TIPO-MODAL OCCURS 27 INDEXED BY IN-OPC01B |  |  |  |  | N/A | N/A |
| V                   15  TB-TP-MOD           PIC X(08) |  |  |  |  | N/A | N/A |
| V      *--- OPCAO 02 - BAT 2: TIPO SUB CONTRA NATUREZA |  |  |  |  | N/A | N/A |
| V           05  TB-OP2-COMB |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(06) VALUE '010104' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(06) VALUE '010211' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(06) VALUE '010311' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(06) VALUE '010411' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(06) VALUE '010504' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(06) VALUE '070105' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(06) VALUE '070213' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(06) VALUE '070214' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(06) VALUE '070215' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(06) VALUE '070313' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(06) VALUE '070314' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(06) VALUE '070315' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(06) VALUE '070413' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(06) VALUE '070414' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(06) VALUE '070415' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(06) VALUE '070513' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(06) VALUE '070514' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(06) VALUE '070515' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(06) VALUE '070613' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(06) VALUE '070614' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(06) VALUE '070615' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(06) VALUE '070713' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(06) VALUE '070714' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(06) VALUE '070715' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(06) VALUE '100102' |  |  |  |  | N/A | N/A |
| V1350               15  FILLER PIC X(06) VALUE '100201' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(06) VALUE '100203' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(06) VALUE '100312' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(06) VALUE '100316' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(06) VALUE '121213' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(06) VALUE '121214' |  |  |  |  | N/A | N/A |
| V                   15  FILLER PIC X(06) VALUE '121215' |  |  |  |  | N/A | N/A |
| V           05  TB-TIPOS-VAL02  REDEFINES TB-OP2-COMB |  |  |  |  | N/A | N/A |
| V1350  *        10  TB-GR-TIPOS02 OCCURS 31 INDEXED BY IN-OPC02A |  |  |  |  | N/A | N/A |
| V1350           10  TB-GR-TIPOS02 OCCURS 32 INDEXED BY IN-OPC02A |  |  |  |  | N/A | N/A |
| V                   15  TB-EL-TIPOS02       PIC X(04) |  |  |  |  | N/A | N/A |
| V                   15  FILLER              PIC X(02) |  |  |  |  | N/A | N/A |
| V           05  TB-COMB-TP-NAT REDEFINES TB-OP2-COMB |  |  |  |  | N/A | N/A |
| V1350  *        10  TB-TIPO-NAT   OCCURS 31 INDEXED BY IN-OPC02B |  |  |  |  | N/A | N/A |
| V1350           10  TB-TIPO-NAT   OCCURS 32 INDEXED BY IN-OPC02B |  |  |  |  | N/A | N/A |
| V                   15  TB-TP-NAT           PIC X(06) |  |  |  |  | N/A | N/A |
| V      *--- BOOKS |  |  |  |  | N/A | N/A |
| V       LINKAGE                         SECTION |  |  |  |  | N/A | N/A |
| V       01 LI-LHCE0700 |  |  |  |  | N/A | N/A |
| V           COPY LHCE0700 |  |  |  |  | N/A | N/A |
| V       PROCEDURE DIVISION     USING    LI-LHCE0700 |  |  |  |  | N/A | N/A |
| V      *--- CONTROLE PRINCIPAL |  |  |  |  | N/A | N/A |
| V       R000-PRINCIPAL SECTION |  |  |  |  | N/A | N/A |
| V           PERFORM R100-INICIO |  |  |  |  | N/A | N/A |
| V           PERFORM R200-PROCESSA |  |  |  |  | N/A | N/A |
| V           PERFORM R300-FINAL |  |  |  |  | N/A | N/A |
| V      *--- PROCEDIMENTOS INICIAIS |  |  |  |  | N/A | N/A |
| V       R100-INICIO |  |  |  |  | N/A | N/A |
| V      *--- UNICO PONTO SETUP OK, A SEQUENCIA DECIDE QDO MUDAR ESTADO |  |  |  |  | N/A | N/A |
| V           SET   LHCE0700-CD-RET-OK   TO TRUE |  |  |  |  | N/A | N/A |
| V      *--- VALIDACAO DA OPCAO E DA AREA DE ENTRADA |  |  |  |  | N/A | N/A |
| V           EVALUATE LHCE0700-NR-OPCAO |  |  |  |  | N/A | N/A |
| V               WHEN CT-01 |  |  |  |  | N/A | N/A |
| V                    IF LHCE0700-TX-OPCAO1             NOT NUMERIC |  |  |  |  | N/A | N/A |
| V                    OR LHCE0700-TX-OPCAO1           EQUAL ZEROS |  |  |  |  | N/A | N/A |
| V                       SET     LHCE0700-CD-RET-ERR     TO TRUE |  |  |  |  | N/A | N/A |
| V                       PERFORM R300-FINAL |  |  |  |  | N/A | N/A |
| V                    END-IF |  |  |  |  | N/A | N/A |
| V               WHEN CT-02 |  |  |  |  | N/A | N/A |
| V                    IF LHCE0700-TX-OP2-TIPOSUB        NOT NUMERIC |  |  |  |  | N/A | N/A |
| V                    OR LHCE0700-TX-OP2-TIPOSUB      EQUAL ZEROS |  |  |  |  | N/A | N/A |
| V                    IF LHCE0700-TX-OP2-NAT            NOT NUMERIC |  |  |  |  | N/A | N/A |
| V                    OR LHCE0700-TX-OP2-NAT          EQUAL ZEROS |  |  |  |  | N/A | N/A |
| V               WHEN OTHER |  |  |  |  | N/A | N/A |
| V                    SET     LHCE0700-CD-RET-ERR        TO TRUE |  |  |  |  | N/A | N/A |
| V                    PERFORM R300-FINAL |  |  |  |  | N/A | N/A |
| V      *--- LINHAS GERAIS PROCESSAMENTO |  |  |  |  | N/A | N/A |
| V       R200-PROCESSA |  |  |  |  | N/A | N/A |
| V           MOVE     LHCE0700-TX-ENTRADA TO WS-TX-ENTRADA |  |  |  |  | N/A | N/A |
| V                    PERFORM R210-PROCESSA-OPCAO-01 |  |  |  |  | N/A | N/A |
| V                    PERFORM R220-PROCESSA-OPCAO-02 |  |  |  |  | N/A | N/A |
| V                    CONTINUE |  |  |  |  | N/A | N/A |
| V      *--- PROCESSA OPCAO 01 - TIPO SUBTIPO CONTRA MODAL |  |  |  |  | N/A | N/A |
| V       R210-PROCESSA-OPCAO-01 |  |  |  |  | N/A | N/A |
| V      *    TRATAMENTO PARA CONVERTER PARA "XX" QUANDO FOR ACEITO |  |  |  |  | N/A | N/A |
| V      *    QUALQUER VALOR |  |  |  |  | N/A | N/A |
| V           EVALUATE TRUE |  |  |  |  | N/A | N/A |
| V               WHEN WS-TX-OP1-TIPOSUBTIPO   EQUAL CT-1402   AND |  |  |  |  | N/A | N/A |
| V                    WS-TX-OP1-MOD           EQUAL CT-08 |  |  |  |  | N/A | N/A |
| V                    WS-TX-OP1-MOD           EQUAL CT-16 |  |  |  |  | N/A | N/A |
| V               WHEN WS-TX-OP1-TIPOSUBTIPO   EQUAL CT-1404   AND |  |  |  |  | N/A | N/A |
| V               WHEN WS-TX-OP1-TIPOSUBTIPO   EQUAL CT-1405   AND |  |  |  |  | N/A | N/A |
| V                    WS-TX-OP1-MOD           EQUAL CT-09 |  |  |  |  | N/A | N/A |
| V                    MOVE   CT-XX               TO WS-TX-OP1-MODSUB |  |  |  |  | N/A | N/A |
| V               WHEN WS-TX-OP1-TP            EQUAL CT-15 |  |  |  |  | N/A | N/A |
| V                    MOVE   CT-XX               TO WS-TX-OP1-TPSUB |  |  |  |  | N/A | N/A |
| V      *    SE ENCONTRAR TIPO NA LISTA "A", VERIFICA SE A COMBINACAO COM |  |  |  |  | N/A | N/A |
| V      *    MODALIDADE EH VALIDA NA LISTA "B" |  |  |  |  | N/A | N/A |
| V           SET    IN-OPC01A   TO   CT-01 |  |  |  |  | N/A | N/A |
| V+---->     SEARCH TB-GR-TIPOS01 |  |  |  |  | N/A | N/A |
| V| |  |  |  |  | N/A | N/A |
| V|              AT END |  |  |  |  | N/A | N/A |
| V|                 CONTINUE |  |  |  |  | N/A | N/A |
| V|            WHEN TB-EL-TIPOS01(IN-OPC01A) EQUAL WS-TX-OP1-TIPOSUBTIPO |  |  |  |  | N/A | N/A |
| V|                 SET    IN-OPC01B   TO   CT-01 |  |  |  |  | N/A | N/A |
| V| +-->            SEARCH TB-TIPO-MODAL |  |  |  |  | N/A | N/A |
| V| | |  |  |  |  | N/A | N/A |
| V| |                   AT END |  |  |  |  | N/A | N/A |
| V| |                      SET     LHCE0700-CD-RET-NOK  TO  TRUE |  |  |  |  | N/A | N/A |
| V| |                 WHEN TB-TP-MOD(IN-OPC01B) EQUAL WS-TX-OPCAO1 |  |  |  |  | N/A | N/A |
| V| |                      CONTINUE |  |  |  |  | N/A | N/A |
| V| +-->            END-SEARCH |  |  |  |  | N/A | N/A |
| V+---->     END-SEARCH |  |  |  |  | N/A | N/A |
| V      *--- PROCESSA OPCAO 02 - TIPO SUBTIPO CONTRA NATUREZA |  |  |  |  | N/A | N/A |
| V       R220-PROCESSA-OPCAO-02 |  |  |  |  | N/A | N/A |
| V      *    NATUREZA EH VALIDA NA LISTA "B" |  |  |  |  | N/A | N/A |
| V           SET    IN-OPC02A   TO   CT-01 |  |  |  |  | N/A | N/A |
| V+---->     SEARCH TB-GR-TIPOS02 |  |  |  |  | N/A | N/A |
| V|            WHEN TB-EL-TIPOS02(IN-OPC02A)  EQUAL WS-TX-OP1-TIPOSUBTIPO |  |  |  |  | N/A | N/A |
| V|                 SET    IN-OPC02B   TO   CT-01 |  |  |  |  | N/A | N/A |
| V| +-->            SEARCH TB-TIPO-NAT |  |  |  |  | N/A | N/A |
| V| |                 WHEN TB-TP-NAT(IN-OPC02B) EQUAL WS-TX-OP2-TPSUBNAT |  |  |  |  | N/A | N/A |
| V       R300-FINAL |  |  |  |  | N/A | N/A |
| VMEMBER NAME  MZAN6056 |  |  |  |  | N/A | N/A |
| V       PROGRAM-ID.    MZAN6056 |  |  |  |  | N/A | N/A |
| V      * OBJETIVOS DO PROGRAMA:                                         * |  |  |  |  | N/A | N/A |
| V      *    - RECUPERAR INFORMACOES DA OPERACAO NO MQ12 DO MES ANTERIOR * |  |  |  |  | N/A | N/A |
| V      * ALTERACOES:                                                    * |  |  |  |  | N/A | N/A |
| V      * -------------------------------------------------------------- * |  |  |  |  | N/A | N/A |
| V      * AUTOR       DATA        OBJETIVO                               * |  |  |  |  | N/A | N/A |
| 2014  ACERTO ERRO FINANCEIRA                 * |  |  |  |  | N/A | N/A |
| 2014  CAMPOS NOVOS FLUXO FINANCEIRO          * |  |  |  |  | N/A | N/A |
| 2015  INCLUSAO DA INTERFACE MP, NA           * |  |  |  |  | N/A | N/A |
| VVS002 *                         RECUPERACAO DE INFORMACOES NO MQ12 |  |  |  |  | N/A | N/A |
| V      *----------------------------------------------------------------- |  |  |  |  | N/A | N/A |
| VNVRGAC*                                                                * |  |  |  |  | N/A | N/A |
| 15   VECTOR        PROJETO NOVAS REGRAS DE ACORDO          * |  |  |  |  | N/A | N/A |
| VNVRGAC*                        INCLUSAO DE NOVAS VARIAVEIS NO BOOK |  |  |  |  | N/A | N/A |
| VNVRGAC*                        MZCE5113, AUMENTANDO SEU TAMANHO PARA   * |  |  |  |  | N/A | N/A |
| VNVRGAC*                        1600 BYTES |  |  |  |  | N/A | N/A |
| VNVRGAC*                        ESTE PROGRAMA NAO FOI ALTERADO          * |  |  |  |  | N/A | N/A |
| VNVRGAC*                        EFETUAMOS APENAS UMA COMPILACAO PARA    * |  |  |  |  | N/A | N/A |
| VNVRGAC*                        INCORPORAR A NOVA VERSAO DO BOOK        * |  |  |  |  | N/A | N/A |
| VNVRGAC*                        MZCE5113 |  |  |  |  | N/A | N/A |
| 2016  RECOMPIL MZCE5113                      * |  |  |  |  | N/A | N/A |
| 2016  ALTERAR "MP" PARA M1, M3, M4 E M5      * |  |  |  |  | N/A | N/A |
| 2018  ACERTO RATING REFERENCIA DO LY         * |  |  |  |  | N/A | N/A |
| 2019  INCLUSAO DO CAMPO DE PARCELAS PAGAS    * |  |  |  |  | N/A | N/A |
| VSPRT28*                         DO MES ANTERIOR                        * |  |  |  |  | N/A | N/A |
| 2019  NAO CANCELAR POR AQUIVO VAZIO          * |  |  |  |  | N/A | N/A |
| 2019  RATING MES ANTERIOR AJUSTADO           * |  |  |  |  | N/A | N/A |
| 2019  EXPANSAO DO BOOK 6001                  * |  |  |  |  | N/A | N/A |
| 2021  AUDITORIA DO GR                        * |  |  |  |  | N/A | N/A |
| 2021  INCLUSAO DA NOVA SIGLA MP06 (M6)       * |  |  |  |  | N/A | N/A |
| 2025  INCLUSAO PLARD ON01 - O1               * |  |  |  |  | N/A | N/A |
| V       CONFIGURATION SECTION |  |  |  |  | N/A | N/A |
| V           DECIMAL-POINT  IS  COMMA |  |  |  |  | N/A | N/A |
| V       INPUT-OUTPUT SECTION |  |  |  |  | N/A | N/A |
| V           SELECT E1DQ6056 ASSIGN E1DQ6056 |  |  |  |  | N/A | N/A |
| V           SELECT E2DQ6056 ASSIGN E2DQ6056 |  |  |  |  | N/A | N/A |
| V           SELECT S1DQ6056 ASSIGN S1DQ6056 |  |  |  |  | N/A | N/A |
| V       DATA DIVISION |  |  |  |  | N/A | N/A |
| V       FD  E1DQ6056 |  |  |  |  | N/A | N/A |
| V           LABEL RECORD           STANDARD |  |  |  |  | N/A | N/A |
| V           BLOCK                  0 RECORDS |  |  |  |  | N/A | N/A |
| V           RECORDING MODE         F |  |  |  |  | N/A | N/A |
| V       01        REG-E1DQ6056 |  |  |  |  | N/A | N/A |
| V       ++INCLUDE MZCE6001 |  |  |  |  | N/A | N/A |
| V       FD  E2DQ6056 |  |  |  |  | N/A | N/A |
| V       01        REG-E2DQ6056 |  |  |  |  | N/A | N/A |
| V       ++INCLUDE MZCE5113 |  |  |  |  | N/A | N/A |
| V       FD  S1DQ6056 |  |  |  |  | N/A | N/A |
| VCMP04  01          REG-S1DQ6056        PIC  X(2000) |  |  |  |  | N/A | N/A |
| V       WORKING-STORAGE SECTION |  |  |  |  | N/A | N/A |
| V       77          AC-LIDOS-E1DQ6056   PIC  9(10)  VALUE  ZEROS |  |  |  |  | N/A | N/A |
| V       77          AC-LIDOS-E2DQ6056   PIC  9(10)  VALUE  ZEROS |  |  |  |  | N/A | N/A |
| V       77          AC-GRAVADOS         PIC  9(10)  VALUE  ZEROS |  |  |  |  | N/A | N/A |
| V       01          WS-CHAVE-E1DQ6056 |  |  |  |  | N/A | N/A |
| V         03        WS-NRO-OPR-6001     PIC  X(33) |  |  |  |  | N/A | N/A |
| V         03        WS-CD-HB-6001       PIC  9(04) |  |  |  |  | N/A | N/A |
| V         03        WS-CD-SIS-6001      PIC  X(02) |  |  |  |  | N/A | N/A |
| V         03        WS-CD-EMP-6001      PIC  9(04) |  |  |  |  | N/A | N/A |
| V      *  03        WS-ST-ACD-6001      PIC  9(01) |  |  |  |  | N/A | N/A |
| V       01          WS-CHAVE-E2DQ6056 |  |  |  |  | N/A | N/A |
| V         03        WS-NRO-OPR-5113     PIC  X(33) |  |  |  |  | N/A | N/A |
| V         03        WS-CD-HB-5113       PIC  9(04) |  |  |  |  | N/A | N/A |
| V         03        WS-CD-SIS-5113      PIC  X(02) |  |  |  |  | N/A | N/A |
| V         03        WS-CD-EMP-5113      PIC  9(04) |  |  |  |  | N/A | N/A |
| V      *  03        WS-ST-ACD-5113      PIC  9(01) |  |  |  |  | N/A | N/A |
| V       01          FILLER  REDEFINES  WS-DT-ACORDO-MZ13 |  |  |  |  | N/A | N/A |
| V         03        WS-MES-ACO-MZ13     PIC  9(02) |  |  |  |  | N/A | N/A |
| V         03        WS-DIA-ACO-MZ13     PIC  9(02) |  |  |  |  | N/A | N/A |
| V         03        WS-ANO-ACO-MZ13     PIC  9(04) |  |  |  |  | N/A | N/A |
| V       01          WS-DT-ACORDO        PIC  9(08) |  |  |  |  | N/A | N/A |
| V       01          FILLER  REDEFINES  WS-DT-ACORDO |  |  |  |  | N/A | N/A |
| V         03        WS-ANO-ACORDO       PIC  9(04) |  |  |  |  | N/A | N/A |
| V         03        WS-MES-ACORDO       PIC  9(02) |  |  |  |  | N/A | N/A |
| V         03        WS-DIA-ACORDO       PIC  9(02) |  |  |  |  | N/A | N/A |
| V       PROCEDURE DIVISION |  |  |  |  | N/A | N/A |
| V      *           M  O  D  U  L  O         M  E  S  T  R  E            * |  |  |  |  | N/A | N/A |
| V       000-00-MODULO-MESTRE  SECTION |  |  |  |  | N/A | N/A |
| V           PERFORM  800-00-INICIALIZA |  |  |  |  | N/A | N/A |
| V           PERFORM  100-00-PROCESSAMENTO |  |  |  |  | N/A | N/A |
| V               UNTIL  WS-CHAVE-E1DQ6056  EQUAL HIGH-VALUES |  |  |  |  | N/A | N/A |
| V           PERFORM  700-00-FINALIZA |  |  |  |  | N/A | N/A |
| V       000-99-FIM |  |  |  |  | N/A | N/A |
| V           EXIT |  |  |  |  | N/A | N/A |
| V           EJECT |  |  |  |  | N/A | N/A |
| V      *             P  R  O  C  E  S  S  A  M  E  N  T  O              * |  |  |  |  | N/A | N/A |
| V       100-00-PROCESSAMENTO  SECTION |  |  |  |  | N/A | N/A |
| VVS003      IF  CD-SIS-ORI-6001        EQUAL  'LY' OR 'M1' OR 'M3' |  |  |  |  | N/A | N/A |
| VVS003                                             OR 'M4' OR 'M5' |  |  |  |  | N/A | N/A |
| VCMP05                                             OR 'GR' OR 'M6' |  |  |  |  | N/A | N/A |
| VPLARD                                             OR 'O1' |  |  |  |  | N/A | N/A |
| V               IF  WS-CHAVE-E1DQ6056  EQUAL  WS-CHAVE-E2DQ6056 |  |  |  |  | N/A | N/A |
| V                   PERFORM  110-00-MOVER-CAMPOS |  |  |  |  | N/A | N/A |
| V                   PERFORM  500-00-GRAVA-S1DQ6056 |  |  |  |  | N/A | N/A |
| V                   PERFORM  610-00-LE-E1DQ6056 |  |  |  |  | N/A | N/A |
| V                   PERFORM  620-00-LE-E2DQ6056 |  |  |  |  | N/A | N/A |
| V                   IF  WS-CHAVE-E1DQ6056  LESS  WS-CHAVE-E2DQ6056 |  |  |  |  | N/A | N/A |
| V                       PERFORM  120-00-ZERAR-CAMPOS |  |  |  |  | N/A | N/A |
| V                       PERFORM  500-00-GRAVA-S1DQ6056 |  |  |  |  | N/A | N/A |
| V                       PERFORM  610-00-LE-E1DQ6056 |  |  |  |  | N/A | N/A |
| V                   ELSE |  |  |  |  | N/A | N/A |
| V                       PERFORM  620-00-LE-E2DQ6056 |  |  |  |  | N/A | N/A |
| V                   END-IF |  |  |  |  | N/A | N/A |
| V               PERFORM  120-00-ZERAR-CAMPOS |  |  |  |  | N/A | N/A |
| V               PERFORM  500-00-GRAVA-S1DQ6056 |  |  |  |  | N/A | N/A |
| V               PERFORM  610-00-LE-E1DQ6056 |  |  |  |  | N/A | N/A |
| V       100-99-EXIT |  |  |  |  | N/A | N/A |
| V      * MOVIMENTAR CAMPOS DO MQ12 MES-ANT PARA O MOVIMENTO ATUAL       * |  |  |  |  | N/A | N/A |
| V       110-00-MOVER-CAMPOS   SECTION |  |  |  |  | N/A | N/A |
| V           MOVE  QT-DIA-ATR-MZ13    TO QT-ATR-ACO-MES-ANT-6001 |  |  |  |  | N/A | N/A |
| V           MOVE  PC-AMO-RENEG-MZ13  TO PC-PAG-ACO-MES-ANT-6001 |  |  |  |  | N/A | N/A |
| V           MOVE  IN-ACORDO-MZ13     TO ST-ACD-MES-ANT-6001 |  |  |  |  | N/A | N/A |
| VSPRT28     MOVE  QT-PARC-PAG-ACD-MZ13 TO PAR-PAG-ACD-MES-ANT-6001 |  |  |  |  | N/A | N/A |
| VCMP05      MOVE  CD-RGR-RAT-OPE-MZ13  TO CD-RGR-RAT-OPE-ANT-6001 |  |  |  |  | N/A | N/A |
| V           MOVE  DT-ACORDO-MZ13     TO WS-DT-ACORDO-MZ13 |  |  |  |  | N/A | N/A |
| V           MOVE  WS-DIA-ACO-MZ13    TO WS-DIA-ACORDO |  |  |  |  | N/A | N/A |
| V           MOVE  WS-MES-ACO-MZ13    TO WS-MES-ACORDO |  |  |  |  | N/A | N/A |
| V           MOVE  WS-ANO-ACO-MZ13    TO WS-ANO-ACORDO |  |  |  |  | N/A | N/A |
| V           IF    WS-DT-ACORDO    EQUAL DT-ACO-6001  AND |  |  |  |  | N/A | N/A |
| VCMP02           (CD-RAT-REFER-MZ13 NOT LESS 01      AND |  |  |  |  | N/A | N/A |
| VCMP02            CD-RAT-REFER-MZ13 NOT GREATER 09) |  |  |  |  | N/A | N/A |
| V                 MOVE 'S'               TO  IN-MSM-ACO-6001 |  |  |  |  | N/A | N/A |
| V                 MOVE CD-RAT-REFER-MZ13 TO  CD-RAT-REF-6001 |  |  |  |  | N/A | N/A |
| V                 MOVE 'N'               TO  IN-MSM-ACO-6001 |  |  |  |  | N/A | N/A |
| V                 EVALUATE CD-RAT-CAC-MZ13 |  |  |  |  | N/A | N/A |
| V                     WHEN 'AA' |  |  |  |  | N/A | N/A |
| V                          MOVE 09       TO  CD-RAT-REF-6001 |  |  |  |  | N/A | N/A |
| V                     WHEN 'A ' |  |  |  |  | N/A | N/A |
| V                          MOVE 08       TO  CD-RAT-REF-6001 |  |  |  |  | N/A | N/A |
| V                     WHEN 'B ' |  |  |  |  | N/A | N/A |
| V                          MOVE 07       TO  CD-RAT-REF-6001 |  |  |  |  | N/A | N/A |
| V                     WHEN 'C ' |  |  |  |  | N/A | N/A |
| V                          MOVE 06       TO  CD-RAT-REF-6001 |  |  |  |  | N/A | N/A |
| V                     WHEN 'D ' |  |  |  |  | N/A | N/A |
| V                          MOVE 05       TO  CD-RAT-REF-6001 |  |  |  |  | N/A | N/A |
| V                     WHEN 'E ' |  |  |  |  | N/A | N/A |
| V                          MOVE 04       TO  CD-RAT-REF-6001 |  |  |  |  | N/A | N/A |
| V                     WHEN 'F ' |  |  |  |  | N/A | N/A |
| V                          MOVE 03       TO  CD-RAT-REF-6001 |  |  |  |  | N/A | N/A |
| V                     WHEN 'G ' |  |  |  |  | N/A | N/A |
| V                          MOVE 02       TO  CD-RAT-REF-6001 |  |  |  |  | N/A | N/A |
| V                     WHEN 'H ' |  |  |  |  | N/A | N/A |
| V                          MOVE 01       TO  CD-RAT-REF-6001 |  |  |  |  | N/A | N/A |
| V                     WHEN    OTHER |  |  |  |  | N/A | N/A |
| V                 END-EVALUATE |  |  |  |  | N/A | N/A |
| V           PERFORM  630-00-CONVERTE-RATING |  |  |  |  | N/A | N/A |
| V       110-99-EXIT |  |  |  |  | N/A | N/A |
| V      * INICIALIZA CAMPOS DO MQ12 MES-ANT PARA O MOVIMENTO ATUAL       * |  |  |  |  | N/A | N/A |
| V       120-00-ZERAR-CAMPOS   SECTION |  |  |  |  | N/A | N/A |
| VCMP01      IF  CD-CLF-MESANT-6001   EQUAL ZEROS |  |  |  |  | N/A | N/A |
| VCMP01          MOVE  99             TO CD-CLF-MESANT-6001 |  |  |  |  | N/A | N/A |
| VCMP01      END-IF |  |  |  |  | N/A | N/A |
| V           MOVE  ZEROS              TO QT-ATR-ACO-MES-ANT-6001 |  |  |  |  | N/A | N/A |
| V                                       PC-PAG-ACO-MES-ANT-6001 |  |  |  |  | N/A | N/A |
| V                                       ST-ACD-MES-ANT-6001 |  |  |  |  | N/A | N/A |
| V                                       PAR-PAG-ACD-MES-ANT-6001 |  |  |  |  | N/A | N/A |
| VCMP05      MOVE  SPACES             TO CD-RGR-RAT-OPE-ANT-6001 |  |  |  |  | N/A | N/A |
| VCMP05      IF  CD-SIS-ORI-6001  EQUAL  'GR'  AND |  |  |  |  | N/A | N/A |
| VCMP05          CD-TIP-NEG-6001  NOT EQUAL  ZEROS |  |  |  |  | N/A | N/A |
| VCMP05          MOVE  05             TO CD-CLF-MESANT-6001 |  |  |  |  | N/A | N/A |
| VCMP05                                  CD-RAT-REF-6001 |  |  |  |  | N/A | N/A |
| VCMP05      END-IF |  |  |  |  | N/A | N/A |
| V           IF  CD-SIS-ORI-6001  EQUAL  'LY' |  |  |  |  | N/A | N/A |
| V               MOVE  05                 TO CD-RAT-REF-6001 |  |  |  |  | N/A | N/A |
| V       120-99-EXIT |  |  |  |  | N/A | N/A |
| V      *               ROTINA  DE  GRAVACAO  DO  ARQUIVO                * |  |  |  |  | N/A | N/A |
| V       500-00-GRAVA-S1DQ6056  SECTION |  |  |  |  | N/A | N/A |
| V           WRITE  REG-S1DQ6056  FROM  REG-E1DQ6056 |  |  |  |  | N/A | N/A |
| V           ADD  1  TO  AC-GRAVADOS |  |  |  |  | N/A | N/A |
| V       500-99-EXIT |  |  |  |  | N/A | N/A |
| V      *            ROTINA  DE  LEITURA  DO  ARQUIVO  DE INTERFACE      * |  |  |  |  | N/A | N/A |
| V       610-00-LE-E1DQ6056  SECTION |  |  |  |  | N/A | N/A |
| V           READ  E1DQ6056 |  |  |  |  | N/A | N/A |
| V               AT  END  MOVE  HIGH-VALUES  TO  WS-CHAVE-E1DQ6056 |  |  |  |  | N/A | N/A |
| V           IF WS-CHAVE-E1DQ6056 NOT EQUAL HIGH-VALUES |  |  |  |  | N/A | N/A |
| V              ADD   1                 TO  AC-LIDOS-E1DQ6056 |  |  |  |  | N/A | N/A |
| V              MOVE  NR-OPR-6001       TO  WS-NRO-OPR-6001 |  |  |  |  | N/A | N/A |
| V              MOVE  CD-HB-6001        TO  WS-CD-HB-6001 |  |  |  |  | N/A | N/A |
| V              MOVE  CD-SIS-ORI-6001   TO  WS-CD-SIS-6001 |  |  |  |  | N/A | N/A |
| V              MOVE  CD-EMP-6001       TO  WS-CD-EMP-6001 |  |  |  |  | N/A | N/A |
| V      *       MOVE  ST-ACD-6001       TO  WS-ST-ACD-6001 |  |  |  |  | N/A | N/A |
| V       610-99-EXIT |  |  |  |  | N/A | N/A |
| V      *            ROTINA  DE  LEITURA  DO  ARQUIVO  DO  MZ            * |  |  |  |  | N/A | N/A |
| V       620-00-LE-E2DQ6056 SECTION |  |  |  |  | N/A | N/A |
| V           READ  E2DQ6056 |  |  |  |  | N/A | N/A |
| V               AT  END  MOVE  HIGH-VALUES  TO  WS-CHAVE-E2DQ6056 |  |  |  |  | N/A | N/A |
| V           IF   WS-CHAVE-E2DQ6056 NOT EQUAL HIGH-VALUES |  |  |  |  | N/A | N/A |
| V                ADD        1            TO  AC-LIDOS-E2DQ6056 |  |  |  |  | N/A | N/A |
| V                MOVE  CD-OPR-CDT-MZ13   TO  WS-NRO-OPR-5113 |  |  |  |  | N/A | N/A |
| V                MOVE  CD-PS-MZ13        TO  WS-CD-HB-5113 |  |  |  |  | N/A | N/A |
| V                MOVE  CD-SIS-MZ13       TO  WS-CD-SIS-5113 |  |  |  |  | N/A | N/A |
| V                MOVE  CD-EMP-MZ13       TO  WS-CD-EMP-5113 |  |  |  |  | N/A | N/A |
| V      *         MOVE  IN-ACORDO-MZ13    TO  WS-ST-ACD-5113 |  |  |  |  | N/A | N/A |
| V       620-99-EXIT |  |  |  |  | N/A | N/A |
| V      *    CONVERTER RATING DE ALFA NUMERICO PARA NUMERICO             * |  |  |  |  | N/A | N/A |
| V       630-00-CONVERTE-RATING  SECTION |  |  |  |  | N/A | N/A |
| VCMP03      IF  CD-RAT-OPER-AJUSTADO-MZ13          EQUAL 'AA' |  |  |  |  | N/A | N/A |
| VCMP03 *    IF  CD-CLF-OPR-MZ13  EQUAL 'AA' |  |  |  |  | N/A | N/A |
| V               MOVE 09                            TO CD-CLF-MESANT-6001 |  |  |  |  | N/A | N/A |
| VCMP03       IF CD-RAT-OPER-AJUSTADO-MZ13          EQUAL 'A ' |  |  |  |  | N/A | N/A |
| V               MOVE 08                            TO CD-CLF-MESANT-6001 |  |  |  |  | N/A | N/A |
| V            ELSE |  |  |  |  | N/A | N/A |
| VCMP03        IF CD-RAT-OPER-AJUSTADO-MZ13         EQUAL 'B ' |  |  |  |  | N/A | N/A |
| V                MOVE 07                           TO CD-CLF-MESANT-6001 |  |  |  |  | N/A | N/A |
| V             ELSE |  |  |  |  | N/A | N/A |
| VCMP03         IF CD-RAT-OPER-AJUSTADO-MZ13        EQUAL 'C ' |  |  |  |  | N/A | N/A |
| V                 MOVE 06                          TO CD-CLF-MESANT-6001 |  |  |  |  | N/A | N/A |
| VCMP03          IF CD-RAT-OPER-AJUSTADO-MZ13       EQUAL 'D ' |  |  |  |  | N/A | N/A |
| V                  MOVE 05                         TO CD-CLF-MESANT-6001 |  |  |  |  | N/A | N/A |
| VCMP03           IF CD-RAT-OPER-AJUSTADO-MZ13      EQUAL 'E ' |  |  |  |  | N/A | N/A |
| V                   MOVE 04                        TO CD-CLF-MESANT-6001 |  |  |  |  | N/A | N/A |
| V                ELSE |  |  |  |  | N/A | N/A |
| VCMP03              IF CD-RAT-OPER-AJUSTADO-MZ13   EQUAL 'F ' |  |  |  |  | N/A | N/A |
| V                      MOVE 03                     TO CD-CLF-MESANT-6001 |  |  |  |  | N/A | N/A |
| VCMP03               IF CD-RAT-OPER-AJUSTADO-MZ13  EQUAL 'G ' |  |  |  |  | N/A | N/A |
| V                       MOVE 02                    TO CD-CLF-MESANT-6001 |  |  |  |  | N/A | N/A |
| V                    ELSE |  |  |  |  | N/A | N/A |
| VCMP03                IF CD-RAT-OPER-AJUSTADO-MZ13 EQUAL 'H ' |  |  |  |  | N/A | N/A |
| V                        MOVE 01         TO CD-CLF-MESANT-6001 |  |  |  |  | N/A | N/A |
| V                     ELSE |  |  |  |  | N/A | N/A |
| V                        MOVE 99         TO CD-CLF-MESANT-6001 |  |  |  |  | N/A | N/A |
| V                     END-IF |  |  |  |  | N/A | N/A |
| V             END-IF |  |  |  |  | N/A | N/A |
| V            END-IF |  |  |  |  | N/A | N/A |
| VCMP05      IF  CD-SIS-ORI-6001               EQUAL  'GR'  AND |  |  |  |  | N/A | N/A |
| VCMP05          CD-TIP-NEG-6001           NOT EQUAL  ZEROS |  |  |  |  | N/A | N/A |
| VCMP05          IF  DT-REN-CTR-6001(1:6)  NOT EQUAL  DT-BSE-6001(1:6) |  |  |  |  | N/A | N/A |
| VCMP05              EVALUATE CD-RAT-CAC-MZ13 |  |  |  |  | N/A | N/A |
| VCMP05                WHEN 'AA' |  |  |  |  | N/A | N/A |
| VCMP05                      MOVE 09       TO  CD-CLF-MESANT-6001 |  |  |  |  | N/A | N/A |
| VCMP05                WHEN 'A ' |  |  |  |  | N/A | N/A |
| VCMP05                      MOVE 08       TO  CD-CLF-MESANT-6001 |  |  |  |  | N/A | N/A |
| VCMP05                WHEN 'B ' |  |  |  |  | N/A | N/A |
| VCMP05                      MOVE 07       TO  CD-CLF-MESANT-6001 |  |  |  |  | N/A | N/A |
| VCMP05                WHEN 'C ' |  |  |  |  | N/A | N/A |
| VCMP05                      MOVE 06       TO  CD-CLF-MESANT-6001 |  |  |  |  | N/A | N/A |
| VCMP05                WHEN 'D ' |  |  |  |  | N/A | N/A |
| VCMP05                      MOVE 05       TO  CD-CLF-MESANT-6001 |  |  |  |  | N/A | N/A |
| VCMP05                WHEN 'E ' |  |  |  |  | N/A | N/A |
| VCMP05                      MOVE 04       TO  CD-CLF-MESANT-6001 |  |  |  |  | N/A | N/A |
| VCMP05                WHEN 'F ' |  |  |  |  | N/A | N/A |
| VCMP05                      MOVE 03       TO  CD-CLF-MESANT-6001 |  |  |  |  | N/A | N/A |
| VCMP05                WHEN 'G ' |  |  |  |  | N/A | N/A |
| VCMP05                      MOVE 02       TO  CD-CLF-MESANT-6001 |  |  |  |  | N/A | N/A |
| VCMP05                WHEN 'H ' |  |  |  |  | N/A | N/A |
| VCMP05                      MOVE 01       TO  CD-CLF-MESANT-6001 |  |  |  |  | N/A | N/A |
| VCMP05                WHEN    OTHER |  |  |  |  | N/A | N/A |
| VCMP05                      MOVE 99       TO  CD-CLF-MESANT-6001 |  |  |  |  | N/A | N/A |
| VCMP05              END-IF |  |  |  |  | N/A | N/A |
| V       630-99-EXIT |  |  |  |  | N/A | N/A |
| V      *           F   I   N   A   L   I   Z   A   C   A   O            * |  |  |  |  | N/A | N/A |
| V       700-00-FINALIZA  SECTION |  |  |  |  | N/A | N/A |
| V           CLOSE  E1DQ6056 |  |  |  |  | N/A | N/A |
| V                  E2DQ6056 |  |  |  |  | N/A | N/A |
| V                  S1DQ6056 |  |  |  |  | N/A | N/A |
| V           DISPLAY '*********************************************' |  |  |  |  | N/A | N/A |
| V           DISPLAY 'REGISTROS LIDOS E1DQ6056 .... |  |  |  |  | N/A | N/A |
| V           DISPLAY 'REGISTROS LIDOS E2DQ6056 .... |  |  |  |  | N/A | N/A |
| V           DISPLAY 'REGISTROS GRAVADOS .......... |  |  |  |  | N/A | N/A |
| V           DISPLAY '*** PROGRAMA MZAN6055 ***' |  |  |  |  | N/A | N/A |
| V           DISPLAY '***  TERMINO  NORMAL  ***' |  |  |  |  | N/A | N/A |
| V           DISPLAY '*************************' |  |  |  |  | N/A | N/A |
| V           STOP RUN |  |  |  |  | N/A | N/A |
| V       700-99-EXIT |  |  |  |  | N/A | N/A |
| V      *       I   N   I   C   I   A   L   I   Z   A   C   A   O        * |  |  |  |  | N/A | N/A |
| V       800-00-INICIALIZA  SECTION |  |  |  |  | N/A | N/A |
| V           DISPLAY '*         PROGRAMA  MZAN6056         *' |  |  |  |  | N/A | N/A |
| V           OPEN  INPUT   E1DQ6056 |  |  |  |  | N/A | N/A |
| V                         E2DQ6056 |  |  |  |  | N/A | N/A |
| V                 OUTPUT  S1DQ6056 |  |  |  |  | N/A | N/A |
| V           PERFORM  610-00-LE-E1DQ6056 |  |  |  |  | N/A | N/A |
| V           IF  WS-CHAVE-E1DQ6056 EQUAL HIGH-VALUES |  |  |  |  | N/A | N/A |
| V               DISPLAY  '*********************************' |  |  |  |  | N/A | N/A |
| V               DISPLAY  '**  A  T  E  N  C  A  O  !  !  **' |  |  |  |  | N/A | N/A |
| V               DISPLAY  'ARQUIVO E1DQ6056 VAZIO' |  |  |  |  | N/A | N/A |
| V               DISPLAY  '*********************' |  |  |  |  | N/A | N/A |
| V               DISPLAY  '* PROGRAMA MZAN6055 *' |  |  |  |  | N/A | N/A |
| VSPRT31         DISPLAY  '*  TERMINO  NORMAL  *' |  |  |  |  | N/A | N/A |
| VSPRT31         PERFORM  700-00-FINALIZA |  |  |  |  | N/A | N/A |
| VSPRT31*        PERFORM  900-00-FIM-ANORMAL |  |  |  |  | N/A | N/A |
| V           PERFORM  620-00-LE-E2DQ6056 |  |  |  |  | N/A | N/A |
| V           IF  WS-CHAVE-E2DQ6056 EQUAL HIGH-VALUES |  |  |  |  | N/A | N/A |
| V               DISPLAY  'ARQUIVO E2DQ6056 VAZIO' |  |  |  |  | N/A | N/A |
| V               DISPLAY  '* PROGRAMA MZAN6056 *' |  |  |  |  | N/A | N/A |
| V               DISPLAY  '*  TERMINO ANORMAL  *' |  |  |  |  | N/A | N/A |
| V               PERFORM  900-00-FIM-ANORMAL |  |  |  |  | N/A | N/A |
| V       800-99-FIM |  |  |  |  | N/A | N/A |
| V      *   T   E   R   M   I   N   O        A   N   O   R   M   A   L   * |  |  |  |  | N/A | N/A |
| V       900-00-FIM-ANORMAL SECTION |  |  |  |  | N/A | N/A |
| V           STOP  RUN |  |  |  |  | N/A | N/A |
| V       900-99-EXIT |  |  |  |  | N/A | N/A |
| LHAN0542 |  |  |  |  | 104,796 | 1278 |
| LHAN0705 |  |  |  |  | 120,539 | 1470 |
| LHAN0706 |  |  |  |  | 99,793 | 1217 |
| LHBR0700 |  |  |  |  | 29,683 | 362 |
| MZAN6056 |  |  |  |  | 42,803 | 522 |


---

## Recomendações

### Ações Imediatas Necessárias

 **Verificar Arquivos Não Encontrados:** Confirmar se os caminhos dos arquivos estão corretos
🤖 **Completar Análise:** Executar análise dos programas pendentes
 **Melhorar Completude:** Atual 0.0% - Meta: 100%


### Próximos Passos

1. **Resolver Problemas Identificados:** Corrigir programas com erro ou não processados
2. **Validar Dependências:** Verificar se todas as dependências estão corretas
3. **Completar Processamento:** Garantir que todos os programas sejam documentados
4. **Monitoramento Contínuo:** Implementar verificações regulares de completude

---

**Relatório gerado automaticamente pelo COBOL AI Engine v2.0.0**  
**Para questões técnicas, consulte a equipe de desenvolvimento**
