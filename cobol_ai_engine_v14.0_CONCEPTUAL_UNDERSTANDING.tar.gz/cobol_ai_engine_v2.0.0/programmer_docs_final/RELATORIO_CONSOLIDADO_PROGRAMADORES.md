# Relatório Consolidado - Documentação para Programadores

**Data de Geração:** 17/09/2025 15:46:42
**Versão do Sistema:** COBOL AI Engine v2.2.1 Programmer Documentation
**Provider Utilizado:** luzia
**Linguagem Alvo:** java
**Foco em Migração:** Sim
**Análise de Problemas:** Sim

## 📊 Estatísticas Gerais

- **Programas Analisados:** 5
- **Documentações Geradas:** 0/5
- **Taxa de Sucesso:** 0.0%
- **Total de Tokens Utilizados:** 0

## 📋 Resumo por Programa

| Programa | Status | Tokens | Regras de Negócio | Documentação |
|----------|--------|--------|-------------------|-------------|
| LHAN0542 | ❌ Falha | 0 | 0 | N/A |
| LHAN0705 | ❌ Falha | 0 | 0 | N/A |
| LHAN0706 | ❌ Falha | 0 | 0 | N/A |
| LHBR0700 | ❌ Falha | 0 | 0 | N/A |
| MZAN6056 | ❌ Falha | 0 | 0 | N/A |

## 📖 Detalhes por Programa

### LHAN0542

**Status:** ❌ Falha na geração da documentação

- **Erro:** Falha na análise para programadores

---

### LHAN0705

**Status:** ❌ Falha na geração da documentação

- **Erro:** Falha na análise para programadores

---

### LHAN0706

**Status:** ❌ Falha na geração da documentação

- **Erro:** Falha na análise para programadores

---

### LHBR0700

**Status:** ❌ Falha na geração da documentação

- **Erro:** Falha na análise para programadores

---

### MZAN6056

**Status:** ❌ Falha na geração da documentação

- **Erro:** Falha na análise para programadores

---

## 🚀 Como Usar Esta Documentação

### Para Programadores COBOL:
- Use a documentação para entender melhor o código existente
- Identifique oportunidades de refatoração e melhoria
- Compreenda o contexto de negócio por trás do código

### Para Programadores de Outras Linguagens:
- Foque nas seções de mapeamento para linguagens modernas
- Use os exemplos de implementação como ponto de partida
- Consulte o guia de migração para estratégias de conversão

### Para Arquitetos de Software:
- Analise as dependências e integrações identificadas
- Use as recomendações estratégicas para planejamento
- Considere os aspectos de compliance e regulamentação

## ⚙️ Configurações da Análise

- **Provider Primário:** luzia
- **Max Tokens:** 8000
- **Temperature:** 0.02
- **Modelo:** aws-claude-3-5-sonnet
- **Arquivo de Configuração:** config/config_unified_enhanced_docs.yaml

---

*Documentação gerada automaticamente pelo COBOL AI Engine v2.2.1*
*Especializado em documentação técnica para programadores*
