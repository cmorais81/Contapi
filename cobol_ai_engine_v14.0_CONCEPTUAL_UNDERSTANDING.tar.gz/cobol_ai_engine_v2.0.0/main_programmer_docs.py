#!/usr/bin/env python3.11
# -*- coding: utf-8 -*-
"""
COBOL AI Engine v2.2.1 - Documentação para Programadores
Sistema especializado em criar documentação compreensível para desenvolvedores

Autor: Manus AI
Data: 17 de Setembro de 2025
"""

import argparse
import logging
import os
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

# Adicionar o diretório src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.core.config import ConfigManager
from src.core.exceptions import COBOLAIEngineException, ProviderError
from src.core.token_manager import TokenManager
from src.parsers.cobol_parser import COBOLParser
from src.providers.provider_manager import ProviderManager
from src.analyzers.cobol_code_analyzer import COBOLCodeAnalyzer
from src.generators.programmer_documentation_generator import ProgrammerDocumentationGenerator
from src.utils.pdf_converter import MarkdownToPDFConverter
from src.providers.base_provider import AIRequest

def setup_logging(log_level: str = "INFO") -> None:
    """Configurar logging do sistema"""
    logging.basicConfig(
        level=getattr(logging, log_level.upper()),
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler('logs/cobol_programmer_docs.log', 'a', encoding='utf-8')
        ]
    )
    
    # Criar diretório de logs se não existir
    os.makedirs('logs', exist_ok=True)

def parse_arguments() -> argparse.Namespace:
    """Parse dos argumentos da linha de comando"""
    parser = argparse.ArgumentParser(
        description='COBOL AI Engine v2.2.1 - Documentação para Programadores',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Exemplos de uso:

  # Documentação para programadores
  python main_programmer_docs.py --fontes examples/fontes.txt --books examples/BOOKS.txt

  # Documentação com foco em migração
  python main_programmer_docs.py --fontes examples/fontes.txt --migration-focus

  # Documentação com análise de problemas
  python main_programmer_docs.py --fontes examples/fontes.txt --include-problems

  # Documentação completa com todos os recursos
  python main_programmer_docs.py --fontes examples/fontes.txt --books examples/BOOKS.txt --migration-focus --include-problems --target-language java
        """
    )
    
    parser.add_argument(
        '--fontes', 
        required=True,
        help='Arquivo contendo lista de programas COBOL para análise'
    )
    
    parser.add_argument(
        '--books', 
        help='Arquivo contendo lista de copybooks COBOL (opcional)'
    )
    
    parser.add_argument(
        '--config',
        default='config/config_unified_enhanced_docs.yaml',
        help='Arquivo de configuração YAML (padrão: config/config_unified_enhanced_docs.yaml)'
    )
    
    parser.add_argument(
        '--output',
        default='programmer_docs',
        help='Diretório de saída para a documentação (padrão: programmer_docs)'
    )
    
    parser.add_argument(
        '--target-language',
        choices=['java', 'python', 'csharp', 'javascript', 'all'],
        default='java',
        help='Linguagem alvo para exemplos de migração (padrão: java)'
    )
    
    parser.add_argument(
        '--migration-focus',
        action='store_true',
        help='Focar na documentação para migração de sistemas'
    )
    
    parser.add_argument(
        '--include-problems',
        action='store_true',
        help='Incluir análise detalhada de problemas no código'
    )
    
    parser.add_argument(
        '--detailed-comments',
        action='store_true',
        help='Incluir análise detalhada de todos os comentários do código'
    )
    
    parser.add_argument(
        '--log-level',
        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'],
        default='INFO',
        help='Nível de logging (padrão: INFO)'
    )
    
    parser.add_argument(
        '--no-pdf',
        action='store_true',
        help='Desabilitar geração de HTML para PDF'
    )
    
    parser.add_argument(
        '--version',
        action='version',
        version='COBOL AI Engine v2.2.1 - Documentação para Programadores'
    )
    
    return parser.parse_args()

def create_enhanced_pre_analysis_context(program_name: str, business_comments: List[str], 
                                        business_rules: List, copybooks: List[str],
                                        args: argparse.Namespace) -> str:
    """Criar contexto de pré-análise aprimorado para documentação de programadores"""
    context_parts = []
    
    # Cabeçalho com foco em programadores
    context_parts.append("=== CONTEXTO PARA DOCUMENTAÇÃO DE PROGRAMADORES ===")
    context_parts.append(f"PROGRAMA: {program_name}")
    context_parts.append(f"OBJETIVO: Documentação compreensível para desenvolvedores")
    context_parts.append(f"LINGUAGEM ALVO: {args.target_language}")
    
    if args.migration_focus:
        context_parts.append("FOCO ESPECIAL: Migração de sistemas")
    
    if args.include_problems:
        context_parts.append("ANÁLISE ESPECIAL: Identificação de problemas no código")
    
    context_parts.append("")
    
    # Comentários de negócio com contexto
    if business_comments:
        context_parts.append(f"COMENTÁRIOS ORIGINAIS DO CÓDIGO ({len(business_comments)} encontrados):")
        for i, comment in enumerate(business_comments[:10], 1):  # Máximo 10 comentários
            context_parts.append(f"  {i}. {comment}")
        if len(business_comments) > 10:
            context_parts.append(f"  ... e mais {len(business_comments) - 10} comentários")
    else:
        context_parts.append("COMENTÁRIOS ORIGINAIS: Nenhum comentário significativo encontrado")
    
    context_parts.append("")
    
    # Regras de negócio identificadas com categorização
    if business_rules:
        context_parts.append(f"REGRAS DE NEGÓCIO PRÉ-IDENTIFICADAS ({len(business_rules)} regras):")
        
        # Agrupar por tipo
        rule_types = {}
        for rule in business_rules:
            rule_type = getattr(rule, 'rule_type', 'Geral')
            if rule_type not in rule_types:
                rule_types[rule_type] = []
            rule_types[rule_type].append(rule)
        
        for rule_type, rules in rule_types.items():
            context_parts.append(f"  - {rule_type}: {len(rules)} regras")
            # Adicionar exemplos das primeiras regras
            for rule in rules[:2]:  # Máximo 2 exemplos por tipo
                description = getattr(rule, 'description', 'Regra identificada')
                context_parts.append(f"    * {description}")
    else:
        context_parts.append("REGRAS DE NEGÓCIO: Serão identificadas durante a análise")
    
    context_parts.append("")
    
    # Copybooks relacionados
    if copybooks:
        context_parts.append(f"COPYBOOKS RELACIONADOS ({len(copybooks)} identificados):")
        for copybook in copybooks[:15]:  # Máximo 15 copybooks
            context_parts.append(f"  - {copybook}")
        if len(copybooks) > 15:
            context_parts.append(f"  ... e mais {len(copybooks) - 15} copybooks")
    else:
        context_parts.append("COPYBOOKS: Nenhum copybook relacionado identificado")
    
    context_parts.append("")
    context_parts.append("=== INSTRUÇÕES ESPECIAIS PARA ANÁLISE ===")
    context_parts.append("1. FOQUE na compreensão da lógica para programadores")
    context_parts.append("2. EXPLIQUE como reimplementar em linguagens modernas")
    context_parts.append("3. IDENTIFIQUE problemas e oportunidades de melhoria")
    context_parts.append("4. MAPEIE todas as estruturas de dados e fluxos")
    context_parts.append("5. DOCUMENTE regras de negócio de forma clara")
    
    return "\n".join(context_parts)

def analyze_program_for_programmers(program_name: str, program_code: str, 
                                  provider_manager: ProviderManager, config: Dict,
                                  pre_analysis_context: str, args: argparse.Namespace) -> Tuple[Optional[str], int]:
    """Realizar análise focada em documentação para programadores"""
    try:
        logging.info(f"Iniciando análise para programadores: {program_name}")
        
        # Obter prompts da configuração
        system_prompt = config.get('prompts', {}).get('system_prompts', {}).get('comprehensive_cobol_documentation', '')
        user_template = config.get('prompts', {}).get('user_prompts', {}).get('comprehensive_documentation', '')
        
        # Se não encontrou os prompts específicos, usar fallback
        if not system_prompt:
            system_prompt = """
Você é um ARQUITETO DE SOFTWARE SÊNIOR especializado em documentação técnica para programadores.

Crie documentação EXTREMAMENTE DETALHADA que permita a qualquer desenvolvedor:
1. COMPREENDER COMPLETAMENTE o que o programa faz
2. IDENTIFICAR a lógica de negócio implementada  
3. DETECTAR problemas e oportunidades de melhoria
4. REESCREVER o programa em linguagens modernas
5. ENTENDER o contexto de negócio

FOQUE em explicar COMO e PORQUÊ o código funciona, não apenas O QUE ele faz.
Use exemplos práticos e mapeamentos para linguagens modernas.
Identifique padrões, anti-padrões e oportunidades de melhoria.
"""
        
        if not user_template:
            user_template = """
Analise o seguinte programa COBOL e crie documentação completa para programadores:

PROGRAMA: {program_name}

CONTEXTO DE PRÉ-ANÁLISE:
{pre_analysis_context}

CÓDIGO COBOL:
{program_code}

INSTRUÇÕES:
1. Explique a lógica de forma que qualquer programador possa entender
2. Mapeie estruturas COBOL para linguagens modernas
3. Identifique regras de negócio e como implementá-las
4. Aponte problemas e oportunidades de melhoria
5. Forneça exemplos práticos de reimplementação
"""
        
        # Preparar prompt do usuário
        try:
            user_prompt = user_template.format(
                program_name=program_name,
                pre_analysis_context=pre_analysis_context,
                program_code=program_code
            )
        except KeyError as e:
            # Se o template tem variáveis não disponíveis, usar template simplificado
            user_prompt = f"""
Analise o seguinte programa COBOL e crie documentação completa para programadores:

PROGRAMA: {program_name}

CONTEXTO DE PRÉ-ANÁLISE:
{pre_analysis_context}

CÓDIGO COBOL:
{program_code}

INSTRUÇÕES:
1. Explique a lógica de forma que qualquer programador possa entender
2. Mapeie estruturas COBOL para linguagens modernas
3. Identifique regras de negócio e como implementá-las
4. Aponte problemas e oportunidades de melhoria
5. Forneça exemplos práticos de reimplementação
"""
        
        # Criar requisição (incluir system prompt no user prompt)
        full_prompt = f"{system_prompt}\n\n{user_prompt}"
        
        request = AIRequest(
            prompt=full_prompt,
            max_tokens=config.get('ai', {}).get('global_max_tokens', 8000),
            temperature=config.get('ai', {}).get('providers', {}).get('luzia', {}).get('temperature', 0.02)
        )
        
        # Executar análise usando o sistema de fallback
        response = provider_manager.analyze(request)
        
        if response and response.success and response.content:
            token_count = response.tokens_used if hasattr(response, 'tokens_used') else len(response.content.split())
            logging.info(f"Análise para programadores concluída: {program_name} - {len(response.content)} caracteres")
            return response.content, token_count
        else:
            error_msg = getattr(response, 'error_message', 'Resposta vazia') if response else 'Sem resposta'
            logging.warning(f"Falha na análise de {program_name}: {error_msg}")
            return None, 0
            
    except Exception as e:
        logging.error(f"Erro na análise para programadores de {program_name}: {e}")
        return None, 0

def generate_programmer_documentation(program_name: str, analysis_result: str, 
                                    business_rules: List, output_dir: str,
                                    args: argparse.Namespace) -> bool:
    """Gerar documentação específica para programadores"""
    try:
        doc_generator = ProgrammerDocumentationGenerator()
        
        # Preparar dados para documentação
        analysis_data = {
            'program_name': program_name,
            'analysis_content': analysis_result,
            'business_rules': business_rules,
            'timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
            'version': 'v2.2.1 Programmer Documentation',
            'target_language': args.target_language,
            'migration_focus': args.migration_focus,
            'include_problems': args.include_problems,
            'detailed_comments': args.detailed_comments
        }
        
        # Gerar documentação
        doc_path = os.path.join(output_dir, f"{program_name}_PROGRAMMER_DOCS.md")
        success = doc_generator.generate_programmer_documentation(analysis_data, doc_path)
        
        if success:
            logging.info(f"Documentação para programadores gerada: {doc_path}")
        
        return success
        
    except Exception as e:
        logging.error(f"Erro ao gerar documentação para programadores de {program_name}: {e}")
        return False

def generate_consolidated_programmer_report(results: Dict, output_dir: str, 
                                          config: Dict, args: argparse.Namespace) -> str:
    """Gerar relatório consolidado para programadores"""
    try:
        report_path = os.path.join(output_dir, "RELATORIO_CONSOLIDADO_PROGRAMADORES.md")
        
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write("# Relatório Consolidado - Documentação para Programadores\n\n")
            f.write(f"**Data de Geração:** {time.strftime('%d/%m/%Y %H:%M:%S')}\n")
            f.write(f"**Versão do Sistema:** COBOL AI Engine v2.2.1 Programmer Documentation\n")
            f.write(f"**Provider Utilizado:** {config.get('ai', {}).get('primary_provider', 'N/A')}\n")
            f.write(f"**Linguagem Alvo:** {args.target_language}\n")
            f.write(f"**Foco em Migração:** {'Sim' if args.migration_focus else 'Não'}\n")
            f.write(f"**Análise de Problemas:** {'Sim' if args.include_problems else 'Não'}\n\n")
            
            # Estatísticas gerais
            total_programs = len(results)
            successful_analyses = sum(1 for r in results.values() if r.get('success', False))
            total_tokens = sum(r.get('tokens', 0) for r in results.values())
            
            f.write("## 📊 Estatísticas Gerais\n\n")
            f.write(f"- **Programas Analisados:** {total_programs}\n")
            f.write(f"- **Documentações Geradas:** {successful_analyses}/{total_programs}\n")
            f.write(f"- **Taxa de Sucesso:** {(successful_analyses/total_programs*100):.1f}%\n")
            f.write(f"- **Total de Tokens Utilizados:** {total_tokens:,}\n\n")
            
            # Resumo por programa
            f.write("## 📋 Resumo por Programa\n\n")
            f.write("| Programa | Status | Tokens | Regras de Negócio | Documentação |\n")
            f.write("|----------|--------|--------|-------------------|-------------|\n")
            
            for program_name, result in results.items():
                status = "✅ Sucesso" if result.get('success', False) else "❌ Falha"
                tokens = f"{result.get('tokens', 0):,}"
                rules_count = result.get('business_rules_count', 0)
                doc_link = f"[{program_name}_PROGRAMMER_DOCS.md](./{program_name}_PROGRAMMER_DOCS.md)" if result.get('success') else "N/A"
                
                f.write(f"| {program_name} | {status} | {tokens} | {rules_count} | {doc_link} |\n")
            
            f.write("\n")
            
            # Detalhes por programa
            f.write("## 📖 Detalhes por Programa\n\n")
            for program_name, result in results.items():
                f.write(f"### {program_name}\n\n")
                if result.get('success', False):
                    f.write("**Status:** ✅ Documentação gerada com sucesso\n\n")
                    f.write(f"- **Tokens Utilizados:** {result.get('tokens', 0):,}\n")
                    f.write(f"- **Regras de Negócio Identificadas:** {result.get('business_rules_count', 0)}\n")
                    f.write(f"- **Arquivo de Documentação:** `{program_name}_PROGRAMMER_DOCS.md`\n")
                    
                    if result.get('analysis_preview'):
                        f.write(f"- **Preview da Análise:**\n")
                        f.write(f"  > {result['analysis_preview'][:300]}...\n")
                else:
                    f.write("**Status:** ❌ Falha na geração da documentação\n\n")
                    if result.get('error'):
                        f.write(f"- **Erro:** {result['error']}\n")
                
                f.write("\n---\n\n")
            
            # Guia de uso
            f.write("## 🚀 Como Usar Esta Documentação\n\n")
            f.write("### Para Programadores COBOL:\n")
            f.write("- Use a documentação para entender melhor o código existente\n")
            f.write("- Identifique oportunidades de refatoração e melhoria\n")
            f.write("- Compreenda o contexto de negócio por trás do código\n\n")
            
            f.write("### Para Programadores de Outras Linguagens:\n")
            f.write("- Foque nas seções de mapeamento para linguagens modernas\n")
            f.write("- Use os exemplos de implementação como ponto de partida\n")
            f.write("- Consulte o guia de migração para estratégias de conversão\n\n")
            
            f.write("### Para Arquitetos de Software:\n")
            f.write("- Analise as dependências e integrações identificadas\n")
            f.write("- Use as recomendações estratégicas para planejamento\n")
            f.write("- Considere os aspectos de compliance e regulamentação\n\n")
            
            # Configurações utilizadas
            f.write("## ⚙️ Configurações da Análise\n\n")
            f.write(f"- **Provider Primário:** {config.get('ai', {}).get('primary_provider', 'N/A')}\n")
            f.write(f"- **Max Tokens:** {config.get('ai', {}).get('global_max_tokens', 'N/A')}\n")
            f.write(f"- **Temperature:** {config.get('ai', {}).get('providers', {}).get('luzia', {}).get('temperature', 'N/A')}\n")
            f.write(f"- **Modelo:** {config.get('ai', {}).get('providers', {}).get('luzia', {}).get('model', 'N/A')}\n")
            f.write(f"- **Arquivo de Configuração:** {args.config}\n\n")
            
            f.write("---\n\n")
            f.write("*Documentação gerada automaticamente pelo COBOL AI Engine v2.2.1*\n")
            f.write("*Especializado em documentação técnica para programadores*\n")
            
        logging.info(f"Relatório consolidado para programadores gerado: {report_path}")
        return report_path
        
    except Exception as e:
        logging.error(f"Erro ao gerar relatório consolidado para programadores: {e}")
        return ""

def main():
    """Função principal"""
    try:
        # Parse dos argumentos
        args = parse_arguments()
        
        # Setup do logging
        setup_logging(args.log_level)
        
        logging.info("=== INICIANDO COBOL AI ENGINE v2.2.1 - DOCUMENTAÇÃO PARA PROGRAMADORES ===")
        logging.info(f"Configuração: {args.config}")
        logging.info(f"Fontes: {args.fontes}")
        logging.info(f"Saída: {args.output}")
        logging.info(f"Linguagem Alvo: {args.target_language}")
        logging.info(f"Foco em Migração: {args.migration_focus}")
        logging.info(f"Análise de Problemas: {args.include_problems}")
        
        # Carregar configuração
        config_manager = ConfigManager(args.config)
        config = config_manager.get_config()
        
        # Criar diretório de saída
        os.makedirs(args.output, exist_ok=True)
        
        # Inicializar componentes
        token_manager = TokenManager(config)
        provider_manager = ProviderManager(config)
        parser = COBOLParser()
        analyzer = COBOLCodeAnalyzer()
        
        # Carregar lista de programas
        logging.info(f"Carregando programas de: {args.fontes}")
        programs, _ = parser.parse_file(args.fontes)
        logging.info(f"Programas identificados: {len(programs)}")
        
        # Carregar copybooks se especificado
        copybooks = []
        if args.books:
            logging.info(f"Carregando copybooks de: {args.books}")
            _, copybooks = parser.parse_file(args.books)
            logging.info(f"Copybooks identificados: {len(copybooks)}")
        
        # Processar cada programa
        results = {}
        start_time = time.time()
        
        for i, program in enumerate(programs, 1):
            program_name = program.name if hasattr(program, 'name') else f'programa_{i}'
            program_code = program.content if hasattr(program, 'content') else ''
            
            logging.info(f"Analisando programa {i}/{len(programs)}: {program_name}")
            
            try:
                # Pré-análise
                logging.info(f"Iniciando pré-análise de {program_name}")
                analysis_result = analyzer.analyze_program(program_code, program_name)
                comments_obj = getattr(analysis_result, 'comments', None)
                business_comments = getattr(comments_obj, 'business_comments', []) if comments_obj else []
                business_rules = getattr(analysis_result, 'business_rules', [])
                logging.info(f"Pré-análise concluída: {len(business_comments)} comentários, {len(business_rules)} regras")
                
                # Criar contexto de pré-análise aprimorado
                pre_analysis_context = create_enhanced_pre_analysis_context(
                    program_name, business_comments, business_rules, 
                    [cb.name if hasattr(cb, 'name') else '' for cb in copybooks],
                    args
                )
                
                # Análise para programadores
                analysis_content, tokens_used = analyze_program_for_programmers(
                    program_name, program_code, provider_manager, config, 
                    pre_analysis_context, args
                )
                
                if analysis_content:
                    # Gerar documentação para programadores
                    doc_success = generate_programmer_documentation(
                        program_name, analysis_content, business_rules, args.output, args
                    )
                    
                    results[program_name] = {
                        'success': True,
                        'tokens': tokens_used,
                        'business_rules_count': len(business_rules),
                        'analysis_preview': analysis_content[:500] if analysis_content else '',
                        'documentation_generated': doc_success
                    }
                else:
                    results[program_name] = {
                        'success': False,
                        'error': 'Falha na análise para programadores',
                        'tokens': 0
                    }
                    
            except Exception as e:
                logging.error(f"Erro na análise de {program_name}: {e}")
                results[program_name] = {
                    'success': False,
                    'error': str(e),
                    'tokens': 0
                }
        
        # Gerar relatório consolidado
        logging.info("Gerando relatório consolidado para programadores...")
        report_path = generate_consolidated_programmer_report(results, args.output, config, args)
        
        # Gerar HTML se solicitado
        if not args.no_pdf and report_path:
            try:
                pdf_converter = MarkdownToPDFConverter()
                html_path = report_path.replace('.md', '.html')
                pdf_converter.convert_to_pdf(report_path, html_path)
                logging.info(f"HTML para impressão gerado: {html_path}")
            except Exception as e:
                logging.warning(f"Erro ao gerar HTML: {e}")
        
        # Estatísticas finais
        end_time = time.time()
        total_time = end_time - start_time
        successful_analyses = sum(1 for r in results.values() if r.get('success', False))
        total_tokens = sum(r.get('tokens', 0) for r in results.values())
        
        logging.info("=== DOCUMENTAÇÃO PARA PROGRAMADORES CONCLUÍDA ===")
        logging.info(f"Programas processados: {len(programs)}")
        logging.info(f"Documentações geradas: {successful_analyses}/{len(programs)}")
        logging.info(f"Taxa de sucesso: {(successful_analyses/len(programs)*100):.1f}%")
        logging.info(f"Total de tokens utilizados: {total_tokens:,}")
        logging.info(f"Tempo de processamento: {total_time:.2f}s")
        logging.info(f"Arquivos gerados em: {args.output}")
        
        # Imprimir estatísticas no console
        print("\n" + "="*60)
        print("=== DOCUMENTAÇÃO PARA PROGRAMADORES CONCLUÍDA ===")
        print(f"Programas processados: {len(programs)}")
        print(f"Documentações geradas: {successful_analyses}/{len(programs)}")
        print(f"Taxa de sucesso: {(successful_analyses/len(programs)*100):.1f}%")
        print(f"Total de tokens utilizados: {total_tokens:,}")
        print(f"Tempo de processamento: {total_time:.2f}s")
        print(f"Linguagem alvo: {args.target_language}")
        print(f"Arquivos gerados em: {args.output}")
        print("="*60)
        
        return 0 if successful_analyses > 0 else 1
        
    except KeyboardInterrupt:
        logging.info("Análise interrompida pelo usuário")
        return 1
    except Exception as e:
        logging.error(f"Erro fatal: {e}")
        return 1

if __name__ == "__main__":
    sys.exit(main())
