# Relatório Consolidado de Análise COBOL

**Data de Geração**: 17/09/2025 10:03:04
**Versão do Sistema**: COBOL AI Engine v2.1.5

## Resumo Executivo da Análise

### Componentes Analisados
- **Total de Programas COBOL:** 5
- **Total de Copybooks:** 0
- **Total de Componentes:** 5
- **Linhas de Código Total:** 4,849 linhas
- **Tamanho Total:** 397,614 caracteres

### Resultados da Análise
- **Análises Bem-sucedidas:** 5/5
- **Taxa de Sucesso:** 100.0%
- **Análises com Falha:** 0
- **Total de Tokens Utilizados:** 43,344
- **Tempo Total de Processamento:** 0.61 segundos
- **Eficiência:** 71046 tokens/segundo

## Detalhamento por Componente

### Programas COBOL Analisados
1. **LHAN0542**
   - Linhas de código: 1278
   - Tamanho: 104796 caracteres
   - Complexidade: Alta
   - Status: Análise pendente

2. **LHAN0705**
   - Linhas de código: 1470
   - Tamanho: 120539 caracteres
   - Complexidade: Alta
   - Status: Análise pendente

3. **LHAN0706**
   - Linhas de código: 1217
   - Tamanho: 99793 caracteres
   - Complexidade: Alta
   - Status: Análise pendente

4. **LHBR0700**
   - Linhas de código: 362
   - Tamanho: 29683 caracteres
   - Complexidade: Média
   - Status: Análise pendente

5. **MZAN6056**
   - Linhas de código: 522
   - Tamanho: 42803 caracteres
   - Complexidade: Alta
   - Status: Análise pendente

### Copybooks Analisados
Nenhum copybook foi analisado nesta execução.

## Estatísticas Detalhadas

### Distribuição por Complexidade

#### Programas COBOL
- **Alta Complexidade (>500 linhas):** 4 programas
- **Média Complexidade (100-500 linhas):** 1 programas
- **Baixa Complexidade (<100 linhas):** 0 programas

#### Copybooks
- **Alta Complexidade (>200 linhas):** 0 copybooks
- **Média Complexidade (50-200 linhas):** 0 copybooks
- **Baixa Complexidade (<50 linhas):** 0 copybooks

### Métricas de Qualidade
- **Densidade Média de Documentação:** 0.0%
- **Tamanho Médio de Programa:** 970 linhas
- **Tamanho Médio de Copybook:** 0 linhas

### Eficiência do Processamento
- **Tokens por Componente:** 8669 tokens/componente
- **Tempo por Componente:** 0.12 segundos/componente
- **Throughput:** 5000.0 componentes/hora

## Recomendações e Próximos Passos

### Componentes Prioritários para Revisão
- **Programas de Alta Complexidade:** LHAN0542, LHAN0705, LHAN0706, MZAN6056

### Oportunidades de Melhoria
- Componentes com baixa documentação podem se beneficiar de comentários adicionais
- Programas de alta complexidade podem ser candidatos a refatoração
- Copybooks extensos podem ser divididos em módulos menores

### Considerações para Manutenção
- Estabelecer padrões de documentação baseados na análise realizada
- Implementar revisões periódicas dos componentes identificados como críticos
- Considerar modernização gradual dos componentes mais complexos

---
**Relatório gerado automaticamente pelo COBOL AI Engine v1.3.0**
**Sistema de Análise Inteligente de Programas COBOL**
**Data de Geração:** 17/09/2025 às 10:03:04
**Escopo:** Análise Consolidada Completa


## Informações Detalhadas dos Prompts Utilizados

### Configuração de Prompts
- **System Prompt Utilizado:** config/prompts.yaml
- **Tamanho do System Prompt:** 2014 caracteres
- **Provedor Principal:** token_managed
- **Modelos Utilizados:** multi_part_analysis

### Estatísticas de Prompts
- **Total de Prompts Enviados:** 5
- **Tamanho Médio dos Prompts:** 161264 caracteres
- **Maior Prompt:** 243297 caracteres
- **Menor Prompt:** 61585 caracteres

### System Prompt Utilizado
```
Você é um especialista em análise de código COBOL com mais de 20 anos de experiência em sistemas mainframe e regulamentação bancária.
Responda todas as perguntas em português brasileiro de forma clara, técnica e detalhada.

FOQUE ESPECIALMENTE NA EXTRAÇÃO DE REGRAS DE NEGÓCIO DETALHADAS:

1. ANALISE COMENTÁRIOS E DESCRIÇÕES:
   - Examine todos os comentários no código (linhas com * ou C)
   - Identifique descrições de funcionalidades nos comentários
   - Extraia regras regulatórias mencionadas (ex: "APLICAÇÃO REGULATÓRIA", "CUMPRIMENTO DE DIRECIONAMENTO")
   - Capture referências a leis, normas e regulamentações (ex: "LEI 13990", "PROGRAMA NACIONAL DE APOIO")
   - Documente operações específicas mencionadas (ex: "OPERAÇÕES CONTRATADAS NO ÂMBITO DO PRONAMPE")

2. IDENTIFIQUE REGRAS DE NEGÓCIO EM:
   - Estruturas de dados (WORKING-STORAGE, FILE SECTION)
   - Condições IF/WHEN/EVALUATE
   - Cálculos e fórmulas
   - Validações de campos
   - Códigos de retorno e mensagens de erro
   - Tabelas de decisão e parâmetros

3. EXTRAIA INFORMAÇÕES REGULATÓRIAS:
   - Tipos de operações financeiras
   - Códigos de produtos e serviços
   - Limites e percentuais regulatórios
   - Classificações de risco
   - Direcionamentos obrigatórios
   - Exigibilidades e provisões

4. DOCUMENTE FLUXOS DE NEGÓCIO:
   - Sequência de processamento
   - Pontos de decisão críticos
   - Tratamento de exceções
   - Integrações com outros sistemas
   - Geração de relatórios regulatórios

Analise o código fornecido identificando:
- Estrutura e organização do programa
- Lógica de negócio implementada COM DETALHES ESPECÍFICOS
- Regras regulatórias e de compliance
- Dependências e relacionamentos
- Pontos críticos e considerações técnicas
- Fluxo de dados e processamento
- Códigos de produtos, operações e classificações

Seja direto e objetivo nas explicações, sem usar formatação especial.
Organize a resposta de forma estruturada e fácil de entender.
SEMPRE inclua as regras de negócio específicas encontradas no código.

```

### Exemplo de Prompt de Análise
```
Analise o seguinte programa COBOL:
Nome do programa: LHAN0705
Timestamp: 2025-09-17 10:03:04

Código do programa:
V       IDENTIFICATION DIVISION.                                                 
V      *---------------------------------------------------------------*         
V       PROGRAM-ID.     LHAN0705.                                                
V       AUTHOR.         T520Q6S.                                                 
V       DATE-WRITTEN.   AGOSTO/2013.                      ...
```

### Provedores e Modelos por Análise

| Análise | Provedor | Modelo | Tokens | Horário |
|---------|----------|--------|--------|---------|
| 1 | token_managed | multi_part_analysis | 11172 | 10:03:04 |
| 2 | token_managed | multi_part_analysis | 13396 | 10:03:04 |
| 3 | token_managed | multi_part_analysis | 10652 | 10:03:04 |
| 4 | token_managed | multi_part_analysis | 3530 | 10:03:04 |
| 5 | token_managed | multi_part_analysis | 4594 | 10:03:04 |

