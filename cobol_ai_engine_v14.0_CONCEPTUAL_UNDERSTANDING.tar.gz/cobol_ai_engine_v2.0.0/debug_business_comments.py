#!/usr/bin/env python3.11
"""
Debug para identificar problema com business_comments
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.analyzers.cobol_code_analyzer import COBOLCodeAnalyzer

try:
    print("Testando COBOLCodeAnalyzer...")
    
    analyzer = COBOLCodeAnalyzer()
    
    # Código de teste simples
    test_code = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. TEST.
       
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01 WS-COUNTER PIC 9(3) VALUE 0.
       
       PROCEDURE DIVISION.
       MAIN-PARA.
           MOVE 1 TO WS-COUNTER.
           STOP RUN.
    """
    
    print("Executando análise...")
    result = analyzer.analyze_program(test_code, "TEST")
    
    print(f"Tipo do resultado: {type(result)}")
    print(f"Atributos do resultado: {dir(result)}")
    
    if hasattr(result, 'business_comments'):
        print(f"business_comments: {result.business_comments}")
    else:
        print("business_comments não encontrado")
        
    if hasattr(result, 'business_rules'):
        print(f"business_rules: {len(result.business_rules)} regras")
    else:
        print("business_rules não encontrado")
    
except Exception as e:
    print(f"Erro: {e}")
    import traceback
    traceback.print_exc()
