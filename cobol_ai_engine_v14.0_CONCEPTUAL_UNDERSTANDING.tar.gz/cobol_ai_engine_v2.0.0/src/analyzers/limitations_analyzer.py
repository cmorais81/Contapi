import logging
from typing import Dict, Any, List

class LimitationsAnalyzer:
    """
    Analisador de limitações que identifica especificamente o que não foi possível
    fazer em cada análise, fornecendo transparência total sobre as limitações.
    """

    def __init__(self):
        self.logger = logging.getLogger(__name__)

    def analyze_limitations(self, program_name: str, complete_results: Dict[str, Any], 
                          original_code: str) -> Dict[str, Any]:
        """
        Analisa as limitações específicas da análise realizada.
        """
        self.logger.info(f"Analisando limitações para {program_name}")

        if "error" in complete_results:
            return self._analyze_error_limitations(complete_results)

        final_analysis = complete_results.get("final_analysis", {})
        gap_analysis = complete_results.get("gap_analysis", {})
        gap_resolution = complete_results.get("gap_resolution", {})
        reimplementation_assessment = complete_results.get("reimplementation_assessment", {})

        limitations = {
            "program_name": program_name,
            "analysis_limitations": self._identify_analysis_limitations(final_analysis, original_code),
            "parsing_limitations": self._identify_parsing_limitations(final_analysis, original_code),
            "business_logic_limitations": self._identify_business_logic_limitations(final_analysis, gap_analysis, original_code),
            "code_generation_limitations": self._identify_code_generation_limitations(final_analysis),
            "llm_limitations": self._identify_llm_limitations(gap_resolution),
            "technical_limitations": self._identify_technical_limitations(),
            "data_extraction_limitations": self._identify_data_extraction_limitations(final_analysis, original_code),
            "validation_limitations": self._identify_validation_limitations(final_analysis, original_code),
            "overall_impact": self._assess_overall_impact(reimplementation_assessment),
            "recommendations": self._generate_recommendations(final_analysis, gap_analysis, original_code)
        }

        return limitations

    def _analyze_error_limitations(self, complete_results: Dict[str, Any]) -> Dict[str, Any]:
        """Analisa limitações quando há erro na análise."""
        error_msg = complete_results.get("error", "Erro desconhecido")
        
        return {
            "program_name": complete_results.get("program_name", "UNKNOWN"),
            "critical_failure": True,
            "error_description": error_msg,
            "analysis_limitations": ["Análise completa falhou devido a erro crítico"],
            "parsing_limitations": ["Parser não conseguiu processar o código"],
            "business_logic_limitations": ["Lógica de negócio não pôde ser extraída"],
            "code_generation_limitations": ["Código não pôde ser gerado"],
            "llm_limitations": ["LLM não foi utilizado devido ao erro"],
            "technical_limitations": ["Erro técnico impediu análise completa"],
            "data_extraction_limitations": ["Dados não puderam ser extraídos"],
            "validation_limitations": ["Validações não puderam ser identificadas"],
            "overall_impact": "CRÍTICO - Reimplementação impossível sem análise manual completa",
            "recommendations": [
                "Verificar sintaxe do código COBOL",
                "Validar encoding do arquivo",
                "Executar análise manual do código",
                "Corrigir problemas estruturais antes de nova tentativa"
            ]
        }

    def _identify_analysis_limitations(self, final_analysis: Dict[str, Any], original_code: str) -> List[str]:
        """Identifica limitações gerais da análise."""
        limitations = []

        # Verifica se copybooks foram resolvidos
        if "COPY" in original_code.upper():
            copy_count = original_code.upper().count("COPY")
            resolved_files = len(final_analysis.get("input_files", []))
            if resolved_files == 0:
                limitations.append(f"Não foi possível resolver {copy_count} declarações COPY encontradas no código")
            elif resolved_files < copy_count:
                limitations.append(f"Apenas {resolved_files} de {copy_count} declarações COPY foram resolvidas")

        # Verifica análise de parágrafos
        paragraph_count = len([line for line in original_code.split('\n') if line.strip().endswith('.')])
        if paragraph_count > 10:
            limitations.append(f"Análise de fluxo entre {paragraph_count} parágrafos pode estar incompleta")

        # Verifica complexidade do código
        code_lines = len([line for line in original_code.split('\n') if line.strip()])
        if code_lines > 1000:
            limitations.append(f"Código extenso ({code_lines} linhas) pode ter análise superficial em algumas seções")

        return limitations

    def _identify_parsing_limitations(self, final_analysis: Dict[str, Any], original_code: str) -> List[str]:
        """Identifica limitações específicas do parsing."""
        limitations = []

        # Verifica estruturas de dados
        record_layouts = final_analysis.get("record_layouts", [])
        working_storage_lines = [line for line in original_code.split('\n') 
                               if 'WORKING-STORAGE' in line.upper() or '01 ' in line or '05 ' in line]
        
        if len(working_storage_lines) > len(record_layouts) * 5:
            limitations.append("Muitas estruturas de dados não foram parseadas corretamente")

        # Verifica campos PIC
        pic_declarations = original_code.upper().count('PIC ')
        if pic_declarations > 20:
            limitations.append(f"Apenas uma fração dos {pic_declarations} campos PIC foram analisados detalhadamente")

        # Verifica REDEFINES
        if 'REDEFINES' in original_code.upper():
            redefines_count = original_code.upper().count('REDEFINES')
            limitations.append(f"Não foi possível processar {redefines_count} declarações REDEFINES (estruturas sobrepostas)")

        # Verifica OCCURS
        if 'OCCURS' in original_code.upper():
            occurs_count = original_code.upper().count('OCCURS')
            limitations.append(f"Análise de {occurs_count} arrays/tabelas (OCCURS) pode estar simplificada")

        return limitations

    def _identify_business_logic_limitations(self, final_analysis: Dict[str, Any], 
                                           gap_analysis: Dict[str, Any], original_code: str) -> List[str]:
        """Identifica limitações na extração da lógica de negócio."""
        limitations = []

        # Verifica EVALUATE statements
        evaluate_count = original_code.upper().count('EVALUATE')
        enhanced_logic = final_analysis.get("enhanced_business_logic", {})
        resolved_evaluates = len(enhanced_logic.get("evaluate_conditions", []))
        
        if evaluate_count > resolved_evaluates:
            limitations.append(f"Apenas {resolved_evaluates} de {evaluate_count} statements EVALUATE foram detalhados")

        # Verifica IF statements complexos
        if_count = original_code.upper().count(' IF ')
        if if_count > 20:
            limitations.append(f"Lógica específica de {if_count} condições IF pode estar genérica")

        # Verifica PERFORM statements
        perform_count = original_code.upper().count('PERFORM')
        if perform_count > 15:
            limitations.append(f"Fluxo específico entre {perform_count} chamadas PERFORM não foi mapeado completamente")

        # Verifica cálculos matemáticos
        if any(op in original_code.upper() for op in ['COMPUTE', 'ADD', 'SUBTRACT', 'MULTIPLY', 'DIVIDE']):
            limitations.append("Fórmulas e cálculos matemáticos não foram documentados especificamente")

        # Verifica regras de negócio específicas do domínio
        if 'BACEN' in original_code.upper() or 'DOC3040' in original_code.upper():
            limitations.append("Regras específicas de compliance BACEN/DOC3040 não foram detalhadas")

        return limitations

    def _identify_code_generation_limitations(self, final_analysis: Dict[str, Any]) -> List[str]:
        """Identifica limitações na geração de código."""
        limitations = []

        java_implementation = final_analysis.get("functional_java_implementation", {})
        complete_implementation = java_implementation.get("complete_implementation", "")

        # Verifica se o código Java é válido
        if "private static final String 05" in complete_implementation:
            limitations.append("Código Java gerado contém nomes de variáveis inválidos")

        if "// Implementação principal" in complete_implementation:
            limitations.append("Código Java gerado é um esqueleto genérico, não implementa lógica específica")

        # Verifica se implementa validações
        if "validation" not in complete_implementation.lower():
            limitations.append("Código gerado não implementa as validações identificadas no COBOL")

        # Verifica se implementa tratamento de erros
        if "try" not in complete_implementation.lower() and "catch" not in complete_implementation.lower():
            limitations.append("Código gerado não implementa tratamento de erros equivalente ao COBOL")

        # Verifica se implementa lógica de particionamento
        if "4000" not in complete_implementation and "partition" not in complete_implementation.lower():
            limitations.append("Código gerado não implementa a lógica de particionamento dinâmico")

        # Verifica se implementa roteamento
        if "route" not in complete_implementation.lower() and "S1" not in complete_implementation:
            limitations.append("Código gerado não implementa o roteamento entre arquivos de saída")

        return limitations

    def _identify_llm_limitations(self, gap_resolution: Dict[str, Any]) -> List[str]:
        """Identifica limitações relacionadas ao uso de LLM."""
        limitations = []

        resolution_method = gap_resolution.get("resolution_method", "unknown")
        resolution_quality = gap_resolution.get("resolution_quality", "unknown")

        if resolution_method == "rule_based":
            limitations.append("LLM não estava disponível - usada resolução baseada em regras (limitada)")
            limitations.append("Análise semântica profunda não foi realizada")
            limitations.append("Interpretação contextual de regras de negócio não foi possível")

        if resolution_quality in ["basic", "poor"]:
            limitations.append("Qualidade da resolução de lacunas foi limitada")

        # Verifica se informações específicas não foram resolvidas
        resolved_info = gap_resolution.get("resolved_information", {})
        if not resolved_info.get("business_logic_details", {}).get("evaluate_conditions"):
            limitations.append("Condições EVALUATE não foram interpretadas especificamente")

        if not resolved_info.get("validation_rules"):
            limitations.append("Regras de validação não foram extraídas detalhadamente")

        return limitations

    def _identify_technical_limitations(self) -> List[str]:
        """Identifica limitações técnicas do sistema."""
        limitations = [
            "Sistema não tem acesso a documentação externa ou manuais do sistema",
            "Não foi possível consultar DBAs ou analistas de negócio para esclarecimentos",
            "Análise baseada apenas no código-fonte, sem contexto do ambiente de produção",
            "Não foi possível testar o código gerado em ambiente real",
            "Dependências externas (JCL, procedures, etc.) não foram analisadas"
        ]

        return limitations

    def _identify_data_extraction_limitations(self, final_analysis: Dict[str, Any], original_code: str) -> List[str]:
        """Identifica limitações na extração de dados."""
        limitations = []

        input_files = final_analysis.get("input_files", [])
        
        # Verifica arquivos de entrada
        file_references = []
        for line in original_code.split('\n'):
            if 'SELECT' in line.upper() and 'ASSIGN' in line.upper():
                file_references.append(line.strip())

        if len(file_references) > len(input_files):
            limitations.append(f"Apenas {len(input_files)} de {len(file_references)} arquivos foram estruturados detalhadamente")

        # Verifica layouts de registro
        if input_files:
            for file_info in input_files:
                fields = file_info.get("fields", [])
                if len(fields) < 5:
                    limitations.append(f"Estrutura do arquivo {file_info.get('logical_name', 'N/A')} pode estar incompleta")

        # Verifica relacionamentos entre dados
        if 'CORRESPONDING' in original_code.upper():
            limitations.append("Relacionamentos CORRESPONDING entre estruturas não foram mapeados")

        return limitations

    def _identify_validation_limitations(self, final_analysis: Dict[str, Any], original_code: str) -> List[str]:
        """Identifica limitações na identificação de validações."""
        limitations = []

        specific_validations = final_analysis.get("specific_validations", [])
        
        # Conta validações no código
        validation_keywords = ['IF', 'WHEN', 'NOT =', '= SPACES', '= ZEROS', '> 0', '< 0']
        total_validations = sum(original_code.upper().count(keyword) for keyword in validation_keywords)

        if total_validations > len(specific_validations) * 2:
            limitations.append(f"Muitas validações ({total_validations} potenciais) não foram documentadas especificamente")

        # Verifica validações de domínio
        if any(domain in original_code.upper() for domain in ['CPF', 'CNPJ', 'CEP', 'DATA']):
            limitations.append("Validações específicas de domínio (CPF, CNPJ, etc.) não foram identificadas")

        # Verifica validações de integridade
        if 'FILE STATUS' in original_code.upper():
            limitations.append("Validações específicas de file status não foram detalhadas por código")

        return limitations

    def _assess_overall_impact(self, reimplementation_assessment: Dict[str, Any]) -> str:
        """Avalia o impacto geral das limitações."""
        capability_level = reimplementation_assessment.get("capability_level", "insufficient")
        score = reimplementation_assessment.get("reimplementation_score", 0)

        if capability_level == "complete" and score >= 90:
            return "BAIXO - Limitações não impedem reimplementação funcional"
        elif capability_level == "high" and score >= 70:
            return "MÉDIO - Limitações requerem validação adicional mas reimplementação é viável"
        elif capability_level == "medium" and score >= 50:
            return "ALTO - Limitações significativas requerem análise manual adicional"
        else:
            return "CRÍTICO - Limitações impedem reimplementação confiável sem análise manual extensiva"

    def _generate_recommendations(self, final_analysis: Dict[str, Any], 
                                gap_analysis: Dict[str, Any], original_code: str) -> List[str]:
        """Gera recomendações para superar as limitações."""
        recommendations = []

        # Recomendações baseadas nas lacunas
        critical_gaps = gap_analysis.get("critical_gaps", 0)
        if critical_gaps > 10:
            recommendations.append("Configurar LLM (OpenAI/Claude) para resolução automática de lacunas críticas")

        # Recomendações baseadas na complexidade
        code_lines = len([line for line in original_code.split('\n') if line.strip()])
        if code_lines > 500:
            recommendations.append("Dividir análise em módulos menores para maior precisão")

        # Recomendações técnicas
        if 'COPY' in original_code.upper():
            recommendations.append("Fornecer todos os copybooks referenciados para análise completa")

        recommendations.extend([
            "Consultar analistas de negócio para validar regras extraídas",
            "Testar código gerado em ambiente de desenvolvimento",
            "Revisar manualmente seções críticas identificadas",
            "Documentar exceções e casos especiais não cobertos",
            "Validar com dados reais de produção (amostra)"
        ])

        return recommendations

    def generate_limitations_section(self, limitations: Dict[str, Any]) -> str:
        """Gera a seção de limitações em formato Markdown."""
        program_name = limitations.get("program_name", "UNKNOWN")
        
        if limitations.get("critical_failure"):
            return self._generate_critical_failure_section(limitations)

        sections = []
        
        sections.append("## 🚨 LIMITAÇÕES E TRANSPARÊNCIA TÉCNICA")
        sections.append("*Esta seção documenta honestamente o que NÃO foi possível fazer nesta análise.*")
        sections.append("")

        # Impacto geral
        overall_impact = limitations.get("overall_impact", "DESCONHECIDO")
        sections.append(f"### 📊 **IMPACTO GERAL DAS LIMITAÇÕES: {overall_impact}**")
        sections.append("")

        # Limitações por categoria
        categories = [
            ("analysis_limitations", "🔍 Limitações da Análise Geral"),
            ("parsing_limitations", "⚙️ Limitações do Parsing"),
            ("business_logic_limitations", "🧠 Limitações da Lógica de Negócio"),
            ("code_generation_limitations", "💻 Limitações da Geração de Código"),
            ("llm_limitations", "🤖 Limitações do LLM/IA"),
            ("data_extraction_limitations", "📊 Limitações da Extração de Dados"),
            ("validation_limitations", "✅ Limitações das Validações")
        ]

        for category_key, category_title in categories:
            category_limitations = limitations.get(category_key, [])
            if category_limitations:
                sections.append(f"### {category_title}")
                for limitation in category_limitations:
                    sections.append(f"- ❌ {limitation}")
                sections.append("")

        # Limitações técnicas
        technical_limitations = limitations.get("technical_limitations", [])
        if technical_limitations:
            sections.append("### 🔧 Limitações Técnicas do Sistema")
            for limitation in technical_limitations:
                sections.append(f"- ⚠️ {limitation}")
            sections.append("")

        # Recomendações
        recommendations = limitations.get("recommendations", [])
        if recommendations:
            sections.append("### 💡 Recomendações para Superar as Limitações")
            for i, recommendation in enumerate(recommendations, 1):
                sections.append(f"{i}. **{recommendation}**")
            sections.append("")

        # Disclaimer final
        sections.append("### ⚖️ Disclaimer de Responsabilidade")
        sections.append("Esta análise automatizada fornece uma base sólida para entendimento do programa, ")
        sections.append("mas **NÃO substitui** a revisão por especialistas em COBOL e analistas de negócio. ")
        sections.append("Para projetos críticos de modernização, recomenda-se validação manual adicional ")
        sections.append("das seções identificadas como limitadas.")
        sections.append("")

        return "\n".join(sections)

    def _generate_critical_failure_section(self, limitations: Dict[str, Any]) -> str:
        """Gera seção para falhas críticas."""
        program_name = limitations.get("program_name", "UNKNOWN")
        error_description = limitations.get("error_description", "Erro desconhecido")
        
        sections = []
        
        sections.append("## 🚨 FALHA CRÍTICA NA ANÁLISE")
        sections.append(f"**Programa:** {program_name}")
        sections.append(f"**Erro:** {error_description}")
        sections.append("")
        
        sections.append("### ❌ O que NÃO foi possível fazer:")
        for category in ["analysis_limitations", "parsing_limitations", "business_logic_limitations", 
                        "code_generation_limitations", "data_extraction_limitations"]:
            category_limitations = limitations.get(category, [])
            for limitation in category_limitations:
                sections.append(f"- {limitation}")
        sections.append("")
        
        sections.append("### 🔧 Recomendações para Correção:")
        recommendations = limitations.get("recommendations", [])
        for i, recommendation in enumerate(recommendations, 1):
            sections.append(f"{i}. {recommendation}")
        sections.append("")
        
        sections.append("### ⚠️ Impacto:")
        sections.append("**REIMPLEMENTAÇÃO IMPOSSÍVEL** sem análise manual completa do código-fonte.")
        
        return "\n".join(sections)
