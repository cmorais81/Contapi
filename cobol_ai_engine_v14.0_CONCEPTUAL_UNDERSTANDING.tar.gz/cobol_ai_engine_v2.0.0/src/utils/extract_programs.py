
import re
import os
import logging

def extract_programs_from_fontes(fontes_path, output_dir):
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
    logger = logging.getLogger(__name__)

    logger.info(f"Garantindo que o diretório de saída exista: {output_dir}")
    os.makedirs(output_dir, exist_ok=True)

    logger.info(f"Lendo o arquivo de fontes: {fontes_path}")
    try:
        with open(fontes_path, 'r', encoding='latin-1') as f:
            lines = f.readlines()
    except FileNotFoundError:
        logger.error(f"Arquivo de fontes não encontrado em: {fontes_path}")
        return

    logger.info("Iniciando a extração dos programas...")
    program_name = None
    program_content = []

    for line in lines:
        # Procura pelo delimitador de início de programa
        match = re.search(r"^VMEMBER NAME\s+([A-Z0-9]+)", line)
        if match:
            # Se já temos um programa, salva o anterior
            if program_name and program_content:
                file_path = os.path.join(output_dir, f"{program_name}.cbl")
                with open(file_path, 'w', encoding='latin-1') as pf:
                    pf.write("\n".join(program_content))
                logger.info(f"Programa {program_name} extraído para {file_path}")
            
            # Inicia um novo programa
            program_name = match.group(1).strip()
            program_content = []
        elif program_name:
            # Adiciona a linha ao conteúdo do programa atual, removendo o caractere de controle
            if len(line) > 1:
                program_content.append(line[1:])

    # Salva o último programa do arquivo
    if program_name and program_content:
        file_path = os.path.join(output_dir, f"{program_name}.cbl")
        with open(file_path, 'w', encoding='latin-1') as pf:
            pf.write("\n".join(program_content))
        logger.info(f"Programa {program_name} extraído para {file_path}")

if __name__ == "__main__":
    extract_programs_from_fontes(
        "/home/ubuntu/cobol_ai_engine_v2.0.0/examples/fontes.txt", 
        "/home/ubuntu/cobol_ai_engine_v2.0.0/extracted_programs"
    )

