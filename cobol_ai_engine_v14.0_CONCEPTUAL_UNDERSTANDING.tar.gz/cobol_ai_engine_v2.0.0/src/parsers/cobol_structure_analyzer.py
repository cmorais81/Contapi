"""
Analisador de Estrutura COBOL Real
Extrai divisões, seções, parágrafos e fluxo de execução
"""

import re
import logging
from typing import Dict, List, Any, Optional, Set, Tuple
from dataclasses import dataclass
from enum import Enum

class DivisionType(Enum):
    IDENTIFICATION = "IDENTIFICATION"
    ENVIRONMENT = "ENVIRONMENT"
    DATA = "DATA"
    PROCEDURE = "PROCEDURE"

class SectionType(Enum):
    # Environment Division
    CONFIGURATION = "CONFIGURATION"
    INPUT_OUTPUT = "INPUT-OUTPUT"
    
    # Data Division
    FILE = "FILE"
    WORKING_STORAGE = "WORKING-STORAGE"
    LOCAL_STORAGE = "LOCAL-STORAGE"
    LINKAGE = "LINKAGE"
    
    # Procedure Division
    DECLARATIVES = "DECLARATIVES"
    CUSTOM = "CUSTOM"

@dataclass
class ParagraphInfo:
    """Informações sobre um parágrafo COBOL"""
    name: str
    line_start: int
    line_end: int
    statements: List[str]
    calls_to: List[str]  # Parágrafos chamados por PERFORM
    called_by: List[str]  # Parágrafos que chamam este
    complexity: int  # Número de decisões (IF, EVALUATE, etc.)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'name': self.name,
            'line_start': self.line_start,
            'line_end': self.line_end,
            'statements': self.statements,
            'calls_to': self.calls_to,
            'called_by': self.called_by,
            'complexity': self.complexity
        }

@dataclass
class SectionInfo:
    """Informações sobre uma seção COBOL"""
    name: str
    section_type: SectionType
    line_start: int
    line_end: int
    paragraphs: List[ParagraphInfo]
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'name': self.name,
            'type': self.section_type.value,
            'line_start': self.line_start,
            'line_end': self.line_end,
            'paragraphs': [p.to_dict() for p in self.paragraphs]
        }

@dataclass
class DivisionInfo:
    """Informações sobre uma divisão COBOL"""
    name: str
    division_type: DivisionType
    line_start: int
    line_end: int
    sections: List[SectionInfo]
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'name': self.name,
            'type': self.division_type.value,
            'line_start': self.line_start,
            'line_end': self.line_end,
            'sections': [s.to_dict() for s in self.sections]
        }

@dataclass
class COBOLStructure:
    """Estrutura completa do programa COBOL"""
    program_name: str
    divisions: List[DivisionInfo]
    total_lines: int
    complexity_metrics: Dict[str, int]
    execution_flow: List[str]  # Ordem de execução dos parágrafos
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'program_name': self.program_name,
            'divisions': [d.to_dict() for d in self.divisions],
            'total_lines': self.total_lines,
            'complexity_metrics': self.complexity_metrics,
            'execution_flow': self.execution_flow
        }

class COBOLStructureAnalyzer:
    """Analisador especializado em estrutura hierárquica COBOL"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
        # Padrões regex para identificar elementos estruturais
        self.division_pattern = re.compile(
            r'^\s*(IDENTIFICATION|ENVIRONMENT|DATA|PROCEDURE)\s+DIVISION\s*\.?\s*$',
            re.IGNORECASE
        )
        
        self.section_pattern = re.compile(
            r'^\s*([A-Z0-9\-_]+)\s+SECTION\s*\.?\s*$',
            re.IGNORECASE
        )
        
        self.paragraph_pattern = re.compile(
            r'^\s*([A-Z0-9\-_]+)\s*\.?\s*$',
            re.IGNORECASE
        )
        
        # Padrões para identificar comandos e fluxo
        self.perform_pattern = re.compile(
            r'PERFORM\s+([A-Z0-9\-_]+)(?:\s+THROUGH\s+([A-Z0-9\-_]+))?',
            re.IGNORECASE
        )
        
        self.decision_patterns = [
            re.compile(r'\bIF\b', re.IGNORECASE),
            re.compile(r'\bEVALUATE\b', re.IGNORECASE),
            re.compile(r'\bWHEN\b', re.IGNORECASE),
            re.compile(r'\bUNTIL\b', re.IGNORECASE),
            re.compile(r'\bVARYING\b', re.IGNORECASE)
        ]
        
        # Seções conhecidas por divisão
        self.known_sections = {
            DivisionType.ENVIRONMENT: [
                SectionType.CONFIGURATION,
                SectionType.INPUT_OUTPUT
            ],
            DivisionType.DATA: [
                SectionType.FILE,
                SectionType.WORKING_STORAGE,
                SectionType.LOCAL_STORAGE,
                SectionType.LINKAGE
            ],
            DivisionType.PROCEDURE: [
                SectionType.DECLARATIVES
            ]
        }
    
    def analyze_structure(self, cobol_lines) -> COBOLStructure:
        """
        Analisa a estrutura completa do programa COBOL
        
        Args:
            cobol_lines: Lista de linhas do código COBOL
            
        Returns:
            COBOLStructure com análise completa
        """
        self.logger.info("Iniciando análise de estrutura COBOL")
        
        # Se receber string, converter para lista
        if isinstance(cobol_lines, str):
            lines = cobol_lines.split('\n')
        else:
            lines = cobol_lines
        program_name = self._extract_program_name(lines)
        
        # Analisar divisões
        divisions = self._analyze_divisions(lines)
        
        # Calcular métricas de complexidade
        complexity_metrics = self._calculate_complexity_metrics(divisions)
        
        # Analisar fluxo de execução
        execution_flow = self._analyze_execution_flow(divisions)
        
        structure = COBOLStructure(
            program_name=program_name,
            divisions=divisions,
            total_lines=len(lines),
            complexity_metrics=complexity_metrics,
            execution_flow=execution_flow
        )
        
        self.logger.info(f"Estrutura analisada: {len(divisions)} divisões, "
                        f"{sum(len(d.sections) for d in divisions)} seções, "
                        f"{sum(len(s.paragraphs) for d in divisions for s in d.sections)} parágrafos")
        
        return structure
    
    def _extract_program_name(self, lines: List[str]) -> str:
        """Extrai o nome do programa da IDENTIFICATION DIVISION"""
        for line in lines[:20]:  # Procurar nas primeiras 20 linhas
            if 'PROGRAM-ID' in line.upper():
                match = re.search(r'PROGRAM-ID\s*\.\s*([A-Z0-9\-_]+)', line, re.IGNORECASE)
                if match:
                    return match.group(1)
        return "UNKNOWN_PROGRAM"
    
    def _analyze_divisions(self, lines: List[str]) -> List[DivisionInfo]:
        """Analisa todas as divisões do programa"""
        divisions = []
        current_division = None
        
        for line_num, line in enumerate(lines, 1):
            # Remover comentários
            if line.strip().startswith('*') or line.strip().startswith('/'):
                continue
            
            # Verificar se é uma nova divisão
            division_match = self.division_pattern.match(line.strip())
            if division_match:
                # Finalizar divisão anterior
                if current_division:
                    current_division.line_end = line_num - 1
                    divisions.append(current_division)
                
                # Iniciar nova divisão
                division_name = division_match.group(1).upper()
                division_type = DivisionType(division_name)
                
                current_division = DivisionInfo(
                    name=division_name,
                    division_type=division_type,
                    line_start=line_num,
                    line_end=len(lines),  # Será atualizado
                    sections=[]
                )
                
                self.logger.debug(f"Nova divisão encontrada: {division_name} (linha {line_num})")
                continue
            
            # Analisar seções dentro da divisão atual
            if current_division:
                sections = self._analyze_sections_in_division(
                    lines[current_division.line_start-1:], 
                    current_division.division_type,
                    current_division.line_start
                )
                current_division.sections = sections
        
        # Finalizar última divisão
        if current_division:
            current_division.line_end = len(lines)
            divisions.append(current_division)
        
        return divisions
    
    def _analyze_sections_in_division(self, division_lines: List[str], 
                                    division_type: DivisionType, 
                                    base_line_num: int) -> List[SectionInfo]:
        """Analisa seções dentro de uma divisão específica"""
        sections = []
        current_section = None
        
        for line_num, line in enumerate(division_lines, base_line_num):
            # Pular comentários
            if line.strip().startswith('*') or line.strip().startswith('/'):
                continue
            
            # Verificar se é uma nova seção
            section_match = self.section_pattern.match(line.strip())
            if section_match:
                # Finalizar seção anterior
                if current_section:
                    current_section.line_end = line_num - 1
                    sections.append(current_section)
                
                # Iniciar nova seção
                section_name = section_match.group(1).upper()
                section_type = self._determine_section_type(section_name, division_type)
                
                current_section = SectionInfo(
                    name=section_name,
                    section_type=section_type,
                    line_start=line_num,
                    line_end=len(division_lines) + base_line_num - 1,
                    paragraphs=[]
                )
                
                self.logger.debug(f"Nova seção encontrada: {section_name} (linha {line_num})")
                continue
            
            # Analisar parágrafos na PROCEDURE DIVISION
            if (division_type == DivisionType.PROCEDURE and 
                self._is_paragraph_definition(line)):
                
                # Se não há seção atual na PROCEDURE DIVISION, criar uma seção padrão
                if not current_section:
                    current_section = SectionInfo(
                        name="MAIN",
                        section_type=SectionType.CUSTOM,
                        line_start=line_num,
                        line_end=len(division_lines) + base_line_num - 1,
                        paragraphs=[]
                    )
                
                paragraph = self._analyze_paragraph(
                    division_lines,
                    line_num,
                    base_line_num
                )
                if paragraph:
                    current_section.paragraphs.append(paragraph)
        
        # Finalizar última seção
        if current_section:
            current_section.line_end = len(division_lines) + base_line_num - 1
            sections.append(current_section)
        
        return sections
    
    def _determine_section_type(self, section_name: str, division_type: DivisionType) -> SectionType:
        """Determina o tipo da seção baseado no nome e divisão"""
        section_name_upper = section_name.upper()
        
        # Mapeamento direto de nomes conhecidos
        section_mappings = {
            'CONFIGURATION': SectionType.CONFIGURATION,
            'INPUT-OUTPUT': SectionType.INPUT_OUTPUT,
            'FILE': SectionType.FILE,
            'WORKING-STORAGE': SectionType.WORKING_STORAGE,
            'LOCAL-STORAGE': SectionType.LOCAL_STORAGE,
            'LINKAGE': SectionType.LINKAGE,
            'DECLARATIVES': SectionType.DECLARATIVES
        }
        
        if section_name_upper in section_mappings:
            return section_mappings[section_name_upper]
        
        # Para seções customizadas na PROCEDURE DIVISION
        if division_type == DivisionType.PROCEDURE:
            return SectionType.CUSTOM
        
        # Default
        return SectionType.CUSTOM
    
    def _is_paragraph_definition(self, line: str) -> bool:
        """Verifica se a linha define um parágrafo"""
        stripped = line.strip()
        if not stripped or stripped.startswith('*'):
            return False
        
        # Parágrafo termina com ponto e não contém palavras-chave COBOL
        if stripped.endswith('.'):
            # Não deve ser comando COBOL
            cobol_keywords = [
                'MOVE', 'ADD', 'SUBTRACT', 'MULTIPLY', 'DIVIDE',
                'IF', 'ELSE', 'PERFORM', 'CALL', 'OPEN', 'CLOSE',
                'READ', 'WRITE', 'DISPLAY', 'ACCEPT', 'STOP'
            ]
            
            first_word = stripped.split()[0].upper()
            return first_word not in cobol_keywords
        
        return False
    
    def _analyze_paragraph(self, division_lines: List[str], line_num: int, base_line_num: int) -> Optional[ParagraphInfo]:
        """Analisa um parágrafo específico"""
        line_index = line_num - base_line_num
        if line_index >= len(division_lines):
            return None
        
        first_line = division_lines[line_index].strip()
        paragraph_name = first_line.rstrip('.').strip()
        
        statements = []
        calls_to = []
        complexity = 0
        end_line = line_num
        
        # Analisar linhas do parágrafo até encontrar próximo parágrafo ou seção
        for i in range(line_index + 1, len(division_lines)):
            line = division_lines[i]
            stripped = line.strip()
            
            # Parar se encontrar novo parágrafo ou seção
            if (self._is_paragraph_definition(line) or 
                self.section_pattern.match(stripped) or
                self.division_pattern.match(stripped)):
                break
            
            # Pular comentários
            if stripped.startswith('*') or stripped.startswith('/'):
                continue
            
            if stripped:
                statements.append(stripped)
                end_line = base_line_num + i
                
                # Identificar chamadas PERFORM
                perform_matches = self.perform_pattern.findall(stripped)
                for match in perform_matches:
                    if isinstance(match, tuple):
                        calls_to.append(match[0])  # Primeiro grupo
                        if match[1]:  # THROUGH
                            calls_to.append(match[1])
                    else:
                        calls_to.append(match)
                
                # Calcular complexidade (decisões)
                for pattern in self.decision_patterns:
                    complexity += len(pattern.findall(stripped))
        
        return ParagraphInfo(
            name=paragraph_name,
            line_start=line_num,
            line_end=end_line,
            statements=statements,
            calls_to=calls_to,
            called_by=[],  # Será preenchido posteriormente
            complexity=complexity
        )
    
    def _calculate_complexity_metrics(self, divisions: List[DivisionInfo]) -> Dict[str, int]:
        """Calcula métricas de complexidade do programa"""
        metrics = {
            'total_divisions': len(divisions),
            'total_sections': 0,
            'total_paragraphs': 0,
            'cyclomatic_complexity': 0,
            'decision_points': 0,
            'perform_statements': 0
        }
        
        for division in divisions:
            metrics['total_sections'] += len(division.sections)
            
            for section in division.sections:
                metrics['total_paragraphs'] += len(section.paragraphs)
                
                for paragraph in section.paragraphs:
                    metrics['cyclomatic_complexity'] += paragraph.complexity
                    metrics['decision_points'] += paragraph.complexity
                    metrics['perform_statements'] += len(paragraph.calls_to)
        
        # Complexidade ciclomática = decisões + 1
        metrics['cyclomatic_complexity'] = metrics['decision_points'] + 1
        
        return metrics
    
    def _analyze_execution_flow(self, divisions: List[DivisionInfo]) -> List[str]:
        """Analisa o fluxo de execução dos parágrafos"""
        execution_flow = []
        
        # Encontrar PROCEDURE DIVISION
        procedure_division = None
        for division in divisions:
            if division.division_type == DivisionType.PROCEDURE:
                procedure_division = division
                break
        
        if not procedure_division:
            return execution_flow
        
        # Coletar todos os parágrafos
        all_paragraphs = []
        for section in procedure_division.sections:
            all_paragraphs.extend(section.paragraphs)
        
        if not all_paragraphs:
            return execution_flow
        
        # Primeiro parágrafo é o ponto de entrada
        if all_paragraphs:
            execution_flow.append(all_paragraphs[0].name)
            
            # Analisar chamadas PERFORM para construir fluxo
            visited = set()
            self._trace_execution_flow(all_paragraphs[0], all_paragraphs, execution_flow, visited)
        
        return execution_flow
    
    def _trace_execution_flow(self, current_paragraph: ParagraphInfo, 
                            all_paragraphs: List[ParagraphInfo],
                            execution_flow: List[str], 
                            visited: Set[str]):
        """Rastreia o fluxo de execução recursivamente"""
        if current_paragraph.name in visited:
            return
        
        visited.add(current_paragraph.name)
        
        # Adicionar parágrafos chamados por PERFORM
        for called_name in current_paragraph.calls_to:
            if called_name not in execution_flow:
                execution_flow.append(called_name)
            
            # Encontrar parágrafo chamado e continuar rastreamento
            called_paragraph = next(
                (p for p in all_paragraphs if p.name == called_name), 
                None
            )
            if called_paragraph:
                self._trace_execution_flow(called_paragraph, all_paragraphs, execution_flow, visited)
    
    def generate_structure_documentation(self, structure: COBOLStructure) -> str:
        """Gera documentação formatada da estrutura"""
        doc = f"## Estrutura Hierárquica do Programa: {structure.program_name}\n\n"
        
        # Resumo geral
        doc += "### Resumo Estrutural\n\n"
        doc += f"- **Total de Linhas:** {structure.total_lines}\n"
        doc += f"- **Divisões:** {structure.complexity_metrics['total_divisions']}\n"
        doc += f"- **Seções:** {structure.complexity_metrics['total_sections']}\n"
        doc += f"- **Parágrafos:** {structure.complexity_metrics['total_paragraphs']}\n"
        doc += f"- **Complexidade Ciclomática:** {structure.complexity_metrics['cyclomatic_complexity']}\n\n"
        
        # Detalhamento por divisão
        for division in structure.divisions:
            doc += f"### {division.name} DIVISION (Linhas {division.line_start}-{division.line_end})\n\n"
            
            if division.sections:
                for section in division.sections:
                    doc += f"#### {section.name} SECTION\n"
                    
                    if section.paragraphs:
                        doc += "| Parágrafo | Linhas | Complexidade | Chama | Chamado Por |\n"
                        doc += "|-----------|--------|--------------|-------|-------------|\n"
                        
                        for paragraph in section.paragraphs:
                            calls_to = ", ".join(paragraph.calls_to) if paragraph.calls_to else "-"
                            called_by = ", ".join(paragraph.called_by) if paragraph.called_by else "-"
                            
                            doc += f"| {paragraph.name} | {paragraph.line_start}-{paragraph.line_end} | {paragraph.complexity} | {calls_to} | {called_by} |\n"
                        
                        doc += "\n"
                    else:
                        doc += "*Nenhum parágrafo identificado*\n\n"
            else:
                doc += "*Nenhuma seção identificada*\n\n"
        
        # Fluxo de execução
        if structure.execution_flow:
            doc += "### Fluxo de Execução\n\n"
            doc += "```\n"
            doc += " → ".join(structure.execution_flow)
            doc += "\n```\n\n"
        
        return doc
