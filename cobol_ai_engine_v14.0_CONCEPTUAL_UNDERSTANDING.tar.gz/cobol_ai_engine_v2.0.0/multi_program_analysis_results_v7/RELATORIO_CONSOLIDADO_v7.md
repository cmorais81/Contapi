
# Documentação Técnica: LHAN0542.
**Data da Análise:** 17/09/2025 20:57

## 1. Resumo Funcional
**Propósito do Programa:** Particionar o arquivo de entrada (LHS542E1) em múltiplos arquivos de saída (LHS542S1, LHS542S2, LHS542S3) com base no tipo de registro e em um limite de tamanho por arquivo.

## 2. Arquitetura de Dados
### Arquivos
Nenhum arquivo identificado.

### Layouts de Registro
#### Layout: 
| Nível | Campo | Posição | Tamanho | Ocorr. | Redef. | Tipo | PIC |
|---|---|---|---|---|---|---|---|
| 1 | REG-SAI3542 | 1 | 0 |  |  | GRUPO |  |
| 1 | WS-AREA-TRABALHO | 1 | 0 |  |  | GRUPO |  |
| 1 | WAREA-82 | 1 | 0 |  |  | GRUPO |  |
| 1 | LK-PARM | 1 | 0 |  |  | GRUPO |  |

## 3. Estrutura do Programa
- **Divisões:** IDENTIFICATION, ENVIRONMENT, DATA
- **Seções:**
- **Fluxo de Controle (Grafo de Execução):**
  - Fluxo não determinado.

## 4. Lógica de Negócio Detalhada
### Fluxo de Dados
O programa lê registros do arquivo de entrada E1DQ0705. Cada registro é validado. Com base no tipo de registro, ele é roteado para um dos dois arquivos de saída principais (S1DQ0705 ou S2DQ0705). Há uma lógica de particionamento que cria novos arquivos de saída quando o número de registros atinge um limite.

### Regras de Negócio
- **Regra 1:** Se o tipo de registro (WS-TIPO-REGISTRO) for '01' ou '02', o registro é gravado no arquivo de saída LHS542S1.
- **Regra 2:** Se o tipo de registro for '03', o registro é gravado no arquivo de saída LHS542S2.
- **Regra 3:** Se o contador de registros para S1 (WS-CONT-S1) exceder o máximo (WS-MAX-REGISTROS), o arquivo S1DQ0705 é fechado e reaberto, zerando o contador.
- **Regra 4:** Se o contador de registros para S2 (WS-CONT-S2) exceder o máximo (WS-MAX-REGISTROS), o arquivo S2DQ0705 é fechado e reaberto, zerando o contador.
- **Regra 5:** Registros com tipo inválido (não numérico, espaços, ou diferente de '01', '02', '03') são rejeitados e uma mensagem é exibida.

### Pontos Críticos da Lógica
- **Ponto Crítico 1:** A lógica de particionamento dinâmico nas seções 2210-GRAVAR-S1 e 2220-GRAVAR-S2, que garante que os arquivos de saída não excedam um tamanho máximo.
- **Ponto Crítico 2:** A validação de registro na seção 2100-VALIDAR-REGISTRO, que garante a integridade dos dados antes do processamento.
- **Ponto Crítico 3:** A chamada para a sub-rotina 'WDRAM0082' na inicialização, que parece ser um ponto crítico para a alocação de recursos, e cujo fracasso leva a um término anormal.

## 5. Guia de Reimplementação (Java)
_(Esta seção é um exemplo genérico e deve ser aprimorada para refletir a lógica de negócio detalhada.)_
``` java
// O código de reimplementação deve ser gerado com base na lógica de negócio detalhada na seção 4.
// Exemplo de esqueleto:
public class LHAN0542 {
    public void process() {
        // 1. Ler registros do arquivo de entrada.
        // 2. Para cada registro, aplicar as validações e regras de negócio descritas na Seção 4.
        // 3. Implementar a lógica de roteamento e particionamento conforme descrito.
        // 4. Gravar nos arquivos de saída apropriados.
        // 5. Tratar erros e gerar logs/relatórios.
    }
}
```\n\n---\n\n
# Documentação Técnica: LHAN0705.
**Data da Análise:** 17/09/2025 20:57

## 1. Resumo Funcional
**Propósito do Programa:** Não foi possível determinar o propósito.

## 2. Arquitetura de Dados
### Arquivos
Nenhum arquivo identificado.

### Layouts de Registro
#### Layout: 
| Nível | Campo | Posição | Tamanho | Ocorr. | Redef. | Tipo | PIC |
|---|---|---|---|---|---|---|---|
| 1 | REG-S2DQ0705 | 1 | 260 |  |  | ALFANUMERICO | X(260) |
| 1 | CT-CONTROLES | 261 | 0 |  |  | GRUPO |  |
| 1 | WS-CHAVES | 261 | 0 |  |  | GRUPO |  |
| 1 | WS-CHAVE-E1-ANT | 261 | 41 |  |  | ALFANUMERICO | X(041) |
| 1 | WS-E1DQ0705 | 302 | 0 |  |  | GRUPO |  |
| 1 | LI-LHCE0700 | 302 | 0 |  |  | GRUPO |  |
| 1 | AC-ACUMULADORES | 302 | 0 |  |  | GRUPO |  |
| 1 | WK-DTCORRENTE | 302 | 6 |  |  | NUMERICO | 9(006) |
| 1 | FILLER | 308 | 0 |  | WK-DTCORRENTE | GRUPO |  |
| 1 | WK-DTA-PROC | 308 | 8 |  |  | NUMERICO | 9(008) |
| 1 | FILLER | 316 | 0 |  | WK-DTA-PROC | GRUPO |  |
| 1 | WK-DATA-BASE | 316 | 8 |  |  | NUMERICO | 9(008) |
| 1 | WK-DT-REESTRU-NUM | 324 | 0 |  |  | GRUPO |  |
| 1 | VARIAVEIS | 324 | 0 |  |  | GRUPO |  |
| 1 | WK-LHCP3402 | 324 | 0 |  |  | GRUPO |  |
| 1 | WK-DRAM0152 | 324 | 0 |  |  | GRUPO |  |
| 1 | WK-DRAM0022 | 324 | 0 |  |  | GRUPO |  |
| 1 | WK-DRAM0038 | 324 | 0 |  |  | GRUPO |  |
| 1 | SW-SWITCHES | 324 | 0 |  |  | GRUPO |  |
| 1 | WS-MSG-TABELA | 324 | 0 |  |  | GRUPO |  |
| 1 | REG-MZTC5001 | 324 | 0 |  |  | GRUPO |  |

## 3. Estrutura do Programa
- **Divisões:** IDENTIFICATION, ENVIRONMENT, DATA, PROCEDURE
- **Seções:**
  - **R000-PRINCIPAL**: GOBACK
  - **R100-INICIO**: AC-RG-GRAV, END-IF, S2DQ0705, END-IF, END-IF, R100-EXIT
  - **R110-LER-E1DQ0705**: END-READ, END-IF, R110-EXIT
  - **R200-PROCESSAMENTO**: END-IF, R200-EXIT, R201-REINCIALIZA
  - **R210-VALIDA-HEADER**: END-IF, R210-EXIT
  - **R220-VALIDA-TRAILLER**: END-IF, R220-EXIT
  - **R230-VALIDA-DETALHE**: END-IF, R230-EXIT, R300-VALIDA-DATA, R305-VALIDA-CPF, R310-VALIDA-CNPJ, R315-VALIDA-CONTRATO, R320-VALIDA-MODSUB, R325-VALIDA-TIPOSUB, R330-VALIDA-VALOR, R335-VALIDA-PERCENTUAL, R340-VALIDA-CD-INFO-ADIC
  - **R500-GRAVA-SAIDA1-OK**: R500-EXIT
  - **R600-GRAVA-SAIDA2-ERRO**: R600-EXIT
  - **R900-FIM**: S2DQ0705, END-IF, R999-EXIT
  - **R990-CANCELA**: T001-TRATA-TIPO-01, T002-TRATA-TIPO-02, T003-TRATA-TIPO-03, T004-TRATA-TIPO-04, T006-TRATA-TIPO-06, T007-TRATA-TIPO-07, T010-TRATA-TIPO-10, T011-TRATA-TIPO-11, T012-TRATA-TIPO-12, T014-TRATA-TIPO-14, T015-TRATA-TIPO-15, T017-TRATA-TIPO-17, END-IF, T018-TRATA-TIPO-18, T019-TRATA-TIPO-19
- **Fluxo de Controle (Grafo de Execução):**
  - `END-IF` -> `R600-GRAVA-SAIDA2-ERRO`, `R990-CANCELA`, `VARYING`
  - `S2DQ0705` -> `R110-LER-E1DQ0705`, `R990-CANCELA`
  - `R201-REINCIALIZA` -> `VARYING`
  - `T001-TRATA-TIPO-01` -> `R300-VALIDA-DATA`, `R310-VALIDA-CNPJ`, `R335-VALIDA-PERCENTUAL`, `R330-VALIDA-VALOR`
  - `T002-TRATA-TIPO-02` -> `R310-VALIDA-CNPJ`, `R335-VALIDA-PERCENTUAL`
  - `T004-TRATA-TIPO-04` -> `R300-VALIDA-DATA`, `R340-VALIDA-CD-INFO-ADIC`
  - `T007-TRATA-TIPO-07` -> `R300-VALIDA-DATA`, `R310-VALIDA-CNPJ`, `R335-VALIDA-PERCENTUAL`, `R330-VALIDA-VALOR`
  - `T010-TRATA-TIPO-10` -> `R300-VALIDA-DATA`, `R310-VALIDA-CNPJ`, `R330-VALIDA-VALOR`
  - `T011-TRATA-TIPO-11` -> `R310-VALIDA-CNPJ`, `R340-VALIDA-CD-INFO-ADIC`
  - `T012-TRATA-TIPO-12` -> `R300-VALIDA-DATA`, `R320-VALIDA-MODSUB`, `R330-VALIDA-VALOR`, `R310-VALIDA-CNPJ`, `R315-VALIDA-CONTRATO`, `R335-VALIDA-PERCENTUAL`
  - `T015-TRATA-TIPO-15` -> `R310-VALIDA-CNPJ`
  - `T018-TRATA-TIPO-18` -> `R340-VALIDA-CD-INFO-ADIC`
  - `T019-TRATA-TIPO-19` -> `R340-VALIDA-CD-INFO-ADIC`

## 4. Lógica de Negócio Detalhada
### Fluxo de Dados
Não descrito.

### Regras de Negócio
Nenhuma regra de negócio específica foi extraída.

### Pontos Críticos da Lógica
Nenhum ponto crítico de lógica foi identificado.

## 5. Guia de Reimplementação (Java)
_(Esta seção é um exemplo genérico e deve ser aprimorada para refletir a lógica de negócio detalhada.)_
``` java
// O código de reimplementação deve ser gerado com base na lógica de negócio detalhada na seção 4.
// Exemplo de esqueleto:
public class LHAN0705 {
    public void process() {
        // 1. Ler registros do arquivo de entrada.
        // 2. Para cada registro, aplicar as validações e regras de negócio descritas na Seção 4.
        // 3. Implementar a lógica de roteamento e particionamento conforme descrito.
        // 4. Gravar nos arquivos de saída apropriados.
        // 5. Tratar erros e gerar logs/relatórios.
    }
}
```\n\n---\n\n
# Documentação Técnica: LHAN0706.
**Data da Análise:** 17/09/2025 20:57

## 1. Resumo Funcional
**Propósito do Programa:** Não foi possível determinar o propósito.

## 2. Arquitetura de Dados
### Arquivos
Nenhum arquivo identificado.

### Layouts de Registro
#### Layout: 
| Nível | Campo | Posição | Tamanho | Ocorr. | Redef. | Tipo | PIC |
|---|---|---|---|---|---|---|---|
| 1 | REG-S2DQ0706 | 1 | 260 |  |  | ALFANUMERICO | X(260) |
| 1 | WS-LHCE0400 | 261 | 0 |  |  | GRUPO |  |
| 1 | WS-LHCE0400-AUX | 261 | 0 |  |  | GRUPO |  |
| 1 | WS-LHCE0430 | 261 | 0 |  |  | GRUPO |  |
| 1 | LI-LHCE0700 | 261 | 0 |  |  | GRUPO |  |
| 1 | WS-VARIAVEIS | 261 | 0 |  |  | GRUPO |  |
| 1 | WS-CHAVES | 261 | 0 |  |  | GRUPO |  |
| 1 | AC-ACUMULADORES | 261 | 0 |  |  | GRUPO |  |
| 1 | ME-MENSAGENS | 261 | 0 |  |  | GRUPO |  |
| 1 | SW-SWITCHES | 261 | 0 |  |  | GRUPO |  |
| 1 | TB-INTERNA | 261 | 0 |  |  | GRUPO |  |
| 1 | WS-CURRENT-DATE | 261 | 19 |  |  | NUMERICO | X(19) |
| 1 | FILLER | 280 | 0 |  | WS-CURRENT-DATE | GRUPO |  |
| 1 | WS-DATA-SIST | 280 | 10 |  |  | ALFANUMERICO | X(10) |
| 1 | FILLER | 290 | 0 |  | WS-DATA-SIST | GRUPO |  |
| 1 | WS-HORA-SIST | 290 | 8 |  |  | ALFANUMERICO | X(08) |
| 1 | FILLER | 298 | 0 |  | WS-HORA-SIST | GRUPO |  |
| 1 | WS-COMPILATION-DATE | 298 | 0 |  |  | GRUPO |  |
| 1 | WS-DATA-COMP | 298 | 8 |  |  | ALFANUMERICO | X(08) |
| 1 | FILLER | 306 | 0 |  | WS-DATA-COMP | GRUPO |  |
| 1 | WK-DATA-BASE | 306 | 8 |  |  | NUMERICO | 9(08) |
| 1 | FILLER | 314 | 0 |  | WK-DATA-BASE | GRUPO |  |

## 3. Estrutura do Programa
- **Divisões:** IDENTIFICATION, ENVIRONMENT, DATA, PROCEDURE
- **Seções:**
  - **R000-PRINCIPAL**: 
  - **R100-INICIO**: S2DQ0706, END-IF, R100-EXIT
  - **R110-LER-E1DQ0706**: END-READ, END-IF, R110-EXIT
  - **R120-CONTROLE-E2DQ0706**: R120-CONTROLE-INICIO, END-IF, R120-EXIT
  - **R125-LER-E2DQ0706**: END-READ, END-IF, R125-EXIT
  - **R200-PROCESSAMENTO**: END-EVALUATE, R200-EXIT
  - **R201-TRATA-IGUAIS**: R201-EXIT
  - **R210-ANALISE-E2DQ0706**: R210-EXIT
  - **R211-GRAVA-E2DQ0706-S1**: R211-EXIT
  - **R301-TATICO-INEXISTE-E1**: R301-EXIT
  - **R401-SALVA-E1DQ0706-S1**: END-PERFORM, R401-EXIT
  - **R402-PREPARA-TATICO**: END-IF, R402-EXIT
  - **R500-GRAVA-S1DQ0706**: R500-EXIT
  - **R510-GRAVA-S2DQ0706**: R510-EXIT
  - **R800-FINALIZACAO**: S2DQ0706, GOBACK
  - **R990-CANCELA**: 
  - **T001-GRAVA-TIPO-01**: T001-EXIT
  - **T002-GRAVA-TIPO-02**: T002-EXIT
  - **T004-GRAVA-TIPO-04**: END-EVALUATE, T004-EXIT
  - **T006-GRAVA-TIPO-06**: T006-EXIT
  - **T007-GRAVA-TIPO-07**: T007-EXIT
  - **T010-GRAVA-TIPO-10**: T010-EXIT
  - **T011-GRAVA-TIPO-11**: T011-EXIT
  - **T012-GRAVA-TIPO-12**: END-EVALUATE, T012-EXIT
  - **T014-GRAVA-TIPO-14**: END-IF, T014-EXIT
  - **T015-GRAVA-TIPO-15**: END-IF, T015-EXIT
  - **T016-GRAVA-TIPO-16**: T016-EXIT
  - **T017-GRAVA-TIPO-17**: T017-EXIT
  - **T018-GRAVA-TIPO-18**: T018-EXIT
  - **T019-GRAVA-TIPO-19**: END-IF, T019-EXIT
  - **T024-GRAVA-TIPO-24**: END-IF, T024-EXIT
  - **U010-CD-INFO-ADIC-DATA**: U010-EXIT
  - **U011-CD-INFO-ADIC-FULL**: U011-EXIT
  - **U012-CD-INFO-ADIC-CONTR**: U012-EXIT
  - **U013-CD-INFO-ADIC-SITUACAO**: U013-EXIT
  - **U020-ID-INFO-ADIC-CNPJ**: END-IF, U020-EXIT
  - **U021-ID-INFO-ADIC-DATA**: U021-EXIT
  - **U022-ID-INFO-ADIC-MODSUB**: U022-EXIT
  - **U023-ID-INFO-ADIC-SITUACAO**: U023-EXIT
  - **U030-VL-INFO-ADIC**: END-IF, U030-EXIT
  - **U040-PC-INFO-ADIC**: END-IF, U040-EXIT
- **Fluxo de Controle (Grafo de Execução):**
  - `S2DQ0706` -> `R110-LER-E1DQ0706`, `R990-CANCELA`
  - `END-IF` -> `R120-CONTROLE-E2DQ0706`
  - `R120-CONTROLE-INICIO` -> `R125-LER-E2DQ0706`, `R120-CONTROLE-INICIO`, `R510-GRAVA-S2DQ0706`, `R120-EXIT`

## 4. Lógica de Negócio Detalhada
### Fluxo de Dados
Não descrito.

### Regras de Negócio
Nenhuma regra de negócio específica foi extraída.

### Pontos Críticos da Lógica
Nenhum ponto crítico de lógica foi identificado.

## 5. Guia de Reimplementação (Java)
_(Esta seção é um exemplo genérico e deve ser aprimorada para refletir a lógica de negócio detalhada.)_
``` java
// O código de reimplementação deve ser gerado com base na lógica de negócio detalhada na seção 4.
// Exemplo de esqueleto:
public class LHAN0706 {
    public void process() {
        // 1. Ler registros do arquivo de entrada.
        // 2. Para cada registro, aplicar as validações e regras de negócio descritas na Seção 4.
        // 3. Implementar a lógica de roteamento e particionamento conforme descrito.
        // 4. Gravar nos arquivos de saída apropriados.
        // 5. Tratar erros e gerar logs/relatórios.
    }
}
```\n\n---\n\n
# Documentação Técnica: LHBR0700.
**Data da Análise:** 17/09/2025 20:57

## 1. Resumo Funcional
**Propósito do Programa:** Não foi possível determinar o propósito.

## 2. Arquitetura de Dados
### Arquivos
Nenhum arquivo identificado.

### Layouts de Registro
Nenhum layout de registro extraído.

## 3. Estrutura do Programa
- **Divisões:** IDENTIFICATION, ENVIRONMENT, DATA
- **Seções:**
- **Fluxo de Controle (Grafo de Execução):**
  - Fluxo não determinado.

## 4. Lógica de Negócio Detalhada
### Fluxo de Dados
Não descrito.

### Regras de Negócio
Nenhuma regra de negócio específica foi extraída.

### Pontos Críticos da Lógica
Nenhum ponto crítico de lógica foi identificado.

## 5. Guia de Reimplementação (Java)
_(Esta seção é um exemplo genérico e deve ser aprimorada para refletir a lógica de negócio detalhada.)_
``` java
// O código de reimplementação deve ser gerado com base na lógica de negócio detalhada na seção 4.
// Exemplo de esqueleto:
public class LHBR0700 {
    public void process() {
        // 1. Ler registros do arquivo de entrada.
        // 2. Para cada registro, aplicar as validações e regras de negócio descritas na Seção 4.
        // 3. Implementar a lógica de roteamento e particionamento conforme descrito.
        // 4. Gravar nos arquivos de saída apropriados.
        // 5. Tratar erros e gerar logs/relatórios.
    }
}
```\n\n---\n\n
# Documentação Técnica: MZAN6056.
**Data da Análise:** 17/09/2025 20:57

## 1. Resumo Funcional
**Propósito do Programa:** Não foi possível determinar o propósito.

## 2. Arquitetura de Dados
### Arquivos
Nenhum arquivo identificado.

### Layouts de Registro
#### Layout: 
| Nível | Campo | Posição | Tamanho | Ocorr. | Redef. | Tipo | PIC |
|---|---|---|---|---|---|---|---|
| 1 | REG-S1DQ6056 | 1 | 2000 |  |  | ALFANUMERICO | X(2000) |
| 1 | WS-CHAVE-E1DQ6056 | 2001 | 0 |  |  | GRUPO |  |
| 1 | WS-CHAVE-E2DQ6056 | 2001 | 0 |  |  | GRUPO |  |
| 1 | WS-CURRENT-DATE | 2001 | 19 |  |  | NUMERICO | X(19) |
| 1 | FILLER | 2020 | 0 |  | WS-CURRENT-DATE | GRUPO |  |
| 1 | WS-DATA-SIST | 2020 | 10 |  |  | ALFANUMERICO | X(10) |
| 1 | FILLER | 2030 | 0 |  | WS-DATA-SIST | GRUPO |  |
| 1 | WS-HORA-SIST | 2030 | 8 |  |  | ALFANUMERICO | X(08) |
| 1 | FILLER | 2038 | 0 |  | WS-HORA-SIST | GRUPO |  |
| 1 | WS-COMPILATION-DATE | 2038 | 0 |  |  | GRUPO |  |
| 1 | WS-DATA-COMP | 2038 | 8 |  |  | ALFANUMERICO | X(08) |
| 1 | FILLER | 2046 | 0 |  | WS-DATA-COMP | GRUPO |  |
| 1 | WS-DT-ACORDO-MZ13 | 2046 | 10 |  |  | ALFANUMERICO | X(10) |
| 1 | FILLER | 2056 | 0 |  | WS-DT-ACORDO-MZ13 | GRUPO |  |
| 1 | WS-DT-ACORDO | 2056 | 8 |  |  | NUMERICO | 9(08) |
| 1 | FILLER | 2064 | 0 |  | WS-DT-ACORDO | GRUPO |  |

## 3. Estrutura do Programa
- **Divisões:** IDENTIFICATION, ENVIRONMENT, DATA, PROCEDURE
- **Seções:**
  - **000-00-MODULO-MESTRE**: 000-99-FIM, EXIT
  - **100-00-PROCESSAMENTO**: END-IF, 100-99-EXIT, EXIT
  - **110-00-MOVER-CAMPOS**: END-IF, 110-99-EXIT, EXIT
  - **120-00-ZERAR-CAMPOS**: END-IF, PAR-PAG-ACD-MES-ANT-6001, END-IF, END-IF, 120-99-EXIT, EXIT
  - **500-00-GRAVA-S1DQ6056**: 500-99-EXIT, EXIT
  - **610-00-LE-E1DQ6056**: END-IF, 610-99-EXIT, EXIT
  - **620-00-LE-E2DQ6056**: END-IF, 620-99-EXIT, EXIT
  - **630-00-CONVERTE-RATING**: END-IF, END-IF, 630-99-EXIT, EXIT
  - **700-00-FINALIZA**: S1DQ6056, 700-99-EXIT, EXIT
  - **800-00-INICIALIZA**: END-IF, END-IF, 800-99-FIM, EXIT
  - **900-00-FIM-ANORMAL**: S1DQ6056, 900-99-EXIT, EXIT
- **Fluxo de Controle (Grafo de Execução):**
  - `END-IF` -> `620-00-LE-E2DQ6056`, `630-00-CONVERTE-RATING`, `900-00-FIM-ANORMAL`

## 4. Lógica de Negócio Detalhada
### Fluxo de Dados
Não descrito.

### Regras de Negócio
Nenhuma regra de negócio específica foi extraída.

### Pontos Críticos da Lógica
Nenhum ponto crítico de lógica foi identificado.

## 5. Guia de Reimplementação (Java)
_(Esta seção é um exemplo genérico e deve ser aprimorada para refletir a lógica de negócio detalhada.)_
``` java
// O código de reimplementação deve ser gerado com base na lógica de negócio detalhada na seção 4.
// Exemplo de esqueleto:
public class MZAN6056 {
    public void process() {
        // 1. Ler registros do arquivo de entrada.
        // 2. Para cada registro, aplicar as validações e regras de negócio descritas na Seção 4.
        // 3. Implementar a lógica de roteamento e particionamento conforme descrito.
        // 4. Gravar nos arquivos de saída apropriados.
        // 5. Tratar erros e gerar logs/relatórios.
    }
}
```\n\n---\n\n
