#!/usr/bin/env python3
"""
Script para testar todos os provedores de IA disponíveis.
Mostra quais estão funcionando e quais têm problemas.
"""

import os
import sys
import yaml
import logging

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

# Configurar logging
logging.basicConfig(level=logging.WARNING)  # Reduzir logs para teste

def test_provider(provider_name, config):
    """Testa um provedor específico."""
    try:
        print(f"\n Testando {provider_name.upper()}...")
        
        # Importar o provider manager
        from src.providers.provider_manager import ProviderManager
        
        # Criar configuração temporária para este provedor
        temp_config = config.copy()
        temp_config['ai']['primary_provider'] = provider_name
        temp_config['ai']['fallback_providers'] = []  # Sem fallback para teste isolado
        
        # Inicializar provider manager
        provider_manager = ProviderManager(temp_config)
        
        # Testar disponibilidade
        status = provider_manager.get_provider_status(provider_name)
        
        if status['available']:
            print(f"    {provider_name}: DISPONÍVEL")
            print(f"      Modelo: {status.get('model', 'N/A')}")
            print(f"      Status: {status.get('status', 'N/A')}")
            return True
        else:
            print(f"    {provider_name}: INDISPONÍVEL")
            print(f"      Erro: {status.get('error', 'Erro desconhecido')}")
            return False
            
    except Exception as e:
        print(f"    {provider_name}: ERRO - {str(e)}")
        return False

def test_analysis_with_provider(provider_name, config):
    """Testa análise real com um provedor."""
    try:
        print(f"\n🧪 Testando análise com {provider_name.upper()}...")
        
        # Importar dependências
        from src.providers.provider_manager import ProviderManager
        from src.core.prompt_manager import PromptManager
        from src.providers.base_provider import AIRequest
        
        # Configurar para usar este provedor
        temp_config = config.copy()
        temp_config['ai']['primary_provider'] = provider_name
        temp_config['ai']['fallback_providers'] = []
        
        # Inicializar componentes
        provider_manager = ProviderManager(temp_config)
        prompt_manager = PromptManager(config.get('prompts', {}))
        
        # Criar prompt de teste
        test_code = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. TESTE.
       
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01 WS-CONTADOR PIC 9(3) VALUE 0.
       
       PROCEDURE DIVISION.
       MAIN-PARA.
           DISPLAY "HELLO WORLD".
           STOP RUN.
        """
        
        # Gerar prompt
        prompt = prompt_manager.generate_base_prompt("TESTE", test_code, {})
        
        # Criar requisição
        request = AIRequest(
            prompt=prompt,
            program_name="TESTE",
            timestamp="2025-09-15 13:50:00"
        )
        
        # Fazer análise
        response = provider_manager.analyze(request)
        
        if response and response.content:
            print(f"    Análise bem-sucedida!")
            print(f"      Tokens: {response.tokens_used}")
            print(f"      Tamanho resposta: {len(response.content)} chars")
            print(f"      Preview: {response.content[:100]}...")
            return True
        else:
            print(f"    Análise falhou - resposta vazia")
            return False
            
    except Exception as e:
        print(f"    Erro na análise: {str(e)}")
        return False

def main():
    """Função principal."""
    print("COBOL AI Engine - Teste de Provedores")
    print("=" * 50)
    
    try:
        # Carregar configuração
        with open('config/config_unified.yaml', 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)
        
        print(" Configuração carregada")
        
        # Lista de provedores para testar
        providers_to_test = [
            "enhanced_mock",
            "basic", 
            "luzia",
            "openai",
            "databricks",
            "bedrock"
        ]
        
        available_providers = []
        
        # Teste 1: Disponibilidade
        print("\n" + "=" * 30)
        print("TESTE 1: DISPONIBILIDADE")
        print("=" * 30)
        
        for provider in providers_to_test:
            if test_provider(provider, config):
                available_providers.append(provider)
        
        # Teste 2: Análise real (apenas com provedores disponíveis)
        print("\n" + "=" * 30)
        print("TESTE 2: ANÁLISE REAL")
        print("=" * 30)
        
        working_providers = []
        
        for provider in available_providers[:3]:  # Testar apenas os 3 primeiros disponíveis
            if test_analysis_with_provider(provider, config):
                working_providers.append(provider)
        
        # Resumo final
        print("\n" + "=" * 50)
        print("RESUMO FINAL")
        print("=" * 50)
        
        print(f" Provedores testados: {len(providers_to_test)}")
        print(f" Disponíveis: {len(available_providers)} - {available_providers}")
        print(f"🧪 Funcionando: {len(working_providers)} - {working_providers}")
        
        if working_providers:
            recommended = working_providers[0]
            print(f"\n RECOMENDAÇÃO: Use '{recommended}' como provedor primário")
            print(f"   Para alterar: edite config/config_unified.yaml")
            print(f"   primary_provider: \"{recommended}\"")
        else:
            print(f"\n⚠  ATENÇÃO: Nenhum provedor está funcionando completamente")
            print(f"   Verifique credenciais e conectividade")
        
        # Instruções específicas para LuzIA
        if "luzia" not in available_providers:
            print(f"\n💡 LUZIA: Para usar o LuzIA, você precisa:")
            print(f"   1. Estar conectado à rede corporativa do Santander")
            print(f"   2. Ou usar VPN corporativa")
            print(f"   3. Verificar se as credenciais estão corretas")
        
    except Exception as e:
        print(f"\n ERRO GERAL: {str(e)}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()

