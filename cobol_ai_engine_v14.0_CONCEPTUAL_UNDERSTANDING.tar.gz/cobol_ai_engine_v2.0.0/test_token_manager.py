#!/usr/bin/env python3.11
"""
Teste específico para TokenManager
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.core.config import ConfigManager
from src.core.token_manager import TokenManager

try:
    print("Testando TokenManager...")
    
    config_manager = ConfigManager("config/config_unified.yaml")
    config = config_manager.get_config()
    print("Configuração carregada com sucesso!")
    
    print("Criando TokenManager...")
    token_manager = TokenManager(config)
    print("TokenManager criado com sucesso!")
    
    print("Teste concluído com sucesso!")
    
except Exception as e:
    print(f"Erro no teste: {e}")
    import traceback
    traceback.print_exc()
