import os
import logging
import argparse
from datetime import datetime
from typing import Dict, Any, List

# Importar os componentes necessários
from src.parsers.multi_program_cobol_parser import MultiProgramCobolParser
from src.parsers.final_record_layout_parser import FinalRecordLayoutParser
from src.parsers.final_cobol_structure_analyzer import FinalCOBOLStructureAnalyzer
from src.analyzers.direct_code_analyzer import DirectCodeAnalyzer
from src.analyzers.copybook_llm_analyzer import CopybookLLMAnalyzer
from src.generators.advanced_documentation_generator import AdvancedDocumentationGenerator
from src.providers.luzia_provider_aws import LuziaAWSProvider

class COBOLAIEngineV10:
    """
    COBOL AI Engine v10.0 - Análise Completa com Simulação de Arquivos
    
    Combina análise direta + copybooks + LLM para resolver o gap crítico
    dos arquivos de entrada não detectados, permitindo reimplementação completa.
    """

    def __init__(self, programs_dir: str, books_dir: str, output_dir: str, books_file: str = None):
        self.logger = logging.getLogger(__name__)
        self.programs_dir = programs_dir
        self.output_dir = output_dir
        self.books_file = books_file or "/home/ubuntu/cobol_ai_engine_v2.0.0/examples/BOOKS.txt"

        if not os.path.exists(self.output_dir):
            os.makedirs(self.output_dir)

        # Carregar conteúdo dos copybooks
        self.copybooks_content = self._load_copybooks_content()

        # Inicializar componentes
        self.multi_parser = MultiProgramCobolParser(books_dir)
        self.layout_parser = FinalRecordLayoutParser()
        self.structure_analyzer = FinalCOBOLStructureAnalyzer()
        self.direct_analyzer = DirectCodeAnalyzer()
        
        # Configurar LLM provider (simulado por enquanto)
        luzia_config = {"model_id": "anthropic.claude-3-5-sonnet-20240620-v1:0"}
        llm_provider = LuziaAWSProvider(config=luzia_config)
        
        # Analisador de copybooks com LLM
        self.copybook_analyzer = CopybookLLMAnalyzer(llm_provider)
        
        # Gerador de documentação
        self.doc_generator = AdvancedDocumentationGenerator()

        self.logger.info("COBOL AI Engine v10.0 - Análise Completa com Simulação inicializado")

    def _load_copybooks_content(self) -> str:
        """Carrega o conteúdo completo do arquivo books.txt."""
        try:
            with open(self.books_file, 'r', encoding='latin-1') as f:
                content = f.read()
            self.logger.info(f"Copybooks carregados de: {self.books_file}")
            return content
        except FileNotFoundError:
            self.logger.warning(f"Arquivo de copybooks não encontrado: {self.books_file}")
            return ""

    def analyze_program(self, program_path: str, program_name: str) -> Dict[str, Any]:
        """Realiza análise completa de um programa individual."""
        self.logger.info(f"=== Iniciando análise completa v10.0: {program_name} ===")

        try:
            # 1. Parse do programa e resolução de COPYs
            self.logger.info("Fase 1: Parsing e resolução de copybooks")
            resolved_code_lines = self.multi_parser.parse(program_path)
            resolved_code_str = "".join(resolved_code_lines)

            # 2. Análise Estrutural
            self.logger.info("Fase 2: Análise estrutural")
            structural_analysis = self.structure_analyzer.analyze(resolved_code_lines)

            # 3. Análise de Layout de Registro
            self.logger.info("Fase 3: Análise de layouts de registro")
            record_layouts = self.layout_parser.parse(resolved_code_lines)

            # 4. Análise Direta Completa
            self.logger.info("Fase 4: Análise direta do código")
            direct_analysis = self.direct_analyzer.analyze(program_name, resolved_code_str)

            # 5. NOVA FASE: Simulação de Arquivos com Copybooks + LLM
            self.logger.info("Fase 5: Simulação de arquivos de entrada com copybooks + LLM")
            file_simulation = self.copybook_analyzer.analyze_missing_files(
                program_name, resolved_code_str, self.copybooks_content, direct_analysis
            )

            # 6. Integrar resultados da simulação na análise funcional
            enhanced_analysis = self._integrate_simulation_results(direct_analysis, file_simulation)

            # 7. Montar resultados completos
            analysis_results = {
                "program_name": program_name,
                "resolved_code": resolved_code_str,
                "structural_analysis": structural_analysis,
                "record_layouts": record_layouts,
                "functional_analysis": enhanced_analysis,
                "file_simulation": file_simulation,
                "analysis_timestamp": datetime.now().isoformat(),
                "engine_version": "10.0"
            }

            self.logger.info(f"Análise completa de {program_name} concluída com sucesso")
            return analysis_results

        except Exception as e:
            self.logger.error(f"Erro na análise do programa {program_name}: {e}", exc_info=True)
            return {
                "program_name": program_name,
                "error": str(e),
                "analysis_timestamp": datetime.now().isoformat(),
                "engine_version": "10.0"
            }

    def _integrate_simulation_results(self, direct_analysis: Dict[str, Any], 
                                    file_simulation: Dict[str, Any]) -> Dict[str, Any]:
        """Integra os resultados da simulação de arquivos na análise funcional."""
        enhanced_analysis = direct_analysis.copy()
        
        # Substitui ou complementa os arquivos de entrada
        simulated_files = file_simulation.get("simulated_input_files", [])
        if simulated_files:
            enhanced_analysis["input_files"] = simulated_files
            self.logger.info(f"Integrados {len(simulated_files)} arquivos de entrada simulados")
        
        # Adiciona informações sobre copybooks relevantes
        relevant_copybooks = file_simulation.get("relevant_copybooks", {})
        if relevant_copybooks:
            enhanced_analysis["copybooks_used"] = list(relevant_copybooks.keys())
            enhanced_analysis["copybook_details"] = relevant_copybooks
        
        # Adiciona metadados da simulação
        enhanced_analysis["simulation_metadata"] = {
            "method": file_simulation.get("simulation_method", "unknown"),
            "files_mentioned": len(file_simulation.get("mentioned_files", [])),
            "copybooks_found": len(relevant_copybooks)
        }
        
        return enhanced_analysis

    def generate_documentation(self, analysis_results: Dict[str, Any], target_language: str = "java") -> str:
        """Gera documentação avançada baseada na análise completa."""
        program_name = analysis_results.get("program_name", "UNKNOWN")
        
        if "error" in analysis_results:
            return f"""# Erro na Análise: {program_name}

**Erro:** {analysis_results['error']}
**Data:** {analysis_results.get('analysis_timestamp', 'N/A')}
**Versão:** {analysis_results.get('engine_version', 'N/A')}

A análise deste programa falhou. Verifique o código-fonte e tente novamente.
"""

        # Gera documentação padrão
        base_documentation = self.doc_generator.generate(analysis_results, target_language)
        
        # Adiciona seção específica sobre simulação de arquivos
        simulation_section = self._generate_simulation_section(analysis_results)
        
        # Combina as documentações
        enhanced_documentation = base_documentation + "\n\n" + simulation_section
        
        return enhanced_documentation

    def _generate_simulation_section(self, analysis_results: Dict[str, Any]) -> str:
        """Gera seção específica sobre a simulação de arquivos."""
        file_simulation = analysis_results.get("file_simulation", {})
        
        if not file_simulation:
            return ""
        
        doc = ["## 7. Simulação de Arquivos de Entrada"]
        doc.append("*Esta seção foi gerada através da análise de copybooks e simulação inteligente.*")
        doc.append("")
        
        # Método de simulação
        method = file_simulation.get("simulation_method", "unknown")
        doc.append(f"**Método de Simulação:** {method.upper()}")
        doc.append("")
        
        # Copybooks utilizados
        copybooks = file_simulation.get("relevant_copybooks", {})
        if copybooks:
            doc.append("### 7.1 Copybooks Relevantes")
            doc.append("| Copybook | Descrição |")
            doc.append("|---|---|")
            for name in copybooks.keys():
                doc.append(f"| {name} | Copybook utilizado pelo programa |")
            doc.append("")
        
        # Arquivos simulados
        simulated_files = file_simulation.get("simulated_input_files", [])
        if simulated_files:
            doc.append("### 7.2 Arquivos de Entrada Simulados")
            for file_info in simulated_files:
                doc.append(f"#### {file_info.get('logical_name', 'N/A')}")
                doc.append(f"**Propósito:** {file_info.get('business_purpose', 'N/A')}")
                doc.append(f"**Tamanho do Registro:** {file_info.get('record_size', 'N/A')} bytes")
                doc.append(f"**Lógica de Processamento:** {file_info.get('processing_logic', 'N/A')}")
                doc.append("")
                
                # Campos do arquivo
                fields = file_info.get('fields', [])
                if fields:
                    doc.append("**Estrutura de Campos:**")
                    doc.append("| Campo | Posição | Tamanho | Tipo | PIC | Descrição |")
                    doc.append("|---|---|---|---|---|---|")
                    for field in fields:
                        doc.append(f"| {field.get('name', 'N/A')} | {field.get('position', 'N/A')} | {field.get('length', 'N/A')} | {field.get('type', 'N/A')} | {field.get('picture', 'N/A')} | {field.get('description', 'N/A')} |")
                    doc.append("")
        
        # Estatísticas da simulação
        metadata = analysis_results.get("functional_analysis", {}).get("simulation_metadata", {})
        if metadata:
            doc.append("### 7.3 Estatísticas da Simulação")
            doc.append(f"- **Arquivos Mencionados no Código:** {metadata.get('files_mentioned', 0)}")
            doc.append(f"- **Copybooks Encontrados:** {metadata.get('copybooks_found', 0)}")
            doc.append(f"- **Método Utilizado:** {metadata.get('method', 'N/A')}")
        
        return "\n".join(doc)

    def run_batch_analysis(self, target_language: str = "java"):
        """Executa análise em lote de todos os programas."""
        self.logger.info(f"Iniciando análise em lote v10.0 - diretório: {self.programs_dir}")
        
        program_files = [f for f in os.listdir(self.programs_dir) if f.endswith(".cbl")]
        total_programs = len(program_files)
        
        self.logger.info(f"Encontrados {total_programs} programas para análise")

        results_summary = []

        for i, program_file in enumerate(program_files, 1):
            program_path = os.path.join(self.programs_dir, program_file)
            program_name = os.path.splitext(program_file)[0]
            
            self.logger.info(f"[{i}/{total_programs}] Processando: {program_name}")

            # Análise do programa
            analysis_results = self.analyze_program(program_path, program_name)
            
            # Geração de documentação
            documentation = self.generate_documentation(analysis_results, target_language)
            
            # Salvar documentação
            doc_file_path = os.path.join(self.output_dir, f"{program_name}_DOCS_v10.md")
            with open(doc_file_path, "w", encoding="utf-8") as f:
                f.write(documentation)
            
            # Salvar análise completa em JSON
            import json
            json_file_path = os.path.join(self.output_dir, f"{program_name}_ANALYSIS_v10.json")
            with open(json_file_path, "w", encoding="utf-8") as f:
                json.dump(analysis_results, f, indent=2, ensure_ascii=False, default=str)

            success = "error" not in analysis_results
            
            # Estatísticas específicas da v10.0
            stats = self._calculate_analysis_stats(analysis_results)
            
            results_summary.append({
                "program": program_name,
                "success": success,
                "doc_file": doc_file_path,
                "json_file": json_file_path,
                "stats": stats
            })

            status = "✓ Sucesso" if success else "✗ Erro"
            self.logger.info(f"[{i}/{total_programs}] {program_name}: {status}")

        # Gerar relatório consolidado
        self._generate_consolidated_report(results_summary)
        
        self.logger.info("Análise em lote v10.0 concluída")
        return results_summary

    def _calculate_analysis_stats(self, analysis_results: Dict[str, Any]) -> Dict[str, Any]:
        """Calcula estatísticas específicas da análise v10.0."""
        if "error" in analysis_results:
            return {"error": True}
        
        functional_analysis = analysis_results.get("functional_analysis", {})
        file_simulation = analysis_results.get("file_simulation", {})
        
        return {
            "input_files_detected": len(functional_analysis.get("input_files", [])),
            "output_files_detected": len(functional_analysis.get("output_files", [])),
            "copybooks_used": len(functional_analysis.get("copybooks_used", [])),
            "simulation_method": file_simulation.get("simulation_method", "none"),
            "files_simulated": len(file_simulation.get("simulated_input_files", [])),
            "business_logic_steps": len(functional_analysis.get("business_logic", [])),
            "constants_found": len(functional_analysis.get("constants_and_limits", []))
        }

    def _generate_consolidated_report(self, results_summary: List[Dict]):
        """Gera um relatório consolidado específico da v10.0."""
        report_path = os.path.join(self.output_dir, "RELATORIO_CONSOLIDADO_v10.md")
        
        with open(report_path, "w", encoding="utf-8") as f:
            f.write("# Relatório Consolidado - COBOL AI Engine v10.0\n\n")
            f.write(f"**Data da Análise:** {datetime.now().strftime('%d/%m/%Y %H:%M')}\n")
            f.write(f"**Versão:** 10.0 - Análise Completa com Simulação de Arquivos\n")
            f.write(f"**Inovação:** Integração de copybooks + LLM para resolver gap de arquivos de entrada\n\n")
            
            successful = sum(1 for r in results_summary if r["success"])
            total = len(results_summary)
            
            f.write(f"## Resumo da Execução\n\n")
            f.write(f"- **Total de Programas:** {total}\n")
            f.write(f"- **Analisados com Sucesso:** {successful}\n")
            f.write(f"- **Falhas:** {total - successful}\n")
            f.write(f"- **Taxa de Sucesso:** {(successful/total*100):.1f}%\n\n")
            
            # Estatísticas específicas da v10.0
            self._write_v10_statistics(f, results_summary)
            
            f.write("## Programas Analisados\n\n")
            f.write("| Programa | Status | Arq. Entrada | Arq. Saída | Copybooks | Simulação | Documentação |\n")
            f.write("|---|---|---|---|---|---|---|\n")
            
            for result in results_summary:
                status = "✓ Sucesso" if result["success"] else "✗ Erro"
                stats = result.get("stats", {})
                
                if not stats.get("error", False):
                    input_files = stats.get("input_files_detected", 0)
                    output_files = stats.get("output_files_detected", 0)
                    copybooks = stats.get("copybooks_used", 0)
                    simulation = stats.get("simulation_method", "none")
                    doc_file = os.path.basename(result["doc_file"])
                    
                    f.write(f"| {result['program']} | {status} | {input_files} | {output_files} | {copybooks} | {simulation} | [{doc_file}](./{doc_file}) |\n")
                else:
                    doc_file = os.path.basename(result["doc_file"])
                    f.write(f"| {result['program']} | {status} | - | - | - | - | [{doc_file}](./{doc_file}) |\n")

        self.logger.info(f"Relatório consolidado v10.0 salvo em: {report_path}")

    def _write_v10_statistics(self, f, results_summary: List[Dict]):
        """Escreve estatísticas específicas da versão 10.0."""
        successful_results = [r for r in results_summary if r["success"] and not r.get("stats", {}).get("error", False)]
        
        if not successful_results:
            return
        
        # Calcula médias
        total_input_files = sum(r["stats"].get("input_files_detected", 0) for r in successful_results)
        total_output_files = sum(r["stats"].get("output_files_detected", 0) for r in successful_results)
        total_copybooks = sum(r["stats"].get("copybooks_used", 0) for r in successful_results)
        total_simulated = sum(r["stats"].get("files_simulated", 0) for r in successful_results)
        
        # Métodos de simulação
        simulation_methods = {}
        for r in successful_results:
            method = r["stats"].get("simulation_method", "none")
            simulation_methods[method] = simulation_methods.get(method, 0) + 1
        
        f.write(f"## Estatísticas da Versão 10.0\n\n")
        f.write(f"### Detecção de Arquivos\n")
        f.write(f"- **Total de Arquivos de Entrada Detectados:** {total_input_files}\n")
        f.write(f"- **Total de Arquivos de Saída Detectados:** {total_output_files}\n")
        f.write(f"- **Total de Arquivos Simulados:** {total_simulated}\n")
        f.write(f"- **Copybooks Utilizados:** {total_copybooks}\n\n")
        
        f.write(f"### Métodos de Simulação Utilizados\n")
        for method, count in simulation_methods.items():
            f.write(f"- **{method.title()}:** {count} programas\n")
        f.write("\n")

if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO, 
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )

    parser = argparse.ArgumentParser(description="COBOL AI Engine v10.0 - Análise Completa com Simulação")
    parser.add_argument("--programs-dir", type=str, 
                       default="/home/ubuntu/cobol_ai_engine_v2.0.0/extracted_programs", 
                       help="Diretório com os programas COBOL extraídos")
    parser.add_argument("--books-dir", type=str, 
                       default="/home/ubuntu/cobol_ai_engine_v2.0.0/extracted_books", 
                       help="Diretório com os copybooks extraídos")
    parser.add_argument("--books-file", type=str, 
                       default="/home/ubuntu/cobol_ai_engine_v2.0.0/examples/BOOKS.txt", 
                       help="Arquivo books.txt com copybooks")
    parser.add_argument("--output-dir", type=str, 
                       default="/home/ubuntu/cobol_ai_engine_v2.0.0/complete_analysis_results_v10", 
                       help="Diretório para salvar os resultados")
    parser.add_argument("--target-language", type=str, default="java", 
                       choices=["java", "python"], 
                       help="Linguagem alvo para o guia de implementação")
    
    args = parser.parse_args()

    engine = COBOLAIEngineV10(args.programs_dir, args.books_dir, args.output_dir, args.books_file)
    results = engine.run_batch_analysis(args.target_language)
    
    print(f"\n=== Análise v10.0 Concluída ===")
    print(f"Resultados salvos em: {args.output_dir}")
    print(f"Programas processados: {len(results)}")
    successful = sum(1 for r in results if r["success"])
    print(f"Taxa de sucesso: {(successful/len(results)*100):.1f}%")
    
    # Estatísticas específicas da v10.0
    print(f"\n=== Estatísticas v10.0 ===")
    for result in results:
        if result["success"] and not result.get("stats", {}).get("error", False):
            stats = result["stats"]
            print(f"✓ {result['program']}: {stats.get('input_files_detected', 0)} entrada(s), {stats.get('files_simulated', 0)} simulado(s), {stats.get('copybooks_used', 0)} copybook(s)")
        else:
            print(f"✗ {result['program']}: Erro na análise")
