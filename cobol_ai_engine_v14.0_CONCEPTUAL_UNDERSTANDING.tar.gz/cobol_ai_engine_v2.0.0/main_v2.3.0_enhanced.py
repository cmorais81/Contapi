#!/usr/bin/env python3.11
# -*- coding: utf-8 -*-
"""
COBOL AI Engine v2.3.0 Enhanced - Script Principal
Sistema completo com todas as melhorias da avaliação crítica aplicadas

Autor: Manus AI
Data: 17 de Setembro de 2025
"""

import argparse
import logging
import os
import sys
import time
from pathlib import Path
from typing import Dict, Any, List, Optional

# Adicionar src ao path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '.')))

# Imports do sistema
from src.core.config import ConfigManager
from src.core.preset_manager import PresetManager, PresetInfo
from src.core.input_validator import InputValidator, ValidationLevel
from src.core.token_manager import TokenManager
from src.parsers.cobol_parser import COBOLParser
from src.analyzers.cobol_code_analyzer import COBOLCodeAnalyzer
from src.providers.provider_manager import ProviderManager
from src.providers.multi_provider_analyzer import MultiProviderAnalyzer
from src.generators.programmer_documentation_generator import ProgrammerDocumentationGenerator
from src.utils.pdf_converter import MarkdownToPDFConverter
from src.core.exceptions import ConfigurationError


class COBOLAIEngineV23Enhanced:
    """
    COBOL AI Engine v2.3.0 Enhanced
    
    Sistema completo com todas as melhorias da avaliação crítica:
    - Documentação simplificada
    - Presets pré-configurados
    - Validação robusta
    - Diagramas visuais
    - Interface amigável
    """
    
    def __init__(self):
        """Inicializa o sistema aprimorado."""
        self.version = "2.3.0 Enhanced"
        self.logger = self._setup_logging()
        
        # Componentes principais
        self.config_manager = None
        self.preset_manager = PresetManager()
        self.input_validator = None
        self.token_manager = None
        self.parser = COBOLParser()
        self.analyzer = COBOLCodeAnalyzer()
        self.provider_manager = None
        self.multi_provider = None
        self.doc_generator = None
        self.pdf_converter = MarkdownToPDFConverter()
        
        # Estado da execução
        self.config = {}
        self.preset_applied = None
        self.validation_results = []
        self.analysis_results = []
        self.execution_stats = {}
        
        self.logger.info(f"COBOL AI Engine v{self.version} inicializado")
    
    def _setup_logging(self) -> logging.Logger:
        """Configura sistema de logging aprimorado."""
        log_dir = Path('logs')
        log_dir.mkdir(exist_ok=True)
        
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_dir / f'cobol_ai_engine_v2.3.0_{int(time.time())}.log'),
                logging.StreamHandler(sys.stdout)
            ]
        )
        
        return logging.getLogger(__name__)
    
    def run(self, args: argparse.Namespace) -> int:
        """Executa o sistema principal com todas as melhorias."""
        try:
            start_time = time.time()
            
            if not self._load_configuration(args):
                return 1
            
            if args.preset:
                if not self._apply_preset(args.preset):
                    return 1
            
            if not self._validate_inputs(args):
                return 1
            
            if not self._initialize_components():
                return 1
            
            if not self._process_cobol_files(args):
                return 1
            
            if not self._generate_documentation(args):
                return 1
            
            end_time = time.time()
            self._generate_execution_stats(start_time, end_time)
            self._display_success_summary(args)
            
            return 0
            
        except KeyboardInterrupt:
            self.logger.warning("Execução interrompida pelo usuário")
            return 1
        except Exception as e:
            self.logger.error(f"Erro crítico durante execução: {str(e)}", exc_info=True)
            return 1
    
    def _load_configuration(self, args: argparse.Namespace) -> bool:
        """Carrega configuração do sistema."""
        self.logger.info("=== ETAPA 1: CARREGANDO CONFIGURAÇÃO ===")
        try:
            config_file = args.config or 'config/config_unified.yaml'
            if not os.path.exists(config_file):
                self.logger.error(f"Arquivo de configuração não encontrado: {config_file}")
                return False
            
            self.config_manager = ConfigManager(config_file)
            self.config = self.config_manager.get_config()
            self.logger.info(f"Configuração carregada: {config_file}")
            return True
        except Exception as e:
            self.logger.error(f"Erro ao carregar configuração: {str(e)}")
            return False

    def _apply_preset(self, preset_name: str) -> bool:
        """Aplica preset à configuração."""
        self.logger.info(f"=== ETAPA 2: APLICANDO PRESET '{preset_name}' ===")
        try:
            preset_info = self.preset_manager.get_preset(preset_name)
            if not preset_info:
                self.logger.error(f"Preset '{preset_name}' não encontrado")
                self._list_available_presets()
                return False

            available_providers = self._get_available_providers()
            if not self.preset_manager.validate_preset_compatibility(preset_name, available_providers):
                self.logger.error(f"Preset '{preset_name}' não é compatível com providers disponíveis: {available_providers}")
                return False

            self.config = self.preset_manager.apply_preset(preset_name, self.config)
            self.preset_applied = preset_info
            self.logger.info(f"Preset aplicado: {preset_info.description}")
            return True
        except Exception as e:
            self.logger.error(f"Erro ao aplicar preset: {str(e)}")
            return False

    def _validate_inputs(self, args: argparse.Namespace) -> bool:
        """Valida todas as entradas do sistema."""
        self.logger.info("=== ETAPA 3: VALIDANDO ENTRADAS ===")
        try:
            validation_level = ValidationLevel.STANDARD
            if self.preset_applied and ('paranoid' in self.preset_applied.name or 'audit' in self.preset_applied.name):
                validation_level = ValidationLevel.STRICT
            
            self.input_validator = InputValidator(validation_level)
            
            sources_file = args.fontes or 'examples/fontes.txt'
            sources_validation = self.input_validator.validate_source_files(sources_file)
            self.validation_results.append(('sources', sources_validation))
            if not sources_validation.is_valid:
                self.logger.error("Validação de fontes falhou: " + "; ".join(sources_validation.errors))
                return False

            if args.books:
                books_validation = self.input_validator.validate_copybooks_file(args.books)
                self.validation_results.append(('copybooks', books_validation))
                if not books_validation.is_valid:
                    self.logger.error("Validação de copybooks falhou: " + "; ".join(books_validation.errors))
                    return False

            config_validation = self.input_validator.validate_configuration(self.config)
            self.validation_results.append(('configuration', config_validation))
            if not config_validation.is_valid:
                self.logger.error("Validação de configuração falhou: " + "; ".join(config_validation.errors))
                return False

            self.logger.info("Validação concluída com sucesso.")
            return True
        except Exception as e:
            self.logger.error(f"Erro durante validação: {str(e)}")
            return False

    def _initialize_components(self) -> bool:
        """Inicializa todos os componentes do sistema."""
        self.logger.info("=== ETAPA 4: INICIALIZANDO COMPONENTES ===")
        try:
            self.token_manager = TokenManager(self.config)
            self.provider_manager = ProviderManager(self.config)
            if not self.provider_manager.get_available_providers():
                self.logger.error("Nenhum provider de IA disponível ou habilitado na configuração.")
                return False
            
            if self.config.get('multi_provider', {}).get('enabled', False):
                self.multi_provider = MultiProviderAnalyzer(self.config, self.provider_manager)
                self.logger.info("Sistema multi-provider habilitado.")
            
            self.doc_generator = ProgrammerDocumentationGenerator(self.config)
            self.logger.info("Todos os componentes inicializados com sucesso.")
            return True
        except Exception as e:
            self.logger.error(f"Erro ao inicializar componentes: {str(e)}")
            return False

    def _process_cobol_files(self, args: argparse.Namespace) -> bool:
        """Processa arquivos COBOL com análise completa."""
        self.logger.info("=== ETAPA 5: PROCESSANDO ARQUIVOS COBOL ===")
        try:
            sources_validation = next((r[1] for r in self.validation_results if r[0] == 'sources'), None)
            if not sources_validation:
                self.logger.error("Validação de fontes não encontrada.")
                return False

            cobol_files = [info.path for info in sources_validation.metadata.get('cobol_files_info', []) if info.has_cobol_structure]
            if not cobol_files:
                self.logger.error("Nenhum arquivo COBOL válido para processar.")
                return False

            self.logger.info(f"Processando {len(cobol_files)} arquivos COBOL...")
            for i, file_path in enumerate(cobol_files, 1):
                self.logger.info(f"Processando arquivo {i}/{len(cobol_files)}: {Path(file_path).name}")
                try:
                    program_data = self.parser.parse_file(file_path)
                    analysis_result = self.analyzer.analyze_program(program_data['content'], program_data['name'])
                    
                    ai_analysis = None
                    if self.multi_provider:
                        ai_analysis = self.multi_provider.analyze_with_multiple_providers(program_data, analysis_result)
                    elif self.provider_manager:
                        primary_provider = self.provider_manager.get_primary_provider()
                        if primary_provider:
                            ai_analysis = primary_provider.analyze(program_data, analysis_result)

                    if not ai_analysis:
                        raise Exception("Nenhuma análise de IA foi produzida.")

                    self.analysis_results.append({
                        'program_data': program_data, 'pre_analysis': analysis_result,
                        'ai_analysis': ai_analysis, 'file_path': file_path
                    })
                    self.logger.info(f"  ✓ Análise concluída para {Path(file_path).name}")
                except Exception as e:
                    self.logger.error(f"  ✗ Erro ao processar {Path(file_path).name}: {str(e)}", exc_info=True)
                    continue
            
            if not self.analysis_results:
                self.logger.error("Nenhuma análise foi concluída com sucesso.")
                return False
            
            self.logger.info(f"Processamento concluído: {len(self.analysis_results)} análises bem-sucedidas.")
            return True
        except Exception as e:
            self.logger.error(f"Erro durante processamento: {str(e)}", exc_info=True)
            return False

    def _generate_documentation(self, args: argparse.Namespace) -> bool:
        """Gera documentação completa."""
        self.logger.info("=== ETAPA 6: GERANDO DOCUMENTAÇÃO ===")
        try:
            output_dir = Path(args.output or 'output_v2.3.0_enhanced')
            output_dir.mkdir(exist_ok=True)
            self.logger.info(f"Gerando documentação em: {output_dir}")

            generated_docs = []
            for result in self.analysis_results:
                program_name = result['program_data']['name']
                try:
                    doc_content = self.doc_generator.generate_comprehensive_documentation(
                        result['program_data'], result['pre_analysis'], result['ai_analysis']
                    )
                    md_file = output_dir / f"{program_name}_DOCS_v2.3.0.md"
                    with open(md_file, 'w', encoding='utf-8') as f:
                        f.write(doc_content)

                    if args.pdf or self.config.get('output', {}).get('generate_pdf', False):
                        html_file = output_dir / f"{program_name}_DOCS_v2.3.0.html"
                        self.pdf_converter.convert_to_pdf(str(md_file), str(html_file))
                    
                    generated_docs.append({'program_name': program_name, 'md_path': str(md_file)})
                except Exception as e:
                    self.logger.error(f"Erro ao gerar documentação para {program_name}: {str(e)}")

            if not generated_docs:
                self.logger.error("Nenhuma documentação foi gerada.")
                return False

            self.logger.info(f"Documentação gerada para {len(generated_docs)} programa(s).")
            return True
        except Exception as e:
            self.logger.error(f"Erro ao gerar documentação: {str(e)}")
            return False

    def _generate_execution_stats(self, start_time: float, end_time: float):
        """Gera e exibe estatísticas de execução."""
        self.execution_stats = {
            'total_time': end_time - start_time,
            'programs_processed': len(self.analysis_results),
            'providers_used': self._get_providers_used(),
            'preset_applied': self.preset_applied.name if self.preset_applied else 'N/A'
        }

    def _display_success_summary(self, args: argparse.Namespace):
        """Exibe um resumo de sucesso amigável."""
        self.logger.info("=" * 60)
        self.logger.info("🎉 ANÁLISE CONCLUÍDA COM SUCESSO 🎉")
        self.logger.info("=" * 60)
        self.logger.info(f"Versão do Engine: {self.version}")
        self.logger.info(f"Preset Utilizado: {self.execution_stats['preset_applied']}")
        self.logger.info(f"Programas Analisados: {self.execution_stats['programs_processed']}")
        self.logger.info(f"Tempo Total: {self.execution_stats['total_time']:.2f} segundos")
        self.logger.info(f"Documentação gerada em: {args.output or 'output_v2.3.0_enhanced'}")
        self.logger.info("=" * 60)

    def _get_available_providers(self) -> List[str]:
        """Retorna uma lista de providers disponíveis."""
        ai_config = self.config.get('ai', {})
        if not isinstance(ai_config, dict): return []
        providers_config = ai_config.get('providers', {})
        if not isinstance(providers_config, dict): return []
        return [name for name, conf in providers_config.items() if isinstance(conf, dict) and conf.get('enabled', False)]

    def _get_providers_used(self) -> List[str]:
        """Retorna lista de providers efetivamente utilizados."""
        if self.multi_provider:
            return self.multi_provider.get_active_providers()
        if self.provider_manager:
            primary = self.provider_manager.get_primary_provider()
            return [primary.name] if primary else []
        return []

    def _list_available_presets(self):
        """Lista presets disponíveis."""
        self.logger.info("Presets disponíveis:")
        for preset in self.preset_manager.list_presets():
            self.logger.info(f"  - {preset.name}: {preset.description}")

def create_argument_parser() -> argparse.ArgumentParser:
    """Cria parser de argumentos aprimorado."""
    parser = argparse.ArgumentParser(
        description=f'COBOL AI Engine v2.3.0 Enhanced - Análise inteligente de código COBOL',
        formatter_class=argparse.RawTextHelpFormatter,
        epilog="""EXEMPLOS DE USO:
  # Análise com preset para programadores (recomendado)
  python main_v2.3.0_enhanced.py --preset programmer_ready

  # Análise rápida para visão geral
  python main_v2.3.0_enhanced.py --preset quick_overview
"""
    )
    parser.add_argument('--preset', type=str, help='Preset pré-configurado para casos específicos')
    parser.add_argument('--fontes', type=str, default='examples/fontes.txt', help='Arquivo com lista de programas COBOL')
    parser.add_argument('--books', type=str, help='Arquivo com lista de copybooks (opcional)')
    parser.add_argument('--config', type=str, help='Arquivo de configuração (padrão: config/config_unified.yaml)')
    parser.add_argument('--output', type=str, help='Diretório de saída (padrão: output_v2.3.0_enhanced)')
    parser.add_argument('--pdf', action='store_true', help='Gerar documentação em PDF além de HTML/Markdown')
    parser.add_argument('--target-language', type=str, default='java', choices=['java', 'python', 'csharp', 'javascript'], help='Linguagem alvo para exemplos de migração')
    parser.add_argument('--list-presets', action='store_true', help='Listar presets disponíveis e sair')
    parser.add_argument('--validate-only', action='store_true', help='Apenas validar arquivos sem executar análise')
    parser.add_argument('--verbose', action='store_true', help='Modo verboso (mais detalhes no log)')
    parser.add_argument('--version', action='version', version='COBOL AI Engine v2.3.0 Enhanced')
    return parser

def main():
    """Função principal aprimorada."""
    parser = create_argument_parser()
    args = parser.parse_args()
    
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    if args.list_presets:
        preset_manager = PresetManager()
        print(preset_manager.get_preset_summary())
        return 0
    
    engine = COBOLAIEngineV23Enhanced()
    
    if args.validate_only:
        engine._load_configuration(args)
        if engine._validate_inputs(args):
            print("✓ Validação concluída com sucesso")
            return 0
        else:
            print("✗ Validação falhou")
            return 1
    
    return engine.run(args)

if __name__ == '__main__':
    sys.exit(main())

