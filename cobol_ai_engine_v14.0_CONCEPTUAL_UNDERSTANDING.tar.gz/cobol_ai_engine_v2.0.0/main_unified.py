#!/usr/bin/env python3.11
# -*- coding: utf-8 -*-
"""
COBOL AI Engine v2.2.0 Enhanced Analysis - Script Principal Unificado
Sistema de análise inteligente de código COBOL com configuração centralizada

Autor: Manus AI
Data: 17 de Setembro de 2025
"""

import argparse
import logging
import os
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

# Adicionar o diretório src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.core.config import ConfigManager
from src.core.exceptions import COBOLAIEngineException, ProviderError
from src.core.token_manager import TokenManager
from src.parsers.cobol_parser import COBOLParser
from src.providers.provider_manager import ProviderManager
from src.analyzers.cobol_code_analyzer import COBOLCodeAnalyzer
from src.generators.documentation_generator import DocumentationGenerator
from src.utils.pdf_converter import MarkdownToPDFConverter
from src.providers.base_provider import AIRequest

def setup_logging(log_level: str = "INFO") -> None:
    """Configurar logging do sistema"""
    logging.basicConfig(
        level=getattr(logging, log_level.upper()),
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler('logs/cobol_ai_engine.log', 'a', encoding='utf-8')
        ]
    )
    
    # Criar diretório de logs se não existir
    os.makedirs('logs', exist_ok=True)

def parse_arguments() -> argparse.Namespace:
    """Parse dos argumentos da linha de comando"""
    parser = argparse.ArgumentParser(
        description='COBOL AI Engine v2.2.0 Enhanced Analysis - Análise Inteligente de Código COBOL',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Exemplos de uso:

  # Análise básica com configuração padrão
  python main_unified.py --fontes examples/fontes.txt --books examples/BOOKS.txt

  # Análise com saída personalizada
  python main_unified.py --fontes examples/fontes.txt --output minha_analise

  # Análise com nível de log específico
  python main_unified.py --fontes examples/fontes.txt --log-level DEBUG

  # Análise usando configuração customizada
  python main_unified.py --fontes examples/fontes.txt --config config/config_unified.yaml
        """
    )
    
    parser.add_argument(
        '--fontes', 
        required=True,
        help='Arquivo contendo lista de programas COBOL para análise'
    )
    
    parser.add_argument(
        '--books', 
        help='Arquivo contendo lista de copybooks COBOL (opcional)'
    )
    
    parser.add_argument(
        '--config',
        default='config/config_unified.yaml',
        help='Arquivo de configuração YAML (padrão: config/config_unified.yaml)'
    )
    
    parser.add_argument(
        '--output',
        default='output',
        help='Diretório de saída para os relatórios (padrão: output)'
    )
    
    parser.add_argument(
        '--log-level',
        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'],
        default='INFO',
        help='Nível de logging (padrão: INFO)'
    )
    
    parser.add_argument(
        '--provider',
        help='Forçar uso de um provider específico (sobrescreve configuração)'
    )
    
    parser.add_argument(
        '--no-pdf',
        action='store_true',
        help='Desabilitar geração de PDF'
    )
    
    parser.add_argument(
        '--version',
        action='version',
        version='COBOL AI Engine v2.2.0 Enhanced Analysis'
    )
    
    return parser.parse_args()

def load_program_list(file_path: str) -> List[str]:
    """Carregar lista de programas de um arquivo"""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            programs = [line.strip() for line in f if line.strip() and not line.startswith('#')]
        return programs
    except Exception as e:
        logging.error(f"Erro ao carregar lista de programas de {file_path}: {e}")
        return []

def create_pre_analysis_context(program_name: str, business_comments: List[str], 
                              business_rules: List, copybooks: List[str]) -> str:
    """Criar contexto de pré-análise para o prompt"""
    context_parts = []
    
    # Informações básicas
    context_parts.append(f"PROGRAMA: {program_name}")
    
    # Comentários de negócio
    if business_comments:
        context_parts.append(f"COMENTÁRIOS DE NEGÓCIO IDENTIFICADOS: {len(business_comments)}")
        for i, comment in enumerate(business_comments[:5], 1):  # Máximo 5 comentários
            context_parts.append(f"  {i}. {comment}")
    
    # Regras de negócio identificadas
    if business_rules:
        context_parts.append(f"REGRAS DE NEGÓCIO PRÉ-IDENTIFICADAS: {len(business_rules)}")
        
        # Agrupar por tipo
        rule_types = {}
        for rule in business_rules:
            rule_type = getattr(rule, 'rule_type', 'Geral')
            if rule_type not in rule_types:
                rule_types[rule_type] = []
            rule_types[rule_type].append(rule)
        
        for rule_type, rules in rule_types.items():
            context_parts.append(f"  - {rule_type}: {len(rules)} regras")
    
    # Copybooks relacionados
    if copybooks:
        context_parts.append(f"COPYBOOKS RELACIONADOS: {len(copybooks)}")
        for copybook in copybooks[:10]:  # Máximo 10 copybooks
            context_parts.append(f"  - {copybook}")
    
    return "\n".join(context_parts)

def analyze_program_enhanced(program_name: str, program_code: str, 
                           provider_manager: ProviderManager, config: Dict,
                           pre_analysis_context: str) -> Tuple[Optional[str], int]:
    """Realizar análise aprimorada de um programa COBOL"""
    try:
        logging.info(f"Iniciando análise aprimorada de {program_name}")
        
        # Obter prompts da configuração
        system_prompt = config.get('prompts', {}).get('system_prompts', {}).get('detailed_cobol_analysis', '')
        user_template = config.get('prompts', {}).get('user_prompts', {}).get('complete_analysis', '')
        
        # Preparar prompt do usuário
        user_prompt = user_template.format(
            program_name=program_name,
            pre_analysis_context=pre_analysis_context,
            program_code=program_code
        )
        
        # Criar requisição
        request = AIRequest(
            prompt=user_prompt,
            system_prompt=system_prompt,
            max_tokens=config.get('ai', {}).get('global_max_tokens', 8000),
            temperature=config.get('ai', {}).get('providers', {}).get('luzia', {}).get('temperature', 0.05)
        )
        
        # Executar análise usando o sistema de fallback
        response = provider_manager.analyze(request)
        
        if response and response.content:
            token_count = len(response.content.split())  # Estimativa simples
            logging.info(f"Análise aprimorada concluída para {program_name}: {len(response.content)} caracteres gerados")
            return response.content, token_count
        else:
            logging.warning(f"Resposta vazia do provider para {program_name}")
            return None, 0
            
    except Exception as e:
        logging.error(f"Erro na análise aprimorada de {program_name}: {e}")
        return None, 0

def generate_enhanced_documentation(program_name: str, analysis_result: str, 
                                  business_rules: List, output_dir: str) -> bool:
    """Gerar documentação aprimorada"""
    try:
        doc_generator = DocumentationGenerator()
        
        # Preparar dados para documentação
        analysis_data = {
            'program_name': program_name,
            'analysis_content': analysis_result,
            'business_rules': business_rules,
            'timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
            'version': 'v2.2.0 Enhanced Analysis'
        }
        
        # Gerar documentação
        doc_path = os.path.join(output_dir, f"{program_name}.md")
        doc_generator.generate_enhanced_documentation(analysis_data, doc_path)
        
        logging.info(f"Documentação aprimorada gerada: {doc_path}")
        return True
        
    except Exception as e:
        logging.error(f"Erro ao gerar documentação aprimorada para {program_name}: {e}")
        return False

def generate_consolidated_report(results: Dict, output_dir: str, config: Dict) -> str:
    """Gerar relatório consolidado aprimorado"""
    try:
        report_path = os.path.join(output_dir, "relatorio_consolidado_aprimorado.md")
        
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write("# Relatório Consolidado de Análise COBOL - Enhanced Analysis\n\n")
            f.write(f"**Data de Geração:** {time.strftime('%d/%m/%Y %H:%M:%S')}\n")
            f.write(f"**Versão do Sistema:** COBOL AI Engine v2.2.0 Enhanced Analysis\n")
            f.write(f"**Provider Utilizado:** {config.get('ai', {}).get('primary_provider', 'N/A')}\n\n")
            
            # Estatísticas gerais
            total_programs = len(results)
            successful_analyses = sum(1 for r in results.values() if r.get('success', False))
            total_tokens = sum(r.get('tokens', 0) for r in results.values())
            
            f.write("## Estatísticas Gerais\n\n")
            f.write(f"- **Programas Processados:** {total_programs}\n")
            f.write(f"- **Análises Bem-sucedidas:** {successful_analyses}/{total_programs}\n")
            f.write(f"- **Taxa de Sucesso:** {(successful_analyses/total_programs*100):.1f}%\n")
            f.write(f"- **Total de Tokens Utilizados:** {total_tokens:,}\n\n")
            
            # Detalhes por programa
            f.write("## Detalhes por Programa\n\n")
            for program_name, result in results.items():
                f.write(f"### {program_name}\n\n")
                if result.get('success', False):
                    f.write("✅ **Status:** Análise concluída com sucesso\n")
                    f.write(f"- **Tokens Utilizados:** {result.get('tokens', 0):,}\n")
                    f.write(f"- **Regras de Negócio Identificadas:** {result.get('business_rules_count', 0)}\n")
                    if result.get('analysis_preview'):
                        f.write(f"- **Preview da Análise:** {result['analysis_preview'][:200]}...\n")
                else:
                    f.write("❌ **Status:** Falha na análise\n")
                    if result.get('error'):
                        f.write(f"- **Erro:** {result['error']}\n")
                f.write("\n")
            
            # Configurações utilizadas
            f.write("## Configurações Utilizadas\n\n")
            f.write(f"- **Provider Primário:** {config.get('ai', {}).get('primary_provider', 'N/A')}\n")
            f.write(f"- **Max Tokens:** {config.get('ai', {}).get('global_max_tokens', 'N/A')}\n")
            f.write(f"- **Temperature:** {config.get('ai', {}).get('providers', {}).get('luzia', {}).get('temperature', 'N/A')}\n")
            f.write(f"- **Modelo:** {config.get('ai', {}).get('providers', {}).get('luzia', {}).get('model', 'N/A')}\n\n")
            
        logging.info(f"Relatório consolidado aprimorado gerado: {report_path}")
        return report_path
        
    except Exception as e:
        logging.error(f"Erro ao gerar relatório consolidado: {e}")
        return ""

def main():
    """Função principal"""
    try:
        # Parse dos argumentos
        args = parse_arguments()
        
        # Setup do logging
        setup_logging(args.log_level)
        
        logging.info("=== INICIANDO COBOL AI ENGINE v2.2.0 Enhanced Analysis ===")
        logging.info(f"Configuração: {args.config}")
        logging.info(f"Fontes: {args.fontes}")
        logging.info(f"Saída: {args.output}")
        
        # Carregar configuração
        config_manager = ConfigManager(args.config)
        config = config_manager.get_config()
        
        # Sobrescrever provider se especificado
        if args.provider:
            config['ai']['primary_provider'] = args.provider
            logging.info(f"Provider forçado: {args.provider}")
        
        # Criar diretório de saída
        os.makedirs(args.output, exist_ok=True)
        
        # Inicializar componentes
        token_manager = TokenManager(config)
        provider_manager = ProviderManager(config)
        parser = COBOLParser()
        analyzer = COBOLCodeAnalyzer()
        
        # Carregar lista de programas
        logging.info(f"Carregando programas de: {args.fontes}")
        programs, _ = parser.parse_file(args.fontes)
        logging.info(f"Programas identificados: {len(programs)}")
        
        # Carregar copybooks se especificado
        copybooks = []
        if args.books:
            logging.info(f"Carregando copybooks de: {args.books}")
            _, copybooks = parser.parse_file(args.books)
            logging.info(f"Copybooks identificados: {len(copybooks)}")
        
        # Processar cada programa
        results = {}
        start_time = time.time()
        
        for i, program in enumerate(programs, 1):
            program_name = program.name if hasattr(program, 'name') else f'programa_{i}'
            program_code = program.content if hasattr(program, 'content') else ''
            
            logging.info(f"Analisando programa {i}/{len(programs)}: {program_name}")
            
            try:
                # Pré-análise
                logging.info(f"Iniciando pré-análise de {program_name}")
                analysis_result = analyzer.analyze_program(program_code, program_name)
                business_comments = analysis_result.business_comments if hasattr(analysis_result, 'business_comments') else []
                business_rules = analysis_result.business_rules if hasattr(analysis_result, 'business_rules') else []
                logging.info(f"Pré-análise concluída: {len(business_comments)} comentários de negócio, {len(business_rules)} regras identificadas")
                
                # Criar contexto de pré-análise
                pre_analysis_context = create_pre_analysis_context(
                    program_name, business_comments, business_rules, 
                    [cb.name if hasattr(cb, 'name') else '' for cb in copybooks]
                )
                
                # Análise aprimorada
                analysis_result, tokens_used = analyze_program_enhanced(
                    program_name, program_code, provider_manager, config, pre_analysis_context
                )
                
                if analysis_result:
                    # Gerar documentação aprimorada
                    doc_success = generate_enhanced_documentation(
                        program_name, analysis_result, business_rules, args.output
                    )
                    
                    results[program_name] = {
                        'success': True,
                        'tokens': tokens_used,
                        'business_rules_count': len(business_rules),
                        'analysis_preview': analysis_result[:500] if analysis_result else '',
                        'documentation_generated': doc_success
                    }
                else:
                    results[program_name] = {
                        'success': False,
                        'error': 'Falha na análise aprimorada',
                        'tokens': 0
                    }
                    
            except Exception as e:
                logging.error(f"Erro na análise de {program_name}: {e}")
                results[program_name] = {
                    'success': False,
                    'error': str(e),
                    'tokens': 0
                }
        
        # Gerar relatório consolidado
        logging.info("Gerando relatório consolidado aprimorado...")
        report_path = generate_consolidated_report(results, args.output, config)
        
        # Gerar PDF se solicitado
        if not args.no_pdf and report_path and config.get('output', {}).get('enable_pdf', True):
            try:
                pdf_converter = MarkdownToPDFConverter()
                pdf_path = report_path.replace('.md', '.html')
                pdf_converter.convert_to_pdf(report_path, pdf_path)
                logging.info(f"HTML para impressão gerado: {pdf_path}")
            except Exception as e:
                logging.warning(f"Erro ao gerar HTML: {e}")
        
        # Estatísticas finais
        end_time = time.time()
        total_time = end_time - start_time
        successful_analyses = sum(1 for r in results.values() if r.get('success', False))
        total_tokens = sum(r.get('tokens', 0) for r in results.values())
        
        logging.info("=== ANÁLISE APRIMORADA CONCLUÍDA ===")
        logging.info(f"Programas processados: {len(programs)}")
        logging.info(f"Análises bem-sucedidas: {successful_analyses}/{len(programs)}")
        logging.info(f"Taxa de sucesso: {(successful_analyses/len(programs)*100):.1f}%")
        logging.info(f"Total de tokens utilizados: {total_tokens:,}")
        logging.info(f"Tempo de processamento: {total_time:.2f}s")
        logging.info(f"Arquivos gerados em: {args.output}")
        
        # Imprimir estatísticas no console
        print("\n" + "="*50)
        print("=== ANÁLISE APRIMORADA CONCLUÍDA ===")
        print(f"Programas processados: {len(programs)}")
        print(f"Análises bem-sucedidas: {successful_analyses}/{len(programs)}")
        print(f"Taxa de sucesso: {(successful_analyses/len(programs)*100):.1f}%")
        print(f"Total de tokens utilizados: {total_tokens:,}")
        print(f"Tempo de processamento: {total_time:.2f}s")
        print(f"Arquivos gerados em: {args.output}")
        print("="*50)
        
        return 0 if successful_analyses > 0 else 1
        
    except KeyboardInterrupt:
        logging.info("Análise interrompida pelo usuário")
        return 1
    except Exception as e:
        logging.error(f"Erro fatal: {e}")
        return 1

if __name__ == "__main__":
    sys.exit(main())
