import os
import logging
import argparse
from datetime import datetime
from typing import Dict, Any, List

# Importar os componentes necessários
from src.parsers.multi_program_cobol_parser import MultiProgramCobolParser
from src.parsers.final_record_layout_parser import FinalRecordLayoutParser
from src.parsers.final_cobol_structure_analyzer import FinalCOBOLStructureAnalyzer
from src.analyzers.hybrid_advanced_analyzer import HybridAdvancedAnalyzer
from src.generators.advanced_documentation_generator import AdvancedDocumentationGenerator
from src.providers.luzia_provider_aws import LuziaAWSProvider

class COBOLAIEngineV8:
    """
    COBOL AI Engine v8.0 - Análise Híbrida Avançada
    
    Combina código original completo + análise estrutural + LLM
    para máxima efetividade na extração de lógica de negócio.
    """

    def __init__(self, programs_dir: str, books_dir: str, output_dir: str):
        self.logger = logging.getLogger(__name__)
        self.programs_dir = programs_dir
        self.output_dir = output_dir

        if not os.path.exists(self.output_dir):
            os.makedirs(self.output_dir)

        # Inicializar componentes
        self.multi_parser = MultiProgramCobolParser(books_dir)
        self.layout_parser = FinalRecordLayoutParser()
        self.structure_analyzer = FinalCOBOLStructureAnalyzer()
        
        # Configurar o provedor LLM e o analisador híbrido avançado
        luzia_config = {"model_id": "anthropic.claude-3-5-sonnet-20240620-v1:0"}
        self.llm_provider = LuziaAWSProvider(config=luzia_config)
        self.hybrid_analyzer = HybridAdvancedAnalyzer(self.llm_provider)
        
        # Gerador de documentação avançado
        self.doc_generator = AdvancedDocumentationGenerator()

        self.logger.info("COBOL AI Engine v8.0 - Análise Híbrida Avançada inicializado")

    def analyze_program(self, program_path: str, program_name: str) -> Dict[str, Any]:
        """Realiza análise completa de um programa individual."""
        self.logger.info(f"=== Iniciando análise híbrida avançada: {program_name} ===")

        try:
            # 1. Parse do programa e resolução de COPYs
            self.logger.info("Fase 1: Parsing e resolução de copybooks")
            resolved_code_lines = self.multi_parser.parse(program_path)
            resolved_code_str = "".join(resolved_code_lines)

            # 2. Análise Estrutural
            self.logger.info("Fase 2: Análise estrutural")
            structural_analysis = self.structure_analyzer.analyze(resolved_code_lines)

            # 3. Análise de Layout de Registro
            self.logger.info("Fase 3: Análise de layouts de registro")
            record_layouts = self.layout_parser.parse(resolved_code_lines)

            # 4. Análise Híbrida Avançada (código + estrutura + LLM)
            self.logger.info("Fase 4: Análise híbrida avançada com LLM")
            hybrid_analysis = self.hybrid_analyzer.analyze(
                program_name, resolved_code_str, structural_analysis, record_layouts
            )

            # 5. Montar resultados completos
            analysis_results = {
                "program_name": program_name,
                "resolved_code": resolved_code_str,
                "structural_analysis": structural_analysis,
                "record_layouts": record_layouts,
                "functional_analysis": hybrid_analysis,
                "analysis_timestamp": datetime.now().isoformat(),
                "engine_version": "8.0"
            }

            return analysis_results

        except Exception as e:
            self.logger.error(f"Erro na análise do programa {program_name}: {e}", exc_info=True)
            return {
                "program_name": program_name,
                "error": str(e),
                "analysis_timestamp": datetime.now().isoformat(),
                "engine_version": "8.0"
            }

    def generate_documentation(self, analysis_results: Dict[str, Any], target_language: str = "java") -> str:
        """Gera documentação avançada baseada na análise híbrida."""
        program_name = analysis_results.get("program_name", "UNKNOWN")
        
        if "error" in analysis_results:
            return f"""# Erro na Análise: {program_name}

**Erro:** {analysis_results['error']}
**Data:** {analysis_results.get('analysis_timestamp', 'N/A')}
**Versão:** {analysis_results.get('engine_version', 'N/A')}

A análise deste programa falhou. Verifique o código-fonte e tente novamente.
"""

        return self.doc_generator.generate(analysis_results, target_language)

    def run_batch_analysis(self, target_language: str = "java"):
        """Executa análise em lote de todos os programas."""
        self.logger.info(f"Iniciando análise em lote - diretório: {self.programs_dir}")
        
        program_files = [f for f in os.listdir(self.programs_dir) if f.endswith(".cbl")]
        total_programs = len(program_files)
        
        self.logger.info(f"Encontrados {total_programs} programas para análise")

        results_summary = []

        for i, program_file in enumerate(program_files, 1):
            program_path = os.path.join(self.programs_dir, program_file)
            program_name = os.path.splitext(program_file)[0]
            
            self.logger.info(f"[{i}/{total_programs}] Processando: {program_name}")

            # Análise do programa
            analysis_results = self.analyze_program(program_path, program_name)
            
            # Geração de documentação
            documentation = self.generate_documentation(analysis_results, target_language)
            
            # Salvar documentação
            doc_file_path = os.path.join(self.output_dir, f"{program_name}_DOCS_v8.md")
            with open(doc_file_path, "w", encoding="utf-8") as f:
                f.write(documentation)
            
            # Salvar análise completa em JSON para debug
            import json
            json_file_path = os.path.join(self.output_dir, f"{program_name}_ANALYSIS_v8.json")
            with open(json_file_path, "w", encoding="utf-8") as f:
                json.dump(analysis_results, f, indent=2, ensure_ascii=False, default=str)

            success = "error" not in analysis_results
            results_summary.append({
                "program": program_name,
                "success": success,
                "doc_file": doc_file_path,
                "json_file": json_file_path
            })

            self.logger.info(f"[{i}/{total_programs}] {program_name}: {'✓ Sucesso' if success else '✗ Erro'}")

        # Gerar relatório consolidado
        self._generate_consolidated_report(results_summary)
        
        self.logger.info("Análise em lote concluída")
        return results_summary

    def _generate_consolidated_report(self, results_summary: List[Dict]):
        """Gera um relatório consolidado de todos os programas analisados."""
        report_path = os.path.join(self.output_dir, "RELATORIO_CONSOLIDADO_v8.md")
        
        with open(report_path, "w", encoding="utf-8") as f:
            f.write("# Relatório Consolidado - COBOL AI Engine v8.0\n\n")
            f.write(f"**Data da Análise:** {datetime.now().strftime('%d/%m/%Y %H:%M')}\n")
            f.write(f"**Versão:** 8.0 - Análise Híbrida Avançada\n\n")
            
            successful = sum(1 for r in results_summary if r["success"])
            total = len(results_summary)
            
            f.write(f"## Resumo da Execução\n\n")
            f.write(f"- **Total de Programas:** {total}\n")
            f.write(f"- **Analisados com Sucesso:** {successful}\n")
            f.write(f"- **Falhas:** {total - successful}\n")
            f.write(f"- **Taxa de Sucesso:** {(successful/total*100):.1f}%\n\n")
            
            f.write("## Programas Analisados\n\n")
            f.write("| Programa | Status | Documentação | Análise JSON |\n")
            f.write("|---|---|---|---|\n")
            
            for result in results_summary:
                status = "✓ Sucesso" if result["success"] else "✗ Erro"
                doc_file = os.path.basename(result["doc_file"])
                json_file = os.path.basename(result["json_file"])
                f.write(f"| {result['program']} | {status} | [{doc_file}](./{doc_file}) | [{json_file}](./{json_file}) |\n")

        self.logger.info(f"Relatório consolidado salvo em: {report_path}")

if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO, 
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )

    parser = argparse.ArgumentParser(description="COBOL AI Engine v8.0 - Análise Híbrida Avançada")
    parser.add_argument("--programs-dir", type=str, 
                       default="/home/ubuntu/cobol_ai_engine_v2.0.0/extracted_programs", 
                       help="Diretório com os programas COBOL extraídos")
    parser.add_argument("--books-dir", type=str, 
                       default="/home/ubuntu/cobol_ai_engine_v2.0.0/extracted_books", 
                       help="Diretório com os copybooks extraídos")
    parser.add_argument("--output-dir", type=str, 
                       default="/home/ubuntu/cobol_ai_engine_v2.0.0/hybrid_analysis_results_v8", 
                       help="Diretório para salvar os resultados")
    parser.add_argument("--target-language", type=str, default="java", 
                       choices=["java", "python"], 
                       help="Linguagem alvo para o guia de implementação")
    
    args = parser.parse_args()

    engine = COBOLAIEngineV8(args.programs_dir, args.books_dir, args.output_dir)
    results = engine.run_batch_analysis(args.target_language)
    
    print(f"\n=== Análise Concluída ===")
    print(f"Resultados salvos em: {args.output_dir}")
    print(f"Programas processados: {len(results)}")
    successful = sum(1 for r in results if r["success"])
    print(f"Taxa de sucesso: {(successful/len(results)*100):.1f}%")
