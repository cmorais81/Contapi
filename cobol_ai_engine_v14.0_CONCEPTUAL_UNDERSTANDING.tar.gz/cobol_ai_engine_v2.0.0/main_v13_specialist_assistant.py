#!/usr/bin/env python3
"""
COBOL AI Engine v13.0 - ASSISTENTE ESPECIALIZADO
Versão focada em assistir especialistas COBOL com análises avançadas
"""

import os
import sys
import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, List

# Adiciona o diretório src ao path
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

# Importações dos analisadores
from analyzers.complexity_analyzer import ComplexityAnalyzer
from analyzers.business_metrics_extractor import BusinessMetricsExtractor
from analyzers.dependency_mapper import DependencyMapper
from analyzers.intelligent_question_generator import IntelligentQuestionGenerator
from analyzers.business_pattern_detector import BusinessPatternDetector
from analyzers.limitations_analyzer import LimitationsAnalyzer

# Importações dos parsers
from parsers.multi_program_cobol_parser import MultiProgramCOBOLParser

# Importações dos geradores
from generators.improved_documentation_generator import ImprovedDocumentationGenerator

# Importações utilitárias
# from utils.pdf_converter import PDFConverter  # Não usado nesta versão

class COBOLSpecialistAssistant:
    """
    COBOL AI Engine v13.0 - ASSISTENTE ESPECIALIZADO
    
    Focado em fornecer análises avançadas para assistir especialistas COBOL
    em vez de tentar substituí-los.
    """

    def __init__(self, config_path: str = None):
        self.setup_logging()
        self.logger = logging.getLogger(__name__)
        
        # Inicializa componentes
        self.parser = MultiProgramCOBOLParser()
        self.complexity_analyzer = ComplexityAnalyzer()
        self.metrics_extractor = BusinessMetricsExtractor()
        self.dependency_mapper = DependencyMapper()
        self.question_generator = IntelligentQuestionGenerator()
        self.pattern_detector = BusinessPatternDetector()
        self.limitations_analyzer = LimitationsAnalyzer()
        self.doc_generator = ImprovedDocumentationGenerator()
        # self.pdf_converter = PDFConverter()  # Não usado nesta versão
        
        self.logger.info("COBOL Specialist Assistant v13.0 inicializado")

    def setup_logging(self):
        """Configura logging."""
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler('cobol_assistant_v13.log'),
                logging.StreamHandler()
            ]
        )

    def analyze_program_comprehensive(self, program_path: str, 
                                    available_programs: List[str] = None,
                                    available_copybooks: List[str] = None) -> Dict[str, Any]:
        """
        Realiza análise abrangente de um programa COBOL.
        """
        program_name = Path(program_path).stem
        self.logger.info(f"Iniciando análise abrangente de {program_name}")
        
        try:
            # 1. Parse do programa
            with open(program_path, 'r', encoding='utf-8', errors='ignore') as f:
                code_lines = f.readlines()
            
            code_lines = [line.rstrip() for line in code_lines]
            
            self.logger.info(f"Programa carregado: {len(code_lines)} linhas")
            
            # 2. Análise de complexidade
            self.logger.info("Executando análise de complexidade...")
            complexity_analysis = self.complexity_analyzer.analyze_complexity(
                program_name, code_lines
            )
            
            # 3. Extração de métricas de negócio
            self.logger.info("Extraindo métricas de negócio...")
            business_metrics = self.metrics_extractor.extract_business_metrics(
                program_name, code_lines
            )
            
            # 4. Mapeamento de dependências
            self.logger.info("Mapeando dependências...")
            dependency_analysis = self.dependency_mapper.map_dependencies(
                program_name, code_lines, available_programs, available_copybooks
            )
            
            # 5. Geração de perguntas inteligentes
            self.logger.info("Gerando perguntas inteligentes...")
            questions_analysis = self.question_generator.generate_questions(
                program_name, code_lines, {
                    'complexity': complexity_analysis,
                    'metrics': business_metrics,
                    'dependencies': dependency_analysis
                }
            )
            
            # 6. Detecção de padrões de negócio
            self.logger.info("Detectando padrões de negócio...")
            patterns_analysis = self.pattern_detector.detect_patterns(
                program_name, code_lines, {
                    'complexity': complexity_analysis,
                    'metrics': business_metrics
                }
            )
            
            # 7. Análise de limitações
            self.logger.info("Analisando limitações...")
            limitations_analysis = self.limitations_analyzer.analyze_limitations(
                program_name, code_lines, {
                    'complexity': complexity_analysis,
                    'metrics': business_metrics,
                    'dependencies': dependency_analysis,
                    'questions': questions_analysis,
                    'patterns': patterns_analysis
                }
            )
            
            # 8. Compilação dos resultados
            comprehensive_analysis = {
                "program_name": program_name,
                "analysis_timestamp": datetime.now().isoformat(),
                "version": "13.0 - SPECIALIST ASSISTANT",
                "total_lines": len(code_lines),
                "complexity_analysis": complexity_analysis,
                "business_metrics": business_metrics,
                "dependency_analysis": dependency_analysis,
                "questions_analysis": questions_analysis,
                "patterns_analysis": patterns_analysis,
                "limitations_analysis": limitations_analysis,
                "specialist_recommendations": self._generate_specialist_recommendations(
                    complexity_analysis, business_metrics, dependency_analysis,
                    questions_analysis, patterns_analysis, limitations_analysis
                )
            }
            
            self.logger.info(f"Análise abrangente de {program_name} concluída")
            return comprehensive_analysis
            
        except Exception as e:
            self.logger.error(f"Erro na análise de {program_name}: {str(e)}")
            return {
                "program_name": program_name,
                "error": str(e),
                "analysis_timestamp": datetime.now().isoformat()
            }

    def _generate_specialist_recommendations(self, complexity_analysis: Dict[str, Any],
                                           business_metrics: Dict[str, Any],
                                           dependency_analysis: Dict[str, Any],
                                           questions_analysis: Dict[str, Any],
                                           patterns_analysis: Dict[str, Any],
                                           limitations_analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Gera recomendações específicas para especialistas."""
        recommendations = {
            "immediate_actions": [],
            "analysis_priorities": [],
            "modernization_opportunities": [],
            "risk_mitigation": [],
            "productivity_tips": []
        }
        
        # Ações imediatas baseadas na complexidade
        complexity_score = complexity_analysis.get("overall_complexity_score", 0)
        if complexity_score > 80:
            recommendations["immediate_actions"].append(
                "CRÍTICO: Programa altamente complexo. Priorize documentação das seções mais complexas."
            )
        
        high_complexity_sections = complexity_analysis.get("high_complexity_sections", [])
        if high_complexity_sections:
            recommendations["analysis_priorities"].append(
                f"Foque nas {len(high_complexity_sections)} seções mais complexas primeiro: "
                f"{', '.join([s['name'] for s in high_complexity_sections[:3]])}"
            )
        
        # Prioridades baseadas em perguntas
        high_priority_questions = len([q for q in questions_analysis.get("questions", []) 
                                     if q.priority == "HIGH"])
        if high_priority_questions > 0:
            estimated_time = questions_analysis.get("estimated_session_time", {}).get("high_priority_minutes", 0)
            recommendations["analysis_priorities"].append(
                f"Reserve {estimated_time} minutos para {high_priority_questions} perguntas críticas"
            )
        
        # Oportunidades de modernização
        patterns = patterns_analysis.get("detected_patterns", [])
        low_effort_patterns = [p for p in patterns if p.implementation_effort == "LOW"]
        if low_effort_patterns:
            recommendations["modernization_opportunities"].append(
                f"Quick wins: {len(low_effort_patterns)} padrões podem ser modernizados facilmente"
            )
        
        # Mitigação de riscos
        risk_level = dependency_analysis.get("impact_analysis", {}).get("risk_level", "LOW")
        if risk_level in ["HIGH", "CRITICAL"]:
            downstream_count = len(dependency_analysis.get("impact_analysis", {}).get("downstream_impact", []))
            recommendations["risk_mitigation"].append(
                f"ATENÇÃO: Mudanças afetarão {downstream_count} programas. Planeje testes abrangentes."
            )
        
        # Dicas de produtividade
        total_questions = questions_analysis.get("total_questions", 0)
        if total_questions > 20:
            recommendations["productivity_tips"].append(
                "Use a agenda sugerida para otimizar sessões de análise"
            )
        
        business_impact = business_metrics.get("business_impact_score", 0)
        if business_impact > 70:
            recommendations["productivity_tips"].append(
                "Programa tem alto impacto de negócio. Envolva analistas de negócio nas sessões"
            )
        
        return recommendations

    def generate_specialist_report(self, analysis_results: Dict[str, Any], 
                                 output_dir: str) -> str:
        """Gera relatório completo para especialistas."""
        program_name = analysis_results["program_name"]
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        # Relatório principal
        main_report_path = output_path / f"{program_name}_SPECIALIST_REPORT_v13.md"
        
        report_sections = []
        
        # Cabeçalho
        report_sections.extend([
            f"# 🎯 Relatório do Especialista - {program_name}",
            f"**Versão:** {analysis_results.get('version', '13.0')}  ",
            f"**Data:** {analysis_results.get('analysis_timestamp', 'N/A')}  ",
            f"**Linhas de Código:** {analysis_results.get('total_lines', 0)}  ",
            "",
            "---",
            "",
            "## 🚀 Resumo Executivo para Especialistas",
            ""
        ])
        
        # Recomendações do especialista
        specialist_recs = analysis_results.get("specialist_recommendations", {})
        
        if specialist_recs.get("immediate_actions"):
            report_sections.extend([
                "### ⚡ Ações Imediatas",
                ""
            ])
            for action in specialist_recs["immediate_actions"]:
                report_sections.append(f"- {action}")
            report_sections.append("")
        
        if specialist_recs.get("analysis_priorities"):
            report_sections.extend([
                "### 🎯 Prioridades de Análise",
                ""
            ])
            for priority in specialist_recs["analysis_priorities"]:
                report_sections.append(f"- {priority}")
            report_sections.append("")
        
        # Métricas chave
        complexity = analysis_results.get("complexity_analysis", {})
        metrics = analysis_results.get("business_metrics", {})
        dependencies = analysis_results.get("dependency_analysis", {})
        
        report_sections.extend([
            "### 📊 Métricas Chave",
            f"- **Complexidade Geral:** {complexity.get('overall_complexity_score', 0)}/100",
            f"- **Impacto de Negócio:** {metrics.get('business_impact_score', 0)}/100",
            f"- **Risco de Mudança:** {dependencies.get('impact_analysis', {}).get('risk_level', 'N/A')}",
            f"- **Programas Afetados:** {len(dependencies.get('impact_analysis', {}).get('downstream_impact', []))}",
            "",
            "---",
            ""
        ])
        
        # Inclui relatórios detalhados de cada componente
        if "complexity_analysis" in analysis_results:
            complexity_report = self.complexity_analyzer.generate_complexity_report(
                analysis_results["complexity_analysis"]
            )
            report_sections.extend([
                complexity_report,
                "",
                "---",
                ""
            ])
        
        if "business_metrics" in analysis_results:
            metrics_report = self.metrics_extractor.generate_metrics_report(
                analysis_results["business_metrics"]
            )
            report_sections.extend([
                metrics_report,
                "",
                "---",
                ""
            ])
        
        if "dependency_analysis" in analysis_results:
            dependency_report = self.dependency_mapper.generate_dependency_report(
                analysis_results["dependency_analysis"]
            )
            report_sections.extend([
                dependency_report,
                "",
                "---",
                ""
            ])
        
        if "questions_analysis" in analysis_results:
            questions_report = self.question_generator.generate_questions_report(
                analysis_results["questions_analysis"]
            )
            report_sections.extend([
                questions_report,
                "",
                "---",
                ""
            ])
        
        if "patterns_analysis" in analysis_results:
            patterns_report = self.pattern_detector.generate_patterns_report(
                analysis_results["patterns_analysis"]
            )
            report_sections.extend([
                patterns_report,
                "",
                "---",
                ""
            ])
        
        if "limitations_analysis" in analysis_results:
            limitations_report = self.limitations_analyzer.generate_limitations_report(
                analysis_results["limitations_analysis"]
            )
            report_sections.extend([
                limitations_report,
                ""
            ])
        
        # Escreve relatório principal
        with open(main_report_path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(report_sections))
        
        # Salva dados JSON para processamento posterior
        json_path = output_path / f"{program_name}_analysis_data_v13.json"
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(analysis_results, f, indent=2, ensure_ascii=False, default=str)
        
        self.logger.info(f"Relatório do especialista salvo em {main_report_path}")
        return str(main_report_path)

    def analyze_multiple_programs(self, programs_file: str, 
                                copybooks_file: str = None) -> Dict[str, Any]:
        """Analisa múltiplos programas de uma vez."""
        self.logger.info(f"Iniciando análise de múltiplos programas de {programs_file}")
        
        # Extrai programas
        extracted_programs = self.parser.extract_programs_from_file(programs_file)
        
        # Extrai copybooks se disponível
        available_copybooks = []
        if copybooks_file and os.path.exists(copybooks_file):
            available_copybooks = self.parser.extract_copybooks_from_file(copybooks_file)
        
        # Lista de programas disponíveis
        available_programs = list(extracted_programs.keys())
        
        # Analisa cada programa
        results = {}
        consolidated_metrics = {
            "total_programs": len(extracted_programs),
            "total_lines": 0,
            "total_complexity": 0,
            "high_risk_programs": [],
            "modernization_candidates": [],
            "critical_dependencies": []
        }
        
        for program_name, program_content in extracted_programs.items():
            self.logger.info(f"Analisando {program_name}...")
            
            # Salva programa temporariamente
            temp_path = f"/tmp/{program_name}.cbl"
            with open(temp_path, 'w', encoding='utf-8') as f:
                f.write(program_content)
            
            # Analisa programa
            analysis = self.analyze_program_comprehensive(
                temp_path, available_programs, available_copybooks
            )
            
            results[program_name] = analysis
            
            # Atualiza métricas consolidadas
            consolidated_metrics["total_lines"] += analysis.get("total_lines", 0)
            
            complexity_score = analysis.get("complexity_analysis", {}).get("overall_complexity_score", 0)
            consolidated_metrics["total_complexity"] += complexity_score
            
            # Identifica programas de alto risco
            risk_level = analysis.get("dependency_analysis", {}).get("impact_analysis", {}).get("risk_level", "LOW")
            if risk_level in ["HIGH", "CRITICAL"]:
                consolidated_metrics["high_risk_programs"].append(program_name)
            
            # Identifica candidatos à modernização
            patterns = analysis.get("patterns_analysis", {}).get("detected_patterns", [])
            if patterns:
                consolidated_metrics["modernization_candidates"].append({
                    "program": program_name,
                    "patterns": len(patterns),
                    "readiness": analysis.get("patterns_analysis", {}).get("pattern_metrics", {}).get("modernization_readiness", "LOW")
                })
            
            # Remove arquivo temporário
            os.remove(temp_path)
        
        # Calcula médias
        if consolidated_metrics["total_programs"] > 0:
            consolidated_metrics["average_complexity"] = consolidated_metrics["total_complexity"] / consolidated_metrics["total_programs"]
        
        return {
            "analysis_results": results,
            "consolidated_metrics": consolidated_metrics,
            "analysis_timestamp": datetime.now().isoformat(),
            "version": "13.0 - SPECIALIST ASSISTANT"
        }

    def generate_consolidated_report(self, multi_analysis_results: Dict[str, Any], 
                                   output_dir: str) -> str:
        """Gera relatório consolidado de múltiplos programas."""
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        consolidated_report_path = output_path / "CONSOLIDATED_SPECIALIST_REPORT_v13.md"
        
        results = multi_analysis_results["analysis_results"]
        metrics = multi_analysis_results["consolidated_metrics"]
        
        report = [
            "# 🎯 Relatório Consolidado do Especialista",
            f"**Versão:** {multi_analysis_results.get('version', '13.0')}  ",
            f"**Data:** {multi_analysis_results.get('analysis_timestamp', 'N/A')}  ",
            f"**Programas Analisados:** {metrics['total_programs']}  ",
            f"**Total de Linhas:** {metrics['total_lines']:,}  ",
            "",
            "## 📊 Visão Geral do Portfolio",
            f"- **Complexidade Média:** {metrics.get('average_complexity', 0):.1f}/100",
            f"- **Programas de Alto Risco:** {len(metrics['high_risk_programs'])}",
            f"- **Candidatos à Modernização:** {len(metrics['modernization_candidates'])}",
            "",
            "## 🚨 Programas de Alto Risco",
            ""
        ]
        
        if metrics["high_risk_programs"]:
            for program in metrics["high_risk_programs"]:
                analysis = results[program]
                impact_radius = analysis.get("dependency_analysis", {}).get("impact_analysis", {}).get("impact_radius", 0)
                complexity = analysis.get("complexity_analysis", {}).get("overall_complexity_score", 0)
                report.append(f"- **{program}**: {impact_radius} programas afetados, complexidade {complexity}/100")
        else:
            report.append("*Nenhum programa de alto risco identificado.*")
        
        report.extend([
            "",
            "## 🚀 Oportunidades de Modernização",
            ""
        ])
        
        # Ordena candidatos por prontidão
        candidates = sorted(metrics["modernization_candidates"], 
                          key=lambda x: {"HIGH": 3, "MEDIUM": 2, "LOW": 1}.get(x["readiness"], 0), 
                          reverse=True)
        
        for candidate in candidates[:10]:  # Top 10
            report.append(f"- **{candidate['program']}**: {candidate['patterns']} padrões, prontidão {candidate['readiness']}")
        
        report.extend([
            "",
            "## 📋 Resumo por Programa",
            "",
            "| Programa | Complexidade | Risco | Padrões | Perguntas | Recomendação |",
            "|----------|--------------|-------|---------|-----------|--------------|"
        ])
        
        for program_name, analysis in results.items():
            complexity = analysis.get("complexity_analysis", {}).get("overall_complexity_score", 0)
            risk = analysis.get("dependency_analysis", {}).get("impact_analysis", {}).get("risk_level", "LOW")
            patterns = len(analysis.get("patterns_analysis", {}).get("detected_patterns", []))
            questions = analysis.get("questions_analysis", {}).get("total_questions", 0)
            
            # Recomendação simples
            if complexity > 80:
                recommendation = "Documentar primeiro"
            elif risk in ["HIGH", "CRITICAL"]:
                recommendation = "Cuidado com mudanças"
            elif patterns > 3:
                recommendation = "Candidato à modernização"
            else:
                recommendation = "Manutenção normal"
            
            report.append(f"| {program_name} | {complexity}/100 | {risk} | {patterns} | {questions} | {recommendation} |")
        
        report.extend([
            "",
            "## 💡 Recomendações Estratégicas",
            "",
            "### Para Gestores:",
            "1. **Priorize programas de alto risco** para documentação detalhada",
            "2. **Invista em modernização** dos candidatos com alta prontidão",
            "3. **Planeje recursos** baseado na complexidade identificada",
            "",
            "### Para Especialistas:",
            "1. **Use as perguntas inteligentes** para acelerar análise",
            "2. **Foque nas seções complexas** identificadas automaticamente",
            "3. **Considere padrões modernos** para reimplementação",
            "",
            "### Para Arquitetos:",
            "1. **Analise dependências** antes de mudanças arquiteturais",
            "2. **Identifique oportunidades** de consolidação de padrões",
            "3. **Planeje migração incremental** baseada nos riscos",
            ""
        ])
        
        # Escreve relatório
        with open(consolidated_report_path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(report))
        
        self.logger.info(f"Relatório consolidado salvo em {consolidated_report_path}")
        return str(consolidated_report_path)

def main():
    """Função principal."""
    if len(sys.argv) < 2:
        print("Uso: python main_v13_specialist_assistant.py <fontes.txt> [books.txt]")
        sys.exit(1)
    
    programs_file = sys.argv[1]
    copybooks_file = sys.argv[2] if len(sys.argv) > 2 else None
    
    # Inicializa assistente
    assistant = COBOLSpecialistAssistant()
    
    # Diretório de saída
    output_dir = "specialist_analysis_results_v13"
    
    try:
        # Analisa múltiplos programas
        multi_results = assistant.analyze_multiple_programs(programs_file, copybooks_file)
        
        # Gera relatórios individuais
        for program_name, analysis in multi_results["analysis_results"].items():
            program_output_dir = os.path.join(output_dir, program_name)
            assistant.generate_specialist_report(analysis, program_output_dir)
        
        # Gera relatório consolidado
        assistant.generate_consolidated_report(multi_results, output_dir)
        
        print(f"\n🎯 Análise completa finalizada!")
        print(f"📁 Resultados salvos em: {output_dir}")
        print(f"📊 {multi_results['consolidated_metrics']['total_programs']} programas analisados")
        print(f"⚡ {len(multi_results['consolidated_metrics']['high_risk_programs'])} programas de alto risco identificados")
        print(f"🚀 {len(multi_results['consolidated_metrics']['modernization_candidates'])} candidatos à modernização")
        
    except Exception as e:
        print(f"❌ Erro durante análise: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main()
