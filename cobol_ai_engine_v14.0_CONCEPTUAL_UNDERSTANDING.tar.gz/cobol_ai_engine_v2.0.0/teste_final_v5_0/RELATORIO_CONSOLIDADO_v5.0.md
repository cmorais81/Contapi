# Relatório Consolidado - COBOL AI Engine v5.0

**Data:** 2025-09-17 19:29:16
**Programas analisados:** 1

**Taxa de sucesso:** 0/1 (0.0%)

## Resultados por Programa

### LHAN0542_TESTE
- **Status:** ❌ Erro
- **Erro:** 'list' object has no attribute 'split'

