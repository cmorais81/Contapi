#!/usr/bin/env python3
"""
CLI Principal - COBOL to Docs v1.0 (PyPI Version)
Autor: Carlos Morais

Wrapper que mantém 100% de compatibilidade com main.py original
"""

import sys
import os
from pathlib import Path

def main():
    """
    Função principal que importa e executa o main.py original
    Mantém 100% de compatibilidade
    """
    
    # Adicionar diretório do pacote ao path
    package_dir = Path(__file__).parent
    sys.path.insert(0, str(package_dir))
    
    # Importar e executar main original
    try:
        # Importação relativa
        from .main_original import main as main_func
        main_func()
    except ImportError:
        try:
            # Importação absoluta
            from cobol_to_docs.main_original import main as main_func
            main_func()
        except ImportError:
            # Fallback direto
            import main_original
            main_original.main()

if __name__ == "__main__":
    main()
