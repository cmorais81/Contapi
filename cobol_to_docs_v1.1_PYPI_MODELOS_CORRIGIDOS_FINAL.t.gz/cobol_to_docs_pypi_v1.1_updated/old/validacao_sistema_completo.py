#!/usr/bin/env python3
"""
Validação completa do sistema COBOL AI Engine após correção do modelo
Verificar se todas as funcionalidades estão mantidas com aws-claude-4-0-sonnet
"""

import os
import sys
import yaml
import json
from pathlib import Path

def validar_configuracao():
    """Validar se as configurações estão corretas"""
    print(" VALIDANDO CONFIGURAÇÕES...")
    print()
    
    config_path = Path("config/config.yaml")
    if not config_path.exists():
        print(f" Arquivo de configuração não encontrado: {config_path}")
        return False
    
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)
        
        print(" Arquivo config.yaml carregado com sucesso")
        
        # Verificar configuração do provider LuzIA
        luzia_config = config.get('providers', {}).get('luzia', {})
        if not luzia_config:
            print(" Configuração do provider LuzIA não encontrada")
            return False
        
        print(" Configuração do provider LuzIA encontrada")
        
        # Verificar modelo configurado
        models = luzia_config.get('models', {})
        if 'aws_claude_3_7' not in models:
            print(" Modelo aws-claude-3.7 não encontrado na configuração")
            print(f"Modelos disponíveis: {list(models.keys())}")
            return False
        
        model_config = models['aws_claude_3_7']
        expected_name = "aws-claude-3.7"
        actual_name = model_config.get('name')
        
        if actual_name != expected_name:
            print(f" Nome do modelo incorreto. Esperado: {expected_name}, Atual: {actual_name}")
            return False
        
        print(f" Modelo aws-claude-3.7 configurado corretamente")
        print(f"  - Nome: {actual_name}")
        print(f"  - Max tokens: {model_config.get('max_tokens')}")
        print(f"  - Temperature: {model_config.get('temperature')}")
        print(f"  - Context window: {model_config.get('context_window')}")
        
        return True
        
    except Exception as e:
        print(f" Erro ao validar configuração: {e}")
        return False

def validar_provider():
    """Validar se o provider está implementado corretamente"""
    print()
    print(" VALIDANDO PROVIDER...")
    print()
    
    provider_path = Path("src/providers/luzia_provider.py")
    if not provider_path.exists():
        print(f" Provider não encontrado: {provider_path}")
        return False
    
    try:
        with open(provider_path, 'r', encoding='utf-8') as f:
            provider_code = f.read()
        
        print(" Arquivo luzia_provider.py encontrado")
        
        # Verificar se o modelo está correto no código
        if 'aws-claude-3.7' not in provider_code:
            print(" Modelo aws-claude-3.7 não encontrado no código do provider")
            return False
        
        print(" Modelo aws-claude-3.7 encontrado no código")
        
        # Verificar se não há referências ao modelo antigo
        old_models = ['azure-gpt-4o-mini', 'aws-claude-3-haiku']
        for old_model in old_models:
            if old_model in provider_code:
                print(f"  Referência ao modelo antigo encontrada: {old_model}")
        
        # Verificar método get_models
        if 'def get_models(self)' not in provider_code:
            print(" Método get_models não encontrado")
            return False
        
        print(" Método get_models encontrado")
        
        return True
        
    except Exception as e:
        print(f" Erro ao validar provider: {e}")
        return False

def validar_estrutura_arquivos():
    """Validar se todos os arquivos necessários estão presentes"""
    print()
    print(" VALIDANDO ESTRUTURA DE ARQUIVOS...")
    print()
    
    arquivos_essenciais = [
        "src/providers/luzia_provider.py",
        "src/providers/base_provider.py",
        "config/config.yaml",
        "config/prompts_original.yaml",
        "main.py"
    ]
    
    todos_presentes = True
    
    for arquivo in arquivos_essenciais:
        path = Path(arquivo)
        if path.exists():
            print(f" {arquivo}")
        else:
            print(f" {arquivo} - AUSENTE")
            todos_presentes = False
    
    return todos_presentes

def validar_prompts():
    """Validar se os arquivos de prompts estão corretos"""
    print()
    print(" VALIDANDO PROMPTS...")
    print()
    
    prompts_path = Path("config/prompts_original.yaml")
    if not prompts_path.exists():
        print(f" Arquivo de prompts não encontrado: {prompts_path}")
        return False
    
    try:
        with open(prompts_path, 'r', encoding='utf-8') as f:
            prompts = yaml.safe_load(f)
        
        print(" Arquivo prompts_original.yaml carregado")
        
        # Verificar se não há ícones ou referências ao Manus
        prompts_str = str(prompts)
        
        # Verificar ícones
        icones_encontrados = []
        icones_comuns = ['', '', '', '⚡', '', '', '', '', '', '']
        for icone in icones_comuns:
            if icone in prompts_str:
                icones_encontrados.append(icone)
        
        if icones_encontrados:
            print(f"  Ícones encontrados nos prompts: {icones_encontrados}")
            print("   Recomenda-se remover para manter profissionalismo")
        else:
            print(" Nenhum ícone encontrado nos prompts")
        
        # Verificar referências ao Manus
        if 'manus' in prompts_str.lower() or 'ai' in prompts_str.lower():
            print("  Possíveis referências a IA/Manus encontradas nos prompts")
        else:
            print(" Nenhuma referência a IA/Manus encontrada")
        
        return True
        
    except Exception as e:
        print(f" Erro ao validar prompts: {e}")
        return False

def validar_funcionalidade_dual_prompts():
    """Validar se a funcionalidade de dual prompts está mantida"""
    print()
    print(" VALIDANDO FUNCIONALIDADE DUAL PROMPTS...")
    print()
    
    # Verificar se existe o arquivo de prompts DOC-LEGADO PRO
    doc_legado_path = Path("config/prompts_doc_legado_pro.yaml")
    if doc_legado_path.exists():
        print(" Arquivo prompts_doc_legado_pro.yaml encontrado")
        print(" Funcionalidade dual prompts mantida")
        return True
    else:
        print("  Arquivo prompts_doc_legado_pro.yaml não encontrado")
        print("   Funcionalidade dual prompts pode estar comprometida")
        return False

def main():
    """Executar validação completa do sistema"""
    print("=" * 60)
    print("VALIDAÇÃO COMPLETA DO SISTEMA COBOL AI ENGINE")
    print("Verificando correção do modelo aws-claude-3.7")
    print("=" * 60)
    
    resultados = []
    
    # Executar validações
    resultados.append(("Configuração", validar_configuracao()))
    resultados.append(("Provider", validar_provider()))
    resultados.append(("Estrutura de Arquivos", validar_estrutura_arquivos()))
    resultados.append(("Prompts", validar_prompts()))
    resultados.append(("Dual Prompts", validar_funcionalidade_dual_prompts()))
    
    # Resumo final
    print()
    print("=" * 60)
    print("RESUMO DA VALIDAÇÃO")
    print("=" * 60)
    
    total_testes = len(resultados)
    testes_passou = sum(1 for _, passou in resultados if passou)
    
    for nome, passou in resultados:
        status = " PASSOU" if passou else " FALHOU"
        print(f"{nome:.<30} {status}")
    
    print()
    print(f"RESULTADO GERAL: {testes_passou}/{total_testes} testes passaram")
    
    if testes_passou == total_testes:
        print()
        print(" VALIDAÇÃO COMPLETA PASSOU!")
        print(" Sistema está pronto com modelo aws-claude-3.7")
        print(" Todas as funcionalidades foram mantidas")
        print(" Erro 'Model not found' deve estar resolvido")
        return True
    else:
        print()
        print(" VALIDAÇÃO FALHOU")
        print(" Alguns problemas foram identificados")
        print("   Revisar os itens marcados como FALHOU")
        return False

if __name__ == "__main__":
    os.chdir(Path(__file__).parent)
    success = main()
    sys.exit(0 if success else 1)
