#!/usr/bin/env python3
"""
Recriação do teste.py que funcionava baseado nas imagens fornecidas
"""

import requests
import json
import os
from dotenv import load_dotenv
import warnings

# Suprimir warnings
warnings.filterwarnings("ignore", message="Unverified HTTPS request is being made to host")

# Carregar variáveis de ambiente
load_dotenv()

CLIENT_ID = os.getenv('LUZIA_CLIENT_ID')
CLIENT_SECRET = os.getenv('LUZIA_CLIENT_SECRET')
SSO_ENDPOINT = "https://login.azure.paas.santanderbr.pre.corp/auth/realms/corp/protocol/openid-connect/token"

def get_token():
    """Obter token OAuth2 - EXATO como nas imagens"""
    request_body = {
        "grant_type": "client_credentials",
        "client_id": CLIENT_ID,
        "client_secret": CLIENT_SECRET
    }
    
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept': '*/*'
    }
    
    token_body = requests.post(SSO_ENDPOINT, headers=headers, data=request_body, verify=False)
    return token_body.json().get("access_token")

TOKEN = get_token()

async_client = requests.Session()
async_client.base_url = "https://gut-api-aws.santanderbr.dev.corp/genai_services/v1/"
async_client.timeout = 120.0

model = "azure-gpt-4o-mini"

system_prompt = """
Answer all questions in brazilian portuguese.
Answer code question with the code only, without using the brackets.
DON'T start the answer with the word 'python'.
"""

user_prompt = """Diga apenas 'teste ok'"""

# Payload EXATO como nas imagens
payload = {
    "input": {
        "query": [
            {
                "role": "system",
                "content": system_prompt
            },
            {
                "role": "user",
                "content": user_prompt
            }
        ]
    },
    "config": {
        "type": "catena.llm.LLMRouter",
        "obj_kwargs": {
            "routing_model": model,
            "temperature": 0.1
        }
    }
}

async def submit():
    """Função submit EXATA como nas imagens"""
    response = await async_client.post(
        url="/pipelines/submit",
        json=payload,
        headers={
            "X-santander-client-id": CLIENT_ID,
            "Authorization": f"Bearer {TOKEN}"
        }
    )
    print(response.json())

# Executar de forma síncrona para debug
def submit_sync():
    """Versão síncrona para debug"""
    print("=== TESTE FUNCIONANDO - RECRIADO ===")
    
    print(f"CLIENT_ID: {CLIENT_ID}")
    print(f"TOKEN: {TOKEN[:20] if TOKEN else 'None'}...")
    
    print("\nPAYLOAD SENDO ENVIADO:")
    print(json.dumps(payload, indent=2, ensure_ascii=False))
    
    print("\nHEADERS:")
    headers = {
        "X-santander-client-id": CLIENT_ID,
        "Authorization": f"Bearer {TOKEN}"
    }
    for key, value in headers.items():
        print(f"  {key}: {value}")
    
    print("\nFAZENDO REQUISIÇÃO...")
    
    try:
        response = requests.post(
            url="https://gut-api-aws.santanderbr.dev.corp/genai_services/v1/pipelines/submit",
            json=payload,
            headers=headers,
            verify=False,
            timeout=120.0
        )
        
        print(f"STATUS CODE: {response.status_code}")
        print(f"HEADERS DE RESPOSTA: {dict(response.headers)}")
        
        if response.status_code == 200:
            print("SUCESSO!")
            print(response.json())
        else:
            print("ERRO!")
            print(response.text)
            
    except Exception as e:
        print(f"EXCEÇÃO: {e}")

if __name__ == "__main__":
    submit_sync()
