#!/usr/bin/env python3
"""
Teste com debug completo para ver exatamente o que está sendo enviado
"""

import os
import sys
sys.path.append('.')

from src.providers.luzia_provider_debug import LuziaProviderDebug
from src.providers.base_provider import AIRequest

def main():
    print("=== TESTE DEBUG COMPLETO ===")
    
    # Verificar credenciais
    client_id = os.getenv('LUZIA_CLIENT_ID')
    client_secret = os.getenv('LUZIA_CLIENT_SECRET')
    
    if not client_id or not client_secret:
        print("ERRO: Defina LUZIA_CLIENT_ID e LUZIA_CLIENT_SECRET")
        print("export LUZIA_CLIENT_ID='seu_client_id'")
        print("export LUZIA_CLIENT_SECRET='seu_client_secret'")
        return
    
    print(f"Client ID: {client_id}")
    print(f"Client Secret: {client_secret[:10]}...")
    
    # Criar provider
    provider = LuziaProviderDebug({
        'base_url': 'https://gut-api-aws.santanderbr.dev.corp/genai_services/v1/pipelines/submit',
        'client_id': client_id,
        'client_secret': client_secret,
        'timeout': 120
    })
    
    # Criar request
    request = AIRequest(
        prompt="Diga apenas 'teste ok'",
        program_name="teste.cbl",
        program_code="IDENTIFICATION DIVISION. PROGRAM-ID. TESTE."
    )
    
    print(f"\nRequest criado:")
    print(f"- Prompt: {request.prompt}")
    print(f"- Program: {request.program_name}")
    
    # Executar análise com debug completo
    print(f"\nExecutando análise...")
    result = provider.analyze(request)
    
    print(f"\nRESULTADO FINAL:")
    print(f"- Sucesso: {result.success}")
    print(f"- Conteúdo: {result.content}")
    print(f"- Erro: {result.error_message}")
    print(f"- Tempo: {result.response_time:.2f}s")

if __name__ == "__main__":
    main()
