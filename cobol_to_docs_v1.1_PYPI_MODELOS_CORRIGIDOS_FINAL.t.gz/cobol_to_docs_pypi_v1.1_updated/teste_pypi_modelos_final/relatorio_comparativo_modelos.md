# Relatório Comparativo de Modelos

**Data:** 24/09/2025 15:45:06
**Programas Analisados:** 5
**Modelos Utilizados:** 2

## Resumo Geral

| Modelo | Sucessos | Falhas | Taxa de Sucesso | Tokens Médios |
|--------|----------|--------|-----------------|---------------|
| aws-claude-3-5-sonnet | 5 | 0 | 100.0% | 870 |
| enhanced-mock-gpt-4 | 5 | 0 | 100.0% | 870 |

## Detalhes por Programa

### LHAN0542

| Modelo | Status | Tokens | Qualidade | Diretório |
|--------|--------|--------|-----------|----------|
| aws-claude-3-5-sonnet | Sucesso | 727 | Baixa | model_aws_claude_3_5_sonnet |
| enhanced-mock-gpt-4 | Sucesso | 727 | Baixa | model_enhanced_mock_gpt_4 |

### LHAN0543

| Modelo | Status | Tokens | Qualidade | Diretório |
|--------|--------|--------|-----------|----------|
| aws-claude-3-5-sonnet | Sucesso | 853 | Baixa | model_aws_claude_3_5_sonnet |
| enhanced-mock-gpt-4 | Sucesso | 853 | Baixa | model_enhanced_mock_gpt_4 |

### LHAN0544

| Modelo | Status | Tokens | Qualidade | Diretório |
|--------|--------|--------|-----------|----------|
| aws-claude-3-5-sonnet | Sucesso | 959 | Baixa | model_aws_claude_3_5_sonnet |
| enhanced-mock-gpt-4 | Sucesso | 959 | Baixa | model_enhanced_mock_gpt_4 |

### LHAN0545

| Modelo | Status | Tokens | Qualidade | Diretório |
|--------|--------|--------|-----------|----------|
| aws-claude-3-5-sonnet | Sucesso | 850 | Baixa | model_aws_claude_3_5_sonnet |
| enhanced-mock-gpt-4 | Sucesso | 850 | Baixa | model_enhanced_mock_gpt_4 |

### LHAN0546

| Modelo | Status | Tokens | Qualidade | Diretório |
|--------|--------|--------|-----------|----------|
| aws-claude-3-5-sonnet | Sucesso | 959 | Baixa | model_aws_claude_3_5_sonnet |
| enhanced-mock-gpt-4 | Sucesso | 959 | Baixa | model_enhanced_mock_gpt_4 |

## Recomendações

**Modelo Recomendado:** aws-claude-3-5-sonnet (melhor taxa de sucesso)

**Modelo Mais Detalhado:** aws-claude-3-5-sonnet (maior média de tokens)

### Uso Recomendado por Cenário

- **Análise Rápida:** Use o modelo com melhor taxa de sucesso
- **Análise Detalhada:** Use o modelo com maior média de tokens
- **Análise Crítica:** Execute com múltiplos modelos e compare resultados
- **Produção:** Use o modelo mais estável baseado nas estatísticas

---
**Relatório gerado automaticamente pelo COBOL to Docs v1.1**
