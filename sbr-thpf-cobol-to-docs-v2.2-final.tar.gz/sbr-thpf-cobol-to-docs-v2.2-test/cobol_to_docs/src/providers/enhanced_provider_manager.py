import logging
import time
import os
from typing import Dict, List, Any, Optional
from .base_provider import BaseProvider, AIRequest, AIResponse
from .luzia_provider import LuziaProvider

from .basic_provider import BasicProvider
from .databricks_provider import DatabricksProvider
from .bedrock_provider import BedrockProvider
from .openai_provider import OpenAIProvider
from .github_copilot_provider import GitHubCopilotProvider


class EnhancedProviderManager:
    """
    Gerenciador aprimorado de provedores de IA com suporte a múltiplos modelos
    e configurações específicas por modelo.
    """
    
    def __init__(self, config: Dict[str, Any]):
        """Inicializa o gerenciador aprimorado de provedores."""
        self.logger = logging.getLogger(__name__)
        self.config = config
        self.providers: Dict[str, BaseProvider] = {}
        self.model_configurations: Dict[str, Dict[str, Any]] = {}
        self.statistics: Dict[str, Dict[str, Any]] = {}
        
        ai_config = config.get("ai", {})
        self.primary_provider = ai_config.get("primary_provider", "basic")
        self.fallback_providers = ai_config.get("fallback_providers", [])
        self.provider_instances: Dict[str, BaseProvider] = {}      

        self._load_all_provider_models()
        self._initialize_providers()
        
        self.logger.info(f"Enhanced Provider Manager inicializado - Primário: {self.primary_provider}")
        self.logger.info(f"Modelos configurados: {list(self.model_configurations.keys())}")
        self.logger.info(f"Provider Models: {self.get_provider_instance(self.primary_provider).models if self.primary_provider in self.provider_instances else 'N/A'}")
        if not self.model_configurations:
            self.logger.warning("Nenhum modelo foi carregado. Verifique a configuração dos provedores.")

    def _load_all_provider_models(self) -> None:
        """Carrega todos os modelos de todos os provedores configurados."""
        providers_config = self.config.get("providers", [])
        for provider_config in providers_config:
            provider_name = provider_config.get("name")
            if not provider_name:
                self.logger.error("Configuração de provedor inválida: 'name' está faltando.")
                continue

            self.logger.info(f"Verificando provedor {provider_name} para carregamento de modelos.")
            # Carregar modelos se o provedor estiver habilitado OU se for o primário/fallback
            if provider_config.get("enabled", False) or provider_name in [self.primary_provider] + self.fallback_providers:
                self.logger.info(f"Carregando modelos para o provedor {provider_name}.")
                self._load_provider_models(provider_name, provider_config)
            else:
                self.logger.info(f"Pulando carregamento de modelos para o provedor {provider_name} (desabilitado).")

    def _initialize_providers(self) -> None:
        """Inicializa todos os provedores disponíveis com configurações específicas."""
        providers_list = self.config.get("providers", [])
        providers_config = {p.get("name"): p for p in providers_list if p.get("name")}
        
        available_providers = {
            "luzia": LuziaProvider,
            "basic": BasicProvider,
            "databricks": DatabricksProvider,
            "bedrock": BedrockProvider,
            "openai": OpenAIProvider,
            "github_copilot": GitHubCopilotProvider
        }
        
        for provider_name, provider_class in available_providers.items():
            try:
                provider_config = providers_config.get(provider_name, {})
                
                is_enabled = provider_config.get("enabled", False)
                
                # Inicializa o provider se estiver habilitado OU se for o primário/fallback
                if is_enabled or provider_name in [self.primary_provider] + self.fallback_providers:
                    self.logger.info(f"Inicializando provider {provider_name}")
                    if provider_name == "luzia":
                        client_id = os.getenv("LUZIA_CLIENT_ID")
                        client_secret = os.getenv("LUZIA_CLIENT_SECRET")
                        
                        if not client_id or not client_secret:
                            self.logger.warning(f"Provider {provider_name} habilitado mas credenciais não encontradas")
                            luzia_client_id_status = "Definido" if client_id else "Não definido"
                            self.logger.warning(f"   LUZIA_CLIENT_ID: {luzia_client_id_status}")
                            luzia_client_secret_status = "Definido" if client_secret else "Não definido"
                            self.logger.warning(f"   LUZIA_CLIENT_SECRET: {luzia_client_secret_status}")
                            self.logger.warning(f"   Provider {provider_name} será inicializado mas ficará indisponível")
                        else:
                            self.logger.info(f"Credenciais LuzIA encontradas - inicializando provider {provider_name}")

                    enhanced_config = provider_config.copy()
                    provider = provider_class(enhanced_config)
                    self.providers[provider_name] = provider
                    self.logger.info(f"Provider {provider_name} inicializado com sucesso")
                else:
                    self.logger.info(f"Pulando provider {provider_name} (desabilitado na configuração)")

            except Exception as e:
                self.logger.error(f"ERRO ao inicializar provider {provider_name}: {str(e)}")

    def _load_provider_models(self, provider_name: str, provider_config: Dict[str, Any]) -> None:
        """Carrega os modelos de um provider para model_configurations."""
        
        # 1. Handle BasicProvider separately as it's a fallback
        if provider_name == "basic":
            # Adicionar o modelo basic-fallback manualmente se for o BasicProvider
            self.model_configurations["basic-fallback"] = {
                "provider": "basic",
                "name": "basic-fallback",
                "cost_per_1k_tokens": 0.0,
                "max_tokens": 4096
            }
            self.logger.info("Modelo basic-fallback adicionado manualmente.")
            return

        # 2. Handle single model configuration (from list format in config)
        model_name = provider_config.get("model")
        if model_name:
            # Create a model config from the provider config
            full_model_config = provider_config.copy()
            full_model_config["provider"] = provider_name
            full_model_config["name"] = model_name # Ensure name is set
            
            # Add defaults if missing
            full_model_config.setdefault("cost_per_1k_tokens", 0.0)
            full_model_config.setdefault("max_tokens", 4096)
            
            self.model_configurations[model_name] = full_model_config
            self.logger.info(f"Modelo {model_name} carregado do provider {provider_name} (config list format)")
            return

        # 3. Handle multiple models configuration (from dict format in config)
        models = provider_config.get("models", {})
        self.logger.info(f"Carregando modelos para o provider {provider_name}. Modelos encontrados: {list(models.keys())}")
        
        if not models:
            self.logger.warning(f"Nenhum modelo encontrado para o provedor {provider_name}.")
            return 
        
        for model_key, model_config in models.items():
            model_name = model_config.get("name", model_key)
            
            # Criar uma cópia para evitar modificar o config original
            full_model_config = model_config.copy()
            full_model_config["provider"] = provider_name
            
            self.model_configurations[model_name] = full_model_config
            self.logger.info(f"Modelo {model_name} carregado do provider {provider_name} (config dict format)")

    def _initialize_provider_statistics(self, provider_name: str) -> None:
        """Inicializa estatísticas para um provider."""
        self.statistics[provider_name] = {
            "total_requests": 0,
            "successful_requests": 0,
            "failed_requests": 0,
            "total_tokens": 0,
            "average_response_time": 0.0,
            "last_request_time": None,
            "consecutive_failures": 0,
            "model_specific_stats": {}
        }

    def _apply_model_specific_config_to_provider_config(self, provider_name: str, provider_config: Dict[str, Any]) -> Dict[str, Any]:
        """Aplica configurações específicas do modelo ao provedor antes de sua inicialização."""
        return provider_config.copy()

    def analyze_with_model(self, model_name: str, request: AIRequest) -> AIResponse:
        """
        Realiza análise usando um modelo específico SEM FALLBACK.
        Se o modelo falhar, retorna erro ao invés de tentar outros providers.
        """
        self.logger.info(f"*** ANÁLISE COM MODELO ESPECÍFICO: {model_name} (SEM FALLBACK) ***")
        
        actual_model = model_name
        
        self.logger.info(f"Modelos disponíveis: {list(self.model_configurations.keys())}")
        
        if model_name not in self.model_configurations:
            error_msg = f"Modelo {model_name} não está configurado no sistema"
            self.logger.error(error_msg)
            return AIResponse(
                success=False,
                content="",
                tokens_used=0,
                model=model_name,
                provider="none",
                error_message=error_msg
            )
        
        model_config = self.model_configurations[model_name]
        provider_name = model_config.get("provider", self.primary_provider)
        actual_model = model_name
        
        if provider_name not in self.providers:
            error_msg = f"Provider {provider_name} para modelo {actual_model} não está disponível"
            self.logger.error(error_msg)
            return AIResponse(
                success=False,
                content="",
                tokens_used=0,
                model=actual_model,
                provider=provider_name,
                error_message=error_msg
            )
        
        enhanced_request = self._enhance_request_for_model(request, model_config)
        
        self.logger.info(f"Executando análise EXCLUSIVAMENTE com {provider_name} para modelo {actual_model}")
        response = self._try_provider(provider_name, enhanced_request)
        
        if not response.success:
            self.logger.error(f"*** FALHA NO MODELO ESPECÍFICO {actual_model} (solicitado como {model_name}) ***")
            self.logger.error(f"Provider: {provider_name}")
            self.logger.error(f"Erro: {response.error_message}")
            self.logger.error("*** NÃO SERÁ FEITO FALLBACK - MODELO ESPECÍFICO SOLICITADO ***")
        
        self._update_statistics(provider_name, actual_model, response)
        
        return response

    def analyze(self, request: AIRequest) -> AIResponse:
        """
        Realiza análise usando o provedor primário e, em caso de falha,
        tenta os provedores de fallback.
        """
        self.logger.info(f"*** INICIANDO ANÁLISE COM PROVIDER PRIMÁRIO: {self.primary_provider} ***")
        
        final_response = AIResponse(success=False, content="", tokens_used=0, model="", provider="", error_message="Nenhum provedor conseguiu responder.")
        
        primary_provider_name = self.primary_provider
        primary_provider_instance = self.providers.get(primary_provider_name)
        
        if primary_provider_instance:
            self.logger.info(f"Tentando provedor primário: {primary_provider_name}")
            primary_response = self._try_provider(primary_provider_name, request)
            self._update_statistics(primary_provider_name, request.model, primary_response)
            if primary_response.success:
                self.logger.info(f"Análise bem-sucedida com provedor primário: {primary_provider_name}")
                return primary_response
            else:
                self.logger.warning(f"Provedor primário {primary_provider_name} falhou: {primary_response.error_message}")
                final_response = primary_response
        else:
            self.logger.warning(f"Provedor primário {primary_provider_name} não configurado ou disponível.")

        if self.config.get("ai", {}).get("enable_fallback", True):
            self.logger.info("Iniciando tentativas com provedores de fallback...")
            for fallback_provider_name in self.fallback_providers:
                if fallback_provider_name == primary_provider_name:
                    continue
                
                fallback_provider_instance = self.providers.get(fallback_provider_name)
                if fallback_provider_instance:
                    self.logger.info(f"Tentando provedor de fallback: {fallback_provider_name}")
                    fallback_response = self._try_provider(fallback_provider_name, request)
                    self._update_statistics(fallback_provider_name, request.model, fallback_response)
                    if fallback_response.success:
                        self.logger.info(f"Análise bem-sucedida com provedor de fallback: {fallback_provider_name}")
                        return fallback_response
                    else:
                        self.logger.warning(f"Provedor de fallback {fallback_provider_name} falhou: {fallback_response.error_message}")
                        final_response = fallback_response
                else:
                    self.logger.warning(f"Provedor de fallback {fallback_provider_name} não configurado ou disponível.")
        else:
            self.logger.info("Fallback desabilitado na configuração.")

        self.logger.error(f"Todos os provedores falharam na análise. Último erro: {final_response.error_message}")
        return final_response

    def _try_provider(self, provider_name: str, request: AIRequest) -> AIResponse:
        """
        Tenta executar uma requisição com um provedor específico.
        Retorna AIResponse.
        """
        provider = self.providers.get(provider_name)
        if not provider:
            return AIResponse(success=False, content="", tokens_used=0, model=request.model, provider=provider_name, error_message=f"Provedor {provider_name} não encontrado.")
        
        try:
            start_time = time.time()
            response = provider.analyze(request)
            end_time = time.time()
            response.response_time = end_time - start_time
            return response
        except Exception as e:
            self.logger.error(f"Exceção durante a chamada ao provedor {provider_name}: {str(e)}")
            return AIResponse(success=False, content="", tokens_used=0, model=request.model, provider=provider_name, error_message=str(e))

    def _update_statistics(self, provider_name: str, model_name: str, response: AIResponse) -> None:
        """
        Atualiza as estatísticas de uso para um provedor e modelo.
        """
        if provider_name not in self.statistics:
            self._initialize_provider_statistics(provider_name)
        
        stats = self.statistics[provider_name]
        stats["total_requests"] += 1
        stats["last_request_time"] = time.time()
        
        if response.success:
            stats["successful_requests"] += 1
            stats["total_tokens"] += response.tokens_used
            stats["consecutive_failures"] = 0
            if stats["successful_requests"] == 1:
                stats["average_response_time"] = response.response_time
            else:
                stats["average_response_time"] = (
                    (stats["average_response_time"] * (stats["successful_requests"] - 1)) +
                    response.response_time
                ) / stats["successful_requests"]
        else:
            stats["failed_requests"] += 1
            stats["consecutive_failures"] += 1
        
        if model_name not in stats["model_specific_stats"]:
            stats["model_specific_stats"][model_name] = {
                "total_requests": 0,
                "successful_requests": 0,
                "failed_requests": 0,
                "total_tokens": 0,
                "average_response_time": 0.0,
                "last_request_time": None,
                "consecutive_failures": 0
            }
        
        model_stats = stats["model_specific_stats"][model_name]
        model_stats["total_requests"] += 1
        model_stats["last_request_time"] = time.time()
        
        if response.success:
            model_stats["successful_requests"] += 1
            model_stats["total_tokens"] += response.tokens_used
            model_stats["consecutive_failures"] = 0
            if model_stats["successful_requests"] == 1:
                model_stats["average_response_time"] = response.response_time
            else:
                model_stats["average_response_time"] = (
                    (model_stats["average_response_time"] * (model_stats["successful_requests"] - 1)) +
                    response.response_time
                ) / model_stats["successful_requests"]
        else:
            model_stats["failed_requests"] += 1
            model_stats["consecutive_failures"] += 1

    def get_provider_statistics(self) -> Dict[str, Any]:
        """Retorna as estatísticas de uso de todos os provedores."""
        return self.statistics

    def get_model_config(self, model_name: str) -> Optional[Dict[str, Any]]:
        """
        Retorna a configuração de um modelo específico.
        """
        return self.model_configurations.get(model_name)

    def get_available_models(self) -> List[str]:
        """
        Retorna uma lista dos nomes de todos os modelos configurados.
        """
        return list(self.model_configurations.keys())

    def get_provider_for_model(self, model_name: str) -> Optional[str]:
        """
        Retorna o nome do provedor associado a um modelo específico.
        """
        model_config = self.model_configurations.get(model_name)
        return model_config.get("provider") if model_config else None

    def get_provider_instance(self, provider_name: str) -> Optional[BaseProvider]:
        """
        Retorna a instância de um provedor específico.
        """
        return self.providers.get(provider_name)

    def _enhance_request_for_model(self, request: AIRequest, model_config: Dict[str, Any]) -> AIRequest:
        """
        Aprimora a requisição com configurações específicas do modelo.
        """
        enhanced_request = request.copy(deep=True)
        
        if "max_tokens" in model_config:
            enhanced_request.max_tokens = model_config["max_tokens"]
        if "temperature" in model_config:
            enhanced_request.temperature = model_config["temperature"]
        
        return enhanced_request

