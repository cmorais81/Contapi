"""
Lineage Analysis Endpoints

Endpoints para análises avançadas de linhagem de dados.

Author: Carlos Morais <carlos.morais@f1rst.com.br>
Date: Julho 2025
"""

from typing import List, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.exceptions import NotFoundError, ValidationError, BusinessRuleError
from app.schemas.lineage.lineage_analysis import (
    ImpactAnalysisRequest,
    ImpactAnalysisResult,
    RootCauseAnalysisRequest,
    RootCauseAnalysisResult,
    CoverageAnalysisRequest,
    CoverageAnalysisResult,
    QualityAnalysisRequest,
    QualityAnalysisResult,
    PerformanceAnalysisRequest,
    PerformanceAnalysisResult,
    ComplianceAnalysisRequest,
    ComplianceAnalysisResult,
    ChangeAnalysisRequest,
    ChangeAnalysisResult,
    AnalysisType,
    SeverityLevel,
    ComplianceFramework
)
from app.services.lineage.lineage_analysis_service import LineageAnalysisService

router = APIRouter()

# ==================== Impact Analysis ====================

@router.post("/impact", response_model=ImpactAnalysisResult)
def analyze_impact(
    request: ImpactAnalysisRequest,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Executa análise de impacto de mudanças.
    
    Args:
        request: Parâmetros da análise de impacto
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        ImpactAnalysisResult: Resultado da análise de impacto
        
    Raises:
        HTTPException: Se parâmetros são inválidos
    """
    try:
        analysis_service = LineageAnalysisService(db)
        result = analysis_service.analyze_impact(request, current_user_id)
        return result
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(e))
    except BusinessRuleError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

@router.get("/impact/{entity_id}", response_model=ImpactAnalysisResult)
def get_entity_impact_analysis(
    entity_id: str,
    change_type: str = Query("schema_change", description="Tipo de mudança"),
    severity: SeverityLevel = Query(SeverityLevel.MEDIUM, description="Severidade da mudança"),
    max_depth: int = Query(5, ge=1, le=10, description="Profundidade máxima da análise"),
    include_probability: bool = Query(True, description="Incluir probabilidade de impacto"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Obtém análise de impacto para uma entidade específica.
    
    Args:
        entity_id: ID da entidade
        change_type: Tipo de mudança
        severity: Severidade da mudança
        max_depth: Profundidade máxima da análise
        include_probability: Incluir probabilidade de impacto
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        ImpactAnalysisResult: Resultado da análise de impacto
    """
    try:
        analysis_service = LineageAnalysisService(db)
        
        # Construir request
        request = ImpactAnalysisRequest(
            entity_id=entity_id,
            change_type=change_type,
            severity=severity,
            max_depth=max_depth,
            include_probability=include_probability
        )
        
        result = analysis_service.analyze_impact(request, current_user_id)
        return result
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

# ==================== Root Cause Analysis ====================

@router.post("/root-cause", response_model=RootCauseAnalysisResult)
def analyze_root_cause(
    request: RootCauseAnalysisRequest,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Executa análise de causa raiz.
    
    Args:
        request: Parâmetros da análise de causa raiz
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        RootCauseAnalysisResult: Resultado da análise de causa raiz
        
    Raises:
        HTTPException: Se parâmetros são inválidos
    """
    try:
        analysis_service = LineageAnalysisService(db)
        result = analysis_service.analyze_root_cause(request, current_user_id)
        return result
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(e))
    except BusinessRuleError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

@router.get("/root-cause/{entity_id}", response_model=RootCauseAnalysisResult)
def get_entity_root_cause_analysis(
    entity_id: str,
    issue_type: str = Query("data_quality", description="Tipo de problema"),
    max_depth: int = Query(5, ge=1, le=10, description="Profundidade máxima da análise"),
    include_evidence: bool = Query(True, description="Incluir evidências"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Obtém análise de causa raiz para uma entidade específica.
    
    Args:
        entity_id: ID da entidade
        issue_type: Tipo de problema
        max_depth: Profundidade máxima da análise
        include_evidence: Incluir evidências
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        RootCauseAnalysisResult: Resultado da análise de causa raiz
    """
    try:
        analysis_service = LineageAnalysisService(db)
        
        # Construir request
        request = RootCauseAnalysisRequest(
            entity_id=entity_id,
            issue_type=issue_type,
            max_depth=max_depth,
            include_evidence=include_evidence
        )
        
        result = analysis_service.analyze_root_cause(request, current_user_id)
        return result
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

# ==================== Coverage Analysis ====================

@router.post("/coverage", response_model=CoverageAnalysisResult)
def analyze_coverage(
    request: CoverageAnalysisRequest,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Executa análise de cobertura de linhagem.
    
    Args:
        request: Parâmetros da análise de cobertura
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        CoverageAnalysisResult: Resultado da análise de cobertura
        
    Raises:
        HTTPException: Se parâmetros são inválidos
    """
    try:
        analysis_service = LineageAnalysisService(db)
        result = analysis_service.analyze_coverage(request, current_user_id)
        return result
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(e))
    except BusinessRuleError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

@router.get("/coverage/global", response_model=CoverageAnalysisResult)
def get_global_coverage_analysis(
    include_gaps: bool = Query(True, description="Incluir gaps de cobertura"),
    include_recommendations: bool = Query(True, description="Incluir recomendações"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Obtém análise de cobertura global.
    
    Args:
        include_gaps: Incluir gaps de cobertura
        include_recommendations: Incluir recomendações
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        CoverageAnalysisResult: Resultado da análise de cobertura
    """
    try:
        analysis_service = LineageAnalysisService(db)
        
        # Construir request
        request = CoverageAnalysisRequest(
            scope="global",
            include_gaps=include_gaps,
            include_recommendations=include_recommendations
        )
        
        result = analysis_service.analyze_coverage(request, current_user_id)
        return result
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

@router.get("/coverage/system/{system_id}", response_model=CoverageAnalysisResult)
def get_system_coverage_analysis(
    system_id: str,
    include_gaps: bool = Query(True, description="Incluir gaps de cobertura"),
    include_recommendations: bool = Query(True, description="Incluir recomendações"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Obtém análise de cobertura para um sistema específico.
    
    Args:
        system_id: ID do sistema
        include_gaps: Incluir gaps de cobertura
        include_recommendations: Incluir recomendações
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        CoverageAnalysisResult: Resultado da análise de cobertura
    """
    try:
        analysis_service = LineageAnalysisService(db)
        
        # Construir request
        request = CoverageAnalysisRequest(
            scope="system",
            system_id=system_id,
            include_gaps=include_gaps,
            include_recommendations=include_recommendations
        )
        
        result = analysis_service.analyze_coverage(request, current_user_id)
        return result
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

# ==================== Quality Analysis ====================

@router.post("/quality", response_model=QualityAnalysisResult)
def analyze_quality(
    request: QualityAnalysisRequest,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Executa análise de qualidade de linhagem.
    
    Args:
        request: Parâmetros da análise de qualidade
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        QualityAnalysisResult: Resultado da análise de qualidade
        
    Raises:
        HTTPException: Se parâmetros são inválidos
    """
    try:
        analysis_service = LineageAnalysisService(db)
        result = analysis_service.analyze_quality(request, current_user_id)
        return result
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(e))
    except BusinessRuleError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

@router.get("/quality/global", response_model=QualityAnalysisResult)
def get_global_quality_analysis(
    include_suggestions: bool = Query(True, description="Incluir sugestões de melhoria"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Obtém análise de qualidade global.
    
    Args:
        include_suggestions: Incluir sugestões de melhoria
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        QualityAnalysisResult: Resultado da análise de qualidade
    """
    try:
        analysis_service = LineageAnalysisService(db)
        
        # Construir request
        request = QualityAnalysisRequest(
            scope="global",
            include_suggestions=include_suggestions
        )
        
        result = analysis_service.analyze_quality(request, current_user_id)
        return result
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

# ==================== Performance Analysis ====================

@router.post("/performance", response_model=PerformanceAnalysisResult)
def analyze_performance(
    request: PerformanceAnalysisRequest,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Executa análise de performance de linhagem.
    
    Args:
        request: Parâmetros da análise de performance
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        PerformanceAnalysisResult: Resultado da análise de performance
        
    Raises:
        HTTPException: Se parâmetros são inválidos
    """
    try:
        analysis_service = LineageAnalysisService(db)
        result = analysis_service.analyze_performance(request, current_user_id)
        return result
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(e))
    except BusinessRuleError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

@router.get("/performance/bottlenecks", response_model=PerformanceAnalysisResult)
def get_performance_bottlenecks(
    include_optimization: bool = Query(True, description="Incluir sugestões de otimização"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Obtém análise de bottlenecks de performance.
    
    Args:
        include_optimization: Incluir sugestões de otimização
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        PerformanceAnalysisResult: Resultado da análise de performance
    """
    try:
        analysis_service = LineageAnalysisService(db)
        
        # Construir request
        request = PerformanceAnalysisRequest(
            analysis_type="bottlenecks",
            include_optimization=include_optimization
        )
        
        result = analysis_service.analyze_performance(request, current_user_id)
        return result
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

# ==================== Compliance Analysis ====================

@router.post("/compliance", response_model=ComplianceAnalysisResult)
def analyze_compliance(
    request: ComplianceAnalysisRequest,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Executa análise de compliance de linhagem.
    
    Args:
        request: Parâmetros da análise de compliance
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        ComplianceAnalysisResult: Resultado da análise de compliance
        
    Raises:
        HTTPException: Se parâmetros são inválidos
    """
    try:
        analysis_service = LineageAnalysisService(db)
        result = analysis_service.analyze_compliance(request, current_user_id)
        return result
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(e))
    except BusinessRuleError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

@router.get("/compliance/{framework}", response_model=ComplianceAnalysisResult)
def get_framework_compliance_analysis(
    framework: ComplianceFramework,
    include_violations: bool = Query(True, description="Incluir violações"),
    include_recommendations: bool = Query(True, description="Incluir recomendações"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Obtém análise de compliance para um framework específico.
    
    Args:
        framework: Framework de compliance
        include_violations: Incluir violações
        include_recommendations: Incluir recomendações
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        ComplianceAnalysisResult: Resultado da análise de compliance
    """
    try:
        analysis_service = LineageAnalysisService(db)
        
        # Construir request
        request = ComplianceAnalysisRequest(
            framework=framework,
            include_violations=include_violations,
            include_recommendations=include_recommendations
        )
        
        result = analysis_service.analyze_compliance(request, current_user_id)
        return result
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

# ==================== Change Analysis ====================

@router.post("/change", response_model=ChangeAnalysisResult)
def analyze_change(
    request: ChangeAnalysisRequest,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Executa análise de mudanças de linhagem.
    
    Args:
        request: Parâmetros da análise de mudanças
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        ChangeAnalysisResult: Resultado da análise de mudanças
        
    Raises:
        HTTPException: Se parâmetros são inválidos
    """
    try:
        analysis_service = LineageAnalysisService(db)
        result = analysis_service.analyze_change(request, current_user_id)
        return result
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(e))
    except BusinessRuleError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

@router.get("/change/patterns", response_model=ChangeAnalysisResult)
def get_change_patterns_analysis(
    time_period_days: int = Query(30, ge=1, le=365, description="Período de análise em dias"),
    include_predictions: bool = Query(True, description="Incluir predições"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Obtém análise de padrões de mudança.
    
    Args:
        time_period_days: Período de análise em dias
        include_predictions: Incluir predições
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        ChangeAnalysisResult: Resultado da análise de mudanças
    """
    try:
        analysis_service = LineageAnalysisService(db)
        
        # Construir request
        request = ChangeAnalysisRequest(
            analysis_type="patterns",
            time_period_days=time_period_days,
            include_predictions=include_predictions
        )
        
        result = analysis_service.analyze_change(request, current_user_id)
        return result
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

# ==================== Multi-Analysis Operations ====================

@router.post("/comprehensive", response_model=dict)
def run_comprehensive_analysis(
    entity_id: str = Query(..., description="ID da entidade"),
    analysis_types: List[AnalysisType] = Query(..., description="Tipos de análise"),
    max_depth: int = Query(5, ge=1, le=10, description="Profundidade máxima"),
    include_recommendations: bool = Query(True, description="Incluir recomendações"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Executa análise abrangente combinando múltiplos tipos.
    
    Args:
        entity_id: ID da entidade
        analysis_types: Tipos de análise
        max_depth: Profundidade máxima
        include_recommendations: Incluir recomendações
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        dict: Resultados combinados das análises
    """
    try:
        analysis_service = LineageAnalysisService(db)
        results = analysis_service.run_comprehensive_analysis(
            entity_id, analysis_types, max_depth, include_recommendations, current_user_id
        )
        return results
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

# ==================== Analysis History ====================

@router.get("/history", response_model=List[dict])
def get_analysis_history(
    skip: int = Query(0, ge=0, description="Número de registros para pular"),
    limit: int = Query(100, ge=1, le=1000, description="Limite de registros"),
    analysis_type: Optional[AnalysisType] = Query(None, description="Filtrar por tipo de análise"),
    entity_id: Optional[str] = Query(None, description="Filtrar por entidade"),
    user_id: Optional[UUID] = Query(None, description="Filtrar por usuário"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Obtém histórico de análises executadas.
    
    Args:
        skip: Número de registros para pular
        limit: Limite de registros
        analysis_type: Filtrar por tipo de análise
        entity_id: Filtrar por entidade
        user_id: Filtrar por usuário
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        List[dict]: Lista de análises executadas
    """
    try:
        analysis_service = LineageAnalysisService(db)
        history = analysis_service.get_analysis_history(
            skip, limit, analysis_type, entity_id, user_id
        )
        return history
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

# ==================== Analysis Scheduling ====================

@router.post("/schedule", response_model=dict)
def schedule_analysis(
    entity_id: str = Query(..., description="ID da entidade"),
    analysis_type: AnalysisType = Query(..., description="Tipo de análise"),
    schedule_expression: str = Query(..., description="Expressão de agendamento (cron)"),
    enabled: bool = Query(True, description="Análise habilitada"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Agenda análise recorrente.
    
    Args:
        entity_id: ID da entidade
        analysis_type: Tipo de análise
        schedule_expression: Expressão de agendamento (cron)
        enabled: Análise habilitada
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        dict: Informações do agendamento
    """
    try:
        analysis_service = LineageAnalysisService(db)
        schedule_info = analysis_service.schedule_analysis(
            entity_id, analysis_type, schedule_expression, enabled, current_user_id
        )
        return schedule_info
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

@router.get("/schedules", response_model=List[dict])
def get_scheduled_analyses(
    entity_id: Optional[str] = Query(None, description="Filtrar por entidade"),
    analysis_type: Optional[AnalysisType] = Query(None, description="Filtrar por tipo de análise"),
    enabled_only: bool = Query(True, description="Apenas análises habilitadas"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Obtém análises agendadas.
    
    Args:
        entity_id: Filtrar por entidade
        analysis_type: Filtrar por tipo de análise
        enabled_only: Apenas análises habilitadas
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        List[dict]: Lista de análises agendadas
    """
    try:
        analysis_service = LineageAnalysisService(db)
        schedules = analysis_service.get_scheduled_analyses(
            entity_id, analysis_type, enabled_only
        )
        return schedules
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

# ==================== Analysis Export ====================

@router.get("/export", response_model=dict)
def export_analysis_results(
    analysis_ids: List[UUID] = Query(..., description="IDs das análises"),
    format: str = Query("json", regex="^(json|csv|pdf|excel)$", description="Formato de exportação"),
    include_charts: bool = Query(True, description="Incluir gráficos"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Exporta resultados de análises.
    
    Args:
        analysis_ids: IDs das análises
        format: Formato de exportação
        include_charts: Incluir gráficos
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        dict: Dados exportados
    """
    try:
        analysis_service = LineageAnalysisService(db)
        exported_data = analysis_service.export_analysis_results(
            analysis_ids, format, include_charts, current_user_id
        )
        return exported_data
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

