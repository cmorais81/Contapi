#!/usr/bin/env python3
"""
Script para gerar dados mockados de custos Azure e Databricks
Autor: Carlos Morais
Data: Julho 2025
"""

import json
import random
from datetime import datetime, timedelta, date
from decimal import Decimal
import uuid

def generate_azure_cost_data(num_records=100):
    """Gera dados mockados de custos Azure"""
    
    azure_services = [
        'Azure SQL Database',
        'Azure Storage',
        'Azure Synapse Analytics',
        'Azure Data Factory',
        'Azure Cosmos DB',
        'Azure Data Lake Storage',
        'Azure Stream Analytics',
        'Azure Machine Learning',
        'Azure Cognitive Services',
        'Azure Functions'
    ]
    
    resource_types = [
        'Microsoft.Sql/servers/databases',
        'Microsoft.Storage/storageAccounts',
        'Microsoft.Synapse/workspaces',
        'Microsoft.DataFactory/factories',
        'Microsoft.DocumentDB/databaseAccounts',
        'Microsoft.Storage/storageAccounts/blobServices',
        'Microsoft.StreamAnalytics/streamingjobs',
        'Microsoft.MachineLearningServices/workspaces',
        'Microsoft.CognitiveServices/accounts',
        'Microsoft.Web/sites'
    ]
    
    meter_categories = [
        'SQL Database',
        'Storage',
        'Analytics',
        'Data Management',
        'Compute',
        'Networking',
        'AI + Machine Learning'
    ]
    
    departments = ['Data Engineering', 'Analytics', 'Data Science', 'Business Intelligence', 'IT Operations']
    cost_centers = ['CC-001', 'CC-002', 'CC-003', 'CC-004', 'CC-005']
    
    azure_costs = []
    
    for i in range(num_records):
        # Data aleatória nos últimos 90 dias
        cost_date = date.today() - timedelta(days=random.randint(0, 90))
        
        # Custo aleatório baseado no tipo de serviço
        base_cost = random.uniform(10, 5000)
        if 'Synapse' in random.choice(azure_services):
            base_cost *= 3  # Synapse é mais caro
        elif 'Storage' in random.choice(azure_services):
            base_cost *= 0.3  # Storage é mais barato
        
        azure_cost = {
            'id': str(uuid.uuid4()),
            'entity_id': None,  # Será associado depois
            'azure_subscription_id': f'sub-{random.randint(1000, 9999)}',
            'azure_resource_group': f'rg-data-{random.choice(["prod", "dev", "test"])}',
            'azure_resource_name': f'resource-{random.randint(100, 999)}',
            'azure_resource_type': random.choice(resource_types),
            'azure_service_name': random.choice(azure_services),
            'cost_date': cost_date.isoformat(),
            'cost_amount': round(base_cost, 4),
            'cost_currency': 'USD',
            'usage_quantity': round(random.uniform(1, 1000), 4),
            'usage_unit': random.choice(['Hours', 'GB', 'Transactions', 'Requests', 'DTU']),
            'meter_category': random.choice(meter_categories),
            'meter_subcategory': f'Sub-{random.choice(meter_categories)}',
            'meter_name': f'Meter-{random.randint(1, 100)}',
            'billing_period': cost_date.strftime('%Y-%m'),
            'cost_center': random.choice(cost_centers),
            'department': random.choice(departments),
            'tags': {
                'Environment': random.choice(['Production', 'Development', 'Testing']),
                'Project': f'Project-{random.randint(1, 10)}',
                'Owner': f'team-{random.randint(1, 5)}'
            },
            'created_at': datetime.now().isoformat(),
            'updated_at': datetime.now().isoformat()
        }
        
        azure_costs.append(azure_cost)
    
    return azure_costs

def generate_databricks_cost_data(num_records=80):
    """Gera dados mockados de custos Databricks"""
    
    cluster_types = ['all_purpose', 'job', 'sql_warehouse']
    node_types = ['Standard_DS3_v2', 'Standard_DS4_v2', 'Standard_DS5_v2', 'Standard_F4s', 'Standard_F8s']
    runtime_versions = ['11.3.x-scala2.12', '12.2.x-scala2.12', '13.1.x-scala2.12', '13.3.x-scala2.12']
    
    databricks_costs = []
    
    for i in range(num_records):
        # Data aleatória nos últimos 90 dias
        usage_date = date.today() - timedelta(days=random.randint(0, 90))
        
        # Configuração do cluster
        cluster_type = random.choice(cluster_types)
        num_workers = random.randint(2, 20)
        usage_hours = round(random.uniform(0.5, 24), 4)
        
        # Cálculo de custos baseado no tipo de cluster
        dbu_rate = 0.15 if cluster_type == 'job' else 0.40
        dbu_consumed = round(usage_hours * (num_workers + 1) * random.uniform(0.8, 1.2), 4)
        dbu_cost = round(dbu_consumed * dbu_rate, 4)
        
        # Custos adicionais
        compute_cost = round(dbu_cost * 1.5, 4)  # Custo de compute é ~1.5x o DBU
        storage_cost = round(random.uniform(5, 50), 4)
        total_cost = round(dbu_cost + compute_cost + storage_cost, 4)
        
        databricks_cost = {
            'id': str(uuid.uuid4()),
            'entity_id': None,  # Será associado depois
            'databricks_workspace_id': f'ws-{random.randint(10000, 99999)}',
            'databricks_cluster_id': f'cluster-{random.randint(1000, 9999)}',
            'databricks_cluster_name': f'cluster-{random.choice(["analytics", "ml", "etl"])}-{random.randint(1, 10)}',
            'databricks_job_id': f'job-{random.randint(100, 999)}' if cluster_type == 'job' else None,
            'databricks_job_name': f'job-{random.choice(["daily-etl", "ml-training", "data-processing"])}' if cluster_type == 'job' else None,
            'usage_date': usage_date.isoformat(),
            'dbu_consumed': dbu_consumed,
            'dbu_cost': dbu_cost,
            'compute_cost': compute_cost,
            'storage_cost': storage_cost,
            'total_cost': total_cost,
            'cost_currency': 'USD',
            'cluster_type': cluster_type,
            'node_type': random.choice(node_types),
            'driver_node_type': random.choice(node_types),
            'num_workers': num_workers,
            'runtime_version': random.choice(runtime_versions),
            'usage_hours': usage_hours,
            'billing_period': usage_date.strftime('%Y-%m'),
            'tags': {
                'Environment': random.choice(['Production', 'Development', 'Testing']),
                'Team': f'team-{random.randint(1, 5)}',
                'Purpose': random.choice(['ETL', 'Analytics', 'ML', 'Exploration'])
            },
            'created_at': datetime.now().isoformat(),
            'updated_at': datetime.now().isoformat()
        }
        
        databricks_costs.append(databricks_cost)
    
    return databricks_costs

def generate_cost_optimization_recommendations(num_records=25):
    """Gera recomendações de otimização de custos"""
    
    recommendation_types = [
        'storage_optimization',
        'compute_optimization', 
        'lifecycle_management',
        'resource_rightsizing',
        'scheduling_optimization'
    ]
    
    recommendations = []
    
    for i in range(num_records):
        rec_type = random.choice(recommendation_types)
        current_cost = round(random.uniform(500, 10000), 2)
        savings_percentage = random.uniform(0.15, 0.60)  # 15% a 60% de economia
        projected_cost = round(current_cost * (1 - savings_percentage), 2)
        monthly_savings = round(current_cost - projected_cost, 2)
        annual_savings = round(monthly_savings * 12, 2)
        
        titles = {
            'storage_optimization': 'Optimize Storage Tier for Infrequently Accessed Data',
            'compute_optimization': 'Right-size Databricks Clusters Based on Usage Patterns',
            'lifecycle_management': 'Implement Data Lifecycle Management Policies',
            'resource_rightsizing': 'Resize Azure SQL Database Based on Performance Metrics',
            'scheduling_optimization': 'Optimize Cluster Scheduling and Auto-termination'
        }
        
        descriptions = {
            'storage_optimization': 'Move infrequently accessed data to cooler storage tiers to reduce costs while maintaining accessibility.',
            'compute_optimization': 'Analyze cluster usage patterns and right-size compute resources to eliminate over-provisioning.',
            'lifecycle_management': 'Implement automated data archival and deletion policies based on data age and usage.',
            'resource_rightsizing': 'Adjust database compute and storage resources based on actual performance requirements.',
            'scheduling_optimization': 'Implement intelligent scheduling and auto-termination to reduce idle resource costs.'
        }
        
        recommendation = {
            'id': str(uuid.uuid4()),
            'entity_id': None,  # Será associado depois
            'recommendation_type': rec_type,
            'recommendation_title': titles[rec_type],
            'recommendation_description': descriptions[rec_type],
            'current_cost_monthly': current_cost,
            'projected_cost_monthly': projected_cost,
            'potential_savings_monthly': monthly_savings,
            'potential_savings_annual': annual_savings,
            'confidence_score': round(random.uniform(0.7, 0.95), 2),
            'implementation_effort': random.choice(['low', 'medium', 'high']),
            'implementation_timeline': random.choice(['immediate', '1_week', '1_month', '3_months']),
            'risk_level': random.choice(['low', 'medium', 'high']),
            'business_impact': 'Reduce operational costs while maintaining service quality and performance.',
            'technical_requirements': 'Requires configuration changes and monitoring setup.',
            'recommendation_status': random.choice(['open', 'in_progress', 'implemented', 'rejected']),
            'assigned_to': None,  # Será associado depois
            'implementation_date': None,
            'actual_savings_monthly': None,
            'recommendation_metadata': {
                'priority': random.choice(['low', 'medium', 'high']),
                'category': random.choice(['cost', 'performance', 'governance'])
            },
            'created_at': datetime.now().isoformat(),
            'updated_at': datetime.now().isoformat(),
            'created_by': None,  # Será associado depois
            'updated_by': None
        }
        
        recommendations.append(recommendation)
    
    return recommendations

def generate_datahub_entities(num_records=50):
    """Gera entidades mockadas do DataHub"""
    
    platforms = ['mysql', 'postgres', 'snowflake', 'bigquery', 'redshift', 'databricks', 'kafka']
    entity_types = ['dataset', 'chart', 'dashboard', 'dataJob', 'dataFlow']
    
    datahub_entities = []
    
    for i in range(num_records):
        platform = random.choice(platforms)
        entity_type = random.choice(entity_types)
        
        datahub_entity = {
            'id': str(uuid.uuid4()),
            'entity_id': None,  # Será associado depois
            'datahub_urn': f'urn:li:{entity_type}:(urn:li:dataPlatform:{platform},{platform}_db.table_{i},PROD)',
            'datahub_entity_type': entity_type,
            'datahub_platform': platform,
            'datahub_name': f'{platform}_table_{i}',
            'datahub_description': f'Sample {entity_type} from {platform} platform for data governance',
            'datahub_properties': {
                'schema': f'{platform}_schema',
                'database': f'{platform}_db',
                'table_type': 'TABLE' if entity_type == 'dataset' else entity_type.upper()
            },
            'datahub_ownership': {
                'owners': [
                    {'type': 'DATAOWNER', 'name': f'owner_{random.randint(1, 10)}'},
                    {'type': 'TECHNICAL_OWNER', 'name': f'tech_owner_{random.randint(1, 5)}'}
                ]
            },
            'datahub_tags': [f'tag_{random.randint(1, 20)}', f'category_{random.randint(1, 10)}'],
            'datahub_glossary_terms': [f'term_{random.randint(1, 15)}'],
            'datahub_schema': {
                'fields': [
                    {'name': 'id', 'type': 'INTEGER', 'nullable': False},
                    {'name': 'name', 'type': 'STRING', 'nullable': True},
                    {'name': 'created_at', 'type': 'TIMESTAMP', 'nullable': False}
                ]
            },
            'datahub_status': random.choice(['active', 'deprecated']),
            'last_sync_at': datetime.now().isoformat(),
            'sync_status': random.choice(['synced', 'pending', 'failed']),
            'sync_error_message': None,
            'created_at': datetime.now().isoformat(),
            'updated_at': datetime.now().isoformat()
        }
        
        datahub_entities.append(datahub_entity)
    
    return datahub_entities

def main():
    """Função principal para gerar todos os dados mockados"""
    print("🔄 Gerando dados mockados de custos e integrações...")
    
    # Gerar dados de custos
    azure_costs = generate_azure_cost_data(100)
    databricks_costs = generate_databricks_cost_data(80)
    cost_recommendations = generate_cost_optimization_recommendations(25)
    datahub_entities = generate_datahub_entities(50)
    
    # Salvar em arquivos JSON
    with open('mock_data/azure_costs.json', 'w') as f:
        json.dump(azure_costs, f, indent=2, default=str)
    
    with open('mock_data/databricks_costs.json', 'w') as f:
        json.dump(databricks_costs, f, indent=2, default=str)
    
    with open('mock_data/cost_recommendations.json', 'w') as f:
        json.dump(cost_recommendations, f, indent=2, default=str)
    
    with open('mock_data/datahub_entities.json', 'w') as f:
        json.dump(datahub_entities, f, indent=2, default=str)
    
    # Consolidar todos os dados
    all_cost_data = {
        'azure_costs': azure_costs,
        'databricks_costs': databricks_costs,
        'cost_recommendations': cost_recommendations,
        'datahub_entities': datahub_entities
    }
    
    with open('mock_data/all_cost_data.json', 'w') as f:
        json.dump(all_cost_data, f, indent=2, default=str)
    
    print("✅ Dados mockados gerados com sucesso!")
    print(f"   - Azure Costs: {len(azure_costs)} registros")
    print(f"   - Databricks Costs: {len(databricks_costs)} registros")
    print(f"   - Cost Recommendations: {len(cost_recommendations)} registros")
    print(f"   - DataHub Entities: {len(datahub_entities)} registros")
    print(f"   - Total: {len(azure_costs) + len(databricks_costs) + len(cost_recommendations) + len(datahub_entities)} registros")

if __name__ == "__main__":
    main()

