"""
User Service

Service para gerenciamento de usuários, autenticação e perfis.

Author: Carlos Morais <carlos.morais@f1rst.com.br>
Date: Julho 2025
"""

import hashlib
import secrets
import uuid
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any, Tuple
from uuid import UUID

from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, func, desc, asc
from passlib.context import CryptContext
from jose import JWTError, jwt

from app.core.config import settings
from app.core.exceptions import (
    ValidationError, 
    NotFoundError, 
    ConflictError, 
    AuthenticationError,
    AuthorizationError,
    BusinessRuleError
)
from app.models.users.user import User
from app.schemas.users.user import (
    UserCreate, 
    UserUpdate, 
    UserRead, 
    UserSummary,
    UserQueryParams,
    UserStats,
    UserPasswordChange,
    UserPasswordReset,
    UserBulkOperation,
    UserBulkResult,
    UserActivityLog,
    UserSession,
    UserStatus,
    UserType,
    AuthenticationMethod
)
from app.components.audit_logger import AuditLogger


class UserService:
    """
    Service para gerenciamento completo de usuários.
    
    Funcionalidades:
    - Autenticação multi-método
    - Gerenciamento de perfis
    - Controle de sessões
    - Auditoria completa
    - Operações em lote
    - Analytics de usuários
    """
    
    def __init__(self, db: Session):
        self.db = db
        self.pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
        self.audit_logger = AuditLogger(db)
        
        # Configurações de segurança
        self.max_failed_attempts = 5
        self.lockout_duration_minutes = 30
        self.password_expiry_days = 90
        self.session_timeout_minutes = 480
        self.api_key_expiry_days = 365
    
    # ==================== CRUD Operations ====================
    
    def create_user(
        self, 
        user_data: UserCreate, 
        created_by: Optional[UUID] = None
    ) -> UserRead:
        """
        Cria um novo usuário com validações completas.
        
        Args:
            user_data: Dados do usuário
            created_by: ID do usuário que está criando
            
        Returns:
            UserRead: Usuário criado
            
        Raises:
            ConflictError: Se username ou email já existem
            ValidationError: Se dados são inválidos
        """
        try:
            # Validar unicidade
            self._validate_user_uniqueness(user_data.username, user_data.email)
            
            # Criar modelo do usuário
            user = User(
                id=uuid.uuid4(),
                username=user_data.username,
                email=user_data.email,
                user_type=user_data.user_type,
                status=user_data.status,
                authentication_method=user_data.authentication_method,
                profile=user_data.profile.dict(),
                preferences=user_data.preferences.dict(),
                security=user_data.security.dict(),
                is_superuser=user_data.is_superuser,
                is_active=user_data.is_active,
                notes=user_data.notes,
                metadata=user_data.metadata or {},
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow()
            )
            
            # Hash da senha se fornecida
            if user_data.password:
                user.password_hash = self._hash_password(user_data.password)
                user.security["password_last_changed"] = datetime.utcnow().isoformat()
                
                if user_data.temporary_password:
                    user.security["password_expires_at"] = (
                        datetime.utcnow() + timedelta(days=1)
                    ).isoformat()
                else:
                    user.security["password_expires_at"] = (
                        datetime.utcnow() + timedelta(days=self.password_expiry_days)
                    ).isoformat()
            
            # Gerar API key se necessário
            if user_data.authentication_method == AuthenticationMethod.API_KEY:
                api_key = self._generate_api_key()
                user.security["api_key_hash"] = self._hash_api_key(api_key)
                user.security["api_key_expires_at"] = (
                    datetime.utcnow() + timedelta(days=self.api_key_expiry_days)
                ).isoformat()
                user.metadata["api_key"] = api_key  # Retornar apenas uma vez
            
            self.db.add(user)
            self.db.commit()
            self.db.refresh(user)
            
            # Atribuir roles se especificados
            if user_data.role_ids:
                self._assign_roles_to_user(user.id, user_data.role_ids, created_by)
            
            # Log de auditoria
            self.audit_logger.log_user_action(
                user_id=created_by,
                action="user_created",
                target_user_id=user.id,
                details={
                    "username": user.username,
                    "email": user.email,
                    "user_type": user.user_type,
                    "authentication_method": user.authentication_method
                }
            )
            
            # Enviar email de boas-vindas se solicitado
            if user_data.send_welcome_email:
                self._send_welcome_email(user)
            
            return self._to_user_read(user)
            
        except Exception as e:
            self.db.rollback()
            if isinstance(e, (ConflictError, ValidationError)):
                raise
            raise BusinessRuleError(f"Erro ao criar usuário: {str(e)}")
    
    def get_user(self, user_id: UUID) -> Optional[UserRead]:
        """
        Obtém um usuário por ID.
        
        Args:
            user_id: ID do usuário
            
        Returns:
            UserRead: Usuário encontrado ou None
        """
        user = self.db.query(User).filter(User.id == user_id).first()
        return self._to_user_read(user) if user else None
    
    def get_user_by_username(self, username: str) -> Optional[UserRead]:
        """
        Obtém um usuário por username.
        
        Args:
            username: Username do usuário
            
        Returns:
            UserRead: Usuário encontrado ou None
        """
        user = self.db.query(User).filter(User.username == username.lower()).first()
        return self._to_user_read(user) if user else None
    
    def get_user_by_email(self, email: str) -> Optional[UserRead]:
        """
        Obtém um usuário por email.
        
        Args:
            email: Email do usuário
            
        Returns:
            UserRead: Usuário encontrado ou None
        """
        user = self.db.query(User).filter(User.email == email.lower()).first()
        return self._to_user_read(user) if user else None
    
    def update_user(
        self, 
        user_id: UUID, 
        user_data: UserUpdate, 
        updated_by: Optional[UUID] = None
    ) -> UserRead:
        """
        Atualiza um usuário existente.
        
        Args:
            user_id: ID do usuário
            user_data: Dados para atualização
            updated_by: ID do usuário que está atualizando
            
        Returns:
            UserRead: Usuário atualizado
            
        Raises:
            NotFoundError: Se usuário não existe
            ConflictError: Se email já existe para outro usuário
        """
        user = self.db.query(User).filter(User.id == user_id).first()
        if not user:
            raise NotFoundError(f"Usuário {user_id} não encontrado")
        
        try:
            # Validar email único se alterado
            if user_data.email and user_data.email != user.email:
                existing = self.db.query(User).filter(
                    and_(User.email == user_data.email.lower(), User.id != user_id)
                ).first()
                if existing:
                    raise ConflictError(f"Email {user_data.email} já está em uso")
            
            # Armazenar valores antigos para auditoria
            old_values = {
                "email": user.email,
                "user_type": user.user_type,
                "status": user.status,
                "is_active": user.is_active
            }
            
            # Atualizar campos
            update_data = user_data.dict(exclude_unset=True)
            for field, value in update_data.items():
                if hasattr(user, field):
                    if field in ["profile", "preferences", "security", "metadata"]:
                        # Merge com dados existentes
                        current_data = getattr(user, field) or {}
                        if isinstance(value, dict):
                            current_data.update(value)
                            setattr(user, field, current_data)
                        else:
                            setattr(user, field, value.dict() if hasattr(value, 'dict') else value)
                    else:
                        setattr(user, field, value)
            
            user.updated_at = datetime.utcnow()
            
            self.db.commit()
            self.db.refresh(user)
            
            # Log de auditoria
            new_values = {
                "email": user.email,
                "user_type": user.user_type,
                "status": user.status,
                "is_active": user.is_active
            }
            
            self.audit_logger.log_user_action(
                user_id=updated_by,
                action="user_updated",
                target_user_id=user.id,
                details={
                    "old_values": old_values,
                    "new_values": new_values,
                    "changed_fields": list(update_data.keys())
                }
            )
            
            return self._to_user_read(user)
            
        except Exception as e:
            self.db.rollback()
            if isinstance(e, (NotFoundError, ConflictError)):
                raise
            raise BusinessRuleError(f"Erro ao atualizar usuário: {str(e)}")
    
    def delete_user(self, user_id: UUID, deleted_by: Optional[UUID] = None) -> bool:
        """
        Exclui um usuário (soft delete).
        
        Args:
            user_id: ID do usuário
            deleted_by: ID do usuário que está excluindo
            
        Returns:
            bool: True se excluído com sucesso
            
        Raises:
            NotFoundError: Se usuário não existe
            BusinessRuleError: Se não pode ser excluído
        """
        user = self.db.query(User).filter(User.id == user_id).first()
        if not user:
            raise NotFoundError(f"Usuário {user_id} não encontrado")
        
        # Verificar se pode ser excluído
        if user.is_superuser and self._count_superusers() <= 1:
            raise BusinessRuleError("Não é possível excluir o último superusuário")
        
        try:
            # Soft delete
            user.is_active = False
            user.status = UserStatus.INACTIVE
            user.updated_at = datetime.utcnow()
            user.metadata = user.metadata or {}
            user.metadata["deleted_at"] = datetime.utcnow().isoformat()
            user.metadata["deleted_by"] = str(deleted_by) if deleted_by else None
            
            # Invalidar sessões ativas
            self._invalidate_user_sessions(user_id)
            
            self.db.commit()
            
            # Log de auditoria
            self.audit_logger.log_user_action(
                user_id=deleted_by,
                action="user_deleted",
                target_user_id=user.id,
                details={"username": user.username, "email": user.email}
            )
            
            return True
            
        except Exception as e:
            self.db.rollback()
            raise BusinessRuleError(f"Erro ao excluir usuário: {str(e)}")
    
    # ==================== Authentication ====================
    
    def authenticate_user(
        self, 
        username: str, 
        password: str,
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None
    ) -> Optional[UserRead]:
        """
        Autentica um usuário por username/password.
        
        Args:
            username: Username ou email
            password: Senha
            ip_address: Endereço IP
            user_agent: User agent
            
        Returns:
            UserRead: Usuário autenticado ou None
        """
        # Buscar usuário por username ou email
        user = self.db.query(User).filter(
            or_(User.username == username.lower(), User.email == username.lower())
        ).first()
        
        if not user:
            # Log tentativa de login inválida
            self.audit_logger.log_security_event(
                event_type="invalid_login_attempt",
                details={"username": username, "reason": "user_not_found"},
                ip_address=ip_address,
                user_agent=user_agent
            )
            return None
        
        # Verificar se conta está bloqueada
        if self._is_account_locked(user):
            self.audit_logger.log_security_event(
                event_type="locked_account_login_attempt",
                user_id=user.id,
                details={"username": username},
                ip_address=ip_address,
                user_agent=user_agent
            )
            return None
        
        # Verificar senha
        if not self._verify_password(password, user.password_hash):
            self._handle_failed_login(user, ip_address, user_agent)
            return None
        
        # Verificar se usuário está ativo
        if not user.is_active or user.status != UserStatus.ACTIVE:
            self.audit_logger.log_security_event(
                event_type="inactive_user_login_attempt",
                user_id=user.id,
                details={"username": username, "status": user.status},
                ip_address=ip_address,
                user_agent=user_agent
            )
            return None
        
        # Verificar se senha expirou
        if self._is_password_expired(user):
            self.audit_logger.log_security_event(
                event_type="expired_password_login_attempt",
                user_id=user.id,
                details={"username": username},
                ip_address=ip_address,
                user_agent=user_agent
            )
            return None
        
        # Login bem-sucedido
        self._handle_successful_login(user, ip_address, user_agent)
        
        return self._to_user_read(user)
    
    def authenticate_api_key(self, api_key: str) -> Optional[UserRead]:
        """
        Autentica um usuário por API key.
        
        Args:
            api_key: API key
            
        Returns:
            UserRead: Usuário autenticado ou None
        """
        api_key_hash = self._hash_api_key(api_key)
        
        user = self.db.query(User).filter(
            User.security["api_key_hash"].astext == api_key_hash
        ).first()
        
        if not user:
            return None
        
        # Verificar se API key expirou
        if self._is_api_key_expired(user):
            return None
        
        # Verificar se usuário está ativo
        if not user.is_active or user.status != UserStatus.ACTIVE:
            return None
        
        # Atualizar última atividade
        user.last_activity_at = datetime.utcnow()
        self.db.commit()
        
        return self._to_user_read(user)
    
    def change_password(
        self, 
        user_id: UUID, 
        password_data: UserPasswordChange,
        changed_by: Optional[UUID] = None
    ) -> bool:
        """
        Altera a senha de um usuário.
        
        Args:
            user_id: ID do usuário
            password_data: Dados da mudança de senha
            changed_by: ID do usuário que está alterando
            
        Returns:
            bool: True se alterado com sucesso
            
        Raises:
            NotFoundError: Se usuário não existe
            AuthenticationError: Se senha atual está incorreta
        """
        user = self.db.query(User).filter(User.id == user_id).first()
        if not user:
            raise NotFoundError(f"Usuário {user_id} não encontrado")
        
        # Verificar senha atual (exceto se for admin alterando)
        if changed_by != user_id and not self._is_admin_user(changed_by):
            if not self._verify_password(password_data.current_password, user.password_hash):
                raise AuthenticationError("Senha atual incorreta")
        
        try:
            # Atualizar senha
            user.password_hash = self._hash_password(password_data.new_password)
            user.security = user.security or {}
            user.security["password_last_changed"] = datetime.utcnow().isoformat()
            user.security["password_expires_at"] = (
                datetime.utcnow() + timedelta(days=self.password_expiry_days)
            ).isoformat()
            user.security["failed_login_attempts"] = 0
            user.security["account_locked_until"] = None
            user.updated_at = datetime.utcnow()
            
            self.db.commit()
            
            # Invalidar outras sessões se solicitado
            if password_data.force_logout_other_sessions:
                self._invalidate_user_sessions(user_id, exclude_current=True)
            
            # Log de auditoria
            self.audit_logger.log_user_action(
                user_id=changed_by or user_id,
                action="password_changed",
                target_user_id=user.id,
                details={"forced_logout": password_data.force_logout_other_sessions}
            )
            
            return True
            
        except Exception as e:
            self.db.rollback()
            raise BusinessRuleError(f"Erro ao alterar senha: {str(e)}")
    
    def reset_password(self, reset_data: UserPasswordReset) -> bool:
        """
        Reseta a senha de um usuário.
        
        Args:
            reset_data: Dados do reset
            
        Returns:
            bool: True se resetado com sucesso
        """
        user = self.db.query(User).filter(User.email == reset_data.email.lower()).first()
        if not user:
            # Não revelar se email existe
            return True
        
        if reset_data.reset_token and reset_data.new_password:
            # Validar token e definir nova senha
            if self._validate_reset_token(user, reset_data.reset_token):
                user.password_hash = self._hash_password(reset_data.new_password)
                user.security = user.security or {}
                user.security["password_last_changed"] = datetime.utcnow().isoformat()
                user.security["password_expires_at"] = (
                    datetime.utcnow() + timedelta(days=self.password_expiry_days)
                ).isoformat()
                user.security["reset_token"] = None
                user.security["reset_token_expires"] = None
                user.updated_at = datetime.utcnow()
                
                self.db.commit()
                
                # Log de auditoria
                self.audit_logger.log_user_action(
                    user_id=user.id,
                    action="password_reset_completed",
                    target_user_id=user.id,
                    details={"email": user.email}
                )
        else:
            # Gerar token de reset
            reset_token = self._generate_reset_token()
            user.security = user.security or {}
            user.security["reset_token"] = reset_token
            user.security["reset_token_expires"] = (
                datetime.utcnow() + timedelta(hours=24)
            ).isoformat()
            
            self.db.commit()
            
            # Enviar email com token
            self._send_password_reset_email(user, reset_token)
            
            # Log de auditoria
            self.audit_logger.log_user_action(
                user_id=user.id,
                action="password_reset_requested",
                target_user_id=user.id,
                details={"email": user.email}
            )
        
        return True
    
    # ==================== Search and Query ====================
    
    def search_users(
        self, 
        params: UserQueryParams,
        skip: int = 0,
        limit: int = 100
    ) -> Tuple[List[UserSummary], int]:
        """
        Busca usuários com filtros avançados.
        
        Args:
            params: Parâmetros de busca
            skip: Número de registros para pular
            limit: Limite de registros
            
        Returns:
            Tuple[List[UserSummary], int]: Lista de usuários e total
        """
        query = self.db.query(User)
        
        # Aplicar filtros
        if params.username:
            query = query.filter(User.username.ilike(f"%{params.username}%"))
        
        if params.email:
            query = query.filter(User.email.ilike(f"%{params.email}%"))
        
        if params.user_type:
            query = query.filter(User.user_type == params.user_type)
        
        if params.status:
            query = query.filter(User.status == params.status)
        
        if params.authentication_method:
            query = query.filter(User.authentication_method == params.authentication_method)
        
        if params.department:
            query = query.filter(User.profile["department"].astext.ilike(f"%{params.department}%"))
        
        if params.organization:
            query = query.filter(User.profile["organization"].astext.ilike(f"%{params.organization}%"))
        
        if params.is_superuser is not None:
            query = query.filter(User.is_superuser == params.is_superuser)
        
        if params.is_active is not None:
            query = query.filter(User.is_active == params.is_active)
        
        if params.last_login_after:
            query = query.filter(User.last_login_at >= params.last_login_after)
        
        if params.last_login_before:
            query = query.filter(User.last_login_at <= params.last_login_before)
        
        if params.created_after:
            query = query.filter(User.created_at >= params.created_after)
        
        if params.created_before:
            query = query.filter(User.created_at <= params.created_before)
        
        if params.search:
            search_term = f"%{params.search}%"
            query = query.filter(
                or_(
                    User.username.ilike(search_term),
                    User.email.ilike(search_term),
                    User.profile["first_name"].astext.ilike(search_term),
                    User.profile["last_name"].astext.ilike(search_term),
                    User.profile["display_name"].astext.ilike(search_term)
                )
            )
        
        # Filtros especiais
        if params.is_locked:
            current_time = datetime.utcnow().isoformat()
            query = query.filter(User.security["account_locked_until"].astext > current_time)
        
        if params.password_expired:
            current_time = datetime.utcnow().isoformat()
            query = query.filter(User.security["password_expires_at"].astext < current_time)
        
        if params.two_factor_enabled is not None:
            query = query.filter(User.security["two_factor_enabled"].astext.cast(bool) == params.two_factor_enabled)
        
        # Contar total
        total = query.count()
        
        # Aplicar ordenação
        if params.sort_by == "username":
            order_field = User.username
        elif params.sort_by == "email":
            order_field = User.email
        elif params.sort_by == "last_login_at":
            order_field = User.last_login_at
        else:
            order_field = User.created_at
        
        if params.sort_order == "desc":
            query = query.order_by(desc(order_field))
        else:
            query = query.order_by(asc(order_field))
        
        # Aplicar paginação
        users = query.offset(skip).limit(limit).all()
        
        # Converter para UserSummary
        user_summaries = [self._to_user_summary(user) for user in users]
        
        return user_summaries, total
    
    def get_user_stats(self) -> UserStats:
        """
        Obtém estatísticas de usuários.
        
        Returns:
            UserStats: Estatísticas dos usuários
        """
        # Contadores básicos
        total_users = self.db.query(User).count()
        active_users = self.db.query(User).filter(User.is_active == True).count()
        inactive_users = total_users - active_users
        
        # Por status
        suspended_users = self.db.query(User).filter(User.status == UserStatus.SUSPENDED).count()
        locked_users = self.db.query(User).filter(
            User.security["account_locked_until"].astext > datetime.utcnow().isoformat()
        ).count()
        pending_activation = self.db.query(User).filter(User.status == UserStatus.PENDING_ACTIVATION).count()
        
        # Por tipo
        users_by_type = {}
        for user_type in UserType:
            count = self.db.query(User).filter(User.user_type == user_type).count()
            users_by_type[user_type.value] = count
        
        # Por departamento
        users_by_department = {}
        dept_results = self.db.query(
            User.profile["department"].astext.label("department"),
            func.count(User.id).label("count")
        ).filter(
            User.profile["department"].astext.isnot(None)
        ).group_by(User.profile["department"].astext).all()
        
        for dept, count in dept_results:
            users_by_department[dept or "Não informado"] = count
        
        # Por método de autenticação
        users_by_auth_method = {}
        for auth_method in AuthenticationMethod:
            count = self.db.query(User).filter(User.authentication_method == auth_method).count()
            users_by_auth_method[auth_method.value] = count
        
        # Estatísticas especiais
        users_with_2fa = self.db.query(User).filter(
            User.security["two_factor_enabled"].astext.cast(bool) == True
        ).count()
        
        users_with_expired_passwords = self.db.query(User).filter(
            User.security["password_expires_at"].astext < datetime.utcnow().isoformat()
        ).count()
        
        users_never_logged_in = self.db.query(User).filter(User.last_login_at.is_(None)).count()
        
        # Usuários mais ativos (últimos 30 dias)
        thirty_days_ago = datetime.utcnow() - timedelta(days=30)
        most_active_users = self.db.query(User).filter(
            User.last_activity_at >= thirty_days_ago
        ).order_by(desc(User.last_activity_at)).limit(10).all()
        
        # Registros recentes (últimos 7 dias)
        seven_days_ago = datetime.utcnow() - timedelta(days=7)
        recent_registrations = self.db.query(User).filter(
            User.created_at >= seven_days_ago
        ).order_by(desc(User.created_at)).limit(10).all()
        
        return UserStats(
            total_users=total_users,
            active_users=active_users,
            inactive_users=inactive_users,
            suspended_users=suspended_users,
            locked_users=locked_users,
            pending_activation=pending_activation,
            users_by_type=users_by_type,
            users_by_department=users_by_department,
            users_by_authentication_method=users_by_auth_method,
            users_with_2fa=users_with_2fa,
            users_with_expired_passwords=users_with_expired_passwords,
            users_never_logged_in=users_never_logged_in,
            average_session_duration_minutes=self._calculate_average_session_duration(),
            most_active_users=[self._to_user_summary(u) for u in most_active_users],
            recent_registrations=[self._to_user_summary(u) for u in recent_registrations]
        )
    
    # ==================== Bulk Operations ====================
    
    def bulk_operation(
        self, 
        operation: UserBulkOperation,
        performed_by: Optional[UUID] = None
    ) -> UserBulkResult:
        """
        Executa operação em lote nos usuários.
        
        Args:
            operation: Operação a ser executada
            performed_by: ID do usuário que está executando
            
        Returns:
            UserBulkResult: Resultado da operação
        """
        results = []
        errors = []
        successful = 0
        failed = 0
        
        for user_id in operation.user_ids:
            try:
                if operation.operation == "activate":
                    self._bulk_activate_user(user_id, performed_by)
                elif operation.operation == "deactivate":
                    self._bulk_deactivate_user(user_id, performed_by)
                elif operation.operation == "suspend":
                    self._bulk_suspend_user(user_id, performed_by)
                elif operation.operation == "unlock":
                    self._bulk_unlock_user(user_id, performed_by)
                elif operation.operation == "reset_password":
                    self._bulk_reset_password(user_id, performed_by)
                elif operation.operation == "force_password_change":
                    self._bulk_force_password_change(user_id, performed_by)
                else:
                    raise ValueError(f"Operação não suportada: {operation.operation}")
                
                results.append({"user_id": str(user_id), "status": "success"})
                successful += 1
                
            except Exception as e:
                error_detail = {
                    "user_id": str(user_id),
                    "error": str(e),
                    "status": "failed"
                }
                errors.append(error_detail)
                results.append(error_detail)
                failed += 1
        
        # Log de auditoria
        self.audit_logger.log_user_action(
            user_id=performed_by,
            action=f"bulk_{operation.operation}",
            details={
                "total_users": len(operation.user_ids),
                "successful": successful,
                "failed": failed,
                "reason": operation.reason
            }
        )
        
        return UserBulkResult(
            total_requested=len(operation.user_ids),
            successful=successful,
            failed=failed,
            errors=errors,
            results=results
        )
    
    # ==================== Helper Methods ====================
    
    def _validate_user_uniqueness(self, username: str, email: str) -> None:
        """Valida se username e email são únicos."""
        existing_username = self.db.query(User).filter(User.username == username.lower()).first()
        if existing_username:
            raise ConflictError(f"Username {username} já está em uso")
        
        existing_email = self.db.query(User).filter(User.email == email.lower()).first()
        if existing_email:
            raise ConflictError(f"Email {email} já está em uso")
    
    def _hash_password(self, password: str) -> str:
        """Gera hash da senha."""
        return self.pwd_context.hash(password)
    
    def _verify_password(self, plain_password: str, hashed_password: str) -> bool:
        """Verifica se a senha está correta."""
        return self.pwd_context.verify(plain_password, hashed_password)
    
    def _generate_api_key(self) -> str:
        """Gera uma nova API key."""
        return f"dgapi_{secrets.token_urlsafe(32)}"
    
    def _hash_api_key(self, api_key: str) -> str:
        """Gera hash da API key."""
        return hashlib.sha256(api_key.encode()).hexdigest()
    
    def _generate_reset_token(self) -> str:
        """Gera token de reset de senha."""
        return secrets.token_urlsafe(32)
    
    def _is_account_locked(self, user: User) -> bool:
        """Verifica se a conta está bloqueada."""
        if not user.security or not user.security.get("account_locked_until"):
            return False
        
        locked_until = datetime.fromisoformat(user.security["account_locked_until"])
        return datetime.utcnow() < locked_until
    
    def _is_password_expired(self, user: User) -> bool:
        """Verifica se a senha expirou."""
        if not user.security or not user.security.get("password_expires_at"):
            return False
        
        expires_at = datetime.fromisoformat(user.security["password_expires_at"])
        return datetime.utcnow() > expires_at
    
    def _is_api_key_expired(self, user: User) -> bool:
        """Verifica se a API key expirou."""
        if not user.security or not user.security.get("api_key_expires_at"):
            return False
        
        expires_at = datetime.fromisoformat(user.security["api_key_expires_at"])
        return datetime.utcnow() > expires_at
    
    def _handle_failed_login(self, user: User, ip_address: str, user_agent: str) -> None:
        """Processa tentativa de login falhada."""
        user.security = user.security or {}
        failed_attempts = user.security.get("failed_login_attempts", 0) + 1
        user.security["failed_login_attempts"] = failed_attempts
        user.security["last_failed_login"] = datetime.utcnow().isoformat()
        
        # Bloquear conta se muitas tentativas
        if failed_attempts >= self.max_failed_attempts:
            user.security["account_locked_until"] = (
                datetime.utcnow() + timedelta(minutes=self.lockout_duration_minutes)
            ).isoformat()
        
        self.db.commit()
        
        # Log de auditoria
        self.audit_logger.log_security_event(
            event_type="failed_login_attempt",
            user_id=user.id,
            details={
                "username": user.username,
                "failed_attempts": failed_attempts,
                "account_locked": failed_attempts >= self.max_failed_attempts
            },
            ip_address=ip_address,
            user_agent=user_agent
        )
    
    def _handle_successful_login(self, user: User, ip_address: str, user_agent: str) -> None:
        """Processa login bem-sucedido."""
        user.security = user.security or {}
        user.security["failed_login_attempts"] = 0
        user.security["account_locked_until"] = None
        user.last_login_at = datetime.utcnow()
        user.last_activity_at = datetime.utcnow()
        
        self.db.commit()
        
        # Log de auditoria
        self.audit_logger.log_security_event(
            event_type="successful_login",
            user_id=user.id,
            details={"username": user.username},
            ip_address=ip_address,
            user_agent=user_agent
        )
    
    def _to_user_read(self, user: User) -> UserRead:
        """Converte User model para UserRead schema."""
        return UserRead(
            id=user.id,
            username=user.username,
            email=user.email,
            user_type=user.user_type,
            status=user.status,
            authentication_method=user.authentication_method,
            profile=user.profile,
            preferences=user.preferences,
            security=user.security,
            is_superuser=user.is_superuser,
            is_active=user.is_active,
            last_login_at=user.last_login_at,
            last_activity_at=user.last_activity_at,
            notes=user.notes,
            metadata=user.metadata,
            created_at=user.created_at,
            updated_at=user.updated_at
        )
    
    def _to_user_summary(self, user: User) -> UserSummary:
        """Converte User model para UserSummary schema."""
        return UserSummary(
            id=user.id,
            username=user.username,
            email=user.email,
            display_name=user.profile.get("display_name", f"{user.profile.get('first_name', '')} {user.profile.get('last_name', '')}".strip()),
            user_type=user.user_type,
            status=user.status,
            department=user.profile.get("department"),
            last_login_at=user.last_login_at,
            is_active=user.is_active,
            created_at=user.created_at
        )
    
    # Métodos auxiliares para operações específicas
    def _count_superusers(self) -> int:
        """Conta número de superusuários ativos."""
        return self.db.query(User).filter(
            and_(User.is_superuser == True, User.is_active == True)
        ).count()
    
    def _is_admin_user(self, user_id: Optional[UUID]) -> bool:
        """Verifica se usuário é admin."""
        if not user_id:
            return False
        
        user = self.db.query(User).filter(User.id == user_id).first()
        return user and user.is_superuser
    
    def _invalidate_user_sessions(self, user_id: UUID, exclude_current: bool = False) -> None:
        """Invalida sessões do usuário."""
        # Implementar invalidação de sessões
        pass
    
    def _assign_roles_to_user(self, user_id: UUID, role_ids: List[UUID], assigned_by: Optional[UUID]) -> None:
        """Atribui roles ao usuário."""
        # Implementar atribuição de roles
        pass
    
    def _send_welcome_email(self, user: User) -> None:
        """Envia email de boas-vindas."""
        # Implementar envio de email
        pass
    
    def _send_password_reset_email(self, user: User, reset_token: str) -> None:
        """Envia email de reset de senha."""
        # Implementar envio de email
        pass
    
    def _validate_reset_token(self, user: User, token: str) -> bool:
        """Valida token de reset."""
        if not user.security or not user.security.get("reset_token"):
            return False
        
        if user.security["reset_token"] != token:
            return False
        
        expires_at = datetime.fromisoformat(user.security["reset_token_expires"])
        return datetime.utcnow() < expires_at
    
    def _calculate_average_session_duration(self) -> float:
        """Calcula duração média de sessão."""
        # Implementar cálculo de duração de sessão
        return 240.0  # Placeholder
    
    # Métodos para operações em lote
    def _bulk_activate_user(self, user_id: UUID, performed_by: Optional[UUID]) -> None:
        """Ativa usuário em operação em lote."""
        user = self.db.query(User).filter(User.id == user_id).first()
        if user:
            user.is_active = True
            user.status = UserStatus.ACTIVE
            user.updated_at = datetime.utcnow()
            self.db.commit()
    
    def _bulk_deactivate_user(self, user_id: UUID, performed_by: Optional[UUID]) -> None:
        """Desativa usuário em operação em lote."""
        user = self.db.query(User).filter(User.id == user_id).first()
        if user:
            user.is_active = False
            user.status = UserStatus.INACTIVE
            user.updated_at = datetime.utcnow()
            self.db.commit()
    
    def _bulk_suspend_user(self, user_id: UUID, performed_by: Optional[UUID]) -> None:
        """Suspende usuário em operação em lote."""
        user = self.db.query(User).filter(User.id == user_id).first()
        if user:
            user.status = UserStatus.SUSPENDED
            user.updated_at = datetime.utcnow()
            self.db.commit()
    
    def _bulk_unlock_user(self, user_id: UUID, performed_by: Optional[UUID]) -> None:
        """Desbloqueia usuário em operação em lote."""
        user = self.db.query(User).filter(User.id == user_id).first()
        if user and user.security:
            user.security["account_locked_until"] = None
            user.security["failed_login_attempts"] = 0
            user.updated_at = datetime.utcnow()
            self.db.commit()
    
    def _bulk_reset_password(self, user_id: UUID, performed_by: Optional[UUID]) -> None:
        """Reseta senha em operação em lote."""
        user = self.db.query(User).filter(User.id == user_id).first()
        if user:
            # Gerar senha temporária
            temp_password = secrets.token_urlsafe(12)
            user.password_hash = self._hash_password(temp_password)
            user.security = user.security or {}
            user.security["password_expires_at"] = (
                datetime.utcnow() + timedelta(days=1)
            ).isoformat()
            user.updated_at = datetime.utcnow()
            self.db.commit()
            
            # Enviar senha temporária por email
            # self._send_temporary_password_email(user, temp_password)
    
    def _bulk_force_password_change(self, user_id: UUID, performed_by: Optional[UUID]) -> None:
        """Força mudança de senha em operação em lote."""
        user = self.db.query(User).filter(User.id == user_id).first()
        if user:
            user.security = user.security or {}
            user.security["password_expires_at"] = datetime.utcnow().isoformat()
            user.updated_at = datetime.utcnow()
            self.db.commit()

