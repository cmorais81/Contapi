#!/usr/bin/env python3
"""
Data Governance API v2.0 - Script de Inicialização
Desenvolvido por: Carlos Morais
Versão: 2.0.0
"""

import os
import sys
import subprocess
import time
import requests
import json
from pathlib import Path

def print_banner():
    """Exibe banner da aplicação"""
    banner = """
╔══════════════════════════════════════════════════════════════════════════════╗
║                    Data Governance API v2.0                                 ║
║                     Solução Enterprise Completa                             ║
║                                                                              ║
║  🚀 Funcionalidades v2.0:                                                   ║
║     • Integração DataHub nativa                                             ║
║     • Azure Cost Management                                                 ║
║     • Otimização de custos IA                                               ║
║     • Multi-platform orchestration                                          ║
║     • 48+ endpoints testados                                                ║
║                                                                              ║
║  👨‍💻 Desenvolvido por: Carlos Morais                                         ║
║  📅 Versão: 2.0.0 - Julho 2025                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
    """
    print(banner)

def check_python_version():
    """Verifica versão do Python"""
    print("🔍 Verificando versão do Python...")
    if sys.version_info < (3, 11):
        print("❌ Python 3.11+ é necessário")
        print(f"   Versão atual: {sys.version}")
        sys.exit(1)
    print(f"✅ Python {sys.version.split()[0]} - OK")

def check_dependencies():
    """Verifica e instala dependências"""
    print("\n📦 Verificando dependências...")
    
    requirements_file = Path("requirements.txt")
    if not requirements_file.exists():
        print("❌ Arquivo requirements.txt não encontrado")
        sys.exit(1)
    
    try:
        # Instalar dependências
        print("   Instalando dependências...")
        result = subprocess.run([
            sys.executable, "-m", "pip", "install", "-r", "requirements.txt", "--quiet"
        ], capture_output=True, text=True)
        
        if result.returncode != 0:
            print(f"❌ Erro ao instalar dependências: {result.stderr}")
            sys.exit(1)
        
        print("✅ Dependências instaladas com sucesso")
        
    except Exception as e:
        print(f"❌ Erro ao verificar dependências: {e}")
        sys.exit(1)

def check_application_files():
    """Verifica se arquivos da aplicação existem"""
    print("\n📁 Verificando arquivos da aplicação...")
    
    required_files = [
        "app/main_v2_complete.py",
        "docs/technical_documentation.md",
        "docs/data_governance_model_v2.dbml",
        "docs/integration_guide.md"
    ]
    
    missing_files = []
    for file_path in required_files:
        if not Path(file_path).exists():
            missing_files.append(file_path)
    
    if missing_files:
        print("❌ Arquivos obrigatórios não encontrados:")
        for file in missing_files:
            print(f"   - {file}")
        sys.exit(1)
    
    print("✅ Todos os arquivos necessários encontrados")

def start_application():
    """Inicia a aplicação"""
    print("\n🚀 Iniciando Data Governance API v2.0...")
    
    try:
        # Iniciar aplicação em background
        process = subprocess.Popen([
            sys.executable, "app/main_v2_complete.py"
        ], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        
        # Aguardar inicialização
        print("   Aguardando inicialização...")
        time.sleep(8)
        
        # Verificar se aplicação está rodando
        try:
            response = requests.get("http://localhost:8000/health", timeout=5)
            if response.status_code == 200:
                health_data = response.json()
                print("✅ Aplicação iniciada com sucesso!")
                print(f"   Status: {health_data.get('status', 'unknown')}")
                print(f"   Versão: {health_data.get('version', 'unknown')}")
                return process
            else:
                print(f"❌ Aplicação não respondeu corretamente (status: {response.status_code})")
                process.terminate()
                sys.exit(1)
                
        except requests.exceptions.RequestException as e:
            print(f"❌ Erro ao conectar com a aplicação: {e}")
            process.terminate()
            sys.exit(1)
            
    except Exception as e:
        print(f"❌ Erro ao iniciar aplicação: {e}")
        sys.exit(1)

def test_endpoints():
    """Testa endpoints principais"""
    print("\n🧪 Testando endpoints principais...")
    
    endpoints = [
        ("Health Check", "http://localhost:8000/health"),
        ("Estatísticas", "http://localhost:8000/api/v1/stats"),
        ("Entidades", "http://localhost:8000/api/v1/entities/"),
        ("Contratos", "http://localhost:8000/api/v1/contracts/"),
        ("DataHub Stats", "http://localhost:8000/api/v1/datahub/stats"),
        ("Custos Azure", "http://localhost:8000/api/v1/costs/azure/"),
        ("Recomendações", "http://localhost:8000/api/v1/costs/recommendations/summary")
    ]
    
    success_count = 0
    for name, url in endpoints:
        try:
            response = requests.get(url, timeout=5)
            if response.status_code == 200:
                print(f"   ✅ {name}")
                success_count += 1
            else:
                print(f"   ❌ {name} (status: {response.status_code})")
        except Exception as e:
            print(f"   ❌ {name} (erro: {str(e)[:50]}...)")
    
    print(f"\n📊 Resultado dos testes: {success_count}/{len(endpoints)} endpoints funcionando")
    
    if success_count == len(endpoints):
        print("🎉 Todos os endpoints estão funcionando perfeitamente!")
    elif success_count >= len(endpoints) * 0.8:
        print("⚠️  Maioria dos endpoints funcionando - aplicação operacional")
    else:
        print("❌ Muitos endpoints com problemas - verifique logs")

def show_access_info():
    """Mostra informações de acesso"""
    print("\n" + "="*80)
    print("🌐 INFORMAÇÕES DE ACESSO")
    print("="*80)
    print()
    print("📋 URLs Principais:")
    print("   • Documentação Swagger: http://localhost:8000/docs")
    print("   • Documentação ReDoc:   http://localhost:8000/redoc")
    print("   • Health Check:         http://localhost:8000/health")
    print("   • Estatísticas:         http://localhost:8000/api/v1/stats")
    print()
    print("🔍 Endpoints de Descoberta:")
    print("   • Entidades:            http://localhost:8000/api/v1/entities/")
    print("   • Contratos:            http://localhost:8000/api/v1/contracts/")
    print("   • DataHub:              http://localhost:8000/api/v1/datahub/entities/")
    print()
    print("💰 Endpoints de Custos:")
    print("   • Azure Costs:          http://localhost:8000/api/v1/costs/azure/")
    print("   • Databricks Costs:     http://localhost:8000/api/v1/costs/databricks/")
    print("   • Recomendações:        http://localhost:8000/api/v1/costs/recommendations/")
    print()
    print("📊 Dados Mockados Carregados:")
    print("   • 260+ registros distribuídos em 10 domínios")
    print("   • Custos Azure: 100 registros")
    print("   • Custos Databricks: 80 registros")
    print("   • Recomendações: 25 otimizações (R$ 558K economia anual)")
    print("   • DataHub: 50 entidades sincronizadas")
    print()
    print("📚 Documentação:")
    print("   • docs/technical_documentation.md - Documentação técnica completa")
    print("   • docs/integration_guide.md - Guia de integrações")
    print("   • docs/user_journey_guide.md - Jornada do usuário")
    print("   • docs/data_governance_model_v2.dbml - Modelo de dados")
    print()
    print("🧪 Teste Rápido via curl:")
    print("   curl http://localhost:8000/health")
    print("   curl http://localhost:8000/api/v1/stats")
    print("   curl http://localhost:8000/api/v1/costs/recommendations/summary")
    print()
    print("="*80)

def main():
    """Função principal"""
    print_banner()
    
    # Verificações pré-inicialização
    check_python_version()
    check_dependencies()
    check_application_files()
    
    # Iniciar aplicação
    process = start_application()
    
    # Testar endpoints
    test_endpoints()
    
    # Mostrar informações de acesso
    show_access_info()
    
    print("\n🎉 Data Governance API v2.0 está rodando com sucesso!")
    print("💡 Pressione Ctrl+C para parar a aplicação")
    
    try:
        # Manter aplicação rodando
        process.wait()
    except KeyboardInterrupt:
        print("\n\n🛑 Parando aplicação...")
        process.terminate()
        process.wait()
        print("✅ Aplicação parada com sucesso")

if __name__ == "__main__":
    main()

