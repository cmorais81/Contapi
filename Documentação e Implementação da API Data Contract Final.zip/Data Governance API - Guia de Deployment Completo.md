# Data Governance API - Guia de Deployment Completo

## Deployment Enterprise para Produção

**Versão:** 1.0.0  
**Data:** 02 de Julho de 2025  
**Autor:** Carlos Morais <carlos.morais@f1rst.com.br>  

---

## 🎯 Visão Geral

Este guia fornece instruções completas para deployment do Data Governance API em ambientes de produção enterprise. O guia cobre desde configurações básicas até deployments complexos em Kubernetes com alta disponibilidade.

---

## 🏗️ Arquiteturas de Deployment

### Arquitetura Básica (Single Node)

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Load Balancer │    │   Application   │    │    Database     │
│    (Nginx)      │───▶│   (FastAPI)     │───▶│  (PostgreSQL)   │
└─────────────────┘    └─────────────────┘    └─────────────────┘
                                │
                                ▼
                       ┌─────────────────┐
                       │     Cache       │
                       │    (Redis)      │
                       └─────────────────┘
```

### Arquitetura Enterprise (Multi-Node)

```
                    ┌─────────────────┐
                    │   Load Balancer │
                    │   (AWS ALB/ELB) │
                    └─────────┬───────┘
                              │
              ┌───────────────┼───────────────┐
              │               │               │
    ┌─────────▼───────┐ ┌─────▼───────┐ ┌─────▼───────┐
    │   App Node 1    │ │ App Node 2  │ │ App Node 3  │
    │   (FastAPI)     │ │ (FastAPI)   │ │ (FastAPI)   │
    └─────────┬───────┘ └─────┬───────┘ └─────┬───────┘
              │               │               │
              └───────────────┼───────────────┘
                              │
                    ┌─────────▼───────┐
                    │   Database      │
                    │ (PostgreSQL HA) │
                    └─────────────────┘
```

---

## 🐳 Docker Deployment

### Configuração Básica

**docker-compose.yml:**
```yaml
version: '3.8'

services:
  api:
    build: .
    ports:
      - "8000:8000"
    environment:
      - DATABASE_URL=postgresql://user:password@db:5432/governance
      - REDIS_URL=redis://redis:6379
      - JWT_SECRET_KEY=your-secret-key
    depends_on:
      - db
      - redis
    volumes:
      - ./logs:/app/logs
    restart: unless-stopped

  db:
    image: postgres:14
    environment:
      - POSTGRES_DB=governance
      - POSTGRES_USER=user
      - POSTGRES_PASSWORD=password
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./backups:/backups
    restart: unless-stopped

  redis:
    image: redis:6-alpine
    volumes:
      - redis_data:/data
    restart: unless-stopped

  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf
      - ./ssl:/etc/nginx/ssl
    depends_on:
      - api
    restart: unless-stopped

volumes:
  postgres_data:
  redis_data:
```

### Configuração de Produção

**docker-compose.prod.yml:**
```yaml
version: '3.8'

services:
  api:
    image: data-governance-api:latest
    deploy:
      replicas: 3
      resources:
        limits:
          cpus: '2'
          memory: 4G
        reservations:
          cpus: '1'
          memory: 2G
    environment:
      - ENV=production
      - LOG_LEVEL=info
      - WORKERS=4
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/health"]
      interval: 30s
      timeout: 10s
      retries: 3

  db:
    image: postgres:14
    deploy:
      resources:
        limits:
          cpus: '4'
          memory: 8G
    environment:
      - POSTGRES_SHARED_PRELOAD_LIBRARIES=pg_stat_statements
      - POSTGRES_MAX_CONNECTIONS=200
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./postgresql.conf:/etc/postgresql/postgresql.conf
```

---

## ☸️ Kubernetes Deployment

### Namespace e ConfigMap

**namespace.yaml:**
```yaml
apiVersion: v1
kind: Namespace
metadata:
  name: data-governance
  labels:
    name: data-governance
```

**configmap.yaml:**
```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: api-config
  namespace: data-governance
data:
  DATABASE_HOST: "postgres-service"
  DATABASE_PORT: "5432"
  DATABASE_NAME: "governance"
  REDIS_HOST: "redis-service"
  REDIS_PORT: "6379"
  LOG_LEVEL: "info"
  WORKERS: "4"
```

### Secrets

**secrets.yaml:**
```yaml
apiVersion: v1
kind: Secret
metadata:
  name: api-secrets
  namespace: data-governance
type: Opaque
data:
  DATABASE_PASSWORD: <base64-encoded-password>
  JWT_SECRET_KEY: <base64-encoded-secret>
  REDIS_PASSWORD: <base64-encoded-password>
```

### Application Deployment

**deployment.yaml:**
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: api-deployment
  namespace: data-governance
spec:
  replicas: 3
  selector:
    matchLabels:
      app: data-governance-api
  template:
    metadata:
      labels:
        app: data-governance-api
    spec:
      containers:
      - name: api
        image: data-governance-api:latest
        ports:
        - containerPort: 8000
        envFrom:
        - configMapRef:
            name: api-config
        - secretRef:
            name: api-secrets
        resources:
          requests:
            memory: "2Gi"
            cpu: "1"
          limits:
            memory: "4Gi"
            cpu: "2"
        livenessProbe:
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 5
          periodSeconds: 5
```

### Services

**service.yaml:**
```yaml
apiVersion: v1
kind: Service
metadata:
  name: api-service
  namespace: data-governance
spec:
  selector:
    app: data-governance-api
  ports:
  - protocol: TCP
    port: 80
    targetPort: 8000
  type: ClusterIP
```

### Ingress

**ingress.yaml:**
```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: api-ingress
  namespace: data-governance
  annotations:
    kubernetes.io/ingress.class: nginx
    cert-manager.io/cluster-issuer: letsencrypt-prod
    nginx.ingress.kubernetes.io/ssl-redirect: "true"
spec:
  tls:
  - hosts:
    - api.datagovernance.company.com
    secretName: api-tls
  rules:
  - host: api.datagovernance.company.com
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: api-service
            port:
              number: 80
```

---

## 🗄️ Database Setup

### PostgreSQL Configuration

**postgresql.conf:**
```ini
# Connection Settings
max_connections = 200
shared_buffers = 2GB
effective_cache_size = 6GB
work_mem = 16MB
maintenance_work_mem = 512MB

# WAL Settings
wal_buffers = 16MB
checkpoint_completion_target = 0.9
wal_level = replica
max_wal_senders = 3
max_replication_slots = 3

# Logging
log_statement = 'mod'
log_min_duration_statement = 1000
log_checkpoints = on
log_connections = on
log_disconnections = on

# Performance
random_page_cost = 1.1
effective_io_concurrency = 200
```

### Database Initialization

```sql
-- Create database
CREATE DATABASE governance;

-- Create user
CREATE USER governance_user WITH PASSWORD 'secure_password';

-- Grant permissions
GRANT ALL PRIVILEGES ON DATABASE governance TO governance_user;

-- Create extensions
\c governance
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_stat_statements";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";
```

### Backup Strategy

**backup.sh:**
```bash
#!/bin/bash

# Configuration
DB_HOST="localhost"
DB_PORT="5432"
DB_NAME="governance"
DB_USER="governance_user"
BACKUP_DIR="/backups"
RETENTION_DAYS=30

# Create backup
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="${BACKUP_DIR}/governance_${TIMESTAMP}.sql"

pg_dump -h $DB_HOST -p $DB_PORT -U $DB_USER -d $DB_NAME > $BACKUP_FILE

# Compress backup
gzip $BACKUP_FILE

# Remove old backups
find $BACKUP_DIR -name "governance_*.sql.gz" -mtime +$RETENTION_DAYS -delete

echo "Backup completed: ${BACKUP_FILE}.gz"
```

---

## 🔧 Environment Configuration

### Production Environment Variables

```bash
# Application
ENV=production
DEBUG=false
LOG_LEVEL=info
WORKERS=4

# Database
DATABASE_URL=postgresql://user:password@db:5432/governance
DATABASE_POOL_SIZE=20
DATABASE_MAX_OVERFLOW=30

# Redis
REDIS_URL=redis://redis:6379
REDIS_POOL_SIZE=10

# Security
JWT_SECRET_KEY=your-very-secure-secret-key
JWT_ALGORITHM=HS256
JWT_EXPIRE_MINUTES=30

# CORS
CORS_ORIGINS=["https://app.company.com"]
CORS_CREDENTIALS=true

# Rate Limiting
RATE_LIMIT_REQUESTS=1000
RATE_LIMIT_WINDOW=3600

# Monitoring
SENTRY_DSN=https://your-sentry-dsn
PROMETHEUS_ENABLED=true
METRICS_PORT=9090
```

### Development Environment

```bash
# Application
ENV=development
DEBUG=true
LOG_LEVEL=debug
WORKERS=1

# Database
DATABASE_URL=postgresql://user:password@localhost:5432/governance_dev

# Security
JWT_SECRET_KEY=dev-secret-key

# CORS
CORS_ORIGINS=["http://localhost:3000"]
```

---

## 📊 Monitoring e Observability

### Prometheus Configuration

**prometheus.yml:**
```yaml
global:
  scrape_interval: 15s

scrape_configs:
  - job_name: 'data-governance-api'
    static_configs:
      - targets: ['api-service:9090']
    metrics_path: /metrics
    scrape_interval: 30s
```

### Grafana Dashboards

**API Performance Dashboard:**
- Request rate e latency
- Error rate por endpoint
- Database connection pool
- Memory e CPU usage
- Cache hit rate

**Business Metrics Dashboard:**
- Total de contratos ativos
- Execuções de qualidade
- Violações de políticas
- Usuários ativos
- Compliance score

### Alerting Rules

**alerts.yml:**
```yaml
groups:
  - name: data-governance-api
    rules:
      - alert: HighErrorRate
        expr: rate(http_requests_total{status=~"5.."}[5m]) > 0.1
        for: 5m
        labels:
          severity: critical
        annotations:
          summary: High error rate detected

      - alert: DatabaseConnectionsHigh
        expr: pg_stat_activity_count > 180
        for: 2m
        labels:
          severity: warning
        annotations:
          summary: High number of database connections
```

---

## 🔒 Security Configuration

### SSL/TLS Setup

**nginx.conf:**
```nginx
server {
    listen 443 ssl http2;
    server_name api.datagovernance.company.com;

    ssl_certificate /etc/nginx/ssl/cert.pem;
    ssl_certificate_key /etc/nginx/ssl/key.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-RSA-AES256-GCM-SHA512:DHE-RSA-AES256-GCM-SHA512;
    ssl_prefer_server_ciphers off;

    location / {
        proxy_pass http://api:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

### Network Security

**network-policy.yaml:**
```yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: api-network-policy
  namespace: data-governance
spec:
  podSelector:
    matchLabels:
      app: data-governance-api
  policyTypes:
  - Ingress
  - Egress
  ingress:
  - from:
    - namespaceSelector:
        matchLabels:
          name: ingress-nginx
    ports:
    - protocol: TCP
      port: 8000
  egress:
  - to:
    - podSelector:
        matchLabels:
          app: postgres
    ports:
    - protocol: TCP
      port: 5432
```

---

## 🚀 Performance Tuning

### Application Optimization

```python
# gunicorn.conf.py
bind = "0.0.0.0:8000"
workers = 4
worker_class = "uvicorn.workers.UvicornWorker"
worker_connections = 1000
max_requests = 1000
max_requests_jitter = 100
preload_app = True
timeout = 30
keepalive = 5
```

### Database Optimization

```sql
-- Indexes for performance
CREATE INDEX CONCURRENTLY idx_entities_name ON entities USING gin(name gin_trgm_ops);
CREATE INDEX CONCURRENTLY idx_contracts_status ON data_contracts(status);
CREATE INDEX CONCURRENTLY idx_quality_rules_entity ON quality_rules(entity_id);

-- Partitioning for large tables
CREATE TABLE audit_logs_2025 PARTITION OF audit_logs
FOR VALUES FROM ('2025-01-01') TO ('2026-01-01');
```

### Caching Strategy

```python
# Redis configuration
REDIS_CONFIG = {
    "host": "redis",
    "port": 6379,
    "db": 0,
    "decode_responses": True,
    "max_connections": 20,
    "retry_on_timeout": True,
    "socket_keepalive": True,
    "socket_keepalive_options": {},
}

# Cache TTL settings
CACHE_TTL = {
    "entities": 3600,  # 1 hour
    "contracts": 1800,  # 30 minutes
    "users": 900,      # 15 minutes
    "stats": 300,      # 5 minutes
}
```

---

## 🔄 CI/CD Pipeline

### GitHub Actions Workflow

**.github/workflows/deploy.yml:**
```yaml
name: Deploy to Production

on:
  push:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Run tests
        run: |
          docker-compose -f docker-compose.test.yml up --abort-on-container-exit
          docker-compose -f docker-compose.test.yml down

  build:
    needs: test
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Build and push Docker image
        run: |
          docker build -t data-governance-api:${{ github.sha }} .
          docker tag data-governance-api:${{ github.sha }} data-governance-api:latest
          docker push data-governance-api:${{ github.sha }}
          docker push data-governance-api:latest

  deploy:
    needs: build
    runs-on: ubuntu-latest
    steps:
      - name: Deploy to Kubernetes
        run: |
          kubectl set image deployment/api-deployment api=data-governance-api:${{ github.sha }}
          kubectl rollout status deployment/api-deployment
```

---

## 📋 Checklist de Deployment

### Pré-Deployment

- [ ] Configurar variáveis de ambiente
- [ ] Configurar secrets e certificados
- [ ] Configurar database e executar migrações
- [ ] Configurar monitoring e alertas
- [ ] Configurar backup strategy
- [ ] Executar testes de carga
- [ ] Configurar DNS e load balancer

### Pós-Deployment

- [ ] Verificar health checks
- [ ] Verificar logs de aplicação
- [ ] Verificar métricas de performance
- [ ] Executar smoke tests
- [ ] Verificar backup automático
- [ ] Documentar configurações
- [ ] Treinar equipe de operações

---

## 🆘 Troubleshooting

### Problemas Comuns

**Application não inicia:**
```bash
# Verificar logs
kubectl logs -f deployment/api-deployment

# Verificar configuração
kubectl describe pod <pod-name>

# Verificar secrets
kubectl get secrets api-secrets -o yaml
```

**Database connection issues:**
```bash
# Testar conectividade
kubectl exec -it <api-pod> -- psql $DATABASE_URL

# Verificar pool de conexões
kubectl exec -it <api-pod> -- curl localhost:8000/health
```

**Performance issues:**
```bash
# Verificar métricas
kubectl top pods
kubectl top nodes

# Verificar database performance
kubectl exec -it <postgres-pod> -- psql -c "SELECT * FROM pg_stat_activity;"
```

---

## 📞 Suporte

Para suporte técnico durante deployment:
- **Email:** carlos.morais@f1rst.com.br
- **Documentation:** /docs
- **Health Check:** /health
- **Metrics:** /metrics

---

**Data Governance API - Deployment Guide v1.0.0**

