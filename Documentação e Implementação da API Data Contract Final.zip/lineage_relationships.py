"""
Lineage Relationship Endpoints

Endpoints para gerenciamento de relacionamentos de linhagem de dados.

Author: Carlos Morais <carlos.morais@f1rst.com.br>
Date: Julho 2025
"""

from typing import List, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.exceptions import NotFoundError, ConflictError, ValidationError, BusinessRuleError
from app.schemas.lineage.lineage_relationship import (
    LineageRelationshipCreate, 
    LineageRelationshipUpdate, 
    LineageRelationshipRead, 
    LineageRelationshipSummary,
    LineageRelationshipQueryParams,
    LineageRelationshipStats,
    LineageGraph,
    LineagePath,
    LineageValidation,
    LineageBulkOperation,
    LineageBulkResult,
    RelationshipType,
    GranularityLevel
)
from app.services.lineage.lineage_relationship_service import LineageRelationshipService

router = APIRouter()

# ==================== CRUD Operations ====================

@router.post("/", response_model=LineageRelationshipRead, status_code=status.HTTP_201_CREATED)
def create_lineage_relationship(
    relationship_data: LineageRelationshipCreate,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Cria um novo relacionamento de linhagem.
    
    Args:
        relationship_data: Dados do relacionamento
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        LineageRelationshipRead: Relacionamento criado
        
    Raises:
        HTTPException: Se dados são inválidos ou relacionamento já existe
    """
    try:
        lineage_service = LineageRelationshipService(db)
        relationship = lineage_service.create_relationship(relationship_data, current_user_id)
        return relationship
    except ConflictError as e:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(e))
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(e))
    except BusinessRuleError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

@router.get("/{relationship_id}", response_model=LineageRelationshipRead)
def get_lineage_relationship(
    relationship_id: UUID,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Obtém um relacionamento de linhagem por ID.
    
    Args:
        relationship_id: ID do relacionamento
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        LineageRelationshipRead: Relacionamento encontrado
        
    Raises:
        HTTPException: Se relacionamento não encontrado
    """
    try:
        lineage_service = LineageRelationshipService(db)
        relationship = lineage_service.get_relationship(relationship_id)
        if not relationship:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Relacionamento não encontrado")
        return relationship
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

@router.put("/{relationship_id}", response_model=LineageRelationshipRead)
def update_lineage_relationship(
    relationship_id: UUID,
    relationship_data: LineageRelationshipUpdate,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Atualiza um relacionamento de linhagem existente.
    
    Args:
        relationship_id: ID do relacionamento
        relationship_data: Dados para atualização
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        LineageRelationshipRead: Relacionamento atualizado
        
    Raises:
        HTTPException: Se relacionamento não encontrado ou dados inválidos
    """
    try:
        lineage_service = LineageRelationshipService(db)
        relationship = lineage_service.update_relationship(relationship_id, relationship_data, current_user_id)
        return relationship
    except NotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(e))
    except BusinessRuleError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

@router.delete("/{relationship_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_lineage_relationship(
    relationship_id: UUID,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Exclui um relacionamento de linhagem.
    
    Args:
        relationship_id: ID do relacionamento
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Raises:
        HTTPException: Se relacionamento não encontrado
    """
    try:
        lineage_service = LineageRelationshipService(db)
        success = lineage_service.delete_relationship(relationship_id, current_user_id)
        if not success:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Relacionamento não encontrado")
    except NotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except BusinessRuleError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

# ==================== Search and Query ====================

@router.get("/", response_model=List[LineageRelationshipSummary])
def search_lineage_relationships(
    skip: int = Query(0, ge=0, description="Número de registros para pular"),
    limit: int = Query(100, ge=1, le=1000, description="Limite de registros"),
    source_entity: Optional[str] = Query(None, description="Filtrar por entidade origem"),
    target_entity: Optional[str] = Query(None, description="Filtrar por entidade destino"),
    relationship_type: Optional[RelationshipType] = Query(None, description="Filtrar por tipo de relacionamento"),
    granularity_level: Optional[GranularityLevel] = Query(None, description="Filtrar por nível de granularidade"),
    source_system: Optional[str] = Query(None, description="Filtrar por sistema origem"),
    target_system: Optional[str] = Query(None, description="Filtrar por sistema destino"),
    is_active: Optional[bool] = Query(None, description="Filtrar por relacionamentos ativos"),
    confidence_min: Optional[float] = Query(None, ge=0.0, le=1.0, description="Confiança mínima"),
    confidence_max: Optional[float] = Query(None, ge=0.0, le=1.0, description="Confiança máxima"),
    search: Optional[str] = Query(None, description="Busca textual"),
    sort_by: Optional[str] = Query("created_at", description="Campo para ordenação"),
    sort_order: Optional[str] = Query("desc", regex="^(asc|desc)$", description="Ordem de classificação"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Busca relacionamentos de linhagem com filtros avançados.
    
    Args:
        skip: Número de registros para pular
        limit: Limite de registros
        source_entity: Filtrar por entidade origem
        target_entity: Filtrar por entidade destino
        relationship_type: Filtrar por tipo de relacionamento
        granularity_level: Filtrar por nível de granularidade
        source_system: Filtrar por sistema origem
        target_system: Filtrar por sistema destino
        is_active: Filtrar por relacionamentos ativos
        confidence_min: Confiança mínima
        confidence_max: Confiança máxima
        search: Busca textual
        sort_by: Campo para ordenação
        sort_order: Ordem de classificação
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        List[LineageRelationshipSummary]: Lista de relacionamentos
    """
    try:
        lineage_service = LineageRelationshipService(db)
        
        # Construir parâmetros de busca
        params = LineageRelationshipQueryParams(
            source_entity=source_entity,
            target_entity=target_entity,
            relationship_type=relationship_type,
            granularity_level=granularity_level,
            source_system=source_system,
            target_system=target_system,
            is_active=is_active,
            confidence_min=confidence_min,
            confidence_max=confidence_max,
            search=search,
            sort_by=sort_by,
            sort_order=sort_order
        )
        
        relationships, total = lineage_service.search_relationships(params, skip, limit)
        
        return relationships
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

@router.get("/stats", response_model=LineageRelationshipStats)
def get_lineage_stats(
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Obtém estatísticas de relacionamentos de linhagem.
    
    Args:
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        LineageRelationshipStats: Estatísticas dos relacionamentos
    """
    try:
        lineage_service = LineageRelationshipService(db)
        stats = lineage_service.get_lineage_stats()
        return stats
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

# ==================== Graph Operations ====================

@router.get("/graph", response_model=LineageGraph)
def get_lineage_graph(
    entity_id: Optional[str] = Query(None, description="ID da entidade central"),
    max_depth: int = Query(3, ge=1, le=10, description="Profundidade máxima do grafo"),
    direction: str = Query("both", regex="^(upstream|downstream|both)$", description="Direção do grafo"),
    include_inactive: bool = Query(False, description="Incluir relacionamentos inativos"),
    relationship_types: Optional[List[RelationshipType]] = Query(None, description="Tipos de relacionamento"),
    granularity_levels: Optional[List[GranularityLevel]] = Query(None, description="Níveis de granularidade"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Constrói grafo de linhagem para uma entidade.
    
    Args:
        entity_id: ID da entidade central
        max_depth: Profundidade máxima do grafo
        direction: Direção do grafo
        include_inactive: Incluir relacionamentos inativos
        relationship_types: Tipos de relacionamento
        granularity_levels: Níveis de granularidade
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        LineageGraph: Grafo de linhagem
    """
    try:
        lineage_service = LineageRelationshipService(db)
        graph = lineage_service.build_lineage_graph(
            entity_id, max_depth, direction, include_inactive, relationship_types, granularity_levels
        )
        return graph
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

@router.get("/paths", response_model=List[LineagePath])
def find_lineage_paths(
    source_entity: str = Query(..., description="Entidade origem"),
    target_entity: str = Query(..., description="Entidade destino"),
    max_paths: int = Query(10, ge=1, le=100, description="Número máximo de caminhos"),
    max_depth: int = Query(10, ge=1, le=20, description="Profundidade máxima"),
    include_inactive: bool = Query(False, description="Incluir relacionamentos inativos"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Encontra caminhos de linhagem entre duas entidades.
    
    Args:
        source_entity: Entidade origem
        target_entity: Entidade destino
        max_paths: Número máximo de caminhos
        max_depth: Profundidade máxima
        include_inactive: Incluir relacionamentos inativos
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        List[LineagePath]: Lista de caminhos encontrados
    """
    try:
        lineage_service = LineageRelationshipService(db)
        paths = lineage_service.find_paths(source_entity, target_entity, max_paths, max_depth, include_inactive)
        return paths
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

@router.get("/upstream/{entity_id}", response_model=List[LineageRelationshipSummary])
def get_upstream_relationships(
    entity_id: str,
    max_depth: int = Query(5, ge=1, le=10, description="Profundidade máxima"),
    include_inactive: bool = Query(False, description="Incluir relacionamentos inativos"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Obtém relacionamentos upstream de uma entidade.
    
    Args:
        entity_id: ID da entidade
        max_depth: Profundidade máxima
        include_inactive: Incluir relacionamentos inativos
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        List[LineageRelationshipSummary]: Lista de relacionamentos upstream
    """
    try:
        lineage_service = LineageRelationshipService(db)
        relationships = lineage_service.get_upstream_relationships(entity_id, max_depth, include_inactive)
        return relationships
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

@router.get("/downstream/{entity_id}", response_model=List[LineageRelationshipSummary])
def get_downstream_relationships(
    entity_id: str,
    max_depth: int = Query(5, ge=1, le=10, description="Profundidade máxima"),
    include_inactive: bool = Query(False, description="Incluir relacionamentos inativos"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Obtém relacionamentos downstream de uma entidade.
    
    Args:
        entity_id: ID da entidade
        max_depth: Profundidade máxima
        include_inactive: Incluir relacionamentos inativos
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        List[LineageRelationshipSummary]: Lista de relacionamentos downstream
    """
    try:
        lineage_service = LineageRelationshipService(db)
        relationships = lineage_service.get_downstream_relationships(entity_id, max_depth, include_inactive)
        return relationships
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

# ==================== Validation Operations ====================

@router.post("/validate", response_model=LineageValidation)
def validate_lineage_relationships(
    entity_ids: Optional[List[str]] = Query(None, description="IDs das entidades específicas"),
    check_cycles: bool = Query(True, description="Verificar ciclos"),
    check_orphans: bool = Query(True, description="Verificar entidades órfãs"),
    check_integrity: bool = Query(True, description="Verificar integridade"),
    check_confidence: bool = Query(True, description="Verificar confiança"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Valida relacionamentos de linhagem.
    
    Args:
        entity_ids: IDs das entidades específicas
        check_cycles: Verificar ciclos
        check_orphans: Verificar entidades órfãs
        check_integrity: Verificar integridade
        check_confidence: Verificar confiança
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        LineageValidation: Resultado da validação
    """
    try:
        lineage_service = LineageRelationshipService(db)
        validation = lineage_service.validate_lineage(
            entity_ids, check_cycles, check_orphans, check_integrity, check_confidence
        )
        return validation
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

@router.get("/cycles", response_model=List[List[str]])
def detect_lineage_cycles(
    max_cycle_length: int = Query(10, ge=3, le=20, description="Comprimento máximo do ciclo"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Detecta ciclos na linhagem.
    
    Args:
        max_cycle_length: Comprimento máximo do ciclo
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        List[List[str]]: Lista de ciclos detectados
    """
    try:
        lineage_service = LineageRelationshipService(db)
        cycles = lineage_service.detect_cycles(max_cycle_length)
        return cycles
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

@router.get("/orphans", response_model=List[str])
def find_orphan_entities(
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Encontra entidades órfãs (sem relacionamentos).
    
    Args:
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        List[str]: Lista de entidades órfãs
    """
    try:
        lineage_service = LineageRelationshipService(db)
        orphans = lineage_service.find_orphan_entities()
        return orphans
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

# ==================== Bulk Operations ====================

@router.post("/bulk", response_model=LineageBulkResult)
def bulk_lineage_operation(
    operation: LineageBulkOperation,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Executa operação em lote nos relacionamentos de linhagem.
    
    Args:
        operation: Operação a ser executada
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        LineageBulkResult: Resultado da operação
    """
    try:
        lineage_service = LineageRelationshipService(db)
        result = lineage_service.bulk_operation(operation, current_user_id)
        return result
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(e))
    except BusinessRuleError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

# ==================== Relationship Management ====================

@router.post("/{relationship_id}/activate", response_model=LineageRelationshipRead)
def activate_relationship(
    relationship_id: UUID,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Ativa um relacionamento de linhagem.
    
    Args:
        relationship_id: ID do relacionamento
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        LineageRelationshipRead: Relacionamento ativado
    """
    try:
        lineage_service = LineageRelationshipService(db)
        relationship = lineage_service.activate_relationship(relationship_id, current_user_id)
        return relationship
    except NotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except BusinessRuleError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

@router.post("/{relationship_id}/deactivate", response_model=LineageRelationshipRead)
def deactivate_relationship(
    relationship_id: UUID,
    reason: Optional[str] = Query(None, description="Motivo da desativação"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Desativa um relacionamento de linhagem.
    
    Args:
        relationship_id: ID do relacionamento
        reason: Motivo da desativação
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        LineageRelationshipRead: Relacionamento desativado
    """
    try:
        lineage_service = LineageRelationshipService(db)
        relationship = lineage_service.deactivate_relationship(relationship_id, current_user_id, reason)
        return relationship
    except NotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except BusinessRuleError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

# ==================== Discovery Operations ====================

@router.post("/discover", response_model=List[LineageRelationshipSummary])
def discover_lineage_relationships(
    entity_id: str = Query(..., description="ID da entidade para descoberta"),
    discovery_method: str = Query("metadata", regex="^(metadata|query_logs|schema_analysis)$", description="Método de descoberta"),
    confidence_threshold: float = Query(0.7, ge=0.0, le=1.0, description="Limite de confiança"),
    max_suggestions: int = Query(50, ge=1, le=200, description="Máximo de sugestões"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Descobre relacionamentos de linhagem automaticamente.
    
    Args:
        entity_id: ID da entidade para descoberta
        discovery_method: Método de descoberta
        confidence_threshold: Limite de confiança
        max_suggestions: Máximo de sugestões
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        List[LineageRelationshipSummary]: Lista de relacionamentos descobertos
    """
    try:
        lineage_service = LineageRelationshipService(db)
        discovered = lineage_service.discover_relationships(
            entity_id, discovery_method, confidence_threshold, max_suggestions
        )
        return discovered
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

# ==================== Export Operations ====================

@router.get("/export", response_model=dict)
def export_lineage_relationships(
    format: str = Query("json", regex="^(json|csv|xml|graphml)$", description="Formato de exportação"),
    entity_ids: Optional[List[str]] = Query(None, description="IDs das entidades específicas"),
    include_inactive: bool = Query(False, description="Incluir relacionamentos inativos"),
    include_metadata: bool = Query(True, description="Incluir metadados"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Exporta relacionamentos de linhagem.
    
    Args:
        format: Formato de exportação
        entity_ids: IDs das entidades específicas
        include_inactive: Incluir relacionamentos inativos
        include_metadata: Incluir metadados
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        dict: Dados exportados
    """
    try:
        lineage_service = LineageRelationshipService(db)
        exported_data = lineage_service.export_relationships(
            format, entity_ids, include_inactive, include_metadata, current_user_id
        )
        return exported_data
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

# ==================== Metrics and Analytics ====================

@router.get("/metrics/complexity", response_model=dict)
def get_lineage_complexity_metrics(
    entity_id: Optional[str] = Query(None, description="ID da entidade específica"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Obtém métricas de complexidade da linhagem.
    
    Args:
        entity_id: ID da entidade específica
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        dict: Métricas de complexidade
    """
    try:
        lineage_service = LineageRelationshipService(db)
        metrics = lineage_service.get_complexity_metrics(entity_id)
        return metrics
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

@router.get("/metrics/coverage", response_model=dict)
def get_lineage_coverage_metrics(
    system_id: Optional[str] = Query(None, description="ID do sistema específico"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Obtém métricas de cobertura da linhagem.
    
    Args:
        system_id: ID do sistema específico
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        dict: Métricas de cobertura
    """
    try:
        lineage_service = LineageRelationshipService(db)
        metrics = lineage_service.get_coverage_metrics(system_id)
        return metrics
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

@router.get("/metrics/quality", response_model=dict)
def get_lineage_quality_metrics(
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Obtém métricas de qualidade da linhagem.
    
    Args:
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        dict: Métricas de qualidade
    """
    try:
        lineage_service = LineageRelationshipService(db)
        metrics = lineage_service.get_quality_metrics()
        return metrics
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

