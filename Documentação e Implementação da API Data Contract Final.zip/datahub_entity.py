"""
DataHub Entity Model
Modelo para integração com DataHub
"""

from sqlalchemy import Column, String, Text, DateTime, Boolean, Integer, DECIMAL, JSON
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from sqlalchemy import ForeignKey

from app.models.base import Base, GUID


class DataHubEntity(Base):
    """Modelo para entidades sincronizadas do DataHub"""
    __tablename__ = "datahub_entities"

    id = Column(GUID(), primary_key=True, default=func.gen_random_uuid())
    entity_id = Column(GUID(), ForeignKey('entities.id'), nullable=False)
    datahub_urn = Column(String(500), nullable=False, unique=True)
    datahub_entity_type = Column(String(100), nullable=False)  # dataset, chart, dashboard, dataJob
    datahub_platform = Column(String(100), nullable=False)  # mysql, postgres, snowflake
    datahub_name = Column(String(255), nullable=False)
    datahub_description = Column(Text)
    datahub_properties = Column(JSON)
    datahub_ownership = Column(JSON)
    datahub_tags = Column(ARRAY(String))
    datahub_glossary_terms = Column(ARRAY(String))
    datahub_schema = Column(JSON)
    datahub_status = Column(String(50), default='active')
    last_sync_at = Column(DateTime(timezone=True))
    sync_status = Column(String(50), default='pending')  # pending, synced, failed, conflict
    sync_error_message = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    # Relacionamentos
    entity = relationship("Entity", back_populates="datahub_entities")

    def __repr__(self):
        return f"<DataHubEntity(urn='{self.datahub_urn}', type='{self.datahub_entity_type}')>"


class DataHubLineage(Base):
    """Modelo para linhagem sincronizada do DataHub"""
    __tablename__ = "datahub_lineage"

    id = Column(GUID(), primary_key=True, default=func.gen_random_uuid())
    upstream_datahub_urn = Column(String(500), nullable=False)
    downstream_datahub_urn = Column(String(500), nullable=False)
    lineage_type = Column(String(50), nullable=False)  # TRANSFORMED_BY, CONSUMED_BY, PRODUCED_BY
    transformation_type = Column(String(100))  # SQL, SPARK, AIRFLOW
    transformation_info = Column(JSON)
    confidence_score = Column(DECIMAL(3, 2), default=1.0)
    last_observed_at = Column(DateTime(timezone=True))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    def __repr__(self):
        return f"<DataHubLineage(upstream='{self.upstream_datahub_urn}', downstream='{self.downstream_datahub_urn}')>"


class DataHubSyncJob(Base):
    """Modelo para jobs de sincronização com DataHub"""
    __tablename__ = "datahub_sync_jobs"

    id = Column(GUID(), primary_key=True, default=func.gen_random_uuid())
    job_name = Column(String(255), nullable=False)
    job_type = Column(String(50), nullable=False)  # full_sync, incremental_sync, lineage_sync
    datahub_platform = Column(String(100))
    job_status = Column(String(50), default='pending')  # pending, running, completed, failed
    start_time = Column(DateTime(timezone=True))
    end_time = Column(DateTime(timezone=True))
    entities_processed = Column(Integer, default=0)
    entities_created = Column(Integer, default=0)
    entities_updated = Column(Integer, default=0)
    entities_failed = Column(Integer, default=0)
    error_details = Column(JSON)
    job_config = Column(JSON)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    def __repr__(self):
        return f"<DataHubSyncJob(name='{self.job_name}', status='{self.job_status}')>"

