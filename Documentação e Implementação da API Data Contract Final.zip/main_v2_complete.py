#!/usr/bin/env python3
"""
Data Governance API v2.0 - Aplicação Completa
Versão atualizada com integração DataHub e Azure Cost Management
Autor: Carlos Morais
Data: Julho 2025
"""

import json
import os
from datetime import datetime, date, timedelta
from decimal import Decimal
from typing import List, Dict, Any, Optional
import uuid

from fastapi import FastAPI, HTTPException, Query, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import uvicorn

# Configuração da aplicação
app = FastAPI(
    title="Data Governance API v2.0",
    description="API completa para governança de dados com integração DataHub e Azure Cost Management",
    version="2.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# Configuração CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ============================================================================
# SCHEMAS BÁSICOS
# ============================================================================

class BaseResponse(BaseModel):
    """Schema base para respostas"""
    id: str
    created_at: datetime
    updated_at: datetime

class PaginationParams(BaseModel):
    """Parâmetros de paginação"""
    page: int = 1
    size: int = 20

class PaginatedResponse(BaseModel):
    """Resposta paginada genérica"""
    items: List[Any]
    total: int
    page: int
    size: int
    pages: int

# ============================================================================
# SCHEMAS DE ENTIDADES
# ============================================================================

class EntityResponse(BaseResponse):
    """Schema de resposta para entidades"""
    entity_name: str
    entity_type: str
    description: Optional[str] = None
    owner: Optional[str] = None
    status: str = "active"

class ContractResponse(BaseResponse):
    """Schema de resposta para contratos"""
    contract_name: str
    entity_name: str
    producer_team: str
    consumer_teams: List[str]
    status: str = "active"
    cost_allocation: Optional[Dict[str, Any]] = None

class QualityRuleResponse(BaseResponse):
    """Schema de resposta para regras de qualidade"""
    rule_name: str
    entity_name: str
    rule_type: str
    severity: str
    cost_impact_per_violation: Optional[Decimal] = None

# ============================================================================
# SCHEMAS DATAHUB
# ============================================================================

class DataHubEntityResponse(BaseResponse):
    """Schema de resposta para entidades DataHub"""
    datahub_urn: str
    datahub_entity_type: str
    datahub_platform: str
    datahub_name: str
    datahub_description: Optional[str] = None
    sync_status: str = "synced"

class DataHubLineageResponse(BaseResponse):
    """Schema de resposta para linhagem DataHub"""
    upstream_datahub_urn: str
    downstream_datahub_urn: str
    lineage_type: str
    transformation_type: Optional[str] = None
    confidence_score: Decimal = Decimal("1.0")

# ============================================================================
# SCHEMAS CUSTOS AZURE
# ============================================================================

class AzureCostResponse(BaseResponse):
    """Schema de resposta para custos Azure"""
    azure_subscription_id: str
    azure_resource_name: Optional[str] = None
    azure_service_name: Optional[str] = None
    cost_date: date
    cost_amount: Decimal
    cost_currency: str = "USD"

class DataricksCostResponse(BaseResponse):
    """Schema de resposta para custos Databricks"""
    databricks_workspace_id: str
    databricks_cluster_name: Optional[str] = None
    usage_date: date
    dbu_consumed: Decimal
    total_cost: Decimal
    cost_currency: str = "USD"

class CostRecommendationResponse(BaseResponse):
    """Schema de resposta para recomendações de custo"""
    recommendation_type: str
    recommendation_title: str
    current_cost_monthly: Optional[Decimal] = None
    potential_savings_monthly: Optional[Decimal] = None
    confidence_score: Decimal = Decimal("0.8")
    recommendation_status: str = "open"

# ============================================================================
# ARMAZENAMENTO EM MEMÓRIA
# ============================================================================

# Dados em memória
entities_db = []
contracts_db = []
quality_rules_db = []
datahub_entities_db = []
datahub_lineage_db = []
azure_costs_db = []
databricks_costs_db = []
cost_recommendations_db = []

# ============================================================================
# FUNÇÕES DE INICIALIZAÇÃO
# ============================================================================

def load_mock_data():
    """Carrega dados mockados na inicialização"""
    global entities_db, contracts_db, quality_rules_db
    global datahub_entities_db, datahub_lineage_db
    global azure_costs_db, databricks_costs_db, cost_recommendations_db
    
    print("🔄 Carregando dados mockados...")
    
    # Entidades básicas
    entities_db = [
        {
            "id": str(uuid.uuid4()),
            "entity_name": "customer_data",
            "entity_type": "table",
            "description": "Dados de clientes com informações pessoais e de contato",
            "owner": "Data Engineering Team",
            "status": "active",
            "created_at": datetime.now(),
            "updated_at": datetime.now()
        },
        {
            "id": str(uuid.uuid4()),
            "entity_name": "sales_transactions",
            "entity_type": "table", 
            "description": "Transações de vendas com detalhes de produtos e valores",
            "owner": "Analytics Team",
            "status": "active",
            "created_at": datetime.now(),
            "updated_at": datetime.now()
        },
        {
            "id": str(uuid.uuid4()),
            "entity_name": "product_catalog",
            "entity_type": "table",
            "description": "Catálogo de produtos com especificações e preços",
            "owner": "Product Team",
            "status": "active",
            "created_at": datetime.now(),
            "updated_at": datetime.now()
        }
    ]
    
    # Contratos
    contracts_db = [
        {
            "id": str(uuid.uuid4()),
            "contract_name": "Customer Data Contract v2.0",
            "entity_name": "customer_data",
            "producer_team": "Data Engineering",
            "consumer_teams": ["Analytics", "Marketing", "Customer Success"],
            "status": "active",
            "cost_allocation": {
                "producer_percentage": 40,
                "consumer_percentage": 60,
                "monthly_budget": 5000
            },
            "created_at": datetime.now(),
            "updated_at": datetime.now()
        },
        {
            "id": str(uuid.uuid4()),
            "contract_name": "Sales Analytics Contract",
            "entity_name": "sales_transactions",
            "producer_team": "Sales Operations",
            "consumer_teams": ["Business Intelligence", "Finance"],
            "status": "active",
            "cost_allocation": {
                "producer_percentage": 30,
                "consumer_percentage": 70,
                "monthly_budget": 8000
            },
            "created_at": datetime.now(),
            "updated_at": datetime.now()
        }
    ]
    
    # Regras de qualidade
    quality_rules_db = [
        {
            "id": str(uuid.uuid4()),
            "rule_name": "Customer Email Validation",
            "entity_name": "customer_data",
            "rule_type": "validity",
            "severity": "high",
            "cost_impact_per_violation": Decimal("25.50"),
            "created_at": datetime.now(),
            "updated_at": datetime.now()
        },
        {
            "id": str(uuid.uuid4()),
            "rule_name": "Sales Amount Completeness",
            "entity_name": "sales_transactions",
            "rule_type": "completeness",
            "severity": "critical",
            "cost_impact_per_violation": Decimal("100.00"),
            "created_at": datetime.now(),
            "updated_at": datetime.now()
        }
    ]
    
    # Carregar dados de custos se existirem
    try:
        if os.path.exists('mock_data/all_cost_data.json'):
            with open('mock_data/all_cost_data.json', 'r') as f:
                cost_data = json.load(f)
                
            # Processar dados Azure
            for azure_cost in cost_data.get('azure_costs', []):
                azure_costs_db.append({
                    **azure_cost,
                    "cost_amount": Decimal(str(azure_cost["cost_amount"])),
                    "usage_quantity": Decimal(str(azure_cost.get("usage_quantity", 0))),
                    "cost_date": datetime.fromisoformat(azure_cost["cost_date"]).date(),
                    "created_at": datetime.fromisoformat(azure_cost["created_at"]),
                    "updated_at": datetime.fromisoformat(azure_cost["updated_at"])
                })
            
            # Processar dados Databricks
            for databricks_cost in cost_data.get('databricks_costs', []):
                databricks_costs_db.append({
                    **databricks_cost,
                    "dbu_consumed": Decimal(str(databricks_cost["dbu_consumed"])),
                    "dbu_cost": Decimal(str(databricks_cost["dbu_cost"])),
                    "compute_cost": Decimal(str(databricks_cost.get("compute_cost", 0))),
                    "storage_cost": Decimal(str(databricks_cost.get("storage_cost", 0))),
                    "total_cost": Decimal(str(databricks_cost["total_cost"])),
                    "usage_hours": Decimal(str(databricks_cost.get("usage_hours", 0))),
                    "usage_date": datetime.fromisoformat(databricks_cost["usage_date"]).date(),
                    "created_at": datetime.fromisoformat(databricks_cost["created_at"]),
                    "updated_at": datetime.fromisoformat(databricks_cost["updated_at"])
                })
            
            # Processar recomendações
            for recommendation in cost_data.get('cost_recommendations', []):
                cost_recommendations_db.append({
                    **recommendation,
                    "current_cost_monthly": Decimal(str(recommendation.get("current_cost_monthly", 0))),
                    "projected_cost_monthly": Decimal(str(recommendation.get("projected_cost_monthly", 0))),
                    "potential_savings_monthly": Decimal(str(recommendation.get("potential_savings_monthly", 0))),
                    "potential_savings_annual": Decimal(str(recommendation.get("potential_savings_annual", 0))),
                    "confidence_score": Decimal(str(recommendation["confidence_score"])),
                    "created_at": datetime.fromisoformat(recommendation["created_at"]),
                    "updated_at": datetime.fromisoformat(recommendation["updated_at"])
                })
            
            # Processar entidades DataHub
            for datahub_entity in cost_data.get('datahub_entities', []):
                datahub_entities_db.append({
                    **datahub_entity,
                    "created_at": datetime.fromisoformat(datahub_entity["created_at"]),
                    "updated_at": datetime.fromisoformat(datahub_entity["updated_at"]),
                    "last_sync_at": datetime.fromisoformat(datahub_entity["last_sync_at"]) if datahub_entity.get("last_sync_at") else None
                })
                
    except Exception as e:
        print(f"⚠️ Erro ao carregar dados de custos: {e}")
    
    print(f"✅ Dados carregados:")
    print(f"   - Entidades: {len(entities_db)}")
    print(f"   - Contratos: {len(contracts_db)}")
    print(f"   - Regras de Qualidade: {len(quality_rules_db)}")
    print(f"   - Custos Azure: {len(azure_costs_db)}")
    print(f"   - Custos Databricks: {len(databricks_costs_db)}")
    print(f"   - Recomendações: {len(cost_recommendations_db)}")
    print(f"   - Entidades DataHub: {len(datahub_entities_db)}")

def paginate_results(items: List[Any], page: int = 1, size: int = 20) -> Dict[str, Any]:
    """Aplica paginação aos resultados"""
    total = len(items)
    start = (page - 1) * size
    end = start + size
    pages = (total + size - 1) // size
    
    return {
        "items": items[start:end],
        "total": total,
        "page": page,
        "size": size,
        "pages": pages
    }

# ============================================================================
# ENDPOINTS BÁSICOS
# ============================================================================

@app.get("/")
async def root():
    """Endpoint raiz da API"""
    return {
        "message": "Data Governance API v2.0",
        "version": "2.0.0",
        "author": "Carlos Morais",
        "description": "API completa para governança de dados com integração DataHub e Azure Cost Management",
        "features": [
            "Data Contract Management",
            "Quality Monitoring & Validation", 
            "DataHub Integration",
            "Azure Cost Management",
            "Databricks Cost Tracking",
            "Cost Optimization Recommendations",
            "Multi-platform Data Lineage"
        ],
        "endpoints": {
            "docs": "/docs",
            "redoc": "/redoc",
            "health": "/health",
            "stats": "/api/v1/stats"
        }
    }

@app.get("/health")
async def health_check():
    """Health check da aplicação"""
    return {
        "status": "healthy",
        "timestamp": datetime.now(),
        "version": "2.0.0",
        "database": "in-memory",
        "integrations": {
            "datahub": "enabled",
            "azure_cost": "enabled",
            "databricks": "enabled"
        }
    }

@app.get("/api/v1/stats")
async def get_stats():
    """Estatísticas gerais da API"""
    total_azure_cost = sum(item["cost_amount"] for item in azure_costs_db)
    total_databricks_cost = sum(item["total_cost"] for item in databricks_costs_db)
    total_potential_savings = sum(item["potential_savings_monthly"] for item in cost_recommendations_db if item.get("potential_savings_monthly"))
    
    return {
        "entities": {
            "total": len(entities_db),
            "by_type": {"table": len([e for e in entities_db if e["entity_type"] == "table"])}
        },
        "contracts": {
            "total": len(contracts_db),
            "active": len([c for c in contracts_db if c["status"] == "active"])
        },
        "quality_rules": {
            "total": len(quality_rules_db),
            "by_severity": {
                "critical": len([r for r in quality_rules_db if r["severity"] == "critical"]),
                "high": len([r for r in quality_rules_db if r["severity"] == "high"])
            }
        },
        "datahub_integration": {
            "total_entities": len(datahub_entities_db),
            "platforms": list(set(e["datahub_platform"] for e in datahub_entities_db)),
            "sync_status": {
                "synced": len([e for e in datahub_entities_db if e["sync_status"] == "synced"]),
                "pending": len([e for e in datahub_entities_db if e["sync_status"] == "pending"])
            }
        },
        "cost_management": {
            "azure_costs": {
                "total_records": len(azure_costs_db),
                "total_amount": float(total_azure_cost),
                "currency": "USD"
            },
            "databricks_costs": {
                "total_records": len(databricks_costs_db),
                "total_amount": float(total_databricks_cost),
                "currency": "USD"
            },
            "optimization": {
                "total_recommendations": len(cost_recommendations_db),
                "potential_monthly_savings": float(total_potential_savings),
                "open_recommendations": len([r for r in cost_recommendations_db if r["recommendation_status"] == "open"])
            }
        },
        "last_updated": datetime.now()
    }

# ============================================================================
# ENDPOINTS DE ENTIDADES
# ============================================================================

@app.get("/api/v1/entities/", response_model=PaginatedResponse)
async def list_entities(
    page: int = Query(1, ge=1),
    size: int = Query(20, ge=1, le=100),
    entity_type: Optional[str] = Query(None),
    status: Optional[str] = Query(None)
):
    """Lista todas as entidades com paginação e filtros"""
    filtered_entities = entities_db.copy()
    
    if entity_type:
        filtered_entities = [e for e in filtered_entities if e["entity_type"] == entity_type]
    if status:
        filtered_entities = [e for e in filtered_entities if e["status"] == status]
    
    return paginate_results(filtered_entities, page, size)

@app.get("/api/v1/entities/{entity_id}")
async def get_entity(entity_id: str):
    """Obtém uma entidade específica"""
    entity = next((e for e in entities_db if e["id"] == entity_id), None)
    if not entity:
        raise HTTPException(status_code=404, detail="Entity not found")
    return entity

@app.post("/api/v1/entities/")
async def create_entity(entity_data: dict):
    """Cria uma nova entidade"""
    new_entity = {
        "id": str(uuid.uuid4()),
        "created_at": datetime.now(),
        "updated_at": datetime.now(),
        **entity_data
    }
    entities_db.append(new_entity)
    return new_entity

# ============================================================================
# ENDPOINTS DE CONTRATOS
# ============================================================================

@app.get("/api/v1/contracts/", response_model=PaginatedResponse)
async def list_contracts(
    page: int = Query(1, ge=1),
    size: int = Query(20, ge=1, le=100),
    status: Optional[str] = Query(None)
):
    """Lista todos os contratos com paginação"""
    filtered_contracts = contracts_db.copy()
    
    if status:
        filtered_contracts = [c for c in filtered_contracts if c["status"] == status]
    
    return paginate_results(filtered_contracts, page, size)

@app.get("/api/v1/contracts/{contract_id}")
async def get_contract(contract_id: str):
    """Obtém um contrato específico"""
    contract = next((c for c in contracts_db if c["id"] == contract_id), None)
    if not contract:
        raise HTTPException(status_code=404, detail="Contract not found")
    return contract

@app.post("/api/v1/contracts/")
async def create_contract(contract_data: dict):
    """Cria um novo contrato"""
    new_contract = {
        "id": str(uuid.uuid4()),
        "created_at": datetime.now(),
        "updated_at": datetime.now(),
        **contract_data
    }
    contracts_db.append(new_contract)
    return new_contract

# ============================================================================
# ENDPOINTS DE QUALIDADE
# ============================================================================

@app.get("/api/v1/quality/rules/", response_model=PaginatedResponse)
async def list_quality_rules(
    page: int = Query(1, ge=1),
    size: int = Query(20, ge=1, le=100),
    rule_type: Optional[str] = Query(None),
    severity: Optional[str] = Query(None)
):
    """Lista todas as regras de qualidade"""
    filtered_rules = quality_rules_db.copy()
    
    if rule_type:
        filtered_rules = [r for r in filtered_rules if r["rule_type"] == rule_type]
    if severity:
        filtered_rules = [r for r in filtered_rules if r["severity"] == severity]
    
    return paginate_results(filtered_rules, page, size)

@app.get("/api/v1/quality/rules/{rule_id}")
async def get_quality_rule(rule_id: str):
    """Obtém uma regra de qualidade específica"""
    rule = next((r for r in quality_rules_db if r["id"] == rule_id), None)
    if not rule:
        raise HTTPException(status_code=404, detail="Quality rule not found")
    return rule

# ============================================================================
# ENDPOINTS DATAHUB
# ============================================================================

@app.get("/api/v1/datahub/entities/", response_model=PaginatedResponse)
async def list_datahub_entities(
    page: int = Query(1, ge=1),
    size: int = Query(20, ge=1, le=100),
    platform: Optional[str] = Query(None),
    entity_type: Optional[str] = Query(None),
    sync_status: Optional[str] = Query(None)
):
    """Lista entidades sincronizadas do DataHub"""
    filtered_entities = datahub_entities_db.copy()
    
    if platform:
        filtered_entities = [e for e in filtered_entities if e["datahub_platform"] == platform]
    if entity_type:
        filtered_entities = [e for e in filtered_entities if e["datahub_entity_type"] == entity_type]
    if sync_status:
        filtered_entities = [e for e in filtered_entities if e["sync_status"] == sync_status]
    
    return paginate_results(filtered_entities, page, size)

@app.get("/api/v1/datahub/entities/{entity_id}")
async def get_datahub_entity(entity_id: str):
    """Obtém uma entidade DataHub específica"""
    entity = next((e for e in datahub_entities_db if e["id"] == entity_id), None)
    if not entity:
        raise HTTPException(status_code=404, detail="DataHub entity not found")
    return entity

@app.post("/api/v1/datahub/sync")
async def trigger_datahub_sync(sync_request: dict = None):
    """Inicia sincronização com DataHub"""
    return {
        "message": "DataHub sync initiated",
        "sync_id": str(uuid.uuid4()),
        "status": "started",
        "timestamp": datetime.now(),
        "estimated_duration": "5-10 minutes"
    }

@app.get("/api/v1/datahub/stats")
async def get_datahub_stats():
    """Estatísticas de integração DataHub"""
    platforms = list(set(e["datahub_platform"] for e in datahub_entities_db))
    entity_types = list(set(e["datahub_entity_type"] for e in datahub_entities_db))
    
    return {
        "total_entities": len(datahub_entities_db),
        "platforms": platforms,
        "entity_types": entity_types,
        "sync_status_summary": {
            "synced": len([e for e in datahub_entities_db if e["sync_status"] == "synced"]),
            "pending": len([e for e in datahub_entities_db if e["sync_status"] == "pending"]),
            "failed": len([e for e in datahub_entities_db if e["sync_status"] == "failed"])
        },
        "last_sync": max([e.get("last_sync_at") for e in datahub_entities_db if e.get("last_sync_at")], default=None)
    }

# ============================================================================
# ENDPOINTS CUSTOS AZURE
# ============================================================================

@app.get("/api/v1/costs/azure/", response_model=PaginatedResponse)
async def list_azure_costs(
    page: int = Query(1, ge=1),
    size: int = Query(20, ge=1, le=100),
    service_name: Optional[str] = Query(None),
    resource_type: Optional[str] = Query(None),
    start_date: Optional[date] = Query(None),
    end_date: Optional[date] = Query(None)
):
    """Lista custos Azure com filtros"""
    filtered_costs = azure_costs_db.copy()
    
    if service_name:
        filtered_costs = [c for c in filtered_costs if c.get("azure_service_name") == service_name]
    if resource_type:
        filtered_costs = [c for c in filtered_costs if c.get("azure_resource_type") == resource_type]
    if start_date:
        filtered_costs = [c for c in filtered_costs if c["cost_date"] >= start_date]
    if end_date:
        filtered_costs = [c for c in filtered_costs if c["cost_date"] <= end_date]
    
    return paginate_results(filtered_costs, page, size)

@app.get("/api/v1/costs/azure/{cost_id}")
async def get_azure_cost(cost_id: str):
    """Obtém um registro de custo Azure específico"""
    cost = next((c for c in azure_costs_db if c["id"] == cost_id), None)
    if not cost:
        raise HTTPException(status_code=404, detail="Azure cost record not found")
    return cost

@app.get("/api/v1/costs/azure/analysis")
async def analyze_azure_costs(
    start_date: Optional[date] = Query(None),
    end_date: Optional[date] = Query(None),
    group_by: Optional[str] = Query("service_name")
):
    """Análise de custos Azure"""
    filtered_costs = azure_costs_db.copy()
    
    if start_date:
        filtered_costs = [c for c in filtered_costs if c["cost_date"] >= start_date]
    if end_date:
        filtered_costs = [c for c in filtered_costs if c["cost_date"] <= end_date]
    
    total_cost = sum(c["cost_amount"] for c in filtered_costs)
    
    # Agrupamento por serviço
    cost_by_service = {}
    for cost in filtered_costs:
        service = cost.get("azure_service_name", "Unknown")
        cost_by_service[service] = cost_by_service.get(service, Decimal("0")) + cost["cost_amount"]
    
    return {
        "total_cost": float(total_cost),
        "cost_by_service": {k: float(v) for k, v in cost_by_service.items()},
        "period": {
            "start_date": start_date,
            "end_date": end_date
        },
        "records_analyzed": len(filtered_costs),
        "currency": "USD"
    }

# ============================================================================
# ENDPOINTS CUSTOS DATABRICKS
# ============================================================================

@app.get("/api/v1/costs/databricks/", response_model=PaginatedResponse)
async def list_databricks_costs(
    page: int = Query(1, ge=1),
    size: int = Query(20, ge=1, le=100),
    workspace_id: Optional[str] = Query(None),
    cluster_type: Optional[str] = Query(None),
    start_date: Optional[date] = Query(None),
    end_date: Optional[date] = Query(None)
):
    """Lista custos Databricks com filtros"""
    filtered_costs = databricks_costs_db.copy()
    
    if workspace_id:
        filtered_costs = [c for c in filtered_costs if c["databricks_workspace_id"] == workspace_id]
    if cluster_type:
        filtered_costs = [c for c in filtered_costs if c.get("cluster_type") == cluster_type]
    if start_date:
        filtered_costs = [c for c in filtered_costs if c["usage_date"] >= start_date]
    if end_date:
        filtered_costs = [c for c in filtered_costs if c["usage_date"] <= end_date]
    
    return paginate_results(filtered_costs, page, size)

@app.get("/api/v1/costs/databricks/{cost_id}")
async def get_databricks_cost(cost_id: str):
    """Obtém um registro de custo Databricks específico"""
    cost = next((c for c in databricks_costs_db if c["id"] == cost_id), None)
    if not cost:
        raise HTTPException(status_code=404, detail="Databricks cost record not found")
    return cost

@app.get("/api/v1/costs/databricks/analysis")
async def analyze_databricks_costs(
    start_date: Optional[date] = Query(None),
    end_date: Optional[date] = Query(None)
):
    """Análise de custos Databricks"""
    filtered_costs = databricks_costs_db.copy()
    
    if start_date:
        filtered_costs = [c for c in filtered_costs if c["usage_date"] >= start_date]
    if end_date:
        filtered_costs = [c for c in filtered_costs if c["usage_date"] <= end_date]
    
    total_cost = sum(c["total_cost"] for c in filtered_costs)
    total_dbu = sum(c["dbu_consumed"] for c in filtered_costs)
    
    # Agrupamento por tipo de cluster
    cost_by_cluster_type = {}
    for cost in filtered_costs:
        cluster_type = cost.get("cluster_type", "unknown")
        cost_by_cluster_type[cluster_type] = cost_by_cluster_type.get(cluster_type, Decimal("0")) + cost["total_cost"]
    
    return {
        "total_cost": float(total_cost),
        "total_dbu_consumed": float(total_dbu),
        "average_cost_per_dbu": float(total_cost / total_dbu) if total_dbu > 0 else 0,
        "cost_by_cluster_type": {k: float(v) for k, v in cost_by_cluster_type.items()},
        "period": {
            "start_date": start_date,
            "end_date": end_date
        },
        "records_analyzed": len(filtered_costs),
        "currency": "USD"
    }

# ============================================================================
# ENDPOINTS RECOMENDAÇÕES DE CUSTO
# ============================================================================

@app.get("/api/v1/costs/recommendations/", response_model=PaginatedResponse)
async def list_cost_recommendations(
    page: int = Query(1, ge=1),
    size: int = Query(20, ge=1, le=100),
    recommendation_type: Optional[str] = Query(None),
    status: Optional[str] = Query(None),
    min_savings: Optional[float] = Query(None)
):
    """Lista recomendações de otimização de custos"""
    filtered_recommendations = cost_recommendations_db.copy()
    
    if recommendation_type:
        filtered_recommendations = [r for r in filtered_recommendations if r["recommendation_type"] == recommendation_type]
    if status:
        filtered_recommendations = [r for r in filtered_recommendations if r["recommendation_status"] == status]
    if min_savings:
        filtered_recommendations = [r for r in filtered_recommendations 
                                  if r.get("potential_savings_monthly", 0) >= min_savings]
    
    return paginate_results(filtered_recommendations, page, size)

@app.get("/api/v1/costs/recommendations/summary")
async def get_recommendations_summary():
    """Resumo das recomendações de custo"""
    total_potential_savings = sum(r.get("potential_savings_monthly", 0) for r in cost_recommendations_db)
    
    by_type = {}
    by_status = {}
    
    for rec in cost_recommendations_db:
        rec_type = rec["recommendation_type"]
        status = rec["recommendation_status"]
        
        by_type[rec_type] = by_type.get(rec_type, 0) + 1
        by_status[status] = by_status.get(status, 0) + 1
    
    return {
        "total_recommendations": len(cost_recommendations_db),
        "total_potential_monthly_savings": float(total_potential_savings),
        "total_potential_annual_savings": float(total_potential_savings * 12),
        "by_type": by_type,
        "by_status": by_status,
        "average_confidence_score": float(sum(r["confidence_score"] for r in cost_recommendations_db) / len(cost_recommendations_db)) if cost_recommendations_db else 0
    }

@app.get("/api/v1/costs/recommendations/{recommendation_id}")
async def get_cost_recommendation(recommendation_id: str):
    """Obtém uma recomendação específica"""
    recommendation = next((r for r in cost_recommendations_db if r["id"] == recommendation_id), None)
    if not recommendation:
        raise HTTPException(status_code=404, detail="Cost recommendation not found")
    return recommendation

# ============================================================================
# INICIALIZAÇÃO
# ============================================================================

@app.on_event("startup")
async def startup_event():
    """Evento de inicialização da aplicação"""
    print("🚀 Iniciando Data Governance API v2.0...")
    print("👨‍💻 Desenvolvido por: Carlos Morais")
    load_mock_data()
    print("✅ API inicializada com sucesso!")

if __name__ == "__main__":
    print("🔄 Iniciando servidor...")
    uvicorn.run(
        "main_v2_complete:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )

