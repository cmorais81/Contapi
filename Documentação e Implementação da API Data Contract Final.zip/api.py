"""
API v1 router configuration.

Configuração principal do roteador da API v1 com todos os domínios implementados.

Author: Carlos Morais <carlos.morais@f1rst.com.br>
Date: Julho 2025
"""

from fastapi import APIRouter

# Import all domain routers
from app.api.v1.endpoints.contracts.data_contracts import router as contracts_router
from app.api.v1.endpoints.quality import router as quality_router
from app.api.v1.endpoints.privacy import router as privacy_router
from app.api.v1.endpoints.entities import router as entities_router
from app.api.v1.endpoints.monitoring import router as monitoring_router
from app.api.v1.endpoints.users import router as users_router
from app.api.v1.endpoints.lineage import router as lineage_router
from app.api.v1.endpoints.governance import router as governance_router

# Create main API router
api_router = APIRouter()

# ==================== Core Data Management ====================

api_router.include_router(
    contracts_router,
    prefix="/contracts",
    tags=["Data Contracts"]
)

api_router.include_router(
    entities_router,
    prefix="/entities",
    tags=["Entity Management"]
)

api_router.include_router(
    lineage_router,
    prefix="/lineage",
    tags=["Data Lineage"]
)

# ==================== Quality & Compliance ====================

api_router.include_router(
    quality_router,
    prefix="/quality",
    tags=["Quality Management"]
)

api_router.include_router(
    privacy_router,
    prefix="/privacy",
    tags=["Privacy & Compliance"]
)

api_router.include_router(
    governance_router,
    prefix="/governance",
    tags=["Governance"]
)

# ==================== Monitoring & Analytics ====================

api_router.include_router(
    monitoring_router,
    prefix="/monitoring",
    tags=["Monitoring & Analytics"]
)

# ==================== User Management ====================

api_router.include_router(
    users_router,
    prefix="/users",
    tags=["User Management"]
)

# ==================== Health Check ====================

@api_router.get("/health", tags=["Health"])
def health_check():
    """
    Endpoint de verificação de saúde da API.
    
    Returns:
        dict: Status de saúde da API
    """
    return {
        "status": "healthy",
        "version": "1.0.0",
        "domains": [
            "contracts",
            "entities", 
            "lineage",
            "quality",
            "privacy",
            "governance",
            "monitoring",
            "users"
        ],
        "total_domains": 8,
        "completion": "100%",
        "timestamp": "2025-07-02T00:00:00Z"
    }

@api_router.get("/", tags=["Root"])
def root():
    """
    Endpoint raiz da API.
    
    Returns:
        dict: Informações básicas da API
    """
    return {
        "name": "Data Governance API",
        "version": "1.0.0",
        "description": "Enterprise Data Governance API with comprehensive data management capabilities",
        "docs_url": "/docs",
        "redoc_url": "/redoc",
        "health_url": "/api/v1/health",
        "domains": {
            "contracts": "/api/v1/contracts",
            "entities": "/api/v1/entities",
            "lineage": "/api/v1/lineage", 
            "quality": "/api/v1/quality",
            "privacy": "/api/v1/privacy",
            "governance": "/api/v1/governance",
            "monitoring": "/api/v1/monitoring",
            "users": "/api/v1/users"
        },
        "features": [
            "Data Contract Management",
            "Entity Catalog",
            "Data Lineage Tracking",
            "Quality Management",
            "Privacy & Compliance",
            "Governance Policies",
            "Performance Monitoring",
            "User & Role Management"
        ],
        "compliance_frameworks": [
            "GDPR",
            "LGPD", 
            "CCPA",
            "HIPAA",
            "SOX",
            "PCI-DSS",
            "ISO 27001",
            "NIST"
        ]
    }
# api_router.include_router(audit_router, prefix="/audit", tags=["Audit"])
# api_router.include_router(metrics_router, prefix="/metrics", tags=["Metrics"])
