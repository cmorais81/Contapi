"""
User Endpoints

Endpoints para gerenciamento de usuários.

Author: Carlos Morais <carlos.morais@f1rst.com.br>
Date: Julho 2025
"""

from typing import List, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.exceptions import NotFoundError, ConflictError, ValidationError, BusinessRuleError
from app.schemas.users.user import (
    UserCreate, 
    UserUpdate, 
    UserRead, 
    UserSummary,
    UserQueryParams,
    UserStats,
    UserProfile,
    UserPreferences,
    UserSecuritySettings,
    UserActivityLog,
    UserSessionInfo,
    UserBulkOperation,
    UserBulkResult,
    UserPasswordReset,
    UserActivation,
    UserSuspension,
    AuthenticationMethod,
    UserType,
    UserStatus
)
from app.services.users.user_service import UserService
from app.components.audit_logger import AuditLogger

router = APIRouter()

# ==================== CRUD Operations ====================

@router.post("/", response_model=UserRead, status_code=status.HTTP_201_CREATED)
def create_user(
    user_data: UserCreate,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None  # TODO: Implement auth dependency
):
    """
    Cria um novo usuário.
    
    Args:
        user_data: Dados do usuário
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        UserRead: Usuário criado
        
    Raises:
        HTTPException: Se dados são inválidos ou usuário já existe
    """
    try:
        user_service = UserService(db)
        user = user_service.create_user(user_data, current_user_id)
        return user
    except ConflictError as e:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(e))
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(e))
    except BusinessRuleError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

@router.get("/{user_id}", response_model=UserRead)
def get_user(
    user_id: UUID,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Obtém um usuário por ID.
    
    Args:
        user_id: ID do usuário
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        UserRead: Usuário encontrado
        
    Raises:
        HTTPException: Se usuário não encontrado
    """
    try:
        user_service = UserService(db)
        user = user_service.get_user(user_id)
        if not user:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Usuário não encontrado")
        return user
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

@router.put("/{user_id}", response_model=UserRead)
def update_user(
    user_id: UUID,
    user_data: UserUpdate,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Atualiza um usuário existente.
    
    Args:
        user_id: ID do usuário
        user_data: Dados para atualização
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        UserRead: Usuário atualizado
        
    Raises:
        HTTPException: Se usuário não encontrado ou dados inválidos
    """
    try:
        user_service = UserService(db)
        user = user_service.update_user(user_id, user_data, current_user_id)
        return user
    except NotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(e))
    except BusinessRuleError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

@router.delete("/{user_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_user(
    user_id: UUID,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Exclui um usuário.
    
    Args:
        user_id: ID do usuário
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Raises:
        HTTPException: Se usuário não encontrado
    """
    try:
        user_service = UserService(db)
        success = user_service.delete_user(user_id, current_user_id)
        if not success:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Usuário não encontrado")
    except NotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except BusinessRuleError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

# ==================== Search and Query ====================

@router.get("/", response_model=List[UserSummary])
def search_users(
    skip: int = Query(0, ge=0, description="Número de registros para pular"),
    limit: int = Query(100, ge=1, le=1000, description="Limite de registros"),
    username: Optional[str] = Query(None, description="Filtrar por username"),
    email: Optional[str] = Query(None, description="Filtrar por email"),
    user_type: Optional[UserType] = Query(None, description="Filtrar por tipo de usuário"),
    status: Optional[UserStatus] = Query(None, description="Filtrar por status"),
    is_active: Optional[bool] = Query(None, description="Filtrar por usuários ativos"),
    department: Optional[str] = Query(None, description="Filtrar por departamento"),
    search: Optional[str] = Query(None, description="Busca textual"),
    sort_by: Optional[str] = Query("created_at", description="Campo para ordenação"),
    sort_order: Optional[str] = Query("desc", regex="^(asc|desc)$", description="Ordem de classificação"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Busca usuários com filtros avançados.
    
    Args:
        skip: Número de registros para pular
        limit: Limite de registros
        username: Filtrar por username
        email: Filtrar por email
        user_type: Filtrar por tipo de usuário
        status: Filtrar por status
        is_active: Filtrar por usuários ativos
        department: Filtrar por departamento
        search: Busca textual
        sort_by: Campo para ordenação
        sort_order: Ordem de classificação
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        List[UserSummary]: Lista de usuários
    """
    try:
        user_service = UserService(db)
        
        # Construir parâmetros de busca
        params = UserQueryParams(
            username=username,
            email=email,
            user_type=user_type,
            status=status,
            is_active=is_active,
            department=department,
            search=search,
            sort_by=sort_by,
            sort_order=sort_order
        )
        
        users, total = user_service.search_users(params, skip, limit)
        
        # Adicionar header com total de registros
        # response.headers["X-Total-Count"] = str(total)
        
        return users
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

@router.get("/stats", response_model=UserStats)
def get_user_stats(
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Obtém estatísticas de usuários.
    
    Args:
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        UserStats: Estatísticas dos usuários
    """
    try:
        user_service = UserService(db)
        stats = user_service.get_user_stats()
        return stats
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

# ==================== User Profile Management ====================

@router.get("/{user_id}/profile", response_model=UserProfile)
def get_user_profile(
    user_id: UUID,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Obtém perfil de um usuário.
    
    Args:
        user_id: ID do usuário
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        UserProfile: Perfil do usuário
    """
    try:
        user_service = UserService(db)
        profile = user_service.get_user_profile(user_id)
        if not profile:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Perfil não encontrado")
        return profile
    except NotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

@router.put("/{user_id}/profile", response_model=UserProfile)
def update_user_profile(
    user_id: UUID,
    profile_data: UserProfile,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Atualiza perfil de um usuário.
    
    Args:
        user_id: ID do usuário
        profile_data: Dados do perfil
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        UserProfile: Perfil atualizado
    """
    try:
        user_service = UserService(db)
        profile = user_service.update_user_profile(user_id, profile_data, current_user_id)
        return profile
    except NotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(e))
    except BusinessRuleError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

# ==================== User Preferences ====================

@router.get("/{user_id}/preferences", response_model=UserPreferences)
def get_user_preferences(
    user_id: UUID,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Obtém preferências de um usuário.
    
    Args:
        user_id: ID do usuário
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        UserPreferences: Preferências do usuário
    """
    try:
        user_service = UserService(db)
        preferences = user_service.get_user_preferences(user_id)
        if not preferences:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Preferências não encontradas")
        return preferences
    except NotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

@router.put("/{user_id}/preferences", response_model=UserPreferences)
def update_user_preferences(
    user_id: UUID,
    preferences_data: UserPreferences,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Atualiza preferências de um usuário.
    
    Args:
        user_id: ID do usuário
        preferences_data: Dados das preferências
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        UserPreferences: Preferências atualizadas
    """
    try:
        user_service = UserService(db)
        preferences = user_service.update_user_preferences(user_id, preferences_data, current_user_id)
        return preferences
    except NotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(e))
    except BusinessRuleError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

# ==================== Security Management ====================

@router.get("/{user_id}/security", response_model=UserSecuritySettings)
def get_user_security_settings(
    user_id: UUID,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Obtém configurações de segurança de um usuário.
    
    Args:
        user_id: ID do usuário
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        UserSecuritySettings: Configurações de segurança
    """
    try:
        user_service = UserService(db)
        security_settings = user_service.get_user_security_settings(user_id)
        if not security_settings:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Configurações não encontradas")
        return security_settings
    except NotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

@router.put("/{user_id}/security", response_model=UserSecuritySettings)
def update_user_security_settings(
    user_id: UUID,
    security_data: UserSecuritySettings,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Atualiza configurações de segurança de um usuário.
    
    Args:
        user_id: ID do usuário
        security_data: Dados de segurança
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        UserSecuritySettings: Configurações atualizadas
    """
    try:
        user_service = UserService(db)
        security_settings = user_service.update_user_security_settings(user_id, security_data, current_user_id)
        return security_settings
    except NotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(e))
    except BusinessRuleError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

# ==================== Authentication Management ====================

@router.post("/{user_id}/password-reset", status_code=status.HTTP_204_NO_CONTENT)
def reset_user_password(
    user_id: UUID,
    reset_data: UserPasswordReset,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Inicia processo de reset de senha.
    
    Args:
        user_id: ID do usuário
        reset_data: Dados do reset
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
    """
    try:
        user_service = UserService(db)
        user_service.reset_user_password(user_id, reset_data, current_user_id)
    except NotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except BusinessRuleError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

@router.post("/{user_id}/activate", response_model=UserRead)
def activate_user(
    user_id: UUID,
    activation_data: UserActivation,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Ativa um usuário.
    
    Args:
        user_id: ID do usuário
        activation_data: Dados de ativação
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        UserRead: Usuário ativado
    """
    try:
        user_service = UserService(db)
        user = user_service.activate_user(user_id, activation_data, current_user_id)
        return user
    except NotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except BusinessRuleError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

@router.post("/{user_id}/suspend", response_model=UserRead)
def suspend_user(
    user_id: UUID,
    suspension_data: UserSuspension,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Suspende um usuário.
    
    Args:
        user_id: ID do usuário
        suspension_data: Dados de suspensão
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        UserRead: Usuário suspenso
    """
    try:
        user_service = UserService(db)
        user = user_service.suspend_user(user_id, suspension_data, current_user_id)
        return user
    except NotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except BusinessRuleError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

@router.post("/{user_id}/unlock", response_model=UserRead)
def unlock_user(
    user_id: UUID,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Desbloqueia um usuário.
    
    Args:
        user_id: ID do usuário
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        UserRead: Usuário desbloqueado
    """
    try:
        user_service = UserService(db)
        user = user_service.unlock_user(user_id, current_user_id)
        return user
    except NotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except BusinessRuleError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

# ==================== Session Management ====================

@router.get("/{user_id}/sessions", response_model=List[UserSessionInfo])
def get_user_sessions(
    user_id: UUID,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Obtém sessões ativas de um usuário.
    
    Args:
        user_id: ID do usuário
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        List[UserSessionInfo]: Lista de sessões
    """
    try:
        user_service = UserService(db)
        sessions = user_service.get_user_sessions(user_id)
        return sessions
    except NotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

@router.delete("/{user_id}/sessions", status_code=status.HTTP_204_NO_CONTENT)
def terminate_user_sessions(
    user_id: UUID,
    session_ids: Optional[List[str]] = Query(None, description="IDs das sessões específicas"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Termina sessões de um usuário.
    
    Args:
        user_id: ID do usuário
        session_ids: IDs das sessões específicas (opcional)
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
    """
    try:
        user_service = UserService(db)
        user_service.terminate_user_sessions(user_id, session_ids, current_user_id)
    except NotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except BusinessRuleError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

# ==================== Activity Logs ====================

@router.get("/{user_id}/activity", response_model=List[UserActivityLog])
def get_user_activity(
    user_id: UUID,
    skip: int = Query(0, ge=0, description="Número de registros para pular"),
    limit: int = Query(100, ge=1, le=1000, description="Limite de registros"),
    action_type: Optional[str] = Query(None, description="Filtrar por tipo de ação"),
    start_date: Optional[str] = Query(None, description="Data de início (ISO format)"),
    end_date: Optional[str] = Query(None, description="Data de fim (ISO format)"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Obtém logs de atividade de um usuário.
    
    Args:
        user_id: ID do usuário
        skip: Número de registros para pular
        limit: Limite de registros
        action_type: Filtrar por tipo de ação
        start_date: Data de início
        end_date: Data de fim
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        List[UserActivityLog]: Lista de logs de atividade
    """
    try:
        user_service = UserService(db)
        
        # Converter datas se fornecidas
        from datetime import datetime
        start_datetime = datetime.fromisoformat(start_date) if start_date else None
        end_datetime = datetime.fromisoformat(end_date) if end_date else None
        
        activity_logs = user_service.get_user_activity(
            user_id, skip, limit, action_type, start_datetime, end_datetime
        )
        return activity_logs
    except NotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=f"Formato de data inválido: {str(e)}")
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

# ==================== Bulk Operations ====================

@router.post("/bulk", response_model=UserBulkResult)
def bulk_user_operation(
    operation: UserBulkOperation,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Executa operação em lote nos usuários.
    
    Args:
        operation: Operação a ser executada
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        UserBulkResult: Resultado da operação
    """
    try:
        user_service = UserService(db)
        result = user_service.bulk_operation(operation, current_user_id)
        return result
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(e))
    except BusinessRuleError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

# ==================== Authentication Methods ====================

@router.get("/{user_id}/auth-methods", response_model=List[AuthenticationMethod])
def get_user_auth_methods(
    user_id: UUID,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Obtém métodos de autenticação de um usuário.
    
    Args:
        user_id: ID do usuário
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        List[AuthenticationMethod]: Lista de métodos de autenticação
    """
    try:
        user_service = UserService(db)
        auth_methods = user_service.get_user_auth_methods(user_id)
        return auth_methods
    except NotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

@router.post("/{user_id}/auth-methods", response_model=AuthenticationMethod)
def add_user_auth_method(
    user_id: UUID,
    auth_method: AuthenticationMethod,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Adiciona método de autenticação para um usuário.
    
    Args:
        user_id: ID do usuário
        auth_method: Método de autenticação
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        AuthenticationMethod: Método adicionado
    """
    try:
        user_service = UserService(db)
        method = user_service.add_user_auth_method(user_id, auth_method, current_user_id)
        return method
    except NotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except ConflictError as e:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(e))
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(e))
    except BusinessRuleError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

@router.delete("/{user_id}/auth-methods/{method_id}", status_code=status.HTTP_204_NO_CONTENT)
def remove_user_auth_method(
    user_id: UUID,
    method_id: str,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Remove método de autenticação de um usuário.
    
    Args:
        user_id: ID do usuário
        method_id: ID do método de autenticação
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
    """
    try:
        user_service = UserService(db)
        user_service.remove_user_auth_method(user_id, method_id, current_user_id)
    except NotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except BusinessRuleError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

# ==================== User Validation ====================

@router.post("/{user_id}/validate", response_model=dict)
def validate_user(
    user_id: UUID,
    validation_type: str = Query(..., description="Tipo de validação (email, phone, identity)"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Valida informações de um usuário.
    
    Args:
        user_id: ID do usuário
        validation_type: Tipo de validação
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        dict: Resultado da validação
    """
    try:
        user_service = UserService(db)
        result = user_service.validate_user(user_id, validation_type, current_user_id)
        return result
    except NotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(e))
    except BusinessRuleError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

# ==================== User Export ====================

@router.get("/{user_id}/export", response_model=dict)
def export_user_data(
    user_id: UUID,
    format: str = Query("json", regex="^(json|csv|xml)$", description="Formato de exportação"),
    include_activity: bool = Query(False, description="Incluir logs de atividade"),
    include_sessions: bool = Query(False, description="Incluir informações de sessão"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Exporta dados de um usuário.
    
    Args:
        user_id: ID do usuário
        format: Formato de exportação
        include_activity: Incluir logs de atividade
        include_sessions: Incluir informações de sessão
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        dict: Dados exportados
    """
    try:
        user_service = UserService(db)
        exported_data = user_service.export_user_data(
            user_id, format, include_activity, include_sessions, current_user_id
        )
        return exported_data
    except NotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except BusinessRuleError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

