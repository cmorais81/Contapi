#!/usr/bin/env python3
"""
Script para atualizar todas as referências para Carlos Morais
"""

import os
import re
from pathlib import Path

def update_references():
    """Atualiza todas as referências nos arquivos"""
    
    # Mapeamento de substituições
    replacements = {
        'Manus AI': 'Carlos Morais',
        'Manus': 'Carlos Morais',
        'Autoria Humana': 'Carlos Morais',
        'Equipe de Desenvolvimento': 'Carlos Morais',
        'Equipe Enterprise de Governança de Dados': 'Carlos Morais',
        'Desenvolvido por:** Manus AI': 'Desenvolvido por:** Carlos Morais',
        'Desenvolvido por:** Equipe de Desenvolvimento': 'Desenvolvido por:** Carlos Morais',
        'Entrega realizada por:** Manus AI': 'Entrega realizada por:** Carlos Morais',
        'Documento gerado por:** Manus AI': 'Documento gerado por:** Carlos Morais',
        'Documento gerado por:** Equipe de Desenvolvimento': 'Documento gerado por:** Carlos Morais'
    }
    
    # Arquivos a serem processados
    files_to_process = [
        './docs/technical_documentation.md',
        './docs/integration_guide.md', 
        './docs/business_insights.md',
        './docs/user_journey_guide.md',
        './docs/windows_deployment_guide.md',
        './README_ENTERPRISE.md',
        './scripts/start_application.py'
    ]
    
    updated_files = []
    
    for file_path in files_to_process:
        if os.path.exists(file_path):
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                original_content = content
                
                # Aplicar todas as substituições
                for old_text, new_text in replacements.items():
                    content = content.replace(old_text, new_text)
                
                # Salvar apenas se houve mudanças
                if content != original_content:
                    with open(file_path, 'w', encoding='utf-8') as f:
                        f.write(content)
                    updated_files.append(file_path)
                    print(f"✅ Atualizado: {file_path}")
                else:
                    print(f"⏭️  Sem mudanças: {file_path}")
                    
            except Exception as e:
                print(f"❌ Erro ao processar {file_path}: {e}")
        else:
            print(f"⚠️  Arquivo não encontrado: {file_path}")
    
    print(f"\n🎉 Processo concluído! {len(updated_files)} arquivos atualizados.")
    return updated_files

if __name__ == "__main__":
    update_references()

