"""
User Role Service

Service para gerenciamento de atribuições entre usuários e roles.

Author: Carlos Morais <carlos.morais@f1rst.com.br>
Date: Julho 2025
"""

import uuid
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any, Tuple
from uuid import UUID

from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, func, desc, asc

from app.core.exceptions import (
    ValidationError, 
    NotFoundError, 
    ConflictError, 
    AuthorizationError,
    BusinessRuleError
)
from app.models.users.user_role import UserRole
from app.models.users.user import User
from app.models.users.role import Role
from app.schemas.users.user_role import (
    UserRoleCreate, 
    UserRoleUpdate, 
    UserRoleRead, 
    UserRoleSummary,
    UserRoleQueryParams,
    UserRoleStats,
    UserRoleAssignment,
    UserRoleBulkOperation,
    UserRoleBulkResult,
    UserRoleRecommendation,
    UserRoleConflict,
    AssignmentType,
    AssignmentStatus
)
from app.components.audit_logger import AuditLogger


class UserRoleService:
    """
    Service para gerenciamento completo de atribuições usuário-role.
    
    Funcionalidades:
    - CRUD de atribuições
    - Atribuições temporárias
    - Detecção de conflitos
    - Recomendações automáticas
    - Operações em lote
    - Analytics de atribuições
    """
    
    def __init__(self, db: Session):
        self.db = db
        self.audit_logger = AuditLogger(db)
        
        # Configurações padrão
        self.default_assignment_duration_days = 365
        self.max_roles_per_user = 20
        self.warning_days_before_expiry = 7
    
    # ==================== CRUD Operations ====================
    
    def assign_role_to_user(
        self, 
        assignment_data: UserRoleCreate, 
        assigned_by: Optional[UUID] = None
    ) -> UserRoleRead:
        """
        Atribui um role a um usuário.
        
        Args:
            assignment_data: Dados da atribuição
            assigned_by: ID do usuário que está atribuindo
            
        Returns:
            UserRoleRead: Atribuição criada
            
        Raises:
            ConflictError: Se atribuição já existe
            ValidationError: Se dados são inválidos
        """
        try:
            # Validar se usuário e role existem
            user = self._get_user(assignment_data.user_id)
            role = self._get_role(assignment_data.role_id)
            
            # Verificar se atribuição já existe
            existing = self.db.query(UserRole).filter(
                and_(
                    UserRole.user_id == assignment_data.user_id,
                    UserRole.role_id == assignment_data.role_id,
                    UserRole.status.in_([AssignmentStatus.ACTIVE, AssignmentStatus.PENDING])
                )
            ).first()
            
            if existing:
                raise ConflictError(f"Usuário {user.username} já possui o role {role.name}")
            
            # Verificar limite de roles por usuário
            current_roles_count = self._count_user_active_roles(assignment_data.user_id)
            if current_roles_count >= self.max_roles_per_user:
                raise BusinessRuleError(f"Usuário já possui o máximo de {self.max_roles_per_user} roles")
            
            # Verificar conflitos de roles
            conflicts = self._check_role_conflicts(assignment_data.user_id, assignment_data.role_id)
            if conflicts and not assignment_data.force_assignment:
                raise BusinessRuleError(f"Conflitos detectados: {[c.description for c in conflicts]}")
            
            # Calcular data de expiração
            expires_at = None
            if assignment_data.assignment_type == AssignmentType.TEMPORARY:
                if assignment_data.expires_at:
                    expires_at = assignment_data.expires_at
                else:
                    expires_at = datetime.utcnow() + timedelta(days=assignment_data.duration_days or 30)
            elif assignment_data.assignment_type == AssignmentType.PERMANENT:
                expires_at = datetime.utcnow() + timedelta(days=self.default_assignment_duration_days)
            
            # Criar atribuição
            user_role = UserRole(
                id=uuid.uuid4(),
                user_id=assignment_data.user_id,
                role_id=assignment_data.role_id,
                assignment_type=assignment_data.assignment_type,
                status=assignment_data.status,
                assigned_by=assigned_by,
                assigned_at=datetime.utcnow(),
                expires_at=expires_at,
                conditions=assignment_data.conditions.dict() if assignment_data.conditions else None,
                metadata=assignment_data.metadata or {},
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow()
            )
            
            self.db.add(user_role)
            self.db.commit()
            self.db.refresh(user_role)
            
            # Log de auditoria
            self.audit_logger.log_user_action(
                user_id=assigned_by,
                action="role_assigned",
                target_user_id=assignment_data.user_id,
                details={
                    "role_id": str(assignment_data.role_id),
                    "role_name": role.name,
                    "assignment_type": assignment_data.assignment_type,
                    "expires_at": expires_at.isoformat() if expires_at else None
                }
            )
            
            # Enviar notificação se solicitado
            if assignment_data.send_notification:
                self._send_assignment_notification(user, role, user_role)
            
            return self._to_user_role_read(user_role)
            
        except Exception as e:
            self.db.rollback()
            if isinstance(e, (ConflictError, ValidationError, BusinessRuleError)):
                raise
            raise BusinessRuleError(f"Erro ao atribuir role: {str(e)}")
    
    def get_user_role(self, user_role_id: UUID) -> Optional[UserRoleRead]:
        """
        Obtém uma atribuição por ID.
        
        Args:
            user_role_id: ID da atribuição
            
        Returns:
            UserRoleRead: Atribuição encontrada ou None
        """
        user_role = self.db.query(UserRole).filter(UserRole.id == user_role_id).first()
        return self._to_user_role_read(user_role) if user_role else None
    
    def update_user_role(
        self, 
        user_role_id: UUID, 
        update_data: UserRoleUpdate, 
        updated_by: Optional[UUID] = None
    ) -> UserRoleRead:
        """
        Atualiza uma atribuição existente.
        
        Args:
            user_role_id: ID da atribuição
            update_data: Dados para atualização
            updated_by: ID do usuário que está atualizando
            
        Returns:
            UserRoleRead: Atribuição atualizada
            
        Raises:
            NotFoundError: Se atribuição não existe
        """
        user_role = self.db.query(UserRole).filter(UserRole.id == user_role_id).first()
        if not user_role:
            raise NotFoundError(f"Atribuição {user_role_id} não encontrada")
        
        try:
            # Armazenar valores antigos para auditoria
            old_values = {
                "status": user_role.status,
                "expires_at": user_role.expires_at,
                "assignment_type": user_role.assignment_type
            }
            
            # Atualizar campos
            update_fields = update_data.dict(exclude_unset=True)
            for field, value in update_fields.items():
                if hasattr(user_role, field):
                    if field == "conditions":
                        setattr(user_role, field, value.dict() if hasattr(value, 'dict') else value)
                    elif field == "metadata":
                        current_metadata = user_role.metadata or {}
                        if isinstance(value, dict):
                            current_metadata.update(value)
                            setattr(user_role, field, current_metadata)
                        else:
                            setattr(user_role, field, value)
                    else:
                        setattr(user_role, field, value)
            
            user_role.updated_at = datetime.utcnow()
            user_role.updated_by = updated_by
            
            self.db.commit()
            self.db.refresh(user_role)
            
            # Log de auditoria
            new_values = {
                "status": user_role.status,
                "expires_at": user_role.expires_at,
                "assignment_type": user_role.assignment_type
            }
            
            self.audit_logger.log_user_action(
                user_id=updated_by,
                action="user_role_updated",
                target_user_id=user_role.user_id,
                details={
                    "user_role_id": str(user_role_id),
                    "old_values": old_values,
                    "new_values": new_values,
                    "changed_fields": list(update_fields.keys())
                }
            )
            
            return self._to_user_role_read(user_role)
            
        except Exception as e:
            self.db.rollback()
            if isinstance(e, NotFoundError):
                raise
            raise BusinessRuleError(f"Erro ao atualizar atribuição: {str(e)}")
    
    def revoke_user_role(
        self, 
        user_role_id: UUID, 
        revoked_by: Optional[UUID] = None,
        reason: Optional[str] = None
    ) -> bool:
        """
        Revoga uma atribuição de role.
        
        Args:
            user_role_id: ID da atribuição
            revoked_by: ID do usuário que está revogando
            reason: Motivo da revogação
            
        Returns:
            bool: True se revogado com sucesso
            
        Raises:
            NotFoundError: Se atribuição não existe
        """
        user_role = self.db.query(UserRole).filter(UserRole.id == user_role_id).first()
        if not user_role:
            raise NotFoundError(f"Atribuição {user_role_id} não encontrada")
        
        try:
            # Atualizar status
            user_role.status = AssignmentStatus.REVOKED
            user_role.revoked_at = datetime.utcnow()
            user_role.revoked_by = revoked_by
            user_role.updated_at = datetime.utcnow()
            
            # Adicionar motivo aos metadados
            user_role.metadata = user_role.metadata or {}
            user_role.metadata["revocation_reason"] = reason
            
            self.db.commit()
            
            # Log de auditoria
            self.audit_logger.log_user_action(
                user_id=revoked_by,
                action="role_revoked",
                target_user_id=user_role.user_id,
                details={
                    "user_role_id": str(user_role_id),
                    "role_id": str(user_role.role_id),
                    "reason": reason
                }
            )
            
            return True
            
        except Exception as e:
            self.db.rollback()
            raise BusinessRuleError(f"Erro ao revogar atribuição: {str(e)}")
    
    # ==================== User Role Management ====================
    
    def get_user_roles(
        self, 
        user_id: UUID,
        include_expired: bool = False,
        include_revoked: bool = False
    ) -> List[UserRoleRead]:
        """
        Obtém todos os roles de um usuário.
        
        Args:
            user_id: ID do usuário
            include_expired: Incluir roles expirados
            include_revoked: Incluir roles revogados
            
        Returns:
            List[UserRoleRead]: Lista de atribuições
        """
        query = self.db.query(UserRole).filter(UserRole.user_id == user_id)
        
        if not include_expired:
            query = query.filter(
                or_(
                    UserRole.expires_at.is_(None),
                    UserRole.expires_at > datetime.utcnow()
                )
            )
        
        if not include_revoked:
            query = query.filter(UserRole.status != AssignmentStatus.REVOKED)
        
        user_roles = query.order_by(UserRole.assigned_at.desc()).all()
        return [self._to_user_role_read(ur) for ur in user_roles]
    
    def get_role_users(
        self, 
        role_id: UUID,
        include_expired: bool = False,
        include_revoked: bool = False
    ) -> List[UserRoleRead]:
        """
        Obtém todos os usuários de um role.
        
        Args:
            role_id: ID do role
            include_expired: Incluir atribuições expiradas
            include_revoked: Incluir atribuições revogadas
            
        Returns:
            List[UserRoleRead]: Lista de atribuições
        """
        query = self.db.query(UserRole).filter(UserRole.role_id == role_id)
        
        if not include_expired:
            query = query.filter(
                or_(
                    UserRole.expires_at.is_(None),
                    UserRole.expires_at > datetime.utcnow()
                )
            )
        
        if not include_revoked:
            query = query.filter(UserRole.status != AssignmentStatus.REVOKED)
        
        user_roles = query.order_by(UserRole.assigned_at.desc()).all()
        return [self._to_user_role_read(ur) for ur in user_roles]
    
    def get_expiring_assignments(
        self, 
        days_ahead: int = 7
    ) -> List[UserRoleRead]:
        """
        Obtém atribuições que expiram em breve.
        
        Args:
            days_ahead: Número de dias para verificar
            
        Returns:
            List[UserRoleRead]: Lista de atribuições expirando
        """
        cutoff_date = datetime.utcnow() + timedelta(days=days_ahead)
        
        user_roles = self.db.query(UserRole).filter(
            and_(
                UserRole.expires_at <= cutoff_date,
                UserRole.expires_at > datetime.utcnow(),
                UserRole.status == AssignmentStatus.ACTIVE
            )
        ).order_by(UserRole.expires_at).all()
        
        return [self._to_user_role_read(ur) for ur in user_roles]
    
    def renew_assignment(
        self, 
        user_role_id: UUID, 
        new_expiry_date: datetime,
        renewed_by: Optional[UUID] = None
    ) -> UserRoleRead:
        """
        Renova uma atribuição de role.
        
        Args:
            user_role_id: ID da atribuição
            new_expiry_date: Nova data de expiração
            renewed_by: ID do usuário que está renovando
            
        Returns:
            UserRoleRead: Atribuição renovada
        """
        user_role = self.db.query(UserRole).filter(UserRole.id == user_role_id).first()
        if not user_role:
            raise NotFoundError(f"Atribuição {user_role_id} não encontrada")
        
        try:
            old_expiry = user_role.expires_at
            user_role.expires_at = new_expiry_date
            user_role.updated_at = datetime.utcnow()
            user_role.updated_by = renewed_by
            
            # Adicionar informação de renovação aos metadados
            user_role.metadata = user_role.metadata or {}
            user_role.metadata["last_renewed_at"] = datetime.utcnow().isoformat()
            user_role.metadata["last_renewed_by"] = str(renewed_by) if renewed_by else None
            user_role.metadata["previous_expiry"] = old_expiry.isoformat() if old_expiry else None
            
            self.db.commit()
            self.db.refresh(user_role)
            
            # Log de auditoria
            self.audit_logger.log_user_action(
                user_id=renewed_by,
                action="role_assignment_renewed",
                target_user_id=user_role.user_id,
                details={
                    "user_role_id": str(user_role_id),
                    "old_expiry": old_expiry.isoformat() if old_expiry else None,
                    "new_expiry": new_expiry_date.isoformat()
                }
            )
            
            return self._to_user_role_read(user_role)
            
        except Exception as e:
            self.db.rollback()
            raise BusinessRuleError(f"Erro ao renovar atribuição: {str(e)}")
    
    # ==================== Conflict Detection ====================
    
    def check_role_conflicts(
        self, 
        user_id: UUID, 
        role_id: UUID
    ) -> List[UserRoleConflict]:
        """
        Verifica conflitos ao atribuir um role a um usuário.
        
        Args:
            user_id: ID do usuário
            role_id: ID do role
            
        Returns:
            List[UserRoleConflict]: Lista de conflitos encontrados
        """
        return self._check_role_conflicts(user_id, role_id)
    
    def get_user_role_conflicts(self, user_id: UUID) -> List[UserRoleConflict]:
        """
        Obtém todos os conflitos de roles de um usuário.
        
        Args:
            user_id: ID do usuário
            
        Returns:
            List[UserRoleConflict]: Lista de conflitos
        """
        conflicts = []
        user_roles = self.get_user_roles(user_id)
        
        # Verificar conflitos entre roles existentes
        for i, role1 in enumerate(user_roles):
            for role2 in user_roles[i+1:]:
                role_conflicts = self._check_specific_role_conflicts(role1.role_id, role2.role_id)
                conflicts.extend(role_conflicts)
        
        return conflicts
    
    # ==================== Recommendations ====================
    
    def get_role_recommendations(
        self, 
        user_id: UUID,
        limit: int = 10
    ) -> List[UserRoleRecommendation]:
        """
        Obtém recomendações de roles para um usuário.
        
        Args:
            user_id: ID do usuário
            limit: Limite de recomendações
            
        Returns:
            List[UserRoleRecommendation]: Lista de recomendações
        """
        user = self._get_user(user_id)
        current_roles = self.get_user_roles(user_id)
        current_role_ids = {ur.role_id for ur in current_roles}
        
        recommendations = []
        
        # Recomendações baseadas no departamento
        dept_recommendations = self._get_department_based_recommendations(user, current_role_ids)
        recommendations.extend(dept_recommendations)
        
        # Recomendações baseadas em usuários similares
        similar_user_recommendations = self._get_similar_user_recommendations(user, current_role_ids)
        recommendations.extend(similar_user_recommendations)
        
        # Recomendações baseadas no tipo de usuário
        user_type_recommendations = self._get_user_type_recommendations(user, current_role_ids)
        recommendations.extend(user_type_recommendations)
        
        # Ordenar por score e limitar
        recommendations.sort(key=lambda x: x.confidence_score, reverse=True)
        return recommendations[:limit]
    
    # ==================== Search and Query ====================
    
    def search_user_roles(
        self, 
        params: UserRoleQueryParams,
        skip: int = 0,
        limit: int = 100
    ) -> Tuple[List[UserRoleSummary], int]:
        """
        Busca atribuições com filtros avançados.
        
        Args:
            params: Parâmetros de busca
            skip: Número de registros para pular
            limit: Limite de registros
            
        Returns:
            Tuple[List[UserRoleSummary], int]: Lista de atribuições e total
        """
        query = self.db.query(UserRole)
        
        # Aplicar filtros
        if params.user_id:
            query = query.filter(UserRole.user_id == params.user_id)
        
        if params.role_id:
            query = query.filter(UserRole.role_id == params.role_id)
        
        if params.assignment_type:
            query = query.filter(UserRole.assignment_type == params.assignment_type)
        
        if params.status:
            query = query.filter(UserRole.status == params.status)
        
        if params.assigned_by:
            query = query.filter(UserRole.assigned_by == params.assigned_by)
        
        if params.assigned_after:
            query = query.filter(UserRole.assigned_at >= params.assigned_after)
        
        if params.assigned_before:
            query = query.filter(UserRole.assigned_at <= params.assigned_before)
        
        if params.expires_after:
            query = query.filter(UserRole.expires_at >= params.expires_after)
        
        if params.expires_before:
            query = query.filter(UserRole.expires_at <= params.expires_before)
        
        # Filtros especiais
        if params.is_expired is not None:
            if params.is_expired:
                query = query.filter(UserRole.expires_at <= datetime.utcnow())
            else:
                query = query.filter(
                    or_(
                        UserRole.expires_at.is_(None),
                        UserRole.expires_at > datetime.utcnow()
                    )
                )
        
        if params.is_expiring_soon is not None and params.is_expiring_soon:
            cutoff_date = datetime.utcnow() + timedelta(days=self.warning_days_before_expiry)
            query = query.filter(
                and_(
                    UserRole.expires_at <= cutoff_date,
                    UserRole.expires_at > datetime.utcnow()
                )
            )
        
        # Contar total
        total = query.count()
        
        # Aplicar ordenação
        if params.sort_by == "assigned_at":
            order_field = UserRole.assigned_at
        elif params.sort_by == "expires_at":
            order_field = UserRole.expires_at
        elif params.sort_by == "status":
            order_field = UserRole.status
        else:
            order_field = UserRole.created_at
        
        if params.sort_order == "desc":
            query = query.order_by(desc(order_field))
        else:
            query = query.order_by(asc(order_field))
        
        # Aplicar paginação
        user_roles = query.offset(skip).limit(limit).all()
        
        # Converter para UserRoleSummary
        summaries = [self._to_user_role_summary(ur) for ur in user_roles]
        
        return summaries, total
    
    def get_user_role_stats(self) -> UserRoleStats:
        """
        Obtém estatísticas de atribuições.
        
        Returns:
            UserRoleStats: Estatísticas das atribuições
        """
        # Contadores básicos
        total_assignments = self.db.query(UserRole).count()
        active_assignments = self.db.query(UserRole).filter(UserRole.status == AssignmentStatus.ACTIVE).count()
        expired_assignments = self.db.query(UserRole).filter(
            and_(
                UserRole.expires_at <= datetime.utcnow(),
                UserRole.status == AssignmentStatus.ACTIVE
            )
        ).count()
        revoked_assignments = self.db.query(UserRole).filter(UserRole.status == AssignmentStatus.REVOKED).count()
        
        # Por tipo de atribuição
        assignments_by_type = {}
        for assignment_type in AssignmentType:
            count = self.db.query(UserRole).filter(UserRole.assignment_type == assignment_type).count()
            assignments_by_type[assignment_type.value] = count
        
        # Expirando em breve
        expiring_soon = len(self.get_expiring_assignments(self.warning_days_before_expiry))
        
        # Usuários com mais roles
        users_with_most_roles = self.db.query(
            UserRole.user_id,
            func.count(UserRole.id).label("role_count")
        ).filter(
            UserRole.status == AssignmentStatus.ACTIVE
        ).group_by(UserRole.user_id).order_by(desc("role_count")).limit(10).all()
        
        # Roles mais atribuídos
        most_assigned_roles = self.db.query(
            UserRole.role_id,
            func.count(UserRole.id).label("assignment_count")
        ).filter(
            UserRole.status == AssignmentStatus.ACTIVE
        ).group_by(UserRole.role_id).order_by(desc("assignment_count")).limit(10).all()
        
        # Atribuições recentes
        recent_assignments = self.db.query(UserRole).filter(
            UserRole.assigned_at >= datetime.utcnow() - timedelta(days=7)
        ).order_by(desc(UserRole.assigned_at)).limit(10).all()
        
        return UserRoleStats(
            total_assignments=total_assignments,
            active_assignments=active_assignments,
            expired_assignments=expired_assignments,
            revoked_assignments=revoked_assignments,
            assignments_by_type=assignments_by_type,
            expiring_soon=expiring_soon,
            average_roles_per_user=self._calculate_average_roles_per_user(),
            users_with_most_roles=[{"user_id": str(u), "count": c} for u, c in users_with_most_roles],
            most_assigned_roles=[{"role_id": str(r), "count": c} for r, c in most_assigned_roles],
            recent_assignments=[self._to_user_role_summary(ur) for ur in recent_assignments]
        )
    
    # ==================== Bulk Operations ====================
    
    def bulk_operation(
        self, 
        operation: UserRoleBulkOperation,
        performed_by: Optional[UUID] = None
    ) -> UserRoleBulkResult:
        """
        Executa operação em lote nas atribuições.
        
        Args:
            operation: Operação a ser executada
            performed_by: ID do usuário que está executando
            
        Returns:
            UserRoleBulkResult: Resultado da operação
        """
        results = []
        errors = []
        successful = 0
        failed = 0
        
        if operation.operation == "assign_role_to_users":
            # Atribuir role a múltiplos usuários
            for user_id in operation.user_ids:
                try:
                    assignment_data = UserRoleCreate(
                        user_id=user_id,
                        role_id=operation.role_id,
                        assignment_type=operation.assignment_type or AssignmentType.PERMANENT,
                        status=AssignmentStatus.ACTIVE,
                        expires_at=operation.expires_at,
                        send_notification=operation.send_notification
                    )
                    
                    result = self.assign_role_to_user(assignment_data, performed_by)
                    results.append({"user_id": str(user_id), "status": "success", "assignment_id": str(result.id)})
                    successful += 1
                    
                except Exception as e:
                    error_detail = {
                        "user_id": str(user_id),
                        "error": str(e),
                        "status": "failed"
                    }
                    errors.append(error_detail)
                    results.append(error_detail)
                    failed += 1
        
        elif operation.operation == "assign_roles_to_user":
            # Atribuir múltiplos roles a um usuário
            for role_id in operation.role_ids:
                try:
                    assignment_data = UserRoleCreate(
                        user_id=operation.user_id,
                        role_id=role_id,
                        assignment_type=operation.assignment_type or AssignmentType.PERMANENT,
                        status=AssignmentStatus.ACTIVE,
                        expires_at=operation.expires_at,
                        send_notification=operation.send_notification
                    )
                    
                    result = self.assign_role_to_user(assignment_data, performed_by)
                    results.append({"role_id": str(role_id), "status": "success", "assignment_id": str(result.id)})
                    successful += 1
                    
                except Exception as e:
                    error_detail = {
                        "role_id": str(role_id),
                        "error": str(e),
                        "status": "failed"
                    }
                    errors.append(error_detail)
                    results.append(error_detail)
                    failed += 1
        
        elif operation.operation == "revoke_assignments":
            # Revogar múltiplas atribuições
            for assignment_id in operation.assignment_ids:
                try:
                    self.revoke_user_role(assignment_id, performed_by, operation.reason)
                    results.append({"assignment_id": str(assignment_id), "status": "success"})
                    successful += 1
                    
                except Exception as e:
                    error_detail = {
                        "assignment_id": str(assignment_id),
                        "error": str(e),
                        "status": "failed"
                    }
                    errors.append(error_detail)
                    results.append(error_detail)
                    failed += 1
        
        elif operation.operation == "renew_assignments":
            # Renovar múltiplas atribuições
            for assignment_id in operation.assignment_ids:
                try:
                    new_expiry = operation.expires_at or (datetime.utcnow() + timedelta(days=365))
                    self.renew_assignment(assignment_id, new_expiry, performed_by)
                    results.append({"assignment_id": str(assignment_id), "status": "success"})
                    successful += 1
                    
                except Exception as e:
                    error_detail = {
                        "assignment_id": str(assignment_id),
                        "error": str(e),
                        "status": "failed"
                    }
                    errors.append(error_detail)
                    results.append(error_detail)
                    failed += 1
        
        # Log de auditoria
        self.audit_logger.log_user_action(
            user_id=performed_by,
            action=f"bulk_{operation.operation}",
            details={
                "total_items": len(operation.user_ids or operation.role_ids or operation.assignment_ids or []),
                "successful": successful,
                "failed": failed,
                "reason": operation.reason
            }
        )
        
        return UserRoleBulkResult(
            total_requested=len(operation.user_ids or operation.role_ids or operation.assignment_ids or []),
            successful=successful,
            failed=failed,
            errors=errors,
            results=results
        )
    
    # ==================== Helper Methods ====================
    
    def _get_user(self, user_id: UUID) -> User:
        """Obtém usuário por ID."""
        user = self.db.query(User).filter(User.id == user_id).first()
        if not user:
            raise NotFoundError(f"Usuário {user_id} não encontrado")
        return user
    
    def _get_role(self, role_id: UUID) -> Role:
        """Obtém role por ID."""
        role = self.db.query(Role).filter(Role.id == role_id).first()
        if not role:
            raise NotFoundError(f"Role {role_id} não encontrado")
        return role
    
    def _count_user_active_roles(self, user_id: UUID) -> int:
        """Conta roles ativos de um usuário."""
        return self.db.query(UserRole).filter(
            and_(
                UserRole.user_id == user_id,
                UserRole.status == AssignmentStatus.ACTIVE,
                or_(
                    UserRole.expires_at.is_(None),
                    UserRole.expires_at > datetime.utcnow()
                )
            )
        ).count()
    
    def _check_role_conflicts(self, user_id: UUID, role_id: UUID) -> List[UserRoleConflict]:
        """Verifica conflitos de roles."""
        conflicts = []
        
        # Obter roles atuais do usuário
        current_roles = self.get_user_roles(user_id)
        new_role = self._get_role(role_id)
        
        for current_assignment in current_roles:
            current_role = self._get_role(current_assignment.role_id)
            
            # Verificar conflitos de escopo
            if self._has_scope_conflict(current_role, new_role):
                conflicts.append(UserRoleConflict(
                    conflict_type="scope_conflict",
                    description=f"Conflito de escopo entre {current_role.name} e {new_role.name}",
                    conflicting_role_id=current_role.id,
                    severity="medium"
                ))
            
            # Verificar conflitos de permissões
            if self._has_permission_conflict(current_role, new_role):
                conflicts.append(UserRoleConflict(
                    conflict_type="permission_conflict",
                    description=f"Conflito de permissões entre {current_role.name} e {new_role.name}",
                    conflicting_role_id=current_role.id,
                    severity="high"
                ))
            
            # Verificar conflitos de segregação de funções
            if self._has_segregation_conflict(current_role, new_role):
                conflicts.append(UserRoleConflict(
                    conflict_type="segregation_conflict",
                    description=f"Violação de segregação de funções entre {current_role.name} e {new_role.name}",
                    conflicting_role_id=current_role.id,
                    severity="critical"
                ))
        
        return conflicts
    
    def _check_specific_role_conflicts(self, role1_id: UUID, role2_id: UUID) -> List[UserRoleConflict]:
        """Verifica conflitos entre dois roles específicos."""
        role1 = self._get_role(role1_id)
        role2 = self._get_role(role2_id)
        
        conflicts = []
        
        if self._has_scope_conflict(role1, role2):
            conflicts.append(UserRoleConflict(
                conflict_type="scope_conflict",
                description=f"Conflito de escopo entre {role1.name} e {role2.name}",
                conflicting_role_id=role2.id,
                severity="medium"
            ))
        
        return conflicts
    
    def _has_scope_conflict(self, role1: Role, role2: Role) -> bool:
        """Verifica se há conflito de escopo entre roles."""
        # Implementar lógica de conflito de escopo
        return False
    
    def _has_permission_conflict(self, role1: Role, role2: Role) -> bool:
        """Verifica se há conflito de permissões entre roles."""
        # Implementar lógica de conflito de permissões
        return False
    
    def _has_segregation_conflict(self, role1: Role, role2: Role) -> bool:
        """Verifica se há violação de segregação de funções."""
        # Implementar lógica de segregação de funções
        return False
    
    def _get_department_based_recommendations(self, user: User, current_role_ids: set) -> List[UserRoleRecommendation]:
        """Obtém recomendações baseadas no departamento."""
        recommendations = []
        
        if user.profile and user.profile.get("department"):
            department = user.profile["department"]
            
            # Buscar roles comuns no departamento
            common_roles = self.db.query(UserRole.role_id, func.count(UserRole.id).label("count")).join(
                User, UserRole.user_id == User.id
            ).filter(
                and_(
                    User.profile["department"].astext == department,
                    UserRole.status == AssignmentStatus.ACTIVE,
                    ~UserRole.role_id.in_(current_role_ids)
                )
            ).group_by(UserRole.role_id).order_by(desc("count")).limit(5).all()
            
            for role_id, count in common_roles:
                role = self._get_role(role_id)
                recommendations.append(UserRoleRecommendation(
                    role_id=role_id,
                    role_name=role.name,
                    recommendation_type="department_based",
                    confidence_score=min(0.8, count / 10),  # Score baseado na frequência
                    reason=f"Role comum no departamento {department} ({count} usuários)"
                ))
        
        return recommendations
    
    def _get_similar_user_recommendations(self, user: User, current_role_ids: set) -> List[UserRoleRecommendation]:
        """Obtém recomendações baseadas em usuários similares."""
        recommendations = []
        
        # Buscar usuários similares (mesmo tipo, departamento, etc.)
        similar_users = self.db.query(User).filter(
            and_(
                User.id != user.id,
                User.user_type == user.user_type,
                User.is_active == True
            )
        ).limit(20).all()
        
        # Analisar roles comuns entre usuários similares
        role_frequency = {}
        for similar_user in similar_users:
            user_roles = self.get_user_roles(similar_user.id)
            for ur in user_roles:
                if ur.role_id not in current_role_ids:
                    role_frequency[ur.role_id] = role_frequency.get(ur.role_id, 0) + 1
        
        # Criar recomendações
        for role_id, frequency in sorted(role_frequency.items(), key=lambda x: x[1], reverse=True)[:5]:
            role = self._get_role(role_id)
            recommendations.append(UserRoleRecommendation(
                role_id=role_id,
                role_name=role.name,
                recommendation_type="similar_users",
                confidence_score=min(0.7, frequency / len(similar_users)),
                reason=f"Role comum entre usuários similares ({frequency}/{len(similar_users)})"
            ))
        
        return recommendations
    
    def _get_user_type_recommendations(self, user: User, current_role_ids: set) -> List[UserRoleRecommendation]:
        """Obtém recomendações baseadas no tipo de usuário."""
        recommendations = []
        
        # Buscar roles padrão para o tipo de usuário
        type_roles = self.db.query(UserRole.role_id, func.count(UserRole.id).label("count")).join(
            User, UserRole.user_id == User.id
        ).filter(
            and_(
                User.user_type == user.user_type,
                UserRole.status == AssignmentStatus.ACTIVE,
                ~UserRole.role_id.in_(current_role_ids)
            )
        ).group_by(UserRole.role_id).order_by(desc("count")).limit(3).all()
        
        for role_id, count in type_roles:
            role = self._get_role(role_id)
            recommendations.append(UserRoleRecommendation(
                role_id=role_id,
                role_name=role.name,
                recommendation_type="user_type_based",
                confidence_score=min(0.6, count / 20),
                reason=f"Role padrão para tipo de usuário {user.user_type}"
            ))
        
        return recommendations
    
    def _calculate_average_roles_per_user(self) -> float:
        """Calcula média de roles por usuário."""
        result = self.db.query(
            func.avg(func.count(UserRole.id))
        ).filter(
            UserRole.status == AssignmentStatus.ACTIVE
        ).group_by(UserRole.user_id).scalar()
        
        return float(result) if result else 0.0
    
    def _send_assignment_notification(self, user: User, role: Role, user_role: UserRole) -> None:
        """Envia notificação de atribuição."""
        # Implementar envio de notificação
        pass
    
    def _to_user_role_read(self, user_role: UserRole) -> UserRoleRead:
        """Converte UserRole model para UserRoleRead schema."""
        user = self._get_user(user_role.user_id)
        role = self._get_role(user_role.role_id)
        
        return UserRoleRead(
            id=user_role.id,
            user_id=user_role.user_id,
            role_id=user_role.role_id,
            user_username=user.username,
            role_name=role.name,
            assignment_type=user_role.assignment_type,
            status=user_role.status,
            assigned_by=user_role.assigned_by,
            assigned_at=user_role.assigned_at,
            expires_at=user_role.expires_at,
            revoked_at=user_role.revoked_at,
            revoked_by=user_role.revoked_by,
            updated_by=user_role.updated_by,
            conditions=user_role.conditions,
            metadata=user_role.metadata,
            created_at=user_role.created_at,
            updated_at=user_role.updated_at
        )
    
    def _to_user_role_summary(self, user_role: UserRole) -> UserRoleSummary:
        """Converte UserRole model para UserRoleSummary schema."""
        user = self._get_user(user_role.user_id)
        role = self._get_role(user_role.role_id)
        
        is_expired = user_role.expires_at and user_role.expires_at <= datetime.utcnow()
        is_expiring_soon = (user_role.expires_at and 
                           user_role.expires_at <= datetime.utcnow() + timedelta(days=self.warning_days_before_expiry))
        
        return UserRoleSummary(
            id=user_role.id,
            user_id=user_role.user_id,
            role_id=user_role.role_id,
            user_username=user.username,
            user_display_name=user.profile.get("display_name", f"{user.profile.get('first_name', '')} {user.profile.get('last_name', '')}".strip()) if user.profile else user.username,
            role_name=role.name,
            role_display_name=role.display_name,
            assignment_type=user_role.assignment_type,
            status=user_role.status,
            assigned_at=user_role.assigned_at,
            expires_at=user_role.expires_at,
            is_expired=is_expired,
            is_expiring_soon=is_expiring_soon,
            created_at=user_role.created_at
        )

