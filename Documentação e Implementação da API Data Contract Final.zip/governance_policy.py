"""
Governance Policy Schemas

Schemas Pydantic para políticas de governança de dados.

Author: Carlos Morais <carlos.morais@f1rst.com.br>
Date: Julho 2025
"""

from datetime import datetime
from typing import List, Optional, Dict, Any
from uuid import UUID
from enum import Enum

from pydantic import BaseModel, Field, validator, root_validator

# ==================== Enums ====================

class PolicyType(str, Enum):
    """Tipos de política de governança."""
    DATA_QUALITY = "data_quality"
    DATA_PRIVACY = "data_privacy"
    DATA_RETENTION = "data_retention"
    DATA_ACCESS = "data_access"
    DATA_CLASSIFICATION = "data_classification"
    DATA_LINEAGE = "data_lineage"
    DATA_SECURITY = "data_security"
    COMPLIANCE = "compliance"
    METADATA_MANAGEMENT = "metadata_management"
    LIFECYCLE_MANAGEMENT = "lifecycle_management"

class PolicyStatus(str, Enum):
    """Status da política."""
    DRAFT = "draft"
    UNDER_REVIEW = "under_review"
    APPROVED = "approved"
    ACTIVE = "active"
    SUSPENDED = "suspended"
    DEPRECATED = "deprecated"
    ARCHIVED = "archived"

class PolicyScope(str, Enum):
    """Escopo da política."""
    GLOBAL = "global"
    ORGANIZATION = "organization"
    DEPARTMENT = "department"
    PROJECT = "project"
    SYSTEM = "system"
    DATASET = "dataset"
    TABLE = "table"
    COLUMN = "column"

class EnforcementLevel(str, Enum):
    """Nível de enforcement da política."""
    ADVISORY = "advisory"
    WARNING = "warning"
    BLOCKING = "blocking"
    AUTOMATIC = "automatic"

class ComplianceFramework(str, Enum):
    """Frameworks de compliance."""
    GDPR = "gdpr"
    LGPD = "lgpd"
    CCPA = "ccpa"
    HIPAA = "hipaa"
    SOX = "sox"
    PCI_DSS = "pci_dss"
    ISO_27001 = "iso_27001"
    NIST = "nist"
    CUSTOM = "custom"

# ==================== Base Schemas ====================

class GovernancePolicyBase(BaseModel):
    """Schema base para política de governança."""
    name: str = Field(..., min_length=1, max_length=255, description="Nome da política")
    description: Optional[str] = Field(None, max_length=2000, description="Descrição da política")
    policy_type: PolicyType = Field(..., description="Tipo da política")
    scope: PolicyScope = Field(..., description="Escopo da política")
    enforcement_level: EnforcementLevel = Field(..., description="Nível de enforcement")
    
    # Configurações da política
    policy_rules: Dict[str, Any] = Field(default_factory=dict, description="Regras da política")
    policy_parameters: Dict[str, Any] = Field(default_factory=dict, description="Parâmetros da política")
    
    # Compliance
    compliance_frameworks: List[ComplianceFramework] = Field(default_factory=list, description="Frameworks de compliance")
    regulatory_requirements: List[str] = Field(default_factory=list, description="Requisitos regulatórios")
    
    # Aplicabilidade
    applicable_systems: List[str] = Field(default_factory=list, description="Sistemas aplicáveis")
    applicable_datasets: List[str] = Field(default_factory=list, description="Datasets aplicáveis")
    applicable_tables: List[str] = Field(default_factory=list, description="Tabelas aplicáveis")
    applicable_columns: List[str] = Field(default_factory=list, description="Colunas aplicáveis")
    
    # Configurações de execução
    is_active: bool = Field(True, description="Política ativa")
    auto_enforcement: bool = Field(False, description="Enforcement automático")
    notification_enabled: bool = Field(True, description="Notificações habilitadas")
    
    # Datas importantes
    effective_date: Optional[datetime] = Field(None, description="Data de vigência")
    expiry_date: Optional[datetime] = Field(None, description="Data de expiração")
    review_date: Optional[datetime] = Field(None, description="Data de revisão")
    
    # Metadados
    tags: List[str] = Field(default_factory=list, description="Tags da política")
    priority: int = Field(5, ge=1, le=10, description="Prioridade da política (1-10)")
    version: str = Field("1.0", description="Versão da política")

class GovernancePolicyCreate(GovernancePolicyBase):
    """Schema para criação de política de governança."""
    
    @validator('policy_rules')
    def validate_policy_rules(cls, v, values):
        """Valida regras da política baseado no tipo."""
        policy_type = values.get('policy_type')
        if not v and policy_type:
            # Regras padrão baseadas no tipo
            if policy_type == PolicyType.DATA_QUALITY:
                return {
                    "completeness_threshold": 0.95,
                    "accuracy_threshold": 0.98,
                    "consistency_checks": True,
                    "validity_rules": []
                }
            elif policy_type == PolicyType.DATA_PRIVACY:
                return {
                    "pii_detection": True,
                    "anonymization_required": False,
                    "consent_required": True,
                    "retention_period_days": 365
                }
            elif policy_type == PolicyType.DATA_RETENTION:
                return {
                    "retention_period_days": 2555,  # 7 anos
                    "archive_after_days": 1095,     # 3 anos
                    "purge_after_days": 2555,       # 7 anos
                    "backup_required": True
                }
        return v
    
    @root_validator
    def validate_dates(cls, values):
        """Valida consistência das datas."""
        effective_date = values.get('effective_date')
        expiry_date = values.get('expiry_date')
        review_date = values.get('review_date')
        
        if effective_date and expiry_date:
            if effective_date >= expiry_date:
                raise ValueError("Data de vigência deve ser anterior à data de expiração")
        
        if effective_date and review_date:
            if review_date <= effective_date:
                raise ValueError("Data de revisão deve ser posterior à data de vigência")
        
        return values

class GovernancePolicyUpdate(BaseModel):
    """Schema para atualização de política de governança."""
    name: Optional[str] = Field(None, min_length=1, max_length=255)
    description: Optional[str] = Field(None, max_length=2000)
    policy_type: Optional[PolicyType] = None
    scope: Optional[PolicyScope] = None
    enforcement_level: Optional[EnforcementLevel] = None
    
    policy_rules: Optional[Dict[str, Any]] = None
    policy_parameters: Optional[Dict[str, Any]] = None
    
    compliance_frameworks: Optional[List[ComplianceFramework]] = None
    regulatory_requirements: Optional[List[str]] = None
    
    applicable_systems: Optional[List[str]] = None
    applicable_datasets: Optional[List[str]] = None
    applicable_tables: Optional[List[str]] = None
    applicable_columns: Optional[List[str]] = None
    
    is_active: Optional[bool] = None
    auto_enforcement: Optional[bool] = None
    notification_enabled: Optional[bool] = None
    
    effective_date: Optional[datetime] = None
    expiry_date: Optional[datetime] = None
    review_date: Optional[datetime] = None
    
    tags: Optional[List[str]] = None
    priority: Optional[int] = Field(None, ge=1, le=10)
    version: Optional[str] = None

# ==================== Response Schemas ====================

class GovernancePolicyRead(GovernancePolicyBase):
    """Schema para leitura de política de governança."""
    id: UUID
    status: PolicyStatus
    
    # Auditoria
    created_at: datetime
    updated_at: datetime
    created_by: Optional[UUID] = None
    updated_by: Optional[UUID] = None
    
    # Estatísticas
    violation_count: int = Field(0, description="Número de violações")
    compliance_score: float = Field(1.0, ge=0.0, le=1.0, description="Score de compliance")
    last_executed_at: Optional[datetime] = Field(None, description="Última execução")
    
    # Relacionamentos
    parent_policy_id: Optional[UUID] = Field(None, description="Política pai")
    child_policies_count: int = Field(0, description="Número de políticas filhas")
    
    class Config:
        from_attributes = True

class GovernancePolicySummary(BaseModel):
    """Schema resumido para política de governança."""
    id: UUID
    name: str
    policy_type: PolicyType
    scope: PolicyScope
    status: PolicyStatus
    enforcement_level: EnforcementLevel
    is_active: bool
    priority: int
    compliance_score: float
    violation_count: int
    created_at: datetime
    effective_date: Optional[datetime]
    expiry_date: Optional[datetime]
    
    class Config:
        from_attributes = True

# ==================== Query Schemas ====================

class GovernancePolicyQueryParams(BaseModel):
    """Parâmetros de busca para políticas de governança."""
    name: Optional[str] = None
    policy_type: Optional[PolicyType] = None
    scope: Optional[PolicyScope] = None
    status: Optional[PolicyStatus] = None
    enforcement_level: Optional[EnforcementLevel] = None
    compliance_framework: Optional[ComplianceFramework] = None
    is_active: Optional[bool] = None
    is_expired: Optional[bool] = None
    is_expiring_soon: Optional[bool] = None
    priority_min: Optional[int] = Field(None, ge=1, le=10)
    priority_max: Optional[int] = Field(None, ge=1, le=10)
    compliance_score_min: Optional[float] = Field(None, ge=0.0, le=1.0)
    compliance_score_max: Optional[float] = Field(None, ge=0.0, le=1.0)
    has_violations: Optional[bool] = None
    applicable_system: Optional[str] = None
    applicable_dataset: Optional[str] = None
    search: Optional[str] = None
    sort_by: Optional[str] = "created_at"
    sort_order: Optional[str] = Field("desc", regex="^(asc|desc)$")

# ==================== Statistics Schemas ====================

class GovernancePolicyStats(BaseModel):
    """Estatísticas de políticas de governança."""
    total_policies: int
    active_policies: int
    draft_policies: int
    expired_policies: int
    expiring_soon_policies: int
    
    # Por tipo
    policies_by_type: Dict[PolicyType, int]
    policies_by_scope: Dict[PolicyScope, int]
    policies_by_status: Dict[PolicyStatus, int]
    policies_by_enforcement: Dict[EnforcementLevel, int]
    
    # Compliance
    average_compliance_score: float
    total_violations: int
    policies_with_violations: int
    compliance_by_framework: Dict[ComplianceFramework, float]
    
    # Tendências
    policies_created_last_30_days: int
    policies_updated_last_30_days: int
    policies_executed_last_24_hours: int

# ==================== Execution Schemas ====================

class PolicyExecution(BaseModel):
    """Schema para execução de política."""
    policy_id: UUID
    execution_id: UUID
    execution_type: str = Field(..., description="Tipo de execução (manual, scheduled, triggered)")
    execution_status: str = Field(..., description="Status da execução")
    started_at: datetime
    completed_at: Optional[datetime] = None
    duration_seconds: Optional[float] = None
    
    # Resultados
    records_processed: int = 0
    violations_found: int = 0
    actions_taken: int = 0
    
    # Detalhes
    execution_details: Dict[str, Any] = Field(default_factory=dict)
    error_message: Optional[str] = None
    
    class Config:
        from_attributes = True

class PolicyViolation(BaseModel):
    """Schema para violação de política."""
    id: UUID
    policy_id: UUID
    execution_id: Optional[UUID] = None
    
    # Localização da violação
    system_name: Optional[str] = None
    dataset_name: Optional[str] = None
    table_name: Optional[str] = None
    column_name: Optional[str] = None
    record_id: Optional[str] = None
    
    # Detalhes da violação
    violation_type: str
    violation_description: str
    severity: str = Field(..., regex="^(low|medium|high|critical)$")
    
    # Status
    status: str = Field("open", regex="^(open|acknowledged|resolved|false_positive)$")
    resolution_notes: Optional[str] = None
    resolved_at: Optional[datetime] = None
    resolved_by: Optional[UUID] = None
    
    # Auditoria
    detected_at: datetime
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True

# ==================== Workflow Schemas ====================

class PolicyApproval(BaseModel):
    """Schema para aprovação de política."""
    policy_id: UUID
    approver_id: UUID
    approval_status: str = Field(..., regex="^(pending|approved|rejected)$")
    approval_notes: Optional[str] = None
    approved_at: Optional[datetime] = None
    
    class Config:
        from_attributes = True

class PolicyReview(BaseModel):
    """Schema para revisão de política."""
    policy_id: UUID
    reviewer_id: UUID
    review_type: str = Field(..., regex="^(scheduled|ad_hoc|compliance)$")
    review_status: str = Field(..., regex="^(pending|in_progress|completed)$")
    review_notes: Optional[str] = None
    recommendations: List[str] = Field(default_factory=list)
    
    # Resultados da revisão
    compliance_assessment: Optional[float] = Field(None, ge=0.0, le=1.0)
    effectiveness_score: Optional[float] = Field(None, ge=0.0, le=1.0)
    requires_update: bool = False
    
    # Datas
    scheduled_date: Optional[datetime] = None
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    
    class Config:
        from_attributes = True

# ==================== Bulk Operations ====================

class PolicyBulkOperation(BaseModel):
    """Schema para operações em lote."""
    operation_type: str = Field(..., regex="^(activate|deactivate|approve|archive|delete)$")
    policy_ids: List[UUID] = Field(..., min_items=1, max_items=1000)
    parameters: Dict[str, Any] = Field(default_factory=dict)
    reason: Optional[str] = None

class PolicyBulkResult(BaseModel):
    """Schema para resultado de operações em lote."""
    operation_type: str
    total_requested: int
    successful: int
    failed: int
    skipped: int
    
    # Detalhes
    successful_ids: List[UUID]
    failed_items: List[Dict[str, Any]]
    skipped_items: List[Dict[str, Any]]
    
    # Timing
    started_at: datetime
    completed_at: datetime
    duration_seconds: float

# ==================== Template Schemas ====================

class PolicyTemplate(BaseModel):
    """Schema para template de política."""
    id: UUID
    name: str
    description: Optional[str] = None
    policy_type: PolicyType
    scope: PolicyScope
    
    # Template content
    template_rules: Dict[str, Any]
    template_parameters: Dict[str, Any]
    default_enforcement_level: EnforcementLevel
    
    # Metadata
    is_system_template: bool = False
    usage_count: int = 0
    created_at: datetime
    created_by: Optional[UUID] = None
    
    class Config:
        from_attributes = True

# ==================== Compliance Schemas ====================

class ComplianceReport(BaseModel):
    """Schema para relatório de compliance."""
    id: UUID
    report_type: str
    framework: ComplianceFramework
    scope: PolicyScope
    
    # Período do relatório
    report_period_start: datetime
    report_period_end: datetime
    
    # Métricas
    total_policies: int
    compliant_policies: int
    non_compliant_policies: int
    compliance_percentage: float
    
    # Violações
    total_violations: int
    critical_violations: int
    resolved_violations: int
    
    # Detalhes
    policy_compliance_details: List[Dict[str, Any]]
    violation_summary: Dict[str, Any]
    recommendations: List[str]
    
    # Auditoria
    generated_at: datetime
    generated_by: Optional[UUID] = None
    
    class Config:
        from_attributes = True

# ==================== Export Schemas ====================

class PolicyExport(BaseModel):
    """Schema para exportação de políticas."""
    export_format: str = Field(..., regex="^(json|csv|xml|pdf)$")
    policy_ids: Optional[List[UUID]] = None
    include_violations: bool = False
    include_executions: bool = False
    include_reviews: bool = False
    date_range_start: Optional[datetime] = None
    date_range_end: Optional[datetime] = None

class PolicyImport(BaseModel):
    """Schema para importação de políticas."""
    import_format: str = Field(..., regex="^(json|csv|xml)$")
    import_data: str = Field(..., description="Dados para importação")
    overwrite_existing: bool = False
    validate_only: bool = False
    
class PolicyImportResult(BaseModel):
    """Schema para resultado de importação."""
    total_policies: int
    imported_policies: int
    updated_policies: int
    skipped_policies: int
    failed_policies: int
    
    validation_errors: List[Dict[str, Any]]
    import_warnings: List[Dict[str, Any]]
    
    imported_policy_ids: List[UUID]
    failed_items: List[Dict[str, Any]]

