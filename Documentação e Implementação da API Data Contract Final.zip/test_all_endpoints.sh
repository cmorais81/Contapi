#!/bin/bash
# Script para testar todos os endpoints da Data Governance API v2.0
# Autor: Carlos Morais
# Data: Julho 2025

echo "🧪 TESTANDO TODOS OS ENDPOINTS DA DATA GOVERNANCE API v2.0"
echo "============================================================"

BASE_URL="http://localhost:8000"
FAILED_TESTS=0
TOTAL_TESTS=0

# Função para testar endpoint
test_endpoint() {
    local method=$1
    local endpoint=$2
    local description=$3
    local data=$4
    
    TOTAL_TESTS=$((TOTAL_TESTS + 1))
    echo ""
    echo "🔍 Teste $TOTAL_TESTS: $description"
    echo "   Método: $method"
    echo "   Endpoint: $endpoint"
    
    if [ "$method" = "GET" ]; then
        response=$(curl -s -w "%{http_code}" -o /tmp/response.json "$BASE_URL$endpoint")
    elif [ "$method" = "POST" ]; then
        response=$(curl -s -w "%{http_code}" -o /tmp/response.json -X POST -H "Content-Type: application/json" -d "$data" "$BASE_URL$endpoint")
    fi
    
    http_code="${response: -3}"
    
    if [ "$http_code" -ge 200 ] && [ "$http_code" -lt 300 ]; then
        echo "   ✅ Status: $http_code (Sucesso)"
        if [ -s /tmp/response.json ]; then
            echo "   📄 Resposta:"
            cat /tmp/response.json | python3 -m json.tool | head -20
            if [ $(cat /tmp/response.json | wc -l) -gt 20 ]; then
                echo "   ... (resposta truncada)"
            fi
        fi
    else
        echo "   ❌ Status: $http_code (Falha)"
        FAILED_TESTS=$((FAILED_TESTS + 1))
        if [ -s /tmp/response.json ]; then
            echo "   📄 Erro:"
            cat /tmp/response.json
        fi
    fi
}

echo ""
echo "🚀 Iniciando testes..."

# ============================================================================
# ENDPOINTS BÁSICOS
# ============================================================================

echo ""
echo "📋 CATEGORIA: Endpoints Básicos"
echo "================================"

test_endpoint "GET" "/" "Endpoint raiz da API"
test_endpoint "GET" "/health" "Health check da aplicação"
test_endpoint "GET" "/api/v1/stats" "Estatísticas gerais da API"

# ============================================================================
# ENDPOINTS DE ENTIDADES
# ============================================================================

echo ""
echo "📋 CATEGORIA: Entidades"
echo "======================="

test_endpoint "GET" "/api/v1/entities/" "Listar todas as entidades"
test_endpoint "GET" "/api/v1/entities/?page=1&size=10" "Listar entidades com paginação"
test_endpoint "GET" "/api/v1/entities/?entity_type=table" "Filtrar entidades por tipo"
test_endpoint "GET" "/api/v1/entities/?status=active" "Filtrar entidades por status"

# Testar criação de entidade
entity_data='{"entity_name": "test_entity", "entity_type": "table", "description": "Entidade de teste", "owner": "Test Team", "status": "active"}'
test_endpoint "POST" "/api/v1/entities/" "Criar nova entidade" "$entity_data"

# Obter ID da primeira entidade para teste
first_entity_id=$(curl -s "$BASE_URL/api/v1/entities/" | python3 -c "import json, sys; data=json.load(sys.stdin); print(data['items'][0]['id'] if data['items'] else 'not-found')")
if [ "$first_entity_id" != "not-found" ]; then
    test_endpoint "GET" "/api/v1/entities/$first_entity_id" "Obter entidade específica"
fi

# ============================================================================
# ENDPOINTS DE CONTRATOS
# ============================================================================

echo ""
echo "📋 CATEGORIA: Contratos"
echo "======================="

test_endpoint "GET" "/api/v1/contracts/" "Listar todos os contratos"
test_endpoint "GET" "/api/v1/contracts/?page=1&size=10" "Listar contratos com paginação"
test_endpoint "GET" "/api/v1/contracts/?status=active" "Filtrar contratos por status"

# Testar criação de contrato
contract_data='{"contract_name": "Test Contract", "entity_name": "test_entity", "producer_team": "Test Team", "consumer_teams": ["Analytics"], "status": "active"}'
test_endpoint "POST" "/api/v1/contracts/" "Criar novo contrato" "$contract_data"

# Obter ID do primeiro contrato para teste
first_contract_id=$(curl -s "$BASE_URL/api/v1/contracts/" | python3 -c "import json, sys; data=json.load(sys.stdin); print(data['items'][0]['id'] if data['items'] else 'not-found')")
if [ "$first_contract_id" != "not-found" ]; then
    test_endpoint "GET" "/api/v1/contracts/$first_contract_id" "Obter contrato específico"
fi

# ============================================================================
# ENDPOINTS DE QUALIDADE
# ============================================================================

echo ""
echo "📋 CATEGORIA: Qualidade"
echo "======================="

test_endpoint "GET" "/api/v1/quality/rules/" "Listar regras de qualidade"
test_endpoint "GET" "/api/v1/quality/rules/?page=1&size=10" "Listar regras com paginação"
test_endpoint "GET" "/api/v1/quality/rules/?rule_type=validity" "Filtrar regras por tipo"
test_endpoint "GET" "/api/v1/quality/rules/?severity=high" "Filtrar regras por severidade"

# Obter ID da primeira regra para teste
first_rule_id=$(curl -s "$BASE_URL/api/v1/quality/rules/" | python3 -c "import json, sys; data=json.load(sys.stdin); print(data['items'][0]['id'] if data['items'] else 'not-found')")
if [ "$first_rule_id" != "not-found" ]; then
    test_endpoint "GET" "/api/v1/quality/rules/$first_rule_id" "Obter regra específica"
fi

# ============================================================================
# ENDPOINTS DATAHUB
# ============================================================================

echo ""
echo "📋 CATEGORIA: DataHub Integration"
echo "================================="

test_endpoint "GET" "/api/v1/datahub/entities/" "Listar entidades DataHub"
test_endpoint "GET" "/api/v1/datahub/entities/?page=1&size=10" "Listar entidades DataHub com paginação"
test_endpoint "GET" "/api/v1/datahub/entities/?platform=mysql" "Filtrar entidades por plataforma"
test_endpoint "GET" "/api/v1/datahub/entities/?entity_type=dataset" "Filtrar entidades por tipo"
test_endpoint "GET" "/api/v1/datahub/entities/?sync_status=synced" "Filtrar por status de sincronização"

# Obter ID da primeira entidade DataHub para teste
first_datahub_id=$(curl -s "$BASE_URL/api/v1/datahub/entities/" | python3 -c "import json, sys; data=json.load(sys.stdin); print(data['items'][0]['id'] if data['items'] else 'not-found')")
if [ "$first_datahub_id" != "not-found" ]; then
    test_endpoint "GET" "/api/v1/datahub/entities/$first_datahub_id" "Obter entidade DataHub específica"
fi

test_endpoint "GET" "/api/v1/datahub/stats" "Estatísticas DataHub"

# Testar sincronização DataHub
sync_data='{"platforms": ["mysql", "postgres"], "sync_type": "incremental", "include_lineage": true}'
test_endpoint "POST" "/api/v1/datahub/sync" "Iniciar sincronização DataHub" "$sync_data"

# ============================================================================
# ENDPOINTS CUSTOS AZURE
# ============================================================================

echo ""
echo "📋 CATEGORIA: Custos Azure"
echo "=========================="

test_endpoint "GET" "/api/v1/costs/azure/" "Listar custos Azure"
test_endpoint "GET" "/api/v1/costs/azure/?page=1&size=10" "Listar custos Azure com paginação"
test_endpoint "GET" "/api/v1/costs/azure/?service_name=Azure%20SQL%20Database" "Filtrar por serviço"
test_endpoint "GET" "/api/v1/costs/azure/?start_date=2025-06-01&end_date=2025-07-01" "Filtrar por período"

# Obter ID do primeiro custo Azure para teste
first_azure_cost_id=$(curl -s "$BASE_URL/api/v1/costs/azure/" | python3 -c "import json, sys; data=json.load(sys.stdin); print(data['items'][0]['id'] if data['items'] else 'not-found')")
if [ "$first_azure_cost_id" != "not-found" ]; then
    test_endpoint "GET" "/api/v1/costs/azure/$first_azure_cost_id" "Obter custo Azure específico"
fi

test_endpoint "GET" "/api/v1/costs/azure/analysis" "Análise de custos Azure"
test_endpoint "GET" "/api/v1/costs/azure/analysis?start_date=2025-06-01&end_date=2025-07-01&group_by=service_name" "Análise detalhada de custos Azure"

# ============================================================================
# ENDPOINTS CUSTOS DATABRICKS
# ============================================================================

echo ""
echo "📋 CATEGORIA: Custos Databricks"
echo "==============================="

test_endpoint "GET" "/api/v1/costs/databricks/" "Listar custos Databricks"
test_endpoint "GET" "/api/v1/costs/databricks/?page=1&size=10" "Listar custos Databricks com paginação"
test_endpoint "GET" "/api/v1/costs/databricks/?cluster_type=job" "Filtrar por tipo de cluster"
test_endpoint "GET" "/api/v1/costs/databricks/?start_date=2025-06-01&end_date=2025-07-01" "Filtrar por período"

# Obter ID do primeiro custo Databricks para teste
first_databricks_cost_id=$(curl -s "$BASE_URL/api/v1/costs/databricks/" | python3 -c "import json, sys; data=json.load(sys.stdin); print(data['items'][0]['id'] if data['items'] else 'not-found')")
if [ "$first_databricks_cost_id" != "not-found" ]; then
    test_endpoint "GET" "/api/v1/costs/databricks/$first_databricks_cost_id" "Obter custo Databricks específico"
fi

test_endpoint "GET" "/api/v1/costs/databricks/analysis" "Análise de custos Databricks"
test_endpoint "GET" "/api/v1/costs/databricks/analysis?start_date=2025-06-01&end_date=2025-07-01" "Análise detalhada de custos Databricks"

# ============================================================================
# ENDPOINTS RECOMENDAÇÕES DE CUSTO
# ============================================================================

echo ""
echo "📋 CATEGORIA: Recomendações de Custo"
echo "===================================="

test_endpoint "GET" "/api/v1/costs/recommendations/" "Listar recomendações de custo"
test_endpoint "GET" "/api/v1/costs/recommendations/?page=1&size=10" "Listar recomendações com paginação"
test_endpoint "GET" "/api/v1/costs/recommendations/?recommendation_type=storage_optimization" "Filtrar por tipo"
test_endpoint "GET" "/api/v1/costs/recommendations/?status=open" "Filtrar por status"
test_endpoint "GET" "/api/v1/costs/recommendations/?min_savings=100" "Filtrar por economia mínima"

# Obter ID da primeira recomendação para teste
first_recommendation_id=$(curl -s "$BASE_URL/api/v1/costs/recommendations/" | python3 -c "import json, sys; data=json.load(sys.stdin); print(data['items'][0]['id'] if data['items'] else 'not-found')")
if [ "$first_recommendation_id" != "not-found" ]; then
    test_endpoint "GET" "/api/v1/costs/recommendations/$first_recommendation_id" "Obter recomendação específica"
fi

test_endpoint "GET" "/api/v1/costs/recommendations/summary" "Resumo das recomendações"

# ============================================================================
# RESULTADOS FINAIS
# ============================================================================

echo ""
echo "============================================================"
echo "🎯 RESULTADOS FINAIS DOS TESTES"
echo "============================================================"
echo "Total de testes executados: $TOTAL_TESTS"
echo "Testes com sucesso: $((TOTAL_TESTS - FAILED_TESTS))"
echo "Testes com falha: $FAILED_TESTS"

if [ $FAILED_TESTS -eq 0 ]; then
    echo "🎉 TODOS OS TESTES PASSARAM! API 100% FUNCIONAL!"
else
    echo "⚠️  Alguns testes falharam. Verifique os logs acima."
fi

echo ""
echo "📚 Documentação disponível em: $BASE_URL/docs"
echo "🔍 ReDoc disponível em: $BASE_URL/redoc"
echo ""

# Limpar arquivo temporário
rm -f /tmp/response.json

