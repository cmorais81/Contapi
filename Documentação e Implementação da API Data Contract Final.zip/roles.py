"""
Role Endpoints

Endpoints para gerenciamento de roles (RBAC).

Author: Carlos Morais <carlos.morais@f1rst.com.br>
Date: Julho 2025
"""

from typing import List, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.exceptions import NotFoundError, ConflictError, ValidationError, BusinessRuleError
from app.schemas.users.role import (
    RoleCreate, 
    RoleUpdate, 
    RoleRead, 
    RoleSummary,
    RoleQueryParams,
    RoleStats,
    RolePermission,
    RoleHierarchy,
    RoleMatrix,
    RoleBulkOperation,
    RoleBulkResult,
    PermissionType,
    ResourceType,
    ScopeType,
    RoleType
)
from app.services.users.role_service import RoleService

router = APIRouter()

# ==================== CRUD Operations ====================

@router.post("/", response_model=RoleRead, status_code=status.HTTP_201_CREATED)
def create_role(
    role_data: RoleCreate,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Cria um novo role.
    
    Args:
        role_data: Dados do role
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        RoleRead: Role criado
        
    Raises:
        HTTPException: Se dados são inválidos ou role já existe
    """
    try:
        role_service = RoleService(db)
        role = role_service.create_role(role_data, current_user_id)
        return role
    except ConflictError as e:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(e))
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(e))
    except BusinessRuleError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

@router.get("/{role_id}", response_model=RoleRead)
def get_role(
    role_id: UUID,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Obtém um role por ID.
    
    Args:
        role_id: ID do role
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        RoleRead: Role encontrado
        
    Raises:
        HTTPException: Se role não encontrado
    """
    try:
        role_service = RoleService(db)
        role = role_service.get_role(role_id)
        if not role:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Role não encontrado")
        return role
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

@router.put("/{role_id}", response_model=RoleRead)
def update_role(
    role_id: UUID,
    role_data: RoleUpdate,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Atualiza um role existente.
    
    Args:
        role_id: ID do role
        role_data: Dados para atualização
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        RoleRead: Role atualizado
        
    Raises:
        HTTPException: Se role não encontrado ou dados inválidos
    """
    try:
        role_service = RoleService(db)
        role = role_service.update_role(role_id, role_data, current_user_id)
        return role
    except NotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(e))
    except BusinessRuleError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

@router.delete("/{role_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_role(
    role_id: UUID,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Exclui um role.
    
    Args:
        role_id: ID do role
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Raises:
        HTTPException: Se role não encontrado
    """
    try:
        role_service = RoleService(db)
        success = role_service.delete_role(role_id, current_user_id)
        if not success:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Role não encontrado")
    except NotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except BusinessRuleError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

# ==================== Search and Query ====================

@router.get("/", response_model=List[RoleSummary])
def search_roles(
    skip: int = Query(0, ge=0, description="Número de registros para pular"),
    limit: int = Query(100, ge=1, le=1000, description="Limite de registros"),
    name: Optional[str] = Query(None, description="Filtrar por nome"),
    role_type: Optional[RoleType] = Query(None, description="Filtrar por tipo de role"),
    scope_type: Optional[ScopeType] = Query(None, description="Filtrar por tipo de escopo"),
    is_active: Optional[bool] = Query(None, description="Filtrar por roles ativos"),
    is_system: Optional[bool] = Query(None, description="Filtrar por roles de sistema"),
    parent_role_id: Optional[UUID] = Query(None, description="Filtrar por role pai"),
    search: Optional[str] = Query(None, description="Busca textual"),
    sort_by: Optional[str] = Query("created_at", description="Campo para ordenação"),
    sort_order: Optional[str] = Query("desc", regex="^(asc|desc)$", description="Ordem de classificação"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Busca roles com filtros avançados.
    
    Args:
        skip: Número de registros para pular
        limit: Limite de registros
        name: Filtrar por nome
        role_type: Filtrar por tipo de role
        scope_type: Filtrar por tipo de escopo
        is_active: Filtrar por roles ativos
        is_system: Filtrar por roles de sistema
        parent_role_id: Filtrar por role pai
        search: Busca textual
        sort_by: Campo para ordenação
        sort_order: Ordem de classificação
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        List[RoleSummary]: Lista de roles
    """
    try:
        role_service = RoleService(db)
        
        # Construir parâmetros de busca
        params = RoleQueryParams(
            name=name,
            role_type=role_type,
            scope_type=scope_type,
            is_active=is_active,
            is_system=is_system,
            parent_role_id=parent_role_id,
            search=search,
            sort_by=sort_by,
            sort_order=sort_order
        )
        
        roles, total = role_service.search_roles(params, skip, limit)
        
        return roles
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

@router.get("/stats", response_model=RoleStats)
def get_role_stats(
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Obtém estatísticas de roles.
    
    Args:
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        RoleStats: Estatísticas dos roles
    """
    try:
        role_service = RoleService(db)
        stats = role_service.get_role_stats()
        return stats
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

# ==================== Permission Management ====================

@router.get("/{role_id}/permissions", response_model=List[RolePermission])
def get_role_permissions(
    role_id: UUID,
    include_inherited: bool = Query(True, description="Incluir permissões herdadas"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Obtém permissões de um role.
    
    Args:
        role_id: ID do role
        include_inherited: Incluir permissões herdadas
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        List[RolePermission]: Lista de permissões
    """
    try:
        role_service = RoleService(db)
        permissions = role_service.get_role_permissions(role_id, include_inherited)
        return permissions
    except NotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

@router.post("/{role_id}/permissions", response_model=RolePermission)
def add_role_permission(
    role_id: UUID,
    permission: RolePermission,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Adiciona permissão a um role.
    
    Args:
        role_id: ID do role
        permission: Permissão a ser adicionada
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        RolePermission: Permissão adicionada
    """
    try:
        role_service = RoleService(db)
        added_permission = role_service.add_role_permission(role_id, permission, current_user_id)
        return added_permission
    except NotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except ConflictError as e:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(e))
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(e))
    except BusinessRuleError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

@router.delete("/{role_id}/permissions/{permission_id}", status_code=status.HTTP_204_NO_CONTENT)
def remove_role_permission(
    role_id: UUID,
    permission_id: UUID,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Remove permissão de um role.
    
    Args:
        role_id: ID do role
        permission_id: ID da permissão
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
    """
    try:
        role_service = RoleService(db)
        role_service.remove_role_permission(role_id, permission_id, current_user_id)
    except NotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except BusinessRuleError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

# ==================== Role Hierarchy ====================

@router.get("/{role_id}/hierarchy", response_model=RoleHierarchy)
def get_role_hierarchy(
    role_id: UUID,
    max_depth: int = Query(10, ge=1, le=20, description="Profundidade máxima da hierarquia"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Obtém hierarquia de um role.
    
    Args:
        role_id: ID do role
        max_depth: Profundidade máxima
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        RoleHierarchy: Hierarquia do role
    """
    try:
        role_service = RoleService(db)
        hierarchy = role_service.get_role_hierarchy(role_id, max_depth)
        return hierarchy
    except NotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

@router.get("/{role_id}/children", response_model=List[RoleSummary])
def get_role_children(
    role_id: UUID,
    recursive: bool = Query(False, description="Busca recursiva"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Obtém roles filhos de um role.
    
    Args:
        role_id: ID do role pai
        recursive: Busca recursiva
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        List[RoleSummary]: Lista de roles filhos
    """
    try:
        role_service = RoleService(db)
        children = role_service.get_role_children(role_id, recursive)
        return children
    except NotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

@router.get("/{role_id}/parents", response_model=List[RoleSummary])
def get_role_parents(
    role_id: UUID,
    recursive: bool = Query(False, description="Busca recursiva"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Obtém roles pais de um role.
    
    Args:
        role_id: ID do role filho
        recursive: Busca recursiva
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        List[RoleSummary]: Lista de roles pais
    """
    try:
        role_service = RoleService(db)
        parents = role_service.get_role_parents(role_id, recursive)
        return parents
    except NotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

# ==================== Permission Checking ====================

@router.post("/{role_id}/check-permission", response_model=dict)
def check_role_permission(
    role_id: UUID,
    permission_type: PermissionType,
    resource_type: ResourceType,
    resource_id: Optional[str] = None,
    scope_type: Optional[ScopeType] = None,
    scope_id: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Verifica se um role tem uma permissão específica.
    
    Args:
        role_id: ID do role
        permission_type: Tipo de permissão
        resource_type: Tipo de recurso
        resource_id: ID do recurso (opcional)
        scope_type: Tipo de escopo (opcional)
        scope_id: ID do escopo (opcional)
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        dict: Resultado da verificação
    """
    try:
        role_service = RoleService(db)
        result = role_service.check_role_permission(
            role_id, permission_type, resource_type, resource_id, scope_type, scope_id
        )
        return {
            "has_permission": result.has_permission,
            "permission_source": result.permission_source,
            "inherited_from": result.inherited_from,
            "scope_match": result.scope_match,
            "details": result.details
        }
    except NotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

# ==================== Role Matrix ====================

@router.get("/matrix", response_model=RoleMatrix)
def get_role_matrix(
    role_ids: Optional[List[UUID]] = Query(None, description="IDs dos roles específicos"),
    permission_types: Optional[List[PermissionType]] = Query(None, description="Tipos de permissão"),
    resource_types: Optional[List[ResourceType]] = Query(None, description="Tipos de recurso"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Obtém matriz de permissões dos roles.
    
    Args:
        role_ids: IDs dos roles específicos
        permission_types: Tipos de permissão
        resource_types: Tipos de recurso
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        RoleMatrix: Matriz de permissões
    """
    try:
        role_service = RoleService(db)
        matrix = role_service.get_role_matrix(role_ids, permission_types, resource_types)
        return matrix
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

# ==================== Role Activation/Deactivation ====================

@router.post("/{role_id}/activate", response_model=RoleRead)
def activate_role(
    role_id: UUID,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Ativa um role.
    
    Args:
        role_id: ID do role
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        RoleRead: Role ativado
    """
    try:
        role_service = RoleService(db)
        role = role_service.activate_role(role_id, current_user_id)
        return role
    except NotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except BusinessRuleError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

@router.post("/{role_id}/deactivate", response_model=RoleRead)
def deactivate_role(
    role_id: UUID,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Desativa um role.
    
    Args:
        role_id: ID do role
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        RoleRead: Role desativado
    """
    try:
        role_service = RoleService(db)
        role = role_service.deactivate_role(role_id, current_user_id)
        return role
    except NotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except BusinessRuleError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

# ==================== Bulk Operations ====================

@router.post("/bulk", response_model=RoleBulkResult)
def bulk_role_operation(
    operation: RoleBulkOperation,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Executa operação em lote nos roles.
    
    Args:
        operation: Operação a ser executada
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        RoleBulkResult: Resultado da operação
    """
    try:
        role_service = RoleService(db)
        result = role_service.bulk_operation(operation, current_user_id)
        return result
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(e))
    except BusinessRuleError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

# ==================== Role Templates ====================

@router.get("/templates", response_model=List[RoleSummary])
def get_role_templates(
    role_type: Optional[RoleType] = Query(None, description="Filtrar por tipo de role"),
    scope_type: Optional[ScopeType] = Query(None, description="Filtrar por tipo de escopo"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Obtém templates de roles disponíveis.
    
    Args:
        role_type: Filtrar por tipo de role
        scope_type: Filtrar por tipo de escopo
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        List[RoleSummary]: Lista de templates
    """
    try:
        role_service = RoleService(db)
        templates = role_service.get_role_templates(role_type, scope_type)
        return templates
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

@router.post("/{role_id}/clone", response_model=RoleRead)
def clone_role(
    role_id: UUID,
    new_name: str,
    new_description: Optional[str] = None,
    include_permissions: bool = Query(True, description="Incluir permissões"),
    include_hierarchy: bool = Query(False, description="Incluir hierarquia"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Clona um role existente.
    
    Args:
        role_id: ID do role a ser clonado
        new_name: Nome do novo role
        new_description: Descrição do novo role
        include_permissions: Incluir permissões
        include_hierarchy: Incluir hierarquia
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        RoleRead: Role clonado
    """
    try:
        role_service = RoleService(db)
        cloned_role = role_service.clone_role(
            role_id, new_name, new_description, include_permissions, include_hierarchy, current_user_id
        )
        return cloned_role
    except NotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except ConflictError as e:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(e))
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(e))
    except BusinessRuleError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

# ==================== Role Validation ====================

@router.post("/{role_id}/validate", response_model=dict)
def validate_role(
    role_id: UUID,
    validation_type: str = Query(..., description="Tipo de validação (permissions, hierarchy, conflicts)"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Valida configuração de um role.
    
    Args:
        role_id: ID do role
        validation_type: Tipo de validação
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        dict: Resultado da validação
    """
    try:
        role_service = RoleService(db)
        result = role_service.validate_role(role_id, validation_type, current_user_id)
        return result
    except NotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(e))
    except BusinessRuleError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

# ==================== Role Export ====================

@router.get("/{role_id}/export", response_model=dict)
def export_role(
    role_id: UUID,
    format: str = Query("json", regex="^(json|csv|xml)$", description="Formato de exportação"),
    include_permissions: bool = Query(True, description="Incluir permissões"),
    include_hierarchy: bool = Query(True, description="Incluir hierarquia"),
    include_assignments: bool = Query(False, description="Incluir atribuições"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Exporta configuração de um role.
    
    Args:
        role_id: ID do role
        format: Formato de exportação
        include_permissions: Incluir permissões
        include_hierarchy: Incluir hierarquia
        include_assignments: Incluir atribuições
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        dict: Dados exportados
    """
    try:
        role_service = RoleService(db)
        exported_data = role_service.export_role(
            role_id, format, include_permissions, include_hierarchy, include_assignments, current_user_id
        )
        return exported_data
    except NotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except BusinessRuleError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

