# Data Governance API v2.0 - Prompt de Regeneração Completo

**Versão:** 2.0.0  
**Data:** Julho 2025  
**Desenvolvido por:** Carlos Morais  
**Objetivo:** Prompt para regeneração completa do projeto  

---

## 🎯 PROMPT PARA REGENERAÇÃO

### Contexto e Objetivo
Criar uma **Data Governance API v2.0** completa e funcional, uma solução enterprise de governança de dados com integrações nativas para DataHub e Azure Cost Management. O projeto deve ser desenvolvido por **Carlos Morais** e incluir aplicação funcional, documentação completa e dados mockados realísticos.

### Especificações Técnicas Obrigatórias

#### 🏗️ **Arquitetura e Tecnologias**
- **Framework:** FastAPI (Python 3.11+)
- **Database:** SQLite para desenvolvimento (compatível PostgreSQL)
- **ORM:** SQLAlchemy com modelos declarativos
- **Schemas:** Pydantic v2 para validação
- **Documentação:** Swagger/OpenAPI automática
- **Estrutura:** Arquitetura em camadas (models, schemas, services, endpoints)

#### 📊 **Modelo de Dados (42 Tabelas DBML)**

**Core Entities (10 tabelas):**
- entities, data_objects, components, contracts, contract_versions
- quality_rules, quality_executions, quality_results, quality_metrics, quality_thresholds

**Governance & Users (8 tabelas):**
- users, roles, user_roles, tags, entity_tags
- governance_policies, policy_executions, audit_logs

**Lineage & Metrics (6 tabelas):**
- lineage_relationships, lineage_analysis, performance_metrics
- metric_definitions, metric_values, metric_alerts

**Privacy & Integrations (6 tabelas):**
- data_classifications, privacy_policies, consent_records
- integrations, integration_logs, external_systems

**DataHub Integration (6 tabelas - NOVA v2.0):**
- datahub_entities, datahub_lineage, datahub_sync_jobs
- datahub_metadata, datahub_platforms, datahub_schemas

**Azure Cost Management (6 tabelas - NOVA v2.0):**
- azure_cost_data, databricks_cost_data, cost_optimization_recommendations
- cost_budgets, cost_alerts, cost_forecasts

#### 🔌 **Integrações Obrigatórias**
1. **DataHub**: Sincronização bidirecional, descoberta de metadados, linhagem cross-platform
2. **Azure Cost Management**: Monitoramento custos, análise preditiva, recomendações IA
3. **Databricks**: Métricas DBU, cluster costs, job execution costs
4. **Unity Catalog**: Compatibilidade (mencionado na documentação)
5. **Informatica Axon**: Conectividade enterprise (mencionado na documentação)

#### 📋 **Endpoints Obrigatórios (48+ endpoints)**

**Core APIs:**
- `GET /health` - Health check
- `GET /info` - Informações da API
- `GET /api/v1/stats` - Estatísticas gerais

**Entities & Contracts:**
- `GET/POST/PUT/DELETE /api/v1/entities/` - CRUD entidades
- `GET/POST/PUT/DELETE /api/v1/contracts/` - CRUD contratos
- `GET /api/v1/entities/{id}` - Entidade específica
- `GET /api/v1/contracts/{id}` - Contrato específico

**Quality Management:**
- `GET /api/v1/quality/rules/` - Regras de qualidade
- `GET /api/v1/quality/executions/` - Execuções
- `GET /api/v1/quality/results/` - Resultados

**DataHub Integration (NOVO v2.0):**
- `GET /api/v1/datahub/entities/` - Entidades sincronizadas
- `POST /api/v1/datahub/sync` - Iniciar sincronização
- `GET /api/v1/datahub/sync/status/{id}` - Status sincronização
- `GET /api/v1/datahub/stats` - Estatísticas DataHub
- `GET /api/v1/datahub/entities/{id}/lineage` - Linhagem

**Azure Cost Management (NOVO v2.0):**
- `GET /api/v1/costs/azure/` - Custos Azure
- `GET /api/v1/costs/azure/analysis` - Análise custos
- `GET /api/v1/costs/databricks/` - Custos Databricks
- `GET /api/v1/costs/recommendations/` - Recomendações
- `GET /api/v1/costs/recommendations/summary` - Resumo executivo
- `GET /api/v1/costs/forecasts/` - Previsões

**Users & Governance:**
- `GET /api/v1/users/` - Usuários
- `GET /api/v1/governance/policies/` - Políticas
- `GET /api/v1/tags/` - Tags

#### 📊 **Dados Mockados Obrigatórios (260+ registros)**
- **Entidades**: 3 entidades (Customer Data, Sales Transactions, Product Catalog)
- **Contratos**: 2 contratos de dados
- **Regras de Qualidade**: 2 regras configuradas
- **Custos Azure**: 100 registros realísticos (compute, storage, network)
- **Custos Databricks**: 80 registros (DBU, clusters, jobs)
- **Recomendações**: 25 otimizações (economia R$ 500K+ anual)
- **DataHub Entities**: 50 entidades de múltiplas plataformas
- **Usuários**: 12 usuários com diferentes roles
- **Tags**: 20 tags organizacionais
- **Políticas**: 10 políticas de governança

### Funcionalidades Específicas Obrigatórias

#### 🔍 **DataHub Integration**
- **Sincronização Bidirecional**: Metadados, linhagem, jobs
- **Descoberta Automatizada**: Múltiplas plataformas (PostgreSQL, Snowflake, BigQuery)
- **Linhagem Cross-Platform**: Rastreamento completo de dependências
- **Observabilidade**: Monitoramento saúde e performance
- **Mapeamento Inteligente**: Datasets → Entidades, Jobs → Processos

#### 💰 **Azure Cost Management**
- **Coleta Automatizada**: Azure Cost API, Resource Graph API, Databricks API
- **Análise Preditiva**: Forecasting com IA, detecção anomalias
- **Recomendações Inteligentes**: Right-sizing, scheduling, storage optimization
- **Dashboards**: Executivo, operacional, engenharia
- **Alertas**: Budget thresholds, anomalias, oportunidades

#### 📊 **Analytics e Insights**
- **ROI Calculation**: Retorno sobre investimento
- **Cost Attribution**: Alocação por equipe/projeto
- **Performance Metrics**: KPIs e dashboards
- **Compliance Tracking**: GDPR, CCPA, HIPAA

### Documentação Obrigatória

#### 📚 **Documentos Técnicos (200+ páginas)**
1. **README_v2.md**: Guia principal com início rápido
2. **technical_documentation.md**: Documentação técnica completa v2.0
3. **data_governance_model_v2.dbml**: Modelo DBML com 42 tabelas
4. **integration_guide.md**: Guia integrações v2.0 (DataHub, Azure)
5. **user_journey_guide.md**: Jornada usuário (8 personas)
6. **business_insights.md**: Insights de negócio e ROI
7. **windows_deployment_guide.md**: Deploy Windows/PyCharm

#### 📋 **Conteúdo Documentação**
- **Arquitetura**: Princípios, componentes, padrões
- **Integrações**: DataHub, Azure, Unity Catalog, Informatica Axon
- **APIs**: 48+ endpoints com exemplos curl
- **Segurança**: OAuth, RBAC, auditoria, compliance
- **Performance**: Caching, scaling, otimizações
- **Casos de Uso**: Por setor (financeiro, saúde, varejo)
- **ROI**: Métricas, benefícios, business case

### Scripts e Automação

#### 🚀 **Scripts Obrigatórios**
- **start_application_v2.py**: Inicialização completa com testes
- **test_all_endpoints.sh**: Testes automáticos via curl
- **create_mock_data.py**: Geração dados mockados
- **create_cost_mock_data.py**: Dados custos Azure/Databricks

#### 🧪 **Validação Automática**
- **Health checks**: Verificação dependências, arquivos
- **Endpoint testing**: 48+ endpoints via curl
- **Data validation**: Verificação dados mockados
- **Performance testing**: Responsividade aplicação

### Estrutura de Arquivos Obrigatória

```
data-governance-api/
├── README_v2.md
├── requirements.txt
├── app/
│   ├── main_v2_complete.py (aplicação principal)
│   ├── models/ (SQLAlchemy models)
│   │   ├── base.py
│   │   ├── entities/
│   │   ├── contracts/
│   │   ├── quality/
│   │   ├── integrations/ (DataHub, Azure)
│   │   └── ...
│   ├── schemas/ (Pydantic schemas)
│   │   ├── base/
│   │   ├── entities/
│   │   ├── integrations/ (DataHub, Azure)
│   │   └── ...
│   └── services/ (Business logic)
├── docs/
│   ├── technical_documentation.md
│   ├── data_governance_model_v2.dbml
│   ├── integration_guide.md
│   ├── user_journey_guide.md
│   ├── business_insights.md
│   └── windows_deployment_guide.md
├── scripts/
│   ├── start_application_v2.py
│   └── test_all_endpoints.sh
├── mock_data/
│   ├── azure_costs.json
│   ├── databricks_costs.json
│   ├── cost_recommendations.json
│   ├── datahub_entities.json
│   └── all_data.json
└── tests/
```

### Critérios de Sucesso

#### ✅ **Funcionalidade**
- [ ] Aplicação inicia sem erros
- [ ] 48+ endpoints respondem corretamente
- [ ] 260+ registros mockados carregados
- [ ] Integrações DataHub e Azure funcionais
- [ ] Documentação Swagger acessível

#### ✅ **Qualidade**
- [ ] Código Python 3.11+ compatível
- [ ] Schemas Pydantic v2 válidos
- [ ] Modelos SQLAlchemy funcionais
- [ ] Testes automáticos passando
- [ ] Performance responsiva

#### ✅ **Documentação**
- [ ] 200+ páginas documentação técnica
- [ ] Guias para diferentes públicos
- [ ] Exemplos práticos funcionais
- [ ] Modelo DBML completo
- [ ] Instruções deployment Windows

#### ✅ **Entrega**
- [ ] Pacote ZIP organizado
- [ ] Scripts inicialização funcionais
- [ ] Dados mockados realísticos
- [ ] Autoria Carlos Morais consistente
- [ ] Pronto para produção

### Comando de Execução Final

```bash
# Após geração completa:
python scripts/start_application_v2.py

# Validação:
curl http://localhost:8000/health
curl http://localhost:8000/api/v1/stats
curl http://localhost:8000/api/v1/costs/recommendations/summary

# Documentação:
# http://localhost:8000/docs
```

### Benefícios Esperados

#### 📈 **Métricas de Impacto**
- **40-80% redução** incidentes qualidade
- **30-60% redução** tempo integração
- **ROI positivo** 12-18 meses
- **R$ 500K+ economia anual** via otimizações
- **Conformidade automatizada** GDPR/CCPA/HIPAA

#### 🎯 **Diferenciais**
- **Única solução** com DataHub + Azure Cost Management
- **FinOps para dados** baseado em IA
- **Multi-platform** (4 integrações principais)
- **Enterprise ready** com segurança robusta
- **Documentação completa** 200+ páginas

---

## 🚀 PROMPT RESUMIDO PARA IA

**"Crie uma Data Governance API v2.0 completa desenvolvida por Carlos Morais com:**

**CORE:** FastAPI + SQLAlchemy + Pydantic v2, 42 tabelas DBML, 48+ endpoints funcionais

**INTEGRAÇÕES:** DataHub (sincronização bidirecional) + Azure Cost Management (otimização IA) + Databricks + Unity Catalog + Informatica Axon

**DADOS:** 260+ registros mockados (Azure costs, Databricks DBU, recomendações R$ 500K+ economia)

**FUNCIONALIDADES:** Descoberta automatizada, contratos inteligentes, qualidade contínua, análise custos preditiva, conformidade GDPR/CCPA/HIPAA

**DOCUMENTAÇÃO:** 200+ páginas (técnica, integrações, jornada usuário, business insights, deployment Windows)

**ENTREGA:** Aplicação funcional + scripts automação + testes curl + pacote enterprise pronto produção

**VALIDAÇÃO:** Todos endpoints testados, dados carregados, documentação Swagger, performance validada"**

---

*Este prompt garante regeneração completa e consistente do projeto Data Governance API v2.0 com todas as funcionalidades, integrações e documentação implementadas na versão atual.*

