"""
Role Service

Service para gerenciamento de roles e sistema RBAC (Role-Based Access Control).

Author: Carlos Morais <carlos.morais@f1rst.com.br>
Date: Julho 2025
"""

import uuid
from datetime import datetime
from typing import List, Optional, Dict, Any, Tuple, Set
from uuid import UUID

from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, func, desc, asc

from app.core.exceptions import (
    ValidationError, 
    NotFoundError, 
    ConflictError, 
    AuthorizationError,
    BusinessRuleError
)
from app.models.users.role import Role
from app.schemas.users.role import (
    RoleCreate, 
    RoleUpdate, 
    RoleRead, 
    RoleSummary,
    RoleQueryParams,
    RoleStats,
    RoleHierarchy,
    RolePermissionMatrix,
    RoleBulkOperation,
    RoleBulkResult,
    PermissionCheck,
    PermissionCheckResult,
    Permission,
    PermissionType,
    ResourceType,
    RoleType,
    RoleScope
)
from app.components.audit_logger import AuditLogger


class RoleService:
    """
    Service para gerenciamento completo de roles e permissões.
    
    Funcionalidades:
    - CRUD de roles
    - Sistema de permissões granular
    - Hierarquia de roles
    - Verificação de permissões
    - Operações em lote
    - Analytics de roles
    """
    
    def __init__(self, db: Session):
        self.db = db
        self.audit_logger = AuditLogger(db)
        
        # Cache de permissões para performance
        self._permission_cache = {}
        self._cache_ttl = 300  # 5 minutos
    
    # ==================== CRUD Operations ====================
    
    def create_role(
        self, 
        role_data: RoleCreate, 
        created_by: Optional[UUID] = None
    ) -> RoleRead:
        """
        Cria um novo role com validações completas.
        
        Args:
            role_data: Dados do role
            created_by: ID do usuário que está criando
            
        Returns:
            RoleRead: Role criado
            
        Raises:
            ConflictError: Se nome já existe
            ValidationError: Se dados são inválidos
        """
        try:
            # Validar unicidade do nome
            self._validate_role_name_uniqueness(role_data.name)
            
            # Validar hierarquia se especificado
            if role_data.parent_role_id:
                self._validate_role_hierarchy(role_data.parent_role_id)
            
            # Criar modelo do role
            role = Role(
                id=uuid.uuid4(),
                name=role_data.name.upper(),
                display_name=role_data.display_name,
                description=role_data.description,
                role_type=role_data.role_type,
                scope=role_data.scope,
                is_active=role_data.is_active,
                is_system=role_data.is_system,
                parent_role_id=role_data.parent_role_id,
                organization_id=role_data.organization_id,
                department_id=role_data.department_id,
                project_id=role_data.project_id,
                permissions=role_data.permissions.dict(),
                metadata=role_data.metadata or {},
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow()
            )
            
            self.db.add(role)
            self.db.commit()
            self.db.refresh(role)
            
            # Copiar permissões de outro role se especificado
            if role_data.copy_from_role_id:
                self._copy_permissions_from_role(role.id, role_data.copy_from_role_id)
            
            # Atribuir a usuários se especificado
            if role_data.assign_to_users:
                self._assign_role_to_users(role.id, role_data.assign_to_users, created_by)
            
            # Limpar cache de permissões
            self._clear_permission_cache()
            
            # Log de auditoria
            self.audit_logger.log_user_action(
                user_id=created_by,
                action="role_created",
                details={
                    "role_id": str(role.id),
                    "role_name": role.name,
                    "role_type": role.role_type,
                    "scope": role.scope
                }
            )
            
            return self._to_role_read(role)
            
        except Exception as e:
            self.db.rollback()
            if isinstance(e, (ConflictError, ValidationError)):
                raise
            raise BusinessRuleError(f"Erro ao criar role: {str(e)}")
    
    def get_role(self, role_id: UUID) -> Optional[RoleRead]:
        """
        Obtém um role por ID.
        
        Args:
            role_id: ID do role
            
        Returns:
            RoleRead: Role encontrado ou None
        """
        role = self.db.query(Role).filter(Role.id == role_id).first()
        return self._to_role_read(role) if role else None
    
    def get_role_by_name(self, name: str) -> Optional[RoleRead]:
        """
        Obtém um role por nome.
        
        Args:
            name: Nome do role
            
        Returns:
            RoleRead: Role encontrado ou None
        """
        role = self.db.query(Role).filter(Role.name == name.upper()).first()
        return self._to_role_read(role) if role else None
    
    def update_role(
        self, 
        role_id: UUID, 
        role_data: RoleUpdate, 
        updated_by: Optional[UUID] = None
    ) -> RoleRead:
        """
        Atualiza um role existente.
        
        Args:
            role_id: ID do role
            role_data: Dados para atualização
            updated_by: ID do usuário que está atualizando
            
        Returns:
            RoleRead: Role atualizado
            
        Raises:
            NotFoundError: Se role não existe
            BusinessRuleError: Se não pode ser atualizado
        """
        role = self.db.query(Role).filter(Role.id == role_id).first()
        if not role:
            raise NotFoundError(f"Role {role_id} não encontrado")
        
        # Verificar se pode ser atualizado
        if role.is_system and not self._is_system_admin(updated_by):
            raise AuthorizationError("Apenas administradores do sistema podem alterar roles do sistema")
        
        try:
            # Armazenar valores antigos para auditoria
            old_values = {
                "display_name": role.display_name,
                "description": role.description,
                "is_active": role.is_active,
                "permissions": role.permissions
            }
            
            # Atualizar campos
            update_data = role_data.dict(exclude_unset=True)
            for field, value in update_data.items():
                if hasattr(role, field):
                    if field == "permissions":
                        # Merge com permissões existentes
                        current_permissions = role.permissions or {}
                        if isinstance(value, dict):
                            current_permissions.update(value)
                            setattr(role, field, current_permissions)
                        else:
                            setattr(role, field, value.dict() if hasattr(value, 'dict') else value)
                    else:
                        setattr(role, field, value)
            
            role.updated_at = datetime.utcnow()
            
            self.db.commit()
            self.db.refresh(role)
            
            # Limpar cache de permissões
            self._clear_permission_cache()
            
            # Log de auditoria
            new_values = {
                "display_name": role.display_name,
                "description": role.description,
                "is_active": role.is_active,
                "permissions": role.permissions
            }
            
            self.audit_logger.log_user_action(
                user_id=updated_by,
                action="role_updated",
                details={
                    "role_id": str(role.id),
                    "role_name": role.name,
                    "old_values": old_values,
                    "new_values": new_values,
                    "changed_fields": list(update_data.keys())
                }
            )
            
            return self._to_role_read(role)
            
        except Exception as e:
            self.db.rollback()
            if isinstance(e, (NotFoundError, AuthorizationError)):
                raise
            raise BusinessRuleError(f"Erro ao atualizar role: {str(e)}")
    
    def delete_role(self, role_id: UUID, deleted_by: Optional[UUID] = None) -> bool:
        """
        Exclui um role (soft delete).
        
        Args:
            role_id: ID do role
            deleted_by: ID do usuário que está excluindo
            
        Returns:
            bool: True se excluído com sucesso
            
        Raises:
            NotFoundError: Se role não existe
            BusinessRuleError: Se não pode ser excluído
        """
        role = self.db.query(Role).filter(Role.id == role_id).first()
        if not role:
            raise NotFoundError(f"Role {role_id} não encontrado")
        
        # Verificar se pode ser excluído
        if role.is_system:
            raise BusinessRuleError("Roles do sistema não podem ser excluídos")
        
        # Verificar se tem usuários atribuídos
        user_count = self._count_users_with_role(role_id)
        if user_count > 0:
            raise BusinessRuleError(f"Role não pode ser excluído pois tem {user_count} usuários atribuídos")
        
        # Verificar se tem roles filhos
        child_roles = self.db.query(Role).filter(Role.parent_role_id == role_id).count()
        if child_roles > 0:
            raise BusinessRuleError(f"Role não pode ser excluído pois tem {child_roles} roles filhos")
        
        try:
            # Soft delete
            role.is_active = False
            role.updated_at = datetime.utcnow()
            role.metadata = role.metadata or {}
            role.metadata["deleted_at"] = datetime.utcnow().isoformat()
            role.metadata["deleted_by"] = str(deleted_by) if deleted_by else None
            
            self.db.commit()
            
            # Limpar cache de permissões
            self._clear_permission_cache()
            
            # Log de auditoria
            self.audit_logger.log_user_action(
                user_id=deleted_by,
                action="role_deleted",
                details={
                    "role_id": str(role.id),
                    "role_name": role.name,
                    "user_count": user_count
                }
            )
            
            return True
            
        except Exception as e:
            self.db.rollback()
            raise BusinessRuleError(f"Erro ao excluir role: {str(e)}")
    
    # ==================== Permission Management ====================
    
    def check_permission(
        self, 
        user_id: UUID, 
        resource_type: ResourceType, 
        permission_type: PermissionType,
        resource_id: Optional[UUID] = None,
        context: Optional[Dict[str, Any]] = None
    ) -> PermissionCheckResult:
        """
        Verifica se um usuário tem uma permissão específica.
        
        Args:
            user_id: ID do usuário
            resource_type: Tipo de recurso
            permission_type: Tipo de permissão
            resource_id: ID específico do recurso (opcional)
            context: Contexto adicional
            
        Returns:
            PermissionCheckResult: Resultado da verificação
        """
        try:
            # Verificar cache primeiro
            cache_key = f"{user_id}:{resource_type}:{permission_type}:{resource_id}"
            cached_result = self._get_cached_permission(cache_key)
            if cached_result:
                return cached_result
            
            # Obter roles do usuário
            user_roles = self._get_user_roles(user_id)
            if not user_roles:
                result = PermissionCheckResult(
                    has_permission=False,
                    granted_by_roles=[],
                    denied_reason="Usuário não possui roles atribuídos"
                )
                self._cache_permission(cache_key, result)
                return result
            
            # Verificar permissões em cada role
            granted_by_roles = []
            for role in user_roles:
                if self._role_has_permission(role, resource_type, permission_type, resource_id):
                    granted_by_roles.append(role.name)
            
            has_permission = len(granted_by_roles) > 0
            denied_reason = None if has_permission else "Permissão não encontrada nos roles do usuário"
            
            # Verificar condições específicas se necessário
            conditions_met = True
            if has_permission and context:
                conditions_met = self._check_permission_conditions(user_roles, context)
            
            result = PermissionCheckResult(
                has_permission=has_permission and conditions_met,
                granted_by_roles=granted_by_roles,
                denied_reason=denied_reason if not conditions_met else None,
                conditions_met=conditions_met,
                metadata={
                    "user_id": str(user_id),
                    "resource_type": resource_type,
                    "permission_type": permission_type,
                    "resource_id": str(resource_id) if resource_id else None,
                    "checked_at": datetime.utcnow().isoformat()
                }
            )
            
            # Cache do resultado
            self._cache_permission(cache_key, result)
            
            return result
            
        except Exception as e:
            return PermissionCheckResult(
                has_permission=False,
                granted_by_roles=[],
                denied_reason=f"Erro ao verificar permissão: {str(e)}"
            )
    
    def get_user_permissions(self, user_id: UUID) -> List[Permission]:
        """
        Obtém todas as permissões de um usuário.
        
        Args:
            user_id: ID do usuário
            
        Returns:
            List[Permission]: Lista de permissões
        """
        user_roles = self._get_user_roles(user_id)
        all_permissions = []
        
        for role in user_roles:
            role_permissions = self._get_role_permissions(role)
            all_permissions.extend(role_permissions)
        
        # Remover duplicatas
        unique_permissions = []
        seen = set()
        for perm in all_permissions:
            perm_key = (perm.resource_type, perm.permission_type, perm.resource_id)
            if perm_key not in seen:
                seen.add(perm_key)
                unique_permissions.append(perm)
        
        return unique_permissions
    
    def add_permission_to_role(
        self, 
        role_id: UUID, 
        permission: Permission,
        added_by: Optional[UUID] = None
    ) -> bool:
        """
        Adiciona uma permissão a um role.
        
        Args:
            role_id: ID do role
            permission: Permissão a ser adicionada
            added_by: ID do usuário que está adicionando
            
        Returns:
            bool: True se adicionado com sucesso
        """
        role = self.db.query(Role).filter(Role.id == role_id).first()
        if not role:
            raise NotFoundError(f"Role {role_id} não encontrado")
        
        try:
            # Obter permissões atuais
            current_permissions = role.permissions or {"permissions": []}
            permissions_list = current_permissions.get("permissions", [])
            
            # Verificar se permissão já existe
            perm_dict = permission.dict()
            if perm_dict not in permissions_list:
                permissions_list.append(perm_dict)
                current_permissions["permissions"] = permissions_list
                role.permissions = current_permissions
                role.updated_at = datetime.utcnow()
                
                self.db.commit()
                
                # Limpar cache
                self._clear_permission_cache()
                
                # Log de auditoria
                self.audit_logger.log_user_action(
                    user_id=added_by,
                    action="permission_added_to_role",
                    details={
                        "role_id": str(role_id),
                        "role_name": role.name,
                        "permission": perm_dict
                    }
                )
                
                return True
            
            return False  # Permissão já existe
            
        except Exception as e:
            self.db.rollback()
            raise BusinessRuleError(f"Erro ao adicionar permissão: {str(e)}")
    
    def remove_permission_from_role(
        self, 
        role_id: UUID, 
        permission: Permission,
        removed_by: Optional[UUID] = None
    ) -> bool:
        """
        Remove uma permissão de um role.
        
        Args:
            role_id: ID do role
            permission: Permissão a ser removida
            removed_by: ID do usuário que está removendo
            
        Returns:
            bool: True se removido com sucesso
        """
        role = self.db.query(Role).filter(Role.id == role_id).first()
        if not role:
            raise NotFoundError(f"Role {role_id} não encontrado")
        
        try:
            # Obter permissões atuais
            current_permissions = role.permissions or {"permissions": []}
            permissions_list = current_permissions.get("permissions", [])
            
            # Remover permissão
            perm_dict = permission.dict()
            if perm_dict in permissions_list:
                permissions_list.remove(perm_dict)
                current_permissions["permissions"] = permissions_list
                role.permissions = current_permissions
                role.updated_at = datetime.utcnow()
                
                self.db.commit()
                
                # Limpar cache
                self._clear_permission_cache()
                
                # Log de auditoria
                self.audit_logger.log_user_action(
                    user_id=removed_by,
                    action="permission_removed_from_role",
                    details={
                        "role_id": str(role_id),
                        "role_name": role.name,
                        "permission": perm_dict
                    }
                )
                
                return True
            
            return False  # Permissão não encontrada
            
        except Exception as e:
            self.db.rollback()
            raise BusinessRuleError(f"Erro ao remover permissão: {str(e)}")
    
    # ==================== Role Hierarchy ====================
    
    def get_role_hierarchy(self, role_id: Optional[UUID] = None) -> List[RoleHierarchy]:
        """
        Obtém a hierarquia de roles.
        
        Args:
            role_id: ID do role raiz (opcional, se None retorna toda hierarquia)
            
        Returns:
            List[RoleHierarchy]: Hierarquia de roles
        """
        if role_id:
            # Hierarquia específica de um role
            role = self.db.query(Role).filter(Role.id == role_id).first()
            if not role:
                return []
            
            return [self._build_role_hierarchy(role)]
        else:
            # Toda a hierarquia (roles raiz)
            root_roles = self.db.query(Role).filter(
                and_(Role.parent_role_id.is_(None), Role.is_active == True)
            ).all()
            
            return [self._build_role_hierarchy(role) for role in root_roles]
    
    def get_role_ancestors(self, role_id: UUID) -> List[RoleSummary]:
        """
        Obtém todos os ancestrais de um role.
        
        Args:
            role_id: ID do role
            
        Returns:
            List[RoleSummary]: Lista de ancestrais
        """
        ancestors = []
        current_role = self.db.query(Role).filter(Role.id == role_id).first()
        
        while current_role and current_role.parent_role_id:
            parent = self.db.query(Role).filter(Role.id == current_role.parent_role_id).first()
            if parent:
                ancestors.append(self._to_role_summary(parent))
                current_role = parent
            else:
                break
        
        return ancestors
    
    def get_role_descendants(self, role_id: UUID) -> List[RoleSummary]:
        """
        Obtém todos os descendentes de um role.
        
        Args:
            role_id: ID do role
            
        Returns:
            List[RoleSummary]: Lista de descendentes
        """
        descendants = []
        
        def collect_children(parent_id: UUID):
            children = self.db.query(Role).filter(Role.parent_role_id == parent_id).all()
            for child in children:
                descendants.append(self._to_role_summary(child))
                collect_children(child.id)
        
        collect_children(role_id)
        return descendants
    
    # ==================== Search and Query ====================
    
    def search_roles(
        self, 
        params: RoleQueryParams,
        skip: int = 0,
        limit: int = 100
    ) -> Tuple[List[RoleSummary], int]:
        """
        Busca roles com filtros avançados.
        
        Args:
            params: Parâmetros de busca
            skip: Número de registros para pular
            limit: Limite de registros
            
        Returns:
            Tuple[List[RoleSummary], int]: Lista de roles e total
        """
        query = self.db.query(Role)
        
        # Aplicar filtros
        if params.name:
            query = query.filter(Role.name.ilike(f"%{params.name}%"))
        
        if params.role_type:
            query = query.filter(Role.role_type == params.role_type)
        
        if params.scope:
            query = query.filter(Role.scope == params.scope)
        
        if params.is_active is not None:
            query = query.filter(Role.is_active == params.is_active)
        
        if params.is_system is not None:
            query = query.filter(Role.is_system == params.is_system)
        
        if params.parent_role_id:
            query = query.filter(Role.parent_role_id == params.parent_role_id)
        
        if params.organization_id:
            query = query.filter(Role.organization_id == params.organization_id)
        
        if params.department_id:
            query = query.filter(Role.department_id == params.department_id)
        
        if params.project_id:
            query = query.filter(Role.project_id == params.project_id)
        
        if params.created_after:
            query = query.filter(Role.created_at >= params.created_after)
        
        if params.created_before:
            query = query.filter(Role.created_at <= params.created_before)
        
        if params.search:
            search_term = f"%{params.search}%"
            query = query.filter(
                or_(
                    Role.name.ilike(search_term),
                    Role.display_name.ilike(search_term),
                    Role.description.ilike(search_term)
                )
            )
        
        # Filtros especiais
        if params.has_users is not None:
            if params.has_users:
                # Roles com usuários (implementar join com user_roles)
                pass
            else:
                # Roles sem usuários
                pass
        
        if params.resource_type:
            # Filtrar por tipo de recurso nas permissões
            query = query.filter(
                Role.permissions["permissions"].astext.contains(f'"resource_type": "{params.resource_type}"')
            )
        
        if params.permission_type:
            # Filtrar por tipo de permissão
            query = query.filter(
                Role.permissions["permissions"].astext.contains(f'"permission_type": "{params.permission_type}"')
            )
        
        # Contar total
        total = query.count()
        
        # Aplicar ordenação
        if params.sort_by == "name":
            order_field = Role.name
        elif params.sort_by == "display_name":
            order_field = Role.display_name
        elif params.sort_by == "role_type":
            order_field = Role.role_type
        else:
            order_field = Role.created_at
        
        if params.sort_order == "desc":
            query = query.order_by(desc(order_field))
        else:
            query = query.order_by(asc(order_field))
        
        # Aplicar paginação
        roles = query.offset(skip).limit(limit).all()
        
        # Converter para RoleSummary
        role_summaries = [self._to_role_summary(role) for role in roles]
        
        return role_summaries, total
    
    def get_role_stats(self) -> RoleStats:
        """
        Obtém estatísticas de roles.
        
        Returns:
            RoleStats: Estatísticas dos roles
        """
        # Contadores básicos
        total_roles = self.db.query(Role).count()
        active_roles = self.db.query(Role).filter(Role.is_active == True).count()
        inactive_roles = total_roles - active_roles
        system_roles = self.db.query(Role).filter(Role.is_system == True).count()
        custom_roles = total_roles - system_roles
        
        # Por tipo
        roles_by_type = {}
        for role_type in RoleType:
            count = self.db.query(Role).filter(Role.role_type == role_type).count()
            roles_by_type[role_type.value] = count
        
        # Por escopo
        roles_by_scope = {}
        for scope in RoleScope:
            count = self.db.query(Role).filter(Role.scope == scope).count()
            roles_by_scope[scope.value] = count
        
        # Roles com/sem usuários
        roles_with_users = 0  # Implementar contagem
        roles_without_users = total_roles - roles_with_users
        
        # Roles mais utilizados
        most_used_roles = self.db.query(Role).filter(Role.is_active == True).limit(10).all()
        
        # Roles criados recentemente
        recently_created_roles = self.db.query(Role).order_by(desc(Role.created_at)).limit(10).all()
        
        # Distribuição de permissões
        permission_distribution = self._calculate_permission_distribution()
        
        # Cobertura por tipo de recurso
        resource_coverage = self._calculate_resource_coverage()
        
        return RoleStats(
            total_roles=total_roles,
            active_roles=active_roles,
            inactive_roles=inactive_roles,
            system_roles=system_roles,
            custom_roles=custom_roles,
            roles_by_type=roles_by_type,
            roles_by_scope=roles_by_scope,
            roles_with_users=roles_with_users,
            roles_without_users=roles_without_users,
            most_used_roles=[self._to_role_summary(r) for r in most_used_roles],
            recently_created_roles=[self._to_role_summary(r) for r in recently_created_roles],
            permission_distribution=permission_distribution,
            resource_coverage=resource_coverage
        )
    
    # ==================== Bulk Operations ====================
    
    def bulk_operation(
        self, 
        operation: RoleBulkOperation,
        performed_by: Optional[UUID] = None
    ) -> RoleBulkResult:
        """
        Executa operação em lote nos roles.
        
        Args:
            operation: Operação a ser executada
            performed_by: ID do usuário que está executando
            
        Returns:
            RoleBulkResult: Resultado da operação
        """
        results = []
        errors = []
        successful = 0
        failed = 0
        
        for role_id in operation.role_ids:
            try:
                if operation.operation == "activate":
                    self._bulk_activate_role(role_id, performed_by)
                elif operation.operation == "deactivate":
                    self._bulk_deactivate_role(role_id, performed_by)
                elif operation.operation == "delete":
                    self._bulk_delete_role(role_id, performed_by)
                elif operation.operation == "clone":
                    self._bulk_clone_role(role_id, performed_by, operation.parameters)
                else:
                    raise ValueError(f"Operação não suportada: {operation.operation}")
                
                results.append({"role_id": str(role_id), "status": "success"})
                successful += 1
                
            except Exception as e:
                error_detail = {
                    "role_id": str(role_id),
                    "error": str(e),
                    "status": "failed"
                }
                errors.append(error_detail)
                results.append(error_detail)
                failed += 1
        
        # Log de auditoria
        self.audit_logger.log_user_action(
            user_id=performed_by,
            action=f"bulk_{operation.operation}_roles",
            details={
                "total_roles": len(operation.role_ids),
                "successful": successful,
                "failed": failed,
                "reason": operation.reason
            }
        )
        
        return RoleBulkResult(
            total_requested=len(operation.role_ids),
            successful=successful,
            failed=failed,
            errors=errors,
            results=results
        )
    
    # ==================== Helper Methods ====================
    
    def _validate_role_name_uniqueness(self, name: str) -> None:
        """Valida se nome do role é único."""
        existing = self.db.query(Role).filter(Role.name == name.upper()).first()
        if existing:
            raise ConflictError(f"Role com nome {name} já existe")
    
    def _validate_role_hierarchy(self, parent_role_id: UUID) -> None:
        """Valida hierarquia de roles."""
        parent = self.db.query(Role).filter(Role.id == parent_role_id).first()
        if not parent:
            raise ValidationError(f"Role pai {parent_role_id} não encontrado")
        
        if not parent.is_active:
            raise ValidationError("Role pai deve estar ativo")
    
    def _get_user_roles(self, user_id: UUID) -> List[Role]:
        """Obtém roles de um usuário."""
        # Implementar join com user_roles
        # Por enquanto retorna lista vazia
        return []
    
    def _role_has_permission(
        self, 
        role: Role, 
        resource_type: ResourceType, 
        permission_type: PermissionType,
        resource_id: Optional[UUID] = None
    ) -> bool:
        """Verifica se role tem permissão específica."""
        if not role.permissions:
            return False
        
        permissions = role.permissions.get("permissions", [])
        for perm in permissions:
            if (perm.get("resource_type") == resource_type and 
                perm.get("permission_type") == permission_type and
                (perm.get("resource_id") is None or perm.get("resource_id") == str(resource_id))):
                return True
        
        # Verificar permissões herdadas
        inherited_permissions = role.permissions.get("inherited_permissions", [])
        for perm in inherited_permissions:
            if (perm.get("resource_type") == resource_type and 
                perm.get("permission_type") == permission_type and
                (perm.get("resource_id") is None or perm.get("resource_id") == str(resource_id))):
                return True
        
        return False
    
    def _get_role_permissions(self, role: Role) -> List[Permission]:
        """Obtém todas as permissões de um role."""
        permissions = []
        
        if role.permissions:
            # Permissões diretas
            for perm_dict in role.permissions.get("permissions", []):
                permissions.append(Permission(**perm_dict))
            
            # Permissões herdadas
            for perm_dict in role.permissions.get("inherited_permissions", []):
                permissions.append(Permission(**perm_dict))
        
        return permissions
    
    def _check_permission_conditions(self, roles: List[Role], context: Dict[str, Any]) -> bool:
        """Verifica condições específicas das permissões."""
        # Implementar verificação de condições
        return True
    
    def _build_role_hierarchy(self, role: Role, depth: int = 0) -> RoleHierarchy:
        """Constrói hierarquia de um role."""
        # Obter filhos
        children = self.db.query(Role).filter(Role.parent_role_id == role.id).all()
        child_hierarchies = [self._build_role_hierarchy(child, depth + 1) for child in children]
        
        return RoleHierarchy(
            role=self._to_role_summary(role),
            parent=None,  # Será definido pelo chamador
            children=child_hierarchies,
            depth=depth
        )
    
    def _count_users_with_role(self, role_id: UUID) -> int:
        """Conta usuários com um role específico."""
        # Implementar contagem via user_roles
        return 0
    
    def _calculate_permission_distribution(self) -> Dict[str, int]:
        """Calcula distribuição de permissões."""
        distribution = {}
        
        roles = self.db.query(Role).filter(Role.is_active == True).all()
        for role in roles:
            if role.permissions:
                permissions = role.permissions.get("permissions", [])
                for perm in permissions:
                    perm_type = perm.get("permission_type", "unknown")
                    distribution[perm_type] = distribution.get(perm_type, 0) + 1
        
        return distribution
    
    def _calculate_resource_coverage(self) -> Dict[str, int]:
        """Calcula cobertura por tipo de recurso."""
        coverage = {}
        
        roles = self.db.query(Role).filter(Role.is_active == True).all()
        for role in roles:
            if role.permissions:
                permissions = role.permissions.get("permissions", [])
                for perm in permissions:
                    resource_type = perm.get("resource_type", "unknown")
                    coverage[resource_type] = coverage.get(resource_type, 0) + 1
        
        return coverage
    
    def _to_role_read(self, role: Role) -> RoleRead:
        """Converte Role model para RoleRead schema."""
        user_count = self._count_users_with_role(role.id)
        
        return RoleRead(
            id=role.id,
            name=role.name,
            display_name=role.display_name,
            description=role.description,
            role_type=role.role_type,
            scope=role.scope,
            is_active=role.is_active,
            is_system=role.is_system,
            parent_role_id=role.parent_role_id,
            organization_id=role.organization_id,
            department_id=role.department_id,
            project_id=role.project_id,
            permissions=role.permissions,
            user_count=user_count,
            metadata=role.metadata,
            created_at=role.created_at,
            updated_at=role.updated_at
        )
    
    def _to_role_summary(self, role: Role) -> RoleSummary:
        """Converte Role model para RoleSummary schema."""
        user_count = self._count_users_with_role(role.id)
        permission_count = 0
        
        if role.permissions:
            permissions = role.permissions.get("permissions", [])
            inherited = role.permissions.get("inherited_permissions", [])
            permission_count = len(permissions) + len(inherited)
        
        return RoleSummary(
            id=role.id,
            name=role.name,
            display_name=role.display_name,
            role_type=role.role_type,
            scope=role.scope,
            is_active=role.is_active,
            user_count=user_count,
            permission_count=permission_count,
            created_at=role.created_at
        )
    
    # Cache methods
    def _get_cached_permission(self, cache_key: str) -> Optional[PermissionCheckResult]:
        """Obtém resultado do cache."""
        # Implementar cache Redis ou em memória
        return None
    
    def _cache_permission(self, cache_key: str, result: PermissionCheckResult) -> None:
        """Armazena resultado no cache."""
        # Implementar cache Redis ou em memória
        pass
    
    def _clear_permission_cache(self) -> None:
        """Limpa cache de permissões."""
        self._permission_cache.clear()
    
    # Métodos auxiliares
    def _is_system_admin(self, user_id: Optional[UUID]) -> bool:
        """Verifica se usuário é admin do sistema."""
        # Implementar verificação
        return True  # Placeholder
    
    def _copy_permissions_from_role(self, target_role_id: UUID, source_role_id: UUID) -> None:
        """Copia permissões de um role para outro."""
        source_role = self.db.query(Role).filter(Role.id == source_role_id).first()
        target_role = self.db.query(Role).filter(Role.id == target_role_id).first()
        
        if source_role and target_role and source_role.permissions:
            target_role.permissions = source_role.permissions.copy()
            self.db.commit()
    
    def _assign_role_to_users(self, role_id: UUID, user_ids: List[UUID], assigned_by: Optional[UUID]) -> None:
        """Atribui role a usuários."""
        # Implementar atribuição via user_roles
        pass
    
    # Métodos para operações em lote
    def _bulk_activate_role(self, role_id: UUID, performed_by: Optional[UUID]) -> None:
        """Ativa role em operação em lote."""
        role = self.db.query(Role).filter(Role.id == role_id).first()
        if role:
            role.is_active = True
            role.updated_at = datetime.utcnow()
            self.db.commit()
    
    def _bulk_deactivate_role(self, role_id: UUID, performed_by: Optional[UUID]) -> None:
        """Desativa role em operação em lote."""
        role = self.db.query(Role).filter(Role.id == role_id).first()
        if role and not role.is_system:
            role.is_active = False
            role.updated_at = datetime.utcnow()
            self.db.commit()
    
    def _bulk_delete_role(self, role_id: UUID, performed_by: Optional[UUID]) -> None:
        """Exclui role em operação em lote."""
        self.delete_role(role_id, performed_by)
    
    def _bulk_clone_role(self, role_id: UUID, performed_by: Optional[UUID], parameters: Optional[Dict[str, Any]]) -> None:
        """Clona role em operação em lote."""
        source_role = self.db.query(Role).filter(Role.id == role_id).first()
        if source_role:
            new_name = parameters.get("new_name", f"{source_role.name}_COPY")
            
            cloned_role = Role(
                id=uuid.uuid4(),
                name=new_name,
                display_name=f"{source_role.display_name} (Cópia)",
                description=source_role.description,
                role_type=RoleType.CUSTOM,
                scope=source_role.scope,
                is_active=True,
                is_system=False,
                permissions=source_role.permissions.copy() if source_role.permissions else None,
                metadata={"cloned_from": str(role_id)},
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow()
            )
            
            self.db.add(cloned_role)
            self.db.commit()

