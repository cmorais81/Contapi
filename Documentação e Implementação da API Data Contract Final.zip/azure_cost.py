"""
Azure Cost Management Models
Modelos para integração com Azure Cost Management
"""

from sqlalchemy import Column, String, Text, DateTime, Boolean, Integer, DECIMAL, JSON, Date
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from sqlalchemy import ForeignKey

from app.models.base import Base, GUID


class AzureCostData(Base):
    """Modelo para dados de custo do Azure"""
    __tablename__ = "azure_cost_data"

    id = Column(GUID(), primary_key=True, default=func.gen_random_uuid())
    entity_id = Column(GUID(), ForeignKey('entities.id'))
    azure_subscription_id = Column(String(255), nullable=False)
    azure_resource_group = Column(String(255))
    azure_resource_name = Column(String(255))
    azure_resource_type = Column(String(100))  # Storage Account, SQL Database, Synapse
    azure_service_name = Column(String(100))
    cost_date = Column(Date, nullable=False)
    cost_amount = Column(DECIMAL(15, 4), nullable=False)
    cost_currency = Column(String(3), default='USD')
    usage_quantity = Column(DECIMAL(15, 4))
    usage_unit = Column(String(50))
    meter_category = Column(String(100))
    meter_subcategory = Column(String(100))
    meter_name = Column(String(255))
    billing_period = Column(String(20))
    cost_center = Column(String(100))
    department = Column(String(100))
    tags = Column(JSON)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    # Relacionamentos
    entity = relationship("Entity", back_populates="azure_costs")

    def __repr__(self):
        return f"<AzureCostData(resource='{self.azure_resource_name}', cost={self.cost_amount})>"


class DataricksCostData(Base):
    """Modelo para dados de custo do Databricks"""
    __tablename__ = "databricks_cost_data"

    id = Column(GUID(), primary_key=True, default=func.gen_random_uuid())
    entity_id = Column(GUID(), ForeignKey('entities.id'))
    databricks_workspace_id = Column(String(255), nullable=False)
    databricks_cluster_id = Column(String(255))
    databricks_cluster_name = Column(String(255))
    databricks_job_id = Column(String(255))
    databricks_job_name = Column(String(255))
    usage_date = Column(Date, nullable=False)
    dbu_consumed = Column(DECIMAL(15, 4), nullable=False)
    dbu_cost = Column(DECIMAL(15, 4), nullable=False)
    compute_cost = Column(DECIMAL(15, 4))
    storage_cost = Column(DECIMAL(15, 4))
    total_cost = Column(DECIMAL(15, 4), nullable=False)
    cost_currency = Column(String(3), default='USD')
    cluster_type = Column(String(50))  # all_purpose, job, sql_warehouse
    node_type = Column(String(100))
    driver_node_type = Column(String(100))
    num_workers = Column(Integer)
    runtime_version = Column(String(50))
    usage_hours = Column(DECIMAL(10, 4))
    billing_period = Column(String(20))
    tags = Column(JSON)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    # Relacionamentos
    entity = relationship("Entity", back_populates="databricks_costs")

    def __repr__(self):
        return f"<DataricksCostData(cluster='{self.databricks_cluster_name}', cost={self.total_cost})>"


class CostOptimizationRecommendation(Base):
    """Modelo para recomendações de otimização de custos"""
    __tablename__ = "cost_optimization_recommendations"

    id = Column(GUID(), primary_key=True, default=func.gen_random_uuid())
    entity_id = Column(GUID(), ForeignKey('entities.id'))
    recommendation_type = Column(String(100), nullable=False)  # storage_optimization, compute_optimization
    recommendation_title = Column(String(255), nullable=False)
    recommendation_description = Column(Text, nullable=False)
    current_cost_monthly = Column(DECIMAL(15, 4))
    projected_cost_monthly = Column(DECIMAL(15, 4))
    potential_savings_monthly = Column(DECIMAL(15, 4))
    potential_savings_annual = Column(DECIMAL(15, 4))
    confidence_score = Column(DECIMAL(3, 2), default=0.8)
    implementation_effort = Column(String(50))  # low, medium, high
    implementation_timeline = Column(String(50))  # immediate, 1_week, 1_month, 3_months
    risk_level = Column(String(50), default='low')  # low, medium, high
    business_impact = Column(Text)
    technical_requirements = Column(Text)
    recommendation_status = Column(String(50), default='open')  # open, in_progress, implemented, rejected
    assigned_to = Column(GUID(), ForeignKey('users.id'))
    implementation_date = Column(Date)
    actual_savings_monthly = Column(DECIMAL(15, 4))
    recommendation_metadata = Column(JSON)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    created_by = Column(GUID(), ForeignKey('users.id'))
    updated_by = Column(GUID(), ForeignKey('users.id'))

    # Relacionamentos
    entity = relationship("Entity", back_populates="cost_recommendations")
    assigned_user = relationship("User", foreign_keys=[assigned_to])
    creator = relationship("User", foreign_keys=[created_by])
    updater = relationship("User", foreign_keys=[updated_by])

    def __repr__(self):
        return f"<CostOptimizationRecommendation(title='{self.recommendation_title}', savings={self.potential_savings_monthly})>"

