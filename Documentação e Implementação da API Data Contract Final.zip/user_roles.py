"""
User Role Endpoints

Endpoints para gerenciamento de atribuições usuário-role.

Author: Carlos Morais <carlos.morais@f1rst.com.br>
Date: Julho 2025
"""

from typing import List, Optional
from uuid import UUID
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.exceptions import NotFoundError, ConflictError, ValidationError, BusinessRuleError
from app.schemas.users.user_role import (
    UserRoleCreate, 
    UserRoleUpdate, 
    UserRoleRead, 
    UserRoleSummary,
    UserRoleQueryParams,
    UserRoleStats,
    UserRoleAssignment,
    UserRoleBulkOperation,
    UserRoleBulkResult,
    UserRoleRecommendation,
    UserRoleConflict,
    AssignmentType,
    AssignmentStatus
)
from app.services.users.user_role_service import UserRoleService

router = APIRouter()

# ==================== CRUD Operations ====================

@router.post("/", response_model=UserRoleRead, status_code=status.HTTP_201_CREATED)
def assign_role_to_user(
    assignment_data: UserRoleCreate,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Atribui um role a um usuário.
    
    Args:
        assignment_data: Dados da atribuição
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        UserRoleRead: Atribuição criada
        
    Raises:
        HTTPException: Se dados são inválidos ou atribuição já existe
    """
    try:
        user_role_service = UserRoleService(db)
        assignment = user_role_service.assign_role_to_user(assignment_data, current_user_id)
        return assignment
    except ConflictError as e:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(e))
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(e))
    except BusinessRuleError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

@router.get("/{assignment_id}", response_model=UserRoleRead)
def get_user_role_assignment(
    assignment_id: UUID,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Obtém uma atribuição por ID.
    
    Args:
        assignment_id: ID da atribuição
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        UserRoleRead: Atribuição encontrada
        
    Raises:
        HTTPException: Se atribuição não encontrada
    """
    try:
        user_role_service = UserRoleService(db)
        assignment = user_role_service.get_user_role(assignment_id)
        if not assignment:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Atribuição não encontrada")
        return assignment
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

@router.put("/{assignment_id}", response_model=UserRoleRead)
def update_user_role_assignment(
    assignment_id: UUID,
    assignment_data: UserRoleUpdate,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Atualiza uma atribuição existente.
    
    Args:
        assignment_id: ID da atribuição
        assignment_data: Dados para atualização
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        UserRoleRead: Atribuição atualizada
        
    Raises:
        HTTPException: Se atribuição não encontrada ou dados inválidos
    """
    try:
        user_role_service = UserRoleService(db)
        assignment = user_role_service.update_user_role(assignment_id, assignment_data, current_user_id)
        return assignment
    except NotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(e))
    except BusinessRuleError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

@router.delete("/{assignment_id}", status_code=status.HTTP_204_NO_CONTENT)
def revoke_user_role_assignment(
    assignment_id: UUID,
    reason: Optional[str] = Query(None, description="Motivo da revogação"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Revoga uma atribuição de role.
    
    Args:
        assignment_id: ID da atribuição
        reason: Motivo da revogação
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Raises:
        HTTPException: Se atribuição não encontrada
    """
    try:
        user_role_service = UserRoleService(db)
        success = user_role_service.revoke_user_role(assignment_id, current_user_id, reason)
        if not success:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Atribuição não encontrada")
    except NotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except BusinessRuleError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

# ==================== Search and Query ====================

@router.get("/", response_model=List[UserRoleSummary])
def search_user_role_assignments(
    skip: int = Query(0, ge=0, description="Número de registros para pular"),
    limit: int = Query(100, ge=1, le=1000, description="Limite de registros"),
    user_id: Optional[UUID] = Query(None, description="Filtrar por usuário"),
    role_id: Optional[UUID] = Query(None, description="Filtrar por role"),
    assignment_type: Optional[AssignmentType] = Query(None, description="Filtrar por tipo de atribuição"),
    status: Optional[AssignmentStatus] = Query(None, description="Filtrar por status"),
    assigned_by: Optional[UUID] = Query(None, description="Filtrar por quem atribuiu"),
    assigned_after: Optional[str] = Query(None, description="Filtrar por data de atribuição (após)"),
    assigned_before: Optional[str] = Query(None, description="Filtrar por data de atribuição (antes)"),
    expires_after: Optional[str] = Query(None, description="Filtrar por data de expiração (após)"),
    expires_before: Optional[str] = Query(None, description="Filtrar por data de expiração (antes)"),
    is_expired: Optional[bool] = Query(None, description="Filtrar por atribuições expiradas"),
    is_expiring_soon: Optional[bool] = Query(None, description="Filtrar por atribuições expirando em breve"),
    sort_by: Optional[str] = Query("assigned_at", description="Campo para ordenação"),
    sort_order: Optional[str] = Query("desc", regex="^(asc|desc)$", description="Ordem de classificação"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Busca atribuições com filtros avançados.
    
    Args:
        skip: Número de registros para pular
        limit: Limite de registros
        user_id: Filtrar por usuário
        role_id: Filtrar por role
        assignment_type: Filtrar por tipo de atribuição
        status: Filtrar por status
        assigned_by: Filtrar por quem atribuiu
        assigned_after: Filtrar por data de atribuição (após)
        assigned_before: Filtrar por data de atribuição (antes)
        expires_after: Filtrar por data de expiração (após)
        expires_before: Filtrar por data de expiração (antes)
        is_expired: Filtrar por atribuições expiradas
        is_expiring_soon: Filtrar por atribuições expirando em breve
        sort_by: Campo para ordenação
        sort_order: Ordem de classificação
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        List[UserRoleSummary]: Lista de atribuições
    """
    try:
        user_role_service = UserRoleService(db)
        
        # Converter datas se fornecidas
        assigned_after_dt = datetime.fromisoformat(assigned_after) if assigned_after else None
        assigned_before_dt = datetime.fromisoformat(assigned_before) if assigned_before else None
        expires_after_dt = datetime.fromisoformat(expires_after) if expires_after else None
        expires_before_dt = datetime.fromisoformat(expires_before) if expires_before else None
        
        # Construir parâmetros de busca
        params = UserRoleQueryParams(
            user_id=user_id,
            role_id=role_id,
            assignment_type=assignment_type,
            status=status,
            assigned_by=assigned_by,
            assigned_after=assigned_after_dt,
            assigned_before=assigned_before_dt,
            expires_after=expires_after_dt,
            expires_before=expires_before_dt,
            is_expired=is_expired,
            is_expiring_soon=is_expiring_soon,
            sort_by=sort_by,
            sort_order=sort_order
        )
        
        assignments, total = user_role_service.search_user_roles(params, skip, limit)
        
        return assignments
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=f"Formato de data inválido: {str(e)}")
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

@router.get("/stats", response_model=UserRoleStats)
def get_user_role_stats(
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Obtém estatísticas de atribuições.
    
    Args:
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        UserRoleStats: Estatísticas das atribuições
    """
    try:
        user_role_service = UserRoleService(db)
        stats = user_role_service.get_user_role_stats()
        return stats
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

# ==================== User Role Management ====================

@router.get("/users/{user_id}/roles", response_model=List[UserRoleRead])
def get_user_roles(
    user_id: UUID,
    include_expired: bool = Query(False, description="Incluir roles expirados"),
    include_revoked: bool = Query(False, description="Incluir roles revogados"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Obtém todos os roles de um usuário.
    
    Args:
        user_id: ID do usuário
        include_expired: Incluir roles expirados
        include_revoked: Incluir roles revogados
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        List[UserRoleRead]: Lista de atribuições
    """
    try:
        user_role_service = UserRoleService(db)
        user_roles = user_role_service.get_user_roles(user_id, include_expired, include_revoked)
        return user_roles
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

@router.get("/roles/{role_id}/users", response_model=List[UserRoleRead])
def get_role_users(
    role_id: UUID,
    include_expired: bool = Query(False, description="Incluir atribuições expiradas"),
    include_revoked: bool = Query(False, description="Incluir atribuições revogadas"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Obtém todos os usuários de um role.
    
    Args:
        role_id: ID do role
        include_expired: Incluir atribuições expiradas
        include_revoked: Incluir atribuições revogadas
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        List[UserRoleRead]: Lista de atribuições
    """
    try:
        user_role_service = UserRoleService(db)
        role_users = user_role_service.get_role_users(role_id, include_expired, include_revoked)
        return role_users
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

# ==================== Expiration Management ====================

@router.get("/expiring", response_model=List[UserRoleRead])
def get_expiring_assignments(
    days_ahead: int = Query(7, ge=1, le=365, description="Número de dias para verificar"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Obtém atribuições que expiram em breve.
    
    Args:
        days_ahead: Número de dias para verificar
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        List[UserRoleRead]: Lista de atribuições expirando
    """
    try:
        user_role_service = UserRoleService(db)
        expiring_assignments = user_role_service.get_expiring_assignments(days_ahead)
        return expiring_assignments
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

@router.post("/{assignment_id}/renew", response_model=UserRoleRead)
def renew_assignment(
    assignment_id: UUID,
    new_expiry_date: str,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Renova uma atribuição de role.
    
    Args:
        assignment_id: ID da atribuição
        new_expiry_date: Nova data de expiração (ISO format)
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        UserRoleRead: Atribuição renovada
    """
    try:
        user_role_service = UserRoleService(db)
        
        # Converter data
        new_expiry_datetime = datetime.fromisoformat(new_expiry_date)
        
        assignment = user_role_service.renew_assignment(assignment_id, new_expiry_datetime, current_user_id)
        return assignment
    except NotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=f"Formato de data inválido: {str(e)}")
    except BusinessRuleError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

# ==================== Conflict Detection ====================

@router.post("/check-conflicts", response_model=List[UserRoleConflict])
def check_role_conflicts(
    user_id: UUID,
    role_id: UUID,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Verifica conflitos ao atribuir um role a um usuário.
    
    Args:
        user_id: ID do usuário
        role_id: ID do role
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        List[UserRoleConflict]: Lista de conflitos encontrados
    """
    try:
        user_role_service = UserRoleService(db)
        conflicts = user_role_service.check_role_conflicts(user_id, role_id)
        return conflicts
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

@router.get("/users/{user_id}/conflicts", response_model=List[UserRoleConflict])
def get_user_role_conflicts(
    user_id: UUID,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Obtém todos os conflitos de roles de um usuário.
    
    Args:
        user_id: ID do usuário
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        List[UserRoleConflict]: Lista de conflitos
    """
    try:
        user_role_service = UserRoleService(db)
        conflicts = user_role_service.get_user_role_conflicts(user_id)
        return conflicts
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

# ==================== Recommendations ====================

@router.get("/users/{user_id}/recommendations", response_model=List[UserRoleRecommendation])
def get_role_recommendations(
    user_id: UUID,
    limit: int = Query(10, ge=1, le=50, description="Limite de recomendações"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Obtém recomendações de roles para um usuário.
    
    Args:
        user_id: ID do usuário
        limit: Limite de recomendações
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        List[UserRoleRecommendation]: Lista de recomendações
    """
    try:
        user_role_service = UserRoleService(db)
        recommendations = user_role_service.get_role_recommendations(user_id, limit)
        return recommendations
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

# ==================== Bulk Operations ====================

@router.post("/bulk", response_model=UserRoleBulkResult)
def bulk_user_role_operation(
    operation: UserRoleBulkOperation,
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Executa operação em lote nas atribuições.
    
    Args:
        operation: Operação a ser executada
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        UserRoleBulkResult: Resultado da operação
    """
    try:
        user_role_service = UserRoleService(db)
        result = user_role_service.bulk_operation(operation, current_user_id)
        return result
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(e))
    except BusinessRuleError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

# ==================== Assignment Templates ====================

@router.get("/templates", response_model=List[UserRoleAssignment])
def get_assignment_templates(
    user_type: Optional[str] = Query(None, description="Filtrar por tipo de usuário"),
    department: Optional[str] = Query(None, description="Filtrar por departamento"),
    role_type: Optional[str] = Query(None, description="Filtrar por tipo de role"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Obtém templates de atribuições disponíveis.
    
    Args:
        user_type: Filtrar por tipo de usuário
        department: Filtrar por departamento
        role_type: Filtrar por tipo de role
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        List[UserRoleAssignment]: Lista de templates
    """
    try:
        # Implementar lógica de templates
        # Por enquanto, retornar lista vazia
        return []
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

# ==================== Assignment Validation ====================

@router.post("/{assignment_id}/validate", response_model=dict)
def validate_assignment(
    assignment_id: UUID,
    validation_type: str = Query(..., description="Tipo de validação (expiration, conflicts, permissions)"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Valida uma atribuição específica.
    
    Args:
        assignment_id: ID da atribuição
        validation_type: Tipo de validação
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        dict: Resultado da validação
    """
    try:
        user_role_service = UserRoleService(db)
        
        # Obter atribuição
        assignment = user_role_service.get_user_role(assignment_id)
        if not assignment:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Atribuição não encontrada")
        
        # Executar validação baseada no tipo
        if validation_type == "expiration":
            result = {
                "is_valid": True,
                "is_expired": assignment.expires_at and assignment.expires_at < datetime.utcnow(),
                "expires_at": assignment.expires_at.isoformat() if assignment.expires_at else None,
                "days_until_expiry": None
            }
            if assignment.expires_at:
                days_until = (assignment.expires_at - datetime.utcnow()).days
                result["days_until_expiry"] = days_until
                result["is_expiring_soon"] = days_until <= 7
        elif validation_type == "conflicts":
            conflicts = user_role_service.check_role_conflicts(assignment.user_id, assignment.role_id)
            result = {
                "is_valid": len(conflicts) == 0,
                "conflicts": [{"type": c.conflict_type, "description": c.description} for c in conflicts]
            }
        elif validation_type == "permissions":
            # Implementar validação de permissões
            result = {
                "is_valid": True,
                "permissions_valid": True,
                "issues": []
            }
        else:
            raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Tipo de validação inválido")
        
        return result
    except NotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

# ==================== Assignment History ====================

@router.get("/{assignment_id}/history", response_model=List[dict])
def get_assignment_history(
    assignment_id: UUID,
    skip: int = Query(0, ge=0, description="Número de registros para pular"),
    limit: int = Query(100, ge=1, le=1000, description="Limite de registros"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Obtém histórico de uma atribuição.
    
    Args:
        assignment_id: ID da atribuição
        skip: Número de registros para pular
        limit: Limite de registros
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        List[dict]: Lista de eventos do histórico
    """
    try:
        # Implementar busca no audit log
        # Por enquanto, retornar lista vazia
        return []
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

# ==================== Assignment Export ====================

@router.get("/export", response_model=dict)
def export_assignments(
    format: str = Query("json", regex="^(json|csv|xml)$", description="Formato de exportação"),
    user_id: Optional[UUID] = Query(None, description="Filtrar por usuário"),
    role_id: Optional[UUID] = Query(None, description="Filtrar por role"),
    include_expired: bool = Query(False, description="Incluir atribuições expiradas"),
    include_revoked: bool = Query(False, description="Incluir atribuições revogadas"),
    db: Session = Depends(get_db),
    current_user_id: Optional[UUID] = None
):
    """
    Exporta atribuições com filtros.
    
    Args:
        format: Formato de exportação
        user_id: Filtrar por usuário
        role_id: Filtrar por role
        include_expired: Incluir atribuições expiradas
        include_revoked: Incluir atribuições revogadas
        db: Sessão do banco de dados
        current_user_id: ID do usuário atual
        
    Returns:
        dict: Dados exportados
    """
    try:
        user_role_service = UserRoleService(db)
        
        # Construir parâmetros de busca
        params = UserRoleQueryParams(
            user_id=user_id,
            role_id=role_id
        )
        
        # Buscar atribuições
        assignments, total = user_role_service.search_user_roles(params, 0, 10000)  # Limite alto para exportação
        
        # Preparar dados para exportação
        export_data = {
            "total_assignments": total,
            "exported_at": datetime.utcnow().isoformat(),
            "format": format,
            "filters": {
                "user_id": str(user_id) if user_id else None,
                "role_id": str(role_id) if role_id else None,
                "include_expired": include_expired,
                "include_revoked": include_revoked
            },
            "assignments": [
                {
                    "id": str(assignment.id),
                    "user_id": str(assignment.user_id),
                    "role_id": str(assignment.role_id),
                    "user_username": assignment.user_username,
                    "role_name": assignment.role_name,
                    "assignment_type": assignment.assignment_type,
                    "status": assignment.status,
                    "assigned_at": assignment.assigned_at.isoformat(),
                    "expires_at": assignment.expires_at.isoformat() if assignment.expires_at else None,
                    "is_expired": assignment.is_expired,
                    "is_expiring_soon": assignment.is_expiring_soon
                }
                for assignment in assignments
            ]
        }
        
        return export_data
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

