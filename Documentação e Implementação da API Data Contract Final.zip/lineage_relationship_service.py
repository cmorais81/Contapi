"""
Lineage Relationship Service

Service para gerenciamento de relacionamentos de linhagem de dados.

Author: Carlos Morais <carlos.morais@f1rst.com.br>
Date: Julho 2025
"""

import uuid
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any, Tuple, Set
from uuid import UUID

from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, func, desc, asc, text

from app.core.exceptions import (
    ValidationError, 
    NotFoundError, 
    ConflictError, 
    BusinessRuleError
)
from app.models.lineage.lineage_relationship import LineageRelationship
from app.schemas.lineage.lineage_relationship import (
    LineageRelationshipCreate, 
    LineageRelationshipUpdate, 
    LineageRelationshipRead, 
    LineageRelationshipSummary,
    LineageRelationshipQueryParams,
    LineageRelationshipStats,
    LineageGraph,
    LineageNode,
    LineageEdge,
    LineagePath,
    LineageTraversal,
    LineageBulkOperation,
    LineageBulkResult,
    RelationshipType,
    GranularityLevel,
    LineageDirection
)
from app.components.audit_logger import AuditLogger


class LineageRelationshipService:
    """
    Service para gerenciamento completo de relacionamentos de linhagem.
    
    Funcionalidades:
    - CRUD de relacionamentos
    - Construção de grafos de linhagem
    - Traversal de linhagem (upstream/downstream)
    - Detecção de ciclos
    - Análise de impacto
    - Validação de integridade
    - Operações em lote
    """
    
    def __init__(self, db: Session):
        self.db = db
        self.audit_logger = AuditLogger(db)
        
        # Configurações
        self.max_traversal_depth = 50
        self.max_graph_nodes = 10000
        self.confidence_threshold = 0.7
        
        # Cache para performance
        self._graph_cache = {}
        self._cache_ttl = 300  # 5 minutos
    
    # ==================== CRUD Operations ====================
    
    def create_relationship(
        self, 
        relationship_data: LineageRelationshipCreate, 
        created_by: Optional[UUID] = None
    ) -> LineageRelationshipRead:
        """
        Cria um novo relacionamento de linhagem.
        
        Args:
            relationship_data: Dados do relacionamento
            created_by: ID do usuário que está criando
            
        Returns:
            LineageRelationshipRead: Relacionamento criado
            
        Raises:
            ConflictError: Se relacionamento já existe
            ValidationError: Se dados são inválidos
        """
        try:
            # Validar se relacionamento já existe
            existing = self._check_existing_relationship(
                relationship_data.source_entity_id,
                relationship_data.target_entity_id,
                relationship_data.relationship_type,
                relationship_data.granularity_level
            )
            
            if existing:
                raise ConflictError("Relacionamento de linhagem já existe")
            
            # Validar se não cria ciclo
            if self._would_create_cycle(relationship_data.source_entity_id, relationship_data.target_entity_id):
                if not relationship_data.allow_cycles:
                    raise ValidationError("Relacionamento criaria um ciclo na linhagem")
            
            # Validar entidades
            self._validate_entities(relationship_data.source_entity_id, relationship_data.target_entity_id)
            
            # Criar relacionamento
            relationship = LineageRelationship(
                id=uuid.uuid4(),
                source_entity_id=relationship_data.source_entity_id,
                target_entity_id=relationship_data.target_entity_id,
                relationship_type=relationship_data.relationship_type,
                granularity_level=relationship_data.granularity_level,
                source_qualified_name=relationship_data.source_qualified_name,
                target_qualified_name=relationship_data.target_qualified_name,
                source_system=relationship_data.source_system,
                target_system=relationship_data.target_system,
                transformation_logic=relationship_data.transformation_logic,
                transformation_type=relationship_data.transformation_type,
                confidence_score=relationship_data.confidence_score,
                discovery_method=relationship_data.discovery_method,
                is_active=relationship_data.is_active,
                is_validated=relationship_data.is_validated,
                validation_status=relationship_data.validation_status,
                last_validated_at=relationship_data.last_validated_at,
                metrics=relationship_data.metrics.dict() if relationship_data.metrics else None,
                metadata=relationship_data.metadata or {},
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow()
            )
            
            self.db.add(relationship)
            self.db.commit()
            self.db.refresh(relationship)
            
            # Limpar cache
            self._clear_graph_cache()
            
            # Log de auditoria
            self.audit_logger.log_user_action(
                user_id=created_by,
                action="lineage_relationship_created",
                details={
                    "relationship_id": str(relationship.id),
                    "source_entity": relationship_data.source_qualified_name,
                    "target_entity": relationship_data.target_qualified_name,
                    "relationship_type": relationship_data.relationship_type,
                    "confidence_score": relationship_data.confidence_score
                }
            )
            
            return self._to_relationship_read(relationship)
            
        except Exception as e:
            self.db.rollback()
            if isinstance(e, (ConflictError, ValidationError)):
                raise
            raise BusinessRuleError(f"Erro ao criar relacionamento: {str(e)}")
    
    def get_relationship(self, relationship_id: UUID) -> Optional[LineageRelationshipRead]:
        """
        Obtém um relacionamento por ID.
        
        Args:
            relationship_id: ID do relacionamento
            
        Returns:
            LineageRelationshipRead: Relacionamento encontrado ou None
        """
        relationship = self.db.query(LineageRelationship).filter(
            LineageRelationship.id == relationship_id
        ).first()
        return self._to_relationship_read(relationship) if relationship else None
    
    def update_relationship(
        self, 
        relationship_id: UUID, 
        update_data: LineageRelationshipUpdate, 
        updated_by: Optional[UUID] = None
    ) -> LineageRelationshipRead:
        """
        Atualiza um relacionamento existente.
        
        Args:
            relationship_id: ID do relacionamento
            update_data: Dados para atualização
            updated_by: ID do usuário que está atualizando
            
        Returns:
            LineageRelationshipRead: Relacionamento atualizado
        """
        relationship = self.db.query(LineageRelationship).filter(
            LineageRelationship.id == relationship_id
        ).first()
        
        if not relationship:
            raise NotFoundError(f"Relacionamento {relationship_id} não encontrado")
        
        try:
            # Armazenar valores antigos para auditoria
            old_values = {
                "confidence_score": relationship.confidence_score,
                "is_validated": relationship.is_validated,
                "validation_status": relationship.validation_status,
                "transformation_logic": relationship.transformation_logic
            }
            
            # Atualizar campos
            update_fields = update_data.dict(exclude_unset=True)
            for field, value in update_fields.items():
                if hasattr(relationship, field):
                    if field in ["metrics", "metadata"]:
                        # Merge com dados existentes
                        current_data = getattr(relationship, field) or {}
                        if isinstance(value, dict):
                            current_data.update(value)
                            setattr(relationship, field, current_data)
                        else:
                            setattr(relationship, field, value.dict() if hasattr(value, 'dict') else value)
                    else:
                        setattr(relationship, field, value)
            
            relationship.updated_at = datetime.utcnow()
            
            self.db.commit()
            self.db.refresh(relationship)
            
            # Limpar cache
            self._clear_graph_cache()
            
            # Log de auditoria
            new_values = {
                "confidence_score": relationship.confidence_score,
                "is_validated": relationship.is_validated,
                "validation_status": relationship.validation_status,
                "transformation_logic": relationship.transformation_logic
            }
            
            self.audit_logger.log_user_action(
                user_id=updated_by,
                action="lineage_relationship_updated",
                details={
                    "relationship_id": str(relationship_id),
                    "old_values": old_values,
                    "new_values": new_values,
                    "changed_fields": list(update_fields.keys())
                }
            )
            
            return self._to_relationship_read(relationship)
            
        except Exception as e:
            self.db.rollback()
            raise BusinessRuleError(f"Erro ao atualizar relacionamento: {str(e)}")
    
    def delete_relationship(
        self, 
        relationship_id: UUID, 
        deleted_by: Optional[UUID] = None
    ) -> bool:
        """
        Exclui um relacionamento de linhagem.
        
        Args:
            relationship_id: ID do relacionamento
            deleted_by: ID do usuário que está excluindo
            
        Returns:
            bool: True se excluído com sucesso
        """
        relationship = self.db.query(LineageRelationship).filter(
            LineageRelationship.id == relationship_id
        ).first()
        
        if not relationship:
            raise NotFoundError(f"Relacionamento {relationship_id} não encontrado")
        
        try:
            # Soft delete
            relationship.is_active = False
            relationship.updated_at = datetime.utcnow()
            relationship.metadata = relationship.metadata or {}
            relationship.metadata["deleted_at"] = datetime.utcnow().isoformat()
            relationship.metadata["deleted_by"] = str(deleted_by) if deleted_by else None
            
            self.db.commit()
            
            # Limpar cache
            self._clear_graph_cache()
            
            # Log de auditoria
            self.audit_logger.log_user_action(
                user_id=deleted_by,
                action="lineage_relationship_deleted",
                details={
                    "relationship_id": str(relationship_id),
                    "source_entity": relationship.source_qualified_name,
                    "target_entity": relationship.target_qualified_name
                }
            )
            
            return True
            
        except Exception as e:
            self.db.rollback()
            raise BusinessRuleError(f"Erro ao excluir relacionamento: {str(e)}")
    
    # ==================== Graph Operations ====================
    
    def build_lineage_graph(
        self, 
        entity_id: UUID,
        direction: LineageDirection = LineageDirection.BOTH,
        max_depth: int = 10,
        include_inactive: bool = False,
        confidence_threshold: float = 0.5
    ) -> LineageGraph:
        """
        Constrói grafo de linhagem para uma entidade.
        
        Args:
            entity_id: ID da entidade central
            direction: Direção da linhagem (upstream, downstream, both)
            max_depth: Profundidade máxima
            include_inactive: Incluir relacionamentos inativos
            confidence_threshold: Threshold mínimo de confiança
            
        Returns:
            LineageGraph: Grafo de linhagem
        """
        try:
            # Verificar cache
            cache_key = f"graph:{entity_id}:{direction}:{max_depth}:{include_inactive}:{confidence_threshold}"
            cached_graph = self._get_cached_graph(cache_key)
            if cached_graph:
                return cached_graph
            
            # Construir grafo
            nodes = {}
            edges = []
            visited = set()
            
            # Adicionar nó central
            central_node = self._create_lineage_node(entity_id, 0, True)
            nodes[str(entity_id)] = central_node
            
            # Traversal recursivo
            if direction in [LineageDirection.UPSTREAM, LineageDirection.BOTH]:
                self._traverse_upstream(entity_id, nodes, edges, visited, 1, max_depth, 
                                     include_inactive, confidence_threshold)
            
            if direction in [LineageDirection.DOWNSTREAM, LineageDirection.BOTH]:
                self._traverse_downstream(entity_id, nodes, edges, visited, 1, max_depth, 
                                        include_inactive, confidence_threshold)
            
            # Criar grafo
            graph = LineageGraph(
                center_entity_id=entity_id,
                nodes=list(nodes.values()),
                edges=edges,
                direction=direction,
                max_depth=max_depth,
                total_nodes=len(nodes),
                total_edges=len(edges),
                confidence_threshold=confidence_threshold,
                generated_at=datetime.utcnow(),
                metadata={
                    "include_inactive": include_inactive,
                    "traversal_stats": self._calculate_traversal_stats(nodes, edges)
                }
            )
            
            # Cache do resultado
            self._cache_graph(cache_key, graph)
            
            return graph
            
        except Exception as e:
            raise BusinessRuleError(f"Erro ao construir grafo de linhagem: {str(e)}")
    
    def get_lineage_path(
        self, 
        source_entity_id: UUID, 
        target_entity_id: UUID,
        max_paths: int = 10
    ) -> List[LineagePath]:
        """
        Encontra caminhos de linhagem entre duas entidades.
        
        Args:
            source_entity_id: ID da entidade origem
            target_entity_id: ID da entidade destino
            max_paths: Número máximo de caminhos
            
        Returns:
            List[LineagePath]: Lista de caminhos encontrados
        """
        try:
            paths = []
            visited = set()
            current_path = []
            
            # Busca em profundidade para encontrar caminhos
            self._find_paths_dfs(
                source_entity_id, 
                target_entity_id, 
                current_path, 
                visited, 
                paths, 
                max_paths,
                0,
                self.max_traversal_depth
            )
            
            # Converter para LineagePath objects
            lineage_paths = []
            for path in paths:
                lineage_path = LineagePath(
                    source_entity_id=source_entity_id,
                    target_entity_id=target_entity_id,
                    path_length=len(path) - 1,
                    entities=path,
                    relationships=self._get_path_relationships(path),
                    confidence_score=self._calculate_path_confidence(path),
                    transformation_summary=self._summarize_path_transformations(path)
                )
                lineage_paths.append(lineage_path)
            
            # Ordenar por confiança
            lineage_paths.sort(key=lambda x: x.confidence_score, reverse=True)
            
            return lineage_paths
            
        except Exception as e:
            raise BusinessRuleError(f"Erro ao encontrar caminhos de linhagem: {str(e)}")
    
    def traverse_lineage(
        self, 
        entity_id: UUID,
        direction: LineageDirection,
        max_depth: int = 10,
        filters: Optional[Dict[str, Any]] = None
    ) -> LineageTraversal:
        """
        Realiza traversal de linhagem com filtros.
        
        Args:
            entity_id: ID da entidade inicial
            direction: Direção do traversal
            max_depth: Profundidade máxima
            filters: Filtros opcionais
            
        Returns:
            LineageTraversal: Resultado do traversal
        """
        try:
            visited_entities = []
            relationships_traversed = []
            current_depth = 0
            
            # Executar traversal
            if direction == LineageDirection.UPSTREAM:
                self._traverse_upstream_detailed(
                    entity_id, visited_entities, relationships_traversed, 
                    current_depth, max_depth, filters
                )
            elif direction == LineageDirection.DOWNSTREAM:
                self._traverse_downstream_detailed(
                    entity_id, visited_entities, relationships_traversed, 
                    current_depth, max_depth, filters
                )
            else:  # BOTH
                # Traversal upstream
                self._traverse_upstream_detailed(
                    entity_id, visited_entities, relationships_traversed, 
                    current_depth, max_depth, filters
                )
                # Traversal downstream
                self._traverse_downstream_detailed(
                    entity_id, visited_entities, relationships_traversed, 
                    current_depth, max_depth, filters
                )
            
            # Calcular estatísticas
            stats = self._calculate_traversal_statistics(visited_entities, relationships_traversed)
            
            return LineageTraversal(
                start_entity_id=entity_id,
                direction=direction,
                max_depth=max_depth,
                visited_entities=visited_entities,
                relationships_traversed=relationships_traversed,
                total_entities=len(visited_entities),
                total_relationships=len(relationships_traversed),
                max_depth_reached=max(e.depth for e in visited_entities) if visited_entities else 0,
                statistics=stats,
                filters_applied=filters,
                executed_at=datetime.utcnow()
            )
            
        except Exception as e:
            raise BusinessRuleError(f"Erro no traversal de linhagem: {str(e)}")
    
    # ==================== Validation and Analysis ====================
    
    def validate_lineage_integrity(self, entity_id: Optional[UUID] = None) -> Dict[str, Any]:
        """
        Valida integridade da linhagem.
        
        Args:
            entity_id: ID da entidade específica (opcional)
            
        Returns:
            Dict[str, Any]: Resultado da validação
        """
        try:
            validation_results = {
                "is_valid": True,
                "issues": [],
                "warnings": [],
                "statistics": {},
                "validated_at": datetime.utcnow().isoformat()
            }
            
            # Validações específicas
            if entity_id:
                # Validar entidade específica
                entity_issues = self._validate_entity_lineage(entity_id)
                validation_results["issues"].extend(entity_issues)
            else:
                # Validar toda a linhagem
                global_issues = self._validate_global_lineage()
                validation_results["issues"].extend(global_issues)
            
            # Detectar ciclos
            cycles = self._detect_cycles()
            if cycles:
                validation_results["issues"].extend([
                    {"type": "cycle", "description": f"Ciclo detectado: {cycle}"} 
                    for cycle in cycles
                ])
            
            # Detectar relacionamentos órfãos
            orphaned = self._detect_orphaned_relationships()
            if orphaned:
                validation_results["warnings"].extend([
                    {"type": "orphaned", "description": f"Relacionamento órfão: {rel}"} 
                    for rel in orphaned
                ])
            
            # Detectar baixa confiança
            low_confidence = self._detect_low_confidence_relationships()
            if low_confidence:
                validation_results["warnings"].extend([
                    {"type": "low_confidence", "description": f"Baixa confiança: {rel}"} 
                    for rel in low_confidence
                ])
            
            # Calcular estatísticas
            validation_results["statistics"] = self._calculate_validation_statistics()
            
            # Determinar se é válido
            validation_results["is_valid"] = len(validation_results["issues"]) == 0
            
            return validation_results
            
        except Exception as e:
            raise BusinessRuleError(f"Erro na validação de integridade: {str(e)}")
    
    def detect_lineage_anomalies(self, entity_id: UUID) -> List[Dict[str, Any]]:
        """
        Detecta anomalias na linhagem de uma entidade.
        
        Args:
            entity_id: ID da entidade
            
        Returns:
            List[Dict[str, Any]]: Lista de anomalias detectadas
        """
        try:
            anomalies = []
            
            # Obter relacionamentos da entidade
            relationships = self._get_entity_relationships(entity_id)
            
            # Detectar anomalias de confiança
            confidence_anomalies = self._detect_confidence_anomalies(relationships)
            anomalies.extend(confidence_anomalies)
            
            # Detectar anomalias temporais
            temporal_anomalies = self._detect_temporal_anomalies(relationships)
            anomalies.extend(temporal_anomalies)
            
            # Detectar anomalias de transformação
            transformation_anomalies = self._detect_transformation_anomalies(relationships)
            anomalies.extend(transformation_anomalies)
            
            # Detectar anomalias de volume
            volume_anomalies = self._detect_volume_anomalies(entity_id)
            anomalies.extend(volume_anomalies)
            
            return anomalies
            
        except Exception as e:
            raise BusinessRuleError(f"Erro na detecção de anomalias: {str(e)}")
    
    # ==================== Search and Query ====================
    
    def search_relationships(
        self, 
        params: LineageRelationshipQueryParams,
        skip: int = 0,
        limit: int = 100
    ) -> Tuple[List[LineageRelationshipSummary], int]:
        """
        Busca relacionamentos com filtros avançados.
        
        Args:
            params: Parâmetros de busca
            skip: Número de registros para pular
            limit: Limite de registros
            
        Returns:
            Tuple[List[LineageRelationshipSummary], int]: Lista de relacionamentos e total
        """
        query = self.db.query(LineageRelationship)
        
        # Aplicar filtros
        if params.source_entity_id:
            query = query.filter(LineageRelationship.source_entity_id == params.source_entity_id)
        
        if params.target_entity_id:
            query = query.filter(LineageRelationship.target_entity_id == params.target_entity_id)
        
        if params.relationship_type:
            query = query.filter(LineageRelationship.relationship_type == params.relationship_type)
        
        if params.granularity_level:
            query = query.filter(LineageRelationship.granularity_level == params.granularity_level)
        
        if params.source_system:
            query = query.filter(LineageRelationship.source_system.ilike(f"%{params.source_system}%"))
        
        if params.target_system:
            query = query.filter(LineageRelationship.target_system.ilike(f"%{params.target_system}%"))
        
        if params.transformation_type:
            query = query.filter(LineageRelationship.transformation_type == params.transformation_type)
        
        if params.discovery_method:
            query = query.filter(LineageRelationship.discovery_method == params.discovery_method)
        
        if params.is_active is not None:
            query = query.filter(LineageRelationship.is_active == params.is_active)
        
        if params.is_validated is not None:
            query = query.filter(LineageRelationship.is_validated == params.is_validated)
        
        if params.validation_status:
            query = query.filter(LineageRelationship.validation_status == params.validation_status)
        
        if params.min_confidence_score is not None:
            query = query.filter(LineageRelationship.confidence_score >= params.min_confidence_score)
        
        if params.max_confidence_score is not None:
            query = query.filter(LineageRelationship.confidence_score <= params.max_confidence_score)
        
        if params.created_after:
            query = query.filter(LineageRelationship.created_at >= params.created_after)
        
        if params.created_before:
            query = query.filter(LineageRelationship.created_at <= params.created_before)
        
        if params.search:
            search_term = f"%{params.search}%"
            query = query.filter(
                or_(
                    LineageRelationship.source_qualified_name.ilike(search_term),
                    LineageRelationship.target_qualified_name.ilike(search_term),
                    LineageRelationship.transformation_logic.ilike(search_term)
                )
            )
        
        # Contar total
        total = query.count()
        
        # Aplicar ordenação
        if params.sort_by == "confidence_score":
            order_field = LineageRelationship.confidence_score
        elif params.sort_by == "created_at":
            order_field = LineageRelationship.created_at
        elif params.sort_by == "updated_at":
            order_field = LineageRelationship.updated_at
        else:
            order_field = LineageRelationship.created_at
        
        if params.sort_order == "desc":
            query = query.order_by(desc(order_field))
        else:
            query = query.order_by(asc(order_field))
        
        # Aplicar paginação
        relationships = query.offset(skip).limit(limit).all()
        
        # Converter para summary
        summaries = [self._to_relationship_summary(rel) for rel in relationships]
        
        return summaries, total
    
    def get_relationship_stats(self) -> LineageRelationshipStats:
        """
        Obtém estatísticas de relacionamentos.
        
        Returns:
            LineageRelationshipStats: Estatísticas dos relacionamentos
        """
        # Contadores básicos
        total_relationships = self.db.query(LineageRelationship).count()
        active_relationships = self.db.query(LineageRelationship).filter(
            LineageRelationship.is_active == True
        ).count()
        validated_relationships = self.db.query(LineageRelationship).filter(
            LineageRelationship.is_validated == True
        ).count()
        
        # Por tipo de relacionamento
        relationships_by_type = {}
        for rel_type in RelationshipType:
            count = self.db.query(LineageRelationship).filter(
                LineageRelationship.relationship_type == rel_type
            ).count()
            relationships_by_type[rel_type.value] = count
        
        # Por nível de granularidade
        relationships_by_granularity = {}
        for granularity in GranularityLevel:
            count = self.db.query(LineageRelationship).filter(
                LineageRelationship.granularity_level == granularity
            ).count()
            relationships_by_granularity[granularity.value] = count
        
        # Por sistema
        systems_stats = self._calculate_systems_stats()
        
        # Estatísticas de confiança
        confidence_stats = self._calculate_confidence_stats()
        
        # Relacionamentos mais recentes
        recent_relationships = self.db.query(LineageRelationship).order_by(
            desc(LineageRelationship.created_at)
        ).limit(10).all()
        
        # Entidades mais conectadas
        most_connected_entities = self._get_most_connected_entities()
        
        return LineageRelationshipStats(
            total_relationships=total_relationships,
            active_relationships=active_relationships,
            inactive_relationships=total_relationships - active_relationships,
            validated_relationships=validated_relationships,
            unvalidated_relationships=total_relationships - validated_relationships,
            relationships_by_type=relationships_by_type,
            relationships_by_granularity=relationships_by_granularity,
            systems_stats=systems_stats,
            confidence_stats=confidence_stats,
            most_connected_entities=most_connected_entities,
            recent_relationships=[self._to_relationship_summary(r) for r in recent_relationships],
            graph_complexity_score=self._calculate_graph_complexity()
        )
    
    # ==================== Bulk Operations ====================
    
    def bulk_operation(
        self, 
        operation: LineageBulkOperation,
        performed_by: Optional[UUID] = None
    ) -> LineageBulkResult:
        """
        Executa operação em lote nos relacionamentos.
        
        Args:
            operation: Operação a ser executada
            performed_by: ID do usuário que está executando
            
        Returns:
            LineageBulkResult: Resultado da operação
        """
        results = []
        errors = []
        successful = 0
        failed = 0
        
        for relationship_id in operation.relationship_ids:
            try:
                if operation.operation == "validate":
                    self._bulk_validate_relationship(relationship_id, performed_by)
                elif operation.operation == "activate":
                    self._bulk_activate_relationship(relationship_id, performed_by)
                elif operation.operation == "deactivate":
                    self._bulk_deactivate_relationship(relationship_id, performed_by)
                elif operation.operation == "delete":
                    self.delete_relationship(relationship_id, performed_by)
                elif operation.operation == "update_confidence":
                    self._bulk_update_confidence(relationship_id, operation.parameters, performed_by)
                else:
                    raise ValueError(f"Operação não suportada: {operation.operation}")
                
                results.append({"relationship_id": str(relationship_id), "status": "success"})
                successful += 1
                
            except Exception as e:
                error_detail = {
                    "relationship_id": str(relationship_id),
                    "error": str(e),
                    "status": "failed"
                }
                errors.append(error_detail)
                results.append(error_detail)
                failed += 1
        
        # Log de auditoria
        self.audit_logger.log_user_action(
            user_id=performed_by,
            action=f"bulk_{operation.operation}_lineage",
            details={
                "total_relationships": len(operation.relationship_ids),
                "successful": successful,
                "failed": failed,
                "reason": operation.reason
            }
        )
        
        return LineageBulkResult(
            total_requested=len(operation.relationship_ids),
            successful=successful,
            failed=failed,
            errors=errors,
            results=results
        )
    
    # ==================== Helper Methods ====================
    
    def _check_existing_relationship(
        self, 
        source_id: UUID, 
        target_id: UUID, 
        rel_type: RelationshipType,
        granularity: GranularityLevel
    ) -> bool:
        """Verifica se relacionamento já existe."""
        existing = self.db.query(LineageRelationship).filter(
            and_(
                LineageRelationship.source_entity_id == source_id,
                LineageRelationship.target_entity_id == target_id,
                LineageRelationship.relationship_type == rel_type,
                LineageRelationship.granularity_level == granularity,
                LineageRelationship.is_active == True
            )
        ).first()
        return existing is not None
    
    def _would_create_cycle(self, source_id: UUID, target_id: UUID) -> bool:
        """Verifica se relacionamento criaria um ciclo."""
        # Implementar detecção de ciclo usando DFS
        visited = set()
        rec_stack = set()
        
        def has_cycle_dfs(node_id: UUID) -> bool:
            if node_id in rec_stack:
                return True
            if node_id in visited:
                return False
            
            visited.add(node_id)
            rec_stack.add(node_id)
            
            # Obter relacionamentos downstream
            downstream_rels = self.db.query(LineageRelationship).filter(
                and_(
                    LineageRelationship.source_entity_id == node_id,
                    LineageRelationship.is_active == True
                )
            ).all()
            
            for rel in downstream_rels:
                if has_cycle_dfs(rel.target_entity_id):
                    return True
            
            rec_stack.remove(node_id)
            return False
        
        # Simular adição do relacionamento
        return has_cycle_dfs(target_id)
    
    def _validate_entities(self, source_id: UUID, target_id: UUID) -> None:
        """Valida se entidades existem."""
        # Implementar validação de entidades
        # Por enquanto, assumir que são válidas
        pass
    
    def _traverse_upstream(
        self, 
        entity_id: UUID, 
        nodes: Dict[str, LineageNode], 
        edges: List[LineageEdge],
        visited: Set[UUID], 
        depth: int, 
        max_depth: int,
        include_inactive: bool, 
        confidence_threshold: float
    ) -> None:
        """Traversal upstream recursivo."""
        if depth > max_depth or entity_id in visited:
            return
        
        visited.add(entity_id)
        
        # Obter relacionamentos upstream
        query = self.db.query(LineageRelationship).filter(
            LineageRelationship.target_entity_id == entity_id
        )
        
        if not include_inactive:
            query = query.filter(LineageRelationship.is_active == True)
        
        if confidence_threshold > 0:
            query = query.filter(LineageRelationship.confidence_score >= confidence_threshold)
        
        relationships = query.all()
        
        for rel in relationships:
            source_id = rel.source_entity_id
            
            # Adicionar nó se não existe
            if str(source_id) not in nodes:
                node = self._create_lineage_node(source_id, depth, False)
                nodes[str(source_id)] = node
            
            # Adicionar edge
            edge = self._create_lineage_edge(rel, depth)
            edges.append(edge)
            
            # Continuar traversal
            self._traverse_upstream(
                source_id, nodes, edges, visited, depth + 1, max_depth,
                include_inactive, confidence_threshold
            )
    
    def _traverse_downstream(
        self, 
        entity_id: UUID, 
        nodes: Dict[str, LineageNode], 
        edges: List[LineageEdge],
        visited: Set[UUID], 
        depth: int, 
        max_depth: int,
        include_inactive: bool, 
        confidence_threshold: float
    ) -> None:
        """Traversal downstream recursivo."""
        if depth > max_depth or entity_id in visited:
            return
        
        visited.add(entity_id)
        
        # Obter relacionamentos downstream
        query = self.db.query(LineageRelationship).filter(
            LineageRelationship.source_entity_id == entity_id
        )
        
        if not include_inactive:
            query = query.filter(LineageRelationship.is_active == True)
        
        if confidence_threshold > 0:
            query = query.filter(LineageRelationship.confidence_score >= confidence_threshold)
        
        relationships = query.all()
        
        for rel in relationships:
            target_id = rel.target_entity_id
            
            # Adicionar nó se não existe
            if str(target_id) not in nodes:
                node = self._create_lineage_node(target_id, depth, False)
                nodes[str(target_id)] = node
            
            # Adicionar edge
            edge = self._create_lineage_edge(rel, depth)
            edges.append(edge)
            
            # Continuar traversal
            self._traverse_downstream(
                target_id, nodes, edges, visited, depth + 1, max_depth,
                include_inactive, confidence_threshold
            )
    
    def _create_lineage_node(self, entity_id: UUID, depth: int, is_center: bool) -> LineageNode:
        """Cria nó de linhagem."""
        # Obter informações da entidade (implementar busca na tabela entities)
        return LineageNode(
            entity_id=entity_id,
            qualified_name=f"entity_{entity_id}",  # Placeholder
            entity_type="table",  # Placeholder
            system="unknown",  # Placeholder
            depth=depth,
            is_center=is_center,
            upstream_count=self._count_upstream_relationships(entity_id),
            downstream_count=self._count_downstream_relationships(entity_id),
            metadata={}
        )
    
    def _create_lineage_edge(self, relationship: LineageRelationship, depth: int) -> LineageEdge:
        """Cria edge de linhagem."""
        return LineageEdge(
            relationship_id=relationship.id,
            source_entity_id=relationship.source_entity_id,
            target_entity_id=relationship.target_entity_id,
            relationship_type=relationship.relationship_type,
            confidence_score=relationship.confidence_score,
            transformation_logic=relationship.transformation_logic,
            depth=depth,
            is_validated=relationship.is_validated,
            metadata=relationship.metadata or {}
        )
    
    def _count_upstream_relationships(self, entity_id: UUID) -> int:
        """Conta relacionamentos upstream."""
        return self.db.query(LineageRelationship).filter(
            and_(
                LineageRelationship.target_entity_id == entity_id,
                LineageRelationship.is_active == True
            )
        ).count()
    
    def _count_downstream_relationships(self, entity_id: UUID) -> int:
        """Conta relacionamentos downstream."""
        return self.db.query(LineageRelationship).filter(
            and_(
                LineageRelationship.source_entity_id == entity_id,
                LineageRelationship.is_active == True
            )
        ).count()
    
    # Métodos de cache
    def _get_cached_graph(self, cache_key: str) -> Optional[LineageGraph]:
        """Obtém grafo do cache."""
        # Implementar cache Redis ou em memória
        return None
    
    def _cache_graph(self, cache_key: str, graph: LineageGraph) -> None:
        """Armazena grafo no cache."""
        # Implementar cache Redis ou em memória
        pass
    
    def _clear_graph_cache(self) -> None:
        """Limpa cache de grafos."""
        self._graph_cache.clear()
    
    # Métodos de conversão
    def _to_relationship_read(self, relationship: LineageRelationship) -> LineageRelationshipRead:
        """Converte model para schema."""
        return LineageRelationshipRead(
            id=relationship.id,
            source_entity_id=relationship.source_entity_id,
            target_entity_id=relationship.target_entity_id,
            relationship_type=relationship.relationship_type,
            granularity_level=relationship.granularity_level,
            source_qualified_name=relationship.source_qualified_name,
            target_qualified_name=relationship.target_qualified_name,
            source_system=relationship.source_system,
            target_system=relationship.target_system,
            transformation_logic=relationship.transformation_logic,
            transformation_type=relationship.transformation_type,
            confidence_score=relationship.confidence_score,
            discovery_method=relationship.discovery_method,
            is_active=relationship.is_active,
            is_validated=relationship.is_validated,
            validation_status=relationship.validation_status,
            last_validated_at=relationship.last_validated_at,
            metrics=relationship.metrics,
            metadata=relationship.metadata,
            created_at=relationship.created_at,
            updated_at=relationship.updated_at
        )
    
    def _to_relationship_summary(self, relationship: LineageRelationship) -> LineageRelationshipSummary:
        """Converte model para summary."""
        return LineageRelationshipSummary(
            id=relationship.id,
            source_qualified_name=relationship.source_qualified_name,
            target_qualified_name=relationship.target_qualified_name,
            relationship_type=relationship.relationship_type,
            granularity_level=relationship.granularity_level,
            confidence_score=relationship.confidence_score,
            is_active=relationship.is_active,
            is_validated=relationship.is_validated,
            created_at=relationship.created_at
        )
    
    # Métodos auxiliares (implementar conforme necessário)
    def _calculate_traversal_stats(self, nodes: Dict, edges: List) -> Dict[str, Any]:
        """Calcula estatísticas do traversal."""
        return {
            "node_count": len(nodes),
            "edge_count": len(edges),
            "avg_confidence": sum(e.confidence_score for e in edges) / len(edges) if edges else 0
        }
    
    def _find_paths_dfs(self, source: UUID, target: UUID, path: List, visited: Set, 
                       paths: List, max_paths: int, depth: int, max_depth: int) -> None:
        """Busca caminhos usando DFS."""
        # Implementar busca de caminhos
        pass
    
    def _get_path_relationships(self, path: List[UUID]) -> List[UUID]:
        """Obtém relacionamentos de um caminho."""
        # Implementar obtenção de relacionamentos
        return []
    
    def _calculate_path_confidence(self, path: List[UUID]) -> float:
        """Calcula confiança de um caminho."""
        # Implementar cálculo de confiança
        return 0.8
    
    def _summarize_path_transformations(self, path: List[UUID]) -> str:
        """Sumariza transformações de um caminho."""
        # Implementar sumarização
        return "Transformações do caminho"
    
    # Métodos de validação e análise (implementar conforme necessário)
    def _validate_entity_lineage(self, entity_id: UUID) -> List[Dict[str, Any]]:
        """Valida linhagem de uma entidade."""
        return []
    
    def _validate_global_lineage(self) -> List[Dict[str, Any]]:
        """Valida linhagem global."""
        return []
    
    def _detect_cycles(self) -> List[str]:
        """Detecta ciclos na linhagem."""
        return []
    
    def _detect_orphaned_relationships(self) -> List[str]:
        """Detecta relacionamentos órfãos."""
        return []
    
    def _detect_low_confidence_relationships(self) -> List[str]:
        """Detecta relacionamentos de baixa confiança."""
        return []
    
    def _calculate_validation_statistics(self) -> Dict[str, Any]:
        """Calcula estatísticas de validação."""
        return {}
    
    def _get_entity_relationships(self, entity_id: UUID) -> List[LineageRelationship]:
        """Obtém relacionamentos de uma entidade."""
        return self.db.query(LineageRelationship).filter(
            or_(
                LineageRelationship.source_entity_id == entity_id,
                LineageRelationship.target_entity_id == entity_id
            )
        ).all()
    
    def _detect_confidence_anomalies(self, relationships: List) -> List[Dict[str, Any]]:
        """Detecta anomalias de confiança."""
        return []
    
    def _detect_temporal_anomalies(self, relationships: List) -> List[Dict[str, Any]]:
        """Detecta anomalias temporais."""
        return []
    
    def _detect_transformation_anomalies(self, relationships: List) -> List[Dict[str, Any]]:
        """Detecta anomalias de transformação."""
        return []
    
    def _detect_volume_anomalies(self, entity_id: UUID) -> List[Dict[str, Any]]:
        """Detecta anomalias de volume."""
        return []
    
    # Métodos de estatísticas (implementar conforme necessário)
    def _calculate_systems_stats(self) -> Dict[str, Any]:
        """Calcula estatísticas por sistema."""
        return {}
    
    def _calculate_confidence_stats(self) -> Dict[str, Any]:
        """Calcula estatísticas de confiança."""
        return {}
    
    def _get_most_connected_entities(self) -> List[Dict[str, Any]]:
        """Obtém entidades mais conectadas."""
        return []
    
    def _calculate_graph_complexity(self) -> float:
        """Calcula complexidade do grafo."""
        return 0.5
    
    # Métodos para operações em lote
    def _bulk_validate_relationship(self, relationship_id: UUID, performed_by: Optional[UUID]) -> None:
        """Valida relacionamento em operação em lote."""
        relationship = self.db.query(LineageRelationship).filter(
            LineageRelationship.id == relationship_id
        ).first()
        if relationship:
            relationship.is_validated = True
            relationship.validation_status = "validated"
            relationship.last_validated_at = datetime.utcnow()
            relationship.updated_at = datetime.utcnow()
            self.db.commit()
    
    def _bulk_activate_relationship(self, relationship_id: UUID, performed_by: Optional[UUID]) -> None:
        """Ativa relacionamento em operação em lote."""
        relationship = self.db.query(LineageRelationship).filter(
            LineageRelationship.id == relationship_id
        ).first()
        if relationship:
            relationship.is_active = True
            relationship.updated_at = datetime.utcnow()
            self.db.commit()
    
    def _bulk_deactivate_relationship(self, relationship_id: UUID, performed_by: Optional[UUID]) -> None:
        """Desativa relacionamento em operação em lote."""
        relationship = self.db.query(LineageRelationship).filter(
            LineageRelationship.id == relationship_id
        ).first()
        if relationship:
            relationship.is_active = False
            relationship.updated_at = datetime.utcnow()
            self.db.commit()
    
    def _bulk_update_confidence(self, relationship_id: UUID, parameters: Dict[str, Any], performed_by: Optional[UUID]) -> None:
        """Atualiza confiança em operação em lote."""
        relationship = self.db.query(LineageRelationship).filter(
            LineageRelationship.id == relationship_id
        ).first()
        if relationship and "confidence_score" in parameters:
            relationship.confidence_score = parameters["confidence_score"]
            relationship.updated_at = datetime.utcnow()
            self.db.commit()
    
    # Métodos de traversal detalhado (implementar conforme necessário)
    def _traverse_upstream_detailed(self, entity_id: UUID, visited: List, relationships: List, 
                                  depth: int, max_depth: int, filters: Optional[Dict]) -> None:
        """Traversal upstream detalhado."""
        pass
    
    def _traverse_downstream_detailed(self, entity_id: UUID, visited: List, relationships: List, 
                                    depth: int, max_depth: int, filters: Optional[Dict]) -> None:
        """Traversal downstream detalhado."""
        pass
    
    def _calculate_traversal_statistics(self, entities: List, relationships: List) -> Dict[str, Any]:
        """Calcula estatísticas do traversal."""
        return {}

