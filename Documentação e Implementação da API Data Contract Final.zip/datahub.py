"""
DataHub Integration Schemas
Schemas Pydantic para integração com DataHub
"""

from datetime import datetime, date
from typing import Optional, List, Dict, Any
from decimal import Decimal
from pydantic import BaseModel, Field
from uuid import UUID

from app.schemas.base import BaseSchema, PaginatedResponse


class DataHubEntityBase(BaseModel):
    """Schema base para entidades DataHub"""
    datahub_urn: str = Field(..., description="URN único da entidade no DataHub")
    datahub_entity_type: str = Field(..., description="Tipo da entidade (dataset, chart, dashboard, etc.)")
    datahub_platform: str = Field(..., description="Plataforma de origem (mysql, postgres, snowflake, etc.)")
    datahub_name: str = Field(..., description="Nome da entidade no DataHub")
    datahub_description: Optional[str] = Field(None, description="Descrição da entidade")
    datahub_properties: Optional[Dict[str, Any]] = Field(None, description="Propriedades específicas da entidade")
    datahub_ownership: Optional[Dict[str, Any]] = Field(None, description="Informações de ownership")
    datahub_tags: Optional[List[str]] = Field(None, description="Tags associadas à entidade")
    datahub_glossary_terms: Optional[List[str]] = Field(None, description="Termos do glossário")
    datahub_schema: Optional[Dict[str, Any]] = Field(None, description="Schema da entidade")
    datahub_status: str = Field(default="active", description="Status da entidade")


class DataHubEntityCreate(DataHubEntityBase):
    """Schema para criação de entidade DataHub"""
    entity_id: UUID = Field(..., description="ID da entidade associada")


class DataHubEntityUpdate(BaseModel):
    """Schema para atualização de entidade DataHub"""
    datahub_description: Optional[str] = None
    datahub_properties: Optional[Dict[str, Any]] = None
    datahub_ownership: Optional[Dict[str, Any]] = None
    datahub_tags: Optional[List[str]] = None
    datahub_glossary_terms: Optional[List[str]] = None
    datahub_schema: Optional[Dict[str, Any]] = None
    datahub_status: Optional[str] = None


class DataHubEntityResponse(DataHubEntityBase, BaseSchema):
    """Schema de resposta para entidade DataHub"""
    id: UUID
    entity_id: UUID
    last_sync_at: Optional[datetime] = None
    sync_status: str = Field(default="pending", description="Status da sincronização")
    sync_error_message: Optional[str] = None


class DataHubLineageBase(BaseModel):
    """Schema base para linhagem DataHub"""
    upstream_datahub_urn: str = Field(..., description="URN da entidade upstream")
    downstream_datahub_urn: str = Field(..., description="URN da entidade downstream")
    lineage_type: str = Field(..., description="Tipo de relacionamento de linhagem")
    transformation_type: Optional[str] = Field(None, description="Tipo de transformação")
    transformation_info: Optional[Dict[str, Any]] = Field(None, description="Informações da transformação")
    confidence_score: Decimal = Field(default=Decimal("1.0"), description="Score de confiança")


class DataHubLineageCreate(DataHubLineageBase):
    """Schema para criação de linhagem DataHub"""
    pass


class DataHubLineageResponse(DataHubLineageBase, BaseSchema):
    """Schema de resposta para linhagem DataHub"""
    id: UUID
    last_observed_at: Optional[datetime] = None


class DataHubSyncJobBase(BaseModel):
    """Schema base para jobs de sincronização DataHub"""
    job_name: str = Field(..., description="Nome do job de sincronização")
    job_type: str = Field(..., description="Tipo do job (full_sync, incremental_sync, lineage_sync)")
    datahub_platform: Optional[str] = Field(None, description="Plataforma específica para sincronização")
    job_config: Optional[Dict[str, Any]] = Field(None, description="Configuração do job")


class DataHubSyncJobCreate(DataHubSyncJobBase):
    """Schema para criação de job de sincronização"""
    pass


class DataHubSyncJobResponse(DataHubSyncJobBase, BaseSchema):
    """Schema de resposta para job de sincronização"""
    id: UUID
    job_status: str = Field(default="pending", description="Status do job")
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    entities_processed: int = Field(default=0, description="Entidades processadas")
    entities_created: int = Field(default=0, description="Entidades criadas")
    entities_updated: int = Field(default=0, description="Entidades atualizadas")
    entities_failed: int = Field(default=0, description="Entidades com falha")
    error_details: Optional[Dict[str, Any]] = Field(None, description="Detalhes de erros")


# Schemas de resposta paginada
class DataHubEntityListResponse(PaginatedResponse[DataHubEntityResponse]):
    """Resposta paginada para lista de entidades DataHub"""
    pass


class DataHubLineageListResponse(PaginatedResponse[DataHubLineageResponse]):
    """Resposta paginada para lista de linhagem DataHub"""
    pass


class DataHubSyncJobListResponse(PaginatedResponse[DataHubSyncJobResponse]):
    """Resposta paginada para lista de jobs de sincronização"""
    pass


# Schemas para estatísticas e métricas
class DataHubStatsResponse(BaseModel):
    """Estatísticas de integração DataHub"""
    total_entities: int = Field(description="Total de entidades sincronizadas")
    entities_by_platform: Dict[str, int] = Field(description="Entidades por plataforma")
    entities_by_type: Dict[str, int] = Field(description="Entidades por tipo")
    sync_status_summary: Dict[str, int] = Field(description="Resumo de status de sincronização")
    last_sync_time: Optional[datetime] = Field(description="Última sincronização")
    total_lineage_relationships: int = Field(description="Total de relacionamentos de linhagem")
    active_sync_jobs: int = Field(description="Jobs de sincronização ativos")


class DataHubSyncRequest(BaseModel):
    """Request para iniciar sincronização DataHub"""
    platforms: Optional[List[str]] = Field(None, description="Plataformas específicas para sincronizar")
    sync_type: str = Field(default="incremental", description="Tipo de sincronização")
    include_lineage: bool = Field(default=True, description="Incluir sincronização de linhagem")
    batch_size: int = Field(default=100, description="Tamanho do lote para processamento")

