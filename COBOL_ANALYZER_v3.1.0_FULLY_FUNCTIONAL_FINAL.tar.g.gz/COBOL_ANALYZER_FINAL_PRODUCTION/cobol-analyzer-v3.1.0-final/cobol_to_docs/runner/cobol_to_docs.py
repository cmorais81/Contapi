#!/usr/bin/env python3
"""
COBOL to Docs - Ponto de entrada principal
Ferramenta de análise de código COBOL com IA
"""

import sys
import os
import argparse
import shutil
from pathlib import Path
import importlib.util

def find_package_path():
    """Encontra o caminho do pacote cobol_to_docs instalado"""
    
    # Método 1: Tentar importar o módulo e obter seu caminho
    try:
        spec = importlib.util.find_spec("cobol_to_docs")
        if spec and spec.origin:
            package_path = Path(spec.origin).parent
            # Verificar se os diretórios necessários existem
            if (package_path / "config").exists():
                return package_path
    except ImportError:
        pass
    
    # Método 2: Verificar caminhos comuns de instalação
    common_paths = [
        "/usr/local/lib/python3.11/dist-packages/cobol_to_docs",
        "/usr/local/lib/python3.11/site-packages/cobol_to_docs",
        "/usr/lib/python3.11/dist-packages/cobol_to_docs",
        "/usr/lib/python3.11/site-packages/cobol_to_docs",
        f"{os.path.expanduser('~')}/.local/lib/python3.11/site-packages/cobol_to_docs"
    ]
    
    for path in common_paths:
        package_path = Path(path)
        if package_path.exists() and (package_path / "config").exists():
            return package_path
    
    # Método 3: Buscar no sys.path
    for sys_path in sys.path:
        potential_path = Path(sys_path) / "cobol_to_docs"
        if potential_path.exists() and (potential_path / "config").exists():
            return potential_path
    
    # Método 4: Usar caminho relativo ao script atual (para execução do código fonte)
    script_dir = Path(__file__).parent.parent  # Sai de runner/ para cobol_to_docs/
    if (script_dir / "config").exists():
        return script_dir
    
    # Método 5: Verificar se estamos executando do diretório do projeto
    current_dir = Path.cwd()
    while current_dir != current_dir.parent:
        # Verificar se é o diretório cobol_to_docs
        if (current_dir / "config").exists() and (current_dir / "data").exists() and (current_dir / "examples").exists():
            return current_dir
        # Verificar se tem subdiretório cobol_to_docs
        cobol_subdir = current_dir / "cobol_to_docs"
        if cobol_subdir.exists() and (cobol_subdir / "config").exists():
            return cobol_subdir
        current_dir = current_dir.parent
    
    # Método 6: Verificar diretório pai do script (estrutura do projeto)
    project_root = Path(__file__).parent.parent.parent  # Sai de runner/cobol_to_docs/ para raiz
    cobol_dir = project_root / "cobol_to_docs"
    if cobol_dir.exists() and (cobol_dir / "config").exists():
        return cobol_dir
    
    raise RuntimeError("Não foi possível localizar o pacote cobol_to_docs")

def find_main_script(package_path):
    """Encontra o script main.py correto"""
    
    # Opção 1: Estrutura do código fonte (prioridade)
    script_dir = Path(__file__).parent
    main_source = script_dir / "main.py"
    if main_source.exists():
        return main_source
    
    # Opção 2: No mesmo diretório do pacote (instalado)
    main_installed = package_path / "runner" / "main.py"
    if main_installed.exists():
        return main_installed
    
    # Opção 3: Buscar na estrutura do projeto
    project_root = package_path.parent if package_path.name == "cobol_to_docs" else package_path
    main_project = project_root / "cobol_to_docs" / "runner" / "main.py"
    if main_project.exists():
        return main_project
    
    return None

def init_project(target_dir=None):
    """Inicializa um projeto COBOL Analyzer copiando todos os arquivos necessários"""
    if target_dir is None:
        target_dir = Path.cwd()
    else:
        target_dir = Path(target_dir)
    
    print(f"Inicializando projeto COBOL Analyzer em: {target_dir}")
    
    try:
        # Encontrar o caminho do pacote
        package_path = find_package_path()
        print(f"Pacote encontrado em: {package_path}")
    except RuntimeError as e:
        print(f"Erro: {e}")
        print("\nTentativas de localização:")
        print("1. Verifique se o pacote foi instalado corretamente: pip install .")
        print("2. Execute o comando do diretório onde extraiu o pacote")
        print("3. Use o caminho completo para o script")
        print("4. Certifique-se de que os diretórios config/, data/ e examples/ existem")
        return 1
    
    # Diretórios a serem copiados
    dirs_to_copy = ["config", "data", "examples"]
    
    success_count = 0
    
    for dir_name in dirs_to_copy:
        source_dir = package_path / dir_name
        target_subdir = target_dir / dir_name
        
        if source_dir.exists():
            try:
                if target_subdir.exists():
                    print(f"Diretório {dir_name} já existe, sobrescrevendo...")
                    shutil.rmtree(target_subdir)
                
                shutil.copytree(source_dir, target_subdir)
                print(f"Copiado: {dir_name}/")
                success_count += 1
            except Exception as e:
                print(f"Erro ao copiar {dir_name}: {e}")
        else:
            print(f"Diretório {dir_name} não encontrado em {source_dir}")
    
    # Criar diretórios de trabalho
    work_dirs = ["logs", "output", "temp"]
    for work_dir in work_dirs:
        work_path = target_dir / work_dir
        work_path.mkdir(exist_ok=True)
        print(f"Criado: {work_dir}/")
    
    # Criar arquivo de exemplo de fontes se não existir
    fontes_example = target_dir / "fontes_exemplo.txt"
    if not fontes_example.exists():
        with open(fontes_example, "w", encoding="utf-8") as f:
            f.write("# Lista de programas COBOL para análise\n")
            f.write("# Um programa por linha\n")
            f.write("# Exemplo:\n")
            f.write("examples/programa_exemplo.cbl\n")
            f.write("# programa2.cbl\n")
        print("Criado: fontes_exemplo.txt")
    
    print(f"\nInicialização concluída!")
    print(f"Arquivos copiados: {success_count}/{len(dirs_to_copy)}")
    
    if success_count == len(dirs_to_copy):
        # Encontrar o script main.py correto
        main_script = find_main_script(package_path)
        
        print(f"\nPara usar:")
        print(f"1. Configure suas credenciais de IA no arquivo config/config.yaml")
        print(f"2. Liste seus programas COBOL em um arquivo (ex: fontes_exemplo.txt)")
        
        if main_script:
            print(f"3. Execute: python {main_script} --fontes fontes_exemplo.txt --models enhanced_mock")
        else:
            print(f"3. Execute: cobol-to-docs --fontes fontes_exemplo.txt --models enhanced_mock")
        
        return 0
    else:
        print(f"\nAlguns arquivos não foram copiados. Verifique as mensagens de erro acima.")
        return 1

def main():
    """Função principal"""
    parser = argparse.ArgumentParser(
        description="COBOL to Docs v3.1.0 - Análise automatizada de código COBOL",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Exemplos de uso:
  cobol-to-docs --init
  cobol-to-docs --fontes programas.txt --models luzia
  cobol-to-docs --fontes programas.txt --books copybooks.txt --models enhanced_mock
  cobol-to-docs --fontes programas.txt --consolidado --models luzia
  cobol-to-docs --status
        """
    )
    
    # Argumentos principais
    parser.add_argument("--init", action="store_true", 
                       help="Inicializar projeto copiando config, data e examples")
    parser.add_argument("--init-dir", type=str,
                       help="Diretório para inicialização (padrão: diretório atual)")
    parser.add_argument("--fontes", type=str,
                       help="Arquivo com lista de programas COBOL ou código COBOL direto")
    parser.add_argument("--books", type=str,
                       help="Arquivo com lista de copybooks")
    parser.add_argument("--models", type=str,
                       help="Modelo(s) de IA a usar (string ou JSON array)")
    parser.add_argument("--output", type=str, default="output",
                       help="Diretório de saída (padrão: output)")
    
    # Opções de análise
    parser.add_argument("--consolidado", action="store_true",
                       help="Análise consolidada sistêmica")
    parser.add_argument("--relatorio-unico", action="store_true",
                       help="Relatório único consolidado")
    parser.add_argument("--analise-especialista", action="store_true",
                       help="Análise especializada")
    parser.add_argument("--procedure-detalhada", action="store_true",
                       help="Análise detalhada da PROCEDURE DIVISION")
    parser.add_argument("--modernizacao", action="store_true",
                       help="Análise para modernização")
    
    # Opções de configuração
    parser.add_argument("--prompt-set", type=str,
                       help="Conjunto de prompts a usar")
    parser.add_argument("--no-comments", action="store_true",
                       help="Remover comentários do código")
    parser.add_argument("--pdf", action="store_true",
                       help="Gerar relatórios HTML/PDF")
    parser.add_argument("--log-level", type=str, default="INFO",
                       help="Nível de logging")
    
    # Comandos utilitários
    parser.add_argument("--status", action="store_true",
                       help="Verificar status do sistema")
    
    args = parser.parse_args()
    
    # Comando de inicialização
    if args.init:
        return init_project(args.init_dir)
    
    # Para outros comandos, executar o main.py diretamente
    try:
        # Encontrar o caminho do pacote
        package_path = find_package_path()
        main_script = find_main_script(package_path)
        
        if not main_script:
            print("Erro: Não foi possível localizar o script main.py")
            return 1
        
        # Construir comando para executar o main.py
        cmd_args = [sys.executable, str(main_script)]
        
        if args.fontes:
            cmd_args.extend(["--fontes", args.fontes])
        if args.books:
            cmd_args.extend(["--books", args.books])
        if args.models:
            cmd_args.extend(["--models", args.models])
        if args.output != "output":
            cmd_args.extend(["--output", args.output])
        if args.consolidado:
            cmd_args.append("--consolidado")
        if args.relatorio_unico:
            cmd_args.append("--relatorio-unico")
        if args.analise_especialista:
            cmd_args.append("--analise-especialista")
        if args.procedure_detalhada:
            cmd_args.append("--procedure-detalhada")
        if args.modernizacao:
            cmd_args.append("--modernizacao")
        if args.prompt_set:
            cmd_args.extend(["--prompt-set", args.prompt_set])
        if args.no_comments:
            cmd_args.append("--no-comments")
        if args.pdf:
            cmd_args.append("--pdf")
        if args.log_level != "INFO":
            cmd_args.extend(["--log-level", args.log_level])
        if args.status:
            cmd_args.append("--status")
        
        # Executar o main.py como subprocesso
        import subprocess
        result = subprocess.run(cmd_args, cwd=Path.cwd())
        return result.returncode
            
    except Exception as e:
        print(f"Erro inesperado: {e}")
        return 1

if __name__ == "__main__":
    sys.exit(main())
