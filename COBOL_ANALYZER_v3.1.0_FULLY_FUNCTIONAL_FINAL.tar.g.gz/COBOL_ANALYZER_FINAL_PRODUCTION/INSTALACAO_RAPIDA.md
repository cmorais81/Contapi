# Instalação Rápida - COBOL Analyzer v3.1.0

## 🚀 INÍCIO RÁPIDO (5 MINUTOS)

### 1. Pré-requisitos
```bash
# Python 3.11+ (recomendado)
python3 --version

# Pip atualizado
pip3 --version
```

### 2. Instalação
```bash
# Extrair pacote
tar -xzf COBOL_ANALYZER_v3.1.0_FINAL_PRODUCTION_READY.tar.gz
cd COBOL_ANALYZER_FINAL_PRODUCTION

# Instalar
cd cobol-analyzer-v3.1.0-final
pip3 install -e .
```

### 3. Validação
```bash
# Voltar à raiz
cd ..

# Executar validação automática
./validate_system.sh
```

### 4. Primeiro Uso
```bash
cd cobol-analyzer-v3.1.0-final

# Inicializar projeto
python3 cobol_to_docs/runner/cobol_to_docs.py --init

# Verificar status
python3 cobol_to_docs/runner/main.py --status

# Testar com exemplo
echo "examples/PROGRAMA_EXEMPLO.CBL" > teste.txt
python3 cobol_to_docs/runner/main.py --fontes teste.txt --models enhanced_mock
```

## ✅ VALIDAÇÃO COMPLETA

Se todos os comandos executaram sem erro, o sistema está **100% funcional**!

### Próximos Passos
1. **Configurar credenciais IA** (opcional): Editar `config/config.yaml`
2. **Testar com seus arquivos**: Copiar arquivos COBOL e executar análise
3. **Explorar funcionalidades**: Ver documentação completa no `README.md`

## 🆘 PROBLEMAS?

### Erro de Instalação
```bash
# Reinstalar
pip3 uninstall cobol-to-docs -y
pip3 install -e . --force-reinstall
```

### Erro de Importação
```bash
# Verificar PYTHONPATH
export PYTHONPATH=$PWD:$PYTHONPATH
```

### Teste com Arquivos Reais
```bash
# Usar arquivos que causavam erro antes (agora funcionam!)
cp ../arquivos-teste/fontes.txt .
echo "fontes.txt" > meus_arquivos.txt
python3 cobol_to_docs/runner/main.py --fontes meus_arquivos.txt --models enhanced_mock
```

---

**Sistema pronto em menos de 5 minutos!** 🎉
