# Changelog

## v2.6.0 (2025-09-10)

### Novas Funcionalidades

- **Integração com LuzIA Real**: Implementada a integração com o provedor LuzIA real, utilizando autenticação OAuth2 e o pipeline de análise de código.
- **Sistema de Prompts Customizáveis**: Adicionado um sistema de prompts customizáveis através do arquivo `config/prompts.yaml`, permitindo ao usuário adicionar, remover e modificar as perguntas de análise.
- **Geração de PDF**: Adicionada a capacidade de gerar a documentação em formato PDF utilizando a flag `--pdf`.

### Melhorias

- **Controle de Tokens**: Aprimorado o sistema de controle de tokens para incluir limites por hora e por dia.
- **Sistema de Fallback**: Melhorado o sistema de fallback para garantir que a análise seja concluída mesmo que o provedor primário falhe.
- **Documentação**: Criados manuais de usuário e de configuração detalhados.

### Correções

- Corrigidos vários erros de importação e inicialização de provedores.
- Corrigidos erros no gerador de documentação que impediam a criação dos arquivos de saída.
- Estabilizada a execução do sistema com diferentes configurações.


