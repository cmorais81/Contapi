


# COBOL AI Engine v2.6.0 - Manual de Configuração

## 1. Introdução

Este manual descreve em detalhes as opções de configuração do COBOL AI Engine. A configuração é feita através de arquivos YAML, permitindo uma grande flexibilidade para adaptar o sistema às suas necessidades.

## 2. Estrutura do Arquivo de Configuração

O arquivo de configuração principal é o `config/config.yaml`. Você pode criar seus próprios arquivos de configuração e especificá-los na linha de comando com a opção `--config`.

A estrutura principal do arquivo de configuração é a seguinte:

```yaml
ai:
  primary_provider: "luzia_real"
  fallback_providers:
    - "enhanced_mock"
    - "basic"
  providers:
    luzia_real:
      enabled: true
      client_id: "${LUZIA_CLIENT_ID}"
      client_secret: "${LUZIA_CLIENT_SECRET}"
      # ... outras configurações do provedor
    enhanced_mock:
      # ...
    basic:
      # ...

logging:
  level: "INFO"

output:
  default_format: "markdown"
  enable_pdf: true
```

## 3. Seção `ai`

A seção `ai` contém todas as configurações relacionadas aos provedores de IA.

*   `primary_provider`: O provedor de IA que será utilizado primariamente. Se este provedor falhar, o sistema tentará os provedores de fallback.
*   `fallback_providers`: Uma lista de provedores de IA que serão utilizados em ordem caso o provedor primário falhe.

### 3.1. Configuração de Provedores

A subseção `providers` contém as configurações para cada provedor de IA.

#### `luzia_real`

*   `enabled`: `true` ou `false`. Habilita ou desabilita o provedor.
*   `client_id`: O ID do cliente para autenticação no LuzIA. Pode ser definido diretamente no arquivo ou através da variável de ambiente `LUZIA_CLIENT_ID`.
*   `client_secret`: O segredo do cliente para autenticação no LuzIA. Pode ser definido diretamente no arquivo ou através da variável de ambiente `LUZIA_CLIENT_SECRET`.
*   `model`: O modelo de IA a ser utilizado (ex: `azure-gpt-4o-mini`).
*   `api_base`: A URL base da API do LuzIA.
*   `auth_url`: A URL para obtenção do token de autenticação.
*   `api_url`: A URL para submissão de pipelines de análise.
*   `client_header_id`: O ID do cliente para o cabeçalho da requisição.
*   `temperature`: A temperatura a ser utilizada na geração de texto (0.0 para respostas mais determinísticas).
*   `timeout`: O tempo máximo de espera pela resposta da API em segundos.
*   `max_tokens_per_request`, `max_tokens_per_hour`, `max_tokens_per_day`: Limites para o controle de uso de tokens.

#### `enhanced_mock`

*   `enabled`: `true` ou `false`.
*   `response_delay`: Atraso em segundos para simular o tempo de resposta de um provedor real.
*   `enable_phasing`: Habilita a simulação de análise em fases.
*   `max_tokens_per_phase`: Número máximo de tokens por fase.
*   `simulate_realistic_tokens`: Simula um uso de tokens mais realista.

#### `basic`

*   `enabled`: `true` ou `false`.
*   `max_tokens`: Número máximo de tokens por resposta.
*   `response_delay`: Atraso em segundos para simular o tempo de resposta.

## 4. Seção `logging`

*   `level`: O nível de log a ser utilizado (`DEBUG`, `INFO`, `WARNING`, `ERROR`, `CRITICAL`).
*   `format`: O formato da mensagem de log.
*   `file`: O caminho para o arquivo de log.

## 5. Seção `output`

*   `default_format`: O formato de saída padrão (`markdown`).
*   `enable_pdf`: `true` ou `false`. Habilita ou desabilita a geração de PDF.
*   `pdf_engine`: O motor a ser utilizado para gerar o PDF (`weasyprint` ou `manus_utility`).
*   `include_metadata`: `true` ou `false`. Inclui metadados da análise na documentação.
*   `include_statistics`: `true` ou `false`. Inclui estatísticas de uso na documentação.


