


# COBOL AI Engine v2.6.0 - Manual do Usuário

## 1. Introdução

O COBOL AI Engine é uma ferramenta poderosa para análise de programas COBOL, utilizando múltiplos provedores de IA para fornecer uma análise completa e detalhada. Esta versão 2.6.0 inclui a integração com o provedor LuzIA real, um sistema de prompts customizáveis e a capacidade de gerar documentação em formato PDF.

## 2. Instalação

Para instalar o COBOL AI Engine, siga os passos abaixo:

1.  **Pré-requisitos**:
    *   Python 3.8 ou superior
    *   `pip` e `virtualenv`

2.  **Instalação**:
    ```bash
    # Crie e ative um ambiente virtual
    python -m venv venv
    source venv/bin/activate  # No Windows: venv\Scripts\activate

    # Instale as dependências
    pip install -r requirements.txt
    ```

## 3. Configuração

O COBOL AI Engine utiliza um arquivo de configuração YAML para gerenciar os provedores de IA e outras configurações. O arquivo principal é o `config/config.yaml`, mas você pode criar configurações customizadas e especificá-las na linha de comando.

### 3.1. Configuração de Provedores

No arquivo de configuração, você pode habilitar, desabilitar e configurar os provedores de IA. A versão 2.6.0 inclui os seguintes provedores:

*   `luzia_real`: Integração real com o provedor LuzIA.
*   `luzia`: Provedor mock para testes do LuzIA.
*   `enhanced_mock`: Provedor mock avançado para fallback.
*   `basic`: Provedor básico que nunca falha.

Para configurar o `luzia_real`, você precisa fornecer as credenciais `client_id` e `client_secret` no arquivo de configuração ou através de variáveis de ambiente (`LUZIA_CLIENT_ID` e `LUZIA_CLIENT_SECRET`).

### 3.2. Configuração de Prompts

O arquivo `config/prompts.yaml` permite customizar as perguntas e os templates de prompt utilizados na análise. Você pode adicionar, remover ou modificar as perguntas para focar a análise em aspectos específicos do programa COBOL.

## 4. Uso

O COBOL AI Engine é executado através da linha de comando. Abaixo estão os principais comandos e opções.

### 4.1. Analisando um Programa COBOL

Para analisar um programa COBOL, utilize o seguinte comando:

```bash
python main.py --fontes <arquivo_fontes> --books <arquivo_books> --output <diretorio_saida>
```

*   `--fontes`: Arquivo de texto contendo a lista de programas COBOL a serem analisados.
*   `--books`: Arquivo de texto contendo a lista de copybooks.
*   `--output`: Diretório onde a documentação gerada será salva.

### 4.2. Gerando Documentação em PDF

Para gerar a documentação em formato PDF, adicione a flag `--pdf` ao comando de análise:

```bash
python main.py --fontes <arquivo_fontes> --pdf --output <diretorio_saida>
```

### 4.3. Verificando o Status do Sistema

Para verificar o status dos provedores de IA e do conversor de PDF, utilize o comando `--status`:

```bash
python main.py --status
```

### 4.4. Listando as Perguntas de Análise

Para listar as perguntas de análise configuradas, utilize o comando `--list-questions`:

```bash
python main.py --list-questions
```

## 5. Solução de Problemas

*   **Erro de importação**: Verifique se você ativou o ambiente virtual e se todas as dependências foram instaladas corretamente.
*   **Erro de autenticação do LuzIA**: Verifique se as credenciais `client_id` e `client_secret` estão corretas e se as variáveis de ambiente foram exportadas corretamente.
*   **Erro na geração de PDF**: Verifique se as dependências do `weasyprint` foram instaladas corretamente. Consulte a documentação do `weasyprint` para mais detalhes.

Para mais informações, consulte os logs gerados no diretório `logs/`.


