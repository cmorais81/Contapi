#!/bin/bash

# COBOL Analyzer v3.1.0 - Script de Validação Automática
# Este script valida se o sistema está funcionando corretamente

echo "=========================================="
echo "COBOL Analyzer v3.1.0 - Validação do Sistema"
echo "=========================================="
echo

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Função para log
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[✅ OK]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[⚠️  WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[❌ ERRO]${NC} $1"
}

# Contador de testes
TESTS_TOTAL=0
TESTS_PASSED=0
TESTS_FAILED=0

run_test() {
    local test_name="$1"
    local test_command="$2"
    
    TESTS_TOTAL=$((TESTS_TOTAL + 1))
    log_info "Teste $TESTS_TOTAL: $test_name"
    
    if eval "$test_command" >/dev/null 2>&1; then
        log_success "$test_name"
        TESTS_PASSED=$((TESTS_PASSED + 1))
        return 0
    else
        log_error "$test_name"
        TESTS_FAILED=$((TESTS_FAILED + 1))
        return 1
    fi
}

# Verificar se estamos no diretório correto
if [ ! -d "cobol-analyzer-v3.1.0-final" ]; then
    log_error "Diretório cobol-analyzer-v3.1.0-final não encontrado!"
    log_info "Execute este script na raiz do pacote extraído."
    exit 1
fi

cd cobol-analyzer-v3.1.0-final

echo "🔍 VERIFICAÇÕES BÁSICAS"
echo "----------------------------------------"

# Teste 1: Python disponível
run_test "Python 3 disponível" "python3 --version"

# Teste 2: Pip disponível  
run_test "Pip3 disponível" "pip3 --version"

# Teste 3: Estrutura de diretórios
run_test "Estrutura de diretórios" "[ -d cobol_to_docs ] && [ -d tests ] && [ -f setup.py ]"

# Teste 4: Arquivos principais
run_test "Arquivos principais" "[ -f cobol_to_docs/runner/main.py ] && [ -f cobol_to_docs/runner/cobol_to_docs.py ]"

echo
echo "🧪 TESTES DE FUNCIONALIDADE"
echo "----------------------------------------"

# Teste 5: Importação básica
run_test "Importação do módulo" "python3 -c 'import sys; sys.path.insert(0, \".\"); from cobol_to_docs.src.core.config import ConfigManager'"

# Teste 6: Inicialização de projeto
if [ ! -d "config" ]; then
    run_test "Inicialização de projeto" "python3 cobol_to_docs/runner/cobol_to_docs.py --init"
else
    log_warning "Projeto já inicializado, pulando teste de inicialização"
    TESTS_TOTAL=$((TESTS_TOTAL + 1))
    TESTS_PASSED=$((TESTS_PASSED + 1))
fi

# Teste 7: Status do sistema
run_test "Status do sistema" "python3 cobol_to_docs/runner/main.py --status"

# Teste 8: Parse de arquivo exemplo
run_test "Parse de arquivo exemplo" "python3 cobol_to_docs/runner/main.py --fontes examples/PROGRAMA_EXEMPLO.CBL --models enhanced_mock --dry-run"

echo
echo "🔧 TESTES DE ENCODING (CORREÇÃO PRINCIPAL)"
echo "----------------------------------------"

# Teste 9: Arquivo fontes.txt (se disponível)
if [ -f "../arquivos-teste/fontes.txt" ]; then
    cp ../arquivos-teste/fontes.txt .
    echo "fontes.txt" > teste_fontes.txt
    run_test "Processamento fontes.txt (UTF-8)" "python3 cobol_to_docs/runner/main.py --fontes teste_fontes.txt --models enhanced_mock"
    rm -f fontes.txt teste_fontes.txt
else
    log_warning "Arquivo fontes.txt não encontrado, pulando teste de encoding"
fi

# Teste 10: Arquivo BOOKS.txt (se disponível)
if [ -f "../arquivos-teste/BOOKS.txt" ]; then
    cp ../arquivos-teste/BOOKS.txt .
    echo "BOOKS.txt" > teste_books.txt
    run_test "Processamento BOOKS.txt (UTF-8)" "python3 cobol_to_docs/runner/main.py --fontes teste_books.txt --models enhanced_mock"
    rm -f BOOKS.txt teste_books.txt
else
    log_warning "Arquivo BOOKS.txt não encontrado, pulando teste de encoding"
fi

echo
echo "🧪 TESTES UNITÁRIOS"
echo "----------------------------------------"

# Teste 11: Testes unitários
if command -v pytest >/dev/null 2>&1; then
    run_test "Testes unitários (pytest)" "python3 -m pytest tests/ -v --tb=short"
else
    log_warning "pytest não instalado, tentando com unittest"
    run_test "Testes unitários (unittest)" "python3 -m unittest discover tests/ -v"
fi

echo
echo "📊 RESULTADOS FINAIS"
echo "=========================================="

# Calcular porcentagem
if [ $TESTS_TOTAL -gt 0 ]; then
    SUCCESS_RATE=$((TESTS_PASSED * 100 / TESTS_TOTAL))
else
    SUCCESS_RATE=0
fi

echo "Total de testes: $TESTS_TOTAL"
echo -e "Testes passaram: ${GREEN}$TESTS_PASSED${NC}"
echo -e "Testes falharam: ${RED}$TESTS_FAILED${NC}"
echo "Taxa de sucesso: $SUCCESS_RATE%"
echo

# Determinar status final
if [ $SUCCESS_RATE -ge 90 ]; then
    echo -e "${GREEN}🎉 SISTEMA VALIDADO COM SUCESSO!${NC}"
    echo -e "${GREEN}✅ O COBOL Analyzer está pronto para uso.${NC}"
    echo
    echo "📋 PRÓXIMOS PASSOS:"
    echo "1. Configure credenciais de IA em config/config.yaml (opcional)"
    echo "2. Copie seus arquivos COBOL para análise"
    echo "3. Execute: python3 cobol_to_docs/runner/main.py --fontes seus_arquivos.txt --models enhanced_mock"
    echo
    exit_code=0
elif [ $SUCCESS_RATE -ge 70 ]; then
    echo -e "${YELLOW}⚠️  SISTEMA PARCIALMENTE FUNCIONAL${NC}"
    echo -e "${YELLOW}Alguns testes falharam, mas funcionalidades básicas estão OK.${NC}"
    echo
    exit_code=1
else
    echo -e "${RED}❌ PROBLEMAS DETECTADOS NO SISTEMA${NC}"
    echo -e "${RED}Muitos testes falharam. Verifique a instalação.${NC}"
    echo
    echo "🔧 SOLUÇÕES SUGERIDAS:"
    echo "1. Reinstalar: pip3 uninstall cobol-to-docs -y && pip3 install -e ."
    echo "2. Verificar Python: python3 --version (requer 3.11+)"
    echo "3. Verificar dependências: pip3 install -r requirements.txt"
    echo
    exit_code=2
fi

# Informações adicionais
echo "📚 DOCUMENTAÇÃO:"
echo "- README.md: Guia completo"
echo "- INSTALACAO_RAPIDA.md: Início rápido"
echo "- documentacao/: Relatórios de validação"
echo

echo "🆘 SUPORTE:"
echo "- Logs em: logs/"
echo "- Testes em: tests/"
echo "- Exemplos em: examples/"
echo

echo "=========================================="
echo "Validação concluída em $(date)"
echo "=========================================="

exit $exit_code
