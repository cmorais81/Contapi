#!/usr/bin/env python3
"""
Sistema de Cálculo de Custos Avançado para Análise COBOL
Baseado na documentação interna de custos de modelos de IA
"""

import logging
from typing import Dict, Any, List
from datetime import datetime

# Modelo padrão para cálculos
DEFAULT_MODEL = "azure-gpt-4o-mini"

class EnhancedCostCalculator:
    """
    Calculadora de custos avançada para análises de IA
    Suporta múltiplos providers e modelos com cálculo preciso de custos
    """
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.session_costs = []
        self.total_session_cost = 0.0
        
        # Documentação de custo https://confluence.santanderbr.corp/x/6sAdP
        self.MODEL_COSTS = {
            "azure-gpt-4o-mini": {"prompt": 0.2640, "completion": 1.0560},
            "azure-gpt-4o": {"prompt": 5.0000, "completion": 15.0000},
            "azure-o1-preview": {"prompt": 0.0165, "completion": 0.066},
            "azure-text-embedding-3-large": {"prompt": 0.00013, "completion": 0},
            "azure-text-embedding-3-small": {"prompt": 0.00002, "completion": 0},
            "dall-e-3": {"prompt": 0.0064, "completion": 0},    
            "aws-claude-3-5-sonnet": {"prompt": 3.0000, "completion": 15.0000},
            "aws-claude-3-haiku": {"prompt": 0.2500, "completion": 1.2500},
            "amazon-titan-embed-text-v2": {"prompt": 0.0008, "completion": 0},
            "amazon-titan-embed-image-v1": {"prompt": 0.00006, "completion": 0},
            "amazon-nova-micro-v1": {"prompt": 0.000035, "completion": 0.00014},
            "amazon-nova-lite-v1": {"prompt": 0.00006, "completion": 0.00024},
            "amazon-nova-pro-v1": {"prompt": 0.0008, "completion": 0.0032},
            "openai-gpt-4": {"prompt": 30.0000, "completion": 60.0000},
            "openai-gpt-4-turbo": {"prompt": 10.0000, "completion": 30.0000},
            "openai-gpt-3.5-turbo": {"prompt": 0.5000, "completion": 1.5000},
            "luzia": {"prompt": 0.2640, "completion": 1.0560},  # Baseado no Azure GPT-4o-mini
            "enhanced-mock-gpt-4": {"prompt": 0.0000, "completion": 0.0000},  # Mock sem custo
        }
    
    def tokens_analytics(self, response: Dict[str, Any], model: str = None) -> Dict[str, Any]:
        """ 
        Analyzes and calculates token information and costs for API calls.
        Calculates cost based on model-specific pricing.
        
        Args:
            response (Dict[str, Any]): API response containing usage information
            model (str): Model name for cost calculation
            
        Returns:
            Dict[str, Any]: Dictionary containing:
                - prompt_tokens (int): Total number of prompt tokens used
                - completion_tokens (int): Total number of completion tokens used  
                - total_tokens (int): Total number of tokens used
                - cost (float): Calculated cost for the API call
                - cost_brl (float): Cost in Brazilian Reais
                - model (str): Model used for calculation
        """
        usage = response.get("usage", [])
        
        # Se usage é uma lista de dicionários
        if isinstance(usage, list):
            tokens_info = {
                "prompt_tokens": sum(item.get("prompt_tokens", 0) for item in usage),
                "completion_tokens": sum(item.get("completion_tokens", 0) for item in usage),
                "total_tokens": sum(item.get("total_tokens", 0) for item in usage)
            }
        # Se usage é um dicionário direto
        elif isinstance(usage, dict):
            tokens_info = {
                "prompt_tokens": usage.get("prompt_tokens", 0),
                "completion_tokens": usage.get("completion_tokens", 0),
                "total_tokens": usage.get("total_tokens", 0)
            }
        else:
            # Fallback para estruturas diferentes
            tokens_info = {
                "prompt_tokens": 0,
                "completion_tokens": 0,
                "total_tokens": 0
            }
        
        # Usar modelo fornecido ou padrão
        model_name = model or DEFAULT_MODEL
        
        # Calcular custo
        cost_usd = self.calculate_cost(tokens_info, model_name)
        cost_brl = cost_usd * 5.50  # Conversão aproximada USD para BRL
        
        tokens_info.update({
            "cost": cost_usd,
            "cost_brl": cost_brl,
            "model": model_name,
            "timestamp": datetime.now().isoformat()
        })
        
        # Registrar na sessão
        self.session_costs.append(tokens_info)
        self.total_session_cost += cost_usd
        
        self.logger.info(f"Modelo: {model_name} | Tokens: {tokens_info['total_tokens']} | Custo: ${cost_usd:.4f} (R$ {cost_brl:.4f})")
        
        return tokens_info

    def calculate_cost(self, tokens: Dict[str, int], model: str) -> float:
        """
        Calculate the cost of using a specific AI model based on token usage.
        
        Args:
            tokens (Dict[str, int]): Dictionary containing token counts
            model (str): Name of the AI model used
            
        Returns:
            float: Total cost in USD
        """
        if model not in self.MODEL_COSTS:
            self.logger.warning(f"Modelo {model} não encontrado na tabela de custos. Usando custo zero.")
            return 0.0
        
        costs = self.MODEL_COSTS[model]
        prompt_cost = (tokens.get("prompt_tokens", 0) / 1000) * costs["prompt"]
        completion_cost = (tokens.get("completion_tokens", 0) / 1000) * costs["completion"]
        
        total_cost = prompt_cost + completion_cost
        
        return total_cost
    
    def get_session_summary(self) -> Dict[str, Any]:
        """
        Retorna resumo da sessão de custos
        """
        if not self.session_costs:
            return {
                "total_requests": 0,
                "total_tokens": 0,
                "total_cost_usd": 0.0,
                "total_cost_brl": 0.0,
                "models_used": [],
                "cost_breakdown": {}
            }
        
        total_tokens = sum(item["total_tokens"] for item in self.session_costs)
        total_cost_brl = sum(item["cost_brl"] for item in self.session_costs)
        models_used = list(set(item["model"] for item in self.session_costs))
        
        # Breakdown por modelo
        cost_breakdown = {}
        for item in self.session_costs:
            model = item["model"]
            if model not in cost_breakdown:
                cost_breakdown[model] = {
                    "requests": 0,
                    "tokens": 0,
                    "cost_usd": 0.0,
                    "cost_brl": 0.0
                }
            cost_breakdown[model]["requests"] += 1
            cost_breakdown[model]["tokens"] += item["total_tokens"]
            cost_breakdown[model]["cost_usd"] += item["cost"]
            cost_breakdown[model]["cost_brl"] += item["cost_brl"]
        
        return {
            "total_requests": len(self.session_costs),
            "total_tokens": total_tokens,
            "total_cost_usd": self.total_session_cost,
            "total_cost_brl": total_cost_brl,
            "models_used": models_used,
            "cost_breakdown": cost_breakdown,
            "session_start": self.session_costs[0]["timestamp"] if self.session_costs else None,
            "session_end": self.session_costs[-1]["timestamp"] if self.session_costs else None
        }
    
    def get_cost_estimate_for_analysis(self, programs: List[Any], model: str = None) -> Dict[str, Any]:
        """
        Estima custo para análise de programas COBOL
        """
        model_name = model or DEFAULT_MODEL
        
        # Estimativa baseada no tamanho dos programas
        total_lines = sum(len(program.content.split('\n')) for program in programs)
        
        # Estimativa de tokens (aproximadamente 1 token por 4 caracteres)
        estimated_prompt_tokens = sum(len(program.content) // 4 for program in programs)
        estimated_completion_tokens = estimated_prompt_tokens * 0.3  # Estimativa de resposta
        
        estimated_tokens = {
            "prompt_tokens": int(estimated_prompt_tokens),
            "completion_tokens": int(estimated_completion_tokens),
            "total_tokens": int(estimated_prompt_tokens + estimated_completion_tokens)
        }
        
        estimated_cost = self.calculate_cost(estimated_tokens, model_name)
        estimated_cost_brl = estimated_cost * 5.50
        
        return {
            "programs_count": len(programs),
            "total_lines": total_lines,
            "estimated_tokens": estimated_tokens,
            "estimated_cost_usd": estimated_cost,
            "estimated_cost_brl": estimated_cost_brl,
            "model": model_name,
            "note": "Estimativa baseada no tamanho do código. Custo real pode variar."
        }
    
    def reset_session(self):
        """Reset session costs"""
        self.session_costs = []
        self.total_session_cost = 0.0
        self.logger.info("Sessão de custos resetada")
