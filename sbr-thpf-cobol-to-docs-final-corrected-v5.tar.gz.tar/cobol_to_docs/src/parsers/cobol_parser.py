
'''
COBOL AI Engine v2.1.0 - COBOL Parser
Parser avançado para programas COBOL e copybooks.
'''

import logging
import re
import os
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass


@dataclass
class CobolProgram:
    """Representa um programa COBOL parseado."""
    name: str
    content: str
    line_count: int
    size: int
    divisions: Dict[str, str]
    sections: List[str]
    variables: List[str]
    files: List[str]
    file_path: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte para dicionário."""
        return {
            'name': self.name,
            'content': self.content,
            'line_count': self.line_count,
            'size': self.size,
            'divisions': self.divisions,
            'sections': self.sections,
            'variables': self.variables,
            'files': self.files,
            'file_path': self.file_path
        }


@dataclass
class CobolBook:
    """Representa um copybook COBOL."""
    name: str
    content: str
    line_count: int
    size: int
    structures: List[str]
    file_path: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte para dicionário."""
        return {
            'name': self.name,
            'content': self.content,
            'line_count': self.line_count,
            'size': self.size,
            'structures': self.structures,
            'file_path': self.file_path
        }


class COBOLParser:
    """
    Parser avançado para programas COBOL e copybooks.
    
    Funcionalidades:
    - Parse de arquivos empilhados (VMEMBER NAME)
    - Extração de programas e copybooks
    - Análise de estrutura COBOL
    - Identificação de divisões e seções
    - Extração de variáveis e arquivos
    """
    
    def __init__(self):
        """Inicializa o parser COBOL."""
        self.logger = logging.getLogger(__name__)
        
        # Padrões regex para parsing
        self.vmember_pattern = re.compile(r'^\s*VMEMBER\s+NAME\s+([A-Z0-9]+)', re.IGNORECASE)
        self.division_pattern = re.compile(r'^\s*([A-Z]+)\s+DIVISION\.', re.IGNORECASE)
        self.section_pattern = re.compile(r'^\s*([A-Z0-9\-]+)\s+SECTION\.', re.IGNORECASE)
        self.variable_pattern = re.compile(r'^\s*\d+\s+([A-Z0-9\-]+)', re.IGNORECASE)
        self.file_pattern = re.compile(r'^\s*SELECT\s+([A-Z0-9\-]+)', re.IGNORECASE)
        self.structure_pattern = re.compile(r'^\s*01\s+([A-Z0-9\-]+)\.', re.IGNORECASE)

        self.logger.info("COBOL Parser inicializado")
    
    def parse_program(self, content: str, file_path: str = None, all_copybook_contents: Optional[Dict[str, str]] = None) -> CobolProgram:
        """
        Parse de um programa COBOL individual.
        
        Args:
            content: Conteúdo do programa COBOL
            file_path: Caminho do arquivo (opcional)
            
        Returns:
            CobolProgram: Programa parseado
        """
        # Extrair nome do programa
        program_name = "UNKNOWN"
        if file_path:
            program_name = os.path.splitext(os.path.basename(file_path))[0]
        
        # Buscar PROGRAM-ID no conteúdo
        program_id_match = re.search(r'PROGRAM-ID\.\s+([A-Z0-9\-]+)', content, re.IGNORECASE)
        if program_id_match:
            program_name = program_id_match.group(1)
        
        # Resolver copybooks antes de parsear o programa
        if all_copybook_contents:
            resolved_content = self._resolve_copybooks(content, all_copybook_contents)
        else:
            resolved_content = content

        # Parse do programa
        # all_copybook_contents é usado por _resolve_copybooks, não diretamente por _parse_program
        return self._parse_program(program_name, resolved_content, file_path=file_path)
    
    def parse_file(self, file_path: str, copybook_dirs: Optional[List[str]] = None, base_path: str = ".") -> Tuple[List[CobolProgram], List[CobolBook]]:
        """
        Parse de arquivo COBOL, incluindo programas e copybooks, e resolve COPY statements.
        
        Args:
            file_path: Caminho para o arquivo.
            copybook_dirs: Lista de diretórios onde procurar copybooks externos.
            
        Returns:
            Tuple[List[CobolProgram], List[CobolBook]]: Programas e copybooks encontrados e processados.
        """
        all_programs: List[CobolProgram] = []
        all_copybooks: List[CobolBook] = []
        
        try:
            if not os.path.exists(file_path):
                self.logger.error(f"Arquivo não encontrado: {file_path}")
                return [], []
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            self.logger.info(f"Iniciando parse do arquivo: {file_path}")
            
	            # 1. Coletar todos os membros (programas e copybooks) do arquivo
	            members_content: Dict[str, str] = self._split_by_vmember(content, file_path)
            
            if not members_content:
                self.logger.warning(f"Nenhum membro encontrado no arquivo: {file_path}")
                return [], []

            self.logger.info(f"Membros encontrados no arquivo {file_path}: {list(members_content.keys())}")

            # 2. Separar programas e copybooks e construir um mapa de copybooks
            temp_programs_raw: Dict[str, str] = {}
            copybook_map: Dict[str, str] = {}
            
            for name, member_content in members_content.items():
                if self._is_program(member_content):
                    temp_programs_raw[name] = member_content
                else:
                    # Considerar todos os outros membros como copybooks
                    book = self._parse_book(name, member_content, file_path=file_path)
                    all_copybooks.append(book)
                    copybook_map[name.upper()] = book.content # Store content for internal copybooks
            
	            # 3. Adicionar copybooks de diretórios externos ao mapa
	            # O base_path é o diretório do arquivo fontes.txt/BOOKS.txt, que é o diretório base para copybooks
	            if base_path and os.path.isdir(base_path):
	                for root, _, files in os.walk(base_path):
	                    for f_name in files:
	                        if f_name.upper().endswith((".CPY", ".CBL")):
	                            c_name = os.path.splitext(f_name)[0].upper()
	                            # Only add if not already defined by an internal copybook
	                            if c_name not in copybook_map:
	                                try:
	                                    with open(os.path.join(root, f_name), 'r', encoding='utf-8', errors='ignore') as cb_f:
	                                        copybook_map[c_name] = cb_f.read()
	                                    self.logger.debug(f"Copybook externo encontrado e lido: {c_name} em {os.path.join(root, f_name)}")
	                                except Exception as cb_e:
	                                    self.logger.error(f"Erro ao ler copybook externo {c_name} em {os.path.join(root, f_name)}: {str(cb_e)}")
	                                    copybook_map[c_name] = "" # Store empty content on error
	            
	            # Adicionar copybooks de diretórios externos fornecidos pelo usuário
	            if copybook_dirs:
	                for c_dir in copybook_dirs:
	                    if os.path.isdir(c_dir):
	                        for root, _, files in os.walk(c_dir):
	                            for f_name in files:
	                                if f_name.upper().endswith((".CPY", ".CBL")):
	                                    c_name = os.path.splitext(f_name)[0].upper()
	                                    # Only add if not already defined by an internal copybook
	                                    if c_name not in copybook_map:
	                                        try:
	                                            with open(os.path.join(root, f_name), 'r', encoding='utf-8', errors='ignore') as cb_f:
	                                                copybook_map[c_name] = cb_f.read()
	                                            self.logger.debug(f"Copybook externo encontrado e lido: {c_name} em {os.path.join(root, f_name)}")
	                                        except Exception as cb_e:
	                                            self.logger.error(f"Erro ao ler copybook externo {c_name} em {os.path.join(root, f_name)}: {str(cb_e)}")
	                                            copybook_map[c_name] = "" # Store empty content on error
	                    else:
	                        self.logger.warning(f"Diretório de copybook não encontrado: {c_dir}")
            
            # 4. Processar programas, resolvendo copybooks
            for program_name, program_content_raw in temp_programs_raw.items():
                self.logger.info(f"Processando programa {program_name} para resolução de copybooks.")
                resolved_program_content = self._resolve_copybooks(program_content_raw, copybook_map)
                program = self._parse_program(program_name, resolved_program_content, file_path=file_path)
                all_programs.append(program)
                self.logger.info(f"Programa {program_name} parseado com copybooks resolvidos.")
                    
        except Exception as e:
            self.logger.error(f"Erro crítico ao parsear arquivo {file_path}: {str(e)}")
            
        return all_programs, all_copybooks
    def _split_by_vmember(self, content: str, file_path: Optional[str] = None, base_path: str = ".") -> Dict[str, str]:
        """
        Divide o conteúdo por VMEMBER NAME, tratando o conteúdo antes do primeiro VMEMBER como um membro.
        
        Args:
            content: Conteúdo do arquivo
            file_path: Caminho do arquivo original, usado para nomear o membro inicial se não houver PROGRAM-ID.
            
        Returns:
            Dict[str, str]: Dicionário com nome do membro e seu conteúdo
        """
        members = {}
        lines = content.split('\n')
        
        members = {}
        
        # Se o arquivo de entrada for um arquivo de lista (fontes.txt ou books.txt),
        # o conteúdo é uma lista de caminhos para os programas/copybooks.
        lines = [line.strip() for line in content.split('\n') if line.strip()]
        
        # O conteúdo aqui é de um único arquivo COBOL, pois a lógica de lista foi movida para main.py.
        
        # Tentativa 1: Tratar como arquivo COBOL com ou sem VMEMBERs

        # Tentativa 2: Tratar como arquivo COBOL com ou sem VMEMBERs
        lines = content.split('\n')
        
        # Find the first VMEMBER NAME
        first_vmember_line_idx = -1
        for i, line in enumerate(lines):
            if self.vmember_pattern.match(line):
                first_vmember_line_idx = i
                break

        # Handle content before the first VMEMBER NAME
        if first_vmember_line_idx != 0: # There is content before the first VMEMBER or no VMEMBER at all
            initial_segment_content = "\n".join(lines[:first_vmember_line_idx if first_vmember_line_idx != -1 else len(lines)])
            if initial_segment_content.strip(): # Only add if there's actual content
                program_id_match = re.search(r'PROGRAM-ID\.\s+([A-Z0-9\-]+)', initial_segment_content, re.IGNORECASE)
                if program_id_match:
                    initial_member_name = program_id_match.group(1)
                else:
                    # Use filename as a fallback if no PROGRAM-ID and it's likely a single file
                    if first_vmember_line_idx == -1 and file_path:
                        initial_member_name = os.path.splitext(os.path.basename(file_path))[0]
                    else:
                        initial_member_name = "UNKNOWN_INITIAL_MEMBER"
                members[initial_member_name] = initial_segment_content

        # Process subsequent VMEMBERs
        current_member_name = None
        current_member_content = []
        
        start_line_idx = first_vmember_line_idx if first_vmember_line_idx != -1 else len(lines) # Start from first VMEMBER or end if none

        for line in lines[start_line_idx:]:
            vmember_match = self.vmember_pattern.match(line)
            if vmember_match:
                if current_member_name and current_member_content:
                    members[current_member_name] = "\n".join(current_member_content)
                
                current_member_name = vmember_match.group(1)
                current_member_content = []
            else:
                current_member_content.append(line)
        
        # Add the last member
        if current_member_name and current_member_content:
            members[current_member_name] = "\n".join(current_member_content)

        return members
    
    def _is_program(self, content: str) -> bool:
        """
        Verifica se o conteúdo é um programa COBOL.
        
        Args:
            content: Conteúdo a verificar
            
        Returns:
            bool: True se for programa, False se for copybook
        """
        # Um programa COBOL deve ter pelo menos PROGRAM-ID e PROCEDURE DIVISION
        content_upper = content.upper()
        has_program_id = any(indicator in content_upper for indicator in ["PROGRAM-ID", "IDENTIFICATION DIVISION", "ID DIVISION"])
        has_procedure_division = "PROCEDURE DIVISION" in content_upper
        
        return has_program_id and has_procedure_division
    
    def _extract_divisions(self, content: str) -> Dict[str, str]:
        """
        Extrai as divisões de um programa COBOL.
        """
        divisions = {}
        current_division = None
        current_content = []
        
        for line in content.split('\n'):
            match = self.division_pattern.match(line)
            if match:
                if current_division:
                    divisions[current_division] = '\n'.join(current_content).strip()
                current_division = match.group(1)
                current_content = [line] # Incluir a linha da divisão
            elif current_division:
                current_content.append(line)
        
        if current_division:
            divisions[current_division] = '\n'.join(current_content).strip()
            
        return divisions

    def _extract_sections(self, content: str) -> List[str]:
        """
        Extrai as seções de um programa COBOL.
        """
        sections = []
        for line in content.split('\n'):
            match = self.section_pattern.match(line)
            if match:
                sections.append(match.group(1))
        return sections

    def _extract_variables(self, content: str) -> List[str]:
        """
        Extrai as variáveis de um programa COBOL (nível 01, 77, 88).
        """
        variables = []
        for line in content.split('\n'):
            # Regex para capturar variáveis de nível 01, 77, 88
            match = re.match(r'^\s*(01|77|88)\s+([A-Z0-9\-]+)(?:\s+PIC.*)?\.', line, re.IGNORECASE)
            if match:
                variables.append(match.group(2))
        return variables

    def _extract_files(self, content: str) -> List[str]:
        """
        Extrai os nomes de arquivos declarados na SELECT clause.
        """
        files = []
        for line in content.split('\n'):
            match = self.file_pattern.match(line)
            if match:
                files.append(match.group(1))
        return files

    def _extract_structures(self, content: str) -> List[str]:
        """
        Extrai as estruturas de nível 01 de um copybook.
        """
        structures = []
        for line in content.split('\n'):
            match = self.structure_pattern.match(line)
            if match:
                structures.append(match.group(1))
        return structures

    def _resolve_copybooks(self, program_content: str, all_copybook_contents: Dict[str, str]) -> str:
        """
        Resolve as declarações COPY em um programa COBOL.
        """
        resolved_content = program_content
        # Regex para encontrar COPY statements
        copy_pattern = re.compile(r'^\s*COPY\s+([A-Z0-9\-]+)\s*\.', re.IGNORECASE | re.MULTILINE)
        
        for match in copy_pattern.finditer(program_content):
            copybook_name = match.group(1).upper()
            if copybook_name in all_copybook_contents:
                self.logger.debug(f"Resolvendo COPY {copybook_name}")
                # Substituir a declaração COPY pelo conteúdo do copybook
                # Adicionar identação para manter a formatação, se possível
                copybook_lines = all_copybook_contents[copybook_name].split('\n')
                # Tentar inferir a identação da linha COPY
                indent = len(match.group(0)) - len(match.group(0).lstrip())
                indented_copybook_content = '\n'.join([(' ' * indent) + line for line in copybook_lines])
                resolved_content = resolved_content.replace(match.group(0), indented_copybook_content)
            else:
                self.logger.warning(f"Copybook {copybook_name} não encontrado para resolução.")
        return resolved_content

    def _parse_program(self, name: str, content: str, file_path: Optional[str] = None) -> CobolProgram:
        """
        Parse de um programa COBOL.
        
        Args:
            name: Nome do programa.
            content: Conteúdo do programa.
            file_path: Caminho do arquivo original.
            
        Returns:
            CobolProgram: Objeto CobolProgram parseado.
        """
        return CobolProgram(
            name=name,
            content=content,
            line_count=len(content.split('\n')),
            size=len(content.encode("utf-8")),
            divisions=self._extract_divisions(content),
            sections=self._extract_sections(content),
            variables=self._extract_variables(content),
            files=self._extract_files(content),
            file_path=file_path
        )

    def _parse_book(self, name: str, content: str, file_path: Optional[str] = None) -> CobolBook:
        """
        Parse de um copybook COBOL.
        
        Args:
            name: Nome do copybook.
            content: Conteúdo do copybook.
            file_path: Caminho do arquivo original.
            
        Returns:
            CobolBook: Objeto CobolBook parseado.
        """
        return CobolBook(
            name=name,
            content=content,
            line_count=len(content.split('\n')),
            size=len(content.encode("utf-8")),
            structures=self._extract_structures(content),
            file_path=file_path
        )

