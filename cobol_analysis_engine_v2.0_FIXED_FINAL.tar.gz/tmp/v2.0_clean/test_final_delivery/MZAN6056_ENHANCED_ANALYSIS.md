# Análise Detalhada do Programa: MZAN6056

**Data da Análise:** 20/09/2025 22:11:42  
**Autor:** N/A  
**Data de Criação:** N/A  
**Tipo:** Programa COBOL  

---

## Informações Extraídas dos Arquivos COBOL


**Copybooks Utilizados:**
- LHCP3402: Disponível
- LHCE0700: Disponível
- LHCE0400: Disponível
- DRR00082: Disponível
- LHCE0430: Disponível
- MZTC5001: Disponível
- MZCE6001: Disponível
- MZCE5113: Disponível
- MZTCM530: Disponível
- MZTCL000: Disponível
- MZTCL040: Disponível

---

## Análise Enriquecida por Inteligência Artificial

### Análise Estruturada

**Objetivo Identificado:** Análise do programa MZAN6056 (IA indisponível: 'str' object has no attribute 'get')

**Regras de Negócio:**
1. Análise de regras requer IA funcional

**Aspectos Técnicos:**
1. Análise técnica requer IA funcional

**Particularidades:**
1. Análise de particularidades requer IA funcional

---

## Resumo Consolidado

**Objetivo do Programa:**
- Análise do programa MZAN6056 (IA indisponível: 'str' object has no attribute 'get')

**Estatísticas do Processamento:**
- Copybooks utilizados: 11
- Divisões identificadas: 0
- Seções mapeadas: 0
- Parágrafos analisados: 0
- Análise por IA: Executada

---

## Respostas Originais das IAs

Esta seção preserva todas as interações com as IAs, incluindo prompts enviados e respostas recebidas, garantindo transparência total.

**Status:** Nenhuma interação com IA foi registrada.

## Estatísticas Finais

### Estatísticas Gerais

- **Total Programs:** 5
- **Successful Analyses:** 0
- **Failed Analyses:** 5
- **Total Tokens:** 0
- **Total Time:** 0.00s
- **Copybooks Processed:** 55
- **Retries Performed:** 0

**Relatório gerado em:** 20/09/2025 22:11:42
**Sistema:** COBOL Analysis Engine v2.0 - Preservação de Respostas Originais
