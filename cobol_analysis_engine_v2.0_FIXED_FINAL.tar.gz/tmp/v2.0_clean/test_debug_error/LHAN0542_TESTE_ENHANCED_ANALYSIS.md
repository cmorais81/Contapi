# Análise Detalhada do Programa: LHAN0542_TESTE

**Data da Análise:** 20/09/2025 22:01:16  
**Autor:** EDIVALDO-DEDIC/GPTI  
**Data de Criação:** 11/01/11  
**Tipo:** Programa COBOL  

---

## Informações Extraídas dos Arquivos

### Dados do Programa COBOL

---

## Enriquecimento com Análise de IA

### Análise Inteligente

**Objetivo Identificado:** Análise do programa LHAN0542_TESTE (IA indisponível: Análise IA indisponível)

**Regras de Negócio Identificadas:**
1. Análise de regras requer IA funcional

**Aspectos Técnicos:**
1. Análise técnica requer IA funcional

**Particularidades:**
1. Análise de particularidades requer IA funcional

---

## Análise Consolidada

### Resumo Executivo

**Objetivo do Programa:**
- Análise IA: Análise do programa LHAN0542_TESTE (IA indisponível: Análise IA indisponível)

**Estatísticas:**
- Copybooks integrados: 0
- Divisões identificadas: 0
- Seções mapeadas: 0
- Parágrafos analisados: 0
- Análise IA: Disponível

---

## Detalhes da Análise com IA

### Análise 1: unified_analysis

**Provedor:** LUZIA
**Modelo:** N/A
**Tempo:** 0.00s
**Status:** Falha

**Prompt enviado:**
```
Analise o programa COBOL abaixo de forma COMPLETA e UNIFICADA:

**PROGRAMA:** LHAN0542_TESTE
\n\nCOMENTÁRIOS DO PROGRAMA:\nOBJETIVO:\n- OBJETIVO DO PROGRAMA ***********************\n


**CÓDIGO COBOL:**
```cobol
       IDENTIFICATION                  DIVISION.                                
      *---------------------------------------------------------------*         
       PROGRAM-ID.     LHAN0542.                                                
       AUTHOR.         EDIVALDO-DEDIC/GPTI.  \n... [prompt truncado - muito longo]
```

**Resposta original do LUZIA:**
```
Tentativa 1 falhou - tentando novamente
```

---

### Análise 2: unified_analysis

**Provedor:** LUZIA
**Modelo:** N/A
**Tempo:** 0.00s
**Status:** Falha

**Prompt enviado:**
```
Analise o programa COBOL abaixo de forma COMPLETA e UNIFICADA:

**PROGRAMA:** LHAN0542_TESTE
\n\nCOMENTÁRIOS DO PROGRAMA:\nOBJETIVO:\n- OBJETIVO DO PROGRAMA ***********************\n


**CÓDIGO COBOL:**
```cobol
       IDENTIFICATION                  DIVISION.                                
      *---------------------------------------------------------------*         
       PROGRAM-ID.     LHAN0542.                                                
       AUTHOR.         EDIVALDO-DEDIC/GPTI.  \n... [prompt truncado - muito longo]
```

**Resposta original do LUZIA:**
```
Tentativa 2 falhou - tentando novamente
```

---

### Análise 3: unified_analysis

**Provedor:** LUZIA
**Modelo:** N/A
**Tempo:** 0.00s
**Status:** Falha

**Prompt enviado:**
```
Analise o programa COBOL abaixo de forma COMPLETA e UNIFICADA:

**PROGRAMA:** LHAN0542_TESTE
\n\nCOMENTÁRIOS DO PROGRAMA:\nOBJETIVO:\n- OBJETIVO DO PROGRAMA ***********************\n


**CÓDIGO COBOL:**
```cobol
       IDENTIFICATION                  DIVISION.                                
      *---------------------------------------------------------------*         
       PROGRAM-ID.     LHAN0542.                                                
       AUTHOR.         EDIVALDO-DEDIC/GPTI.  \n... [prompt truncado - muito longo]
```

**Resposta original do LUZIA:**
```
Tentativa 3 falhou - tentando novamente
```

---

### Análise 4: unified_analysis

**Provedor:** LUZIA
**Modelo:** N/A
**Tempo:** 0.00s
**Status:** Falha

**Prompt enviado:**
```
Analise o programa COBOL abaixo de forma COMPLETA e UNIFICADA:

**PROGRAMA:** LHAN0542_TESTE
\n\nCOMENTÁRIOS DO PROGRAMA:\nOBJETIVO:\n- OBJETIVO DO PROGRAMA ***********************\n


**CÓDIGO COBOL:**
```cobol
       IDENTIFICATION                  DIVISION.                                
      *---------------------------------------------------------------*         
       PROGRAM-ID.     LHAN0542.                                                
       AUTHOR.         EDIVALDO-DEDIC/GPTI.  \n... [prompt truncado - muito longo]
```

**Resposta original do LUZIA:**
```
Falha após 4 tentativas
```

---

**Resumo das Análises:**
- Total de análises: 4
- Análises bem-sucedidas: 0
- Taxa de sucesso: 0.0%

