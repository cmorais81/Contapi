# Relatório de Processamento em Lote - COBOL Analysis Engine

**Data:** 20/09/2025 22:08:35  
**Total de Programas:** 5  
**Sucessos:** 0  
**Falhas:** 5  
**Taxa de Sucesso:** 0.0%  

---

## Programas Processados com Sucesso


## Programas com Falha

- **LHAN0542**: Erro ao processar LHAN0542: 'str' object has no attribute 'get'
- **LHAN0705**: Erro ao processar LHAN0705: 'str' object has no attribute 'get'
- **LHAN0706**: Erro ao processar LHAN0706: 'str' object has no attribute 'get'
- **LHBR0700**: Erro ao processar LHBR0700: 'str' object has no attribute 'get'
- **MZAN6056**: Erro ao processar MZAN6056: 'str' object has no attribute 'get'

---

*Processamento concluído em test_batch_transparent/*
