# Análise Detalhada do Programa: LHAN0542

**Data da Análise:** 20/09/2025 22:10:02  
**Autor:** N/A  
**Data de Criação:** N/A  
**Tipo:** Programa COBOL  

---

## Informações Extraídas dos Arquivos

### Dados do Programa COBOL


**Copybooks Referenciados:**
- LHCP3402: Dados disponíveis
- LHCE0700: Dados disponíveis
- LHCE0400: Dados disponíveis
- DRR00082: Dados disponíveis
- LHCE0430: Dados disponíveis
- MZTC5001: Dados disponíveis
- MZCE6001: Dados disponíveis
- MZCE5113: Dados disponíveis
- MZTCM530: Dados disponíveis
- MZTCL000: Dados disponíveis
- MZTCL040: Dados disponíveis

---

## Enriquecimento com Análise de IA

### Análise Inteligente

**Objetivo Identificado:** Análise do programa LHAN0542 (IA indisponível: 'str' object has no attribute 'get')

**Regras de Negócio Identificadas:**
1. Análise de regras requer IA funcional

**Aspectos Técnicos:**
1. Análise técnica requer IA funcional

**Particularidades:**
1. Análise de particularidades requer IA funcional

---

## Análise Consolidada

### Resumo Executivo

**Objetivo do Programa:**
- Análise IA: Análise do programa LHAN0542 (IA indisponível: 'str' object has no attribute 'get')

**Estatísticas:**
- Copybooks integrados: 11
- Divisões identificadas: 0
- Seções mapeadas: 0
- Parágrafos analisados: 0
- Análise IA: Disponível

---

## Transparência Completa - Prompts e Respostas da IA

**Status:** Nenhuma interação com IA registrada.

**Motivo:** Sistema funcionando no modo básico ou falha na conectividade.

## Estatísticas Finais de Processamento

### Estatísticas Gerais do Sistema

- **Total Programs:** 1
- **Successful Analyses:** 0
- **Failed Analyses:** 1
- **Total Tokens:** 0
- **Total Time:** 0.00s
- **Copybooks Processed:** 11
- **Retries Performed:** 0

---

**Relatório gerado em:** 20/09/2025 22:10:02
**Sistema:** COBOL Analysis Engine v2.0
