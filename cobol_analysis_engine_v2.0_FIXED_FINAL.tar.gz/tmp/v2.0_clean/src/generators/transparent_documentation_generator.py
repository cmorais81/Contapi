# -*- coding: utf-8 -*-
"""
Gerador de documentação com transparência total que mostra:
1. Informações extraídas dos arquivos COBOL primeiro
2. Enriquecimento pelas análises de IA depois
3. Prompts e respostas originais completos no final
4. Estatísticas detalhadas de processamento
"""

import time
from typing import Dict, Any, List, Optional

class TransparentDocumentationGenerator:
    """Gerador de documentação com transparência total"""
    
    def __init__(self):
        self.prompt_history = []
        self.statistics = {}
    
    def generate_documentation(
        self, 
        extracted_data: Dict[str, Any], 
        ai_analyses: Dict[str, Any] = None,
        prompt_history: List[Dict] = None,
        statistics: Dict[str, Any] = None,
        output_path: str = ""
    ) -> str:
        """Gera documentação com transparência total"""
        
        if prompt_history:
            self.prompt_history = prompt_history
        
        if statistics:
            self.statistics = statistics
        
        program_name = extracted_data.get('program_name', 'PROGRAMA_DESCONHECIDO')
        
        # Construir documentação
        doc = self._build_header(program_name, extracted_data)
        doc += self._build_file_information_section(extracted_data)
        doc += self._build_ai_enrichment_section(ai_analyses)
        doc += self._build_consolidated_analysis_section(extracted_data, ai_analyses)
        doc += self._build_complete_transparency_section()
        doc += self._build_final_statistics_section()
        
        # Salvar arquivo
        if output_path:
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(doc)
        
        return doc
    
    def _build_header(self, program_name: str, extracted_data: Dict[str, Any]) -> str:
        """Constrói cabeçalho do documento"""
        
        timestamp = time.strftime('%d/%m/%Y %H:%M:%S')
        
        return f"""# Análise Detalhada do Programa: {program_name}

**Data da Análise:** {timestamp}  
**Autor:** {extracted_data.get('author', 'N/A')}  
**Data de Criação:** {extracted_data.get('date_written', 'N/A')}  
**Tipo:** Programa COBOL  

---

"""
    
    def _build_file_information_section(self, extracted_data: Dict[str, Any]) -> str:
        """Constrói seção com informações extraídas dos arquivos"""
        
        section = "## Informações Extraídas dos Arquivos\n\n"
        section += "### Dados do Programa COBOL\n\n"
        
        # Informações básicas
        if extracted_data.get('program_id'):
            section += f"**Program-ID:** {extracted_data['program_id']}\n"
        
        if extracted_data.get('author'):
            section += f"**Autor:** {extracted_data['author']}\n"
        
        if extracted_data.get('date_written'):
            section += f"**Data de Criação:** {extracted_data['date_written']}\n"
        
        if extracted_data.get('date_compiled'):
            section += f"**Data de Compilação:** {extracted_data['date_compiled']}\n"
        
        # Comentários do programa
        comments = extracted_data.get('comments', [])
        if comments:
            section += "\n**Comentários do Programa:**\n"
            for comment in comments[:10]:  # Limitar a 10 comentários
                section += f"- {comment}\n"
            if len(comments) > 10:
                section += f"- ... e mais {len(comments) - 10} comentários\n"
        
        # Estrutura do programa
        structure = extracted_data.get('structure', {})
        if structure:
            section += "\n**Estrutura Identificada:**\n"
            
            divisions = structure.get('divisions', [])
            if divisions:
                section += f"- Divisões: {', '.join(divisions)}\n"
            
            sections = structure.get('sections', [])
            if sections:
                section += f"- Seções: {len(sections)} identificadas\n"
            
            paragraphs = structure.get('paragraphs', [])
            if paragraphs:
                section += f"- Parágrafos: {len(paragraphs)} identificados\n"
        
        # Copybooks
        copybooks = extracted_data.get('copybooks', {})
        if copybooks:
            section += "\n**Copybooks Referenciados:**\n"
            if isinstance(copybooks, dict):
                for copybook_name, copybook_data in copybooks.items():
                    if isinstance(copybook_data, dict):
                        section += f"- {copybook_name}: {len(copybook_data.get('fields', []))} campos\n"
                    else:
                        section += f"- {copybook_name}: Dados disponíveis\n"
            else:
                section += f"- {len(copybooks) if hasattr(copybooks, '__len__') else 'N/A'} copybooks disponíveis\n"
        
        section += "\n---\n\n"
        return section
    
    def _build_ai_enrichment_section(self, ai_analyses: Dict[str, Any]) -> str:
        """Constrói seção com enriquecimento das análises de IA"""
        
        section = "## Enriquecimento com Análise de IA\n\n"
        
        if not ai_analyses or not ai_analyses.get('main_analysis'):
            section += "### Análise Inteligente\n\n"
            section += "**Status:** Análise de IA não disponível ou falhou\n\n"
            section += "**Motivo:** Sistema funcionando no modo básico\n\n"
            section += "---\n\n"
            return section
        
        main_analysis = ai_analyses.get('main_analysis', {})
        
        section += "### Análise Inteligente\n\n"
        
        # Objetivo identificado
        objective = main_analysis.get('objective', '')
        if objective:
            section += f"**Objetivo Identificado:** {objective}\n\n"
        
        # Regras de negócio
        business_rules = main_analysis.get('business_rules', [])
        if business_rules:
            section += "**Regras de Negócio Identificadas:**\n"
            for i, rule in enumerate(business_rules, 1):
                section += f"{i}. {rule}\n"
            section += "\n"
        
        # Aspectos técnicos
        technical_aspects = main_analysis.get('technical_analysis', [])
        if technical_aspects:
            section += "**Aspectos Técnicos:**\n"
            for i, aspect in enumerate(technical_aspects, 1):
                section += f"{i}. {aspect}\n"
            section += "\n"
        
        # Particularidades
        particularities = main_analysis.get('particularities', [])
        if particularities:
            section += "**Particularidades:**\n"
            for i, particularity in enumerate(particularities, 1):
                section += f"{i}. {particularity}\n"
            section += "\n"
        
        section += "---\n\n"
        return section
    
    def _build_consolidated_analysis_section(self, extracted_data: Dict[str, Any], ai_analyses: Dict[str, Any]) -> str:
        """Constrói seção consolidada combinando dados dos arquivos e IA"""
        
        section = "## Análise Consolidada\n\n"
        section += "### Resumo Executivo\n\n"
        
        # Objetivo do programa
        ai_objective = ""
        if ai_analyses and ai_analyses.get('main_analysis'):
            ai_objective = ai_analyses['main_analysis'].get('objective', '')
        
        section += "**Objetivo do Programa:**\n"
        if ai_objective:
            section += f"- Análise IA: {ai_objective}\n"
        else:
            section += "- Análise IA: Não disponível\n"
        
        # Estatísticas básicas
        structure = extracted_data.get('structure', {})
        copybooks = extracted_data.get('copybooks', {})
        
        section += "\n**Estatísticas:**\n"
        section += f"- Copybooks integrados: {len(copybooks)}\n"
        section += f"- Divisões identificadas: {len(structure.get('divisions', []))}\n"
        section += f"- Seções mapeadas: {len(structure.get('sections', []))}\n"
        section += f"- Parágrafos analisados: {len(structure.get('paragraphs', []))}\n"
        
        # Status da análise
        ai_available = bool(ai_analyses and ai_analyses.get('main_analysis'))
        section += f"- Análise IA: {'Disponível' if ai_available else 'Não disponível'}\n"
        
        section += "\n---\n\n"
        return section
    
    def _build_complete_transparency_section(self) -> str:
        """Constrói seção de transparência completa com todos os prompts e respostas"""
        
        section = "## Transparência Completa - Prompts e Respostas da IA\n\n"
        
        if not self.prompt_history:
            section += "**Status:** Nenhuma interação com IA registrada.\n\n"
            section += "**Motivo:** Sistema funcionando no modo básico ou falha na conectividade.\n\n"
            return section
        
        section += "Esta seção apresenta todos os prompts enviados para a IA e suas respostas originais, "
        section += "garantindo transparência total sobre o processo de análise.\n\n"
        
        # Mostrar cada análise completa
        for i, entry in enumerate(self.prompt_history, 1):
            status = "Sucesso" if entry.get('success', False) else "Falha"
            provider = entry.get('provider', 'Desconhecido')
            model = entry.get('model', 'N/A')
            processing_time = entry.get('processing_time', 0)
            
            section += f"### Análise {i}: {entry.get('type', 'unified_analysis')}\n\n"
            section += f"**Provedor:** {provider}\n"
            section += f"**Modelo:** {model}\n"
            section += f"**Tempo:** {processing_time:.2f}s\n"
            section += f"**Status:** {status}\n\n"
            
            # Prompt enviado (completo)
            prompt = entry.get('prompt', '')
            if prompt:
                section += "**Prompt enviado:**\n```\n"
                section += prompt
                section += "\n```\n\n"
            
            # Resposta recebida (completa)
            response = entry.get('response', '')
            if response:
                section += f"**Resposta original do {provider}:**\n```\n"
                section += response
                section += "\n```\n\n"
            
            # Informações adicionais
            if entry.get('tokens_used'):
                section += f"**Tokens utilizados:** {entry['tokens_used']}\n"
            
            if entry.get('error'):
                section += f"**Erro:** {entry['error']}\n"
            
            section += "---\n\n"
        
        return section
    
    def _build_final_statistics_section(self) -> str:
        """Constrói seção final com estatísticas detalhadas"""
        
        section = "## Estatísticas Finais de Processamento\n\n"
        
        # Estatísticas das análises
        if self.prompt_history:
            total_analyses = len(self.prompt_history)
            successful_analyses = len([entry for entry in self.prompt_history if entry.get('success', False)])
            failed_analyses = total_analyses - successful_analyses
            success_rate = (successful_analyses / total_analyses * 100) if total_analyses > 0 else 0
            
            total_time = sum([entry.get('processing_time', 0) for entry in self.prompt_history])
            total_tokens = sum([entry.get('tokens_used', 0) for entry in self.prompt_history])
            
            section += "### Resumo das Análises de IA\n\n"
            section += f"- **Total de análises:** {total_analyses}\n"
            section += f"- **Análises bem-sucedidas:** {successful_analyses}\n"
            section += f"- **Análises falharam:** {failed_analyses}\n"
            section += f"- **Taxa de sucesso:** {success_rate:.1f}%\n"
            section += f"- **Tempo total de processamento:** {total_time:.2f}s\n"
            section += f"- **Total de tokens utilizados:** {total_tokens}\n\n"
            
            # Detalhes por provedor
            providers = {}
            for entry in self.prompt_history:
                provider = entry.get('provider', 'Desconhecido')
                if provider not in providers:
                    providers[provider] = {'total': 0, 'success': 0, 'time': 0, 'tokens': 0}
                
                providers[provider]['total'] += 1
                if entry.get('success', False):
                    providers[provider]['success'] += 1
                providers[provider]['time'] += entry.get('processing_time', 0)
                providers[provider]['tokens'] += entry.get('tokens_used', 0)
            
            if providers:
                section += "### Estatísticas por Provedor\n\n"
                for provider, stats in providers.items():
                    success_rate = (stats['success'] / stats['total'] * 100) if stats['total'] > 0 else 0
                    section += f"**{provider}:**\n"
                    section += f"- Tentativas: {stats['total']}\n"
                    section += f"- Sucessos: {stats['success']}\n"
                    section += f"- Taxa de sucesso: {success_rate:.1f}%\n"
                    section += f"- Tempo total: {stats['time']:.2f}s\n"
                    section += f"- Tokens utilizados: {stats['tokens']}\n\n"
        
        # Estatísticas gerais do sistema
        if self.statistics:
            section += "### Estatísticas Gerais do Sistema\n\n"
            
            for key, value in self.statistics.items():
                if isinstance(value, (int, float)):
                    if 'time' in key.lower():
                        section += f"- **{key.replace('_', ' ').title()}:** {value:.2f}s\n"
                    else:
                        section += f"- **{key.replace('_', ' ').title()}:** {value}\n"
                else:
                    section += f"- **{key.replace('_', ' ').title()}:** {value}\n"
        
        section += "\n---\n\n"
        section += f"**Relatório gerado em:** {time.strftime('%d/%m/%Y %H:%M:%S')}\n"
        section += "**Sistema:** COBOL Analysis Engine v2.0\n"
        
        return section
