# -*- coding: utf-8 -*-
"""
Gerador de documentação que preserva as respostas originais das IAs
Quando não souber tratar uma resposta, grava o retorno original junto com o restante
"""

import time
import json
from typing import Dict, Any, List, Optional

class AIPreservingDocumentationGenerator:
    """Gerador que preserva respostas originais das IAs"""
    
    def __init__(self):
        self.prompt_history = []
        self.statistics = {}
    
    def generate_documentation(
        self, 
        extracted_data: Dict[str, Any], 
        ai_analyses: Dict[str, Any] = None,
        prompt_history: List[Dict] = None,
        statistics: Dict[str, Any] = None,
        output_path: str = ""
    ) -> str:
        """Gera documentação preservando respostas originais das IAs"""
        
        if prompt_history:
            self.prompt_history = prompt_history
        
        if statistics:
            self.statistics = statistics
        
        program_name = extracted_data.get('program_name', 'PROGRAMA_DESCONHECIDO')
        
        # Construir documentação
        doc = self._build_header(program_name, extracted_data)
        doc += self._build_file_information_section(extracted_data)
        doc += self._build_ai_analysis_section(ai_analyses)
        doc += self._build_consolidated_analysis_section(extracted_data, ai_analyses)
        doc += self._build_original_ai_responses_section()
        doc += self._build_final_statistics_section()
        
        # Salvar arquivo
        if output_path:
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(doc)
        
        return doc
    
    def _build_header(self, program_name: str, extracted_data: Dict[str, Any]) -> str:
        """Constrói cabeçalho do documento"""
        
        timestamp = time.strftime('%d/%m/%Y %H:%M:%S')
        
        return f"""# Análise Detalhada do Programa: {program_name}

**Data da Análise:** {timestamp}  
**Autor:** {extracted_data.get('author', 'N/A')}  
**Data de Criação:** {extracted_data.get('date_written', 'N/A')}  
**Tipo:** Programa COBOL  

---

"""
    
    def _build_file_information_section(self, extracted_data: Dict[str, Any]) -> str:
        """Constrói seção com informações extraídas dos arquivos"""
        
        section = "## Informações Extraídas dos Arquivos COBOL\n\n"
        
        # Informações básicas
        if extracted_data.get('program_id'):
            section += f"**Program-ID:** {extracted_data['program_id']}\n"
        
        if extracted_data.get('author'):
            section += f"**Autor:** {extracted_data['author']}\n"
        
        if extracted_data.get('date_written'):
            section += f"**Data de Criação:** {extracted_data['date_written']}\n"
        
        # Comentários do programa
        comments = extracted_data.get('comments', [])
        if comments:
            section += "\n**Comentários Identificados:**\n"
            for comment in comments[:10]:  # Limitar a 10 comentários
                section += f"- {comment}\n"
            if len(comments) > 10:
                section += f"- ... e mais {len(comments) - 10} comentários\n"
        
        # Estrutura do programa
        structure = extracted_data.get('structure', {})
        if structure:
            section += "\n**Estrutura do Programa:**\n"
            
            divisions = structure.get('divisions', [])
            if divisions:
                section += f"- Divisões: {', '.join(divisions)}\n"
            
            sections = structure.get('sections', [])
            if sections:
                section += f"- Seções: {len(sections)} identificadas\n"
            
            paragraphs = structure.get('paragraphs', [])
            if paragraphs:
                section += f"- Parágrafos: {len(paragraphs)} identificados\n"
        
        # Copybooks
        copybooks = extracted_data.get('copybooks', {})
        if copybooks:
            section += "\n**Copybooks Utilizados:**\n"
            if isinstance(copybooks, dict):
                for copybook_name, copybook_data in copybooks.items():
                    if isinstance(copybook_data, dict):
                        fields_count = len(copybook_data.get('fields', []))
                        section += f"- {copybook_name}: {fields_count} campos definidos\n"
                    else:
                        section += f"- {copybook_name}: Disponível\n"
            else:
                section += f"- {len(copybooks) if hasattr(copybooks, '__len__') else 'N/A'} copybooks referenciados\n"
        
        section += "\n---\n\n"
        return section
    
    def _build_ai_analysis_section(self, ai_analyses: Dict[str, Any]) -> str:
        """Constrói seção com análises das IAs, preservando conteúdo original"""
        
        section = "## Análise Enriquecida por Inteligência Artificial\n\n"
        
        if not ai_analyses or not ai_analyses.get('main_analysis'):
            section += "**Status:** Análise por IA não disponível ou não executada.\n\n"
            section += "**Motivo:** Sistema funcionando no modo básico ou falha na conectividade.\n\n"
            section += "---\n\n"
            return section
        
        main_analysis = ai_analyses.get('main_analysis', {})
        
        # Tentar parsear análise estruturada
        if self._is_structured_analysis(main_analysis):
            section += self._format_structured_analysis(main_analysis)
        else:
            # Se não conseguir parsear, preservar conteúdo original
            section += "### Resposta Original da IA\n\n"
            section += "A resposta da IA não pôde ser parseada automaticamente. "
            section += "Conteúdo original preservado abaixo:\n\n"
            
            if isinstance(main_analysis, dict):
                section += "```json\n"
                section += json.dumps(main_analysis, indent=2, ensure_ascii=False)
                section += "\n```\n\n"
            elif isinstance(main_analysis, str):
                section += "```\n"
                section += main_analysis
                section += "\n```\n\n"
            else:
                section += f"**Tipo de dados:** {type(main_analysis)}\n"
                section += f"**Conteúdo:** {str(main_analysis)}\n\n"
        
        section += "---\n\n"
        return section
    
    def _is_structured_analysis(self, analysis: Any) -> bool:
        """Verifica se a análise está em formato estruturado conhecido"""
        
        if not isinstance(analysis, dict):
            return False
        
        # Verificar se tem campos conhecidos
        known_fields = ['objective', 'business_rules', 'technical_analysis', 'particularities']
        return any(field in analysis for field in known_fields)
    
    def _format_structured_analysis(self, analysis: Dict[str, Any]) -> str:
        """Formata análise estruturada"""
        
        section = "### Análise Estruturada\n\n"
        
        # Objetivo
        if 'objective' in analysis:
            section += f"**Objetivo Identificado:** {analysis['objective']}\n\n"
        
        # Regras de negócio
        if 'business_rules' in analysis and analysis['business_rules']:
            section += "**Regras de Negócio:**\n"
            rules = analysis['business_rules']
            if isinstance(rules, list):
                for i, rule in enumerate(rules, 1):
                    section += f"{i}. {rule}\n"
            else:
                section += f"- {rules}\n"
            section += "\n"
        
        # Análise técnica
        if 'technical_analysis' in analysis and analysis['technical_analysis']:
            section += "**Aspectos Técnicos:**\n"
            tech = analysis['technical_analysis']
            if isinstance(tech, list):
                for i, aspect in enumerate(tech, 1):
                    section += f"{i}. {aspect}\n"
            else:
                section += f"- {tech}\n"
            section += "\n"
        
        # Particularidades
        if 'particularities' in analysis and analysis['particularities']:
            section += "**Particularidades:**\n"
            parts = analysis['particularities']
            if isinstance(parts, list):
                for i, part in enumerate(parts, 1):
                    section += f"{i}. {part}\n"
            else:
                section += f"- {parts}\n"
            section += "\n"
        
        return section
    
    def _build_consolidated_analysis_section(self, extracted_data: Dict[str, Any], ai_analyses: Dict[str, Any]) -> str:
        """Constrói seção consolidada"""
        
        section = "## Resumo Consolidado\n\n"
        
        # Objetivo do programa
        ai_objective = ""
        if ai_analyses and ai_analyses.get('main_analysis'):
            main_analysis = ai_analyses['main_analysis']
            if isinstance(main_analysis, dict) and 'objective' in main_analysis:
                ai_objective = main_analysis['objective']
            elif isinstance(main_analysis, str):
                ai_objective = "Análise textual disponível (ver seção de respostas originais)"
        
        section += "**Objetivo do Programa:**\n"
        if ai_objective:
            section += f"- {ai_objective}\n"
        else:
            section += "- Não identificado automaticamente\n"
        
        # Estatísticas
        structure = extracted_data.get('structure', {})
        copybooks = extracted_data.get('copybooks', {})
        
        section += "\n**Estatísticas do Processamento:**\n"
        section += f"- Copybooks utilizados: {len(copybooks) if copybooks else 0}\n"
        section += f"- Divisões identificadas: {len(structure.get('divisions', []))}\n"
        section += f"- Seções mapeadas: {len(structure.get('sections', []))}\n"
        section += f"- Parágrafos analisados: {len(structure.get('paragraphs', []))}\n"
        
        # Status da análise
        ai_available = bool(ai_analyses and ai_analyses.get('main_analysis'))
        section += f"- Análise por IA: {'Executada' if ai_available else 'Não executada'}\n"
        
        section += "\n---\n\n"
        return section
    
    def _build_original_ai_responses_section(self) -> str:
        """Constrói seção com respostas originais das IAs"""
        
        section = "## Respostas Originais das IAs\n\n"
        section += "Esta seção preserva todas as interações com as IAs, incluindo prompts enviados "
        section += "e respostas recebidas, garantindo transparência total.\n\n"
        
        if not self.prompt_history:
            section += "**Status:** Nenhuma interação com IA foi registrada.\n\n"
            return section
        
        # Mostrar cada interação
        for i, entry in enumerate(self.prompt_history, 1):
            provider = entry.get('provider', 'Desconhecido')
            model = entry.get('model', 'N/A')
            success = entry.get('success', False)
            
            section += f"### Interação {i} - {provider}\n\n"
            section += f"**Provedor:** {provider}\n"
            section += f"**Modelo:** {model}\n"
            section += f"**Status:** {'Sucesso' if success else 'Falha'}\n"
            section += f"**Tempo:** {entry.get('processing_time', 0):.2f}s\n\n"
            
            # Prompt enviado
            prompt = entry.get('prompt', '')
            if prompt:
                section += "**Prompt Enviado:**\n"
                section += "```\n"
                section += prompt
                section += "\n```\n\n"
            
            # Resposta recebida
            response = entry.get('response', '')
            if response:
                section += f"**Resposta do {provider}:**\n"
                section += "```\n"
                section += response
                section += "\n```\n\n"
            
            # Erro se houver
            if entry.get('error'):
                section += f"**Erro:** {entry['error']}\n\n"
            
            section += "---\n\n"
        
        return section
    
    def _build_final_statistics_section(self) -> str:
        """Constrói seção final com estatísticas"""
        
        section = "## Estatísticas Finais\n\n"
        
        # Estatísticas das IAs
        if self.prompt_history:
            total = len(self.prompt_history)
            successful = len([e for e in self.prompt_history if e.get('success', False)])
            
            section += "### Interações com IAs\n\n"
            section += f"- **Total de tentativas:** {total}\n"
            section += f"- **Sucessos:** {successful}\n"
            section += f"- **Falhas:** {total - successful}\n"
            section += f"- **Taxa de sucesso:** {(successful/total*100):.1f}%\n\n"
        
        # Estatísticas gerais
        if self.statistics:
            section += "### Estatísticas Gerais\n\n"
            for key, value in self.statistics.items():
                formatted_key = key.replace('_', ' ').title()
                if isinstance(value, float) and 'time' in key.lower():
                    section += f"- **{formatted_key}:** {value:.2f}s\n"
                else:
                    section += f"- **{formatted_key}:** {value}\n"
        
        section += f"\n**Relatório gerado em:** {time.strftime('%d/%m/%Y %H:%M:%S')}\n"
        section += "**Sistema:** COBOL Analysis Engine v2.0 - Preservação de Respostas Originais\n"
        
        return section
