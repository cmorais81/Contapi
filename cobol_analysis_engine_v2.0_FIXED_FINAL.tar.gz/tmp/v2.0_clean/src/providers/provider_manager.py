"""
Sistema de Análise COBOL v2.6.0 - Provider Manager CORRIGIDO
Gerenciador completo de provedores de análise com método get_provider implementado.
"""

import logging
import time
import asyncio
from typing import Dict, List, Any, Optional
from .base_provider import BaseProvider, AIRequest, AIResponse
from .luzia_provider import LuziaProvider
from .enhanced_mock_provider import EnhancedMockProvider
from .basic_provider import BasicProvider

class ProviderManager:
    """
    Gerenciador de provedores de análise CORRIGIDO.
    Inclui método get_provider que estava faltando.
    """
    
    def __init__(self, config: Dict[str, Any]):
        """Inicializa o gerenciador de provedores."""
        self.logger = logging.getLogger(__name__)
        self.config = config
        self.providers: Dict[str, BaseProvider] = {}
        self.statistics: Dict[str, Dict[str, Any]] = {}
        
        ai_config = config.get("ai", {})
        self.primary_provider = ai_config.get("primary_provider", "luzia")
        self.fallback_providers = ai_config.get("fallback_providers", ["basic"])
        
        self._initialize_providers(ai_config)
        
        self.logger.info(f"Provider Manager inicializado - Primário: {self.primary_provider}")
    
    def _initialize_providers(self, ai_config: Dict[str, Any]) -> None:
        """Inicializa todos os provedores disponíveis."""
        providers_config = ai_config.get("providers", {})
        
        available_providers = {
            "luzia": LuziaProvider,
            "enhanced_mock": EnhancedMockProvider,
            "basic": BasicProvider,
        }
        
        for provider_name, provider_class in available_providers.items():
            try:
                provider_config = providers_config.get(provider_name, {})
                # Passar configuração completa com seção específica do provider
                full_config = self.config.copy() if isinstance(self.config, dict) else {}
                full_config[provider_name] = provider_config
                provider_instance = provider_class(full_config)
                self.providers[provider_name] = provider_instance
                
                # Inicializar estatísticas
                self.statistics[provider_name] = {
                    "total_requests": 0,
                    "successful_requests": 0,
                    "failed_requests": 0,
                    "total_tokens": 0,
                    "total_time": 0.0,
                    "last_used": None,
                    "average_response_time": 0.0
                }
                
                self.logger.info(f"Provider {provider_name} inicializado com sucesso")
                
            except Exception as e:
                self.logger.error(f"Erro ao inicializar provider {provider_name}: {e}")
    
    def get_provider(self, provider_name: str) -> Optional[BaseProvider]:
        """
        MÉTODO CORRIGIDO: Retorna uma instância do provider especificado.
        
        Args:
            provider_name: Nome do provider a ser retornado
            
        Returns:
            Instância do provider ou None se não encontrado
        """
        return self.providers.get(provider_name)
    
    async def get_available_providers(self) -> List[str]:
        """Retorna lista de provedores disponíveis."""
        return list(self.providers.keys())
    
    def get_provider_statistics(self, provider_name: str) -> Dict[str, Any]:
        """Retorna estatísticas de um provider específico."""
        return self.statistics.get(provider_name, {})
    
    async def analyze_with_specific_provider(self, provider_name: str, request: AIRequest) -> AIResponse:
        """Executa análise com um provider específico."""
        if provider_name not in self.providers:
            return AIResponse(
                success=False,
                content="",
                error_message=f"Provider {provider_name} não disponível",
                provider=provider_name,
                model="",
                tokens_used=0
            )
        
        return await self._try_provider(provider_name, request)
    
    async def get_provider_status(self, provider_name: str) -> Dict[str, Any]:
        """Verifica status de um provider específico."""
        if provider_name not in self.providers:
            return {
                "available": False,
                "error": "Provider não encontrado",
                "last_check": time.time()
            }
        
        try:
            provider = self.providers[provider_name]
            stats = self.get_provider_statistics(provider_name)
            
            return {
                "available": True,
                "provider_name": provider_name,
                "statistics": stats,
                "last_check": time.time()
            }
            
        except Exception as e:
            return {
                "available": False,
                "error": str(e),
                "last_check": time.time()
            }
    
    async def _try_provider(self, provider_name: str, request: AIRequest) -> AIResponse:
        """Tenta executar análise com um provider específico."""
        start_time = time.time()
        
        try:
            provider = self.providers[provider_name]
            
            # Executar análise
            if hasattr(provider, 'analyze') and asyncio.iscoroutinefunction(provider.analyze):
                response = await provider.analyze(request)
            elif hasattr(provider, 'analyze'):
                # Método síncrono - executar em thread separada
                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor() as executor:
                    response = await asyncio.get_event_loop().run_in_executor(
                        executor, provider.analyze, request
                    )
            else:
                raise AttributeError(f"Provider {provider_name} não possui método analyze")
            
            processing_time = time.time() - start_time
            
            # Atualizar estatísticas
            self._update_provider_statistics(provider_name, response, processing_time)
            
            return response
            
        except Exception as e:
            processing_time = time.time() - start_time
            
            error_response = AIResponse(
                success=False,
                content="",
                error_message=str(e),
                provider=provider_name,
                model="",
                tokens_used=0
            )
            
            self._update_provider_statistics(provider_name, error_response, processing_time)
            
            return error_response
    
    def _update_provider_statistics(self, provider_name: str, response: Optional[AIResponse], 
                                  processing_time: float) -> None:
        """Atualiza estatísticas do provider."""
        if provider_name not in self.statistics:
            return
        
        stats = self.statistics[provider_name]
        stats["total_requests"] += 1
        stats["total_time"] += processing_time
        stats["last_used"] = time.time()
        
        if response and response.success:
            stats["successful_requests"] += 1
            if hasattr(response, 'tokens_used'):
                stats["total_tokens"] += response.tokens_used
        else:
            stats["failed_requests"] += 1
        
        # Calcular tempo médio de resposta
        if stats["total_requests"] > 0:
            stats["average_response_time"] = stats["total_time"] / stats["total_requests"]
