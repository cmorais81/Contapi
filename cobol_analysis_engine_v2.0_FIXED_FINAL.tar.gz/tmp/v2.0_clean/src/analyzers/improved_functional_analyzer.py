import re
import logging
from typing import Dict, List, Any

class ImprovedFunctionalAnalyzer:
    """Analisador funcional aprimorado para extrair o propósito real e a lógica de negócio."""

    def __init__(self):
        self.logger = logging.getLogger(__name__)
        # Padrões Regex para análise funcional
        self.select_pattern = re.compile(r'SELECT\s+([A-Z0-9\-]+)\s+ASSIGN\s+TO\s+([A-Z0-9\-]+)', re.IGNORECASE)
        self.open_pattern = re.compile(r'OPEN\s+(INPUT|OUTPUT|I-O|EXTEND)\s+([A-Z0-9\-]+)', re.IGNORECASE)
        self.read_pattern = re.compile(r'READ\s+([A-Z0-9\-]+)', re.IGNORECASE)
        self.write_pattern = re.compile(r'WRITE\s+([A-Z0-9\-]+-RECORD)', re.IGNORECASE)
        self.evaluate_pattern = re.compile(r'EVALUATE\s+(TRUE|.+)', re.IGNORECASE)
        self.when_pattern = re.compile(r'WHEN\s+(.+)', re.IGNORECASE)

    def analyze(self, lines: List[str]) -> Dict[str, Any]:
        """Executa a análise funcional completa do código COBOL."""
        files = self._analyze_files(lines)
        purpose = self._determine_purpose(files, lines)
        business_logic = self._extract_business_logic(lines)

        return {
            "program_purpose": purpose,
            "files": files,
            "business_logic": business_logic,
            "data_flow": self._analyze_data_flow(files, business_logic)
        }

    def _analyze_files(self, lines: List[str]) -> List[Dict[str, Any]]:
        """Analisa e cataloga todos os arquivos usados no programa."""
        file_map = {}
        # 1. Encontrar todas as declarações SELECT
        for line in lines:
            if 'SELECT' in line.upper():
                match = self.select_pattern.search(line)
                if match:
                    logical_name, physical_name = match.groups()
                    file_map[logical_name] = {"logical_name": logical_name, "physical_name": physical_name, "operation": "UNKNOWN"}

        # 2. Determinar a operação (INPUT, OUTPUT, I-O)
        for line in lines:
            if 'OPEN' in line.upper():
                match = self.open_pattern.search(line)
                if match:
                    op_mode, file_name = match.groups()
                    if file_name in file_map:
                        file_map[file_name]["operation"] = op_mode
        
        return list(file_map.values())

    def _determine_purpose(self, files: List[Dict[str, Any]], lines: List[str]) -> str:
        """Determina o propósito do programa com base no uso de arquivos e palavras-chave."""
        input_files = [f for f in files if f['operation'] in ['INPUT', 'I-O']]
        output_files = [f for f in files if f['operation'] in ['OUTPUT', 'I-O', 'EXTEND']]

        if len(input_files) == 1 and len(output_files) > 1:
            return "Divisor de Arquivos (File Splitter)"
        if len(input_files) > 1 and len(output_files) == 1:
            return "Agregador de Arquivos (File Merger)"
        if len(input_files) == 1 and len(output_files) == 1 and input_files[0]['physical_name'] == output_files[0]['physical_name']:
            return "Atualizador de Arquivos (File Updater)"
        if len(input_files) >= 1 and len(output_files) >= 1:
            return "Transformador de Dados (Data Transformer)"
        if not input_files and output_files:
            return "Gerador de Relatórios (Report Generator)"

        # Fallback para análise de comentários
        for line in lines[:50]: # Analisa o cabeçalho
            if '*' in line and 'OBJETIVO' in line.upper():
                return line.split(':')[1].strip() if ':' in line else "Propósito definido em comentários"

        return "Processamento de Dados Genérico"

    def _extract_business_logic(self, lines: List[str]) -> Dict[str, Any]:
        """Extrai a lógica de negócio, focando em estruturas de decisão."""
        logic = {"decision_blocks": []}
        in_evaluate = False
        current_evaluate = None

        for line in lines:
            content = line[7:].strip()
            if not content or content.startswith('*'):
                continue

            evaluate_match = self.evaluate_pattern.match(content)
            if evaluate_match:
                in_evaluate = True
                current_evaluate = {"evaluate_on": evaluate_match.group(1), "when_clauses": []}
                continue

            if in_evaluate:
                if 'END-EVALUATE' in content.upper():
                    in_evaluate = False
                    logic["decision_blocks"].append(current_evaluate)
                    current_evaluate = None
                    continue
                
                when_match = self.when_pattern.match(content)
                if when_match and current_evaluate is not None:
                    current_evaluate["when_clauses"].append(when_match.group(1))

        return logic

    def _analyze_data_flow(self, files: List[Dict[str, Any]], business_logic: Dict[str, Any]) -> List[str]:
        """Analisa e descreve o fluxo de dados do programa."""
        flow = []
        inputs = [f['physical_name'] for f in files if f['operation'] in ['INPUT', 'I-O']]
        outputs = [f['physical_name'] for f in files if f['operation'] in ['OUTPUT', 'I-O', 'EXTEND']]

        if inputs:
            flow.append(f"1. Lê dados de: {', '.join(inputs)}.")
        else:
            flow.append("1. Gera dados internamente.")

        if business_logic['decision_blocks']:
            flow.append("2. Aplica lógica de negócio baseada em blocos EVALUATE.")
        else:
            flow.append("2. Processa os dados sequencialmente.")

        if outputs:
            flow.append(f"3. Escreve resultados em: {', '.join(outputs)}.")
        else:
            flow.append("3. Exibe resultados (DISPLAY) ou não gera saída em arquivo.")

        return flow

