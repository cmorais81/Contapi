"""
Classe CompareData Otimizada para Integração PostgreSQL
Otimizada para processar milhões de registros com máxima performance
"""

import os
import time
import random
import psycopg2
import psycopg2.pool
from functools import wraps
from pyspark.sql.functions import (
    current_timestamp, date_format, monotonically_increasing_id,
    col, coalesce, when, broadcast, hash as spark_hash
)
from pyspark import StorageLevel
from pyspark.sql.types import StructType, StructField, StringType, IntegerType


def retry_with_backoff(max_retries=3, base_delay=1, max_delay=60):
    """Decorator para retry com backoff exponencial"""
    
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            for attempt in range(max_retries + 1):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    if attempt == max_retries:
                        raise
                    
                    delay = min(base_delay * (2 ** attempt), max_delay)
                    jitter = random.uniform(0, delay * 0.1)
                    time.sleep(delay + jitter)
                    
            return None
        return wrapper
    return decorator


class OptimizedConnectionManager:
    """Gerenciador de conexões otimizado com pooling"""
    
    def __init__(self, host, database, user, password, min_conn=5, max_conn=20):
        self.connection_pool = psycopg2.pool.ThreadedConnectionPool(
            min_conn, max_conn,
            host=host,
            database=database,
            user=user,
            password=password,
            connect_timeout=60,
            application_name="spark_etl_optimized"
        )
    
    def get_connection(self):
        """Obtém conexão do pool"""
        return self.connection_pool.getconn()
    
    def return_connection(self, conn):
        """Retorna conexão para o pool"""
        self.connection_pool.putconn(conn)
    
    def close_all_connections(self):
        """Fecha todas as conexões do pool"""
        self.connection_pool.closeall()


class CompareDataOptimized:
    """Classe otimizada para comparação e sincronização de dados com PostgreSQL"""
    
    def __init__(self, logger, dbutils, spark):
        self.host = os.environ["env_host_postgres"]
        self.dbname = os.environ["env_database_postgres"]
        self.user = os.environ["env_user_postgres"]
        self.password = dbutils.secrets.get(scope="lpd", key="lpduser")
        self.logger = logger
        self.spark = spark
        self.env = os.environ.get("ENV_AMBIENTE")
        
        # Storage level otimizado
        self.storage_level = StorageLevel.MEMORY_AND_DISK_SER
        
        # Configurações otimizadas
        self.jdbc_fetch_size = 100000
        self.jdbc_batch_size = 50000
        self.num_partitions = self.calculate_optimal_partitions()
        
        # Connection manager otimizado
        self.connection_manager = OptimizedConnectionManager(
            self.host, self.dbname, self.user, self.password
        )
        
        # Configurações JDBC otimizadas
        self.jdbc_read_options = {
            "url": f"jdbc:postgresql://{self.host}/{self.dbname}",
            "user": self.user,
            "password": self.password,
            "driver": "org.postgresql.Driver",
            "fetchsize": str(self.jdbc_fetch_size),
            "queryTimeout": "3600",
            "connectTimeout": "60",
            "socketTimeout": "3600"
        }
        
        self.jdbc_write_options = {
            "url": f"jdbc:postgresql://{self.host}/{self.dbname}",
            "user": self.user,
            "password": self.password,
            "driver": "org.postgresql.Driver",
            "batchsize": str(self.jdbc_batch_size),
            "isolationLevel": "READ_COMMITTED",
            "rewriteBatchedStatements": "true",
            "stringtype": "unspecified"
        }
        
        # Métricas de performance
        self.performance_metrics = {}
    
    def calculate_optimal_partitions(self):
        """Calcula número otimizado de partições baseado no cluster"""
        try:
            # Obter número de cores disponíveis
            total_cores = self.spark.sparkContext.defaultParallelism
            # Usar 2-4 partições por core para balancear paralelismo e overhead
            return min(max(total_cores * 2, 8), 64)  # Entre 8 e 64 partições
        except:
            return 32  # Valor padrão seguro
    
    @retry_with_backoff(max_retries=3)
    def get_table_bounds(self, table_name, column_name):
        """Obtém bounds da tabela para particionamento otimizado"""
        try:
            conn = self.connection_manager.get_connection()
            try:
                with conn.cursor() as cursor:
                    cursor.execute(f"""
                        SELECT 
                            MIN({column_name})::text as min_val,
                            MAX({column_name})::text as max_val,
                            COUNT(*) as total_count
                        FROM {table_name}
                    """)
                    result = cursor.fetchone()
                    return {
                        'lower': result[0] if result[0] else '1',
                        'upper': result[1] if result[1] else '999999999',
                        'count': result[2] if result[2] else 0
                    }
            finally:
                self.connection_manager.return_connection(conn)
        except Exception as e:
            self.logger.warning(f"Erro ao obter bounds da tabela: {e}")
            return {'lower': '1', 'upper': '999999999', 'count': 0}
    
    def read_dossie_simples_optimized(self):
        """Leitura otimizada da tabela tb_dossie_simples com particionamento inteligente"""
        start_time = time.time()
        
        try:
            self.logger.info("Iniciando leitura otimizada do PostgreSQL")
            
            # Obter bounds para particionamento otimizado
            bounds = self.get_table_bounds("tb_dossie_simples", "penumper")
            self.logger.info(f"Bounds calculados: {bounds['lower']} - {bounds['upper']}, Total: {bounds['count']:,}")
            
            # Configurar opções de leitura com particionamento
            read_options = self.jdbc_read_options.copy()
            read_options.update({
                "dbtable": "tb_dossie_simples",
                "numPartitions": str(self.num_partitions),
                "partitionColumn": "penumper",
                "lowerBound": bounds['lower'],
                "upperBound": bounds['upper']
            })
            
            # Executar leitura
            df = self.spark.read.format("jdbc").options(**read_options).load()
            
            # Cache otimizado
            df_cached = df.persist(self.storage_level)
            
            # Materializar cache e obter contagem
            count = df_cached.count()
            
            duration = time.time() - start_time
            throughput = count / duration if duration > 0 else 0
            
            self.performance_metrics['read_postgresql'] = {
                'duration_seconds': duration,
                'record_count': count,
                'throughput_records_per_second': throughput
            }
            
            self.logger.info(f"Leitura PostgreSQL concluída: {count:,} registros em {duration:.2f}s ({throughput:.0f} rec/s)")
            
            return df_cached
            
        except Exception as e:
            self.logger.error(f"Erro na leitura otimizada do PostgreSQL: {e}")
            raise
    
    def data_compare_optimized(self, df_new, df_existing):
        """Comparação otimizada de dados sem collect e com joins consolidados"""
        start_time = time.time()
        
        try:
            self.logger.info("Iniciando comparação otimizada de dados")
            
            # Determinar qual DataFrame fazer broadcast (menor)
            count_new = df_new.count()
            count_existing = df_existing.count()
            
            self.logger.info(f"Registros novos: {count_new:,}, Registros existentes: {count_existing:,}")
            
            # Broadcast do DataFrame menor para otimizar join
            if count_existing < count_new and count_existing < 200000000:  # Limite de 200M para broadcast
                df_existing = broadcast(df_existing)
                self.logger.info("Aplicando broadcast no DataFrame existente")
            elif count_new < count_existing and count_new < 200000000:
                df_new = broadcast(df_new)
                self.logger.info("Aplicando broadcast no DataFrame novo")
            
            # Join único para identificar todos os casos
            df_comparison = df_new.alias("new").join(
                df_existing.alias("existing"), 
                on="penumper", 
                how="full_outer"
            ).select(
                coalesce(col("new.penumper"), col("existing.penumper")).alias("penumper"),
                col("new.identity_hash").alias("new_hash"),
                col("existing.identity_hash").alias("existing_hash"),
                when(col("existing.penumper").isNull(), "INSERT")
                .when(col("new.penumper").isNull(), "DELETE")
                .when(col("new.identity_hash") != col("existing.identity_hash"), "UPDATE")
                .otherwise("NO_CHANGE").alias("operation")
            )
            
            # Cache da comparação
            df_comparison_cached = df_comparison.persist(self.storage_level)
            
            # Separar operações
            df_inserts = df_comparison_cached.filter(col("operation") == "INSERT")
            df_updates = df_comparison_cached.filter(col("operation") == "UPDATE")
            df_deletes = df_comparison_cached.filter(col("operation") == "DELETE")
            
            # Obter contagens
            insert_count = df_inserts.count()
            update_count = df_updates.count()
            delete_count = df_deletes.count()
            
            self.logger.info(f"Operações identificadas - Inserções: {insert_count:,}, Atualizações: {update_count:,}, Deleções: {delete_count:,}")
            
            # Preparar DataFrame para escrita (inserções + atualizações)
            df_to_write = df_inserts.union(df_updates).join(
                df_new, on="penumper", how="inner"
            ).drop("new_hash", "existing_hash", "operation")
            
            # Adicionar timestamp
            df_to_write = df_to_write.withColumn(
                "update_date", 
                date_format(current_timestamp(), "yyyyMMdd HH:mm:ss")
            )
            
            # Preparar DataFrame para deleção
            df_to_delete = df_updates.union(df_deletes).select("penumper")
            
            # Aplicar limite inteligente baseado na capacidade
            max_batch_size = 4000000
            write_count = df_to_write.count()
            
            if write_count > max_batch_size:
                self.logger.info(f"Limitando escrita para {max_batch_size:,} registros (de {write_count:,})")
                df_to_write = df_to_write.limit(max_batch_size)
                write_count = max_batch_size
            
            duration = time.time() - start_time
            
            self.performance_metrics['data_compare'] = {
                'duration_seconds': duration,
                'insert_count': insert_count,
                'update_count': update_count,
                'delete_count': delete_count,
                'write_count': write_count
            }
            
            self.logger.info(f"Comparação concluída em {duration:.2f}s")
            
            # Limpar cache intermediário
            df_comparison_cached.unpersist()
            
            return df_to_delete, df_to_write, write_count == 0, write_count
            
        except Exception as e:
            self.logger.error(f"Erro na comparação otimizada: {e}")
            raise
    
    def delete_data_optimized(self, df_to_delete):
        """Deleção distribuída otimizada sem collect"""
        start_time = time.time()
        
        try:
            delete_count = df_to_delete.count()
            if delete_count == 0:
                self.logger.info("Nenhum registro para deletar")
                return
            
            self.logger.info(f"Iniciando deleção otimizada de {delete_count:,} registros")
            
            def delete_partition(partition_data):
                """Função para deletar dados de uma partição"""
                penumpers = [row.penumper for row in partition_data]
                if not penumpers:
                    return
                
                conn = self.connection_manager.get_connection()
                try:
                    with conn.cursor() as cursor:
                        # Usar ANY para deleção eficiente em lote
                        cursor.execute(
                            "DELETE FROM tb_dossie_simples WHERE penumper = ANY(%s)",
                            (penumpers,)
                        )
                        conn.commit()
                        
                except Exception as e:
                    conn.rollback()
                    raise e
                finally:
                    self.connection_manager.return_connection(conn)
            
            # Reparticionar para distribuição otimizada
            optimal_partitions = min(16, max(1, delete_count // 10000))
            df_to_delete.repartition(optimal_partitions, "penumper").foreachPartition(delete_partition)
            
            duration = time.time() - start_time
            throughput = delete_count / duration if duration > 0 else 0
            
            self.performance_metrics['delete_postgresql'] = {
                'duration_seconds': duration,
                'record_count': delete_count,
                'throughput_records_per_second': throughput
            }
            
            self.logger.info(f"Deleção concluída: {delete_count:,} registros em {duration:.2f}s ({throughput:.0f} rec/s)")
            
        except Exception as e:
            self.logger.error(f"Erro na deleção otimizada: {e}")
            raise
    
    def insert_data_optimized(self, df_to_insert, total_count):
        """Inserção otimizada usando JDBC nativo do Spark"""
        start_time = time.time()
        
        try:
            if total_count == 0:
                self.logger.info("Nenhum registro para inserir")
                return
            
            self.logger.info(f"Iniciando inserção otimizada de {total_count:,} registros")
            
            # Calcular número otimizado de partições para escrita
            # Objetivo: 500k-1M registros por partição
            target_records_per_partition = 750000
            num_write_partitions = max(1, min(32, total_count // target_records_per_partition))
            
            self.logger.info(f"Usando {num_write_partitions} partições para escrita")
            
            # Reparticionar para escrita otimizada
            df_partitioned = df_to_insert.repartition(num_write_partitions)
            
            # Configurar opções de escrita
            write_options = self.jdbc_write_options.copy()
            write_options["dbtable"] = "tb_dossie_simples"
            
            # Executar escrita
            df_partitioned.write \
                .format("jdbc") \
                .options(**write_options) \
                .mode("append") \
                .save()
            
            duration = time.time() - start_time
            throughput = total_count / duration if duration > 0 else 0
            
            self.performance_metrics['insert_postgresql'] = {
                'duration_seconds': duration,
                'record_count': total_count,
                'throughput_records_per_second': throughput
            }
            
            self.logger.info(f"Inserção concluída: {total_count:,} registros em {duration:.2f}s ({throughput:.0f} rec/s)")
            
        except Exception as e:
            self.logger.error(f"Erro na inserção otimizada: {e}")
            raise
    
    def execute_optimized_sync(self, df_new_data):
        """Executa sincronização completa otimizada"""
        total_start_time = time.time()
        
        try:
            self.logger.info("=== INICIANDO SINCRONIZAÇÃO OTIMIZADA ===")
            
            # Etapa 1: Ler dados existentes
            df_existing = self.read_dossie_simples_optimized()
            
            # Etapa 2: Comparar dados
            df_to_delete, df_to_write, is_empty, write_count = self.data_compare_optimized(
                df_new_data, df_existing
            )
            
            if is_empty:
                self.logger.info("Nenhuma alteração detectada. Sincronização concluída.")
                return
            
            # Etapa 3: Deletar registros alterados
            if df_to_delete.count() > 0:
                self.delete_data_optimized(df_to_delete)
            
            # Etapa 4: Inserir registros novos e atualizados
            self.insert_data_optimized(df_to_write, write_count)
            
            # Métricas finais
            total_duration = time.time() - total_start_time
            
            self.performance_metrics['total_sync'] = {
                'duration_seconds': total_duration,
                'total_records_processed': write_count
            }
            
            self.logger.info(f"=== SINCRONIZAÇÃO CONCLUÍDA EM {total_duration:.2f}s ===")
            
            # Log das métricas de performance
            self.log_performance_metrics()
            
        except Exception as e:
            self.logger.error(f"Erro na sincronização otimizada: {e}")
            raise
        finally:
            # Limpar recursos
            self.cleanup_resources()
    
    def log_performance_metrics(self):
        """Log detalhado das métricas de performance"""
        self.logger.info("=== MÉTRICAS DE PERFORMANCE ===")
        
        for operation, metrics in self.performance_metrics.items():
            self.logger.info(f"{operation.upper()}:")
            for metric, value in metrics.items():
                if isinstance(value, float):
                    self.logger.info(f"  {metric}: {value:.2f}")
                else:
                    self.logger.info(f"  {metric}: {value:,}")
    
    def get_performance_metrics(self):
        """Retorna métricas de performance para análise externa"""
        return self.performance_metrics.copy()
    
    def cleanup_resources(self):
        """Limpa recursos e conexões"""
        try:
            self.connection_manager.close_all_connections()
            self.logger.info("Recursos limpos com sucesso")
        except Exception as e:
            self.logger.warning(f"Erro ao limpar recursos: {e}")
    
    # Métodos de compatibilidade com a interface original
    def read_dossie_simples(self):
        """Método de compatibilidade - usa versão otimizada"""
        return self.read_dossie_simples_optimized()
    
    def data_compare(self, df1, df2):
        """Método de compatibilidade - usa versão otimizada"""
        df_to_delete, df_to_write, is_empty, count = self.data_compare_optimized(df1, df2)
        
        # Converter df_to_delete para lista para compatibilidade
        if df_to_delete.count() > 0:
            # Limitar collect para evitar problemas de memória
            delete_count = df_to_delete.count()
            if delete_count > 1000000:  # Limite de 1M para collect
                self.logger.warning(f"Muitos registros para deletar ({delete_count:,}). Usando versão otimizada.")
                keys_to_delete_list = []  # Lista vazia - usar método otimizado
            else:
                keys_to_delete_list = [row.penumper for row in df_to_delete.collect()]
        else:
            keys_to_delete_list = []
        
        return keys_to_delete_list, df_to_write, is_empty, count
    
    def delete_data(self, penumper_list, batch_size=10000):
        """Método de compatibilidade - usa versão otimizada se lista muito grande"""
        if len(penumper_list) > 100000:  # Limite para usar versão otimizada
            self.logger.info("Lista muito grande. Usando deleção otimizada.")
            # Criar DataFrame temporário para usar método otimizado
            schema = StructType([StructField("penumper", StringType(), True)])
            df_temp = self.spark.createDataFrame(
                [(penumper,) for penumper in penumper_list], 
                schema
            )
            self.delete_data_optimized(df_temp)
        else:
            # Usar método original para listas pequenas
            self._delete_data_original(penumper_list, batch_size)
    
    def _delete_data_original(self, penumper_list, batch_size=10000):
        """Implementação original para compatibilidade com listas pequenas"""
        try:
            self.logger.info("Iniciando deleção de registros no postgres (método original)")
            if not penumper_list:
                self.logger.info("Lista de penumperes para deleção está vazia.")
                return

            conn = self.connection_manager.get_connection()
            try:
                cur = conn.cursor()

                total = len(penumper_list)
                for i in range(0, total, batch_size):
                    batch = penumper_list[i:i+batch_size]
                    batch_str = ",".join([f"'{x}'" for x in batch])
                    query = f"DELETE FROM tb_dossie_simples WHERE penumper IN ({batch_str})"
                    self.logger.info(f"Deletando batch {i//batch_size+1}: {len(batch)} registros")
                    cur.execute(query)
                    conn.commit()
            finally:
                self.connection_manager.return_connection(conn)

            self.logger.info("Deleção realizada com sucesso.")

        except Exception as exp:
            self.logger.info("Falha na exclusão dos dados no postgres")
            self.logger.error(exp)
    
    def insert_new_and_altered_data(self, df, total):
        """Método de compatibilidade - usa versão otimizada"""
        self.insert_data_optimized(df, total)


# Exemplo de uso da classe otimizada
def exemplo_uso_otimizado():
    """Exemplo de como usar a classe otimizada"""
    
    # Configurar Spark (assumindo que já existe)
    # spark = SparkSession.builder...
    
    # Instanciar classe otimizada
    compare_data = CompareDataOptimized(logger, dbutils, spark)
    
    # Executar sincronização completa otimizada
    # df_new_data = ... (DataFrame com novos dados)
    # compare_data.execute_optimized_sync(df_new_data)
    
    # Ou usar métodos individuais para compatibilidade
    # df_existing = compare_data.read_dossie_simples()
    # keys_to_delete, df_to_write, is_empty, count = compare_data.data_compare(df_new, df_existing)
    # compare_data.delete_data(keys_to_delete)
    # compare_data.insert_new_and_altered_data(df_to_write, count)
    
    pass

