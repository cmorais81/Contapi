"""
Script de exemplo para execução da classe DadosCadastraisOtimizado
no Databricks Azure com configurações otimizadas para 1TB
"""

import sys
import time
import argparse
from datetime import datetime
from pyspark.sql import SparkSession
import logging

# Importar classes otimizadas
from dados_cadastrais_otimizado import DadosCadastraisOtimizado
from databricks_config import DatabricksConfig, PerformanceMonitoring


def setup_environment():
    """Configura o ambiente de execução"""
    
    # Configurar logging
    logger = DatabricksConfig.setup_logging()
    
    # Criar SparkSession otimizada
    spark = DatabricksConfig.create_optimized_spark_session()
    
    # Configurar nível de log do Spark
    spark.sparkContext.setLogLevel("WARN")
    
    return spark, logger


def validate_environment(spark, logger):
    """Valida se o ambiente está configurado corretamente"""
    
    logger.info("Validando ambiente de execução...")
    
    try:
        # Verificar configurações críticas
        critical_configs = {
            "spark.sql.adaptive.enabled": "true",
            "spark.sql.adaptive.coalescePartitions.enabled": "true",
            "spark.sql.adaptive.skewJoin.enabled": "true"
        }
        
        for config, expected_value in critical_configs.items():
            actual_value = spark.conf.get(config, "not_set")
            if actual_value.lower() != expected_value.lower():
                logger.warning(f"Configuração {config} não está otimizada: {actual_value}")
        
        # Verificar acesso às tabelas
        test_tables = [
            'b_stbr_pe.pedt001',
            'b_stbr_pe.pedt002', 
            'b_stbr_pe.pedt003'
        ]
        
        for table in test_tables:
            try:
                count = spark.sql(f"SELECT COUNT(*) FROM {table} LIMIT 1").collect()[0][0]
                logger.info(f"Acesso à tabela {table}: OK ({count:,} registros)")
            except Exception as e:
                logger.error(f"Erro ao acessar tabela {table}: {e}")
                return False
        
        logger.info("Validação do ambiente concluída com sucesso")
        return True
        
    except Exception as e:
        logger.error(f"Erro na validação do ambiente: {e}")
        return False


def execute_pipeline_with_monitoring(spark, logger, output_table=None):
    """Executa o pipeline com monitoramento completo"""
    
    start_time = time.time()
    logger.info("=== INICIANDO EXECUÇÃO DO PIPELINE OTIMIZADO ===")
    
    # Configurar monitoramento
    monitor = PerformanceMonitoring(spark)
    monitor.log_cluster_metrics()
    
    try:
        # Instanciar classe otimizada
        dados_cadastrais = DadosCadastraisOtimizado(spark, logger)
        
        # Executar pipeline
        logger.info("Iniciando processamento dos dados...")
        df_resultado = dados_cadastrais.execute_optimized_pipeline()
        
        # Monitorar progresso
        monitor.monitor_job_progress("Pipeline Dados Cadastrais")
        
        # Obter métricas de performance
        performance_metrics = dados_cadastrais.get_performance_metrics()
        
        # Log das métricas
        logger.info("=== MÉTRICAS DE PERFORMANCE ===")
        total_records = 0
        total_duration = 0
        
        for stage, metrics in performance_metrics.items():
            logger.info(f"{stage}:")
            logger.info(f"  Registros: {metrics['record_count']:,}")
            logger.info(f"  Duração: {metrics['duration_seconds']:.2f}s")
            logger.info(f"  Throughput: {metrics['throughput_records_per_second']:.0f} rec/s")
            
            total_records += metrics['record_count']
            total_duration += metrics['duration_seconds']
        
        # Salvar resultado
        if output_table:
            logger.info(f"Salvando resultado na tabela: {output_table}")
            
            df_resultado.write \
                .mode("overwrite") \
                .option("overwriteSchema", "true") \
                .saveAsTable(output_table)
            
            # Verificar resultado salvo
            saved_count = spark.sql(f"SELECT COUNT(*) FROM {output_table}").collect()[0][0]
            logger.info(f"Registros salvos: {saved_count:,}")
        
        # Métricas finais
        total_time = time.time() - start_time
        logger.info("=== RESUMO FINAL ===")
        logger.info(f"Tempo total de execução: {total_time:.2f} segundos ({total_time/60:.1f} minutos)")
        logger.info(f"Total de registros processados: {total_records:,}")
        logger.info(f"Throughput médio: {total_records/total_time:.0f} registros/segundo")
        
        # Limpar recursos
        dados_cadastrais.cleanup_resources()
        
        return df_resultado, performance_metrics
        
    except Exception as e:
        logger.error(f"Erro na execução do pipeline: {e}")
        raise
    
    finally:
        execution_time = time.time() - start_time
        logger.info(f"Tempo total de execução: {execution_time:.2f} segundos")


def create_performance_report(performance_metrics, output_file="/tmp/performance_report.txt"):
    """Cria relatório de performance"""
    
    with open(output_file, 'w') as f:
        f.write("RELATÓRIO DE PERFORMANCE - DADOS CADASTRAIS OTIMIZADO\n")
        f.write("=" * 60 + "\n")
        f.write(f"Data/Hora: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
        
        total_records = 0
        total_duration = 0
        
        f.write("MÉTRICAS POR ESTÁGIO:\n")
        f.write("-" * 40 + "\n")
        
        for stage, metrics in performance_metrics.items():
            f.write(f"\n{stage}:\n")
            f.write(f"  Registros: {metrics['record_count']:,}\n")
            f.write(f"  Duração: {metrics['duration_seconds']:.2f}s\n")
            f.write(f"  Throughput: {metrics['throughput_records_per_second']:.0f} rec/s\n")
            
            total_records += metrics['record_count']
            total_duration += metrics['duration_seconds']
        
        f.write(f"\nRESUMO GERAL:\n")
        f.write("-" * 20 + "\n")
        f.write(f"Total de registros: {total_records:,}\n")
        f.write(f"Duração total: {total_duration:.2f}s\n")
        f.write(f"Throughput médio: {total_records/total_duration:.0f} rec/s\n")
    
    print(f"Relatório de performance salvo em: {output_file}")


def main():
    """Função principal"""
    
    parser = argparse.ArgumentParser(description='Executa pipeline otimizado de dados cadastrais')
    parser.add_argument('--output-table', 
                       default='dados_cadastrais_otimizado_v2',
                       help='Nome da tabela de saída')
    parser.add_argument('--validate-only', 
                       action='store_true',
                       help='Apenas valida o ambiente sem executar o pipeline')
    parser.add_argument('--performance-report',
                       default='/tmp/performance_report.txt',
                       help='Arquivo para salvar relatório de performance')
    
    args = parser.parse_args()
    
    try:
        # Configurar ambiente
        spark, logger = setup_environment()
        
        # Validar ambiente
        if not validate_environment(spark, logger):
            logger.error("Falha na validação do ambiente. Abortando execução.")
            sys.exit(1)
        
        if args.validate_only:
            logger.info("Validação concluída. Saindo sem executar pipeline.")
            return
        
        # Executar pipeline
        df_resultado, performance_metrics = execute_pipeline_with_monitoring(
            spark, logger, args.output_table
        )
        
        # Criar relatório de performance
        create_performance_report(performance_metrics, args.performance_report)
        
        logger.info("Execução concluída com sucesso!")
        
    except Exception as e:
        logger.error(f"Erro na execução: {e}")
        sys.exit(1)
    
    finally:
        # Parar SparkSession
        if 'spark' in locals():
            spark.stop()


if __name__ == "__main__":
    main()


# Exemplo de execução via notebook Databricks
def exemplo_notebook():
    """
    Exemplo de como executar no notebook Databricks
    """
    
    # Configurar ambiente
    spark, logger = setup_environment()
    
    # Validar ambiente
    if validate_environment(spark, logger):
        
        # Executar pipeline
        df_resultado, metrics = execute_pipeline_with_monitoring(
            spark, logger, "dados_cadastrais_otimizado_notebook"
        )
        
        # Mostrar algumas estatísticas
        print("Primeiras 10 linhas do resultado:")
        df_resultado.show(10)
        
        print("\nEstatísticas das colunas principais:")
        df_resultado.select("penumper", "cpf", "nome", "idade").describe().show()
        
        # Criar relatório
        create_performance_report(metrics)
        
    else:
        print("Falha na validação do ambiente")


# Exemplo de execução com configurações customizadas
def exemplo_configuracao_customizada():
    """
    Exemplo com configurações customizadas
    """
    
    # Configurações específicas para teste
    from pyspark.conf import SparkConf
    
    custom_config = SparkConf()
    custom_config.set("spark.sql.adaptive.advisoryPartitionSizeInBytes", "128MB")
    custom_config.set("spark.sql.adaptive.coalescePartitions.minPartitionNum", "100")
    
    spark = SparkSession.builder \
        .config(conf=custom_config) \
        .getOrCreate()
    
    # Aplicar configurações adicionais
    spark.conf.set("spark.sql.adaptive.enabled", "true")
    spark.conf.set("spark.sql.adaptive.coalescePartitions.enabled", "true")
    
    logger = logging.getLogger(__name__)
    
    # Executar com configurações customizadas
    dados_cadastrais = DadosCadastraisOtimizado(spark, logger)
    df_resultado = dados_cadastrais.execute_optimized_pipeline()
    
    return df_resultado

