from pyspark.sql.types import DateType, StringType, IntegerType
from datetime import date
from pyspark.sql.functions import (
    col, concat, max, regexp_replace, when, trim, lit, substring, coalesce,
    first, concat_ws, collect_list, sort_array, datediff, current_date, lpad,
    upper, sha2, md5, broadcast, expr, split, array_join, size, filter as spark_filter,
    row_number, rank, dense_rank, lag, lead, sum as spark_sum, count, avg,
    collect_set, array_distinct, flatten, transform, exists, forall
)
from pyspark.sql.window import Window
from pyspark import StorageLevel
from pyspark.sql import DataFrame
import time
import logging
from typing import Dict, List, Optional, Tuple


class DadosCadastraisOtimizado:
    """
    Versão otimizada da classe DadosCadastrais para processar 1TB de dados
    no Databricks Azure com Spark 3, sem Photon.
    
    Principais otimizações:
    - Pipeline unificado com lazy evaluation
    - Consolidação de transformações
    - Broadcast maps para lookups
    - Cache estratégico
    - Configurações otimizadas para 1TB
    """

    def __init__(self, spark, logger=None):
        self.spark = spark
        self.logger = logger or logging.getLogger(__name__)
        
        # Configurações otimizadas para 1TB
        self._configure_spark_for_1tb()
        
        # Storage levels estratégicos
        self.storage_level_base = StorageLevel.MEMORY_AND_DISK_SER_2
        self.storage_level_intermediate = StorageLevel.DISK_ONLY_2
        self.storage_level_final = StorageLevel.MEMORY_ONLY_SER
        
        # Broadcast maps para lookups eficientes
        self._initialize_broadcast_maps()
        
        # Métricas de performance
        self.performance_metrics = {}

    def _configure_spark_for_1tb(self):
        """Configurações específicas do Spark para processar 1TB eficientemente"""
        configs = {
            # Adaptive Query Execution
            "spark.sql.adaptive.enabled": "true",
            "spark.sql.adaptive.coalescePartitions.enabled": "true",
            "spark.sql.adaptive.skewJoin.enabled": "true",
            "spark.sql.adaptive.localShuffleReader.enabled": "true",
            
            # Configurações para 1TB
            "spark.sql.adaptive.advisoryPartitionSizeInBytes": "256MB",
            "spark.sql.adaptive.coalescePartitions.minPartitionNum": "100",
            "spark.sql.adaptive.skewJoin.skewedPartitionThresholdInBytes": "512MB",
            "spark.sql.adaptive.skewJoin.skewedPartitionFactor": "5",
            
            # Otimizações de memória
            "spark.sql.execution.arrow.pyspark.enabled": "true",
            "spark.sql.execution.arrow.maxRecordsPerBatch": "20000",
            
            # Broadcast
            "spark.sql.autoBroadcastJoinThreshold": "200MB",
            
            # Delta Lake optimizations
            "spark.databricks.delta.optimizeWrite.enabled": "true",
            "spark.databricks.delta.autoCompact.enabled": "true",
            
            # Serialization
            "spark.serializer": "org.apache.spark.serializer.KryoSerializer",
            "spark.sql.execution.arrow.pyspark.enabled": "true"
        }
        
        for key, value in configs.items():
            self.spark.conf.set(key, value)
            
        self.logger.info("Configurações do Spark otimizadas para 1TB aplicadas")

    def _initialize_broadcast_maps(self):
        """Inicializa broadcast variables para lookups O(1)"""
        
        # Mapa de estados brasileiros
        estados_map = {
            "01": "AC - ACRE", "02": "AL - ALAGOAS", "03": "AP - AMAPA",
            "04": "AM - AMAZONAS", "05": "BA - BAHIA", "06": "CE - CEARA",
            "07": "ES - ESPIRITO SANTO", "08": "GO - GOIAS", "09": "MA - MARANHAO",
            "10": "MT - MATO GROSSO", "11": "MS - MATO GROSSO DO SUL", "12": "MG - MINAS GERAIS",
            "13": "PA - PARA", "14": "PB - PARAIBA", "15": "PR - PARANA",
            "16": "PE - PERNAMBUCO", "17": "PI - PIAUI", "18": "RJ - RIO DE JANEIRO",
            "19": "RN - RIO GRANDE DO NORTE", "20": "RS - RIO GRANDE DO SUL", "21": "RO - RONDONIA",
            "22": "RR - RORAIMA", "23": "SC - SANTA CATARINA", "24": "SP - SAO PAULO",
            "25": "SE - SERGIPE", "26": "TO - TOCANTINS", "27": "DF - DISTRITO FEDERAL",
            "99": "ZZ - NAO INFORMADA"
        }
        
        # Mapa de estados (apenas siglas)
        estados_sigla_map = {k: v.split(" - ")[0] for k, v in estados_map.items()}
        
        # Mapa de estado civil
        estado_civil_map = {
            "A": "CASADO(A) S/ INFORMACAO DE REGIME",
            "B": "CASADO(A)-PARTICIP FINAL DOS AQUESTOS",
            "1": "SOLTEIRO(A)",
            "3": "VIUVO(A)",
            "4": "DIVORCIADO/A",
            "5": "SEPARADO/A JUDICIALMENTE",
            "6": "UNIAO ESTAVEL",
            "7": "CASADO(A)-COMUNHAO PARCIAL BENS",
            "8": "CASADO(A)-COMUNHAO UNIVERSAL BENS",
            "9": "CASADO(A)-SEPARACAO BENS"
        }
        
        # Mapa de sexo
        sexo_map = {"H": "masculino", "M": "feminino"}
        
        # Mapa de tipo de ocupação
        tipo_ocupacao_map = {
            "01": "MAIOR C/RENDA", "02": "MENOR RELATIV.INCAPAZ",
            "03": "MENOR ABSOLUT.INCAPAZ", "04": "MENOR EMANCIP.C/RENDA",
            "05": "INTERDITO", "06": "ANALFABETO",
            "07": "DEF VISUAL/AUDI - MAIOR COM RENDA", "08": "ESPOLIO",
            "09": "MENOR APRENDIZ", "10": "MAIOR SEM RENDA",
            "11": "MENOR EMANCIP.S/RENDA", "12": "DEF VISUAL/AUDI - MAIOR SEM RENDA",
            "13": "DEF VISUAL/AUDI-MENOR EMANCIP C/RENDA", "14": "DEF VISUAL/AUDI-MENOR EMANCIP S/RENDA",
            "15": "DEF VISUAL/AUDI-MENOR RELATIV INCAPAZ", "16": "DEF VISUAL/AUDI-MENOR ABSOLUT INCAPAZ",
            "17": "PESSOA FALECIDA"
        }
        
        # Mapa de nacionalidade
        nacionalidade_map = {
            "BRA": "BRASILEIRA", "EXT": "ESTRANGEIRA", "NAT": "NATURALIZADA"
        }
        
        # Mapa de tipos de bem
        tipo_bem_map = {
            "01": "ACOES", "02": "AUTOMOVEIS", "03": "IMOVEIS",
            "04": "INVESTIMENTOS", "05": "NAO POSSUI", "06": "OUTROS",
            "07": "NAO INFORMADO", "08": "PATRIMONIO LIQUIDO"
        }
        
        # Mapa de PEP
        pep_map = {
            "046": "POLITICAMENTE EXPOSTA-EM EXERCICIO",
            "047": "POLITICAMENTE EXPOSTA-PROXIMO OU PARENTE",
            "048": "POLITICAMENTE EXPOSTA-AFASTADO/INATIVO"
        }
        
        # Criar broadcast variables
        self.broadcast_estados = self.spark.sparkContext.broadcast(estados_map)
        self.broadcast_estados_sigla = self.spark.sparkContext.broadcast(estados_sigla_map)
        self.broadcast_estado_civil = self.spark.sparkContext.broadcast(estado_civil_map)
        self.broadcast_sexo = self.spark.sparkContext.broadcast(sexo_map)
        self.broadcast_tipo_ocupacao = self.spark.sparkContext.broadcast(tipo_ocupacao_map)
        self.broadcast_nacionalidade = self.spark.sparkContext.broadcast(nacionalidade_map)
        self.broadcast_tipo_bem = self.spark.sparkContext.broadcast(tipo_bem_map)
        self.broadcast_pep = self.spark.sparkContext.broadcast(pep_map)
        
        self.logger.info("Broadcast maps inicializados para lookups O(1)")

    def _track_performance(self, stage_name: str, df: DataFrame) -> DataFrame:
        """Rastreia métricas de performance para cada estágio"""
        start_time = time.time()
        
        # Força a execução para medir o tempo real
        count = df.count()
        
        end_time = time.time()
        duration = end_time - start_time
        
        self.performance_metrics[stage_name] = {
            'duration_seconds': duration,
            'record_count': count,
            'throughput_records_per_second': count / duration if duration > 0 else 0
        }
        
        self.logger.info(f"{stage_name}: {count:,} registros em {duration:.2f}s "
                        f"({count/duration:.0f} registros/s)")
        
        return df

    def collectOdate(self, tabela: str) -> str:
        """Coleta a data de referência mais recente de uma tabela"""
        try:
            odate = (self.spark.sql(f'SHOW PARTITIONS {tabela}')
                    .orderBy(col('partition').desc())
                    .limit(1)
                    .collect()[0][0])
            
            # Extrai apenas a data da partição
            if 'dat_ref_carga=' in odate:
                return odate.split('dat_ref_carga=')[1]
            return odate
        except Exception as e:
            self.logger.warning(f"Erro ao obter data de referência para {tabela}: {e}")
            return "2024-01-01"  # Data padrão

    def _create_estado_lookup_expr(self, col_name: str, map_type: str = "full") -> str:
        """Cria expressão SQL para lookup de estados usando CASE"""
        estados = self.broadcast_estados.value
        if map_type == "sigla":
            estados = self.broadcast_estados_sigla.value
            
        case_expr = "CASE "
        for codigo, descricao in estados.items():
            case_expr += f"WHEN {col_name} = '{codigo}' THEN '{descricao}' "
        case_expr += "ELSE '' END"
        
        return case_expr

    def load_base_tables(self) -> Dict[str, DataFrame]:
        """
        Carrega todas as tabelas base com filtros mínimos e particionamento otimizado.
        Estratégia: load-first, transform-later para aproveitar lazy evaluation.
        """
        self.logger.info("Iniciando carregamento das tabelas base...")
        
        tables = {}
        
        # PEDT001 - Dados pessoais básicos
        df_data_ref_001 = self.collectOdate('b_stbr_pe.pedt001')
        tables['pedt001'] = (
            self.spark.read.table("b_stbr_pe.pedt001")
            .select("penomper", "penumdoc", "petipdoc", "penumper", "pepriape", 
                   "pefecnac", "peestciv", "penacper", "pesexper", "petipocu", 
                   "peusualt", "pesegape", "petipper")
            .where(
                (col("dat_ref_carga") == df_data_ref_001) &
                (col("petipper") == "F") &
                (~col("peusualt").isin("BG28101", "BG28102", "CIPRSANF", "CIPRSANJ", 
                                      "MQCICP", "MQWPCG", "RBD0712", "RBD0713", 
                                      "RBDO730", "RBHG702"))
            )
            .repartition(200, col("penumper"))  # Particionamento otimizado
        )
        
        # PEDT002 - Naturalidade e filiação
        df_data_ref_002 = self.collectOdate('b_stbr_pe.pedt002')
        tables['pedt002'] = (
            self.spark.read.table("b_stbr_pe.pedt002")
            .select("penumper", "peestrat", "penommad", "penompad")
            .where(col("dat_ref_carga") == df_data_ref_002)
            .repartition(200, col("penumper"))
        )
        
        # PEDT003 - Endereços e emails
        df_data_ref_003 = self.collectOdate('b_stbr_pe.pedt003')
        tables['pedt003'] = (
            self.spark.read.table("b_stbr_pe.pedt003")
            .select("penumper", "petipnur", "peobserv", "penumblo", 
                   "pedesloc", "pecodpro", "pecodpos")
            .where(col("dat_ref_carga") == df_data_ref_003)
            .repartition(200, col("penumper"))
        )
        
        # PEDT023 - Telefones
        df_data_ref_023 = self.collectOdate('b_stbr_pe.pedt023')
        tables['pedt023'] = (
            self.spark.read.table("b_stbr_pe.pedt023")
            .select("penumper", "peclatel", "pepretel", "peobserv", "petiptel")
            .where(col("dat_ref_carga") == df_data_ref_023)
            .repartition(200, col("penumper"))
        )
        
        # PEDT036 - Renda
        df_data_ref_036 = self.collectOdate('b_stbr_pe.pedt036')
        tables['pedt036'] = (
            self.spark.read.table("b_stbr_pe.pedt036")
            .select("penumper", "pefecalt", "peimping", "petiping")
            .where(
                (col("dat_ref_carga") == df_data_ref_036) &
                (col('petiping') == '099')
            )
            .repartition(200, col("penumper"))
        )
        
        # PEDT052 - PEP e coligadas
        df_data_ref_052 = self.collectOdate('b_stbr_pe.pedt052')
        tables['pedt052'] = (
            self.spark.read.table("b_stbr_pe.pedt052")
            .select("penumper", "peindica", "pevalind")
            .where(
                (col("dat_ref_carga") == df_data_ref_052) &
                (col('pevalind') == "S")
            )
            .repartition(200, col("penumper"))
        )
        
        # PEDT150 - Documentos
        df_data_ref_150 = self.collectOdate('b_stbr_pe.pedt150')
        tables['pedt150'] = (
            self.spark.read.table("b_stbr_pe.pedt150")
            .select("penumper", "penumero", "pecondoc", "petipdoc", 
                   "peexppor", "pefecexp", "pelugexp")
            .where(col("dat_ref_carga") == df_data_ref_150)
            .repartition(200, col("penumper"))
        )
        
        # PEDT205 - Bens patrimoniais
        df_data_ref_205 = self.collectOdate('b_stbr_pe.pedt205')
        tables['pedt205'] = (
            self.spark.read.table("b_stbr_pe.pedt205")
            .select("cd_pess", "tp_bem")
            .where(col("dat_ref_carga") == df_data_ref_205)
            .withColumnRenamed("cd_pess", "penumper")
            .repartition(200, col("penumper"))
        )
        
        self.logger.info(f"Carregadas {len(tables)} tabelas base com particionamento otimizado")
        return tables

    def process_unified_pipeline(self) -> DataFrame:
        """
        Pipeline unificado que processa todas as transformações em uma única operação.
        Estratégia principal de otimização para 1TB.
        """
        self.logger.info("Iniciando pipeline unificado otimizado...")
        
        # Carrega todas as tabelas
        tables = self.load_base_tables()
        
        # Tabela principal (PEDT001) com todas as transformações consolidadas
        df_base = self._process_pedt001_optimized(tables['pedt001'])
        df_base = self._track_performance("PEDT001_Optimized", df_base)
        
        # Cache estratégico da tabela base
        df_base = df_base.persist(self.storage_level_base)
        
        # Processa tabelas auxiliares de forma otimizada
        df_naturalidade = self._process_pedt002_optimized(tables['pedt002'])
        df_endereco = self._process_pedt003_optimized(tables['pedt003'])
        df_telefone = self._process_pedt023_optimized(tables['pedt023'])
        df_renda = self._process_pedt036_optimized(tables['pedt036'])
        df_pep = self._process_pedt052_optimized(tables['pedt052'])
        df_documentos = self._process_pedt150_optimized(tables['pedt150'])
        df_bens = self._process_pedt205_optimized(tables['pedt205'])
        
        # Joins otimizados com broadcast para tabelas menores
        df_result = self._perform_optimized_joins(
            df_base, df_naturalidade, df_endereco, df_telefone, 
            df_renda, df_pep, df_documentos, df_bens
        )
        
        # Transformações finais consolidadas
        df_final = self._apply_final_transformations(df_result)
        
        # Cache final com storage level otimizado
        df_final = df_final.persist(self.storage_level_final)
        df_final = self._track_performance("Pipeline_Final", df_final)
        
        return df_final

    def _process_pedt001_optimized(self, df: DataFrame) -> DataFrame:
        """Processa PEDT001 com todas as transformações consolidadas"""
        
        # Todas as transformações em uma única operação select()
        return df.select(
            col("penumper"),
            col("penumdoc").alias("cpf"),
            col("penomper").alias("nome"),
            col("pepriape"),
            col("pesegape"),
            col("pefecnac"),
            col("peestciv"),
            col("penacper"),
            col("pesexper"),
            col("petipocu"),
            
            # Transformações consolidadas usando expressões SQL
            expr(self._create_estado_civil_expr()).alias("peestciv_desc"),
            expr(self._create_sexo_expr()).alias("pesexper_desc"),
            expr(self._create_tipo_ocupacao_expr()).alias("petipocu_desc"),
            expr(self._create_nacionalidade_expr()).alias("penacper_desc"),
            
            # Cálculo de idade otimizado
            expr("CAST((DATEDIFF(CURRENT_DATE(), CAST(pefecnac AS DATE)) / 365.25) AS INT)")
                .cast("string").alias("idade"),
            
            # Concatenações otimizadas
            concat_ws(" ", col("penomper"), col("pepriape"), col("pesegape")).alias("nm_copt"),
            col("penomper").alias("nome_clean"),
            concat_ws(" ", col("pepriape"), col("pesegape")).alias("sobrenome"),
            
            # Hash para deduplicação
            sha2(concat_ws("|", col("penumper"), col("penumdoc")), 256).alias("penumper_hash"),
            md5(concat_ws("|", col("penomper"), col("penumdoc"), col("pefecnac"))).alias("identity_hash")
        ).distinct()

    def _create_estado_civil_expr(self) -> str:
        """Cria expressão SQL para mapeamento de estado civil"""
        estado_civil = self.broadcast_estado_civil.value
        case_expr = "CASE "
        for codigo, descricao in estado_civil.items():
            case_expr += f"WHEN peestciv = '{codigo}' THEN '{descricao}' "
        case_expr += "ELSE '' END"
        return case_expr

    def _create_sexo_expr(self) -> str:
        """Cria expressão SQL para mapeamento de sexo"""
        sexo = self.broadcast_sexo.value
        case_expr = "CASE "
        for codigo, descricao in sexo.items():
            case_expr += f"WHEN pesexper = '{codigo}' THEN '{descricao}' "
        case_expr += "ELSE '' END"
        return case_expr

    def _create_tipo_ocupacao_expr(self) -> str:
        """Cria expressão SQL para mapeamento de tipo de ocupação"""
        tipo_ocupacao = self.broadcast_tipo_ocupacao.value
        case_expr = "CASE "
        for codigo, descricao in tipo_ocupacao.items():
            case_expr += f"WHEN petipocu = '{codigo}' THEN '{descricao}' "
        case_expr += "ELSE '' END"
        return case_expr

    def _create_nacionalidade_expr(self) -> str:
        """Cria expressão SQL para mapeamento de nacionalidade"""
        nacionalidade = self.broadcast_nacionalidade.value
        case_expr = "CASE "
        for codigo, descricao in nacionalidade.items():
            case_expr += f"WHEN penacper = '{codigo}' THEN '{descricao}' "
        case_expr += "ELSE '' END"
        return case_expr

    def _process_pedt002_optimized(self, df: DataFrame) -> DataFrame:
        """Processa PEDT002 com lookup otimizado de estados"""
        return df.select(
            col("penumper"),
            col("penommad"),
            col("penompad"),
            expr(self._create_estado_lookup_expr("peestrat", "full")).alias("natural")
        ).distinct()

    def _process_pedt003_optimized(self, df: DataFrame) -> DataFrame:
        """
        Processa PEDT003 com eliminação de joins desnecessários usando window functions
        """
        # Window specification para agrupamento
        window_spec = Window.partitionBy("penumper")
        
        # Todas as transformações em uma única operação
        df_transformed = df.select(
            col("penumper"),
            col("petipnur"),
            col("peobserv"),
            col("penumblo"),
            col("pedesloc"),
            expr(self._create_estado_lookup_expr("pecodpro", "sigla")).alias("pecodpro_desc"),
            col("pecodpos"),
            
            # Endereço residencial
            when(
                col("petipnur") == "0001",
                concat_ws(", ",
                    trim(substring(col("peobserv"), 1, 70)),
                    trim(col("penumblo")),
                    concat(lit(" - "), trim(substring(col("peobserv"), 71, 72))),
                    concat(lit(" - "), trim(col("pedesloc"))),
                    concat(lit(" - "), expr(self._create_estado_lookup_expr("pecodpro", "sigla"))),
                    trim(col("pecodpos"))
                )
            ).alias("end_res_raw"),
            
            # Endereço comercial
            when(
                col("petipnur") == "0002",
                concat_ws(", ",
                    trim(substring(col("peobserv"), 1, 70)),
                    trim(col("penumblo")),
                    concat(lit(" - "), trim(substring(col("peobserv"), 71, 72))),
                    concat(lit(" - "), trim(col("pedesloc"))),
                    concat(lit(" - "), expr(self._create_estado_lookup_expr("pecodpro", "sigla"))),
                    trim(col("pecodpos"))
                )
            ).alias("end_com_raw"),
            
            # Email
            when(
                col("petipnur").isin("0008", "0009"),
                trim(substring(col("peobserv"), 1, 70))
            ).alias("email_raw")
        )
        
        # Agrupamento consolidado com window functions
        return df_transformed.select(
            col("penumper"),
            
            # Agregações usando window functions (mais eficiente que groupBy + join)
            first(col("end_res_raw"), ignorenulls=True).over(window_spec).alias("end_res"),
            first(col("end_com_raw"), ignorenulls=True).over(window_spec).alias("end_com"),
            concat_ws(", ", 
                sort_array(
                    collect_set(col("email_raw")).over(window_spec)
                )
            ).alias("email")
        ).distinct().select(
            col("penumper"),
            regexp_replace(col("end_res"), "\\s+", " ").alias("end_res"),
            regexp_replace(col("end_com"), "\\s+", " ").alias("end_com"),
            col("email")
        )

    def _process_pedt023_optimized(self, df: DataFrame) -> DataFrame:
        """Processa PEDT023 com regex otimizado"""
        
        # Window specification
        window_spec = Window.partitionBy("penumper")
        
        return df.select(
            col("penumper"),
            
            # Telefone residencial
            when(
                (col("peclatel") == "001") & col("pepretel").isNotNull(),
                concat(col('pepretel'), substring(col("peobserv"), 21, 10))
            ).alias("nr_tel_res_raw"),
            
            # Telefone comercial
            when(
                (col("peclatel") == "002") & col("pepretel").isNotNull(),
                concat(col('pepretel'), substring(col("peobserv"), 21, 10))
            ).alias("nr_tel_com_raw"),
            
            # Telefone celular
            when(
                (col("petiptel") == "002") & col("pepretel").isNotNull(),
                concat(col('pepretel'), substring(col("peobserv"), 21, 10))
            ).alias("nr_tel_cel_raw")
        ).select(
            col("penumper"),
            
            # Limpeza e agregação em uma única operação
            regexp_replace(
                concat_ws(",", 
                    sort_array(collect_set(col("nr_tel_res_raw")).over(window_spec))
                ),
                "^[,\\s]+|[,\\s]+$|,,+", ""
            ).alias("nr_tel_res"),
            
            regexp_replace(
                concat_ws(",", 
                    sort_array(collect_set(col("nr_tel_com_raw")).over(window_spec))
                ),
                "^[,\\s]+|[,\\s]+$|,,+", ""
            ).alias("nr_tel_com"),
            
            regexp_replace(
                concat_ws(",", 
                    sort_array(collect_set(col("nr_tel_cel_raw")).over(window_spec))
                ),
                "^[,\\s]+|[,\\s]+$|,,+", ""
            ).alias("nr_tel_cel")
        ).distinct()

    def _process_pedt036_optimized(self, df: DataFrame) -> DataFrame:
        """Processa PEDT036 (renda) de forma otimizada"""
        return df.groupBy("penumper").agg(
            max("pefecalt").alias("pefecalt"),
            first("peimping").alias("renda")
        ).select(
            col("penumper"),
            col("pefecalt"),
            col("renda").cast("string").alias("renda")
        )

    def _process_pedt052_optimized(self, df: DataFrame) -> DataFrame:
        """Processa PEDT052 (PEP) com eliminação de joins"""
        
        # Window specification
        window_spec = Window.partitionBy("penumper")
        
        return df.select(
            col("penumper"),
            col("peindica"),
            col("pevalind"),
            
            # Mapeamento PEP
            expr(self._create_pep_expr()).alias("pep_desc"),
            
            # Coligada
            when(
                col("peindica").isin("980", "998") & (col("pevalind") == "S"),
                col("peindica")
            ).alias("coligada_raw")
        ).select(
            col("penumper"),
            col("pevalind"),
            
            # Agregações consolidadas
            concat_ws(",", 
                sort_array(collect_set(col("pep_desc")).over(window_spec))
            ).alias("pep"),
            
            concat_ws(",", 
                sort_array(collect_set(col("coligada_raw")).over(window_spec))
            ).alias("coligada"),
            
            concat_ws(",", 
                sort_array(
                    collect_set(
                        when(col("peindica").isin("046", "047", "048"), col("peindica"))
                    ).over(window_spec)
                )
            ).alias("pep_ind")
        ).distinct().select(
            col("penumper"),
            col("pevalind"),
            regexp_replace(col("pep"), "^,|,$|,,+", "").alias("pep"),
            regexp_replace(col("coligada"), "^,|,$", "").alias("coligada"),
            col("pep_ind")
        )

    def _create_pep_expr(self) -> str:
        """Cria expressão SQL para mapeamento de PEP"""
        pep = self.broadcast_pep.value
        case_expr = "CASE "
        for codigo, descricao in pep.items():
            case_expr += f"WHEN peindica = '{codigo}' THEN '{descricao}' "
        case_expr += "ELSE '' END"
        return case_expr

    def _process_pedt150_optimized(self, df: DataFrame) -> DataFrame:
        """Processa PEDT150 (documentos) com transformações consolidadas"""
        
        # Filtro para documentos relevantes
        df_filtered = df.where(
            col("petipdoc").isin("01", "02", "04", "07", "08", "09", "10", "12", "36", "39", "13")
        )
        
        # Window specification
        window_spec = Window.partitionBy("penumper")
        
        return df_filtered.select(
            col("penumper"),
            col("petipdoc"),
            col("penumero"),
            col("peexppor"),
            col("pefecexp"),
            expr(self._create_estado_lookup_expr("pelugexp", "full")).alias("cd_esta_emis"),
            
            # Concatenação otimizada de documentos
            concat_ws(" ", 
                trim(col("penumero")),
                trim(col("peexppor")),
                trim(col("pefecexp")),
                expr(self._create_estado_lookup_expr("pelugexp", "full"))
            ).alias("documento_completo")
        ).select(
            col("penumper"),
            
            # Documentos específicos usando window functions
            first(
                when(col("petipdoc") == "01", col("documento_completo")),
                ignorenulls=True
            ).over(window_spec).alias("identidade_rg"),
            
            first(
                when(col("petipdoc") == "02", col("documento_completo")),
                ignorenulls=True
            ).over(window_spec).alias("carteira_profissional"),
            
            first(
                when(col("petipdoc") == "04", col("documento_completo")),
                ignorenulls=True
            ).over(window_spec).alias("passaporte"),
            
            first(
                when(col("petipdoc") == "07", col("documento_completo")),
                ignorenulls=True
            ).over(window_spec).alias("pis"),
            
            first(
                when(col("petipdoc") == "08", col("documento_completo")),
                ignorenulls=True
            ).over(window_spec).alias("titulo_de_eleitor"),
            
            first(
                when(col("petipdoc") == "09", col("documento_completo")),
                ignorenulls=True
            ).over(window_spec).alias("identidade_entidades_classe"),
            
            first(
                when(col("petipdoc") == "10", col("documento_completo")),
                ignorenulls=True
            ).over(window_spec).alias("rne_registro_nac_estrang"),
            
            first(
                when(col("petipdoc") == "12", col("documento_completo")),
                ignorenulls=True
            ).over(window_spec).alias("cnh_cart_nac_habilitacao"),
            
            first(
                when(col("petipdoc") == "36", col("documento_completo")),
                ignorenulls=True
            ).over(window_spec).alias("protocolo_do_pedido_refugio"),
            
            first(
                when(col("petipdoc") == "39", col("documento_completo")),
                ignorenulls=True
            ).over(window_spec).alias("guia_de_acolhimento")
        ).distinct()

    def _process_pedt205_optimized(self, df: DataFrame) -> DataFrame:
        """Processa PEDT205 (bens) com lookup otimizado"""
        
        # Window specification
        window_spec = Window.partitionBy("penumper")
        
        return df.select(
            col("penumper"),
            expr(self._create_tipo_bem_expr()).alias("tp_bem_desc")
        ).select(
            col("penumper"),
            concat_ws(",", 
                sort_array(collect_set(col("tp_bem_desc")).over(window_spec))
            ).alias("tp_bem")
        ).distinct()

    def _create_tipo_bem_expr(self) -> str:
        """Cria expressão SQL para mapeamento de tipos de bem"""
        tipo_bem = self.broadcast_tipo_bem.value
        case_expr = "CASE "
        for codigo, descricao in tipo_bem.items():
            case_expr += f"WHEN tp_bem = '{codigo}' THEN '{descricao}' "
        case_expr += "ELSE '' END"
        return case_expr

    def _perform_optimized_joins(self, df_base: DataFrame, df_naturalidade: DataFrame,
                                df_endereco: DataFrame, df_telefone: DataFrame,
                                df_renda: DataFrame, df_pep: DataFrame,
                                df_documentos: DataFrame, df_bens: DataFrame) -> DataFrame:
        """
        Realiza joins otimizados com broadcast automático para tabelas menores
        """
        self.logger.info("Iniciando joins otimizados...")
        
        # Função para determinar se deve usar broadcast
        def smart_join(large_df: DataFrame, small_df: DataFrame, join_key: str) -> DataFrame:
            try:
                # Estima o tamanho da tabela menor
                small_count = small_df.count()
                estimated_size = small_count * 1000  # Estimativa conservadora de 1KB por registro
                
                if estimated_size < 200_000_000:  # 200MB
                    self.logger.info(f"Usando broadcast join para tabela com {small_count:,} registros")
                    return large_df.join(broadcast(small_df), join_key, "left")
                else:
                    self.logger.info(f"Usando join regular para tabela com {small_count:,} registros")
                    return large_df.join(small_df, join_key, "left")
            except Exception as e:
                self.logger.warning(f"Erro ao determinar tipo de join: {e}. Usando join regular.")
                return large_df.join(small_df, join_key, "left")
        
        # Sequência de joins otimizados
        result = df_base
        
        # Join com naturalidade (geralmente pequena)
        result = smart_join(result, df_naturalidade, "penumper")
        result = self._track_performance("Join_Naturalidade", result)
        
        # Join com endereços
        result = smart_join(result, df_endereco, "penumper")
        result = self._track_performance("Join_Endereco", result)
        
        # Join com telefones
        result = smart_join(result, df_telefone, "penumper")
        result = self._track_performance("Join_Telefone", result)
        
        # Join com renda (geralmente pequena)
        result = smart_join(result, df_renda, "penumper")
        result = self._track_performance("Join_Renda", result)
        
        # Join com PEP (geralmente pequena)
        result = smart_join(result, df_pep, "penumper")
        result = self._track_performance("Join_PEP", result)
        
        # Join com documentos
        result = smart_join(result, df_documentos, "penumper")
        result = self._track_performance("Join_Documentos", result)
        
        # Join com bens (geralmente pequena)
        result = smart_join(result, df_bens, "penumper")
        result = self._track_performance("Join_Bens", result)
        
        return result

    def _apply_final_transformations(self, df: DataFrame) -> DataFrame:
        """Aplica transformações finais e seleciona colunas do resultado"""
        
        return df.select(
            col("penumper"),
            col("cpf"),
            col("nome_clean").alias("nome"),
            col("sobrenome"),
            col("nm_copt"),
            col("pefecnac"),
            col("identidade_rg"),
            col("cnh_cart_nac_habilitacao"),
            col("carteira_profissional"),
            col("protocolo_do_pedido_refugio"),
            col("passaporte"),
            col("guia_de_acolhimento"),
            col("idade"),
            col("penacper_desc").alias("penacper"),
            col("email"),
            col("natural"),
            col("penommad"),
            col("penompad"),
            col("end_res"),
            col("end_com"),
            col("peestciv_desc").alias("peestciv"),
            col("pesexper_desc").alias("pesexper"),
            col("nr_tel_res"),
            col("nr_tel_com"),
            col("nr_tel_cel"),
            col("petipocu_desc").alias("petipocu"),
            col("renda"),
            col("tp_bem"),
            col("pep"),
            col("titulo_de_eleitor"),
            col("identidade_entidades_classe"),
            col("pis"),
            col("rne_registro_nac_estrang"),
            
            # Campos adicionais para compatibilidade
            lit(None).cast("string").alias("imei_celular"),
            lit(None).cast("string").alias("origem_racial"),
            lit(None).cast("string").alias("geolocalizacao"),
            lit(None).cast("string").alias("foto"),
            lit(None).cast("string").alias("biometria"),
            
            # Metadados
            current_date().alias("dat_ref_carga"),
            col("penumper_hash"),
            col("identity_hash")
        ).dropDuplicates(["penumper", "cpf", "nome"])

    def execute_optimized_pipeline(self) -> DataFrame:
        """
        Executa o pipeline completo otimizado para 1TB
        """
        start_time = time.time()
        self.logger.info("=== INICIANDO PIPELINE OTIMIZADO PARA 1TB ===")
        
        try:
            # Executa o pipeline unificado
            df_result = self.process_unified_pipeline()
            
            # Reparticionamento final otimizado para escrita
            df_result = df_result.repartition(64, col("penumper"))
            
            # Métricas finais
            total_time = time.time() - start_time
            final_count = df_result.count()
            
            self.logger.info(f"=== PIPELINE CONCLUÍDO ===")
            self.logger.info(f"Registros processados: {final_count:,}")
            self.logger.info(f"Tempo total: {total_time:.2f} segundos")
            self.logger.info(f"Throughput: {final_count/total_time:.0f} registros/segundo")
            
            # Log das métricas de performance
            self._log_performance_summary()
            
            return df_result
            
        except Exception as e:
            self.logger.error(f"Erro no pipeline otimizado: {e}")
            raise

    def _log_performance_summary(self):
        """Log do resumo de performance"""
        self.logger.info("=== RESUMO DE PERFORMANCE ===")
        total_duration = sum(m['duration_seconds'] for m in self.performance_metrics.values())
        total_records = sum(m['record_count'] for m in self.performance_metrics.values())
        
        for stage, metrics in self.performance_metrics.items():
            self.logger.info(
                f"{stage}: {metrics['record_count']:,} registros, "
                f"{metrics['duration_seconds']:.2f}s, "
                f"{metrics['throughput_records_per_second']:.0f} rec/s"
            )
        
        self.logger.info(f"TOTAL: {total_records:,} registros em {total_duration:.2f}s")
        self.logger.info(f"THROUGHPUT MÉDIO: {total_records/total_duration:.0f} registros/segundo")

    def get_performance_metrics(self) -> Dict:
        """Retorna métricas de performance para análise"""
        return self.performance_metrics

    def cleanup_resources(self):
        """Limpa recursos e unpersist DataFrames"""
        try:
            # Unpersist todos os DataFrames em cache
            self.spark.catalog.clearCache()
            
            # Destroy broadcast variables
            if hasattr(self, 'broadcast_estados'):
                self.broadcast_estados.destroy()
            if hasattr(self, 'broadcast_estados_sigla'):
                self.broadcast_estados_sigla.destroy()
            if hasattr(self, 'broadcast_estado_civil'):
                self.broadcast_estado_civil.destroy()
            if hasattr(self, 'broadcast_sexo'):
                self.broadcast_sexo.destroy()
            if hasattr(self, 'broadcast_tipo_ocupacao'):
                self.broadcast_tipo_ocupacao.destroy()
            if hasattr(self, 'broadcast_nacionalidade'):
                self.broadcast_nacionalidade.destroy()
            if hasattr(self, 'broadcast_tipo_bem'):
                self.broadcast_tipo_bem.destroy()
            if hasattr(self, 'broadcast_pep'):
                self.broadcast_pep.destroy()
                
            self.logger.info("Recursos limpos com sucesso")
            
        except Exception as e:
            self.logger.warning(f"Erro ao limpar recursos: {e}")


# Exemplo de uso
if __name__ == "__main__":
    from pyspark.sql import SparkSession
    import logging
    
    # Configurar logging
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    
    # Criar SparkSession
    spark = SparkSession.builder \
        .appName("DadosCadastraisOtimizado") \
        .config("spark.sql.adaptive.enabled", "true") \
        .getOrCreate()
    
    try:
        # Instanciar classe otimizada
        dados_cadastrais = DadosCadastraisOtimizado(spark, logger)
        
        # Executar pipeline otimizado
        df_resultado = dados_cadastrais.execute_optimized_pipeline()
        
        # Salvar resultado (exemplo)
        # df_resultado.write.mode("overwrite").saveAsTable("dados_cadastrais_otimizado")
        
        # Obter métricas
        metricas = dados_cadastrais.get_performance_metrics()
        print("Métricas de Performance:", metricas)
        
    finally:
        # Limpar recursos
        dados_cadastrais.cleanup_resources()
        spark.stop()

