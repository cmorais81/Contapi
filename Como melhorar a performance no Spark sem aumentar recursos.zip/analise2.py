 import os
import psycopg2
from pyspark.sql.functions import current_timestamp, date_format
from pyspark.sql.functions import monotonically_increasing_id #ID inserido para particionar o dataframe de inserção
from pyspark import StorageLevel

class CompareData:
    def __init__(self, logger, dbutils, spark):
        self.host = os.environ["env_host_postgres"]
        self.dbname = os.environ["env_database_postgres"]
        self.user = os.environ["env_user_postgres"]
        self.password = dbutils.secrets.get(scope="lpd", key="lpduser")
        self.logger = logger
        self.spark = spark
        self.env = os.environ.get("ENV_AMBIENTE")
        self.storage_level = StorageLevel.MEMORY

        self.properties = {"user": self.user,
                           "host": self.host,
                           "dbname": self.dbname,
                           "password": self.password,
                           "driver": "org.postgresql.Driver"}
        
    def read_dossie_simples(self):
        #função para ler a tabela tb_dossie_simples em um dataframe
        try:
            self.logger.info("Lendo registros no postgres")

            df = self.spark.read.format("jdbc").option("url", f"jdbc:postgresql://{self.host}/{self.dbname}") \
                .option("query", "SELECT penumper, identity_hash FROM tb_dossie_simples") \
                .option("user", self.user) \
                .option("password", self.password) \
                .option("driver", "org.postgresql.Driver") \
                .load()

            # self.logger.info("------------------")
            # self.logger.info(f"Registros lidos do Postgres {df.count()}")
            # self.logger.info("------------------")

            return df.persist(self.storage_level)

        except Exception as exp:
            self.logger.info("Falha na leitura da tabela tb_dossie_simples")
            self.logger.error(exp)


    def data_compare(self, df1, df2):
        try:
            #função que compara os registros do postgresql com os novos registros gerados pelo motor
            #df1 = resultado do motor
            #df2 = leitura do postgresql
            #retorna uma lista para deleção de registros que foram alterados, um dataframe com registros novos
            #e um booleano que indica se o dataframe final está vazio ou não
            self.logger.info("Realizando join dos registros do postgres com os novos dados")

            #Seleciona apenas as colunas necessárias para a comparação
            changed_keys = df1.join(df2, on="penumper", how="inner") \
                .filter(
                    (df1.identity_hash != df2.identity_hash) |
                    (df1.identity_hash.isNotNull() & df2.identity_hash.isNull())
                ) \
                .select(df1["penumper"], df1["identity_hash"])

            #Seleciona apenas as colunas necessárias para a comparação
            new_keys = df1.join(df2, on="penumper", how="left_anti") \
                .select(df1["penumper"], df1["identity_hash"])

            # Realiza o join para obter todas as colunas para a escrita
            changed_records = changed_keys.join(df1, on=["penumper", "identity_hash"], how="inner") # dataframe com o que mudou
            new_records = new_keys.join(df1, on=["penumper", "identity_hash"], how="inner") # dataframe com o que eh novo

            df1.unpersist()
            df2.unpersist()

            # Sempre insere todos os changed_records (os que serão deletados)
            changed_count = changed_records.count() # primeira action a ser executada
            changed_records = changed_records.withColumn("update_date", date_format(current_timestamp(), "yyyyMMdd HH:mm:ss"))
            new_records = new_records.withColumn("update_date", date_format(current_timestamp(), "yyyyMMdd HH:mm:ss"))

            # Se changed_records < 4mi, completa com new_records até 4mi
            #TODO validar
            if changed_count < 4000000:
                limit_new = 4000000 - changed_count
                new_records_limited = new_records.limit(limit_new)
                df_to_be_written = changed_records.unionByName(new_records_limited)
            else:
                df_to_be_written = changed_records.limit(4000000)

            # Lista de penumperes a serem deletados = todos os changed_records inseridos
            keys_to_delete_list = [row["penumper"] for row in changed_records.select("penumper").collect()]

            count = df_to_be_written.count()

            self.logger.info("------------------")
            self.logger.info(f"Número de registros a serem deletados: {len(keys_to_delete_list)}")
            self.logger.info(f"Número de registros a serem inseridos/atualizados: {count}")
            self.logger.info("------------------")

            df_is_empty = (count == 0)  # checa se o dataframe está vazio e seta a variavel como true ou false

            return keys_to_delete_list, df_to_be_written, df_is_empty, count

        except Exception as exp:
            self.logger.error("Falha na comparação dos dados")
            self.logger.error(exp)

    def delete_data(self, penumper_list, batch_size=10000):
        # Função que deleta do postgresql os registros que foram alterados em batches
        try:
            self.logger.info("Iniciando deleção de registros no postgres")
            if not penumper_list:
                self.logger.info("Lista de penumperes para deleção está vazia.")
                return

            con = psycopg2.connect(host=self.host, database=self.dbname,
                                   user=self.user, password=self.password)
            cur = con.cursor()

            total = len(penumper_list)
            for i in range(0, total, batch_size):
                batch = penumper_list[i:i+batch_size]
                # Garante que cada penumper está entre aspas simples
                batch_str = ",".join([f"'{x}'" for x in batch])
                query = f"DELETE FROM tb_dossie_simples WHERE penumper IN ({batch_str})"
                self.logger.info(f"Deletando batch {i//batch_size+1}: {len(batch)} registros")
                cur.execute(query)
                con.commit()

            con.close()
            self.logger.info("Deleção realizada com sucesso.")

        except Exception as exp:
            self.logger.info("Falha na exclusão dos dados no postgres")
            self.logger.error(exp)


    def insert_new_and_altered_data(self, df, total):
        try:
            self.logger.info("Iniciando inserção de registros no postgres")
            batch_size = total // 4 if total >= 4 else total  # Evita divisão por zero ou batches vazios
            num_batches = 4 if total >= 4 else 1

            # Adiciona um índice para facilitar o particionamento, ele será dropado antes da inserção
            df = df.withColumn("_row_id", monotonically_increasing_id())
            df.persist(self.storage_level)

            for i in range(num_batches):
                start = i * batch_size
                end = (i + 1) * batch_size if i < num_batches - 1 else total  # Último batch vai até o final dos registros
                batch_df = df.filter((df._row_id >= start) & (df._row_id < end)).drop("_row_id")
                self.logger.info(f"Inserindo batch {i+1} de {num_batches} (Registros de {start} a {end})")

                batch_df.write.format("jdbc") \
                    .option("url", f"jdbc:postgresql://{self.host}/{self.dbname}") \
                    .option("batchsize", str(batch_size)) \
                    .option("isolationLevel", "NONE") \
                    .option("rewriteBatchedStatements", "true") \
                    .option("compression", "snappy") \
                    .option("dbtable", "tb_dossie_simples") \
                    .option("user", self.user) \
                    .option("password", self.password) \
                    .option("driver", "org.postgresql.Driver") \
                    .mode("append") \
                    .save()

            self.logger.info("Inserção no postgres realizada com sucesso.")
            df.unpersist()

        except Exception as exp:
            self.logger.info("Falha na inserção dos dados no postgres")
            self.logger.error(exp)
