from pyspark.sql.types import DateType
from datetime import date
from pyspark.sql.functions import (
    col,
    concat,
    max,
    regexp_replace,
    when,
    trim,
    lit,
    substring,
    coalesce,
    first,
    concat_ws,
    collect_list,
    sort_array,
    datediff,
    current_date,
    lpad,
    upper,
    sha2,
    md5,
)
from pyspark import StorageLevel


class DadosCadastrais:
    """
    Coleta dos dados e aplicacao de regras
    :return: tupla
    """

    def __init__(self, spark, logger):
        self.spark = spark
        self.logger = logger
        self.storage_level = StorageLevel.DISK
        # Data de referencia para 1 ano de historico
        #self.df_data_ref = datetime.now() - timedelta(days=365)

    def collectOdate(self, tabela):

        odate = self.spark.sql(f'show partitions {tabela}').orderBy(col('dat_ref_carga').asc()).collect()[-1][-1]

        return odate

    def coletapedt001(self):
        """
        Coleta de informacoes de dados cadastrais na tabela PEDT001
        :return: Dataframe
        """

        df_data_ref = self.collectOdate('b_stbr_pe.pedt001')

        # Load dos dados
        df_pedt001 = (
            self.spark.read.table("b_stbr_pe.pedt001")
            .select(
                "penomper",
                "penumdoc",
                "petipdoc",
                "penumper",
                "pepriape",
                "pefecnac",
                "peestciv",
                "penacper",
                "pesexper",
                "petipocu",
                "peusualt",
                "pesegape",
                "petipper",
            )
            .where(col("dat_ref_carga") == df_data_ref)
            .distinct()
            .where(
                (col("petipper") == "F")
                & (
                    ~col("peusualt").isin(
                        "BG28101",
                        "BG28102",
                        "CIPRSANF",
                        "CIPRSANJ",
                        "MQCICP",
                        "MQWPCG",
                        "RBD0712",
                        "RBD0713",
                        "RBDO730",
                        "RBHG702",
                    )
                )
            )
        )

        # Transformacoes
        df_pedt001_aj = (
            df_pedt001.withColumn(
                "peestciv",
                when(col("peestciv") == "A", "CASADO(A) S/ INFORMACAO DE REGIME")
                .when(col("peestciv") == "B", "CASADO(A)-PARTICIP FINAL DOS AQUESTOS")
                .when(col("peestciv") == "1", "SOLTEIRO(A)")
                .when(col("peestciv") == "3", "VIUVO(A)")
                .when(col("peestciv") == "4", "DIVORCIADO/A")
                .when(col("peestciv") == "5", "SEPARADO/A JUDICIALMENTE")
                .when(col("peestciv") == "6", "UNIAO ESTAVEL")
                .when(col("peestciv") == "7", "CASADO(A)-COMUNHAO PARCIAL BENS")
                .when(col("peestciv") == "8", "CASADO(A)-COMUNHAO UNIVERSAL BENS")
                .when(col("peestciv") == "9", "CASADO(A)-SEPARACAO BENS")
                .otherwise(""),
            )
            .withColumn(
                "pesexper",
                when(col("pesexper") == "H", "masculino")
                .when(col("pesexper") == "M", "feminino")
                .otherwise(""),
            )
            .withColumn(
                "petipocu",
                when(col("petipocu") == "01", "MAIOR C/RENDA")
                .when(col("petipocu") == "02", "MENOR RELATIV.INCAPAZ")
                .when(col("petipocu") == "03", "MENOR ABSOLUT.INCAPAZ")
                .when(col("petipocu") == "04", "MENOR EMANCIP.C/RENDA")
                .when(col("petipocu") == "05", "INTERDITO")
                .when(col("petipocu") == "06", "ANALFABETO")
                .when(col("petipocu") == "07", "DEF VISUAL/AUDI - MAIOR COM RENDA")
                .when(col("petipocu") == "08", "ESPOLIO")
                .when(col("petipocu") == "09", "MENOR APRENDIZ")
                .when(col("petipocu") == "10", "MAIOR SEM RENDA")
                .when(col("petipocu") == "11", "MENOR EMANCIP.S/RENDA")
                .when(col("petipocu") == "12", "DEF VISUAL/AUDI - MAIOR SEM RENDA")
                .when(col("petipocu") == "13", "DEF VISUAL/AUDI-MENOR EMANCIP C/RENDA")
                .when(col("petipocu") == "14", "DEF VISUAL/AUDI-MENOR EMANCIP S/RENDA")
                .when(col("petipocu") == "15", "DEF VISUAL/AUDI-MENOR RELATIV INCAPAZ")
                .when(col("petipocu") == "16", "DEF VISUAL/AUDI-MENOR ABSOLUT INCAPAZ")
                .when(col("petipocu") == "17", "PESSOA FALECIDA")
                .otherwise(""),
            )
            .withColumn(
                "penacper",
                when(col("penacper") == "BRA", "BRASILEIRA")
                .when(col("penacper") == "EXT", "ESTRANGEIRA")
                .when(col("penacper") == "NAT", "NATURALIZADA")
                .otherwise(""),
            )
            .withColumn(
                "idade",
                (datediff(current_date(), col("pefecnac").cast(DateType())) / 365.25)
                .cast("int")
                .cast("string"),
            )
            .withColumn(
                "nm_copt", concat(col("penomper"), col("pepriape"), col("pesegape"))
            )
            .withColumn("nome", concat(col("penomper")))
            .withColumn("sobrenome", concat(col("pepriape"), col("pesegape")))
        )

        df_pedt001_gb = df_pedt001_aj.withColumn(
            "sobrenome",
            when(
                ((col("sobrenome") != "") | (col("sobrenome").isNotNull())),
                col("sobrenome"),
            ).otherwise(None),
        )

        return df_pedt001_gb.persist(self.storage_level)

    def coletapedt205(self):
        """
        Coleta de informacoes de dados cadastrais na tabela PEDT205
        :return: Dataframe
        """
        df_data_ref = self.collectOdate('b_stbr_pe.pedt205')

        # Load dos dados
        df_pedt205 = (
            self.spark.read.table("b_stbr_pe.pedt205")
            .select("cd_pess", "tp_bem")
            .where(col("dat_ref_carga") == df_data_ref)
            .distinct()
        )

        # Transformacoes
        df_pedt205_aj = df_pedt205.withColumn(
            "tp_bem",
            when(col("tp_bem") == "01", "ACOES")
            .when(col("tp_bem") == "02", "AUTOMOVEIS")
            .when(col("tp_bem") == "03", "IMOVEIS")
            .when(col("tp_bem") == "04", "INVESTIMENTOS")
            .when(col("tp_bem") == "05", "NAO POSSUI")
            .when(col("tp_bem") == "06", "OUTROS")
            .when(col("tp_bem") == "07", "NAO INFORMADO")
            .when(col("tp_bem") == "08", "PATRIMONIO LIQUIDO")
            .otherwise(""),
        )

        # Agrupamento de dados distribuidos em linhas, para lista dentro da campo
        dados_groupby = (
            df_pedt205_aj.groupBy("cd_pess")
            .agg(concat_ws(",", sort_array(collect_list("tp_bem"))).alias("tp_bem"))
            .withColumnRenamed("cd_pess", "penumper")
        )

        result = dados_groupby

        return result.persist(self.storage_level)

    def coletapedt002(self):
        """
        Coleta de informacoes de dados cadastrais na tabela PEDT205
        :return: Dataframe
        """
        df_data_ref = self.collectOdate('b_stbr_pe.pedt002')

        # Load dos dados
        df_pedt002 = (
            self.spark.read.table("b_stbr_pe.pedt002")
            .select("penumper", "peestrat", "penommad", "penompad")
            .where(col("dat_ref_carga") == df_data_ref)
            .distinct()
        )

        # Transformacoes
        df_pedt002_aj = df_pedt002.withColumn(
            "natural",
            when(col("peestrat") == "01", "AC - ACRE")
            .when(col("peestrat") == "02", "AL - ALAGOAS")
            .when(col("peestrat") == "03", "AP - AMAPA")
            .when(col("peestrat") == "04", "AM - AMAZONAS")
            .when(col("peestrat") == "05", "BA - BAHIA")
            .when(col("peestrat") == "06", "CE - CEARA")
            .when(col("peestrat") == "07", "ES - ESPIRITO SANTO")
            .when(col("peestrat") == "08", "GO - GOIAS")
            .when(col("peestrat") == "09", "MA - MARANHAO")
            .when(col("peestrat") == "10", "MT - MATO GROSSO")
            .when(col("peestrat") == "11", "MS - MATO GROSSO DO SUL")
            .when(col("peestrat") == "12", "MG - MINAS GERAIS")
            .when(col("peestrat") == "13", "PA - PARA")
            .when(col("peestrat") == "14", "PB - PARAIBA")
            .when(col("peestrat") == "15", "PR - PARANA")
            .when(col("peestrat") == "16", "PE - PERNAMBUCO")
            .when(col("peestrat") == "17", "PI - PIAUI")
            .when(col("peestrat") == "18", "RJ - RIO DE JANEIRO")
            .when(col("peestrat") == "19", "RN - RIO GRANDE DO NORTE")
            .when(col("peestrat") == "20", "RS - RIO GRANDE DO SUL")
            .when(col("peestrat") == "21", "RO - RONDONIA")
            .when(col("peestrat") == "22", "RR - RORAIMA")
            .when(col("peestrat") == "23", "SC - SANTA CATARINA")
            .when(col("peestrat") == "24", "SP - SAO PAULO")
            .when(col("peestrat") == "25", "SE - SERGIPE")
            .when(col("peestrat") == "26", "TO - TOCANTINS")
            .when(col("peestrat") == "27", "DF - DISTRITO FEDERAL")
            .when(col("peestrat") == "99", "ZZ - NAO INFORMADA")
            .otherwise(""),
        )

        return df_pedt002_aj.persist(self.storage_level)

    def coletapedt003(self):
        """
        Coleta de informacoes de dados cadastrais na tabela PEDT003
        :return: Dataframe
        """

        df_data_ref = self.collectOdate('b_stbr_pe.pedt003')

        # Load dos dados
        df_pedt003 = (
            self.spark.read.table("b_stbr_pe.pedt003")
                .select(
                "penumper",
                "petipnur",
                "peobserv",
                "penumblo",
                "pedesloc",
                "pecodpro",
                "pecodpos",
            ).where(col("dat_ref_carga") == df_data_ref)
                .withColumn(
                "pecodpro",
                when(col("pecodpro") == "01", "AC")
                    .when(col("pecodpro") == "02", "AL")
                    .when(col("pecodpro") == "03", "AP")
                    .when(col("pecodpro") == "04", "AM")
                    .when(col("pecodpro") == "05", "BA")
                    .when(col("pecodpro") == "06", "CE")
                    .when(col("pecodpro") == "07", "ES")
                    .when(col("pecodpro") == "08", "GO")
                    .when(col("pecodpro") == "09", "MA")
                    .when(col("pecodpro") == "10", "MT")
                    .when(col("pecodpro") == "11", "MS")
                    .when(col("pecodpro") == "12", "MG")
                    .when(col("pecodpro") == "13", "PA")
                    .when(col("pecodpro") == "14", "PB")
                    .when(col("pecodpro") == "15", "PR")
                    .when(col("pecodpro") == "16", "PE")
                    .when(col("pecodpro") == "17", "PI")
                    .when(col("pecodpro") == "18", "RJ")
                    .when(col("pecodpro") == "19", "RN")
                    .when(col("pecodpro") == "20", "RS")
                    .when(col("pecodpro") == "21", "RO")
                    .when(col("pecodpro") == "22", "RR")
                    .when(col("pecodpro") == "23", "SC")
                    .when(col("pecodpro") == "24", "SP")
                    .when(col("pecodpro") == "25", "SE")
                    .when(col("pecodpro") == "26", "TO")
                    .when(col("pecodpro") == "27", "DF")
                    .when(col("pecodpro") == "99", "ZZ")
                    .otherwise(""),
            ).distinct()
        )

        # Transformacoes
        df_endereco = (
            df_pedt003.withColumn(
                "end_res",
                when(
                    col("petipnur") == "0001",
                    trim(
                        concat(
                            trim(substring(col("peobserv"), 1, 70)),
                            lit(", "),
                            trim(col("penumblo")),
                            lit(" - "),
                            trim(substring(col("peobserv"), 71, 72)),
                            lit(" - "),
                            trim(col("pedesloc")),
                            lit(" - "),
                            trim(col("pecodpro")),
                            lit(", "),
                            trim(col("pecodpos")),
                        )
                    ),
                ).otherwise(None),
            ).withColumn(
                "end_com",
                when(
                    col("petipnur") == "0002",
                    trim(
                        concat(
                            trim(substring(col("peobserv"), 1, 70)),
                            lit(", "),
                            trim(col("penumblo")),
                            lit(" - "),
                            trim(substring(col("peobserv"), 71, 72)),
                            lit(" - "),
                            trim(col("pedesloc")),
                            lit(" - "),
                            trim(col("pecodpro")),
                            lit(", "),
                            trim(col("pecodpos")),
                        )
                    ),
                ).otherwise(None),
            ).withColumn(
                "email",
                when(
                    ((col("petipnur") == "0008") | (col("petipnur") == "0009")),
                    trim(substring(col("peobserv"), 1, 70)),
                ).otherwise(None),
            )
        )

        # Agrupando E-mails
        email_group = (df_endereco.groupBy(col('penumper')).
                       agg(concat_ws(", ", sort_array(collect_list('email'))).alias('email2')))
        df_end_join = email_group.join(df_endereco, on="penumper", how="left")

        df_end_com = df_endereco.groupBy(col('penumper')).agg(
            concat_ws(" | ", sort_array(collect_list('end_com'))).alias('end_com2'),
            concat_ws(" | ", sort_array(collect_list('end_res'))).alias('end_res2'))

        df_end_join = df_end_com.join(df_end_join, on="penumper", how="left")

        # Agrupamento de dados distribuidos em linhas, para lista dentro da campo
        dados_groupby = (
            df_end_join.select("penumper", "end_res2", "end_com2", "email2")
                .groupBy("penumper")
                .agg(
                coalesce(
                    first("end_res2", ignorenulls=True),
                    first("end_res2", ignorenulls=True),
                ).alias("end_res"),
                coalesce(
                    first("end_com2", ignorenulls=True),
                    first("end_com2", ignorenulls=True),
                ).alias("end_com"),
                coalesce(
                    first("email2", ignorenulls=True), first("email2", ignorenulls=True)
                ).alias("email"),
            )
        )

        dados_groupby = (dados_groupby.
        withColumn("end_res", regexp_replace("end_res", "\\s+", " ")).withColumn(
            "end_com", regexp_replace("end_com", "\\s+", " ")))

        result = dados_groupby

        return result.persist(self.storage_level)

    def coletapedt023(self):
        """
        Coleta de informacoes de dados cadastrais na tabela PEDT023
        :return: Dataframe
        """
        df_data_ref = self.collectOdate('b_stbr_pe.pedt023')

        # Load dos dados
        df_pedt023 = (
            self.spark.read.table("b_stbr_pe.pedt023")
            .select("penumper", "peclatel", "pepretel", "peobserv", "petiptel")
            .where(col("dat_ref_carga") == df_data_ref)
            .distinct()
        )

        # Transformacoes
        df_pedt023_aj = (
            df_pedt023.withColumn(
                "nr_tel_res",
                when(
                    (col("peclatel") == "001") & (col("pepretel").isNotNull()),
                    concat(col('pepretel'),substring(col("peobserv"), 21, 10)),
                ).otherwise(""),
            )
            .withColumn(
                "nr_tel_com",
                when(
                    (col("peclatel") == "002") & (col("pepretel").isNotNull()),
                    concat(col('pepretel'),substring(col("peobserv"), 21, 10)),
                ).otherwise(""),
            )
            .withColumn(
                "nr_tel_cel",
                when(
                    (col("petiptel") == "002") & (col("pepretel").isNotNull()),
                    concat(col('pepretel'),substring(col("peobserv"), 21, 10)),
                ).otherwise(""),
            )
        )

        df_pedt023_aj2 = df_pedt023_aj.select(
            "penumper", "nr_tel_res", "nr_tel_com", "nr_tel_cel"
        ).distinct()

        # Agrupamento de dados distribuidos em linhas, para lista dentro da campo
        dados_groupby = df_pedt023_aj2.groupBy("penumper").agg(
            concat_ws(",", sort_array(collect_list("nr_tel_res"))).alias("nr_tel_res"),
            concat_ws(",", sort_array(collect_list("nr_tel_com"))).alias("nr_tel_com"),
            concat_ws(",", sort_array(collect_list("nr_tel_cel"))).alias("nr_tel_cel"),
        )

        df_pedt023_ag_2 = dados_groupby

        # Limpeza dos campos
        result = (
            df_pedt023_ag_2.withColumn(
                "nr_tel_res",
                regexp_replace(
                    regexp_replace(
                        regexp_replace(
                            regexp_replace(
                                regexp_replace(col("nr_tel_res"), "^,", ""), ",,", ","
                            ),
                            ",$",
                            "",
                        ),
                        ",^",
                        "",
                    ),
                    "^[, ]+|[, ]+$",
                    "",
                ),
            )
            .withColumn(
                "nr_tel_com",
                regexp_replace(
                    regexp_replace(
                        regexp_replace(
                            regexp_replace(
                                regexp_replace(col("nr_tel_com"), "^,", ""), ",,", ","
                            ),
                            ",$",
                            "",
                        ),
                        ",^",
                        "",
                    ),
                    "^[, ]+|[, ]+$",
                    "",
                ),
            )
            .withColumn(
                "nr_tel_cel",
                regexp_replace(
                    regexp_replace(
                        regexp_replace(
                            regexp_replace(
                                regexp_replace(col("nr_tel_cel"), "^,", ""), ",,", ","
                            ),
                            ",$",
                            "",
                        ),
                        ",^",
                        "",
                    ),
                    "^[, ]+|[, ]+$",
                    "",
                ),
            )
        )

        return result.persist(self.storage_level)

    def coletapedt036(self):
        """
        Coleta de informacoes de dados cadastrais na tabela PEDT036 - RENDA
        :return: Dataframe
        """
        df_data_ref = self.collectOdate('b_stbr_pe.pedt036')

        # Load dos dados
        df_pedt036 = (
            self.spark.read.table("b_stbr_pe.pedt036")
            .select("penumper", "pefecalt", "peimping")
            .where(col("dat_ref_carga") == df_data_ref)
            .filter((col('petiping') == '099'))
            .distinct()
        )

        # Transformacoes
        df_renda = df_pedt036.groupBy("penumper").agg(
            max("pefecalt").alias("pefecalt"), first("peimping").alias("renda")
        )
        df_renda_aj = df_renda.withColumn("renda", col("renda").cast("string"))

        return df_renda_aj.persist(self.storage_level)

    def coletapedt052(self):
        """
        Coleta de informacoes de dados cadastrais na tabela PEDT052
        :return: Dataframe
        """
        df_data_ref = self.collectOdate('b_stbr_pe.pedt052')

        # Load dos dados
        df_pedt052 = (
            self.spark.read.table("b_stbr_pe.pedt052")
                .select("penumper", "peindica", "pevalind")
                .where((col("dat_ref_carga") == df_data_ref) & (col('pevalind') == "S"))
                .distinct()
        )

        df_filter_colig = df_pedt052.where(
            col("peindica").isin("046", "047", "048")
        )

        # Agrupamento de dados distribuidos em linhas, para lista dentro da campo
        df_for_join_colig = df_filter_colig.groupBy("penumper").agg(
            concat_ws(",", sort_array(collect_list("peindica"))).alias("pep_ind")
        )

        # Transformacoes
        df_pedt052_aj = df_filter_colig.withColumn(
            "pep",
            when(col("peindica") == "046", "POLITICAMENTE EXPOSTA-EM EXERCICIO")
                .when(col("peindica") == "047", "POLITICAMENTE EXPOSTA-PROXIMO OU PARENTE")
                .when(col("peindica") == "048", "POLITICAMENTE EXPOSTA-AFASTADO/INATIVO")
                .otherwise(""),
        ).withColumn(
            "coligada",
            when(
                (col("peindica").isin("980", "998")) & (col("pevalind") == "S"),
                col("peindica"),
            ).otherwise(""),
        )

        # Join entre dataframe df_pedt052_aj e dataframe df_for_join_colig
        df_052_join = df_pedt052_aj.join(df_for_join_colig, on="penumper", how="left")

        # Agrupamento de dados distribuidos em linhas, para lista dentro da campo
        dados_groupby = df_052_join.groupBy("penumper", "pevalind", "pep_ind").agg(
            concat_ws(",", sort_array(collect_list("coligada"))).alias("coligada"),
            concat_ws(",", sort_array(collect_list("pep"))).alias("pep"),
        )

        df_052_join_2 = dados_groupby

        result = df_052_join_2.withColumn(
            "coligada", regexp_replace(regexp_replace("coligada", "^,", ""), ",$", "")
        ).withColumn(
            "pep",
            regexp_replace(
                regexp_replace(regexp_replace(col("pep"), "^,", ""), ",,", ","),
                ",$",
                "",
            ),
        )

        return result.persist(self.storage_level)

    def coletapedt150(self):
        """
        Coleta de informacoes de dados cadastrais na tabela PEDT052
        :return: Dataframe
        """
        df_data_ref = self.collectOdate('b_stbr_pe.pedt150')

        # Load dos dados
        df_pedt150 = (
            self.spark.read.table("b_stbr_pe.pedt150")
            .select(
                "penumper",
                "penumero",
                "pecondoc",
                "petipdoc",
                "peexppor",
                "pefecexp",
                "pelugexp",
            )
            .where(col("dat_ref_carga") == df_data_ref)
            .distinct()
        )

        # Transformacoes
        df_pedt150_outros_docs = df_pedt150.where(
            (
                col("petipdoc").isin(
                    "01", "02", "04", "07", "08", "09", "10", "12", "36", "39", "13"
                )
            )
        ).withColumn(
            "cd_esta_emis",
            when(col("pelugexp") == "01", "AC - ACRE")
            .when(col("pelugexp") == "02", "AL - ALAGOAS")
            .when(col("pelugexp") == "03", "AP - AMAPA")
            .when(col("pelugexp") == "04", "AM - AMAZONAS")
            .when(col("pelugexp") == "05", "BA - BAHIA")
            .when(col("pelugexp") == "06", "CE - CEARA")
            .when(col("pelugexp") == "07", "ES - ESPIRITO SANTO")
            .when(col("pelugexp") == "08", "GO - GOIAS")
            .when(col("pelugexp") == "09", "MA - MARANHAO")
            .when(col("pelugexp") == "10", "MT - MATO GROSSO")
            .when(col("pelugexp") == "11", "MS - MATO GROSSO DO SUL")
            .when(col("pelugexp") == "12", "MG - MINAS GERAIS")
            .when(col("pelugexp") == "13", "PA - PARA")
            .when(col("pelugexp") == "14", "PB - PARAIBA")
            .when(col("pelugexp") == "15", "PR - PARANA")
            .when(col("pelugexp") == "16", "PE - PERNAMBUCO")
            .when(col("pelugexp") == "17", "PI - PIAUI")
            .when(col("pelugexp") == "18", "RJ - RIO DE JANEIRO")
            .when(col("pelugexp") == "19", "RN - RIO GRANDE DO NORTE")
            .when(col("pelugexp") == "20", "RS - RIO GRANDE DO SUL")
            .when(col("pelugexp") == "21", "RO - RONDONIA")
            .when(col("pelugexp") == "22", "RR - RORAIMA")
            .when(col("pelugexp") == "23", "SC - SANTA CATARINA")
            .when(col("pelugexp") == "24", "SP - SAO PAULO")
            .when(col("pelugexp") == "25", "SE - SERGIPE")
            .when(col("pelugexp") == "26", "TO - TOCANTINS")
            .when(col("pelugexp") == "27", "DF - DISTRITO FEDERAL")
            .when(col("pelugexp") == "99", "ZZ - NAO INFORMADA"),
        )

        df_pedt150_outros_docs2 = (
            df_pedt150_outros_docs.withColumnRenamed("petipdoc", "tip_doc")
            .withColumnRenamed("peexppor", "cd_orga_emis")
            .withColumnRenamed("pefecexp", "dt_emis")
        )

        df_pedt150_outros_docs3 = (
            df_pedt150_outros_docs2.withColumn(
                "identidade_rg",
                when(
                    trim(col("tip_doc")) == "01",
                    trim(concat_ws(" ",
                                   trim(col("penumero")),
                                   trim(col("cd_orga_emis")),
                                   trim(col("dt_emis")),
                                   trim(col("cd_esta_emis")),
                                   )),
                ),
            ).withColumn(
                "carteira_profissional",
                when(
                    col("tip_doc") == "02",
                    trim(concat_ws(" ",
                                   trim(col("penumero")),
                                   trim(col("cd_orga_emis")),
                                   trim(col("dt_emis")),
                                   trim(col("cd_esta_emis")),
                                   )),
                ),
            ).withColumn(
                "passaporte",
                when(
                    col("tip_doc") == "04",
                    trim(concat_ws(" ",
                                   trim(col("penumero")),
                                   trim(col("cd_orga_emis")),
                                   trim(col("dt_emis")),
                                   trim(col("cd_esta_emis")),
                                   )),
                ),
            ).withColumn(
                "pis",
                when(
                    col("tip_doc") == "07",
                    trim(concat_ws(" ",
                                   trim(col("penumero")),
                                   trim(col("cd_orga_emis")),
                                   trim(col("dt_emis")),
                                   trim(col("cd_esta_emis")),
                                   )),
                ),
            ).withColumn(
                "titulo_de_eleitor",
                when(
                    col("tip_doc") == "08",
                    trim(concat_ws(" ",
                                   trim(col("penumero")),
                                   trim(col("cd_orga_emis")),
                                   trim(col("dt_emis")),
                                   trim(col("cd_esta_emis")),
                                   )),
                ),
            ).withColumn(
                "identidade_entidades_classe",
                when(
                    col("tip_doc") == "09",
                    trim(concat_ws(" ",
                                   trim(col("penumero")),
                                   trim(col("cd_orga_emis")),
                                   trim(col("dt_emis")),
                                   trim(col("cd_esta_emis")),
                                   )),
                ),
            ).withColumn(
                "rne_registro_nac_estrang",
                when(
                    col("tip_doc") == "10",
                    trim(concat_ws(" ",
                                   trim(col("penumero")),
                                   trim(col("cd_orga_emis")),
                                   trim(col("dt_emis")),
                                   trim(col("cd_esta_emis")),
                                   )),
                ),
            ).withColumn(
                "cnh_cart_nac_habilitacao",
                when(
                    col("tip_doc") == "12",
                    trim(concat_ws(" ",
                                   trim(col("penumero")),
                                   trim(col("cd_orga_emis")),
                                   trim(col("dt_emis")),
                                   trim(col("cd_esta_emis")),
                                   )),
                ),
            ).withColumn(
                "protocolo_do_pedido_refugio",
                when(
                    col("tip_doc") == "36",
                    trim(concat_ws(" ",
                                   trim(col("penumero")),
                                   trim(col("cd_orga_emis")),
                                   trim(col("dt_emis")),
                                   trim(col("cd_esta_emis")),
                                   )),
                ),
            ).withColumn(
                "guia_de_acolhimento",
                when(
                    col("tip_doc") == "39",
                    trim(concat_ws(" ",
                                   trim(col("penumero")),
                                   trim(col("cd_orga_emis")),
                                   trim(col("dt_emis")),
                                   trim(col("cd_esta_emis")),
                                   )),
                ),
            )
        )


        df = df_pedt150_outros_docs3.select(
            "penumper",
            "identidade_rg",
            "carteira_profissional",
            "passaporte",
            "pis",
            "titulo_de_eleitor",
            "identidade_entidades_classe",
            "cnh_cart_nac_habilitacao",
            "protocolo_do_pedido_refugio",
            "guia_de_acolhimento",
            "rne_registro_nac_estrang",
        )

        # Agrupamento de dados distribuidos em linhas, para lista dentro da campo
        dados_groupby = df.groupBy("penumper").agg(
            first("identidade_rg", ignorenulls=True).alias("identidade_rg"),
            first("carteira_profissional", ignorenulls=True).alias(
                "carteira_profissional"
            ),
            first("passaporte", ignorenulls=True).alias("passaporte"),
            first("pis", ignorenulls=True).alias("pis"),
            first("titulo_de_eleitor", ignorenulls=True).alias("titulo_de_eleitor"),
            first("identidade_entidades_classe", ignorenulls=True).alias(
                "identidade_entidades_classe"
            ),
            first("cnh_cart_nac_habilitacao", ignorenulls=True).alias(
                "cnh_cart_nac_habilitacao"
            ),
            first("protocolo_do_pedido_refugio", ignorenulls=True).alias(
                "protocolo_do_pedido_refugio"
            ),
            first("guia_de_acolhimento", ignorenulls=True).alias("guia_de_acolhimento"),
            first("rne_registro_nac_estrang", ignorenulls=True).alias(
                "rne_registro_nac_estrang"
            ),
        )

        df_documentos = dados_groupby

        df_pedt150_cpf = df_pedt150.withColumn(
            "CPF", when(col("petipdoc") == "13", col("penumero"))
        )
        df_pedt150_cpf_aj = df_pedt150_cpf.select("penumper", "cpf").where(
            col("cpf").isNotNull()
        )

        # Join entre dataframe df_documentos e tabela PEDT150
        df_documentos_cpf = df_documentos.join(
            df_pedt150_cpf_aj, on="penumper", how="left"
        )

        return df_documentos_cpf.persist(self.storage_level)

    def bureau_email(self, df_final_pe):
        #coleta de dados de email da tabela do bureau
        df_data_ref = self.collectOdate('s_stbr_dps_dps.dps_bure_pf_email')

        df_bureau_email = (
            self.spark.read.table("s_stbr_dps_dps.dps_bure_pf_email")
            .where((col("dat_ref_carga") == df_data_ref) & (upper("ds_selo_quld") != "RUIM") 
                   & (col("id_pe") != 1))
            .distinct()
        )

        df_bureau_email = df_bureau_email.select(
            col("nr_cpf").alias("cpf"),
            col("ds_email").alias("email")
        ).withColumn("cpf", lpad(col("cpf"), 11, "0"))

        df_bureau_email_aj = df_bureau_email.groupBy("cpf").agg(
            first("email", ignorenulls=True).alias("email_bureau")
        )

        # Joins e ajustes para Bureau
        df_final_pe_email = df_final_pe.join(
            df_bureau_email_aj, on="cpf", how="left"
        )

        df_email_bureau = df_final_pe_email.withColumn(
            "email_aj",
            when(
                col("email").isNull()
                | (col("email") == "")
                | (col("email") == None),  # noqa
                col("email_bureau"),
            ).when(
                col("email") != "",
                concat_ws(", ", col("email"), col("email_bureau")),  # noqa
            ),
        )

        df_email_bureau_aj = df_email_bureau.drop("email", "email_bureau")

        df_email_bureau_aj2 = df_email_bureau_aj.withColumnRenamed("email_aj", "email")

        return df_email_bureau_aj2.persist(self.storage_level)

    def bureau_endereco(self, df):
        #coleta de dados de endereço da tabela do bureau
        df_data_ref = self.collectOdate('s_stbr_dps_dps.dps_bure_pf_ende')

        df_bureau_endereco = (
            self.spark.read.table("s_stbr_dps_dps.dps_bure_pf_ende")
            .where(col("dat_ref_carga") == df_data_ref)
            .distinct()
        )
        df_bureau_endereco_aj = (
            df_bureau_endereco.where((upper("ds_selo_quld") != "RUIM") & (col("id_pe") != 1) 
                                     & (col("tp_doml").isin(1, 2, 3)))
            .withColumn("cpf", lpad(col("nr_cpf"), 11, "0"))
            .withColumn(
                "end_residencial_bureau",
                when(col("tp_doml") == 1,
                    trim(
                        concat(
                            coalesce(trim(col("ds_logr")), lit("")),
                            lit(", "),
                            coalesce(trim(col("nr_resd")), lit("")),
                            lit(" - "),
                            coalesce(trim(col("nm_bair")), lit("")),
                            lit(" - "),
                            coalesce(trim(col("nm_cida").cast("string")), lit("")),
                            lit("-"),
                            coalesce(trim(col("ds_uf")), lit("")),
                            lit(", "),
                            coalesce(trim(col("nr_cep")), lit("")),
                            lit(" "),
                            coalesce(trim(col("ds_comp")), lit(""))
                        )
                    )
                ).otherwise(lit(None))
            )
        )

        df_bureau_endereco_aj = df_bureau_endereco_aj.withColumn(
                "end_comercial_bureau",
                when(col("tp_doml").isin(2, 3),
                    trim(
                        concat(
                            coalesce(trim(col("ds_logr")), lit("")),
                            lit(", "),
                            coalesce(trim(col("nr_resd")), lit("")),
                            lit(" - "),
                            coalesce(trim(col("nm_bair")), lit("")),
                            lit(" "),
                            coalesce(trim(col("nm_cida").cast("string")), lit("")),
                            lit("-"),
                            coalesce(trim(col("ds_uf")), lit("")),
                            lit(", "),
                            coalesce(trim(col("nr_cep")), lit("")),
                            lit(" "),
                            coalesce(trim(col("ds_comp")), lit(""))
                        )
                    )
                ).otherwise(lit(None))
            )

        df_bureau_endereco_aj2 = df_bureau_endereco_aj.select("cpf", "end_residencial_bureau", "end_comercial_bureau")

        df_agroup_end = df_bureau_endereco_aj2.groupby("cpf").agg(
            concat_ws(" | ", sort_array(collect_list("end_residencial_bureau"))).alias("end_res_alternativo"),
            concat_ws(" | ", sort_array(collect_list("end_comercial_bureau"))).alias("end_comercial_alternativo")
        )
        
        df_pe_bureau_end = df.join(df_agroup_end, on="cpf", how="left")

        df_pe_bureau_end2 = df_pe_bureau_end.withColumn(
            "end_res_bureau",
            when(
                col("end_res").isNull()
                | (col("end_res") == "")  # noqa
                | (col("end_res") == None),  # noqa
                col("end_res_alternativo"),
            ).when(
                col("end_res") != "",  # noqa
                concat_ws(" | ", col("end_res"), col("end_res_alternativo")),
            ),
        ).withColumn(
            "end_com_bureau",
            when(
                col("end_com").isNull()
                | (col("end_com") == "")  # noqa
                | (col("end_com") == None),  # noqa
                col("end_comercial_alternativo"),
            ).when(
                col("end_com") != "",  # noqa
                concat_ws(" | ", col("end_com"), col("end_comercial_alternativo")),
            ),
        )

        df_pe_bureau_end_aj = df_pe_bureau_end2.drop("end_res", "end_res_alternativo", "end_com")

        df_pe_bureau_end_aj2 = df_pe_bureau_end_aj.withColumnRenamed(
            "end_res_bureau", "end_res").withColumnRenamed("end_com_bureau","end_com")

        return df_pe_bureau_end_aj2.persist(self.storage_level)

    def bureau_tel(self, df):
        #coleta de dados de telefone das tabelas do bureau
        df_data_ref = self.collectOdate('s_stbr_dps_dps.dps_bure_pf_telf')

        df_bureau_telefone = (
            self.spark.read.table("s_stbr_dps_dps.dps_bure_pf_telf")
            .where((col("dat_ref_carga") == df_data_ref) & (col("id_pe") != 1))
            .distinct()
        )

        df_bureau_telefone_aj = (
            df_bureau_telefone.where(upper("ds_selo_quld") != "RUIM")
            .withColumn("cpf", lpad(col("nr_cpf"), 11, "0"))
            .withColumn(
                "nr_tel_cel_bureau",
                when(
                    col("id_celu") == "1",
                    concat(lit("55 "), col("nr_ddd"), lit(" "), col("nr_telf")),
                ).otherwise(None),
            )
            .withColumn(
                "nr_tel_alternativo",
                when(
                    col("id_celu") != "1",
                    concat(lit("55 "), col("nr_ddd"), lit(" "), col("nr_telf")),
                ).otherwise(None),
            )
        )

        df_bureau_telefone_aj2 = df_bureau_telefone_aj.select(
            "cpf", "nr_tel_cel_bureau", "nr_tel_alternativo"
        )

        df_telefones_group = df_bureau_telefone_aj2.groupby("cpf").agg(
            concat_ws(" | ", sort_array(collect_list("nr_tel_cel_bureau"))).alias('nr_tel_cel_bureau'),
            concat_ws(" | ", sort_array(collect_list("nr_tel_alternativo"))).alias('nr_tel_alternativo')  # noqa
        )

        df_pe_bureau_telefones = df.join(
            df_telefones_group, on="cpf", how="left"
        )

        df_telefones = df_pe_bureau_telefones.withColumn(
            "nr_tel_cel_pe_bureau",
            when(
                col("nr_tel_cel").isNull()
                | (col("nr_tel_cel") == "")
                | (col("nr_tel_cel") == None),  # noqa
                col("nr_tel_cel_bureau"),
            ).when(
                col("nr_tel_cel") != "",
                concat_ws(", ", col("nr_tel_cel"), col("nr_tel_cel_bureau")),
            ),
        ).withColumn(
            "nr_tel_res_pe_bureau",
            when(
                col("nr_tel_res").isNull()
                | (col("nr_tel_res") == "")  # noqa
                | (col("nr_tel_cel") == None),  # noqa
                col("nr_tel_alternativo"),
            ).when(
                col("nr_tel_res") != "",
                concat_ws(", ", col("nr_tel_res"), col("nr_tel_alternativo")),
            ),
        )

        df_telefones_aj = df_telefones.drop("nr_tel_cel", "nr_tel_res")

        df_telefones_aj2 = df_telefones_aj.withColumnRenamed(
            "nr_tel_cel_pe_bureau", "nr_tel_cel"
        ).withColumnRenamed("nr_tel_res_pe_bureau", "nr_tel_res")

        df_telefones_aj2 = df_telefones_aj2.drop('nr_tel_cel_bureau', 'nr_tel_alternativo')

        return df_telefones_aj2.persist(self.storage_level)

    def df_joins(self):
        df_pedt001_aj = self.coletapedt001()
        df_pedt205_aj2 = self.coletapedt205()
        df_pedt002_aj = self.coletapedt002()
        df_endereco_aj = self.coletapedt003()
        df_pedt023_ag_2 = self.coletapedt023()
        df_renda_aj = self.coletapedt036()
        df_052_join_2 = self.coletapedt052()
        df_documentos_cpf = self.coletapedt150()

        self.logger.info("Realizando join entre pedt001 e 205")
        df_pedt205_aj2_rp = df_pedt205_aj2
        df_pedt001_aj_rp = df_pedt001_aj
        df_ped_01_205 = df_pedt001_aj_rp.join(
            df_pedt205_aj2_rp, on="penumper", how="left"
        )
        df_pedt001_aj.unpersist()
        df_pedt205_aj2.unpersist()

        self.logger.info("Realizando join entre dataframe df_ped_01_205 e pedt002")
        df_ped_01_205_rp = df_ped_01_205
        df_pedt002_aj_rp = df_pedt002_aj
        df_pedt_01_02 = df_ped_01_205_rp.join(
            df_pedt002_aj_rp, on="penumper", how="left"
        )
        df_pedt002_aj.unpersist()

        self.logger.info(
            "Realizando join entre dataframe df_pedt_01_02 com dataframe de enderecos"
        )
        df_pedt_01_02_rp = df_pedt_01_02
        df_endereco_aj_rp = df_endereco_aj
        df_pedt_01_02_endereco = df_pedt_01_02_rp.join(
            df_endereco_aj_rp, on="penumper", how="left"
        )
        df_endereco_aj.unpersist()

        self.logger.info(
            "Realizando join entre dataframe df_pedt_01_02_endereco com pedt023"
        )
        df_pedt_01_02_endereco_rp = df_pedt_01_02_endereco
        df_pedt023_ag_2_rp = df_pedt023_ag_2
        df_pedt_01_02_endereco_03 = df_pedt_01_02_endereco_rp.join(
            df_pedt023_ag_2_rp, on="penumper", how="left"
        )
        df_pedt023_ag_2.unpersist()

        self.logger.info(
            "Realizando join entre dataframe df_pedt_01_02_endereco_03 com dataframe de renda"
        )
        df_pedt_01_02_endereco_03_rp = df_pedt_01_02_endereco_03
        df_renda_aj_rp = df_renda_aj
        df_pedt_01_02_endereco_03_04 = df_pedt_01_02_endereco_03_rp.join(
            df_renda_aj_rp, on="penumper", how="left"
        )
        df_renda_aj.unpersist()

        self.logger.info(
            "Realizando join entre dataframe df_pedt_01_02_endereco_03_04 com pedt052"
        )
        df_pedt_01_02_endereco_03_04_rp = df_pedt_01_02_endereco_03_04
        df_052_join_2_rp = df_052_join_2
        df_pedt_01_02_endereco_03_04_52 = df_pedt_01_02_endereco_03_04_rp.join(
            df_052_join_2_rp, on="penumper", how="left"
        )
        df_052_join_2.unpersist()

        self.logger.info(
            "Realizando join entre dataframe df_pedt_01_02_endereco_03_04_52 com dataframe de documentos"
        )
        df_pedt_01_02_endereco_03_04_52_rp = (
            df_pedt_01_02_endereco_03_04_52
        )
        df_documentos_cpf_rp = df_documentos_cpf
        df_final_pe = df_pedt_01_02_endereco_03_04_52_rp.join(
            df_documentos_cpf_rp, on="penumper", how="left"
        )
        df_documentos_cpf.unpersist()

        self.logger.info("Realizando join entre dataframe df_final_pe e bureau_email")
        df_pe_bureau_email = self.bureau_email(df_final_pe)

        self.logger.info(
            "Realizando join entre dataframe df_pe_bureau_email e bureau_endereco"
        )
        df_pe_bureau_endereco = self.bureau_endereco(df_pe_bureau_email)
        df_pe_bureau_email.unpersist()

        self.logger.info(
            "Realizando join entre dataframe df_pe_bureau_endereco e bureau_tel"
        )
        df_pe_bureau_tel = self.bureau_tel(df_pe_bureau_endereco)
        df_pe_bureau_endereco.unpersist()


        self.logger.info("Implementação de novas colunas")

        # Criacao de colunas que nao ficaram definidas a origem dos dados
        df_final = (
            df_pe_bureau_tel.withColumn("imei_celular", lit(""))
            .withColumn("penumper_hash", sha2(col("penumper"), 256))
            .withColumn("origem_racial", lit(""))
            .withColumn("geolocalizacao", lit(""))
            .withColumn("foto", lit(""))
            .withColumn("biometria", lit(""))
            .withColumn("dat_ref_carga", lit(str(date.today())))
            .withColumn(
                        "identity_hash",
                        md5(
                            concat_ws(
                                '',
                                col("penumper"), col("cpf"), col("nome"), col("sobrenome"),
                                col("nm_copt"), col("pefecnac"), col("identidade_rg"),
                                col("cnh_cart_nac_habilitacao"), col("carteira_profissional"),
                                col("protocolo_do_pedido_refugio"), col("passaporte"),
                                col("guia_de_acolhimento"), col("idade"), col("penacper"),
                                col("email"), col("natural"), col("penommad"), col("penompad"),
                                col("end_res"), col("end_com"), col("peestciv"), col("pesexper"),
                                col("nr_tel_res"), col("nr_tel_com"), col("nr_tel_cel"),
                                col("petipocu"), col("renda"), col("tp_bem"), col("pep"),
                                col("titulo_de_eleitor"), col("identidade_entidades_classe"),
                                col("pis"), col("rne_registro_nac_estrang"), col("imei_celular"),
                                col("origem_racial"), col("geolocalizacao"), col("foto"),
                                col("biometria")
                            )
                        )
                    )
        )

        df_pe_bureau_tel.unpersist()

        # Selecao dos dados para insert
        self.logger.info("Seleção de campos para inclusão dos dados")
        df_final_columns = df_final.select(
            "penumper",
            "cpf",
            "nome",
            "sobrenome",
            "nm_copt",
            "pefecnac",
            "identidade_rg",
            "cnh_cart_nac_habilitacao",
            "carteira_profissional",
            "protocolo_do_pedido_refugio",
            "passaporte",
            "guia_de_acolhimento",
            "idade",
            "penacper",
            "email",
            "natural",
            "penommad",
            "penompad",
            "end_res",
            "end_com",
            "peestciv",
            "pesexper",
            "nr_tel_res",
            "nr_tel_com",
            "nr_tel_cel",
            "petipocu",
            "renda",
            "tp_bem",
            "pep",
            "titulo_de_eleitor",
            "identidade_entidades_classe",
            "pis",
            "rne_registro_nac_estrang",
            "imei_celular",
            "origem_racial",
            "geolocalizacao",
            "foto",
            "biometria",
            "dat_ref_carga",
            "penumper_hash",
            "identity_hash"
        ).dropDuplicates(["penumper", "cpf", "nome"])

        # self.logger.info("------------------")
        # self.logger.info(f"Registros vindos do ETL {df_final_columns.count()}")
        # self.logger.info("------------------")

        df_final_columns.repartition(64)
        return df_final_columns.persist(self.storage_level)