"""
Configurações específicas para execução no Databricks Azure
Otimizado para processar 1TB de dados com Spark 3 sem Photon
"""

from pyspark.sql import SparkSession
from pyspark.conf import SparkConf
import logging


class DatabricksConfig:
    """Configurações otimizadas para Databricks Azure"""
    
    @staticmethod
    def get_optimized_spark_config():
        """Retorna configurações otimizadas do Spark para 1TB"""
        
        config = SparkConf()
        
        # Configurações básicas
        config.set("spark.app.name", "DadosCadastrais_Otimizado_1TB")
        config.set("spark.sql.adaptive.enabled", "true")
        config.set("spark.sql.adaptive.coalescePartitions.enabled", "true")
        config.set("spark.sql.adaptive.skewJoin.enabled", "true")
        config.set("spark.sql.adaptive.localShuffleReader.enabled", "true")
        
        # Configurações para 1TB
        config.set("spark.sql.adaptive.advisoryPartitionSizeInBytes", "256MB")
        config.set("spark.sql.adaptive.coalescePartitions.minPartitionNum", "200")
        config.set("spark.sql.adaptive.coalescePartitions.maxPartitionNum", "1000")
        config.set("spark.sql.adaptive.skewJoin.skewedPartitionThresholdInBytes", "512MB")
        config.set("spark.sql.adaptive.skewJoin.skewedPartitionFactor", "5")
        
        # Configurações de memória
        config.set("spark.sql.execution.arrow.pyspark.enabled", "true")
        config.set("spark.sql.execution.arrow.maxRecordsPerBatch", "20000")
        config.set("spark.sql.execution.arrow.pyspark.fallback.enabled", "true")
        
        # Broadcast
        config.set("spark.sql.autoBroadcastJoinThreshold", "200MB")
        config.set("spark.sql.broadcastTimeout", "36000")  # 10 minutos
        
        # Serialização
        config.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
        config.set("spark.kryo.unsafe", "true")
        config.set("spark.kryoserializer.buffer.max", "1024m")
        
        # Delta Lake
        config.set("spark.databricks.delta.optimizeWrite.enabled", "true")
        config.set("spark.databricks.delta.autoCompact.enabled", "true")
        config.set("spark.databricks.delta.retentionDurationCheck.enabled", "false")
        
        # Configurações de rede
        config.set("spark.network.timeout", "800s")
        config.set("spark.sql.broadcastTimeout", "36000")
        
        # Configurações de shuffle
        config.set("spark.sql.shuffle.partitions", "400")
        config.set("spark.sql.adaptive.shuffle.targetPostShuffleInputSize", "256MB")
        
        # Configurações de cache
        config.set("spark.sql.adaptive.localShuffleReader.enabled", "true")
        config.set("spark.sql.adaptive.skewJoin.enabled", "true")
        
        return config
    
    @staticmethod
    def create_optimized_spark_session():
        """Cria SparkSession otimizada para Databricks"""
        
        config = DatabricksConfig.get_optimized_spark_config()
        
        spark = SparkSession.builder \
            .config(conf=config) \
            .getOrCreate()
        
        # Configurações adicionais via SQL
        additional_configs = {
            "spark.sql.adaptive.enabled": "true",
            "spark.sql.adaptive.coalescePartitions.enabled": "true",
            "spark.sql.adaptive.skewJoin.enabled": "true",
            "spark.sql.adaptive.localShuffleReader.enabled": "true",
            "spark.sql.adaptive.advisoryPartitionSizeInBytes": "256MB",
            "spark.sql.adaptive.coalescePartitions.minPartitionNum": "200",
            "spark.sql.adaptive.skewJoin.skewedPartitionThresholdInBytes": "512MB",
            "spark.sql.execution.arrow.pyspark.enabled": "true",
            "spark.sql.autoBroadcastJoinThreshold": "200MB",
            "spark.databricks.delta.optimizeWrite.enabled": "true",
            "spark.databricks.delta.autoCompact.enabled": "true"
        }
        
        for key, value in additional_configs.items():
            spark.conf.set(key, value)
        
        return spark
    
    @staticmethod
    def setup_logging():
        """Configura logging otimizado"""
        
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.StreamHandler(),
                logging.FileHandler('/tmp/dados_cadastrais_otimizado.log')
            ]
        )
        
        # Reduzir verbosidade de logs do Spark
        spark_logger = logging.getLogger('pyspark')
        spark_logger.setLevel(logging.WARN)
        
        py4j_logger = logging.getLogger('py4j')
        py4j_logger.setLevel(logging.WARN)
        
        return logging.getLogger(__name__)


class ClusterRecommendations:
    """Recomendações de configuração de cluster para diferentes volumes"""
    
    @staticmethod
    def get_cluster_config_for_1tb():
        """Configuração recomendada para 1TB"""
        return {
            "cluster_name": "dados-cadastrais-1tb-optimized",
            "spark_version": "11.3.x-scala2.12",
            "node_type_id": "Standard_D16s_v3",
            "driver_node_type_id": "Standard_D16s_v3",
            "num_workers": 25,
            "autoscale": {
                "min_workers": 20,
                "max_workers": 30
            },
            "spark_conf": {
                "spark.sql.adaptive.enabled": "true",
                "spark.sql.adaptive.coalescePartitions.enabled": "true",
                "spark.sql.adaptive.skewJoin.enabled": "true",
                "spark.sql.adaptive.advisoryPartitionSizeInBytes": "256MB",
                "spark.sql.adaptive.coalescePartitions.minPartitionNum": "200",
                "spark.sql.autoBroadcastJoinThreshold": "200MB",
                "spark.databricks.delta.optimizeWrite.enabled": "true",
                "spark.databricks.delta.autoCompact.enabled": "true"
            },
            "azure_attributes": {
                "availability": "ON_DEMAND_AZURE",
                "first_on_demand": 1,
                "spot_bid_max_price": -1
            },
            "enable_elastic_disk": True,
            "disk_spec": {
                "disk_type": {
                    "azure_disk_volume_type": "PREMIUM_LRS"
                },
                "disk_size": 128
            }
        }
    
    @staticmethod
    def get_cluster_config_for_500gb():
        """Configuração recomendada para 500GB"""
        return {
            "cluster_name": "dados-cadastrais-500gb-optimized",
            "spark_version": "11.3.x-scala2.12",
            "node_type_id": "Standard_D8s_v3",
            "driver_node_type_id": "Standard_D8s_v3",
            "num_workers": 15,
            "autoscale": {
                "min_workers": 10,
                "max_workers": 20
            },
            "spark_conf": {
                "spark.sql.adaptive.enabled": "true",
                "spark.sql.adaptive.coalescePartitions.enabled": "true",
                "spark.sql.adaptive.advisoryPartitionSizeInBytes": "128MB",
                "spark.sql.adaptive.coalescePartitions.minPartitionNum": "100",
                "spark.sql.autoBroadcastJoinThreshold": "100MB"
            }
        }


class PerformanceMonitoring:
    """Monitoramento de performance específico para Databricks"""
    
    def __init__(self, spark):
        self.spark = spark
        self.metrics = {}
    
    def log_cluster_metrics(self):
        """Log das métricas do cluster"""
        try:
            # Informações do cluster
            sc = self.spark.sparkContext
            
            print(f"Spark Version: {sc.version}")
            print(f"Master: {sc.master}")
            print(f"App Name: {sc.appName}")
            print(f"Default Parallelism: {sc.defaultParallelism}")
            
            # Configurações importantes
            important_configs = [
                "spark.sql.adaptive.enabled",
                "spark.sql.adaptive.coalescePartitions.enabled",
                "spark.sql.adaptive.skewJoin.enabled",
                "spark.sql.adaptive.advisoryPartitionSizeInBytes",
                "spark.sql.autoBroadcastJoinThreshold"
            ]
            
            print("\nConfigurações Importantes:")
            for config in important_configs:
                value = self.spark.conf.get(config, "Not Set")
                print(f"{config}: {value}")
                
        except Exception as e:
            print(f"Erro ao obter métricas do cluster: {e}")
    
    def monitor_job_progress(self, job_description="Job"):
        """Monitor de progresso do job"""
        try:
            sc = self.spark.sparkContext
            status = sc.statusTracker()
            
            print(f"\n=== {job_description} Status ===")
            print(f"Active Jobs: {len(status.getActiveJobIds())}")
            print(f"Active Stages: {len(status.getActiveStageIds())}")
            
            # Informações dos executors
            executor_infos = status.getExecutorInfos()
            total_cores = sum(info.totalCores for info in executor_infos)
            total_memory = sum(info.maxMemory for info in executor_infos)
            
            print(f"Total Executors: {len(executor_infos)}")
            print(f"Total Cores: {total_cores}")
            print(f"Total Memory: {total_memory / (1024**3):.2f} GB")
            
        except Exception as e:
            print(f"Erro ao monitorar progresso: {e}")


# Exemplo de uso
if __name__ == "__main__":
    # Configurar logging
    logger = DatabricksConfig.setup_logging()
    
    # Criar SparkSession otimizada
    spark = DatabricksConfig.create_optimized_spark_session()
    
    # Monitoramento
    monitor = PerformanceMonitoring(spark)
    monitor.log_cluster_metrics()
    
    # Exemplo de uso da classe otimizada
    from dados_cadastrais_otimizado import DadosCadastraisOtimizado
    
    try:
        # Instanciar classe otimizada
        dados_cadastrais = DadosCadastraisOtimizado(spark, logger)
        
        # Executar pipeline
        df_resultado = dados_cadastrais.execute_optimized_pipeline()
        
        # Monitorar progresso
        monitor.monitor_job_progress("Pipeline Dados Cadastrais")
        
        # Salvar resultado
        df_resultado.write \
            .mode("overwrite") \
            .option("overwriteSchema", "true") \
            .saveAsTable("dados_cadastrais_otimizado_final")
        
        logger.info("Pipeline executado com sucesso!")
        
    except Exception as e:
        logger.error(f"Erro na execução do pipeline: {e}")
        raise
    
    finally:
        # Limpar recursos
        dados_cadastrais.cleanup_resources()
        spark.stop()

