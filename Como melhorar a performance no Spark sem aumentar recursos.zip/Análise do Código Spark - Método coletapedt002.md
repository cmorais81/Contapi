# Análise do Código Spark - Método coletapedt002

## Código Analisado

Baseado nas imagens fornecidas, o método `coletapedt002(self)` realiza as seguintes operações:

### 1. Carregamento dos Dados
```python
df_data_ref = self.collectdata('b_stbr_pe.pedt002')

df_pedt002 = (
    self.spark.read.table("b_stbr_pe.pedt002")
    .select("penumper", "pesestrat", "penommad", "penompad")
    .where(col("dat_ref_carga") == df_data_ref)
    .distinct()
)
```

### 2. Transformação Complexa de Estados
```python
df_pedt002_aj = df_pedt002.withColumn(
    "natural",
    when(col("pesestrat") == "01", "AC - ACRE")
    .when(col("pesestrat") == "02", "AL - ALAGOAS")
    .when(col("pesestrat") == "03", "AP - AMAPA")
    .when(col("pesestrat") == "04", "AM - AMAZONAS")
    .when(col("pesestrat") == "05", "BA - BAHIA")
    .when(col("pesestrat") == "06", "CE - CEARA")
    .when(col("pesestrat") == "07", "ES - ESPIRITO SANTO")
    .when(col("pesestrat") == "08", "GO - GOIAS")
    .when(col("pesestrat") == "09", "MA - MARANHAO")
    .when(col("pesestrat") == "10", "MT - MATO GROSSO")
    .when(col("pesestrat") == "11", "MS - MATO GROSSO DO SUL")
    .when(col("pesestrat") == "12", "MG - MINAS GERAIS")
    .when(col("pesestrat") == "13", "PA - PARA")
    .when(col("pesestrat") == "14", "PB - PARAIBA")
    .when(col("pesestrat") == "15", "PR - PARANA")
    .when(col("pesestrat") == "16", "PE - PERNAMBUCO")
    .when(col("pesestrat") == "17", "PI - PIAUI")
    .when(col("pesestrat") == "18", "RJ - RIO DE JANEIRO")
    .when(col("pesestrat") == "19", "RN - RIO GRANDE DO NORTE")
    .when(col("pesestrat") == "20", "RS - RIO GRANDE DO SUL")
    .when(col("pesestrat") == "21", "RO - RONDONIA")
    .when(col("pesestrat") == "22", "RR - RORAIMA")
    .when(col("pesestrat") == "23", "SC - SANTA CATARINA")
    .when(col("pesestrat") == "24", "SP - SAO PAULO")
    .when(col("pesestrat") == "25", "SE - SERGIPE")
    .when(col("pesestrat") == "26", "TO - TOCANTINS")
    .when(col("pesestrat") == "27", "DF - DISTRITO FEDERAL")
    .when(col("pesestrat") == "99", "ZZ - NAO INFORMADA")
    .otherwise("")
)

return df_pedt002_aj.persist(self.storage_level)
```

## Problemas de Performance Identificados

### 1. **Transformação withColumn() com Muitas Condições**
- Uma única transformação `withColumn()` com 28 condições `when/otherwise`
- Cada condição é avaliada sequencialmente, causando overhead
- Operação custosa que pode ser otimizada com lookup tables ou expressões SQL

### 2. **Operação distinct() Prematura**
- `distinct()` aplicado logo após select, antes das transformações
- Pode não ser necessário dependendo da qualidade dos dados
- Operação custosa que requer shuffle completo

### 3. **Falta de Otimizações de Lookup**
- Mapeamento de códigos para estados feito com condições sequenciais
- Não utiliza estruturas otimizadas como broadcast maps ou lookup tables
- Cada registro precisa passar por todas as condições até encontrar a correta

### 4. **Ausência de Cache Estratégico**
- DataFrame base não é cacheado antes das transformações
- Pode ser recomputado se usado em outras operações

### 5. **Falta de Validação de Dados**
- Não há validação se todos os códigos de estado são válidos
- Códigos inválidos resultam em string vazia sem log ou tratamento

### 6. **Operações de String Repetitivas**
- Múltiplas comparações de string com códigos
- Não aproveita otimizações de índices ou hash maps

## Características Específicas do Método

### Volume de Dados Esperado
- Tabela de dados cadastrais (PEDT002) provavelmente grande
- Transformação aplicada a todos os registros
- Mapeamento 1:1 de códigos para descrições

### Padrão de Acesso
- Leitura sequencial de todos os registros
- Transformação determinística (mesmo input sempre produz mesmo output)
- Resultado provavelmente usado em joins ou análises posteriores

### Complexidade da Transformação
- 28 estados brasileiros + 1 código especial (99)
- Mapeamento estático que não muda frequentemente
- Transformação que pode ser pré-computada ou otimizada


## Sugestões de Otimização para Performance

### 1. **Otimização com Broadcast Map para Lookup de Estados**

**Problema**: 28 condições `when/otherwise` sequenciais para mapear códigos de estados.

**Solução**: Usar broadcast map para lookup instantâneo:

```python
def coletapedt002_broadcast_otimizado(self):
    """
    Versão otimizada usando broadcast map para lookup de estados
    """
    df_data_ref = self.collectdata('b_stbr_pe.pedt002')
    
    # Criar mapa de estados para broadcast
    estados_map = {
        "01": "AC - ACRE",
        "02": "AL - ALAGOAS", 
        "03": "AP - AMAPA",
        "04": "AM - AMAZONAS",
        "05": "BA - BAHIA",
        "06": "CE - CEARA",
        "07": "ES - ESPIRITO SANTO",
        "08": "GO - GOIAS",
        "09": "MA - MARANHAO",
        "10": "MT - MATO GROSSO",
        "11": "MS - MATO GROSSO DO SUL",
        "12": "MG - MINAS GERAIS",
        "13": "PA - PARA",
        "14": "PB - PARAIBA",
        "15": "PR - PARANA",
        "16": "PE - PERNAMBUCO",
        "17": "PI - PIAUI",
        "18": "RJ - RIO DE JANEIRO",
        "19": "RN - RIO GRANDE DO NORTE",
        "20": "RS - RIO GRANDE DO SUL",
        "21": "RO - RONDONIA",
        "22": "RR - RORAIMA",
        "23": "SC - SANTA CATARINA",
        "24": "SP - SAO PAULO",
        "25": "SE - SERGIPE",
        "26": "TO - TOCANTINS",
        "27": "DF - DISTRITO FEDERAL",
        "99": "ZZ - NAO INFORMADA"
    }
    
    # Broadcast do mapa
    broadcast_estados = self.spark.sparkContext.broadcast(estados_map)
    
    # UDF para lookup otimizado
    def lookup_estado(codigo):
        return broadcast_estados.value.get(codigo, "")
    
    lookup_estado_udf = udf(lookup_estado, StringType())
    
    resultado = (
        self.spark.read.table("b_stbr_pe.pedt002")
        .where(col("dat_ref_carga") == df_data_ref)
        .select(
            col("penumper"),
            col("pesestrat"), 
            col("penommad"),
            col("penompad"),
            lookup_estado_udf(col("pesestrat")).alias("natural")
        )
        .distinct()
        .persist(self.storage_level)
    )
    
    return resultado
```

**Benefícios**:
- Lookup O(1) ao invés de O(n) sequencial
- Reduz drasticamente o tempo de processamento
- Mapa é distribuído uma vez para todos os executors

### 2. **Otimização com DataFrame de Lookup e Join**

**Problema**: UDF pode ser custosa para grandes volumes.

**Solução**: Usar DataFrame de lookup com join otimizado:

```python
def coletapedt002_join_otimizado(self):
    """
    Versão usando DataFrame de lookup com join para máxima performance
    """
    df_data_ref = self.collectdata('b_stbr_pe.pedt002')
    
    # Criar DataFrame de lookup de estados
    estados_data = [
        ("01", "AC - ACRE"),
        ("02", "AL - ALAGOAS"),
        ("03", "AP - AMAPA"),
        ("04", "AM - AMAZONAS"),
        ("05", "BA - BAHIA"),
        ("06", "CE - CEARA"),
        ("07", "ES - ESPIRITO SANTO"),
        ("08", "GO - GOIAS"),
        ("09", "MA - MARANHAO"),
        ("10", "MT - MATO GROSSO"),
        ("11", "MS - MATO GROSSO DO SUL"),
        ("12", "MG - MINAS GERAIS"),
        ("13", "PA - PARA"),
        ("14", "PB - PARAIBA"),
        ("15", "PR - PARANA"),
        ("16", "PE - PERNAMBUCO"),
        ("17", "PI - PIAUI"),
        ("18", "RJ - RIO DE JANEIRO"),
        ("19", "RN - RIO GRANDE DO NORTE"),
        ("20", "RS - RIO GRANDE DO SUL"),
        ("21", "RO - RONDONIA"),
        ("22", "RR - RORAIMA"),
        ("23", "SC - SANTA CATARINA"),
        ("24", "SP - SAO PAULO"),
        ("25", "SE - SERGIPE"),
        ("26", "TO - TOCANTINS"),
        ("27", "DF - DISTRITO FEDERAL"),
        ("99", "ZZ - NAO INFORMADA")
    ]
    
    df_estados = self.spark.createDataFrame(
        estados_data, 
        ["codigo_estado", "nome_estado"]
    )
    
    # Join otimizado com broadcast
    resultado = (
        self.spark.read.table("b_stbr_pe.pedt002")
        .where(col("dat_ref_carga") == df_data_ref)
        .select("penumper", "pesestrat", "penommad", "penompad")
        .distinct()
        .join(
            broadcast(df_estados),
            col("pesestrat") == col("codigo_estado"),
            "left"
        )
        .select(
            col("penumper"),
            col("pesestrat"),
            col("penommad"), 
            col("penompad"),
            coalesce(col("nome_estado"), lit("")).alias("natural")
        )
        .persist(self.storage_level)
    )
    
    return resultado
```

**Benefícios**:
- Join é otimizado nativamente pelo Spark
- Broadcast elimina shuffle
- Melhor performance que UDF para grandes volumes
- Suporte nativo a valores nulos/ausentes

### 3. **Otimização com Expressão SQL CASE Otimizada**

**Problema**: Múltiplas condições when/otherwise podem ser lentas.

**Solução**: Usar expressão SQL CASE nativa:

```python
def coletapedt002_sql_case_otimizado(self):
    """
    Versão usando expressão SQL CASE nativa para máxima performance
    """
    df_data_ref = self.collectdata('b_stbr_pe.pedt002')
    
    resultado = (
        self.spark.read.table("b_stbr_pe.pedt002")
        .where(col("dat_ref_carga") == df_data_ref)
        .select(
            col("penumper"),
            col("pesestrat"),
            col("penommad"),
            col("penompad"),
            expr("""
                CASE pesestrat
                    WHEN '01' THEN 'AC - ACRE'
                    WHEN '02' THEN 'AL - ALAGOAS'
                    WHEN '03' THEN 'AP - AMAPA'
                    WHEN '04' THEN 'AM - AMAZONAS'
                    WHEN '05' THEN 'BA - BAHIA'
                    WHEN '06' THEN 'CE - CEARA'
                    WHEN '07' THEN 'ES - ESPIRITO SANTO'
                    WHEN '08' THEN 'GO - GOIAS'
                    WHEN '09' THEN 'MA - MARANHAO'
                    WHEN '10' THEN 'MT - MATO GROSSO'
                    WHEN '11' THEN 'MS - MATO GROSSO DO SUL'
                    WHEN '12' THEN 'MG - MINAS GERAIS'
                    WHEN '13' THEN 'PA - PARA'
                    WHEN '14' THEN 'PB - PARAIBA'
                    WHEN '15' THEN 'PR - PARANA'
                    WHEN '16' THEN 'PE - PERNAMBUCO'
                    WHEN '17' THEN 'PI - PIAUI'
                    WHEN '18' THEN 'RJ - RIO DE JANEIRO'
                    WHEN '19' THEN 'RN - RIO GRANDE DO NORTE'
                    WHEN '20' THEN 'RS - RIO GRANDE DO SUL'
                    WHEN '21' THEN 'RO - RONDONIA'
                    WHEN '22' THEN 'RR - RORAIMA'
                    WHEN '23' THEN 'SC - SANTA CATARINA'
                    WHEN '24' THEN 'SP - SAO PAULO'
                    WHEN '25' THEN 'SE - SERGIPE'
                    WHEN '26' THEN 'TO - TOCANTINS'
                    WHEN '27' THEN 'DF - DISTRITO FEDERAL'
                    WHEN '99' THEN 'ZZ - NAO INFORMADA'
                    ELSE ''
                END
            """).alias("natural")
        )
        .distinct()
        .persist(self.storage_level)
    )
    
    return resultado
```

**Benefícios**:
- Expressão SQL nativa é otimizada pelo Catalyst
- Melhor performance que when/otherwise do PySpark
- Suporte a code generation

### 4. **Otimização com Cache e Validação de Dados**

**Problema**: Falta de validação e cache estratégico.

**Solução**: Implementar validação e cache otimizado:

```python
def coletapedt002_com_validacao(self):
    """
    Versão com validação de dados e cache estratégico
    """
    df_data_ref = self.collectdata('b_stbr_pe.pedt002')
    
    # Cache do DataFrame base
    df_base = (
        self.spark.read.table("b_stbr_pe.pedt002")
        .where(col("dat_ref_carga") == df_data_ref)
        .select("penumper", "pesestrat", "penommad", "penompad")
        .cache()
    )
    
    # Força materialização do cache
    total_records = df_base.count()
    print(f"Total de registros processados: {total_records}")
    
    # Validação de códigos de estado
    codigos_validos = [f"{i:02d}" for i in range(1, 28)] + ["99"]
    codigos_invalidos = (
        df_base
        .select("pesestrat")
        .distinct()
        .filter(~col("pesestrat").isin(codigos_validos))
        .collect()
    )
    
    if codigos_invalidos:
        print(f"Warning: Códigos de estado inválidos encontrados: {[row.pesestrat for row in codigos_invalidos]}")
    
    # Transformação otimizada
    resultado = (
        df_base
        .select(
            col("penumper"),
            col("pesestrat"),
            col("penommad"),
            col("penompad"),
            expr("""
                CASE pesestrat
                    WHEN '01' THEN 'AC - ACRE'
                    WHEN '02' THEN 'AL - ALAGOAS'
                    WHEN '03' THEN 'AP - AMAPA'
                    WHEN '04' THEN 'AM - AMAZONAS'
                    WHEN '05' THEN 'BA - BAHIA'
                    WHEN '06' THEN 'CE - CEARA'
                    WHEN '07' THEN 'ES - ESPIRITO SANTO'
                    WHEN '08' THEN 'GO - GOIAS'
                    WHEN '09' THEN 'MA - MARANHAO'
                    WHEN '10' THEN 'MT - MATO GROSSO'
                    WHEN '11' THEN 'MS - MATO GROSSO DO SUL'
                    WHEN '12' THEN 'MG - MINAS GERAIS'
                    WHEN '13' THEN 'PA - PARA'
                    WHEN '14' THEN 'PB - PARAIBA'
                    WHEN '15' THEN 'PR - PARANA'
                    WHEN '16' THEN 'PE - PERNAMBUCO'
                    WHEN '17' THEN 'PI - PIAUI'
                    WHEN '18' THEN 'RJ - RIO DE JANEIRO'
                    WHEN '19' THEN 'RN - RIO GRANDE DO NORTE'
                    WHEN '20' THEN 'RS - RIO GRANDE DO SUL'
                    WHEN '21' THEN 'RO - RONDONIA'
                    WHEN '22' THEN 'RR - RORAIMA'
                    WHEN '23' THEN 'SC - SANTA CATARINA'
                    WHEN '24' THEN 'SP - SAO PAULO'
                    WHEN '25' THEN 'SE - SERGIPE'
                    WHEN '26' THEN 'TO - TOCANTINS'
                    WHEN '27' THEN 'DF - DISTRITO FEDERAL'
                    WHEN '99' THEN 'ZZ - NAO INFORMADA'
                    ELSE 'CODIGO INVALIDO'
                END
            """).alias("natural")
        )
        .distinct()
        .persist(self.storage_level)
    )
    
    return resultado
```

### 5. **Otimização com Tabela de Lookup Persistente**

**Problema**: Recriação do mapeamento a cada execução.

**Solução**: Criar tabela de lookup persistente:

```python
def criar_tabela_estados_lookup(self):
    """
    Criar tabela de lookup de estados uma única vez
    """
    estados_data = [
        ("01", "AC - ACRE"),
        ("02", "AL - ALAGOAS"),
        ("03", "AP - AMAPA"),
        ("04", "AM - AMAZONAS"),
        ("05", "BA - BAHIA"),
        ("06", "CE - CEARA"),
        ("07", "ES - ESPIRITO SANTO"),
        ("08", "GO - GOIAS"),
        ("09", "MA - MARANHAO"),
        ("10", "MT - MATO GROSSO"),
        ("11", "MS - MATO GROSSO DO SUL"),
        ("12", "MG - MINAS GERAIS"),
        ("13", "PA - PARA"),
        ("14", "PB - PARAIBA"),
        ("15", "PR - PARANA"),
        ("16", "PE - PERNAMBUCO"),
        ("17", "PI - PIAUI"),
        ("18", "RJ - RIO DE JANEIRO"),
        ("19", "RN - RIO GRANDE DO NORTE"),
        ("20", "RS - RIO GRANDE DO SUL"),
        ("21", "RO - RONDONIA"),
        ("22", "RR - RORAIMA"),
        ("23", "SC - SANTA CATARINA"),
        ("24", "SP - SAO PAULO"),
        ("25", "SE - SERGIPE"),
        ("26", "TO - TOCANTINS"),
        ("27", "DF - DISTRITO FEDERAL"),
        ("99", "ZZ - NAO INFORMADA")
    ]
    
    df_estados = self.spark.createDataFrame(
        estados_data, 
        ["codigo_estado", "nome_estado"]
    )
    
    # Salvar como tabela persistente
    df_estados.write.mode("overwrite").saveAsTable("lookup.estados_brasil")
    
    print("Tabela de lookup de estados criada: lookup.estados_brasil")

def coletapedt002_lookup_persistente(self):
    """
    Versão usando tabela de lookup persistente
    """
    df_data_ref = self.collectdata('b_stbr_pe.pedt002')
    
    resultado = (
        self.spark.read.table("b_stbr_pe.pedt002")
        .where(col("dat_ref_carga") == df_data_ref)
        .select("penumper", "pesestrat", "penommad", "penompad")
        .distinct()
        .join(
            broadcast(self.spark.read.table("lookup.estados_brasil")),
            col("pesestrat") == col("codigo_estado"),
            "left"
        )
        .select(
            col("penumper"),
            col("pesestrat"),
            col("penommad"),
            col("penompad"),
            coalesce(col("nome_estado"), lit("")).alias("natural")
        )
        .persist(self.storage_level)
    )
    
    return resultado
```

### 6. **Versão Final Otimizada Recomendada**

```python
def coletapedt002_final_otimizado(self):
    """
    Versão final otimizada combinando as melhores práticas
    """
    # Configurações otimizadas
    spark.conf.set("spark.sql.adaptive.enabled", "true")
    spark.conf.set("spark.sql.adaptive.coalescePartitions.enabled", "true")
    
    df_data_ref = self.collectdata('b_stbr_pe.pedt002')
    
    # Análise prévia do volume de dados
    total_records = (
        self.spark.read.table("b_stbr_pe.pedt002")
        .where(col("dat_ref_carga") == df_data_ref)
        .count()
    )
    
    # Escolha da estratégia baseada no volume
    if total_records < 1000000:  # Menos de 1M registros - usar join
        return self._coletapedt002_join_strategy(df_data_ref)
    else:  # Mais de 1M registros - usar SQL CASE
        return self._coletapedt002_sql_strategy(df_data_ref)

def _coletapedt002_join_strategy(self, df_data_ref):
    """Estratégia de join para volumes menores"""
    estados_data = [
        ("01", "AC - ACRE"), ("02", "AL - ALAGOAS"), ("03", "AP - AMAPA"),
        ("04", "AM - AMAZONAS"), ("05", "BA - BAHIA"), ("06", "CE - CEARA"),
        ("07", "ES - ESPIRITO SANTO"), ("08", "GO - GOIAS"), ("09", "MA - MARANHAO"),
        ("10", "MT - MATO GROSSO"), ("11", "MS - MATO GROSSO DO SUL"), ("12", "MG - MINAS GERAIS"),
        ("13", "PA - PARA"), ("14", "PB - PARAIBA"), ("15", "PR - PARANA"),
        ("16", "PE - PERNAMBUCO"), ("17", "PI - PIAUI"), ("18", "RJ - RIO DE JANEIRO"),
        ("19", "RN - RIO GRANDE DO NORTE"), ("20", "RS - RIO GRANDE DO SUL"), ("21", "RO - RONDONIA"),
        ("22", "RR - RORAIMA"), ("23", "SC - SANTA CATARINA"), ("24", "SP - SAO PAULO"),
        ("25", "SE - SERGIPE"), ("26", "TO - TOCANTINS"), ("27", "DF - DISTRITO FEDERAL"),
        ("99", "ZZ - NAO INFORMADA")
    ]
    
    df_estados = self.spark.createDataFrame(estados_data, ["codigo_estado", "nome_estado"])
    
    return (
        self.spark.read.table("b_stbr_pe.pedt002")
        .where(col("dat_ref_carga") == df_data_ref)
        .select("penumper", "pesestrat", "penommad", "penompad")
        .distinct()
        .join(broadcast(df_estados), col("pesestrat") == col("codigo_estado"), "left")
        .select(
            col("penumper"), col("pesestrat"), col("penommad"), col("penompad"),
            coalesce(col("nome_estado"), lit("")).alias("natural")
        )
        .persist(self.storage_level)
    )

def _coletapedt002_sql_strategy(self, df_data_ref):
    """Estratégia SQL CASE para volumes maiores"""
    return (
        self.spark.read.table("b_stbr_pe.pedt002")
        .where(col("dat_ref_carga") == df_data_ref)
        .select(
            col("penumper"), col("pesestrat"), col("penommad"), col("penompad"),
            expr("""
                CASE pesestrat
                    WHEN '01' THEN 'AC - ACRE'
                    WHEN '02' THEN 'AL - ALAGOAS'
                    WHEN '03' THEN 'AP - AMAPA'
                    WHEN '04' THEN 'AM - AMAZONAS'
                    WHEN '05' THEN 'BA - BAHIA'
                    WHEN '06' THEN 'CE - CEARA'
                    WHEN '07' THEN 'ES - ESPIRITO SANTO'
                    WHEN '08' THEN 'GO - GOIAS'
                    WHEN '09' THEN 'MA - MARANHAO'
                    WHEN '10' THEN 'MT - MATO GROSSO'
                    WHEN '11' THEN 'MS - MATO GROSSO DO SUL'
                    WHEN '12' THEN 'MG - MINAS GERAIS'
                    WHEN '13' THEN 'PA - PARA'
                    WHEN '14' THEN 'PB - PARAIBA'
                    WHEN '15' THEN 'PR - PARANA'
                    WHEN '16' THEN 'PE - PERNAMBUCO'
                    WHEN '17' THEN 'PI - PIAUI'
                    WHEN '18' THEN 'RJ - RIO DE JANEIRO'
                    WHEN '19' THEN 'RN - RIO GRANDE DO NORTE'
                    WHEN '20' THEN 'RS - RIO GRANDE DO SUL'
                    WHEN '21' THEN 'RO - RONDONIA'
                    WHEN '22' THEN 'RR - RORAIMA'
                    WHEN '23' THEN 'SC - SANTA CATARINA'
                    WHEN '24' THEN 'SP - SAO PAULO'
                    WHEN '25' THEN 'SE - SERGIPE'
                    WHEN '26' THEN 'TO - TOCANTINS'
                    WHEN '27' THEN 'DF - DISTRITO FEDERAL'
                    WHEN '99' THEN 'ZZ - NAO INFORMADA'
                    ELSE ''
                END
            """).alias("natural")
        )
        .distinct()
        .persist(self.storage_level)
    )
```

## Estimativa de Melhoria de Performance

### Comparação de Abordagens:

| Abordagem | Redução Tempo | Redução Recursos | Complexidade | Recomendação |
|-----------|---------------|------------------|--------------|--------------|
| SQL CASE Nativo | 40-50% | 30-40% | Baixa | ✅ Recomendado |
| Join com Broadcast | 50-60% | 35-45% | Média | ✅ Recomendado |
| UDF com Broadcast | 30-40% | 25-35% | Média | ⚠️ Alternativa |
| Tabela Lookup Persistente | 60-70% | 40-50% | Alta | ✅ Para uso frequente |

### Métricas Esperadas Gerais:

| Otimização | Impacto Performance | Facilidade Implementação |
|------------|-------------------|-------------------------|
| Substituir when/otherwise por SQL CASE | Alto | Fácil |
| Implementar join com broadcast | Muito Alto | Médio |
| Adicionar validação de dados | Baixo | Fácil |
| Cache estratégico | Médio | Fácil |
| **Total Estimado** | **50-70%** | **Médio** |

## Implementação Recomendada

### Fase 1 (Imediata): Otimização Básica
- Substituir when/otherwise por expressão SQL CASE
- Aplicar filtros antes de distinct()
- Configurar Spark AQE

### Fase 2 (Semana 1): Otimização Avançada
- Implementar join com broadcast para volumes menores
- Adicionar validação de códigos de estado
- Implementar cache estratégico

### Fase 3 (Semana 2): Otimização Empresarial
- Criar tabela de lookup persistente se usado frequentemente
- Implementar estratégia adaptativa baseada no volume
- Adicionar monitoramento de performance

### Monitoramento Específico

```python
def monitor_coletapedt002_performance(df_result):
    # Verificar distribuição de estados
    df_estados_stats = (
        df_result
        .groupBy("natural")
        .count()
        .orderBy(desc("count"))
    )
    
    print("Distribuição de estados:")
    df_estados_stats.show(30)
    
    # Verificar códigos inválidos
    codigos_invalidos = df_result.filter(col("natural") == "").count()
    if codigos_invalidos > 0:
        print(f"Warning: {codigos_invalidos} registros com códigos de estado inválidos")
    
    return df_estados_stats
```

Esta implementação otimizada deve resultar em uma melhoria significativa de performance, especialmente para o processamento de mapeamentos de códigos para descrições, que é um padrão muito comum em processamento de dados cadastrais.

