"""
Testes unitários para modelos
Autor: Carlos Morais

Testes para validação dos modelos SQLAlchemy.
"""

import pytest
from datetime import datetime
from decimal import Decimal
from uuid import uuid4

from src.app.models.data_contracts import DataContract
from src.app.models.contract_versions import ContractVersion
from src.app.models.contract_layouts import ContractLayout
from src.app.models.data_objects import DataObject
from src.app.models.data_object_properties import DataObjectProperty
from src.app.models.quality_rules import QualityRule
from src.app.models.users import User
from src.app.models.groups import Group
from src.app.models.permissions import Permission, GroupPermission


class TestDataContract:
    """Testes para modelo DataContract"""
    
    def test_create_data_contract(self, sample_data_contract_data):
        """Teste de criação de contrato de dados"""
        # Act
        contract = DataContract(**sample_data_contract_data)
        
        # Assert
        assert contract.contract_name == sample_data_contract_data["contract_name"]
        assert contract.contract_status == sample_data_contract_data["contract_status"]
        assert contract.data_product_name == sample_data_contract_data["data_product_name"]
    
    def test_data_contract_repr(self, sample_data_contract_data):
        """Teste de representação string"""
        # Arrange
        contract = DataContract(**sample_data_contract_data)
        
        # Act
        repr_str = repr(contract)
        
        # Assert
        assert "DataContract" in repr_str
        assert sample_data_contract_data["contract_name"] in repr_str
    
    def test_data_contract_to_dict(self, sample_data_contract_data):
        """Teste de conversão para dicionário"""
        # Arrange
        contract = DataContract(**sample_data_contract_data)
        contract.id = uuid4()
        contract.data_criacao = datetime.utcnow()
        contract.data_atualizacao = datetime.utcnow()
        
        # Act
        result = contract.to_dict()
        
        # Assert
        assert isinstance(result, dict)
        assert "id" in result
        assert "contract_name" in result
        assert "data_criacao" in result
    
    def test_data_contract_is_active_property(self, sample_data_contract_data):
        """Teste da propriedade is_active"""
        # Arrange
        contract = DataContract(**sample_data_contract_data)
        contract.contract_status = "ativo"
        
        # Act & Assert
        assert contract.is_active is True
        
        # Arrange
        contract.contract_status = "depreciado"
        
        # Act & Assert
        assert contract.is_active is False
    
    def test_data_contract_is_deprecated_property(self, sample_data_contract_data):
        """Teste da propriedade is_deprecated"""
        # Arrange
        contract = DataContract(**sample_data_contract_data)
        contract.contract_status = "depreciado"
        
        # Act & Assert
        assert contract.is_deprecated is True


class TestContractVersion:
    """Testes para modelo ContractVersion"""
    
    def test_create_contract_version(self):
        """Teste de criação de versão de contrato"""
        # Arrange
        version_data = {
            "contract_id": uuid4(),
            "version_tag": "1.0.0",
            "version_description": "Initial version",
            "version_status": "ativo"
        }
        
        # Act
        version = ContractVersion(**version_data)
        
        # Assert
        assert version.version_tag == "1.0.0"
        assert version.version_status == "ativo"
    
    def test_contract_version_is_active_property(self):
        """Teste da propriedade is_active"""
        # Arrange
        version = ContractVersion(
            contract_id=uuid4(),
            version_tag="1.0.0",
            version_status="ativo"
        )
        
        # Act & Assert
        assert version.is_active is True
        
        # Arrange
        version.version_status = "depreciado"
        
        # Act & Assert
        assert version.is_active is False


class TestContractLayout:
    """Testes para modelo ContractLayout"""
    
    def test_create_contract_layout(self, test_contract_layout_data):
        """Teste de criação de layout de contrato"""
        # Act
        layout = ContractLayout(**test_contract_layout_data)
        
        # Assert
        assert layout.layout_name == test_contract_layout_data["layout_name"]
        assert layout.layout_type == test_contract_layout_data["layout_type"]
        assert layout.country_code == test_contract_layout_data["country_code"]
    
    def test_contract_layout_properties(self, test_contract_layout_data):
        """Teste das propriedades do layout"""
        # Arrange
        layout = ContractLayout(**test_contract_layout_data)
        
        # Act & Assert
        assert layout.is_country_specific is True
        assert layout.is_region_specific is False
        assert layout.supports_compliance is False
    
    def test_contract_layout_template_variables(self, test_contract_layout_data):
        """Teste das variáveis do template"""
        # Arrange
        layout = ContractLayout(**test_contract_layout_data)
        
        # Act
        variables = layout.get_template_variables()
        
        # Assert
        assert isinstance(variables, dict)
        assert "layout_name" in variables
        assert "country_code" in variables
        assert variables["layout_name"] == test_contract_layout_data["layout_name"]


class TestDataObject:
    """Testes para modelo DataObject"""
    
    def test_create_data_object(self, test_data_object_data):
        """Teste de criação de objeto de dados"""
        # Arrange
        data_object_data = {
            **test_data_object_data,
            "schema_definition_id": uuid4()
        }
        
        # Act
        data_object = DataObject(**data_object_data)
        
        # Assert
        assert data_object.object_name == test_data_object_data["object_name"]
        assert data_object.object_type == test_data_object_data["object_type"]
        assert data_object.estimated_size_gb == test_data_object_data["estimated_size_gb"]
    
    def test_data_object_properties(self, test_data_object_data):
        """Teste das propriedades do objeto de dados"""
        # Arrange
        data_object_data = {
            **test_data_object_data,
            "schema_definition_id": uuid4(),
            "is_pii_data": True,
            "encryption_enabled": True,
            "access_control_enabled": True
        }
        data_object = DataObject(**data_object_data)
        
        # Act & Assert
        assert data_object.estimated_size_mb == Decimal('10752.0')  # 10.5 * 1024
        assert data_object.is_large_table is False  # < 100GB
        assert data_object.requires_special_handling is True  # PII data
        assert data_object.compliance_level == "HIGH"
    
    def test_data_object_lifecycle_policies(self, test_data_object_data):
        """Teste das políticas de ciclo de vida"""
        # Arrange
        data_object_data = {
            **test_data_object_data,
            "schema_definition_id": uuid4(),
            "retention_policy": "7 years",
            "purge_policy": "permanent deletion",
            "backup_policy": "daily",
            "archival_policy": "yearly"
        }
        data_object = DataObject(**data_object_data)
        
        # Act
        policies = data_object.get_lifecycle_policies()
        
        # Assert
        assert policies["retention"] == "7 years"
        assert policies["purge"] == "permanent deletion"
        assert policies["backup"] == "daily"
        assert policies["archival"] == "yearly"


class TestDataObjectProperty:
    """Testes para modelo DataObjectProperty"""
    
    def test_create_data_object_property(self, test_data_object_property_data):
        """Teste de criação de propriedade"""
        # Arrange
        property_data = {
            **test_data_object_property_data,
            "data_object_id": uuid4()
        }
        
        # Act
        prop = DataObjectProperty(**property_data)
        
        # Assert
        assert prop.property_name == test_data_object_property_data["property_name"]
        assert prop.logical_type == test_data_object_property_data["logical_type"]
        assert prop.physical_type == test_data_object_property_data["physical_type"]
    
    def test_data_object_property_privacy_level(self, test_data_object_property_data):
        """Teste do nível de privacidade"""
        # Arrange
        property_data = {
            **test_data_object_property_data,
            "data_object_id": uuid4(),
            "is_pii": True
        }
        prop = DataObjectProperty(**property_data)
        
        # Act & Assert
        assert prop.privacy_level == "HIGH"
        assert prop.requires_masking is True
    
    def test_data_object_property_quality_grade(self, test_data_object_property_data):
        """Teste da nota de qualidade"""
        # Arrange
        property_data = {
            **test_data_object_property_data,
            "data_object_id": uuid4(),
            "quality_score": Decimal('85.5')
        }
        prop = DataObjectProperty(**property_data)
        
        # Act & Assert
        assert prop.data_quality_grade == "B"
    
    def test_data_object_property_compliance_flags(self, test_data_object_property_data):
        """Teste das flags de compliance"""
        # Arrange
        property_data = {
            **test_data_object_property_data,
            "data_object_id": uuid4(),
            "is_pii": True,
            "is_gdpr_relevant": True,
            "is_lgpd_relevant": True
        }
        prop = DataObjectProperty(**property_data)
        
        # Act
        flags = prop.get_compliance_flags()
        
        # Assert
        assert flags["is_pii"] is True
        assert flags["is_gdpr_relevant"] is True
        assert flags["is_lgpd_relevant"] is True
        assert flags["privacy_level"] == "HIGH"


class TestQualityRule:
    """Testes para modelo QualityRule"""
    
    def test_create_quality_rule(self, test_quality_rule_data):
        """Teste de criação de regra de qualidade"""
        # Act
        rule = QualityRule(**test_quality_rule_data)
        
        # Assert
        assert rule.rule_name == test_quality_rule_data["rule_name"]
        assert rule.quality_dimension == test_quality_rule_data["quality_dimension"]
        assert rule.severity_level == test_quality_rule_data["severity_level"]
    
    def test_quality_rule_properties(self, test_quality_rule_data):
        """Teste das propriedades da regra"""
        # Arrange
        rule_data = {
            **test_quality_rule_data,
            "severity_level": "critical",
            "execution_frequency": "real_time"
        }
        rule = QualityRule(**rule_data)
        
        # Act & Assert
        assert rule.is_critical is True
        assert rule.is_real_time is True


class TestUser:
    """Testes para modelo User"""
    
    def test_create_user(self, test_user_data):
        """Teste de criação de usuário"""
        # Act
        user = User(**test_user_data)
        
        # Assert
        assert user.username == test_user_data["username"]
        assert user.email == test_user_data["email"]
        assert user.full_name == test_user_data["full_name"]
    
    def test_user_properties(self, test_user_data):
        """Teste das propriedades do usuário"""
        # Arrange
        user_data = {
            **test_user_data,
            "last_login_timestamp": datetime.utcnow()
        }
        user = User(**user_data)
        
        # Act & Assert
        assert user.is_recently_active is True


class TestGroup:
    """Testes para modelo Group"""
    
    def test_create_group(self, test_group_data):
        """Teste de criação de grupo"""
        # Act
        group = Group(**test_group_data)
        
        # Assert
        assert group.group_name == test_group_data["group_name"]
        assert group.group_type == test_group_data["group_type"]
    
    def test_group_properties(self, test_group_data):
        """Teste das propriedades do grupo"""
        # Arrange
        group_data = {
            **test_group_data,
            "can_approve_contracts": True,
            "can_access_pii": True,
            "compliance_level": "HIGH"
        }
        group = Group(**group_data)
        
        # Act & Assert
        assert group.is_root_group is True  # Sem parent_group_id
        assert group.is_high_privilege is True
        assert group.requires_enhanced_security is False  # Sem MFA ou IP restrictions
    
    def test_group_hierarchy_path(self, test_group_data):
        """Teste do caminho hierárquico"""
        # Arrange
        group = Group(**test_group_data)
        
        # Act
        path = group.get_hierarchy_path()
        
        # Assert
        assert path == test_group_data["group_name"]


class TestPermission:
    """Testes para modelo Permission"""
    
    def test_create_permission(self, test_permission_data):
        """Teste de criação de permissão"""
        # Act
        permission = Permission(**test_permission_data)
        
        # Assert
        assert permission.permission_name == test_permission_data["permission_name"]
        assert permission.permission_category == test_permission_data["permission_category"]
        assert permission.action == test_permission_data["action"]
    
    def test_permission_properties(self, test_permission_data):
        """Teste das propriedades da permissão"""
        # Arrange
        permission_data = {
            **test_permission_data,
            "security_level": "HIGH",
            "requires_mfa": True,
            "action": "delete"
        }
        permission = Permission(**permission_data)
        
        # Act & Assert
        assert permission.is_high_risk is True
        assert permission.is_administrative is False  # action delete não é admin
        assert permission.requires_enhanced_monitoring is True
    
    def test_permission_security_config(self, test_permission_data):
        """Teste da configuração de segurança"""
        # Arrange
        permission_data = {
            **test_permission_data,
            "security_level": "CRITICAL",
            "requires_mfa": True,
            "requires_justification": True
        }
        permission = Permission(**permission_data)
        
        # Act
        config = permission.get_security_config()
        
        # Assert
        assert config["security_level"] == "CRITICAL"
        assert config["requires_mfa"] is True
        assert config["requires_justification"] is True
        assert config["is_high_risk"] is True


class TestGroupPermission:
    """Testes para modelo GroupPermission"""
    
    def test_create_group_permission(self):
        """Teste de criação de permissão de grupo"""
        # Arrange
        group_permission_data = {
            "group_id": uuid4(),
            "permission_id": uuid4(),
            "resource_type": "contract",
            "is_active": True
        }
        
        # Act
        group_perm = GroupPermission(**group_permission_data)
        
        # Assert
        assert group_perm.group_id == group_permission_data["group_id"]
        assert group_perm.permission_id == group_permission_data["permission_id"]
        assert group_perm.resource_type == group_permission_data["resource_type"]
    
    def test_group_permission_validity(self):
        """Teste da validade da permissão"""
        # Arrange
        group_permission_data = {
            "group_id": uuid4(),
            "permission_id": uuid4(),
            "is_active": True,
            "valid_from": datetime(2024, 1, 1),
            "valid_until": datetime(2024, 12, 31)
        }
        group_perm = GroupPermission(**group_permission_data)
        
        # Act
        validity = group_perm.get_validity_status()
        
        # Assert
        assert validity["is_active"] is True
        assert "valid_from" in validity
        assert "valid_until" in validity

