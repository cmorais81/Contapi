"""
Testes unitários para DataContractsService
Seguindo exatamente o modelo_estendido.dbml original
Autor: Carlos Morais
"""

import pytest
from uuid import uuid4

from src.app.services.data_contracts import DataContractsService
from src.app.repositories.data_contracts import DataContractsRepository
from src.app.utils.exceptions import EntityNotFoundError, ValidationError
from src.app.schemas.base import PaginationParams
from tests.conftest import TestDataFactory


@pytest.mark.unit
@pytest.mark.database
class TestDataContractsService:
    """Testes para DataContractsService"""
    
    @pytest.mark.asyncio
    async def test_create_contract_success(self, db_session):
        """Testa criação bem-sucedida de contrato"""
        repository = DataContractsRepository(db_session)
        service = DataContractsService(repository)
        
        contract_data = TestDataFactory.create_contract_data()
        contract = await service.create(contract_data)
        
        assert contract.contract_id is not None
        assert contract.contract_name == contract_data["contract_name"]
        assert contract.contract_description == contract_data["contract_description"]
        assert contract.contract_status == contract_data["contract_status"]
    
    @pytest.mark.asyncio
    async def test_create_contract_duplicate_name(self, db_session):
        """Testa criação de contrato com nome duplicado"""
        repository = DataContractsRepository(db_session)
        service = DataContractsService(repository)
        
        # Criar primeiro contrato
        contract_data = TestDataFactory.create_contract_data()
        await service.create(contract_data)
        
        # Tentar criar segundo contrato com mesmo nome
        duplicate_data = TestDataFactory.create_contract_data(
            contract_name=contract_data["contract_name"]
        )
        
        with pytest.raises(ValidationError) as exc_info:
            await service.create(duplicate_data)
        
        assert "já existe" in str(exc_info.value)
    
    @pytest.mark.asyncio
    async def test_create_contract_missing_required_fields(self, db_session):
        """Testa criação de contrato sem campos obrigatórios"""
        repository = DataContractsRepository(db_session)
        service = DataContractsService(repository)
        
        # Dados sem campo obrigatório
        invalid_data = {
            "contract_description": "Descrição sem nome"
        }
        
        with pytest.raises(ValidationError) as exc_info:
            await service.create(invalid_data)
        
        assert "obrigatórios ausentes" in str(exc_info.value)
    
    @pytest.mark.asyncio
    async def test_create_contract_invalid_status(self, db_session):
        """Testa criação de contrato com status inválido"""
        repository = DataContractsRepository(db_session)
        service = DataContractsService(repository)
        
        contract_data = TestDataFactory.create_contract_data(
            contract_status="invalid_status"
        )
        
        with pytest.raises(ValidationError) as exc_info:
            await service.create(contract_data)
        
        assert "Valor inválido" in str(exc_info.value)
    
    @pytest.mark.asyncio
    async def test_create_contract_partial_unity_catalog(self, db_session):
        """Testa criação com integração Unity Catalog incompleta"""
        repository = DataContractsRepository(db_session)
        service = DataContractsService(repository)
        
        contract_data = TestDataFactory.create_contract_data(
            unity_catalog_name="test_catalog",
            unity_catalog_schema="test_schema"
            # unity_catalog_table ausente
        )
        
        with pytest.raises(ValidationError) as exc_info:
            await service.create(contract_data)
        
        assert "Unity Catalog" in str(exc_info.value)
    
    @pytest.mark.asyncio
    async def test_get_by_id_success(self, db_session):
        """Testa busca por ID bem-sucedida"""
        repository = DataContractsRepository(db_session)
        service = DataContractsService(repository)
        
        # Criar contrato
        contract_data = TestDataFactory.create_contract_data()
        created_contract = await service.create(contract_data)
        
        # Buscar por ID
        found_contract = await service.get_by_id(created_contract.contract_id)
        
        assert found_contract.contract_id == created_contract.contract_id
        assert found_contract.contract_name == created_contract.contract_name
    
    @pytest.mark.asyncio
    async def test_get_by_id_not_found(self, db_session):
        """Testa busca por ID inexistente"""
        repository = DataContractsRepository(db_session)
        service = DataContractsService(repository)
        
        non_existent_id = uuid4()
        
        with pytest.raises(EntityNotFoundError) as exc_info:
            await service.get_by_id(non_existent_id)
        
        assert str(non_existent_id) in str(exc_info.value)
    
    @pytest.mark.asyncio
    async def test_get_by_name_success(self, db_session):
        """Testa busca por nome bem-sucedida"""
        repository = DataContractsRepository(db_session)
        service = DataContractsService(repository)
        
        # Criar contrato
        contract_data = TestDataFactory.create_contract_data()
        created_contract = await service.create(contract_data)
        
        # Buscar por nome
        found_contract = await service.get_by_name(created_contract.contract_name)
        
        assert found_contract.contract_id == created_contract.contract_id
        assert found_contract.contract_name == created_contract.contract_name
    
    @pytest.mark.asyncio
    async def test_get_by_name_not_found(self, db_session):
        """Testa busca por nome inexistente"""
        repository = DataContractsRepository(db_session)
        service = DataContractsService(repository)
        
        with pytest.raises(EntityNotFoundError) as exc_info:
            await service.get_by_name("non_existent_contract")
        
        assert "não encontrado" in str(exc_info.value)
    
    @pytest.mark.asyncio
    async def test_get_by_status_valid(self, db_session):
        """Testa busca por status válido"""
        repository = DataContractsRepository(db_session)
        service = DataContractsService(repository)
        
        # Criar contratos com diferentes status
        await service.create(TestDataFactory.create_contract_data(contract_status="active"))
        await service.create(TestDataFactory.create_contract_data(contract_status="draft"))
        
        # Buscar por status
        active_contracts = await service.get_by_status("active")
        draft_contracts = await service.get_by_status("draft")
        
        assert len(active_contracts) == 1
        assert len(draft_contracts) == 1
        assert active_contracts[0].contract_status == "active"
        assert draft_contracts[0].contract_status == "draft"
    
    @pytest.mark.asyncio
    async def test_get_by_status_invalid(self, db_session):
        """Testa busca por status inválido"""
        repository = DataContractsRepository(db_session)
        service = DataContractsService(repository)
        
        with pytest.raises(ValidationError) as exc_info:
            await service.get_by_status("invalid_status")
        
        assert "Status inválido" in str(exc_info.value)
    
    @pytest.mark.asyncio
    async def test_search_contracts_valid_term(self, db_session):
        """Testa busca textual com termo válido"""
        repository = DataContractsRepository(db_session)
        service = DataContractsService(repository)
        
        # Criar contratos
        await service.create(TestDataFactory.create_contract_data(
            contract_name="customer_data",
            contract_description="Dados de clientes"
        ))
        await service.create(TestDataFactory.create_contract_data(
            contract_name="product_data",
            contract_description="Dados de produtos"
        ))
        
        # Buscar
        pagination = PaginationParams(page=1, size=10)
        result = await service.search("customer", pagination)
        
        assert result.total >= 1
        assert len(result.items) >= 1
        assert "customer" in result.items[0].contract_name.lower()
    
    @pytest.mark.asyncio
    async def test_search_contracts_invalid_term(self, db_session):
        """Testa busca textual com termo inválido"""
        repository = DataContractsRepository(db_session)
        service = DataContractsService(repository)
        
        pagination = PaginationParams(page=1, size=10)
        
        with pytest.raises(ValidationError) as exc_info:
            await service.search("a", pagination)  # Termo muito curto
        
        assert "pelo menos 2 caracteres" in str(exc_info.value)
    
    @pytest.mark.asyncio
    async def test_update_contract_success(self, db_session):
        """Testa atualização bem-sucedida"""
        repository = DataContractsRepository(db_session)
        service = DataContractsService(repository)
        
        # Criar contrato
        contract_data = TestDataFactory.create_contract_data()
        created_contract = await service.create(contract_data)
        
        # Atualizar
        update_data = {
            "contract_description": "Descrição atualizada",
            "contract_status": "active"
        }
        updated_contract = await service.update(created_contract.contract_id, update_data)
        
        assert updated_contract.contract_description == "Descrição atualizada"
        assert updated_contract.contract_status == "active"
    
    @pytest.mark.asyncio
    async def test_update_contract_not_found(self, db_session):
        """Testa atualização de contrato inexistente"""
        repository = DataContractsRepository(db_session)
        service = DataContractsService(repository)
        
        non_existent_id = uuid4()
        update_data = {"contract_description": "Nova descrição"}
        
        with pytest.raises(EntityNotFoundError) as exc_info:
            await service.update(non_existent_id, update_data)
        
        assert str(non_existent_id) in str(exc_info.value)
    
    @pytest.mark.asyncio
    async def test_activate_contract_success(self, db_session):
        """Testa ativação bem-sucedida de contrato"""
        repository = DataContractsRepository(db_session)
        service = DataContractsService(repository)
        
        # Criar contrato com dados completos
        contract_data = TestDataFactory.create_contract_data(
            contract_status="draft",
            contract_description="Descrição completa",
            contract_owner="owner",
            business_domain="domain"
        )
        created_contract = await service.create(contract_data)
        
        # Ativar
        activated_contract = await service.activate_contract(created_contract.contract_id)
        
        assert activated_contract.contract_status == "active"
    
    @pytest.mark.asyncio
    async def test_activate_contract_missing_data(self, db_session):
        """Testa ativação de contrato com dados incompletos"""
        repository = DataContractsRepository(db_session)
        service = DataContractsService(repository)
        
        # Criar contrato sem descrição
        contract_data = TestDataFactory.create_contract_data(
            contract_status="draft",
            contract_description=None  # Faltando descrição
        )
        created_contract = await service.create(contract_data)
        
        # Tentar ativar
        with pytest.raises(ValidationError) as exc_info:
            await service.activate_contract(created_contract.contract_id)
        
        assert "descrição" in str(exc_info.value)
    
    @pytest.mark.asyncio
    async def test_activate_contract_already_active(self, db_session):
        """Testa ativação de contrato já ativo"""
        repository = DataContractsRepository(db_session)
        service = DataContractsService(repository)
        
        # Criar contrato ativo
        contract_data = TestDataFactory.create_contract_data(
            contract_status="active",
            contract_description="Descrição completa",
            contract_owner="owner",
            business_domain="domain"
        )
        created_contract = await service.create(contract_data)
        
        # Tentar ativar novamente
        with pytest.raises(ValidationError) as exc_info:
            await service.activate_contract(created_contract.contract_id)
        
        assert "já está ativo" in str(exc_info.value)
    
    @pytest.mark.asyncio
    async def test_deprecate_contract_success(self, db_session):
        """Testa depreciação bem-sucedida"""
        repository = DataContractsRepository(db_session)
        service = DataContractsService(repository)
        
        # Criar contrato ativo
        contract_data = TestDataFactory.create_contract_data(contract_status="active")
        created_contract = await service.create(contract_data)
        
        # Depreciar
        deprecated_contract = await service.deprecate_contract(created_contract.contract_id)
        
        assert deprecated_contract.contract_status == "deprecated"
    
    @pytest.mark.asyncio
    async def test_archive_contract_success(self, db_session):
        """Testa arquivamento bem-sucedido"""
        repository = DataContractsRepository(db_session)
        service = DataContractsService(repository)
        
        # Criar contrato
        contract_data = TestDataFactory.create_contract_data(contract_status="deprecated")
        created_contract = await service.create(contract_data)
        
        # Arquivar
        archived_contract = await service.archive_contract(created_contract.contract_id)
        
        assert archived_contract.contract_status == "archived"
    
    @pytest.mark.asyncio
    async def test_delete_contract_success(self, db_session):
        """Testa remoção bem-sucedida"""
        repository = DataContractsRepository(db_session)
        service = DataContractsService(repository)
        
        # Criar contrato
        contract_data = TestDataFactory.create_contract_data()
        created_contract = await service.create(contract_data)
        
        # Remover
        deleted = await service.delete(created_contract.contract_id)
        
        assert deleted is True
        
        # Verificar que foi removido
        with pytest.raises(EntityNotFoundError):
            await service.get_by_id(created_contract.contract_id)
    
    @pytest.mark.asyncio
    async def test_get_all_paginated(self, db_session):
        """Testa listagem paginada"""
        repository = DataContractsRepository(db_session)
        service = DataContractsService(repository)
        
        # Criar múltiplos contratos
        for i in range(5):
            await service.create(TestDataFactory.create_contract_data())
        
        # Buscar paginado
        pagination = PaginationParams(page=1, size=3)
        result = await service.get_all_paginated(pagination)
        
        assert result.total == 5
        assert len(result.items) == 3
        assert result.page == 1
        assert result.size == 3
        assert result.pages == 2
    
    @pytest.mark.asyncio
    async def test_get_contracts_stats(self, db_session):
        """Testa estatísticas de contratos"""
        repository = DataContractsRepository(db_session)
        service = DataContractsService(repository)
        
        # Criar contratos com diferentes configurações
        await service.create(TestDataFactory.create_contract_data(
            contract_status="active",
            abac_enabled=True,
            monitoring_enabled=True
        ))
        await service.create(TestDataFactory.create_contract_data(
            contract_status="draft",
            abac_enabled=False,
            monitoring_enabled=True
        ))
        
        # Obter estatísticas
        stats = await service.get_contracts_stats()
        
        assert stats["total"] == 2
        assert "by_status" in stats
        assert "abac_enabled" in stats
        assert "monitoring_enabled" in stats

