"""
Testes unitários para DataContractsRepository com snake_case
Autor: Carlos Morais
"""

import pytest
from uuid import uuid4
from sqlalchemy.orm import Session

from src.app.models.data_contracts import DataContracts
from src.app.repositories.data_contracts import DataContractsRepository


class TestDataContractsRepository:
    """Testes para DataContractsRepository"""

    @pytest.fixture
    def repository(self, db_session: Session):
        """Fixture do repository"""
        return DataContractsRepository(db_session)

    @pytest.fixture
    def sample_contract_data(self):
        """Dados de exemplo para contrato"""
        return {
            "contract_name": "test_contract",
            "contract_description": "Contrato de teste",
            "contract_owner": "test_owner",
            "business_domain": "test_domain",
            "contract_status": "draft",
            "unity_catalog_enabled": True,
            "unity_catalog_name": "test_catalog",
            "unity_catalog_schema": "test_schema",
            "unity_catalog_table": "test_table",
            "abac_enabled": False,
            "monitoring_enabled": True,
            "monitoring_frequency": "daily"
        }

    async def test_create_contract(self, repository: DataContractsRepository, sample_contract_data: dict):
        """Testa criação de contrato"""
        contract = DataContracts(**sample_contract_data)
        created = await repository.create(contract)
        
        assert created.contract_id is not None
        assert created.contract_name == sample_contract_data["contract_name"]
        assert created.contract_description == sample_contract_data["contract_description"]
        assert created.unity_catalog_enabled == sample_contract_data["unity_catalog_enabled"]

    async def test_get_by_name(self, repository: DataContractsRepository, sample_contract_data: dict):
        """Testa busca por nome"""
        contract = DataContracts(**sample_contract_data)
        await repository.create(contract)
        
        found = await repository.get_by_name(sample_contract_data["contract_name"])
        assert found is not None
        assert found.contract_name == sample_contract_data["contract_name"]

    async def test_get_by_name_not_found(self, repository: DataContractsRepository):
        """Testa busca por nome inexistente"""
        found = await repository.get_by_name("nonexistent_contract")
        assert found is None

    async def test_get_by_domain(self, repository: DataContractsRepository, sample_contract_data: dict):
        """Testa busca por domínio"""
        contract = DataContracts(**sample_contract_data)
        await repository.create(contract)
        
        contracts = await repository.get_by_domain(sample_contract_data["business_domain"])
        assert len(contracts) == 1
        assert contracts[0].business_domain == sample_contract_data["business_domain"]

    async def test_get_by_owner(self, repository: DataContractsRepository, sample_contract_data: dict):
        """Testa busca por proprietário"""
        contract = DataContracts(**sample_contract_data)
        await repository.create(contract)
        
        contracts = await repository.get_by_owner(sample_contract_data["contract_owner"])
        assert len(contracts) == 1
        assert contracts[0].contract_owner == sample_contract_data["contract_owner"]

    async def test_get_by_status(self, repository: DataContractsRepository, sample_contract_data: dict):
        """Testa busca por status"""
        contract = DataContracts(**sample_contract_data)
        await repository.create(contract)
        
        contracts = await repository.get_by_status(sample_contract_data["contract_status"])
        assert len(contracts) == 1
        assert contracts[0].contract_status == sample_contract_data["contract_status"]

    async def test_get_unity_catalog_enabled(self, repository: DataContractsRepository, sample_contract_data: dict):
        """Testa busca por Unity Catalog habilitado"""
        contract = DataContracts(**sample_contract_data)
        await repository.create(contract)
        
        contracts = await repository.get_unity_catalog_enabled()
        assert len(contracts) == 1
        assert contracts[0].unity_catalog_enabled is True

    async def test_get_abac_enabled(self, repository: DataContractsRepository, sample_contract_data: dict):
        """Testa busca por ABAC habilitado"""
        sample_contract_data["abac_enabled"] = True
        contract = DataContracts(**sample_contract_data)
        await repository.create(contract)
        
        contracts = await repository.get_abac_enabled()
        assert len(contracts) == 1
        assert contracts[0].abac_enabled is True

    async def test_get_monitoring_enabled(self, repository: DataContractsRepository, sample_contract_data: dict):
        """Testa busca por monitoramento habilitado"""
        contract = DataContracts(**sample_contract_data)
        await repository.create(contract)
        
        contracts = await repository.get_monitoring_enabled()
        assert len(contracts) == 1
        assert contracts[0].monitoring_enabled is True

    async def test_search_text(self, repository: DataContractsRepository, sample_contract_data: dict):
        """Testa busca textual"""
        contract = DataContracts(**sample_contract_data)
        await repository.create(contract)
        
        # Busca por nome
        contracts = await repository.search_text("test_contract")
        assert len(contracts) == 1
        
        # Busca por descrição
        contracts = await repository.search_text("teste")
        assert len(contracts) == 1
        
        # Busca por proprietário
        contracts = await repository.search_text("test_owner")
        assert len(contracts) == 1

    async def test_get_stats(self, repository: DataContractsRepository, sample_contract_data: dict):
        """Testa estatísticas"""
        contract = DataContracts(**sample_contract_data)
        await repository.create(contract)
        
        stats = await repository.get_stats()
        
        assert stats["total_contracts"] == 1
        assert "draft" in stats["by_status"]
        assert stats["by_status"]["draft"] == 1
        assert stats["unity_catalog_enabled"] == 1
        assert stats["abac_enabled"] == 0
        assert stats["monitoring_enabled"] == 1

    async def test_name_exists(self, repository: DataContractsRepository, sample_contract_data: dict):
        """Testa verificação de existência de nome"""
        contract = DataContracts(**sample_contract_data)
        created = await repository.create(contract)
        
        # Nome existe
        exists = await repository.name_exists(sample_contract_data["contract_name"])
        assert exists is True
        
        # Nome não existe
        exists = await repository.name_exists("nonexistent_name")
        assert exists is False
        
        # Nome existe mas excluindo o próprio ID
        exists = await repository.name_exists(
            sample_contract_data["contract_name"], 
            exclude_id=created.contract_id
        )
        assert exists is False

    async def test_update_contract(self, repository: DataContractsRepository, sample_contract_data: dict):
        """Testa atualização de contrato"""
        contract = DataContracts(**sample_contract_data)
        created = await repository.create(contract)
        
        # Atualizar
        created.contract_description = "Descrição atualizada"
        created.contract_status = "active"
        
        updated = await repository.update(created)
        
        assert updated.contract_description == "Descrição atualizada"
        assert updated.contract_status == "active"
        assert updated.contract_id == created.contract_id

    async def test_delete_contract(self, repository: DataContractsRepository, sample_contract_data: dict):
        """Testa remoção de contrato"""
        contract = DataContracts(**sample_contract_data)
        created = await repository.create(contract)
        
        # Verificar que existe
        found = await repository.get(created.contract_id)
        assert found is not None
        
        # Remover
        await repository.remove(created.contract_id)
        
        # Verificar que foi removido
        found = await repository.get(created.contract_id)
        assert found is None
