# Guia de Instalação - Data Governance API (Corrigida)

**Autor:** Carlos Morais  
**Versão:** 2.0 (Corrigida)  
**Data:** 2024-07-26

---

## 🎯 **Nota Importante**

Esta versão foi **completamente corrigida** para seguir **exatamente** o modelo de dados original `modelo_estendido.dbml` com **36 tabelas**. Todas as instruções de instalação e configuração foram atualizadas para refletir a estrutura correta.

---

## 📋 **Pré-requisitos**

### **Sistema Operacional**
- Linux (Ubuntu 20.04+ recomendado)
- macOS 10.15+
- Windows 10+ com WSL2

### **Software Necessário**
- **Docker:** 20.10+
- **Docker Compose:** 2.0+
- **Python:** 3.10+ (para desenvolvimento local)
- **Git:** 2.30+

### **Recursos Mínimos**
- **CPU:** 4 cores
- **RAM:** 8GB
- **Disco:** 20GB livres
- **Rede:** Acesso à internet

---

## 🚀 **Instalação Rápida (Docker)**

### **1. Clone o Repositório**
```bash
git clone <url_do_repositorio>
cd data-governance-api-final
```

### **2. Configure o Ambiente**
```bash
# Copie o arquivo de exemplo
cp .env.example .env

# Edite as configurações
nano .env
```

### **3. Inicie os Serviços**
```bash
# Construa e inicie todos os containers
docker-compose up -d --build

# Verifique o status
docker-compose ps
```

### **4. Verifique a Instalação**
```bash
# Teste a API
curl http://localhost:8000/health

# Acesse a documentação
open http://localhost:8000/docs
```

---

## ⚙️ **Configuração Detalhada**

### **Arquivo .env**
```bash
# =============================================================================
# Data Governance API - Configuração de Ambiente
# Autor: Carlos Morais
# =============================================================================

# -----------------------------------------------------------------------------
# BANCO DE DADOS
# -----------------------------------------------------------------------------
DATABASE_URL=postgresql://governance:governance123@postgres:5432/governance_db
DATABASE_POOL_SIZE=20
DATABASE_MAX_OVERFLOW=30
DATABASE_ECHO=false

# -----------------------------------------------------------------------------
# API CONFIGURATION
# -----------------------------------------------------------------------------
API_HOST=0.0.0.0
API_PORT=8000
API_WORKERS=4
DEBUG=false
RELOAD=false

# -----------------------------------------------------------------------------
# SEGURANÇA
# -----------------------------------------------------------------------------
SECRET_KEY=your-super-secret-key-change-in-production
JWT_ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=30
REFRESH_TOKEN_EXPIRE_DAYS=7

# -----------------------------------------------------------------------------
# UNITY CATALOG INTEGRATION
# -----------------------------------------------------------------------------
UNITY_CATALOG_ENABLED=true
UNITY_CATALOG_URL=https://your-workspace.cloud.databricks.com
UNITY_CATALOG_TOKEN=your-databricks-token
UNITY_CATALOG_WAREHOUSE_ID=your-warehouse-id

# -----------------------------------------------------------------------------
# REDIS (CACHE)
# -----------------------------------------------------------------------------
REDIS_URL=redis://redis:6379/0
REDIS_PASSWORD=
CACHE_TTL_SECONDS=3600
CACHE_MAX_CONNECTIONS=20

# -----------------------------------------------------------------------------
# MONITORAMENTO
# -----------------------------------------------------------------------------
ENABLE_METRICS=true
METRICS_PORT=9090
PROMETHEUS_ENABLED=true
JAEGER_ENABLED=true
JAEGER_AGENT_HOST=jaeger
JAEGER_AGENT_PORT=6831

# -----------------------------------------------------------------------------
# LOGGING
# -----------------------------------------------------------------------------
LOG_LEVEL=INFO
LOG_FORMAT=json
LOG_FILE=/app/logs/governance.log

# -----------------------------------------------------------------------------
# QUALIDADE DE DADOS
# -----------------------------------------------------------------------------
QUALITY_RULES_ENABLED=true
DLT_INTEGRATION_ENABLED=true
AUTO_REMEDIATION_ENABLED=false

# -----------------------------------------------------------------------------
# INTEGRAÇÕES EXTERNAS
# -----------------------------------------------------------------------------
INFORMATICA_AXON_ENABLED=false
INFORMATICA_AXON_URL=
INFORMATICA_AXON_TOKEN=

COLLIBRA_ENABLED=false
COLLIBRA_URL=
COLLIBRA_TOKEN=

# -----------------------------------------------------------------------------
# COMPLIANCE E PRIVACIDADE
# -----------------------------------------------------------------------------
GDPR_COMPLIANCE_ENABLED=true
LGPD_COMPLIANCE_ENABLED=true
PII_DETECTION_ENABLED=true
DATA_MASKING_ENABLED=true

# -----------------------------------------------------------------------------
# BACKUP E RETENÇÃO
# -----------------------------------------------------------------------------
BACKUP_ENABLED=true
BACKUP_SCHEDULE=0 2 * * *
RETENTION_DAYS=90
AUDIT_LOG_RETENTION_DAYS=2555  # 7 anos
```

### **Docker Compose Personalizado**
```yaml
# docker-compose.override.yml
version: '3.8'

services:
  api:
    environment:
      - DEBUG=true
      - LOG_LEVEL=DEBUG
    volumes:
      - ./logs:/app/logs
    ports:
      - "8001:8000"  # Porta alternativa

  postgres:
    environment:
      - POSTGRES_DB=governance_dev
    volumes:
      - postgres_dev_data:/var/lib/postgresql/data
    ports:
      - "5433:5432"  # Porta alternativa

volumes:
  postgres_dev_data:
```

---

## 🏗️ **Instalação para Desenvolvimento**

### **1. Ambiente Python Local**
```bash
# Crie um ambiente virtual
python3.10 -m venv venv
source venv/bin/activate  # Linux/Mac
# ou
venv\Scripts\activate     # Windows

# Instale as dependências
pip install -r requirements.txt
pip install -r requirements-dev.txt
```

### **2. Configuração do Banco Local**
```bash
# Inicie apenas o PostgreSQL
docker-compose up -d postgres redis

# Execute as migrações
alembic upgrade head

# Popule dados de exemplo
python scripts/populate_database.py
```

### **3. Execute a API Localmente**
```bash
# Modo desenvolvimento
uvicorn src.app.main:app --reload --host 0.0.0.0 --port 8000

# Com hot reload
python -m src.app.main
```

---

## 🔧 **Configuração de Produção**

### **1. Variáveis de Ambiente de Produção**
```bash
# Segurança
SECRET_KEY=$(openssl rand -hex 32)
DEBUG=false
RELOAD=false

# Performance
API_WORKERS=8
DATABASE_POOL_SIZE=50
DATABASE_MAX_OVERFLOW=100

# Monitoramento
ENABLE_METRICS=true
LOG_LEVEL=WARNING
```

### **2. Docker Compose para Produção**
```yaml
# docker-compose.prod.yml
version: '3.8'

services:
  api:
    image: data-governance-api:latest
    restart: unless-stopped
    environment:
      - DEBUG=false
      - API_WORKERS=8
    deploy:
      replicas: 3
      resources:
        limits:
          cpus: '2'
          memory: 4G
        reservations:
          cpus: '1'
          memory: 2G

  postgres:
    image: postgres:15-alpine
    restart: unless-stopped
    environment:
      - POSTGRES_DB=governance_prod
    volumes:
      - postgres_prod_data:/var/lib/postgresql/data
      - ./backups:/backups
    deploy:
      resources:
        limits:
          cpus: '4'
          memory: 8G

  nginx:
    image: nginx:alpine
    restart: unless-stopped
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf
      - ./ssl:/etc/nginx/ssl
    depends_on:
      - api

volumes:
  postgres_prod_data:
```

### **3. Configuração do Nginx**
```nginx
# nginx.conf
upstream api_backend {
    server api:8000;
}

server {
    listen 80;
    server_name your-domain.com;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name your-domain.com;

    ssl_certificate /etc/nginx/ssl/cert.pem;
    ssl_certificate_key /etc/nginx/ssl/key.pem;

    location / {
        proxy_pass http://api_backend;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    location /health {
        proxy_pass http://api_backend/health;
        access_log off;
    }
}
```

---

## 🐳 **Deployment com Kubernetes**

### **1. Namespace**
```yaml
# k8s/namespace.yaml
apiVersion: v1
kind: Namespace
metadata:
  name: data-governance
```

### **2. ConfigMap**
```yaml
# k8s/configmap.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: governance-config
  namespace: data-governance
data:
  DATABASE_URL: "postgresql://governance:governance123@postgres:5432/governance_db"
  REDIS_URL: "redis://redis:6379/0"
  API_HOST: "0.0.0.0"
  API_PORT: "8000"
  DEBUG: "false"
```

### **3. Deployment**
```yaml
# k8s/deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: governance-api
  namespace: data-governance
spec:
  replicas: 3
  selector:
    matchLabels:
      app: governance-api
  template:
    metadata:
      labels:
        app: governance-api
    spec:
      containers:
      - name: api
        image: data-governance-api:latest
        ports:
        - containerPort: 8000
        envFrom:
        - configMapRef:
            name: governance-config
        resources:
          requests:
            memory: "1Gi"
            cpu: "500m"
          limits:
            memory: "2Gi"
            cpu: "1000m"
        livenessProbe:
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 5
          periodSeconds: 5
```

### **4. Service**
```yaml
# k8s/service.yaml
apiVersion: v1
kind: Service
metadata:
  name: governance-api-service
  namespace: data-governance
spec:
  selector:
    app: governance-api
  ports:
  - protocol: TCP
    port: 80
    targetPort: 8000
  type: LoadBalancer
```

---

## 🔍 **Verificação da Instalação**

### **1. Health Checks**
```bash
# API Health
curl http://localhost:8000/health

# Database Health
curl http://localhost:8000/health/database

# Cache Health
curl http://localhost:8000/health/cache

# Integrations Health
curl http://localhost:8000/health/integrations
```

### **2. Testes de Funcionalidade**
```bash
# Teste de autenticação
curl -X POST http://localhost:8000/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username": "admin", "password": "admin123"}'

# Teste de criação de contrato
curl -X POST http://localhost:8000/api/v1/data-contracts/ \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{"contract_name": "test_contract", "contract_description": "Test"}'

# Teste de listagem
curl http://localhost:8000/api/v1/data-contracts/ \
  -H "Authorization: Bearer <token>"
```

### **3. Monitoramento**
```bash
# Métricas Prometheus
curl http://localhost:9090/metrics

# Logs da aplicação
docker-compose logs -f api

# Status dos containers
docker-compose ps
```

---

## 🛠️ **Troubleshooting**

### **Problemas Comuns**

#### **1. Erro de Conexão com Banco**
```bash
# Verifique se o PostgreSQL está rodando
docker-compose ps postgres

# Verifique os logs
docker-compose logs postgres

# Teste a conexão
docker-compose exec postgres psql -U governance -d governance_db -c "SELECT 1;"
```

#### **2. Erro de Permissões**
```bash
# Ajuste permissões dos volumes
sudo chown -R $USER:$USER ./data
sudo chmod -R 755 ./data

# Recrie os containers
docker-compose down -v
docker-compose up -d --build
```

#### **3. Erro de Memória**
```bash
# Aumente os limites do Docker
# No Docker Desktop: Settings > Resources > Memory > 8GB+

# Ou ajuste o docker-compose.yml
services:
  api:
    deploy:
      resources:
        limits:
          memory: 4G
```

#### **4. Erro de Porta em Uso**
```bash
# Verifique portas em uso
netstat -tulpn | grep :8000

# Mate o processo
sudo kill -9 <PID>

# Ou use porta alternativa
docker-compose up -d -p 8001:8000
```

---

## 📚 **Próximos Passos**

Após a instalação bem-sucedida:

1. **Leia a documentação completa:** `DOCUMENTATION_COMPLETE_CORRECTED.md`
2. **Execute os testes:** `pytest tests/`
3. **Configure integrações:** Unity Catalog, Informatica Axon
4. **Customize para seu ambiente:** Ajuste configurações específicas
5. **Configure monitoramento:** Prometheus, Grafana, Jaeger
6. **Implemente backup:** Configure rotinas de backup automático

---

## 📞 **Suporte**

Para problemas de instalação:
- **Documentação:** Consulte os arquivos de documentação
- **Logs:** Sempre verifique os logs primeiro
- **Issues:** Reporte problemas no repositório
- **Email:** suporte@datagovernance.com

---

**© 2024 Carlos Morais - Data Governance API**

