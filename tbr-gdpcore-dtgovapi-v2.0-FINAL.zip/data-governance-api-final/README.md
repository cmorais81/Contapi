# tbr-gdpcore-dtgovapi

API de Governança de Dados com suporte a Unity Catalog External Lineage

## Visão Geral

O tbr-gdpcore-dtgovapi é uma API completa para governança de dados empresarial, oferecendo suporte a contratos de dados, linhagem, qualidade de dados e integração com Unity Catalog.

### Principais Funcionalidades

- Contratos de dados com versionamento
- Linhagem de dados com suporte a Unity Catalog External Lineage
- Qualidade de dados com regras customizáveis
- Integração com múltiplos sistemas externos
- Segurança RBAC/ABAC granular

## Estrutura do Projeto

```
tbr-gdpcore-dtgovapi/
├── src/                         # Código fonte da aplicação
│   ├── app/
│   │   ├── models/              # Modelos SQLAlchemy
│   │   ├── schemas/             # Schemas Pydantic
│   │   ├── services/            # Lógica de negócio
│   │   ├── endpoints/           # Endpoints FastAPI
│   │   ├── utils/               # Utilitários
│   │   └── integrations/        # Integrações externas
│   └── main.py                  # Aplicação principal
├── tests/                       # Testes automatizados
├── deployment/                  # Arquivos de deploy
│   ├── k8s/                     # Manifests Kubernetes
│   ├── scripts/                 # Scripts de automação
│   └── docker/                  # Arquivos Docker adicionais
├── documentation/               # Documentação
│   └── external/                # Documentação externa
├── .github/                     # Workflows GitHub Actions
├── Dockerfile                   # Dockerfile principal
├── requirements-prod.txt        # Dependências de produção
└── .dockerignore                # Exclusões Docker
```

## Requisitos

- Python 3.11+
- PostgreSQL 15+
- Redis 7+
- Databricks Unity Catalog

## Instalação e Execução

### Desenvolvimento Local

```bash
# Clonar repositório
git clone https://github.com/company/tbr-gdpcore-dtgovapi.git
cd tbr-gdpcore-dtgovapi

# Criar ambiente virtual
python -m venv venv
source venv/bin/activate  # Linux/Mac
# ou
venv\Scripts\activate  # Windows

# Instalar dependências
pip install -r requirements-dev.txt

# Configurar variáveis de ambiente
cp .env.example .env
# Editar .env com suas configurações

# Executar migrações
alembic upgrade head

# Iniciar aplicação
uvicorn src.main:app --reload
```

### Deploy em Kubernetes (AKS)

Consulte a documentação completa em `deployment/MANUAL_DEPLOY_AKS_ATUALIZADO.md`.

```bash
# Deploy usando script automatizado
cd deployment/scripts
./deploy.sh --environment production \
  --namespace tbr-gdpcore-dtgovapi \
  --tag v2.0 \
  --acr your-acr-name \
  --resource-group your-resource-group \
  --cluster your-aks-cluster \
  --keyvault your-keyvault
```

## Documentação

- API Swagger UI: `/docs`
- ReDoc: `/redoc`
- Manual de Deploy: `deployment/MANUAL_DEPLOY_AKS_ATUALIZADO.md`
- Próximos Passos: `deployment/PROXIMOS_PASSOS_1_E_2_ROADMAP.md`

## Licença

Copyright (c) 2025 Company. Todos os direitos reservados.

