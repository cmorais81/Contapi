#!/bin/bash
set -euo pipefail

# tbr-gdpcore-dtgovapi Deploy Script
# Automated deployment script for Azure Kubernetes Service (AKS)

# Script metadata
SCRIPT_NAME="tbr-gdpcore-dtgovapi-deploy"
SCRIPT_VERSION="2.0"
PROJECT_NAME="tbr-gdpcore-dtgovapi"

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1"
}

# Configuration variables with defaults
ENVIRONMENT="${ENVIRONMENT:-production}"
NAMESPACE="${NAMESPACE:-tbr-gdpcore-dtgovapi}"
IMAGE_TAG="${IMAGE_TAG:-latest}"
ACR_NAME="${ACR_NAME:-}"
RESOURCE_GROUP="${RESOURCE_GROUP:-}"
AKS_CLUSTER_NAME="${AKS_CLUSTER_NAME:-}"
KEY_VAULT_NAME="${KEY_VAULT_NAME:-}"
DRY_RUN="${DRY_RUN:-false}"
SKIP_TESTS="${SKIP_TESTS:-false}"
FORCE_DEPLOY="${FORCE_DEPLOY:-false}"

# Derived variables
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
K8S_DIR="$PROJECT_ROOT/k8s"
DOCKER_DIR="$PROJECT_ROOT"

# Help function
show_help() {
    cat << EOF
$SCRIPT_NAME v$SCRIPT_VERSION

USAGE:
    $0 [OPTIONS]

DESCRIPTION:
    Deploy tbr-gdpcore-dtgovapi to Azure Kubernetes Service (AKS)

OPTIONS:
    -e, --environment ENVIRONMENT    Target environment (default: production)
    -n, --namespace NAMESPACE        Kubernetes namespace (default: tbr-gdpcore-dtgovapi)
    -t, --tag IMAGE_TAG             Docker image tag (default: latest)
    -a, --acr ACR_NAME              Azure Container Registry name
    -g, --resource-group RG_NAME    Azure Resource Group name
    -c, --cluster AKS_CLUSTER       AKS cluster name
    -k, --keyvault KEY_VAULT        Azure Key Vault name
    -d, --dry-run                   Perform dry run without actual deployment
    -s, --skip-tests                Skip health checks and validation tests
    -f, --force                     Force deployment even if validation fails
    -h, --help                      Show this help message

EXAMPLES:
    # Basic deployment
    $0 --acr myacr --resource-group myrg --cluster myaks --keyvault mykv

    # Deployment with specific tag
    $0 --tag v2.0.1 --acr myacr --resource-group myrg --cluster myaks --keyvault mykv

    # Dry run deployment
    $0 --dry-run --acr myacr --resource-group myrg --cluster myaks --keyvault mykv

ENVIRONMENT VARIABLES:
    ENVIRONMENT                     Target environment
    NAMESPACE                       Kubernetes namespace
    IMAGE_TAG                       Docker image tag
    ACR_NAME                        Azure Container Registry name
    RESOURCE_GROUP                  Azure Resource Group name
    AKS_CLUSTER_NAME               AKS cluster name
    KEY_VAULT_NAME                 Azure Key Vault name
    DRY_RUN                        Perform dry run (true/false)
    SKIP_TESTS                     Skip tests (true/false)
    FORCE_DEPLOY                   Force deployment (true/false)

EOF
}

# Parse command line arguments
parse_args() {
    while [[ $# -gt 0 ]]; do
        case $1 in
            -e|--environment)
                ENVIRONMENT="$2"
                shift 2
                ;;
            -n|--namespace)
                NAMESPACE="$2"
                shift 2
                ;;
            -t|--tag)
                IMAGE_TAG="$2"
                shift 2
                ;;
            -a|--acr)
                ACR_NAME="$2"
                shift 2
                ;;
            -g|--resource-group)
                RESOURCE_GROUP="$2"
                shift 2
                ;;
            -c|--cluster)
                AKS_CLUSTER_NAME="$2"
                shift 2
                ;;
            -k|--keyvault)
                KEY_VAULT_NAME="$2"
                shift 2
                ;;
            -d|--dry-run)
                DRY_RUN="true"
                shift
                ;;
            -s|--skip-tests)
                SKIP_TESTS="true"
                shift
                ;;
            -f|--force)
                FORCE_DEPLOY="true"
                shift
                ;;
            -h|--help)
                show_help
                exit 0
                ;;
            *)
                log_error "Unknown option: $1"
                show_help
                exit 1
                ;;
        esac
    done
}

# Validation functions
validate_prerequisites() {
    log_info "Validating prerequisites..."
    
    # Check required tools
    local required_tools=("az" "kubectl" "docker" "jq" "yq")
    for tool in "${required_tools[@]}"; do
        if ! command -v "$tool" &> /dev/null; then
            log_error "Required tool '$tool' is not installed"
            exit 1
        fi
    done
    
    # Check required parameters
    if [[ -z "$ACR_NAME" ]]; then
        log_error "Azure Container Registry name is required (--acr)"
        exit 1
    fi
    
    if [[ -z "$RESOURCE_GROUP" ]]; then
        log_error "Resource Group name is required (--resource-group)"
        exit 1
    fi
    
    if [[ -z "$AKS_CLUSTER_NAME" ]]; then
        log_error "AKS cluster name is required (--cluster)"
        exit 1
    fi
    
    if [[ -z "$KEY_VAULT_NAME" ]]; then
        log_error "Key Vault name is required (--keyvault)"
        exit 1
    fi
    
    log_success "Prerequisites validation completed"
}

# Azure authentication and connectivity
validate_azure_connectivity() {
    log_info "Validating Azure connectivity..."
    
    # Check Azure CLI authentication
    if ! az account show &> /dev/null; then
        log_error "Azure CLI is not authenticated. Run 'az login' first."
        exit 1
    fi
    
    # Validate ACR access
    if ! az acr show --name "$ACR_NAME" --resource-group "$RESOURCE_GROUP" &> /dev/null; then
        log_error "Cannot access Azure Container Registry '$ACR_NAME' in resource group '$RESOURCE_GROUP'"
        exit 1
    fi
    
    # Validate AKS access
    if ! az aks show --name "$AKS_CLUSTER_NAME" --resource-group "$RESOURCE_GROUP" &> /dev/null; then
        log_error "Cannot access AKS cluster '$AKS_CLUSTER_NAME' in resource group '$RESOURCE_GROUP'"
        exit 1
    fi
    
    # Validate Key Vault access
    if ! az keyvault show --name "$KEY_VAULT_NAME" --resource-group "$RESOURCE_GROUP" &> /dev/null; then
        log_error "Cannot access Key Vault '$KEY_VAULT_NAME' in resource group '$RESOURCE_GROUP'"
        exit 1
    fi
    
    log_success "Azure connectivity validation completed"
}

# Kubernetes connectivity
validate_kubernetes_connectivity() {
    log_info "Validating Kubernetes connectivity..."
    
    # Get AKS credentials
    az aks get-credentials --name "$AKS_CLUSTER_NAME" --resource-group "$RESOURCE_GROUP" --overwrite-existing
    
    # Test kubectl connectivity
    if ! kubectl cluster-info &> /dev/null; then
        log_error "Cannot connect to Kubernetes cluster"
        exit 1
    fi
    
    # Check cluster health
    local cluster_status
    cluster_status=$(kubectl get nodes --no-headers | awk '{print $2}' | grep -v "Ready" | wc -l)
    if [[ "$cluster_status" -gt 0 ]]; then
        log_warning "Some cluster nodes are not in Ready state"
        kubectl get nodes
    fi
    
    log_success "Kubernetes connectivity validation completed"
}

# Docker image validation
validate_docker_image() {
    log_info "Validating Docker image..."
    
    local image_name="$ACR_NAME.azurecr.io/$PROJECT_NAME:$IMAGE_TAG"
    
    # Login to ACR
    az acr login --name "$ACR_NAME"
    
    # Check if image exists
    if ! az acr repository show --name "$ACR_NAME" --image "$PROJECT_NAME:$IMAGE_TAG" &> /dev/null; then
        log_error "Docker image '$image_name' not found in registry"
        log_info "Available tags:"
        az acr repository show-tags --name "$ACR_NAME" --repository "$PROJECT_NAME" --output table || true
        exit 1
    fi
    
    # Validate image security
    log_info "Scanning image for vulnerabilities..."
    az acr task run --registry "$ACR_NAME" --name "security-scan" --set image="$PROJECT_NAME:$IMAGE_TAG" || log_warning "Security scan failed or not configured"
    
    log_success "Docker image validation completed"
}

# Kubernetes manifests validation
validate_kubernetes_manifests() {
    log_info "Validating Kubernetes manifests..."
    
    # Check if k8s directory exists
    if [[ ! -d "$K8S_DIR" ]]; then
        log_error "Kubernetes manifests directory not found: $K8S_DIR"
        exit 1
    fi
    
    # Validate YAML syntax
    local yaml_files
    yaml_files=$(find "$K8S_DIR" -name "*.yaml" -o -name "*.yml")
    
    for file in $yaml_files; do
        if [[ "$file" == *"secret-template.yaml" ]]; then
            log_info "Skipping secret template file: $file"
            continue
        fi
        
        log_info "Validating YAML syntax: $(basename "$file")"
        if ! yq eval '.' "$file" > /dev/null; then
            log_error "Invalid YAML syntax in file: $file"
            exit 1
        fi
    done
    
    # Dry run kubectl apply
    log_info "Performing dry-run validation of Kubernetes manifests..."
    for file in $yaml_files; do
        if [[ "$file" == *"secret-template.yaml" ]]; then
            continue
        fi
        
        log_info "Dry-run validation: $(basename "$file")"
        if ! kubectl apply --dry-run=client -f "$file" &> /dev/null; then
            log_error "Kubernetes manifest validation failed: $file"
            exit 1
        fi
    done
    
    log_success "Kubernetes manifests validation completed"
}

# Create namespace if it doesn't exist
create_namespace() {
    log_info "Creating namespace if it doesn't exist..."
    
    if kubectl get namespace "$NAMESPACE" &> /dev/null; then
        log_info "Namespace '$NAMESPACE' already exists"
    else
        if [[ "$DRY_RUN" == "true" ]]; then
            log_info "[DRY RUN] Would create namespace: $NAMESPACE"
        else
            kubectl apply -f "$K8S_DIR/namespace.yaml"
            log_success "Namespace '$NAMESPACE' created"
        fi
    fi
}

# Create secrets from Azure Key Vault
create_secrets() {
    log_info "Creating secrets from Azure Key Vault..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would create secrets from Key Vault: $KEY_VAULT_NAME"
        return
    fi
    
    # Install CSI Secret Store driver if not present
    if ! kubectl get csidriver secrets-store.csi.k8s.io &> /dev/null; then
        log_info "Installing CSI Secret Store driver..."
        helm repo add secrets-store-csi-driver https://kubernetes-sigs.github.io/secrets-store-csi-driver/charts
        helm install csi-secrets-store secrets-store-csi-driver/secrets-store-csi-driver --namespace kube-system
    fi
    
    # Install Azure Key Vault provider
    if ! kubectl get daemonset aks-secrets-store-provider-azure -n kube-system &> /dev/null; then
        log_info "Installing Azure Key Vault provider..."
        kubectl apply -f https://raw.githubusercontent.com/Azure/secrets-store-csi-driver-provider-azure/master/deployment/provider-azure-installer.yaml
    fi
    
    # Apply secret provider class
    if [[ -f "$K8S_DIR/secret-template.yaml" ]]; then
        # Extract SecretProviderClass from template
        yq eval 'select(.kind == "SecretProviderClass")' "$K8S_DIR/secret-template.yaml" | kubectl apply -f -
        log_success "SecretProviderClass applied"
    fi
}

# Deploy application
deploy_application() {
    log_info "Deploying application..."
    
    local deployment_files=(
        "namespace.yaml"
        "configmap.yaml"
        "unity-catalog-config.yaml"
        "rbac.yaml"
        "deployment.yaml"
        "service.yaml"
        "ingress.yaml"
        "hpa.yaml"
        "pdb.yaml"
    )
    
    for file in "${deployment_files[@]}"; do
        local file_path="$K8S_DIR/$file"
        
        if [[ ! -f "$file_path" ]]; then
            log_warning "File not found, skipping: $file"
            continue
        fi
        
        log_info "Applying: $file"
        
        if [[ "$DRY_RUN" == "true" ]]; then
            log_info "[DRY RUN] Would apply: $file"
            kubectl apply --dry-run=client -f "$file_path"
        else
            # Update image tag in deployment
            if [[ "$file" == "deployment.yaml" ]]; then
                local temp_file
                temp_file=$(mktemp)
                yq eval ".spec.template.spec.containers[0].image = \"$ACR_NAME.azurecr.io/$PROJECT_NAME:$IMAGE_TAG\"" "$file_path" > "$temp_file"
                kubectl apply -f "$temp_file"
                rm "$temp_file"
            else
                kubectl apply -f "$file_path"
            fi
        fi
    done
    
    if [[ "$DRY_RUN" != "true" ]]; then
        log_success "Application deployment completed"
    else
        log_success "Dry run deployment validation completed"
    fi
}

# Wait for deployment to be ready
wait_for_deployment() {
    if [[ "$DRY_RUN" == "true" ]] || [[ "$SKIP_TESTS" == "true" ]]; then
        return
    fi
    
    log_info "Waiting for deployment to be ready..."
    
    # Wait for deployment rollout
    if ! kubectl rollout status deployment/"$PROJECT_NAME" -n "$NAMESPACE" --timeout=600s; then
        log_error "Deployment rollout failed"
        
        # Show deployment status
        kubectl get deployment "$PROJECT_NAME" -n "$NAMESPACE"
        kubectl describe deployment "$PROJECT_NAME" -n "$NAMESPACE"
        
        # Show pod status
        kubectl get pods -n "$NAMESPACE" -l app="$PROJECT_NAME"
        kubectl describe pods -n "$NAMESPACE" -l app="$PROJECT_NAME"
        
        # Show recent events
        kubectl get events -n "$NAMESPACE" --sort-by='.lastTimestamp' | tail -20
        
        exit 1
    fi
    
    log_success "Deployment is ready"
}

# Health checks
perform_health_checks() {
    if [[ "$DRY_RUN" == "true" ]] || [[ "$SKIP_TESTS" == "true" ]]; then
        return
    fi
    
    log_info "Performing health checks..."
    
    # Get service endpoint
    local service_ip
    service_ip=$(kubectl get service "$PROJECT_NAME" -n "$NAMESPACE" -o jsonpath='{.spec.clusterIP}')
    
    if [[ -z "$service_ip" ]]; then
        log_error "Could not get service IP"
        exit 1
    fi
    
    # Health check endpoint
    local health_url="http://$service_ip/health"
    local max_attempts=30
    local attempt=1
    
    log_info "Testing health endpoint: $health_url"
    
    while [[ $attempt -le $max_attempts ]]; do
        if kubectl run health-check-$RANDOM --rm -i --restart=Never --image=curlimages/curl -- curl -f "$health_url" &> /dev/null; then
            log_success "Health check passed"
            break
        fi
        
        log_info "Health check attempt $attempt/$max_attempts failed, retrying in 10 seconds..."
        sleep 10
        ((attempt++))
    done
    
    if [[ $attempt -gt $max_attempts ]]; then
        log_error "Health checks failed after $max_attempts attempts"
        
        # Show pod logs for debugging
        log_info "Recent pod logs:"
        kubectl logs -n "$NAMESPACE" -l app="$PROJECT_NAME" --tail=50
        
        exit 1
    fi
    
    # API endpoint tests
    log_info "Testing API endpoints..."
    
    local api_endpoints=(
        "/health"
        "/health/ready"
        "/docs"
        "/api/v1/system-types"
    )
    
    for endpoint in "${api_endpoints[@]}"; do
        local endpoint_url="http://$service_ip$endpoint"
        log_info "Testing endpoint: $endpoint"
        
        if ! kubectl run api-test-$RANDOM --rm -i --restart=Never --image=curlimages/curl -- curl -f "$endpoint_url" &> /dev/null; then
            log_warning "Endpoint test failed: $endpoint"
        else
            log_success "Endpoint test passed: $endpoint"
        fi
    done
}

# Cleanup function
cleanup() {
    local exit_code=$?
    
    if [[ $exit_code -ne 0 ]]; then
        log_error "Deployment failed with exit code: $exit_code"
        
        if [[ "$DRY_RUN" != "true" ]] && [[ "$FORCE_DEPLOY" != "true" ]]; then
            log_info "Collecting debugging information..."
            
            # Create debug directory
            local debug_dir="/tmp/tbr-gdpcore-dtgovapi-debug-$(date +%Y%m%d-%H%M%S)"
            mkdir -p "$debug_dir"
            
            # Collect deployment information
            kubectl get all -n "$NAMESPACE" > "$debug_dir/resources.txt" 2>&1
            kubectl describe deployment "$PROJECT_NAME" -n "$NAMESPACE" > "$debug_dir/deployment.txt" 2>&1
            kubectl get events -n "$NAMESPACE" --sort-by='.lastTimestamp' > "$debug_dir/events.txt" 2>&1
            kubectl logs -n "$NAMESPACE" -l app="$PROJECT_NAME" --tail=100 > "$debug_dir/logs.txt" 2>&1
            
            log_info "Debug information saved to: $debug_dir"
        fi
    else
        log_success "Deployment completed successfully"
    fi
    
    exit $exit_code
}

# Main execution function
main() {
    # Set trap for cleanup
    trap cleanup EXIT
    
    log_info "Starting $SCRIPT_NAME v$SCRIPT_VERSION"
    log_info "Project: $PROJECT_NAME"
    log_info "Environment: $ENVIRONMENT"
    log_info "Namespace: $NAMESPACE"
    log_info "Image Tag: $IMAGE_TAG"
    log_info "Dry Run: $DRY_RUN"
    
    # Parse command line arguments
    parse_args "$@"
    
    # Validation phase
    validate_prerequisites
    validate_azure_connectivity
    validate_kubernetes_connectivity
    validate_docker_image
    validate_kubernetes_manifests
    
    # Deployment phase
    create_namespace
    create_secrets
    deploy_application
    wait_for_deployment
    perform_health_checks
    
    log_success "Deployment completed successfully!"
    
    if [[ "$DRY_RUN" != "true" ]]; then
        log_info "Application endpoints:"
        kubectl get ingress -n "$NAMESPACE"
        
        log_info "To check application status:"
        echo "  kubectl get pods -n $NAMESPACE"
        echo "  kubectl logs -n $NAMESPACE -l app=$PROJECT_NAME"
        echo "  kubectl describe deployment $PROJECT_NAME -n $NAMESPACE"
    fi
}

# Execute main function with all arguments
main "$@"

