#!/bin/bash
set -e

# Script de inicialização para tbr-gdpcore-dtgovapi

# Executar migrações do banco de dados
echo "Executando migrações do banco de dados..."
alembic upgrade head

# Inicializar dados necessários
echo "Inicializando dados necessários..."
python -m src.scripts.initialize_data

# Executar comando passado como argumento
echo "Iniciando aplicação..."
exec "$@"

