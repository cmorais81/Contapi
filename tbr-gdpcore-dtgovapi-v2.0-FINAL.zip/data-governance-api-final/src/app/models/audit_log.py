"""
Modelo AuditLog para Data Governance API
Seguindo exatamente o modelo_estendido.dbml original
Autor: Carlos Morais
"""

from sqlalchemy import Boolean, Column, ForeignKey, Integer, Text
from sqlalchemy.dialects.postgresql import JSON, UUID
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship

from .base import BaseEntity


class AuditLog(BaseEntity):
    """
    Trilha de auditoria imutável para todas as alterações do sistema
    """
    
    __tablename__ = "AuditLog"
    
    # Chave primária UUID conforme modelo original
    audit_id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        default=func.gen_random_uuid(),
        nullable=False,
        comment='Identificador único da auditoria'
    )
    
    # Informações da entidade alterada
    entity_name = Column(
        Text,
        nullable=False,
        comment='Nome da entidade que foi alterada'
    )
    
    entity_id = Column(
        UUID(as_uuid=True),
        comment='ID da instância específica da entidade'
    )
    
    entity_type = Column(
        Text,
        comment='Tipo da entidade (contrato, objeto_dados, regra_qualidade, etc.)'
    )
    
    # Detalhes da alteração
    action = Column(
        Text,
        nullable=False,
        comment='Ação realizada (criar, atualizar, deletar, aprovar, rejeitar)'
    )
    
    changed_by = Column(
        UUID(as_uuid=True),
        ForeignKey('Users.user_id'),
        comment='Usuário que fez a alteração'
    )
    
    change_timestamp = Column(
        func.timestamptz(),
        nullable=False,
        default=func.now(),
        comment='Timestamp da alteração'
    )
    
    change_details = Column(
        JSON,
        comment='Informações detalhadas da alteração (valores antes/depois)'
    )
    
    change_reason = Column(
        Text,
        comment='Motivo da alteração'
    )
    
    # Contexto
    session_id = Column(
        UUID(as_uuid=True),
        comment='Identificador da sessão do usuário'
    )
    
    client_ip = Column(
        Text,
        comment='Endereço IP do cliente'
    )
    
    user_agent = Column(
        Text,
        comment='String do user agent'
    )
    
    # Conformidade
    compliance_event = Column(
        Boolean,
        default=False,
        comment='Se este é um evento relevante para conformidade'
    )
    
    retention_period_days = Column(
        Integer,
        comment='Por quanto tempo manter este registro de auditoria'
    )
    
    # Relacionamentos
    user = relationship("Users", back_populates="audit_logs")
    
    def __repr__(self):
        return f"<AuditLog(audit_id={self.audit_id}, entity={self.entity_name}, action={self.action})>"

