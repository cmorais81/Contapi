"""
Modelo UserGroups para Data Governance API
Seguindo exatamente o modelo_estendido.dbml original
Autor: Carlos Morais
"""

from sqlalchemy import Column, ForeignKey, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship

from .base import BaseEntity


class UserGroups(BaseEntity):
    """
    Associação usuário-grupo com funções
    """
    
    __tablename__ = "UserGroups"
    
    # Chave primária composta conforme modelo original
    user_id = Column(
        UUID(as_uuid=True),
        ForeignKey('Users.user_id'),
        primary_key=True,
        nullable=False,
        comment='Referência ao usuário'
    )
    
    group_id = Column(
        UUID(as_uuid=True),
        ForeignKey('Groups.group_id'),
        primary_key=True,
        nullable=False,
        comment='Referência ao grupo'
    )
    
    # Função no grupo
    role_in_group = Column(
        Text,
        comment='Função dentro do grupo (membro, admin, proprietario)'
    )
    
    # Relacionamentos
    user = relationship("Users", back_populates="user_groups")
    group = relationship("Groups", back_populates="user_groups")
    
    def __repr__(self):
        return f"<UserGroups(user_id={self.user_id}, group_id={self.group_id}, role={self.role_in_group})>"

