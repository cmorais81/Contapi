"""
Modelo ContractPricingDefinitions para Data Governance API
Seguindo exatamente o modelo_estendido.dbml original
Autor: Carlos Morais
"""

from sqlalchemy import Column, ForeignKey, Numeric, Text
from sqlalchemy.dialects.postgresql import JSON, UUID
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship

from .base import BaseEntity


class ContractPricingDefinitions(BaseEntity):
    """
    Definições de modelo de precificação para comercialização do contrato de dados
    """
    
    __tablename__ = "ContractPricingDefinitions"
    
    # Chave primária UUID conforme modelo original
    pricing_definition_id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        default=func.gen_random_uuid(),
        nullable=False,
        comment='Identificador único da definição de precificação'
    )
    
    # Relacionamento único com versão
    version_id = Column(
        UUID(as_uuid=True),
        ForeignKey('ContractVersions.version_id'),
        unique=True,
        nullable=False,
        comment='Referência única à versão do contrato'
    )
    
    # Modelo de precificação
    pricing_model_name = Column(
        Text,
        nullable=False,
        comment='Nome do modelo de precificação'
    )
    
    pricing_description = Column(
        Text,
        comment='Descrição detalhada do modelo de precificação'
    )
    
    currency_code = Column(
        Text,
        comment='Código de moeda ISO 4217'
    )
    
    base_price = Column(
        Numeric,
        comment='Preço base para o serviço'
    )
    
    pricing_unit = Column(
        Text,
        comment='Unidade de precificação (por GB, por query, por mês, etc.)'
    )
    
    # Suporte a precificação em camadas
    pricing_tiers = Column(
        JSON,
        comment='Array JSON de camadas de precificação com limites e taxas'
    )
    
    volume_discounts = Column(
        JSON,
        comment='Estrutura de desconto por volume'
    )
    
    # Integração de rastreamento de custos
    cost_center = Column(
        Text,
        comment='Centro de custo para chargeback'
    )
    
    billing_frequency = Column(
        Text,
        comment='Frequência de cobrança (mensal, trimestral, anual)'
    )
    
    # Relacionamentos
    version = relationship("ContractVersions", back_populates="pricing_definition")
    
    def __repr__(self):
        return f"<ContractPricingDefinitions(pricing_definition_id={self.pricing_definition_id}, model={self.pricing_model_name})>"

