"""
Modelo Users para Data Governance API
Seguindo exatamente o modelo_estendido.dbml original
Autor: Carlos Morais
"""

from sqlalchemy import Boolean, Column, ForeignKey, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship

from .base import BaseEntity


class Users(BaseEntity):
    """
    Gerenciamento de usuários com integração da plataforma de dados
    """
    
    __tablename__ = "Users"
    
    # Chave primária UUID conforme modelo original
    user_id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        default=func.gen_random_uuid(),
        nullable=False,
        comment='Identificador único do usuário'
    )
    
    # Informações básicas do usuário
    username = Column(
        Text,
        unique=True,
        nullable=False,
        comment='Nome de usuário'
    )
    
    email = Column(
        Text,
        unique=True,
        comment='Endereço de email'
    )
    
    full_name = Column(
        Text,
        comment='Nome completo'
    )
    
    is_active = Column(
        Boolean,
        default=True,
        comment='Se o usuário está ativo'
    )
    
    # Integração com plataforma
    platform_user_id = Column(
        Text,
        comment='ID do usuário na plataforma de dados'
    )
    
    unity_catalog_principal = Column(
        Text,
        comment='Principal do Unity Catalog'
    )
    
    # Informações do perfil
    department = Column(
        Text,
        comment='Departamento'
    )
    
    job_title = Column(
        Text,
        comment='Cargo'
    )
    
    manager_user_id = Column(
        UUID(as_uuid=True),
        ForeignKey('Users.user_id'),
        comment='Referência do gerente'
    )
    
    # Autenticação
    last_login_timestamp = Column(
        func.timestamptz(),
        comment='Timestamp do último login'
    )
    
    password_last_changed = Column(
        func.timestamptz(),
        comment='Timestamp da última alteração de senha'
    )
    
    # Relacionamentos
    manager = relationship("Users", remote_side=[user_id], back_populates="subordinates")
    subordinates = relationship("Users", back_populates="manager")
    user_groups = relationship("UserGroups", back_populates="user")
    validated_lineages = relationship("DataLineage", back_populates="validator")
    
    def __repr__(self):
        return f"<Users(user_id={self.user_id}, username={self.username})>"

