"""
Modelo ContractQualityDefinitions para Data Governance API
Seguindo exatamente o modelo_estendido.dbml original
Autor: Carlos Morais
"""

from sqlalchemy import Column, ForeignKey, Numeric, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship

from .base import BaseEntity


class ContractQualityDefinitions(BaseEntity):
    """
    Definições de qualidade de nível superior para uma versão do contrato
    """
    
    __tablename__ = "ContractQualityDefinitions"
    
    # Chave primária UUID conforme modelo original
    quality_definition_id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        default=func.gen_random_uuid(),
        nullable=False,
        comment='Identificador único da definição de qualidade'
    )
    
    # Relacionamento único com versão
    version_id = Column(
        UUID(as_uuid=True),
        ForeignKey('ContractVersions.version_id'),
        unique=True,
        nullable=False,
        comment='Referência única à versão do contrato'
    )
    
    # Definições de qualidade
    overall_quality_description = Column(
        Text,
        comment='Descrição geral das expectativas de qualidade'
    )
    
    quality_framework = Column(
        Text,
        comment='Framework de qualidade usado (ISO 25012, DAMA-DMBOK, Customizado)'
    )
    
    quality_dimensions = Column(
        Text,
        comment='Dimensões de qualidade cobertas (Completude, Precisão, Consistência, etc.)'
    )
    
    # Metas de qualidade
    overall_quality_target = Column(
        Numeric,
        comment='Meta geral de qualidade em porcentagem'
    )
    
    minimum_quality_threshold = Column(
        Numeric,
        comment='Limite mínimo aceitável de qualidade'
    )
    
    # Relacionamentos
    version = relationship("ContractVersions", back_populates="quality_definition")
    quality_rules = relationship("QualityRules", back_populates="quality_definition")
    
    def __repr__(self):
        return f"<ContractQualityDefinitions(quality_definition_id={self.quality_definition_id})>"

