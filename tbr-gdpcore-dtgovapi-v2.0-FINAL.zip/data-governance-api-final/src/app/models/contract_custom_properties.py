"""
Modelo ContractCustomProperties para Data Governance API
Seguindo exatamente o modelo_estendido.dbml original
Autor: Carlos Morais
"""

from sqlalchemy import Boolean, Column, ForeignKey, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship

from .base import BaseEntity


class ContractCustomProperties(BaseEntity):
    """
    Propriedades customizadas para flexibilidade e extensibilidade do contrato
    """
    
    __tablename__ = "ContractCustomProperties"
    
    # Chave primária UUID conforme modelo original
    custom_property_id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        default=func.gen_random_uuid(),
        nullable=False,
        comment='Identificador único da propriedade customizada'
    )
    
    # Relacionamento com versão
    version_id = Column(
        UUID(as_uuid=True),
        ForeignKey('ContractVersions.version_id'),
        nullable=False,
        comment='Referência à versão do contrato'
    )
    
    # Propriedade customizada
    property_name = Column(
        Text,
        nullable=False,
        comment='Nome da propriedade customizada (chave)'
    )
    
    property_value = Column(
        Text,
        comment='Valor da propriedade customizada'
    )
    
    property_description = Column(
        Text,
        comment='Descrição opcional da propriedade customizada'
    )
    
    property_type = Column(
        Text,
        comment='Tipo da propriedade (string, number, boolean, json)'
    )
    
    is_searchable = Column(
        Boolean,
        default=False,
        comment='Se a propriedade é pesquisável'
    )
    
    # Relacionamentos
    version = relationship("ContractVersions", back_populates="custom_properties")
    
    def __repr__(self):
        return f"<ContractCustomProperties(custom_property_id={self.custom_property_id}, name={self.property_name})>"

