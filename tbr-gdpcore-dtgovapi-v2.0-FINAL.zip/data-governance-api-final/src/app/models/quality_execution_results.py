"""
Modelo QualityExecutionResults para Data Governance API
Seguindo exatamente o modelo_estendido.dbml original
Autor: Carlos Morais
"""

from sqlalchemy import BigInteger, Column, ForeignKey, Numeric, Text
from sqlalchemy.dialects.postgresql import JSON, UUID
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship

from .base import BaseEntity


class QualityExecutionResults(BaseEntity):
    """
    Resultados históricos de execuções de regras de qualidade com métricas detalhadas
    """
    
    __tablename__ = "QualityExecutionResults"
    
    # Chave primária UUID conforme modelo original
    execution_result_id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        default=func.gen_random_uuid(),
        nullable=False,
        comment='Identificador único do resultado de execução'
    )
    
    # Relacionamento com regra de qualidade
    quality_rule_id = Column(
        UUID(as_uuid=True),
        ForeignKey('QualityRules.quality_rule_id'),
        nullable=False,
        comment='Referência à regra de qualidade'
    )
    
    # Informações da execução
    execution_timestamp = Column(
        func.timestamptz(),
        nullable=False,
        comment='Timestamp da execução'
    )
    
    execution_duration_ms = Column(
        Numeric,
        comment='Duração da execução em milissegundos'
    )
    
    execution_status = Column(
        Text,
        nullable=False,
        comment='Status: sucesso, falhou, timeout, cancelado'
    )
    
    # Resultados da qualidade
    rule_passed = Column(
        Text,
        comment='Se a regra passou (true, false, null para execuções falhadas)'
    )
    
    records_evaluated = Column(
        BigInteger,
        comment='Número de registros avaliados'
    )
    
    records_passed = Column(
        BigInteger,
        comment='Número de registros que passaram na regra'
    )
    
    records_failed = Column(
        BigInteger,
        comment='Número de registros que falharam na regra'
    )
    
    pass_rate_percentage = Column(
        Numeric,
        comment='Taxa de aprovação em porcentagem'
    )
    
    quality_score = Column(
        Numeric,
        comment='Pontuação de qualidade calculada (0-100)'
    )
    
    # Resultados detalhados
    result_details = Column(
        Text,
        comment='Detalhes adicionais sobre o resultado'
    )
    
    sample_failed_records = Column(
        JSON,
        comment='Amostra de registros que falharam para análise'
    )
    
    error_message = Column(
        Text,
        comment='Mensagem de erro se a execução falhou'
    )
    
    # Contexto de execução da plataforma
    cluster_id = Column(
        Text,
        comment='Cluster usado para execução'
    )
    
    job_run_id = Column(
        Text,
        comment='ID da execução do job'
    )
    
    notebook_path = Column(
        Text,
        comment='Caminho do notebook se executado via notebook'
    )
    
    # Relacionamentos
    quality_rule = relationship("QualityRules", back_populates="execution_results")
    
    def __repr__(self):
        return f"<QualityExecutionResults(execution_result_id={self.execution_result_id}, status={self.execution_status})>"

