"""
Modelo ContractVersions para Data Governance API
Seguindo exatamente o modelo_estendido.dbml original
Autor: Carlos Morais
"""

from sqlalchemy import BigInteger, Column, Date, ForeignKey, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship

from .base import BaseEntity


class ContractVersions(BaseEntity):
    """
    Sistema robusto de versionamento para gerenciamento do ciclo de vida do contrato
    """
    
    __tablename__ = "ContractVersions"
    
    # Chave primária UUID conforme modelo original
    version_id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        default=func.gen_random_uuid(),
        nullable=False,
        comment='Identificador único da versão'
    )
    
    # Relacionamento com contrato
    contract_id = Column(
        UUID(as_uuid=True),
        ForeignKey('DataContracts.contract_id'),
        nullable=False,
        comment='Referência ao contrato'
    )
    
    # Informações da versão
    version_tag = Column(
        Text,
        nullable=False,
        comment='Versão semântica (ex: 1.0.0, 2.1-rascunho)'
    )
    
    version_description = Column(
        Text,
        comment='Descrição das alterações da versão ou notas de lançamento'
    )
    
    effective_date = Column(
        Date,
        comment='Data em que esta versão se torna/tornou efetiva'
    )
    
    version_status = Column(
        Text,
        nullable=False,
        comment='Status: rascunho, ativo, depreciado, substituído'
    )
    
    # Integração com Plataforma de Dados
    unity_catalog_version = Column(
        Text,
        comment='Versão do schema do Unity Catalog'
    )
    
    delta_table_version = Column(
        BigInteger,
        comment='Referência da versão da tabela Delta'
    )
    
    iceberg_snapshot_id = Column(
        UUID(as_uuid=True),
        comment='ID do snapshot Iceberg para esta versão'
    )
    
    # Fluxo de aprovação
    approved_by = Column(
        UUID(as_uuid=True),
        comment='Usuário que aprovou esta versão'
    )
    
    approval_timestamp = Column(
        func.timestamptz(),
        comment='Timestamp da aprovação'
    )
    
    approval_notes = Column(
        Text,
        comment='Notas e comentários da aprovação'
    )
    
    # Relacionamentos
    contract = relationship("DataContracts", back_populates="versions")
    
    def __repr__(self):
        return f"<ContractVersions(version_id={self.version_id}, tag={self.version_tag})>"

