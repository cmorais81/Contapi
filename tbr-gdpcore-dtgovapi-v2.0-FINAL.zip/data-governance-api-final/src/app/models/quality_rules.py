"""
Modelo QualityRules para Data Governance API
Seguindo exatamente o modelo_estendido.dbml original
Autor: Carlos Morais
"""

from sqlalchemy import Boolean, Column, ForeignKey, Integer, Numeric, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship

from .base import BaseEntity


class QualityRules(BaseEntity):
    """
    Regras detalhadas de qualidade com integração da plataforma e rastreamento de performance
    """
    
    __tablename__ = "QualityRules"
    
    # Chave primária UUID conforme modelo original
    quality_rule_id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        default=func.gen_random_uuid(),
        nullable=False,
        comment='Identificador único da regra de qualidade'
    )
    
    # Relacionamento com definição de qualidade
    quality_definition_id = Column(
        UUID(as_uuid=True),
        ForeignKey('ContractQualityDefinitions.quality_definition_id'),
        nullable=False,
        comment='Referência à definição de qualidade'
    )
    
    # Identificação da regra
    rule_identifier = Column(
        Text,
        unique=True,
        nullable=False,
        comment='Identificador único da regra dentro do contrato'
    )
    
    rule_name = Column(
        Text,
        nullable=False,
        comment='Nome legível da regra'
    )
    
    rule_description = Column(
        Text,
        nullable=False,
        comment='Descrição da regra de qualidade'
    )
    
    # Dimensões de qualidade
    quality_dimension = Column(
        Text,
        comment='Dimensão de qualidade (Completude, Unicidade, Validade, Precisão, Pontualidade, Consistência)'
    )
    
    rule_category = Column(
        Text,
        comment='Categoria da regra (regra_negocio, regra_tecnica, regra_regulatoria)'
    )
    
    # Implementação
    implementation_logic = Column(
        Text,
        comment='Lógica da regra (cláusula SQL WHERE, regex, função Python)'
    )
    
    implementation_language = Column(
        Text,
        comment='Linguagem de implementação (SQL, Python, Scala, R)'
    )
    
    severity_level = Column(
        Text,
        comment='Severidade se a regra for violada (Crítico, Erro, Aviso, Info)'
    )
    
    expected_outcome = Column(
        Text,
        comment='Resultado esperado ou limite para a regra passar'
    )
    
    # Integração com Plataforma de Dados
    dlt_expectation_name = Column(
        Text,
        comment='Nome da expectativa do Delta Live Tables'
    )
    
    dlt_expectation_type = Column(
        Text,
        comment='Tipo de expectativa DLT (expect, expect_or_drop, expect_or_fail)'
    )
    
    unity_catalog_function_id = Column(
        UUID(as_uuid=True),
        comment='Referência da função do Unity Catalog para regras complexas'
    )
    
    # Configuração de execução
    execution_frequency = Column(
        Text,
        comment='Com que frequência a regra é executada (tempo real, horário, diário)'
    )
    
    execution_timeout_seconds = Column(
        Integer,
        comment='Tempo máximo de execução em segundos'
    )
    
    retry_attempts = Column(
        Integer,
        default=3,
        comment='Número de tentativas de retry em caso de falha'
    )
    
    # Métricas de performance
    avg_execution_time_ms = Column(
        Numeric,
        comment='Tempo médio de execução em milissegundos'
    )
    
    success_rate_percentage = Column(
        Numeric,
        comment='Taxa de sucesso histórica em porcentagem'
    )
    
    last_execution_timestamp = Column(
        func.timestamptz(),
        comment='Timestamp da última execução'
    )
    
    # Status
    is_active = Column(
        Boolean,
        nullable=False,
        default=True,
        comment='Se a regra está ativa'
    )
    
    # Relacionamentos
    quality_definition = relationship("ContractQualityDefinitions", back_populates="quality_rules")
    execution_results = relationship("QualityExecutionResults", back_populates="quality_rule")
    property_links = relationship("PropertyQualityRuleLinks", back_populates="quality_rule")
    
    def __repr__(self):
        return f"<QualityRules(quality_rule_id={self.quality_rule_id}, name={self.rule_name})>"

