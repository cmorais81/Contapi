"""
Modelo Permissions para Data Governance API
Seguindo exatamente o modelo_estendido.dbml original
Autor: Carlos Morais
"""

from sqlalchemy import Column, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship

from .base import BaseEntity


class Permissions(BaseEntity):
    """
    Permissões disponíveis no sistema
    """
    
    __tablename__ = "Permissions"
    
    # Chave primária UUID conforme modelo original
    permission_id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        default=func.gen_random_uuid(),
        nullable=False,
        comment='Identificador único da permissão'
    )
    
    # Informações da permissão
    permission_name = Column(
        Text,
        nullable=False,
        comment='Nome da permissão'
    )
    
    permission_description = Column(
        Text,
        comment='Descrição da permissão'
    )
    
    permission_category = Column(
        Text,
        comment='Categoria da permissão (contrato, dados, admin, qualidade)'
    )
    
    # Relacionamentos
    group_permissions = relationship("GroupPermissions", back_populates="permission")
    
    def __repr__(self):
        return f"<Permissions(permission_id={self.permission_id}, name={self.permission_name})>"

