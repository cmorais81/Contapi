"""
Modelo ContractSLADefinitions para Data Governance API
Seguindo exatamente o modelo_estendido.dbml original
Autor: Carlos Morais
"""

from sqlalchemy import Column, ForeignKey, Numeric, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship

from .base import BaseEntity


class ContractSlaDefinitions(BaseEntity):
    """
    Definições de Acordo de Nível de Serviço com integração de monitoramento
    """
    
    __tablename__ = "ContractSLADefinitions"
    
    # Chave primária UUID conforme modelo original
    sla_definition_id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        default=func.gen_random_uuid(),
        nullable=False,
        comment='Identificador único da definição de SLA'
    )
    
    # Relacionamento com versão
    version_id = Column(
        UUID(as_uuid=True),
        ForeignKey('ContractVersions.version_id'),
        nullable=False,
        comment='Referência à versão do contrato'
    )
    
    # Definição do SLA
    sla_metric_name = Column(
        Text,
        nullable=False,
        comment='Nome da métrica do SLA'
    )
    
    sla_description = Column(
        Text,
        comment='O que este SLA cobre e como é medido'
    )
    
    target_value = Column(
        Text,
        nullable=False,
        comment='Valor alvo ou expressão para o SLA'
    )
    
    measurement_methodology = Column(
        Text,
        comment='Como este SLA é medido'
    )
    
    consequence_of_breach = Column(
        Text,
        comment='Ações ou implicações se o SLA for violado'
    )
    
    # Integração com Plataforma de Dados
    dlt_expectation_id = Column(
        UUID(as_uuid=True),
        comment='Referência da expectativa do Delta Live Tables'
    )
    
    unity_catalog_metric_id = Column(
        UUID(as_uuid=True),
        comment='Referência da métrica do Unity Catalog'
    )
    
    monitoring_query = Column(
        Text,
        comment='Query SQL para monitoramento do SLA'
    )
    
    alert_threshold_warning = Column(
        Numeric,
        comment='Limite de aviso para alertas'
    )
    
    alert_threshold_critical = Column(
        Numeric,
        comment='Limite crítico para alertas'
    )
    
    # Rastreamento de SLA
    measurement_frequency = Column(
        Text,
        comment='Com que frequência o SLA é medido (horário, diário, semanal)'
    )
    
    reporting_frequency = Column(
        Text,
        comment='Com que frequência o SLA é reportado'
    )
    
    escalation_procedure = Column(
        Text,
        comment='Procedimento de escalação para violações de SLA'
    )
    
    # Relacionamentos
    version = relationship("ContractVersions", back_populates="sla_definitions")
    
    def __repr__(self):
        return f"<ContractSLADefinitions(sla_definition_id={self.sla_definition_id}, metric={self.sla_metric_name})>"

