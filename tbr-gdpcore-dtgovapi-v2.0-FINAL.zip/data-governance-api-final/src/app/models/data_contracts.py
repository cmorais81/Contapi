"""
Modelo data_contracts para Data Governance API
Autor: Carlos Morais
"""

from sqlalchemy import Column, String, Text, Boolean
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped
from typing import Optional
import uuid

from .base import BaseEntity


class DataContracts(BaseEntity):
    """
    Modelo para contratos de dados - tabela central do sistema de governança
    """
    __tablename__ = "data_contracts"

    # Campos principais
    contract_id: Mapped[UUID] = Column(
        UUID(as_uuid=True), 
        primary_key=True, 
        default=uuid.uuid4,
        comment="Identificador único do contrato"
    )
    
    contract_name: Mapped[str] = Column(
        String(255), 
        nullable=False, 
        unique=True,
        comment="Nome único do contrato"
    )
    
    contract_description: Mapped[Optional[str]] = Column(
        Text,
        comment="Descrição detalhada do contrato"
    )
    
    contract_owner: Mapped[Optional[str]] = Column(
        String(255),
        comment="Proprietário responsável pelo contrato"
    )
    
    business_domain: Mapped[Optional[str]] = Column(
        String(255),
        comment="Domínio de negócio do contrato"
    )
    
    contract_status: Mapped[Optional[str]] = Column(
        String(50),
        default="draft",
        comment="Status do contrato (draft, active, deprecated, archived)"
    )
    
    # Integração Unity Catalog
    unity_catalog_enabled: Mapped[Optional[bool]] = Column(
        Boolean,
        default=False,
        comment="Indica se o contrato está integrado com Unity Catalog"
    )
    
    unity_catalog_name: Mapped[Optional[str]] = Column(
        String(255),
        comment="Nome do catálogo no Unity Catalog"
    )
    
    unity_catalog_schema: Mapped[Optional[str]] = Column(
        String(255),
        comment="Schema no Unity Catalog"
    )
    
    unity_catalog_table: Mapped[Optional[str]] = Column(
        String(255),
        comment="Tabela no Unity Catalog"
    )
    
    # ABAC (Attribute-Based Access Control)
    abac_enabled: Mapped[Optional[bool]] = Column(
        Boolean,
        default=False,
        comment="Indica se ABAC está habilitado para este contrato"
    )
    
    abac_policy: Mapped[Optional[str]] = Column(
        Text,
        comment="Política ABAC em formato JSON"
    )
    
    # Monitoramento
    monitoring_enabled: Mapped[Optional[bool]] = Column(
        Boolean,
        default=True,
        comment="Indica se o monitoramento está ativo"
    )
    
    monitoring_frequency: Mapped[Optional[str]] = Column(
        String(50),
        default="daily",
        comment="Frequência de monitoramento (hourly, daily, weekly)"
    )

    def __repr__(self) -> str:
        return f"<DataContracts(contract_id={self.contract_id}, name='{self.contract_name}', status='{self.contract_status}')>"

    def to_dict(self) -> dict:
        """Converte o modelo para dicionário"""
        base_dict = super().to_dict()
        base_dict.update({
            "contract_id": str(self.contract_id),
            "contract_name": self.contract_name,
            "contract_description": self.contract_description,
            "contract_owner": self.contract_owner,
            "business_domain": self.business_domain,
            "contract_status": self.contract_status,
            "unity_catalog_enabled": self.unity_catalog_enabled,
            "unity_catalog_name": self.unity_catalog_name,
            "unity_catalog_schema": self.unity_catalog_schema,
            "unity_catalog_table": self.unity_catalog_table,
            "abac_enabled": self.abac_enabled,
            "abac_policy": self.abac_policy,
            "monitoring_enabled": self.monitoring_enabled,
            "monitoring_frequency": self.monitoring_frequency
        })
        return base_dict

