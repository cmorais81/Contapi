"""
Modelo DataClassificationResults para Data Governance API
Seguindo exatamente o modelo_estendido.dbml original
Autor: Carlos Morais
"""

from sqlalchemy import Column, ForeignKey, Integer, Numeric, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship

from .base import BaseEntity


class DataClassificationResults(BaseEntity):
    """
    Resultados de classificação de dados automatizada e manual
    """
    
    __tablename__ = "DataClassificationResults"
    
    # Chave primária UUID conforme modelo original
    classification_id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        default=func.gen_random_uuid(),
        nullable=False,
        comment='Identificador único da classificação'
    )
    
    # Relacionamento com propriedade
    property_id = Column(
        UUID(as_uuid=True),
        ForeignKey('DataObjectProperties.property_id'),
        comment='Propriedade classificada'
    )
    
    # Detalhes da classificação
    classification_type = Column(
        Text,
        nullable=False,
        comment='Tipo: PII, sensivel, publico, confidencial, restrito'
    )
    
    classification_subtype = Column(
        Text,
        comment='Subtipo: email, telefone, cpf, cartao_credito, etc.'
    )
    
    classification_level = Column(
        Text,
        comment='Nível: baixo, medio, alto, critico'
    )
    
    confidence_score = Column(
        Numeric,
        comment='Pontuação de confiança (0-1) para classificações automatizadas'
    )
    
    # Método de detecção
    classification_method = Column(
        Text,
        nullable=False,
        comment='Método: ia_automatizada, manual, baseada_regras, correspondencia_padrao'
    )
    
    detection_algorithm = Column(
        Text,
        comment='Algoritmo específico usado para detecção'
    )
    
    # Validação e aprovação
    classification_timestamp = Column(
        func.timestamptz(),
        nullable=False,
        comment='Timestamp da classificação'
    )
    
    validated_by = Column(
        UUID(as_uuid=True),
        ForeignKey('Users.user_id'),
        comment='Usuário que validou a classificação'
    )
    
    validation_timestamp = Column(
        func.timestamptz(),
        comment='Timestamp da validação'
    )
    
    validation_status = Column(
        Text,
        comment='Status: pendente, aprovado, rejeitado, precisa_revisao'
    )
    
    # Conformidade regulatória
    regulatory_framework = Column(
        Text,
        comment='Framework: GDPR, LGPD, HIPAA, PCI_DSS, SOX'
    )
    
    compliance_requirements = Column(
        Text,
        comment='Requisitos específicos de conformidade'
    )
    
    retention_period_days = Column(
        Integer,
        comment='Período de retenção obrigatório'
    )
    
    # Raciocínio da classificação
    classification_rationale = Column(
        Text,
        comment='Raciocínio para a decisão de classificação'
    )
    
    sample_data_patterns = Column(
        Text,
        comment='Padrões de amostra que acionaram a classificação'
    )
    
    # Relacionamentos
    property = relationship("DataObjectProperties", back_populates="classification_results")
    validator = relationship("Users", back_populates="classification_validations")
    
    def __repr__(self):
        return f"<DataClassificationResults(classification_id={self.classification_id}, type={self.classification_type})>"

