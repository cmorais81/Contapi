"""
Modelo JobMetrics para Data Governance API
Seguindo exatamente o modelo_estendido.dbml original
Autor: Carlos Morais
"""

from sqlalchemy import BigInteger, Column, ForeignKey, Integer, Numeric, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship

from .base import BaseEntity


class JobMetrics(BaseEntity):
    """
    Métricas detalhadas de execução de job para análise de performance
    """
    
    __tablename__ = "JobMetrics"
    
    # Chave primária composta conforme modelo original
    job_id = Column(
        Text,
        primary_key=True,
        nullable=False,
        comment='Identificador do job da plataforma'
    )
    
    job_run_id = Column(
        Text,
        primary_key=True,
        nullable=False,
        comment='Identificador específico da execução do job'
    )
    
    # Informações do job
    job_name = Column(
        Text,
        nullable=False,
        comment='Nome do job'
    )
    
    contract_id = Column(
        UUID(as_uuid=True),
        ForeignKey('DataContracts.contract_id'),
        comment='Contrato de dados associado'
    )
    
    quality_rule_id = Column(
        UUID(as_uuid=True),
        ForeignKey('QualityRules.quality_rule_id'),
        comment='Regra de qualidade associada se aplicável'
    )
    
    # Métricas de execução
    execution_start_time = Column(
        func.timestamptz(),
        nullable=False,
        comment='Timestamp de início da execução'
    )
    
    execution_end_time = Column(
        func.timestamptz(),
        comment='Timestamp de fim da execução (nulo se ainda estiver executando)'
    )
    
    execution_duration_seconds = Column(
        Numeric,
        comment='Duração total da execução'
    )
    
    execution_status = Column(
        Text,
        nullable=False,
        comment='Status: executando, sucesso, falhou, cancelado'
    )
    
    # Métricas de nível de tarefa
    tasks_total = Column(
        Integer,
        comment='Número total de tarefas'
    )
    
    tasks_successful = Column(
        Integer,
        comment='Número de tarefas bem-sucedidas'
    )
    
    tasks_failed = Column(
        Integer,
        comment='Número de tarefas que falharam'
    )
    
    tasks_skipped = Column(
        Integer,
        comment='Número de tarefas puladas'
    )
    
    # Métricas de processamento de dados
    input_data_size_bytes = Column(
        BigInteger,
        comment='Tamanho dos dados de entrada em bytes'
    )
    
    output_data_size_bytes = Column(
        BigInteger,
        comment='Tamanho dos dados de saída em bytes'
    )
    
    shuffle_data_size_bytes = Column(
        BigInteger,
        comment='Tamanho dos dados de shuffle em bytes'
    )
    
    peak_memory_usage_bytes = Column(
        BigInteger,
        comment='Pico de uso de memória'
    )
    
    # Detalhes de erro
    error_message = Column(
        Text,
        comment='Mensagem de erro se falhou'
    )
    
    error_stack_trace = Column(
        Text,
        comment='Stack trace completo do erro'
    )
    
    # Relacionamentos
    contract = relationship("DataContracts", back_populates="job_metrics")
    quality_rule = relationship("QualityRules", back_populates="job_metrics")
    
    def __repr__(self):
        return f"<JobMetrics(job_id={self.job_id}, run_id={self.job_run_id})>"

