"""
Validadores para Data Governance API
Autor: Carlos Morais

Módulo com validadores para diferentes tipos de dados,
schemas, contratos e regras de negócio.
"""

import re
import json
import uuid
from typing import Any, Dict, List, Optional, Union
from datetime import datetime
from email_validator import validate_email as email_validate, EmailNotValidError
import jsonschema
from jsonschema import ValidationError as JsonSchemaValidationError

from .exceptions import ValidationError


def validate_email(email: str) -> bool:
    """
    Valida formato de email
    
    Args:
        email: Email para validar
        
    Returns:
        True se válido
        
    Raises:
        ValidationError: Se email inválido
    """
    try:
        email_validate(email)
        return True
    except EmailNotValidError as e:
        raise ValidationError(f"Email inválido: {str(e)}")


def validate_uuid(uuid_string: str) -> bool:
    """
    Valida formato UUID
    
    Args:
        uuid_string: String UUID para validar
        
    Returns:
        True se válido
        
    Raises:
        ValidationError: Se UUID inválido
    """
    try:
        uuid.UUID(uuid_string)
        return True
    except ValueError:
        raise ValidationError(f"UUID inválido: {uuid_string}")


def validate_json_schema(data: Dict[str, Any], schema: Dict[str, Any]) -> bool:
    """
    Valida dados contra schema JSON
    
    Args:
        data: Dados para validar
        schema: Schema JSON
        
    Returns:
        True se válido
        
    Raises:
        ValidationError: Se dados não atendem schema
    """
    try:
        jsonschema.validate(data, schema)
        return True
    except JsonSchemaValidationError as e:
        raise ValidationError(f"Schema inválido: {str(e)}")


def validate_data_contract(contract_data: Dict[str, Any]) -> bool:
    """
    Valida dados de contrato de dados
    
    Args:
        contract_data: Dados do contrato
        
    Returns:
        True se válido
        
    Raises:
        ValidationError: Se contrato inválido
    """
    required_fields = [
        "contract_name",
        "data_product_name", 
        "data_product_owner",
        "data_product_domain"
    ]
    
    # Verificar campos obrigatórios
    for field in required_fields:
        if field not in contract_data or not contract_data[field]:
            raise ValidationError(f"Campo obrigatório ausente: {field}")
    
    # Validar email do owner
    validate_email(contract_data["data_product_owner"])
    
    # Validar status se presente
    if "contract_status" in contract_data:
        valid_statuses = ["rascunho", "ativo", "depreciado", "inativo"]
        if contract_data["contract_status"] not in valid_statuses:
            raise ValidationError(f"Status inválido: {contract_data['contract_status']}")
    
    # Validar nome do contrato
    if not re.match(r"^[a-zA-Z0-9_\-\s]+$", contract_data["contract_name"]):
        raise ValidationError("Nome do contrato contém caracteres inválidos")
    
    return True


def validate_lineage_path(lineage_data: Dict[str, Any]) -> bool:
    """
    Valida dados de lineage
    
    Args:
        lineage_data: Dados de lineage
        
    Returns:
        True se válido
        
    Raises:
        ValidationError: Se lineage inválido
    """
    required_fields = ["source_name", "target_name", "transformation_type"]
    
    for field in required_fields:
        if field not in lineage_data or not lineage_data[field]:
            raise ValidationError(f"Campo obrigatório ausente: {field}")
    
    # Validar confidence score
    if "confidence_score" in lineage_data:
        score = lineage_data["confidence_score"]
        if not isinstance(score, (int, float)) or score < 0 or score > 100:
            raise ValidationError("Confidence score deve ser entre 0 e 100")
    
    # Validar tipo de transformação
    valid_types = ["direct", "transformation", "aggregation", "join", "filter"]
    if lineage_data["transformation_type"] not in valid_types:
        raise ValidationError(f"Tipo de transformação inválido: {lineage_data['transformation_type']}")
    
    return True


def validate_quality_rule(rule_data: Dict[str, Any]) -> bool:
    """
    Valida regra de qualidade
    
    Args:
        rule_data: Dados da regra
        
    Returns:
        True se válido
        
    Raises:
        ValidationError: Se regra inválida
    """
    required_fields = ["rule_name", "rule_type", "rule_expression"]
    
    for field in required_fields:
        if field not in rule_data or not rule_data[field]:
            raise ValidationError(f"Campo obrigatório ausente: {field}")
    
    # Validar tipo de regra
    valid_types = ["completeness", "uniqueness", "validity", "consistency", "accuracy"]
    if rule_data["rule_type"] not in valid_types:
        raise ValidationError(f"Tipo de regra inválido: {rule_data['rule_type']}")
    
    # Validar threshold se presente
    if "threshold_value" in rule_data:
        threshold = rule_data["threshold_value"]
        if not isinstance(threshold, (int, float)) or threshold < 0 or threshold > 100:
            raise ValidationError("Threshold deve ser entre 0 e 100")
    
    return True


def validate_alert_definition(alert_data: Dict[str, Any]) -> bool:
    """
    Valida definição de alerta
    
    Args:
        alert_data: Dados do alerta
        
    Returns:
        True se válido
        
    Raises:
        ValidationError: Se alerta inválido
    """
    required_fields = ["alert_name", "alert_type", "threshold_value"]
    
    for field in required_fields:
        if field not in alert_data or alert_data[field] is None:
            raise ValidationError(f"Campo obrigatório ausente: {field}")
    
    # Validar tipo de alerta
    valid_types = ["quality", "performance", "security", "compliance", "system"]
    if alert_data["alert_type"] not in valid_types:
        raise ValidationError(f"Tipo de alerta inválido: {alert_data['alert_type']}")
    
    # Validar severidade se presente
    if "severity" in alert_data:
        valid_severities = ["LOW", "MEDIUM", "HIGH", "CRITICAL"]
        if alert_data["severity"] not in valid_severities:
            raise ValidationError(f"Severidade inválida: {alert_data['severity']}")
    
    return True


def validate_user_data(user_data: Dict[str, Any]) -> bool:
    """
    Valida dados de usuário
    
    Args:
        user_data: Dados do usuário
        
    Returns:
        True se válido
        
    Raises:
        ValidationError: Se dados inválidos
    """
    required_fields = ["username", "email", "full_name"]
    
    for field in required_fields:
        if field not in user_data or not user_data[field]:
            raise ValidationError(f"Campo obrigatório ausente: {field}")
    
    # Validar email
    validate_email(user_data["email"])
    
    # Validar username
    if not re.match(r"^[a-zA-Z0-9_\-\.]+$", user_data["username"]):
        raise ValidationError("Username contém caracteres inválidos")
    
    # Validar senha se presente
    if "password" in user_data:
        password = user_data["password"]
        if len(password) < 8:
            raise ValidationError("Senha deve ter pelo menos 8 caracteres")
        if not re.search(r"[A-Z]", password):
            raise ValidationError("Senha deve conter pelo menos uma letra maiúscula")
        if not re.search(r"[a-z]", password):
            raise ValidationError("Senha deve conter pelo menos uma letra minúscula")
        if not re.search(r"\d", password):
            raise ValidationError("Senha deve conter pelo menos um número")
    
    return True


def validate_permission_data(permission_data: Dict[str, Any]) -> bool:
    """
    Valida dados de permissão
    
    Args:
        permission_data: Dados da permissão
        
    Returns:
        True se válido
        
    Raises:
        ValidationError: Se permissão inválida
    """
    required_fields = ["permission_name", "resource_type", "action"]
    
    for field in required_fields:
        if field not in permission_data or not permission_data[field]:
            raise ValidationError(f"Campo obrigatório ausente: {field}")
    
    # Validar tipo de recurso
    valid_resources = ["contract", "data_object", "lineage", "alert", "user", "group"]
    if permission_data["resource_type"] not in valid_resources:
        raise ValidationError(f"Tipo de recurso inválido: {permission_data['resource_type']}")
    
    # Validar ação
    valid_actions = ["create", "read", "update", "delete", "execute", "approve"]
    if permission_data["action"] not in valid_actions:
        raise ValidationError(f"Ação inválida: {permission_data['action']}")
    
    # Validar nível de segurança se presente
    if "security_level" in permission_data:
        valid_levels = ["LOW", "STANDARD", "HIGH", "CRITICAL"]
        if permission_data["security_level"] not in valid_levels:
            raise ValidationError(f"Nível de segurança inválido: {permission_data['security_level']}")
    
    return True


def validate_data_policy(policy_data: Dict[str, Any]) -> bool:
    """
    Valida política de dados
    
    Args:
        policy_data: Dados da política
        
    Returns:
        True se válido
        
    Raises:
        ValidationError: Se política inválida
    """
    required_fields = ["policy_name", "policy_type", "policy_rules"]
    
    for field in required_fields:
        if field not in policy_data or not policy_data[field]:
            raise ValidationError(f"Campo obrigatório ausente: {field}")
    
    # Validar tipo de política
    valid_types = ["retention", "access", "quality", "privacy", "security"]
    if policy_data["policy_type"] not in valid_types:
        raise ValidationError(f"Tipo de política inválido: {policy_data['policy_type']}")
    
    # Validar regras da política
    if not isinstance(policy_data["policy_rules"], list):
        raise ValidationError("Regras da política devem ser uma lista")
    
    return True


def validate_datetime_range(start_date: str, end_date: str) -> bool:
    """
    Valida range de datas
    
    Args:
        start_date: Data inicial (ISO format)
        end_date: Data final (ISO format)
        
    Returns:
        True se válido
        
    Raises:
        ValidationError: Se range inválido
    """
    try:
        start = datetime.fromisoformat(start_date.replace('Z', '+00:00'))
        end = datetime.fromisoformat(end_date.replace('Z', '+00:00'))
        
        if start >= end:
            raise ValidationError("Data inicial deve ser anterior à data final")
        
        return True
    except ValueError as e:
        raise ValidationError(f"Formato de data inválido: {str(e)}")


def validate_sql_query(query: str) -> bool:
    """
    Valida query SQL básica (verificações de segurança)
    
    Args:
        query: Query SQL
        
    Returns:
        True se válido
        
    Raises:
        ValidationError: Se query insegura
    """
    # Palavras-chave perigosas
    dangerous_keywords = [
        "DROP", "DELETE", "UPDATE", "INSERT", "ALTER", "CREATE",
        "TRUNCATE", "EXEC", "EXECUTE", "GRANT", "REVOKE"
    ]
    
    query_upper = query.upper()
    
    for keyword in dangerous_keywords:
        if keyword in query_upper:
            raise ValidationError(f"Query contém palavra-chave não permitida: {keyword}")
    
    # Verificar se é uma query SELECT
    if not query_upper.strip().startswith("SELECT"):
        raise ValidationError("Apenas queries SELECT são permitidas")
    
    return True


def validate_file_upload(file_data: Dict[str, Any]) -> bool:
    """
    Valida dados de upload de arquivo
    
    Args:
        file_data: Dados do arquivo
        
    Returns:
        True se válido
        
    Raises:
        ValidationError: Se arquivo inválido
    """
    required_fields = ["filename", "content_type", "size"]
    
    for field in required_fields:
        if field not in file_data:
            raise ValidationError(f"Campo obrigatório ausente: {field}")
    
    # Validar extensão do arquivo
    allowed_extensions = [".csv", ".json", ".yaml", ".yml", ".sql", ".txt"]
    filename = file_data["filename"].lower()
    
    if not any(filename.endswith(ext) for ext in allowed_extensions):
        raise ValidationError(f"Extensão de arquivo não permitida: {filename}")
    
    # Validar tamanho (máximo 10MB)
    max_size = 10 * 1024 * 1024  # 10MB
    if file_data["size"] > max_size:
        raise ValidationError(f"Arquivo muito grande: {file_data['size']} bytes (máximo: {max_size})")
    
    return True

