"""
Sistema de Análises e Relatórios
Autor: Carlos Morais

Sistema completo para geração de análises, relatórios
e dashboards de governança de dados.
"""

import json
import statistics
from typing import Any, Dict, List, Optional, Union, Tuple
from enum import Enum
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta
from collections import defaultdict, Counter
import uuid

from .exceptions import DataGovernanceException
from .observability import record_business_metric, trace_operation


class ReportType(Enum):
    """Tipos de relatórios"""
    EXECUTIVE_SUMMARY = "executive_summary"
    TECHNICAL_DETAIL = "technical_detail"
    COMPLIANCE_REPORT = "compliance_report"
    QUALITY_ASSESSMENT = "quality_assessment"
    LINEAGE_ANALYSIS = "lineage_analysis"
    USAGE_ANALYTICS = "usage_analytics"
    TREND_ANALYSIS = "trend_analysis"
    RISK_ASSESSMENT = "risk_assessment"


class DashboardType(Enum):
    """Tipos de dashboards"""
    EXECUTIVE = "executive"
    OPERATIONAL = "operational"
    TECHNICAL = "technical"
    COMPLIANCE = "compliance"
    QUALITY = "quality"
    LINEAGE = "lineage"
    USAGE = "usage"


class MetricCategory(Enum):
    """Categorias de métricas"""
    GOVERNANCE = "governance"
    QUALITY = "quality"
    COMPLIANCE = "compliance"
    USAGE = "usage"
    PERFORMANCE = "performance"
    RISK = "risk"
    BUSINESS = "business"


@dataclass
class KPI:
    """Indicador chave de performance"""
    id: str
    name: str
    description: str
    category: MetricCategory
    current_value: float
    target_value: float
    unit: str
    trend: str  # "up", "down", "stable"
    trend_percentage: float
    status: str  # "excellent", "good", "warning", "critical"
    last_updated: datetime
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte para dicionário"""
        data = asdict(self)
        data['category'] = self.category.value
        data['last_updated'] = self.last_updated.isoformat()
        return data


@dataclass
class ChartData:
    """Dados para gráficos"""
    chart_type: str  # "line", "bar", "pie", "scatter", "heatmap"
    title: str
    x_axis: Dict[str, Any]
    y_axis: Dict[str, Any]
    data: List[Dict[str, Any]]
    metadata: Dict[str, Any]
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte para dicionário"""
        return asdict(self)


class AnalyticsEngine:
    """Engine de análises de governança"""
    
    def __init__(self):
        self.kpi_definitions = self._initialize_kpis()
        self.report_templates = self._initialize_report_templates()
    
    def _initialize_kpis(self) -> Dict[str, Dict[str, Any]]:
        """Inicializa definições de KPIs"""
        return {
            "data_quality_score": {
                "name": "Score de Qualidade de Dados",
                "description": "Score médio de qualidade de dados",
                "category": MetricCategory.QUALITY,
                "target": 95.0,
                "unit": "%"
            },
            "contract_compliance": {
                "name": "Compliance de Contratos",
                "description": "Percentual de contratos em compliance",
                "category": MetricCategory.COMPLIANCE,
                "target": 98.0,
                "unit": "%"
            },
            "data_coverage": {
                "name": "Cobertura de Dados",
                "description": "Percentual de dados cobertos por contratos",
                "category": MetricCategory.GOVERNANCE,
                "target": 90.0,
                "unit": "%"
            },
            "policy_violations": {
                "name": "Violações de Política",
                "description": "Número de violações de política por mês",
                "category": MetricCategory.RISK,
                "target": 5.0,
                "unit": "count"
            },
            "lineage_coverage": {
                "name": "Cobertura de Linhagem",
                "description": "Percentual de objetos com linhagem mapeada",
                "category": MetricCategory.GOVERNANCE,
                "target": 85.0,
                "unit": "%"
            },
            "api_performance": {
                "name": "Performance da API",
                "description": "Tempo médio de resposta da API",
                "category": MetricCategory.PERFORMANCE,
                "target": 200.0,
                "unit": "ms"
            },
            "user_adoption": {
                "name": "Adoção de Usuários",
                "description": "Número de usuários ativos mensais",
                "category": MetricCategory.USAGE,
                "target": 100.0,
                "unit": "users"
            },
            "data_freshness": {
                "name": "Frescor dos Dados",
                "description": "Idade média dos dados em horas",
                "category": MetricCategory.QUALITY,
                "target": 24.0,
                "unit": "hours"
            }
        }
    
    def _initialize_report_templates(self) -> Dict[str, Dict[str, Any]]:
        """Inicializa templates de relatórios"""
        return {
            ReportType.EXECUTIVE_SUMMARY.value: {
                "sections": [
                    "overview",
                    "key_metrics",
                    "trends",
                    "risks",
                    "recommendations"
                ],
                "kpis": [
                    "data_quality_score",
                    "contract_compliance",
                    "data_coverage",
                    "policy_violations"
                ]
            },
            ReportType.TECHNICAL_DETAIL.value: {
                "sections": [
                    "system_overview",
                    "performance_metrics",
                    "quality_details",
                    "lineage_analysis",
                    "technical_issues"
                ],
                "kpis": [
                    "api_performance",
                    "lineage_coverage",
                    "data_freshness",
                    "user_adoption"
                ]
            },
            ReportType.COMPLIANCE_REPORT.value: {
                "sections": [
                    "compliance_overview",
                    "policy_status",
                    "violations",
                    "remediation",
                    "certification"
                ],
                "kpis": [
                    "contract_compliance",
                    "policy_violations"
                ]
            }
        }
    
    @trace_operation("analytics.calculate_kpis", "analytics")
    def calculate_kpis(self, 
                      period_start: datetime,
                      period_end: datetime,
                      kpi_ids: Optional[List[str]] = None) -> List[KPI]:
        """
        Calcula KPIs para período especificado
        
        Args:
            period_start: Início do período
            period_end: Fim do período
            kpi_ids: IDs específicos de KPIs (todos se None)
            
        Returns:
            Lista de KPIs calculados
        """
        if kpi_ids is None:
            kpi_ids = list(self.kpi_definitions.keys())
        
        kpis = []
        
        for kpi_id in kpi_ids:
            kpi_def = self.kpi_definitions.get(kpi_id)
            if not kpi_def:
                continue
            
            # Calcular valor atual do KPI
            current_value = self._calculate_kpi_value(kpi_id, period_start, period_end)
            
            # Calcular tendência
            previous_period_start = period_start - (period_end - period_start)
            previous_value = self._calculate_kpi_value(kpi_id, previous_period_start, period_start)
            
            trend, trend_percentage = self._calculate_trend(current_value, previous_value)
            
            # Determinar status
            status = self._determine_kpi_status(current_value, kpi_def["target"], kpi_def["unit"])
            
            kpi = KPI(
                id=kpi_id,
                name=kpi_def["name"],
                description=kpi_def["description"],
                category=kpi_def["category"],
                current_value=current_value,
                target_value=kpi_def["target"],
                unit=kpi_def["unit"],
                trend=trend,
                trend_percentage=trend_percentage,
                status=status,
                last_updated=datetime.utcnow()
            )
            
            kpis.append(kpi)
            
            # Registrar métrica de negócio
            record_business_metric(
                f"kpi_{kpi_id}",
                current_value,
                tags={"category": kpi_def["category"].value}
            )
        
        return kpis
    
    def _calculate_kpi_value(self, kpi_id: str, start_date: datetime, end_date: datetime) -> float:
        """Calcula valor de KPI específico"""
        # Simulação de cálculos - em produção, seria baseado em dados reais
        
        if kpi_id == "data_quality_score":
            # Simular score de qualidade baseado em regras executadas
            return 87.3 + (hash(str(start_date)) % 10) / 10
        
        elif kpi_id == "contract_compliance":
            # Simular compliance de contratos
            return 94.2 + (hash(str(start_date)) % 8) / 10
        
        elif kpi_id == "data_coverage":
            # Simular cobertura de dados
            return 82.1 + (hash(str(start_date)) % 15) / 10
        
        elif kpi_id == "policy_violations":
            # Simular violações de política
            return max(0, 8 - (hash(str(start_date)) % 6))
        
        elif kpi_id == "lineage_coverage":
            # Simular cobertura de linhagem
            return 78.5 + (hash(str(start_date)) % 12) / 10
        
        elif kpi_id == "api_performance":
            # Simular performance da API
            return 180 + (hash(str(start_date)) % 40)
        
        elif kpi_id == "user_adoption":
            # Simular adoção de usuários
            return 85 + (hash(str(start_date)) % 30)
        
        elif kpi_id == "data_freshness":
            # Simular frescor dos dados
            return 18 + (hash(str(start_date)) % 12)
        
        return 0.0
    
    def _calculate_trend(self, current: float, previous: float) -> Tuple[str, float]:
        """Calcula tendência e percentual de mudança"""
        if previous == 0:
            return "stable", 0.0
        
        change_percentage = ((current - previous) / previous) * 100
        
        if abs(change_percentage) < 2:
            return "stable", change_percentage
        elif change_percentage > 0:
            return "up", change_percentage
        else:
            return "down", change_percentage
    
    def _determine_kpi_status(self, current: float, target: float, unit: str) -> str:
        """Determina status do KPI baseado no valor atual vs target"""
        if unit == "count" and target < current:
            # Para métricas onde menor é melhor (ex: violações)
            ratio = target / current if current > 0 else 1
        else:
            # Para métricas onde maior é melhor
            ratio = current / target if target > 0 else 1
        
        if ratio >= 0.95:
            return "excellent"
        elif ratio >= 0.85:
            return "good"
        elif ratio >= 0.70:
            return "warning"
        else:
            return "critical"
    
    @trace_operation("analytics.generate_report", "analytics")
    def generate_report(self, 
                       report_type: ReportType,
                       period_start: datetime,
                       period_end: datetime,
                       audience: str = "technical") -> Dict[str, Any]:
        """
        Gera relatório específico
        
        Args:
            report_type: Tipo do relatório
            period_start: Início do período
            period_end: Fim do período
            audience: Público-alvo (executive, technical, operational)
            
        Returns:
            Relatório gerado
        """
        template = self.report_templates.get(report_type.value)
        if not template:
            raise DataGovernanceException(f"Template não encontrado para: {report_type.value}")
        
        # Calcular KPIs relevantes
        kpis = self.calculate_kpis(period_start, period_end, template["kpis"])
        
        # Gerar seções do relatório
        sections = {}
        for section_name in template["sections"]:
            sections[section_name] = self._generate_report_section(
                section_name, kpis, period_start, period_end, audience
            )
        
        report = {
            "id": str(uuid.uuid4()),
            "type": report_type.value,
            "title": self._get_report_title(report_type, audience),
            "period": {
                "start": period_start.isoformat(),
                "end": period_end.isoformat()
            },
            "audience": audience,
            "generated_at": datetime.utcnow().isoformat(),
            "kpis": [kpi.to_dict() for kpi in kpis],
            "sections": sections,
            "summary": self._generate_report_summary(kpis, audience)
        }
        
        return report
    
    def _generate_report_section(self, 
                                section_name: str,
                                kpis: List[KPI],
                                period_start: datetime,
                                period_end: datetime,
                                audience: str) -> Dict[str, Any]:
        """Gera seção específica do relatório"""
        
        if section_name == "overview":
            return self._generate_overview_section(kpis, audience)
        elif section_name == "key_metrics":
            return self._generate_key_metrics_section(kpis)
        elif section_name == "trends":
            return self._generate_trends_section(kpis, period_start, period_end)
        elif section_name == "risks":
            return self._generate_risks_section(kpis)
        elif section_name == "recommendations":
            return self._generate_recommendations_section(kpis, audience)
        elif section_name == "system_overview":
            return self._generate_system_overview_section()
        elif section_name == "performance_metrics":
            return self._generate_performance_section(kpis)
        elif section_name == "quality_details":
            return self._generate_quality_details_section(kpis)
        elif section_name == "lineage_analysis":
            return self._generate_lineage_analysis_section()
        elif section_name == "technical_issues":
            return self._generate_technical_issues_section()
        elif section_name == "compliance_overview":
            return self._generate_compliance_overview_section(kpis)
        elif section_name == "policy_status":
            return self._generate_policy_status_section()
        elif section_name == "violations":
            return self._generate_violations_section()
        elif section_name == "remediation":
            return self._generate_remediation_section()
        elif section_name == "certification":
            return self._generate_certification_section()
        
        return {"content": f"Seção {section_name} não implementada"}
    
    def _generate_overview_section(self, kpis: List[KPI], audience: str) -> Dict[str, Any]:
        """Gera seção de overview"""
        if audience == "executive":
            content = """
            ## Resumo Executivo de Governança de Dados
            
            Nossa plataforma de governança de dados demonstra excelente performance no período analisado, 
            com indicadores-chave mantendo-se dentro dos targets estabelecidos. A qualidade dos dados 
            permanece em níveis elevados, e a adoção da plataforma continua crescendo consistentemente.
            
            ### Destaques do Período:
            - Qualidade de dados mantida acima de 85%
            - Compliance de contratos em níveis excelentes
            - Redução significativa em violações de política
            - Crescimento na adoção por usuários finais
            """
        else:
            content = """
            ## Visão Técnica da Governança
            
            A infraestrutura de governança de dados está operando com alta disponibilidade e performance 
            otimizada. Os sistemas de monitoramento indicam estabilidade operacional, com métricas de 
            qualidade e compliance dentro dos parâmetros esperados.
            
            ### Aspectos Técnicos:
            - APIs respondendo dentro do SLA estabelecido
            - Cobertura de linhagem expandindo gradualmente
            - Processos de qualidade executando conforme programado
            - Integração com Unity Catalog funcionando adequadamente
            """
        
        # Calcular estatísticas gerais
        total_kpis = len(kpis)
        excellent_kpis = len([k for k in kpis if k.status == "excellent"])
        critical_kpis = len([k for k in kpis if k.status == "critical"])
        
        return {
            "content": content.strip(),
            "statistics": {
                "total_kpis": total_kpis,
                "excellent_kpis": excellent_kpis,
                "critical_kpis": critical_kpis,
                "health_score": (excellent_kpis / total_kpis * 100) if total_kpis > 0 else 0
            }
        }
    
    def _generate_key_metrics_section(self, kpis: List[KPI]) -> Dict[str, Any]:
        """Gera seção de métricas-chave"""
        metrics_by_category = defaultdict(list)
        
        for kpi in kpis:
            metrics_by_category[kpi.category.value].append({
                "name": kpi.name,
                "current": kpi.current_value,
                "target": kpi.target_value,
                "unit": kpi.unit,
                "status": kpi.status,
                "trend": kpi.trend,
                "trend_percentage": kpi.trend_percentage
            })
        
        return {
            "content": "Métricas organizadas por categoria de governança",
            "metrics_by_category": dict(metrics_by_category),
            "summary": {
                "total_metrics": len(kpis),
                "categories": len(metrics_by_category)
            }
        }
    
    def _generate_trends_section(self, kpis: List[KPI], start: datetime, end: datetime) -> Dict[str, Any]:
        """Gera seção de tendências"""
        # Simular dados históricos para gráficos de tendência
        trend_data = []
        
        for kpi in kpis[:4]:  # Top 4 KPIs para tendências
            historical_data = []
            current_date = start
            
            while current_date <= end:
                value = self._calculate_kpi_value(kpi.id, current_date, current_date + timedelta(days=1))
                historical_data.append({
                    "date": current_date.isoformat(),
                    "value": value
                })
                current_date += timedelta(days=7)  # Dados semanais
            
            trend_data.append({
                "kpi_name": kpi.name,
                "kpi_id": kpi.id,
                "data": historical_data,
                "trend": kpi.trend,
                "trend_percentage": kpi.trend_percentage
            })
        
        return {
            "content": "Análise de tendências dos principais indicadores",
            "trend_data": trend_data,
            "insights": [
                "Qualidade de dados mostra tendência de melhoria consistente",
                "Compliance mantém-se estável em níveis elevados",
                "Adoção de usuários apresenta crescimento acelerado",
                "Performance da API permanece dentro do SLA"
            ]
        }
    
    def _generate_risks_section(self, kpis: List[KPI]) -> Dict[str, Any]:
        """Gera seção de riscos"""
        risks = []
        
        # Identificar riscos baseados nos KPIs
        for kpi in kpis:
            if kpi.status == "critical":
                risks.append({
                    "level": "high",
                    "category": kpi.category.value,
                    "description": f"{kpi.name} está em nível crítico ({kpi.current_value} {kpi.unit})",
                    "impact": "Alto impacto na governança de dados",
                    "mitigation": f"Implementar ações corretivas para atingir target de {kpi.target_value} {kpi.unit}"
                })
            elif kpi.status == "warning":
                risks.append({
                    "level": "medium",
                    "category": kpi.category.value,
                    "description": f"{kpi.name} requer atenção ({kpi.current_value} {kpi.unit})",
                    "impact": "Impacto moderado se não corrigido",
                    "mitigation": f"Monitorar de perto e implementar melhorias graduais"
                })
        
        # Adicionar riscos operacionais
        operational_risks = [
            {
                "level": "medium",
                "category": "operational",
                "description": "Dependência de sistemas externos pode afetar disponibilidade",
                "impact": "Possível interrupção temporária de serviços",
                "mitigation": "Implementar redundância e planos de contingência"
            },
            {
                "level": "low",
                "category": "security",
                "description": "Acesso a dados sensíveis requer monitoramento contínuo",
                "impact": "Risco de exposição de dados pessoais",
                "mitigation": "Manter políticas de acesso atualizadas e auditoria regular"
            }
        ]
        
        risks.extend(operational_risks)
        
        return {
            "content": "Avaliação de riscos identificados na governança de dados",
            "risks": risks,
            "risk_summary": {
                "high": len([r for r in risks if r["level"] == "high"]),
                "medium": len([r for r in risks if r["level"] == "medium"]),
                "low": len([r for r in risks if r["level"] == "low"])
            }
        }
    
    def _generate_recommendations_section(self, kpis: List[KPI], audience: str) -> Dict[str, Any]:
        """Gera seção de recomendações"""
        recommendations = []
        
        # Recomendações baseadas em KPIs
        for kpi in kpis:
            if kpi.status in ["critical", "warning"]:
                if audience == "executive":
                    recommendations.append({
                        "priority": "high" if kpi.status == "critical" else "medium",
                        "category": "strategic",
                        "title": f"Melhorar {kpi.name}",
                        "description": f"Investir em iniciativas para elevar {kpi.name} aos níveis target",
                        "expected_impact": "Melhoria na governança geral e redução de riscos",
                        "timeline": "3-6 meses"
                    })
                else:
                    recommendations.append({
                        "priority": "high" if kpi.status == "critical" else "medium",
                        "category": "technical",
                        "title": f"Otimizar {kpi.name}",
                        "description": f"Implementar melhorias técnicas para {kpi.name}",
                        "expected_impact": "Melhoria operacional e performance",
                        "timeline": "1-3 meses"
                    })
        
        # Recomendações gerais
        general_recommendations = [
            {
                "priority": "medium",
                "category": "process",
                "title": "Automatizar Processos de Qualidade",
                "description": "Implementar automação adicional nos processos de verificação de qualidade",
                "expected_impact": "Redução de esforço manual e maior consistência",
                "timeline": "2-4 meses"
            },
            {
                "priority": "low",
                "category": "training",
                "title": "Programa de Capacitação",
                "description": "Desenvolver programa de treinamento para usuários finais",
                "expected_impact": "Maior adoção e uso efetivo da plataforma",
                "timeline": "Contínuo"
            }
        ]
        
        recommendations.extend(general_recommendations)
        
        return {
            "content": "Recomendações para melhoria contínua da governança",
            "recommendations": recommendations,
            "summary": {
                "total": len(recommendations),
                "high_priority": len([r for r in recommendations if r["priority"] == "high"]),
                "categories": list(set(r["category"] for r in recommendations))
            }
        }
    
    def _get_report_title(self, report_type: ReportType, audience: str) -> str:
        """Gera título do relatório"""
        titles = {
            ReportType.EXECUTIVE_SUMMARY.value: {
                "executive": "Relatório Executivo de Governança de Dados",
                "technical": "Resumo Técnico de Governança de Dados",
                "operational": "Resumo Operacional de Governança de Dados"
            },
            ReportType.TECHNICAL_DETAIL.value: {
                "executive": "Detalhes Técnicos para Executivos",
                "technical": "Relatório Técnico Detalhado",
                "operational": "Detalhes Técnicos Operacionais"
            },
            ReportType.COMPLIANCE_REPORT.value: {
                "executive": "Relatório de Compliance Executivo",
                "technical": "Relatório de Compliance Técnico",
                "operational": "Relatório de Compliance Operacional"
            }
        }
        
        return titles.get(report_type.value, {}).get(audience, f"Relatório de {report_type.value}")
    
    def _generate_report_summary(self, kpis: List[KPI], audience: str) -> Dict[str, Any]:
        """Gera resumo do relatório"""
        # Calcular estatísticas gerais
        total_kpis = len(kpis)
        excellent_count = len([k for k in kpis if k.status == "excellent"])
        good_count = len([k for k in kpis if k.status == "good"])
        warning_count = len([k for k in kpis if k.status == "warning"])
        critical_count = len([k for k in kpis if k.status == "critical"])
        
        # Calcular score geral
        status_scores = {"excellent": 100, "good": 80, "warning": 60, "critical": 20}
        total_score = sum(status_scores[kpi.status] for kpi in kpis)
        average_score = total_score / total_kpis if total_kpis > 0 else 0
        
        # Determinar status geral
        if average_score >= 90:
            overall_status = "excellent"
        elif average_score >= 75:
            overall_status = "good"
        elif average_score >= 60:
            overall_status = "warning"
        else:
            overall_status = "critical"
        
        # Gerar insights baseados no público
        if audience == "executive":
            key_insights = [
                f"Score geral de governança: {average_score:.1f}/100",
                f"{excellent_count} de {total_kpis} métricas em nível excelente",
                f"Áreas que requerem atenção: {warning_count + critical_count}",
                "Investimento em qualidade de dados mostra retorno positivo"
            ]
        else:
            key_insights = [
                f"Performance técnica: {average_score:.1f}/100",
                f"Métricas críticas: {critical_count}",
                f"Métricas em alerta: {warning_count}",
                "Sistemas operando dentro dos parâmetros esperados"
            ]
        
        return {
            "overall_status": overall_status,
            "overall_score": average_score,
            "kpi_distribution": {
                "excellent": excellent_count,
                "good": good_count,
                "warning": warning_count,
                "critical": critical_count
            },
            "key_insights": key_insights,
            "next_actions": self._generate_next_actions(kpis, audience)
        }
    
    def _generate_next_actions(self, kpis: List[KPI], audience: str) -> List[str]:
        """Gera próximas ações recomendadas"""
        actions = []
        
        critical_kpis = [k for k in kpis if k.status == "critical"]
        warning_kpis = [k for k in kpis if k.status == "warning"]
        
        if critical_kpis:
            if audience == "executive":
                actions.append(f"Priorizar resolução de {len(critical_kpis)} métricas críticas")
            else:
                actions.append(f"Implementar correções para {len(critical_kpis)} KPIs críticos")
        
        if warning_kpis:
            actions.append(f"Monitorar {len(warning_kpis)} métricas em estado de alerta")
        
        # Ações gerais
        if audience == "executive":
            actions.extend([
                "Revisar investimentos em governança de dados",
                "Avaliar ROI das iniciativas de qualidade",
                "Considerar expansão da cobertura de dados"
            ])
        else:
            actions.extend([
                "Executar manutenção preventiva dos sistemas",
                "Atualizar documentação técnica",
                "Revisar configurações de monitoramento"
            ])
        
        return actions[:5]  # Limitar a 5 ações
    
    # Métodos auxiliares para seções específicas
    def _generate_system_overview_section(self) -> Dict[str, Any]:
        """Gera overview do sistema"""
        return {
            "content": "Visão geral da arquitetura e componentes do sistema",
            "components": {
                "api_gateway": {"status": "healthy", "uptime": "99.9%"},
                "database": {"status": "healthy", "connections": 45},
                "cache": {"status": "healthy", "hit_rate": "85.2%"},
                "background_jobs": {"status": "healthy", "queue_size": 8}
            }
        }
    
    def _generate_performance_section(self, kpis: List[KPI]) -> Dict[str, Any]:
        """Gera seção de performance"""
        perf_kpis = [k for k in kpis if k.category == MetricCategory.PERFORMANCE]
        return {
            "content": "Métricas de performance do sistema",
            "performance_kpis": [k.to_dict() for k in perf_kpis]
        }
    
    def _generate_quality_details_section(self, kpis: List[KPI]) -> Dict[str, Any]:
        """Gera detalhes de qualidade"""
        quality_kpis = [k for k in kpis if k.category == MetricCategory.QUALITY]
        return {
            "content": "Análise detalhada da qualidade de dados",
            "quality_kpis": [k.to_dict() for k in quality_kpis],
            "quality_rules": {
                "total_rules": 156,
                "active_rules": 142,
                "passing_rules": 134,
                "failing_rules": 8
            }
        }
    
    def _generate_lineage_analysis_section(self) -> Dict[str, Any]:
        """Gera análise de linhagem"""
        return {
            "content": "Análise da cobertura e qualidade da linhagem de dados",
            "lineage_stats": {
                "total_objects": 2847,
                "mapped_objects": 2234,
                "coverage_percentage": 78.5,
                "orphaned_objects": 23,
                "circular_dependencies": 0
            }
        }
    
    def _generate_technical_issues_section(self) -> Dict[str, Any]:
        """Gera seção de issues técnicos"""
        return {
            "content": "Issues técnicos identificados e status de resolução",
            "issues": [
                {
                    "id": "TECH-001",
                    "severity": "medium",
                    "description": "Latência elevada em queries complexas",
                    "status": "in_progress",
                    "assigned_to": "team_performance"
                },
                {
                    "id": "TECH-002",
                    "severity": "low",
                    "description": "Cache miss rate acima do esperado",
                    "status": "investigating",
                    "assigned_to": "team_infrastructure"
                }
            ]
        }
    
    def _generate_compliance_overview_section(self, kpis: List[KPI]) -> Dict[str, Any]:
        """Gera overview de compliance"""
        compliance_kpis = [k for k in kpis if k.category == MetricCategory.COMPLIANCE]
        return {
            "content": "Visão geral do status de compliance",
            "compliance_kpis": [k.to_dict() for k in compliance_kpis],
            "regulations": {
                "lgpd": {"status": "compliant", "score": 94.2},
                "gdpr": {"status": "compliant", "score": 92.8},
                "sox": {"status": "compliant", "score": 96.1}
            }
        }
    
    def _generate_policy_status_section(self) -> Dict[str, Any]:
        """Gera status de políticas"""
        return {
            "content": "Status das políticas de governança",
            "policies": {
                "total_policies": 45,
                "active_policies": 42,
                "pending_review": 3,
                "violations_this_month": 8
            }
        }
    
    def _generate_violations_section(self) -> Dict[str, Any]:
        """Gera seção de violações"""
        return {
            "content": "Análise de violações de políticas",
            "violations": [
                {
                    "policy": "Data Retention Policy",
                    "count": 3,
                    "severity": "medium",
                    "trend": "decreasing"
                },
                {
                    "policy": "Access Control Policy",
                    "count": 2,
                    "severity": "high",
                    "trend": "stable"
                }
            ]
        }
    
    def _generate_remediation_section(self) -> Dict[str, Any]:
        """Gera seção de remediação"""
        return {
            "content": "Planos de remediação para violações",
            "remediation_plans": [
                {
                    "violation_type": "data_retention",
                    "action": "Automated data purging",
                    "timeline": "2 weeks",
                    "responsible": "Data Engineering Team"
                }
            ]
        }
    
    def _generate_certification_section(self) -> Dict[str, Any]:
        """Gera seção de certificação"""
        return {
            "content": "Status de certificações e auditorias",
            "certifications": {
                "iso_27001": {"status": "certified", "expires": "2024-12-31"},
                "soc2": {"status": "in_progress", "expected": "2024-06-30"}
            }
        }


class DashboardGenerator:
    """Gerador de dashboards interativos"""
    
    def __init__(self, analytics_engine: AnalyticsEngine):
        self.analytics_engine = analytics_engine
    
    @trace_operation("dashboard.generate", "analytics")
    def generate_dashboard(self, 
                          dashboard_type: DashboardType,
                          period_start: datetime,
                          period_end: datetime) -> Dict[str, Any]:
        """
        Gera dashboard específico
        
        Args:
            dashboard_type: Tipo do dashboard
            period_start: Início do período
            period_end: Fim do período
            
        Returns:
            Dashboard gerado
        """
        # Calcular KPIs relevantes
        kpis = self.analytics_engine.calculate_kpis(period_start, period_end)
        
        # Gerar widgets baseados no tipo
        widgets = self._generate_widgets(dashboard_type, kpis, period_start, period_end)
        
        dashboard = {
            "id": str(uuid.uuid4()),
            "type": dashboard_type.value,
            "title": self._get_dashboard_title(dashboard_type),
            "period": {
                "start": period_start.isoformat(),
                "end": period_end.isoformat()
            },
            "generated_at": datetime.utcnow().isoformat(),
            "widgets": widgets,
            "layout": self._get_dashboard_layout(dashboard_type),
            "refresh_interval": 300  # 5 minutos
        }
        
        return dashboard
    
    def _generate_widgets(self, 
                         dashboard_type: DashboardType,
                         kpis: List[KPI],
                         period_start: datetime,
                         period_end: datetime) -> List[Dict[str, Any]]:
        """Gera widgets para o dashboard"""
        widgets = []
        
        if dashboard_type == DashboardType.EXECUTIVE:
            widgets.extend(self._generate_executive_widgets(kpis))
        elif dashboard_type == DashboardType.OPERATIONAL:
            widgets.extend(self._generate_operational_widgets(kpis))
        elif dashboard_type == DashboardType.TECHNICAL:
            widgets.extend(self._generate_technical_widgets(kpis))
        elif dashboard_type == DashboardType.QUALITY:
            widgets.extend(self._generate_quality_widgets(kpis))
        elif dashboard_type == DashboardType.COMPLIANCE:
            widgets.extend(self._generate_compliance_widgets(kpis))
        
        return widgets
    
    def _generate_executive_widgets(self, kpis: List[KPI]) -> List[Dict[str, Any]]:
        """Gera widgets para dashboard executivo"""
        widgets = []
        
        # Widget de score geral
        overall_score = sum(self._kpi_to_score(kpi) for kpi in kpis) / len(kpis) if kpis else 0
        widgets.append({
            "id": "overall_score",
            "type": "scorecard",
            "title": "Score Geral de Governança",
            "value": overall_score,
            "unit": "/100",
            "status": self._score_to_status(overall_score),
            "size": "large"
        })
        
        # Widgets de KPIs principais
        main_kpis = ["data_quality_score", "contract_compliance", "data_coverage"]
        for kpi in kpis:
            if kpi.id in main_kpis:
                widgets.append({
                    "id": f"kpi_{kpi.id}",
                    "type": "metric",
                    "title": kpi.name,
                    "value": kpi.current_value,
                    "unit": kpi.unit,
                    "target": kpi.target_value,
                    "trend": kpi.trend,
                    "trend_percentage": kpi.trend_percentage,
                    "status": kpi.status,
                    "size": "medium"
                })
        
        # Gráfico de tendências
        widgets.append({
            "id": "trends_chart",
            "type": "line_chart",
            "title": "Tendências dos KPIs Principais",
            "chart_data": self._generate_trends_chart_data(kpis[:4]),
            "size": "large"
        })
        
        # Widget de riscos
        risk_count = len([k for k in kpis if k.status in ["warning", "critical"]])
        widgets.append({
            "id": "risk_summary",
            "type": "alert",
            "title": "Resumo de Riscos",
            "value": risk_count,
            "unit": "riscos identificados",
            "severity": "high" if risk_count > 3 else "medium" if risk_count > 0 else "low",
            "size": "medium"
        })
        
        return widgets
    
    def _generate_operational_widgets(self, kpis: List[KPI]) -> List[Dict[str, Any]]:
        """Gera widgets para dashboard operacional"""
        widgets = []
        
        # Status dos sistemas
        widgets.append({
            "id": "system_status",
            "type": "status_grid",
            "title": "Status dos Sistemas",
            "data": {
                "API Gateway": "healthy",
                "Database": "healthy", 
                "Cache": "healthy",
                "Background Jobs": "warning"
            },
            "size": "medium"
        })
        
        # Métricas de performance
        perf_kpis = [k for k in kpis if k.category == MetricCategory.PERFORMANCE]
        for kpi in perf_kpis:
            widgets.append({
                "id": f"perf_{kpi.id}",
                "type": "gauge",
                "title": kpi.name,
                "value": kpi.current_value,
                "unit": kpi.unit,
                "min": 0,
                "max": kpi.target_value * 2,
                "threshold": kpi.target_value,
                "size": "small"
            })
        
        # Gráfico de volume de dados
        widgets.append({
            "id": "data_volume",
            "type": "bar_chart",
            "title": "Volume de Dados Processados",
            "chart_data": self._generate_volume_chart_data(),
            "size": "large"
        })
        
        return widgets
    
    def _generate_technical_widgets(self, kpis: List[KPI]) -> List[Dict[str, Any]]:
        """Gera widgets para dashboard técnico"""
        widgets = []
        
        # Métricas de API
        widgets.append({
            "id": "api_metrics",
            "type": "metrics_grid",
            "title": "Métricas da API",
            "data": {
                "Requests/min": 245,
                "Avg Response Time": "185ms",
                "Error Rate": "0.8%",
                "Uptime": "99.9%"
            },
            "size": "large"
        })
        
        # Gráfico de performance
        widgets.append({
            "id": "performance_chart",
            "type": "area_chart",
            "title": "Performance ao Longo do Tempo",
            "chart_data": self._generate_performance_chart_data(),
            "size": "large"
        })
        
        # Logs recentes
        widgets.append({
            "id": "recent_logs",
            "type": "log_viewer",
            "title": "Logs Recentes",
            "data": [
                {"timestamp": "2024-01-15T10:30:00Z", "level": "INFO", "message": "Quality rule executed successfully"},
                {"timestamp": "2024-01-15T10:25:00Z", "level": "WARN", "message": "Cache miss rate above threshold"},
                {"timestamp": "2024-01-15T10:20:00Z", "level": "INFO", "message": "Data contract validated"}
            ],
            "size": "medium"
        })
        
        return widgets
    
    def _generate_quality_widgets(self, kpis: List[KPI]) -> List[Dict[str, Any]]:
        """Gera widgets para dashboard de qualidade"""
        widgets = []
        
        # Score de qualidade geral
        quality_kpis = [k for k in kpis if k.category == MetricCategory.QUALITY]
        avg_quality = sum(k.current_value for k in quality_kpis) / len(quality_kpis) if quality_kpis else 0
        
        widgets.append({
            "id": "quality_score",
            "type": "donut_chart",
            "title": "Score de Qualidade Geral",
            "value": avg_quality,
            "unit": "%",
            "chart_data": {
                "passed": avg_quality,
                "failed": 100 - avg_quality
            },
            "size": "medium"
        })
        
        # Regras de qualidade
        widgets.append({
            "id": "quality_rules",
            "type": "table",
            "title": "Status das Regras de Qualidade",
            "data": [
                {"rule": "Completeness Check", "status": "passing", "score": 94.2},
                {"rule": "Uniqueness Check", "status": "passing", "score": 98.1},
                {"rule": "Format Validation", "status": "warning", "score": 87.3},
                {"rule": "Range Check", "status": "passing", "score": 95.7}
            ],
            "size": "large"
        })
        
        return widgets
    
    def _generate_compliance_widgets(self, kpis: List[KPI]) -> List[Dict[str, Any]]:
        """Gera widgets para dashboard de compliance"""
        widgets = []
        
        # Status de compliance por regulamentação
        widgets.append({
            "id": "compliance_status",
            "type": "compliance_grid",
            "title": "Status de Compliance",
            "data": {
                "LGPD": {"status": "compliant", "score": 94.2},
                "GDPR": {"status": "compliant", "score": 92.8},
                "SOX": {"status": "compliant", "score": 96.1},
                "HIPAA": {"status": "partial", "score": 78.5}
            },
            "size": "large"
        })
        
        # Violações recentes
        widgets.append({
            "id": "recent_violations",
            "type": "alert_list",
            "title": "Violações Recentes",
            "data": [
                {"policy": "Data Retention", "severity": "medium", "count": 3},
                {"policy": "Access Control", "severity": "high", "count": 1},
                {"policy": "Data Classification", "severity": "low", "count": 5}
            ],
            "size": "medium"
        })
        
        return widgets
    
    def _kpi_to_score(self, kpi: KPI) -> float:
        """Converte KPI para score 0-100"""
        if kpi.unit == "count" and kpi.target_value < kpi.current_value:
            # Para métricas onde menor é melhor
            return max(0, 100 - (kpi.current_value - kpi.target_value) * 10)
        else:
            # Para métricas onde maior é melhor
            return min(100, (kpi.current_value / kpi.target_value) * 100) if kpi.target_value > 0 else 0
    
    def _score_to_status(self, score: float) -> str:
        """Converte score para status"""
        if score >= 90:
            return "excellent"
        elif score >= 80:
            return "good"
        elif score >= 60:
            return "warning"
        else:
            return "critical"
    
    def _generate_trends_chart_data(self, kpis: List[KPI]) -> Dict[str, Any]:
        """Gera dados para gráfico de tendências"""
        # Simular dados históricos
        dates = [(datetime.utcnow() - timedelta(days=i)).strftime("%Y-%m-%d") for i in range(30, 0, -1)]
        
        series = []
        for kpi in kpis:
            data_points = []
            for i, date in enumerate(dates):
                # Simular variação baseada na tendência
                base_value = kpi.current_value
                variation = (hash(f"{kpi.id}_{i}") % 20 - 10) / 100 * base_value
                data_points.append(base_value + variation)
            
            series.append({
                "name": kpi.name,
                "data": data_points
            })
        
        return {
            "categories": dates,
            "series": series
        }
    
    def _generate_volume_chart_data(self) -> Dict[str, Any]:
        """Gera dados para gráfico de volume"""
        categories = ["Contratos", "Objetos", "Regras", "Usuários"]
        data = [145, 2847, 156, 89]
        
        return {
            "categories": categories,
            "series": [{"name": "Volume", "data": data}]
        }
    
    def _generate_performance_chart_data(self) -> Dict[str, Any]:
        """Gera dados para gráfico de performance"""
        hours = [f"{i:02d}:00" for i in range(24)]
        response_times = [180 + (hash(f"perf_{i}") % 40) for i in range(24)]
        
        return {
            "categories": hours,
            "series": [{"name": "Response Time (ms)", "data": response_times}]
        }
    
    def _get_dashboard_title(self, dashboard_type: DashboardType) -> str:
        """Obtém título do dashboard"""
        titles = {
            DashboardType.EXECUTIVE: "Dashboard Executivo de Governança",
            DashboardType.OPERATIONAL: "Dashboard Operacional",
            DashboardType.TECHNICAL: "Dashboard Técnico",
            DashboardType.QUALITY: "Dashboard de Qualidade de Dados",
            DashboardType.COMPLIANCE: "Dashboard de Compliance",
            DashboardType.LINEAGE: "Dashboard de Linhagem",
            DashboardType.USAGE: "Dashboard de Uso"
        }
        return titles.get(dashboard_type, f"Dashboard {dashboard_type.value}")
    
    def _get_dashboard_layout(self, dashboard_type: DashboardType) -> Dict[str, Any]:
        """Obtém layout do dashboard"""
        if dashboard_type == DashboardType.EXECUTIVE:
            return {
                "columns": 12,
                "rows": 8,
                "widget_positions": {
                    "overall_score": {"x": 0, "y": 0, "w": 4, "h": 2},
                    "trends_chart": {"x": 4, "y": 0, "w": 8, "h": 4},
                    "kpi_data_quality_score": {"x": 0, "y": 2, "w": 2, "h": 2},
                    "kpi_contract_compliance": {"x": 2, "y": 2, "w": 2, "h": 2},
                    "risk_summary": {"x": 0, "y": 4, "w": 4, "h": 2}
                }
            }
        else:
            return {
                "columns": 12,
                "rows": 6,
                "auto_layout": True
            }


# Instâncias globais
analytics_engine = AnalyticsEngine()
dashboard_generator = DashboardGenerator(analytics_engine)


# Funções de conveniência
def generate_executive_report(period_start: datetime, period_end: datetime) -> Dict[str, Any]:
    """
    Gera relatório executivo
    
    Args:
        period_start: Início do período
        period_end: Fim do período
        
    Returns:
        Relatório executivo
    """
    return analytics_engine.generate_report(
        ReportType.EXECUTIVE_SUMMARY,
        period_start,
        period_end,
        "executive"
    )


def generate_technical_report(period_start: datetime, period_end: datetime) -> Dict[str, Any]:
    """
    Gera relatório técnico
    
    Args:
        period_start: Início do período
        period_end: Fim do período
        
    Returns:
        Relatório técnico
    """
    return analytics_engine.generate_report(
        ReportType.TECHNICAL_DETAIL,
        period_start,
        period_end,
        "technical"
    )


def generate_executive_dashboard(period_start: datetime, period_end: datetime) -> Dict[str, Any]:
    """
    Gera dashboard executivo
    
    Args:
        period_start: Início do período
        period_end: Fim do período
        
    Returns:
        Dashboard executivo
    """
    return dashboard_generator.generate_dashboard(
        DashboardType.EXECUTIVE,
        period_start,
        period_end
    )


def calculate_governance_kpis(period_start: datetime, period_end: datetime) -> List[KPI]:
    """
    Calcula KPIs de governança
    
    Args:
        period_start: Início do período
        period_end: Fim do período
        
    Returns:
        Lista de KPIs
    """
    return analytics_engine.calculate_kpis(period_start, period_end)

