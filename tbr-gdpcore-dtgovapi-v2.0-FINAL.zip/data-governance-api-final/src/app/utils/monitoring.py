"""
Monitoramento para Data Governance API
Autor: Carlos Morais

Módulo com funcionalidades de monitoramento, métricas,
alertas e observabilidade da aplicação.
"""

import time
import psutil
import logging
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Callable
from functools import wraps
from collections import defaultdict, deque
import threading
import json

from .exceptions import PerformanceError


class MetricsCollector:
    """Coletor de métricas da aplicação"""
    
    def __init__(self):
        self.metrics = defaultdict(list)
        self.counters = defaultdict(int)
        self.gauges = defaultdict(float)
        self.histograms = defaultdict(lambda: deque(maxlen=1000))
        self._lock = threading.Lock()
    
    def increment_counter(self, name: str, value: int = 1, tags: Dict[str, str] = None):
        """
        Incrementa contador
        
        Args:
            name: Nome da métrica
            value: Valor para incrementar
            tags: Tags adicionais
        """
        with self._lock:
            key = self._build_key(name, tags)
            self.counters[key] += value
    
    def set_gauge(self, name: str, value: float, tags: Dict[str, str] = None):
        """
        Define valor de gauge
        
        Args:
            name: Nome da métrica
            value: Valor do gauge
            tags: Tags adicionais
        """
        with self._lock:
            key = self._build_key(name, tags)
            self.gauges[key] = value
    
    def record_histogram(self, name: str, value: float, tags: Dict[str, str] = None):
        """
        Registra valor em histograma
        
        Args:
            name: Nome da métrica
            value: Valor para registrar
            tags: Tags adicionais
        """
        with self._lock:
            key = self._build_key(name, tags)
            self.histograms[key].append({
                'value': value,
                'timestamp': datetime.utcnow()
            })
    
    def record_timing(self, name: str, duration: float, tags: Dict[str, str] = None):
        """
        Registra tempo de execução
        
        Args:
            name: Nome da métrica
            duration: Duração em segundos
            tags: Tags adicionais
        """
        self.record_histogram(f"{name}.duration", duration, tags)
        self.increment_counter(f"{name}.count", 1, tags)
    
    def get_metrics(self) -> Dict[str, Any]:
        """
        Retorna todas as métricas coletadas
        
        Returns:
            Dicionário com métricas
        """
        with self._lock:
            return {
                'counters': dict(self.counters),
                'gauges': dict(self.gauges),
                'histograms': {
                    name: {
                        'count': len(values),
                        'avg': sum(v['value'] for v in values) / len(values) if values else 0,
                        'min': min(v['value'] for v in values) if values else 0,
                        'max': max(v['value'] for v in values) if values else 0,
                        'p95': self._percentile([v['value'] for v in values], 95) if values else 0,
                        'p99': self._percentile([v['value'] for v in values], 99) if values else 0
                    }
                    for name, values in self.histograms.items()
                }
            }
    
    def _build_key(self, name: str, tags: Dict[str, str] = None) -> str:
        """Constrói chave da métrica com tags"""
        if not tags:
            return name
        
        tag_str = ','.join(f"{k}={v}" for k, v in sorted(tags.items()))
        return f"{name}[{tag_str}]"
    
    def _percentile(self, values: List[float], percentile: int) -> float:
        """Calcula percentil de uma lista de valores"""
        if not values:
            return 0
        
        sorted_values = sorted(values)
        index = int((percentile / 100) * len(sorted_values))
        return sorted_values[min(index, len(sorted_values) - 1)]


class PerformanceMonitor:
    """Monitor de performance da aplicação"""
    
    def __init__(self, metrics_collector: MetricsCollector):
        self.metrics = metrics_collector
        self.thresholds = {
            'response_time': 2.0,  # segundos
            'memory_usage': 80.0,  # percentual
            'cpu_usage': 80.0,     # percentual
            'error_rate': 5.0      # percentual
        }
    
    def monitor_function(self, name: str = None, threshold: float = None):
        """
        Decorator para monitorar performance de função
        
        Args:
            name: Nome da métrica (usa nome da função se None)
            threshold: Threshold de performance em segundos
        """
        def decorator(func: Callable):
            metric_name = name or f"function.{func.__name__}"
            perf_threshold = threshold or self.thresholds['response_time']
            
            @wraps(func)
            def wrapper(*args, **kwargs):
                start_time = time.time()
                
                try:
                    result = func(*args, **kwargs)
                    self.metrics.increment_counter(f"{metric_name}.success")
                    return result
                except Exception as e:
                    self.metrics.increment_counter(f"{metric_name}.error")
                    raise
                finally:
                    duration = time.time() - start_time
                    self.metrics.record_timing(metric_name, duration)
                    
                    # Verificar threshold
                    if duration > perf_threshold:
                        self.metrics.increment_counter(f"{metric_name}.slow")
                        logging.warning(
                            f"Performance degradada em {metric_name}: {duration:.2f}s > {perf_threshold}s"
                        )
            
            return wrapper
        return decorator
    
    def get_system_metrics(self) -> Dict[str, float]:
        """
        Coleta métricas do sistema
        
        Returns:
            Métricas do sistema
        """
        cpu_percent = psutil.cpu_percent(interval=1)
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        
        metrics = {
            'cpu_usage_percent': cpu_percent,
            'memory_usage_percent': memory.percent,
            'memory_available_mb': memory.available / 1024 / 1024,
            'disk_usage_percent': disk.percent,
            'disk_free_gb': disk.free / 1024 / 1024 / 1024
        }
        
        # Registrar métricas
        for name, value in metrics.items():
            self.metrics.set_gauge(f"system.{name}", value)
        
        # Verificar thresholds
        if cpu_percent > self.thresholds['cpu_usage']:
            logging.warning(f"Alto uso de CPU: {cpu_percent:.1f}%")
        
        if memory.percent > self.thresholds['memory_usage']:
            logging.warning(f"Alto uso de memória: {memory.percent:.1f}%")
        
        return metrics
    
    def check_health(self) -> Dict[str, Any]:
        """
        Verifica saúde geral da aplicação
        
        Returns:
            Status de saúde
        """
        system_metrics = self.get_system_metrics()
        app_metrics = self.metrics.get_metrics()
        
        # Calcular score de saúde
        health_score = 100.0
        issues = []
        
        # Verificar CPU
        if system_metrics['cpu_usage_percent'] > self.thresholds['cpu_usage']:
            health_score -= 20
            issues.append(f"Alto uso de CPU: {system_metrics['cpu_usage_percent']:.1f}%")
        
        # Verificar memória
        if system_metrics['memory_usage_percent'] > self.thresholds['memory_usage']:
            health_score -= 20
            issues.append(f"Alto uso de memória: {system_metrics['memory_usage_percent']:.1f}%")
        
        # Verificar taxa de erro
        total_requests = sum(v for k, v in app_metrics['counters'].items() if k.endswith('.count'))
        total_errors = sum(v for k, v in app_metrics['counters'].items() if k.endswith('.error'))
        
        error_rate = (total_errors / total_requests * 100) if total_requests > 0 else 0
        if error_rate > self.thresholds['error_rate']:
            health_score -= 30
            issues.append(f"Alta taxa de erro: {error_rate:.1f}%")
        
        # Determinar status
        if health_score >= 90:
            status = "healthy"
        elif health_score >= 70:
            status = "degraded"
        else:
            status = "unhealthy"
        
        return {
            'status': status,
            'score': health_score,
            'issues': issues,
            'timestamp': datetime.utcnow().isoformat(),
            'system_metrics': system_metrics,
            'application_metrics': app_metrics
        }


class AlertManager:
    """Gerenciador de alertas"""
    
    def __init__(self):
        self.alert_rules = []
        self.active_alerts = {}
        self.alert_history = deque(maxlen=1000)
    
    def add_rule(self, name: str, condition: Callable[[Dict[str, Any]], bool], 
                 severity: str = "warning", cooldown: int = 300):
        """
        Adiciona regra de alerta
        
        Args:
            name: Nome do alerta
            condition: Função que retorna True se alerta deve disparar
            severity: Severidade (info, warning, error, critical)
            cooldown: Tempo de cooldown em segundos
        """
        self.alert_rules.append({
            'name': name,
            'condition': condition,
            'severity': severity,
            'cooldown': cooldown
        })
    
    def check_alerts(self, metrics: Dict[str, Any]):
        """
        Verifica regras de alerta
        
        Args:
            metrics: Métricas para verificar
        """
        now = datetime.utcnow()
        
        for rule in self.alert_rules:
            rule_name = rule['name']
            
            # Verificar cooldown
            if rule_name in self.active_alerts:
                last_triggered = self.active_alerts[rule_name]['triggered_at']
                if (now - last_triggered).total_seconds() < rule['cooldown']:
                    continue
            
            # Verificar condição
            if rule['condition'](metrics):
                alert = {
                    'name': rule_name,
                    'severity': rule['severity'],
                    'triggered_at': now,
                    'message': f"Alerta {rule_name} disparado",
                    'metrics': metrics
                }
                
                self.active_alerts[rule_name] = alert
                self.alert_history.append(alert)
                
                # Log do alerta
                logging.warning(f"ALERT: {alert['message']}")
                
                # Aqui seria implementado o envio de notificações
                self._send_notification(alert)
    
    def _send_notification(self, alert: Dict[str, Any]):
        """
        Envia notificação de alerta
        
        Args:
            alert: Dados do alerta
        """
        # Implementação de envio de notificação
        # (email, Slack, webhook, etc.)
        print(f"NOTIFICATION: {alert}")
    
    def get_active_alerts(self) -> List[Dict[str, Any]]:
        """
        Retorna alertas ativos
        
        Returns:
            Lista de alertas ativos
        """
        return list(self.active_alerts.values())
    
    def acknowledge_alert(self, alert_name: str, user: str):
        """
        Reconhece alerta
        
        Args:
            alert_name: Nome do alerta
            user: Usuário que reconheceu
        """
        if alert_name in self.active_alerts:
            self.active_alerts[alert_name]['acknowledged_by'] = user
            self.active_alerts[alert_name]['acknowledged_at'] = datetime.utcnow()
    
    def resolve_alert(self, alert_name: str, user: str):
        """
        Resolve alerta
        
        Args:
            alert_name: Nome do alerta
            user: Usuário que resolveu
        """
        if alert_name in self.active_alerts:
            alert = self.active_alerts.pop(alert_name)
            alert['resolved_by'] = user
            alert['resolved_at'] = datetime.utcnow()
            self.alert_history.append(alert)


class LoggingManager:
    """Gerenciador de logs estruturados"""
    
    def __init__(self):
        self.setup_logging()
    
    def setup_logging(self):
        """Configura logging estruturado"""
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.StreamHandler(),
                logging.FileHandler('data_governance.log')
            ]
        )
    
    def log_api_request(self, method: str, path: str, user_id: str = None, 
                       duration: float = None, status_code: int = None):
        """
        Log de requisição API
        
        Args:
            method: Método HTTP
            path: Caminho da API
            user_id: ID do usuário
            duration: Duração da requisição
            status_code: Código de status
        """
        log_data = {
            'type': 'api_request',
            'method': method,
            'path': path,
            'user_id': user_id,
            'duration': duration,
            'status_code': status_code,
            'timestamp': datetime.utcnow().isoformat()
        }
        
        logging.info(json.dumps(log_data))
    
    def log_data_access(self, user_id: str, resource_type: str, resource_id: str, 
                       action: str, success: bool = True):
        """
        Log de acesso a dados
        
        Args:
            user_id: ID do usuário
            resource_type: Tipo do recurso
            resource_id: ID do recurso
            action: Ação realizada
            success: Se foi bem-sucedida
        """
        log_data = {
            'type': 'data_access',
            'user_id': user_id,
            'resource_type': resource_type,
            'resource_id': resource_id,
            'action': action,
            'success': success,
            'timestamp': datetime.utcnow().isoformat()
        }
        
        logging.info(json.dumps(log_data))
    
    def log_security_event(self, event_type: str, user_id: str = None, 
                          ip_address: str = None, details: Dict[str, Any] = None):
        """
        Log de evento de segurança
        
        Args:
            event_type: Tipo do evento
            user_id: ID do usuário
            ip_address: Endereço IP
            details: Detalhes adicionais
        """
        log_data = {
            'type': 'security_event',
            'event_type': event_type,
            'user_id': user_id,
            'ip_address': ip_address,
            'details': details or {},
            'timestamp': datetime.utcnow().isoformat()
        }
        
        logging.warning(json.dumps(log_data))


# Instâncias globais
metrics_collector = MetricsCollector()
performance_monitor = PerformanceMonitor(metrics_collector)
alert_manager = AlertManager()
logging_manager = LoggingManager()


# Configuração de alertas padrão
def setup_default_alerts():
    """Configura alertas padrão do sistema"""
    
    # Alerta de alto uso de CPU
    alert_manager.add_rule(
        name="high_cpu_usage",
        condition=lambda m: m.get('system_metrics', {}).get('cpu_usage_percent', 0) > 80,
        severity="warning",
        cooldown=300
    )
    
    # Alerta de alto uso de memória
    alert_manager.add_rule(
        name="high_memory_usage",
        condition=lambda m: m.get('system_metrics', {}).get('memory_usage_percent', 0) > 80,
        severity="warning",
        cooldown=300
    )
    
    # Alerta de alta taxa de erro
    alert_manager.add_rule(
        name="high_error_rate",
        condition=lambda m: _calculate_error_rate(m) > 5.0,
        severity="error",
        cooldown=180
    )
    
    # Alerta de performance degradada
    alert_manager.add_rule(
        name="slow_response_time",
        condition=lambda m: _get_avg_response_time(m) > 2.0,
        severity="warning",
        cooldown=300
    )


def _calculate_error_rate(metrics: Dict[str, Any]) -> float:
    """Calcula taxa de erro das métricas"""
    counters = metrics.get('application_metrics', {}).get('counters', {})
    total_requests = sum(v for k, v in counters.items() if k.endswith('.count'))
    total_errors = sum(v for k, v in counters.items() if k.endswith('.error'))
    
    return (total_errors / total_requests * 100) if total_requests > 0 else 0


def _get_avg_response_time(metrics: Dict[str, Any]) -> float:
    """Obtém tempo médio de resposta das métricas"""
    histograms = metrics.get('application_metrics', {}).get('histograms', {})
    
    # Procura por métricas de duração
    duration_metrics = [v for k, v in histograms.items() if 'duration' in k]
    
    if duration_metrics:
        return sum(m['avg'] for m in duration_metrics) / len(duration_metrics)
    
    return 0.0


# Configurar alertas padrão
setup_default_alerts()


# Decorators para uso fácil
def monitor_performance(name: str = None, threshold: float = None):
    """Decorator para monitorar performance"""
    return performance_monitor.monitor_function(name, threshold)


def track_metric(metric_name: str, metric_type: str = "counter"):
    """
    Decorator para rastrear métricas
    
    Args:
        metric_name: Nome da métrica
        metric_type: Tipo da métrica (counter, gauge, histogram)
    """
    def decorator(func: Callable):
        @wraps(func)
        def wrapper(*args, **kwargs):
            if metric_type == "counter":
                metrics_collector.increment_counter(metric_name)
            
            result = func(*args, **kwargs)
            
            if metric_type == "gauge" and isinstance(result, (int, float)):
                metrics_collector.set_gauge(metric_name, result)
            
            return result
        return wrapper
    return decorator

