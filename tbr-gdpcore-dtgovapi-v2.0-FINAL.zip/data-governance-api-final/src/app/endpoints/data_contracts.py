"""
Endpoints para data_contracts seguindo modelo original
Autor: Carlos Morais
"""

from typing import List, Dict, Any
from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from ..core.dependencies import get_db
from ..schemas.data_contracts import (
    DataContracts, 
    DataContractsCreate, 
    DataContractsUpdate, 
    DataContractsSummary
)
from ..schemas.base import PaginatedResponse
from ..services.data_contracts import DataContractsService
from ..utils.exceptions import EntityNotFoundError, ValidationError

router = APIRouter(prefix="/data-contracts", tags=["data-contracts"])


@router.get("/", response_model=PaginatedResponse[DataContractsSummary])
async def list_data_contracts(
    skip: int = Query(0, ge=0, description="Número de registros para pular"),
    limit: int = Query(100, ge=1, le=1000, description="Número máximo de registros"),
    db: Session = Depends(get_db)
):
    """Lista contratos de dados com paginação"""
    service = DataContractsService(db)
    contracts = await service.get_multi(skip=skip, limit=limit)
    total = await service.count()
    
    return PaginatedResponse(
        items=[DataContractsSummary.model_validate(contract) for contract in contracts],
        total=total,
        skip=skip,
        limit=limit
    )


@router.get("/search", response_model=List[DataContractsSummary])
async def search_data_contracts(
    q: str = Query(..., min_length=2, description="Termo de busca"),
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    db: Session = Depends(get_db)
):
    """Busca textual em contratos de dados"""
    try:
        service = DataContractsService(db)
        contracts = await service.search_text(q, skip, limit)
        return [DataContractsSummary.model_validate(contract) for contract in contracts]
    except ValidationError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.get("/stats", response_model=Dict[str, Any])
async def get_data_contracts_stats(db: Session = Depends(get_db)):
    """Retorna estatísticas dos contratos de dados"""
    service = DataContractsService(db)
    return await service.get_stats()


@router.get("/by-domain/{domain}", response_model=List[DataContractsSummary])
async def get_data_contracts_by_domain(
    domain: str,
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    db: Session = Depends(get_db)
):
    """Lista contratos por domínio de negócio"""
    service = DataContractsService(db)
    contracts = await service.get_by_domain(domain, skip, limit)
    return [DataContractsSummary.model_validate(contract) for contract in contracts]


@router.get("/by-owner/{owner}", response_model=List[DataContractsSummary])
async def get_data_contracts_by_owner(
    owner: str,
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    db: Session = Depends(get_db)
):
    """Lista contratos por proprietário"""
    service = DataContractsService(db)
    contracts = await service.get_by_owner(owner, skip, limit)
    return [DataContractsSummary.model_validate(contract) for contract in contracts]


@router.get("/by-status/{status}", response_model=List[DataContractsSummary])
async def get_data_contracts_by_status(
    status: str,
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    db: Session = Depends(get_db)
):
    """Lista contratos por status"""
    service = DataContractsService(db)
    contracts = await service.get_by_status(status, skip, limit)
    return [DataContractsSummary.model_validate(contract) for contract in contracts]


@router.get("/unity-catalog", response_model=List[DataContractsSummary])
async def get_unity_catalog_contracts(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    db: Session = Depends(get_db)
):
    """Lista contratos com Unity Catalog habilitado"""
    service = DataContractsService(db)
    contracts = await service.get_unity_catalog_enabled(skip, limit)
    return [DataContractsSummary.model_validate(contract) for contract in contracts]


@router.get("/abac-enabled", response_model=List[DataContractsSummary])
async def get_abac_enabled_contracts(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    db: Session = Depends(get_db)
):
    """Lista contratos com ABAC habilitado"""
    service = DataContractsService(db)
    contracts = await service.get_abac_enabled(skip, limit)
    return [DataContractsSummary.model_validate(contract) for contract in contracts]


@router.get("/monitoring-enabled", response_model=List[DataContractsSummary])
async def get_monitoring_enabled_contracts(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    db: Session = Depends(get_db)
):
    """Lista contratos com monitoramento habilitado"""
    service = DataContractsService(db)
    contracts = await service.get_monitoring_enabled(skip, limit)
    return [DataContractsSummary.model_validate(contract) for contract in contracts]


@router.post("/", response_model=DataContracts, status_code=status.HTTP_201_CREATED)
async def create_data_contract(
    contract: DataContractsCreate,
    db: Session = Depends(get_db)
):
    """Cria um novo contrato de dados"""
    try:
        service = DataContractsService(db)
        return await service.create(contract)
    except ValidationError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.get("/{contract_id}", response_model=DataContracts)
async def get_data_contract(
    contract_id: UUID,
    db: Session = Depends(get_db)
):
    """Busca contrato por ID"""
    try:
        service = DataContractsService(db)
        contract = await service.get(contract_id)
        if not contract:
            raise HTTPException(status_code=404, detail="Contrato não encontrado")
        return contract
    except EntityNotFoundError:
        raise HTTPException(status_code=404, detail="Contrato não encontrado")


@router.get("/name/{contract_name}", response_model=DataContracts)
async def get_data_contract_by_name(
    contract_name: str,
    db: Session = Depends(get_db)
):
    """Busca contrato por nome"""
    service = DataContractsService(db)
    contract = await service.get_by_name(contract_name)
    if not contract:
        raise HTTPException(status_code=404, detail="Contrato não encontrado")
    return contract


@router.put("/{contract_id}", response_model=DataContracts)
async def update_data_contract(
    contract_id: UUID,
    contract: DataContractsUpdate,
    db: Session = Depends(get_db)
):
    """Atualiza um contrato de dados"""
    try:
        service = DataContractsService(db)
        return await service.update(contract_id, contract)
    except EntityNotFoundError:
        raise HTTPException(status_code=404, detail="Contrato não encontrado")
    except ValidationError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/{contract_id}/activate", response_model=DataContracts)
async def activate_data_contract(
    contract_id: UUID,
    db: Session = Depends(get_db)
):
    """Ativa um contrato de dados"""
    try:
        service = DataContractsService(db)
        return await service.activate(contract_id)
    except EntityNotFoundError:
        raise HTTPException(status_code=404, detail="Contrato não encontrado")


@router.post("/{contract_id}/deprecate", response_model=DataContracts)
async def deprecate_data_contract(
    contract_id: UUID,
    db: Session = Depends(get_db)
):
    """Deprecia um contrato de dados"""
    try:
        service = DataContractsService(db)
        return await service.deprecate(contract_id)
    except EntityNotFoundError:
        raise HTTPException(status_code=404, detail="Contrato não encontrado")


@router.post("/{contract_id}/archive", response_model=DataContracts)
async def archive_data_contract(
    contract_id: UUID,
    db: Session = Depends(get_db)
):
    """Arquiva um contrato de dados"""
    try:
        service = DataContractsService(db)
        return await service.archive(contract_id)
    except EntityNotFoundError:
        raise HTTPException(status_code=404, detail="Contrato não encontrado")


@router.delete("/{contract_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_data_contract(
    contract_id: UUID,
    db: Session = Depends(get_db)
):
    """Remove um contrato de dados"""
    try:
        service = DataContractsService(db)
        await service.remove(contract_id)
    except EntityNotFoundError:
        raise HTTPException(status_code=404, detail="Contrato não encontrado")
