"""
Endpoints REST para External Metadata
APIs para Unity Catalog External Lineage
Autor: Manus AI
"""

import logging
from typing import List, Optional, Dict, Any
from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from ..database import get_db
from ..schemas.external_metadata import (
    ExternalMetadataCreate,
    ExternalMetadataUpdate,
    ExternalMetadataResponse,
    ExternalMetadataListResponse,
    ExternalMetadataFilter,
    ExternalLineageRelationshipCreate,
    ExternalLineageRelationshipResponse,
    ExternalColumnMappingResponse,
    ExternalMetadataStats,
    SystemTypeInfo,
    EntityTypeInfo
)
from ..services.external_metadata import ExternalMetadataService
from ..utils.exceptions import (
    ValidationError,
    NotFoundError,
    ConflictError,
    UnauthorizedError
)
from ..utils.security import get_current_user, get_unity_catalog_privileges
from ..utils.pagination import PaginationParams

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/external-metadata", tags=["External Metadata"])


@router.post(
    "/",
    response_model=ExternalMetadataResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Criar objeto de metadados externo",
    description="Cria novo objeto de metadados externo para Unity Catalog External Lineage"
)
async def create_external_metadata(
    data: ExternalMetadataCreate,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user),
    unity_catalog_privileges: Dict[str, Any] = Depends(get_unity_catalog_privileges)
):
    """
    Cria novo objeto de metadados externo.
    
    Requer privilégio 'CREATE EXTERNAL METADATA' no metastore Unity Catalog.
    """
    try:
        service = ExternalMetadataService(db, current_user.user_id)
        external_metadata = await service.create_external_metadata(
            data=data,
            unity_catalog_privileges=unity_catalog_privileges
        )
        return ExternalMetadataResponse.from_orm(external_metadata)
        
    except ValidationError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except UnauthorizedError as e:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=str(e)
        )
    except ConflictError as e:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(e)
        )
    except Exception as e:
        logger.error(f"Erro ao criar external metadata: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro interno do servidor"
        )


@router.get(
    "/",
    response_model=ExternalMetadataListResponse,
    summary="Listar objetos de metadados externos",
    description="Lista objetos de metadados externos com filtros e paginação"
)
async def list_external_metadata(
    system_type: Optional[str] = Query(None, description="Filtrar por tipo de sistema"),
    entity_type: Optional[str] = Query(None, description="Filtrar por tipo de entidade"),
    is_active: Optional[bool] = Query(None, description="Filtrar por status ativo"),
    validation_status: Optional[str] = Query(None, description="Filtrar por status de validação"),
    sync_status: Optional[str] = Query(None, description="Filtrar por status de sincronização"),
    search: Optional[str] = Query(None, description="Busca textual em nome e descrição"),
    pagination: PaginationParams = Depends(),
    order_by: str = Query("created_at", description="Campo para ordenação"),
    order_desc: bool = Query(True, description="Ordenação descendente"),
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    Lista objetos de metadados externos com filtros opcionais.
    """
    try:
        filters = ExternalMetadataFilter(
            system_type=system_type,
            entity_type=entity_type,
            is_active=is_active,
            validation_status=validation_status,
            sync_status=sync_status,
            search=search
        )
        
        service = ExternalMetadataService(db, current_user.user_id)
        items, total = await service.list_external_metadata(
            filters=filters,
            page=pagination.page,
            size=pagination.size,
            order_by=order_by,
            order_desc=order_desc
        )
        
        # Calcular páginas
        pages = (total + pagination.size - 1) // pagination.size
        
        return ExternalMetadataListResponse(
            items=[ExternalMetadataResponse.from_orm(item) for item in items],
            total=total,
            page=pagination.page,
            size=pagination.size,
            pages=pages
        )
        
    except Exception as e:
        logger.error(f"Erro ao listar external metadata: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro interno do servidor"
        )


@router.get(
    "/{external_metadata_id}",
    response_model=ExternalMetadataResponse,
    summary="Obter objeto de metadados externo",
    description="Obtém objeto de metadados externo por ID"
)
async def get_external_metadata(
    external_metadata_id: UUID,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    Obtém objeto de metadados externo específico por ID.
    """
    try:
        service = ExternalMetadataService(db, current_user.user_id)
        external_metadata = await service.get_external_metadata(external_metadata_id)
        return ExternalMetadataResponse.from_orm(external_metadata)
        
    except NotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except Exception as e:
        logger.error(f"Erro ao obter external metadata {external_metadata_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro interno do servidor"
        )


@router.put(
    "/{external_metadata_id}",
    response_model=ExternalMetadataResponse,
    summary="Atualizar objeto de metadados externo",
    description="Atualiza objeto de metadados externo existente"
)
async def update_external_metadata(
    external_metadata_id: UUID,
    data: ExternalMetadataUpdate,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user),
    unity_catalog_privileges: Dict[str, Any] = Depends(get_unity_catalog_privileges)
):
    """
    Atualiza objeto de metadados externo.
    
    Requer privilégio 'MODIFY' no objeto external metadata.
    """
    try:
        service = ExternalMetadataService(db, current_user.user_id)
        external_metadata = await service.update_external_metadata(
            external_metadata_id=external_metadata_id,
            data=data,
            unity_catalog_privileges=unity_catalog_privileges
        )
        return ExternalMetadataResponse.from_orm(external_metadata)
        
    except NotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except ValidationError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except UnauthorizedError as e:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=str(e)
        )
    except ConflictError as e:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(e)
        )
    except Exception as e:
        logger.error(f"Erro ao atualizar external metadata {external_metadata_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro interno do servidor"
        )


@router.delete(
    "/{external_metadata_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Remover objeto de metadados externo",
    description="Remove objeto de metadados externo (soft delete)"
)
async def delete_external_metadata(
    external_metadata_id: UUID,
    force: bool = Query(False, description="Forçar remoção mesmo com relacionamentos"),
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user),
    unity_catalog_privileges: Dict[str, Any] = Depends(get_unity_catalog_privileges)
):
    """
    Remove objeto de metadados externo.
    
    Requer privilégio 'MODIFY' no objeto external metadata.
    Use force=True para remover objetos com relacionamentos existentes.
    """
    try:
        service = ExternalMetadataService(db, current_user.user_id)
        await service.delete_external_metadata(
            external_metadata_id=external_metadata_id,
            unity_catalog_privileges=unity_catalog_privileges,
            force=force
        )
        
    except NotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except UnauthorizedError as e:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=str(e)
        )
    except ConflictError as e:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(e)
        )
    except Exception as e:
        logger.error(f"Erro ao remover external metadata {external_metadata_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro interno do servidor"
        )


@router.post(
    "/{external_metadata_id}/relationships",
    response_model=ExternalLineageRelationshipResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Criar relacionamento de linhagem",
    description="Cria relacionamento de linhagem entre objeto externo e Unity Catalog"
)
async def create_lineage_relationship(
    external_metadata_id: UUID,
    data: ExternalLineageRelationshipCreate,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user),
    unity_catalog_privileges: Dict[str, Any] = Depends(get_unity_catalog_privileges)
):
    """
    Cria relacionamento de linhagem entre objeto externo e Unity Catalog.
    
    Privilégios necessários dependem da direção:
    - Downstream: privilégios de leitura no objeto Unity Catalog
    - Upstream: privilégios de escrita no objeto Unity Catalog
    """
    try:
        # Definir external_metadata_id no data
        data.external_metadata_id = external_metadata_id
        
        service = ExternalMetadataService(db, current_user.user_id)
        relationship = await service.create_lineage_relationship(
            data=data,
            unity_catalog_privileges=unity_catalog_privileges
        )
        return ExternalLineageRelationshipResponse.from_orm(relationship)
        
    except NotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except ValidationError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except UnauthorizedError as e:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=str(e)
        )
    except Exception as e:
        logger.error(f"Erro ao criar relacionamento de linhagem: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro interno do servidor"
        )


@router.get(
    "/system-types",
    response_model=List[SystemTypeInfo],
    summary="Listar tipos de sistema suportados",
    description="Obtém lista de tipos de sistema suportados para external metadata"
)
async def get_supported_system_types():
    """
    Retorna lista de tipos de sistema suportados com informações detalhadas.
    """
    system_types = [
        SystemTypeInfo(
            name="tableau",
            display_name="Tableau",
            description="Tableau Server/Online dashboards e workbooks",
            supported_entity_types=["dashboard", "workbook", "datasource"],
            required_properties=["server_url"],
            optional_properties=["site_id", "project_name"]
        ),
        SystemTypeInfo(
            name="powerbi",
            display_name="Power BI",
            description="Microsoft Power BI dashboards e datasets",
            supported_entity_types=["dashboard", "report", "dataset"],
            required_properties=["workspace_id"],
            optional_properties=["app_id"]
        ),
        SystemTypeInfo(
            name="salesforce",
            display_name="Salesforce",
            description="Salesforce CRM objects e reports",
            supported_entity_types=["table", "report", "dashboard"],
            required_properties=["org_id"],
            optional_properties=["sandbox"]
        ),
        SystemTypeInfo(
            name="mysql",
            display_name="MySQL",
            description="MySQL database tables e views",
            supported_entity_types=["table", "view"],
            required_properties=["host", "database"],
            optional_properties=["port", "schema"]
        ),
        SystemTypeInfo(
            name="postgresql",
            display_name="PostgreSQL",
            description="PostgreSQL database tables e views",
            supported_entity_types=["table", "view"],
            required_properties=["host", "database"],
            optional_properties=["port", "schema"]
        ),
        SystemTypeInfo(
            name="custom",
            display_name="Sistema Customizado",
            description="Sistema customizado ou não listado",
            supported_entity_types=["custom"],
            required_properties=[],
            optional_properties=["system_name", "version"]
        )
    ]
    
    return system_types


@router.get(
    "/entity-types",
    response_model=List[EntityTypeInfo],
    summary="Listar tipos de entidade suportados",
    description="Obtém lista de tipos de entidade suportados para external metadata"
)
async def get_supported_entity_types():
    """
    Retorna lista de tipos de entidade suportados com informações detalhadas.
    """
    entity_types = [
        EntityTypeInfo(
            name="table",
            display_name="Tabela",
            description="Tabela de banco de dados",
            applicable_systems=["mysql", "postgresql", "oracle", "sqlserver", "salesforce"]
        ),
        EntityTypeInfo(
            name="view",
            display_name="View",
            description="View de banco de dados",
            applicable_systems=["mysql", "postgresql", "oracle", "sqlserver"]
        ),
        EntityTypeInfo(
            name="dashboard",
            display_name="Dashboard",
            description="Dashboard de BI",
            applicable_systems=["tableau", "powerbi", "looker", "qlik", "salesforce"]
        ),
        EntityTypeInfo(
            name="report",
            display_name="Relatório",
            description="Relatório de BI",
            applicable_systems=["powerbi", "salesforce", "custom"]
        ),
        EntityTypeInfo(
            name="dataset",
            display_name="Dataset",
            description="Dataset ou conjunto de dados",
            applicable_systems=["powerbi", "bigquery", "custom"]
        ),
        EntityTypeInfo(
            name="workbook",
            display_name="Workbook",
            description="Workbook do Tableau",
            applicable_systems=["tableau"]
        ),
        EntityTypeInfo(
            name="datasource",
            display_name="Data Source",
            description="Fonte de dados",
            applicable_systems=["tableau", "looker", "custom"]
        ),
        EntityTypeInfo(
            name="custom",
            display_name="Customizado",
            description="Tipo de entidade customizado",
            applicable_systems=["custom"]
        )
    ]
    
    return entity_types


@router.get(
    "/statistics",
    response_model=ExternalMetadataStats,
    summary="Obter estatísticas",
    description="Obtém estatísticas de objetos de metadados externos"
)
async def get_external_metadata_statistics(
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    Retorna estatísticas detalhadas de external metadata.
    """
    try:
        service = ExternalMetadataService(db, current_user.user_id)
        stats = await service.get_statistics()
        return ExternalMetadataStats(**stats)
        
    except Exception as e:
        logger.error(f"Erro ao obter estatísticas: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro interno do servidor"
        )

