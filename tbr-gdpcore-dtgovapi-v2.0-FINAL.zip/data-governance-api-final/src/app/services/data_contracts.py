"""
Service para data_contracts seguindo modelo original
Autor: Carlos Morais
"""

from typing import List, Optional, Dict, Any
from uuid import UUID
from sqlalchemy.orm import Session

from .base import BaseService
from ..models.data_contracts import DataContracts
from ..schemas.data_contracts import DataContractsCreate, DataContractsUpdate
from ..repositories.data_contracts import DataContractsRepository
from ..utils.exceptions import EntityNotFoundError, ValidationError


class DataContractsService(BaseService[DataContracts, DataContractsCreate, DataContractsUpdate]):
    """Service para data_contracts"""

    def __init__(self, db: Session):
        repository = DataContractsRepository(db)
        super().__init__(repository)

    async def create(self, obj_in: DataContractsCreate) -> DataContracts:
        """Cria um novo contrato com validações"""
        # Validar nome único
        if await self.repository.name_exists(obj_in.contract_name):
            raise ValidationError(f"Contrato com nome '{obj_in.contract_name}' já existe")
        
        # Validar status
        valid_statuses = ["draft", "active", "deprecated", "archived"]
        if obj_in.contract_status and obj_in.contract_status not in valid_statuses:
            raise ValidationError(f"Status inválido. Valores aceitos: {valid_statuses}")
        
        # Validar Unity Catalog
        if obj_in.unity_catalog_enabled:
            if not obj_in.unity_catalog_name:
                raise ValidationError("unity_catalog_name é obrigatório quando Unity Catalog está habilitado")
        
        return await super().create(obj_in)

    async def update(self, id: UUID, obj_in: DataContractsUpdate) -> DataContracts:
        """Atualiza contrato com validações"""
        # Verificar se existe
        existing = await self.get(id)
        if not existing:
            raise EntityNotFoundError(f"Contrato com ID {id} não encontrado")
        
        # Validar nome único se alterado
        if obj_in.contract_name and obj_in.contract_name != existing.contract_name:
            if await self.repository.name_exists(obj_in.contract_name, exclude_id=id):
                raise ValidationError(f"Contrato com nome '{obj_in.contract_name}' já existe")
        
        # Validar status se alterado
        if obj_in.contract_status:
            valid_statuses = ["draft", "active", "deprecated", "archived"]
            if obj_in.contract_status not in valid_statuses:
                raise ValidationError(f"Status inválido. Valores aceitos: {valid_statuses}")
        
        # Validar Unity Catalog se alterado
        if obj_in.unity_catalog_enabled is not None:
            if obj_in.unity_catalog_enabled and not obj_in.unity_catalog_name:
                if not existing.unity_catalog_name:
                    raise ValidationError("unity_catalog_name é obrigatório quando Unity Catalog está habilitado")
        
        return await super().update(id, obj_in)

    async def get_by_name(self, contract_name: str) -> Optional[DataContracts]:
        """Busca contrato por nome"""
        return await self.repository.get_by_name(contract_name)

    async def get_by_domain(self, business_domain: str, skip: int = 0, limit: int = 100) -> List[DataContracts]:
        """Busca contratos por domínio"""
        return await self.repository.get_by_domain(business_domain, skip, limit)

    async def get_by_owner(self, contract_owner: str, skip: int = 0, limit: int = 100) -> List[DataContracts]:
        """Busca contratos por proprietário"""
        return await self.repository.get_by_owner(contract_owner, skip, limit)

    async def get_by_status(self, contract_status: str, skip: int = 0, limit: int = 100) -> List[DataContracts]:
        """Busca contratos por status"""
        return await self.repository.get_by_status(contract_status, skip, limit)

    async def get_unity_catalog_enabled(self, skip: int = 0, limit: int = 100) -> List[DataContracts]:
        """Busca contratos com Unity Catalog habilitado"""
        return await self.repository.get_unity_catalog_enabled(skip, limit)

    async def get_abac_enabled(self, skip: int = 0, limit: int = 100) -> List[DataContracts]:
        """Busca contratos com ABAC habilitado"""
        return await self.repository.get_abac_enabled(skip, limit)

    async def get_monitoring_enabled(self, skip: int = 0, limit: int = 100) -> List[DataContracts]:
        """Busca contratos com monitoramento habilitado"""
        return await self.repository.get_monitoring_enabled(skip, limit)

    async def search_text(self, search_term: str, skip: int = 0, limit: int = 100) -> List[DataContracts]:
        """Busca textual"""
        if not search_term or len(search_term.strip()) < 2:
            raise ValidationError("Termo de busca deve ter pelo menos 2 caracteres")
        
        return await self.repository.search_text(search_term.strip(), skip, limit)

    async def get_stats(self) -> Dict[str, Any]:
        """Retorna estatísticas"""
        return await self.repository.get_stats()

    async def activate(self, id: UUID) -> DataContracts:
        """Ativa um contrato"""
        contract = await self.get(id)
        if not contract:
            raise EntityNotFoundError(f"Contrato com ID {id} não encontrado")
        
        update_data = DataContractsUpdate(contract_status="active")
        return await self.update(id, update_data)

    async def deprecate(self, id: UUID) -> DataContracts:
        """Deprecia um contrato"""
        contract = await self.get(id)
        if not contract:
            raise EntityNotFoundError(f"Contrato com ID {id} não encontrado")
        
        update_data = DataContractsUpdate(contract_status="deprecated")
        return await self.update(id, update_data)

    async def archive(self, id: UUID) -> DataContracts:
        """Arquiva um contrato"""
        contract = await self.get(id)
        if not contract:
            raise EntityNotFoundError(f"Contrato com ID {id} não encontrado")
        
        update_data = DataContractsUpdate(contract_status="archived")
        return await self.update(id, update_data)
