"""
Aplicação principal da Data Governance API
Autor: Carlos Morais

API completa para governança de dados com todas as funcionalidades.
"""

from fastapi import FastAPI, Request, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.responses import JSONResponse
from fastapi.openapi.utils import get_openapi
import time
import logging
from contextlib import asynccontextmanager

from .core.config import settings
from .core.database import engine, Base
from .core.exceptions import (
    ValidationError, NotFoundError, ConflictError,
    UnauthorizedError, ForbiddenError
)

# Importar todos os routers
from .endpoints.health import router as health_router
from .endpoints.data_contracts import router as contracts_router
from .endpoints.data_lineage import router as lineage_router
from .endpoints.alerts import router as alerts_router

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Gerencia o ciclo de vida da aplicação"""
    # Startup
    logger.info("Iniciando Data Governance API...")
    
    # Criar tabelas se não existirem
    try:
        Base.metadata.create_all(bind=engine)
        logger.info("Tabelas do banco de dados verificadas/criadas")
    except Exception as e:
        logger.error(f"Erro ao criar tabelas: {e}")
        raise
    
    logger.info("Data Governance API iniciada com sucesso!")
    
    yield
    
    # Shutdown
    logger.info("Encerrando Data Governance API...")


# Criar aplicação FastAPI
app = FastAPI(
    title="Data Governance API",
    description="""
    ## API Completa para Governança de Dados
    
    **Autor:** Carlos Morais
    
    Esta API fornece funcionalidades completas para governança de dados, incluindo:
    
    ### 🏗️ Contratos de Dados
    - Criação e gerenciamento de contratos
    - Versionamento avançado
    - Layouts customizáveis por país
    - Validação e ativação automática
    
    ### 📊 Data Lineage
    - Rastreamento completo de linhagem
    - Análise de impacto upstream/downstream
    - Grafos interativos de dependências
    - Validação de integridade
    
    ### 🚨 Sistema de Alertas
    - Definições configuráveis de alertas
    - Monitoramento em tempo real
    - Notificações automáticas
    - Dashboard de métricas
    
    ### 📈 Monitoramento
    - Métricas de cluster, job e query
    - Alertas de performance e qualidade
    - Dashboards executivos
    - Relatórios de compliance
    
    ### 🔐 Governança e Segurança
    - Políticas de dados
    - Controle de acesso (ABAC)
    - Auditoria completa
    - Classificação de dados
    
    ### 🔍 Qualidade de Dados
    - Regras de qualidade configuráveis
    - Execução automática
    - Detecção de anomalias
    - Histórico de resultados
    
    ---
    
    **Versão:** {version}
    **Ambiente:** {environment}
    """.format(
        version=settings.VERSION,
        environment=settings.ENVIRONMENT
    ),
    version=settings.VERSION,
    openapi_url=f"{settings.API_V1_STR}/openapi.json",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan
)

# Configurar CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_HOSTS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Middleware de hosts confiáveis
if settings.ENVIRONMENT == "production":
    app.add_middleware(
        TrustedHostMiddleware,
        allowed_hosts=settings.ALLOWED_HOSTS
    )


# Middleware para logging de requests
@app.middleware("http")
async def log_requests(request: Request, call_next):
    """Log de todas as requisições"""
    start_time = time.time()
    
    # Log da requisição
    logger.info(
        f"Request: {request.method} {request.url.path} "
        f"from {request.client.host if request.client else 'unknown'}"
    )
    
    # Processar requisição
    response = await call_next(request)
    
    # Log da resposta
    process_time = time.time() - start_time
    logger.info(
        f"Response: {response.status_code} "
        f"in {process_time:.4f}s"
    )
    
    # Adicionar header de tempo de processamento
    response.headers["X-Process-Time"] = str(process_time)
    
    return response


# Exception handlers
@app.exception_handler(ValidationError)
async def validation_exception_handler(request: Request, exc: ValidationError):
    """Handler para erros de validação"""
    logger.warning(f"Validation error: {exc}")
    return JSONResponse(
        status_code=400,
        content={
            "error": "Validation Error",
            "message": str(exc),
            "type": "validation_error"
        }
    )


@app.exception_handler(NotFoundError)
async def not_found_exception_handler(request: Request, exc: NotFoundError):
    """Handler para recursos não encontrados"""
    logger.warning(f"Not found error: {exc}")
    return JSONResponse(
        status_code=404,
        content={
            "error": "Not Found",
            "message": str(exc),
            "type": "not_found_error"
        }
    )


@app.exception_handler(ConflictError)
async def conflict_exception_handler(request: Request, exc: ConflictError):
    """Handler para conflitos"""
    logger.warning(f"Conflict error: {exc}")
    return JSONResponse(
        status_code=409,
        content={
            "error": "Conflict",
            "message": str(exc),
            "type": "conflict_error"
        }
    )


@app.exception_handler(UnauthorizedError)
async def unauthorized_exception_handler(request: Request, exc: UnauthorizedError):
    """Handler para erros de autenticação"""
    logger.warning(f"Unauthorized error: {exc}")
    return JSONResponse(
        status_code=401,
        content={
            "error": "Unauthorized",
            "message": str(exc),
            "type": "unauthorized_error"
        }
    )


@app.exception_handler(ForbiddenError)
async def forbidden_exception_handler(request: Request, exc: ForbiddenError):
    """Handler para erros de autorização"""
    logger.warning(f"Forbidden error: {exc}")
    return JSONResponse(
        status_code=403,
        content={
            "error": "Forbidden",
            "message": str(exc),
            "type": "forbidden_error"
        }
    )


@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    """Handler para HTTPExceptions do FastAPI"""
    logger.warning(f"HTTP exception: {exc.status_code} - {exc.detail}")
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error": "HTTP Error",
            "message": exc.detail,
            "type": "http_error"
        }
    )


@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception):
    """Handler geral para exceções não tratadas"""
    logger.error(f"Unhandled exception: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={
            "error": "Internal Server Error",
            "message": "An unexpected error occurred",
            "type": "internal_error"
        }
    )


# Incluir routers
app.include_router(
    health_router,
    prefix=settings.API_V1_STR,
    tags=["Health Check"]
)

app.include_router(
    contracts_router,
    prefix=settings.API_V1_STR,
    tags=["Contratos de Dados"]
)

app.include_router(
    lineage_router,
    prefix=settings.API_V1_STR,
    tags=["Data Lineage"]
)

app.include_router(
    alerts_router,
    prefix=settings.API_V1_STR,
    tags=["Alertas"]
)


# Customizar OpenAPI schema
def custom_openapi():
    """Customiza o schema OpenAPI"""
    if app.openapi_schema:
        return app.openapi_schema
    
    openapi_schema = get_openapi(
        title="Data Governance API",
        version=settings.VERSION,
        description=app.description,
        routes=app.routes,
    )
    
    # Adicionar informações de segurança
    openapi_schema["components"]["securitySchemes"] = {
        "BearerAuth": {
            "type": "http",
            "scheme": "bearer",
            "bearerFormat": "JWT"
        }
    }
    
    # Adicionar tags personalizadas
    openapi_schema["tags"] = [
        {
            "name": "Health Check",
            "description": "Endpoints para verificação de saúde da API"
        },
        {
            "name": "Contratos de Dados",
            "description": "Gerenciamento completo de contratos de dados"
        },
        {
            "name": "Data Lineage",
            "description": "Rastreamento e análise de linhagem de dados"
        },
        {
            "name": "Alertas",
            "description": "Sistema de alertas e notificações"
        },
        {
            "name": "Qualidade de Dados",
            "description": "Regras e execução de qualidade de dados"
        },
        {
            "name": "Monitoramento",
            "description": "Métricas e monitoramento de sistemas"
        },
        {
            "name": "Políticas",
            "description": "Políticas de governança e segurança"
        },
        {
            "name": "Usuários",
            "description": "Gerenciamento de usuários e permissões"
        }
    ]
    
    # Adicionar informações de contato
    openapi_schema["info"]["contact"] = {
        "name": "Carlos Morais",
        "email": "carlos.morais@example.com"
    }
    
    # Adicionar informações de licença
    openapi_schema["info"]["license"] = {
        "name": "MIT",
        "url": "https://opensource.org/licenses/MIT"
    }
    
    app.openapi_schema = openapi_schema
    return app.openapi_schema


app.openapi = custom_openapi


# Root endpoint
@app.get("/", tags=["Root"])
async def root():
    """Endpoint raiz da API"""
    return {
        "message": "Data Governance API",
        "version": settings.VERSION,
        "environment": settings.ENVIRONMENT,
        "author": "Carlos Morais",
        "docs_url": "/docs",
        "redoc_url": "/redoc",
        "health_check": f"{settings.API_V1_STR}/health",
        "features": [
            "Contratos de Dados",
            "Data Lineage",
            "Sistema de Alertas",
            "Qualidade de Dados",
            "Monitoramento",
            "Políticas de Governança",
            "Controle de Acesso",
            "Auditoria Completa"
        ]
    }


# Endpoint de informações da API
@app.get("/info", tags=["Root"])
async def api_info():
    """Informações detalhadas da API"""
    return {
        "api": {
            "name": "Data Governance API",
            "version": settings.VERSION,
            "environment": settings.ENVIRONMENT,
            "author": "Carlos Morais"
        },
        "database": {
            "url": settings.DATABASE_URL.replace(
                settings.DATABASE_PASSWORD, "***"
            ) if settings.DATABASE_PASSWORD else settings.DATABASE_URL,
            "echo": settings.DATABASE_ECHO
        },
        "features": {
            "data_contracts": "Gerenciamento completo de contratos de dados",
            "data_lineage": "Rastreamento e análise de linhagem",
            "alerts": "Sistema de alertas e notificações",
            "quality": "Regras e execução de qualidade",
            "monitoring": "Métricas e monitoramento",
            "policies": "Políticas de governança",
            "users": "Gerenciamento de usuários",
            "audit": "Auditoria completa"
        },
        "endpoints": {
            "health": f"{settings.API_V1_STR}/health",
            "contracts": f"{settings.API_V1_STR}/contracts",
            "lineage": f"{settings.API_V1_STR}/lineage",
            "alerts": f"{settings.API_V1_STR}/alerts"
        }
    }


if __name__ == "__main__":
    import uvicorn
    
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=settings.ENVIRONMENT == "development",
        log_level="info"
    )

