"""
Schemas Pydantic para External Metadata
Validação e serialização de dados para Unity Catalog External Lineage
Autor: Manus AI
"""

from pydantic import BaseModel, Field, validator, root_validator
from typing import Optional, Dict, Any, List
from datetime import datetime
from uuid import UUID


class ExternalMetadataBase(BaseModel):
    """Schema base para External Metadata"""
    
    name: str = Field(
        ...,
        description="Nome human-readable do objeto externo (sem espaços)",
        min_length=1,
        max_length=255
    )
    
    system_type: str = Field(
        ...,
        description="Tipo do sistema externo",
        min_length=1,
        max_length=50
    )
    
    entity_type: str = Field(
        ...,
        description="Tipo da entidade",
        min_length=1,
        max_length=50
    )
    
    external_url: Optional[str] = Field(
        None,
        description="URL do objeto externo para navegação direta",
        max_length=2048
    )
    
    description: Optional[str] = Field(
        None,
        description="Descrição detalhada do objeto externo",
        max_length=4000
    )
    
    properties: Optional[Dict[str, Any]] = Field(
        None,
        description="Propriedades customizadas específicas do sistema"
    )
    
    unity_catalog_metastore_id: Optional[UUID] = Field(
        None,
        description="ID do metastore Unity Catalog associado"
    )
    
    @validator('name')
    def validate_name_format(cls, v):
        """Valida que o nome não contém espaços"""
        if ' ' in v:
            raise ValueError('Nome não pode conter espaços')
        return v
    
    @validator('system_type')
    def validate_system_type(cls, v):
        """Valida se system_type é suportado"""
        supported_types = [
            'tableau', 'powerbi', 'salesforce', 'mysql', 'postgresql',
            'oracle', 'sqlserver', 'snowflake', 'redshift', 'bigquery',
            'looker', 'qlik', 'custom'
        ]
        if v.lower() not in supported_types:
            raise ValueError(f'System type deve ser um de: {", ".join(supported_types)}')
        return v.lower()
    
    @validator('entity_type')
    def validate_entity_type(cls, v):
        """Valida se entity_type é suportado"""
        supported_types = [
            'table', 'view', 'dashboard', 'report', 'dataset',
            'workbook', 'datasource', 'model', 'pipeline', 'job', 'custom'
        ]
        if v.lower() not in supported_types:
            raise ValueError(f'Entity type deve ser um de: {", ".join(supported_types)}')
        return v.lower()
    
    @validator('external_url')
    def validate_url_format(cls, v):
        """Valida formato básico da URL"""
        if v and not (v.startswith('http://') or v.startswith('https://')):
            raise ValueError('URL deve começar com http:// ou https://')
        return v


class ExternalMetadataCreate(ExternalMetadataBase):
    """Schema para criação de External Metadata"""
    pass


class ExternalMetadataUpdate(BaseModel):
    """Schema para atualização de External Metadata"""
    
    name: Optional[str] = Field(
        None,
        description="Nome human-readable do objeto externo",
        min_length=1,
        max_length=255
    )
    
    system_type: Optional[str] = Field(
        None,
        description="Tipo do sistema externo",
        min_length=1,
        max_length=50
    )
    
    entity_type: Optional[str] = Field(
        None,
        description="Tipo da entidade",
        min_length=1,
        max_length=50
    )
    
    external_url: Optional[str] = Field(
        None,
        description="URL do objeto externo",
        max_length=2048
    )
    
    description: Optional[str] = Field(
        None,
        description="Descrição do objeto externo",
        max_length=4000
    )
    
    properties: Optional[Dict[str, Any]] = Field(
        None,
        description="Propriedades customizadas"
    )
    
    is_active: Optional[bool] = Field(
        None,
        description="Status ativo do objeto"
    )
    
    # Aplicar mesmas validações do schema base
    _validate_name = validator('name', allow_reuse=True)(ExternalMetadataBase.validate_name_format)
    _validate_system_type = validator('system_type', allow_reuse=True)(ExternalMetadataBase.validate_system_type)
    _validate_entity_type = validator('entity_type', allow_reuse=True)(ExternalMetadataBase.validate_entity_type)
    _validate_url = validator('external_url', allow_reuse=True)(ExternalMetadataBase.validate_url_format)


class ExternalMetadataResponse(ExternalMetadataBase):
    """Schema para resposta de External Metadata"""
    
    external_metadata_id: UUID = Field(
        ...,
        description="Identificador único do objeto"
    )
    
    unity_catalog_external_id: Optional[str] = Field(
        None,
        description="ID no Unity Catalog External Lineage"
    )
    
    is_active: bool = Field(
        ...,
        description="Status ativo do objeto"
    )
    
    validation_status: str = Field(
        ...,
        description="Status de validação"
    )
    
    last_validated_at: Optional[datetime] = Field(
        None,
        description="Timestamp da última validação"
    )
    
    validated_by: Optional[UUID] = Field(
        None,
        description="Usuário que validou"
    )
    
    last_synced_at: Optional[datetime] = Field(
        None,
        description="Timestamp da última sincronização"
    )
    
    sync_status: str = Field(
        ...,
        description="Status da sincronização"
    )
    
    sync_error_message: Optional[str] = Field(
        None,
        description="Mensagem de erro da sincronização"
    )
    
    created_at: datetime = Field(
        ...,
        description="Timestamp de criação"
    )
    
    updated_at: datetime = Field(
        ...,
        description="Timestamp de atualização"
    )
    
    class Config:
        from_attributes = True


class ExternalColumnMappingBase(BaseModel):
    """Schema base para Column Mapping"""
    
    source_column_name: str = Field(
        ...,
        description="Nome da coluna no sistema externo",
        min_length=1,
        max_length=255
    )
    
    source_column_type: Optional[str] = Field(
        None,
        description="Tipo de dados da coluna externa",
        max_length=100
    )
    
    source_column_description: Optional[str] = Field(
        None,
        description="Descrição da coluna externa",
        max_length=1000
    )
    
    target_property_id: Optional[UUID] = Field(
        None,
        description="ID da propriedade Unity Catalog de destino"
    )
    
    target_column_name: Optional[str] = Field(
        None,
        description="Nome da coluna Unity Catalog",
        max_length=255
    )
    
    transformation_type: Optional[str] = Field(
        None,
        description="Tipo de transformação aplicada",
        max_length=50
    )
    
    transformation_description: Optional[str] = Field(
        None,
        description="Descrição da transformação",
        max_length=2000
    )
    
    transformation_metadata: Optional[Dict[str, Any]] = Field(
        None,
        description="Metadados adicionais da transformação"
    )
    
    @validator('transformation_type')
    def validate_transformation_type(cls, v):
        """Valida tipo de transformação"""
        if v is None:
            return v
        
        supported_types = [
            'direct', 'calculated', 'aggregated', 'concatenated',
            'split', 'formatted', 'converted', 'custom'
        ]
        if v.lower() not in supported_types:
            raise ValueError(f'Transformation type deve ser um de: {", ".join(supported_types)}')
        return v.lower()


class ExternalColumnMappingCreate(ExternalColumnMappingBase):
    """Schema para criação de Column Mapping"""
    
    external_metadata_id: UUID = Field(
        ...,
        description="ID do objeto de metadados externo"
    )


class ExternalColumnMappingResponse(ExternalColumnMappingBase):
    """Schema para resposta de Column Mapping"""
    
    mapping_id: UUID = Field(
        ...,
        description="Identificador único do mapeamento"
    )
    
    external_metadata_id: UUID = Field(
        ...,
        description="ID do objeto de metadados externo"
    )
    
    compatibility_status: str = Field(
        ...,
        description="Status de compatibilidade"
    )
    
    compatibility_notes: Optional[str] = Field(
        None,
        description="Notas sobre compatibilidade"
    )
    
    created_at: datetime = Field(
        ...,
        description="Timestamp de criação"
    )
    
    updated_at: datetime = Field(
        ...,
        description="Timestamp de atualização"
    )
    
    class Config:
        from_attributes = True


class ExternalLineageRelationshipBase(BaseModel):
    """Schema base para Lineage Relationship"""
    
    target_object_type: str = Field(
        ...,
        description="Tipo do objeto Unity Catalog",
        min_length=1,
        max_length=50
    )
    
    target_object_id: str = Field(
        ...,
        description="Identificador do objeto Unity Catalog",
        min_length=1,
        max_length=500
    )
    
    target_object_name: Optional[str] = Field(
        None,
        description="Nome completo do objeto Unity Catalog",
        max_length=500
    )
    
    relationship_direction: str = Field(
        ...,
        description="Direção do relacionamento",
        min_length=1,
        max_length=20
    )
    
    relationship_metadata: Optional[Dict[str, Any]] = Field(
        None,
        description="Metadados adicionais do relacionamento"
    )
    
    relationship_description: Optional[str] = Field(
        None,
        description="Descrição do relacionamento",
        max_length=2000
    )
    
    @validator('target_object_type')
    def validate_target_type(cls, v):
        """Valida tipo de objeto Unity Catalog"""
        supported_types = ['table', 'model', 'path', 'external_metadata']
        if v.lower() not in supported_types:
            raise ValueError(f'Target object type deve ser um de: {", ".join(supported_types)}')
        return v.lower()
    
    @validator('relationship_direction')
    def validate_direction(cls, v):
        """Valida direção do relacionamento"""
        supported_directions = ['upstream', 'downstream']
        if v.lower() not in supported_directions:
            raise ValueError(f'Relationship direction deve ser um de: {", ".join(supported_directions)}')
        return v.lower()


class ExternalLineageRelationshipCreate(ExternalLineageRelationshipBase):
    """Schema para criação de Lineage Relationship"""
    
    external_metadata_id: UUID = Field(
        ...,
        description="ID do objeto de metadados externo"
    )
    
    column_mappings: Optional[List[ExternalColumnMappingCreate]] = Field(
        None,
        description="Mapeamentos de colunas para o relacionamento"
    )


class ExternalLineageRelationshipResponse(ExternalLineageRelationshipBase):
    """Schema para resposta de Lineage Relationship"""
    
    relationship_id: UUID = Field(
        ...,
        description="Identificador único do relacionamento"
    )
    
    external_metadata_id: UUID = Field(
        ...,
        description="ID do objeto de metadados externo"
    )
    
    is_active: bool = Field(
        ...,
        description="Status ativo do relacionamento"
    )
    
    validation_status: str = Field(
        ...,
        description="Status de validação"
    )
    
    validated_by: Optional[UUID] = Field(
        None,
        description="Usuário que validou"
    )
    
    validated_at: Optional[datetime] = Field(
        None,
        description="Timestamp da validação"
    )
    
    created_at: datetime = Field(
        ...,
        description="Timestamp de criação"
    )
    
    updated_at: datetime = Field(
        ...,
        description="Timestamp de atualização"
    )
    
    class Config:
        from_attributes = True


class ExternalMetadataListResponse(BaseModel):
    """Schema para listagem de External Metadata"""
    
    items: List[ExternalMetadataResponse] = Field(
        ...,
        description="Lista de objetos de metadados externos"
    )
    
    total: int = Field(
        ...,
        description="Total de itens"
    )
    
    page: int = Field(
        ...,
        description="Página atual"
    )
    
    size: int = Field(
        ...,
        description="Tamanho da página"
    )
    
    pages: int = Field(
        ...,
        description="Total de páginas"
    )


class ExternalMetadataFilter(BaseModel):
    """Schema para filtros de External Metadata"""
    
    system_type: Optional[str] = Field(
        None,
        description="Filtrar por tipo de sistema"
    )
    
    entity_type: Optional[str] = Field(
        None,
        description="Filtrar por tipo de entidade"
    )
    
    is_active: Optional[bool] = Field(
        None,
        description="Filtrar por status ativo"
    )
    
    validation_status: Optional[str] = Field(
        None,
        description="Filtrar por status de validação"
    )
    
    sync_status: Optional[str] = Field(
        None,
        description="Filtrar por status de sincronização"
    )
    
    search: Optional[str] = Field(
        None,
        description="Busca textual em nome e descrição",
        max_length=255
    )


class SystemTypeInfo(BaseModel):
    """Informações sobre tipos de sistema suportados"""
    
    name: str = Field(..., description="Nome do tipo de sistema")
    display_name: str = Field(..., description="Nome para exibição")
    description: str = Field(..., description="Descrição do sistema")
    supported_entity_types: List[str] = Field(..., description="Tipos de entidade suportados")
    required_properties: List[str] = Field(..., description="Propriedades obrigatórias")
    optional_properties: List[str] = Field(..., description="Propriedades opcionais")


class EntityTypeInfo(BaseModel):
    """Informações sobre tipos de entidade suportados"""
    
    name: str = Field(..., description="Nome do tipo de entidade")
    display_name: str = Field(..., description="Nome para exibição")
    description: str = Field(..., description="Descrição da entidade")
    applicable_systems: List[str] = Field(..., description="Sistemas aplicáveis")


class ExternalMetadataStats(BaseModel):
    """Estatísticas de External Metadata"""
    
    total_objects: int = Field(..., description="Total de objetos")
    by_system_type: Dict[str, int] = Field(..., description="Contagem por tipo de sistema")
    by_entity_type: Dict[str, int] = Field(..., description="Contagem por tipo de entidade")
    by_validation_status: Dict[str, int] = Field(..., description="Contagem por status de validação")
    by_sync_status: Dict[str, int] = Field(..., description="Contagem por status de sincronização")
    total_relationships: int = Field(..., description="Total de relacionamentos")
    total_column_mappings: int = Field(..., description="Total de mapeamentos de colunas")

