"""
Integração com Informatica Axon
Autor: Carlos Morais

Integração completa com Informatica Axon para
sincronização de glossário de negócios e metadados.
"""

import json
import requests
from typing import Dict, List, Optional, Any
from datetime import datetime
from dataclasses import dataclass

from ..utils.exceptions import DataGovernanceException
from ..utils.observability import trace_operation
from ..utils.audit import audit_logger, AuditEventType


@dataclass
class AxonConfig:
    """Configuração do Informatica Axon"""
    base_url: str
    username: str
    password: str
    domain: str
    timeout: int = 30
    max_retries: int = 3


class InformaticaAxonIntegration:
    """Integração com Informatica Axon"""
    
    def __init__(self, config: AxonConfig):
        self.config = config
        self.base_url = f"{config.base_url}/axonhome/public/api/v2"
        self.session_token = None
        self._authenticate()
    
    def _authenticate(self):
        """Autentica com Informatica Axon"""
        try:
            auth_data = {
                "username": self.config.username,
                "password": self.config.password,
                "domain": self.config.domain
            }
            
            response = requests.post(
                f"{self.base_url}/auth/login",
                json=auth_data,
                timeout=self.config.timeout
            )
            response.raise_for_status()
            
            auth_result = response.json()
            self.session_token = auth_result.get("sessionToken")
            
            if not self.session_token:
                raise DataGovernanceException("Falha na autenticação com Axon")
                
        except requests.RequestException as e:
            raise DataGovernanceException(f"Erro na autenticação Axon: {str(e)}")
    
    def _get_headers(self) -> Dict[str, str]:
        """Obtém headers para requisições"""
        return {
            "Authorization": f"Bearer {self.session_token}",
            "Content-Type": "application/json"
        }
    
    @trace_operation("axon.sync_business_glossary", "integration")
    def sync_business_glossary(self) -> Dict[str, Any]:
        """
        Sincroniza glossário de negócios do Axon
        
        Returns:
            Resultado da sincronização
        """
        try:
            # Buscar termos do glossário
            terms = self._get_business_terms()
            
            # Buscar categorias
            categories = self._get_categories()
            
            # Buscar relacionamentos
            relationships = self._get_term_relationships()
            
            sync_result = {
                "timestamp": datetime.utcnow().isoformat(),
                "terms_count": len(terms),
                "categories_count": len(categories),
                "relationships_count": len(relationships),
                "status": "success"
            }
            
            # Registrar auditoria
            audit_logger.log_event({
                "event_type": AuditEventType.SYNC,
                "resource_type": "axon_glossary",
                "action": "glossary_sync",
                "details": sync_result
            })
            
            return sync_result
            
        except Exception as e:
            raise DataGovernanceException(f"Erro na sincronização Axon: {str(e)}")
    
    def _get_business_terms(self) -> List[Dict[str, Any]]:
        """Busca termos do glossário de negócios"""
        try:
            response = requests.get(
                f"{self.base_url}/glossary/terms",
                headers=self._get_headers(),
                timeout=self.config.timeout
            )
            response.raise_for_status()
            
            data = response.json()
            return data.get("terms", [])
            
        except requests.RequestException as e:
            raise DataGovernanceException(f"Erro ao buscar termos: {str(e)}")
    
    def _get_categories(self) -> List[Dict[str, Any]]:
        """Busca categorias do glossário"""
        try:
            response = requests.get(
                f"{self.base_url}/glossary/categories",
                headers=self._get_headers(),
                timeout=self.config.timeout
            )
            response.raise_for_status()
            
            data = response.json()
            return data.get("categories", [])
            
        except requests.RequestException as e:
            raise DataGovernanceException(f"Erro ao buscar categorias: {str(e)}")
    
    def _get_term_relationships(self) -> List[Dict[str, Any]]:
        """Busca relacionamentos entre termos"""
        try:
            response = requests.get(
                f"{self.base_url}/glossary/relationships",
                headers=self._get_headers(),
                timeout=self.config.timeout
            )
            response.raise_for_status()
            
            data = response.json()
            return data.get("relationships", [])
            
        except requests.RequestException as e:
            raise DataGovernanceException(f"Erro ao buscar relacionamentos: {str(e)}")
    
    @trace_operation("axon.create_business_term", "integration")
    def create_business_term(self, term_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Cria termo no glossário de negócios
        
        Args:
            term_data: Dados do termo
            
        Returns:
            Resultado da criação
        """
        try:
            response = requests.post(
                f"{self.base_url}/glossary/terms",
                headers=self._get_headers(),
                json=term_data,
                timeout=self.config.timeout
            )
            response.raise_for_status()
            
            result = response.json()
            
            # Registrar auditoria
            audit_logger.log_event({
                "event_type": AuditEventType.CREATE,
                "resource_type": "axon_term",
                "resource_id": result.get("id"),
                "action": "term_created",
                "details": {"term_name": term_data.get("name")}
            })
            
            return result
            
        except requests.RequestException as e:
            raise DataGovernanceException(f"Erro ao criar termo: {str(e)}")
    
    @trace_operation("axon.link_data_asset", "integration")
    def link_data_asset(self, term_id: str, asset_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Vincula ativo de dados a termo do glossário
        
        Args:
            term_id: ID do termo
            asset_data: Dados do ativo
            
        Returns:
            Resultado da vinculação
        """
        try:
            link_data = {
                "termId": term_id,
                "assetType": asset_data.get("type", "table"),
                "assetName": asset_data.get("name"),
                "assetPath": asset_data.get("path"),
                "linkType": "implements"
            }
            
            response = requests.post(
                f"{self.base_url}/glossary/terms/{term_id}/assets",
                headers=self._get_headers(),
                json=link_data,
                timeout=self.config.timeout
            )
            response.raise_for_status()
            
            result = response.json()
            
            # Registrar auditoria
            audit_logger.log_event({
                "event_type": AuditEventType.LINK,
                "resource_type": "axon_asset_link",
                "resource_id": f"{term_id}_{asset_data.get('name')}",
                "action": "asset_linked",
                "details": {
                    "term_id": term_id,
                    "asset_name": asset_data.get("name")
                }
            })
            
            return result
            
        except requests.RequestException as e:
            raise DataGovernanceException(f"Erro ao vincular ativo: {str(e)}")
    
    @trace_operation("axon.get_data_lineage", "integration")
    def get_data_lineage(self, asset_id: str) -> Dict[str, Any]:
        """
        Obtém linhagem de dados do Axon
        
        Args:
            asset_id: ID do ativo
            
        Returns:
            Informações de linhagem
        """
        try:
            response = requests.get(
                f"{self.base_url}/lineage/assets/{asset_id}",
                headers=self._get_headers(),
                timeout=self.config.timeout
            )
            response.raise_for_status()
            
            return response.json()
            
        except requests.RequestException as e:
            raise DataGovernanceException(f"Erro ao obter linhagem: {str(e)}")
    
    @trace_operation("axon.create_data_policy", "integration")
    def create_data_policy(self, policy_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Cria política de dados no Axon
        
        Args:
            policy_data: Dados da política
            
        Returns:
            Resultado da criação
        """
        try:
            response = requests.post(
                f"{self.base_url}/policies",
                headers=self._get_headers(),
                json=policy_data,
                timeout=self.config.timeout
            )
            response.raise_for_status()
            
            result = response.json()
            
            # Registrar auditoria
            audit_logger.log_event({
                "event_type": AuditEventType.CREATE,
                "resource_type": "axon_policy",
                "resource_id": result.get("id"),
                "action": "policy_created",
                "details": {"policy_name": policy_data.get("name")}
            })
            
            return result
            
        except requests.RequestException as e:
            raise DataGovernanceException(f"Erro ao criar política: {str(e)}")
    
    @trace_operation("axon.validate_data_quality", "integration")
    def validate_data_quality(self, asset_id: str) -> Dict[str, Any]:
        """
        Valida qualidade de dados via Axon
        
        Args:
            asset_id: ID do ativo
            
        Returns:
            Resultado da validação
        """
        try:
            response = requests.get(
                f"{self.base_url}/quality/assets/{asset_id}/validation",
                headers=self._get_headers(),
                timeout=self.config.timeout
            )
            response.raise_for_status()
            
            return response.json()
            
        except requests.RequestException as e:
            raise DataGovernanceException(f"Erro na validação de qualidade: {str(e)}")
    
    @trace_operation("axon.get_stewardship_assignments", "integration")
    def get_stewardship_assignments(self) -> Dict[str, Any]:
        """
        Obtém atribuições de stewardship
        
        Returns:
            Atribuições de stewardship
        """
        try:
            response = requests.get(
                f"{self.base_url}/stewardship/assignments",
                headers=self._get_headers(),
                timeout=self.config.timeout
            )
            response.raise_for_status()
            
            return response.json()
            
        except requests.RequestException as e:
            raise DataGovernanceException(f"Erro ao obter stewardship: {str(e)}")
    
    @trace_operation("axon.create_stewardship_task", "integration")
    def create_stewardship_task(self, task_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Cria tarefa de stewardship
        
        Args:
            task_data: Dados da tarefa
            
        Returns:
            Resultado da criação
        """
        try:
            response = requests.post(
                f"{self.base_url}/stewardship/tasks",
                headers=self._get_headers(),
                json=task_data,
                timeout=self.config.timeout
            )
            response.raise_for_status()
            
            result = response.json()
            
            # Registrar auditoria
            audit_logger.log_event({
                "event_type": AuditEventType.CREATE,
                "resource_type": "axon_stewardship_task",
                "resource_id": result.get("id"),
                "action": "task_created",
                "details": {"task_type": task_data.get("type")}
            })
            
            return result
            
        except requests.RequestException as e:
            raise DataGovernanceException(f"Erro ao criar tarefa: {str(e)}")
    
    @trace_operation("axon.export_glossary", "integration")
    def export_glossary(self, format: str = "json") -> Dict[str, Any]:
        """
        Exporta glossário de negócios
        
        Args:
            format: Formato de exportação (json, csv, excel)
            
        Returns:
            Dados exportados
        """
        try:
            response = requests.get(
                f"{self.base_url}/glossary/export",
                headers=self._get_headers(),
                params={"format": format},
                timeout=self.config.timeout
            )
            response.raise_for_status()
            
            if format == "json":
                return response.json()
            else:
                return {
                    "format": format,
                    "content": response.content.decode(),
                    "size_bytes": len(response.content)
                }
                
        except requests.RequestException as e:
            raise DataGovernanceException(f"Erro na exportação: {str(e)}")
    
    @trace_operation("axon.import_data_contracts", "integration")
    def import_data_contracts(self, contracts: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Importa contratos de dados para o Axon
        
        Args:
            contracts: Lista de contratos
            
        Returns:
            Resultado da importação
        """
        try:
            import_data = {
                "contracts": contracts,
                "import_mode": "merge",
                "validate_before_import": True
            }
            
            response = requests.post(
                f"{self.base_url}/contracts/import",
                headers=self._get_headers(),
                json=import_data,
                timeout=self.config.timeout * 2  # Timeout maior para importação
            )
            response.raise_for_status()
            
            result = response.json()
            
            # Registrar auditoria
            audit_logger.log_event({
                "event_type": AuditEventType.IMPORT,
                "resource_type": "axon_contracts",
                "action": "contracts_imported",
                "details": {
                    "contracts_count": len(contracts),
                    "import_status": result.get("status")
                }
            })
            
            return result
            
        except requests.RequestException as e:
            raise DataGovernanceException(f"Erro na importação: {str(e)}")
    
    def health_check(self) -> Dict[str, Any]:
        """
        Verifica conectividade com Informatica Axon
        
        Returns:
            Status da conexão
        """
        try:
            response = requests.get(
                f"{self.base_url}/health",
                headers=self._get_headers(),
                timeout=5
            )
            response.raise_for_status()
            
            return {
                "status": "healthy",
                "response_time_ms": response.elapsed.total_seconds() * 1000,
                "base_url": self.config.base_url,
                "domain": self.config.domain
            }
            
        except Exception as e:
            return {
                "status": "unhealthy",
                "error": str(e),
                "base_url": self.config.base_url
            }

