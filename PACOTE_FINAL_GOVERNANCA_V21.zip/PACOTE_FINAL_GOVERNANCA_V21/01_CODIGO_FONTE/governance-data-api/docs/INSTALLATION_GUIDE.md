# Guia de Instalação - API de Governança de Dados

## 📋 Pré-requisitos

### Sistema Operacional
- **Windows 11** (versão 21H2 ou superior)
- **RAM**: Mínimo 8GB, recomendado 16GB
- **Disco**: Mínimo 10GB livres
- **CPU**: 4 cores recomendado

### Software Necessário

#### 1. Python 3.14
```powershell
# Verificar se Python 3.14 está instalado
python --version

# Se não estiver instalado, baixar de:
# https://www.python.org/downloads/
```

#### 2. PostgreSQL 15+
```powershell
# Download: https://www.postgresql.org/download/windows/
# Durante a instalação:
# - Porta: 5432 (padrão)
# - Usuário: postgres
# - Senha: definir uma senha segura
```

#### 3. Redis 7+
```powershell
# Opção 1: Redis para Windows
# Download: https://github.com/microsoftarchive/redis/releases

# Opção 2: Docker Desktop (recomendado)
# Download: https://www.docker.com/products/docker-desktop/
# Executar: docker run -d -p 6379:6379 redis:7-alpine
```

#### 4. Git
```powershell
# Download: https://git-scm.com/download/win
# Verificar instalação:
git --version
```

## 🚀 Instalação Automática

### 1. Clone o Repositório
```powershell
# Abrir PowerShell como Administrador
git clone <repository-url>
cd governance-data-api
```

### 2. Executar Setup Automático
```powershell
# Executar script de setup
.\scripts\windows\setup.ps1

# O script irá:
# ✅ Verificar Python 3.14
# ✅ Criar ambiente virtual
# ✅ Instalar dependências
# ✅ Configurar PostgreSQL
# ✅ Configurar Redis
# ✅ Criar banco de dados
# ✅ Executar migrações
# ✅ Configurar variáveis de ambiente
```

### 3. Verificar Instalação
```powershell
# Ativar ambiente virtual
.\venv\Scripts\Activate.ps1

# Executar testes
.\scripts\windows\test.ps1

# Iniciar servidor
.\scripts\windows\run.ps1
```

## 🔧 Instalação Manual

### 1. Configurar Ambiente Python

#### Criar Ambiente Virtual
```powershell
# Verificar Python 3.14
python --version

# Criar ambiente virtual
python -m venv venv

# Ativar ambiente virtual
.\venv\Scripts\Activate.ps1

# Atualizar pip
python -m pip install --upgrade pip
```

#### Instalar Dependências
```powershell
# Instalar dependências principais
pip install -r requirements.txt

# Instalar dependências de desenvolvimento
pip install -r requirements-dev.txt
```

### 2. Configurar PostgreSQL

#### Criar Banco de Dados
```sql
-- Conectar ao PostgreSQL como postgres
psql -U postgres

-- Criar banco de dados
CREATE DATABASE governance_data_api;

-- Criar usuário
CREATE USER governance_user WITH PASSWORD 'governance_password';

-- Conceder privilégios
GRANT ALL PRIVILEGES ON DATABASE governance_data_api TO governance_user;

-- Sair
\q
```

#### Configurar Conexão
```powershell
# Editar arquivo .env
notepad .env

# Configurar variáveis:
DATABASE_URL=postgresql://governance_user:governance_password@localhost:5432/governance_data_api
```

### 3. Configurar Redis

#### Iniciar Redis
```powershell
# Opção 1: Redis nativo
redis-server

# Opção 2: Docker
docker run -d --name redis -p 6379:6379 redis:7-alpine

# Verificar conexão
redis-cli ping
# Resposta esperada: PONG
```

### 4. Configurar Variáveis de Ambiente

#### Criar arquivo .env
```powershell
# Copiar exemplo
copy .env.example .env

# Editar configurações
notepad .env
```

#### Configurações Principais
```env
# Database
DATABASE_URL=postgresql://governance_user:governance_password@localhost:5432/governance_data_api
DATABASE_POOL_SIZE=20
DATABASE_MAX_OVERFLOW=30

# Redis
REDIS_URL=redis://localhost:6379/0
REDIS_CACHE_TTL=3600

# Security
SECRET_KEY=your-super-secret-key-here
JWT_SECRET_KEY=your-jwt-secret-key-here
JWT_ALGORITHM=HS256
JWT_EXPIRATION_HOURS=24

# API
API_HOST=0.0.0.0
API_PORT=8000
API_DEBUG=true
API_RELOAD=true

# Logging
LOG_LEVEL=INFO
LOG_FORMAT=json

# External Services
UNITY_CATALOG_URL=https://your-unity-catalog.com
UNITY_CATALOG_TOKEN=your-token

# Monitoring
PROMETHEUS_ENABLED=true
HEALTH_CHECK_INTERVAL=30

# Rate Limiting
RATE_LIMIT_PER_MINUTE=100
RATE_LIMIT_BURST=200
```

### 5. Executar Migrações

#### Configurar Alembic
```powershell
# Gerar migração inicial
alembic revision --autogenerate -m "Initial migration"

# Executar migrações
alembic upgrade head
```

#### Verificar Tabelas
```sql
-- Conectar ao banco
psql -U governance_user -d governance_data_api

-- Listar tabelas
\dt

-- Verificar algumas tabelas principais
SELECT COUNT(*) FROM data_contracts;
SELECT COUNT(*) FROM entities;
SELECT COUNT(*) FROM quality_rules;
```

## 🧪 Testes e Validação

### 1. Executar Testes
```powershell
# Todos os testes com cobertura
.\scripts\windows\test.ps1 -Coverage

# Apenas testes unitários
.\scripts\windows\test.ps1 -TestType unit

# Testes de integração
.\scripts\windows\test.ps1 -TestType integration
```

### 2. Verificar Cobertura
```powershell
# Abrir relatório de cobertura
start htmlcov\index.html

# Meta: 90%+ de cobertura
```

### 3. Testes de Performance
```powershell
# Executar testes de carga
python -m pytest tests/performance/ -v

# Verificar métricas
curl http://localhost:8000/metrics
```

## 🚀 Execução

### 1. Modo Desenvolvimento
```powershell
# Iniciar com reload automático
.\scripts\windows\run.ps1 -Environment development

# Ou manualmente:
uvicorn src.governance_api.main:app --host 0.0.0.0 --port 8000 --reload
```

### 2. Modo Produção
```powershell
# Iniciar para produção
.\scripts\windows\run.ps1 -Environment production -Port 8000

# Ou manualmente:
uvicorn src.governance_api.main:app --host 0.0.0.0 --port 8000 --workers 4
```

### 3. Verificar Funcionamento
```powershell
# Health check
curl http://localhost:8000/health

# Documentação
start http://localhost:8000/docs

# Métricas
curl http://localhost:8000/metrics
```

## 🔍 Solução de Problemas

### Problemas Comuns

#### 1. Erro de Conexão com PostgreSQL
```powershell
# Verificar se PostgreSQL está rodando
Get-Service postgresql*

# Iniciar serviço se necessário
Start-Service postgresql-x64-15

# Testar conexão
psql -U postgres -h localhost -p 5432
```

#### 2. Erro de Conexão com Redis
```powershell
# Verificar se Redis está rodando
redis-cli ping

# Se usando Docker:
docker ps | findstr redis
docker start redis
```

#### 3. Erro de Dependências Python
```powershell
# Recriar ambiente virtual
Remove-Item -Recurse -Force venv
python -m venv venv
.\venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

#### 4. Erro de Migrações
```powershell
# Reset do banco (CUIDADO: apaga dados)
alembic downgrade base
alembic upgrade head

# Ou recriar banco:
dropdb -U postgres governance_data_api
createdb -U postgres governance_data_api
alembic upgrade head
```

### Logs e Debugging

#### Verificar Logs
```powershell
# Logs da aplicação
Get-Content logs\app.log -Tail 50

# Logs do PostgreSQL
Get-Content "C:\Program Files\PostgreSQL\15\data\log\*.log" -Tail 50
```

#### Debug Mode
```powershell
# Executar com debug
$env:LOG_LEVEL="DEBUG"
.\scripts\windows\run.ps1 -Environment development
```

## 📊 Monitoramento

### 1. Health Checks
```powershell
# Status geral
curl http://localhost:8000/health

# Status detalhado
curl http://localhost:8000/health/detailed

# Status do banco
curl http://localhost:8000/health/database

# Status do Redis
curl http://localhost:8000/health/redis
```

### 2. Métricas
```powershell
# Métricas Prometheus
curl http://localhost:8000/metrics

# Métricas customizadas
curl "http://localhost:8000/api/v1/monitoring/metrics?metric=request_count"
```

### 3. Performance
```powershell
# Verificar uso de recursos
Get-Process python

# Monitorar conexões de banco
# No PostgreSQL:
SELECT count(*) FROM pg_stat_activity WHERE datname = 'governance_data_api';
```

## 🔐 Segurança

### 1. Configurações de Segurança
```env
# Gerar chaves seguras
SECRET_KEY=$(python -c "import secrets; print(secrets.token_urlsafe(32))")
JWT_SECRET_KEY=$(python -c "import secrets; print(secrets.token_urlsafe(32))")
```

### 2. Firewall
```powershell
# Permitir porta da API
New-NetFirewallRule -DisplayName "API Governance" -Direction Inbound -Port 8000 -Protocol TCP -Action Allow
```

### 3. SSL/TLS (Produção)
```powershell
# Para produção, configurar certificado SSL
# Editar .env:
# SSL_CERT_FILE=path/to/cert.pem
# SSL_KEY_FILE=path/to/key.pem
```

## 📚 Próximos Passos

1. **Configurar Backup**:
   - Backup automático do PostgreSQL
   - Backup das configurações

2. **Monitoramento Avançado**:
   - Configurar Grafana
   - Alertas por email/Slack

3. **Integração**:
   - Conectar com Unity Catalog
   - Configurar webhooks

4. **Produção**:
   - Load balancer
   - Alta disponibilidade
   - Disaster recovery

## 📞 Suporte

Para problemas durante a instalação:

1. Verificar logs de erro
2. Consultar seção de solução de problemas
3. Abrir issue no repositório
4. Contatar equipe de suporte

---

**Instalação concluída com sucesso!** 🎉

A API de Governança de Dados está pronta para uso em Windows 11 com Python 3.14.

