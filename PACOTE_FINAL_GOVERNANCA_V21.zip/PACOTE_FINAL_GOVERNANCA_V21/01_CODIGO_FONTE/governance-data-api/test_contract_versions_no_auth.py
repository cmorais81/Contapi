#!/usr/bin/env python3
"""
Teste de Versionamento de Contratos de Dados - Sem Autenticação
Desenvolvido por: Carlos Morais
Data: Janeiro 2025
"""

import requests
import json
import uuid
from datetime import datetime
import time

class ContractVersionTester:
    def __init__(self, base_url="http://localhost:8001"):
        self.base_url = base_url
        self.headers = {"Content-Type": "application/json"}
        self.test_results = []
        
    def log_result(self, test_name, success, details):
        """Log do resultado do teste"""
        result = {
            "test_name": test_name,
            "success": success,
            "details": details,
            "timestamp": datetime.now().isoformat()
        }
        self.test_results.append(result)
        status = "✅" if success else "❌"
        print(f"{status} {test_name}: {details}")
    
    def test_health_endpoint(self):
        """Testar endpoint de health"""
        try:
            response = requests.get(f"{self.base_url}/health", timeout=5)
            if response.status_code == 200:
                health_data = response.json()
                self.log_result("Health Check", True, f"Status: {health_data.get('status', 'N/A')}")
                return True
            else:
                self.log_result("Health Check", False, f"Status: {response.status_code}")
                return False
        except Exception as e:
            self.log_result("Health Check", False, f"Erro: {str(e)}")
            return False
    
    def test_docs_endpoint(self):
        """Testar endpoint de documentação"""
        try:
            response = requests.get(f"{self.base_url}/docs", timeout=5)
            if response.status_code == 200:
                self.log_result("Documentação", True, "Swagger UI acessível")
                return True
            else:
                self.log_result("Documentação", False, f"Status: {response.status_code}")
                return False
        except Exception as e:
            self.log_result("Documentação", False, f"Erro: {str(e)}")
            return False
    
    def test_openapi_schema(self):
        """Testar schema OpenAPI"""
        try:
            response = requests.get(f"{self.base_url}/openapi.json", timeout=5)
            if response.status_code == 200:
                schema = response.json()
                paths_count = len(schema.get('paths', {}))
                self.log_result("Schema OpenAPI", True, f"{paths_count} endpoints documentados")
                return schema
            else:
                self.log_result("Schema OpenAPI", False, f"Status: {response.status_code}")
                return None
        except Exception as e:
            self.log_result("Schema OpenAPI", False, f"Erro: {str(e)}")
            return None
    
    def analyze_contract_endpoints(self, schema):
        """Analisar endpoints de contratos no schema"""
        if not schema:
            return
        
        paths = schema.get('paths', {})
        contract_endpoints = [path for path in paths.keys() if 'contracts' in path]
        
        print(f"\n📋 ENDPOINTS DE CONTRATOS DISPONÍVEIS:")
        print("-" * 50)
        
        for endpoint in contract_endpoints:
            methods = list(paths[endpoint].keys())
            print(f"🔗 {endpoint}")
            for method in methods:
                operation = paths[endpoint][method]
                summary = operation.get('summary', 'Sem descrição')
                print(f"   {method.upper()}: {summary}")
        
        self.log_result("Análise de Endpoints", True, f"{len(contract_endpoints)} endpoints de contratos encontrados")
    
    def simulate_contract_v1_structure(self):
        """Simular estrutura do contrato V1"""
        contract_v1 = {
            "name": "customer_data_contract_v1",
            "description": "Contrato de dados de clientes - Versão 1.0",
            "version": "1.0.0",
            "domain": "customer_domain",
            "steward": "data_team",
            "status": "active",
            "unity_catalog_path": "prod.customer.customer_data_v1",
            "schema_definition": {
                "type": "object",
                "properties": {
                    "customer_id": {
                        "type": "integer",
                        "description": "ID único do cliente"
                    },
                    "name": {
                        "type": "string",
                        "description": "Nome completo do cliente"
                    },
                    "email": {
                        "type": "string",
                        "format": "email",
                        "description": "Email do cliente"
                    },
                    "created_at": {
                        "type": "string",
                        "format": "date-time",
                        "description": "Data de criação do registro"
                    }
                },
                "required": ["customer_id", "name", "email"]
            },
            "quality_rules": [
                {
                    "field": "email",
                    "rule": "format_validation",
                    "description": "Email deve ter formato válido"
                },
                {
                    "field": "customer_id",
                    "rule": "uniqueness",
                    "description": "ID do cliente deve ser único"
                }
            ],
            "sla_definition": {
                "availability": "99.9%",
                "freshness": "24h",
                "completeness": "95%"
            }
        }
        
        self.log_result("Estrutura Contrato V1", True, "Estrutura simulada criada")
        return contract_v1
    
    def simulate_contract_v2_structure(self):
        """Simular estrutura do contrato V2 (evolução)"""
        contract_v2 = {
            "name": "customer_data_contract_v2",
            "description": "Contrato de dados de clientes - Versão 2.0 (Evoluído)",
            "version": "2.0.0",
            "domain": "customer_domain",
            "steward": "data_team",
            "status": "active",
            "unity_catalog_path": "prod.customer.customer_data_v2",
            "schema_definition": {
                "type": "object",
                "properties": {
                    "customer_id": {
                        "type": "integer",
                        "description": "ID único do cliente"
                    },
                    "name": {
                        "type": "string",
                        "description": "Nome completo do cliente"
                    },
                    "email": {
                        "type": "string",
                        "format": "email",
                        "description": "Email do cliente"
                    },
                    "phone": {
                        "type": "string",
                        "description": "Telefone do cliente (novo campo)"
                    },
                    "address": {
                        "type": "object",
                        "properties": {
                            "street": {"type": "string"},
                            "city": {"type": "string"},
                            "country": {"type": "string"},
                            "postal_code": {"type": "string"}
                        },
                        "description": "Endereço completo do cliente (novo campo)"
                    },
                    "status": {
                        "type": "string",
                        "enum": ["active", "inactive", "suspended"],
                        "description": "Status do cliente (novo campo)"
                    },
                    "created_at": {
                        "type": "string",
                        "format": "date-time",
                        "description": "Data de criação do registro"
                    },
                    "updated_at": {
                        "type": "string",
                        "format": "date-time",
                        "description": "Data de última atualização (novo campo)"
                    }
                },
                "required": ["customer_id", "name", "email", "status"]
            },
            "quality_rules": [
                {
                    "field": "email",
                    "rule": "format_validation",
                    "description": "Email deve ter formato válido"
                },
                {
                    "field": "customer_id",
                    "rule": "uniqueness",
                    "description": "ID do cliente deve ser único"
                },
                {
                    "field": "phone",
                    "rule": "format_validation",
                    "description": "Telefone deve ter formato válido (novo)"
                },
                {
                    "field": "status",
                    "rule": "enum_validation",
                    "description": "Status deve ser um dos valores permitidos (novo)"
                }
            ],
            "sla_definition": {
                "availability": "99.95%",
                "freshness": "12h",
                "completeness": "98%",
                "accuracy": "99%"
            }
        }
        
        self.log_result("Estrutura Contrato V2", True, "Estrutura simulada criada")
        return contract_v2
    
    def compare_contract_versions(self, contract_v1, contract_v2):
        """Comparar as duas versões de contrato"""
        print("\n🔍 COMPARAÇÃO ENTRE VERSÕES:")
        print("-" * 50)
        
        # Comparar schemas
        schema_v1 = contract_v1.get('schema_definition', {}).get('properties', {})
        schema_v2 = contract_v2.get('schema_definition', {}).get('properties', {})
        
        fields_v1 = set(schema_v1.keys())
        fields_v2 = set(schema_v2.keys())
        
        new_fields = fields_v2 - fields_v1
        removed_fields = fields_v1 - fields_v2
        common_fields = fields_v1 & fields_v2
        
        print(f"📊 Campos V1: {len(fields_v1)} ({', '.join(sorted(fields_v1))})")
        print(f"📊 Campos V2: {len(fields_v2)} ({', '.join(sorted(fields_v2))})")
        print(f"🆕 Novos campos: {len(new_fields)} ({', '.join(sorted(new_fields))})")
        print(f"❌ Campos removidos: {len(removed_fields)} ({', '.join(sorted(removed_fields))})")
        print(f"🔄 Campos comuns: {len(common_fields)}")
        
        # Comparar regras de qualidade
        rules_v1 = len(contract_v1.get('quality_rules', []))
        rules_v2 = len(contract_v2.get('quality_rules', []))
        
        print(f"📋 Regras V1: {rules_v1}")
        print(f"📋 Regras V2: {rules_v2}")
        
        # Comparar SLAs
        sla_v1 = contract_v1.get('sla_definition', {})
        sla_v2 = contract_v2.get('sla_definition', {})
        
        print(f"⚡ SLA V1: Disponibilidade {sla_v1.get('availability')}, Freshness {sla_v1.get('freshness')}")
        print(f"⚡ SLA V2: Disponibilidade {sla_v2.get('availability')}, Freshness {sla_v2.get('freshness')}")
        
        # Análise de compatibilidade
        compatibility_issues = []
        
        if removed_fields:
            compatibility_issues.append(f"Campos removidos: {', '.join(removed_fields)}")
        
        required_v1 = set(contract_v1.get('schema_definition', {}).get('required', []))
        required_v2 = set(contract_v2.get('schema_definition', {}).get('required', []))
        
        new_required = required_v2 - required_v1
        if new_required:
            compatibility_issues.append(f"Novos campos obrigatórios: {', '.join(new_required)}")
        
        if compatibility_issues:
            print(f"⚠️ Problemas de compatibilidade: {'; '.join(compatibility_issues)}")
            self.log_result("Análise de Compatibilidade", False, f"{len(compatibility_issues)} problemas encontrados")
        else:
            print("✅ Versões são compatíveis (backward compatible)")
            self.log_result("Análise de Compatibilidade", True, "Versões compatíveis")
        
        self.log_result("Comparação de Versões", True, f"V1: {len(fields_v1)} campos, V2: {len(fields_v2)} campos")
    
    def generate_version_diff_report(self, contract_v1, contract_v2):
        """Gerar relatório detalhado de diferenças"""
        diff_report = {
            "comparison_timestamp": datetime.now().isoformat(),
            "version_1": {
                "name": contract_v1.get('name'),
                "version": contract_v1.get('version'),
                "fields_count": len(contract_v1.get('schema_definition', {}).get('properties', {})),
                "quality_rules_count": len(contract_v1.get('quality_rules', [])),
                "sla": contract_v1.get('sla_definition', {})
            },
            "version_2": {
                "name": contract_v2.get('name'),
                "version": contract_v2.get('version'),
                "fields_count": len(contract_v2.get('schema_definition', {}).get('properties', {})),
                "quality_rules_count": len(contract_v2.get('quality_rules', [])),
                "sla": contract_v2.get('sla_definition', {})
            },
            "differences": {
                "new_fields": list(set(contract_v2.get('schema_definition', {}).get('properties', {}).keys()) - 
                                 set(contract_v1.get('schema_definition', {}).get('properties', {}).keys())),
                "removed_fields": list(set(contract_v1.get('schema_definition', {}).get('properties', {}).keys()) - 
                                     set(contract_v2.get('schema_definition', {}).get('properties', {}).keys())),
                "quality_rules_diff": len(contract_v2.get('quality_rules', [])) - len(contract_v1.get('quality_rules', []))
            }
        }
        
        with open("contract_version_diff_report.json", "w") as f:
            json.dump(diff_report, f, indent=2)
        
        print(f"\n📁 Relatório de diferenças salvo em: contract_version_diff_report.json")
        self.log_result("Relatório de Diferenças", True, "Relatório gerado com sucesso")
    
    def run_all_tests(self):
        """Executar todos os testes de versionamento"""
        print("🚀 Iniciando Testes de Versionamento de Contratos (Simulação)")
        print("=" * 70)
        
        # 1. Testar endpoints básicos
        if not self.test_health_endpoint():
            print("❌ API não está funcionando. Abortando testes.")
            return False
        
        self.test_docs_endpoint()
        schema = self.test_openapi_schema()
        
        # 2. Analisar endpoints disponíveis
        self.analyze_contract_endpoints(schema)
        
        # 3. Simular estruturas de contratos
        contract_v1 = self.simulate_contract_v1_structure()
        contract_v2 = self.simulate_contract_v2_structure()
        
        # 4. Comparar versões
        self.compare_contract_versions(contract_v1, contract_v2)
        
        # 5. Gerar relatório de diferenças
        self.generate_version_diff_report(contract_v1, contract_v2)
        
        # 6. Gerar relatório final
        self.generate_report()
        
        return True
    
    def generate_report(self):
        """Gerar relatório dos testes"""
        print("\n" + "=" * 70)
        print("📊 RELATÓRIO DE TESTES DE VERSIONAMENTO (SIMULAÇÃO)")
        print("=" * 70)
        
        total_tests = len(self.test_results)
        successful_tests = sum(1 for result in self.test_results if result['success'])
        failed_tests = total_tests - successful_tests
        
        print(f"📋 Total de Testes: {total_tests}")
        print(f"✅ Sucessos: {successful_tests}")
        print(f"❌ Falhas: {failed_tests}")
        print(f"📊 Taxa de Sucesso: {(successful_tests/total_tests)*100:.1f}%")
        
        print("\n📝 Detalhes dos Testes:")
        for result in self.test_results:
            status = "✅" if result['success'] else "❌"
            print(f"  {status} {result['test_name']}: {result['details']}")
        
        # Salvar relatório em arquivo
        report_data = {
            "summary": {
                "total_tests": total_tests,
                "successful_tests": successful_tests,
                "failed_tests": failed_tests,
                "success_rate": (successful_tests/total_tests)*100 if total_tests > 0 else 0
            },
            "test_results": self.test_results,
            "generated_at": datetime.now().isoformat(),
            "test_type": "simulation"
        }
        
        with open("contract_version_simulation_report.json", "w") as f:
            json.dump(report_data, f, indent=2)
        
        print(f"\n📁 Relatório salvo em: contract_version_simulation_report.json")

def main():
    """Função principal"""
    tester = ContractVersionTester()
    
    # Executar testes
    success = tester.run_all_tests()
    
    if success:
        print("\n🎉 Testes de versionamento (simulação) concluídos!")
        print("📋 Arquivos gerados:")
        print("   - contract_version_simulation_report.json")
        print("   - contract_version_diff_report.json")
    else:
        print("\n⚠️ Testes concluídos com problemas.")

if __name__ == "__main__":
    main()

