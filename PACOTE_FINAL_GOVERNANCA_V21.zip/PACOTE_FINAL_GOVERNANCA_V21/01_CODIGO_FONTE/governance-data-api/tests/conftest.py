"""
Configurações e fixtures para testes
"""

import asyncio
import os
import pytest
import pytest_asyncio
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker
from unittest.mock import AsyncMock, MagicMock

from governance_api.config.settings import get_settings
from governance_api.database.connection import Base, get_db_session
from governance_api.database.models import *
from governance_api.main import app

# Configurar ambiente de teste
os.environ["ENVIRONMENT"] = "test"
os.environ["DATABASE_URL"] = "sqlite+aiosqlite:///./test.db"
os.environ["REDIS_URL"] = "redis://localhost:6379/1"

settings = get_settings()


@pytest.fixture(scope="session")
def event_loop():
    """Cria event loop para testes assíncronos"""
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()


@pytest_asyncio.fixture(scope="session")
async def test_engine():
    """Engine de teste para banco de dados"""
    engine = create_async_engine(
        "sqlite+aiosqlite:///./test.db",
        echo=False,
        future=True
    )
    
    # Criar tabelas
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    
    yield engine
    
    # Limpar após testes
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
    
    await engine.dispose()


@pytest_asyncio.fixture
async def test_session(test_engine):
    """Sessão de teste para banco de dados"""
    async_session = sessionmaker(
        test_engine, class_=AsyncSession, expire_on_commit=False
    )
    
    async with async_session() as session:
        yield session
        await session.rollback()


@pytest_asyncio.fixture
async def test_client(test_session):
    """Cliente de teste para API"""
    
    # Override da dependência de sessão
    app.dependency_overrides[get_db_session] = lambda: test_session
    
    async with AsyncClient(app=app, base_url="http://test") as client:
        yield client
    
    # Limpar overrides
    app.dependency_overrides.clear()


@pytest.fixture
def mock_redis():
    """Mock do Redis para testes"""
    mock = AsyncMock()
    mock.ping.return_value = True
    mock.set.return_value = True
    mock.get.return_value = None
    mock.delete.return_value = True
    mock.exists.return_value = False
    mock.expire.return_value = True
    mock.ttl.return_value = -1
    mock.flushall.return_value = True
    mock.keys.return_value = []
    return mock


@pytest.fixture
def mock_unity_catalog():
    """Mock do Unity Catalog para testes"""
    mock = AsyncMock()
    mock.health_check.return_value = True
    mock.list_catalogs.return_value = [
        {"name": "test_catalog", "comment": "Test catalog"}
    ]
    mock.get_catalog.return_value = {
        "name": "test_catalog",
        "comment": "Test catalog"
    }
    mock.list_schemas.return_value = [
        {"name": "test_schema", "catalog_name": "test_catalog"}
    ]
    mock.list_tables.return_value = [
        {
            "name": "test_table",
            "catalog_name": "test_catalog",
            "schema_name": "test_schema",
            "table_type": "MANAGED"
        }
    ]
    return mock


@pytest.fixture
def sample_user_data():
    """Dados de exemplo para usuário"""
    return {
        "username": "testuser",
        "email": "test@example.com",
        "full_name": "Test User",
        "password": "testpassword123",
        "is_active": True,
        "is_superuser": False
    }


@pytest.fixture
def sample_domain_data():
    """Dados de exemplo para domínio"""
    return {
        "name": "Test Domain",
        "description": "Domain for testing",
        "metadata": {"test": True}
    }


@pytest.fixture
def sample_contract_data():
    """Dados de exemplo para contrato de dados"""
    return {
        "name": "Test Contract",
        "description": "Contract for testing",
        "unity_catalog_path": "test_catalog.test_schema.test_table"
    }


@pytest.fixture
def sample_contract_version_data():
    """Dados de exemplo para versão de contrato"""
    return {
        "version": "1.0.0",
        "description": "Initial version",
        "schema_definition": {
            "type": "object",
            "properties": {
                "id": {"type": "integer"},
                "name": {"type": "string"}
            },
            "required": ["id", "name"]
        },
        "quality_rules": {
            "completeness": {
                "id": {"threshold": 100},
                "name": {"threshold": 95}
            }
        },
        "sla_definition": {
            "availability": "99.9%",
            "response_time": "< 100ms"
        }
    }


@pytest.fixture
def sample_entity_data():
    """Dados de exemplo para entidade"""
    return {
        "name": "Test Entity",
        "type": "table",
        "description": "Entity for testing",
        "unity_catalog_path": "test_catalog.test_schema.test_entity",
        "classification": "internal",
        "schema_definition": {
            "columns": [
                {
                    "name": "id",
                    "type": "integer",
                    "nullable": False,
                    "primary_key": True
                },
                {
                    "name": "name",
                    "type": "string",
                    "nullable": False
                }
            ]
        }
    }


@pytest.fixture
def sample_quality_rule_data():
    """Dados de exemplo para regra de qualidade"""
    return {
        "name": "Test Quality Rule",
        "description": "Quality rule for testing",
        "rule_type": "completeness",
        "rule_definition": {
            "column": "name",
            "condition": "NOT NULL",
            "threshold": 95.0
        },
        "threshold_warning": 90.0,
        "threshold_critical": 80.0,
        "is_active": True
    }


@pytest.fixture
def auth_headers():
    """Headers de autenticação para testes"""
    # Mock JWT token
    token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ0ZXN0dXNlciIsImV4cCI6OTk5OTk5OTk5OX0.test"
    return {"Authorization": f"Bearer {token}"}


@pytest.fixture
def mock_jwt_decode():
    """Mock para decodificação JWT"""
    def mock_decode(token, key, algorithms):
        return {
            "sub": "testuser",
            "exp": 9999999999
        }
    return mock_decode


@pytest_asyncio.fixture
async def test_user(test_session):
    """Usuário de teste no banco"""
    from governance_api.database.models import User
    from governance_api.domain.value_objects import Email
    
    user = User(
        username="testuser",
        email=Email("test@example.com"),
        full_name="Test User",
        password_hash="hashed_password",
        is_active=True,
        is_superuser=False
    )
    
    test_session.add(user)
    await test_session.commit()
    await test_session.refresh(user)
    
    return user


@pytest_asyncio.fixture
async def test_domain(test_session, test_user):
    """Domínio de teste no banco"""
    from governance_api.database.models import Domain
    
    domain = Domain(
        name="Test Domain",
        description="Domain for testing",
        steward_id=test_user.id,
        created_by=test_user.id
    )
    
    test_session.add(domain)
    await test_session.commit()
    await test_session.refresh(domain)
    
    return domain


@pytest_asyncio.fixture
async def test_contract(test_session, test_domain, test_user):
    """Contrato de teste no banco"""
    from governance_api.database.models import DataContract
    from governance_api.domain.value_objects import UnityCatalogPath
    
    contract = DataContract(
        name="Test Contract",
        description="Contract for testing",
        domain_id=test_domain.id,
        steward_id=test_user.id,
        unity_catalog_path=UnityCatalogPath.from_string("test.schema.table"),
        created_by=test_user.id
    )
    
    test_session.add(contract)
    await test_session.commit()
    await test_session.refresh(contract)
    
    return contract


@pytest_asyncio.fixture
async def test_entity(test_session, test_domain, test_user):
    """Entidade de teste no banco"""
    from governance_api.database.models import Entity
    from governance_api.domain.value_objects import UnityCatalogPath
    
    entity = Entity(
        name="Test Entity",
        type="table",
        description="Entity for testing",
        domain_id=test_domain.id,
        steward_id=test_user.id,
        unity_catalog_path=UnityCatalogPath.from_string("test.schema.entity"),
        classification="internal",
        created_by=test_user.id
    )
    
    test_session.add(entity)
    await test_session.commit()
    await test_session.refresh(entity)
    
    return entity


# Configurações de pytest
pytest_plugins = ["pytest_asyncio"]

