# API de Governança de Dados

Uma API robusta e escalável para governança de dados baseada no modelo ODCS v3.0.2, implementada com FastAPI e arquitetura hexagonal.

## 🚀 Características Principais

- **112+ Endpoints REST** para gestão completa de governança
- **Arquitetura Hexagonal** com princípios SOLID
- **Performance Otimizada** com cache Redis e connection pooling
- **Resiliência** com circuit breakers e retry policies
- **Monitoramento** com métricas Prometheus e health checks
- **Segurança** com autenticação JWT e rate limiting
- **Testes Abrangentes** com 90%+ de cobertura
- **Documentação Rica** com Swagger/OpenAPI

## 📋 Pré-requisitos

### Windows 11
- Python 3.14+
- PostgreSQL 15+
- Redis 7+
- Git

## 🛠️ Instalação no Windows 11

### 1. Clone o repositório
```powershell
git clone <repository-url>
cd governance-data-api
```

### 2. Execute o setup automático
```powershell
.\scripts\windows\setup.ps1
```

Este script irá:
- Verificar Python 3.14
- Criar ambiente virtual
- Instalar dependências
- Configurar PostgreSQL local
- Configurar Redis
- Executar migrações iniciais

### 3. Configure as variáveis de ambiente
```powershell
# O arquivo .env será criado automaticamente
# Edite conforme necessário
notepad .env
```

## 🚀 Execução

### Desenvolvimento
```powershell
.\scripts\windows\run.ps1 -Environment development
```

### Produção
```powershell
.\scripts\windows\run.ps1 -Environment production -Port 8000
```

## 🧪 Testes

### Executar todos os testes
```powershell
.\scripts\windows\test.ps1 -Coverage
```

### Testes específicos
```powershell
# Apenas testes unitários
.\scripts\windows\test.ps1 -TestType unit

# Testes de integração
.\scripts\windows\test.ps1 -TestType integration

# Testes end-to-end
.\scripts\windows\test.ps1 -TestType e2e
```

## 📚 Documentação da API

Após iniciar o servidor, acesse:

- **Swagger UI**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc
- **OpenAPI JSON**: http://localhost:8000/openapi.json

## 🏗️ Arquitetura

```
src/governance_api/
├── domain/           # Entidades e regras de negócio
├── application/      # Casos de uso e serviços
├── database/         # Persistência e repositórios
├── api/             # Controllers e endpoints REST
├── external/        # Integrações externas
├── cache/           # Sistema de cache
├── monitoring/      # Métricas e health checks
└── config/          # Configurações
```

## 🔧 Principais Endpoints

### Contratos de Dados
- `GET /api/v1/contracts` - Listar contratos
- `POST /api/v1/contracts` - Criar contrato
- `GET /api/v1/contracts/{id}` - Obter contrato
- `PUT /api/v1/contracts/{id}` - Atualizar contrato
- `DELETE /api/v1/contracts/{id}` - Excluir contrato

### Entidades
- `GET /api/v1/entities` - Listar entidades
- `POST /api/v1/entities` - Criar entidade
- `GET /api/v1/entities/{id}/lineage` - Linhagem de dados

### Qualidade
- `GET /api/v1/quality/rules` - Regras de qualidade
- `POST /api/v1/quality/rules` - Criar regra
- `GET /api/v1/quality/metrics` - Métricas de qualidade

### Governança
- `GET /api/v1/governance/policies` - Políticas
- `GET /api/v1/governance/compliance` - Conformidade

## 📊 Monitoramento

### Health Checks
- `GET /health` - Status geral
- `GET /health/database` - Status do banco
- `GET /health/redis` - Status do cache

### Métricas
- `GET /metrics` - Métricas Prometheus

## 🔒 Segurança

- Autenticação JWT
- Rate limiting por IP
- Validação de entrada rigorosa
- Logs de auditoria
- CORS configurável

## 🚀 Performance

- Cache Redis para consultas frequentes
- Connection pooling otimizado
- Paginação eficiente
- Índices de banco otimizados
- Compressão de resposta

## 🛡️ Resiliência

- Circuit breakers para serviços externos
- Retry policies configuráveis
- Timeouts apropriados
- Graceful shutdown
- Health checks automáticos

## 📈 Escalabilidade

- Arquitetura stateless
- Cache distribuído
- Métricas de performance
- Logs estruturados
- Deploy horizontal

## 🤝 Contribuição

1. Fork o projeto
2. Crie uma branch para sua feature
3. Commit suas mudanças
4. Push para a branch
5. Abra um Pull Request

## 📄 Licença

Este projeto está licenciado sob a MIT License.

## 📞 Suporte

Para suporte técnico, abra uma issue no repositório ou entre em contato com a equipe de desenvolvimento.

