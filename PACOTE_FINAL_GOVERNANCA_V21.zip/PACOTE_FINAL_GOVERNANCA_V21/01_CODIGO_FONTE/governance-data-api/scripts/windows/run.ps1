# Script para executar a API de Governança no Windows
# Compatível com Python 3.14

param(
    [string]$Environment = "development",
    [int]$Port = 8000,
    [string]$Host = "0.0.0.0"
)

Write-Host "🚀 Iniciando API de Governança de Dados..." -ForegroundColor Green
Write-Host "Ambiente: $Environment" -ForegroundColor Yellow
Write-Host "Porta: $Port" -ForegroundColor Yellow

# Verificar se o ambiente virtual existe
if (-not (Test-Path "venv")) {
    Write-Host "❌ Ambiente virtual não encontrado. Execute setup.ps1 primeiro." -ForegroundColor Red
    exit 1
}

# Ativar ambiente virtual
Write-Host "📦 Ativando ambiente virtual..." -ForegroundColor Blue
& "venv\Scripts\Activate.ps1"

# Verificar variáveis de ambiente
if (-not (Test-Path ".env")) {
    Write-Host "⚠️  Arquivo .env não encontrado. Copiando de .env.example..." -ForegroundColor Yellow
    Copy-Item ".env.example" ".env"
}

# Executar migrações se necessário
Write-Host "🔄 Verificando migrações do banco..." -ForegroundColor Blue
python -m alembic upgrade head

# Iniciar servidor
Write-Host "🌐 Iniciando servidor FastAPI..." -ForegroundColor Green
Write-Host "URL: http://$Host`:$Port" -ForegroundColor Cyan
Write-Host "Documentação: http://$Host`:$Port/docs" -ForegroundColor Cyan

if ($Environment -eq "development") {
    uvicorn src.main:app --host $Host --port $Port --reload --log-level debug
} else {
    uvicorn src.main:app --host $Host --port $Port --workers 4
}

