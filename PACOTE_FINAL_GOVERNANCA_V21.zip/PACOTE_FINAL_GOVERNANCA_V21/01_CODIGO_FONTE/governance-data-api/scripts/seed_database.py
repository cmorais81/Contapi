#!/usr/bin/env python3
"""
Script para popular banco de dados com dados mocados
"""
import asyncio
import sys
import os
from pathlib import Path

# Adicionar src ao path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from database.seeders import run_seeder
from config.settings import get_settings


async def main():
    """Função principal"""
    print("🚀 Script de População do Banco de Dados")
    print("=" * 50)
    
    # Verificar argumentos
    size = "medium"
    clear_first = False
    
    if len(sys.argv) > 1:
        if sys.argv[1] in ["small", "medium", "large"]:
            size = sys.argv[1]
        elif sys.argv[1] == "--help":
            print_help()
            return
    
    if "--clear" in sys.argv:
        clear_first = True
    
    # Mostrar configurações
    settings = get_settings()
    print(f"📊 Dataset: {size}")
    print(f"🗑️ Limpar primeiro: {'Sim' if clear_first else 'Não'}")
    print(f"🗄️ Banco: {'SQLite' if settings.use_sqlite else 'PostgreSQL'}")
    
    if settings.use_sqlite:
        print(f"📁 Arquivo SQLite: {settings.sqlite_db_path}")
    
    print()
    
    # Confirmar execução
    if not confirm_execution():
        print("❌ Operação cancelada.")
        return
    
    try:
        # Executar seeder
        counts = await run_seeder(size, clear_first)
        
        print("\n🎉 Sucesso! Dados inseridos:")
        print("-" * 30)
        total = 0
        for table, count in counts.items():
            print(f"  📋 {table.replace('_', ' ').title()}: {count:,} registros")
            total += count
        
        print("-" * 30)
        print(f"  🎯 Total: {total:,} registros")
        
        print("\n✅ Banco de dados populado com sucesso!")
        print("\n🔗 Próximos passos:")
        print("  1. Iniciar a API: python -m uvicorn src.governance_api.main:app --reload")
        print("  2. Acessar documentação: http://localhost:8000/docs")
        print("  3. Testar endpoints com dados reais")
        
    except Exception as e:
        print(f"\n❌ Erro ao popular banco: {e}")
        sys.exit(1)


def print_help():
    """Mostra ajuda do script"""
    print("""
Script de População do Banco de Dados

Uso:
    python scripts/seed_database.py [TAMANHO] [OPÇÕES]

Tamanhos disponíveis:
    small   - Dataset pequeno (5 usuários, 10 contratos, 20 entidades)
    medium  - Dataset médio (10 usuários, 20 contratos, 50 entidades) [padrão]
    large   - Dataset grande (20 usuários, 50 contratos, 100 entidades)

Opções:
    --clear     Limpa todas as tabelas antes de inserir dados
    --help      Mostra esta ajuda

Exemplos:
    python scripts/seed_database.py small
    python scripts/seed_database.py medium --clear
    python scripts/seed_database.py large

Configuração:
    Configure USE_SQLITE=true no .env para usar SQLite em desenvolvimento
    """)


def confirm_execution() -> bool:
    """Confirma execução do script"""
    try:
        response = input("🤔 Continuar com a população do banco? (s/N): ").strip().lower()
        return response in ['s', 'sim', 'y', 'yes']
    except KeyboardInterrupt:
        print("\n❌ Operação cancelada.")
        return False


if __name__ == "__main__":
    asyncio.run(main())

