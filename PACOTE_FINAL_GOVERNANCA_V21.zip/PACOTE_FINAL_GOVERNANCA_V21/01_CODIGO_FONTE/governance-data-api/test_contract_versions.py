#!/usr/bin/env python3
"""
Teste de Versionamento de Contratos de Dados
Desenvolvido por: Carlos Morais
Data: Janeiro 2025
"""

import requests
import json
import uuid
from datetime import datetime
import time

class ContractVersionTester:
    def __init__(self, base_url="http://localhost:8001"):
        self.base_url = base_url
        self.headers = {"Content-Type": "application/json"}
        self.test_results = []
        
    def log_result(self, test_name, success, details):
        """Log do resultado do teste"""
        result = {
            "test_name": test_name,
            "success": success,
            "details": details,
            "timestamp": datetime.now().isoformat()
        }
        self.test_results.append(result)
        status = "✅" if success else "❌"
        print(f"{status} {test_name}: {details}")
        
    def create_domain(self):
        """Criar domínio para os testes"""
        domain_data = {
            "name": "test_domain_contracts",
            "description": "Domínio para testes de versionamento de contratos",
            "parent_domain_id": None,
            "steward_id": None
        }
        
        try:
            response = requests.post(
                f"{self.base_url}/api/v1/domains/",
                headers=self.headers,
                json=domain_data,
                timeout=10
            )
            
            if response.status_code in [200, 201]:
                domain = response.json()
                self.log_result("Criar Domínio", True, f"Domínio criado: {domain.get('id', 'N/A')}")
                return domain.get('id')
            else:
                self.log_result("Criar Domínio", False, f"Status: {response.status_code}")
                return None
                
        except Exception as e:
            self.log_result("Criar Domínio", False, f"Erro: {str(e)}")
            return None
    
    def create_contract_v1(self, domain_id):
        """Criar contrato versão 1.0"""
        contract_data = {
            "name": "customer_data_contract",
            "description": "Contrato de dados de clientes - Versão 1.0",
            "domain_id": domain_id,
            "steward_id": None,
            "status": "active",
            "unity_catalog_path": "prod.customer.customer_data"
        }
        
        try:
            response = requests.post(
                f"{self.base_url}/api/v1/contracts/",
                headers=self.headers,
                json=contract_data,
                timeout=10
            )
            
            if response.status_code in [200, 201]:
                contract = response.json()
                contract_id = contract.get('id')
                self.log_result("Criar Contrato V1", True, f"Contrato V1 criado: {contract_id}")
                return contract_id
            else:
                self.log_result("Criar Contrato V1", False, f"Status: {response.status_code}")
                return None
                
        except Exception as e:
            self.log_result("Criar Contrato V1", False, f"Erro: {str(e)}")
            return None
    
    def create_contract_version_1_0(self, contract_id):
        """Criar versão 1.0 do contrato"""
        version_data = {
            "contract_id": contract_id,
            "version": "1.0.0",
            "description": "Versão inicial do contrato de dados de clientes",
            "schema_definition": {
                "type": "object",
                "properties": {
                    "customer_id": {
                        "type": "integer",
                        "description": "ID único do cliente"
                    },
                    "name": {
                        "type": "string",
                        "description": "Nome completo do cliente"
                    },
                    "email": {
                        "type": "string",
                        "format": "email",
                        "description": "Email do cliente"
                    },
                    "created_at": {
                        "type": "string",
                        "format": "date-time",
                        "description": "Data de criação do registro"
                    }
                },
                "required": ["customer_id", "name", "email"]
            },
            "quality_rules": [
                {
                    "field": "email",
                    "rule": "format_validation",
                    "description": "Email deve ter formato válido"
                },
                {
                    "field": "customer_id",
                    "rule": "uniqueness",
                    "description": "ID do cliente deve ser único"
                }
            ],
            "sla_definition": {
                "availability": "99.9%",
                "freshness": "24h",
                "completeness": "95%"
            },
            "terms_and_conditions": "Dados de clientes para uso interno apenas",
            "is_active": True
        }
        
        try:
            response = requests.post(
                f"{self.base_url}/api/v1/contracts/versions/",
                headers=self.headers,
                json=version_data,
                timeout=10
            )
            
            if response.status_code in [200, 201]:
                version = response.json()
                version_id = version.get('id')
                self.log_result("Criar Versão 1.0", True, f"Versão 1.0 criada: {version_id}")
                return version_id
            else:
                self.log_result("Criar Versão 1.0", False, f"Status: {response.status_code}")
                return None
                
        except Exception as e:
            self.log_result("Criar Versão 1.0", False, f"Erro: {str(e)}")
            return None
    
    def create_contract_version_2_0(self, contract_id):
        """Criar versão 2.0 do contrato (evolução)"""
        version_data = {
            "contract_id": contract_id,
            "version": "2.0.0",
            "description": "Versão evoluída com novos campos e regras aprimoradas",
            "schema_definition": {
                "type": "object",
                "properties": {
                    "customer_id": {
                        "type": "integer",
                        "description": "ID único do cliente"
                    },
                    "name": {
                        "type": "string",
                        "description": "Nome completo do cliente"
                    },
                    "email": {
                        "type": "string",
                        "format": "email",
                        "description": "Email do cliente"
                    },
                    "phone": {
                        "type": "string",
                        "description": "Telefone do cliente (novo campo)"
                    },
                    "address": {
                        "type": "object",
                        "properties": {
                            "street": {"type": "string"},
                            "city": {"type": "string"},
                            "country": {"type": "string"},
                            "postal_code": {"type": "string"}
                        },
                        "description": "Endereço completo do cliente (novo campo)"
                    },
                    "status": {
                        "type": "string",
                        "enum": ["active", "inactive", "suspended"],
                        "description": "Status do cliente (novo campo)"
                    },
                    "created_at": {
                        "type": "string",
                        "format": "date-time",
                        "description": "Data de criação do registro"
                    },
                    "updated_at": {
                        "type": "string",
                        "format": "date-time",
                        "description": "Data de última atualização (novo campo)"
                    }
                },
                "required": ["customer_id", "name", "email", "status"]
            },
            "quality_rules": [
                {
                    "field": "email",
                    "rule": "format_validation",
                    "description": "Email deve ter formato válido"
                },
                {
                    "field": "customer_id",
                    "rule": "uniqueness",
                    "description": "ID do cliente deve ser único"
                },
                {
                    "field": "phone",
                    "rule": "format_validation",
                    "description": "Telefone deve ter formato válido (novo)"
                },
                {
                    "field": "status",
                    "rule": "enum_validation",
                    "description": "Status deve ser um dos valores permitidos (novo)"
                }
            ],
            "sla_definition": {
                "availability": "99.95%",
                "freshness": "12h",
                "completeness": "98%",
                "accuracy": "99%"
            },
            "terms_and_conditions": "Dados de clientes para uso interno e analytics",
            "is_active": True
        }
        
        try:
            response = requests.post(
                f"{self.base_url}/api/v1/contracts/versions/",
                headers=self.headers,
                json=version_data,
                timeout=10
            )
            
            if response.status_code in [200, 201]:
                version = response.json()
                version_id = version.get('id')
                self.log_result("Criar Versão 2.0", True, f"Versão 2.0 criada: {version_id}")
                return version_id
            else:
                self.log_result("Criar Versão 2.0", False, f"Status: {response.status_code}")
                return None
                
        except Exception as e:
            self.log_result("Criar Versão 2.0", False, f"Erro: {str(e)}")
            return None
    
    def test_version_compatibility(self, contract_id):
        """Testar compatibilidade entre versões"""
        try:
            # Listar todas as versões do contrato
            response = requests.get(
                f"{self.base_url}/api/v1/contracts/{contract_id}/versions/",
                headers=self.headers,
                timeout=10
            )
            
            if response.status_code == 200:
                versions = response.json()
                version_count = len(versions) if isinstance(versions, list) else 0
                self.log_result("Listar Versões", True, f"Encontradas {version_count} versões")
                
                # Verificar se ambas as versões existem
                if version_count >= 2:
                    self.log_result("Compatibilidade", True, "Múltiplas versões coexistindo")
                else:
                    self.log_result("Compatibilidade", False, f"Apenas {version_count} versão(ões) encontrada(s)")
                    
            else:
                self.log_result("Listar Versões", False, f"Status: {response.status_code}")
                
        except Exception as e:
            self.log_result("Listar Versões", False, f"Erro: {str(e)}")
    
    def test_contract_retrieval(self, contract_id):
        """Testar recuperação do contrato"""
        try:
            response = requests.get(
                f"{self.base_url}/api/v1/contracts/{contract_id}/",
                headers=self.headers,
                timeout=10
            )
            
            if response.status_code == 200:
                contract = response.json()
                self.log_result("Recuperar Contrato", True, f"Contrato recuperado: {contract.get('name', 'N/A')}")
            else:
                self.log_result("Recuperar Contrato", False, f"Status: {response.status_code}")
                
        except Exception as e:
            self.log_result("Recuperar Contrato", False, f"Erro: {str(e)}")
    
    def run_all_tests(self):
        """Executar todos os testes de versionamento"""
        print("🚀 Iniciando Testes de Versionamento de Contratos")
        print("=" * 60)
        
        # 1. Criar domínio
        domain_id = self.create_domain()
        if not domain_id:
            print("❌ Falha ao criar domínio. Abortando testes.")
            return False
        
        # 2. Criar contrato
        contract_id = self.create_contract_v1(domain_id)
        if not contract_id:
            print("❌ Falha ao criar contrato. Abortando testes.")
            return False
        
        # 3. Criar versão 1.0
        version_1_id = self.create_contract_version_1_0(contract_id)
        if not version_1_id:
            print("❌ Falha ao criar versão 1.0. Continuando...")
        
        # 4. Criar versão 2.0
        version_2_id = self.create_contract_version_2_0(contract_id)
        if not version_2_id:
            print("❌ Falha ao criar versão 2.0. Continuando...")
        
        # 5. Testar compatibilidade
        self.test_version_compatibility(contract_id)
        
        # 6. Testar recuperação
        self.test_contract_retrieval(contract_id)
        
        # Gerar relatório
        self.generate_report()
        
        return True
    
    def generate_report(self):
        """Gerar relatório dos testes"""
        print("\n" + "=" * 60)
        print("📊 RELATÓRIO DE TESTES DE VERSIONAMENTO")
        print("=" * 60)
        
        total_tests = len(self.test_results)
        successful_tests = sum(1 for result in self.test_results if result['success'])
        failed_tests = total_tests - successful_tests
        
        print(f"📋 Total de Testes: {total_tests}")
        print(f"✅ Sucessos: {successful_tests}")
        print(f"❌ Falhas: {failed_tests}")
        print(f"📊 Taxa de Sucesso: {(successful_tests/total_tests)*100:.1f}%")
        
        print("\n📝 Detalhes dos Testes:")
        for result in self.test_results:
            status = "✅" if result['success'] else "❌"
            print(f"  {status} {result['test_name']}: {result['details']}")
        
        # Salvar relatório em arquivo
        report_data = {
            "summary": {
                "total_tests": total_tests,
                "successful_tests": successful_tests,
                "failed_tests": failed_tests,
                "success_rate": (successful_tests/total_tests)*100
            },
            "test_results": self.test_results,
            "generated_at": datetime.now().isoformat()
        }
        
        with open("contract_version_test_report.json", "w") as f:
            json.dump(report_data, f, indent=2)
        
        print(f"\n📁 Relatório salvo em: contract_version_test_report.json")

def main():
    """Função principal"""
    tester = ContractVersionTester()
    
    # Verificar se API está disponível
    try:
        response = requests.get(f"{tester.base_url}/health", timeout=5)
        if response.status_code != 200:
            print("❌ API não está disponível. Verifique se está rodando.")
            return
    except Exception as e:
        print(f"❌ Erro ao conectar com a API: {e}")
        return
    
    # Executar testes
    success = tester.run_all_tests()
    
    if success:
        print("\n🎉 Testes de versionamento concluídos!")
    else:
        print("\n⚠️ Testes concluídos com problemas.")

if __name__ == "__main__":
    main()

