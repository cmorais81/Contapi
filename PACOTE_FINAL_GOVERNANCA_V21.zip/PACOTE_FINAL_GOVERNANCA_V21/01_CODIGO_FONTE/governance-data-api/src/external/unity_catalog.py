"""
Cliente para integração com Unity Catalog
"""

import asyncio
from typing import Any, Dict, List, Optional

import aiohttp

from config.settings import get_settings
from domain.exceptions import IntegrationError
from circuit_breaker import circuit_breaker
from retry import retry, NETWORK_RETRY

settings = get_settings()


class UnityCatalogClient:
    """Cliente para Unity Catalog"""
    
    def __init__(
        self,
        base_url: Optional[str] = None,
        token: Optional[str] = None,
        timeout: int = 30
    ):
        self.base_url = base_url or settings.unity_catalog_url
        self.token = token or settings.unity_catalog_token
        self.timeout = timeout
        self._session = None
    
    async def __aenter__(self):
        """Context manager entry"""
        self._session = aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=self.timeout),
            headers={
                "Authorization": f"Bearer {self.token}",
                "Content-Type": "application/json"
            }
        )
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit"""
        if self._session:
            await self._session.close()
    
    @circuit_breaker(failure_threshold=5, recovery_timeout=60)
    @retry(policy=NETWORK_RETRY)
    async def _make_request(
        self,
        method: str,
        endpoint: str,
        **kwargs
    ) -> Dict[str, Any]:
        """Faz requisição para Unity Catalog"""
        
        if not self._session:
            raise IntegrationError("Client session not initialized")
        
        url = f"{self.base_url.rstrip('/')}/{endpoint.lstrip('/')}"
        
        try:
            async with self._session.request(method, url, **kwargs) as response:
                if response.status >= 400:
                    error_text = await response.text()
                    raise IntegrationError(
                        f"Unity Catalog API error: {response.status}",
                        details={
                            "status": response.status,
                            "error": error_text,
                            "url": url
                        }
                    )
                
                return await response.json()
        
        except aiohttp.ClientError as e:
            raise IntegrationError(
                f"Unity Catalog connection error: {str(e)}",
                details={"url": url}
            ) from e
    
    async def list_catalogs(self) -> List[Dict[str, Any]]:
        """Lista catálogos disponíveis"""
        response = await self._make_request("GET", "/api/2.1/unity-catalog/catalogs")
        return response.get("catalogs", [])
    
    async def get_catalog(self, catalog_name: str) -> Dict[str, Any]:
        """Obtém informações de um catálogo"""
        return await self._make_request(
            "GET", 
            f"/api/2.1/unity-catalog/catalogs/{catalog_name}"
        )
    
    async def list_schemas(self, catalog_name: str) -> List[Dict[str, Any]]:
        """Lista schemas de um catálogo"""
        response = await self._make_request(
            "GET", 
            f"/api/2.1/unity-catalog/schemas",
            params={"catalog_name": catalog_name}
        )
        return response.get("schemas", [])
    
    async def get_schema(self, catalog_name: str, schema_name: str) -> Dict[str, Any]:
        """Obtém informações de um schema"""
        return await self._make_request(
            "GET",
            f"/api/2.1/unity-catalog/schemas/{catalog_name}.{schema_name}"
        )
    
    async def list_tables(
        self,
        catalog_name: str,
        schema_name: str
    ) -> List[Dict[str, Any]]:
        """Lista tabelas de um schema"""
        response = await self._make_request(
            "GET",
            f"/api/2.1/unity-catalog/tables",
            params={
                "catalog_name": catalog_name,
                "schema_name": schema_name
            }
        )
        return response.get("tables", [])
    
    async def get_table(
        self,
        catalog_name: str,
        schema_name: str,
        table_name: str
    ) -> Dict[str, Any]:
        """Obtém informações de uma tabela"""
        return await self._make_request(
            "GET",
            f"/api/2.1/unity-catalog/tables/{catalog_name}.{schema_name}.{table_name}"
        )
    
    async def get_table_columns(
        self,
        catalog_name: str,
        schema_name: str,
        table_name: str
    ) -> List[Dict[str, Any]]:
        """Obtém colunas de uma tabela"""
        table_info = await self.get_table(catalog_name, schema_name, table_name)
        return table_info.get("columns", [])
    
    async def search_tables(
        self,
        query: str,
        catalog_name: Optional[str] = None,
        schema_name: Optional[str] = None,
        max_results: int = 100
    ) -> List[Dict[str, Any]]:
        """Busca tabelas por nome ou descrição"""
        params = {
            "query": query,
            "max_results": max_results
        }
        
        if catalog_name:
            params["catalog_name"] = catalog_name
        if schema_name:
            params["schema_name"] = schema_name
        
        response = await self._make_request(
            "GET",
            "/api/2.1/unity-catalog/search/tables",
            params=params
        )
        return response.get("tables", [])
    
    async def get_table_lineage(
        self,
        catalog_name: str,
        schema_name: str,
        table_name: str,
        direction: str = "both"  # upstream, downstream, both
    ) -> Dict[str, Any]:
        """Obtém linhagem de uma tabela"""
        return await self._make_request(
            "GET",
            f"/api/2.1/unity-catalog/lineage/tables/{catalog_name}.{schema_name}.{table_name}",
            params={"direction": direction}
        )
    
    async def update_table_comment(
        self,
        catalog_name: str,
        schema_name: str,
        table_name: str,
        comment: str
    ) -> Dict[str, Any]:
        """Atualiza comentário de uma tabela"""
        return await self._make_request(
            "PATCH",
            f"/api/2.1/unity-catalog/tables/{catalog_name}.{schema_name}.{table_name}",
            json={"comment": comment}
        )
    
    async def add_table_tags(
        self,
        catalog_name: str,
        schema_name: str,
        table_name: str,
        tags: Dict[str, str]
    ) -> Dict[str, Any]:
        """Adiciona tags a uma tabela"""
        return await self._make_request(
            "PUT",
            f"/api/2.1/unity-catalog/tables/{catalog_name}.{schema_name}.{table_name}/tags",
            json={"tags": tags}
        )
    
    async def health_check(self) -> bool:
        """Verifica saúde da conexão com Unity Catalog"""
        try:
            await self._make_request("GET", "/api/2.1/unity-catalog/catalogs")
            return True
        except Exception:
            return False


class UnityCatalogService:
    """Serviço para operações com Unity Catalog"""
    
    def __init__(self):
        self.client = UnityCatalogClient()
    
    async def sync_catalog_metadata(
        self,
        catalog_name: str,
        schema_name: Optional[str] = None
    ) -> Dict[str, Any]:
        """Sincroniza metadados de um catálogo"""
        
        async with self.client as uc:
            try:
                # Obter informações do catálogo
                catalog_info = await uc.get_catalog(catalog_name)
                
                # Listar schemas
                schemas = await uc.list_schemas(catalog_name)
                
                if schema_name:
                    schemas = [s for s in schemas if s["name"] == schema_name]
                
                synced_tables = []
                
                for schema in schemas:
                    schema_name = schema["name"]
                    
                    # Listar tabelas do schema
                    tables = await uc.list_tables(catalog_name, schema_name)
                    
                    for table in tables:
                        table_name = table["name"]
                        
                        # Obter detalhes da tabela
                        table_details = await uc.get_table(
                            catalog_name, schema_name, table_name
                        )
                        
                        synced_tables.append({
                            "catalog": catalog_name,
                            "schema": schema_name,
                            "table": table_name,
                            "details": table_details
                        })
                
                return {
                    "catalog": catalog_info,
                    "schemas": schemas,
                    "tables": synced_tables,
                    "sync_timestamp": "2025-01-07T10:00:00Z"
                }
            
            except Exception as e:
                raise IntegrationError(
                    f"Failed to sync Unity Catalog metadata: {str(e)}"
                ) from e
    
    async def discover_entities(
        self,
        catalog_pattern: Optional[str] = None,
        schema_pattern: Optional[str] = None,
        table_pattern: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """Descobre entidades no Unity Catalog"""
        
        async with self.client as uc:
            discovered_entities = []
            
            try:
                # Listar catálogos
                catalogs = await uc.list_catalogs()
                
                for catalog in catalogs:
                    catalog_name = catalog["name"]
                    
                    if catalog_pattern and catalog_pattern not in catalog_name:
                        continue
                    
                    # Listar schemas
                    schemas = await uc.list_schemas(catalog_name)
                    
                    for schema in schemas:
                        schema_name = schema["name"]
                        
                        if schema_pattern and schema_pattern not in schema_name:
                            continue
                        
                        # Listar tabelas
                        tables = await uc.list_tables(catalog_name, schema_name)
                        
                        for table in tables:
                            table_name = table["name"]
                            
                            if table_pattern and table_pattern not in table_name:
                                continue
                            
                            discovered_entities.append({
                                "unity_catalog_path": f"{catalog_name}.{schema_name}.{table_name}",
                                "name": table_name,
                                "type": table.get("table_type", "table").lower(),
                                "catalog": catalog_name,
                                "schema": schema_name,
                                "description": table.get("comment"),
                                "created_at": table.get("created_at"),
                                "updated_at": table.get("updated_at")
                            })
                
                return discovered_entities
            
            except Exception as e:
                raise IntegrationError(
                    f"Failed to discover Unity Catalog entities: {str(e)}"
                ) from e

