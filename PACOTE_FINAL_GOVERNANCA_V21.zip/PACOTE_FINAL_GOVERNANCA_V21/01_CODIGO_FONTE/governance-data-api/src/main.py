"""
Aplicação principal FastAPI
API de Governança de Dados V2.1
Desenvolvido por Carlos Morais
"""

from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import time

# Importar controllers
from api.controllers import contracts, entities, quality
from api.controllers import auth, audit, rate_limiting, system, metrics
from api.middleware import (
    ErrorHandlingMiddleware,
    RateLimitMiddleware,
    RequestLoggingMiddleware,
    SecurityHeadersMiddleware,
)
from config.settings import get_settings
from database.connection import db_manager
from domain.exceptions import (
    BusinessRuleViolation,
    EntityNotFoundError,
    ValidationError,
)

settings = get_settings()

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Gerenciar ciclo de vida da aplicação"""
    # Startup
    await db_manager.initialize()
    yield
    # Shutdown
    await db_manager.close()

# Criar aplicação FastAPI
app = FastAPI(
    title="Governance Data API",
    description="API de Governança de Dados baseada no modelo ODCS v3.0.2 - Desenvolvida por Carlos Morais",
    version="2.1.0",
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json",
    lifespan=lifespan
)

# Configurar CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Em produção, especificar domínios
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Adicionar middlewares customizados
app.add_middleware(ErrorHandlingMiddleware)
app.add_middleware(RateLimitMiddleware)
app.add_middleware(RequestLoggingMiddleware)
app.add_middleware(SecurityHeadersMiddleware)

# Middleware para métricas
@app.middleware("http")
async def metrics_middleware(request: Request, call_next):
    start_time = time.time()
    response = await call_next(request)
    process_time = time.time() - start_time
    
    # Registrar métricas
    try:
        from api.controllers.metrics import record_request_metrics
        record_request_metrics(
            method=request.method,
            endpoint=request.url.path,
            status_code=response.status_code,
            duration=process_time
        )
    except Exception:
        pass  # Ignorar erros de métricas
    
    return response

# Incluir routers
app.include_router(auth.router)
app.include_router(contracts.router)
app.include_router(entities.router)
app.include_router(quality.router)
app.include_router(audit.router)
app.include_router(rate_limiting.router)
app.include_router(system.router)
app.include_router(metrics.router)

# Endpoint raiz
@app.get("/")
async def root():
    """Informações da API"""
    return {
        "name": "Governance Data API",
        "description": "API de Governança de Dados baseada no modelo ODCS v3.0.2",
        "version": "2.1.0",
        "developer": "Carlos Morais",
        "docs_url": "/docs",
        "redoc_url": "/redoc",
        "openapi_url": "/openapi.json",
        "health_url": "/health",
        "metrics_url": "/metrics"
    }

# Health check
@app.get("/health")
async def health_check():
    """Health check da aplicação"""
    return {
        "status": "healthy",
        "timestamp": "2025-01-07T10:00:00Z",
        "version": "2.1.0",
        "environment": settings.ENVIRONMENT,
        "developer": "Carlos Morais"
    }

# Handlers de exceção
@app.exception_handler(ValidationError)
async def validation_exception_handler(request: Request, exc: ValidationError):
    return JSONResponse(
        status_code=status.HTTP_400_BAD_REQUEST,
        content={"detail": str(exc), "type": "validation_error"}
    )

@app.exception_handler(EntityNotFoundError)
async def not_found_exception_handler(request: Request, exc: EntityNotFoundError):
    return JSONResponse(
        status_code=status.HTTP_404_NOT_FOUND,
        content={"detail": str(exc), "type": "not_found_error"}
    )

@app.exception_handler(BusinessRuleViolation)
async def business_rule_exception_handler(request: Request, exc: BusinessRuleViolation):
    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        content={"detail": str(exc), "type": "business_rule_violation"}
    )

@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    return JSONResponse(
        status_code=exc.status_code,
        content={"detail": exc.detail, "timestamp": time.time()}
    )

@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception):
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal server error", "timestamp": time.time()}
    )

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True
    )

