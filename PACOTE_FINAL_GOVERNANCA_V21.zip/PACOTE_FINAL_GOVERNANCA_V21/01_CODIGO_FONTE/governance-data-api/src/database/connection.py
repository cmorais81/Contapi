"""
Configuração de conexão com banco de dados
"""

import os
from typing import AsyncGenerator

from sqlalchemy import create_engine, event
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.orm import DeclarativeBase, sessionmaker
from sqlalchemy.pool import StaticPool

from config.settings import get_settings


class Base(DeclarativeBase):
    """Base class para modelos SQLAlchemy"""
    pass


class DatabaseManager:
    """Gerenciador de conexões com banco de dados"""
    
    def __init__(self):
        self.settings = get_settings()
        self._async_engine = None
        self._sync_engine = None
        self._async_session_factory = None
        self._sync_session_factory = None
    
    @property
    def async_engine(self):
        """Engine assíncrona"""
        if self._async_engine is None:
            self._async_engine = create_async_engine(
                self.settings.database_url,
                pool_size=self.settings.database_pool_size,
                max_overflow=self.settings.database_max_overflow,
                pool_pre_ping=True,
                pool_recycle=self.settings.database_pool_recycle,
                echo=self.settings.database_echo,
            )
        return self._async_engine
    
    @property
    def sync_engine(self):
        """Engine síncrona (para migrações)"""
        if self._sync_engine is None:
            # Converter URL assíncrona para síncrona
            sync_url = self.settings.database_url.replace(
                "postgresql+asyncpg://", "postgresql+psycopg2://"
            )
            self._sync_engine = create_engine(
                sync_url,
                pool_size=self.settings.database_pool_size,
                max_overflow=self.settings.database_max_overflow,
                pool_pre_ping=True,
                pool_recycle=self.settings.database_pool_recycle,
                echo=self.settings.database_echo,
            )
        return self._sync_engine
    
    @property
    def async_session_factory(self):
        """Factory para sessões assíncronas"""
        if self._async_session_factory is None:
            self._async_session_factory = async_sessionmaker(
                bind=self.async_engine,
                class_=AsyncSession,
                expire_on_commit=False,
            )
        return self._async_session_factory
    
    @property
    def sync_session_factory(self):
        """Factory para sessões síncronas"""
        if self._sync_session_factory is None:
            self._sync_session_factory = sessionmaker(
                bind=self.sync_engine,
                expire_on_commit=False,
            )
        return self._sync_session_factory
    
    async def get_async_session(self) -> AsyncGenerator[AsyncSession, None]:
        """Gera sessão assíncrona"""
        async with self.async_session_factory() as session:
            try:
                yield session
                await session.commit()
            except Exception:
                await session.rollback()
                raise
            finally:
                await session.close()
    
    def get_sync_session(self):
        """Gera sessão síncrona"""
        with self.sync_session_factory() as session:
            try:
                yield session
                session.commit()
            except Exception:
                session.rollback()
                raise
            finally:
                session.close()
    
    async def create_tables(self):
        """Cria todas as tabelas"""
        async with self.async_engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
    
    async def drop_tables(self):
        """Remove todas as tabelas"""
        async with self.async_engine.begin() as conn:
            await conn.run_sync(Base.metadata.drop_all)
    
    async def close(self):
        """Fecha conexões"""
        if self._async_engine:
            await self._async_engine.dispose()
        if self._sync_engine:
            self._sync_engine.dispose()


# Instância global do gerenciador
db_manager = DatabaseManager()


# Dependency para FastAPI
async def get_db_session() -> AsyncGenerator[AsyncSession, None]:
    """Dependency para obter sessão de banco"""
    async for session in db_manager.get_async_session():
        yield session


# Alias para compatibilidade
async def get_async_session() -> AsyncGenerator[AsyncSession, None]:
    """Alias para get_db_session"""
    async for session in get_db_session():
        yield session


# Configurações para SQLite em testes
def configure_sqlite_for_tests():
    """Configura SQLite para testes"""
    test_engine = create_async_engine(
        "sqlite+aiosqlite:///./test.db",
        poolclass=StaticPool,
        connect_args={"check_same_thread": False},
        echo=True,
    )
    
    db_manager._async_engine = test_engine
    db_manager._async_session_factory = async_sessionmaker(
        bind=test_engine,
        class_=AsyncSession,
        expire_on_commit=False,
    )


# Event listeners para otimizações
@event.listens_for(DatabaseManager().sync_engine, "connect")
def set_sqlite_pragma(dbapi_connection, connection_record):
    """Configura pragmas do SQLite"""
    if "sqlite" in str(dbapi_connection):
        cursor = dbapi_connection.cursor()
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.execute("PRAGMA journal_mode=WAL")
        cursor.execute("PRAGMA synchronous=NORMAL")
        cursor.execute("PRAGMA cache_size=1000")
        cursor.execute("PRAGMA temp_store=MEMORY")
        cursor.close()


@event.listens_for(DatabaseManager().sync_engine, "connect")
def set_postgresql_settings(dbapi_connection, connection_record):
    """Configura settings do PostgreSQL"""
    if "postgresql" in str(dbapi_connection):
        with dbapi_connection.cursor() as cursor:
            # Configurações de performance
            cursor.execute("SET statement_timeout = '30s'")
            cursor.execute("SET lock_timeout = '10s'")
            cursor.execute("SET idle_in_transaction_session_timeout = '60s'")
            dbapi_connection.commit()

