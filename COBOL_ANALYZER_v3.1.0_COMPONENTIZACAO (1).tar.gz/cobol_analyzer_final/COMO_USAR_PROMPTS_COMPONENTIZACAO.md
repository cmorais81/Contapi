# Como Usar os Prompts de Componentização com main.py

## ✅ Problema Resolvido!

O arquivo de prompts `prompts_componentizacao_v3.1.0.yaml` agora está integrado ao `main.py`.

---

## 🚀 Formas de Usar

### Opção 1: Via argumento --prompt-set (RECOMENDADO)

```bash
# Usar com o nome 'componentizacao'
python main.py \
  --fontes examples/fontes.txt \
  --books examples/BOOKS.txt \
  --prompt-set componentizacao \
  --output output_componentizacao

# Ou usar o alias 'bian'
python main.py \
  --fontes examples/fontes.txt \
  --books examples/BOOKS.txt \
  --prompt-set bian \
  --output output_bian

# Ou usar o alias 'componentizacao_v3'
python main.py \
  --fontes examples/fontes.txt \
  --books examples/BOOKS.txt \
  --prompt-set componentizacao_v3 \
  --output output
```

### Opção 2: Com análise profunda (deep-analysis)

```bash
python main.py \
  --fontes examples/fontes.txt \
  --books examples/BOOKS.txt \
  --prompt-set componentizacao \
  --deep-analysis \
  --output output_deep
```

### Opção 3: Com múltiplos modelos

```bash
python main.py \
  --fontes examples/fontes.txt \
  --books examples/BOOKS.txt \
  --prompt-set componentizacao \
  --models '["aws-claude-3-5-sonnet", "gpt-4"]' \
  --output output_multi
```

---

## 📋 Nomes Disponíveis para --prompt-set

Agora você pode usar qualquer um destes nomes:

| Nome | Arquivo Carregado |
|------|-------------------|
| `componentizacao` | `config/prompts_componentizacao_v3.1.0.yaml` |
| `componentizacao_v3` | `config/prompts_componentizacao_v3.1.0.yaml` |
| `bian` | `config/prompts_componentizacao_v3.1.0.yaml` |
| `original` | `config/prompts_original.yaml` |
| `doc_legado_pro` | `config/prompts_doc_legado_pro.yaml` |
| `melhorado_rag` | `config/prompts_melhorado_rag.yaml` |

---

## 🎯 Exemplos Práticos

### Exemplo 1: Análise Básica com Componentização

```bash
python main.py \
  --fontes examples/fontes.txt \
  --prompt-set componentizacao \
  --output output
```

**O que vai gerar:**
- Análise de cada programa COBOL
- Identificação de candidatos a componentes
- Regras de negócio detalhadas
- Sugestões de contratos JSON Schema

### Exemplo 2: Análise Profunda com Foco em BIAN

```bash
python main.py \
  --fontes examples/fontes.txt \
  --books examples/BOOKS.txt \
  --prompt-set bian \
  --deep-analysis \
  --output output_bian
```

**O que vai gerar:**
- Análise detalhada de regras de negócio
- Mapeamento BIAN sugerido
- Componentes reutilizáveis identificados
- Macro rules aplicáveis
- Estratégia de migração

### Exemplo 3: Análise Consolidada do Sistema

```bash
python main.py \
  --fontes examples/fontes.txt \
  --books examples/BOOKS.txt \
  --prompt-set componentizacao \
  --consolidado \
  --output output_consolidado
```

**O que vai gerar:**
- Análise sistêmica de todos os programas
- Visão consolidada de componentes
- Arquitetura de integração sugerida
- Tabela priorizada de componentes

---

## 🔍 Verificar se Está Funcionando

### Teste Rápido

```bash
# Este comando deve funcionar sem erros
python main.py \
  --fontes examples/fontes.txt \
  --prompt-set componentizacao \
  --output test_output
```

### Verificar Logs

Procure no log por:
```
Dual Prompt Manager inicializado - Conjunto ativo: componentizacao
Prompts carregados de: config/prompts_componentizacao_v3.1.0.yaml
```

### Se Ainda Der Erro

1. **Verificar se o arquivo existe:**
```bash
ls -la config/prompts_componentizacao_v3.1.0.yaml
```

2. **Testar o arquivo YAML:**
```bash
python test_prompts.py
```

3. **Ver o log completo:**
```bash
tail -f logs/cobol_to_docs_*.log
```

---

## 📊 Diferença Entre os Prompt Sets

### `original`
- Análise técnica tradicional
- Foco em documentação funcional
- Sem identificação de componentes

### `melhorado_rag`
- Análise com RAG (Retrieval Augmented Generation)
- Base de conhecimento incremental
- Melhor contexto histórico

### `componentizacao` / `bian` ⭐
- **Tudo dos anteriores** +
- Identificação de componentes reutilizáveis
- Contratos JSON Schema
- Mapeamento BIAN
- 12 macro rules
- Estratégia de migração

---

## 🎓 Dicas de Uso

### Para Análise Inicial
Use `componentizacao` para ter uma visão completa:
```bash
python main.py --fontes ... --prompt-set componentizacao
```

### Para Foco em Arquitetura
Use `bian` (mesmo arquivo, nome mais descritivo):
```bash
python main.py --fontes ... --prompt-set bian --consolidado
```

### Para Análise Detalhada
Combine com `--deep-analysis`:
```bash
python main.py --fontes ... --prompt-set componentizacao --deep-analysis
```

### Para Comparar Modelos
Use múltiplos modelos:
```bash
python main.py --fontes ... --prompt-set bian --models '["aws-claude-3-5-sonnet", "gpt-4"]'
```

---

## 📁 Estrutura de Saída

Quando usar `--prompt-set componentizacao`, a saída incluirá:

```
output/
├── PROGRAMA1_analise_funcional.md
│   ├── Regras de Negócio
│   ├── Cálculos Financeiros
│   ├── Validações de Dados
│   └── Componentes Reutilizáveis ⭐
│       ├── Nome sugerido
│       ├── Contrato (entrada/saída)
│       ├── Mapeamento BIAN
│       ├── Macro rules
│       └── Estratégia de migração
├── PROGRAMA2_analise_funcional.md
└── relatorio_custos.txt
```

---

## ⚙️ Configuração Avançada

### Usar Arquivo Customizado

Se quiser usar um arquivo diferente:

```bash
# Editar src/core/prompt_manager_dual.py
# Adicionar ao dicionário prompt_files:
'meu_prompt': 'config/meu_arquivo.yaml'

# Depois usar:
python main.py --prompt-set meu_prompt ...
```

### Ou usar via código Python:

```python
from src.core.prompt_manager_dual import DualPromptManager

# Carregar arquivo customizado
pm = DualPromptManager(
    config={},
    custom_prompts_file='config/meu_arquivo.yaml'
)
```

---

## 🐛 Troubleshooting

### Erro: "Arquivo não encontrado"
**Solução**: Verifique se está executando do diretório raiz:
```bash
cd /caminho/para/cobol_analyzer_final
python main.py ...
```

### Erro: "Prompts não carregados"
**Solução**: Valide o arquivo YAML:
```bash
python test_prompts.py
```

### Erro: "KeyError: 'prompts'"
**Solução**: O arquivo YAML deve ter a estrutura:
```yaml
prompts:
  business_rule_extraction:
    system: |
      ...
    user: |
      ...
```

---

## ✅ Checklist de Uso

- [ ] Arquivo `config/prompts_componentizacao_v3.1.0.yaml` existe
- [ ] Executar `python test_prompts.py` passou
- [ ] Usar `--prompt-set componentizacao` no comando
- [ ] Verificar logs para confirmar carregamento
- [ ] Revisar saída para ver seção "Componentes Reutilizáveis"

---

**Atualizado**: Outubro 2025  
**Versão**: 3.1.0 Componentização  
**Status**: ✅ Integrado e Funcionando

