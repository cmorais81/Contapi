#!/usr/bin/env python3
"""
Script para utilizar os prompts de componentização v3.1.0
Facilita a análise de código COBOL com foco em extração de componentes reutilizáveis.

Uso:
    python use_componentization_prompts.py --fontes examples/fontes.txt --books examples/BOOKS.txt
    python use_componentization_prompts.py --fontes examples/fontes.txt --component-analysis
    python use_componentization_prompts.py --fontes examples/fontes.txt --full-analysis
"""

import os
import sys
import argparse
import logging
from pathlib import Path

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.core.config import ConfigManager
from src.core.prompt_manager_dual import DualPromptManager
from src.providers.enhanced_provider_manager import EnhancedProviderManager
from src.parsers.cobol_parser_original import COBOLParser
from src.generators.documentation_generator import DocumentationGenerator
from src.utils.cost_calculator import CostCalculator


def setup_logging(log_level: str = "INFO") -> None:
    """Configura o sistema de logging."""
    log_dir = "logs"
    os.makedirs(log_dir, exist_ok=True)
    
    from datetime import datetime
    log_file = os.path.join(log_dir, f"componentization_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
    
    logging.basicConfig(
        level=getattr(logging, log_level.upper()),
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file, encoding='utf-8'),
            logging.StreamHandler(sys.stdout)
        ]
    )


class ComponentizationAnalyzer:
    """Analisador especializado em componentização e abstração de código COBOL."""
    
    def __init__(self, config_file: str = "config/prompts_componentizacao_v3.1.0.yaml"):
        """Inicializa o analisador de componentização."""
        self.logger = logging.getLogger(__name__)
        self.config_manager = ConfigManager()
        
        # Configurar para usar os novos prompts
        config = self.config_manager.config.copy()
        config['prompts_file'] = config_file
        
        self.prompt_manager = DualPromptManager(config, "componentizacao")
        self.provider_manager = EnhancedProviderManager(config)
        self.parser = COBOLParser()
        self.cost_calculator = CostCalculator()
        
        self.logger.info(f"ComponentizationAnalyzer inicializado com prompts: {config_file}")
    
    def analyze_business_rules(self, program_code: str, program_name: str, model: str = "aws-claude-3-5-sonnet") -> dict:
        """Analisa regras de negócio com foco em candidatos a componentes."""
        self.logger.info(f"Analisando regras de negócio de {program_name}")
        
        # Obter prompt específico para extração de regras de negócio
        prompt = self._get_prompt("business_rule_extraction", {"cobol_code": program_code})
        
        # Executar análise
        result = self.provider_manager.analyze_cobol(
            program_content=program_code,
            program_name=program_name,
            prompt=prompt,
            model=model
        )
        
        return {
            'success': result.success,
            'content': result.content if result.success else result.error_message,
            'tokens_used': result.tokens_used,
            'model': model
        }
    
    def analyze_financial_calculations(self, program_code: str, program_name: str, model: str = "aws-claude-3-5-sonnet") -> dict:
        """Analisa cálculos financeiros e identifica componentes reutilizáveis."""
        self.logger.info(f"Analisando cálculos financeiros de {program_name}")
        
        prompt = self._get_prompt("financial_calculations", {"cobol_code": program_code})
        
        result = self.provider_manager.analyze_cobol(
            program_content=program_code,
            program_name=program_name,
            prompt=prompt,
            model=model
        )
        
        return {
            'success': result.success,
            'content': result.content if result.success else result.error_message,
            'tokens_used': result.tokens_used,
            'model': model
        }
    
    def analyze_data_validations(self, program_code: str, program_name: str, model: str = "aws-claude-3-5-sonnet") -> dict:
        """Analisa validações de dados e identifica componentes centralizáveis."""
        self.logger.info(f"Analisando validações de dados de {program_name}")
        
        prompt = self._get_prompt("data_validation_rules", {"cobol_code": program_code})
        
        result = self.provider_manager.analyze_cobol(
            program_content=program_code,
            program_name=program_name,
            prompt=prompt,
            model=model
        )
        
        return {
            'success': result.success,
            'content': result.content if result.success else result.error_message,
            'tokens_used': result.tokens_used,
            'model': model
        }
    
    def analyze_copybooks(self, copybooks_code: str, model: str = "aws-claude-3-5-sonnet") -> dict:
        """Analisa copybooks e identifica estruturas reutilizáveis."""
        self.logger.info("Analisando copybooks")
        
        prompt = self._get_prompt("detailed_copybook_analysis", {"copybooks": copybooks_code})
        
        result = self.provider_manager.analyze_cobol(
            program_content=copybooks_code,
            program_name="COPYBOOKS",
            prompt=prompt,
            model=model
        )
        
        return {
            'success': result.success,
            'content': result.content if result.success else result.error_message,
            'tokens_used': result.tokens_used,
            'model': model
        }
    
    def deep_business_analysis(self, program_code: str, copybooks_code: str, program_name: str, 
                              model: str = "aws-claude-3-5-sonnet") -> dict:
        """Análise profunda de negócio com identificação de componentes."""
        self.logger.info(f"Análise profunda de negócio de {program_name}")
        
        prompt = self._get_prompt("deep_business_analysis", {
            "cobol_code": program_code,
            "copybooks": copybooks_code
        })
        
        result = self.provider_manager.analyze_cobol(
            program_content=program_code,
            program_name=program_name,
            prompt=prompt,
            model=model
        )
        
        return {
            'success': result.success,
            'content': result.content if result.success else result.error_message,
            'tokens_used': result.tokens_used,
            'model': model
        }
    
    def component_design_analysis(self, system_documentation: str, model: str = "aws-claude-3-5-sonnet") -> dict:
        """Análise de design de componentes e abstração."""
        self.logger.info("Análise de design de componentes")
        
        prompt = self._get_prompt("component_design_and_abstraction", {
            "system_documentation": system_documentation
        })
        
        result = self.provider_manager.analyze_cobol(
            program_content=system_documentation,
            program_name="COMPONENT_DESIGN",
            prompt=prompt,
            model=model
        )
        
        return {
            'success': result.success,
            'content': result.content if result.success else result.error_message,
            'tokens_used': result.tokens_used,
            'model': model
        }
    
    def full_componentization_analysis(self, fontes_file: str, books_file: str = None, 
                                      output_dir: str = "output_componentization",
                                      model: str = "aws-claude-3-5-sonnet") -> dict:
        """Análise completa com foco em componentização."""
        self.logger.info("=== ANÁLISE COMPLETA DE COMPONENTIZAÇÃO ===")
        
        # Criar diretório de saída
        os.makedirs(output_dir, exist_ok=True)
        
        # Parse dos arquivos
        programs, books = self.parser.parse_file(fontes_file)
        
        if books_file and os.path.exists(books_file):
            _, additional_books = self.parser.parse_file(books_file)
            books.extend(additional_books)
        
        self.logger.info(f"Programas carregados: {len(programs)}")
        self.logger.info(f"Copybooks carregados: {len(books)}")
        
        # Preparar documentação do sistema
        system_doc = self._prepare_system_documentation(programs, books)
        
        results = {
            'programs_analyzed': len(programs),
            'copybooks_analyzed': len(books),
            'analyses': [],
            'total_tokens': 0,
            'total_cost': 0.0
        }
        
        # 1. Análise de copybooks
        if books:
            copybooks_code = "\n\n".join([f"--- {book.name} ---\n{book.content}" for book in books])
            copybook_result = self.analyze_copybooks(copybooks_code, model)
            
            if copybook_result['success']:
                output_file = os.path.join(output_dir, "01_ANALISE_COPYBOOKS.md")
                self._save_result(output_file, copybook_result['content'], "Análise de Copybooks")
                results['analyses'].append({
                    'type': 'copybooks',
                    'file': output_file,
                    'tokens': copybook_result['tokens_used']
                })
                results['total_tokens'] += copybook_result['tokens_used']
        
        # 2. Análise de cada programa
        for i, program in enumerate(programs, 1):
            self.logger.info(f"Processando programa {i}/{len(programs)}: {program.name}")
            
            # Análise profunda de negócio
            copybooks_code = "\n\n".join([f"--- {book.name} ---\n{book.content}" for book in books])
            deep_result = self.deep_business_analysis(program.content, copybooks_code, program.name, model)
            
            if deep_result['success']:
                output_file = os.path.join(output_dir, f"02_ANALISE_PROFUNDA_{program.name}.md")
                self._save_result(output_file, deep_result['content'], f"Análise Profunda - {program.name}")
                results['analyses'].append({
                    'type': 'deep_business',
                    'program': program.name,
                    'file': output_file,
                    'tokens': deep_result['tokens_used']
                })
                results['total_tokens'] += deep_result['tokens_used']
        
        # 3. Análise de design de componentes (consolidada)
        component_result = self.component_design_analysis(system_doc, model)
        
        if component_result['success']:
            output_file = os.path.join(output_dir, "03_DESIGN_COMPONENTES.md")
            self._save_result(output_file, component_result['content'], "Design de Componentes")
            results['analyses'].append({
                'type': 'component_design',
                'file': output_file,
                'tokens': component_result['tokens_used']
            })
            results['total_tokens'] += component_result['tokens_used']
        
        # Calcular custo total
        results['total_cost'] = self.cost_calculator.calculate_cost(model, results['total_tokens'])
        
        # Gerar relatório resumo
        self._generate_summary_report(results, output_dir)
        
        self.logger.info(f"Análise completa finalizada. Total de tokens: {results['total_tokens']:,}")
        self.logger.info(f"Custo estimado: ${results['total_cost']:.4f}")
        self.logger.info(f"Resultados salvos em: {output_dir}")
        
        return results
    
    def _get_prompt(self, prompt_type: str, variables: dict) -> str:
        """Obtém e formata um prompt específico."""
        # Carregar prompts do arquivo YAML
        import yaml
        
        prompts_file = "config/prompts_componentizacao_v3.1.0.yaml"
        with open(prompts_file, 'r', encoding='utf-8') as f:
            prompts_config = yaml.safe_load(f)
        
        prompt_data = prompts_config['prompts'].get(prompt_type, {})
        system_prompt = prompt_data.get('system', '')
        user_prompt = prompt_data.get('user', '')
        
        # Substituir variáveis
        for key, value in variables.items():
            user_prompt = user_prompt.replace(f"{{{key}}}", str(value))
        
        return f"{system_prompt}\n\n{user_prompt}"
    
    def _prepare_system_documentation(self, programs, books) -> str:
        """Prepara documentação consolidada do sistema."""
        doc_parts = []
        
        doc_parts.append("# DOCUMENTAÇÃO DO SISTEMA COBOL BANCÁRIO")
        doc_parts.append("")
        doc_parts.append(f"Total de programas: {len(programs)}")
        doc_parts.append(f"Total de copybooks: {len(books)}")
        doc_parts.append("")
        
        doc_parts.append("## PROGRAMAS")
        for program in programs:
            doc_parts.append(f"### {program.name}")
            doc_parts.append(f"Linhas: {program.line_count}")
            doc_parts.append("")
            doc_parts.append("```cobol")
            doc_parts.append(program.content[:2000])  # Primeiras 2000 chars
            doc_parts.append("```")
            doc_parts.append("")
        
        doc_parts.append("## COPYBOOKS")
        for book in books:
            doc_parts.append(f"### {book.name}")
            doc_parts.append("")
            doc_parts.append("```cobol")
            doc_parts.append(book.content[:1000])  # Primeiros 1000 chars
            doc_parts.append("```")
            doc_parts.append("")
        
        return "\n".join(doc_parts)
    
    def _save_result(self, output_file: str, content: str, title: str) -> None:
        """Salva resultado da análise em arquivo."""
        from datetime import datetime
        
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(f"# {title}\n\n")
            f.write(f"**Data:** {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}\n\n")
            f.write("---\n\n")
            f.write(content)
        
        self.logger.info(f"Resultado salvo em: {output_file}")
    
    def _generate_summary_report(self, results: dict, output_dir: str) -> None:
        """Gera relatório resumo da análise."""
        from datetime import datetime
        
        report_file = os.path.join(output_dir, "00_RELATORIO_RESUMO.md")
        
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write("# RELATÓRIO DE ANÁLISE DE COMPONENTIZAÇÃO\n\n")
            f.write(f"**Data:** {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}\n\n")
            f.write("---\n\n")
            
            f.write("## RESUMO EXECUTIVO\n\n")
            f.write(f"- **Programas analisados:** {results['programs_analyzed']}\n")
            f.write(f"- **Copybooks analisados:** {results['copybooks_analyzed']}\n")
            f.write(f"- **Total de análises:** {len(results['analyses'])}\n")
            f.write(f"- **Total de tokens:** {results['total_tokens']:,}\n")
            f.write(f"- **Custo estimado:** ${results['total_cost']:.4f}\n\n")
            
            f.write("## ARQUIVOS GERADOS\n\n")
            for analysis in results['analyses']:
                f.write(f"### {analysis['type'].upper()}\n")
                f.write(f"- **Arquivo:** `{os.path.basename(analysis['file'])}`\n")
                f.write(f"- **Tokens:** {analysis['tokens']:,}\n")
                if 'program' in analysis:
                    f.write(f"- **Programa:** {analysis['program']}\n")
                f.write("\n")
            
            f.write("## PRÓXIMOS PASSOS\n\n")
            f.write("1. Revisar a análise de design de componentes (`03_DESIGN_COMPONENTES.md`)\n")
            f.write("2. Priorizar componentes por impacto e complexidade\n")
            f.write("3. Definir roadmap de implementação\n")
            f.write("4. Criar POCs dos componentes prioritários\n")
            f.write("5. Implementar estratégia de migração incremental\n")
        
        self.logger.info(f"Relatório resumo gerado: {report_file}")


def main():
    """Função principal."""
    parser = argparse.ArgumentParser(
        description="Análise de Componentização de Código COBOL v3.1.0",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    parser.add_argument('--fontes', type=str, required=True, help='Arquivo com programas COBOL')
    parser.add_argument('--books', type=str, help='Arquivo com copybooks COBOL')
    parser.add_argument('--output', type=str, default='output_componentization', help='Diretório de saída')
    parser.add_argument('--model', type=str, default='aws-claude-3-5-sonnet', help='Modelo de IA')
    parser.add_argument('--log-level', type=str, default='INFO', help='Nível de log')
    parser.add_argument('--full-analysis', action='store_true', help='Análise completa de componentização')
    parser.add_argument('--component-analysis', action='store_true', help='Apenas análise de design de componentes')
    
    args = parser.parse_args()
    
    # Configurar logging
    setup_logging(args.log_level)
    logger = logging.getLogger(__name__)
    
    try:
        # Inicializar analisador
        analyzer = ComponentizationAnalyzer()
        
        print("=" * 80)
        print("ANÁLISE DE COMPONENTIZAÇÃO DE CÓDIGO COBOL v3.1.0")
        print("=" * 80)
        print()
        
        if args.full_analysis:
            # Análise completa
            results = analyzer.full_componentization_analysis(
                fontes_file=args.fontes,
                books_file=args.books,
                output_dir=args.output,
                model=args.model
            )
            
            print()
            print("=" * 80)
            print("ANÁLISE CONCLUÍDA COM SUCESSO")
            print("=" * 80)
            print(f"Programas analisados: {results['programs_analyzed']}")
            print(f"Copybooks analisados: {results['copybooks_analyzed']}")
            print(f"Total de tokens: {results['total_tokens']:,}")
            print(f"Custo estimado: ${results['total_cost']:.4f}")
            print(f"Resultados em: {args.output}")
            print("=" * 80)
        
        elif args.component_analysis:
            # Apenas análise de componentes
            parser_obj = COBOLParser()
            programs, books = parser_obj.parse_file(args.fontes)
            
            if args.books and os.path.exists(args.books):
                _, additional_books = parser_obj.parse_file(args.books)
                books.extend(additional_books)
            
            system_doc = analyzer._prepare_system_documentation(programs, books)
            result = analyzer.component_design_analysis(system_doc, args.model)
            
            if result['success']:
                os.makedirs(args.output, exist_ok=True)
                output_file = os.path.join(args.output, "DESIGN_COMPONENTES.md")
                analyzer._save_result(output_file, result['content'], "Design de Componentes")
                
                print()
                print("=" * 80)
                print("ANÁLISE DE COMPONENTES CONCLUÍDA")
                print("=" * 80)
                print(f"Tokens utilizados: {result['tokens_used']:,}")
                print(f"Resultado salvo em: {output_file}")
                print("=" * 80)
        
        else:
            print("Use --full-analysis ou --component-analysis")
            parser.print_help()
    
    except Exception as e:
        logger.error(f"Erro na análise: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()

