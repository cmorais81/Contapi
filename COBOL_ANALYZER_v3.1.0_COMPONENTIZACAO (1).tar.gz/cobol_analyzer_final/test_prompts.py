#!/usr/bin/env python3
"""
Script de teste para validar os prompts de componentização v3.1.0
"""

import os
import sys
import yaml

def test_prompts_file():
    """Testa se o arquivo de prompts está bem formado."""
    print("=" * 80)
    print("TESTE DE VALIDAÇÃO DOS PROMPTS DE COMPONENTIZAÇÃO v3.1.0")
    print("=" * 80)
    print()
    
    prompts_file = "config/prompts_componentizacao_v3.1.0.yaml"
    
    # Verificar se o arquivo existe
    if not os.path.exists(prompts_file):
        print(f"❌ ERRO: Arquivo não encontrado: {prompts_file}")
        return False
    
    print(f"✅ Arquivo encontrado: {prompts_file}")
    
    # Tentar carregar o YAML
    try:
        with open(prompts_file, 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)
        print("✅ Arquivo YAML válido")
    except Exception as e:
        print(f"❌ ERRO ao carregar YAML: {e}")
        return False
    
    # Verificar estrutura
    if 'prompts' not in config:
        print("❌ ERRO: Chave 'prompts' não encontrada")
        return False
    
    print("✅ Estrutura básica válida")
    
    # Verificar prompts esperados
    expected_prompts = [
        'business_rule_extraction',
        'financial_calculations',
        'data_validation_rules',
        'detailed_copybook_analysis',
        'deep_business_analysis',
        'component_design_and_abstraction',
        'component_templates',
        'migration_and_governance'
    ]
    
    prompts = config['prompts']
    
    print()
    print("PROMPTS ENCONTRADOS:")
    print("-" * 80)
    
    for prompt_name in expected_prompts:
        if prompt_name in prompts:
            prompt_data = prompts[prompt_name]
            has_system = 'system' in prompt_data
            has_user = 'user' in prompt_data
            
            system_len = len(prompt_data.get('system', ''))
            user_len = len(prompt_data.get('user', ''))
            
            status = "✅" if has_system and has_user else "⚠️"
            print(f"{status} {prompt_name}")
            print(f"   - System prompt: {system_len} caracteres")
            print(f"   - User prompt: {user_len} caracteres")
            
            if not has_system:
                print(f"   ⚠️  Faltando 'system' prompt")
            if not has_user:
                print(f"   ⚠️  Faltando 'user' prompt")
        else:
            print(f"❌ {prompt_name} - NÃO ENCONTRADO")
    
    print()
    print("-" * 80)
    
    # Verificar campos específicos do novo prompt
    print()
    print("VALIDAÇÃO DO PROMPT PRINCIPAL: component_design_and_abstraction")
    print("-" * 80)
    
    if 'component_design_and_abstraction' in prompts:
        comp_prompt = prompts['component_design_and_abstraction']
        user_content = comp_prompt.get('user', '')
        
        # Verificar se contém as seções esperadas
        expected_sections = [
            'Nome sugerido',
            'Entradas (contract)',
            'Saídas (contract)',
            'Eventos gerados / consumidos',
            'Mapeamento BIAN',
            'Regras macro',
            'Requisitos não-funcionais',
            'Compatibilidade / migração',
            'Observabilidade / Auditoria',
            'JSON Schema',
            'MACRORREGRAS'
        ]
        
        for section in expected_sections:
            if section in user_content:
                print(f"✅ Seção encontrada: {section}")
            else:
                print(f"⚠️  Seção não encontrada: {section}")
        
        # Verificar se há exemplos de macro rules
        if 'macros_examples' in comp_prompt:
            macros = comp_prompt['macros_examples']
            print(f"\n✅ Exemplos de macro rules encontrados ({len(macros)} caracteres)")
            
            # Contar quantas regras macro existem
            macro_rules = [
                'Idempotência',
                'Versionamento',
                'Configurabilidade',
                'Observabilidade',
                'Transacionalidade',
                'Segurança',
                'Localização',
                'Performance',
                'Testabilidade',
                'Reuso de dados',
                'Tolerância a falhas',
                'Observância regulatória'
            ]
            
            found_rules = sum(1 for rule in macro_rules if rule in macros)
            print(f"   - Regras macro identificadas: {found_rules}/{len(macro_rules)}")
    
    print()
    print("-" * 80)
    
    # Verificar templates
    print()
    print("VALIDAÇÃO DOS TEMPLATES")
    print("-" * 80)
    
    if 'component_templates' in prompts:
        templates = prompts['component_templates']
        user_content = templates.get('user', '')
        
        expected_templates = [
            'TaxCalculationService',
            'TaxCalculationRequest',
            'TaxCalculationResponse',
            'CadocGenerationRequest',
            'TaxRules.Changed'
        ]
        
        for template in expected_templates:
            if template in user_content:
                print(f"✅ Template encontrado: {template}")
            else:
                print(f"⚠️  Template não encontrado: {template}")
    
    print()
    print("=" * 80)
    print("TESTE CONCLUÍDO COM SUCESSO")
    print("=" * 80)
    
    return True


def test_prompt_manager_integration():
    """Testa integração com o PromptManager."""
    print()
    print("=" * 80)
    print("TESTE DE INTEGRAÇÃO COM PROMPT MANAGER")
    print("=" * 80)
    print()
    
    try:
        # Adicionar src ao path
        sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))
        
        # Tentar importar e usar o PromptManager
        from src.core.prompt_manager import PromptManager
        
        pm = PromptManager("config/prompts_componentizacao_v3.1.0.yaml")
        print("✅ PromptManager inicializado com sucesso")
        
        # Verificar se consegue carregar a configuração
        if pm.config and 'prompts' in pm.config:
            print(f"✅ Configuração carregada: {len(pm.config['prompts'])} prompts")
        else:
            print("⚠️  Configuração não carregada corretamente")
        
        # Tentar obter um prompt específico
        try:
            questions = pm.get_analysis_questions()
            print(f"✅ Método get_analysis_questions() funcional")
        except Exception as e:
            print(f"⚠️  Método get_analysis_questions() com erro: {e}")
        
        print()
        print("=" * 80)
        print("INTEGRAÇÃO VALIDADA")
        print("=" * 80)
        
        return True
        
    except Exception as e:
        print(f"❌ ERRO na integração: {e}")
        import traceback
        traceback.print_exc()
        return False


def main():
    """Função principal."""
    success = True
    
    # Teste 1: Validar arquivo de prompts
    if not test_prompts_file():
        success = False
    
    # Teste 2: Validar integração
    if not test_prompt_manager_integration():
        success = False
    
    print()
    if success:
        print("🎉 TODOS OS TESTES PASSARAM!")
        print()
        print("Próximos passos:")
        print("1. Execute: python use_componentization_prompts.py --help")
        print("2. Leia: GUIA_COMPONENTIZACAO.md")
        print("3. Teste com seus arquivos COBOL")
    else:
        print("⚠️  ALGUNS TESTES FALHARAM")
        print("Revise os erros acima antes de prosseguir")
        sys.exit(1)


if __name__ == "__main__":
    main()

