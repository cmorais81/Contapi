"""
Testes para Custom Prompt Manager
"""

import unittest
import tempfile
import os
from unittest.mock import patch, MagicMock

import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'cobol_to_docs', 'src'))

from core.custom_prompt_manager import CustomPromptManager

class TestCustomPromptManager(unittest.TestCase):
    
    def setUp(self):
        """Setup para cada teste."""
        self.test_prompt_content = """
Você é um especialista em análise COBOL.

Analise o programa: {program_name}

Código:
{cobol_code}

Copybooks:
{copybooks}
"""
    
    def test_load_custom_prompt_success(self):
        """Testa carregamento bem-sucedido de prompt customizado."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
            f.write(self.test_prompt_content)
            temp_file = f.name
        
        try:
            manager = CustomPromptManager(temp_file)
            self.assertTrue(manager.has_custom_prompt())
            self.assertIn("especialista em análise COBOL", manager.custom_prompt_content)
        finally:
            os.unlink(temp_file)
    
    def test_load_custom_prompt_file_not_found(self):
        """Testa comportamento quando arquivo não existe."""
        manager = CustomPromptManager("/arquivo/inexistente.txt")
        self.assertFalse(manager.has_custom_prompt())
        self.assertIsNone(manager.custom_prompt_content)
    
    def test_create_custom_analysis_prompt(self):
        """Testa criação de prompt de análise customizado."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
            f.write(self.test_prompt_content)
            temp_file = f.name
        
        try:
            manager = CustomPromptManager(temp_file)
            
            # Mock copybook
            copybook_mock = MagicMock()
            copybook_mock.name = "TEST-COPYBOOK"
            copybook_mock.content = "01 TEST-FIELD PIC X(10)."
            
            prompt = manager.create_custom_analysis_prompt(
                program_name="TEST-PROGRAM",
                program_code="IDENTIFICATION DIVISION.",
                copybooks=[copybook_mock]
            )
            
            self.assertIn("TEST-PROGRAM", prompt)
            self.assertIn("IDENTIFICATION DIVISION", prompt)
            self.assertIn("TEST-COPYBOOK", prompt)
            self.assertIn("PROMPT CUSTOMIZADO", prompt)
            
        finally:
            os.unlink(temp_file)
    
    def test_get_prompt_info(self):
        """Testa obtenção de informações do prompt."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
            f.write(self.test_prompt_content)
            temp_file = f.name
        
        try:
            manager = CustomPromptManager(temp_file)
            info = manager.get_prompt_info()
            
            self.assertEqual(info['status'], 'custom_prompt_loaded')
            self.assertEqual(info['file'], temp_file)
            self.assertGreater(info['size'], 0)
            self.assertIn('preview', info)
            
        finally:
            os.unlink(temp_file)
    
    def test_no_custom_prompt_info(self):
        """Testa informações quando não há prompt customizado."""
        manager = CustomPromptManager()
        info = manager.get_prompt_info()
        
        self.assertEqual(info['status'], 'no_custom_prompt')

if __name__ == '__main__':
    unittest.main()
