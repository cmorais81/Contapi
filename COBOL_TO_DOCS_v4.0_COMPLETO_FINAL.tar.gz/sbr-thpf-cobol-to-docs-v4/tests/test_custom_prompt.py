import unittest
import tempfile
import os
import sys

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'cobol_to_docs', 'src'))

from core.custom_prompt_manager import CustomPromptManager

class TestCustomPromptManager(unittest.TestCase):
    
    def setUp(self):
        self.temp_file = tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.txt')
        self.temp_file.write("Teste de prompt customizado: {program_name}\n{cobol_code}")
        self.temp_file.close()
    
    def tearDown(self):
        os.unlink(self.temp_file.name)
    
    def test_custom_prompt_loading(self):
        """Testa carregamento de prompt customizado."""
        manager = CustomPromptManager(self.temp_file.name)
        self.assertTrue(manager.has_custom_prompt())
    
    def test_prompt_info(self):
        """Testa informações do prompt."""
        manager = CustomPromptManager(self.temp_file.name)
        info = manager.get_prompt_info()
        self.assertIn('size', info)
        self.assertIn('file', info)
        self.assertGreater(info['size'], 0)
    
    def test_create_analysis_prompt(self):
        """Testa criação de prompt de análise."""
        manager = CustomPromptManager(self.temp_file.name)
        prompt = manager.create_custom_analysis_prompt(
            program_name="TESTE",
            program_code="IDENTIFICATION DIVISION.",
            copybooks=[]
        )
        self.assertIn("TESTE", prompt)
        self.assertIn("IDENTIFICATION DIVISION", prompt)

if __name__ == '__main__':
    unittest.main()
