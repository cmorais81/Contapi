import unittest
from unittest.mock import patch, MagicMock
import sys
import os

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'cobol_to_docs', 'src'))

from providers.enhanced_provider_manager import EnhancedProviderManager
from providers.base_provider import AIRequest

class TestEnhancedProviderManager(unittest.TestCase):
    
    @patch('providers.enhanced_provider_manager.ConfigManager')
    def test_provider_initialization(self, mock_config):
        """Testa inicialização do provider manager."""
        mock_config.return_value.config = {
            'providers': {
                'enhanced_mock': {'enabled': True}
            }
        }
        
        manager = EnhancedProviderManager(mock_config.return_value.config)
        self.assertIsNotNone(manager)
    
    def test_ai_request_creation(self):
        """Testa criação de AIRequest."""
        request = AIRequest(
            prompt="Teste",
            program_code="COBOL CODE",
            program_name="TESTE",
            context={'model': 'test'}
        )
        
        self.assertEqual(request.prompt, "Teste")
        self.assertEqual(request.program_code, "COBOL CODE")
        self.assertEqual(request.program_name, "TESTE")

if __name__ == '__main__':
    unittest.main()
