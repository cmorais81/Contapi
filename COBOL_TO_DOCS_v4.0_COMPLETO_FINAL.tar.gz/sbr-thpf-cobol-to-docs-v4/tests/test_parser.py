import unittest
import tempfile
import os
import sys

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'cobol_to_docs', 'src'))

from parsers.cobol_parser import COBOLParser

class TestCOBOLParser(unittest.TestCase):
    
    def setUp(self):
        self.parser = COBOLParser()
        
        # Criar arquivo COBOL temporário
        self.temp_file = tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.cbl')
        cobol_code = """IDENTIFICATION DIVISION.
PROGRAM-ID. TESTE.

DATA DIVISION.
WORKING-STORAGE SECTION.
01 WS-VAR PIC X(10).

PROCEDURE DIVISION.
MAIN-PROCESS.
    DISPLAY 'HELLO WORLD'.
    STOP RUN.
"""
        self.temp_file.write(cobol_code)
        self.temp_file.close()
    
    def tearDown(self):
        os.unlink(self.temp_file.name)
    
    def test_parser_initialization(self):
        """Testa inicialização do parser."""
        self.assertIsNotNone(self.parser)
    
    def test_parse_cobol_file(self):
        """Testa parsing de arquivo COBOL."""
        result = self.parser.parse_file(self.temp_file.name)
        
        # Verificar se retorna tupla (programs, copybooks)
        self.assertIsInstance(result, tuple)
        self.assertEqual(len(result), 2)
        
        programs, copybooks = result
        self.assertIsInstance(programs, list)
        self.assertIsInstance(copybooks, list)
        
        if programs:
            program = programs[0]
            self.assertEqual(program.name, "TESTE")
            self.assertIn("IDENTIFICATION DIVISION", program.content)

if __name__ == '__main__':
    unittest.main()
