import unittest
import os
import tempfile
from unittest.mock import patch, MagicMock
import sys

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'cobol_to_docs', 'src'))

from core.config import ConfigManager

class TestConfigManager(unittest.TestCase):
    
    def setUp(self):
        self.temp_dir = tempfile.mkdtemp()
    
    def test_config_initialization(self):
        """Testa inicialização do ConfigManager."""
        config_manager = ConfigManager()
        self.assertIsNotNone(config_manager)
        self.assertIsNotNone(config_manager.config)
    
    def test_get_data_dir(self):
        """Testa obtenção do diretório de dados."""
        config_manager = ConfigManager()
        data_dir = config_manager.get_data_dir()
        self.assertIsInstance(data_dir, str)
        self.assertTrue(len(data_dir) > 0)
    
    def test_get_config_dir(self):
        """Testa obtenção do diretório de configuração."""
        config_manager = ConfigManager()
        config_dir = config_manager.get_config_dir()
        self.assertIsInstance(config_dir, str)
        self.assertTrue(len(config_dir) > 0)

if __name__ == '__main__':
    unittest.main()
