# COBOL-to-docs v4.0 - Suporte a Prompts Customizados

## 🎯 Nova Funcionalidade: --prompt

A versão 4.0 introduz suporte completo a prompts customizados via arquivos .txt, permitindo análises totalmente personalizadas.

## 🚀 Como Usar

### Execução via main.py
```bash
python3 cobol_to_docs/runner/main.py --fontes fontes.txt --books books.txt --prompt meu_prompt.txt --output resultado
```

### Execução via CLI
```bash
python3 cobol_to_docs/runner/cli.py --fontes fontes.txt --prompt meu_prompt.txt
```

### Execução via pip install
```bash
cobol-to-docs --fontes fontes.txt --books books.txt --prompt meu_prompt.txt --output resultado
```

## 📝 Formato do Arquivo de Prompt

O arquivo .txt pode conter placeholders que serão substituídos automaticamente:

```
Você é um especialista em análise COBOL bancário.

Analise o programa: {program_name}

Código COBOL:
{cobol_code}

Copybooks disponíveis:
{copybooks}

Instruções específicas:
1. Extraia todas as regras de negócio
2. Identifique cálculos financeiros
3. Liste validações de dados
4. Sugira componentes reutilizáveis
```

### Placeholders Disponíveis:
- `{program_name}` - Nome do programa
- `{program_code}` - Código COBOL completo
- `{cobol_code}` - Alias para program_code
- `{copybooks}` - Conteúdo de todos os copybooks
- `{system_documentation}` - Documentação completa (programa + copybooks)

## 🔧 Funcionalidades

### ✅ Compatibilidade Total
- Funciona com todos os métodos de execução
- Mantém compatibilidade com prompts padrões
- Sistema de fallback automático

### ✅ Logging Detalhado
- Informações sobre o prompt customizado carregado
- Debug JSON completo com metadados do prompt
- Rastreamento de substituições de placeholders

### ✅ Validação Robusta
- Verificação de existência do arquivo
- Tratamento de erros de carregamento
- Fallback para prompts padrões em caso de erro

## 📊 Exemplo de Saída

### Arquivo Gerado: `PROGRAMA_custom_prompt_analise.md`
```markdown
# Análise do Programa PROGRAMA

**Modelo utilizado:** custom_prompt
**Provider:** enhanced_mock
**Tokens utilizados:** 2,500
**Tempo de resposta:** 0.45s
**Prompt customizado:** meu_prompt.txt (1,234 chars)

## Análise

[Conteúdo da análise baseado no prompt customizado]
```

### Debug JSON: `PROGRAMA_custom_prompt_debug.json`
```json
{
  "metadata": {
    "program_name": "PROGRAMA",
    "timestamp": "2025-10-13T15:30:00.000000",
    "formatter_version": "enhanced_v1.0"
  },
  "request": {
    "program_name": "PROGRAMA",
    "model": "custom_prompt",
    "prompt_length": 5678,
    "prompt_file": "meu_prompt.txt",
    "custom_prompt": true,
    "copybooks_count": 2
  },
  "response": {
    "success": true,
    "content": "[Resposta completa preservada]",
    "tokens_used": 2500,
    "provider": "enhanced_mock"
  }
}
```

## 🎯 Casos de Uso

### 1. Análise Especializada por Domínio
```
# prompt_bancario.txt
Você é um especialista em sistemas bancários COBOL.
Foque em: cálculos de juros, tarifas, validações regulamentares.
Programa: {program_name}
Código: {cobol_code}
```

### 2. Extração de Componentes Reutilizáveis
```
# prompt_componentes.txt
Identifique componentes que podem ser extraídos como serviços:
- APIs reutilizáveis
- Cálculos padronizáveis  
- Validações centralizáveis
Programa: {program_name}
Código: {cobol_code}
```

### 3. Análise de Migração
```
# prompt_migracao.txt
Analise este código COBOL para migração para arquitetura moderna:
- Complexidade de migração (1-10)
- Dependências críticas
- Estratégia de conversão
Programa: {program_name}
Código: {cobol_code}
```

## 🔄 Integração com Prompts Padrões

O sistema mantém todos os prompts padrões atualizados com o conteúdo do arquivo Minato:

- `business_rule_extraction` - Extração de regras de negócio
- `financial_calculations` - Cálculos financeiros
- `data_validation_rules` - Validações de dados
- `detailed_copybook_analysis` - Análise de copybooks
- `deep_business_analysis` - Análise profunda de negócio
- `component_design_and_abstraction` - Design de componentes

## 🧪 Testes

Execute os testes para validar o funcionamento:

```bash
cd sbr-thpf-cobol-to-docs-v4
python3 -m unittest tests.test_custom_prompt_manager -v
```

## 📈 Benefícios

### ✅ Flexibilidade Total
- Prompts 100% customizáveis
- Análises específicas por contexto
- Adaptação a diferentes necessidades

### ✅ Produtividade
- Reutilização de prompts especializados
- Análises consistentes e padronizadas
- Automação de processos específicos

### ✅ Qualidade
- Prompts otimizados para casos específicos
- Resultados mais precisos e relevantes
- Controle total sobre o processo de análise

**Status:** ✅ **IMPLEMENTADO E TESTADO - PRONTO PARA USO**
