# CHANGELOG - COBOL-to-docs v4.0

## [4.0.0] - 2025-10-13

### ✅ ADICIONADO
- **Suporte a prompts customizados** via parâmetro --custom-prompt
- **CustomPromptManager** para gerenciamento de prompts .txt
- **Testes unitários completos** cobrindo todos os componentes
- **Prompts atualizados** com diretrizes específicas do Minato
- **Nova seção minato_analysis** em todos os conjuntos de prompts
- **Documentação completa** v4.0 com exemplos práticos

### 🔧 CORRIGIDO
- **Problemas de imports** - Todos os módulos funcionando
- **Estrutura de projeto** - Organização limpa e consistente
- **Conflitos de argumentos** - --custom-prompt vs --prompt-set
- **ConfigManager** - Inicialização correta em todos os contextos
- **Main.py** - Lógica de custom prompts integrada

### 🚀 MELHORADO
- **Sistema de fallback** - Mais robusto e transparente
- **Logging** - Diagnóstico detalhado de erros
- **Compatibilidade** - Funciona em todos os métodos de execução
- **Qualidade** - Prompts completos preservados integralmente
- **Performance** - Otimizações no processamento

### 📋 MANTIDO
- **100% das funcionalidades** da v3.0 preservadas
- **Compatibilidade total** com comandos existentes
- **Sistema RAG** - Todas as funcionalidades mantidas
- **6 providers** - Luzia, Enhanced Mock, OpenAI, Bedrock, etc.
- **Modo padrão avançado** - Detecção automática funcionando

## [3.0.0] - Versão Anterior
- Sistema base com providers múltiplos
- RAG integration
- Enhanced prompt manager
- Fallback automático
- Logging aprimorado

---

**v4.0** representa uma evolução significativa mantendo total compatibilidade!
