"""
Custom Prompt Manager para suporte a arquivos .txt personalizados
"""

import os
import logging
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)

class CustomPromptManager:
    """Gerenciador de prompts customizados via arquivo .txt."""
    
    def __init__(self, custom_prompt_file: Optional[str] = None):
        """
        Inicializa o Custom Prompt Manager.
        
        Args:
            custom_prompt_file: Caminho para arquivo .txt com prompt customizado
        """
        self.custom_prompt_file = custom_prompt_file
        self.custom_prompt_content = None
        
        if custom_prompt_file:
            self._load_custom_prompt()
    
    def _load_custom_prompt(self) -> None:
        """Carrega o prompt customizado do arquivo .txt."""
        if not self.custom_prompt_file or not os.path.exists(self.custom_prompt_file):
            logger.warning(f"Arquivo de prompt customizado não encontrado: {self.custom_prompt_file}")
            return
        
        try:
            with open(self.custom_prompt_file, 'r', encoding='utf-8') as f:
                self.custom_prompt_content = f.read().strip()
            
            logger.info(f"Prompt customizado carregado: {len(self.custom_prompt_content)} caracteres")
            logger.info(f"Arquivo: {self.custom_prompt_file}")
            
        except Exception as e:
            logger.error(f"Erro ao carregar prompt customizado: {e}")
            self.custom_prompt_content = None
    
    def has_custom_prompt(self) -> bool:
        """Verifica se há um prompt customizado carregado."""
        return self.custom_prompt_content is not None
    
    def create_custom_analysis_prompt(self, 
                                    program_name: str,
                                    program_code: str,
                                    copybooks: list = None,
                                    **kwargs) -> str:
        """
        Cria prompt de análise usando o prompt customizado.
        
        Args:
            program_name: Nome do programa
            program_code: Código COBOL do programa
            copybooks: Lista de copybooks
            **kwargs: Argumentos adicionais
            
        Returns:
            Prompt completo para análise
        """
        if not self.has_custom_prompt():
            raise ValueError("Nenhum prompt customizado carregado")
        
        # Preparar copybooks
        copybooks_text = ""
        if copybooks:
            copybooks_text = "\n\n=== COPYBOOKS DISPONÍVEIS ===\n"
            for copybook in copybooks:
                copybooks_text += f"\n--- {copybook.name} ---\n"
                copybooks_text += copybook.content
        
        # Substituir placeholders no prompt customizado
        prompt = self.custom_prompt_content
        
        # Substituições básicas
        replacements = {
            '{program_name}': program_name,
            '{program_code}': program_code,
            '{cobol_code}': program_code,
            '{copybooks}': copybooks_text,
            '{system_documentation}': f"PROGRAMA: {program_name}\n\n{program_code}{copybooks_text}"
        }
        
        # Aplicar substituições
        for placeholder, value in replacements.items():
            if placeholder in prompt:
                prompt = prompt.replace(placeholder, value)
                logger.debug(f"Substituído {placeholder} no prompt customizado")
        
        # Adicionar metadados
        final_prompt = f"""=== PROMPT CUSTOMIZADO ===
Arquivo: {os.path.basename(self.custom_prompt_file)}
Programa: {program_name}
Copybooks: {len(copybooks) if copybooks else 0}

{prompt}

=== CÓDIGO COBOL PARA ANÁLISE ===
{program_code}

{copybooks_text}
"""
        
        logger.info(f"Prompt customizado criado: {len(final_prompt)} caracteres")
        return final_prompt
    
    def get_prompt_info(self) -> Dict[str, Any]:
        """Retorna informações sobre o prompt customizado."""
        if not self.has_custom_prompt():
            return {"status": "no_custom_prompt"}
        
        return {
            "status": "custom_prompt_loaded",
            "file": self.custom_prompt_file,
            "size": len(self.custom_prompt_content),
            "preview": self.custom_prompt_content[:200] + "..." if len(self.custom_prompt_content) > 200 else self.custom_prompt_content
        }
