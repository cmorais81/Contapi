#!/usr/bin/env python3
"""
COBOL to Docs v3.0 - Sistema de Análise e Documentação de Programas COBOL
Sistema completo para análise automatizada de programas COBOL com IA.

FUNCIONALIDADES:
- Processamento de múltiplos programas COBOL
- Suporte a múltiplos modelos de IA com fallback
- Análise de copybooks complementares
- Sistema RAG para contexto expandido
- Modo padrão avançado automático
- Geração de documentação profissional
"""

import argparse
import logging
import os
import sys
import json
import time
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple

# Configurar path para imports
current_dir = os.path.dirname(os.path.abspath(__file__))
src_dir = os.path.join(current_dir, '..', 'src')
sys.path.insert(0, src_dir)

# Imports do sistema
from core.config import ConfigManager
from parsers.cobol_parser import COBOLParser
from providers.enhanced_provider_manager import EnhancedProviderManager
from rag.rag_integration import RAGIntegration
from rag.rag_maintenance import RAGMaintenance
from utils.cost_calculator import CostCalculator
from generators.advanced_report_generator import HTMLReportGenerator
from generators.documentation_generator import DocumentationGenerator
from analyzers.enhanced_cobol_analyzer import EnhancedCOBOLAnalyzer
from analyzers.consolidated_analyzer import ConsolidatedAnalyzer
from core.prompt_manager_dual import DualPromptManager
from core.intelligent_model_selector import IntelligentModelSelector
from providers.base_provider import AIRequest
from core.enhanced_prompt_manager import EnhancedPromptManager
from utils.enhanced_response_formatter import EnhancedResponseFormatter
from core.custom_prompt_manager import CustomPromptManager

def setup_logging(log_level: str = "INFO") -> None:
    """Configura o sistema de logging."""
    log_dir = "logs"
    os.makedirs(log_dir, exist_ok=True)
    
    log_file = os.path.join(log_dir, f"cobol_to_docs_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
    
    logging.basicConfig(
        level=getattr(logging, log_level.upper(), logging.INFO),
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(),
            logging.FileHandler(log_file)
        ]
    )

def parse_arguments():
    """Parse dos argumentos da linha de comando."""
    parser = argparse.ArgumentParser(
        description='COBOL to Docs v3.0 - Análise e Documentação de Programas COBOL com IA',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
Exemplos de uso:
  python3 main.py --fontes fontes.txt --books books.txt
  python3 main.py --fontes fontes.txt --consolidado --analise-especialista
  python3 main.py --status
  python3 main.py --rag-stats
        '''
    )
    
    # Argumentos principais
    parser.add_argument('--fontes', type=str, help='Arquivo com lista de programas COBOL')
    parser.add_argument('--books', type=str, help='Arquivo com lista de copybooks')
    parser.add_argument('--custom-prompt', type=str, help='Arquivo .txt com prompt customizado')
    parser.add_argument('--output', type=str, default='output', help='Diretório de saída')
    parser.add_argument('--log-level', type=str, default='INFO', help='Nível de log')
    
    # Modos de análise
    parser.add_argument('--consolidado', action='store_true', help='Análise consolidada sistêmica')
    parser.add_argument('--analise-especialista', action='store_true', help='Análise especialista')
    parser.add_argument('--deep-analysis', action='store_true', help='Análise detalhada de regras')
    parser.add_argument('--relatorio-unico', action='store_true', help='Relatório único consolidado')
    parser.add_argument('--procedure-detalhada', action='store_true', help='Análise detalhada de procedures')
    parser.add_argument('--modernizacao', action='store_true', help='Análise de modernização')
    
    # Configurações
    parser.add_argument('--config-dir', type=str, help='Diretório de configuração customizado')
    parser.add_argument('--data-dir', type=str, help='Diretório de dados customizado')
    parser.add_argument('--prompts-file', type=str, help='Arquivo de prompts customizado')
    parser.add_argument('--prompt-set', type=str, default='especialista', help='Conjunto de prompts')
    
    # RAG
    parser.add_argument('--rag-stats', action='store_true', help='Estatísticas da base RAG')
    parser.add_argument('--rag-backup', action='store_true', help='Backup da base RAG')
    parser.add_argument('--rag-clean', action='store_true', help='Limpeza da base RAG')
    parser.add_argument('--rag-reindex', action='store_true', help='Reindexar base RAG')
    
    # Status
    parser.add_argument('--status', action='store_true', help='Status do sistema')
    
    return parser.parse_args()

def main_logic():
    """Lógica principal da aplicação."""
    args = parse_arguments()
    
    # Configurar logging
    setup_logging(args.log_level)
    logger = logging.getLogger(__name__)
    
    try:
        # Inicializar configuração
        config_manager = ConfigManager(
            config_path=args.config_dir,
            data_dir=args.data_dir,
            prompts_file=args.prompts_file
        )
        
        # Status do sistema
        if args.status:
            print("=== STATUS DO SISTEMA ===")
            
            # Status dos providers
            try:
                provider_manager = EnhancedProviderManager(config_manager.config)
                print("\\nProviders disponíveis:")
                for provider_name, provider in provider_manager.providers.items():
                    status = "✅ Ativo" if provider else "❌ Inativo"
                    print(f"  {provider_name}: {status}")
            except Exception as e:
                print(f"Erro ao verificar providers: {e}")
            
            # Status RAG
            try:
                rag_integration = RAGIntegration(config_manager)
                stats = rag_integration.get_rag_statistics()
                print(f"\\nSistema RAG:")
                print(f"  Base de conhecimento: {stats.get('total_items', 0)} itens")
                print(f"  Status: ✅ Ativo")
            except Exception as e:
                print(f"  Status RAG: ❌ Erro - {e}")
            
            return
        
        # Detecção de modo padrão avançado
        if not any([
            args.consolidado, 
            args.relatorio_unico, 
            args.analise_especialista, 
            args.procedure_detalhada, 
            args.modernizacao,
            args.deep_analysis,
            args.status,
            args.rag_stats,
            args.rag_backup,
            args.rag_clean,
            args.rag_reindex
        ]):
            logger.info("=== NENHUM MODO ESPECÍFICO ESCOLHIDO - ATIVANDO MODO AVANÇADO PADRÃO ===")
            logger.info("Ativando: --consolidado + --analise-especialista + --deep-analysis")
            args.consolidado = True
            args.analise_especialista = True
            args.deep_analysis = True
            args.custom_prompt_set = 'especialista'
        
        # RAG Maintenance Operations
        if args.rag_reindex or args.rag_stats or args.rag_backup or args.rag_clean:
            data_dir = config_manager.get_data_dir()
            maintenance = RAGMaintenance(data_dir)
            
            if args.rag_stats:
                print("=== ESTATÍSTICAS DA BASE RAG ===")
                stats = maintenance.get_base_statistics()
                for key, value in stats.items():
                    if key == 'programs_distribution' and isinstance(value, dict):
                        print(f"{key}:")
                        for prog, count in value.items():
                            print(f"  {prog}: {count} entradas")
                    else:
                        print(f"{key}: {value}")
            
            if args.rag_backup:
                backup_file = maintenance.create_backup()
                print(f"Backup criado: {backup_file}")
            
            if args.rag_clean:
                removed = maintenance.clean_duplicates()
                print(f"Duplicatas removidas: {removed}")
            
            if args.rag_reindex:
                maintenance.reindex_knowledge_base()
                print("Base RAG reindexada com sucesso")
            
            return
        
        # Verificar arquivos obrigatórios
        if not args.fontes:
            logger.error("Arquivo de fontes é obrigatório")
            print("Erro: Especifique o arquivo de fontes com --fontes")
            return
        
        if not os.path.exists(args.fontes):
            logger.error(f"Arquivo de fontes não encontrado: {args.fontes}")
            print(f"Erro: Arquivo {args.fontes} não encontrado")
            return
        
        # Criar diretório de saída
        os.makedirs(args.output, exist_ok=True)
        
        # Inicializar componentes
        provider_manager = EnhancedProviderManager(config_manager.config)
        parser = COBOLParser()
        cost_calculator = CostCalculator()
        
        # Ler programas
        with open(args.fontes, 'r', encoding='utf-8') as f:
            program_files = [line.strip() for line in f if line.strip()]
        
        # Ler copybooks se especificado
        copybook_files = []
        if args.books and os.path.exists(args.books):
            with open(args.books, 'r', encoding='utf-8') as f:
                copybook_files = [line.strip() for line in f if line.strip()]
        
        # Processar programas
        programs = []
        copybooks = []
        
        for program_file in program_files:
            if os.path.exists(program_file):

                try:
                    if use_custom_prompt and custom_prompt_manager:
                        # Usar Custom Prompt Manager
                        prompt = custom_prompt_manager.create_custom_analysis_prompt(
                            program_name=program.name,
                            program_code=program.content,
                            copybooks=copybooks
                        )
                        
                        # Criar request
                        request = AIRequest(
                            prompt=prompt,
                            program_code=program.content,
                            program_name=program.name,
                            context={'model': 'custom_prompt', 'prompt_file': args.custom_prompt}
                        )
                        
                        # Fazer análise
                        response = provider_manager.analyze(request)
                        
                        if response.success:
                            # Salvar com sufixo custom_prompt
                            output_file = os.path.join(args.output, f"{program.name}_custom_prompt_analise.md")
                            debug_file = os.path.join(args.output, f"{program.name}_custom_prompt_debug.json")
                            
                            # Usar Enhanced Response Formatter
                            response_formatter = EnhancedResponseFormatter()
                            
                            request_info = {
                                'program_name': program.name,
                                'model': 'custom_prompt',
                                'prompt_length': len(prompt),
                                'program_code_length': len(program.content),
                                'prompt_file': args.custom_prompt,
                                'copybooks_count': len(copybooks),
                                'custom_prompt': True
                            }
                            
                            complete_report = response_formatter.format_complete_analysis_report(
                                program_name=program.name,
                                response=response,
                                request_info=request_info,
                                debug_mode=True
                            )
                            
                            with open(output_file, 'w', encoding='utf-8') as f:
                                f.write(complete_report)
                            
                            debug_data = response_formatter.create_debug_json(
                                program_name=program.name,
                                request_info=request_info,
                                response=response
                            )
                            
                            with open(debug_file, 'w', encoding='utf-8') as f:
                                json.dump(debug_data, f, indent=2, ensure_ascii=False)
                            
                            logger.info(f"Análise customizada salva em: {output_file}")
                            print(f"   Análise concluída - {response.tokens_used} tokens")
                            
                            all_results.append({
                                'program': program.name,
                                'model': 'custom_prompt',
                                'success': True,
                                'tokens': response.tokens_used,
                                'time': response.response_time,
                                'output_file': output_file
                            })
                            
                            continue  # Pular análise padrão
                        
                        else:
                            logger.error(f"Erro com prompt customizado: {response.error_message}")
                            print(f"   Erro: {response.error_message}")
                            # Continuar com análise padrão como fallback
                    
                    # Análise padrão (existente)
                    parsed_programs, parsed_books = parser.parse_file(program_file)
                    programs.extend(parsed_programs)
                    copybooks.extend(parsed_books)
                    logger.info(f"Arquivo processado: {program_file} - {len(parsed_programs)} programas, {len(parsed_books)} copybooks")
                except Exception as e:
                    logger.error(f"Erro ao processar {program_file}: {e}")
        
        # Processar copybooks adicionais
        for copybook_file in copybook_files:
            if os.path.exists(copybook_file):

                try:
                    if use_custom_prompt and custom_prompt_manager:
                        # Usar Custom Prompt Manager
                        prompt = custom_prompt_manager.create_custom_analysis_prompt(
                            program_name=program.name,
                            program_code=program.content,
                            copybooks=copybooks
                        )
                        
                        # Criar request
                        request = AIRequest(
                            prompt=prompt,
                            program_code=program.content,
                            program_name=program.name,
                            context={'model': 'custom_prompt', 'prompt_file': args.custom_prompt}
                        )
                        
                        # Fazer análise
                        response = provider_manager.analyze(request)
                        
                        if response.success:
                            # Salvar com sufixo custom_prompt
                            output_file = os.path.join(args.output, f"{program.name}_custom_prompt_analise.md")
                            debug_file = os.path.join(args.output, f"{program.name}_custom_prompt_debug.json")
                            
                            # Usar Enhanced Response Formatter
                            response_formatter = EnhancedResponseFormatter()
                            
                            request_info = {
                                'program_name': program.name,
                                'model': 'custom_prompt',
                                'prompt_length': len(prompt),
                                'program_code_length': len(program.content),
                                'prompt_file': args.custom_prompt,
                                'copybooks_count': len(copybooks),
                                'custom_prompt': True
                            }
                            
                            complete_report = response_formatter.format_complete_analysis_report(
                                program_name=program.name,
                                response=response,
                                request_info=request_info,
                                debug_mode=True
                            )
                            
                            with open(output_file, 'w', encoding='utf-8') as f:
                                f.write(complete_report)
                            
                            debug_data = response_formatter.create_debug_json(
                                program_name=program.name,
                                request_info=request_info,
                                response=response
                            )
                            
                            with open(debug_file, 'w', encoding='utf-8') as f:
                                json.dump(debug_data, f, indent=2, ensure_ascii=False)
                            
                            logger.info(f"Análise customizada salva em: {output_file}")
                            print(f"   Análise concluída - {response.tokens_used} tokens")
                            
                            all_results.append({
                                'program': program.name,
                                'model': 'custom_prompt',
                                'success': True,
                                'tokens': response.tokens_used,
                                'time': response.response_time,
                                'output_file': output_file
                            })
                            
                            continue  # Pular análise padrão
                        
                        else:
                            logger.error(f"Erro com prompt customizado: {response.error_message}")
                            print(f"   Erro: {response.error_message}")
                            # Continuar com análise padrão como fallback
                    
                    # Análise padrão (existente)
                    parsed_programs, parsed_books = parser.parse_file(copybook_file)
                    copybooks.extend(parsed_books)
                    logger.info(f"Copybook processado: {copybook_file} - {len(parsed_books)} copybooks")
                except Exception as e:
                    logger.error(f"Erro ao processar copybook {copybook_file}: {e}")
        
        if not programs:
            logger.error("Nenhum programa válido encontrado")
            print("Erro: Nenhum programa COBOL válido encontrado")
            return
        
        
        # NOVO: Verificar se deve usar prompt customizado
        use_custom_prompt = getattr(args, 'custom_prompt', None) and os.path.exists(getattr(args, 'custom_prompt', ''))
        custom_prompt_manager = None
        
        if use_custom_prompt:
            logger.info(f"=== USANDO PROMPT CUSTOMIZADO: {args.custom_prompt} ===")
            try:
                custom_prompt_manager = CustomPromptManager(args.custom_prompt)
                
                if not custom_prompt_manager.has_custom_prompt():
                    logger.error("Falha ao carregar prompt customizado")
                    print("Erro: Não foi possível carregar o prompt customizado")
                    use_custom_prompt = False
                else:
                    prompt_info = custom_prompt_manager.get_prompt_info()
                    logger.info(f"Prompt customizado: {prompt_info['size']} caracteres")
                    print(f"Usando prompt customizado: {os.path.basename(args.custom_prompt)} ({prompt_info['size']} chars)")
            except Exception as e:
                logger.error(f"Erro ao inicializar custom prompt: {e}")
                use_custom_prompt = False
        else:
            logger.info("=== USANDO PROMPTS PADRÕES ===")
\n        # Executar análise
        print(f"\\nIniciando análise de {len(programs)} programa(s)...")
        
        start_time = time.time()
        all_results = []
        models = ['enhanced_mock']  # Modelo padrão para fallback
        
        for i, program in enumerate(programs, 1):
            print(f"Analisando programa {i}/{len(programs)}: {program.name}")
            
            for model in models:

                try:
                    if use_custom_prompt and custom_prompt_manager:
                        # Usar Custom Prompt Manager
                        prompt = custom_prompt_manager.create_custom_analysis_prompt(
                            program_name=program.name,
                            program_code=program.content,
                            copybooks=copybooks
                        )
                        
                        # Criar request
                        request = AIRequest(
                            prompt=prompt,
                            program_code=program.content,
                            program_name=program.name,
                            context={'model': 'custom_prompt', 'prompt_file': args.custom_prompt}
                        )
                        
                        # Fazer análise
                        response = provider_manager.analyze(request)
                        
                        if response.success:
                            # Salvar com sufixo custom_prompt
                            output_file = os.path.join(args.output, f"{program.name}_custom_prompt_analise.md")
                            debug_file = os.path.join(args.output, f"{program.name}_custom_prompt_debug.json")
                            
                            # Usar Enhanced Response Formatter
                            response_formatter = EnhancedResponseFormatter()
                            
                            request_info = {
                                'program_name': program.name,
                                'model': 'custom_prompt',
                                'prompt_length': len(prompt),
                                'program_code_length': len(program.content),
                                'prompt_file': args.custom_prompt,
                                'copybooks_count': len(copybooks),
                                'custom_prompt': True
                            }
                            
                            complete_report = response_formatter.format_complete_analysis_report(
                                program_name=program.name,
                                response=response,
                                request_info=request_info,
                                debug_mode=True
                            )
                            
                            with open(output_file, 'w', encoding='utf-8') as f:
                                f.write(complete_report)
                            
                            debug_data = response_formatter.create_debug_json(
                                program_name=program.name,
                                request_info=request_info,
                                response=response
                            )
                            
                            with open(debug_file, 'w', encoding='utf-8') as f:
                                json.dump(debug_data, f, indent=2, ensure_ascii=False)
                            
                            logger.info(f"Análise customizada salva em: {output_file}")
                            print(f"   Análise concluída - {response.tokens_used} tokens")
                            
                            all_results.append({
                                'program': program.name,
                                'model': 'custom_prompt',
                                'success': True,
                                'tokens': response.tokens_used,
                                'time': response.response_time,
                                'output_file': output_file
                            })
                            
                            continue  # Pular análise padrão
                        
                        else:
                            logger.error(f"Erro com prompt customizado: {response.error_message}")
                            print(f"   Erro: {response.error_message}")
                            # Continuar com análise padrão como fallback
                    
                    # Análise padrão (existente)

                    if use_custom_prompt:
                        # Usar Custom Prompt Manager
                        prompt = custom_prompt_manager.create_custom_analysis_prompt(
                            program_name=program.name,
                            program_code=program.content,
                            copybooks=copybooks
                        )
                        
                        # Criar request
                        request = AIRequest(
                            prompt=prompt,
                            program_code=program.content,
                            program_name=program.name,
                            context={'model': 'custom_prompt', 'prompt_file': args.custom_prompt}
                        )
                        
                        # Fazer análise
                        response = provider_manager.analyze(request)
                        
                        if response.success:
                            # Salvar com sufixo custom_prompt
                            output_file = os.path.join(args.output, f"{program.name}_custom_prompt_analise.md")
                            debug_file = os.path.join(args.output, f"{program.name}_custom_prompt_debug.json")
                            
                            # Usar Enhanced Response Formatter
                            response_formatter = EnhancedResponseFormatter()
                            
                            request_info = {
                                'program_name': program.name,
                                'model': 'custom_prompt',
                                'prompt_length': len(prompt),
                                'program_code_length': len(program.content),
                                'prompt_file': args.custom_prompt,
                                'copybooks_count': len(copybooks),
                                'custom_prompt': True
                            }
                            
                            complete_report = response_formatter.format_complete_analysis_report(
                                program_name=program.name,
                                response=response,
                                request_info=request_info,
                                debug_mode=True
                            )
                            
                            with open(output_file, 'w', encoding='utf-8') as f:
                                f.write(complete_report)
                            
                            debug_data = response_formatter.create_debug_json(
                                program_name=program.name,
                                request_info=request_info,
                                response=response
                            )
                            
                            with open(debug_file, 'w', encoding='utf-8') as f:
                                import json
                                json.dump(debug_data, f, indent=2, ensure_ascii=False)
                            
                            logger.info(f"Análise customizada salva em: {output_file}")
                            print(f"   Análise concluída - {response.tokens_used} tokens")
                            
                            all_results.append({
                                'program': program.name,
                                'model': 'custom_prompt',
                                'success': True,
                                'tokens': response.tokens_used,
                                'time': response.response_time,
                                'output_file': output_file
                            })
                            
                            continue  # Pular análise padrão
                        
                        else:
                            logger.error(f"Erro com prompt customizado: {response.error_message}")
                            print(f"   Erro: {response.error_message}")
                            # Continuar com análise padrão como fallback
                    
                    # Análise padrão (existente)
                    # Criar prompt COMPLETO usando Enhanced Prompt Manager
                    enhanced_prompt_manager = EnhancedPromptManager(config_manager)
                    prompt = enhanced_prompt_manager.create_complete_analysis_prompt(
                        program_name=program.name,
                        program_code=program.content,
                        copybooks=copybooks,
                        prompt_set=args.custom_prompt_set
                    )
                    
                    # Criar request
                    request = AIRequest(
                        prompt=prompt,
                        program_code=program.content,
                        program_name=program.name,
                        context={'model': model}
                    )
                    
                    # Fazer análise
                    response = provider_manager.analyze(request)
                    
                    if response.success:
                        # Criar Enhanced Response Formatter
                        response_formatter = EnhancedResponseFormatter()
                        
                        # Informações do request para debug
                        request_info = {
                            'program_name': request.program_name,
                            'model': request.context.get('model', model),
                            'prompt_length': len(request.prompt),
                            'program_code_length': len(request.program_code),
                            'prompt_set': args.custom_prompt_set,
                            'copybooks_count': len(copybooks)
                        }
                        
                        # Gerar relatório completo
                        complete_report = response_formatter.format_complete_analysis_report(
                            program_name=program.name,
                            response=response,
                            request_info=request_info,
                            debug_mode=True
                        )
                        
                        # Salvar relatório
                        output_file = os.path.join(args.output, f"{program.name}_{model}_analise.md")
                        with open(output_file, 'w', encoding='utf-8') as f:
                            f.write(complete_report)
                        with open(output_file, 'w', encoding='utf-8') as f:
                            f.write(f"# Análise do Programa {program.name}\\n\\n")
                            f.write(f"**Modelo utilizado:** {response.model}\\n")
                            f.write(f"**Provider:** {response.provider}\\n")
                            f.write(f"**Tokens utilizados:** {response.tokens_used}\\n")
                            f.write(f"**Tempo de resposta:** {response.response_time:.2f}s\\n\\n")
                            f.write("## Análise\\n\\n")
                            f.write(response.content)
                        
                        # Salvar debug COMPLETO
                        debug_file = os.path.join(args.output, f"{program.name}_{model}_debug.json")
                        debug_data = response_formatter.create_debug_json(
                            program_name=program.name,
                            request_info=request_info,
                            response=response
                        )
                        
                        with open(debug_file, 'w', encoding='utf-8') as f:
                            json.dump(debug_data, f, indent=2, ensure_ascii=False)
                        
                        logger.info(f"Análise salva em: {output_file}")
                        print(f"   Análise concluída - {response.tokens_used} tokens")
                        
                        all_results.append({
                            'program': program.name,
                            'model': model,
                            'success': True,
                            'tokens': response.tokens_used,
                            'time': response.response_time,
                            'output_file': output_file
                        })
                        
                    else:
                        logger.error(f"Erro na análise: {response.error_message}")
                        print(f"   Erro na análise: {response.error_message}")
                        
                        all_results.append({
                            'program': program.name,
                            'model': model,
                            'success': False,
                            'error': response.error_message
                        })
                
                except Exception as e:
                    logger.error(f"Erro ao processar {program.name} com {model}: {e}")
                    print(f"   Erro: {e}")
        
        # Relatório final
        total_time = time.time() - start_time
        successful = [r for r in all_results if r['success']]
        total_tokens = sum(r.get('tokens', 0) for r in successful)
        
        print("\\n" + "="*60)
        print("PROCESSAMENTO CONCLUÍDO")
        print(f"Programas processados: {len(programs)}")
        print(f"Modelos utilizados: {len(models)}")
        print(f"Análises bem-sucedidas: {len(successful)}/{len(all_results)}")
        print(f"Total de tokens utilizados: {total_tokens:,}")
        print(f"Tempo total: {total_time:.2f}s")
        print(f"Resultados salvos em: {args.output}")
        
        logger.info("Processamento concluído com sucesso")
        
    except Exception as e:
        logger.error(f"Erro na execução: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

def main():
    """Entry point for the application."""
    main_logic()

if __name__ == "__main__":
    main()
