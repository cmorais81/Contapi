#!/usr/bin/env python3
"""
Extrator Avançado de Regras de Negócio
Extrai valores específicos, fórmulas e trechos de código do COBOL
"""

import re
import logging
from typing import Dict, List, Any, Tuple, Optional
from dataclasses import dataclass

@dataclass
class BusinessRule:
    """Representa uma regra de negócio extraída"""
    id: str
    name: str
    description: str
    location: str
    cobol_code: str
    formula: str
    variables: List[str]
    conditions: List[str]
    values: List[str]
    result: str
    example: Dict[str, Any]
    line_numbers: List[int]
    category: str

@dataclass
class FinancialCalculation:
    """Representa um cálculo financeiro"""
    id: str
    name: str
    type: str
    formula: str
    cobol_code: str
    variables: List[Dict[str, str]]
    conditions: List[str]
    example: Dict[str, Any]
    line_numbers: List[int]
    precision: str

@dataclass
class DataValidation:
    """Representa uma validação de dados"""
    id: str
    type: str
    field: str
    location: str
    code: str
    criteria: str
    error_handling: str
    line_numbers: List[int]

class BusinessRulesExtractor:
    """Extrator avançado de regras de negócio do código COBOL"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
        # Padrões para identificar diferentes tipos de regras
        self.patterns = {
            'financial_calculations': [
                r'COMPUTE\s+(\w+)\s*=\s*(.+)',
                r'ADD\s+(.+)\s+TO\s+(\w+)',
                r'SUBTRACT\s+(.+)\s+FROM\s+(\w+)',
                r'MULTIPLY\s+(.+)\s+BY\s+(\w+)',
                r'DIVIDE\s+(.+)\s+INTO\s+(\w+)'
            ],
            'validations': [
                r'IF\s+(.+)\s+THEN',
                r'EVALUATE\s+(.+)',
                r'WHEN\s+(.+)',
                r'PERFORM\s+(.+)\s+UNTIL\s+(.+)'
            ],
            'constants': [
                r'(\w+)\s+PIC\s+[\w\(\)V]+\s+VALUE\s+(.+)',
                r'77\s+(\w+)\s+PIC\s+[\w\(\)V]+\s+VALUE\s+(.+)',
                r'88\s+(\w+)\s+VALUE\s+(.+)'
            ],
            'file_operations': [
                r'OPEN\s+(INPUT|OUTPUT|I-O|EXTEND)\s+(\w+)',
                r'READ\s+(\w+)',
                r'WRITE\s+(\w+)',
                r'CLOSE\s+(\w+)'
            ]
        }
    
    def extract_all_rules(self, program_content: str, program_name: str) -> Dict[str, List[Any]]:
        """Extrai todas as regras de negócio do programa"""
        
        lines = program_content.split('\n')
        
        results = {
            'business_rules': self.extract_business_rules(lines, program_name),
            'financial_calculations': self.extract_financial_calculations(lines, program_name),
            'data_validations': self.extract_data_validations(lines, program_name),
            'constants_and_values': self.extract_constants_and_values(lines, program_name),
            'conditional_logic': self.extract_conditional_logic(lines, program_name),
            'file_operations': self.extract_file_operations(lines, program_name)
        }
        
        self.logger.info(f"Extraídas {sum(len(v) for v in results.values())} regras de {program_name}")
        
        return results
    
    def extract_business_rules(self, lines: List[str], program_name: str) -> List[BusinessRule]:
        """Extrai regras de negócio específicas"""
        
        rules = []
        rule_counter = 1
        
        for i, line in enumerate(lines):
            line_clean = line.strip().upper()
            
            # Identificar regras de limite
            if 'LIMIT' in line_clean or 'LIMITE' in line_clean:
                rule = self._extract_limit_rule(lines, i, program_name, rule_counter)
                if rule:
                    rules.append(rule)
                    rule_counter += 1
            
            # Identificar regras de tarifa
            elif 'TARIFA' in line_clean or 'TAXA' in line_clean or 'FEE' in line_clean:
                rule = self._extract_fee_rule(lines, i, program_name, rule_counter)
                if rule:
                    rules.append(rule)
                    rule_counter += 1
            
            # Identificar regras de juros
            elif 'JUROS' in line_clean or 'INTEREST' in line_clean:
                rule = self._extract_interest_rule(lines, i, program_name, rule_counter)
                if rule:
                    rules.append(rule)
                    rule_counter += 1
            
            # Identificar regras de desconto
            elif 'DESCONTO' in line_clean or 'DISCOUNT' in line_clean:
                rule = self._extract_discount_rule(lines, i, program_name, rule_counter)
                if rule:
                    rules.append(rule)
                    rule_counter += 1
        
        return rules
    
    def extract_financial_calculations(self, lines: List[str], program_name: str) -> List[FinancialCalculation]:
        """Extrai cálculos financeiros específicos"""
        
        calculations = []
        calc_counter = 1
        
        for i, line in enumerate(lines):
            line_clean = line.strip().upper()
            
            # COMPUTE statements
            compute_match = re.search(r'COMPUTE\s+(\w+)\s*=\s*(.+)', line_clean)
            if compute_match:
                calc = self._extract_compute_calculation(lines, i, compute_match, program_name, calc_counter)
                if calc:
                    calculations.append(calc)
                    calc_counter += 1
            
            # ADD statements
            add_match = re.search(r'ADD\s+(.+)\s+TO\s+(\w+)', line_clean)
            if add_match:
                calc = self._extract_add_calculation(lines, i, add_match, program_name, calc_counter)
                if calc:
                    calculations.append(calc)
                    calc_counter += 1
            
            # MULTIPLY statements
            mult_match = re.search(r'MULTIPLY\s+(.+)\s+BY\s+(\w+)', line_clean)
            if mult_match:
                calc = self._extract_multiply_calculation(lines, i, mult_match, program_name, calc_counter)
                if calc:
                    calculations.append(calc)
                    calc_counter += 1
        
        return calculations
    
    def extract_data_validations(self, lines: List[str], program_name: str) -> List[DataValidation]:
        """Extrai validações de dados"""
        
        validations = []
        val_counter = 1
        
        for i, line in enumerate(lines):
            line_clean = line.strip().upper()
            
            # IF statements
            if_match = re.search(r'IF\s+(.+)', line_clean)
            if if_match:
                validation = self._extract_if_validation(lines, i, if_match, program_name, val_counter)
                if validation:
                    validations.append(validation)
                    val_counter += 1
            
            # EVALUATE statements
            eval_match = re.search(r'EVALUATE\s+(.+)', line_clean)
            if eval_match:
                validation = self._extract_evaluate_validation(lines, i, eval_match, program_name, val_counter)
                if validation:
                    validations.append(validation)
                    val_counter += 1
        
        return validations
    
    def extract_constants_and_values(self, lines: List[str], program_name: str) -> List[Dict[str, Any]]:
        """Extrai constantes e valores específicos"""
        
        constants = []
        
        for i, line in enumerate(lines):
            line_clean = line.strip()
            
            # VALUE clauses
            value_match = re.search(r'(\w+)\s+PIC\s+([\w\(\)V]+)\s+VALUE\s+(.+)', line_clean, re.IGNORECASE)
            if value_match:
                constant = {
                    'name': value_match.group(1),
                    'pic_clause': value_match.group(2),
                    'value': value_match.group(3).rstrip('.'),
                    'line_number': i + 1,
                    'line_content': line.strip(),
                    'type': self._determine_data_type(value_match.group(2)),
                    'description': self._generate_constant_description(value_match.group(1), value_match.group(3))
                }
                constants.append(constant)
            
            # 88 level conditions
            condition_match = re.search(r'88\s+(\w+)\s+VALUE\s+(.+)', line_clean, re.IGNORECASE)
            if condition_match:
                constant = {
                    'name': condition_match.group(1),
                    'pic_clause': 'CONDITION',
                    'value': condition_match.group(2).rstrip('.'),
                    'line_number': i + 1,
                    'line_content': line.strip(),
                    'type': 'CONDITION',
                    'description': f'Condição: {condition_match.group(1)}'
                }
                constants.append(constant)
        
        return constants
    
    def extract_conditional_logic(self, lines: List[str], program_name: str) -> List[Dict[str, Any]]:
        """Extrai lógica condicional complexa"""
        
        logic_blocks = []
        
        i = 0
        while i < len(lines):
            line_clean = lines[i].strip().upper()
            
            # IF blocks
            if line_clean.startswith('IF '):
                block = self._extract_if_block(lines, i, program_name)
                if block:
                    logic_blocks.append(block)
                    i = block.get('end_line', i)
            
            # EVALUATE blocks
            elif line_clean.startswith('EVALUATE '):
                block = self._extract_evaluate_block(lines, i, program_name)
                if block:
                    logic_blocks.append(block)
                    i = block.get('end_line', i)
            
            i += 1
        
        return logic_blocks
    
    def extract_file_operations(self, lines: List[str], program_name: str) -> List[Dict[str, Any]]:
        """Extrai operações de arquivo"""
        
        operations = []
        
        for i, line in enumerate(lines):
            line_clean = line.strip().upper()
            
            # File operations
            for pattern in self.patterns['file_operations']:
                match = re.search(pattern, line_clean)
                if match:
                    operation = {
                        'type': match.group(1) if len(match.groups()) > 1 else 'OPERATION',
                        'file': match.group(-1),  # Last group is usually the file
                        'line_number': i + 1,
                        'line_content': line.strip(),
                        'full_statement': self._get_full_statement(lines, i)
                    }
                    operations.append(operation)
        
        return operations
    
    # Métodos auxiliares para extração específica
    def _extract_limit_rule(self, lines: List[str], line_index: int, program_name: str, rule_id: int) -> Optional[BusinessRule]:
        """Extrai regra de limite específica"""
        
        line = lines[line_index].strip()
        
        # Procurar por valores numéricos na linha
        values = re.findall(r'\d+(?:\.\d+)?', line)
        
        # Extrair contexto (linhas anteriores e posteriores)
        context_start = max(0, line_index - 2)
        context_end = min(len(lines), line_index + 3)
        context_lines = lines[context_start:context_end]
        
        return BusinessRule(
            id=f"BR_LIMIT_{rule_id:03d}",
            name=f"Regra de Limite - {program_name}",
            description=f"Limite identificado na linha {line_index + 1}",
            location=f"Linha {line_index + 1}",
            cobol_code='\n'.join(context_lines),
            formula=self._extract_formula_from_line(line),
            variables=self._extract_variables_from_line(line),
            conditions=self._extract_conditions_from_context(context_lines),
            values=values,
            result="Aplicação de limite",
            example={"valor_limite": values[0] if values else "N/A"},
            line_numbers=[line_index + 1],
            category="LIMITE"
        )
    
    def _extract_fee_rule(self, lines: List[str], line_index: int, program_name: str, rule_id: int) -> Optional[BusinessRule]:
        """Extrai regra de tarifa específica"""
        
        line = lines[line_index].strip()
        
        # Procurar por valores monetários
        values = re.findall(r'\d+(?:\.\d+)?', line)
        
        context_start = max(0, line_index - 2)
        context_end = min(len(lines), line_index + 3)
        context_lines = lines[context_start:context_end]
        
        return BusinessRule(
            id=f"BR_FEE_{rule_id:03d}",
            name=f"Regra de Tarifa - {program_name}",
            description=f"Tarifa identificada na linha {line_index + 1}",
            location=f"Linha {line_index + 1}",
            cobol_code='\n'.join(context_lines),
            formula=self._extract_formula_from_line(line),
            variables=self._extract_variables_from_line(line),
            conditions=self._extract_conditions_from_context(context_lines),
            values=[f"R$ {v}" for v in values],
            result="Aplicação de tarifa",
            example={"valor_tarifa": f"R$ {values[0]}" if values else "N/A"},
            line_numbers=[line_index + 1],
            category="TARIFA"
        )
    
    def _extract_interest_rule(self, lines: List[str], line_index: int, program_name: str, rule_id: int) -> Optional[BusinessRule]:
        """Extrai regra de juros específica"""
        
        line = lines[line_index].strip()
        
        # Procurar por percentuais e valores
        percentages = re.findall(r'\d+(?:\.\d+)?%?', line)
        
        context_start = max(0, line_index - 2)
        context_end = min(len(lines), line_index + 3)
        context_lines = lines[context_start:context_end]
        
        return BusinessRule(
            id=f"BR_INTEREST_{rule_id:03d}",
            name=f"Regra de Juros - {program_name}",
            description=f"Cálculo de juros identificado na linha {line_index + 1}",
            location=f"Linha {line_index + 1}",
            cobol_code='\n'.join(context_lines),
            formula=self._extract_interest_formula(context_lines),
            variables=self._extract_variables_from_line(line),
            conditions=self._extract_conditions_from_context(context_lines),
            values=percentages,
            result="Cálculo de juros",
            example={"taxa_juros": f"{percentages[0]}%" if percentages else "N/A"},
            line_numbers=[line_index + 1],
            category="JUROS"
        )
    
    def _extract_discount_rule(self, lines: List[str], line_index: int, program_name: str, rule_id: int) -> Optional[BusinessRule]:
        """Extrai regra de desconto específica"""
        
        line = lines[line_index].strip()
        
        values = re.findall(r'\d+(?:\.\d+)?', line)
        
        context_start = max(0, line_index - 2)
        context_end = min(len(lines), line_index + 3)
        context_lines = lines[context_start:context_end]
        
        return BusinessRule(
            id=f"BR_DISCOUNT_{rule_id:03d}",
            name=f"Regra de Desconto - {program_name}",
            description=f"Desconto identificado na linha {line_index + 1}",
            location=f"Linha {line_index + 1}",
            cobol_code='\n'.join(context_lines),
            formula=self._extract_formula_from_line(line),
            variables=self._extract_variables_from_line(line),
            conditions=self._extract_conditions_from_context(context_lines),
            values=[f"{v}%" for v in values],
            result="Aplicação de desconto",
            example={"percentual_desconto": f"{values[0]}%" if values else "N/A"},
            line_numbers=[line_index + 1],
            category="DESCONTO"
        )
    
    def _extract_compute_calculation(self, lines: List[str], line_index: int, match: re.Match, program_name: str, calc_id: int) -> Optional[FinancialCalculation]:
        """Extrai cálculo COMPUTE específico"""
        
        variable = match.group(1)
        expression = match.group(2).rstrip('.')
        
        context_start = max(0, line_index - 1)
        context_end = min(len(lines), line_index + 2)
        context_lines = lines[context_start:context_end]
        
        return FinancialCalculation(
            id=f"FC_COMPUTE_{calc_id:03d}",
            name=f"Cálculo COMPUTE - {variable}",
            type="COMPUTE",
            formula=f"{variable} = {expression}",
            cobol_code='\n'.join(context_lines),
            variables=self._extract_variables_from_expression(expression),
            conditions=[],
            example={"resultado": f"{variable} calculado"},
            line_numbers=[line_index + 1],
            precision=self._determine_precision(variable, lines)
        )
    
    def _extract_add_calculation(self, lines: List[str], line_index: int, match: re.Match, program_name: str, calc_id: int) -> Optional[FinancialCalculation]:
        """Extrai cálculo ADD específico"""
        
        addend = match.group(1)
        target = match.group(2)
        
        context_lines = [lines[line_index]]
        
        return FinancialCalculation(
            id=f"FC_ADD_{calc_id:03d}",
            name=f"Cálculo ADD - {target}",
            type="ADD",
            formula=f"{target} = {target} + {addend}",
            cobol_code=lines[line_index].strip(),
            variables=[addend.strip(), target.strip()],
            conditions=[],
            example={"operacao": f"Adicionar {addend} a {target}"},
            line_numbers=[line_index + 1],
            precision=self._determine_precision(target, lines)
        )
    
    def _extract_multiply_calculation(self, lines: List[str], line_index: int, match: re.Match, program_name: str, calc_id: int) -> Optional[FinancialCalculation]:
        """Extrai cálculo MULTIPLY específico"""
        
        multiplier = match.group(1)
        target = match.group(2)
        
        return FinancialCalculation(
            id=f"FC_MULT_{calc_id:03d}",
            name=f"Cálculo MULTIPLY - {target}",
            type="MULTIPLY",
            formula=f"{target} = {target} * {multiplier}",
            cobol_code=lines[line_index].strip(),
            variables=[multiplier.strip(), target.strip()],
            conditions=[],
            example={"operacao": f"Multiplicar {target} por {multiplier}"},
            line_numbers=[line_index + 1],
            precision=self._determine_precision(target, lines)
        )
    
    def _extract_if_validation(self, lines: List[str], line_index: int, match: re.Match, program_name: str, val_id: int) -> Optional[DataValidation]:
        """Extrai validação IF específica"""
        
        condition = match.group(1)
        
        # Procurar por ELSE e END-IF
        validation_block = self._get_if_block(lines, line_index)
        
        return DataValidation(
            id=f"DV_IF_{val_id:03d}",
            type="IF_VALIDATION",
            field=self._extract_field_from_condition(condition),
            location=f"Linha {line_index + 1}",
            code=validation_block,
            criteria=condition,
            error_handling=self._extract_error_handling(validation_block),
            line_numbers=[line_index + 1]
        )
    
    def _extract_evaluate_validation(self, lines: List[str], line_index: int, match: re.Match, program_name: str, val_id: int) -> Optional[DataValidation]:
        """Extrai validação EVALUATE específica"""
        
        variable = match.group(1)
        
        # Procurar por END-EVALUATE
        evaluate_block = self._get_evaluate_block(lines, line_index)
        
        return DataValidation(
            id=f"DV_EVAL_{val_id:03d}",
            type="EVALUATE_VALIDATION",
            field=variable,
            location=f"Linha {line_index + 1}",
            code=evaluate_block,
            criteria=f"Avaliação de {variable}",
            error_handling=self._extract_error_handling(evaluate_block),
            line_numbers=[line_index + 1]
        )
    
    # Métodos auxiliares
    def _extract_formula_from_line(self, line: str) -> str:
        """Extrai fórmula da linha"""
        # Procurar por operações matemáticas
        if '=' in line:
            return line.split('=', 1)[1].strip().rstrip('.')
        elif 'COMPUTE' in line.upper():
            match = re.search(r'COMPUTE\s+\w+\s*=\s*(.+)', line, re.IGNORECASE)
            return match.group(1).rstrip('.') if match else ""
        return ""
    
    def _extract_variables_from_line(self, line: str) -> List[str]:
        """Extrai variáveis da linha"""
        # Procurar por identificadores COBOL
        variables = re.findall(r'\b[A-Z][A-Z0-9-]*\b', line.upper())
        # Filtrar palavras reservadas
        reserved_words = {'IF', 'THEN', 'ELSE', 'END-IF', 'COMPUTE', 'ADD', 'TO', 'MULTIPLY', 'BY', 'VALUE', 'PIC'}
        return [v for v in variables if v not in reserved_words]
    
    def _extract_conditions_from_context(self, context_lines: List[str]) -> List[str]:
        """Extrai condições do contexto"""
        conditions = []
        for line in context_lines:
            if 'IF ' in line.upper():
                match = re.search(r'IF\s+(.+)', line.upper())
                if match:
                    conditions.append(match.group(1).rstrip('.'))
        return conditions
    
    def _extract_interest_formula(self, context_lines: List[str]) -> str:
        """Extrai fórmula de juros do contexto"""
        for line in context_lines:
            if 'COMPUTE' in line.upper() and ('JUROS' in line.upper() or 'INTEREST' in line.upper()):
                match = re.search(r'COMPUTE\s+\w+\s*=\s*(.+)', line, re.IGNORECASE)
                return match.group(1).rstrip('.') if match else ""
        return "PRINCIPAL * TAXA * PERIODO"
    
    def _extract_variables_from_expression(self, expression: str) -> List[Dict[str, str]]:
        """Extrai variáveis de uma expressão"""
        variables = []
        var_names = re.findall(r'\b[A-Z][A-Z0-9-]*\b', expression.upper())
        
        for var in var_names:
            if not var.isdigit():
                variables.append({
                    'name': var,
                    'type': 'NUMERIC',  # Assumir numérico para cálculos
                    'usage': 'CALCULATION'
                })
        
        return variables
    
    def _determine_precision(self, variable: str, lines: List[str]) -> str:
        """Determina precisão da variável"""
        for line in lines:
            if variable in line and 'PIC' in line.upper():
                match = re.search(rf'{variable}\s+PIC\s+([\w\(\)V]+)', line, re.IGNORECASE)
                return match.group(1) if match else "UNKNOWN"
        return "UNKNOWN"
    
    def _determine_data_type(self, pic_clause: str) -> str:
        """Determina tipo de dados da cláusula PIC"""
        if '9' in pic_clause:
            return 'NUMERIC'
        elif 'X' in pic_clause:
            return 'ALPHANUMERIC'
        elif 'A' in pic_clause:
            return 'ALPHABETIC'
        return 'UNKNOWN'
    
    def _generate_constant_description(self, name: str, value: str) -> str:
        """Gera descrição para constante"""
        if 'TARIFA' in name.upper() or 'FEE' in name.upper():
            return f"Tarifa definida: {value}"
        elif 'LIMITE' in name.upper() or 'LIMIT' in name.upper():
            return f"Limite estabelecido: {value}"
        elif 'TAXA' in name.upper() or 'RATE' in name.upper():
            return f"Taxa configurada: {value}"
        return f"Constante {name}: {value}"
    
    def _get_full_statement(self, lines: List[str], start_index: int) -> str:
        """Obtém declaração completa (pode continuar em múltiplas linhas)"""
        statement = lines[start_index].strip()
        
        # Se não termina com ponto, procurar continuação
        i = start_index + 1
        while i < len(lines) and not statement.rstrip().endswith('.'):
            next_line = lines[i].strip()
            if next_line and not next_line.startswith('*'):
                statement += ' ' + next_line
            i += 1
            if i - start_index > 5:  # Limite de segurança
                break
        
        return statement
    
    def _extract_if_block(self, lines: List[str], start_index: int, program_name: str) -> Optional[Dict[str, Any]]:
        """Extrai bloco IF completo"""
        block_lines = []
        i = start_index
        
        while i < len(lines):
            line = lines[i].strip().upper()
            block_lines.append(lines[i])
            
            if 'END-IF' in line:
                break
            i += 1
            
            if i - start_index > 20:  # Limite de segurança
                break
        
        return {
            'type': 'IF_BLOCK',
            'start_line': start_index + 1,
            'end_line': i,
            'code': '\n'.join(block_lines),
            'conditions': self._extract_conditions_from_context(block_lines)
        }
    
    def _extract_evaluate_block(self, lines: List[str], start_index: int, program_name: str) -> Optional[Dict[str, Any]]:
        """Extrai bloco EVALUATE completo"""
        block_lines = []
        i = start_index
        
        while i < len(lines):
            line = lines[i].strip().upper()
            block_lines.append(lines[i])
            
            if 'END-EVALUATE' in line:
                break
            i += 1
            
            if i - start_index > 30:  # Limite de segurança
                break
        
        return {
            'type': 'EVALUATE_BLOCK',
            'start_line': start_index + 1,
            'end_line': i,
            'code': '\n'.join(block_lines),
            'when_clauses': self._extract_when_clauses(block_lines)
        }
    
    def _extract_when_clauses(self, block_lines: List[str]) -> List[str]:
        """Extrai cláusulas WHEN do bloco EVALUATE"""
        when_clauses = []
        for line in block_lines:
            if 'WHEN ' in line.upper():
                match = re.search(r'WHEN\s+(.+)', line.upper())
                if match:
                    when_clauses.append(match.group(1).rstrip('.'))
        return when_clauses
    
    def _get_if_block(self, lines: List[str], start_index: int) -> str:
        """Obtém bloco IF completo como string"""
        block_lines = []
        i = start_index
        
        while i < len(lines):
            line = lines[i].strip()
            block_lines.append(line)
            
            if 'END-IF' in line.upper():
                break
            i += 1
            
            if i - start_index > 10:  # Limite de segurança
                break
        
        return '\n'.join(block_lines)
    
    def _get_evaluate_block(self, lines: List[str], start_index: int) -> str:
        """Obtém bloco EVALUATE completo como string"""
        block_lines = []
        i = start_index
        
        while i < len(lines):
            line = lines[i].strip()
            block_lines.append(line)
            
            if 'END-EVALUATE' in line.upper():
                break
            i += 1
            
            if i - start_index > 20:  # Limite de segurança
                break
        
        return '\n'.join(block_lines)
    
    def _extract_field_from_condition(self, condition: str) -> str:
        """Extrai campo principal da condição"""
        # Procurar por primeiro identificador
        match = re.search(r'\b([A-Z][A-Z0-9-]*)\b', condition.upper())
        return match.group(1) if match else "UNKNOWN"
    
    def _extract_error_handling(self, code_block: str) -> str:
        """Extrai tratamento de erro do bloco de código"""
        if 'ELSE' in code_block.upper():
            return "Tratamento de erro via ELSE"
        elif 'WHEN OTHER' in code_block.upper():
            return "Tratamento de erro via WHEN OTHER"
        elif 'ERROR' in code_block.upper():
            return "Tratamento de erro específico"
        return "Sem tratamento de erro explícito"
