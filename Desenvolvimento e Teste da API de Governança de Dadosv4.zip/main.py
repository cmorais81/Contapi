"""
TBR GDP Core - Data Governance API V3.0
Aplicação principal FastAPI
"""

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import uvicorn
from datetime import datetime

from governance_api.config.environments.base import get_settings
from governance_api.database.init_db import init_database

# Importar routers
from governance_api.api.v1.admin.users import router as users_router
from governance_api.api.v1.admin.auth import router as auth_router
from governance_api.api.v1.admin.advanced import router as advanced_router
from governance_api.api.v1.entities.entities import router as entities_router
from governance_api.api.v1.entities.attributes import router as attributes_router
from governance_api.api.v1.entities.tags import router as tags_router
from governance_api.api.v1.contracts.contracts import router as contracts_router
from governance_api.api.v1.contracts.versions import router as versions_router
from governance_api.api.v1.contracts.validation import router as validation_router
from governance_api.api.v1.contracts.odcs import router as odcs_router
from governance_api.api.v1.quality import quality_router
from governance_api.api.v1.governance import governance_router
from governance_api.api.v1.monitoring import monitoring_router
from governance_api.api.v1.integration import integration_router
from governance_api.api.v1.organizations import router as organizations_router
from governance_api.api.v1.lineage import router as lineage_router
from governance_api.api.v1.privacy import router as privacy_router

# Configurações
settings = get_settings()

# Criar aplicação FastAPI
app = FastAPI(
    title="TBR GDP Core - Data Governance API",
    description="API de Governança de Dados baseada no modelo ODCS v3.0.2",
    version="3.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# Configurar CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Incluir routers
app.include_router(users_router, prefix="/api/v1")
app.include_router(auth_router, prefix="/api/v1")
app.include_router(advanced_router, prefix="/api/v1")

# Data Contracts
app.include_router(contracts_router, prefix="/api/v1")
app.include_router(versions_router, prefix="/api/v1")
app.include_router(validation_router, prefix="/api/v1")
app.include_router(odcs_router, prefix="/api/v1")

# Entities & Tags
app.include_router(entities_router, prefix="/api/v1")
app.include_router(attributes_router, prefix="/api/v1")
app.include_router(tags_router, prefix="/api/v1")

# Quality Management
app.include_router(quality_router, prefix="/api/v1")

# Governance
app.include_router(governance_router, prefix="/api/v1")

# Monitoring
app.include_router(monitoring_router, prefix="/api/v1")

# Integration
app.include_router(integration_router, prefix="/api/v1")

# Organizations & Multi-tenancy
app.include_router(organizations_router, prefix="/api/v1")

# Data Lineage
app.include_router(lineage_router, prefix="/api/v1")

# Privacy & Access Control
app.include_router(privacy_router, prefix="/api/v1")


@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "version": "3.0.0",
        "service": "TBR GDP Core - Data Governance API"
    }


@app.get("/api/v1/info")
async def api_info():
    """Informações da API"""
    return {
        "name": "TBR GDP Core - Data Governance API",
        "version": "3.0.0",
        "description": "API de Governança de Dados baseada no modelo ODCS v3.0.2",
        "features": [
            "Data Contracts Management",
            "Contract Versioning", 
            "Schema Validation",
            "ODCS Import/Export",
            "Quality Management",
            "Governance Workflows"
        ],
        "endpoints": {
            "contracts": 15,
            "entities": 12,
            "quality": 18,
            "governance": 15,
            "monitoring": 25,
            "integration": 15,
            "admin": 12,
            "total_implemented": 112,
            "total_planned": 112
        },
        "environment": "development",
        "authentication": "disabled_in_dev",
        "database": "SQLite",
        "timestamp": datetime.utcnow().isoformat()
    }


@app.post("/api/v1/admin/init-db")
async def initialize_database():
    """Inicializar banco de dados"""
    try:
        await init_database()
        return {
            "message": "Database initialized successfully",
            "timestamp": datetime.utcnow().isoformat(),
            "tables_created": [
                "users",
                "data_contracts", 
                "data_contract_versions",
                "data_contract_validations",
                "data_contract_approvals",
                "data_contract_usage"
            ],
            "sample_data": "3 sample contracts created"
        }
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={
                "error": "Failed to initialize database",
                "detail": str(e),
                "timestamp": datetime.utcnow().isoformat()
            }
        )


@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """Handler global para exceções"""
    return JSONResponse(
        status_code=500,
        content={
            "error": "Internal server error",
            "detail": str(exc) if settings.DEBUG else "An unexpected error occurred",
            "timestamp": datetime.utcnow().isoformat(),
            "path": str(request.url)
        }
    )


if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )

