"""
Data Entity Domain Entities
"""

from enum import Enum
from typing import Dict, List, Optional, Any
from .base import BaseEntity


class EntityType(Enum):
    """Entity type enumeration"""
    TABLE = "table"
    VIEW = "view"
    STREAM = "stream"
    API = "api"
    FILE = "file"


class DataEntity(BaseEntity):
    """Data Entity domain entity"""
    
    def __init__(
        self,
        name: str,
        entity_type: EntityType,
        description: Optional[str] = None,
        id: Optional[int] = None
    ):
        super().__init__(id)
        self._name = name
        self._entity_type = entity_type
        self._description = description
        self._schema_definition: Optional[Dict[str, Any]] = None
        self._business_rules: Dict[str, Any] = {}
        self._data_classification: Optional[str] = None
        self._sensitivity_level: Optional[str] = None
        self._owner_id: Optional[int] = None
        self._domain_id: Optional[int] = None
        self._source_system: Optional[str] = None
        self._tags: List[str] = []
    
    @property
    def name(self) -> str:
        return self._name
    
    @property
    def entity_type(self) -> EntityType:
        return self._entity_type
    
    @property
    def description(self) -> Optional[str]:
        return self._description
    
    def set_classification(self, classification: str) -> None:
        """Set data classification"""
        self._data_classification = classification
        self.update_timestamp()
    
    def add_tag(self, tag: str) -> None:
        """Add a tag"""
        if tag not in self._tags:
            self._tags.append(tag)
            self.update_timestamp()


class EntityAttribute(BaseEntity):
    """Entity Attribute domain entity"""
    
    def __init__(
        self,
        entity_id: int,
        name: str,
        data_type: str,
        description: Optional[str] = None,
        id: Optional[int] = None
    ):
        super().__init__(id)
        self._entity_id = entity_id
        self._name = name
        self._data_type = data_type
        self._description = description
        self._is_required = False
        self._is_primary_key = False
        self._constraints: Dict[str, Any] = {}
    
    @property
    def entity_id(self) -> int:
        return self._entity_id
    
    @property
    def name(self) -> str:
        return self._name
    
    @property
    def data_type(self) -> str:
        return self._data_type

