"""
Access Control Service
"""

from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any
from governance_api.domain.entities.access_control import (
    AccessPolicy, DataAccess, PrivacyRule, AccessLevel, PrivacyLevel
)


class AccessControlService:
    """Service for managing access control and privacy"""
    
    def __init__(self):
        self._access_policies: Dict[int, AccessPolicy] = {}
        self._data_accesses: Dict[int, DataAccess] = {}
        self._privacy_rules: Dict[int, PrivacyRule] = {}
    
    def create_access_policy(
        self,
        name: str,
        description: str,
        policy_type: str,
        rules: Dict[str, Any]
    ) -> AccessPolicy:
        """Create a new access policy"""
        policy = AccessPolicy(
            name=name,
            description=description,
            policy_type=policy_type,
            rules=rules
        )
        return policy
    
    def grant_data_access(
        self,
        user_id: int,
        entity_id: int,
        access_level: AccessLevel,
        granted_by: int,
        reason: str,
        expires_in_days: Optional[int] = None
    ) -> DataAccess:
        """Grant data access to a user"""
        access = DataAccess(
            user_id=user_id,
            entity_id=entity_id,
            access_level=access_level,
            granted_by=granted_by,
            reason=reason
        )
        
        if expires_in_days:
            expires_at = datetime.utcnow() + timedelta(days=expires_in_days)
            access.set_expiry(expires_at)
        
        return access
    
    def revoke_data_access(self, access_id: int) -> bool:
        """Revoke data access"""
        if access_id in self._data_accesses:
            self._data_accesses[access_id].revoke()
            return True
        return False
    
    def check_user_access(
        self,
        user_id: int,
        entity_id: int,
        required_level: AccessLevel
    ) -> bool:
        """Check if user has required access level"""
        user_accesses = [
            access for access in self._data_accesses.values()
            if access.user_id == user_id and access.entity_id == entity_id
        ]
        
        for access in user_accesses:
            if access.is_valid() and self._has_sufficient_access(access.access_level, required_level):
                access.record_access()
                return True
        
        return False
    
    def get_user_accesses(self, user_id: int) -> List[DataAccess]:
        """Get all accesses for a user"""
        return [
            access for access in self._data_accesses.values()
            if access.user_id == user_id and access.is_valid()
        ]
    
    def get_entity_accesses(self, entity_id: int) -> List[DataAccess]:
        """Get all accesses for an entity"""
        return [
            access for access in self._data_accesses.values()
            if access.entity_id == entity_id and access.is_valid()
        ]
    
    def create_privacy_rule(
        self,
        name: str,
        description: str,
        rule_type: str,
        privacy_level: PrivacyLevel,
        retention_period_days: Optional[int] = None
    ) -> PrivacyRule:
        """Create a privacy rule"""
        from governance_api.domain.entities.access_control import DataClassification
        
        rule = PrivacyRule(
            name=name,
            description=description,
            rule_type=rule_type,
            privacy_level=privacy_level,
            data_classification=DataClassification.INTERNAL,
            retention_period_days=retention_period_days
        )
        return rule
    
    def apply_privacy_rule(self, entity_id: int, rule_id: int) -> bool:
        """Apply privacy rule to an entity"""
        # Implementation would involve database operations
        return True
    
    def get_privacy_compliance_report(self, entity_id: int) -> Dict[str, Any]:
        """Get privacy compliance report for an entity"""
        return {
            "entity_id": entity_id,
            "compliance_status": "compliant",
            "privacy_rules_applied": [],
            "retention_status": "within_policy",
            "anonymization_required": False,
            "consent_status": "obtained"
        }
    
    def _has_sufficient_access(self, user_level: AccessLevel, required_level: AccessLevel) -> bool:
        """Check if user access level is sufficient"""
        access_hierarchy = {
            AccessLevel.READ: 1,
            AccessLevel.WRITE: 2,
            AccessLevel.DELETE: 3,
            AccessLevel.ADMIN: 4
        }
        
        return access_hierarchy.get(user_level, 0) >= access_hierarchy.get(required_level, 0)

