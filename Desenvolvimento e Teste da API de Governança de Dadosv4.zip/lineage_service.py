"""
Data Lineage Service
"""

from typing import List, Dict, Any, Optional, Set
from datetime import datetime


class LineageNode:
    """Represents a node in the data lineage graph"""
    
    def __init__(self, node_id: str, name: str, node_type: str, metadata: Dict[str, Any] = None):
        self.node_id = node_id
        self.name = name
        self.node_type = node_type  # table, view, api, file, etc.
        self.metadata = metadata or {}
        self.created_at = datetime.utcnow()


class LineageEdge:
    """Represents a relationship between nodes in the lineage graph"""
    
    def __init__(self, source_id: str, target_id: str, relationship_type: str, metadata: Dict[str, Any] = None):
        self.source_id = source_id
        self.target_id = target_id
        self.relationship_type = relationship_type  # derives_from, transforms_to, etc.
        self.metadata = metadata or {}
        self.created_at = datetime.utcnow()


class LineageService:
    """Service for managing data lineage"""
    
    def __init__(self):
        self._nodes: Dict[str, LineageNode] = {}
        self._edges: List[LineageEdge] = []
        self._adjacency_list: Dict[str, List[str]] = {}
        self._reverse_adjacency_list: Dict[str, List[str]] = {}
    
    def add_node(
        self,
        node_id: str,
        name: str,
        node_type: str,
        metadata: Dict[str, Any] = None
    ) -> LineageNode:
        """Add a node to the lineage graph"""
        node = LineageNode(node_id, name, node_type, metadata)
        self._nodes[node_id] = node
        
        if node_id not in self._adjacency_list:
            self._adjacency_list[node_id] = []
        if node_id not in self._reverse_adjacency_list:
            self._reverse_adjacency_list[node_id] = []
        
        return node
    
    def add_edge(
        self,
        source_id: str,
        target_id: str,
        relationship_type: str,
        metadata: Dict[str, Any] = None
    ) -> LineageEdge:
        """Add an edge to the lineage graph"""
        # Ensure nodes exist
        if source_id not in self._nodes or target_id not in self._nodes:
            raise ValueError("Both source and target nodes must exist")
        
        edge = LineageEdge(source_id, target_id, relationship_type, metadata)
        self._edges.append(edge)
        
        # Update adjacency lists
        self._adjacency_list[source_id].append(target_id)
        self._reverse_adjacency_list[target_id].append(source_id)
        
        return edge
    
    def get_downstream_lineage(
        self,
        node_id: str,
        max_depth: int = 10
    ) -> Dict[str, Any]:
        """Get downstream lineage (what this node affects)"""
        if node_id not in self._nodes:
            raise ValueError(f"Node {node_id} not found")
        
        visited = set()
        result = self._traverse_downstream(node_id, visited, max_depth, 0)
        
        return {
            "root_node": self._node_to_dict(self._nodes[node_id]),
            "downstream_nodes": result,
            "total_affected": len(self._get_all_downstream_nodes(node_id, max_depth))
        }
    
    def get_upstream_lineage(
        self,
        node_id: str,
        max_depth: int = 10
    ) -> Dict[str, Any]:
        """Get upstream lineage (what affects this node)"""
        if node_id not in self._nodes:
            raise ValueError(f"Node {node_id} not found")
        
        visited = set()
        result = self._traverse_upstream(node_id, visited, max_depth, 0)
        
        return {
            "root_node": self._node_to_dict(self._nodes[node_id]),
            "upstream_nodes": result,
            "total_sources": len(self._get_all_upstream_nodes(node_id, max_depth))
        }
    
    def get_full_lineage(
        self,
        node_id: str,
        max_depth: int = 5
    ) -> Dict[str, Any]:
        """Get both upstream and downstream lineage"""
        upstream = self.get_upstream_lineage(node_id, max_depth)
        downstream = self.get_downstream_lineage(node_id, max_depth)
        
        return {
            "root_node": self._node_to_dict(self._nodes[node_id]),
            "upstream": upstream["upstream_nodes"],
            "downstream": downstream["downstream_nodes"],
            "total_sources": upstream["total_sources"],
            "total_affected": downstream["total_affected"]
        }
    
    def find_path(self, source_id: str, target_id: str) -> Optional[List[str]]:
        """Find path between two nodes"""
        if source_id not in self._nodes or target_id not in self._nodes:
            return None
        
        visited = set()
        path = []
        
        if self._dfs_path(source_id, target_id, visited, path):
            return path
        
        return None
    
    def get_impact_analysis(self, node_id: str) -> Dict[str, Any]:
        """Get impact analysis for a node"""
        downstream = self.get_downstream_lineage(node_id)
        
        # Categorize affected nodes by type
        affected_by_type = {}
        for node_data in downstream["downstream_nodes"]:
            node_type = node_data["node_type"]
            if node_type not in affected_by_type:
                affected_by_type[node_type] = 0
            affected_by_type[node_type] += 1
        
        return {
            "node_id": node_id,
            "total_affected": downstream["total_affected"],
            "affected_by_type": affected_by_type,
            "critical_paths": self._find_critical_paths(node_id),
            "risk_level": self._calculate_risk_level(downstream["total_affected"])
        }
    
    def get_lineage_summary(self) -> Dict[str, Any]:
        """Get summary of the entire lineage graph"""
        node_types = {}
        for node in self._nodes.values():
            node_type = node.node_type
            if node_type not in node_types:
                node_types[node_type] = 0
            node_types[node_type] += 1
        
        return {
            "total_nodes": len(self._nodes),
            "total_edges": len(self._edges),
            "node_types": node_types,
            "orphaned_nodes": self._find_orphaned_nodes(),
            "circular_dependencies": self._detect_cycles()
        }
    
    def _traverse_downstream(
        self,
        node_id: str,
        visited: Set[str],
        max_depth: int,
        current_depth: int
    ) -> List[Dict[str, Any]]:
        """Traverse downstream nodes recursively"""
        if current_depth >= max_depth or node_id in visited:
            return []
        
        visited.add(node_id)
        result = []
        
        for child_id in self._adjacency_list.get(node_id, []):
            if child_id not in visited:
                child_node = self._nodes[child_id]
                child_data = self._node_to_dict(child_node)
                child_data["depth"] = current_depth + 1
                child_data["children"] = self._traverse_downstream(
                    child_id, visited.copy(), max_depth, current_depth + 1
                )
                result.append(child_data)
        
        return result
    
    def _traverse_upstream(
        self,
        node_id: str,
        visited: Set[str],
        max_depth: int,
        current_depth: int
    ) -> List[Dict[str, Any]]:
        """Traverse upstream nodes recursively"""
        if current_depth >= max_depth or node_id in visited:
            return []
        
        visited.add(node_id)
        result = []
        
        for parent_id in self._reverse_adjacency_list.get(node_id, []):
            if parent_id not in visited:
                parent_node = self._nodes[parent_id]
                parent_data = self._node_to_dict(parent_node)
                parent_data["depth"] = current_depth + 1
                parent_data["parents"] = self._traverse_upstream(
                    parent_id, visited.copy(), max_depth, current_depth + 1
                )
                result.append(parent_data)
        
        return result
    
    def _get_all_downstream_nodes(self, node_id: str, max_depth: int) -> Set[str]:
        """Get all downstream node IDs"""
        visited = set()
        self._collect_downstream(node_id, visited, max_depth, 0)
        visited.discard(node_id)  # Remove the starting node
        return visited
    
    def _get_all_upstream_nodes(self, node_id: str, max_depth: int) -> Set[str]:
        """Get all upstream node IDs"""
        visited = set()
        self._collect_upstream(node_id, visited, max_depth, 0)
        visited.discard(node_id)  # Remove the starting node
        return visited
    
    def _collect_downstream(self, node_id: str, visited: Set[str], max_depth: int, current_depth: int):
        """Collect all downstream nodes"""
        if current_depth >= max_depth or node_id in visited:
            return
        
        visited.add(node_id)
        for child_id in self._adjacency_list.get(node_id, []):
            self._collect_downstream(child_id, visited, max_depth, current_depth + 1)
    
    def _collect_upstream(self, node_id: str, visited: Set[str], max_depth: int, current_depth: int):
        """Collect all upstream nodes"""
        if current_depth >= max_depth or node_id in visited:
            return
        
        visited.add(node_id)
        for parent_id in self._reverse_adjacency_list.get(node_id, []):
            self._collect_upstream(parent_id, visited, max_depth, current_depth + 1)
    
    def _dfs_path(self, current: str, target: str, visited: Set[str], path: List[str]) -> bool:
        """DFS to find path between nodes"""
        visited.add(current)
        path.append(current)
        
        if current == target:
            return True
        
        for neighbor in self._adjacency_list.get(current, []):
            if neighbor not in visited:
                if self._dfs_path(neighbor, target, visited, path):
                    return True
        
        path.pop()
        return False
    
    def _node_to_dict(self, node: LineageNode) -> Dict[str, Any]:
        """Convert node to dictionary"""
        return {
            "node_id": node.node_id,
            "name": node.name,
            "node_type": node.node_type,
            "metadata": node.metadata,
            "created_at": node.created_at.isoformat()
        }
    
    def _find_critical_paths(self, node_id: str) -> List[List[str]]:
        """Find critical paths from a node"""
        # Simplified implementation - would be more complex in real scenario
        return []
    
    def _calculate_risk_level(self, affected_count: int) -> str:
        """Calculate risk level based on affected nodes"""
        if affected_count == 0:
            return "low"
        elif affected_count <= 5:
            return "medium"
        elif affected_count <= 20:
            return "high"
        else:
            return "critical"
    
    def _find_orphaned_nodes(self) -> List[str]:
        """Find nodes with no connections"""
        orphaned = []
        for node_id in self._nodes:
            has_incoming = len(self._reverse_adjacency_list.get(node_id, [])) > 0
            has_outgoing = len(self._adjacency_list.get(node_id, [])) > 0
            if not has_incoming and not has_outgoing:
                orphaned.append(node_id)
        return orphaned
    
    def _detect_cycles(self) -> List[List[str]]:
        """Detect circular dependencies"""
        # Simplified implementation - would use proper cycle detection algorithm
        return []

