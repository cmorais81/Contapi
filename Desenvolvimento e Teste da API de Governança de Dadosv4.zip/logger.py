"""
Logging utilities
"""

import logging
import sys
from typing import Optional


def get_logger(name: str, level: str = "INFO") -> logging.Logger:
    """Get configured logger"""
    logger = logging.getLogger(name)
    
    if not logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
    
    logger.setLevel(getattr(logging, level.upper()))
    return logger


def log_api_request(endpoint: str, method: str, user_id: Optional[int] = None):
    """Log API request"""
    logger = get_logger("api")
    logger.info(f"{method} {endpoint} - User: {user_id}")


def log_error(error: Exception, context: str = ""):
    """Log error with context"""
    logger = get_logger("error")
    logger.error(f"Error in {context}: {str(error)}", exc_info=True)

