"""Quality Domain Entities"""
from .base import BaseEntity

class QualityRule(BaseEntity):
    def __init__(self, name: str, rule_type: str, id=None):
        super().__init__(id)
        self._name = name
        self._rule_type = rule_type

class QualityMetric(BaseEntity):
    def __init__(self, name: str, metric_type: str, id=None):
        super().__init__(id)
        self._name = name
        self._metric_type = metric_type

class QualityIncident(BaseEntity):
    def __init__(self, title: str, severity: str, id=None):
        super().__init__(id)
        self._title = title
        self._severity = severity

