"""
Advanced Data Lineage endpoints
"""

from fastapi import APIRouter, HTTPException, Query
from typing import List, Optional, Dict, Any
from datetime import datetime

router = APIRouter()


@router.get("/graph/{entity_id}", response_model=Dict[str, Any])
async def get_lineage_graph(
    entity_id: str,
    direction: str = Query("both", description="upstream, downstream, or both"),
    depth: int = Query(5, description="Maximum depth to traverse"),
    include_metadata: bool = Query(True, description="Include node metadata")
):
    """Get complete lineage graph for an entity"""
    
    # Simulate lineage graph data
    if entity_id == "customers_table":
        return {
            "entity_id": entity_id,
            "entity_name": "customers",
            "entity_type": "table",
            "direction": direction,
            "max_depth": depth,
            "graph": {
                "nodes": [
                    {
                        "id": "customers_table",
                        "name": "customers",
                        "type": "table",
                        "schema": "production",
                        "database": "crm",
                        "level": 0,
                        "metadata": {
                            "owner": "data_team",
                            "created_at": "2024-01-15T00:00:00Z",
                            "row_count": 1250000,
                            "size_mb": 450,
                            "last_updated": "2025-06-15T08:30:00Z"
                        } if include_metadata else {}
                    },
                    {
                        "id": "customer_api",
                        "name": "Customer API",
                        "type": "api",
                        "level": -1,
                        "metadata": {
                            "endpoint": "/api/v1/customers",
                            "method": "POST",
                            "owner": "backend_team",
                            "avg_calls_per_day": 15000
                        } if include_metadata else {}
                    },
                    {
                        "id": "customer_analytics",
                        "name": "customer_analytics",
                        "type": "view",
                        "schema": "analytics",
                        "database": "warehouse",
                        "level": 1,
                        "metadata": {
                            "owner": "analytics_team",
                            "refresh_frequency": "daily",
                            "consumers": 12
                        } if include_metadata else {}
                    },
                    {
                        "id": "customer_report",
                        "name": "Monthly Customer Report",
                        "type": "report",
                        "level": 2,
                        "metadata": {
                            "format": "PDF",
                            "schedule": "monthly",
                            "recipients": ["executives", "sales_team"]
                        } if include_metadata else {}
                    }
                ],
                "edges": [
                    {
                        "source": "customer_api",
                        "target": "customers_table",
                        "relationship": "feeds_into",
                        "transformation": "INSERT",
                        "frequency": "real_time"
                    },
                    {
                        "source": "customers_table",
                        "target": "customer_analytics",
                        "relationship": "transforms_to",
                        "transformation": "SELECT with aggregations",
                        "frequency": "daily"
                    },
                    {
                        "source": "customer_analytics",
                        "target": "customer_report",
                        "relationship": "generates",
                        "transformation": "Report generation",
                        "frequency": "monthly"
                    }
                ]
            },
            "statistics": {
                "total_nodes": 4,
                "total_edges": 3,
                "max_depth_reached": 2,
                "upstream_sources": 1,
                "downstream_consumers": 2
            }
        }
    
    return {
        "entity_id": entity_id,
        "error": "Entity not found or no lineage available"
    }


@router.get("/upstream/{entity_id}", response_model=Dict[str, Any])
async def get_upstream_lineage(
    entity_id: str,
    depth: int = Query(10, description="Maximum depth to traverse"),
    include_transformations: bool = Query(True, description="Include transformation details")
):
    """Get upstream lineage (data sources) for an entity"""
    
    return {
        "entity_id": entity_id,
        "direction": "upstream",
        "max_depth": depth,
        "upstream_sources": [
            {
                "source_id": "customer_api",
                "source_name": "Customer Registration API",
                "source_type": "api",
                "path_length": 1,
                "transformation_chain": [
                    {
                        "step": 1,
                        "operation": "API_INSERT",
                        "description": "Customer data inserted via REST API",
                        "frequency": "real_time",
                        "data_volume_per_day": "~5000 records"
                    }
                ] if include_transformations else [],
                "data_freshness": "real_time",
                "reliability_score": 98.5
            },
            {
                "source_id": "legacy_import",
                "source_name": "Legacy System Import",
                "source_type": "batch_job",
                "path_length": 1,
                "transformation_chain": [
                    {
                        "step": 1,
                        "operation": "BULK_INSERT",
                        "description": "Daily import from legacy CRM",
                        "frequency": "daily",
                        "data_volume_per_day": "~1000 records"
                    }
                ] if include_transformations else [],
                "data_freshness": "daily",
                "reliability_score": 94.2
            }
        ],
        "summary": {
            "total_sources": 2,
            "real_time_sources": 1,
            "batch_sources": 1,
            "avg_reliability_score": 96.35,
            "oldest_data_source": "legacy_import",
            "most_reliable_source": "customer_api"
        }
    }


@router.get("/downstream/{entity_id}", response_model=Dict[str, Any])
async def get_downstream_lineage(
    entity_id: str,
    depth: int = Query(10, description="Maximum depth to traverse"),
    include_consumers: bool = Query(True, description="Include consumer details")
):
    """Get downstream lineage (data consumers) for an entity"""
    
    return {
        "entity_id": entity_id,
        "direction": "downstream",
        "max_depth": depth,
        "downstream_consumers": [
            {
                "consumer_id": "customer_analytics",
                "consumer_name": "Customer Analytics View",
                "consumer_type": "view",
                "path_length": 1,
                "usage_pattern": {
                    "frequency": "daily",
                    "typical_query_time": "06:00 UTC",
                    "avg_execution_time_seconds": 45,
                    "data_volume_processed": "1.2M records"
                } if include_consumers else {},
                "business_criticality": "high",
                "dependent_reports": 5
            },
            {
                "consumer_id": "ml_model_training",
                "consumer_name": "Customer Segmentation ML Model",
                "consumer_type": "ml_pipeline",
                "path_length": 2,
                "usage_pattern": {
                    "frequency": "weekly",
                    "typical_query_time": "Sunday 02:00 UTC",
                    "avg_execution_time_seconds": 1800,
                    "data_volume_processed": "1.25M records"
                } if include_consumers else {},
                "business_criticality": "medium",
                "model_accuracy_dependency": "high"
            },
            {
                "consumer_id": "customer_dashboard",
                "consumer_name": "Executive Customer Dashboard",
                "consumer_type": "dashboard",
                "path_length": 2,
                "usage_pattern": {
                    "frequency": "real_time",
                    "active_users": 25,
                    "avg_queries_per_hour": 120,
                    "peak_usage_time": "09:00-11:00 UTC"
                } if include_consumers else {},
                "business_criticality": "critical",
                "executive_visibility": True
            }
        ],
        "impact_analysis": {
            "total_consumers": 3,
            "critical_consumers": 1,
            "high_priority_consumers": 1,
            "estimated_impact_if_unavailable": {
                "affected_dashboards": 3,
                "affected_reports": 8,
                "affected_ml_models": 2,
                "business_impact_level": "high"
            }
        }
    }


@router.get("/path/{source_id}/{target_id}", response_model=Dict[str, Any])
async def get_lineage_path(
    source_id: str,
    target_id: str,
    include_transformations: bool = Query(True, description="Include transformation details")
):
    """Get the lineage path between two entities"""
    
    return {
        "source_id": source_id,
        "target_id": target_id,
        "path_found": True,
        "path_length": 3,
        "path": [
            {
                "step": 1,
                "entity_id": source_id,
                "entity_name": "Customer API",
                "entity_type": "api",
                "transformation": {
                    "operation": "INSERT",
                    "description": "Real-time customer data insertion",
                    "data_quality_checks": ["email_validation", "phone_validation"],
                    "estimated_latency_ms": 150
                } if include_transformations else {}
            },
            {
                "step": 2,
                "entity_id": "customers_table",
                "entity_name": "customers",
                "entity_type": "table",
                "transformation": {
                    "operation": "AGGREGATE",
                    "description": "Customer data aggregation for analytics",
                    "sql_query": "SELECT customer_id, COUNT(*) as order_count, SUM(total) as total_spent FROM customers c JOIN orders o ON c.id = o.customer_id GROUP BY customer_id",
                    "estimated_latency_ms": 2500
                } if include_transformations else {}
            },
            {
                "step": 3,
                "entity_id": target_id,
                "entity_name": "Customer Analytics Dashboard",
                "entity_type": "dashboard",
                "transformation": {
                    "operation": "VISUALIZATION",
                    "description": "Real-time dashboard rendering",
                    "refresh_frequency": "5 minutes",
                    "estimated_latency_ms": 800
                } if include_transformations else {}
            }
        ],
        "total_estimated_latency_ms": 3450,
        "data_freshness": "5 minutes",
        "reliability_score": 96.8
    }


@router.get("/search", response_model=Dict[str, Any])
async def search_lineage(
    query: str = Query(..., description="Search term"),
    entity_types: Optional[List[str]] = Query(None, description="Filter by entity types"),
    limit: int = Query(20, description="Maximum results to return")
):
    """Search entities in the lineage graph"""
    
    # Simulate search results
    results = [
        {
            "entity_id": "customers_table",
            "entity_name": "customers",
            "entity_type": "table",
            "schema": "production",
            "database": "crm",
            "description": "Main customer data table",
            "relevance_score": 95.2,
            "upstream_count": 2,
            "downstream_count": 8,
            "last_updated": "2025-06-15T08:30:00Z"
        },
        {
            "entity_id": "customer_analytics",
            "entity_name": "customer_analytics",
            "entity_type": "view",
            "schema": "analytics",
            "database": "warehouse",
            "description": "Customer analytics aggregated view",
            "relevance_score": 87.6,
            "upstream_count": 1,
            "downstream_count": 5,
            "last_updated": "2025-06-15T06:00:00Z"
        }
    ]
    
    # Apply entity type filter if provided
    if entity_types:
        results = [r for r in results if r["entity_type"] in entity_types]
    
    return {
        "query": query,
        "total_results": len(results),
        "results": results[:limit],
        "entity_type_distribution": {
            "table": 1,
            "view": 1,
            "api": 0,
            "dashboard": 0
        },
        "search_time_ms": 45
    }


@router.post("/register-entity", response_model=Dict[str, Any])
async def register_lineage_entity(entity_data: Dict[str, Any]):
    """Register a new entity in the lineage graph"""
    
    return {
        "entity_id": entity_data.get("entity_id"),
        "entity_name": entity_data.get("entity_name"),
        "entity_type": entity_data.get("entity_type"),
        "status": "registered",
        "registered_at": datetime.utcnow().isoformat(),
        "lineage_tracking_enabled": True,
        "auto_discovery_enabled": entity_data.get("auto_discovery", True)
    }


@router.post("/register-relationship", response_model=Dict[str, Any])
async def register_lineage_relationship(relationship_data: Dict[str, Any]):
    """Register a new relationship in the lineage graph"""
    
    return {
        "source_id": relationship_data.get("source_id"),
        "target_id": relationship_data.get("target_id"),
        "relationship_type": relationship_data.get("relationship_type"),
        "transformation_details": relationship_data.get("transformation_details"),
        "status": "registered",
        "registered_at": datetime.utcnow().isoformat(),
        "monitoring_enabled": True
    }


@router.get("/statistics", response_model=Dict[str, Any])
async def get_lineage_statistics():
    """Get overall lineage graph statistics"""
    
    return {
        "total_entities": 1247,
        "total_relationships": 3891,
        "entity_types": {
            "tables": 456,
            "views": 234,
            "apis": 89,
            "dashboards": 67,
            "reports": 123,
            "ml_models": 45,
            "files": 233
        },
        "relationship_types": {
            "feeds_into": 1567,
            "transforms_to": 1234,
            "generates": 567,
            "derives_from": 523
        },
        "graph_metrics": {
            "avg_depth": 4.2,
            "max_depth": 12,
            "orphaned_entities": 23,
            "circular_dependencies": 0,
            "most_connected_entity": {
                "entity_id": "customers_table",
                "total_connections": 45
            }
        },
        "data_freshness": {
            "real_time_entities": 234,
            "daily_refresh": 567,
            "weekly_refresh": 123,
            "manual_refresh": 89,
            "stale_entities": 12
        },
        "generated_at": datetime.utcnow().isoformat()
    }

