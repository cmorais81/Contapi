"""
Multi-tenancy models for TBR GDP Core
"""

from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, JSON, ForeignKey
from sqlalchemy.dialects.postgresql import TIMESTAMPTZ
from sqlalchemy.orm import relationship
from governance_api.database.base import Base


class Organization(Base):
    """Organization/Tenant model for multi-tenancy"""
    __tablename__ = "organizations"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(Text, nullable=False)
    code = Column(Text, unique=True, nullable=False, index=True)  # BR, US, EU
    region = Column(Text)
    country = Column(Text)
    timezone = Column(Text, default="UTC")
    locale = Column(Text, default="en-US")
    currency = Column(Text, default="USD")
    compliance_frameworks = Column(JSON, default=list)  # LGPD, GDPR, SOX
    is_active = Column(Boolean, default=True)
    
    # Configuration settings
    data_retention_days = Column(Integer, default=2555)  # 7 years default
    anonymization_required = Column(Boolean, default=False)
    encryption_required = Column(Boolean, default=True)
    audit_level = Column(Text, default="standard")  # minimal, standard, detailed
    
    # Metadata
    created_at = Column(TIMESTAMPTZ, server_default="now()")
    updated_at = Column(TIMESTAMPTZ, server_default="now()", onupdate="now()")
    
    # Relationships
    contracts = relationship("DataContract", back_populates="organization")
    users = relationship("OrganizationUser", back_populates="organization")


class OrganizationUser(Base):
    """Users associated with organizations"""
    __tablename__ = "organization_users"
    
    id = Column(Integer, primary_key=True, index=True)
    organization_id = Column(Integer, ForeignKey("organizations.id"), nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    role = Column(Text, nullable=False)  # admin, steward, viewer
    permissions = Column(JSON, default=list)
    is_active = Column(Boolean, default=True)
    
    # Metadata
    created_at = Column(TIMESTAMPTZ, server_default="now()")
    updated_at = Column(TIMESTAMPTZ, server_default="now()", onupdate="now()")
    
    # Relationships
    organization = relationship("Organization", back_populates="users")


class ContractVersioning(Base):
    """Advanced contract versioning with multiple active versions"""
    __tablename__ = "contract_versioning"
    
    id = Column(Integer, primary_key=True, index=True)
    contract_id = Column(Integer, ForeignKey("data_contracts.id"), nullable=False)
    version = Column(Text, nullable=False)
    
    # Version status and lifecycle
    status = Column(Text, default="draft")  # draft, active, deprecated, retired
    is_active = Column(Boolean, default=False)
    traffic_percentage = Column(Integer, default=0)  # 0-100
    
    # Lifecycle dates
    effective_date = Column(TIMESTAMPTZ)
    deprecation_date = Column(TIMESTAMPTZ)
    retirement_date = Column(TIMESTAMPTZ)
    
    # Migration information
    migration_path = Column(Text)
    backward_compatible = Column(Boolean, default=False)
    breaking_changes = Column(Boolean, default=False)
    migration_script = Column(Text)
    
    # Schema and configuration
    schema_definition = Column(JSON, nullable=False)
    quality_requirements = Column(JSON, default=dict)
    sla_definition = Column(JSON, default=dict)
    
    # Change tracking
    changelog = Column(Text)
    created_by = Column(Integer, ForeignKey("users.id"))
    approved_by = Column(Integer, ForeignKey("users.id"))
    approved_at = Column(TIMESTAMPTZ)
    
    # Metadata
    created_at = Column(TIMESTAMPTZ, server_default="now()")
    updated_at = Column(TIMESTAMPTZ, server_default="now()", onupdate="now()")


class VersionMigration(Base):
    """Track version migrations and rollout strategies"""
    __tablename__ = "version_migrations"
    
    id = Column(Integer, primary_key=True, index=True)
    contract_id = Column(Integer, ForeignKey("data_contracts.id"), nullable=False)
    from_version = Column(Text, nullable=False)
    to_version = Column(Text, nullable=False)
    
    # Migration strategy
    strategy_type = Column(Text, nullable=False)  # blue_green, canary, gradual
    rollout_phases = Column(JSON, default=list)
    current_phase = Column(Integer, default=0)
    
    # Status tracking
    status = Column(Text, default="planned")  # planned, in_progress, completed, failed, rolled_back
    started_at = Column(TIMESTAMPTZ)
    completed_at = Column(TIMESTAMPTZ)
    
    # Monitoring
    success_metrics = Column(JSON, default=dict)
    error_rate = Column(Integer, default=0)
    performance_impact = Column(JSON, default=dict)
    
    # Rollback information
    rollback_available = Column(Boolean, default=True)
    rollback_script = Column(Text)
    rollback_reason = Column(Text)
    
    # Metadata
    created_at = Column(TIMESTAMPTZ, server_default="now()")
    updated_at = Column(TIMESTAMPTZ, server_default="now()", onupdate="now()")


class OrganizationConfig(Base):
    """Organization-specific configuration settings"""
    __tablename__ = "organization_configs"
    
    id = Column(Integer, primary_key=True, index=True)
    organization_id = Column(Integer, ForeignKey("organizations.id"), nullable=False)
    config_key = Column(Text, nullable=False)
    config_value = Column(JSON, nullable=False)
    config_type = Column(Text, nullable=False)  # compliance, integration, notification
    
    # Metadata
    is_active = Column(Boolean, default=True)
    created_at = Column(TIMESTAMPTZ, server_default="now()")
    updated_at = Column(TIMESTAMPTZ, server_default="now()", onupdate="now()")
    
    # Unique constraint per organization and key
    __table_args__ = (
        {"schema": None},
    )

