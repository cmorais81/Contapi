"""
Data Contract Domain Entities
"""

from datetime import datetime
from enum import Enum
from typing import Dict, List, Optional, Any
from .base import BaseEntity


class ContractStatus(Enum):
    """Contract status enumeration"""
    DRAFT = "draft"
    ACTIVE = "active"
    DEPRECATED = "deprecated"
    REJECTED = "rejected"


class ContractType(Enum):
    """Contract type enumeration"""
    DATA_PRODUCT = "data_product"
    DATA_SERVICE = "data_service"
    DATA_API = "data_api"
    DATA_STREAM = "data_stream"


class DataContract(BaseEntity):
    """Data Contract domain entity"""
    
    def __init__(
        self,
        name: str,
        version: str,
        description: str,
        schema_definition: Dict[str, Any],
        contract_type: ContractType = ContractType.DATA_PRODUCT,
        id: Optional[int] = None
    ):
        super().__init__(id)
        self._name = name
        self._version = version
        self._description = description
        self._schema_definition = schema_definition
        self._contract_type = contract_type
        self._status = ContractStatus.DRAFT
        self._owner: Optional[str] = None
        self._steward: Optional[str] = None
        self._domain: Optional[str] = None
        self._tags: List[str] = []
        self._quality_requirements: Dict[str, Any] = {}
        self._sla_definition: Dict[str, Any] = {}
        self._approved_by: Optional[str] = None
        self._approved_at: Optional[datetime] = None
        self._rejection_reason: Optional[str] = None
    
    @property
    def name(self) -> str:
        return self._name
    
    @property
    def version(self) -> str:
        return self._version
    
    @property
    def description(self) -> str:
        return self._description
    
    @property
    def schema_definition(self) -> Dict[str, Any]:
        return self._schema_definition.copy()
    
    @property
    def contract_type(self) -> ContractType:
        return self._contract_type
    
    @property
    def status(self) -> ContractStatus:
        return self._status
    
    @property
    def owner(self) -> Optional[str]:
        return self._owner
    
    @property
    def steward(self) -> Optional[str]:
        return self._steward
    
    @property
    def domain(self) -> Optional[str]:
        return self._domain
    
    @property
    def tags(self) -> List[str]:
        return self._tags.copy()
    
    @property
    def quality_requirements(self) -> Dict[str, Any]:
        return self._quality_requirements.copy()
    
    @property
    def sla_definition(self) -> Dict[str, Any]:
        return self._sla_definition.copy()
    
    @property
    def approved_by(self) -> Optional[str]:
        return self._approved_by
    
    @property
    def approved_at(self) -> Optional[datetime]:
        return self._approved_at
    
    @property
    def rejection_reason(self) -> Optional[str]:
        return self._rejection_reason
    
    def set_owner(self, owner: str) -> None:
        """Set contract owner"""
        self._owner = owner
        self.update_timestamp()
    
    def set_steward(self, steward: str) -> None:
        """Set data steward"""
        self._steward = steward
        self.update_timestamp()
    
    def set_domain(self, domain: str) -> None:
        """Set business domain"""
        self._domain = domain
        self.update_timestamp()
    
    def add_tag(self, tag: str) -> None:
        """Add a tag"""
        if tag not in self._tags:
            self._tags.append(tag)
            self.update_timestamp()
    
    def remove_tag(self, tag: str) -> None:
        """Remove a tag"""
        if tag in self._tags:
            self._tags.remove(tag)
            self.update_timestamp()
    
    def update_schema(self, schema_definition: Dict[str, Any]) -> None:
        """Update schema definition"""
        self._schema_definition = schema_definition
        self.update_timestamp()
    
    def set_quality_requirements(self, requirements: Dict[str, Any]) -> None:
        """Set quality requirements"""
        self._quality_requirements = requirements
        self.update_timestamp()
    
    def set_sla_definition(self, sla: Dict[str, Any]) -> None:
        """Set SLA definition"""
        self._sla_definition = sla
        self.update_timestamp()
    
    def approve(self, approved_by: str) -> None:
        """Approve the contract"""
        if self._status != ContractStatus.DRAFT:
            raise ValueError("Only draft contracts can be approved")
        
        self._status = ContractStatus.ACTIVE
        self._approved_by = approved_by
        self._approved_at = datetime.utcnow()
        self._rejection_reason = None
        self.update_timestamp()
    
    def reject(self, reason: str) -> None:
        """Reject the contract"""
        if self._status != ContractStatus.DRAFT:
            raise ValueError("Only draft contracts can be rejected")
        
        self._status = ContractStatus.REJECTED
        self._rejection_reason = reason
        self.update_timestamp()
    
    def deprecate(self) -> None:
        """Deprecate the contract"""
        if self._status != ContractStatus.ACTIVE:
            raise ValueError("Only active contracts can be deprecated")
        
        self._status = ContractStatus.DEPRECATED
        self.update_timestamp()
    
    def is_active(self) -> bool:
        """Check if contract is active"""
        return self._status == ContractStatus.ACTIVE
    
    def can_be_modified(self) -> bool:
        """Check if contract can be modified"""
        return self._status == ContractStatus.DRAFT


class ContractVersion(BaseEntity):
    """Contract Version domain entity"""
    
    def __init__(
        self,
        contract_id: int,
        version: str,
        schema_definition: Dict[str, Any],
        changelog: Optional[str] = None,
        id: Optional[int] = None
    ):
        super().__init__(id)
        self._contract_id = contract_id
        self._version = version
        self._schema_definition = schema_definition
        self._changelog = changelog
        self._is_active = False
        self._breaking_changes = False
        self._migration_script: Optional[str] = None
    
    @property
    def contract_id(self) -> int:
        return self._contract_id
    
    @property
    def version(self) -> str:
        return self._version
    
    @property
    def schema_definition(self) -> Dict[str, Any]:
        return self._schema_definition.copy()
    
    @property
    def changelog(self) -> Optional[str]:
        return self._changelog
    
    @property
    def is_active(self) -> bool:
        return self._is_active
    
    @property
    def breaking_changes(self) -> bool:
        return self._breaking_changes
    
    @property
    def migration_script(self) -> Optional[str]:
        return self._migration_script
    
    def activate(self) -> None:
        """Activate this version"""
        self._is_active = True
        self.update_timestamp()
    
    def deactivate(self) -> None:
        """Deactivate this version"""
        self._is_active = False
        self.update_timestamp()
    
    def mark_breaking_changes(self, migration_script: Optional[str] = None) -> None:
        """Mark version as having breaking changes"""
        self._breaking_changes = True
        self._migration_script = migration_script
        self.update_timestamp()


class ContractValidation(BaseEntity):
    """Contract Validation domain entity"""
    
    def __init__(
        self,
        contract_id: int,
        validation_type: str,
        validation_rules: Dict[str, Any],
        id: Optional[int] = None
    ):
        super().__init__(id)
        self._contract_id = contract_id
        self._validation_type = validation_type
        self._validation_rules = validation_rules
        self._is_active = True
        self._last_validation: Optional[datetime] = None
        self._validation_result: Optional[Dict[str, Any]] = None
    
    @property
    def contract_id(self) -> int:
        return self._contract_id
    
    @property
    def validation_type(self) -> str:
        return self._validation_type
    
    @property
    def validation_rules(self) -> Dict[str, Any]:
        return self._validation_rules.copy()
    
    @property
    def is_active(self) -> bool:
        return self._is_active
    
    @property
    def last_validation(self) -> Optional[datetime]:
        return self._last_validation
    
    @property
    def validation_result(self) -> Optional[Dict[str, Any]]:
        return self._validation_result.copy() if self._validation_result else None
    
    def execute_validation(self, result: Dict[str, Any]) -> None:
        """Execute validation and store result"""
        self._last_validation = datetime.utcnow()
        self._validation_result = result
        self.update_timestamp()
    
    def activate(self) -> None:
        """Activate validation"""
        self._is_active = True
        self.update_timestamp()
    
    def deactivate(self) -> None:
        """Deactivate validation"""
        self._is_active = False
        self.update_timestamp()
    
    def update_rules(self, rules: Dict[str, Any]) -> None:
        """Update validation rules"""
        self._validation_rules = rules
        self.update_timestamp()

