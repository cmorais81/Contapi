"""
Domain Entities for TBR GDP Core
Rich domain entities following DDD principles
"""

from .base import BaseEntity
from .data_contract import DataContract, ContractVersion, ContractValidation
from .data_entity import DataEntity, EntityAttribute
from .quality import QualityRule, QualityMetric, QualityIncident
from .governance import Domain, DataSteward, GovernancePolicy
from .monitoring import Dashboard, Alert, Metric
from .integration import ExternalSystem, LineageNode, SystemConnector
from .access_control import AccessPolicy, DataAccess, PrivacyRule

__all__ = [
    'BaseEntity',
    'DataContract',
    'ContractVersion', 
    'ContractValidation',
    'DataEntity',
    'EntityAttribute',
    'QualityRule',
    'QualityMetric',
    'QualityIncident',
    'Domain',
    'DataSteward',
    'GovernancePolicy',
    'Dashboard',
    'Alert',
    'Metric',
    'ExternalSystem',
    'LineageNode',
    'SystemConnector',
    'AccessPolicy',
    'DataAccess',
    'PrivacyRule'
]

