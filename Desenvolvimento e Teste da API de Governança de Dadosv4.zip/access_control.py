"""
Access Control and Privacy Domain Entities
"""

from datetime import datetime, date
from enum import Enum
from typing import Dict, List, Optional, Any
from .base import BaseEntity


class AccessLevel(Enum):
    """Access levels for data"""
    READ = "read"
    WRITE = "write"
    DELETE = "delete"
    ADMIN = "admin"


class PrivacyLevel(Enum):
    """Privacy levels for data classification"""
    PUBLIC = "public"
    INTERNAL = "internal"
    CONFIDENTIAL = "confidential"
    RESTRICTED = "restricted"
    PII = "pii"
    SENSITIVE_PII = "sensitive_pii"


class DataClassification(Enum):
    """Data classification types"""
    PUBLIC = "public"
    INTERNAL = "internal"
    CONFIDENTIAL = "confidential"
    RESTRICTED = "restricted"
    TOP_SECRET = "top_secret"


class AccessPolicy(BaseEntity):
    """Access policy domain entity"""
    
    def __init__(
        self,
        name: str,
        description: str,
        policy_type: str,
        rules: Dict[str, Any],
        is_active: bool = True,
        id: Optional[int] = None
    ):
        super().__init__(id)
        self._name = name
        self._description = description
        self._policy_type = policy_type
        self._rules = rules
        self._is_active = is_active
        self._effective_date = datetime.utcnow().date()
        self._expiry_date: Optional[date] = None
    
    @property
    def name(self) -> str:
        return self._name
    
    @property
    def description(self) -> str:
        return self._description
    
    @property
    def policy_type(self) -> str:
        return self._policy_type
    
    @property
    def rules(self) -> Dict[str, Any]:
        return self._rules.copy()
    
    @property
    def is_active(self) -> bool:
        return self._is_active
    
    @property
    def effective_date(self) -> date:
        return self._effective_date
    
    @property
    def expiry_date(self) -> Optional[date]:
        return self._expiry_date
    
    def activate(self) -> None:
        """Activate the policy"""
        self._is_active = True
        self.update_timestamp()
    
    def deactivate(self) -> None:
        """Deactivate the policy"""
        self._is_active = False
        self.update_timestamp()
    
    def set_expiry_date(self, expiry_date: date) -> None:
        """Set expiry date for the policy"""
        self._expiry_date = expiry_date
        self.update_timestamp()
    
    def is_expired(self) -> bool:
        """Check if policy is expired"""
        if not self._expiry_date:
            return False
        return datetime.utcnow().date() > self._expiry_date
    
    def update_rules(self, rules: Dict[str, Any]) -> None:
        """Update policy rules"""
        self._rules = rules
        self.update_timestamp()


class DataAccess(BaseEntity):
    """Data access tracking entity"""
    
    def __init__(
        self,
        user_id: int,
        entity_id: int,
        access_level: AccessLevel,
        granted_by: int,
        reason: str,
        id: Optional[int] = None
    ):
        super().__init__(id)
        self._user_id = user_id
        self._entity_id = entity_id
        self._access_level = access_level
        self._granted_by = granted_by
        self._reason = reason
        self._granted_at = datetime.utcnow()
        self._expires_at: Optional[datetime] = None
        self._is_active = True
        self._last_accessed: Optional[datetime] = None
        self._access_count = 0
    
    @property
    def user_id(self) -> int:
        return self._user_id
    
    @property
    def entity_id(self) -> int:
        return self._entity_id
    
    @property
    def access_level(self) -> AccessLevel:
        return self._access_level
    
    @property
    def granted_by(self) -> int:
        return self._granted_by
    
    @property
    def reason(self) -> str:
        return self._reason
    
    @property
    def granted_at(self) -> datetime:
        return self._granted_at
    
    @property
    def expires_at(self) -> Optional[datetime]:
        return self._expires_at
    
    @property
    def is_active(self) -> bool:
        return self._is_active
    
    @property
    def last_accessed(self) -> Optional[datetime]:
        return self._last_accessed
    
    @property
    def access_count(self) -> int:
        return self._access_count
    
    def set_expiry(self, expires_at: datetime) -> None:
        """Set expiry time for access"""
        self._expires_at = expires_at
        self.update_timestamp()
    
    def revoke(self) -> None:
        """Revoke access"""
        self._is_active = False
        self.update_timestamp()
    
    def record_access(self) -> None:
        """Record an access event"""
        self._last_accessed = datetime.utcnow()
        self._access_count += 1
        self.update_timestamp()
    
    def is_expired(self) -> bool:
        """Check if access is expired"""
        if not self._expires_at:
            return False
        return datetime.utcnow() > self._expires_at
    
    def is_valid(self) -> bool:
        """Check if access is valid (active and not expired)"""
        return self._is_active and not self.is_expired()


class PrivacyRule(BaseEntity):
    """Privacy rule domain entity"""
    
    def __init__(
        self,
        name: str,
        description: str,
        rule_type: str,
        privacy_level: PrivacyLevel,
        data_classification: DataClassification,
        retention_period_days: Optional[int] = None,
        anonymization_required: bool = False,
        consent_required: bool = False,
        id: Optional[int] = None
    ):
        super().__init__(id)
        self._name = name
        self._description = description
        self._rule_type = rule_type
        self._privacy_level = privacy_level
        self._data_classification = data_classification
        self._retention_period_days = retention_period_days
        self._anonymization_required = anonymization_required
        self._consent_required = consent_required
        self._is_active = True
        self._compliance_frameworks: List[str] = []
    
    @property
    def name(self) -> str:
        return self._name
    
    @property
    def description(self) -> str:
        return self._description
    
    @property
    def rule_type(self) -> str:
        return self._rule_type
    
    @property
    def privacy_level(self) -> PrivacyLevel:
        return self._privacy_level
    
    @property
    def data_classification(self) -> DataClassification:
        return self._data_classification
    
    @property
    def retention_period_days(self) -> Optional[int]:
        return self._retention_period_days
    
    @property
    def anonymization_required(self) -> bool:
        return self._anonymization_required
    
    @property
    def consent_required(self) -> bool:
        return self._consent_required
    
    @property
    def is_active(self) -> bool:
        return self._is_active
    
    @property
    def compliance_frameworks(self) -> List[str]:
        return self._compliance_frameworks.copy()
    
    def add_compliance_framework(self, framework: str) -> None:
        """Add compliance framework"""
        if framework not in self._compliance_frameworks:
            self._compliance_frameworks.append(framework)
            self.update_timestamp()
    
    def remove_compliance_framework(self, framework: str) -> None:
        """Remove compliance framework"""
        if framework in self._compliance_frameworks:
            self._compliance_frameworks.remove(framework)
            self.update_timestamp()
    
    def activate(self) -> None:
        """Activate the rule"""
        self._is_active = True
        self.update_timestamp()
    
    def deactivate(self) -> None:
        """Deactivate the rule"""
        self._is_active = False
        self.update_timestamp()
    
    def update_retention_period(self, days: int) -> None:
        """Update retention period"""
        self._retention_period_days = days
        self.update_timestamp()
    
    def requires_anonymization(self) -> bool:
        """Check if data requires anonymization"""
        return self._anonymization_required
    
    def requires_consent(self) -> bool:
        """Check if data requires consent"""
        return self._consent_required

