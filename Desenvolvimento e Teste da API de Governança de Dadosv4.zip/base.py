"""
Base Entity for Domain Driven Design
"""

from abc import ABC
from datetime import datetime
from typing import Any, Dict, List, Optional
from uuid import uuid4


class BaseEntity(ABC):
    """Base entity with common functionality"""
    
    def __init__(self, id: Optional[int] = None):
        self._id = id
        self._created_at = datetime.utcnow()
        self._updated_at = datetime.utcnow()
        self._version = 1
        self._domain_events: List[Any] = []
    
    @property
    def id(self) -> Optional[int]:
        return self._id
    
    @property
    def created_at(self) -> datetime:
        return self._created_at
    
    @property
    def updated_at(self) -> datetime:
        return self._updated_at
    
    @property
    def version(self) -> int:
        return self._version
    
    @property
    def domain_events(self) -> List[Any]:
        return self._domain_events.copy()
    
    def mark_events_as_committed(self) -> None:
        """Mark all domain events as committed"""
        self._domain_events.clear()
    
    def add_domain_event(self, event: Any) -> None:
        """Add a domain event"""
        self._domain_events.append(event)
    
    def update_timestamp(self) -> None:
        """Update the updated_at timestamp"""
        self._updated_at = datetime.utcnow()
        self._version += 1
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert entity to dictionary"""
        return {
            'id': self.id,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat(),
            'version': self.version
        }
    
    def __eq__(self, other) -> bool:
        if not isinstance(other, BaseEntity):
            return False
        return self.id == other.id
    
    def __hash__(self) -> int:
        return hash(self.id) if self.id else hash(id(self))

