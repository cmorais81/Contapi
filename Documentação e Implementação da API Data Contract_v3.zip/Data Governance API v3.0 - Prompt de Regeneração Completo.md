# Data Governance API v3.0 - Prompt de Regeneração Completo

**Versão:** 3.0.0  
**Data:** Julho 2025  
**Desenvolvido por:** Carlos Morais  
**Objetivo:** Prompt para regeneração completa do projeto com 42 tabelas  

---

## 🎯 PROMPT PARA REGENERAÇÃO

### Contexto e Objetivo
Criar uma **Data Governance API v3.0** completa e funcional, uma solução enterprise de governança de dados com integrações nativas para DataHub e Azure Cost Management. O projeto deve ser desenvolvido por **Carlos Morais** e incluir aplicação funcional, documentação completa e dados mockados realísticos.

### Especificações Técnicas Obrigatórias

#### 🏗️ **Arquitetura e Tecnologias**
- **Framework:** FastAPI (Python 3.11+)
- **Database:** SQLite para desenvolvimento (compatível PostgreSQL)
- **ORM:** SQLAlchemy com modelos declarativos
- **Schemas:** Pydantic v2 para validação
- **Documentação:** Swagger/OpenAPI automática
- **Estrutura:** Arquitetura em camadas (models, schemas, services, endpoints)

#### 📊 **Modelo de Dados (42 Tabelas DBML) - ESTRUTURA OBRIGATÓRIA**

### **Tabelas Originais (36 tabelas) - MANTER TODAS OBRIGATORIAMENTE:**

#### **Entidades e Metadados (4 tabelas):**
- **entities**: Catálogo principal de ativos de dados
- **data_objects**: Colunas/campos das entidades
- **components**: Aplicações e sistemas
- **external_systems**: Sistemas externos

#### **Contratos de Dados (2 tabelas):**
- **data_contracts**: Acordos formais de dados
- **contract_versions**: Versionamento de contratos

#### **Qualidade de Dados (5 tabelas):**
- **quality_rules**: Regras de validação
- **quality_executions**: Execuções das regras
- **quality_results**: Resultados detalhados
- **quality_metrics**: Métricas agregadas
- **quality_thresholds**: Limites e alertas

#### **Linhagem e Relacionamentos (2 tabelas):**
- **lineage_relationships**: Relacionamentos entre entidades
- **lineage_analysis**: Análises de impacto

#### **Métricas e Monitoramento (4 tabelas):**
- **performance_metrics**: Métricas de performance
- **metric_definitions**: Definições de métricas
- **metric_values**: Valores time-series
- **metric_alerts**: Alertas baseados em métricas

#### **Gestão de Usuários (3 tabelas):**
- **users**: Usuários do sistema
- **roles**: Perfis de acesso
- **user_roles**: Atribuições de perfis

#### **Tags e Classificação (2 tabelas):**
- **tags**: Definições de tags
- **entity_tags**: Tags aplicadas às entidades

#### **Governança e Políticas (2 tabelas):**
- **governance_policies**: Políticas de governança
- **policy_executions**: Execuções de políticas

#### **Privacidade e Conformidade (3 tabelas):**
- **data_classifications**: Classificações de dados
- **privacy_policies**: Políticas de privacidade
- **consent_records**: Registros de consentimento

#### **Integrações (3 tabelas):**
- **integrations**: Configurações de integração
- **integration_logs**: Logs de integração
- **external_systems**: (já listado acima)

#### **Auditoria (1 tabela):**
- **audit_logs**: Trilha de auditoria completa

### **Novas Funcionalidades DataHub (6 tabelas) - ADICIONAR:**
- **datahub_entities**: Sincronização entidades DataHub com URNs
- **datahub_lineage**: Linhagem cross-platform DataHub
- **datahub_sync_jobs**: Jobs de sincronização e status
- **datahub_metadata**: Metadados detalhados por tipo
- **datahub_platforms**: Configurações de plataforma
- **datahub_schemas**: Versões e definições de schema

### **Novas Funcionalidades Azure Cost (6 tabelas) - ADICIONAR:**
- **azure_cost_data**: Custos Azure detalhados por recurso
- **databricks_cost_data**: Custos DBU e compute Databricks
- **cost_optimization_recommendations**: Recomendações IA com economia
- **cost_budgets**: Orçamentos e controles de gastos
- **cost_alerts**: Alertas proativos de custo
- **cost_forecasts**: Previsões ML com intervalos confiança

**TOTAL OBRIGATÓRIO: 42 tabelas (36 originais + 6 DataHub + 6 Azure Cost)**

#### 🔌 **Integrações Obrigatórias**

**DataHub Integration:**
- Sincronização bidirecional de entidades
- Linhagem cross-platform unificada
- Descoberta automatizada de metadados
- Jobs de sincronização com monitoramento

**Azure Cost Management:**
- Coleta automática custos Azure/Databricks
- Análise preditiva com ML
- Recomendações otimização baseadas IA
- Alertas proativos e orçamentos

**Multi-Platform Support:**
- Unity Catalog (compatibilidade mantida)
- Informatica Axon (compatibilidade mantida)
- DataHub (nova integração principal)
- Azure (nova integração custos)

#### 📱 **Endpoints da API (48+ endpoints obrigatórios)**

**Básicos (3):**
- GET / (info), GET /health, GET /stats

**Entidades (6):**
- GET/POST /api/v1/entities/
- GET/PUT/DELETE /api/v1/entities/{id}
- GET /api/v1/entities/{id}/lineage

**Contratos (4):**
- GET/POST /api/v1/contracts/
- GET/PUT/DELETE /api/v1/contracts/{id}

**Qualidade (6):**
- GET/POST /api/v1/quality/rules/
- GET/POST /api/v1/quality/executions/
- GET /api/v1/quality/results/

**DataHub (8):**
- GET /api/v1/datahub/entities/
- POST /api/v1/datahub/sync/
- GET /api/v1/datahub/lineage/{urn}
- GET /api/v1/datahub/platforms/
- GET /api/v1/datahub/jobs/{job_id}
- GET /api/v1/datahub/schemas/{entity_id}/versions

**Azure Costs (12):**
- GET /api/v1/costs/azure/
- GET /api/v1/costs/azure/breakdown
- GET /api/v1/costs/databricks/
- GET /api/v1/costs/databricks/clusters/{id}/analysis
- GET /api/v1/costs/recommendations/
- GET /api/v1/costs/recommendations/summary
- POST /api/v1/costs/budgets/
- GET /api/v1/costs/alerts/active
- POST /api/v1/costs/forecasts/generate

**Outros (9):**
- Users, Tags, Governance, Metrics, Lineage endpoints

#### 💾 **Dados Mockados (300+ registros obrigatórios)**

**Distribuição por Domínio:**
- **Entidades**: 25 registros (tabelas, views, datasets)
- **Contratos**: 15 registros (APIs, batch, streaming)
- **Qualidade**: 30 regras + 60 execuções
- **DataHub**: 50 entidades sincronizadas
- **Azure Costs**: 100 registros custos + 25 recomendações
- **Databricks**: 80 registros DBU/compute
- **Usuários**: 15 usuários + roles
- **Tags**: 25 tags aplicadas
- **Outros**: Métricas, linhagem, auditoria

**Cenários Realísticos:**
- Dados financeiros, vendas, marketing, RH
- Múltiplas plataformas (Snowflake, Databricks, PostgreSQL)
- Diferentes ambientes (dev, test, prod)
- Custos variados por região e serviço

#### 📚 **Documentação Obrigatória (5 documentos)**

**1. README_v3.md (Guia Principal):**
- Visão geral da solução v3.0
- Instruções de instalação e uso
- Exemplos de API calls
- Arquitetura e benefícios

**2. technical_documentation_v3.md (Documentação Técnica):**
- Arquitetura detalhada
- 42 tabelas explicadas
- Endpoints com exemplos
- Integrações DataHub e Azure
- Segurança e conformidade

**3. integration_guide_v3.md (Guia de Integrações):**
- DataHub: configuração e uso
- Azure Cost: setup e análises
- Unity Catalog: compatibilidade
- Informatica Axon: manutenção
- Casos de uso por setor

**4. user_journey_guide_v3.md (Jornada do Usuário):**
- 8 personas detalhadas
- Workflows por tipo de usuário
- Contratos de dados: criação à implementação
- APIs: guias práticos
- UI mockups e fluxos

**5. business_insights_v3.md (Insights de Negócio):**
- ROI e benefícios quantificados
- Casos de sucesso por setor
- Transformação digital
- Vantagem competitiva
- Métricas de adoção

**6. data_governance_model_v3_complete.dbml (Modelo DBML):**
- 42 tabelas com relacionamentos
- Comentários detalhados
- Índices otimizados
- Constraints e validações

#### 🧪 **Critérios de Validação**

**Aplicação Funcional:**
- ✅ 48+ endpoints respondendo corretamente
- ✅ 300+ registros mockados carregados
- ✅ Documentação Swagger acessível
- ✅ Health checks funcionais
- ✅ Paginação e filtros operacionais

**Testes com curl:**
```bash
# Básicos
curl http://localhost:8000/health
curl http://localhost:8000/stats

# Entidades
curl http://localhost:8000/api/v1/entities/
curl -X POST http://localhost:8000/api/v1/entities/ -H "Content-Type: application/json" -d '{...}'

# DataHub
curl http://localhost:8000/api/v1/datahub/entities/
curl http://localhost:8000/api/v1/datahub/platforms/

# Azure Costs
curl http://localhost:8000/api/v1/costs/azure/
curl http://localhost:8000/api/v1/costs/recommendations/summary
```

**Estrutura de Arquivos:**
```
data-governance-api/
├── app/
│   ├── main.py (aplicação principal)
│   ├── models/ (42 modelos SQLAlchemy)
│   ├── schemas/ (schemas Pydantic v2)
│   ├── services/ (business logic)
│   └── api/v1/endpoints/ (endpoints organizados)
├── docs/ (6 documentos obrigatórios)
├── scripts/ (inicialização e dados)
├── requirements.txt
└── README_v3.md
```

#### 🎯 **Funcionalidades Específicas v3.0**

**DataHub Integration:**
- Sincronização automática de entidades
- Linhagem unificada cross-platform
- Descoberta de metadados automatizada
- Monitoramento de jobs de sincronização

**Azure Cost Management:**
- Análise de custos em tempo real
- Recomendações IA de otimização
- Previsões preditivas com ML
- Alertas proativos de orçamento
- Análise DBU Databricks

**FinOps Capabilities:**
- ROI analysis por projeto/departamento
- Cost allocation e chargeback
- Budget management com alertas
- Optimization recommendations

#### 🔒 **Segurança e Conformidade**

**Autenticação:**
- JWT tokens para APIs
- Role-based access control
- Audit trail completo

**Conformidade:**
- GDPR: direito esquecimento, portabilidade
- CCPA: transparência e controle
- HIPAA: dados saúde protegidos
- SOX: controles financeiros

**Privacidade:**
- Data classification automática
- Consent management
- Pseudonymization capabilities

#### 📈 **Métricas de Sucesso**

**Performance:**
- APIs < 200ms latência média
- Suporte 1000+ entidades
- 10K+ execuções qualidade/dia

**Adoção:**
- 15+ usuários ativos
- 25+ contratos de dados
- 100+ regras de qualidade

**Custos:**
- R$ 500K+ economia anual identificada
- 25+ recomendações otimização
- 95%+ precisão previsões

---

## 🚀 PROMPT RESUMIDO PARA IA

**Crie uma Data Governance API v3.0 completa desenvolvida por Carlos Morais com:**

1. **FastAPI + SQLAlchemy + Pydantic v2**
2. **42 tabelas DBML** (36 originais + 6 DataHub + 6 Azure Cost)
3. **48+ endpoints funcionais** testáveis via curl
4. **300+ registros mockados** realísticos
5. **Integrações DataHub e Azure Cost Management**
6. **6 documentos técnicos** completos
7. **Aplicação 100% funcional** com dados carregados
8. **Testes sistemáticos** de todos endpoints
9. **Estrutura enterprise** pronta para produção
10. **Conformidade GDPR/CCPA/HIPAA**

**Entregáveis finais:**
- Aplicação rodando em http://localhost:8000
- Documentação Swagger em /docs
- 6 documentos técnicos completos
- Pacote ZIP com tudo organizado
- Script de inicialização automática
- Dados mockados carregados e testados

**Validação obrigatória:**
- Todos 48+ endpoints respondendo via curl
- 300+ registros carregados no banco
- Documentação acessível e completa
- Health checks funcionais
- Estrutura de arquivos organizada

**Foco especial v3.0:**
- DataHub: sincronização bidirecional completa
- Azure Cost: análise preditiva com IA
- FinOps: otimização e alertas proativos
- Multi-platform: orquestração unificada
- Enterprise: segurança e conformidade

**Autor obrigatório em todos os arquivos: Carlos Morais**

