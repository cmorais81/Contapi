# Documentação Técnica - COBOL AI Engine v1.0.2

## Visão Geral

O COBOL AI Engine v1.0.2 é um sistema completo de análise de programas COBOL utilizando Inteligência Artificial. Esta versão representa uma evolução significativa com foco em simplicidade, configuração centralizada e suporte robusto a múltiplos modelos de IA.

## Arquitetura do Sistema

### Componentes Principais

**Script Principal Unificado (main.py)**
- Ponto de entrada único para todas as funcionalidades
- Gerenciamento de argumentos de linha de comando
- Orquestração de análises single e multi-modelo
- Geração de relatórios comparativos

**Sistema de Configuração**
- `config/config.yaml`: Configuração principal do sistema
- `config/prompts.yaml`: Prompts organizados por modelo e profundidade
- Suporte a variáveis de ambiente para credenciais

**Módulos Core**
- `src/core/`: Componentes centrais (prompt manager, token manager)
- `src/providers/`: Provedores de IA (LuzIA, OpenAI, Mock)
- `src/analyzers/`: Analisadores de código COBOL
- `src/generators/`: Geradores de documentação

## Configuração do Sistema

### Arquivo Principal: config/config.yaml

```yaml
# Configurações de IA
ai:
  default_models:
    - "claude_3_5_sonnet"
  
  prompt:
    max_tokens: 8000
    temperature: 0.1
    system_prompt: |
      Você é um analista de sistemas COBOL especializado...

# Provedores de IA
providers:
  luzia:
    enabled: true
    auth_url: "https://api.luzia.com/auth"
    endpoint: "https://api.luzia.com/v1/chat/completions"
    headers:
      Authorization: "Bearer ${LUZIA_API_KEY}"
      Content-Type: "application/json"
      User-Agent: "COBOL-AI-Engine/1.0.2"
    models:
      claude_3_5_sonnet:
        name: "claude-3-5-sonnet-20241022"
        max_tokens: 8192
        temperature: 0.1
        timeout: 120
        context_window: 200000
```

### Arquivo de Prompts: config/prompts.yaml

```yaml
# Prompts por modelo
model_prompts:
  claude_3_5_sonnet:
    system_prompt: |
      Você é um analista de sistemas COBOL especializado...
    persona: "analista de sistemas COBOL sênior"
    analysis_depth: "detailed"

# Questões de análise organizadas por prioridade
analysis_questions:
  functional:
    priority: 1
    required: true
    question: |
      Forneça uma análise funcional completa...
```

## Uso do Sistema

### Instalação

```bash
# 1. Extrair o pacote
tar -xzf cobol_ai_engine_v1.0.2.tar.gz
cd cobol_ai_engine_v2.0.0/

# 2. Instalar dependências
pip install -r requirements.txt

# 3. Configurar variáveis de ambiente
export LUZIA_API_KEY="sua_chave_luzia_aqui"
```

### Parâmetros de Linha de Comando

```
python main.py <fontes> [opções]

Argumentos Obrigatórios:
  fontes                    Arquivo de fontes COBOL (ex: fontes.txt)

Opções:
  --books BOOKS            Arquivo de copybooks (opcional)
  --output OUTPUT          Diretório de saída (padrão: output)
  --config CONFIG          Arquivo de configuração (padrão: config/config.yaml)
  --models MODELS          Modelo(s) a usar (padrão: configuração)
  --pdf                    Converter para PDF
  --log LEVEL              Nível de log (DEBUG, INFO, WARNING, ERROR)
```

### Exemplos de Uso

**Análise com Configuração Padrão**
```bash
python main.py examples/fontes.txt
```

**Análise com Modelo Específico**
```bash
python main.py examples/fontes.txt --models "claude_3_5_sonnet"
```

**Análise Multi-Modelo**
```bash
python main.py examples/fontes.txt --models '["claude_3_5_sonnet","luzia_standard"]'
```

**Análise Completa com Copybooks**
```bash
python main.py examples/fontes.txt --books examples/BOOKS.txt --models '["claude_3_5_sonnet","luzia_standard"]' --pdf
```

## Provedores de IA Suportados

### LuzIA (Provedor Principal)

**Configuração**
```yaml
luzia:
  enabled: true
  auth_url: "https://api.luzia.com/auth"
  endpoint: "https://api.luzia.com/v1/chat/completions"
  headers:
    Authorization: "Bearer ${LUZIA_API_KEY}"
```

**Modelos Disponíveis**
- `claude_3_5_sonnet`: Análises técnicas profundas (200K tokens)
- `luzia_standard`: Análises balanceadas (32K tokens)

**Configuração de Ambiente**
```bash
export LUZIA_API_KEY="sua_chave_luzia"
```

### OpenAI (Provedor Alternativo)

**Configuração**
```yaml
openai:
  enabled: false
  endpoint: "https://api.openai.com/v1/chat/completions"
  models:
    openai_gpt4:
      name: "gpt-4"
      max_tokens: 8192
```

**Configuração de Ambiente**
```bash
export OPENAI_API_KEY="sua_chave_openai"
```

### Enhanced Mock (Testes e Desenvolvimento)

**Configuração**
```yaml
enhanced_mock:
  enabled: true
  models:
    mock_enhanced:
      name: "enhanced-mock-gpt-4"
      timeout: 5
```

## Estrutura de Saída

### Modelo Único

```
output/
├── PROGRAMA1.md          # Análise do programa 1
├── PROGRAMA2.md          # Análise do programa 2
├── PROGRAMA3.md          # Análise do programa 3
└── ...
```

### Múltiplos Modelos

```
output/
├── model_claude_3_5_sonnet/
│   ├── PROGRAMA1.md
│   ├── PROGRAMA2.md
│   └── ...
├── model_luzia_standard/
│   ├── PROGRAMA1.md
│   ├── PROGRAMA2.md
│   └── ...
└── relatorio_comparativo_modelos.md
```

## Formato dos Relatórios

### Estrutura Padrão

Cada relatório gerado inclui as seguintes seções:

1. **Resumo Executivo**: Visão geral do programa
2. **Análise Técnica**: Estrutura e arquitetura
3. **Regras de Negócio**: Lógica empresarial implementada
4. **Estruturas de Dados**: Layouts e formatos
5. **Interfaces e Integrações**: Dependências externas
6. **Recomendações**: Sugestões de melhoria
7. **Transparência e Auditoria**: Prompts utilizados

### Seção de Transparência

```markdown
## Transparência e Auditoria

### Prompts Utilizados na Análise

#### Prompt Principal
```
Você é um analista de sistemas COBOL especializado...
[prompt completo aqui]
```

#### Contexto do Sistema
- Modelo utilizado: claude-3-5-sonnet-20241022
- Tokens processados: 5,753
- Timestamp: 2025-09-21 20:23:25
- Qualidade: Excelente
```

## Relatório Comparativo Multi-Modelo

Quando múltiplos modelos são utilizados, o sistema gera automaticamente um relatório comparativo incluindo:

### Estatísticas por Modelo

| Modelo | Taxa de Sucesso | Tokens Médios | Qualidade | Tempo Médio |
|--------|----------------|---------------|-----------|-------------|
| claude_3_5_sonnet | 100.0% | 4,764 | Alta | 0.52s |
| luzia_standard | 100.0% | 4,764 | Alta | 0.52s |

### Análise por Programa

Para cada programa analisado, o relatório apresenta:
- Comparação lado a lado dos resultados
- Consensos identificados entre modelos
- Divergências e suas possíveis causas
- Recomendação do melhor resultado

### Recomendações de Uso

- **Desenvolvimento**: Use modelo mock para testes rápidos
- **Análise Padrão**: Use claude_3_5_sonnet para análises completas
- **Análise Crítica**: Execute com múltiplos modelos e compare resultados
- **Produção**: Use o modelo mais estável baseado nas estatísticas

## Engenharia de Prompt

### Estratégias Implementadas

**Context Enrichment**: Enriquecimento do contexto com informações de copybooks e pré-análise automática.

**Structured Analysis**: Análise estruturada com questões organizadas por prioridade e importância.

**Domain Expertise**: Prompts especializados para diferentes tipos de programa COBOL.

**Transparency Focus**: Foco na transparência com salvamento completo dos prompts utilizados.

### Técnicas Utilizadas

- **Few-shot Examples**: Exemplos contextuais para melhor compreensão
- **Chain of Thought**: Raciocínio estruturado passo a passo
- **Role Playing**: Definição clara de persona especializada
- **Structured Output**: Saída organizada em seções bem definidas

### Otimização de Tokens

```yaml
prompt_engineering:
  optimization:
    max_context_tokens: 150000
    reserve_tokens_for_response: 8000
    chunk_overlap: 200
    priority_sections: ["PROCEDURE DIVISION", "DATA DIVISION", "WORKING-STORAGE"]
```

## Análise de Código COBOL

### Componentes Analisados

**Divisões COBOL**
- IDENTIFICATION DIVISION: Metadados do programa
- ENVIRONMENT DIVISION: Configurações de ambiente
- DATA DIVISION: Estruturas de dados
- PROCEDURE DIVISION: Lógica de processamento

**Estruturas de Dados**
- WORKING-STORAGE SECTION: Variáveis de trabalho
- LINKAGE SECTION: Parâmetros de entrada
- FILE SECTION: Definições de arquivos

**Fluxos Lógicos**
- Seções e parágrafos
- Estruturas de controle (IF, PERFORM, etc.)
- Chamadas de programa (CALL)
- Operações de arquivo (READ, WRITE, etc.)

### Análise Semântica

**Comentários Categorizados**
- Negócio: Regras e processos empresariais
- Técnico: Implementação e arquitetura
- Regulatório: Normas e compliance
- Histórico: Mudanças e evoluções

**Entidades de Negócio**
- Identificação automática de conceitos de domínio
- Mapeamento de relacionamentos
- Extração de regras implícitas

**Complexidade Avaliada**
- Análise de fluxos lógicos
- Avaliação de estruturas aninhadas
- Métricas de manutenibilidade

## Logs e Monitoramento

### Configuração de Logs

```yaml
logging:
  level: "INFO"
  format: "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
  file_rotation: true
  max_file_size: "10MB"
  backup_count: 5
  console_output: true
```

### Informações Registradas

- Progresso das análises por programa
- Estatísticas de tokens utilizados
- Erros e avisos durante o processamento
- Métricas de performance e tempo
- Informações de configuração aplicada

### Localização dos Logs

```
logs/
└── cobol_ai_engine_YYYYMMDD_HHMMSS.log
```

## Segurança e Validação

### Validação de Entrada

```yaml
security:
  input_validation:
    max_file_size: "10MB"
    allowed_extensions: [".txt", ".cbl", ".cob", ".cobol"]
    sanitize_content: true
    validate_encoding: true
```

### Configurações de API

- Rate limiting configurável
- Timeouts apropriados
- Verificação SSL habilitada
- Headers de segurança

### Tratamento de Credenciais

- Uso de variáveis de ambiente
- Não armazenamento em arquivos
- Validação de chaves de API

## Performance e Otimização

### Configurações de Performance

```yaml
performance:
  timeout: 300
  memory:
    max_program_size: "5MB"
    max_total_size: "50MB"
  processing:
    parallel_analysis: false
    batch_size: 1
    max_concurrent: 1
    chunk_size: 4000
```

### Métricas Típicas

- **Tempo por programa**: 0.5-2.0 segundos
- **Tokens por análise**: 2,000-8,000 tokens
- **Taxa de sucesso**: 99%+
- **Uso de memória**: <100MB por execução

## Solução de Problemas

### Erros Comuns

**Erro de Autenticação (401)**
```
Causa: Chave de API inválida ou expirada
Solução: Verificar LUZIA_API_KEY ou OPENAI_API_KEY
```

**Modelo Não Encontrado**
```
Causa: Modelo não configurado em config.yaml
Solução: Adicionar modelo na seção providers
```

**Arquivo Não Encontrado**
```
Causa: Caminho incorreto para arquivo de fontes
Solução: Verificar caminho e existência do arquivo
```

**Timeout de Conexão**
```
Causa: Problemas de rede ou sobrecarga da API
Solução: Aumentar timeout em config.yaml
```

### Diagnóstico

**Verificar Configuração**
```bash
python main.py --help
```

**Testar com Mock**
```bash
python main.py examples/fontes.txt --models "mock_enhanced"
```

**Logs Detalhados**
```bash
python main.py examples/fontes.txt --log DEBUG
```

## Extensibilidade

### Adicionando Novos Provedores

1. Criar classe em `src/providers/`
2. Implementar interface base
3. Adicionar configuração em `config.yaml`
4. Registrar no provider manager

### Personalizando Prompts

1. Editar `config/prompts.yaml`
2. Adicionar novos modelos ou questões
3. Configurar profundidade de análise
4. Testar com dados de exemplo

### Novos Formatos de Saída

1. Implementar gerador em `src/generators/`
2. Adicionar configuração de formato
3. Integrar no fluxo principal
4. Documentar uso

## Compatibilidade

### Requisitos do Sistema

- **Python**: 3.11 ou superior
- **Sistemas Operacionais**: Windows, Linux, macOS
- **Memória**: Mínimo 512MB RAM
- **Espaço em Disco**: 100MB para instalação

### Dependências Python

```
pyyaml>=6.0
requests>=2.31.0
python-dateutil>=2.8.2
```

### Provedores de IA

- **LuzIA**: API v1 compatível
- **OpenAI**: API v1 compatível
- **Outros**: Implementação customizada necessária

## Versionamento

### Esquema de Versão

Formato: `MAJOR.MINOR.PATCH`

- **MAJOR**: Mudanças incompatíveis
- **MINOR**: Novas funcionalidades compatíveis
- **PATCH**: Correções de bugs

### Histórico de Versões

- **v1.0.2**: Configuração unificada, limpeza completa
- **v1.0.1**: Suporte multi-modelo, transparência
- **v1.0.0**: Versão inicial estável

## Suporte e Contribuição

### Documentação Adicional

- `README.md`: Guia de uso rápido
- `INSTALACAO.md`: Instruções de instalação
- `examples/`: Arquivos de exemplo

### Estrutura do Projeto

```
cobol_ai_engine_v1.0.2/
├── main.py                 # Script principal
├── config/                 # Configurações
├── src/                    # Código fonte
├── examples/               # Exemplos
├── docs/                   # Documentação
└── requirements.txt        # Dependências
```

### Licença

Este software é fornecido "como está", sem garantias de qualquer tipo. Use por sua própria conta e risco.

---

**Documentação Técnica - COBOL AI Engine v1.0.2**  
**Data**: 21 de Setembro de 2025  
**Compatibilidade**: Python 3.11+
