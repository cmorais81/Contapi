"""
Testes para a configuração unificada.
"""

import sys
import os
import unittest
import yaml
import tempfile

# Adicionar o diretório src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from core.config import ConfigManager


class TestUnifiedConfig(unittest.TestCase):
    """Testes para a configuração unificada."""
    
    def setUp(self):
        """Configuração inicial para cada teste."""
        self.config_path = os.path.join(
            os.path.dirname(__file__), '..', 'config', 'config_unified.yaml'
        )
    
    def test_config_file_exists(self):
        """Testa se o arquivo de configuração unificada existe."""
        self.assertTrue(os.path.exists(self.config_path))
    
    def test_config_is_valid_yaml(self):
        """Testa se o arquivo é um YAML válido."""
        try:
            with open(self.config_path, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f)
            self.assertIsInstance(config, dict)
        except yaml.YAMLError as e:
            self.fail(f"Arquivo de configuração não é um YAML válido: {e}")
    
    def test_config_has_required_sections(self):
        """Testa se a configuração tem todas as seções necessárias."""
        with open(self.config_path, 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)
        
        # Seções obrigatórias
        required_sections = ['ai', 'prompts', 'logging', 'output']
        for section in required_sections:
            self.assertIn(section, config, f"Seção '{section}' não encontrada")
    
    def test_ai_section_structure(self):
        """Testa a estrutura da seção AI."""
        with open(self.config_path, 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)
        
        ai_config = config['ai']
        
        # Campos obrigatórios na seção AI
        required_fields = ['primary_provider', 'fallback_providers', 'providers']
        for field in required_fields:
            self.assertIn(field, ai_config, f"Campo '{field}' não encontrado na seção AI")
        
        # Verificar se primary_provider é uma string
        self.assertIsInstance(ai_config['primary_provider'], str)
        
        # Verificar se fallback_providers é uma lista
        self.assertIsInstance(ai_config['fallback_providers'], list)
        
        # Verificar se providers é um dicionário
        self.assertIsInstance(ai_config['providers'], dict)
    
    def test_providers_configuration(self):
        """Testa a configuração dos provedores."""
        with open(self.config_path, 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)
        
        providers = config['ai']['providers']
        
        # Provedores esperados
        expected_providers = ['openai', 'databricks', 'bedrock', 'luzia', 'enhanced_mock', 'basic']
        for provider in expected_providers:
            self.assertIn(provider, providers, f"Provedor '{provider}' não encontrado")
        
        # Verificar se cada provedor tem configuração 'enabled'
        for provider_name, provider_config in providers.items():
            self.assertIn('enabled', provider_config, 
                         f"Provedor '{provider_name}' não tem campo 'enabled'")
            self.assertIsInstance(provider_config['enabled'], bool)
    
    def test_prompts_section(self):
        """Testa a seção de prompts."""
        with open(self.config_path, 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)
        
        prompts_config = config['prompts']
        
        # Campos obrigatórios
        required_fields = ['include_in_documentation', 'save_prompt_history', 'analysis_questions']
        for field in required_fields:
            self.assertIn(field, prompts_config, f"Campo '{field}' não encontrado na seção prompts")
        
        # Verificar perguntas de análise
        questions = prompts_config['analysis_questions']
        self.assertIsInstance(questions, dict)
        
        # Verificar se tem a pergunta funcional obrigatória
        self.assertIn('functional', questions)
        functional_question = questions['functional']
        self.assertIn('question', functional_question)
        self.assertIn('priority', functional_question)
        self.assertIn('required', functional_question)
    
    def test_logging_section(self):
        """Testa a seção de logging."""
        with open(self.config_path, 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)
        
        logging_config = config['logging']
        
        # Campos obrigatórios
        required_fields = ['level', 'format', 'file']
        for field in required_fields:
            self.assertIn(field, logging_config, f"Campo '{field}' não encontrado na seção logging")
        
        # Verificar se o nível de log é válido
        valid_levels = ['DEBUG', 'INFO', 'WARNING', 'ERROR']
        self.assertIn(logging_config['level'], valid_levels)
    
    def test_output_section(self):
        """Testa a seção de output."""
        with open(self.config_path, 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)
        
        output_config = config['output']
        
        # Campos obrigatórios
        required_fields = ['default_format', 'enable_pdf', 'include_metadata']
        for field in required_fields:
            self.assertIn(field, output_config, f"Campo '{field}' não encontrado na seção output")
        
        # Verificar tipos
        self.assertIsInstance(output_config['enable_pdf'], bool)
        self.assertIsInstance(output_config['include_metadata'], bool)
    
    def test_config_manager_loads_unified_config(self):
        """Testa se o ConfigManager consegue carregar a configuração unificada."""
        try:
            config_manager = ConfigManager(self.config_path)
            config = config_manager.get_config()
            
            # Verificar se carregou corretamente
            self.assertIsInstance(config, dict)
            self.assertIn('ai', config)
            self.assertIn('prompts', config)
            
        except Exception as e:
            self.fail(f"ConfigManager falhou ao carregar configuração unificada: {e}")
    
    def test_primary_provider_is_valid(self):
        """Testa se o provedor primário configurado é válido."""
        with open(self.config_path, 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)
        
        primary_provider = config['ai']['primary_provider']
        available_providers = list(config['ai']['providers'].keys())
        
        self.assertIn(primary_provider, available_providers,
                     f"Provedor primário '{primary_provider}' não está na lista de provedores disponíveis")
    
    def test_fallback_providers_are_valid(self):
        """Testa se os provedores de fallback são válidos."""
        with open(self.config_path, 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)
        
        fallback_providers = config['ai']['fallback_providers']
        available_providers = list(config['ai']['providers'].keys())
        
        for provider in fallback_providers:
            self.assertIn(provider, available_providers,
                         f"Provedor de fallback '{provider}' não está na lista de provedores disponíveis")


def run_tests():
    """Executa todos os testes."""
    print("Executando testes de configuração unificada...")
    
    # Criar suite de testes
    suite = unittest.TestLoader().loadTestsFromTestCase(TestUnifiedConfig)
    
    # Executar testes
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    # Retornar resultado
    return result.wasSuccessful()


if __name__ == "__main__":
    success = run_tests()
    if success:
        print("\n Todos os testes de configuração passaram!")
        sys.exit(0)
    else:
        print("\n Alguns testes de configuração falharam!")
        sys.exit(1)

