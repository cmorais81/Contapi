#!/usr/bin/env python3
"""
COBOL AI Engine v2.0.0 - Documentation Generator
Gerador de documentação otimizado para clareza, rastreabilidade e usabilidade.
"""

import os
import json
import logging
from datetime import datetime
from typing import Dict, Any, Optional

from src.parsers.cobol_parser import CobolProgram
from src.providers.base_provider import AIResponse

class DocumentationGenerator:
    """Gerador de documentação focado em relatórios funcionais."""

    def __init__(self, output_dir: str = "output"):
        self.output_dir = output_dir
        self.logger = logging.getLogger(__name__)
        self.files_generated = 0
        self.total_programs = 0
        
        # Criar diretórios necessários
        os.makedirs(output_dir, exist_ok=True)
        
        # Diretório para JSONs das respostas
        self.json_dir = os.path.join(output_dir, "ai_responses")
        os.makedirs(self.json_dir, exist_ok=True)
        
        # Diretório para JSONs dos requests
        self.request_dir = os.path.join(output_dir, "ai_requests")
        os.makedirs(self.request_dir, exist_ok=True)

    def generate_program_documentation(self, program: CobolProgram, ai_response: AIResponse, phase_info: Optional[Dict[str, Any]] = None) -> str:
        """Gera a documentação funcional aprimorada para um programa."""
        try:
            # Salvar JSONs de auditoria
            self._save_ai_response_json(program, ai_response)
            self._save_ai_request_json(program, ai_response)
            
            # Gerar conteúdo do relatório
            content = self._generate_functional_report(program, ai_response)
            filename = f"{program.name}_analise_funcional.md"
            filepath = os.path.join(self.output_dir, filename)

            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)

            self.files_generated += 1
            self.total_programs += 1
            
            self.logger.info(f"Documentação funcional gerada: {filename}")
            return filepath
        except Exception as e:
            self.logger.error(f"Erro ao gerar documentação para {program.name}: {e}")
            raise

    def _generate_functional_report(self, program: CobolProgram, ai_response: AIResponse) -> str:
        """Gera o conteúdo do relatório funcional em Markdown."""
        # Extrair a análise da IA
        analysis_content = ai_response.content

        # Montar o cabeçalho do documento
        header = f"""# Análise Funcional do Programa: {program.name}

**Data da Análise:** {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}  
**Modelo de IA:** {ai_response.model}  
**Provedor:** {ai_response.provider}  

---
"""

        # Montar o corpo do documento com a análise da IA
        body = f"""## Análise Detalhada

{analysis_content}
"""

        # Montar a seção de transparência
        transparency = self._generate_transparency_section(program, ai_response)

        # Juntar tudo
        full_content = f"{header}\n{body}\n{transparency}"

        return full_content

    def _generate_transparency_section(self, program: CobolProgram, ai_response: AIResponse) -> str:
        """Gera a seção de transparência e auditoria."""
        prompts = getattr(ai_response, 'prompts_used', {})
        main_prompt = prompts.get('original_prompt', 'Prompt não disponível')
        system_prompt = prompts.get('system_prompt', 'Contexto não disponível')

        # Calcular estatísticas adicionais
        response_time = getattr(ai_response, 'response_time', 0)
        tokens_per_second = ai_response.tokens_used / response_time if response_time > 0 else 0
        
        # Determinar qualidade da resposta
        response_quality = "Excelente" if ai_response.tokens_used > 1000 else "Boa" if ai_response.tokens_used > 500 else "Básica"
        
        # Obter informações de trace/request ID se disponível
        trace_id = getattr(ai_response, 'trace_id', 'N/A')
        request_id = getattr(ai_response, 'request_id', 'N/A')

        return f"""---

## 🔍 TRANSPARÊNCIA E AUDITORIA DA ANÁLISE

> **IMPORTANTE:** Esta seção documenta completamente como a análise foi realizada, garantindo total transparência e rastreabilidade do processo.

---

### 🎯 RESUMO EXECUTIVO DA ANÁLISE

| **INDICADOR** | **VALOR** | **AVALIAÇÃO** |
|---------------|-----------|---------------|
| **Status Geral** | {'✅ ANÁLISE CONCLUÍDA COM SUCESSO' if ai_response.success else '❌ ANÁLISE FALHOU'} | {'Excelente' if ai_response.success else 'Requer Atenção'} |
| **Qualidade da Resposta** | {response_quality} | {len(ai_response.content):,} caracteres gerados |
| **Eficiência** | {tokens_per_second:.1f} tokens/seg | {'Rápida' if tokens_per_second > 50 else 'Normal' if tokens_per_second > 20 else 'Lenta'} |
| **Completude** | {ai_response.tokens_used:,} tokens | {'Análise Detalhada' if ai_response.tokens_used > 800 else 'Análise Padrão'} |

---

### 🤖 INFORMAÇÕES TÉCNICAS DO PROVIDER DE IA

#### **Provider e Modelo Utilizados**
```
🔧 PROVIDER: {ai_response.provider.upper()}
🧠 MODELO:   {ai_response.model}
📊 VERSÃO:   COBOL AI Engine v2.0.0
```

#### **Métricas de Performance**
| **Métrica** | **Valor** | **Observação** |
|-------------|-----------|----------------|
| **Tokens de Entrada** | {getattr(ai_response, 'prompt_tokens', 'N/A')} | Tamanho do prompt enviado |
| **Tokens de Saída** | {getattr(ai_response, 'completion_tokens', ai_response.tokens_used)} | Resposta gerada pela IA |
| **Total de Tokens** | {ai_response.tokens_used:,} | Consumo total da análise |
| **Tempo de Resposta** | {response_time:.2f} segundos | Latência da API |
| **Velocidade** | {tokens_per_second:.1f} tokens/seg | Taxa de geração |
| **Tamanho da Resposta** | {len(ai_response.content):,} caracteres | Volume de conteúdo gerado |

#### **Informações de Rastreabilidade**
| **Campo** | **Valor** |
|-----------|-----------|
| **Data/Hora da Análise** | {datetime.now().strftime('%d/%m/%Y às %H:%M:%S')} |
| **Trace ID** | `{trace_id}` |
| **Request ID** | `{request_id}` |
| **Status HTTP** | {getattr(ai_response, 'status_code', 'N/A')} |
| **Programa Analisado** | {program.name} |

---

### 📋 CONFIGURAÇÃO DA ANÁLISE

#### **Parâmetros do Modelo**
```yaml
Temperatura: {getattr(ai_response, 'temperature', 0.1)}
Max Tokens: {getattr(ai_response, 'max_tokens', 4000)}
Timeout: {getattr(ai_response, 'timeout', 120)}s
```

#### **Metodologia Aplicada**
- **Tipo de Análise:** Funcional Estruturada
- **Abordagem:** 9 Questões Específicas
- **Contexto:** Especialista COBOL Sênior
- **Foco:** Análise Técnica e de Negócio

---

### 🔍 DETALHES DO PROVIDER DE IA

**Provider:** {ai_response.provider}  
**Modelo:** {ai_response.model}  
**Status:** {'✅ Sucesso' if ai_response.success else '❌ Falha'}  
{f"**Erro:** {ai_response.error_message}" if not ai_response.success else "**Qualidade:** Análise completa e detalhada"}

---

### 🔬 METODOLOGIA DE ANÁLISE APLICADA

#### **Processo de Análise Estruturada**
A análise foi realizada utilizando **{ai_response.model}** via **{ai_response.provider}**, seguindo uma metodologia rigorosa:

1. **🧠 Análise Geral:** O modelo primeiro realiza uma análise holística do programa para entender seu propósito, fluxo e arquitetura
2. **📋 Questões Específicas:** Em seguida, aplica 9 questões estruturadas para extrair informações detalhadas
3. **🔍 Validação:** Verifica consistência e completude das informações extraídas
4. **📝 Documentação:** Gera relatório estruturado com insights técnicos e de negócio

#### **Configuração do Modelo de IA**
```yaml
Provider: {ai_response.provider}
Modelo: {ai_response.model}
Temperatura: {getattr(ai_response, 'temperature', 0.1)} (análise precisa)
Max Tokens: {getattr(ai_response, 'max_tokens', 4000)}
Timeout: {getattr(ai_response, 'timeout', 120)} segundos
```

---

### 📝 PROMPTS UTILIZADOS

<details>
<summary>🔽 Clique para expandir e ver os prompts completos enviados à IA</summary>

#### **Prompt do Sistema (Contexto):**
```
{system_prompt}
```

#### **Prompt Principal (Análise):**
```
{main_prompt}
```

</details>

---

### 📊 ESTATÍSTICAS DETALHADAS

#### **Consumo de Recursos**
- **Custo Estimado:** {ai_response.tokens_used * 0.000015:.4f} USD (baseado em preços médios)
- **Eficiência:** {tokens_per_second:.1f} tokens por segundo
- **Densidade:** {ai_response.tokens_used / len(ai_response.content) if len(ai_response.content) > 0 else 0:.2f} tokens por caractere

#### **Qualidade da Análise**
- **Profundidade:** {response_quality} ({ai_response.tokens_used:,} tokens gerados)
- **Completude:** {len(ai_response.content):,} caracteres de análise
- **Estruturação:** Seguiu metodologia de 9 questões específicas

---

### 📁 ARQUIVOS DE AUDITORIA GERADOS

Para garantir **transparência total** e **rastreabilidade completa**, os seguintes arquivos foram gerados:

| **Arquivo** | **Conteúdo** | **Finalidade** |
|-------------|--------------|----------------|
| **`ai_responses/{program.name}_response.json`** | Resposta completa da IA | Auditoria da análise gerada |
| **`ai_requests/{program.name}_request.json`** | Request enviado para a IA | Rastreabilidade do prompt |
| **`{program.name}_analise_funcional.md`** | Este relatório | Documentação final |

#### **Localização dos Arquivos**
```
output/
├── {program.name}_analise_funcional.md    # Relatório principal
├── ai_responses/
│   └── {program.name}_response.json       # Resposta da IA
└── ai_requests/
    └── {program.name}_request.json        # Request enviado
```

---

### ⚠️ LIMITAÇÕES E CONSIDERAÇÕES IMPORTANTES

#### **Sobre a Análise por IA**
- ✅ **Ponto de partida:** Excelente base para análise técnica
- ⚠️ **Validação humana:** Sempre recomendada para decisões críticas
- 📋 **Precisão:** Depende da qualidade e clareza do código fonte
- 🔍 **Contexto:** Limitado ao código fornecido (sem acesso a documentação externa)

#### **Recomendações de Uso**
1. **Use como base** para análise técnica inicial
2. **Valide com especialistas** antes de decisões críticas
3. **Consulte arquivos JSON** para detalhes técnicos completos
4. **Mantenha arquivos** para auditoria e rastreabilidade

---

### 🏆 CERTIFICAÇÃO DE QUALIDADE

**✅ ANÁLISE CERTIFICADA**
- Gerada por: **{ai_response.provider.upper()} - {ai_response.model}**
- Processada em: **{response_time:.2f} segundos**
- Qualidade: **{response_quality}** ({ai_response.tokens_used:,} tokens)
- Data: **{datetime.now().strftime('%d/%m/%Y às %H:%M:%S')}**

---

*Relatório gerado automaticamente pelo **COBOL AI Engine v2.0.0***  
*Sistema de análise inteligente para programas COBOL*
"""

    def _save_ai_response_json(self, program: CobolProgram, response: AIResponse) -> None:
        """Salva a resposta da IA em formato JSON para auditoria."""
        try:
            # Preparar dados da resposta
            response_data = {
                "program_name": program.name,
                "timestamp": datetime.now().isoformat(),
                "provider": response.provider,
                "model": response.model,
                "success": response.success,
                "tokens_used": response.tokens_used,
                "response_time": getattr(response, 'response_time', 0),
                "content": response.content,
                "error_message": response.error_message,
                "metadata": response.metadata,
                "pre_analysis": getattr(response, 'pre_analysis', {}),
                "prompts_used": getattr(response, 'prompts_used', {}),
                "quality_score": getattr(response, 'quality_score', 0),
                "analysis_depth": getattr(response, 'analysis_depth', 'standard')
            }
            
            # Salvar JSON
            json_filename = f"{program.name}_ai_response.json"
            json_filepath = os.path.join(self.json_dir, json_filename)
            
            with open(json_filepath, 'w', encoding='utf-8') as f:
                json.dump(response_data, f, indent=2, ensure_ascii=False, default=str)
            
            self.logger.info(f"JSON da resposta salvo: {json_filename}")
            
        except Exception as e:
            self.logger.error(f"Erro ao salvar JSON da resposta para {program.name}: {e}")
    
    def _save_ai_request_json(self, program: CobolProgram, response: AIResponse) -> None:
        """Salva o request enviado ao provedor em formato JSON para auditoria."""
        try:
            # Extrair dados do request dos metadados da resposta
            request_data = {
                "program_name": program.name,
                "timestamp": datetime.now().isoformat(),
                "provider": response.provider,
                "model": response.model,
                "request_payload": getattr(response, 'request_payload', {}),
                "prompts_sent": getattr(response, 'prompts_used', {}),
                "headers": getattr(response, 'request_headers', {}),
                "endpoint": getattr(response, 'endpoint_used', ''),
                "method": getattr(response, 'http_method', 'POST'),
                "request_size": len(str(getattr(response, 'request_payload', {}))),
                "configuration": {
                    "temperature": getattr(response, 'temperature', 0.1),
                    "max_tokens": getattr(response, 'max_tokens', 4000),
                    "timeout": getattr(response, 'timeout', 120)
                }
            }
            
            # Salvar JSON do request
            json_filename = f"{program.name}_ai_request.json"
            json_filepath = os.path.join(self.request_dir, json_filename)
            
            with open(json_filepath, 'w', encoding='utf-8') as f:
                json.dump(request_data, f, indent=2, ensure_ascii=False, default=str)
            
            self.logger.info(f"JSON do request salvo: {json_filename}")
            
        except Exception as e:
            self.logger.error(f"Erro ao salvar JSON do request para {program.name}: {e}")

    def get_generation_stats(self) -> Dict[str, Any]:
        """Retorna estatísticas de geração."""
        return {
            "files_generated": self.files_generated,
            "total_programs": self.total_programs,
            "output_directory": self.output_dir,
            "json_responses_dir": self.json_dir,
            "json_requests_dir": self.request_dir
        }
