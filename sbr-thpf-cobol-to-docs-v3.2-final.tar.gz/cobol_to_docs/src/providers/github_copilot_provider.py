"""
GitHub Copilot Provider - Integração com GitHub Copilot API
Fornece acesso aos modelos GPT-4o, o1-preview e o1-mini via GitHub Copilot
"""

import logging
import os
import time
import json
from typing import Dict, Any, Optional, List
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from cobol_to_docs.src.providers.base_provider import AIResponse, AIRequest

class GitHubCopilotProvider:
    """Provider para GitHub Copilot API."""
    
    def __init__(self, config: Dict[str, Any]):
        """
        Inicializa o provider GitHub Copilot.
        
        Args:
            config: Configuração do provider
        """
        self.logger = logging.getLogger(__name__)
        self.config = config
        self.name = "github_copilot"
        
        # Configurações de autenticação
        access_token_from_config = self.config.get('access_token')
        if isinstance(access_token_from_config, str) and access_token_from_config.startswith('${') and access_token_from_config.endswith('}'):
            env_var_name = access_token_from_config[2:-1]
            self.access_token = os.getenv(env_var_name)
        elif access_token_from_config:
            self.access_token = access_token_from_config
        else:
            self.access_token = os.getenv('GITHUB_TOKEN')
        self.logger.info(f"GitHubCopilotProvider: Loaded GITHUB_TOKEN: {self.access_token is not None}")
        
        # URLs e endpoints
        self.api_url = config.get('api_url', 'https://api.githubcopilot.com/chat/completions')
        
        # Configurações de conexão
        self.timeout = config.get('timeout', 120)
        self.verify_ssl = config.get('verify_ssl', True)
        
        # Modelos disponíveis
        self.models = config.get('models', {})
        
        # Configurações de retry
        retry_config = config.get('retry', {})
        self.max_attempts = retry_config.get('max_attempts', 3)
        self.retry_delay = retry_config.get('delay', 1)
        self.backoff_factor = retry_config.get('backoff_factor', 2)
        
        # Rate limiting
        rate_limit = config.get('rate_limit', {})
        self.requests_per_minute = rate_limit.get('requests_per_minute', 50)
        self.tokens_per_minute = rate_limit.get('tokens_per_minute', 80000)
        
        # Controle de rate limiting
        self.last_request_time = 0
        self.request_count = 0
        self.token_count = 0
        self.minute_start = time.time()
        
        # Configurar sessão HTTP
        self.session = requests.Session()
        self._setup_session()
        
        # Validar configuração
        self._validate_config()
        
        self.logger.info(f"GitHub Copilot Provider configurado: {len(self.models)} modelos disponíveis")
    
    def _setup_session(self):
        """Configura a sessão HTTP com retry e headers."""
        # Configurar retry strategy
        retry_strategy = Retry(
            total=self.max_attempts,
            backoff_factor=self.backoff_factor,
            status_forcelist=[429, 500, 502, 503, 504],
        )
        
        adapter = HTTPAdapter(max_retries=retry_strategy)
        self.session.mount("http://", adapter)
        self.session.mount("https://", adapter)
        
        # Headers padrão
        auth_header = f'Bearer {self.access_token}'
        self.logger.info(f"GitHubCopilotProvider: Authorization header: {auth_header[:15]}...")
        self.session.headers.update({
            'Authorization': auth_header,
            'Content-Type': 'application/json',
            'User-Agent': 'COBOL-Analyzer/3.1.0',
            'Accept': 'application/json'
        })
        
        # Configurar SSL
        self.session.verify = self.verify_ssl
    
    def _validate_config(self):
        """Valida a configuração do provider."""
        # A validação do token é feita no generate_response para permitir fallback.
        if not self.models:
            raise ValueError("Nenhum modelo configurado para GitHub Copilot")
        
        self.logger.info("Configuração do GitHub Copilot validada com sucesso")
    
    def _check_rate_limit(self, estimated_tokens: int = 1000):
        """Verifica e aplica rate limiting."""
        current_time = time.time()
        
        # Reset contador se passou 1 minuto
        if current_time - self.minute_start >= 60:
            self.request_count = 0
            self.token_count = 0
            self.minute_start = current_time
        
        # Verificar limites
        if self.request_count >= self.requests_per_minute:
            sleep_time = 60 - (current_time - self.minute_start)
            if sleep_time > 0:
                self.logger.warning(f"Rate limit atingido. Aguardando {sleep_time:.1f}s")
                time.sleep(sleep_time)
                self.request_count = 0
                self.token_count = 0
                self.minute_start = time.time()
        
        if self.token_count + estimated_tokens > self.tokens_per_minute:
            sleep_time = 60 - (current_time - self.minute_start)
            if sleep_time > 0:
                self.logger.warning(f"Token limit atingido. Aguardando {sleep_time:.1f}s")
                time.sleep(sleep_time)
                self.request_count = 0
                self.token_count = 0
                self.minute_start = time.time()
        
        # Delay mínimo entre requests
        time_since_last = current_time - self.last_request_time
        if time_since_last < 1.0:  # Mínimo 1 segundo entre requests
            time.sleep(1.0 - time_since_last)
        
        self.last_request_time = time.time()
    
    def _estimate_tokens(self, text: str) -> int:
        """Estima número de tokens no texto."""
        # Estimativa aproximada: 1 token ≈ 4 caracteres
        return len(text) // 4
    
    def generate_response(self, prompt: str, model: str = "gpt-4o", system_prompt: str = None, **kwargs) -> Dict[str, Any]:
        """
        Gera resposta usando GitHub Copilot API.
        
        Args:
            prompt: Prompt para o modelo
            model: Nome do modelo a usar
            **kwargs: Parâmetros adicionais
            
        Returns:
            Dict com resposta e metadados
        """
        try:
            # Verificar se o token de acesso está disponível
            if not self.access_token:
                raise Exception("Token GitHub ausente. Não é possível autenticar.")

            # Verificar se modelo existe
            # Normalizar o nome do modelo para corresponder às chaves do dicionário (que são gpt_4o, etc.)
            normalized_model = model.replace('-', '_')
            
            if normalized_model not in self.models:
                available_models = list(self.models.keys())
                raise ValueError(f"Modelo '{model}' não disponível. Modelos disponíveis: {available_models}")
            
            model_config = self.models[normalized_model]
            
            # Estimar tokens e aplicar rate limiting
            estimated_tokens = self._estimate_tokens(prompt)
            self._check_rate_limit(estimated_tokens)
            
            # Preparar payload
            messages = []
            if system_prompt:
                messages.append({"role": "system", "content": system_prompt})
            
            messages.append({"role": "user", "content": prompt})
            
            payload = {
                "model": model_config['name'],
                "messages": messages,
                "max_tokens": kwargs.get('max_tokens', model_config.get('max_tokens', 8192)),
                "temperature": kwargs.get('temperature', model_config.get('temperature', 0.1)),
                "stream": False
            }
            
            # Fazer requisição
            start_time = time.time()
            
            self.logger.info(f"Enviando requisição para GitHub Copilot - Modelo: {model}")
            
            response = self.session.post(
                self.api_url,
                json=payload,
                timeout=model_config.get('timeout', self.timeout)
            )
            
            response_time = time.time() - start_time
            
            # Verificar resposta
            if response.status_code == 401:
                raise Exception("Token GitHub inválido ou expirado")
            elif response.status_code == 403:
                raise Exception("Acesso negado. Verifique se tem acesso ao GitHub Copilot")
            elif response.status_code == 429:
                raise Exception("Rate limit excedido")
            elif response.status_code != 200:
                raise Exception(f"Erro HTTP {response.status_code}: {response.text}")
            
            # Processar resposta
            response_data = response.json()
            
            if 'choices' not in response_data or not response_data['choices']:
                raise Exception("Resposta inválida da API")
            
            content = response_data['choices'][0]['message']['content']
            
            # Atualizar contadores
            self.request_count += 1
            usage = response_data.get('usage', {})
            tokens_used = usage.get('total_tokens', estimated_tokens)
            self.token_count += tokens_used
            
            # Calcular custo (GitHub Copilot é gratuito para usuários elegíveis)
            cost = 0.0
            
            result = {
                'content': content,
                'model': model,
                'provider': self.name,
                'success': True,
                'response_time': response_time,
                'tokens_used': tokens_used,
                'cost': cost,
                'metadata': {
                    'model_name': model_config['name'],
                    'finish_reason': response_data['choices'][0].get('finish_reason'),
                    'usage': usage
                }
            }
            
            self.logger.info(f"Resposta recebida - Tokens: {tokens_used}, Tempo: {response_time:.2f}s")
            
            return result
            
        except Exception as e:
            self.logger.error(f"Erro na requisição GitHub Copilot: {e}")
            return {
                'content': f"Erro ao processar com GitHub Copilot: {str(e)}",
                'model': model,
                'provider': self.name,
                'success': False,
                'error': str(e),
                'response_time': 0,
                'tokens_used': 0,
                'cost': 0.0
            }
    
    def analyze(self, request: AIRequest) -> AIResponse:
        """
        Analisa o prompt usando o modelo especificado.
        
        Args:
            request: Objeto de requisição AIRequest
            
        Returns:
            AIResponse: Objeto de resposta da IA
        """
        
        # Extrair prompt e modelo do request
        self.logger.info(f"GitHubCopilotProvider.analyze: request.model = {request.model}")
        prompt = request.prompt
        model = request.model or self.config.get('default_model', 'gpt-4o')
        self.logger.info(f"GitHubCopilotProvider.analyze: model = {model}")
        
        # Extrair system prompt e kwargs do request.context
        system_prompt = request.context.get('system_prompt')
        kwargs = request.context or {}
        
        response = self.generate_response(prompt, model, system_prompt=system_prompt, **kwargs)
        
        # Criar AIResponse a partir do resultado
        
        # Adicionar prompts usados para auditoria
        prompts_used = {
            'full_prompt': prompt,
            'program_code': request.program_code,
            'program_name': request.program_name,
            'system_prompt': system_prompt
        }
        
        return AIResponse(
            success=response.get('success', False),
            content=response.get('content', ''),
            tokens_used=response.get('tokens_used', 0),
            prompt_tokens=response.get('metadata', {}).get('usage', {}).get('prompt_tokens', 0),
            completion_tokens=response.get('metadata', {}).get('usage', {}).get('completion_tokens', 0),
            model=response.get('model', request.model),
            provider=response.get('provider', self.name),
            response_time=response.get('response_time', 0),
            error_message=response.get('error', ''),
            prompts_used=prompts_used
        )

    def get_available_models(self) -> List[str]:
        """Retorna lista de modelos disponíveis."""
        return list(self.models.keys())
    
    def get_model_info(self, model: str) -> Dict[str, Any]:
        """Retorna informações sobre um modelo específico."""
        if model not in self.models:
            return {}
        
        model_config = self.models[model]
        return {
            'name': model_config['name'],
            'max_tokens': model_config.get('max_tokens', 8192),
            'context_window': model_config.get('context_window', 128000),
            'description': model_config.get('description', ''),
            'provider': self.name
        }
    
    def is_healthy(self) -> bool:
        """Verifica se o provider está funcionando."""
        try:
            # Fazer uma requisição simples para testar
            test_payload = {
                "model": "gpt-4o-mini",
                "messages": [{"role": "user", "content": "Hello"}],
                "max_tokens": 10
            }
            
            response = self.session.post(
                self.api_url,
                json=test_payload,
                timeout=10
            )
            
            return response.status_code == 200
            
        except Exception as e:
            self.logger.error(f"Health check falhou: {e}")
            return False
    
    def get_status(self) -> Dict[str, Any]:
        """Retorna status do provider."""
        return {
            'name': self.name,
            'healthy': self.is_healthy(),
            'models_count': len(self.models),
            'requests_this_minute': self.request_count,
            'tokens_this_minute': self.token_count,
            'rate_limits': {
                'requests_per_minute': self.requests_per_minute,
                'tokens_per_minute': self.tokens_per_minute
            }
        }
