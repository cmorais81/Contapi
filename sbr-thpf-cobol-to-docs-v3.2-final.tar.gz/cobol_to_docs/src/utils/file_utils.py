import os
from pathlib import Path

def resolve_file_path(base_path: Path, file_name: str) -> Path:
    """
    Resolve o caminho completo para um arquivo, procurando recursivamente
    a partir de um caminho base.
    """
    # 1. Tenta resolver o caminho diretamente
    full_path = base_path / file_name
    if full_path.exists():
        return full_path
        
    # 2. Procura recursivamente
    for root, _, files in os.walk(base_path):
        if file_name in files:
            return Path(root) / file_name
            
    # 3. Tenta caminhos relativos
    for root, _, files in os.walk('.'):
        if file_name in files:
            return Path(root) / file_name
            
    return None

def resolve_file_path_case_insensitive(base_path: Path, file_name: str) -> Path:
    """
    Resolve o caminho completo para um arquivo, procurando recursivamente
    a partir de um caminho base, ignorando a caixa.
    """
    file_name_upper = file_name.upper()
    for root, _, files in os.walk(base_path):
        for f in files:
            if f.upper() == file_name_upper:
                return Path(root) / f
    return None

