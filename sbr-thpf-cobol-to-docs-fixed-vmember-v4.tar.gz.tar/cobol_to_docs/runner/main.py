
'''
COBOL to Docs v1.0 - Sistema de Análise e Documentação de Programas COBOL
Autor: Carlos Morais
Data: Setembro 2025

Sistema completo para análise automatizada de programas COBOL com geração
de documentação técnica profissional usando IA.

FUNCIONALIDADE COMPLETA RESTAURADA:
- Processamento de múltiplos programas COBOL
- Suporte a múltiplos modelos de IA
- Análise de copybooks complementares
- Geração de relatórios comparativos
- Detecção automática de código COBOL
'''

import argparse
import logging
import os
import sys
import json
import time
import re
import shutil
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple

# Adicionar o diretório raiz do projeto ao sys.path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from cobol_to_docs.src.core.config import ConfigManager
from cobol_to_docs.src.core.prompt_manager_dual import DualPromptManager
from cobol_to_docs.src.providers.enhanced_provider_manager import EnhancedProviderManager
from cobol_to_docs.src.parsers.cobol_parser import COBOLParser, CobolProgram, CobolBook
from cobol_to_docs.src.analyzers.enhanced_cobol_analyzer import EnhancedCOBOLAnalyzer
from cobol_to_docs.src.analyzers.consolidated_analyzer import ConsolidatedAnalyzer
from cobol_to_docs.src.generators.documentation_generator import DocumentationGenerator
from cobol_to_docs.src.utils.html_generator import HTMLReportGenerator
from cobol_to_docs.src.utils.cost_calculator import CostCalculator
from cobol_to_docs.src.rag.rag_integration import RAGIntegration
from cobol_to_docs.src.core.intelligent_model_selector import IntelligentModelSelector
from cobol_to_docs.src.utils.cobol_preprocessor import COBOLPreprocessor
from cobol_to_docs.src.analytics.consolidated_analysis import (
    process_advanced_consolidated_analysis,
    process_detailed_business_analysis
)

def resolve_file_path(file_path: str) -> str:
    """Resolve um caminho de arquivo, tratando-o como absoluto se não for relativo ao diretório atual."""
    if os.path.isabs(file_path):
        return file_path
    return os.path.abspath(file_path)

def setup_logging(log_level: str = "INFO") -> None:
    """Configura o sistema de logging."""
    log_dir = "logs"
    os.makedirs(log_dir, exist_ok=True)
    
    timestamp_str = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_file = os.path.join(log_dir, f"cobol_to_docs_{timestamp_str}.log") 
    logging.basicConfig(
        level=getattr(logging, log_level.upper()),
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        handlers=[
            logging.FileHandler(log_file, encoding="utf-8"),
            logging.StreamHandler(sys.stdout)
        ]
    )

def display_status(config_manager: ConfigManager) -> None:
    """Exibe o status dos provedores e modelos de IA configurados."""
    logger = logging.getLogger(__name__)
    config = config_manager.get_config()
    ai_config = config.get('ai', {})
    
    print("\n--- Status dos Provedores de IA ---")
    
    primary_provider = ai_config.get('primary_provider', 'N/A')
    print(f"Provedor Primário: {primary_provider}")
    
    fallback_providers = ai_config.get('fallback_providers', [])
    print(f"Provedores de Fallback: {', '.join(fallback_providers)}")
    
    providers = ai_config.get('providers', {})
    
    for name, provider_config in providers.items():
        enabled = provider_config.get('enabled', False)
        status = "ATIVO" if enabled else "INATIVO"
        print(f"\nProvedor: {name} ({status})")
        
        models = provider_config.get('models', {})
        if models:
            print("  Modelos:")
            for model_name, model_config in models.items():
                is_default = model_config.get('default', False)
                default_tag = " (PADRÃO)" if is_default else ""
                print(f"    - {model_name}{default_tag}: {model_config.get('description', 'Sem descrição')}")
        else:
            print("  Nenhum modelo configurado.")

    print("\n--- Fim do Status ---")

def parse_models_argument(models_str: str) -> List[str]:
    """Parse do argumento models que pode ser string ou lista JSON."""
    if not models_str:
        return []
    
    models_str = models_str.strip()
    
    if models_str.startswith("["):
        try:
            models = json.loads(models_str)
            return models if isinstance(models, list) else [models]
        except json.JSONDecodeError:
            print(f"Erro: Formato JSON inválido para models: {models_str}")
            sys.exit(1)
    else:
        return [models_str]

def analyze_program_with_model(program: CobolProgram, books: List[CobolBook], model: str, output_dir: str, config_manager: ConfigManager, is_multi_model: bool, prompt_set: str, cost_calculator: CostCalculator, rag_integration=None, args=None, jcl_content: Optional[str] = None, all_copybook_contents: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
    """Analisa um programa COBOL com um modelo específico."""
    logger = logging.getLogger(__name__)
    
    if is_multi_model:
        model_name_sanitized = model.replace("/", "_").replace("-", "_")
        model_output_dir = os.path.join(output_dir, "model_" + model_name_sanitized)
        os.makedirs(model_output_dir, exist_ok=True)
    else:
        model_output_dir = output_dir
    
    try:
        provider_manager = EnhancedProviderManager(config_manager.get_config())
        prompts_path = Path(__file__).resolve().parents[2] / "config" / "prompts"
        prompt_manager = DualPromptManager(config_manager.config, prompt_set, custom_prompts_file=args.custom_prompt_file, prompts_dir=prompts_path)
        doc_generator = DocumentationGenerator(model_output_dir)
        analyzer = EnhancedCOBOLAnalyzer(provider_manager, prompt_manager, rag_integration)
    
        if args:
            from cobol_to_docs.src.utils.cobol_preprocessor import COBOLPreprocessor
            preprocessor = COBOLPreprocessor()
            
            has_many_comments = preprocessor.has_comments(program.content)
            no_comments_arg = getattr(args, "no_comments", False)
            logger.info(f"Verificando comentários em {program.name}: no_comments={no_comments_arg}, has_many_comments={has_many_comments}")
            
            if hasattr(args, "no_comments") and (args.no_comments or has_many_comments):
                if args.no_comments:
                    logger.info(f"Remoção de comentários solicitada para {program.name}")
                else:
                    logger.info(f"Muitos comentários detectados em {program.name} - removendo para análise focada")
                
                original_content = program.content
                program.content, removed_comments = preprocessor.remove_comments(program.content)
                logger.info(f"Removidos {removed_comments} comentários de {program.name}")
            else:
                logger.info(f"Mantendo comentários em {program.name}")
        
        start_time = time.time()
        
        logger.info(f"*** PROVIDER SELECIONADO: {model} ***")
        logger.info(f"Iniciando análise de {program.name} com provider {model}")
        
        # O modelo deve ser passado para o analyzer.analyze_program
        # O `model` que chega aqui é o nome do modelo (ex: aws-claude-3-5-sonnet)
        # O EnhancedCOBOLAnalyzer deve usar o EnhancedProviderManager para resolver o provider
        analysis_result = analyzer.analyze_program(program, model, books=books, jcl_content=jcl_content, all_copybook_contents=all_copybook_contents)
        analysis_time = time.time() - start_time
        
        provider_usado = getattr(analysis_result, "provider_used", model)
        logger.info(f"*** ANÁLISE CONCLUÍDA COM PROVIDER: {provider_usado} ***")
        
        if not analysis_result.success:
            error_msg = f"ERRO na análise de {program.name} com modelo {model}: {analysis_result.error_message}"
            logger.error(error_msg)
            print(f"\n {error_msg}")
            print(f"   Programa: {program.name}")
            print(f"   Modelo solicitado: {model}")
            print(f"   Tempo decorrido: {analysis_time:.2f}s")
            print(f"   Detalhes do erro: {analysis_result.error_message}")
            return {
                "success": False,
                "program_name": program.name,
                "model": model,
                "error": analysis_result.error_message,
                "tokens_used": 0,
                "analysis_time": analysis_time,
                "output_dir": model_output_dir
            }
        
        cost_info = cost_calculator.tokens_analytics(
            {"usage": [{"total_tokens": analysis_result.tokens_used}]},
            analysis_result.model_used
        )
        
        from cobol_to_docs.src.providers.base_provider import AIResponse
        
        prompts_used = {
            "system_prompt": prompt_manager.get_system_prompt(),
            "original_prompt": getattr(analysis_result, "original_prompt", "Prompt gerado dinamicamente"),
            "main_prompt": getattr(analysis_result, "prompt_used", "Prompt principal não disponível")
        }
        
        ai_response = AIResponse(
            success=True,
            content=analysis_result.content,
            tokens_used=analysis_result.tokens_used,
            model=analysis_result.model_used,
            provider=getattr(analysis_result, "provider_used", "enhanced_mock"),
            prompts_used=prompts_used,
            response_time=analysis_time
        )
        
        doc_result = doc_generator.generate_program_documentation(program, ai_response)
        
        logger.info(f"Análise de {program.name} com {model} bem-sucedida.")
        logger.info(f"Tokens utilizados: {analysis_result.tokens_used:,}")
        logger.info(f"Custo: ${cost_info['cost']:.4f}")
        logger.info(f"Modelo utilizado: {analysis_result.model_used}")
        
        if rag_integration and hasattr(rag_integration, "add_program_analysis_to_knowledge_base"):
            try:
                rag_integration.add_program_analysis_to_knowledge_base(
                    program.name,
                    analysis_result.content,
                    program.content
                )
                logger.info(f"Auto-learning: Conhecimento do programa {program.name} adicionado à base RAG")
            except Exception as e:
                logger.warning(f"Auto-learning falhou para {program.name}: {e}")
        
        return {
            "success": True,
            "program_name": program.name,
            "model": model,
            "tokens_used": analysis_result.tokens_used,
            "analysis_time": analysis_time,
            "output_dir": model_output_dir,
            "files_generated": [doc_result] if doc_result else [],
            "response": analysis_result
        }
        
    except Exception as e:
        logger.error(f"Erro na análise de {program.name} com modelo {model}: {str(e)}")
        return {
            "success": False,
            "program_name": program.name,
            "model": model,
            "error": str(e),
            "tokens_used": 0,
            "analysis_time": 0,
            "output_dir": model_output_dir
        }

def is_vmember_file(file_path: str) -> bool:
    """Verifica se o arquivo de entrada tem o formato V-MEMBER (código-fonte completo)."""
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            for _ in range(10):
                line = f.readline()
                if re.match(r'^\s*VMEMBER\s+NAME\s+[A-Z0-9]+', line, re.IGNORECASE):
                    return True
    except Exception:
        pass
    return False

def process_programs(program_paths: List[str], books_paths: List[str], output_dir: str, models: List[str], prompt_set: str, config_manager: ConfigManager, args: argparse.Namespace, jcl_content: Optional[str] = None, cobol_parser: COBOLParser = None, base_search_dir: str = os.getcwd()) -> Tuple[List[Dict[str, Any]], List[CobolProgram]]:
    logger = logging.getLogger(__name__)
    all_results = []
    rag_integration = RAGIntegration(config_manager.get_config()) if args.rag_enabled else None
    cost_calculator = CostCalculator(config_manager.get_ai_config().get("api_costs"))
    parsed_programs: List[CobolProgram] = []
    parsed_books: List[CobolBook] = []

    # Processar copybooks primeiro
    all_copybook_paths: List[str] = []
    for b_path in books_paths:
        resolved_path = resolve_file_path(b_path)
        if not os.path.exists(resolved_path):
            logger.error(f"Arquivo de books não encontrado: {resolved_path}")
            continue
        
        try:
            # Se for um arquivo de lista de books (o que o usuário espera)
            if os.path.isfile(resolved_path):
                with open(resolved_path, 'r') as f:
                    file_contents = f.read().splitlines()
                
                base_dir = os.path.dirname(resolved_path)
                
                for line in file_contents:
                    line = line.strip()
                    if not line or line.startswith('#'):
                        continue
                    
                    program_or_book_path = os.path.join(base_search_dir, line)
                    all_program_files.append(program_or_book_path)
            
            # Se for um diretório de copybooks
            elif os.path.isdir(resolved_path):
                base_dir = resolved_path
                for root, _, files in os.walk(base_dir):
                    for file in files:
                        if file.endswith(('.cbl', '.cpy', '.cob')):
                            all_copybook_paths.append(os.path.join(root, file))
            
        except Exception as e:
            logger.error(f"Erro ao processar o arquivo/diretório de books {resolved_path}: {e}")

    # Parsear todos os copybooks coletados
    for book_path in all_copybook_paths:
        if not os.path.exists(book_path):
            logger.error(f"Copybook não encontrado: {book_path}")
            continue
        
        try:
            # Passa o diretório do copybook como base_path para o parser
            base_dir = os.path.dirname(book_path)
            programs_in_file, books_in_file = cobol_parser.parse_file(book_path, base_path=base_dir)
            parsed_books.extend(books_in_file)
        except Exception as e:
            logger.error(f"Erro ao processar o copybook {book_path}: {e}")

    # Processar programas
    all_program_files: List[str] = []
    for p_path in program_paths:
        resolved_path = resolve_file_path(p_path)
        if not os.path.exists(resolved_path):
            logger.error(f"Arquivo de fontes não encontrado: {resolved_path}")
            continue
        
        try:
            # O resolved_path é o fontes.txt
            with open(resolved_path, 'r') as f:
                file_contents = f.read().splitlines()
            
            # O base_search_dir já foi definido no main() e aponta para o diretório temporário
            # se o pré-processamento foi executado.
            
            for line in file_contents:
                line = line.strip()
                if not line or line.startswith('#'):
                    continue
                
                # Usamos o base_search_dir para resolver o caminho, que é o diretório temporário
                # se o pré-processamento foi executado.
                program_file_path = os.path.join(base_search_dir, line)
                
                # O problema era que o all_program_files estava sendo sobrescrito a cada iteração
                # do loop de arquivos de fontes.txt. O correto é apenas adicionar.
                all_program_files.append(program_file_path)

        except Exception as e:
            logger.error(f"Erro ao processar o arquivo {resolved_path}: {e}")

    # Parsear todos os programas coletados
    logger.info(f"Programas a serem processados: {all_program_files}")

    # Parsear todos os programas coletados
    for program_file_path in all_program_files:
        if not os.path.exists(program_file_path):
            logger.error(f"Arquivo COBOL não encontrado: {program_file_path}")
            continue
        
        try:
            # Passa o diretório do programa como base_path para o parser
            base_dir = os.path.dirname(program_file_path)
            
            # O cobol_parser.parse_file já retorna a lista de programas encontrados no arquivo.
            # No caso de um arquivo V-MEMBER, all_program_files é a lista de arquivos extraídos.
            programs_in_file, _ = cobol_parser.parse_file(program_file_path, base_path=base_dir)
            
            # Adiciona um log para cada programa parseado
            for program in programs_in_file:
                logger.info(f"Programa parseado: {program.name}")
                
            parsed_programs.extend(programs_in_file)
        except Exception as e:
            logger.error(f"Erro ao processar o arquivo COBOL {program_file_path}: {e}")

    logger.info(f"Programas parseados com sucesso: {[p.name for p in parsed_programs]}")

    if not parsed_programs:
        logger.warning("Nenhum programa COBOL válido encontrado para análise.")
        return [], []

    is_multi_model = len(models) > 1
    all_copybook_contents = {b.name.upper(): b.content for b in parsed_books}

    for program in parsed_programs:
        for model in models:
            result = analyze_program_with_model(
                program, parsed_books, model, output_dir, config_manager, 
                is_multi_model, prompt_set, cost_calculator, rag_integration, 
                args, jcl_content=jcl_content, all_copybook_contents=all_copybook_contents
            )
            all_results.append(result)

    return all_results, parsed_programs

def generate_comparative_report(programs: List[CobolProgram], all_results: List[Dict[str, Any]], output_dir: str) -> None:
    logger = logging.getLogger(__name__)
    try:
        report_path = os.path.join(output_dir, "relatorio_comparativo_modelos.md")
        models_used = sorted(list(set(r["model"] for r in all_results)))
        with open(report_path, "w", encoding="utf-8") as f:
            f.write("# Relatório Comparativo de Modelos\n\n")
            f.write("**Data:** " + datetime.now().strftime("%d/%m/%Y %H:%M:%S") + "\n")
            f.write(f"**Programas Analisados:** {len(programs)}\n")
            f.write(f"**Modelos Utilizados:** {len(models_used)}\n\n")
            for model_name in models_used:
                results = [r for r in all_results if r["model"] == model_name]
                f.write(f"## Modelo: {model_name}\n\n")
                f.write("| Programa | Status | Tempo (s) | Tokens |\n")
                f.write("|----------|--------|-----------|--------|\n")
                for res in results:
                    status = "Sucesso" if res["success"] else "Falha"
                    f.write(f"| {res['program_name']} | {status} | {res['analysis_time']:.2f} | {res['tokens_used']:,} |\n")
                f.write("\n")
        logger.info(f"Relatório comparativo gerado em: {report_path}")
    except Exception as e:
        logger.error(f"Erro ao gerar relatório comparativo: {e}")

def is_vmember_file(file_path: str) -> bool:
    """Verifica se o arquivo de entrada tem o formato V-MEMBER (código-fonte completo)."""
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            for _ in range(10):
                line = f.readline()
                if re.match(r'^\s*VMEMBER\s+NAME\s+[A-Z0-9]+', line, re.IGNORECASE):
                    return True
    except Exception:
        pass
    return False



def is_vmember_file(file_path: str) -> bool:
    """Verifica se o arquivo está no formato V-MEMBER NAME (mais robusto)."""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            # Verifica se o padrão V-MEMBER NAME aparece nas primeiras 10 linhas
            for _ in range(10):
                line = f.readline()
                if not line:
                    break
                if line.strip().startswith('VMEMBER NAME '):
                    return True
            return False
    except Exception:
        return False

def main():
    print("DEBUG: main function started")
    print("DEBUG: Parsing arguments...")
    parser = argparse.ArgumentParser(description="COBOL to Docs - Análise e Documentação de Programas COBOL com IA.")
    parser.add_argument("--fontes", type=str, help="Caminho para um arquivo de texto contendo uma lista de caminhos para programas COBOL.")


    parser.add_argument("--output", type=str, default="output", help="Diretório para salvar os resultados.")
    parser.add_argument("--models", type=str, default="aws-claude-3-5-sonnet", help="Modelos de IA a serem usados.")
    parser.add_argument("--prompt-set", type=str, default="default", help="Conjunto de prompts a ser utilizado.")
    parser.add_argument("--custom-prompt-file", type=str, help="Caminho para um arquivo JSON com prompts customizados.")
    parser.add_argument("--log-level", type=str, default="INFO", help="Nível de log.")
    parser.add_argument("--config-path", type=str, help="Caminho para o arquivo de configuração (config.yaml).")
    parser.add_argument("--jcl-path", type=str, help="Caminho para um arquivo JCL associado.")
    parser.add_argument("--books", type=str, help="Caminho para um arquivo de texto contendo uma lista de caminhos para copybooks, ou diretórios separados por vírgula.")
    parser.add_argument("--pdf", action="store_true", help="Gera o relatório final em formato PDF.")
    parser.add_argument("--rag-enabled", action="store_true", help="Ativa a integração com RAG.")
    parser.add_argument("--status", action="store_true", help="Exibe o status dos provedores e modelos de IA configurados.")
    
    args = parser.parse_args()

    setup_logging(args.log_level)
    logger = logging.getLogger(__name__)

    # O caminho correto é parents[1] para chegar em cobol_to_docs/runner, parents[2] para cobol_to_docs, e depois config/config.yaml
    # Se o main.py estiver em cobol_to_docs/runner/main.py, o parents[2] é o diretório pai de cobol_to_docs
    # O correto é parents[1] para cobol_to_docs/runner, parents[2] para cobol_to_docs, e depois config/config.yaml
    # Vamos usar o caminho absoluto do main.py e navegar até o config.yaml
    main_dir = Path(__file__).resolve().parent
    cobol_to_docs_dir = main_dir.parent
    default_config_path = cobol_to_docs_dir / "config" / "config.yaml"
    
    config_path = resolve_file_path(args.config_path) if args.config_path else default_config_path
    config_manager = ConfigManager(config_path=config_path)

    cobol_preprocessor = COBOLPreprocessor()
    temp_dir = None
    base_search_dir = os.getcwd()

    # --- Pré-processamento de Arquivos V-MEMBER (fontes.txt/BOOKS.txt) ---
    is_vmember_input = False
    if args.fontes and os.path.exists(args.fontes) and is_vmember_file(args.fontes):
        is_vmember_input = True
    elif args.books and os.path.exists(args.books) and is_vmember_file(args.books):
        is_vmember_input = True

    if is_vmember_input:
        logger.info("Arquivos de entrada detectados como V-MEMBER (contêm código-fonte). Iniciando pré-processamento...")
        temp_dir = os.path.join(os.getcwd(), "temp_cobol_members")
        
        if os.path.exists(temp_dir):
            shutil.rmtree(temp_dir)
        os.makedirs(temp_dir, exist_ok=True)
        os.makedirs(os.path.join(temp_dir, 'programs'), exist_ok=True)
        os.makedirs(os.path.join(temp_dir, 'copybooks'), exist_ok=True)
        
        cobol_preprocessor.parse_vmember_files(args.fontes, args.books, temp_dir)
        
        new_fontes_path = os.path.join(temp_dir, "new_fontes.txt")
        new_books_path = os.path.join(temp_dir, "new_books.txt")
        
        with open(new_fontes_path, 'w') as f:
            for filename in os.listdir(os.path.join(temp_dir, 'programs')):
                f.write(f'programs/{filename}\n')

        with open(new_books_path, 'w') as f:
            for filename in os.listdir(os.path.join(temp_dir, 'copybooks')):
                f.write(f'copybooks/{filename}\n')
        
        args.fontes = new_fontes_path
        args.books = new_books_path
        
        base_search_dir = temp_dir
        logger.info(f"Pré-processamento concluído. Usando arquivos de lista e membros em: {temp_dir}")
    else:
        logger.info("Arquivos de entrada detectados como lista de nomes. Pulando pré-processamento.")
        base_search_dir = os.getcwd()
    temp_dir = None
    base_search_dir = os.getcwd()

    # --- Pré-processamento de Arquivos V-MEMBER (fontes.txt/BOOKS.txt) ---
    is_vmember_input = False
    if args.fontes and os.path.exists(args.fontes) and is_vmember_file(args.fontes):
        is_vmember_input = True
    elif args.books and os.path.exists(args.books) and is_vmember_file(args.books):
        is_vmember_input = True

    if is_vmember_input:
        logger.info("Arquivos de entrada detectados como V-MEMBER (contêm código-fonte). Iniciando pré-processamento...")
        temp_dir = os.path.join(os.getcwd(), "temp_cobol_members")
        
        if os.path.exists(temp_dir):
            shutil.rmtree(temp_dir)
        os.makedirs(temp_dir, exist_ok=True)
        os.makedirs(os.path.join(temp_dir, 'programs'), exist_ok=True)
        os.makedirs(os.path.join(temp_dir, 'copybooks'), exist_ok=True)
        
        cobol_preprocessor.parse_vmember_files(args.fontes, args.books, temp_dir)
        
        new_fontes_path = os.path.join(temp_dir, "new_fontes.txt")
        new_books_path = os.path.join(temp_dir, "new_books.txt")
        
        with open(new_fontes_path, 'w') as f:
            for filename in os.listdir(os.path.join(temp_dir, 'programs')):
                f.write(f'programs/{filename}\n')

        with open(new_books_path, 'w') as f:
            for filename in os.listdir(os.path.join(temp_dir, 'copybooks')):
                f.write(f'copybooks/{filename}\n')
        
        args.fontes = new_fontes_path
        args.books = new_books_path
        
        base_search_dir = temp_dir
        logger.info(f"Pré-processamento concluído. Usando arquivos de lista e membros em: {temp_dir}")
    else:
        logger.info("Arquivos de entrada detectados como lista de nomes. Pulando pré-processamento.")
        base_search_dir = os.getcwd()

    # Lógica para o comando --status
    if args.status:
        display_status(config_manager)
        sys.exit(0)

    output_dir = args.output
    os.makedirs(output_dir, exist_ok=True)

    # Inicializa o ProviderManager para obter a lista de modelos configurados
    provider_manager = EnhancedProviderManager(config_manager.get_config())
    available_models = list(provider_manager.model_configurations.keys())
    
    if not available_models:
        logger.error("Nenhum modelo de IA configurado ou disponível. Verifique o arquivo de configuração.")
        sys.exit(1)
    
    models_to_use = []
    
    # Se o usuário especificou modelos, usa a lista do usuário.
    if args.models:
        user_models = parse_models_argument(args.models)
        models_to_use = [m for m in available_models if m in user_models]
        if not models_to_use:
            logger.error(f"Nenhum dos modelos especificados ({args.models}) está configurado ou disponível.")
            sys.exit(1)
    else:
        # Se o usuário não especificou modelos, usa o modelo padrão.
        default_model = config_manager.get_ai_config().get("default_model", "aws-claude-3-5-sonnet")
        if default_model in available_models:
            models_to_use = [default_model]
        else:
            # Fallback para o primeiro modelo disponível se o padrão não estiver configurado
            models_to_use = [available_models[0]]
            logger.warning(f"Modelo padrão '{default_model}' não está configurado. Usando o primeiro modelo disponível: {models_to_use[0]}")

    program_paths = []
    
    if args.fontes:
        fontes_path = resolve_file_path(args.fontes)
        if not os.path.exists(fontes_path):
            logger.error(f"Arquivo de fontes não encontrado: {fontes_path}")
            sys.exit(1)
        
        # Se for um arquivo, lê a lista de caminhos de programa
        if os.path.isfile(fontes_path):
            # Se o arquivo for V-MEMBER, ele será tratado no pré-processamento.
            # Se não for V-MEMBER, ele é uma lista de caminhos de programa.
            if is_vmember_file(fontes_path):
                # Se for V-MEMBER, o pré-processamento fará o trabalho.
                # Apenas adiciona o caminho do arquivo V-MEMBER para o pré-processamento.
                program_paths = [fontes_path]
            else:
                # Se for um arquivo de lista normal, lê os caminhos.
                with open(fontes_path, 'r', encoding='utf-8') as f:
                    program_paths = [resolve_file_path(line.strip()) for line in f if line.strip()]
        else:
            # Se não for um arquivo, assume que é um único caminho de programa
            program_paths = [fontes_path]

    if not program_paths:
        logger.error("Nenhum arquivo de programa COBOL ou arquivo de lista de fontes fornecido.")
        sys.exit(1)
    
    copybook_dirs = []
    if args.books:
        books_path = resolve_file_path(args.books)
        if os.path.isfile(books_path):
            # Se for um arquivo, lê a lista de diretórios/arquivos
            with open(books_path, 'r', encoding='utf-8') as f:
                copybook_dirs = [resolve_file_path(line.strip()) for line in f if line.strip()]
        else:
            # Se não for um arquivo, assume que é uma lista de diretórios separados por vírgula
            copybook_dirs = [resolve_file_path(d.strip()) for d in args.books.split(",")]
    
    jcl_content = None
    if args.jcl_path:
        jcl_path = resolve_file_path(args.jcl_path)
        try:
            with open(jcl_path, "r", encoding="utf-8") as f:
                jcl_content = f.read()
        except FileNotFoundError:
            logger.warning(f"Arquivo JCL não encontrado: {jcl_path}")
            jcl_content = None

    cobol_parser = COBOLParser()
    all_results, parsed_programs = process_programs(program_paths, copybook_dirs, output_dir, models_to_use, args.prompt_set, config_manager, args, jcl_content, cobol_parser, base_search_dir)

    # Limpeza do diretório temporário
    if temp_dir and os.path.exists(temp_dir):
        shutil.rmtree(temp_dir)

    # ... (restante da função main)
    pass # O restante da função main é mantidogging.shutdown()

    if len(models_to_use) > 1 and parsed_programs:
        generate_comparative_report(parsed_programs, all_results, output_dir)

    print("DEBUG: Processing complete.")
    logger.info("Processamento concluído.")
    print("DEBUG: main function finished")

if __name__ == "__main__":
    main()

