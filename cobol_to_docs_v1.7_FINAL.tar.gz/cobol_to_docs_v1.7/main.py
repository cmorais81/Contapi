#!/usr/bin/env python3
"""
COBOL to Docs v1.6 - Sistema Integrado de Análise e Documentação COBOL
Sistema completo com todas as funcionalidades integradas seguindo princípios SOLID.

Funcionalidades Integradas:
- Análise COBOL com múltiplos providers
- Geração de prompts adaptativa
- Processamento avançado consolidado
- Sistema RAG com aprendizado automático
- Análise de códigos técnicos
- Validação anti-alucinação
- Cache inteligente e processamento paralelo
- Relatórios consolidados e individuais
"""

import argparse
import logging
import os
import sys
import json
import time
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple
from concurrent.futures import ThreadPoolExecutor, as_completed

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

# Imports core
from src.core.config import ConfigManager
from src.core.prompt_manager_dual import DualPromptManager
from src.providers.provider_manager import ProviderManager
from src.parsers.cobol_parser_original import COBOLParser, CobolProgram, CobolBook
from src.analyzers.enhanced_cobol_analyzer import EnhancedCOBOLAnalyzer
from src.generators.documentation_generator import DocumentationGenerator
from src.utils.cost_calculator import CostCalculator
from src.rag.rag_integration import RAGIntegration

# Imports funcionalidades avançadas
from src.core.adaptive_prompt_generator import AdaptivePromptGenerator
from src.analyzers.technical_code_analyzer import TechnicalCodeAnalyzer
from src.utils.technical_code_integration import integrate_technical_code_analysis
from src.utils.hallucination_validator import HallucinationValidator
from src.utils.intelligent_cache import IntelligentCache
from src.utils.parallel_processor import ParallelProcessor
from src.generators.advanced_report_generator import AdvancedReportGenerator

# Imports ferramentas
from tools.generate_prompt_yaml import generate_prompt_yaml
from tools.cobol_to_json import convert_cobol_to_json
from tools.extract_business_rules import extract_business_rules


class IntegratedCOBOLAnalyzer:
    """
    Analisador COBOL integrado com todas as funcionalidades avançadas.
    Segue princípios SOLID para máxima extensibilidade e manutenibilidade.
    """
    
    def __init__(self, config_path: str = "config/config.yaml"):
        """Inicializa o analisador integrado."""
        self.logger = logging.getLogger(__name__)
        
        # Componentes core
        self.config_manager = ConfigManager(config_path)
        self.provider_manager = ProviderManager(self.config_manager.config)
        self.rag_integration = RAGIntegration(self.config_manager.config)
        
        # Componentes avançados
        self.cache = IntelligentCache()
        self.parallel_processor = ParallelProcessor()
        self.hallucination_validator = HallucinationValidator()
        self.technical_analyzer = TechnicalCodeAnalyzer()
        # Função de integração técnica disponível via import
        
        # Estatísticas
        self.statistics = {
            'total_programs': 0,
            'successful_analyses': 0,
            'failed_analyses': 0,
            'total_tokens': 0,
            'total_time': 0.0,
            'cache_hits': 0,
            'rag_enhancements': 0
        }
        
        self.logger.info("Sistema COBOL to Docs v1.6 inicializado com todas as funcionalidades")
    
    def analyze_programs(self, sources: List[str], models: List[str], output_dir: str, 
                        options: Dict[str, Any]) -> Dict[str, Any]:
        """
        Análise principal integrada de programas COBOL.
        
        Args:
            sources: Lista de arquivos/diretórios fonte
            models: Lista de modelos a usar
            output_dir: Diretório de saída
            options: Opções de análise
            
        Returns:
            Resultados consolidados da análise
        """
        start_time = time.time()
        
        # Preparar ambiente
        os.makedirs(output_dir, exist_ok=True)
        
        # Descobrir programas COBOL
        programs = self._discover_cobol_programs(sources)
        self.statistics['total_programs'] = len(programs)
        
        if not programs:
            self.logger.warning("Nenhum programa COBOL encontrado")
            return {'success': False, 'error': 'Nenhum programa encontrado'}
        
        # Configurar processamento
        use_parallel = options.get('parallel', False) and len(programs) > 1
        generate_prompts = options.get('generate_prompts', False)
        advanced_analysis = options.get('advanced_analysis', False)
        
        # Executar análises
        if use_parallel:
            results = self._analyze_parallel(programs, models, output_dir, options)
        else:
            results = self._analyze_sequential(programs, models, output_dir, options)
        
        # Pós-processamento
        if generate_prompts:
            self._generate_adaptive_prompts(programs, results, output_dir)
        
        if advanced_analysis:
            self._perform_advanced_analysis(programs, results, output_dir)
        
        # Gerar relatórios consolidados
        consolidated_results = self._generate_consolidated_reports(results, output_dir, options)
        
        # Estatísticas finais
        total_time = time.time() - start_time
        self.statistics['total_time'] = total_time
        
        self.logger.info(f"Análise concluída em {total_time:.2f}s")
        self.logger.info(f"Programas processados: {self.statistics['successful_analyses']}/{self.statistics['total_programs']}")
        
        return {
            'success': True,
            'results': consolidated_results,
            'statistics': self.statistics,
            'output_dir': output_dir
        }
    
    def _discover_cobol_programs(self, sources: List[str]) -> List[Tuple[str, CobolProgram, List[CobolBook]]]:
        """Descobre e parseia programas COBOL."""
        programs = []
        parser = COBOLParser()
        
        for source in sources:
            if os.path.isfile(source):
                files = [source]
            elif os.path.isdir(source):
                files = []
                for ext in ['.cbl', '.cob', '.cobol', '.txt']:
                    files.extend(Path(source).rglob(f'*{ext}'))
            else:
                # Arquivo de lista
                try:
                    with open(source, 'r', encoding='utf-8') as f:
                        files = [line.strip() for line in f if line.strip()]
                except:
                    self.logger.error(f"Erro ao ler arquivo de lista: {source}")
                    continue
            
            for file_path in files:
                try:
                    parsed_result = parser.parse_file(str(file_path))
                    if isinstance(parsed_result, tuple) and len(parsed_result) == 2:
                        program, books = parsed_result
                        if isinstance(program, list) and program:
                            # Parser retorna lista de programas
                            for prog in program:
                                programs.append((str(file_path), prog, books))
                                self.logger.info(f"Programa descoberto: {prog.name}")
                        elif program:
                            # Parser retorna programa único
                            programs.append((str(file_path), program, books))
                            self.logger.info(f"Programa descoberto: {program.name}")
                except Exception as e:
                    self.logger.error(f"Erro ao parsear {file_path}: {e}")
        
        return programs
    
    def _analyze_sequential(self, programs: List[Tuple], models: List[str], 
                          output_dir: str, options: Dict[str, Any]) -> Dict[str, Any]:
        """Análise sequencial de programas."""
        results = {}
        
        for file_path, program, books in programs:
            program_results = {}
            
            for model in models:
                try:
                    result = self._analyze_single_program(
                        file_path, program, books, model, output_dir, options
                    )
                    program_results[model] = result
                    
                    if result['success']:
                        self.statistics['successful_analyses'] += 1
                    else:
                        self.statistics['failed_analyses'] += 1
                        
                except Exception as e:
                    self.logger.error(f"Erro na análise de {program.name} com {model}: {e}")
                    program_results[model] = {'success': False, 'error': str(e)}
                    self.statistics['failed_analyses'] += 1
            
            results[program.name] = program_results
        
        return results
    
    def _analyze_parallel(self, programs: List[Tuple], models: List[str], 
                         output_dir: str, options: Dict[str, Any]) -> Dict[str, Any]:
        """Análise paralela de programas."""
        results = {}
        max_workers = options.get('max_workers', 4)
        
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            # Submeter todas as tarefas
            future_to_info = {}
            
            for file_path, program, books in programs:
                for model in models:
                    future = executor.submit(
                        self._analyze_single_program,
                        file_path, program, books, model, output_dir, options
                    )
                    future_to_info[future] = (program.name, model)
            
            # Coletar resultados
            for future in as_completed(future_to_info):
                program_name, model = future_to_info[future]
                
                if program_name not in results:
                    results[program_name] = {}
                
                try:
                    result = future.result()
                    results[program_name][model] = result
                    
                    if result['success']:
                        self.statistics['successful_analyses'] += 1
                    else:
                        self.statistics['failed_analyses'] += 1
                        
                except Exception as e:
                    self.logger.error(f"Erro na análise paralela de {program_name} com {model}: {e}")
                    results[program_name][model] = {'success': False, 'error': str(e)}
                    self.statistics['failed_analyses'] += 1
        
        return results
    
    def _analyze_single_program(self, file_path: str, program: CobolProgram, 
                              books: List[CobolBook], model: str, output_dir: str, 
                              options: Dict[str, Any]) -> Dict[str, Any]:
        """Análise de um único programa com modelo específico."""
        start_time = time.time()
        
        # Verificar cache
        cache_key = f"{program.name}_{model}_{hash(program.content)}"
        cached_result = self.cache.get_analysis_cache(program.content, model)
        
        if cached_result and not options.get('force_refresh', False):
            self.statistics['cache_hits'] += 1
            self.logger.info(f"Resultado obtido do cache para {program.name} com {model}")
            return cached_result
        
        try:
            # Configurar componentes
            prompt_set = options.get('prompt_set', 'cadoc_deep_analysis')
            prompt_manager = DualPromptManager(self.config_manager.config, prompt_set)
            
            # Criar diretório específico
            model_dir = os.path.join(output_dir, f"model_{model.replace('/', '_').replace('-', '_')}")
            os.makedirs(model_dir, exist_ok=True)
            
            # Análise principal
            analyzer = EnhancedCOBOLAnalyzer(
                self.provider_manager, 
                prompt_manager, 
                self.rag_integration
            )
            
            # Executar análise
            analysis_result = analyzer.analyze_program(program, model)
            
            # Validação anti-alucinação
            if options.get('validate_hallucination', True):
                validation_result = self.hallucination_validator.validate_analysis(
                    program.content, analysis_result.get('content', '')
                )
                analysis_result['validation'] = validation_result
            
            # Análise de códigos técnicos
            if options.get('technical_analysis', True):
                technical_result = self.technical_analyzer.analyze_technical_codes(
                    program.content, analysis_result.get('content', '')
                )
                analysis_result['technical_codes'] = technical_result
            
            # Gerar documentação
            doc_generator = DocumentationGenerator(model_dir)
            doc_path = doc_generator.generate_documentation(
                program, analysis_result, f"{program.name}_analise_funcional.md"
            )
            
            # Preparar resultado
            result = {
                'success': True,
                'analysis': analysis_result,
                'documentation_path': doc_path,
                'model': model,
                'tokens_used': analysis_result.get('tokens_used', 0),
                'processing_time': time.time() - start_time,
                'timestamp': datetime.now().isoformat()
            }
            
            # Salvar no cache
            self.cache.set_analysis_cache(cache_key, result)
            
            # Atualizar estatísticas
            self.statistics['total_tokens'] += result['tokens_used']
            
            # Aprendizado RAG
            if options.get('rag_learning', True):
                self.rag_integration.learn_from_analysis(program, analysis_result)
                self.statistics['rag_enhancements'] += 1
            
            # Salvar documentação de mensagens se solicitado
            if options.get('save_messages', False):
                prompt_used = analysis_result.get('prompt_used', 'N/A')
                response_content = analysis_result.get('content', 'N/A')
                metadata = {
                    'tokens_used': result['tokens_used'],
                    'processing_time': result['processing_time'],
                    'model': model,
                    'timestamp': result['timestamp'],
                    'validation': analysis_result.get('validation', {}),
                    'technical_codes': analysis_result.get('technical_codes', {})
                }
                save_message_documentation(output_dir, program.name, model, 
                                         prompt_used, response_content, metadata)
            
            return result
            
        except Exception as e:
            self.logger.error(f"Erro na análise de {program.name} com {model}: {e}")
            return {
                'success': False,
                'error': str(e),
                'model': model,
                'processing_time': time.time() - start_time
            }
    
    def _generate_adaptive_prompts(self, programs: List[Tuple], results: Dict[str, Any], 
                                 output_dir: str) -> None:
        """Gera prompts adaptativos baseados nos programas analisados."""
        self.logger.info("Gerando prompts adaptativos...")
        
        try:
            prompt_generator = AdaptivePromptGenerator(self.config_manager.config)
            
            for file_path, program, books in programs:
                # Gerar prompt adaptativo
                adaptive_prompt = prompt_generator.generate_adaptive_prompt(
                    program, books, results.get(program.name, {})
                )
                
                # Salvar prompt YAML
                prompt_file = os.path.join(output_dir, f"{program.name}_prompt_adaptativo.yaml")
                generate_prompt_yaml(
                    program_name=program.name,
                    analysis_type="funcionalidades_completas",
                    output_file=prompt_file,
                    custom_prompt=adaptive_prompt
                )
                
                self.logger.info(f"Prompt adaptativo gerado: {prompt_file}")
                
        except Exception as e:
            self.logger.error(f"Erro na geração de prompts adaptativos: {e}")
    
    def _perform_advanced_analysis(self, programs: List[Tuple], results: Dict[str, Any], 
                                 output_dir: str) -> None:
        """Executa análises avançadas consolidadas."""
        self.logger.info("Executando análises avançadas...")
        
        try:
            # Análise consolidada de regras de negócio
            business_rules = {}
            technical_patterns = {}
            
            for file_path, program, books in programs:
                # Extrair regras de negócio
                rules = extract_business_rules(program.content)
                business_rules[program.name] = rules
                
                # Converter para JSON estruturado
                json_data = convert_cobol_to_json(file_path)
                
                # Salvar análises
                rules_file = os.path.join(output_dir, f"{program.name}_regras_negocio.json")
                with open(rules_file, 'w', encoding='utf-8') as f:
                    json.dump(rules, f, indent=2, ensure_ascii=False)
                
                json_file = os.path.join(output_dir, f"{program.name}_estrutura.json")
                with open(json_file, 'w', encoding='utf-8') as f:
                    json.dump(json_data, f, indent=2, ensure_ascii=False)
            
            # Gerar relatório consolidado avançado
            advanced_generator = AdvancedReportGenerator()
            consolidated_report = advanced_generator.generate_consolidated_report(
                programs, results, business_rules, output_dir
            )
            
            self.logger.info("Análises avançadas concluídas")
            
        except Exception as e:
            self.logger.error(f"Erro nas análises avançadas: {e}")
    
    def _generate_consolidated_reports(self, results: Dict[str, Any], output_dir: str, 
                                     options: Dict[str, Any]) -> Dict[str, Any]:
        """Gera relatórios consolidados finais."""
        self.logger.info("Gerando relatórios consolidados...")
        
        try:
            # Relatório de estatísticas
            stats_file = os.path.join(output_dir, "relatorio_estatisticas.json")
            with open(stats_file, 'w', encoding='utf-8') as f:
                json.dump(self.statistics, f, indent=2, ensure_ascii=False)
            
            # Relatório de custos
            cost_calculator = CostCalculator()
            cost_report = cost_calculator.calculate_total_costs(results)
            
            cost_file = os.path.join(output_dir, "relatorio_custos.json")
            with open(cost_file, 'w', encoding='utf-8') as f:
                json.dump(cost_report, f, indent=2, ensure_ascii=False)
            
            # Relatório RAG
            rag_file = self.rag_integration.generate_knowledge_report(output_dir)
            
            # Consolidar resultados
            consolidated = {
                'summary': {
                    'total_programs': self.statistics['total_programs'],
                    'successful_analyses': self.statistics['successful_analyses'],
                    'success_rate': (self.statistics['successful_analyses'] / self.statistics['total_programs'] * 100) if self.statistics['total_programs'] > 0 else 0,
                    'total_tokens': self.statistics['total_tokens'],
                    'total_time': self.statistics['total_time'],
                    'cache_efficiency': (self.statistics['cache_hits'] / (self.statistics['successful_analyses'] + self.statistics['cache_hits']) * 100) if (self.statistics['successful_analyses'] + self.statistics['cache_hits']) > 0 else 0
                },
                'detailed_results': results,
                'reports': {
                    'statistics': stats_file,
                    'costs': cost_file,
                    'rag': rag_file
                }
            }
            
            # Salvar consolidado
            consolidated_file = os.path.join(output_dir, "relatorio_consolidado.json")
            with open(consolidated_file, 'w', encoding='utf-8') as f:
                json.dump(consolidated, f, indent=2, ensure_ascii=False)
            
            self.logger.info(f"Relatórios consolidados salvos em: {output_dir}")
            return consolidated
            
        except Exception as e:
            self.logger.error(f"Erro na geração de relatórios consolidados: {e}")
            return {'error': str(e)}


def generate_html_pdf_reports(output_dir: str, detailed_results: List[Dict]) -> None:
    """Gera relatórios HTML/PDF a partir dos arquivos Markdown."""
    try:
        from src.utils.pdf_converter import MarkdownToPDFConverter
        
        converter = MarkdownToPDFConverter()
        html_files_generated = []
        
        # Buscar arquivos Markdown nos diretórios de modelo
        for result in detailed_results:
            if isinstance(result, dict) and result.get('success'):
                model_dir = result.get('output_dir', '')
                if model_dir and os.path.exists(model_dir):
                    md_files = [f for f in os.listdir(model_dir) if f.endswith('.md')]
                    
                    for md_file in md_files:
                        md_path = os.path.join(model_dir, md_file)
                        try:
                            html_file = converter.convert_to_pdf(md_path)
                            html_files_generated.append(html_file)
                            print(f"  HTML gerado: {html_file}")
                        except Exception as e:
                            print(f"  Erro ao converter {md_file}: {e}")
        
        # Buscar arquivos Markdown na raiz
        md_files = [f for f in os.listdir(output_dir) if f.endswith('.md')]
        for md_file in md_files:
            md_path = os.path.join(output_dir, md_file)
            try:
                html_file = converter.convert_to_pdf(md_path)
                html_files_generated.append(html_file)
                print(f"  HTML gerado: {html_file}")
            except Exception as e:
                print(f"  Erro ao converter {md_file}: {e}")
        
        if html_files_generated:
            print(f"\n[OK] {len(html_files_generated)} relatórios HTML/PDF gerados com sucesso!")
            print("[OK] Abra os arquivos .html no navegador e use Ctrl+P para gerar PDF")
        else:
            print("[OK][OK] Nenhum arquivo Markdown encontrado para conversão")
            
    except ImportError as e:
        print(f"[OK] Erro ao importar conversor PDF: {e}")
    except Exception as e:
        print(f"[OK] Erro na geração de relatórios HTML/PDF: {e}")


def save_message_documentation(output_dir: str, program_name: str, model: str, 
                             prompt: str, response: str, metadata: Dict[str, Any]) -> None:
    """Salva documentação de mensagens enviadas/recebidas."""
    try:
        # Criar diretório para mensagens
        messages_dir = os.path.join(output_dir, "messages")
        os.makedirs(messages_dir, exist_ok=True)
        
        # Nome do arquivo
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{program_name}_{model}_{timestamp}.md"
        filepath = os.path.join(messages_dir, filename)
        
        # Conteúdo da documentação
        content = f"""# Documentação de Mensagem - {program_name}

## Informações Gerais
- **Programa**: {program_name}
- **Modelo**: {model}
- **Timestamp**: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
- **Tokens utilizados**: {metadata.get('tokens_used', 'N/A')}
- **Tempo de processamento**: {metadata.get('processing_time', 'N/A')}s

## Prompt Enviado
```
{prompt}
```

## Resposta Recebida
```
{response}
```

## Metadados Técnicos
```json
{json.dumps(metadata, indent=2, ensure_ascii=False)}
```

---
*Documentação gerada automaticamente pelo sistema COBOL to Docs v1.6*
"""
        
        # Salvar arquivo
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
            
        print(f"📝 Mensagem documentada: {filename}")
        
    except Exception as e:
        print(f"[OK] Erro ao salvar documentação de mensagem: {e}")


def setup_logging(log_level: str = "INFO") -> None:
    """Configura o sistema de logging."""
    log_dir = "logs"
    os.makedirs(log_dir, exist_ok=True)
    
    log_file = os.path.join(log_dir, f"cobol_to_docs_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
    
    logging.basicConfig(
        level=getattr(logging, log_level.upper()),
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file, encoding='utf-8'),
            logging.StreamHandler(sys.stdout)
        ]
    )


def parse_arguments() -> argparse.Namespace:
    """Parse dos argumentos da linha de comando."""
    parser = argparse.ArgumentParser(
        description="COBOL to Docs v1.6 - Sistema Integrado de Análise COBOL",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Exemplos de uso:

  # Análise básica
  python main_integrated.py --fontes programa.cbl --models enhanced_mock

  # Análise avançada com múltiplos modelos
  python main_integrated.py --fontes lista_programas.txt --models "['enhanced_mock', 'luzia']" --advanced

  # Análise paralela com geração de prompts
  python main_integrated.py --fontes /path/cobol/ --models enhanced_mock --parallel --generate-prompts

  # Análise completa com todas as funcionalidades
  python main_integrated.py --fontes programa.cbl --models enhanced_mock --advanced --generate-prompts --validate
        """
    )
    
    # Argumentos obrigatórios
    parser.add_argument('--fontes', '--sources', required=True,
                       help='Arquivo, diretório ou lista de programas COBOL')
    
    parser.add_argument('--models', required=True,
                       help='Modelo(s) a usar: string simples ou lista JSON')
    
    # Argumentos opcionais
    parser.add_argument('--output', default=f'analise_{datetime.now().strftime("%Y%m%d_%H%M%S")}',
                       help='Diretório de saída (padrão: analise_TIMESTAMP)')
    
    parser.add_argument('--config', default='config/config.yaml',
                       help='Arquivo de configuração (padrão: config/config.yaml)')
    
    parser.add_argument('--prompt-set', default='cadoc_deep_analysis',
                       help='Conjunto de prompts a usar (padrão: cadoc_deep_analysis)')
    
    # Funcionalidades avançadas
    parser.add_argument('--advanced', action='store_true',
                       help='Ativar análises avançadas (regras de negócio, JSON, etc.)')
    
    parser.add_argument('--generate-prompts', action='store_true',
                       help='Gerar prompts adaptativos baseados na análise')
    
    parser.add_argument('--parallel', action='store_true',
                       help='Usar processamento paralelo (múltiplos programas)')
    
    parser.add_argument('--validate', action='store_true',
                       help='Ativar validação anti-alucinação')
    
    parser.add_argument('--no-cache', action='store_true',
                       help='Desabilitar cache inteligente')
    
    parser.add_argument('--no-rag', action='store_true',
                       help='Desabilitar aprendizado RAG')
    
    # Configurações técnicas
    parser.add_argument('--max-workers', type=int, default=4,
                       help='Número máximo de workers paralelos (padrão: 4)')
    
    parser.add_argument('--log-level', default='INFO',
                       choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'],
                       help='Nível de log (padrão: INFO)')
    
    parser.add_argument('--pdf', action='store_true',
                       help='Gerar relatórios HTML/PDF dos arquivos Markdown')
    
    parser.add_argument('--save-messages', action='store_true',
                       help='Salvar mensagens enviadas/recebidas para cada modelo')
    
    return parser.parse_args()


def main():
    """Função principal integrada."""
    args = parse_arguments()
    
    # Configurar logging
    setup_logging(args.log_level)
    logger = logging.getLogger(__name__)
    
    logger.info("=== COBOL to Docs v1.6 - Sistema Integrado ===")
    logger.info(f"Fontes: {args.fontes}")
    logger.info(f"Modelos: {args.models}")
    logger.info(f"Saída: {args.output}")
    
    try:
        # Parse dos modelos
        if args.models.startswith('['):
            models = json.loads(args.models)
        else:
            models = [args.models]
        
        # Configurar opções
        options = {
            'prompt_set': args.prompt_set,
            'advanced_analysis': args.advanced,
            'generate_prompts': args.generate_prompts,
            'parallel': args.parallel,
            'validate_hallucination': args.validate,
            'force_refresh': args.no_cache,
            'rag_learning': not args.no_rag,
            'max_workers': args.max_workers,
            'technical_analysis': True,
            'save_messages': args.save_messages
        }
        
        # Inicializar analisador
        analyzer = IntegratedCOBOLAnalyzer(args.config)
        
        # Executar análise
        results = analyzer.analyze_programs(
            sources=[args.fontes],
            models=models,
            output_dir=args.output,
            options=options
        )
        
        # Exibir resultados
        if results['success']:
            summary = results['results']['summary']
            logger.info("=== ANÁLISE CONCLUÍDA COM SUCESSO ===")
            logger.info(f"Programas processados: {summary['successful_analyses']}/{summary['total_programs']}")
            logger.info(f"Taxa de sucesso: {summary['success_rate']:.1f}%")
            logger.info(f"Tokens utilizados: {summary['total_tokens']}")
            logger.info(f"Tempo total: {summary['total_time']:.2f}s")
            logger.info(f"Eficiência do cache: {summary['cache_efficiency']:.1f}%")
            logger.info(f"Resultados salvos em: {results['output_dir']}")
            
            # Gerar PDF se solicitado
            if args.pdf:
                logger.info("Gerando relatórios HTML/PDF...")
                generate_html_pdf_reports(results['output_dir'], results['results']['detailed_results'])
            
            return 0
        else:
            logger.error(f"Erro na análise: {results.get('error', 'Erro desconhecido')}")
            return 1
            
    except Exception as e:
        logger.error(f"Erro fatal: {e}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
