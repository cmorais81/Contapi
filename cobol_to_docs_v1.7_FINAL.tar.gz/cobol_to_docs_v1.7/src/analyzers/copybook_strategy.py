#!/usr/bin/env python3
"""
Estratégia de Análise de Copybooks
Define a estratégia para análise de copybooks em programas COBOL.

Este módulo implementa uma abordagem estratégica para lidar com copybooks,
baseada no feedback do especialista: "não trouxe nenhum copybook, se errava
ao tentar trazer todos, desta vez acertou em não trazer nenhum, dai o analista
verá que conferir no código, o que vai fazer de qualquer jeito."
"""

import logging
from enum import Enum
from typing import Dict, List, Any, Optional, Set, Tuple

class CopybookStrategy(Enum):
    """Estratégias possíveis para lidar com copybooks."""
    
    # Não listar copybooks, deixando para o analista verificar no código
    NO_COPYBOOKS = 1
    
    # Listar apenas copybooks encontrados com certeza no código
    VERIFIED_ONLY = 2
    
    # Tentar identificar todos os copybooks possíveis
    ALL_POSSIBLE = 3


class CopybookStrategyManager:
    """
    Gerenciador de estratégia para análise de copybooks.
    Implementa a abordagem recomendada pelo especialista.
    """
    
    def __init__(self, strategy: CopybookStrategy = CopybookStrategy.VERIFIED_ONLY):
        """
        Inicializa o gerenciador de estratégia.
        
        Args:
            strategy: Estratégia a ser utilizada para análise de copybooks
        """
        self.logger = logging.getLogger(__name__)
        self.strategy = strategy
    
    def should_list_copybooks(self, program_complexity: int) -> bool:
        """
        Determina se copybooks devem ser listados com base na estratégia e complexidade.
        
        Args:
            program_complexity: Complexidade estimada do programa (linhas de código)
            
        Returns:
            True se copybooks devem ser listados, False caso contrário
        """
        if self.strategy == CopybookStrategy.NO_COPYBOOKS:
            return False
        
        if self.strategy == CopybookStrategy.VERIFIED_ONLY:
            # Listar apenas se o programa não for muito complexo
            return program_complexity < 1000
        
        # Para ALL_POSSIBLE, sempre listar
        return True
    
    def get_copybook_documentation_note(self) -> str:
        """
        Retorna uma nota técnica sobre a estratégia de documentação de copybooks.
        
        Returns:
            Nota técnica para incluir na documentação
        """
        if self.strategy == CopybookStrategy.NO_COPYBOOKS:
            return (
                "> **Nota técnica sobre copybooks:** A análise não lista copybooks automaticamente. "
                "O analista deve verificar diretamente no código fonte as declarações COPY e ++INCLUDE."
            )
        
        if self.strategy == CopybookStrategy.VERIFIED_ONLY:
            return (
                "> **Nota técnica sobre copybooks:** A análise lista apenas copybooks verificados com certeza no código. "
                "Copybooks adicionais podem estar presentes e devem ser verificados diretamente no código fonte."
            )
        
        # Para ALL_POSSIBLE
        return (
            "> **Nota técnica sobre copybooks:** A análise tenta identificar todos os copybooks possíveis, "
            "mas recomenda-se verificação adicional no código fonte para confirmação."
        )
    
    def filter_copybook_references(self, references: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Filtra referências a copybooks de acordo com a estratégia.
        
        Args:
            references: Lista de referências a copybooks encontradas
            
        Returns:
            Lista filtrada de referências a copybooks
        """
        if self.strategy == CopybookStrategy.NO_COPYBOOKS:
            return []
        
        if self.strategy == CopybookStrategy.VERIFIED_ONLY:
            # Filtrar apenas referências com alta confiança
            return [ref for ref in references if self._is_high_confidence(ref)]
        
        # Para ALL_POSSIBLE, retornar todas as referências
        return references
    
    def _is_high_confidence(self, reference: Dict[str, Any]) -> bool:
        """
        Determina se uma referência a copybook tem alta confiança.
        
        Args:
            reference: Referência a copybook
            
        Returns:
            True se a referência tem alta confiança, False caso contrário
        """
        # Implementação básica: considerar apenas sintaxes padrão
        syntax = reference.get('syntax', '').upper()
        return syntax in ('COPY', '++INCLUDE')


# Função auxiliar para uso direto
def get_copybook_strategy(config: Dict[str, Any]) -> CopybookStrategyManager:
    """
    Cria um gerenciador de estratégia de copybooks com base na configuração.
    
    Args:
        config: Configuração do sistema
        
    Returns:
        Gerenciador de estratégia de copybooks
    """
    strategy_name = config.get('copybook_strategy', 'verified_only').lower()
    
    if strategy_name == 'none' or strategy_name == 'no_copybooks':
        strategy = CopybookStrategy.NO_COPYBOOKS
    elif strategy_name == 'all' or strategy_name == 'all_possible':
        strategy = CopybookStrategy.ALL_POSSIBLE
    else:
        strategy = CopybookStrategy.VERIFIED_ONLY
    
    return CopybookStrategyManager(strategy)
