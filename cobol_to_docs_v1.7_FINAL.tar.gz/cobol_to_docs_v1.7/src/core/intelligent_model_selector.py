#!/usr/bin/env python3
"""
Sistema de Seleção Inteligente de Modelos LLM
Seleciona automaticamente o melhor modelo baseado na complexidade do código COBOL
"""

import re
import logging
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass

@dataclass
class ModelRecommendation:
    """Recomendação de modelo com justificativa"""
    model_name: str
    confidence: float
    reasoning: str
    fallback_models: List[str]

class IntelligentModelSelector:
    """Seletor inteligente de modelos LLM baseado na complexidade do código"""
    
    def __init__(self, config=None):
        self.logger = logging.getLogger(__name__)
        self.config = config or {}
        
        # Configuração dos modelos disponíveis
        self.models_config = {
            "aws_claude_3_5_sonnet": {
                "complexity_range": (0.7, 1.0),
                "strengths": ["análise complexa", "regras de negócio", "arquitetura"],
                "max_tokens": 8192,
                "context_window": 200000,
                "cost_factor": 1.0,
                "description": "Modelo avançado para análises complexas e detalhadas"
            },
            "amazon_nova_pro_v1": {
                "complexity_range": (0.6, 0.9),
                "strengths": ["contexto extenso", "documentação", "integração"],
                "max_tokens": 8192,
                "context_window": 300000,
                "cost_factor": 0.8,
                "description": "Modelo robusto para programas grandes com contexto extenso"
            },
            "azure_gpt_4o": {
                "complexity_range": (0.4, 0.8),
                "strengths": ["análise balanceada", "documentação", "padrões"],
                "max_tokens": 4096,
                "context_window": 128000,
                "cost_factor": 0.6,
                "description": "Modelo balanceado para análises padrão"
            },
            "aws_claude_3_5_haiku": {
                "complexity_range": (0.0, 0.6),
                "strengths": ["velocidade", "eficiência", "batch"],
                "max_tokens": 4096,
                "context_window": 200000,
                "cost_factor": 0.3,
                "description": "Modelo rápido e eficiente para programas simples"
            }
        }
        
        # Padrões de complexidade
        self.complexity_patterns = {
            "high_complexity": {
                "patterns": [
                    r"EXEC\s+SQL",  # SQL embebido
                    r"CALL\s+['\"][\w-]+['\"]",  # Chamadas de programa
                    r"COPY\s+[\w-]+",  # Copybooks
                    r"EVALUATE\s+.*WHEN",  # Estruturas condicionais complexas
                    r"SEARCH\s+ALL",  # Busca binária
                    r"SORT\s+.*USING",  # Operações de ordenação
                    r"MERGE\s+.*USING",  # Operações de merge
                    r"ORGANIZATION\s+INDEXED",  # Arquivos indexados
                    r"ALTERNATE\s+RECORD\s+KEY",  # Chaves alternativas
                    r"REDEFINES",  # Redefinições de dados
                ],
                "weight": 0.15
            },
            "medium_complexity": {
                "patterns": [
                    r"PERFORM\s+.*UNTIL",  # Loops
                    r"IF\s+.*THEN.*ELSE",  # Condicionais com else
                    r"STRING\s+.*DELIMITED",  # Manipulação de strings
                    r"UNSTRING\s+.*DELIMITED",  # Decomposição de strings
                    r"INSPECT\s+.*REPLACING",  # Inspeção e substituição
                    r"COMPUTE\s+.*=",  # Cálculos
                    r"ADD\s+.*TO",  # Operações aritméticas
                    r"SUBTRACT\s+.*FROM",
                    r"MULTIPLY\s+.*BY",
                    r"DIVIDE\s+.*INTO",
                ],
                "weight": 0.08
            },
            "low_complexity": {
                "patterns": [
                    r"MOVE\s+.*TO",  # Movimentações simples
                    r"DISPLAY\s+",  # Exibições
                    r"ACCEPT\s+",  # Entradas
                    r"OPEN\s+",  # Abertura de arquivos
                    r"CLOSE\s+",  # Fechamento de arquivos
                    r"READ\s+",  # Leitura
                    r"WRITE\s+",  # Escrita
                    r"STOP\s+RUN",  # Fim de programa
                ],
                "weight": 0.03
            }
        }
        
        # Padrões específicos CADOC
        self.cadoc_patterns = {
            "document_processing": [
                r"DOC[A-Z0-9-]*",  # Identificadores de documento
                r"CADOC",  # Sistema CADOC
                r"INDICE|INDEX",  # Indexação
                r"CLASSIF",  # Classificação
                r"METADADO",  # Metadados
                r"ARQUIVO|REPOSIT",  # Arquivamento/Repositório
                r"AUDITORIA|AUDIT",  # Auditoria
                r"RETENCAO|RETENTION",  # Retenção
                r"WORKFLOW",  # Workflow
                r"APROVACAO|APPROVAL",  # Aprovação
            ],
            "banking_specific": [
                r"CHEQUE|CHQ",  # Cheques
                r"CONTRATO|CONTRACT",  # Contratos
                r"COMPROVANTE|RECEIPT",  # Comprovantes
                r"CREDITO|CREDIT",  # Crédito
                r"FINANC",  # Financiamento
                r"COMPLIANCE",  # Compliance
                r"REGULAT",  # Regulatório
                r"BACEN|CVM|FEBRABAN",  # Órgãos reguladores
            ]
        }
    
    def analyze_code_complexity(self, cobol_code: str) -> float:
        """Analisa a complexidade do código COBOL"""
        
        if not cobol_code or not cobol_code.strip():
            return 0.0
        
        complexity_score = 0.0
        total_lines = len(cobol_code.split('\n'))
        
        # Análise por padrões de complexidade
        for category, config in self.complexity_patterns.items():
            pattern_count = 0
            for pattern in config["patterns"]:
                matches = len(re.findall(pattern, cobol_code, re.IGNORECASE))
                pattern_count += matches
            
            # Normalizar por número de linhas
            normalized_count = pattern_count / max(total_lines, 1)
            complexity_score += normalized_count * config["weight"]
        
        # Bônus para padrões CADOC específicos
        cadoc_bonus = 0.0
        for category, patterns in self.cadoc_patterns.items():
            for pattern in patterns:
                if re.search(pattern, cobol_code, re.IGNORECASE):
                    cadoc_bonus += 0.05  # Bônus por padrão CADOC encontrado
        
        complexity_score += min(cadoc_bonus, 0.3)  # Máximo 30% de bônus CADOC
        
        # Análise de tamanho
        size_factor = min(total_lines / 1000, 0.5)  # Máximo 50% por tamanho
        complexity_score += size_factor
        
        # Normalizar para 0-1
        return min(complexity_score, 1.0)
    
    def select_optimal_model(self, cobol_code: str, user_preference: Optional[str] = None) -> ModelRecommendation:
        """Seleciona o modelo ótimo baseado na complexidade do código"""
        
        complexity = self.analyze_code_complexity(cobol_code)
        
        self.logger.info(f"Complexidade analisada: {complexity:.3f}")
        
        # Se usuário especificou um modelo, validar se é apropriado
        if user_preference and user_preference in self.models_config:
            model_config = self.models_config[user_preference]
            min_complexity, max_complexity = model_config["complexity_range"]
            
            if min_complexity <= complexity <= max_complexity:
                return ModelRecommendation(
                    model_name=user_preference,
                    confidence=0.9,
                    reasoning=f"Modelo especificado pelo usuário é apropriado para complexidade {complexity:.3f}",
                    fallback_models=self._get_fallback_models(user_preference, complexity)
                )
            else:
                self.logger.warning(f"Modelo {user_preference} não é ideal para complexidade {complexity:.3f}")
        
        # Encontrar melhor modelo baseado na complexidade
        best_model = None
        best_score = 0.0
        
        for model_name, config in self.models_config.items():
            min_complexity, max_complexity = config["complexity_range"]
            
            # Calcular score de adequação
            if min_complexity <= complexity <= max_complexity:
                # Modelo dentro da faixa ideal
                center = (min_complexity + max_complexity) / 2
                distance_from_center = abs(complexity - center)
                range_size = max_complexity - min_complexity
                
                # Score baseado na proximidade do centro da faixa
                adequacy_score = 1.0 - (distance_from_center / (range_size / 2))
                
                # Ajustar por custo-benefício
                cost_efficiency = 1.0 / config["cost_factor"]
                final_score = adequacy_score * 0.7 + cost_efficiency * 0.3
                
                if final_score > best_score:
                    best_score = final_score
                    best_model = model_name
        
        # Se nenhum modelo foi encontrado na faixa ideal, usar o mais próximo
        if not best_model:
            best_model = self._find_closest_model(complexity)
            best_score = 0.6  # Score reduzido para modelo não ideal
        
        # Gerar justificativa
        reasoning = self._generate_reasoning(best_model, complexity, best_score)
        
        return ModelRecommendation(
            model_name=best_model,
            confidence=best_score,
            reasoning=reasoning,
            fallback_models=self._get_fallback_models(best_model, complexity)
        )
    
    def _find_closest_model(self, complexity: float) -> str:
        """Encontra o modelo mais próximo quando nenhum está na faixa ideal"""
        
        closest_model = "azure_gpt_4o"  # Modelo padrão
        min_distance = float('inf')
        
        for model_name, config in self.models_config.items():
            min_complexity, max_complexity = config["complexity_range"]
            
            if complexity < min_complexity:
                distance = min_complexity - complexity
            elif complexity > max_complexity:
                distance = complexity - max_complexity
            else:
                distance = 0  # Dentro da faixa
            
            if distance < min_distance:
                min_distance = distance
                closest_model = model_name
        
        return closest_model
    
    def _get_fallback_models(self, primary_model: str, complexity: float) -> List[str]:
        """Gera lista de modelos de fallback"""
        
        fallbacks = []
        
        # Ordenar modelos por adequação à complexidade
        model_scores = []
        for model_name, config in self.models_config.items():
            if model_name == primary_model:
                continue
            
            min_complexity, max_complexity = config["complexity_range"]
            center = (min_complexity + max_complexity) / 2
            distance = abs(complexity - center)
            
            model_scores.append((model_name, distance))
        
        # Ordenar por distância (menor distância = mais adequado)
        model_scores.sort(key=lambda x: x[1])
        
        # Pegar os 2 melhores como fallback
        fallbacks = [model[0] for model in model_scores[:2]]
        
        return fallbacks
    
    def _generate_reasoning(self, model_name: str, complexity: float, confidence: float) -> str:
        """Gera justificativa para a seleção do modelo"""
        
        config = self.models_config[model_name]
        
        reasoning_parts = [
            f"Complexidade do código: {complexity:.3f}",
            f"Modelo selecionado: {model_name}",
            f"Confiança: {confidence:.1%}",
            f"Faixa ideal do modelo: {config['complexity_range'][0]:.1f}-{config['complexity_range'][1]:.1f}",
            f"Pontos fortes: {', '.join(config['strengths'])}",
            config["description"]
        ]
        
        return " | ".join(reasoning_parts)
    
    def get_model_comparison(self, cobol_code: str) -> Dict[str, Dict]:
        """Retorna comparação de todos os modelos para o código"""
        
        complexity = self.analyze_code_complexity(cobol_code)
        comparison = {}
        
        for model_name, config in self.models_config.items():
            min_complexity, max_complexity = config["complexity_range"]
            
            # Calcular adequação
            if min_complexity <= complexity <= max_complexity:
                adequacy = "Ideal"
                score = 1.0
            elif complexity < min_complexity:
                adequacy = "Subutilizado"
                score = 0.6
            elif complexity > max_complexity:
                adequacy = "Sobrecarregado"
                score = 0.4
            else:
                adequacy = "Inadequado"
                score = 0.2
            
            comparison[model_name] = {
                "adequacy": adequacy,
                "score": score,
                "description": config["description"],
                "strengths": config["strengths"],
                "cost_factor": config["cost_factor"],
                "max_tokens": config["max_tokens"],
                "context_window": config["context_window"]
            }
        
        return comparison

def create_model_selector() -> IntelligentModelSelector:
    """Factory function para criar o seletor de modelos"""
    return IntelligentModelSelector()

# Exemplo de uso
if __name__ == "__main__":
    selector = create_model_selector()
    
    # Código de exemplo
    sample_code = """
    IDENTIFICATION DIVISION.
    PROGRAM-ID. CADOC-PROCESSOR.
    
    DATA DIVISION.
    WORKING-STORAGE SECTION.
    01 WS-DOCUMENT-REC.
       05 WS-DOC-ID        PIC X(20).
       05 WS-DOC-TYPE      PIC X(10).
       05 WS-DOC-STATUS    PIC X(02).
    
    PROCEDURE DIVISION.
    MAIN-PROCESS.
        PERFORM PROCESS-DOCUMENTS
        UNTIL WS-EOF = 'Y'.
        
    PROCESS-DOCUMENTS.
        EXEC SQL
            SELECT DOC_ID, DOC_TYPE, STATUS
            INTO :WS-DOC-ID, :WS-DOC-TYPE, :WS-DOC-STATUS
            FROM CADOC_DOCUMENTS
            WHERE STATUS = 'PENDING'
        END-EXEC.
        
        EVALUATE WS-DOC-TYPE
            WHEN 'CHEQUE'
                PERFORM PROCESS-CHEQUE
            WHEN 'CONTRATO'
                PERFORM PROCESS-CONTRACT
            WHEN OTHER
                PERFORM PROCESS-GENERIC
        END-EVALUATE.
    """
    
    recommendation = selector.select_optimal_model(sample_code)
    print(f"Modelo recomendado: {recommendation.model_name}")
    print(f"Confiança: {recommendation.confidence:.1%}")
    print(f"Justificativa: {recommendation.reasoning}")
    print(f"Fallbacks: {recommendation.fallback_models}")
