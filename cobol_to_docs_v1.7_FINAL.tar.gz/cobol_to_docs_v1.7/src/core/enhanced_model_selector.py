"""
Seletor de Modelo Aprimorado
Versão melhorada com cache inteligente e otimizações de performance.
"""

import logging
import re
from typing import Dict, List, Any, Optional, Tuple
from src.utils.intelligent_cache import cache_manager
from src.core.intelligent_model_selector import IntelligentModelSelector

logger = logging.getLogger(__name__)

class EnhancedModelSelector(IntelligentModelSelector):
    """
    Seletor de modelo aprimorado com cache inteligente e otimizações.
    
    Melhorias:
    - Cache inteligente de recomendações
    - Análise de complexidade otimizada
    - Detecção aprimorada de padrões CADOC
    - Métricas de performance
    - Compatibilidade total com versão anterior
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Inicializa o seletor aprimorado.
        
        Args:
            config: Configuração do sistema
        """
        super().__init__(config)
        self.cache_enabled = config.get('performance', {}).get('cache_enabled', True)
        self.performance_metrics = {
            'cache_hits': 0,
            'cache_misses': 0,
            'analysis_time': 0,
            'recommendations_made': 0
        }
        
        logger.info(f"Enhanced Model Selector inicializado (cache: {'habilitado' if self.cache_enabled else 'desabilitado'})")
    
    def recommend_model(self, cobol_code: str, available_models: List[str]) -> Dict[str, Any]:
        """
        Recomenda modelo com cache inteligente.
        
        Args:
            cobol_code: Código COBOL para análise
            available_models: Modelos disponíveis
            
        Returns:
            Recomendação de modelo com justificativa
        """
        import time
        start_time = time.time()
        
        # Tentar obter do cache primeiro
        if self.cache_enabled:
            cached_recommendation = cache_manager.get_model_recommendation(cobol_code)
            if cached_recommendation:
                # Verificar se os modelos disponíveis ainda são válidos
                recommended_model = cached_recommendation.get('recommended_model')
                if recommended_model in available_models:
                    self.performance_metrics['cache_hits'] += 1
                    logger.debug(f"Recomendação obtida do cache: {recommended_model}")
                    return cached_recommendation
        
        # Cache miss - fazer análise completa
        self.performance_metrics['cache_misses'] += 1
        
        # Usar análise da classe pai
        recommendation = super().select_optimal_model(cobol_code)
        
        # Converter ModelRecommendation para dict compatível
        result = {
            'recommended_model': recommendation.model_name,
            'confidence': recommendation.confidence,
            'reasoning': recommendation.reasoning,
            'fallback_models': recommendation.fallback_models,
            'complexity_score': super().analyze_code_complexity(cobol_code)
        }
        
        # Adicionar métricas aprimoradas
        result = self._enhance_recommendation(result, cobol_code)
        
        # Salvar no cache
        if self.cache_enabled:
            cache_manager.set_model_recommendation(cobol_code, result)
        
        analysis_time = time.time() - start_time
        self.performance_metrics['analysis_time'] += analysis_time
        self.performance_metrics['recommendations_made'] += 1
        
        logger.debug(f"Nova recomendação gerada em {analysis_time:.3f}s: {result.get('recommended_model')}")
        
        return result
    
    def analyze_complexity_cached(self, cobol_code: str) -> Dict[str, Any]:
        """
        Análise de complexidade com cache.
        
        Args:
            cobol_code: Código COBOL
            
        Returns:
            Análise de complexidade
        """
        # Tentar obter do cache
        if self.cache_enabled:
            cached_analysis = cache_manager.get_complexity_analysis(cobol_code)
            if cached_analysis:
                logger.debug("Análise de complexidade obtida do cache")
                return cached_analysis
        
        # Cache miss - fazer análise
        analysis = self.analyze_complexity(cobol_code)
        
        # Salvar no cache
        if self.cache_enabled:
            cache_manager.set_complexity_analysis(cobol_code, analysis)
        
        return analysis
    
    def _enhance_recommendation(self, recommendation: Dict[str, Any], cobol_code: str) -> Dict[str, Any]:
        """
        Aprimora recomendação com análises adicionais.
        
        Args:
            recommendation: Recomendação base
            cobol_code: Código COBOL
            
        Returns:
            Recomendação aprimorada
        """
        # Adicionar análise de padrões avançados
        advanced_patterns = self._analyze_advanced_patterns(cobol_code)
        recommendation['advanced_patterns'] = advanced_patterns
        
        # Adicionar estimativa de tempo de processamento
        processing_estimate = self._estimate_processing_time(recommendation, cobol_code)
        recommendation['processing_estimate'] = processing_estimate
        
        # Adicionar recomendações de otimização
        optimization_tips = self._get_optimization_tips(recommendation)
        recommendation['optimization_tips'] = optimization_tips
        
        # Adicionar nível de confiança aprimorado
        enhanced_confidence = self._calculate_enhanced_confidence(recommendation, advanced_patterns)
        recommendation['enhanced_confidence'] = enhanced_confidence
        
        return recommendation
    
    def _analyze_advanced_patterns(self, cobol_code: str) -> Dict[str, Any]:
        """
        Analisa padrões avançados no código COBOL.
        
        Args:
            cobol_code: Código COBOL
            
        Returns:
            Análise de padrões avançados
        """
        patterns = {
            'database_operations': {
                'sql_embedded': len(re.findall(r'EXEC\s+SQL', cobol_code, re.IGNORECASE)),
                'db2_calls': len(re.findall(r'DB2|SQLCA|SQLDA', cobol_code, re.IGNORECASE)),
                'file_operations': len(re.findall(r'READ|WRITE|REWRITE|DELETE', cobol_code, re.IGNORECASE))
            },
            'business_logic': {
                'calculations': len(re.findall(r'COMPUTE|ADD|SUBTRACT|MULTIPLY|DIVIDE', cobol_code, re.IGNORECASE)),
                'conditionals': len(re.findall(r'IF|EVALUATE|WHEN', cobol_code, re.IGNORECASE)),
                'loops': len(re.findall(r'PERFORM.*UNTIL|PERFORM.*TIMES', cobol_code, re.IGNORECASE))
            },
            'integration': {
                'cics_calls': len(re.findall(r'EXEC\s+CICS', cobol_code, re.IGNORECASE)),
                'mq_operations': len(re.findall(r'MQOPEN|MQPUT|MQGET|MQCLOSE', cobol_code, re.IGNORECASE)),
                'web_services': len(re.findall(r'SOAP|REST|HTTP|XML', cobol_code, re.IGNORECASE))
            },
            'error_handling': {
                'exception_handling': len(re.findall(r'ON\s+EXCEPTION|ON\s+ERROR|INVALID\s+KEY', cobol_code, re.IGNORECASE)),
                'status_checks': len(re.findall(r'FILE-STATUS|RETURN-CODE|SQLCODE', cobol_code, re.IGNORECASE))
            }
        }
        
        # Calcular complexidade por categoria
        total_operations = sum(
            sum(category.values()) for category in patterns.values()
        )
        
        return {
            'patterns': patterns,
            'total_operations': total_operations,
            'complexity_distribution': {
                category: sum(ops.values()) / total_operations if total_operations > 0 else 0
                for category, ops in patterns.items()
            }
        }
    
    def _estimate_processing_time(self, recommendation: Dict[str, Any], cobol_code: str) -> Dict[str, Any]:
        """
        Estima tempo de processamento baseado no modelo e complexidade.
        
        Args:
            recommendation: Recomendação de modelo
            cobol_code: Código COBOL
            
        Returns:
            Estimativa de tempo de processamento
        """
        model = recommendation.get('recommended_model', '')
        complexity = recommendation.get('complexity_score', 0)
        code_length = len(cobol_code)
        
        # Fatores base por modelo (em segundos por 1000 caracteres)
        model_factors = {
            'aws_claude_3_5_sonnet': 2.5,
            'aws_claude_3_5_haiku': 1.8,
            'amazon_nova_pro_v1': 3.2,
            'enhanced_mock': 0.5,
            'basic': 0.1
        }
        
        base_factor = model_factors.get(model, 2.0)
        
        # Ajustar por complexidade
        complexity_multiplier = 1 + (complexity * 2)
        
        # Calcular estimativa
        estimated_seconds = (code_length / 1000) * base_factor * complexity_multiplier
        
        return {
            'estimated_seconds': round(estimated_seconds, 2),
            'estimated_minutes': round(estimated_seconds / 60, 2),
            'factors': {
                'base_factor': base_factor,
                'complexity_multiplier': complexity_multiplier,
                'code_length': code_length
            }
        }
    
    def _get_optimization_tips(self, recommendation: Dict[str, Any]) -> List[str]:
        """
        Gera dicas de otimização baseadas na recomendação.
        
        Args:
            recommendation: Recomendação de modelo
            
        Returns:
            Lista de dicas de otimização
        """
        tips = []
        
        model = recommendation.get('recommended_model', '')
        complexity = recommendation.get('complexity_score', 0)
        
        # Dicas baseadas no modelo
        if 'claude' in model.lower():
            tips.append("Modelo Claude: Ideal para análise detalhada de regras de negócio")
            if complexity > 0.5:
                tips.append("Alta complexidade detectada: Claude 3.5 Sonnet recomendado para análise profunda")
        
        if 'haiku' in model.lower():
            tips.append("Modelo Haiku: Otimizado para velocidade e eficiência")
            tips.append("Considere usar para análises rápidas ou código menos complexo")
        
        if 'nova' in model.lower():
            tips.append("Modelo Nova: Excelente para análise de padrões modernos")
        
        # Dicas baseadas na complexidade
        if complexity < 0.2:
            tips.append("Baixa complexidade: Considere usar modelo mais rápido para otimizar custos")
        elif complexity > 0.7:
            tips.append("Alta complexidade: Use modelo mais robusto para melhor qualidade")
        
        # Dicas gerais
        tips.append("Use cache inteligente para evitar reprocessamento")
        tips.append("Considere processamento em lote para múltiplos arquivos")
        
        return tips
    
    def _calculate_enhanced_confidence(self, recommendation: Dict[str, Any], advanced_patterns: Dict[str, Any]) -> Dict[str, Any]:
        """
        Calcula nível de confiança aprimorado.
        
        Args:
            recommendation: Recomendação base
            advanced_patterns: Padrões avançados detectados
            
        Returns:
            Confiança aprimorada
        """
        base_confidence = recommendation.get('confidence', 0.5)
        
        # Fatores que aumentam a confiança
        confidence_factors = []
        
        # Padrões bem definidos aumentam confiança
        total_ops = advanced_patterns.get('total_operations', 0)
        if total_ops > 10:
            confidence_factors.append(('sufficient_patterns', 0.1))
        
        # Distribuição equilibrada de complexidade
        distribution = advanced_patterns.get('complexity_distribution', {})
        if len([v for v in distribution.values() if v > 0.1]) >= 2:
            confidence_factors.append(('balanced_complexity', 0.05))
        
        # Presença de padrões específicos
        patterns = advanced_patterns.get('patterns', {})
        if patterns.get('database_operations', {}).get('sql_embedded', 0) > 0:
            confidence_factors.append(('database_patterns', 0.08))
        
        if patterns.get('business_logic', {}).get('calculations', 0) > 5:
            confidence_factors.append(('business_logic', 0.06))
        
        # Calcular confiança final
        bonus = sum(factor[1] for factor in confidence_factors)
        enhanced_confidence = min(0.95, base_confidence + bonus)
        
        return {
            'base_confidence': base_confidence,
            'confidence_factors': confidence_factors,
            'enhanced_confidence': enhanced_confidence,
            'confidence_level': self._get_confidence_level(enhanced_confidence)
        }
    
    def _get_confidence_level(self, confidence: float) -> str:
        """
        Converte confiança numérica em nível descritivo.
        
        Args:
            confidence: Valor de confiança (0-1)
            
        Returns:
            Nível de confiança descritivo
        """
        if confidence >= 0.9:
            return "Muito Alta"
        elif confidence >= 0.8:
            return "Alta"
        elif confidence >= 0.7:
            return "Boa"
        elif confidence >= 0.6:
            return "Moderada"
        elif confidence >= 0.5:
            return "Baixa"
        else:
            return "Muito Baixa"
    
    def get_performance_metrics(self) -> Dict[str, Any]:
        """
        Obtém métricas de performance do seletor.
        
        Returns:
            Métricas de performance
        """
        total_requests = self.performance_metrics['cache_hits'] + self.performance_metrics['cache_misses']
        cache_hit_rate = (self.performance_metrics['cache_hits'] / total_requests * 100) if total_requests > 0 else 0
        
        avg_analysis_time = (
            self.performance_metrics['analysis_time'] / self.performance_metrics['recommendations_made']
            if self.performance_metrics['recommendations_made'] > 0 else 0
        )
        
        return {
            'cache_hit_rate': round(cache_hit_rate, 2),
            'total_recommendations': self.performance_metrics['recommendations_made'],
            'avg_analysis_time': round(avg_analysis_time, 3),
            'cache_enabled': self.cache_enabled,
            **self.performance_metrics
        }
    
    def clear_performance_metrics(self):
        """Limpa métricas de performance."""
        self.performance_metrics = {
            'cache_hits': 0,
            'cache_misses': 0,
            'analysis_time': 0,
            'recommendations_made': 0
        }
        logger.info("Métricas de performance limpas")

# Função de compatibilidade para manter interface existente
def create_enhanced_selector(config: Dict[str, Any]) -> EnhancedModelSelector:
    """
    Cria seletor aprimorado mantendo compatibilidade.
    
    Args:
        config: Configuração do sistema
        
    Returns:
        Instância do seletor aprimorado
    """
    return EnhancedModelSelector(config)
