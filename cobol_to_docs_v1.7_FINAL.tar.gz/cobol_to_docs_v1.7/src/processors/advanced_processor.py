"""
COBOL AI Engine v1.6 - Advanced Processor
Processador avançado consolidado integrado à estrutura principal.
Segue princípios SOLID para máxima extensibilidade.
"""

import logging
import os
import json
import time
from datetime import datetime
from typing import Dict, List, Any, Optional, Tuple
from pathlib import Path

from ..core.config import ConfigManager
from ..providers.provider_manager import ProviderManager
from ..rag.rag_integration import RAGIntegration
from ..parsers.cobol_parser_original import COBOLParser, CobolProgram, CobolBook
from ..analyzers.enhanced_cobol_analyzer import EnhancedCOBOLAnalyzer
from ..generators.advanced_report_generator import AdvancedReportGenerator
from ..utils.cost_calculator import CostCalculator


class IAdvancedProcessor:
    """Interface para processadores avançados (Interface Segregation Principle)."""
    
    def process_programs(self, programs: List[Tuple], options: Dict[str, Any]) -> Dict[str, Any]:
        """Processa lista de programas com opções específicas."""
        pass


class ConsolidatedAnalysisProcessor(IAdvancedProcessor):
    """
    Processador de análise consolidada (Single Responsibility Principle).
    Responsável por análises detalhadas e comparativas entre múltiplos modelos.
    """
    
    def __init__(self, config_manager: ConfigManager, output_dir: str):
        """Inicializa o processador de análise consolidada."""
        self.config_manager = config_manager
        self.output_dir = output_dir
        self.logger = logging.getLogger(__name__)
        
        # Componentes
        self.provider_manager = ProviderManager(config_manager.config)
        self.rag_integration = RAGIntegration(config_manager.config)
        self.cost_calculator = CostCalculator()
        
        # Estatísticas
        self.statistics = {
            'total_analyses': 0,
            'successful_analyses': 0,
            'failed_analyses': 0,
            'total_tokens': 0,
            'total_cost': 0.0,
            'processing_time': 0.0
        }
    
    def process_programs(self, programs: List[Tuple], options: Dict[str, Any]) -> Dict[str, Any]:
        """
        Processa programas com análise consolidada avançada.
        
        Args:
            programs: Lista de (file_path, CobolProgram, CobolBook)
            options: Opções de processamento
            
        Returns:
            Resultados consolidados
        """
        start_time = time.time()
        
        # Configurações
        models = options.get('models', ['enhanced_mock'])
        prompt_sets = options.get('prompt_sets', ['cadoc_deep_analysis'])
        generate_individual = options.get('generate_individual', True)
        generate_comparative = options.get('generate_comparative', True)
        
        results = {}
        
        try:
            # Processar cada programa
            for file_path, program, books in programs:
                program_results = self._process_single_program(
                    file_path, program, books, models, prompt_sets, options
                )
                results[program.name] = program_results
            
            # Gerar relatórios consolidados
            if generate_comparative and len(programs) > 1:
                comparative_results = self._generate_comparative_analysis(
                    programs, results, options
                )
                results['_comparative'] = comparative_results
            
            # Gerar relatório final
            final_report = self._generate_final_report(results, options)
            
            # Estatísticas finais
            self.statistics['processing_time'] = time.time() - start_time
            
            return {
                'success': True,
                'results': results,
                'final_report': final_report,
                'statistics': self.statistics,
                'output_directory': self.output_dir
            }
            
        except Exception as e:
            self.logger.error(f"Erro no processamento consolidado: {e}")
            return {
                'success': False,
                'error': str(e),
                'statistics': self.statistics
            }
    
    def _process_single_program(self, file_path: str, program: CobolProgram, 
                              books: List[CobolBook], models: List[str], 
                              prompt_sets: List[str], options: Dict[str, Any]) -> Dict[str, Any]:
        """Processa um único programa com múltiplos modelos e prompt sets."""
        program_results = {}
        
        for model in models:
            model_results = {}
            
            for prompt_set in prompt_sets:
                try:
                    # Análise específica
                    analysis_result = self._analyze_with_model_and_prompt(
                        program, books, model, prompt_set, options
                    )
                    
                    model_results[prompt_set] = analysis_result
                    
                    # Atualizar estatísticas
                    self.statistics['total_analyses'] += 1
                    if analysis_result.get('success', False):
                        self.statistics['successful_analyses'] += 1
                        self.statistics['total_tokens'] += analysis_result.get('tokens_used', 0)
                    else:
                        self.statistics['failed_analyses'] += 1
                    
                except Exception as e:
                    self.logger.error(f"Erro na análise de {program.name} com {model}/{prompt_set}: {e}")
                    model_results[prompt_set] = {
                        'success': False,
                        'error': str(e)
                    }
                    self.statistics['failed_analyses'] += 1
            
            program_results[model] = model_results
        
        return program_results
    
    def _analyze_with_model_and_prompt(self, program: CobolProgram, books: List[CobolBook], 
                                     model: str, prompt_set: str, 
                                     options: Dict[str, Any]) -> Dict[str, Any]:
        """Executa análise com modelo e prompt set específicos."""
        from ..core.prompt_manager_dual import DualPromptManager
        from ..generators.documentation_generator import DocumentationGenerator
        
        # Configurar componentes
        prompt_manager = DualPromptManager(self.config_manager.config, prompt_set)
        analyzer = EnhancedCOBOLAnalyzer(
            self.provider_manager, 
            prompt_manager, 
            self.rag_integration
        )
        
        # Criar diretório específico
        model_dir = os.path.join(
            self.output_dir, 
            f"model_{model.replace('/', '_').replace('-', '_')}",
            f"prompt_{prompt_set}"
        )
        os.makedirs(model_dir, exist_ok=True)
        
        # Executar análise
        start_time = time.time()
        analysis_result = analyzer.analyze_program(program, books, model)
        processing_time = time.time() - start_time
        
        # Gerar documentação
        doc_generator = DocumentationGenerator(model_dir)
        doc_path = doc_generator.generate_documentation(
            program, analysis_result, f"{program.name}_analise_funcional.md"
        )
        
        # Calcular custos
        cost_info = self.cost_calculator.calculate_request_cost(
            model, analysis_result.get('tokens_used', 0)
        )
        
        return {
            'success': analysis_result.get('success', False),
            'content': analysis_result.get('content', ''),
            'tokens_used': analysis_result.get('tokens_used', 0),
            'processing_time': processing_time,
            'cost': cost_info,
            'documentation_path': doc_path,
            'model': model,
            'prompt_set': prompt_set,
            'timestamp': datetime.now().isoformat()
        }
    
    def _generate_comparative_analysis(self, programs: List[Tuple], 
                                     results: Dict[str, Any], 
                                     options: Dict[str, Any]) -> Dict[str, Any]:
        """Gera análise comparativa entre programas e modelos."""
        self.logger.info("Gerando análise comparativa...")
        
        try:
            comparative_data = {
                'programs_comparison': {},
                'models_comparison': {},
                'performance_metrics': {},
                'quality_assessment': {}
            }
            
            # Comparação entre programas
            for file_path, program, books in programs:
                program_name = program.name
                program_results = results.get(program_name, {})
                
                comparative_data['programs_comparison'][program_name] = {
                    'file_path': file_path,
                    'program_size': len(program.content),
                    'copybooks_count': len(books),
                    'models_analyzed': list(program_results.keys()),
                    'total_analyses': sum(len(model_data) for model_data in program_results.values()),
                    'success_rate': self._calculate_success_rate(program_results)
                }
            
            # Comparação entre modelos
            all_models = set()
            for program_results in results.values():
                if isinstance(program_results, dict):
                    all_models.update(program_results.keys())
            
            for model in all_models:
                model_stats = self._calculate_model_statistics(model, results)
                comparative_data['models_comparison'][model] = model_stats
            
            # Métricas de performance
            comparative_data['performance_metrics'] = {
                'total_processing_time': self.statistics['processing_time'],
                'average_tokens_per_analysis': (
                    self.statistics['total_tokens'] / self.statistics['total_analyses']
                    if self.statistics['total_analyses'] > 0 else 0
                ),
                'success_rate': (
                    self.statistics['successful_analyses'] / self.statistics['total_analyses'] * 100
                    if self.statistics['total_analyses'] > 0 else 0
                )
            }
            
            # Salvar análise comparativa
            comparative_file = os.path.join(self.output_dir, "analise_comparativa.json")
            with open(comparative_file, 'w', encoding='utf-8') as f:
                json.dump(comparative_data, f, indent=2, ensure_ascii=False)
            
            self.logger.info(f"Análise comparativa salva em: {comparative_file}")
            return comparative_data
            
        except Exception as e:
            self.logger.error(f"Erro na análise comparativa: {e}")
            return {'error': str(e)}
    
    def _calculate_success_rate(self, program_results: Dict[str, Any]) -> float:
        """Calcula taxa de sucesso para um programa."""
        total = 0
        successful = 0
        
        for model_data in program_results.values():
            if isinstance(model_data, dict):
                for prompt_data in model_data.values():
                    if isinstance(prompt_data, dict):
                        total += 1
                        if prompt_data.get('success', False):
                            successful += 1
        
        return (successful / total * 100) if total > 0 else 0
    
    def _calculate_model_statistics(self, model: str, results: Dict[str, Any]) -> Dict[str, Any]:
        """Calcula estatísticas para um modelo específico."""
        total_analyses = 0
        successful_analyses = 0
        total_tokens = 0
        total_time = 0.0
        total_cost = 0.0
        
        for program_name, program_results in results.items():
            if program_name.startswith('_'):  # Skip meta results
                continue
                
            model_data = program_results.get(model, {})
            if isinstance(model_data, dict):
                for prompt_data in model_data.values():
                    if isinstance(prompt_data, dict):
                        total_analyses += 1
                        if prompt_data.get('success', False):
                            successful_analyses += 1
                        total_tokens += prompt_data.get('tokens_used', 0)
                        total_time += prompt_data.get('processing_time', 0)
                        cost_info = prompt_data.get('cost', {})
                        if isinstance(cost_info, dict):
                            total_cost += cost_info.get('total_cost', 0)
        
        return {
            'total_analyses': total_analyses,
            'successful_analyses': successful_analyses,
            'success_rate': (successful_analyses / total_analyses * 100) if total_analyses > 0 else 0,
            'total_tokens': total_tokens,
            'average_tokens': (total_tokens / total_analyses) if total_analyses > 0 else 0,
            'total_processing_time': total_time,
            'average_processing_time': (total_time / total_analyses) if total_analyses > 0 else 0,
            'total_cost': total_cost,
            'average_cost': (total_cost / total_analyses) if total_analyses > 0 else 0
        }
    
    def _generate_final_report(self, results: Dict[str, Any], options: Dict[str, Any]) -> str:
        """Gera relatório final consolidado."""
        try:
            report_generator = AdvancedReportGenerator()
            
            # Preparar dados para o relatório
            report_data = {
                'results': results,
                'statistics': self.statistics,
                'options': options,
                'timestamp': datetime.now().isoformat()
            }
            
            # Gerar relatório
            report_path = report_generator.generate_consolidated_report(
                report_data, self.output_dir
            )
            
            self.logger.info(f"Relatório final gerado: {report_path}")
            return report_path
            
        except Exception as e:
            self.logger.error(f"Erro na geração do relatório final: {e}")
            return ""


class DetailedAnalysisProcessor(IAdvancedProcessor):
    """
    Processador de análise detalhada (Single Responsibility Principle).
    Responsável por análises profundas de programas individuais.
    """
    
    def __init__(self, config_manager: ConfigManager, output_dir: str):
        """Inicializa o processador de análise detalhada."""
        self.config_manager = config_manager
        self.output_dir = output_dir
        self.logger = logging.getLogger(__name__)
        
        # Componentes específicos para análise detalhada
        self.provider_manager = ProviderManager(config_manager.config)
        self.rag_integration = RAGIntegration(config_manager.config)
    
    def process_programs(self, programs: List[Tuple], options: Dict[str, Any]) -> Dict[str, Any]:
        """
        Processa programas com análise detalhada individual.
        
        Args:
            programs: Lista de programas
            options: Opções de processamento
            
        Returns:
            Resultados detalhados
        """
        results = {}
        
        for file_path, program, books in programs:
            try:
                detailed_result = self._perform_detailed_analysis(
                    file_path, program, books, options
                )
                results[program.name] = detailed_result
                
            except Exception as e:
                self.logger.error(f"Erro na análise detalhada de {program.name}: {e}")
                results[program.name] = {
                    'success': False,
                    'error': str(e)
                }
        
        return {
            'success': True,
            'results': results,
            'output_directory': self.output_dir
        }
    
    def _perform_detailed_analysis(self, file_path: str, program: CobolProgram, 
                                 books: List[CobolBook], options: Dict[str, Any]) -> Dict[str, Any]:
        """Executa análise detalhada de um programa."""
        from ..analyzers.deep_business_analyzer import DeepBusinessAnalyzer
        from ..analyzers.technical_code_analyzer import TechnicalCodeAnalyzer
        from ..core.detailed_prompt_generator import DetailedPromptGenerator
        
        # Componentes especializados
        business_analyzer = DeepBusinessAnalyzer(self.config_manager.config)
        technical_analyzer = TechnicalCodeAnalyzer()
        prompt_generator = DetailedPromptGenerator(self.config_manager.config)
        
        # Análise de regras de negócio
        business_rules = business_analyzer.extract_business_rules(program.content)
        
        # Análise técnica
        technical_analysis = technical_analyzer.analyze_technical_codes(
            program.content, ""
        )
        
        # Gerar prompt detalhado
        detailed_prompt = prompt_generator.generate_detailed_prompt(
            program, books, business_rules, technical_analysis
        )
        
        # Criar diretório específico
        program_dir = os.path.join(self.output_dir, f"detailed_{program.name}")
        os.makedirs(program_dir, exist_ok=True)
        
        # Salvar análises
        analyses = {
            'business_rules': business_rules,
            'technical_analysis': technical_analysis,
            'detailed_prompt': detailed_prompt,
            'program_info': {
                'name': program.name,
                'file_path': file_path,
                'size': len(program.content),
                'copybooks': len(books)
            }
        }
        
        # Salvar resultados
        analysis_file = os.path.join(program_dir, f"{program.name}_analise_detalhada.json")
        with open(analysis_file, 'w', encoding='utf-8') as f:
            json.dump(analyses, f, indent=2, ensure_ascii=False)
        
        return {
            'success': True,
            'analyses': analyses,
            'output_file': analysis_file,
            'output_directory': program_dir
        }


class ProcessorFactory:
    """
    Fábrica de processadores (Factory Pattern + Dependency Inversion).
    Permite extensão fácil com novos tipos de processadores.
    """
    
    @staticmethod
    def create_processor(processor_type: str, config_manager: ConfigManager, 
                        output_dir: str) -> Optional[IAdvancedProcessor]:
        """
        Cria processador baseado no tipo especificado.
        
        Args:
            processor_type: Tipo do processador ('consolidated', 'detailed')
            config_manager: Gerenciador de configuração
            output_dir: Diretório de saída
            
        Returns:
            Instância do processador ou None se tipo inválido
        """
        processors = {
            'consolidated': ConsolidatedAnalysisProcessor,
            'detailed': DetailedAnalysisProcessor
        }
        
        processor_class = processors.get(processor_type)
        if processor_class:
            return processor_class(config_manager, output_dir)
        
        return None


def create_advanced_processor(processor_type: str, config_path: str, 
                            output_dir: str) -> Optional[IAdvancedProcessor]:
    """
    Função de conveniência para criar processadores avançados.
    
    Args:
        processor_type: Tipo do processador
        config_path: Caminho do arquivo de configuração
        output_dir: Diretório de saída
        
    Returns:
        Instância do processador
    """
    config_manager = ConfigManager(config_path)
    return ProcessorFactory.create_processor(processor_type, config_manager, output_dir)
