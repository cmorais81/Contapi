"""
COBOL AI Engine v2.7.0 - Mock Provider Consolidado
Provider simulado com análises aprimoradas baseadas em feedback de especialista.
"""

import logging
import time
import random
import re
from typing import Dict, Any, Optional, List
from datetime import datetime

from .base_provider import BaseProvider, AIRequest, AIResponse


class MockProvider(BaseProvider):
    """
    Provider simulado consolidado com análises técnicas aprimoradas.
    
    Melhorias baseadas em feedback de especialista:
    - Análise precisa de copybooks (COPY vs ++INCLUDE)
    - Identificação detalhada de regras de negócio
    - Detecção de interfaces ativas/desativadas
    - Análise técnica sem termos genéricos
    - Tratamento adequado de códigos sem comentários
    """
    
    def __init__(self, config: Dict[str, Any]):
        """Inicializa o Mock Provider consolidado."""
        super().__init__(config)
        self.logger = logging.getLogger(__name__)
        
        # Determinar modo baseado na configuração
        enhanced_config = config.get('providers', {}).get('enhanced_mock', {})
        basic_config = config.get('providers', {}).get('basic', {})
        
        if enhanced_config.get('enabled', False):
            self.mode = 'enhanced'
            self.name = "enhanced_mock"
            provider_config = enhanced_config
        else:
            self.mode = 'basic'
            self.name = "basic"
            provider_config = basic_config
        
        # Sempre habilitado (fallback garantido)
        self.enabled = True
        
        # Configurações do modelo
        models_config = provider_config.get('models', {})
        if models_config:
            first_model_key = list(models_config.keys())[0]
            model_config = models_config[first_model_key]
            self.model = model_config.get('name', f'{self.mode}-mock-gpt-4')
            self.max_tokens = model_config.get('max_tokens', 8192 if self.mode == 'enhanced' else 4096)
            self.temperature = model_config.get('temperature', 0.1 if self.mode == 'enhanced' else 0.0)
            self.timeout = model_config.get('timeout', 5 if self.mode == 'enhanced' else 1)
        else:
            # Valores padrão
            self.model = f'{self.mode}-mock-gpt-4'
            self.max_tokens = 8192 if self.mode == 'enhanced' else 4096
            self.temperature = 0.1 if self.mode == 'enhanced' else 0.0
            self.timeout = 5 if self.mode == 'enhanced' else 1
        
        self.response_delay = self.timeout * 0.1
        self.logger.info(f"Mock Provider consolidado configurado: modo={self.mode}, modelo={self.model}")
    
    def is_available(self) -> bool:
        """Verifica se o provider está disponível."""
        return self.enabled
    
    def analyze(self, request: AIRequest) -> AIResponse:
        """Realiza análise simulada com melhorias técnicas."""
        try:
            # Simular tempo de processamento
            time.sleep(self.response_delay)
            
            # Análise técnica aprimorada do código
            code_analysis = self._analyze_cobol_code(request.program_code)
            
            # Gerar resposta baseada na análise técnica
            content = self._generate_enhanced_response(
                request.program_name,
                request.program_code,
                code_analysis,
                request.context
            )
            
            # Calcular tokens
            tokens_input = len(request.prompt.split())
            tokens_output = len(content.split())
            total_tokens = tokens_input + tokens_output
            
            return AIResponse(
                success=True,
                content=content,
                tokens_used=total_tokens,
                model=self.model,
                provider=self.name,
                prompts_used={
                    'system_prompt': request.prompt,
                    'program_code': request.program_code,
                    'program_name': request.program_name
                },
                metadata={
                    'analysis_type': 'enhanced_technical',
                    'tokens_input': tokens_input,
                    'tokens_output': tokens_output,
                    'response_time': self.response_delay,
                    'timestamp': time.time(),
                    'code_analysis': code_analysis
                }
            )
            
        except Exception as e:
            self.logger.error(f"Erro no Mock Provider: {str(e)}")
            return AIResponse(
                success=False,
                content="",
                tokens_used=0,
                model=self.model,
                provider=self.name,
                error_message=str(e)
            )
    
    def _analyze_cobol_code(self, code: str) -> Dict[str, Any]:
        """Análise técnica aprimorada do código COBOL."""
        analysis = {
            'copybooks': self._analyze_copybooks(code),
            'business_rules': self._identify_business_rules(code),
            'interfaces': self._analyze_interfaces(code),
            'data_structures': self._analyze_data_structures(code),
            'program_flow': self._analyze_program_flow(code),
            'comments_analysis': self._analyze_comments(code),
            'technical_complexity': self._calculate_technical_complexity(code)
        }
        return analysis
    
    def _analyze_copybooks(self, code: str) -> Dict[str, Any]:
        """Análise precisa de copybooks (COPY vs ++INCLUDE)."""
        copy_pattern = r'COPY\s+([A-Z0-9\-]+)'
        include_pattern = r'\+\+INCLUDE\s+([A-Z0-9\-]+)'
        
        copy_statements = re.findall(copy_pattern, code, re.IGNORECASE)
        include_statements = re.findall(include_pattern, code, re.IGNORECASE)
        
        return {
            'copy_statements': copy_statements,
            'include_statements': include_statements,
            'total_copybooks': len(copy_statements) + len(include_statements),
            'copy_vs_include': {
                'copy_count': len(copy_statements),
                'include_count': len(include_statements),
                'predominant_type': 'COPY' if len(copy_statements) > len(include_statements) else '++INCLUDE' if include_statements else 'NONE'
            }
        }
    
    def _identify_business_rules(self, code: str) -> List[Dict[str, str]]:
        """Identificação detalhada de regras de negócio."""
        rules = []
        
        # Padrões de regras de negócio
        validation_patterns = [
            (r'IF\s+([A-Z0-9\-]+)\s*(=|>|<|NOT)\s*([A-Z0-9\-\'"]+)', 'Validação de Campo'),
            (r'EVALUATE\s+([A-Z0-9\-]+)', 'Regra de Decisão'),
            (r'PERFORM\s+([A-Z0-9\-]+)\s+UNTIL', 'Processamento Iterativo'),
            (r'CALL\s+[\'"]([A-Z0-9\-]+)[\'"]', 'Chamada de Subprograma'),
            (r'MOVE\s+([A-Z0-9\-]+)\s+TO\s+([A-Z0-9\-]+)', 'Transferência de Dados')
        ]
        
        for pattern, rule_type in validation_patterns:
            matches = re.findall(pattern, code, re.IGNORECASE | re.MULTILINE)
            for match in matches:
                if isinstance(match, tuple):
                    rule_description = f"{rule_type}: {' '.join(match)}"
                else:
                    rule_description = f"{rule_type}: {match}"
                
                rules.append({
                    'type': rule_type,
                    'description': rule_description,
                    'pattern': pattern
                })
        
        return rules
    
    def _analyze_interfaces(self, code: str) -> Dict[str, Any]:
        """Análise de interfaces ativas e desativadas."""
        interfaces = {
            'active_interfaces': [],
            'inactive_interfaces': [],
            'commented_interfaces': []
        }
        
        # Padrões de interface
        interface_patterns = [
            r'(MZV\d+E)\s*',  # Padrão MZV seguido de números e E
            r'([A-Z]{2,4}\d{4,6}[A-Z]?)\s*',  # Padrões de interface genéricos
        ]
        
        lines = code.split('\n')
        for line_num, line in enumerate(lines, 1):
            line_stripped = line.strip()
            
            # Verificar se linha está comentada
            is_commented = line_stripped.startswith('*') or line_stripped.startswith('//')
            
            for pattern in interface_patterns:
                matches = re.findall(pattern, line, re.IGNORECASE)
                for match in matches:
                    interface_info = {
                        'name': match,
                        'line': line_num,
                        'context': line_stripped
                    }
                    
                    if is_commented:
                        interfaces['commented_interfaces'].append(interface_info)
                        interfaces['inactive_interfaces'].append(interface_info)
                    else:
                        interfaces['active_interfaces'].append(interface_info)
        
        return interfaces
    
    def _analyze_data_structures(self, code: str) -> Dict[str, Any]:
        """Análise detalhada de estruturas de dados."""
        structures = {
            'working_storage': [],
            'linkage_section': [],
            'file_section': [],
            'level_structures': {}
        }
        
        # Padrões de estruturas de dados
        ws_pattern = r'^\s*(\d{2})\s+([A-Z0-9\-]+).*PIC\s+([X9V\(\)S\+\-\.]+)'
        linkage_pattern = r'LINKAGE\s+SECTION'
        file_pattern = r'FILE\s+SECTION'
        
        lines = code.split('\n')
        current_section = None
        
        for line in lines:
            line_stripped = line.strip()
            
            if re.search(r'WORKING-STORAGE\s+SECTION', line_stripped, re.IGNORECASE):
                current_section = 'working_storage'
            elif re.search(linkage_pattern, line_stripped, re.IGNORECASE):
                current_section = 'linkage_section'
            elif re.search(file_pattern, line_stripped, re.IGNORECASE):
                current_section = 'file_section'
            
            # Analisar definições de dados
            ws_match = re.search(ws_pattern, line_stripped, re.IGNORECASE)
            if ws_match and current_section:
                level, name, pic = ws_match.groups()
                structures[current_section].append({
                    'level': level,
                    'name': name,
                    'picture': pic,
                    'line': line_stripped
                })
        
        return structures
    
    def _analyze_program_flow(self, code: str) -> Dict[str, Any]:
        """Análise do fluxo do programa."""
        flow = {
            'paragraphs': [],
            'performs': [],
            'gotos': [],
            'stops': []
        }
        
        # Padrões de fluxo
        paragraph_pattern = r'^([A-Z0-9\-]+)\.\s*$'
        perform_pattern = r'PERFORM\s+([A-Z0-9\-]+)'
        goto_pattern = r'GO\s+TO\s+([A-Z0-9\-]+)'
        stop_pattern = r'STOP\s+RUN'
        
        lines = code.split('\n')
        for line_num, line in enumerate(lines, 1):
            line_stripped = line.strip()
            
            # Parágrafos
            para_match = re.search(paragraph_pattern, line_stripped)
            if para_match:
                flow['paragraphs'].append({
                    'name': para_match.group(1),
                    'line': line_num
                })
            
            # PERFORMs
            perform_matches = re.findall(perform_pattern, line_stripped, re.IGNORECASE)
            for match in perform_matches:
                flow['performs'].append({
                    'target': match,
                    'line': line_num
                })
            
            # GOTOs
            goto_matches = re.findall(goto_pattern, line_stripped, re.IGNORECASE)
            for match in goto_matches:
                flow['gotos'].append({
                    'target': match,
                    'line': line_num
                })
            
            # STOPs
            if re.search(stop_pattern, line_stripped, re.IGNORECASE):
                flow['stops'].append({'line': line_num})
        
        return flow
    
    def _analyze_comments(self, code: str) -> Dict[str, Any]:
        """Análise de comentários no código."""
        lines = code.split('\n')
        total_lines = len(lines)
        comment_lines = 0
        code_lines = 0
        blank_lines = 0
        
        for line in lines:
            line_stripped = line.strip()
            if not line_stripped:
                blank_lines += 1
            elif line_stripped.startswith('*') or line_stripped.startswith('//'):
                comment_lines += 1
            else:
                code_lines += 1
        
        comment_ratio = (comment_lines / total_lines * 100) if total_lines > 0 else 0
        
        return {
            'total_lines': total_lines,
            'comment_lines': comment_lines,
            'code_lines': code_lines,
            'blank_lines': blank_lines,
            'comment_ratio': round(comment_ratio, 2),
            'documentation_level': self._assess_documentation_level(comment_ratio)
        }
    
    def _assess_documentation_level(self, comment_ratio: float) -> str:
        """Avalia o nível de documentação baseado na proporção de comentários."""
        if comment_ratio >= 20:
            return "Bem documentado"
        elif comment_ratio >= 10:
            return "Moderadamente documentado"
        elif comment_ratio >= 5:
            return "Pouco documentado"
        else:
            return "Sem documentação adequada"
    
    def _calculate_technical_complexity(self, code: str) -> Dict[str, Any]:
        """Calcula complexidade técnica específica."""
        complexity_factors = {
            'nested_ifs': len(re.findall(r'IF.*IF', code, re.IGNORECASE)),
            'evaluate_statements': len(re.findall(r'EVALUATE', code, re.IGNORECASE)),
            'perform_statements': len(re.findall(r'PERFORM', code, re.IGNORECASE)),
            'call_statements': len(re.findall(r'CALL', code, re.IGNORECASE)),
            'goto_statements': len(re.findall(r'GO\s+TO', code, re.IGNORECASE)),
            'file_operations': len(re.findall(r'(READ|WRITE|REWRITE|DELETE)', code, re.IGNORECASE))
        }
        
        # Calcular score de complexidade
        complexity_score = (
            complexity_factors['nested_ifs'] * 3 +
            complexity_factors['evaluate_statements'] * 2 +
            complexity_factors['perform_statements'] * 1 +
            complexity_factors['call_statements'] * 2 +
            complexity_factors['goto_statements'] * 4 +
            complexity_factors['file_operations'] * 2
        )
        
        # Classificar complexidade
        if complexity_score <= 10:
            complexity_level = "Baixa"
        elif complexity_score <= 25:
            complexity_level = "Moderada"
        elif complexity_score <= 50:
            complexity_level = "Alta"
        else:
            complexity_level = "Muito Alta"
        
        return {
            'factors': complexity_factors,
            'score': complexity_score,
            'level': complexity_level
        }
    
    def _generate_enhanced_response(self, program_name: str, code: str, 
                                  analysis: Dict[str, Any], context: Dict[str, Any]) -> str:
        """Gera resposta aprimorada baseada na análise técnica."""
        
        if self.mode == 'basic':
            return self._generate_basic_response(program_name, analysis)
        
        return self._generate_detailed_response(program_name, code, analysis, context)
    
    def _generate_basic_response(self, program_name: str, analysis: Dict[str, Any]) -> str:
        """Gera resposta básica garantida."""
        return f"""## Análise Técnica Detalhada

### Estrutura do Programa {program_name}

#### Informações Básicas
- **Linhas de código**: {analysis['comments_analysis']['code_lines']}
- **Tamanho estimado**: {len(program_name) * 10} caracteres
- **Divisões identificadas**: 2
- **Seções encontradas**: 0

#### Estruturas COBOL Identificadas

**Divisões Principais:**
- IDENTIFICATION DIVISION.
- PROCEDURE DIVISION.

**Seções de Código:**
- Seções de processamento principal

**Arquivos e Datasets:**
- Arquivos de entrada e saída padrão

#### Componentes Técnicos
- **Controle de Arquivos**: Implementa abertura, leitura e fechamento controlado
- **Processamento Principal**: Lógica de negócio estruturada em parágrafos
- **Validações Implementadas**: Verificações de dados e tratamento de erros
- **Estruturas de Dados**: Variáveis e registros organizados hierarquicamente

#### Padrões de Codificação
O programa segue convenções COBOL padrão com estrutura modular e organização lógica das funcionalidades."""
    
    def _generate_detailed_response(self, program_name: str, code: str, 
                                  analysis: Dict[str, Any], context: Dict[str, Any]) -> str:
        """Gera resposta detalhada com análise técnica aprimorada."""
        
        copybooks = analysis['copybooks']
        business_rules = analysis['business_rules']
        interfaces = analysis['interfaces']
        data_structures = analysis['data_structures']
        program_flow = analysis['program_flow']
        comments = analysis['comments_analysis']
        complexity = analysis['technical_complexity']
        
        response = f"""## Análise Funcional Detalhada - {program_name}

### 1. Estrutura Técnica do Programa

#### Métricas de Código
- **Total de linhas**: {comments['total_lines']}
- **Linhas de código**: {comments['code_lines']}
- **Linhas de comentário**: {comments['comment_lines']} ({comments['comment_ratio']}%)
- **Nível de documentação**: {comments['documentation_level']}

#### Complexidade Técnica
- **Nível de complexidade**: {complexity['level']}
- **Score de complexidade**: {complexity['score']}
- **Fatores de complexidade**:
  - IFs aninhados: {complexity['factors']['nested_ifs']}
  - Statements EVALUATE: {complexity['factors']['evaluate_statements']}
  - Statements PERFORM: {complexity['factors']['perform_statements']}
  - Chamadas CALL: {complexity['factors']['call_statements']}
  - Statements GOTO: {complexity['factors']['goto_statements']}
  - Operações de arquivo: {complexity['factors']['file_operations']}

### 2. Análise de Copybooks e Includes

#### Estruturas de Dados Externas
"""
        
        if copybooks['total_copybooks'] > 0:
            response += f"""- **Total de copybooks**: {copybooks['total_copybooks']}
- **Tipo predominante**: {copybooks['copy_vs_include']['predominant_type']}
- **COPY statements**: {copybooks['copy_vs_include']['copy_count']}
- **++INCLUDE statements**: {copybooks['copy_vs_include']['include_count']}

**Copybooks identificados:**
"""
            for copy_name in copybooks['copy_statements']:
                response += f"  - COPY {copy_name}\n"
            for include_name in copybooks['include_statements']:
                response += f"  - ++INCLUDE {include_name}\n"
        else:
            response += "- **Nenhum copybook identificado** - Programa autocontido\n"
        
        response += f"""
### 3. Regras de Negócio Identificadas

#### Análise de Lógica de Negócio
"""
        
        if business_rules:
            response += f"- **Total de regras identificadas**: {len(business_rules)}\n\n"
            
            rule_types = {}
            for rule in business_rules:
                rule_type = rule['type']
                if rule_type not in rule_types:
                    rule_types[rule_type] = []
                rule_types[rule_type].append(rule['description'])
            
            for rule_type, descriptions in rule_types.items():
                response += f"**{rule_type}:**\n"
                for desc in descriptions[:3]:  # Limitar a 3 exemplos
                    response += f"  - {desc}\n"
                if len(descriptions) > 3:
                    response += f"  - ... e mais {len(descriptions) - 3} regras\n"
                response += "\n"
        else:
            response += "- **Regras de negócio**: Análise necessária do código fonte para identificação precisa\n"
        
        response += f"""
### 4. Interfaces e Integrações

#### Análise de Interfaces Externas
"""
        
        active_interfaces = interfaces['active_interfaces']
        inactive_interfaces = interfaces['inactive_interfaces']
        
        if active_interfaces or inactive_interfaces:
            response += f"""- **Interfaces ativas**: {len(active_interfaces)}
- **Interfaces desativadas**: {len(inactive_interfaces)}

"""
            if active_interfaces:
                response += "**Interfaces Ativas:**\n"
                for interface in active_interfaces[:5]:  # Limitar a 5
                    response += f"  - {interface['name']} (linha {interface['line']})\n"
            
            if inactive_interfaces:
                response += "\n**Interfaces Desativadas/Comentadas:**\n"
                for interface in inactive_interfaces[:5]:  # Limitar a 5
                    response += f"  - {interface['name']} (linha {interface['line']}) - INATIVA\n"
        else:
            response += "- **Interfaces**: Nenhuma interface externa identificada no código fonte\n"
        
        response += f"""
### 5. Estruturas de Dados

#### Organização de Dados
"""
        
        ws_count = len(data_structures['working_storage'])
        linkage_count = len(data_structures['linkage_section'])
        file_count = len(data_structures['file_section'])
        
        response += f"""- **Working Storage**: {ws_count} variáveis definidas
- **Linkage Section**: {linkage_count} parâmetros de entrada
- **File Section**: {file_count} estruturas de arquivo

"""
        
        if ws_count > 0:
            response += "**Principais variáveis Working Storage:**\n"
            for var in data_structures['working_storage'][:5]:
                response += f"  - {var['level']} {var['name']} PIC {var['picture']}\n"
        
        response += f"""
### 6. Fluxo de Execução

#### Estrutura de Controle
- **Parágrafos definidos**: {len(program_flow['paragraphs'])}
- **Chamadas PERFORM**: {len(program_flow['performs'])}
- **Statements GOTO**: {len(program_flow['gotos'])}
- **Pontos de parada**: {len(program_flow['stops'])}

"""
        
        if program_flow['paragraphs']:
            response += "**Principais parágrafos:**\n"
            for para in program_flow['paragraphs'][:5]:
                response += f"  - {para['name']} (linha {para['line']})\n"
        
        response += f"""
### 7. Conhecimento Extraído para Aprendizado

#### Padrões Técnicos Identificados
- **Arquitetura**: Programa COBOL estruturado com {complexity['level'].lower()} complexidade técnica
- **Padrões de codificação**: {comments['documentation_level'].lower()} seguindo convenções mainframe
- **Integração**: {'Com interfaces externas' if active_interfaces else 'Programa autocontido'}
- **Manutenibilidade**: Baseada na estrutura modular e nível de documentação

#### Características Específicas
- **Tipo de processamento**: {'Batch com múltiplas interfaces' if active_interfaces else 'Processamento interno'}
- **Gestão de dados**: {'Uso de copybooks externos' if copybooks['total_copybooks'] > 0 else 'Estruturas internas'}
- **Controle de fluxo**: {'Estruturado com parágrafos' if program_flow['paragraphs'] else 'Linear simples'}

### Conclusão da Análise

O programa {program_name} apresenta características técnicas específicas que indicam {'um sistema de integração' if active_interfaces else 'processamento interno'} com {'alta' if complexity['level'] in ['Alta', 'Muito Alta'] else 'baixa'} complexidade operacional. A análise técnica revela padrões de desenvolvimento {'bem estruturados' if comments['comment_ratio'] > 10 else 'que necessitam melhor documentação'} adequados ao ambiente mainframe.
"""
        
        return response
