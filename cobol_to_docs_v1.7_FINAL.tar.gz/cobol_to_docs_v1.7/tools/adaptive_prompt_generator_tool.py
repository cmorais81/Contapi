#!/usr/bin/env python3
"""
Ferramenta de Geração de Prompts Adaptativos
Gera prompts que se adaptam à complexidade e domínio do código COBOL.
"""

import os
import sys
import argparse
import logging
import json
from typing import Dict, List, Any, Optional

# Adicionar diretório pai ao path para importar módulos do projeto
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Importar módulos do projeto
from src.core.adaptive_prompt_generator import AdaptivePromptGenerator

def generate_adaptive_prompt(input_file: str, output_file: str = None, 
                           model: str = 'aws_claude_3_5_sonnet') -> Dict[str, Any]:
    """
    Gera um prompt adaptativo para o código COBOL fornecido.
    
    Args:
        input_file: Arquivo de código COBOL de entrada
        output_file: Arquivo de saída para o prompt (opcional)
        model: Nome do modelo para o qual gerar o prompt
        
    Returns:
        Dicionário com o prompt gerado e metadados
    """
    try:
        # Ler o código COBOL
        with open(input_file, 'r', encoding='utf-8') as f:
            cobol_code = f.read()
        
        # Criar gerador de prompts adaptativos
        generator = AdaptivePromptGenerator()
        
        # Analisar complexidade e domínio
        complexity = generator.analyze_complexity(cobol_code)
        domain = generator.identify_domain(cobol_code)
        
        # Gerar prompt adaptativo
        prompt = generator.generate_prompt(cobol_code, model, complexity, domain)
        
        # Criar resultado
        result = {
            'prompt': prompt,
            'metadata': {
                'complexity': complexity,
                'domain': domain,
                'model': model,
                'input_file': input_file
            }
        }
        
        # Salvar resultado se output_file for especificado
        if output_file:
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(prompt)
            
            # Salvar metadados
            metadata_file = output_file + '.metadata.json'
            with open(metadata_file, 'w', encoding='utf-8') as f:
                json.dump(result['metadata'], f, indent=2)
            
            print(f"Prompt adaptativo gerado com sucesso: {output_file}")
            print(f"Metadados salvos em: {metadata_file}")
        
        return result
        
    except Exception as e:
        print(f"Erro ao gerar prompt adaptativo: {e}")
        return {'error': str(e)}


if __name__ == "__main__":
    # Configuração de logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Argumentos de linha de comando
    parser = argparse.ArgumentParser(description='Gerar prompt adaptativo para código COBOL')
    parser.add_argument('--input', required=True, help='Arquivo de código COBOL de entrada')
    parser.add_argument('--output', default=None, help='Arquivo de saída para o prompt')
    parser.add_argument('--model', default='aws_claude_3_5_sonnet', help='Nome do modelo')
    
    args = parser.parse_args()
    
    # Determinar arquivo de saída se não especificado
    output_file = args.output
    if not output_file:
        base_name = os.path.basename(args.input)
        name_without_ext = os.path.splitext(base_name)[0]
        output_file = f"prompt_adaptativo_{name_without_ext}.txt"
    
    # Gerar prompt adaptativo
    result = generate_adaptive_prompt(
        args.input,
        output_file,
        args.model
    )
    
    if 'error' not in result:
        print(f"Geração de prompt adaptativo concluída com sucesso!")
        print(f"Complexidade: {result['metadata']['complexity']}/10")
        print(f"Domínio: {result['metadata']['domain']}")
    else:
        print(f"Erro na geração de prompt adaptativo: {result['error']}")
        sys.exit(1)
