#!/usr/bin/env python3
"""
CLI para COBOL to Docs v1.6
Interface de linha de comando simplificada
"""

import sys
import os
import argparse
from pathlib import Path

# Adicionar src ao path para imports
sys.path.insert(0, str(Path(__file__).parent.parent))

def main():
    """Função principal do CLI."""
    parser = argparse.ArgumentParser(
        description='COBOL to Docs v1.6 - Análise e documentação automatizada de programas COBOL',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Exemplos de uso:
  cobol-to-docs --file programa.cbl
  cobol-to-docs --files lista_arquivos.txt --model enhanced_mock
  cobol-to-docs --file programa.cbl --output ./docs --model github_copilot
  
Provedores disponíveis:
  - luzia (LuzIA - requer credenciais)
  - enhanced_mock (Mock avançado - sempre disponível)
  - basic (Fallback básico)
  - github_copilot (GitHub Copilot - requer token)
        """
    )
    
    # Argumentos principais
    parser.add_argument('--file', '--fonte', dest='file',
                       help='Arquivo COBOL único para análise')
    parser.add_argument('--files', '--fontes', dest='files',
                       help='Lista de arquivos ou diretório com programas COBOL')
    parser.add_argument('--model', '--models', dest='model', default='enhanced_mock',
                       help='Modelo a usar (padrão: enhanced_mock)')
    parser.add_argument('--output', '-o', dest='output',
                       help='Diretório de saída (padrão: analise_TIMESTAMP)')
    parser.add_argument('--config', dest='config',
                       help='Arquivo de configuração (padrão: config/config.yaml)')
    
    # Opções avançadas
    parser.add_argument('--advanced', action='store_true',
                       help='Ativar análises avançadas')
    parser.add_argument('--generate-prompts', action='store_true',
                       help='Gerar prompts adaptativos')
    parser.add_argument('--parallel', action='store_true',
                       help='Usar processamento paralelo')
    parser.add_argument('--validate', action='store_true',
                       help='Ativar validação anti-alucinação')
    parser.add_argument('--no-cache', action='store_true',
                       help='Desabilitar cache inteligente')
    parser.add_argument('--no-rag', action='store_true',
                       help='Desabilitar aprendizado RAG')
    
    # Configurações
    parser.add_argument('--max-workers', type=int, default=4,
                       help='Número máximo de workers paralelos')
    parser.add_argument('--log-level', choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'],
                       default='INFO', help='Nível de log')
    parser.add_argument('--pdf', action='store_true',
                       help='Gerar relatórios HTML/PDF')
    parser.add_argument('--save-messages', action='store_true',
                       help='Salvar mensagens enviadas/recebidas')
    
    args = parser.parse_args()
    
    # Validar argumentos
    if not args.file and not args.files:
        parser.error("É necessário especificar --file ou --files")
    
    # Importar e executar main.py
    try:
        from main import main as main_function
        
        # Converter argumentos para formato do main.py
        sys.argv = ['main.py']
        
        if args.file:
            sys.argv.extend(['--fontes', args.file])
        elif args.files:
            sys.argv.extend(['--fontes', args.files])
        
        sys.argv.extend(['--models', args.model])
        
        if args.output:
            sys.argv.extend(['--output', args.output])
        if args.config:
            sys.argv.extend(['--config', args.config])
        if args.advanced:
            sys.argv.append('--advanced')
        if args.generate_prompts:
            sys.argv.append('--generate-prompts')
        if args.parallel:
            sys.argv.append('--parallel')
        if args.validate:
            sys.argv.append('--validate')
        if args.no_cache:
            sys.argv.append('--no-cache')
        if args.no_rag:
            sys.argv.append('--no-rag')
        
        sys.argv.extend(['--max-workers', str(args.max_workers)])
        sys.argv.extend(['--log-level', args.log_level])
        
        if args.pdf:
            sys.argv.append('--pdf')
        if args.save_messages:
            sys.argv.append('--save-messages')
        
        # Executar main
        return main_function()
        
    except ImportError as e:
        print(f"Erro ao importar main.py: {e}")
        print("Certifique-se de que o COBOL to Docs está instalado corretamente.")
        return 1
    except Exception as e:
        print(f"Erro na execução: {e}")
        return 1

if __name__ == '__main__':
    sys.exit(main())
