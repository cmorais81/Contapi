# Manual de Instalação - COBOL to Docs v1.6

Guia completo para instalação e configuração do sistema COBOL to Docs v1.6 com todas as funcionalidades e dependências opcionais.

## Requisitos do Sistema

### Requisitos Mínimos
- **Sistema Operacional**: Linux, Windows 10+, macOS 10.14+
- **Python**: 3.8 ou superior (recomendado 3.11+)
- **Memória RAM**: 4GB (8GB recomendado)
- **Espaço em Disco**: 2GB livres
- **Conexão Internet**: Necessária para provedores de IA

### Requisitos Recomendados
- **Python**: 3.11+
- **Memória RAM**: 16GB
- **Processador**: Multi-core (para processamento paralelo)
- **SSD**: Para melhor performance do cache

## Métodos de Instalação

### 1. Instalação Básica (Funcionalidade Mínima)

Esta instalação inclui apenas as dependências essenciais para funcionamento básico.

```bash
# Clonar ou extrair o projeto
cd cobol_to_docs_v1.6

# Instalar dependências básicas
pip install -r requirements.txt

# Verificar instalação
python -c "from cobol_to_docs import check_system_status; print(check_system_status())"
```

**Funcionalidades Disponíveis:**
- Análise COBOL com LuzIA
- Sistema RAG básico
- Interface linha de comando
- Cache básico

### 2. Instalação Completa (Recomendada)

Esta instalação inclui todas as dependências opcionais para funcionalidade máxima.

```bash
# Instalar todas as dependências
pip install -r requirements-full.txt

# Verificar instalação completa
python -c "
from cobol_to_docs import COBOLAnalyzer
analyzer = COBOLAnalyzer()
print('Modelos disponíveis:', analyzer.get_available_models())
print('Status dependências:', analyzer.get_dependency_status())
"
```

**Funcionalidades Disponíveis:**
- Todos os provedores de IA (OpenAI, Bedrock, Anthropic, etc.)
- RAG avançado com busca vetorial
- Processamento paralelo otimizado
- API REST e Dashboard Web
- Cache inteligente completo
- Modelos locais (opcional)

### 3. Instalação Seletiva

Instale apenas as dependências que você precisa:

```bash
# Instalar dependências básicas
pip install -r requirements.txt

# Adicionar provedores específicos
pip install openai>=1.0.0                    # Para OpenAI
pip install boto3>=1.26.0                    # Para AWS Bedrock
pip install anthropic>=0.7.0                 # Para Anthropic
pip install google-cloud-aiplatform>=1.25.0 # Para Google Cloud

# Adicionar RAG avançado
pip install sentence-transformers>=2.2.0     # Embeddings avançados
pip install faiss-cpu>=1.7.0                 # Busca vetorial
pip install chromadb>=0.4.0                  # Base vetorial

# Adicionar interfaces web
pip install flask>=2.3.0                     # Para API e Dashboard
```

### 4. Instalação Automática de Dependências

O sistema pode instalar dependências automaticamente conforme necessário:

```python
from cobol_to_docs import COBOLAnalyzer

# Inicializar com instalação automática
analyzer = COBOLAnalyzer()

# Instalar dependências para um provider específico
result = analyzer.install_optional_dependencies(['openai', 'boto3'])
print(result)

# Instalar todas as dependências opcionais
result = analyzer.install_optional_dependencies()
print(result)
```

## Configuração

### 1. Arquivo de Configuração Principal

Copie e edite o arquivo de configuração:

```bash
cp config/config.yaml.example config/config.yaml
```

Exemplo de configuração completa:

```yaml
# config/config.yaml
ai:
  primary_provider: "luzia"
  fallback_providers: ["enhanced_mock", "basic"]
  
  models:
    aws_claude_3_5_sonnet:
      provider: "luzia"
      url: "https://api.luzia.com/v1/chat/completions"
      timeout: 120
      max_tokens: 8192
      temperature: 0.1
    
    gpt_4_turbo:
      provider: "openai"
      name: "gpt-4-turbo"
      max_tokens: 4096
      temperature: 0.1
    
    claude_3_sonnet:
      provider: "bedrock"
      model_id: "anthropic.claude-3-sonnet-20240229-v1:0"
      region: "us-east-1"
      max_tokens: 4096

rag:
  enabled: true
  knowledge_base_path: "data/cobol_knowledge_base.json"
  auto_learning: true
  similarity_threshold: 0.7
  max_results: 10

performance:
  cache_enabled: true
  cache_ttl: 3600
  cache_max_size_mb: 500
  parallel_analysis: true
  max_workers: 4

logging:
  level: "INFO"
  file: "logs/cobol_to_docs.log"
  max_size_mb: 100
  backup_count: 5

optional_providers:
  openai:
    enabled: false
    api_key: "${OPENAI_API_KEY}"
    organization: "${OPENAI_ORG_ID}"
  
  bedrock:
    enabled: false
    region: "us-east-1"
    aws_access_key_id: "${AWS_ACCESS_KEY_ID}"
    aws_secret_access_key: "${AWS_SECRET_ACCESS_KEY}"
  
  anthropic:
    enabled: false
    api_key: "${ANTHROPIC_API_KEY}"
  
  google:
    enabled: false
    project_id: "${GOOGLE_PROJECT_ID}"
    location: "us-central1"
    credentials_path: "${GOOGLE_CREDENTIALS_PATH}"
```

### 2. Variáveis de Ambiente

Crie um arquivo `.env` ou configure as variáveis no sistema:

```bash
# .env
# LuzIA (obrigatório)
LUZIA_API_KEY=sua_chave_luzia_aqui

# OpenAI (opcional)
OPENAI_API_KEY=sua_chave_openai_aqui
OPENAI_ORG_ID=sua_organizacao_openai

# AWS Bedrock (opcional)
AWS_ACCESS_KEY_ID=sua_chave_aws
AWS_SECRET_ACCESS_KEY=sua_chave_secreta_aws
AWS_DEFAULT_REGION=us-east-1

# Anthropic (opcional)
ANTHROPIC_API_KEY=sua_chave_anthropic

# Google Cloud (opcional)
GOOGLE_PROJECT_ID=seu_projeto_google
GOOGLE_CREDENTIALS_PATH=/caminho/para/credenciais.json

# Azure (opcional)
AZURE_OPENAI_API_KEY=sua_chave_azure
AZURE_OPENAI_ENDPOINT=https://seu-recurso.openai.azure.com/
```

### 3. Configuração de Diretórios

```bash
# Criar estrutura de diretórios
mkdir -p logs cache temp_uploads api_output

# Definir permissões (Linux/macOS)
chmod 755 logs cache temp_uploads api_output
```

## Verificação da Instalação

### 1. Teste Básico

```bash
# Testar funcionalidade básica
python -c "
from cobol_to_docs import COBOLAnalyzer
analyzer = COBOLAnalyzer()
print('Sistema inicializado com sucesso!')
print('Modelos disponíveis:', len(analyzer.get_available_models()))
"
```

### 2. Teste de Provedores

```bash
# Testar conectividade dos provedores
python -c "
from cobol_to_docs import check_system_status
status = check_system_status()
print('Status dos provedores:')
for provider, info in status['providers'].items():
    print(f'  {provider}: {\"✓\" if info.get(\"available\") else \"✗\"}')
"
```

### 3. Teste de Dependências

```bash
# Verificar dependências opcionais
python -c "
from cobol_to_docs import COBOLAnalyzer
analyzer = COBOLAnalyzer()
deps = analyzer.get_dependency_status()
print(f'Dependências instaladas: {deps[\"installed_count\"]}/{deps[\"total_dependencies\"]}')
"
```

### 4. Teste de Análise

```bash
# Teste com código COBOL simples
python -c "
from cobol_to_docs import analyze_cobol_code
result = analyze_cobol_code('''
IDENTIFICATION DIVISION.
PROGRAM-ID. TESTE.
DATA DIVISION.
PROCEDURE DIVISION.
DISPLAY 'HELLO WORLD'.
STOP RUN.
''', program_name='TESTE')
print('Análise concluída:', 'content' in result)
"
```

## Instalação de Interfaces

### 1. API REST

```bash
# Instalar dependências da API
pip install flask>=2.3.0 werkzeug>=2.3.0

# Testar API
python api_server.py --port 5000 &
curl http://localhost:5000/health
```

### 2. Dashboard Web

```bash
# Instalar dependências do dashboard
pip install flask>=2.3.0

# Testar dashboard
python web_dashboard.py --port 8080 &
# Acessar: http://localhost:8080
```

### 3. Biblioteca Python

```bash
# Instalar como biblioteca
pip install -e .

# Testar importação
python -c "import cobol_to_docs; print(cobol_to_docs.__version__)"
```

## Configuração Avançada

### 1. Cache Personalizado

```yaml
# config/config.yaml
performance:
  cache_enabled: true
  cache_ttl: 7200  # 2 horas
  cache_max_size_mb: 1000  # 1GB
  cache_cleanup_interval: 3600  # 1 hora
  cache_compression: true
```

### 2. RAG Avançado

```yaml
# config/config.yaml
rag:
  enabled: true
  knowledge_base_path: "data/cobol_knowledge_base_expanded.json"
  auto_learning: true
  similarity_threshold: 0.75
  max_results: 15
  embedding_model: "sentence-transformers/all-MiniLM-L6-v2"
  vector_store: "faiss"  # ou "chromadb"
  vector_store_path: "data/vector_store"
```

### 3. Processamento Paralelo

```yaml
# config/config.yaml
performance:
  parallel_analysis: true
  max_workers: 8  # Ajustar conforme CPU
  chunk_size: 5   # Arquivos por worker
  timeout_per_file: 300  # 5 minutos por arquivo
```

### 4. Logging Detalhado

```yaml
# config/config.yaml
logging:
  level: "DEBUG"
  file: "logs/cobol_to_docs_detailed.log"
  max_size_mb: 200
  backup_count: 10
  format: "%(asctime)s - %(name)s - %(levelname)s - %(funcName)s:%(lineno)d - %(message)s"
  
  # Logs específicos
  providers_log: "logs/providers.log"
  rag_log: "logs/rag.log"
  cache_log: "logs/cache.log"
  performance_log: "logs/performance.log"
```

## Solução de Problemas

### 1. Problemas de Dependências

```bash
# Verificar versão do Python
python --version

# Atualizar pip
pip install --upgrade pip

# Reinstalar dependências
pip uninstall -r requirements-full.txt -y
pip install -r requirements-full.txt

# Verificar conflitos
pip check
```

### 2. Problemas de Conectividade

```bash
# Testar conectividade
python -c "
import requests
try:
    response = requests.get('https://api.luzia.com/health', timeout=10)
    print('Conectividade OK')
except Exception as e:
    print(f'Erro de conectividade: {e}')
"
```

### 3. Problemas de Permissões

```bash
# Linux/macOS - Corrigir permissões
sudo chown -R $USER:$USER cobol_to_docs_v1.6/
chmod -R 755 cobol_to_docs_v1.6/

# Windows - Executar como administrador se necessário
```

### 4. Problemas de Memória

```yaml
# config/config.yaml - Reduzir uso de memória
performance:
  max_workers: 2
  cache_max_size_mb: 100
  
rag:
  max_results: 5
  
ai:
  models:
    aws_claude_3_5_haiku:  # Modelo mais leve
      max_tokens: 2048
```

### 5. Limpeza e Reset

```bash
# Limpar cache
python -c "
from cobol_to_docs import COBOLAnalyzer
analyzer = COBOLAnalyzer()
removed = analyzer.cleanup_cache()
print(f'Cache limpo: {removed} arquivos removidos')
"

# Remover logs antigos
find logs/ -name "*.log" -mtime +7 -delete

# Reset completo (cuidado!)
rm -rf cache/ logs/ temp_uploads/ api_output/
mkdir -p cache logs temp_uploads api_output
```

## Configuração para Produção

### 1. Configuração de Servidor

```yaml
# config/config_production.yaml
ai:
  primary_provider: "luzia"
  fallback_providers: ["openai", "bedrock"]

performance:
  cache_enabled: true
  cache_ttl: 86400  # 24 horas
  cache_max_size_mb: 2000  # 2GB
  parallel_analysis: true
  max_workers: 16

logging:
  level: "WARNING"
  file: "/var/log/cobol_to_docs/app.log"
  max_size_mb: 500
  backup_count: 20

security:
  api_rate_limit: 100  # requests per minute
  max_file_size_mb: 50
  allowed_extensions: [".cbl", ".cob", ".cobol", ".txt"]
```

### 2. Variáveis de Ambiente de Produção

```bash
# /etc/environment ou systemd service
COBOL_TO_DOCS_ENV=production
COBOL_TO_DOCS_CONFIG=/etc/cobol_to_docs/config.yaml
COBOL_TO_DOCS_LOG_LEVEL=WARNING
COBOL_TO_DOCS_CACHE_DIR=/var/cache/cobol_to_docs
```

### 3. Serviço Systemd (Linux)

```ini
# /etc/systemd/system/cobol-to-docs-api.service
[Unit]
Description=COBOL to Docs API Server
After=network.target

[Service]
Type=simple
User=cobol-docs
Group=cobol-docs
WorkingDirectory=/opt/cobol_to_docs_v1.6
Environment=PYTHONPATH=/opt/cobol_to_docs_v1.6
ExecStart=/usr/bin/python3 api_server.py --host 0.0.0.0 --port 5000
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

### 4. Nginx Proxy (Opcional)

```nginx
# /etc/nginx/sites-available/cobol-to-docs
server {
    listen 80;
    server_name cobol-docs.exemplo.com;
    
    client_max_body_size 50M;
    
    location / {
        proxy_pass http://127.0.0.1:8080;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    
    location /api/ {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

## Monitoramento

### 1. Métricas de Sistema

```python
# scripts/monitor.py
from cobol_to_docs import COBOLAnalyzer
import json
import time

analyzer = COBOLAnalyzer()

while True:
    metrics = analyzer.get_performance_metrics()
    
    # Log métricas
    with open('logs/metrics.json', 'a') as f:
        json.dump({
            'timestamp': time.time(),
            'metrics': metrics
        }, f)
        f.write('\n')
    
    time.sleep(60)  # A cada minuto
```

### 2. Health Check

```python
# scripts/health_check.py
from cobol_to_docs import check_system_status
import sys

status = check_system_status()
providers_ok = sum(1 for p in status['providers'].values() if p.get('available'))

if providers_ok == 0:
    print("CRITICAL: Nenhum provider disponível")
    sys.exit(2)
elif providers_ok < 2:
    print("WARNING: Poucos providers disponíveis")
    sys.exit(1)
else:
    print("OK: Sistema funcionando normalmente")
    sys.exit(0)
```

## Backup e Recuperação

### 1. Backup de Dados

```bash
#!/bin/bash
# scripts/backup.sh

DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/backup/cobol_to_docs"

# Criar diretório de backup
mkdir -p $BACKUP_DIR

# Backup de configurações
tar -czf $BACKUP_DIR/config_$DATE.tar.gz config/

# Backup de base RAG
tar -czf $BACKUP_DIR/data_$DATE.tar.gz data/

# Backup de logs importantes
tar -czf $BACKUP_DIR/logs_$DATE.tar.gz logs/

# Backup de cache (opcional)
tar -czf $BACKUP_DIR/cache_$DATE.tar.gz cache/

echo "Backup concluído: $BACKUP_DIR"
```

### 2. Recuperação

```bash
#!/bin/bash
# scripts/restore.sh

BACKUP_FILE=$1

if [ -z "$BACKUP_FILE" ]; then
    echo "Uso: $0 <arquivo_backup.tar.gz>"
    exit 1
fi

# Parar serviços
systemctl stop cobol-to-docs-api

# Restaurar backup
tar -xzf $BACKUP_FILE

# Reiniciar serviços
systemctl start cobol-to-docs-api

echo "Recuperação concluída"
```

## Atualizações

### 1. Atualização de Versão

```bash
# Backup antes da atualização
./scripts/backup.sh

# Baixar nova versão
wget https://releases.com/cobol_to_docs_v1.7.tar.gz

# Extrair e atualizar
tar -xzf cobol_to_docs_v1.7.tar.gz
cp -r cobol_to_docs_v1.7/* cobol_to_docs_v1.6/

# Atualizar dependências
pip install -r requirements-full.txt --upgrade

# Verificar atualização
python -c "import cobol_to_docs; print(cobol_to_docs.__version__)"
```

### 2. Migração de Dados

```python
# scripts/migrate_data.py
from cobol_to_docs import COBOLAnalyzer
import json

# Migrar base RAG para novo formato
with open('data/cobol_knowledge_base_old.json', 'r') as f:
    old_data = json.load(f)

# Converter para novo formato
new_data = migrate_rag_format(old_data)

with open('data/cobol_knowledge_base.json', 'w') as f:
    json.dump(new_data, f, indent=2)

print("Migração de dados concluída")
```

## Suporte

Para suporte técnico:
1. Verifique os logs em `logs/`
2. Execute diagnósticos: `python -c "from cobol_to_docs import check_system_status; print(check_system_status())"`
3. Consulte a documentação em `docs/`
4. Reporte problemas com logs e configuração

---

**COBOL to Docs v1.6** - Manual de Instalação Completo
