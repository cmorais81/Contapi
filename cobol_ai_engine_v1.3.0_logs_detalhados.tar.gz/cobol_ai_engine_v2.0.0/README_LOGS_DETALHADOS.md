# COBOL AI Engine v1.3.0 - Logs Detalhados da LuzIA

## Sistema com Transparência Total

Esta versão foi criada especificamente para resolver o problema de visibilidade da conectividade com a LuzIA. O sistema agora mostra **exatamente** o que está acontecendo em cada etapa.

## Arquivo Principal: main_detailed.py

Use `main_detailed.py` em vez do `main.py` para ter logs completos da conectividade LuzIA.

## Como Usar

### 1. Verificar Status da LuzIA

```bash
python main_detailed.py --status
```

**O que você verá:**
- Status das variáveis de ambiente
- Teste real de conectividade
- Token de acesso obtido
- Confirmação se está pronto para análise

### 2. Executar Análise com Logs Detalhados

```bash
# Configurar credenciais
export LUZIA_CLIENT_ID="seu_client_id_real"
export LUZIA_CLIENT_SECRET="seu_client_secret_real"

# Executar análise
python main_detailed.py --fontes examples/fontes.txt --output minha_analise
```

## Logs Detalhados Gerados

### Console (Tempo Real)
- Status de conectividade
- Progresso da análise
- Confirmação de sucesso/erro

### Arquivo: cobol_ai_engine_detailed.log
- **Autenticação**: Payload completo, headers, resposta do token
- **Requests**: Payload JSON enviado para LuzIA
- **Responses**: Resposta completa da LuzIA
- **Erros**: Detalhes completos de qualquer falha

### Arquivos JSON Salvos
- **ai_requests/**: Todos os payloads enviados
- **ai_responses/**: Todas as respostas recebidas
- **Relatórios MD**: Análises com transparência total

## Exemplo de Log Detalhado

```
2025-09-22 14:18:05,743 - LUZIA - INFO - === INICIALIZANDO CONECTOR LUZIA ===
2025-09-22 14:18:05,743 - LUZIA - INFO - Client ID configurado: SIM
2025-09-22 14:18:05,743 - LUZIA - INFO - Client Secret configurado: SIM
2025-09-22 14:18:05,743 - LUZIA - INFO - Auth URL: https://login.azure.paas.santanderbr.pre.corp/auth/realms/santander/protocol/openid-connect/token
2025-09-22 14:18:05,743 - LUZIA - INFO - API URL: https://gpt-api-aws.santanderbr.dev.corp/genai_services/v1/

2025-09-22 14:18:05,743 - LUZIA - INFO - === INICIANDO AUTENTICAÇÃO LUZIA ===
2025-09-22 14:18:05,743 - LUZIA - INFO - === PAYLOAD DE AUTENTICAÇÃO ===
2025-09-22 14:18:05,743 - LUZIA - INFO - URL: https://login.azure.paas.santanderbr.pre.corp/auth/realms/santander/protocol/openid-connect/token
2025-09-22 14:18:05,743 - LUZIA - INFO - Headers: {
  "Content-Type": "application/x-www-form-urlencoded",
  "Accept": "*/*"
}
2025-09-22 14:18:05,743 - LUZIA - INFO - Payload: grant_type=client_credentials&client_id=seu_id&client_secret=***

2025-09-22 14:18:06,123 - LUZIA - INFO - === RESPOSTA DE AUTENTICAÇÃO ===
2025-09-22 14:18:06,123 - LUZIA - INFO - Status Code: 200
2025-09-22 14:18:06,123 - LUZIA - INFO - TOKEN OBTIDO COM SUCESSO: eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6...

2025-09-22 14:18:06,124 - LUZIA - INFO - === INICIANDO ANÁLISE DO PROGRAMA LHBR0700 ===
2025-09-22 14:18:06,124 - LUZIA - INFO - === PAYLOAD PARA LUZIA ===
2025-09-22 14:18:06,124 - LUZIA - INFO - URL: https://gpt-api-aws.santanderbr.dev.corp/genai_services/v1/pipelines/submit
2025-09-22 14:18:06,124 - LUZIA - INFO - Payload Size: 15234 bytes
2025-09-22 14:18:06,124 - LUZIA - INFO - System Prompt Length: 567 chars
2025-09-22 14:18:06,124 - LUZIA - INFO - User Prompt Length: 14234 chars
2025-09-22 14:18:06,124 - LUZIA - INFO - Program Code Length: 13456 chars

2025-09-22 14:18:06,124 - LUZIA - INFO - Enviando requisição para LuzIA...

2025-09-22 14:18:15,456 - LUZIA - INFO - === RESPOSTA DA LUZIA ===
2025-09-22 14:18:15,456 - LUZIA - INFO - Status Code: 200
2025-09-22 14:18:15,456 - LUZIA - INFO - Response Size: 8765 bytes
2025-09-22 14:18:15,456 - LUZIA - INFO - SUCESSO: Resposta recebida da LuzIA
```

## Estrutura de Saída

```
minha_analise/
├── LHBR0700.md                    # Relatório com análise da LuzIA
├── LHAN0542.md                    # Relatório com análise da LuzIA
├── ai_requests/
│   ├── LHBR0700_request.json      # Payload enviado para LuzIA
│   └── LHAN0542_request.json      # Payload enviado para LuzIA
├── ai_responses/
│   ├── LHBR0700_response.json     # Resposta completa da LuzIA
│   └── LHAN0542_response.json     # Resposta completa da LuzIA
└── cobol_ai_engine_detailed.log   # Log completo de tudo
```

## Solução de Problemas

### Se não conectar na LuzIA:
1. Verifique o log: `cobol_ai_engine_detailed.log`
2. Confirme as credenciais: `python main_detailed.py --status`
3. Veja o payload de autenticação no log
4. Veja a resposta de erro no log

### Se não receber resposta da análise:
1. Verifique se o token foi obtido
2. Veja o payload enviado no log
3. Veja a resposta HTTP no log
4. Verifique os arquivos JSON salvos

## Diferenças do main.py Original

- **main.py**: Sistema antigo sem logs detalhados
- **main_detailed.py**: Sistema novo com transparência total

**Use sempre main_detailed.py para ter visibilidade completa do que está acontecendo.**

## Configuração LuzIA

O sistema está configurado para usar:
- **Modelo**: aws-claude-3-5-sonnet
- **Auth URL**: https://login.azure.paas.santanderbr.pre.corp/auth/realms/santander/protocol/openid-connect/token
- **API URL**: https://gpt-api-aws.santanderbr.dev.corp/genai_services/v1/pipelines/submit
- **Headers**: x-santander-client-id + Authorization Bearer
- **Payload**: Formato input/query/config conforme especificação

Agora você pode ver **exatamente** o que está sendo enviado e recebido da LuzIA!
