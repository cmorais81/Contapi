#!/usr/bin/env python3
"""
COBOL AI Engine v1.3.0 - Sistema com Logs Detalhados da LuzIA
Sistema que mostra claramente a conectividade, payloads e respostas da LuzIA.
"""

import os
import sys
import json
import argparse
import logging
import requests
from datetime import datetime
from pathlib import Path

def setup_detailed_logging():
    """Configura logging detalhado do sistema."""
    # Configurar formatação detalhada
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Handler para console
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(formatter)
    
    # Handler para arquivo
    file_handler = logging.FileHandler('cobol_ai_engine_detailed.log')
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(formatter)
    
    # Configurar logger principal
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    logger.addHandler(console_handler)
    logger.addHandler(file_handler)
    
    # Logger específico para LuzIA
    luzia_logger = logging.getLogger('LUZIA')
    luzia_logger.setLevel(logging.DEBUG)
    
    return logger, luzia_logger

class LuziaConnector:
    """Conector LuzIA com logs detalhados."""
    
    def __init__(self):
        self.logger = logging.getLogger('LUZIA')
        self.client_id = os.getenv("LUZIA_CLIENT_ID")
        self.client_secret = os.getenv("LUZIA_CLIENT_SECRET")
        self.token = None
        
        # URLs conforme configuração
        self.auth_url = "https://login.azure.paas.santanderbr.pre.corp/auth/realms/santander/protocol/openid-connect/token"
        self.api_url = "https://gpt-api-aws.santanderbr.dev.corp/genai_services/v1/"
        
        self.logger.info("=== INICIALIZANDO CONECTOR LUZIA ===")
        self.logger.info(f"Client ID configurado: {'SIM' if self.client_id else 'NÃO'}")
        self.logger.info(f"Client Secret configurado: {'SIM' if self.client_secret else 'NÃO'}")
        self.logger.info(f"Auth URL: {self.auth_url}")
        self.logger.info(f"API URL: {self.api_url}")
    
    def get_token(self):
        """Obtém token de acesso da LuzIA com logs detalhados."""
        self.logger.info("=== INICIANDO AUTENTICAÇÃO LUZIA ===")
        
        if not self.client_id or not self.client_secret:
            self.logger.error("ERRO: Credenciais não configuradas")
            return None
        
        # Preparar payload de autenticação
        auth_payload = {
            "grant_type": "client_credentials",
            "client_id": self.client_id,
            "client_secret": self.client_secret
        }
        
        headers = {
            "Content-Type": "application/x-www-form-urlencoded",
            "Accept": "*/*"
        }
        
        self.logger.info("=== PAYLOAD DE AUTENTICAÇÃO ===")
        self.logger.info(f"URL: {self.auth_url}")
        self.logger.info(f"Headers: {json.dumps(headers, indent=2)}")
        self.logger.info(f"Payload: grant_type=client_credentials&client_id={self.client_id}&client_secret=***")
        
        try:
            self.logger.info("Enviando requisição de autenticação...")
            
            response = requests.post(
                self.auth_url,
                data=auth_payload,
                headers=headers,
                verify=False,
                timeout=30
            )
            
            self.logger.info(f"=== RESPOSTA DE AUTENTICAÇÃO ===")
            self.logger.info(f"Status Code: {response.status_code}")
            self.logger.info(f"Headers: {dict(response.headers)}")
            
            if response.status_code == 200:
                token_data = response.json()
                self.logger.info(f"Response Body: {json.dumps(token_data, indent=2)}")
                
                self.token = token_data.get("access_token")
                if self.token:
                    self.logger.info(f"TOKEN OBTIDO COM SUCESSO: {self.token[:50]}...")
                    return self.token
                else:
                    self.logger.error("ERRO: Token não encontrado na resposta")
                    return None
            else:
                self.logger.error(f"ERRO DE AUTENTICAÇÃO: {response.status_code}")
                self.logger.error(f"Response Body: {response.text}")
                return None
                
        except Exception as e:
            self.logger.error(f"EXCEÇÃO NA AUTENTICAÇÃO: {str(e)}")
            return None
    
    def analyze_program(self, program_name, program_code):
        """Analisa programa COBOL com logs detalhados."""
        self.logger.info(f"=== INICIANDO ANÁLISE DO PROGRAMA {program_name} ===")
        
        # Garantir token
        if not self.token:
            self.logger.info("Token não disponível, obtendo novo token...")
            if not self.get_token():
                return {"success": False, "error": "Falha na autenticação"}
        
        # Preparar prompts
        system_prompt = """Você é um programador COBOL muito experiente com mais de 20 anos de experiência em sistemas mainframe e aplicações críticas de negócio.

Sua tarefa é analisar o programa COBOL fornecido de forma completa e detalhada, considerando:

1. Arquitetura e estrutura técnica
2. Regras de negócio implementadas  
3. Qualidade do código e boas práticas
4. Comentários e documentação inline
5. Fluxos lógicos e complexidade
6. Interfaces e integrações
7. Performance e otimização
8. Manutenibilidade

Forneça uma análise profissional e detalhada que seria útil para outros desenvolvedores e analistas de negócio."""

        user_prompt = f"""Analise este programa COBOL:

Nome do Programa: {program_name}

Código Fonte:
{program_code}

Por favor, forneça uma análise completa incluindo:

1. **Análise Funcional**: O que o programa faz, qual seu propósito no sistema
2. **Estrutura Técnica**: Divisões, seções, variáveis principais, arquivos
3. **Regras de Negócio**: Regras implementadas, validações, cálculos
4. **Comentários e Documentação**: Análise dos comentários encontrados
5. **Qualidade do Código**: Avaliação técnica, pontos de melhoria
6. **Fluxos Lógicos**: Principais fluxos de execução e decisões
7. **Interfaces**: Arquivos de entrada/saída, chamadas para outros programas
8. **Recomendações**: Sugestões de melhoria e manutenção

Seja detalhado e técnico, mas também explique o contexto de negócio quando possível."""

        # Preparar payload para LuzIA
        payload = {
            "input": {
                "query": [
                    {
                        "role": "system",
                        "content": system_prompt
                    },
                    {
                        "role": "user", 
                        "content": user_prompt
                    }
                ]
            },
            "config": [
                {
                    "type": "catena.llm.LLMRouter",
                    "obj_kwargs": {
                        "routing_model": "aws-claude-3-5-sonnet",
                        "temperature": 0.1
                    }
                }
            ]
        }
        
        headers = {
            "x-santander-client-id": self.client_id,
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json"
        }
        
        self.logger.info("=== PAYLOAD PARA LUZIA ===")
        self.logger.info(f"URL: {self.api_url}pipelines/submit")
        self.logger.info(f"Headers: {json.dumps({k: v if k != 'Authorization' else f'Bearer {self.token[:20]}...' for k, v in headers.items()}, indent=2)}")
        self.logger.info(f"Payload Size: {len(json.dumps(payload))} bytes")
        self.logger.info(f"System Prompt Length: {len(system_prompt)} chars")
        self.logger.info(f"User Prompt Length: {len(user_prompt)} chars")
        self.logger.info(f"Program Code Length: {len(program_code)} chars")
        
        # Log do payload completo (truncado para logs)
        payload_log = payload.copy()
        if len(payload_log["input"]["query"][1]["content"]) > 1000:
            payload_log["input"]["query"][1]["content"] = payload_log["input"]["query"][1]["content"][:1000] + "... [TRUNCADO]"
        
        self.logger.debug(f"Payload Completo: {json.dumps(payload_log, indent=2, ensure_ascii=False)}")
        
        try:
            self.logger.info("Enviando requisição para LuzIA...")
            
            response = requests.post(
                url=f"{self.api_url}pipelines/submit",
                json=payload,
                headers=headers,
                verify=False,
                timeout=120
            )
            
            self.logger.info(f"=== RESPOSTA DA LUZIA ===")
            self.logger.info(f"Status Code: {response.status_code}")
            self.logger.info(f"Response Headers: {dict(response.headers)}")
            self.logger.info(f"Response Size: {len(response.text)} bytes")
            
            if response.status_code == 200:
                result = response.json()
                self.logger.info("SUCESSO: Resposta recebida da LuzIA")
                self.logger.info(f"Response Keys: {list(result.keys()) if isinstance(result, dict) else 'Not a dict'}")
                
                # Log da resposta (truncada)
                if isinstance(result, dict):
                    result_log = {}
                    for key, value in result.items():
                        if isinstance(value, str) and len(value) > 500:
                            result_log[key] = value[:500] + "... [TRUNCADO]"
                        else:
                            result_log[key] = value
                    self.logger.debug(f"Response Body: {json.dumps(result_log, indent=2, ensure_ascii=False)}")
                else:
                    self.logger.debug(f"Response Body: {str(result)[:1000]}...")
                
                return {
                    "success": True,
                    "response": result,
                    "request_payload": payload,
                    "status_code": response.status_code
                }
            else:
                self.logger.error(f"ERRO NA REQUISIÇÃO: {response.status_code}")
                self.logger.error(f"Response Body: {response.text}")
                return {
                    "success": False,
                    "error": f"HTTP {response.status_code}: {response.text}",
                    "request_payload": payload
                }
                
        except Exception as e:
            self.logger.error(f"EXCEÇÃO NA REQUISIÇÃO: {str(e)}")
            return {
                "success": False,
                "error": str(e),
                "request_payload": payload
            }

def parse_cobol_file(file_path: str) -> list:
    """Parse do arquivo de fontes COBOL."""
    programs = []
    logger = logging.getLogger('PARSER')
    
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        logger.info(f"Arquivo lido: {len(content)} caracteres")
        
        # Dividir por programas (assumindo separação por PROGRAM-ID)
        program_sections = content.split('PROGRAM-ID.')
        logger.info(f"Encontradas {len(program_sections)} seções")
        
        for i, section in enumerate(program_sections[1:], 1):  # Pular primeira seção vazia
            lines = section.strip().split('\n')
            if lines:
                # Extrair nome do programa da primeira linha
                program_name = lines[0].strip().rstrip('.')
                
                # Reconstruir código completo
                program_code = f"PROGRAM-ID. {section}"
                
                programs.append({
                    'name': program_name,
                    'code': program_code,
                    'lines': len(lines)
                })
                
                logger.info(f"Programa {i}: {program_name} ({len(lines)} linhas)")
                
        logger.info(f"Total de programas parseados: {len(programs)}")
        return programs
        
    except Exception as e:
        logger.error(f"Erro ao parsear arquivo {file_path}: {str(e)}")
        return []

def save_detailed_results(program_name: str, analysis_result: dict, output_dir: str):
    """Salva resultados com logs detalhados."""
    logger = logging.getLogger('SAVER')
    
    # Criar diretórios
    os.makedirs(output_dir, exist_ok=True)
    os.makedirs(os.path.join(output_dir, 'ai_requests'), exist_ok=True)
    os.makedirs(os.path.join(output_dir, 'ai_responses'), exist_ok=True)
    
    timestamp = datetime.now().isoformat()
    
    # Salvar request completo
    request_file = os.path.join(output_dir, 'ai_requests', f'{program_name}_request.json')
    request_data = {
        'program_name': program_name,
        'timestamp': timestamp,
        'request_payload': analysis_result.get('request_payload', {}),
        'model_used': 'aws-claude-3-5-sonnet',
        'provider': 'luzia',
        'status': 'sent'
    }
    
    with open(request_file, 'w', encoding='utf-8') as f:
        json.dump(request_data, f, indent=2, ensure_ascii=False)
    
    logger.info(f"Request salvo: {request_file}")
    
    # Salvar response completo
    response_file = os.path.join(output_dir, 'ai_responses', f'{program_name}_response.json')
    response_data = {
        'program_name': program_name,
        'timestamp': timestamp,
        'success': analysis_result.get('success', False),
        'response_data': analysis_result.get('response', {}),
        'error': analysis_result.get('error'),
        'status_code': analysis_result.get('status_code'),
        'model_used': 'aws-claude-3-5-sonnet',
        'provider': 'luzia'
    }
    
    with open(response_file, 'w', encoding='utf-8') as f:
        json.dump(response_data, f, indent=2, ensure_ascii=False)
    
    logger.info(f"Response salvo: {response_file}")
    
    # Salvar relatório markdown se sucesso
    if analysis_result.get('success') and analysis_result.get('response'):
        report_file = os.path.join(output_dir, f'{program_name}.md')
        
        # Extrair conteúdo da resposta
        response_data = analysis_result.get('response', {})
        content = ""
        
        # Tentar extrair conteúdo da estrutura de resposta da LuzIA
        if 'output' in response_data:
            content = response_data['output']
        elif 'result' in response_data:
            content = response_data['result']
        elif 'content' in response_data:
            content = response_data['content']
        elif 'choices' in response_data and response_data['choices']:
            content = response_data['choices'][0].get('message', {}).get('content', '')
        else:
            content = f"Resposta da LuzIA:\n\n```json\n{json.dumps(response_data, indent=2, ensure_ascii=False)}\n```"
        
        # Criar relatório markdown
        markdown_content = f"""# Análise do Programa COBOL: {program_name}

**Data da Análise**: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}  
**Modelo Utilizado**: aws-claude-3-5-sonnet  
**Provedor**: LuzIA  
**Status**: {'SUCESSO' if analysis_result.get('success') else 'ERRO'}

## Análise Detalhada

{content}

## Transparência e Auditoria

### Informações da Análise

- **Status da Análise**: {'SUCESSO' if analysis_result.get('success') else 'ERRO'}
- **Provedor Utilizado**: LuzIA
- **Modelo**: aws-claude-3-5-sonnet
- **Timestamp**: {timestamp}
- **Status Code**: {analysis_result.get('status_code', 'N/A')}

### Arquivos de Auditoria

- **Request JSON**: `ai_requests/{program_name}_request.json`
- **Response JSON**: `ai_responses/{program_name}_response.json`
- **Log Detalhado**: `cobol_ai_engine_detailed.log`

### Conectividade LuzIA

- **Auth URL**: https://login.azure.paas.santanderbr.pre.corp/auth/realms/santander/protocol/openid-connect/token
- **API URL**: https://gpt-api-aws.santanderbr.dev.corp/genai_services/v1/pipelines/submit
- **Modelo**: aws-claude-3-5-sonnet
- **Temperatura**: 0.1

---
*Relatório gerado pelo COBOL AI Engine v1.3.0*
"""
        
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write(markdown_content)
        
        logger.info(f"Relatório salvo: {report_file}")

def check_luzia_status():
    """Verifica status da conexão com LuzIA."""
    print("COBOL AI Engine v1.3.0 - Status Detalhado da LuzIA")
    print("=" * 60)
    
    connector = LuziaConnector()
    
    print("\nVARIAVEIS DE AMBIENTE")
    print("-" * 30)
    print(f"LUZIA_CLIENT_ID: {'[OK] Configurada' if connector.client_id else '[ERRO] Não configurada'}")
    print(f"LUZIA_CLIENT_SECRET: {'[OK] Configurada' if connector.client_secret else '[ERRO] Não configurada'}")
    print()
    
    if not connector.client_id or not connector.client_secret:
        print("[ERRO] Configure as variáveis de ambiente antes de usar:")
        print("export LUZIA_CLIENT_ID='seu_client_id'")
        print("export LUZIA_CLIENT_SECRET='seu_client_secret'")
        return False
    
    # Testar conexão real
    print("TESTE DE CONECTIVIDADE REAL")
    print("-" * 30)
    
    token = connector.get_token()
    
    if token:
        print("[OK] Conectividade com LuzIA estabelecida")
        print(f"[OK] Token obtido: {token[:20]}...")
        print("[OK] Pronto para análise")
        return True
    else:
        print("[ERRO] Falha na conectividade com LuzIA")
        print("[ERRO] Verifique logs detalhados em cobol_ai_engine_detailed.log")
        return False

def main():
    """Função principal."""
    parser = argparse.ArgumentParser(description='COBOL AI Engine v1.3.0 - Logs Detalhados LuzIA')
    parser.add_argument('--fontes', required=False, help='Arquivo de fontes COBOL')
    parser.add_argument('--books', help='Arquivo de copybooks')
    parser.add_argument('--output', default='output_detailed', help='Diretório de saída')
    parser.add_argument('--status', action='store_true', help='Verificar status da LuzIA')
    parser.add_argument('--log', default='INFO', choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'], help='Nível de log')
    
    args = parser.parse_args()
    
    # Configurar logging detalhado
    logger, luzia_logger = setup_detailed_logging()
    logger.info("=== COBOL AI ENGINE v1.3.0 INICIADO ===")
    
    # Verificar status se solicitado
    if args.status:
        check_luzia_status()
        return
    
    # Validar argumentos
    if not args.fontes:
        print("Erro: --fontes é obrigatório")
        print("Use: python main_detailed.py --fontes arquivo.txt")
        print("Ou: python main_detailed.py --status")
        return
    
    if not os.path.exists(args.fontes):
        print(f"Erro: Arquivo {args.fontes} não encontrado")
        return
    
    # Verificar conectividade
    print("Verificando conectividade com LuzIA...")
    connector = LuziaConnector()
    
    if not connector.get_token():
        print("ERRO: Não foi possível conectar na LuzIA")
        print("Verifique os logs detalhados em cobol_ai_engine_detailed.log")
        return
    
    print("Conectividade OK! Iniciando análise...")
    
    # Parse dos arquivos
    programs = parse_cobol_file(args.fontes)
    
    if not programs:
        print("Nenhum programa encontrado no arquivo de fontes")
        return
    
    print(f"Encontrados {len(programs)} programas para análise")
    
    # Analisar cada programa
    for i, program in enumerate(programs, 1):
        program_name = program['name']
        program_code = program['code']
        
        print(f"\nAnalisando programa {i}/{len(programs)}: {program_name}")
        print("Enviando para LuzIA... (verifique logs detalhados)")
        
        # Executar análise
        result = connector.analyze_program(program_name, program_code)
        
        # Salvar resultados
        save_detailed_results(program_name, result, args.output)
        
        if result.get('success'):
            print(f"[OK] {program_name} analisado com sucesso")
        else:
            print(f"[ERRO] Falha na análise de {program_name}: {result.get('error')}")
    
    print(f"\nAnálise concluída. Resultados salvos em: {args.output}")
    print(f"- Relatórios: {args.output}/*.md")
    print(f"- Requests: {args.output}/ai_requests/")
    print(f"- Responses: {args.output}/ai_responses/")
    print(f"- Logs detalhados: cobol_ai_engine_detailed.log")

if __name__ == "__main__":
    main()
