# Guia de Estilo Técnico para Análises COBOL v1.5

## Objetivo

Este documento estabelece diretrizes para garantir que todas as análises geradas pelo sistema COBOL to Docs v1.5 mantenham um padrão técnico profissional, objetivo e preciso, conforme feedback do especialista.

## 1. Linguagem e Terminologia

### 1.1 Estilo de Escrita

- **Utilizar**: Linguagem técnica, objetiva e precisa
- **Evitar**: Expressões coloquiais, adjetivos emocionais, superlativos

### 1.2 Termos Técnicos

- **Utilizar**: Terminologia COBOL padrão conforme especificações oficiais
- **Evitar**: Simplificações excessivas ou jargões não técnicos

### 1.3 Expressões Proibidas

Evitar completamente as seguintes expressões:
- "complexo", "descobertas", "incrível", "maravilhoso"
- "firula", "único", "impressionante"
- "algoritmos únicos", "técnicas interessantes"
- Qualquer adjetivo que denote emoção ou subjetividade

### 1.4 Nível de Linguagem

Conforme feedback do especialista, o texto deve ser:
- Técnico e objetivo, sem parecer "coisa de estagiário ou júnior"
- Sem "firulas" que chamam atenção onde não existem destaques relevantes
- Sem excesso de emotividade, mantendo objetividade técnica
- Sem termos como "complexo", "descobertas", "algoritmos únicos"

## 2. Estrutura da Análise

### 2.1 Seções Obrigatórias

1. **Identificação do Programa**
   - Nome do programa
   - Versão do compilador COBOL compatível
   - Dependências externas

2. **Estrutura do Código**
   - Divisões presentes (IDENTIFICATION, ENVIRONMENT, DATA, PROCEDURE)
   - Seções identificadas
   - Parágrafos principais

3. **Estruturas de Dados**
   - FILE SECTION: Arquivos definidos com FD
   - WORKING-STORAGE SECTION: Variáveis principais
   - LINKAGE SECTION: Parâmetros de interface

4. **Fluxo de Processamento**
   - Ponto de entrada
   - Fluxo principal de execução
   - Condições de término

5. **Regras de Negócio**
   - Regras identificadas com referência exata ao código fonte
   - Valores específicos e fórmulas matemáticas
   - Condições de validação

6. **Integrações e Interfaces**
   - Chamadas a outros programas (CALL)
   - Interfaces de banco de dados (SQL)
   - Comunicação com sistemas externos

7. **Análise Técnica**
   - Padrões de codificação utilizados
   - Potenciais problemas de performance
   - Recomendações técnicas específicas

### 2.2 Formato de Referência ao Código

- Sempre referenciar números de linha exatos: `(linhas 125-130)`
- Para variáveis, incluir definição completa: `WS-TAXA-JUROS PIC 9(3)V99 VALUE 12.50`
- Para comandos, citar contexto: `PERFORM CALCULA-JUROS UNTIL FIM-ARQUIVO = 'S'`

## 3. Análise de Copybooks

### 3.1 Estratégia para Copybooks

Conforme feedback do especialista: "não trouxe nenhum copybook, se errava ao tentar trazer todos, desta vez acertou em não trazer nenhum, dai o analista verá que conferir no código, o que vai fazer de qualquer jeito."

**Abordagem recomendada:**
- Não tentar listar todos os copybooks automaticamente
- Incluir nota técnica indicando que o analista deve verificar no código
- Quando identificados com certeza, documentar com precisão

### 3.2 Documentação de Copybooks (quando aplicável)

Quando copybooks forem documentados, seguir este formato:

```
Copybook: NOME-COPYBOOK
Referenciado em: linha X
Sintaxe utilizada: COPY/++INCLUDE
Propósito técnico: [descrição objetiva]
```

## 4. Regras de Negócio

### 4.1 Formato de Documentação

```
Regra: [Título técnico da regra]
Localização: linhas X-Y
Implementação: [descrição técnica]
Valores/Parâmetros:
- Parâmetro 1: valor/fórmula
- Parâmetro 2: valor/fórmula
Condições de aplicação: [condições específicas]
```

### 4.2 Exemplos de Regras Bem Documentadas

```
Regra: Cálculo de Juros de Mora
Localização: linhas 342-350
Implementação: COMPUTE WS-JUROS-MORA = WS-VALOR-PRINCIPAL * WS-TAXA-DIARIA * WS-DIAS-ATRASO / 30
Valores/Parâmetros:
- WS-TAXA-DIARIA: 0.0033 (0.33% ao dia, definido na linha 125)
- Divisor fixo: 30 (mês comercial)
Condições de aplicação: Executado quando WS-DIAS-ATRASO > 0
```

## 5. Interfaces e Integrações

### 5.1 Documentação de Interfaces

- Identificar todas as interfaces, mesmo as comentadas/desativadas
- Especificar estado atual (ativa/desativada)
- Documentar parâmetros de entrada/saída

### 5.2 Formato de Documentação

```
Interface: [Nome da interface]
Tipo: [CALL, SQL, API, etc.]
Estado: Ativo/Desativado (comentado na linha X)
Parâmetros de entrada:
- Parâmetro 1 (tipo/formato)
- Parâmetro 2 (tipo/formato)
Parâmetros de saída:
- Parâmetro 1 (tipo/formato)
- Parâmetro 2 (tipo/formato)
Propósito técnico: [descrição objetiva]
```

## 6. Aprendizado Automático

### 6.1 Critérios para Extração de Conhecimento

Conforme feedback do especialista: "ainda não me acostumei como este item é descrito, muita informação esconde o que é realmente essencial."

**Abordagem recomendada:**
- Focar apenas em padrões técnicos verificáveis e essenciais
- Evitar excesso de informação que obscurece o essencial
- Priorizar clareza e objetividade sobre quantidade

### 6.2 Formato de Itens de Conhecimento

```
Padrão Técnico: [Nome do padrão]
Categoria: [Algoritmo, Estrutura de Dados, Validação, etc.]
Implementação: [Descrição técnica objetiva e concisa]
Aplicabilidade: [Contextos técnicos específicos onde se aplica]
```

## 7. Recomendações Técnicas

### 7.1 Formato de Recomendações

```
Recomendação: [Título técnico]
Tipo: [Performance, Manutenibilidade, Segurança, etc.]
Justificativa técnica: [Razões objetivas]
Implementação sugerida: [Descrição técnica da solução]
```

### 7.2 Exemplos de Recomendações Bem Formuladas

```
Recomendação: Indexação de Arquivo CLIENTE
Tipo: Performance
Justificativa técnica: O arquivo CLIENTE é acessado sequencialmente em loop (linhas 230-245) com volume estimado de 100.000+ registros
Implementação sugerida: Utilizar INDEXED FILE com chave primária em CLIENTE-ID para reduzir complexidade de O(n) para O(log n)
```

## 8. Validação de Qualidade

### 8.1 Checklist de Revisão

- [ ] Linguagem técnica e objetiva em todo o documento
- [ ] Referências precisas ao código fonte (números de linha)
- [ ] Valores específicos para todas as regras de negócio
- [ ] Documentação apropriada de copybooks (conforme estratégia)
- [ ] Interfaces corretamente identificadas e documentadas
- [ ] Ausência de termos emocionais ou subjetivos
- [ ] Recomendações técnicas específicas e implementáveis
- [ ] Informação essencial destacada sem excesso de detalhes

### 8.2 Processo de Validação

1. Verificação automática de terminologia proibida
2. Validação de referências a linhas de código
3. Confirmação de valores específicos em regras de negócio
4. Revisão de consistência técnica
5. Verificação de clareza e objetividade

---

## Aplicação no Sistema

Este guia de estilo deve ser implementado como filtro de pós-processamento em todas as análises geradas pelo sistema COBOL to Docs v1.5, garantindo consistência e profissionalismo em todos os documentos produzidos.
