# COBOL AI Engine v2.0

**Versão**: 2.0.0  
**Data**: 09 de Setembro de 2025  

## Visão Geral

O COBOL AI Engine v2.0 é um sistema robusto e simplificado para análise e documentação automática de programas COBOL. Esta versão foi completamente reescrita para garantir compatibilidade, simplicidade e confiabilidade.

## Principais Funcionalidades

- **Parser COBOL Robusto**: Processa arquivos empilhados e extrai programas e copybooks.
- **Análise com IA**: Integração com múltiplos provedores (Enhanced Mock, OpenAI, LuzIA).
- **Sistema de Fallback**: Garante que a análise sempre funcione, mesmo sem provedores externos.
- **Documentação Automática**: Gera documentação completa em Markdown para cada programa.
- **Relatório Consolidado**: Cria um resumo com estatísticas de todo o processamento.
- **Configuração Simplificada**: Um único arquivo `config.yaml` para todas as configurações.
- **Sem Ícones**: Interface limpa e profissional em toda a documentação e mensagens.

## Estrutura do Projeto

```
.
├── config/              # Arquivos de configuração
├── docs/                # Manuais e documentação
├── examples/            # Arquivos de exemplo
├── logs/                # Arquivos de log
├── src/                 # Código fonte
│   ├── core/            # Engine principal e configuração
│   ├── generators/      # Gerador de documentação
│   ├── parsers/         # Parser COBOL
│   └── providers/       # Provedores de IA
├── tests/               # Testes automatizados
├── main.py              # Script principal
├── requirements.txt     # Dependências
└── VERSION              # Versão do sistema
```

## Como Começar

1. **Instale o sistema**: Siga as instruções em `docs/MANUAL_INSTALACAO_WINDOWS.md` ou `docs/MANUAL_INSTALACAO_LINUX.md`.
2. **Verifique a instalação**:
   ```bash
   python main.py --version
   ```
3. **Execute uma análise de teste**:
   ```bash
   python main.py --fontes examples/fontes.txt --books examples/BOOKS.txt
   ```
4. **Verifique os resultados**: A documentação será gerada na pasta `output`.

## Configuração

A configuração é feita no arquivo `config/config.yaml`. Você pode habilitar e configurar diferentes provedores de IA (OpenAI, LuzIA) e ajustar outras configurações de processamento.

Para mais detalhes, consulte `docs/MANUAL_CONFIGURACAO.md`.

## Uso

O sistema é executado via linha de comando. Para ver todas as opções, use:

```bash
python main.py --help
```

Para mais detalhes sobre o uso, consulte `docs/MANUAL_USUARIO.md`.

## Contribuindo

Este projeto é de código fechado. Para contribuições, entre em contato com a equipe de desenvolvimento.

## Licença

Este projeto é licenciado sob os termos da licença proprietária.


