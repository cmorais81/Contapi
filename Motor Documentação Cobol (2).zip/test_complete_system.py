#!/usr/bin/env python3
"""
COBOL AI Engine v2.0 - Teste Completo do Sistema
Testa todas as funcionalidades principais do sistema.
"""

import os
import sys
import json
import tempfile
import shutil
from datetime import datetime

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from core.engine import CobolAIEngine
from core.config import ConfigManager


def test_configuration():
    """Testa o sistema de configuração."""
    print("Testando configuração...")
    
    try:
        config_manager = ConfigManager("config/config.yaml")
        ai_config = config_manager.get_ai_config()
        
        # Verificar se configuração foi carregada
        assert ai_config is not None, "Configuração de IA não foi carregada"
        assert ai_config.primary_provider == "enhanced_mock", "Provedor primário incorreto"
        assert "enhanced_mock" in ai_config.providers, "Provedor enhanced_mock não encontrado"
        
        print("  Configuração: OK")
        return True
        
    except Exception as e:
        print(f"  Configuração: ERRO - {str(e)}")
        return False


def test_parser():
    """Testa o parser COBOL."""
    print("Testando parser COBOL...")
    
    try:
        from parsers.cobol_parser import CobolParser
        
        parser = CobolParser()
        
        # Testar com arquivo de exemplo
        if os.path.exists("examples/fontes.txt"):
            result = parser.parse_file("examples/fontes.txt")
            
            assert "programs" in result, "Programas não foram parseados"
            assert "books" in result, "Books não foram parseados"
            
            programs = result["programs"]
            books = result["books"]
            
            print(f"  Programas parseados: {len(programs)}")
            print(f"  Books parseados: {len(books)}")
            
            # Verificar se pelo menos um programa foi parseado
            if len(programs) > 0:
                program = programs[0]
                assert hasattr(program, 'name'), "Programa não tem nome"
                assert hasattr(program, 'source_lines'), "Programa não tem linhas de código"
                print(f"  Primeiro programa: {program.name} ({program.line_count} linhas)")
            
            print("  Parser COBOL: OK")
            return True
        else:
            print("  Parser COBOL: AVISO - Arquivo de exemplo não encontrado")
            return True
            
    except Exception as e:
        print(f"  Parser COBOL: ERRO - {str(e)}")
        return False


def test_providers():
    """Testa os provedores de IA."""
    print("Testando provedores de IA...")
    
    try:
        from providers.enhanced_mock_provider import EnhancedMockProvider
        from providers.basic_provider import BasicProvider
        from providers.base_provider import AIRequest
        
        # Testar Enhanced Mock Provider
        enhanced_mock = EnhancedMockProvider("enhanced_mock", {
            "enabled": True,
            "model": "enhanced-mock-gpt-4"
        })
        
        assert enhanced_mock.is_available(), "Enhanced Mock não está disponível"
        
        # Testar análise
        request = AIRequest(
            prompt="Analise este programa COBOL funcionalmente.",
            context={"program_name": "TEST", "source_lines": ["PROGRAM-ID. TEST."]}
        )
        
        response = enhanced_mock.analyze(request)
        assert response.success, "Enhanced Mock falhou na análise"
        assert len(response.content) > 0, "Enhanced Mock não retornou conteúdo"
        
        print("  Enhanced Mock Provider: OK")
        
        # Testar Basic Provider
        basic = BasicProvider("basic", {"enabled": True})
        
        assert basic.is_available(), "Basic Provider não está disponível"
        
        response = basic.analyze(request)
        assert response.success, "Basic Provider falhou na análise"
        
        print("  Basic Provider: OK")
        print("  Provedores de IA: OK")
        return True
        
    except Exception as e:
        print(f"  Provedores de IA: ERRO - {str(e)}")
        return False


def test_documentation_generator():
    """Testa o gerador de documentação."""
    print("Testando gerador de documentação...")
    
    try:
        from generators.documentation_generator import DocumentationGenerator
        from parsers.cobol_parser import CobolProgram
        from providers.base_provider import AIResponse
        
        doc_gen = DocumentationGenerator()
        
        # Criar programa de teste
        program = CobolProgram(
            name="TEST_PROG",
            source_lines=["PROGRAM-ID. TEST_PROG.", "DISPLAY 'HELLO WORLD'."],
            line_count=2,
            char_count=50,
            divisions=["IDENTIFICATION", "PROCEDURE"],
            sections=[]
        )
        
        # Criar resposta de IA de teste
        ai_response = AIResponse(
            content="Este programa exibe 'Hello World'.",
            tokens_used=10,
            provider_name="test",
            model_name="test-model",
            success=True
        )
        
        # Gerar documentação
        doc_content = doc_gen.generate_program_documentation(program, ai_response)
        
        assert len(doc_content) > 0, "Documentação não foi gerada"
        assert "TEST_PROG" in doc_content, "Nome do programa não está na documentação"
        assert "Hello World" in doc_content, "Análise de IA não está na documentação"
        
        print("  Gerador de documentação: OK")
        return True
        
    except Exception as e:
        print(f"  Gerador de documentação: ERRO - {str(e)}")
        return False


def test_complete_workflow():
    """Testa o fluxo completo do sistema."""
    print("Testando fluxo completo...")
    
    try:
        # Criar diretório temporário para saída
        with tempfile.TemporaryDirectory() as temp_dir:
            
            # Inicializar engine
            engine = CobolAIEngine("config/config.yaml")
            
            # Verificar se arquivos de exemplo existem
            if not os.path.exists("examples/fontes.txt"):
                print("  Fluxo completo: AVISO - Arquivos de exemplo não encontrados")
                return True
            
            # Processar arquivos
            results = engine.process_files(
                fontes_path="examples/fontes.txt",
                books_path="examples/BOOKS.txt" if os.path.exists("examples/BOOKS.txt") else None,
                output_dir=temp_dir
            )
            
            # Verificar resultados
            assert results["success"], f"Processamento falhou: {results.get('error', 'Erro desconhecido')}"
            assert results["files_generated"] > 0, "Nenhum arquivo foi gerado"
            
            # Verificar se arquivos foram criados
            generated_files = results["generated_files"]
            for filename in generated_files:
                filepath = os.path.join(temp_dir, filename)
                assert os.path.exists(filepath), f"Arquivo não foi criado: {filename}"
                
                # Verificar se arquivo não está vazio
                with open(filepath, 'r', encoding='utf-8') as f:
                    content = f.read()
                    assert len(content) > 0, f"Arquivo está vazio: {filename}"
            
            print(f"  Programas processados: {results['programs_processed']}")
            print(f"  Books processados: {results['books_processed']}")
            print(f"  Arquivos gerados: {results['files_generated']}")
            print(f"  Tempo de processamento: {results['processing_time_seconds']:.2f}s")
            print("  Fluxo completo: OK")
            return True
            
    except Exception as e:
        print(f"  Fluxo completo: ERRO - {str(e)}")
        return False


def test_command_line_interface():
    """Testa a interface de linha de comando."""
    print("Testando interface de linha de comando...")
    
    try:
        import subprocess
        
        # Testar comando --version
        result = subprocess.run([
            sys.executable, "main.py", "--version"
        ], capture_output=True, text=True, cwd=".")
        
        assert result.returncode == 0, f"Comando --version falhou: {result.stderr}"
        assert "2.0.0" in result.stdout, "Versão incorreta"
        
        print("  Comando --version: OK")
        
        # Testar comando --status
        result = subprocess.run([
            sys.executable, "main.py", "--status"
        ], capture_output=True, text=True, cwd=".")
        
        assert result.returncode == 0, f"Comando --status falhou: {result.stderr}"
        assert "enhanced_mock" in result.stdout, "Status dos provedores incorreto"
        
        print("  Comando --status: OK")
        print("  Interface de linha de comando: OK")
        return True
        
    except Exception as e:
        print(f"  Interface de linha de comando: ERRO - {str(e)}")
        return False


def main():
    """Executa todos os testes."""
    
    print("=" * 60)
    print("COBOL AI Engine v2.0 - Teste Completo do Sistema")
    print("=" * 60)
    print(f"Data: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}")
    print()
    
    # Lista de testes
    tests = [
        ("Configuração", test_configuration),
        ("Parser COBOL", test_parser),
        ("Provedores de IA", test_providers),
        ("Gerador de Documentação", test_documentation_generator),
        ("Fluxo Completo", test_complete_workflow),
        ("Interface de Linha de Comando", test_command_line_interface)
    ]
    
    # Executar testes
    results = {}
    
    for test_name, test_func in tests:
        print(f"Executando: {test_name}")
        print("-" * 40)
        
        try:
            success = test_func()
            results[test_name] = success
        except Exception as e:
            print(f"  ERRO INESPERADO: {str(e)}")
            results[test_name] = False
        
        print()
    
    # Resumo dos resultados
    print("=" * 60)
    print("RESUMO DOS TESTES")
    print("=" * 60)
    
    total_tests = len(results)
    passed_tests = sum(1 for success in results.values() if success)
    
    for test_name, success in results.items():
        status = "PASSOU" if success else "FALHOU"
        print(f"{test_name}: {status}")
    
    print()
    print(f"Total de testes: {total_tests}")
    print(f"Testes aprovados: {passed_tests}")
    print(f"Taxa de sucesso: {(passed_tests/total_tests*100):.1f}%")
    
    # Salvar resultados em JSON
    test_results = {
        "timestamp": datetime.now().isoformat(),
        "version": "2.0.0",
        "total_tests": total_tests,
        "passed_tests": passed_tests,
        "success_rate": passed_tests/total_tests*100,
        "results": results
    }
    
    with open("test_results_v2.0.json", "w", encoding="utf-8") as f:
        json.dump(test_results, f, indent=2, ensure_ascii=False)
    
    print(f"\nResultados salvos em: test_results_v2.0.json")
    
    # Status final
    if passed_tests == total_tests:
        print("\nSTATUS GERAL: APROVADO")
        print("Todos os testes passaram com sucesso!")
        return 0
    else:
        print("\nSTATUS GERAL: REPROVADO")
        print(f"{total_tests - passed_tests} teste(s) falharam.")
        return 1


if __name__ == "__main__":
    sys.exit(main())

