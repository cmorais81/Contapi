"""
COBOL AI Engine v2.0 - Gerador de Documentação
Gerador simples e robusto de documentação Markdown.
"""

import logging
from datetime import datetime
from typing import Dict, Any, List, Optional
from parsers.cobol_parser import CobolProgram, CobolBook
from providers.base_provider import AIResponse


class DocumentationGenerator:
    """Gerador de documentação Markdown."""
    
    def __init__(self):
        """Inicializa o gerador de documentação."""
        self.logger = logging.getLogger(__name__)
    
    def generate_program_documentation(
        self, 
        program: CobolProgram, 
        ai_response: Optional[AIResponse] = None
    ) -> str:
        """
        Gera documentação completa de um programa.
        
        Args:
            program: Programa COBOL
            ai_response: Resposta da análise de IA (opcional)
            
        Returns:
            Documentação em Markdown
        """
        
        # Cabeçalho
        doc = f"# Documentação do Programa {program.name}\n\n"
        doc += f"**Data de Geração**: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}\n\n"
        
        # Informações básicas
        doc += self._generate_basic_info(program)
        
        # Análise com IA (se disponível)
        if ai_response and ai_response.success:
            doc += self._generate_ai_analysis_section(ai_response)
        else:
            doc += "## Análise com IA\n\n"
            if ai_response and ai_response.error_message:
                doc += f"Erro na análise: {ai_response.error_message}\n\n"
            else:
                doc += "Análise com IA não disponível\n\n"
        
        # Estrutura do código
        doc += self._generate_structure_section(program)
        
        # Código fonte
        doc += self._generate_source_section(program)
        
        # Rodapé
        doc += "\n---\n\n"
        doc += "*Documentação gerada pelo COBOL AI Engine v2.0*\n"
        
        return doc
    
    def _generate_basic_info(self, program: CobolProgram) -> str:
        """Gera seção de informações básicas."""
        
        doc = "## Informações Básicas\n\n"
        doc += f"- **Nome**: {program.name}\n"
        doc += f"- **Linhas de Código**: {program.line_count}\n"
        doc += f"- **Tamanho**: {program.char_count} caracteres\n\n"
        
        return doc
    
    def _generate_ai_analysis_section(self, ai_response: AIResponse) -> str:
        """Gera seção de análise com IA."""
        
        doc = "## Análise com IA\n\n"
        doc += ai_response.content
        doc += "\n\n"
        
        # Metadados da análise
        doc += "### Metadados da Análise\n\n"
        doc += f"- **Provedor**: {ai_response.provider_name}\n"
        doc += f"- **Modelo**: {ai_response.model_name}\n"
        doc += f"- **Tokens Utilizados**: {ai_response.tokens_used}\n"
        
        if ai_response.metadata:
            for key, value in ai_response.metadata.items():
                if key not in ['timestamp']:  # Pular campos internos
                    doc += f"- **{key.replace('_', ' ').title()}**: {value}\n"
        
        doc += "\n"
        
        return doc
    
    def _generate_structure_section(self, program: CobolProgram) -> str:
        """Gera seção de estrutura do código."""
        
        doc = "## Estrutura do Código\n\n"
        
        # Divisões COBOL
        if program.divisions:
            doc += "### Divisões COBOL\n"
            for division in program.divisions:
                doc += f"- {division} Division\n"
            doc += "\n"
        
        # Seções
        if program.sections:
            doc += "### Seções\n"
            for section in program.sections:
                doc += f"- {section} Section\n"
            doc += "\n"
        
        # Estatísticas básicas
        doc += "### Estatísticas\n"
        doc += f"- **Total de Linhas**: {program.line_count}\n"
        doc += f"- **Divisões Identificadas**: {len(program.divisions)}\n"
        doc += f"- **Seções Identificadas**: {len(program.sections)}\n\n"
        
        return doc
    
    def _generate_source_section(self, program: CobolProgram, max_lines: int = 50) -> str:
        """Gera seção de código fonte."""
        
        doc = f"## Código Fonte (Primeiras {max_lines} linhas)\n\n"
        doc += "```cobol\n"
        
        # Cabeçalho com régua
        doc += " ----+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----8\n"
        
        # Linhas do código
        preview_lines = program.get_source_preview(max_lines)
        for i, line in enumerate(preview_lines, 1):
            # Adicionar indicador de linha
            line_indicator = "V" if i <= len(preview_lines) else " "
            doc += f"{line_indicator}{line}\n"
        
        if program.line_count > max_lines:
            doc += f"\n... ({program.line_count - max_lines} linhas restantes)\n"
        
        doc += "```\n\n"
        
        return doc
    
    def generate_summary_report(
        self, 
        programs: List[CobolProgram], 
        books: List[CobolBook],
        analysis_results: Dict[str, AIResponse] = None
    ) -> str:
        """
        Gera relatório consolidado.
        
        Args:
            programs: Lista de programas
            books: Lista de books
            analysis_results: Resultados das análises (opcional)
            
        Returns:
            Relatório em Markdown
        """
        
        doc = "# Relatório Consolidado - Análise COBOL\n\n"
        doc += f"**Data de Geração**: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}\n"
        doc += f"**Sistema**: COBOL AI Engine v2.0\n\n"
        
        # Resumo executivo
        doc += "## Resumo Executivo\n\n"
        
        # Programas processados
        doc += "### Programas Processados\n\n"
        doc += f"{len(programs)} programas COBOL analisados:\n\n"
        
        for program in programs:
            doc += f"- **{program.name}** ({program.line_count} linhas)\n"
        
        doc += "\n"
        
        # Books/Copybooks
        if books:
            doc += "### Books/Copybooks\n\n"
            doc += f"{len(books)} books processados:\n\n"
            
            for book in books:
                doc += f"- **{book.name}** ({book.line_count} linhas)\n"
            
            doc += "\n"
        
        # Estatísticas gerais
        doc += "### Estatísticas Gerais\n\n"
        
        total_program_lines = sum(p.line_count for p in programs)
        total_book_lines = sum(b.line_count for b in books)
        
        doc += f"- **Total de Linhas de Programas**: {total_program_lines}\n"
        doc += f"- **Total de Linhas de Books**: {total_book_lines}\n"
        doc += f"- **Total Geral**: {total_program_lines + total_book_lines}\n"
        
        if programs:
            doc += f"- **Média de Linhas por Programa**: {total_program_lines / len(programs):.0f}\n"
        
        doc += "\n"
        
        # Resultados da análise com IA
        if analysis_results:
            doc += "### Análises com IA\n\n"
            
            successful_analyses = sum(1 for r in analysis_results.values() if r.success)
            total_tokens = sum(r.tokens_used for r in analysis_results.values() if r.success)
            
            doc += f"- **Análises Realizadas**: {len(analysis_results)}\n"
            doc += f"- **Análises Bem-sucedidas**: {successful_analyses}\n"
            doc += f"- **Taxa de Sucesso**: {(successful_analyses/len(analysis_results)*100):.1f}%\n"
            doc += f"- **Total de Tokens Utilizados**: {total_tokens}\n\n"
            
            # Provedores utilizados
            providers_used = {}
            for response in analysis_results.values():
                if response.success:
                    provider = response.provider_name
                    providers_used[provider] = providers_used.get(provider, 0) + 1
            
            if providers_used:
                doc += "**Provedores Utilizados**:\n\n"
                for provider, count in providers_used.items():
                    doc += f"- {provider}: {count} análises\n"
                doc += "\n"
        
        # Arquivos gerados
        doc += "### Arquivos de Documentação\n\n"
        doc += "Os seguintes arquivos foram gerados:\n\n"
        
        for program in programs:
            doc += f"- `{program.name}.md` - Documentação completa do programa\n"
        
        doc += f"- `relatorio_completo.md` - Este relatório consolidado\n\n"
        
        # Rodapé
        doc += "---\n\n"
        doc += "*Relatório gerado pelo COBOL AI Engine v2.0*\n"
        
        return doc

