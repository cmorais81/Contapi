#!/usr/bin/env python3
"""
COBOL AI Engine v2.0 - Script Principal
Sistema de análise e documentação de programas COBOL.
"""

import sys
import argparse
import os
from pathlib import Path

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from core.engine import CobolAIEngine


def main():
    """Função principal."""
    
    parser = argparse.ArgumentParser(
        description='COBOL AI Engine v2.0 - Análise e documentação de programas COBOL',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Exemplos de uso:

  # Análise básica
  python main.py --fontes dados/fontes.txt --books dados/books.txt --output documentacao

  # Com configuração específica
  python main.py --fontes dados/fontes.txt --books dados/books.txt --output docs --config config/config.yaml

  # Apenas programas (sem books)
  python main.py --fontes dados/fontes.txt --output docs

  # Verificar versão
  python main.py --version

  # Status dos provedores
  python main.py --status
        """
    )
    
    parser.add_argument(
        '--fontes',
        type=str,
        help='Caminho para arquivo de programas COBOL (formato empilhado)'
    )
    
    parser.add_argument(
        '--books',
        type=str,
        help='Caminho para arquivo de copybooks/books (opcional)'
    )
    
    parser.add_argument(
        '--output',
        type=str,
        default='output',
        help='Diretório de saída para documentação (padrão: output)'
    )
    
    parser.add_argument(
        '--config',
        type=str,
        default='config/config.yaml',
        help='Caminho para arquivo de configuração (padrão: config/config.yaml)'
    )
    
    parser.add_argument(
        '--version',
        action='store_true',
        help='Mostra a versão do sistema'
    )
    
    parser.add_argument(
        '--status',
        action='store_true',
        help='Mostra status dos provedores de IA'
    )
    
    args = parser.parse_args()
    
    # Verificar versão
    if args.version:
        try:
            engine = CobolAIEngine(args.config)
            version = engine.get_version()
            print(f"COBOL AI Engine v{version}")
            return 0
        except Exception as e:
            print(f"Erro ao obter versão: {str(e)}")
            return 1
    
    # Verificar status
    if args.status:
        try:
            engine = CobolAIEngine(args.config)
            status = engine.get_provider_status()
            
            print("=== Status dos Provedores de IA ===")
            print(f"Provedores configurados: {status['total_configured']}")
            print(f"Provedores disponíveis: {status['total_available']}")
            print(f"Provedor primário: {status['primary_provider']}")
            print(f"Primário disponível: {'Sim' if status['primary_available'] else 'Não'}")
            print()
            
            print("Detalhes dos provedores:")
            for name, info in status['providers'].items():
                status_text = "Disponível" if info['available'] else "Indisponível"
                enabled_text = "Habilitado" if info['enabled'] else "Desabilitado"
                print(f"  {name}: {status_text} ({enabled_text}) - Modelo: {info['model']}")
            
            return 0
            
        except Exception as e:
            print(f"Erro ao obter status: {str(e)}")
            return 1
    
    # Validar argumentos obrigatórios
    if not args.fontes:
        print("Erro: Argumento --fontes é obrigatório")
        parser.print_help()
        return 1
    
    # Verificar se arquivo de fontes existe
    if not os.path.exists(args.fontes):
        print(f"Erro: Arquivo de fontes não encontrado: {args.fontes}")
        return 1
    
    # Verificar arquivo de books se especificado
    if args.books and not os.path.exists(args.books):
        print(f"Erro: Arquivo de books não encontrado: {args.books}")
        return 1
    
    # Verificar arquivo de configuração
    if not os.path.exists(args.config):
        print(f"Erro: Arquivo de configuração não encontrado: {args.config}")
        return 1
    
    try:
        # Inicializar engine
        print("Inicializando COBOL AI Engine v2.0...")
        engine = CobolAIEngine(args.config)
        
        # Processar arquivos
        print(f"Processando arquivos...")
        print(f"  Fontes: {args.fontes}")
        if args.books:
            print(f"  Books: {args.books}")
        print(f"  Saída: {args.output}")
        print()
        
        results = engine.process_files(
            fontes_path=args.fontes,
            books_path=args.books,
            output_dir=args.output
        )
        
        if results['success']:
            print("=== Processamento Concluído com Sucesso ===")
            print(f"Programas processados: {results['programs_processed']}")
            print(f"Books processados: {results['books_processed']}")
            print(f"Arquivos gerados: {results['files_generated']}")
            print(f"Tempo de processamento: {results['processing_time_seconds']:.2f}s")
            print(f"Diretório de saída: {results['output_directory']}")
            print()
            
            print("Arquivos gerados:")
            for filename in results['generated_files']:
                filepath = os.path.join(results['output_directory'], filename)
                if os.path.exists(filepath):
                    size = os.path.getsize(filepath)
                    print(f"  {filename} ({size} bytes)")
            
            print()
            print("Para visualizar os resultados:")
            print(f"  cd {results['output_directory']}")
            print("  # Abrir arquivos .md com seu editor preferido")
            
            return 0
        else:
            print("=== Erro no Processamento ===")
            print(f"Erro: {results['error']}")
            return 1
            
    except KeyboardInterrupt:
        print("\nProcessamento interrompido pelo usuário")
        return 1
    except Exception as e:
        print(f"Erro inesperado: {str(e)}")
        return 1


if __name__ == '__main__':
    sys.exit(main())

