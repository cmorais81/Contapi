# COBOL AI Engine v2.0 - Manual do Usuário

**Versão**: 2.0.0  
**Data**: 09 de Setembro de 2025  

## 1. Introdução

Este manual descreve como usar o COBOL AI Engine v2.0, um sistema para análise e documentação automática de programas COBOL. A versão 2.0 foi completamente reescrita para garantir compatibilidade, simplicidade e robustez.

## 2. Instalação

Para instalar o sistema, siga as instruções no `MANUAL_INSTALACAO_WINDOWS.md` ou `MANUAL_INSTALACAO_LINUX.md`.

## 3. Uso Básico

O sistema é executado via linha de comando. O comando principal é:

```bash
python main.py --fontes <arquivo_fontes> --books <arquivo_books> --output <pasta_saida>
```

### Argumentos

- `--fontes`: (Obrigatório) Caminho para o arquivo com programas COBOL.
- `--books`: (Opcional) Caminho para o arquivo com copybooks.
- `--output`: (Opcional) Pasta para salvar a documentação. Padrão: `output`.
- `--config`: (Opcional) Caminho para o arquivo de configuração. Padrão: `config/config.yaml`.

## 4. Exemplos de Uso

### Análise com Enhanced Mock (Padrão)

```bash
python main.py --fontes examples/fontes.txt --books examples/BOOKS.txt --output documentacao_mock
```

### Análise com OpenAI

1. **Habilitar no `config.yaml`**:
   ```yaml
   openai:
     enabled: true
   ```

2. **Definir chave de API**:
   ```bash
   export OPENAI_API_KEY="sua_chave_aqui"
   ```

3. **Executar**:
   ```bash
   python main.py --fontes examples/fontes.txt --books examples/BOOKS.txt --output documentacao_openai
   ```

### Análise com LuzIA

1. **Habilitar no `config.yaml`**:
   ```yaml
   luzia:
     enabled: true
   ```

2. **Definir credenciais**:
   ```bash
   export LUZIA_CLIENT_ID="seu_client_id"
   export LUZIA_CLIENT_SECRET="seu_client_secret"
   ```

3. **Executar**:
   ```bash
   python main.py --fontes examples/fontes.txt --books examples/BOOKS.txt --output documentacao_luzia
   ```

## 5. Comandos Adicionais

### Verificar Versão

```bash
python main.py --version
```

### Verificar Status dos Provedores

```bash
python main.py --status
```

## 6. Formato dos Arquivos de Entrada

Os arquivos de entrada devem ser no formato "empilhado", com cada programa ou book precedido por `VMEMBER NAME`.

### Exemplo de `fontes.txt`

```
----+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----8
VMEMBER NAME  PROG001
 IDENTIFICATION DIVISION.
 PROGRAM-ID. PROG001.
 ...
```

## 7. Estrutura da Saída

O sistema gera os seguintes arquivos na pasta de saída:

- **`<NOME_PROGRAMA>.md`**: Documentação completa de cada programa.
- **`relatorio_completo.md`**: Relatório consolidado com estatísticas.

## 8. Solução de Problemas

- **Erro de configuração**: Verifique o arquivo `config/config.yaml` e as variáveis de ambiente.
- **Arquivo não encontrado**: Verifique os caminhos para os arquivos de fontes e books.
- **Análise falhou**: Verifique os logs em `logs/cobol_ai_engine.log` para detalhes.

## 9. Suporte

Para mais informações, consulte os seguintes documentos:

- `MANUAL_CONFIGURACAO.md`
- `MANUAL_INSTALACAO_WINDOWS.md`
- `MANUAL_INSTALACAO_LINUX.md`
- `README.md`

