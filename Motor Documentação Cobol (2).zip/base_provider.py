"""
COBOL AI Engine v2.0 - Interface Base para Provedores
Interface simples e robusta para provedores de IA.
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, Optional
from dataclasses import dataclass


@dataclass
class AIRequest:
    """Requisição para provedor de IA."""
    prompt: str
    max_tokens: int = 4000
    temperature: float = 0.1
    context: Optional[Dict[str, Any]] = None


@dataclass
class AIResponse:
    """Resposta de provedor de IA."""
    content: str
    tokens_used: int
    provider_name: str
    model_name: str
    success: bool
    error_message: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None


class BaseAIProvider(ABC):
    """Interface base para provedores de IA."""
    
    def __init__(self, name: str, config: Dict[str, Any]):
        """
        Inicializa o provedor.
        
        Args:
            name: Nome do provedor
            config: Configuração do provedor
        """
        self.name = name
        self.config = config
        self.enabled = config.get('enabled', False)
    
    @abstractmethod
    def is_available(self) -> bool:
        """
        Verifica se o provedor está disponível.
        
        Returns:
            True se o provedor está disponível
        """
        pass
    
    @abstractmethod
    def analyze(self, request: AIRequest) -> AIResponse:
        """
        Analisa o conteúdo usando IA.
        
        Args:
            request: Requisição de análise
            
        Returns:
            Resposta da análise
        """
        pass
    
    def get_model_name(self) -> str:
        """Retorna o nome do modelo."""
        return self.config.get('model', 'unknown')
    
    def get_max_tokens(self) -> int:
        """Retorna o limite máximo de tokens."""
        return self.config.get('max_tokens', 4000)
    
    def get_temperature(self) -> float:
        """Retorna a temperatura padrão."""
        return self.config.get('temperature', 0.1)
    
    def get_timeout(self) -> int:
        """Retorna o timeout em segundos."""
        return self.config.get('timeout', 30)

