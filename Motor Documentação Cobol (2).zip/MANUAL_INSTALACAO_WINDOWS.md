# COBOL AI Engine v2.0 - Manual de Instalação (Windows)

**Versão**: 2.0.0  
**Data**: 09 de Setembro de 2025  

## 1. Pré-requisitos

- Windows 10 ou 11
- Python 3.11 ou superior
- PowerShell ou Command Prompt

## 2. Instalação do Python

1. Baixe Python de https://www.python.org/downloads/
2. Execute o instalador
3. **IMPORTANTE**: Marque a opção "Add Python to PATH"
4. Siga as instruções de instalação

## 3. Instalação do COBOL AI Engine

### Passo 1: Extrair o Pacote

1. Extraia o arquivo `cobol_ai_engine_v2.0.tar.gz` para uma pasta (ex: `C:\cobol_ai`)

### Passo 2: Instalar Dependências

1. Abra o Command Prompt
2. Navegue para a pasta do projeto:
   ```cmd
   cd C:\cobol_ai\cobol_ai_engine_v2.0
   ```
3. Instale as dependências:
   ```cmd
   pip install -r requirements.txt
   ```

## 4. Verificação da Instalação

```cmd
python main.py --version
```

**Resultado esperado**: `COBOL AI Engine v2.0.0`

## 5. Execução

```cmd
python main.py --fontes examples/fontes.txt --books examples/BOOKS.txt
```

## 6. Solução de Problemas

- **`python` não reconhecido**: Reinstale o Python marcando "Add Python to PATH"
- **Erro de dependências**: Execute `pip install --user -r requirements.txt`

Para mais detalhes, consulte o `MANUAL_USUARIO.md`.

