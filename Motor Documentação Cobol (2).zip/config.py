"""
COBOL AI Engine v2.0 - Sistema de Configuração Unificado
Configuração simples, robusta e compatível.
"""

import os
import yaml
import logging
from typing import Dict, Any, List, Optional
from dataclasses import dataclass


@dataclass
class ProviderConfig:
    """Configuração de um provedor de IA."""
    name: str
    enabled: bool
    config: Dict[str, Any]


@dataclass
class AIConfig:
    """Configuração completa de IA."""
    primary_provider: str
    fallback_providers: List[str]
    providers: Dict[str, ProviderConfig]


class ConfigManager:
    """Gerenciador de configuração unificado."""
    
    def __init__(self, config_path: str = "config/config.yaml"):
        """
        Inicializa o gerenciador de configuração.
        
        Args:
            config_path: Caminho para o arquivo de configuração
        """
        self.config_path = config_path
        self.config = {}
        self.ai_config = None
        self._load_config()
        self._validate_config()
    
    def _load_config(self) -> None:
        """Carrega a configuração do arquivo YAML."""
        try:
            if not os.path.exists(self.config_path):
                raise FileNotFoundError(f"Arquivo de configuração não encontrado: {self.config_path}")
            
            with open(self.config_path, 'r', encoding='utf-8') as f:
                self.config = yaml.safe_load(f)
            
            # Expandir variáveis de ambiente
            self._expand_env_vars(self.config)
            
            # Processar configuração de IA
            self._process_ai_config()
            
        except Exception as e:
            raise RuntimeError(f"Erro ao carregar configuração: {str(e)}")
    
    def _expand_env_vars(self, obj: Any) -> None:
        """Expande variáveis de ambiente recursivamente."""
        if isinstance(obj, dict):
            for key, value in obj.items():
                if isinstance(value, str) and value.startswith("${") and value.endswith("}"):
                    env_var = value[2:-1]
                    obj[key] = os.getenv(env_var, "")
                elif isinstance(value, (dict, list)):
                    self._expand_env_vars(value)
        elif isinstance(obj, list):
            for item in obj:
                self._expand_env_vars(item)
    
    def _process_ai_config(self) -> None:
        """Processa a configuração de IA."""
        if 'ai' not in self.config:
            raise ValueError("Seção 'ai' é obrigatória na configuração")
        
        ai_section = self.config['ai']
        
        # Validar campos obrigatórios
        if 'primary_provider' not in ai_section:
            raise ValueError("Campo 'primary_provider' é obrigatório na seção 'ai'")
        
        if 'providers' not in ai_section:
            raise ValueError("Campo 'providers' é obrigatório na seção 'ai'")
        
        # Processar provedores
        providers = {}
        for name, config in ai_section['providers'].items():
            enabled = config.get('enabled', False)
            providers[name] = ProviderConfig(
                name=name,
                enabled=enabled,
                config=config
            )
        
        # Criar configuração de IA
        self.ai_config = AIConfig(
            primary_provider=ai_section['primary_provider'],
            fallback_providers=ai_section.get('fallback_providers', []),
            providers=providers
        )
    
    def _validate_config(self) -> None:
        """Valida a configuração carregada."""
        if not self.ai_config:
            raise ValueError("Configuração de IA não foi processada corretamente")
        
        # Verificar se o provedor principal existe
        if self.ai_config.primary_provider not in self.ai_config.providers:
            raise ValueError(f"Provedor principal '{self.ai_config.primary_provider}' não encontrado na configuração")
        
        # Verificar se pelo menos um provedor está habilitado
        enabled_providers = [p for p in self.ai_config.providers.values() if p.enabled]
        if not enabled_providers:
            # Habilitar enhanced_mock como fallback
            if 'enhanced_mock' in self.ai_config.providers:
                self.ai_config.providers['enhanced_mock'].enabled = True
                logging.warning("Nenhum provedor habilitado. Habilitando enhanced_mock automaticamente.")
            else:
                raise ValueError("Nenhum provedor de IA está habilitado")
    
    def get_ai_config(self) -> AIConfig:
        """Retorna a configuração de IA."""
        return self.ai_config
    
    def get_provider_config(self, provider_name: str) -> Optional[ProviderConfig]:
        """
        Retorna a configuração de um provedor específico.
        
        Args:
            provider_name: Nome do provedor
            
        Returns:
            Configuração do provedor ou None se não encontrado
        """
        return self.ai_config.providers.get(provider_name)
    
    def get_enabled_providers(self) -> List[ProviderConfig]:
        """Retorna lista de provedores habilitados."""
        return [p for p in self.ai_config.providers.values() if p.enabled]
    
    def get_processing_config(self) -> Dict[str, Any]:
        """Retorna configuração de processamento."""
        return self.config.get('processing', {})
    
    def get_logging_config(self) -> Dict[str, Any]:
        """Retorna configuração de logging."""
        return self.config.get('logging', {
            'level': 'INFO',
            'format': '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        })
    
    def is_provider_available(self, provider_name: str) -> bool:
        """
        Verifica se um provedor está disponível (habilitado e configurado).
        
        Args:
            provider_name: Nome do provedor
            
        Returns:
            True se o provedor está disponível
        """
        provider = self.get_provider_config(provider_name)
        if not provider or not provider.enabled:
            return False
        
        # Verificações específicas por provedor
        if provider_name == "openai":
            return bool(provider.config.get('api_key'))
        elif provider_name == "luzia":
            return bool(provider.config.get('client_id') and provider.config.get('client_secret'))
        elif provider_name in ["enhanced_mock", "basic"]:
            return True
        
        return True
    
    def get_available_providers(self) -> List[str]:
        """Retorna lista de provedores disponíveis."""
        return [name for name in self.ai_config.providers.keys() if self.is_provider_available(name)]


def load_config(config_path: str = "config/config.yaml") -> ConfigManager:
    """
    Carrega e retorna o gerenciador de configuração.
    
    Args:
        config_path: Caminho para o arquivo de configuração
        
    Returns:
        Instância do ConfigManager
    """
    return ConfigManager(config_path)

