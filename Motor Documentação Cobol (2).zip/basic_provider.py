"""
COBOL AI Engine v2.0 - Basic Provider
Provedor básico que sempre funciona como fallback final.
"""

import logging
from typing import Dict, Any
from providers.base_provider import BaseAIProvider, AIRequest, AIResponse


class BasicProvider(BaseAIProvider):
    """Provedor básico que sempre funciona."""
    
    def __init__(self, name: str, config: Dict[str, Any]):
        """Inicializa o provedor básico."""
        super().__init__(name, config)
        self.logger = logging.getLogger(__name__)
    
    def is_available(self) -> bool:
        """Provedor básico está sempre disponível."""
        return True
    
    def analyze(self, request: AIRequest) -> AIResponse:
        """
        Fornece análise básica sem IA.
        
        Args:
            request: Requisição de análise
            
        Returns:
            Resposta básica
        """
        try:
            # Extrair informações do contexto
            program_name = "PROGRAMA"
            if request.context:
                program_name = request.context.get('program_name', 'PROGRAMA')
            
            # Gerar análise básica
            content = self._generate_basic_analysis(program_name, request.context)
            
            return AIResponse(
                content=content,
                tokens_used=len(content.split()),
                provider_name=self.name,
                model_name="basic-analysis",
                success=True,
                metadata={
                    'type': 'basic_analysis',
                    'no_ai': True
                }
            )
            
        except Exception as e:
            self.logger.error(f"Erro no Basic Provider: {str(e)}")
            return AIResponse(
                content="Análise básica não disponível devido a erro interno.",
                tokens_used=0,
                provider_name=self.name,
                model_name="basic-analysis",
                success=False,
                error_message=str(e)
            )
    
    def _generate_basic_analysis(self, program_name: str, context: Dict[str, Any] = None) -> str:
        """Gera análise básica sem IA."""
        
        # Informações básicas do contexto
        line_count = 0
        char_count = 0
        divisions = []
        
        if context:
            line_count = context.get('line_count', 0)
            char_count = context.get('char_count', 0)
            divisions = context.get('divisions', [])
        
        divisions_text = ", ".join(divisions) if divisions else "Não identificadas"
        
        return f"""## Análise Básica - {program_name}

### Informações Gerais
- **Nome do Programa**: {program_name}
- **Linhas de Código**: {line_count}
- **Tamanho**: {char_count} caracteres

### Estrutura COBOL
- **Divisões Identificadas**: {divisions_text}
- **Tipo**: Programa COBOL padrão

### Observações
Esta é uma análise básica sem processamento de IA. Para análise mais detalhada, configure um provedor de IA (Enhanced Mock, OpenAI, ou LuzIA).

### Funcionalidade
O programa {program_name} é um programa COBOL que implementa lógica de negócio específica. Para entender sua funcionalidade detalhada, é recomendado:

1. Revisar o código fonte manualmente
2. Consultar documentação técnica
3. Configurar análise com IA para insights automáticos

### Próximos Passos
- Configure um provedor de IA para análise detalhada
- Revise a documentação técnica do sistema
- Consulte especialistas em COBOL se necessário"""

