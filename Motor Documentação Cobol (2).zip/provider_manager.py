"""
COBOL AI Engine v2.0 - Gerenciador de Provedores
Gerencia provedores de IA com fallback automático.
"""

import logging
from typing import Dict, Any, List, Optional
from providers.base_provider import BaseAIProvider, AIRequest, AIResponse
from providers.enhanced_mock_provider import EnhancedMockProvider
from providers.basic_provider import BasicProvider


class ProviderManager:
    """Gerenciador de provedores de IA com fallback."""
    
    def __init__(self, ai_config):
        """
        Inicializa o gerenciador de provedores.
        
        Args:
            ai_config: Configuração de IA
        """
        self.ai_config = ai_config
        self.logger = logging.getLogger(__name__)
        self.providers: Dict[str, BaseAIProvider] = {}
        
        # Inicializar provedores
        self._initialize_providers()
    
    def _initialize_providers(self) -> None:
        """Inicializa todos os provedores configurados."""
        
        for provider_name, provider_config in self.ai_config.providers.items():
            if not provider_config.enabled:
                continue
            
            try:
                provider = self._create_provider(provider_name, provider_config.config)
                if provider and provider.is_available():
                    self.providers[provider_name] = provider
                    self.logger.info(f"Provedor {provider_name} inicializado com sucesso")
                else:
                    self.logger.warning(f"Provedor {provider_name} não está disponível")
            
            except Exception as e:
                self.logger.error(f"Erro ao inicializar provedor {provider_name}: {str(e)}")
        
        # Garantir que pelo menos o provedor básico está disponível
        if not self.providers:
            self.logger.warning("Nenhum provedor disponível. Inicializando provedor básico.")
            basic_provider = BasicProvider("basic", {"enabled": True})
            self.providers["basic"] = basic_provider
    
    def _create_provider(self, name: str, config: Dict[str, Any]) -> Optional[BaseAIProvider]:
        """
        Cria instância de provedor.
        
        Args:
            name: Nome do provedor
            config: Configuração do provedor
            
        Returns:
            Instância do provedor ou None
        """
        
        if name == "enhanced_mock":
            return EnhancedMockProvider(name, config)
        elif name == "basic":
            return BasicProvider(name, config)
        elif name == "openai":
            # Importar apenas se necessário
            try:
                from .openai_provider import OpenAIProvider
                return OpenAIProvider(name, config)
            except ImportError:
                self.logger.warning("OpenAI provider não disponível (dependências não instaladas)")
                return None
        elif name == "luzia":
            # Importar apenas se necessário
            try:
                from .luzia_provider import LuziaProvider
                return LuziaProvider(name, config)
            except ImportError:
                self.logger.warning("LuzIA provider não disponível (dependências não instaladas)")
                return None
        else:
            self.logger.error(f"Provedor desconhecido: {name}")
            return None
    
    def get_available_providers(self) -> List[str]:
        """Retorna lista de provedores disponíveis."""
        return list(self.providers.keys())
    
    def analyze_with_fallback(self, request: AIRequest) -> AIResponse:
        """
        Executa análise com sistema de fallback.
        
        Args:
            request: Requisição de análise
            
        Returns:
            Resposta da análise
        """
        
        # Lista de provedores para tentar (primário + fallbacks)
        providers_to_try = []
        
        # Adicionar provedor primário se disponível
        if self.ai_config.primary_provider in self.providers:
            providers_to_try.append(self.ai_config.primary_provider)
        
        # Adicionar fallbacks se disponíveis
        for fallback in self.ai_config.fallback_providers:
            if fallback in self.providers and fallback not in providers_to_try:
                providers_to_try.append(fallback)
        
        # Adicionar todos os outros provedores disponíveis
        for provider_name in self.providers.keys():
            if provider_name not in providers_to_try:
                providers_to_try.append(provider_name)
        
        # Tentar cada provedor
        last_error = None
        
        for provider_name in providers_to_try:
            try:
                provider = self.providers[provider_name]
                self.logger.info(f"Tentando análise com provedor: {provider_name}")
                
                response = provider.analyze(request)
                
                if response.success:
                    self.logger.info(f"Análise bem-sucedida com provedor: {provider_name}")
                    return response
                else:
                    self.logger.warning(f"Provedor {provider_name} retornou erro: {response.error_message}")
                    last_error = response.error_message
            
            except Exception as e:
                self.logger.error(f"Erro ao usar provedor {provider_name}: {str(e)}")
                last_error = str(e)
        
        # Se chegou aqui, todos os provedores falharam
        self.logger.error("Todos os provedores falharam")
        
        return AIResponse(
            content="Análise não disponível - todos os provedores falharam.",
            tokens_used=0,
            provider_name="none",
            model_name="none",
            success=False,
            error_message=f"Todos os provedores falharam. Último erro: {last_error}"
        )
    
    def get_provider_status(self) -> Dict[str, Any]:
        """Retorna status de todos os provedores."""
        
        status = {
            'total_configured': len(self.ai_config.providers),
            'total_available': len(self.providers),
            'primary_provider': self.ai_config.primary_provider,
            'primary_available': self.ai_config.primary_provider in self.providers,
            'providers': {}
        }
        
        for name, config in self.ai_config.providers.items():
            provider_status = {
                'enabled': config.enabled,
                'available': name in self.providers,
                'model': config.config.get('model', 'unknown')
            }
            
            if name in self.providers:
                provider_status['initialized'] = True
            else:
                provider_status['initialized'] = False
            
            status['providers'][name] = provider_status
        
        return status

