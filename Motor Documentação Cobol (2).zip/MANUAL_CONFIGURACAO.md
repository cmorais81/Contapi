# COBOL AI Engine v2.0 - Manual de Configuração

**Versão**: 2.0.0  
**Data**: 09 de Setembro de 2025  

## 1. Introdução

Este manual descreve como configurar o COBOL AI Engine v2.0. A configuração é feita através do arquivo `config/config.yaml`.

## 2. Estrutura do `config.yaml`

O arquivo de configuração tem 3 seções principais:

- `ai`: Configurações dos provedores de análise.
- `processing`: Configurações de processamento.
- `logging`: Configurações de log.

## 3. Seção `ai`

### `primary_provider`
- **Descrição**: Provedor principal a ser usado.
- **Padrão**: `enhanced_mock`
- **Recomendação**: Manter `enhanced_mock` para garantir funcionamento.

### `fallback_providers`
- **Descrição**: Lista de provedores de fallback em ordem de prioridade.
- **Padrão**: `["basic"]`

### `providers`
- **Descrição**: Configuração de cada provedor.

#### `enhanced_mock`
- **Descrição**: Provedor simulado que sempre funciona.
- **Configuração**:
  ```yaml
  enhanced_mock:
    enabled: true
    model: "enhanced-mock-gpt-4"
  ```

#### `basic`
- **Descrição**: Provedor básico como fallback final.
- **Configuração**:
  ```yaml
  basic:
    enabled: true
  ```

#### `openai`
- **Descrição**: Provedor OpenAI (requer chave de API).
- **Configuração**:
  ```yaml
  openai:
    enabled: true
    api_key: "${OPENAI_API_KEY}"
    model: "gpt-4"
  ```
- **Variável de Ambiente**: `OPENAI_API_KEY`

#### `luzia`
- **Descrição**: Provedor LuzIA (requer credenciais corporativas).
- **Configuração**:
  ```yaml
  luzia:
    enabled: true
    client_id: "${LUZIA_CLIENT_ID}"
    client_secret: "${LUZIA_CLIENT_SECRET}"
    endpoint: "https://..."
  ```
- **Variáveis de Ambiente**: `LUZIA_CLIENT_ID`, `LUZIA_CLIENT_SECRET`

## 4. Seção `processing`

- **`analysis_types`**: Tipos de análise a serem realizadas.
- **`output`**: Configurações de saída (formato, etc.).

## 5. Seção `logging`

- **`level`**: Nível de log (DEBUG, INFO, WARNING, ERROR).
- **`format`**: Formato das mensagens de log.
- **`file`**: Arquivo para salvar os logs.

## 6. Configuração de Variáveis de Ambiente

### Windows
```cmd
set OPENAI_API_KEY=sua_chave_aqui
```

### Linux/macOS
```bash
export OPENAI_API_KEY="sua_chave_aqui"
```

## 7. Exemplo Completo de `config.yaml`

```yaml
ai:
  primary_provider: "enhanced_mock"
  fallback_providers: ["basic"]
  
  providers:
    enhanced_mock:
      enabled: true
      model: "enhanced-mock-gpt-4"
      
    openai:
      enabled: false
      api_key: "${OPENAI_API_KEY}"
      model: "gpt-4"
      
    luzia:
      enabled: false
      client_id: "${LUZIA_CLIENT_ID}"
      client_secret: "${LUZIA_CLIENT_SECRET}"

processing:
  analysis_types: ["basic_info", "ai_analysis"]
  output:
    format: "markdown"

logging:
  level: "INFO"
  file: "logs/cobol_ai_engine.log"
```

