"""
COBOL AI Engine v2.0 - Parser COBOL Simplificado
Parser robusto e simples para arquivos COBOL.
"""

import re
import logging
from typing import List, Dict, Any, Optional
from dataclasses import dataclass


@dataclass
class CobolProgram:
    """Representa um programa COBOL."""
    name: str
    source_lines: List[str]
    line_count: int
    char_count: int
    divisions: List[str]
    sections: List[str]
    
    def get_source_preview(self, max_lines: int = 20) -> List[str]:
        """Retorna preview do código fonte."""
        return self.source_lines[:max_lines]
    
    def get_full_source(self) -> str:
        """Retorna código fonte completo."""
        return '\n'.join(self.source_lines)


@dataclass
class CobolBook:
    """Representa um copybook COBOL."""
    name: str
    source_lines: List[str]
    line_count: int
    char_count: int


class CobolParser:
    """Parser para arquivos COBOL empilhados."""
    
    def __init__(self):
        """Inicializa o parser."""
        self.logger = logging.getLogger(__name__)
        
        # Padrões regex
        self.vmember_pattern = re.compile(r'^VMEMBER\s+NAME\s*(\w+)', re.IGNORECASE)
        self.division_pattern = re.compile(r'^\s*(\w+)\s+DIVISION\.', re.IGNORECASE)
        self.section_pattern = re.compile(r'^\s*(\w+)\s+SECTION\.', re.IGNORECASE)
        self.program_id_pattern = re.compile(r'^\s*PROGRAM-ID\.\s*(\w+)', re.IGNORECASE)
    
    def parse_file(self, file_path: str) -> Dict[str, Any]:
        """
        Parseia arquivo COBOL empilhado.
        
        Args:
            file_path: Caminho para o arquivo
            
        Returns:
            Dicionário com programas e books parseados
        """
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                lines = f.readlines()
            
            # Processar linhas
            programs, books = self._parse_lines(lines)
            
            self.logger.info(f"Parseados {len(programs)} programas e {len(books)} books de {file_path}")
            
            return {
                'programs': programs,
                'books': books,
                'total_lines': len(lines)
            }
            
        except Exception as e:
            self.logger.error(f"Erro ao parsear arquivo {file_path}: {str(e)}")
            raise
    
    def _parse_lines(self, lines: List[str]) -> tuple[List[CobolProgram], List[CobolBook]]:
        """Parseia linhas do arquivo."""
        programs = []
        books = []
        current_member = None
        current_lines = []
        
        for line in lines:
            line = line.rstrip('\n\r')
            
            # Verificar se é início de novo membro
            vmember_match = self.vmember_pattern.match(line)
            if vmember_match:
                # Processar membro anterior se existir
                if current_member and current_lines:
                    member_obj = self._create_member_object(current_member, current_lines)
                    if member_obj:
                        if self._is_program(current_lines):
                            programs.append(member_obj)
                        else:
                            books.append(member_obj)
                
                # Iniciar novo membro
                current_member = vmember_match.group(1)
                current_lines = []
                continue
            
            # Adicionar linha ao membro atual
            if current_member:
                current_lines.append(line)
        
        # Processar último membro
        if current_member and current_lines:
            member_obj = self._create_member_object(current_member, current_lines)
            if member_obj:
                if self._is_program(current_lines):
                    programs.append(member_obj)
                else:
                    books.append(member_obj)
        
        return programs, books
    
    def _is_program(self, lines: List[str]) -> bool:
        """Verifica se as linhas representam um programa COBOL."""
        for line in lines[:20]:  # Verificar apenas primeiras 20 linhas
            if self.program_id_pattern.search(line):
                return True
            if 'IDENTIFICATION DIVISION' in line.upper():
                return True
        return False
    
    def _create_member_object(self, name: str, lines: List[str]) -> Optional[Any]:
        """Cria objeto CobolProgram ou CobolBook."""
        if not lines:
            return None
        
        # Filtrar linhas vazias e comentários
        filtered_lines = [line for line in lines if line.strip() and not line.strip().startswith('*')]
        
        if not filtered_lines:
            return None
        
        line_count = len(filtered_lines)
        char_count = sum(len(line) for line in filtered_lines)
        
        if self._is_program(lines):
            # Criar programa
            divisions = self._extract_divisions(filtered_lines)
            sections = self._extract_sections(filtered_lines)
            
            return CobolProgram(
                name=name,
                source_lines=filtered_lines,
                line_count=line_count,
                char_count=char_count,
                divisions=divisions,
                sections=sections
            )
        else:
            # Criar book
            return CobolBook(
                name=name,
                source_lines=filtered_lines,
                line_count=line_count,
                char_count=char_count
            )
    
    def _extract_divisions(self, lines: List[str]) -> List[str]:
        """Extrai divisões COBOL."""
        divisions = []
        for line in lines:
            match = self.division_pattern.search(line)
            if match:
                division = match.group(1).upper()
                if division not in divisions:
                    divisions.append(division)
        return divisions
    
    def _extract_sections(self, lines: List[str]) -> List[str]:
        """Extrai seções COBOL."""
        sections = []
        for line in lines:
            match = self.section_pattern.search(line)
            if match:
                section = match.group(1).upper()
                if section not in sections:
                    sections.append(section)
        return sections
    
    def get_program_statistics(self, programs: List[CobolProgram]) -> Dict[str, Any]:
        """Calcula estatísticas dos programas."""
        if not programs:
            return {}
        
        total_lines = sum(p.line_count for p in programs)
        total_chars = sum(p.char_count for p in programs)
        
        return {
            'total_programs': len(programs),
            'total_lines': total_lines,
            'total_characters': total_chars,
            'average_lines_per_program': total_lines / len(programs),
            'program_names': [p.name for p in programs]
        }
    
    def get_books_statistics(self, books: List[CobolBook]) -> Dict[str, Any]:
        """Calcula estatísticas dos books."""
        if not books:
            return {}
        
        total_lines = sum(b.line_count for b in books)
        total_chars = sum(b.char_count for b in books)
        
        return {
            'total_books': len(books),
            'total_lines': total_lines,
            'total_characters': total_chars,
            'average_lines_per_book': total_lines / len(books) if books else 0,
            'book_names': [b.name for b in books]
        }

