"""
COBOL AI Engine v2.0 - Engine Principal
Sistema principal simplificado e robusto.
"""

import os
import logging
from typing import Dict, Any, List, Optional
from datetime import datetime

from core.config import ConfigManager
from parsers.cobol_parser import CobolParser, CobolProgram, CobolBook
from providers.provider_manager import ProviderManager
from providers.base_provider import AIRequest, AIResponse
from generators.documentation_generator import DocumentationGenerator


class CobolAIEngine:
    """Engine principal do COBOL AI Engine v2.0."""
    
    def __init__(self, config_path: str = "config/config.yaml"):
        """
        Inicializa o engine.
        
        Args:
            config_path: Caminho para arquivo de configuração
        """
        
        # Configurar logging
        self._setup_logging()
        
        self.logger = logging.getLogger(__name__)
        self.logger.info("Inicializando COBOL AI Engine v2.0")
        
        # Carregar configuração
        try:
            self.config_manager = ConfigManager(config_path)
            self.logger.info("Configuração carregada com sucesso")
        except Exception as e:
            self.logger.error(f"Erro ao carregar configuração: {str(e)}")
            raise
        
        # Inicializar componentes
        self.parser = CobolParser()
        self.provider_manager = ProviderManager(self.config_manager.get_ai_config())
        self.doc_generator = DocumentationGenerator()
        
        self.logger.info("COBOL AI Engine v2.0 inicializado com sucesso")
    
    def _setup_logging(self) -> None:
        """Configura o sistema de logging."""
        
        # Criar diretório de logs se não existir
        os.makedirs("logs", exist_ok=True)
        
        # Configuração básica
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler('logs/cobol_ai_engine.log'),
                logging.StreamHandler()
            ]
        )
    
    def process_files(
        self, 
        fontes_path: str, 
        books_path: Optional[str] = None, 
        output_dir: str = "output"
    ) -> Dict[str, Any]:
        """
        Processa arquivos COBOL e gera documentação.
        
        Args:
            fontes_path: Caminho para arquivo de fontes
            books_path: Caminho para arquivo de books (opcional)
            output_dir: Diretório de saída
            
        Returns:
            Dicionário com resultados do processamento
        """
        
        self.logger.info("=== Iniciando Processamento ===")
        start_time = datetime.now()
        
        try:
            # Criar diretório de saída
            os.makedirs(output_dir, exist_ok=True)
            
            # Parsear arquivos
            programs, books = self._parse_files(fontes_path, books_path)
            
            # Analisar com IA
            analysis_results = self._analyze_programs(programs)
            
            # Gerar documentação
            generated_files = self._generate_documentation(programs, books, analysis_results, output_dir)
            
            # Calcular estatísticas
            end_time = datetime.now()
            processing_time = (end_time - start_time).total_seconds()
            
            results = {
                'success': True,
                'programs_processed': len(programs),
                'books_processed': len(books),
                'files_generated': len(generated_files),
                'processing_time_seconds': processing_time,
                'output_directory': output_dir,
                'generated_files': generated_files,
                'analysis_results': analysis_results
            }
            
            self.logger.info("=== Processamento Concluído com Sucesso ===")
            self._log_results(results)
            
            return results
            
        except Exception as e:
            self.logger.error(f"Erro durante processamento: {str(e)}")
            return {
                'success': False,
                'error': str(e),
                'processing_time_seconds': (datetime.now() - start_time).total_seconds()
            }
    
    def _parse_files(self, fontes_path: str, books_path: Optional[str]) -> tuple[List[CobolProgram], List[CobolBook]]:
        """Parseia arquivos de entrada."""
        
        self.logger.info("Parseando arquivos...")
        
        # Parsear programas
        programs = []
        if os.path.exists(fontes_path):
            fontes_result = self.parser.parse_file(fontes_path)
            programs = fontes_result['programs']
            self.logger.info(f"Parseados {len(programs)} programas de {fontes_path}")
        else:
            self.logger.warning(f"Arquivo de fontes não encontrado: {fontes_path}")
        
        # Parsear books
        books = []
        if books_path and os.path.exists(books_path):
            books_result = self.parser.parse_file(books_path)
            books = books_result['books']
            self.logger.info(f"Parseados {len(books)} books de {books_path}")
        elif books_path:
            self.logger.warning(f"Arquivo de books não encontrado: {books_path}")
        
        return programs, books
    
    def _analyze_programs(self, programs: List[CobolProgram]) -> Dict[str, AIResponse]:
        """Analisa programas com IA."""
        
        self.logger.info("Iniciando análise com IA...")
        
        analysis_results = {}
        
        for program in programs:
            self.logger.info(f"Analisando programa: {program.name}")
            
            # Preparar contexto para análise
            context = {
                'program_name': program.name,
                'source_lines': program.source_lines,
                'line_count': program.line_count,
                'char_count': program.char_count,
                'divisions': program.divisions,
                'sections': program.sections
            }
            
            # Criar prompt para análise funcional
            prompt = self._create_analysis_prompt(program)
            
            # Criar requisição
            request = AIRequest(
                prompt=prompt,
                max_tokens=4000,
                temperature=0.1,
                context=context
            )
            
            # Executar análise com fallback
            response = self.provider_manager.analyze_with_fallback(request)
            analysis_results[program.name] = response
            
            if response.success:
                self.logger.info(f"Análise de {program.name} concluída com {response.provider_name}")
            else:
                self.logger.warning(f"Falha na análise de {program.name}: {response.error_message}")
        
        return analysis_results
    
    def _create_analysis_prompt(self, program: CobolProgram) -> str:
        """Cria prompt para análise do programa."""
        
        # Obter preview do código
        source_preview = '\n'.join(program.get_source_preview(30))
        
        prompt = f"""Analise funcionalmente este programa COBOL:

PROGRAMA: {program.name}
LINHAS: {program.line_count}
DIVISÕES: {', '.join(program.divisions)}

CÓDIGO (primeiras 30 linhas):
{source_preview}

Por favor, responda especificamente:

1. O que este programa faz funcionalmente?
2. Qual o processo de negócio implementado?
3. Quais regras de negócio estão codificadas?
4. Que validações são realizadas?
5. Que transformações de dados ocorrem?

Forneça uma análise clara e detalhada focada na funcionalidade do programa."""
        
        return prompt
    
    def _generate_documentation(
        self, 
        programs: List[CobolProgram], 
        books: List[CobolBook],
        analysis_results: Dict[str, AIResponse],
        output_dir: str
    ) -> List[str]:
        """Gera documentação para todos os programas."""
        
        self.logger.info("Gerando documentação...")
        
        generated_files = []
        
        # Gerar documentação individual para cada programa
        for program in programs:
            ai_response = analysis_results.get(program.name)
            
            doc_content = self.doc_generator.generate_program_documentation(program, ai_response)
            
            # Salvar arquivo
            filename = f"{program.name}.md"
            filepath = os.path.join(output_dir, filename)
            
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(doc_content)
            
            generated_files.append(filename)
            self.logger.info(f"Documentação gerada: {filename}")
        
        # Gerar relatório consolidado
        summary_content = self.doc_generator.generate_summary_report(programs, books, analysis_results)
        
        summary_filename = "relatorio_completo.md"
        summary_filepath = os.path.join(output_dir, summary_filename)
        
        with open(summary_filepath, 'w', encoding='utf-8') as f:
            f.write(summary_content)
        
        generated_files.append(summary_filename)
        self.logger.info(f"Relatório consolidado gerado: {summary_filename}")
        
        return generated_files
    
    def _log_results(self, results: Dict[str, Any]) -> None:
        """Registra resultados do processamento."""
        
        self.logger.info("=== Resultados do Processamento ===")
        self.logger.info(f"Programas processados: {results['programs_processed']}")
        self.logger.info(f"Books processados: {results['books_processed']}")
        self.logger.info(f"Arquivos gerados: {results['files_generated']}")
        self.logger.info(f"Tempo de processamento: {results['processing_time_seconds']:.2f}s")
        self.logger.info(f"Diretório de saída: {results['output_directory']}")
        
        # Estatísticas de análise
        if results['analysis_results']:
            successful = sum(1 for r in results['analysis_results'].values() if r.success)
            total = len(results['analysis_results'])
            success_rate = (successful / total * 100) if total > 0 else 0
            
            self.logger.info(f"Análises de IA: {successful}/{total} ({success_rate:.1f}%)")
        
        self.logger.info("\n=== Arquivos Gerados ===")
        for filename in results['generated_files']:
            filepath = os.path.join(results['output_directory'], filename)
            if os.path.exists(filepath):
                size = os.path.getsize(filepath)
                self.logger.info(f"{filename} ({size} bytes)")
        
        self.logger.info("\nProcessamento concluído com sucesso!")
    
    def get_version(self) -> str:
        """Retorna a versão do sistema."""
        try:
            with open("VERSION", 'r') as f:
                return f.read().strip()
        except:
            return "2.0.0"
    
    def get_provider_status(self) -> Dict[str, Any]:
        """Retorna status dos provedores."""
        return self.provider_manager.get_provider_status()

