# COBOL to Docs v1.1 - Análise Consolidada

## Visão Geral

A **Análise Consolidada** é uma funcionalidade avançada do COBOL to Docs v1.1 que processa todos os programas COBOL de um sistema simultaneamente, gerando uma **visão sistêmica integrada e abrangente** ideal para especialistas COBOL.

Diferentemente da análise individual de programas, a análise consolidada considera o sistema como um todo, identificando relacionamentos, dependências, fluxos de dados e processos de negócio integrados.

## Características Principais

### Análise Sistêmica Integrada
- Processa todos os programas COBOL simultaneamente
- Identifica relacionamentos entre programas
- Mapeia fluxos de dados e dependências
- Analisa o sistema como uma unidade coesa

### Visão Especializada para COBOL
- Prompt especializado para análise técnica profunda
- Foco em aspectos arquiteturais e de negócio
- Considerações específicas para sistemas bancários mainframe
- Análise de qualidade e conformidade com padrões COBOL

### Documentação Abrangente
- Relatório único consolidado
- Metadados estruturados do sistema
- Relatório de custos detalhado
- Arquivos de auditoria (requests/responses)

## Como Usar

### Comando Básico
```bash
python main_consolidado.py --fontes examples/fontes.txt
```

### Comando Completo
```bash
python main_consolidado.py \
  --fontes examples/fontes.txt \
  --books examples/books.txt \
  --output analise_sistema \
  --model aws-claude-3-5-sonnet \
  --log-level INFO
```

### Parâmetros Disponíveis

| Parâmetro | Obrigatório | Descrição | Exemplo |
|-----------|-------------|-----------|---------|
| `--fontes` | Sim | Arquivo com programas COBOL | `examples/fontes.txt` |
| `--books` | Não | Arquivo com copybooks COBOL | `examples/books.txt` |
| `--output` | Não | Diretório de saída | `analise_consolidada` |
| `--model` | Não | Modelo de IA a utilizar | `aws-claude-3-5-sonnet` |
| `--log-level` | Não | Nível de log | `INFO` |

## Estrutura de Saída

A análise consolidada gera os seguintes arquivos:

```
analise_consolidada/
├── ANALISE_CONSOLIDADA_SISTEMA_BANCARIO.md  # Relatório principal
├── metadados_sistema.json                   # Metadados estruturados
├── relatorio_custos.txt                     # Relatório de custos
├── ai_requests/                             # Requests enviados
└── ai_responses/                            # Responses recebidas
```

### Arquivo Principal: ANALISE_CONSOLIDADA_SISTEMA_BANCARIO.md

O relatório principal contém:

1. **Cabeçalho com Metadados**
   - Data e hora da análise
   - Modelo e provider utilizados
   - Estatísticas de tokens e custos
   - Tempo de processamento

2. **Análise Técnica Completa**
   - Visão arquitetural do sistema
   - Análise técnica detalhada
   - Análise de negócio
   - Estrutura de dados
   - Avaliação de qualidade
   - Recomendações estratégicas
   - Documentação técnica

### Metadados Estruturados: metadados_sistema.json

Contém informações estruturadas sobre:
- Contexto do sistema analisado
- Programas e copybooks processados
- Relacionamentos identificados
- Processos de negócio mapeados
- Estatísticas de processamento

### Relatório de Custos: relatorio_custos.txt

Detalha:
- Custo total da análise
- Tokens utilizados
- Modelo e provider
- Tempo de processamento
- Métricas de eficiência

## Diferenças da Análise Individual

| Aspecto | Análise Individual | Análise Consolidada |
|---------|-------------------|-------------------|
| **Escopo** | Um programa por vez | Todo o sistema |
| **Relacionamentos** | Não identifica | Mapeia dependências |
| **Visão de Negócio** | Programa específico | Processos integrados |
| **Arquitetura** | Componente isolado | Visão sistêmica |
| **Documentação** | Múltiplos arquivos | Relatório único |
| **Especialização** | Análise técnica | Análise estratégica |

## Casos de Uso Ideais

### Para Especialistas COBOL
- Análise arquitetural de sistemas legados
- Avaliação de qualidade de código
- Planejamento de modernização
- Documentação de sistemas complexos

### Para Gestores Técnicos
- Avaliação de riscos técnicos
- Planejamento de manutenção
- Análise de dependências
- Estimativas de refatoração

### Para Equipes de Desenvolvimento
- Compreensão de sistemas existentes
- Identificação de pontos críticos
- Mapeamento de fluxos de dados
- Guia para manutenção

## Vantagens da Análise Consolidada

### Eficiência
- **Processamento único**: Todos os programas analisados em uma execução
- **Contexto completo**: Análise considera todo o sistema
- **Custo otimizado**: Menor uso de tokens comparado a análises individuais

### Qualidade
- **Visão holística**: Compreensão completa do sistema
- **Relacionamentos**: Identifica dependências e integrações
- **Especialização**: Prompt otimizado para análise sistêmica

### Praticidade
- **Relatório único**: Toda informação em um documento
- **Formato padronizado**: Estrutura consistente e profissional
- **Metadados estruturados**: Informações processáveis programaticamente

## Requisitos Técnicos

### Sistema
- Python 3.11+
- Acesso aos providers de IA configurados
- Espaço em disco para arquivos de saída

### Arquivos de Entrada
- **fontes.txt**: Arquivo com programas COBOL (obrigatório)
- **books.txt**: Arquivo com copybooks COBOL (opcional)

### Configuração
- Providers de IA configurados (LuzIA, enhanced_mock, etc.)
- Variáveis de ambiente para credenciais
- Configuração adequada em config.yaml

## Exemplo de Execução

```bash
# Navegue para o diretório do projeto
cd cobol_to_docs_v1.1

# Execute a análise consolidada
python main_consolidado.py \
  --fontes examples/fontes.txt \
  --books examples/books.txt \
  --output sistema_bancario_analise \
  --model aws-claude-3-5-sonnet

# Resultado esperado:
# ✅ ANÁLISE CONSOLIDADA CONCLUÍDA COM SUCESSO!
# - Programas analisados: 5
# - Copybooks analisados: 3
# - Tokens utilizados: 3,991
# - Tempo de processamento: 0.53 segundos
# - Custo estimado: $0.0000
```

## Troubleshooting

### Problemas Comuns

**Erro: Arquivo de fontes não encontrado**
```
Solução: Verificar se o arquivo existe e o caminho está correto
```

**Erro: Provider não disponível**
```
Solução: Verificar configuração de credenciais e conectividade
```

**Erro: Memória insuficiente**
```
Solução: Processar sistemas menores ou aumentar recursos disponíveis
```

### Logs e Debugging

Use `--log-level DEBUG` para informações detalhadas:
```bash
python main_consolidado.py --fontes examples/fontes.txt --log-level DEBUG
```

Os logs são salvos em arquivo com timestamp:
```
cobol_analysis_YYYYMMDD_HHMMSS.log
```

## Integração com Workflow Existente

A análise consolidada complementa o workflow tradicional:

1. **Análise Individual**: Para desenvolvimento e manutenção específica
2. **Análise Consolidada**: Para visão sistêmica e planejamento estratégico
3. **Relatórios HTML/PDF**: Para apresentações e documentação formal

## Próximos Passos

Após executar a análise consolidada:

1. **Revisar o relatório principal** para compreensão geral
2. **Analisar metadados** para informações estruturadas
3. **Verificar custos** para controle orçamentário
4. **Planejar ações** baseadas nas recomendações
5. **Documentar decisões** para rastreabilidade

## Conclusão

A **Análise Consolidada** representa um avanço significativo na capacidade de análise de sistemas COBOL, oferecendo uma visão sistêmica que vai além da análise individual de programas. É a ferramenta ideal para especialistas COBOL que precisam compreender, avaliar e planejar ações em sistemas complexos e integrados.

---

**Versão:** 1.1  
**Data:** 25/09/2025  
**Status:** Funcional e Testado
