"""
COBOL to Docs v1.1 - Setup para PyPI
Configuração para instalação via pip install cobol-to-docs
"""

from setuptools import setup, find_packages
import os

# Ler README para descrição longa
def read_readme():
    try:
        with open('README.md', 'r', encoding='utf-8') as f:
            return f.read()
    except FileNotFoundError:
        return "Ferramenta de análise e documentação automatizada de programas COBOL"

# Ler versão
def read_version():
    try:
        with open('VERSION', 'r', encoding='utf-8') as f:
            return f.read().strip()
    except FileNotFoundError:
        return "1.1.0"

# Ler requirements
def read_requirements():
    try:
        with open('requirements.txt', 'r', encoding='utf-8') as f:
            return [line.strip() for line in f if line.strip() and not line.startswith('#')]
    except FileNotFoundError:
        return [
            'requests>=2.25.0',
            'pyyaml>=5.4.0',
            'jinja2>=3.0.0',
            'weasyprint>=54.0',
            'markdown>=3.3.0',
            'jupyter>=1.0.0'
        ]

setup(
    name="cobol-to-docs",
    version=read_version(),
    author="Carlos Morais",
    author_email="carlos@example.com",
    description="Ferramenta de análise e documentação automatizada de programas COBOL",
    long_description=read_readme(),
    long_description_content_type="text/markdown",
    url="https://github.com/carlosmorais/cobol-to-docs",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    include_package_data=True,
    package_data={
        "": [
            "config/*.yaml",
            "templates/*.html",
            "examples/*.*"
        ]
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Documentation",
        "Topic :: Software Development :: Code Generators",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
    install_requires=read_requirements(),
    extras_require={
        "dev": [
            "pytest>=6.0",
            "black>=21.0",
            "flake8>=3.8",
            "mypy>=0.800"
        ],
        "jupyter": [
            "jupyter>=1.0.0",
            "ipykernel>=6.0.0",
            "notebook>=6.4.0"
        ]
    },
    entry_points={
        "console_scripts": [
            "cobol-to-docs=main:main",
            "cobol-generate-prompts=generate_prompts:main",
            "cobol-init=tools.init_project:main",
        ],
    },
    keywords="cobol analysis documentation legacy mainframe",
    project_urls={
        "Bug Reports": "https://github.com/carlosmorais/cobol-to-docs/issues",
        "Source": "https://github.com/carlosmorais/cobol-to-docs",
        "Documentation": "https://github.com/carlosmorais/cobol-to-docs/wiki",
    },
)
