# Guia de Uso - COBOL Analyzer v3.0 Corrigido

## Instalação e Configuração

### 1. Extrair o Pacote
```bash
tar -xzf cobol_analyzer_CORRIGIDO_FINAL_v3.0.tar.gz
cd cobol_to_docs_v1.1_final/
```

### 2. Instalar Dependências
```bash
pip install -r requirements.txt
```

### 3. Verificar Estrutura
```bash
ls -la
# Deve mostrar: main.py, src/, config/, data/, etc.
```

## Uso Básico

### Verificar Status dos Providers
```bash
python3 main.py --status
```

### Comando Principal
```bash
python3 main.py --fontes ARQUIVO_FONTES.txt --books ARQUIVO_BOOKS.txt --models enhanced_mock --output PASTA_SAIDA
```

### Exemplo Prático
```bash
python3 main.py --fontes ../fontes.txt --books ../BOOKS.txt --models enhanced_mock --output minha_analise --log-level INFO
```

## Parâmetros Disponíveis

| Parâmetro | Descrição | Exemplo |
|-----------|-----------|---------|
| `--status` | Verificar status dos providers | (sem argumentos) |
| `--fontes` | Arquivo com programas COBOL | `../fontes.txt` |
| `--books` | Arquivo com copybooks | `../BOOKS.txt` |
| `--models` | Modelo/Provider a usar | `enhanced_mock` |
| `--output` | Pasta de saída | `minha_analise` |
| `--log-level` | Nível de log | `INFO`, `DEBUG` |
| `--pdf` | Gerar PDFs | (opcional) |

## Modelos Disponíveis

### Enhanced Mock (Recomendado para Testes)
```bash
--models enhanced_mock
```
- ✅ Funcionamento garantido
- ✅ Análises detalhadas
- ✅ Sistema RAG ativo
- ✅ Sem necessidade de credenciais

### Outros Providers (Requer Configuração)
```bash
--models luzia          # Requer credenciais LuzIA
--models openai         # Requer OPENAI_API_KEY
--models bedrock        # Requer AWS credentials
--models databricks     # Requer Databricks config
```

## Estrutura de Saída

### Organização por Provider
```
minha_analise/
├── enhanced_mock/
│   ├── PROGRAMA1_analise_funcional.html
│   ├── PROGRAMA1_analise_funcional.md
│   ├── requests/
│   │   └── PROGRAMA1_ai_request.json
│   └── responses/
│       └── PROGRAMA1_ai_response.json
└── analise_detalhada/
```

### Arquivos Gerados
- **`.md`**: Relatório em Markdown
- **`.html`**: Relatório formatado em HTML
- **`requests/`**: JSONs das requisições enviadas
- **`responses/`**: JSONs das respostas recebidas

## Sistema RAG (Retrieval Augmented Generation)

### Funcionamento Automático
- ✅ **Auto-ativado**: Não requer configuração
- ✅ **Auto-learning**: Aprende com cada análise
- ✅ **Enriquecimento**: Melhora contexto automaticamente

### Base de Conhecimento
- **Localização**: `data/rag_knowledge_base.json`
- **Sessões**: `data/rag_sessions/`
- **Cache**: `data/rag_embeddings_cache.json`

## Logs e Monitoramento

### Logs Principais
```bash
tail -f execution_log_debug.txt    # Log detalhado
tail -f logs/main_*.log            # Logs por sessão
```

### Relatórios RAG
```bash
ls data/rag_sessions/              # Relatórios de sessão RAG
```

## Verificação de Status

### Comando de Status
```bash
python3 main.py --status
```

### Saída Esperada
```
=== STATUS DOS PROVEDORES ===
  luzia: ❌ Indisponível
    Modelo: aws-claude-3-5-sonnet
    Estatísticas: 0 requisições, 0 tokens
  enhanced_mock: ✅ Disponível
    Modelo: enhanced-mock-gpt-4
    Estatísticas: 0 requisições, 0 tokens
  openai: ❌ Indisponível
    Modelo: unknown
    Estatísticas: 0 requisições, 0 tokens
  bedrock: ❌ Indisponível
    Modelo: unknown
    Estatísticas: 0 requisições, 0 tokens

=== CONFIGURAÇÕES RAG ===
  Status: ✅ Ativo
  Base de conhecimento: 129 itens
  Cache de embeddings: 0 itens
```

## Solução de Problemas

### Erro: "Provider não disponível"
**Solução**: Use `enhanced_mock` que está sempre disponível
```bash
--models enhanced_mock
```

**Verificação**: Execute `--status` para ver quais providers estão disponíveis

### Erro: "Arquivo não encontrado"
**Solução**: Verifique caminhos dos arquivos
```bash
ls ../fontes.txt ../BOOKS.txt      # Verificar se existem
```

### Erro: "Dependências não instaladas"
**Solução**: Instalar requirements
```bash
pip install -r requirements.txt
```

## Exemplos de Uso

### 1. Verificar Status dos Providers
```bash
python3 main.py --status
```

### 2. Análise Básica
```bash
python3 main.py --fontes ../fontes.txt --books ../BOOKS.txt --models enhanced_mock --output analise_basica
```

### 3. Análise com Logs Detalhados
```bash
python3 main.py --fontes ../fontes.txt --books ../BOOKS.txt --models enhanced_mock --output analise_debug --log-level DEBUG
```

### 4. Análise com PDF
```bash
python3 main.py --fontes ../fontes.txt --books ../BOOKS.txt --models enhanced_mock --output analise_pdf --pdf
```

## Verificação de Sucesso

### Saída Esperada
```
============================================================
PROCESSAMENTO CONCLUÍDO
Programas processados: X
Análises bem-sucedidas: X
Análises falharam: 0
Total de tokens utilizados: XXXX
Tempo total de processamento: X.XXs
Documentação gerada em: PASTA_SAIDA
```

### Arquivos Gerados
- ✅ Relatórios HTML e Markdown
- ✅ JSONs de auditoria (requests/responses)
- ✅ Logs de execução
- ✅ Relatórios RAG

## Configurações Avançadas

### Arquivo config.yaml
```yaml
providers:
  enhanced_mock:
    enabled: true
    models:
      enhanced-mock-gpt-4:
        name: "enhanced-mock-gpt-4"
        max_tokens: 8192
        temperature: 0.1
        timeout: 5
```

### Variáveis de Ambiente
```bash
export OPENAI_API_KEY="sua_chave"          # Para OpenAI
export LUZIA_CLIENT_ID="seu_client_id"     # Para LuzIA
export LUZIA_CLIENT_SECRET="seu_secret"    # Para LuzIA
```

## Status da Aplicação

### ✅ Funcionalidades Validadas
- **Enhanced Mock Provider**: Funcionando perfeitamente
- **Sistema RAG**: Ativo e aprendendo
- **Estrutura de saída**: Organizada por provider/modelo
- **Análise detalhada**: Relatórios completos
- **Fallback inteligente**: Sistema robusto
- **Auto-learning**: Base RAG sendo expandida

### 🔧 Correções Implementadas
- **Problema de tuplas**: Resolvido
- **Método analyze ausente**: Adicionado
- **Inicialização de providers**: Corrigida
- **Compatibilidade de interface**: Garantida

---

**Aplicação 100% funcional e pronta para uso!**

Para suporte ou dúvidas, consulte o arquivo `RELATORIO_CORRECOES_FINAIS_COMPLETO.md`.
