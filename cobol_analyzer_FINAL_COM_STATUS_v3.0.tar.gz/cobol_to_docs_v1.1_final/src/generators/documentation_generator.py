"""
COBOL AI Engine v3.0.0 - Documentation Generator
Gerador de documentação funcional para programas COBOL com suporte a múltiplos formatos.
"""

import os
import json
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime
from dataclasses import dataclass

# Importar classes necessárias
try:
    from ..parsers.cobol_parser import CobolProgram
    from ..providers.base_provider import AIResponse
except ImportError:
    from parsers.cobol_parser import CobolProgram
    from providers.base_provider import AIResponse


class DocumentationGenerator:
    """Gerador de documentação focado em relatórios funcionais."""

    def __init__(self, output_dir: str = "output"):
        self.output_dir = output_dir
        self.logger = logging.getLogger(__name__)
        self.files_generated = 0
        self.total_programs = 0
        
        # Criar diretórios necessários
        os.makedirs(output_dir, exist_ok=True)

    def _create_model_directory(self, provider: str) -> str:
        """Cria estrutura completa de diretórios para o modelo/provider."""
        provider_name = provider.lower().replace(' ', '_')
        model_dir = os.path.join(self.output_dir, provider_name)
        
        # Criar diretórios para o modelo (como era antes)
        os.makedirs(model_dir, exist_ok=True)
        os.makedirs(os.path.join(model_dir, "requests"), exist_ok=True)
        os.makedirs(os.path.join(model_dir, "responses"), exist_ok=True)
        
        return model_dir

    def generate_program_documentation(self, program: CobolProgram, ai_response: AIResponse, phase_info: Optional[Dict[str, Any]] = None) -> str:
        """Gera a documentação funcional aprimorada para um programa."""
        try:
            # Criar estrutura completa para o modelo/provider
            model_dir = self._create_model_directory(ai_response.provider)
            
            # Salvar JSONs de auditoria na pasta do modelo
            self._save_ai_response_json(program, ai_response, model_dir)
            self._save_ai_request_json(program, ai_response, model_dir)
            
            # Gerar conteúdo do relatório
            content = self._generate_functional_report(program, ai_response)
            
            # Salvar relatório markdown diretamente na pasta do modelo
            filename_md = f"{program.name}_analise_funcional.md"
            filepath_md = os.path.join(model_dir, filename_md)
            
            # Salvar relatório HTML diretamente na pasta do modelo
            filename_html = f"{program.name}_analise_funcional.html"
            filepath_html = os.path.join(model_dir, filename_html)

            # Salvar relatório markdown
            with open(filepath_md, 'w', encoding='utf-8') as f:
                f.write(content)
            
            # Gerar e salvar relatório HTML
            html_content = self._generate_html_report(program, ai_response, content)
            with open(filepath_html, 'w', encoding='utf-8') as f:
                f.write(html_content)

            self.files_generated += 2  # Markdown + HTML
            self.total_programs += 1
            
            self.logger.info(f"Relatório markdown gerado: {ai_response.provider.lower()}/{filename_md}")
            self.logger.info(f"Relatório HTML gerado: {ai_response.provider.lower()}/{filename_html}")
            return filepath_md
        except Exception as e:
            self.logger.error(f"Erro ao gerar documentação para {program.name}: {e}")
            raise

    def _generate_functional_report(self, program: CobolProgram, ai_response: AIResponse) -> str:
        """Gera o relatório funcional em formato markdown."""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # Extrair informações básicas
        program_info = {
            'name': program.name,
            'size': getattr(program, 'size', 0),
            'line_count': getattr(program, 'line_count', 0),
            'tokens_used': ai_response.tokens_used,
            'model': ai_response.model,
            'provider': ai_response.provider,
            'timestamp': timestamp
        }
        
        # Template do relatório funcional
        content = f"""# Análise Funcional - {program_info['name']}

## Informações do Programa

- **Nome**: {program_info['name']}
- **Tamanho**: {program_info['size']:,} bytes
- **Linhas de código**: {program_info['line_count']:,}
- **Modelo de IA**: {program_info['model']}
- **Provider**: {program_info['provider']}
- **Tokens utilizados**: {program_info['tokens_used']:,}
- **Data da análise**: {program_info['timestamp']}

## O que este programa faz funcionalmente?

{ai_response.content}

---

## Metadados da Análise

- **Sucesso**: {'✅ Sim' if ai_response.success else '❌ Não'}
- **Tempo de resposta**: {getattr(ai_response, 'response_time', 0):.2f}s
- **Qualidade da análise**: {getattr(ai_response, 'quality_score', 'N/A')}

---

*Relatório gerado automaticamente pelo COBOL AI Engine v3.0.0*
"""
        return content

    def _generate_html_report(self, program: CobolProgram, ai_response: AIResponse, markdown_content: str) -> str:
        """Gera o relatório funcional em formato HTML."""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # Converter markdown básico para HTML
        html_content = markdown_content.replace('\n', '<br>\n')
        html_content = html_content.replace('# ', '<h1>').replace('\n<br>', '</h1>\n')
        html_content = html_content.replace('## ', '<h2>').replace('\n<br>', '</h2>\n')
        html_content = html_content.replace('### ', '<h3>').replace('\n<br>', '</h3>\n')
        html_content = html_content.replace('**', '<strong>').replace('**', '</strong>')
        html_content = html_content.replace('- ', '<li>').replace('<li>', '<ul><li>').replace('\n<br>', '</li></ul>\n')
        
        # Template HTML
        html_template = f"""<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Análise Funcional - {program.name}</title>
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f5f5f5;
        }}
        .container {{
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }}
        h1 {{
            color: #2c3e50;
            border-bottom: 3px solid #3498db;
            padding-bottom: 10px;
        }}
        h2 {{
            color: #34495e;
            margin-top: 30px;
            border-left: 4px solid #3498db;
            padding-left: 15px;
        }}
        h3 {{
            color: #7f8c8d;
        }}
        .info-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 15px;
            margin: 20px 0;
        }}
        .info-item {{
            background-color: #ecf0f1;
            padding: 15px;
            border-radius: 5px;
            border-left: 4px solid #3498db;
        }}
        .info-label {{
            font-weight: bold;
            color: #2c3e50;
        }}
        .content-section {{
            background-color: #fafafa;
            padding: 20px;
            border-radius: 5px;
            margin: 20px 0;
            border: 1px solid #ddd;
        }}
        .metadata {{
            background-color: #e8f4f8;
            padding: 15px;
            border-radius: 5px;
            margin-top: 30px;
        }}
        .footer {{
            text-align: center;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
            color: #7f8c8d;
            font-style: italic;
        }}
        ul {{
            padding-left: 20px;
        }}
        li {{
            margin: 5px 0;
        }}
        .success {{
            color: #27ae60;
            font-weight: bold;
        }}
        .error {{
            color: #e74c3c;
            font-weight: bold;
        }}
    </style>
</head>
<body>
    <div class="container">
        <h1>Análise Funcional - {program.name}</h1>
        
        <h2>Informações do Programa</h2>
        <div class="info-grid">
            <div class="info-item">
                <div class="info-label">Nome:</div>
                {program.name}
            </div>
            <div class="info-item">
                <div class="info-label">Tamanho:</div>
                {getattr(program, 'size', 0):,} bytes
            </div>
            <div class="info-item">
                <div class="info-label">Linhas de código:</div>
                {getattr(program, 'line_count', 0):,}
            </div>
            <div class="info-item">
                <div class="info-label">Modelo de IA:</div>
                {ai_response.model}
            </div>
            <div class="info-item">
                <div class="info-label">Provider:</div>
                {ai_response.provider}
            </div>
            <div class="info-item">
                <div class="info-label">Tokens utilizados:</div>
                {ai_response.tokens_used:,}
            </div>
        </div>
        
        <h2>Análise Funcional</h2>
        <div class="content-section">
            {ai_response.content.replace(chr(10), '<br>')}
        </div>
        
        <div class="metadata">
            <h3>Metadados da Análise</h3>
            <ul>
                <li><strong>Sucesso:</strong> <span class="{'success' if ai_response.success else 'error'}">{'✅ Sim' if ai_response.success else '❌ Não'}</span></li>
                <li><strong>Tempo de resposta:</strong> {getattr(ai_response, 'response_time', 0):.2f}s</li>
                <li><strong>Data da análise:</strong> {timestamp}</li>
                <li><strong>Qualidade da análise:</strong> {getattr(ai_response, 'quality_score', 'N/A')}</li>
            </ul>
        </div>
        
        <div class="footer">
            Relatório gerado automaticamente pelo COBOL AI Engine v3.0.0
        </div>
    </div>
</body>
</html>"""
        return html_template

    def _save_ai_response_json(self, program: CobolProgram, response: AIResponse, model_dir: str) -> None:
        """Salva a resposta da IA em formato JSON para auditoria."""
        try:
            
            response_data = {
                "program_name": program.name,
                "timestamp": datetime.now().isoformat(),
                "success": response.success,
                "provider": response.provider,
                "model": response.model,
                "tokens_used": response.tokens_used,
                "response_time": getattr(response, 'response_time', 0.0),
                "content": response.content,
                "error_message": response.error_message,
                "metadata": getattr(response, 'metadata', {}),
                "prompts_used": getattr(response, 'prompts_used', {}),
                "quality_score": getattr(response, 'quality_score', 0),
                "analysis_depth": getattr(response, 'analysis_depth', 'standard'),
                "raw_response": getattr(response, 'raw_response', None)
            }
            
            # Salvar JSON na pasta responses do modelo
            json_filename = f"{program.name}_ai_response.json"
            json_filepath = os.path.join(model_dir, "responses", json_filename)
            
            with open(json_filepath, 'w', encoding='utf-8') as f:
                json.dump(response_data, f, indent=2, ensure_ascii=False, default=str)
            
            self.logger.info(f"JSON da resposta salvo: {response.provider.lower()}/responses/{json_filename}")
            
        except Exception as e:
            self.logger.error(f"Erro ao salvar JSON da resposta para {program.name}: {e}")
    
    def _save_ai_request_json(self, program: CobolProgram, response: AIResponse, model_dir: str) -> None:
        """Salva o request enviado ao provedor em formato JSON para auditoria."""
        try:
            
            # Extrair dados do request dos metadados da resposta
            request_data = {
                "program_name": program.name,
                "timestamp": datetime.now().isoformat(),
                "provider": response.provider,
                "model": response.model,
                "request_payload": {
                    "prompt": getattr(response, 'prompts_used', {}).get('full_prompt', 'Prompt não disponível'),
                    "program_name": program.name,
                    "program_code": program.content,
                    "context": {},
                    "max_tokens": getattr(response, 'max_tokens', 4000),
                    "temperature": getattr(response, 'temperature', 0.1)
                },
                "prompts_sent": getattr(response, 'prompts_used', {}),
                "headers": getattr(response, 'request_headers', {
                    "Content-Type": "application/json",
                    "Provider": response.provider
                }),
                "endpoint": getattr(response, 'endpoint_used', f"api://{response.provider}/analyze"),
                "method": getattr(response, 'http_method', 'POST'),
                "request_size": len(str(getattr(response, 'prompts_used', {}).get('full_prompt', ''))),
                "configuration": {
                    "temperature": getattr(response, 'temperature', 0.1),
                    "max_tokens": getattr(response, 'max_tokens', 4000),
                    "timeout": getattr(response, 'timeout', 120)
                }
            }
            
            # Salvar JSON do request na pasta requests do modelo
            json_filename = f"{program.name}_ai_request.json"
            json_filepath = os.path.join(model_dir, "requests", json_filename)
            
            with open(json_filepath, 'w', encoding='utf-8') as f:
                json.dump(request_data, f, indent=2, ensure_ascii=False, default=str)
            
            self.logger.info(f"JSON do request salvo: {response.provider.lower()}/requests/{json_filename}")
            
        except Exception as e:
            self.logger.error(f"Erro ao salvar JSON do request para {program.name}: {e}")

    def generate_consolidated_report(self, programs: List[CobolProgram], results: List[Dict[str, Any]], output_dir: str) -> str:
        """Gera relatório consolidado de todos os programas analisados."""
        try:
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            
            # Estatísticas gerais
            total_programs = len(programs)
            successful_analyses = sum(1 for r in results if r.get('success', False))
            total_tokens = sum(r.get('tokens_used', 0) for r in results)
            
            # Conteúdo do relatório consolidado
            content = f"""# Relatório Consolidado de Análise COBOL

## Resumo Executivo

- **Data da análise**: {timestamp}
- **Total de programas**: {total_programs}
- **Análises bem-sucedidas**: {successful_analyses}
- **Taxa de sucesso**: {(successful_analyses/total_programs*100):.1f}%
- **Total de tokens utilizados**: {total_tokens:,}

## Programas Analisados

"""
            
            for i, (program, result) in enumerate(zip(programs, results), 1):
                status = "✅ Sucesso" if result.get('success', False) else "❌ Falha"
                tokens = result.get('tokens_used', 0)
                model = result.get('model_used', 'N/A')
                
                content += f"""### {i}. {program.name}

- **Status**: {status}
- **Modelo utilizado**: {model}
- **Tokens**: {tokens:,}
- **Tamanho**: {getattr(program, 'size', 0):,} bytes
- **Linhas**: {getattr(program, 'line_count', 0):,}

"""
            
            content += f"""
---

*Relatório gerado automaticamente pelo COBOL AI Engine v3.0.0*
"""
            
            # Salvar relatório consolidado
            consolidated_file = os.path.join(output_dir, "relatorio_consolidado.md")
            with open(consolidated_file, 'w', encoding='utf-8') as f:
                f.write(content)
            
            self.logger.info(f"Relatório consolidado gerado: {consolidated_file}")
            return consolidated_file
            
        except Exception as e:
            self.logger.error(f"Erro ao gerar relatório consolidado: {e}")
            return ""

    def get_generation_stats(self) -> Dict[str, Any]:
        """Retorna estatísticas de geração de documentação."""
        return {
            'files_generated': self.files_generated,
            'programs_processed': self.total_programs,
            'output_directory': self.output_dir
        }
