"""
Enhanced Provider Manager v3.0
Gerenciador de providers de IA com suporte a múltiplos modelos e fallback.
"""

import logging
import time
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass

from .base_provider import AIRequest, AIResponse
from .luzia_provider import LuziaProvider
from .enhanced_mock_provider import EnhancedMockProvider
from .openai_provider import OpenAIProvider
from .bedrock_provider import BedrockProvider
from .databricks_provider import DatabricksProvider


@dataclass
class ProviderConfig:
    """Configuração de um provider."""
    name: str
    enabled: bool = True
    priority: int = 1
    timeout: float = 120.0
    max_retries: int = 2
    settings: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.settings is None:
            self.settings = {}


class EnhancedProviderManager:
    """Gerenciador avançado de providers de IA com fallback inteligente."""
    
    def __init__(self, config: Dict[str, Any] = None):
        """Inicializa o gerenciador de providers."""
        self.logger = logging.getLogger(__name__)
        self.config = config or {}
        
        # Inicializar providers disponíveis
        self.providers = {}
        self.model_configurations = {}
        
        # Configurações padrão
        self.default_settings = {
            'temperature': 0.1,
            'max_tokens': 4000,
            'timeout': 120.0
        }
        
        self._initialize_providers()
        self._setup_model_configurations()
    
    def _initialize_providers(self):
        """Inicializa todos os providers disponíveis."""
        try:
            # Luzia Provider (Principal)
            self.providers['luzia'] = LuziaProvider(self.config)
            self.logger.info("LuziaProvider inicializado")
            
            # Enhanced Mock Provider (Fallback)
            self.providers['enhanced_mock'] = EnhancedMockProvider(self.config)
            self.logger.info("EnhancedMockProvider inicializado")
            
            # OpenAI Provider
            self.providers['openai'] = OpenAIProvider(self.config)
            self.logger.info("OpenAIProvider inicializado")
            
            # Bedrock Provider
            self.providers['bedrock'] = BedrockProvider(self.config)
            self.logger.info("BedrockProvider inicializado")
            
            # Databricks Provider
            self.providers['databricks'] = DatabricksProvider(self.config)
            self.logger.info("DatabricksProvider inicializado")
            
        except Exception as e:
            self.logger.error(f"Erro ao inicializar providers: {e}")
    
    def _setup_model_configurations(self):
        """Configura os modelos disponíveis."""
        self.model_configurations = {
            # Luzia (Principal)
            'luzia': {
                'provider': 'luzia',
                'description': 'Luzia AI - Provider principal corporativo',
                'capabilities': ['analysis', 'generation', 'translation'],
                'settings': {
                    'temperature': 0.1,
                    'max_tokens': 4000,
                    'timeout': 120.0
                }
            },
            
            # Enhanced Mock (Fallback)
            'enhanced_mock': {
                'provider': 'enhanced_mock',
                'description': 'Enhanced Mock Provider - Fallback inteligente',
                'capabilities': ['analysis', 'generation'],
                'settings': {
                    'temperature': 0.1,
                    'max_tokens': 4000,
                    'timeout': 30.0
                }
            },
            
            # OpenAI Models
            'gpt-4': {
                'provider': 'openai',
                'description': 'OpenAI GPT-4 - Modelo avançado',
                'capabilities': ['analysis', 'generation', 'reasoning'],
                'settings': {
                    'model': 'gpt-4',
                    'temperature': 0.1,
                    'max_tokens': 4000
                }
            },
            
            'gpt-3.5-turbo': {
                'provider': 'openai',
                'description': 'OpenAI GPT-3.5 Turbo - Modelo rápido',
                'capabilities': ['analysis', 'generation'],
                'settings': {
                    'model': 'gpt-3.5-turbo',
                    'temperature': 0.1,
                    'max_tokens': 4000
                }
            },
            
            # AWS Bedrock Models
            'aws-claude-3-5-sonnet': {
                'provider': 'bedrock',
                'description': 'AWS Claude 3.5 Sonnet - Análise avançada',
                'capabilities': ['analysis', 'reasoning', 'generation'],
                'settings': {
                    'model': 'anthropic.claude-3-5-sonnet-20240620-v1:0',
                    'temperature': 0.1,
                    'max_tokens': 4000
                }
            },
            
            'aws-claude-3-haiku': {
                'provider': 'bedrock',
                'description': 'AWS Claude 3 Haiku - Modelo rápido',
                'capabilities': ['analysis', 'generation'],
                'settings': {
                    'model': 'anthropic.claude-3-haiku-20240307-v1:0',
                    'temperature': 0.1,
                    'max_tokens': 4000
                }
            },
            
            # Databricks Models
            'databricks-dbrx': {
                'provider': 'databricks',
                'description': 'Databricks DBRX - Modelo corporativo',
                'capabilities': ['analysis', 'generation'],
                'settings': {
                    'model': 'databricks-dbrx-instruct',
                    'temperature': 0.1,
                    'max_tokens': 4000
                }
            },
            
            'databricks-llama2': {
                'provider': 'databricks',
                'description': 'Databricks Llama2 - Modelo open source',
                'capabilities': ['analysis', 'generation'],
                'settings': {
                    'model': 'llama2-70b-chat',
                    'temperature': 0.1,
                    'max_tokens': 4000
                }
            }
        }
    
    def analyze_with_model(self, request: AIRequest, model_name: str = 'luzia') -> Tuple[AIResponse, str]:
        """
        Analisa usando um modelo específico com fallback inteligente.
        
        Args:
            request: Requisição de análise
            model_name: Nome do modelo a ser usado
            
        Returns:
            Tuple[AIResponse, str]: Resposta da análise e nome do modelo usado
        """
        # Validar e corrigir tipo do request
        if isinstance(request, str):
            # Se request é string, criar um AIRequest válido
            self.logger.warning("Request recebido como string, convertendo para AIRequest")
            original_prompt = request  # Salvar a string original
            request = AIRequest(
                prompt=original_prompt,
                program_name="UNKNOWN",
                program_code="",
                context={'converted_from_string': True}
            )
        elif not hasattr(request, 'program_name'):
            # Se não tem program_name, adicionar
            request.program_name = "UNKNOWN"
        elif not request.program_name:
            # Se program_name está vazio, definir padrão
            request.program_name = "UNKNOWN"
        
        # Configurar modelo
        if model_name not in self.model_configurations:
            self.logger.warning(f"Modelo {model_name} não configurado, usando provedor padrão")
            model_name = 'luzia'
        
        model_config = self.model_configurations[model_name]
        provider_name = model_config['provider']
        
        # Tentar provider primário
        self.logger.info(f"Iniciando análise com provider primário: {provider_name}")
        primary_response = self._try_provider(provider_name, request, model_config)
        
        if primary_response.success:
            return primary_response, model_name
        
        # Fallback para enhanced_mock se não for o provider primário
        fallback_providers = ['enhanced_mock'] if provider_name != 'enhanced_mock' else []
        
        for fallback_name in fallback_providers:
            self.logger.info(f"Tentando fallback: {fallback_name}")
            fallback_config = self.model_configurations.get(fallback_name, {})
            fallback_response = self._try_provider(fallback_name, request, fallback_config)
            
            if fallback_response.success:
                self.logger.info(f"Análise bem-sucedida com fallback {fallback_name} - Tokens: {fallback_response.tokens_used}")
                return fallback_response, fallback_name
            else:
                self.logger.warning(f"Falha no fallback {fallback_name}: {fallback_response.error_message}")
        
        # Se todos falharam
        self.logger.error("TODOS OS PROVEDORES FALHARAM - Análise não pôde ser concluída")
        error_response = AIResponse(
            success=False,
            content="",
            tokens_used=0,
            model=model_name,
            provider=provider_name,
            error_message="Todos os provedores falharam"
        )
        return error_response, model_name
    
    def _try_provider(self, provider_name: str, request: AIRequest, model_config: Dict[str, Any]) -> AIResponse:
        """
        Tenta usar um provider específico.
        
        Args:
            provider_name: Nome do provider
            request: Requisição de análise
            model_config: Configuração do modelo
            
        Returns:
            AIResponse: Resposta da análise
        """
        if provider_name not in self.providers:
            return AIResponse(
                success=False,
                content="",
                tokens_used=0,
                model=model_config.get('settings', {}).get('model', provider_name),
                provider=provider_name,
                error_message=f"Provider {provider_name} não disponível"
            )
        
        provider = self.providers[provider_name]
        
        try:
            self.logger.info(f"Tentando provider primário: {provider_name}")
            self.logger.info(f"Executando análise com {provider_name}")
            
            start_time = time.time()
            
            # Criar request enriquecido com configurações do modelo
            enhanced_request = AIRequest(
                prompt=request.prompt,
                program_name=request.program_name,
                program_code=request.program_code,
                context=request.context,
                max_tokens=model_config.get('settings', {}).get('max_tokens', request.max_tokens),
                temperature=model_config.get('settings', {}).get('temperature', request.temperature)
            )
            
            response = provider.analyze(enhanced_request)
            
            elapsed_time = time.time() - start_time
            
            if response.success:
                self.logger.info(f"{provider_name} respondeu em {elapsed_time:.2f}s - {response.tokens_used} tokens")
                return response
            else:
                self.logger.error(f"{provider_name} falhou em {elapsed_time:.2f}s: {response.error_message}")
                return response
                
        except Exception as e:
            elapsed_time = time.time() - start_time if 'start_time' in locals() else 0
            error_msg = str(e)
            self.logger.error(f"Erro no {provider_name}: {error_msg}")
            self.logger.error(f"{provider_name} falhou em {elapsed_time:.2f}s: {error_msg}")
            
            return AIResponse(
                success=False,
                content="",
                tokens_used=0,
                model=model_config.get('settings', {}).get('model', provider_name),
                provider=provider_name,
                error_message=error_msg,
                response_time=elapsed_time
            )
    
    def get_available_models(self) -> List[str]:
        """Retorna lista de modelos disponíveis."""
        available_models = []
        
        for model_name, model_config in self.model_configurations.items():
            provider_name = model_config.get('provider')
            if provider_name in self.providers:
                try:
                    if self.providers[provider_name].is_available():
                        available_models.append(model_name)
                except Exception as e:
                    self.logger.error(f"Erro ao verificar disponibilidade do modelo {model_name}: {e}")
        
        return available_models
    
    def get_model_info(self, model_name: str) -> Dict[str, Any]:
        """Retorna informações detalhadas sobre um modelo."""
        if model_name not in self.model_configurations:
            return {}
        
        model_config = self.model_configurations[model_name]
        provider_name = model_config.get('provider')
        
        info = {
            'name': model_name,
            'provider': provider_name,
            'description': model_config.get('description', ''),
            'capabilities': model_config.get('capabilities', []),
            'settings': model_config.get('settings', {}),
            'available': False
        }
        
        # Verificar disponibilidade
        if provider_name in self.providers:
            try:
                info['available'] = self.providers[provider_name].is_available()
            except Exception:
                info['available'] = False
        
        return info
    
    def get_model_statistics(self, model_name: str) -> Dict[str, Any]:
        """Retorna estatísticas específicas de um modelo."""
        if model_name not in self.model_configurations:
            return {}
        
        model_config = self.model_configurations[model_name]
        provider_name = model_config.get('provider')
        
        if provider_name not in self.providers:
            return {}
        
        try:
            provider = self.providers[provider_name]
            if hasattr(provider, 'get_statistics'):
                return provider.get_statistics()
        except Exception as e:
            self.logger.error(f"Erro ao obter estatísticas do modelo {model_name}: {e}")
        
        return {}
    
    def create_provider_config(self, provider_name: str, **kwargs) -> ProviderConfig:
        """Cria configuração para um provider."""
        return ProviderConfig(
            name=provider_name,
            enabled=kwargs.get('enabled', True),
            priority=kwargs.get('priority', 1),
            timeout=kwargs.get('timeout', 120.0),
            max_retries=kwargs.get('max_retries', 2),
            settings=kwargs.get('settings', {})
        )
    
    def estimate_costs(self, request: AIRequest, model_name: str = 'luzia') -> Dict[str, Any]:
        """
        Estima custos de uma análise.
        
        Args:
            request: Requisição de análise
            model_name: Nome do modelo
            
        Returns:
            Dict com estimativa de custos
        """
        if model_name not in self.model_configurations:
            return {'error': f'Modelo {model_name} não encontrado'}
        
        model_config = self.model_configurations[model_name]
        provider_name = model_config.get('provider')
        
        if provider_name not in self.providers:
            return {'error': f'Provider {provider_name} não disponível'}
        
        try:
            provider = self.providers[provider_name]
            if hasattr(provider, 'estimate_cost'):
                return provider.estimate_cost(request)
            else:
                return {
                    'model': model_name,
                    'provider': provider_name,
                    'estimated_tokens': len(request.prompt.split()) * 1.3,  # Estimativa aproximada
                    'cost_usd': 0.0,
                    'cost_brl': 0.0,
                    'note': 'Estimativa não disponível para este provider'
                }
        except Exception as e:
            return {'error': f'Erro ao estimar custos: {str(e)}'}
    
    def analyze(self, request: AIRequest, model_name: str = 'enhanced_mock') -> AIResponse:
        """
        Método principal de análise - compatibilidade com interface antiga.
        
        Args:
            request: Requisição de análise
            model_name: Nome do modelo a ser usado
            
        Returns:
            AIResponse: Resposta da análise
        """
        try:
            response, used_model = self.analyze_with_model(request, model_name)
            return response
        except Exception as e:
            self.logger.error(f"Erro no método analyze: {str(e)}")
            return AIResponse(
                success=False,
                content="",
                tokens_used=0,
                model=model_name,
                provider="enhanced_provider_manager",
                error_message=f"Erro na análise: {str(e)}"
            )

    def get_provider_status(self) -> Dict[str, Dict[str, Any]]:
        """Retorna status de todos os providers."""
        status = {}
        
        for provider_name, provider in self.providers.items():
            try:
                status[provider_name] = {
                    'available': provider.is_available(),
                    'name': provider.name if hasattr(provider, 'name') else provider_name,
                    'model': provider.model if hasattr(provider, 'model') else 'unknown',
                    'statistics': provider.get_statistics() if hasattr(provider, 'get_statistics') else {}
                }
            except Exception as e:
                status[provider_name] = {
                    'available': False,
                    'error': str(e)
                }
        
        return status
