"""
LuziaProvider CORRIGIDO - Versão Final com URLs e Payload Corretos
Baseado na versão que funcionava anteriormente
"""

import os
import json
import logging
import time
import warnings
import requests
from datetime import datetime
from typing import Dict, Any, Optional, List
from urllib3.exceptions import InsecureRequestWarning

# Suprimir warnings de SSL
warnings.filterwarnings('ignore', message='Unverified HTTPS request')
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

from .base_provider import BaseProvider, AIRequest, AIResponse

class LuziaProvider(BaseProvider):
    """Provider LuzIA corrigido com URLs e payload corretos da versão funcionando"""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.logger = logging.getLogger('LuziaProvider')
        
        # Obter configurações do LuzIA do config.yaml
        luzia_config = config.get('providers', {}).get('luzia', {})
        
        # Configurações da API - URLs do config.yaml ou padrão
        self.client_id = luzia_config.get('client_id') or os.getenv('LUZIA_CLIENT_ID')
        self.client_secret = luzia_config.get('client_secret') or os.getenv('LUZIA_CLIENT_SECRET')
        
        # URLs do config.yaml - usar exatamente as URLs configuradas
        self.auth_url = luzia_config.get('auth_url', "https://login.azure.paas.santanderbr.pre.corp/auth/realms/corp/protocol/openid-connect/token")
        self.base_url = luzia_config.get('api_url', "https://gut-api-aws.santanderbr.pre.corp/genai_services/v1/")
        
        # Sem URLs de fallback - falhar imediatamente se não conectar
        
        # Configurações de timeout do config.yaml
        models_config = luzia_config.get('models', {})
        default_model_config = list(models_config.values())[0] if models_config else {}
        self.timeout = default_model_config.get('timeout', 120.0)
        
        # Verificar credenciais e definir valores padrão se necessário
        if not self.client_id or not self.client_secret:
            self.logger.warning("Credenciais LuzIA não configuradas - usando valores padrão para evitar erros")
            self.client_id = self.client_id or "test_client_id"
            self.client_secret = self.client_secret or "test_client_secret"
        
        # Modelo padrão do config.yaml ou fallback
        if models_config:
            # Pegar o primeiro modelo configurado
            first_model_key = list(models_config.keys())[0]
            self.model = models_config[first_model_key].get('name', 'aws-claude-3-5-sonnet')
        else:
            self.model = "aws-claude-3-5-sonnet"
        
        self.logger.info(f"LuzIA configurado: modelo={self.model}, timeout={self.timeout}s")
        self.logger.info(f"URLs: auth={self.auth_url[:50]}..., api={self.base_url[:50]}...")
        
        # Token management
        self._token = None
        self._token_expires_at = None
        
        # Armazenar configuração completa para uso posterior
        self.luzia_config = luzia_config
        
        self.logger.info("LuziaProvider CORRIGIDO inicializado com URLs e payload corretos")

    def get_model_config(self, model_name: str = None) -> Dict[str, Any]:
        """
        Obter configurações específicas de um modelo do config.yaml
        
        Args:
            model_name: Nome do modelo (se None, usa o modelo padrão)
            
        Returns:
            Dicionário com configurações do modelo
        """
        if not model_name:
            model_name = self.model
            
        models_config = self.luzia_config.get('models', {})
        
        # Procurar por nome do modelo
        for model_key, model_config in models_config.items():
            if model_config.get('name') == model_name:
                return model_config
                
        # Se não encontrar, retornar configuração padrão
        return {
            'name': model_name,
            'max_tokens': 8192,
            'temperature': 0.1,
            'timeout': 120,
            'context_window': 200000
        }
        
    def get_available_models(self) -> List[str]:
        """
        Obter lista de modelos disponíveis do config.yaml
        
        Returns:
            Lista de nomes de modelos disponíveis
        """
        models_config = self.luzia_config.get('models', {})
        return [model_config.get('name', key) for key, model_config in models_config.items()]

    def get_token(self):
        """Obter token OAuth2 - usar apenas a URL configurada"""
        auth_url = self.auth_url
        
        try:
            # Payload correto para OAuth2
            request_body = {
                "grant_type": "client_credentials",
                "client_id": self.client_id,
                "client_secret": self.client_secret
            }
            
            # Headers corretos
            headers = {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Accept': '*/*'
            }
            
            self.logger.info(f"Obtendo token OAuth2 de {auth_url}")
            
            response = requests.post(
                auth_url,
                headers=headers,
                data=request_body,
                verify=False,
                timeout=self.timeout
            )
            
            if response.status_code == 200:
                token_data = response.json()
                self._token = token_data.get('access_token')
                expires_in = token_data.get('expires_in', 3600)
                self._token_expires_at = time.time() + expires_in - 60
                
                # Log detalhado do token para debug
                if self._token:
                    token_preview = self._token[:20] + "..." if len(self._token) > 20 else self._token
                    self.logger.info(f"Token obtido com sucesso de {auth_url}")
                    self.logger.info(f"Token: {token_preview} (tamanho: {len(self._token)})")
                    # Verificar se há caracteres problemáticos
                    if any(c in self._token for c in ['\n', '\r', '\t', ' ']):
                        self.logger.warning("Token contém caracteres de espaço - limpando...")
                        self._token = self._token.strip()
                else:
                    self.logger.error("Token está vazio na resposta")
                    raise Exception("Token OAuth2 vazio na resposta")
                
                self.logger.info(f"Token OAuth2 obtido com sucesso (expira em {expires_in}s)")
                return self._token
                
            else:
                error_msg = f"Erro HTTP {response.status_code}: {response.text}"
                self.logger.error(f"Erro ao obter token de {auth_url}: {error_msg}")
                raise Exception(f"Falha ao obter token OAuth2: {error_msg}")
                
        except Exception as e:
            self.logger.error(f"Exceção ao obter token de {auth_url}: {e}")
            raise Exception(f"Falha ao obter token OAuth2: {str(e)}")

    def _ensure_valid_token(self):
        """Garantir que temos um token válido"""
        if not self._token or (self._token_expires_at and time.time() >= self._token_expires_at):
            self.logger.info("Token expirado ou inexistente, renovando...")
            self.get_token()

    def analyze(self, request: AIRequest) -> AIResponse:
        """Analisar usando formato correto da versão funcionando"""
        
        start_time = time.time()
        
        try:
            # Garantir token válido
            self._ensure_valid_token()
            
            # Extrair prompt do request
            prompt = request.prompt
            
            # Dividir prompt em system e user baseado na estrutura do COBOL to Docs
            if "=== PROGRAMA COBOL PARA ANÁLISE APROFUNDADA ===" in prompt:
                parts = prompt.split("=== PROGRAMA COBOL PARA ANÁLISE APROFUNDADA ===")
                system_prompt = parts[0].strip()
                user_prompt = parts[1].strip() if len(parts) > 1 else ""
            else:
                # Usar prompts padrão para análise COBOL
                system_prompt = """Você é um analista de sistemas COBOL especializado.
Sua tarefa é realizar uma análise detalhada e técnica do programa COBOL fornecido.
Responda sempre em português brasileiro.
Forneça análises precisas e detalhadas sobre estrutura, lógica de negócio e aspectos técnicos."""
                user_prompt = prompt
            
            # Obter configurações do modelo do config.yaml
            model_config = self.get_model_config(self.model)
            
            # Usar configurações do modelo do config.yaml
            temperature = model_config.get('temperature', request.temperature or 0.1)
            max_tokens = model_config.get('max_tokens', request.max_tokens or 8192)
            
            # Payload no formato correto da versão funcionando
            payload = {
                "input": {
                    "query": [
                        {
                            "role": "system",
                            "content": system_prompt
                        },
                        {
                            "role": "user", 
                            "content": user_prompt
                        }
                    ]
                },
                "config": [
                    {
                        "type": "catena.llm.LLMRouter",
                        "obj_kwargs": {
                            "routing_model": self.model,
                            "temperature": temperature,
                            "max_tokens": max_tokens,
                            "system_prompt": "Responda sempre em português brasileiro com análises técnicas detalhadas"
                        }
                    }
                ]
            }
            
            # Headers no formato correto - CORREÇÃO: usar Bearer no Authorization
            # Verificar se o token é válido antes de usar
            if not self._token:
                self.logger.error("Token não disponível - não é possível fazer requisição")
                return AIResponse(
                    success=False,
                    content="",
                    tokens_used=0,
                    model=self.model,
                    provider=self.__class__.__name__,
                    error_message="Token de autenticação não disponível",
                    response_time=0.0
                )
            
            # Construir header Authorization com validação e limpeza
            clean_token = self._token.strip().replace('\n', '').replace('\r', '').replace('\t', '') if self._token else ""
            auth_header = f"Bearer {clean_token}"
            
            # Log detalhado para debug
            self.logger.info(f"Construindo header Authorization: Bearer [token de {len(clean_token)} chars]")
            
            # Validar se o token não está vazio
            if not clean_token:
                self.logger.error("Token vazio após limpeza!")
                return AIResponse(
                    success=False,
                    content="",
                    tokens_used=0,
                    model=self.model,
                    provider=self.__class__.__name__,
                    error_message="Token de autenticação vazio",
                    response_time=0.0
                )
            
            # Headers limpos e validados
            headers = {
                "X-santander-client-id": str(self.client_id).strip(),
                "Authorization": auth_header,
                "Content-Type": "application/json",
                "Accept": "application/json"
            }
            
            # Log detalhado
            self.logger.info("Enviando para LuzIA (formato correto)")
            self.logger.info(f"URL: {self.base_url}")
            self.logger.info(f"Modelo: {self.model}")
            self.logger.info(f"System prompt: {len(system_prompt)} chars")
            self.logger.info(f"User prompt: {len(user_prompt)} chars")
            
            # Endpoint correto para LuzIA
            api_endpoint = f"{self.base_url}pipelines/submit"
            
            # Fazer requisição usando json= para enviar JSON corretamente
            response = requests.post(
                url=api_endpoint,
                json=payload,
                headers=headers,
                verify=False,
                timeout=self.timeout
            )
            
            response_time = time.time() - start_time
            self.logger.info(f"Status HTTP: {response.status_code} (tempo: {response_time:.2f}s)")
            
            # Tratar HTTP 200 e 201 como sucesso
            if response.status_code in [200, 201]:
                response_data = response.json()
                self.logger.info(f"SUCESSO com LuzIA - Status {response.status_code}")
                
                # Extrair conteúdo da resposta baseado na estrutura real da API
                content = ""
                tokens_used = 0
                
                if isinstance(response_data, dict):
                    # Baseado na estrutura real: o conteúdo está em "output"."content"
                    if 'output' in response_data:
                        output = response_data['output']
                        if isinstance(output, dict) and 'content' in output:
                            content = output['content']
                        elif isinstance(output, str):
                            content = output
                        else:
                            content = str(output)
                    # Fallback para outras estruturas possíveis
                    elif 'result' in response_data:
                        content = response_data['result']
                    elif 'content' in response_data:
                        content = response_data['content']
                    elif 'response' in response_data:
                        content = response_data['response']
                    else:
                        # Se não encontrar estrutura conhecida, usar a resposta completa
                        content = str(response_data)
                    
                    # Tentar extrair informações de tokens se disponível
                    if 'usage' in response_data:
                        usage = response_data['usage']
                        tokens_used = usage.get('total_tokens', len(content.split()) if content else 0)
                    else:
                        tokens_used = len(content.split()) if content else 0
                
                self.logger.info(f"Conteúdo extraído: {len(content)} caracteres")
                
                return AIResponse(
                    success=True,
                    content=content,
                    tokens_used=tokens_used,
                    model=self.model,
                    provider=self.__class__.__name__,
                    response_time=response_time,
                    raw_response=response_data,
                    prompts_used={
                        "system_prompt": system_prompt,
                        "user_prompt": user_prompt,
                        "full_prompt": f"{system_prompt}\n\n{user_prompt}"
                    },
                    request_payload=payload,
                    request_headers={k: v if k != 'Authorization' else f"Bearer [token de {len(v)-7} chars]" for k, v in headers.items()},
                    endpoint_used=api_endpoint,
                    http_method="POST",
                    temperature=payload.get('temperature', 0.1),
                    max_tokens=payload.get('max_tokens', 4000),
                    timeout=self.timeout
                )
            else:
                # Log detalhado de erro
                self.logger.error(f"Erro HTTP {response.status_code}")
                self.logger.error(f"Headers de resposta: {dict(response.headers)}")
                self.logger.error(f"Texto da resposta: {response.text}")
                
                # Log dos headers enviados para debug (sem expor token completo)
                safe_headers = {k: v if k != 'Authorization' else f"Bearer [token de {len(v)-7} chars]" for k, v in headers.items()}
                self.logger.error(f"Headers enviados: {safe_headers}")
                
                # Tratamento específico para HTTP 503 (Service Temporarily Unavailable)
                if response.status_code == 503:
                    self.logger.warning("LuzIA temporariamente indisponível (HTTP 503)")
                    self.logger.warning("Sugestão: Tentar novamente em alguns minutos ou usar provider de fallback")
                    error_msg = "LuzIA temporariamente indisponível (HTTP 503). Tente novamente em alguns minutos."
                
                # Tratamento específico para HTTP 401/403 (Authorization)
                elif response.status_code in [401, 403]:
                    self.logger.error("ERRO DE AUTORIZAÇÃO DETECTADO!")
                    self.logger.error("Verificar credenciais LUZIA_CLIENT_ID e LUZIA_CLIENT_SECRET")
                    self.logger.error(f"Client ID usado: {self.client_id}")
                    self.logger.error(f"Token válido: {'Sim' if self._token else 'Não'}")
                    error_msg = f"Erro de autorização (HTTP {response.status_code}). Verificar credenciais."
                
                else:
                    try:
                        error_json = response.json()
                        self.logger.error(f"JSON da resposta: {json.dumps(error_json, indent=2)}")
                        
                        # Verificar se é erro específico de Authorization
                        if 'message' in error_json and 'Authorization' in str(error_json['message']):
                            self.logger.error("ERRO ESPECÍFICO DE AUTHORIZATION DETECTADO!")
                            self.logger.error(f"Token usado: {self._token[:50]}..." if self._token else "Token é None")
                            
                    except:
                        self.logger.error("Resposta não é JSON válido")
                    
                    error_msg = f"Erro HTTP {response.status_code}: {response.text}"
                
                return AIResponse(
                    success=False,
                    content="",
                    tokens_used=0,
                    model=self.model,
                    provider=self.__class__.__name__,
                    error_message=error_msg,
                    response_time=response_time
                )
                
        except requests.exceptions.Timeout:
            response_time = time.time() - start_time
            self.logger.error("Timeout na requisição")
            return AIResponse(
                success=False,
                content="",
                model=self.model,
                tokens_used=0,
                response_time=response_time,
                error_message="Timeout na requisição para LuzIA"
            )
        except Exception as e:
            response_time = time.time() - start_time
            self.logger.error(f"Exceção na requisição: {e}")
            return AIResponse(
                success=False,
                content="",
                model=self.model,
                tokens_used=0,
                response_time=response_time,
                error_message=str(e)
            )

    def is_available(self) -> bool:
        """Verificar se o provider está disponível"""
        try:
            self._ensure_valid_token()
            return True
        except Exception as e:
            self.logger.error(f"Provider não disponível: {e}")
            return False

    def get_models(self) -> List[str]:
        """Retornar modelos disponíveis"""
        return ["aws-claude-3-5-sonnet"]

    def get_status(self) -> Dict[str, Any]:
        """Retornar status do provider"""
        try:
            available = self.is_available()
            return {
                "available": available,
                "models": self.get_models(),
                "auth_url": self.auth_url,
                "api_url": self.base_url,
                "has_credentials": bool(self.client_id and self.client_secret),
                "token_valid": bool(self._token and self._token_expires_at and time.time() < self._token_expires_at),
                "format": "corrigido_urls_payload",
                "model": self.model
            }
        except Exception as e:
            return {
                "available": False,
                "error": str(e),
                "models": [],
                "has_credentials": bool(self.client_id and self.client_secret),
                "format": "corrigido_urls_payload",
                "model": self.model
            }
