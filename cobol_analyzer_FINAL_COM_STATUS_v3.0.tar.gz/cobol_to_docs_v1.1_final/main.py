#!/usr/bin/env python3
"""
COBOL Analyzer - Sistema Profissional de Análise e Documentação COBOL
Autor: Carlos Morais
Data: Outubro 2025

Sistema completo para análise automatizada de programas COBOL com geração
de documentação técnica profissional usando IA.

FUNCIONALIDADES:
- Análise detalhada padrão com máximo detalhamento técnico
- Processamento de múltiplos programas COBOL
- Suporte a múltiplos modelos de IA
- Análise de copybooks complementares
- Sistema RAG com auto-learning
- Geração de relatórios profissionais
"""

import argparse
import logging
import os
import sys
import json
import time
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.core.config import ConfigManager
from src.core.prompt_manager_dual import DualPromptManager
from src.providers.enhanced_provider_manager import EnhancedProviderManager
from src.parsers.cobol_parser_original import COBOLParser, CobolProgram, CobolBook
from src.analyzers.enhanced_cobol_analyzer import EnhancedCOBOLAnalyzer
from src.generators.documentation_generator import DocumentationGenerator
from src.utils.html_generator import HTMLReportGenerator
from src.utils.cost_calculator import CostCalculator
from src.rag.rag_integration_enhanced import EnhancedRAGIntegration
from src.core.intelligent_model_selector import IntelligentModelSelector

# Importações para análise detalhada (com fallback)
try:
    from src.analyzers.expert_level_analyzer import ExpertLevelAnalyzer
    from src.prompts.expert_level_prompts import ExpertLevelPrompts
    EXPERT_ANALYSIS_AVAILABLE = True
except ImportError:
    EXPERT_ANALYSIS_AVAILABLE = False

try:
    from src.analyzers.ultra_detailed_analyzer import UltraDetailedAnalyzer
    from src.prompts.ultra_detailed_cobol_prompts import UltraDetailedCOBOLPrompts
    DETAILED_ANALYSIS_AVAILABLE = True
except ImportError:
    DETAILED_ANALYSIS_AVAILABLE = False

def setup_logging(log_level: str = "INFO") -> None:
    """Configura o sistema de logging."""
    log_dir = "logs"
    os.makedirs(log_dir, exist_ok=True)
    
    log_file = os.path.join(log_dir, f"cobol_analyzer_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
    
    logging.basicConfig(
        level=getattr(logging, log_level.upper()),
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file, encoding='utf-8'),
            logging.StreamHandler(sys.stdout)
        ]
    )

def parse_models_argument(models_str: str) -> List[str]:
    """Parse do argumento models que pode ser string ou lista JSON."""
    if not models_str:
        return []
    
    models_str = models_str.strip()
    
    # Se começa com [ é uma lista JSON
    if models_str.startswith('['):
        try:
            models = json.loads(models_str)
            return models if isinstance(models, list) else [models]
        except json.JSONDecodeError:
            print(f"Erro: Formato JSON inválido para models: {models_str}")
            sys.exit(1)
    else:
        # String simples
        return [models_str]

def execute_detailed_analysis(programs: List[CobolProgram], 
                             books: List[CobolBook], 
                             model: str, 
                             args, 
                             config_manager: ConfigManager, 
                             rag_integration) -> Dict[str, Any]:
    """
    Executa análise detalhada dos programas COBOL (padrão da aplicação)
    """
    logger = logging.getLogger(__name__)
    
    if not DETAILED_ANALYSIS_AVAILABLE:
        logger.info("Análise detalhada não disponível, usando análise padrão")
        return {'success': False, 'reason': 'detailed_analysis_not_available'}
    
    try:
        logger.info("=== EXECUTANDO ANÁLISE DETALHADA ===")
        
        # Criar configuração de providers
        provider_config = config_manager.get_config()
        
        # Inicializar analisador detalhado
        detailed_analyzer = UltraDetailedAnalyzer(provider_config)
        
        # Preparar copybooks
        copybooks_dict = {}
        for book in books:
            copybooks_dict[book.name] = book.content
        
        # Executar análise para cada programa
        all_results = []
        total_cost_brl = 0.0
        total_analyses = 0
        
        for program in programs:
            logger.info(f"Analisando {program.name} com análise detalhada")
            
            result = detailed_analyzer.analyze_program_ultra_detailed(
                program, model, copybooks_dict
            )
            
            all_results.append(result)
            
            # Contar análises bem-sucedidas
            analysis_types = ['functional_analysis', 'business_rules_analysis', 
                            'file_processing_analysis', 'validation_analysis', 
                            'cadoc_analysis', 'error_handling_analysis']
            
            for analysis_type in analysis_types:
                if result.get(analysis_type, {}).get('success'):
                    total_analyses += 1
                    total_cost_brl += result[analysis_type].get('cost_brl', 0.0)
                    
                    # Adicionar conhecimento ao RAG
                    if rag_integration and hasattr(rag_integration, 'add_analysis_to_knowledge_base'):
                        try:
                            analysis_content = result[analysis_type].get('analysis_content', '')
                            rag_integration.add_analysis_to_knowledge_base(
                                f"{program.name}_{analysis_type}",
                                analysis_content,
                                program.content,
                                analysis_type
                            )
                        except Exception as e:
                            logger.warning(f"Falha ao adicionar {analysis_type} ao RAG: {e}")
        
        # Gerar relatórios detalhados
        detailed_output_dir = os.path.join(args.output, "analise_detalhada")
        os.makedirs(detailed_output_dir, exist_ok=True)
        
        # Salvar resultados em JSON
        detailed_json_file = os.path.join(detailed_output_dir, "analise_detalhada_completa.json")
        with open(detailed_json_file, 'w', encoding='utf-8') as f:
            json.dump(all_results, f, ensure_ascii=False, indent=2, default=str)
        
        # Gerar relatórios individuais
        for result in all_results:
            program_name = result['program_name']
            
            # Relatório funcional detalhado
            if result.get('functional_analysis', {}).get('success'):
                func_file = os.path.join(detailed_output_dir, f"{program_name}_funcional_detalhado.md")
                with open(func_file, 'w', encoding='utf-8') as f:
                    f.write(f"# Análise Funcional Detalhada - {program_name}\n\n")
                    f.write(result['functional_analysis']['analysis_content'])
            
            # Relatório de regras de negócio detalhado
            if result.get('business_rules_analysis', {}).get('success'):
                rules_file = os.path.join(detailed_output_dir, f"{program_name}_regras_negocio.md")
                with open(rules_file, 'w', encoding='utf-8') as f:
                    f.write(f"# Regras de Negócio Detalhadas - {program_name}\n\n")
                    f.write(result['business_rules_analysis']['analysis_content'])
            
            # Relatório de validações detalhado
            if result.get('validation_analysis', {}).get('success'):
                val_file = os.path.join(detailed_output_dir, f"{program_name}_validacoes.md")
                with open(val_file, 'w', encoding='utf-8') as f:
                    f.write(f"# Validações Detalhadas - {program_name}\n\n")
                    f.write(result['validation_analysis']['analysis_content'])
        
        # Gerar relatório consolidado
        consolidated_file = os.path.join(detailed_output_dir, "relatorio_consolidado.md")
        with open(consolidated_file, 'w', encoding='utf-8') as f:
            f.write("# Relatório Consolidado - Análise COBOL Detalhada\n\n")
            f.write(f"**Data da Análise**: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}\n\n")
            
            f.write("## Resumo Executivo\n\n")
            f.write(f"- **Programas Analisados**: {len(programs)}\n")
            f.write(f"- **Análises Específicas Realizadas**: {total_analyses}\n")
            f.write(f"- **Custo Total**: R$ {total_cost_brl:.4f}\n")
            f.write(f"- **Tipos de Análise**: 6 por programa\n\n")
            
            f.write("## Tipos de Análise Realizados\n\n")
            f.write("1. **🔧 Análise Funcional Detalhada** - Funcionalidades e sequência de execução\n")
            f.write("2. **📋 Extração Profunda de Regras de Negócio** - Regras com algoritmos específicos\n")
            f.write("3. **📁 Análise Detalhada de Processamento de Arquivos** - Estruturas e operações\n")
            f.write("4. **✅ Análise Específica de Validações** - Tipos de informação e algoritmos\n")
            f.write("5. **📄 Análise Especializada CADOC** - Funcionalidades CADOC específicas\n")
            f.write("6. **⚠️ Análise de Tratamento de Erros** - Códigos e ações de recuperação\n\n")
        
        logger.info(f"✅ Análise detalhada concluída: {total_analyses} análises específicas")
        logger.info(f"💰 Custo da análise detalhada: R$ {total_cost_brl:.4f}")
        
        return {
            'success': True,
            'programs_analyzed': len(programs),
            'total_analyses': total_analyses,
            'total_cost_brl': total_cost_brl,
            'output_directory': detailed_output_dir,
            'reports_generated': {
                'json_data': detailed_json_file,
                'consolidated_report': consolidated_file,
                'individual_reports': total_analyses
            }
        }
        
    except Exception as e:
        logger.error(f"Erro na análise detalhada: {e}")
        return {
            'success': False,
            'error': str(e),
            'programs_analyzed': 0,
            'total_analyses': 0,
            'total_cost_brl': 0.0
        }

def analyze_program_with_model(program: CobolProgram, books: List[CobolBook], model: str, 
                              output_dir: str, config_manager: ConfigManager, 
                              prompt_set: str, rag_integration=None) -> Dict[str, Any]:
    """Analisa um programa COBOL com um modelo específico."""
    logger = logging.getLogger(__name__)
    
    try:
        # Inicializar componentes específicos para o modelo
        prompt_manager = DualPromptManager(config_manager.config, prompt_set)
        provider_manager = EnhancedProviderManager(config_manager.config)
        doc_generator = DocumentationGenerator(output_dir)
        
        # Análise com IA (passando RAG integration)
        # Usar análise de nível especialista se disponível
        if EXPERT_ANALYSIS_AVAILABLE:
            expert_analyzer = ExpertLevelAnalyzer(provider_manager, rag_integration)
            logger.info(f"Usando análise de nível especialista para {program.name}")
        else:
            analyzer = EnhancedCOBOLAnalyzer(provider_manager, prompt_manager, rag_integration)
            logger.info(f"Usando análise padrão para {program.name}")
        
        start_time = time.time()
        
        logger.info(f"Iniciando análise de {program.name} com provider {model}")
        
        # Executar análise baseada no tipo de analisador
        if EXPERT_ANALYSIS_AVAILABLE:
            expert_result = expert_analyzer.analyze_program_expert_level(program, model)
            # Converter resultado para formato compatível
            class CompatibleResult:
                def __init__(self, expert_result):
                    self.success = expert_result.success
                    self.content = expert_result.detailed_analysis
                    self.tokens_used = expert_result.tokens_used
                    self.model_used = expert_result.model_used
                    self.error_message = expert_result.error_message
                    self.provider_used = model
            
            analysis_result = CompatibleResult(expert_result)
        else:
            analysis_result = analyzer.analyze_program(program, model)
        analysis_time = time.time() - start_time
        
        if not analysis_result.success:
            logger.error(f"Falha na análise de {program.name} com modelo {model}: {analysis_result.error_message}")
            return {
                'success': False,
                'program_name': program.name,
                'model': model,
                'error': analysis_result.error_message,
                'tokens_used': 0,
                'analysis_time': analysis_time,
                'output_dir': output_dir
            }
        
        # Gerar documentação
        from src.providers.base_provider import AIResponse
        
        # Obter prompts utilizados do prompt_manager
        prompts_used = {
            'system_prompt': prompt_manager.get_system_prompt(),
            'original_prompt': getattr(analysis_result, 'original_prompt', 'Prompt gerado dinamicamente'),
            'main_prompt': getattr(analysis_result, 'prompt_used', 'Prompt principal não disponível')
        }
        
        ai_response = AIResponse(
            success=True,
            content=analysis_result.content,
            tokens_used=analysis_result.tokens_used,
            model=analysis_result.model_used,
            provider=getattr(analysis_result, 'provider_used', 'enhanced_mock'),
            prompts_used=prompts_used,
            response_time=analysis_time
        )
        
        doc_result = doc_generator.generate_program_documentation(program, ai_response)
        
        logger.info(f"Análise de {program.name} concluída com sucesso")
        logger.info(f"Tokens utilizados: {analysis_result.tokens_used:,}")
        logger.info(f"Modelo utilizado: {analysis_result.model_used}")
        
        # Auto-learning: Adicionar análise bem-sucedida à base de conhecimento
        if rag_integration and hasattr(rag_integration, 'add_program_analysis_to_knowledge_base'):
            try:
                rag_integration.add_program_analysis_to_knowledge_base(
                    program.name, 
                    analysis_result.content, 
                    program.content
                )
                logger.info(f"Conhecimento do programa {program.name} adicionado à base RAG")
            except Exception as e:
                logger.warning(f"Auto-learning falhou para {program.name}: {e}")
        
        return {
            'success': True,
            'program_name': program.name,
            'model': model,
            'tokens_used': analysis_result.tokens_used,
            'analysis_time': analysis_time,
            'output_dir': output_dir,
            'files_generated': [doc_result] if doc_result else [],
            'response': analysis_result
        }
        
    except Exception as e:
        logger.error(f"Erro na análise de {program.name} com modelo {model}: {str(e)}")
        return {
            'success': False,
            'program_name': program.name,
            'model': model,
            'error': str(e),
            'tokens_used': 0,
            'analysis_time': 0,
            'output_dir': output_dir
        }

def get_models_from_providers(config_manager: ConfigManager) -> List[str]:
    """Obtém modelos disponíveis dos providers configurados."""
    try:
        provider_manager = EnhancedProviderManager(config_manager.config)
        available_models = []
        
        # Verificar providers disponíveis
        providers = ['luzia', 'enhanced_mock', 'basic']
        for provider_name in providers:
            try:
                if provider_manager.get_provider_status(provider_name):
                    if provider_name == 'luzia':
                        available_models.append('luzia')
                    elif provider_name == 'enhanced_mock':
                        available_models.append('enhanced_mock')
                    elif provider_name == 'basic':
                        available_models.append('basic')
            except Exception:
                continue
        
        # Se nenhum provider disponível, usar mock
        if not available_models:
            available_models = ['enhanced_mock']
        
        return available_models
    except Exception:
        return ['enhanced_mock']

def process_cobol_files(args, config_manager: ConfigManager, rag_integration) -> None:
    """Processa arquivos COBOL com análise detalhada como padrão."""
    logger = logging.getLogger(__name__)
    
    # Inicializar seletor inteligente de modelos
    model_selector = IntelligentModelSelector()
    
    # Determinar modelos a usar
    if hasattr(args, 'models') and args.models:
        models = parse_models_argument(args.models)
        logger.info(f"Modelos especificados: {models}")
    else:
        # Obter modelos dos providers configurados
        models = get_models_from_providers(config_manager)
        logger.info(f"Modelos disponíveis: {models}")
    
    # Inicializar parser
    parser = COBOLParser()
    
    logger.info("=== INICIANDO ANÁLISE COBOL ===")
    logger.info(f"Modelos selecionados: {models}")
    logger.info(f"Arquivo de fontes: {args.fontes}")
    if args.books:
        logger.info(f"Arquivo de books: {args.books}")
    logger.info(f"Diretório de saída: {args.output}")
    
    start_time = time.time()
    
    try:
        # Parse do arquivo principal
        programs, books = parser.parse_file(args.fontes)
        
        # Parse de copybooks adicionais se especificado
        if args.books and os.path.exists(args.books):
            _, additional_books = parser.parse_file(args.books)
            books.extend(additional_books)
        
        logger.info(f"Programas encontrados: {len(programs)}, Books encontrados: {len(books)}")
        
        if not programs:
            print("Nenhum programa encontrado para análise.")
            return
            
    except Exception as e:
        logger.error(f"Erro ao parsear arquivos: {str(e)}")
        return
    
    # Criar diretório de saída
    os.makedirs(args.output, exist_ok=True)
    
    # ANÁLISE DETALHADA COMO PADRÃO: Executar análise detalhada automaticamente
    if DETAILED_ANALYSIS_AVAILABLE and len(programs) > 0:
        try:
            detailed_results = execute_detailed_analysis(
                programs, books, models[0] if models else 'enhanced_mock', 
                args, config_manager, rag_integration
            )
            
            if detailed_results.get('success'):
                logger.info(f"✅ Análise detalhada concluída: {detailed_results['total_analyses']} análises específicas")
                logger.info(f"💰 Custo da análise detalhada: R$ {detailed_results['total_cost_brl']:.4f}")
            else:
                logger.info("Análise detalhada não executada, continuando com análise padrão")
        except Exception as e:
            logger.warning(f"Análise detalhada falhou, continuando com análise padrão: {e}")
    
    all_results = []
    model = models[0] if models else 'enhanced_mock'
    
    print(f"\nCOBOL Analyzer - Iniciando processamento")
    print(f"Programas COBOL: {len(programs)}")
    if books:
        print(f"Copybooks: {len(books)}")
    print(f"Modelo: {model}")
    print(f"Diretório de saída: {args.output}")
    print("=" * 60)
    
    # Processar cada programa
    for i, program in enumerate(programs, 1):
        print(f"\n[{i}/{len(programs)}] Analisando {program.name}...")
        
        result = analyze_program_with_model(
            program, books, model, args.output, config_manager, 
            args.prompt_set, rag_integration
        )
        
        all_results.append(result)
        
        if result['success']:
            print(f"   ✅ Sucesso - {result['tokens_used']:,} tokens - {result['analysis_time']:.1f}s")
        else:
            print(f"   ❌ Falha: {result['error']}")
    
    # Gerar relatórios HTML se solicitado
    if hasattr(args, 'pdf') and args.pdf:
        print(f"\n📄 Gerando relatórios HTML...")
        generate_html_reports(args.output, programs, all_results)
    
    # Estatísticas finais
    total_time = time.time() - start_time
    successful_analyses = [r for r in all_results if r['success']]
    failed_analyses = [r for r in all_results if not r['success']]
    total_tokens = sum(r.get('tokens_used', 0) for r in successful_analyses)
    
    print(f"\n" + "=" * 60)
    print(f"PROCESSAMENTO CONCLUÍDO")
    print(f"Programas processados: {len(programs)}")
    print(f"Análises bem-sucedidas: {len(successful_analyses)}")
    print(f"Análises falharam: {len(failed_analyses)}")
    print(f"Total de tokens utilizados: {total_tokens:,}")
    print(f"Tempo total de processamento: {total_time:.2f}s")
    print(f"Documentação gerada em: {args.output}")
    
    if failed_analyses:
        print(f"\n⚠️  Análises que falharam:")
        for result in failed_analyses:
            print(f"   - {result['program_name']}: {result['error']}")

def generate_html_reports(output_dir: str, programs: List, all_results: List[Dict]) -> None:
    """Gera relatórios HTML/PDF a partir dos arquivos Markdown."""
    try:
        from src.utils.html_generator import HTMLReportGenerator
        
        html_generator = HTMLReportGenerator()
        html_files_generated = []
        
        # Processar arquivos na raiz
        md_files = [f for f in os.listdir(output_dir) if f.endswith('_analise_funcional.md')]
        
        for md_file in md_files:
            md_path = os.path.join(output_dir, md_file)
            
            # Gerar HTML
            html_file = html_generator.generate_html_report(md_path, output_dir)
            html_files_generated.append(html_file)
            print(f"  HTML gerado: {html_file}")
        
        print(f"  Total de arquivos HTML gerados: {len(html_files_generated)}")
        
    except Exception as e:
        print(f"  Erro ao gerar relatórios HTML: {e}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='COBOL Analyzer - Análise Profissional de Programas COBOL')
    
    # Argumentos principais
    parser.add_argument('--fontes', help='Arquivo contendo os programas COBOL')
    parser.add_argument('--books', help='Arquivo contendo os copybooks')
    parser.add_argument('--output', default='output', help='Diretório de saída')
    parser.add_argument('--models', help='Modelos a usar (string ou JSON)')
    parser.add_argument('--prompt-set', default='enhanced', choices=['basic', 'enhanced'], 
                        help='Conjunto de prompts a usar')
    parser.add_argument('--log-level', default='INFO', choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'],
                        help='Nível de logging')
    parser.add_argument('--pdf', action='store_true', help='Gerar relatórios HTML/PDF')
    parser.add_argument('--status', action='store_true', help='Verificar status dos providers')
    
    args = parser.parse_args()
    
    # Configurar logging
    setup_logging(args.log_level)
    logger = logging.getLogger(__name__)
    
    try:
        # Carregar configuração
        config_manager = ConfigManager()
        
        # Inicializar sistema RAG aprimorado
        rag_integration = EnhancedRAGIntegration(config_manager.config)
        if rag_integration.is_enabled():
            rag_stats = rag_integration.get_rag_statistics()
            logger.info(f"Sistema RAG inicializado: {rag_stats.get('total_items', 0)} itens na base de conhecimento")
        else:
            logger.info("Sistema RAG desabilitado")
        
        # Verificar status se solicitado
        if args.status:
            provider_manager = EnhancedProviderManager(config_manager.config)
            print("=== STATUS DOS PROVEDORES ===")
            
            # Obter status de todos os providers
            all_status = provider_manager.get_provider_status()
            
            for provider_name, status_info in all_status.items():
                if 'error' in status_info:
                    print(f"  {provider_name}: ❌ Erro - {status_info['error']}")
                else:
                    available = status_info.get('available', False)
                    model = status_info.get('model', 'unknown')
                    stats = status_info.get('statistics', {})
                    
                    status_icon = "✅" if available else "❌"
                    print(f"  {provider_name}: {status_icon} {'Disponível' if available else 'Indisponível'}")
                    print(f"    Modelo: {model}")
                    
                    if stats:
                        total_requests = stats.get('total_requests', 0)
                        total_tokens = stats.get('total_tokens', 0)
                        print(f"    Estatísticas: {total_requests} requisições, {total_tokens} tokens")
            
            print("\n=== CONFIGURAÇÕES RAG ===")
            if rag_integration.is_enabled():
                rag_stats = rag_integration.get_rag_statistics()
                print(f"  Status: ✅ Ativo")
                print(f"  Base de conhecimento: {rag_stats.get('total_items', 0)} itens")
                print(f"  Cache de embeddings: {rag_stats.get('cache_size', 0)} itens")
            else:
                print(f"  Status: ❌ Desabilitado")
            
            sys.exit(0)
        
        # Validar argumentos (exceto quando usando --status)
        if not args.fontes and not args.status:
            print("Erro: --fontes é obrigatório")
            parser.print_help()
            sys.exit(1)
        
        if args.fontes and not os.path.exists(args.fontes):
            print(f"Erro: Arquivo não encontrado: {args.fontes}")
            sys.exit(1)
        
        # Processar arquivos COBOL (apenas se não for status)
        if args.fontes:
            process_cobol_files(args, config_manager, rag_integration)
        
        # Finalizar sessão RAG
        if rag_integration.is_enabled():
            try:
                rag_report = rag_integration.finalize_session()
                if rag_report:
                    logger.info(f"Relatório de uso do RAG gerado: {rag_report}")
            except Exception as e:
                logger.warning(f"Erro ao finalizar sessão RAG: {e}")
        
    except KeyboardInterrupt:
        print("\nProcessamento interrompido pelo usuário.")
    except Exception as e:
        logger.error(f"Erro fatal: {str(e)}")
        print(f"Erro: {str(e)}")
