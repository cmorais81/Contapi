# Relatório de Sessão RAG

**Data**: 02/10/2025 19:58:34

## Resumo da Sessão

- **Operações RAG realizadas**: 0
- **Programas analisados**: 0
- **Novos itens adicionados**: 0
- **Tipos de análise processados**: 0

## Programas Analisados


## Tipos de Análise Processados


## Estatísticas da Base de Conhecimento

- **Total de itens**: 119
- **Categorias**: {'Fundamentos CADOC': 1, 'Processamento Documental': 1, 'Indexação': 1, 'Controle de Qualidade': 1, 'Auditoria': 1, 'Retenção': 1, 'Busca': 1, 'Integração': 1, 'Processamento Batch': 1, 'Segurança': 1, 'Workflow': 1, 'Métricas': 1, 'Modernização': 1, 'Disaster Recovery': 1, 'OCR': 1, 'Processamento Bancário': 1, 'Documentos Jurídicos': 1, 'Comprovantes Eletrônicos': 1, 'Documentos de Crédito': 1, 'Compliance Regulatório': 1, 'Captura Inteligente': 1, 'Gestão de Exceções': 1, 'Integração Core Banking': 1, 'Analytics Documental': 1, 'Controle de Versões': 1, 'technical_doc': 94}
- **Domínios**: {'Gestão Documental': 1, 'Inteligência Documental': 1, 'Estruturas de Dados': 1, 'Qualidade': 1, 'Compliance': 1, 'Gestão de Ciclo de Vida': 1, 'Recuperação de Informação': 1, 'Integração Sistêmica': 2, 'Processamento em Lote': 1, 'Segurança da Informação': 1, 'Processos de Negócio': 1, 'Monitoramento': 1, 'Arquitetura': 1, 'Continuidade de Negócio': 1, 'Inteligência Artificial': 1, 'Documentos Bancários': 1, 'Gestão Jurídica': 1, 'Documentação Eletrônica': 1, 'Crédito e Financiamento': 1, 'Regulamentação Bancária': 1, 'Captura Documental': 1, 'Gestão de Qualidade': 1, 'Business Intelligence': 1, 'Gestão de Configuração': 1, 'banking': 62, 'general': 32}
