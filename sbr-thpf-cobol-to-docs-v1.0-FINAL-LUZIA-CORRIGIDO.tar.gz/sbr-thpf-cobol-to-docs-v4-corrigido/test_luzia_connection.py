#!/usr/bin/env python3
"""
Teste de conexão com o provedor Luzia
"""

import os
import sys
import logging

# Adicionar o diretório src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'cobol_to_docs', 'src'))

from core.config import ConfigManager
from providers.luzia_provider import LuziaProvider
from providers.base_provider import AIRequest

def test_luzia_connection():
    """Testa a conexão com o provedor Luzia"""
    
    # Configurar logging
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    
    try:
        # Carregar configuração
        config_path = os.path.join(os.path.dirname(__file__), 'cobol_to_docs', 'config', 'config.yaml')
        config_manager = ConfigManager(config_path)
        config = config_manager.get_config()
        
        # Verificar se as variáveis de ambiente estão definidas
        client_id = os.getenv('LUZIA_CLIENT_ID')
        client_secret = os.getenv('LUZIA_CLIENT_SECRET')
        
        if not client_id or not client_secret:
            logger.error("❌ Variáveis LUZIA_CLIENT_ID e LUZIA_CLIENT_SECRET não estão definidas")
            logger.info("Configure as variáveis de ambiente:")
            logger.info("export LUZIA_CLIENT_ID='seu_client_id'")
            logger.info("export LUZIA_CLIENT_SECRET='seu_client_secret'")
            return False
        
        logger.info(f"✅ Variáveis de ambiente configuradas")
        logger.info(f"Client ID: {client_id[:10]}...")
        
        # Inicializar provedor Luzia
        luzia_config = config['providers']['luzia']
        luzia_provider = LuziaProvider(luzia_config)
        
        logger.info(f"✅ Provedor Luzia inicializado")
        logger.info(f"Auth URL: {luzia_provider.auth_url}")
        logger.info(f"API URL: {luzia_provider.api_url}")
        
        # Testar disponibilidade
        logger.info("🔄 Testando disponibilidade do Luzia...")
        is_available = luzia_provider.is_available()
        
        if is_available:
            logger.info("✅ Luzia está disponível!")
            
            # Teste simples de análise
            logger.info("🔄 Testando análise simples...")
            test_request = AIRequest(
                prompt="Analise este programa COBOL simples: IDENTIFICATION DIVISION. PROGRAM-ID. TESTE.",
                max_tokens=100,
                temperature=0.1,
                model="aws-claude-3-5-haiku",
                program_name="TESTE"
            )
            
            response = luzia_provider.analyze(test_request)
            
            if response.success:
                logger.info("✅ Teste de análise bem-sucedido!")
                logger.info(f"Resposta: {response.content[:100]}...")
                return True
            else:
                logger.error(f"❌ Falha na análise: {response.error_message}")
                return False
        else:
            logger.error("❌ Luzia não está disponível")
            return False
            
    except Exception as e:
        logger.error(f"❌ Erro no teste: {str(e)}")
        return False

if __name__ == "__main__":
    print("=== Teste de Conexão com Luzia ===")
    success = test_luzia_connection()
    
    if success:
        print("\n🎉 Todos os testes passaram! O Luzia está funcionando corretamente.")
    else:
        print("\n❌ Alguns testes falharam. Verifique a configuração.")
    
    sys.exit(0 if success else 1)
