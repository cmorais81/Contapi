import os
import re

def fix_relative_imports(file_path):
    with open(file_path, 'r') as f:
        content = f.read()
    
    # Fix relative imports like "from ..core import" to "from core import"
    content = re.sub(r'from \.\.([a-zA-Z_][a-zA-Z0-9_.]*) import', r'from \1 import', content)
    # Fix relative imports like "from .base_provider import" to "from base_provider import"
    content = re.sub(r'from \.([a-zA-Z_][a-zA-Z0-9_.]*) import', r'from \1 import', content)
    
    with open(file_path, 'w') as f:
        f.write(content)
    print(f"Fixed imports in {file_path}")

# Find all Python files in src and fix them
for root, dirs, files in os.walk('src'):
    for file in files:
        if file.endswith('.py'):
            file_path = os.path.join(root, file)
            fix_relative_imports(file_path)

print("All imports fixed!")
