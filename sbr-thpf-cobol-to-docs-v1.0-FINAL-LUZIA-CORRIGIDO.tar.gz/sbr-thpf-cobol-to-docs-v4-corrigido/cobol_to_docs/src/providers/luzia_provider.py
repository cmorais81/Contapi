"""
Provider LuzIA corrigido com URLs e payload corretos da versão funcionando
"""

import logging
import time
from typing import Dict, Any, Optional, List
import requests
from urllib3.exceptions import InsecureRequestWarning
import warnings

from .base_provider import BaseProvider, AIRequest, AIResponse

# Suprimir warnings de SSL
warnings.filterwarnings("ignore", message="Unverified HTTPS request")
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

class LuziaProvider(BaseProvider):
    """
    Provider LuzIA corrigido com URLs e payload corretos da versão funcionando
    """
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.logger = logging.getLogger("LuziaProvider")
        
        # Obter configurações do LuzIA do config.yaml
        self.auth_url = config.get("auth_url", "https://login.azure.paas.santanderbr.pre.corp/auth/realms/corp/protocol/openid-connect/token")
        self.api_url = config.get("api_url", "https://gut-api-aws.santanderbr.pre.corp/genai_services/v1/")
        self.client_id = config.get("client_id")
        self.client_secret = config.get("client_secret")
        self.timeout = config.get("timeout", 300)
        self.access_token = None
        self.token_expires_at = 0
        
        self.logger.info(f"LuziaProvider initialized with client_id: {self.client_id} and client_secret: {self.client_secret}")
    
    def _get_access_token(self) -> str:
        """
        Obtém um token de acesso para a API LuzIA.
        """
        if self.access_token and time.time() < self.token_expires_at:
            return self.access_token

        self.logger.info("Obtendo novo token de acesso para LuzIA...")
        token_url = self.auth_url
        headers = {
            "Content-Type": "application/x-www-form-urlencoded",
            "Accept": "*/*"
        }
        data = {
            "grant_type": "client_credentials",
            "client_id": self.client_id,
            "client_secret": self.client_secret
        }

        try:
            response = requests.post(token_url, headers=headers, data=data, timeout=10, verify=False)
            response.raise_for_status()
            token_data = response.json()
            self.access_token = token_data["access_token"]
            self.token_expires_at = time.time() + token_data["expires_in"] - 60  # 60s de buffer
            self.logger.info("Token de acesso LuzIA obtido com sucesso.")
            return self.access_token
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Erro ao obter token de acesso LuzIA: {e}")
            raise Exception(f"Falha na autenticação com LuzIA: {e}")

    def is_available(self) -> bool:
        """
        Verifica se o LuzIA está disponível tentando obter um token de acesso.
        """
        if not self.client_id or not self.client_secret:
            self.logger.warning("LuzIA client_id ou client_secret não configurado")
            return False
        
        try:
            self._get_access_token()
            return True
        except Exception as e:
            self.logger.error(f"Erro ao autenticar com LuzIA para verificar disponibilidade: {e}")
            return False

    def analyze(self, request: AIRequest) -> AIResponse:
        """
        Realiza análise usando a API LuzIA com payload correto.
        """
        start_time = time.time()
        
        try:
            # Obter token de acesso
            access_token = self._get_access_token()
            
            # Construir payload no formato LuzIA correto (baseado no exemplo fornecido)
            user_prompt_content = f"""
Analise o seguinte programa COBOL:

PROGRAMA: {request.program_name}

CÓDIGO:
{request.program_code}

PROMPT DE ANÁLISE:
{request.prompt}

Por favor, forneça uma análise técnica detalhada seguindo as diretrizes do prompt.
"""

            payload = {
                "input": {
                    "query": [
                        {
                            "role": "system",
                            "content": "Você é um especialista em análise de sistemas COBOL."
                        },
                        {
                            "role": "user",
                            "content": user_prompt_content
                        }
                    ]
                },
                "config": [
                    {
                        "type": "catena.llm.LLMRouter",
                        "obj_kwargs": {
                            "routing_model": request.model,
                            "temperature": request.temperature,
                            "max_tokens": request.max_tokens
                        }
                    }
                ]
            }
            
            self.logger.info(f"Enviando requisição para LuzIA - Programa: {request.program_name}")
            self.logger.info(f"Modelo: {request.model}")
            self.logger.info(f"Tokens máximos: {request.max_tokens}")
            
            # Headers
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {access_token}"
            }
            
            # Fazer requisição
            response = requests.post(
                f"{self.api_url}pipelines/submit",
                json=payload,
                headers=headers,
                timeout=self.timeout,
                verify=False
            )
            
            response_time = time.time() - start_time
            self.logger.info(f"Status da resposta: {response.status_code}")
            
            if response.status_code == 200:
                response_data = response.json()
                
                # Extrair conteúdo da resposta
                content = ""
                if "choices" in response_data and len(response_data["choices"]) > 0:
                    choice = response_data["choices"][0]
                    if "message" in choice and "content" in choice["message"]:
                        content = choice["message"]["content"]
                elif "output" in response_data:
                    content = str(response_data["output"])
                elif "result" in response_data:
                    content = str(response_data["result"])
                else:
                    # Fallback: usar toda a resposta como string
                    content = str(response_data)
                
                # Extrair tokens usados
                tokens_used = 0
                if "usage" in response_data:
                    tokens_used = response_data["usage"].get("total_tokens", 0)
                
                self.logger.info(f"Análise LuzIA concluída com sucesso em {response_time:.2f}s")
                
                return AIResponse(
                    success=True,
                    content=content,
                    tokens_used=tokens_used,
                    model=request.model,
                    provider="luzia",
                    response_time=response_time
                )
            else:
                error_msg = f"Erro HTTP {response.status_code}: {response.text}"
                self.logger.error(error_msg)
                
                return AIResponse(
                    success=False,
                    content="",
                    tokens_used=0,
                    model=request.model,
                    provider="luzia",
                    error_message=error_msg,
                    response_time=response_time
                )
                
        except Exception as e:
            response_time = time.time() - start_time
            error_msg = f"Erro na análise LuzIA: {str(e)}"
            self.logger.error(error_msg)
            
            return AIResponse(
                success=False,
                content="",
                tokens_used=0,
                model=request.model or "unknown",
                provider="luzia",
                error_message=error_msg,
                response_time=response_time
            )

    def get_statistics(self) -> Dict[str, Any]:
        """
        Retorna estatísticas do provider.
        """
        return {
            "provider": "luzia",
            "auth_url": self.auth_url,
            "api_url": self.api_url,
            "has_token": self.access_token is not None,
            "token_expires_at": self.token_expires_at
        }
