"""
Service para Lineage de Dados
"""

import asyncio
from datetime import datetime
from typing import Dict, List
from uuid import UUID

from src.application.dtos.lineage import (
    LineageGraphDTO,
    LineageTraceRequestDTO,
    LineageImpactAnalysisDTO,
    LineageRootCauseAnalysisDTO,
    LineageRegistrationDTO,
    LineageBulkTraceRequestDTO,
    LineageBulkTraceResponseDTO,
    ColumnLineageDTO,
    LineageStatsDTO,
    LineageNodeDTO,
    LineageEdgeDTO,
    LineageDirection,
    LineageType,
    TransformationType,
)
from src.database.repositories.lineage_repository import LineageRepository
from src.domain.exceptions import BusinessRuleViolation, EntityNotFoundError


class LineageService:
    """Service para operações de lineage"""

    def __init__(self, lineage_repository: LineageRepository):
        self.lineage_repository = lineage_repository

    async def trace_lineage(self, request: LineageTraceRequestDTO) -> LineageGraphDTO:
        """Rastreia lineage de uma entidade"""
        # Verificar se entidade existe
        entity_exists = await self.lineage_repository.entity_exists(request.entity_id)
        if not entity_exists:
            raise EntityNotFoundError(f"Entity {request.entity_id} not found")

        # Buscar nós e arestas do lineage
        nodes = []
        edges = []

        if request.direction in [LineageDirection.UPSTREAM, LineageDirection.BOTH]:
            upstream_nodes, upstream_edges = await self.lineage_repository.get_upstream_lineage(
                request.entity_id, request.max_depth
            )
            nodes.extend(upstream_nodes)
            edges.extend(upstream_edges)

        if request.direction in [LineageDirection.DOWNSTREAM, LineageDirection.BOTH]:
            downstream_nodes, downstream_edges = await self.lineage_repository.get_downstream_lineage(
                request.entity_id, request.max_depth
            )
            nodes.extend(downstream_nodes)
            edges.extend(downstream_edges)

        # Adicionar nó raiz se não estiver presente
        root_node = await self.lineage_repository.get_entity_node(request.entity_id)
        if root_node and not any(node.entity_id == request.entity_id for node in nodes):
            nodes.insert(0, root_node)

        # Remover duplicatas
        unique_nodes = self._deduplicate_nodes(nodes)
        unique_edges = self._deduplicate_edges(edges)

        # Filtrar por tipos de entidade se especificado
        if request.filter_entity_types:
            unique_nodes = [
                node for node in unique_nodes 
                if node.entity_type in request.filter_entity_types
            ]

        return LineageGraphDTO(
            nodes=unique_nodes,
            edges=unique_edges,
            root_entity_id=request.entity_id,
            direction=request.direction,
            max_depth=request.max_depth,
            total_nodes=len(unique_nodes),
            total_edges=len(unique_edges)
        )

    async def analyze_impact(self, entity_id: UUID, impact_type: str) -> LineageImpactAnalysisDTO:
        """Analisa impacto de mudanças em uma entidade"""
        entity_exists = await self.lineage_repository.entity_exists(entity_id)
        if not entity_exists:
            raise EntityNotFoundError(f"Entity {entity_id} not found")

        entity_info = await self.lineage_repository.get_entity_info(entity_id)
        
        # Buscar entidades afetadas (downstream)
        downstream_nodes, _ = await self.lineage_repository.get_downstream_lineage(entity_id, max_depth=5)
        
        # Calcular score de impacto baseado no número de entidades afetadas
        impact_score = min(len(downstream_nodes) * 5, 100)
        
        # Determinar nível de risco
        if impact_score >= 80:
            risk_level = "critical"
        elif impact_score >= 60:
            risk_level = "high"
        elif impact_score >= 30:
            risk_level = "medium"
        else:
            risk_level = "low"

        # Gerar recomendações baseadas no tipo de impacto
        recommendations = self._generate_impact_recommendations(impact_type, len(downstream_nodes))
        
        # Estimar esforço em horas
        estimated_effort = self._estimate_effort_hours(impact_type, len(downstream_nodes))

        return LineageImpactAnalysisDTO(
            entity_id=entity_id,
            entity_name=entity_info.get("name", "Unknown"),
            impact_type=impact_type,
            affected_entities=downstream_nodes,
            impact_score=impact_score,
            risk_level=risk_level,
            recommendations=recommendations,
            estimated_effort_hours=estimated_effort
        )

    async def analyze_root_cause(self, entity_id: UUID, issue_type: str) -> LineageRootCauseAnalysisDTO:
        """Analisa causa raiz de problemas"""
        entity_exists = await self.lineage_repository.entity_exists(entity_id)
        if not entity_exists:
            raise EntityNotFoundError(f"Entity {entity_id} not found")

        entity_info = await self.lineage_repository.get_entity_info(entity_id)
        
        # Buscar possíveis causas (upstream)
        upstream_nodes, _ = await self.lineage_repository.get_upstream_lineage(entity_id, max_depth=3)
        
        # Calcular scores de confiança para cada causa potencial
        confidence_scores = {}
        for node in upstream_nodes:
            # Score baseado na proximidade e tipo de entidade
            base_score = 1.0 - (node.level * 0.2)  # Diminui com a distância
            if node.entity_type in ["source", "raw"]:
                base_score += 0.2  # Fontes têm maior probabilidade
            confidence_scores[str(node.entity_id)] = max(0.1, base_score)

        # Gerar recomendações baseadas no tipo de problema
        recommendations = self._generate_root_cause_recommendations(issue_type, len(upstream_nodes))

        return LineageRootCauseAnalysisDTO(
            entity_id=entity_id,
            entity_name=entity_info.get("name", "Unknown"),
            issue_type=issue_type,
            potential_causes=upstream_nodes,
            confidence_scores=confidence_scores,
            investigation_path=upstream_nodes[:5],  # Top 5 mais próximos
            recommendations=recommendations
        )

    async def bulk_trace_lineage(self, request: LineageBulkTraceRequestDTO) -> LineageBulkTraceResponseDTO:
        """Trace de lineage em lote"""
        start_time = datetime.now()
        results = {}
        errors = {}
        success_count = 0
        error_count = 0

        if request.parallel_processing:
            # Processamento paralelo
            tasks = []
            for entity_id in request.entity_ids:
                trace_request = LineageTraceRequestDTO(
                    entity_id=entity_id,
                    direction=request.direction,
                    max_depth=request.max_depth,
                    include_transformations=request.include_transformations
                )
                tasks.append(self._safe_trace_lineage(trace_request))
            
            task_results = await asyncio.gather(*tasks, return_exceptions=True)
            
            for i, result in enumerate(task_results):
                entity_id = str(request.entity_ids[i])
                if isinstance(result, Exception):
                    errors[entity_id] = str(result)
                    error_count += 1
                else:
                    results[entity_id] = result
                    success_count += 1
        else:
            # Processamento sequencial
            for entity_id in request.entity_ids:
                try:
                    trace_request = LineageTraceRequestDTO(
                        entity_id=entity_id,
                        direction=request.direction,
                        max_depth=request.max_depth,
                        include_transformations=request.include_transformations
                    )
                    result = await self.trace_lineage(trace_request)
                    results[str(entity_id)] = result
                    success_count += 1
                except Exception as e:
                    errors[str(entity_id)] = str(e)
                    error_count += 1

        end_time = datetime.now()
        processing_time_ms = int((end_time - start_time).total_seconds() * 1000)

        return LineageBulkTraceResponseDTO(
            results=results,
            processing_time_ms=processing_time_ms,
            success_count=success_count,
            error_count=error_count,
            errors=errors
        )

    async def get_visual_graph(self, entity_id: UUID, format: str, max_depth: int) -> Dict:
        """Obtém grafo formatado para visualização"""
        if format not in ["d3", "cytoscape", "vis"]:
            raise BusinessRuleViolation(f"Unsupported format: {format}")

        request = LineageTraceRequestDTO(
            entity_id=entity_id,
            direction=LineageDirection.BOTH,
            max_depth=max_depth
        )
        
        graph = await self.trace_lineage(request)
        
        if format == "d3":
            return self._format_for_d3(graph)
        elif format == "cytoscape":
            return self._format_for_cytoscape(graph)
        elif format == "vis":
            return self._format_for_vis(graph)

    async def get_attribute_lineage(self, attribute_id: UUID, direction: LineageDirection) -> List[ColumnLineageDTO]:
        """Obtém lineage granular por atributo"""
        return await self.lineage_repository.get_attribute_lineage(attribute_id, direction)

    async def get_column_lineage(self, entity_id: UUID, column_names: List[str], direction: LineageDirection) -> List[ColumnLineageDTO]:
        """Obtém lineage por coluna"""
        return await self.lineage_repository.get_column_lineage(entity_id, column_names, direction)

    async def get_entity_transformations(self, entity_id: UUID) -> List[Dict]:
        """Lista transformações de uma entidade"""
        return await self.lineage_repository.get_entity_transformations(entity_id)

    async def register_lineage(self, lineage_data: LineageRegistrationDTO) -> UUID:
        """Registra lineage manualmente"""
        # Validar se entidades existem
        source_exists = await self.lineage_repository.entity_exists(lineage_data.source_entity_id)
        target_exists = await self.lineage_repository.entity_exists(lineage_data.target_entity_id)
        
        if not source_exists:
            raise EntityNotFoundError(f"Source entity {lineage_data.source_entity_id} not found")
        if not target_exists:
            raise EntityNotFoundError(f"Target entity {lineage_data.target_entity_id} not found")

        # Verificar se relacionamento já existe
        existing = await self.lineage_repository.get_lineage_relationship(
            lineage_data.source_entity_id, lineage_data.target_entity_id
        )
        if existing:
            raise BusinessRuleViolation("Lineage relationship already exists")

        return await self.lineage_repository.create_lineage_relationship(lineage_data)

    async def get_lineage_stats(self) -> LineageStatsDTO:
        """Obtém estatísticas de lineage"""
        stats = await self.lineage_repository.get_lineage_statistics()
        
        return LineageStatsDTO(
            total_entities_with_lineage=stats.get("total_entities_with_lineage", 0),
            total_lineage_relationships=stats.get("total_lineage_relationships", 0),
            avg_lineage_depth=stats.get("avg_lineage_depth", 0.0),
            most_connected_entity=stats.get("most_connected_entity"),
            lineage_coverage_percentage=stats.get("lineage_coverage_percentage", 0.0),
            last_updated=stats.get("last_updated", datetime.utcnow())
        )

    async def _safe_trace_lineage(self, request: LineageTraceRequestDTO) -> LineageGraphDTO:
        """Trace seguro para processamento paralelo"""
        try:
            return await self.trace_lineage(request)
        except Exception as e:
            raise e

    def _deduplicate_nodes(self, nodes: List[LineageNodeDTO]) -> List[LineageNodeDTO]:
        """Remove nós duplicados"""
        seen = set()
        unique_nodes = []
        for node in nodes:
            if node.entity_id not in seen:
                seen.add(node.entity_id)
                unique_nodes.append(node)
        return unique_nodes

    def _deduplicate_edges(self, edges: List[LineageEdgeDTO]) -> List[LineageEdgeDTO]:
        """Remove arestas duplicadas"""
        seen = set()
        unique_edges = []
        for edge in edges:
            edge_key = (edge.source_entity_id, edge.target_entity_id)
            if edge_key not in seen:
                seen.add(edge_key)
                unique_edges.append(edge)
        return unique_edges

    def _generate_impact_recommendations(self, impact_type: str, affected_count: int) -> List[str]:
        """Gera recomendações para análise de impacto"""
        recommendations = []
        
        if impact_type == "schema_change":
            recommendations.extend([
                "Update downstream ETL jobs and data pipelines",
                "Notify data consumers about schema changes",
                "Test data quality rules and validations",
                "Update data documentation and contracts"
            ])
        elif impact_type == "deletion":
            recommendations.extend([
                "Identify alternative data sources",
                "Migrate dependent processes",
                "Archive historical data if needed",
                "Update data catalogs and documentation"
            ])
        else:  # change
            recommendations.extend([
                "Test downstream data quality",
                "Validate business logic consistency",
                "Monitor data freshness and availability"
            ])

        if affected_count > 10:
            recommendations.append("Consider phased rollout approach")
            recommendations.append("Set up monitoring and alerting")

        return recommendations

    def _generate_root_cause_recommendations(self, issue_type: str, upstream_count: int) -> List[str]:
        """Gera recomendações para análise de causa raiz"""
        recommendations = []
        
        if issue_type == "quality":
            recommendations.extend([
                "Check source data quality and validation rules",
                "Validate transformation logic and business rules",
                "Review data ingestion processes",
                "Analyze data profiling results"
            ])
        elif issue_type == "availability":
            recommendations.extend([
                "Check source system availability",
                "Validate data pipeline execution status",
                "Review network connectivity and permissions",
                "Analyze job scheduling and dependencies"
            ])
        else:  # performance
            recommendations.extend([
                "Analyze query execution plans",
                "Check resource utilization and bottlenecks",
                "Review indexing and partitioning strategies",
                "Validate data volume and growth patterns"
            ])

        if upstream_count > 5:
            recommendations.append("Focus investigation on most critical upstream sources")

        return recommendations

    def _estimate_effort_hours(self, impact_type: str, affected_count: int) -> int:
        """Estima esforço em horas"""
        base_hours = {
            "schema_change": 8,
            "deletion": 16,
            "change": 4
        }
        
        base = base_hours.get(impact_type, 8)
        additional = min(affected_count * 2, 40)  # Max 40 horas adicionais
        
        return base + additional

    def _format_for_d3(self, graph: LineageGraphDTO) -> Dict:
        """Formata grafo para D3.js"""
        nodes = []
        links = []
        
        for node in graph.nodes:
            nodes.append({
                "id": str(node.entity_id),
                "name": node.entity_name,
                "type": node.entity_type,
                "level": node.level,
                "group": node.node_type
            })
        
        for edge in graph.edges:
            links.append({
                "source": str(edge.source_entity_id),
                "target": str(edge.target_entity_id),
                "type": edge.transformation_type,
                "confidence": edge.confidence_score
            })
        
        return {"nodes": nodes, "links": links}

    def _format_for_cytoscape(self, graph: LineageGraphDTO) -> Dict:
        """Formata grafo para Cytoscape.js"""
        elements = []
        
        for node in graph.nodes:
            elements.append({
                "data": {
                    "id": str(node.entity_id),
                    "label": node.entity_name,
                    "type": node.entity_type,
                    "level": node.level
                }
            })
        
        for edge in graph.edges:
            elements.append({
                "data": {
                    "id": f"{edge.source_entity_id}-{edge.target_entity_id}",
                    "source": str(edge.source_entity_id),
                    "target": str(edge.target_entity_id),
                    "type": edge.transformation_type
                }
            })
        
        return {"elements": elements}

    def _format_for_vis(self, graph: LineageGraphDTO) -> Dict:
        """Formata grafo para Vis.js"""
        nodes = []
        edges = []
        
        for node in graph.nodes:
            nodes.append({
                "id": str(node.entity_id),
                "label": node.entity_name,
                "group": node.entity_type,
                "level": node.level
            })
        
        for edge in graph.edges:
            edges.append({
                "from": str(edge.source_entity_id),
                "to": str(edge.target_entity_id),
                "label": edge.transformation_type,
                "arrows": "to"
            })
        
        return {"nodes": nodes, "edges": edges}

