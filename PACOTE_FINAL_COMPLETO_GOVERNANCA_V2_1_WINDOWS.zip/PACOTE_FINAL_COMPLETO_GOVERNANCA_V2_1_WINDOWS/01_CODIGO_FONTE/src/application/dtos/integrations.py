from typing import TypeVar
"""
DTOs para Integrações Externas
"""

from datetime import datetime
from enum import Enum
from typing import Dict, List, Optional, Union, Any
from uuid import UUID

from pydantic import BaseModel, Field


class IntegrationType(str, Enum):
    """Tipo de integração"""
    UNITY_CATALOG = "unity_catalog"
    INFORMATICA_AXON = "informatica_axon"
    APACHE_ATLAS = "apache_atlas"
    COLLIBRA = "collibra"
    ALATION = "alation"
    PURVIEW = "purview"
    DATABRICKS = "databricks"
    SNOWFLAKE = "snowflake"
    BIGQUERY = "bigquery"
    REDSHIFT = "redshift"
    WEBHOOK = "webhook"
    REST_API = "rest_api"
    CUSTOM = "custom"


class IntegrationStatus(str, Enum):
    """Status da integração"""
    ACTIVE = "active"
    INACTIVE = "inactive"
    ERROR = "error"
    SYNCING = "syncing"
    PENDING = "pending"
    DISABLED = "disabled"


class SyncDirection(str, Enum):
    """Direção da sincronização"""
    INBOUND = "inbound"  # External -> Our API
    OUTBOUND = "outbound"  # Our API -> External
    BIDIRECTIONAL = "bidirectional"


class AuthenticationType(str, Enum):
    """Tipo de autenticação"""
    API_KEY = "api_key"
    OAUTH2 = "oauth2"
    BASIC_AUTH = "basic_auth"
    BEARER_TOKEN = "bearer_token"
    SERVICE_PRINCIPAL = "service_principal"
    CERTIFICATE = "certificate"
    CUSTOM = "custom"


class IntegrationConfigDTO(BaseModel):
    """DTO para configuração de integração"""
    name: str = Field(..., min_length=1, max_length=255)
    description: str
    integration_type: IntegrationType
    endpoint_url: str = Field(..., min_length=1)
    authentication_type: AuthenticationType
    authentication_config: Dict = Field(default_factory=dict)
    sync_direction: SyncDirection = SyncDirection.INBOUND
    sync_frequency: str = Field(default="daily")  # hourly, daily, weekly, manual
    entity_mappings: Dict = Field(default_factory=dict)
    field_mappings: Dict = Field(default_factory=dict)
    filters: Dict = Field(default_factory=dict)
    transformation_rules: List[Dict] = Field(default_factory=list)
    retry_config: Dict = Field(default_factory=dict)
    timeout_seconds: int = Field(default=300, ge=1, le=3600)
    is_active: bool = Field(default=True)
    metadata: Dict = Field(default_factory=dict)

    class Config:
        json_schema_extra = {
            "example": {
                "name": "Unity Catalog Integration",
                "description": "Integration with Databricks Unity Catalog",
                "integration_type": "unity_catalog",
                "endpoint_url": "https://workspace.cloud.databricks.com",
                "authentication_type": "bearer_token",
                "authentication_config": {
                    "token": "dapi123...",
                    "workspace_id": "12345"
                },
                "sync_direction": "inbound",
                "sync_frequency": "daily",
                "entity_mappings": {
                    "catalog": "domain",
                    "schema": "subdomain",
                    "table": "entity"
                },
                "field_mappings": {
                    "table_name": "name",
                    "table_comment": "description",
                    "owner": "steward"
                },
                "filters": {
                    "catalogs": ["production", "staging"],
                    "exclude_system_tables": True
                },
                "transformation_rules": [
                    {
                        "field": "name",
                        "transformation": "lowercase"
                    }
                ],
                "retry_config": {
                    "max_retries": 3,
                    "backoff_factor": 2
                },
                "timeout_seconds": 300,
                "metadata": {"environment": "production"}
            }
        }


class IntegrationResponseDTO(BaseModel):
    """DTO para resposta de integração"""
    id: UUID
    name: str
    description: str
    integration_type: IntegrationType
    endpoint_url: str
    authentication_type: AuthenticationType
    sync_direction: SyncDirection
    sync_frequency: str
    status: IntegrationStatus
    last_sync_at: Optional[datetime] = None
    last_sync_status: Optional[str] = None
    next_sync_at: Optional[datetime] = None
    total_syncs: int = Field(default=0)
    successful_syncs: int = Field(default=0)
    failed_syncs: int = Field(default=0)
    entity_mappings: Dict
    field_mappings: Dict
    filters: Dict
    transformation_rules: List[Dict]
    is_active: bool
    created_by: UUID
    created_at: datetime
    updated_at: datetime
    metadata: Dict

    class Config:
        from_attributes = True


class SyncJobDTO(BaseModel):
    """DTO para job de sincronização"""
    integration_id: UUID
    sync_type: str = Field(default="full")  # full, incremental, delta
    force_sync: bool = Field(default=False)
    dry_run: bool = Field(default=False)
    specific_entities: List[str] = Field(default_factory=list)
    custom_filters: Dict = Field(default_factory=dict)
    metadata: Dict = Field(default_factory=dict)

    class Config:
        json_schema_extra = {
            "example": {
                "integration_id": "123e4567-e89b-12d3-a456-426614174000",
                "sync_type": "incremental",
                "force_sync": False,
                "dry_run": True,
                "specific_entities": ["catalog1.schema1.table1"],
                "custom_filters": {"modified_after": "2025-01-01T00:00:00Z"},
                "metadata": {"triggered_by": "user_request"}
            }
        }


class SyncJobResponseDTO(BaseModel):
    """DTO para resposta de job de sincronização"""
    id: UUID
    integration_id: UUID
    integration_name: str
    sync_type: str
    status: str  # queued, running, completed, failed, cancelled
    progress_percentage: float = Field(ge=0, le=100)
    entities_processed: int = Field(default=0)
    entities_created: int = Field(default=0)
    entities_updated: int = Field(default=0)
    entities_deleted: int = Field(default=0)
    entities_failed: int = Field(default=0)
    start_time: datetime
    end_time: Optional[datetime] = None
    execution_time_seconds: Optional[int] = None
    error_message: Optional[str] = None
    summary: Dict = Field(default_factory=dict)
    logs: List[str] = Field(default_factory=list)
    dry_run: bool
    triggered_by: UUID
    metadata: Dict

    class Config:
        from_attributes = True


class WebhookConfigDTO(BaseModel):
    """DTO para configuração de webhook"""
    name: str = Field(..., min_length=1, max_length=255)
    description: str
    url: str = Field(..., min_length=1)
    secret: Optional[str] = None
    events: List[str] = Field(min_items=1)
    headers: Dict[str, str] = Field(default_factory=dict)
    payload_template: Optional[str] = None
    retry_config: Dict = Field(default_factory=dict)
    timeout_seconds: int = Field(default=30, ge=1, le=300)
    is_active: bool = Field(default=True)
    metadata: Dict = Field(default_factory=dict)

    class Config:
        json_schema_extra = {
            "example": {
                "name": "Data Quality Webhook",
                "description": "Webhook for data quality events",
                "url": "https://external-system.com/webhooks/data-quality",
                "secret": "webhook_secret_123",
                "events": ["quality_rule_failed", "quality_score_changed"],
                "headers": {
                    "Content-Type": "application/json",
                    "X-API-Key": "api_key_123"
                },
                "payload_template": "{\"event\": \"{{event_type}}\", \"entity\": \"{{entity_name}}\"}",
                "retry_config": {
                    "max_retries": 3,
                    "backoff_seconds": [1, 2, 4]
                },
                "timeout_seconds": 30,
                "metadata": {"environment": "production"}
            }
        }


class WebhookDeliveryDTO(BaseModel):
    """DTO para entrega de webhook"""
    id: UUID
    webhook_id: UUID
    webhook_name: str
    event_type: str
    payload: Dict
    status: str  # pending, sent, delivered, failed
    http_status_code: Optional[int] = None
    response_body: Optional[str] = None
    error_message: Optional[str] = None
    attempt_count: int = Field(default=0)
    last_attempt_at: Optional[datetime] = None
    delivered_at: Optional[datetime] = None
    created_at: datetime

    class Config:
        from_attributes = True


class ExternalSystemDTO(BaseModel):
    """DTO para sistema externo"""
    name: str = Field(..., min_length=1, max_length=255)
    description: str
    system_type: str
    base_url: str = Field(..., min_length=1)
    version: Optional[str] = None
    capabilities: List[str] = Field(default_factory=list)
    supported_operations: List[str] = Field(default_factory=list)
    rate_limits: Dict = Field(default_factory=dict)
    health_check_url: Optional[str] = None
    documentation_url: Optional[str] = None
    contact_info: Dict = Field(default_factory=dict)
    is_active: bool = Field(default=True)
    metadata: Dict = Field(default_factory=dict)

    class Config:
        json_schema_extra = {
            "example": {
                "name": "Databricks Unity Catalog",
                "description": "Databricks Unity Catalog for metadata management",
                "system_type": "data_catalog",
                "base_url": "https://workspace.cloud.databricks.com",
                "version": "3.0",
                "capabilities": ["metadata_management", "lineage_tracking", "access_control"],
                "supported_operations": ["read_metadata", "write_metadata", "query_lineage"],
                "rate_limits": {
                    "requests_per_minute": 1000,
                    "concurrent_connections": 10
                },
                "health_check_url": "https://workspace.cloud.databricks.com/api/2.0/clusters/list",
                "documentation_url": "https://docs.databricks.com/data-governance/unity-catalog/",
                "contact_info": {
                    "admin_email": "admin@company.com",
                    "support_team": "data-platform-team"
                },
                "metadata": {"environment": "production", "region": "us-east-1"}
            }
        }


class DataMappingDTO(BaseModel):
    """DTO para mapeamento de dados"""
    source_system: str
    target_system: str
    entity_mappings: Dict[str, str] = Field(default_factory=dict)
    field_mappings: Dict[str, Dict] = Field(default_factory=dict)
    transformation_rules: List[Dict] = Field(default_factory=list)
    validation_rules: List[Dict] = Field(default_factory=list)
    is_active: bool = Field(default=True)
    metadata: Dict = Field(default_factory=dict)

    class Config:
        json_schema_extra = {
            "example": {
                "source_system": "unity_catalog",
                "target_system": "governance_api",
                "entity_mappings": {
                    "catalog": "domain",
                    "schema": "subdomain",
                    "table": "entity",
                    "column": "attribute"
                },
                "field_mappings": {
                    "table": {
                        "name": "name",
                        "comment": "description",
                        "owner": "steward_email",
                        "created_at": "created_at"
                    }
                },
                "transformation_rules": [
                    {
                        "field": "name",
                        "transformation": "lowercase",
                        "parameters": {}
                    },
                    {
                        "field": "description",
                        "transformation": "truncate",
                        "parameters": {"max_length": 500}
                    }
                ],
                "validation_rules": [
                    {
                        "field": "name",
                        "rule": "required"
                    },
                    {
                        "field": "steward_email",
                        "rule": "email_format"
                    }
                ],
                "metadata": {"version": "1.0", "last_updated": "2025-01-14"}
            }
        }


class IntegrationHealthDTO(BaseModel):
    """DTO para saúde da integração"""
    integration_id: UUID
    integration_name: str
    status: IntegrationStatus
    last_health_check: datetime
    response_time_ms: Optional[int] = None
    error_rate: float = Field(ge=0, le=1)
    success_rate: float = Field(ge=0, le=1)
    uptime_percentage: float = Field(ge=0, le=100)
    issues: List[str] = Field(default_factory=list)
    recommendations: List[str] = Field(default_factory=list)
    metrics: Dict = Field(default_factory=dict)

    class Config:
        json_schema_extra = {
            "example": {
                "integration_id": "123e4567-e89b-12d3-a456-426614174000",
                "integration_name": "Unity Catalog Integration",
                "status": "active",
                "last_health_check": "2025-01-14T10:00:00Z",
                "response_time_ms": 250,
                "error_rate": 0.02,
                "success_rate": 0.98,
                "uptime_percentage": 99.5,
                "issues": ["Occasional timeout on large queries"],
                "recommendations": [
                    "Consider increasing timeout configuration",
                    "Implement query pagination"
                ],
                "metrics": {
                    "avg_response_time_24h": 245,
                    "total_requests_24h": 1500,
                    "failed_requests_24h": 30
                }
            }
        }


class IntegrationStatsDTO(BaseModel):
    """DTO para estatísticas de integração"""
    integration_id: UUID
    integration_name: str
    total_syncs: int
    successful_syncs: int
    failed_syncs: int
    avg_sync_duration_seconds: float
    entities_synced: int
    last_sync_summary: Dict = Field(default_factory=dict)
    sync_frequency_analysis: Dict = Field(default_factory=dict)
    error_patterns: List[Dict] = Field(default_factory=list)
    performance_trends: Dict = Field(default_factory=dict)
    period_start: datetime
    period_end: datetime

    class Config:
        json_schema_extra = {
            "example": {
                "integration_id": "123e4567-e89b-12d3-a456-426614174000",
                "integration_name": "Unity Catalog Integration",
                "total_syncs": 150,
                "successful_syncs": 145,
                "failed_syncs": 5,
                "avg_sync_duration_seconds": 120.5,
                "entities_synced": 2500,
                "last_sync_summary": {
                    "entities_processed": 50,
                    "entities_created": 5,
                    "entities_updated": 40,
                    "entities_deleted": 2
                },
                "sync_frequency_analysis": {
                    "daily_syncs": 30,
                    "weekly_syncs": 4,
                    "manual_syncs": 116
                },
                "error_patterns": [
                    {
                        "error_type": "timeout",
                        "count": 3,
                        "percentage": 60.0
                    }
                ],
                "performance_trends": {
                    "sync_duration_trend": "stable",
                    "success_rate_trend": "improving"
                },
                "period_start": "2025-01-01T00:00:00Z",
                "period_end": "2025-01-14T23:59:59Z"
            }
        }


class APIConnectionTestDTO(BaseModel):
    """DTO para teste de conexão de API"""
    integration_type: IntegrationType
    endpoint_url: str
    authentication_type: AuthenticationType
    authentication_config: Dict
    timeout_seconds: int = Field(default=30, ge=1, le=300)
    test_operations: List[str] = Field(default_factory=list)

    class Config:
        json_schema_extra = {
            "example": {
                "integration_type": "unity_catalog",
                "endpoint_url": "https://workspace.cloud.databricks.com",
                "authentication_type": "bearer_token",
                "authentication_config": {
                    "token": "dapi123...",
                    "workspace_id": "12345"
                },
                "timeout_seconds": 30,
                "test_operations": ["list_catalogs", "get_catalog_info"]
            }
        }


class APIConnectionTestResultDTO(BaseModel):
    """DTO para resultado do teste de conexão"""
    success: bool
    response_time_ms: int
    status_code: Optional[int] = None
    error_message: Optional[str] = None
    test_results: Dict = Field(default_factory=dict)
    capabilities_detected: List[str] = Field(default_factory=list)
    recommendations: List[str] = Field(default_factory=list)
    tested_at: datetime

    class Config:
        json_schema_extra = {
            "example": {
                "success": True,
                "response_time_ms": 250,
                "status_code": 200,
                "error_message": None,
                "test_results": {
                    "list_catalogs": {"success": True, "count": 5},
                    "get_catalog_info": {"success": True, "response_time_ms": 150}
                },
                "capabilities_detected": ["metadata_read", "lineage_query"],
                "recommendations": [
                    "Connection is healthy",
                    "Consider enabling additional capabilities"
                ],
                "tested_at": "2025-01-14T10:00:00Z"
            }
        }

