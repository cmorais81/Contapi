from typing import TypeVar
"""
DTOs para Lineage de Dados
"""

from datetime import datetime
from enum import Enum
from typing import Dict, List, Optional
from uuid import UUID

from pydantic import BaseModel, Field


class LineageDirection(str, Enum):
    """Direção do lineage"""
    UPSTREAM = "upstream"
    DOWNSTREAM = "downstream"
    BOTH = "both"


class LineageType(str, Enum):
    """Tipo de lineage"""
    TABLE = "table"
    COLUMN = "column"
    TRANSFORMATION = "transformation"
    PROCESS = "process"


class TransformationType(str, Enum):
    """Tipo de transformação"""
    SELECT = "select"
    JOIN = "join"
    UNION = "union"
    AGGREGATE = "aggregate"
    FILTER = "filter"
    CUSTOM = "custom"


class LineageNodeDTO(BaseModel):
    """DTO para nó do lineage"""
    entity_id: UUID
    entity_name: str
    entity_type: str
    schema_name: Optional[str] = None
    table_name: Optional[str] = None
    column_name: Optional[str] = None
    node_type: LineageType
    level: int = Field(ge=0, description="Nível na hierarquia")
    metadata: Dict = Field(default_factory=dict)

    class Config:
        json_schema_extra = {
            "example": {
                "entity_id": "123e4567-e89b-12d3-a456-426614174000",
                "entity_name": "customer_data",
                "entity_type": "table",
                "schema_name": "sales",
                "table_name": "customers",
                "column_name": None,
                "node_type": "table",
                "level": 0,
                "metadata": {"source_system": "CRM"}
            }
        }


class LineageEdgeDTO(BaseModel):
    """DTO para aresta do lineage"""
    source_entity_id: UUID
    target_entity_id: UUID
    transformation_type: TransformationType
    transformation_logic: Optional[str] = None
    confidence_score: float = Field(ge=0, le=1, default=1.0)
    created_at: datetime
    metadata: Dict = Field(default_factory=dict)

    class Config:
        json_schema_extra = {
            "example": {
                "source_entity_id": "123e4567-e89b-12d3-a456-426614174000",
                "target_entity_id": "456e7890-e89b-12d3-a456-426614174000",
                "transformation_type": "select",
                "transformation_logic": "SELECT customer_id, name FROM raw_customers",
                "confidence_score": 0.95,
                "created_at": "2025-01-14T10:00:00Z",
                "metadata": {"job_id": "etl_job_123"}
            }
        }


class LineageGraphDTO(BaseModel):
    """DTO para grafo de lineage"""
    nodes: List[LineageNodeDTO]
    edges: List[LineageEdgeDTO]
    root_entity_id: UUID
    direction: LineageDirection
    max_depth: int
    total_nodes: int
    total_edges: int

    class Config:
        json_schema_extra = {
            "example": {
                "nodes": [],
                "edges": [],
                "root_entity_id": "123e4567-e89b-12d3-a456-426614174000",
                "direction": "both",
                "max_depth": 3,
                "total_nodes": 15,
                "total_edges": 12
            }
        }


class LineageTraceRequestDTO(BaseModel):
    """DTO para solicitação de trace de lineage"""
    entity_id: UUID
    direction: LineageDirection = LineageDirection.BOTH
    max_depth: int = Field(default=5, ge=1, le=10)
    include_transformations: bool = True
    include_metadata: bool = True
    filter_entity_types: Optional[List[str]] = None

    class Config:
        json_schema_extra = {
            "example": {
                "entity_id": "123e4567-e89b-12d3-a456-426614174000",
                "direction": "both",
                "max_depth": 3,
                "include_transformations": True,
                "include_metadata": True,
                "filter_entity_types": ["table", "view"]
            }
        }


class LineageImpactAnalysisDTO(BaseModel):
    """DTO para análise de impacto"""
    entity_id: UUID
    entity_name: str
    impact_type: str  # "change", "deletion", "schema_change"
    affected_entities: List[LineageNodeDTO]
    impact_score: float = Field(ge=0, le=100)
    risk_level: str  # "low", "medium", "high", "critical"
    recommendations: List[str]
    estimated_effort_hours: Optional[int] = None

    class Config:
        json_schema_extra = {
            "example": {
                "entity_id": "123e4567-e89b-12d3-a456-426614174000",
                "entity_name": "customer_data",
                "impact_type": "schema_change",
                "affected_entities": [],
                "impact_score": 75.5,
                "risk_level": "high",
                "recommendations": [
                    "Update downstream ETL jobs",
                    "Notify data consumers",
                    "Test data quality rules"
                ],
                "estimated_effort_hours": 16
            }
        }


class LineageRootCauseAnalysisDTO(BaseModel):
    """DTO para análise de causa raiz"""
    entity_id: UUID
    entity_name: str
    issue_type: str  # "quality", "availability", "performance"
    potential_causes: List[LineageNodeDTO]
    confidence_scores: Dict[str, float]  # entity_id -> confidence
    investigation_path: List[LineageNodeDTO]
    recommendations: List[str]

    class Config:
        json_schema_extra = {
            "example": {
                "entity_id": "123e4567-e89b-12d3-a456-426614174000",
                "entity_name": "customer_data",
                "issue_type": "quality",
                "potential_causes": [],
                "confidence_scores": {
                    "456e7890-e89b-12d3-a456-426614174000": 0.85
                },
                "investigation_path": [],
                "recommendations": [
                    "Check source data quality",
                    "Validate transformation logic",
                    "Review data validation rules"
                ]
            }
        }


class LineageRegistrationDTO(BaseModel):
    """DTO para registro manual de lineage"""
    source_entity_id: UUID
    target_entity_id: UUID
    transformation_type: TransformationType
    transformation_logic: Optional[str] = None
    confidence_score: float = Field(default=1.0, ge=0, le=1)
    metadata: Dict = Field(default_factory=dict)
    created_by: Optional[UUID] = None

    class Config:
        json_schema_extra = {
            "example": {
                "source_entity_id": "123e4567-e89b-12d3-a456-426614174000",
                "target_entity_id": "456e7890-e89b-12d3-a456-426614174000",
                "transformation_type": "custom",
                "transformation_logic": "Custom business logic transformation",
                "confidence_score": 0.9,
                "metadata": {"manual_entry": True, "verified": False},
                "created_by": "789e0123-e89b-12d3-a456-426614174000"
            }
        }


class LineageBulkTraceRequestDTO(BaseModel):
    """DTO para trace em lote"""
    entity_ids: List[UUID] = Field(min_items=1, max_items=50)
    direction: LineageDirection = LineageDirection.BOTH
    max_depth: int = Field(default=3, ge=1, le=5)
    include_transformations: bool = True
    parallel_processing: bool = True

    class Config:
        json_schema_extra = {
            "example": {
                "entity_ids": [
                    "123e4567-e89b-12d3-a456-426614174000",
                    "456e7890-e89b-12d3-a456-426614174000"
                ],
                "direction": "downstream",
                "max_depth": 2,
                "include_transformations": True,
                "parallel_processing": True
            }
        }


class LineageBulkTraceResponseDTO(BaseModel):
    """DTO para resposta de trace em lote"""
    results: Dict[str, LineageGraphDTO]  # entity_id -> graph
    processing_time_ms: int
    success_count: int
    error_count: int
    errors: Dict[str, str] = Field(default_factory=dict)  # entity_id -> error

    class Config:
        json_schema_extra = {
            "example": {
                "results": {},
                "processing_time_ms": 1250,
                "success_count": 2,
                "error_count": 0,
                "errors": {}
            }
        }


class ColumnLineageDTO(BaseModel):
    """DTO para lineage granular por coluna"""
    source_entity_id: UUID
    source_column: str
    target_entity_id: UUID
    target_column: str
    transformation_logic: Optional[str] = None
    data_type_source: Optional[str] = None
    data_type_target: Optional[str] = None
    confidence_score: float = Field(ge=0, le=1, default=1.0)

    class Config:
        json_schema_extra = {
            "example": {
                "source_entity_id": "123e4567-e89b-12d3-a456-426614174000",
                "source_column": "customer_id",
                "target_entity_id": "456e7890-e89b-12d3-a456-426614174000",
                "target_column": "cust_id",
                "transformation_logic": "CAST(customer_id AS VARCHAR)",
                "data_type_source": "INTEGER",
                "data_type_target": "VARCHAR",
                "confidence_score": 0.95
            }
        }


class LineageStatsDTO(BaseModel):
    """DTO para estatísticas de lineage"""
    total_entities_with_lineage: int
    total_lineage_relationships: int
    avg_lineage_depth: float
    most_connected_entity: Optional[str] = None
    lineage_coverage_percentage: float = Field(ge=0, le=100)
    last_updated: datetime

    class Config:
        json_schema_extra = {
            "example": {
                "total_entities_with_lineage": 245,
                "total_lineage_relationships": 1850,
                "avg_lineage_depth": 3.2,
                "most_connected_entity": "customer_master_table",
                "lineage_coverage_percentage": 78.5,
                "last_updated": "2025-01-14T10:00:00Z"
            }
        }

