from typing import TypeVar
"""
DTOs para Métricas e Analytics
"""

from datetime import datetime
from enum import Enum
from typing import Dict, List, Optional, Union
from uuid import UUID

from pydantic import BaseModel, Field


class MetricType(str, Enum):
    """Tipo de métrica"""
    USAGE = "usage"
    QUALITY = "quality"
    PERFORMANCE = "performance"
    GOVERNANCE = "governance"
    COMPLIANCE = "compliance"
    BUSINESS = "business"
    TECHNICAL = "technical"


class AggregationType(str, Enum):
    """Tipo de agregação"""
    SUM = "sum"
    AVG = "avg"
    COUNT = "count"
    MIN = "min"
    MAX = "max"
    MEDIAN = "median"
    PERCENTILE = "percentile"


class TimeGranularity(str, Enum):
    """Granularidade temporal"""
    HOUR = "hour"
    DAY = "day"
    WEEK = "week"
    MONTH = "month"
    QUARTER = "quarter"
    YEAR = "year"


class MetricDefinitionDTO(BaseModel):
    """DTO para definição de métrica"""
    name: str = Field(..., min_length=1, max_length=255)
    description: str
    metric_type: MetricType
    calculation_logic: str
    aggregation_type: AggregationType
    unit: Optional[str] = None
    target_value: Optional[float] = None
    threshold_warning: Optional[float] = None
    threshold_critical: Optional[float] = None
    is_higher_better: bool = Field(default=True)
    collection_frequency: str = Field(default="daily")  # hourly, daily, weekly
    retention_days: int = Field(default=365, ge=1, le=3650)
    tags: List[str] = Field(default_factory=list)
    metadata: Dict = Field(default_factory=dict)

    class Config:
        json_schema_extra = {
            "example": {
                "name": "Data Quality Score",
                "description": "Overall data quality score for an entity",
                "metric_type": "quality",
                "calculation_logic": "AVG(completeness, accuracy, consistency, validity)",
                "aggregation_type": "avg",
                "unit": "percentage",
                "target_value": 95.0,
                "threshold_warning": 85.0,
                "threshold_critical": 70.0,
                "is_higher_better": True,
                "collection_frequency": "daily",
                "retention_days": 365,
                "tags": ["quality", "automated"],
                "metadata": {"dashboard_visible": True}
            }
        }


class MetricValueDTO(BaseModel):
    """DTO para valor de métrica"""
    metric_id: UUID
    entity_id: Optional[UUID] = None
    domain_id: Optional[UUID] = None
    value: float
    timestamp: datetime
    dimensions: Dict = Field(default_factory=dict)
    metadata: Dict = Field(default_factory=dict)

    class Config:
        json_schema_extra = {
            "example": {
                "metric_id": "123e4567-e89b-12d3-a456-426614174000",
                "entity_id": "456e7890-e89b-12d3-a456-426614174000",
                "value": 87.5,
                "timestamp": "2025-01-14T10:00:00Z",
                "dimensions": {"department": "sales", "region": "north"},
                "metadata": {"collection_method": "automated"}
            }
        }


class MetricQueryDTO(BaseModel):
    """DTO para consulta de métricas"""
    metric_ids: List[UUID] = Field(min_items=1)
    entity_ids: Optional[List[UUID]] = None
    domain_ids: Optional[List[UUID]] = None
    start_date: datetime
    end_date: datetime
    granularity: TimeGranularity = TimeGranularity.DAY
    aggregation: Optional[AggregationType] = None
    dimensions: Optional[List[str]] = None
    filters: Dict = Field(default_factory=dict)

    class Config:
        json_schema_extra = {
            "example": {
                "metric_ids": ["123e4567-e89b-12d3-a456-426614174000"],
                "entity_ids": ["456e7890-e89b-12d3-a456-426614174000"],
                "start_date": "2025-01-01T00:00:00Z",
                "end_date": "2025-01-14T23:59:59Z",
                "granularity": "day",
                "aggregation": "avg",
                "dimensions": ["department"],
                "filters": {"department": "sales"}
            }
        }


class MetricResultDTO(BaseModel):
    """DTO para resultado de métrica"""
    metric_id: UUID
    metric_name: str
    entity_id: Optional[UUID]
    entity_name: Optional[str]
    domain_id: Optional[UUID]
    domain_name: Optional[str]
    values: List[Dict]  # timestamp, value, dimensions
    aggregated_value: Optional[float]
    trend: Optional[str]  # increasing, decreasing, stable
    status: str  # good, warning, critical
    last_updated: datetime

    class Config:
        json_schema_extra = {
            "example": {
                "metric_id": "123e4567-e89b-12d3-a456-426614174000",
                "metric_name": "Data Quality Score",
                "entity_id": "456e7890-e89b-12d3-a456-426614174000",
                "entity_name": "customer_data",
                "values": [
                    {"timestamp": "2025-01-13T00:00:00Z", "value": 85.0},
                    {"timestamp": "2025-01-14T00:00:00Z", "value": 87.5}
                ],
                "aggregated_value": 86.25,
                "trend": "increasing",
                "status": "warning",
                "last_updated": "2025-01-14T10:00:00Z"
            }
        }


class DashboardDTO(BaseModel):
    """DTO para dashboard"""
    name: str = Field(..., min_length=1, max_length=255)
    description: Optional[str] = None
    dashboard_type: str = Field(default="operational")  # operational, executive, technical
    layout: Dict = Field(default_factory=dict)
    widgets: List[Dict] = Field(default_factory=list)
    filters: Dict = Field(default_factory=dict)
    refresh_interval: int = Field(default=300, ge=60)  # seconds
    is_public: bool = Field(default=False)
    owner_id: UUID
    shared_with: List[UUID] = Field(default_factory=list)
    tags: List[str] = Field(default_factory=list)

    class Config:
        json_schema_extra = {
            "example": {
                "name": "Data Quality Dashboard",
                "description": "Overview of data quality metrics",
                "dashboard_type": "operational",
                "layout": {"columns": 3, "rows": 4},
                "widgets": [
                    {
                        "id": "widget_1",
                        "type": "metric_chart",
                        "metric_id": "123e4567-e89b-12d3-a456-426614174000",
                        "position": {"x": 0, "y": 0, "w": 2, "h": 2}
                    }
                ],
                "filters": {"domain": "customer"},
                "refresh_interval": 300,
                "is_public": False,
                "owner_id": "789e0123-e89b-12d3-a456-426614174000",
                "tags": ["quality", "monitoring"]
            }
        }


class ReportRequestDTO(BaseModel):
    """DTO para solicitação de relatório"""
    name: str = Field(..., min_length=1, max_length=255)
    report_type: str  # governance, quality, usage, compliance
    scope: str = Field(default="system")  # system, domain, entity
    target_ids: List[UUID] = Field(default_factory=list)
    metrics: List[UUID] = Field(default_factory=list)
    period_start: datetime
    period_end: datetime
    granularity: TimeGranularity = TimeGranularity.DAY
    include_charts: bool = Field(default=True)
    include_recommendations: bool = Field(default=True)
    format: str = Field(default="pdf")  # pdf, excel, json
    delivery_method: str = Field(default="download")  # download, email
    recipients: List[str] = Field(default_factory=list)

    class Config:
        json_schema_extra = {
            "example": {
                "name": "Monthly Data Quality Report",
                "report_type": "quality",
                "scope": "domain",
                "target_ids": ["123e4567-e89b-12d3-a456-426614174000"],
                "period_start": "2025-01-01T00:00:00Z",
                "period_end": "2025-01-31T23:59:59Z",
                "granularity": "week",
                "include_charts": True,
                "include_recommendations": True,
                "format": "pdf",
                "delivery_method": "email",
                "recipients": ["manager@company.com"]
            }
        }


class GovernanceScoreDTO(BaseModel):
    """DTO para score de governança"""
    entity_id: Optional[UUID] = None
    domain_id: Optional[UUID] = None
    overall_score: float = Field(ge=0, le=100)
    quality_score: float = Field(ge=0, le=100)
    compliance_score: float = Field(ge=0, le=100)
    documentation_score: float = Field(ge=0, le=100)
    usage_score: float = Field(ge=0, le=100)
    stewardship_score: float = Field(ge=0, le=100)
    score_breakdown: Dict[str, float]
    improvement_areas: List[str]
    strengths: List[str]
    last_calculated: datetime
    trend: str  # improving, declining, stable

    class Config:
        json_schema_extra = {
            "example": {
                "entity_id": "123e4567-e89b-12d3-a456-426614174000",
                "overall_score": 78.5,
                "quality_score": 85.0,
                "compliance_score": 90.0,
                "documentation_score": 65.0,
                "usage_score": 80.0,
                "stewardship_score": 72.5,
                "score_breakdown": {
                    "data_quality": 85.0,
                    "metadata_completeness": 65.0,
                    "policy_compliance": 90.0
                },
                "improvement_areas": [
                    "Improve documentation coverage",
                    "Assign data stewards"
                ],
                "strengths": [
                    "High data quality",
                    "Good compliance posture"
                ],
                "last_calculated": "2025-01-14T10:00:00Z",
                "trend": "improving"
            }
        }


class UsageAnalyticsDTO(BaseModel):
    """DTO para analytics de uso"""
    entity_id: UUID
    entity_name: str
    period_start: datetime
    period_end: datetime
    total_queries: int
    unique_users: int
    avg_queries_per_user: float
    peak_usage_hour: int
    peak_usage_day: str
    most_accessed_attributes: List[Dict]
    user_departments: Dict[str, int]
    query_patterns: List[Dict]
    performance_metrics: Dict[str, float]
    growth_rate: float

    class Config:
        json_schema_extra = {
            "example": {
                "entity_id": "123e4567-e89b-12d3-a456-426614174000",
                "entity_name": "customer_data",
                "period_start": "2025-01-01T00:00:00Z",
                "period_end": "2025-01-14T23:59:59Z",
                "total_queries": 1250,
                "unique_users": 45,
                "avg_queries_per_user": 27.8,
                "peak_usage_hour": 14,
                "peak_usage_day": "Tuesday",
                "most_accessed_attributes": [
                    {"attribute": "customer_id", "count": 800},
                    {"attribute": "email", "count": 650}
                ],
                "user_departments": {
                    "Sales": 25,
                    "Marketing": 15,
                    "Analytics": 5
                },
                "query_patterns": [
                    {"pattern": "SELECT customer_id, email", "count": 300}
                ],
                "performance_metrics": {
                    "avg_response_time_ms": 150.5,
                    "cache_hit_rate": 0.85
                },
                "growth_rate": 0.15
            }
        }


class AlertRuleDTO(BaseModel):
    """DTO para regra de alerta"""
    name: str = Field(..., min_length=1, max_length=255)
    description: str
    metric_id: UUID
    condition: str  # >, <, >=, <=, ==, !=
    threshold_value: float
    severity: str = Field(default="medium")  # low, medium, high, critical
    notification_channels: List[str] = Field(default_factory=list)
    is_active: bool = Field(default=True)
    cooldown_minutes: int = Field(default=60, ge=1)
    entity_filters: Dict = Field(default_factory=dict)
    metadata: Dict = Field(default_factory=dict)

    class Config:
        json_schema_extra = {
            "example": {
                "name": "Low Data Quality Alert",
                "description": "Alert when data quality score drops below 80%",
                "metric_id": "123e4567-e89b-12d3-a456-426614174000",
                "condition": "<",
                "threshold_value": 80.0,
                "severity": "high",
                "notification_channels": ["email", "slack"],
                "is_active": True,
                "cooldown_minutes": 120,
                "entity_filters": {"domain": "customer"},
                "metadata": {"escalation_after": 3}
            }
        }


class AlertDTO(BaseModel):
    """DTO para alerta"""
    id: UUID
    rule_id: UUID
    rule_name: str
    metric_id: UUID
    metric_name: str
    entity_id: Optional[UUID]
    entity_name: Optional[str]
    current_value: float
    threshold_value: float
    condition: str
    severity: str
    status: str  # active, acknowledged, resolved
    triggered_at: datetime
    acknowledged_at: Optional[datetime] = None
    acknowledged_by: Optional[UUID] = None
    resolved_at: Optional[datetime] = None
    message: str
    metadata: Dict

    class Config:
        from_attributes = True


class TrendAnalysisDTO(BaseModel):
    """DTO para análise de tendência"""
    metric_id: UUID
    metric_name: str
    entity_id: Optional[UUID]
    entity_name: Optional[str]
    period_start: datetime
    period_end: datetime
    trend_direction: str  # increasing, decreasing, stable, volatile
    trend_strength: float = Field(ge=0, le=1)  # 0 = no trend, 1 = strong trend
    slope: float
    r_squared: float = Field(ge=0, le=1)
    seasonal_pattern: Optional[str] = None
    anomalies: List[Dict] = Field(default_factory=list)
    forecast: List[Dict] = Field(default_factory=list)
    confidence_interval: Dict = Field(default_factory=dict)

    class Config:
        json_schema_extra = {
            "example": {
                "metric_id": "123e4567-e89b-12d3-a456-426614174000",
                "metric_name": "Data Quality Score",
                "entity_id": "456e7890-e89b-12d3-a456-426614174000",
                "entity_name": "customer_data",
                "period_start": "2025-01-01T00:00:00Z",
                "period_end": "2025-01-14T23:59:59Z",
                "trend_direction": "increasing",
                "trend_strength": 0.75,
                "slope": 0.5,
                "r_squared": 0.85,
                "seasonal_pattern": "weekly",
                "anomalies": [
                    {"date": "2025-01-10", "value": 65.0, "expected": 85.0}
                ],
                "forecast": [
                    {"date": "2025-01-15", "value": 88.0, "confidence": 0.9}
                ],
                "confidence_interval": {"lower": 85.0, "upper": 91.0}
            }
        }


class BenchmarkDTO(BaseModel):
    """DTO para benchmark"""
    metric_id: UUID
    metric_name: str
    entity_id: UUID
    entity_name: str
    current_value: float
    industry_average: Optional[float] = None
    peer_average: Optional[float] = None
    best_in_class: Optional[float] = None
    percentile_rank: Optional[float] = None
    comparison_entities: List[Dict] = Field(default_factory=list)
    gap_analysis: Dict = Field(default_factory=dict)
    recommendations: List[str] = Field(default_factory=list)
    last_updated: datetime

    class Config:
        json_schema_extra = {
            "example": {
                "metric_id": "123e4567-e89b-12d3-a456-426614174000",
                "metric_name": "Data Quality Score",
                "entity_id": "456e7890-e89b-12d3-a456-426614174000",
                "entity_name": "customer_data",
                "current_value": 85.0,
                "industry_average": 78.5,
                "peer_average": 82.0,
                "best_in_class": 95.0,
                "percentile_rank": 75.0,
                "comparison_entities": [
                    {"name": "product_data", "value": 90.0},
                    {"name": "order_data", "value": 80.0}
                ],
                "gap_analysis": {
                    "vs_industry": 6.5,
                    "vs_best_in_class": -10.0
                },
                "recommendations": [
                    "Improve data validation rules",
                    "Implement automated quality checks"
                ],
                "last_updated": "2025-01-14T10:00:00Z"
            }
        }

