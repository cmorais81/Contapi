"""
Gerenciador de Sessões Avançado
API de Governança de Dados V1.9
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

import logging
from typing import Optional, Any, Dict
from contextlib import contextmanager
from sqlalchemy.orm import Session
from sqlalchemy.exc import SQLAlchemyError
from .connection import get_database_connection

logger = logging.getLogger(__name__)

class SessionManager:
    """Gerenciador avançado de sessões com transações e rollback"""
    
    def __init__(self):
        self.db_connection = get_database_connection()
    
    @contextmanager
    def transaction(self, session: Optional[Session] = None):
        """Context manager para transações com rollback automático"""
        if session is None:
            session = self.db_connection.get_session()
            should_close = True
        else:
            should_close = False
        
        try:
            yield session
            session.commit()
            logger.debug("Transação commitada com sucesso")
        except SQLAlchemyError as e:
            session.rollback()
            logger.error(f"Erro na transação, rollback executado: {e}")
            raise
        except Exception as e:
            session.rollback()
            logger.error(f"Erro inesperado na transação: {e}")
            raise
        finally:
            if should_close:
                session.close()
    
    @contextmanager
    def read_only_session(self):
        """Context manager para sessões somente leitura"""
        session = self.db_connection.get_session()
        try:
            # Configurar sessão como read-only
            session.execute("SET TRANSACTION READ ONLY")
            yield session
        except Exception as e:
            logger.error(f"Erro na sessão read-only: {e}")
            raise
        finally:
            session.close()
    
    def execute_with_retry(self, operation, max_retries: int = 3, **kwargs):
        """Executa operação com retry automático"""
        last_exception = None
        
        for attempt in range(max_retries):
            try:
                with self.transaction() as session:
                    return operation(session, **kwargs)
            except SQLAlchemyError as e:
                last_exception = e
                logger.warning(f"Tentativa {attempt + 1} falhou: {e}")
                if attempt == max_retries - 1:
                    break
        
        logger.error(f"Operação falhou após {max_retries} tentativas")
        raise last_exception
    
    def bulk_insert(self, model_class, data_list: list, batch_size: int = 1000):
        """Inserção em lote otimizada"""
        with self.transaction() as session:
            for i in range(0, len(data_list), batch_size):
                batch = data_list[i:i + batch_size]
                session.bulk_insert_mappings(model_class, batch)
                logger.debug(f"Inseridos {len(batch)} registros de {model_class.__name__}")
    
    def bulk_update(self, model_class, data_list: list, batch_size: int = 1000):
        """Atualização em lote otimizada"""
        with self.transaction() as session:
            for i in range(0, len(data_list), batch_size):
                batch = data_list[i:i + batch_size]
                session.bulk_update_mappings(model_class, batch)
                logger.debug(f"Atualizados {len(batch)} registros de {model_class.__name__}")
    
    def get_session_stats(self, session: Session) -> Dict[str, Any]:
        """Obtém estatísticas da sessão"""
        return {
            'dirty_objects': len(session.dirty),
            'new_objects': len(session.new),
            'deleted_objects': len(session.deleted),
            'identity_map_size': len(session.identity_map),
            'is_active': session.is_active,
            'autocommit': session.autocommit,
            'autoflush': session.autoflush
        }

# Instância global do gerenciador
session_manager = SessionManager()

