"""
Configuração de Conexão com Banco de Dados
API de Governança de Dados V1.9
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

import os
import logging
from typing import Generator
from sqlalchemy import create_engine, event
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.pool import QueuePool
from contextlib import contextmanager

logger = logging.getLogger(__name__)

class DatabaseConnection:
    """Gerenciador de conexão com banco de dados"""
    
    def __init__(self):
        self.database_url = self._get_database_url()
        self.engine = self._create_engine()
        self.SessionLocal = sessionmaker(
            autocommit=False,
            autoflush=False,
            bind=self.engine
        )
        logger.info("DatabaseConnection inicializado com sucesso")
    
    def _get_database_url(self) -> str:
        """Obtém URL de conexão do banco de dados"""
        # Configuração para diferentes ambientes
        database_url = os.getenv(
            'DATABASE_URL',
            'postgresql://postgres:postgres@localhost:5432/governance_db'
        )
        
        # Para desenvolvimento local, usar SQLite se PostgreSQL não disponível
        if database_url.startswith('postgresql://') and os.getenv('ENVIRONMENT') == 'development':
            try:
                # Tenta conectar no PostgreSQL
                test_engine = create_engine(database_url)
                test_engine.connect().close()
                logger.info("Usando PostgreSQL para desenvolvimento")
            except Exception as e:
                logger.warning(f"PostgreSQL não disponível: {e}")
                database_url = 'sqlite:///./governance_dev.db'
                logger.info("Usando SQLite para desenvolvimento")
        
        return database_url
    
    def _create_engine(self):
        """Cria engine do SQLAlchemy com configurações otimizadas"""
        engine_kwargs = {
            'echo': os.getenv('SQL_ECHO', 'false').lower() == 'true',
            'future': True
        }
        
        # Configurações específicas para PostgreSQL
        if self.database_url.startswith('postgresql://'):
            engine_kwargs.update({
                'poolclass': QueuePool,
                'pool_size': int(os.getenv('DB_POOL_SIZE', '10')),
                'max_overflow': int(os.getenv('DB_MAX_OVERFLOW', '20')),
                'pool_timeout': int(os.getenv('DB_POOL_TIMEOUT', '30')),
                'pool_recycle': int(os.getenv('DB_POOL_RECYCLE', '3600')),
                'pool_pre_ping': True
            })
        
        engine = create_engine(self.database_url, **engine_kwargs)
        
        # Event listeners para logging e monitoramento
        @event.listens_for(engine, "connect")
        def set_sqlite_pragma(dbapi_connection, connection_record):
            if 'sqlite' in self.database_url:
                cursor = dbapi_connection.cursor()
                cursor.execute("PRAGMA foreign_keys=ON")
                cursor.close()
        
        return engine
    
    def get_session(self) -> Session:
        """Obtém nova sessão do banco de dados"""
        return self.SessionLocal()
    
    @contextmanager
    def session_scope(self):
        """Context manager para sessão com commit/rollback automático"""
        session = self.get_session()
        try:
            yield session
            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()
    
    def create_tables(self):
        """Cria todas as tabelas no banco de dados"""
        from .base import Base
        Base.metadata.create_all(bind=self.engine)
        logger.info("Tabelas criadas com sucesso")
    
    def drop_tables(self):
        """Remove todas as tabelas do banco de dados"""
        from .base import Base
        Base.metadata.drop_all(bind=self.engine)
        logger.info("Tabelas removidas com sucesso")
    
    def health_check(self) -> bool:
        """Verifica saúde da conexão com banco"""
        try:
            with self.session_scope() as session:
                session.execute("SELECT 1")
            return True
        except Exception as e:
            logger.error(f"Health check falhou: {e}")
            return False

# Instância global da conexão
_db_connection = None

def get_database_connection() -> DatabaseConnection:
    """Obtém instância singleton da conexão"""
    global _db_connection
    if _db_connection is None:
        _db_connection = DatabaseConnection()
    return _db_connection

def get_database_session() -> Generator[Session, None, None]:
    """Dependency para FastAPI - obtém sessão do banco"""
    db_connection = get_database_connection()
    session = db_connection.get_session()
    try:
        yield session
    finally:
        session.close()

# Para compatibilidade com FastAPI Depends
def get_db() -> Generator[Session, None, None]:
    """Alias para get_database_session"""
    yield from get_database_session()


# Função assíncrona para compatibilidade
async def get_async_session() -> Generator[Session, None, None]:
    """Dependency assíncrona para FastAPI - obtém sessão do banco"""
    db_connection = get_database_connection()
    session = db_connection.get_session()
    try:
        yield session
    finally:
        session.close()

# Alias para compatibilidade
async def get_async_db() -> Generator[Session, None, None]:
    """Alias para get_async_session"""
    async for session in get_async_session():
        yield session

