"""
Repositories - Camada de Acesso a Dados
API de Governança de Dados V1.9
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from .base import BaseRepository
from .user_repository import UserRepository
from .contract_repository import ContractRepository
from .entity_repository import EntityRepository
from .quality_repository import QualityRepository

__all__ = [
    'BaseRepository',
    'UserRepository', 
    'ContractRepository',
    'EntityRepository',
    'QualityRepository'
]

