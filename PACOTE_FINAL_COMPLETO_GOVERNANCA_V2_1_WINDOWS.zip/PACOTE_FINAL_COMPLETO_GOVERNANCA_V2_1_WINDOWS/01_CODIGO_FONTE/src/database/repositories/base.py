"""
Repository Base com operações CRUD genéricas
API de Governança de Dados V1.9
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from typing import Generic, TypeVar, Type, List, Optional, Dict, Any
from uuid import UUID
from sqlalchemy.orm import Session
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy import and_, or_, desc, asc
from ..base import Base

T = TypeVar('T', bound=Base)

class BaseRepository(Generic[T]):
    """Repository base com operações CRUD genéricas"""
    
    def __init__(self, model: Type[T], session: Session):
        self.model = model
        self.session = session
    
    def create(self, **kwargs) -> T:
        """Cria novo registro"""
        try:
            instance = self.model(**kwargs)
            self.session.add(instance)
            self.session.flush()  # Para obter o ID sem commit
            return instance
        except SQLAlchemyError as e:
            self.session.rollback()
            raise e
    
    def get_by_id(self, id: UUID) -> Optional[T]:
        """Obtém registro por ID"""
        return self.session.query(self.model).filter(self.model.id == id).first()
    
    def get_all(self, limit: int = 100, offset: int = 0) -> List[T]:
        """Obtém todos os registros com paginação"""
        return (
            self.session.query(self.model)
            .offset(offset)
            .limit(limit)
            .all()
        )
    
    def update(self, id: UUID, **kwargs) -> Optional[T]:
        """Atualiza registro por ID"""
        try:
            instance = self.get_by_id(id)
            if instance:
                for key, value in kwargs.items():
                    if hasattr(instance, key) and key not in ['id', 'created_at']:
                        setattr(instance, key, value)
                self.session.flush()
            return instance
        except SQLAlchemyError as e:
            self.session.rollback()
            raise e
    
    def delete(self, id: UUID) -> bool:
        """Remove registro por ID"""
        try:
            instance = self.get_by_id(id)
            if instance:
                self.session.delete(instance)
                self.session.flush()
                return True
            return False
        except SQLAlchemyError as e:
            self.session.rollback()
            raise e
    
    def count(self, filters: Optional[Dict[str, Any]] = None) -> int:
        """Conta registros com filtros opcionais"""
        query = self.session.query(self.model)
        if filters:
            query = self._apply_filters(query, filters)
        return query.count()
    
    def find_by(self, **kwargs) -> List[T]:
        """Busca registros por critérios"""
        return self.session.query(self.model).filter_by(**kwargs).all()
    
    def find_one_by(self, **kwargs) -> Optional[T]:
        """Busca um registro por critérios"""
        return self.session.query(self.model).filter_by(**kwargs).first()
    
    def exists(self, **kwargs) -> bool:
        """Verifica se registro existe"""
        return self.session.query(self.model).filter_by(**kwargs).first() is not None
    
    def search(self, 
               filters: Optional[Dict[str, Any]] = None,
               search_term: Optional[str] = None,
               sort_by: Optional[str] = None,
               sort_order: str = 'asc',
               limit: int = 100,
               offset: int = 0) -> List[T]:
        """Busca avançada com filtros, ordenação e paginação"""
        
        query = self.session.query(self.model)
        
        # Aplicar filtros
        if filters:
            query = self._apply_filters(query, filters)
        
        # Aplicar busca textual (se o modelo tiver campos de texto)
        if search_term:
            query = self._apply_text_search(query, search_term)
        
        # Aplicar ordenação
        if sort_by and hasattr(self.model, sort_by):
            order_func = desc if sort_order.lower() == 'desc' else asc
            query = query.order_by(order_func(getattr(self.model, sort_by)))
        
        # Aplicar paginação
        return query.offset(offset).limit(limit).all()
    
    def bulk_create(self, data_list: List[Dict[str, Any]]) -> List[T]:
        """Criação em lote"""
        try:
            instances = [self.model(**data) for data in data_list]
            self.session.add_all(instances)
            self.session.flush()
            return instances
        except SQLAlchemyError as e:
            self.session.rollback()
            raise e
    
    def bulk_update(self, updates: List[Dict[str, Any]]) -> int:
        """Atualização em lote"""
        try:
            count = 0
            for update_data in updates:
                if 'id' in update_data:
                    id = update_data.pop('id')
                    updated = self.session.query(self.model).filter(
                        self.model.id == id
                    ).update(update_data)
                    count += updated
            self.session.flush()
            return count
        except SQLAlchemyError as e:
            self.session.rollback()
            raise e
    
    def _apply_filters(self, query, filters: Dict[str, Any]):
        """Aplica filtros à query"""
        for key, value in filters.items():
            if hasattr(self.model, key):
                if isinstance(value, list):
                    query = query.filter(getattr(self.model, key).in_(value))
                elif isinstance(value, dict):
                    # Suporte para operadores como {'gte': 10, 'lte': 20}
                    column = getattr(self.model, key)
                    if 'gte' in value:
                        query = query.filter(column >= value['gte'])
                    if 'lte' in value:
                        query = query.filter(column <= value['lte'])
                    if 'gt' in value:
                        query = query.filter(column > value['gt'])
                    if 'lt' in value:
                        query = query.filter(column < value['lt'])
                    if 'ne' in value:
                        query = query.filter(column != value['ne'])
                else:
                    query = query.filter(getattr(self.model, key) == value)
        return query
    
    def _apply_text_search(self, query, search_term: str):
        """Aplica busca textual em campos de texto do modelo"""
        text_columns = []
        for column in self.model.__table__.columns:
            if str(column.type).lower() in ['text', 'string', 'varchar']:
                text_columns.append(column)
        
        if text_columns:
            search_conditions = [
                column.ilike(f'%{search_term}%') for column in text_columns
            ]
            query = query.filter(or_(*search_conditions))
        
        return query

