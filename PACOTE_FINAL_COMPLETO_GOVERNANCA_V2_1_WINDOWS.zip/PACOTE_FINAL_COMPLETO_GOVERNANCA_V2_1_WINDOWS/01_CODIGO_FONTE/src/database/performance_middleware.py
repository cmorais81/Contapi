"""
Middleware de Performance para Monitoramento Automático
Desenvolvido por Carlos Morais
"""

import time
import asyncio
from typing import Optional, Dict, Any
from contextlib import asynccontextmanager

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.engine.events import event
from sqlalchemy.engine import Engine
from sqlalchemy.pool import Pool

from src.database.query_optimizer import query_monitor
from monitoring.audit_logger import audit_logger, EventType, Severity


class DatabasePerformanceMiddleware:
    """Middleware para monitoramento automático de performance do banco"""
    
    def __init__(self):
        self.query_times = {}
        self.connection_metrics = {}
        self.enabled = True
    
    def setup_event_listeners(self, engine: Engine):
        """Configura listeners de eventos do SQLAlchemy"""
        
        @event.listens_for(engine, "before_cursor_execute")
        def before_cursor_execute(conn, cursor, statement, parameters, context, executemany):
            """Captura início da execução da query"""
            if self.enabled:
                context._query_start_time = time.time()
                context._query_statement = statement
                context._query_parameters = parameters
        
        @event.listens_for(engine, "after_cursor_execute")
        def after_cursor_execute(conn, cursor, statement, parameters, context, executemany):
            """Captura fim da execução da query"""
            if self.enabled and hasattr(context, '_query_start_time'):
                execution_time = time.time() - context._query_start_time
                execution_time_ms = int(execution_time * 1000)
                
                # Log assíncrono da performance
                asyncio.create_task(self._log_query_performance(
                    statement=statement,
                    parameters=parameters,
                    execution_time_ms=execution_time_ms,
                    rows_affected=cursor.rowcount if hasattr(cursor, 'rowcount') else None
                ))
        
        @event.listens_for(engine, "connect")
        def on_connect(dbapi_connection, connection_record):
            """Monitora conexões"""
            if self.enabled:
                connection_id = id(dbapi_connection)
                self.connection_metrics[connection_id] = {
                    'connected_at': time.time(),
                    'queries_executed': 0
                }
        
        @event.listens_for(engine, "close")
        def on_close(dbapi_connection, connection_record):
            """Monitora fechamento de conexões"""
            if self.enabled:
                connection_id = id(dbapi_connection)
                if connection_id in self.connection_metrics:
                    metrics = self.connection_metrics.pop(connection_id)
                    connection_duration = time.time() - metrics['connected_at']
                    
                    # Log de conexão longa
                    if connection_duration > 300:  # 5 minutos
                        asyncio.create_task(self._log_long_connection(
                            connection_duration=connection_duration,
                            queries_executed=metrics['queries_executed']
                        ))
        
        @event.listens_for(Pool, "connect")
        def on_pool_connect(dbapi_connection, connection_record):
            """Monitora pool de conexões"""
            if self.enabled:
                pool = connection_record.info.get('pool')
                if pool:
                    asyncio.create_task(self._log_pool_metrics(pool))
    
    async def _log_query_performance(
        self,
        statement: str,
        parameters: Optional[Dict[str, Any]],
        execution_time_ms: int,
        rows_affected: Optional[int]
    ):
        """Log assíncrono da performance da query"""
        
        try:
            # Filtrar queries de sistema/monitoramento
            if self._should_skip_query(statement):
                return
            
            # Log da performance
            await query_monitor.log_query_performance(
                query_text=statement,
                execution_time_ms=execution_time_ms,
                rows_returned=rows_affected,
                endpoint=None,  # Seria obtido do contexto da requisição
                user_id=None   # Seria obtido do contexto da requisição
            )
            
        except Exception as e:
            # Não falhar a aplicação por erro de log
            print(f"Error logging query performance: {e}")
    
    async def _log_long_connection(
        self,
        connection_duration: float,
        queries_executed: int
    ):
        """Log de conexões que ficaram abertas por muito tempo"""
        
        try:
            await audit_logger.log_event(
                event_type=EventType.SYSTEM_EVENT,
                resource_type="database_connection",
                additional_metadata={
                    "connection_duration_seconds": round(connection_duration, 2),
                    "queries_executed": queries_executed,
                    "avg_time_per_query": round(connection_duration / max(queries_executed, 1), 2)
                },
                severity=Severity.WARN,
                tags=["database", "long_connection"]
            )
            
        except Exception as e:
            print(f"Error logging long connection: {e}")
    
    async def _log_pool_metrics(self, pool):
        """Log das métricas do pool de conexões"""
        
        try:
            # Obter métricas do pool
            pool_metrics = {
                "size": pool.size(),
                "checked_in": pool.checkedin(),
                "checked_out": pool.checkedout(),
                "overflow": pool.overflow(),
                "invalid": pool.invalid()
            }
            
            # Log apenas se houver problemas
            utilization = (pool_metrics["checked_out"] / max(pool_metrics["size"], 1)) * 100
            
            if utilization > 80:  # Pool com alta utilização
                await audit_logger.log_event(
                    event_type=EventType.SYSTEM_EVENT,
                    resource_type="connection_pool",
                    additional_metadata={
                        "pool_metrics": pool_metrics,
                        "utilization_percent": round(utilization, 2)
                    },
                    severity=Severity.WARN if utilization > 90 else Severity.INFO,
                    tags=["database", "pool_utilization"]
                )
                
        except Exception as e:
            print(f"Error logging pool metrics: {e}")
    
    def _should_skip_query(self, statement: str) -> bool:
        """Determina se deve pular o log da query"""
        
        statement_upper = statement.upper().strip()
        
        # Pular queries de sistema
        skip_patterns = [
            "SELECT 1",
            "SHOW ",
            "DESCRIBE ",
            "EXPLAIN ",
            "SELECT VERSION()",
            "SELECT CURRENT_",
            "INSERT INTO audit_logs",
            "INSERT INTO query_performance_logs",
            "SELECT FROM audit_logs",
            "SELECT FROM query_performance_logs"
        ]
        
        return any(pattern in statement_upper for pattern in skip_patterns)
    
    def enable(self):
        """Habilita o monitoramento"""
        self.enabled = True
    
    def disable(self):
        """Desabilita o monitoramento"""
        self.enabled = False


class QueryExecutionContext:
    """Contexto para execução de queries com monitoramento"""
    
    def __init__(
        self,
        session: AsyncSession,
        endpoint: Optional[str] = None,
        user_id: Optional[str] = None,
        enable_monitoring: bool = True
    ):
        self.session = session
        self.endpoint = endpoint
        self.user_id = user_id
        self.enable_monitoring = enable_monitoring
        self.start_time = None
        self.query_count = 0
    
    @asynccontextmanager
    async def execute_with_monitoring(self):
        """Context manager para execução com monitoramento"""
        
        if self.enable_monitoring:
            self.start_time = time.time()
            self.query_count = 0
        
        try:
            yield self
        finally:
            if self.enable_monitoring and self.start_time:
                total_time = time.time() - self.start_time
                
                # Log de operação longa
                if total_time > 5.0:  # 5 segundos
                    await audit_logger.log_event(
                        event_type=EventType.SYSTEM_EVENT,
                        resource_type="database_operation",
                        user_id=self.user_id,
                        additional_metadata={
                            "endpoint": self.endpoint,
                            "total_execution_time_seconds": round(total_time, 2),
                            "queries_executed": self.query_count
                        },
                        severity=Severity.WARN,
                        tags=["database", "long_operation"]
                    )
    
    async def execute_query(self, query, **kwargs):
        """Executa query com monitoramento"""
        
        if self.enable_monitoring:
            start_time = time.time()
            self.query_count += 1
        
        try:
            result = await self.session.execute(query, **kwargs)
            
            if self.enable_monitoring:
                execution_time_ms = int((time.time() - start_time) * 1000)
                
                # Log da performance
                await query_monitor.log_query_performance(
                    query_text=str(query),
                    execution_time_ms=execution_time_ms,
                    endpoint=self.endpoint,
                    user_id=self.user_id,
                    session=self.session
                )
            
            return result
            
        except Exception as e:
            if self.enable_monitoring:
                execution_time_ms = int((time.time() - start_time) * 1000)
                
                # Log de erro
                await audit_logger.log_event(
                    event_type=EventType.SYSTEM_EVENT,
                    resource_type="database_query",
                    user_id=self.user_id,
                    additional_metadata={
                        "endpoint": self.endpoint,
                        "query": str(query)[:500],
                        "execution_time_ms": execution_time_ms,
                        "error": str(e)
                    },
                    severity=Severity.ERROR,
                    tags=["database", "query_error"]
                )
            
            raise


# Instância global do middleware
db_performance_middleware = DatabasePerformanceMiddleware()


# Decorator para monitoramento automático
def monitor_query_performance(endpoint: Optional[str] = None):
    """Decorator para monitoramento automático de performance"""
    
    def decorator(func):
        async def wrapper(*args, **kwargs):
            # Tentar extrair sessão e user_id dos argumentos
            session = None
            user_id = None
            
            for arg in args:
                if isinstance(arg, AsyncSession):
                    session = arg
                    break
            
            # Procurar nos kwargs
            if not session:
                session = kwargs.get('session')
            
            user_id = kwargs.get('user_id') or kwargs.get('current_user_id')
            
            if session and db_performance_middleware.enabled:
                context = QueryExecutionContext(
                    session=session,
                    endpoint=endpoint,
                    user_id=user_id
                )
                
                async with context.execute_with_monitoring():
                    return await func(*args, **kwargs)
            else:
                return await func(*args, **kwargs)
        
        return wrapper
    return decorator

