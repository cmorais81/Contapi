"""
Modelos de Sistema e Performance
API de Governança de Dados V1.2
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from sqlalchemy import Column, String, Boolean, Integer, DateTime, Text, ForeignKey, Float
from sqlalchemy.dialects.postgresql import UUID, INET, JSONB
from sqlalchemy.orm import relationship
from ..base import Base

class QueryPerformanceLog(Base):
    """Log de performance de queries do sistema"""
    __tablename__ = 'query_performance_logs'
    __table_args__ = {'extend_existing': True}
    
    query_hash = Column(String(64), nullable=False, comment='Hash MD5 da query para agrupamento')
    query_text = Column(Text, comment='Texto completo da query (truncado se muito longo)')
    query_type = Column(String(20), nullable=False, comment='Tipo da query (SELECT, INSERT, UPDATE, DELETE)')
    table_name = Column(String(100), comment='Tabela principal da query')
    
    # Métricas de performance
    execution_time_ms = Column(Float, nullable=False, comment='Tempo de execução em milissegundos')
    rows_affected = Column(Integer, comment='Número de linhas afetadas')
    rows_examined = Column(Integer, comment='Número de linhas examinadas')
    cpu_time_ms = Column(Float, comment='Tempo de CPU em milissegundos')
    io_reads = Column(Integer, comment='Número de leituras de I/O')
    io_writes = Column(Integer, comment='Número de escritas de I/O')
    memory_used_mb = Column(Float, comment='Memória utilizada em MB')
    
    # Contexto da execução
    user_id = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Usuário que executou a query')
    session_id = Column(UUID(as_uuid=True), ForeignKey('user_sessions.id'), comment='Sessão onde foi executada')
    endpoint = Column(String(200), comment='Endpoint da API que gerou a query')
    request_id = Column(String(100), comment='ID da requisição')
    
    # Status e erro
    status = Column(String(20), default='success', comment='Status da execução (success, error, timeout)')
    error_message = Column(Text, comment='Mensagem de erro se aplicável')
    error_code = Column(String(20), comment='Código do erro')
    
    # Relacionamentos
    user = relationship("User", foreign_keys=[user_id])
    session = relationship("UserSession", foreign_keys=[session_id])

class SystemMetrics(Base):
    """Métricas gerais do sistema"""
    __tablename__ = 'system_metrics'
    __table_args__ = {'extend_existing': True}
    
    metric_name = Column(String(100), nullable=False, comment='Nome da métrica')
    metric_type = Column(String(20), nullable=False, comment='Tipo da métrica (gauge, counter, histogram)')
    metric_value = Column(Float, nullable=False, comment='Valor da métrica')
    metric_unit = Column(String(20), comment='Unidade da métrica (ms, mb, count, etc)')
    
    # Contexto
    component = Column(String(50), comment='Componente do sistema')
    instance = Column(String(100), comment='Instância específica')
    environment = Column(String(20), comment='Ambiente (dev, staging, prod)')
    
    # Tags adicionais
    tags = Column(JSONB, comment='Tags adicionais em formato JSON')
    
    # Agregação temporal
    aggregation_period = Column(String(20), comment='Período de agregação (1m, 5m, 1h, 1d)')
    period_start = Column(DateTime(timezone=True), comment='Início do período')
    period_end = Column(DateTime(timezone=True), comment='Fim do período')

class SystemHealth(Base):
    """Status de saúde dos componentes do sistema"""
    __tablename__ = 'system_health'
    __table_args__ = {'extend_existing': True}
    
    component = Column(String(50), nullable=False, comment='Nome do componente')
    instance = Column(String(100), comment='Instância específica do componente')
    status = Column(String(20), nullable=False, comment='Status (healthy, degraded, unhealthy)')
    
    # Métricas de saúde
    response_time_ms = Column(Float, comment='Tempo de resposta em ms')
    cpu_usage_percent = Column(Float, comment='Uso de CPU em percentual')
    memory_usage_percent = Column(Float, comment='Uso de memória em percentual')
    disk_usage_percent = Column(Float, comment='Uso de disco em percentual')
    
    # Conectividade
    database_connected = Column(Boolean, comment='Conexão com banco de dados')
    external_services_connected = Column(Boolean, comment='Conexão com serviços externos')
    
    # Detalhes adicionais
    details = Column(JSONB, comment='Detalhes adicionais do status')
    error_message = Column(Text, comment='Mensagem de erro se aplicável')
    
    # Timestamps
    last_check = Column(DateTime(timezone=True), comment='Última verificação')
    status_since = Column(DateTime(timezone=True), comment='Status desde quando')

class SystemConfiguration(Base):
    """Configurações do sistema"""
    __tablename__ = 'system_configurations'
    __table_args__ = {'extend_existing': True}
    
    key = Column(String(100), unique=True, nullable=False, comment='Chave da configuração')
    value = Column(Text, comment='Valor da configuração')
    value_type = Column(String(20), default='string', comment='Tipo do valor (string, int, float, bool, json)')
    category = Column(String(50), comment='Categoria da configuração')
    description = Column(Text, comment='Descrição da configuração')
    
    # Controle
    is_sensitive = Column(Boolean, default=False, comment='Se é uma configuração sensível')
    is_readonly = Column(Boolean, default=False, comment='Se é somente leitura')
    requires_restart = Column(Boolean, default=False, comment='Se requer reinicialização')
    
    # Validação
    validation_regex = Column(String(200), comment='Regex para validação do valor')
    allowed_values = Column(JSONB, comment='Valores permitidos')
    min_value = Column(Float, comment='Valor mínimo (para números)')
    max_value = Column(Float, comment='Valor máximo (para números)')
    
    # Auditoria
    modified_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Usuário que modificou')
    modified_at = Column(DateTime(timezone=True), comment='Data da modificação')
    
    # Relacionamentos
    modified_by_user = relationship("User", foreign_keys=[modified_by])

class SystemAlert(Base):
    """Alertas do sistema"""
    __tablename__ = 'system_alerts'
    __table_args__ = {'extend_existing': True}
    
    alert_type = Column(String(50), nullable=False, comment='Tipo do alerta')
    severity = Column(String(20), nullable=False, comment='Severidade (low, medium, high, critical)')
    title = Column(String(200), nullable=False, comment='Título do alerta')
    message = Column(Text, nullable=False, comment='Mensagem detalhada')
    
    # Contexto
    component = Column(String(50), comment='Componente relacionado')
    resource_type = Column(String(50), comment='Tipo de recurso')
    resource_id = Column(String, comment='ID do recurso')
    
    # Status
    status = Column(String(20), default='active', comment='Status (active, acknowledged, resolved)')
    acknowledged_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Usuário que reconheceu')
    acknowledged_at = Column(DateTime(timezone=True), comment='Data do reconhecimento')
    resolved_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Usuário que resolveu')
    resolved_at = Column(DateTime(timezone=True), comment='Data da resolução')
    
    # Dados adicionais
    entity_metadata = Column(JSONB, comment='Metadados adicionais do alerta')
    
    # Relacionamentos
    acknowledged_by_user = relationship("User", foreign_keys=[acknowledged_by])
    resolved_by_user = relationship("User", foreign_keys=[resolved_by])


class LoadBalancerMetrics(Base):
    """Métricas de load balancer e distribuição de carga"""
    __tablename__ = 'load_balancer_metrics'
    __table_args__ = {'extend_existing': True}
    
    # Identificação do load balancer
    load_balancer_name = Column(String(100), nullable=False, comment='Nome do load balancer')
    instance_id = Column(String(100), comment='ID da instância do load balancer')
    region = Column(String(50), comment='Região onde está o load balancer')
    availability_zone = Column(String(50), comment='Zona de disponibilidade')
    
    # Métricas de tráfego
    requests_per_second = Column(Float, comment='Requisições por segundo')
    active_connections = Column(Integer, comment='Conexões ativas')
    new_connections_per_second = Column(Float, comment='Novas conexões por segundo')
    bytes_in_per_second = Column(Float, comment='Bytes de entrada por segundo')
    bytes_out_per_second = Column(Float, comment='Bytes de saída por segundo')
    
    # Métricas de latência
    avg_response_time_ms = Column(Float, comment='Tempo médio de resposta em ms')
    p50_response_time_ms = Column(Float, comment='Percentil 50 do tempo de resposta')
    p95_response_time_ms = Column(Float, comment='Percentil 95 do tempo de resposta')
    p99_response_time_ms = Column(Float, comment='Percentil 99 do tempo de resposta')
    
    # Métricas de saúde
    healthy_targets = Column(Integer, comment='Número de targets saudáveis')
    unhealthy_targets = Column(Integer, comment='Número de targets não saudáveis')
    target_response_time_ms = Column(Float, comment='Tempo de resposta dos targets')
    
    # Métricas de erro
    http_2xx_count = Column(Integer, comment='Contagem de respostas 2xx')
    http_3xx_count = Column(Integer, comment='Contagem de respostas 3xx')
    http_4xx_count = Column(Integer, comment='Contagem de respostas 4xx')
    http_5xx_count = Column(Integer, comment='Contagem de respostas 5xx')
    error_rate_percent = Column(Float, comment='Taxa de erro em percentual')
    
    # Métricas de capacidade
    cpu_utilization_percent = Column(Float, comment='Utilização de CPU em percentual')
    memory_utilization_percent = Column(Float, comment='Utilização de memória em percentual')
    network_utilization_percent = Column(Float, comment='Utilização de rede em percentual')
    
    # Configuração e status
    max_connections = Column(Integer, comment='Máximo de conexões configurado')
    timeout_seconds = Column(Integer, comment='Timeout configurado em segundos')
    health_check_interval_seconds = Column(Integer, comment='Intervalo de health check')
    status = Column(String(20), default='active', comment='Status do load balancer')
    
    # Metadados
    configuration = Column(JSONB, comment='Configuração detalhada do load balancer')
    tags = Column(JSONB, comment='Tags do load balancer')
    
    # Auditoria
    author = Column(String(100), default='Carlos Morais', comment='Autor do registro')
    email = Column(String(100), default='carlos.morais@f1rst.com.br', comment='Email do autor')
    organization = Column(String(100), default='F1rst', comment='Organização')

class SystemHealth(Base):
    """Status de saúde geral do sistema"""
    __tablename__ = 'system_health'
    __table_args__ = {'extend_existing': True}
    
    # Identificação do componente
    component_name = Column(String(100), nullable=False, comment='Nome do componente')
    component_type = Column(String(50), nullable=False, comment='Tipo do componente')
    service_name = Column(String(100), comment='Nome do serviço')
    
    # Status de saúde
    health_status = Column(String(20), nullable=False, comment='Status de saúde (healthy, degraded, unhealthy)')
    availability_percent = Column(Float, comment='Percentual de disponibilidade')
    uptime_seconds = Column(Integer, comment='Tempo de atividade em segundos')
    last_restart = Column(DateTime, comment='Último restart do componente')
    
    # Métricas de performance
    response_time_ms = Column(Float, comment='Tempo de resposta em ms')
    throughput_per_second = Column(Float, comment='Throughput por segundo')
    error_rate_percent = Column(Float, comment='Taxa de erro em percentual')
    
    # Recursos utilizados
    cpu_usage_percent = Column(Float, comment='Uso de CPU em percentual')
    memory_usage_percent = Column(Float, comment='Uso de memória em percentual')
    disk_usage_percent = Column(Float, comment='Uso de disco em percentual')
    network_usage_mbps = Column(Float, comment='Uso de rede em Mbps')
    
    # Dependências
    dependencies_healthy = Column(Integer, comment='Número de dependências saudáveis')
    dependencies_total = Column(Integer, comment='Total de dependências')
    critical_dependencies_down = Column(Integer, comment='Dependências críticas indisponíveis')
    
    # Alertas e incidentes
    active_alerts = Column(Integer, comment='Número de alertas ativos')
    critical_alerts = Column(Integer, comment='Número de alertas críticos')
    last_incident = Column(DateTime, comment='Último incidente registrado')
    
    # Configuração
    health_check_url = Column(String(500), comment='URL do health check')
    health_check_interval_seconds = Column(Integer, comment='Intervalo de verificação')
    timeout_seconds = Column(Integer, comment='Timeout para health check')
    
    # Metadados
    environment = Column(String(50), comment='Ambiente (dev, staging, prod)')
    version = Column(String(50), comment='Versão do componente')
    deployment_id = Column(String(100), comment='ID do deployment')
    
    # Auditoria
    author = Column(String(100), default='Carlos Morais', comment='Autor do registro')
    email = Column(String(100), default='carlos.morais@f1rst.com.br', comment='Email do autor')
    organization = Column(String(100), default='F1rst', comment='Organização')

