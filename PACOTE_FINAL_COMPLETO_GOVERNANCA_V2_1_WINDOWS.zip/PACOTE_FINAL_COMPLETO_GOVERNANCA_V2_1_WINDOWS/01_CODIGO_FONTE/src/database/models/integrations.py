"""
Modelos de Integrações Externas
API de Governança de Dados V2.1
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from sqlalchemy import Column, String, Text, Boolean, Integer, DateTime, ForeignKey, Enum as SQLEnum, Float
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import relationship
from enum import Enum
from ..base import Base

class IntegrationType(Enum):
    UNITY_CATALOG = "unity_catalog"
    INFORMATICA_AXON = "informatica_axon"
    DATAHUB = "datahub"
    DATA_CONTRACT_MANAGER = "data_contract_manager"
    CUSTOM = "custom"

class IntegrationStatus(Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    ERROR = "error"
    CONFIGURING = "configuring"
    TESTING = "testing"

class SyncStatus(Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"

class SyncDirection(Enum):
    INBOUND = "inbound"
    OUTBOUND = "outbound"
    BIDIRECTIONAL = "bidirectional"

class ExternalIntegration(Base):
    """Configurações de integrações com sistemas externos"""
    __tablename__ = 'external_integrations'
    __table_args__ = {'extend_existing': True}
    
    name = Column(String(255), nullable=False, comment='Nome da integração')
    integration_type = Column(SQLEnum(IntegrationType), nullable=False, comment='Tipo de integração')
    description = Column(Text, comment='Descrição da integração')
    
    # Configurações de conexão
    endpoint_url = Column(String(500), comment='URL do endpoint da API')
    authentication_config = Column(JSONB, comment='Configurações de autenticação')
    connection_config = Column(JSONB, comment='Configurações de conexão')
    
    # Status e controle
    status = Column(SQLEnum(IntegrationStatus), default=IntegrationStatus.INACTIVE, comment='Status da integração')
    is_enabled = Column(Boolean, default=False, comment='Integração habilitada')
    
    # Configurações de sincronização
    sync_frequency = Column(String(100), comment='Frequência de sincronização (cron expression)')
    sync_direction = Column(SQLEnum(SyncDirection), default=SyncDirection.INBOUND, comment='Direção da sincronização')
    batch_size = Column(Integer, default=1000, comment='Tamanho do lote para sincronização')
    
    # Configurações específicas
    entity_filters = Column(JSONB, comment='Filtros para entidades a sincronizar')
    field_mappings = Column(JSONB, comment='Mapeamentos de campos')
    transformation_rules = Column(JSONB, comment='Regras de transformação')
    
    # Metadados
    created_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), nullable=False, comment='Usuário que criou')
    last_sync_at = Column(DateTime(timezone=True), comment='Última sincronização')
    next_sync_at = Column(DateTime(timezone=True), comment='Próxima sincronização')
    
    # Estatísticas
    total_syncs = Column(Integer, default=0, comment='Total de sincronizações')
    successful_syncs = Column(Integer, default=0, comment='Sincronizações bem-sucedidas')
    failed_syncs = Column(Integer, default=0, comment='Sincronizações falhadas')
    
    # Relacionamentos
    creator = relationship("User", foreign_keys=[created_by])
    mappings = relationship("IntegrationMapping", back_populates="integration", cascade="all, delete-orphan")
    sync_jobs = relationship("SyncJob", back_populates="integration", cascade="all, delete-orphan")

class IntegrationMapping(Base):
    """Mapeamentos de campos entre sistemas"""
    __tablename__ = 'integration_mappings'
    __table_args__ = {'extend_existing': True}
    
    integration_id = Column(UUID(as_uuid=True), ForeignKey('external_integrations.id'), nullable=False)
    
    # Mapeamento de campos
    source_field = Column(String(255), nullable=False, comment='Campo no sistema de origem')
    target_field = Column(String(255), nullable=False, comment='Campo no sistema de destino')
    source_entity = Column(String(255), comment='Entidade no sistema de origem')
    target_entity = Column(String(255), comment='Entidade no sistema de destino')
    
    # Configurações de transformação
    transformation_function = Column(String(255), comment='Função de transformação')
    transformation_config = Column(JSONB, comment='Configuração da transformação')
    default_value = Column(Text, comment='Valor padrão se campo não existir')
    
    # Validações
    is_required = Column(Boolean, default=False, comment='Campo obrigatório')
    validation_rules = Column(JSONB, comment='Regras de validação')
    data_type = Column(String(100), comment='Tipo de dados esperado')
    
    # Metadados
    is_active = Column(Boolean, default=True, comment='Mapeamento ativo')
    priority = Column(Integer, default=0, comment='Prioridade do mapeamento')
    
    # Relacionamentos
    integration = relationship("ExternalIntegration", back_populates="mappings")

class SyncJob(Base):
    """Jobs de sincronização de dados"""
    __tablename__ = 'sync_jobs'
    __table_args__ = {'extend_existing': True}
    
    integration_id = Column(UUID(as_uuid=True), ForeignKey('external_integrations.id'), nullable=False)
    
    # Identificação do job
    job_name = Column(String(255), comment='Nome do job')
    job_type = Column(String(100), comment='Tipo do job (full_sync, incremental, etc.)')
    
    # Status e execução
    status = Column(SQLEnum(SyncStatus), default=SyncStatus.PENDING, comment='Status do job')
    started_at = Column(DateTime(timezone=True), comment='Data de início')
    completed_at = Column(DateTime(timezone=True), comment='Data de conclusão')
    
    # Configurações do job
    sync_config = Column(JSONB, comment='Configuração específica do job')
    filters = Column(JSONB, comment='Filtros aplicados')
    
    # Resultados
    records_processed = Column(Integer, default=0, comment='Registros processados')
    records_created = Column(Integer, default=0, comment='Registros criados')
    records_updated = Column(Integer, default=0, comment='Registros atualizados')
    records_deleted = Column(Integer, default=0, comment='Registros deletados')
    records_failed = Column(Integer, default=0, comment='Registros com falha')
    
    # Logs e erros
    execution_log = Column(JSONB, comment='Log de execução')
    error_details = Column(Text, comment='Detalhes de erros')
    warnings = Column(JSONB, comment='Avisos durante execução')
    
    # Performance
    duration_seconds = Column(Integer, comment='Duração em segundos')
    memory_usage_mb = Column(Float, comment='Uso de memória em MB')
    
    # Metadados
    triggered_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Usuário que disparou')
    trigger_type = Column(String(50), comment='Tipo de disparo (manual, scheduled, event)')
    
    # Relacionamentos
    integration = relationship("ExternalIntegration", back_populates="sync_jobs")
    trigger_user = relationship("User", foreign_keys=[triggered_by])

