"""
Modelos de Auditoria e Log de Ações
API de Governança de Dados V1.2
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from sqlalchemy import Column, String, Boolean, Integer, DateTime, Text, ForeignKey, Float
from sqlalchemy.dialects.postgresql import UUID, INET, JSONB
from sqlalchemy.orm import relationship
from ..base import Base

class AuditLog(Base):
    """Log de auditoria de todas as ações do sistema"""
    __tablename__ = 'audit_logs'
    __table_args__ = {'extend_existing': True}
    
    user_id = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Usuário que executou a ação')
    session_id = Column(UUID(as_uuid=True), ForeignKey('user_sessions.id'), comment='Sessão onde a ação foi executada')
    action = Column(String(100), nullable=False, comment='Tipo de ação executada')
    resource_type = Column(String(50), comment='Tipo de recurso afetado')
    resource_id = Column(String, comment='ID do recurso afetado')
    resource_name = Column(String(255), comment='Nome do recurso afetado')
    details = Column(JSONB, comment='Detalhes da ação em formato JSON')
    old_values = Column(JSONB, comment='Valores anteriores (para updates)')
    new_values = Column(JSONB, comment='Novos valores (para updates)')
    ip_address = Column(INET, comment='Endereço IP de origem')
    user_agent = Column(Text, comment='Informações do cliente/navegador')
    request_id = Column(String(100), comment='ID único da requisição')
    execution_time_ms = Column(Float, comment='Tempo de execução em milissegundos')
    status = Column(String(20), default='success', comment='Status da ação (success, error, warning)')
    error_message = Column(Text, comment='Mensagem de erro se aplicável')
    
    # Relacionamentos
    user = relationship("User", foreign_keys=[user_id])
    session = relationship("UserSession", foreign_keys=[session_id])

class AuditRule(Base):
    """Regras de auditoria configuráveis"""
    __tablename__ = 'audit_rules'
    __table_args__ = {'extend_existing': True}
    
    name = Column(String(100), unique=True, nullable=False, comment='Nome da regra de auditoria')
    description = Column(Text, comment='Descrição da regra')
    resource_types = Column(JSONB, comment='Tipos de recursos a auditar')
    actions = Column(JSONB, comment='Ações a auditar')
    conditions = Column(JSONB, comment='Condições para aplicar a regra')
    retention_days = Column(Integer, default=365, comment='Dias para manter os logs')
    is_active = Column(Boolean, default=True, comment='Status ativo/inativo da regra')
    alert_on_violation = Column(Boolean, default=False, comment='Alertar em caso de violação')
    alert_recipients = Column(JSONB, comment='Destinatários dos alertas')

class ComplianceReport(Base):
    """Relatórios de compliance e auditoria"""
    __tablename__ = 'compliance_reports'
    __table_args__ = {'extend_existing': True}
    
    name = Column(String(100), nullable=False, comment='Nome do relatório')
    report_type = Column(String(50), nullable=False, comment='Tipo de relatório (LGPD, SOX, etc)')
    period_start = Column(DateTime(timezone=True), nullable=False, comment='Início do período do relatório')
    period_end = Column(DateTime(timezone=True), nullable=False, comment='Fim do período do relatório')
    generated_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Usuário que gerou o relatório')
    status = Column(String(20), default='pending', comment='Status do relatório')
    findings = Column(JSONB, comment='Achados e violações encontradas')
    recommendations = Column(JSONB, comment='Recomendações de melhoria')
    file_path = Column(String(500), comment='Caminho do arquivo do relatório')
    file_size = Column(Integer, comment='Tamanho do arquivo em bytes')
    
    # Relacionamentos
    generated_by_user = relationship("User", foreign_keys=[generated_by])

class DataAccessLog(Base):
    """Log específico de acesso a dados sensíveis"""
    __tablename__ = 'data_access_logs'
    __table_args__ = {'extend_existing': True}
    
    user_id = Column(UUID(as_uuid=True), ForeignKey('users.id'), nullable=False)
    entity_id = Column(UUID(as_uuid=True), ForeignKey('entities.id'), comment='Entidade acessada')
    attribute_id = Column(UUID(as_uuid=True), ForeignKey('entity_attributes.id'), comment='Atributo específico acessado')
    access_type = Column(String(20), nullable=False, comment='Tipo de acesso (read, write, delete)')
    data_classification = Column(String(20), comment='Classificação dos dados (public, internal, confidential, restricted)')
    purpose = Column(Text, comment='Propósito do acesso aos dados')
    legal_basis = Column(String(50), comment='Base legal para o acesso (LGPD)')
    consent_id = Column(String(100), comment='ID do consentimento relacionado')
    retention_period = Column(Integer, comment='Período de retenção em dias')
    anonymized = Column(Boolean, default=False, comment='Dados foram anonimizados')
    masked = Column(Boolean, default=False, comment='Dados foram mascarados')
    
    # Relacionamentos
    user = relationship("User", foreign_keys=[user_id])
    entity = relationship("Entity", foreign_keys=[entity_id])
    attribute = relationship("EntityAttribute", foreign_keys=[attribute_id])


class AuditLogRetentionPolicy(Base):
    """Políticas de retenção de logs de auditoria"""
    __tablename__ = 'audit_log_retention_policies'
    __table_args__ = {'extend_existing': True}
    
    name = Column(String(100), unique=True, nullable=False, comment='Nome da política de retenção')
    description = Column(Text, comment='Descrição da política')
    resource_types = Column(JSONB, comment='Tipos de recursos cobertos pela política')
    retention_period_days = Column(Integer, nullable=False, comment='Período de retenção em dias')
    archive_after_days = Column(Integer, comment='Dias após os quais arquivar (opcional)')
    archive_location = Column(String(255), comment='Local de arquivamento')
    compression_enabled = Column(Boolean, default=True, comment='Habilitar compressão no arquivamento')
    encryption_enabled = Column(Boolean, default=True, comment='Habilitar criptografia no arquivamento')
    auto_delete_enabled = Column(Boolean, default=False, comment='Habilitar exclusão automática após retenção')
    compliance_requirements = Column(JSONB, comment='Requisitos de compliance (LGPD, SOX, etc.)')
    is_active = Column(Boolean, default=True, comment='Status ativo/inativo da política')
    priority = Column(Integer, default=100, comment='Prioridade da política (menor número = maior prioridade)')
    
class ComplianceReport(Base):
    """Relatórios de compliance e auditoria"""
    __tablename__ = 'compliance_reports'
    __table_args__ = {'extend_existing': True}
    
    name = Column(String(100), nullable=False, comment='Nome do relatório')
    report_type = Column(String(50), nullable=False, comment='Tipo do relatório (LGPD, SOX, ISO27001, etc.)')
    period_start = Column(DateTime, nullable=False, comment='Início do período do relatório')
    period_end = Column(DateTime, nullable=False, comment='Fim do período do relatório')
    generated_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Usuário que gerou o relatório')
    status = Column(String(20), default='draft', comment='Status do relatório (draft, final, approved)')
    findings = Column(JSONB, comment='Achados e observações do relatório')
    recommendations = Column(JSONB, comment='Recomendações de melhoria')
    risk_assessment = Column(JSONB, comment='Avaliação de riscos identificados')
    action_items = Column(JSONB, comment='Itens de ação requeridos')
    approval_date = Column(DateTime, comment='Data de aprovação do relatório')
    approved_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Usuário que aprovou o relatório')
    file_path = Column(String(500), comment='Caminho do arquivo do relatório')
    file_hash = Column(String(64), comment='Hash do arquivo para integridade')
    
    # Relacionamentos
    generated_by_user = relationship("User", foreign_keys=[generated_by])
    approved_by_user = relationship("User", foreign_keys=[approved_by])

class DataAccessLog(Base):
    """Log específico de acesso a dados sensíveis"""
    __tablename__ = 'data_access_logs'
    __table_args__ = {'extend_existing': True}
    
    user_id = Column(UUID(as_uuid=True), ForeignKey('users.id'), nullable=False, comment='Usuário que acessou os dados')
    entity_id = Column(UUID(as_uuid=True), ForeignKey('entities.id'), comment='Entidade acessada')
    data_classification = Column(String(50), comment='Classificação dos dados (public, internal, confidential, restricted)')
    access_type = Column(String(50), nullable=False, comment='Tipo de acesso (read, write, delete, export)')
    access_method = Column(String(100), comment='Método de acesso (API, UI, SQL, etc.)')
    query_executed = Column(Text, comment='Query ou comando executado')
    records_affected = Column(Integer, comment='Número de registros afetados')
    data_volume_bytes = Column(Integer, comment='Volume de dados acessados em bytes')
    purpose = Column(String(255), comment='Propósito do acesso aos dados')
    legal_basis = Column(String(100), comment='Base legal para o acesso (LGPD)')
    consent_id = Column(UUID(as_uuid=True), comment='ID do consentimento relacionado')
    ip_address = Column(INET, comment='Endereço IP de origem')
    location = Column(String(100), comment='Localização geográfica do acesso')
    device_info = Column(JSONB, comment='Informações do dispositivo')
    session_duration_seconds = Column(Integer, comment='Duração da sessão em segundos')
    risk_score = Column(Float, comment='Score de risco do acesso (0-100)')
    anomaly_detected = Column(Boolean, default=False, comment='Anomalia detectada no acesso')
    
    # Relacionamentos
    user = relationship("User", foreign_keys=[user_id])
    entity = relationship("Entity", foreign_keys=[entity_id])



class AuditLogArchive(Base):
    """Arquivo de logs de auditoria antigos"""
    __tablename__ = 'audit_log_archives'
    __table_args__ = {'extend_existing': True}
    
    original_log_id = Column(UUID(as_uuid=True), nullable=False, comment='ID do log original')
    user_id = Column(UUID(as_uuid=True), comment='Usuário que executou a ação')
    action = Column(String(100), nullable=False, comment='Tipo de ação executada')
    resource_type = Column(String(50), comment='Tipo de recurso afetado')
    resource_id = Column(String, comment='ID do recurso afetado')
    resource_name = Column(String(255), comment='Nome do recurso afetado')
    details = Column(JSONB, comment='Detalhes da ação em formato JSON')
    ip_address = Column(INET, comment='Endereço IP de origem')
    execution_time_ms = Column(Float, comment='Tempo de execução em milissegundos')
    status = Column(String(20), comment='Status da ação')
    error_message = Column(Text, comment='Mensagem de erro se aplicável')
    archived_at = Column(DateTime, nullable=False, comment='Data do arquivamento')
    archive_reason = Column(String(100), comment='Motivo do arquivamento')
    
class ComplianceReport(Base):
    """Relatórios de compliance gerados"""
    __tablename__ = 'compliance_reports'
    __table_args__ = {'extend_existing': True}
    
    name = Column(String(255), nullable=False, comment='Nome do relatório')
    report_type = Column(String(50), nullable=False, comment='Tipo de relatório (LGPD, GDPR, SOX, etc.)')
    period_start = Column(DateTime, nullable=False, comment='Início do período analisado')
    period_end = Column(DateTime, nullable=False, comment='Fim do período analisado')
    generated_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Usuário que gerou o relatório')
    status = Column(String(20), default='generating', comment='Status da geração')
    file_path = Column(String(500), comment='Caminho do arquivo gerado')
    file_size = Column(Integer, comment='Tamanho do arquivo em bytes')
    summary = Column(JSONB, comment='Resumo executivo do relatório')
    findings = Column(JSONB, comment='Achados e recomendações')
    
    # Relacionamentos
    generator = relationship("User", foreign_keys=[generated_by])

class DataAccessLog(Base):
    """Log específico de acesso a dados sensíveis"""
    __tablename__ = 'data_access_logs'
    __table_args__ = {'extend_existing': True}
    
    user_id = Column(UUID(as_uuid=True), ForeignKey('users.id'), nullable=False, comment='Usuário que acessou')
    entity_id = Column(UUID(as_uuid=True), ForeignKey('entities.id'), comment='Entidade acessada')
    access_type = Column(String(50), nullable=False, comment='Tipo de acesso (read, write, delete)')
    data_classification = Column(String(50), comment='Classificação dos dados acessados')
    purpose = Column(String(255), comment='Propósito do acesso')
    legal_basis = Column(String(100), comment='Base legal para o acesso')
    records_accessed = Column(Integer, comment='Número de registros acessados')
    fields_accessed = Column(JSONB, comment='Campos específicos acessados')
    ip_address = Column(INET, comment='Endereço IP de origem')
    location = Column(String(100), comment='Localização geográfica')
    device_info = Column(JSONB, comment='Informações do dispositivo')
    
    # Relacionamentos
    user = relationship("User", foreign_keys=[user_id])
    entity = relationship("Entity", foreign_keys=[entity_id])


class AuditLogRetentionPolicy(Base):
    """Políticas de retenção de logs de auditoria"""
    __tablename__ = 'audit_log_retention_policies'
    __table_args__ = {'extend_existing': True}
    
    name = Column(String(100), unique=True, nullable=False, comment='Nome da política')
    description = Column(Text, comment='Descrição da política')
    resource_types = Column(JSONB, comment='Tipos de recursos cobertos')
    retention_days = Column(Integer, nullable=False, comment='Dias de retenção')
    archive_after_days = Column(Integer, comment='Dias para arquivamento')
    delete_after_days = Column(Integer, comment='Dias para exclusão definitiva')
    is_active = Column(Boolean, default=True, comment='Status ativo/inativo')
    priority = Column(Integer, default=100, comment='Prioridade da política')
    compliance_requirements = Column(JSONB, comment='Requisitos de compliance')
    
class AuditAlert(Base):
    """Alertas de auditoria"""
    __tablename__ = 'audit_alerts'
    __table_args__ = {'extend_existing': True}
    
    name = Column(String(100), nullable=False, comment='Nome do alerta')
    description = Column(Text, comment='Descrição do alerta')
    alert_type = Column(String(50), nullable=False, comment='Tipo de alerta')
    conditions = Column(JSONB, nullable=False, comment='Condições para disparo')
    severity = Column(String(20), default='medium', comment='Severidade do alerta')
    recipients = Column(JSONB, comment='Destinatários do alerta')
    is_active = Column(Boolean, default=True, comment='Status ativo/inativo')
    last_triggered = Column(DateTime, comment='Última vez que foi disparado')
    trigger_count = Column(Integer, default=0, comment='Número de vezes disparado')

