"""
Modelos de Retenção e Expurgo de Dados
API de Governança de Dados V2.1
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from sqlalchemy import Column, String, Text, Boolean, Integer, DateTime, ForeignKey, Enum as SQLEnum
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import relationship
from enum import Enum
from ..base import Base

class RetentionType(Enum):
    TIME_BASED = "time_based"
    EVENT_BASED = "event_based"
    SIZE_BASED = "size_based"
    CUSTOM = "custom"

class RetentionStatus(Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    SUSPENDED = "suspended"
    EXPIRED = "expired"

class DeletionMethod(Enum):
    SOFT_DELETE = "soft_delete"
    HARD_DELETE = "hard_delete"
    ARCHIVE = "archive"
    ANONYMIZE = "anonymize"

class DeletionStatus(Enum):
    SCHEDULED = "scheduled"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"

class DataRetentionPolicy(Base):
    """Políticas de retenção de dados"""
    __tablename__ = 'data_retention_policies'
    __table_args__ = {'extend_existing': True}
    
    name = Column(String(255), nullable=False, comment='Nome da política de retenção')
    description = Column(Text, comment='Descrição da política')
    retention_type = Column(SQLEnum(RetentionType), nullable=False, comment='Tipo de retenção')
    
    # Configurações de retenção
    retention_period_days = Column(Integer, comment='Período de retenção em dias')
    retention_rules = Column(JSONB, comment='Regras específicas de retenção')
    
    # Escopo da política
    entity_filters = Column(JSONB, comment='Filtros de entidades aplicáveis')
    data_categories = Column(JSONB, comment='Categorias de dados aplicáveis')
    
    # Configurações de exclusão
    deletion_method = Column(SQLEnum(DeletionMethod), default=DeletionMethod.SOFT_DELETE, comment='Método de exclusão')
    archive_location = Column(String(500), comment='Local de arquivamento')
    
    # Exceções e condições especiais
    legal_hold_exceptions = Column(JSONB, comment='Exceções por retenção legal')
    business_exceptions = Column(JSONB, comment='Exceções de negócio')
    
    # Configurações de notificação
    notify_before_deletion = Column(Boolean, default=True, comment='Notificar antes da exclusão')
    notification_days_before = Column(Integer, default=30, comment='Dias antes para notificar')
    notification_recipients = Column(JSONB, comment='Destinatários das notificações')
    
    # Aprovação e compliance
    requires_approval = Column(Boolean, default=False, comment='Requer aprovação para exclusão')
    compliance_requirements = Column(JSONB, comment='Requisitos de compliance')
    
    # Status
    status = Column(SQLEnum(RetentionStatus), default=RetentionStatus.ACTIVE, comment='Status da política')
    
    # Metadados
    created_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), nullable=False, comment='Criador da política')
    approved_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Aprovador da política')
    approved_at = Column(DateTime(timezone=True), comment='Data de aprovação')
    
    # Execução
    last_execution = Column(DateTime(timezone=True), comment='Última execução')
    next_execution = Column(DateTime(timezone=True), comment='Próxima execução')
    
    # Relacionamentos
    creator = relationship("User", foreign_keys=[created_by])
    approver = relationship("User", foreign_keys=[approved_by])
    deletion_logs = relationship("DataDeletionLog", back_populates="policy", cascade="all, delete-orphan")

class DataDeletionLog(Base):
    """Logs de exclusão de dados"""
    __tablename__ = 'data_deletion_logs'
    __table_args__ = {'extend_existing': True}
    
    policy_id = Column(UUID(as_uuid=True), ForeignKey('data_retention_policies.id'), comment='Política aplicada')
    
    # Identificação da exclusão
    deletion_batch_id = Column(String(255), comment='ID do lote de exclusão')
    entity_id = Column(UUID(as_uuid=True), ForeignKey('entities.id'), comment='Entidade afetada')
    
    # Detalhes da exclusão
    deletion_method = Column(SQLEnum(DeletionMethod), nullable=False, comment='Método usado para exclusão')
    status = Column(SQLEnum(DeletionStatus), default=DeletionStatus.SCHEDULED, comment='Status da exclusão')
    
    # Dados excluídos
    records_identified = Column(Integer, comment='Registros identificados para exclusão')
    records_deleted = Column(Integer, comment='Registros efetivamente excluídos')
    records_failed = Column(Integer, comment='Registros que falharam na exclusão')
    
    # Metadados dos dados excluídos
    data_summary = Column(JSONB, comment='Resumo dos dados excluídos')
    deletion_criteria = Column(JSONB, comment='Critérios usados para identificar dados')
    
    # Execução
    scheduled_at = Column(DateTime(timezone=True), comment='Data agendada para exclusão')
    started_at = Column(DateTime(timezone=True), comment='Data de início da exclusão')
    completed_at = Column(DateTime(timezone=True), comment='Data de conclusão')
    
    # Aprovação (se necessária)
    approved_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Usuário que aprovou')
    approved_at = Column(DateTime(timezone=True), comment='Data de aprovação')
    approval_notes = Column(Text, comment='Notas da aprovação')
    
    # Execução
    executed_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Usuário que executou')
    execution_details = Column(JSONB, comment='Detalhes da execução')
    
    # Logs e erros
    execution_log = Column(JSONB, comment='Log detalhado da execução')
    error_details = Column(Text, comment='Detalhes de erros')
    
    # Auditoria e compliance
    legal_basis = Column(Text, comment='Base legal para exclusão')
    compliance_notes = Column(Text, comment='Notas de compliance')
    
    # Backup e recuperação
    backup_location = Column(String(500), comment='Local do backup antes da exclusão')
    recovery_possible = Column(Boolean, default=False, comment='Recuperação ainda possível')
    recovery_deadline = Column(DateTime(timezone=True), comment='Prazo limite para recuperação')
    
    # Relacionamentos
    policy = relationship("DataRetentionPolicy", back_populates="deletion_logs")
    entity = relationship("Entity")
    approver = relationship("User", foreign_keys=[approved_by])
    executor = relationship("User", foreign_keys=[executed_by])

