"""
Modelo de Domínios de Dados
API de Governança de Dados V2.2
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from sqlalchemy import Column, String, Text, Boolean, Integer, DateTime, ForeignKey, Enum as SQLEnum
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import relationship
from enum import Enum
from ..base import Base

class DomainType(Enum):
    BUSINESS = "business"      # Domínio de negócio
    TECHNICAL = "technical"    # Domínio técnico
    FUNCTIONAL = "functional"  # Domínio funcional
    GEOGRAPHIC = "geographic"  # Domínio geográfico
    REGULATORY = "regulatory"  # Domínio regulatório
    CUSTOM = "custom"         # Domínio customizado

class DomainStatus(Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    DEPRECATED = "deprecated"
    PLANNING = "planning"
    DEVELOPMENT = "development"

class GovernanceLevel(Enum):
    CENTRALIZED = "centralized"    # Governança centralizada
    FEDERATED = "federated"        # Governança federada
    DECENTRALIZED = "decentralized" # Governança descentralizada
    HYBRID = "hybrid"              # Governança híbrida

class Domain(Base):
    """Domínios de dados organizacionais"""
    __tablename__ = 'domains'
    __table_args__ = {'extend_existing': True}
    
    name = Column(String(255), nullable=False, unique=True, comment='Nome único do domínio')
    display_name = Column(String(255), comment='Nome de exibição do domínio')
    description = Column(Text, comment='Descrição do domínio')
    
    # Configurações do domínio
    domain_type = Column(SQLEnum(DomainType), nullable=False, comment='Tipo do domínio')
    status = Column(SQLEnum(DomainStatus), default=DomainStatus.ACTIVE, comment='Status do domínio')
    
    # Hierarquia
    parent_domain_id = Column(UUID(as_uuid=True), ForeignKey('domains.id'), comment='Domínio pai')
    level = Column(Integer, default=0, comment='Nível na hierarquia')
    path = Column(String(500), comment='Caminho hierárquico completo')
    
    # Responsabilidade
    domain_owner = Column(UUID(as_uuid=True), ForeignKey('users.id'), nullable=False, comment='Dono do domínio')
    technical_lead = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Líder técnico')
    business_lead = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Líder de negócio')
    
    # Configurações de governança
    governance_level = Column(SQLEnum(GovernanceLevel), default=GovernanceLevel.FEDERATED, comment='Nível de governança')
    governance_policies = Column(JSONB, comment='Políticas de governança específicas')
    data_classification_rules = Column(JSONB, comment='Regras de classificação de dados')
    
    # Configurações de acesso
    access_control_model = Column(String(100), comment='Modelo de controle de acesso')
    default_permissions = Column(JSONB, comment='Permissões padrão')
    approval_workflow = Column(JSONB, comment='Workflow de aprovação')
    
    # Configurações de qualidade
    quality_standards = Column(JSONB, comment='Padrões de qualidade do domínio')
    quality_thresholds = Column(JSONB, comment='Limites de qualidade')
    monitoring_rules = Column(JSONB, comment='Regras de monitoramento')
    
    # Configurações de compliance
    regulatory_requirements = Column(JSONB, comment='Requisitos regulatórios')
    compliance_frameworks = Column(JSONB, comment='Frameworks de compliance')
    audit_requirements = Column(JSONB, comment='Requisitos de auditoria')
    
    # Configurações de retenção
    default_retention_policy = Column(JSONB, comment='Política de retenção padrão')
    backup_requirements = Column(JSONB, comment='Requisitos de backup')
    archival_rules = Column(JSONB, comment='Regras de arquivamento')
    
    # Configurações de segurança
    security_classification = Column(String(100), comment='Classificação de segurança')
    encryption_requirements = Column(JSONB, comment='Requisitos de criptografia')
    masking_rules = Column(JSONB, comment='Regras de mascaramento')
    
    # Metadados de negócio
    business_purpose = Column(Text, comment='Propósito de negócio')
    business_context = Column(Text, comment='Contexto de negócio')
    key_stakeholders = Column(JSONB, comment='Principais stakeholders')
    
    # Configurações técnicas
    preferred_technologies = Column(JSONB, comment='Tecnologias preferidas')
    integration_patterns = Column(JSONB, comment='Padrões de integração')
    api_standards = Column(JSONB, comment='Padrões de API')
    
    # Configurações de custo
    budget_allocation = Column(JSONB, comment='Alocação de orçamento')
    cost_center = Column(String(100), comment='Centro de custo')
    cost_optimization_rules = Column(JSONB, comment='Regras de otimização de custo')
    
    # Métricas e KPIs
    success_metrics = Column(JSONB, comment='Métricas de sucesso')
    kpi_definitions = Column(JSONB, comment='Definições de KPIs')
    reporting_requirements = Column(JSONB, comment='Requisitos de relatórios')
    
    # Configurações de comunicação
    communication_channels = Column(JSONB, comment='Canais de comunicação')
    notification_preferences = Column(JSONB, comment='Preferências de notificação')
    escalation_matrix = Column(JSONB, comment='Matriz de escalação')
    
    # Documentação
    documentation_links = Column(JSONB, comment='Links para documentação')
    training_materials = Column(JSONB, comment='Materiais de treinamento')
    best_practices = Column(JSONB, comment='Melhores práticas')
    
    # Configurações de desenvolvimento
    development_standards = Column(JSONB, comment='Padrões de desenvolvimento')
    testing_requirements = Column(JSONB, comment='Requisitos de teste')
    deployment_procedures = Column(JSONB, comment='Procedimentos de deploy')
    
    # Status e estatísticas
    entity_count = Column(Integer, default=0, comment='Número de entidades no domínio')
    active_projects = Column(Integer, default=0, comment='Projetos ativos')
    health_score = Column(Integer, comment='Score de saúde do domínio (0-100)')
    
    # Configurações de migração
    migration_strategy = Column(JSONB, comment='Estratégia de migração')
    legacy_systems = Column(JSONB, comment='Sistemas legados')
    modernization_roadmap = Column(JSONB, comment='Roadmap de modernização')
    
    # Metadados
    created_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), nullable=False, comment='Criador do domínio')
    approved_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Aprovador do domínio')
    approved_at = Column(DateTime(timezone=True), comment='Data de aprovação')
    
    # Configurações visuais
    color_scheme = Column(String(50), comment='Esquema de cores')
    icon = Column(String(100), comment='Ícone do domínio')
    logo_url = Column(String(500), comment='URL do logo')
    
    # Relacionamentos
    parent_domain = relationship("Domain", remote_side="Domain.id", back_populates="child_domains")
    child_domains = relationship("Domain", back_populates="parent_domain", cascade="all, delete-orphan")
    
    domain_owner_user = relationship("User", foreign_keys=[domain_owner])
    technical_lead_user = relationship("User", foreign_keys=[technical_lead])
    business_lead_user = relationship("User", foreign_keys=[business_lead])
    creator = relationship("User", foreign_keys=[created_by])
    approver = relationship("User", foreign_keys=[approved_by])

