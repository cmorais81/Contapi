"""
Factory para geração de dados mocados realistas
"""
import random
import uuid
from datetime import datetime, timedelta
from typing import List, Dict, Any
from faker import Faker

fake = Faker('pt_BR')


class MockDataFactory:
    """Factory para criação de dados mocados"""
    
    @staticmethod
    def create_users(count: int = 10) -> List[Dict[str, Any]]:
        """Cria usuários mocados"""
        users = []
        for i in range(count):
            users.append({
                'id': str(uuid.uuid4()),
                'username': fake.user_name(),
                'email': fake.email(),
                'full_name': fake.name(),
                'is_active': random.choice([True, True, True, False]),  # 75% ativos
                'is_superuser': random.choice([True, False, False, False]),  # 25% superuser
                'created_at': fake.date_time_between(start_date='-2y', end_date='now'),
                'updated_at': fake.date_time_between(start_date='-1y', end_date='now')
            })
        return users
    
    @staticmethod
    def create_data_contracts(count: int = 20) -> List[Dict[str, Any]]:
        """Cria contratos de dados mocados"""
        contracts = []
        statuses = ['draft', 'active', 'deprecated', 'archived']
        contract_types = ['api', 'dataset', 'stream', 'batch']
        
        for i in range(count):
            created_at = fake.date_time_between(start_date='-1y', end_date='now')
            contracts.append({
                'id': str(uuid.uuid4()),
                'name': f"Contrato {fake.company()} - {fake.word().title()}",
                'description': fake.text(max_nb_chars=200),
                'version': f"{random.randint(1, 5)}.{random.randint(0, 9)}.{random.randint(0, 9)}",
                'status': random.choice(statuses),
                'contract_type': random.choice(contract_types),
                'owner_email': fake.email(),
                'schema_definition': {
                    "type": "object",
                    "properties": {
                        "id": {"type": "string"},
                        "name": {"type": "string"},
                        "email": {"type": "string", "format": "email"},
                        "created_at": {"type": "string", "format": "date-time"}
                    },
                    "required": ["id", "name"]
                },
                'sla_availability': round(random.uniform(95.0, 99.9), 2),
                'sla_response_time': random.randint(50, 500),
                'created_at': created_at,
                'updated_at': fake.date_time_between(start_date=created_at, end_date='now')
            })
        return contracts
    
    @staticmethod
    def create_entities(count: int = 50) -> List[Dict[str, Any]]:
        """Cria entidades mocadas"""
        entities = []
        entity_types = ['table', 'view', 'materialized_view', 'external_table']
        domains = ['sales', 'marketing', 'finance', 'hr', 'operations', 'analytics']
        
        for i in range(count):
            created_at = fake.date_time_between(start_date='-1y', end_date='now')
            entities.append({
                'id': str(uuid.uuid4()),
                'name': f"{random.choice(['customer', 'order', 'product', 'transaction', 'user', 'campaign'])}_{fake.word()}",
                'display_name': fake.catch_phrase(),
                'description': fake.text(max_nb_chars=150),
                'entity_type': random.choice(entity_types),
                'domain': random.choice(domains),
                'owner_email': fake.email(),
                'schema_name': f"schema_{random.choice(domains)}",
                'table_name': f"tbl_{fake.word()}_{random.randint(1, 999)}",
                'unity_catalog_path': f"catalog.{random.choice(domains)}.{fake.word()}",
                'row_count': random.randint(1000, 1000000),
                'size_bytes': random.randint(1024*1024, 1024*1024*1024),  # 1MB a 1GB
                'is_active': random.choice([True, True, True, False]),
                'tags': random.sample(['pii', 'financial', 'public', 'internal', 'confidential', 'analytics'], k=random.randint(1, 3)),
                'created_at': created_at,
                'updated_at': fake.date_time_between(start_date=created_at, end_date='now')
            })
        return entities
    
    @staticmethod
    def create_quality_rules(count: int = 30) -> List[Dict[str, Any]]:
        """Cria regras de qualidade mocadas"""
        rules = []
        rule_types = ['not_null', 'unique', 'range', 'format', 'custom']
        severities = ['info', 'warning', 'error', 'critical']
        
        for i in range(count):
            created_at = fake.date_time_between(start_date='-6m', end_date='now')
            rule_type = random.choice(rule_types)
            
            # Parâmetros baseados no tipo de regra
            parameters = {}
            if rule_type == 'range':
                parameters = {'min_value': random.randint(0, 100), 'max_value': random.randint(100, 1000)}
            elif rule_type == 'format':
                parameters = {'pattern': r'^[A-Z]{2,3}-\d{4,6}$'}
            elif rule_type == 'custom':
                parameters = {'expression': 'LENGTH(column_name) > 0'}
            
            rules.append({
                'id': str(uuid.uuid4()),
                'name': f"Regra {fake.word().title()} - {rule_type.title()}",
                'description': fake.text(max_nb_chars=100),
                'rule_type': rule_type,
                'column_name': random.choice(['id', 'name', 'email', 'status', 'created_at', 'amount']),
                'parameters': parameters,
                'severity': random.choice(severities),
                'is_active': random.choice([True, True, False]),
                'created_at': created_at,
                'updated_at': fake.date_time_between(start_date=created_at, end_date='now')
            })
        return rules
    
    @staticmethod
    def create_quality_metrics(count: int = 100) -> List[Dict[str, Any]]:
        """Cria métricas de qualidade mocadas"""
        metrics = []
        metric_types = ['completeness', 'uniqueness', 'validity', 'consistency', 'accuracy']
        
        for i in range(count):
            measured_at = fake.date_time_between(start_date='-3m', end_date='now')
            metric_type = random.choice(metric_types)
            
            # Valores realistas baseados no tipo de métrica
            if metric_type in ['completeness', 'uniqueness', 'validity']:
                value = round(random.uniform(85.0, 99.9), 2)
            else:
                value = round(random.uniform(70.0, 95.0), 2)
            
            metrics.append({
                'id': str(uuid.uuid4()),
                'metric_type': metric_type,
                'value': value,
                'threshold': round(random.uniform(80.0, 95.0), 2),
                'status': 'passed' if value >= 90 else 'failed',
                'measured_at': measured_at,
                'created_at': measured_at
            })
        return metrics
    
    @staticmethod
    def create_governance_policies(count: int = 15) -> List[Dict[str, Any]]:
        """Cria políticas de governança mocadas"""
        policies = []
        policy_types = ['access_control', 'data_retention', 'data_classification', 'privacy']
        
        for i in range(count):
            created_at = fake.date_time_between(start_date='-1y', end_date='now')
            policies.append({
                'id': str(uuid.uuid4()),
                'name': f"Política {fake.catch_phrase()}",
                'description': fake.text(max_nb_chars=200),
                'policy_type': random.choice(policy_types),
                'rules': {
                    'conditions': [
                        {'field': 'data_classification', 'operator': 'equals', 'value': 'confidential'}
                    ],
                    'actions': [
                        {'type': 'require_approval', 'approvers': [fake.email()]}
                    ]
                },
                'is_active': random.choice([True, True, False]),
                'created_at': created_at,
                'updated_at': fake.date_time_between(start_date=created_at, end_date='now')
            })
        return policies
    
    @staticmethod
    def create_lineage_relationships(entities: List[Dict], count: int = 40) -> List[Dict[str, Any]]:
        """Cria relacionamentos de linhagem mocados"""
        relationships = []
        relationship_types = ['derives_from', 'feeds_into', 'transforms', 'aggregates']
        
        entity_ids = [e['id'] for e in entities]
        
        for i in range(min(count, len(entity_ids) * 2)):
            source_id = random.choice(entity_ids)
            target_id = random.choice([eid for eid in entity_ids if eid != source_id])
            
            relationships.append({
                'id': str(uuid.uuid4()),
                'source_entity_id': source_id,
                'target_entity_id': target_id,
                'relationship_type': random.choice(relationship_types),
                'confidence_score': round(random.uniform(0.7, 1.0), 2),
                'created_at': fake.date_time_between(start_date='-6m', end_date='now')
            })
        return relationships
    
    @staticmethod
    def create_audit_logs(count: int = 200) -> List[Dict[str, Any]]:
        """Cria logs de auditoria mocados"""
        logs = []
        actions = ['create', 'read', 'update', 'delete', 'approve', 'reject']
        resource_types = ['data_contract', 'entity', 'quality_rule', 'policy']
        
        for i in range(count):
            logs.append({
                'id': str(uuid.uuid4()),
                'user_id': str(uuid.uuid4()),
                'action': random.choice(actions),
                'resource_type': random.choice(resource_types),
                'resource_id': str(uuid.uuid4()),
                'details': {
                    'ip_address': fake.ipv4(),
                    'user_agent': fake.user_agent(),
                    'changes': {'field': 'status', 'old_value': 'draft', 'new_value': 'active'}
                },
                'timestamp': fake.date_time_between(start_date='-1m', end_date='now')
            })
        return logs
    
    @staticmethod
    def create_complete_dataset(size: str = "small") -> Dict[str, List[Dict]]:
        """Cria um dataset completo com relacionamentos"""
        sizes = {
            "small": {"users": 5, "contracts": 10, "entities": 20, "rules": 15, "metrics": 50},
            "medium": {"users": 10, "contracts": 20, "entities": 50, "rules": 30, "metrics": 100},
            "large": {"users": 20, "contracts": 50, "entities": 100, "rules": 60, "metrics": 200}
        }
        
        config = sizes.get(size, sizes["small"])
        
        # Criar dados base
        users = MockDataFactory.create_users(config["users"])
        contracts = MockDataFactory.create_data_contracts(config["contracts"])
        entities = MockDataFactory.create_entities(config["entities"])
        rules = MockDataFactory.create_quality_rules(config["rules"])
        metrics = MockDataFactory.create_quality_metrics(config["metrics"])
        policies = MockDataFactory.create_governance_policies(10)
        lineage = MockDataFactory.create_lineage_relationships(entities, 30)
        audit_logs = MockDataFactory.create_audit_logs(100)
        
        return {
            "users": users,
            "data_contracts": contracts,
            "entities": entities,
            "quality_rules": rules,
            "quality_metrics": metrics,
            "governance_policies": policies,
            "lineage_relationships": lineage,
            "audit_logs": audit_logs
        }

