"""
Engine de Inteligência Artificial
API de Governança de Dados V3.0
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)

Este módulo implementa funcionalidades avançadas de IA para:
- Detecção automática de anomalias
- Recomendações inteligentes
- Classificação automática de dados
- Predição de qualidade
- Análise de padrões
"""

from .ml_engine import MLEngine
from .anomaly_detector import AnomalyDetector
from .recommendation_engine import RecommendationEngine
from .auto_classifier import AutoClassifier
from .quality_predictor import QualityPredictor
from .pattern_analyzer import PatternAnalyzer

__all__ = [
    'MLEngine',
    'AnomalyDetector', 
    'RecommendationEngine',
    'AutoClassifier',
    'QualityPredictor',
    'PatternAnalyzer'
]

__version__ = '3.0.0'
__author__ = 'Carlos Morais (carlos.morais@f1rst.com.br)'

