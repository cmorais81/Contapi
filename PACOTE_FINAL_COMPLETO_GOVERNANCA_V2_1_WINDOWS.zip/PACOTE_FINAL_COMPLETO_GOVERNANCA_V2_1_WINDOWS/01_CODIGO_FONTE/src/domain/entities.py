"""
Entidades de domínio para a API de Governança de Dados
"""

from datetime import datetime
from typing import Any, Dict, List, Optional
from uuid import UUID, uuid4

from src.domain.exceptions import BusinessRuleViolation, ValidationError
from src.domain.value_objects import (
    ClassificationLevel,
    DomainPath,
    Email,
    EntityId,
    QualityThreshold,
    UnityCatalogPath,
    Version,
)


class BaseEntity:
    """Entidade base com campos comuns"""
    
    def __init__(
        self,
        id: Optional[UUID] = None,
        created_at: Optional[datetime] = None,
        updated_at: Optional[datetime] = None,
        created_by: Optional[UUID] = None,
        updated_by: Optional[UUID] = None,
    ):
        self.id = id or uuid4()
        self.created_at = created_at or datetime.utcnow()
        self.updated_at = updated_at or datetime.utcnow()
        self.created_by = created_by
        self.updated_by = updated_by
    
    def update_timestamp(self, updated_by: Optional[UUID] = None):
        """Atualiza timestamp de modificação"""
        self.updated_at = datetime.utcnow()
        if updated_by:
            self.updated_by = updated_by


class DataContract(BaseEntity):
    """Entidade para contratos de dados"""
    
    def __init__(
        self,
        name: str,
        description: Optional[str] = None,
        domain_id: Optional[UUID] = None,
        steward_id: Optional[UUID] = None,
        status: str = "draft",
        unity_catalog_path: Optional[UnityCatalogPath] = None,
        **kwargs
    ):
        super().__init__(**kwargs)
        self.name = name
        self.description = description
        self.domain_id = domain_id
        self.steward_id = steward_id
        self.status = status
        self.unity_catalog_path = unity_catalog_path
        self.current_version_id: Optional[UUID] = None
        self.versions: List["DataContractVersion"] = []
        
        self._validate()
    
    def _validate(self):
        """Valida a entidade"""
        if not self.name or len(self.name.strip()) == 0:
            raise ValidationError("Nome do contrato é obrigatório")
        
        if len(self.name) > 255:
            raise ValidationError("Nome do contrato não pode exceder 255 caracteres")
        
        valid_statuses = ["draft", "active", "deprecated", "archived"]
        if self.status not in valid_statuses:
            raise ValidationError(f"Status inválido: {self.status}")
    
    def add_version(
        self,
        version: Version,
        schema_definition: Dict[str, Any],
        description: Optional[str] = None,
        quality_rules: Optional[Dict[str, Any]] = None,
        sla_definition: Optional[Dict[str, Any]] = None,
        terms_and_conditions: Optional[str] = None,
        created_by: Optional[UUID] = None,
    ) -> "DataContractVersion":
        """Adiciona uma nova versão ao contrato"""
        
        # Verificar se a versão já existe
        for existing_version in self.versions:
            if existing_version.version == version:
                raise BusinessRuleViolation(f"Versão {version} já existe")
        
        contract_version = DataContractVersion(
            contract_id=self.id,
            version=version,
            description=description,
            schema_definition=schema_definition,
            quality_rules=quality_rules,
            sla_definition=sla_definition,
            terms_and_conditions=terms_and_conditions,
            created_by=created_by,
        )
        
        self.versions.append(contract_version)
        return contract_version
    
    def activate_version(self, version: Version, updated_by: Optional[UUID] = None):
        """Ativa uma versão específica"""
        target_version = None
        for v in self.versions:
            if v.version == version:
                target_version = v
                break
        
        if not target_version:
            raise BusinessRuleViolation(f"Versão {version} não encontrada")
        
        # Desativar versão atual
        for v in self.versions:
            v.is_active = False
        
        # Ativar nova versão
        target_version.is_active = True
        self.current_version_id = target_version.id
        self.status = "active"
        self.update_timestamp(updated_by)
    
    def get_active_version(self) -> Optional["DataContractVersion"]:
        """Retorna a versão ativa"""
        for version in self.versions:
            if version.is_active:
                return version
        return None
    
    def get_latest_version(self) -> Optional["DataContractVersion"]:
        """Retorna a versão mais recente"""
        if not self.versions:
            return None
        
        return max(self.versions, key=lambda v: (v.version.major, v.version.minor, v.version.patch))


class DataContractVersion(BaseEntity):
    """Versão de um contrato de dados"""
    
    def __init__(
        self,
        contract_id: UUID,
        version: Version,
        schema_definition: Dict[str, Any],
        description: Optional[str] = None,
        quality_rules: Optional[Dict[str, Any]] = None,
        sla_definition: Optional[Dict[str, Any]] = None,
        terms_and_conditions: Optional[str] = None,
        is_active: bool = False,
        odcs_export: Optional[Dict[str, Any]] = None,
        **kwargs
    ):
        super().__init__(**kwargs)
        self.contract_id = contract_id
        self.version = version
        self.description = description
        self.schema_definition = schema_definition
        self.quality_rules = quality_rules or {}
        self.sla_definition = sla_definition or {}
        self.terms_and_conditions = terms_and_conditions
        self.is_active = is_active
        self.odcs_export = odcs_export
        
        self._validate()
    
    def _validate(self):
        """Valida a versão do contrato"""
        if not self.schema_definition:
            raise ValidationError("Definição do schema é obrigatória")
        
        # Validar estrutura básica do schema
        required_fields = ["type", "properties"]
        for field in required_fields:
            if field not in self.schema_definition:
                raise ValidationError(f"Campo obrigatório no schema: {field}")
    
    def generate_odcs_export(self) -> Dict[str, Any]:
        """Gera export no formato ODCS v3.0.2"""
        odcs_contract = {
            "dataContractSpecification": "3.0.2",
            "id": str(self.contract_id),
            "info": {
                "title": f"Data Contract - Version {self.version}",
                "version": str(self.version),
                "description": self.description or "",
            },
            "schema": self.schema_definition,
        }
        
        if self.quality_rules:
            odcs_contract["quality"] = self.quality_rules
        
        if self.sla_definition:
            odcs_contract["serviceLevel"] = self.sla_definition
        
        if self.terms_and_conditions:
            odcs_contract["terms"] = {
                "usage": self.terms_and_conditions
            }
        
        self.odcs_export = odcs_contract
        return odcs_contract


class Entity(BaseEntity):
    """Entidade de dados (tabela, view, dataset, etc.)"""
    
    def __init__(
        self,
        name: str,
        type: str,
        description: Optional[str] = None,
        domain_id: Optional[UUID] = None,
        steward_id: Optional[UUID] = None,
        unity_catalog_path: Optional[UnityCatalogPath] = None,
        schema_definition: Optional[Dict[str, Any]] = None,
        business_glossary_id: Optional[UUID] = None,
        classification: Optional[ClassificationLevel] = None,
        **kwargs
    ):
        super().__init__(**kwargs)
        self.name = name
        self.type = type
        self.description = description
        self.domain_id = domain_id
        self.steward_id = steward_id
        self.unity_catalog_path = unity_catalog_path
        self.schema_definition = schema_definition or {}
        self.business_glossary_id = business_glossary_id
        self.classification = classification or ClassificationLevel("internal")
        self.attributes: List["EntityAttribute"] = []
        self.tags: List[UUID] = []
        
        self._validate()
    
    def _validate(self):
        """Valida a entidade"""
        if not self.name or len(self.name.strip()) == 0:
            raise ValidationError("Nome da entidade é obrigatório")
        
        if len(self.name) > 255:
            raise ValidationError("Nome da entidade não pode exceder 255 caracteres")
        
        valid_types = ["table", "view", "dataset", "stream", "file"]
        if self.type not in valid_types:
            raise ValidationError(f"Tipo de entidade inválido: {self.type}")
    
    def add_attribute(
        self,
        name: str,
        data_type: str,
        description: Optional[str] = None,
        is_nullable: bool = True,
        is_primary_key: bool = False,
        is_foreign_key: bool = False,
        business_term_id: Optional[UUID] = None,
        classification: Optional[ClassificationLevel] = None,
        masking_policy_id: Optional[UUID] = None,
    ) -> "EntityAttribute":
        """Adiciona um atributo à entidade"""
        
        # Verificar se o atributo já existe
        for attr in self.attributes:
            if attr.name == name:
                raise BusinessRuleViolation(f"Atributo {name} já existe")
        
        attribute = EntityAttribute(
            entity_id=self.id,
            name=name,
            data_type=data_type,
            description=description,
            is_nullable=is_nullable,
            is_primary_key=is_primary_key,
            is_foreign_key=is_foreign_key,
            business_term_id=business_term_id,
            classification=classification,
            masking_policy_id=masking_policy_id,
        )
        
        self.attributes.append(attribute)
        return attribute
    
    def add_tag(self, tag_id: UUID):
        """Adiciona uma tag à entidade"""
        if tag_id not in self.tags:
            self.tags.append(tag_id)
    
    def remove_tag(self, tag_id: UUID):
        """Remove uma tag da entidade"""
        if tag_id in self.tags:
            self.tags.remove(tag_id)


class EntityAttribute(BaseEntity):
    """Atributo de uma entidade"""
    
    def __init__(
        self,
        entity_id: UUID,
        name: str,
        data_type: str,
        description: Optional[str] = None,
        is_nullable: bool = True,
        is_primary_key: bool = False,
        is_foreign_key: bool = False,
        business_term_id: Optional[UUID] = None,
        classification: Optional[ClassificationLevel] = None,
        masking_policy_id: Optional[UUID] = None,
        **kwargs
    ):
        super().__init__(**kwargs)
        self.entity_id = entity_id
        self.name = name
        self.data_type = data_type
        self.description = description
        self.is_nullable = is_nullable
        self.is_primary_key = is_primary_key
        self.is_foreign_key = is_foreign_key
        self.business_term_id = business_term_id
        self.classification = classification
        self.masking_policy_id = masking_policy_id
        
        self._validate()
    
    def _validate(self):
        """Valida o atributo"""
        if not self.name or len(self.name.strip()) == 0:
            raise ValidationError("Nome do atributo é obrigatório")
        
        if not self.data_type or len(self.data_type.strip()) == 0:
            raise ValidationError("Tipo de dados é obrigatório")
        
        if self.is_primary_key and self.is_nullable:
            raise BusinessRuleViolation("Chave primária não pode ser nullable")


class QualityRule(BaseEntity):
    """Regra de qualidade de dados"""
    
    def __init__(
        self,
        name: str,
        entity_id: UUID,
        dimension_id: UUID,
        rule_type: str,
        rule_definition: Dict[str, Any],
        description: Optional[str] = None,
        attribute_id: Optional[UUID] = None,
        threshold: Optional[QualityThreshold] = None,
        is_active: bool = True,
        **kwargs
    ):
        super().__init__(**kwargs)
        self.name = name
        self.description = description
        self.entity_id = entity_id
        self.attribute_id = attribute_id
        self.dimension_id = dimension_id
        self.rule_type = rule_type
        self.rule_definition = rule_definition
        self.threshold = threshold
        self.is_active = is_active
        self.metrics: List["QualityMetric"] = []
        
        self._validate()
    
    def _validate(self):
        """Valida a regra de qualidade"""
        if not self.name or len(self.name.strip()) == 0:
            raise ValidationError("Nome da regra é obrigatório")
        
        valid_rule_types = [
            "completeness", "accuracy", "consistency", "validity",
            "uniqueness", "timeliness", "integrity"
        ]
        if self.rule_type not in valid_rule_types:
            raise ValidationError(f"Tipo de regra inválido: {self.rule_type}")
        
        if not self.rule_definition:
            raise ValidationError("Definição da regra é obrigatória")
    
    def execute(self, data_sample: Any = None) -> "QualityMetric":
        """Executa a regra de qualidade"""
        # Simulação de execução - em implementação real, 
        # seria integrado com engine de qualidade
        import random
        
        execution_start = datetime.utcnow()
        
        # Simular execução
        metric_value = random.uniform(70, 100)
        
        execution_time = (datetime.utcnow() - execution_start).total_seconds() * 1000
        
        status = "passed"
        if self.threshold:
            status = self.threshold.evaluate_status(metric_value)
        
        metric = QualityMetric(
            rule_id=self.id,
            entity_id=self.entity_id,
            execution_date=execution_start,
            metric_value=metric_value,
            status=status,
            execution_time_ms=int(execution_time),
            details={"sample_size": 1000, "rule_type": self.rule_type},
        )
        
        self.metrics.append(metric)
        return metric


class QualityMetric(BaseEntity):
    """Métrica de qualidade de dados"""
    
    def __init__(
        self,
        rule_id: UUID,
        entity_id: UUID,
        execution_date: datetime,
        metric_value: float,
        status: str,
        execution_time_ms: int,
        details: Optional[Dict[str, Any]] = None,
        **kwargs
    ):
        super().__init__(**kwargs)
        self.rule_id = rule_id
        self.entity_id = entity_id
        self.execution_date = execution_date
        self.metric_value = metric_value
        self.status = status
        self.details = details or {}
        self.execution_time_ms = execution_time_ms
        
        self._validate()
    
    def _validate(self):
        """Valida a métrica"""
        if not (0 <= self.metric_value <= 100):
            raise ValidationError("Valor da métrica deve estar entre 0 e 100")
        
        valid_statuses = ["passed", "warning", "critical"]
        if self.status not in valid_statuses:
            raise ValidationError(f"Status inválido: {self.status}")
    
    def is_critical(self) -> bool:
        """Verifica se a métrica está em estado crítico"""
        return self.status == "critical"
    
    def needs_attention(self) -> bool:
        """Verifica se a métrica precisa de atenção"""
        return self.status in ["warning", "critical"]


class Domain(BaseEntity):
    """Domínio de dados"""
    
    def __init__(
        self,
        name: str,
        description: Optional[str] = None,
        parent_domain_id: Optional[UUID] = None,
        steward_id: Optional[UUID] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs
    ):
        super().__init__(**kwargs)
        self.name = name
        self.description = description
        self.parent_domain_id = parent_domain_id
        self.steward_id = steward_id
        self.metadata = metadata or {}
        self.path = self._calculate_path()
        
        self._validate()
    
    def _validate(self):
        """Valida o domínio"""
        if not self.name or len(self.name.strip()) == 0:
            raise ValidationError("Nome do domínio é obrigatório")
        
        if len(self.name) > 255:
            raise ValidationError("Nome do domínio não pode exceder 255 caracteres")
    
    def _calculate_path(self) -> DomainPath:
        """Calcula o path hierárquico do domínio"""
        # Em implementação real, seria calculado baseado na hierarquia
        return DomainPath(self.name.lower().replace(' ', '_'))


class User(BaseEntity):
    """Usuário do sistema"""
    
    def __init__(
        self,
        username: str,
        email: Email,
        full_name: Optional[str] = None,
        hashed_password: Optional[str] = None,
        is_active: bool = True,
        is_superuser: bool = False,
        last_login: Optional[datetime] = None,
        **kwargs
    ):
        super().__init__(**kwargs)
        self.username = username
        self.email = email
        self.full_name = full_name
        self.hashed_password = hashed_password
        self.is_active = is_active
        self.is_superuser = is_superuser
        self.last_login = last_login
        
        self._validate()
    
    def _validate(self):
        """Valida o usuário"""
        if not self.username or len(self.username.strip()) == 0:
            raise ValidationError("Username é obrigatório")
        
        if len(self.username) > 100:
            raise ValidationError("Username não pode exceder 100 caracteres")
    
    def update_last_login(self):
        """Atualiza timestamp do último login"""
        self.last_login = datetime.utcnow()
        self.update_timestamp()

