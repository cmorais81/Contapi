"""
Controller para Workflows e Aprovações
"""

from typing import List, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status
from fastapi.responses import JSONResponse

from src.application.dtos.workflows import (
    WorkflowDefinitionDTO,
    WorkflowInstanceDTO,
    WorkflowInstanceResponseDTO,
    ApprovalRequestDTO,
    ApprovalResponseDTO,
    WorkflowStepDTO,
    WorkflowHistoryDTO,
    WorkflowMetricsDTO,
    TaskDTO,
    BulkApprovalDTO,
    BulkApprovalResultDTO,
    WorkflowTemplateDTO,
    WorkflowType,
    WorkflowStatus,
    ApprovalAction,
    Priority,
)
from src.application.dtos import PaginatedResponse, PaginationParams
from src.application.services.workflow_service import WorkflowService
from src.domain.exceptions import BusinessRuleViolation, EntityNotFoundError
from src.api.dependencies import get_current_active_user, get_workflow_service, validate_pagination

router = APIRouter(prefix="/api/v1/workflows", tags=["Workflows & Approvals"])


# Workflow Definitions
@router.post(
    "/definitions",
    response_model=dict,
    status_code=status.HTTP_201_CREATED,
    summary="Criar definição de workflow",
    description="Cria uma nova definição de workflow"
)
async def create_workflow_definition(
    definition: WorkflowDefinitionDTO,
    service: WorkflowService = Depends(get_workflow_service),
    current_user: dict = Depends(get_current_active_user)
) -> dict:
    """Cria definição de workflow"""
    try:
        definition_id = await service.create_workflow_definition(definition, current_user["id"])
        return {"message": "Workflow definition created successfully", "id": definition_id}
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get(
    "/definitions",
    response_model=List[dict],
    summary="Listar definições de workflow",
    description="Lista todas as definições de workflow"
)
async def list_workflow_definitions(
    workflow_type: Optional[WorkflowType] = Query(None, description="Filtro por tipo"),
    is_active: bool = Query(True, description="Filtro por ativo"),
    service: WorkflowService = Depends(get_workflow_service),
    current_user: dict = Depends(get_current_active_user)
) -> List[dict]:
    """Lista definições de workflow"""
    filters = {
        "workflow_type": workflow_type,
        "is_active": is_active
    }
    filters = {k: v for k, v in filters.items() if v is not None}
    
    return await service.list_workflow_definitions(filters)


# Workflow Instances
@router.post(
    "/instances",
    response_model=WorkflowInstanceResponseDTO,
    status_code=status.HTTP_201_CREATED,
    summary="Criar instância de workflow",
    description="Inicia uma nova instância de workflow"
)
async def create_workflow_instance(
    instance: WorkflowInstanceDTO,
    service: WorkflowService = Depends(get_workflow_service),
    current_user: dict = Depends(get_current_active_user)
) -> WorkflowInstanceResponseDTO:
    """Cria instância de workflow"""
    try:
        instance.requester_id = current_user["id"]
        return await service.create_workflow_instance(instance)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get(
    "/instances",
    response_model=PaginatedResponse[WorkflowInstanceResponseDTO],
    summary="Listar instâncias de workflow",
    description="Lista instâncias de workflow com filtros"
)
async def list_workflow_instances(
    pagination: PaginationParams = Depends(validate_pagination),
    status: Optional[WorkflowStatus] = Query(None, description="Filtro por status"),
    workflow_type: Optional[WorkflowType] = Query(None, description="Filtro por tipo"),
    priority: Optional[Priority] = Query(None, description="Filtro por prioridade"),
    requester_id: Optional[UUID] = Query(None, description="Filtro por solicitante"),
    assigned_to_me: bool = Query(False, description="Apenas atribuídos a mim"),
    service: WorkflowService = Depends(get_workflow_service),
    current_user: dict = Depends(get_current_active_user)
) -> PaginatedResponse[WorkflowInstanceResponseDTO]:
    """Lista instâncias de workflow"""
    filters = {
        "status": status,
        "workflow_type": workflow_type,
        "priority": priority,
        "requester_id": requester_id
    }
    
    if assigned_to_me:
        filters["assigned_to"] = current_user["id"]
    
    filters = {k: v for k, v in filters.items() if v is not None}
    
    return await service.list_workflow_instances(pagination, filters)


@router.get(
    "/instances/{instance_id}",
    response_model=WorkflowInstanceResponseDTO,
    summary="Buscar instância de workflow",
    description="Retorna detalhes de uma instância específica"
)
async def get_workflow_instance(
    instance_id: UUID,
    service: WorkflowService = Depends(get_workflow_service),
    current_user: dict = Depends(get_current_active_user)
) -> WorkflowInstanceResponseDTO:
    """Busca instância de workflow"""
    try:
        return await service.get_workflow_instance(instance_id)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.get(
    "/instances/{instance_id}/steps",
    response_model=List[WorkflowStepDTO],
    summary="Etapas do workflow",
    description="Lista etapas de uma instância de workflow"
)
async def get_workflow_steps(
    instance_id: UUID,
    service: WorkflowService = Depends(get_workflow_service),
    current_user: dict = Depends(get_current_active_user)
) -> List[WorkflowStepDTO]:
    """Lista etapas do workflow"""
    try:
        return await service.get_workflow_steps(instance_id)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.get(
    "/instances/{instance_id}/history",
    response_model=List[WorkflowHistoryDTO],
    summary="Histórico do workflow",
    description="Retorna histórico completo de uma instância"
)
async def get_workflow_history(
    instance_id: UUID,
    service: WorkflowService = Depends(get_workflow_service),
    current_user: dict = Depends(get_current_active_user)
) -> List[WorkflowHistoryDTO]:
    """Obtém histórico do workflow"""
    try:
        return await service.get_workflow_history(instance_id)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


# Approvals
@router.post(
    "/approvals",
    response_model=ApprovalResponseDTO,
    summary="Processar aprovação",
    description="Processa uma aprovação ou rejeição"
)
async def process_approval(
    approval: ApprovalRequestDTO,
    service: WorkflowService = Depends(get_workflow_service),
    current_user: dict = Depends(get_current_active_user)
) -> ApprovalResponseDTO:
    """Processa aprovação"""
    try:
        return await service.process_approval(approval, current_user["id"])
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.post(
    "/approvals/bulk",
    response_model=BulkApprovalResultDTO,
    summary="Aprovação em lote",
    description="Processa múltiplas aprovações em uma operação"
)
async def process_bulk_approval(
    bulk_approval: BulkApprovalDTO,
    service: WorkflowService = Depends(get_workflow_service),
    current_user: dict = Depends(get_current_active_user)
) -> BulkApprovalResultDTO:
    """Processa aprovação em lote"""
    try:
        return await service.process_bulk_approval(bulk_approval, current_user["id"])
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


# Tasks
@router.get(
    "/tasks/my-tasks",
    response_model=PaginatedResponse[TaskDTO],
    summary="Minhas tarefas",
    description="Lista tarefas pendentes do usuário atual"
)
async def get_my_tasks(
    pagination: PaginationParams = Depends(validate_pagination),
    priority: Optional[Priority] = Query(None, description="Filtro por prioridade"),
    workflow_type: Optional[WorkflowType] = Query(None, description="Filtro por tipo"),
    overdue_only: bool = Query(False, description="Apenas tarefas em atraso"),
    service: WorkflowService = Depends(get_workflow_service),
    current_user: dict = Depends(get_current_active_user)
) -> PaginatedResponse[TaskDTO]:
    """Lista tarefas do usuário"""
    filters = {
        "assignee_id": current_user["id"],
        "priority": priority,
        "workflow_type": workflow_type,
        "overdue_only": overdue_only
    }
    filters = {k: v for k, v in filters.items() if v is not None}
    
    return await service.get_user_tasks(pagination, filters)


@router.get(
    "/tasks/team-tasks",
    response_model=PaginatedResponse[TaskDTO],
    summary="Tarefas da equipe",
    description="Lista tarefas da equipe do usuário"
)
async def get_team_tasks(
    pagination: PaginationParams = Depends(validate_pagination),
    team_id: Optional[UUID] = Query(None, description="ID da equipe"),
    service: WorkflowService = Depends(get_workflow_service),
    current_user: dict = Depends(get_current_active_user)
) -> PaginatedResponse[TaskDTO]:
    """Lista tarefas da equipe"""
    filters = {
        "team_id": team_id or current_user.get("team_id")
    }
    filters = {k: v for k, v in filters.items() if v is not None}
    
    return await service.get_team_tasks(pagination, filters)


# Metrics and Analytics
@router.get(
    "/metrics",
    response_model=List[WorkflowMetricsDTO],
    summary="Métricas de workflow",
    description="Retorna métricas de performance dos workflows"
)
async def get_workflow_metrics(
    workflow_type: Optional[WorkflowType] = Query(None, description="Filtro por tipo"),
    period_days: int = Query(30, ge=1, le=365, description="Período em dias"),
    service: WorkflowService = Depends(get_workflow_service),
    current_user: dict = Depends(get_current_active_user)
) -> List[WorkflowMetricsDTO]:
    """Obtém métricas de workflow"""
    filters = {
        "workflow_type": workflow_type,
        "period_days": period_days
    }
    filters = {k: v for k, v in filters.items() if v is not None}
    
    return await service.get_workflow_metrics(filters)


@router.get(
    "/analytics/bottlenecks",
    response_model=List[dict],
    summary="Análise de gargalos",
    description="Identifica gargalos nos workflows"
)
async def analyze_workflow_bottlenecks(
    workflow_type: Optional[WorkflowType] = Query(None, description="Filtro por tipo"),
    period_days: int = Query(30, ge=1, le=365, description="Período em dias"),
    service: WorkflowService = Depends(get_workflow_service),
    current_user: dict = Depends(get_current_active_user)
) -> List[dict]:
    """Analisa gargalos nos workflows"""
    filters = {
        "workflow_type": workflow_type,
        "period_days": period_days
    }
    filters = {k: v for k, v in filters.items() if v is not None}
    
    return await service.analyze_workflow_bottlenecks(filters)


# Templates
@router.post(
    "/templates",
    response_model=dict,
    status_code=status.HTTP_201_CREATED,
    summary="Criar template",
    description="Cria um template de workflow reutilizável"
)
async def create_workflow_template(
    template: WorkflowTemplateDTO,
    service: WorkflowService = Depends(get_workflow_service),
    current_user: dict = Depends(get_current_active_user)
) -> dict:
    """Cria template de workflow"""
    try:
        template_id = await service.create_workflow_template(template, current_user["id"])
        return {"message": "Workflow template created successfully", "id": template_id}
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get(
    "/templates",
    response_model=List[dict],
    summary="Listar templates",
    description="Lista templates de workflow disponíveis"
)
async def list_workflow_templates(
    category: Optional[str] = Query(None, description="Filtro por categoria"),
    workflow_type: Optional[WorkflowType] = Query(None, description="Filtro por tipo"),
    is_public: Optional[bool] = Query(None, description="Filtro por público"),
    service: WorkflowService = Depends(get_workflow_service),
    current_user: dict = Depends(get_current_active_user)
) -> List[dict]:
    """Lista templates de workflow"""
    filters = {
        "category": category,
        "workflow_type": workflow_type,
        "is_public": is_public,
        "user_id": current_user["id"]
    }
    filters = {k: v for k, v in filters.items() if v is not None}
    
    return await service.list_workflow_templates(filters)


# Workflow Actions
@router.post(
    "/instances/{instance_id}/cancel",
    response_model=dict,
    summary="Cancelar workflow",
    description="Cancela uma instância de workflow"
)
async def cancel_workflow(
    instance_id: UUID,
    reason: str = Query(..., description="Motivo do cancelamento"),
    service: WorkflowService = Depends(get_workflow_service),
    current_user: dict = Depends(get_current_active_user)
) -> dict:
    """Cancela workflow"""
    try:
        await service.cancel_workflow(instance_id, reason, current_user["id"])
        return {"message": "Workflow cancelled successfully"}
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

