"""
Controller para Tags e Classificação
"""

from typing import List, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status
from fastapi.responses import JSONResponse

from src.application.dtos.tags import (
    TagCreateDTO,
    TagUpdateDTO,
    TagResponseDTO,
    TagAssignmentDTO,
    TagAssignmentResponseDTO,
    ClassificationRuleDTO,
    ClassificationResultDTO,
    TagHierarchyDTO,
    TagSearchDTO,
    TagUsageStatsDTO,
    BulkTagAssignmentDTO,
    BulkTagAssignmentResultDTO,
    TagType,
    TagScope,
    ClassificationLevel,
)
from src.application.dtos.common import PaginatedResponse, PaginationParams
from src.application.services.tag_service import TagService
from src.domain.exceptions import BusinessRuleViolation, EntityNotFoundError
from src.api.dependencies import get_current_active_user, get_tag_service, validate_pagination

router = APIRouter(prefix="/api/v1/tags", tags=["Tags & Classification"])


@router.post(
    "/",
    response_model=TagResponseDTO,
    status_code=status.HTTP_201_CREATED,
    summary="Criar tag",
    description="Cria uma nova tag no sistema"
)
async def create_tag(
    tag_data: TagCreateDTO,
    service: TagService = Depends(get_tag_service),
    current_user: dict = Depends(get_current_active_user)
) -> TagResponseDTO:
    """Cria uma nova tag"""
    try:
        return await service.create_tag(tag_data, current_user["id"])
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get(
    "/",
    response_model=PaginatedResponse[TagResponseDTO],
    summary="Listar tags",
    description="Lista todas as tags com filtros e paginação"
)
async def list_tags(
    pagination: PaginationParams = Depends(validate_pagination),
    tag_type: Optional[TagType] = Query(None, description="Filtro por tipo"),
    scope: Optional[TagScope] = Query(None, description="Filtro por escopo"),
    is_system_tag: Optional[bool] = Query(None, description="Filtro por tag do sistema"),
    is_mandatory: Optional[bool] = Query(None, description="Filtro por obrigatório"),
    parent_tag_id: Optional[UUID] = Query(None, description="Filtro por tag pai"),
    service: TagService = Depends(get_tag_service),
    current_user: dict = Depends(get_current_active_user)
) -> PaginatedResponse[TagResponseDTO]:
    """Lista tags com filtros"""
    filters = {
        "tag_type": tag_type,
        "scope": scope,
        "is_system_tag": is_system_tag,
        "is_mandatory": is_mandatory,
        "parent_tag_id": parent_tag_id
    }
    filters = {k: v for k, v in filters.items() if v is not None}
    
    return await service.list_tags(pagination, filters)


@router.get(
    "/{tag_id}",
    response_model=TagResponseDTO,
    summary="Buscar tag",
    description="Busca uma tag específica por ID"
)
async def get_tag(
    tag_id: UUID,
    service: TagService = Depends(get_tag_service),
    current_user: dict = Depends(get_current_active_user)
) -> TagResponseDTO:
    """Busca uma tag específica"""
    try:
        return await service.get_tag(tag_id)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.put(
    "/{tag_id}",
    response_model=TagResponseDTO,
    summary="Atualizar tag",
    description="Atualiza uma tag existente"
)
async def update_tag(
    tag_id: UUID,
    tag_data: TagUpdateDTO,
    service: TagService = Depends(get_tag_service),
    current_user: dict = Depends(get_current_active_user)
) -> TagResponseDTO:
    """Atualiza uma tag"""
    try:
        return await service.update_tag(tag_id, tag_data, current_user["id"])
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.delete(
    "/{tag_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Deletar tag",
    description="Remove uma tag do sistema"
)
async def delete_tag(
    tag_id: UUID,
    force: bool = Query(False, description="Forçar remoção mesmo com uso"),
    service: TagService = Depends(get_tag_service),
    current_user: dict = Depends(get_current_active_user)
):
    """Remove uma tag"""
    try:
        await service.delete_tag(tag_id, force, current_user["id"])
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.post(
    "/assign",
    response_model=TagAssignmentResponseDTO,
    status_code=status.HTTP_201_CREATED,
    summary="Atribuir tag",
    description="Atribui uma tag a uma entidade, atributo ou domínio"
)
async def assign_tag(
    assignment: TagAssignmentDTO,
    service: TagService = Depends(get_tag_service),
    current_user: dict = Depends(get_current_active_user)
) -> TagAssignmentResponseDTO:
    """Atribui tag a um recurso"""
    try:
        return await service.assign_tag(assignment, current_user["id"])
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.post(
    "/bulk-assign",
    response_model=BulkTagAssignmentResultDTO,
    summary="Atribuição em lote",
    description="Atribui múltiplas tags em uma única operação"
)
async def bulk_assign_tags(
    bulk_assignment: BulkTagAssignmentDTO,
    service: TagService = Depends(get_tag_service),
    current_user: dict = Depends(get_current_active_user)
) -> BulkTagAssignmentResultDTO:
    """Atribuição em lote de tags"""
    try:
        return await service.bulk_assign_tags(bulk_assignment, current_user["id"])
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get(
    "/assignments",
    response_model=PaginatedResponse[TagAssignmentResponseDTO],
    summary="Listar atribuições",
    description="Lista todas as atribuições de tags"
)
async def list_tag_assignments(
    pagination: PaginationParams = Depends(validate_pagination),
    tag_id: Optional[UUID] = Query(None, description="Filtro por tag"),
    entity_id: Optional[UUID] = Query(None, description="Filtro por entidade"),
    domain_id: Optional[UUID] = Query(None, description="Filtro por domínio"),
    assigned_by: Optional[str] = Query(None, description="Filtro por quem atribuiu"),
    is_validated: Optional[bool] = Query(None, description="Filtro por validado"),
    service: TagService = Depends(get_tag_service),
    current_user: dict = Depends(get_current_active_user)
) -> PaginatedResponse[TagAssignmentResponseDTO]:
    """Lista atribuições com filtros"""
    filters = {
        "tag_id": tag_id,
        "entity_id": entity_id,
        "domain_id": domain_id,
        "assigned_by": assigned_by,
        "is_validated": is_validated
    }
    filters = {k: v for k, v in filters.items() if v is not None}
    
    return await service.list_tag_assignments(pagination, filters)


@router.post(
    "/classify",
    response_model=ClassificationResultDTO,
    summary="Classificar automaticamente",
    description="Executa classificação automática de uma entidade"
)
async def classify_entity(
    entity_id: UUID,
    force_reclassification: bool = Query(False, description="Forçar reclassificação"),
    service: TagService = Depends(get_tag_service),
    current_user: dict = Depends(get_current_active_user)
) -> ClassificationResultDTO:
    """Classifica entidade automaticamente"""
    try:
        return await service.classify_entity(entity_id, force_reclassification)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.get(
    "/hierarchy",
    response_model=List[TagHierarchyDTO],
    summary="Hierarquia de tags",
    description="Retorna hierarquia completa de tags"
)
async def get_tag_hierarchy(
    root_tag_id: Optional[UUID] = Query(None, description="Tag raiz (opcional)"),
    include_usage: bool = Query(False, description="Incluir estatísticas de uso"),
    service: TagService = Depends(get_tag_service),
    current_user: dict = Depends(get_current_active_user)
) -> List[TagHierarchyDTO]:
    """Obtém hierarquia de tags"""
    return await service.get_tag_hierarchy(root_tag_id, include_usage)


@router.post(
    "/search",
    response_model=PaginatedResponse[TagResponseDTO],
    summary="Busca avançada de tags",
    description="Realiza busca avançada de tags com múltiplos critérios"
)
async def search_tags(
    search_criteria: TagSearchDTO,
    pagination: PaginationParams = Depends(validate_pagination),
    service: TagService = Depends(get_tag_service),
    current_user: dict = Depends(get_current_active_user)
) -> PaginatedResponse[TagResponseDTO]:
    """Busca avançada de tags"""
    return await service.search_tags(search_criteria, pagination)


@router.get(
    "/{tag_id}/usage",
    response_model=TagUsageStatsDTO,
    summary="Estatísticas de uso",
    description="Retorna estatísticas detalhadas de uso de uma tag"
)
async def get_tag_usage_stats(
    tag_id: UUID,
    period_days: int = Query(30, ge=1, le=365, description="Período em dias"),
    service: TagService = Depends(get_tag_service),
    current_user: dict = Depends(get_current_active_user)
) -> TagUsageStatsDTO:
    """Obtém estatísticas de uso da tag"""
    try:
        return await service.get_tag_usage_stats(tag_id, period_days)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


# Entity-specific endpoints
@router.get(
    "/entities/{entity_id}/tags",
    response_model=List[TagAssignmentResponseDTO],
    summary="Tags da entidade",
    description="Lista todas as tags atribuídas a uma entidade"
)
async def get_entity_tags(
    entity_id: UUID,
    tag_type: Optional[TagType] = Query(None, description="Filtro por tipo"),
    include_inherited: bool = Query(True, description="Incluir tags herdadas"),
    service: TagService = Depends(get_tag_service),
    current_user: dict = Depends(get_current_active_user)
) -> List[TagAssignmentResponseDTO]:
    """Lista tags de uma entidade"""
    try:
        return await service.get_entity_tags(entity_id, tag_type, include_inherited)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


# Classification Rules
@router.post(
    "/classification/rules",
    response_model=dict,
    status_code=status.HTTP_201_CREATED,
    summary="Criar regra de classificação",
    description="Cria uma nova regra de classificação automática"
)
async def create_classification_rule(
    rule_data: ClassificationRuleDTO,
    service: TagService = Depends(get_tag_service),
    current_user: dict = Depends(get_current_active_user)
) -> dict:
    """Cria regra de classificação"""
    try:
        rule_id = await service.create_classification_rule(rule_data, current_user["id"])
        return {"message": "Classification rule created successfully", "id": rule_id}
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get(
    "/classification/rules",
    response_model=List[dict],
    summary="Listar regras de classificação",
    description="Lista todas as regras de classificação ativas"
)
async def list_classification_rules(
    is_active: bool = Query(True, description="Filtro por ativo"),
    service: TagService = Depends(get_tag_service),
    current_user: dict = Depends(get_current_active_user)
) -> List[dict]:
    """Lista regras de classificação"""
    return await service.list_classification_rules(is_active)

