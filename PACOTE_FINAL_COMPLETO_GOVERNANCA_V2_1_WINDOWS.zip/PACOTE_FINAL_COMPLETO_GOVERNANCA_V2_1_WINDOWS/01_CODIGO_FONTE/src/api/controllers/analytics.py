"""
Controller para Métricas e Analytics
"""

from typing import List, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status
from fastapi.responses import JSONResponse

from src.application.dtos.analytics import (
    MetricDefinitionDTO,
    MetricValueDTO,
    MetricQueryDTO,
    MetricResultDTO,
    DashboardDTO,
    ReportRequestDTO,
    GovernanceScoreDTO,
    UsageAnalyticsDTO,
    AlertRuleDTO,
    AlertDTO,
    TrendAnalysisDTO,
    BenchmarkDTO,
    MetricType,
    TimeGranularity,
    AggregationType,
)
from src.application.dtos import PaginatedResponse, PaginationParams
from src.application.services.analytics_service import AnalyticsService
from src.domain.exceptions import BusinessRuleViolation, EntityNotFoundError
from src.api.dependencies import get_current_active_user, get_analytics_service, validate_pagination

router = APIRouter(prefix="/api/v1/analytics", tags=["Metrics & Analytics"])


# Metrics Management
@router.post(
    "/metrics",
    response_model=dict,
    status_code=status.HTTP_201_CREATED,
    summary="Criar métrica",
    description="Define uma nova métrica no sistema"
)
async def create_metric(
    metric_data: MetricDefinitionDTO,
    service: AnalyticsService = Depends(get_analytics_service),
    current_user: dict = Depends(get_current_active_user)
) -> dict:
    """Cria uma nova métrica"""
    try:
        metric_id = await service.create_metric(metric_data, current_user["id"])
        return {"message": "Metric created successfully", "id": metric_id}
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get(
    "/metrics",
    response_model=PaginatedResponse[dict],
    summary="Listar métricas",
    description="Lista todas as métricas definidas"
)
async def list_metrics(
    pagination: PaginationParams = Depends(validate_pagination),
    metric_type: Optional[MetricType] = Query(None, description="Filtro por tipo"),
    tags: Optional[str] = Query(None, description="Filtro por tags (separadas por vírgula)"),
    service: AnalyticsService = Depends(get_analytics_service),
    current_user: dict = Depends(get_current_active_user)
) -> PaginatedResponse[dict]:
    """Lista métricas com filtros"""
    filters = {
        "metric_type": metric_type,
        "tags": tags.split(",") if tags else None
    }
    filters = {k: v for k, v in filters.items() if v is not None}
    
    return await service.list_metrics(pagination, filters)


@router.post(
    "/metrics/values",
    response_model=dict,
    status_code=status.HTTP_201_CREATED,
    summary="Registrar valor de métrica",
    description="Registra um novo valor para uma métrica"
)
async def record_metric_value(
    metric_value: MetricValueDTO,
    service: AnalyticsService = Depends(get_analytics_service),
    current_user: dict = Depends(get_current_active_user)
) -> dict:
    """Registra valor de métrica"""
    try:
        value_id = await service.record_metric_value(metric_value)
        return {"message": "Metric value recorded successfully", "id": value_id}
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.post(
    "/metrics/query",
    response_model=List[MetricResultDTO],
    summary="Consultar métricas",
    description="Consulta valores de métricas com filtros e agregações"
)
async def query_metrics(
    query: MetricQueryDTO,
    service: AnalyticsService = Depends(get_analytics_service),
    current_user: dict = Depends(get_current_active_user)
) -> List[MetricResultDTO]:
    """Consulta métricas"""
    try:
        return await service.query_metrics(query)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


# Governance Scores
@router.get(
    "/governance-score",
    response_model=GovernanceScoreDTO,
    summary="Score de governança geral",
    description="Retorna score de governança do sistema"
)
async def get_overall_governance_score(
    service: AnalyticsService = Depends(get_analytics_service),
    current_user: dict = Depends(get_current_active_user)
) -> GovernanceScoreDTO:
    """Obtém score geral de governança"""
    return await service.get_overall_governance_score()


@router.get(
    "/governance-score/entity/{entity_id}",
    response_model=GovernanceScoreDTO,
    summary="Score de governança da entidade",
    description="Retorna score de governança de uma entidade específica"
)
async def get_entity_governance_score(
    entity_id: UUID,
    service: AnalyticsService = Depends(get_analytics_service),
    current_user: dict = Depends(get_current_active_user)
) -> GovernanceScoreDTO:
    """Obtém score de governança da entidade"""
    try:
        return await service.get_entity_governance_score(entity_id)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.get(
    "/governance-score/domain/{domain_id}",
    response_model=GovernanceScoreDTO,
    summary="Score de governança do domínio",
    description="Retorna score de governança de um domínio"
)
async def get_domain_governance_score(
    domain_id: UUID,
    service: AnalyticsService = Depends(get_analytics_service),
    current_user: dict = Depends(get_current_active_user)
) -> GovernanceScoreDTO:
    """Obtém score de governança do domínio"""
    try:
        return await service.get_domain_governance_score(domain_id)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


# Usage Analytics
@router.get(
    "/usage/entity/{entity_id}",
    response_model=UsageAnalyticsDTO,
    summary="Analytics de uso da entidade",
    description="Retorna analytics detalhados de uso de uma entidade"
)
async def get_entity_usage_analytics(
    entity_id: UUID,
    period_days: int = Query(30, ge=1, le=365, description="Período em dias"),
    service: AnalyticsService = Depends(get_analytics_service),
    current_user: dict = Depends(get_current_active_user)
) -> UsageAnalyticsDTO:
    """Obtém analytics de uso da entidade"""
    try:
        return await service.get_entity_usage_analytics(entity_id, period_days)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.get(
    "/usage/top-entities",
    response_model=List[dict],
    summary="Entidades mais utilizadas",
    description="Lista entidades mais utilizadas no período"
)
async def get_top_used_entities(
    limit: int = Query(10, ge=1, le=100, description="Número de entidades"),
    period_days: int = Query(30, ge=1, le=365, description="Período em dias"),
    service: AnalyticsService = Depends(get_analytics_service),
    current_user: dict = Depends(get_current_active_user)
) -> List[dict]:
    """Lista entidades mais utilizadas"""
    return await service.get_top_used_entities(limit, period_days)


# Dashboards
@router.post(
    "/dashboards",
    response_model=dict,
    status_code=status.HTTP_201_CREATED,
    summary="Criar dashboard",
    description="Cria um novo dashboard personalizado"
)
async def create_dashboard(
    dashboard_data: DashboardDTO,
    service: AnalyticsService = Depends(get_analytics_service),
    current_user: dict = Depends(get_current_active_user)
) -> dict:
    """Cria dashboard"""
    try:
        dashboard_data.owner_id = current_user["id"]
        dashboard_id = await service.create_dashboard(dashboard_data)
        return {"message": "Dashboard created successfully", "id": dashboard_id}
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get(
    "/dashboards",
    response_model=List[dict],
    summary="Listar dashboards",
    description="Lista dashboards do usuário"
)
async def list_dashboards(
    dashboard_type: Optional[str] = Query(None, description="Filtro por tipo"),
    is_public: Optional[bool] = Query(None, description="Filtro por público"),
    service: AnalyticsService = Depends(get_analytics_service),
    current_user: dict = Depends(get_current_active_user)
) -> List[dict]:
    """Lista dashboards"""
    filters = {
        "dashboard_type": dashboard_type,
        "is_public": is_public,
        "user_id": current_user["id"]
    }
    filters = {k: v for k, v in filters.items() if v is not None}
    
    return await service.list_dashboards(filters)


@router.get(
    "/dashboards/{dashboard_id}",
    response_model=dict,
    summary="Buscar dashboard",
    description="Retorna dados de um dashboard específico"
)
async def get_dashboard(
    dashboard_id: UUID,
    service: AnalyticsService = Depends(get_analytics_service),
    current_user: dict = Depends(get_current_active_user)
) -> dict:
    """Busca dashboard"""
    try:
        return await service.get_dashboard(dashboard_id, current_user["id"])
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


# Reports
@router.post(
    "/reports",
    response_model=dict,
    summary="Gerar relatório",
    description="Gera relatório customizado com métricas e analytics"
)
async def generate_report(
    report_request: ReportRequestDTO,
    service: AnalyticsService = Depends(get_analytics_service),
    current_user: dict = Depends(get_current_active_user)
) -> dict:
    """Gera relatório"""
    try:
        report_id = await service.generate_report(report_request, current_user["id"])
        return {"message": "Report generation started", "report_id": report_id}
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get(
    "/reports/{report_id}/status",
    response_model=dict,
    summary="Status do relatório",
    description="Verifica status de geração do relatório"
)
async def get_report_status(
    report_id: UUID,
    service: AnalyticsService = Depends(get_analytics_service),
    current_user: dict = Depends(get_current_active_user)
) -> dict:
    """Verifica status do relatório"""
    try:
        return await service.get_report_status(report_id)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


# Alerts
@router.post(
    "/alerts/rules",
    response_model=dict,
    status_code=status.HTTP_201_CREATED,
    summary="Criar regra de alerta",
    description="Cria uma nova regra de alerta para métricas"
)
async def create_alert_rule(
    alert_rule: AlertRuleDTO,
    service: AnalyticsService = Depends(get_analytics_service),
    current_user: dict = Depends(get_current_active_user)
) -> dict:
    """Cria regra de alerta"""
    try:
        rule_id = await service.create_alert_rule(alert_rule, current_user["id"])
        return {"message": "Alert rule created successfully", "id": rule_id}
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get(
    "/alerts",
    response_model=PaginatedResponse[AlertDTO],
    summary="Listar alertas",
    description="Lista alertas ativos e histórico"
)
async def list_alerts(
    pagination: PaginationParams = Depends(validate_pagination),
    status: Optional[str] = Query(None, description="Filtro por status"),
    severity: Optional[str] = Query(None, description="Filtro por severidade"),
    entity_id: Optional[UUID] = Query(None, description="Filtro por entidade"),
    service: AnalyticsService = Depends(get_analytics_service),
    current_user: dict = Depends(get_current_active_user)
) -> PaginatedResponse[AlertDTO]:
    """Lista alertas"""
    filters = {
        "status": status,
        "severity": severity,
        "entity_id": entity_id
    }
    filters = {k: v for k, v in filters.items() if v is not None}
    
    return await service.list_alerts(pagination, filters)


# Trend Analysis
@router.get(
    "/trends/metric/{metric_id}",
    response_model=TrendAnalysisDTO,
    summary="Análise de tendência",
    description="Analisa tendência de uma métrica específica"
)
async def analyze_metric_trend(
    metric_id: UUID,
    entity_id: Optional[UUID] = Query(None, description="ID da entidade"),
    period_days: int = Query(30, ge=7, le=365, description="Período em dias"),
    service: AnalyticsService = Depends(get_analytics_service),
    current_user: dict = Depends(get_current_active_user)
) -> TrendAnalysisDTO:
    """Analisa tendência da métrica"""
    try:
        return await service.analyze_metric_trend(metric_id, entity_id, period_days)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


# Benchmarking
@router.get(
    "/benchmark/entity/{entity_id}",
    response_model=List[BenchmarkDTO],
    summary="Benchmark da entidade",
    description="Compara métricas da entidade com benchmarks"
)
async def get_entity_benchmark(
    entity_id: UUID,
    metric_ids: Optional[str] = Query(None, description="IDs das métricas (separados por vírgula)"),
    service: AnalyticsService = Depends(get_analytics_service),
    current_user: dict = Depends(get_current_active_user)
) -> List[BenchmarkDTO]:
    """Obtém benchmark da entidade"""
    try:
        metric_id_list = None
        if metric_ids:
            metric_id_list = [UUID(mid.strip()) for mid in metric_ids.split(",")]
        
        return await service.get_entity_benchmark(entity_id, metric_id_list)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid metric ID format: {str(e)}"
        )


@router.get(
    "/kpis/summary",
    response_model=dict,
    summary="Resumo de KPIs",
    description="Retorna resumo dos principais KPIs do sistema"
)
async def get_kpi_summary(
    service: AnalyticsService = Depends(get_analytics_service),
    current_user: dict = Depends(get_current_active_user)
) -> dict:
    """Obtém resumo de KPIs"""
    return await service.get_kpi_summary()

