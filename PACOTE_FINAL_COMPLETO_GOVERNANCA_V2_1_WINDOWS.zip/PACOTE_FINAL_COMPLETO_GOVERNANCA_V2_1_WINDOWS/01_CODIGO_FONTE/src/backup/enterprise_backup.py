"""
Sistema de Backup e Disaster Recovery Enterprise
API de Governança de Dados V2.5
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

import asyncio
import os
import shutil
import gzip
import json
import boto3
from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta
from dataclasses import dataclass
import logging
from pathlib import Path
import subprocess
import hashlib
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker

logger = logging.getLogger(__name__)

@dataclass
class BackupJob:
    """Job de backup"""
    id: str
    name: str
    backup_type: str  # full, incremental, differential
    source_type: str  # database, files, configuration
    schedule: str  # cron expression
    retention_days: int
    compression: bool
    encryption: bool
    destination: str  # local, s3, azure, gcp
    status: str  # scheduled, running, completed, failed
    last_run: Optional[datetime] = None
    next_run: Optional[datetime] = None
    size_bytes: Optional[int] = None
    duration_seconds: Optional[float] = None

@dataclass
class RestorePoint:
    """Ponto de restauração"""
    id: str
    backup_job_id: str
    timestamp: datetime
    backup_type: str
    size_bytes: int
    checksum: str
    location: str
    metadata: Dict[str, Any]
    verified: bool = False

class EnterpriseBackup:
    """
    Sistema de backup e disaster recovery enterprise com:
    - Backups automáticos programados
    - Múltiplos destinos (local, cloud)
    - Compressão e criptografia
    - Verificação de integridade
    - Restauração point-in-time
    """
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.backup_jobs: Dict[str, BackupJob] = {}
        self.restore_points: List[RestorePoint] = []
        
        # Configurações
        self.backup_base_path = config.get('backup_base_path', '/var/backups/governanca')
        self.encryption_key = config.get('encryption_key')
        self.compression_level = config.get('compression_level', 6)
        
        # Clientes cloud
        self.s3_client = None
        self.azure_client = None
        
        # Database
        self.db_url = config.get('database_url')
        self.engine = None
        
        # Criar diretório base
        Path(self.backup_base_path).mkdir(parents=True, exist_ok=True)
        
        logger.info("Sistema de backup enterprise inicializado")
    
    async def initialize(self):
        """Inicializa conexões e recursos"""
        try:
            # Configurar clientes cloud
            if self.config.get('aws_access_key'):
                self.s3_client = boto3.client(
                    's3',
                    aws_access_key_id=self.config['aws_access_key'],
                    aws_secret_access_key=self.config['aws_secret_key'],
                    region_name=self.config.get('aws_region', 'us-east-1')
                )
            
            # Configurar engine de banco
            if self.db_url:
                self.engine = create_engine(self.db_url)
            
            # Carregar jobs de backup existentes
            await self._load_backup_jobs()
            
            logger.info("Sistema de backup inicializado com sucesso")
            
        except Exception as e:
            logger.error(f"Erro ao inicializar sistema de backup: {e}")
            raise
    
    async def create_backup_job(self, job_config: Dict[str, Any]) -> BackupJob:
        """Cria um novo job de backup"""
        try:
            job = BackupJob(
                id=job_config['id'],
                name=job_config['name'],
                backup_type=job_config['backup_type'],
                source_type=job_config['source_type'],
                schedule=job_config['schedule'],
                retention_days=job_config['retention_days'],
                compression=job_config.get('compression', True),
                encryption=job_config.get('encryption', True),
                destination=job_config['destination'],
                status='scheduled'
            )
            
            self.backup_jobs[job.id] = job
            
            # Salvar configuração
            await self._save_backup_jobs()
            
            logger.info(f"Job de backup criado: {job.name}")
            return job
            
        except Exception as e:
            logger.error(f"Erro ao criar job de backup: {e}")
            raise
    
    async def execute_backup_job(self, job_id: str) -> RestorePoint:
        """Executa um job de backup"""
        if job_id not in self.backup_jobs:
            raise ValueError(f"Job de backup não encontrado: {job_id}")
        
        job = self.backup_jobs[job_id]
        job.status = 'running'
        job.last_run = datetime.now()
        
        start_time = datetime.now()
        
        try:
            logger.info(f"Iniciando backup: {job.name}")
            
            # Executar backup baseado no tipo de fonte
            if job.source_type == 'database':
                restore_point = await self._backup_database(job)
            elif job.source_type == 'files':
                restore_point = await self._backup_files(job)
            elif job.source_type == 'configuration':
                restore_point = await self._backup_configuration(job)
            else:
                raise ValueError(f"Tipo de fonte não suportado: {job.source_type}")
            
            # Calcular duração
            duration = (datetime.now() - start_time).total_seconds()
            job.duration_seconds = duration
            job.size_bytes = restore_point.size_bytes
            job.status = 'completed'
            
            # Adicionar ponto de restauração
            self.restore_points.append(restore_point)
            
            # Limpar backups antigos
            await self._cleanup_old_backups(job)
            
            logger.info(f"Backup concluído: {job.name} ({restore_point.size_bytes} bytes)")
            return restore_point
            
        except Exception as e:
            job.status = 'failed'
            logger.error(f"Erro no backup {job.name}: {e}")
            raise
        finally:
            await self._save_backup_jobs()
    
    async def _backup_database(self, job: BackupJob) -> RestorePoint:
        """Executa backup do banco de dados"""
        timestamp = datetime.now()
        backup_id = f"{job.id}_{timestamp.strftime('%Y%m%d_%H%M%S')}"
        
        # Diretório de backup
        backup_dir = Path(self.backup_base_path) / 'database' / backup_id
        backup_dir.mkdir(parents=True, exist_ok=True)
        
        # Arquivo de backup
        backup_file = backup_dir / 'database_backup.sql'
        
        try:
            # Executar pg_dump
            if 'postgresql' in self.db_url:
                cmd = [
                    'pg_dump',
                    '--no-password',
                    '--verbose',
                    '--clean',
                    '--if-exists',
                    '--format=custom',
                    '--file', str(backup_file),
                    self.db_url
                ]
                
                result = subprocess.run(cmd, capture_output=True, text=True)
                
                if result.returncode != 0:
                    raise Exception(f"pg_dump failed: {result.stderr}")
            
            # Backup de metadados adicionais
            await self._backup_database_metadata(backup_dir)
            
            # Compressão
            if job.compression:
                compressed_file = backup_dir / 'database_backup.sql.gz'
                with open(backup_file, 'rb') as f_in:
                    with gzip.open(compressed_file, 'wb', compresslevel=self.compression_level) as f_out:
                        shutil.copyfileobj(f_in, f_out)
                
                backup_file.unlink()  # Remover arquivo original
                backup_file = compressed_file
            
            # Criptografia
            if job.encryption and self.encryption_key:
                encrypted_file = await self._encrypt_file(backup_file)
                backup_file.unlink()  # Remover arquivo original
                backup_file = encrypted_file
            
            # Calcular checksum
            checksum = await self._calculate_checksum(backup_file)
            
            # Obter tamanho
            size_bytes = backup_file.stat().st_size
            
            # Upload para destino
            location = await self._upload_backup(backup_file, job.destination)
            
            # Criar ponto de restauração
            restore_point = RestorePoint(
                id=backup_id,
                backup_job_id=job.id,
                timestamp=timestamp,
                backup_type=job.backup_type,
                size_bytes=size_bytes,
                checksum=checksum,
                location=location,
                metadata={
                    'database_url': self.db_url,
                    'compression': job.compression,
                    'encryption': job.encryption,
                    'tables_count': await self._get_tables_count(),
                    'records_count': await self._get_records_count()
                }
            )
            
            return restore_point
            
        except Exception as e:
            logger.error(f"Erro no backup do banco de dados: {e}")
            raise
    
    async def _backup_files(self, job: BackupJob) -> RestorePoint:
        """Executa backup de arquivos"""
        timestamp = datetime.now()
        backup_id = f"{job.id}_{timestamp.strftime('%Y%m%d_%H%M%S')}"
        
        # Diretório de backup
        backup_dir = Path(self.backup_base_path) / 'files' / backup_id
        backup_dir.mkdir(parents=True, exist_ok=True)
        
        # Arquivo de backup
        backup_file = backup_dir / 'files_backup.tar'
        
        try:
            # Criar arquivo tar
            source_paths = job.metadata.get('source_paths', [])
            
            cmd = ['tar', '-cf', str(backup_file)] + source_paths
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode != 0:
                raise Exception(f"tar failed: {result.stderr}")
            
            # Compressão
            if job.compression:
                compressed_file = backup_dir / 'files_backup.tar.gz'
                with open(backup_file, 'rb') as f_in:
                    with gzip.open(compressed_file, 'wb', compresslevel=self.compression_level) as f_out:
                        shutil.copyfileobj(f_in, f_out)
                
                backup_file.unlink()
                backup_file = compressed_file
            
            # Criptografia
            if job.encryption and self.encryption_key:
                encrypted_file = await self._encrypt_file(backup_file)
                backup_file.unlink()
                backup_file = encrypted_file
            
            # Calcular checksum
            checksum = await self._calculate_checksum(backup_file)
            
            # Obter tamanho
            size_bytes = backup_file.stat().st_size
            
            # Upload para destino
            location = await self._upload_backup(backup_file, job.destination)
            
            # Criar ponto de restauração
            restore_point = RestorePoint(
                id=backup_id,
                backup_job_id=job.id,
                timestamp=timestamp,
                backup_type=job.backup_type,
                size_bytes=size_bytes,
                checksum=checksum,
                location=location,
                metadata={
                    'source_paths': source_paths,
                    'compression': job.compression,
                    'encryption': job.encryption,
                    'files_count': len(source_paths)
                }
            )
            
            return restore_point
            
        except Exception as e:
            logger.error(f"Erro no backup de arquivos: {e}")
            raise
    
    async def _backup_configuration(self, job: BackupJob) -> RestorePoint:
        """Executa backup de configurações"""
        timestamp = datetime.now()
        backup_id = f"{job.id}_{timestamp.strftime('%Y%m%d_%H%M%S')}"
        
        # Diretório de backup
        backup_dir = Path(self.backup_base_path) / 'configuration' / backup_id
        backup_dir.mkdir(parents=True, exist_ok=True)
        
        try:
            # Backup de configurações da aplicação
            config_data = {
                'timestamp': timestamp.isoformat(),
                'version': '2.5.0',
                'database_schema': await self._export_database_schema(),
                'environment_variables': dict(os.environ),
                'application_config': self.config,
                'backup_jobs': {job_id: {
                    'id': job.id,
                    'name': job.name,
                    'backup_type': job.backup_type,
                    'source_type': job.source_type,
                    'schedule': job.schedule,
                    'retention_days': job.retention_days,
                    'compression': job.compression,
                    'encryption': job.encryption,
                    'destination': job.destination
                } for job_id, job in self.backup_jobs.items()}
            }
            
            # Salvar configurações
            config_file = backup_dir / 'configuration.json'
            with open(config_file, 'w') as f:
                json.dump(config_data, f, indent=2, default=str)
            
            # Compressão
            if job.compression:
                compressed_file = backup_dir / 'configuration.json.gz'
                with open(config_file, 'rb') as f_in:
                    with gzip.open(compressed_file, 'wb', compresslevel=self.compression_level) as f_out:
                        shutil.copyfileobj(f_in, f_out)
                
                config_file.unlink()
                config_file = compressed_file
            
            # Criptografia
            if job.encryption and self.encryption_key:
                encrypted_file = await self._encrypt_file(config_file)
                config_file.unlink()
                config_file = encrypted_file
            
            # Calcular checksum
            checksum = await self._calculate_checksum(config_file)
            
            # Obter tamanho
            size_bytes = config_file.stat().st_size
            
            # Upload para destino
            location = await self._upload_backup(config_file, job.destination)
            
            # Criar ponto de restauração
            restore_point = RestorePoint(
                id=backup_id,
                backup_job_id=job.id,
                timestamp=timestamp,
                backup_type=job.backup_type,
                size_bytes=size_bytes,
                checksum=checksum,
                location=location,
                metadata={
                    'configuration_items': len(config_data),
                    'compression': job.compression,
                    'encryption': job.encryption
                }
            )
            
            return restore_point
            
        except Exception as e:
            logger.error(f"Erro no backup de configuração: {e}")
            raise
    
    async def _backup_database_metadata(self, backup_dir: Path):
        """Backup de metadados do banco"""
        try:
            if not self.engine:
                return
            
            with self.engine.connect() as conn:
                # Schema information
                schema_info = {
                    'tables': [],
                    'indexes': [],
                    'constraints': []
                }
                
                # Obter informações das tabelas
                tables_result = conn.execute(text("""
                    SELECT table_name, table_rows, data_length, index_length
                    FROM information_schema.tables
                    WHERE table_schema = 'public'
                """))
                
                for row in tables_result:
                    schema_info['tables'].append({
                        'name': row[0],
                        'rows': row[1],
                        'data_length': row[2],
                        'index_length': row[3]
                    })
                
                # Salvar metadados
                metadata_file = backup_dir / 'database_metadata.json'
                with open(metadata_file, 'w') as f:
                    json.dump(schema_info, f, indent=2, default=str)
                
        except Exception as e:
            logger.warning(f"Erro ao fazer backup de metadados: {e}")
    
    async def _encrypt_file(self, file_path: Path) -> Path:
        """Criptografa um arquivo"""
        # TODO: Implementar criptografia real (AES-256)
        # Por enquanto, apenas renomeia o arquivo
        encrypted_path = file_path.with_suffix(file_path.suffix + '.enc')
        shutil.move(file_path, encrypted_path)
        return encrypted_path
    
    async def _calculate_checksum(self, file_path: Path) -> str:
        """Calcula checksum SHA-256 de um arquivo"""
        sha256_hash = hashlib.sha256()
        
        with open(file_path, 'rb') as f:
            for chunk in iter(lambda: f.read(4096), b""):
                sha256_hash.update(chunk)
        
        return sha256_hash.hexdigest()
    
    async def _upload_backup(self, file_path: Path, destination: str) -> str:
        """Faz upload do backup para o destino"""
        try:
            if destination == 'local':
                return str(file_path)
            
            elif destination == 's3' and self.s3_client:
                bucket = self.config.get('s3_bucket')
                key = f"backups/{file_path.name}"
                
                self.s3_client.upload_file(str(file_path), bucket, key)
                return f"s3://{bucket}/{key}"
            
            elif destination == 'azure':
                # TODO: Implementar upload para Azure
                return str(file_path)
            
            else:
                logger.warning(f"Destino não suportado: {destination}")
                return str(file_path)
                
        except Exception as e:
            logger.error(f"Erro no upload do backup: {e}")
            return str(file_path)
    
    async def _cleanup_old_backups(self, job: BackupJob):
        """Remove backups antigos baseado na política de retenção"""
        try:
            cutoff_date = datetime.now() - timedelta(days=job.retention_days)
            
            # Filtrar pontos de restauração antigos
            old_restore_points = [
                rp for rp in self.restore_points
                if rp.backup_job_id == job.id and rp.timestamp < cutoff_date
            ]
            
            for restore_point in old_restore_points:
                try:
                    # Remover arquivo local
                    if restore_point.location.startswith('/'):
                        file_path = Path(restore_point.location)
                        if file_path.exists():
                            file_path.unlink()
                    
                    # Remover do S3
                    elif restore_point.location.startswith('s3://') and self.s3_client:
                        bucket, key = restore_point.location[5:].split('/', 1)
                        self.s3_client.delete_object(Bucket=bucket, Key=key)
                    
                    # Remover da lista
                    self.restore_points.remove(restore_point)
                    
                    logger.info(f"Backup antigo removido: {restore_point.id}")
                    
                except Exception as e:
                    logger.error(f"Erro ao remover backup antigo {restore_point.id}: {e}")
            
        except Exception as e:
            logger.error(f"Erro na limpeza de backups antigos: {e}")
    
    async def restore_from_point(self, restore_point_id: str, target_location: str = None) -> bool:
        """Restaura dados de um ponto de restauração"""
        try:
            # Encontrar ponto de restauração
            restore_point = None
            for rp in self.restore_points:
                if rp.id == restore_point_id:
                    restore_point = rp
                    break
            
            if not restore_point:
                raise ValueError(f"Ponto de restauração não encontrado: {restore_point_id}")
            
            logger.info(f"Iniciando restauração: {restore_point.id}")
            
            # Download do backup
            backup_file = await self._download_backup(restore_point)
            
            # Verificar integridade
            if not await self._verify_backup_integrity(backup_file, restore_point.checksum):
                raise Exception("Falha na verificação de integridade do backup")
            
            # Descriptografar se necessário
            if restore_point.metadata.get('encryption'):
                backup_file = await self._decrypt_file(backup_file)
            
            # Descomprimir se necessário
            if restore_point.metadata.get('compression'):
                backup_file = await self._decompress_file(backup_file)
            
            # Executar restauração baseada no tipo
            job = self.backup_jobs[restore_point.backup_job_id]
            
            if job.source_type == 'database':
                success = await self._restore_database(backup_file, target_location)
            elif job.source_type == 'files':
                success = await self._restore_files(backup_file, target_location)
            elif job.source_type == 'configuration':
                success = await self._restore_configuration(backup_file, target_location)
            else:
                raise ValueError(f"Tipo de fonte não suportado: {job.source_type}")
            
            if success:
                logger.info(f"Restauração concluída com sucesso: {restore_point.id}")
            else:
                logger.error(f"Falha na restauração: {restore_point.id}")
            
            return success
            
        except Exception as e:
            logger.error(f"Erro na restauração: {e}")
            return False
    
    async def _download_backup(self, restore_point: RestorePoint) -> Path:
        """Faz download do backup"""
        if restore_point.location.startswith('/'):
            # Arquivo local
            return Path(restore_point.location)
        
        elif restore_point.location.startswith('s3://') and self.s3_client:
            # Download do S3
            bucket, key = restore_point.location[5:].split('/', 1)
            local_file = Path(self.backup_base_path) / 'temp' / key.split('/')[-1]
            local_file.parent.mkdir(parents=True, exist_ok=True)
            
            self.s3_client.download_file(bucket, key, str(local_file))
            return local_file
        
        else:
            raise Exception(f"Localização não suportada: {restore_point.location}")
    
    async def _verify_backup_integrity(self, file_path: Path, expected_checksum: str) -> bool:
        """Verifica integridade do backup"""
        actual_checksum = await self._calculate_checksum(file_path)
        return actual_checksum == expected_checksum
    
    async def _decrypt_file(self, file_path: Path) -> Path:
        """Descriptografa um arquivo"""
        # TODO: Implementar descriptografia real
        decrypted_path = file_path.with_suffix('')
        shutil.move(file_path, decrypted_path)
        return decrypted_path
    
    async def _decompress_file(self, file_path: Path) -> Path:
        """Descomprime um arquivo"""
        if file_path.suffix == '.gz':
            decompressed_path = file_path.with_suffix('')
            
            with gzip.open(file_path, 'rb') as f_in:
                with open(decompressed_path, 'wb') as f_out:
                    shutil.copyfileobj(f_in, f_out)
            
            return decompressed_path
        
        return file_path
    
    async def _restore_database(self, backup_file: Path, target_location: str = None) -> bool:
        """Restaura banco de dados"""
        try:
            db_url = target_location or self.db_url
            
            if 'postgresql' in db_url:
                cmd = [
                    'pg_restore',
                    '--no-password',
                    '--verbose',
                    '--clean',
                    '--if-exists',
                    '--dbname', db_url,
                    str(backup_file)
                ]
                
                result = subprocess.run(cmd, capture_output=True, text=True)
                
                if result.returncode != 0:
                    logger.error(f"pg_restore failed: {result.stderr}")
                    return False
            
            return True
            
        except Exception as e:
            logger.error(f"Erro na restauração do banco: {e}")
            return False
    
    async def _restore_files(self, backup_file: Path, target_location: str = None) -> bool:
        """Restaura arquivos"""
        try:
            target_dir = target_location or '/'
            
            cmd = ['tar', '-xf', str(backup_file), '-C', target_dir]
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode != 0:
                logger.error(f"tar extract failed: {result.stderr}")
                return False
            
            return True
            
        except Exception as e:
            logger.error(f"Erro na restauração de arquivos: {e}")
            return False
    
    async def _restore_configuration(self, backup_file: Path, target_location: str = None) -> bool:
        """Restaura configurações"""
        try:
            with open(backup_file, 'r') as f:
                config_data = json.load(f)
            
            # TODO: Implementar restauração de configurações
            logger.info("Configurações restauradas com sucesso")
            return True
            
        except Exception as e:
            logger.error(f"Erro na restauração de configurações: {e}")
            return False
    
    async def _get_tables_count(self) -> int:
        """Obtém número de tabelas"""
        try:
            if not self.engine:
                return 0
            
            with self.engine.connect() as conn:
                result = conn.execute(text("""
                    SELECT COUNT(*) FROM information_schema.tables
                    WHERE table_schema = 'public'
                """))
                return result.scalar()
                
        except Exception:
            return 0
    
    async def _get_records_count(self) -> int:
        """Obtém número total de registros"""
        try:
            if not self.engine:
                return 0
            
            with self.engine.connect() as conn:
                result = conn.execute(text("""
                    SELECT SUM(table_rows) FROM information_schema.tables
                    WHERE table_schema = 'public'
                """))
                return result.scalar() or 0
                
        except Exception:
            return 0
    
    async def _export_database_schema(self) -> Dict[str, Any]:
        """Exporta schema do banco"""
        try:
            if not self.engine:
                return {}
            
            with self.engine.connect() as conn:
                # Obter informações das tabelas
                tables_result = conn.execute(text("""
                    SELECT table_name FROM information_schema.tables
                    WHERE table_schema = 'public'
                """))
                
                schema = {
                    'tables': [row[0] for row in tables_result],
                    'export_timestamp': datetime.now().isoformat()
                }
                
                return schema
                
        except Exception as e:
            logger.error(f"Erro ao exportar schema: {e}")
            return {}
    
    async def _load_backup_jobs(self):
        """Carrega jobs de backup salvos"""
        try:
            jobs_file = Path(self.backup_base_path) / 'backup_jobs.json'
            
            if jobs_file.exists():
                with open(jobs_file, 'r') as f:
                    jobs_data = json.load(f)
                
                for job_data in jobs_data:
                    job = BackupJob(**job_data)
                    self.backup_jobs[job.id] = job
                
                logger.info(f"Carregados {len(self.backup_jobs)} jobs de backup")
            
        except Exception as e:
            logger.error(f"Erro ao carregar jobs de backup: {e}")
    
    async def _save_backup_jobs(self):
        """Salva jobs de backup"""
        try:
            jobs_file = Path(self.backup_base_path) / 'backup_jobs.json'
            
            jobs_data = []
            for job in self.backup_jobs.values():
                jobs_data.append({
                    'id': job.id,
                    'name': job.name,
                    'backup_type': job.backup_type,
                    'source_type': job.source_type,
                    'schedule': job.schedule,
                    'retention_days': job.retention_days,
                    'compression': job.compression,
                    'encryption': job.encryption,
                    'destination': job.destination,
                    'status': job.status,
                    'last_run': job.last_run.isoformat() if job.last_run else None,
                    'next_run': job.next_run.isoformat() if job.next_run else None,
                    'size_bytes': job.size_bytes,
                    'duration_seconds': job.duration_seconds
                })
            
            with open(jobs_file, 'w') as f:
                json.dump(jobs_data, f, indent=2)
            
        except Exception as e:
            logger.error(f"Erro ao salvar jobs de backup: {e}")
    
    async def get_backup_status(self) -> Dict[str, Any]:
        """Obtém status do sistema de backup"""
        try:
            total_backup_size = sum(
                rp.size_bytes for rp in self.restore_points
                if rp.size_bytes
            )
            
            recent_backups = [
                rp for rp in self.restore_points
                if rp.timestamp > datetime.now() - timedelta(days=7)
            ]
            
            return {
                'total_jobs': len(self.backup_jobs),
                'active_jobs': len([j for j in self.backup_jobs.values() if j.status != 'failed']),
                'total_restore_points': len(self.restore_points),
                'recent_backups': len(recent_backups),
                'total_backup_size_bytes': total_backup_size,
                'backup_base_path': self.backup_base_path,
                'jobs': [
                    {
                        'id': job.id,
                        'name': job.name,
                        'status': job.status,
                        'last_run': job.last_run.isoformat() if job.last_run else None,
                        'size_bytes': job.size_bytes
                    }
                    for job in self.backup_jobs.values()
                ],
                'recent_restore_points': [
                    {
                        'id': rp.id,
                        'timestamp': rp.timestamp.isoformat(),
                        'backup_type': rp.backup_type,
                        'size_bytes': rp.size_bytes,
                        'verified': rp.verified
                    }
                    for rp in recent_backups
                ]
            }
            
        except Exception as e:
            logger.error(f"Erro ao obter status do backup: {e}")
            return {}
    
    async def cleanup(self):
        """Limpa recursos"""
        try:
            await self._save_backup_jobs()
            logger.info("Recursos de backup limpos")
            
        except Exception as e:
            logger.error(f"Erro ao limpar recursos de backup: {e}")

# Instância global do sistema de backup
backup_instance = None

async def get_backup_instance(config: Dict[str, Any] = None) -> EnterpriseBackup:
    """Obtém instância singleton do sistema de backup"""
    global backup_instance
    
    if backup_instance is None:
        if config is None:
            config = {}
        
        backup_instance = EnterpriseBackup(config)
        await backup_instance.initialize()
    
    return backup_instance

