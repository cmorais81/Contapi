#!/usr/bin/env python3
"""
TBR GDP Core v1.0 - Teste Completo da API
Script de validação funcional de todos os endpoints
"""

import requests
import json
import time
from datetime import datetime
from typing import Dict, List, Optional

class TBRGDPCoreAPITester:
    """Classe para testar a API do TBR GDP Core v1.0"""
    
    def __init__(self, base_url: str = "http://localhost:8002"):
        self.base_url = base_url
        self.api_base = f"{base_url}/api/v1"
        self.session = requests.Session()
        self.test_results = []
        
    def log_test(self, test_name: str, success: bool, details: str = ""):
        """Registrar resultado do teste"""
        result = {
            "test": test_name,
            "success": success,
            "details": details,
            "timestamp": datetime.now().isoformat()
        }
        self.test_results.append(result)
        status = "✅" if success else "❌"
        print(f"{status} {test_name}: {details}")
    
    def test_health_check(self):
        """Testar endpoint de health check"""
        try:
            response = self.session.get(f"{self.base_url}/health", timeout=5)
            if response.status_code == 200:
                data = response.json()
                if data.get("status") == "healthy":
                    self.log_test("Health Check", True, f"Status: {data.get('status')}")
                    return True
                else:
                    self.log_test("Health Check", False, f"Status inválido: {data.get('status')}")
                    return False
            else:
                self.log_test("Health Check", False, f"Status code: {response.status_code}")
                return False
        except Exception as e:
            self.log_test("Health Check", False, f"Erro: {str(e)}")
            return False
    
    def test_entities_endpoints(self):
        """Testar endpoints de entidades"""
        success_count = 0
        total_tests = 9
        
        # GET /entities
        try:
            response = self.session.get(f"{self.api_base}/entities", timeout=5)
            if response.status_code == 200:
                entities = response.json()
                self.log_test("GET /entities", True, f"Retornou {len(entities)} entidades")
                success_count += 1
            else:
                self.log_test("GET /entities", False, f"Status: {response.status_code}")
        except Exception as e:
            self.log_test("GET /entities", False, f"Erro: {str(e)}")
        
        # GET /entities/{id}
        try:
            response = self.session.get(f"{self.api_base}/entities/1", timeout=5)
            if response.status_code == 200:
                entity = response.json()
                self.log_test("GET /entities/1", True, f"Entidade: {entity.get('name', 'N/A')}")
                success_count += 1
            else:
                self.log_test("GET /entities/1", False, f"Status: {response.status_code}")
        except Exception as e:
            self.log_test("GET /entities/1", False, f"Erro: {str(e)}")
        
        # POST /entities
        try:
            entity_data = {
                "name": "test_entity_api",
                "display_name": "Entidade de Teste API",
                "description": "Entidade criada durante teste da API",
                "domain_id": 1,
                "entity_type": "table",
                "classification": "internal",
                "owner_id": 1
            }
            response = self.session.post(f"{self.api_base}/entities", json=entity_data, timeout=5)
            if response.status_code == 201:
                new_entity = response.json()
                self.log_test("POST /entities", True, f"Criada com ID: {new_entity.get('id')}")
                success_count += 1
            else:
                self.log_test("POST /entities", False, f"Status: {response.status_code}")
        except Exception as e:
            self.log_test("POST /entities", False, f"Erro: {str(e)}")
        
        # PUT /entities/{id}
        try:
            update_data = {"description": "Descrição atualizada via API test"}
            response = self.session.put(f"{self.api_base}/entities/1", json=update_data, timeout=5)
            if response.status_code == 200:
                self.log_test("PUT /entities/1", True, "Entidade atualizada")
                success_count += 1
            else:
                self.log_test("PUT /entities/1", False, f"Status: {response.status_code}")
        except Exception as e:
            self.log_test("PUT /entities/1", False, f"Erro: {str(e)}")
        
        # GET /entities/{id}/lineage
        try:
            response = self.session.get(f"{self.api_base}/entities/1/lineage?max_depth=3", timeout=5)
            if response.status_code == 200:
                lineage = response.json()
                total_rel = lineage.get("total_relationships", 0)
                self.log_test("GET /entities/1/lineage", True, f"Relacionamentos: {total_rel}")
                success_count += 1
            else:
                self.log_test("GET /entities/1/lineage", False, f"Status: {response.status_code}")
        except Exception as e:
            self.log_test("GET /entities/1/lineage", False, f"Erro: {str(e)}")
        
        # POST /entities/{id}/lineage/{target_id}
        try:
            response = self.session.post(f"{self.api_base}/entities/1/lineage/2", timeout=5)
            if response.status_code == 201:
                self.log_test("POST /entities/1/lineage/2", True, "Relacionamento adicionado")
                success_count += 1
            else:
                self.log_test("POST /entities/1/lineage/2", False, f"Status: {response.status_code}")
        except Exception as e:
            self.log_test("POST /entities/1/lineage/2", False, f"Erro: {str(e)}")
        
        # PUT /entities/{id}/quality
        try:
            quality_data = {"score": 95, "issues_count": 2}
            response = self.session.put(f"{self.api_base}/entities/1/quality", json=quality_data, timeout=5)
            if response.status_code == 200:
                self.log_test("PUT /entities/1/quality", True, "Score atualizado")
                success_count += 1
            else:
                self.log_test("PUT /entities/1/quality", False, f"Status: {response.status_code}")
        except Exception as e:
            self.log_test("PUT /entities/1/quality", False, f"Erro: {str(e)}")
        
        # POST /entities/{id}/access
        try:
            access_data = {"access_type": "read", "user_id": "test_user"}
            response = self.session.post(f"{self.api_base}/entities/1/access", json=access_data, timeout=5)
            if response.status_code == 201:
                self.log_test("POST /entities/1/access", True, "Acesso registrado")
                success_count += 1
            else:
                self.log_test("POST /entities/1/access", False, f"Status: {response.status_code}")
        except Exception as e:
            self.log_test("POST /entities/1/access", False, f"Erro: {str(e)}")
        
        # DELETE /entities/{id}
        try:
            response = self.session.delete(f"{self.api_base}/entities/999", timeout=5)
            if response.status_code == 200:
                self.log_test("DELETE /entities/999", True, "Entidade excluída")
                success_count += 1
            else:
                self.log_test("DELETE /entities/999", False, f"Status: {response.status_code}")
        except Exception as e:
            self.log_test("DELETE /entities/999", False, f"Erro: {str(e)}")
        
        return success_count, total_tests
    
    def test_contracts_endpoints(self):
        """Testar endpoints de contratos"""
        success_count = 0
        total_tests = 6
        
        endpoints = [
            ("GET", "/contracts", "Listar contratos"),
            ("GET", "/contracts/1", "Obter contrato"),
            ("POST", "/contracts", "Criar contrato"),
            ("PUT", "/contracts/1", "Atualizar contrato"),
            ("DELETE", "/contracts/1", "Excluir contrato"),
            ("POST", "/contracts/1/approve", "Aprovar contrato")
        ]
        
        for method, endpoint, description in endpoints:
            try:
                if method == "GET":
                    response = self.session.get(f"{self.api_base}{endpoint}", timeout=5)
                elif method == "POST":
                    data = {"name": "Test Contract", "provider_id": 1, "consumer_id": 2}
                    response = self.session.post(f"{self.api_base}{endpoint}", json=data, timeout=5)
                elif method == "PUT":
                    data = {"description": "Updated description"}
                    response = self.session.put(f"{self.api_base}{endpoint}", json=data, timeout=5)
                elif method == "DELETE":
                    response = self.session.delete(f"{self.api_base}{endpoint}", timeout=5)
                
                if response.status_code in [200, 201]:
                    self.log_test(f"{method} {endpoint}", True, description)
                    success_count += 1
                else:
                    self.log_test(f"{method} {endpoint}", False, f"Status: {response.status_code}")
            except Exception as e:
                self.log_test(f"{method} {endpoint}", False, f"Erro: {str(e)}")
        
        return success_count, total_tests
    
    def test_quality_endpoints(self):
        """Testar endpoints de qualidade"""
        success_count = 0
        total_tests = 5
        
        endpoints = [
            ("GET", "/quality/rules", "Listar regras"),
            ("POST", "/quality/rules", "Criar regra"),
            ("GET", "/quality/checks", "Listar verificações"),
            ("POST", "/quality/checks/execute", "Executar verificação"),
            ("GET", "/quality/issues", "Listar problemas")
        ]
        
        for method, endpoint, description in endpoints:
            try:
                if method == "GET":
                    response = self.session.get(f"{self.api_base}{endpoint}", timeout=5)
                elif method == "POST":
                    if "execute" in endpoint:
                        data = {"rule_id": 1, "entity_id": 1}
                    else:
                        data = {"name": "Test Rule", "entity_id": 1, "rule_type": "completeness"}
                    response = self.session.post(f"{self.api_base}{endpoint}", json=data, timeout=5)
                
                if response.status_code in [200, 201]:
                    self.log_test(f"{method} {endpoint}", True, description)
                    success_count += 1
                else:
                    self.log_test(f"{method} {endpoint}", False, f"Status: {response.status_code}")
            except Exception as e:
                self.log_test(f"{method} {endpoint}", False, f"Erro: {str(e)}")
        
        return success_count, total_tests
    
    def test_other_domains(self):
        """Testar outros domínios"""
        success_count = 0
        total_tests = 14
        
        domains = [
            "policies", "analytics", "integrations", "governance",
            "monitoring", "automation", "marketplace"
        ]
        
        for domain in domains:
            # GET endpoint
            try:
                response = self.session.get(f"{self.api_base}/{domain}/", timeout=5)
                if response.status_code == 200:
                    self.log_test(f"GET /{domain}/", True, f"Domínio {domain} funcionando")
                    success_count += 1
                else:
                    self.log_test(f"GET /{domain}/", False, f"Status: {response.status_code}")
            except Exception as e:
                self.log_test(f"GET /{domain}/", False, f"Erro: {str(e)}")
            
            # POST endpoint
            try:
                data = {"name": f"Test {domain.title()}"}
                response = self.session.post(f"{self.api_base}/{domain}/", json=data, timeout=5)
                if response.status_code in [200, 201]:
                    self.log_test(f"POST /{domain}/", True, f"Criação em {domain} funcionando")
                    success_count += 1
                else:
                    self.log_test(f"POST /{domain}/", False, f"Status: {response.status_code}")
            except Exception as e:
                self.log_test(f"POST /{domain}/", False, f"Erro: {str(e)}")
        
        return success_count, total_tests
    
    def run_all_tests(self):
        """Executar todos os testes"""
        print("🚀 Iniciando Teste Completo da API TBR GDP Core v1.0")
        print("=" * 60)
        
        start_time = time.time()
        total_success = 0
        total_tests = 0
        
        # Health Check
        if self.test_health_check():
            total_success += 1
        total_tests += 1
        
        print("\n📊 Testando Domínio: Entities")
        print("-" * 30)
        success, tests = self.test_entities_endpoints()
        total_success += success
        total_tests += tests
        
        print("\n📄 Testando Domínio: Contracts")
        print("-" * 30)
        success, tests = self.test_contracts_endpoints()
        total_success += success
        total_tests += tests
        
        print("\n✅ Testando Domínio: Quality")
        print("-" * 30)
        success, tests = self.test_quality_endpoints()
        total_success += success
        total_tests += tests
        
        print("\n🔧 Testando Outros Domínios")
        print("-" * 30)
        success, tests = self.test_other_domains()
        total_success += success
        total_tests += tests
        
        end_time = time.time()
        duration = end_time - start_time
        success_rate = (total_success / total_tests) * 100 if total_tests > 0 else 0
        
        print("\n" + "=" * 60)
        print("📊 RESULTADO FINAL DOS TESTES")
        print("=" * 60)
        print(f"✅ Testes Passaram: {total_success}/{total_tests}")
        print(f"📈 Taxa de Sucesso: {success_rate:.1f}%")
        print(f"⏱️  Tempo Total: {duration:.2f} segundos")
        print(f"🎯 Status: {'APROVADO' if success_rate >= 80 else 'REPROVADO'}")
        
        # Salvar resultados
        results = {
            "timestamp": datetime.now().isoformat(),
            "total_tests": total_tests,
            "successful_tests": total_success,
            "success_rate": success_rate,
            "duration_seconds": duration,
            "status": "APPROVED" if success_rate >= 80 else "FAILED",
            "detailed_results": self.test_results
        }
        
        with open("test_results_v1.json", "w") as f:
            json.dump(results, f, indent=2)
        
        print(f"📄 Resultados salvos em: test_results_v1.json")
        
        return success_rate >= 80

def main():
    """Função principal"""
    tester = TBRGDPCoreAPITester()
    success = tester.run_all_tests()
    return 0 if success else 1

if __name__ == "__main__":
    exit(main())

