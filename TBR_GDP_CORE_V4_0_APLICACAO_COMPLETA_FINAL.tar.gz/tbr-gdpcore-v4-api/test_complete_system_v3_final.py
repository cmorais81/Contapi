"""
TBR GDP Core v3.0 - Suite Completa de Testes Funcionais
Testes abrangentes para todos os endpoints e funcionalidades
"""

import requests
import json
import time
from datetime import datetime, timedelta
from typing import Dict, List, Any
import uuid

# Configuração da API
BASE_URL = "http://localhost:8004"
API_BASE = f"{BASE_URL}/api/v3"

class ComprehensiveTestSuite:
    """Suite completa de testes para TBR GDP Core v3.0"""
    
    def __init__(self):
        self.results = []
        self.start_time = time.time()
        self.test_data = {}  # Para armazenar dados criados durante os testes
    
    def run_all_tests(self):
        """Executar todos os testes"""
        print("🚀 Iniciando Suite Completa de Testes TBR GDP Core v3.0")
        print("=" * 80)
        
        # Verificar se API está disponível
        if not self._check_api_health():
            print("❌ API não está disponível. Encerrando testes.")
            return
        
        print("✅ API está disponível. Iniciando testes...")
        print()
        
        # Executar grupos de testes
        self._test_entities_domain()
        self._test_contracts_domain()
        self._test_contract_versioning()
        self._test_quality_domain()
        self._test_rbac_abac_permissions()
        self._test_policies_domain()
        self._test_analytics_domain()
        self._test_integrations_domain()
        self._test_governance_domain()
        self._test_monitoring_domain()
        self._test_automation_domain()
        self._test_marketplace_domain()
        
        # Gerar relatório final
        self._generate_final_report()
    
    def _check_api_health(self) -> bool:
        """Verificar se a API está funcionando"""
        try:
            response = requests.get(f"{BASE_URL}/health", timeout=5)
            return response.status_code == 200
        except:
            return False
    
    # === TESTES DO DOMÍNIO ENTITIES ===
    
    def _test_entities_domain(self):
        """Testar domínio de entidades"""
        print("📊 Testando Domínio de Entidades...")
        
        # Teste 1: Listar entidades
        self._test_endpoint(
            "GET", f"{API_BASE}/entities",
            "Listar entidades",
            expected_keys=["entities", "total"]
        )
        
        # Teste 2: Criar entidade
        entity_data = {
            "name": f"test_entity_{int(time.time())}",
            "description": "Entidade de teste criada automaticamente",
            "domain_id": 1,
            "entity_type": "table",
            "source_system": "test_system",
            "owner": "test_user",
            "tags": ["test", "automated"]
        }
        
        create_result = self._test_endpoint(
            "POST", f"{API_BASE}/entities",
            "Criar entidade",
            data=entity_data,
            expected_keys=["id", "name", "description"]
        )
        
        if create_result and create_result.get("success"):
            entity_id = create_result["response"].get("id")
            self.test_data["entity_id"] = entity_id
            
            # Teste 3: Obter entidade por ID
            self._test_endpoint(
                "GET", f"{API_BASE}/entities/{entity_id}",
                f"Obter entidade {entity_id}",
                expected_keys=["id", "name", "description"]
            )
            
            # Teste 4: Atualizar entidade
            update_data = {
                "description": "Entidade atualizada via teste automatizado",
                "tags": ["test", "automated", "updated"]
            }
            
            self._test_endpoint(
                "PUT", f"{API_BASE}/entities/{entity_id}",
                f"Atualizar entidade {entity_id}",
                data=update_data,
                expected_keys=["id", "name", "description"]
            )
            
            # Teste 5: Obter linhagem da entidade
            self._test_endpoint(
                "GET", f"{API_BASE}/entities/{entity_id}/lineage",
                f"Obter linhagem da entidade {entity_id}",
                expected_keys=["entity_id", "upstream", "downstream"]
            )
            
            # Teste 6: Buscar entidades
            self._test_endpoint(
                "GET", f"{API_BASE}/entities/search?query=test",
                "Buscar entidades por query",
                expected_keys=["entities", "total", "query"]
            )
    
    # === TESTES DO DOMÍNIO CONTRACTS ===
    
    def _test_contracts_domain(self):
        """Testar domínio de contratos"""
        print("📋 Testando Domínio de Contratos...")
        
        # Teste 1: Listar contratos
        self._test_endpoint(
            "GET", f"{API_BASE}/contracts",
            "Listar contratos",
            expected_keys=["contracts", "total"]
        )
        
        # Teste 2: Criar contrato
        contract_data = {
            "name": f"test_contract_{int(time.time())}",
            "description": "Contrato de teste criado automaticamente",
            "entity_id": self.test_data.get("entity_id", 1),
            "contract_type": "data_sharing",
            "owner": "test_user",
            "status": "draft",
            "schema_definition": {
                "fields": [
                    {"name": "id", "type": "integer", "required": True},
                    {"name": "name", "type": "string", "required": True},
                    {"name": "email", "type": "string", "required": False}
                ]
            },
            "quality_requirements": {
                "completeness": 95.0,
                "accuracy": 98.0,
                "timeliness": 90.0
            }
        }
        
        create_result = self._test_endpoint(
            "POST", f"{API_BASE}/contracts",
            "Criar contrato",
            data=contract_data,
            expected_keys=["id", "name", "description", "status"]
        )
        
        if create_result and create_result.get("success"):
            contract_id = create_result["response"].get("id")
            self.test_data["contract_id"] = contract_id
            
            # Teste 3: Obter contrato por ID
            self._test_endpoint(
                "GET", f"{API_BASE}/contracts/{contract_id}",
                f"Obter contrato {contract_id}",
                expected_keys=["id", "name", "description", "status"]
            )
            
            # Teste 4: Atualizar contrato
            update_data = {
                "description": "Contrato atualizado via teste automatizado",
                "status": "pending_approval"
            }
            
            self._test_endpoint(
                "PUT", f"{API_BASE}/contracts/{contract_id}",
                f"Atualizar contrato {contract_id}",
                data=update_data,
                expected_keys=["id", "name", "description", "status"]
            )
            
            # Teste 5: Validar permissões do contrato
            permission_data = {
                "user_role": "data_analyst",
                "operation": "read",
                "user_attributes": {
                    "department": "analytics",
                    "clearance_level": 3
                }
            }
            
            self._test_endpoint(
                "POST", f"{API_BASE}/contracts/{contract_id}/permissions/validate",
                f"Validar permissões do contrato {contract_id}",
                data=permission_data,
                expected_keys=["final_decision", "rbac_decision", "abac_decision"]
            )
            
            # Teste 6: Obter preview de mascaramento
            self._test_endpoint(
                "GET", f"{API_BASE}/contracts/{contract_id}/masking/preview?user_role=data_analyst",
                f"Preview de mascaramento do contrato {contract_id}",
                expected_keys=["contract_id", "user_role", "masked_data"]
            )
            
            # Teste 7: Obter linhagem do contrato
            self._test_endpoint(
                "GET", f"{API_BASE}/contracts/{contract_id}/lineage",
                f"Obter linhagem do contrato {contract_id}",
                expected_keys=["contract_id", "upstream_contracts", "downstream_consumers"]
            )
    
    # === TESTES DE VERSIONAMENTO ===
    
    def _test_contract_versioning(self):
        """Testar funcionalidades de versionamento"""
        print("🔄 Testando Versionamento de Contratos...")
        
        contract_id = self.test_data.get("contract_id", 1)
        
        # Teste 1: Criar nova versão
        version_data = {
            "changes": {
                "schema_changes": ["Added field: customer_segment"],
                "quality_rules": ["Updated email validation"],
                "access_policies": ["Added read access for analytics team"]
            },
            "change_type": "minor",
            "created_by": "test_user"
        }
        
        create_version_result = self._test_endpoint(
            "POST", f"{API_BASE}/contracts/{contract_id}/versions",
            f"Criar nova versão do contrato {contract_id}",
            data=version_data,
            expected_keys=["success", "version"]
        )
        
        # Teste 2: Obter histórico de versões
        self._test_endpoint(
            "GET", f"{API_BASE}/contracts/{contract_id}/versions",
            f"Obter histórico de versões do contrato {contract_id}",
            expected_keys=["contract_id", "total_versions", "versions"]
        )
        
        # Teste 3: Comparar versões
        self._test_endpoint(
            "GET", f"{API_BASE}/contracts/{contract_id}/versions/compare?version1=3.0.0&version2=3.1.0",
            f"Comparar versões do contrato {contract_id}",
            expected_keys=["contract_id", "version1", "version2", "differences"]
        )
        
        # Teste 4: Análise de impacto
        impact_data = {
            "schema_changes": ["Added field: customer_segment"],
            "quality_rules": ["Updated email validation"]
        }
        
        self._test_endpoint(
            "POST", f"{API_BASE}/contracts/{contract_id}/impact-analysis",
            f"Análise de impacto do contrato {contract_id}",
            data=impact_data,
            expected_keys=["contract_id", "change_summary", "impact_categories"]
        )
        
        # Teste 5: Obter dependências
        self._test_endpoint(
            "GET", f"{API_BASE}/contracts/{contract_id}/dependencies",
            f"Obter dependências do contrato {contract_id}",
            expected_keys=["contract_id", "dependencies", "impact_radius"]
        )
        
        if create_version_result and create_version_result.get("success"):
            version_id = create_version_result["response"]["version"]["version_id"]
            
            # Teste 6: Iniciar workflow de aprovação
            workflow_data = {"initiated_by": "test_user"}
            
            workflow_result = self._test_endpoint(
                "POST", f"{API_BASE}/contracts/versions/{version_id}/workflow/start",
                f"Iniciar workflow para versão {version_id}",
                data=workflow_data,
                expected_keys=["success", "workflow"]
            )
            
            if workflow_result and workflow_result.get("success"):
                workflow_id = workflow_result["response"]["workflow"]["workflow_id"]
                
                # Teste 7: Obter status do workflow
                self._test_endpoint(
                    "GET", f"{API_BASE}/contracts/workflows/{workflow_id}",
                    f"Obter status do workflow {workflow_id}",
                    expected_keys=["workflow_id", "current_stage", "status"]
                )
    
    # === TESTES DO DOMÍNIO QUALITY ===
    
    def _test_quality_domain(self):
        """Testar domínio de qualidade"""
        print("✅ Testando Domínio de Qualidade...")
        
        entity_id = self.test_data.get("entity_id", 1)
        
        # Teste 1: Criar regra de qualidade
        rule_data = {
            "name": f"test_rule_{int(time.time())}",
            "description": "Regra de teste criada automaticamente",
            "rule_type": "not_null",
            "entity_id": entity_id,
            "column_name": "email",
            "threshold": 95.0,
            "severity": "high",
            "created_by": "test_user",
            "rule_definition": {
                "allow_empty_strings": False
            }
        }
        
        rule_result = self._test_endpoint(
            "POST", f"{API_BASE}/quality/rules",
            "Criar regra de qualidade",
            data=rule_data,
            expected_keys=["id", "name", "rule_type", "threshold"]
        )
        
        # Teste 2: Listar regras de qualidade
        self._test_endpoint(
            "GET", f"{API_BASE}/quality/rules",
            "Listar regras de qualidade",
            expected_keys=["rules", "total"]
        )
        
        if rule_result and rule_result.get("success"):
            rule_id = rule_result["response"].get("id")
            
            # Teste 3: Executar verificação de qualidade
            check_data = {
                "rule_id": rule_id,
                "entity_id": entity_id
            }
            
            check_result = self._test_endpoint(
                "POST", f"{API_BASE}/quality/checks",
                "Executar verificação de qualidade",
                data=check_data,
                expected_keys=["id", "rule_id", "status", "quality_score"]
            )
            
            # Teste 4: Listar verificações
            self._test_endpoint(
                "GET", f"{API_BASE}/quality/checks",
                "Listar verificações de qualidade",
                expected_keys=["checks", "total"]
            )
            
            # Teste 5: Obter métricas agregadas
            self._test_endpoint(
                "GET", f"{API_BASE}/quality/metrics/aggregated",
                "Obter métricas agregadas de qualidade",
                expected_keys=["overall_score", "total_records", "total_issues"]
            )
            
            # Teste 6: Obter tendências de qualidade
            self._test_endpoint(
                "GET", f"{API_BASE}/quality/trends?days=7",
                "Obter tendências de qualidade",
                expected_keys=["trends", "period_days"]
            )
            
            # Teste 7: Dashboard de qualidade
            self._test_endpoint(
                "GET", f"{API_BASE}/quality/dashboard",
                "Dashboard de qualidade",
                expected_keys=["overview", "metrics", "recent_checks"]
            )
    
    # === TESTES RBAC/ABAC ===
    
    def _test_rbac_abac_permissions(self):
        """Testar sistema de permissões RBAC/ABAC"""
        print("🔐 Testando Sistema RBAC/ABAC...")
        
        # Teste 1: Listar roles RBAC
        self._test_endpoint(
            "GET", f"{API_BASE}/permissions/rbac/roles",
            "Listar roles RBAC",
            expected_keys=["roles"]
        )
        
        # Teste 2: Obter permissões de role específica
        self._test_endpoint(
            "GET", f"{API_BASE}/permissions/rbac/roles/data_analyst/permissions",
            "Obter permissões do data_analyst",
            expected_keys=["global_permissions", "data_permissions"]
        )
        
        # Teste 3: Avaliar política ABAC
        abac_request = {
            "user_attributes": {
                "user_id": "test_user_001",
                "role": "data_analyst",
                "department": "analytics",
                "clearance_level": 3
            },
            "resource_attributes": {
                "contract_id": self.test_data.get("contract_id", 1),
                "classification_level": 2,
                "data_sensitivity": "internal"
            },
            "environment_attributes": {
                "current_time": datetime.utcnow().isoformat(),
                "network_zone": "internal"
            },
            "action_attributes": {
                "action_type": "read",
                "purpose": "analysis"
            }
        }
        
        self._test_endpoint(
            "POST", f"{API_BASE}/permissions/abac/evaluate",
            "Avaliar política ABAC",
            data=abac_request,
            expected_keys=["request_id", "decision", "policies_evaluated"]
        )
        
        # Teste 4: Listar políticas ABAC
        self._test_endpoint(
            "GET", f"{API_BASE}/permissions/abac/policies",
            "Listar políticas ABAC",
            expected_keys=["policies"]
        )
        
        # Teste 5: Dashboard de permissões
        self._test_endpoint(
            "GET", f"{API_BASE}/permissions/permissions/dashboard",
            "Dashboard de permissões",
            expected_keys=["overview", "security_metrics"]
        )
    
    # === TESTES DOS DEMAIS DOMÍNIOS ===
    
    def _test_policies_domain(self):
        """Testar domínio de políticas"""
        print("📜 Testando Domínio de Políticas...")
        
        self._test_endpoint(
            "GET", f"{API_BASE}/policies",
            "Listar políticas de governança",
            expected_keys=["policies", "total"]
        )
        
        self._test_endpoint(
            "GET", f"{API_BASE}/policies/compliance",
            "Obter políticas de compliance",
            expected_keys=["compliance_policies", "frameworks"]
        )
    
    def _test_analytics_domain(self):
        """Testar domínio de analytics"""
        print("📈 Testando Domínio de Analytics...")
        
        self._test_endpoint(
            "GET", f"{API_BASE}/analytics/usage",
            "Obter analytics de uso",
            expected_keys=["usage_metrics", "period"]
        )
        
        self._test_endpoint(
            "GET", f"{API_BASE}/analytics/trends",
            "Obter tendências de analytics",
            expected_keys=["trends", "insights"]
        )
    
    def _test_integrations_domain(self):
        """Testar domínio de integrações"""
        print("🔗 Testando Domínio de Integrações...")
        
        self._test_endpoint(
            "GET", f"{API_BASE}/integrations",
            "Listar integrações",
            expected_keys=["integrations", "total"]
        )
        
        self._test_endpoint(
            "GET", f"{API_BASE}/integrations/status",
            "Status das integrações",
            expected_keys=["status", "active_integrations"]
        )
    
    def _test_governance_domain(self):
        """Testar domínio de governança"""
        print("⚖️ Testando Domínio de Governança...")
        
        self._test_endpoint(
            "GET", f"{API_BASE}/governance/framework",
            "Obter framework de governança",
            expected_keys=["framework", "policies"]
        )
        
        self._test_endpoint(
            "GET", f"{API_BASE}/governance/compliance",
            "Status de compliance",
            expected_keys=["compliance_status", "score"]
        )
    
    def _test_monitoring_domain(self):
        """Testar domínio de monitoramento"""
        print("📊 Testando Domínio de Monitoramento...")
        
        self._test_endpoint(
            "GET", f"{API_BASE}/monitoring/performance",
            "Métricas de performance",
            expected_keys=["performance_metrics", "slow_queries"]
        )
        
        self._test_endpoint(
            "GET", f"{API_BASE}/monitoring/azure-costs",
            "Custos Azure",
            expected_keys=["current_costs", "trends"]
        )
    
    def _test_automation_domain(self):
        """Testar domínio de automação"""
        print("🤖 Testando Domínio de Automação...")
        
        self._test_endpoint(
            "GET", f"{API_BASE}/automation/rules",
            "Listar regras de automação",
            expected_keys=["rules", "total"]
        )
        
        self._test_endpoint(
            "GET", f"{API_BASE}/automation/executions",
            "Execuções de automação",
            expected_keys=["executions", "status"]
        )
    
    def _test_marketplace_domain(self):
        """Testar domínio de marketplace"""
        print("🛒 Testando Domínio de Marketplace...")
        
        self._test_endpoint(
            "GET", f"{API_BASE}/marketplace/items",
            "Listar itens do marketplace",
            expected_keys=["items", "total"]
        )
        
        self._test_endpoint(
            "GET", f"{API_BASE}/marketplace/requests",
            "Solicitações do marketplace",
            expected_keys=["requests", "pending"]
        )
    
    # === MÉTODOS AUXILIARES ===
    
    def _test_endpoint(self, 
                      method: str, 
                      url: str, 
                      description: str,
                      data: Dict = None,
                      expected_keys: List[str] = None,
                      expected_status: int = 200) -> Dict[str, Any]:
        """Testar um endpoint específico"""
        
        start_time = time.time()
        
        try:
            if method == "GET":
                response = requests.get(url, timeout=10)
            elif method == "POST":
                response = requests.post(url, json=data, timeout=10)
            elif method == "PUT":
                response = requests.put(url, json=data, timeout=10)
            elif method == "DELETE":
                response = requests.delete(url, timeout=10)
            else:
                raise ValueError(f"Método HTTP não suportado: {method}")
            
            response_time = (time.time() - start_time) * 1000  # em ms
            
            # Verificar status code
            status_ok = response.status_code == expected_status
            
            # Verificar conteúdo da resposta
            response_data = {}
            keys_ok = True
            
            try:
                response_data = response.json()
                
                if expected_keys:
                    for key in expected_keys:
                        if key not in response_data:
                            keys_ok = False
                            break
            except:
                if expected_status == 200:
                    keys_ok = False
            
            # Determinar resultado do teste
            success = status_ok and keys_ok
            status_icon = "✅" if success else "❌"
            
            # Registrar resultado
            result = {
                "test": description,
                "method": method,
                "url": url,
                "status": "PASS" if success else "FAIL",
                "status_code": response.status_code,
                "response_time_ms": round(response_time, 2),
                "expected_keys": expected_keys,
                "keys_found": keys_ok,
                "response_size": len(response.content),
                "success": success,
                "response": response_data
            }
            
            self.results.append(result)
            
            # Exibir resultado
            print(f"{status_icon} {description}")
            print(f"   {method} {url}")
            print(f"   Status: {response.status_code} | Tempo: {response_time:.1f}ms | Tamanho: {len(response.content)} bytes")
            
            if not success:
                print(f"   ⚠️  Falha: Status={response.status_code}, Keys={keys_ok}")
            
            print()
            
            return result
            
        except Exception as e:
            # Registrar erro
            result = {
                "test": description,
                "method": method,
                "url": url,
                "status": "ERROR",
                "error": str(e),
                "response_time_ms": (time.time() - start_time) * 1000,
                "success": False,
                "response": None
            }
            
            self.results.append(result)
            
            print(f"❌ {description}")
            print(f"   {method} {url}")
            print(f"   ⚠️  Erro: {str(e)}")
            print()
            
            return result
    
    def _generate_final_report(self):
        """Gerar relatório final dos testes"""
        
        total_tests = len(self.results)
        passed_tests = len([r for r in self.results if r["status"] == "PASS"])
        failed_tests = len([r for r in self.results if r["status"] == "FAIL"])
        error_tests = len([r for r in self.results if r["status"] == "ERROR"])
        
        success_rate = (passed_tests / total_tests * 100) if total_tests > 0 else 0
        avg_response_time = sum(r.get("response_time_ms", 0) for r in self.results) / total_tests if total_tests > 0 else 0
        total_time = time.time() - self.start_time
        
        print("\n" + "=" * 80)
        print("📊 RELATÓRIO FINAL DOS TESTES")
        print("=" * 80)
        
        print(f"⏱️  Tempo Total de Execução: {total_time:.1f}s")
        print(f"🧪 Total de Testes: {total_tests}")
        print(f"✅ Aprovados: {passed_tests}")
        print(f"❌ Falharam: {failed_tests}")
        print(f"⚠️  Erros: {error_tests}")
        print(f"📈 Taxa de Sucesso: {success_rate:.1f}%")
        print(f"⚡ Tempo Médio de Resposta: {avg_response_time:.1f}ms")
        print()
        
        # Resumo por domínio
        domains = {}
        for result in self.results:
            domain = self._extract_domain_from_url(result["url"])
            if domain not in domains:
                domains[domain] = {"total": 0, "passed": 0, "failed": 0, "errors": 0}
            
            domains[domain]["total"] += 1
            if result["status"] == "PASS":
                domains[domain]["passed"] += 1
            elif result["status"] == "FAIL":
                domains[domain]["failed"] += 1
            else:
                domains[domain]["errors"] += 1
        
        print("📋 RESUMO POR DOMÍNIO:")
        print("-" * 80)
        for domain, stats in domains.items():
            success_rate_domain = (stats["passed"] / stats["total"] * 100) if stats["total"] > 0 else 0
            status_icon = "✅" if success_rate_domain >= 90 else "⚠️" if success_rate_domain >= 70 else "❌"
            print(f"{status_icon} {domain.upper()}: {stats['passed']}/{stats['total']} ({success_rate_domain:.1f}%)")
        
        print()
        
        # Testes mais lentos
        slowest_tests = sorted(self.results, key=lambda x: x.get("response_time_ms", 0), reverse=True)[:5]
        if slowest_tests:
            print("🐌 TESTES MAIS LENTOS:")
            print("-" * 80)
            for test in slowest_tests:
                print(f"   {test['response_time_ms']:.1f}ms - {test['test']}")
            print()
        
        # Testes falhados
        failed_results = [r for r in self.results if r["status"] in ["FAIL", "ERROR"]]
        if failed_results:
            print("❌ TESTES FALHADOS:")
            print("-" * 80)
            for test in failed_results:
                print(f"   {test['status']} - {test['test']}")
                if "error" in test:
                    print(f"      Erro: {test['error']}")
            print()
        
        # Status final
        if success_rate >= 95:
            print("🎉 EXCELENTE! Sistema funcionando perfeitamente!")
        elif success_rate >= 85:
            print("✅ BOM! Sistema funcionando adequadamente.")
        elif success_rate >= 70:
            print("⚠️ ATENÇÃO! Sistema precisa de alguns ajustes.")
        else:
            print("❌ CRÍTICO! Sistema precisa de correções urgentes.")
        
        # Salvar resultados detalhados
        detailed_results = {
            "test_summary": {
                "total_tests": total_tests,
                "passed_tests": passed_tests,
                "failed_tests": failed_tests,
                "error_tests": error_tests,
                "success_rate": success_rate,
                "avg_response_time_ms": avg_response_time,
                "total_execution_time_s": total_time,
                "execution_timestamp": datetime.utcnow().isoformat()
            },
            "domain_summary": domains,
            "test_results": self.results,
            "test_data_created": self.test_data
        }
        
        with open("/home/ubuntu/TBR_GDP_CORE_V3_0_FINAL/complete_system_test_results.json", "w") as f:
            json.dump(detailed_results, f, indent=2, default=str)
        
        print(f"📄 Resultados detalhados salvos em: complete_system_test_results.json")
        print("=" * 80)
    
    def _extract_domain_from_url(self, url: str) -> str:
        """Extrair domínio da URL"""
        if "/entities" in url:
            return "entities"
        elif "/contracts" in url:
            return "contracts"
        elif "/quality" in url:
            return "quality"
        elif "/permissions" in url:
            return "permissions"
        elif "/policies" in url:
            return "policies"
        elif "/analytics" in url:
            return "analytics"
        elif "/integrations" in url:
            return "integrations"
        elif "/governance" in url:
            return "governance"
        elif "/monitoring" in url:
            return "monitoring"
        elif "/automation" in url:
            return "automation"
        elif "/marketplace" in url:
            return "marketplace"
        else:
            return "other"

def main():
    """Função principal para executar os testes"""
    suite = ComprehensiveTestSuite()
    suite.run_all_tests()

if __name__ == "__main__":
    main()

