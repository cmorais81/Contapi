#!/usr/bin/env python3
"""
TBR GDP Core v3.0 - Simulação Completa de Cenários de Teste
Executa cenários realísticos de uso da plataforma de governança
"""

import requests
import json
import time
from datetime import datetime
from typing import Dict, List, Any
import uuid

class TBRGDPCoreScenarioSimulator:
    """Simulador de cenários completos de uso"""
    
    def __init__(self, base_url: str = "http://localhost:8003"):
        self.base_url = base_url
        self.session = requests.Session()
        self.scenario_results = []
        self.created_resources = {
            "contracts": [],
            "quality_rules": [],
            "entities": []
        }
        
    def log_scenario(self, scenario_name: str, success: bool, details: Dict = None):
        """Registrar resultado do cenário"""
        result = {
            "scenario": scenario_name,
            "success": success,
            "timestamp": datetime.now().isoformat(),
            "details": details or {}
        }
        self.scenario_results.append(result)
        
        status = "✅ PASS" if success else "❌ FAIL"
        print(f"{status} {scenario_name}")
        if not success and details:
            print(f"   Erro: {details.get('error', 'Erro desconhecido')}")
    
    def scenario_1_create_data_contract(self):
        """Cenário 1: Criar contrato de dados completo"""
        print("\\n🎯 Cenário 1: Criação de Contrato de Dados Completo")
        
        try:
            # Dados do contrato
            contract_data = {
                "name": "Contrato de Dados de Clientes - Simulação",
                "description": "Contrato para compartilhamento de dados de clientes entre CRM e Analytics",
                "entity_id": 1,
                "provider": "Sistema CRM",
                "consumer": "Plataforma Analytics",
                "sla_requirements": {
                    "availability": "99.9%",
                    "latency_max": "100ms",
                    "throughput_min": "1000 req/s",
                    "data_freshness": "5 minutes"
                },
                "quality_rules": [
                    {"field": "customer_id", "rule": "not_null", "threshold": 100},
                    {"field": "email", "rule": "valid_email", "threshold": 95},
                    {"field": "phone", "rule": "valid_phone", "threshold": 90}
                ],
                "data_schema": {
                    "customer_id": {"type": "integer", "required": True},
                    "name": {"type": "string", "required": True, "max_length": 100},
                    "email": {"type": "string", "required": True, "format": "email"},
                    "phone": {"type": "string", "required": False, "format": "phone"},
                    "created_date": {"type": "datetime", "required": True}
                },
                "retention_policy": {
                    "retention_days": 2555,
                    "archive_after_days": 1095,
                    "delete_after_days": 2555,
                    "compliance_requirements": ["LGPD", "GDPR"]
                },
                "access_permissions": [
                    {"role": "data_analyst", "permissions": ["read"], "conditions": ["business_hours"]},
                    {"role": "data_engineer", "permissions": ["read", "write"], "conditions": []},
                    {"role": "admin", "permissions": ["read", "write", "delete"], "conditions": []}
                ],
                "masking_rules": [
                    {"field": "email", "mask_type": "email_domain", "roles_exempt": ["admin"]},
                    {"field": "phone", "mask_type": "partial", "mask_pattern": "XXX-XXX-####"}
                ]
            }
            
            # Criar contrato
            response = self.session.post(f"{self.base_url}/api/v3/contracts/", json=contract_data)
            
            if response.status_code == 200:
                contract = response.json()
                contract_id = contract["id"]
                self.created_resources["contracts"].append(contract_id)
                
                # Aprovar contrato
                approval_data = {
                    "approved_by": "admin@company.com",
                    "comments": "Contrato aprovado após revisão técnica e jurídica"
                }
                
                approval_response = self.session.post(
                    f"{self.base_url}/api/v3/contracts/{contract_id}/approve",
                    json=approval_data
                )
                
                if approval_response.status_code == 200:
                    approval = approval_response.json()
                    self.log_scenario(
                        "Cenário 1: Criar e Aprovar Contrato",
                        True,
                        {
                            "contract_id": contract_id,
                            "contract_name": contract["name"],
                            "approval_id": approval["approval_id"],
                            "approved_by": approval["approved_by"]
                        }
                    )
                    return contract_id
                else:
                    self.log_scenario(
                        "Cenário 1: Criar e Aprovar Contrato",
                        False,
                        {"error": f"Falha na aprovação: {approval_response.status_code}"}
                    )
            else:
                self.log_scenario(
                    "Cenário 1: Criar e Aprovar Contrato",
                    False,
                    {"error": f"Falha na criação: {response.status_code}"}
                )
                
        except Exception as e:
            self.log_scenario(
                "Cenário 1: Criar e Aprovar Contrato",
                False,
                {"error": str(e)}
            )
        
        return None
    
    def scenario_2_quality_management(self):
        """Cenário 2: Gestão de qualidade de dados"""
        print("\\n🎯 Cenário 2: Gestão de Qualidade de Dados")
        
        try:
            # Criar regra de qualidade
            quality_rule_data = {
                "name": "Validação de Email - Simulação",
                "description": "Validar formato de email nos dados de clientes",
                "entity_id": 1,
                "field": "email",
                "rule_type": "format_validation",
                "rule_config": {
                    "pattern": "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$",
                    "error_message": "Formato de email inválido"
                },
                "threshold": 95,
                "severity": "high",
                "active": True
            }
            
            response = self.session.post(f"{self.base_url}/api/v3/quality/rules", json=quality_rule_data)
            
            if response.status_code == 201:
                rule = response.json()
                rule_id = rule["id"]
                self.created_resources["quality_rules"].append(rule_id)
                
                # Executar verificação de qualidade
                check_data = {
                    "rule_id": rule_id,
                    "entity_id": 1,
                    "check_type": "full_scan",
                    "sample_size": 1000
                }
                
                check_response = self.session.post(
                    f"{self.base_url}/api/v3/quality/checks/execute",
                    json=check_data
                )
                
                if check_response.status_code == 201:
                    check = check_response.json()
                    self.log_scenario(
                        "Cenário 2: Criar Regra e Executar Verificação",
                        True,
                        {
                            "rule_id": rule_id,
                            "rule_name": rule["name"],
                            "check_id": check["check_id"],
                            "quality_score": check["quality_score"]
                        }
                    )
                    return rule_id
                else:
                    self.log_scenario(
                        "Cenário 2: Criar Regra e Executar Verificação",
                        False,
                        {"error": f"Falha na verificação: {check_response.status_code}"}
                    )
            else:
                self.log_scenario(
                    "Cenário 2: Criar Regra e Executar Verificação",
                    False,
                    {"error": f"Falha na criação da regra: {response.status_code}"}
                )
                
        except Exception as e:
            self.log_scenario(
                "Cenário 2: Criar Regra e Executar Verificação",
                False,
                {"error": str(e)}
            )
        
        return None
    
    def scenario_3_data_lineage_tracking(self, contract_id: int):
        """Cenário 3: Rastreamento de linhagem de dados"""
        print("\\n🎯 Cenário 3: Rastreamento de Linhagem de Dados")
        
        if not contract_id:
            self.log_scenario(
                "Cenário 3: Rastreamento de Linhagem",
                False,
                {"error": "Contract ID não disponível"}
            )
            return
        
        try:
            # Obter linhagem do contrato
            response = self.session.get(
                f"{self.base_url}/api/v3/contracts/{contract_id}/lineage",
                params={"depth": 5, "direction": "both"}
            )
            
            if response.status_code == 200:
                lineage = response.json()
                
                # Obter linhagem de entidade relacionada
                entity_response = self.session.get(
                    f"{self.base_url}/api/v3/entities/1/lineage",
                    params={"max_depth": 3}
                )
                
                if entity_response.status_code == 200:
                    entity_lineage = entity_response.json()
                    
                    self.log_scenario(
                        "Cenário 3: Rastreamento de Linhagem",
                        True,
                        {
                            "contract_lineage": {
                                "upstream_levels": len(lineage["upstream_lineage"]),
                                "downstream_levels": len(lineage["downstream_lineage"]),
                                "transformations": len(lineage["transformations"])
                            },
                            "entity_lineage": {
                                "upstream_entities": len(entity_lineage.get("upstream_entities", [])),
                                "downstream_entities": len(entity_lineage.get("downstream_entities", []))
                            }
                        }
                    )
                else:
                    self.log_scenario(
                        "Cenário 3: Rastreamento de Linhagem",
                        False,
                        {"error": f"Falha na linhagem de entidade: {entity_response.status_code}"}
                    )
            else:
                self.log_scenario(
                    "Cenário 3: Rastreamento de Linhagem",
                    False,
                    {"error": f"Falha na linhagem de contrato: {response.status_code}"}
                )
                
        except Exception as e:
            self.log_scenario(
                "Cenário 3: Rastreamento de Linhagem",
                False,
                {"error": str(e)}
            )
    
    def scenario_4_permission_and_masking(self, contract_id: int):
        """Cenário 4: Validação de permissões e mascaramento"""
        print("\\n🎯 Cenário 4: Validação de Permissões e Mascaramento")
        
        if not contract_id:
            self.log_scenario(
                "Cenário 4: Permissões e Mascaramento",
                False,
                {"error": "Contract ID não disponível"}
            )
            return
        
        try:
            # Testar diferentes roles
            roles = ["admin", "data_engineer", "data_analyst"]
            permission_results = {}
            masking_results = {}
            
            for role in roles:
                # Validar permissões
                permission_data = {
                    "user_role": role,
                    "operation": "read",
                    "context": {"ip_address": "192.168.1.100", "time": "business_hours"}
                }
                
                perm_response = self.session.post(
                    f"{self.base_url}/api/v3/contracts/{contract_id}/permissions/validate",
                    json=permission_data
                )
                
                if perm_response.status_code == 200:
                    permission_results[role] = perm_response.json()
                
                # Obter preview de mascaramento
                mask_response = self.session.get(
                    f"{self.base_url}/api/v3/contracts/{contract_id}/masking/preview",
                    params={"user_role": role, "sample_size": 5}
                )
                
                if mask_response.status_code == 200:
                    masking_results[role] = mask_response.json()
            
            if len(permission_results) == 3 and len(masking_results) == 3:
                self.log_scenario(
                    "Cenário 4: Permissões e Mascaramento",
                    True,
                    {
                        "roles_tested": roles,
                        "permission_summary": {
                            role: {
                                "access_granted": data["access_granted"],
                                "data_access_level": data["data_access_level"]
                            }
                            for role, data in permission_results.items()
                        },
                        "masking_summary": {
                            role: {
                                "sample_size": data["sample_size"],
                                "masking_rules_applied": len(data["masking_rules_applied"])
                            }
                            for role, data in masking_results.items()
                        }
                    }
                )
            else:
                self.log_scenario(
                    "Cenário 4: Permissões e Mascaramento",
                    False,
                    {"error": "Falha em obter dados para todos os roles"}
                )
                
        except Exception as e:
            self.log_scenario(
                "Cenário 4: Permissões e Mascaramento",
                False,
                {"error": str(e)}
            )
    
    def scenario_5_monitoring_and_metrics(self, contract_id: int):
        """Cenário 5: Monitoramento e métricas"""
        print("\\n🎯 Cenário 5: Monitoramento e Métricas")
        
        if not contract_id:
            self.log_scenario(
                "Cenário 5: Monitoramento e Métricas",
                False,
                {"error": "Contract ID não disponível"}
            )
            return
        
        try:
            # Obter métricas do contrato
            metrics_response = self.session.get(
                f"{self.base_url}/api/v3/contracts/{contract_id}/metrics",
                params={"period": "7d"}
            )
            
            # Obter violações
            violations_response = self.session.get(
                f"{self.base_url}/api/v3/contracts/{contract_id}/violations",
                params={"days": 30}
            )
            
            # Obter problemas de qualidade
            quality_issues_response = self.session.get(f"{self.base_url}/api/v3/quality/issues")
            
            if (metrics_response.status_code == 200 and 
                violations_response.status_code == 200 and 
                quality_issues_response.status_code == 200):
                
                metrics = metrics_response.json()
                violations = violations_response.json()
                quality_issues = quality_issues_response.json()
                
                self.log_scenario(
                    "Cenário 5: Monitoramento e Métricas",
                    True,
                    {
                        "metrics": {
                            "sla_compliance": metrics["sla_compliance"],
                            "data_quality": metrics["data_quality"],
                            "usage_stats": metrics["usage_stats"],
                            "cost_metrics": metrics["cost_metrics"]
                        },
                        "violations_count": len(violations),
                        "quality_issues_count": len(quality_issues)
                    }
                )
            else:
                self.log_scenario(
                    "Cenário 5: Monitoramento e Métricas",
                    False,
                    {
                        "error": f"Falha em obter dados: metrics={metrics_response.status_code}, violations={violations_response.status_code}, quality={quality_issues_response.status_code}"
                    }
                )
                
        except Exception as e:
            self.log_scenario(
                "Cenário 5: Monitoramento e Métricas",
                False,
                {"error": str(e)}
            )
    
    def run_all_scenarios(self):
        """Executar todos os cenários de teste"""
        print("🚀 Iniciando Simulação Completa de Cenários TBR GDP Core v3.0")
        print("=" * 60)
        
        start_time = datetime.now()
        
        # Executar cenários em sequência
        contract_id = self.scenario_1_create_data_contract()
        time.sleep(1)  # Aguardar processamento
        
        quality_rule_id = self.scenario_2_quality_management()
        time.sleep(1)
        
        self.scenario_3_data_lineage_tracking(contract_id)
        time.sleep(1)
        
        self.scenario_4_permission_and_masking(contract_id)
        time.sleep(1)
        
        self.scenario_5_monitoring_and_metrics(contract_id)
        
        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds()
        
        # Calcular estatísticas
        total_scenarios = len(self.scenario_results)
        successful_scenarios = sum(1 for r in self.scenario_results if r["success"])
        success_rate = (successful_scenarios / total_scenarios) * 100 if total_scenarios > 0 else 0
        
        print("\\n" + "=" * 60)
        print("📊 RESUMO DA SIMULAÇÃO")
        print("=" * 60)
        print(f"✅ Cenários Executados: {total_scenarios}")
        print(f"✅ Cenários Bem-sucedidos: {successful_scenarios}")
        print(f"❌ Cenários Falharam: {total_scenarios - successful_scenarios}")
        print(f"📈 Taxa de Sucesso: {success_rate:.1f}%")
        print(f"⏱️ Tempo Total: {duration:.2f}s")
        
        if success_rate >= 80:
            print("🎉 SIMULAÇÃO APROVADA! Taxa de sucesso satisfatória.")
            status = "PASSED"
        else:
            print("⚠️ SIMULAÇÃO COM PROBLEMAS! Taxa de sucesso abaixo do esperado.")
            status = "FAILED"
        
        # Salvar resultados
        results = {
            "simulation_suite": "TBR GDP Core v3.0 Scenario Simulation",
            "execution_time": start_time.isoformat(),
            "duration_seconds": duration,
            "summary": {
                "total_scenarios": total_scenarios,
                "successful_scenarios": successful_scenarios,
                "failed_scenarios": total_scenarios - successful_scenarios,
                "success_rate": success_rate,
                "status": status
            },
            "scenarios": self.scenario_results,
            "created_resources": self.created_resources
        }
        
        with open("scenario_simulation_results.json", "w", encoding="utf-8") as f:
            json.dump(results, f, indent=2, ensure_ascii=False)
        
        print(f"💾 Resultados salvos em: scenario_simulation_results.json")
        
        return success_rate >= 80

def main():
    """Função principal"""
    import sys
    
    if len(sys.argv) > 1:
        base_url = sys.argv[1]
    else:
        base_url = "http://localhost:8003"
    
    print(f"🔗 URL Base: {base_url}")
    
    simulator = TBRGDPCoreScenarioSimulator(base_url)
    success = simulator.run_all_scenarios()
    
    return 0 if success else 1

if __name__ == "__main__":
    exit(main())

