#!/usr/bin/env python3
"""
TBR GDP Core v3.0 - Teste Completo da API
Teste abrangente de todos os endpoints incluindo versionamento de contratos,
monitoramento de performance e custos Azure
"""

import requests
import json
import time
import uuid
from datetime import datetime
from typing import Dict, List, Any

class TBRGDPCoreV3Tester:
    """Testador completo da API TBR GDP Core v3.0"""
    
    def __init__(self, base_url: str = "http://localhost:8004"):
        self.base_url = base_url
        self.session = requests.Session()
        self.test_results = []
        self.total_tests = 0
        self.passed_tests = 0
        self.failed_tests = 0
        
    def log_test(self, test_name: str, success: bool, response_time: float, details: str = ""):
        """Registrar resultado do teste"""
        self.total_tests += 1
        if success:
            self.passed_tests += 1
            status = "PASS"
        else:
            self.failed_tests += 1
            status = "FAIL"
        
        result = {
            "test_name": test_name,
            "status": status,
            "response_time_ms": round(response_time * 1000, 2),
            "timestamp": datetime.utcnow().isoformat(),
            "details": details
        }
        
        self.test_results.append(result)
        print(f"[{status}] {test_name} - {result['response_time_ms']}ms")
        
        if not success and details:
            print(f"      Error: {details}")
    
    def test_endpoint(self, method: str, endpoint: str, test_name: str, 
                     expected_status: int = 200, payload: Dict = None) -> bool:
        """Testar um endpoint específico"""
        url = f"{self.base_url}{endpoint}"
        start_time = time.time()
        
        try:
            if method.upper() == "GET":
                response = self.session.get(url)
            elif method.upper() == "POST":
                response = self.session.post(url, json=payload)
            elif method.upper() == "PUT":
                response = self.session.put(url, json=payload)
            elif method.upper() == "DELETE":
                response = self.session.delete(url)
            else:
                raise ValueError(f"Método HTTP não suportado: {method}")
            
            response_time = time.time() - start_time
            success = response.status_code == expected_status
            
            details = ""
            if not success:
                details = f"Status {response.status_code}, esperado {expected_status}"
                if response.text:
                    details += f" - {response.text[:100]}"
            
            self.log_test(test_name, success, response_time, details)
            return success
            
        except Exception as e:
            response_time = time.time() - start_time
            self.log_test(test_name, False, response_time, str(e))
            return False
    
    def test_health_check(self):
        """Testar health check"""
        return self.test_endpoint("GET", "/health", "Health Check")
    
    def test_entities_endpoints(self):
        """Testar endpoints de entidades"""
        tests = [
            ("GET", "/api/v3/entities/", "Listar Entidades"),
            ("GET", "/api/v3/entities/1", "Obter Entidade por ID"),
            ("GET", "/api/v3/entities/1/lineage", "Obter Linhagem de Entidade"),
            ("POST", "/api/v3/entities/1/lineage/2", "Adicionar Relacionamento de Linhagem"),
            ("GET", "/api/v3/entities/search", "Buscar Entidades"),
        ]
        
        results = []
        for method, endpoint, name in tests:
            results.append(self.test_endpoint(method, endpoint, name))
        
        return all(results)
    
    def test_contracts_endpoints(self):
        """Testar endpoints de contratos incluindo versionamento"""
        # Teste de criação de contrato
        contract_payload = {
            "name": "Contrato de Teste v3.0",
            "description": "Contrato para teste de versionamento",
            "data_source": "test_database",
            "data_consumer": "test_application",
            "version": "1.0.0"
        }
        
        tests = [
            ("GET", "/api/v3/contracts/", "Listar Contratos"),
            ("POST", "/api/v3/contracts/", "Criar Contrato", 201, contract_payload),
            ("GET", "/api/v3/contracts/1", "Obter Contrato por ID"),
            ("GET", "/api/v3/contracts/1/versions", "Listar Versões do Contrato"),
            ("POST", "/api/v3/contracts/1/versions", "Criar Nova Versão", 201, {"version": "2.0.0", "changes": "Atualização de schema"}),
            ("GET", "/api/v3/contracts/1/versions/2.0.0", "Obter Versão Específica"),
            ("POST", "/api/v3/contracts/1/approve", "Aprovar Contrato"),
            ("GET", "/api/v3/contracts/1/sla", "Obter SLA do Contrato"),
            ("GET", "/api/v3/contracts/1/lineage", "Obter Linhagem do Contrato"),
            ("GET", "/api/v3/contracts/1/masking/preview", "Preview de Mascaramento"),
        ]
        
        results = []
        for test_data in tests:
            if len(test_data) == 3:
                method, endpoint, name = test_data
                results.append(self.test_endpoint(method, endpoint, name))
            elif len(test_data) == 4:
                method, endpoint, name, status = test_data
                results.append(self.test_endpoint(method, endpoint, name, status))
            else:
                method, endpoint, name, status, payload = test_data
                results.append(self.test_endpoint(method, endpoint, name, status, payload))
        
        return all(results)
    
    def test_quality_endpoints(self):
        """Testar endpoints de qualidade"""
        rule_payload = {
            "name": "Regra de Teste",
            "description": "Regra para validação de dados",
            "rule_type": "not_null",
            "table_name": "test_table",
            "column_name": "test_column"
        }
        
        tests = [
            ("GET", "/api/v3/quality/", "Listar Regras de Qualidade"),
            ("POST", "/api/v3/quality/", "Criar Regra de Qualidade", 201, rule_payload),
            ("GET", "/api/v3/quality/1", "Obter Regra por ID"),
            ("GET", "/api/v3/quality/checks", "Listar Verificações"),
            ("POST", "/api/v3/quality/checks", "Executar Verificação", 201, {"rule_id": 1}),
            ("GET", "/api/v3/quality/issues", "Listar Problemas de Qualidade"),
            ("GET", "/api/v3/quality/dashboard", "Dashboard de Qualidade"),
        ]
        
        results = []
        for test_data in tests:
            if len(test_data) == 3:
                method, endpoint, name = test_data
                results.append(self.test_endpoint(method, endpoint, name))
            elif len(test_data) == 4:
                method, endpoint, name, status = test_data
                results.append(self.test_endpoint(method, endpoint, name, status))
            else:
                method, endpoint, name, status, payload = test_data
                results.append(self.test_endpoint(method, endpoint, name, status, payload))
        
        return all(results)
    
    def test_performance_monitoring_endpoints(self):
        """Testar endpoints de monitoramento de performance"""
        tests = [
            ("GET", "/api/v3/monitoring/performance/queries/slow", "Consultas Lentas"),
            ("GET", "/api/v3/monitoring/performance/queries/stats", "Estatísticas de Consultas"),
            ("POST", "/api/v3/monitoring/performance/queries/optimize", "Otimizar Consultas", 200, {"table_name": "test_table"}),
            ("GET", "/api/v3/monitoring/performance/performance/dashboard", "Dashboard de Performance"),
            ("POST", "/api/v3/monitoring/performance/monitoring/configure", "Configurar Monitoramento", 200, {"slow_query_threshold_ms": 2000}),
            ("GET", "/api/v3/monitoring/performance/monitoring/health", "Saúde do Monitoramento"),
        ]
        
        results = []
        for test_data in tests:
            if len(test_data) == 3:
                method, endpoint, name = test_data
                results.append(self.test_endpoint(method, endpoint, name))
            elif len(test_data) == 4:
                method, endpoint, name, status = test_data
                results.append(self.test_endpoint(method, endpoint, name, status))
            else:
                method, endpoint, name, status, payload = test_data
                results.append(self.test_endpoint(method, endpoint, name, status, payload))
        
        return all(results)
    
    def test_azure_cost_monitoring_endpoints(self):
        """Testar endpoints de monitoramento de custos Azure"""
        alert_payload = {
            "name": "Alerta de Teste",
            "threshold_type": "absolute",
            "threshold_value": 1000.0,
            "currency": "USD"
        }
        
        budget_payload = {
            "monthly_budget": 15000.0,
            "alert_threshold_percent": 85
        }
        
        tests = [
            ("GET", "/api/v3/monitoring/costs/costs/current", "Custos Atuais"),
            ("GET", "/api/v3/monitoring/costs/costs/trends", "Tendências de Custos"),
            ("GET", "/api/v3/monitoring/costs/costs/optimization", "Recomendações de Otimização"),
            ("POST", "/api/v3/monitoring/costs/costs/alerts", "Criar Alerta de Custo", 200, alert_payload),
            ("GET", "/api/v3/monitoring/costs/costs/alerts", "Listar Alertas"),
            ("GET", "/api/v3/monitoring/costs/costs/dashboard", "Dashboard de Custos"),
            ("POST", "/api/v3/monitoring/costs/costs/budget", "Configurar Orçamento", 200, budget_payload),
        ]
        
        results = []
        for test_data in tests:
            if len(test_data) == 3:
                method, endpoint, name = test_data
                results.append(self.test_endpoint(method, endpoint, name))
            elif len(test_data) == 4:
                method, endpoint, name, status = test_data
                results.append(self.test_endpoint(method, endpoint, name, status))
            else:
                method, endpoint, name, status, payload = test_data
                results.append(self.test_endpoint(method, endpoint, name, status, payload))
        
        return all(results)
    
    def test_other_domains(self):
        """Testar outros domínios"""
        tests = [
            ("GET", "/api/v3/policies/", "Listar Políticas"),
            ("GET", "/api/v3/analytics/", "Listar Analytics"),
            ("GET", "/api/v3/integrations/", "Listar Integrações"),
            ("GET", "/api/v3/governance/", "Listar Governança"),
            ("GET", "/api/v3/monitoring/", "Listar Monitoramento"),
            ("GET", "/api/v3/automation/", "Listar Automação"),
            ("GET", "/api/v3/marketplace/", "Listar Marketplace"),
        ]
        
        results = []
        for method, endpoint, name in tests:
            results.append(self.test_endpoint(method, endpoint, name))
        
        return all(results)
    
    def run_comprehensive_test(self):
        """Executar teste abrangente de toda a API"""
        print("=== INICIANDO TESTE COMPLETO TBR GDP CORE v3.0 ===")
        print(f"Base URL: {self.base_url}")
        print(f"Timestamp: {datetime.utcnow().isoformat()}")
        print()
        
        # Executar todos os testes
        test_suites = [
            ("Health Check", self.test_health_check),
            ("Entidades", self.test_entities_endpoints),
            ("Contratos (com Versionamento)", self.test_contracts_endpoints),
            ("Qualidade", self.test_quality_endpoints),
            ("Monitoramento de Performance", self.test_performance_monitoring_endpoints),
            ("Monitoramento de Custos Azure", self.test_azure_cost_monitoring_endpoints),
            ("Outros Domínios", self.test_other_domains),
        ]
        
        suite_results = {}
        
        for suite_name, test_function in test_suites:
            print(f"\n--- Testando {suite_name} ---")
            suite_results[suite_name] = test_function()
        
        # Calcular estatísticas finais
        success_rate = (self.passed_tests / self.total_tests * 100) if self.total_tests > 0 else 0
        
        # Gerar relatório final
        report = {
            "test_summary": {
                "total_tests": self.total_tests,
                "passed_tests": self.passed_tests,
                "failed_tests": self.failed_tests,
                "success_rate": round(success_rate, 2),
                "test_duration": "completed",
                "timestamp": datetime.utcnow().isoformat()
            },
            "suite_results": suite_results,
            "detailed_results": self.test_results,
            "api_version": "3.0.0",
            "base_url": self.base_url,
            "new_features_tested": [
                "Versionamento de Contratos",
                "Monitoramento de Performance de Consultas",
                "Monitoramento de Custos Azure",
                "Otimização Automática de Consultas",
                "Alertas de Custo Personalizados",
                "Dashboard de Performance em Tempo Real"
            ]
        }
        
        # Salvar resultados
        with open("test_results_v3_complete_updated.json", "w") as f:
            json.dump(report, f, indent=2)
        
        # Exibir resumo
        print("\n" + "="*60)
        print("RESUMO DOS TESTES TBR GDP CORE v3.0")
        print("="*60)
        print(f"Total de Testes: {self.total_tests}")
        print(f"Testes Aprovados: {self.passed_tests}")
        print(f"Testes Falharam: {self.failed_tests}")
        print(f"Taxa de Sucesso: {success_rate:.2f}%")
        print()
        
        print("RESULTADOS POR SUITE:")
        for suite_name, result in suite_results.items():
            status = "✅ PASS" if result else "❌ FAIL"
            print(f"  {suite_name}: {status}")
        
        print()
        print("NOVAS FUNCIONALIDADES TESTADAS:")
        for feature in report["new_features_tested"]:
            print(f"  ✅ {feature}")
        
        print(f"\nResultados salvos em: test_results_v3_complete_updated.json")
        
        return success_rate >= 80.0

def main():
    """Função principal"""
    tester = TBRGDPCoreV3Tester()
    success = tester.run_comprehensive_test()
    
    if success:
        print("\n🎉 TESTE COMPLETO APROVADO! API v3.0 está funcionando corretamente.")
        exit(0)
    else:
        print("\n⚠️  TESTE COMPLETO COM FALHAS. Revisar problemas identificados.")
        exit(1)

if __name__ == "__main__":
    main()

