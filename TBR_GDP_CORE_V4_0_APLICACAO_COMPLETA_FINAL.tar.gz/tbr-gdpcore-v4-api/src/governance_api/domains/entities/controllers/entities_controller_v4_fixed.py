"""
TBR GDP Core v4.0 - Entities Controller (Fixed)
Author: Carlos Morais <carlos.morais@f1rst.com.br>

Controller para gerenciamento de entidades com busca corrigida.
"""

from fastapi import APIRouter, HTTPException, Query, Path, Body, Depends
from typing import List, Optional
from datetime import datetime
import logging

# Configurar logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

router = APIRouter()

# Mock database dependency
def get_db():
    return None

@router.get("/search")
async def search_entities(
    q: Optional[str] = Query(None, description="Termo de busca"),
    entity_type: Optional[str] = Query(None, description="Tipo de entidade"),
    classification: Optional[str] = Query(None, description="Classificação"),
    domain_id: Optional[int] = Query(None, description="ID do domínio"),
    limit: int = Query(20, description="Limite de resultados"),
    offset: int = Query(0, description="Offset para paginação")
):
    """Buscar entidades com filtros avançados"""
    try:
        # Mock entities data
        all_entities = [
            {
                "id": 1,
                "name": "customer_profiles",
                "display_name": "Perfis de Clientes",
                "description": "Dados consolidados de perfis de clientes",
                "domain_id": 1,
                "entity_type": "table",
                "classification": "confidential",
                "owner": "data_team",
                "quality_score": 95,
                "is_active": True,
                "created_at": "2025-01-01T00:00:00",
                "updated_at": "2025-01-01T00:00:00"
            },
            {
                "id": 2,
                "name": "order_transactions",
                "display_name": "Transações de Pedidos",
                "description": "Histórico de transações de pedidos",
                "domain_id": 2,
                "entity_type": "table",
                "classification": "internal",
                "owner": "finance_team",
                "quality_score": 88,
                "is_active": True,
                "created_at": "2025-01-01T00:00:00",
                "updated_at": "2025-01-01T00:00:00"
            },
            {
                "id": 3,
                "name": "product_catalog",
                "display_name": "Catálogo de Produtos",
                "description": "Informações detalhadas de produtos",
                "domain_id": 3,
                "entity_type": "view",
                "classification": "public",
                "owner": "product_team",
                "quality_score": 92,
                "is_active": True,
                "created_at": "2025-01-01T00:00:00",
                "updated_at": "2025-01-01T00:00:00"
            },
            {
                "id": 4,
                "name": "sales_analytics",
                "display_name": "Analytics de Vendas",
                "description": "Métricas e KPIs de vendas",
                "domain_id": 2,
                "entity_type": "model",
                "classification": "confidential",
                "owner": "analytics_team",
                "quality_score": 90,
                "is_active": True,
                "created_at": "2025-01-01T00:00:00",
                "updated_at": "2025-01-01T00:00:00"
            },
            {
                "id": 5,
                "name": "customer_support_tickets",
                "display_name": "Tickets de Suporte",
                "description": "Histórico de tickets de suporte ao cliente",
                "domain_id": 1,
                "entity_type": "table",
                "classification": "internal",
                "owner": "support_team",
                "quality_score": 85,
                "is_active": True,
                "created_at": "2025-01-01T00:00:00",
                "updated_at": "2025-01-01T00:00:00"
            }
        ]
        
        # Aplicar filtros
        filtered_entities = all_entities.copy()
        
        # Filtro por termo de busca
        if q:
            filtered_entities = [
                e for e in filtered_entities 
                if (q.lower() in e["name"].lower() or 
                    q.lower() in e["display_name"].lower() or 
                    q.lower() in e["description"].lower())
            ]
        
        # Filtro por tipo de entidade
        if entity_type:
            filtered_entities = [
                e for e in filtered_entities 
                if e["entity_type"].lower() == entity_type.lower()
            ]
        
        # Filtro por classificação
        if classification:
            filtered_entities = [
                e for e in filtered_entities 
                if e["classification"].lower() == classification.lower()
            ]
        
        # Filtro por domínio
        if domain_id:
            filtered_entities = [
                e for e in filtered_entities 
                if e["domain_id"] == domain_id
            ]
        
        # Aplicar paginação
        total = len(filtered_entities)
        paginated_entities = filtered_entities[offset:offset + limit]
        
        result = {
            "entities": paginated_entities,
            "total": total,
            "limit": limit,
            "offset": offset,
            "filters_applied": {
                "search_term": q,
                "entity_type": entity_type,
                "classification": classification,
                "domain_id": domain_id
            },
            "timestamp": datetime.utcnow().isoformat()
        }
        
        logger.info(f"Busca realizada: {len(paginated_entities)} resultados de {total} total")
        return result
        
    except Exception as e:
        logger.error(f"Erro na busca de entidades: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.get("/")
async def list_entities(
    search: Optional[str] = Query(None, description="Termo de busca"),
    domain_id: Optional[int] = Query(None, description="ID do domínio"),
    entity_type: Optional[str] = Query(None, description="Tipo de entidade"),
    classification: Optional[str] = Query(None, description="Classificação"),
    limit: int = Query(20, description="Limite de resultados"),
    skip: int = Query(0, description="Pular registros"),
    db = Depends(get_db)
):
    """Listar entidades com filtros opcionais"""
    try:
        # Mock entities data
        entities = [
            {
                "id": 1,
                "name": "customer_profiles",
                "display_name": "Perfis de Clientes",
                "description": "Dados consolidados de perfis de clientes",
                "domain_id": 1,
                "entity_type": "table",
                "classification": "confidential",
                "owner_id": 1,
                "quality_score": 95,
                "is_active": True,
                "created_at": "2025-01-01T00:00:00",
                "updated_at": "2025-01-01T00:00:00"
            },
            {
                "id": 2,
                "name": "order_transactions",
                "display_name": "Transações de Pedidos",
                "description": "Histórico de transações de pedidos",
                "domain_id": 2,
                "entity_type": "table",
                "classification": "internal",
                "owner_id": 2,
                "quality_score": 88,
                "is_active": True,
                "created_at": "2025-01-01T00:00:00",
                "updated_at": "2025-01-01T00:00:00"
            }
        ]
        
        # Aplicar filtros básicos
        if search:
            entities = [e for e in entities if search.lower() in e["name"].lower() or search.lower() in e["display_name"].lower()]
        
        if domain_id:
            entities = [e for e in entities if e["domain_id"] == domain_id]
            
        if entity_type:
            entities = [e for e in entities if e["entity_type"] == entity_type]
            
        if classification:
            entities = [e for e in entities if e["classification"] == classification]
        
        # Aplicar paginação
        total = len(entities)
        entities = entities[skip:skip + limit]
        
        logger.info(f"Listando {len(entities)} entidades (total: {total})")
        return entities
        
    except Exception as e:
        logger.error(f"Erro ao listar entidades: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.get("/{entity_id}")
async def get_entity(
    entity_id: int = Path(..., description="ID da entidade"),
    db = Depends(get_db)
):
    """Obter entidade por ID"""
    try:
        # Mock data
        if entity_id == 1:
            entity = {
                "id": 1,
                "name": "customer_profiles",
                "display_name": "Perfis de Clientes",
                "description": "Dados consolidados de perfis de clientes",
                "domain_id": 1,
                "entity_type": "table",
                "classification": "confidential",
                "owner_id": 1,
                "quality_score": 95,
                "is_active": True,
                "created_at": "2025-01-01T00:00:00",
                "updated_at": "2025-01-01T00:00:00",
                "schema": {
                    "columns": [
                        {"name": "customer_id", "type": "integer", "nullable": False},
                        {"name": "full_name", "type": "varchar", "nullable": False},
                        {"name": "email", "type": "varchar", "nullable": False},
                        {"name": "phone", "type": "varchar", "nullable": True}
                    ]
                },
                "metadata": {
                    "source_system": "CRM",
                    "update_frequency": "daily",
                    "data_retention": "7 years"
                }
            }
            return entity
        else:
            raise HTTPException(status_code=404, detail="Entidade não encontrada")
            
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao obter entidade {entity_id}: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.get("/{entity_id}/lineage")
async def get_entity_lineage(
    entity_id: int = Path(..., description="ID da entidade"),
    direction: str = Query("both", description="Direção da linhagem: upstream, downstream, both"),
    depth: int = Query(3, description="Profundidade da linhagem"),
    db = Depends(get_db)
):
    """Obter linhagem da entidade"""
    try:
        if entity_id != 1:
            raise HTTPException(status_code=404, detail="Entidade não encontrada")
        
        lineage = {
            "entity_id": entity_id,
            "entity_name": "customer_profiles",
            "direction": direction,
            "depth": depth,
            "upstream": [
                {
                    "entity_id": 10,
                    "entity_name": "raw_customer_data",
                    "relationship_type": "derives_from",
                    "transformation": "Data cleansing and normalization"
                },
                {
                    "entity_id": 11,
                    "entity_name": "customer_interactions",
                    "relationship_type": "enriched_by",
                    "transformation": "Behavioral data aggregation"
                }
            ],
            "downstream": [
                {
                    "entity_id": 20,
                    "entity_name": "customer_segments",
                    "relationship_type": "feeds_into",
                    "transformation": "Segmentation algorithm"
                },
                {
                    "entity_id": 21,
                    "entity_name": "marketing_campaigns",
                    "relationship_type": "used_by",
                    "transformation": "Campaign targeting"
                }
            ],
            "total_upstream": 2,
            "total_downstream": 2,
            "generated_at": datetime.utcnow().isoformat()
        }
        
        return lineage
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao obter linhagem da entidade {entity_id}: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

