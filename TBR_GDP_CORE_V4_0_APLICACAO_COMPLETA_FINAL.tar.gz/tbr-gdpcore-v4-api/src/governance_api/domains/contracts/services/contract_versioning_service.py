"""
TBR GDP Core v3.0 - Service de Versionamento de Contratos
Implementação completa de versionamento avançado e workflows
"""

from sqlalchemy.orm import Session
from typing import List, Optional, Dict, Any, Tuple
from datetime import datetime, timedelta
import json
import uuid
from enum import Enum

from governance_api.domains.contracts.models.contract import Contract
from governance_api.domains.contracts.schemas.contract_schemas import (
    ContractCreate, ContractUpdate, ContractResponse
)
from governance_api.shared.services import BaseService

class VersionAction(str, Enum):
    CREATED = "created"
    UPDATED = "updated"
    APPROVED = "approved"
    REJECTED = "rejected"
    DEPRECATED = "deprecated"
    ARCHIVED = "archived"
    RESTORED = "restored"

class ChangeType(str, Enum):
    MAJOR = "major"          # Breaking changes
    MINOR = "minor"          # New features, backward compatible
    PATCH = "patch"          # Bug fixes, backward compatible
    HOTFIX = "hotfix"        # Critical fixes

class WorkflowStatus(str, Enum):
    DRAFT = "draft"
    PENDING_REVIEW = "pending_review"
    IN_REVIEW = "in_review"
    PENDING_APPROVAL = "pending_approval"
    APPROVED = "approved"
    REJECTED = "rejected"
    PUBLISHED = "published"
    DEPRECATED = "deprecated"
    ARCHIVED = "archived"

class ContractVersioningService(BaseService):
    def __init__(self, db: Session):
        super().__init__(db)
    
    # === VERSION MANAGEMENT ===
    
    def create_new_version(self, 
                          contract_id: int, 
                          changes: Dict[str, Any],
                          change_type: ChangeType = ChangeType.MINOR,
                          created_by: str = "system") -> Dict[str, Any]:
        """Criar nova versão de um contrato"""
        
        # Obter contrato atual
        current_contract = self.db.query(Contract).filter(Contract.id == contract_id).first()
        if not current_contract:
            raise ValueError(f"Contract {contract_id} not found")
        
        # Determinar nova versão
        current_version = current_contract.version or "1.0.0"
        new_version = self._calculate_next_version(current_version, change_type)
        
        # Criar registro de versão
        version_data = {
            "contract_id": contract_id,
            "version": new_version,
            "previous_version": current_version,
            "change_type": change_type.value,
            "changes": changes,
            "created_by": created_by,
            "created_at": datetime.utcnow(),
            "status": WorkflowStatus.DRAFT.value,
            "is_current": False,
            "metadata": {
                "change_summary": self._generate_change_summary(changes),
                "impact_analysis": self._analyze_impact(changes),
                "compatibility": self._check_compatibility(current_contract, changes)
            }
        }
        
        # Simular salvamento (em produção seria salvo no banco)
        version_id = self._generate_version_id()
        
        return {
            "version_id": version_id,
            "contract_id": contract_id,
            "version": new_version,
            "previous_version": current_version,
            "change_type": change_type.value,
            "status": WorkflowStatus.DRAFT.value,
            "created_by": created_by,
            "created_at": datetime.utcnow(),
            "changes": changes,
            "metadata": version_data["metadata"]
        }
    
    def get_version_history(self, contract_id: int) -> List[Dict[str, Any]]:
        """Obter histórico de versões de um contrato"""
        
        # Mock data para demonstração
        versions = [
            {
                "version_id": "ver_001",
                "contract_id": contract_id,
                "version": "3.1.0",
                "previous_version": "3.0.2",
                "change_type": "minor",
                "status": "published",
                "created_by": "data_steward_001",
                "created_at": datetime.utcnow() - timedelta(days=1),
                "approved_at": datetime.utcnow() - timedelta(hours=2),
                "approved_by": "governance_manager",
                "is_current": True,
                "changes": {
                    "schema_changes": ["Added new field: customer_segment"],
                    "quality_rules": ["Updated email validation rule"],
                    "access_policies": ["Added read access for analytics team"]
                },
                "metadata": {
                    "change_summary": "Added customer segmentation support",
                    "impact_analysis": "Low impact - backward compatible",
                    "compatibility": "backward_compatible"
                }
            },
            {
                "version_id": "ver_002",
                "contract_id": contract_id,
                "version": "3.0.2",
                "previous_version": "3.0.1",
                "change_type": "patch",
                "status": "published",
                "created_by": "data_engineer_002",
                "created_at": datetime.utcnow() - timedelta(days=7),
                "approved_at": datetime.utcnow() - timedelta(days=6),
                "approved_by": "data_steward_001",
                "is_current": False,
                "changes": {
                    "quality_rules": ["Fixed phone number validation regex"],
                    "documentation": ["Updated field descriptions"]
                },
                "metadata": {
                    "change_summary": "Bug fixes and documentation updates",
                    "impact_analysis": "No impact - patch release",
                    "compatibility": "fully_compatible"
                }
            },
            {
                "version_id": "ver_003",
                "contract_id": contract_id,
                "version": "3.0.1",
                "previous_version": "3.0.0",
                "change_type": "patch",
                "status": "published",
                "created_by": "data_steward_001",
                "created_at": datetime.utcnow() - timedelta(days=14),
                "approved_at": datetime.utcnow() - timedelta(days=13),
                "approved_by": "governance_manager",
                "is_current": False,
                "changes": {
                    "quality_rules": ["Added null check for required fields"],
                    "access_policies": ["Restricted delete access"]
                },
                "metadata": {
                    "change_summary": "Enhanced data quality and security",
                    "impact_analysis": "Low impact - additional validations",
                    "compatibility": "backward_compatible"
                }
            }
        ]
        
        return sorted(versions, key=lambda x: x["created_at"], reverse=True)
    
    def compare_versions(self, 
                        contract_id: int, 
                        version1: str, 
                        version2: str) -> Dict[str, Any]:
        """Comparar duas versões de um contrato"""
        
        # Obter dados das versões (mock)
        version1_data = self._get_version_data(contract_id, version1)
        version2_data = self._get_version_data(contract_id, version2)
        
        # Realizar comparação
        comparison = {
            "contract_id": contract_id,
            "version1": version1,
            "version2": version2,
            "comparison_timestamp": datetime.utcnow(),
            "differences": {
                "schema_changes": self._compare_schemas(version1_data, version2_data),
                "quality_rules": self._compare_quality_rules(version1_data, version2_data),
                "access_policies": self._compare_access_policies(version1_data, version2_data),
                "metadata_changes": self._compare_metadata(version1_data, version2_data)
            },
            "summary": {
                "total_changes": 0,
                "breaking_changes": 0,
                "new_features": 0,
                "bug_fixes": 0,
                "compatibility_impact": "backward_compatible"
            }
        }
        
        # Calcular resumo
        total_changes = sum(len(changes) for changes in comparison["differences"].values())
        comparison["summary"]["total_changes"] = total_changes
        
        return comparison
    
    def approve_version(self, 
                       version_id: str, 
                       approved_by: str,
                       approval_notes: Optional[str] = None) -> Dict[str, Any]:
        """Aprovar uma versão específica"""
        
        # Simular aprovação
        approval_data = {
            "version_id": version_id,
            "approved_by": approved_by,
            "approved_at": datetime.utcnow(),
            "approval_notes": approval_notes,
            "status": WorkflowStatus.APPROVED.value,
            "next_steps": [
                "Version ready for publication",
                "Stakeholders will be notified",
                "Deployment can proceed"
            ]
        }
        
        return approval_data
    
    def reject_version(self, 
                      version_id: str, 
                      rejected_by: str,
                      rejection_reason: str) -> Dict[str, Any]:
        """Rejeitar uma versão específica"""
        
        rejection_data = {
            "version_id": version_id,
            "rejected_by": rejected_by,
            "rejected_at": datetime.utcnow(),
            "rejection_reason": rejection_reason,
            "status": WorkflowStatus.REJECTED.value,
            "next_steps": [
                "Review rejection feedback",
                "Make necessary changes",
                "Resubmit for approval"
            ]
        }
        
        return rejection_data
    
    def publish_version(self, version_id: str, published_by: str) -> Dict[str, Any]:
        """Publicar uma versão aprovada"""
        
        publication_data = {
            "version_id": version_id,
            "published_by": published_by,
            "published_at": datetime.utcnow(),
            "status": WorkflowStatus.PUBLISHED.value,
            "is_current": True,
            "publication_details": {
                "notification_sent": True,
                "documentation_updated": True,
                "apis_updated": True,
                "consumers_notified": True
            }
        }
        
        return publication_data
    
    def rollback_version(self, 
                        contract_id: int, 
                        target_version: str,
                        rollback_reason: str,
                        performed_by: str) -> Dict[str, Any]:
        """Fazer rollback para uma versão anterior"""
        
        rollback_data = {
            "contract_id": contract_id,
            "target_version": target_version,
            "rollback_reason": rollback_reason,
            "performed_by": performed_by,
            "rollback_timestamp": datetime.utcnow(),
            "rollback_id": str(uuid.uuid4()),
            "impact_assessment": {
                "affected_consumers": 15,
                "data_pipelines_affected": 8,
                "estimated_downtime": "5 minutes",
                "rollback_complexity": "medium"
            },
            "rollback_steps": [
                "Backup current version",
                "Update contract metadata",
                "Notify affected consumers",
                "Update API documentation",
                "Validate rollback success"
            ]
        }
        
        return rollback_data
    
    # === WORKFLOW MANAGEMENT ===
    
    def start_approval_workflow(self, version_id: str, initiated_by: str) -> Dict[str, Any]:
        """Iniciar workflow de aprovação"""
        
        workflow_data = {
            "workflow_id": str(uuid.uuid4()),
            "version_id": version_id,
            "initiated_by": initiated_by,
            "initiated_at": datetime.utcnow(),
            "current_stage": "technical_review",
            "status": "active",
            "stages": [
                {
                    "stage": "technical_review",
                    "assignee": "data_engineer_lead",
                    "status": "pending",
                    "estimated_duration": "2 hours",
                    "checklist": [
                        "Schema validation",
                        "Quality rules review",
                        "Performance impact assessment"
                    ]
                },
                {
                    "stage": "business_review",
                    "assignee": "data_steward_001",
                    "status": "waiting",
                    "estimated_duration": "4 hours",
                    "checklist": [
                        "Business logic validation",
                        "Compliance check",
                        "Stakeholder impact review"
                    ]
                },
                {
                    "stage": "governance_approval",
                    "assignee": "governance_manager",
                    "status": "waiting",
                    "estimated_duration": "1 hour",
                    "checklist": [
                        "Final governance review",
                        "Risk assessment",
                        "Approval decision"
                    ]
                }
            ],
            "estimated_completion": datetime.utcnow() + timedelta(hours=7)
        }
        
        return workflow_data
    
    def get_workflow_status(self, workflow_id: str) -> Dict[str, Any]:
        """Obter status do workflow"""
        
        # Mock data
        return {
            "workflow_id": workflow_id,
            "version_id": "ver_001",
            "current_stage": "business_review",
            "status": "active",
            "progress": 66.7,  # 2 de 3 estágios
            "started_at": datetime.utcnow() - timedelta(hours=3),
            "estimated_completion": datetime.utcnow() + timedelta(hours=4),
            "stages_completed": [
                {
                    "stage": "technical_review",
                    "completed_by": "data_engineer_lead",
                    "completed_at": datetime.utcnow() - timedelta(hours=1),
                    "result": "approved",
                    "notes": "All technical validations passed"
                }
            ],
            "current_stage_details": {
                "stage": "business_review",
                "assignee": "data_steward_001",
                "started_at": datetime.utcnow() - timedelta(minutes=30),
                "checklist_progress": {
                    "business_logic_validation": "completed",
                    "compliance_check": "in_progress",
                    "stakeholder_impact_review": "pending"
                }
            }
        }
    
    def advance_workflow_stage(self, 
                              workflow_id: str, 
                              stage_result: str,
                              notes: Optional[str] = None,
                              completed_by: str = "system") -> Dict[str, Any]:
        """Avançar estágio do workflow"""
        
        return {
            "workflow_id": workflow_id,
            "stage_completed": "business_review",
            "result": stage_result,
            "completed_by": completed_by,
            "completed_at": datetime.utcnow(),
            "notes": notes,
            "next_stage": "governance_approval" if stage_result == "approved" else None,
            "workflow_status": "active" if stage_result == "approved" else "rejected"
        }
    
    # === CHANGE IMPACT ANALYSIS ===
    
    def analyze_change_impact(self, 
                             contract_id: int, 
                             proposed_changes: Dict[str, Any]) -> Dict[str, Any]:
        """Analisar impacto de mudanças propostas"""
        
        impact_analysis = {
            "contract_id": contract_id,
            "analysis_timestamp": datetime.utcnow(),
            "change_summary": self._generate_change_summary(proposed_changes),
            "impact_categories": {
                "data_consumers": self._analyze_consumer_impact(contract_id, proposed_changes),
                "data_pipelines": self._analyze_pipeline_impact(contract_id, proposed_changes),
                "quality_rules": self._analyze_quality_impact(proposed_changes),
                "access_control": self._analyze_access_impact(proposed_changes),
                "compliance": self._analyze_compliance_impact(proposed_changes)
            },
            "risk_assessment": {
                "overall_risk": "medium",
                "breaking_changes": False,
                "data_loss_risk": "low",
                "performance_impact": "minimal",
                "security_impact": "none"
            },
            "recommendations": [
                "Test changes in staging environment",
                "Notify affected data consumers 48h in advance",
                "Prepare rollback plan",
                "Monitor data quality metrics post-deployment"
            ],
            "estimated_effort": {
                "development_hours": 4,
                "testing_hours": 2,
                "deployment_hours": 1,
                "total_hours": 7
            }
        }
        
        return impact_analysis
    
    def get_dependency_graph(self, contract_id: int) -> Dict[str, Any]:
        """Obter grafo de dependências do contrato"""
        
        return {
            "contract_id": contract_id,
            "dependencies": {
                "upstream_contracts": [
                    {
                        "contract_id": 101,
                        "name": "Customer Master Data",
                        "relationship": "provides_customer_data",
                        "impact_level": "high"
                    },
                    {
                        "contract_id": 102,
                        "name": "Product Catalog",
                        "relationship": "provides_product_data",
                        "impact_level": "medium"
                    }
                ],
                "downstream_consumers": [
                    {
                        "consumer_id": "analytics_team",
                        "consumer_type": "team",
                        "usage_pattern": "daily_batch",
                        "impact_level": "high"
                    },
                    {
                        "consumer_id": "reporting_service",
                        "consumer_type": "service",
                        "usage_pattern": "real_time",
                        "impact_level": "critical"
                    },
                    {
                        "consumer_id": "ml_pipeline",
                        "consumer_type": "pipeline",
                        "usage_pattern": "weekly_training",
                        "impact_level": "medium"
                    }
                ],
                "related_contracts": [
                    {
                        "contract_id": 201,
                        "name": "Customer Analytics Contract",
                        "relationship": "shares_customer_data",
                        "impact_level": "medium"
                    }
                ]
            },
            "impact_radius": {
                "direct_dependencies": 5,
                "indirect_dependencies": 12,
                "total_affected_entities": 17
            }
        }
    
    # === HELPER METHODS ===
    
    def _calculate_next_version(self, current_version: str, change_type: ChangeType) -> str:
        """Calcular próxima versão baseada no tipo de mudança"""
        try:
            major, minor, patch = map(int, current_version.split('.'))
            
            if change_type == ChangeType.MAJOR:
                return f"{major + 1}.0.0"
            elif change_type == ChangeType.MINOR:
                return f"{major}.{minor + 1}.0"
            elif change_type in [ChangeType.PATCH, ChangeType.HOTFIX]:
                return f"{major}.{minor}.{patch + 1}"
            
        except ValueError:
            # Fallback para versões não semânticas
            return f"{current_version}.1"
        
        return current_version
    
    def _generate_change_summary(self, changes: Dict[str, Any]) -> str:
        """Gerar resumo das mudanças"""
        summaries = []
        
        if "schema_changes" in changes:
            summaries.append(f"{len(changes['schema_changes'])} schema changes")
        
        if "quality_rules" in changes:
            summaries.append(f"{len(changes['quality_rules'])} quality rule updates")
        
        if "access_policies" in changes:
            summaries.append(f"{len(changes['access_policies'])} access policy changes")
        
        return ", ".join(summaries) if summaries else "Minor updates"
    
    def _analyze_impact(self, changes: Dict[str, Any]) -> str:
        """Analisar impacto das mudanças"""
        if any("breaking" in str(change).lower() for change in changes.values()):
            return "High impact - breaking changes detected"
        elif len(changes) > 5:
            return "Medium impact - multiple changes"
        else:
            return "Low impact - minor changes"
    
    def _check_compatibility(self, current_contract, changes: Dict[str, Any]) -> str:
        """Verificar compatibilidade das mudanças"""
        # Lógica simplificada
        if "schema_changes" in changes:
            schema_changes = changes["schema_changes"]
            if any("removed" in str(change).lower() for change in schema_changes):
                return "breaking_change"
            elif any("added" in str(change).lower() for change in schema_changes):
                return "backward_compatible"
        
        return "fully_compatible"
    
    def _generate_version_id(self) -> str:
        """Gerar ID único para versão"""
        return f"ver_{uuid.uuid4().hex[:8]}"
    
    def _get_version_data(self, contract_id: int, version: str) -> Dict[str, Any]:
        """Obter dados de uma versão específica (mock)"""
        return {
            "contract_id": contract_id,
            "version": version,
            "schema": {"fields": ["id", "name", "email"]},
            "quality_rules": ["email_format", "not_null"],
            "access_policies": ["read_access", "write_access"],
            "metadata": {"description": "Sample contract"}
        }
    
    def _compare_schemas(self, version1_data: Dict, version2_data: Dict) -> List[str]:
        """Comparar schemas entre versões"""
        return ["Added field: customer_segment", "Modified field: email (validation updated)"]
    
    def _compare_quality_rules(self, version1_data: Dict, version2_data: Dict) -> List[str]:
        """Comparar regras de qualidade entre versões"""
        return ["Updated email validation rule", "Added phone number validation"]
    
    def _compare_access_policies(self, version1_data: Dict, version2_data: Dict) -> List[str]:
        """Comparar políticas de acesso entre versões"""
        return ["Added read access for analytics team", "Restricted delete access"]
    
    def _compare_metadata(self, version1_data: Dict, version2_data: Dict) -> List[str]:
        """Comparar metadados entre versões"""
        return ["Updated description", "Added tags: customer, analytics"]
    
    def _analyze_consumer_impact(self, contract_id: int, changes: Dict[str, Any]) -> Dict[str, Any]:
        """Analisar impacto nos consumidores"""
        return {
            "affected_consumers": 15,
            "impact_level": "medium",
            "notification_required": True,
            "migration_effort": "low"
        }
    
    def _analyze_pipeline_impact(self, contract_id: int, changes: Dict[str, Any]) -> Dict[str, Any]:
        """Analisar impacto nos pipelines"""
        return {
            "affected_pipelines": 8,
            "impact_level": "low",
            "testing_required": True,
            "estimated_downtime": "5 minutes"
        }
    
    def _analyze_quality_impact(self, changes: Dict[str, Any]) -> Dict[str, Any]:
        """Analisar impacto na qualidade"""
        return {
            "quality_improvement": True,
            "new_validations": 2,
            "stricter_rules": False,
            "data_rejection_risk": "low"
        }
    
    def _analyze_access_impact(self, changes: Dict[str, Any]) -> Dict[str, Any]:
        """Analisar impacto no controle de acesso"""
        return {
            "access_changes": True,
            "new_permissions": 1,
            "revoked_permissions": 0,
            "security_improvement": True
        }
    
    def _analyze_compliance_impact(self, changes: Dict[str, Any]) -> Dict[str, Any]:
        """Analisar impacto na compliance"""
        return {
            "compliance_maintained": True,
            "new_requirements": False,
            "audit_trail_updated": True,
            "regulatory_impact": "none"
        }

