"""
TBR GDP Core v4.0 - Contracts Controller (Fixed)
Author: Carlos Morais <carlos.morais@f1rst.com.br>

Controller para gerenciamento de contratos com versionamento corrigido.
"""

from fastapi import APIRouter, HTTPException, Query, Path, Body, Depends
from typing import List, Optional, Dict, Any
from datetime import datetime
import logging

# Configurar logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

router = APIRouter()

# Mock database dependency
def get_db():
    return None

@router.get("/{contract_id}/versions/compare")
async def compare_contract_versions(
    contract_id: int = Path(..., description="ID do contrato"),
    version1: str = Query(..., description="Primeira versão para comparação"),
    version2: str = Query(..., description="Segunda versão para comparação"),
    db = Depends(get_db)
):
    """Comparar duas versões de um contrato"""
    try:
        # Verificar se o contrato existe
        if contract_id not in [1, 2, 3]:
            raise HTTPException(status_code=404, detail="Contrato não encontrado")
        
        # Mock versions data - criar versões que existem para teste
        available_versions = {
            1: {
                "1.0.0": {
                    "version": "1.0.0",
                    "created_at": "2024-01-01T00:00:00",
                    "schema": {
                        "fields": [
                            {"name": "customer_id", "type": "integer", "required": True},
                            {"name": "name", "type": "string", "required": True},
                            {"name": "email", "type": "string", "required": True}
                        ]
                    },
                    "quality_rules": [
                        {"field": "email", "rule": "email_format", "threshold": 0.95}
                    ],
                    "access_policies": {
                        "read": ["data_analyst", "data_engineer"],
                        "write": ["data_engineer"]
                    }
                },
                "1.1.0": {
                    "version": "1.1.0",
                    "created_at": "2024-02-01T00:00:00",
                    "schema": {
                        "fields": [
                            {"name": "customer_id", "type": "integer", "required": True},
                            {"name": "name", "type": "string", "required": True},
                            {"name": "email", "type": "string", "required": True},
                            {"name": "phone", "type": "string", "required": False}  # Campo adicionado
                        ]
                    },
                    "quality_rules": [
                        {"field": "email", "rule": "email_format", "threshold": 0.95},
                        {"field": "phone", "rule": "phone_format", "threshold": 0.90}  # Nova regra
                    ],
                    "access_policies": {
                        "read": ["data_analyst", "data_engineer", "business_user"],  # Acesso expandido
                        "write": ["data_engineer"]
                    }
                },
                "2.0.0": {
                    "version": "2.0.0",
                    "created_at": "2024-03-01T00:00:00",
                    "schema": {
                        "fields": [
                            {"name": "customer_id", "type": "integer", "required": True},
                            {"name": "full_name", "type": "string", "required": True},  # Campo renomeado
                            {"name": "email", "type": "string", "required": True},
                            {"name": "phone", "type": "string", "required": False},
                            {"name": "created_date", "type": "timestamp", "required": True}  # Campo adicionado
                        ]
                    },
                    "quality_rules": [
                        {"field": "email", "rule": "email_format", "threshold": 0.98},  # Threshold aumentado
                        {"field": "phone", "rule": "phone_format", "threshold": 0.90},
                        {"field": "created_date", "rule": "not_null", "threshold": 1.0}  # Nova regra
                    ],
                    "access_policies": {
                        "read": ["data_analyst", "data_engineer", "business_user"],
                        "write": ["data_engineer", "data_steward"]  # Acesso de escrita expandido
                    }
                }
            }
        }
        
        # Verificar se as versões existem
        contract_versions = available_versions.get(contract_id, {})
        
        if version1 not in contract_versions:
            raise HTTPException(status_code=404, detail=f"Versão {version1} não encontrada")
        
        if version2 not in contract_versions:
            raise HTTPException(status_code=404, detail=f"Versão {version2} não encontrada")
        
        v1_data = contract_versions[version1]
        v2_data = contract_versions[version2]
        
        # Comparar schemas
        schema_changes = compare_schemas(v1_data["schema"], v2_data["schema"])
        
        # Comparar regras de qualidade
        quality_changes = compare_quality_rules(v1_data["quality_rules"], v2_data["quality_rules"])
        
        # Comparar políticas de acesso
        policy_changes = compare_access_policies(v1_data["access_policies"], v2_data["access_policies"])
        
        # Calcular impacto
        impact_analysis = calculate_impact(schema_changes, quality_changes, policy_changes)
        
        comparison_result = {
            "contract_id": contract_id,
            "version1": version1,
            "version2": version2,
            "comparison_timestamp": datetime.utcnow().isoformat(),
            "changes": {
                "schema": schema_changes,
                "quality_rules": quality_changes,
                "access_policies": policy_changes
            },
            "impact_analysis": impact_analysis,
            "compatibility": determine_compatibility(schema_changes),
            "migration_required": len(schema_changes["breaking_changes"]) > 0,
            "summary": {
                "total_changes": len(schema_changes["added"]) + len(schema_changes["removed"]) + len(schema_changes["modified"]),
                "breaking_changes": len(schema_changes["breaking_changes"]),
                "new_features": len(schema_changes["added"]) + len(quality_changes["added"]),
                "deprecated_features": len(schema_changes["removed"]) + len(quality_changes["removed"])
            }
        }
        
        logger.info(f"Comparação realizada entre versões {version1} e {version2} do contrato {contract_id}")
        return comparison_result
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao comparar versões do contrato {contract_id}: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

def compare_schemas(schema1: Dict, schema2: Dict) -> Dict:
    """Comparar schemas entre duas versões"""
    fields1 = {f["name"]: f for f in schema1["fields"]}
    fields2 = {f["name"]: f for f in schema2["fields"]}
    
    added = []
    removed = []
    modified = []
    breaking_changes = []
    
    # Campos adicionados
    for name, field in fields2.items():
        if name not in fields1:
            added.append(field)
    
    # Campos removidos
    for name, field in fields1.items():
        if name not in fields2:
            removed.append(field)
            breaking_changes.append({
                "type": "field_removed",
                "field": name,
                "impact": "high"
            })
    
    # Campos modificados
    for name in fields1.keys() & fields2.keys():
        field1 = fields1[name]
        field2 = fields2[name]
        
        changes = {}
        if field1["type"] != field2["type"]:
            changes["type"] = {"from": field1["type"], "to": field2["type"]}
            breaking_changes.append({
                "type": "type_changed",
                "field": name,
                "from": field1["type"],
                "to": field2["type"],
                "impact": "high"
            })
        
        if field1["required"] != field2["required"]:
            changes["required"] = {"from": field1["required"], "to": field2["required"]}
            if field2["required"] and not field1["required"]:
                breaking_changes.append({
                    "type": "field_required",
                    "field": name,
                    "impact": "medium"
                })
        
        if changes:
            modified.append({
                "field": name,
                "changes": changes
            })
    
    return {
        "added": added,
        "removed": removed,
        "modified": modified,
        "breaking_changes": breaking_changes
    }

def compare_quality_rules(rules1: List, rules2: List) -> Dict:
    """Comparar regras de qualidade entre duas versões"""
    rules1_dict = {f"{r['field']}_{r['rule']}": r for r in rules1}
    rules2_dict = {f"{r['field']}_{r['rule']}": r for r in rules2}
    
    added = []
    removed = []
    modified = []
    
    # Regras adicionadas
    for key, rule in rules2_dict.items():
        if key not in rules1_dict:
            added.append(rule)
    
    # Regras removidas
    for key, rule in rules1_dict.items():
        if key not in rules2_dict:
            removed.append(rule)
    
    # Regras modificadas
    for key in rules1_dict.keys() & rules2_dict.keys():
        rule1 = rules1_dict[key]
        rule2 = rules2_dict[key]
        
        if rule1["threshold"] != rule2["threshold"]:
            modified.append({
                "field": rule1["field"],
                "rule": rule1["rule"],
                "threshold_change": {
                    "from": rule1["threshold"],
                    "to": rule2["threshold"]
                }
            })
    
    return {
        "added": added,
        "removed": removed,
        "modified": modified
    }

def compare_access_policies(policies1: Dict, policies2: Dict) -> Dict:
    """Comparar políticas de acesso entre duas versões"""
    changes = {}
    
    for operation in ["read", "write"]:
        roles1 = set(policies1.get(operation, []))
        roles2 = set(policies2.get(operation, []))
        
        added_roles = list(roles2 - roles1)
        removed_roles = list(roles1 - roles2)
        
        if added_roles or removed_roles:
            changes[operation] = {
                "added_roles": added_roles,
                "removed_roles": removed_roles
            }
    
    return changes

def calculate_impact(schema_changes: Dict, quality_changes: Dict, policy_changes: Dict) -> Dict:
    """Calcular análise de impacto das mudanças"""
    impact_score = 0
    affected_systems = []
    recommendations = []
    
    # Impacto de mudanças de schema
    if schema_changes["breaking_changes"]:
        impact_score += len(schema_changes["breaking_changes"]) * 3
        affected_systems.extend(["ETL Pipelines", "Data Consumers", "Analytics Dashboards"])
        recommendations.append("Implementar migração gradual com versionamento de API")
    
    # Impacto de mudanças de qualidade
    if quality_changes["modified"]:
        impact_score += len(quality_changes["modified"]) * 1
        affected_systems.append("Data Quality Monitoring")
        recommendations.append("Atualizar thresholds de qualidade gradualmente")
    
    # Impacto de mudanças de políticas
    if policy_changes:
        impact_score += len(policy_changes) * 2
        affected_systems.append("Access Control Systems")
        recommendations.append("Comunicar mudanças de acesso aos usuários afetados")
    
    return {
        "impact_score": impact_score,
        "impact_level": "low" if impact_score < 3 else "medium" if impact_score < 8 else "high",
        "affected_systems": list(set(affected_systems)),
        "recommendations": recommendations,
        "estimated_migration_time": f"{max(1, impact_score // 2)} days"
    }

def determine_compatibility(schema_changes: Dict) -> str:
    """Determinar nível de compatibilidade"""
    if schema_changes["breaking_changes"]:
        return "incompatible"
    elif schema_changes["added"] or schema_changes["modified"]:
        return "backward_compatible"
    else:
        return "fully_compatible"

@router.get("/{contract_id}/versions")
async def list_contract_versions(
    contract_id: int = Path(..., description="ID do contrato"),
    db = Depends(get_db)
):
    """Listar todas as versões de um contrato"""
    try:
        if contract_id not in [1, 2, 3]:
            raise HTTPException(status_code=404, detail="Contrato não encontrado")
        
        # Mock versions data
        versions = [
            {
                "version": "1.0.0",
                "status": "published",
                "created_at": "2024-01-01T00:00:00",
                "created_by": "data_engineer",
                "description": "Versão inicial do contrato",
                "changes": "Criação inicial"
            },
            {
                "version": "1.1.0",
                "status": "published",
                "created_at": "2024-02-01T00:00:00",
                "created_by": "data_engineer",
                "description": "Adição de campo phone",
                "changes": "Campo phone adicionado, acesso expandido para business_user"
            },
            {
                "version": "2.0.0",
                "status": "published",
                "created_at": "2024-03-01T00:00:00",
                "created_by": "data_steward",
                "description": "Refatoração major com breaking changes",
                "changes": "Campo name renomeado para full_name, campo created_date adicionado"
            }
        ]
        
        return {
            "contract_id": contract_id,
            "versions": versions,
            "total_versions": len(versions),
            "latest_version": "2.0.0",
            "generated_at": datetime.utcnow().isoformat()
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao listar versões do contrato {contract_id}: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

