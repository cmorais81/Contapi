"""
TBR GDP Core v3.0 - Controller de Versionamento de Contratos
Endpoints para gestão avançada de versões e workflows
"""

from fastapi import APIRouter, Depends, HTTPException, Query, Body
from sqlalchemy.orm import Session
from typing import List, Optional, Dict, Any
from datetime import datetime

from governance_api.core.database import get_db
from governance_api.domains.contracts.services.contract_versioning_service import (
    ContractVersioningService, ChangeType, WorkflowStatus
)

router = APIRouter(prefix="/api/v3/contracts", tags=["Contract Versioning"])

def get_versioning_service(db: Session = Depends(get_db)) -> ContractVersioningService:
    return ContractVersioningService(db)

# === VERSION MANAGEMENT ===

@router.post("/{contract_id}/versions")
async def create_new_version(
    contract_id: int,
    changes: Dict[str, Any] = Body(...),
    change_type: ChangeType = Body(ChangeType.MINOR),
    created_by: str = Body(...),
    service: ContractVersioningService = Depends(get_versioning_service)
):
    """Criar nova versão de um contrato"""
    try:
        version = service.create_new_version(contract_id, changes, change_type, created_by)
        return {
            "success": True,
            "message": "New version created successfully",
            "version": version
        }
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error creating version: {str(e)}")

@router.get("/{contract_id}/versions")
async def get_version_history(
    contract_id: int,
    service: ContractVersioningService = Depends(get_versioning_service)
):
    """Obter histórico de versões de um contrato"""
    versions = service.get_version_history(contract_id)
    return {
        "contract_id": contract_id,
        "total_versions": len(versions),
        "versions": versions,
        "current_version": next((v for v in versions if v.get("is_current")), None)
    }

@router.get("/{contract_id}/versions/compare")
async def compare_versions(
    contract_id: int,
    version1: str = Query(..., description="First version to compare"),
    version2: str = Query(..., description="Second version to compare"),
    service: ContractVersioningService = Depends(get_versioning_service)
):
    """Comparar duas versões de um contrato"""
    comparison = service.compare_versions(contract_id, version1, version2)
    return comparison

@router.post("/versions/{version_id}/approve")
async def approve_version(
    version_id: str,
    approved_by: str = Body(...),
    approval_notes: Optional[str] = Body(None),
    service: ContractVersioningService = Depends(get_versioning_service)
):
    """Aprovar uma versão específica"""
    approval = service.approve_version(version_id, approved_by, approval_notes)
    return {
        "success": True,
        "message": "Version approved successfully",
        "approval": approval
    }

@router.post("/versions/{version_id}/reject")
async def reject_version(
    version_id: str,
    rejected_by: str = Body(...),
    rejection_reason: str = Body(...),
    service: ContractVersioningService = Depends(get_versioning_service)
):
    """Rejeitar uma versão específica"""
    rejection = service.reject_version(version_id, rejected_by, rejection_reason)
    return {
        "success": True,
        "message": "Version rejected",
        "rejection": rejection
    }

@router.post("/versions/{version_id}/publish")
async def publish_version(
    version_id: str,
    published_by: str = Body(...),
    service: ContractVersioningService = Depends(get_versioning_service)
):
    """Publicar uma versão aprovada"""
    publication = service.publish_version(version_id, published_by)
    return {
        "success": True,
        "message": "Version published successfully",
        "publication": publication
    }

@router.post("/{contract_id}/rollback")
async def rollback_version(
    contract_id: int,
    target_version: str = Body(...),
    rollback_reason: str = Body(...),
    performed_by: str = Body(...),
    service: ContractVersioningService = Depends(get_versioning_service)
):
    """Fazer rollback para uma versão anterior"""
    rollback = service.rollback_version(contract_id, target_version, rollback_reason, performed_by)
    return {
        "success": True,
        "message": "Rollback completed successfully",
        "rollback": rollback
    }

# === WORKFLOW MANAGEMENT ===

@router.post("/versions/{version_id}/workflow/start")
async def start_approval_workflow(
    version_id: str,
    initiated_by: str = Body(...),
    service: ContractVersioningService = Depends(get_versioning_service)
):
    """Iniciar workflow de aprovação"""
    workflow = service.start_approval_workflow(version_id, initiated_by)
    return {
        "success": True,
        "message": "Approval workflow started",
        "workflow": workflow
    }

@router.get("/workflows/{workflow_id}")
async def get_workflow_status(
    workflow_id: str,
    service: ContractVersioningService = Depends(get_versioning_service)
):
    """Obter status do workflow"""
    status = service.get_workflow_status(workflow_id)
    return status

@router.post("/workflows/{workflow_id}/advance")
async def advance_workflow_stage(
    workflow_id: str,
    stage_result: str = Body(..., regex="^(approved|rejected)$"),
    notes: Optional[str] = Body(None),
    completed_by: str = Body(...),
    service: ContractVersioningService = Depends(get_versioning_service)
):
    """Avançar estágio do workflow"""
    result = service.advance_workflow_stage(workflow_id, stage_result, notes, completed_by)
    return {
        "success": True,
        "message": f"Workflow stage {stage_result}",
        "result": result
    }

# === CHANGE IMPACT ANALYSIS ===

@router.post("/{contract_id}/impact-analysis")
async def analyze_change_impact(
    contract_id: int,
    proposed_changes: Dict[str, Any] = Body(...),
    service: ContractVersioningService = Depends(get_versioning_service)
):
    """Analisar impacto de mudanças propostas"""
    impact = service.analyze_change_impact(contract_id, proposed_changes)
    return impact

@router.get("/{contract_id}/dependencies")
async def get_dependency_graph(
    contract_id: int,
    service: ContractVersioningService = Depends(get_versioning_service)
):
    """Obter grafo de dependências do contrato"""
    dependencies = service.get_dependency_graph(contract_id)
    return dependencies

# === ADVANCED FEATURES ===

@router.get("/{contract_id}/versions/timeline")
async def get_version_timeline(
    contract_id: int,
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    service: ContractVersioningService = Depends(get_versioning_service)
):
    """Obter timeline de versões"""
    versions = service.get_version_history(contract_id)
    
    # Filtrar por data se especificado
    if start_date or end_date:
        filtered_versions = []
        for version in versions:
            version_date = version["created_at"]
            if start_date and version_date < start_date:
                continue
            if end_date and version_date > end_date:
                continue
            filtered_versions.append(version)
        versions = filtered_versions
    
    # Criar timeline
    timeline = {
        "contract_id": contract_id,
        "period": {
            "start_date": start_date,
            "end_date": end_date
        },
        "timeline": [
            {
                "date": version["created_at"],
                "version": version["version"],
                "change_type": version["change_type"],
                "status": version["status"],
                "created_by": version["created_by"],
                "summary": version["metadata"]["change_summary"]
            }
            for version in versions
        ],
        "statistics": {
            "total_versions": len(versions),
            "major_versions": len([v for v in versions if v["change_type"] == "major"]),
            "minor_versions": len([v for v in versions if v["change_type"] == "minor"]),
            "patch_versions": len([v for v in versions if v["change_type"] == "patch"]),
            "published_versions": len([v for v in versions if v["status"] == "published"])
        }
    }
    
    return timeline

@router.get("/{contract_id}/versions/metrics")
async def get_version_metrics(
    contract_id: int,
    service: ContractVersioningService = Depends(get_versioning_service)
):
    """Obter métricas de versionamento"""
    versions = service.get_version_history(contract_id)
    
    # Calcular métricas
    total_versions = len(versions)
    published_versions = [v for v in versions if v["status"] == "published"]
    
    # Tempo médio de aprovação
    approval_times = []
    for version in published_versions:
        if version.get("approved_at") and version.get("created_at"):
            approval_time = (version["approved_at"] - version["created_at"]).total_seconds() / 3600
            approval_times.append(approval_time)
    
    avg_approval_time = sum(approval_times) / len(approval_times) if approval_times else 0
    
    # Distribuição por tipo de mudança
    change_types = {}
    for version in versions:
        change_type = version["change_type"]
        change_types[change_type] = change_types.get(change_type, 0) + 1
    
    metrics = {
        "contract_id": contract_id,
        "version_statistics": {
            "total_versions": total_versions,
            "published_versions": len(published_versions),
            "draft_versions": len([v for v in versions if v["status"] == "draft"]),
            "rejected_versions": len([v for v in versions if v["status"] == "rejected"])
        },
        "approval_metrics": {
            "average_approval_time_hours": round(avg_approval_time, 2),
            "fastest_approval_hours": min(approval_times) if approval_times else 0,
            "slowest_approval_hours": max(approval_times) if approval_times else 0
        },
        "change_distribution": change_types,
        "activity_metrics": {
            "versions_this_month": len([
                v for v in versions 
                if v["created_at"] >= datetime.utcnow().replace(day=1)
            ]),
            "most_active_contributor": self._get_most_active_contributor(versions),
            "last_version_date": max([v["created_at"] for v in versions]) if versions else None
        }
    }
    
    return metrics

@router.get("/versions/search")
async def search_versions(
    query: str = Query(..., min_length=1),
    status: Optional[WorkflowStatus] = Query(None),
    change_type: Optional[ChangeType] = Query(None),
    created_by: Optional[str] = Query(None),
    limit: int = Query(50, le=100),
    service: ContractVersioningService = Depends(get_versioning_service)
):
    """Buscar versões por critérios"""
    
    # Mock search results
    all_versions = []
    for contract_id in [1, 2, 3, 4, 5]:
        versions = service.get_version_history(contract_id)
        all_versions.extend(versions)
    
    # Aplicar filtros
    filtered_versions = []
    for version in all_versions:
        # Filtro por query (busca em campos de texto)
        if query.lower() not in str(version.get("metadata", {}).get("change_summary", "")).lower():
            continue
        
        # Filtro por status
        if status and version.get("status") != status.value:
            continue
        
        # Filtro por tipo de mudança
        if change_type and version.get("change_type") != change_type.value:
            continue
        
        # Filtro por criador
        if created_by and version.get("created_by") != created_by:
            continue
        
        filtered_versions.append(version)
    
    # Limitar resultados
    filtered_versions = filtered_versions[:limit]
    
    return {
        "query": query,
        "filters": {
            "status": status.value if status else None,
            "change_type": change_type.value if change_type else None,
            "created_by": created_by
        },
        "results": filtered_versions,
        "total_found": len(filtered_versions),
        "limit_applied": limit
    }

# === BULK OPERATIONS ===

@router.post("/versions/bulk-approve")
async def bulk_approve_versions(
    version_ids: List[str] = Body(...),
    approved_by: str = Body(...),
    approval_notes: Optional[str] = Body(None),
    service: ContractVersioningService = Depends(get_versioning_service)
):
    """Aprovar múltiplas versões em lote"""
    results = []
    
    for version_id in version_ids:
        try:
            approval = service.approve_version(version_id, approved_by, approval_notes)
            results.append({
                "version_id": version_id,
                "status": "approved",
                "approval": approval
            })
        except Exception as e:
            results.append({
                "version_id": version_id,
                "status": "error",
                "error": str(e)
            })
    
    successful = len([r for r in results if r["status"] == "approved"])
    failed = len([r for r in results if r["status"] == "error"])
    
    return {
        "success": failed == 0,
        "message": f"Bulk approval completed: {successful} successful, {failed} failed",
        "summary": {
            "total_processed": len(version_ids),
            "successful": successful,
            "failed": failed
        },
        "results": results
    }

@router.post("/versions/bulk-publish")
async def bulk_publish_versions(
    version_ids: List[str] = Body(...),
    published_by: str = Body(...),
    service: ContractVersioningService = Depends(get_versioning_service)
):
    """Publicar múltiplas versões em lote"""
    results = []
    
    for version_id in version_ids:
        try:
            publication = service.publish_version(version_id, published_by)
            results.append({
                "version_id": version_id,
                "status": "published",
                "publication": publication
            })
        except Exception as e:
            results.append({
                "version_id": version_id,
                "status": "error",
                "error": str(e)
            })
    
    successful = len([r for r in results if r["status"] == "published"])
    failed = len([r for r in results if r["status"] == "error"])
    
    return {
        "success": failed == 0,
        "message": f"Bulk publication completed: {successful} successful, {failed} failed",
        "summary": {
            "total_processed": len(version_ids),
            "successful": successful,
            "failed": failed
        },
        "results": results
    }

# === HELPER METHODS ===

def _get_most_active_contributor(versions: List[Dict]) -> str:
    """Obter contribuidor mais ativo"""
    contributors = {}
    for version in versions:
        creator = version.get("created_by", "unknown")
        contributors[creator] = contributors.get(creator, 0) + 1
    
    if not contributors:
        return "none"
    
    return max(contributors.items(), key=lambda x: x[1])[0]

