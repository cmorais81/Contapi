"""
TBR GDP Core v3.0 - Controller Avançado de Contratos de Dados
Funcionalidades completas para gestão de contratos, SLA, monitoramento e versionamento
"""

from fastapi import APIRouter, Depends, HTTPException, Query, Path, Body
from sqlalchemy.orm import Session
from typing import List, Optional, Dict, Any
import logging
from datetime import datetime, timedelta
import uuid
import json

from governance_api.core.database import get_db
from governance_api.shared.models import PaginationSchema, FilterSchema, SuccessSchema

# Configurar logging
logger = logging.getLogger(__name__)

# Criar router
router = APIRouter()

# Schemas para contratos avançados com versionamento
class ContractCreateSchema:
    def __init__(self, **data):
        self.name = data.get("name")
        self.description = data.get("description")
        self.entity_id = data.get("entity_id")
        self.provider = data.get("provider")
        self.consumer = data.get("consumer")
        self.version = data.get("version", "1.0.0")
        self.parent_contract_id = data.get("parent_contract_id")
        self.sla_requirements = data.get("sla_requirements", {})
        self.quality_rules = data.get("quality_rules", [])
        self.data_schema = data.get("data_schema", {})
        self.retention_policy = data.get("retention_policy", {})
        self.access_permissions = data.get("access_permissions", [])
        self.masking_rules = data.get("masking_rules", [])

class ContractVersionSchema:
    def __init__(self, **data):
        self.contract_id = data.get("contract_id")
        self.version = data.get("version")
        self.changes_description = data.get("changes_description")
        self.breaking_changes = data.get("breaking_changes", False)
        self.migration_notes = data.get("migration_notes", "")

class ContractResponseSchema:
    def __init__(self, **data):
        self.id = data.get("id")
        self.name = data.get("name")
        self.description = data.get("description")
        self.entity_id = data.get("entity_id")
        self.provider = data.get("provider")
        self.consumer = data.get("consumer")
        self.status = data.get("status", "draft")
        self.version = data.get("version", "1.0.0")
        self.parent_contract_id = data.get("parent_contract_id")
        self.sla_requirements = data.get("sla_requirements", {})
        self.quality_rules = data.get("quality_rules", [])
        self.data_schema = data.get("data_schema", {})
        self.retention_policy = data.get("retention_policy", {})
        self.access_permissions = data.get("access_permissions", [])
        self.masking_rules = data.get("masking_rules", [])
        self.created_at = data.get("created_at")
        self.updated_at = data.get("updated_at")
        self.approved_at = data.get("approved_at")
        self.approved_by = data.get("approved_by")

# Mock database para demonstração
contracts_db = {}
contract_violations_db = {}
contract_metrics_db = {}

@router.get("/", response_model=List[Dict])
async def list_contracts(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    status: Optional[str] = Query(None),
    provider: Optional[str] = Query(None),
    consumer: Optional[str] = Query(None),
    db: Session = Depends(get_db)
):
    """Listar contratos de dados com filtros avançados"""
    logger.info(f"Listando contratos: skip={skip}, limit={limit}, status={status}")
    
    # Simular busca no database
    contracts = []
    for i in range(1, min(limit + 1, 6)):
        contract = {
            "id": i,
            "name": f"Contrato de Dados {i}",
            "description": f"Contrato para entidade {i}",
            "entity_id": i,
            "provider": f"Sistema Origem {i}",
            "consumer": f"Sistema Destino {i}",
            "status": "active" if i % 2 == 0 else "draft",
            "sla_requirements": {
                "availability": "99.9%",
                "latency_max": "100ms",
                "throughput_min": "1000 req/s"
            },
            "quality_rules": [
                {"field": "customer_id", "rule": "not_null", "threshold": 100},
                {"field": "email", "rule": "valid_email", "threshold": 95}
            ],
            "data_schema": {
                "customer_id": {"type": "integer", "required": True},
                "name": {"type": "string", "required": True},
                "email": {"type": "string", "required": True},
                "phone": {"type": "string", "required": False}
            },
            "retention_policy": {
                "retention_days": 2555,  # 7 anos
                "archive_after_days": 1095,  # 3 anos
                "delete_after_days": 2555
            },
            "access_permissions": [
                {"role": "data_analyst", "permissions": ["read"]},
                {"role": "data_engineer", "permissions": ["read", "write"]},
                {"role": "admin", "permissions": ["read", "write", "delete"]}
            ],
            "masking_rules": [
                {"field": "email", "mask_type": "email_domain", "roles_exempt": ["admin"]},
                {"field": "phone", "mask_type": "partial", "mask_pattern": "XXX-XXX-####"}
            ],
            "created_at": "2025-01-01T10:00:00Z",
            "updated_at": "2025-01-11T15:30:00Z"
        }
        contracts.append(contract)
    
    return contracts

@router.post("/", response_model=Dict)
async def create_contract(
    contract_data: Dict = Body(...),
    db: Session = Depends(get_db)
):
    """Criar novo contrato de dados"""
    contract_id = len(contracts_db) + 1
    
    # Validar dados obrigatórios
    required_fields = ["name", "entity_id", "provider", "consumer"]
    for field in required_fields:
        if field not in contract_data:
            raise HTTPException(status_code=400, detail=f"Campo obrigatório: {field}")
    
    # Criar contrato
    contract = {
        "id": contract_id,
        "name": contract_data["name"],
        "description": contract_data.get("description", ""),
        "entity_id": contract_data["entity_id"],
        "provider": contract_data["provider"],
        "consumer": contract_data["consumer"],
        "status": "draft",
        "sla_requirements": contract_data.get("sla_requirements", {}),
        "quality_rules": contract_data.get("quality_rules", []),
        "data_schema": contract_data.get("data_schema", {}),
        "retention_policy": contract_data.get("retention_policy", {}),
        "access_permissions": contract_data.get("access_permissions", []),
        "masking_rules": contract_data.get("masking_rules", []),
        "created_at": datetime.utcnow().isoformat(),
        "updated_at": datetime.utcnow().isoformat(),
        "approved_at": None,
        "approved_by": None
    }
    
    contracts_db[contract_id] = contract
    
    logger.info(f"Contrato criado: {contract['name']} (ID: {contract_id})")
    return contract

@router.get("/{contract_id}", response_model=Dict)
async def get_contract(
    contract_id: int = Path(..., gt=0),
    db: Session = Depends(get_db)
):
    """Obter contrato específico por ID"""
    logger.info(f"Buscando contrato ID: {contract_id}")
    
    # Simular busca no database
    if contract_id <= 5:
        contract = {
            "id": contract_id,
            "name": f"Contrato de Dados {contract_id}",
            "description": f"Contrato detalhado para entidade {contract_id}",
            "entity_id": contract_id,
            "provider": f"Sistema Origem {contract_id}",
            "consumer": f"Sistema Destino {contract_id}",
            "status": "active",
            "sla_requirements": {
                "availability": "99.9%",
                "latency_max": "100ms",
                "throughput_min": "1000 req/s",
                "data_freshness": "5 minutes"
            },
            "quality_rules": [
                {"field": "customer_id", "rule": "not_null", "threshold": 100},
                {"field": "email", "rule": "valid_email", "threshold": 95},
                {"field": "created_date", "rule": "valid_date", "threshold": 100}
            ],
            "data_schema": {
                "customer_id": {"type": "integer", "required": True, "description": "ID único do cliente"},
                "name": {"type": "string", "required": True, "max_length": 100},
                "email": {"type": "string", "required": True, "format": "email"},
                "phone": {"type": "string", "required": False, "format": "phone"},
                "created_date": {"type": "datetime", "required": True}
            },
            "retention_policy": {
                "retention_days": 2555,
                "archive_after_days": 1095,
                "delete_after_days": 2555,
                "backup_frequency": "daily",
                "compliance_requirements": ["LGPD", "GDPR"]
            },
            "access_permissions": [
                {"role": "data_analyst", "permissions": ["read"], "conditions": ["business_hours"]},
                {"role": "data_engineer", "permissions": ["read", "write"], "conditions": []},
                {"role": "admin", "permissions": ["read", "write", "delete"], "conditions": []}
            ],
            "masking_rules": [
                {
                    "field": "email",
                    "mask_type": "email_domain",
                    "roles_exempt": ["admin"],
                    "mask_pattern": "****@domain.com"
                },
                {
                    "field": "phone",
                    "mask_type": "partial",
                    "mask_pattern": "XXX-XXX-####",
                    "roles_exempt": ["admin", "data_engineer"]
                }
            ],
            "lineage": {
                "upstream_entities": [f"raw_data_{contract_id}", f"staging_{contract_id}"],
                "downstream_entities": [f"analytics_{contract_id}", f"reporting_{contract_id}"],
                "transformations": ["data_cleaning", "validation", "enrichment"]
            },
            "created_at": "2025-01-01T10:00:00Z",
            "updated_at": "2025-01-11T15:30:00Z",
            "approved_at": "2025-01-02T14:20:00Z",
            "approved_by": "admin@company.com"
        }
        return contract
    else:
        raise HTTPException(status_code=404, detail="Contrato não encontrado")

@router.put("/{contract_id}", response_model=Dict)
async def update_contract(
    contract_id: int = Path(..., gt=0),
    contract_data: Dict = Body(...),
    db: Session = Depends(get_db)
):
    """Atualizar contrato existente"""
    logger.info(f"Atualizando contrato ID: {contract_id}")
    
    # Verificar se contrato existe
    if contract_id > 5:
        raise HTTPException(status_code=404, detail="Contrato não encontrado")
    
    # Simular atualização
    updated_contract = {
        "id": contract_id,
        "name": contract_data.get("name", f"Contrato Atualizado {contract_id}"),
        "description": contract_data.get("description", "Contrato atualizado"),
        "entity_id": contract_data.get("entity_id", contract_id),
        "provider": contract_data.get("provider", f"Sistema Origem {contract_id}"),
        "consumer": contract_data.get("consumer", f"Sistema Destino {contract_id}"),
        "status": contract_data.get("status", "active"),
        "sla_requirements": contract_data.get("sla_requirements", {}),
        "quality_rules": contract_data.get("quality_rules", []),
        "data_schema": contract_data.get("data_schema", {}),
        "retention_policy": contract_data.get("retention_policy", {}),
        "access_permissions": contract_data.get("access_permissions", []),
        "masking_rules": contract_data.get("masking_rules", []),
        "updated_at": datetime.utcnow().isoformat()
    }
    
    return updated_contract

@router.post("/{contract_id}/approve", response_model=Dict)
async def approve_contract(
    contract_id: int = Path(..., gt=0),
    approval_data: Dict = Body(...),
    db: Session = Depends(get_db)
):
    """Aprovar contrato de dados"""
    logger.info(f"Aprovando contrato ID: {contract_id}")
    
    if contract_id > 5:
        raise HTTPException(status_code=404, detail="Contrato não encontrado")
    
    approved_by = approval_data.get("approved_by", "admin@company.com")
    comments = approval_data.get("comments", "")
    
    approval_result = {
        "contract_id": contract_id,
        "status": "approved",
        "approved_by": approved_by,
        "approved_at": datetime.utcnow().isoformat(),
        "comments": comments,
        "approval_id": str(uuid.uuid4()),
        "next_review_date": (datetime.utcnow() + timedelta(days=365)).isoformat()
    }
    
    return approval_result

@router.get("/{contract_id}/violations", response_model=List[Dict])
async def get_contract_violations(
    contract_id: int = Path(..., gt=0),
    days: int = Query(30, ge=1, le=365),
    severity: Optional[str] = Query(None),
    db: Session = Depends(get_db)
):
    """Obter violações de SLA do contrato"""
    logger.info(f"Buscando violações do contrato {contract_id} nos últimos {days} dias")
    
    if contract_id > 5:
        raise HTTPException(status_code=404, detail="Contrato não encontrado")
    
    # Simular violações
    violations = []
    for i in range(1, 4):
        violation = {
            "id": i,
            "contract_id": contract_id,
            "violation_type": "sla_breach" if i % 2 == 0 else "quality_issue",
            "severity": "high" if i == 1 else "medium",
            "description": f"Violação {i}: Latência acima do limite" if i % 2 == 0 else f"Violação {i}: Qualidade abaixo do threshold",
            "metric": "latency" if i % 2 == 0 else "data_quality",
            "expected_value": "100ms" if i % 2 == 0 else "95%",
            "actual_value": "150ms" if i % 2 == 0 else "89%",
            "detected_at": (datetime.utcnow() - timedelta(days=i)).isoformat(),
            "resolved_at": (datetime.utcnow() - timedelta(days=i-1)).isoformat() if i > 1 else None,
            "impact": "service_degradation" if i % 2 == 0 else "data_reliability",
            "root_cause": "network_latency" if i % 2 == 0 else "source_data_issues"
        }
        violations.append(violation)
    
    return violations

@router.get("/{contract_id}/metrics", response_model=Dict)
async def get_contract_metrics(
    contract_id: int = Path(..., gt=0),
    period: str = Query("7d", regex="^(1d|7d|30d|90d)$"),
    db: Session = Depends(get_db)
):
    """Obter métricas de performance do contrato"""
    logger.info(f"Obtendo métricas do contrato {contract_id} para período {period}")
    
    if contract_id > 5:
        raise HTTPException(status_code=404, detail="Contrato não encontrado")
    
    # Simular métricas
    metrics = {
        "contract_id": contract_id,
        "period": period,
        "sla_compliance": {
            "availability": {
                "target": 99.9,
                "actual": 99.95,
                "status": "compliant"
            },
            "latency": {
                "target": 100,
                "actual": 85,
                "unit": "ms",
                "status": "compliant"
            },
            "throughput": {
                "target": 1000,
                "actual": 1250,
                "unit": "req/s",
                "status": "compliant"
            }
        },
        "data_quality": {
            "completeness": {
                "target": 100,
                "actual": 99.8,
                "status": "compliant"
            },
            "accuracy": {
                "target": 95,
                "actual": 97.2,
                "status": "compliant"
            },
            "consistency": {
                "target": 98,
                "actual": 96.5,
                "status": "warning"
            }
        },
        "usage_stats": {
            "total_requests": 125000,
            "successful_requests": 124750,
            "failed_requests": 250,
            "success_rate": 99.8,
            "peak_usage_time": "14:00-16:00",
            "avg_daily_volume": "18GB"
        },
        "cost_metrics": {
            "storage_cost": 150.75,
            "compute_cost": 89.25,
            "transfer_cost": 12.50,
            "total_cost": 252.50,
            "currency": "USD"
        },
        "generated_at": datetime.utcnow().isoformat()
    }
    
    return metrics

@router.get("/{contract_id}/lineage", response_model=Dict)
async def get_contract_lineage(
    contract_id: int = Path(..., gt=0),
    depth: int = Query(3, ge=1, le=10),
    direction: str = Query("both", regex="^(upstream|downstream|both)$"),
    db: Session = Depends(get_db)
):
    """Obter linhagem de dados do contrato"""
    logger.info(f"Obtendo linhagem do contrato {contract_id}, profundidade {depth}, direção {direction}")
    
    if contract_id > 5:
        raise HTTPException(status_code=404, detail="Contrato não encontrado")
    
    # Simular linhagem
    lineage = {
        "contract_id": contract_id,
        "entity_name": f"customer_data_{contract_id}",
        "depth": depth,
        "direction": direction,
        "upstream_lineage": [
            {
                "level": 1,
                "entities": [
                    {
                        "id": f"raw_{contract_id}",
                        "name": f"raw_customer_data_{contract_id}",
                        "type": "source_table",
                        "system": "CRM System",
                        "last_updated": "2025-01-11T10:00:00Z"
                    }
                ]
            },
            {
                "level": 2,
                "entities": [
                    {
                        "id": f"staging_{contract_id}",
                        "name": f"staging_customer_{contract_id}",
                        "type": "staging_table",
                        "system": "Data Lake",
                        "transformations": ["data_cleaning", "validation"],
                        "last_updated": "2025-01-11T11:00:00Z"
                    }
                ]
            }
        ],
        "downstream_lineage": [
            {
                "level": 1,
                "entities": [
                    {
                        "id": f"analytics_{contract_id}",
                        "name": f"customer_analytics_{contract_id}",
                        "type": "analytics_table",
                        "system": "Data Warehouse",
                        "consumers": ["BI Dashboard", "ML Pipeline"],
                        "last_updated": "2025-01-11T12:00:00Z"
                    }
                ]
            },
            {
                "level": 2,
                "entities": [
                    {
                        "id": f"report_{contract_id}",
                        "name": f"customer_report_{contract_id}",
                        "type": "report",
                        "system": "BI Platform",
                        "consumers": ["Executive Dashboard"],
                        "last_updated": "2025-01-11T13:00:00Z"
                    }
                ]
            }
        ],
        "transformations": [
            {
                "name": "data_cleaning",
                "description": "Remove duplicates and invalid records",
                "rules": ["remove_nulls", "deduplicate", "validate_email"]
            },
            {
                "name": "data_enrichment",
                "description": "Add derived fields and external data",
                "rules": ["calculate_age", "add_geo_data", "segment_customers"]
            }
        ],
        "impact_analysis": {
            "downstream_systems": 5,
            "affected_reports": 12,
            "dependent_pipelines": 3,
            "estimated_impact_time": "2 hours"
        },
        "generated_at": datetime.utcnow().isoformat()
    }
    
    return lineage

@router.post("/{contract_id}/permissions/validate", response_model=Dict)
async def validate_permissions(
    contract_id: int = Path(..., gt=0),
    permission_request: Dict = Body(...),
    db: Session = Depends(get_db)
):
    """Validar permissões de acesso aos dados do contrato"""
    logger.info(f"Validando permissões para contrato {contract_id}")
    
    if contract_id > 5:
        raise HTTPException(status_code=404, detail="Contrato não encontrado")
    
    user_role = permission_request.get("user_role", "")
    requested_operation = permission_request.get("operation", "")
    context = permission_request.get("context", {})
    
    # Simular validação de permissões
    permission_result = {
        "contract_id": contract_id,
        "user_role": user_role,
        "requested_operation": requested_operation,
        "access_granted": True,
        "permissions": {
            "read": True,
            "write": user_role in ["data_engineer", "admin"],
            "delete": user_role == "admin"
        },
        "masking_applied": {
            "email": user_role != "admin",
            "phone": user_role not in ["admin", "data_engineer"]
        },
        "conditions": {
            "time_restrictions": user_role == "data_analyst",
            "ip_restrictions": False,
            "audit_required": True
        },
        "data_access_level": "full" if user_role == "admin" else "masked",
        "session_duration": "8 hours" if user_role == "data_analyst" else "unlimited",
        "validated_at": datetime.utcnow().isoformat(),
        "expires_at": (datetime.utcnow() + timedelta(hours=8)).isoformat()
    }
    
    return permission_result

@router.get("/{contract_id}/masking/preview", response_model=Dict)
async def preview_data_masking(
    contract_id: int = Path(..., gt=0),
    user_role: str = Query(...),
    sample_size: int = Query(10, ge=1, le=100),
    db: Session = Depends(get_db)
):
    """Visualizar preview dos dados com mascaramento aplicado"""
    logger.info(f"Gerando preview de mascaramento para contrato {contract_id}, role {user_role}")
    
    if contract_id > 5:
        raise HTTPException(status_code=404, detail="Contrato não encontrado")
    
    # Simular dados com mascaramento
    sample_data = []
    for i in range(1, min(sample_size + 1, 11)):
        if user_role == "admin":
            # Admin vê dados completos
            record = {
                "customer_id": 1000 + i,
                "name": f"João Silva {i}",
                "email": f"joao.silva{i}@email.com",
                "phone": f"(11) 9999-{1000+i}",
                "created_date": f"2025-01-{i:02d}T10:00:00Z"
            }
        elif user_role == "data_engineer":
            # Data Engineer vê email mascarado
            record = {
                "customer_id": 1000 + i,
                "name": f"João Silva {i}",
                "email": f"****@email.com",
                "phone": f"(11) 9999-{1000+i}",
                "created_date": f"2025-01-{i:02d}T10:00:00Z"
            }
        else:
            # Outros roles veem dados mascarados
            record = {
                "customer_id": 1000 + i,
                "name": f"João Silva {i}",
                "email": "****@****.com",
                "phone": "XXX-XXX-####",
                "created_date": f"2025-01-{i:02d}T10:00:00Z"
            }
        sample_data.append(record)
    
    masking_preview = {
        "contract_id": contract_id,
        "user_role": user_role,
        "sample_size": len(sample_data),
        "masking_rules_applied": [
            {
                "field": "email",
                "mask_type": "email_domain" if user_role == "data_engineer" else "full_email",
                "applied": user_role != "admin"
            },
            {
                "field": "phone",
                "mask_type": "partial",
                "applied": user_role not in ["admin", "data_engineer"]
            }
        ],
        "sample_data": sample_data,
        "data_classification": {
            "customer_id": "public",
            "name": "internal",
            "email": "confidential",
            "phone": "confidential",
            "created_date": "internal"
        },
        "compliance_notes": [
            "Dados mascarados conforme LGPD",
            "Acesso auditado e registrado",
            "Retenção conforme política do contrato"
        ],
        "generated_at": datetime.utcnow().isoformat()
    }
    
    return masking_preview


# ===========================
# ENDPOINTS DE VERSIONAMENTO
# ===========================

@router.post("/{contract_id}/versions", response_model=Dict)
async def create_contract_version(
    contract_id: int = Path(..., gt=0),
    version_data: Dict = Body(...),
    db: Session = Depends(get_db)
):
    """Criar nova versão de um contrato existente"""
    logger.info(f"Criando nova versão para contrato ID: {contract_id}")
    
    # Verificar se contrato pai existe
    if contract_id > 5:
        raise HTTPException(status_code=404, detail="Contrato pai não encontrado")
    
    # Validar dados da versão
    required_fields = ["version", "changes_description"]
    for field in required_fields:
        if field not in version_data:
            raise HTTPException(status_code=400, detail=f"Campo obrigatório: {field}")
    
    # Gerar ID para nova versão (usando metadata para armazenar versionamento)
    new_version_id = contract_id + 100  # Offset para versões
    
    # Criar nova versão baseada no contrato original
    new_version = {
        "id": new_version_id,
        "name": f"{version_data.get('name', f'Contrato {contract_id}')} v{version_data['version']}",
        "description": version_data.get("description", f"Versão {version_data['version']} do contrato"),
        "entity_id": contract_id,  # Referência ao contrato original
        "provider": version_data.get("provider", f"Sistema Origem {contract_id}"),
        "consumer": version_data.get("consumer", f"Sistema Destino {contract_id}"),
        "status": "draft",
        "version": version_data["version"],
        "parent_contract_id": contract_id,
        "version_metadata": {
            "changes_description": version_data["changes_description"],
            "breaking_changes": version_data.get("breaking_changes", False),
            "migration_notes": version_data.get("migration_notes", ""),
            "created_by": version_data.get("created_by", "system"),
            "version_type": version_data.get("version_type", "minor")  # major, minor, patch
        },
        "sla_requirements": version_data.get("sla_requirements", {
            "availability": "99.9%",
            "latency_max": "100ms",
            "throughput_min": "1000 req/s"
        }),
        "quality_rules": version_data.get("quality_rules", []),
        "data_schema": version_data.get("data_schema", {}),
        "retention_policy": version_data.get("retention_policy", {}),
        "access_permissions": version_data.get("access_permissions", []),
        "masking_rules": version_data.get("masking_rules", []),
        "created_at": datetime.utcnow().isoformat(),
        "updated_at": datetime.utcnow().isoformat()
    }
    
    # Simular salvamento no banco (usando metadata da tabela contracts)
    logger.info(f"Nova versão criada: {new_version_id} para contrato {contract_id}")
    
    return {
        "message": "Nova versão do contrato criada com sucesso",
        "version_id": new_version_id,
        "parent_contract_id": contract_id,
        "version": version_data["version"],
        "contract": new_version
    }

@router.get("/{contract_id}/versions", response_model=List[Dict])
async def list_contract_versions(
    contract_id: int = Path(..., gt=0),
    include_draft: bool = Query(False, description="Incluir versões em draft"),
    db: Session = Depends(get_db)
):
    """Listar todas as versões de um contrato"""
    logger.info(f"Listando versões do contrato ID: {contract_id}")
    
    if contract_id > 5:
        raise HTTPException(status_code=404, detail="Contrato não encontrado")
    
    # Simular busca de versões (usando metadata para filtrar)
    versions = [
        {
            "id": contract_id,
            "version": "1.0.0",
            "status": "active",
            "is_current": True,
            "created_at": "2025-01-01T10:00:00Z",
            "created_by": "admin@company.com",
            "changes_description": "Versão inicial do contrato",
            "breaking_changes": False
        },
        {
            "id": contract_id + 100,
            "version": "1.1.0",
            "status": "active",
            "is_current": False,
            "created_at": "2025-01-05T14:30:00Z",
            "created_by": "data_engineer@company.com",
            "changes_description": "Adicionado campo opcional 'department'",
            "breaking_changes": False
        },
        {
            "id": contract_id + 200,
            "version": "2.0.0",
            "status": "draft" if include_draft else "active",
            "is_current": False,
            "created_at": "2025-01-10T09:15:00Z",
            "created_by": "architect@company.com",
            "changes_description": "Reestruturação do schema - BREAKING CHANGE",
            "breaking_changes": True
        }
    ]
    
    # Filtrar drafts se necessário
    if not include_draft:
        versions = [v for v in versions if v["status"] != "draft"]
    
    return versions

@router.get("/{contract_id}/versions/{version}", response_model=Dict)
async def get_contract_version(
    contract_id: int = Path(..., gt=0),
    version: str = Path(..., description="Versão específica (ex: 1.0.0)"),
    db: Session = Depends(get_db)
):
    """Obter versão específica de um contrato"""
    logger.info(f"Obtendo versão {version} do contrato ID: {contract_id}")
    
    if contract_id > 5:
        raise HTTPException(status_code=404, detail="Contrato não encontrado")
    
    # Simular busca de versão específica
    if version not in ["1.0.0", "1.1.0", "2.0.0"]:
        raise HTTPException(status_code=404, detail=f"Versão {version} não encontrada")
    
    version_details = {
        "id": contract_id + (100 if version == "1.1.0" else 200 if version == "2.0.0" else 0),
        "name": f"Contrato de Dados v{version}",
        "description": f"Contrato versão {version}",
        "entity_id": contract_id,
        "provider": f"Sistema Origem {contract_id}",
        "consumer": f"Sistema Destino {contract_id}",
        "status": "active" if version != "2.0.0" else "draft",
        "version": version,
        "parent_contract_id": contract_id if version != "1.0.0" else None,
        "version_metadata": {
            "changes_description": {
                "1.0.0": "Versão inicial do contrato",
                "1.1.0": "Adicionado campo opcional 'department'",
                "2.0.0": "Reestruturação do schema - BREAKING CHANGE"
            }[version],
            "breaking_changes": version == "2.0.0",
            "migration_notes": "Consultar documentação de migração" if version == "2.0.0" else "",
            "created_by": "system",
            "version_type": "major" if version == "2.0.0" else "minor"
        },
        "sla_requirements": {
            "availability": "99.9%",
            "latency_max": "100ms",
            "throughput_min": "1000 req/s"
        },
        "quality_rules": [
            {"field": "customer_id", "rule": "not_null", "threshold": 100},
            {"field": "email", "rule": "valid_email", "threshold": 95}
        ],
        "data_schema": {
            "customer_id": {"type": "integer", "required": True},
            "name": {"type": "string", "required": True},
            "email": {"type": "string", "required": True},
            "phone": {"type": "string", "required": False},
            "department": {"type": "string", "required": False} if version in ["1.1.0", "2.0.0"] else None
        },
        "created_at": {
            "1.0.0": "2025-01-01T10:00:00Z",
            "1.1.0": "2025-01-05T14:30:00Z",
            "2.0.0": "2025-01-10T09:15:00Z"
        }[version],
        "updated_at": datetime.utcnow().isoformat()
    }
    
    # Remover campos None
    version_details["data_schema"] = {k: v for k, v in version_details["data_schema"].items() if v is not None}
    
    return version_details

@router.post("/{contract_id}/versions/{version}/activate", response_model=Dict)
async def activate_contract_version(
    contract_id: int = Path(..., gt=0),
    version: str = Path(..., description="Versão a ser ativada"),
    activation_data: Dict = Body(default={}),
    db: Session = Depends(get_db)
):
    """Ativar uma versão específica do contrato"""
    logger.info(f"Ativando versão {version} do contrato ID: {contract_id}")
    
    if contract_id > 5:
        raise HTTPException(status_code=404, detail="Contrato não encontrado")
    
    if version not in ["1.0.0", "1.1.0", "2.0.0"]:
        raise HTTPException(status_code=404, detail=f"Versão {version} não encontrada")
    
    # Verificar se é breaking change
    is_breaking = version == "2.0.0"
    if is_breaking and not activation_data.get("confirm_breaking_changes", False):
        raise HTTPException(
            status_code=400, 
            detail="Esta versão contém breaking changes. Confirme com 'confirm_breaking_changes': true"
        )
    
    activation_result = {
        "contract_id": contract_id,
        "activated_version": version,
        "previous_version": "1.1.0",  # Simular versão anterior
        "activation_timestamp": datetime.utcnow().isoformat(),
        "activated_by": activation_data.get("activated_by", "system"),
        "breaking_changes": is_breaking,
        "migration_required": is_breaking,
        "rollback_available": True,
        "status": "active",
        "message": f"Versão {version} ativada com sucesso"
    }
    
    if is_breaking:
        activation_result["migration_notes"] = [
            "Schema foi reestruturado",
            "Verificar compatibilidade com sistemas consumidores",
            "Executar testes de integração",
            "Monitorar métricas de qualidade"
        ]
    
    return activation_result

@router.post("/{contract_id}/versions/compare", response_model=Dict)
async def compare_contract_versions(
    contract_id: int = Path(..., gt=0),
    comparison_data: Dict = Body(...),
    db: Session = Depends(get_db)
):
    """Comparar duas versões de um contrato"""
    logger.info(f"Comparando versões do contrato ID: {contract_id}")
    
    if contract_id > 5:
        raise HTTPException(status_code=404, detail="Contrato não encontrado")
    
    version_from = comparison_data.get("version_from")
    version_to = comparison_data.get("version_to")
    
    if not version_from or not version_to:
        raise HTTPException(status_code=400, detail="Versões 'version_from' e 'version_to' são obrigatórias")
    
    # Simular comparação
    comparison_result = {
        "contract_id": contract_id,
        "version_from": version_from,
        "version_to": version_to,
        "comparison_timestamp": datetime.utcnow().isoformat(),
        "differences": {
            "schema_changes": [
                {
                    "field": "department",
                    "change_type": "added",
                    "old_value": None,
                    "new_value": {"type": "string", "required": False}
                }
            ] if version_from == "1.0.0" and version_to == "1.1.0" else [],
            "sla_changes": [],
            "quality_rule_changes": [],
            "permission_changes": []
        },
        "breaking_changes": version_to == "2.0.0",
        "compatibility_score": 95.0 if version_to != "2.0.0" else 60.0,
        "migration_complexity": "low" if version_to != "2.0.0" else "high",
        "recommendations": [
            "Versão compatível - migração segura" if version_to != "2.0.0" else "Breaking changes detectados - planeje migração cuidadosamente",
            "Executar testes de regressão",
            "Monitorar métricas após migração"
        ]
    }
    
    return comparison_result

