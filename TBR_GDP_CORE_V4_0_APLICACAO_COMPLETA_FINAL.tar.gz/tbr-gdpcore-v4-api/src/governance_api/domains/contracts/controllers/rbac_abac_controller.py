"""
TBR GDP Core v3.0 - Controller Avançado de RBAC/ABAC
Implementação completa de Role-Based Access Control (RBAC) e Attribute-Based Access Control (ABAC)
com visibilidade granular de permissionamento por contrato
"""

from fastapi import APIRouter, Depends, HTTPException, Query, Path, Body
from sqlalchemy.orm import Session
from typing import List, Optional, Dict, Any
import logging
from datetime import datetime, timedelta
import uuid
import json

from governance_api.core.database import get_db
from governance_api.shared.models import PaginationSchema, FilterSchema, SuccessSchema

# Configurar logging
logger = logging.getLogger(__name__)

# Criar router
router = APIRouter()

# ===========================
# SCHEMAS PARA RBAC/ABAC
# ===========================

class RolePermissionSchema:
    def __init__(self, **data):
        self.role_name = data.get("role_name")
        self.permissions = data.get("permissions", [])
        self.conditions = data.get("conditions", {})
        self.attributes = data.get("attributes", {})

class AccessRequestSchema:
    def __init__(self, **data):
        self.user_id = data.get("user_id")
        self.user_role = data.get("user_role")
        self.contract_id = data.get("contract_id")
        self.operation = data.get("operation")
        self.context = data.get("context", {})
        self.attributes = data.get("attributes", {})

class PolicySchema:
    def __init__(self, **data):
        self.policy_name = data.get("policy_name")
        self.policy_type = data.get("policy_type")  # RBAC, ABAC, Hybrid
        self.rules = data.get("rules", [])
        self.conditions = data.get("conditions", {})
        self.priority = data.get("priority", 100)

# ===========================
# RBAC - ROLE-BASED ACCESS CONTROL
# ===========================

@router.get("/rbac/roles", response_model=List[Dict])
async def list_roles(
    include_permissions: bool = Query(True, description="Incluir permissões detalhadas"),
    db: Session = Depends(get_db)
):
    """Listar todas as roles disponíveis no sistema"""
    logger.info("Listando roles RBAC disponíveis")
    
    roles = [
        {
            "role_id": "admin",
            "role_name": "Administrator",
            "description": "Acesso completo ao sistema",
            "level": 1,
            "permissions": [
                "read", "write", "delete", "approve", "configure", "audit"
            ] if include_permissions else [],
            "contract_permissions": {
                "create_contract": True,
                "modify_contract": True,
                "delete_contract": True,
                "approve_contract": True,
                "view_all_contracts": True,
                "manage_permissions": True
            } if include_permissions else {},
            "data_access": {
                "level": "full",
                "masking_exempt": True,
                "sensitive_data": True,
                "pii_access": True
            } if include_permissions else {},
            "restrictions": {
                "time_based": False,
                "ip_based": False,
                "location_based": False
            } if include_permissions else {},
            "created_at": "2025-01-01T00:00:00Z",
            "is_active": True
        },
        {
            "role_id": "data_engineer",
            "role_name": "Data Engineer",
            "description": "Engenheiro de dados com acesso técnico",
            "level": 2,
            "permissions": [
                "read", "write", "execute", "monitor"
            ] if include_permissions else [],
            "contract_permissions": {
                "create_contract": True,
                "modify_contract": True,
                "delete_contract": False,
                "approve_contract": False,
                "view_all_contracts": True,
                "manage_permissions": False
            } if include_permissions else {},
            "data_access": {
                "level": "technical",
                "masking_exempt": False,
                "sensitive_data": True,
                "pii_access": False
            } if include_permissions else {},
            "restrictions": {
                "time_based": False,
                "ip_based": True,
                "location_based": False
            } if include_permissions else {},
            "created_at": "2025-01-01T00:00:00Z",
            "is_active": True
        },
        {
            "role_id": "data_analyst",
            "role_name": "Data Analyst",
            "description": "Analista de dados com acesso limitado",
            "level": 3,
            "permissions": [
                "read", "analyze", "report"
            ] if include_permissions else [],
            "contract_permissions": {
                "create_contract": False,
                "modify_contract": False,
                "delete_contract": False,
                "approve_contract": False,
                "view_all_contracts": False,
                "manage_permissions": False
            } if include_permissions else {},
            "data_access": {
                "level": "analytical",
                "masking_exempt": False,
                "sensitive_data": False,
                "pii_access": False
            } if include_permissions else {},
            "restrictions": {
                "time_based": True,
                "ip_based": True,
                "location_based": True
            } if include_permissions else {},
            "created_at": "2025-01-01T00:00:00Z",
            "is_active": True
        },
        {
            "role_id": "business_user",
            "role_name": "Business User",
            "description": "Usuário de negócio com acesso básico",
            "level": 4,
            "permissions": [
                "read", "view_reports"
            ] if include_permissions else [],
            "contract_permissions": {
                "create_contract": False,
                "modify_contract": False,
                "delete_contract": False,
                "approve_contract": False,
                "view_all_contracts": False,
                "manage_permissions": False
            } if include_permissions else {},
            "data_access": {
                "level": "business",
                "masking_exempt": False,
                "sensitive_data": False,
                "pii_access": False
            } if include_permissions else {},
            "restrictions": {
                "time_based": True,
                "ip_based": True,
                "location_based": True
            } if include_permissions else {},
            "created_at": "2025-01-01T00:00:00Z",
            "is_active": True
        },
        {
            "role_id": "data_steward",
            "role_name": "Data Steward",
            "description": "Responsável pela governança de dados",
            "level": 2,
            "permissions": [
                "read", "write", "approve", "govern", "audit"
            ] if include_permissions else [],
            "contract_permissions": {
                "create_contract": True,
                "modify_contract": True,
                "delete_contract": False,
                "approve_contract": True,
                "view_all_contracts": True,
                "manage_permissions": True
            } if include_permissions else {},
            "data_access": {
                "level": "governance",
                "masking_exempt": True,
                "sensitive_data": True,
                "pii_access": True
            } if include_permissions else {},
            "restrictions": {
                "time_based": False,
                "ip_based": False,
                "location_based": False
            } if include_permissions else {},
            "created_at": "2025-01-01T00:00:00Z",
            "is_active": True
        }
    ]
    
    return roles

@router.get("/rbac/roles/{role_id}/permissions", response_model=Dict)
async def get_role_permissions(
    role_id: str = Path(..., description="ID da role"),
    contract_id: Optional[int] = Query(None, description="Filtrar por contrato específico"),
    db: Session = Depends(get_db)
):
    """Obter permissões detalhadas de uma role específica"""
    logger.info(f"Obtendo permissões da role {role_id}")
    
    # Validar role
    valid_roles = ["admin", "data_engineer", "data_analyst", "business_user", "data_steward"]
    if role_id not in valid_roles:
        raise HTTPException(status_code=404, detail="Role não encontrada")
    
    # Definir permissões por role
    role_permissions = {
        "admin": {
            "global_permissions": [
                "create_contract", "read_contract", "update_contract", "delete_contract",
                "approve_contract", "reject_contract", "manage_users", "configure_system",
                "view_audit_logs", "manage_policies", "override_restrictions"
            ],
            "data_permissions": {
                "read_level": "full",
                "write_level": "full",
                "delete_level": "full",
                "masking_bypass": True,
                "pii_access": True,
                "sensitive_data_access": True
            },
            "contract_specific_permissions": {
                "view_contract_details": True,
                "modify_contract_schema": True,
                "manage_contract_permissions": True,
                "view_contract_lineage": True,
                "manage_contract_versions": True,
                "approve_contract_changes": True
            },
            "restrictions": {
                "time_based": False,
                "ip_whitelist": [],
                "location_restrictions": [],
                "session_timeout": "unlimited",
                "concurrent_sessions": "unlimited"
            }
        },
        "data_engineer": {
            "global_permissions": [
                "create_contract", "read_contract", "update_contract",
                "view_technical_metadata", "execute_pipelines", "monitor_quality"
            ],
            "data_permissions": {
                "read_level": "technical",
                "write_level": "technical",
                "delete_level": "limited",
                "masking_bypass": False,
                "pii_access": False,
                "sensitive_data_access": True
            },
            "contract_specific_permissions": {
                "view_contract_details": True,
                "modify_contract_schema": True,
                "manage_contract_permissions": False,
                "view_contract_lineage": True,
                "manage_contract_versions": True,
                "approve_contract_changes": False
            },
            "restrictions": {
                "time_based": False,
                "ip_whitelist": ["10.0.0.0/8", "192.168.0.0/16"],
                "location_restrictions": [],
                "session_timeout": "12 hours",
                "concurrent_sessions": 3
            }
        },
        "data_analyst": {
            "global_permissions": [
                "read_contract", "view_reports", "analyze_data", "create_dashboards"
            ],
            "data_permissions": {
                "read_level": "analytical",
                "write_level": "none",
                "delete_level": "none",
                "masking_bypass": False,
                "pii_access": False,
                "sensitive_data_access": False
            },
            "contract_specific_permissions": {
                "view_contract_details": True,
                "modify_contract_schema": False,
                "manage_contract_permissions": False,
                "view_contract_lineage": True,
                "manage_contract_versions": False,
                "approve_contract_changes": False
            },
            "restrictions": {
                "time_based": True,
                "business_hours_only": True,
                "ip_whitelist": ["10.0.0.0/8"],
                "location_restrictions": ["office"],
                "session_timeout": "8 hours",
                "concurrent_sessions": 1
            }
        },
        "business_user": {
            "global_permissions": [
                "read_contract", "view_reports", "request_data_access"
            ],
            "data_permissions": {
                "read_level": "business",
                "write_level": "none",
                "delete_level": "none",
                "masking_bypass": False,
                "pii_access": False,
                "sensitive_data_access": False
            },
            "contract_specific_permissions": {
                "view_contract_details": False,
                "modify_contract_schema": False,
                "manage_contract_permissions": False,
                "view_contract_lineage": False,
                "manage_contract_versions": False,
                "approve_contract_changes": False
            },
            "restrictions": {
                "time_based": True,
                "business_hours_only": True,
                "ip_whitelist": ["10.0.0.0/8"],
                "location_restrictions": ["office"],
                "session_timeout": "4 hours",
                "concurrent_sessions": 1
            }
        },
        "data_steward": {
            "global_permissions": [
                "create_contract", "read_contract", "update_contract", "approve_contract",
                "manage_data_quality", "define_policies", "audit_access", "govern_data"
            ],
            "data_permissions": {
                "read_level": "governance",
                "write_level": "governance",
                "delete_level": "limited",
                "masking_bypass": True,
                "pii_access": True,
                "sensitive_data_access": True
            },
            "contract_specific_permissions": {
                "view_contract_details": True,
                "modify_contract_schema": True,
                "manage_contract_permissions": True,
                "view_contract_lineage": True,
                "manage_contract_versions": True,
                "approve_contract_changes": True
            },
            "restrictions": {
                "time_based": False,
                "ip_whitelist": [],
                "location_restrictions": [],
                "session_timeout": "10 hours",
                "concurrent_sessions": 2
            }
        }
    }
    
    permissions = role_permissions.get(role_id, {})
    
    # Se contrato específico for solicitado, adicionar permissões específicas
    if contract_id:
        permissions["contract_specific"] = {
            "contract_id": contract_id,
            "access_level": permissions.get("data_permissions", {}).get("read_level", "none"),
            "can_modify": permissions.get("contract_specific_permissions", {}).get("modify_contract_schema", False),
            "can_approve": permissions.get("contract_specific_permissions", {}).get("approve_contract_changes", False),
            "masking_rules": {
                "email": not permissions.get("data_permissions", {}).get("masking_bypass", False),
                "phone": not permissions.get("data_permissions", {}).get("pii_access", False),
                "ssn": not permissions.get("data_permissions", {}).get("pii_access", False)
            }
        }
    
    permissions["role_id"] = role_id
    permissions["generated_at"] = datetime.utcnow().isoformat()
    
    return permissions

# ===========================
# ABAC - ATTRIBUTE-BASED ACCESS CONTROL
# ===========================

@router.post("/abac/evaluate", response_model=Dict)
async def evaluate_abac_policy(
    access_request: Dict = Body(...),
    db: Session = Depends(get_db)
):
    """Avaliar política ABAC baseada em atributos"""
    logger.info("Avaliando política ABAC")
    
    # Extrair atributos da requisição
    user_attributes = access_request.get("user_attributes", {})
    resource_attributes = access_request.get("resource_attributes", {})
    environment_attributes = access_request.get("environment_attributes", {})
    action_attributes = access_request.get("action_attributes", {})
    
    # Simular avaliação de política ABAC
    evaluation_result = {
        "request_id": str(uuid.uuid4()),
        "decision": "permit",  # permit, deny, indeterminate
        "evaluation_timestamp": datetime.utcnow().isoformat(),
        "policies_evaluated": [
            {
                "policy_id": "data_classification_policy",
                "policy_name": "Data Classification Access Policy",
                "result": "permit",
                "conditions_met": [
                    "user.clearance_level >= resource.classification_level",
                    "user.department == resource.owner_department",
                    "environment.time within business_hours"
                ]
            },
            {
                "policy_id": "contract_access_policy",
                "policy_name": "Contract-Specific Access Policy",
                "result": "permit",
                "conditions_met": [
                    "user.role in resource.allowed_roles",
                    "action.type in resource.permitted_actions"
                ]
            }
        ],
        "attributes_used": {
            "user_attributes": {
                "user_id": user_attributes.get("user_id", "user123"),
                "role": user_attributes.get("role", "data_analyst"),
                "department": user_attributes.get("department", "analytics"),
                "clearance_level": user_attributes.get("clearance_level", 3),
                "location": user_attributes.get("location", "office"),
                "ip_address": user_attributes.get("ip_address", "10.0.1.100")
            },
            "resource_attributes": {
                "contract_id": resource_attributes.get("contract_id", 1),
                "classification_level": resource_attributes.get("classification_level", 2),
                "owner_department": resource_attributes.get("owner_department", "analytics"),
                "data_sensitivity": resource_attributes.get("data_sensitivity", "internal"),
                "allowed_roles": resource_attributes.get("allowed_roles", ["data_analyst", "data_engineer"])
            },
            "environment_attributes": {
                "current_time": environment_attributes.get("current_time", datetime.utcnow().isoformat()),
                "network_zone": environment_attributes.get("network_zone", "internal"),
                "security_level": environment_attributes.get("security_level", "standard")
            },
            "action_attributes": {
                "action_type": action_attributes.get("action_type", "read"),
                "urgency": action_attributes.get("urgency", "normal"),
                "purpose": action_attributes.get("purpose", "analysis")
            }
        },
        "obligations": [
            {
                "type": "audit_log",
                "description": "Log access for compliance",
                "required": True
            },
            {
                "type": "data_masking",
                "description": "Apply PII masking for this role",
                "required": True,
                "masking_rules": ["email_domain", "phone_partial"]
            },
            {
                "type": "session_timeout",
                "description": "Limit session duration",
                "required": True,
                "timeout_minutes": 480
            }
        ],
        "advice": [
            "Monitor usage patterns for anomaly detection",
            "Review access permissions quarterly",
            "Ensure data lineage is documented"
        ]
    }
    
    return evaluation_result

@router.get("/abac/policies", response_model=List[Dict])
async def list_abac_policies(
    policy_type: Optional[str] = Query(None, description="Filtrar por tipo de política"),
    active_only: bool = Query(True, description="Apenas políticas ativas"),
    db: Session = Depends(get_db)
):
    """Listar políticas ABAC configuradas"""
    logger.info("Listando políticas ABAC")
    
    policies = [
        {
            "policy_id": "data_classification_policy",
            "policy_name": "Data Classification Access Policy",
            "policy_type": "access_control",
            "description": "Controla acesso baseado na classificação dos dados",
            "priority": 100,
            "status": "active",
            "rules": [
                {
                    "rule_id": "clearance_check",
                    "condition": "user.clearance_level >= resource.classification_level",
                    "effect": "permit"
                },
                {
                    "rule_id": "department_match",
                    "condition": "user.department == resource.owner_department OR user.role == 'admin'",
                    "effect": "permit"
                }
            ],
            "attributes_required": {
                "user": ["clearance_level", "department", "role"],
                "resource": ["classification_level", "owner_department"],
                "environment": ["current_time"],
                "action": ["action_type"]
            },
            "created_at": "2025-01-01T00:00:00Z",
            "updated_at": "2025-01-11T10:00:00Z",
            "created_by": "admin@company.com"
        },
        {
            "policy_id": "time_based_access_policy",
            "policy_name": "Time-Based Access Policy",
            "policy_type": "temporal_control",
            "description": "Controla acesso baseado em horários e dias",
            "priority": 90,
            "status": "active",
            "rules": [
                {
                    "rule_id": "business_hours",
                    "condition": "environment.time within business_hours AND user.role != 'admin'",
                    "effect": "permit"
                },
                {
                    "rule_id": "emergency_access",
                    "condition": "action.urgency == 'emergency' AND user.emergency_contact_verified == true",
                    "effect": "permit"
                }
            ],
            "attributes_required": {
                "user": ["role", "emergency_contact_verified"],
                "environment": ["current_time"],
                "action": ["urgency"]
            },
            "created_at": "2025-01-01T00:00:00Z",
            "updated_at": "2025-01-11T10:00:00Z",
            "created_by": "security@company.com"
        },
        {
            "policy_id": "contract_specific_policy",
            "policy_name": "Contract-Specific Access Policy",
            "policy_type": "resource_control",
            "description": "Controla acesso específico por contrato de dados",
            "priority": 95,
            "status": "active",
            "rules": [
                {
                    "rule_id": "contract_role_check",
                    "condition": "user.role in resource.allowed_roles",
                    "effect": "permit"
                },
                {
                    "rule_id": "contract_action_check",
                    "condition": "action.type in resource.permitted_actions",
                    "effect": "permit"
                },
                {
                    "rule_id": "contract_expiry_check",
                    "condition": "environment.current_time < resource.contract_expiry",
                    "effect": "permit"
                }
            ],
            "attributes_required": {
                "user": ["role", "user_id"],
                "resource": ["allowed_roles", "permitted_actions", "contract_expiry"],
                "environment": ["current_time"],
                "action": ["action_type"]
            },
            "created_at": "2025-01-01T00:00:00Z",
            "updated_at": "2025-01-11T10:00:00Z",
            "created_by": "data_steward@company.com"
        },
        {
            "policy_id": "pii_protection_policy",
            "policy_name": "PII Protection Policy",
            "policy_type": "data_protection",
            "description": "Protege dados pessoais identificáveis",
            "priority": 110,
            "status": "active",
            "rules": [
                {
                    "rule_id": "pii_access_check",
                    "condition": "resource.contains_pii == true AND user.pii_training_completed == true",
                    "effect": "permit_with_masking"
                },
                {
                    "rule_id": "admin_pii_bypass",
                    "condition": "user.role == 'admin' OR user.role == 'data_steward'",
                    "effect": "permit_full_access"
                }
            ],
            "attributes_required": {
                "user": ["role", "pii_training_completed"],
                "resource": ["contains_pii", "pii_fields"],
                "action": ["action_type"]
            },
            "created_at": "2025-01-01T00:00:00Z",
            "updated_at": "2025-01-11T10:00:00Z",
            "created_by": "compliance@company.com"
        }
    ]
    
    # Filtrar por tipo se especificado
    if policy_type:
        policies = [p for p in policies if p["policy_type"] == policy_type]
    
    # Filtrar apenas ativas se especificado
    if active_only:
        policies = [p for p in policies if p["status"] == "active"]
    
    return policies

# ===========================
# CONTRATOS COM RBAC/ABAC
# ===========================

@router.get("/contracts/{contract_id}/permissions/matrix", response_model=Dict)
async def get_contract_permission_matrix(
    contract_id: int = Path(..., gt=0),
    include_abac: bool = Query(True, description="Incluir avaliação ABAC"),
    db: Session = Depends(get_db)
):
    """Obter matriz completa de permissões para um contrato específico"""
    logger.info(f"Obtendo matriz de permissões para contrato {contract_id}")
    
    if contract_id > 5:
        raise HTTPException(status_code=404, detail="Contrato não encontrado")
    
    # Simular matriz de permissões
    permission_matrix = {
        "contract_id": contract_id,
        "contract_name": f"Contrato de Dados {contract_id}",
        "data_classification": "confidential",
        "contains_pii": True,
        "rbac_permissions": {
            "admin": {
                "read": True,
                "write": True,
                "delete": True,
                "approve": True,
                "manage_permissions": True,
                "view_lineage": True,
                "masking_exempt": True,
                "restrictions": []
            },
            "data_steward": {
                "read": True,
                "write": True,
                "delete": False,
                "approve": True,
                "manage_permissions": True,
                "view_lineage": True,
                "masking_exempt": True,
                "restrictions": []
            },
            "data_engineer": {
                "read": True,
                "write": True,
                "delete": False,
                "approve": False,
                "manage_permissions": False,
                "view_lineage": True,
                "masking_exempt": False,
                "restrictions": ["ip_whitelist"]
            },
            "data_analyst": {
                "read": True,
                "write": False,
                "delete": False,
                "approve": False,
                "manage_permissions": False,
                "view_lineage": True,
                "masking_exempt": False,
                "restrictions": ["business_hours", "ip_whitelist", "session_timeout"]
            },
            "business_user": {
                "read": True,
                "write": False,
                "delete": False,
                "approve": False,
                "manage_permissions": False,
                "view_lineage": False,
                "masking_exempt": False,
                "restrictions": ["business_hours", "ip_whitelist", "session_timeout", "location_based"]
            }
        },
        "abac_policies_applied": [
            {
                "policy_id": "data_classification_policy",
                "policy_name": "Data Classification Access Policy",
                "effect": "additional_restrictions",
                "conditions": [
                    "user.clearance_level >= 3 for confidential data",
                    "user.department matches data owner department"
                ]
            },
            {
                "policy_id": "pii_protection_policy",
                "policy_name": "PII Protection Policy",
                "effect": "masking_required",
                "conditions": [
                    "PII training completion required",
                    "Automatic masking for non-exempt roles"
                ]
            }
        ] if include_abac else [],
        "field_level_permissions": {
            "customer_id": {
                "admin": "full_access",
                "data_steward": "full_access",
                "data_engineer": "full_access",
                "data_analyst": "full_access",
                "business_user": "full_access"
            },
            "name": {
                "admin": "full_access",
                "data_steward": "full_access",
                "data_engineer": "full_access",
                "data_analyst": "full_access",
                "business_user": "full_access"
            },
            "email": {
                "admin": "full_access",
                "data_steward": "full_access",
                "data_engineer": "masked_domain",
                "data_analyst": "masked_full",
                "business_user": "masked_full"
            },
            "phone": {
                "admin": "full_access",
                "data_steward": "full_access",
                "data_engineer": "full_access",
                "data_analyst": "masked_partial",
                "business_user": "masked_full"
            },
            "ssn": {
                "admin": "full_access",
                "data_steward": "full_access",
                "data_engineer": "denied",
                "data_analyst": "denied",
                "business_user": "denied"
            }
        },
        "audit_requirements": {
            "log_all_access": True,
            "log_failed_attempts": True,
            "retention_period_days": 2555,  # 7 anos
            "compliance_frameworks": ["LGPD", "GDPR", "SOX"]
        },
        "generated_at": datetime.utcnow().isoformat()
    }
    
    return permission_matrix

@router.post("/contracts/{contract_id}/permissions/validate", response_model=Dict)
async def validate_contract_access(
    contract_id: int = Path(..., gt=0),
    access_request: Dict = Body(...),
    use_abac: bool = Query(True, description="Usar avaliação ABAC"),
    db: Session = Depends(get_db)
):
    """Validar acesso a um contrato usando RBAC e/ou ABAC"""
    logger.info(f"Validando acesso ao contrato {contract_id}")
    
    if contract_id > 5:
        raise HTTPException(status_code=404, detail="Contrato não encontrado")
    
    user_role = access_request.get("user_role", "")
    user_attributes = access_request.get("user_attributes", {})
    requested_operation = access_request.get("operation", "read")
    context = access_request.get("context", {})
    
    # Validação RBAC
    rbac_result = {
        "method": "RBAC",
        "decision": "permit" if user_role in ["admin", "data_steward", "data_engineer", "data_analyst"] else "deny",
        "role_permissions": {
            "read": user_role in ["admin", "data_steward", "data_engineer", "data_analyst", "business_user"],
            "write": user_role in ["admin", "data_steward", "data_engineer"],
            "delete": user_role in ["admin"],
            "approve": user_role in ["admin", "data_steward"]
        },
        "restrictions_applied": []
    }
    
    # Adicionar restrições baseadas na role
    if user_role == "data_analyst":
        rbac_result["restrictions_applied"].extend([
            "business_hours_only", "ip_whitelist", "session_timeout_8h"
        ])
    elif user_role == "business_user":
        rbac_result["restrictions_applied"].extend([
            "business_hours_only", "ip_whitelist", "session_timeout_4h", "location_office_only"
        ])
    
    # Validação ABAC (se solicitada)
    abac_result = None
    if use_abac:
        abac_result = {
            "method": "ABAC",
            "decision": "permit",
            "policies_evaluated": [
                {
                    "policy_id": "data_classification_policy",
                    "result": "permit",
                    "conditions_met": True
                },
                {
                    "policy_id": "contract_specific_policy",
                    "result": "permit",
                    "conditions_met": True
                }
            ],
            "additional_obligations": [
                "audit_access",
                "apply_pii_masking" if user_role not in ["admin", "data_steward"] else "no_masking"
            ]
        }
    
    # Decisão final
    final_decision = "permit"
    if rbac_result["decision"] == "deny":
        final_decision = "deny"
    elif abac_result and abac_result["decision"] == "deny":
        final_decision = "deny"
    
    validation_result = {
        "contract_id": contract_id,
        "user_role": user_role,
        "requested_operation": requested_operation,
        "final_decision": final_decision,
        "evaluation_methods": {
            "rbac": rbac_result,
            "abac": abac_result
        },
        "effective_permissions": {
            "data_access_level": "full" if user_role in ["admin", "data_steward"] else "masked",
            "masking_rules": {
                "email": user_role not in ["admin", "data_steward"],
                "phone": user_role not in ["admin", "data_steward", "data_engineer"],
                "ssn": user_role not in ["admin", "data_steward"]
            },
            "session_restrictions": {
                "max_duration": "unlimited" if user_role in ["admin", "data_steward"] else "8 hours",
                "concurrent_sessions": 5 if user_role == "admin" else 2 if user_role in ["data_steward", "data_engineer"] else 1,
                "ip_restrictions": user_role not in ["admin", "data_steward"]
            }
        },
        "audit_trail": {
            "access_logged": True,
            "log_level": "detailed" if user_role in ["admin", "data_steward"] else "standard",
            "compliance_flags": ["LGPD", "GDPR"] if "pii" in context.get("data_types", []) else []
        },
        "validated_at": datetime.utcnow().isoformat(),
        "expires_at": (datetime.utcnow() + timedelta(hours=8)).isoformat()
    }
    
    return validation_result

@router.get("/contracts/{contract_id}/permissions/audit", response_model=Dict)
async def get_contract_access_audit(
    contract_id: int = Path(..., gt=0),
    days: int = Query(30, ge=1, le=365, description="Período em dias"),
    user_role: Optional[str] = Query(None, description="Filtrar por role"),
    operation: Optional[str] = Query(None, description="Filtrar por operação"),
    db: Session = Depends(get_db)
):
    """Obter auditoria de acessos a um contrato"""
    logger.info(f"Obtendo auditoria de acessos do contrato {contract_id}")
    
    if contract_id > 5:
        raise HTTPException(status_code=404, detail="Contrato não encontrado")
    
    # Simular dados de auditoria
    audit_data = {
        "contract_id": contract_id,
        "audit_period_days": days,
        "total_access_attempts": 1247,
        "successful_accesses": 1198,
        "denied_accesses": 49,
        "success_rate": 96.07,
        "access_by_role": {
            "admin": {"attempts": 45, "successful": 45, "denied": 0},
            "data_steward": {"attempts": 89, "successful": 89, "denied": 0},
            "data_engineer": {"attempts": 456, "successful": 445, "denied": 11},
            "data_analyst": {"attempts": 567, "successful": 534, "denied": 33},
            "business_user": {"attempts": 90, "successful": 85, "denied": 5}
        },
        "access_by_operation": {
            "read": {"attempts": 1089, "successful": 1067, "denied": 22},
            "write": {"attempts": 134, "successful": 120, "denied": 14},
            "delete": {"attempts": 12, "successful": 11, "denied": 1},
            "approve": {"attempts": 12, "successful": 0, "denied": 12}
        },
        "denied_access_reasons": [
            {"reason": "insufficient_role_permissions", "count": 27},
            {"reason": "outside_business_hours", "count": 15},
            {"reason": "ip_not_whitelisted", "count": 4},
            {"reason": "session_expired", "count": 3}
        ],
        "peak_usage_patterns": {
            "busiest_hour": "14:00-15:00",
            "busiest_day": "Wednesday",
            "average_daily_accesses": 41.6,
            "weekend_access_percentage": 8.2
        },
        "compliance_metrics": {
            "audit_log_completeness": 100.0,
            "pii_access_properly_logged": 100.0,
            "unauthorized_access_attempts": 0,
            "data_breach_incidents": 0
        },
        "recent_access_events": [
            {
                "timestamp": "2025-01-11T14:30:00Z",
                "user_id": "analyst_001",
                "user_role": "data_analyst",
                "operation": "read",
                "result": "success",
                "ip_address": "10.0.1.45",
                "session_duration": "2h 15m"
            },
            {
                "timestamp": "2025-01-11T14:25:00Z",
                "user_id": "engineer_003",
                "user_role": "data_engineer",
                "operation": "write",
                "result": "success",
                "ip_address": "10.0.1.67",
                "session_duration": "45m"
            },
            {
                "timestamp": "2025-01-11T14:20:00Z",
                "user_id": "business_005",
                "user_role": "business_user",
                "operation": "read",
                "result": "denied",
                "reason": "outside_business_hours",
                "ip_address": "10.0.1.89"
            }
        ],
        "generated_at": datetime.utcnow().isoformat()
    }
    
    # Aplicar filtros se especificados
    if user_role and user_role in audit_data["access_by_role"]:
        audit_data["filtered_by_role"] = user_role
        audit_data["role_specific_stats"] = audit_data["access_by_role"][user_role]
    
    if operation and operation in audit_data["access_by_operation"]:
        audit_data["filtered_by_operation"] = operation
        audit_data["operation_specific_stats"] = audit_data["access_by_operation"][operation]
    
    return audit_data

# ===========================
# DASHBOARD DE PERMISSÕES
# ===========================

@router.get("/permissions/dashboard", response_model=Dict)
async def get_permissions_dashboard(
    include_trends: bool = Query(True, description="Incluir tendências temporais"),
    db: Session = Depends(get_db)
):
    """Dashboard executivo de permissões e acessos"""
    logger.info("Gerando dashboard de permissões")
    
    dashboard = {
        "overview": {
            "total_contracts": 156,
            "total_users": 1247,
            "total_roles": 5,
            "total_policies": 12,
            "active_sessions": 89,
            "access_requests_today": 2456
        },
        "security_metrics": {
            "overall_compliance_score": 94.8,
            "rbac_coverage": 100.0,
            "abac_coverage": 87.3,
            "audit_completeness": 99.2,
            "unauthorized_attempts_24h": 3,
            "security_incidents_30d": 0
        },
        "access_patterns": {
            "most_accessed_contracts": [
                {"contract_id": 1, "name": "Customer Data Contract", "accesses": 456},
                {"contract_id": 3, "name": "Financial Data Contract", "accesses": 234},
                {"contract_id": 2, "name": "Product Data Contract", "accesses": 189}
            ],
            "most_active_roles": [
                {"role": "data_analyst", "users": 45, "accesses": 1234},
                {"role": "data_engineer", "users": 23, "accesses": 987},
                {"role": "business_user", "users": 156, "accesses": 567}
            ],
            "peak_usage_hours": ["09:00-10:00", "14:00-15:00", "16:00-17:00"]
        },
        "permission_violations": {
            "total_violations_30d": 23,
            "by_type": {
                "insufficient_permissions": 12,
                "time_restrictions": 7,
                "ip_restrictions": 3,
                "session_expired": 1
            },
            "by_role": {
                "data_analyst": 15,
                "business_user": 6,
                "data_engineer": 2
            }
        },
        "trends": {
            "access_growth_30d": 12.5,
            "new_users_30d": 34,
            "policy_updates_30d": 5,
            "compliance_trend": "improving"
        } if include_trends else {},
        "recommendations": [
            "Revisar permissões de data_analyst para reduzir violações",
            "Implementar treinamento adicional sobre horários de acesso",
            "Considerar expansão da whitelist de IPs para trabalho remoto",
            "Atualizar políticas ABAC para melhor cobertura"
        ],
        "generated_at": datetime.utcnow().isoformat()
    }
    
    return dashboard

