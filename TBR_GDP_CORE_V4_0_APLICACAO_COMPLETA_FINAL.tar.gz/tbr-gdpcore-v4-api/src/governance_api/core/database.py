"""
TBR GDP Core v1.0 - Sistema de Database
Configuração e conexão com PostgreSQL
"""

from sqlalchemy import create_engine, MetaData
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.pool import StaticPool
from typing import Generator
import logging

from .config import settings

logger = logging.getLogger(__name__)

# Configurar engine do SQLAlchemy
engine = create_engine(
    settings.database_url,
    echo=settings.database_echo,
    pool_pre_ping=True,
    pool_recycle=300,
    connect_args={"check_same_thread": False} if "sqlite" in settings.database_url else {}
)

# Configurar session factory
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Base para modelos
Base = declarative_base()

# Metadata para reflexão
metadata = MetaData()

def get_db() -> Generator[Session, None, None]:
    """
    Dependency para obter sessão do banco de dados
    """
    db = SessionLocal()
    try:
        yield db
    except Exception as e:
        logger.error(f"Erro na sessão do banco: {e}")
        db.rollback()
        raise
    finally:
        db.close()

def create_tables():
    """
    Criar todas as tabelas no banco de dados
    """
    try:
        Base.metadata.create_all(bind=engine)
        logger.info("Tabelas criadas com sucesso")
    except Exception as e:
        logger.error(f"Erro ao criar tabelas: {e}")
        raise

def drop_tables():
    """
    Remover todas as tabelas do banco de dados
    """
    try:
        Base.metadata.drop_all(bind=engine)
        logger.info("Tabelas removidas com sucesso")
    except Exception as e:
        logger.error(f"Erro ao remover tabelas: {e}")
        raise

def check_connection() -> bool:
    """
    Verificar conexão com o banco de dados
    """
    try:
        with engine.connect() as connection:
            connection.execute("SELECT 1")
        logger.info("Conexão com banco de dados OK")
        return True
    except Exception as e:
        logger.error(f"Erro na conexão com banco: {e}")
        return False

class DatabaseManager:
    """
    Gerenciador de operações do banco de dados
    """
    
    def __init__(self):
        self.engine = engine
        self.session_factory = SessionLocal
    
    def get_session(self) -> Session:
        """Obter nova sessão"""
        return self.session_factory()
    
    def execute_raw_sql(self, sql: str, params: dict = None):
        """Executar SQL raw"""
        with self.engine.connect() as connection:
            return connection.execute(sql, params or {})
    
    def backup_database(self, backup_path: str):
        """Backup do banco de dados"""
        # Implementar backup específico por tipo de banco
        pass
    
    def restore_database(self, backup_path: str):
        """Restaurar banco de dados"""
        # Implementar restore específico por tipo de banco
        pass

# Instância global do gerenciador
db_manager = DatabaseManager()

