"""
TBR GDP Core - Data Governance API
Unity Catalog External Lineage Endpoints

Endpoints para integração com Unity Catalog External Lineage
baseados no modelo DBML completo.
"""

from flask import Blueprint, request, jsonify, g
from flask_restx import Namespace, Resource, fields
from datetime import datetime
import uuid

# Criar namespace
external_lineage_ns = Namespace(
    'external-lineage', 
    description='Unity Catalog External Lineage - Integração com metadados externos'
)

# Modelos Swagger
external_metadata_model = external_lineage_ns.model('ExternalMetadata', {
    'external_metadata_id': fields.String(description='ID único do metadado externo'),
    'name': fields.String(required=True, description='Nome human-readable do objeto externo'),
    'system_type': fields.String(required=True, description='Tipo do sistema externo', 
                                enum=['tableau', 'powerbi', 'salesforce', 'mysql', 'custom']),
    'entity_type': fields.String(required=True, description='Tipo da entidade',
                                enum=['table', 'dashboard', 'report', 'dataset']),
    'external_url': fields.String(description='URL do objeto externo'),
    'description': fields.String(description='Descrição detalhada'),
    'properties': fields.Raw(description='Propriedades customizadas em JSON'),
    'unity_catalog_metastore_id': fields.String(description='ID do metastore Unity Catalog'),
    'unity_catalog_external_id': fields.String(description='ID no Unity Catalog External Lineage'),
    'is_active': fields.Boolean(description='Se o objeto está ativo'),
    'validation_status': fields.String(enum=['validated', 'pending', 'failed', 'deprecated']),
    'last_validated_at': fields.DateTime(description='Última validação'),
    'last_synced_at': fields.DateTime(description='Última sincronização'),
    'sync_status': fields.String(enum=['synced', 'pending', 'failed', 'conflict']),
    'created_at': fields.DateTime(description='Data de criação'),
    'updated_at': fields.DateTime(description='Data de atualização')
})

external_metadata_create_model = external_lineage_ns.model('ExternalMetadataCreate', {
    'name': fields.String(required=True, description='Nome do objeto externo'),
    'system_type': fields.String(required=True, description='Tipo do sistema'),
    'entity_type': fields.String(required=True, description='Tipo da entidade'),
    'external_url': fields.String(description='URL do objeto'),
    'description': fields.String(description='Descrição'),
    'properties': fields.Raw(description='Propriedades customizadas'),
    'unity_catalog_metastore_id': fields.String(description='ID do metastore')
})

column_mapping_model = external_lineage_ns.model('ColumnMapping', {
    'mapping_id': fields.String(description='ID único do mapeamento'),
    'external_metadata_id': fields.String(required=True, description='ID do metadado externo'),
    'source_column_name': fields.String(required=True, description='Nome da coluna no sistema externo'),
    'source_column_type': fields.String(description='Tipo da coluna externa'),
    'source_column_description': fields.String(description='Descrição da coluna'),
    'target_column_name': fields.String(description='Nome da coluna Unity Catalog'),
    'transformation_type': fields.String(description='Tipo de transformação',
                                       enum=['direct', 'calculated', 'aggregated']),
    'transformation_description': fields.String(description='Descrição da transformação'),
    'compatibility_status': fields.String(enum=['compatible', 'incompatible', 'warning', 'pending']),
    'created_at': fields.DateTime(description='Data de criação')
})

lineage_relationship_model = external_lineage_ns.model('LineageRelationship', {
    'relationship_id': fields.String(description='ID único do relacionamento'),
    'external_metadata_id': fields.String(required=True, description='ID do metadado externo'),
    'target_object_type': fields.String(required=True, description='Tipo do objeto Unity Catalog'),
    'target_object_id': fields.String(required=True, description='ID do objeto Unity Catalog'),
    'target_object_name': fields.String(description='Nome do objeto Unity Catalog'),
    'relationship_direction': fields.String(required=True, enum=['upstream', 'downstream']),
    'relationship_description': fields.String(description='Descrição do relacionamento'),
    'is_active': fields.Boolean(description='Se o relacionamento está ativo'),
    'validation_status': fields.String(enum=['validated', 'pending', 'failed']),
    'created_at': fields.DateTime(description='Data de criação')
})

@external_lineage_ns.route('/metadata')
class ExternalMetadataList(Resource):
    @external_lineage_ns.doc('list_external_metadata')
    @external_lineage_ns.marshal_list_with(external_metadata_model)
    @external_lineage_ns.param('system_type', 'Filtrar por tipo de sistema')
    @external_lineage_ns.param('entity_type', 'Filtrar por tipo de entidade')
    @external_lineage_ns.param('validation_status', 'Filtrar por status de validação')
    @external_lineage_ns.param('page', 'Número da página', type=int, default=1)
    @external_lineage_ns.param('limit', 'Itens por página', type=int, default=20)
    def get(self):
        """Lista todos os metadados externos registrados"""
        # Implementação simulada
        return [{
            'external_metadata_id': str(uuid.uuid4()),
            'name': 'customer_analytics_dashboard',
            'system_type': 'tableau',
            'entity_type': 'dashboard',
            'external_url': 'https://tableau.empresa.com/dashboards/customer_analytics',
            'description': 'Dashboard principal de analytics de clientes',
            'properties': {
                'workbook_name': 'Customer Analytics',
                'project': 'Sales & Marketing',
                'owner': 'analytics_team@empresa.com'
            },
            'unity_catalog_metastore_id': str(uuid.uuid4()),
            'unity_catalog_external_id': 'external_tableau_001',
            'is_active': True,
            'validation_status': 'validated',
            'last_validated_at': datetime.utcnow().isoformat(),
            'last_synced_at': datetime.utcnow().isoformat(),
            'sync_status': 'synced',
            'created_at': datetime.utcnow().isoformat(),
            'updated_at': datetime.utcnow().isoformat()
        }]
    
    @external_lineage_ns.doc('create_external_metadata')
    @external_lineage_ns.expect(external_metadata_create_model)
    @external_lineage_ns.marshal_with(external_metadata_model, code=201)
    def post(self):
        """Registra um novo metadado externo"""
        data = request.json
        
        # Aplicar localização se necessário
        if hasattr(g, 'tenant_id') and g.tenant_id:
            from src.utils.tenancy.geo_tenancy import geo_tenancy_manager
            data = geo_tenancy_manager.apply_localization(data, g.tenant_id)
        
        # Simular criação
        new_metadata = {
            'external_metadata_id': str(uuid.uuid4()),
            'name': data['name'],
            'system_type': data['system_type'],
            'entity_type': data['entity_type'],
            'external_url': data.get('external_url'),
            'description': data.get('description'),
            'properties': data.get('properties', {}),
            'unity_catalog_metastore_id': data.get('unity_catalog_metastore_id'),
            'unity_catalog_external_id': f"external_{data['system_type']}_{datetime.utcnow().strftime('%Y%m%d%H%M%S')}",
            'is_active': True,
            'validation_status': 'pending',
            'sync_status': 'pending',
            'created_at': datetime.utcnow().isoformat(),
            'updated_at': datetime.utcnow().isoformat()
        }
        
        return new_metadata, 201

@external_lineage_ns.route('/metadata/<string:metadata_id>')
class ExternalMetadata(Resource):
    @external_lineage_ns.doc('get_external_metadata')
    @external_lineage_ns.marshal_with(external_metadata_model)
    def get(self, metadata_id):
        """Obtém um metadado externo específico"""
        return {
            'external_metadata_id': metadata_id,
            'name': 'customer_analytics_dashboard',
            'system_type': 'tableau',
            'entity_type': 'dashboard',
            'external_url': 'https://tableau.empresa.com/dashboards/customer_analytics',
            'description': 'Dashboard principal de analytics de clientes',
            'properties': {
                'workbook_name': 'Customer Analytics',
                'project': 'Sales & Marketing',
                'owner': 'analytics_team@empresa.com',
                'last_updated': '2025-07-01T10:00:00Z'
            },
            'unity_catalog_metastore_id': str(uuid.uuid4()),
            'unity_catalog_external_id': 'external_tableau_001',
            'is_active': True,
            'validation_status': 'validated',
            'last_validated_at': datetime.utcnow().isoformat(),
            'last_synced_at': datetime.utcnow().isoformat(),
            'sync_status': 'synced',
            'created_at': '2025-01-01T00:00:00Z',
            'updated_at': datetime.utcnow().isoformat()
        }
    
    @external_lineage_ns.doc('validate_external_metadata')
    def post(self, metadata_id):
        """Valida um metadado externo"""
        return {
            'metadata_id': metadata_id,
            'validation_status': 'validated',
            'validation_timestamp': datetime.utcnow().isoformat(),
            'validation_results': {
                'connectivity': 'success',
                'schema_validation': 'success',
                'data_availability': 'success'
            },
            'issues': [],
            'recommendations': [
                'Configurar sincronização automática',
                'Adicionar tags de classificação'
            ]
        }

@external_lineage_ns.route('/metadata/<string:metadata_id>/sync')
class ExternalMetadataSync(Resource):
    @external_lineage_ns.doc('sync_external_metadata')
    def post(self, metadata_id):
        """Sincroniza um metadado externo com Unity Catalog"""
        return {
            'metadata_id': metadata_id,
            'sync_status': 'completed',
            'sync_timestamp': datetime.utcnow().isoformat(),
            'unity_catalog_external_id': f'external_sync_{metadata_id}',
            'records_synced': 1,
            'changes_detected': [
                'Schema updated',
                'New columns added'
            ],
            'sync_duration_ms': 1250
        }

@external_lineage_ns.route('/column-mappings')
class ColumnMappingList(Resource):
    @external_lineage_ns.doc('list_column_mappings')
    @external_lineage_ns.marshal_list_with(column_mapping_model)
    @external_lineage_ns.param('external_metadata_id', 'Filtrar por metadado externo')
    @external_lineage_ns.param('compatibility_status', 'Filtrar por status de compatibilidade')
    def get(self):
        """Lista todos os mapeamentos de colunas"""
        return [{
            'mapping_id': str(uuid.uuid4()),
            'external_metadata_id': str(uuid.uuid4()),
            'source_column_name': 'total_customers',
            'source_column_type': 'integer',
            'source_column_description': 'Número total de clientes ativos',
            'target_column_name': 'customer_count',
            'transformation_type': 'direct',
            'transformation_description': 'Mapeamento direto sem transformação',
            'compatibility_status': 'compatible',
            'created_at': datetime.utcnow().isoformat()
        }]

@external_lineage_ns.route('/relationships')
class LineageRelationshipList(Resource):
    @external_lineage_ns.doc('list_lineage_relationships')
    @external_lineage_ns.marshal_list_with(lineage_relationship_model)
    @external_lineage_ns.param('external_metadata_id', 'Filtrar por metadado externo')
    @external_lineage_ns.param('relationship_direction', 'Filtrar por direção')
    def get(self):
        """Lista todos os relacionamentos de linhagem"""
        return [{
            'relationship_id': str(uuid.uuid4()),
            'external_metadata_id': str(uuid.uuid4()),
            'target_object_type': 'table',
            'target_object_id': 'main.ecommerce.customers',
            'target_object_name': 'customers',
            'relationship_direction': 'upstream',
            'relationship_description': 'Dashboard consome dados da tabela de clientes',
            'is_active': True,
            'validation_status': 'validated',
            'created_at': datetime.utcnow().isoformat()
        }]

@external_lineage_ns.route('/systems')
class ExternalSystemsList(Resource):
    @external_lineage_ns.doc('list_external_systems')
    def get(self):
        """Lista todos os sistemas externos conectados"""
        return {
            'total_systems': 5,
            'systems': [
                {
                    'system_type': 'tableau',
                    'total_objects': 15,
                    'active_objects': 12,
                    'last_sync': datetime.utcnow().isoformat(),
                    'sync_status': 'healthy'
                },
                {
                    'system_type': 'powerbi',
                    'total_objects': 8,
                    'active_objects': 7,
                    'last_sync': datetime.utcnow().isoformat(),
                    'sync_status': 'healthy'
                },
                {
                    'system_type': 'salesforce',
                    'total_objects': 25,
                    'active_objects': 23,
                    'last_sync': datetime.utcnow().isoformat(),
                    'sync_status': 'warning'
                }
            ]
        }

@external_lineage_ns.route('/impact-analysis/<string:object_id>')
class ImpactAnalysis(Resource):
    @external_lineage_ns.doc('impact_analysis')
    @external_lineage_ns.param('depth', 'Profundidade da análise', type=int, default=3)
    def get(self, object_id):
        """Análise de impacto para mudanças em objetos Unity Catalog"""
        depth = request.args.get('depth', 3, type=int)
        
        return {
            'object_id': object_id,
            'analysis_depth': depth,
            'impact_summary': {
                'total_affected_objects': 12,
                'external_systems_affected': 3,
                'critical_dashboards': 2,
                'risk_level': 'medium'
            },
            'affected_objects': [
                {
                    'object_id': 'tableau_dashboard_001',
                    'object_name': 'Customer Analytics Dashboard',
                    'system_type': 'tableau',
                    'impact_type': 'direct',
                    'risk_level': 'high',
                    'estimated_downtime': '15 minutes'
                },
                {
                    'object_id': 'powerbi_report_005',
                    'object_name': 'Sales Performance Report',
                    'system_type': 'powerbi',
                    'impact_type': 'indirect',
                    'risk_level': 'medium',
                    'estimated_downtime': '5 minutes'
                }
            ],
            'recommendations': [
                'Notificar equipes responsáveis pelos dashboards',
                'Agendar mudança para horário de baixo uso',
                'Preparar rollback plan'
            ],
            'analysis_timestamp': datetime.utcnow().isoformat()
        }

# Blueprint para compatibilidade
external_lineage_bp = Blueprint('external_lineage', __name__, url_prefix='/api/v2/external-lineage')

