"""
TBR GDP Core - Data Governance API
Configurações da Aplicação
"""

import os
from datetime import timedelta


class Config:
    """Configuração base da aplicação"""
    
    # Configurações básicas
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'tbr-gdp-core-secret-key-2025'
    
    # Configurações de banco de dados
    DATABASE_URL = os.environ.get('DATABASE_URL') or 'sqlite:///src/database/app.db'
    SQLALCHEMY_DATABASE_URI = DATABASE_URL
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {
        'pool_pre_ping': True,
        'pool_recycle': 300,
    }
    
    # Configurações de cache (Redis)
    REDIS_URL = os.environ.get('REDIS_URL') or 'redis://localhost:6379/0'
    CACHE_TYPE = 'redis'
    CACHE_REDIS_URL = REDIS_URL
    CACHE_DEFAULT_TIMEOUT = 300
    
    # Configurações JWT
    JWT_SECRET_KEY = os.environ.get('JWT_SECRET_KEY') or SECRET_KEY
    JWT_ACCESS_TOKEN_EXPIRES = timedelta(hours=24)
    JWT_REFRESH_TOKEN_EXPIRES = timedelta(days=30)
    
    # Configurações da API
    API_TITLE = 'TBR GDP Core - Data Governance API'
    API_VERSION = '3.0.0'
    OPENAPI_VERSION = '3.0.2'
    OPENAPI_URL_PREFIX = '/'
    OPENAPI_SWAGGER_UI_PATH = '/docs/'
    OPENAPI_SWAGGER_UI_URL = 'https://cdn.jsdelivr.net/npm/swagger-ui-dist/'
    
    # Configurações de paginação
    DEFAULT_PAGE_SIZE = 20
    MAX_PAGE_SIZE = 100
    
    # Configurações de upload
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB
    UPLOAD_FOLDER = 'uploads'
    ALLOWED_EXTENSIONS = {'json', 'csv', 'xlsx', 'sql'}
    
    # Configurações de logging
    LOG_LEVEL = os.environ.get('LOG_LEVEL', 'INFO')
    LOG_FORMAT = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    
    # Configurações de segurança
    CORS_ORIGINS = os.environ.get('CORS_ORIGINS', '*').split(',')
    RATE_LIMIT_STORAGE_URL = REDIS_URL
    
    # Configurações de monitoramento
    PROMETHEUS_METRICS = True
    HEALTH_CHECK_INTERVAL = 30  # segundos
    
    # Configurações de integração
    UNITY_CATALOG_URL = os.environ.get('UNITY_CATALOG_URL')
    UNITY_CATALOG_TOKEN = os.environ.get('UNITY_CATALOG_TOKEN')
    
    INFORMATICA_AXON_URL = os.environ.get('INFORMATICA_AXON_URL')
    INFORMATICA_AXON_TOKEN = os.environ.get('INFORMATICA_AXON_TOKEN')
    
    # Configurações de email
    MAIL_SERVER = os.environ.get('MAIL_SERVER')
    MAIL_PORT = int(os.environ.get('MAIL_PORT') or 587)
    MAIL_USE_TLS = os.environ.get('MAIL_USE_TLS', 'true').lower() in ['true', 'on', '1']
    MAIL_USERNAME = os.environ.get('MAIL_USERNAME')
    MAIL_PASSWORD = os.environ.get('MAIL_PASSWORD')
    
    # Configurações de ML
    ML_MODEL_PATH = os.environ.get('ML_MODEL_PATH', 'models/')
    ML_BATCH_SIZE = int(os.environ.get('ML_BATCH_SIZE', '1000'))
    ML_ANOMALY_THRESHOLD = float(os.environ.get('ML_ANOMALY_THRESHOLD', '0.8'))


class DevelopmentConfig(Config):
    """Configuração para desenvolvimento"""
    DEBUG = True
    TESTING = False
    
    # Usar SQLite para desenvolvimento
    SQLALCHEMY_DATABASE_URI = 'sqlite:///src/database/app_dev.db'
    
    # Configurações mais permissivas para desenvolvimento
    CORS_ORIGINS = ['*']
    
    # Logging mais verboso
    LOG_LEVEL = 'DEBUG'


class TestingConfig(Config):
    """Configuração para testes"""
    TESTING = True
    DEBUG = True
    
    # Usar banco em memória para testes
    SQLALCHEMY_DATABASE_URI = 'sqlite:///:memory:'
    
    # Desabilitar CSRF para testes
    WTF_CSRF_ENABLED = False
    
    # Cache em memória para testes
    CACHE_TYPE = 'simple'


class ProductionConfig(Config):
    """Configuração para produção"""
    DEBUG = False
    TESTING = False
    
    # Configurações de segurança mais rigorosas
    SESSION_COOKIE_SECURE = True
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Lax'
    
    # Configurações de performance
    SQLALCHEMY_ENGINE_OPTIONS = {
        'pool_size': 20,
        'pool_recycle': 3600,
        'pool_pre_ping': True,
        'max_overflow': 30
    }
    
    # Rate limiting mais rigoroso
    RATELIMIT_DEFAULT = "1000 per hour"


# Mapeamento de configurações por ambiente
config = {
    'development': DevelopmentConfig,
    'testing': TestingConfig,
    'production': ProductionConfig,
    'default': DevelopmentConfig
}

