"""
TBR GDP Core - Data Governance API
Sistema de Multi-Tenancy Geográfico

Este módulo implementa um sistema robusto de multi-tenancy que permite:
- Layouts customizáveis por país/região
- Configurações específicas por localização
- Compliance regional (LGPD, GDPR, CCPA, etc.)
- Formatação de dados por localização
- Integração entre diferentes regiões
"""

from typing import Dict, List, Optional, Any, Union
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
import json
import re
from abc import ABC, abstractmethod


class RegionType(Enum):
    """Tipos de região"""
    COUNTRY = "country"
    STATE = "state"
    PROVINCE = "province"
    REGION = "region"
    CUSTOM = "custom"


class ComplianceFramework(Enum):
    """Frameworks de compliance"""
    LGPD = "lgpd"          # Brasil
    GDPR = "gdpr"          # União Europeia
    CCPA = "ccpa"          # Califórnia, EUA
    PIPEDA = "pipeda"      # Canadá
    PDPA = "pdpa"          # Singapura, Tailândia
    DPA = "dpa"            # Reino Unido
    CUSTOM = "custom"


@dataclass
class LocalizationConfig:
    """Configuração de localização"""
    country_code: str  # ISO 3166-1 alpha-2
    region_code: Optional[str] = None
    language: str = "en"
    timezone: str = "UTC"
    currency: str = "USD"
    date_format: str = "%Y-%m-%d"
    time_format: str = "%H:%M:%S"
    number_format: Dict[str, str] = field(default_factory=lambda: {
        "decimal_separator": ".",
        "thousands_separator": ",",
        "currency_symbol": "$"
    })
    compliance_frameworks: List[ComplianceFramework] = field(default_factory=list)
    data_residency_requirements: Dict[str, Any] = field(default_factory=dict)
    
    def __post_init__(self):
        """Validação pós-inicialização"""
        if len(self.country_code) != 2:
            raise ValueError("country_code deve ter 2 caracteres (ISO 3166-1)")


@dataclass
class TenantConfig:
    """Configuração de tenant"""
    tenant_id: str
    tenant_name: str
    localization: LocalizationConfig
    custom_fields: Dict[str, Any] = field(default_factory=dict)
    layout_overrides: Dict[str, Any] = field(default_factory=dict)
    validation_rules: Dict[str, Any] = field(default_factory=dict)
    business_rules: Dict[str, Any] = field(default_factory=dict)
    integration_configs: Dict[str, Any] = field(default_factory=dict)
    is_active: bool = True
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)


class GeoTenancyManager:
    """Gerenciador de multi-tenancy geográfico"""
    
    def __init__(self):
        self.tenants: Dict[str, TenantConfig] = {}
        self.country_mappings: Dict[str, List[str]] = {}
        self.default_configs: Dict[str, LocalizationConfig] = {}
        
        # Inicializar configurações padrão
        self._initialize_default_configs()
    
    def _initialize_default_configs(self):
        """Inicializa configurações padrão por país"""
        
        # Brasil - LGPD
        self.default_configs["BR"] = LocalizationConfig(
            country_code="BR",
            language="pt-BR",
            timezone="America/Sao_Paulo",
            currency="BRL",
            date_format="%d/%m/%Y",
            time_format="%H:%M:%S",
            number_format={
                "decimal_separator": ",",
                "thousands_separator": ".",
                "currency_symbol": "R$"
            },
            compliance_frameworks=[ComplianceFramework.LGPD],
            data_residency_requirements={
                "personal_data_location": "BR",
                "backup_location": "BR",
                "processing_location": "BR",
                "cross_border_transfer": "restricted"
            }
        )
        
        # Estados Unidos - CCPA
        self.default_configs["US"] = LocalizationConfig(
            country_code="US",
            language="en-US",
            timezone="America/New_York",
            currency="USD",
            date_format="%m/%d/%Y",
            time_format="%I:%M:%S %p",
            number_format={
                "decimal_separator": ".",
                "thousands_separator": ",",
                "currency_symbol": "$"
            },
            compliance_frameworks=[ComplianceFramework.CCPA],
            data_residency_requirements={
                "personal_data_location": "US",
                "backup_location": "US",
                "processing_location": "US",
                "cross_border_transfer": "allowed_with_consent"
            }
        )
        
        # União Europeia - GDPR
        self.default_configs["EU"] = LocalizationConfig(
            country_code="EU",
            language="en-EU",
            timezone="Europe/Brussels",
            currency="EUR",
            date_format="%d.%m.%Y",
            time_format="%H:%M:%S",
            number_format={
                "decimal_separator": ",",
                "thousands_separator": ".",
                "currency_symbol": "€"
            },
            compliance_frameworks=[ComplianceFramework.GDPR],
            data_residency_requirements={
                "personal_data_location": "EU",
                "backup_location": "EU",
                "processing_location": "EU",
                "cross_border_transfer": "restricted"
            }
        )
        
        # Reino Unido - DPA
        self.default_configs["GB"] = LocalizationConfig(
            country_code="GB",
            language="en-GB",
            timezone="Europe/London",
            currency="GBP",
            date_format="%d/%m/%Y",
            time_format="%H:%M:%S",
            number_format={
                "decimal_separator": ".",
                "thousands_separator": ",",
                "currency_symbol": "£"
            },
            compliance_frameworks=[ComplianceFramework.DPA],
            data_residency_requirements={
                "personal_data_location": "GB",
                "backup_location": "GB",
                "processing_location": "GB",
                "cross_border_transfer": "allowed_with_adequacy"
            }
        )
        
        # Canadá - PIPEDA
        self.default_configs["CA"] = LocalizationConfig(
            country_code="CA",
            language="en-CA",
            timezone="America/Toronto",
            currency="CAD",
            date_format="%Y-%m-%d",
            time_format="%H:%M:%S",
            number_format={
                "decimal_separator": ".",
                "thousands_separator": ",",
                "currency_symbol": "C$"
            },
            compliance_frameworks=[ComplianceFramework.PIPEDA],
            data_residency_requirements={
                "personal_data_location": "CA",
                "backup_location": "CA",
                "processing_location": "CA",
                "cross_border_transfer": "allowed_with_consent"
            }
        )
    
    def create_tenant(self, tenant_id: str, tenant_name: str, 
                     country_code: str, **kwargs) -> TenantConfig:
        """Cria um novo tenant"""
        
        # Usar configuração padrão do país como base
        base_config = self.default_configs.get(country_code)
        if not base_config:
            # Usar configuração padrão genérica
            base_config = LocalizationConfig(
                country_code=country_code,
                language="en",
                timezone="UTC",
                currency="USD"
            )
        
        # Aplicar overrides se fornecidos
        localization_overrides = kwargs.get("localization_overrides", {})
        localization = LocalizationConfig(
            country_code=base_config.country_code,
            region_code=localization_overrides.get("region_code", base_config.region_code),
            language=localization_overrides.get("language", base_config.language),
            timezone=localization_overrides.get("timezone", base_config.timezone),
            currency=localization_overrides.get("currency", base_config.currency),
            date_format=localization_overrides.get("date_format", base_config.date_format),
            time_format=localization_overrides.get("time_format", base_config.time_format),
            number_format=localization_overrides.get("number_format", base_config.number_format),
            compliance_frameworks=localization_overrides.get("compliance_frameworks", base_config.compliance_frameworks),
            data_residency_requirements=localization_overrides.get("data_residency_requirements", base_config.data_residency_requirements)
        )
        
        tenant_config = TenantConfig(
            tenant_id=tenant_id,
            tenant_name=tenant_name,
            localization=localization,
            custom_fields=kwargs.get("custom_fields", {}),
            layout_overrides=kwargs.get("layout_overrides", {}),
            validation_rules=kwargs.get("validation_rules", {}),
            business_rules=kwargs.get("business_rules", {}),
            integration_configs=kwargs.get("integration_configs", {})
        )
        
        self.tenants[tenant_id] = tenant_config
        
        # Atualizar mapeamento por país
        if country_code not in self.country_mappings:
            self.country_mappings[country_code] = []
        self.country_mappings[country_code].append(tenant_id)
        
        return tenant_config
    
    def get_tenant(self, tenant_id: str) -> Optional[TenantConfig]:
        """Obtém configuração de um tenant"""
        return self.tenants.get(tenant_id)
    
    def get_tenants_by_country(self, country_code: str) -> List[TenantConfig]:
        """Obtém todos os tenants de um país"""
        tenant_ids = self.country_mappings.get(country_code, [])
        return [self.tenants[tid] for tid in tenant_ids if tid in self.tenants]
    
    def resolve_tenant_from_request(self, request_data: Dict[str, Any]) -> Optional[str]:
        """Resolve tenant baseado nos dados da requisição"""
        
        # Prioridade 1: Tenant ID explícito no header
        tenant_id = request_data.get("headers", {}).get("X-Tenant-ID")
        if tenant_id and tenant_id in self.tenants:
            return tenant_id
        
        # Prioridade 2: País no header
        country_code = request_data.get("headers", {}).get("X-Country-Code")
        if country_code:
            tenants = self.get_tenants_by_country(country_code)
            if tenants:
                return tenants[0].tenant_id  # Retorna o primeiro tenant do país
        
        # Prioridade 3: Detectar pelo IP (simulado)
        ip_address = request_data.get("ip_address")
        if ip_address:
            country_code = self._detect_country_from_ip(ip_address)
            if country_code:
                tenants = self.get_tenants_by_country(country_code)
                if tenants:
                    return tenants[0].tenant_id
        
        # Prioridade 4: Tenant padrão
        return self._get_default_tenant()
    
    def _detect_country_from_ip(self, ip_address: str) -> Optional[str]:
        """Detecta país pelo IP (implementação simulada)"""
        # Em implementação real, usaria serviço de geolocalização
        ip_country_map = {
            "192.168.": "BR",  # IPs locais brasileiros (simulado)
            "10.0.": "US",     # IPs locais americanos (simulado)
            "172.16.": "EU"    # IPs locais europeus (simulado)
        }
        
        for ip_prefix, country in ip_country_map.items():
            if ip_address.startswith(ip_prefix):
                return country
        
        return "US"  # Padrão
    
    def _get_default_tenant(self) -> Optional[str]:
        """Retorna tenant padrão"""
        if self.tenants:
            return list(self.tenants.keys())[0]
        return None
    
    def apply_localization(self, data: Dict[str, Any], tenant_id: str) -> Dict[str, Any]:
        """Aplica localização aos dados"""
        tenant = self.get_tenant(tenant_id)
        if not tenant:
            return data
        
        localized_data = data.copy()
        
        # Aplicar formatação de datas
        localized_data = self._format_dates(localized_data, tenant.localization)
        
        # Aplicar formatação de números
        localized_data = self._format_numbers(localized_data, tenant.localization)
        
        # Aplicar campos customizados
        if tenant.custom_fields:
            localized_data.update(tenant.custom_fields)
        
        # Aplicar overrides de layout
        if tenant.layout_overrides:
            localized_data["_layout"] = tenant.layout_overrides
        
        return localized_data
    
    def _format_dates(self, data: Dict[str, Any], localization: LocalizationConfig) -> Dict[str, Any]:
        """Formata datas conforme localização"""
        # Implementação simplificada
        # Em implementação real, percorreria recursivamente o dicionário
        formatted_data = data.copy()
        
        for key, value in data.items():
            if isinstance(value, str) and self._is_iso_date(value):
                try:
                    dt = datetime.fromisoformat(value.replace('Z', '+00:00'))
                    formatted_data[key] = dt.strftime(localization.date_format)
                except:
                    pass  # Manter valor original se não conseguir formatar
        
        return formatted_data
    
    def _format_numbers(self, data: Dict[str, Any], localization: LocalizationConfig) -> Dict[str, Any]:
        """Formata números conforme localização"""
        # Implementação simplificada
        formatted_data = data.copy()
        
        for key, value in data.items():
            if isinstance(value, (int, float)) and "amount" in key.lower():
                # Formatar valores monetários
                formatted_value = f"{localization.number_format['currency_symbol']}{value:,.2f}"
                formatted_value = formatted_value.replace(",", "TEMP").replace(".", localization.number_format['decimal_separator']).replace("TEMP", localization.number_format['thousands_separator'])
                formatted_data[f"{key}_formatted"] = formatted_value
        
        return formatted_data
    
    def _is_iso_date(self, value: str) -> bool:
        """Verifica se string é uma data ISO"""
        iso_date_pattern = r'^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}'
        return bool(re.match(iso_date_pattern, value))
    
    def validate_compliance(self, data: Dict[str, Any], tenant_id: str) -> Dict[str, Any]:
        """Valida compliance baseado no tenant"""
        tenant = self.get_tenant(tenant_id)
        if not tenant:
            return {"valid": True, "warnings": []}
        
        warnings = []
        errors = []
        
        # Verificar frameworks de compliance
        for framework in tenant.localization.compliance_frameworks:
            if framework == ComplianceFramework.LGPD:
                warnings.extend(self._validate_lgpd(data))
            elif framework == ComplianceFramework.GDPR:
                warnings.extend(self._validate_gdpr(data))
            elif framework == ComplianceFramework.CCPA:
                warnings.extend(self._validate_ccpa(data))
        
        # Verificar residência de dados
        residency_warnings = self._validate_data_residency(data, tenant)
        warnings.extend(residency_warnings)
        
        return {
            "valid": len(errors) == 0,
            "warnings": warnings,
            "errors": errors,
            "compliance_frameworks": [f.value for f in tenant.localization.compliance_frameworks]
        }
    
    def _validate_lgpd(self, data: Dict[str, Any]) -> List[str]:
        """Validação específica LGPD"""
        warnings = []
        
        # Verificar se há dados pessoais sem consentimento
        if self._contains_personal_data(data):
            if not data.get("consent_given"):
                warnings.append("Dados pessoais detectados sem consentimento explícito (LGPD)")
        
        return warnings
    
    def _validate_gdpr(self, data: Dict[str, Any]) -> List[str]:
        """Validação específica GDPR"""
        warnings = []
        
        # Verificar base legal para processamento
        if self._contains_personal_data(data):
            if not data.get("legal_basis"):
                warnings.append("Dados pessoais sem base legal definida (GDPR)")
        
        return warnings
    
    def _validate_ccpa(self, data: Dict[str, Any]) -> List[str]:
        """Validação específica CCPA"""
        warnings = []
        
        # Verificar direitos do consumidor
        if self._contains_personal_data(data):
            if not data.get("consumer_rights_notice"):
                warnings.append("Dados pessoais sem aviso de direitos do consumidor (CCPA)")
        
        return warnings
    
    def _validate_data_residency(self, data: Dict[str, Any], tenant: TenantConfig) -> List[str]:
        """Valida requisitos de residência de dados"""
        warnings = []
        
        residency_req = tenant.localization.data_residency_requirements
        
        if residency_req.get("cross_border_transfer") == "restricted":
            # Verificar se há transferência internacional
            if data.get("processing_location") != tenant.localization.country_code:
                warnings.append(f"Transferência internacional restrita para {tenant.localization.country_code}")
        
        return warnings
    
    def _contains_personal_data(self, data: Dict[str, Any]) -> bool:
        """Verifica se dados contêm informações pessoais"""
        personal_data_indicators = ["email", "phone", "cpf", "ssn", "passport", "address"]
        
        for key in data.keys():
            if any(indicator in key.lower() for indicator in personal_data_indicators):
                return True
        
        return False
    
    def get_tenant_summary(self) -> Dict[str, Any]:
        """Retorna resumo de todos os tenants"""
        return {
            "total_tenants": len(self.tenants),
            "countries": list(self.country_mappings.keys()),
            "compliance_frameworks": list(set([
                framework.value 
                for tenant in self.tenants.values() 
                for framework in tenant.localization.compliance_frameworks
            ])),
            "tenants": {
                tenant_id: {
                    "name": config.tenant_name,
                    "country": config.localization.country_code,
                    "language": config.localization.language,
                    "compliance": [f.value for f in config.localization.compliance_frameworks],
                    "is_active": config.is_active
                }
                for tenant_id, config in self.tenants.items()
            }
        }
    
    def sync_tenant_data(self, source_tenant_id: str, target_tenant_id: str, 
                        data_types: List[str]) -> Dict[str, Any]:
        """Sincroniza dados entre tenants"""
        source_tenant = self.get_tenant(source_tenant_id)
        target_tenant = self.get_tenant(target_tenant_id)
        
        if not source_tenant or not target_tenant:
            return {"success": False, "error": "Tenant not found"}
        
        # Verificar compatibilidade de compliance
        source_frameworks = set(source_tenant.localization.compliance_frameworks)
        target_frameworks = set(target_tenant.localization.compliance_frameworks)
        
        if not source_frameworks.intersection(target_frameworks):
            return {
                "success": False, 
                "error": "Incompatible compliance frameworks",
                "source_frameworks": [f.value for f in source_frameworks],
                "target_frameworks": [f.value for f in target_frameworks]
            }
        
        # Simular sincronização
        sync_result = {
            "success": True,
            "synced_data_types": data_types,
            "source_tenant": source_tenant_id,
            "target_tenant": target_tenant_id,
            "sync_timestamp": datetime.utcnow().isoformat(),
            "records_synced": len(data_types) * 100  # Simulado
        }
        
        return sync_result


# Instância global do gerenciador de tenancy
geo_tenancy_manager = GeoTenancyManager()

# Criar alguns tenants padrão
geo_tenancy_manager.create_tenant("br-main", "Brasil Principal", "BR")
geo_tenancy_manager.create_tenant("us-main", "Estados Unidos Principal", "US")
geo_tenancy_manager.create_tenant("eu-main", "União Europeia Principal", "EU")
geo_tenancy_manager.create_tenant("gb-main", "Reino Unido Principal", "GB")
geo_tenancy_manager.create_tenant("ca-main", "Canadá Principal", "CA")

