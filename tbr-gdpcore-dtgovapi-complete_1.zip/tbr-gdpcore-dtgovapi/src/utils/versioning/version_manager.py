"""
TBR GDP Core - Data Governance API
Sistema de Versionamento Avançado

Este módulo implementa um sistema robusto de versionamento que permite:
- Múltiplas versões ativas da API simultaneamente
- Versionamento de contratos de dados
- Compatibilidade entre versões
- Migração automática de dados
- Deprecação controlada
"""

from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
import semver
import json
from abc import ABC, abstractmethod


class VersionStatus(Enum):
    """Status das versões"""
    DEVELOPMENT = "development"
    BETA = "beta"
    STABLE = "stable"
    DEPRECATED = "deprecated"
    SUNSET = "sunset"


class CompatibilityMode(Enum):
    """Modos de compatibilidade entre versões"""
    BACKWARD = "backward"  # Nova versão é compatível com versões anteriores
    FORWARD = "forward"    # Versão anterior é compatível com novas versões
    FULL = "full"         # Compatibilidade total (backward + forward)
    BREAKING = "breaking"  # Mudanças incompatíveis


@dataclass
class VersionInfo:
    """Informações de uma versão"""
    version: str
    status: VersionStatus
    release_date: datetime
    deprecation_date: Optional[datetime] = None
    sunset_date: Optional[datetime] = None
    compatibility_mode: CompatibilityMode = CompatibilityMode.BACKWARD
    breaking_changes: List[str] = field(default_factory=list)
    migration_guide: Optional[str] = None
    supported_features: List[str] = field(default_factory=list)
    deprecated_features: List[str] = field(default_factory=list)
    api_endpoints: Dict[str, Any] = field(default_factory=dict)
    schema_changes: Dict[str, Any] = field(default_factory=dict)
    
    def is_active(self) -> bool:
        """Verifica se a versão está ativa"""
        return self.status in [VersionStatus.BETA, VersionStatus.STABLE]
    
    def is_deprecated(self) -> bool:
        """Verifica se a versão está depreciada"""
        return self.status == VersionStatus.DEPRECATED
    
    def days_until_sunset(self) -> Optional[int]:
        """Retorna quantos dias até o sunset"""
        if not self.sunset_date:
            return None
        delta = self.sunset_date - datetime.utcnow()
        return max(0, delta.days)


class VersionManager:
    """Gerenciador de versões da API"""
    
    def __init__(self):
        self.versions: Dict[str, VersionInfo] = {}
        self.active_versions: List[str] = []
        self.default_version: Optional[str] = None
        self.version_mappings: Dict[str, Dict[str, str]] = {}
        
        # Inicializar versões padrão
        self._initialize_default_versions()
    
    def _initialize_default_versions(self):
        """Inicializa versões padrão do sistema"""
        # Versão 1.0 - Estável
        v1_info = VersionInfo(
            version="1.0.0",
            status=VersionStatus.STABLE,
            release_date=datetime(2025, 1, 1),
            supported_features=[
                "contracts_basic", "quality_rules", "lineage_basic",
                "monitoring_basic", "analytics_basic"
            ],
            api_endpoints={
                "contracts": "/api/v1/contracts",
                "quality": "/api/v1/quality",
                "lineage": "/api/v1/lineage",
                "monitoring": "/api/v1/monitoring",
                "analytics": "/api/v1/analytics"
            }
        )
        
        # Versão 2.0 - Estável com novas funcionalidades
        v2_info = VersionInfo(
            version="2.0.0",
            status=VersionStatus.STABLE,
            release_date=datetime(2025, 6, 1),
            compatibility_mode=CompatibilityMode.BACKWARD,
            supported_features=[
                "contracts_advanced", "quality_ml", "lineage_external",
                "monitoring_advanced", "analytics_executive", "privacy_compliance",
                "multi_tenancy", "governance_policies"
            ],
            api_endpoints={
                "contracts": "/api/v2/contracts",
                "quality": "/api/v2/quality",
                "lineage": "/api/v2/lineage",
                "monitoring": "/api/v2/monitoring",
                "analytics": "/api/v2/analytics",
                "privacy": "/api/v2/privacy",
                "governance": "/api/v2/governance",
                "compliance": "/api/v2/compliance"
            },
            schema_changes={
                "contracts": {
                    "added_fields": ["multi_region_config", "compliance_tags"],
                    "deprecated_fields": [],
                    "breaking_changes": []
                }
            }
        )
        
        # Versão 3.0 - Beta com funcionalidades experimentais
        v3_info = VersionInfo(
            version="3.0.0",
            status=VersionStatus.BETA,
            release_date=datetime(2025, 7, 1),
            compatibility_mode=CompatibilityMode.BREAKING,
            breaking_changes=[
                "Reestruturação do schema de contratos",
                "Nova API de autenticação",
                "Mudança no formato de resposta de qualidade"
            ],
            supported_features=[
                "contracts_v3", "quality_ai", "lineage_realtime",
                "monitoring_predictive", "analytics_ai", "privacy_automated",
                "governance_intelligent", "compliance_automated", "audit_advanced",
                "reporting_dynamic", "metadata_intelligent", "anomalies_ai"
            ],
            api_endpoints={
                "contracts": "/api/v3/contracts",
                "quality": "/api/v3/quality",
                "lineage": "/api/v3/lineage",
                "monitoring": "/api/v3/monitoring",
                "analytics": "/api/v3/analytics",
                "privacy": "/api/v3/privacy",
                "governance": "/api/v3/governance",
                "compliance": "/api/v3/compliance",
                "audit": "/api/v3/audit",
                "reporting": "/api/v3/reporting",
                "metadata": "/api/v3/metadata",
                "anomalies": "/api/v3/anomalies"
            },
            migration_guide="Consulte /docs/migration/v2-to-v3.md para guia detalhado"
        )
        
        # Registrar versões
        self.register_version(v1_info)
        self.register_version(v2_info)
        self.register_version(v3_info)
        
        # Definir versões ativas
        self.active_versions = ["1.0.0", "2.0.0", "3.0.0"]
        self.default_version = "2.0.0"
    
    def register_version(self, version_info: VersionInfo):
        """Registra uma nova versão"""
        self.versions[version_info.version] = version_info
    
    def get_version_info(self, version: str) -> Optional[VersionInfo]:
        """Obtém informações de uma versão"""
        return self.versions.get(version)
    
    def get_active_versions(self) -> List[VersionInfo]:
        """Retorna todas as versões ativas"""
        return [
            self.versions[v] for v in self.active_versions 
            if v in self.versions and self.versions[v].is_active()
        ]
    
    def get_latest_version(self) -> Optional[VersionInfo]:
        """Retorna a versão mais recente"""
        if not self.versions:
            return None
        
        latest_version = max(
            self.versions.keys(),
            key=lambda v: semver.VersionInfo.parse(v)
        )
        return self.versions[latest_version]
    
    def get_default_version(self) -> Optional[VersionInfo]:
        """Retorna a versão padrão"""
        if self.default_version:
            return self.versions.get(self.default_version)
        return None
    
    def is_version_supported(self, version: str) -> bool:
        """Verifica se uma versão é suportada"""
        return version in self.active_versions
    
    def deprecate_version(self, version: str, sunset_date: datetime, reason: str = ""):
        """Deprecia uma versão"""
        if version in self.versions:
            self.versions[version].status = VersionStatus.DEPRECATED
            self.versions[version].deprecation_date = datetime.utcnow()
            self.versions[version].sunset_date = sunset_date
    
    def get_compatible_versions(self, version: str) -> List[str]:
        """Retorna versões compatíveis com a versão especificada"""
        if version not in self.versions:
            return []
        
        version_info = self.versions[version]
        compatible = []
        
        for v, info in self.versions.items():
            if v == version:
                continue
                
            # Verificar compatibilidade baseada no modo
            if version_info.compatibility_mode == CompatibilityMode.BACKWARD:
                if semver.compare(v, version) <= 0:
                    compatible.append(v)
            elif version_info.compatibility_mode == CompatibilityMode.FORWARD:
                if semver.compare(v, version) >= 0:
                    compatible.append(v)
            elif version_info.compatibility_mode == CompatibilityMode.FULL:
                compatible.append(v)
        
        return compatible
    
    def get_migration_path(self, from_version: str, to_version: str) -> List[str]:
        """Retorna o caminho de migração entre versões"""
        if from_version not in self.versions or to_version not in self.versions:
            return []
        
        # Para simplificar, retorna migração direta
        # Em implementação real, poderia calcular caminho otimizado
        return [from_version, to_version]
    
    def validate_version_request(self, requested_version: Optional[str]) -> Tuple[str, bool]:
        """
        Valida e resolve a versão solicitada
        
        Returns:
            Tuple[str, bool]: (versão_resolvida, é_válida)
        """
        if not requested_version:
            # Usar versão padrão
            return self.default_version or "2.0.0", True
        
        # Verificar se versão existe e está ativa
        if requested_version in self.active_versions:
            return requested_version, True
        
        # Verificar se é uma versão depreciada mas ainda suportada
        if requested_version in self.versions:
            version_info = self.versions[requested_version]
            if version_info.is_deprecated():
                # Permitir uso mas com warning
                return requested_version, True
        
        # Versão não suportada
        return self.default_version or "2.0.0", False
    
    def get_version_features(self, version: str) -> List[str]:
        """Retorna funcionalidades suportadas por uma versão"""
        if version not in self.versions:
            return []
        return self.versions[version].supported_features
    
    def is_feature_supported(self, version: str, feature: str) -> bool:
        """Verifica se uma funcionalidade é suportada em uma versão"""
        features = self.get_version_features(version)
        return feature in features
    
    def get_version_endpoints(self, version: str) -> Dict[str, str]:
        """Retorna endpoints disponíveis para uma versão"""
        if version not in self.versions:
            return {}
        return self.versions[version].api_endpoints
    
    def get_deprecation_warnings(self, version: str) -> List[str]:
        """Retorna avisos de depreciação para uma versão"""
        warnings = []
        
        if version not in self.versions:
            return warnings
        
        version_info = self.versions[version]
        
        if version_info.is_deprecated():
            days_left = version_info.days_until_sunset()
            if days_left is not None:
                warnings.append(
                    f"Versão {version} está depreciada e será removida em {days_left} dias"
                )
            else:
                warnings.append(f"Versão {version} está depreciada")
        
        if version_info.deprecated_features:
            warnings.append(
                f"Funcionalidades depreciadas: {', '.join(version_info.deprecated_features)}"
            )
        
        return warnings
    
    def get_version_summary(self) -> Dict[str, Any]:
        """Retorna resumo de todas as versões"""
        return {
            "total_versions": len(self.versions),
            "active_versions": len(self.active_versions),
            "default_version": self.default_version,
            "latest_version": self.get_latest_version().version if self.get_latest_version() else None,
            "versions": {
                version: {
                    "status": info.status.value,
                    "release_date": info.release_date.isoformat(),
                    "is_active": info.is_active(),
                    "supported_features_count": len(info.supported_features),
                    "endpoints_count": len(info.api_endpoints)
                }
                for version, info in self.versions.items()
            }
        }


class ContractVersionManager:
    """Gerenciador de versões de contratos de dados"""
    
    def __init__(self):
        self.contract_versions: Dict[str, Dict[str, Any]] = {}
    
    def create_contract_version(self, contract_id: str, version: str, 
                              schema_definition: Dict[str, Any],
                              compatibility_mode: CompatibilityMode = CompatibilityMode.BACKWARD,
                              changelog: str = "") -> Dict[str, Any]:
        """Cria uma nova versão de contrato"""
        if contract_id not in self.contract_versions:
            self.contract_versions[contract_id] = {}
        
        version_data = {
            "version": version,
            "schema_definition": schema_definition,
            "compatibility_mode": compatibility_mode.value,
            "changelog": changelog,
            "created_at": datetime.utcnow().isoformat(),
            "is_active": False,
            "activation_date": None,
            "deprecation_date": None,
            "breaking_changes": [],
            "migration_guide": ""
        }
        
        self.contract_versions[contract_id][version] = version_data
        return version_data
    
    def activate_contract_version(self, contract_id: str, version: str) -> bool:
        """Ativa uma versão de contrato"""
        if (contract_id in self.contract_versions and 
            version in self.contract_versions[contract_id]):
            
            self.contract_versions[contract_id][version]["is_active"] = True
            self.contract_versions[contract_id][version]["activation_date"] = datetime.utcnow().isoformat()
            return True
        return False
    
    def get_active_contract_versions(self, contract_id: str) -> List[Dict[str, Any]]:
        """Retorna versões ativas de um contrato"""
        if contract_id not in self.contract_versions:
            return []
        
        return [
            version_data for version_data in self.contract_versions[contract_id].values()
            if version_data["is_active"]
        ]
    
    def get_contract_version(self, contract_id: str, version: str) -> Optional[Dict[str, Any]]:
        """Obtém uma versão específica de contrato"""
        if (contract_id in self.contract_versions and 
            version in self.contract_versions[contract_id]):
            return self.contract_versions[contract_id][version]
        return None
    
    def validate_schema_compatibility(self, contract_id: str, 
                                    old_version: str, new_version: str) -> Dict[str, Any]:
        """Valida compatibilidade entre versões de schema"""
        old_schema = self.get_contract_version(contract_id, old_version)
        new_schema = self.get_contract_version(contract_id, new_version)
        
        if not old_schema or not new_schema:
            return {"compatible": False, "reason": "Version not found"}
        
        # Análise simplificada de compatibilidade
        old_fields = set(old_schema["schema_definition"].get("properties", {}).keys())
        new_fields = set(new_schema["schema_definition"].get("properties", {}).keys())
        
        added_fields = new_fields - old_fields
        removed_fields = old_fields - new_fields
        
        compatibility_mode = CompatibilityMode(new_schema["compatibility_mode"])
        
        if compatibility_mode == CompatibilityMode.BACKWARD:
            # Não pode remover campos obrigatórios
            compatible = len(removed_fields) == 0
        elif compatibility_mode == CompatibilityMode.FORWARD:
            # Não pode adicionar campos obrigatórios
            compatible = True  # Simplificado
        elif compatibility_mode == CompatibilityMode.FULL:
            # Não pode adicionar nem remover campos obrigatórios
            compatible = len(added_fields) == 0 and len(removed_fields) == 0
        else:  # BREAKING
            compatible = False
        
        return {
            "compatible": compatible,
            "added_fields": list(added_fields),
            "removed_fields": list(removed_fields),
            "compatibility_mode": compatibility_mode.value,
            "breaking_changes": new_schema.get("breaking_changes", [])
        }


# Instância global do gerenciador de versões
version_manager = VersionManager()
contract_version_manager = ContractVersionManager()

