-- TBR GDP Core - Data Governance API
-- Script de Criação do Banco de Dados
-- Baseado no modelo_completo_v2.1.dbml

-- Criar extensões necessárias
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";
CREATE EXTENSION IF NOT EXISTS "btree_gin";

-- Criar schema principal
CREATE SCHEMA IF NOT EXISTS governance;
SET search_path TO governance, public;

-- ============================================================================
-- UNITY CATALOG EXTERNAL LINEAGE - Integração com Unity Catalog
-- ============================================================================

CREATE TABLE external_metadata (
    external_metadata_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    system_type TEXT NOT NULL CHECK (system_type IN ('tableau', 'powerbi', 'salesforce', 'mysql', 'custom')),
    entity_type TEXT NOT NULL CHECK (entity_type IN ('table', 'dashboard', 'report', 'dataset')),
    external_url TEXT,
    description TEXT,
    properties JSONB,
    unity_catalog_metastore_id UUID,
    unity_catalog_external_id TEXT,
    is_active BOOLEAN NOT NULL DEFAULT true,
    validation_status TEXT DEFAULT 'pending' CHECK (validation_status IN ('validated', 'pending', 'failed', 'deprecated')),
    last_validated_at TIMESTAMPTZ,
    validated_by UUID,
    last_synced_at TIMESTAMPTZ,
    sync_status TEXT DEFAULT 'pending' CHECK (sync_status IN ('synced', 'pending', 'failed', 'conflict')),
    sync_error_message TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE external_column_mappings (
    mapping_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    external_metadata_id UUID NOT NULL REFERENCES external_metadata(external_metadata_id) ON DELETE CASCADE,
    source_column_name TEXT NOT NULL,
    source_column_type TEXT,
    source_column_description TEXT,
    target_property_id UUID,
    target_column_name TEXT,
    transformation_type TEXT CHECK (transformation_type IN ('direct', 'calculated', 'aggregated')),
    transformation_description TEXT,
    transformation_metadata JSONB,
    compatibility_status TEXT DEFAULT 'pending' CHECK (compatibility_status IN ('compatible', 'incompatible', 'warning', 'pending')),
    compatibility_notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE external_lineage_relationships (
    relationship_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    external_metadata_id UUID NOT NULL REFERENCES external_metadata(external_metadata_id) ON DELETE CASCADE,
    target_object_type TEXT NOT NULL,
    target_object_id TEXT NOT NULL,
    target_object_name TEXT,
    relationship_direction TEXT NOT NULL CHECK (relationship_direction IN ('upstream', 'downstream')),
    relationship_metadata JSONB,
    relationship_description TEXT,
    is_active BOOLEAN NOT NULL DEFAULT true,
    validation_status TEXT DEFAULT 'pending' CHECK (validation_status IN ('validated', 'pending', 'failed')),
    validated_by UUID,
    validated_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ============================================================================
-- CORE ENTITIES - Entidades Principais
-- ============================================================================

CREATE TABLE data_contracts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    description TEXT,
    version TEXT NOT NULL DEFAULT '1.0.0',
    status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'active', 'deprecated', 'archived')),
    schema_definition JSONB,
    data_classification TEXT DEFAULT 'internal' CHECK (data_classification IN ('public', 'internal', 'confidential', 'restricted')),
    owner_id UUID,
    steward_id UUID,
    business_domain TEXT,
    tags TEXT[],
    metadata JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    created_by UUID,
    updated_by UUID
);

CREATE TABLE contract_versions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    contract_id UUID NOT NULL REFERENCES data_contracts(id) ON DELETE CASCADE,
    version_number TEXT NOT NULL,
    schema_definition JSONB NOT NULL,
    changelog TEXT,
    compatibility_mode TEXT DEFAULT 'backward' CHECK (compatibility_mode IN ('backward', 'forward', 'full', 'none')),
    is_active BOOLEAN DEFAULT false,
    activation_date TIMESTAMPTZ,
    deprecation_date TIMESTAMPTZ,
    migration_guide TEXT,
    breaking_changes TEXT[],
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    created_by UUID
);

CREATE TABLE contract_layouts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    contract_id UUID NOT NULL REFERENCES data_contracts(id) ON DELETE CASCADE,
    country_code TEXT NOT NULL,
    region_code TEXT,
    layout_name TEXT NOT NULL,
    layout_config JSONB NOT NULL,
    field_mappings JSONB,
    validation_rules JSONB,
    formatting_rules JSONB,
    compliance_requirements TEXT[],
    is_active BOOLEAN DEFAULT true,
    priority INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE contract_schema_definitions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    contract_id UUID NOT NULL REFERENCES data_contracts(id) ON DELETE CASCADE,
    field_name TEXT NOT NULL,
    field_type TEXT NOT NULL,
    field_description TEXT,
    is_required BOOLEAN DEFAULT false,
    is_pii BOOLEAN DEFAULT false,
    default_value TEXT,
    validation_pattern TEXT,
    min_length INTEGER,
    max_length INTEGER,
    min_value NUMERIC,
    max_value NUMERIC,
    enum_values TEXT[],
    format_hint TEXT,
    business_rules TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ============================================================================
-- DATA OBJECTS - Catálogo de Objetos de Dados
-- ============================================================================

CREATE TABLE data_objects (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    description TEXT,
    object_type TEXT NOT NULL CHECK (object_type IN ('table', 'view', 'file', 'api', 'stream')),
    data_source TEXT,
    schema_name TEXT,
    table_name TEXT,
    full_path TEXT,
    contract_id UUID REFERENCES data_contracts(id),
    business_domain TEXT,
    data_classification TEXT DEFAULT 'internal',
    contains_pii BOOLEAN DEFAULT false,
    record_count BIGINT,
    data_size_bytes BIGINT,
    last_updated TIMESTAMPTZ,
    update_frequency TEXT,
    retention_period TEXT,
    tags TEXT[],
    metadata JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE data_object_properties (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    data_object_id UUID NOT NULL REFERENCES data_objects(id) ON DELETE CASCADE,
    property_name TEXT NOT NULL,
    property_type TEXT NOT NULL,
    property_description TEXT,
    is_nullable BOOLEAN DEFAULT true,
    is_primary_key BOOLEAN DEFAULT false,
    is_foreign_key BOOLEAN DEFAULT false,
    is_indexed BOOLEAN DEFAULT false,
    is_pii BOOLEAN DEFAULT false,
    data_classification TEXT,
    sample_values TEXT[],
    distinct_count BIGINT,
    null_count BIGINT,
    min_value TEXT,
    max_value TEXT,
    avg_length NUMERIC,
    pattern_analysis JSONB,
    quality_score NUMERIC,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ============================================================================
-- QUALITY MANAGEMENT - Gestão de Qualidade
-- ============================================================================

CREATE TABLE quality_rules (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    description TEXT,
    rule_type TEXT NOT NULL CHECK (rule_type IN ('completeness', 'uniqueness', 'validity', 'consistency', 'accuracy', 'integrity', 'timeliness', 'conformity', 'business_rule', 'custom')),
    data_object_id UUID REFERENCES data_objects(id),
    contract_id UUID REFERENCES data_contracts(id),
    rule_definition JSONB NOT NULL,
    rule_parameters JSONB,
    threshold_warning NUMERIC DEFAULT 80,
    threshold_critical NUMERIC DEFAULT 95,
    is_active BOOLEAN DEFAULT true,
    execution_frequency TEXT DEFAULT 'daily',
    execution_schedule TEXT,
    dimension TEXT NOT NULL,
    weight NUMERIC DEFAULT 1.0,
    business_impact TEXT,
    remediation_guide TEXT,
    owner_id UUID,
    tags TEXT[],
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE quality_executions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    rule_id UUID NOT NULL REFERENCES quality_rules(id) ON DELETE CASCADE,
    execution_id TEXT NOT NULL,
    execution_type TEXT DEFAULT 'scheduled' CHECK (execution_type IN ('scheduled', 'manual', 'triggered')),
    status TEXT NOT NULL CHECK (status IN ('running', 'completed', 'failed', 'cancelled')),
    started_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    completed_at TIMESTAMPTZ,
    duration_ms INTEGER,
    records_processed BIGINT,
    records_passed BIGINT,
    records_failed BIGINT,
    pass_rate NUMERIC,
    quality_score NUMERIC,
    execution_details JSONB,
    error_message TEXT,
    sample_failures JSONB,
    execution_context JSONB
);

CREATE TABLE quality_results (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    execution_id UUID NOT NULL REFERENCES quality_executions(id) ON DELETE CASCADE,
    rule_id UUID NOT NULL REFERENCES quality_rules(id),
    data_object_id UUID NOT NULL REFERENCES data_objects(id),
    measurement_date TIMESTAMPTZ NOT NULL DEFAULT now(),
    dimension TEXT NOT NULL,
    metric_name TEXT NOT NULL,
    metric_value NUMERIC NOT NULL,
    metric_unit TEXT,
    threshold_status TEXT CHECK (threshold_status IN ('excellent', 'good', 'warning', 'critical')),
    baseline_value NUMERIC,
    trend_direction TEXT CHECK (trend_direction IN ('up', 'down', 'stable')),
    anomaly_score NUMERIC,
    is_anomaly BOOLEAN DEFAULT false,
    business_impact_score NUMERIC,
    metadata JSONB
);

-- ============================================================================
-- ANOMALY DETECTION - Detecção de Anomalias com ML
-- ============================================================================

CREATE TABLE anomaly_detections (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    anomaly_type TEXT NOT NULL CHECK (anomaly_type IN ('statistical_outlier', 'pattern_deviation', 'volume_anomaly', 'quality_degradation', 'usage_anomaly', 'schema_drift', 'temporal_anomaly')),
    detection_method TEXT NOT NULL CHECK (detection_method IN ('isolation_forest', 'z_score', 'iqr', 'lstm', 'autoencoder', 'ensemble')),
    data_object_id UUID REFERENCES data_objects(id),
    contract_id UUID REFERENCES data_contracts(id),
    anomaly_score NUMERIC NOT NULL,
    confidence_score NUMERIC NOT NULL,
    threshold_used NUMERIC NOT NULL,
    is_confirmed BOOLEAN DEFAULT false,
    severity TEXT NOT NULL CHECK (severity IN ('low', 'medium', 'high', 'critical')),
    status TEXT DEFAULT 'open' CHECK (status IN ('open', 'investigating', 'resolved', 'false_positive')),
    description TEXT,
    affected_metrics JSONB,
    detection_context JSONB,
    root_cause_analysis TEXT,
    remediation_actions TEXT,
    detected_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    resolved_at TIMESTAMPTZ,
    resolved_by UUID,
    model_version TEXT
);

-- ============================================================================
-- DATA LINEAGE - Linhagem de Dados
-- ============================================================================

CREATE TABLE data_lineage (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    source_object_id UUID NOT NULL REFERENCES data_objects(id),
    target_object_id UUID NOT NULL REFERENCES data_objects(id),
    lineage_type TEXT NOT NULL CHECK (lineage_type IN ('direct_copy', 'transformation', 'aggregation', 'join', 'union', 'filter')),
    transformation_logic TEXT,
    transformation_tool TEXT,
    job_name TEXT,
    job_id TEXT,
    execution_frequency TEXT,
    last_execution TIMESTAMPTZ,
    confidence_score NUMERIC DEFAULT 1.0,
    detection_method TEXT CHECK (detection_method IN ('manual', 'automatic', 'inferred')),
    business_process TEXT,
    data_flow_direction TEXT DEFAULT 'downstream' CHECK (data_flow_direction IN ('upstream', 'downstream', 'bidirectional')),
    impact_level TEXT CHECK (impact_level IN ('low', 'medium', 'high', 'critical')),
    lineage_metadata JSONB,
    tags TEXT[],
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ============================================================================
-- PRIVACY & COMPLIANCE - Privacidade e Conformidade
-- ============================================================================

CREATE TABLE data_policies (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    description TEXT,
    policy_type TEXT NOT NULL CHECK (policy_type IN ('privacy', 'retention', 'access', 'masking', 'encryption', 'backup')),
    regulation_framework TEXT CHECK (regulation_framework IN ('LGPD', 'GDPR', 'CCPA', 'HIPAA', 'SOX')),
    policy_definition JSONB NOT NULL,
    scope_type TEXT NOT NULL CHECK (scope_type IN ('global', 'domain', 'contract', 'data_object')),
    scope_id UUID,
    enforcement_level TEXT DEFAULT 'mandatory' CHECK (enforcement_level IN ('mandatory', 'recommended', 'optional')),
    enforcement_method TEXT CHECK (enforcement_method IN ('automatic', 'manual', 'hybrid')),
    is_active BOOLEAN DEFAULT true,
    effective_from TIMESTAMPTZ NOT NULL DEFAULT now(),
    effective_until TIMESTAMPTZ,
    review_frequency TEXT,
    next_review_date TIMESTAMPTZ,
    owner_id UUID,
    approved_by UUID,
    approval_date TIMESTAMPTZ,
    version TEXT DEFAULT '1.0',
    previous_version_id UUID,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ============================================================================
-- USERS & PERMISSIONS - Usuários e Permissões
-- ============================================================================

CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    username TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE NOT NULL,
    full_name TEXT,
    role TEXT,
    department TEXT,
    password_hash TEXT,
    is_active BOOLEAN DEFAULT true,
    is_superuser BOOLEAN DEFAULT false,
    last_login TIMESTAMPTZ,
    login_count INTEGER DEFAULT 0,
    failed_login_attempts INTEGER DEFAULT 0,
    locked_until TIMESTAMPTZ,
    password_changed_at TIMESTAMPTZ,
    profile_data JSONB,
    preferences JSONB,
    timezone TEXT DEFAULT 'UTC',
    language TEXT DEFAULT 'pt-BR',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE groups (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT UNIQUE NOT NULL,
    description TEXT,
    group_type TEXT DEFAULT 'role' CHECK (group_type IN ('role', 'department', 'project', 'custom')),
    is_active BOOLEAN DEFAULT true,
    parent_group_id UUID REFERENCES groups(id),
    level INTEGER DEFAULT 0,
    member_count INTEGER DEFAULT 0,
    permissions_inherited BOOLEAN DEFAULT true,
    metadata JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE user_groups (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    group_id UUID NOT NULL REFERENCES groups(id) ON DELETE CASCADE,
    role_in_group TEXT CHECK (role_in_group IN ('member', 'admin', 'owner')),
    joined_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    joined_by UUID REFERENCES users(id),
    is_active BOOLEAN DEFAULT true,
    UNIQUE(user_id, group_id)
);

CREATE TABLE permissions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT UNIQUE NOT NULL,
    description TEXT,
    resource_type TEXT NOT NULL,
    action TEXT NOT NULL CHECK (action IN ('create', 'read', 'update', 'delete', 'execute', 'approve')),
    scope TEXT DEFAULT 'all' CHECK (scope IN ('all', 'own', 'group', 'custom')),
    condition_expression TEXT,
    is_system_permission BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE group_permission_assignments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    group_id UUID NOT NULL REFERENCES groups(id) ON DELETE CASCADE,
    permission_id UUID NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
    granted_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    granted_by UUID REFERENCES users(id),
    expires_at TIMESTAMPTZ,
    is_active BOOLEAN DEFAULT true,
    UNIQUE(group_id, permission_id)
);

CREATE TABLE user_permission_assignments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    permission_id UUID NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
    resource_id UUID,
    granted_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    granted_by UUID REFERENCES users(id),
    expires_at TIMESTAMPTZ,
    is_active BOOLEAN DEFAULT true
);

-- ============================================================================
-- AUDIT & COMPLIANCE - Auditoria e Conformidade
-- ============================================================================

CREATE TABLE audit_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    event_type TEXT NOT NULL CHECK (event_type IN ('CREATE', 'READ', 'UPDATE', 'DELETE', 'EXECUTE', 'LOGIN', 'LOGOUT', 'SYNC', 'TRAIN', 'IMPORT', 'EXPORT', 'APPROVE', 'REJECT', 'LINK', 'UNLINK', 'ERROR')),
    resource_type TEXT NOT NULL,
    resource_id UUID,
    user_id UUID REFERENCES users(id),
    session_id TEXT,
    ip_address INET,
    user_agent TEXT,
    action TEXT NOT NULL,
    details JSONB,
    old_values JSONB,
    new_values JSONB,
    status TEXT CHECK (status IN ('success', 'failure', 'partial')),
    error_message TEXT,
    duration_ms INTEGER,
    compliance_flags TEXT[],
    risk_score INTEGER CHECK (risk_score BETWEEN 0 AND 100),
    timestamp TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ============================================================================
-- ANALYTICS & REPORTING - Analytics e Relatórios
-- ============================================================================

CREATE TABLE governance_kpis (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    kpi_name TEXT NOT NULL,
    kpi_category TEXT NOT NULL CHECK (kpi_category IN ('quality', 'compliance', 'usage', 'performance', 'cost', 'adoption', 'risk', 'efficiency')),
    measurement_date TIMESTAMPTZ NOT NULL DEFAULT now(),
    current_value NUMERIC NOT NULL,
    target_value NUMERIC,
    previous_value NUMERIC,
    unit TEXT,
    trend_direction TEXT CHECK (trend_direction IN ('up', 'down', 'stable')),
    trend_percentage NUMERIC,
    status TEXT CHECK (status IN ('excellent', 'good', 'warning', 'critical')),
    calculation_method TEXT,
    data_sources TEXT[],
    business_context TEXT,
    improvement_actions TEXT
);

CREATE TABLE report_definitions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    description TEXT,
    report_type TEXT NOT NULL CHECK (report_type IN ('executive_summary', 'technical_detail', 'compliance_report', 'quality_assessment', 'usage_analysis')),
    template_config JSONB NOT NULL,
    data_sources JSONB,
    filters JSONB,
    schedule_expression TEXT,
    output_formats TEXT[] DEFAULT '{json}',
    recipients TEXT[],
    is_active BOOLEAN DEFAULT true,
    owner_id UUID REFERENCES users(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE report_executions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    report_definition_id UUID NOT NULL REFERENCES report_definitions(id) ON DELETE CASCADE,
    execution_type TEXT DEFAULT 'scheduled' CHECK (execution_type IN ('scheduled', 'manual', 'api')),
    status TEXT NOT NULL CHECK (status IN ('running', 'completed', 'failed')),
    started_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    completed_at TIMESTAMPTZ,
    duration_ms INTEGER,
    output_format TEXT,
    output_size_bytes INTEGER,
    output_path TEXT,
    parameters_used JSONB,
    error_message TEXT,
    generated_by UUID REFERENCES users(id)
);

-- ============================================================================
-- INTEGRATION METADATA - Metadados de Integração
-- ============================================================================

CREATE TABLE integration_configs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    integration_name TEXT NOT NULL,
    integration_type TEXT NOT NULL CHECK (integration_type IN ('unity_catalog', 'informatica_axon', 'databricks', 'custom')),
    connection_config JSONB NOT NULL,
    sync_frequency TEXT DEFAULT 'daily',
    last_sync_at TIMESTAMPTZ,
    sync_status TEXT CHECK (sync_status IN ('success', 'failure', 'partial', 'never_run')),
    error_count INTEGER DEFAULT 0,
    last_error_message TEXT,
    is_active BOOLEAN DEFAULT true,
    health_check_url TEXT,
    timeout_seconds INTEGER DEFAULT 30,
    retry_count INTEGER DEFAULT 3,
    metadata JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE sync_operations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    integration_config_id UUID NOT NULL REFERENCES integration_configs(id) ON DELETE CASCADE,
    operation_type TEXT NOT NULL CHECK (operation_type IN ('full_sync', 'incremental_sync', 'metadata_sync', 'schema_sync')),
    status TEXT NOT NULL CHECK (status IN ('running', 'completed', 'failed', 'cancelled')),
    started_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    completed_at TIMESTAMPTZ,
    duration_ms INTEGER,
    records_processed INTEGER,
    records_created INTEGER,
    records_updated INTEGER,
    records_deleted INTEGER,
    records_failed INTEGER,
    error_details JSONB,
    operation_metadata JSONB
);

-- ============================================================================
-- ÍNDICES PARA PERFORMANCE
-- ============================================================================

-- Índices para external_metadata
CREATE INDEX idx_external_metadata_system_type ON external_metadata(system_type);
CREATE INDEX idx_external_metadata_entity_type ON external_metadata(entity_type);
CREATE INDEX idx_external_metadata_validation_status ON external_metadata(validation_status);
CREATE INDEX idx_external_metadata_sync_status ON external_metadata(sync_status);
CREATE INDEX idx_external_metadata_created_at ON external_metadata(created_at);

-- Índices para data_contracts
CREATE INDEX idx_data_contracts_name ON data_contracts(name);
CREATE INDEX idx_data_contracts_status ON data_contracts(status);
CREATE INDEX idx_data_contracts_business_domain ON data_contracts(business_domain);
CREATE INDEX idx_data_contracts_created_at ON data_contracts(created_at);

-- Índices para quality_rules
CREATE INDEX idx_quality_rules_rule_type ON quality_rules(rule_type);
CREATE INDEX idx_quality_rules_dimension ON quality_rules(dimension);
CREATE INDEX idx_quality_rules_is_active ON quality_rules(is_active);
CREATE INDEX idx_quality_rules_data_object_id ON quality_rules(data_object_id);

-- Índices para anomaly_detections
CREATE INDEX idx_anomaly_detections_anomaly_type ON anomaly_detections(anomaly_type);
CREATE INDEX idx_anomaly_detections_severity ON anomaly_detections(severity);
CREATE INDEX idx_anomaly_detections_status ON anomaly_detections(status);
CREATE INDEX idx_anomaly_detections_detected_at ON anomaly_detections(detected_at);

-- Índices para audit_logs
CREATE INDEX idx_audit_logs_event_type ON audit_logs(event_type);
CREATE INDEX idx_audit_logs_resource_type ON audit_logs(resource_type);
CREATE INDEX idx_audit_logs_user_id ON audit_logs(user_id);
CREATE INDEX idx_audit_logs_timestamp ON audit_logs(timestamp);

-- Índices para data_lineage
CREATE INDEX idx_data_lineage_source_object_id ON data_lineage(source_object_id);
CREATE INDEX idx_data_lineage_target_object_id ON data_lineage(target_object_id);
CREATE INDEX idx_data_lineage_lineage_type ON data_lineage(lineage_type);

-- ============================================================================
-- TRIGGERS PARA UPDATED_AT
-- ============================================================================

CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Aplicar trigger em todas as tabelas com updated_at
CREATE TRIGGER update_external_metadata_updated_at BEFORE UPDATE ON external_metadata FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_data_contracts_updated_at BEFORE UPDATE ON data_contracts FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_contract_layouts_updated_at BEFORE UPDATE ON contract_layouts FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_data_objects_updated_at BEFORE UPDATE ON data_objects FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_data_object_properties_updated_at BEFORE UPDATE ON data_object_properties FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_quality_rules_updated_at BEFORE UPDATE ON quality_rules FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_data_lineage_updated_at BEFORE UPDATE ON data_lineage FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_data_policies_updated_at BEFORE UPDATE ON data_policies FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_groups_updated_at BEFORE UPDATE ON groups FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_report_definitions_updated_at BEFORE UPDATE ON report_definitions FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_integration_configs_updated_at BEFORE UPDATE ON integration_configs FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ============================================================================
-- COMENTÁRIOS NAS TABELAS
-- ============================================================================

COMMENT ON SCHEMA governance IS 'Schema principal para o sistema de governança de dados TBR GDP Core';

COMMENT ON TABLE external_metadata IS 'Objetos de metadados externos para Unity Catalog External Lineage';
COMMENT ON TABLE external_column_mappings IS 'Mapeamentos column-level entre objetos externos e Unity Catalog';
COMMENT ON TABLE external_lineage_relationships IS 'Relacionamentos de linhagem entre objetos externos e Unity Catalog';

COMMENT ON TABLE data_contracts IS 'Contratos de dados - acordos formais sobre estrutura, qualidade e semântica';
COMMENT ON TABLE contract_versions IS 'Versionamento de contratos - permite múltiplas versões ativas';
COMMENT ON TABLE contract_layouts IS 'Layouts customizáveis por país/região para atender requisitos locais';

COMMENT ON TABLE data_objects IS 'Catálogo de objetos de dados - tabelas, arquivos, APIs, streams';
COMMENT ON TABLE data_object_properties IS 'Propriedades/colunas dos objetos de dados com profiling automático';

COMMENT ON TABLE quality_rules IS 'Regras de qualidade de dados com múltiplas dimensões';
COMMENT ON TABLE quality_executions IS 'Histórico de execuções das regras de qualidade';
COMMENT ON TABLE quality_results IS 'Resultados detalhados das medições de qualidade';

COMMENT ON TABLE anomaly_detections IS 'Anomalias detectadas por algoritmos de Machine Learning';

COMMENT ON TABLE data_lineage IS 'Linhagem de dados - rastreamento de origem e transformações';

COMMENT ON TABLE data_policies IS 'Políticas de dados para privacidade, retenção, acesso, etc.';

COMMENT ON TABLE users IS 'Usuários do sistema com autenticação e perfil';
COMMENT ON TABLE groups IS 'Grupos de usuários para organização e permissões';
COMMENT ON TABLE permissions IS 'Permissões granulares do sistema';

COMMENT ON TABLE audit_logs IS 'Log de auditoria completo para compliance e segurança';

COMMENT ON TABLE governance_kpis IS 'KPIs de governança para dashboards e relatórios';
COMMENT ON TABLE report_definitions IS 'Definições de relatórios automáticos';

COMMENT ON TABLE integration_configs IS 'Configurações de integrações com sistemas externos';

