-- TBR GDP Core - Data Governance API
-- Script de Dados Iniciais (Seed Data)
-- Popula o banco com dados básicos para funcionamento

SET search_path TO governance, public;

-- ============================================================================
-- USUÁRIOS INICIAIS
-- ============================================================================

INSERT INTO users (id, username, email, full_name, role, department, is_superuser, timezone, language) VALUES
('00000000-0000-0000-0000-000000000001', 'admin', 'admin@tbr-gdp.com', 'Administrador do Sistema', 'admin', 'TI', true, 'America/Sao_Paulo', 'pt-BR'),
('00000000-0000-0000-0000-000000000002', 'data_steward', 'steward@tbr-gdp.com', 'Data Steward Principal', 'data_steward', 'Dados', false, 'America/Sao_Paulo', 'pt-BR'),
('00000000-0000-0000-0000-000000000003', 'analyst', 'analyst@tbr-gdp.com', 'Analista de Dados', 'analyst', 'Analytics', false, 'America/Sao_Paulo', 'pt-BR'),
('00000000-0000-0000-0000-000000000004', 'business_user', 'business@tbr-gdp.com', 'Usuário de Negócio', 'business_user', 'Vendas', false, 'America/Sao_Paulo', 'pt-BR');

-- ============================================================================
-- GRUPOS E PERMISSÕES
-- ============================================================================

INSERT INTO groups (id, name, description, group_type) VALUES
('10000000-0000-0000-0000-000000000001', 'Administradores', 'Administradores do sistema', 'role'),
('10000000-0000-0000-0000-000000000002', 'Data Stewards', 'Responsáveis pela governança de dados', 'role'),
('10000000-0000-0000-0000-000000000003', 'Analistas', 'Analistas de dados e qualidade', 'role'),
('10000000-0000-0000-0000-000000000004', 'Usuários de Negócio', 'Usuários finais do sistema', 'role');

INSERT INTO permissions (id, name, description, resource_type, action) VALUES
('20000000-0000-0000-0000-000000000001', 'contracts.create', 'Criar contratos de dados', 'contract', 'create'),
('20000000-0000-0000-0000-000000000002', 'contracts.read', 'Visualizar contratos de dados', 'contract', 'read'),
('20000000-0000-0000-0000-000000000003', 'contracts.update', 'Atualizar contratos de dados', 'contract', 'update'),
('20000000-0000-0000-0000-000000000004', 'contracts.delete', 'Excluir contratos de dados', 'contract', 'delete'),
('20000000-0000-0000-0000-000000000005', 'quality.execute', 'Executar regras de qualidade', 'quality_rule', 'execute'),
('20000000-0000-0000-0000-000000000006', 'lineage.read', 'Visualizar linhagem de dados', 'lineage', 'read'),
('20000000-0000-0000-0000-000000000007', 'anomalies.investigate', 'Investigar anomalias', 'anomaly', 'update'),
('20000000-0000-0000-0000-000000000008', 'reports.generate', 'Gerar relatórios', 'report', 'create'),
('20000000-0000-0000-0000-000000000009', 'admin.all', 'Acesso total de administrador', 'all', 'all');

-- Associar usuários a grupos
INSERT INTO user_groups (user_id, group_id, role_in_group) VALUES
('00000000-0000-0000-0000-000000000001', '10000000-0000-0000-0000-000000000001', 'owner'),
('00000000-0000-0000-0000-000000000002', '10000000-0000-0000-0000-000000000002', 'admin'),
('00000000-0000-0000-0000-000000000003', '10000000-0000-0000-0000-000000000003', 'member'),
('00000000-0000-0000-0000-000000000004', '10000000-0000-0000-0000-000000000004', 'member');

-- Associar permissões a grupos
INSERT INTO group_permission_assignments (group_id, permission_id, granted_by) VALUES
('10000000-0000-0000-0000-000000000001', '20000000-0000-0000-0000-000000000009', '00000000-0000-0000-0000-000000000001'),
('10000000-0000-0000-0000-000000000002', '20000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-000000000001'),
('10000000-0000-0000-0000-000000000002', '20000000-0000-0000-0000-000000000002', '00000000-0000-0000-0000-000000000001'),
('10000000-0000-0000-0000-000000000002', '20000000-0000-0000-0000-000000000003', '00000000-0000-0000-0000-000000000001'),
('10000000-0000-0000-0000-000000000002', '20000000-0000-0000-0000-000000000005', '00000000-0000-0000-0000-000000000001'),
('10000000-0000-0000-0000-000000000002', '20000000-0000-0000-0000-000000000007', '00000000-0000-0000-0000-000000000001'),
('10000000-0000-0000-0000-000000000003', '20000000-0000-0000-0000-000000000002', '00000000-0000-0000-0000-000000000001'),
('10000000-0000-0000-0000-000000000003', '20000000-0000-0000-0000-000000000005', '00000000-0000-0000-0000-000000000001'),
('10000000-0000-0000-0000-000000000003', '20000000-0000-0000-0000-000000000006', '00000000-0000-0000-0000-000000000001'),
('10000000-0000-0000-0000-000000000003', '20000000-0000-0000-0000-000000000008', '00000000-0000-0000-0000-000000000001'),
('10000000-0000-0000-0000-000000000004', '20000000-0000-0000-0000-000000000002', '00000000-0000-0000-0000-000000000001'),
('10000000-0000-0000-0000-000000000004', '20000000-0000-0000-0000-000000000006', '00000000-0000-0000-0000-000000000001');

-- ============================================================================
-- CONTRATOS DE DADOS INICIAIS
-- ============================================================================

INSERT INTO data_contracts (id, name, description, version, status, schema_definition, data_classification, business_domain, tags, owner_id, steward_id) VALUES
('30000000-0000-0000-0000-000000000001', 'customer_data_contract', 'Contrato para dados de clientes do e-commerce', '2.1.0', 'active', 
'{"type": "object", "properties": {"customer_id": {"type": "string", "pattern": "^CUST[0-9]{8}$"}, "email": {"type": "string", "format": "email"}, "phone": {"type": "string"}, "created_at": {"type": "string", "format": "date-time"}, "status": {"type": "string", "enum": ["active", "inactive", "suspended"]}}}',
'confidential', 'sales', ARRAY['customer', 'pii', 'ecommerce'], '00000000-0000-0000-0000-000000000002', '00000000-0000-0000-0000-000000000002'),

('30000000-0000-0000-0000-000000000002', 'order_data_contract', 'Contrato para dados de pedidos', '1.5.0', 'active',
'{"type": "object", "properties": {"order_id": {"type": "string"}, "customer_id": {"type": "string"}, "order_date": {"type": "string", "format": "date-time"}, "total_amount": {"type": "number", "minimum": 0}, "status": {"type": "string", "enum": ["pending", "confirmed", "shipped", "delivered", "cancelled"]}}}',
'internal', 'sales', ARRAY['order', 'transaction'], '00000000-0000-0000-0000-000000000002', '00000000-0000-0000-0000-000000000002'),

('30000000-0000-0000-0000-000000000003', 'product_catalog_contract', 'Contrato para catálogo de produtos', '1.0.0', 'active',
'{"type": "object", "properties": {"product_id": {"type": "string"}, "name": {"type": "string"}, "description": {"type": "string"}, "price": {"type": "number", "minimum": 0}, "category": {"type": "string"}, "is_active": {"type": "boolean"}}}',
'public', 'product', ARRAY['product', 'catalog'], '00000000-0000-0000-0000-000000000002', '00000000-0000-0000-0000-000000000002');

-- Versões dos contratos
INSERT INTO contract_versions (contract_id, version_number, schema_definition, changelog, is_active) VALUES
('30000000-0000-0000-0000-000000000001', '2.1.0', 
'{"type": "object", "properties": {"customer_id": {"type": "string", "pattern": "^CUST[0-9]{8}$"}, "email": {"type": "string", "format": "email"}, "phone": {"type": "string"}, "created_at": {"type": "string", "format": "date-time"}, "status": {"type": "string", "enum": ["active", "inactive", "suspended"]}}}',
'Adicionado campo status e validação de customer_id', true),

('30000000-0000-0000-0000-000000000001', '2.0.0', 
'{"type": "object", "properties": {"customer_id": {"type": "string"}, "email": {"type": "string", "format": "email"}, "phone": {"type": "string"}, "created_at": {"type": "string", "format": "date-time"}}}',
'Versão anterior sem campo status', false);

-- Layouts por país
INSERT INTO contract_layouts (contract_id, country_code, layout_name, layout_config, compliance_requirements) VALUES
('30000000-0000-0000-0000-000000000001', 'BR', 'Layout Brasil', 
'{"date_format": "dd/MM/yyyy", "phone_format": "(XX) XXXXX-XXXX", "currency": "BRL"}',
ARRAY['LGPD']),

('30000000-0000-0000-0000-000000000001', 'US', 'Layout Estados Unidos',
'{"date_format": "MM/dd/yyyy", "phone_format": "(XXX) XXX-XXXX", "currency": "USD"}',
ARRAY['CCPA']),

('30000000-0000-0000-0000-000000000001', 'EU', 'Layout União Europeia',
'{"date_format": "dd.MM.yyyy", "phone_format": "+XX XX XXXX XXXX", "currency": "EUR"}',
ARRAY['GDPR']);

-- ============================================================================
-- OBJETOS DE DADOS
-- ============================================================================

INSERT INTO data_objects (id, name, description, object_type, data_source, schema_name, table_name, full_path, contract_id, business_domain, contains_pii, record_count, data_size_bytes) VALUES
('40000000-0000-0000-0000-000000000001', 'customers', 'Tabela principal de clientes', 'table', 'databricks', 'main.ecommerce', 'customers', 'main.ecommerce.customers', '30000000-0000-0000-0000-000000000001', 'sales', true, 150000, 52428800),

('40000000-0000-0000-0000-000000000002', 'orders', 'Tabela de pedidos', 'table', 'databricks', 'main.ecommerce', 'orders', 'main.ecommerce.orders', '30000000-0000-0000-0000-000000000002', 'sales', false, 500000, 104857600),

('40000000-0000-0000-0000-000000000003', 'products', 'Catálogo de produtos', 'table', 'databricks', 'main.ecommerce', 'products', 'main.ecommerce.products', '30000000-0000-0000-0000-000000000003', 'product', false, 25000, 10485760),

('40000000-0000-0000-0000-000000000004', 'customer_summary', 'View resumo de clientes', 'view', 'databricks', 'main.analytics', 'customer_summary', 'main.analytics.customer_summary', null, 'analytics', true, 150000, 0);

-- Propriedades dos objetos
INSERT INTO data_object_properties (data_object_id, property_name, property_type, property_description, is_nullable, is_primary_key, is_pii, distinct_count, null_count, quality_score) VALUES
('40000000-0000-0000-0000-000000000001', 'customer_id', 'string', 'ID único do cliente', false, true, false, 150000, 0, 100.0),
('40000000-0000-0000-0000-000000000001', 'email', 'string', 'Email do cliente', false, false, true, 149500, 500, 99.7),
('40000000-0000-0000-0000-000000000001', 'phone', 'string', 'Telefone do cliente', true, false, true, 145000, 5000, 96.7),
('40000000-0000-0000-0000-000000000001', 'created_at', 'timestamp', 'Data de criação', false, false, false, 150000, 0, 100.0),
('40000000-0000-0000-0000-000000000001', 'status', 'string', 'Status do cliente', false, false, false, 3, 0, 100.0);

-- ============================================================================
-- REGRAS DE QUALIDADE
-- ============================================================================

INSERT INTO quality_rules (id, name, description, rule_type, data_object_id, contract_id, rule_definition, dimension, threshold_warning, threshold_critical, is_active) VALUES
('50000000-0000-0000-0000-000000000001', 'customer_email_completeness', 'Verificar se email está presente', 'completeness', '40000000-0000-0000-0000-000000000001', '30000000-0000-0000-0000-000000000001', 
'{"column": "email", "check_type": "not_null"}', 'completeness', 95.0, 99.0, true),

('50000000-0000-0000-0000-000000000002', 'customer_email_format', 'Verificar formato do email', 'validity', '40000000-0000-0000-0000-000000000001', '30000000-0000-0000-0000-000000000001',
'{"column": "email", "format": "email"}', 'validity', 98.0, 99.5, true),

('50000000-0000-0000-0000-000000000003', 'customer_id_uniqueness', 'Verificar unicidade do customer_id', 'uniqueness', '40000000-0000-0000-0000-000000000001', '30000000-0000-0000-0000-000000000001',
'{"column": "customer_id", "check_type": "unique"}', 'uniqueness', 99.9, 100.0, true),

('50000000-0000-0000-0000-000000000004', 'order_amount_validity', 'Verificar se valor do pedido é positivo', 'validity', '40000000-0000-0000-0000-000000000002', '30000000-0000-0000-0000-000000000002',
'{"column": "total_amount", "condition": "> 0"}', 'validity', 99.0, 99.8, true);

-- ============================================================================
-- LINHAGEM DE DADOS
-- ============================================================================

INSERT INTO data_lineage (source_object_id, target_object_id, lineage_type, transformation_logic, transformation_tool, confidence_score, detection_method) VALUES
('40000000-0000-0000-0000-000000000001', '40000000-0000-0000-0000-000000000004', 'aggregation', 'SELECT customer_id, COUNT(*) as order_count, SUM(total_amount) as total_spent FROM customers c JOIN orders o ON c.customer_id = o.customer_id GROUP BY customer_id', 'databricks_sql', 1.0, 'automatic'),

('40000000-0000-0000-0000-000000000002', '40000000-0000-0000-0000-000000000004', 'aggregation', 'Agregação de pedidos por cliente', 'databricks_sql', 1.0, 'automatic');

-- ============================================================================
-- POLÍTICAS DE DADOS
-- ============================================================================

INSERT INTO data_policies (id, name, description, policy_type, regulation_framework, policy_definition, scope_type, scope_id, enforcement_level) VALUES
('60000000-0000-0000-0000-000000000001', 'LGPD_PII_Protection', 'Proteção de dados pessoais conforme LGPD', 'privacy', 'LGPD', 
'{"data_types": ["email", "phone", "cpf"], "protection_methods": ["encryption", "masking"], "retention_period": "5_years", "consent_required": true}',
'global', null, 'mandatory'),

('60000000-0000-0000-0000-000000000002', 'Customer_Data_Retention', 'Política de retenção para dados de clientes', 'retention', null,
'{"retention_period": "7_years", "archive_after": "3_years", "delete_after": "7_years", "exceptions": ["legal_hold"]}',
'contract', '30000000-0000-0000-0000-000000000001', 'mandatory'),

('60000000-0000-0000-0000-000000000003', 'Sensitive_Data_Access', 'Controle de acesso a dados sensíveis', 'access', null,
'{"access_levels": ["read", "write", "admin"], "approval_required": true, "audit_all_access": true}',
'global', null, 'mandatory');

-- ============================================================================
-- CONFIGURAÇÕES DE INTEGRAÇÃO
-- ============================================================================

INSERT INTO integration_configs (id, integration_name, integration_type, connection_config, sync_frequency, is_active) VALUES
('70000000-0000-0000-0000-000000000001', 'Unity Catalog Principal', 'unity_catalog', 
'{"url": "https://databricks.empresa.com", "workspace_id": "12345", "token": "encrypted_token"}',
'hourly', true),

('70000000-0000-0000-0000-000000000002', 'Informatica Axon', 'informatica_axon',
'{"url": "https://axon.empresa.com", "username": "api_user", "password": "encrypted_password"}',
'daily', true),

('70000000-0000-0000-0000-000000000003', 'Tableau Server', 'custom',
'{"url": "https://tableau.empresa.com", "site_id": "default", "token": "encrypted_token"}',
'daily', true);

-- ============================================================================
-- METADADOS EXTERNOS (UNITY CATALOG EXTERNAL LINEAGE)
-- ============================================================================

INSERT INTO external_metadata (id, name, system_type, entity_type, external_url, description, properties, unity_catalog_external_id, validation_status, sync_status) VALUES
('80000000-0000-0000-0000-000000000001', 'customer_analytics_dashboard', 'tableau', 'dashboard', 'https://tableau.empresa.com/dashboards/customer_analytics', 'Dashboard principal de analytics de clientes',
'{"workbook_name": "Customer Analytics", "project": "Sales & Marketing", "owner": "analytics_team@empresa.com"}',
'external_tableau_001', 'validated', 'synced'),

('80000000-0000-0000-0000-000000000002', 'sales_performance_report', 'powerbi', 'report', 'https://powerbi.empresa.com/reports/sales_performance', 'Relatório de performance de vendas',
'{"workspace": "Sales", "owner": "sales_team@empresa.com", "refresh_schedule": "daily"}',
'external_powerbi_001', 'validated', 'synced'),

('80000000-0000-0000-0000-000000000003', 'customer_data_extract', 'salesforce', 'dataset', null, 'Extração de dados de clientes do Salesforce',
'{"object_type": "Account", "fields": ["Id", "Name", "Email", "Phone"], "last_modified": "2025-07-01T10:00:00Z"}',
'external_salesforce_001', 'pending', 'pending');

-- Relacionamentos de linhagem externa
INSERT INTO external_lineage_relationships (external_metadata_id, target_object_type, target_object_id, target_object_name, relationship_direction, relationship_description, validation_status) VALUES
('80000000-0000-0000-0000-000000000001', 'table', 'main.ecommerce.customers', 'customers', 'upstream', 'Dashboard consome dados da tabela de clientes', 'validated'),
('80000000-0000-0000-0000-000000000001', 'view', 'main.analytics.customer_summary', 'customer_summary', 'upstream', 'Dashboard usa view de resumo de clientes', 'validated'),
('80000000-0000-0000-0000-000000000002', 'table', 'main.ecommerce.orders', 'orders', 'upstream', 'Relatório usa dados de pedidos', 'validated'),
('80000000-0000-0000-0000-000000000003', 'table', 'main.ecommerce.customers', 'customers', 'downstream', 'Dados do Salesforce alimentam tabela de clientes', 'pending');

-- ============================================================================
-- KPIS DE GOVERNANÇA
-- ============================================================================

INSERT INTO governance_kpis (kpi_name, kpi_category, current_value, target_value, unit, status, calculation_method) VALUES
('Data Quality Score', 'quality', 94.2, 95.0, '%', 'good', 'Média ponderada de todas as regras de qualidade'),
('Contract Coverage', 'compliance', 78.5, 85.0, '%', 'warning', 'Percentual de objetos com contratos ativos'),
('Lineage Completeness', 'usage', 82.1, 90.0, '%', 'good', 'Percentual de objetos com linhagem mapeada'),
('Policy Compliance', 'compliance', 96.8, 98.0, '%', 'good', 'Percentual de conformidade com políticas'),
('Anomaly Detection Rate', 'risk', 2.3, 5.0, '%', 'excellent', 'Taxa de anomalias detectadas vs total de execuções'),
('User Adoption', 'adoption', 67.0, 80.0, '%', 'warning', 'Percentual de usuários ativos no sistema');

-- ============================================================================
-- DEFINIÇÕES DE RELATÓRIOS
-- ============================================================================

INSERT INTO report_definitions (id, name, description, report_type, template_config, schedule_expression, output_formats, recipients, owner_id) VALUES
('90000000-0000-0000-0000-000000000001', 'Executive Governance Summary', 'Relatório executivo mensal de governança', 'executive_summary',
'{"sections": ["kpis", "trends", "achievements", "recommendations"], "format": "executive"}',
'0 0 1 * *', ARRAY['pdf', 'json'], ARRAY['executives@empresa.com'], '00000000-0000-0000-0000-000000000002'),

('90000000-0000-0000-0000-000000000002', 'Quality Assessment Report', 'Relatório detalhado de qualidade de dados', 'quality_assessment',
'{"sections": ["quality_scores", "failed_rules", "trends", "recommendations"], "format": "technical"}',
'0 6 * * 1', ARRAY['pdf', 'excel'], ARRAY['data_team@empresa.com'], '00000000-0000-0000-0000-000000000002'),

('90000000-0000-0000-0000-000000000003', 'Compliance Status Report', 'Relatório de status de compliance', 'compliance_report',
'{"sections": ["policy_compliance", "audit_findings", "risk_assessment"], "format": "compliance"}',
'0 8 1 * *', ARRAY['pdf'], ARRAY['compliance@empresa.com', 'legal@empresa.com'], '00000000-0000-0000-0000-000000000002');

-- ============================================================================
-- LOGS DE AUDITORIA INICIAIS
-- ============================================================================

INSERT INTO audit_logs (event_type, resource_type, resource_id, user_id, action, details, status) VALUES
('CREATE', 'contract', '30000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-000000000002', 'create_contract', '{"contract_name": "customer_data_contract"}', 'success'),
('CREATE', 'quality_rule', '50000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-000000000002', 'create_quality_rule', '{"rule_name": "customer_email_completeness"}', 'success'),
('EXECUTE', 'quality_rule', '50000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-000000000003', 'execute_quality_rule', '{"execution_type": "manual"}', 'success'),
('CREATE', 'data_policy', '60000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-000000000001', 'create_policy', '{"policy_name": "LGPD_PII_Protection"}', 'success');

-- ============================================================================
-- ATUALIZAR CONTADORES
-- ============================================================================

-- Atualizar contadores de membros nos grupos
UPDATE groups SET member_count = (
    SELECT COUNT(*) FROM user_groups WHERE group_id = groups.id AND is_active = true
);

-- Inserir algumas execuções de qualidade simuladas
INSERT INTO quality_executions (rule_id, execution_id, status, started_at, completed_at, duration_ms, records_processed, records_passed, records_failed, pass_rate, quality_score) VALUES
('50000000-0000-0000-0000-000000000001', 'exec_001', 'completed', now() - interval '1 hour', now() - interval '59 minutes', 60000, 150000, 149500, 500, 99.67, 99.67),
('50000000-0000-0000-0000-000000000002', 'exec_002', 'completed', now() - interval '1 hour', now() - interval '58 minutes', 45000, 150000, 147000, 3000, 98.00, 98.00),
('50000000-0000-0000-0000-000000000003', 'exec_003', 'completed', now() - interval '1 hour', now() - interval '57 minutes', 30000, 150000, 150000, 0, 100.00, 100.00);

-- Inserir resultados de qualidade
INSERT INTO quality_results (execution_id, rule_id, data_object_id, dimension, metric_name, metric_value, metric_unit, threshold_status) VALUES
((SELECT id FROM quality_executions WHERE execution_id = 'exec_001'), '50000000-0000-0000-0000-000000000001', '40000000-0000-0000-0000-000000000001', 'completeness', 'null_percentage', 0.33, '%', 'good'),
((SELECT id FROM quality_executions WHERE execution_id = 'exec_002'), '50000000-0000-0000-0000-000000000002', '40000000-0000-0000-0000-000000000001', 'validity', 'format_violations', 2.00, '%', 'warning'),
((SELECT id FROM quality_executions WHERE execution_id = 'exec_003'), '50000000-0000-0000-0000-000000000003', '40000000-0000-0000-0000-000000000001', 'uniqueness', 'duplicate_percentage', 0.00, '%', 'excellent');

-- Inserir algumas anomalias simuladas
INSERT INTO anomaly_detections (anomaly_type, detection_method, data_object_id, anomaly_score, confidence_score, threshold_used, severity, status, description, detected_at) VALUES
('volume_anomaly', 'isolation_forest', '40000000-0000-0000-0000-000000000001', 0.85, 0.92, 0.8, 'high', 'investigating', 'Volume de novos clientes 40% abaixo da média histórica', now() - interval '2 hours'),
('quality_degradation', 'ensemble', '40000000-0000-0000-0000-000000000002', 0.78, 0.89, 0.75, 'medium', 'resolved', 'Aumento temporário em valores nulos', now() - interval '1 day'),
('pattern_deviation', 'lstm', '40000000-0000-0000-0000-000000000001', 0.72, 0.85, 0.7, 'low', 'false_positive', 'Padrão sazonal identificado incorretamente', now() - interval '3 hours');

COMMIT;

