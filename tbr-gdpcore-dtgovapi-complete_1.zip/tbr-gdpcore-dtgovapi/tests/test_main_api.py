"""
TBR GDP Core - Data Governance API
Testes Unitários para API Principal

Testes abrangentes para validar funcionalidades da API,
incluindo versionamento, multi-tenancy e Swagger.
"""

import pytest
import json
from datetime import datetime
from unittest.mock import patch, MagicMock

# Importar a aplicação
import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'src'))

from main import create_app


@pytest.fixture
def app():
    """Fixture para criar aplicação de teste"""
    app = create_app('testing')
    app.config['TESTING'] = True
    return app


@pytest.fixture
def client(app):
    """Fixture para cliente de teste"""
    return app.test_client()


@pytest.fixture
def auth_headers():
    """Headers de autenticação para testes"""
    return {
        'Authorization': 'Bearer test-token',
        'Content-Type': 'application/json',
        'X-Country-Code': 'BR',
        'X-Tenant-ID': 'test-tenant',
        'X-API-Version': '2.0.0'
    }


class TestHealthCheck:
    """Testes para health check da aplicação"""
    
    def test_health_check_success(self, client):
        """Testa health check básico"""
        response = client.get('/health')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        
        assert data['status'] == 'healthy'
        assert 'timestamp' in data
        assert 'components' in data
        assert data['components']['api'] == 'healthy'
    
    def test_health_check_headers(self, client):
        """Testa se headers de versionamento são adicionados"""
        response = client.get('/health')
        
        assert 'X-API-Version' in response.headers
        assert 'X-Tenant-ID' in response.headers


class TestAPIInfo:
    """Testes para endpoint de informações da API"""
    
    def test_api_info_success(self, client):
        """Testa endpoint de informações"""
        response = client.get('/info')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        
        assert data['api_name'] == 'TBR GDP Core - Data Governance API'
        assert 'version_info' in data
        assert 'tenant_info' in data
        assert 'documentation' in data
        assert data['documentation'] == '/docs/'


class TestVersioning:
    """Testes para sistema de versionamento"""
    
    def test_version_header_processing(self, client, auth_headers):
        """Testa processamento de headers de versão"""
        # Testar versão específica
        headers = auth_headers.copy()
        headers['X-API-Version'] = '1.0.0'
        
        response = client.get('/info', headers=headers)
        
        assert response.status_code == 200
        assert response.headers.get('X-API-Version') == '1.0.0'
    
    def test_default_version(self, client):
        """Testa versão padrão quando não especificada"""
        response = client.get('/info')
        
        assert response.status_code == 200
        # Versão padrão deve ser 2.0.0
        assert response.headers.get('X-API-Version') == '2.0.0'
    
    def test_invalid_version_fallback(self, client, auth_headers):
        """Testa fallback para versão inválida"""
        headers = auth_headers.copy()
        headers['X-API-Version'] = '99.0.0'  # Versão inexistente
        
        response = client.get('/info', headers=headers)
        
        assert response.status_code == 200
        # Deve fazer fallback para versão padrão
        assert response.headers.get('X-API-Version') == '2.0.0'


class TestMultiTenancy:
    """Testes para sistema de multi-tenancy geográfico"""
    
    def test_country_code_processing(self, client, auth_headers):
        """Testa processamento de código de país"""
        headers = auth_headers.copy()
        headers['X-Country-Code'] = 'US'
        
        response = client.get('/info', headers=headers)
        
        assert response.status_code == 200
        # Tenant deve ser resolvido baseado no país
        tenant_id = response.headers.get('X-Tenant-ID')
        assert tenant_id is not None
    
    def test_tenant_id_override(self, client, auth_headers):
        """Testa override de tenant ID"""
        headers = auth_headers.copy()
        headers['X-Tenant-ID'] = 'custom-tenant'
        
        response = client.get('/info', headers=headers)
        
        assert response.status_code == 200
        assert response.headers.get('X-Tenant-ID') == 'custom-tenant'
    
    def test_default_tenant(self, client):
        """Testa tenant padrão quando não especificado"""
        response = client.get('/info')
        
        assert response.status_code == 200
        assert response.headers.get('X-Tenant-ID') == 'default'


class TestSwaggerDocumentation:
    """Testes para documentação Swagger"""
    
    def test_swagger_ui_accessible(self, client):
        """Testa se Swagger UI está acessível"""
        response = client.get('/docs/')
        
        assert response.status_code == 200
        # Deve retornar HTML do Swagger UI
        assert b'swagger-ui' in response.data.lower()
    
    def test_openapi_spec_accessible(self, client):
        """Testa se especificação OpenAPI está acessível"""
        response = client.get('/swagger.json')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        
        assert 'openapi' in data
        assert 'info' in data
        assert data['info']['title'] == 'TBR GDP Core - Data Governance API'
        assert data['info']['version'] == '3.0.0'


class TestContractsAPI:
    """Testes para API de contratos de dados"""
    
    def test_list_contracts(self, client, auth_headers):
        """Testa listagem de contratos"""
        response = client.get('/api/v2/contracts/', headers=auth_headers)
        
        assert response.status_code == 200
        data = json.loads(response.data)
        
        assert isinstance(data, list)
        if len(data) > 0:
            contract = data[0]
            assert 'id' in contract
            assert 'name' in contract
            assert 'version' in contract
            assert 'status' in contract
    
    def test_create_contract(self, client, auth_headers):
        """Testa criação de contrato"""
        contract_data = {
            'name': 'test_contract',
            'description': 'Contrato de teste',
            'schema_definition': {
                'type': 'object',
                'properties': {
                    'id': {'type': 'string'},
                    'name': {'type': 'string'}
                }
            },
            'data_classification': 'internal'
        }
        
        response = client.post(
            '/api/v2/contracts/',
            headers=auth_headers,
            data=json.dumps(contract_data)
        )
        
        assert response.status_code == 201
        data = json.loads(response.data)
        
        assert data['name'] == 'test_contract'
        assert data['status'] == 'draft'
        assert 'id' in data
        assert 'created_at' in data
    
    def test_get_contract_by_id(self, client, auth_headers):
        """Testa obtenção de contrato por ID"""
        contract_id = 'test-contract-001'
        
        response = client.get(
            f'/api/v2/contracts/{contract_id}',
            headers=auth_headers
        )
        
        assert response.status_code == 200
        data = json.loads(response.data)
        
        assert data['id'] == contract_id
        assert 'name' in data
        assert 'schema_definition' in data


class TestQualityAPI:
    """Testes para API de qualidade de dados"""
    
    def test_quality_dashboard(self, client, auth_headers):
        """Testa dashboard de qualidade"""
        response = client.get('/api/v2/quality/dashboard', headers=auth_headers)
        
        assert response.status_code == 200
        data = json.loads(response.data)
        
        assert 'overall_score' in data
        assert 'total_rules' in data
        assert 'dimensions' in data
        assert isinstance(data['overall_score'], (int, float))
    
    def test_list_quality_rules(self, client, auth_headers):
        """Testa listagem de regras de qualidade"""
        response = client.get('/api/v2/quality/rules', headers=auth_headers)
        
        assert response.status_code == 200
        data = json.loads(response.data)
        
        assert isinstance(data, list)
        if len(data) > 0:
            rule = data[0]
            assert 'id' in rule
            assert 'name' in rule
            assert 'rule_type' in rule
            assert 'dimension' in rule


class TestLineageAPI:
    """Testes para API de linhagem de dados"""
    
    def test_lineage_graph(self, client, auth_headers):
        """Testa obtenção de grafo de linhagem"""
        object_id = 'main.ecommerce.customers'
        
        response = client.get(
            f'/api/v2/lineage/graph/{object_id}',
            headers=auth_headers
        )
        
        assert response.status_code == 200
        data = json.loads(response.data)
        
        assert data['object_id'] == object_id
        assert 'nodes' in data
        assert 'edges' in data
        assert 'metadata' in data
        assert isinstance(data['nodes'], list)
        assert isinstance(data['edges'], list)


class TestAnomaliesAPI:
    """Testes para API de detecção de anomalias"""
    
    def test_list_anomalies(self, client, auth_headers):
        """Testa listagem de anomalias"""
        response = client.get('/api/v2/anomalies/', headers=auth_headers)
        
        assert response.status_code == 200
        data = json.loads(response.data)
        
        assert isinstance(data, list)
        if len(data) > 0:
            anomaly = data[0]
            assert 'id' in anomaly
            assert 'anomaly_type' in anomaly
            assert 'severity' in anomaly
            assert 'anomaly_score' in anomaly
    
    def test_anomalies_dashboard(self, client, auth_headers):
        """Testa dashboard de anomalias"""
        response = client.get('/api/v2/anomalies/dashboard', headers=auth_headers)
        
        assert response.status_code == 200
        data = json.loads(response.data)
        
        assert 'summary' in data
        assert 'trends' in data
        assert 'top_affected_objects' in data
        assert 'model_performance' in data
    
    def test_create_anomaly_detection(self, client, auth_headers):
        """Testa criação de configuração de detecção"""
        detection_config = {
            'anomaly_type': 'volume_anomaly',
            'detection_method': 'isolation_forest',
            'data_object_id': 'main.ecommerce.customers',
            'threshold_config': {
                'threshold': 0.8
            }
        }
        
        response = client.post(
            '/api/v2/anomalies/',
            headers=auth_headers,
            data=json.dumps(detection_config)
        )
        
        assert response.status_code == 201
        data = json.loads(response.data)
        
        assert data['anomaly_type'] == 'volume_anomaly'
        assert data['detection_method'] == 'isolation_forest'
        assert 'id' in data


class TestExternalLineageAPI:
    """Testes para API de Unity Catalog External Lineage"""
    
    def test_list_external_metadata(self, client, auth_headers):
        """Testa listagem de metadados externos"""
        response = client.get('/api/v2/external-lineage/metadata', headers=auth_headers)
        
        assert response.status_code == 200
        data = json.loads(response.data)
        
        assert isinstance(data, list)
        if len(data) > 0:
            metadata = data[0]
            assert 'external_metadata_id' in metadata
            assert 'name' in metadata
            assert 'system_type' in metadata
            assert 'entity_type' in metadata
    
    def test_create_external_metadata(self, client, auth_headers):
        """Testa criação de metadado externo"""
        metadata_data = {
            'name': 'test_dashboard',
            'system_type': 'tableau',
            'entity_type': 'dashboard',
            'external_url': 'https://tableau.test.com/dashboard/test',
            'description': 'Dashboard de teste'
        }
        
        response = client.post(
            '/api/v2/external-lineage/metadata',
            headers=auth_headers,
            data=json.dumps(metadata_data)
        )
        
        assert response.status_code == 201
        data = json.loads(response.data)
        
        assert data['name'] == 'test_dashboard'
        assert data['system_type'] == 'tableau'
        assert 'external_metadata_id' in data
        assert 'unity_catalog_external_id' in data


class TestMonitoringAPI:
    """Testes para API de monitoramento"""
    
    def test_monitoring_health(self, client, auth_headers):
        """Testa health check do monitoramento"""
        response = client.get('/api/v2/monitoring/health', headers=auth_headers)
        
        assert response.status_code == 200
        data = json.loads(response.data)
        
        assert 'overall_status' in data
        assert 'components' in data
        assert 'active_monitors' in data
        assert isinstance(data['components'], dict)


class TestAnalyticsAPI:
    """Testes para API de analytics"""
    
    def test_executive_summary(self, client, auth_headers):
        """Testa relatório executivo"""
        response = client.get('/api/v2/analytics/executive-summary', headers=auth_headers)
        
        assert response.status_code == 200
        data = json.loads(response.data)
        
        assert 'governance_score' in data
        assert 'kpis' in data
        assert 'achievements' in data
        assert 'recommendations' in data
        assert isinstance(data['kpis'], list)


class TestErrorHandling:
    """Testes para tratamento de erros"""
    
    def test_404_error(self, client):
        """Testa erro 404"""
        response = client.get('/api/v2/nonexistent-endpoint')
        
        assert response.status_code == 404
        data = json.loads(response.data)
        
        assert data['error'] == 'Not Found'
        assert 'timestamp' in data
    
    def test_invalid_json(self, client, auth_headers):
        """Testa erro de JSON inválido"""
        response = client.post(
            '/api/v2/contracts/',
            headers=auth_headers,
            data='invalid json'
        )
        
        # Deve retornar erro 400 para JSON inválido
        assert response.status_code in [400, 422]


class TestSecurity:
    """Testes para recursos de segurança"""
    
    def test_cors_headers(self, client):
        """Testa headers CORS"""
        response = client.options('/api/v2/contracts/')
        
        assert response.status_code == 200
        assert 'Access-Control-Allow-Origin' in response.headers
        assert 'Access-Control-Allow-Methods' in response.headers
    
    def test_security_headers(self, client):
        """Testa headers de segurança"""
        response = client.get('/health')
        
        # Verificar se headers básicos estão presentes
        assert response.status_code == 200
        # Headers de segurança podem ser adicionados via middleware


class TestPerformance:
    """Testes básicos de performance"""
    
    def test_response_time_health(self, client):
        """Testa tempo de resposta do health check"""
        import time
        
        start_time = time.time()
        response = client.get('/health')
        end_time = time.time()
        
        response_time = (end_time - start_time) * 1000  # em ms
        
        assert response.status_code == 200
        assert response_time < 100  # Menos de 100ms
    
    def test_response_time_api_info(self, client):
        """Testa tempo de resposta do endpoint de info"""
        import time
        
        start_time = time.time()
        response = client.get('/info')
        end_time = time.time()
        
        response_time = (end_time - start_time) * 1000  # em ms
        
        assert response.status_code == 200
        assert response_time < 200  # Menos de 200ms


if __name__ == '__main__':
    pytest.main([__file__, '-v'])

