# TBR GDP Core - Data Governance API

**Sistema Completo de Governança de Dados Empresariais**

[![API Version](https://img.shields.io/badge/API-v3.0.0-blue.svg)](https://github.com/tbr/gdp-core-api)
[![Python](https://img.shields.io/badge/Python-3.11+-green.svg)](https://python.org)
[![License](https://img.shields.io/badge/License-Proprietary-red.svg)](LICENSE)
[![Swagger](https://img.shields.io/badge/Swagger-OpenAPI%203.0-orange.svg)](/docs/)

## 🎯 Visão Geral

O **TBR GDP Core - Data Governance API** é uma solução empresarial completa para governança de dados que integra contratos de dados, qualidade, linhagem, privacidade e analytics em uma plataforma unificada. Desenvolvido com foco em escalabilidade, conformidade regulatória e experiência do usuário.

### 🌟 Principais Características

- **🔄 Versionamento Avançado**: Múltiplas versões ativas da API (v1, v2, v3) com migração automática
- **🌍 Multi-Tenancy Geográfico**: Layouts customizáveis por país (BR, US, EU, GB, CA)
- **🤖 Machine Learning Integrado**: Detecção automática de anomalias e insights preditivos
- **🔗 Unity Catalog External Lineage**: Integração nativa com Databricks Unity Catalog
- **📊 Swagger Completo**: Documentação automática e interativa da API
- **🛡️ Compliance Total**: Suporte a LGPD, GDPR, CCPA, HIPAA, SOX
- **⚡ Performance Otimizada**: Cache Redis, índices otimizados, queries eficientes

## 🏗️ Arquitetura

### Componentes Principais

```
┌─────────────────────────────────────────────────────────────┐
│                    TBR GDP Core API                         │
├─────────────────────────────────────────────────────────────┤
│  🌐 API Gateway (Flask + Swagger)                          │
│  ├── Versionamento (v1, v2, v3)                           │
│  ├── Multi-Tenancy Geográfico                             │
│  └── Rate Limiting & Security                             │
├─────────────────────────────────────────────────────────────┤
│  📋 Core Modules                                           │
│  ├── Contracts (Contratos de Dados)                       │
│  ├── Quality (Qualidade de Dados)                         │
│  ├── Lineage (Linhagem de Dados)                          │
│  ├── Privacy (Privacidade & Compliance)                   │
│  ├── Analytics (Relatórios & KPIs)                        │
│  └── Monitoring (Monitoramento & Alertas)                 │
├─────────────────────────────────────────────────────────────┤
│  🤖 ML & AI Layer                                          │
│  ├── Anomaly Detection (Isolation Forest, LSTM)          │
│  ├── Quality Prediction                                   │
│  └── Usage Analytics                                      │
├─────────────────────────────────────────────────────────────┤
│  🔌 Integration Layer                                       │
│  ├── Unity Catalog External Lineage                       │
│  ├── Informatica Axon                                     │
│  ├── Tableau/Power BI                                     │
│  └── Custom Connectors                                    │
├─────────────────────────────────────────────────────────────┤
│  💾 Data Layer                                             │
│  ├── PostgreSQL (Metadados)                               │
│  ├── Redis (Cache & Sessions)                             │
│  └── File Storage (Relatórios)                            │
└─────────────────────────────────────────────────────────────┘
```

### Tecnologias Utilizadas

| Categoria | Tecnologia | Versão | Propósito |
|-----------|------------|--------|-----------|
| **Backend** | Python | 3.11+ | Linguagem principal |
| **Framework** | Flask | 3.0.0 | API REST |
| **API Docs** | Flask-RESTX | 1.3.0 | Swagger/OpenAPI |
| **Database** | PostgreSQL | 15+ | Dados principais |
| **Cache** | Redis | 7+ | Cache e sessões |
| **ML** | scikit-learn, TensorFlow | Latest | Machine Learning |
| **Monitoring** | Prometheus | Latest | Métricas |
| **Container** | Docker | Latest | Containerização |
| **Orchestration** | Kubernetes | 1.28+ | Deployment |

## 🚀 Início Rápido

### Pré-requisitos

- Python 3.11+
- PostgreSQL 15+
- Redis 7+
- Docker (opcional)

### Instalação Local (Windows)

```powershell
# 1. Clonar o repositório
git clone https://github.com/tbr/gdp-core-api.git
cd tbr-gdpcore-dtgovapi

# 2. Executar setup automático
.\scripts\setup-windows.ps1

# 3. Iniciar a aplicação
.\scripts\run-windows.ps1
```

### Instalação via Docker

```bash
# 1. Build da imagem
docker build -t tbr-gdpcore-api .

# 2. Executar com docker-compose
docker-compose up -d
```

### Deployment no Azure AKS

```powershell
# Deploy automático no AKS
.\scripts\deploy-aks.ps1 -ResourceGroup "meu-rg" -ClusterName "meu-aks" -AcrName "meu-acr"
```

## 📚 Documentação da API

### Swagger UI

Acesse a documentação interativa em: `http://localhost:5000/docs/`

### Endpoints Principais

#### 🔐 Autenticação

```http
POST /api/v2/auth/login
Content-Type: application/json

{
  "username": "user@empresa.com",
  "password": "senha123"
}
```

#### 📋 Contratos de Dados

```http
# Listar contratos
GET /api/v2/contracts?page=1&limit=20

# Criar contrato
POST /api/v2/contracts
Content-Type: application/json
X-Country-Code: BR

{
  "name": "customer_data_contract",
  "description": "Contrato para dados de clientes",
  "schema_definition": {
    "type": "object",
    "properties": {
      "customer_id": {"type": "string"},
      "email": {"type": "string", "format": "email"}
    }
  },
  "data_classification": "confidential"
}
```

#### 🔍 Qualidade de Dados

```http
# Dashboard de qualidade
GET /api/v2/quality/dashboard

# Executar regra de qualidade
POST /api/v2/quality/rules/{rule_id}/execute
```

#### 🔗 Linhagem de Dados

```http
# Obter grafo de linhagem
GET /api/v2/lineage/graph/{object_id}?depth=3

# Análise de impacto
GET /api/v2/lineage/impact-analysis/{object_id}
```

#### 🤖 Detecção de Anomalias

```http
# Listar anomalias
GET /api/v2/anomalies?severity=high&status=open

# Dashboard de anomalias
GET /api/v2/anomalies/dashboard
```

#### 🌐 Unity Catalog External Lineage

```http
# Registrar metadado externo
POST /api/v2/external-lineage/metadata
Content-Type: application/json

{
  "name": "customer_dashboard",
  "system_type": "tableau",
  "entity_type": "dashboard",
  "external_url": "https://tableau.empresa.com/dashboard/customers"
}

# Sincronizar com Unity Catalog
POST /api/v2/external-lineage/metadata/{metadata_id}/sync
```

## 🌍 Multi-Tenancy Geográfico

### Configurações por País

| País | Código | Formato Data | Moeda | Regulamentação |
|------|--------|--------------|-------|----------------|
| Brasil | BR | dd/MM/yyyy | R$ | LGPD |
| Estados Unidos | US | MM/dd/yyyy | $ | CCPA |
| União Europeia | EU | dd.MM.yyyy | € | GDPR |
| Reino Unido | GB | dd/MM/yyyy | £ | DPA |
| Canadá | CA | yyyy-MM-dd | C$ | PIPEDA |

### Headers Importantes

```http
X-Country-Code: BR
X-Tenant-ID: empresa-brasil
X-API-Version: 2.0.0
Authorization: Bearer <jwt_token>
```

## 🔄 Versionamento da API

### Versões Suportadas

- **v1.0**: Funcionalidades básicas (manutenção)
- **v2.0**: Funcionalidades avançadas (estável) ⭐
- **v3.0**: Funcionalidades experimentais (beta)

### Migração entre Versões

```http
# Solicitar migração
POST /api/v2/contracts/{contract_id}/migrate
Content-Type: application/json

{
  "target_version": "2.1.0",
  "migration_strategy": "backward_compatible"
}
```

## 🤖 Machine Learning

### Algoritmos Disponíveis

#### Detecção de Anomalias

- **Isolation Forest**: Detecção de outliers estatísticos
- **LSTM Autoencoder**: Anomalias temporais e padrões
- **Z-Score**: Desvios estatísticos simples
- **Ensemble**: Combinação de múltiplos algoritmos

#### Configuração de Modelos

```python
# Exemplo de configuração
anomaly_config = {
    "model_type": "isolation_forest",
    "parameters": {
        "contamination": 0.1,
        "n_estimators": 100,
        "random_state": 42
    },
    "training_schedule": "weekly",
    "threshold": 0.8
}
```

## 📊 Monitoramento e Observabilidade

### Métricas Disponíveis

- **Performance**: Latência, throughput, taxa de erro
- **Qualidade**: Scores de qualidade, anomalias detectadas
- **Uso**: Usuários ativos, endpoints mais usados
- **Compliance**: Status de políticas, violações

### Health Checks

```http
GET /health
```

```json
{
  "status": "healthy",
  "components": {
    "database": {"status": "healthy", "response_time_ms": 45},
    "redis": {"status": "healthy", "response_time_ms": 2},
    "unity_catalog": {"status": "healthy", "response_time_ms": 1250}
  }
}
```

## 🛡️ Segurança e Compliance

### Recursos de Segurança

- **Autenticação JWT**: Tokens seguros com expiração
- **RBAC**: Controle de acesso baseado em roles
- **Rate Limiting**: Proteção contra abuso
- **Audit Log**: Log completo de todas as ações
- **Encryption**: Dados sensíveis criptografados

### Compliance Regulatório

#### LGPD (Brasil)
- Identificação automática de dados pessoais
- Controles de consentimento
- Relatórios de conformidade
- Direito ao esquecimento

#### GDPR (União Europeia)
- Data Protection Impact Assessment (DPIA)
- Privacy by Design
- Portabilidade de dados
- Notificação de violações

## 🔧 Configuração

### Variáveis de Ambiente

```bash
# Database
DATABASE_URL=postgresql://user:pass@localhost:5432/governance
REDIS_URL=redis://localhost:6379/0

# Security
SECRET_KEY=your-secret-key
JWT_SECRET_KEY=your-jwt-secret

# Unity Catalog
UNITY_CATALOG_URL=https://databricks.empresa.com
UNITY_CATALOG_TOKEN=your-token

# Monitoring
PROMETHEUS_METRICS=true
LOG_LEVEL=INFO
```

### Configuração por Ambiente

```python
# config/environments/production.py
class ProductionConfig(Config):
    DEBUG = False
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL')
    REDIS_URL = os.environ.get('REDIS_URL')
    
    # Security
    SESSION_COOKIE_SECURE = True
    SESSION_COOKIE_HTTPONLY = True
    
    # Performance
    SQLALCHEMY_ENGINE_OPTIONS = {
        'pool_size': 20,
        'pool_recycle': 3600,
        'pool_pre_ping': True
    }
```

## 🧪 Testes

### Executar Testes

```bash
# Todos os testes
pytest

# Testes específicos
pytest tests/test_contracts.py
pytest tests/test_quality.py

# Com cobertura
pytest --cov=src --cov-report=html
```

### Estrutura de Testes

```
tests/
├── unit/                 # Testes unitários
├── integration/          # Testes de integração
├── api/                  # Testes de API
├── performance/          # Testes de performance
└── fixtures/             # Dados de teste
```

## 📈 Performance

### Benchmarks

| Endpoint | Latência Média | Throughput | Cache Hit Rate |
|----------|----------------|------------|----------------|
| GET /contracts | 45ms | 1000 req/s | 85% |
| POST /quality/execute | 2.3s | 50 req/s | N/A |
| GET /lineage/graph | 150ms | 200 req/s | 70% |
| GET /anomalies | 80ms | 500 req/s | 90% |

### Otimizações

- **Cache Redis**: Cache inteligente com TTL configurável
- **Índices Database**: Índices otimizados para queries frequentes
- **Connection Pooling**: Pool de conexões para melhor performance
- **Async Processing**: Processamento assíncrono para operações pesadas

## 🤝 Contribuição

### Padrões de Código

- **PEP 8**: Estilo de código Python
- **Type Hints**: Tipagem estática
- **Docstrings**: Documentação de funções
- **Tests**: Cobertura mínima de 80%

### Processo de Desenvolvimento

1. Fork do repositório
2. Criar branch feature (`git checkout -b feature/nova-funcionalidade`)
3. Commit das mudanças (`git commit -am 'Adiciona nova funcionalidade'`)
4. Push para branch (`git push origin feature/nova-funcionalidade`)
5. Criar Pull Request

## 📞 Suporte

### Canais de Suporte

- **Email**: gdp-core-support@tbr.com
- **Slack**: #gdp-core-support
- **Documentação**: [Wiki Interno](https://wiki.tbr.com/gdp-core)
- **Issues**: [GitHub Issues](https://github.com/tbr/gdp-core-api/issues)

### SLA

- **Crítico**: 2 horas
- **Alto**: 8 horas
- **Médio**: 24 horas
- **Baixo**: 72 horas

## 📄 Licença

Este projeto é propriedade da TBR e está licenciado sob termos proprietários. Veja o arquivo [LICENSE](LICENSE) para detalhes.

## 🔄 Changelog

### v3.0.0 (2025-07-01)
- ✨ Unity Catalog External Lineage completo
- ✨ Multi-tenancy geográfico
- ✨ Versionamento avançado da API
- ✨ Machine Learning para detecção de anomalias
- 🐛 Correções de performance
- 📚 Documentação Swagger completa

### v2.0.0 (2025-01-01)
- ✨ Contratos de dados com versionamento
- ✨ Sistema de qualidade avançado
- ✨ Linhagem de dados automática
- ✨ Compliance LGPD/GDPR

### v1.0.0 (2024-06-01)
- 🎉 Lançamento inicial
- ✨ Funcionalidades básicas de governança

---

**Desenvolvido com ❤️ pela equipe TBR GDP Core**

*Para mais informações, acesse nossa [documentação completa](docs/) ou entre em contato com a equipe de suporte.*

