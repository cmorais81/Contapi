"""
COBOL AI Engine v2.0.0 - Completeness Analyzer
Analisador de completude para garantir que todos os programas sejam processados.
"""

import logging
import os
from typing import Dict, List, Set, Any, Optional, Tuple
from datetime import datetime
from dataclasses import dataclass

try:
    from ..parsers.cobol_parser import CobolProgram, CobolBook
except ImportError:
    from parsers.cobol_parser import CobolProgram, CobolBook


@dataclass
class ProgramStatus:
    """Status de processamento de um programa."""
    name: str
    found: bool = False
    parsed: bool = False
    analyzed: bool = False
    documented: bool = False
    error_message: Optional[str] = None
    file_path: Optional[str] = None
    size: int = 0
    line_count: int = 0


@dataclass
class DependencyInfo:
    """Informações de dependência entre programas."""
    source_program: str
    target_program: str
    dependency_type: str  # 'CALL', 'COPY', 'INCLUDE', 'JCL', 'FILE'
    line_number: Optional[int] = None
    context: Optional[str] = None


class CompletenessAnalyzer:
    """
    Analisador de completude para garantir processamento completo de todos os programas.
    
    Funcionalidades:
    - Verificação de completude de processamento
    - Análise de dependências entre programas
    - Identificação de programas não processados
    - Relatório de status detalhado
    """
    
    def __init__(self):
        """Inicializa o analisador de completude."""
        self.logger = logging.getLogger(__name__)
        self.program_statuses: Dict[str, ProgramStatus] = {}
        self.dependencies: List[DependencyInfo] = []
        self.missing_programs: Set[str] = set()
        self.analysis_timestamp = datetime.now()
        
        self.logger.info("Completeness Analyzer inicializado")
    
    def load_expected_programs(self, fontes_file: str) -> List[str]:
        """
        Carrega lista de programas esperados do arquivo fontes.txt.
        
        Args:
            fontes_file: Caminho para arquivo fontes.txt
            
        Returns:
            Lista de nomes de programas esperados
        """
        expected_programs = []
        
        try:
            if not os.path.exists(fontes_file):
                self.logger.error(f"Arquivo fontes não encontrado: {fontes_file}")
                return expected_programs
            
            with open(fontes_file, 'r', encoding='utf-8') as f:
                for line_num, line in enumerate(f, 1):
                    line = line.strip()
                    if line and not line.startswith('#'):
                        # Extrair nome do programa da linha
                        program_name = self._extract_program_name(line)
                        if program_name:
                            expected_programs.append(program_name)
                            # Inicializar status
                            self.program_statuses[program_name] = ProgramStatus(
                                name=program_name,
                                file_path=line
                            )
            
            self.logger.info(f"Carregados {len(expected_programs)} programas esperados de {fontes_file}")
            return expected_programs
            
        except Exception as e:
            self.logger.error(f"Erro ao carregar programas esperados: {e}")
            return expected_programs
    
    def _extract_program_name(self, file_path: str) -> Optional[str]:
        """
        Extrai nome do programa de um caminho de arquivo.
        
        Args:
            file_path: Caminho do arquivo
            
        Returns:
            Nome do programa ou None
        """
        try:
            # Extrair nome do arquivo sem extensão
            filename = os.path.basename(file_path)
            name_without_ext = os.path.splitext(filename)[0]
            
            # Limpar caracteres especiais e converter para maiúsculo
            program_name = name_without_ext.upper().strip()
            
            return program_name if program_name else None
            
        except Exception as e:
            self.logger.warning(f"Erro ao extrair nome do programa de {file_path}: {e}")
            return None
    
    def update_program_status(self, program_name: str, status_field: str, 
                            value: Any = True, error_message: str = None) -> None:
        """
        Atualiza status de processamento de um programa.
        
        Args:
            program_name: Nome do programa
            status_field: Campo de status a atualizar
            value: Valor a definir
            error_message: Mensagem de erro se aplicável
        """
        if program_name not in self.program_statuses:
            self.program_statuses[program_name] = ProgramStatus(name=program_name)
        
        status = self.program_statuses[program_name]
        
        if hasattr(status, status_field):
            setattr(status, status_field, value)
        
        if error_message:
            status.error_message = error_message
        
        self.logger.debug(f"Status atualizado para {program_name}: {status_field}={value}")
    
    def mark_program_found(self, program_name: str, file_path: str, 
                          size: int = 0, line_count: int = 0) -> None:
        """Marca programa como encontrado."""
        self.update_program_status(program_name, 'found', True)
        if program_name in self.program_statuses:
            self.program_statuses[program_name].file_path = file_path
            self.program_statuses[program_name].size = size
            self.program_statuses[program_name].line_count = line_count
    
    def mark_program_parsed(self, program_name: str) -> None:
        """Marca programa como parseado."""
        self.update_program_status(program_name, 'parsed', True)
    
    def mark_program_analyzed(self, program_name: str) -> None:
        """Marca programa como analisado."""
        self.update_program_status(program_name, 'analyzed', True)
    
    def mark_program_documented(self, program_name: str) -> None:
        """Marca programa como documentado."""
        self.update_program_status(program_name, 'documented', True)
    
    def mark_program_error(self, program_name: str, error_message: str) -> None:
        """Marca programa com erro."""
        self.update_program_status(program_name, 'error_message', error_message)
    
    def analyze_dependencies(self, programs: List[CobolProgram], 
                           copybooks: List[CobolBook] = None) -> None:
        """
        Analisa dependências entre programas.
        
        Args:
            programs: Lista de programas COBOL
            copybooks: Lista de copybooks (opcional)
        """
        self.logger.info("Iniciando análise de dependências")
        
        for program in programs:
            self._analyze_program_dependencies(program)
        
        if copybooks:
            for copybook in copybooks:
                self._analyze_copybook_dependencies(copybook)
        
        self.logger.info(f"Análise de dependências concluída: {len(self.dependencies)} dependências encontradas")
    
    def _analyze_program_dependencies(self, program: CobolProgram) -> None:
        """Analisa dependências de um programa específico."""
        content = program.content.upper()
        lines = content.split('\n')
        
        for line_num, line in enumerate(lines, 1):
            line = line.strip()
            
            # Analisar CALL statements
            if 'CALL' in line and not line.startswith('*'):
                called_program = self._extract_called_program(line)
                if called_program:
                    self.dependencies.append(DependencyInfo(
                        source_program=program.name,
                        target_program=called_program,
                        dependency_type='CALL',
                        line_number=line_num,
                        context=line[:100]
                    ))
            
            # Analisar COPY statements
            if 'COPY' in line and not line.startswith('*'):
                copied_book = self._extract_copied_book(line)
                if copied_book:
                    self.dependencies.append(DependencyInfo(
                        source_program=program.name,
                        target_program=copied_book,
                        dependency_type='COPY',
                        line_number=line_num,
                        context=line[:100]
                    ))
            
            # Analisar referências a arquivos
            if any(keyword in line for keyword in ['SELECT', 'ASSIGN', 'FD']) and not line.startswith('*'):
                file_ref = self._extract_file_reference(line)
                if file_ref:
                    self.dependencies.append(DependencyInfo(
                        source_program=program.name,
                        target_program=file_ref,
                        dependency_type='FILE',
                        line_number=line_num,
                        context=line[:100]
                    ))
    
    def _analyze_copybook_dependencies(self, copybook: CobolBook) -> None:
        """Analisa dependências de um copybook."""
        content = copybook.content.upper()
        lines = content.split('\n')
        
        for line_num, line in enumerate(lines, 1):
            line = line.strip()
            
            # Analisar COPY statements em copybooks
            if 'COPY' in line and not line.startswith('*'):
                copied_book = self._extract_copied_book(line)
                if copied_book:
                    self.dependencies.append(DependencyInfo(
                        source_program=copybook.name,
                        target_program=copied_book,
                        dependency_type='COPY',
                        line_number=line_num,
                        context=line[:100]
                    ))
    
    def _extract_called_program(self, line: str) -> Optional[str]:
        """Extrai nome do programa chamado de uma linha CALL."""
        try:
            # Padrões comuns: CALL 'PROGRAM', CALL "PROGRAM", CALL PROGRAM
            import re
            
            # Buscar por CALL seguido de string literal
            match = re.search(r'CALL\s+[\'"]([^\'\"]+)[\'"]', line)
            if match:
                return match.group(1).strip()
            
            # Buscar por CALL seguido de variável
            match = re.search(r'CALL\s+([A-Z0-9\-]+)', line)
            if match:
                called = match.group(1).strip()
                # Filtrar palavras reservadas
                if called not in ['USING', 'GIVING', 'ON', 'OVERFLOW']:
                    return called
            
            return None
            
        except Exception as e:
            self.logger.debug(f"Erro ao extrair programa chamado de '{line}': {e}")
            return None
    
    def _extract_copied_book(self, line: str) -> Optional[str]:
        """Extrai nome do copybook de uma linha COPY."""
        try:
            import re
            
            # Padrões: COPY BOOK, COPY 'BOOK', COPY "BOOK"
            match = re.search(r'COPY\s+[\'"]?([A-Z0-9\-]+)[\'"]?', line)
            if match:
                return match.group(1).strip()
            
            return None
            
        except Exception as e:
            self.logger.debug(f"Erro ao extrair copybook de '{line}': {e}")
            return None
    
    def _extract_file_reference(self, line: str) -> Optional[str]:
        """Extrai referência de arquivo de uma linha."""
        try:
            import re
            
            # Buscar por ASSIGN TO
            match = re.search(r'ASSIGN\s+TO\s+[\'"]?([A-Z0-9\-]+)[\'"]?', line)
            if match:
                return match.group(1).strip()
            
            # Buscar por FD
            match = re.search(r'FD\s+([A-Z0-9\-]+)', line)
            if match:
                return match.group(1).strip()
            
            return None
            
        except Exception as e:
            self.logger.debug(f"Erro ao extrair referência de arquivo de '{line}': {e}")
            return None
    
    def get_completeness_report(self) -> Dict[str, Any]:
        """
        Gera relatório de completude do processamento.
        
        Returns:
            Dicionário com relatório de completude
        """
        total_programs = len(self.program_statuses)
        found_count = sum(1 for s in self.program_statuses.values() if s.found)
        parsed_count = sum(1 for s in self.program_statuses.values() if s.parsed)
        analyzed_count = sum(1 for s in self.program_statuses.values() if s.analyzed)
        documented_count = sum(1 for s in self.program_statuses.values() if s.documented)
        error_count = sum(1 for s in self.program_statuses.values() if s.error_message)
        
        # Identificar programas não processados
        not_found = [s.name for s in self.program_statuses.values() if not s.found]
        not_parsed = [s.name for s in self.program_statuses.values() if s.found and not s.parsed]
        not_analyzed = [s.name for s in self.program_statuses.values() if s.parsed and not s.analyzed]
        not_documented = [s.name for s in self.program_statuses.values() if s.analyzed and not s.documented]
        with_errors = [s.name for s in self.program_statuses.values() if s.error_message]
        
        return {
            'timestamp': self.analysis_timestamp.isoformat(),
            'summary': {
                'total_programs': total_programs,
                'found': found_count,
                'parsed': parsed_count,
                'analyzed': analyzed_count,
                'documented': documented_count,
                'errors': error_count,
                'completeness_percentage': (documented_count / max(total_programs, 1)) * 100
            },
            'missing_programs': {
                'not_found': not_found,
                'not_parsed': not_parsed,
                'not_analyzed': not_analyzed,
                'not_documented': not_documented,
                'with_errors': with_errors
            },
            'dependencies': {
                'total_dependencies': len(self.dependencies),
                'by_type': self._group_dependencies_by_type(),
                'dependency_list': [
                    {
                        'source': dep.source_program,
                        'target': dep.target_program,
                        'type': dep.dependency_type,
                        'line': dep.line_number,
                        'context': dep.context
                    }
                    for dep in self.dependencies
                ]
            },
            'program_details': {
                name: {
                    'found': status.found,
                    'parsed': status.parsed,
                    'analyzed': status.analyzed,
                    'documented': status.documented,
                    'error': status.error_message,
                    'file_path': status.file_path,
                    'size': status.size,
                    'line_count': status.line_count
                }
                for name, status in self.program_statuses.items()
            }
        }
    
    def _group_dependencies_by_type(self) -> Dict[str, int]:
        """Agrupa dependências por tipo."""
        type_counts = {}
        for dep in self.dependencies:
            type_counts[dep.dependency_type] = type_counts.get(dep.dependency_type, 0) + 1
        return type_counts
    
    def get_missing_programs(self) -> List[str]:
        """Retorna lista de programas não processados completamente."""
        missing = []
        for name, status in self.program_statuses.items():
            if not status.documented and not status.error_message:
                missing.append(name)
        return missing
    
    def get_dependency_graph(self) -> Dict[str, List[str]]:
        """
        Retorna grafo de dependências.
        
        Returns:
            Dicionário onde chave é programa e valor é lista de dependências
        """
        graph = {}
        
        for dep in self.dependencies:
            if dep.source_program not in graph:
                graph[dep.source_program] = []
            graph[dep.source_program].append(dep.target_program)
        
        return graph
    
    def validate_all_programs_processed(self) -> Tuple[bool, List[str]]:
        """
        Valida se todos os programas foram processados completamente.
        
        Returns:
            Tupla (sucesso, lista_de_problemas)
        """
        problems = []
        
        for name, status in self.program_statuses.items():
            if not status.found:
                problems.append(f"Programa não encontrado: {name}")
            elif not status.parsed:
                problems.append(f"Programa não parseado: {name}")
            elif not status.analyzed:
                problems.append(f"Programa não analisado: {name}")
            elif not status.documented:
                problems.append(f"Programa não documentado: {name}")
            elif status.error_message:
                problems.append(f"Programa com erro: {name} - {status.error_message}")
        
        success = len(problems) == 0
        return success, problems

