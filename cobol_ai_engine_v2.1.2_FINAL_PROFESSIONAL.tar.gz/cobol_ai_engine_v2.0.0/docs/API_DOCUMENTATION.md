# COBOL AI Engine v2.0.0 - Documentação da API

**Data:** 13/09/2025

## Visão Geral

A API do COBOL AI Engine v2.0.0 foi projetada para ser simples, flexível e poderosa. Ela permite que você integre a análise de código COBOL em seus próprios scripts Python, notebooks Jupyter ou qualquer outra aplicação.

## Formas de Uso

Existem três formas principais de usar o COBOL AI Engine:

1. **CLI Interativo:** Interface de linha de comando amigável para uso rápido.
2. **API Programática:** Módulo Python para integração em notebooks e scripts.
3. **CLI Clássico:** Interface de linha de comando original para automação.

## 1. CLI Interativo (`cli_interactive.py`)

O CLI interativo é a forma mais fácil de começar a usar o COBOL AI Engine. Ele oferece um menu guiado para todas as funcionalidades principais.

### Como Usar

```bash
# Navegar para o diretório
cd cobol_ai_engine_v2.0.0

# Executar o CLI interativo
python3 cli_interactive.py
```

### Funcionalidades

- **Análise de Código:** Digite ou cole código COBOL diretamente.
- **Análise de Arquivos:** Analise arquivos COBOL individuais ou múltiplos.
- **Análise de Diretório:** Analise todos os arquivos COBOL em um diretório.
- **Configuração de Provedor:** Alterne facilmente entre provedores de IA.
- **Status dos Provedores:** Verifique quais provedores estão disponíveis.
- **Configurações Avançadas:** Ajuste timeout, max tokens e veja logs.
- **Ajuda Integrada:** Guia rápido com exemplos de uso.

### Exemplo de Sessão

```
============================================================
    COBOL AI Engine v2.0.0 - Interface Interativa
============================================================

Opções Disponíveis:
1. Analisar código COBOL (digitar/colar)
2. Analisar arquivo COBOL
3. Analisar múltiplos arquivos
4. Analisar diretório
5. Configurar provedor de IA
6. Ver status dos provedores
7. Gerar relatório consolidado
8. Configurações avançadas
9. Ajuda e exemplos
0. Sair

Escolha uma opção (0-9): 2

--- Análise de Arquivo COBOL ---
Caminho do arquivo: examples/programa1.cbl

 Analisando arquivo 'examples/programa1.cbl'...

============================================================
RESULTADO DA ANÁLISE
============================================================
 Programa: programa1
🤖 Provedor: enhanced_mock

 DOCUMENTAÇÃO:
----------------------------------------
## Análise Geral do Programa
### Resumo Executivo
Este programa COBOL implementa funcionalidades específicas...

============================================================

Deseja salvar o resultado? (s/N): s
 Resultado salvo em: programa1_analise.md
```

## 2. API Programática (`cobol_ai_engine.py`)

A API programática é a forma mais poderosa de usar o COBOL AI Engine. Ela permite que você integre a análise de código em seus próprios fluxos de trabalho.

### Como Usar

```python
# Importar o módulo
import cobol_ai_engine as cae

# Guia rápido
cae.quick_start_guide()

# Listar provedores
cae.list_providers()
```

### Funções de Conveniência

#### `analyze_cobol(cobol_code, provider="enhanced_mock")`
Analisa código COBOL fornecido como string.

```python
resultado = cae.analyze_cobol("...")
print(resultado["documentation"])
```

#### `analyze_cobol_file(file_path, provider="enhanced_mock")`
Analisa um arquivo COBOL.

```python
resultado = cae.analyze_cobol_file("meu_programa.cbl")
```

### Classe `COBOLAnalyzer`

Para uso avançado, a classe `COBOLAnalyzer` oferece controle total sobre o processo de análise.

#### Inicialização

```python
# Criar analisador com provedor específico
analyzer = cae.create_analyzer(provider="openai")
```

#### Métodos Principais

- `analyze_code(cobol_code, program_name)`: Analisa código como string.
- `analyze_file(file_path, program_name)`: Analisa um arquivo.
- `analyze_multiple_files(file_paths)`: Analisa múltiplos arquivos.
- `analyze_directory(directory_path, extensions)`: Analisa um diretório.
- `generate_report(results, output_path, format)`: Gera relatório.
- `get_available_providers()`: Lista provedores disponíveis.
- `get_provider_status()`: Retorna status dos provedores.
- `set_provider(provider_name)`: Altera o provedor de IA.
- `get_current_provider()`: Retorna o provedor atual.

### Exemplo de Workflow em Notebook

```python
# 1. Importar e criar analisador
import cobol_ai_engine as cae
analyzer = cae.create_analyzer(provider="enhanced_mock")

# 2. Analisar diretório
resultados = analyzer.analyze_directory("examples")

# 3. Gerar relatório PDF
sucesso = analyzer.generate_report(resultados, "relatorio.pdf", format="pdf")

if sucesso:
    print(" Relatório gerado com sucesso!")
```

## 3. CLI Clássico (`main.py`)

O CLI clássico é a interface de linha de comando original, ideal para automação e scripts.

### Como Usar

```bash
# Navegar para o diretório
cd cobol_ai_engine_v2.0.0

# Ver ajuda
python3 main.py --help
```

### Principais Comandos

#### Status do Sistema
```bash
python3 main.py --status
```

#### Análise de Arquivo Único
```bash
python3 main.py --fontes examples/programa1.cbl --output output_dir
```

#### Análise de Múltiplos Arquivos
```bash
python3 main.py --fontes examples/fontes.txt --output output_dir
```

#### Análise de Diretório
```bash
python3 main.py --diretorio examples --output output_dir
```

#### Usar Configuração Específica
```bash
python3 main.py --config config/config_openai.yaml --status
```

#### Gerar Documentação Consolidada
```bash
python3 main.py --fontes examples/fontes.txt --output output_dir --consolidado
```

#### Gerar PDF
```bash
python3 main.py --fontes examples/fontes.txt --output output_dir --pdf
```

## Configuração de Provedores

Para usar provedores de IA reais, você precisa configurar as credenciais como variáveis de ambiente.

### OpenAI
```bash
export OPENAI_API_KEY="sua_chave_api_aqui"
```

### Databricks
```bash
export DATABRICKS_WORKSPACE_URL="sua_url_workspace"
export DATABRICKS_ACCESS_TOKEN="seu_token_de_acesso"
```

### AWS Bedrock
```bash
export AWS_ACCESS_KEY_ID="sua_chave_de_acesso"
export AWS_SECRET_ACCESS_KEY="sua_chave_secreta"
export AWS_REGION="sua_regiao_aws"
```

## Conclusão

O COBOL AI Engine v2.0.0 oferece múltiplas formas de uso para atender a diferentes necessidades. Seja para uma análise rápida no CLI interativo, integração em notebooks com a API programática ou automação com o CLI clássico, você tem total controle sobre o processo de análise de código COBOL.

Para mais detalhes, consulte os exemplos de código nos diretórios `examples/` e `docs/`.

