"""
COBOL AI Engine v1.3.0 - Documentation Generator
Gerador completo de documentação com suporte a faseamento e múltiplos formatos.
"""

import logging
import os
from typing import Dict, Any, List, Optional
from datetime import datetime

from ..parsers.cobol_parser import CobolProgram, CobolBook
from ..providers.base_provider import AIResponse


class DocumentationGenerator:
    """
    Gerador de documentação completo para programas COBOL.
    
    Funcionalidades:
    - Geração de documentação individual por programa
    - Relatório consolidado
    - Suporte a metadados de faseamento
    - Múltiplos formatos de saída
    - Estatísticas detalhadas
    """
    
    def __init__(self, output_dir: str = "output"):
        """
        Inicializa o gerador de documentação.
        
        Args:
            output_dir: Diretório de saída
        """
        self.output_dir = output_dir
        self.logger = logging.getLogger(__name__)
        
        # Criar diretório de saída
        os.makedirs(output_dir, exist_ok=True)
        
        # Estatísticas
        self.files_generated = 0
        self.total_programs = 0
        self.total_books = 0
        
        self.logger.info(f"Documentation Generator inicializado - Output: {output_dir}")
    
    def generate_program_documentation(self, program: CobolProgram, 
                                     ai_response: AIResponse,
                                     phase_info: Optional[Dict[str, Any]] = None) -> str:
        """
        Gera documentação completa para um programa COBOL.
        
        Args:
            program: Programa COBOL analisado
            ai_response: Resposta da análise de IA
            phase_info: Informações de faseamento (opcional)
            
        Returns:
            Caminho do arquivo gerado
        """
        try:
            # Gerar conteúdo
            content = self._generate_program_content(program, ai_response, phase_info)
            
            # Salvar arquivo
            filename = f"{program.name}.md"
            filepath = os.path.join(self.output_dir, filename)
            
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)
            
            self.files_generated += 1
            self.total_programs += 1
            
            self.logger.info(f"Documentação gerada: {filename}")
            return filepath
            
        except Exception as e:
            self.logger.error(f"Erro ao gerar documentação para {program.name}: {e}")
            return ""
    
    def _generate_program_content(self, program: CobolProgram, 
                                ai_response: AIResponse,
                                phase_info: Optional[Dict[str, Any]] = None) -> str:
        """Gera conteúdo da documentação do programa."""
        
        # Obter documentação de prompts se disponível
        prompt_documentation = ""
        if hasattr(ai_response, 'prompt_manager') and ai_response.prompt_manager:
            prompt_documentation = ai_response.prompt_manager.get_prompt_documentation()
        
        # Obter prompts utilizados
        prompts_used = getattr(ai_response, 'prompts_used', {})
        
        content = f"""# Documentação Técnica e Funcional Completa: {program.name}

**Data de Geração**: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}
**Versão do Sistema**: COBOL AI Engine v1.3.0

## Resumo Executivo

**Nome do Programa:** {program.name}
**Tamanho do Código:** {program.size} caracteres ({program.line_count} linhas)
**Tipo de Componente:** {'Programa Principal' if 'PROGRAM-ID' in program.content else 'Copybook/Módulo'}
**Complexidade:** {'Alta' if program.line_count > 500 else 'Média' if program.line_count > 100 else 'Baixa'}

### Descrição Geral
Este documento apresenta uma análise técnica e funcional completa do componente COBOL {program.name}. 
A análise foi realizada utilizando inteligência artificial avançada para garantir compreensão profunda 
do código fonte, identificação de padrões, regras de negócio e relacionamentos com outros componentes 
do sistema. O objetivo é fornecer documentação clara e detalhada que facilite a manutenção, 
evolução e compreensão do sistema.

## Análise Detalhada Realizada pela IA

{ai_response.content}

{prompt_documentation}

## Informações Técnicas Detalhadas

### Características do Código Fonte
- **Total de Linhas:** {program.line_count} linhas
- **Tamanho em Caracteres:** {program.size} caracteres
- **Densidade de Código:** {len([line for line in program.content.split(chr(10)) if line.strip() and not line.strip().startswith('*')])} linhas efetivas
- **Linhas de Comentário:** {len([line for line in program.content.split(chr(10)) if line.strip().startswith('*')])} linhas
- **Percentual de Documentação:** {(len([line for line in program.content.split(chr(10)) if line.strip().startswith('*')]) / max(program.line_count, 1) * 100):.1f}%

### Estrutura Hierárquica do Programa

#### Divisões Identificadas"""
        
        # Adicionar divisões com mais detalhes
        if program.divisions:
            for division_name, division_content in program.divisions.items():
                lines_count = len(division_content.split(chr(10)))
                content += f"""
**{division_name} DIVISION**
- Linhas de código: {lines_count}
- Percentual do programa: {(lines_count / max(program.line_count, 1) * 100):.1f}%
- Função: {self._get_division_description(division_name)}
"""
        else:
            content += "\nEstrutura COBOL padrão detectada - análise detalhada realizada pela IA acima.\n"
        
        # Adicionar seções com mais detalhes
        content += "\n#### Seções Identificadas\n"
        if program.sections:
            content += f"Total de seções encontradas: {len(program.sections)}\n\n"
            for i, section in enumerate(program.sections[:15], 1):  # Limitar a 15
                content += f"{i}. **{section}**\n"
                content += f"   - Tipo: {self._get_section_type(section)}\n"
                content += f"   - Propósito: {self._get_section_purpose(section)}\n\n"
            if len(program.sections) > 15:
                content += f"... e mais {len(program.sections) - 15} seções adicionais\n"
        else:
            content += "Estrutura de seções analisada pela IA - detalhes na análise funcional acima.\n"
        
        # Adicionar variáveis com mais detalhes
        content += "\n#### Principais Variáveis e Estruturas de Dados\n"
        if program.variables:
            content += f"Total de variáveis identificadas: {len(program.variables)}\n\n"
            for i, variable in enumerate(program.variables[:20], 1):  # Limitar a 20
                content += f"{i}. **{variable}**\n"
                content += f"   - Categoria: {self._get_variable_category(variable)}\n"
                content += f"   - Uso estimado: {self._get_variable_usage(variable)}\n\n"
            if len(program.variables) > 20:
                content += f"... e mais {len(program.variables) - 20} variáveis adicionais\n"
        else:
            content += "Estruturas de dados analisadas pela IA - detalhes na análise técnica acima.\n"
        
        # Adicionar arquivos com mais detalhes
        content += "\n#### Arquivos e Recursos Utilizados\n"
        if program.files:
            content += f"Total de arquivos identificados: {len(program.files)}\n\n"
            for i, file_name in enumerate(program.files, 1):
                content += f"{i}. **{file_name}**\n"
                content += f"   - Tipo: {self._get_file_type(file_name)}\n"
                content += f"   - Função: {self._get_file_purpose(file_name)}\n\n"
        else:
            content += "Recursos e dependências analisados pela IA - detalhes na análise de relacionamentos acima.\n"
        
        # Adicionar informações de faseamento se disponível
        phase_content = ""
        if phase_info:
            phase_content = f"""
## Informações de Processamento Multi-Fase

**Número de Fases:** {phase_info.get('total_phases', 1)}
**Fase Atual:** {phase_info.get('current_phase', 1)}
**Tokens por Fase:** {phase_info.get('tokens_per_phase', 'N/A')}
**Estratégia de Divisão:** {phase_info.get('split_strategy', 'Automática baseada em tokens')}

### Detalhes do Faseamento
{phase_info.get('phase_details', 'Processamento realizado em fase única devido ao tamanho do programa.')}
"""
        
        # Adicionar seção de prompts utilizados
        prompts_section = ""
        if prompts_used and isinstance(prompts_used, dict):
            prompts_section = f"""
## Transparência e Auditoria

### Prompts Utilizados na Análise

#### Prompt Principal
```
{prompts_used.get('original_prompt', 'Prompt padrão de análise COBOL utilizado')}
```

#### Contexto do Sistema
```
{prompts_used.get('system_prompt', 'Contexto de análise técnica de programas COBOL')}
```

#### Informações do Programa
```
{prompts_used.get('context', f'Programa: {program.name}, Tamanho: {program.size} caracteres')}
```

#### Perguntas Específicas Realizadas
{chr(10).join([f'- {question}' for question in prompts_used.get('questions', ['Análise funcional', 'Estrutura técnica', 'Regras de negócio'])]) if prompts_used.get('questions') else '- Análise funcional completa realizada'}
"""
        
        # Adicionar metadados detalhados da análise
        content += f"""
{phase_content}

{prompts_section}

## Metadados Completos da Análise

### Informações do Processamento de IA
- **Provedor Utilizado:** {ai_response.provider}
- **Modelo de IA:** {ai_response.model}
- **Total de Tokens Processados:** {ai_response.tokens_used}
- **Timestamp da Análise:** {ai_response.timestamp}
- **Status do Processamento:** {getattr(ai_response, 'status', 'Concluído com sucesso')}
- **Tempo de Processamento:** {getattr(ai_response, 'processing_time', 'N/A')} segundos
- **Qualidade da Análise:** {'Excelente' if ai_response.tokens_used > 1000 else 'Boa' if ai_response.tokens_used > 500 else 'Básica'}

### Estatísticas de Análise
- **Profundidade da Análise:** {'Completa' if len(ai_response.content) > 2000 else 'Detalhada' if len(ai_response.content) > 1000 else 'Resumida'}
- **Cobertura do Código:** {'Total' if program.line_count < 1000 else 'Extensiva' if program.line_count < 2000 else 'Segmentada'}
- **Nível de Detalhamento:** {'Alto' if len(ai_response.content.split('.')) > 20 else 'Médio' if len(ai_response.content.split('.')) > 10 else 'Básico'}

### Metodologia Aplicada
A análise deste componente COBOL foi realizada seguindo uma metodologia estruturada que combina:

1. **Análise Estrutural Automatizada:** Identificação de divisões, seções, parágrafos e estruturas de dados
2. **Análise Semântica com IA:** Compreensão do propósito, funcionalidades e regras de negócio
3. **Análise de Contexto:** Identificação de relacionamentos e dependências
4. **Validação de Qualidade:** Verificação da consistência e completude da documentação gerada

### Limitações e Considerações Importantes
- Esta análise é baseada exclusivamente no código fonte fornecido
- Dependências externas e configurações de ambiente podem não estar refletidas
- Regras de negócio específicas podem requerer conhecimento adicional do domínio
- Para sistemas críticos, recomenda-se validação adicional com especialistas em COBOL
- A qualidade da análise está diretamente relacionada à clareza e documentação do código original

### Recomendações para Uso
- Utilize esta documentação como base para compreensão do componente
- Complemente com conhecimento específico do negócio quando necessário
- Mantenha esta documentação atualizada conforme evoluções do código
- Considere esta análise como ponto de partida para modernização ou migração

---
**Documentação gerada automaticamente pelo COBOL AI Engine v1.3.0**
**Sistema de Análise Inteligente de Programas COBOL**
**Data de Geração:** {datetime.now().strftime('%d/%m/%Y às %H:%M:%S')}
**Qualidade:** Análise Detalhada e Transparente
"""
        
        return content
    
    def _get_division_description(self, division_name: str) -> str:
        """Retorna descrição da divisão COBOL."""
        descriptions = {
            "IDENTIFICATION": "Identificação do programa e metadados",
            "ENVIRONMENT": "Configuração do ambiente e recursos",
            "DATA": "Definição de estruturas de dados e variáveis",
            "PROCEDURE": "Lógica principal e procedimentos do programa"
        }
        return descriptions.get(division_name.upper(), "Divisão específica do programa")
    
    def _get_section_type(self, section_name: str) -> str:
        """Identifica o tipo da seção."""
        section_upper = section_name.upper()
        if "INPUT-OUTPUT" in section_upper:
            return "Configuração de E/S"
        elif "FILE-CONTROL" in section_upper:
            return "Controle de Arquivos"
        elif "WORKING-STORAGE" in section_upper:
            return "Área de Trabalho"
        elif "LINKAGE" in section_upper:
            return "Interface Externa"
        else:
            return "Seção Procedimental"
    
    def _get_section_purpose(self, section_name: str) -> str:
        """Retorna o propósito da seção."""
        section_upper = section_name.upper()
        if "INPUT-OUTPUT" in section_upper:
            return "Define configurações de entrada e saída"
        elif "FILE-CONTROL" in section_upper:
            return "Especifica arquivos utilizados pelo programa"
        elif "WORKING-STORAGE" in section_upper:
            return "Declara variáveis de trabalho e constantes"
        elif "LINKAGE" in section_upper:
            return "Define interface com programas externos"
        else:
            return "Contém lógica de processamento"
    
    def _get_variable_category(self, variable_name: str) -> str:
        """Categoriza a variável baseada no nome."""
        var_upper = variable_name.upper()
        if var_upper.startswith('WS-'):
            return "Variável de Working Storage"
        elif var_upper.startswith('LS-'):
            return "Variável de Linkage Section"
        elif var_upper.startswith('FD-'):
            return "Descrição de Arquivo"
        elif any(prefix in var_upper for prefix in ['CNT-', 'CONT-', 'COUNT']):
            return "Contador"
        elif any(prefix in var_upper for prefix in ['SW-', 'FLAG-', 'IND-']):
            return "Indicador/Flag"
        else:
            return "Variável de Dados"
    
    def _get_variable_usage(self, variable_name: str) -> str:
        """Estima o uso da variável."""
        var_upper = variable_name.upper()
        if any(word in var_upper for word in ['ERRO', 'ERROR']):
            return "Tratamento de erros"
        elif any(word in var_upper for word in ['TOTAL', 'SUM', 'SOMA']):
            return "Acumulação/Totalização"
        elif any(word in var_upper for word in ['DATA', 'DATE']):
            return "Manipulação de datas"
        elif any(word in var_upper for word in ['NOME', 'NAME']):
            return "Armazenamento de nomes"
        else:
            return "Processamento geral"
    
    def _get_file_type(self, file_name: str) -> str:
        """Identifica o tipo do arquivo."""
        file_upper = file_name.upper()
        if any(ext in file_upper for ext in ['.DAT', '.DATA']):
            return "Arquivo de Dados"
        elif any(ext in file_upper for ext in ['.TXT', '.TEXT']):
            return "Arquivo Texto"
        elif any(ext in file_upper for ext in ['.IDX', '.INDEX']):
            return "Arquivo Indexado"
        elif any(word in file_upper for word in ['ENTRADA', 'INPUT']):
            return "Arquivo de Entrada"
        elif any(word in file_upper for word in ['SAIDA', 'OUTPUT']):
            return "Arquivo de Saída"
        else:
            return "Arquivo de Sistema"
    
    def _get_file_purpose(self, file_name: str) -> str:
        """Determina o propósito do arquivo."""
        file_upper = file_name.upper()
        if any(word in file_upper for word in ['LOG', 'AUDIT']):
            return "Registro de auditoria"
        elif any(word in file_upper for word in ['ERRO', 'ERROR']):
            return "Registro de erros"
        elif any(word in file_upper for word in ['RELAT', 'REPORT']):
            return "Geração de relatórios"
        elif any(word in file_upper for word in ['TEMP', 'TMP']):
            return "Arquivo temporário"
        else:
            return "Processamento de dados"

    def generate_book_documentation(self, book: CobolBook, 
                                  ai_response: AIResponse) -> str:
        """
        Gera documentação para um copybook COBOL.
        
        Args:
            book: Copybook COBOL analisado
            ai_response: Resposta da análise de IA
            
        Returns:
            Caminho do arquivo gerado
        """
        try:
            # Gerar conteúdo
            content = self._generate_book_content(book, ai_response)
            
            # Salvar arquivo
            filename = f"{book.name}_COPYBOOK.md"
            filepath = os.path.join(self.output_dir, filename)
            
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)
            
            self.files_generated += 1
            self.total_books += 1
            
            self.logger.info(f"Documentação de copybook gerada: {filename}")
            return filepath
            
        except Exception as e:
            self.logger.error(f"Erro ao gerar documentação para copybook {book.name}: {e}")
            return ""
    
    def _generate_book_content(self, book: CobolBook, ai_response: AIResponse) -> str:
        """Gera conteúdo da documentação do copybook."""
        
        # Obter prompts utilizados
        prompts_used = getattr(ai_response, 'prompts_used', {})
        
        content = f"""# Documentação de Copybook: {book.name}

**Data de Geração**: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}
**Versão do Sistema**: COBOL AI Engine v1.3.0

## Resumo Executivo

**Nome do Copybook:** {book.name}
**Tamanho do Código:** {book.size} caracteres ({book.line_count} linhas)
**Tipo de Componente:** Copybook/Biblioteca de Definições
**Complexidade:** {'Alta' if book.line_count > 200 else 'Média' if book.line_count > 50 else 'Baixa'}

### Descrição Geral
Este documento apresenta uma análise técnica completa do copybook COBOL {book.name}. 
Copybooks são componentes fundamentais em sistemas COBOL, contendo definições de dados, 
estruturas e constantes reutilizáveis por múltiplos programas. Esta análise identifica 
as estruturas definidas, seu propósito e como podem ser utilizadas em programas COBOL.

## Análise Detalhada do Copybook

{ai_response.content}

## Informações Técnicas Detalhadas

### Características do Copybook
- **Total de Linhas:** {book.line_count} linhas
- **Tamanho em Caracteres:** {book.size} caracteres
- **Densidade de Código:** {len([line for line in book.content.split(chr(10)) if line.strip() and not line.strip().startswith('*')])} linhas efetivas
- **Linhas de Comentário:** {len([line for line in book.content.split(chr(10)) if line.strip().startswith('*')])} linhas
- **Percentual de Documentação:** {(len([line for line in book.content.split(chr(10)) if line.strip().startswith('*')]) / max(book.line_count, 1) * 100):.1f}%

### Estruturas Definidas

#### Principais Definições de Dados"""
        
        # Adicionar variáveis do copybook
        if book.variables:
            content += f"\nTotal de definições encontradas: {len(book.variables)}\n\n"
            for i, variable in enumerate(book.variables[:25], 1):  # Limitar a 25
                content += f"{i}. **{variable}**\n"
                content += f"   - Categoria: {self._get_variable_category(variable)}\n"
                content += f"   - Uso típico: {self._get_variable_usage(variable)}\n\n"
            if len(book.variables) > 25:
                content += f"... e mais {len(book.variables) - 25} definições adicionais\n"
        else:
            content += "\nDefinições de dados analisadas pela IA - detalhes na análise técnica acima.\n"
        
        # Adicionar seção de prompts utilizados
        prompts_section = ""
        if prompts_used and isinstance(prompts_used, dict):
            prompts_section = f"""
## Transparência e Auditoria

### Prompts Utilizados na Análise

#### Prompt Principal
```
{prompts_used.get('original_prompt', 'Prompt padrão de análise de copybook COBOL utilizado')}
```

#### Contexto do Sistema
```
{prompts_used.get('system_prompt', 'Contexto de análise técnica de copybooks COBOL')}
```

#### Informações do Copybook
```
{prompts_used.get('context', f'Copybook: {book.name}, Tamanho: {book.size} caracteres')}
```
"""
        
        content += f"""
{prompts_section}

## Metadados da Análise

### Informações do Processamento de IA
- **Provedor Utilizado:** {ai_response.provider}
- **Modelo de IA:** {ai_response.model}
- **Total de Tokens Processados:** {ai_response.tokens_used}
- **Timestamp da Análise:** {ai_response.timestamp}
- **Status do Processamento:** {getattr(ai_response, 'status', 'Concluído com sucesso')}
- **Qualidade da Análise:** {'Excelente' if ai_response.tokens_used > 500 else 'Boa' if ai_response.tokens_used > 200 else 'Básica'}

### Uso Recomendado
- **Inclusão em Programas:** COPY {book.name}
- **Propósito Principal:** {self._get_copybook_purpose(book.name)}
- **Compatibilidade:** COBOL padrão
- **Dependências:** {self._get_copybook_dependencies(book.content)}

### Considerações de Manutenção
- Alterações neste copybook afetam todos os programas que o utilizam
- Recomenda-se versionamento adequado para controle de mudanças
- Testes de regressão são essenciais após modificações
- Documentação deve ser mantida atualizada com as definições

---
**Documentação gerada automaticamente pelo COBOL AI Engine v1.3.0**
**Sistema de Análise Inteligente de Programas COBOL**
**Data de Geração:** {datetime.now().strftime('%d/%m/%Y às %H:%M:%S')}
**Tipo:** Análise de Copybook Detalhada
"""
        
        return content
    
    def _get_copybook_purpose(self, book_name: str) -> str:
        """Determina o propósito do copybook baseado no nome."""
        name_upper = book_name.upper()
        if any(word in name_upper for word in ['ERRO', 'ERROR']):
            return "Definições para tratamento de erros"
        elif any(word in name_upper for word in ['DATA', 'DATE']):
            return "Estruturas para manipulação de datas"
        elif any(word in name_upper for word in ['COMM', 'COMMON']):
            return "Definições comuns compartilhadas"
        elif any(word in name_upper for word in ['FILE', 'ARQUIVO']):
            return "Estruturas de arquivos"
        else:
            return "Definições de dados específicas do sistema"
    
    def _get_copybook_dependencies(self, content: str) -> str:
        """Identifica dependências do copybook."""
        if 'COPY ' in content.upper():
            return "Possui dependências de outros copybooks"
        elif any(word in content.upper() for word in ['CALL ', 'INVOKE ']):
            return "Pode ter dependências de programas externos"
        else:
            return "Sem dependências externas identificadas"

    def generate_consolidated_report(self, programs: List[CobolProgram], 
                                   books: List[CobolBook],
                                   analysis_results: Dict[str, Any]) -> str:
        """
        Gera relatório consolidado da análise.
        
        Args:
            programs: Lista de programas analisados
            books: Lista de copybooks analisados
            analysis_results: Resultados da análise
            
        Returns:
            Caminho do arquivo gerado
        """
        try:
            content = self._generate_consolidated_content(programs, books, analysis_results)
            
            # Salvar arquivo
            filename = "relatorio_consolidado.md"
            filepath = os.path.join(self.output_dir, filename)
            
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)
            
            self.logger.info(f"Relatório consolidado gerado: {filename}")
            return filepath
            
        except Exception as e:
            self.logger.error(f"Erro ao gerar relatório consolidado: {e}")
            return ""
    
    def _generate_consolidated_content(self, programs: List[CobolProgram], 
                                     books: List[CobolBook],
                                     analysis_results: Dict[str, Any]) -> str:
        """Gera conteúdo do relatório consolidado."""
        
        total_programs = len(programs)
        total_books = len(books)
        total_lines = sum(getattr(p, 'line_count', 0) for p in programs) + sum(getattr(b, 'line_count', 0) for b in books)
        total_size = sum(getattr(p, 'size', 0) for p in programs) + sum(getattr(b, 'size', 0) for b in books)
        
        # Estatísticas de análise
        successful_analyses = analysis_results.get('successful_analyses', 0)
        failed_analyses = analysis_results.get('failed_analyses', 0)
        total_tokens = analysis_results.get('total_tokens', 0)
        processing_time = analysis_results.get('processing_time', 0)
        
        content = f"""# Relatório Consolidado de Análise COBOL

**Data de Geração**: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}
**Versão do Sistema**: COBOL AI Engine v1.3.0

## Resumo Executivo da Análise

### Componentes Analisados
- **Total de Programas COBOL:** {total_programs}
- **Total de Copybooks:** {total_books}
- **Total de Componentes:** {total_programs + total_books}
- **Linhas de Código Total:** {total_lines:,} linhas
- **Tamanho Total:** {total_size:,} caracteres

### Resultados da Análise
- **Análises Bem-sucedidas:** {successful_analyses}/{total_programs + total_books}
- **Taxa de Sucesso:** {(successful_analyses / max(total_programs + total_books, 1) * 100):.1f}%
- **Análises com Falha:** {failed_analyses}
- **Total de Tokens Utilizados:** {total_tokens:,}
- **Tempo Total de Processamento:** {processing_time:.2f} segundos
- **Eficiência:** {(total_tokens / max(processing_time, 0.1)):.0f} tokens/segundo

## Detalhamento por Componente

### Programas COBOL Analisados"""
        
        if programs:
            for i, program in enumerate(programs, 1):
                complexity = 'Alta' if getattr(program, 'line_count', 0) > 500 else 'Média' if getattr(program, 'line_count', 0) > 100 else 'Baixa'
                content += f"""
{i}. **{program.name}**
   - Linhas de código: {getattr(program, 'line_count', 0)}
   - Tamanho: {getattr(program, 'size', 0)} caracteres
   - Complexidade: {complexity}
   - Status: {'Analisado com sucesso' if program.name in analysis_results.get('successful_programs', []) else 'Análise pendente'}
"""
        else:
            content += "\nNenhum programa COBOL foi analisado nesta execução.\n"
        
        content += "\n### Copybooks Analisados"
        
        if books:
            for i, book in enumerate(books, 1):
                complexity = 'Alta' if getattr(book, 'line_count', 0) > 200 else 'Média' if getattr(book, 'line_count', 0) > 50 else 'Baixa'
                content += f"""
{i}. **{book.name}**
   - Linhas de código: {getattr(book, 'line_count', 0)}
   - Tamanho: {getattr(book, 'size', 0)} caracteres
   - Complexidade: {complexity}
   - Status: {'Analisado com sucesso' if book.name in analysis_results.get('successful_books', []) else 'Análise pendente'}
"""
        else:
            content += "\nNenhum copybook foi analisado nesta execução.\n"
        
        # Estatísticas detalhadas
        content += f"""
## Estatísticas Detalhadas

### Distribuição por Complexidade

#### Programas COBOL
- **Alta Complexidade (>500 linhas):** {len([p for p in programs if getattr(p, 'line_count', 0) > 500])} programas
- **Média Complexidade (100-500 linhas):** {len([p for p in programs if 100 <= getattr(p, 'line_count', 0) <= 500])} programas
- **Baixa Complexidade (<100 linhas):** {len([p for p in programs if getattr(p, 'line_count', 0) < 100])} programas

#### Copybooks
- **Alta Complexidade (>200 linhas):** {len([b for b in books if getattr(b, 'line_count', 0) > 200])} copybooks
- **Média Complexidade (50-200 linhas):** {len([b for b in books if 50 <= getattr(b, 'line_count', 0) <= 200])} copybooks
- **Baixa Complexidade (<50 linhas):** {len([b for b in books if getattr(b, 'line_count', 0) < 50])} copybooks

### Métricas de Qualidade
- **Densidade Média de Documentação:** {self._calculate_documentation_density(programs + books):.1f}%
- **Tamanho Médio de Programa:** {(sum(getattr(p, 'line_count', 0) for p in programs) / max(len(programs), 1)):.0f} linhas
- **Tamanho Médio de Copybook:** {(sum(getattr(b, 'line_count', 0) for b in books) / max(len(books), 1)):.0f} linhas

### Eficiência do Processamento
- **Tokens por Componente:** {(total_tokens / max(total_programs + total_books, 1)):.0f} tokens/componente
- **Tempo por Componente:** {(processing_time / max(total_programs + total_books, 1)):.2f} segundos/componente
- **Throughput:** {((total_programs + total_books) / max(processing_time / 3600, 0.001)):.1f} componentes/hora

## Recomendações e Próximos Passos

### Componentes Prioritários para Revisão
{self._get_priority_recommendations(programs, books)}

### Oportunidades de Melhoria
- Componentes com baixa documentação podem se beneficiar de comentários adicionais
- Programas de alta complexidade podem ser candidatos a refatoração
- Copybooks extensos podem ser divididos em módulos menores

### Considerações para Manutenção
- Estabelecer padrões de documentação baseados na análise realizada
- Implementar revisões periódicas dos componentes identificados como críticos
- Considerar modernização gradual dos componentes mais complexos

---
**Relatório gerado automaticamente pelo COBOL AI Engine v1.3.0**
**Sistema de Análise Inteligente de Programas COBOL**
**Data de Geração:** {datetime.now().strftime('%d/%m/%Y às %H:%M:%S')}
**Escopo:** Análise Consolidada Completa
"""
        
        return content
    
    def _calculate_documentation_density(self, components) -> float:
        """Calcula a densidade média de documentação."""
        if not components:
            return 0.0
        
        total_lines = 0
        total_comment_lines = 0
        
        for component in components:
            content = getattr(component, 'content', '')
            lines = content.split(chr(10))
            total_lines += len(lines)
            total_comment_lines += len([line for line in lines if line.strip().startswith('*')])
        
        return (total_comment_lines / max(total_lines, 1)) * 100
    
    def _get_priority_recommendations(self, programs, books) -> str:
        """Gera recomendações de prioridade."""
        high_complexity_programs = [p for p in programs if getattr(p, 'line_count', 0) > 500]
        low_doc_components = []  # Seria calculado baseado na densidade de documentação
        
        recommendations = []
        
        if high_complexity_programs:
            recommendations.append(f"- **Programas de Alta Complexidade:** {', '.join([p.name for p in high_complexity_programs[:5]])}")
        
        if len(programs) > 10:
            recommendations.append("- **Volume Elevado:** Considerar análise em lotes para otimização")
        
        if not recommendations:
            recommendations.append("- **Sistema Bem Estruturado:** Componentes dentro de padrões aceitáveis")
        
        return chr(10).join(recommendations)

    def get_statistics(self) -> Dict[str, Any]:
        """
        Retorna estatísticas do gerador.
        
        Returns:
            Dicionário com estatísticas
        """
        return {
            'files_generated': self.files_generated,
            'total_programs': self.total_programs,
            'total_books': self.total_books,
            'output_directory': self.output_dir
        }

