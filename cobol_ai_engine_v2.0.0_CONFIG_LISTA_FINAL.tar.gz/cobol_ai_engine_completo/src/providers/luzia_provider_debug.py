"""
Provider LuzIA com debug detalhado para identificar problema
"""

import requests
import json
import time
import logging
from datetime import datetime, timedelta
from .base_provider import BaseProvider, AIRequest, AIResponse


class LuziaProviderDebug(BaseProvider):
    """Provider LuzIA com debug completo"""
    
    def __init__(self, config):
        super().__init__(config)
        self.base_url = config.get('base_url', 'https://gut-api-aws.santanderbr.dev.corp/genai_services/v1/pipelines/submit')
        self.client_id = config.get('client_id')
        self.client_secret = config.get('client_secret')
        self.auth_url = "https://login.azure.paas.santanderbr.pre.corp/auth/realms/corp/protocol/openid-connect/token"
        self.model = "azure-gpt-4o-mini"
        self.timeout = config.get('timeout', 120)
        
        self._token = None
        self._token_expires_at = 0
        
        self.logger = logging.getLogger(__name__)
    
    def get_token(self):
        """Obter token OAuth2"""
        if self._token and time.time() < self._token_expires_at:
            return self._token
        
        try:
            request_body = {
                "grant_type": "client_credentials",
                "client_id": self.client_id,
                "client_secret": self.client_secret
            }
            
            headers = {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Accept': '*/*'
            }
            
            response = requests.post(
                self.auth_url,
                headers=headers,
                data=request_body,
                verify=False,
                timeout=30
            )
            
            if response.status_code == 200:
                token_data = response.json()
                self._token = token_data.get("access_token")
                expires_in = token_data.get("expires_in", 3600)
                self._token_expires_at = time.time() + expires_in - 60  # 1 min buffer
                
                self.logger.info("Token obtido com sucesso")
                return self._token
            else:
                self.logger.error(f"Erro ao obter token: {response.status_code} - {response.text}")
                return None
                
        except Exception as e:
            self.logger.error(f"Exceção ao obter token: {e}")
            return None
    
    def analyze(self, request: AIRequest) -> AIResponse:
        """Analisar com debug completo"""
        
        start_time = time.time()
        
        try:
            # Obter token
            token = self.get_token()
            if not token:
                return AIResponse(
                    success=False,
                    content="",
                    tokens_used=0,
                    model=self.model,
                    error_message="Falha na autenticação"
                )
            
            # Construir prompts
            system_prompt = """
Answer all questions in brazilian portuguese.
Answer code question with the code only, without using the brackets.
DON'T start the answer with the word 'python'.
"""
            
            user_prompt = request.prompt
            
            # Construir payload EXATO - config deve ser LISTA!
            payload = {
                "input": {
                    "query": [
                        {
                            "role": "system",
                            "content": system_prompt
                        },
                        {
                            "role": "user",
                            "content": user_prompt
                        }
                    ]
                },
                "config": [
                    {
                        "type": "catena.llm.LLMRouter",
                        "obj_kwargs": {
                            "routing_model": self.model,
                            "temperature": 0.1,
                            "system_prompt": "Responda apenas em português"
                        }
                    }
                ]
            }
            
            # Headers
            headers = {
                "X-santander-client-id": self.client_id,
                "Authorization": f"Bearer {token}"
            }
            
            # DEBUG COMPLETO
            print("\n" + "="*60)
            print("DEBUG REQUISIÇÃO LUZIA")
            print("="*60)
            print(f"URL: {self.base_url}")
            print(f"Client ID: {self.client_id}")
            print(f"Token (primeiros 20): {token[:20]}...")
            print("\nHEADERS:")
            for key, value in headers.items():
                if key == "Authorization":
                    print(f"  {key}: Bearer {value[7:27]}...")
                else:
                    print(f"  {key}: {value}")
            
            print(f"\nPAYLOAD ({len(json.dumps(payload))} bytes):")
            print(json.dumps(payload, indent=2, ensure_ascii=False))
            
            print(f"\nSYSTEM PROMPT ({len(system_prompt)} chars):")
            print(repr(system_prompt))
            
            print(f"\nUSER PROMPT ({len(user_prompt)} chars):")
            print(repr(user_prompt))
            
            print("\nVALIDAÇÃO PAYLOAD:")
            print(f"- Tipo de 'input': {type(payload['input'])}")
            print(f"- Tipo de 'input.query': {type(payload['input']['query'])}")
            print(f"- Tamanho de 'input.query': {len(payload['input']['query'])}")
            for i, item in enumerate(payload['input']['query']):
                print(f"  [{i}] role: {item['role']}, content: {len(item['content'])} chars")
            
            print("\nFAZENDO REQUISIÇÃO...")
            print("="*60)
            
            # Fazer requisição
            response = requests.post(
                url=self.base_url,
                json=payload,
                headers=headers,
                verify=False,
                timeout=self.timeout
            )
            
            response_time = time.time() - start_time
            
            print(f"\nRESPOSTA RECEBIDA:")
            print(f"Status Code: {response.status_code}")
            print(f"Tempo: {response_time:.2f}s")
            print(f"Headers de resposta:")
            for key, value in response.headers.items():
                print(f"  {key}: {value}")
            
            print(f"\nBODY DA RESPOSTA:")
            print(response.text)
            
            if response.status_code == 200:
                try:
                    response_data = response.json()
                    print(f"\nJSON DA RESPOSTA:")
                    print(json.dumps(response_data, indent=2, ensure_ascii=False))
                    
                    content = response_data.get('result', str(response_data))
                    
                    return AIResponse(
                        success=True,
                        content=content,
                        tokens_used=len(content.split()) if content else 0,
                        model=self.model,
                        response_time=response_time
                    )
                except Exception as e:
                    print(f"Erro ao processar JSON: {e}")
                    return AIResponse(
                        success=False,
                        content="",
                        tokens_used=0,
                        model=self.model,
                        error_message=f"Erro ao processar resposta: {e}",
                        response_time=response_time
                    )
            else:
                print(f"\nERRO HTTP {response.status_code}")
                try:
                    error_json = response.json()
                    print("JSON do erro:")
                    print(json.dumps(error_json, indent=2, ensure_ascii=False))
                except:
                    print("Resposta de erro não é JSON válido")
                
                print("="*60)
                
                return AIResponse(
                    success=False,
                    content="",
                    tokens_used=0,
                    model=self.model,
                    error_message=f"HTTP {response.status_code}: {response.text}",
                    response_time=response_time
                )
                
        except Exception as e:
            response_time = time.time() - start_time
            print(f"\nEXCEÇÃO: {e}")
            print("="*60)
            
            return AIResponse(
                success=False,
                content="",
                tokens_used=0,
                model=self.model,
                error_message=f"Exceção: {e}",
                response_time=response_time
            )
    
    def is_available(self) -> bool:
        """Verificar se provider está disponível"""
        return bool(self.client_id and self.client_secret)
