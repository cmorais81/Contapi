#!/usr/bin/env python3
"""
COBOL AI Engine v2.0.0 - Sistema de Análise de Programas COBOL
Sistema completo de análise de programas COBOL com IA, suportando múltiplos modelos e transparência total.
"""

import argparse
import json
import logging
import os
import sys
import time
from datetime import datetime
from typing import List, Dict, Any

# Imports removidos - funcionalidades integradas nos módulos principais

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.core.config import ConfigManager
from src.core.prompt_manager_dual import DualPromptManager
from src.core.token_manager import TokenManager
from src.providers.enhanced_provider_manager import EnhancedProviderManager
from src.parsers.cobol_parser import COBOLParser
from src.generators.documentation_generator import DocumentationGenerator
from src.utils.html_generator import HTMLReportGenerator
from src.analyzers.enhanced_cobol_analyzer import EnhancedCOBOLAnalyzer

def setup_logging(log_level: str = "INFO") -> None:
    """Configura o sistema de logging."""
    log_dir = "logs"
    os.makedirs(log_dir, exist_ok=True)
    
    log_file = os.path.join(log_dir, f"cobol_ai_engine_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
    
    logging.basicConfig(
        level=getattr(logging, log_level.upper()),
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file, encoding='utf-8'),
            logging.StreamHandler(sys.stdout)
        ]
    )

def parse_models_argument(models_arg: str) -> List[str]:
    """
    Parseia o argumento de modelos, suportando tanto string única quanto array JSON.
    
    Args:
        models_arg: String contendo modelo único ou array JSON de modelos
        
    Returns:
        Lista de modelos para usar
    """
    models_arg = models_arg.strip()
    
    # Verificar se é um array JSON
    if models_arg.startswith('[') and models_arg.endswith(']'):
        try:
            models = json.loads(models_arg)
            if isinstance(models, list):
                return [str(model).strip() for model in models if model]
            else:
                return [str(models)]
        except json.JSONDecodeError:
            # Se não conseguir parsear como JSON, tratar como string única
            return [models_arg]
    else:
        # String única
        return [models_arg]

def convert_to_html(output_dir: str) -> None:
    """Converte arquivos markdown para HTML otimizado para impressão."""
    try:
        generator = HTMLReportGenerator()
        html_files = generator.generate_html_reports(output_dir)
        
        if html_files:
            print(f"\n=== RELATÓRIOS HTML GERADOS ===")
            for html_file in html_files:
                print(f"HTML: {html_file}")
            
            # Mostrar instruções
            print(f"\n=== COMO CONVERTER PARA PDF ===")
            print("1. Abra qualquer arquivo HTML no seu navegador")
            print("2. Pressione Ctrl+P (Windows/Linux) ou Cmd+P (Mac)")
            print("3. Selecione 'Salvar como PDF' como destino")
            print("4. Configure margens como 'Mínimas'")
            print("5. Marque 'Gráficos de fundo' se disponível")
            print("6. Clique em 'Salvar'")
            print(f"\nArquivos HTML prontos em: {output_dir}")
        else:
            logging.warning("Nenhum arquivo HTML foi gerado")
            
    except Exception as e:
        logging.error(f"Erro na conversão para HTML: {e}")

def analyze_program_with_model(program, books, model_name: str, base_output_dir: str, 
                             config_manager: ConfigManager, code_analyzer: EnhancedCOBOLAnalyzer,
                             is_multi_model: bool = False, prompt_set: str = 'original') -> Dict[str, Any]:
    """
    Analisa um programa com um modelo específico.
    
    Args:
        program: Programa COBOL para analisar
        books: Lista de copybooks
        model_name: Nome do modelo a usar
        base_output_dir: Diretório base de saída
        config_manager: Gerenciador de configuração
        code_analyzer: Analisador de código aprimorado
        is_multi_model: Se é análise multi-modelo
        
    Returns:
        Dicionário com resultados da análise
    """
    logger = logging.getLogger(__name__)
    
    # Criar diretório específico para o modelo se múltiplos modelos
    if is_multi_model:
        model_output_dir = os.path.join(base_output_dir, f"model_{model_name}")
        os.makedirs(model_output_dir, exist_ok=True)
    else:
        model_output_dir = base_output_dir
    
    # Inicializar componentes específicos para o modelo
    prompt_manager = DualPromptManager(config_manager.config, prompt_set)
    provider_manager = EnhancedProviderManager(config_manager.config)
    doc_generator = DocumentationGenerator(model_output_dir)
    
    logger.info(f"Analisando {program.name} com modelo {model_name}")
    
    try:
        # Pré-análise detalhada
        pre_analysis_result = code_analyzer.analyze_program_enhanced(program.content, program.name)
        
        # Converter resultado da pré-análise para formato compatível
        pre_analysis = {
            'enhanced_comments': [
                {
                    'text': comment.text,
                    'category': comment.category,
                    'confidence': comment.confidence,
                    'business_impact': comment.business_impact
                } for comment in pre_analysis_result.enhanced_comments
            ],
            'logic_flows': [
                {
                    'name': flow.name,
                    'type': flow.type,
                    'description': flow.description,
                    'business_purpose': flow.business_purpose,
                    'complexity_score': flow.complexity_score
                } for flow in pre_analysis_result.logic_flows
            ],
            'business_entities': [
                {
                    'name': entity.name,
                    'type': entity.type,
                    'attributes': entity.attributes,
                    'regulatory_context': entity.regulatory_context
                } for entity in pre_analysis_result.business_entities
            ],
            'regulatory_compliance': pre_analysis_result.regulatory_compliance,
            'quality_metrics': pre_analysis_result.quality_metrics
        }

        # Gerar prompt base com contexto enriquecido
        base_prompt = prompt_manager.generate_base_prompt(
            program.name, 
            program.content,
            context={
                "books": books,
                "pre_analysis": pre_analysis
            }
        )

        # Criar requisição com informações completas
        from src.providers.base_provider import AIRequest
        request = AIRequest(
            prompt=base_prompt,
            program_name=program.name,
            program_code=program.content,
            context={
                "books": books,
                "pre_analysis": pre_analysis,
                "model_selected": model_name
            }
        )

        # Analisar com o modelo selecionado
        if hasattr(provider_manager, 'analyze_with_model') and model_name != 'default':
            response = provider_manager.analyze_with_model(model_name, request)
        else:
            response = provider_manager.analyze(request)

        if response.success:
            # TRANSPARÊNCIA: Adicionar informações completas dos prompts utilizados
            response.prompts_used = {
                'original_prompt': base_prompt,
                'system_prompt': prompt_manager.get_system_prompt(),
                'model_selected': model_name,
                'context_information': {
                    'books_count': len(books),
                    'pre_analysis_comments': len(pre_analysis.get('enhanced_comments', [])),
                    'pre_analysis_flows': len(pre_analysis.get('logic_flows', [])),
                    'pre_analysis_entities': len(pre_analysis.get('business_entities', []))
                },
                'prompt_engineering_strategy': 'standard',
                'analysis_questions': list(prompt_manager.get_analysis_questions().keys()),
                'timestamp': datetime.now().isoformat()
            }
            
            # Adicionar metadados da pré-análise à resposta
            response.pre_analysis = pre_analysis_result
            response.program_name = program.name
            response.model_used = model_name
            
            # Gerar documentação específica para o modelo
            doc_generator.generate_program_documentation(program, response, None)
            
            logger.info(f"Análise de {program.name} com {model_name} bem-sucedida.")
            logger.info(f"Tokens utilizados: {response.tokens_used}")
            logger.info(f"Modelo utilizado: {response.model}")
            
            return {
                'success': True,
                'model': model_name,
                'response': response,
                'tokens_used': response.tokens_used,
                'output_dir': model_output_dir
            }
            
        else:
            logger.error(f"Análise de {program.name} com {model_name} falhou: {response.error_message}")
            return {
                'success': False,
                'model': model_name,
                'error': response.error_message,
                'output_dir': model_output_dir
            }

    except Exception as e:
        logger.error(f"Erro ao processar {program.name} com {model_name}: {str(e)}")
        return {
            'success': False,
            'model': model_name,
            'error': str(e),
            'output_dir': model_output_dir
        }

def generate_comparative_report(programs, all_results: List[Dict], base_output_dir: str) -> None:
    """
    Gera relatório comparativo entre os diferentes modelos.
    
    Args:
        programs: Lista de programas analisados
        all_results: Lista com todos os resultados das análises
        base_output_dir: Diretório base de saída
    """
    logger = logging.getLogger(__name__)
    
    try:
        report_path = os.path.join(base_output_dir, "relatorio_comparativo_modelos.md")
        
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write("# Relatório Comparativo - Análise Multi-Modelo\n\n")
            f.write(f"**Data:** {datetime.now().strftime('%d/%m/%Y às %H:%M:%S')}\n")
            f.write(f"**Sistema:** COBOL AI Engine v2.0.0\n\n")
            
            # Resumo geral
            f.write("## Resumo Executivo\n\n")
            f.write(f"**Programas Analisados:** {len(programs)}\n")
            
            # Agrupar resultados por modelo
            models_used = set()
            results_by_model = {}
            
            for result in all_results:
                model = result['model']
                models_used.add(model)
                if model not in results_by_model:
                    results_by_model[model] = []
                results_by_model[model].append(result)
            
            f.write(f"**Modelos Utilizados:** {len(models_used)} ({', '.join(sorted(models_used))})\n")
            f.write(f"**Total de Análises:** {len(all_results)}\n\n")
            
            # Estatísticas por modelo
            f.write("## Estatísticas por Modelo\n\n")
            f.write("| Modelo | Sucessos | Falhas | Taxa de Sucesso | Tokens Médios |\n")
            f.write("|--------|----------|--------|-----------------|---------------|\n")
            
            for model in sorted(models_used):
                model_results = results_by_model[model]
                successes = sum(1 for r in model_results if r['success'])
                failures = len(model_results) - successes
                success_rate = (successes / len(model_results)) * 100 if model_results else 0
                avg_tokens = sum(r.get('tokens_used', 0) for r in model_results if r['success']) / max(successes, 1)
                
                f.write(f"| {model} | {successes} | {failures} | {success_rate:.1f}% | {avg_tokens:.0f} |\n")
            
            f.write("\n")
            
            # Detalhes por programa
            f.write("## Detalhes por Programa\n\n")
            
            for program in programs:
                f.write(f"### {program.name}\n\n")
                
                program_results = [r for r in all_results if r.get('response') and r['response'].program_name == program.name]
                
                if program_results:
                    f.write("| Modelo | Status | Tokens | Qualidade | Diretório |\n")
                    f.write("|--------|--------|--------|-----------|----------|\n")
                    
                    for result in program_results:
                        status = "Sucesso" if result['success'] else "Falha"
                        tokens = result.get('tokens_used', 0)
                        quality = "Alta" if tokens > 2000 else "Média" if tokens > 1000 else "Baixa"
                        output_dir = os.path.basename(result['output_dir'])
                        
                        f.write(f"| {result['model']} | {status} | {tokens} | {quality} | {output_dir} |\n")
                    
                    f.write("\n")
                else:
                    f.write("Nenhum resultado encontrado para este programa.\n\n")
            
            # Recomendações
            f.write("## Recomendações\n\n")
            
            # Encontrar melhor modelo por taxa de sucesso
            best_model = max(models_used, key=lambda m: sum(1 for r in results_by_model[m] if r['success']) / len(results_by_model[m]))
            f.write(f"**Modelo Recomendado:** {best_model} (melhor taxa de sucesso)\n\n")
            
            # Encontrar modelo com mais tokens em média
            highest_tokens_model = max(models_used, key=lambda m: sum(r.get('tokens_used', 0) for r in results_by_model[m] if r['success']) / max(sum(1 for r in results_by_model[m] if r['success']), 1))
            f.write(f"**Modelo Mais Detalhado:** {highest_tokens_model} (maior média de tokens)\n\n")
            
            f.write("### Uso Recomendado por Cenário\n\n")
            f.write("- **Análise Rápida:** Use o modelo com melhor taxa de sucesso\n")
            f.write("- **Análise Detalhada:** Use o modelo com maior média de tokens\n")
            f.write("- **Análise Crítica:** Execute com múltiplos modelos e compare resultados\n")
            f.write("- **Produção:** Use o modelo mais estável baseado nas estatísticas\n\n")
            
            f.write("---\n")
            f.write("**Relatório gerado automaticamente pelo COBOL AI Engine v2.0.0**\n")
        
        logger.info(f"Relatório comparativo gerado: {report_path}")
        
    except Exception as e:
        logger.error(f"Erro ao gerar relatório comparativo: {e}")

def process_cobol_files(args, config_manager: ConfigManager, 
                       provider_manager: EnhancedProviderManager) -> None:
    """Processa arquivos COBOL com suporte a múltiplos modelos."""
    logger = logging.getLogger(__name__)
    
    # Carregar modelos da configuração se não especificado
    if hasattr(args, 'models') and args.models:
        models = parse_models_argument(args.models)
    else:
        # Usar modelos dos provedores habilitados
        models = []
        if 'providers' in config_manager.config:
            for provider_name, provider_config in config_manager.config['providers'].items():
                if provider_config.get('enabled', False) and 'models' in provider_config:
                    models.extend(provider_config['models'].keys())
        
        if not models:
            logger.warning("Nenhum modelo encontrado nos provedores habilitados, usando luzia")
            models = ['luzia']
    
    parser = COBOLParser()
    code_analyzer = EnhancedCOBOLAnalyzer()

    logger.info("=== INICIANDO PROCESSAMENTO ===")
    logger.info(f"Modelos selecionados: {models}")
    logger.info(f"Arquivo de fontes: {args.fontes}")
    if args.books:
        logger.info(f"Arquivo de books: {args.books}")
    logger.info(f"Diretório de saída: {args.output}")

    start_time = time.time()

    try:
        programs, books = parser.parse_file(args.fontes)
        if args.books and os.path.exists(args.books):
            _, additional_books = parser.parse_file(args.books)
            books.extend(additional_books)
        logger.info(f"Programas encontrados: {len(programs)}, Books encontrados: {len(books)}")
        if not programs:
            print("Nenhum programa encontrado para análise.")
            return
    except Exception as e:
        logger.error(f"Erro ao parsear arquivos: {str(e)}")
        return

    all_results = []
    is_multi_model = len(models) > 1
    
    # Se apenas um modelo, usar estrutura simples
    if not is_multi_model:
        model = models[0]
        for i, program in enumerate(programs, 1):
            print(f"Analisando programa {i}/{len(programs)}: {program.name}")
            
            result = analyze_program_with_model(
                program, books, model, args.output, config_manager, code_analyzer, is_multi_model, args.prompt_set
            )
            
            all_results.append(result)
    else:
        # Múltiplos modelos - usar estrutura com diretórios separados
        total_analyses = len(programs) * len(models)
        current_analysis = 0
        
        for i, program in enumerate(programs, 1):
            logger.info(f"\nPrograma {i}/{len(programs)}: {program.name}")
            
            for j, model in enumerate(models, 1):
                current_analysis += 1
                print(f"Analisando {program.name} com {model} ({current_analysis}/{total_analyses})")
                
                result = analyze_program_with_model(
                    program, books, model, args.output, config_manager, code_analyzer, is_multi_model, args.prompt_set
                )
                
                all_results.append(result)

    # Gerar relatório comparativo se múltiplos modelos
    if is_multi_model:
        generate_comparative_report(programs, all_results, args.output)

    # Converter para HTML se solicitado
    if args.pdf:
        if not is_multi_model:
            convert_to_html(args.output)
        else:
            for model in models:
                model_output_dir = os.path.join(args.output, f"model_{model}")
                if os.path.exists(model_output_dir):
                    convert_to_html(model_output_dir)

    # Estatísticas finais
    processing_time = time.time() - start_time
    successful_analyses = sum(1 for r in all_results if r['success'])
    total_tokens = sum(r.get('tokens_used', 0) for r in all_results if r['success'])
    
    print()
    print("=== PROCESSAMENTO CONCLUÍDO ===")
    print(f"Programas processados: {len(programs)}")
    print(f"Modelos utilizados: {len(models)} ({', '.join(models)})")
    print(f"Análises bem-sucedidas: {successful_analyses}/{len(all_results)}")
    print(f"Taxa de sucesso geral: {(successful_analyses/len(all_results)*100):.1f}%")
    print(f"Total de tokens utilizados: {total_tokens}")
    print(f"Tempo total de processamento: {processing_time:.2f}s")
    print(f"Documentação gerada em: {args.output}")
    
    if is_multi_model:
        print(f"Relatório comparativo: {args.output}/relatorio_comparativo_modelos.md")

def main():
    """Função principal para executar o script."""
    parser = argparse.ArgumentParser(description='COBOL AI Engine v2.0.0 - Sistema de Análise de Programas COBOL')
    parser.add_argument('--fontes', help='Caminho para o arquivo de fontes COBOL (ex: fontes.txt)')
    parser.add_argument('--books', help='Caminho para o arquivo de copybooks (opcional)')
    parser.add_argument('--output', default='output', help='Diretório de saída para a documentação')
    parser.add_argument('--config', default='config/config.yaml', help='Arquivo de configuração principal')
    parser.add_argument('--models', help='(Opcional) Sobrescrever modelos da configuração. Formato: "modelo" ou ["modelo1","modelo2"]')
    parser.add_argument('--pdf', action='store_true', help='Gera relatórios HTML otimizados para conversão PDF via navegador')
    parser.add_argument('--log', default='INFO', help='Nível de log (DEBUG, INFO, WARNING, ERROR)')
    parser.add_argument('--status', action='store_true', help='Verifica status e conectividade dos provedores de IA configurados')
    parser.add_argument('--prompt-set', choices=['original', 'doc_legado_pro'], 
                        default='original', help='Conjunto de prompts a usar (original ou doc_legado_pro)')

    args = parser.parse_args()

    setup_logging(args.log)
    
    try:
        config_manager = ConfigManager(args.config)
        
        # Log da configuração inicial
        ai_config = config_manager.config.get('ai', {})
        primary_provider = ai_config.get('primary_provider', 'não definido')
        default_models = ai_config.get('default_models', [])
        
        print(f"\nCOBOL AI Engine v2.0.0 - Iniciando análise")
        print(f"Provider primário configurado: {primary_provider}")
        print(f"Modelos padrão: {', '.join(default_models)}")
        print(f"Arquivo de prompts: {ai_config.get('prompt', {}).get('prompts_file', 'config/prompts.yaml')}")
        
        # Verificar credenciais LuzIA se for o provider primário
        if primary_provider == 'luzia':
            import os
            client_id = os.getenv('LUZIA_CLIENT_ID')
            client_secret = os.getenv('LUZIA_CLIENT_SECRET')
            
            if not client_id or not client_secret:
                print(f"\nAVISO: Provider primário é LuzIA mas credenciais não estão definidas!")
                print(f"   LUZIA_CLIENT_ID: {'OK' if client_id else 'NÃO DEFINIDO'}")
                print(f"   LUZIA_CLIENT_SECRET: {'OK' if client_secret else 'NÃO DEFINIDO'}")
                print(f"   Sistema usará providers de fallback (enhanced_mock, basic)")
                print(f"\n   Para usar LuzIA, defina as variáveis:")
                print(f"   export LUZIA_CLIENT_ID='seu_client_id'")
                print(f"   export LUZIA_CLIENT_SECRET='seu_client_secret'")
            else:
                print(f"Credenciais LuzIA encontradas")
        
        print("=" * 60)
        
        provider_manager = EnhancedProviderManager(config_manager.config)
        
        # Verificar se é comando de status
        if args.status:
            print("\n=== STATUS DOS PROVEDORES ===")
            available_providers = provider_manager.get_available_providers()
            
            if not available_providers:
                print("Nenhum provider disponível")
                return
            
            for provider_name in available_providers:
                provider_status = provider_manager.get_provider_status(provider_name)
                status = "Disponível" if provider_status.get('available', False) else "Indisponível"
                print(f"{provider_name}: {status}")
            return
        
        # Validar argumentos obrigatórios para análise
        if not args.fontes:
            print("Erro: --fontes é obrigatório para análise de programas")
            print("Use --status para verificar conectividade dos provedores")
            sys.exit(1)
        
        process_cobol_files(args, config_manager, provider_manager)
    except Exception as e:
        logging.error(f"Uma falha crítica ocorreu: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
