#!/usr/bin/env python3
"""
COBOL to Docs - Script Executável
Script que funciona independentemente após instalação via pip
"""

import sys
import os
import subprocess
from pathlib import Path

def find_application_directory():
    """Encontra o diretório da aplicação COBOL Analyzer"""
    # Procurar no diretório atual
    current_dir = Path.cwd()
    
    # Verificar se estamos no diretório da aplicação
    if (current_dir / "main.py").exists() and (current_dir / "src").exists():
        return current_dir
    
    # Procurar no diretório pai
    parent_dir = current_dir.parent
    if (parent_dir / "main.py").exists() and (parent_dir / "src").exists():
        return parent_dir
    
    # Procurar por cobol_analyzer_EXCELENCIA
    for candidate in [current_dir, parent_dir, current_dir.parent.parent]:
        cobol_dir = candidate / "cobol_analyzer_EXCELENCIA"
        if cobol_dir.exists() and (cobol_dir / "main.py").exists():
            return cobol_dir
    
    # Procurar no diretório do script
    script_dir = Path(__file__).parent
    if (script_dir / "main.py").exists() and (script_dir / "src").exists():
        return script_dir
    
    # Procurar nos diretórios de instalação
    try:
        import site
        for site_dir in site.getsitepackages() + [site.getusersitepackages()]:
            if site_dir:
                site_path = Path(site_dir)
                candidates = [
                    site_path / "cobol_analyzer_EXCELENCIA",
                    site_path.parent / "cobol_analyzer_EXCELENCIA",
                ]
                for candidate in candidates:
                    if candidate.exists() and (candidate / "main.py").exists():
                        return candidate
    except:
        pass
    
    return None

def main():
    """Função principal"""
    try:
        # Encontrar o diretório da aplicação
        app_dir = find_application_directory()
        
        if app_dir:
            # Mudar para o diretório da aplicação
            original_cwd = os.getcwd()
            os.chdir(str(app_dir))
            
            try:
                # Executar o main.py
                cmd = [sys.executable, "main.py"] + sys.argv[1:]
                result = subprocess.call(cmd)
                return result
            finally:
                # Voltar ao diretório original
                os.chdir(original_cwd)
        else:
            print("Erro: Não foi possível encontrar a aplicação COBOL Analyzer.")
            print("\nSoluções:")
            print("1. Navegue até o diretório da aplicação e execute:")
            print("   python3 main.py --help")
            print("2. Verifique se a instalação foi feita corretamente")
            print("3. Execute a partir do diretório onde extraiu o pacote")
            return 1
            
    except Exception as e:
        print(f"Erro ao executar COBOL Analyzer: {e}")
        print("\nTente executar diretamente:")
        print("  python3 main.py --help")
        return 1

if __name__ == '__main__':
    sys.exit(main())
