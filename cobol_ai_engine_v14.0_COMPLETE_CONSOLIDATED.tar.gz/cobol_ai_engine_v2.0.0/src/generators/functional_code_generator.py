"""
Gerador de Código Funcional Específico
Gera código específico e funcional baseado na análise real do programa COBOL
"""

import logging
from typing import Dict, List, Any
from dataclasses import dataclass

@dataclass
class CodeTemplate:
    """Template de código para uma linguagem específica"""
    language: str
    main_class: str
    imports: List[str]
    data_structures: List[str]
    methods: List[str]

class FunctionalCodeGenerator:
    """Gerador de código funcional baseado em análise COBOL real"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
    
    def generate_code(self, analysis_data: Dict[str, Any], target_language: str = "java") -> CodeTemplate:
        self.logger.info(f"Gerando código {target_language} específico baseado em análise real")
        if target_language.lower() == "java":
            return self._generate_java_code(analysis_data)
        else:
            return CodeTemplate(language=target_language, main_class="", imports=[], data_structures=[], methods=[])

    def _generate_java_code(self, analysis_data: Dict[str, Any]) -> CodeTemplate:
        functional_analysis = analysis_data.get('functional_analysis', {})
        record_layouts = analysis_data.get('record_layouts', {})
        files = functional_analysis.get('functional_analysis', {}).get('files', [])
        
        purpose = functional_analysis.get('program_purpose', 'DataProcessor')
        class_name = self._extract_class_name_from_purpose(purpose)
        
        imports = [
            "import java.io.*;",
            "import java.nio.file.*;",
            "import java.util.*;"
        ]
        
        data_structures = self._generate_specific_java_data_structures(record_layouts)
        methods = self._generate_specific_java_methods(functional_analysis)
        
        return CodeTemplate(
            language="java",
            main_class=class_name,
            imports=imports,
            data_structures=data_structures,
            methods=methods
        )

    def _generate_specific_java_data_structures(self, record_layouts: Dict[str, Any]) -> List[str]:
        structures = []
        for record_name, fields in record_layouts.items():
            if not fields:
                continue
            
            class_name = self._to_java_class_name(record_name)
            structures.append(f"public class {class_name} {{")
            
            for field in fields:
                field_name = self._to_java_field_name(field.name)
                java_type = self._cobol_to_java_type(field.picture)
                structures.append(f"    private {java_type} {field_name}; // PIC {field.picture}")
            
            structures.append("\n    // Getters and Setters")
            for field in fields:
                field_name = self._to_java_field_name(field.name)
                java_type = self._cobol_to_java_type(field.picture)
                getter_name = f"get{field_name.capitalize()}"
                setter_name = f"set{field_name.capitalize()}"
                structures.append(f"    public {java_type} {getter_name}() {{ return {field_name}; }}")
                structures.append(f"    public void {setter_name}({java_type} value) {{ this.{field_name} = value; }}")
            
            structures.append("}")
        return structures

    def _generate_specific_java_methods(self, functional_analysis: Dict[str, Any]) -> List[str]:
        methods = []
        business_logic = functional_analysis.get('business_logic', {})
        files = functional_analysis.get('files', [])
        
        methods.append("public void process() throws IOException {")
        input_file = next((f for f in files if f['operation'] == 'INPUT'), None)
        output_files = [f for f in files if f['operation'] == 'OUTPUT']

        if input_file:
            methods.append(f"    try (BufferedReader reader = Files.newBufferedReader(Paths.get(\"{input_file['physical_name']}\"))) {{")
            methods.append("        String line;")
            methods.append("        while ((line = reader.readLine()) != null) {")
            if business_logic.get('decision_blocks'):
                block = business_logic['decision_blocks'][0]
                var_name = self._to_java_field_name(block['evaluate_on'])
                methods.append(f"            String {var_name} = line.substring(0, 2); // Example, adjust position")
                methods.append(f"            switch({var_name}) {{")
                for i, when in enumerate(block['when_clauses']):
                    condition = when.split(' ')[0]
                    methods.append(f"                case {condition}:")
                    if i < len(output_files):
                         methods.append(f"                    // Write to {output_files[i]['physical_name']}")
                    methods.append("                    break;")
                methods.append("                default:")
                methods.append("                    break;")
                methods.append("            }}")
            methods.append("        }")
            methods.append("    }}")
        methods.append("}")
        return methods

    def _extract_class_name_from_purpose(self, purpose: str) -> str:
        if 'divide' in purpose.lower() or 'split' in purpose.lower():
            return "FileSplitter"
        return "DataProcessor"

    def _to_java_class_name(self, cobol_name: str) -> str:
        return cobol_name.replace("-", "").capitalize()

    def _to_java_field_name(self, cobol_name: str) -> str:
        parts = cobol_name.lower().split('-')
        return parts[0] + ''.join(p.capitalize() for p in parts[1:])

    def _cobol_to_java_type(self, picture: str) -> str:
        if not picture: return "String"
        if '9' in picture and 'V' in picture:
            return "java.math.BigDecimal"
        if '9' in picture:
            return "long"
        return "String"

