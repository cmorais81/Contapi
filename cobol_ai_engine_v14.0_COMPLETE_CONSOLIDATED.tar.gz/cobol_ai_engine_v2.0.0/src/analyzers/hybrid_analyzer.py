"""
Analisador Híbrido - Combina análise interna com LLM
Garante que a análise interna sempre seja considerada e enriquecida pelo LLM
"""

import logging
from typing import Dict, Any, List, Optional
from dataclasses import dataclass

@dataclass
class AnalysisConfidence:
    """Representa a confiança de uma análise específica."""
    source: str  # 'internal', 'llm', 'hybrid'
    score: float  # 0.0 - 1.0
    reasoning: str

class HybridAnalyzer:
    """
    Analisador que combina análise interna (sempre executada) com análise de LLM.
    A análise interna é a base, e o LLM enriquece e valida os resultados.
    """
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
    
    def combine_analyses(self, internal_analysis: Dict[str, Any], 
                        llm_analysis: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Combina análise interna (obrigatória) com análise do LLM (opcional).
        
        Args:
            internal_analysis: Análise sempre executada pelo interpretador interno
            llm_analysis: Análise opcional do LLM (pode ser None se falhar)
            
        Returns:
            Análise híbrida combinando ambas as fontes
        """
        
        # Base sempre é a análise interna
        hybrid_result = {
            "base_analysis": internal_analysis,
            "llm_enhancement": llm_analysis or {},
            "confidence_scores": {},
            "combined_insights": {}
        }
        
        # Combinar funcionalidade principal
        hybrid_result["combined_insights"]["main_functionality"] = self._combine_functionality(
            internal_analysis, llm_analysis
        )
        
        # Combinar arquitetura de dados
        hybrid_result["combined_insights"]["data_architecture"] = self._combine_data_architecture(
            internal_analysis, llm_analysis
        )
        
        # Combinar lógica de processamento
        hybrid_result["combined_insights"]["processing_logic"] = self._combine_processing_logic(
            internal_analysis, llm_analysis
        )
        
        # Combinar regras de negócio
        hybrid_result["combined_insights"]["business_rules"] = self._combine_business_rules(
            internal_analysis, llm_analysis
        )
        
        # Combinar guia de reimplementação
        hybrid_result["combined_insights"]["reimplementation_guide"] = self._combine_reimplementation_guide(
            internal_analysis, llm_analysis
        )
        
        # Calcular scores de confiança
        hybrid_result["confidence_scores"] = self._calculate_confidence_scores(
            internal_analysis, llm_analysis
        )
        
        return hybrid_result
    
    def _combine_functionality(self, internal: Dict[str, Any], 
                              llm: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        """Combina análise de funcionalidade principal."""
        
        # Base da análise interna
        functional_summary = internal.get("functional_analysis", {}).get("functional_summary", {})
        
        result = {
            "description": functional_summary.get("primary_function", "Processador de dados COBOL"),
            "business_purpose": functional_summary.get("business_value", "Processamento de dados corporativos"),
            "technical_implementation": functional_summary.get("technical_approach", "Processamento sequencial de arquivos"),
            "confidence": AnalysisConfidence("internal", 0.8, "Baseado em análise estrutural do código")
        }
        
        # Enriquecer com LLM se disponível
        if llm and "main_functionality" in llm:
            llm_func = llm["main_functionality"]
            
            # Combinar descrições
            if llm_func.get("description") and llm_func["description"] != "Análise detalhada do LLM":
                result["description"] = f"{result['description']}. {llm_func['description']}"
                result["confidence"] = AnalysisConfidence("hybrid", 0.95, "Análise interna validada e enriquecida por LLM")
            
            # Enriquecer propósito de negócio
            if llm_func.get("business_purpose") and llm_func["business_purpose"] != "Propósito identificado pelo LLM":
                result["business_purpose"] = llm_func["business_purpose"]
        
        return result
    
    def _combine_data_architecture(self, internal: Dict[str, Any], 
                                  llm: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        """Combina análise de arquitetura de dados."""
        
        # Base da análise interna
        file_processing = internal.get("functional_analysis", {}).get("file_processing", {})
        
        result = {
            "input_files": getattr(file_processing, "input_file", []) if hasattr(file_processing, "input_file") else [],
            "output_files": getattr(file_processing, "output_files", []) if hasattr(file_processing, "output_files") else [],
            "data_flow": "Fluxo sequencial: leitura → validação → escrita",
            "confidence": AnalysisConfidence("internal", 0.9, "Extraído diretamente do código COBOL")
        }
        
        # Enriquecer com LLM se disponível
        if llm and "data_architecture" in llm:
            llm_data = llm["data_architecture"]
            
            if llm_data.get("data_flow") and llm_data["data_flow"] != "Fluxo de dados analisado pelo LLM":
                result["data_flow"] = llm_data["data_flow"]
                result["confidence"] = AnalysisConfidence("hybrid", 0.95, "Fluxo interno validado por LLM")
        
        return result
    
    def _combine_processing_logic(self, internal: Dict[str, Any], 
                                 llm: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        """Combina análise de lógica de processamento."""
        
        # Base da análise interna
        functional_analysis = internal.get("functional_analysis", {})
        file_splitting = functional_analysis.get("file_splitting_logic", {})
        
        result = {
            "algorithm": functional_analysis.get("functional_summary", {}).get("technical_approach", "Processamento sequencial"),
            "file_splitting_detected": file_splitting.get("detected", False),
            "splitting_criteria": file_splitting.get("criteria", []),
            "decision_points": len(file_splitting.get("decision_points", [])),
            "confidence": AnalysisConfidence("internal", 0.85, "Baseado em padrões identificados no código")
        }
        
        # Enriquecer com LLM se disponível
        if llm and "processing_logic" in llm:
            llm_logic = llm["processing_logic"]
            
            if llm_logic.get("algorithm") and llm_logic["algorithm"] != "Algoritmo identificado pelo LLM":
                result["algorithm"] = llm_logic["algorithm"]
                result["confidence"] = AnalysisConfidence("hybrid", 0.92, "Algoritmo interno enriquecido por LLM")
        
        return result
    
    def _combine_business_rules(self, internal: Dict[str, Any], 
                               llm: Optional[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Combina regras de negócio identificadas."""
        
        # Base da análise interna
        file_processing = internal.get("functional_analysis", {}).get("file_processing", {})
        validation_rules = getattr(file_processing, "validation_rules", []) if hasattr(file_processing, "validation_rules") else []
        
        combined_rules = []
        
        # Adicionar regras da análise interna
        for rule in validation_rules:
            combined_rules.append({
                "rule": getattr(rule, "field", "Campo não identificado"),
                "type": getattr(rule, "rule_type", "validação"),
                "description": getattr(rule, "description", "Regra de validação"),
                "source": "internal",
                "confidence": 0.9
            })
        
        # TODO: Adicionar regras do LLM quando disponível
        
        return combined_rules
    
    def _combine_reimplementation_guide(self, internal: Dict[str, Any], 
                                       llm: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        """Combina guia de reimplementação."""
        
        # Base da análise interna
        functional_summary = internal.get("functional_analysis", {}).get("functional_summary", {})
        
        result = {
            "migration_considerations": functional_summary.get("migration_considerations", []),
            "complexity_assessment": functional_summary.get("complexity_assessment", "Média"),
            "recommended_approach": "Migração incremental com validação de dados",
            "confidence": AnalysisConfidence("internal", 0.8, "Baseado em padrões COBOL identificados")
        }
        
        # Enriquecer com LLM se disponível
        if llm and "reimplementation_guide" in llm:
            llm_guide = llm["reimplementation_guide"]
            
            # Usar sugestões do LLM se disponíveis e não forem placeholders
            if llm_guide.get("data_mapping") and "Mapeamento sugerido pelo LLM" not in llm_guide["data_mapping"]:
                result["data_mapping"] = llm_guide["data_mapping"]
                result["confidence"] = AnalysisConfidence("hybrid", 0.9, "Guia interno enriquecido por LLM")
        
        return result
    
    def _calculate_confidence_scores(self, internal: Dict[str, Any], 
                                   llm: Optional[Dict[str, Any]]) -> Dict[str, float]:
        """Calcula scores de confiança para diferentes aspectos da análise."""
        
        scores = {
            "overall": 0.85,  # Base da análise interna
            "functionality": 0.8,
            "data_architecture": 0.9,
            "processing_logic": 0.85,
            "business_rules": 0.8,
            "reimplementation": 0.8
        }
        
        # Aumentar confiança se LLM está disponível e fornece dados válidos
        if llm and self._is_valid_llm_analysis(llm):
            for key in scores:
                scores[key] = min(0.95, scores[key] + 0.1)  # Máximo 95%
        
        return scores
    
    def _is_valid_llm_analysis(self, llm_analysis: Dict[str, Any]) -> bool:
        """Verifica se a análise do LLM contém dados válidos (não placeholders)."""
        
        placeholders = [
            "Análise detalhada do LLM",
            "Propósito identificado pelo LLM",
            "Implementação técnica analisada",
            "Algoritmo identificado pelo LLM",
            "Mapeamento sugerido pelo LLM"
        ]
        
        # Verificar se há conteúdo real (não placeholders)
        for section in llm_analysis.values():
            if isinstance(section, dict):
                for value in section.values():
                    if isinstance(value, str) and value not in placeholders and len(value) > 20:
                        return True
        
        return False
