"""
Interpretador genérico de código COBOL que extrai informações reais do código.
"""

import re
from typing import Dict, List, Any, Tuple
from dataclasses import dataclass

@dataclass
class BusinessLogic:
    main_purpose: str
    business_context: str
    key_operations: List[str]
    decision_points: List[str]

@dataclass
class DataStructures:
    main_structures: List[str]
    file_definitions: List[str]
    working_storage: List[str]
    copybooks: List[str]

@dataclass
class ProcessingFlow:
    main_algorithm: str
    technical_details: str
    control_flow: List[str]
    error_handling: List[str]

class COBOLInterpreter:
    """Interpretador genérico que funciona para qualquer programa COBOL."""
    
    def __init__(self):
        self.cobol_keywords = {
            'file_operations': ['READ', 'WRITE', 'OPEN', 'CLOSE', 'REWRITE'],
            'control_flow': ['IF', 'ELSE', 'PERFORM', 'UNTIL', 'WHILE', 'GO TO'],
            'data_operations': ['MOVE', 'ADD', 'SUBTRACT', 'MULTIPLY', 'DIVIDE', 'COMPUTE'],
            'validation': ['NUMERIC', 'ALPHABETIC', 'SPACE', 'ZERO', 'HIGH-VALUE', 'LOW-VALUE'],
            'conditions': ['EQUAL', 'NOT EQUAL', 'GREATER', 'LESS', 'AND', 'OR', 'NOT']
        }
    
    def extract_business_logic_from_code(self, cleaned_lines: List[Tuple[int, str]]) -> BusinessLogic:
        """Extrai lógica de negócio real do código COBOL."""
        
        key_operations = []
        decision_points = []
        business_context = "Sistema de processamento de dados"
        main_purpose = "Processamento de dados corporativos"
        
        for line_num, line in cleaned_lines:
            line_upper = line.upper().strip()
            
            # Identificar operações principais
            if any(op in line_upper for op in ['READ', 'WRITE', 'OPEN', 'CLOSE']):
                key_operations.append(f"Linha {line_num}: {line.strip()}")
            
            # Identificar pontos de decisão
            if any(cond in line_upper for cond in ['IF', 'EVALUATE', 'WHEN']):
                decision_points.append(f"Linha {line_num}: {line.strip()}")
            
            # Inferir contexto de negócio baseado em nomes de variáveis/arquivos
            if any(term in line_upper for term in ['BANCO', 'BACEN', 'CONTA', 'CLIENTE']):
                business_context = "Sistema bancário/financeiro"
            elif any(term in line_upper for term in ['PRODUTO', 'ESTOQUE', 'VENDA']):
                business_context = "Sistema comercial/vendas"
            elif any(term in line_upper for term in ['FUNCIONARIO', 'FOLHA', 'SALARIO']):
                business_context = "Sistema de recursos humanos"
            
            # Inferir propósito principal
            if any(term in line_upper for term in ['SPLIT', 'DIVIDE', 'QUEBRA']):
                main_purpose = "Divisão e processamento de arquivos"
            elif any(term in line_upper for term in ['VALIDACAO', 'CRITICA', 'CONSISTENCIA']):
                main_purpose = "Validação e crítica de dados"
            elif any(term in line_upper for term in ['RELATORIO', 'REPORT', 'LISTAGEM']):
                main_purpose = "Geração de relatórios"
        
        return BusinessLogic(
            main_purpose=main_purpose,
            business_context=business_context,
            key_operations=key_operations[:10],  # Limitar a 10 operações principais
            decision_points=decision_points[:10]  # Limitar a 10 pontos de decisão
        )
    
    def extract_data_structures_from_code(self, cleaned_lines: List[Tuple[int, str]]) -> DataStructures:
        """Extrai estruturas de dados reais do código COBOL."""
        
        main_structures = []
        file_definitions = []
        working_storage = []
        copybooks = []
        
        in_working_storage = False
        in_file_section = False
        
        for line_num, line in cleaned_lines:
            line_upper = line.upper().strip()
            
            # Identificar seções
            if 'WORKING-STORAGE SECTION' in line_upper:
                in_working_storage = True
                in_file_section = False
            elif 'FILE SECTION' in line_upper:
                in_file_section = True
                in_working_storage = False
            elif 'PROCEDURE DIVISION' in line_upper:
                in_working_storage = False
                in_file_section = False
            
            # Extrair definições de arquivo
            if 'FD ' in line_upper or 'SELECT ' in line_upper:
                file_definitions.append(line.strip())
            
            # Extrair estruturas principais (01 level)
            if re.match(r'\s*01\s+', line_upper):
                structure_name = re.search(r'01\s+([A-Z0-9-]+)', line_upper)
                if structure_name:
                    main_structures.append(structure_name.group(1))
            
            # Extrair variáveis de working storage
            if in_working_storage and re.match(r'\s*\d+\s+', line_upper):
                working_storage.append(line.strip())
            
            # Identificar copybooks
            if 'COPY ' in line_upper:
                copy_match = re.search(r'COPY\s+([A-Z0-9-]+)', line_upper)
                if copy_match:
                    copybooks.append(copy_match.group(1))
        
        return DataStructures(
            main_structures=main_structures[:10],
            file_definitions=file_definitions[:5],
            working_storage=working_storage[:20],
            copybooks=copybooks
        )
    
    def extract_processing_flow_from_code(self, cleaned_lines: List[Tuple[int, str]]) -> ProcessingFlow:
        """Extrai fluxo de processamento real do código COBOL."""
        
        control_flow = []
        error_handling = []
        main_algorithm = "Processamento sequencial"
        technical_details = "Leitura, processamento e escrita de dados"
        
        perform_count = 0
        loop_count = 0
        file_ops_count = 0
        
        for line_num, line in cleaned_lines:
            line_upper = line.upper().strip()
            
            # Contar operações para inferir algoritmo
            if 'PERFORM' in line_upper:
                perform_count += 1
                control_flow.append(f"Linha {line_num}: {line.strip()}")
            
            if any(loop in line_upper for loop in ['UNTIL', 'WHILE', 'TIMES']):
                loop_count += 1
            
            if any(op in line_upper for op in ['READ', 'WRITE', 'OPEN', 'CLOSE']):
                file_ops_count += 1
            
            # Identificar tratamento de erros
            if any(err in line_upper for err in ['ERROR', 'EXCEPTION', 'INVALID', 'AT END']):
                error_handling.append(f"Linha {line_num}: {line.strip()}")
        
        # Inferir algoritmo principal baseado nas operações
        if loop_count > 0 and file_ops_count > 2:
            main_algorithm = "Processamento iterativo com controle de arquivo"
            technical_details = f"Loop principal com {loop_count} estruturas de repetição e {file_ops_count} operações de arquivo"
        elif perform_count > 5:
            main_algorithm = "Processamento modular com múltiplas rotinas"
            technical_details = f"Arquitetura modular com {perform_count} chamadas de rotina"
        elif file_ops_count > 4:
            main_algorithm = "Processamento intensivo de arquivos"
            technical_details = f"Múltiplas operações de arquivo ({file_ops_count} operações identificadas)"
        
        return ProcessingFlow(
            main_algorithm=main_algorithm,
            technical_details=technical_details,
            control_flow=control_flow[:10],
            error_handling=error_handling[:5]
        )
    
    def generate_algorithm_description(self, business_logic: BusinessLogic, 
                                     processing_flow: ProcessingFlow,
                                     validation_rules: List[Any]) -> str:
        """Gera descrição detalhada do algoritmo baseada nos dados extraídos."""
        
        algorithm = f"""ALGORITMO PRINCIPAL ({processing_flow.main_algorithm}):

1. INICIALIZAÇÃO:
   - Configuração do ambiente de processamento
   - Abertura de arquivos necessários
   - Inicialização de contadores e variáveis de controle

2. PROCESSAMENTO PRINCIPAL:
   {processing_flow.technical_details}
   
   Operações identificadas:
"""
        
        for i, operation in enumerate(business_logic.key_operations[:5], 1):
            algorithm += f"   {i}. {operation}\n"
        
        if business_logic.decision_points:
            algorithm += f"\n   Pontos de decisão críticos:\n"
            for decision in business_logic.decision_points[:3]:
                algorithm += f"   - {decision}\n"
        
        if validation_rules:
            algorithm += f"\n3. VALIDAÇÕES:\n"
            algorithm += f"   - {len(validation_rules)} regras de validação implementadas\n"
            for rule in validation_rules[:3]:
                if hasattr(rule, 'field'):
                    algorithm += f"   - Validação de {rule.field}: {rule.validation_type}\n"
        
        algorithm += f"\n4. FINALIZAÇÃO:\n"
        algorithm += f"   - Fechamento de arquivos\n"
        algorithm += f"   - Consolidação de resultados\n"
        algorithm += f"   - Retorno de status de processamento"
        
        return algorithm
    
    def generate_data_mapping(self, data_structures: DataStructures, target_language: str) -> str:
        """Gera mapeamento de estruturas de dados para linguagem alvo."""
        
        mapping = f"MAPEAMENTO DE ESTRUTURAS DE DADOS (COBOL → {target_language.upper()}):\n\n"
        
        # Mapeamento de tipos básicos
        if target_language.lower() == 'java':
            type_mapping = {
                'PIC X': 'String',
                'PIC 9': 'Integer/Long',
                'PIC 9V99': 'BigDecimal',
                'PIC S9': 'Integer (signed)'
            }
        elif target_language.lower() == 'python':
            type_mapping = {
                'PIC X': 'str',
                'PIC 9': 'int',
                'PIC 9V99': 'Decimal',
                'PIC S9': 'int'
            }
        else:
            type_mapping = {
                'PIC X': 'string',
                'PIC 9': 'number',
                'PIC 9V99': 'decimal',
                'PIC S9': 'signed_number'
            }
        
        mapping += "TIPOS BÁSICOS:\n"
        for cobol_type, target_type in type_mapping.items():
            mapping += f"- {cobol_type} → {target_type}\n"
        
        if data_structures.main_structures:
            mapping += f"\nESTRUTURAS PRINCIPAIS:\n"
            for structure in data_structures.main_structures:
                if target_language.lower() == 'java':
                    mapping += f"- {structure} → {structure.replace('-', '')}Class\n"
                elif target_language.lower() == 'python':
                    mapping += f"- {structure} → {structure.lower().replace('-', '_')} (dataclass)\n"
                else:
                    mapping += f"- {structure} → {structure}Structure\n"
        
        if data_structures.copybooks:
            mapping += f"\nCOPYBOOKS IDENTIFICADOS:\n"
            for copybook in data_structures.copybooks:
                mapping += f"- {copybook} → Implementar como módulo/classe separada\n"
        
        return mapping
