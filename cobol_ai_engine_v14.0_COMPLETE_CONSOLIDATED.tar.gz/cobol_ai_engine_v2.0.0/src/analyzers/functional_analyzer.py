#!/usr/bin/env python3.11
# -*- coding: utf-8 -*-
"""
COBOL AI Engine v3.0 - Functional Analyzer
Sistema de análise funcional específica para identificar padrões e lógicas COBOL

Autor: Manus AI
Data: 17 de Setembro de 2025
"""

import re
import logging
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass
from enum import Enum


class ProcessingPattern(Enum):
    """Padrões de processamento identificados."""
    FILE_SPLITTER = "file_splitter"
    FILE_MERGER = "file_merger"
    DATA_VALIDATOR = "data_validator"
    REPORT_GENERATOR = "report_generator"
    BATCH_PROCESSOR = "batch_processor"
    INTERFACE_PROCESSOR = "interface_processor"
    CALCULATION_ENGINE = "calculation_engine"
    DATA_TRANSFORMER = "data_transformer"


@dataclass
class FunctionalPattern:
    """Representa um padrão funcional identificado."""
    pattern_type: ProcessingPattern
    confidence: float
    description: str
    evidence: List[str]
    business_purpose: str
    technical_implementation: str
    key_components: List[str]


@dataclass
class DataFlow:
    """Representa fluxo de dados no programa."""
    source: str
    target: str
    transformation: str
    conditions: List[str]
    business_rule: str
    line_numbers: List[int]


@dataclass
class ValidationRule:
    """Representa uma regra de validação específica."""
    field_name: str
    validation_type: str
    condition: str
    error_action: str
    business_context: str
    line_number: int
    code_snippet: str


@dataclass
class FileProcessingLogic:
    """Representa lógica de processamento de arquivo."""
    input_file: str
    output_files: List[str]
    processing_type: str
    split_criteria: Optional[str]
    record_selection: List[str]
    transformations: List[str]
    validation_rules: List[ValidationRule]


@dataclass
class BusinessProcess:
    """Representa um processo de negócio identificado."""
    name: str
    description: str
    steps: List[str]
    inputs: List[str]
    outputs: List[str]
    business_rules: List[str]
    error_handling: List[str]
    integration_points: List[str]


class FunctionalAnalyzer:
    """
    Analisador funcional que identifica:
    - Padrões de processamento específicos
    - Lógica de quebra de arquivos
    - Regras de validação de negócio
    - Fluxos de dados e transformações
    - Processos de negócio implementados
    """
    
    def __init__(self):
        """Inicializa o analisador funcional."""
        self.logger = logging.getLogger(__name__)
        self._setup_pattern_detectors()
    
    def _setup_pattern_detectors(self):
        """Configura detectores de padrões funcionais."""
        
        # Padrões para identificar quebra de arquivos
        self.file_splitter_patterns = [
            re.compile(r'IF\s+.*SIZE.*GREATER.*THAN', re.IGNORECASE),
            re.compile(r'IF\s+.*COUNT.*GREATER.*THAN', re.IGNORECASE),
            re.compile(r'IF\s+.*RECORD.*COUNT.*>', re.IGNORECASE),
            re.compile(r'WRITE\s+.*S1.*', re.IGNORECASE),
            re.compile(r'WRITE\s+.*S2.*', re.IGNORECASE),
            re.compile(r'CLOSE.*OPEN.*', re.IGNORECASE),
        ]
        
        # Padrões para validação de dados
        self.validation_patterns = [
            re.compile(r'IF\s+.*NUMERIC', re.IGNORECASE),
            re.compile(r'IF\s+.*SPACES', re.IGNORECASE),
            re.compile(r'IF\s+.*ZEROS', re.IGNORECASE),
            re.compile(r'IF\s+.*HIGH-VALUES', re.IGNORECASE),
            re.compile(r'IF\s+.*LOW-VALUES', re.IGNORECASE),
            re.compile(r'IF\s+.*EQUAL', re.IGNORECASE),
            re.compile(r'IF\s+.*NOT\s+EQUAL', re.IGNORECASE),
            re.compile(r'IF\s+.*GREATER', re.IGNORECASE),
            re.compile(r'IF\s+.*LESS', re.IGNORECASE),
        ]
        
        # Padrões para transformação de dados
        self.transformation_patterns = [
            re.compile(r'MOVE\s+.*TO\s+.*', re.IGNORECASE),
            re.compile(r'COMPUTE\s+.*=.*', re.IGNORECASE),
            re.compile(r'ADD\s+.*TO\s+.*', re.IGNORECASE),
            re.compile(r'SUBTRACT\s+.*FROM\s+.*', re.IGNORECASE),
            re.compile(r'MULTIPLY\s+.*BY\s+.*', re.IGNORECASE),
            re.compile(r'DIVIDE\s+.*INTO\s+.*', re.IGNORECASE),
        ]
        
        # Padrões para controle de fluxo
        self.flow_control_patterns = [
            re.compile(r'PERFORM\s+.*UNTIL', re.IGNORECASE),
            re.compile(r'PERFORM\s+.*TIMES', re.IGNORECASE),
            re.compile(r'PERFORM\s+.*THRU', re.IGNORECASE),
            re.compile(r'GO\s+TO', re.IGNORECASE),
            re.compile(r'STOP\s+RUN', re.IGNORECASE),
        ]
        
        # Padrões para tratamento de erro
        self.error_handling_patterns = [
            re.compile(r'IF\s+.*ERROR', re.IGNORECASE),
            re.compile(r'IF\s+.*FILE-STATUS', re.IGNORECASE),
            re.compile(r'DISPLAY\s+.*ERROR', re.IGNORECASE),
            re.compile(r'MOVE\s+.*TO\s+RETURN-CODE', re.IGNORECASE),
            re.compile(r'STOP\s+RUN', re.IGNORECASE),
        ]
    
    def analyze_functionality(self, parsed_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analisa funcionalidade específica do programa COBOL.
        
        Args:
            parsed_data: Dados do parser avançado
            
        Returns:
            Análise funcional completa
        """
        try:
            # Identificar padrões principais
            main_patterns = self._identify_main_patterns(parsed_data)
            
            # Analisar lógica de processamento de arquivos
            file_processing = self._analyze_file_processing_logic(parsed_data)
            
            # Identificar regras de validação
            validation_rules = self._extract_validation_rules(parsed_data.get('cleaned_lines', []))
            
            # Mapear fluxos de dados
            data_flows = self._map_data_flows(parsed_data)
            
            # Identificar processos de negócio
            business_processes = self._identify_business_processes(parsed_data)
            
            # Analisar lógica de quebra de arquivo (específico)
            file_splitting_logic = self._analyze_file_splitting_logic(parsed_data)
            
            # Identificar pontos de integração
            integration_analysis = self._analyze_integrations(parsed_data)
            
            return {
                'main_patterns': main_patterns,
                'file_processing': file_processing,
                'validation_rules': validation_rules,
                'data_flows': data_flows,
                'business_processes': business_processes,
                'file_splitting_logic': file_splitting_logic,
                'integration_analysis': integration_analysis,
                'functional_summary': self._generate_functional_summary(
                    main_patterns, file_processing, business_processes
                )
            }
            
        except Exception as e:
            self.logger.error(f"Erro na análise funcional: {str(e)}")
            return {'error': str(e)}
    
    def _identify_main_patterns(self, parsed_data: Dict[str, Any]) -> List[FunctionalPattern]:
        """Identifica padrões funcionais principais."""
        patterns = []
        lines = parsed_data.get('cleaned_lines', [])
        files = parsed_data.get('files', {})
        
        # Verificar padrão de quebra de arquivo
        splitter_evidence = []
        for line_num, line in lines:
            for pattern in self.file_splitter_patterns:
                if pattern.search(line):
                    splitter_evidence.append(f"Linha {line_num}: {line}")
        
        if len(splitter_evidence) > 0:
            input_files = files.get('definitions', [])
            output_files = [f for f in files.get('definitions', []) if 'S1' in f.name or 'S2' in f.name]
            
            if len(input_files) > 0 and len(output_files) > 1:
                pattern = FunctionalPattern(
                    pattern_type=ProcessingPattern.FILE_SPLITTER,
                    confidence=0.9,
                    description="Programa que divide arquivo de entrada em múltiplos arquivos de saída baseado em critérios específicos",
                    evidence=splitter_evidence,
                    business_purpose="Segregar dados de entrada em diferentes categorias ou destinos para processamento especializado",
                    technical_implementation="Lê arquivo sequencialmente, aplica validações e critérios de seleção, grava em arquivos específicos",
                    key_components=["Leitura sequencial", "Validação de dados", "Critérios de seleção", "Múltiplas saídas"]
                )
                patterns.append(pattern)
        
        # Verificar padrão de validação
        validation_evidence = []
        for line_num, line in lines:
            for pattern in self.validation_patterns:
                if pattern.search(line):
                    validation_evidence.append(f"Linha {line_num}: {line}")
        
        if len(validation_evidence) > 10:
            pattern = FunctionalPattern(
                pattern_type=ProcessingPattern.DATA_VALIDATOR,
                confidence=0.8,
                description="Programa com foco em validação extensiva de dados de entrada",
                evidence=validation_evidence[:5],  # Primeiras 5 evidências
                business_purpose="Garantir qualidade e integridade dos dados antes do processamento",
                technical_implementation="Múltiplas validações condicionais com tratamento de erro",
                key_components=["Validações numéricas", "Validações de formato", "Tratamento de erro", "Controle de qualidade"]
            )
            patterns.append(pattern)
        
        return patterns
    
    def _analyze_file_processing_logic(self, parsed_data: Dict[str, Any]) -> FileProcessingLogic:
        """Analisa lógica específica de processamento de arquivos."""
        files = parsed_data.get('files', {})
        lines = parsed_data.get('cleaned_lines', [])
        
        # Identificar arquivos de entrada e saída
        input_files = []
        output_files = []
        
        for file_def in files.get('definitions', []):
            if file_def.name.startswith('E') or 'INPUT' in file_def.assign_to:
                input_files.append(file_def.name)
            elif file_def.name.startswith('S') or 'OUTPUT' in file_def.assign_to:
                output_files.append(file_def.name)
        
        # Analisar critérios de divisão
        split_criteria = None
        record_selection = []
        transformations = []
        
        for line_num, line in lines:
            # Procurar critérios de tamanho ou contagem
            if re.search(r'IF\s+.*COUNT.*GREATER', line, re.IGNORECASE):
                split_criteria = "Baseado em contagem de registros"
            elif re.search(r'IF\s+.*SIZE.*GREATER', line, re.IGNORECASE):
                split_criteria = "Baseado em tamanho do arquivo"
            
            # Identificar seleções de registro
            if re.search(r'IF\s+.*EQUAL.*THEN.*WRITE', line, re.IGNORECASE):
                record_selection.append(f"Seleção condicional: {line}")
            
            # Identificar transformações
            if re.search(r'MOVE\s+.*TO\s+.*', line, re.IGNORECASE):
                transformations.append(f"Transformação: {line}")
        
        # Identificar validações específicas
        validation_rules = self._extract_validation_rules(lines)
        
        return FileProcessingLogic(
            input_file=input_files[0] if input_files else "Não identificado",
            output_files=output_files,
            processing_type="Sequential file splitting with validation",
            split_criteria=split_criteria,
            record_selection=record_selection,
            transformations=transformations,
            validation_rules=validation_rules
        )
    
    def _extract_validation_rules(self, lines: List[Tuple[int, str]]) -> List[ValidationRule]:
        """Extrai regras de validação específicas."""
        validation_rules = []
        
        for line_num, line in lines:
            # Validação numérica
            if re.search(r'IF\s+.*NUMERIC', line, re.IGNORECASE):
                field_match = re.search(r'IF\s+([A-Z0-9\-]+)\s+.*NUMERIC', line, re.IGNORECASE)
                if field_match:
                    field_name = field_match.group(1)
                    rule = ValidationRule(
                        field_name=field_name,
                        validation_type="numeric",
                        condition="Campo deve ser numérico",
                        error_action="Rejeitar registro",
                        business_context="Garantir integridade de dados numéricos",
                        line_number=line_num,
                        code_snippet=line
                    )
                    validation_rules.append(rule)
            
            # Validação de espaços
            if re.search(r'IF\s+.*SPACES', line, re.IGNORECASE):
                field_match = re.search(r'IF\s+([A-Z0-9\-]+)\s+.*SPACES', line, re.IGNORECASE)
                if field_match:
                    field_name = field_match.group(1)
                    rule = ValidationRule(
                        field_name=field_name,
                        validation_type="not_blank",
                        condition="Campo não pode estar em branco",
                        error_action="Rejeitar registro",
                        business_context="Garantir preenchimento obrigatório",
                        line_number=line_num,
                        code_snippet=line
                    )
                    validation_rules.append(rule)
            
            # Validação de igualdade
            if re.search(r'IF\s+.*EQUAL', line, re.IGNORECASE):
                equal_match = re.search(r'IF\s+([A-Z0-9\-]+)\s+EQUAL\s+([A-Z0-9\-\'\"]+)', line, re.IGNORECASE)
                if equal_match:
                    field_name = equal_match.group(1)
                    expected_value = equal_match.group(2)
                    rule = ValidationRule(
                        field_name=field_name,
                        validation_type="equality",
                        condition=f"Campo deve ser igual a {expected_value}",
                        error_action="Processar condicionalmente",
                        business_context="Validação de valor específico",
                        line_number=line_num,
                        code_snippet=line
                    )
                    validation_rules.append(rule)
        
        return validation_rules
    
    def _map_data_flows(self, parsed_data: Dict[str, Any]) -> List[DataFlow]:
        """Mapeia fluxos de dados no programa."""
        data_flows = []
        lines = parsed_data.get('cleaned_lines', [])
        
        for line_num, line in lines:
            # MOVE statements
            move_match = re.search(r'MOVE\s+([A-Z0-9\-\(\)]+)\s+TO\s+([A-Z0-9\-\(\)]+)', line, re.IGNORECASE)
            if move_match:
                source = move_match.group(1)
                target = move_match.group(2)
                
                flow = DataFlow(
                    source=source,
                    target=target,
                    transformation="Direct copy",
                    conditions=[],
                    business_rule="Transferência direta de dados",
                    line_numbers=[line_num]
                )
                data_flows.append(flow)
            
            # COMPUTE statements
            compute_match = re.search(r'COMPUTE\s+([A-Z0-9\-]+)\s*=\s*(.+)', line, re.IGNORECASE)
            if compute_match:
                target = compute_match.group(1)
                expression = compute_match.group(2)
                
                flow = DataFlow(
                    source=expression,
                    target=target,
                    transformation="Mathematical calculation",
                    conditions=[],
                    business_rule="Cálculo matemático",
                    line_numbers=[line_num]
                )
                data_flows.append(flow)
        
        return data_flows
    
    def _identify_business_processes(self, parsed_data: Dict[str, Any]) -> List[BusinessProcess]:
        """Identifica processos de negócio implementados."""
        processes = []
        
        # Processo principal baseado na análise
        main_functionality = parsed_data.get('main_functionality', {})
        
        if main_functionality.get('type') == 'file_splitter':
            process = BusinessProcess(
                name="Processamento e Divisão de Arquivo",
                description="Processo que lê arquivo de operações, aplica validações e divide em arquivos específicos",
                steps=[
                    "1. Abrir arquivo de entrada (E1DQ0705)",
                    "2. Ler registros sequencialmente",
                    "3. Aplicar validações de negócio",
                    "4. Classificar registros válidos/inválidos",
                    "5. Gravar em arquivo de saída apropriado (S1DQ0705/S2DQ0705)",
                    "6. Fechar arquivos e finalizar processamento"
                ],
                inputs=main_functionality.get('input_files', []),
                outputs=main_functionality.get('output_files', []),
                business_rules=[
                    "Validar integridade dos dados de entrada",
                    "Segregar registros válidos dos inválidos",
                    "Manter auditoria de processamento",
                    "Garantir qualidade dos dados de saída"
                ],
                error_handling=[
                    "Registros inválidos são direcionados para arquivo de rejeição",
                    "Erros de sistema geram código de retorno específico",
                    "Log de processamento para auditoria"
                ],
                integration_points=[
                    "Sistema de origem dos dados (E1DQ0705)",
                    "Sistemas consumidores dos dados processados",
                    "Sistema de monitoramento e auditoria"
                ]
            )
            processes.append(process)
        
        return processes
    
    def _analyze_file_splitting_logic(self, parsed_data: Dict[str, Any]) -> Dict[str, Any]:
        """Analisa especificamente a lógica de quebra de arquivo."""
        lines = parsed_data.get('cleaned_lines', [])
        files = parsed_data.get('files', {})
        
        splitting_logic = {
            'detected': False,
            'criteria': [],
            'output_destinations': [],
            'decision_points': [],
            'size_controls': [],
            'record_routing': []
        }
        
        # Procurar evidências de quebra de arquivo
        for line_num, line in lines:
            # Critérios de tamanho
            if re.search(r'SIZE|COUNT|RECORD.*COUNT', line, re.IGNORECASE):
                splitting_logic['size_controls'].append({
                    'line': line_num,
                    'logic': line,
                    'type': 'size_control'
                })
            
            # Múltiplas escritas
            if re.search(r'WRITE.*S[12]', line, re.IGNORECASE):
                splitting_logic['output_destinations'].append({
                    'line': line_num,
                    'destination': line,
                    'type': 'output_routing'
                })
            
            # Pontos de decisão
            if re.search(r'IF.*THEN.*WRITE', line, re.IGNORECASE):
                splitting_logic['decision_points'].append({
                    'line': line_num,
                    'condition': line,
                    'type': 'conditional_routing'
                })
        
        # Determinar se há lógica de quebra
        if (len(splitting_logic['output_destinations']) > 1 or 
            len(splitting_logic['decision_points']) > 0):
            splitting_logic['detected'] = True
            splitting_logic['criteria'] = [
                "Validação de dados de entrada",
                "Classificação por tipo de registro",
                "Segregação de registros válidos/inválidos"
            ]
        
        return splitting_logic
    
    def _analyze_integrations(self, parsed_data: Dict[str, Any]) -> Dict[str, Any]:
        """Analisa integrações com outros sistemas."""
        lines = parsed_data.get('cleaned_lines', [])
        
        integrations = {
            'external_calls': [],
            'file_interfaces': [],
            'data_exchanges': []
        }
        
        for line_num, line in lines:
            # Chamadas externas
            call_match = re.search(r'CALL\s+[\'"]([A-Z0-9\-]+)[\'"]', line, re.IGNORECASE)
            if call_match:
                program = call_match.group(1)
                integrations['external_calls'].append({
                    'program': program,
                    'line': line_num,
                    'context': line,
                    'purpose': self._determine_call_purpose(program)
                })
        
        return integrations
    
    def _determine_call_purpose(self, program_name: str) -> str:
        """Determina o propósito de uma chamada externa."""
        if 'DRAM' in program_name:
            return "Validação de dados ou regras de negócio"
        elif 'LHBR' in program_name:
            return "Processamento específico de negócio"
        elif 'MZ' in program_name:
            return "Utilitário ou função auxiliar"
        else:
            return "Funcionalidade específica não identificada"
    
    def _generate_functional_summary(self, patterns: List[FunctionalPattern], 
                                   file_processing: FileProcessingLogic,
                                   business_processes: List[BusinessProcess]) -> Dict[str, Any]:
        """Gera resumo funcional do programa."""
        
        primary_pattern = patterns[0] if patterns else None
        
        return {
            'primary_function': primary_pattern.description if primary_pattern else "Não identificada",
            'confidence_level': primary_pattern.confidence if primary_pattern else 0.0,
            'business_value': primary_pattern.business_purpose if primary_pattern else "Não determinado",
            'technical_approach': primary_pattern.technical_implementation if primary_pattern else "Não determinado",
            'complexity_assessment': self._assess_complexity(patterns, file_processing, business_processes),
            'migration_considerations': self._generate_migration_notes(patterns, file_processing)
        }
    
    def _assess_complexity(self, patterns: List[FunctionalPattern], 
                          file_processing: FileProcessingLogic,
                          business_processes: List[BusinessProcess]) -> str:
        """Avalia complexidade do programa."""
        
        complexity_factors = 0
        
        if len(patterns) > 1:
            complexity_factors += 1
        
        if len(file_processing.validation_rules) > 10:
            complexity_factors += 1
        
        if len(file_processing.output_files) > 2:
            complexity_factors += 1
        
        if len(business_processes) > 1:
            complexity_factors += 1
        
        if complexity_factors >= 3:
            return "Alta - Múltiplos padrões e validações complexas"
        elif complexity_factors >= 2:
            return "Média - Processamento com validações moderadas"
        else:
            return "Baixa - Processamento direto com poucas validações"
    
    def _generate_migration_notes(self, patterns: List[FunctionalPattern],
                                 file_processing: FileProcessingLogic) -> List[str]:
        """Gera notas para migração do código."""
        notes = []
        
        if any(p.pattern_type == ProcessingPattern.FILE_SPLITTER for p in patterns):
            notes.append("Implementar lógica de divisão de arquivo com streams ou processamento em lote")
            notes.append("Considerar uso de frameworks de processamento de arquivo (Apache Camel, Spring Batch)")
        
        if len(file_processing.validation_rules) > 5:
            notes.append("Implementar sistema de validação robusto com Bean Validation ou similar")
            notes.append("Considerar padrão Strategy para diferentes tipos de validação")
        
        if len(file_processing.output_files) > 1:
            notes.append("Implementar padrão Router para direcionamento de registros")
            notes.append("Usar configuração externa para definir critérios de roteamento")
        
        return notes
