"""
Extrator de Lógica de Decisão Específica
Identifica critérios exatos de segregação e roteamento de dados
"""

import re
import logging
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from enum import Enum

class DecisionType(Enum):
    IF_CONDITION = "IF"
    EVALUATE_WHEN = "EVALUATE"
    FILE_ROUTING = "FILE_ROUTING"
    VALIDATION_RULE = "VALIDATION"

@dataclass
class DecisionCondition:
    condition_type: DecisionType
    field_name: str
    operator: str
    value: str
    line_number: int
    context: str
    action_true: str

@dataclass
class FileRoutingRule:
    output_file: str
    conditions: List[DecisionCondition]
    priority: int
    description: str

@dataclass
class DecisionLogicAnalysis:
    routing_rules: List[FileRoutingRule]
    validation_conditions: List[DecisionCondition]
    business_logic_conditions: List[DecisionCondition]
    complexity_score: int
    decision_tree: Dict[str, Any]

class DecisionLogicExtractor:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.if_pattern = re.compile(r'IF\s+([A-Z0-9\-]+)\s*(=|>|<|>=|<=|NOT\s*=|IS\s+NOT|IS)\s*([\'\"]?[^\'\"\s]+[\'\"]?)', re.IGNORECASE)
        self.evaluate_pattern = re.compile(r'EVALUATE\s+(.+)', re.IGNORECASE)
        self.when_pattern = re.compile(r'WHEN\s+(.+)', re.IGNORECASE)
        self.write_pattern = re.compile(r'WRITE\s+([A-Z0-9\-]+-RECORD)', re.IGNORECASE)

    def extract_decision_logic(self, cobol_lines: List[str], files: List[Dict[str, Any]]) -> DecisionLogicAnalysis:
        self.logger.info("Iniciando extração de lógica de decisão")
        validation_conditions = self._extract_validation_conditions(cobol_lines)
        business_conditions = self._extract_business_logic_conditions(cobol_lines)
        routing_rules = self._extract_file_routing_rules(cobol_lines, files)
        complexity_score = len(validation_conditions) + len(business_conditions)
        decision_tree = self._build_decision_tree(routing_rules, validation_conditions)

        return DecisionLogicAnalysis(
            routing_rules=routing_rules,
            validation_conditions=validation_conditions,
            business_logic_conditions=business_conditions,
            complexity_score=complexity_score,
            decision_tree=decision_tree
        )

    def _extract_validation_conditions(self, lines: List[str]) -> List[DecisionCondition]:
        return [] # Simplificado por enquanto

    def _extract_business_logic_conditions(self, lines: List[str]) -> List[DecisionCondition]:
        conditions = []
        in_evaluate = False
        evaluate_target = None

        for i, line in enumerate(lines):
            content = line[7:].strip()
            if not content or content.startswith('*'):
                continue

            if_match = self.if_pattern.search(content)
            if if_match:
                field, op, value = if_match.groups()
                conditions.append(DecisionCondition(DecisionType.IF_CONDITION, field, op, value, i + 1, content, self._find_next_action(lines, i)))

            eval_match = self.evaluate_pattern.match(content)
            if eval_match:
                in_evaluate = True
                evaluate_target = eval_match.group(1)
                continue

            if in_evaluate:
                if 'END-EVALUATE' in content.upper():
                    in_evaluate = False
                    evaluate_target = None
                    continue
                
                when_match = self.when_pattern.match(content)
                if when_match:
                    value = when_match.group(1)
                    conditions.append(DecisionCondition(DecisionType.EVALUATE_WHEN, evaluate_target, 'EQUALS', value, i + 1, content, self._find_next_action(lines, i)))
        return conditions

    def _extract_file_routing_rules(self, lines: List[str], files: List[Dict[str, Any]]) -> List[FileRoutingRule]:
        rules = []
        output_files = [f for f in files if f['operation'] in ['OUTPUT', 'I-O', 'EXTEND']]
        
        for i, line in enumerate(lines):
            content = line[7:].strip()
            if not content or content.startswith('*'):
                continue

            write_match = self.write_pattern.search(content)
            if write_match:
                record_name = write_match.group(1)
                # Simplificação: assume que o nome do arquivo pode ser derivado do nome do registro
                # Numa implementação real, seria necessário mapear FD -> record -> file
                for f in output_files:
                    if f['logical_name'] in record_name: # Heurística
                        conditions = self._find_preceding_conditions(lines, i)
                        rules.append(FileRoutingRule(f['physical_name'], conditions, len(rules) + 1, "Regra de escrita para " + f['physical_name']))
                        break
        return rules

    def _find_preceding_conditions(self, lines: List[str], start_index: int) -> List[DecisionCondition]:
        conditions = []
        for i in range(max(0, start_index - 10), start_index):
            content = lines[i][7:].strip()
            if 'IF' in content.upper():
                if_match = self.if_pattern.search(content)
                if if_match:
                    field, op, value = if_match.groups()
                    conditions.append(DecisionCondition(DecisionType.FILE_ROUTING, field, op, value, i + 1, content, self._find_next_action(lines, i)))
        return conditions

    def _find_next_action(self, lines: List[str], start_index: int) -> str:
        for i in range(start_index + 1, min(start_index + 5, len(lines))):
            action_line = lines[i][7:].strip()
            if action_line and not action_line.startswith('*'):
                return action_line
        return "Ação não identificada"

    def _build_decision_tree(self, routing_rules: List[FileRoutingRule], validation_conditions: List[DecisionCondition]) -> Dict[str, Any]:
        tree = {'validations': [], 'routing': {}}
        for v in validation_conditions:
            tree['validations'].append(v.context)
        for r in routing_rules:
            tree['routing'][r.output_file] = [c.context for c in r.conditions]
        return tree

