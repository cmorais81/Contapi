import os
import re
import logging
from typing import List, Dict

class MultiProgramCOBOLParser:
    def __init__(self, books_dir: str = None):
        self.logger = logging.getLogger(__name__)
        self.books_dir = books_dir or ""
        self.copy_pattern = re.compile(r"^\s*COPY\s+([A-Z0-9\-]+)\s*\.", re.IGNORECASE)

    def extract_programs_from_file(self, programs_file: str) -> Dict[str, str]:
        """Extrai programas do arquivo fontes.txt."""
        programs = {}
        
        with open(programs_file, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        
        # Divide por programas (assumindo que cada programa começa com IDENTIFICATION DIVISION)
        program_sections = re.split(r'(?=\s*IDENTIFICATION\s+DIVISION)', content, flags=re.IGNORECASE)
        
        for i, section in enumerate(program_sections):
            if section.strip():
                # Extrai nome do programa
                program_name_match = re.search(r'PROGRAM-ID\.\s*([A-Z0-9-]+)', section, re.IGNORECASE)
                if program_name_match:
                    program_name = program_name_match.group(1)
                else:
                    program_name = f"PROGRAM_{i:03d}"
                
                programs[program_name] = section.strip()
        
        return programs

    def extract_copybooks_from_file(self, copybooks_file: str) -> List[str]:
        """Extrai lista de copybooks do arquivo books.txt."""
        copybooks = []
        
        with open(copybooks_file, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        
        # Procura por nomes de copybooks (assumindo formato padrão)
        copybook_matches = re.findall(r'([A-Z0-9-]+)(?:\s|$)', content)
        copybooks.extend(copybook_matches)
        
        return list(set(copybooks))  # Remove duplicatas

    def parse(self, program_path: str) -> List[str]:
        self.logger.info(f"Iniciando o parsing do programa: {program_path}")
        
        with open(program_path, 'r', encoding='latin-1') as f:
            program_lines = f.readlines()

        resolved_lines = []
        for line in program_lines:
            match = self.copy_pattern.search(line)
            if match:
                book_name = match.group(1)
                resolved_lines.extend(self._resolve_copy(book_name))
            else:
                resolved_lines.append(line)
        
        self.logger.info(f"Parsing do programa {program_path} concluído com a resolução dos copybooks.")
        return resolved_lines

    def _resolve_copy(self, book_name: str) -> List[str]:
        book_path = os.path.join(self.books_dir, f"{book_name}.cpy")
        if os.path.exists(book_path):
            self.logger.info(f"Resolvendo COPY para o book: {book_name}")
            with open(book_path, 'r', encoding='latin-1') as f:
                return f.readlines()
        else:
            self.logger.warning(f"Book {book_name} não encontrado em {self.books_dir}")
            return [f"* COPY {book_name} NOT FOUND\n"]

