#!/usr/bin/env python3.11
# -*- coding: utf-8 -*-
"""
COBOL AI Engine v2.3.0 - Preset Manager
Sistema de presets pré-configurados para simplificar uso

Autor: Manus AI
Data: 17 de Setembro de 2025
"""

import logging
import os
from typing import Dict, Any, List, Optional
from dataclasses import dataclass


@dataclass
class PresetInfo:
    """Informações de um preset."""
    name: str
    description: str
    use_case: str
    target_audience: str
    estimated_time: str
    config: Dict[str, Any]


class PresetManager:
    """
    Gerenciador de presets pré-configurados.
    
    Baseado na avaliação crítica, implementa presets para:
    - Simplificar configuração complexa
    - Reduzir barreira de entrada
    - Casos de uso específicos
    """
    
    def __init__(self):
        """Inicializa o gerenciador de presets."""
        self.logger = logging.getLogger(__name__)
        self.presets = self._initialize_presets()
        self.logger.info(f"Preset Manager inicializado com {len(self.presets)} presets")
    
    def _initialize_presets(self) -> Dict[str, PresetInfo]:
        """Inicializa presets baseados na avaliação crítica."""
        
        presets = {}
        
        # PRESET 1: PROGRAMMER_READY - Para programadores que querem reimplementar
        presets['programmer_ready'] = PresetInfo(
            name="programmer_ready",
            description="Documentação técnica detalhada para reimplementação em outras linguagens",
            use_case="Programador experiente quer entender lógica completa para reimplementar",
            target_audience="Desenvolvedores sênior, arquitetos de software",
            estimated_time="2-3 minutos por programa",
            config={
                'ai': {
                    'primary_provider': 'luzia',
                    'global_temperature': 0.01,  # Máxima precisão técnica
                    'global_max_tokens': 12000,  # Análise muito detalhada
                },
                'multi_provider': {
                    'enabled': True,
                    'combination_strategy': 'primary_enhanced',
                    'parallel_execution': True,
                    'consensus_threshold': 0.8,
                },
                'programmer_documentation': {
                    'target_language': 'java',
                    'migration_focus': True,
                    'include_problems': True,
                    'include_code_examples': True,
                    'include_data_mapping': True,
                    'include_business_logic_flow': True,
                    'include_implementation_guide': True,
                },
                'analysis_depth': 'maximum',
                'include_sections': [
                    'functional_analysis',
                    'technical_architecture', 
                    'business_rules_detailed',
                    'data_structures_mapping',
                    'algorithm_explanation',
                    'implementation_examples',
                    'migration_roadmap',
                    'quality_assessment'
                ]
            }
        )
        
        # PRESET 2: QUICK_OVERVIEW - Análise rápida para visão geral
        presets['quick_overview'] = PresetInfo(
            name="quick_overview",
            description="Análise rápida para compreensão geral do sistema",
            use_case="Primeira análise para entender o que o programa faz",
            target_audience="Gerentes técnicos, novos membros da equipe",
            estimated_time="30-60 segundos por programa",
            config={
                'ai': {
                    'primary_provider': 'luzia',
                    'global_temperature': 0.1,
                    'global_max_tokens': 4000,
                },
                'multi_provider': {
                    'enabled': False,
                },
                'programmer_documentation': {
                    'target_language': 'java',
                    'migration_focus': False,
                    'include_problems': False,
                },
                'analysis_depth': 'summary',
                'include_sections': [
                    'program_purpose',
                    'main_functions',
                    'business_rules_summary',
                    'key_dependencies'
                ]
            }
        )
        
        # PRESET 3: MIGRATION_READY - Foco em migração de sistemas
        presets['migration_ready'] = PresetInfo(
            name="migration_ready",
            description="Análise completa focada em migração para tecnologias modernas",
            use_case="Projeto de modernização de mainframe",
            target_audience="Arquitetos de migração, equipes de modernização",
            estimated_time="3-5 minutos por programa",
            config={
                'ai': {
                    'primary_provider': 'luzia',
                    'global_temperature': 0.02,
                    'global_max_tokens': 15000,
                },
                'multi_provider': {
                    'enabled': True,
                    'combination_strategy': 'consensus_first',
                    'parallel_execution': True,
                    'consensus_threshold': 0.85,
                    'secondary_providers': ['copilot']
                },
                'programmer_documentation': {
                    'target_language': 'java',
                    'migration_focus': True,
                    'include_problems': True,
                    'include_modernization_suggestions': True,
                    'include_architecture_patterns': True,
                    'include_technology_mapping': True,
                },
                'analysis_depth': 'maximum',
                'include_sections': [
                    'migration_assessment',
                    'technology_mapping',
                    'architecture_modernization',
                    'risk_analysis',
                    'effort_estimation',
                    'implementation_phases'
                ]
            }
        )
        
        # PRESET 4: CODE_AUDIT - Auditoria de qualidade de código
        presets['code_audit'] = PresetInfo(
            name="code_audit",
            description="Auditoria focada em qualidade, problemas e oportunidades de melhoria",
            use_case="Revisão de código e identificação de débito técnico",
            target_audience="Tech leads, auditores de código",
            estimated_time="2-3 minutos por programa",
            config={
                'ai': {
                    'primary_provider': 'copilot',  # Copilot é melhor para detectar problemas
                    'global_temperature': 0.05,
                    'global_max_tokens': 8000,
                },
                'multi_provider': {
                    'enabled': True,
                    'combination_strategy': 'weighted_merge',
                    'provider_weights': {
                        'copilot': 0.7,  # Maior peso para detecção de problemas
                        'luzia': 0.3
                    }
                },
                'programmer_documentation': {
                    'include_problems': True,
                    'include_security_analysis': True,
                    'include_performance_analysis': True,
                    'include_maintainability_score': True,
                },
                'analysis_depth': 'detailed',
                'include_sections': [
                    'code_quality_assessment',
                    'security_vulnerabilities',
                    'performance_bottlenecks',
                    'maintainability_issues',
                    'refactoring_opportunities',
                    'best_practices_violations'
                ]
            }
        )
        
        # PRESET 5: BUSINESS_FOCUS - Foco em regras de negócio
        presets['business_focus'] = PresetInfo(
            name="business_focus",
            description="Extração e documentação detalhada de regras de negócio",
            use_case="Documentação funcional para analistas de negócio",
            target_audience="Analistas de negócio, product owners",
            estimated_time="1-2 minutos por programa",
            config={
                'ai': {
                    'primary_provider': 'luzia',  # LuzIA é melhor para contexto de negócio
                    'global_temperature': 0.1,
                    'global_max_tokens': 6000,
                },
                'multi_provider': {
                    'enabled': False,
                },
                'programmer_documentation': {
                    'migration_focus': False,
                    'include_problems': False,
                    'focus_business_rules': True,
                },
                'analysis_depth': 'business_focused',
                'include_sections': [
                    'business_purpose',
                    'business_rules_detailed',
                    'process_flows',
                    'decision_points',
                    'validation_rules',
                    'calculation_logic'
                ]
            }
        )
        
        return presets
    
    def get_preset(self, preset_name: str) -> Optional[PresetInfo]:
        """Retorna informações de um preset específico."""
        return self.presets.get(preset_name)
    
    def list_presets(self) -> List[PresetInfo]:
        """Lista todos os presets disponíveis."""
        return list(self.presets.values())
    
    def apply_preset(self, preset_name: str, base_config: Dict[str, Any]) -> Dict[str, Any]:
        """
        Aplica um preset à configuração base.
        
        Args:
            preset_name: Nome do preset
            base_config: Configuração base do sistema
            
        Returns:
            Configuração modificada com o preset aplicado
        """
        preset = self.get_preset(preset_name)
        if not preset:
            self.logger.error(f"Preset '{preset_name}' não encontrado")
            return base_config
        
        # Fazer deep merge da configuração
        merged_config = self._deep_merge(base_config.copy(), preset.config)
        
        # Adicionar metadados do preset
        merged_config['_preset_applied'] = {
            'name': preset.name,
            'description': preset.description,
            'use_case': preset.use_case,
            'target_audience': preset.target_audience,
            'estimated_time': preset.estimated_time
        }
        
        self.logger.info(f"Preset '{preset_name}' aplicado com sucesso")
        return merged_config
    
    def _deep_merge(self, base: Dict[str, Any], overlay: Dict[str, Any]) -> Dict[str, Any]:
        """Faz merge profundo de duas configurações."""
        for key, value in overlay.items():
            if key in base and isinstance(base[key], dict) and isinstance(value, dict):
                base[key] = self._deep_merge(base[key], value)
            else:
                base[key] = value
        return base
    
    def get_preset_recommendations(self, context: Dict[str, Any]) -> List[str]:
        """
        Recomenda presets baseado no contexto de uso.
        
        Args:
            context: Contexto com informações sobre o uso pretendido
            
        Returns:
            Lista de nomes de presets recomendados
        """
        recommendations = []
        
        # Lógica de recomendação baseada no contexto
        if context.get('purpose') == 'migration':
            recommendations.extend(['migration_ready', 'programmer_ready'])
        elif context.get('purpose') == 'understanding':
            recommendations.extend(['programmer_ready', 'quick_overview'])
        elif context.get('purpose') == 'audit':
            recommendations.extend(['code_audit', 'programmer_ready'])
        elif context.get('purpose') == 'business':
            recommendations.extend(['business_focus', 'quick_overview'])
        else:
            # Recomendação padrão
            recommendations.extend(['programmer_ready', 'quick_overview'])
        
        return recommendations[:3]  # Máximo 3 recomendações
    
    def validate_preset_compatibility(self, preset_name: str, 
                                    available_providers: List[str]) -> bool:
        """
        Valida se um preset é compatível com os providers disponíveis.
        
        Args:
            preset_name: Nome do preset
            available_providers: Lista de providers disponíveis
            
        Returns:
            True se compatível, False caso contrário
        """
        preset = self.get_preset(preset_name)
        if not preset:
            return False
        
        # Verificar provider primário
        primary_provider = preset.config.get('ai', {}).get('primary_provider')
        if primary_provider and primary_provider not in available_providers:
            return False
        
        # Verificar providers secundários se multi-provider estiver habilitado
        multi_config = preset.config.get('multi_provider', {})
        if multi_config.get('enabled', False):
            secondary_providers = multi_config.get('secondary_providers', [])
            for provider in secondary_providers:
                if provider not in available_providers:
                    return False
        
        return True
    
    def get_preset_summary(self) -> str:
        """Retorna um resumo de todos os presets disponíveis."""
        summary_lines = []
        summary_lines.append("PRESETS DISPONÍVEIS:")
        summary_lines.append("=" * 50)
        
        for preset in self.presets.values():
            summary_lines.append(f"\n📋 {preset.name.upper()}")
            summary_lines.append(f"   Descrição: {preset.description}")
            summary_lines.append(f"   Caso de Uso: {preset.use_case}")
            summary_lines.append(f"   Público: {preset.target_audience}")
            summary_lines.append(f"   Tempo Estimado: {preset.estimated_time}")
        
        return "\n".join(summary_lines)
