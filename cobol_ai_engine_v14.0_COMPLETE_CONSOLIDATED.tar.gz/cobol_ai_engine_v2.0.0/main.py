#!/usr/bin/env python3
"""
COBOL AI Engine v14.0 - ENTENDIMENTO CONCEITUAL
Versão focada em maximizar o entendimento conceitual dos programas COBOL
"""

import os
import sys
import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, List

# Adiciona o diretório src ao path
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

# Importações dos novos analisadores v14.0
from analyzers.purpose_extractor import PurposeExtractor
from analyzers.simple_flow_mapper import SimpleFlowMapper
from generators.executive_summary_generator import ExecutiveSummaryGenerator

# Importações dos parsers
from parsers.multi_program_cobol_parser import MultiProgramCOBOLParser

class COBOLConceptualAnalyzer:
    """
    COBOL AI Engine v14.0 - ENTENDIMENTO CONCEITUAL
    
    Focado especificamente em maximizar a capacidade de entender
    e explicar o que cada programa COBOL faz, baseado no feedback
    positivo do usuário.
    """

    def __init__(self):
        self.setup_logging()
        self.logger = logging.getLogger(__name__)
        
        # Inicializa componentes focados em entendimento
        self.parser = MultiProgramCOBOLParser()
        self.purpose_extractor = PurposeExtractor()
        self.flow_mapper = SimpleFlowMapper()
        self.summary_generator = ExecutiveSummaryGenerator()
        
        self.logger.info("COBOL Conceptual Analyzer v14.0 inicializado")

    def setup_logging(self):
        """Configura logging."""
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler('cobol_conceptual_v14.log'),
                logging.StreamHandler()
            ]
        )

    def analyze_program_for_understanding(self, program_path: str) -> Dict[str, Any]:
        """
        Analisa um programa COBOL focando no entendimento conceitual.
        """
        program_name = Path(program_path).stem
        self.logger.info(f"Analisando {program_name} para entendimento conceitual")
        
        try:
            # 1. Carrega o programa
            with open(program_path, 'r', encoding='utf-8', errors='ignore') as f:
                code_lines = f.readlines()
            
            code_lines = [line.rstrip() for line in code_lines]
            self.logger.info(f"Programa carregado: {len(code_lines)} linhas")
            
            # 2. Extrai propósito principal
            self.logger.info("Extraindo propósito principal...")
            purpose = self.purpose_extractor.extract_purpose(program_name, code_lines)
            
            # 3. Mapeia fluxo de processamento
            self.logger.info("Mapeando fluxo de processamento...")
            flow = self.flow_mapper.map_flow(program_name, code_lines)
            
            # 4. Gera resumo executivo
            self.logger.info("Gerando resumo executivo...")
            
            # Converte dados para dicionários
            purpose_data = {
                'main_purpose': purpose.main_purpose,
                'action_verb': purpose.action_verb,
                'business_domain': purpose.business_domain,
                'input_files': purpose.input_files,
                'output_files': purpose.output_files,
                'confidence': purpose.confidence
            }
            
            flow_data = {
                'overall_flow': flow.overall_flow,
                'steps_count': len(flow.steps),
                'decision_points': flow.decision_points,
                'error_handling': flow.error_handling
            }
            
            summary = self.summary_generator.generate_summary(
                program_name, purpose_data, flow_data
            )
            
            # 5. Compila resultado final
            analysis_result = {
                "program_name": program_name,
                "analysis_timestamp": datetime.now().isoformat(),
                "version": "14.0 - CONCEPTUAL UNDERSTANDING",
                "total_lines": len(code_lines),
                
                # Dados principais para entendimento
                "purpose": {
                    "one_line_summary": summary.one_line_summary,
                    "main_purpose": purpose.main_purpose,
                    "action_verb": purpose.action_verb,
                    "business_domain": purpose.business_domain,
                    "confidence": purpose.confidence
                },
                
                "flow": {
                    "overall_description": flow.overall_flow,
                    "total_steps": len(flow.steps),
                    "key_decisions": flow.decision_points[:3],  # Top 3
                    "has_error_handling": len(flow.error_handling) > 0
                },
                
                "files": {
                    "input_files": purpose.input_files,
                    "output_files": purpose.output_files,
                    "total_files": len(purpose.input_files) + len(purpose.output_files)
                },
                
                "summary": {
                    "what_it_does": summary.what_it_does,
                    "why_it_exists": summary.why_it_exists,
                    "business_impact": summary.business_impact,
                    "key_numbers": summary.key_numbers,
                    "main_dependencies": summary.dependencies[:3],  # Top 3
                    "main_risks": summary.risks[:3]  # Top 3
                },
                
                # Capacidade de explicação
                "explainability": {
                    "can_explain_purpose": purpose.confidence > 0.3,
                    "can_explain_flow": len(flow.steps) > 0,
                    "can_identify_files": len(purpose.input_files + purpose.output_files) > 0,
                    "overall_understanding": self._calculate_understanding_score(purpose, flow, summary)
                }
            }
            
            self.logger.info(f"Análise de {program_name} concluída com sucesso")
            return analysis_result
            
        except Exception as e:
            self.logger.error(f"Erro na análise de {program_name}: {str(e)}")
            return {
                "program_name": program_name,
                "error": str(e),
                "analysis_timestamp": datetime.now().isoformat(),
                "version": "14.0 - CONCEPTUAL UNDERSTANDING"
            }

    def _calculate_understanding_score(self, purpose, flow, summary) -> float:
        """Calcula score de entendimento geral."""
        score = 0.0
        
        # Propósito identificado (30%)
        if purpose.confidence > 0.7:
            score += 0.3
        elif purpose.confidence > 0.4:
            score += 0.2
        elif purpose.confidence > 0.1:
            score += 0.1
        
        # Fluxo mapeado (25%)
        if len(flow.steps) >= 3:
            score += 0.25
        elif len(flow.steps) >= 1:
            score += 0.15
        
        # Arquivos identificados (25%)
        total_files = len(purpose.input_files) + len(purpose.output_files)
        if total_files >= 3:
            score += 0.25
        elif total_files >= 1:
            score += 0.15
        
        # Resumo gerado (20%)
        if summary.what_it_does and len(summary.what_it_does) > 20:
            score += 0.2
        elif summary.what_it_does:
            score += 0.1
        
        return min(score, 1.0)

    def generate_understanding_report(self, analysis_result: Dict[str, Any], 
                                    output_dir: str) -> str:
        """Gera relatório focado no entendimento conceitual."""
        program_name = analysis_result["program_name"]
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        # Relatório principal
        main_report_path = output_path / f"{program_name}_UNDERSTANDING_v14.md"
        
        # Verifica se houve erro
        if "error" in analysis_result:
            error_report = [
                f"# ❌ Erro na Análise - {program_name}",
                f"**Versão:** {analysis_result.get('version', '14.0')}",
                f"**Data:** {analysis_result.get('analysis_timestamp', 'N/A')}",
                "",
                f"**Erro:** {analysis_result['error']}",
                "",
                "## 🔧 Recomendações",
                "1. Verifique se o arquivo COBOL está acessível",
                "2. Confirme se o formato do arquivo está correto",
                "3. Tente novamente com um arquivo menor para teste"
            ]
            
            with open(main_report_path, 'w', encoding='utf-8') as f:
                f.write('\n'.join(error_report))
            
            return str(main_report_path)
        
        # Extrai dados para o relatório
        purpose = analysis_result.get("purpose", {})
        flow = analysis_result.get("flow", {})
        files = analysis_result.get("files", {})
        summary = analysis_result.get("summary", {})
        explainability = analysis_result.get("explainability", {})
        
        # Constrói relatório
        report_sections = []
        
        # Cabeçalho
        understanding_score = explainability.get("overall_understanding", 0)
        score_emoji = "🟢" if understanding_score > 0.7 else "🟡" if understanding_score > 0.4 else "🔴"
        
        report_sections.extend([
            f"# 🎯 Relatório de Entendimento - {program_name}",
            f"**Versão:** {analysis_result.get('version', '14.0')}",
            f"**Data:** {analysis_result.get('analysis_timestamp', 'N/A')}",
            f"**Linhas de Código:** {analysis_result.get('total_lines', 0):,}",
            f"**Score de Entendimento:** {score_emoji} {understanding_score:.1%}",
            "",
            "---",
            ""
        ])
        
        # Resumo em uma frase
        one_line = purpose.get("one_line_summary", "Propósito não identificado")
        report_sections.extend([
            "## 🎯 RESUMO EM UMA FRASE",
            f"**{one_line}**",
            "",
            "---",
            ""
        ])
        
        # O que faz
        what_it_does = summary.get("what_it_does", "Funcionalidade não identificada")
        report_sections.extend([
            "## 🔍 O QUE O PROGRAMA FAZ",
            what_it_does,
            "",
            "---",
            ""
        ])
        
        # Fluxo simplificado
        overall_flow = flow.get("overall_description", "Fluxo não identificado")
        input_files = files.get("input_files", [])
        output_files = files.get("output_files", [])
        
        report_sections.extend([
            "## 🔄 FLUXO SIMPLIFICADO",
            f"**Padrão:** {overall_flow}",
            ""
        ])
        
        # Fluxo visual
        if input_files or output_files:
            input_str = " + ".join(input_files[:3]) if input_files else "ENTRADA"
            output_str = " + ".join(output_files[:3]) if output_files else "SAÍDA"
            action = purpose.get("action_verb", "PROCESSAR")
            
            report_sections.extend([
                "```",
                f"{input_str} → [{action}] → {output_str}",
                "```",
                ""
            ])
        
        # Arquivos detalhados
        if input_files or output_files:
            report_sections.extend([
                "### 📁 Arquivos Identificados",
                ""
            ])
            
            if input_files:
                report_sections.append("**Entrada:**")
                for file in input_files:
                    report_sections.append(f"- {file}")
                report_sections.append("")
            
            if output_files:
                report_sections.append("**Saída:**")
                for file in output_files:
                    report_sections.append(f"- {file}")
                report_sections.append("")
        
        report_sections.append("---\n")
        
        # Por que existe
        why_exists = summary.get("why_it_exists", "Justificativa não identificada")
        report_sections.extend([
            "## 💼 POR QUE ESTE PROGRAMA EXISTE",
            why_exists,
            "",
            "---",
            ""
        ])
        
        # Impacto no negócio
        business_impact = summary.get("business_impact", "Impacto não avaliado")
        report_sections.extend([
            "## 📈 IMPACTO NO NEGÓCIO",
            business_impact,
            "",
            "---",
            ""
        ])
        
        # Números importantes
        key_numbers = summary.get("key_numbers", {})
        if key_numbers:
            report_sections.extend([
                "## 📊 NÚMEROS IMPORTANTES",
                ""
            ])
            
            for key, value in key_numbers.items():
                key_formatted = key.replace('_', ' ').title()
                report_sections.append(f"- **{key_formatted}:** {value}")
            
            report_sections.extend(["", "---", ""])
        
        # Pontos de decisão
        decisions = flow.get("key_decisions", [])
        if decisions:
            report_sections.extend([
                "## ⚡ PRINCIPAIS DECISÕES DO PROGRAMA",
                ""
            ])
            
            for i, decision in enumerate(decisions, 1):
                report_sections.append(f"{i}. {decision}")
            
            report_sections.extend(["", "---", ""])
        
        # Dependências
        dependencies = summary.get("main_dependencies", [])
        if dependencies:
            report_sections.extend([
                "## 🔗 PRINCIPAIS DEPENDÊNCIAS",
                ""
            ])
            
            for dep in dependencies:
                report_sections.append(f"- {dep}")
            
            report_sections.extend(["", "---", ""])
        
        # Riscos
        risks = summary.get("main_risks", [])
        if risks:
            report_sections.extend([
                "## ⚠️ PRINCIPAIS RISCOS",
                ""
            ])
            
            for risk in risks:
                report_sections.append(f"- {risk}")
            
            report_sections.extend(["", "---", ""])
        
        # Capacidade de explicação
        report_sections.extend([
            "## 🎯 CAPACIDADE DE EXPLICAÇÃO",
            "",
            f"✅ **Posso explicar o propósito:** {'SIM' if explainability.get('can_explain_purpose') else 'NÃO'}",
            f"✅ **Posso explicar o fluxo:** {'SIM' if explainability.get('can_explain_flow') else 'NÃO'}",
            f"✅ **Posso identificar arquivos:** {'SIM' if explainability.get('can_identify_files') else 'NÃO'}",
            f"✅ **Entendimento geral:** {understanding_score:.1%}",
            "",
            "---",
            ""
        ])
        
        # Conclusão
        if understanding_score > 0.7:
            conclusion = "🟢 **EXCELENTE** - Programa bem compreendido, posso explicar claramente sua funcionalidade"
        elif understanding_score > 0.4:
            conclusion = "🟡 **BOM** - Programa parcialmente compreendido, posso explicar os aspectos principais"
        else:
            conclusion = "🔴 **LIMITADO** - Compreensão limitada, requer análise manual adicional"
        
        report_sections.extend([
            "## 🏆 CONCLUSÃO",
            conclusion,
            ""
        ])
        
        # Escreve relatório
        with open(main_report_path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(report_sections))
        
        # Salva dados JSON
        json_path = output_path / f"{program_name}_understanding_data_v14.json"
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(analysis_result, f, indent=2, ensure_ascii=False, default=str)
        
        self.logger.info(f"Relatório de entendimento salvo em {main_report_path}")
        return str(main_report_path)

    def analyze_multiple_programs(self, programs_file: str, 
                                copybooks_file: str = None) -> Dict[str, Any]:
        """Analisa múltiplos programas para entendimento conceitual."""
        self.logger.info(f"Iniciando análise conceitual de múltiplos programas de {programs_file}")
        
        # Extrai programas
        extracted_programs = self.parser.extract_programs_from_file(programs_file)
        
        # Analisa cada programa
        results = {}
        consolidated_understanding = {
            "total_programs": len(extracted_programs),
            "programs_understood": 0,
            "programs_partially_understood": 0,
            "programs_not_understood": 0,
            "total_lines": 0,
            "average_understanding": 0.0,
            "best_understood": [],
            "needs_attention": []
        }
        
        understanding_scores = []
        
        for program_name, program_content in extracted_programs.items():
            self.logger.info(f"Analisando {program_name} para entendimento...")
            
            # Salva programa temporariamente
            temp_path = f"/tmp/{program_name}.cbl"
            with open(temp_path, 'w', encoding='utf-8') as f:
                f.write(program_content)
            
            # Analisa programa
            analysis = self.analyze_program_for_understanding(temp_path)
            results[program_name] = analysis
            
            # Atualiza métricas consolidadas
            if "error" not in analysis:
                consolidated_understanding["total_lines"] += analysis.get("total_lines", 0)
                
                understanding_score = analysis.get("explainability", {}).get("overall_understanding", 0)
                understanding_scores.append(understanding_score)
                
                # Categoriza por nível de entendimento
                if understanding_score > 0.7:
                    consolidated_understanding["programs_understood"] += 1
                    consolidated_understanding["best_understood"].append({
                        "program": program_name,
                        "score": understanding_score,
                        "summary": analysis.get("purpose", {}).get("one_line_summary", "")
                    })
                elif understanding_score > 0.4:
                    consolidated_understanding["programs_partially_understood"] += 1
                else:
                    consolidated_understanding["programs_not_understood"] += 1
                    consolidated_understanding["needs_attention"].append({
                        "program": program_name,
                        "score": understanding_score,
                        "reason": "Baixo score de entendimento"
                    })
            else:
                consolidated_understanding["programs_not_understood"] += 1
                consolidated_understanding["needs_attention"].append({
                    "program": program_name,
                    "score": 0.0,
                    "reason": f"Erro na análise: {analysis.get('error', 'Desconhecido')}"
                })
            
            # Remove arquivo temporário
            if os.path.exists(temp_path):
                os.remove(temp_path)
        
        # Calcula média de entendimento
        if understanding_scores:
            consolidated_understanding["average_understanding"] = sum(understanding_scores) / len(understanding_scores)
        
        return {
            "analysis_results": results,
            "consolidated_understanding": consolidated_understanding,
            "analysis_timestamp": datetime.now().isoformat(),
            "version": "14.0 - CONCEPTUAL UNDERSTANDING"
        }

    def generate_consolidated_understanding_report(self, multi_analysis_results: Dict[str, Any], 
                                                 output_dir: str) -> str:
        """Gera relatório consolidado de entendimento."""
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        consolidated_report_path = output_path / "CONSOLIDATED_UNDERSTANDING_REPORT_v14.md"
        
        results = multi_analysis_results["analysis_results"]
        understanding = multi_analysis_results["consolidated_understanding"]
        
        # Calcula percentuais
        total = understanding["total_programs"]
        understood_pct = (understanding["programs_understood"] / total * 100) if total > 0 else 0
        partial_pct = (understanding["programs_partially_understood"] / total * 100) if total > 0 else 0
        not_understood_pct = (understanding["programs_not_understood"] / total * 100) if total > 0 else 0
        
        report = [
            "# 🎯 Relatório Consolidado de Entendimento",
            f"**Versão:** {multi_analysis_results.get('version', '14.0')}",
            f"**Data:** {multi_analysis_results.get('analysis_timestamp', 'N/A')}",
            f"**Programas Analisados:** {total}",
            f"**Total de Linhas:** {understanding['total_lines']:,}",
            "",
            "## 📊 Visão Geral do Entendimento",
            f"- **Score Médio de Entendimento:** {understanding['average_understanding']:.1%}",
            f"- **Programas Bem Compreendidos:** {understanding['programs_understood']} ({understood_pct:.1f}%)",
            f"- **Programas Parcialmente Compreendidos:** {understanding['programs_partially_understood']} ({partial_pct:.1f}%)",
            f"- **Programas Não Compreendidos:** {understanding['programs_not_understood']} ({not_understood_pct:.1f}%)",
            "",
            "## 🏆 Programas Melhor Compreendidos",
            ""
        ]
        
        # Lista os programas melhor compreendidos
        best_understood = sorted(understanding["best_understood"], 
                               key=lambda x: x["score"], reverse=True)
        
        if best_understood:
            for program in best_understood[:5]:  # Top 5
                report.append(f"### {program['program']} ({program['score']:.1%})")
                report.append(f"**{program['summary']}**")
                report.append("")
        else:
            report.append("*Nenhum programa atingiu score alto de entendimento.*")
            report.append("")
        
        # Lista programas que precisam de atenção
        report.extend([
            "## ⚠️ Programas que Precisam de Atenção",
            ""
        ])
        
        if understanding["needs_attention"]:
            for program in understanding["needs_attention"]:
                report.append(f"- **{program['program']}** ({program['score']:.1%}): {program['reason']}")
        else:
            report.append("*Todos os programas foram adequadamente compreendidos.*")
        
        report.extend([
            "",
            "## 📋 Resumo Detalhado por Programa",
            "",
            "| Programa | Score | Propósito | Arquivos | Status |",
            "|----------|-------|-----------|----------|--------|"
        ])
        
        # Tabela resumo
        for program_name, analysis in results.items():
            if "error" in analysis:
                score = "0%"
                purpose = "Erro na análise"
                files = "0"
                status = "❌ Erro"
            else:
                score_val = analysis.get("explainability", {}).get("overall_understanding", 0)
                score = f"{score_val:.1%}"
                purpose = analysis.get("purpose", {}).get("main_purpose", "Não identificado")[:50]
                if len(purpose) == 50:
                    purpose += "..."
                files = analysis.get("files", {}).get("total_files", 0)
                
                if score_val > 0.7:
                    status = "🟢 Excelente"
                elif score_val > 0.4:
                    status = "🟡 Bom"
                else:
                    status = "🔴 Limitado"
            
            report.append(f"| {program_name} | {score} | {purpose} | {files} | {status} |")
        
        report.extend([
            "",
            "## 💡 Recomendações",
            "",
            "### Para Programas Bem Compreendidos (🟢):",
            "- Use os resumos gerados para documentação",
            "- Considere como candidatos para modernização",
            "- Utilize como referência para outros programas similares",
            "",
            "### Para Programas Parcialmente Compreendidos (🟡):",
            "- Revise manualmente os pontos não identificados",
            "- Complemente com análise de especialista",
            "- Foque nas seções de maior complexidade",
            "",
            "### Para Programas Não Compreendidos (🔴):",
            "- Priorize análise manual detalhada",
            "- Verifique se há documentação adicional disponível",
            "- Considere consultar especialistas do domínio",
            "",
            "## 🎯 Conclusão",
            ""
        ])
        
        # Conclusão baseada nos resultados
        if understood_pct > 70:
            conclusion = "🟢 **EXCELENTE RESULTADO** - A maioria dos programas foi bem compreendida. O sistema está fornecendo entendimento conceitual efetivo."
        elif understood_pct + partial_pct > 70:
            conclusion = "🟡 **BOM RESULTADO** - A maioria dos programas foi pelo menos parcialmente compreendida. Alguns ajustes podem melhorar o entendimento."
        else:
            conclusion = "🔴 **RESULTADO LIMITADO** - Muitos programas precisam de análise manual adicional. Considere revisar a abordagem ou buscar mais contexto."
        
        report.append(conclusion)
        
        # Escreve relatório
        with open(consolidated_report_path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(report))
        
        self.logger.info(f"Relatório consolidado de entendimento salvo em {consolidated_report_path}")
        return str(consolidated_report_path)

def main():
    """Função principal."""
    if len(sys.argv) < 2:
        print("Uso: python main_v14_conceptual_understanding.py <fontes.txt> [books.txt]")
        sys.exit(1)
    
    programs_file = sys.argv[1]
    copybooks_file = sys.argv[2] if len(sys.argv) > 2 else None
    
    # Inicializa analisador conceitual
    analyzer = COBOLConceptualAnalyzer()
    
    # Diretório de saída
    output_dir = "conceptual_understanding_results_v14"
    
    try:
        # Analisa múltiplos programas
        multi_results = analyzer.analyze_multiple_programs(programs_file, copybooks_file)
        
        # Gera relatórios individuais
        for program_name, analysis in multi_results["analysis_results"].items():
            program_output_dir = os.path.join(output_dir, program_name)
            analyzer.generate_understanding_report(analysis, program_output_dir)
        
        # Gera relatório consolidado
        analyzer.generate_consolidated_understanding_report(multi_results, output_dir)
        
        # Estatísticas finais
        understanding = multi_results["consolidated_understanding"]
        
        print(f"\n🎯 Análise de Entendimento Conceitual Finalizada!")
        print(f"📁 Resultados salvos em: {output_dir}")
        print(f"📊 {understanding['total_programs']} programas analisados")
        print(f"🟢 {understanding['programs_understood']} programas bem compreendidos")
        print(f"🟡 {understanding['programs_partially_understood']} programas parcialmente compreendidos")
        print(f"🔴 {understanding['programs_not_understood']} programas precisam de atenção")
        print(f"📈 Score médio de entendimento: {understanding['average_understanding']:.1%}")
        
        if understanding['average_understanding'] > 0.7:
            print("🎉 EXCELENTE! A maioria dos programas foi bem compreendida!")
        elif understanding['average_understanding'] > 0.4:
            print("👍 BOM! Entendimento conceitual efetivo alcançado!")
        else:
            print("⚠️  Entendimento limitado. Considere análise manual adicional.")
        
    except Exception as e:
        print(f"❌ Erro durante análise: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main()
