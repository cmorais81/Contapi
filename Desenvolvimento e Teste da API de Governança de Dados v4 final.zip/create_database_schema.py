"""
TBR GDP Core v4.0 - Database Schema Creation
Author: Carlos Morais <carlos.morais@f1rst.com.br>
"""

import psycopg2
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT

# Database configuration
DB_CONFIG = {
    'host': 'localhost',
    'port': 5432,
    'database': 'tbr_gdp_core_v4',
    'user': 'tbr_user',
    'password': 'tbr_password'
}

# SQL Schema based on DBML model
SCHEMA_SQL = """
-- TBR GDP Core v4.0 Database Schema
-- Author: Carlos Morais <carlos.morais@f1rst.com.br>

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ===== CORE ENTITIES =====

CREATE TABLE domains (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    owner VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE entities (
    id SERIAL PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    domain_id INTEGER REFERENCES domains(id),
    entity_type VARCHAR(50) NOT NULL,
    source_system VARCHAR(100),
    database_name VARCHAR(100),
    schema_name VARCHAR(100),
    table_name VARCHAR(100),
    owner VARCHAR(100) NOT NULL,
    steward VARCHAR(100),
    classification VARCHAR(50),
    sensitivity_level INTEGER DEFAULT 1,
    retention_period INTEGER,
    tags TEXT[],
    metadata JSONB,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE entity_schemas (
    id SERIAL PRIMARY KEY,
    entity_id INTEGER REFERENCES entities(id),
    version VARCHAR(20) NOT NULL,
    schema_definition JSONB NOT NULL,
    is_current BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT NOW(),
    created_by VARCHAR(100) NOT NULL
);

-- ===== CONTRACTS AND VERSIONING =====

CREATE TABLE contracts (
    id SERIAL PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    entity_id INTEGER REFERENCES entities(id),
    contract_type VARCHAR(50) NOT NULL,
    version VARCHAR(20) NOT NULL DEFAULT '1.0.0',
    status VARCHAR(50) NOT NULL DEFAULT 'draft',
    owner VARCHAR(100) NOT NULL,
    steward VARCHAR(100),
    schema_definition JSONB,
    quality_requirements JSONB,
    access_policies JSONB,
    sla_requirements JSONB,
    compliance_requirements JSONB,
    tags TEXT[],
    metadata JSONB,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    published_at TIMESTAMP,
    deprecated_at TIMESTAMP
);

CREATE TABLE contract_versions (
    id SERIAL PRIMARY KEY,
    contract_id INTEGER REFERENCES contracts(id),
    version VARCHAR(20) NOT NULL,
    previous_version VARCHAR(20),
    change_type VARCHAR(20) NOT NULL,
    changes JSONB NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'draft',
    created_by VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    approved_by VARCHAR(100),
    approved_at TIMESTAMP,
    published_by VARCHAR(100),
    published_at TIMESTAMP,
    is_current BOOLEAN DEFAULT FALSE,
    metadata JSONB
);

-- ===== QUALITY MANAGEMENT =====

CREATE TABLE quality_rules (
    id SERIAL PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    rule_type VARCHAR(50) NOT NULL,
    entity_id INTEGER REFERENCES entities(id),
    column_name VARCHAR(100),
    threshold DECIMAL(5,2) NOT NULL,
    severity VARCHAR(20) NOT NULL,
    rule_definition JSONB NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    schedule_expression VARCHAR(100),
    created_by VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE quality_checks (
    id SERIAL PRIMARY KEY,
    rule_id INTEGER REFERENCES quality_rules(id),
    entity_id INTEGER REFERENCES entities(id),
    execution_timestamp TIMESTAMP DEFAULT NOW(),
    status VARCHAR(20) NOT NULL,
    records_checked INTEGER,
    records_passed INTEGER,
    records_failed INTEGER,
    quality_score DECIMAL(5,2),
    execution_time_ms INTEGER,
    error_message TEXT,
    sample_failures JSONB,
    metadata JSONB
);

-- ===== RBAC/ABAC PERMISSIONS =====

CREATE TABLE rbac_roles (
    id SERIAL PRIMARY KEY,
    name VARCHAR(50) UNIQUE NOT NULL,
    display_name VARCHAR(100) NOT NULL,
    description TEXT,
    parent_role_id INTEGER REFERENCES rbac_roles(id),
    is_active BOOLEAN DEFAULT TRUE,
    permissions JSONB NOT NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE rbac_user_roles (
    id SERIAL PRIMARY KEY,
    user_id VARCHAR(100) NOT NULL,
    role_id INTEGER REFERENCES rbac_roles(id),
    assigned_by VARCHAR(100) NOT NULL,
    assigned_at TIMESTAMP DEFAULT NOW(),
    expires_at TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE
);

CREATE TABLE abac_policies (
    id SERIAL PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    policy_type VARCHAR(50) NOT NULL,
    target_expression JSONB NOT NULL,
    condition_expression JSONB,
    obligations JSONB,
    is_active BOOLEAN DEFAULT TRUE,
    priority INTEGER DEFAULT 100,
    created_by VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- ===== DATA LINEAGE =====

CREATE TABLE lineage_relationships (
    id SERIAL PRIMARY KEY,
    source_entity_id INTEGER REFERENCES entities(id),
    target_entity_id INTEGER REFERENCES entities(id),
    relationship_type VARCHAR(50) NOT NULL,
    transformation_logic TEXT,
    transformation_type VARCHAR(50),
    confidence_score DECIMAL(3,2) DEFAULT 1.0,
    discovered_method VARCHAR(50),
    metadata JSONB,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- ===== MONITORING AND ANALYTICS =====

CREATE TABLE usage_analytics (
    id SERIAL PRIMARY KEY,
    usage_date DATE NOT NULL,
    entity_id INTEGER REFERENCES entities(id),
    contract_id INTEGER REFERENCES contracts(id),
    user_id VARCHAR(100) NOT NULL,
    user_role VARCHAR(50),
    access_count INTEGER DEFAULT 1,
    data_volume_mb DECIMAL(10,2),
    operation_type VARCHAR(50),
    access_method VARCHAR(50),
    session_duration_minutes INTEGER,
    metadata JSONB
);

CREATE TABLE performance_metrics (
    id SERIAL PRIMARY KEY,
    metric_timestamp TIMESTAMP DEFAULT NOW(),
    metric_type VARCHAR(50) NOT NULL,
    metric_name VARCHAR(100) NOT NULL,
    metric_value DECIMAL(10,2) NOT NULL,
    metric_unit VARCHAR(20),
    entity_id INTEGER REFERENCES entities(id),
    user_id VARCHAR(100),
    additional_context JSONB
);

-- ===== AUDIT LOGS =====

CREATE TABLE audit_logs (
    id SERIAL PRIMARY KEY,
    event_id VARCHAR(50) UNIQUE NOT NULL,
    event_type VARCHAR(50) NOT NULL,
    entity_type VARCHAR(50) NOT NULL,
    entity_id VARCHAR(100) NOT NULL,
    user_id VARCHAR(100) NOT NULL,
    user_role VARCHAR(50),
    action_description TEXT NOT NULL,
    old_values JSONB,
    new_values JSONB,
    ip_address INET,
    user_agent TEXT,
    session_id VARCHAR(100),
    timestamp TIMESTAMP DEFAULT NOW()
);

-- ===== INDEXES FOR PERFORMANCE =====

-- Entities indexes
CREATE INDEX idx_entities_domain_id ON entities(domain_id);
CREATE INDEX idx_entities_entity_type ON entities(entity_type);
CREATE INDEX idx_entities_owner ON entities(owner);
CREATE INDEX idx_entities_classification ON entities(classification);
CREATE INDEX idx_entities_tags ON entities USING GIN(tags);
CREATE INDEX idx_entities_metadata ON entities USING GIN(metadata);

-- Contracts indexes
CREATE INDEX idx_contracts_entity_id ON contracts(entity_id);
CREATE INDEX idx_contracts_status ON contracts(status);
CREATE INDEX idx_contracts_owner ON contracts(owner);
CREATE INDEX idx_contracts_type_status ON contracts(contract_type, status);

-- Quality indexes
CREATE INDEX idx_quality_rules_entity_id ON quality_rules(entity_id);
CREATE INDEX idx_quality_checks_rule_id ON quality_checks(rule_id);
CREATE INDEX idx_quality_checks_execution_timestamp ON quality_checks(execution_timestamp);

-- RBAC indexes
CREATE INDEX idx_rbac_user_roles_user_id ON rbac_user_roles(user_id);
CREATE INDEX idx_rbac_user_roles_role_id ON rbac_user_roles(role_id);

-- Analytics indexes
CREATE INDEX idx_usage_analytics_date_entity ON usage_analytics(usage_date, entity_id);
CREATE INDEX idx_usage_analytics_user_date ON usage_analytics(user_id, usage_date);

-- Audit indexes
CREATE INDEX idx_audit_logs_entity_type_id ON audit_logs(entity_type, entity_id);
CREATE INDEX idx_audit_logs_user_timestamp ON audit_logs(user_id, timestamp);
CREATE INDEX idx_audit_logs_timestamp ON audit_logs(timestamp);

-- Performance indexes
CREATE INDEX idx_performance_metrics_timestamp ON performance_metrics(metric_timestamp);
CREATE INDEX idx_performance_metrics_type_name ON performance_metrics(metric_type, metric_name);
"""

def create_database_schema():
    """Create the complete database schema"""
    try:
        # Connect to database
        conn = psycopg2.connect(**DB_CONFIG)
        conn.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)
        cursor = conn.cursor()
        
        print("🔧 Creating TBR GDP Core v4.0 database schema...")
        
        # Execute schema creation
        cursor.execute(SCHEMA_SQL)
        
        print("✅ Database schema created successfully!")
        
        # Verify tables were created
        cursor.execute("""
            SELECT table_name 
            FROM information_schema.tables 
            WHERE table_schema = 'public' 
            ORDER BY table_name;
        """)
        
        tables = cursor.fetchall()
        print(f"📊 Created {len(tables)} tables:")
        for table in tables:
            print(f"  - {table[0]}")
        
        cursor.close()
        conn.close()
        
        return True
        
    except Exception as e:
        print(f"❌ Error creating database schema: {e}")
        return False

if __name__ == "__main__":
    create_database_schema()

