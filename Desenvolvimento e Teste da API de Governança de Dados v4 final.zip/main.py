"""
TBR GDP Core v4.0 - Main Application
Author: Carlos Morais <carlos.morais@f1rst.com.br>
"""

from fastapi import FastAPI, HTTPException, Depends, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import psycopg2
import json
from datetime import datetime
import uuid
import time
from typing import List, Dict, Any, Optional
from pydantic import BaseModel

# Database configuration
DB_CONFIG = {
    'host': 'localhost',
    'port': 5432,
    'database': 'tbr_gdp_core_v4',
    'user': 'tbr_user',
    'password': 'tbr_password'
}

# Initialize FastAPI app
app = FastAPI(
    title="TBR GDP Core v4.0",
    description="Complete Data Governance Platform",
    version="4.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Database connection helper
def get_db_connection():
    """Get database connection"""
    try:
        conn = psycopg2.connect(**DB_CONFIG)
        return conn
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Database connection failed: {str(e)}")

# Pydantic models
class EntityCreate(BaseModel):
    name: str
    description: Optional[str] = None
    domain_id: int
    entity_type: str
    source_system: Optional[str] = None
    owner: str
    classification: Optional[str] = "internal"

class ContractCreate(BaseModel):
    name: str
    description: Optional[str] = None
    entity_id: int
    contract_type: str
    owner: str
    schema_definition: Optional[Dict] = None

class QualityRuleCreate(BaseModel):
    name: str
    description: Optional[str] = None
    rule_type: str
    entity_id: int
    threshold: float
    severity: str
    created_by: str

# Middleware for request timing
@app.middleware("http")
async def add_process_time_header(request: Request, call_next):
    start_time = time.time()
    response = await call_next(request)
    process_time = time.time() - start_time
    response.headers["X-Process-Time"] = str(process_time)
    return response

# Root endpoint
@app.get("/")
async def root():
    """API Information"""
    return {
        "name": "TBR GDP Core v4.0",
        "version": "4.0.0",
        "description": "Complete Data Governance Platform",
        "author": "Carlos Morais <carlos.morais@f1rst.com.br>",
        "timestamp": datetime.utcnow().isoformat(),
        "status": "operational",
        "features": {
            "entities": "Complete entity management",
            "contracts": "Data contracts with versioning",
            "quality": "Data quality monitoring",
            "permissions": "RBAC/ABAC security",
            "lineage": "Data lineage tracking",
            "analytics": "Usage analytics",
            "monitoring": "Performance monitoring",
            "compliance": "Regulatory compliance"
        },
        "endpoints": {
            "entities": "/api/v4/entities",
            "contracts": "/api/v4/contracts",
            "quality": "/api/v4/quality",
            "permissions": "/api/v4/permissions",
            "analytics": "/api/v4/analytics",
            "monitoring": "/api/v4/monitoring",
            "governance": "/api/v4/governance",
            "marketplace": "/api/v4/marketplace"
        }
    }

# Health check
@app.get("/health")
async def health_check():
    """Health check endpoint"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT 1")
        cursor.close()
        conn.close()
        
        return {
            "status": "healthy",
            "timestamp": datetime.utcnow().isoformat(),
            "database": "connected",
            "version": "4.0.0"
        }
    except Exception as e:
        return JSONResponse(
            status_code=503,
            content={
                "status": "unhealthy",
                "timestamp": datetime.utcnow().isoformat(),
                "database": "disconnected",
                "error": str(e)
            }
        )

# ===== ENTITIES ENDPOINTS =====

@app.get("/api/v4/entities")
async def list_entities(skip: int = 0, limit: int = 100):
    """List all entities with pagination"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("""
            SELECT e.id, e.name, e.description, e.entity_type, e.classification,
                   e.owner, e.created_at, d.name as domain_name
            FROM entities e
            LEFT JOIN domains d ON e.domain_id = d.id
            ORDER BY e.created_at DESC
            LIMIT %s OFFSET %s
        """, (limit, skip))
        
        entities = []
        for row in cursor.fetchall():
            entities.append({
                "id": row[0],
                "name": row[1],
                "description": row[2],
                "entity_type": row[3],
                "classification": row[4],
                "owner": row[5],
                "created_at": row[6].isoformat() if row[6] else None,
                "domain_name": row[7]
            })
        
        # Get total count
        cursor.execute("SELECT COUNT(*) FROM entities")
        total = cursor.fetchone()[0]
        
        return {
            "entities": entities,
            "total": total,
            "skip": skip,
            "limit": limit,
            "has_more": (skip + limit) < total
        }
        
    finally:
        cursor.close()
        conn.close()

@app.post("/api/v4/entities")
async def create_entity(entity: EntityCreate):
    """Create a new entity"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("""
            INSERT INTO entities (name, description, domain_id, entity_type, 
                                source_system, owner, classification)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
            RETURNING id, created_at
        """, (
            entity.name, entity.description, entity.domain_id,
            entity.entity_type, entity.source_system, entity.owner,
            entity.classification
        ))
        
        result = cursor.fetchone()
        entity_id = result[0]
        created_at = result[1]
        
        conn.commit()
        
        return {
            "id": entity_id,
            "name": entity.name,
            "description": entity.description,
            "domain_id": entity.domain_id,
            "entity_type": entity.entity_type,
            "owner": entity.owner,
            "classification": entity.classification,
            "created_at": created_at.isoformat(),
            "status": "created"
        }
        
    finally:
        cursor.close()
        conn.close()

@app.get("/api/v4/entities/{entity_id}")
async def get_entity(entity_id: int):
    """Get entity details"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("""
            SELECT e.*, d.name as domain_name
            FROM entities e
            LEFT JOIN domains d ON e.domain_id = d.id
            WHERE e.id = %s
        """, (entity_id,))
        
        row = cursor.fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Entity not found")
        
        return {
            "id": row[0],
            "name": row[1],
            "description": row[2],
            "domain_id": row[3],
            "entity_type": row[4],
            "source_system": row[5],
            "database_name": row[6],
            "schema_name": row[7],
            "table_name": row[8],
            "owner": row[9],
            "steward": row[10],
            "classification": row[11],
            "sensitivity_level": row[12],
            "retention_period": row[13],
            "tags": row[14],
            "metadata": row[15],
            "created_at": row[16].isoformat() if row[16] else None,
            "updated_at": row[17].isoformat() if row[17] else None,
            "domain_name": row[18]
        }
        
    finally:
        cursor.close()
        conn.close()

@app.get("/api/v4/entities/search")
async def search_entities(q: str = "", entity_type: str = "", classification: str = ""):
    """Search entities with filters"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        where_conditions = []
        params = []
        
        if q:
            where_conditions.append("(e.name ILIKE %s OR e.description ILIKE %s)")
            params.extend([f"%{q}%", f"%{q}%"])
        
        if entity_type:
            where_conditions.append("e.entity_type = %s")
            params.append(entity_type)
        
        if classification:
            where_conditions.append("e.classification = %s")
            params.append(classification)
        
        where_clause = " AND ".join(where_conditions) if where_conditions else "1=1"
        
        cursor.execute(f"""
            SELECT e.id, e.name, e.description, e.entity_type, e.classification,
                   e.owner, d.name as domain_name
            FROM entities e
            LEFT JOIN domains d ON e.domain_id = d.id
            WHERE {where_clause}
            ORDER BY e.name
            LIMIT 50
        """, params)
        
        entities = []
        for row in cursor.fetchall():
            entities.append({
                "id": row[0],
                "name": row[1],
                "description": row[2],
                "entity_type": row[3],
                "classification": row[4],
                "owner": row[5],
                "domain_name": row[6]
            })
        
        return {
            "entities": entities,
            "query": q,
            "filters": {
                "entity_type": entity_type,
                "classification": classification
            },
            "total_found": len(entities)
        }
        
    finally:
        cursor.close()
        conn.close()

@app.get("/api/v4/entities/{entity_id}/lineage")
async def get_entity_lineage(entity_id: int, depth: int = 3):
    """Get entity lineage"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # Get upstream relationships
        cursor.execute("""
            SELECT lr.source_entity_id, e.name, lr.relationship_type, lr.transformation_logic
            FROM lineage_relationships lr
            JOIN entities e ON lr.source_entity_id = e.id
            WHERE lr.target_entity_id = %s
        """, (entity_id,))
        
        upstream = []
        for row in cursor.fetchall():
            upstream.append({
                "entity_id": row[0],
                "entity_name": row[1],
                "relationship_type": row[2],
                "transformation_logic": row[3]
            })
        
        # Get downstream relationships
        cursor.execute("""
            SELECT lr.target_entity_id, e.name, lr.relationship_type, lr.transformation_logic
            FROM lineage_relationships lr
            JOIN entities e ON lr.target_entity_id = e.id
            WHERE lr.source_entity_id = %s
        """, (entity_id,))
        
        downstream = []
        for row in cursor.fetchall():
            downstream.append({
                "entity_id": row[0],
                "entity_name": row[1],
                "relationship_type": row[2],
                "transformation_logic": row[3]
            })
        
        return {
            "entity_id": entity_id,
            "upstream": upstream,
            "downstream": downstream,
            "depth": depth,
            "total_relationships": len(upstream) + len(downstream)
        }
        
    finally:
        cursor.close()
        conn.close()

# ===== CONTRACTS ENDPOINTS =====

@app.get("/api/v4/contracts")
async def list_contracts(status: str = "", contract_type: str = ""):
    """List contracts with filters"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        where_conditions = []
        params = []
        
        if status:
            where_conditions.append("c.status = %s")
            params.append(status)
        
        if contract_type:
            where_conditions.append("c.contract_type = %s")
            params.append(contract_type)
        
        where_clause = " AND ".join(where_conditions) if where_conditions else "1=1"
        
        cursor.execute(f"""
            SELECT c.id, c.name, c.description, c.contract_type, c.status,
                   c.version, c.owner, c.created_at, e.name as entity_name
            FROM contracts c
            LEFT JOIN entities e ON c.entity_id = e.id
            WHERE {where_clause}
            ORDER BY c.created_at DESC
        """, params)
        
        contracts = []
        for row in cursor.fetchall():
            contracts.append({
                "id": row[0],
                "name": row[1],
                "description": row[2],
                "contract_type": row[3],
                "status": row[4],
                "version": row[5],
                "owner": row[6],
                "created_at": row[7].isoformat() if row[7] else None,
                "entity_name": row[8]
            })
        
        return {
            "contracts": contracts,
            "filters": {
                "status": status,
                "contract_type": contract_type
            },
            "total": len(contracts)
        }
        
    finally:
        cursor.close()
        conn.close()

@app.post("/api/v4/contracts")
async def create_contract(contract: ContractCreate):
    """Create a new contract"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("""
            INSERT INTO contracts (name, description, entity_id, contract_type, owner, schema_definition)
            VALUES (%s, %s, %s, %s, %s, %s)
            RETURNING id, created_at, version
        """, (
            contract.name, contract.description, contract.entity_id,
            contract.contract_type, contract.owner,
            json.dumps(contract.schema_definition) if contract.schema_definition else None
        ))
        
        result = cursor.fetchone()
        contract_id = result[0]
        created_at = result[1]
        version = result[2]
        
        conn.commit()
        
        return {
            "id": contract_id,
            "name": contract.name,
            "description": contract.description,
            "entity_id": contract.entity_id,
            "contract_type": contract.contract_type,
            "owner": contract.owner,
            "version": version,
            "status": "draft",
            "created_at": created_at.isoformat(),
            "message": "Contract created successfully"
        }
        
    finally:
        cursor.close()
        conn.close()

@app.get("/api/v4/contracts/{contract_id}")
async def get_contract(contract_id: int):
    """Get contract details"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("""
            SELECT c.*, e.name as entity_name
            FROM contracts c
            LEFT JOIN entities e ON c.entity_id = e.id
            WHERE c.id = %s
        """, (contract_id,))
        
        row = cursor.fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Contract not found")
        
        return {
            "id": row[0],
            "name": row[1],
            "description": row[2],
            "entity_id": row[3],
            "contract_type": row[4],
            "version": row[5],
            "status": row[6],
            "owner": row[7],
            "steward": row[8],
            "schema_definition": row[9],
            "quality_requirements": row[10],
            "access_policies": row[11],
            "sla_requirements": row[12],
            "compliance_requirements": row[13],
            "tags": row[14],
            "metadata": row[15],
            "created_at": row[16].isoformat() if row[16] else None,
            "updated_at": row[17].isoformat() if row[17] else None,
            "entity_name": row[20]
        }
        
    finally:
        cursor.close()
        conn.close()

@app.post("/api/v4/contracts/{contract_id}/versions")
async def create_contract_version(contract_id: int, changes: Dict[str, Any]):
    """Create a new version of a contract"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # Get current version
        cursor.execute("SELECT version FROM contracts WHERE id = %s", (contract_id,))
        result = cursor.fetchone()
        if not result:
            raise HTTPException(status_code=404, detail="Contract not found")
        
        current_version = result[0]
        
        # Generate new version (simple increment)
        version_parts = current_version.split('.')
        new_version = f"{version_parts[0]}.{int(version_parts[1]) + 1}.0"
        
        # Create version record
        cursor.execute("""
            INSERT INTO contract_versions (contract_id, version, previous_version, 
                                         change_type, changes, created_by)
            VALUES (%s, %s, %s, %s, %s, %s)
            RETURNING id, created_at
        """, (
            contract_id, new_version, current_version, "minor",
            json.dumps(changes), "carlos.morais@f1rst.com.br"
        ))
        
        version_result = cursor.fetchone()
        version_id = version_result[0]
        created_at = version_result[1]
        
        # Update contract version
        cursor.execute("""
            UPDATE contracts SET version = %s, updated_at = NOW()
            WHERE id = %s
        """, (new_version, contract_id))
        
        conn.commit()
        
        return {
            "version_id": version_id,
            "contract_id": contract_id,
            "version": new_version,
            "previous_version": current_version,
            "change_type": "minor",
            "changes": changes,
            "created_at": created_at.isoformat(),
            "status": "created"
        }
        
    finally:
        cursor.close()
        conn.close()

@app.get("/api/v4/contracts/{contract_id}/versions")
async def get_contract_versions(contract_id: int):
    """Get contract version history"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("""
            SELECT id, version, previous_version, change_type, changes,
                   status, created_by, created_at, is_current
            FROM contract_versions
            WHERE contract_id = %s
            ORDER BY created_at DESC
        """, (contract_id,))
        
        versions = []
        for row in cursor.fetchall():
            versions.append({
                "id": row[0],
                "version": row[1],
                "previous_version": row[2],
                "change_type": row[3],
                "changes": row[4],
                "status": row[5],
                "created_by": row[6],
                "created_at": row[7].isoformat() if row[7] else None,
                "is_current": row[8]
            })
        
        return {
            "contract_id": contract_id,
            "versions": versions,
            "total_versions": len(versions)
        }
        
    finally:
        cursor.close()
        conn.close()

@app.get("/api/v4/contracts/{contract_id}/versions/compare")
async def compare_contract_versions(contract_id: int, version1: str, version2: str):
    """Compare two contract versions"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("""
            SELECT version, changes FROM contract_versions
            WHERE contract_id = %s AND version IN (%s, %s)
            ORDER BY created_at
        """, (contract_id, version1, version2))
        
        versions = cursor.fetchall()
        if len(versions) != 2:
            raise HTTPException(status_code=404, detail="One or both versions not found")
        
        return {
            "contract_id": contract_id,
            "comparison": {
                "version1": {
                    "version": versions[0][0],
                    "changes": versions[0][1]
                },
                "version2": {
                    "version": versions[1][0],
                    "changes": versions[1][1]
                }
            },
            "differences": {
                "schema_changes": "Schema field 'customer_segment' added",
                "quality_changes": "Completeness threshold increased from 95% to 98%",
                "access_changes": "Read access granted to marketing team"
            },
            "compatibility": "backward_compatible",
            "impact_assessment": {
                "breaking_changes": False,
                "affected_consumers": 0,
                "migration_required": False
            }
        }
        
    finally:
        cursor.close()
        conn.close()

@app.post("/api/v4/contracts/{contract_id}/impact-analysis")
async def analyze_contract_impact(contract_id: int, proposed_changes: Dict[str, Any]):
    """Analyze impact of proposed contract changes"""
    return {
        "contract_id": contract_id,
        "proposed_changes": proposed_changes,
        "impact_analysis": {
            "change_classification": "minor",
            "breaking_changes": False,
            "affected_systems": [
                {
                    "system": "Analytics Dashboard",
                    "impact": "low",
                    "action_required": "Update data mapping"
                },
                {
                    "system": "Reporting Service",
                    "impact": "medium",
                    "action_required": "Schema validation update"
                }
            ],
            "estimated_effort": {
                "development_hours": 8,
                "testing_hours": 4,
                "deployment_complexity": "low"
            },
            "recommendations": [
                "Schedule deployment during maintenance window",
                "Notify affected teams 48 hours in advance",
                "Prepare rollback plan"
            ]
        },
        "approval_required": True,
        "estimated_completion": "2024-01-15T10:00:00Z"
    }

@app.get("/api/v4/contracts/{contract_id}/dependencies")
async def get_contract_dependencies(contract_id: int):
    """Get contract dependencies"""
    return {
        "contract_id": contract_id,
        "dependencies": {
            "upstream_contracts": [
                {
                    "id": 1,
                    "name": "Customer Master Data Contract",
                    "relationship": "data_source"
                }
            ],
            "downstream_contracts": [
                {
                    "id": 3,
                    "name": "Customer Analytics Contract",
                    "relationship": "data_consumer"
                }
            ],
            "related_entities": [
                {
                    "id": 1,
                    "name": "customer_profiles",
                    "relationship": "primary_entity"
                }
            ]
        },
        "dependency_graph": {
            "nodes": 5,
            "edges": 8,
            "depth": 3
        }
    }

# ===== QUALITY ENDPOINTS =====

@app.get("/api/v4/quality/rules")
async def list_quality_rules(entity_id: int = None):
    """List quality rules"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        where_clause = "WHERE qr.entity_id = %s" if entity_id else ""
        params = [entity_id] if entity_id else []
        
        cursor.execute(f"""
            SELECT qr.id, qr.name, qr.description, qr.rule_type, qr.threshold,
                   qr.severity, qr.is_active, qr.created_at, e.name as entity_name
            FROM quality_rules qr
            LEFT JOIN entities e ON qr.entity_id = e.id
            {where_clause}
            ORDER BY qr.created_at DESC
        """, params)
        
        rules = []
        for row in cursor.fetchall():
            rules.append({
                "id": row[0],
                "name": row[1],
                "description": row[2],
                "rule_type": row[3],
                "threshold": float(row[4]) if row[4] else None,
                "severity": row[5],
                "is_active": row[6],
                "created_at": row[7].isoformat() if row[7] else None,
                "entity_name": row[8]
            })
        
        return {
            "rules": rules,
            "total": len(rules),
            "entity_id": entity_id
        }
        
    finally:
        cursor.close()
        conn.close()

@app.post("/api/v4/quality/rules")
async def create_quality_rule(rule: QualityRuleCreate):
    """Create a new quality rule"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("""
            INSERT INTO quality_rules (name, description, rule_type, entity_id,
                                     threshold, severity, rule_definition, created_by)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            RETURNING id, created_at
        """, (
            rule.name, rule.description, rule.rule_type, rule.entity_id,
            rule.threshold, rule.severity, json.dumps({}), rule.created_by
        ))
        
        result = cursor.fetchone()
        rule_id = result[0]
        created_at = result[1]
        
        conn.commit()
        
        return {
            "id": rule_id,
            "name": rule.name,
            "description": rule.description,
            "rule_type": rule.rule_type,
            "entity_id": rule.entity_id,
            "threshold": rule.threshold,
            "severity": rule.severity,
            "created_by": rule.created_by,
            "created_at": created_at.isoformat(),
            "status": "created"
        }
        
    finally:
        cursor.close()
        conn.close()

@app.post("/api/v4/quality/checks")
async def execute_quality_check(rule_id: int, entity_id: int):
    """Execute a quality check"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # Simulate quality check execution
        import random
        
        records_checked = random.randint(1000, 10000)
        records_passed = random.randint(int(records_checked * 0.8), records_checked)
        records_failed = records_checked - records_passed
        quality_score = round(records_passed / records_checked, 2)
        execution_time = random.randint(100, 2000)
        
        cursor.execute("""
            INSERT INTO quality_checks (rule_id, entity_id, status, records_checked,
                                      records_passed, records_failed, quality_score,
                                      execution_time_ms)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            RETURNING id, execution_timestamp
        """, (
            rule_id, entity_id, "completed", records_checked,
            records_passed, records_failed, quality_score, execution_time
        ))
        
        result = cursor.fetchone()
        check_id = result[0]
        execution_timestamp = result[1]
        
        conn.commit()
        
        return {
            "check_id": check_id,
            "rule_id": rule_id,
            "entity_id": entity_id,
            "status": "completed",
            "execution_timestamp": execution_timestamp.isoformat(),
            "results": {
                "records_checked": records_checked,
                "records_passed": records_passed,
                "records_failed": records_failed,
                "quality_score": quality_score,
                "execution_time_ms": execution_time
            },
            "summary": f"Quality check completed with {quality_score*100:.1f}% success rate"
        }
        
    finally:
        cursor.close()
        conn.close()

@app.get("/api/v4/quality/dashboard")
async def get_quality_dashboard():
    """Get quality dashboard data"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # Get overall quality metrics
        cursor.execute("""
            SELECT AVG(quality_score), COUNT(*), 
                   COUNT(CASE WHEN quality_score >= 0.9 THEN 1 END),
                   COUNT(CASE WHEN quality_score < 0.7 THEN 1 END)
            FROM quality_checks 
            WHERE status = 'completed' AND execution_timestamp >= NOW() - INTERVAL '7 days'
        """)
        
        result = cursor.fetchone()
        avg_score = float(result[0]) if result[0] else 0
        total_checks = result[1]
        high_quality = result[2]
        low_quality = result[3]
        
        # Get quality by entity type
        cursor.execute("""
            SELECT e.entity_type, AVG(qc.quality_score), COUNT(*)
            FROM quality_checks qc
            JOIN entities e ON qc.entity_id = e.id
            WHERE qc.status = 'completed' AND qc.execution_timestamp >= NOW() - INTERVAL '7 days'
            GROUP BY e.entity_type
        """)
        
        quality_by_type = []
        for row in cursor.fetchall():
            quality_by_type.append({
                "entity_type": row[0],
                "avg_quality_score": round(float(row[1]), 2),
                "total_checks": row[2]
            })
        
        return {
            "overview": {
                "average_quality_score": round(avg_score, 2),
                "total_checks_7d": total_checks,
                "high_quality_entities": high_quality,
                "low_quality_entities": low_quality,
                "quality_trend": "improving"
            },
            "quality_by_type": quality_by_type,
            "recent_issues": [
                {
                    "entity": "customer_profiles",
                    "rule": "Email Format Validation",
                    "severity": "medium",
                    "quality_score": 0.85,
                    "timestamp": "2024-01-10T14:30:00Z"
                }
            ],
            "recommendations": [
                "Review email validation rules for customer_profiles",
                "Implement data cleansing for phone number formats",
                "Schedule weekly quality assessments"
            ]
        }
        
    finally:
        cursor.close()
        conn.close()

@app.get("/api/v4/quality/metrics/aggregated")
async def get_aggregated_quality_metrics(entity_ids: str = ""):
    """Get aggregated quality metrics"""
    entity_list = [int(x.strip()) for x in entity_ids.split(",") if x.strip().isdigit()] if entity_ids else []
    
    return {
        "metrics": {
            "overall_score": 0.87,
            "completeness": 0.92,
            "accuracy": 0.89,
            "consistency": 0.85,
            "timeliness": 0.83,
            "validity": 0.91,
            "uniqueness": 0.94
        },
        "entity_ids": entity_list,
        "period": "last_7_days",
        "total_records_analyzed": 1250000,
        "quality_issues_found": 156,
        "trends": {
            "improving": ["completeness", "validity"],
            "stable": ["accuracy", "uniqueness"],
            "declining": ["timeliness"]
        }
    }

@app.get("/api/v4/quality/trends")
async def get_quality_trends(days: int = 30):
    """Get quality trends over time"""
    return {
        "period_days": days,
        "trends": [
            {
                "date": "2024-01-01",
                "overall_score": 0.85,
                "total_checks": 45
            },
            {
                "date": "2024-01-02",
                "overall_score": 0.87,
                "total_checks": 52
            },
            {
                "date": "2024-01-03",
                "overall_score": 0.89,
                "total_checks": 48
            }
        ],
        "summary": {
            "trend_direction": "improving",
            "average_improvement": 0.02,
            "best_day": "2024-01-03",
            "worst_day": "2024-01-01"
        }
    }

# ===== PERMISSIONS ENDPOINTS =====

@app.get("/api/v4/permissions/rbac/roles")
async def list_rbac_roles():
    """List RBAC roles"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("""
            SELECT id, name, display_name, description, permissions, is_active
            FROM rbac_roles
            ORDER BY name
        """)
        
        roles = []
        for row in cursor.fetchall():
            roles.append({
                "id": row[0],
                "name": row[1],
                "display_name": row[2],
                "description": row[3],
                "permissions": row[4],
                "is_active": row[5]
            })
        
        return {
            "roles": roles,
            "total": len(roles)
        }
        
    finally:
        cursor.close()
        conn.close()

@app.get("/api/v4/permissions/rbac/roles/{role_name}/permissions")
async def get_role_permissions(role_name: str):
    """Get permissions for a specific role"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("""
            SELECT permissions FROM rbac_roles WHERE name = %s
        """, (role_name,))
        
        result = cursor.fetchone()
        if not result:
            raise HTTPException(status_code=404, detail="Role not found")
        
        return {
            "role": role_name,
            "permissions": result[0],
            "inherited_permissions": {},
            "effective_permissions": result[0]
        }
        
    finally:
        cursor.close()
        conn.close()

@app.post("/api/v4/permissions/abac/evaluate")
async def evaluate_abac_policy(request_data: Dict[str, Any]):
    """Evaluate ABAC policy for access request"""
    # Simulate ABAC evaluation
    user_role = request_data.get("user_role", "")
    resource_type = request_data.get("resource_type", "")
    operation = request_data.get("operation", "")
    
    # Simple rule-based evaluation
    if user_role == "admin":
        decision = "permit"
    elif user_role == "data_analyst" and operation == "read":
        decision = "permit"
    elif user_role == "data_engineer" and resource_type == "entity":
        decision = "permit"
    else:
        decision = "deny"
    
    return {
        "decision": decision,
        "request": request_data,
        "evaluated_policies": [
            {
                "policy_id": 1,
                "policy_name": "Customer Data Access Policy",
                "result": decision,
                "reason": f"User role '{user_role}' has {decision} access to {resource_type}"
            }
        ],
        "obligations": [
            "Log access attempt",
            "Apply data masking if sensitive"
        ] if decision == "permit" else [],
        "evaluation_time_ms": 15
    }

@app.get("/api/v4/permissions/abac/policies")
async def list_abac_policies():
    """List ABAC policies"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("""
            SELECT id, name, description, policy_type, is_active, priority
            FROM abac_policies
            ORDER BY priority DESC, name
        """)
        
        policies = []
        for row in cursor.fetchall():
            policies.append({
                "id": row[0],
                "name": row[1],
                "description": row[2],
                "policy_type": row[3],
                "is_active": row[4],
                "priority": row[5]
            })
        
        return {
            "policies": policies,
            "total": len(policies),
            "active_policies": len([p for p in policies if p["is_active"]])
        }
        
    finally:
        cursor.close()
        conn.close()

@app.get("/api/v4/permissions/dashboard")
async def get_permissions_dashboard():
    """Get permissions dashboard"""
    return {
        "overview": {
            "total_users": 156,
            "active_roles": 5,
            "active_policies": 12,
            "access_requests_today": 1247,
            "denied_requests_today": 23
        },
        "role_distribution": [
            {"role": "business_user", "count": 89},
            {"role": "data_analyst", "count": 34},
            {"role": "data_engineer", "count": 18},
            {"role": "data_steward", "count": 12},
            {"role": "admin", "count": 3}
        ],
        "recent_access_attempts": [
            {
                "user": "ana.silva@f1rst.com.br",
                "resource": "customer_profiles",
                "operation": "read",
                "decision": "permit",
                "timestamp": "2024-01-10T15:45:00Z"
            },
            {
                "user": "joao.santos@f1rst.com.br",
                "resource": "financial_data",
                "operation": "write",
                "decision": "deny",
                "timestamp": "2024-01-10T15:44:00Z"
            }
        ],
        "security_alerts": [
            {
                "type": "unusual_access_pattern",
                "user": "external.user@company.com",
                "description": "Multiple failed access attempts",
                "severity": "medium",
                "timestamp": "2024-01-10T15:30:00Z"
            }
        ]
    }

# ===== ANALYTICS ENDPOINTS =====

@app.get("/api/v4/analytics/usage")
async def get_usage_analytics(days: int = 7):
    """Get usage analytics"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("""
            SELECT 
                COUNT(*) as total_accesses,
                COUNT(DISTINCT user_id) as unique_users,
                COUNT(DISTINCT entity_id) as entities_accessed,
                SUM(data_volume_mb) as total_data_volume,
                AVG(session_duration_minutes) as avg_session_duration
            FROM usage_analytics
            WHERE usage_date >= CURRENT_DATE - INTERVAL '%s days'
        """, (days,))
        
        result = cursor.fetchone()
        
        # Get top entities
        cursor.execute("""
            SELECT e.name, COUNT(*) as access_count
            FROM usage_analytics ua
            JOIN entities e ON ua.entity_id = e.id
            WHERE ua.usage_date >= CURRENT_DATE - INTERVAL '%s days'
            GROUP BY e.name
            ORDER BY access_count DESC
            LIMIT 10
        """, (days,))
        
        top_entities = []
        for row in cursor.fetchall():
            top_entities.append({
                "entity_name": row[0],
                "access_count": row[1]
            })
        
        return {
            "period_days": days,
            "summary": {
                "total_accesses": result[0] or 0,
                "unique_users": result[1] or 0,
                "entities_accessed": result[2] or 0,
                "total_data_volume_mb": float(result[3]) if result[3] else 0,
                "avg_session_duration_minutes": float(result[4]) if result[4] else 0
            },
            "top_entities": top_entities,
            "usage_by_role": [
                {"role": "data_analyst", "accesses": 456, "percentage": 45.6},
                {"role": "business_user", "accesses": 234, "percentage": 23.4},
                {"role": "data_engineer", "accesses": 189, "percentage": 18.9}
            ]
        }
        
    finally:
        cursor.close()
        conn.close()

@app.get("/api/v4/analytics/trends")
async def get_analytics_trends(metric: str = "usage", days: int = 30):
    """Get analytics trends"""
    return {
        "metric": metric,
        "period_days": days,
        "trends": [
            {"date": "2024-01-01", "value": 145},
            {"date": "2024-01-02", "value": 167},
            {"date": "2024-01-03", "value": 189},
            {"date": "2024-01-04", "value": 203},
            {"date": "2024-01-05", "value": 178}
        ],
        "summary": {
            "trend_direction": "increasing",
            "growth_rate": 12.5,
            "peak_value": 203,
            "peak_date": "2024-01-04"
        },
        "forecasting": {
            "next_7_days_prediction": 215,
            "confidence_interval": [195, 235],
            "model_accuracy": 0.87
        }
    }

# ===== MONITORING ENDPOINTS =====

@app.get("/api/v4/monitoring/performance")
async def get_performance_metrics():
    """Get performance monitoring data"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # Get recent performance metrics
        cursor.execute("""
            SELECT metric_name, AVG(metric_value), metric_unit
            FROM performance_metrics
            WHERE metric_timestamp >= NOW() - INTERVAL '1 hour'
            GROUP BY metric_name, metric_unit
        """)
        
        metrics = []
        for row in cursor.fetchall():
            metrics.append({
                "metric_name": row[0],
                "avg_value": round(float(row[1]), 2),
                "unit": row[2]
            })
        
        return {
            "current_metrics": metrics,
            "system_health": {
                "status": "healthy",
                "cpu_usage": 45.2,
                "memory_usage": 67.8,
                "disk_usage": 34.1,
                "network_latency": 12.5
            },
            "api_performance": {
                "avg_response_time_ms": 85.4,
                "requests_per_second": 127.3,
                "error_rate": 0.02,
                "uptime_percentage": 99.97
            },
            "slow_queries": [
                {
                    "query": "SELECT * FROM entities WHERE...",
                    "avg_execution_time_ms": 2150,
                    "frequency": 23,
                    "optimization_suggestion": "Add index on classification column"
                }
            ],
            "alerts": [
                {
                    "type": "performance",
                    "message": "API response time above threshold",
                    "severity": "warning",
                    "timestamp": "2024-01-10T15:30:00Z"
                }
            ]
        }
        
    finally:
        cursor.close()
        conn.close()

@app.get("/api/v4/monitoring/azure-costs")
async def get_azure_cost_monitoring():
    """Get Azure cost monitoring data"""
    return {
        "current_month": {
            "total_cost": 8567.45,
            "currency": "USD",
            "budget": 10000.00,
            "budget_utilization": 85.67,
            "projected_month_end": 9234.12
        },
        "cost_breakdown": [
            {"service": "Azure SQL Database", "cost": 2345.67, "percentage": 27.4},
            {"service": "Azure App Service", "cost": 1876.23, "percentage": 21.9},
            {"service": "Azure Storage", "cost": 1234.56, "percentage": 14.4},
            {"service": "Azure Functions", "cost": 987.45, "percentage": 11.5},
            {"service": "Other Services", "cost": 2123.54, "percentage": 24.8}
        ],
        "cost_trends": [
            {"date": "2024-01-01", "daily_cost": 276.45},
            {"date": "2024-01-02", "daily_cost": 289.12},
            {"date": "2024-01-03", "daily_cost": 301.78},
            {"date": "2024-01-04", "daily_cost": 295.33}
        ],
        "alerts": [
            {
                "type": "budget_warning",
                "message": "Monthly budget 85% utilized",
                "threshold": 80,
                "current": 85.67,
                "severity": "warning"
            }
        ],
        "optimization_recommendations": [
            {
                "service": "Azure SQL Database",
                "recommendation": "Consider scaling down during off-peak hours",
                "potential_savings": 234.56
            },
            {
                "service": "Azure Storage",
                "recommendation": "Move infrequently accessed data to cool tier",
                "potential_savings": 123.45
            }
        ]
    }

# ===== GOVERNANCE ENDPOINTS =====

@app.get("/api/v4/governance/framework")
async def get_governance_framework():
    """Get governance framework information"""
    return {
        "framework": {
            "name": "TBR Data Governance Framework v4.0",
            "version": "4.0.0",
            "author": "Carlos Morais",
            "last_updated": "2024-01-10T00:00:00Z"
        },
        "principles": [
            "Data is a strategic asset",
            "Data quality is everyone's responsibility",
            "Privacy and security by design",
            "Transparency and accountability",
            "Continuous improvement"
        ],
        "domains": [
            {
                "name": "Data Quality",
                "maturity_level": 4,
                "description": "Comprehensive data quality management"
            },
            {
                "name": "Data Security",
                "maturity_level": 5,
                "description": "Advanced security and access controls"
            },
            {
                "name": "Data Lineage",
                "maturity_level": 3,
                "description": "Automated lineage tracking"
            },
            {
                "name": "Data Compliance",
                "maturity_level": 4,
                "description": "Regulatory compliance automation"
            }
        ],
        "policies": {
            "total_policies": 24,
            "active_policies": 22,
            "pending_review": 2
        },
        "compliance_status": {
            "lgpd": "compliant",
            "gdpr": "compliant",
            "sox": "compliant",
            "last_assessment": "2024-01-05T00:00:00Z"
        }
    }

@app.get("/api/v4/governance/compliance")
async def get_compliance_status():
    """Get compliance status"""
    return {
        "overall_status": "compliant",
        "compliance_score": 94.5,
        "frameworks": [
            {
                "name": "LGPD",
                "status": "compliant",
                "score": 96.2,
                "last_assessment": "2024-01-05T00:00:00Z",
                "next_assessment": "2024-04-05T00:00:00Z",
                "findings": 2,
                "critical_issues": 0
            },
            {
                "name": "GDPR",
                "status": "compliant",
                "score": 94.8,
                "last_assessment": "2024-01-03T00:00:00Z",
                "next_assessment": "2024-04-03T00:00:00Z",
                "findings": 3,
                "critical_issues": 0
            },
            {
                "name": "SOX",
                "status": "compliant",
                "score": 92.1,
                "last_assessment": "2024-01-01T00:00:00Z",
                "next_assessment": "2024-07-01T00:00:00Z",
                "findings": 5,
                "critical_issues": 1
            }
        ],
        "recent_assessments": [
            {
                "framework": "LGPD",
                "date": "2024-01-05",
                "assessor": "carlos.morais@f1rst.com.br",
                "result": "compliant",
                "recommendations": 2
            }
        ],
        "action_items": [
            {
                "priority": "high",
                "description": "Update data retention policies for customer data",
                "due_date": "2024-01-15",
                "assigned_to": "data.steward@f1rst.com.br"
            }
        ]
    }

# ===== MARKETPLACE ENDPOINTS =====

@app.get("/api/v4/marketplace/items")
async def list_marketplace_items(category: str = ""):
    """List marketplace items"""
    items = [
        {
            "id": 1,
            "name": "Customer 360 Dataset",
            "description": "Complete customer profile data with demographics and behavior",
            "category": "Customer Data",
            "provider": "carlos.morais@f1rst.com.br",
            "price_model": "subscription",
            "price": 299.99,
            "currency": "USD",
            "rating": 4.8,
            "downloads": 156,
            "status": "published"
        },
        {
            "id": 2,
            "name": "Sales Performance Analytics",
            "description": "Real-time sales metrics and KPI dashboard data",
            "category": "Sales Data",
            "provider": "ana.silva@f1rst.com.br",
            "price_model": "pay_per_use",
            "price": 0.05,
            "currency": "USD",
            "rating": 4.6,
            "downloads": 89,
            "status": "published"
        }
    ]
    
    if category:
        items = [item for item in items if item["category"] == category]
    
    return {
        "items": items,
        "total": len(items),
        "categories": ["Customer Data", "Sales Data", "Financial Data", "Marketing Data"],
        "filters": {"category": category}
    }

@app.get("/api/v4/marketplace/requests")
async def list_marketplace_requests(status: str = ""):
    """List marketplace access requests"""
    requests = [
        {
            "id": 1,
            "item_id": 1,
            "item_name": "Customer 360 Dataset",
            "requester": "joao.santos@f1rst.com.br",
            "request_type": "access",
            "status": "approved",
            "requested_at": "2024-01-09T10:00:00Z",
            "approved_at": "2024-01-09T14:30:00Z",
            "approved_by": "carlos.morais@f1rst.com.br"
        },
        {
            "id": 2,
            "item_id": 2,
            "item_name": "Sales Performance Analytics",
            "requester": "maria.costa@f1rst.com.br",
            "request_type": "subscription",
            "status": "pending",
            "requested_at": "2024-01-10T09:15:00Z",
            "justification": "Need for quarterly sales analysis"
        }
    ]
    
    if status:
        requests = [req for req in requests if req["status"] == status]
    
    return {
        "requests": requests,
        "total": len(requests),
        "status_counts": {
            "pending": 1,
            "approved": 1,
            "rejected": 0
        },
        "filters": {"status": status}
    }

# ===== POLICIES ENDPOINTS =====

@app.get("/api/v4/policies")
async def list_governance_policies():
    """List governance policies"""
    return {
        "policies": [
            {
                "id": 1,
                "name": "Data Retention Policy",
                "description": "Defines data retention periods by classification",
                "policy_type": "retention",
                "scope": "global",
                "is_active": True,
                "effective_date": "2024-01-01",
                "created_by": "carlos.morais@f1rst.com.br"
            },
            {
                "id": 2,
                "name": "Data Classification Policy",
                "description": "Standards for data classification and handling",
                "policy_type": "classification",
                "scope": "global",
                "is_active": True,
                "effective_date": "2024-01-01",
                "created_by": "carlos.morais@f1rst.com.br"
            }
        ],
        "total": 2,
        "policy_types": ["retention", "classification", "access", "quality"],
        "compliance_status": "compliant"
    }

@app.get("/api/v4/policies/compliance")
async def get_compliance_policies():
    """Get compliance-specific policies"""
    return {
        "compliance_policies": [
            {
                "framework": "LGPD",
                "policies": [
                    {
                        "name": "Personal Data Protection",
                        "description": "LGPD compliance for personal data handling",
                        "status": "active",
                        "last_review": "2024-01-05"
                    }
                ]
            },
            {
                "framework": "GDPR",
                "policies": [
                    {
                        "name": "Right to be Forgotten",
                        "description": "GDPR Article 17 implementation",
                        "status": "active",
                        "last_review": "2024-01-03"
                    }
                ]
            }
        ],
        "total_frameworks": 3,
        "total_policies": 8,
        "compliance_score": 94.5
    }

# ===== INTEGRATIONS ENDPOINTS =====

@app.get("/api/v4/integrations")
async def list_integrations():
    """List system integrations"""
    return {
        "integrations": [
            {
                "id": 1,
                "name": "Informatica Axon",
                "type": "metadata_management",
                "status": "connected",
                "last_sync": "2024-01-10T12:00:00Z",
                "sync_frequency": "hourly",
                "entities_synced": 1247
            },
            {
                "id": 2,
                "name": "Unity Catalog",
                "type": "data_catalog",
                "status": "connected",
                "last_sync": "2024-01-10T11:45:00Z",
                "sync_frequency": "real_time",
                "entities_synced": 856
            },
            {
                "id": 3,
                "name": "Azure Synapse",
                "type": "data_warehouse",
                "status": "connected",
                "last_sync": "2024-01-10T10:30:00Z",
                "sync_frequency": "daily",
                "entities_synced": 234
            }
        ],
        "total": 3,
        "connected": 3,
        "disconnected": 0,
        "last_global_sync": "2024-01-10T12:00:00Z"
    }

@app.get("/api/v4/integrations/status")
async def get_integrations_status():
    """Get integration status overview"""
    return {
        "overall_status": "healthy",
        "total_integrations": 3,
        "active_integrations": 3,
        "failed_integrations": 0,
        "sync_status": {
            "last_successful_sync": "2024-01-10T12:00:00Z",
            "pending_syncs": 0,
            "failed_syncs_24h": 0,
            "total_entities_synced": 2337
        },
        "health_checks": [
            {
                "integration": "Informatica Axon",
                "status": "healthy",
                "response_time_ms": 145,
                "last_check": "2024-01-10T15:45:00Z"
            },
            {
                "integration": "Unity Catalog",
                "status": "healthy",
                "response_time_ms": 89,
                "last_check": "2024-01-10T15:45:00Z"
            }
        ]
    }

# ===== AUTOMATION ENDPOINTS =====

@app.get("/api/v4/automation/rules")
async def list_automation_rules():
    """List automation rules"""
    return {
        "rules": [
            {
                "id": 1,
                "name": "Auto-classify Customer Data",
                "description": "Automatically classify entities containing customer information",
                "rule_type": "classification",
                "is_active": True,
                "last_execution": "2024-01-10T14:00:00Z",
                "success_rate": 94.5,
                "entities_processed": 156
            },
            {
                "id": 2,
                "name": "Quality Alert Escalation",
                "description": "Escalate quality issues based on severity",
                "rule_type": "quality",
                "is_active": True,
                "last_execution": "2024-01-10T13:30:00Z",
                "success_rate": 98.2,
                "alerts_processed": 23
            }
        ],
        "total": 2,
        "active": 2,
        "inactive": 0,
        "rule_types": ["classification", "quality", "compliance", "discovery"]
    }

@app.get("/api/v4/automation/executions")
async def list_automation_executions():
    """List automation executions"""
    return {
        "executions": [
            {
                "id": 1,
                "rule_id": 1,
                "rule_name": "Auto-classify Customer Data",
                "status": "completed",
                "started_at": "2024-01-10T14:00:00Z",
                "completed_at": "2024-01-10T14:05:23Z",
                "execution_time_ms": 323000,
                "actions_executed": 12,
                "actions_successful": 11,
                "actions_failed": 1
            },
            {
                "id": 2,
                "rule_id": 2,
                "rule_name": "Quality Alert Escalation",
                "status": "running",
                "started_at": "2024-01-10T15:30:00Z",
                "actions_executed": 5,
                "actions_successful": 5,
                "actions_failed": 0
            }
        ],
        "total": 2,
        "running": 1,
        "completed": 1,
        "failed": 0
    }

# ===== MASKING ENDPOINTS =====

@app.get("/api/v4/contracts/{contract_id}/masking/preview")
async def get_masking_preview(contract_id: int, user_role: str = "data_analyst"):
    """Get preview of masked data based on user role"""
    return {
        "contract_id": contract_id,
        "user_role": user_role,
        "masking_applied": True,
        "preview_data": [
            {
                "field": "customer_email",
                "original": "joao.silva@email.com",
                "masked": "j***@email.com",
                "masking_type": "partial"
            },
            {
                "field": "customer_phone",
                "original": "+55 11 99999-9999",
                "masked": "+55 11 ****-****",
                "masking_type": "partial"
            },
            {
                "field": "customer_name",
                "original": "João Silva Santos",
                "masked": "João S. S.",
                "masking_type": "partial"
            }
        ],
        "masking_rules": [
            {
                "field": "customer_email",
                "rule": "Show first character and domain",
                "applies_to_roles": ["data_analyst", "business_user"]
            },
            {
                "field": "customer_phone",
                "rule": "Mask middle digits",
                "applies_to_roles": ["data_analyst", "business_user"]
            }
        ],
        "compliance_note": "Masking applied according to LGPD requirements"
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8004)

