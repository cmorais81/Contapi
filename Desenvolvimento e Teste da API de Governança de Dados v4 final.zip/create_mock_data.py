"""
TBR GDP Core v4.0 - Mock Data Generator
Author: Carlos Morais <carlos.morais@f1rst.com.br>
"""

import psycopg2
import json
from faker import Faker
from datetime import datetime, timedelta
import random
import uuid

fake = Faker('pt_BR')

# Database configuration
DB_CONFIG = {
    'host': 'localhost',
    'port': 5432,
    'database': 'tbr_gdp_core_v4',
    'user': 'tbr_user',
    'password': 'tbr_password'
}

def create_mock_data():
    """Generate comprehensive mock data for all tables"""
    try:
        conn = psycopg2.connect(**DB_CONFIG)
        cursor = conn.cursor()
        
        print("🎭 Generating mock data for TBR GDP Core v4.0...")
        
        # 1. Create Domains
        print("📁 Creating domains...")
        domains_data = [
            ('Customer Data', 'Customer information and profiles', 'carlos.morais@f1rst.com.br'),
            ('Financial Data', 'Financial transactions and records', 'ana.silva@f1rst.com.br'),
            ('Product Data', 'Product catalog and inventory', 'joao.santos@f1rst.com.br'),
            ('Marketing Data', 'Marketing campaigns and analytics', 'maria.costa@f1rst.com.br'),
            ('Operations Data', 'Operational metrics and KPIs', 'pedro.oliveira@f1rst.com.br'),
            ('HR Data', 'Human resources and employee data', 'lucia.ferreira@f1rst.com.br'),
            ('Sales Data', 'Sales transactions and performance', 'ricardo.almeida@f1rst.com.br'),
            ('Compliance Data', 'Regulatory and compliance information', 'fernanda.lima@f1rst.com.br')
        ]
        
        for name, desc, owner in domains_data:
            cursor.execute("""
                INSERT INTO domains (name, description, owner) 
                VALUES (%s, %s, %s)
            """, (name, desc, owner))
        
        # 2. Create RBAC Roles
        print("👥 Creating RBAC roles...")
        roles_data = [
            ('admin', 'System Administrator', 'Full system access and administration', None, {
                'entities': ['create', 'read', 'update', 'delete'],
                'contracts': ['create', 'read', 'update', 'delete', 'approve'],
                'quality': ['create', 'read', 'update', 'delete', 'execute'],
                'permissions': ['create', 'read', 'update', 'delete'],
                'system': ['configure', 'monitor', 'audit']
            }),
            ('data_steward', 'Data Steward', 'Data governance and quality management', None, {
                'entities': ['create', 'read', 'update'],
                'contracts': ['create', 'read', 'update', 'approve'],
                'quality': ['create', 'read', 'update', 'execute'],
                'permissions': ['read'],
                'governance': ['manage', 'audit']
            }),
            ('data_engineer', 'Data Engineer', 'Technical data management and pipelines', None, {
                'entities': ['create', 'read', 'update'],
                'contracts': ['create', 'read', 'update'],
                'quality': ['read', 'execute'],
                'integrations': ['create', 'read', 'update'],
                'monitoring': ['read', 'configure']
            }),
            ('data_analyst', 'Data Analyst', 'Data analysis and reporting', None, {
                'entities': ['read'],
                'contracts': ['read'],
                'quality': ['read'],
                'analytics': ['read', 'create'],
                'marketplace': ['read', 'request']
            }),
            ('business_user', 'Business User', 'Basic data consumption', None, {
                'entities': ['read'],
                'contracts': ['read'],
                'marketplace': ['read', 'request'],
                'analytics': ['read']
            })
        ]
        
        for name, display_name, desc, parent_id, permissions in roles_data:
            cursor.execute("""
                INSERT INTO rbac_roles (name, display_name, description, parent_role_id, permissions) 
                VALUES (%s, %s, %s, %s, %s)
            """, (name, display_name, desc, parent_id, json.dumps(permissions)))
        
        # 3. Create Entities
        print("📊 Creating entities...")
        entity_types = ['table', 'view', 'dataset', 'api', 'file', 'stream']
        classifications = ['public', 'internal', 'confidential', 'restricted']
        
        entities_data = []
        for i in range(50):
            domain_id = random.randint(1, 8)
            entity_type = random.choice(entity_types)
            classification = random.choice(classifications)
            
            entity_data = {
                'name': f"{fake.word()}_{entity_type}_{i+1}",
                'description': fake.text(max_nb_chars=200),
                'domain_id': domain_id,
                'entity_type': entity_type,
                'source_system': random.choice(['SAP', 'Salesforce', 'Oracle', 'MySQL', 'PostgreSQL', 'MongoDB']),
                'database_name': f"db_{fake.word()}",
                'schema_name': random.choice(['public', 'staging', 'prod', 'analytics']),
                'table_name': f"tbl_{fake.word()}",
                'owner': fake.email(),
                'steward': fake.email(),
                'classification': classification,
                'sensitivity_level': random.randint(1, 5),
                'retention_period': random.choice([30, 90, 365, 1095, 2555]),  # days
                'tags': [fake.word() for _ in range(random.randint(2, 5))],
                'metadata': {
                    'row_count': random.randint(1000, 1000000),
                    'size_mb': round(random.uniform(1.0, 1000.0), 2),
                    'last_updated': fake.date_time_between(start_date='-30d', end_date='now').isoformat(),
                    'quality_score': round(random.uniform(0.7, 1.0), 2)
                }
            }
            entities_data.append(entity_data)
        
        for entity in entities_data:
            cursor.execute("""
                INSERT INTO entities (
                    name, description, domain_id, entity_type, source_system,
                    database_name, schema_name, table_name, owner, steward,
                    classification, sensitivity_level, retention_period, tags, metadata
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, (
                entity['name'], entity['description'], entity['domain_id'],
                entity['entity_type'], entity['source_system'], entity['database_name'],
                entity['schema_name'], entity['table_name'], entity['owner'],
                entity['steward'], entity['classification'], entity['sensitivity_level'],
                entity['retention_period'], entity['tags'], json.dumps(entity['metadata'])
            ))
        
        # 4. Create Contracts
        print("📋 Creating contracts...")
        contract_types = ['data_sharing', 'analytics', 'integration', 'api']
        contract_statuses = ['draft', 'pending_review', 'approved', 'published', 'deprecated']
        
        for i in range(30):
            entity_id = random.randint(1, 50)
            contract_type = random.choice(contract_types)
            status = random.choice(contract_statuses)
            
            contract_data = {
                'name': f"Contract {fake.company()} - {contract_type.title()} {i+1}",
                'description': fake.text(max_nb_chars=300),
                'entity_id': entity_id,
                'contract_type': contract_type,
                'version': f"{random.randint(1,3)}.{random.randint(0,9)}.{random.randint(0,9)}",
                'status': status,
                'owner': fake.email(),
                'steward': fake.email(),
                'schema_definition': {
                    'fields': [
                        {
                            'name': fake.word(),
                            'type': random.choice(['string', 'integer', 'decimal', 'boolean', 'date', 'timestamp']),
                            'required': random.choice([True, False]),
                            'description': fake.sentence()
                        } for _ in range(random.randint(3, 8))
                    ]
                },
                'quality_requirements': {
                    'completeness': round(random.uniform(0.8, 1.0), 2),
                    'accuracy': round(random.uniform(0.85, 1.0), 2),
                    'consistency': round(random.uniform(0.9, 1.0), 2),
                    'timeliness': round(random.uniform(0.7, 1.0), 2)
                },
                'access_policies': {
                    'data_analyst': {'read': True, 'write': False, 'delete': False},
                    'data_engineer': {'read': True, 'write': True, 'delete': False},
                    'admin': {'read': True, 'write': True, 'delete': True}
                },
                'sla_requirements': {
                    'availability': 99.9,
                    'response_time_ms': random.randint(100, 2000),
                    'throughput_rps': random.randint(100, 10000)
                },
                'tags': [fake.word() for _ in range(random.randint(2, 4))]
            }
            
            cursor.execute("""
                INSERT INTO contracts (
                    name, description, entity_id, contract_type, version, status,
                    owner, steward, schema_definition, quality_requirements,
                    access_policies, sla_requirements, tags
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, (
                contract_data['name'], contract_data['description'], contract_data['entity_id'],
                contract_data['contract_type'], contract_data['version'], contract_data['status'],
                contract_data['owner'], contract_data['steward'],
                json.dumps(contract_data['schema_definition']),
                json.dumps(contract_data['quality_requirements']),
                json.dumps(contract_data['access_policies']),
                json.dumps(contract_data['sla_requirements']),
                contract_data['tags']
            ))
        
        # 5. Create Quality Rules
        print("✅ Creating quality rules...")
        rule_types = ['not_null', 'format', 'range', 'uniqueness', 'consistency', 'custom']
        severities = ['low', 'medium', 'high', 'critical']
        
        for i in range(40):
            entity_id = random.randint(1, 50)
            rule_type = random.choice(rule_types)
            severity = random.choice(severities)
            
            rule_definition = {}
            if rule_type == 'format':
                rule_definition = {'pattern': r'^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}$'}
            elif rule_type == 'range':
                rule_definition = {'min_value': 0, 'max_value': 100}
            elif rule_type == 'custom':
                rule_definition = {'sql': f"SELECT COUNT(*) FROM table WHERE {fake.word()} IS NOT NULL"}
            
            cursor.execute("""
                INSERT INTO quality_rules (
                    name, description, rule_type, entity_id, column_name,
                    threshold, severity, rule_definition, created_by
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, (
                f"Rule {rule_type.title()} {i+1}",
                fake.text(max_nb_chars=150),
                rule_type,
                entity_id,
                fake.word(),
                round(random.uniform(0.8, 1.0), 2),
                severity,
                json.dumps(rule_definition),
                fake.email()
            ))
        
        # 6. Create Quality Checks
        print("🔍 Creating quality checks...")
        check_statuses = ['completed', 'failed', 'running']
        
        for i in range(100):
            rule_id = random.randint(1, 40)
            entity_id = random.randint(1, 50)
            status = random.choice(check_statuses)
            
            records_checked = random.randint(1000, 100000)
            if status == 'completed':
                records_passed = random.randint(int(records_checked * 0.7), records_checked)
                records_failed = records_checked - records_passed
                quality_score = round(records_passed / records_checked, 2)
            else:
                records_passed = records_failed = quality_score = None
            
            cursor.execute("""
                INSERT INTO quality_checks (
                    rule_id, entity_id, status, records_checked, records_passed,
                    records_failed, quality_score, execution_time_ms, metadata
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, (
                rule_id, entity_id, status, records_checked, records_passed,
                records_failed, quality_score, random.randint(100, 5000),
                json.dumps({'execution_id': str(uuid.uuid4())})
            ))
        
        # 7. Create ABAC Policies
        print("🔐 Creating ABAC policies...")
        policy_types = ['permit', 'deny']
        
        policies_data = [
            {
                'name': 'Customer Data Access Policy',
                'description': 'Allow access to customer data during business hours',
                'policy_type': 'permit',
                'target_expression': {
                    'resource_type': 'entity',
                    'classification': 'confidential',
                    'domain': 'Customer Data'
                },
                'condition_expression': {
                    'time_range': {'start': '08:00', 'end': '18:00'},
                    'user_department': ['sales', 'marketing', 'customer_service']
                }
            },
            {
                'name': 'Financial Data Restriction',
                'description': 'Restrict access to financial data for non-finance users',
                'policy_type': 'deny',
                'target_expression': {
                    'resource_type': 'entity',
                    'classification': 'restricted',
                    'domain': 'Financial Data'
                },
                'condition_expression': {
                    'user_department': ['marketing', 'hr', 'operations']
                }
            },
            {
                'name': 'Analytics Data Access',
                'description': 'Allow analysts to access analytics data',
                'policy_type': 'permit',
                'target_expression': {
                    'resource_type': 'contract',
                    'contract_type': 'analytics'
                },
                'condition_expression': {
                    'user_role': ['data_analyst', 'data_scientist']
                }
            }
        ]
        
        for policy in policies_data:
            cursor.execute("""
                INSERT INTO abac_policies (
                    name, description, policy_type, target_expression,
                    condition_expression, created_by
                ) VALUES (%s, %s, %s, %s, %s, %s)
            """, (
                policy['name'], policy['description'], policy['policy_type'],
                json.dumps(policy['target_expression']),
                json.dumps(policy['condition_expression']),
                'carlos.morais@f1rst.com.br'
            ))
        
        # 8. Create Lineage Relationships
        print("🔗 Creating lineage relationships...")
        relationship_types = ['derives_from', 'feeds_into', 'transforms', 'aggregates']
        
        for i in range(60):
            source_id = random.randint(1, 50)
            target_id = random.randint(1, 50)
            
            if source_id != target_id:  # Avoid self-references
                cursor.execute("""
                    INSERT INTO lineage_relationships (
                        source_entity_id, target_entity_id, relationship_type,
                        transformation_logic, confidence_score, discovered_method
                    ) VALUES (%s, %s, %s, %s, %s, %s)
                """, (
                    source_id, target_id, random.choice(relationship_types),
                    fake.text(max_nb_chars=200),
                    round(random.uniform(0.7, 1.0), 2),
                    random.choice(['manual', 'automatic', 'inferred'])
                ))
        
        # 9. Create Usage Analytics
        print("📈 Creating usage analytics...")
        operation_types = ['read', 'write', 'query', 'download', 'api_call']
        access_methods = ['api', 'direct', 'dashboard', 'report']
        
        # Generate data for last 30 days
        for i in range(500):
            usage_date = fake.date_between(start_date='-30d', end_date='today')
            entity_id = random.randint(1, 50)
            contract_id = random.randint(1, 30) if random.choice([True, False]) else None
            
            cursor.execute("""
                INSERT INTO usage_analytics (
                    usage_date, entity_id, contract_id, user_id, user_role,
                    access_count, data_volume_mb, operation_type, access_method,
                    session_duration_minutes
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, (
                usage_date, entity_id, contract_id, fake.email(),
                random.choice(['data_analyst', 'data_engineer', 'business_user']),
                random.randint(1, 50),
                round(random.uniform(0.1, 100.0), 2),
                random.choice(operation_types),
                random.choice(access_methods),
                random.randint(5, 120)
            ))
        
        # 10. Create Performance Metrics
        print("⚡ Creating performance metrics...")
        metric_types = ['api_latency', 'query_performance', 'system_resource', 'throughput']
        
        # Generate metrics for last 7 days
        for i in range(1000):
            metric_timestamp = fake.date_time_between(start_date='-7d', end_date='now')
            metric_type = random.choice(metric_types)
            
            if metric_type == 'api_latency':
                metric_name = 'response_time'
                metric_value = round(random.uniform(10.0, 2000.0), 2)
                metric_unit = 'ms'
            elif metric_type == 'query_performance':
                metric_name = 'execution_time'
                metric_value = round(random.uniform(100.0, 10000.0), 2)
                metric_unit = 'ms'
            elif metric_type == 'system_resource':
                metric_name = random.choice(['cpu_usage', 'memory_usage', 'disk_usage'])
                metric_value = round(random.uniform(10.0, 95.0), 2)
                metric_unit = 'percentage'
            else:  # throughput
                metric_name = 'requests_per_second'
                metric_value = round(random.uniform(10.0, 1000.0), 2)
                metric_unit = 'rps'
            
            cursor.execute("""
                INSERT INTO performance_metrics (
                    metric_timestamp, metric_type, metric_name, metric_value,
                    metric_unit, entity_id, user_id
                ) VALUES (%s, %s, %s, %s, %s, %s, %s)
            """, (
                metric_timestamp, metric_type, metric_name, metric_value,
                metric_unit, random.randint(1, 50) if random.choice([True, False]) else None,
                fake.email() if random.choice([True, False]) else None
            ))
        
        # 11. Create Audit Logs
        print("📝 Creating audit logs...")
        event_types = ['create', 'update', 'delete', 'access', 'approve', 'reject']
        entity_types = ['entity', 'contract', 'quality_rule', 'policy', 'user']
        
        for i in range(200):
            event_timestamp = fake.date_time_between(start_date='-30d', end_date='now')
            event_type = random.choice(event_types)
            entity_type = random.choice(entity_types)
            
            cursor.execute("""
                INSERT INTO audit_logs (
                    event_id, event_type, entity_type, entity_id, user_id,
                    user_role, action_description, ip_address, user_agent,
                    session_id, timestamp
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, (
                str(uuid.uuid4()),
                event_type,
                entity_type,
                str(random.randint(1, 50)),
                fake.email(),
                random.choice(['admin', 'data_steward', 'data_analyst']),
                f"{event_type.title()} {entity_type} with ID {random.randint(1, 50)}",
                fake.ipv4(),
                fake.user_agent(),
                str(uuid.uuid4()),
                event_timestamp
            ))
        
        # Commit all changes
        conn.commit()
        
        # Get final statistics
        cursor.execute("SELECT COUNT(*) FROM domains")
        domains_count = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM entities")
        entities_count = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM contracts")
        contracts_count = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM quality_rules")
        quality_rules_count = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM usage_analytics")
        analytics_count = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM audit_logs")
        audit_count = cursor.fetchone()[0]
        
        print("\n✅ Mock data generation completed successfully!")
        print(f"📊 Generated data summary:")
        print(f"  - Domains: {domains_count}")
        print(f"  - Entities: {entities_count}")
        print(f"  - Contracts: {contracts_count}")
        print(f"  - Quality Rules: {quality_rules_count}")
        print(f"  - Usage Analytics: {analytics_count}")
        print(f"  - Audit Logs: {audit_count}")
        print(f"  - Total Records: {domains_count + entities_count + contracts_count + quality_rules_count + analytics_count + audit_count}")
        
        cursor.close()
        conn.close()
        
        return True
        
    except Exception as e:
        print(f"❌ Error generating mock data: {e}")
        return False

if __name__ == "__main__":
    create_mock_data()

