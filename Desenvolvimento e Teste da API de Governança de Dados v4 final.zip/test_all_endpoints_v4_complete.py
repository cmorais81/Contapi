"""
TBR GDP Core v4.0 - Complete Endpoint Testing Suite
Author: Carlos Morais <carlos.morais@f1rst.com.br>

This script tests all 80+ endpoints and captures evidence for documentation.
"""

import requests
import json
import time
from datetime import datetime
import os
import sys

# API Configuration
BASE_URL = "http://localhost:8004"
HEADERS = {"Content-Type": "application/json"}

# Test Results Storage
test_results = []
failed_tests = []
evidence_data = {}

def log_test(endpoint, method, status_code, response_time, response_data, success=True):
    """Log test results"""
    result = {
        "endpoint": endpoint,
        "method": method,
        "status_code": status_code,
        "response_time_ms": round(response_time * 1000, 2),
        "timestamp": datetime.utcnow().isoformat(),
        "success": success,
        "response_size": len(str(response_data)) if response_data else 0
    }
    
    test_results.append(result)
    evidence_data[f"{method}_{endpoint.replace('/', '_')}"] = {
        "request": {"method": method, "url": f"{BASE_URL}{endpoint}"},
        "response": response_data,
        "metadata": result
    }
    
    if not success:
        failed_tests.append(result)
    
    status = "✅" if success else "❌"
    print(f"{status} {method} {endpoint} - {status_code} ({result['response_time_ms']}ms)")

def test_endpoint(endpoint, method="GET", data=None, expected_status=200):
    """Test a single endpoint"""
    try:
        start_time = time.time()
        
        if method == "GET":
            response = requests.get(f"{BASE_URL}{endpoint}", headers=HEADERS, timeout=10)
        elif method == "POST":
            response = requests.post(f"{BASE_URL}{endpoint}", headers=HEADERS, json=data, timeout=10)
        elif method == "PUT":
            response = requests.put(f"{BASE_URL}{endpoint}", headers=HEADERS, json=data, timeout=10)
        elif method == "DELETE":
            response = requests.delete(f"{BASE_URL}{endpoint}", headers=HEADERS, timeout=10)
        
        response_time = time.time() - start_time
        
        try:
            response_data = response.json()
        except:
            response_data = {"raw_response": response.text}
        
        success = response.status_code == expected_status
        log_test(endpoint, method, response.status_code, response_time, response_data, success)
        
        return response_data
        
    except Exception as e:
        log_test(endpoint, method, 0, 0, {"error": str(e)}, False)
        return None

def run_comprehensive_tests():
    """Run comprehensive tests for all endpoints"""
    
    print("🚀 Starting TBR GDP Core v4.0 Complete Endpoint Testing")
    print("=" * 60)
    
    # 1. SYSTEM ENDPOINTS
    print("\n📊 Testing System Endpoints...")
    test_endpoint("/")
    test_endpoint("/health")
    test_endpoint("/docs", expected_status=200)
    
    # 2. ENTITIES ENDPOINTS
    print("\n🏢 Testing Entities Endpoints...")
    test_endpoint("/api/v4/entities")
    test_endpoint("/api/v4/entities?skip=0&limit=10")
    test_endpoint("/api/v4/entities/search")
    test_endpoint("/api/v4/entities/search?q=customer")
    test_endpoint("/api/v4/entities/search?entity_type=table")
    test_endpoint("/api/v4/entities/search?classification=confidential")
    test_endpoint("/api/v4/entities/1")
    test_endpoint("/api/v4/entities/2")
    test_endpoint("/api/v4/entities/1/lineage")
    test_endpoint("/api/v4/entities/1/lineage?depth=5")
    
    # Create entity test
    entity_data = {
        "name": "test_entity_api",
        "description": "Test entity created via API",
        "domain_id": 1,
        "entity_type": "table",
        "owner": "carlos.morais@f1rst.com.br",
        "classification": "internal"
    }
    test_endpoint("/api/v4/entities", "POST", entity_data, 200)
    
    # 3. CONTRACTS ENDPOINTS
    print("\n📋 Testing Contracts Endpoints...")
    test_endpoint("/api/v4/contracts")
    test_endpoint("/api/v4/contracts?status=published")
    test_endpoint("/api/v4/contracts?contract_type=data_sharing")
    test_endpoint("/api/v4/contracts/1")
    test_endpoint("/api/v4/contracts/2")
    test_endpoint("/api/v4/contracts/1/versions")
    test_endpoint("/api/v4/contracts/1/versions/compare?version1=1.0.0&version2=1.1.0")
    test_endpoint("/api/v4/contracts/1/dependencies")
    
    # Create contract test
    contract_data = {
        "name": "Test API Contract",
        "description": "Contract created via API testing",
        "entity_id": 1,
        "contract_type": "api",
        "owner": "carlos.morais@f1rst.com.br",
        "schema_definition": {
            "fields": [
                {"name": "id", "type": "integer", "required": True},
                {"name": "name", "type": "string", "required": True}
            ]
        }
    }
    test_endpoint("/api/v4/contracts", "POST", contract_data, 200)
    
    # Contract versioning tests
    version_changes = {
        "schema_changes": ["Added field: customer_segment"],
        "quality_changes": ["Increased completeness threshold to 98%"],
        "reason": "Business requirement update"
    }
    test_endpoint("/api/v4/contracts/1/versions", "POST", version_changes, 200)
    
    # Impact analysis test
    impact_data = {
        "proposed_changes": {
            "schema": {"new_field": "customer_tier"},
            "quality": {"completeness": 0.99}
        }
    }
    test_endpoint("/api/v4/contracts/1/impact-analysis", "POST", impact_data, 200)
    
    # 4. QUALITY ENDPOINTS
    print("\n✅ Testing Quality Endpoints...")
    test_endpoint("/api/v4/quality/rules")
    test_endpoint("/api/v4/quality/rules?entity_id=1")
    test_endpoint("/api/v4/quality/dashboard")
    test_endpoint("/api/v4/quality/metrics/aggregated")
    test_endpoint("/api/v4/quality/metrics/aggregated?entity_ids=1,2,3")
    test_endpoint("/api/v4/quality/trends")
    test_endpoint("/api/v4/quality/trends?days=30")
    
    # Create quality rule test
    quality_rule_data = {
        "name": "Test Email Format Rule",
        "description": "Validate email format in customer data",
        "rule_type": "format",
        "entity_id": 1,
        "threshold": 0.95,
        "severity": "medium",
        "created_by": "carlos.morais@f1rst.com.br"
    }
    test_endpoint("/api/v4/quality/rules", "POST", quality_rule_data, 200)
    
    # Execute quality check test
    test_endpoint("/api/v4/quality/checks?rule_id=1&entity_id=1", "POST", {}, 200)
    
    # 5. PERMISSIONS ENDPOINTS
    print("\n🔐 Testing Permissions Endpoints...")
    test_endpoint("/api/v4/permissions/rbac/roles")
    test_endpoint("/api/v4/permissions/rbac/roles/admin/permissions")
    test_endpoint("/api/v4/permissions/rbac/roles/data_analyst/permissions")
    test_endpoint("/api/v4/permissions/abac/policies")
    test_endpoint("/api/v4/permissions/dashboard")
    
    # ABAC policy evaluation test
    abac_request = {
        "user_id": "carlos.morais@f1rst.com.br",
        "user_role": "data_analyst",
        "resource_type": "entity",
        "resource_id": "1",
        "operation": "read",
        "context": {
            "time": "14:30",
            "ip_address": "192.168.1.100"
        }
    }
    test_endpoint("/api/v4/permissions/abac/evaluate", "POST", abac_request, 200)
    
    # 6. ANALYTICS ENDPOINTS
    print("\n📈 Testing Analytics Endpoints...")
    test_endpoint("/api/v4/analytics/usage")
    test_endpoint("/api/v4/analytics/usage?days=7")
    test_endpoint("/api/v4/analytics/usage?days=30")
    test_endpoint("/api/v4/analytics/trends")
    test_endpoint("/api/v4/analytics/trends?metric=usage&days=30")
    test_endpoint("/api/v4/analytics/trends?metric=quality&days=7")
    
    # 7. MONITORING ENDPOINTS
    print("\n⚡ Testing Monitoring Endpoints...")
    test_endpoint("/api/v4/monitoring/performance")
    test_endpoint("/api/v4/monitoring/azure-costs")
    
    # 8. GOVERNANCE ENDPOINTS
    print("\n⚖️ Testing Governance Endpoints...")
    test_endpoint("/api/v4/governance/framework")
    test_endpoint("/api/v4/governance/compliance")
    
    # 9. MARKETPLACE ENDPOINTS
    print("\n🛒 Testing Marketplace Endpoints...")
    test_endpoint("/api/v4/marketplace/items")
    test_endpoint("/api/v4/marketplace/items?category=Customer Data")
    test_endpoint("/api/v4/marketplace/requests")
    test_endpoint("/api/v4/marketplace/requests?status=pending")
    test_endpoint("/api/v4/marketplace/requests?status=approved")
    
    # 10. POLICIES ENDPOINTS
    print("\n📜 Testing Policies Endpoints...")
    test_endpoint("/api/v4/policies")
    test_endpoint("/api/v4/policies/compliance")
    
    # 11. INTEGRATIONS ENDPOINTS
    print("\n🔗 Testing Integrations Endpoints...")
    test_endpoint("/api/v4/integrations")
    test_endpoint("/api/v4/integrations/status")
    
    # 12. AUTOMATION ENDPOINTS
    print("\n🤖 Testing Automation Endpoints...")
    test_endpoint("/api/v4/automation/rules")
    test_endpoint("/api/v4/automation/executions")
    
    # 13. MASKING ENDPOINTS
    print("\n🎭 Testing Masking Endpoints...")
    test_endpoint("/api/v4/contracts/1/masking/preview")
    test_endpoint("/api/v4/contracts/1/masking/preview?user_role=data_analyst")
    test_endpoint("/api/v4/contracts/1/masking/preview?user_role=business_user")
    test_endpoint("/api/v4/contracts/1/masking/preview?user_role=admin")
    
    # 14. ADDITIONAL ENTITY ENDPOINTS
    print("\n🔍 Testing Additional Entity Endpoints...")
    test_endpoint("/api/v4/entities/3")
    test_endpoint("/api/v4/entities/4")
    test_endpoint("/api/v4/entities/5")
    test_endpoint("/api/v4/entities/2/lineage")
    test_endpoint("/api/v4/entities/3/lineage?depth=2")
    
    # 15. ADDITIONAL CONTRACT ENDPOINTS
    print("\n📄 Testing Additional Contract Endpoints...")
    test_endpoint("/api/v4/contracts/3")
    test_endpoint("/api/v4/contracts/4")
    test_endpoint("/api/v4/contracts/2/versions")
    test_endpoint("/api/v4/contracts/2/dependencies")
    test_endpoint("/api/v4/contracts/3/dependencies")
    
    # 16. ADDITIONAL QUALITY ENDPOINTS
    print("\n🎯 Testing Additional Quality Endpoints...")
    test_endpoint("/api/v4/quality/rules?entity_id=2")
    test_endpoint("/api/v4/quality/rules?entity_id=3")
    test_endpoint("/api/v4/quality/checks?rule_id=2&entity_id=2", "POST", {}, 200)
    test_endpoint("/api/v4/quality/checks?rule_id=3&entity_id=3", "POST", {}, 200)
    
    # 17. EDGE CASES AND ERROR HANDLING
    print("\n⚠️ Testing Edge Cases and Error Handling...")
    test_endpoint("/api/v4/entities/999", expected_status=404)
    test_endpoint("/api/v4/contracts/999", expected_status=404)
    test_endpoint("/api/v4/permissions/rbac/roles/nonexistent/permissions", expected_status=404)
    
    print("\n" + "=" * 60)
    print("🏁 Testing Complete!")
    
    # Generate summary
    total_tests = len(test_results)
    successful_tests = len([t for t in test_results if t['success']])
    failed_tests_count = len(failed_tests)
    
    avg_response_time = sum([t['response_time_ms'] for t in test_results]) / total_tests if total_tests > 0 else 0
    
    print(f"\n📊 TEST SUMMARY:")
    print(f"   Total Endpoints Tested: {total_tests}")
    print(f"   Successful Tests: {successful_tests}")
    print(f"   Failed Tests: {failed_tests_count}")
    print(f"   Success Rate: {(successful_tests/total_tests)*100:.1f}%")
    print(f"   Average Response Time: {avg_response_time:.2f}ms")
    
    if failed_tests:
        print(f"\n❌ FAILED TESTS:")
        for test in failed_tests:
            print(f"   - {test['method']} {test['endpoint']} (Status: {test['status_code']})")
    
    # Save detailed results
    save_test_results()
    
    return {
        "total_tests": total_tests,
        "successful_tests": successful_tests,
        "failed_tests": failed_tests_count,
        "success_rate": (successful_tests/total_tests)*100,
        "avg_response_time": avg_response_time,
        "evidence_data": evidence_data
    }

def save_test_results():
    """Save test results to files"""
    
    # Save summary results
    summary = {
        "test_execution": {
            "timestamp": datetime.utcnow().isoformat(),
            "total_tests": len(test_results),
            "successful_tests": len([t for t in test_results if t['success']]),
            "failed_tests": len(failed_tests),
            "success_rate": (len([t for t in test_results if t['success']])/len(test_results))*100 if test_results else 0,
            "avg_response_time_ms": sum([t['response_time_ms'] for t in test_results]) / len(test_results) if test_results else 0
        },
        "test_results": test_results,
        "failed_tests": failed_tests,
        "evidence_data": evidence_data
    }
    
    with open("test_results_v4_complete.json", "w") as f:
        json.dump(summary, f, indent=2)
    
    # Save evidence for documentation
    with open("api_evidence_v4.json", "w") as f:
        json.dump(evidence_data, f, indent=2)
    
    print(f"\n💾 Test results saved:")
    print(f"   - test_results_v4_complete.json")
    print(f"   - api_evidence_v4.json")

if __name__ == "__main__":
    try:
        results = run_comprehensive_tests()
        
        if results["success_rate"] >= 90:
            print(f"\n🎉 EXCELLENT! {results['success_rate']:.1f}% success rate")
            sys.exit(0)
        elif results["success_rate"] >= 75:
            print(f"\n✅ GOOD! {results['success_rate']:.1f}% success rate")
            sys.exit(0)
        else:
            print(f"\n⚠️ NEEDS IMPROVEMENT! {results['success_rate']:.1f}% success rate")
            sys.exit(1)
            
    except KeyboardInterrupt:
        print("\n\n⏹️ Testing interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n\n❌ Testing failed with error: {e}")
        sys.exit(1)

