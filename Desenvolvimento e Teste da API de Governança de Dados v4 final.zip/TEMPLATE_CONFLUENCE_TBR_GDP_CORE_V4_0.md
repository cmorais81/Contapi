# Template Confluence - TBR GDP Core v4.0

**Autor:** Carlos Morais <carlos.morais@f1rst.com.br>  
**Versão:** 4.0.0  
**Data:** Janeiro 2024  

---

## Estrutura de Páginas para Confluence

### 1. Página Principal - TBR GDP Core v4.0

```
🏠 TBR GDP Core v4.0 - Plataforma de Governança de Dados

📋 Visão Geral
├── 🎯 Objetivos e Benefícios
├── 🏗️ Arquitetura da Solução
├── 📊 Funcionalidades Principais
└── 🚀 Guia de Início Rápido

📚 Documentação Técnica
├── 🔧 Guia de Instalação
├── ⚙️ Configuração e Setup
├── 🔌 APIs e Integrações
└── 🛠️ Troubleshooting

👥 Guias por Perfil
├── 👨‍💼 Data Steward
├── 👨‍💻 Data Engineer  
├── 📊 Data Analyst
└── 🏢 Business User

📈 Casos de Uso
├── 🔍 Descoberta de Dados
├── 📋 Contratos de Dados
├── ✅ Qualidade de Dados
└── 🔐 Governança e Compliance

🎓 Treinamento e Suporte
├── 📹 Vídeos Tutoriais
├── 📖 Documentação de APIs
├── ❓ FAQ
└── 🆘 Suporte Técnico
```

### 2. Template de Página - Visão Geral

```confluence
{panel:title=TBR GDP Core v4.0 - Plataforma de Governança de Dados|borderStyle=solid|borderColor=#0052CC|titleBGColor=#E6F3FF|bgColor=#F8FBFF}

## 🎯 O que é o TBR GDP Core?

O TBR GDP Core v4.0 é uma plataforma completa de governança de dados que automatiza e simplifica a gestão de ativos de dados organizacionais. A solução oferece:

- **Catálogo Inteligente**: Descoberta e catalogação automática de dados
- **Contratos de Dados**: Acordos formais sobre estrutura e qualidade
- **Qualidade Contínua**: Monitoramento e melhoria automática da qualidade
- **Segurança Avançada**: Controles RBAC/ABAC granulares
- **Compliance Automático**: Conformidade com LGPD, GDPR e SOX

{panel}

{info:title=💡 Benefícios Principais}
✅ **70% redução** no tempo de descoberta de dados  
✅ **40-60% melhoria** nos scores de qualidade  
✅ **90% redução** no tempo de preparação para auditorias  
✅ **35% aumento** na produtividade de equipes analíticas  
{info}

## 🏗️ Arquitetura da Solução

{expand:title=Clique para ver a arquitetura detalhada}

### Stack Tecnológico
- **Backend**: FastAPI + Python 3.11
- **Banco de Dados**: PostgreSQL 14+
- **APIs**: REST + OpenAPI/Swagger
- **Segurança**: JWT + RBAC/ABAC
- **Monitoramento**: Métricas em tempo real

### Componentes Principais
1. **Catálogo de Entidades**: Gestão centralizada de metadados
2. **Motor de Contratos**: Versionamento e gestão de acordos
3. **Engine de Qualidade**: Regras e verificações automáticas
4. **Sistema de Permissões**: Controles de acesso granulares
5. **Analytics**: Métricas de uso e performance

{expand}

## 📊 Funcionalidades por Módulo

{section:border=true}
{column:width=50%}
### 🏢 Gestão de Entidades
- Catálogo centralizado
- Busca avançada
- Classificação automática
- Linhagem de dados
- Metadados enriquecidos

### 📋 Contratos de Dados
- Definição de acordos
- Versionamento semântico
- Análise de impacto
- Workflows de aprovação
- Comparação de versões
{column}

{column:width=50%}
### ✅ Qualidade de Dados
- 6 dimensões de qualidade
- Regras configuráveis
- Monitoramento contínuo
- Correção automática
- Dashboards executivos

### 🔐 Segurança e Compliance
- RBAC + ABAC
- Auditoria completa
- Mascaramento dinâmico
- Compliance LGPD/GDPR
- Políticas configuráveis
{column}
{section}

## 🚀 Guia de Início Rápido

{note:title=⚡ Primeiros Passos}
1. **Acesse a plataforma**: [http://localhost:8004](http://localhost:8004)
2. **Faça login** com suas credenciais corporativas
3. **Explore o catálogo** de dados disponíveis
4. **Solicite acesso** aos dados necessários
5. **Configure alertas** de qualidade relevantes
{note}

{tip:title=🎯 Próximos Passos}
- Consulte o **Guia do seu Perfil** para funcionalidades específicas
- Assista aos **Vídeos Tutoriais** para aprender na prática
- Participe do **Treinamento** da sua área
- Entre em contato com o **Suporte** para dúvidas
{tip}
```

### 3. Template de Página - Guia por Perfil

```confluence
{panel:title=👨‍💼 Guia do Data Steward|borderStyle=solid|borderColor=#36B37E|titleBGColor=#E3FCEF|bgColor=#F3FFF5}

## 🎯 Suas Responsabilidades

Como Data Steward, você é responsável por:
- Definir e manter políticas de governança
- Configurar regras de qualidade
- Aprovar contratos de dados
- Monitorar compliance
- Resolver conflitos de acesso

{panel}

## 📋 Tarefas Principais

{section:border=true}
{column:width=50%}
### 🔧 Configuração Inicial
1. **Definir Domínios de Dados**
   - Criar estrutura organizacional
   - Atribuir responsabilidades
   - Configurar hierarquias

2. **Estabelecer Políticas**
   - Classificação de dados
   - Retenção e expurgo
   - Controles de acesso

3. **Configurar Qualidade**
   - Definir regras por domínio
   - Estabelecer thresholds
   - Configurar alertas
{column}

{column:width=50%}
### 📊 Operação Diária
1. **Monitorar Dashboards**
   - Qualidade por domínio
   - Compliance status
   - Alertas pendentes

2. **Aprovar Solicitações**
   - Novos contratos
   - Mudanças de acesso
   - Exceções de política

3. **Resolver Problemas**
   - Investigar alertas
   - Coordenar correções
   - Comunicar stakeholders
{column}
{section}

## 🛠️ Ferramentas e Recursos

{info:title=🔗 Links Úteis}
- **Dashboard Executivo**: [/governance/dashboard](http://localhost:8004/governance/dashboard)
- **Configuração de Políticas**: [/policies](http://localhost:8004/policies)
- **Regras de Qualidade**: [/quality/rules](http://localhost:8004/quality/rules)
- **Auditoria**: [/audit](http://localhost:8004/audit)
{info}

{expand:title=📹 Vídeos Tutoriais Específicos}
1. **Configuração Inicial** (15 min)
2. **Definindo Políticas de Qualidade** (20 min)
3. **Gestão de Contratos** (25 min)
4. **Monitoramento e Alertas** (18 min)
5. **Relatórios de Compliance** (12 min)
{expand}

## ❓ FAQ - Data Steward

{expand:title=Como definir regras de qualidade efetivas?}
**Resposta**: Comece com regras básicas (completude, formato) e evolua gradualmente. Use dados históricos para definir thresholds realistas. Monitore falsos positivos e ajuste conforme necessário.
{expand}

{expand:title=Como lidar com conflitos entre domínios?}
**Resposta**: Use o processo de escalação definido. Documente o conflito, colete evidências e apresente ao Data Governance Council para decisão final.
{expand}

{expand:title=Qual a frequência ideal para revisão de políticas?}
**Resposta**: Políticas críticas devem ser revisadas trimestralmente. Políticas operacionais podem ser revisadas semestralmente. Use métricas de compliance para priorizar revisões.
{expand}
```

### 4. Template de Página - API Documentation

```confluence
{panel:title=🔌 Documentação de APIs - TBR GDP Core v4.0|borderStyle=solid|borderColor=#FF5630|titleBGColor=#FFEBE6|bgColor=#FFF8F7}

## 📖 Referência Completa de APIs

Esta página documenta todas as APIs disponíveis no TBR GDP Core v4.0, organizadas por módulo funcional.

**Base URL**: `http://localhost:8004`  
**Autenticação**: Bearer Token (JWT)  
**Formato**: JSON  
**Documentação Interativa**: [/docs](http://localhost:8004/docs)

{panel}

## 🏢 APIs de Entidades

{code:language=http|title=Listar Entidades}
GET /api/v4/entities?skip=0&limit=100
Authorization: Bearer {token}

Response:
{
  "entities": [...],
  "total": 150,
  "skip": 0,
  "limit": 100,
  "has_more": true
}
{code}

{code:language=http|title=Buscar Entidades}
GET /api/v4/entities/search?q=customer&entity_type=table
Authorization: Bearer {token}

Response:
{
  "entities": [...],
  "query": "customer",
  "filters": {
    "entity_type": "table"
  },
  "total_found": 25
}
{code}

{code:language=http|title=Criar Entidade}
POST /api/v4/entities
Authorization: Bearer {token}
Content-Type: application/json

{
  "name": "customer_profiles",
  "description": "Customer demographic and behavioral data",
  "domain_id": 1,
  "entity_type": "table",
  "owner": "carlos.morais@f1rst.com.br",
  "classification": "confidential"
}
{code}

{expand:title=Ver mais endpoints de Entidades}
- `GET /api/v4/entities/{id}` - Obter detalhes de entidade
- `PUT /api/v4/entities/{id}` - Atualizar entidade
- `DELETE /api/v4/entities/{id}` - Remover entidade
- `GET /api/v4/entities/{id}/lineage` - Obter linhagem
- `GET /api/v4/entities/{id}/contracts` - Listar contratos relacionados
{expand}

## 📋 APIs de Contratos

{code:language=http|title=Listar Contratos}
GET /api/v4/contracts?status=published&contract_type=data_sharing
Authorization: Bearer {token}

Response:
{
  "contracts": [...],
  "filters": {
    "status": "published",
    "contract_type": "data_sharing"
  },
  "total": 45
}
{code}

{code:language=http|title=Criar Contrato}
POST /api/v4/contracts
Authorization: Bearer {token}
Content-Type: application/json

{
  "name": "Customer Data Sharing Agreement",
  "description": "Contract for sharing customer data with analytics team",
  "entity_id": 1,
  "contract_type": "data_sharing",
  "owner": "carlos.morais@f1rst.com.br",
  "schema_definition": {
    "fields": [
      {"name": "customer_id", "type": "integer", "required": true},
      {"name": "email", "type": "string", "required": true}
    ]
  },
  "quality_requirements": {
    "completeness": 0.95,
    "accuracy": 0.90
  }
}
{code}

{expand:title=Ver mais endpoints de Contratos}
- `GET /api/v4/contracts/{id}` - Obter detalhes do contrato
- `POST /api/v4/contracts/{id}/versions` - Criar nova versão
- `GET /api/v4/contracts/{id}/versions` - Listar versões
- `GET /api/v4/contracts/{id}/versions/compare` - Comparar versões
- `POST /api/v4/contracts/{id}/impact-analysis` - Analisar impacto
{expand}

## ✅ APIs de Qualidade

{code:language=http|title=Executar Verificação de Qualidade}
POST /api/v4/quality/checks?rule_id=1&entity_id=1
Authorization: Bearer {token}

Response:
{
  "check_id": 123,
  "rule_id": 1,
  "entity_id": 1,
  "status": "completed",
  "results": {
    "records_checked": 10000,
    "records_passed": 9500,
    "records_failed": 500,
    "quality_score": 0.95,
    "execution_time_ms": 1250
  }
}
{code}

{expand:title=Ver mais endpoints de Qualidade}
- `GET /api/v4/quality/rules` - Listar regras de qualidade
- `POST /api/v4/quality/rules` - Criar regra de qualidade
- `GET /api/v4/quality/dashboard` - Dashboard de qualidade
- `GET /api/v4/quality/trends` - Tendências de qualidade
{expand}

## 🔐 APIs de Permissões

{code:language=http|title=Avaliar Política ABAC}
POST /api/v4/permissions/abac/evaluate
Authorization: Bearer {token}
Content-Type: application/json

{
  "user_id": "carlos.morais@f1rst.com.br",
  "user_role": "data_analyst",
  "resource_type": "entity",
  "resource_id": "1",
  "operation": "read",
  "context": {
    "time": "14:30",
    "ip_address": "192.168.1.100"
  }
}

Response:
{
  "decision": "permit",
  "evaluated_policies": [...],
  "obligations": ["Log access attempt"],
  "evaluation_time_ms": 15
}
{code}

## 📊 Códigos de Status HTTP

{section:border=true}
{column:width=50%}
### ✅ Sucesso
- **200 OK**: Operação bem-sucedida
- **201 Created**: Recurso criado
- **204 No Content**: Operação sem retorno

### ⚠️ Erro do Cliente
- **400 Bad Request**: Dados inválidos
- **401 Unauthorized**: Não autenticado
- **403 Forbidden**: Sem permissão
- **404 Not Found**: Recurso não encontrado
{column}

{column:width=50%}
### 🔧 Erro do Servidor
- **500 Internal Server Error**: Erro interno
- **502 Bad Gateway**: Erro de gateway
- **503 Service Unavailable**: Serviço indisponível

### 📈 Rate Limiting
- **429 Too Many Requests**: Limite excedido
- Headers: `X-RateLimit-Limit`, `X-RateLimit-Remaining`
{column}
{section}

{tip:title=💡 Dicas de Uso}
- Use a **documentação interativa** em `/docs` para testar APIs
- Implemente **retry logic** com backoff exponencial
- Monitore **rate limits** para evitar bloqueios
- Use **paginação** para grandes volumes de dados
{tip}
```

### 5. Template de Página - Troubleshooting

```confluence
{panel:title=🛠️ Troubleshooting - TBR GDP Core v4.0|borderStyle=solid|borderColor=#FF8B00|titleBGColor=#FFF4E6|bgColor=#FFFBF7}

## 🔍 Guia de Resolução de Problemas

Esta página contém soluções para problemas comuns e procedimentos de diagnóstico.

{panel}

## 🚨 Problemas Comuns

{expand:title=❌ Erro de Conexão com Banco de Dados}
**Sintomas**: 
- API retorna erro 500
- Mensagem "Database connection failed"
- Timeout em operações

**Diagnóstico**:
```bash
# Verificar status do PostgreSQL
sudo systemctl status postgresql

# Testar conexão
psql -h localhost -U tbr_user -d tbr_gdp_core_v4 -c "SELECT 1;"

# Verificar logs
tail -f /var/log/postgresql/postgresql-14-main.log
```

**Soluções**:
1. Reiniciar serviço PostgreSQL: `sudo systemctl restart postgresql`
2. Verificar configurações de conexão no arquivo de configuração
3. Validar credenciais de banco de dados
4. Verificar disponibilidade de recursos (CPU, memória, disco)
{expand}

{expand:title=🔐 Problemas de Autenticação}
**Sintomas**:
- Erro 401 Unauthorized
- Token JWT inválido
- Falha no login SSO

**Diagnóstico**:
```bash
# Verificar validade do token
curl -H "Authorization: Bearer {token}" http://localhost:8004/health

# Verificar logs de autenticação
grep "authentication" /var/log/tbr-gdp-core/app.log
```

**Soluções**:
1. Renovar token JWT através do endpoint de refresh
2. Verificar configuração de SSO
3. Validar certificados SSL
4. Verificar sincronização de horário do servidor
{expand}

{expand:title=⚡ Performance Lenta}
**Sintomas**:
- APIs respondem lentamente (>2s)
- Timeout em operações
- Alta utilização de recursos

**Diagnóstico**:
```sql
-- Verificar queries lentas
SELECT query, mean_exec_time, calls 
FROM pg_stat_statements 
WHERE mean_exec_time > 1000 
ORDER BY mean_exec_time DESC;

-- Verificar conexões ativas
SELECT count(*) FROM pg_stat_activity;
```

**Soluções**:
1. Otimizar queries identificadas como lentas
2. Adicionar índices apropriados
3. Aumentar connection pool
4. Verificar recursos de sistema (CPU, RAM, I/O)
{expand}

## 🔧 Ferramentas de Diagnóstico

{section:border=true}
{column:width=50%}
### 📊 Health Checks
```bash
# Status geral da aplicação
curl http://localhost:8004/health

# Métricas de performance
curl http://localhost:8004/api/v4/monitoring/performance

# Status de integrações
curl http://localhost:8004/api/v4/integrations/status
```

### 📝 Logs Importantes
```bash
# Logs da aplicação
tail -f /var/log/tbr-gdp-core/app.log

# Logs de auditoria
tail -f /var/log/tbr-gdp-core/audit.log

# Logs de qualidade
tail -f /var/log/tbr-gdp-core/quality.log
```
{column}

{column:width=50%}
### 🗄️ Verificações de Banco
```sql
-- Verificar tamanho das tabelas
SELECT schemaname, tablename, 
       pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename)) as size
FROM pg_tables 
WHERE schemaname = 'public' 
ORDER BY pg_total_relation_size(schemaname||'.'||tablename) DESC;

-- Verificar índices não utilizados
SELECT schemaname, tablename, indexname, idx_scan
FROM pg_stat_user_indexes 
WHERE idx_scan = 0;
```

### 🔍 Monitoramento
```bash
# Utilização de recursos
htop

# Espaço em disco
df -h

# Conexões de rede
netstat -tulpn | grep 8004
```
{column}
{section}

## 📞 Escalação de Suporte

{warning:title=🆘 Quando Escalar}
Escale para o suporte técnico quando:
- Problemas persistem após seguir este guia
- Erro afeta múltiplos usuários
- Suspeita de problema de segurança
- Perda de dados ou corrupção
{warning}

{info:title=📧 Informações para Suporte}
Ao abrir chamado, inclua:
- **Descrição detalhada** do problema
- **Passos para reproduzir** o erro
- **Logs relevantes** (últimas 100 linhas)
- **Horário** de ocorrência
- **Usuários afetados**
- **Ambiente** (dev/test/prod)
{info}

### 📋 Template de Chamado

```
Título: [URGÊNCIA] Descrição breve do problema

Ambiente: [DEV/TEST/PROD]
Horário: [YYYY-MM-DD HH:MM:SS]
Usuários Afetados: [Número ou lista]

Descrição:
[Descrição detalhada do problema]

Passos para Reproduzir:
1. [Passo 1]
2. [Passo 2]
3. [Resultado esperado vs obtido]

Logs:
[Colar logs relevantes]

Ações Já Tentadas:
[Listar o que já foi tentado]
```

## 🔄 Procedimentos de Recuperação

{expand:title=💾 Backup e Restore}
**Backup Automático**:
```bash
# Backup completo
pg_dump -h localhost -U tbr_user tbr_gdp_core_v4 > backup_$(date +%Y%m%d_%H%M%S).sql

# Backup apenas dados
pg_dump -h localhost -U tbr_user --data-only tbr_gdp_core_v4 > data_backup.sql
```

**Restore**:
```bash
# Restore completo
psql -h localhost -U tbr_user tbr_gdp_core_v4 < backup_file.sql

# Restore apenas dados
psql -h localhost -U tbr_user tbr_gdp_core_v4 < data_backup.sql
```
{expand}

{expand:title=🔄 Restart de Serviços}
**Ordem de Restart**:
1. PostgreSQL: `sudo systemctl restart postgresql`
2. Aplicação: `sudo systemctl restart tbr-gdp-core`
3. Nginx (se aplicável): `sudo systemctl restart nginx`

**Verificação**:
```bash
# Verificar status dos serviços
sudo systemctl status postgresql tbr-gdp-core

# Testar conectividade
curl http://localhost:8004/health
```
{expand}
```

### 6. Estrutura de Navegação Recomendada

```confluence
📁 TBR GDP Core v4.0
├── 🏠 Página Principal
├── 📋 Visão Geral
│   ├── Objetivos e Benefícios
│   ├── Arquitetura da Solução
│   └── Funcionalidades Principais
├── 👥 Guias por Perfil
│   ├── 👨‍💼 Data Steward
│   ├── 👨‍💻 Data Engineer
│   ├── 📊 Data Analyst
│   └── 🏢 Business User
├── 📚 Documentação Técnica
│   ├── 🔧 Guia de Instalação
│   ├── ⚙️ Configuração e Setup
│   ├── 🔌 APIs e Integrações
│   └── 🛠️ Troubleshooting
├── 📈 Casos de Uso
│   ├── 🔍 Descoberta de Dados
│   ├── 📋 Contratos de Dados
│   ├── ✅ Qualidade de Dados
│   └── 🔐 Governança e Compliance
└── 🎓 Treinamento e Suporte
    ├── 📹 Vídeos Tutoriais
    ├── 📖 Documentação de APIs
    ├── ❓ FAQ
    └── 🆘 Suporte Técnico
```

### 7. Macros e Formatação Confluence

```confluence
{panel:title=Título|borderStyle=solid|borderColor=#0052CC|titleBGColor=#E6F3FF|bgColor=#F8FBFF}
Conteúdo do painel
{panel}

{info:title=Informação Importante}
Texto informativo
{info}

{tip:title=Dica Útil}
Dica para o usuário
{tip}

{warning:title=Atenção}
Aviso importante
{warning}

{note:title=Nota}
Observação adicional
{note}

{expand:title=Clique para expandir}
Conteúdo expansível
{expand}

{code:language=json|title=Exemplo de JSON}
{
  "exemplo": "código"
}
{code}

{section:border=true}
{column:width=50%}
Coluna 1
{column}
{column:width=50%}
Coluna 2
{column}
{section}
```

Este template fornece uma estrutura completa e profissional para documentação no Confluence, com formatação rica, navegação intuitiva e conteúdo organizado por perfil de usuário.

