# 📋 TBR GDP Core V5.0 - Guia Completo de Layouts e Schemas de Contratos

**🎯 Como definir, alterar e evoluir layouts de Data Contracts**

---

## 🔍 Visão Geral

No TBR GDP Core, os **layouts** dos contratos são definidos através do campo `schema_definition`, que utiliza **JSON Schema** para descrever a estrutura dos dados. Isso permite flexibilidade total para definir qualquer tipo de "capítulo" ou seção no seu contrato.

---

## 📝 1. Definindo um Layout Inicial

### Estrutura Básica do Schema

```json
{
  "type": "object",
  "properties": {
    "campo1": {
      "type": "string",
      "description": "Descrição do campo"
    },
    "campo2": {
      "type": "integer",
      "description": "Campo numérico"
    }
  },
  "required": ["campo1"]
}
```

### Exemplo Prático: Contrato de Clientes

```bash
curl -X POST http://localhost:8000/api/v1/contracts/ \
  -H "Content-Type: application/json" \
  -d '{
    "name": "customer_data_v1",
    "description": "Dados básicos de clientes",
    "contract_type": "data_product",
    "domain": "customer_management",
    "owner": "carlos.morais@tbr.com.br",
    "schema_definition": {
      "type": "object",
      "title": "Customer Data Contract",
      "description": "Estrutura de dados de clientes",
      "properties": {
        "customer_id": {
          "type": "string",
          "format": "uuid",
          "description": "Identificador único do cliente"
        },
        "personal_info": {
          "type": "object",
          "description": "Informações pessoais",
          "properties": {
            "full_name": {
              "type": "string",
              "maxLength": 100,
              "description": "Nome completo"
            },
            "email": {
              "type": "string",
              "format": "email",
              "description": "Email principal"
            },
            "phone": {
              "type": "string",
              "pattern": "^\\+55\\d{10,11}$",
              "description": "Telefone brasileiro"
            }
          },
          "required": ["full_name", "email"]
        },
        "address": {
          "type": "object",
          "description": "Endereço do cliente",
          "properties": {
            "street": {"type": "string"},
            "city": {"type": "string"},
            "state": {"type": "string", "maxLength": 2},
            "zip_code": {"type": "string", "pattern": "^\\d{5}-?\\d{3}$"}
          }
        }
      },
      "required": ["customer_id", "personal_info"]
    }
  }'
```

---

## 🔄 2. Adicionando Novos "Capítulos" ao Contrato

### Cenário: Adicionar seção de "Histórico de Compras"

Para adicionar um novo capítulo/seção ao seu contrato, você atualiza o `schema_definition`:

```bash
curl -X PUT http://localhost:8000/api/v1/contracts/1 \
  -H "Content-Type: application/json" \
  -d '{
    "schema_definition": {
      "type": "object",
      "title": "Customer Data Contract - Enhanced",
      "description": "Estrutura completa de dados de clientes",
      "properties": {
        "customer_id": {
          "type": "string",
          "format": "uuid",
          "description": "Identificador único do cliente"
        },
        "personal_info": {
          "type": "object",
          "description": "Informações pessoais",
          "properties": {
            "full_name": {"type": "string", "maxLength": 100},
            "email": {"type": "string", "format": "email"},
            "phone": {"type": "string", "pattern": "^\\+55\\d{10,11}$"},
            "birth_date": {"type": "string", "format": "date"}
          },
          "required": ["full_name", "email"]
        },
        "address": {
          "type": "object",
          "description": "Endereço do cliente",
          "properties": {
            "street": {"type": "string"},
            "city": {"type": "string"},
            "state": {"type": "string", "maxLength": 2},
            "zip_code": {"type": "string", "pattern": "^\\d{5}-?\\d{3}$"}
          }
        },
        "purchase_history": {
          "type": "object",
          "description": "🆕 NOVO CAPÍTULO: Histórico de compras",
          "properties": {
            "total_purchases": {
              "type": "integer",
              "minimum": 0,
              "description": "Total de compras realizadas"
            },
            "total_spent": {
              "type": "number",
              "minimum": 0,
              "description": "Valor total gasto"
            },
            "last_purchase_date": {
              "type": "string",
              "format": "date-time",
              "description": "Data da última compra"
            },
            "favorite_categories": {
              "type": "array",
              "items": {"type": "string"},
              "description": "Categorias preferidas"
            },
            "loyalty_tier": {
              "type": "string",
              "enum": ["bronze", "silver", "gold", "platinum"],
              "description": "Nível de fidelidade"
            }
          }
        },
        "preferences": {
          "type": "object",
          "description": "🆕 NOVO CAPÍTULO: Preferências do cliente",
          "properties": {
            "communication_channels": {
              "type": "array",
              "items": {
                "type": "string",
                "enum": ["email", "sms", "whatsapp", "phone"]
              },
              "description": "Canais de comunicação preferidos"
            },
            "marketing_consent": {
              "type": "boolean",
              "description": "Consentimento para marketing"
            },
            "language": {
              "type": "string",
              "default": "pt-BR",
              "description": "Idioma preferido"
            }
          }
        }
      },
      "required": ["customer_id", "personal_info"]
    }
  }'
```

---

## 📊 3. Versionamento de Layouts

### Criando Nova Versão com Layout Expandido

Quando você faz mudanças significativas no layout, é recomendado criar uma nova versão:

```bash
curl -X POST http://localhost:8000/api/v1/contracts/1/versions \
  -H "Content-Type: application/json" \
  -d '{
    "version": "2.0.0",
    "changes": "Adicionados capítulos de histórico de compras e preferências",
    "change_type": "major",
    "backward_compatible": false,
    "schema_definition": {
      // ... novo schema completo aqui
    },
    "migration_notes": "Novos campos opcionais adicionados. Sistemas existentes continuam funcionando."
  }'
```

---

## 🎨 4. Tipos de Layouts Suportados

### 4.1 Layout Simples (Flat)
```json
{
  "type": "object",
  "properties": {
    "id": {"type": "string"},
    "name": {"type": "string"},
    "value": {"type": "number"}
  }
}
```

### 4.2 Layout Hierárquico (Nested)
```json
{
  "type": "object",
  "properties": {
    "header": {
      "type": "object",
      "properties": {
        "title": {"type": "string"},
        "version": {"type": "string"}
      }
    },
    "body": {
      "type": "object",
      "properties": {
        "sections": {
          "type": "array",
          "items": {
            "type": "object",
            "properties": {
              "section_name": {"type": "string"},
              "content": {"type": "object"}
            }
          }
        }
      }
    }
  }
}
```

### 4.3 Layout com Arrays (Listas)
```json
{
  "type": "object",
  "properties": {
    "transactions": {
      "type": "array",
      "items": {
        "type": "object",
        "properties": {
          "transaction_id": {"type": "string"},
          "amount": {"type": "number"},
          "date": {"type": "string", "format": "date-time"}
        }
      }
    }
  }
}
```

### 4.4 Layout com Validações Avançadas
```json
{
  "type": "object",
  "properties": {
    "financial_data": {
      "type": "object",
      "properties": {
        "income": {
          "type": "number",
          "minimum": 0,
          "maximum": 1000000,
          "description": "Renda mensal em reais"
        },
        "credit_score": {
          "type": "integer",
          "minimum": 0,
          "maximum": 1000,
          "description": "Score de crédito"
        },
        "risk_category": {
          "type": "string",
          "enum": ["low", "medium", "high"],
          "description": "Categoria de risco"
        }
      }
    }
  }
}
```

---

## 🔧 5. Ferramentas para Gerenciar Layouts

### 5.1 Validação de Schema
```bash
# Validar se um schema está correto
curl -X POST http://localhost:8000/api/v1/contracts/1/validate \
  -H "Content-Type: application/json" \
  -d '{
    "validation_type": "schema",
    "validation_config": {
      "strict_mode": true,
      "check_examples": true
    }
  }'
```

### 5.2 Comparação de Versões
```bash
# Comparar schemas entre versões
curl http://localhost:8000/api/v1/contracts/1/versions/compare?from=1.0.0&to=2.0.0
```

### 5.3 Geração de Documentação
```bash
# Gerar documentação do schema
curl http://localhost:8000/api/v1/contracts/1/documentation
```

---

## 📋 6. Exemplos Práticos de Layouts

### 6.1 Contrato de Vendas
```json
{
  "type": "object",
  "title": "Sales Transaction Contract",
  "properties": {
    "transaction_header": {
      "type": "object",
      "properties": {
        "transaction_id": {"type": "string", "format": "uuid"},
        "transaction_date": {"type": "string", "format": "date-time"},
        "sales_rep": {"type": "string"},
        "channel": {"type": "string", "enum": ["online", "store", "phone"]}
      }
    },
    "customer_info": {
      "type": "object",
      "properties": {
        "customer_id": {"type": "string"},
        "customer_type": {"type": "string", "enum": ["individual", "corporate"]}
      }
    },
    "items": {
      "type": "array",
      "items": {
        "type": "object",
        "properties": {
          "product_id": {"type": "string"},
          "quantity": {"type": "integer", "minimum": 1},
          "unit_price": {"type": "number", "minimum": 0},
          "discount": {"type": "number", "minimum": 0, "maximum": 100}
        }
      }
    },
    "payment": {
      "type": "object",
      "properties": {
        "method": {"type": "string", "enum": ["credit", "debit", "cash", "pix"]},
        "total_amount": {"type": "number", "minimum": 0},
        "currency": {"type": "string", "default": "BRL"}
      }
    }
  }
}
```

### 6.2 Contrato de Logs de Sistema
```json
{
  "type": "object",
  "title": "System Log Contract",
  "properties": {
    "log_metadata": {
      "type": "object",
      "properties": {
        "timestamp": {"type": "string", "format": "date-time"},
        "log_level": {"type": "string", "enum": ["DEBUG", "INFO", "WARN", "ERROR"]},
        "source_system": {"type": "string"},
        "environment": {"type": "string", "enum": ["dev", "staging", "prod"]}
      }
    },
    "event_data": {
      "type": "object",
      "properties": {
        "event_type": {"type": "string"},
        "user_id": {"type": "string"},
        "session_id": {"type": "string"},
        "ip_address": {"type": "string", "format": "ipv4"}
      }
    },
    "technical_details": {
      "type": "object",
      "properties": {
        "execution_time_ms": {"type": "integer", "minimum": 0},
        "memory_usage_mb": {"type": "number", "minimum": 0},
        "error_code": {"type": "string"},
        "stack_trace": {"type": "string"}
      }
    }
  }
}
```

---

## 🚀 7. Workflow Completo de Alteração

### Passo 1: Planejar a Mudança
```bash
# 1. Verificar contrato atual
curl http://localhost:8000/api/v1/contracts/1

# 2. Analisar impacto
curl http://localhost:8000/api/v1/contracts/1/impact-analysis
```

### Passo 2: Criar Nova Versão
```bash
# 3. Criar versão de desenvolvimento
curl -X POST http://localhost:8000/api/v1/contracts/1/versions \
  -d '{"version": "2.0.0-dev", "changes": "Adicionando novos capítulos"}'
```

### Passo 3: Atualizar Schema
```bash
# 4. Atualizar schema da nova versão
curl -X PUT http://localhost:8000/api/v1/contracts/1/versions/2.0.0-dev \
  -d '{"schema_definition": { /* novo schema */ }}'
```

### Passo 4: Validar e Testar
```bash
# 5. Validar novo schema
curl -X POST http://localhost:8000/api/v1/contracts/1/validate

# 6. Testar com dados de exemplo
curl -X POST http://localhost:8000/api/v1/contracts/1/test-data \
  -d '{"sample_data": { /* dados de teste */ }}'
```

### Passo 5: Aprovar e Publicar
```bash
# 7. Solicitar aprovação
curl -X POST http://localhost:8000/api/v1/contracts/1/approval \
  -d '{"approval_type": "schema_change", "comments": "Novos capítulos aprovados"}'

# 8. Publicar versão final
curl -X POST http://localhost:8000/api/v1/contracts/1/versions/2.0.0-dev/publish
```

---

## 📊 8. Monitoramento de Mudanças

### Auditoria de Alterações
```bash
# Ver histórico de mudanças
curl http://localhost:8000/api/v1/contracts/1/audit-log

# Comparar versões
curl http://localhost:8000/api/v1/contracts/1/versions/compare?from=1.0.0&to=2.0.0
```

### Métricas de Uso
```bash
# Ver quais campos são mais utilizados
curl http://localhost:8000/api/v1/contracts/1/usage-metrics

# Identificar campos não utilizados
curl http://localhost:8000/api/v1/contracts/1/unused-fields
```

---

## 🎯 9. Melhores Práticas

### ✅ Recomendações

1. **Versionamento Semântico**
   - Major: Mudanças que quebram compatibilidade
   - Minor: Novos campos opcionais
   - Patch: Correções de documentação

2. **Campos Obrigatórios**
   - Minimize campos obrigatórios
   - Use defaults quando possível
   - Documente bem os requisitos

3. **Documentação**
   - Sempre inclua `description` nos campos
   - Use exemplos práticos
   - Mantenha changelog atualizado

4. **Validação**
   - Use patterns para formatos específicos
   - Defina ranges para números
   - Use enums para valores fixos

### ❌ Evitar

1. **Mudanças Bruscas**
   - Não remova campos sem deprecação
   - Não mude tipos de dados drasticamente
   - Não altere campos obrigatórios sem migração

2. **Schemas Complexos Demais**
   - Evite aninhamento excessivo (>5 níveis)
   - Não crie arrays de arrays complexos
   - Mantenha schemas legíveis

---

## 🔍 10. Exemplo Completo: Evoluindo um Contrato

### Versão 1.0.0 - Básica
```json
{
  "customer_id": "string",
  "name": "string",
  "email": "string"
}
```

### Versão 1.1.0 - Adicionando Telefone
```json
{
  "customer_id": "string",
  "name": "string", 
  "email": "string",
  "phone": "string"  // ← NOVO CAMPO OPCIONAL
}
```

### Versão 2.0.0 - Reestruturação Completa
```json
{
  "customer_id": "string",
  "personal_info": {     // ← NOVO CAPÍTULO
    "name": "string",
    "email": "string",
    "phone": "string"
  },
  "preferences": {       // ← NOVO CAPÍTULO
    "language": "string",
    "notifications": "boolean"
  },
  "metadata": {          // ← NOVO CAPÍTULO
    "created_at": "date-time",
    "updated_at": "date-time"
  }
}
```

---

## 🎉 Conclusão

O TBR GDP Core V5.0 oferece **flexibilidade total** para definir e evoluir layouts de contratos através de JSON Schema. Você pode:

- ✅ **Adicionar novos capítulos** facilmente
- ✅ **Versionar mudanças** com controle completo
- ✅ **Validar schemas** automaticamente
- ✅ **Manter compatibilidade** entre versões
- ✅ **Auditar todas as mudanças**
- ✅ **Documentar automaticamente**

**O sistema foi projetado para crescer com suas necessidades!** 🚀

