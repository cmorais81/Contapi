"""
Controller principal para Data Contracts
"""

from typing import List
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession

from governance_api.database.connection import get_db_session
from governance_api.database.models.auth_models import User
from governance_api.api.dependencies.dev_auth import get_current_active_user_dev
from governance_api.application.dtos.contracts import (
    CreateContractRequest, UpdateContractRequest, ContractResponse,
    ContractSearchRequest, ContractListResponse
)
from governance_api.application.use_cases.contracts import (
    CreateContractUseCase, GetContractUseCase, UpdateContractUseCase,
    DeleteContractUseCase, ListContractsUseCase
)

router = APIRouter(prefix="/contracts", tags=["Data Contracts"])


@router.post("/", response_model=ContractResponse, status_code=201)
async def create_contract(
    request: CreateContractRequest,
    db: AsyncSession = Depends(get_db_session),
    current_user: User = Depends(get_current_active_user_dev)
):
    """
    Criar novo Data Contract
    
    Cria um novo contrato de dados seguindo o padrão Open Data Contract Standard (ODCS).
    
    **Parâmetros:**
    - **name**: Nome único do contrato (ex: "customer_data_v2")
    - **description**: Descrição detalhada do propósito do contrato
    - **contract_type**: Tipo do contrato (data_product, data_service, data_api)
    - **domain**: Domínio de negócio (customer_management, sales, finance)
    - **owner**: Email do proprietário responsável pelo contrato
    - **steward**: Email do steward responsável pela qualidade dos dados
    - **data_location**: Localização física dos dados (S3, HDFS, etc.)
    - **schema_definition**: Schema JSON dos dados
    - **quality_requirements**: Requisitos de qualidade (completeness, accuracy, etc.)
    - **sla_definition**: Definições de SLA (availability, response_time, etc.)
    
    **Exemplo de uso:**
    ```json
    {
        "name": "customer_data_v2",
        "description": "Dados de clientes para sistema CRM",
        "contract_type": "data_product",
        "domain": "customer_management",
        "owner": "carlos.morais@tbr.com.br",
        "steward": "ana.silva@tbr.com.br",
        "data_location": "s3://tbr-data/customers/",
        "schema_definition": {
            "type": "object",
            "properties": {
                "customer_id": {"type": "string", "format": "uuid"},
                "full_name": {"type": "string", "maxLength": 100},
                "email": {"type": "string", "format": "email"}
            }
        },
        "quality_requirements": {
            "completeness": 95,
            "accuracy": 98
        },
        "sla_definition": {
            "availability": "99.9%",
            "response_time": "< 500ms"
        }
    }
    ```
    
    **Retorna:**
    - Contrato criado com ID único e timestamps de auditoria
    """
    
    use_case = CreateContractUseCase()
    result = await use_case.execute(request, db, current_user.username)
    
    return result


@router.get("/", response_model=ContractListResponse)
async def list_contracts(
    name: str = Query(None, description="Filtrar por nome"),
    domain: str = Query(None, description="Filtrar por domínio"),
    owner: str = Query(None, description="Filtrar por proprietário"),
    status: str = Query(None, description="Filtrar por status"),
    contract_type: str = Query(None, description="Filtrar por tipo"),
    limit: int = Query(50, description="Limite de resultados"),
    offset: int = Query(0, description="Offset para paginação"),
    db: AsyncSession = Depends(get_db_session),
    current_user: User = Depends(get_current_active_user_dev)
):
    """
    Listar Data Contracts com filtros avançados
    