#!/usr/bin/env python3
"""
TBR GDP Core V5.0 - Exemplo Prático: Adicionando Capítulos ao Contrato

Este script demonstra como adicionar novos "capítulos" ou seções 
ao schema de um Data Contract usando a API do TBR GDP Core.

Autor: Carlos Morais
Data: Julho 2025
"""

import requests
import json
from datetime import datetime
from typing import Dict, Any


class ContractLayoutManager:
    """Gerenciador de layouts de contratos"""
    
    def __init__(self, base_url: str = "http://localhost:8000"):
        self.base_url = base_url
        self.headers = {
            "Content-Type": "application/json",
            "Accept": "application/json"
        }
    
    def get_contract(self, contract_id: int) -> Dict[str, Any]:
        """Buscar contrato atual"""
        response = requests.get(
            f"{self.base_url}/api/v1/contracts/{contract_id}",
            headers=self.headers
        )
        response.raise_for_status()
        return response.json()
    
    def update_contract_schema(self, contract_id: int, new_schema: Dict[str, Any]) -> Dict[str, Any]:
        """Atualizar schema do contrato"""
        payload = {
            "schema_definition": new_schema
        }
        
        response = requests.put(
            f"{self.base_url}/api/v1/contracts/{contract_id}",
            headers=self.headers,
            json=payload
        )
        response.raise_for_status()
        return response.json()
    
    def create_new_version(self, contract_id: int, version: str, changes: str, 
                          new_schema: Dict[str, Any]) -> Dict[str, Any]:
        """Criar nova versão com schema atualizado"""
        payload = {
            "version": version,
            "changes": changes,
            "change_type": "minor",
            "schema_definition": new_schema,
            "backward_compatible": True,
            "migration_notes": f"Adicionados novos capítulos em {datetime.now().strftime('%Y-%m-%d')}"
        }
        
        response = requests.post(
            f"{self.base_url}/api/v1/contracts/{contract_id}/versions",
            headers=self.headers,
            json=payload
        )
        response.raise_for_status()
        return response.json()


def create_enhanced_customer_schema() -> Dict[str, Any]:
    """Criar schema de cliente com novos capítulos"""
    return {
        "type": "object",
        "title": "Enhanced Customer Data Contract",
        "description": "Contrato completo de dados de clientes com múltiplos capítulos",
        "properties": {
            # CAPÍTULO 1: Identificação Básica
            "identification": {
                "type": "object",
                "title": "Capítulo 1: Identificação",
                "description": "Dados básicos de identificação do cliente",
                "properties": {
                    "customer_id": {
                        "type": "string",
                        "format": "uuid",
                        "description": "Identificador único do cliente"
                    },
                    "customer_code": {
                        "type": "string",
                        "pattern": "^CUS[0-9]{6}$",
                        "description": "Código interno do cliente (ex: CUS123456)"
                    },
                    "registration_date": {
                        "type": "string",
                        "format": "date-time",
                        "description": "Data de cadastro do cliente"
                    },
                    "status": {
                        "type": "string",
                        "enum": ["active", "inactive", "suspended", "pending"],
                        "description": "Status atual do cliente"
                    }
                },
                "required": ["customer_id", "customer_code", "registration_date"]
            },
            
            # CAPÍTULO 2: Informações Pessoais
            "personal_info": {
                "type": "object",
                "title": "Capítulo 2: Informações Pessoais",
                "description": "Dados pessoais completos do cliente",
                "properties": {
                    "full_name": {
                        "type": "string",
                        "maxLength": 100,
                        "description": "Nome completo do cliente"
                    },
                    "document": {
                        "type": "object",
                        "properties": {
                            "cpf": {
                                "type": "string",
                                "pattern": "^\\d{3}\\.\\d{3}\\.\\d{3}-\\d{2}$",
                                "description": "CPF no formato XXX.XXX.XXX-XX"
                            },
                            "rg": {
                                "type": "string",
                                "description": "Registro Geral"
                            },
                            "passport": {
                                "type": "string",
                                "description": "Número do passaporte (se aplicável)"
                            }
                        }
                    },
                    "birth_date": {
                        "type": "string",
                        "format": "date",
                        "description": "Data de nascimento"
                    },
                    "gender": {
                        "type": "string",
                        "enum": ["M", "F", "O", "N"],
                        "description": "Gênero (M=Masculino, F=Feminino, O=Outro, N=Não informar)"
                    },
                    "marital_status": {
                        "type": "string",
                        "enum": ["single", "married", "divorced", "widowed"],
                        "description": "Estado civil"
                    }
                },
                "required": ["full_name", "document"]
            },
            
            # CAPÍTULO 3: Contato
            "contact_info": {
                "type": "object",
                "title": "Capítulo 3: Informações de Contato",
                "description": "Dados de contato e comunicação",
                "properties": {
                    "primary_email": {
                        "type": "string",
                        "format": "email",
                        "description": "Email principal"
                    },
                    "secondary_email": {
                        "type": "string",
                        "format": "email",
                        "description": "Email secundário"
                    },
                    "phones": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "type": {
                                    "type": "string",
                                    "enum": ["mobile", "home", "work", "whatsapp"]
                                },
                                "number": {
                                    "type": "string",
                                    "pattern": "^\\+55\\d{10,11}$"
                                },
                                "is_primary": {"type": "boolean"}
                            }
                        },
                        "description": "Lista de telefones"
                    },
                    "preferred_contact_method": {
                        "type": "string",
                        "enum": ["email", "phone", "sms", "whatsapp"],
                        "description": "Método de contato preferido"
                    }
                },
                "required": ["primary_email"]
            },
            
            # CAPÍTULO 4: Endereço
            "address_info": {
                "type": "object",
                "title": "Capítulo 4: Informações de Endereço",
                "description": "Endereços do cliente",
                "properties": {
                    "primary_address": {
                        "type": "object",
                        "properties": {
                            "street": {"type": "string", "description": "Logradouro"},
                            "number": {"type": "string", "description": "Número"},
                            "complement": {"type": "string", "description": "Complemento"},
                            "neighborhood": {"type": "string", "description": "Bairro"},
                            "city": {"type": "string", "description": "Cidade"},
                            "state": {"type": "string", "maxLength": 2, "description": "Estado (UF)"},
                            "zip_code": {
                                "type": "string",
                                "pattern": "^\\d{5}-?\\d{3}$",
                                "description": "CEP"
                            },
                            "country": {"type": "string", "default": "BR"}
                        },
                        "required": ["street", "city", "state", "zip_code"]
                    },
                    "billing_address": {
                        "type": "object",
                        "description": "Endereço de cobrança (se diferente do principal)",
                        "properties": {
                            "same_as_primary": {"type": "boolean", "default": True},
                            "address": {
                                "type": "object",
                                "description": "Endereço completo (se same_as_primary = false)"
                            }
                        }
                    }
                }
            },
            
            # CAPÍTULO 5: Informações Financeiras
            "financial_info": {
                "type": "object",
                "title": "Capítulo 5: Informações Financeiras",
                "description": "Dados financeiros e de crédito",
                "properties": {
                    "income": {
                        "type": "object",
                        "properties": {
                            "monthly_income": {
                                "type": "number",
                                "minimum": 0,
                                "description": "Renda mensal declarada"
                            },
                            "income_source": {
                                "type": "string",
                                "enum": ["employment", "business", "investments", "retirement", "other"],
                                "description": "Fonte de renda"
                            },
                            "employer": {"type": "string", "description": "Empregador"}
                        }
                    },
                    "credit_info": {
                        "type": "object",
                        "properties": {
                            "credit_score": {
                                "type": "integer",
                                "minimum": 0,
                                "maximum": 1000,
                                "description": "Score de crédito"
                            },
                            "credit_limit": {
                                "type": "number",
                                "minimum": 0,
                                "description": "Limite de crédito aprovado"
                            },
                            "risk_category": {
                                "type": "string",
                                "enum": ["low", "medium", "high"],
                                "description": "Categoria de risco"
                            }
                        }
                    }
                }
            },
            
            # CAPÍTULO 6: Histórico de Relacionamento
            "relationship_history": {
                "type": "object",
                "title": "Capítulo 6: Histórico de Relacionamento",
                "description": "Histórico de interações e transações",
                "properties": {
                    "customer_since": {
                        "type": "string",
                        "format": "date",
                        "description": "Cliente desde"
                    },
                    "total_transactions": {
                        "type": "integer",
                        "minimum": 0,
                        "description": "Total de transações realizadas"
                    },
                    "total_value": {
                        "type": "number",
                        "minimum": 0,
                        "description": "Valor total transacionado"
                    },
                    "last_transaction_date": {
                        "type": "string",
                        "format": "date-time",
                        "description": "Data da última transação"
                    },
                    "loyalty_program": {
                        "type": "object",
                        "properties": {
                            "member": {"type": "boolean", "description": "Membro do programa"},
                            "tier": {
                                "type": "string",
                                "enum": ["bronze", "silver", "gold", "platinum"],
                                "description": "Nível no programa"
                            },
                            "points": {"type": "integer", "minimum": 0, "description": "Pontos acumulados"}
                        }
                    }
                }
            },
            
            # CAPÍTULO 7: Preferências e Consentimentos
            "preferences": {
                "type": "object",
                "title": "Capítulo 7: Preferências e Consentimentos",
                "description": "Preferências do cliente e consentimentos LGPD",
                "properties": {
                    "communication_preferences": {
                        "type": "object",
                        "properties": {
                            "marketing_emails": {"type": "boolean", "default": False},
                            "promotional_sms": {"type": "boolean", "default": False},
                            "newsletter": {"type": "boolean", "default": False},
                            "product_updates": {"type": "boolean", "default": True}
                        }
                    },
                    "privacy_settings": {
                        "type": "object",
                        "properties": {
                            "data_sharing_consent": {"type": "boolean", "description": "Consentimento compartilhamento"},
                            "analytics_consent": {"type": "boolean", "description": "Consentimento analytics"},
                            "third_party_consent": {"type": "boolean", "description": "Consentimento terceiros"}
                        }
                    },
                    "language": {"type": "string", "default": "pt-BR"},
                    "timezone": {"type": "string", "default": "America/Sao_Paulo"}
                }
            },
            
            # CAPÍTULO 8: Metadados do Sistema
            "system_metadata": {
                "type": "object",
                "title": "Capítulo 8: Metadados do Sistema",
                "description": "Informações técnicas e de auditoria",
                "properties": {
                    "created_at": {
                        "type": "string",
                        "format": "date-time",
                        "description": "Data de criação do registro"
                    },
                    "updated_at": {
                        "type": "string",
                        "format": "date-time",
                        "description": "Data da última atualização"
                    },
                    "created_by": {"type": "string", "description": "Usuário que criou"},
                    "updated_by": {"type": "string", "description": "Usuário que atualizou"},
                    "source_system": {"type": "string", "description": "Sistema de origem"},
                    "data_quality_score": {
                        "type": "number",
                        "minimum": 0,
                        "maximum": 100,
                        "description": "Score de qualidade dos dados"
                    },
                    "last_validation": {
                        "type": "string",
                        "format": "date-time",
                        "description": "Última validação dos dados"
                    }
                },
                "required": ["created_at", "updated_at"]
            }
        },
        "required": ["identification", "personal_info", "contact_info", "system_metadata"]
    }


def main():
    """Exemplo prático de uso"""
    print("🚀 TBR GDP Core V5.0 - Adicionando Capítulos ao Contrato")
    print("=" * 60)
    
    # Inicializar gerenciador
    manager = ContractLayoutManager()
    
    try:
        # 1. Buscar contrato existente
        print("📋 1. Buscando contrato atual...")
        contract_id = 1  # ID do contrato a ser atualizado
        current_contract = manager.get_contract(contract_id)
        print(f"   ✅ Contrato encontrado: {current_contract['name']}")
        print(f"   📊 Versão atual: {current_contract['version']}")
        
        # 2. Criar novo schema com capítulos
        print("\n🎨 2. Criando schema com novos capítulos...")
        enhanced_schema = create_enhanced_customer_schema()
        print(f"   ✅ Schema criado com {len(enhanced_schema['properties'])} capítulos")
        
        # Listar capítulos
        for i, (key, value) in enumerate(enhanced_schema['properties'].items(), 1):
            title = value.get('title', key)
            print(f"   📖 Capítulo {i}: {title}")
        
        # 3. Criar nova versão
        print("\n📝 3. Criando nova versão do contrato...")
        new_version = "2.0.0"
        changes = "Adicionados 8 capítulos completos: identificação, dados pessoais, contato, endereço, financeiro, histórico, preferências e metadados"
        
        result = manager.create_new_version(
            contract_id=contract_id,
            version=new_version,
            changes=changes,
            new_schema=enhanced_schema
        )
        
        print(f"   ✅ Nova versão criada: {result['version']}")
        print(f"   📅 Data: {result['created_at']}")
        
        # 4. Mostrar resumo
        print("\n📊 4. Resumo da atualização:")
        print(f"   🆔 Contrato ID: {contract_id}")
        print(f"   📈 Versão: {current_contract['version']} → {new_version}")
        print(f"   📋 Capítulos adicionados: 8")
        print(f"   🔄 Compatibilidade: Mantida")
        
        # 5. Exemplo de dados que seguem o novo schema
        print("\n💡 5. Exemplo de dados no novo formato:")
        example_data = {
            "identification": {
                "customer_id": "550e8400-e29b-41d4-a716-446655440000",
                "customer_code": "CUS123456",
                "registration_date": "2025-07-08T10:00:00Z",
                "status": "active"
            },
            "personal_info": {
                "full_name": "Maria Silva Santos",
                "document": {
                    "cpf": "123.456.789-00"
                },
                "birth_date": "1985-03-15"
            },
            "contact_info": {
                "primary_email": "maria.silva@email.com",
                "phones": [
                    {
                        "type": "mobile",
                        "number": "+5511987654321",
                        "is_primary": True
                    }
                ]
            },
            "system_metadata": {
                "created_at": "2025-07-08T10:00:00Z",
                "updated_at": "2025-07-08T10:00:00Z",
                "created_by": "system",
                "data_quality_score": 95.5
            }
        }
        
        print(json.dumps(example_data, indent=2, ensure_ascii=False))
        
        print("\n🎉 Processo concluído com sucesso!")
        print("   ✅ Contrato atualizado com novos capítulos")
        print("   ✅ Versionamento mantido")
        print("   ✅ Compatibilidade preservada")
        
    except requests.exceptions.RequestException as e:
        print(f"❌ Erro na API: {e}")
    except Exception as e:
        print(f"❌ Erro: {e}")


if __name__ == "__main__":
    main()

