# COBOL Analyzer v3.1.0 - Documentação Completa

## Visão Geral

O COBOL Analyzer é uma ferramenta profissional para análise automatizada e geração de documentação de sistemas COBOL legados. Utiliza inteligência artificial avançada para compreender, analisar e documentar código COBOL de forma abrangente e precisa.

## Características Principais

### Análise Inteligente
- Processamento automatizado de código COBOL
- Análise de regras de negócio
- Identificação de padrões e estruturas
- Extração de fórmulas e cálculos

### Documentação Profissional
- Geração automática de documentação técnica
- Múltiplos formatos de saída (Markdown, HTML, PDF, JSON)
- Relatórios consolidados de sistemas
- Análise comparativa entre modelos

### API Programática
- Interface Python completa
- Integração com sistemas existentes
- Processamento em lote
- Configuração flexível

### Base de Conhecimento
- Sistema RAG especializado em COBOL
- Aprendizado contínuo
- Contexto enriquecido
- Busca semântica

## Instalação

### Requisitos do Sistema
- Python 3.8 ou superior
- Sistema operacional: Windows, Linux, macOS
- Memória RAM: 512MB mínimo, 2GB recomendado
- Espaço em disco: 100MB para instalação completa

### Instalação Rápida

```bash
# Extrair o pacote
tar -xzf cobol-analyzer-v3.1.0-clean.tar.gz
cd cobol_analyzer_clean/

# Instalar com API programática
python install_api.py

# Verificar instalação
cobol-to-docs --help
python -c "import cobol_to_docs; print('API instalada')"
```

### Instalação Manual

```bash
# Instalar dependências
pip install -r requirements.txt

# Instalar pacote
python setup_api.py install

# Configurar entry points
python fix_install.py
```

## Uso Básico

### 1. Inicialização do Ambiente

O primeiro passo é inicializar o ambiente, que cria a estrutura de diretórios e copia os arquivos de configuração:

```bash
# Via linha de comando
cobol-to-docs --init

# Via API Python
python -c "import cobol_to_docs; cobol_to_docs.init()"
```

Isso cria a seguinte estrutura:
```
projeto/
├── config/                 # Configurações (8 arquivos)
├── data/                  # Base de conhecimento (10+ arquivos)
├── logs/                  # Logs do sistema
├── examples/              # Exemplos prontos
└── .cobol_analyzer_init   # Marcador de inicialização
```

### 2. Análise via Linha de Comando

```bash
# Análise básica
cobol-to-docs --fontes programas.txt

# Análise com copybooks
cobol-to-docs --fontes programas.txt --books copybooks.txt

# Análise consolidada (sistema completo)
cobol-to-docs --fontes programas.txt --consolidado

# Análise especializada
cobol-to-docs --fontes programas.txt --analise-especialista

# Múltiplos modelos
cobol-to-docs --fontes programas.txt --models enhanced_mock
```

### 3. Uso Programático

```python
import cobol_to_docs

# Inicializar ambiente
cobol_to_docs.init()

# Analisar programa individual
codigo_cobol = """
IDENTIFICATION DIVISION.
PROGRAM-ID. CALC-JUROS.
DATA DIVISION.
WORKING-STORAGE SECTION.
01 WS-PRINCIPAL PIC 9(7)V99.
01 WS-TAXA      PIC 9V999.
01 WS-JUROS     PIC 9(7)V99.
PROCEDURE DIVISION.
    COMPUTE WS-JUROS = WS-PRINCIPAL * WS-TAXA.
    STOP RUN.
"""

resultado = cobol_to_docs.analyze_program(codigo_cobol, "CALC-JUROS.CBL")

if resultado.success:
    print(f"Análise concluída: {len(resultado.documentation)} caracteres")
    print(resultado.documentation)
else:
    print(f"Erro: {resultado.error_message}")
```

## API Programática Detalhada

### Funções Principais

#### `init(config_dir, data_dir, logs_dir, force=False)`
Inicializa o ambiente COBOL Analyzer.

**Parâmetros:**
- `config_dir`: Diretório de configurações (padrão: './config')
- `data_dir`: Diretório de dados (padrão: './data')
- `logs_dir`: Diretório de logs (padrão: './logs')
- `force`: Forçar reinicialização (padrão: False)

**Retorno:** `bool` - True se inicializado com sucesso

#### `analyze_program(program_content, program_name, analysis_type, model, output_format)`
Analisa um programa COBOL a partir do código fonte.

**Parâmetros:**
- `program_content`: Código COBOL como string
- `program_name`: Nome do programa (padrão: "programa.cbl")
- `analysis_type`: Tipo de análise ('basic', 'detailed', 'comprehensive')
- `model`: Modelo de IA a usar (padrão: configuração atual)
- `output_format`: Formato de saída ('markdown', 'html', 'json')

**Retorno:** `AnalysisResult`

#### `analyze_file(file_path, analysis_type, model, output_format)`
Analisa um arquivo COBOL.

**Parâmetros:**
- `file_path`: Caminho para o arquivo COBOL
- `analysis_type`: Tipo de análise
- `model`: Modelo de IA a usar
- `output_format`: Formato de saída

**Retorno:** `AnalysisResult`

#### `analyze_batch(file_paths, analysis_type, model, output_format, parallel=True)`
Analisa múltiplos arquivos COBOL.

**Parâmetros:**
- `file_paths`: Lista de caminhos para arquivos COBOL
- `analysis_type`: Tipo de análise
- `model`: Modelo de IA a usar
- `output_format`: Formato de saída
- `parallel`: Executar em paralelo (quando disponível)

**Retorno:** `BatchResult`

#### `analyze_system(fontes_file, books_file, analysis_type, model, consolidado=True)`
Analisa um sistema completo COBOL.

**Parâmetros:**
- `fontes_file`: Arquivo com lista de programas
- `books_file`: Arquivo com lista de copybooks (opcional)
- `analysis_type`: Tipo de análise
- `model`: Modelo de IA a usar
- `consolidado`: Gerar análise consolidada

**Retorno:** `BatchResult`

### Funções de Configuração

#### `configure(config_dict)`
Configura o COBOL Analyzer.

```python
cobol_to_docs.configure({
    'model': 'enhanced_mock',
    'analysis_type': 'detailed',
    'output_format': 'markdown',
    'include_business_rules': True
})
```

#### `set_model(model_name)`
Define o modelo de IA a usar.

```python
cobol_to_docs.set_model('enhanced_mock')
```

#### `get_config()`
Obtém a configuração atual.

```python
config = cobol_to_docs.get_config()
print(f"Modelo atual: {config['model']}")
```

### Funções Utilitárias

#### `status()`
Verifica o status do sistema.

```python
status = cobol_to_docs.status()
print(f"Inicializado: {status['initialized']}")
print(f"Comando disponível: {status['command_available']}")
```

#### `show_paths()`
Mostra os caminhos configurados.

```python
paths = cobol_to_docs.show_paths()
print(f"Config: {paths['config_dir']}")
print(f"Data: {paths['data_dir']}")
```

#### `list_models()`
Lista os modelos disponíveis.

```python
models = cobol_to_docs.list_models()
print("Modelos disponíveis:", models)
```

### Classes Avançadas

#### `COBOLAnalyzer`
Classe principal para análise com configuração personalizada.

```python
analyzer = cobol_to_docs.COBOLAnalyzer({
    'model': 'enhanced_mock',
    'analysis_type': 'comprehensive',
    'output_format': 'html'
})

# Configurar analisador
analyzer.configure(temperature=0.1, max_tokens=8000)

# Analisar programa
resultado = analyzer.analyze_program(codigo_cobol, "PROGRAMA.CBL")

# Analisar arquivo
resultado = analyzer.analyze_file("PROGRAMA.CBL")
```

#### `COBOLProject`
Classe para gerenciar projetos COBOL.

```python
projeto = cobol_to_docs.COBOLProject("SistemaBancario", {
    'analysis_type': 'detailed',
    'model': 'enhanced_mock'
})

# Adicionar programas
projeto.add_program("CLIENTE.CBL")
projeto.add_program("CONTA.CBL")
projeto.add_program("TRANSACAO.CBL")

# Adicionar copybooks
projeto.add_copybook("CLIENTE.CPY")
projeto.add_copybook("CONTA.CPY")

# Analisar projeto completo
resultado = projeto.analyze_all()

print(f"Projeto {projeto.name}:")
print(f"Programas: {resultado.total_programs}")
print(f"Sucessos: {resultado.successful}")
print(f"Tempo: {resultado.total_time:.2f}s")
```

#### `COBOLBatch`
Classe para análise em lote.

```python
batch = cobol_to_docs.COBOLBatch({
    'analysis_type': 'basic',
    'model': 'enhanced_mock'
})

# Adicionar arquivos
batch.add_file("PROGRAMA1.CBL")
batch.add_files(["PROGRAMA2.CBL", "PROGRAMA3.CBL"])

# Executar análise
resultado = batch.execute()

print(f"Lote executado:")
print(f"Total: {resultado.total_programs}")
print(f"Sucessos: {resultado.successful}")
print(f"Falhas: {resultado.failed}")

# Resultados individuais
for res in resultado.results:
    status = "OK" if res.success else "ERRO"
    print(f"  {status} {res.program_name} ({res.execution_time:.2f}s)")
```

## Estruturas de Dados

### `AnalysisResult`
Resultado de uma análise individual.

```python
@dataclass
class AnalysisResult:
    program_name: str           # Nome do programa
    success: bool              # Status da análise
    documentation: str         # Documentação gerada
    metadata: Dict[str, Any]   # Metadados da análise
    execution_time: float      # Tempo de execução em segundos
    error_message: str         # Mensagem de erro (se houver)
```

**Exemplo de uso:**
```python
resultado = cobol_to_docs.analyze_program(codigo)

if resultado.success:
    print(f"Programa: {resultado.program_name}")
    print(f"Tempo: {resultado.execution_time:.2f}s")
    print(f"Documentação: {len(resultado.documentation)} caracteres")
    print(f"Modelo usado: {resultado.metadata.get('model')}")
else:
    print(f"Erro: {resultado.error_message}")
```

### `BatchResult`
Resultado de análise em lote.

```python
@dataclass
class BatchResult:
    total_programs: int        # Total de programas processados
    successful: int           # Número de sucessos
    failed: int              # Número de falhas
    results: List[AnalysisResult]  # Resultados individuais
    total_time: float        # Tempo total de execução
```

**Exemplo de uso:**
```python
resultado = cobol_to_docs.analyze_batch(lista_arquivos)

print(f"Processamento em lote:")
print(f"Total: {resultado.total_programs}")
print(f"Sucessos: {resultado.successful}")
print(f"Falhas: {resultado.failed}")
print(f"Taxa de sucesso: {resultado.successful/resultado.total_programs*100:.1f}%")
print(f"Tempo médio: {resultado.total_time/resultado.total_programs:.2f}s por programa")

# Analisar falhas
falhas = [r for r in resultado.results if not r.success]
for falha in falhas:
    print(f"ERRO em {falha.program_name}: {falha.error_message}")
```

## Configuração Avançada

### Modelos Disponíveis

- **enhanced_mock**: Modelo simulado para testes e desenvolvimento
- **gpt-4**: OpenAI GPT-4 (requer chave API)
- **claude**: Anthropic Claude (requer chave API)
- **gemini**: Google Gemini (requer chave API)

### Tipos de Análise

- **basic**: Análise básica com informações essenciais
- **detailed**: Análise detalhada (padrão) com documentação completa
- **comprehensive**: Análise abrangente com regras de negócio
- **business_rules**: Foco específico em regras de negócio
- **modernization**: Análise para modernização e migração

### Formatos de Saída

- **markdown**: Markdown (padrão) - ideal para documentação
- **html**: HTML - ideal para visualização web
- **json**: JSON estruturado - ideal para integração
- **pdf**: PDF - ideal para relatórios formais
- **docx**: Microsoft Word - ideal para documentação corporativa

### Arquivo de Configuração

O arquivo `config/config.yaml` contém as configurações principais:

```yaml
# Configuração de modelos
models:
  default: "enhanced_mock"
  fallback: ["gpt-4", "claude"]
  temperature: 0.1
  max_tokens: 8000

# Configuração de análise
analysis:
  type: "detailed"
  include_business_rules: true
  include_comments: true
  extract_formulas: true

# Configuração de saída
output:
  format: "markdown"
  directory: "./output"
  generate_html: false
  generate_pdf: false

# Sistema RAG
rag:
  enabled: true
  knowledge_base_path: "data/cobol_knowledge_base.json"
  max_context_items: 10
  similarity_threshold: 0.7
  auto_learning: true

# Logging
logging:
  level: "INFO"
  file: "logs/cobol_analyzer.log"
  max_size: "10MB"
  backup_count: 5
```

## Exemplos Práticos

### 1. Análise de Sistema Bancário

```python
import cobol_to_docs

# Configurar ambiente
cobol_to_docs.init()
cobol_to_docs.configure({
    'model': 'enhanced_mock',
    'analysis_type': 'comprehensive',
    'output_format': 'html'
})

# Criar projeto
projeto = cobol_to_docs.COBOLProject("SistemaBancario")

# Adicionar módulos
modulos = {
    'clientes': ['CLIENTE01.CBL', 'CLIENTE02.CBL'],
    'contas': ['CONTA001.CBL', 'CONTA002.CBL'],
    'transacoes': ['TRANS001.CBL', 'TRANS002.CBL'],
    'relatorios': ['RELAT01.CBL', 'RELAT02.CBL']
}

for modulo, programas in modulos.items():
    for programa in programas:
        projeto.add_program(programa)

# Analisar sistema completo
resultado = projeto.analyze_all()

# Gerar relatório
print(f"Sistema Bancário - Análise Completa")
print(f"Total de programas: {resultado.total_programs}")
print(f"Sucessos: {resultado.successful}")
print(f"Falhas: {resultado.failed}")
print(f"Tempo total: {resultado.total_time:.2f}s")

# Relatório por módulo
for modulo, programas in modulos.items():
    modulo_results = [r for r in resultado.results if r.program_name in programas]
    sucessos = sum(1 for r in modulo_results if r.success)
    print(f"Módulo {modulo}: {sucessos}/{len(programas)} sucessos")
```

### 2. Integração com Pipeline CI/CD

```python
import cobol_to_docs
import json
from datetime import datetime

def pipeline_cobol_analysis(source_dir, output_dir):
    """Função para integração com pipeline CI/CD"""
    
    # Inicializar
    cobol_to_docs.init()
    
    # Encontrar arquivos COBOL
    import glob
    cobol_files = glob.glob(f"{source_dir}/**/*.CBL", recursive=True)
    cobol_files.extend(glob.glob(f"{source_dir}/**/*.cbl", recursive=True))
    
    if not cobol_files:
        return {"error": "Nenhum arquivo COBOL encontrado"}
    
    # Analisar em lote
    resultado = cobol_to_docs.analyze_batch(
        file_paths=cobol_files,
        analysis_type='detailed'
    )
    
    # Gerar relatório para CI/CD
    relatorio = {
        'timestamp': datetime.now().isoformat(),
        'source_directory': source_dir,
        'total_files': resultado.total_programs,
        'successful_analyses': resultado.successful,
        'failed_analyses': resultado.failed,
        'success_rate': resultado.successful / resultado.total_programs * 100,
        'total_time': resultado.total_time,
        'average_time_per_file': resultado.total_time / resultado.total_programs,
        'files': []
    }
    
    # Detalhes por arquivo
    for res in resultado.results:
        relatorio['files'].append({
            'name': res.program_name,
            'success': res.success,
            'execution_time': res.execution_time,
            'documentation_size': len(res.documentation),
            'error': res.error_message if not res.success else None
        })
    
    # Salvar relatório
    with open(f"{output_dir}/cobol_analysis_report.json", 'w') as f:
        json.dump(relatorio, f, indent=2)
    
    # Retornar status para CI/CD
    return {
        'success': resultado.failed == 0,
        'total': resultado.total_programs,
        'successful': resultado.successful,
        'failed': resultado.failed,
        'report_file': f"{output_dir}/cobol_analysis_report.json"
    }

# Usar no pipeline
result = pipeline_cobol_analysis('./src/cobol', './reports')
if result['success']:
    print("Pipeline: Análise COBOL bem-sucedida")
else:
    print(f"Pipeline: {result['failed']} arquivos falharam")
    exit(1)
```

### 3. Análise Comparativa de Modelos

```python
import cobol_to_docs

def comparar_modelos(codigo_cobol, modelos=['enhanced_mock', 'gpt-4']):
    """Compara análise entre diferentes modelos"""
    
    cobol_to_docs.init()
    
    resultados = {}
    
    for modelo in modelos:
        print(f"Analisando com modelo: {modelo}")
        
        try:
            resultado = cobol_to_docs.analyze_program(
                program_content=codigo_cobol,
                program_name="TESTE_COMPARACAO.CBL",
                model=modelo
            )
            
            resultados[modelo] = {
                'success': resultado.success,
                'execution_time': resultado.execution_time,
                'documentation_length': len(resultado.documentation),
                'documentation': resultado.documentation,
                'error': resultado.error_message
            }
            
        except Exception as e:
            resultados[modelo] = {
                'success': False,
                'error': str(e)
            }
    
    # Análise comparativa
    print("\nComparação de Modelos:")
    print("-" * 50)
    
    for modelo, resultado in resultados.items():
        if resultado['success']:
            print(f"{modelo}:")
            print(f"  Tempo: {resultado['execution_time']:.2f}s")
            print(f"  Documentação: {resultado['documentation_length']} caracteres")
        else:
            print(f"{modelo}: ERRO - {resultado['error']}")
    
    return resultados

# Exemplo de uso
codigo_teste = """
IDENTIFICATION DIVISION.
PROGRAM-ID. CALC-DESCONTO.
DATA DIVISION.
WORKING-STORAGE SECTION.
01 WS-VALOR-ORIGINAL PIC 9(7)V99.
01 WS-PERCENTUAL     PIC 9V99.
01 WS-DESCONTO       PIC 9(7)V99.
01 WS-VALOR-FINAL    PIC 9(7)V99.
PROCEDURE DIVISION.
    MOVE 1000.00 TO WS-VALOR-ORIGINAL.
    MOVE 0.15 TO WS-PERCENTUAL.
    COMPUTE WS-DESCONTO = WS-VALOR-ORIGINAL * WS-PERCENTUAL.
    COMPUTE WS-VALOR-FINAL = WS-VALOR-ORIGINAL - WS-DESCONTO.
    DISPLAY 'VALOR ORIGINAL: ' WS-VALOR-ORIGINAL.
    DISPLAY 'DESCONTO: ' WS-DESCONTO.
    DISPLAY 'VALOR FINAL: ' WS-VALOR-FINAL.
    STOP RUN.
"""

comparacao = comparar_modelos(codigo_teste)
```

### 4. Monitoramento e Relatórios

```python
import cobol_to_docs
import time
from datetime import datetime

class COBOLMonitor:
    """Classe para monitoramento de análises COBOL"""
    
    def __init__(self):
        self.historico = []
        cobol_to_docs.init()
    
    def analisar_com_monitoramento(self, arquivo_ou_codigo, nome="programa.cbl"):
        """Analisa com monitoramento detalhado"""
        
        inicio = time.time()
        timestamp = datetime.now()
        
        try:
            if arquivo_ou_codigo.endswith('.CBL') or arquivo_ou_codigo.endswith('.cbl'):
                resultado = cobol_to_docs.analyze_file(arquivo_ou_codigo)
            else:
                resultado = cobol_to_docs.analyze_program(arquivo_ou_codigo, nome)
            
            fim = time.time()
            
            # Registrar no histórico
            registro = {
                'timestamp': timestamp.isoformat(),
                'programa': nome,
                'sucesso': resultado.success,
                'tempo_execucao': fim - inicio,
                'tamanho_documentacao': len(resultado.documentation),
                'modelo_usado': resultado.metadata.get('model', 'unknown'),
                'erro': resultado.error_message if not resultado.success else None
            }
            
            self.historico.append(registro)
            
            return resultado
            
        except Exception as e:
            fim = time.time()
            
            registro = {
                'timestamp': timestamp.isoformat(),
                'programa': nome,
                'sucesso': False,
                'tempo_execucao': fim - inicio,
                'erro': str(e)
            }
            
            self.historico.append(registro)
            raise
    
    def gerar_relatorio(self):
        """Gera relatório de monitoramento"""
        
        if not self.historico:
            return "Nenhuma análise registrada"
        
        total = len(self.historico)
        sucessos = sum(1 for r in self.historico if r['sucesso'])
        falhas = total - sucessos
        
        tempo_total = sum(r['tempo_execucao'] for r in self.historico)
        tempo_medio = tempo_total / total
        
        relatorio = f"""
Relatório de Monitoramento COBOL Analyzer
==========================================

Período: {self.historico[0]['timestamp']} até {self.historico[-1]['timestamp']}

Estatísticas Gerais:
- Total de análises: {total}
- Sucessos: {sucessos} ({sucessos/total*100:.1f}%)
- Falhas: {falhas} ({falhas/total*100:.1f}%)
- Tempo total: {tempo_total:.2f}s
- Tempo médio: {tempo_medio:.2f}s por análise

Análises por Modelo:
"""
        
        # Estatísticas por modelo
        modelos = {}
        for r in self.historico:
            if r['sucesso']:
                modelo = r.get('modelo_usado', 'unknown')
                if modelo not in modelos:
                    modelos[modelo] = {'count': 0, 'tempo': 0}
                modelos[modelo]['count'] += 1
                modelos[modelo]['tempo'] += r['tempo_execucao']
        
        for modelo, stats in modelos.items():
            tempo_medio_modelo = stats['tempo'] / stats['count']
            relatorio += f"- {modelo}: {stats['count']} análises, {tempo_medio_modelo:.2f}s médio\n"
        
        # Últimas falhas
        falhas_recentes = [r for r in self.historico[-10:] if not r['sucesso']]
        if falhas_recentes:
            relatorio += "\nÚltimas Falhas:\n"
            for falha in falhas_recentes:
                relatorio += f"- {falha['programa']}: {falha['erro']}\n"
        
        return relatorio

# Exemplo de uso
monitor = COBOLMonitor()

# Analisar vários programas
programas = ["CLIENTE.CBL", "CONTA.CBL", "TRANSACAO.CBL"]
for programa in programas:
    try:
        resultado = monitor.analisar_com_monitoramento(programa)
        print(f"Analisado: {programa} - {'OK' if resultado.success else 'ERRO'}")
    except Exception as e:
        print(f"Erro em {programa}: {e}")

# Gerar relatório
print(monitor.gerar_relatorio())
```

## Tratamento de Erros

### Exceções Personalizadas

O COBOL Analyzer define exceções específicas para diferentes tipos de erro:

```python
# Exceções disponíveis
from cobol_to_docs import (
    COBOLAnalyzerError,      # Exceção base
    ConfigurationError,      # Erro de configuração
    AnalysisError           # Erro durante análise
)

# Exemplo de tratamento
try:
    resultado = cobol_to_docs.analyze_program(codigo_invalido)
    
except cobol_to_docs.ConfigurationError as e:
    print(f"Erro de configuração: {e}")
    # Reconfigurar ou usar configuração padrão
    cobol_to_docs.configure({'model': 'enhanced_mock'})
    
except cobol_to_docs.AnalysisError as e:
    print(f"Erro na análise: {e}")
    # Tentar com modelo diferente ou configuração mais simples
    
except cobol_to_docs.COBOLAnalyzerError as e:
    print(f"Erro geral: {e}")
    # Erro genérico do sistema
    
except Exception as e:
    print(f"Erro inesperado: {e}")
    # Erro não relacionado ao COBOL Analyzer
```

### Verificação de Resultados

```python
def analisar_com_verificacao(codigo, nome):
    """Análise com verificação robusta de resultados"""
    
    resultado = cobol_to_docs.analyze_program(codigo, nome)
    
    # Verificar sucesso básico
    if not resultado.success:
        print(f"ERRO: {resultado.error_message}")
        return None
    
    # Verificar qualidade da documentação
    if len(resultado.documentation) < 100:
        print("AVISO: Documentação muito curta")
    
    # Verificar tempo de execução
    if resultado.execution_time > 30:
        print("AVISO: Análise demorou mais que 30 segundos")
    
    # Verificar metadados
    if 'model' not in resultado.metadata:
        print("AVISO: Modelo usado não identificado")
    
    return resultado

# Usar função com verificação
resultado = analisar_com_verificacao(codigo_cobol, "TESTE.CBL")
if resultado:
    print("Análise válida e completa")
```

### Recuperação de Erros

```python
def analisar_com_fallback(codigo, nome, modelos=['enhanced_mock', 'gpt-4']):
    """Análise com fallback automático entre modelos"""
    
    for modelo in modelos:
        try:
            cobol_to_docs.set_model(modelo)
            resultado = cobol_to_docs.analyze_program(codigo, nome)
            
            if resultado.success:
                print(f"Sucesso com modelo: {modelo}")
                return resultado
            else:
                print(f"Falha com {modelo}: {resultado.error_message}")
                
        except Exception as e:
            print(f"Erro com {modelo}: {e}")
            continue
    
    print("Todos os modelos falharam")
    return None

# Usar com fallback
resultado = analisar_com_fallback(codigo_cobol, "TESTE.CBL")
```

## Solução de Problemas

### Problemas Comuns

#### 1. Comando não encontrado
```bash
# Erro: cobol-to-docs: command not found

# Solução 1: Reinstalar
python install_api.py

# Solução 2: Usar caminho completo
python /usr/local/bin/cobol-to-docs --help

# Solução 3: Adicionar ao PATH
export PATH=$PATH:/usr/local/bin
```

#### 2. Erro de importação da API
```python
# Erro: ModuleNotFoundError: No module named 'cobol_to_docs'

# Verificar instalação
import sys
print(sys.path)

# Reinstalar se necessário
import subprocess
subprocess.run(['python', 'install_api.py'])

# Verificar novamente
import cobol_to_docs
print("API instalada com sucesso")
```

#### 3. Problemas de configuração
```bash
# Erro: ConfigurationError

# Reinicializar ambiente
cobol-to-docs --init --force-init

# Verificar configuração
cobol-to-docs --status

# Usar modelo padrão
cobol-to-docs --fontes programas.txt --models enhanced_mock
```

#### 4. Erro de permissão
```bash
# Erro: Permission denied

# Instalar para usuário atual
python install_api.py --user

# Ou usar sudo (Linux/Mac)
sudo python install_api.py
```

#### 5. Problemas de dependências
```bash
# Erro: ImportError

# Reinstalar dependências
pip install -r requirements.txt --force-reinstall

# Verificar versão do Python
python --version  # Deve ser 3.8+
```

### Diagnóstico

#### Script de Diagnóstico
```python
def diagnosticar_instalacao():
    """Diagnóstica problemas na instalação"""
    
    print("Diagnóstico COBOL Analyzer")
    print("=" * 40)
    
    # 1. Verificar Python
    import sys
    print(f"Python: {sys.version}")
    
    if sys.version_info < (3, 8):
        print("ERRO: Python 3.8+ necessário")
        return False
    
    # 2. Verificar importação
    try:
        import cobol_to_docs
        print("API: Importação OK")
    except ImportError as e:
        print(f"ERRO: Importação falhou - {e}")
        return False
    
    # 3. Verificar comando
    import shutil
    if shutil.which('cobol-to-docs'):
        print("Comando: Disponível")
    else:
        print("AVISO: Comando não encontrado no PATH")
    
    # 4. Verificar inicialização
    try:
        cobol_to_docs.init()
        print("Inicialização: OK")
    except Exception as e:
        print(f"ERRO: Inicialização falhou - {e}")
        return False
    
    # 5. Verificar análise básica
    try:
        resultado = cobol_to_docs.analyze_program(
            "IDENTIFICATION DIVISION.\nPROGRAM-ID. TESTE.\nPROCEDURE DIVISION.\nSTOP RUN.",
            "TESTE.CBL"
        )
        if resultado.success:
            print("Análise: OK")
        else:
            print(f"ERRO: Análise falhou - {resultado.error_message}")
            return False
    except Exception as e:
        print(f"ERRO: Análise falhou - {e}")
        return False
    
    print("\nTodos os testes passaram!")
    return True

# Executar diagnóstico
if __name__ == "__main__":
    diagnosticar_instalacao()
```

### Logs e Depuração

#### Configurar Logging
```python
import logging
import cobol_to_docs

# Configurar nível de log
logging.basicConfig(level=logging.DEBUG)

# Ou via configuração
cobol_to_docs.configure({
    'log_level': 'DEBUG',
    'log_file': 'debug.log'
})
```

#### Verificar Logs
```bash
# Ver logs em tempo real
tail -f logs/cobol_analyzer.log

# Buscar erros específicos
grep "ERROR" logs/cobol_analyzer.log

# Ver últimas 50 linhas
tail -50 logs/cobol_analyzer.log
```

## Performance e Otimização

### Configuração de Performance

```python
# Configuração otimizada para performance
cobol_to_docs.configure({
    'model': 'enhanced_mock',  # Mais rápido para testes
    'analysis_type': 'basic',  # Análise mais rápida
    'max_tokens': 4000,        # Reduzir tokens para velocidade
    'temperature': 0.0,        # Determinístico e mais rápido
    'parallel': True           # Processamento paralelo quando disponível
})
```

### Análise em Lote Otimizada

```python
def analisar_lote_otimizado(arquivos, batch_size=10):
    """Análise em lote com otimizações"""
    
    resultados = []
    
    # Processar em lotes menores
    for i in range(0, len(arquivos), batch_size):
        lote = arquivos[i:i+batch_size]
        
        print(f"Processando lote {i//batch_size + 1}: {len(lote)} arquivos")
        
        resultado_lote = cobol_to_docs.analyze_batch(
            file_paths=lote,
            analysis_type='basic',  # Mais rápido
            parallel=True
        )
        
        resultados.extend(resultado_lote.results)
    
    return resultados

# Usar análise otimizada
arquivos = ["PROG1.CBL", "PROG2.CBL", "PROG3.CBL", "PROG4.CBL"]
resultados = analisar_lote_otimizado(arquivos)
```

### Cache de Resultados

```python
import pickle
import hashlib
import os

class COBOLCache:
    """Cache para resultados de análise"""
    
    def __init__(self, cache_dir="./cache"):
        self.cache_dir = cache_dir
        os.makedirs(cache_dir, exist_ok=True)
    
    def _get_cache_key(self, codigo, modelo, analysis_type):
        """Gera chave única para cache"""
        content = f"{codigo}{modelo}{analysis_type}"
        return hashlib.md5(content.encode()).hexdigest()
    
    def get(self, codigo, modelo, analysis_type):
        """Recupera resultado do cache"""
        key = self._get_cache_key(codigo, modelo, analysis_type)
        cache_file = os.path.join(self.cache_dir, f"{key}.pkl")
        
        if os.path.exists(cache_file):
            with open(cache_file, 'rb') as f:
                return pickle.load(f)
        
        return None
    
    def set(self, codigo, modelo, analysis_type, resultado):
        """Salva resultado no cache"""
        key = self._get_cache_key(codigo, modelo, analysis_type)
        cache_file = os.path.join(self.cache_dir, f"{key}.pkl")
        
        with open(cache_file, 'wb') as f:
            pickle.dump(resultado, f)
    
    def analyze_with_cache(self, codigo, nome, modelo='enhanced_mock', analysis_type='detailed'):
        """Análise com cache"""
        
        # Verificar cache
        resultado = self.get(codigo, modelo, analysis_type)
        if resultado:
            print(f"Cache hit para {nome}")
            return resultado
        
        # Analisar e cachear
        print(f"Analisando {nome}...")
        resultado = cobol_to_docs.analyze_program(
            program_content=codigo,
            program_name=nome,
            model=modelo,
            analysis_type=analysis_type
        )
        
        if resultado.success:
            self.set(codigo, modelo, analysis_type, resultado)
        
        return resultado

# Usar cache
cache = COBOLCache()
resultado = cache.analyze_with_cache(codigo_cobol, "PROGRAMA.CBL")
```

## Integração com Ferramentas

### Integração com Git

```python
import subprocess
import cobol_to_docs

def analisar_mudancas_git():
    """Analisa apenas arquivos COBOL modificados no Git"""
    
    # Obter arquivos modificados
    result = subprocess.run(
        ['git', 'diff', '--name-only', 'HEAD~1', 'HEAD'],
        capture_output=True, text=True
    )
    
    arquivos_modificados = result.stdout.strip().split('\n')
    
    # Filtrar apenas arquivos COBOL
    cobol_files = [f for f in arquivos_modificados 
                   if f.endswith(('.CBL', '.cbl', '.COB', '.cob'))]
    
    if not cobol_files:
        print("Nenhum arquivo COBOL modificado")
        return
    
    print(f"Analisando {len(cobol_files)} arquivos modificados:")
    
    # Analisar arquivos
    cobol_to_docs.init()
    resultado = cobol_to_docs.analyze_batch(cobol_files)
    
    # Relatório para commit
    relatorio = f"""
Análise COBOL - Commit {subprocess.run(['git', 'rev-parse', 'HEAD'], capture_output=True, text=True).stdout[:8]}

Arquivos analisados: {resultado.total_programs}
Sucessos: {resultado.successful}
Falhas: {resultado.failed}
Tempo total: {resultado.total_time:.2f}s

Arquivos:
"""
    
    for res in resultado.results:
        status = "OK" if res.success else "ERRO"
        relatorio += f"- {res.program_name}: {status}\n"
    
    # Salvar relatório
    with open('cobol_analysis_report.txt', 'w') as f:
        f.write(relatorio)
    
    print("Relatório salvo em: cobol_analysis_report.txt")

# Usar em hook do Git
if __name__ == "__main__":
    analisar_mudancas_git()
```

### Integração com Jenkins

```python
# Jenkinsfile (pipeline)
"""
pipeline {
    agent any
    
    stages {
        stage('COBOL Analysis') {
            steps {
                script {
                    // Instalar COBOL Analyzer
                    sh 'python install_api.py'
                    
                    // Executar análise
                    sh '''
                        python -c "
import cobol_to_docs
import json

# Analisar todos os arquivos COBOL
import glob
files = glob.glob('**/*.CBL', recursive=True)

if files:
    cobol_to_docs.init()
    result = cobol_to_docs.analyze_batch(files)
    
    # Gerar relatório para Jenkins
    report = {
        'total': result.total_programs,
        'successful': result.successful,
        'failed': result.failed,
        'success_rate': result.successful / result.total_programs * 100
    }
    
    with open('cobol_report.json', 'w') as f:
        json.dump(report, f)
    
    # Falhar build se muitas falhas
    if report['success_rate'] < 80:
        exit(1)
else:
    print('No COBOL files found')
"
                    '''
                }
            }
        }
    }
    
    post {
        always {
            // Arquivar relatórios
            archiveArtifacts artifacts: 'cobol_report.json', allowEmptyArchive: true
            
            // Publicar resultados
            publishHTML([
                allowMissing: false,
                alwaysLinkToLastBuild: true,
                keepAll: true,
                reportDir: 'output',
                reportFiles: '*.html',
                reportName: 'COBOL Analysis Report'
            ])
        }
    }
}
"""
```

### Integração com Docker

```dockerfile
# Dockerfile
FROM python:3.11-slim

# Instalar dependências do sistema
RUN apt-get update && apt-get install -y \
    git \
    && rm -rf /var/lib/apt/lists/*

# Criar diretório de trabalho
WORKDIR /app

# Copiar arquivos do projeto
COPY . .

# Instalar COBOL Analyzer
RUN python install_api.py

# Criar script de entrada
RUN echo '#!/bin/bash\ncobol-to-docs "$@"' > /usr/local/bin/analyze-cobol && \
    chmod +x /usr/local/bin/analyze-cobol

# Definir entrada padrão
ENTRYPOINT ["analyze-cobol"]
CMD ["--help"]
```

```bash
# Usar container Docker
docker build -t cobol-analyzer .

# Analisar arquivos locais
docker run -v $(pwd):/workspace cobol-analyzer --init
docker run -v $(pwd):/workspace cobol-analyzer --fontes /workspace/programas.txt
```

## Licença e Suporte

### Licença

Este software é distribuído sob a Licença MIT. Você tem permissão para:

- Usar comercialmente
- Modificar o código
- Distribuir
- Usar em projetos privados

### Suporte Técnico

Para suporte técnico e documentação adicional:

1. **Documentação**: Consulte este arquivo e os guias específicos
2. **Exemplos**: Veja os arquivos de exemplo incluídos
3. **Logs**: Verifique os logs em `logs/` para depuração
4. **Diagnóstico**: Use o script de diagnóstico incluído

### Contribuição

Para contribuir com o projeto:

1. Faça fork do repositório
2. Crie uma branch para sua feature
3. Implemente as mudanças
4. Adicione testes se necessário
5. Envie um pull request

### Versão e Compatibilidade

- **Versão Atual**: 3.1.0
- **Data de Lançamento**: Outubro 2025
- **Compatibilidade**: Python 3.8+
- **Sistemas Suportados**: Windows, Linux, macOS

---

**COBOL Analyzer v3.1.0** - Transformando sistemas legados em documentação moderna com inteligência artificial.
