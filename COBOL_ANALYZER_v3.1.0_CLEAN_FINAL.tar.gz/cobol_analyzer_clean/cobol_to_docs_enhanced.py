#!/usr/bin/env python3
"""
COBOL to Docs Enhanced v3.1.0 - Wrapper principal com inicialização automática
Ponto de entrada global que suporta diretórios personalizados e inicialização automática
"""

import sys
import os
from pathlib import Path

# Adicionar diretório atual ao path para importações
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, current_dir)

def main():
    """
    Ponto de entrada principal que delega para o CLI enhanced
    Mantém compatibilidade total com versões anteriores
    """
    try:
        # Verificar se é comando --init primeiro
        if '--init' in sys.argv:
            # Executar main_enhanced.py diretamente para --init
            import subprocess
            main_script = os.path.join(current_dir, 'main_enhanced.py')
            if os.path.exists(main_script):
                # Substituir --init por --init-local para compatibilidade
                args = [arg if arg != '--init' else '--init-local' for arg in sys.argv[1:]]
                cmd = [sys.executable, main_script] + args
                result = subprocess.run(cmd, check=False)
                sys.exit(result.returncode)
        
        # Importar e executar CLI enhanced
        from cli_enhanced import main as cli_main
        cli_main()
    except ImportError:
        # Fallback para CLI original se enhanced não estiver disponível
        try:
            from cli import main as cli_original
            cli_original()
        except ImportError:
            # Último recurso: executar main.py diretamente
            import subprocess
            main_script = os.path.join(current_dir, 'main_enhanced.py')
            if not os.path.exists(main_script):
                main_script = os.path.join(current_dir, 'main.py')
            
            if os.path.exists(main_script):
                cmd = [sys.executable, main_script] + sys.argv[1:]
                result = subprocess.run(cmd, check=False)
                sys.exit(result.returncode)
            else:
                print("Erro: Não foi possível encontrar os arquivos principais do COBOL Analyzer")
                sys.exit(1)

if __name__ == "__main__":
    main()
