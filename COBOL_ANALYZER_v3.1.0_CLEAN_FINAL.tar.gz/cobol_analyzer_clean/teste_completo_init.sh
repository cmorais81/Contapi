#!/bin/bash
# Script de teste completo para validar funcionalidade --init

echo "🧪 TESTE COMPLETO - COBOL Analyzer --init"
echo "========================================"

# Função para limpar testes
cleanup() {
    cd /home/ubuntu
    rm -rf test_init_*
}

# Limpar testes anteriores
cleanup

echo ""
echo "=== Teste 1: Inicialização Básica ==="
mkdir test_init_basico && cd test_init_basico
echo "📍 Diretório: $(pwd)"

if cobol-to-docs --init; then
    echo "✅ Comando executado com sucesso"
    
    # Verificar diretórios
    dirs_created=$(ls -1d */ 2>/dev/null | wc -l)
    echo "📁 Diretórios criados: $dirs_created"
    
    # Verificar arquivos config
    if [ -d "config" ]; then
        config_files=$(ls -1 config/ | wc -l)
        echo "⚙️  Arquivos config: $config_files"
    else
        echo "❌ Diretório config não encontrado"
    fi
    
    # Verificar arquivos data
    if [ -d "data" ]; then
        data_files=$(ls -1 data/ | wc -l)
        echo "📊 Arquivos data: $data_files"
    else
        echo "❌ Diretório data não encontrado"
    fi
    
    # Verificar arquivo de controle
    if [ -f ".cobol_analyzer_init" ]; then
        echo "✅ Arquivo de controle criado"
    else
        echo "❌ Arquivo de controle não encontrado"
    fi
else
    echo "❌ Comando falhou"
fi

cd /home/ubuntu

echo ""
echo "=== Teste 2: Diretórios Personalizados ==="
mkdir test_init_personalizado && cd test_init_personalizado
echo "📍 Diretório: $(pwd)"

if cobol-to-docs --init --config-dir ./custom_config --data-dir ./custom_data --logs-dir ./custom_logs; then
    echo "✅ Comando com diretórios personalizados executado"
    
    # Verificar diretórios personalizados
    if [ -d "custom_config" ]; then
        echo "✅ custom_config criado"
        custom_config_files=$(ls -1 custom_config/ | wc -l)
        echo "⚙️  Arquivos em custom_config: $custom_config_files"
    else
        echo "❌ custom_config não encontrado"
    fi
    
    if [ -d "custom_data" ]; then
        echo "✅ custom_data criado"
        custom_data_files=$(ls -1 custom_data/ | wc -l)
        echo "📊 Arquivos em custom_data: $custom_data_files"
    else
        echo "❌ custom_data não encontrado"
    fi
    
    if [ -d "custom_logs" ]; then
        echo "✅ custom_logs criado"
    else
        echo "❌ custom_logs não encontrado"
    fi
else
    echo "❌ Comando com diretórios personalizados falhou"
fi

cd /home/ubuntu

echo ""
echo "=== Teste 3: Comandos Existentes ==="
echo "🔍 Testando compatibilidade..."

if cobol-to-docs --help > /dev/null 2>&1; then
    echo "✅ --help funcionando"
else
    echo "❌ --help falhou"
fi

if cobol-to-docs --status > /dev/null 2>&1; then
    echo "✅ --status funcionando"
else
    echo "❌ --status falhou"
fi

echo ""
echo "=== Teste 4: Verificação de Arquivos ==="
echo "🔍 Verificando arquivos fonte..."

if [ -f "/home/ubuntu/cobol_analyzer_EXCELENCIA/main_enhanced.py" ]; then
    echo "✅ main_enhanced.py encontrado"
else
    echo "❌ main_enhanced.py não encontrado"
fi

if [ -d "/home/ubuntu/cobol_analyzer_EXCELENCIA/config" ]; then
    source_config_files=$(ls -1 /home/ubuntu/cobol_analyzer_EXCELENCIA/config/ | wc -l)
    echo "✅ Diretório config fonte: $source_config_files arquivos"
else
    echo "❌ Diretório config fonte não encontrado"
fi

if [ -d "/home/ubuntu/cobol_analyzer_EXCELENCIA/data" ]; then
    source_data_files=$(ls -1 /home/ubuntu/cobol_analyzer_EXCELENCIA/data/ | wc -l)
    echo "✅ Diretório data fonte: $source_data_files arquivos"
else
    echo "❌ Diretório data fonte não encontrado"
fi

echo ""
echo "=== Resumo dos Testes ==="
echo "📋 Teste 1 (Básico): $([ -d "test_init_basico/config" ] && echo "✅ PASSOU" || echo "❌ FALHOU")"
echo "📋 Teste 2 (Personalizado): $([ -d "test_init_personalizado/custom_config" ] && echo "✅ PASSOU" || echo "❌ FALHOU")"
echo "📋 Teste 3 (Compatibilidade): $(cobol-to-docs --help > /dev/null 2>&1 && echo "✅ PASSOU" || echo "❌ FALHOU")"
echo "📋 Teste 4 (Arquivos): $([ -f "/home/ubuntu/cobol_analyzer_EXCELENCIA/main_enhanced.py" ] && echo "✅ PASSOU" || echo "❌ FALHOU")"

echo ""
echo "🎯 CONCLUSÃO:"
if [ -d "test_init_basico/config" ] && [ -d "test_init_personalizado/custom_config" ]; then
    echo "✅ TODOS OS TESTES PASSARAM - Funcionalidade --init está FUNCIONANDO"
else
    echo "❌ ALGUNS TESTES FALHARAM - Verificar problemas"
fi

# Limpar testes
cleanup

echo ""
echo "🧹 Testes limpos. Teste concluído."
