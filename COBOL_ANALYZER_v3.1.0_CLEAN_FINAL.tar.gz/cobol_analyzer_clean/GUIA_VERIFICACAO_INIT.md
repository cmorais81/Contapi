# Guia de Verificação - Comando --init

## Status Atual:  FUNCIONANDO

O comando `cobol-to-docs --init` está funcionando corretamente e criando todos os arquivos necessários.

## Verificação Completa

### 1. Teste Básico
```bash
# Criar diretório de teste
mkdir test_verificacao && cd test_verificacao

# Executar inicialização
cobol-to-docs --init

# Verificar resultado
ls -la
```

**Resultado Esperado:**
```
drwxrwxr-x  6 ubuntu ubuntu 4096 config/
drwxrwxr-x  5 ubuntu ubuntu 4096 data/
drwxrwxr-x  2 ubuntu ubuntu 4096 examples/
drwxrwxr-x  2 ubuntu ubuntu 4096 logs/
-rw-rw-r--  1 ubuntu ubuntu   40 .cobol_analyzer_init
```

### 2. Verificação de Arquivos de Configuração
```bash
ls -la config/
```

**Resultado Esperado:**
```
-rw-rw-r-- config.yaml                      # Configuração principal
-rw-rw-r-- config_enhanced.yaml             # Configuração v3.1.0
-rw-rw-r-- prompts_enhanced.yaml            # Prompts especializados
-rw-rw-r-- prompts_cadoc_deep_analysis.yaml # Prompts análise profunda
-rw-rw-r-- prompts_deep_business_rules.yaml # Prompts regras de negócio
-rw-rw-r-- prompts_doc_legado_pro.yaml      # Prompts documentação legado
-rw-rw-r-- prompts_especialista.yaml        # Prompts especialista
-rw-rw-r-- prompts_melhorado_rag.yaml       # Prompts RAG melhorado
```

### 3. Verificação da Base de Conhecimento RAG
```bash
ls -la data/
```

**Resultado Esperado:**
```
-rw-rw-r-- cobol_knowledge_base.json                # Base principal
-rw-rw-r-- cobol_knowledge_base_backup.json         # Backup
-rw-rw-r-- cobol_knowledge_base_cadoc_expanded.json # Base expandida
-rw-rw-r-- cobol_knowledge_base_consolidated.json   # Base consolidada
drwxrwxr-x embeddings/                              # Cache embeddings
drwxrwxr-x knowledge_base/                          # Base conhecimento
drwxrwxr-x sessions/                                # Sessões RAG
```

### 4. Teste com Diretórios Personalizados
```bash
# Criar novo teste
mkdir test_personalizado && cd test_personalizado

# Executar com diretórios personalizados
cobol-to-docs --init --config-dir ./minha_config --data-dir ./meus_dados --logs-dir ./meus_logs

# Verificar estrutura
ls -la
```

**Resultado Esperado:**
```
drwxrwxr-x minha_config/  # Configurações personalizadas
drwxrwxr-x meus_dados/    # Dados RAG personalizados
drwxrwxr-x meus_logs/     # Logs personalizados
drwxrwxr-x examples/      # Exemplos (sempre no diretório atual)
```

## Solução de Problemas

### Problema: "unrecognized arguments: --init"

**Causa**: Entry point não corrigido
**Solução**:
```bash
# Executar script de correção
python fix_install.py

# Testar novamente
cobol-to-docs --init
```

### Problema: "main_enhanced.py não encontrado"

**Causa**: Arquivo não está no local esperado
**Solução**:
```bash
# Verificar se arquivo existe
ls -la /home/ubuntu/cobol_analyzer_EXCELENCIA/main_enhanced.py

# Se não existir, reinstalar
pip install --force-reinstall .
python fix_install.py
```

### Problema: Diretórios criados mas vazios

**Causa**: Erro na cópia de arquivos
**Solução**:
```bash
# Verificar permissões
ls -la /home/ubuntu/cobol_analyzer_EXCELENCIA/config/
ls -la /home/ubuntu/cobol_analyzer_EXCELENCIA/data/

# Executar com --force-init
cobol-to-docs --init --force-init
```

### Problema: Erro de permissão

**Causa**: Sem permissão para criar diretórios
**Solução**:
```bash
# Usar diretório com permissão
cd ~/
mkdir meu_projeto && cd meu_projeto
cobol-to-docs --init

# Ou especificar diretórios com permissão
cobol-to-docs --init --config-dir ~/config --data-dir ~/data
```

## Comandos de Diagnóstico

### Verificar Instalação
```bash
# Verificar comando disponível
which cobol-to-docs

# Verificar versão do script
head -20 /usr/local/bin/cobol-to-docs

# Testar comando básico
cobol-to-docs --help
```

### Verificar Arquivos Fonte
```bash
# Verificar main_enhanced.py
ls -la /home/ubuntu/cobol_analyzer_EXCELENCIA/main_enhanced.py

# Verificar arquivos de configuração
ls -la /home/ubuntu/cobol_analyzer_EXCELENCIA/config/

# Verificar base de conhecimento
ls -la /home/ubuntu/cobol_analyzer_EXCELENCIA/data/
```

### Teste Manual Direto
```bash
# Se cobol-to-docs --init falhar, testar diretamente
python /home/ubuntu/cobol_analyzer_EXCELENCIA/main_enhanced.py --init-local

# Com diretórios personalizados
python /home/ubuntu/cobol_analyzer_EXCELENCIA/main_enhanced.py --init-local \
  --config-dir ./config --data-dir ./data --logs-dir ./logs
```

## Validação Final

### Checklist de Verificação
- [ ] Comando `cobol-to-docs --init` executa sem erro
- [ ] Diretórios criados: config, data, logs, examples
- [ ] Arquivo `.cobol_analyzer_init` criado
- [ ] Arquivos de configuração copiados (8 arquivos em config/)
- [ ] Base de conhecimento RAG inicializada (4 arquivos + 3 diretórios em data/)
- [ ] Diretórios personalizados funcionando
- [ ] Comandos existentes ainda funcionam

### Teste Completo
```bash
#!/bin/bash
# Script de teste completo

echo "=== Teste 1: Inicialização Básica ==="
mkdir test1 && cd test1
cobol-to-docs --init
echo "Diretórios criados: $(ls -1 | wc -l)"
echo "Arquivos config: $(ls -1 config/ | wc -l)"
echo "Arquivos data: $(ls -1 data/ | wc -l)"
cd ..

echo "=== Teste 2: Diretórios Personalizados ==="
mkdir test2 && cd test2
cobol-to-docs --init --config-dir ./custom_config --data-dir ./custom_data
echo "Config personalizado: $(ls -d custom_config 2>/dev/null && echo 'OK' || echo 'FALHOU')"
echo "Data personalizado: $(ls -d custom_data 2>/dev/null && echo 'OK' || echo 'FALHOU')"
cd ..

echo "=== Teste 3: Comandos Existentes ==="
cobol-to-docs --help > /dev/null && echo "Help: OK" || echo "Help: FALHOU"
cobol-to-docs --status > /dev/null && echo "Status: OK" || echo "Status: FALHOU"

echo "=== Todos os testes concluídos ==="
```

## Resultado da Verificação

###  Status Confirmado: FUNCIONANDO

Baseado nos testes realizados:

1. **Comando --init**:  Funcionando
2. **Criação de diretórios**:  Funcionando
3. **Cópia de arquivos**:  Funcionando
4. **Base RAG**:  Funcionando
5. **Diretórios personalizados**:  Funcionando
6. **Compatibilidade**:  Mantida

### Estrutura Completa Criada

**Diretórios**: 4 (config, data, logs, examples)
**Arquivos de configuração**: 8 arquivos YAML
**Base de conhecimento**: 4 arquivos JSON + 3 diretórios
**Arquivo de controle**: .cobol_analyzer_init

### Recomendação

O comando `cobol-to-docs --init` está **totalmente funcional**. Se houver problemas:

1. Execute `python fix_install.py` uma vez
2. Teste em diretório limpo
3. Verifique permissões do diretório
4. Use teste manual direto se necessário

---

**Data**: 03/10/2025  
**Status**: Verificação Completa  
**Resultado**: Funcionalidade Totalmente Operacional
