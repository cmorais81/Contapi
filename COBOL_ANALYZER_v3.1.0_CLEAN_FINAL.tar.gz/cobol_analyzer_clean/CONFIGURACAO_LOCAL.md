# Configuração Local Automática - COBOL Analyzer

O COBOL Analyzer agora inclui um sistema de configuração automática que cria uma estrutura local de diretórios e arquivos na primeira execução.

##  Inicialização Automática

### Primeira Execução

Na primeira vez que você executar o COBOL Analyzer (via qualquer método), ele automaticamente criará:

```
./
├── config/
│   ├── config.yaml          # Configuração principal
│   └── prompts.yaml         # Prompts personalizados
├── data/
│   ├── cobol_knowledge_base.json  # Base de conhecimento RAG
│   ├── embeddings/          # Embeddings para RAG
│   ├── knowledge_base/      # Itens de conhecimento
│   └── sessions/            # Sessões RAG
├── logs/                    # Logs da aplicação
└── examples/
    ├── fontes.txt           # Exemplo de lista de programas
    ├── books.txt            # Exemplo de lista de copybooks
    └── PROGRAMA_EXEMPLO.CBL # Programa COBOL de exemplo
```

### Inicialização Manual

Para forçar a criação da estrutura local:

```bash
# Via comando instalado
cobol-to-docs --init

# Via main.py
python3 main.py --init

# Via CLI local
python3 cli.py --init
```

##  Diretórios Personalizados

Você pode especificar diretórios personalizados para configurações, dados e logs:

### Exemplos de Uso

```bash
# Usar diretórios personalizados
cobol-to-docs --config-dir /meu/config \
              --data-dir /meu/dados \
              --logs-dir /meu/logs \
              --fontes programas.txt

# Análise com configuração personalizada
cobol-to-docs --config-dir ./projeto/config \
              --data-dir ./projeto/rag_data \
              --fontes sistema_fontes.txt \
              --consolidado

# Inicializar com diretórios personalizados
cobol-to-docs --init \
              --config-dir ./empresa/config \
              --data-dir ./empresa/knowledge \
              --logs-dir ./empresa/logs
```

### Parâmetros Disponíveis

| Parâmetro | Descrição | Padrão |
|-----------|-----------|---------|
| `--config-dir` | Diretório para arquivos de configuração | `./config` |
| `--data-dir` | Diretório para dados RAG e base de conhecimento | `./data` |
| `--logs-dir` | Diretório para arquivos de log | `./logs` |
| `--init` | Forçar inicialização do ambiente local | - |

##  Arquivos Criados Automaticamente

### config/config.yaml
```yaml
models:
  default: enhanced_mock
  enhanced_mock:
    provider: enhanced_mock
    model: enhanced-mock-gpt-4
    enabled: true

output:
  default_dir: output
  generate_pdf: false
  generate_html: true

rag:
  enabled: true
  knowledge_base_file: data/cobol_knowledge_base.json
  max_items: 10

logging:
  level: INFO
  file: logs/cobol_analyzer.log
```

### data/cobol_knowledge_base.json
Base de conhecimento inicial com conceitos básicos de COBOL:
- IDENTIFICATION DIVISION
- DATA DIVISION  
- PROCEDURE DIVISION
- Estruturas de dados comuns
- Padrões de programação

### examples/fontes.txt
```
# Lista de programas COBOL para análise
# Um programa por linha
# Exemplo:
# PROGRAMA1.CBL
# PROGRAMA2.CBL
```

### examples/PROGRAMA_EXEMPLO.CBL
Programa COBOL de exemplo funcional para testes.

##  Configuração Avançada

### Múltiplos Projetos

Você pode ter diferentes configurações para diferentes projetos:

```bash
# Projeto A
cobol-to-docs --config-dir ./projeto_a/config \
              --data-dir ./projeto_a/rag \
              --fontes projeto_a_fontes.txt

# Projeto B  
cobol-to-docs --config-dir ./projeto_b/config \
              --data-dir ./projeto_b/rag \
              --fontes projeto_b_fontes.txt
```

### Configuração Corporativa

Para uso em ambiente corporativo:

```bash
# Configuração centralizada
cobol-to-docs --config-dir /empresa/cobol_analyzer/config \
              --data-dir /empresa/cobol_analyzer/knowledge \
              --logs-dir /empresa/cobol_analyzer/logs \
              --fontes /projetos/sistema_principal/fontes.txt \
              --consolidado
```

##  Personalização

### Editando Configurações

Após a inicialização, você pode editar os arquivos criados:

1. **config/config.yaml**: Configurações gerais, modelos de IA, providers
2. **config/prompts.yaml**: Prompts personalizados para análise
3. **data/cobol_knowledge_base.json**: Base de conhecimento inicial

### Adicionando Conhecimento Personalizado

Edite `data/cobol_knowledge_base.json` para incluir conhecimento específico da sua empresa:

```json
{
  "knowledge_items": [
    {
      "id": "kb_empresa_001",
      "type": "company_standard",
      "title": "Padrão de Nomenclatura da Empresa",
      "content": "Todos os programas devem seguir o padrão XXXX-YYYY...",
      "tags": ["padrão", "nomenclatura", "empresa"],
      "relevance_score": 0.95
    }
  ]
}
```

##  Vantagens da Configuração Local

###  Benefícios

- **Portabilidade**: Cada projeto tem sua própria configuração
- **Isolamento**: Dados RAG separados por projeto
- **Flexibilidade**: Diretórios personalizáveis
- **Facilidade**: Configuração automática na primeira execução
- **Consistência**: Estrutura padronizada
- **Backup**: Fácil backup de configurações e conhecimento

###  Casos de Uso

1. **Desenvolvimento Individual**: Configuração local simples
2. **Projetos Múltiplos**: Configurações isoladas por projeto
3. **Ambiente Corporativo**: Configuração centralizada
4. **Análise Temporária**: Diretórios temporários
5. **Backup/Restore**: Preservação de configurações

##  Migração de Configurações Existentes

Se você já tem configurações do COBOL Analyzer:

1. **Backup**: Faça backup das configurações existentes
2. **Inicialização**: Execute `--init` para criar nova estrutura
3. **Migração**: Copie suas configurações personalizadas
4. **Teste**: Valide se tudo funciona corretamente

```bash
# Backup
cp -r config config_backup
cp -r data data_backup

# Inicializar nova estrutura
cobol-to-docs --init

# Restaurar configurações personalizadas
cp config_backup/config.yaml config/
cp -r data_backup/cobol_knowledge_base.json data/
```

##  Monitoramento

### Verificação de Status

```bash
# Verificar se ambiente está inicializado
ls -la | grep .cobol_analyzer_init

# Verificar estrutura criada
tree config data logs examples
```

### Logs de Inicialização

Os logs de inicialização são salvos em `logs/` e incluem:
- Diretórios criados
- Arquivos copiados
- Configurações aplicadas
- Erros ou avisos

##  Solução de Problemas

### Problemas Comuns

1. **Permissões**: Certifique-se de ter permissão de escrita no diretório
2. **Espaço em Disco**: Verifique se há espaço suficiente
3. **Diretórios Existentes**: A inicialização não sobrescreve arquivos existentes

### Reinicialização

Para reinicializar completamente:

```bash
# Remover marcador de inicialização
rm .cobol_analyzer_init

# Executar novamente
cobol-to-docs --init
```

##  Conclusão

A configuração local automática torna o COBOL Analyzer mais flexível e fácil de usar, permitindo:

- **Configuração zero** para começar rapidamente
- **Personalização completa** para necessidades específicas  
- **Isolamento de projetos** para trabalhar com múltiplos sistemas
- **Facilidade de backup** e migração de configurações

Agora você pode usar o COBOL Analyzer de forma profissional em qualquer ambiente!
