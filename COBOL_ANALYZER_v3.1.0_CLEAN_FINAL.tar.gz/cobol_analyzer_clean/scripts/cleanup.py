#!/usr/bin/env python3
"""
Script de Limpeza Inteligente
Remove arquivos de teste e logs desnecessários mantendo estrutura essencial

Autor: Carlos Morais
Data: 03/10/2025
"""

import os
import shutil
import glob
from pathlib import Path
from typing import List, Set
import argparse

class IntelligentCleaner:
    """Limpador inteligente que preserva arquivos essenciais"""
    
    def __init__(self, base_path: str, dry_run: bool = True):
        self.base_path = Path(base_path)
        self.dry_run = dry_run
        self.removed_files: List[str] = []
        self.removed_dirs: List[str] = []
        self.preserved_files: List[str] = []
        
        # Padrões de arquivos/diretórios para remover
        self.remove_patterns = [
            # Diretórios de teste
            "teste*",
            "*test*",
            "*debug*",
            "temp*",
            "tmp*",
            
            # Arquivos de log antigos
            "*.log",
            "execution_log*.txt",
            
            # Arquivos temporários
            "*.tmp",
            "*.temp",
            "*.bak",
            "*.backup",
            
            # Cache e builds
            "__pycache__",
            "*.pyc",
            "*.pyo",
            ".pytest_cache",
            ".coverage",
            
            # Arquivos de sistema
            ".DS_Store",
            "Thumbs.db",
            "*.swp",
            "*.swo",
            "*~"
        ]
        
        # Arquivos/diretórios essenciais para preservar
        self.preserve_patterns = [
            # Arquivos de configuração essenciais
            "config/*.yaml",
            "config/*.yml",
            "requirements.txt",
            "setup.py",
            "main.py",
            
            # Documentação
            "README*",
            "CHANGELOG*",
            "LICENSE*",
            "docs/*",
            
            # Código fonte principal
            "src/**/*.py",
            "cobol_analyzer/**/*.py",
            
            # Exemplos importantes
            "examples/fontes.txt",
            "examples/BOOKS.txt",
            
            # Templates
            "templates/*"
        ]
    
    def should_preserve(self, path: Path) -> bool:
        """Verifica se arquivo/diretório deve ser preservado"""
        path_str = str(path.relative_to(self.base_path))
        
        # Verificar padrões de preservação
        for pattern in self.preserve_patterns:
            if path.match(pattern) or Path(path_str).match(pattern):
                return True
        
        # Preservar se contém arquivos essenciais
        if path.is_dir():
            for preserve_pattern in self.preserve_patterns:
                if list(path.glob(preserve_pattern)):
                    return True
        
        return False
    
    def should_remove(self, path: Path) -> bool:
        """Verifica se arquivo/diretório deve ser removido"""
        if self.should_preserve(path):
            return False
        
        path_str = str(path.relative_to(self.base_path))
        
        # Verificar padrões de remoção
        for pattern in self.remove_patterns:
            if path.name.lower().startswith(pattern.replace('*', '').lower()):
                return True
            if path.match(pattern) or Path(path_str).match(pattern):
                return True
        
        return False
    
    def clean_logs(self):
        """Limpa logs antigos mantendo apenas os mais recentes"""
        logs_dir = self.base_path / "logs"
        if not logs_dir.exists():
            return
        
        log_files = list(logs_dir.glob("*.log"))
        if len(log_files) <= 5:  # Manter até 5 logs
            return
        
        # Ordenar por data de modificação
        log_files.sort(key=lambda x: x.stat().st_mtime, reverse=True)
        
        # Remover logs antigos (manter apenas os 5 mais recentes)
        for log_file in log_files[5:]:
            if not self.dry_run:
                log_file.unlink()
            self.removed_files.append(str(log_file))
    
    def clean_rag_sessions(self):
        """Limpa sessões RAG antigas mantendo apenas as mais recentes"""
        rag_dir = self.base_path / "data" / "rag_sessions"
        if not rag_dir.exists():
            return
        
        session_files = list(rag_dir.glob("*.md"))
        if len(session_files) <= 10:  # Manter até 10 sessões
            return
        
        # Ordenar por data de modificação
        session_files.sort(key=lambda x: x.stat().st_mtime, reverse=True)
        
        # Remover sessões antigas (manter apenas as 10 mais recentes)
        for session_file in session_files[10:]:
            if not self.dry_run:
                session_file.unlink()
            self.removed_files.append(str(session_file))
    
    def clean_test_directories(self):
        """Remove diretórios de teste desnecessários"""
        for pattern in ["teste*", "*test*", "*debug*"]:
            for test_dir in self.base_path.glob(pattern):
                if test_dir.is_dir() and not self.should_preserve(test_dir):
                    if not self.dry_run:
                        shutil.rmtree(test_dir)
                    self.removed_dirs.append(str(test_dir))
    
    def clean_temporary_files(self):
        """Remove arquivos temporários"""
        temp_patterns = ["*.tmp", "*.temp", "*.bak", "*.backup", "*.swp", "*.swo", "*~"]
        
        for pattern in temp_patterns:
            for temp_file in self.base_path.rglob(pattern):
                if temp_file.is_file() and not self.should_preserve(temp_file):
                    if not self.dry_run:
                        temp_file.unlink()
                    self.removed_files.append(str(temp_file))
    
    def clean_cache_files(self):
        """Remove arquivos de cache"""
        cache_patterns = ["__pycache__", "*.pyc", "*.pyo", ".pytest_cache"]
        
        for pattern in cache_patterns:
            for cache_item in self.base_path.rglob(pattern):
                if cache_item.is_file():
                    if not self.dry_run:
                        cache_item.unlink()
                    self.removed_files.append(str(cache_item))
                elif cache_item.is_dir():
                    if not self.dry_run:
                        shutil.rmtree(cache_item)
                    self.removed_dirs.append(str(cache_item))
    
    def clean_all(self):
        """Executa limpeza completa"""
        print(f"🧹 Iniciando limpeza {'(DRY RUN)' if self.dry_run else '(REAL)'}")
        print(f" Diretório base: {self.base_path}")
        print()
        
        # Executar limpezas específicas
        self.clean_logs()
        self.clean_rag_sessions()
        self.clean_test_directories()
        self.clean_temporary_files()
        self.clean_cache_files()
        
        # Relatório
        self.print_report()
    
    def print_report(self):
        """Imprime relatório da limpeza"""
        print(" RELATÓRIO DE LIMPEZA")
        print("=" * 50)
        print(f"🗑  Arquivos removidos: {len(self.removed_files)}")
        print(f" Diretórios removidos: {len(self.removed_dirs)}")
        print()
        
        if self.removed_dirs:
            print(" Diretórios removidos:")
            for dir_path in self.removed_dirs[:10]:  # Mostrar apenas os primeiros 10
                print(f"  - {dir_path}")
            if len(self.removed_dirs) > 10:
                print(f"  ... e mais {len(self.removed_dirs) - 10} diretórios")
            print()
        
        if self.removed_files:
            print("🗑 Arquivos removidos (amostra):")
            for file_path in self.removed_files[:15]:  # Mostrar apenas os primeiros 15
                print(f"  - {file_path}")
            if len(self.removed_files) > 15:
                print(f"  ... e mais {len(self.removed_files) - 15} arquivos")
            print()
        
        if self.dry_run:
            print("  MODO DRY RUN: Nenhum arquivo foi realmente removido")
            print("   Execute com --execute para aplicar as mudanças")
        else:
            print(" Limpeza concluída com sucesso!")

def main():
    parser = argparse.ArgumentParser(description="Limpeza inteligente de arquivos de teste e logs")
    parser.add_argument("--path", default=".", help="Caminho base para limpeza")
    parser.add_argument("--execute", action="store_true", help="Executar limpeza real (padrão é dry-run)")
    parser.add_argument("--verbose", "-v", action="store_true", help="Modo verboso")
    
    args = parser.parse_args()
    
    cleaner = IntelligentCleaner(args.path, dry_run=not args.execute)
    cleaner.clean_all()

if __name__ == "__main__":
    main()
