#!/usr/bin/env python3
"""
Exemplo Completo - API Programática COBOL Analyzer
==================================================

Demonstra todas as funcionalidades da API programática
após instalação via: pip install cobol-to-docs
"""

def exemplo_basico():
    """Exemplo básico de uso da API"""
    
    print(" EXEMPLO 1: Uso Básico da API")
    print("=" * 50)
    
    try:
        # Importar o COBOL Analyzer
        import cobol_to_docs
        
        # 1. Inicializar ambiente
        print(" Inicializando ambiente...")
        cobol_to_docs.init()
        print(" Ambiente inicializado")
        
        # 2. Analisar programa simples
        programa_cobol = """
        IDENTIFICATION DIVISION.
        PROGRAM-ID. EXEMPLO-API.
        
        DATA DIVISION.
        WORKING-STORAGE SECTION.
        01 WS-CONTADOR PIC 9(3) VALUE 0.
        01 WS-MENSAGEM PIC X(50) VALUE 'API FUNCIONANDO'.
        
        PROCEDURE DIVISION.
        INICIO.
            DISPLAY WS-MENSAGEM.
            ADD 1 TO WS-CONTADOR.
            DISPLAY 'CONTADOR: ' WS-CONTADOR.
            STOP RUN.
        """
        
        print(" Analisando programa...")
        resultado = cobol_to_docs.analyze_program(
            program_content=programa_cobol,
            program_name="EXEMPLO-API.CBL"
        )
        
        print(f" Análise concluída!")
        print(f"   Programa: {resultado.program_name}")
        print(f"   Sucesso: {resultado.success}")
        print(f"   Tempo: {resultado.execution_time:.2f}s")
        print(f"   Documentação: {len(resultado.documentation)} caracteres")
        
        if resultado.error_message:
            print(f"   Erro: {resultado.error_message}")
        
        return resultado
        
    except ImportError:
        print(" Erro: cobol_to_docs não está instalado")
        print(" Execute: pip install cobol-to-docs")
        return None
    except Exception as e:
        print(f" Erro: {e}")
        return None

def exemplo_configuracao():
    """Exemplo de configuração personalizada"""
    
    print("\n EXEMPLO 2: Configuração Personalizada")
    print("=" * 50)
    
    try:
        import cobol_to_docs
        
        # 1. Verificar configuração atual
        print("⚙ Configuração atual:")
        config = cobol_to_docs.get_config()
        for key, value in config.items():
            print(f"   {key}: {value}")
        
        # 2. Configurar modelo específico
        print("\n🤖 Configurando modelo...")
        cobol_to_docs.set_model('enhanced_mock')
        print(" Modelo configurado")
        
        # 3. Configuração avançada
        print("\n Configuração avançada...")
        cobol_to_docs.configure({
            'analysis_type': 'comprehensive',
            'output_format': 'markdown',
            'include_business_rules': True
        })
        print(" Configuração aplicada")
        
        # 4. Verificar modelos disponíveis
        print("\n Modelos disponíveis:")
        models = cobol_to_docs.list_models()
        for model in models:
            print(f"   - {model}")
        
        # 5. Verificar status
        print("\n Status do sistema:")
        status = cobol_to_docs.status()
        for key, value in status.items():
            print(f"   {key}: {value}")
        
        return True
        
    except Exception as e:
        print(f" Erro: {e}")
        return False

def exemplo_analise_arquivo():
    """Exemplo de análise de arquivo"""
    
    print("\n EXEMPLO 3: Análise de Arquivo")
    print("=" * 50)
    
    try:
        import cobol_to_docs
        
        # 1. Criar arquivo de exemplo
        programa_exemplo = """
        IDENTIFICATION DIVISION.
        PROGRAM-ID. CALC-JUROS.
        AUTHOR. SISTEMA BANCARIO.
        
        DATA DIVISION.
        WORKING-STORAGE SECTION.
        01 WS-DADOS-CALCULO.
           05 WS-PRINCIPAL     PIC 9(7)V99 VALUE 0.
           05 WS-TAXA-JUROS    PIC 9V9999  VALUE 0.
           05 WS-PRAZO         PIC 9(3)    VALUE 0.
           05 WS-JUROS-CALC    PIC 9(7)V99 VALUE 0.
        
        01 WS-MENSAGENS.
           05 WS-MSG-INICIO    PIC X(30) VALUE 'CALCULO DE JUROS INICIADO'.
           05 WS-MSG-FIM       PIC X(30) VALUE 'CALCULO CONCLUIDO'.
        
        PROCEDURE DIVISION.
        MAIN-PROCESS.
            DISPLAY WS-MSG-INICIO.
            
            MOVE 10000.00 TO WS-PRINCIPAL.
            MOVE 0.0150   TO WS-TAXA-JUROS.
            MOVE 12       TO WS-PRAZO.
            
            PERFORM CALCULAR-JUROS.
            
            DISPLAY 'PRINCIPAL: ' WS-PRINCIPAL.
            DISPLAY 'TAXA: ' WS-TAXA-JUROS.
            DISPLAY 'PRAZO: ' WS-PRAZO.
            DISPLAY 'JUROS: ' WS-JUROS-CALC.
            
            DISPLAY WS-MSG-FIM.
            STOP RUN.
        
        CALCULAR-JUROS.
            COMPUTE WS-JUROS-CALC = WS-PRINCIPAL * WS-TAXA-JUROS * WS-PRAZO.
        """
        
        arquivo_teste = "CALC-JUROS.CBL"
        
        print(f" Criando arquivo: {arquivo_teste}")
        with open(arquivo_teste, 'w') as f:
            f.write(programa_exemplo)
        
        # 2. Analisar arquivo
        print(" Analisando arquivo...")
        resultado = cobol_to_docs.analyze_file(
            file_path=arquivo_teste,
            analysis_type='detailed'
        )
        
        print(f" Análise do arquivo concluída!")
        print(f"   Arquivo: {resultado.program_name}")
        print(f"   Sucesso: {resultado.success}")
        print(f"   Tempo: {resultado.execution_time:.2f}s")
        print(f"   Modelo usado: {resultado.metadata.get('model', 'N/A')}")
        
        # 3. Mostrar parte da documentação
        if resultado.success and resultado.documentation:
            print(f"\n Documentação gerada ({len(resultado.documentation)} caracteres):")
            print("   " + resultado.documentation[:200] + "...")
        
        # 4. Limpar arquivo
        import os
        os.unlink(arquivo_teste)
        print(f"🧹 Arquivo {arquivo_teste} removido")
        
        return resultado
        
    except Exception as e:
        print(f" Erro: {e}")
        return None

def exemplo_analise_lote():
    """Exemplo de análise em lote"""
    
    print("\n EXEMPLO 4: Análise em Lote")
    print("=" * 50)
    
    try:
        import cobol_to_docs
        
        # 1. Criar múltiplos programas
        programas = {
            "CLIENTE.CBL": """
            IDENTIFICATION DIVISION.
            PROGRAM-ID. CLIENTE.
            DATA DIVISION.
            WORKING-STORAGE SECTION.
            01 WS-CLIENTE.
               05 WS-CODIGO    PIC 9(6).
               05 WS-NOME      PIC X(50).
               05 WS-CPF       PIC 9(11).
            PROCEDURE DIVISION.
                DISPLAY 'PROGRAMA CLIENTE'.
                STOP RUN.
            """,
            
            "CONTA.CBL": """
            IDENTIFICATION DIVISION.
            PROGRAM-ID. CONTA.
            DATA DIVISION.
            WORKING-STORAGE SECTION.
            01 WS-CONTA.
               05 WS-NUMERO    PIC 9(10).
               05 WS-SALDO     PIC 9(7)V99.
               05 WS-TIPO      PIC X(10).
            PROCEDURE DIVISION.
                DISPLAY 'PROGRAMA CONTA'.
                STOP RUN.
            """,
            
            "TRANSACAO.CBL": """
            IDENTIFICATION DIVISION.
            PROGRAM-ID. TRANSACAO.
            DATA DIVISION.
            WORKING-STORAGE SECTION.
            01 WS-TRANSACAO.
               05 WS-ID        PIC 9(12).
               05 WS-VALOR     PIC 9(7)V99.
               05 WS-DATA      PIC 9(8).
               05 WS-TIPO      PIC X(20).
            PROCEDURE DIVISION.
                DISPLAY 'PROGRAMA TRANSACAO'.
                STOP RUN.
            """
        }
        
        print(f" Criando {len(programas)} programas...")
        arquivos_criados = []
        
        for nome_arquivo, conteudo in programas.items():
            with open(nome_arquivo, 'w') as f:
                f.write(conteudo)
            arquivos_criados.append(nome_arquivo)
            print(f"    {nome_arquivo}")
        
        # 2. Analisar em lote
        print("\n Executando análise em lote...")
        resultado = cobol_to_docs.analyze_batch(
            file_paths=arquivos_criados,
            analysis_type='detailed'
        )
        
        print(f" Análise em lote concluída!")
        print(f"   Total de programas: {resultado.total_programs}")
        print(f"   Sucessos: {resultado.successful}")
        print(f"   Falhas: {resultado.failed}")
        print(f"   Tempo total: {resultado.total_time:.2f}s")
        
        # 3. Mostrar resultados individuais
        print(f"\n Resultados individuais:")
        for i, res in enumerate(resultado.results, 1):
            status = "" if res.success else ""
            print(f"   {i}. {status} {res.program_name} ({res.execution_time:.2f}s)")
            if res.error_message:
                print(f"      Erro: {res.error_message}")
        
        # 4. Limpar arquivos
        print(f"\n🧹 Limpando arquivos...")
        import os
        for arquivo in arquivos_criados:
            os.unlink(arquivo)
            print(f"   🗑 {arquivo}")
        
        return resultado
        
    except Exception as e:
        print(f" Erro: {e}")
        return None

def exemplo_classes_avancadas():
    """Exemplo usando classes avançadas"""
    
    print("\n EXEMPLO 5: Classes Avançadas")
    print("=" * 50)
    
    try:
        import cobol_to_docs
        
        # 1. Usar COBOLAnalyzer
        print(" Usando COBOLAnalyzer...")
        analyzer = cobol_to_docs.COBOLAnalyzer({
            'model': 'enhanced_mock',
            'analysis_type': 'comprehensive',
            'output_format': 'markdown'
        })
        
        programa_teste = """
        IDENTIFICATION DIVISION.
        PROGRAM-ID. TESTE-ANALYZER.
        PROCEDURE DIVISION.
            DISPLAY 'TESTE COM ANALYZER'.
            STOP RUN.
        """
        
        resultado = analyzer.analyze_program(programa_teste, "TESTE-ANALYZER.CBL")
        print(f"    Análise: {resultado.success}")
        
        # 2. Usar COBOLProject
        print("\n Usando COBOLProject...")
        projeto = cobol_to_docs.COBOLProject("SistemaBancario", {
            'analysis_type': 'detailed'
        })
        
        # Criar arquivos do projeto
        arquivos_projeto = ["CLIENTE-PROJ.CBL", "CONTA-PROJ.CBL"]
        for arquivo in arquivos_projeto:
            with open(arquivo, 'w') as f:
                f.write(f"""
                IDENTIFICATION DIVISION.
                PROGRAM-ID. {arquivo.replace('.CBL', '').replace('-', '_')}.
                PROCEDURE DIVISION.
                    DISPLAY 'PROGRAMA DO PROJETO'.
                    STOP RUN.
                """)
            projeto.add_program(arquivo)
        
        resultado_projeto = projeto.analyze_all()
        print(f"    Projeto analisado: {resultado_projeto.successful} programas")
        
        # 3. Usar COBOLBatch
        print("\n Usando COBOLBatch...")
        batch = cobol_to_docs.COBOLBatch({
            'analysis_type': 'basic'
        })
        
        batch.add_files(arquivos_projeto)
        resultado_batch = batch.execute()
        print(f"    Lote executado: {resultado_batch.successful} sucessos")
        
        # 4. Limpar arquivos
        import os
        for arquivo in arquivos_projeto:
            os.unlink(arquivo)
        
        return True
        
    except Exception as e:
        print(f" Erro: {e}")
        return False

def exemplo_integracao_sistema():
    """Exemplo de integração com sistema existente"""
    
    print("\n EXEMPLO 6: Integração com Sistema")
    print("=" * 50)
    
    try:
        import cobol_to_docs
        import json
        from datetime import datetime
        
        # 1. Simular dados de sistema existente
        sistema_dados = {
            'nome': 'Sistema Financeiro',
            'versao': '3.2.1',
            'modulos': [
                {'nome': 'CONTAS', 'programas': ['CONTA001.CBL', 'CONTA002.CBL']},
                {'nome': 'CLIENTES', 'programas': ['CLIENTE01.CBL', 'CLIENTE02.CBL']},
                {'nome': 'RELATORIOS', 'programas': ['RELAT001.CBL']}
            ]
        }
        
        print(f" Integrando com: {sistema_dados['nome']} v{sistema_dados['versao']}")
        
        # 2. Função de integração
        def processar_sistema_cobol(dados_sistema):
            """Processa sistema COBOL existente"""
            
            relatorio = {
                'sistema': dados_sistema['nome'],
                'versao': dados_sistema['versao'],
                'data_analise': datetime.now().isoformat(),
                'modulos': [],
                'resumo': {
                    'total_modulos': len(dados_sistema['modulos']),
                    'total_programas': 0,
                    'programas_analisados': 0
                }
            }
            
            for modulo in dados_sistema['modulos']:
                print(f" Processando módulo: {modulo['nome']}")
                
                modulo_resultado = {
                    'nome': modulo['nome'],
                    'programas': [],
                    'sucessos': 0,
                    'falhas': 0
                }
                
                for programa in modulo['programas']:
                    print(f"    Analisando: {programa}")
                    
                    # Criar programa simulado
                    codigo_simulado = f"""
                    IDENTIFICATION DIVISION.
                    PROGRAM-ID. {programa.replace('.CBL', '').replace('-', '_')}.
                    AUTHOR. {modulo['nome']}.
                    
                    DATA DIVISION.
                    WORKING-STORAGE SECTION.
                    01 WS-STATUS PIC X(10) VALUE 'ATIVO'.
                    
                    PROCEDURE DIVISION.
                        DISPLAY 'PROGRAMA {programa} DO MODULO {modulo["nome"]}'.
                        STOP RUN.
                    """
                    
                    # Analisar programa
                    resultado = cobol_to_docs.analyze_program(
                        program_content=codigo_simulado,
                        program_name=programa
                    )
                    
                    programa_resultado = {
                        'nome': programa,
                        'sucesso': resultado.success,
                        'tempo': resultado.execution_time,
                        'tamanho_doc': len(resultado.documentation)
                    }
                    
                    modulo_resultado['programas'].append(programa_resultado)
                    
                    if resultado.success:
                        modulo_resultado['sucessos'] += 1
                        relatorio['resumo']['programas_analisados'] += 1
                    else:
                        modulo_resultado['falhas'] += 1
                    
                    relatorio['resumo']['total_programas'] += 1
                    
                    print(f"      {'' if resultado.success else ''} {programa}")
                
                relatorio['modulos'].append(modulo_resultado)
                print(f"    Módulo {modulo['nome']}: {modulo_resultado['sucessos']} sucessos")
            
            return relatorio
        
        # 3. Executar integração
        print("\n Executando integração...")
        relatorio = processar_sistema_cobol(sistema_dados)
        
        # 4. Salvar relatório
        arquivo_relatorio = f"relatorio_{sistema_dados['nome'].lower().replace(' ', '_')}.json"
        with open(arquivo_relatorio, 'w', encoding='utf-8') as f:
            json.dump(relatorio, f, indent=2, ensure_ascii=False)
        
        print(f"\n Relatório de Integração:")
        print(f"   Sistema: {relatorio['sistema']}")
        print(f"   Módulos: {relatorio['resumo']['total_modulos']}")
        print(f"   Programas: {relatorio['resumo']['total_programas']}")
        print(f"   Analisados: {relatorio['resumo']['programas_analisados']}")
        print(f"   Relatório salvo: {arquivo_relatorio}")
        
        # 5. Limpar
        import os
        os.unlink(arquivo_relatorio)
        
        return relatorio
        
    except Exception as e:
        print(f" Erro: {e}")
        return None

def main():
    """Executa todos os exemplos da API"""
    
    print(" COBOL ANALYZER - API PROGRAMÁTICA COMPLETA")
    print("=" * 60)
    print("Demonstração de todas as funcionalidades da API")
    print("=" * 60)
    
    exemplos = [
        ("Uso Básico", exemplo_basico),
        ("Configuração", exemplo_configuracao),
        ("Análise de Arquivo", exemplo_analise_arquivo),
        ("Análise em Lote", exemplo_analise_lote),
        ("Classes Avançadas", exemplo_classes_avancadas),
        ("Integração Sistema", exemplo_integracao_sistema)
    ]
    
    sucessos = 0
    resultados = []
    
    for nome, exemplo in exemplos:
        try:
            resultado = exemplo()
            if resultado is not None and resultado is not False:
                sucessos += 1
                resultados.append((nome, " SUCESSO"))
            else:
                resultados.append((nome, " FALHOU"))
        except Exception as e:
            resultados.append((nome, f" ERRO: {e}"))
    
    print(f"\n RESUMO FINAL DA API")
    print("=" * 40)
    
    for nome, status in resultados:
        print(f"{status} {nome}")
    
    print(f"\n Estatísticas:")
    print(f"   Total de exemplos: {len(exemplos)}")
    print(f"   Sucessos: {sucessos}")
    print(f"   Falhas: {len(exemplos) - sucessos}")
    
    if sucessos == len(exemplos):
        print("\n TODOS OS EXEMPLOS DA API FUNCIONARAM!")
        print(" A API está pronta para uso em produção!")
    else:
        print(f"\n  {len(exemplos) - sucessos} exemplo(s) falharam")
        print(" Verifique a instalação e configuração")
    
    print(f"\n COMO USAR EM SEU PROJETO:")
    print("1. pip install cobol-to-docs")
    print("2. import cobol_to_docs")
    print("3. cobol_to_docs.init()")
    print("4. resultado = cobol_to_docs.analyze_program(codigo)")
    print("5. Adapte os exemplos para seu caso de uso")

if __name__ == "__main__":
    main()
