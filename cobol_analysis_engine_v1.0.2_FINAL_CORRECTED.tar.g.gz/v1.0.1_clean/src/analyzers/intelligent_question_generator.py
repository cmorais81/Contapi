import re
import logging
from typing import Dict, Any, List, Set, Tuple
from dataclasses import dataclass
from enum import Enum

class QuestionCategory(Enum):
    BUSINESS_LOGIC = "business_logic"
    DATA_VALIDATION = "data_validation"
    ERROR_HANDLING = "error_handling"
    PERFORMANCE = "performance"
    INTEGRATION = "integration"
    MAINTENANCE = "maintenance"
    TESTING = "testing"

@dataclass
class IntelligentQuestion:
    """Representa uma pergunta inteligente gerada."""
    question: str
    category: QuestionCategory
    priority: str  # HIGH, MEDIUM, LOW
    context: str  # Contexto do código que gerou a pergunta
    line_reference: int
    suggested_validation: str  # Como validar a resposta
    business_impact: str  # Impacto no negócio se não for respondida

class IntelligentQuestionGenerator:
    """
    Gerador de Perguntas Inteligentes
    
    Analisa o código COBOL e gera perguntas específicas e contextuais
    para acelerar sessões de análise com especialistas.
    """

    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
        # Templates de perguntas por padrão identificado
        self.question_templates = {
            'evaluate_incomplete': {
                'template': "O EVALUATE na linha {line} trata todos os valores possíveis de '{variable}'? Existem casos não cobertos?",
                'category': QuestionCategory.BUSINESS_LOGIC,
                'priority': 'HIGH',
                'validation': "Revisar especificação do campo e testar com valores extremos",
                'impact': "Dados inválidos podem causar comportamento inesperado"
            },
            'file_status_check': {
                'template': "O FILE-STATUS do arquivo '{file}' na linha {line} está sendo verificado adequadamente? Todos os códigos de erro são tratados?",
                'category': QuestionCategory.ERROR_HANDLING,
                'priority': 'HIGH',
                'validation': "Testar com arquivo inexistente, sem permissão, corrompido",
                'impact': "Falhas de arquivo podem causar abend do programa"
            },
            'numeric_validation': {
                'template': "O campo numérico '{field}' na linha {line} tem validação contra valores inválidos (zeros, negativos, muito grandes)?",
                'category': QuestionCategory.DATA_VALIDATION,
                'priority': 'MEDIUM',
                'validation': "Testar com valores zero, negativos, máximo do tipo",
                'impact': "Cálculos incorretos podem afetar resultados financeiros"
            },
            'loop_termination': {
                'template': "O loop PERFORM UNTIL na linha {line} tem garantia de terminação? Existe possibilidade de loop infinito?",
                'category': QuestionCategory.PERFORMANCE,
                'priority': 'HIGH',
                'validation': "Analisar condições de parada e testar com dados extremos",
                'impact': "Loop infinito pode travar o sistema"
            },
            'date_validation': {
                'template': "As operações de data na linha {line} consideram anos bissextos, mudanças de século e fusos horários?",
                'category': QuestionCategory.DATA_VALIDATION,
                'priority': 'MEDIUM',
                'validation': "Testar com datas limite: 29/02, 31/12/1999, 01/01/2000",
                'impact': "Erros de data podem afetar relatórios e cálculos"
            },
            'external_call': {
                'template': "A chamada para '{program}' na linha {line} trata adequadamente falhas de execução? O programa chamado está sempre disponível?",
                'category': QuestionCategory.INTEGRATION,
                'priority': 'HIGH',
                'validation': "Testar com programa indisponível ou com erro",
                'impact': "Falha em programa externo pode interromper processamento"
            },
            'memory_usage': {
                'template': "A estrutura OCCURS {size} na linha {line} pode causar problemas de memória com grandes volumes? Existe limite prático?",
                'category': QuestionCategory.PERFORMANCE,
                'priority': 'MEDIUM',
                'validation': "Testar com volume máximo esperado em produção",
                'impact': "Estouro de memória pode causar abend"
            },
            'business_rule': {
                'template': "A regra de negócio implementada na linha {line} está alinhada com a especificação atual? Houve mudanças recentes?",
                'category': QuestionCategory.BUSINESS_LOGIC,
                'priority': 'HIGH',
                'validation': "Validar com analista de negócio e documentação atual",
                'impact': "Regras desatualizadas podem gerar resultados incorretos"
            }
        }

    def generate_questions(self, program_name: str, code_lines: List[str], 
                          analysis_results: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Gera perguntas inteligentes baseadas na análise do código.
        """
        self.logger.info(f"Gerando perguntas inteligentes para {program_name}")
        
        code_text = '\n'.join(code_lines)
        
        # Gera perguntas por categoria
        questions = []
        
        # Perguntas sobre lógica de negócio
        questions.extend(self._generate_business_logic_questions(code_lines, code_text))
        
        # Perguntas sobre validação de dados
        questions.extend(self._generate_data_validation_questions(code_lines, code_text))
        
        # Perguntas sobre tratamento de erros
        questions.extend(self._generate_error_handling_questions(code_lines, code_text))
        
        # Perguntas sobre performance
        questions.extend(self._generate_performance_questions(code_lines, code_text))
        
        # Perguntas sobre integração
        questions.extend(self._generate_integration_questions(code_lines, code_text))
        
        # Perguntas sobre manutenção
        questions.extend(self._generate_maintenance_questions(code_lines, code_text, analysis_results))
        
        # Perguntas sobre testes
        questions.extend(self._generate_testing_questions(code_lines, code_text))
        
        # Ordena por prioridade
        questions.sort(key=lambda q: {'HIGH': 3, 'MEDIUM': 2, 'LOW': 1}[q.priority], reverse=True)
        
        # Agrupa por categoria
        questions_by_category = self._group_questions_by_category(questions)
        
        # Gera estatísticas
        statistics = self._generate_question_statistics(questions)
        
        # Gera agenda sugerida
        suggested_agenda = self._generate_suggested_agenda(questions)
        
        return {
            "program_name": program_name,
            "total_questions": len(questions),
            "questions": questions,
            "questions_by_category": questions_by_category,
            "statistics": statistics,
            "suggested_agenda": suggested_agenda,
            "estimated_session_time": self._estimate_session_time(questions)
        }

    def _generate_business_logic_questions(self, code_lines: List[str], code_text: str) -> List[IntelligentQuestion]:
        """Gera perguntas sobre lógica de negócio."""
        questions = []
        
        # EVALUATE statements
        evaluate_pattern = r'EVALUATE\s+([A-Z0-9-]+)'
        for match in re.finditer(evaluate_pattern, code_text, re.IGNORECASE):
            line_num = code_text[:match.start()].count('\n') + 1
            variable = match.group(1)
            
            # Verifica se tem WHEN OTHER
            evaluate_block = self._extract_evaluate_block(code_lines, line_num - 1)
            has_when_other = 'WHEN OTHER' in evaluate_block.upper()
            
            if not has_when_other:
                template = self.question_templates['evaluate_incomplete']
                questions.append(IntelligentQuestion(
                    question=template['template'].format(line=line_num, variable=variable),
                    category=template['category'],
                    priority=template['priority'],
                    context=code_lines[line_num - 1].strip(),
                    line_reference=line_num,
                    suggested_validation=template['validation'],
                    business_impact=template['impact']
                ))
        
        # IF statements complexos
        complex_if_pattern = r'IF\s+.*\s+AND\s+.*\s+OR\s+'
        for match in re.finditer(complex_if_pattern, code_text, re.IGNORECASE):
            line_num = code_text[:match.start()].count('\n') + 1
            
            questions.append(IntelligentQuestion(
                question=f"A condição complexa na linha {line_num} está correta? A precedência dos operadores AND/OR está clara?",
                category=QuestionCategory.BUSINESS_LOGIC,
                priority='MEDIUM',
                context=code_lines[line_num - 1].strip(),
                line_reference=line_num,
                suggested_validation="Revisar com tabela verdade e testar casos extremos",
                business_impact="Lógica incorreta pode processar dados indevidamente"
            ))
        
        # Cálculos financeiros
        compute_pattern = r'COMPUTE\s+([A-Z0-9-]+)\s*=.*[\+\-\*/]'
        for match in re.finditer(compute_pattern, code_text, re.IGNORECASE):
            line_num = code_text[:match.start()].count('\n') + 1
            field = match.group(1)
            
            questions.append(IntelligentQuestion(
                question=f"O cálculo do campo '{field}' na linha {line_num} está usando a fórmula correta? Considera todas as regras de negócio?",
                category=QuestionCategory.BUSINESS_LOGIC,
                priority='HIGH',
                context=code_lines[line_num - 1].strip(),
                line_reference=line_num,
                suggested_validation="Validar fórmula com especialista de negócio e casos de teste",
                business_impact="Cálculos incorretos podem afetar valores financeiros"
            ))
        
        return questions

    def _generate_data_validation_questions(self, code_lines: List[str], code_text: str) -> List[IntelligentQuestion]:
        """Gera perguntas sobre validação de dados."""
        questions = []
        
        # Campos numéricos sem validação aparente
        pic_numeric_pattern = r'PIC\s+9+.*'
        numeric_fields = []
        for match in re.finditer(pic_numeric_pattern, code_text, re.IGNORECASE):
            line_num = code_text[:match.start()].count('\n') + 1
            # Extrai nome do campo (linha anterior ou mesma linha)
            field_name = self._extract_field_name(code_lines, line_num - 1)
            if field_name:
                numeric_fields.append((field_name, line_num))
        
        # Verifica se campos numéricos têm validação
        for field_name, line_num in numeric_fields:
            has_validation = self._has_field_validation(code_text, field_name)
            if not has_validation:
                template = self.question_templates['numeric_validation']
                questions.append(IntelligentQuestion(
                    question=template['template'].format(field=field_name, line=line_num),
                    category=template['category'],
                    priority=template['priority'],
                    context=code_lines[line_num - 1].strip(),
                    line_reference=line_num,
                    suggested_validation=template['validation'],
                    business_impact=template['impact']
                ))
        
        # Operações de data
        date_patterns = ['CURRENT-DATE', 'ACCEPT.*DATE', 'MOVE.*DATE']
        for pattern in date_patterns:
            for match in re.finditer(pattern, code_text, re.IGNORECASE):
                line_num = code_text[:match.start()].count('\n') + 1
                
                template = self.question_templates['date_validation']
                questions.append(IntelligentQuestion(
                    question=template['template'].format(line=line_num),
                    category=template['category'],
                    priority=template['priority'],
                    context=code_lines[line_num - 1].strip(),
                    line_reference=line_num,
                    suggested_validation=template['validation'],
                    business_impact=template['impact']
                ))
        
        return questions

    def _generate_error_handling_questions(self, code_lines: List[str], code_text: str) -> List[IntelligentQuestion]:
        """Gera perguntas sobre tratamento de erros."""
        questions = []
        
        # Operações de arquivo sem verificação de FILE-STATUS
        file_operations = ['OPEN', 'READ', 'WRITE', 'CLOSE']
        for operation in file_operations:
            pattern = rf'{operation}\s+([A-Z0-9-]+)'
            for match in re.finditer(pattern, code_text, re.IGNORECASE):
                line_num = code_text[:match.start()].count('\n') + 1
                file_name = match.group(1)
                
                # Verifica se há verificação de FILE-STATUS próxima
                has_status_check = self._has_file_status_check(code_lines, line_num - 1, file_name)
                if not has_status_check:
                    template = self.question_templates['file_status_check']
                    questions.append(IntelligentQuestion(
                        question=template['template'].format(file=file_name, line=line_num),
                        category=template['category'],
                        priority=template['priority'],
                        context=code_lines[line_num - 1].strip(),
                        line_reference=line_num,
                        suggested_validation=template['validation'],
                        business_impact=template['impact']
                    ))
        
        # Divisões sem verificação de zero
        divide_pattern = r'DIVIDE\s+([A-Z0-9-]+)\s+INTO\s+([A-Z0-9-]+)'
        for match in re.finditer(divide_pattern, code_text, re.IGNORECASE):
            line_num = code_text[:match.start()].count('\n') + 1
            divisor = match.group(1)
            
            questions.append(IntelligentQuestion(
                question=f"A divisão na linha {line_num} verifica se o divisor '{divisor}' é zero?",
                category=QuestionCategory.ERROR_HANDLING,
                priority='HIGH',
                context=code_lines[line_num - 1].strip(),
                line_reference=line_num,
                suggested_validation="Testar com divisor zero e implementar tratamento",
                business_impact="Divisão por zero causa abend do programa"
            ))
        
        return questions

    def _generate_performance_questions(self, code_lines: List[str], code_text: str) -> List[IntelligentQuestion]:
        """Gera perguntas sobre performance."""
        questions = []
        
        # PERFORM UNTIL loops
        perform_until_pattern = r'PERFORM\s+.*\s+UNTIL\s+(.*)'
        for match in re.finditer(perform_until_pattern, code_text, re.IGNORECASE):
            line_num = code_text[:match.start()].count('\n') + 1
            condition = match.group(1)
            
            template = self.question_templates['loop_termination']
            questions.append(IntelligentQuestion(
                question=template['template'].format(line=line_num),
                category=template['category'],
                priority=template['priority'],
                context=code_lines[line_num - 1].strip(),
                line_reference=line_num,
                suggested_validation=template['validation'],
                business_impact=template['impact']
            ))
        
        # OCCURS com tamanhos grandes
        occurs_pattern = r'OCCURS\s+(\d+)'
        for match in re.finditer(occurs_pattern, code_text, re.IGNORECASE):
            line_num = code_text[:match.start()].count('\n') + 1
            size = int(match.group(1))
            
            if size > 1000:  # Considera grande se > 1000 elementos
                template = self.question_templates['memory_usage']
                questions.append(IntelligentQuestion(
                    question=template['template'].format(size=size, line=line_num),
                    category=template['category'],
                    priority=template['priority'],
                    context=code_lines[line_num - 1].strip(),
                    line_reference=line_num,
                    suggested_validation=template['validation'],
                    business_impact=template['impact']
                ))
        
        # Operações de SORT em arquivos grandes
        if 'SORT' in code_text.upper():
            sort_matches = list(re.finditer(r'SORT\s+', code_text, re.IGNORECASE))
            for match in sort_matches:
                line_num = code_text[:match.start()].count('\n') + 1
                
                questions.append(IntelligentQuestion(
                    question=f"A operação SORT na linha {line_num} está otimizada para o volume de dados esperado? Há memória suficiente?",
                    category=QuestionCategory.PERFORMANCE,
                    priority='MEDIUM',
                    context=code_lines[line_num - 1].strip(),
                    line_reference=line_num,
                    suggested_validation="Testar com volume real e monitorar uso de recursos",
                    business_impact="SORT lento pode afetar janela de processamento"
                ))
        
        return questions

    def _generate_integration_questions(self, code_lines: List[str], code_text: str) -> List[IntelligentQuestion]:
        """Gera perguntas sobre integração."""
        questions = []
        
        # Chamadas externas
        call_pattern = r'CALL\s+[\'"]([A-Z0-9-]+)[\'"]'
        for match in re.finditer(call_pattern, code_text, re.IGNORECASE):
            line_num = code_text[:match.start()].count('\n') + 1
            program = match.group(1)
            
            template = self.question_templates['external_call']
            questions.append(IntelligentQuestion(
                question=template['template'].format(program=program, line=line_num),
                category=template['category'],
                priority=template['priority'],
                context=code_lines[line_num - 1].strip(),
                line_reference=line_num,
                suggested_validation=template['validation'],
                business_impact=template['impact']
            ))
        
        # SQL embarcado
        if 'EXEC SQL' in code_text.upper():
            sql_matches = list(re.finditer(r'EXEC\s+SQL', code_text, re.IGNORECASE))
            for match in sql_matches:
                line_num = code_text[:match.start()].count('\n') + 1
                
                questions.append(IntelligentQuestion(
                    question=f"A operação SQL na linha {line_num} trata adequadamente timeouts e falhas de conexão?",
                    category=QuestionCategory.INTEGRATION,
                    priority='HIGH',
                    context=code_lines[line_num - 1].strip(),
                    line_reference=line_num,
                    suggested_validation="Testar com banco indisponível e timeout",
                    business_impact="Falha de banco pode interromper processamento"
                ))
        
        return questions

    def _generate_maintenance_questions(self, code_lines: List[str], code_text: str, 
                                      analysis_results: Dict[str, Any] = None) -> List[IntelligentQuestion]:
        """Gera perguntas sobre manutenção."""
        questions = []
        
        # Código complexo sem comentários
        complex_sections = self._identify_complex_sections(code_lines)
        for section_start, section_end in complex_sections:
            has_comments = any(line.strip().startswith('*') 
                             for line in code_lines[section_start:section_end])
            
            if not has_comments:
                questions.append(IntelligentQuestion(
                    question=f"A seção complexa (linhas {section_start+1}-{section_end+1}) deveria ter mais comentários explicativos?",
                    category=QuestionCategory.MAINTENANCE,
                    priority='MEDIUM',
                    context=f"Seção de {section_end - section_start} linhas sem comentários",
                    line_reference=section_start + 1,
                    suggested_validation="Revisar com equipe de manutenção",
                    business_impact="Código sem documentação dificulta manutenção"
                ))
        
        # Hardcoded values
        hardcoded_pattern = r'(MOVE\s+[\'"]([^\'"]+)[\'"]|IF\s+.*=\s*[\'"]([^\'"]+)[\'"])'
        for match in re.finditer(hardcoded_pattern, code_text, re.IGNORECASE):
            line_num = code_text[:match.start()].count('\n') + 1
            value = match.group(2) or match.group(3)
            
            if value and len(value) > 2:  # Ignora valores muito pequenos
                questions.append(IntelligentQuestion(
                    question=f"O valor hardcoded '{value}' na linha {line_num} deveria ser parametrizável?",
                    category=QuestionCategory.MAINTENANCE,
                    priority='LOW',
                    context=code_lines[line_num - 1].strip(),
                    line_reference=line_num,
                    suggested_validation="Verificar se valor pode mudar no futuro",
                    business_impact="Valores fixos dificultam adaptação a mudanças"
                ))
        
        return questions

    def _generate_testing_questions(self, code_lines: List[str], code_text: str) -> List[IntelligentQuestion]:
        """Gera perguntas sobre testes."""
        questions = []
        
        # Paths de código raramente executados
        evaluate_matches = list(re.finditer(r'EVALUATE', code_text, re.IGNORECASE))
        for match in evaluate_matches:
            line_num = code_text[:match.start()].count('\n') + 1
            
            questions.append(IntelligentQuestion(
                question=f"Todos os caminhos do EVALUATE na linha {line_num} foram testados? Existe massa de dados para cada WHEN?",
                category=QuestionCategory.TESTING,
                priority='MEDIUM',
                context=code_lines[line_num - 1].strip(),
                line_reference=line_num,
                suggested_validation="Criar casos de teste para cada WHEN clause",
                business_impact="Caminhos não testados podem ter bugs em produção"
            ))
        
        # Tratamento de erros
        error_handling_lines = [i for i, line in enumerate(code_lines) 
                               if any(keyword in line.upper() 
                                     for keyword in ['FILE STATUS', 'INVALID KEY', 'AT END'])]
        
        for line_num in error_handling_lines:
            questions.append(IntelligentQuestion(
                question=f"O tratamento de erro na linha {line_num + 1} foi testado? Como simular esta condição de erro?",
                category=QuestionCategory.TESTING,
                priority='HIGH',
                context=code_lines[line_num].strip(),
                line_reference=line_num + 1,
                suggested_validation="Criar cenários que forcem a condição de erro",
                business_impact="Tratamento de erro não testado pode falhar em produção"
            ))
        
        return questions

    def _extract_evaluate_block(self, code_lines: List[str], start_line: int) -> str:
        """Extrai o bloco completo de um EVALUATE."""
        block_lines = []
        in_evaluate = False
        
        for i in range(start_line, min(start_line + 50, len(code_lines))):
            line = code_lines[i].strip().upper()
            
            if 'EVALUATE' in line:
                in_evaluate = True
            
            if in_evaluate:
                block_lines.append(line)
                
                if 'END-EVALUATE' in line:
                    break
        
        return '\n'.join(block_lines)

    def _extract_field_name(self, code_lines: List[str], line_num: int) -> str:
        """Extrai o nome do campo de uma linha de definição."""
        if line_num < 0 or line_num >= len(code_lines):
            return ""
        
        line = code_lines[line_num].strip()
        
        # Procura padrão: 05 FIELD-NAME PIC...
        field_match = re.match(r'\s*\d+\s+([A-Z0-9-]+)', line)
        if field_match:
            return field_match.group(1)
        
        return ""

    def _has_field_validation(self, code_text: str, field_name: str) -> bool:
        """Verifica se um campo tem validação no código."""
        validation_patterns = [
            rf'IF\s+{field_name}\s*(=|>|<|NOT)',
            rf'EVALUATE\s+{field_name}',
            rf'{field_name}\s*=\s*ZERO',
            rf'{field_name}\s*=\s*SPACES'
        ]
        
        for pattern in validation_patterns:
            if re.search(pattern, code_text, re.IGNORECASE):
                return True
        
        return False

    def _has_file_status_check(self, code_lines: List[str], operation_line: int, file_name: str) -> bool:
        """Verifica se há verificação de FILE-STATUS após operação de arquivo."""
        # Verifica nas próximas 5 linhas
        for i in range(operation_line + 1, min(operation_line + 6, len(code_lines))):
            line = code_lines[i].upper()
            if 'FILE STATUS' in line or f'{file_name}-STATUS' in line:
                return True
        
        return False

    def _identify_complex_sections(self, code_lines: List[str]) -> List[Tuple[int, int]]:
        """Identifica seções complexas do código."""
        complex_sections = []
        current_section_start = None
        complexity_score = 0
        
        for i, line in enumerate(code_lines):
            line_upper = line.strip().upper()
            
            # Inicia nova seção em parágrafos
            if re.match(r'^\s*[0-9]+-[A-Z0-9-]+\s*\.$', line_upper):
                if current_section_start is not None and complexity_score > 10:
                    complex_sections.append((current_section_start, i - 1))
                
                current_section_start = i
                complexity_score = 0
            
            # Conta elementos de complexidade
            complexity_keywords = ['IF', 'EVALUATE', 'PERFORM', 'COMPUTE', 'CALL']
            for keyword in complexity_keywords:
                if keyword in line_upper:
                    complexity_score += 1
        
        # Verifica última seção
        if current_section_start is not None and complexity_score > 10:
            complex_sections.append((current_section_start, len(code_lines) - 1))
        
        return complex_sections

    def _group_questions_by_category(self, questions: List[IntelligentQuestion]) -> Dict[str, List[IntelligentQuestion]]:
        """Agrupa perguntas por categoria."""
        grouped = {}
        
        for question in questions:
            category_name = question.category.value
            if category_name not in grouped:
                grouped[category_name] = []
            grouped[category_name].append(question)
        
        return grouped

    def _generate_question_statistics(self, questions: List[IntelligentQuestion]) -> Dict[str, Any]:
        """Gera estatísticas das perguntas."""
        total = len(questions)
        
        by_priority = {'HIGH': 0, 'MEDIUM': 0, 'LOW': 0}
        by_category = {}
        
        for question in questions:
            by_priority[question.priority] += 1
            
            category_name = question.category.value
            by_category[category_name] = by_category.get(category_name, 0) + 1
        
        return {
            "total_questions": total,
            "by_priority": by_priority,
            "by_category": by_category,
            "priority_percentages": {
                k: round(v / total * 100, 1) if total > 0 else 0 
                for k, v in by_priority.items()
            }
        }

    def _generate_suggested_agenda(self, questions: List[IntelligentQuestion]) -> List[Dict[str, Any]]:
        """Gera agenda sugerida para sessão de análise."""
        agenda = []
        
        # Agrupa por prioridade e categoria
        high_priority = [q for q in questions if q.priority == 'HIGH']
        medium_priority = [q for q in questions if q.priority == 'MEDIUM']
        
        # Fase 1: Questões críticas
        if high_priority:
            agenda.append({
                "phase": "Fase 1: Questões Críticas",
                "duration_minutes": len(high_priority) * 3,  # 3 min por pergunta
                "questions": len(high_priority),
                "focus": "Resolver questões que podem causar falhas em produção",
                "participants": ["Especialista COBOL", "Analista de Negócio"]
            })
        
        # Fase 2: Questões importantes
        if medium_priority:
            agenda.append({
                "phase": "Fase 2: Questões Importantes",
                "duration_minutes": len(medium_priority) * 2,  # 2 min por pergunta
                "questions": len(medium_priority),
                "focus": "Esclarecer lógica de negócio e validações",
                "participants": ["Especialista COBOL", "Analista de Negócio"]
            })
        
        # Fase 3: Questões de melhoria
        low_priority = [q for q in questions if q.priority == 'LOW']
        if low_priority:
            agenda.append({
                "phase": "Fase 3: Melhorias (Opcional)",
                "duration_minutes": len(low_priority) * 1,  # 1 min por pergunta
                "questions": len(low_priority),
                "focus": "Identificar oportunidades de melhoria",
                "participants": ["Especialista COBOL"]
            })
        
        return agenda

    def _estimate_session_time(self, questions: List[IntelligentQuestion]) -> Dict[str, int]:
        """Estima tempo necessário para sessão de análise."""
        high_count = len([q for q in questions if q.priority == 'HIGH'])
        medium_count = len([q for q in questions if q.priority == 'MEDIUM'])
        low_count = len([q for q in questions if q.priority == 'LOW'])
        
        # Tempos em minutos
        high_time = high_count * 3
        medium_time = medium_count * 2
        low_time = low_count * 1
        
        total_time = high_time + medium_time + low_time
        
        return {
            "high_priority_minutes": high_time,
            "medium_priority_minutes": medium_time,
            "low_priority_minutes": low_time,
            "total_minutes": total_time,
            "total_hours": round(total_time / 60, 1),
            "recommended_sessions": max(1, total_time // 120)  # Sessões de 2h
        }

    def generate_questions_report(self, questions_analysis: Dict[str, Any]) -> str:
        """Gera relatório de perguntas em formato Markdown."""
        program_name = questions_analysis["program_name"]
        questions = questions_analysis["questions"]
        statistics = questions_analysis["statistics"]
        agenda = questions_analysis["suggested_agenda"]
        time_estimate = questions_analysis["estimated_session_time"]
        
        report = [
            f"#  Perguntas Inteligentes - {program_name}",
            "",
            "##  Resumo Executivo",
            f"- **Total de Perguntas:** {statistics['total_questions']}",
            f"- **Prioridade ALTA:** {statistics['by_priority']['HIGH']} ({statistics['priority_percentages']['HIGH']}%)",
            f"- **Prioridade MÉDIA:** {statistics['by_priority']['MEDIUM']} ({statistics['priority_percentages']['MEDIUM']}%)",
            f"- **Prioridade BAIXA:** {statistics['by_priority']['LOW']} ({statistics['priority_percentages']['LOW']}%)",
            f"- **Tempo Estimado:** {time_estimate['total_hours']}h ({time_estimate['total_minutes']} minutos)",
            f"- **Sessões Recomendadas:** {time_estimate['recommended_sessions']}",
            "",
            "##  Agenda Sugerida",
            ""
        ]
        
        for phase in agenda:
            report.extend([
                f"### {phase['phase']}",
                f"- **Duração:** {phase['duration_minutes']} minutos",
                f"- **Perguntas:** {phase['questions']}",
                f"- **Foco:** {phase['focus']}",
                f"- **Participantes:** {', '.join(phase['participants'])}",
                ""
            ])
        
        report.extend([
            "## 🚨 Perguntas Prioritárias (ALTA)",
            ""
        ])
        
        high_priority_questions = [q for q in questions if q.priority == 'HIGH']
        for i, question in enumerate(high_priority_questions, 1):
            report.extend([
                f"### {i}. {question.question}",
                f"**Linha:** {question.line_reference}  ",
                f"**Contexto:** `{question.context}`  ",
                f"**Como Validar:** {question.suggested_validation}  ",
                f"**Impacto se Não Respondida:** {question.business_impact}  ",
                ""
            ])
        
        report.extend([
            "## ⚠️ Perguntas Importantes (MÉDIA)",
            ""
        ])
        
        medium_priority_questions = [q for q in questions if q.priority == 'MEDIUM']
        for i, question in enumerate(medium_priority_questions, 1):
            report.extend([
                f"### {i}. {question.question}",
                f"**Linha:** {question.line_reference}  ",
                f"**Como Validar:** {question.suggested_validation}  ",
                ""
            ])
        
        # Perguntas por categoria
        questions_by_category = questions_analysis["questions_by_category"]
        
        report.extend([
            "##  Perguntas por Categoria",
            ""
        ])
        
        category_names = {
            'business_logic': '🧠 Lógica de Negócio',
            'data_validation': ' Validação de Dados',
            'error_handling': '🚨 Tratamento de Erros',
            'performance': ' Performance',
            'integration': '🔗 Integração',
            'maintenance': ' Manutenção',
            'testing': '🧪 Testes'
        }
        
        for category, category_questions in questions_by_category.items():
            category_display = category_names.get(category, category.title())
            report.extend([
                f"### {category_display} ({len(category_questions)} perguntas)",
                ""
            ])
            
            for question in category_questions[:5]:  # Top 5 por categoria
                report.append(f"- **Linha {question.line_reference}:** {question.question}")
            
            if len(category_questions) > 5:
                report.append(f"- *... e mais {len(category_questions) - 5} perguntas*")
            
            report.append("")
        
        report.extend([
            "##  Dicas para Conduzir a Sessão",
            "",
            "### Preparação:",
            "1. **Revise o código** nas linhas mencionadas antes da sessão",
            "2. **Prepare ambiente** com código aberto e documentação disponível",
            "3. **Convide participantes certos** para cada fase",
            "",
            "### Durante a Sessão:",
            "1. **Comece pelas perguntas HIGH** - são as mais críticas",
            "2. **Documente respostas** diretamente no código ou wiki",
            "3. **Marque perguntas resolvidas** para acompanhar progresso",
            "4. **Faça pausas** a cada 30 minutos para manter foco",
            "",
            "### Após a Sessão:",
            "1. **Atualize documentação** com respostas obtidas",
            "2. **Crie tasks** para itens que precisam de investigação adicional",
            "3. **Agende sessões de follow-up** se necessário",
            "4. **Compartilhe conhecimento** com a equipe",
            ""
        ])
        
        return "\n".join(report)
