
import os
import requests
import httpx
import asyncio
import warnings
import logging
from typing import Dict, Any, Optional
from dotenv import load_dotenv
from .base_provider import BaseProvider

warnings.filterwarnings(action="ignore", message="Unverified HTTPS request is being made to host")
load_dotenv()

class LuziaProvider(BaseProvider):
    """Provider para LuzIA Corporativo - REST API simples."""

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        luzia_config = config.get('luzia', {})

        self.client_id = luzia_config.get('client_id', os.getenv('LUZIA_CLIENT_ID'))
        self.client_secret = luzia_config.get('client_secret', os.getenv('LUZIA_CLIENT_SECRET'))
        self.sso_endpoint = luzia_config.get('auth_url', 'https://login.azure.paas.santanderbr.pre.corp/auth/realms/corp/protocol/openid-connect/token')
        self.base_url = luzia_config.get('api_url', 'https://gut-api-aws.santanderbr.dev.corp/genai_services/v1/')
        self.model = luzia_config.get('model', 'azure-gpt-4o-mini')
        self.temperature = luzia_config.get('temperature', 0.1)
        self.timeout = luzia_config.get('timeout', 120.0)
        ssl_config = config.get("ssl", {})
        self.ssl_verify = ssl_config.get("verify", True)
        self.ssl_cert_path = ssl_config.get("cert_path")
        self.ssl_ca_bundle = ssl_config.get("ca_bundle")

        self.logger = self._setup_logging()
        self.last_error = None

    def _setup_logging(self) -> logging.Logger:
        logger = logging.getLogger('LuziaProvider')
        logger.setLevel(logging.INFO)
        if not logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
            handler.setFormatter(formatter)
            logger.addHandler(handler)
        return logger

    def _get_token(self) -> Optional[str]:
        request_body = {
            "grant_type": "client_credentials",
            "client_id": self.client_id,
            "client_secret": self.client_secret
        }
        headers = {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Accept': 'application/json'
        }
        try:
            verify_ssl = self.ssl_verify
            if self.ssl_cert_path:
                verify_ssl = self.ssl_cert_path
            elif self.ssl_ca_bundle:
                verify_ssl = self.ssl_ca_bundle

            token_body = requests.post(self.sso_endpoint, headers=headers, data=request_body, verify=verify_ssl)

            token_body.raise_for_status()
            return token_body.json().get("access_token")
        except requests.exceptions.RequestException as e:
            self.last_error = str(e)
            self.logger.error(f"Erro ao obter token: {self.last_error}")
            return None

    async def _submit(self, prompt: str, token: str) -> Dict[str, Any]:
        system_prompt = """Answer all questions in brazilian portuguese.
Answer code question with the code only, without using the brackets.
DON'T start the answer with the word 'python'."""

        payload = {
            "input": {
                "query": [
                    {
                        "role": "system",
                        "content": system_prompt
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                "config": [
                    {
                        "type": "catena.llm.LLMRouter",
                        "obj_kwargs": {
                            "routing_model": self.model,
                            "temperature": self.temperature
                        }
                    }
                ]
            }
        }

        headers = {
            "x-santander-client-id": self.client_id,
            "Authorization": f"Bearer {token}"
        }

        verify_ssl = self.ssl_verify
        if self.ssl_cert_path:
            verify_ssl = self.ssl_cert_path
        elif self.ssl_ca_bundle:
            verify_ssl = self.ssl_ca_bundle

        async with httpx.AsyncClient(verify=verify_ssl) as async_client:

            response = await async_client.post(
                url=f"{self.base_url}pipelines/submit",
                json=payload,
                headers=headers,
                timeout=self.timeout
            )
            response.raise_for_status()
            return response.json()

    def analyze(self, prompt: str, context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        # Log do prompt que será enviado
        self.logger.info("=" * 80)
        self.logger.info("PROMPT ENVIADO PARA LUZIA:")
        self.logger.info("=" * 80)
        self.logger.info(f"Modelo: {self.model}")
        self.logger.info(f"Temperatura: {self.temperature}")
        self.logger.info(f"Tamanho do prompt: {len(prompt)} caracteres")
        self.logger.info("-" * 80)
        self.logger.info("CONTEÚDO DO PROMPT:")
        self.logger.info("-" * 80)
        self.logger.info(prompt)
        self.logger.info("=" * 80)
        
        token = self._get_token()
        if not token:
            self.logger.error("Falha ao obter token de acesso LuzIA")
            return {
                'success': False,
                'content': 'Falha ao obter token de acesso.',
                'provider': 'luzia',
            }
        try:
            self.logger.info("Enviando requisição para LuzIA...")
            response_data = asyncio.run(self._submit(prompt, token))
            self.logger.info("Resposta recebida do LuzIA com sucesso")
            return {
                'success': True,
                'content': response_data, # Ajustar conforme a estrutura da resposta real
                'provider': 'luzia',
                'model': self.model,
            }
        except (httpx.HTTPStatusError, Exception) as e:
            self.last_error = str(e)
            self.logger.error(f"Erro na análise com LuzIA: {self.last_error}")
            return {
                'success': False,
                'content': f'Erro na chamada da API LuzIA: {self.last_error}',
                'provider': 'luzia',
            }

    def is_available(self) -> bool:
        """Verifica se o provedor está disponível."""
        token = self._get_token()
        return token is not None

    def get_status(self) -> Dict[str, Any]:
        token = self._get_token()
        return {
            'provider': 'luzia',
            'available': token is not None,
            'authenticated': token is not None,
            'model': self.model,
            'endpoint': self.base_url,
            'auth_endpoint': self.sso_endpoint,
            'status': 'ready' if token else 'auth_failed',
            'last_error': self.last_error
        }

