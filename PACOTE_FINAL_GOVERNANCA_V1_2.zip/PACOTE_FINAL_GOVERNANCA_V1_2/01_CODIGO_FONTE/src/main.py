"""
API de Governança de Dados V1.0
Desenvolvida por: Carlos Morais
Email: carlos.morais@f1rst.com.br
Organização: F1rst Technology Solutions

Uma solução enterprise completa para gestão, controle e monitoramento 
de dados em organizações modernas.
"""

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import uvicorn
import logging
from datetime import datetime

# Configuração de logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Importar controllers
try:
    from api.controllers import contracts, entities, quality
    from api.controllers import auth, audit, rate_limiting, system, metrics
    from api.controllers import domains, lineage, policies, stewardship
    from api.controllers import tags, analytics, discovery
    from api.controllers import workflows, notifications, integrations
    from api.controllers import security, performance
except ImportError as e:
    logger.warning(f"Alguns controllers não puderam ser importados: {e}")

# Importar middleware
try:
    from api.middleware import LoggingMiddleware
    from api.error_middleware import ErrorHandlingMiddleware
    from api.exception_handlers import setup_exception_handlers
except ImportError as e:
    logger.warning(f"Middleware não pôde ser importado: {e}")

# Criar aplicação FastAPI
app = FastAPI(
    title="API de Governança de Dados",
    description="""
    ## API de Governança de Dados V1.0
    
    **Desenvolvida por:** Carlos Morais  
    **Email:** carlos.morais@f1rst.com.br  
    **Organização:** F1rst Technology Solutions
    
    Uma solução enterprise completa para gestão, controle e monitoramento de dados.
    
    ### Funcionalidades Principais:
    - 🏢 Gestão de Domínios e Hierarquias
    - 📜 Contratos de Dados com Versionamento
    - 🔍 Descoberta e Catálogo Inteligente
    - 🛡️ Políticas e Compliance (LGPD/GDPR)
    - 📊 Qualidade de Dados e Métricas
    - 🔗 Lineage e Rastreabilidade
    - 👥 Stewardship e Responsabilidades
    - 🔔 Notificações Multi-canal
    - 🔄 Workflows e Aprovações
    - 🔗 Integrações Externas
    
    ### Compatibilidade:
    - DataMesh Manager
    - Unity Catalog
    - Databricks
    - Informatica Axon
    """,
    version="1.0.0",
    contact={
        "name": "Carlos Morais",
        "email": "carlos.morais@f1rst.com.br",
    },
    license_info={
        "name": "Proprietário",
        "url": "mailto:carlos.morais@f1rst.com.br",
    },
)

# Configurar CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Adicionar middleware personalizado
try:
    app.add_middleware(ErrorHandlingMiddleware)
    app.add_middleware(LoggingMiddleware)
except:
    logger.warning("Middleware personalizado não pôde ser adicionado")

# Configurar exception handlers
try:
    setup_exception_handlers(app)
except:
    logger.warning("Exception handlers não puderam ser configurados")

# Health check endpoint
@app.get("/health", tags=["System"])
async def health_check():
    """
    Health check endpoint para verificar status da API.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "version": "1.0.0",
        "author": "Carlos Morais",
        "email": "carlos.morais@f1rst.com.br",
        "organization": "F1rst Technology Solutions"
    }

# Root endpoint
@app.get("/", tags=["System"])
async def root():
    """
    Endpoint raiz da API de Governança de Dados.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    return {
        "message": "API de Governança de Dados V1.0",
        "author": "Carlos Morais",
        "email": "carlos.morais@f1rst.com.br",
        "organization": "F1rst Technology Solutions",
        "version": "1.0.0",
        "docs": "/docs",
        "redoc": "/redoc",
        "health": "/health"
    }

# Incluir routers dos controllers
try:
    # Core functionality
    app.include_router(contracts.router, prefix="/api/v1", tags=["Contracts"])
    app.include_router(entities.router, prefix="/api/v1", tags=["Entities"])
    app.include_router(quality.router, prefix="/api/v1", tags=["Quality"])
    
    # Governance
    app.include_router(domains.router, prefix="/api/v1", tags=["Domains"])
    app.include_router(policies.router, prefix="/api/v1", tags=["Policies"])
    app.include_router(stewardship.router, prefix="/api/v1", tags=["Stewardship"])
    
    # Discovery and Analytics
    app.include_router(discovery.router, prefix="/api/v1", tags=["Discovery"])
    app.include_router(analytics.router, prefix="/api/v1", tags=["Analytics"])
    app.include_router(lineage.router, prefix="/api/v1", tags=["Lineage"])
    
    # Operations
    app.include_router(workflows.router, prefix="/api/v1", tags=["Workflows"])
    app.include_router(notifications.router, prefix="/api/v1", tags=["Notifications"])
    app.include_router(integrations.router, prefix="/api/v1", tags=["Integrations"])
    
    # Security and Performance
    app.include_router(security.router, prefix="/api/v1", tags=["Security"])
    app.include_router(performance.router, prefix="/api/v1", tags=["Performance"])
    
    # System
    app.include_router(auth.router, prefix="/api/v1", tags=["Authentication"])
    app.include_router(audit.router, prefix="/api/v1", tags=["Audit"])
    app.include_router(system.router, prefix="/api/v1", tags=["System"])
    app.include_router(metrics.router, prefix="/api/v1", tags=["Metrics"])
    
    logger.info("Todos os routers foram incluídos com sucesso")
except Exception as e:
    logger.warning(f"Alguns routers não puderam ser incluídos: {e}")

# Middleware para adicionar headers de autor
@app.middleware("http")
async def add_author_headers(request: Request, call_next):
    """Adiciona headers com informações do autor"""
    response = await call_next(request)
    response.headers["X-Author"] = "Carlos Morais"
    response.headers["X-Author-Email"] = "carlos.morais@f1rst.com.br"
    response.headers["X-Organization"] = "F1rst Technology Solutions"
    response.headers["X-API-Version"] = "1.0.0"
    return response

if __name__ == "__main__":
    logger.info("Iniciando API de Governança de Dados V1.0")
    logger.info("Desenvolvida por: Carlos Morais (carlos.morais@f1rst.com.br)")
    
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )

