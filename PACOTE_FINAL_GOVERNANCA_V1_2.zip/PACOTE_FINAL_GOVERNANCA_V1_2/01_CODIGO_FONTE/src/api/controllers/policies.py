"""
Controller para Políticas e Compliance
"""

from typing import List, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status
from fastapi.responses import JSONResponse

from application.dtos.policies import (
    PolicyCreateDTO,
    PolicyUpdateDTO,
    PolicyResponseDTO,
    ComplianceReportDTO,
    ViolationCreateDTO,
    ViolationResponseDTO,
    RetentionPolicyDTO,
    AuditRequestDTO,
    AuditResultDTO,
    ComplianceFramework,
    PolicyType,
    ViolationSeverity,
)
from application.dtos import PaginatedResponse, PaginationParams
from application.services.policy_service import PolicyService
from domain.exceptions import BusinessRuleViolation, EntityNotFoundError
from api.dependencies import get_current_active_user, get_policy_service, validate_pagination

router = APIRouter(prefix="/api/v1/policies", tags=["Policies & Compliance"])


@router.post(
    "/",
    response_model=PolicyResponseDTO,
    status_code=status.HTTP_201_CREATED,
    summary="Criar política",
    description="Cria uma nova política de governança ou compliance"
)
async def create_policy(
    policy_data: PolicyCreateDTO,
    service: PolicyService = Depends(get_policy_service),
    current_user: dict = Depends(get_current_active_user)
) -> PolicyResponseDTO:
    """Cria uma nova política"""
    try:
        return await service.create_policy(policy_data, current_user["id"])
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get(
    "/",
    response_model=PaginatedResponse[PolicyResponseDTO],
    summary="Listar políticas",
    description="Lista todas as políticas com filtros e paginação"
)
async def list_policies(
    pagination: PaginationParams = Depends(validate_pagination),
    policy_type: Optional[PolicyType] = Query(None, description="Filtro por tipo"),
    framework: Optional[ComplianceFramework] = Query(None, description="Filtro por framework"),
    is_mandatory: Optional[bool] = Query(None, description="Filtro por obrigatório"),
    status: Optional[str] = Query(None, description="Filtro por status"),
    service: PolicyService = Depends(get_policy_service),
    current_user: dict = Depends(get_current_active_user)
) -> PaginatedResponse[PolicyResponseDTO]:
    """Lista políticas com filtros"""
    filters = {
        "policy_type": policy_type,
        "framework": framework,
        "is_mandatory": is_mandatory,
        "status": status
    }
    filters = {k: v for k, v in filters.items() if v is not None}
    
    return await service.list_policies(pagination, filters)


@router.get(
    "/{policy_id}",
    response_model=PolicyResponseDTO,
    summary="Buscar política",
    description="Busca uma política específica por ID"
)
async def get_policy(
    policy_id: UUID,
    service: PolicyService = Depends(get_policy_service),
    current_user: dict = Depends(get_current_active_user)
) -> PolicyResponseDTO:
    """Busca uma política específica"""
    try:
        return await service.get_policy(policy_id)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.put(
    "/{policy_id}",
    response_model=PolicyResponseDTO,
    summary="Atualizar política",
    description="Atualiza uma política existente"
)
async def update_policy(
    policy_id: UUID,
    policy_data: PolicyUpdateDTO,
    service: PolicyService = Depends(get_policy_service),
    current_user: dict = Depends(get_current_active_user)
) -> PolicyResponseDTO:
    """Atualiza uma política"""
    try:
        return await service.update_policy(policy_id, policy_data, current_user["id"])
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.delete(
    "/{policy_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Deletar política",
    description="Remove uma política do sistema"
)
async def delete_policy(
    policy_id: UUID,
    service: PolicyService = Depends(get_policy_service),
    current_user: dict = Depends(get_current_active_user)
):
    """Remove uma política"""
    try:
        await service.delete_policy(policy_id, current_user["id"])
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


# Compliance Endpoints
@router.get(
    "/compliance/lgpd",
    response_model=ComplianceReportDTO,
    summary="Status compliance LGPD",
    description="Retorna relatório de compliance com LGPD"
)
async def get_lgpd_compliance(
    service: PolicyService = Depends(get_policy_service),
    current_user: dict = Depends(get_current_active_user)
) -> ComplianceReportDTO:
    """Obtém status de compliance LGPD"""
    return await service.get_compliance_report(ComplianceFramework.LGPD)


@router.get(
    "/compliance/gdpr",
    response_model=ComplianceReportDTO,
    summary="Status compliance GDPR",
    description="Retorna relatório de compliance com GDPR"
)
async def get_gdpr_compliance(
    service: PolicyService = Depends(get_policy_service),
    current_user: dict = Depends(get_current_active_user)
) -> ComplianceReportDTO:
    """Obtém status de compliance GDPR"""
    return await service.get_compliance_report(ComplianceFramework.GDPR)


@router.post(
    "/compliance/audit",
    response_model=AuditResultDTO,
    summary="Executar auditoria",
    description="Executa auditoria de compliance com critérios específicos"
)
async def execute_audit(
    audit_request: AuditRequestDTO,
    service: PolicyService = Depends(get_policy_service),
    current_user: dict = Depends(get_current_active_user)
) -> AuditResultDTO:
    """Executa auditoria de compliance"""
    try:
        return await service.execute_audit(audit_request, current_user["id"])
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get(
    "/compliance/violations",
    response_model=PaginatedResponse[ViolationResponseDTO],
    summary="Violações identificadas",
    description="Lista violações de políticas identificadas"
)
async def get_violations(
    pagination: PaginationParams = Depends(validate_pagination),
    severity: Optional[ViolationSeverity] = Query(None, description="Filtro por severidade"),
    status: Optional[str] = Query(None, description="Filtro por status"),
    policy_id: Optional[UUID] = Query(None, description="Filtro por política"),
    entity_id: Optional[UUID] = Query(None, description="Filtro por entidade"),
    service: PolicyService = Depends(get_policy_service),
    current_user: dict = Depends(get_current_active_user)
) -> PaginatedResponse[ViolationResponseDTO]:
    """Lista violações com filtros"""
    filters = {
        "severity": severity,
        "status": status,
        "policy_id": policy_id,
        "entity_id": entity_id
    }
    filters = {k: v for k, v in filters.items() if v is not None}
    
    return await service.list_violations(pagination, filters)


# Retention Policies
@router.get(
    "/retention/policies",
    response_model=List[RetentionPolicyDTO],
    summary="Políticas de retenção",
    description="Lista políticas de retenção de dados"
)
async def get_retention_policies(
    entity_id: Optional[UUID] = Query(None, description="Filtro por entidade"),
    service: PolicyService = Depends(get_policy_service),
    current_user: dict = Depends(get_current_active_user)
) -> List[RetentionPolicyDTO]:
    """Lista políticas de retenção"""
    return await service.get_retention_policies(entity_id)


@router.post(
    "/retention/apply",
    response_model=dict,
    summary="Aplicar retenção",
    description="Aplica política de retenção a entidades específicas"
)
async def apply_retention(
    retention_policy: RetentionPolicyDTO,
    service: PolicyService = Depends(get_policy_service),
    current_user: dict = Depends(get_current_active_user)
) -> dict:
    """Aplica política de retenção"""
    try:
        result = await service.apply_retention_policy(retention_policy, current_user["id"])
        return {"message": "Retention policy applied successfully", "result": result}
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get(
    "/retention/schedule",
    response_model=List[dict],
    summary="Cronograma de retenção",
    description="Retorna cronograma de execução de políticas de retenção"
)
async def get_retention_schedule(
    days_ahead: int = Query(30, ge=1, le=365, description="Dias à frente"),
    service: PolicyService = Depends(get_policy_service),
    current_user: dict = Depends(get_current_active_user)
) -> List[dict]:
    """Obtém cronograma de retenção"""
    return await service.get_retention_schedule(days_ahead)


# Violation Management
@router.post(
    "/violations",
    response_model=ViolationResponseDTO,
    status_code=status.HTTP_201_CREATED,
    summary="Criar violação",
    description="Registra uma nova violação de política"
)
async def create_violation(
    violation_data: ViolationCreateDTO,
    service: PolicyService = Depends(get_policy_service),
    current_user: dict = Depends(get_current_active_user)
) -> ViolationResponseDTO:
    """Registra nova violação"""
    try:
        return await service.create_violation(violation_data, current_user["id"])
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get(
    "/violations/{violation_id}",
    response_model=ViolationResponseDTO,
    summary="Buscar violação",
    description="Busca uma violação específica por ID"
)
async def get_violation(
    violation_id: UUID,
    service: PolicyService = Depends(get_policy_service),
    current_user: dict = Depends(get_current_active_user)
) -> ViolationResponseDTO:
    """Busca violação específica"""
    try:
        return await service.get_violation(violation_id)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.put(
    "/violations/{violation_id}",
    response_model=ViolationResponseDTO,
    summary="Atualizar violação",
    description="Atualiza status ou informações de uma violação"
)
async def update_violation(
    violation_id: UUID,
    status_update: str = Query(..., description="Novo status"),
    resolution_notes: Optional[str] = Query(None, description="Notas de resolução"),
    assigned_to: Optional[str] = Query(None, description="Responsável"),
    service: PolicyService = Depends(get_policy_service),
    current_user: dict = Depends(get_current_active_user)
) -> ViolationResponseDTO:
    """Atualiza violação"""
    try:
        return await service.update_violation(
            violation_id, status_update, resolution_notes, assigned_to, current_user["id"]
        )
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

