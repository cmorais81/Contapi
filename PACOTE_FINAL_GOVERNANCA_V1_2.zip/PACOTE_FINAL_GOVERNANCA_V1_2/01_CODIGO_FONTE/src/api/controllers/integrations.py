"""
Controller para Integrações Externas
"""

from typing import List, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status
from fastapi.responses import JSONResponse

from application.dtos.integrations import (
    IntegrationConfigDTO,
    IntegrationResponseDTO,
    SyncJobDTO,
    SyncJobResponseDTO,
    WebhookConfigDTO,
    WebhookDeliveryDTO,
    ExternalSystemDTO,
    DataMappingDTO,
    IntegrationHealthDTO,
    IntegrationStatsDTO,
    APIConnectionTestDTO,
    APIConnectionTestResultDTO,
    IntegrationType,
    IntegrationStatus,
    SyncDirection,
    AuthenticationType,
)
from application.dtos import PaginatedResponse, PaginationParams
from application.services.integration_service import IntegrationService
from domain.exceptions import BusinessRuleViolation, EntityNotFoundError
from api.dependencies import get_current_active_user, get_integration_service, validate_pagination

router = APIRouter(prefix="/api/v1/integrations", tags=["External Integrations"])


# Integration Management
@router.post(
    "/",
    response_model=IntegrationResponseDTO,
    status_code=status.HTTP_201_CREATED,
    summary="Criar integração",
    description="Configura uma nova integração externa"
)
async def create_integration(
    integration: IntegrationConfigDTO,
    service: IntegrationService = Depends(get_integration_service),
    current_user: dict = Depends(get_current_active_user)
) -> IntegrationResponseDTO:
    """Cria nova integração"""
    try:
        return await service.create_integration(integration, current_user["id"])
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get(
    "/",
    response_model=PaginatedResponse[IntegrationResponseDTO],
    summary="Listar integrações",
    description="Lista integrações configuradas com filtros"
)
async def list_integrations(
    pagination: PaginationParams = Depends(validate_pagination),
    integration_type: Optional[IntegrationType] = Query(None, description="Filtro por tipo"),
    status: Optional[IntegrationStatus] = Query(None, description="Filtro por status"),
    sync_direction: Optional[SyncDirection] = Query(None, description="Filtro por direção"),
    is_active: Optional[bool] = Query(None, description="Filtro por ativo"),
    service: IntegrationService = Depends(get_integration_service),
    current_user: dict = Depends(get_current_active_user)
) -> PaginatedResponse[IntegrationResponseDTO]:
    """Lista integrações"""
    filters = {
        "integration_type": integration_type,
        "status": status,
        "sync_direction": sync_direction,
        "is_active": is_active
    }
    filters = {k: v for k, v in filters.items() if v is not None}
    
    return await service.list_integrations(pagination, filters)


@router.get(
    "/{integration_id}",
    response_model=IntegrationResponseDTO,
    summary="Buscar integração",
    description="Retorna detalhes de uma integração específica"
)
async def get_integration(
    integration_id: UUID,
    service: IntegrationService = Depends(get_integration_service),
    current_user: dict = Depends(get_current_active_user)
) -> IntegrationResponseDTO:
    """Busca integração específica"""
    try:
        return await service.get_integration(integration_id)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.put(
    "/{integration_id}",
    response_model=IntegrationResponseDTO,
    summary="Atualizar integração",
    description="Atualiza configuração de uma integração"
)
async def update_integration(
    integration_id: UUID,
    integration: IntegrationConfigDTO,
    service: IntegrationService = Depends(get_integration_service),
    current_user: dict = Depends(get_current_active_user)
) -> IntegrationResponseDTO:
    """Atualiza integração"""
    try:
        return await service.update_integration(integration_id, integration, current_user["id"])
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.delete(
    "/{integration_id}",
    response_model=dict,
    summary="Deletar integração",
    description="Remove uma integração configurada"
)
async def delete_integration(
    integration_id: UUID,
    service: IntegrationService = Depends(get_integration_service),
    current_user: dict = Depends(get_current_active_user)
) -> dict:
    """Deleta integração"""
    try:
        await service.delete_integration(integration_id, current_user["id"])
        return {"message": "Integration deleted successfully"}
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


# Synchronization Jobs
@router.post(
    "/{integration_id}/sync",
    response_model=SyncJobResponseDTO,
    summary="Iniciar sincronização",
    description="Inicia um job de sincronização manual"
)
async def start_sync_job(
    integration_id: UUID,
    sync_job: SyncJobDTO,
    service: IntegrationService = Depends(get_integration_service),
    current_user: dict = Depends(get_current_active_user)
) -> SyncJobResponseDTO:
    """Inicia job de sincronização"""
    try:
        sync_job.integration_id = integration_id
        return await service.start_sync_job(sync_job, current_user["id"])
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get(
    "/sync-jobs",
    response_model=PaginatedResponse[SyncJobResponseDTO],
    summary="Listar jobs de sincronização",
    description="Lista jobs de sincronização com filtros"
)
async def list_sync_jobs(
    pagination: PaginationParams = Depends(validate_pagination),
    integration_id: Optional[UUID] = Query(None, description="Filtro por integração"),
    status: Optional[str] = Query(None, description="Filtro por status"),
    sync_type: Optional[str] = Query(None, description="Filtro por tipo"),
    service: IntegrationService = Depends(get_integration_service),
    current_user: dict = Depends(get_current_active_user)
) -> PaginatedResponse[SyncJobResponseDTO]:
    """Lista jobs de sincronização"""
    filters = {
        "integration_id": integration_id,
        "status": status,
        "sync_type": sync_type
    }
    filters = {k: v for k, v in filters.items() if v is not None}
    
    return await service.list_sync_jobs(pagination, filters)


@router.get(
    "/sync-jobs/{job_id}",
    response_model=SyncJobResponseDTO,
    summary="Buscar job de sincronização",
    description="Retorna detalhes de um job específico"
)
async def get_sync_job(
    job_id: UUID,
    service: IntegrationService = Depends(get_integration_service),
    current_user: dict = Depends(get_current_active_user)
) -> SyncJobResponseDTO:
    """Busca job de sincronização"""
    try:
        return await service.get_sync_job(job_id)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.post(
    "/sync-jobs/{job_id}/cancel",
    response_model=dict,
    summary="Cancelar job",
    description="Cancela um job de sincronização em execução"
)
async def cancel_sync_job(
    job_id: UUID,
    service: IntegrationService = Depends(get_integration_service),
    current_user: dict = Depends(get_current_active_user)
) -> dict:
    """Cancela job de sincronização"""
    try:
        await service.cancel_sync_job(job_id, current_user["id"])
        return {"message": "Sync job cancelled successfully"}
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


# Webhooks
@router.post(
    "/webhooks",
    response_model=dict,
    status_code=status.HTTP_201_CREATED,
    summary="Criar webhook",
    description="Configura um webhook para eventos externos"
)
async def create_webhook(
    webhook: WebhookConfigDTO,
    service: IntegrationService = Depends(get_integration_service),
    current_user: dict = Depends(get_current_active_user)
) -> dict:
    """Cria webhook"""
    try:
        webhook_id = await service.create_webhook(webhook, current_user["id"])
        return {"message": "Webhook created successfully", "id": webhook_id}
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get(
    "/webhooks",
    response_model=List[dict],
    summary="Listar webhooks",
    description="Lista webhooks configurados"
)
async def list_webhooks(
    is_active: bool = Query(True, description="Filtro por ativo"),
    service: IntegrationService = Depends(get_integration_service),
    current_user: dict = Depends(get_current_active_user)
) -> List[dict]:
    """Lista webhooks"""
    filters = {"is_active": is_active}
    return await service.list_webhooks(filters)


@router.get(
    "/webhooks/{webhook_id}/deliveries",
    response_model=PaginatedResponse[WebhookDeliveryDTO],
    summary="Entregas do webhook",
    description="Lista entregas de um webhook específico"
)
async def list_webhook_deliveries(
    webhook_id: UUID,
    pagination: PaginationParams = Depends(validate_pagination),
    status: Optional[str] = Query(None, description="Filtro por status"),
    service: IntegrationService = Depends(get_integration_service),
    current_user: dict = Depends(get_current_active_user)
) -> PaginatedResponse[WebhookDeliveryDTO]:
    """Lista entregas do webhook"""
    try:
        filters = {"webhook_id": webhook_id, "status": status}
        filters = {k: v for k, v in filters.items() if v is not None}
        
        return await service.list_webhook_deliveries(pagination, filters)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


# External Systems
@router.post(
    "/external-systems",
    response_model=dict,
    status_code=status.HTTP_201_CREATED,
    summary="Registrar sistema externo",
    description="Registra um sistema externo no catálogo"
)
async def register_external_system(
    system: ExternalSystemDTO,
    service: IntegrationService = Depends(get_integration_service),
    current_user: dict = Depends(get_current_active_user)
) -> dict:
    """Registra sistema externo"""
    try:
        system_id = await service.register_external_system(system, current_user["id"])
        return {"message": "External system registered successfully", "id": system_id}
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get(
    "/external-systems",
    response_model=List[dict],
    summary="Listar sistemas externos",
    description="Lista sistemas externos registrados"
)
async def list_external_systems(
    system_type: Optional[str] = Query(None, description="Filtro por tipo"),
    is_active: bool = Query(True, description="Filtro por ativo"),
    service: IntegrationService = Depends(get_integration_service),
    current_user: dict = Depends(get_current_active_user)
) -> List[dict]:
    """Lista sistemas externos"""
    filters = {
        "system_type": system_type,
        "is_active": is_active
    }
    filters = {k: v for k, v in filters.items() if v is not None}
    
    return await service.list_external_systems(filters)


# Data Mappings
@router.post(
    "/data-mappings",
    response_model=dict,
    status_code=status.HTTP_201_CREATED,
    summary="Criar mapeamento de dados",
    description="Define mapeamento entre sistemas"
)
async def create_data_mapping(
    mapping: DataMappingDTO,
    service: IntegrationService = Depends(get_integration_service),
    current_user: dict = Depends(get_current_active_user)
) -> dict:
    """Cria mapeamento de dados"""
    try:
        mapping_id = await service.create_data_mapping(mapping, current_user["id"])
        return {"message": "Data mapping created successfully", "id": mapping_id}
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get(
    "/data-mappings",
    response_model=List[dict],
    summary="Listar mapeamentos",
    description="Lista mapeamentos de dados configurados"
)
async def list_data_mappings(
    source_system: Optional[str] = Query(None, description="Filtro por sistema origem"),
    target_system: Optional[str] = Query(None, description="Filtro por sistema destino"),
    is_active: bool = Query(True, description="Filtro por ativo"),
    service: IntegrationService = Depends(get_integration_service),
    current_user: dict = Depends(get_current_active_user)
) -> List[dict]:
    """Lista mapeamentos de dados"""
    filters = {
        "source_system": source_system,
        "target_system": target_system,
        "is_active": is_active
    }
    filters = {k: v for k, v in filters.items() if v is not None}
    
    return await service.list_data_mappings(filters)


# Health and Monitoring
@router.get(
    "/{integration_id}/health",
    response_model=IntegrationHealthDTO,
    summary="Verificar saúde da integração",
    description="Verifica status de saúde de uma integração"
)
async def check_integration_health(
    integration_id: UUID,
    service: IntegrationService = Depends(get_integration_service),
    current_user: dict = Depends(get_current_active_user)
) -> IntegrationHealthDTO:
    """Verifica saúde da integração"""
    try:
        return await service.check_integration_health(integration_id)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.get(
    "/{integration_id}/stats",
    response_model=IntegrationStatsDTO,
    summary="Estatísticas da integração",
    description="Retorna estatísticas de performance da integração"
)
async def get_integration_stats(
    integration_id: UUID,
    period_days: int = Query(30, ge=1, le=365, description="Período em dias"),
    service: IntegrationService = Depends(get_integration_service),
    current_user: dict = Depends(get_current_active_user)
) -> IntegrationStatsDTO:
    """Obtém estatísticas da integração"""
    try:
        return await service.get_integration_stats(integration_id, period_days)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


# Connection Testing
@router.post(
    "/test-connection",
    response_model=APIConnectionTestResultDTO,
    summary="Testar conexão",
    description="Testa conectividade com sistema externo"
)
async def test_api_connection(
    test_config: APIConnectionTestDTO,
    service: IntegrationService = Depends(get_integration_service),
    current_user: dict = Depends(get_current_active_user)
) -> APIConnectionTestResultDTO:
    """Testa conexão com API externa"""
    try:
        return await service.test_api_connection(test_config)
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

