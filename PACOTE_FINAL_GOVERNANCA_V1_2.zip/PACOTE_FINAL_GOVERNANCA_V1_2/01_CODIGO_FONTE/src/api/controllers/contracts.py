"""
Controller para contratos de dados
"""

from typing import Any, Dict, List, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status
from fastapi.responses import JSONResponse

from application.dtos import (
    DataContractCreateDTO,
    DataContractResponseDTO,
    DataContractUpdateDTO,
    DataContractVersionCreateDTO,
    DataContractVersionResponseDTO,
    PaginatedResponse,
    PaginationParams,
)
from application.services import DataContractService
from domain.exceptions import BusinessRuleViolation, EntityNotFoundError
from api.dependencies import get_current_active_user, get_data_contract_service, validate_pagination

router = APIRouter(prefix="/contracts", tags=["Data Contracts"])


@router.post(
    "/",
    response_model=DataContractResponseDTO,
    status_code=status.HTTP_201_CREATED,
    summary="Criar contrato de dados",
    description="Cria um novo contrato de dados no sistema"
)
async def create_contract(
    contract_data: DataContractCreateDTO,
    service: DataContractService = Depends(get_data_contract_service),
    current_user: dict = Depends(get_current_active_user)
) -> DataContractResponseDTO:
    """Cria um novo contrato de dados"""
    try:
        return await service.create_contract(contract_data, current_user["id"])
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.get(
    "/",
    response_model=PaginatedResponse,
    summary="Listar contratos de dados",
    description="Lista contratos de dados com paginação e filtros"
)
async def list_contracts(
    pagination: dict = Depends(validate_pagination),
    domain_id: Optional[UUID] = Query(None, description="Filtrar por domínio"),
    status: Optional[str] = Query(None, description="Filtrar por status"),
    steward_id: Optional[UUID] = Query(None, description="Filtrar por steward"),
    service: DataContractService = Depends(get_data_contract_service),
    current_user: dict = Depends(get_current_active_user)
) -> PaginatedResponse:
    """Lista contratos de dados"""
    
    # Construir filtros
    filters = {}
    if domain_id:
        filters["domain_id"] = domain_id
    if status:
        filters["status"] = status
    if steward_id:
        filters["steward_id"] = steward_id
    
    pagination_params = PaginationParams(**pagination)
    return await service.list_contracts(pagination_params, filters)


@router.get(
    "/{contract_id}",
    response_model=DataContractResponseDTO,
    summary="Buscar contrato de dados",
    description="Busca um contrato de dados específico por ID"
)
async def get_contract(
    contract_id: UUID,
    service: DataContractService = Depends(get_data_contract_service),
    current_user: dict = Depends(get_current_active_user)
) -> DataContractResponseDTO:
    """Busca um contrato de dados por ID"""
    try:
        return await service.get_contract(contract_id)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.put(
    "/{contract_id}",
    response_model=DataContractResponseDTO,
    summary="Atualizar contrato de dados",
    description="Atualiza um contrato de dados existente"
)
async def update_contract(
    contract_id: UUID,
    contract_data: DataContractUpdateDTO,
    service: DataContractService = Depends(get_data_contract_service),
    current_user: dict = Depends(get_current_active_user)
) -> DataContractResponseDTO:
    """Atualiza um contrato de dados"""
    try:
        return await service.update_contract(
            contract_id, 
            contract_data, 
            current_user["id"]
        )
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.delete(
    "/{contract_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Deletar contrato de dados",
    description="Remove um contrato de dados do sistema"
)
async def delete_contract(
    contract_id: UUID,
    service: DataContractService = Depends(get_data_contract_service),
    current_user: dict = Depends(get_current_active_user)
):
    """Remove um contrato de dados"""
    try:
        success = await service.delete_contract(contract_id)
        if not success:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Contract not found"
            )
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


# ========================================
# CONTRACT VERSIONS
# ========================================

@router.post(
    "/{contract_id}/versions",
    response_model=DataContractVersionResponseDTO,
    status_code=status.HTTP_201_CREATED,
    summary="Criar versão do contrato",
    description="Cria uma nova versão para um contrato de dados"
)
async def create_contract_version(
    contract_id: UUID,
    version_data: DataContractVersionCreateDTO,
    service: DataContractService = Depends(get_data_contract_service),
    current_user: dict = Depends(get_current_active_user)
) -> DataContractVersionResponseDTO:
    """Cria uma nova versão do contrato"""
    try:
        return await service.create_version(
            contract_id, 
            version_data, 
            current_user["id"]
        )
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.post(
    "/{contract_id}/versions/{version}/activate",
    response_model=DataContractVersionResponseDTO,
    summary="Ativar versão do contrato",
    description="Ativa uma versão específica do contrato"
)
async def activate_contract_version(
    contract_id: UUID,
    version: str,
    service: DataContractService = Depends(get_data_contract_service),
    current_user: dict = Depends(get_current_active_user)
) -> DataContractVersionResponseDTO:
    """Ativa uma versão específica do contrato"""
    try:
        return await service.activate_version(
            contract_id, 
            version, 
            current_user["id"]
        )
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get(
    "/{contract_id}/odcs",
    response_model=Dict[str, Any],
    summary="Exportar contrato ODCS",
    description="Exporta contrato no formato Open Data Contract Standard v3.0.2"
)
async def export_contract_odcs(
    contract_id: UUID,
    version: Optional[str] = Query(None, description="Versão específica (padrão: ativa)"),
    service: DataContractService = Depends(get_data_contract_service),
    current_user: dict = Depends(get_current_active_user)
) -> Dict[str, Any]:
    """Exporta contrato no formato ODCS"""
    try:
        return await service.export_odcs(contract_id, version)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.get(
    "/{contract_id}/odcs/{version}",
    response_model=Dict[str, Any],
    summary="Exportar versão específica ODCS",
    description="Exporta versão específica do contrato no formato ODCS v3.0.2"
)
async def export_contract_version_odcs(
    contract_id: UUID,
    version: str,
    service: DataContractService = Depends(get_data_contract_service),
    current_user: dict = Depends(get_current_active_user)
) -> Dict[str, Any]:
    """Exporta versão específica no formato ODCS"""
    try:
        return await service.export_odcs(contract_id, version)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.post(
    "/{contract_id}/validate",
    response_model=Dict[str, Any],
    summary="Validar contrato de dados",
    description="Valida um contrato de dados e sua conformidade com ODCS"
)
async def validate_contract(
    contract_id: UUID,
    version: Optional[str] = Query(None, description="Versão específica (padrão: ativa)"),
    service: DataContractService = Depends(get_data_contract_service),
    current_user: dict = Depends(get_current_active_user)
) -> Dict[str, Any]:
    """Valida um contrato de dados"""
    try:
        return await service.validate_contract(contract_id, version)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.get(
    "/{contract_id}/versions",
    response_model=List[DataContractVersionResponseDTO],
    summary="Listar versões do contrato",
    description="Lista todas as versões de um contrato de dados"
)
async def list_contract_versions(
    contract_id: UUID,
    service: DataContractService = Depends(get_data_contract_service),
    current_user: dict = Depends(get_current_active_user)
) -> List[DataContractVersionResponseDTO]:
    """Lista versões do contrato"""
    # Implementação futura - buscar versões do repositório
    return []


@router.get(
    "/{contract_id}/versions/{version}",
    response_model=DataContractVersionResponseDTO,
    summary="Buscar versão específica",
    description="Busca uma versão específica de um contrato de dados"
)
async def get_contract_version(
    contract_id: UUID,
    version: str,
    service: DataContractService = Depends(get_data_contract_service),
    current_user: dict = Depends(get_current_active_user)
) -> DataContractVersionResponseDTO:
    """Busca versão específica do contrato"""
    # Implementação futura - buscar versão específica
    raise HTTPException(
        status_code=status.HTTP_501_NOT_IMPLEMENTED,
        detail="Endpoint será implementado"
    )


@router.get(
    "/{contract_id}/diff/{version1}/{version2}",
    response_model=Dict[str, Any],
    summary="Comparar versões",
    description="Compara duas versões de um contrato de dados"
)
async def compare_contract_versions(
    contract_id: UUID,
    version1: str,
    version2: str,
    service: DataContractService = Depends(get_data_contract_service),
    current_user: dict = Depends(get_current_active_user)
) -> Dict[str, Any]:
    """Compara duas versões do contrato"""
    # Implementação futura - comparação de versões
    return {
        "contract_id": contract_id,
        "version1": version1,
        "version2": version2,
        "differences": [],
        "status": "not_implemented"
    }

