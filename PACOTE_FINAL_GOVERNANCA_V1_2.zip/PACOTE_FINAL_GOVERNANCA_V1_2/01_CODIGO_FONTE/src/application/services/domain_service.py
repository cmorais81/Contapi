"""
Service para Domínios de Negócio
"""

from typing import Dict, List, Optional
from uuid import UUID

from application.dtos.domains import (
    DomainCreateDTO,
    DomainResponseDTO,
    DomainUpdateDTO,
    DomainSearchDTO,
    DomainHierarchyDTO,
    DomainStatsDTO,
)
from application.dtos import PaginatedResponse, PaginationParams
from database.repositories.domain_repository import DomainRepository
from domain.entities.domain import Domain
from domain.exceptions import BusinessRuleViolation, EntityNotFoundError


class DomainService:
    """Service para operações de domínios"""

    def __init__(self, domain_repository: DomainRepository):
        self.domain_repository = domain_repository

    async def create_domain(self, domain_data: DomainCreateDTO, user_id: UUID) -> DomainResponseDTO:
        """Cria um novo domínio"""
        # Validar se nome é único
        existing = await self.domain_repository.get_by_name(domain_data.name)
        if existing:
            raise BusinessRuleViolation(f"Domain with name '{domain_data.name}' already exists")

        # Validar domínio pai se especificado
        if domain_data.parent_domain_id:
            parent = await self.domain_repository.get_by_id(domain_data.parent_domain_id)
            if not parent:
                raise EntityNotFoundError(f"Parent domain {domain_data.parent_domain_id} not found")
            if not parent.is_active:
                raise BusinessRuleViolation("Cannot create subdomain under inactive parent domain")

        # Criar entidade de domínio
        domain = Domain(
            name=domain_data.name,
            display_name=domain_data.display_name,
            description=domain_data.description,
            parent_domain_id=domain_data.parent_domain_id,
            domain_type=domain_data.domain_type,
            business_owner=domain_data.business_owner,
            technical_owner=domain_data.technical_owner,
            is_active=domain_data.is_active,
            created_by=user_id
        )

        # Salvar no repositório
        saved_domain = await self.domain_repository.create(domain)
        
        # Converter para DTO de resposta
        return await self._to_response_dto(saved_domain)

    async def get_domain(self, domain_id: UUID) -> DomainResponseDTO:
        """Busca um domínio por ID"""
        domain = await self.domain_repository.get_by_id(domain_id)
        if not domain:
            raise EntityNotFoundError(f"Domain {domain_id} not found")
        
        return await self._to_response_dto(domain)

    async def update_domain(self, domain_id: UUID, domain_data: DomainUpdateDTO, user_id: UUID) -> DomainResponseDTO:
        """Atualiza um domínio existente"""
        domain = await self.domain_repository.get_by_id(domain_id)
        if not domain:
            raise EntityNotFoundError(f"Domain {domain_id} not found")

        # Validar domínio pai se sendo alterado
        if domain_data.parent_domain_id is not None:
            if domain_data.parent_domain_id == domain_id:
                raise BusinessRuleViolation("Domain cannot be its own parent")
            
            if domain_data.parent_domain_id:
                parent = await self.domain_repository.get_by_id(domain_data.parent_domain_id)
                if not parent:
                    raise EntityNotFoundError(f"Parent domain {domain_data.parent_domain_id} not found")
                if not parent.is_active:
                    raise BusinessRuleViolation("Cannot set inactive domain as parent")

        # Atualizar campos
        update_data = domain_data.model_dump(exclude_unset=True)
        for field, value in update_data.items():
            setattr(domain, field, value)
        
        domain.updated_by = user_id

        # Salvar alterações
        updated_domain = await self.domain_repository.update(domain)
        
        return await self._to_response_dto(updated_domain)

    async def delete_domain(self, domain_id: UUID, user_id: UUID) -> None:
        """Remove um domínio (soft delete)"""
        domain = await self.domain_repository.get_by_id(domain_id)
        if not domain:
            raise EntityNotFoundError(f"Domain {domain_id} not found")

        # Verificar se tem subdomínios ativos
        children = await self.domain_repository.get_children(domain_id, include_inactive=False)
        if children:
            raise BusinessRuleViolation("Cannot delete domain with active subdomains")

        # Verificar se tem entidades ativas
        entity_count = await self.domain_repository.get_entity_count(domain_id, include_inactive=False)
        if entity_count > 0:
            raise BusinessRuleViolation("Cannot delete domain with active entities")

        # Soft delete
        domain.is_active = False
        domain.updated_by = user_id
        await self.domain_repository.update(domain)

    async def list_domains(self, pagination: PaginationParams, filters: Dict) -> PaginatedResponse[DomainResponseDTO]:
        """Lista domínios com filtros e paginação"""
        domains, total = await self.domain_repository.list_with_filters(pagination, filters)
        
        domain_dtos = []
        for domain in domains:
            domain_dtos.append(await self._to_response_dto(domain))
        
        return PaginatedResponse(
            items=domain_dtos,
            total=total,
            page=pagination.page,
            size=pagination.size,
            pages=(total + pagination.size - 1) // pagination.size
        )

    async def get_domain_children(self, domain_id: UUID, include_inactive: bool = False) -> List[DomainResponseDTO]:
        """Lista subdomínios de um domínio"""
        domain = await self.domain_repository.get_by_id(domain_id)
        if not domain:
            raise EntityNotFoundError(f"Domain {domain_id} not found")

        children = await self.domain_repository.get_children(domain_id, include_inactive)
        
        result = []
        for child in children:
            result.append(await self._to_response_dto(child))
        
        return result

    async def get_domain_entities(self, domain_id: UUID, pagination: PaginationParams, include_inactive: bool = False) -> PaginatedResponse:
        """Lista entidades de um domínio"""
        domain = await self.domain_repository.get_by_id(domain_id)
        if not domain:
            raise EntityNotFoundError(f"Domain {domain_id} not found")

        return await self.domain_repository.get_domain_entities(domain_id, pagination, include_inactive)

    async def search_domains(self, search_criteria: DomainSearchDTO, pagination: PaginationParams) -> PaginatedResponse[DomainResponseDTO]:
        """Busca avançada de domínios"""
        domains, total = await self.domain_repository.search(search_criteria, pagination)
        
        domain_dtos = []
        for domain in domains:
            domain_dtos.append(await self._to_response_dto(domain))
        
        return PaginatedResponse(
            items=domain_dtos,
            total=total,
            page=pagination.page,
            size=pagination.size,
            pages=(total + pagination.size - 1) // pagination.size
        )

    async def get_domain_hierarchy(self, domain_id: UUID, max_depth: int = 5) -> DomainHierarchyDTO:
        """Obtém hierarquia completa do domínio"""
        domain = await self.domain_repository.get_by_id(domain_id)
        if not domain:
            raise EntityNotFoundError(f"Domain {domain_id} not found")

        return await self._build_hierarchy(domain, max_depth)

    async def get_domain_stats(self, domain_id: UUID) -> DomainStatsDTO:
        """Obtém estatísticas do domínio"""
        domain = await self.domain_repository.get_by_id(domain_id)
        if not domain:
            raise EntityNotFoundError(f"Domain {domain_id} not found")

        stats = await self.domain_repository.get_domain_stats(domain_id)
        
        return DomainStatsDTO(
            total_entities=stats.get("total_entities", 0),
            total_contracts=stats.get("total_contracts", 0),
            total_quality_rules=stats.get("total_quality_rules", 0),
            quality_score=stats.get("quality_score", 0.0),
            compliance_score=stats.get("compliance_score", 0.0),
            last_updated=stats.get("last_updated")
        )

    async def get_domains_tree(self, include_inactive: bool = False) -> List[DomainHierarchyDTO]:
        """Obtém árvore completa de domínios"""
        root_domains = await self.domain_repository.get_root_domains(include_inactive)
        
        tree = []
        for domain in root_domains:
            tree.append(await self._build_hierarchy(domain, max_depth=10))
        
        return tree

    async def _to_response_dto(self, domain: Domain) -> DomainResponseDTO:
        """Converte entidade para DTO de resposta"""
        entity_count = await self.domain_repository.get_entity_count(domain.id)
        subdomain_count = await self.domain_repository.get_subdomain_count(domain.id)
        
        return DomainResponseDTO(
            id=domain.id,
            name=domain.name,
            display_name=domain.display_name,
            description=domain.description,
            parent_domain_id=domain.parent_domain_id,
            domain_type=domain.domain_type,
            business_owner=domain.business_owner,
            technical_owner=domain.technical_owner,
            is_active=domain.is_active,
            entity_count=entity_count,
            subdomain_count=subdomain_count,
            created_at=domain.created_at,
            updated_at=domain.updated_at
        )

    async def _build_hierarchy(self, domain: Domain, max_depth: int, current_depth: int = 0) -> DomainHierarchyDTO:
        """Constrói hierarquia recursiva do domínio"""
        entity_count = await self.domain_repository.get_entity_count(domain.id)
        
        hierarchy = DomainHierarchyDTO(
            id=domain.id,
            name=domain.name,
            display_name=domain.display_name,
            description=domain.description,
            domain_type=domain.domain_type,
            is_active=domain.is_active,
            entity_count=entity_count,
            children=[]
        )

        # Buscar filhos se não atingiu profundidade máxima
        if current_depth < max_depth:
            children = await self.domain_repository.get_children(domain.id, include_inactive=False)
            for child in children:
                child_hierarchy = await self._build_hierarchy(child, max_depth, current_depth + 1)
                hierarchy.children.append(child_hierarchy)

        return hierarchy

