"""
Application Layer - Casos de uso e serviços de aplicação
"""

