"""
DTOs para Políticas e Compliance
"""

from datetime import datetime
from enum import Enum
from typing import Dict, List, Optional
from uuid import UUID

from pydantic import BaseModel, Field


class PolicyType(str, Enum):
    """Tipo de política"""
    DATA_GOVERNANCE = "data_governance"
    DATA_QUALITY = "data_quality"
    DATA_PRIVACY = "data_privacy"
    DATA_RETENTION = "data_retention"
    DATA_ACCESS = "data_access"
    DATA_CLASSIFICATION = "data_classification"
    COMPLIANCE = "compliance"


class PolicyStatus(str, Enum):
    """Status da política"""
    DRAFT = "draft"
    ACTIVE = "active"
    INACTIVE = "inactive"
    DEPRECATED = "deprecated"


class ComplianceFramework(str, Enum):
    """Framework de compliance"""
    LGPD = "lgpd"
    GDPR = "gdpr"
    CCPA = "ccpa"
    HIPAA = "hipaa"
    SOX = "sox"
    PCI_DSS = "pci_dss"
    ISO_27001 = "iso_27001"


class ViolationSeverity(str, Enum):
    """Severidade da violação"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class PolicyCreateDTO(BaseModel):
    """DTO para criação de política"""
    name: str = Field(..., min_length=1, max_length=255)
    description: str = Field(..., min_length=1)
    policy_type: PolicyType
    compliance_frameworks: List[ComplianceFramework] = Field(default_factory=list)
    policy_rules: List[Dict] = Field(default_factory=list)
    applicable_domains: List[UUID] = Field(default_factory=list)
    applicable_entities: List[UUID] = Field(default_factory=list)
    enforcement_level: str = Field(default="warning")  # warning, blocking, audit
    is_mandatory: bool = Field(default=False)
    effective_date: Optional[datetime] = None
    expiration_date: Optional[datetime] = None
    owner: str = Field(..., description="Responsável pela política")
    approver: Optional[str] = None
    metadata: Dict = Field(default_factory=dict)

    class Config:
        json_schema_extra = {
            "example": {
                "name": "Customer Data Privacy Policy",
                "description": "Policy for handling customer personal data according to LGPD",
                "policy_type": "data_privacy",
                "compliance_frameworks": ["lgpd", "gdpr"],
                "policy_rules": [
                    {
                        "rule_id": "encrypt_pii",
                        "description": "All PII data must be encrypted",
                        "condition": "data_classification = 'PII'",
                        "action": "encrypt"
                    }
                ],
                "applicable_domains": [],
                "applicable_entities": [],
                "enforcement_level": "blocking",
                "is_mandatory": True,
                "effective_date": "2025-01-15T00:00:00Z",
                "owner": "privacy.officer@company.com",
                "metadata": {"regulation_reference": "LGPD Art. 46"}
            }
        }


class PolicyUpdateDTO(BaseModel):
    """DTO para atualização de política"""
    description: Optional[str] = None
    policy_rules: Optional[List[Dict]] = None
    applicable_domains: Optional[List[UUID]] = None
    applicable_entities: Optional[List[UUID]] = None
    enforcement_level: Optional[str] = None
    is_mandatory: Optional[bool] = None
    effective_date: Optional[datetime] = None
    expiration_date: Optional[datetime] = None
    owner: Optional[str] = None
    approver: Optional[str] = None
    status: Optional[PolicyStatus] = None
    metadata: Optional[Dict] = None


class PolicyResponseDTO(BaseModel):
    """DTO para resposta de política"""
    id: UUID
    name: str
    description: str
    policy_type: PolicyType
    compliance_frameworks: List[ComplianceFramework]
    policy_rules: List[Dict]
    applicable_domains: List[UUID]
    applicable_entities: List[UUID]
    enforcement_level: str
    is_mandatory: bool
    status: PolicyStatus
    effective_date: Optional[datetime]
    expiration_date: Optional[datetime]
    owner: str
    approver: Optional[str]
    violation_count: int = Field(default=0)
    compliance_score: float = Field(default=100.0, ge=0, le=100)
    last_evaluated: Optional[datetime] = None
    metadata: Dict
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class ComplianceReportDTO(BaseModel):
    """DTO para relatório de compliance"""
    framework: ComplianceFramework
    overall_score: float = Field(ge=0, le=100)
    total_policies: int
    compliant_policies: int
    non_compliant_policies: int
    total_violations: int
    critical_violations: int
    high_violations: int
    medium_violations: int
    low_violations: int
    entities_covered: int
    entities_not_covered: int
    coverage_percentage: float = Field(ge=0, le=100)
    last_assessment: datetime
    next_assessment: Optional[datetime] = None
    recommendations: List[str] = Field(default_factory=list)

    class Config:
        json_schema_extra = {
            "example": {
                "framework": "lgpd",
                "overall_score": 87.5,
                "total_policies": 25,
                "compliant_policies": 22,
                "non_compliant_policies": 3,
                "total_violations": 15,
                "critical_violations": 1,
                "high_violations": 3,
                "medium_violations": 7,
                "low_violations": 4,
                "entities_covered": 180,
                "entities_not_covered": 20,
                "coverage_percentage": 90.0,
                "last_assessment": "2025-01-14T10:00:00Z",
                "recommendations": [
                    "Implement encryption for PII data",
                    "Update data retention policies",
                    "Enhance access controls"
                ]
            }
        }


class ViolationCreateDTO(BaseModel):
    """DTO para criação de violação"""
    policy_id: UUID
    entity_id: UUID
    violation_type: str
    severity: ViolationSeverity
    description: str
    detected_by: str  # system, user, audit
    detection_method: str
    evidence: Dict = Field(default_factory=dict)
    affected_records: Optional[int] = None
    business_impact: Optional[str] = None

    class Config:
        json_schema_extra = {
            "example": {
                "policy_id": "123e4567-e89b-12d3-a456-426614174000",
                "entity_id": "456e7890-e89b-12d3-a456-426614174000",
                "violation_type": "unencrypted_pii",
                "severity": "high",
                "description": "PII data found without encryption",
                "detected_by": "system",
                "detection_method": "automated_scan",
                "evidence": {"column": "customer_ssn", "encryption": False},
                "affected_records": 1500,
                "business_impact": "Potential LGPD violation"
            }
        }


class ViolationResponseDTO(BaseModel):
    """DTO para resposta de violação"""
    id: UUID
    policy_id: UUID
    policy_name: str
    entity_id: UUID
    entity_name: str
    violation_type: str
    severity: ViolationSeverity
    description: str
    status: str  # open, investigating, resolved, false_positive
    detected_by: str
    detection_method: str
    evidence: Dict
    affected_records: Optional[int]
    business_impact: Optional[str]
    assigned_to: Optional[str] = None
    resolution_notes: Optional[str] = None
    resolved_at: Optional[datetime] = None
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class RetentionPolicyDTO(BaseModel):
    """DTO para política de retenção"""
    entity_id: UUID
    retention_period_days: int = Field(gt=0)
    retention_criteria: Dict
    deletion_method: str  # soft_delete, hard_delete, archive
    legal_hold_exemption: bool = Field(default=False)
    business_justification: str
    approval_required: bool = Field(default=True)
    auto_execution: bool = Field(default=False)
    notification_before_days: int = Field(default=30, ge=0)

    class Config:
        json_schema_extra = {
            "example": {
                "entity_id": "123e4567-e89b-12d3-a456-426614174000",
                "retention_period_days": 2555,  # 7 anos
                "retention_criteria": {
                    "data_type": "customer_transaction",
                    "regulatory_requirement": "LGPD Art. 16"
                },
                "deletion_method": "archive",
                "legal_hold_exemption": False,
                "business_justification": "Legal requirement for financial records",
                "approval_required": True,
                "auto_execution": False,
                "notification_before_days": 90
            }
        }


class AuditRequestDTO(BaseModel):
    """DTO para solicitação de auditoria"""
    audit_type: str  # compliance, policy, data_quality, access
    scope: str  # domain, entity, system, full
    target_ids: List[UUID] = Field(default_factory=list)
    compliance_frameworks: List[ComplianceFramework] = Field(default_factory=list)
    audit_criteria: Dict = Field(default_factory=dict)
    include_recommendations: bool = Field(default=True)
    detailed_report: bool = Field(default=True)

    class Config:
        json_schema_extra = {
            "example": {
                "audit_type": "compliance",
                "scope": "domain",
                "target_ids": ["123e4567-e89b-12d3-a456-426614174000"],
                "compliance_frameworks": ["lgpd", "gdpr"],
                "audit_criteria": {
                    "check_encryption": True,
                    "check_access_controls": True,
                    "check_data_retention": True
                },
                "include_recommendations": True,
                "detailed_report": True
            }
        }


class AuditResultDTO(BaseModel):
    """DTO para resultado de auditoria"""
    audit_id: UUID
    audit_type: str
    scope: str
    overall_score: float = Field(ge=0, le=100)
    total_checks: int
    passed_checks: int
    failed_checks: int
    warnings: int
    findings: List[Dict]
    recommendations: List[str]
    compliance_status: Dict[str, str]  # framework -> status
    execution_time_ms: int
    audited_entities: List[UUID]
    created_at: datetime

    class Config:
        json_schema_extra = {
            "example": {
                "audit_id": "123e4567-e89b-12d3-a456-426614174000",
                "audit_type": "compliance",
                "scope": "domain",
                "overall_score": 85.5,
                "total_checks": 50,
                "passed_checks": 42,
                "failed_checks": 6,
                "warnings": 2,
                "findings": [
                    {
                        "check": "encryption_check",
                        "status": "failed",
                        "entity": "customer_table",
                        "details": "PII columns not encrypted"
                    }
                ],
                "recommendations": [
                    "Implement column-level encryption",
                    "Update access control policies"
                ],
                "compliance_status": {
                    "lgpd": "partial_compliance",
                    "gdpr": "compliant"
                },
                "execution_time_ms": 5500,
                "audited_entities": [],
                "created_at": "2025-01-14T10:00:00Z"
            }
        }

