


# COBOL AI Engine v1.0.1

Sistema completo de análise de programas COBOL com Inteligência Artificial, oferecendo suporte a múltiplos modelos de IA, análise comparativa e transparência total do processo.

## Características Principais

**Análise Multi-Modelo**: Execute análises com múltiplos modelos de IA simultaneamente para maior confiabilidade e comparação de resultados.

**Transparência Total**: Todos os prompts utilizados são salvos junto com as análises, garantindo auditabilidade e reprodutibilidade.

**Configuração Flexível**: Sistema totalmente configurável através de arquivos YAML, permitindo personalização completa dos modelos e parâmetros.

**Análise Profunda**: Interpretação avançada de comentários, regras de negócio, estruturas de dados e fluxos lógicos dos programas COBOL.

**Suporte a Copybooks**: Análise integrada de copybooks (BOOKS.txt) para contexto completo das estruturas de dados.

## Instalação

### Requisitos
- Python 3.11 ou superior
- Chave de API da LuzIA (ou outros provedores configurados)

### Passos de Instalação
```bash
# 1. Extrair o pacote
tar -xzf cobol_ai_engine_v1.0.1.tar.gz
cd cobol_ai_engine_v1.0.1/

# 2. Instalar dependências
pip install -r requirements.txt

# 3. Configurar variáveis de ambiente
export LUZIA_API_KEY="sua_chave_luzia_aqui"

# 4. Teste rápido
python main.py examples/fontes.txt
```

## Uso Básico

### Análise com Modelo Único
```bash
python main.py examples/fontes.txt --models "claude_3_5_sonnet"
```

### Análise Multi-Modelo
```bash
python main.py examples/fontes.txt --models '["claude_3_5_sonnet","luzia_standard"]'
```

### Análise Completa com Copybooks
```bash
python main.py examples/fontes.txt --books examples/BOOKS.txt --models '["claude_3_5_sonnet","luzia_standard"]' --pdf
```

### Usando Configuração Padrão
```bash
# Os modelos são definidos em config/config.yaml
python main.py examples/fontes.txt
```

## Configuração

### Arquivo Principal: config/config.yaml

```yaml
ai:
  default_models:
    - "claude_3_5_sonnet"
    - "luzia_standard"

providers:
  luzia:
    enabled: true
    endpoint: "https://api.luzia.com/v1/chat/completions"
    models:
      claude_3_5_sonnet:
        name: "claude-3-5-sonnet-20241022"
        max_tokens: 8192
        temperature: 0.1
```

### Variáveis de Ambiente

```bash
# LuzIA
export LUZIA_API_KEY="sua_chave_luzia"

# OpenAI (opcional)
export OPENAI_API_KEY="sua_chave_openai"
```

## Estrutura de Saída

### Modelo Único
```
output/
├── PROGRAMA1.md
├── PROGRAMA2.md
└── relatorio_consolidado.md
```

### Múltiplos Modelos
```
output/
├── model_claude_3_5_sonnet/
│   ├── PROGRAMA1.md
│   └── PROGRAMA2.md
├── model_luzia_standard/
│   ├── PROGRAMA1.md
│   └── PROGRAMA2.md
└── relatorio_comparativo_modelos.md
```

## Transparência e Auditoria

Cada relatório gerado inclui uma seção completa de transparência com:

- **Prompt Original**: O prompt exato enviado para a IA
- **Prompt de Sistema**: Instruções de contexto utilizadas
- **Metadados**: Informações sobre modelo, tokens, timestamp
- **Contexto**: Dados sobre copybooks e pré-análise incluídos
- **Estratégia**: Técnicas de engenharia de prompt aplicadas

## Modelos Suportados

| Modelo | Provedor | Descrição |
|--------|----------|-----------|
| claude_3_5_sonnet | LuzIA | Análises técnicas profundas |
| luzia_standard | LuzIA | Análises balanceadas |
| openai_gpt4 | OpenAI | Análises alternativas |
| mock_enhanced | Mock | Testes e desenvolvimento |

## Parâmetros da Linha de Comando

```
python main.py <fontes> [opções]

Argumentos:
  fontes                    Arquivo de fontes COBOL (obrigatório)

Opções:
  --books BOOKS            Arquivo de copybooks (opcional)
  --output OUTPUT          Diretório de saída (padrão: output)
  --config CONFIG          Arquivo de configuração (padrão: config/config.yaml)
  --models MODELS          Modelo(s) a usar (padrão: configuração)
  --pdf                    Converter para PDF
  --log LEVEL              Nível de log (DEBUG, INFO, WARNING, ERROR)
```

## Exemplos de Uso

### Desenvolvimento e Testes
```bash
# Teste rápido com modelo mock
python main.py examples/fontes.txt --models "mock_enhanced"

# Análise de desenvolvimento
python main.py fontes.txt --models '["mock_enhanced","luzia_standard"]' --output dev_analysis
```

### Produção
```bash
# Análise de produção completa
python main.py fontes_producao.txt \
  --books books_producao.txt \
  --models '["claude_3_5_sonnet","luzia_standard"]' \
  --output analise_producao \
  --pdf

# Análise crítica com múltiplos modelos
python main.py fontes_criticos.txt \
  --books books_criticos.txt \
  --models '["claude_3_5_sonnet","luzia_standard","openai_gpt4"]' \
  --output analise_critica
```

## Relatório Comparativo

Quando múltiplos modelos são utilizados, o sistema gera automaticamente um relatório comparativo incluindo:

- **Estatísticas por Modelo**: Taxa de sucesso, tokens médios, qualidade
- **Análise por Programa**: Comparação lado a lado dos resultados
- **Recomendações**: Melhor modelo para cada cenário
- **Métricas de Performance**: Tempo de processamento e eficiência

## Solução de Problemas

### Erro de Autenticação
```
Erro: 401 Unauthorized
```
**Solução**: Verifique se a variável LUZIA_API_KEY está configurada corretamente.

### Modelo Não Encontrado
```
Erro: Modelo 'xyz' não encontrado
```
**Solução**: Verifique se o modelo está configurado em config/config.yaml.

### Arquivo Não Encontrado
```
Erro: Arquivo 'fontes.txt' não encontrado
```
**Solução**: Verifique o caminho do arquivo e se ele existe.

## Logs e Monitoramento

O sistema gera logs detalhados em `logs/cobol_ai_engine_YYYYMMDD_HHMMSS.log` incluindo:

- Progresso das análises
- Estatísticas de tokens
- Erros e avisos
- Métricas de performance

## Estrutura do Projeto

```
cobol_ai_engine_v1.0.1/
├── main.py                 # Script principal unificado
├── config/
│   └── config.yaml        # Configuração principal
├── src/                   # Código fonte
├── examples/              # Arquivos de exemplo
├── logs/                  # Logs do sistema
├── requirements.txt       # Dependências Python
├── VERSION               # Versão atual
└── README.md             # Este arquivo
```

## Compatibilidade

- **Python**: 3.11+
- **Sistemas Operacionais**: Windows, Linux, macOS
- **Provedores de IA**: LuzIA, OpenAI, outros compatíveis
- **Formatos de Entrada**: TXT, CBL, COB, COBOL

## Licença

Este software é fornecido "como está", sem garantias de qualquer tipo. Use por sua própria conta e risco.

---

**Versão**: 1.0.1  
**Data**: 21 de Setembro de 2025  
**Compatibilidade**: Python 3.11+


