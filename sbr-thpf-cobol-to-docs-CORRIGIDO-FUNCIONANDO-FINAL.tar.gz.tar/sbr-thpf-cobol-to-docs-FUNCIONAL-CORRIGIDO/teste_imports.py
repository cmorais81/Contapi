#!/usr/bin/env python3
"""
Teste simples para validar que os imports funcionam
"""

import sys
import os

# Adicionar src ao path
script_dir = os.path.dirname(os.path.abspath(__file__))
cobol_to_docs_dir = os.path.dirname(script_dir)
src_dir = os.path.join(cobol_to_docs_dir, 'src')
sys.path.insert(0, src_dir)

print("🧪 TESTANDO IMPORTS...")

try:
    from core.config import ConfigManager
    print("✅ ConfigManager importado")
    
    from generators.documentation_generator import DocumentationGenerator
    print("✅ DocumentationGenerator importado")
    
    from providers.enhanced_mock_provider import EnhancedMockProvider
    print("✅ EnhancedMockProvider importado")
    
    print("\n🎉 TODOS OS IMPORTS FUNCIONANDO!")
    
except ImportError as e:
    print(f"❌ Erro de import: {e}")
    import traceback
    traceback.print_exc()
