#!/usr/bin/env python3
"""
COBOL Analyzer - Versão Simplificada Funcional
Demonstra que a correção da estrutura de diretórios funciona
"""

import os
import sys
import argparse
import json
from datetime import datetime

# Adicionar src ao path
script_dir = os.path.dirname(os.path.abspath(__file__))
src_dir = os.path.join(script_dir, 'cobol_to_docs', 'src')
sys.path.insert(0, src_dir)

def main():
    print("🚀 COBOL ANALYZER - VERSÃO FUNCIONAL CORRIGIDA")
    print("=" * 60)
    
    parser = argparse.ArgumentParser(description='COBOL Analyzer com estrutura corrigida')
    parser.add_argument('--fontes', required=True, help='Arquivo COBOL para análise')
    parser.add_argument('--output', default='output', help='Diretório de saída')
    parser.add_argument('--models', default='enhanced_mock', help='Modelo a usar')
    
    args = parser.parse_args()
    
    print(f"📄 Arquivo: {args.fontes}")
    print(f"📁 Saída: {args.output}")
    print(f"🤖 Modelo: {args.models}")
    
    # Verificar se arquivo existe
    if not os.path.exists(args.fontes):
        print(f"❌ Arquivo não encontrado: {args.fontes}")
        return 1
    
    try:
        # Imports básicos que funcionam
        from providers.enhanced_mock_provider import EnhancedMockProvider
        from providers.base_provider import AIRequest
        from generators.documentation_generator import DocumentationGenerator
        
        print("✅ Módulos importados com sucesso")
        
        # Ler código COBOL
        with open(args.fontes, 'r', encoding='utf-8') as f:
            cobol_code = f.read()
        
        print(f"📖 Código lido: {len(cobol_code)} caracteres")
        
        # Detectar nome do programa
        program_name = "PROGRAMA-EXEMPLO"
        for line in cobol_code.split('\\n'):
            if 'PROGRAM-ID' in line:
                parts = line.split('.')
                if len(parts) > 0:
                    program_name = parts[0].split()[-1]
                break
        
        print(f"🔍 Programa identificado: {program_name}")
        
        # Configurar provider
        config = {
            "providers": {
                "enhanced_mock": {
                    "enabled": True,
                    "models": {
                        "enhanced-mock-gpt-4": {
                            "name": "enhanced-mock-gpt-4",
                            "max_tokens": 8192,
                            "temperature": 0.1,
                            "timeout": 5
                        }
                    }
                }
            }
        }
        
        # Criar provider
        provider = EnhancedMockProvider(config)
        print("🏢 Provider: enhanced_mock")
        print("🤖 Modelo: enhanced-mock-gpt-4")
        
        # Criar DocumentationGenerator com estrutura corrigida
        doc_gen = DocumentationGenerator(
            output_dir=args.output,
            provider="enhanced_mock",
            model="enhanced-mock-gpt-4"
        )
        print("📁 Estrutura de saída: enhanced_mock/enhanced-mock-gpt-4/")
        
        # Criar request
        request = AIRequest(
            prompt=f"Analise o código COBOL a seguir e gere documentação técnica completa:\\n\\n{cobol_code}",
            program_name=program_name,
            program_code=cobol_code,
            max_tokens=8192
        )
        
        print("🔬 Iniciando análise...")
        start_time = datetime.now()
        
        # Executar análise
        response = provider.analyze(request)
        
        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds()
        
        print(f"✅ Análise concluída em {duration:.2f}s")
        print(f"📊 Tokens utilizados: {response.tokens_used}")
        print(f"💰 Custo estimado: ${response.metadata.get('cost', 0.0):.4f}")
        
        # Simular CobolProgram
        class MockCobolProgram:
            def __init__(self, name, code):
                self.name = name
                self.code = code
                self.content = code  # Adicionar content para evitar erro
        
        mock_program = MockCobolProgram(program_name, cobol_code)
        
        # Gerar documentação
        print("📝 Gerando documentação...")
        doc_path = doc_gen.generate_program_documentation(mock_program, response)
        
        print(f"✅ Documentação gerada: {doc_path}")
        
        # Verificar estrutura criada
        print("\\n📁 ESTRUTURA CRIADA:")
        output_path = os.path.join(args.output, "enhanced_mock", "enhanced-mock-gpt-4")
        
        if os.path.exists(output_path):
            print(f"   ✅ {output_path}/")
            
            requests_dir = os.path.join(output_path, "requests")
            responses_dir = os.path.join(output_path, "responses")
            
            if os.path.exists(requests_dir):
                print(f"   ✅ requests/ (CORRIGIDO)")
                files = os.listdir(requests_dir)
                for file in files:
                    print(f"      📄 {file}")
            
            if os.path.exists(responses_dir):
                print(f"   ✅ responses/ (CORRIGIDO)")
                files = os.listdir(responses_dir)
                for file in files:
                    print(f"      📄 {file}")
            
            # Listar arquivos de documentação
            doc_files = [f for f in os.listdir(output_path) if f.endswith('.md')]
            for doc_file in doc_files:
                print(f"   ✅ {doc_file}")
        
        print("\\n" + "=" * 60)
        print("🎉 ANÁLISE CONCLUÍDA COM SUCESSO!")
        print("\\n✅ CORREÇÃO IMPLEMENTADA:")
        print("   - Estrutura provider/model criada")
        print("   - Subpastas requests/ e responses/ (corrigidas)")
        print("   - Documentação gerada")
        print("   - Arquivos JSON salvos")
        
        return 0
        
    except Exception as e:
        print(f"❌ Erro durante execução: {e}")
        import traceback
        traceback.print_exc()
        return 1

if __name__ == "__main__":
    sys.exit(main())
