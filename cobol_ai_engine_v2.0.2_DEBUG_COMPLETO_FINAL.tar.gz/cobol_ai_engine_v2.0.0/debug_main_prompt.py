#!/usr/bin/env python3
"""
Debug do Prompt no Main.py
Verifica se o main.py está gerando o prompt no formato correto.
"""

import os
import sys
import logging

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.core.prompt_manager_enhanced import EnhancedPromptManager
from src.core.constants import PROMPT_SEPARATOR

# Configurar logging
logging.basicConfig(level=logging.DEBUG)

def test_main_prompt_generation():
    """Testa se o main.py gera prompt no formato correto."""
    print("=" * 60)
    print("DEBUG: Prompt gerado pelo main.py")
    print("=" * 60)
    
    # Simular o que o main.py faz
    model_name = "luzia"
    prompt_manager = EnhancedPromptManager(model_name=model_name)
    
    # Código COBOL de teste (mesmo do main.py)
    program_code = """       IDENTIFICATION DIVISION.
       PROGRAM-ID. TEST-PROG.
       PROCEDURE DIVISION.
       DISPLAY 'TEST'.
       STOP RUN."""
    
    program_name = "TEST-PROG"
    
    # Gerar prompt como faz o main.py
    context = {
        "books": [],
        "pre_analysis": {}
    }
    
    base_prompt = prompt_manager.generate_base_prompt(
        program_name, 
        program_code,
        context=context
    )
    
    print(f"Prompt gerado:")
    print(f"Tamanho total: {len(base_prompt)} caracteres")
    print()
    
    # Verificar se contém o separador
    if PROMPT_SEPARATOR in base_prompt:
        print("✅ Separador encontrado no prompt")
        
        # Dividir o prompt
        parts = base_prompt.split(PROMPT_SEPARATOR, 1)
        system_prompt = parts[0].strip()
        user_prompt = parts[1].strip()
        
        print(f"✅ System prompt: {len(system_prompt)} caracteres")
        print(f"✅ User prompt: {len(user_prompt)} caracteres")
        
        # Mostrar primeiros caracteres de cada parte
        print()
        print("System prompt (primeiros 200 chars):")
        print(system_prompt[:200] + "...")
        print()
        print("User prompt (primeiros 200 chars):")
        print(user_prompt[:200] + "...")
        
        return True
    else:
        print("❌ Separador NÃO encontrado no prompt")
        print()
        print("Prompt completo (primeiros 500 chars):")
        print(base_prompt[:500] + "...")
        
        return False

def test_luzia_provider_compatibility():
    """Testa se o LuziaProvider consegue processar o prompt."""
    print("\n" + "=" * 60)
    print("DEBUG: Compatibilidade com LuziaProvider")
    print("=" * 60)
    
    # Gerar prompt
    prompt_manager = EnhancedPromptManager(model_name="luzia")
    
    program_code = """       IDENTIFICATION DIVISION.
       PROGRAM-ID. TEST-PROG.
       PROCEDURE DIVISION.
       DISPLAY 'TEST'.
       STOP RUN."""
    
    base_prompt = prompt_manager.generate_base_prompt(
        "TEST-PROG", 
        program_code,
        context={"books": [], "pre_analysis": {}}
    )
    
    # Simular o que o LuziaProvider faz
    try:
        from src.core.constants import PROMPT_SEPARATOR
        prompt_parts = base_prompt.split(PROMPT_SEPARATOR, 1)
        
        if len(prompt_parts) == 2:
            system_prompt = prompt_parts[0].strip()
            user_prompt = prompt_parts[1].strip()
            
            print("✅ LuziaProvider consegue dividir o prompt")
            print(f"✅ System prompt extraído: {len(system_prompt)} chars")
            print(f"✅ User prompt extraído: {len(user_prompt)} chars")
            
            # Verificar se não estão vazios
            if system_prompt and user_prompt:
                print("✅ Ambas as partes têm conteúdo")
                return True
            else:
                print("❌ Uma das partes está vazia")
                return False
        else:
            print("❌ LuziaProvider NÃO consegue dividir o prompt")
            return False
            
    except Exception as e:
        print(f"❌ Erro ao processar prompt: {e}")
        return False

def main():
    """Executa todos os testes de debug."""
    print("INICIANDO DEBUG DO PROMPT NO MAIN.PY")
    print("=" * 60)
    
    test1_ok = test_main_prompt_generation()
    test2_ok = test_luzia_provider_compatibility()
    
    print("\n" + "=" * 60)
    print("RESUMO DO DEBUG")
    print("=" * 60)
    
    if test1_ok and test2_ok:
        print("✅ PROMPT ESTÁ CORRETO - Problema deve estar em outro lugar")
    else:
        print("❌ PROBLEMA ENCONTRADO NO FORMATO DO PROMPT")
        
    return test1_ok and test2_ok

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
