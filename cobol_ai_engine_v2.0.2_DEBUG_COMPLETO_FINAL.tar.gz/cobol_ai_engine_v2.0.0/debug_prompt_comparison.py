#!/usr/bin/env python3
"""
Debug: Comparação entre Prompt Simples vs Complexo
Identifica qual parte do prompt complexo está causando o erro HTTP 403.
"""

import os
import sys
import json
import re

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.core.prompt_manager_enhanced import EnhancedPromptManager
from src.core.constants import PROMPT_SEPARATOR

def analyze_prompt_content(prompt_text):
    """Analisa o conteúdo do prompt em busca de caracteres problemáticos."""
    print("=" * 60)
    print("ANÁLISE DE CONTEÚDO DO PROMPT")
    print("=" * 60)
    
    # Estatísticas básicas
    print(f"Tamanho total: {len(prompt_text)} caracteres")
    print(f"Número de linhas: {prompt_text.count(chr(10)) + 1}")
    
    # Procurar caracteres especiais problemáticos
    problematic_chars = []
    
    # Caracteres que podem causar problemas em JSON/HTTP
    special_chars = {
        '"': 'aspas duplas',
        "'": 'aspas simples', 
        '\\': 'barra invertida',
        '\n': 'quebra de linha',
        '\r': 'retorno de carro',
        '\t': 'tab',
        '\0': 'null',
        '=': 'igual',
        '&': 'e comercial',
        '%': 'porcentagem',
        '+': 'mais',
        '#': 'hashtag'
    }
    
    char_counts = {}
    for char, name in special_chars.items():
        count = prompt_text.count(char)
        if count > 0:
            char_counts[name] = count
    
    print("\nCaracteres especiais encontrados:")
    for name, count in char_counts.items():
        print(f"  {name}: {count}")
    
    # Procurar padrões que podem ser problemáticos
    patterns = {
        r'=\s*[^=\s]': 'padrões key=value',
        r'[&%+]': 'caracteres de URL encoding',
        r'[\x00-\x1f]': 'caracteres de controle',
        r'[^\x20-\x7e\n\r\t]': 'caracteres não-ASCII'
    }
    
    print("\nPadrões problemáticos:")
    for pattern, description in patterns.items():
        matches = re.findall(pattern, prompt_text)
        if matches:
            print(f"  {description}: {len(matches)} ocorrências")
            if len(matches) <= 5:
                print(f"    Exemplos: {matches}")
    
    return char_counts

def create_simple_prompt():
    """Cria um prompt simples que sabemos que funciona."""
    system_prompt = "Você é um analista COBOL experiente."
    user_prompt = "Analise este programa COBOL simples."
    
    return f"{system_prompt}{PROMPT_SEPARATOR}{user_prompt}"

def create_complex_prompt():
    """Cria o prompt complexo do EnhancedPromptManager."""
    prompt_manager = EnhancedPromptManager(model_name="luzia")
    
    program_code = """       IDENTIFICATION DIVISION.
       PROGRAM-ID. TEST-PROG.
       PROCEDURE DIVISION.
       DISPLAY 'TEST'.
       STOP RUN."""
    
    return prompt_manager.generate_base_prompt(
        "TEST-PROG", 
        program_code,
        context={"books": [], "pre_analysis": {}}
    )

def test_json_serialization(prompt_text, prompt_name):
    """Testa se o prompt pode ser serializado em JSON sem problemas."""
    print(f"\n--- Teste JSON para {prompt_name} ---")
    
    try:
        # Simular o payload que seria enviado
        payload = {
            "input": {
                "query": [
                    {"role": "system", "content": "test"},
                    {"role": "user", "content": prompt_text}
                ]
            },
            "config": [
                {
                    "type": "catena.llm.LLMRouter",
                    "obj_kwargs": {
                        "routing_model": "azure-gpt-4o-mini",
                        "temperature": 0.1,
                        "max_tokens": 4000
                    }
                }
            ]
        }
        
        # Tentar serializar
        json_str = json.dumps(payload, ensure_ascii=False)
        print(f"✅ JSON serialization OK - {len(json_str)} caracteres")
        
        # Tentar deserializar
        json.loads(json_str)
        print("✅ JSON deserialization OK")
        
        return True
        
    except Exception as e:
        print(f"❌ Erro JSON: {e}")
        return False

def find_problematic_section(prompt_text):
    """Tenta identificar qual seção do prompt está causando problema."""
    print("\n" + "=" * 60)
    print("IDENTIFICAÇÃO DE SEÇÃO PROBLEMÁTICA")
    print("=" * 60)
    
    # Dividir o prompt em seções
    if PROMPT_SEPARATOR in prompt_text:
        parts = prompt_text.split(PROMPT_SEPARATOR, 1)
        system_part = parts[0].strip()
        user_part = parts[1].strip()
        
        print("Testando seção SYSTEM:")
        system_ok = test_json_serialization(system_part, "SYSTEM")
        
        print("\nTestando seção USER:")
        user_ok = test_json_serialization(user_part, "USER")
        
        if not system_ok:
            print("⚠️  Problema na seção SYSTEM")
            analyze_prompt_content(system_part)
        
        if not user_ok:
            print("⚠️  Problema na seção USER")
            analyze_prompt_content(user_part)
            
        return system_ok, user_ok
    else:
        print("❌ Separador não encontrado")
        return False, False

def main():
    """Executa a comparação completa."""
    print("COMPARAÇÃO: PROMPT SIMPLES vs COMPLEXO")
    print("=" * 60)
    
    # Teste 1: Prompt simples
    print("\n1. PROMPT SIMPLES (que funciona)")
    simple_prompt = create_simple_prompt()
    analyze_prompt_content(simple_prompt)
    simple_json_ok = test_json_serialization(simple_prompt, "SIMPLES")
    
    # Teste 2: Prompt complexo
    print("\n\n2. PROMPT COMPLEXO (EnhancedPromptManager)")
    complex_prompt = create_complex_prompt()
    analyze_prompt_content(complex_prompt)
    complex_json_ok = test_json_serialization(complex_prompt, "COMPLEXO")
    
    # Teste 3: Identificar seção problemática
    if not complex_json_ok:
        find_problematic_section(complex_prompt)
    
    # Resumo
    print("\n" + "=" * 60)
    print("RESUMO DA ANÁLISE")
    print("=" * 60)
    
    print(f"Prompt simples JSON OK: {'✅' if simple_json_ok else '❌'}")
    print(f"Prompt complexo JSON OK: {'✅' if complex_json_ok else '❌'}")
    
    if simple_json_ok and not complex_json_ok:
        print("\n🔍 PROBLEMA IDENTIFICADO:")
        print("O prompt complexo contém caracteres ou estruturas que causam erro na API.")
        print("Recomendação: Simplificar ou escapar caracteres especiais no prompt.")
    elif simple_json_ok and complex_json_ok:
        print("\n✅ AMBOS OS PROMPTS ESTÃO OK:")
        print("O problema pode estar em outro lugar (token, headers, etc.)")
    else:
        print("\n❌ PROBLEMA GERAL:")
        print("Há um problema fundamental na serialização JSON.")

if __name__ == "__main__":
    main()
