#!/usr/bin/env python3
"""
Teste Final de Validação v2.0.2
Valida todas as funcionalidades implementadas:
1. Geração de prompt correta
2. Salvamento de prompt em arquivo
3. Processamento pelo provider
4. Salvamento de resposta em arquivo
5. Logs detalhados
"""

import os
import sys
import subprocess
import time
from datetime import datetime

def run_command(cmd, timeout=30):
    """Executa comando e retorna resultado."""
    try:
        result = subprocess.run(
            cmd, 
            shell=True, 
            capture_output=True, 
            text=True, 
            timeout=timeout,
            cwd="/home/ubuntu/cobol_ai_engine_v2.0.0"
        )
        return result.returncode == 0, result.stdout, result.stderr
    except subprocess.TimeoutExpired:
        return False, "", "Timeout"
    except Exception as e:
        return False, "", str(e)

def check_file_exists(filepath):
    """Verifica se arquivo existe e retorna tamanho."""
    if os.path.exists(filepath):
        return True, os.path.getsize(filepath)
    return False, 0

def validate_prompt_file(filepath):
    """Valida conteúdo do arquivo de prompt."""
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
        
        checks = {
            'tem_header': 'PROMPT GERADO PARA:' in content,
            'tem_system_prompt': 'SYSTEM PROMPT:' in content,
            'tem_user_prompt': 'USER PROMPT:' in content,
            'tem_separador': '=' * 80 in content,
            'tamanho_adequado': len(content) > 1000
        }
        
        return all(checks.values()), checks
    except Exception as e:
        return False, {'erro': str(e)}

def validate_response_file(filepath):
    """Valida conteúdo do arquivo de resposta."""
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
        
        checks = {
            'tem_header': 'RESPOSTA DO PROVIDER PARA:' in content,
            'tem_success': 'SUCCESS:' in content,
            'tem_provider': 'PROVIDER:' in content,
            'tem_conteudo': 'CONTEÚDO DA RESPOSTA:' in content,
            'tamanho_adequado': len(content) > 500
        }
        
        return all(checks.values()), checks
    except Exception as e:
        return False, {'erro': str(e)}

def main():
    """Executa validação completa."""
    print("=" * 80)
    print("TESTE FINAL DE VALIDAÇÃO v2.0.2")
    print("=" * 80)
    print(f"Data/Hora: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print()
    
    # Preparar ambiente
    print("1. PREPARANDO AMBIENTE...")
    
    # Limpar arquivos anteriores
    output_dir = "/home/ubuntu/cobol_ai_engine_v2.0.0/output"
    if os.path.exists(output_dir):
        for file in os.listdir(output_dir):
            if file.startswith("PROGRAMA_"):
                os.remove(os.path.join(output_dir, file))
    
    # Verificar arquivo de teste
    test_file = "/home/ubuntu/cobol_ai_engine_v2.0.0/fontes_test.txt"
    if not os.path.exists(test_file):
        with open(test_file, 'w') as f:
            f.write("test_program.cbl\n")
    
    print("✅ Ambiente preparado")
    
    # Teste 2: Executar main.py
    print("\n2. EXECUTANDO MAIN.PY...")
    
    cmd = 'LUZIA_CLIENT_ID="test_client_id" LUZIA_CLIENT_SECRET="test_client_secret" python3 main.py --fontes fontes_test.txt --models luzia --log INFO'
    success, stdout, stderr = run_command(cmd)
    
    if success:
        print("✅ Main.py executado com sucesso")
    else:
        print("❌ Erro ao executar main.py")
        print(f"STDERR: {stderr}")
        return False
    
    # Teste 3: Verificar arquivos gerados
    print("\n3. VERIFICANDO ARQUIVOS GERADOS...")
    
    prompt_file = os.path.join(output_dir, "PROGRAMA_prompt_gerado.txt")
    response_file = os.path.join(output_dir, "PROGRAMA_resposta_provider.txt")
    
    # Verificar prompt
    prompt_exists, prompt_size = check_file_exists(prompt_file)
    if prompt_exists:
        print(f"✅ Arquivo de prompt criado: {prompt_size} bytes")
        
        prompt_valid, prompt_checks = validate_prompt_file(prompt_file)
        if prompt_valid:
            print("✅ Conteúdo do prompt válido")
        else:
            print("❌ Conteúdo do prompt inválido")
            print(f"   Checks: {prompt_checks}")
    else:
        print("❌ Arquivo de prompt não encontrado")
        return False
    
    # Verificar resposta
    response_exists, response_size = check_file_exists(response_file)
    if response_exists:
        print(f"✅ Arquivo de resposta criado: {response_size} bytes")
        
        response_valid, response_checks = validate_response_file(response_file)
        if response_valid:
            print("✅ Conteúdo da resposta válido")
        else:
            print("❌ Conteúdo da resposta inválido")
            print(f"   Checks: {response_checks}")
    else:
        print("❌ Arquivo de resposta não encontrado")
        return False
    
    # Teste 4: Verificar logs
    print("\n4. VERIFICANDO LOGS...")
    
    log_checks = {
        'prompt_gerado': 'PROMPT GERADO PARA' in stdout,
        'prompt_salvo': 'Prompt salvo em:' in stdout,
        'resposta_salva': 'Resposta do provider salva em:' in stdout,
        'analise_sucesso': 'Análise bem-sucedida' in stdout
    }
    
    logs_ok = all(log_checks.values())
    if logs_ok:
        print("✅ Logs detalhados presentes")
    else:
        print("❌ Logs incompletos")
        for check, result in log_checks.items():
            print(f"   {check}: {'✅' if result else '❌'}")
    
    # Teste 5: Verificar estrutura do prompt
    print("\n5. VERIFICANDO ESTRUTURA DO PROMPT...")
    
    try:
        with open(prompt_file, 'r', encoding='utf-8') as f:
            prompt_content = f.read()
        
        structure_checks = {
            'tem_divisao_clara': 'SYSTEM PROMPT:' in prompt_content and 'USER PROMPT:' in prompt_content,
            'system_antes_user': prompt_content.find('SYSTEM PROMPT:') < prompt_content.find('USER PROMPT:'),
            'tamanho_system': 'SYSTEM PROMPT:' in prompt_content and len(prompt_content.split('SYSTEM PROMPT:')[1].split('USER PROMPT:')[0]) > 3000,
            'tamanho_user': 'USER PROMPT:' in prompt_content and len(prompt_content.split('USER PROMPT:')[1]) > 100,
            'tem_codigo_cobol': 'cobol' in prompt_content.lower()
        }
        
        structure_ok = all(structure_checks.values())
        if structure_ok:
            print("✅ Estrutura do prompt correta")
        else:
            print("❌ Estrutura do prompt incorreta")
            for check, result in structure_checks.items():
                print(f"   {check}: {'✅' if result else '❌'}")
                
    except Exception as e:
        print(f"❌ Erro ao verificar estrutura: {e}")
        structure_ok = False
    
    # Resumo final
    print("\n" + "=" * 80)
    print("RESUMO DA VALIDAÇÃO")
    print("=" * 80)
    
    all_tests = [
        ("Execução do main.py", success),
        ("Arquivo de prompt", prompt_exists and prompt_valid),
        ("Arquivo de resposta", response_exists and response_valid),
        ("Logs detalhados", logs_ok),
        ("Estrutura do prompt", structure_ok)
    ]
    
    passed = sum(1 for _, result in all_tests if result)
    total = len(all_tests)
    
    print(f"Testes aprovados: {passed}/{total}")
    print()
    
    for test_name, result in all_tests:
        status = "✅ PASSOU" if result else "❌ FALHOU"
        print(f"{test_name}: {status}")
    
    print()
    if passed == total:
        print("🎉 TODOS OS TESTES PASSARAM!")
        print("✅ Sistema funcionando perfeitamente")
        print("✅ Prompt sendo salvo antes do envio")
        print("✅ Resposta sendo salva após recebimento")
        print("✅ Logs detalhados funcionando")
        return True
    else:
        print("❌ ALGUNS TESTES FALHARAM")
        print("Verifique os itens marcados como falhou")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
