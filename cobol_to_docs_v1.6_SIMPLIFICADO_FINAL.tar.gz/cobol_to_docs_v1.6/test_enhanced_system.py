#!/usr/bin/env python3
"""
Script de Teste Abrangente para Sistema COBOL to Docs v1.0 Aprimorado
Testa todas as melhorias implementadas: RAG expandido, seleção inteligente, prompts adaptativos
"""

import os
import sys
import json
import time
import logging
from datetime import datetime
from pathlib import Path

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.core.config import ConfigManager
from src.core.intelligent_model_selector import IntelligentModelSelector
from src.core.adaptive_prompt_manager import AdaptivePromptManager
from src.rag.rag_integration import RAGIntegration

def setup_test_logging():
    """Configura logging para testes"""
    log_dir = "logs"
    os.makedirs(log_dir, exist_ok=True)
    
    log_file = os.path.join(log_dir, f"test_enhanced_system_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
    
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file, encoding='utf-8'),
            logging.StreamHandler(sys.stdout)
        ]
    )
    
    return log_file

def create_test_cobol_programs():
    """Cria programas COBOL de teste para diferentes cenários"""
    
    test_programs = {
        "CADOC_CLASSIFIER": {
            "description": "Programa de classificação de documentos - Complexidade Alta",
            "content": """
            IDENTIFICATION DIVISION.
            PROGRAM-ID. CADOC-CLASSIFIER.
            
            DATA DIVISION.
            WORKING-STORAGE SECTION.
            01 WS-DOCUMENT-REC.
               05 WS-DOC-ID        PIC X(20).
               05 WS-DOC-TYPE      PIC X(10).
               05 WS-DOC-STATUS    PIC X(02).
               05 WS-QUALITY-SCORE PIC 9(03)V99.
               05 WS-CLASSIFICATION PIC X(20).
            
            01 WS-AUDIT-REC.
               05 WS-USER-ID       PIC X(10).
               05 WS-TIMESTAMP     PIC X(26).
               05 WS-ACTION        PIC X(20).
            
            PROCEDURE DIVISION.
            MAIN-PROCESS.
                PERFORM INITIALIZE-SYSTEM
                PERFORM CLASSIFY-DOCUMENTS
                UNTIL WS-EOF = 'Y'
                PERFORM FINALIZE-SYSTEM.
                
            CLASSIFY-DOCUMENTS.
                EXEC SQL
                    SELECT DOC_ID, DOC_TYPE, CONTENT
                    INTO :WS-DOC-ID, :WS-DOC-TYPE, :WS-DOC-CONTENT
                    FROM CADOC_DOCUMENTS
                    WHERE STATUS = 'PENDING'
                    AND CREATED_DATE >= CURRENT_DATE - 30 DAYS
                END-EXEC.
                
                EVALUATE WS-DOC-TYPE
                    WHEN 'CHEQUE'
                        PERFORM CLASSIFY-CHEQUE
                        PERFORM VALIDATE-CMC7
                        PERFORM CHECK-SIGNATURE-PATTERN
                    WHEN 'CONTRATO'
                        PERFORM CLASSIFY-CONTRACT
                        PERFORM VALIDATE-LEGAL-CLAUSES
                        PERFORM CHECK-APPROVAL-WORKFLOW
                    WHEN 'COMPROVANTE'
                        PERFORM CLASSIFY-RECEIPT
                        PERFORM VALIDATE-TRANSACTION-DATA
                    WHEN OTHER
                        PERFORM GENERIC-CLASSIFICATION
                        PERFORM QUALITY-ASSESSMENT
                END-EVALUATE.
                
                PERFORM AUDIT-LOG-ENTRY
                PERFORM UPDATE-DOCUMENT-STATUS.
                
            CLASSIFY-CHEQUE.
                STRING WS-DOC-TYPE DELIMITED BY SPACE
                       '_BANCARIO' DELIMITED BY SIZE
                       INTO WS-CLASSIFICATION
                END-STRING.
                
                IF WS-QUALITY-SCORE > 90.00
                    MOVE 'AUTO_APPROVED' TO WS-DOC-STATUS
                ELSE
                    IF WS-QUALITY-SCORE > 70.00
                        MOVE 'MANUAL_REVIEW' TO WS-DOC-STATUS
                    ELSE
                        MOVE 'REJECTED' TO WS-DOC-STATUS
                    END-IF
                END-IF.
            """
        },
        
        "CADOC_RETENTION": {
            "description": "Programa de retenção e arquivamento - Complexidade Média",
            "content": """
            IDENTIFICATION DIVISION.
            PROGRAM-ID. CADOC-RETENTION.
            
            DATA DIVISION.
            WORKING-STORAGE SECTION.
            01 WS-RETENTION-RULES.
               05 WS-DOC-TYPE      PIC X(10).
               05 WS-RETENTION-DAYS PIC 9(05).
               05 WS-ARCHIVE-LEVEL PIC X(10).
            
            01 WS-DOCUMENT-INFO.
               05 WS-DOC-ID        PIC X(20).
               05 WS-CREATED-DATE  PIC X(10).
               05 WS-LAST-ACCESS   PIC X(10).
               05 WS-ACCESS-COUNT  PIC 9(05).
            
            PROCEDURE DIVISION.
            MAIN-PROCESS.
                PERFORM LOAD-RETENTION-RULES
                PERFORM PROCESS-DOCUMENTS
                UNTIL WS-EOF = 'Y'
                PERFORM GENERATE-RETENTION-REPORT.
                
            PROCESS-DOCUMENTS.
                READ DOCUMENT-FILE
                AT END MOVE 'Y' TO WS-EOF
                NOT AT END
                    PERFORM CALCULATE-RETENTION-PERIOD
                    PERFORM DETERMINE-ARCHIVE-LEVEL
                    PERFORM UPDATE-DOCUMENT-METADATA
                END-READ.
                
            CALCULATE-RETENTION-PERIOD.
                EVALUATE WS-DOC-TYPE
                    WHEN 'CHEQUE'
                        MOVE 2555 TO WS-RETENTION-DAYS  *> 7 anos
                    WHEN 'CONTRATO'
                        MOVE 3650 TO WS-RETENTION-DAYS  *> 10 anos
                    WHEN 'COMPROVANTE'
                        MOVE 1825 TO WS-RETENTION-DAYS  *> 5 anos
                    WHEN OTHER
                        MOVE 1095 TO WS-RETENTION-DAYS  *> 3 anos
                END-EVALUATE.
                
                COMPUTE WS-DAYS-SINCE-CREATION = 
                    FUNCTION INTEGER-OF-DATE(FUNCTION CURRENT-DATE) -
                    FUNCTION INTEGER-OF-DATE(WS-CREATED-DATE).
                    
                IF WS-DAYS-SINCE-CREATION > WS-RETENTION-DAYS
                    PERFORM INITIATE-PURGE-PROCESS
                ELSE
                    IF WS-ACCESS-COUNT < 5 AND WS-DAYS-SINCE-CREATION > 365
                        MOVE 'NEARLINE' TO WS-ARCHIVE-LEVEL
                    ELSE
                        MOVE 'ONLINE' TO WS-ARCHIVE-LEVEL
                    END-IF
                END-IF.
            """
        },
        
        "CADOC_SIMPLE": {
            "description": "Programa simples de consulta - Complexidade Baixa",
            "content": """
            IDENTIFICATION DIVISION.
            PROGRAM-ID. CADOC-SIMPLE.
            
            DATA DIVISION.
            WORKING-STORAGE SECTION.
            01 WS-DOCUMENT-ID    PIC X(20).
            01 WS-DOCUMENT-TYPE  PIC X(10).
            01 WS-DOCUMENT-STATUS PIC X(02).
            01 WS-EOF            PIC X(01) VALUE 'N'.
            
            PROCEDURE DIVISION.
            MAIN-PROCESS.
                OPEN INPUT DOCUMENT-FILE
                PERFORM READ-DOCUMENTS
                UNTIL WS-EOF = 'Y'
                CLOSE DOCUMENT-FILE
                STOP RUN.
                
            READ-DOCUMENTS.
                READ DOCUMENT-FILE
                AT END 
                    MOVE 'Y' TO WS-EOF
                NOT AT END
                    MOVE DOC-ID TO WS-DOCUMENT-ID
                    MOVE DOC-TYPE TO WS-DOCUMENT-TYPE
                    MOVE DOC-STATUS TO WS-DOCUMENT-STATUS
                    PERFORM DISPLAY-DOCUMENT-INFO
                END-READ.
                
            DISPLAY-DOCUMENT-INFO.
                DISPLAY 'Documento: ' WS-DOCUMENT-ID
                DISPLAY 'Tipo: ' WS-DOCUMENT-TYPE
                DISPLAY 'Status: ' WS-DOCUMENT-STATUS
                DISPLAY '---'.
            """
        }
    }
    
    return test_programs

def test_intelligent_model_selector():
    """Testa o seletor inteligente de modelos"""
    print("\n" + "="*60)
    print("TESTE: SELETOR INTELIGENTE DE MODELOS")
    print("="*60)
    
    selector = IntelligentModelSelector()
    test_programs = create_test_cobol_programs()
    
    results = {}
    
    for program_name, program_info in test_programs.items():
        print(f"\n🧪 Testando programa: {program_name}")
        print(f"   Descrição: {program_info['description']}")
        
        # Analisar complexidade
        complexity = selector.analyze_code_complexity(program_info['content'])
        print(f"   Complexidade calculada: {complexity:.3f}")
        
        # Selecionar modelo ótimo
        recommendation = selector.select_optimal_model(program_info['content'])
        print(f"   Modelo recomendado: {recommendation.model_name}")
        print(f"   Confiança: {recommendation.confidence:.1%}")
        print(f"   Justificativa: {recommendation.reasoning}")
        print(f"   Modelos fallback: {recommendation.fallback_models}")
        
        # Comparação de modelos
        comparison = selector.get_model_comparison(program_info['content'])
        print(f"   Comparação de modelos:")
        for model, info in comparison.items():
            print(f"     - {model}: {info['adequacy']} (score: {info['score']:.2f})")
        
        results[program_name] = {
            "complexity": complexity,
            "recommended_model": recommendation.model_name,
            "confidence": recommendation.confidence,
            "model_comparison": comparison
        }
    
    return results

def test_adaptive_prompt_manager():
    """Testa o gerenciador de prompts adaptativos"""
    print("\n" + "="*60)
    print("TESTE: GERENCIADOR DE PROMPTS ADAPTATIVOS")
    print("="*60)
    
    try:
        manager = AdaptivePromptManager()
        test_programs = create_test_cobol_programs()
        
        results = {}
        
        for program_name, program_info in test_programs.items():
            print(f"\n🧪 Testando programa: {program_name}")
            
            # Analisar domínio
            domain_summary = manager.get_domain_analysis_summary(program_info['content'])
            print(f"   Domínio principal: {domain_summary['primary_domain']}")
            print(f"   Complexidade: {domain_summary['complexity_level']}")
            print(f"   Tipo de análise: {domain_summary['recommended_analysis_type']}")
            
            # Testar com diferentes modelos
            models_to_test = ["aws_claude_3_5_sonnet", "amazon_nova_pro_v1", "azure_gpt_4o", "aws_claude_3_5_haiku"]
            
            model_results = {}
            for model in models_to_test:
                try:
                    recommendation = manager.select_optimal_prompt(program_info['content'], model)
                    print(f"   Modelo {model}:")
                    print(f"     - Tipo de análise: {recommendation.analysis_type}")
                    print(f"     - Confiança: {recommendation.confidence:.1%}")
                    print(f"     - Áreas de foco: {len(recommendation.focus_areas)} identificadas")
                    
                    model_results[model] = {
                        "analysis_type": recommendation.analysis_type,
                        "confidence": recommendation.confidence,
                        "focus_areas_count": len(recommendation.focus_areas)
                    }
                except Exception as e:
                    print(f"     - Erro: {e}")
                    model_results[model] = {"error": str(e)}
            
            results[program_name] = {
                "domain_analysis": domain_summary,
                "model_results": model_results
            }
        
        return results
        
    except Exception as e:
        print(f"❌ Erro no teste de prompts adaptativos: {e}")
        return {"error": str(e)}

def test_rag_integration():
    """Testa a integração RAG expandida"""
    print("\n" + "="*60)
    print("TESTE: INTEGRAÇÃO RAG EXPANDIDA")
    print("="*60)
    
    try:
        config_manager = ConfigManager()
        rag_integration = RAGIntegration(config_manager.config)
        
        if not rag_integration.is_enabled():
            print("❌ Sistema RAG não está habilitado")
            return {"error": "RAG not enabled"}
        
        # Verificar estatísticas da base
        stats = rag_integration.get_rag_statistics()
        print(f"📊 Estatísticas da base RAG:")
        print(f"   Total de itens: {stats['total_items']}")
        print(f"   Categorias: {len(stats['categories'])}")
        print(f"   Domínios: {len(stats['domains'])}")
        print(f"   Arquivo da base: {stats['knowledge_base_file']}")
        
        # Testar busca de contexto
        test_queries = [
            "classificação de documentos CADOC",
            "workflow de aprovação bancária",
            "retenção e arquivamento de documentos",
            "controle de qualidade documental",
            "auditoria e rastreabilidade"
        ]
        
        context_results = {}
        for query in test_queries:
            print(f"\n🔍 Testando busca: '{query}'")
            try:
                context_items = rag_integration.get_relevant_context(query)
                print(f"   Itens encontrados: {len(context_items)}")
                
                if context_items:
                    for i, item in enumerate(context_items[:2], 1):  # Mostrar apenas os 2 primeiros
                        print(f"     {i}. {item.get('title', 'Sem título')} (score: {item.get('similarity_score', 0):.3f})")
                
                context_results[query] = {
                    "items_found": len(context_items),
                    "top_items": [item.get('title', 'Sem título') for item in context_items[:3]]
                }
            except Exception as e:
                print(f"   ❌ Erro na busca: {e}")
                context_results[query] = {"error": str(e)}
        
        return {
            "rag_stats": stats,
            "context_results": context_results
        }
        
    except Exception as e:
        print(f"❌ Erro no teste RAG: {e}")
        return {"error": str(e)}

def test_end_to_end_analysis():
    """Teste end-to-end com programa real"""
    print("\n" + "="*60)
    print("TESTE: ANÁLISE END-TO-END")
    print("="*60)
    
    try:
        # Verificar se existe programa de exemplo
        examples_dir = Path("examples")
        if not examples_dir.exists():
            print("❌ Diretório examples não encontrado")
            return {"error": "Examples directory not found"}
        
        # Procurar arquivo de fontes
        fontes_file = examples_dir / "fontes.txt"
        if not fontes_file.exists():
            print("❌ Arquivo examples/fontes.txt não encontrado")
            return {"error": "fontes.txt not found"}
        
        print(f"✅ Arquivo de fontes encontrado: {fontes_file}")
        
        # Simular análise (sem executar realmente para não sobrecarregar)
        print("🔄 Simulando análise end-to-end...")
        
        # Verificar componentes necessários
        components_status = {
            "config_manager": False,
            "model_selector": False,
            "prompt_manager": False,
            "rag_integration": False
        }
        
        try:
            config_manager = ConfigManager()
            components_status["config_manager"] = True
            print("   ✅ ConfigManager inicializado")
        except Exception as e:
            print(f"   ❌ ConfigManager falhou: {e}")
        
        try:
            model_selector = IntelligentModelSelector()
            components_status["model_selector"] = True
            print("   ✅ IntelligentModelSelector inicializado")
        except Exception as e:
            print(f"   ❌ IntelligentModelSelector falhou: {e}")
        
        try:
            prompt_manager = AdaptivePromptManager()
            components_status["prompt_manager"] = True
            print("   ✅ AdaptivePromptManager inicializado")
        except Exception as e:
            print(f"   ❌ AdaptivePromptManager falhou: {e}")
        
        try:
            if components_status["config_manager"]:
                rag_integration = RAGIntegration(config_manager.config)
                components_status["rag_integration"] = True
                print("   ✅ RAGIntegration inicializado")
        except Exception as e:
            print(f"   ❌ RAGIntegration falhou: {e}")
        
        # Verificar se todos os componentes estão funcionando
        all_working = all(components_status.values())
        print(f"\n📊 Status dos componentes: {sum(components_status.values())}/4 funcionando")
        
        if all_working:
            print("🎉 Todos os componentes estão funcionando corretamente!")
            print("💡 Sistema pronto para análise end-to-end")
        else:
            print("⚠️  Alguns componentes apresentaram problemas")
        
        return {
            "components_status": components_status,
            "all_working": all_working,
            "fontes_file_exists": True
        }
        
    except Exception as e:
        print(f"❌ Erro no teste end-to-end: {e}")
        return {"error": str(e)}

def generate_test_report(results):
    """Gera relatório completo dos testes"""
    print("\n" + "="*60)
    print("RELATÓRIO FINAL DOS TESTES")
    print("="*60)
    
    report = {
        "timestamp": datetime.now().isoformat(),
        "test_results": results,
        "summary": {
            "total_tests": len(results),
            "successful_tests": 0,
            "failed_tests": 0
        }
    }
    
    # Contar sucessos e falhas
    for test_name, test_result in results.items():
        if isinstance(test_result, dict) and "error" not in test_result:
            report["summary"]["successful_tests"] += 1
            print(f"✅ {test_name}: SUCESSO")
        else:
            report["summary"]["failed_tests"] += 1
            print(f"❌ {test_name}: FALHA")
    
    # Calcular taxa de sucesso
    total = report["summary"]["total_tests"]
    success_rate = (report["summary"]["successful_tests"] / total * 100) if total > 0 else 0
    
    print(f"\n📊 RESUMO FINAL:")
    print(f"   Testes executados: {total}")
    print(f"   Sucessos: {report['summary']['successful_tests']}")
    print(f"   Falhas: {report['summary']['failed_tests']}")
    print(f"   Taxa de sucesso: {success_rate:.1f}%")
    
    # Salvar relatório
    report_file = f"logs/test_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    os.makedirs("logs", exist_ok=True)
    
    with open(report_file, 'w', encoding='utf-8') as f:
        json.dump(report, f, indent=2, ensure_ascii=False)
    
    print(f"\n📄 Relatório salvo em: {report_file}")
    
    return report

def main():
    """Função principal de teste"""
    print("🧪 INICIANDO TESTES DO SISTEMA COBOL TO DOCS v1.0 APRIMORADO")
    print("=" * 80)
    
    # Configurar logging
    log_file = setup_test_logging()
    print(f"📝 Log dos testes: {log_file}")
    
    # Executar testes
    test_results = {}
    
    try:
        # Teste 1: Seletor Inteligente de Modelos
        test_results["intelligent_model_selector"] = test_intelligent_model_selector()
        
        # Teste 2: Gerenciador de Prompts Adaptativos
        test_results["adaptive_prompt_manager"] = test_adaptive_prompt_manager()
        
        # Teste 3: Integração RAG Expandida
        test_results["rag_integration"] = test_rag_integration()
        
        # Teste 4: Análise End-to-End
        test_results["end_to_end_analysis"] = test_end_to_end_analysis()
        
    except KeyboardInterrupt:
        print("\n⚠️  Testes interrompidos pelo usuário")
    except Exception as e:
        print(f"\n❌ Erro durante execução dos testes: {e}")
        test_results["fatal_error"] = {"error": str(e)}
    
    # Gerar relatório final
    final_report = generate_test_report(test_results)
    
    print("\n🎯 TESTES CONCLUÍDOS!")
    return final_report

if __name__ == "__main__":
    main()
