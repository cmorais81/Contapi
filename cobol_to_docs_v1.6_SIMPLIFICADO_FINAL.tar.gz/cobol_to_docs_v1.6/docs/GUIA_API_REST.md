# Guia da API REST - COBOL to Docs v1.6

Documentação completa da API REST para integração externa com o sistema COBOL to Docs v1.6.

## Visão Geral

A API REST do COBOL to Docs v1.6 oferece endpoints completos para:
- Análise de código COBOL via HTTP
- Processamento em lote de arquivos
- Gerenciamento de modelos e provedores
- Monitoramento de métricas e performance
- Instalação automática de dependências

## Iniciando o Servidor API

### Comando Básico
```bash
python api_server.py
```

### Opções Avançadas
```bash
python api_server.py --host 0.0.0.0 --port 5000 --config config/config.yaml
```

### Parâmetros Disponíveis
- `--host`: Host para bind (padrão: 0.0.0.0)
- `--port`: Porta para bind (padrão: 5000)
- `--config`: Caminho para arquivo de configuração
- `--debug`: Modo debug (não recomendado para produção)

## Endpoints Disponíveis

### 1. Health Check

**GET /health**

Verifica se a API está funcionando.

```bash
curl -X GET http://localhost:5000/health
```

**Resposta:**
```json
{
  "status": "healthy",
  "timestamp": "2024-01-15T10:30:00.000Z",
  "version": "1.6.0",
  "analyzer_available": true
}
```

### 2. Status do Sistema

**GET /status**

Obtém status completo do sistema.

```bash
curl -X GET http://localhost:5000/status
```

**Resposta:**
```json
{
  "system": {
    "providers": {
      "luzia": {"available": true, "models": 3},
      "openai": {"available": false, "error": "API key not configured"}
    },
    "dependencies": {
      "total_dependencies": 10,
      "installed_count": 7,
      "missing_count": 3
    },
    "performance": {
      "cache_hit_rate": 85.5,
      "total_analyses": 150
    }
  },
  "api": {
    "requests_total": 1250,
    "requests_successful": 1200,
    "requests_failed": 50,
    "analyses_performed": 300
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

### 3. Análise de Código COBOL

**POST /analyze/code**

Analisa código COBOL enviado no body da requisição.

```bash
curl -X POST http://localhost:5000/analyze/code \
  -H "Content-Type: application/json" \
  -d '{
    "code": "IDENTIFICATION DIVISION.\nPROGRAM-ID. TESTE.\nDATA DIVISION.\nPROCEDURE DIVISION.\nDISPLAY \"HELLO WORLD\".\nSTOP RUN.",
    "program_name": "TESTE",
    "options": {
      "model": "aws_claude_3_5_sonnet",
      "auto_learn": true,
      "generate_technical_codes": true
    }
  }'
```

**Parâmetros:**
- `code` (obrigatório): Código COBOL para análise
- `program_name` (opcional): Nome do programa (padrão: "PROGRAMA")
- `options` (opcional): Opções de análise
  - `model`: Modelo específico a usar
  - `auto_learn`: Adicionar resultado ao RAG (padrão: true)
  - `generate_technical_codes`: Gerar códigos técnicos (padrão: false)

**Resposta:**
```json
{
  "success": true,
  "result": {
    "content": "# Análise Funcional - TESTE\n\n## Identificação do Programa...",
    "model": "aws_claude_3_5_sonnet",
    "tokens_used": 1250,
    "cost": 0.0375,
    "response_time": 2.45,
    "provider": "luzia",
    "technical_codes": ["TC001", "TC002"],
    "rag_context_used": true
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

### 4. Análise de Arquivo

**POST /analyze/file**

Analisa arquivo COBOL enviado via upload.

```bash
curl -X POST http://localhost:5000/analyze/file \
  -F "file=@programa.cbl" \
  -F 'options={"model": "aws_claude_3_5_sonnet"}'
```

**Parâmetros:**
- `file` (obrigatório): Arquivo COBOL para upload
- `options` (opcional): JSON com opções de análise

**Resposta:**
```json
{
  "success": true,
  "result": {
    "content": "# Análise Funcional - programa.cbl...",
    "model": "aws_claude_3_5_sonnet",
    "tokens_used": 2100,
    "cost": 0.063,
    "response_time": 3.2,
    "provider": "luzia"
  },
  "filename": "programa.cbl",
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

### 5. Análise em Lote

**POST /analyze/batch**

Analisa múltiplos arquivos COBOL simultaneamente.

```bash
curl -X POST http://localhost:5000/analyze/batch \
  -F "files=@programa1.cbl" \
  -F "files=@programa2.cbl" \
  -F "files=@programa3.cbl" \
  -F 'options={"parallel": true, "model": "aws_claude_3_5_sonnet"}'
```

**Parâmetros:**
- `files` (obrigatório): Múltiplos arquivos COBOL
- `options` (opcional): JSON com opções de análise
  - `parallel`: Processamento paralelo (padrão: true)
  - `max_workers`: Número de workers (padrão: 4)

**Resposta:**
```json
{
  "success": true,
  "result": {
    "results": {
      "/tmp/programa1.cbl": {
        "content": "# Análise...",
        "model": "aws_claude_3_5_sonnet",
        "tokens_used": 1500,
        "cost": 0.045
      },
      "/tmp/programa2.cbl": {
        "content": "# Análise...",
        "model": "aws_claude_3_5_sonnet",
        "tokens_used": 1800,
        "cost": 0.054
      }
    },
    "errors": {},
    "statistics": {
      "total_files": 3,
      "successful": 2,
      "failed": 1,
      "success_rate": 66.7,
      "processing_time": 8.5,
      "total_cost": 0.099
    }
  },
  "files_processed": 3,
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

### 6. Listar Modelos

**GET /models**

Lista todos os modelos disponíveis.

```bash
curl -X GET http://localhost:5000/models
```

**Resposta:**
```json
{
  "models": [
    "aws_claude_3_5_sonnet",
    "aws_claude_3_5_haiku",
    "amazon_nova_pro_v1",
    "gpt_4_turbo",
    "enhanced_mock"
  ],
  "count": 5,
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

### 7. Status dos Provedores

**GET /providers**

Obtém status detalhado de todos os provedores.

```bash
curl -X GET http://localhost:5000/providers
```

**Resposta:**
```json
{
  "providers": {
    "luzia": {
      "available": true,
      "models": ["aws_claude_3_5_sonnet", "aws_claude_3_5_haiku"],
      "last_check": "2024-01-15T10:29:00.000Z",
      "response_time": 1.2
    },
    "openai": {
      "available": false,
      "error": "API key not configured",
      "models": []
    },
    "enhanced_mock": {
      "available": true,
      "models": ["enhanced_mock"],
      "description": "Provider de teste com respostas aprimoradas"
    }
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

### 8. Métricas de Performance

**GET /metrics**

Obtém métricas detalhadas de performance.

```bash
curl -X GET http://localhost:5000/metrics
```

**Resposta:**
```json
{
  "metrics": {
    "model_selector": {
      "cache_hit_rate": 85.5,
      "total_recommendations": 150,
      "avg_analysis_time": 0.25
    },
    "providers": {
      "luzia": {
        "requests_made": 120,
        "avg_response_time": 2.1,
        "total_cost": 15.75,
        "error_rate": 2.5
      }
    },
    "cache": {
      "cache_size_mb": 45.2,
      "hit_rate": 78.3,
      "entries": 1250
    }
  },
  "api_stats": {
    "requests_total": 1250,
    "requests_successful": 1200,
    "requests_failed": 50,
    "analyses_performed": 300,
    "uptime_seconds": 86400
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

### 9. Status das Dependências

**GET /dependencies/status**

Verifica status das dependências opcionais.

```bash
curl -X GET http://localhost:5000/dependencies/status
```

**Resposta:**
```json
{
  "dependencies": {
    "total_dependencies": 10,
    "installed_count": 7,
    "missing_count": 3,
    "dependencies": {
      "openai": {
        "installed": true,
        "description": "Suporte a modelos OpenAI (GPT-4, GPT-3.5)",
        "providers": ["openai"],
        "features": ["OpenAI GPT models", "ChatGPT integration"]
      },
      "boto3": {
        "installed": false,
        "description": "Suporte a AWS Bedrock",
        "providers": ["bedrock"],
        "features": ["AWS Bedrock models", "Claude via Bedrock"]
      }
    }
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

### 10. Instalar Dependências

**POST /dependencies/install**

Instala dependências opcionais automaticamente.

```bash
curl -X POST http://localhost:5000/dependencies/install \
  -H "Content-Type: application/json" \
  -d '{
    "packages": ["openai", "boto3", "anthropic"]
  }'
```

**Parâmetros:**
- `packages` (opcional): Lista de pacotes específicos. Se omitido, instala todos.

**Resposta:**
```json
{
  "installation_result": {
    "success": true,
    "results": {
      "openai": {
        "success": true,
        "message": "Instalado com sucesso"
      },
      "boto3": {
        "success": true,
        "message": "Instalado com sucesso"
      },
      "anthropic": {
        "success": false,
        "message": "Erro de conectividade"
      }
    },
    "summary": "2/3 pacotes instalados com sucesso"
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

## Códigos de Status HTTP

### Códigos de Sucesso
- **200 OK**: Requisição processada com sucesso
- **201 Created**: Recurso criado com sucesso

### Códigos de Erro do Cliente
- **400 Bad Request**: Parâmetros inválidos ou ausentes
- **404 Not Found**: Endpoint não encontrado
- **413 Payload Too Large**: Arquivo muito grande (máximo 16MB)
- **429 Too Many Requests**: Limite de taxa excedido

### Códigos de Erro do Servidor
- **500 Internal Server Error**: Erro interno do servidor
- **503 Service Unavailable**: Analyzer não disponível

## Tratamento de Erros

### Formato de Erro Padrão
```json
{
  "error": "Descrição do erro",
  "code": "ERROR_CODE",
  "timestamp": "2024-01-15T10:30:00.000Z",
  "request_id": "req_123456789"
}
```

### Exemplos de Erros Comuns

**Analyzer não disponível:**
```json
{
  "error": "Analyzer não disponível",
  "code": "ANALYZER_UNAVAILABLE",
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

**Arquivo muito grande:**
```json
{
  "error": "Arquivo muito grande (máximo 16MB)",
  "code": "FILE_TOO_LARGE",
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

**Modelo não encontrado:**
```json
{
  "error": "Modelo 'modelo_inexistente' não configurado",
  "code": "MODEL_NOT_FOUND",
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

## Autenticação e Segurança

### Configuração de Segurança (Futuro)
```yaml
# config/config.yaml
api:
  security:
    enabled: true
    api_key_required: true
    rate_limit: 100  # requests per minute
    max_file_size_mb: 16
    allowed_origins: ["https://app.exemplo.com"]
```

### Headers de Segurança
```bash
# Exemplo com API key (quando implementado)
curl -X POST http://localhost:5000/analyze/code \
  -H "Authorization: Bearer sua_api_key_aqui" \
  -H "Content-Type: application/json" \
  -d '{"code": "..."}'
```

## Exemplos de Integração

### 1. Python com requests

```python
import requests
import json

class COBOLAnalysisClient:
    def __init__(self, base_url="http://localhost:5000"):
        self.base_url = base_url
    
    def analyze_code(self, cobol_code, program_name="PROGRAMA", **options):
        """Analisa código COBOL via API."""
        url = f"{self.base_url}/analyze/code"
        
        payload = {
            "code": cobol_code,
            "program_name": program_name,
            "options": options
        }
        
        response = requests.post(url, json=payload)
        response.raise_for_status()
        
        return response.json()
    
    def analyze_file(self, file_path, **options):
        """Analisa arquivo COBOL via API."""
        url = f"{self.base_url}/analyze/file"
        
        with open(file_path, 'rb') as f:
            files = {'file': f}
            data = {'options': json.dumps(options)}
            
            response = requests.post(url, files=files, data=data)
            response.raise_for_status()
            
            return response.json()
    
    def get_available_models(self):
        """Lista modelos disponíveis."""
        url = f"{self.base_url}/models"
        response = requests.get(url)
        response.raise_for_status()
        
        return response.json()['models']
    
    def get_system_status(self):
        """Obtém status do sistema."""
        url = f"{self.base_url}/status"
        response = requests.get(url)
        response.raise_for_status()
        
        return response.json()

# Uso
client = COBOLAnalysisClient()

# Analisar código
result = client.analyze_code("""
IDENTIFICATION DIVISION.
PROGRAM-ID. TESTE.
DATA DIVISION.
PROCEDURE DIVISION.
DISPLAY 'HELLO WORLD'.
STOP RUN.
""", program_name="TESTE")

print(result['result']['content'])

# Verificar modelos
models = client.get_available_models()
print("Modelos disponíveis:", models)
```

### 2. JavaScript/Node.js

```javascript
const axios = require('axios');
const FormData = require('form-data');
const fs = require('fs');

class COBOLAnalysisClient {
    constructor(baseUrl = 'http://localhost:5000') {
        this.baseUrl = baseUrl;
    }
    
    async analyzeCode(cobolCode, programName = 'PROGRAMA', options = {}) {
        const url = `${this.baseUrl}/analyze/code`;
        
        const payload = {
            code: cobolCode,
            program_name: programName,
            options: options
        };
        
        try {
            const response = await axios.post(url, payload);
            return response.data;
        } catch (error) {
            throw new Error(`Erro na análise: ${error.response?.data?.error || error.message}`);
        }
    }
    
    async analyzeFile(filePath, options = {}) {
        const url = `${this.baseUrl}/analyze/file`;
        
        const form = new FormData();
        form.append('file', fs.createReadStream(filePath));
        form.append('options', JSON.stringify(options));
        
        try {
            const response = await axios.post(url, form, {
                headers: form.getHeaders()
            });
            return response.data;
        } catch (error) {
            throw new Error(`Erro na análise: ${error.response?.data?.error || error.message}`);
        }
    }
    
    async getAvailableModels() {
        const url = `${this.baseUrl}/models`;
        
        try {
            const response = await axios.get(url);
            return response.data.models;
        } catch (error) {
            throw new Error(`Erro ao obter modelos: ${error.response?.data?.error || error.message}`);
        }
    }
}

// Uso
const client = new COBOLAnalysisClient();

(async () => {
    try {
        // Analisar código
        const result = await client.analyzeCode(`
            IDENTIFICATION DIVISION.
            PROGRAM-ID. TESTE.
            DATA DIVISION.
            PROCEDURE DIVISION.
            DISPLAY 'HELLO WORLD'.
            STOP RUN.
        `, 'TESTE');
        
        console.log(result.result.content);
        
        // Verificar modelos
        const models = await client.getAvailableModels();
        console.log('Modelos disponíveis:', models);
        
    } catch (error) {
        console.error('Erro:', error.message);
    }
})();
```

### 3. cURL Scripts

```bash
#!/bin/bash
# analyze_cobol.sh

API_BASE="http://localhost:5000"
COBOL_FILE="$1"
OUTPUT_FILE="$2"

if [ -z "$COBOL_FILE" ] || [ -z "$OUTPUT_FILE" ]; then
    echo "Uso: $0 <arquivo_cobol> <arquivo_saida>"
    exit 1
fi

# Verificar se API está funcionando
echo "Verificando API..."
curl -s "$API_BASE/health" | jq -r '.status' || {
    echo "Erro: API não está respondendo"
    exit 1
}

# Analisar arquivo
echo "Analisando $COBOL_FILE..."
curl -X POST "$API_BASE/analyze/file" \
    -F "file=@$COBOL_FILE" \
    -F 'options={"model": "aws_claude_3_5_sonnet"}' \
    -o "$OUTPUT_FILE.json"

# Extrair conteúdo da análise
jq -r '.result.content' "$OUTPUT_FILE.json" > "$OUTPUT_FILE"

echo "Análise concluída: $OUTPUT_FILE"
echo "Tokens utilizados: $(jq -r '.result.tokens_used' "$OUTPUT_FILE.json")"
echo "Custo: $$(jq -r '.result.cost' "$OUTPUT_FILE.json")"
```

## Monitoramento e Logs

### 1. Logs da API

Os logs da API são salvos em:
- Console: Logs em tempo real
- Arquivo: `logs/api_server.log` (se configurado)

### 2. Métricas Personalizadas

```python
# Exemplo de coleta de métricas
import requests
import time
import json

def collect_metrics():
    """Coleta métricas da API periodicamente."""
    while True:
        try:
            response = requests.get('http://localhost:5000/metrics')
            metrics = response.json()
            
            # Salvar métricas
            with open('logs/api_metrics.json', 'a') as f:
                json.dump({
                    'timestamp': time.time(),
                    'metrics': metrics
                }, f)
                f.write('\n')
            
            print(f"Métricas coletadas: {metrics['api_stats']['requests_total']} requisições")
            
        except Exception as e:
            print(f"Erro ao coletar métricas: {e}")
        
        time.sleep(60)  # A cada minuto

if __name__ == '__main__':
    collect_metrics()
```

### 3. Health Check Automatizado

```bash
#!/bin/bash
# health_check.sh

API_URL="http://localhost:5000"

# Verificar health
HEALTH=$(curl -s "$API_URL/health" | jq -r '.status')

if [ "$HEALTH" = "healthy" ]; then
    echo "OK: API funcionando normalmente"
    exit 0
else
    echo "CRITICAL: API não está saudável"
    exit 2
fi
```

## Configuração para Produção

### 1. Configuração de Performance

```yaml
# config/config_production.yaml
api:
  host: "0.0.0.0"
  port: 5000
  workers: 4
  timeout: 300
  max_content_length: 52428800  # 50MB
  
  rate_limiting:
    enabled: true
    requests_per_minute: 100
    burst_size: 20
  
  cors:
    enabled: true
    origins: ["https://app.exemplo.com"]
    methods: ["GET", "POST"]
    headers: ["Content-Type", "Authorization"]

logging:
  level: "INFO"
  file: "/var/log/cobol_to_docs/api.log"
  max_size_mb: 100
  backup_count: 10
  format: "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
```

### 2. Proxy Reverso (Nginx)

```nginx
upstream cobol_api {
    server 127.0.0.1:5000;
    server 127.0.0.1:5001 backup;
}

server {
    listen 80;
    server_name api.cobol-docs.exemplo.com;
    
    client_max_body_size 50M;
    client_body_timeout 300s;
    
    location / {
        proxy_pass http://cobol_api;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        proxy_connect_timeout 30s;
        proxy_send_timeout 300s;
        proxy_read_timeout 300s;
    }
    
    location /health {
        proxy_pass http://cobol_api;
        access_log off;
    }
}
```

### 3. Containerização (Docker)

```dockerfile
# Dockerfile
FROM python:3.11-slim

WORKDIR /app

COPY requirements-full.txt .
RUN pip install -r requirements-full.txt

COPY . .

EXPOSE 5000

CMD ["python", "api_server.py", "--host", "0.0.0.0", "--port", "5000"]
```

```yaml
# docker-compose.yml
version: '3.8'

services:
  cobol-api:
    build: .
    ports:
      - "5000:5000"
    environment:
      - LUZIA_API_KEY=${LUZIA_API_KEY}
      - OPENAI_API_KEY=${OPENAI_API_KEY}
    volumes:
      - ./config:/app/config
      - ./data:/app/data
      - ./logs:/app/logs
      - ./cache:/app/cache
    restart: unless-stopped
    
  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf
    depends_on:
      - cobol-api
    restart: unless-stopped
```

## Troubleshooting

### Problemas Comuns

1. **API não inicia**
   ```bash
   # Verificar dependências
   pip install flask werkzeug
   
   # Verificar porta em uso
   netstat -tulpn | grep :5000
   ```

2. **Timeout em análises**
   ```yaml
   # config/config.yaml
   ai:
     models:
       aws_claude_3_5_sonnet:
         timeout: 300  # 5 minutos
   ```

3. **Erro de memória**
   ```yaml
   # config/config.yaml
   performance:
     max_workers: 2
     cache_max_size_mb: 100
   ```

4. **Problemas de CORS**
   ```python
   # api_server.py
   from flask_cors import CORS
   
   app = Flask(__name__)
   CORS(app, origins=['https://app.exemplo.com'])
   ```

---

**COBOL to Docs v1.6** - Guia Completo da API REST
