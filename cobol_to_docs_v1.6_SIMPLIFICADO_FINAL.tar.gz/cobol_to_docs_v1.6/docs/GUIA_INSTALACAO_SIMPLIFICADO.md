# Guia de Instalação - COBOL to Docs v1.6

Este guia apresenta as três formas principais de usar o COBOL to Docs v1.6: via pip install, CLI e biblioteca Python.

## Instalação via pip

### Instalação Básica

```bash
pip install cobol-to-docs
```

Esta instalação inclui todas as funcionalidades essenciais:
- Sistema RAG com base de conhecimento COBOL
- Providers Enhanced Mock e Basic (sempre funcionais)
- Interface de linha de comando
- Biblioteca Python completa

### Instalação com Provedores Específicos

```bash
# Para usar GitHub Copilot
pip install cobol-to-docs[github]

# Para usar OpenAI
pip install cobol-to-docs[openai]

# Para usar AWS Bedrock
pip install cobol-to-docs[bedrock]

# Instalação completa (todos os provedores)
pip install cobol-to-docs[full]
```

### Verificar Instalação

```bash
cobol-to-docs --version
cobol-to-docs --status
```

## Configuração de Credenciais

### GitHub Copilot

```bash
export GITHUB_TOKEN="seu_token_github"
```

### OpenAI

```bash
export OPENAI_API_KEY="sua_chave_openai"
```

### LuzIA (Santander)

```bash
export LUZIA_CLIENT_ID="seu_client_id"
export LUZIA_CLIENT_SECRET="seu_client_secret"
```

### AWS Bedrock

```bash
export AWS_ACCESS_KEY_ID="seu_access_key"
export AWS_SECRET_ACCESS_KEY="sua_secret_key"
export AWS_REGION="us-east-1"
```

## Uso via CLI (Linha de Comando)

### Comandos Básicos

```bash
# Analisar um arquivo COBOL
cobol-to-docs --file programa.cbl

# Analisar múltiplos arquivos
cobol-to-docs --files lista_arquivos.txt

# Especificar diretório de saída
cobol-to-docs --file programa.cbl --output ./documentacao

# Usar modelo específico
cobol-to-docs --file programa.cbl --model github_copilot
```

### Opções Avançadas

```bash
# Desabilitar RAG
cobol-to-docs --file programa.cbl --no-rag

# Desabilitar aprendizado automático
cobol-to-docs --file programa.cbl --no-auto-learn

# Saída detalhada
cobol-to-docs --file programa.cbl --verbose

# Verificar status do sistema
cobol-to-docs --status
```

### Exemplos Práticos

```bash
# Análise básica com mock (sempre funciona)
cobol-to-docs --file sistema.cbl --model enhanced_mock

# Análise com GitHub Copilot
cobol-to-docs --file sistema.cbl --model github_copilot --output ./docs

# Processar lista de arquivos
echo "programa1.cbl" > arquivos.txt
echo "programa2.cbl" >> arquivos.txt
cobol-to-docs --files arquivos.txt --output ./analise_completa
```

## Uso como Biblioteca Python

### Importação e Inicialização

```python
from cobol_to_docs import COBOLAnalyzer

# Inicializar com configuração padrão
analyzer = COBOLAnalyzer()

# Inicializar com configuração personalizada
analyzer = COBOLAnalyzer(config_path="minha_config.yaml")
```

### Análise de Código

```python
# Analisar código COBOL diretamente
codigo = """
IDENTIFICATION DIVISION.
PROGRAM-ID. EXEMPLO.
DATA DIVISION.
WORKING-STORAGE SECTION.
01 WS-CONTADOR PIC 9(3).
PROCEDURE DIVISION.
MOVE 1 TO WS-CONTADOR.
DISPLAY "Contador: " WS-CONTADOR.
STOP RUN.
"""

resultado = analyzer.analyze_code(codigo, "EXEMPLO")
print(f"Modelo: {resultado.model}")
print(f"Documentação: {resultado.content}")
```

### Análise de Arquivos

```python
# Analisar arquivo único
resultado = analyzer.analyze_file("programa.cbl")

# Analisar múltiplos arquivos
resultados = analyzer.analyze_multiple_files([
    "sistema1.cbl",
    "sistema2.cbl",
    "sistema3.cbl"
])

# Processar com opções específicas
resultado = analyzer.analyze_file(
    "programa.cbl",
    model="github_copilot",
    output_dir="./docs",
    disable_rag=False
)
```

### Monitoramento e Status

```python
# Verificar modelos disponíveis
modelos = analyzer.get_available_models()
print(f"Modelos disponíveis: {modelos}")

# Verificar status das dependências
deps = analyzer.get_dependency_status()
print(f"Dependências: {deps['installed_count']}/{deps['total_dependencies']}")

# Obter métricas de performance
metricas = analyzer.get_performance_metrics()
print(f"Análises realizadas: {metricas.get('total_analyses', 0)}")
```

## Uso do Script Principal (main.py)

### Para Desenvolvimento e Testes

```bash
# Clonar repositório
git clone https://github.com/cobol-to-docs/cobol-to-docs.git
cd cobol-to-docs

# Instalar dependências
pip install -r requirements.txt

# Usar script principal
python main.py --fontes arquivos.txt --models enhanced_mock --output ./resultado
```

### Opções do main.py

```bash
# Análise com modelo específico
python main.py --fontes lista.txt --models github_copilot --output ./docs

# Análise com múltiplos modelos
python main.py --fontes lista.txt --models "enhanced_mock,github_copilot" --output ./docs

# Configuração personalizada
python main.py --fontes lista.txt --config minha_config.yaml --output ./docs
```

## Estrutura de Arquivos de Entrada

### Lista de Arquivos (para --files)

```text
# Arquivo: lista_programas.txt
sistema_pagamento.cbl
sistema_cliente.cbl
sistema_conta.cbl
utilitarios.cbl
```

### Estrutura de Projeto Recomendada

```
projeto_cobol/
├── fontes/
│   ├── sistema1.cbl
│   ├── sistema2.cbl
│   └── copybooks/
│       ├── copy1.cpy
│       └── copy2.cpy
├── lista_arquivos.txt
└── documentacao/
    └── (gerada automaticamente)
```

## Troubleshooting

### Problemas Comuns

**"Nenhum modelo disponível"**
- Verifique se as credenciais estão configuradas
- Use `enhanced_mock` para testes sem credenciais
- Execute `cobol-to-docs --status` para diagnóstico

**"Erro de importação"**
- Reinstale com `pip install --upgrade cobol-to-docs`
- Para funcionalidades completas: `pip install cobol-to-docs[full]`

**"Timeout nas requisições"**
- Use modelos mais rápidos (enhanced_mock, basic)
- Ajuste timeout no arquivo de configuração
- Verifique conectividade de rede

### Comandos de Diagnóstico

```bash
# Verificar instalação
pip show cobol-to-docs

# Verificar status completo
cobol-to-docs --status

# Teste básico
cobol-to-docs --file exemplo.cbl --model enhanced_mock --verbose
```

### Logs e Debug

```bash
# Executar com logs detalhados
cobol-to-docs --file programa.cbl --verbose

# Verificar logs (se configurado)
tail -f logs/cobol_to_docs.log
```

## Próximos Passos

Após a instalação e configuração:

1. **Teste básico**: Execute uma análise simples com `enhanced_mock`
2. **Configure credenciais**: Adicione tokens para provedores desejados
3. **Explore funcionalidades**: Teste diferentes modelos e opções
4. **Integre ao workflow**: Incorpore ao seu processo de documentação

Para documentação completa e exemplos avançados, consulte o README.md e a documentação técnica.
