# COBOL to Docs v1.6

Sistema avançado de análise e documentação automatizada de programas COBOL com suporte a múltiplos provedores de IA, sistema RAG inteligente e GitHub Copilot.

## Características Principais

**Análise Inteligente de Código COBOL**
O sistema analisa programas COBOL e gera documentação técnica detalhada, identificando estruturas, lógica de negócio, fluxos de dados e padrões arquiteturais.

**Sistema RAG (Retrieval-Augmented Generation)**
Base de conhecimento especializada em COBOL que enriquece as análises com padrões conhecidos, melhores práticas e regras de negócio específicas do domínio bancário e mainframe.

**Múltiplos Provedores de IA**
Suporte integrado para LuzIA, GitHub Copilot, OpenAI, AWS Bedrock e outros provedores, com sistema de fallback automático e seleção inteligente de modelos.

**Aprendizado Automático**
O sistema aprende continuamente com cada análise, expandindo automaticamente a base de conhecimento RAG para melhorar análises futuras.

## Instalação

### Instalação Básica via pip

```bash
pip install cobol-to-docs
```

### Instalação com Provedores Específicos

```bash
# Com suporte ao OpenAI
pip install cobol-to-docs[openai]

# Com suporte ao AWS Bedrock
pip install cobol-to-docs[bedrock]

# Com suporte ao GitHub Copilot
pip install cobol-to-docs[github]

# Instalação completa com todos os provedores
pip install cobol-to-docs[full]
```

### Instalação para Desenvolvimento

```bash
git clone https://github.com/cobol-to-docs/cobol-to-docs.git
cd cobol-to-docs
pip install -e .
```

## Configuração

### Variáveis de Ambiente

```bash
# LuzIA (Santander)
export LUZIA_CLIENT_ID="seu_client_id"
export LUZIA_CLIENT_SECRET="seu_client_secret"

# GitHub Copilot
export GITHUB_TOKEN="seu_github_token"

# OpenAI
export OPENAI_API_KEY="sua_api_key"

# AWS Bedrock
export AWS_ACCESS_KEY_ID="seu_access_key"
export AWS_SECRET_ACCESS_KEY="sua_secret_key"
export AWS_REGION="us-east-1"
```

### Arquivo de Configuração

O sistema utiliza o arquivo `config/config.yaml` para configurações avançadas. Você pode personalizar provedores, modelos, timeouts e outras opções.

## Uso

### Interface de Linha de Comando

```bash
# Analisar um arquivo único
cobol-to-docs --file programa.cbl

# Analisar múltiplos arquivos
cobol-to-docs --files lista_arquivos.txt

# Especificar modelo e diretório de saída
cobol-to-docs --file programa.cbl --model github_copilot --output ./docs

# Verificar status do sistema
cobol-to-docs --status
```

### Como Biblioteca Python

```python
from cobol_to_docs import COBOLAnalyzer

# Inicializar analyzer
analyzer = COBOLAnalyzer()

# Analisar código COBOL
codigo_cobol = """
IDENTIFICATION DIVISION.
PROGRAM-ID. EXEMPLO.
PROCEDURE DIVISION.
DISPLAY "Hello World".
STOP RUN.
"""

resultado = analyzer.analyze_code(codigo_cobol, "EXEMPLO")
print(f"Modelo usado: {resultado.model}")
print(f"Documentação: {resultado.content}")

# Analisar arquivo
resultado = analyzer.analyze_file("programa.cbl")

# Analisar múltiplos arquivos
resultados = analyzer.analyze_multiple_files(["prog1.cbl", "prog2.cbl"])
```

### Script Principal (main.py)

```bash
# Usar o script principal diretamente
python main.py --fontes arquivos.txt --models enhanced_mock --output ./resultado
```

## Provedores Suportados

**LuzIA (Santander)**
Integração com a plataforma LuzIA do Santander, oferecendo modelos Claude 3.5 Sonnet e Haiku otimizados para análise de código.

**GitHub Copilot**
Suporte completo ao GitHub Copilot via API, permitindo análises com modelos GPT-4 e GPT-3.5 Turbo.

**OpenAI**
Integração direta com OpenAI para acesso aos modelos GPT-4, GPT-4 Turbo e GPT-3.5 Turbo.

**AWS Bedrock**
Suporte aos modelos Claude 3 Sonnet, Claude 3 Haiku e Amazon Titan via AWS Bedrock.

**Enhanced Mock**
Provider de desenvolvimento que simula respostas reais, ideal para testes e desenvolvimento.

**Basic Fallback**
Provider básico que garante funcionamento mesmo sem conectividade externa.

## Sistema RAG

O sistema RAG (Retrieval-Augmented Generation) mantém uma base de conhecimento especializada que inclui:

- Padrões comuns de programação COBOL
- Melhores práticas de desenvolvimento mainframe
- Regras de negócio específicas do setor bancário
- Estruturas de dados e arquivos típicos
- Convenções de nomenclatura e documentação

A base de conhecimento é automaticamente expandida com cada análise, criando um sistema que melhora continuamente.

## Estrutura de Saída

O sistema gera documentação estruturada incluindo:

- **Análise Funcional**: Descrição detalhada da funcionalidade do programa
- **Estrutura de Dados**: Mapeamento de variáveis e estruturas
- **Fluxo de Execução**: Descrição da lógica e fluxos de controle
- **Regras de Negócio**: Identificação de regras e validações
- **Dependências**: Análise de copybooks e chamadas externas
- **Métricas**: Estatísticas de complexidade e qualidade

## Exemplos Avançados

### Análise com Configuração Personalizada

```python
from cobol_to_docs import COBOLAnalyzer

# Configuração personalizada
analyzer = COBOLAnalyzer(config_path="minha_config.yaml")

# Análise com opções específicas
resultado = analyzer.analyze_code(
    codigo_cobol,
    program_name="SISTEMA-PAGAMENTO",
    model="github_copilot",
    disable_rag=False,
    auto_learn=True
)
```

### Processamento em Lote

```python
# Processar múltiplos arquivos com paralelização
resultados = analyzer.analyze_multiple_files(
    ["sistema1.cbl", "sistema2.cbl", "sistema3.cbl"],
    parallel=True,
    max_workers=4
)

# Gerar relatório consolidado
relatorio = analyzer.generate_consolidated_report(resultados)
```

### Monitoramento e Métricas

```python
# Obter métricas de performance
metricas = analyzer.get_performance_metrics()
print(f"Análises realizadas: {metricas['total_analyses']}")
print(f"Tempo médio: {metricas['average_time']:.2f}s")

# Status das dependências
deps = analyzer.get_dependency_status()
print(f"Dependências instaladas: {deps['installed_count']}/{deps['total_dependencies']}")
```

## Troubleshooting

### Problemas Comuns

**Nenhum modelo disponível**
Verifique se as credenciais estão configuradas corretamente ou use o provider enhanced_mock para testes.

**Erro de importação**
Certifique-se de que todas as dependências estão instaladas. Use `pip install cobol-to-docs[full]` para instalação completa.

**Timeout nas requisições**
Ajuste os valores de timeout no arquivo de configuração ou use modelos mais rápidos.

### Logs e Debugging

```bash
# Executar com saída detalhada
cobol-to-docs --file programa.cbl --verbose

# Verificar logs do sistema
tail -f logs/cobol_to_docs.log
```

## Contribuição

Contribuições são bem-vindas! Por favor, consulte o guia de contribuição e as diretrizes de desenvolvimento.

## Licença

Este projeto está licenciado sob a Licença MIT. Consulte o arquivo LICENSE para detalhes.

## Suporte

Para suporte técnico, dúvidas ou sugestões:
- Abra uma issue no GitHub
- Consulte a documentação completa
- Entre em contato com a equipe de desenvolvimento

---

**COBOL to Docs v1.6** - Transformando código legado em documentação moderna
