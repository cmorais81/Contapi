"""
CLI para COBOL to Docs v1.6
Interface de linha de comando simplificada
"""

import sys
import os
import argparse
from pathlib import Path

# Adicionar src ao path para imports
sys.path.insert(0, str(Path(__file__).parent.parent))

from cobol_to_docs import COBOLAnalyzer

def main():
    """Função principal do CLI."""
    parser = argparse.ArgumentParser(
        description='COBOL to Docs v1.6 - Análise e documentação automatizada de programas COBOL',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Exemplos de uso:
  cobol-to-docs --file programa.cbl
  cobol-to-docs --files lista_arquivos.txt --model enhanced_mock
  cobol-to-docs --file programa.cbl --output ./docs --model github_copilot
  
Provedores disponíveis:
  - luzia (LuzIA - requer credenciais)
  - enhanced_mock (Mock avançado - sempre disponível)
  - basic (Fallback básico)
  - github_copilot (GitHub Copilot - requer GITHUB_TOKEN)
  - openai (OpenAI - requer OPENAI_API_KEY)
  - bedrock (AWS Bedrock - requer credenciais AWS)
        """
    )
    
    # Argumentos principais
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--file', '-f', 
                      help='Arquivo COBOL único para análise')
    group.add_argument('--files', '-F', 
                      help='Arquivo texto com lista de arquivos COBOL')
    
    # Configurações
    parser.add_argument('--output', '-o', 
                       default='./output',
                       help='Diretório de saída (padrão: ./output)')
    
    parser.add_argument('--model', '-m',
                       help='Modelo específico para usar (ex: enhanced_mock, github_copilot)')
    
    parser.add_argument('--config', '-c',
                       help='Arquivo de configuração personalizado')
    
    # Opções avançadas
    parser.add_argument('--no-rag', 
                       action='store_true',
                       help='Desabilitar sistema RAG')
    
    parser.add_argument('--no-auto-learn', 
                       action='store_true',
                       help='Desabilitar aprendizado automático')
    
    parser.add_argument('--verbose', '-v', 
                       action='store_true',
                       help='Saída detalhada')
    
    parser.add_argument('--version', 
                       action='version',
                       version='COBOL to Docs v1.6.0')
    
    # Status do sistema
    parser.add_argument('--status', 
                       action='store_true',
                       help='Mostrar status dos provedores e sair')
    
    args = parser.parse_args()
    
    try:
        # Inicializar analyzer
        if args.verbose:
            print("Inicializando COBOL to Docs v1.6...")
        
        analyzer = COBOLAnalyzer(config_path=args.config)
        
        # Mostrar status se solicitado
        if args.status:
            show_system_status(analyzer)
            return 0
        
        # Configurar opções
        options = {
            'output_dir': args.output,
            'disable_rag': args.no_rag,
            'auto_learn': not args.no_auto_learn,
            'verbose': args.verbose
        }
        
        if args.model:
            options['model'] = args.model
        
        # Processar arquivos
        if args.file:
            # Arquivo único
            result = analyzer.analyze_file(args.file, **options)
            print(f"✓ Análise concluída: {args.file}")
            print(f"  Modelo: {result.model}")
            print(f"  Tokens: {result.tokens_used}")
            print(f"  Tempo: {result.response_time:.2f}s")
            
        elif args.files:
            # Lista de arquivos
            results = analyzer.analyze_multiple_files_from_list(args.files, **options)
            print(f"✓ Análise concluída: {len(results)} arquivos processados")
            
            # Resumo
            total_tokens = sum(r.tokens_used for r in results.values())
            total_time = sum(r.response_time for r in results.values())
            print(f"  Total de tokens: {total_tokens}")
            print(f"  Tempo total: {total_time:.2f}s")
        
        print(f"\nDocumentação gerada em: {args.output}")
        return 0
        
    except KeyboardInterrupt:
        print("\nOperação cancelada pelo usuário.")
        return 1
        
    except Exception as e:
        print(f"Erro: {e}")
        if args.verbose:
            import traceback
            traceback.print_exc()
        return 1

def show_system_status(analyzer):
    """Mostra status detalhado do sistema."""
    print("=== COBOL to Docs v1.6 - Status do Sistema ===\n")
    
    # Status dos provedores
    print("Provedores disponíveis:")
    try:
        models = analyzer.get_available_models()
        if models:
            for model in models:
                print(f"  ✓ {model}")
        else:
            print("  ⚠ Nenhum modelo disponível")
    except Exception as e:
        print(f"  ✗ Erro ao verificar modelos: {e}")
    
    print()
    
    # Status das dependências
    print("Dependências opcionais:")
    try:
        deps = analyzer.get_dependency_status()
        for dep, status in deps.get('dependencies', {}).items():
            status_icon = "✓" if status else "✗"
            print(f"  {status_icon} {dep}")
    except Exception as e:
        print(f"  ✗ Erro ao verificar dependências: {e}")
    
    print()
    
    # Status do RAG
    print("Sistema RAG:")
    try:
        if analyzer.rag_integration and analyzer.rag_integration.is_enabled():
            stats = analyzer.rag_integration.get_rag_statistics()
            print(f"  ✓ Habilitado ({stats.get('total_items', 0)} itens na base)")
        else:
            print("  ✗ Desabilitado")
    except Exception as e:
        print(f"  ✗ Erro ao verificar RAG: {e}")

if __name__ == '__main__':
    sys.exit(main())
