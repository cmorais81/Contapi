"""
GitHub Copilot Provider - Integração com GitHub Copilot API
Permite usar GitHub Copilot para análise de código COBOL
"""

import os
import json
import logging
import requests
from typing import Dict, Any, Optional

# Import com path absoluto para evitar problemas
import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent.parent))

from .base_provider import BaseProvider
from ..models import AIRequest, AIResponse

class GitHubCopilotProvider(BaseProvider):
    """Provider para GitHub Copilot API."""
    
    def __init__(self, config: Dict[str, Any]):
        """
        Inicializa o provider GitHub Copilot.
        
        Args:
            config: Configuração do provider
        """
        super().__init__(config)
        self.logger = logging.getLogger(__name__)
        
        # Configurações específicas do GitHub Copilot
        self.api_token = config.get('api_token') or os.getenv('GITHUB_TOKEN')
        self.api_url = config.get('api_url', 'https://api.github.com/copilot/chat/completions')
        self.model = config.get('model', 'gpt-4')
        self.max_tokens = config.get('max_tokens', 4096)
        self.temperature = config.get('temperature', 0.1)
        self.timeout = config.get('timeout', 120)
        
        # Headers para autenticação
        self.headers = {
            'Authorization': f'Bearer {self.api_token}' if self.api_token else '',
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'User-Agent': 'COBOL-to-Docs/1.6.0',
            'X-GitHub-Api-Version': '2022-11-28'
        }
        
        # Validar configuração
        if not self.api_token:
            self.logger.warning("GitHub token não configurado - provider ficará indisponível")
            self.logger.warning("Configure GITHUB_TOKEN ou api_token na configuração")
        
        self.logger.info(f"GitHub Copilot configurado: modelo={self.model}, timeout={self.timeout}s")
        self.logger.info(f"API URL: {self.api_url}")
        self.logger.info("GitHub Copilot Provider inicializado")
    
    def is_available(self) -> bool:
        """
        Verifica se o provider está disponível.
        
        Returns:
            True se disponível, False caso contrário
        """
        if not self.api_token:
            return False
        
        try:
            # Teste simples de conectividade
            test_url = "https://api.github.com/user"
            response = requests.get(
                test_url,
                headers={'Authorization': f'Bearer {self.api_token}'},
                timeout=10
            )
            
            if response.status_code == 200:
                self.logger.debug("GitHub Copilot provider disponível")
                return True
            else:
                self.logger.warning(f"GitHub API retornou status {response.status_code}")
                return False
                
        except Exception as e:
            self.logger.error(f"Erro ao verificar disponibilidade do GitHub Copilot: {e}")
            return False
    
    def analyze(self, request: AIRequest) -> AIResponse:
        """
        Realiza análise usando GitHub Copilot.
        
        Args:
            request: Requisição de análise
            
        Returns:
            Resposta da análise
        """
        try:
            self.logger.info(f"Iniciando análise com GitHub Copilot: {request.program_name}")
            
            # Preparar payload para GitHub Copilot
            payload = {
                "model": self.model,
                "messages": [
                    {
                        "role": "system",
                        "content": "Você é um especialista em análise de código COBOL. Analise o código fornecido e gere documentação técnica detalhada em português brasileiro."
                    },
                    {
                        "role": "user",
                        "content": request.prompt
                    }
                ],
                "max_tokens": self.max_tokens,
                "temperature": self.temperature,
                "stream": False
            }
            
            self.logger.debug(f"Payload preparado para GitHub Copilot: {json.dumps(payload, indent=2)}")
            
            # Fazer requisição
            response = requests.post(
                self.api_url,
                headers=self.headers,
                json=payload,
                timeout=self.timeout
            )
            
            self.logger.debug(f"Status da resposta GitHub Copilot: {response.status_code}")
            
            if response.status_code == 200:
                response_data = response.json()
                
                # Extrair conteúdo da resposta
                content = ""
                if 'choices' in response_data and len(response_data['choices']) > 0:
                    content = response_data['choices'][0]['message']['content']
                
                # Calcular tokens usados
                tokens_used = response_data.get('usage', {}).get('total_tokens', 0)
                
                # Estimar custo (GitHub Copilot tem preços específicos)
                cost = self._calculate_cost(tokens_used)
                
                self.logger.info(f"Análise GitHub Copilot concluída: {tokens_used} tokens, custo: ${cost:.4f}")
                
                return AIResponse(
                    content=content,
                    model=self.model,
                    provider="github_copilot",
                    tokens_used=tokens_used,
                    cost=cost,
                    response_time=0.0,  # Será calculado externamente
                    success=True,
                    raw_response=response_data
                )
            
            else:
                error_msg = f"Erro na API GitHub Copilot: {response.status_code}"
                try:
                    error_data = response.json()
                    if 'error' in error_data:
                        error_msg += f" - {error_data['error'].get('message', 'Erro desconhecido')}"
                except:
                    error_msg += f" - {response.text}"
                
                self.logger.error(error_msg)
                
                return AIResponse(
                    content="",
                    model=self.model,
                    provider="github_copilot",
                    tokens_used=0,
                    cost=0.0,
                    response_time=0.0,
                    success=False,
                    error=error_msg
                )
        
        except requests.exceptions.Timeout:
            error_msg = f"Timeout na requisição GitHub Copilot após {self.timeout}s"
            self.logger.error(error_msg)
            
            return AIResponse(
                content="",
                model=self.model,
                provider="github_copilot",
                tokens_used=0,
                cost=0.0,
                response_time=0.0,
                success=False,
                error=error_msg
            )
        
        except Exception as e:
            error_msg = f"Erro inesperado no GitHub Copilot: {str(e)}"
            self.logger.error(error_msg)
            
            return AIResponse(
                content="",
                model=self.model,
                provider="github_copilot",
                tokens_used=0,
                cost=0.0,
                response_time=0.0,
                success=False,
                error=error_msg
            )
    
    def _calculate_cost(self, tokens_used: int) -> float:
        """
        Calcula o custo estimado baseado nos tokens usados.
        
        Args:
            tokens_used: Número de tokens utilizados
            
        Returns:
            Custo estimado em USD
        """
        # GitHub Copilot tem preços específicos
        # Valores aproximados baseados no modelo usado
        if self.model.startswith('gpt-4'):
            # GPT-4 via GitHub Copilot
            cost_per_1k_tokens = 0.03  # Estimativa
        else:
            # Outros modelos
            cost_per_1k_tokens = 0.002  # Estimativa
        
        return (tokens_used / 1000) * cost_per_1k_tokens
    
    def get_model_info(self) -> Dict[str, Any]:
        """
        Retorna informações sobre o modelo.
        
        Returns:
            Informações do modelo
        """
        return {
            'name': self.model,
            'provider': 'github_copilot',
            'max_tokens': self.max_tokens,
            'temperature': self.temperature,
            'timeout': self.timeout,
            'api_url': self.api_url,
            'available': self.is_available()
        }
    
    def get_provider_stats(self) -> Dict[str, Any]:
        """
        Retorna estatísticas do provider.
        
        Returns:
            Estatísticas do provider
        """
        return {
            'provider': 'github_copilot',
            'model': self.model,
            'api_url': self.api_url,
            'configured': bool(self.api_token),
            'available': self.is_available(),
            'max_tokens': self.max_tokens,
            'temperature': self.temperature,
            'timeout': self.timeout
        }
