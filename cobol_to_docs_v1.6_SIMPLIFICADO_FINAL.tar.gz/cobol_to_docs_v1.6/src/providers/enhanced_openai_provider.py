"""
Provider OpenAI Aprimorado
Provider OpenAI com instalação automática de dependências e recursos avançados.
"""

import logging
import time
from typing import Dict, Any, Optional, List
from src.utils.dependency_manager import dependency_manager

logger = logging.getLogger(__name__)

class EnhancedOpenAIProvider:
    """
    Provider OpenAI aprimorado com instalação automática de dependências.
    
    Funcionalidades:
    - Instalação automática da biblioteca OpenAI
    - Suporte a múltiplos modelos GPT
    - Tratamento robusto de erros
    - Métricas de performance
    - Compatibilidade com interface existente
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Inicializa o provider OpenAI aprimorado.
        
        Args:
            config: Configuração do provider
        """
        self.config = config
        self.client = None
        self.available = False
        self.models = {}
        self.performance_metrics = {
            'requests_made': 0,
            'total_tokens': 0,
            'total_cost': 0.0,
            'avg_response_time': 0.0,
            'errors': 0
        }
        
        # Tentar inicializar
        self._initialize()
    
    def _initialize(self):
        """Inicializa o provider com verificação de dependências."""
        try:
            # Verificar se OpenAI está instalado
            deps_status = dependency_manager.check_provider_dependencies('openai')
            
            if not deps_status['is_available']:
                logger.warning("Biblioteca OpenAI não encontrada. Tentando instalação automática...")
                
                # Tentar instalação automática
                install_result = dependency_manager.auto_install_for_provider('openai')
                
                if not install_result['success']:
                    logger.error(f"Falha na instalação automática do OpenAI: {install_result}")
                    self._setup_fallback()
                    return
                
                logger.info("Biblioteca OpenAI instalada automaticamente")
            
            # Importar e configurar OpenAI
            import openai
            
            api_key = self.config.get('api_key')
            if not api_key:
                logger.error("API key do OpenAI não configurada")
                self._setup_fallback()
                return
            
            # Configurar cliente
            self.client = openai.OpenAI(api_key=api_key)
            
            # Configurar modelos
            self.models = self.config.get('models', {})
            
            # Testar conectividade
            if self._test_connection():
                self.available = True
                logger.info(f"Enhanced OpenAI Provider inicializado com {len(self.models)} modelos")
            else:
                self._setup_fallback()
                
        except Exception as e:
            logger.error(f"Erro ao inicializar Enhanced OpenAI Provider: {e}")
            self._setup_fallback()
    
    def _setup_fallback(self):
        """Configura modo fallback quando OpenAI não está disponível."""
        self.available = False
        self.client = None
        logger.warning("Enhanced OpenAI Provider em modo fallback - funcionalidade limitada")
    
    def _test_connection(self) -> bool:
        """
        Testa conectividade com a API OpenAI.
        
        Returns:
            True se a conexão foi bem-sucedida
        """
        try:
            # Fazer uma requisição simples para testar
            response = self.client.models.list()
            logger.debug("Teste de conectividade OpenAI bem-sucedido")
            return True
            
        except Exception as e:
            logger.error(f"Falha no teste de conectividade OpenAI: {e}")
            return False
    
    def is_available(self) -> bool:
        """
        Verifica se o provider está disponível.
        
        Returns:
            True se disponível
        """
        return self.available
    
    def get_available_models(self) -> List[str]:
        """
        Obtém lista de modelos disponíveis.
        
        Returns:
            Lista de modelos disponíveis
        """
        if not self.available:
            return []
        
        return list(self.models.keys())
    
    def analyze(self, prompt: str, model_name: str = None, **kwargs) -> Dict[str, Any]:
        """
        Executa análise usando OpenAI.
        
        Args:
            prompt: Prompt para análise
            model_name: Nome do modelo (opcional)
            **kwargs: Argumentos adicionais
            
        Returns:
            Resultado da análise
        """
        if not self.available:
            raise RuntimeError("Enhanced OpenAI Provider não está disponível")
        
        # Selecionar modelo
        if not model_name:
            model_name = list(self.models.keys())[0] if self.models else 'gpt-3.5-turbo'
        
        if model_name not in self.models:
            raise ValueError(f"Modelo {model_name} não configurado")
        
        model_config = self.models[model_name]
        
        start_time = time.time()
        
        try:
            # Preparar parâmetros
            params = {
                'model': model_config.get('name', model_name),
                'messages': [{'role': 'user', 'content': prompt}],
                'max_tokens': model_config.get('max_tokens', 4096),
                'temperature': model_config.get('temperature', 0.1),
                'timeout': model_config.get('timeout', 120)
            }
            
            # Adicionar parâmetros extras
            params.update(kwargs)
            
            # Fazer requisição
            logger.debug(f"Enviando requisição para OpenAI modelo {model_name}")
            
            response = self.client.chat.completions.create(**params)
            
            # Processar resposta
            content = response.choices[0].message.content
            tokens_used = response.usage.total_tokens
            
            # Calcular custo (estimativa)
            cost = self._calculate_cost(model_name, tokens_used)
            
            # Atualizar métricas
            response_time = time.time() - start_time
            self._update_metrics(tokens_used, cost, response_time)
            
            logger.info(f"Análise OpenAI concluída: {tokens_used} tokens, {response_time:.2f}s")
            
            return {
                'content': content,
                'model': model_name,
                'tokens_used': tokens_used,
                'cost': cost,
                'response_time': response_time,
                'provider': 'enhanced_openai'
            }
            
        except Exception as e:
            self.performance_metrics['errors'] += 1
            logger.error(f"Erro na análise OpenAI: {e}")
            raise
    
    def _calculate_cost(self, model_name: str, tokens: int) -> float:
        """
        Calcula custo estimado da requisição.
        
        Args:
            model_name: Nome do modelo
            tokens: Número de tokens
            
        Returns:
            Custo estimado em USD
        """
        # Tabela de custos por 1K tokens (valores aproximados)
        cost_table = {
            'gpt-4': 0.03,
            'gpt-4-turbo': 0.01,
            'gpt-4-turbo-preview': 0.01,
            'gpt-3.5-turbo': 0.002,
            'gpt-3.5-turbo-16k': 0.004
        }
        
        model_config = self.models.get(model_name, {})
        model_api_name = model_config.get('name', model_name)
        
        cost_per_1k = cost_table.get(model_api_name, 0.002)  # Default para GPT-3.5
        
        return (tokens / 1000) * cost_per_1k
    
    def _update_metrics(self, tokens: int, cost: float, response_time: float):
        """
        Atualiza métricas de performance.
        
        Args:
            tokens: Tokens utilizados
            cost: Custo da requisição
            response_time: Tempo de resposta
        """
        self.performance_metrics['requests_made'] += 1
        self.performance_metrics['total_tokens'] += tokens
        self.performance_metrics['total_cost'] += cost
        
        # Calcular média de tempo de resposta
        total_requests = self.performance_metrics['requests_made']
        current_avg = self.performance_metrics['avg_response_time']
        self.performance_metrics['avg_response_time'] = (
            (current_avg * (total_requests - 1) + response_time) / total_requests
        )
    
    def get_performance_metrics(self) -> Dict[str, Any]:
        """
        Obtém métricas de performance.
        
        Returns:
            Métricas de performance
        """
        return {
            **self.performance_metrics,
            'available': self.available,
            'models_configured': len(self.models),
            'cost_per_request': (
                self.performance_metrics['total_cost'] / self.performance_metrics['requests_made']
                if self.performance_metrics['requests_made'] > 0 else 0
            ),
            'tokens_per_request': (
                self.performance_metrics['total_tokens'] / self.performance_metrics['requests_made']
                if self.performance_metrics['requests_made'] > 0 else 0
            )
        }
    
    def get_model_info(self, model_name: str) -> Dict[str, Any]:
        """
        Obtém informações sobre um modelo específico.
        
        Args:
            model_name: Nome do modelo
            
        Returns:
            Informações do modelo
        """
        if model_name not in self.models:
            return {}
        
        model_config = self.models[model_name]
        
        return {
            'name': model_name,
            'api_name': model_config.get('name'),
            'max_tokens': model_config.get('max_tokens'),
            'temperature': model_config.get('temperature'),
            'timeout': model_config.get('timeout'),
            'context_window': model_config.get('context_window'),
            'estimated_cost_per_1k_tokens': self._calculate_cost(model_name, 1000)
        }
    
    def list_available_models_from_api(self) -> List[Dict[str, Any]]:
        """
        Lista modelos disponíveis diretamente da API OpenAI.
        
        Returns:
            Lista de modelos disponíveis na API
        """
        if not self.available:
            return []
        
        try:
            response = self.client.models.list()
            models = []
            
            for model in response.data:
                if 'gpt' in model.id.lower():  # Filtrar apenas modelos GPT
                    models.append({
                        'id': model.id,
                        'created': model.created,
                        'owned_by': model.owned_by
                    })
            
            return sorted(models, key=lambda x: x['id'])
            
        except Exception as e:
            logger.error(f"Erro ao listar modelos da API OpenAI: {e}")
            return []
    
    def validate_configuration(self) -> Dict[str, Any]:
        """
        Valida configuração do provider.
        
        Returns:
            Resultado da validação
        """
        validation = {
            'valid': True,
            'issues': [],
            'recommendations': []
        }
        
        # Verificar API key
        if not self.config.get('api_key'):
            validation['valid'] = False
            validation['issues'].append("API key não configurada")
            validation['recommendations'].append("Configure OPENAI_API_KEY nas variáveis de ambiente")
        
        # Verificar modelos
        if not self.models:
            validation['issues'].append("Nenhum modelo configurado")
            validation['recommendations'].append("Configure pelo menos um modelo na seção 'models'")
        
        # Verificar conectividade
        if not self.available:
            validation['valid'] = False
            validation['issues'].append("Provider não disponível")
            validation['recommendations'].append("Verifique conectividade e dependências")
        
        return validation

def create_enhanced_openai_provider(config: Dict[str, Any]) -> EnhancedOpenAIProvider:
    """
    Cria provider OpenAI aprimorado.
    
    Args:
        config: Configuração do provider
        
    Returns:
        Instância do provider aprimorado
    """
    return EnhancedOpenAIProvider(config)
