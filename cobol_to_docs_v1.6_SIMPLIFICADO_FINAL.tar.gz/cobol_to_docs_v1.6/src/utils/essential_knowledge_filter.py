#!/usr/bin/env python3
"""
Filtro de Conhecimento Essencial
Implementa um filtro para destacar apenas o conhecimento essencial
nas análises, conforme feedback do especialista: "muita informação
esconde o que é realmente essencial."
"""

import re
import logging
from typing import Dict, List, Any, Optional, Set, Tuple

class EssentialKnowledgeFilter:
    """
    Filtro para destacar apenas o conhecimento essencial nas análises,
    removendo excesso de informação que obscurece o essencial.
    """
    
    def __init__(self):
        """Inicializa o filtro de conhecimento essencial."""
        self.logger = logging.getLogger(__name__)
        
        # Padrões para identificar seções de conhecimento
        self.knowledge_section_patterns = [
            r'(?:## |# )?Conhecimento Extraído(?:[^\n]*)\n(.*?)(?:##|#|$)',
            r'(?:## |# )?Aprendizado Automático(?:[^\n]*)\n(.*?)(?:##|#|$)',
            r'(?:## |# )?Padrões Identificados(?:[^\n]*)\n(.*?)(?:##|#|$)'
        ]
        
        # Critérios para determinar conhecimento essencial
        self.essential_criteria = [
            # Padrões de codificação específicos
            r'padrão\s+(?:de\s+)?codificação\s+(?:para|de|em)\s+([^.]+)',
            # Algoritmos específicos
            r'algoritmo\s+(?:de|para)\s+([^.]+)',
            # Estruturas de dados específicas
            r'estrutura\s+(?:de\s+)?dados\s+(?:para|de)\s+([^.]+)',
            # Técnicas de validação específicas
            r'técnica\s+(?:de\s+)?validação\s+(?:para|de)\s+([^.]+)',
            # Regras de negócio específicas
            r'regra\s+(?:de\s+)?negócio\s+(?:para|de)\s+([^.]+)'
        ]
        
        # Termos que indicam conhecimento não essencial
        self.non_essential_terms = [
            r'poderia\s+ser',
            r'talvez\s+seja',
            r'possivelmente',
            r'provavelmente',
            r'aparentemente',
            r'parece\s+(?:ser|que)',
            r'sugere\s+que',
            r'indica\s+que',
            r'pode\s+indicar',
            r'pode\s+sugerir'
        ]
    
    def filter_knowledge_section(self, content: str) -> str:
        """
        Filtra seções de conhecimento para destacar apenas o essencial.
        
        Args:
            content: Conteúdo da análise a ser filtrado
            
        Returns:
            Conteúdo com seções de conhecimento filtradas
        """
        try:
            filtered_content = content
            
            # Processar cada padrão de seção de conhecimento
            for pattern in self.knowledge_section_patterns:
                section_match = re.search(pattern, filtered_content, re.DOTALL | re.IGNORECASE)
                if section_match:
                    # Extrair a seção completa e seu conteúdo
                    full_section = section_match.group(0)
                    section_content = section_match.group(1)
                    
                    # Filtrar o conteúdo da seção
                    filtered_section_content = self._filter_section_content(section_content)
                    
                    # Reconstruir a seção com o conteúdo filtrado
                    section_start = full_section[:full_section.find(section_content)]
                    section_end = full_section[full_section.find(section_content) + len(section_content):]
                    filtered_section = section_start + filtered_section_content + section_end
                    
                    # Substituir a seção original pela filtrada
                    filtered_content = filtered_content.replace(full_section, filtered_section)
            
            return filtered_content
            
        except Exception as e:
            self.logger.error(f"Erro ao filtrar seção de conhecimento: {e}")
            return content
    
    def _filter_section_content(self, section_content: str) -> str:
        """
        Filtra o conteúdo de uma seção de conhecimento.
        
        Args:
            section_content: Conteúdo da seção a ser filtrado
            
        Returns:
            Conteúdo filtrado
        """
        # Dividir em parágrafos ou itens de lista
        items = re.split(r'(?:\r?\n){2,}|\r?\n(?:[-*]\s+)', section_content)
        
        # Filtrar itens
        essential_items = []
        for item in items:
            item = item.strip()
            if not item:
                continue
            
            # Verificar se o item contém conhecimento essencial
            if self._is_essential_knowledge(item):
                # Remover termos não essenciais
                for term in self.non_essential_terms:
                    item = re.sub(term, '', item, flags=re.IGNORECASE)
                
                essential_items.append(item)
        
        # Adicionar nota sobre filtragem
        if essential_items:
            filtered_content = "\n\n> **Nota técnica:** Esta seção foi filtrada para destacar apenas o conhecimento essencial.\n\n"
            
            # Reconstruir conteúdo com itens essenciais
            for item in essential_items:
                if item.startswith('-') or item.startswith('*'):
                    filtered_content += f"{item}\n"
                else:
                    filtered_content += f"- {item}\n"
            
            return filtered_content
        else:
            return "\n\n> **Nota técnica:** Nenhum conhecimento essencial específico identificado nesta análise.\n\n"
    
    def _is_essential_knowledge(self, item: str) -> bool:
        """
        Determina se um item contém conhecimento essencial.
        
        Args:
            item: Item a ser avaliado
            
        Returns:
            True se o item contém conhecimento essencial, False caso contrário
        """
        # Verificar critérios de essencialidade
        for criterion in self.essential_criteria:
            if re.search(criterion, item, re.IGNORECASE):
                return True
        
        # Verificar se o item contém termos não essenciais
        for term in self.non_essential_terms:
            if re.search(term, item, re.IGNORECASE):
                return False
        
        # Verificar se o item contém informações específicas
        # (números, valores, referências a linhas)
        if re.search(r'linha[s]?\s+\d+', item, re.IGNORECASE):
            return True
        if re.search(r'\b\d+(?:\.\d+)?\b', item):
            return True
        if re.search(r'PIC\s+[X9][^.]+', item, re.IGNORECASE):
            return True
        
        # Por padrão, considerar não essencial
        return False


# Função auxiliar para uso direto
def filter_essential_knowledge(content: str) -> str:
    """
    Filtra o conteúdo para destacar apenas o conhecimento essencial.
    
    Args:
        content: Conteúdo a ser filtrado
        
    Returns:
        Conteúdo com conhecimento essencial destacado
    """
    filter_instance = EssentialKnowledgeFilter()
    return filter_instance.filter_knowledge_section(content)


if __name__ == "__main__":
    # Teste simples
    import sys
    
    if len(sys.argv) > 1:
        input_file = sys.argv[1]
        try:
            with open(input_file, 'r', encoding='utf-8') as f:
                content = f.read()
            
            filter_instance = EssentialKnowledgeFilter()
            filtered_content = filter_instance.filter_knowledge_section(content)
            
            output_file = input_file.replace('.md', '_essential.md')
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(filtered_content)
            
            print(f"Conteúdo filtrado salvo em: {output_file}")
            
        except Exception as e:
            print(f"Erro: {e}")
    else:
        print("Uso: python essential_knowledge_filter.py arquivo.md")
