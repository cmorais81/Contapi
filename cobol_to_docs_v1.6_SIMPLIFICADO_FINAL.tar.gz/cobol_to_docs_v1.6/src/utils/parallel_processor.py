"""
Sistema de Processamento Paralelo
Implementa processamento paralelo para análises mantendo compatibilidade.
"""

import os
import logging
import threading
import multiprocessing
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor, as_completed
from typing import List, Dict, Any, Callable, Optional, Tuple
import time

logger = logging.getLogger(__name__)

class ParallelProcessor:
    """
    Sistema de processamento paralelo para análises COBOL.
    
    Funcionalidades:
    - Processamento paralelo de múltiplos arquivos
    - Balanceamento de carga inteligente
    - Monitoramento de progresso
    - Tratamento de erros robusto
    - Compatibilidade com sistema existente
    """
    
    def __init__(self, max_workers: Optional[int] = None, use_processes: bool = False):
        """
        Inicializa o processador paralelo.
        
        Args:
            max_workers: Número máximo de workers (None = auto)
            use_processes: Se True, usa processos; se False, usa threads
        """
        self.max_workers = max_workers or min(4, (os.cpu_count() or 1) + 1)
        self.use_processes = use_processes
        self.results = []
        self.errors = []
        
        logger.info(f"Processador paralelo inicializado: {self.max_workers} workers, "
                   f"tipo: {'processos' if use_processes else 'threads'}")
    
    def process_files_parallel(self, 
                             files: List[str], 
                             processor_func: Callable,
                             **kwargs) -> Dict[str, Any]:
        """
        Processa múltiplos arquivos em paralelo.
        
        Args:
            files: Lista de arquivos para processar
            processor_func: Função de processamento
            **kwargs: Argumentos adicionais para a função
            
        Returns:
            Resultados do processamento paralelo
        """
        start_time = time.time()
        results = {}
        errors = {}
        
        logger.info(f"Iniciando processamento paralelo de {len(files)} arquivos")
        
        # Escolher executor baseado na configuração
        executor_class = ProcessPoolExecutor if self.use_processes else ThreadPoolExecutor
        
        try:
            with executor_class(max_workers=self.max_workers) as executor:
                # Submeter tarefas
                future_to_file = {
                    executor.submit(self._safe_process_file, file_path, processor_func, **kwargs): file_path
                    for file_path in files
                }
                
                # Coletar resultados
                completed = 0
                for future in as_completed(future_to_file):
                    file_path = future_to_file[future]
                    completed += 1
                    
                    try:
                        result = future.result()
                        if result['success']:
                            results[file_path] = result['data']
                            logger.info(f"Processamento concluído ({completed}/{len(files)}): {os.path.basename(file_path)}")
                        else:
                            errors[file_path] = result['error']
                            logger.error(f"Erro no processamento ({completed}/{len(files)}): {os.path.basename(file_path)} - {result['error']}")
                            
                    except Exception as e:
                        errors[file_path] = str(e)
                        logger.error(f"Exceção no processamento ({completed}/{len(files)}): {os.path.basename(file_path)} - {e}")
        
        except Exception as e:
            logger.error(f"Erro no executor paralelo: {e}")
            # Fallback para processamento sequencial
            return self._fallback_sequential_processing(files, processor_func, **kwargs)
        
        end_time = time.time()
        processing_time = end_time - start_time
        
        # Estatísticas
        total_files = len(files)
        successful = len(results)
        failed = len(errors)
        success_rate = (successful / total_files * 100) if total_files > 0 else 0
        
        logger.info(f"Processamento paralelo concluído em {processing_time:.2f}s")
        logger.info(f"Arquivos processados: {successful}/{total_files} ({success_rate:.1f}% sucesso)")
        
        return {
            'results': results,
            'errors': errors,
            'statistics': {
                'total_files': total_files,
                'successful': successful,
                'failed': failed,
                'success_rate': success_rate,
                'processing_time': processing_time,
                'avg_time_per_file': processing_time / total_files if total_files > 0 else 0
            }
        }
    
    def _safe_process_file(self, file_path: str, processor_func: Callable, **kwargs) -> Dict[str, Any]:
        """
        Processa um arquivo de forma segura com tratamento de erros.
        
        Args:
            file_path: Caminho do arquivo
            processor_func: Função de processamento
            **kwargs: Argumentos adicionais
            
        Returns:
            Resultado do processamento
        """
        try:
            result = processor_func(file_path, **kwargs)
            return {
                'success': True,
                'data': result,
                'file': file_path
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'file': file_path
            }
    
    def _fallback_sequential_processing(self, 
                                      files: List[str], 
                                      processor_func: Callable, 
                                      **kwargs) -> Dict[str, Any]:
        """
        Processamento sequencial como fallback.
        
        Args:
            files: Lista de arquivos
            processor_func: Função de processamento
            **kwargs: Argumentos adicionais
            
        Returns:
            Resultados do processamento sequencial
        """
        logger.warning("Usando processamento sequencial como fallback")
        
        start_time = time.time()
        results = {}
        errors = {}
        
        for i, file_path in enumerate(files, 1):
            try:
                result = processor_func(file_path, **kwargs)
                results[file_path] = result
                logger.info(f"Processamento sequencial ({i}/{len(files)}): {os.path.basename(file_path)}")
                
            except Exception as e:
                errors[file_path] = str(e)
                logger.error(f"Erro no processamento sequencial ({i}/{len(files)}): {os.path.basename(file_path)} - {e}")
        
        end_time = time.time()
        processing_time = end_time - start_time
        
        total_files = len(files)
        successful = len(results)
        failed = len(errors)
        success_rate = (successful / total_files * 100) if total_files > 0 else 0
        
        return {
            'results': results,
            'errors': errors,
            'statistics': {
                'total_files': total_files,
                'successful': successful,
                'failed': failed,
                'success_rate': success_rate,
                'processing_time': processing_time,
                'avg_time_per_file': processing_time / total_files if total_files > 0 else 0,
                'mode': 'sequential_fallback'
            }
        }
    
    def process_batch_analysis(self, 
                             programs: List[Dict[str, Any]], 
                             analysis_func: Callable,
                             batch_size: int = 5) -> Dict[str, Any]:
        """
        Processa análises em lotes para otimização.
        
        Args:
            programs: Lista de programas para analisar
            analysis_func: Função de análise
            batch_size: Tamanho do lote
            
        Returns:
            Resultados da análise em lotes
        """
        logger.info(f"Iniciando análise em lotes: {len(programs)} programas, lotes de {batch_size}")
        
        # Dividir em lotes
        batches = [programs[i:i + batch_size] for i in range(0, len(programs), batch_size)]
        
        start_time = time.time()
        all_results = {}
        all_errors = {}
        
        try:
            with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
                future_to_batch = {
                    executor.submit(self._process_batch, batch, analysis_func): i
                    for i, batch in enumerate(batches)
                }
                
                for future in as_completed(future_to_batch):
                    batch_index = future_to_batch[future]
                    
                    try:
                        batch_result = future.result()
                        all_results.update(batch_result['results'])
                        all_errors.update(batch_result['errors'])
                        
                        logger.info(f"Lote {batch_index + 1}/{len(batches)} concluído")
                        
                    except Exception as e:
                        logger.error(f"Erro no lote {batch_index + 1}: {e}")
                        # Marcar todos os programas do lote como erro
                        for program in batches[batch_index]:
                            all_errors[program.get('name', f'program_{batch_index}')] = str(e)
        
        except Exception as e:
            logger.error(f"Erro no processamento em lotes: {e}")
            return self._fallback_sequential_batch(programs, analysis_func)
        
        end_time = time.time()
        processing_time = end_time - start_time
        
        total_programs = len(programs)
        successful = len(all_results)
        failed = len(all_errors)
        success_rate = (successful / total_programs * 100) if total_programs > 0 else 0
        
        logger.info(f"Análise em lotes concluída em {processing_time:.2f}s")
        logger.info(f"Programas analisados: {successful}/{total_programs} ({success_rate:.1f}% sucesso)")
        
        return {
            'results': all_results,
            'errors': all_errors,
            'statistics': {
                'total_programs': total_programs,
                'successful': successful,
                'failed': failed,
                'success_rate': success_rate,
                'processing_time': processing_time,
                'batches_processed': len(batches),
                'avg_batch_time': processing_time / len(batches) if batches else 0
            }
        }
    
    def _process_batch(self, batch: List[Dict[str, Any]], analysis_func: Callable) -> Dict[str, Any]:
        """
        Processa um lote de programas.
        
        Args:
            batch: Lote de programas
            analysis_func: Função de análise
            
        Returns:
            Resultados do lote
        """
        results = {}
        errors = {}
        
        for program in batch:
            try:
                result = analysis_func(program)
                program_name = program.get('name', 'unknown')
                results[program_name] = result
                
            except Exception as e:
                program_name = program.get('name', 'unknown')
                errors[program_name] = str(e)
        
        return {
            'results': results,
            'errors': errors
        }
    
    def _fallback_sequential_batch(self, programs: List[Dict[str, Any]], analysis_func: Callable) -> Dict[str, Any]:
        """
        Processamento sequencial de lotes como fallback.
        
        Args:
            programs: Lista de programas
            analysis_func: Função de análise
            
        Returns:
            Resultados do processamento sequencial
        """
        logger.warning("Usando processamento sequencial de lotes como fallback")
        
        start_time = time.time()
        results = {}
        errors = {}
        
        for i, program in enumerate(programs, 1):
            try:
                result = analysis_func(program)
                program_name = program.get('name', f'program_{i}')
                results[program_name] = result
                logger.info(f"Análise sequencial ({i}/{len(programs)}): {program_name}")
                
            except Exception as e:
                program_name = program.get('name', f'program_{i}')
                errors[program_name] = str(e)
                logger.error(f"Erro na análise sequencial ({i}/{len(programs)}): {program_name} - {e}")
        
        end_time = time.time()
        processing_time = end_time - start_time
        
        total_programs = len(programs)
        successful = len(results)
        failed = len(errors)
        success_rate = (successful / total_programs * 100) if total_programs > 0 else 0
        
        return {
            'results': results,
            'errors': errors,
            'statistics': {
                'total_programs': total_programs,
                'successful': successful,
                'failed': failed,
                'success_rate': success_rate,
                'processing_time': processing_time,
                'mode': 'sequential_fallback'
            }
        }
    
    def get_optimal_workers(self, workload_size: int) -> int:
        """
        Calcula número ótimo de workers baseado na carga de trabalho.
        
        Args:
            workload_size: Tamanho da carga de trabalho
            
        Returns:
            Número ótimo de workers
        """
        cpu_count = os.cpu_count() or 1
        
        if workload_size <= 2:
            return 1
        elif workload_size <= 5:
            return min(2, cpu_count)
        elif workload_size <= 10:
            return min(3, cpu_count)
        else:
            return min(self.max_workers, cpu_count)

# Instância global do processador paralelo
parallel_processor = ParallelProcessor()
