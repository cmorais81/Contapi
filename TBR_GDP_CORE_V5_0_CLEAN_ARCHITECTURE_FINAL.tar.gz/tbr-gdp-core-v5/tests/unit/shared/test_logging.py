"""
TBR GDP Core v5.0 - Logging System Tests
Autor: Carlos Morais <carlos.morais@f1rst.com.br>

Testes unitários para o sistema de logging estruturado.
"""

import pytest
import json
import logging
from unittest.mock import Mock, patch
from datetime import datetime

from src.shared.logging import (
    LogLevel, LogCategory, LogContext, StructuredLogger,
    StructuredFormatter, LoggerFactory, log_performance,
    get_logger, create_context
)
from src.domain.exceptions import ValidationError


class TestLogContext:
    """Testes para LogContext."""
    
    def test_create_empty_context(self):
        """Deve criar contexto vazio."""
        # Act
        context = LogContext()
        
        # Assert
        assert context.user_id is None
        assert context.session_id is None
        assert context.additional_data is None
    
    def test_create_context_with_data(self):
        """Deve criar contexto com dados."""
        # Act
        context = LogContext(
            user_id="user123",
            session_id="session456",
            entity_id="entity789"
        )
        
        # Assert
        assert context.user_id == "user123"
        assert context.session_id == "session456"
        assert context.entity_id == "entity789"
    
    def test_to_dict_removes_none_values(self):
        """Deve remover valores None ao converter para dict."""
        # Arrange
        context = LogContext(
            user_id="user123",
            session_id=None,
            entity_id="entity789"
        )
        
        # Act
        result = context.to_dict()
        
        # Assert
        assert result == {
            "user_id": "user123",
            "entity_id": "entity789"
        }
        assert "session_id" not in result
    
    def test_add_data_creates_additional_data(self):
        """Deve criar additional_data se não existir."""
        # Arrange
        context = LogContext()
        
        # Act
        result = context.add_data("key1", "value1")
        
        # Assert
        assert result is context  # Fluent interface
        assert context.additional_data == {"key1": "value1"}
    
    def test_add_data_appends_to_existing(self):
        """Deve adicionar a additional_data existente."""
        # Arrange
        context = LogContext()
        context.additional_data = {"existing": "value"}
        
        # Act
        context.add_data("new_key", "new_value")
        
        # Assert
        assert context.additional_data == {
            "existing": "value",
            "new_key": "new_value"
        }


class TestStructuredLogger:
    """Testes para StructuredLogger."""
    
    def setup_method(self):
        """Setup para cada teste."""
        self.logger = StructuredLogger("test_logger", LogLevel.DEBUG)
        self.mock_handler = Mock()
        self.mock_handler.level = 0  # Aceitar todos os níveis
        self.logger._logger.handlers = [self.mock_handler]
    
    def test_debug_log_with_context(self):
        """Deve fazer log debug com contexto."""
        # Arrange
        context = LogContext(user_id="user123")
        
        # Act
        self.logger.debug("Debug message", LogCategory.DOMAIN, context)
        
        # Assert
        self.mock_handler.handle.assert_called_once()
        record = self.mock_handler.handle.call_args[0][0]
        
        log_data = json.loads(record.getMessage())
        assert log_data["level"] == "DEBUG"
        assert log_data["category"] == "domain"
        assert log_data["message"] == "Debug message"
        assert log_data["context"]["user_id"] == "user123"
    
    def test_error_log_with_exception(self):
        """Deve fazer log de erro com exceção."""
        # Arrange
        exception = ValidationError(["Field is required"], "test_field")
        
        # Act
        self.logger.error("Error occurred", exception=exception)
        
        # Assert
        self.mock_handler.handle.assert_called_once()
        record = self.mock_handler.handle.call_args[0][0]
        
        log_data = json.loads(record.getMessage())
        assert log_data["level"] == "ERROR"
        assert log_data["data"]["exception_type"] == "ValidationError"
        assert log_data["data"]["error_code"] == "VALIDATION_ERROR"
    
    def test_performance_log_includes_duration(self):
        """Deve incluir duração no log de performance."""
        # Act
        self.logger.performance("Operation completed", 150.5)
        
        # Assert
        self.mock_handler.handle.assert_called_once()
        record = self.mock_handler.handle.call_args[0][0]
        
        log_data = json.loads(record.getMessage())
        assert log_data["category"] == "performance"
        assert log_data["data"]["duration_ms"] == 150.5
        assert log_data["context"]["duration_ms"] == 150.5
    
    def test_audit_log_always_info_level(self):
        """Deve sempre usar nível INFO para auditoria."""
        # Act
        self.logger.audit("User action performed")
        
        # Assert
        self.mock_handler.handle.assert_called_once()
        record = self.mock_handler.handle.call_args[0][0]
        
        log_data = json.loads(record.getMessage())
        assert log_data["level"] == "INFO"
        assert log_data["category"] == "audit"


class TestStructuredFormatter:
    """Testes para StructuredFormatter."""
    
    def setup_method(self):
        """Setup para cada teste."""
        self.formatter = StructuredFormatter()
    
    def test_format_structured_log(self):
        """Deve formatar log já estruturado."""
        # Arrange
        log_data = {
            "timestamp": "2024-01-01T12:00:00",
            "level": "INFO",
            "message": "Test message"
        }
        record = logging.LogRecord(
            name="test",
            level=logging.INFO,
            pathname="",
            lineno=0,
            msg=json.dumps(log_data),
            args=(),
            exc_info=None
        )
        
        # Act
        result = self.formatter.format(record)
        
        # Assert
        parsed = json.loads(result)
        assert parsed == log_data
    
    def test_format_unstructured_log(self):
        """Deve formatar log não estruturado."""
        # Arrange
        record = logging.LogRecord(
            name="test",
            level=logging.INFO,
            pathname="test.py",
            lineno=42,
            msg="Simple message",
            args=(),
            exc_info=None
        )
        record.module = "test_module"
        record.funcName = "test_function"
        
        # Act
        result = self.formatter.format(record)
        
        # Assert
        parsed = json.loads(result)
        assert parsed["level"] == "INFO"
        assert parsed["message"] == "Simple message"
        assert parsed["module"] == "test_module"
        assert parsed["function"] == "test_function"
        assert parsed["line"] == 42


class TestLoggerFactory:
    """Testes para LoggerFactory."""
    
    def setup_method(self):
        """Setup para cada teste."""
        # Limpar cache de loggers
        LoggerFactory._loggers.clear()
    
    def test_get_logger_creates_new(self):
        """Deve criar novo logger se não existir."""
        # Act
        logger = LoggerFactory.get_logger("test_logger")
        
        # Assert
        assert isinstance(logger, StructuredLogger)
        assert "test_logger" in LoggerFactory._loggers
    
    def test_get_logger_returns_cached(self):
        """Deve retornar logger em cache."""
        # Arrange
        logger1 = LoggerFactory.get_logger("test_logger")
        
        # Act
        logger2 = LoggerFactory.get_logger("test_logger")
        
        # Assert
        assert logger1 is logger2
    
    def test_set_default_level(self):
        """Deve definir nível padrão."""
        # Act
        LoggerFactory.set_default_level(LogLevel.ERROR)
        
        # Assert
        assert LoggerFactory._default_level == LogLevel.ERROR


class TestLogPerformance:
    """Testes para context manager de performance."""
    
    def setup_method(self):
        """Setup para cada teste."""
        self.mock_logger = Mock(spec=StructuredLogger)
    
    def test_log_performance_success(self):
        """Deve logar performance em operação bem-sucedida."""
        # Act
        with log_performance(self.mock_logger, "test_operation"):
            pass  # Operação simulada
        
        # Assert
        assert self.mock_logger.debug.called
        assert self.mock_logger.performance.called
        
        # Verificar chamada de debug (início)
        debug_call = self.mock_logger.debug.call_args
        assert "Starting operation: test_operation" in debug_call[0][0]
        
        # Verificar chamada de performance (fim)
        perf_call = self.mock_logger.performance.call_args
        assert "Operation completed: test_operation" in perf_call[0][0]
        assert "duration_ms" in perf_call[1]
    
    def test_log_performance_with_exception(self):
        """Deve logar erro quando operação falha."""
        # Arrange
        test_exception = ValueError("Test error")
        
        # Act & Assert
        with pytest.raises(ValueError):
            with log_performance(self.mock_logger, "failing_operation"):
                raise test_exception
        
        # Verificar log de erro
        assert self.mock_logger.error.called
        error_call = self.mock_logger.error.call_args
        assert "Operation failed: failing_operation" in error_call[0][0]
        assert error_call[1]["exception"] is test_exception


class TestConvenienceFunctions:
    """Testes para funções de conveniência."""
    
    def test_get_logger_uses_factory(self):
        """Deve usar LoggerFactory."""
        with patch.object(LoggerFactory, 'get_logger') as mock_get:
            # Act
            get_logger("test")
            
            # Assert
            mock_get.assert_called_once_with("test")
    
    def test_create_context_with_kwargs(self):
        """Deve criar contexto com kwargs."""
        # Act
        context = create_context(
            user_id="user123",
            custom_field="custom_value",
            another_field=42
        )
        
        # Assert
        assert context.user_id == "user123"
        assert context.additional_data == {
            "custom_field": "custom_value",
            "another_field": 42
        }

