"""
TBR GDP Core v5.0 - Error Handling Tests
Autor: Carlos Morais <carlos.morais@f1rst.com.br>

Testes unitários para o sistema de tratamento de erros.
"""

import pytest
import json
from unittest.mock import Mock, AsyncMock, patch
from fastapi import Request, status
from fastapi.exceptions import HTTPException, RequestValidationError
from starlette.responses import Response

from src.shared.error_handling import (
    ErrorResponse, ErrorHandler, ErrorHandlingMiddleware, handle_error
)
from src.domain.exceptions import (
    ValidationError, EntityNotFoundError, EntityAlreadyExistsError,
    BusinessRuleViolationError, DatabaseError
)


class TestErrorResponse:
    """Testes para ErrorResponse."""
    
    def test_create_basic_error_response(self):
        """Deve criar resposta de erro básica."""
        # Act
        response = ErrorResponse(
            error_code="TEST_ERROR",
            message="Test error message"
        )
        
        # Assert
        assert response.error_code == "TEST_ERROR"
        assert response.message == "Test error message"
        assert response.details == {}
        assert response.status_code == 500
    
    def test_create_error_response_with_details(self):
        """Deve criar resposta com detalhes."""
        # Arrange
        details = {"field": "name", "value": "invalid"}
        
        # Act
        response = ErrorResponse(
            error_code="VALIDATION_ERROR",
            message="Validation failed",
            details=details,
            request_id="req-123",
            status_code=400
        )
        
        # Assert
        assert response.details == details
        assert response.request_id == "req-123"
        assert response.status_code == 400
    
    def test_to_dict_basic(self):
        """Deve converter para dicionário básico."""
        # Arrange
        response = ErrorResponse(
            error_code="TEST_ERROR",
            message="Test message"
        )
        
        # Act
        result = response.to_dict()
        
        # Assert
        expected = {
            "error": {
                "code": "TEST_ERROR",
                "message": "Test message",
                "details": {}
            }
        }
        assert result == expected
    
    def test_to_dict_with_request_id(self):
        """Deve incluir request_id quando presente."""
        # Arrange
        response = ErrorResponse(
            error_code="TEST_ERROR",
            message="Test message",
            request_id="req-123"
        )
        
        # Act
        result = response.to_dict()
        
        # Assert
        assert result["request_id"] == "req-123"
    
    def test_to_json_response(self):
        """Deve converter para JSONResponse."""
        # Arrange
        response = ErrorResponse(
            error_code="TEST_ERROR",
            message="Test message",
            status_code=400
        )
        
        # Act
        json_response = response.to_json_response()
        
        # Assert
        assert json_response.status_code == 400
        # Verificar conteúdo seria mais complexo devido à serialização


class TestErrorHandler:
    """Testes para ErrorHandler."""
    
    def setup_method(self):
        """Setup para cada teste."""
        self.handler = ErrorHandler()
        self.mock_request = Mock(spec=Request)
        self.mock_request.method = "POST"
        self.mock_request.url = Mock()
        self.mock_request.url.__str__ = Mock(return_value="http://test.com/api/entities")
        self.mock_request.headers = {"user-agent": "test-agent"}
    
    def test_handle_validation_error(self):
        """Deve tratar ValidationError corretamente."""
        # Arrange
        error = ValidationError(["Name is required"], "name")
        
        # Act
        response = self.handler.handle_error(error, self.mock_request)
        
        # Assert
        assert response.error_code == "VALIDATION_ERROR"
        assert "Name is required" in response.message
        assert response.status_code == 400
        assert response.details["field"] == "name"
    
    def test_handle_entity_not_found_error(self):
        """Deve tratar EntityNotFoundError corretamente."""
        # Arrange
        error = EntityNotFoundError("Entity", "entity-123")
        
        # Act
        response = self.handler.handle_error(error, self.mock_request)
        
        # Assert
        assert response.error_code == "ENTITY_NOT_FOUND"
        assert response.message == "Entity not found"
        assert response.status_code == 404
        assert response.details["entity_type"] == "Entity"
        assert response.details["identifier"] == "entity-123"
    
    def test_handle_entity_already_exists_error(self):
        """Deve tratar EntityAlreadyExistsError corretamente."""
        # Arrange
        error = EntityAlreadyExistsError("Entity", "entity-123")
        
        # Act
        response = self.handler.handle_error(error, self.mock_request)
        
        # Assert
        assert response.error_code == "ENTITY_ALREADY_EXISTS"
        assert response.message == "Entity already exists"
        assert response.status_code == 409
        assert response.details["entity_type"] == "Entity"
        assert response.details["identifier"] == "entity-123"
    
    def test_handle_business_rule_violation_error(self):
        """Deve tratar BusinessRuleViolationError corretamente."""
        # Arrange
        error = BusinessRuleViolationError(
            "table_schema_required",
            "TABLE entities must have schema",
            {"entity_id": "entity-123"}
        )
        
        # Act
        response = self.handler.handle_error(error, self.mock_request)
        
        # Assert
        assert response.error_code == "BUSINESS_RULE_VIOLATION"
        assert response.message == "TABLE entities must have schema"
        assert response.status_code == 422
        assert response.details["rule_code"] == "table_schema_required"
        assert response.details["entity_id"] == "entity-123"
    
    def test_handle_database_error(self):
        """Deve tratar DatabaseError corretamente."""
        # Arrange
        error = DatabaseError("save", "Connection failed")
        
        # Act
        response = self.handler.handle_error(error, self.mock_request)
        
        # Assert
        assert response.error_code == "DATABASE_ERROR"
        assert response.message == "Database operation failed"
        assert response.status_code == 500
        assert response.details["operation"] == "save"
        # Não deve expor detalhes internos
        assert "Connection failed" not in str(response.details)
    
    def test_handle_http_exception(self):
        """Deve tratar HTTPException corretamente."""
        # Arrange
        error = HTTPException(status_code=403, detail="Forbidden")
        
        # Act
        response = self.handler.handle_error(error, self.mock_request)
        
        # Assert
        assert response.error_code == "HTTP_ERROR"
        assert response.message == "Forbidden"
        assert response.status_code == 403
    
    def test_handle_request_validation_error(self):
        """Deve tratar RequestValidationError corretamente."""
        # Arrange
        error = RequestValidationError([
            {
                "loc": ["body", "name"],
                "msg": "field required",
                "type": "value_error.missing"
            }
        ])
        
        # Act
        response = self.handler.handle_error(error, self.mock_request)
        
        # Assert
        assert response.error_code == "REQUEST_VALIDATION_ERROR"
        assert response.message == "Request validation failed"
        assert response.status_code == 422
        assert "validation_errors" in response.details
    
    def test_handle_unknown_error(self):
        """Deve tratar erro desconhecido."""
        # Arrange
        error = ValueError("Unknown error")
        
        # Act
        response = self.handler.handle_error(error, self.mock_request)
        
        # Assert
        assert response.error_code == "INTERNAL_SERVER_ERROR"
        assert response.message == "An unexpected error occurred"
        assert response.status_code == 500
        assert response.details["error_type"] == "ValueError"
    
    def test_handle_error_without_request(self):
        """Deve tratar erro sem request."""
        # Arrange
        error = ValidationError("field", "value", "Error message")
        
        # Act
        response = self.handler.handle_error(error)
        
        # Assert
        assert response.error_code == "VALIDATION_ERROR"
        assert response.request_id is not None  # Deve gerar ID
    
    @patch('src.shared.error_handling.uuid.uuid4')
    def test_generates_request_id_when_missing(self, mock_uuid):
        """Deve gerar request_id quando não fornecido."""
        # Arrange
        mock_uuid.return_value = Mock()
        mock_uuid.return_value.__str__ = Mock(return_value="generated-id")
        error = ValidationError("field", "value", "Error message")
        
        # Act
        response = self.handler.handle_error(error)
        
        # Assert
        assert response.request_id == "generated-id"


class TestErrorHandlingMiddleware:
    """Testes para ErrorHandlingMiddleware."""
    
    def setup_method(self):
        """Setup para cada teste."""
        self.mock_app = Mock()
        self.middleware = ErrorHandlingMiddleware(self.mock_app, debug=True)
        
        self.mock_request = Mock(spec=Request)
        self.mock_request.method = "GET"
        self.mock_request.url = Mock()
        self.mock_request.url.path = "/api/entities"
        self.mock_request.state = Mock()
    
    @pytest.mark.asyncio
    async def test_dispatch_success(self):
        """Deve processar requisição bem-sucedida."""
        # Arrange
        mock_response = Mock(spec=Response)
        mock_response.status_code = 200
        
        async def mock_call_next(request):
            return mock_response
        
        # Act
        response = await self.middleware.dispatch(self.mock_request, mock_call_next)
        
        # Assert
        assert response is mock_response
        assert hasattr(self.mock_request.state, 'request_id')
    
    @pytest.mark.asyncio
    async def test_dispatch_handles_exception(self):
        """Deve tratar exceção durante processamento."""
        # Arrange
        test_error = ValidationError("field", "value", "Test error")
        
        async def mock_call_next(request):
            raise test_error
        
        # Act
        response = await self.middleware.dispatch(self.mock_request, mock_call_next)
        
        # Assert
        assert response.status_code == 400
        # Verificar que é JSONResponse seria mais complexo
    
    @pytest.mark.asyncio
    async def test_dispatch_adds_stack_trace_in_debug(self):
        """Deve adicionar stack trace em modo debug."""
        # Arrange
        test_error = Exception("Internal error")
        
        async def mock_call_next(request):
            raise test_error
        
        # Act
        response = await self.middleware.dispatch(self.mock_request, mock_call_next)
        
        # Assert
        assert response.status_code == 500
        # Em modo debug, deve incluir stack trace
        # Verificação completa seria mais complexa devido à serialização


class TestConvenienceFunction:
    """Testes para função de conveniência."""
    
    @patch('src.shared.error_handling.ErrorHandler')
    def test_handle_error_uses_handler(self, mock_handler_class):
        """Deve usar ErrorHandler."""
        # Arrange
        mock_handler = Mock()
        mock_handler_class.return_value = mock_handler
        mock_handler.handle_error.return_value = "test_response"
        
        error = Exception("test")
        request = Mock()
        
        # Act
        result = handle_error(error, request)
        
        # Assert
        mock_handler_class.assert_called_once()
        mock_handler.handle_error.assert_called_once_with(error, request)
        assert result == "test_response"

