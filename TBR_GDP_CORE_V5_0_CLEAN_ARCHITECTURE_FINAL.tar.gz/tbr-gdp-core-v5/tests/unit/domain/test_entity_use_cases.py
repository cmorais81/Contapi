"""
TBR GDP Core v5.0 - Entity Use Cases Unit Tests
Autor: Carlos Morais <carlos.morais@f1rst.com.br>

Testes unitários REAIS para casos de uso de Entity.
Testa a lógica de aplicação isoladamente usando mocks.
"""

import pytest
from unittest.mock import Mock, AsyncMock
from typing import List, Optional

from src.domain.use_cases.entity_use_cases import (
    CreateEntityUseCase, UpdateEntityUseCase, ChangeEntityStatusUseCase,
    DeleteEntityUseCase, GetEntityByIdUseCase, SearchEntitiesUseCase,
    CreateEntityCommand, UpdateEntityCommand, ChangeEntityStatusCommand,
    SearchEntitiesQuery
)
from src.domain.entities.entity import Entity
from src.domain.value_objects import EntityId, EntityName, EntityType, EntityStatus
from src.domain.repositories import EntityRepositoryInterface, SearchResult
from src.domain.exceptions import EntityNotFoundError, EntityAlreadyExistsError, BusinessRuleViolationError


class TestCreateEntityUseCase:
    """Testes para CreateEntityUseCase."""
    
    def setup_method(self):
        """Setup executado antes de cada teste."""
        # Mock do repositório - ISOLAMENTO COMPLETO
        self.mock_repository = Mock(spec=EntityRepositoryInterface)
        self.use_case = CreateEntityUseCase(self.mock_repository)
    
    @pytest.mark.asyncio
    async def test_create_entity_success(self):
        """Deve criar entidade com sucesso."""
        # Arrange
        command = CreateEntityCommand(
            name="Test Entity",
            type="DATASET",
            description="Test description",
            owner="owner@example.com"
        )
        
        # Mock: entidade não existe
        self.mock_repository.find_by_name = AsyncMock(return_value=None)
        
        # Mock: save retorna a entidade criada
        saved_entity = Mock(spec=Entity)
        self.mock_repository.save = AsyncMock(return_value=saved_entity)
        
        # Act
        result = await self.use_case.execute(command)
        
        # Assert
        assert result == saved_entity
        
        # Verify interactions
        self.mock_repository.find_by_name.assert_called_once_with("Test Entity")
        self.mock_repository.save.assert_called_once()
        
        # Verify que save foi chamado com uma Entity
        save_call_args = self.mock_repository.save.call_args[0]
        created_entity = save_call_args[0]
        assert isinstance(created_entity, Entity)
    
    @pytest.mark.asyncio
    async def test_create_entity_already_exists_raises_error(self):
        """Deve falhar se entidade já existir."""
        # Arrange
        command = CreateEntityCommand(
            name="Existing Entity",
            type="DATASET"
        )
        
        # Mock: entidade já existe
        existing_entity = Mock(spec=Entity)
        self.mock_repository.find_by_name = AsyncMock(return_value=existing_entity)
        
        # Act & Assert
        with pytest.raises(EntityAlreadyExistsError) as exc_info:
            await self.use_case.execute(command)
        
        # Verify error details
        assert exc_info.value.entity_type == "Entity"
        assert exc_info.value.identifier == "Existing Entity"
        
        # Verify interactions
        self.mock_repository.find_by_name.assert_called_once_with("Existing Entity")
        self.mock_repository.save.assert_not_called()
    
    @pytest.mark.asyncio
    async def test_create_table_entity_with_schema(self):
        """Deve criar entidade TABLE com schema."""
        # Arrange
        schema = {"columns": [{"name": "id", "type": "int"}]}
        command = CreateEntityCommand(
            name="Test Table",
            type="TABLE",
            schema_definition=schema,
            owner="owner@example.com"
        )
        
        # Mock: entidade não existe
        self.mock_repository.find_by_name = AsyncMock(return_value=None)
        
        # Mock: save retorna a entidade criada
        saved_entity = Mock(spec=Entity)
        self.mock_repository.save = AsyncMock(return_value=saved_entity)
        
        # Act
        result = await self.use_case.execute(command)
        
        # Assert
        assert result == saved_entity
        self.mock_repository.save.assert_called_once()
        
        # Verify que foi criada uma entidade TABLE
        save_call_args = self.mock_repository.save.call_args[0]
        created_entity = save_call_args[0]
        assert created_entity.type.value == "TABLE"
        assert created_entity.metadata.schema_definition == schema
    
    @pytest.mark.asyncio
    async def test_create_entity_with_tags(self):
        """Deve criar entidade com tags."""
        # Arrange
        command = CreateEntityCommand(
            name="Tagged Entity",
            type="DATASET",
            tags=["important", "production"]
        )
        
        # Mock setup
        self.mock_repository.find_by_name = AsyncMock(return_value=None)
        saved_entity = Mock(spec=Entity)
        self.mock_repository.save = AsyncMock(return_value=saved_entity)
        
        # Act
        result = await self.use_case.execute(command)
        
        # Assert
        assert result == saved_entity
        
        # Verify que tags foram adicionadas
        save_call_args = self.mock_repository.save.call_args[0]
        created_entity = save_call_args[0]
        assert "important" in created_entity.metadata.tags
        assert "production" in created_entity.metadata.tags


class TestUpdateEntityUseCase:
    """Testes para UpdateEntityUseCase."""
    
    def setup_method(self):
        """Setup executado antes de cada teste."""
        self.mock_repository = Mock(spec=EntityRepositoryInterface)
        self.use_case = UpdateEntityUseCase(self.mock_repository)
    
    @pytest.mark.asyncio
    async def test_update_entity_success(self):
        """Deve atualizar entidade com sucesso."""
        # Arrange
        command = UpdateEntityCommand(
            entity_id="test-entity-1",
            name="Updated Name",
            description="Updated description"
        )
        
        # Mock: entidade existe
        existing_entity = Entity(
            id=EntityId("test-entity-1"),
            name=EntityName("Original Name"),
            type=EntityType("DATASET")
        )
        self.mock_repository.find_by_id = AsyncMock(return_value=existing_entity)
        
        # Mock: save retorna entidade atualizada
        updated_entity = Mock(spec=Entity)
        self.mock_repository.save = AsyncMock(return_value=updated_entity)
        
        # Act
        result = await self.use_case.execute(command)
        
        # Assert
        assert result == updated_entity
        
        # Verify interactions
        expected_id = EntityId("test-entity-1")
        self.mock_repository.find_by_id.assert_called_once_with(expected_id)
        self.mock_repository.save.assert_called_once_with(existing_entity)
        
        # Verify que a entidade foi atualizada
        assert existing_entity.name.value == "Updated Name"
        assert existing_entity.description.value == "Updated description"
    
    @pytest.mark.asyncio
    async def test_update_entity_not_found_raises_error(self):
        """Deve falhar se entidade não existir."""
        # Arrange
        command = UpdateEntityCommand(
            entity_id="nonexistent-entity",
            name="New Name"
        )
        
        # Mock: entidade não existe
        self.mock_repository.find_by_id = AsyncMock(return_value=None)
        
        # Act & Assert
        with pytest.raises(EntityNotFoundError) as exc_info:
            await self.use_case.execute(command)
        
        # Verify error details
        assert exc_info.value.entity_type == "Entity"
        assert exc_info.value.identifier == "nonexistent-entity"
        
        # Verify interactions
        self.mock_repository.save.assert_not_called()
    
    @pytest.mark.asyncio
    async def test_update_entity_tags_replaces_all(self):
        """Deve substituir todas as tags."""
        # Arrange
        command = UpdateEntityCommand(
            entity_id="test-entity-1",
            tags=["new-tag-1", "new-tag-2"]
        )
        
        # Mock: entidade com tags existentes
        existing_entity = Entity(
            id=EntityId("test-entity-1"),
            name=EntityName("Test Entity"),
            type=EntityType("DATASET")
        )
        existing_entity.add_tag("old-tag-1")
        existing_entity.add_tag("old-tag-2")
        
        self.mock_repository.find_by_id = AsyncMock(return_value=existing_entity)
        self.mock_repository.save = AsyncMock(return_value=existing_entity)
        
        # Act
        await self.use_case.execute(command)
        
        # Assert
        # Tags antigas devem ter sido removidas
        assert not existing_entity.metadata.has_tag("old-tag-1")
        assert not existing_entity.metadata.has_tag("old-tag-2")
        
        # Tags novas devem estar presentes
        assert existing_entity.metadata.has_tag("new-tag-1")
        assert existing_entity.metadata.has_tag("new-tag-2")


class TestChangeEntityStatusUseCase:
    """Testes para ChangeEntityStatusUseCase."""
    
    def setup_method(self):
        """Setup executado antes de cada teste."""
        self.mock_repository = Mock(spec=EntityRepositoryInterface)
        self.use_case = ChangeEntityStatusUseCase(self.mock_repository)
    
    @pytest.mark.asyncio
    async def test_change_status_success(self):
        """Deve alterar status com sucesso."""
        # Arrange
        command = ChangeEntityStatusCommand(
            entity_id="test-entity-1",
            new_status="INACTIVE"
        )
        
        # Mock: entidade existe
        existing_entity = Entity(
            id=EntityId("test-entity-1"),
            name=EntityName("Test Entity"),
            type=EntityType("DATASET")
        )
        self.mock_repository.find_by_id = AsyncMock(return_value=existing_entity)
        self.mock_repository.save = AsyncMock(return_value=existing_entity)
        
        # Act
        result = await self.use_case.execute(command)
        
        # Assert
        assert result == existing_entity
        assert existing_entity.status.value == "INACTIVE"
        
        # Verify interactions
        self.mock_repository.save.assert_called_once_with(existing_entity)
    
    @pytest.mark.asyncio
    async def test_change_status_to_deprecated_sets_retention_policy(self):
        """Deve definir retention policy ao depreciar."""
        # Arrange
        command = ChangeEntityStatusCommand(
            entity_id="test-entity-1",
            new_status="DEPRECATED"
        )
        
        # Mock: entidade existe
        existing_entity = Entity(
            id=EntityId("test-entity-1"),
            name=EntityName("Test Entity"),
            type=EntityType("DATASET")
        )
        self.mock_repository.find_by_id = AsyncMock(return_value=existing_entity)
        self.mock_repository.save = AsyncMock(return_value=existing_entity)
        
        # Act
        result = await self.use_case.execute(command)
        
        # Assert
        assert result == existing_entity
        assert existing_entity.status.value == "DEPRECATED"
        assert existing_entity.metadata.retention_policy is not None
        assert "90 days" in existing_entity.metadata.retention_policy
    
    @pytest.mark.asyncio
    async def test_change_status_entity_not_found_raises_error(self):
        """Deve falhar se entidade não existir."""
        # Arrange
        command = ChangeEntityStatusCommand(
            entity_id="nonexistent-entity",
            new_status="INACTIVE"
        )
        
        # Mock: entidade não existe
        self.mock_repository.find_by_id = AsyncMock(return_value=None)
        
        # Act & Assert
        with pytest.raises(EntityNotFoundError):
            await self.use_case.execute(command)


class TestDeleteEntityUseCase:
    """Testes para DeleteEntityUseCase."""
    
    def setup_method(self):
        """Setup executado antes de cada teste."""
        self.mock_repository = Mock(spec=EntityRepositoryInterface)
        self.use_case = DeleteEntityUseCase(self.mock_repository)
    
    @pytest.mark.asyncio
    async def test_delete_entity_success(self):
        """Deve deletar entidade com sucesso."""
        # Arrange
        entity_id = "test-entity-1"
        
        # Mock: entidade existe e pode ser deletada
        existing_entity = Entity(
            id=EntityId(entity_id),
            name=EntityName("Test Entity"),
            type=EntityType("DATASET"),
            status=EntityStatus("INACTIVE")  # Pode ser deletada
        )
        self.mock_repository.find_by_id = AsyncMock(return_value=existing_entity)
        self.mock_repository.delete = AsyncMock()
        
        # Act
        await self.use_case.execute(entity_id)
        
        # Assert
        # Verify interactions
        expected_id = EntityId(entity_id)
        self.mock_repository.find_by_id.assert_called_once_with(expected_id)
        self.mock_repository.delete.assert_called_once_with(expected_id)
    
    @pytest.mark.asyncio
    async def test_delete_entity_not_found_raises_error(self):
        """Deve falhar se entidade não existir."""
        # Arrange
        entity_id = "nonexistent-entity"
        
        # Mock: entidade não existe
        self.mock_repository.find_by_id = AsyncMock(return_value=None)
        
        # Act & Assert
        with pytest.raises(EntityNotFoundError):
            await self.use_case.execute(entity_id)
        
        # Verify que delete não foi chamado
        self.mock_repository.delete.assert_not_called()
    
    @pytest.mark.asyncio
    async def test_delete_active_entity_raises_error(self):
        """Deve falhar ao deletar entidade ativa."""
        # Arrange
        entity_id = "test-entity-1"
        
        # Mock: entidade existe mas está ativa (não pode ser deletada)
        existing_entity = Entity(
            id=EntityId(entity_id),
            name=EntityName("Test Entity"),
            type=EntityType("DATASET"),
            status=EntityStatus("ACTIVE")  # Não pode ser deletada
        )
        self.mock_repository.find_by_id = AsyncMock(return_value=existing_entity)
        
        # Act & Assert
        with pytest.raises(BusinessRuleViolationError) as exc_info:
            await self.use_case.execute(entity_id)
        
        # Verify error details
        assert "entity_cannot_be_deleted" in str(exc_info.value)
        
        # Verify que delete não foi chamado
        self.mock_repository.delete.assert_not_called()


class TestGetEntityByIdUseCase:
    """Testes para GetEntityByIdUseCase."""
    
    def setup_method(self):
        """Setup executado antes de cada teste."""
        self.mock_repository = Mock(spec=EntityRepositoryInterface)
        self.use_case = GetEntityByIdUseCase(self.mock_repository)
    
    @pytest.mark.asyncio
    async def test_get_entity_by_id_success(self):
        """Deve buscar entidade por ID com sucesso."""
        # Arrange
        entity_id = "test-entity-1"
        
        # Mock: entidade existe
        existing_entity = Mock(spec=Entity)
        self.mock_repository.find_by_id = AsyncMock(return_value=existing_entity)
        
        # Act
        result = await self.use_case.execute(entity_id)
        
        # Assert
        assert result == existing_entity
        
        # Verify interactions
        expected_id = EntityId(entity_id)
        self.mock_repository.find_by_id.assert_called_once_with(expected_id)
    
    @pytest.mark.asyncio
    async def test_get_entity_by_id_not_found_raises_error(self):
        """Deve falhar se entidade não existir."""
        # Arrange
        entity_id = "nonexistent-entity"
        
        # Mock: entidade não existe
        self.mock_repository.find_by_id = AsyncMock(return_value=None)
        
        # Act & Assert
        with pytest.raises(EntityNotFoundError) as exc_info:
            await self.use_case.execute(entity_id)
        
        # Verify error details
        assert exc_info.value.entity_type == "Entity"
        assert exc_info.value.identifier == entity_id


class TestSearchEntitiesUseCase:
    """Testes para SearchEntitiesUseCase."""
    
    def setup_method(self):
        """Setup executado antes de cada teste."""
        self.mock_repository = Mock(spec=EntityRepositoryInterface)
        self.use_case = SearchEntitiesUseCase(self.mock_repository)
    
    @pytest.mark.asyncio
    async def test_search_entities_success(self):
        """Deve buscar entidades com sucesso."""
        # Arrange
        query = SearchEntitiesQuery(
            name_filter="Test",
            type_filter="DATASET",
            status_filter="ACTIVE",
            limit=10,
            offset=0
        )
        
        # Mock: resultado da busca
        mock_entities = [Mock(spec=Entity), Mock(spec=Entity)]
        mock_result = SearchResult(
            items=mock_entities,
            total_count=2,
            offset=0,
            limit=10
        )
        self.mock_repository.find_all = AsyncMock(return_value=mock_result)
        
        # Act
        result = await self.use_case.execute(query)
        
        # Assert
        assert result == mock_result
        assert len(result.items) == 2
        
        # Verify interactions
        self.mock_repository.find_all.assert_called_once()
        
        # Verify que os filtros foram passados corretamente
        call_args = self.mock_repository.find_all.call_args[0]
        search_criteria = call_args[0]
        
        assert search_criteria.filters["name"] == "Test"
        assert search_criteria.filters["type"] == "DATASET"
        assert search_criteria.filters["status"] == "ACTIVE"
        assert search_criteria.limit == 10
        assert search_criteria.offset == 0
    
    @pytest.mark.asyncio
    async def test_search_entities_with_optional_filters(self):
        """Deve buscar entidades com filtros opcionais."""
        # Arrange
        query = SearchEntitiesQuery(
            has_owner=True,
            min_quality_score=0.8,
            tags_filter=["important", "production"]
        )
        
        # Mock: resultado da busca
        mock_result = SearchResult(items=[], total_count=0, offset=0, limit=None)
        self.mock_repository.find_all = AsyncMock(return_value=mock_result)
        
        # Act
        result = await self.use_case.execute(query)
        
        # Assert
        assert result == mock_result
        
        # Verify que filtros opcionais foram incluídos
        call_args = self.mock_repository.find_all.call_args[0]
        search_criteria = call_args[0]
        
        assert search_criteria.filters["has_owner"] is True
        assert search_criteria.filters["min_quality_score"] == 0.8
        assert search_criteria.filters["tags"] == ["important", "production"]
    
    @pytest.mark.asyncio
    async def test_search_entities_empty_query(self):
        """Deve buscar todas as entidades com query vazia."""
        # Arrange
        query = SearchEntitiesQuery()  # Query vazia
        
        # Mock: resultado da busca
        mock_result = SearchResult(items=[], total_count=0, offset=0, limit=None)
        self.mock_repository.find_all = AsyncMock(return_value=mock_result)
        
        # Act
        result = await self.use_case.execute(query)
        
        # Assert
        assert result == mock_result
        
        # Verify que foi chamado com filtros vazios
        call_args = self.mock_repository.find_all.call_args[0]
        search_criteria = call_args[0]
        
        assert search_criteria.filters == {}  # Sem filtros

