"""
TBR GDP Core v5.0 - Entity Unit Tests
Autor: Carlos Morais <carlos.morais@f1rst.com.br>

Testes unitários REAIS para a entidade Entity.
Testa comportamento e regras de negócio isoladamente.
"""

import pytest
from unittest.mock import Mock, AsyncMock
from datetime import datetime, timedelta

from src.domain.entities.entity import Entity, EntityMetadata, QualityMetrics
from src.domain.value_objects import (
    EntityId, EntityName, EntityType, EntityStatus, 
    Description, Email, Timestamp
)
from src.domain.exceptions import (
    BusinessRuleViolationError, ValidationError
)


class TestEntityMetadata:
    """Testes para EntityMetadata."""
    
    def test_add_tag_success(self):
        """Deve adicionar tag com sucesso."""
        # Arrange
        metadata = EntityMetadata()
        
        # Act
        metadata.add_tag("important")
        
        # Assert
        assert "important" in metadata.tags
        assert len(metadata.tags) == 1
    
    def test_add_tag_normalizes_case(self):
        """Deve normalizar case das tags."""
        # Arrange
        metadata = EntityMetadata()
        
        # Act
        metadata.add_tag("  Important  ")
        
        # Assert
        assert "Important" in metadata.tags
        assert len(metadata.tags) == 1
    
    def test_add_duplicate_tag_ignored(self):
        """Deve ignorar tags duplicadas."""
        # Arrange
        metadata = EntityMetadata()
        metadata.add_tag("important")
        
        # Act
        metadata.add_tag("IMPORTANT")  # Case different
        
        # Assert
        assert len(metadata.tags) == 1
    
    def test_add_empty_tag_raises_error(self):
        """Deve falhar ao adicionar tag vazia."""
        # Arrange
        metadata = EntityMetadata()
        
        # Act & Assert
        with pytest.raises(ValidationError) as exc_info:
            metadata.add_tag("")
        
        assert "Tag must be a non-empty string" in str(exc_info.value)
    
    def test_remove_tag_success(self):
        """Deve remover tag com sucesso."""
        # Arrange
        metadata = EntityMetadata()
        metadata.add_tag("important")
        metadata.add_tag("critical")
        
        # Act
        metadata.remove_tag("important")
        
        # Assert
        assert "important" not in metadata.tags
        assert "critical" in metadata.tags
        assert len(metadata.tags) == 1
    
    def test_has_tag_case_insensitive(self):
        """Deve verificar tag ignorando case."""
        # Arrange
        metadata = EntityMetadata()
        metadata.add_tag("Important")
        
        # Act & Assert
        assert metadata.has_tag("important")
        assert metadata.has_tag("IMPORTANT")
        assert metadata.has_tag("Important")
    
    def test_set_property_success(self):
        """Deve definir propriedade com sucesso."""
        # Arrange
        metadata = EntityMetadata()
        
        # Act
        metadata.set_property("database", "postgres")
        
        # Assert
        assert metadata.get_property("database") == "postgres"
    
    def test_set_property_empty_key_raises_error(self):
        """Deve falhar ao definir propriedade com chave vazia."""
        # Arrange
        metadata = EntityMetadata()
        
        # Act & Assert
        with pytest.raises(ValidationError):
            metadata.set_property("", "value")
    
    def test_get_property_with_default(self):
        """Deve retornar valor padrão para propriedade inexistente."""
        # Arrange
        metadata = EntityMetadata()
        
        # Act
        result = metadata.get_property("nonexistent", "default")
        
        # Assert
        assert result == "default"


class TestQualityMetrics:
    """Testes para QualityMetrics."""
    
    def test_init_with_valid_scores(self):
        """Deve inicializar com scores válidos."""
        # Act
        metrics = QualityMetrics(
            completeness_score=0.9,
            accuracy_score=0.8,
            consistency_score=0.7
        )
        
        # Assert
        assert metrics.completeness_score == 0.9
        assert metrics.accuracy_score == 0.8
        assert metrics.consistency_score == 0.7
    
    def test_init_with_invalid_score_raises_error(self):
        """Deve falhar com score inválido."""
        # Act & Assert
        with pytest.raises(ValidationError):
            QualityMetrics(completeness_score=1.5)  # > 1.0
        
        with pytest.raises(ValidationError):
            QualityMetrics(accuracy_score=-0.1)  # < 0.0
    
    def test_overall_score_calculation(self):
        """Deve calcular score geral corretamente."""
        # Arrange
        metrics = QualityMetrics(
            completeness_score=1.0,
            accuracy_score=0.8,
            consistency_score=0.6,
            timeliness_score=0.4,
            validity_score=0.2,
            uniqueness_score=0.0
        )
        
        # Act
        overall = metrics.overall_score
        
        # Assert
        expected = (1.0 + 0.8 + 0.6 + 0.4 + 0.2 + 0.0) / 6
        assert overall == expected
    
    def test_is_high_quality_with_default_threshold(self):
        """Deve verificar alta qualidade com threshold padrão."""
        # Arrange
        high_quality = QualityMetrics(
            completeness_score=0.9,
            accuracy_score=0.9,
            consistency_score=0.9,
            timeliness_score=0.9,
            validity_score=0.9,
            uniqueness_score=0.9
        )
        
        low_quality = QualityMetrics(
            completeness_score=0.5,
            accuracy_score=0.5,
            consistency_score=0.5,
            timeliness_score=0.5,
            validity_score=0.5,
            uniqueness_score=0.5
        )
        
        # Act & Assert
        assert high_quality.is_high_quality()
        assert not low_quality.is_high_quality()
    
    def test_get_quality_level(self):
        """Deve retornar nível de qualidade correto."""
        # Test cases: (score, expected_level)
        test_cases = [
            (0.95, "EXCELLENT"),
            (0.85, "GOOD"),
            (0.70, "FAIR"),
            (0.50, "POOR"),
            (0.30, "CRITICAL")
        ]
        
        for score, expected_level in test_cases:
            # Arrange
            metrics = QualityMetrics(
                completeness_score=score,
                accuracy_score=score,
                consistency_score=score,
                timeliness_score=score,
                validity_score=score,
                uniqueness_score=score
            )
            
            # Act
            level = metrics.get_quality_level()
            
            # Assert
            assert level == expected_level
    
    def test_update_score_success(self):
        """Deve atualizar score com sucesso."""
        # Arrange
        metrics = QualityMetrics()
        
        # Act
        metrics.update_score("completeness", 0.9)
        
        # Assert
        assert metrics.completeness_score == 0.9
        assert metrics.last_quality_check is not None
    
    def test_update_score_invalid_dimension_raises_error(self):
        """Deve falhar com dimensão inválida."""
        # Arrange
        metrics = QualityMetrics()
        
        # Act & Assert
        with pytest.raises(ValidationError) as exc_info:
            metrics.update_score("invalid_dimension", 0.9)
        
        assert "Unknown quality dimension" in str(exc_info.value)
    
    def test_update_score_invalid_value_raises_error(self):
        """Deve falhar com valor inválido."""
        # Arrange
        metrics = QualityMetrics()
        
        # Act & Assert
        with pytest.raises(ValidationError):
            metrics.update_score("completeness", 1.5)  # > 1.0


class TestEntity:
    """Testes para Entity."""
    
    def test_create_entity_success(self):
        """Deve criar entidade com sucesso."""
        # Arrange
        entity_id = EntityId("test-entity-1")
        name = EntityName("Test Entity")
        entity_type = EntityType("DATASET")  # Mudando de TABLE para DATASET
        
        # Act
        entity = Entity(
            id=entity_id,
            name=name,
            type=entity_type
        )
        
        # Assert
        assert entity.id == entity_id
        assert entity.name == name
        assert entity.type == entity_type
        assert entity.status.value == "ACTIVE"  # Default status
        assert entity.is_active()
    
    def test_create_table_entity_without_schema_raises_error(self):
        """Deve falhar ao criar TABLE sem schema."""
        # Arrange
        entity_id = EntityId("test-table")
        name = EntityName("Test Table")
        entity_type = EntityType("TABLE")
        
        # Act & Assert
        with pytest.raises(BusinessRuleViolationError) as exc_info:
            Entity(
                id=entity_id,
                name=name,
                type=entity_type
            )
        
        assert "table_schema_required" in str(exc_info.value)
    
    def test_create_deprecated_entity_without_retention_policy_raises_error(self):
        """Deve falhar ao criar entidade DEPRECATED sem retention policy."""
        # Arrange
        entity_id = EntityId("test-entity")
        name = EntityName("Test Entity")
        entity_type = EntityType("DATASET")
        status = EntityStatus("DEPRECATED")
        
        # Act & Assert
        with pytest.raises(BusinessRuleViolationError) as exc_info:
            Entity(
                id=entity_id,
                name=name,
                type=entity_type,
                status=status
            )
        
        assert "deprecated_retention_policy_required" in str(exc_info.value)
    
    def test_update_name_success(self):
        """Deve atualizar nome com sucesso."""
        # Arrange
        entity = self._create_valid_entity()
        new_name = EntityName("Updated Name")
        
        # Act
        entity.update_name(new_name)
        
        # Assert
        assert entity.name == new_name
    
    def test_update_name_archived_entity_raises_error(self):
        """Deve falhar ao atualizar nome de entidade arquivada."""
        # Arrange
        entity = self._create_valid_entity()
        # Simula entidade arquivada (hack para teste)
        entity._status = EntityStatus("ARCHIVED")
        
        # Act & Assert
        with pytest.raises(BusinessRuleViolationError) as exc_info:
            entity.update_name(EntityName("New Name"))
        
        assert "archived_entity_immutable" in str(exc_info.value)
    
    def test_change_status_success(self):
        """Deve alterar status com sucesso."""
        # Arrange
        entity = self._create_valid_entity()
        new_status = EntityStatus("INACTIVE")
        
        # Act
        entity.change_status(new_status)
        
        # Assert
        assert entity.status == new_status
        assert not entity.is_active()
    
    def test_change_status_from_archived_raises_error(self):
        """Deve falhar ao alterar status de entidade arquivada."""
        # Arrange
        entity = self._create_valid_entity()
        entity._status = EntityStatus("ARCHIVED")  # Hack para teste
        
        # Act & Assert
        with pytest.raises(BusinessRuleViolationError) as exc_info:
            entity.change_status(EntityStatus("ACTIVE"))
        
        assert "archived_status_final" in str(exc_info.value)
    
    def test_change_status_to_archived_from_non_deprecated_raises_error(self):
        """Deve falhar ao arquivar entidade não depreciada."""
        # Arrange
        entity = self._create_valid_entity()  # Status ACTIVE
        
        # Act & Assert
        with pytest.raises(BusinessRuleViolationError) as exc_info:
            entity.change_status(EntityStatus("ARCHIVED"))
        
        assert "archive_requires_deprecated" in str(exc_info.value)
    
    def test_assign_owner_success(self):
        """Deve atribuir owner com sucesso."""
        # Arrange
        entity = self._create_valid_entity()
        owner = Email("owner@example.com")
        
        # Act
        entity.assign_owner(owner)
        
        # Assert
        assert entity.metadata.owner == owner
        assert entity.has_owner()
    
    def test_assign_steward_success(self):
        """Deve atribuir steward com sucesso."""
        # Arrange
        entity = self._create_valid_entity()
        steward = Email("steward@example.com")
        
        # Act
        entity.assign_steward(steward)
        
        # Assert
        assert entity.metadata.steward == steward
        assert entity.has_steward()
    
    def test_add_tag_success(self):
        """Deve adicionar tag com sucesso."""
        # Arrange
        entity = self._create_valid_entity()
        
        # Act
        entity.add_tag("important")
        
        # Assert
        assert entity.metadata.has_tag("important")
    
    def test_update_quality_score_success(self):
        """Deve atualizar score de qualidade com sucesso."""
        # Arrange
        entity = self._create_valid_entity()
        
        # Act
        entity.update_quality_score("completeness", 0.9)
        
        # Assert
        assert entity.quality_metrics.completeness_score == 0.9
    
    def test_set_schema_definition_success(self):
        """Deve definir schema com sucesso."""
        # Arrange
        entity = self._create_valid_entity()
        schema = {"columns": [{"name": "id", "type": "int"}]}
        
        # Act
        entity.set_schema_definition(schema)
        
        # Assert
        assert entity.metadata.schema_definition == schema
    
    def test_set_empty_schema_definition_raises_error(self):
        """Deve falhar ao definir schema vazio."""
        # Arrange
        entity = self._create_valid_entity()
        
        # Act & Assert
        with pytest.raises(ValidationError):
            entity.set_schema_definition({})
    
    def test_can_be_deleted_inactive_entity(self):
        """Entidade INACTIVE pode ser deletada."""
        # Arrange
        entity = self._create_valid_entity()
        entity.change_status(EntityStatus("INACTIVE"))
        
        # Act & Assert
        assert entity.can_be_deleted()
    
    def test_can_be_deleted_active_entity(self):
        """Entidade ACTIVE não pode ser deletada."""
        # Arrange
        entity = self._create_valid_entity()  # Status ACTIVE
        
        # Act & Assert
        assert not entity.can_be_deleted()
    
    def test_can_be_archived_deprecated_entity(self):
        """Entidade DEPRECATED pode ser arquivada."""
        # Arrange
        entity = self._create_valid_entity()
        entity.set_retention_policy("90 days")  # Necessário para DEPRECATED
        entity.change_status(EntityStatus("DEPRECATED"))
        
        # Act & Assert
        assert entity.can_be_archived()
    
    def test_can_be_archived_active_entity(self):
        """Entidade ACTIVE não pode ser arquivada."""
        # Arrange
        entity = self._create_valid_entity()  # Status ACTIVE
        
        # Act & Assert
        assert not entity.can_be_archived()
    
    def test_has_governance_with_owner(self):
        """Deve ter governança com owner."""
        # Arrange
        entity = self._create_valid_entity()
        entity.assign_owner(Email("owner@example.com"))
        
        # Act & Assert
        assert entity.has_governance()
    
    def test_has_governance_with_steward(self):
        """Deve ter governança com steward."""
        # Arrange
        entity = self._create_valid_entity()
        entity.assign_steward(Email("steward@example.com"))
        
        # Act & Assert
        assert entity.has_governance()
    
    def test_has_governance_without_owner_or_steward(self):
        """Não deve ter governança sem owner ou steward."""
        # Arrange
        entity = self._create_valid_entity()
        
        # Act & Assert
        assert not entity.has_governance()
    
    def test_has_high_quality_with_high_scores(self):
        """Deve ter alta qualidade com scores altos."""
        # Arrange
        entity = self._create_valid_entity()
        entity.update_quality_score("completeness", 0.9)
        entity.update_quality_score("accuracy", 0.9)
        entity.update_quality_score("consistency", 0.9)
        entity.update_quality_score("timeliness", 0.9)
        entity.update_quality_score("validity", 0.9)
        entity.update_quality_score("uniqueness", 0.9)
        
        # Act & Assert
        assert entity.has_high_quality()
    
    def test_equality_based_on_id(self):
        """Igualdade deve ser baseada no ID."""
        # Arrange
        entity_id = EntityId("same-id")
        entity1 = Entity(
            id=entity_id,
            name=EntityName("Entity 1"),
            type=EntityType("DATASET")
        )
        entity2 = Entity(
            id=entity_id,
            name=EntityName("Entity 2"),  # Nome diferente
            type=EntityType("DATASET")    # Mesmo tipo para evitar problema
        )
        
        # Act & Assert
        assert entity1 == entity2
        assert hash(entity1) == hash(entity2)
    
    def test_string_representation(self):
        """Deve ter representação string adequada."""
        # Arrange
        entity = self._create_valid_entity()
        
        # Act
        str_repr = str(entity)
        repr_repr = repr(entity)
        
        # Assert
        assert "Entity" in str_repr
        assert entity.id.value in str_repr
        assert entity.name.value in str_repr
        assert "Entity" in repr_repr
    
    def test_create_new_factory_method(self):
        """Deve criar nova entidade usando factory method."""
        # Arrange
        name = EntityName("New Entity")
        entity_type = EntityType("DATASET")
        description = Description("Test description")
        owner = Email("owner@example.com")
        
        # Act
        entity = Entity.create_new(
            name=name,
            type=entity_type,
            description=description,
            owner=owner
        )
        
        # Assert
        assert entity.name == name
        assert entity.type == entity_type
        assert entity.description == description
        assert entity.metadata.owner == owner
        assert entity.is_active()
    
    def test_create_table_entity_factory_method(self):
        """Deve criar entidade TABLE usando factory method."""
        # Arrange
        name = EntityName("Test Table")
        schema = {"columns": [{"name": "id", "type": "int"}]}
        description = Description("Test table")
        owner = Email("owner@example.com")
        
        # Act
        entity = Entity.create_table_entity(
            name=name,
            schema=schema,
            description=description,
            owner=owner
        )
        
        # Assert
        assert entity.name == name
        assert entity.type.value == "TABLE"
        assert entity.description == description
        assert entity.metadata.owner == owner
        assert entity.metadata.schema_definition == schema
    
    def _create_valid_entity(self) -> Entity:
        """Helper para criar entidade válida para testes."""
        return Entity(
            id=EntityId("test-entity"),
            name=EntityName("Test Entity"),
            type=EntityType("DATASET"),
            description=Description("Test description")
        )

