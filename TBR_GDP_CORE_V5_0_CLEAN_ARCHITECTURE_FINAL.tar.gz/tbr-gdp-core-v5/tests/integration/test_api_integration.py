"""
TBR GDP Core v5.0 - Integration Tests
Autor: Carlos Morais <carlos.morais@f1rst.com.br>

Testes de integração para validar a API completa.
Testa o fluxo completo desde o controller até o repositório.
"""

import pytest
import asyncio
from httpx import AsyncClient
from fastapi.testclient import TestClient
from unittest.mock import Mock, AsyncMock, patch

from src.main import app
from src.domain.entities.entity import Entity
from src.domain.value_objects import EntityId, EntityType, EntityStatus
from src.domain.repositories import EntityRepositoryInterface


class TestEntityAPIIntegration:
    """Testes de integração para API de entidades."""
    
    def setup_method(self):
        """Setup para cada teste."""
        self.client = TestClient(app)
        
        # Mock do repositório para testes
        self.mock_repository = AsyncMock(spec=EntityRepositoryInterface)
        
        # Patch do container DI
        self.container_patcher = patch('src.shared.di_container.DIContainer.get_instance')
        self.mock_container = self.container_patcher.start()
        self.mock_container.return_value.get.return_value = self.mock_repository
    
    def teardown_method(self):
        """Cleanup após cada teste."""
        self.container_patcher.stop()
    
    def test_root_endpoint(self):
        """Deve retornar informações da API no endpoint raiz."""
        # Act
        response = self.client.get("/")
        
        # Assert
        assert response.status_code == 200
        data = response.json()
        assert data["name"] == "TBR GDP Core"
        assert data["version"] == "5.0.0"
        assert "endpoints" in data
        assert "features" in data
    
    def test_health_check_endpoint(self):
        """Deve retornar status de saúde da aplicação."""
        # Act
        response = self.client.get("/health")
        
        # Assert
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "healthy"
        assert data["version"] == "5.0.0"
        assert "components" in data
    
    def test_api_info_endpoint(self):
        """Deve retornar informações detalhadas da API."""
        # Act
        response = self.client.get("/api/v1/info")
        
        # Assert
        assert response.status_code == 200
        data = response.json()
        assert data["api"]["name"] == "TBR GDP Core API"
        assert data["architecture"]["pattern"] == "Clean Architecture"
        assert "domains" in data
    
    def test_create_entity_success(self):
        """Deve criar entidade com sucesso."""
        # Arrange
        entity_data = {
            "name": "Test Entity",
            "entity_type": "TABLE",
            "description": "Test description",
            "schema_definition": {
                "columns": [
                    {"name": "id", "type": "integer"},
                    {"name": "name", "type": "string"}
                ]
            },
            "data_owner": "test.owner@company.com"
        }
        
        # Mock da entidade criada
        created_entity = Entity.create_table_entity(
            name="Test Entity",
            description="Test description",
            schema_definition=entity_data["schema_definition"],
            data_owner="test.owner@company.com"
        )
        
        self.mock_repository.save.return_value = created_entity
        self.mock_repository.find_by_name.return_value = None  # Não existe
        
        # Act
        response = self.client.post("/api/v1/entities/", json=entity_data)
        
        # Assert
        assert response.status_code == 201
        data = response.json()
        assert data["name"] == "Test Entity"
        assert data["entity_type"] == "TABLE"
        assert data["status"] == "DRAFT"
        assert "id" in data
        assert "created_at" in data
    
    def test_create_entity_validation_error(self):
        """Deve retornar erro de validação para dados inválidos."""
        # Arrange
        invalid_data = {
            "name": "",  # Nome vazio
            "entity_type": "TABLE",
            # schema_definition ausente para TABLE
        }
        
        # Act
        response = self.client.post("/api/v1/entities/", json=invalid_data)
        
        # Assert
        assert response.status_code == 422  # Validation error
        data = response.json()
        assert "error" in data
    
    def test_get_entity_success(self):
        """Deve retornar entidade existente."""
        # Arrange
        entity_id = "test-entity-123"
        entity = Entity.create_table_entity(
            name="Test Entity",
            schema_definition={"columns": [{"name": "id", "type": "integer"}]}
        )
        
        self.mock_repository.find_by_id.return_value = entity
        
        # Act
        response = self.client.get(f"/api/v1/entities/{entity_id}")
        
        # Assert
        assert response.status_code == 200
        data = response.json()
        assert data["name"] == "Test Entity"
        assert data["entity_type"] == "TABLE"
    
    def test_get_entity_not_found(self):
        """Deve retornar 404 para entidade não encontrada."""
        # Arrange
        entity_id = "non-existent-entity"
        self.mock_repository.find_by_id.return_value = None
        
        # Act
        response = self.client.get(f"/api/v1/entities/{entity_id}")
        
        # Assert
        assert response.status_code == 404
        data = response.json()
        assert "error" in data
        assert data["error"]["code"] == "ENTITY_NOT_FOUND"
    
    def test_update_entity_success(self):
        """Deve atualizar entidade com sucesso."""
        # Arrange
        entity_id = "test-entity-123"
        update_data = {
            "name": "Updated Entity Name",
            "description": "Updated description"
        }
        
        # Mock da entidade existente
        existing_entity = Entity.create_table_entity(
            name="Original Name",
            schema_definition={"columns": [{"name": "id", "type": "integer"}]}
        )
        
        # Mock da entidade atualizada
        updated_entity = Entity.create_table_entity(
            name="Updated Entity Name",
            description="Updated description",
            schema_definition={"columns": [{"name": "id", "type": "integer"}]}
        )
        
        self.mock_repository.find_by_id.return_value = existing_entity
        self.mock_repository.save.return_value = updated_entity
        
        # Act
        response = self.client.put(f"/api/v1/entities/{entity_id}", json=update_data)
        
        # Assert
        assert response.status_code == 200
        data = response.json()
        assert data["name"] == "Updated Entity Name"
        assert data["description"] == "Updated description"
    
    def test_change_entity_status_success(self):
        """Deve alterar status da entidade com sucesso."""
        # Arrange
        entity_id = "test-entity-123"
        status_data = {
            "new_status": "ACTIVE",
            "reason": "Entity is ready for production"
        }
        
        # Mock da entidade
        entity = Entity.create_table_entity(
            name="Test Entity",
            schema_definition={"columns": [{"name": "id", "type": "integer"}]}
        )
        
        self.mock_repository.find_by_id.return_value = entity
        self.mock_repository.save.return_value = entity
        
        # Act
        response = self.client.patch(f"/api/v1/entities/{entity_id}/status", json=status_data)
        
        # Assert
        assert response.status_code == 200
        data = response.json()
        # O status seria alterado no use case real
    
    def test_delete_entity_success(self):
        """Deve deletar entidade com sucesso."""
        # Arrange
        entity_id = "test-entity-123"
        entity = Entity.create_table_entity(
            name="Test Entity",
            schema_definition={"columns": [{"name": "id", "type": "integer"}]}
        )
        
        self.mock_repository.find_by_id.return_value = entity
        self.mock_repository.delete.return_value = None
        
        # Act
        response = self.client.delete(f"/api/v1/entities/{entity_id}")
        
        # Assert
        assert response.status_code == 204
    
    def test_search_entities_success(self):
        """Deve buscar entidades com sucesso."""
        # Arrange
        entities = [
            Entity.create_table_entity(
                name="Entity 1",
                schema_definition={"columns": [{"name": "id", "type": "integer"}]}
            ),
            Entity.create_table_entity(
                name="Entity 2", 
                schema_definition={"columns": [{"name": "id", "type": "integer"}]}
            )
        ]
        
        # Mock do resultado de busca
        search_result = Mock()
        search_result.entities = entities
        search_result.total = 2
        search_result.page = 1
        search_result.page_size = 20
        
        self.mock_repository.search.return_value = search_result
        
        # Act
        response = self.client.get("/api/v1/entities/?query=test&page=1&page_size=20")
        
        # Assert
        assert response.status_code == 200
        data = response.json()
        assert data["total"] == 2
        assert len(data["entities"]) == 2
        assert data["page"] == 1
        assert data["page_size"] == 20
    
    def test_search_entities_with_filters(self):
        """Deve buscar entidades com filtros."""
        # Arrange
        search_result = Mock()
        search_result.entities = []
        search_result.total = 0
        search_result.page = 1
        search_result.page_size = 20
        
        self.mock_repository.search.return_value = search_result
        
        # Act
        response = self.client.get(
            "/api/v1/entities/?entity_type=TABLE&status=ACTIVE&data_owner=test.owner"
        )
        
        # Assert
        assert response.status_code == 200
        data = response.json()
        assert data["total"] == 0
        assert len(data["entities"]) == 0


class TestAPIErrorHandling:
    """Testes específicos para tratamento de erros da API."""
    
    def setup_method(self):
        """Setup para cada teste."""
        self.client = TestClient(app)
    
    def test_invalid_json_request(self):
        """Deve tratar JSON inválido adequadamente."""
        # Act
        response = self.client.post(
            "/api/v1/entities/",
            data="invalid json",
            headers={"Content-Type": "application/json"}
        )
        
        # Assert
        assert response.status_code == 422
    
    def test_missing_required_fields(self):
        """Deve validar campos obrigatórios."""
        # Arrange
        incomplete_data = {
            "description": "Missing name and type"
        }
        
        # Act
        response = self.client.post("/api/v1/entities/", json=incomplete_data)
        
        # Assert
        assert response.status_code == 422
        data = response.json()
        assert "error" in data
    
    def test_invalid_entity_type(self):
        """Deve validar tipos de entidade."""
        # Arrange
        invalid_data = {
            "name": "Test Entity",
            "entity_type": "INVALID_TYPE"
        }
        
        # Act
        response = self.client.post("/api/v1/entities/", json=invalid_data)
        
        # Assert
        assert response.status_code == 422


@pytest.mark.asyncio
class TestAsyncAPIIntegration:
    """Testes assíncronos para a API."""
    
    async def test_async_client_create_entity(self):
        """Deve criar entidade usando cliente assíncrono."""
        async with AsyncClient(app=app, base_url="http://test") as client:
            # Arrange
            entity_data = {
                "name": "Async Test Entity",
                "entity_type": "VIEW",
                "description": "Created via async client"
            }
            
            # Mock do repositório
            with patch('src.shared.di_container.DIContainer.get_instance') as mock_container:
                mock_repo = AsyncMock(spec=EntityRepositoryInterface)
                mock_container.return_value.get.return_value = mock_repo
                
                created_entity = Entity.create_view_entity(
                    name="Async Test Entity",
                    description="Created via async client"
                )
                mock_repo.save.return_value = created_entity
                mock_repo.find_by_name.return_value = None
                
                # Act
                response = await client.post("/api/v1/entities/", json=entity_data)
                
                # Assert
                assert response.status_code == 201
                data = response.json()
                assert data["name"] == "Async Test Entity"
                assert data["entity_type"] == "VIEW"

