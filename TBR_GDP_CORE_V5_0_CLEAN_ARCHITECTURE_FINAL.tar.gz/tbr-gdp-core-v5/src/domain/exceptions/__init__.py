"""
TBR GDP Core v5.0 - Domain Exceptions
Autor: Carlos Morais <carlos.morais@f1rst.com.br>

Hierarquia estruturada de exceções seguindo princípios SOLID.
"""

from typing import List, Optional, Dict, Any


class TBRGDPError(Exception):
    """
    Exceção base do sistema TBR GDP Core.
    
    Todas as exceções do sistema devem herdar desta classe.
    Segue o princípio de hierarquia bem definida.
    """
    
    def __init__(self, message: str, error_code: Optional[str] = None, details: Optional[Dict[str, Any]] = None):
        self.message = message
        self.error_code = error_code or self.__class__.__name__
        self.details = details or {}
        super().__init__(self.message)
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte a exceção para dicionário para serialização."""
        return {
            "error_code": self.error_code,
            "message": self.message,
            "details": self.details,
            "type": self.__class__.__name__
        }


class DomainError(TBRGDPError):
    """
    Exceção base para erros de domínio.
    
    Representa violações de regras de negócio ou estados inválidos
    no domínio da aplicação.
    """
    pass


class ValidationError(DomainError):
    """
    Erro de validação de dados.
    
    Usado quando dados não atendem aos critérios de validação
    definidos pelas regras de negócio.
    """
    
    def __init__(self, errors: List[str], field: Optional[str] = None):
        self.errors = errors
        self.field = field
        
        message = f"Validation failed"
        if field:
            message += f" for field '{field}'"
        message += f": {', '.join(errors)}"
        
        super().__init__(
            message=message,
            error_code="VALIDATION_ERROR",
            details={"errors": errors, "field": field}
        )


class EntityNotFoundError(DomainError):
    """
    Erro quando uma entidade não é encontrada.
    
    Usado quando se tenta acessar uma entidade que não existe
    no repositório.
    """
    
    def __init__(self, entity_type: str, identifier: str):
        self.entity_type = entity_type
        self.identifier = identifier
        
        message = f"{entity_type} with identifier '{identifier}' not found"
        
        super().__init__(
            message=message,
            error_code="ENTITY_NOT_FOUND",
            details={"entity_type": entity_type, "identifier": identifier}
        )


class EntityAlreadyExistsError(DomainError):
    """
    Erro quando se tenta criar uma entidade que já existe.
    
    Usado para evitar duplicação de entidades com identificadores únicos.
    """
    
    def __init__(self, entity_type: str, identifier: str):
        self.entity_type = entity_type
        self.identifier = identifier
        
        message = f"{entity_type} with identifier '{identifier}' already exists"
        
        super().__init__(
            message=message,
            error_code="ENTITY_ALREADY_EXISTS",
            details={"entity_type": entity_type, "identifier": identifier}
        )


class BusinessRuleViolationError(DomainError):
    """
    Erro quando uma regra de negócio é violada.
    
    Usado para representar violações específicas de regras de domínio
    que não se encaixam em outras categorias.
    """
    
    def __init__(self, rule_name: str, description: str, context: Optional[Dict[str, Any]] = None):
        self.rule_name = rule_name
        self.description = description
        self.context = context or {}
        
        message = f"Business rule '{rule_name}' violated: {description}"
        
        super().__init__(
            message=message,
            error_code="BUSINESS_RULE_VIOLATION",
            details={"rule_name": rule_name, "description": description, "context": context}
        )


class InfrastructureError(TBRGDPError):
    """
    Exceção base para erros de infraestrutura.
    
    Representa problemas com componentes externos como banco de dados,
    serviços externos, sistema de arquivos, etc.
    """
    pass


class DatabaseError(InfrastructureError):
    """
    Erro relacionado ao banco de dados.
    
    Usado para problemas de conexão, queries malformadas,
    violações de constraints, etc.
    """
    
    def __init__(self, operation: str, original_error: Optional[Exception] = None):
        self.operation = operation
        self.original_error = original_error
        
        message = f"Database error during {operation}"
        if original_error:
            message += f": {str(original_error)}"
        
        super().__init__(
            message=message,
            error_code="DATABASE_ERROR",
            details={"operation": operation, "original_error": str(original_error) if original_error else None}
        )


class ExternalServiceError(InfrastructureError):
    """
    Erro relacionado a serviços externos.
    
    Usado para problemas de comunicação com APIs externas,
    timeouts, respostas inválidas, etc.
    """
    
    def __init__(self, service_name: str, operation: str, status_code: Optional[int] = None):
        self.service_name = service_name
        self.operation = operation
        self.status_code = status_code
        
        message = f"External service '{service_name}' error during {operation}"
        if status_code:
            message += f" (HTTP {status_code})"
        
        super().__init__(
            message=message,
            error_code="EXTERNAL_SERVICE_ERROR",
            details={"service_name": service_name, "operation": operation, "status_code": status_code}
        )


class ConfigurationError(InfrastructureError):
    """
    Erro de configuração da aplicação.
    
    Usado quando configurações necessárias estão ausentes
    ou têm valores inválidos.
    """
    
    def __init__(self, config_key: str, reason: str):
        self.config_key = config_key
        self.reason = reason
        
        message = f"Configuration error for '{config_key}': {reason}"
        
        super().__init__(
            message=message,
            error_code="CONFIGURATION_ERROR",
            details={"config_key": config_key, "reason": reason}
        )


class ApplicationError(TBRGDPError):
    """
    Exceção base para erros da camada de aplicação.
    
    Representa problemas na coordenação entre casos de uso,
    mapeamento de dados, etc.
    """
    pass


class MappingError(ApplicationError):
    """
    Erro durante mapeamento de dados.
    
    Usado quando há problemas na conversão entre DTOs,
    entidades de domínio e modelos de persistência.
    """
    
    def __init__(self, source_type: str, target_type: str, reason: str):
        self.source_type = source_type
        self.target_type = target_type
        self.reason = reason
        
        message = f"Mapping error from {source_type} to {target_type}: {reason}"
        
        super().__init__(
            message=message,
            error_code="MAPPING_ERROR",
            details={"source_type": source_type, "target_type": target_type, "reason": reason}
        )


class AuthorizationError(TBRGDPError):
    """
    Erro de autorização.
    
    Usado quando um usuário não tem permissão para
    executar uma operação específica.
    """
    
    def __init__(self, user_id: str, operation: str, resource: Optional[str] = None):
        self.user_id = user_id
        self.operation = operation
        self.resource = resource
        
        message = f"User '{user_id}' not authorized to {operation}"
        if resource:
            message += f" on resource '{resource}'"
        
        super().__init__(
            message=message,
            error_code="AUTHORIZATION_ERROR",
            details={"user_id": user_id, "operation": operation, "resource": resource}
        )


class AuthenticationError(TBRGDPError):
    """
    Erro de autenticação.
    
    Usado quando credenciais são inválidas ou
    tokens de autenticação são inválidos/expirados.
    """
    
    def __init__(self, reason: str):
        self.reason = reason
        
        message = f"Authentication failed: {reason}"
        
        super().__init__(
            message=message,
            error_code="AUTHENTICATION_ERROR",
            details={"reason": reason}
        )

