"""
TBR GDP Core v5.0 - Repository Interfaces
Autor: Carlos Morais <carlos.morais@f1rst.com.br>

Interfaces de repositório seguindo princípios SOLID.
Define contratos para persistência de dados sem depender de implementações específicas.
"""

from abc import ABC, abstractmethod
from typing import List, Optional, Dict, Any, TypeVar, Generic
from dataclasses import dataclass

from ..value_objects import EntityId
from ..exceptions import EntityNotFoundError


# Type variable para entidades genéricas
T = TypeVar('T')


@dataclass
class SearchCriteria:
    """
    Critérios de busca para repositórios.
    
    Encapsula parâmetros de busca de forma type-safe.
    """
    
    filters: Dict[str, Any]
    sort_by: Optional[str] = None
    sort_order: str = 'asc'  # 'asc' ou 'desc'
    limit: Optional[int] = None
    offset: int = 0
    
    def __post_init__(self):
        if self.sort_order not in ['asc', 'desc']:
            raise ValueError("sort_order must be 'asc' or 'desc'")
        
        if self.limit is not None and self.limit <= 0:
            raise ValueError("limit must be positive")
        
        if self.offset < 0:
            raise ValueError("offset must be non-negative")


@dataclass
class SearchResult(Generic[T]):
    """
    Resultado de busca paginada.
    
    Encapsula resultados com metadados de paginação.
    """
    
    items: List[T]
    total_count: int
    offset: int
    limit: Optional[int]
    
    @property
    def has_more(self) -> bool:
        """Verifica se há mais itens disponíveis."""
        if self.limit is None:
            return False
        return self.offset + len(self.items) < self.total_count
    
    @property
    def current_page(self) -> int:
        """Retorna a página atual (baseada em 1)."""
        if self.limit is None or self.limit == 0:
            return 1
        return (self.offset // self.limit) + 1
    
    @property
    def total_pages(self) -> int:
        """Retorna o total de páginas."""
        if self.limit is None or self.limit == 0:
            return 1
        return (self.total_count + self.limit - 1) // self.limit


class Repository(ABC, Generic[T]):
    """
    Interface base para repositórios.
    
    Define operações CRUD básicas que todos os repositórios devem implementar.
    Segue o princípio da Interface Segregation (ISP) do SOLID.
    """
    
    @abstractmethod
    async def find_by_id(self, entity_id: EntityId) -> Optional[T]:
        """
        Busca uma entidade por ID.
        
        Args:
            entity_id: ID da entidade
            
        Returns:
            Entidade encontrada ou None se não existir
        """
        pass
    
    @abstractmethod
    async def save(self, entity: T) -> T:
        """
        Salva uma entidade (create ou update).
        
        Args:
            entity: Entidade a ser salva
            
        Returns:
            Entidade salva com dados atualizados
        """
        pass
    
    @abstractmethod
    async def delete(self, entity_id: EntityId) -> None:
        """
        Remove uma entidade por ID.
        
        Args:
            entity_id: ID da entidade a ser removida
            
        Raises:
            EntityNotFoundError: Se a entidade não existir
        """
        pass
    
    @abstractmethod
    async def exists(self, entity_id: EntityId) -> bool:
        """
        Verifica se uma entidade existe.
        
        Args:
            entity_id: ID da entidade
            
        Returns:
            True se a entidade existir, False caso contrário
        """
        pass


class SearchableRepository(Repository[T]):
    """
    Interface para repositórios que suportam busca.
    
    Estende a interface base com capacidades de busca e listagem.
    """
    
    @abstractmethod
    async def find_all(self, criteria: Optional[SearchCriteria] = None) -> SearchResult[T]:
        """
        Busca todas as entidades com critérios opcionais.
        
        Args:
            criteria: Critérios de busca opcionais
            
        Returns:
            Resultado da busca com paginação
        """
        pass
    
    @abstractmethod
    async def count(self, filters: Optional[Dict[str, Any]] = None) -> int:
        """
        Conta o número de entidades que atendem aos filtros.
        
        Args:
            filters: Filtros opcionais
            
        Returns:
            Número de entidades
        """
        pass


class EntityRepositoryInterface(SearchableRepository):
    """
    Interface específica para repositório de entidades.
    
    Define operações específicas para o domínio de entidades.
    Segue o princípio da responsabilidade única (SRP).
    """
    
    @abstractmethod
    async def find_by_name(self, name: str) -> Optional[Any]:
        """
        Busca uma entidade por nome.
        
        Args:
            name: Nome da entidade
            
        Returns:
            Entidade encontrada ou None
        """
        pass
    
    @abstractmethod
    async def find_by_type(self, entity_type: str) -> List[Any]:
        """
        Busca entidades por tipo.
        
        Args:
            entity_type: Tipo da entidade
            
        Returns:
            Lista de entidades do tipo especificado
        """
        pass
    
    @abstractmethod
    async def find_by_status(self, status: str) -> List[Any]:
        """
        Busca entidades por status.
        
        Args:
            status: Status da entidade
            
        Returns:
            Lista de entidades com o status especificado
        """
        pass
    
    @abstractmethod
    async def find_active_entities(self) -> List[Any]:
        """
        Busca todas as entidades ativas.
        
        Returns:
            Lista de entidades ativas
        """
        pass


class ContractRepositoryInterface(SearchableRepository):
    """
    Interface específica para repositório de contratos.
    
    Define operações específicas para o domínio de contratos de dados.
    """
    
    @abstractmethod
    async def find_by_entity_id(self, entity_id: EntityId) -> List[Any]:
        """
        Busca contratos por ID da entidade.
        
        Args:
            entity_id: ID da entidade
            
        Returns:
            Lista de contratos da entidade
        """
        pass
    
    @abstractmethod
    async def find_active_contracts(self) -> List[Any]:
        """
        Busca todos os contratos ativos.
        
        Returns:
            Lista de contratos ativos
        """
        pass
    
    @abstractmethod
    async def find_by_version(self, contract_id: EntityId, version: str) -> Optional[Any]:
        """
        Busca um contrato por ID e versão.
        
        Args:
            contract_id: ID do contrato
            version: Versão do contrato
            
        Returns:
            Contrato encontrado ou None
        """
        pass


class QualityRuleRepositoryInterface(SearchableRepository):
    """
    Interface específica para repositório de regras de qualidade.
    
    Define operações específicas para o domínio de qualidade de dados.
    """
    
    @abstractmethod
    async def find_by_entity_id(self, entity_id: EntityId) -> List[Any]:
        """
        Busca regras de qualidade por ID da entidade.
        
        Args:
            entity_id: ID da entidade
            
        Returns:
            Lista de regras de qualidade da entidade
        """
        pass
    
    @abstractmethod
    async def find_active_rules(self) -> List[Any]:
        """
        Busca todas as regras de qualidade ativas.
        
        Returns:
            Lista de regras ativas
        """
        pass
    
    @abstractmethod
    async def find_by_rule_type(self, rule_type: str) -> List[Any]:
        """
        Busca regras por tipo.
        
        Args:
            rule_type: Tipo da regra
            
        Returns:
            Lista de regras do tipo especificado
        """
        pass


class AuditLogRepositoryInterface(Repository):
    """
    Interface específica para repositório de logs de auditoria.
    
    Define operações específicas para auditoria.
    """
    
    @abstractmethod
    async def log_operation(
        self, 
        entity_type: str, 
        entity_id: str, 
        operation: str, 
        user_id: str, 
        details: Optional[Dict[str, Any]] = None
    ) -> None:
        """
        Registra uma operação de auditoria.
        
        Args:
            entity_type: Tipo da entidade
            entity_id: ID da entidade
            operation: Operação realizada
            user_id: ID do usuário
            details: Detalhes adicionais
        """
        pass
    
    @abstractmethod
    async def find_by_entity(self, entity_type: str, entity_id: str) -> List[Any]:
        """
        Busca logs por entidade.
        
        Args:
            entity_type: Tipo da entidade
            entity_id: ID da entidade
            
        Returns:
            Lista de logs da entidade
        """
        pass
    
    @abstractmethod
    async def find_by_user(self, user_id: str) -> List[Any]:
        """
        Busca logs por usuário.
        
        Args:
            user_id: ID do usuário
            
        Returns:
            Lista de logs do usuário
        """
        pass


class UnitOfWork(ABC):
    """
    Interface para Unit of Work pattern.
    
    Gerencia transações e coordena mudanças em múltiplos repositórios.
    """
    
    @abstractmethod
    async def __aenter__(self):
        """Inicia uma transação."""
        pass
    
    @abstractmethod
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Finaliza uma transação (commit ou rollback)."""
        pass
    
    @abstractmethod
    async def commit(self) -> None:
        """Confirma as mudanças."""
        pass
    
    @abstractmethod
    async def rollback(self) -> None:
        """Desfaz as mudanças."""
        pass
    
    @property
    @abstractmethod
    def entities(self) -> EntityRepositoryInterface:
        """Repositório de entidades."""
        pass
    
    @property
    @abstractmethod
    def contracts(self) -> ContractRepositoryInterface:
        """Repositório de contratos."""
        pass
    
    @property
    @abstractmethod
    def quality_rules(self) -> QualityRuleRepositoryInterface:
        """Repositório de regras de qualidade."""
        pass
    
    @property
    @abstractmethod
    def audit_logs(self) -> AuditLogRepositoryInterface:
        """Repositório de logs de auditoria."""
        pass

