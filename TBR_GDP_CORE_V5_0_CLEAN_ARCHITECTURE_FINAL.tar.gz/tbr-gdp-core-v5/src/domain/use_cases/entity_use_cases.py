"""
TBR GDP Core v5.0 - Entity Use Cases
Autor: Carlos Morais <carlos.morais@f1rst.com.br>

Casos de uso para o domínio de Entity seguindo Clean Architecture.
Implementa a lógica de aplicação sem depender de detalhes de infraestrutura.
"""

from abc import ABC, abstractmethod
from typing import List, Optional, Dict, Any
from dataclasses import dataclass

from ..entities.entity import Entity
from ..value_objects import EntityId, EntityName, EntityType, EntityStatus, Description, Email
from ..repositories import EntityRepositoryInterface, SearchCriteria, SearchResult
from ..exceptions import EntityNotFoundError, EntityAlreadyExistsError, BusinessRuleViolationError


@dataclass
class CreateEntityCommand:
    """
    Comando para criar uma nova entidade.
    
    Encapsula todos os dados necessários para criar uma entidade.
    """
    name: str
    type: str
    description: str = ""
    owner: Optional[str] = None
    steward: Optional[str] = None
    tags: List[str] = None
    schema_definition: Optional[Dict[str, Any]] = None
    
    def __post_init__(self):
        if self.tags is None:
            self.tags = []


@dataclass
class UpdateEntityCommand:
    """
    Comando para atualizar uma entidade existente.
    """
    entity_id: str
    name: Optional[str] = None
    description: Optional[str] = None
    owner: Optional[str] = None
    steward: Optional[str] = None
    tags: Optional[List[str]] = None
    schema_definition: Optional[Dict[str, Any]] = None


@dataclass
class ChangeEntityStatusCommand:
    """
    Comando para alterar o status de uma entidade.
    """
    entity_id: str
    new_status: str
    reason: Optional[str] = None


@dataclass
class SearchEntitiesQuery:
    """
    Query para buscar entidades.
    """
    name_filter: Optional[str] = None
    type_filter: Optional[str] = None
    status_filter: Optional[str] = None
    owner_filter: Optional[str] = None
    tags_filter: Optional[List[str]] = None
    has_owner: Optional[bool] = None
    has_steward: Optional[bool] = None
    min_quality_score: Optional[float] = None
    sort_by: Optional[str] = None
    sort_order: str = "asc"
    limit: Optional[int] = None
    offset: int = 0


class CreateEntityUseCase:
    """
    Caso de uso para criar uma nova entidade.
    
    Implementa a lógica de negócio para criação de entidades,
    incluindo validações e regras específicas.
    """
    
    def __init__(self, entity_repository: EntityRepositoryInterface):
        self._entity_repository = entity_repository
    
    async def execute(self, command: CreateEntityCommand) -> Entity:
        """
        Executa o caso de uso de criação de entidade.
        
        Args:
            command: Comando com dados da entidade
            
        Returns:
            Entidade criada
            
        Raises:
            EntityAlreadyExistsError: Se já existe entidade com o mesmo nome
            ValidationError: Se os dados são inválidos
        """
        # Validar se já existe entidade com o mesmo nome
        existing_entity = await self._entity_repository.find_by_name(command.name)
        if existing_entity:
            raise EntityAlreadyExistsError("Entity", command.name)
        
        # Criar value objects
        name = EntityName(command.name)
        entity_type = EntityType(command.type)
        description = Description(command.description)
        
        # Criar entidade usando factory method apropriado
        if entity_type.value == "TABLE" and command.schema_definition:
            owner = Email(command.owner) if command.owner else None
            entity = Entity.create_table_entity(
                name=name,
                schema=command.schema_definition,
                description=description,
                owner=owner
            )
        else:
            owner = Email(command.owner) if command.owner else None
            entity = Entity.create_new(
                name=name,
                type=entity_type,
                description=description,
                owner=owner
            )
        
        # Adicionar steward se fornecido
        if command.steward:
            steward = Email(command.steward)
            entity.assign_steward(steward)
        
        # Adicionar tags se fornecidas
        for tag in command.tags:
            entity.add_tag(tag)
        
        # Salvar no repositório
        saved_entity = await self._entity_repository.save(entity)
        
        return saved_entity


class UpdateEntityUseCase:
    """
    Caso de uso para atualizar uma entidade existente.
    """
    
    def __init__(self, entity_repository: EntityRepositoryInterface):
        self._entity_repository = entity_repository
    
    async def execute(self, command: UpdateEntityCommand) -> Entity:
        """
        Executa o caso de uso de atualização de entidade.
        
        Args:
            command: Comando com dados de atualização
            
        Returns:
            Entidade atualizada
            
        Raises:
            EntityNotFoundError: Se a entidade não existir
        """
        # Buscar entidade existente
        entity_id = EntityId(command.entity_id)
        entity = await self._entity_repository.find_by_id(entity_id)
        
        if not entity:
            raise EntityNotFoundError("Entity", command.entity_id)
        
        # Aplicar atualizações
        if command.name:
            new_name = EntityName(command.name)
            entity.update_name(new_name)
        
        if command.description is not None:
            new_description = Description(command.description)
            entity.update_description(new_description)
        
        if command.owner:
            owner = Email(command.owner)
            entity.assign_owner(owner)
        
        if command.steward:
            steward = Email(command.steward)
            entity.assign_steward(steward)
        
        if command.tags is not None:
            # Remove todas as tags existentes e adiciona as novas
            for existing_tag in entity.metadata.tags.copy():
                entity.remove_tag(existing_tag)
            
            for new_tag in command.tags:
                entity.add_tag(new_tag)
        
        if command.schema_definition:
            entity.set_schema_definition(command.schema_definition)
        
        # Salvar alterações
        updated_entity = await self._entity_repository.save(entity)
        
        return updated_entity


class ChangeEntityStatusUseCase:
    """
    Caso de uso para alterar o status de uma entidade.
    """
    
    def __init__(self, entity_repository: EntityRepositoryInterface):
        self._entity_repository = entity_repository
    
    async def execute(self, command: ChangeEntityStatusCommand) -> Entity:
        """
        Executa o caso de uso de alteração de status.
        
        Args:
            command: Comando com novo status
            
        Returns:
            Entidade com status atualizado
            
        Raises:
            EntityNotFoundError: Se a entidade não existir
            BusinessRuleViolationError: Se a transição não for válida
        """
        # Buscar entidade existente
        entity_id = EntityId(command.entity_id)
        entity = await self._entity_repository.find_by_id(entity_id)
        
        if not entity:
            raise EntityNotFoundError("Entity", command.entity_id)
        
        # Se está sendo depreciada, deve ter retention policy
        new_status = EntityStatus(command.new_status)
        if new_status.value == "DEPRECATED" and not entity.metadata.retention_policy:
            # Define uma política padrão se não foi especificada
            entity.set_retention_policy("90 days after deprecation")
        
        # Alterar status (validações são feitas na entidade)
        entity.change_status(new_status)
        
        # Salvar alterações
        updated_entity = await self._entity_repository.save(entity)
        
        return updated_entity


class DeleteEntityUseCase:
    """
    Caso de uso para deletar uma entidade.
    """
    
    def __init__(self, entity_repository: EntityRepositoryInterface):
        self._entity_repository = entity_repository
    
    async def execute(self, entity_id: str) -> None:
        """
        Executa o caso de uso de deleção de entidade.
        
        Args:
            entity_id: ID da entidade a ser deletada
            
        Raises:
            EntityNotFoundError: Se a entidade não existir
            BusinessRuleViolationError: Se a entidade não puder ser deletada
        """
        # Buscar entidade existente
        id_obj = EntityId(entity_id)
        entity = await self._entity_repository.find_by_id(id_obj)
        
        if not entity:
            raise EntityNotFoundError("Entity", entity_id)
        
        # Verificar se pode ser deletada
        if not entity.can_be_deleted():
            raise BusinessRuleViolationError(
                "entity_cannot_be_deleted",
                f"Entity with status '{entity.status.value}' cannot be deleted",
                {"entity_id": entity_id, "status": entity.status.value}
            )
        
        # Deletar do repositório
        await self._entity_repository.delete(id_obj)


class GetEntityByIdUseCase:
    """
    Caso de uso para buscar uma entidade por ID.
    """
    
    def __init__(self, entity_repository: EntityRepositoryInterface):
        self._entity_repository = entity_repository
    
    async def execute(self, entity_id: str) -> Entity:
        """
        Executa o caso de uso de busca por ID.
        
        Args:
            entity_id: ID da entidade
            
        Returns:
            Entidade encontrada
            
        Raises:
            EntityNotFoundError: Se a entidade não existir
        """
        id_obj = EntityId(entity_id)
        entity = await self._entity_repository.find_by_id(id_obj)
        
        if not entity:
            raise EntityNotFoundError("Entity", entity_id)
        
        return entity


class SearchEntitiesUseCase:
    """
    Caso de uso para buscar entidades com filtros.
    """
    
    def __init__(self, entity_repository: EntityRepositoryInterface):
        self._entity_repository = entity_repository
    
    async def execute(self, query: SearchEntitiesQuery) -> SearchResult[Entity]:
        """
        Executa o caso de uso de busca de entidades.
        
        Args:
            query: Query com filtros de busca
            
        Returns:
            Resultado da busca com paginação
        """
        # Construir critérios de busca
        filters = {}
        
        if query.name_filter:
            filters["name"] = query.name_filter
        
        if query.type_filter:
            filters["type"] = query.type_filter
        
        if query.status_filter:
            filters["status"] = query.status_filter
        
        if query.owner_filter:
            filters["owner"] = query.owner_filter
        
        if query.tags_filter:
            filters["tags"] = query.tags_filter
        
        if query.has_owner is not None:
            filters["has_owner"] = query.has_owner
        
        if query.has_steward is not None:
            filters["has_steward"] = query.has_steward
        
        if query.min_quality_score is not None:
            filters["min_quality_score"] = query.min_quality_score
        
        # Criar critérios de busca
        criteria = SearchCriteria(
            filters=filters,
            sort_by=query.sort_by,
            sort_order=query.sort_order,
            limit=query.limit,
            offset=query.offset
        )
        
        # Executar busca
        result = await self._entity_repository.find_all(criteria)
        
        return result


class GetActiveEntitiesUseCase:
    """
    Caso de uso para buscar todas as entidades ativas.
    """
    
    def __init__(self, entity_repository: EntityRepositoryInterface):
        self._entity_repository = entity_repository
    
    async def execute(self) -> List[Entity]:
        """
        Executa o caso de uso de busca de entidades ativas.
        
        Returns:
            Lista de entidades ativas
        """
        entities = await self._entity_repository.find_active_entities()
        return entities


class GetEntitiesByTypeUseCase:
    """
    Caso de uso para buscar entidades por tipo.
    """
    
    def __init__(self, entity_repository: EntityRepositoryInterface):
        self._entity_repository = entity_repository
    
    async def execute(self, entity_type: str) -> List[Entity]:
        """
        Executa o caso de uso de busca por tipo.
        
        Args:
            entity_type: Tipo das entidades
            
        Returns:
            Lista de entidades do tipo especificado
        """
        # Validar tipo
        EntityType(entity_type)  # Valida se é um tipo válido
        
        entities = await self._entity_repository.find_by_type(entity_type)
        return entities


class UpdateEntityQualityUseCase:
    """
    Caso de uso para atualizar métricas de qualidade de uma entidade.
    """
    
    def __init__(self, entity_repository: EntityRepositoryInterface):
        self._entity_repository = entity_repository
    
    async def execute(
        self, 
        entity_id: str, 
        quality_scores: Dict[str, float]
    ) -> Entity:
        """
        Executa o caso de uso de atualização de qualidade.
        
        Args:
            entity_id: ID da entidade
            quality_scores: Dicionário com scores de qualidade
            
        Returns:
            Entidade com qualidade atualizada
            
        Raises:
            EntityNotFoundError: Se a entidade não existir
        """
        # Buscar entidade existente
        id_obj = EntityId(entity_id)
        entity = await self._entity_repository.find_by_id(id_obj)
        
        if not entity:
            raise EntityNotFoundError("Entity", entity_id)
        
        # Atualizar scores de qualidade
        for dimension, score in quality_scores.items():
            entity.update_quality_score(dimension, score)
        
        # Salvar alterações
        updated_entity = await self._entity_repository.save(entity)
        
        return updated_entity


class GetEntityStatisticsUseCase:
    """
    Caso de uso para obter estatísticas das entidades.
    """
    
    def __init__(self, entity_repository: EntityRepositoryInterface):
        self._entity_repository = entity_repository
    
    async def execute(self) -> Dict[str, Any]:
        """
        Executa o caso de uso de estatísticas.
        
        Returns:
            Dicionário com estatísticas das entidades
        """
        # Buscar todas as entidades
        all_entities_result = await self._entity_repository.find_all()
        all_entities = all_entities_result.items
        
        # Calcular estatísticas
        total_entities = len(all_entities)
        
        # Estatísticas por status
        status_counts = {}
        for entity in all_entities:
            status = entity.status.value
            status_counts[status] = status_counts.get(status, 0) + 1
        
        # Estatísticas por tipo
        type_counts = {}
        for entity in all_entities:
            entity_type = entity.type.value
            type_counts[entity_type] = type_counts.get(entity_type, 0) + 1
        
        # Estatísticas de governança
        entities_with_owner = sum(1 for e in all_entities if e.has_owner())
        entities_with_steward = sum(1 for e in all_entities if e.has_steward())
        entities_with_governance = sum(1 for e in all_entities if e.has_governance())
        
        # Estatísticas de qualidade
        high_quality_entities = sum(1 for e in all_entities if e.has_high_quality())
        avg_quality_score = (
            sum(e.quality_metrics.overall_score for e in all_entities) / total_entities
            if total_entities > 0 else 0
        )
        
        return {
            "total_entities": total_entities,
            "status_distribution": status_counts,
            "type_distribution": type_counts,
            "governance_stats": {
                "entities_with_owner": entities_with_owner,
                "entities_with_steward": entities_with_steward,
                "entities_with_governance": entities_with_governance,
                "governance_coverage": (
                    entities_with_governance / total_entities * 100
                    if total_entities > 0 else 0
                )
            },
            "quality_stats": {
                "high_quality_entities": high_quality_entities,
                "average_quality_score": avg_quality_score,
                "quality_coverage": (
                    high_quality_entities / total_entities * 100
                    if total_entities > 0 else 0
                )
            }
        }

