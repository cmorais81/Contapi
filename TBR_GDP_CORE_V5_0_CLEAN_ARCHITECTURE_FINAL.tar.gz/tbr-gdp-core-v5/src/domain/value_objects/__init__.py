"""
TBR GDP Core v5.0 - Value Objects
Autor: Carlos Morais <carlos.morais@f1rst.com.br>

Value Objects seguindo princípios DDD e SOLID.
Objetos imutáveis que representam conceitos de domínio.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, TypeVar, Generic
import re
import uuid
from datetime import datetime

from ..exceptions import ValidationError


T = TypeVar('T')


class ValueObject(ABC):
    """
    Classe base para Value Objects.
    
    Value Objects são imutáveis e sua igualdade é baseada
    em seus valores, não em identidade.
    """
    
    def __eq__(self, other: Any) -> bool:
        """Igualdade baseada em valor, não em identidade."""
        if not isinstance(other, self.__class__):
            return False
        return self.__dict__ == other.__dict__
    
    def __hash__(self) -> int:
        """Hash baseado nos valores dos atributos."""
        return hash(tuple(sorted(self.__dict__.items())))
    
    @abstractmethod
    def _validate(self) -> None:
        """Valida o valor do objeto. Deve ser implementado pelas subclasses."""
        pass


@dataclass(frozen=True)
class EntityId(ValueObject):
    """
    Value Object para identificadores de entidades.
    
    Garante que IDs sejam válidos e únicos.
    """
    
    value: str
    
    def __post_init__(self):
        self._validate()
    
    def _validate(self) -> None:
        """Valida o ID da entidade."""
        if not self.value:
            raise ValidationError(["Entity ID cannot be empty"], "entity_id")
        
        if not isinstance(self.value, str):
            raise ValidationError(["Entity ID must be a string"], "entity_id")
        
        if len(self.value) < 3:
            raise ValidationError(["Entity ID must have at least 3 characters"], "entity_id")
        
        if len(self.value) > 100:
            raise ValidationError(["Entity ID cannot exceed 100 characters"], "entity_id")
        
        # Permite apenas caracteres alfanuméricos, hífens e underscores
        if not re.match(r'^[a-zA-Z0-9_-]+$', self.value):
            raise ValidationError(
                ["Entity ID can only contain alphanumeric characters, hyphens and underscores"], 
                "entity_id"
            )
    
    @classmethod
    def generate(cls) -> 'EntityId':
        """Gera um novo ID único."""
        return cls(str(uuid.uuid4()))
    
    def __str__(self) -> str:
        return self.value


@dataclass(frozen=True)
class EntityName(ValueObject):
    """
    Value Object para nomes de entidades.
    
    Garante que nomes sejam válidos e bem formatados.
    """
    
    value: str
    
    def __post_init__(self):
        self._validate()
    
    def _validate(self) -> None:
        """Valida o nome da entidade."""
        if not self.value:
            raise ValidationError(["Entity name cannot be empty"], "entity_name")
        
        if not isinstance(self.value, str):
            raise ValidationError(["Entity name must be a string"], "entity_name")
        
        # Remove espaços extras
        cleaned_value = self.value.strip()
        if not cleaned_value:
            raise ValidationError(["Entity name cannot be only whitespace"], "entity_name")
        
        if len(cleaned_value) < 2:
            raise ValidationError(["Entity name must have at least 2 characters"], "entity_name")
        
        if len(cleaned_value) > 255:
            raise ValidationError(["Entity name cannot exceed 255 characters"], "entity_name")
        
        # Atualiza o valor limpo (hack para dataclass frozen)
        object.__setattr__(self, 'value', cleaned_value)
    
    def __str__(self) -> str:
        return self.value


@dataclass(frozen=True)
class EntityType(ValueObject):
    """
    Value Object para tipos de entidades.
    
    Define os tipos válidos de entidades no sistema.
    """
    
    value: str
    
    # Tipos válidos de entidades
    VALID_TYPES = {
        'TABLE': 'Database Table',
        'VIEW': 'Database View',
        'DATASET': 'Dataset',
        'API': 'API Endpoint',
        'FILE': 'File',
        'STREAM': 'Data Stream',
        'REPORT': 'Report',
        'DASHBOARD': 'Dashboard'
    }
    
    def __post_init__(self):
        self._validate()
    
    def _validate(self) -> None:
        """Valida o tipo da entidade."""
        if not self.value:
            raise ValidationError(["Entity type cannot be empty"], "entity_type")
        
        if not isinstance(self.value, str):
            raise ValidationError(["Entity type must be a string"], "entity_type")
        
        # Converte para uppercase
        upper_value = self.value.upper()
        
        if upper_value not in self.VALID_TYPES:
            valid_types = ', '.join(self.VALID_TYPES.keys())
            raise ValidationError(
                [f"Invalid entity type. Valid types are: {valid_types}"], 
                "entity_type"
            )
        
        # Atualiza o valor normalizado
        object.__setattr__(self, 'value', upper_value)
    
    @property
    def description(self) -> str:
        """Retorna a descrição do tipo."""
        return self.VALID_TYPES[self.value]
    
    @classmethod
    def valid_types(cls) -> list[str]:
        """Retorna lista de tipos válidos."""
        return list(cls.VALID_TYPES.keys())
    
    def __str__(self) -> str:
        return self.value


@dataclass(frozen=True)
class EntityStatus(ValueObject):
    """
    Value Object para status de entidades.
    
    Define os status válidos de entidades no sistema.
    """
    
    value: str
    
    # Status válidos
    ACTIVE = 'ACTIVE'
    INACTIVE = 'INACTIVE'
    DEPRECATED = 'DEPRECATED'
    IN_DEVELOPMENT = 'IN_DEVELOPMENT'
    ARCHIVED = 'ARCHIVED'
    
    VALID_STATUSES = {
        ACTIVE: 'Active and available for use',
        INACTIVE: 'Temporarily inactive',
        DEPRECATED: 'Deprecated, will be removed',
        IN_DEVELOPMENT: 'Under development',
        ARCHIVED: 'Archived for historical purposes'
    }
    
    def __post_init__(self):
        self._validate()
    
    def _validate(self) -> None:
        """Valida o status da entidade."""
        if not self.value:
            raise ValidationError(["Entity status cannot be empty"], "entity_status")
        
        if not isinstance(self.value, str):
            raise ValidationError(["Entity status must be a string"], "entity_status")
        
        # Converte para uppercase
        upper_value = self.value.upper()
        
        if upper_value not in self.VALID_STATUSES:
            valid_statuses = ', '.join(self.VALID_STATUSES.keys())
            raise ValidationError(
                [f"Invalid entity status. Valid statuses are: {valid_statuses}"], 
                "entity_status"
            )
        
        # Atualiza o valor normalizado
        object.__setattr__(self, 'value', upper_value)
    
    @property
    def description(self) -> str:
        """Retorna a descrição do status."""
        return self.VALID_STATUSES[self.value]
    
    def is_active(self) -> bool:
        """Verifica se o status é ativo."""
        return self.value == self.ACTIVE
    
    def is_available(self) -> bool:
        """Verifica se a entidade está disponível para uso."""
        return self.value in [self.ACTIVE, self.IN_DEVELOPMENT]
    
    def __str__(self) -> str:
        return self.value


@dataclass(frozen=True)
class Email(ValueObject):
    """
    Value Object para endereços de email.
    
    Garante que emails sejam válidos.
    """
    
    value: str
    
    def __post_init__(self):
        self._validate()
    
    def _validate(self) -> None:
        """Valida o formato do email."""
        if not self.value:
            raise ValidationError(["Email cannot be empty"], "email")
        
        if not isinstance(self.value, str):
            raise ValidationError(["Email must be a string"], "email")
        
        # Regex simples para validação de email
        email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        
        if not re.match(email_pattern, self.value):
            raise ValidationError(["Invalid email format"], "email")
        
        if len(self.value) > 254:  # RFC 5321
            raise ValidationError(["Email cannot exceed 254 characters"], "email")
    
    @property
    def domain(self) -> str:
        """Retorna o domínio do email."""
        return self.value.split('@')[1]
    
    @property
    def local_part(self) -> str:
        """Retorna a parte local do email."""
        return self.value.split('@')[0]
    
    def __str__(self) -> str:
        return self.value


@dataclass(frozen=True)
class Timestamp(ValueObject):
    """
    Value Object para timestamps.
    
    Representa um momento específico no tempo.
    """
    
    value: datetime
    
    def __post_init__(self):
        self._validate()
    
    def _validate(self) -> None:
        """Valida o timestamp."""
        if not self.value:
            raise ValidationError(["Timestamp cannot be empty"], "timestamp")
        
        if not isinstance(self.value, datetime):
            raise ValidationError(["Timestamp must be a datetime object"], "timestamp")
    
    @classmethod
    def now(cls) -> 'Timestamp':
        """Cria um timestamp com o momento atual."""
        return cls(datetime.utcnow())
    
    @classmethod
    def from_iso_string(cls, iso_string: str) -> 'Timestamp':
        """Cria um timestamp a partir de uma string ISO."""
        try:
            dt = datetime.fromisoformat(iso_string.replace('Z', '+00:00'))
            return cls(dt)
        except ValueError as e:
            raise ValidationError([f"Invalid ISO timestamp format: {str(e)}"], "timestamp")
    
    def to_iso_string(self) -> str:
        """Converte para string ISO."""
        return self.value.isoformat()
    
    def is_before(self, other: 'Timestamp') -> bool:
        """Verifica se este timestamp é anterior ao outro."""
        return self.value < other.value
    
    def is_after(self, other: 'Timestamp') -> bool:
        """Verifica se este timestamp é posterior ao outro."""
        return self.value > other.value
    
    def __str__(self) -> str:
        return self.to_iso_string()


@dataclass(frozen=True)
class Description(ValueObject):
    """
    Value Object para descrições.
    
    Representa descrições textuais com validação.
    """
    
    value: str
    
    def __post_init__(self):
        self._validate()
    
    def _validate(self) -> None:
        """Valida a descrição."""
        if self.value is None:
            # Descrição pode ser vazia, mas não None
            object.__setattr__(self, 'value', '')
            return
        
        if not isinstance(self.value, str):
            raise ValidationError(["Description must be a string"], "description")
        
        # Remove espaços extras
        cleaned_value = self.value.strip()
        
        if len(cleaned_value) > 2000:
            raise ValidationError(["Description cannot exceed 2000 characters"], "description")
        
        # Atualiza o valor limpo
        object.__setattr__(self, 'value', cleaned_value)
    
    def is_empty(self) -> bool:
        """Verifica se a descrição está vazia."""
        return not self.value
    
    def word_count(self) -> int:
        """Retorna o número de palavras na descrição."""
        if not self.value:
            return 0
        return len(self.value.split())
    
    def __str__(self) -> str:
        return self.value

