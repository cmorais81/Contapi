"""
TBR GDP Core v5.0 - Entity Domain Model
Autor: Carlos Morais <carlos.morais@f1rst.com.br>

Entidade rica de domínio seguindo princípios DDD e SOLID.
Contém comportamento e regras de negócio, não apenas dados.
"""

from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional
from datetime import datetime

from ..value_objects import (
    EntityId, EntityName, EntityType, EntityStatus, 
    Description, Timestamp, Email
)
from ..exceptions import (
    BusinessRuleViolationError, ValidationError
)


@dataclass
class EntityMetadata:
    """
    Metadados da entidade.
    
    Encapsula informações técnicas e de negócio sobre a entidade.
    """
    
    owner: Optional[Email] = None
    steward: Optional[Email] = None
    tags: List[str] = field(default_factory=list)
    properties: Dict[str, Any] = field(default_factory=dict)
    schema_definition: Optional[Dict[str, Any]] = None
    data_source: Optional[str] = None
    update_frequency: Optional[str] = None
    retention_policy: Optional[str] = None
    
    def add_tag(self, tag: str) -> None:
        """Adiciona uma tag aos metadados."""
        if not tag or not isinstance(tag, str):
            raise ValidationError(["Tag must be a non-empty string"], "tag")
        
        tag_normalized = tag.strip().lower()
        if tag_normalized not in [t.lower() for t in self.tags]:
            self.tags.append(tag.strip())
    
    def remove_tag(self, tag: str) -> None:
        """Remove uma tag dos metadados."""
        self.tags = [t for t in self.tags if t.lower() != tag.lower()]
    
    def has_tag(self, tag: str) -> bool:
        """Verifica se possui uma tag específica."""
        return tag.lower() in [t.lower() for t in self.tags]
    
    def set_property(self, key: str, value: Any) -> None:
        """Define uma propriedade customizada."""
        if not key or not isinstance(key, str):
            raise ValidationError(["Property key must be a non-empty string"], "property_key")
        
        self.properties[key] = value
    
    def get_property(self, key: str, default: Any = None) -> Any:
        """Obtém uma propriedade customizada."""
        return self.properties.get(key, default)
    
    def has_owner(self) -> bool:
        """Verifica se tem owner definido."""
        return self.owner is not None
    
    def has_steward(self) -> bool:
        """Verifica se tem steward definido."""
        return self.steward is not None


@dataclass
class QualityMetrics:
    """
    Métricas de qualidade da entidade.
    
    Encapsula informações sobre a qualidade dos dados.
    """
    
    completeness_score: float = 0.0
    accuracy_score: float = 0.0
    consistency_score: float = 0.0
    timeliness_score: float = 0.0
    validity_score: float = 0.0
    uniqueness_score: float = 0.0
    last_quality_check: Optional[Timestamp] = None
    
    def __post_init__(self):
        """Valida as métricas após inicialização."""
        self._validate_scores()
    
    def _validate_scores(self) -> None:
        """Valida se os scores estão no range válido (0.0 a 1.0)."""
        scores = [
            self.completeness_score, self.accuracy_score, self.consistency_score,
            self.timeliness_score, self.validity_score, self.uniqueness_score
        ]
        
        for score in scores:
            if not isinstance(score, (int, float)):
                raise ValidationError(["Quality scores must be numeric"], "quality_score")
            
            if not (0.0 <= score <= 1.0):
                raise ValidationError(["Quality scores must be between 0.0 and 1.0"], "quality_score")
    
    @property
    def overall_score(self) -> float:
        """Calcula o score geral de qualidade."""
        scores = [
            self.completeness_score, self.accuracy_score, self.consistency_score,
            self.timeliness_score, self.validity_score, self.uniqueness_score
        ]
        return sum(scores) / len(scores)
    
    def is_high_quality(self, threshold: float = 0.8) -> bool:
        """Verifica se a qualidade está acima do threshold."""
        return self.overall_score >= threshold
    
    def get_quality_level(self) -> str:
        """Retorna o nível de qualidade como string."""
        score = self.overall_score
        
        if score >= 0.9:
            return "EXCELLENT"
        elif score >= 0.8:
            return "GOOD"
        elif score >= 0.6:
            return "FAIR"
        elif score >= 0.4:
            return "POOR"
        else:
            return "CRITICAL"
    
    def update_score(self, dimension: str, score: float) -> None:
        """Atualiza um score específico."""
        if not (0.0 <= score <= 1.0):
            raise ValidationError([f"Score must be between 0.0 and 1.0"], "quality_score")
        
        dimension_lower = dimension.lower()
        
        if dimension_lower == "completeness":
            self.completeness_score = score
        elif dimension_lower == "accuracy":
            self.accuracy_score = score
        elif dimension_lower == "consistency":
            self.consistency_score = score
        elif dimension_lower == "timeliness":
            self.timeliness_score = score
        elif dimension_lower == "validity":
            self.validity_score = score
        elif dimension_lower == "uniqueness":
            self.uniqueness_score = score
        else:
            raise ValidationError([f"Unknown quality dimension: {dimension}"], "quality_dimension")
        
        self.last_quality_check = Timestamp.now()


class Entity:
    """
    Entidade rica de domínio para Entity.
    
    Representa uma entidade de dados no sistema de governança.
    Contém comportamento rico e regras de negócio.
    """
    
    def __init__(
        self,
        id: EntityId,
        name: EntityName,
        type: EntityType,
        description: Description = Description(""),
        status: EntityStatus = EntityStatus(EntityStatus.ACTIVE),
        metadata: Optional[EntityMetadata] = None,
        quality_metrics: Optional[QualityMetrics] = None,
        created_at: Optional[Timestamp] = None,
        updated_at: Optional[Timestamp] = None
    ):
        self._id = id
        self._name = name
        self._type = type
        self._description = description
        self._status = status
        self._metadata = metadata or EntityMetadata()
        self._quality_metrics = quality_metrics or QualityMetrics()
        self._created_at = created_at or Timestamp.now()
        self._updated_at = updated_at or Timestamp.now()
        
        # Validações de negócio
        self._validate_business_rules()
    
    def _validate_business_rules(self) -> None:
        """Valida regras de negócio da entidade."""
        # Regra: Entidades de tipo TABLE devem ter schema_definition
        if (self._type.value == "TABLE" and 
            not self._metadata.schema_definition):
            raise BusinessRuleViolationError(
                "table_schema_required",
                "TABLE entities must have schema definition",
                {"entity_id": self._id.value, "entity_type": self._type.value}
            )
        
        # Regra: Entidades DEPRECATED devem ter retention_policy
        if (self._status.value == "DEPRECATED" and 
            not self._metadata.retention_policy):
            raise BusinessRuleViolationError(
                "deprecated_retention_policy_required",
                "DEPRECATED entities must have retention policy defined",
                {"entity_id": self._id.value, "status": self._status.value}
            )
    
    # Properties (getters) - Encapsulamento adequado
    @property
    def id(self) -> EntityId:
        return self._id
    
    @property
    def name(self) -> EntityName:
        return self._name
    
    @property
    def type(self) -> EntityType:
        return self._type
    
    @property
    def description(self) -> Description:
        return self._description
    
    @property
    def status(self) -> EntityStatus:
        return self._status
    
    @property
    def metadata(self) -> EntityMetadata:
        return self._metadata
    
    @property
    def quality_metrics(self) -> QualityMetrics:
        return self._quality_metrics
    
    @property
    def created_at(self) -> Timestamp:
        return self._created_at
    
    @property
    def updated_at(self) -> Timestamp:
        return self._updated_at
    
    # Comportamentos ricos (métodos de negócio)
    
    def update_name(self, new_name: EntityName) -> None:
        """
        Atualiza o nome da entidade.
        
        Args:
            new_name: Novo nome da entidade
            
        Raises:
            BusinessRuleViolationError: Se a entidade estiver arquivada
        """
        if self._status.value == "ARCHIVED":
            raise BusinessRuleViolationError(
                "archived_entity_immutable",
                "Cannot update archived entities",
                {"entity_id": self._id.value, "operation": "update_name"}
            )
        
        self._name = new_name
        self._updated_at = Timestamp.now()
    
    def update_description(self, new_description: Description) -> None:
        """
        Atualiza a descrição da entidade.
        
        Args:
            new_description: Nova descrição
        """
        if self._status.value == "ARCHIVED":
            raise BusinessRuleViolationError(
                "archived_entity_immutable",
                "Cannot update archived entities",
                {"entity_id": self._id.value, "operation": "update_description"}
            )
        
        self._description = new_description
        self._updated_at = Timestamp.now()
    
    def change_status(self, new_status: EntityStatus) -> None:
        """
        Altera o status da entidade com validações de negócio.
        
        Args:
            new_status: Novo status
            
        Raises:
            BusinessRuleViolationError: Se a transição não for válida
        """
        # Regras de transição de status
        current = self._status.value
        target = new_status.value
        
        # Não pode sair de ARCHIVED
        if current == "ARCHIVED":
            raise BusinessRuleViolationError(
                "archived_status_final",
                "Cannot change status from ARCHIVED",
                {"entity_id": self._id.value, "current_status": current, "target_status": target}
            )
        
        # Só pode ir para ARCHIVED se estiver DEPRECATED
        if target == "ARCHIVED" and current != "DEPRECATED":
            raise BusinessRuleViolationError(
                "archive_requires_deprecated",
                "Can only archive DEPRECATED entities",
                {"entity_id": self._id.value, "current_status": current}
            )
        
        self._status = new_status
        self._updated_at = Timestamp.now()
        
        # Re-valida regras de negócio após mudança de status
        self._validate_business_rules()
    
    def assign_owner(self, owner: Email) -> None:
        """
        Atribui um owner à entidade.
        
        Args:
            owner: Email do owner
        """
        self._metadata.owner = owner
        self._updated_at = Timestamp.now()
    
    def assign_steward(self, steward: Email) -> None:
        """
        Atribui um steward à entidade.
        
        Args:
            steward: Email do steward
        """
        self._metadata.steward = steward
        self._updated_at = Timestamp.now()
    
    def add_tag(self, tag: str) -> None:
        """
        Adiciona uma tag à entidade.
        
        Args:
            tag: Tag a ser adicionada
        """
        self._metadata.add_tag(tag)
        self._updated_at = Timestamp.now()
    
    def remove_tag(self, tag: str) -> None:
        """
        Remove uma tag da entidade.
        
        Args:
            tag: Tag a ser removida
        """
        self._metadata.remove_tag(tag)
        self._updated_at = Timestamp.now()
    
    def update_quality_score(self, dimension: str, score: float) -> None:
        """
        Atualiza um score de qualidade.
        
        Args:
            dimension: Dimensão da qualidade
            score: Novo score (0.0 a 1.0)
        """
        self._quality_metrics.update_score(dimension, score)
        self._updated_at = Timestamp.now()
    
    def set_schema_definition(self, schema: Dict[str, Any]) -> None:
        """
        Define o schema da entidade.
        
        Args:
            schema: Definição do schema
        """
        if not schema:
            raise ValidationError(["Schema definition cannot be empty"], "schema")
        
        self._metadata.schema_definition = schema
        self._updated_at = Timestamp.now()
    
    def set_retention_policy(self, policy: str) -> None:
        """
        Define a política de retenção.
        
        Args:
            policy: Política de retenção
        """
        if not policy or not isinstance(policy, str):
            raise ValidationError(["Retention policy must be a non-empty string"], "retention_policy")
        
        self._metadata.retention_policy = policy.strip()
        self._updated_at = Timestamp.now()
    
    # Métodos de consulta (queries)
    
    def is_active(self) -> bool:
        """Verifica se a entidade está ativa."""
        return self._status.is_active()
    
    def is_available_for_use(self) -> bool:
        """Verifica se a entidade está disponível para uso."""
        return self._status.is_available()
    
    def has_high_quality(self, threshold: float = 0.8) -> bool:
        """Verifica se tem alta qualidade."""
        return self._quality_metrics.is_high_quality(threshold)
    
    def has_owner(self) -> bool:
        """Verifica se tem owner definido."""
        return self._metadata.has_owner()
    
    def has_steward(self) -> bool:
        """Verifica se tem steward definido."""
        return self._metadata.has_steward()
    
    def has_governance(self) -> bool:
        """Verifica se tem governança adequada (owner ou steward)."""
        return self.has_owner() or self.has_steward()
    
    def can_be_deleted(self) -> bool:
        """
        Verifica se a entidade pode ser deletada.
        
        Returns:
            True se pode ser deletada, False caso contrário
        """
        # Só pode deletar se estiver INACTIVE ou DEPRECATED
        return self._status.value in ["INACTIVE", "DEPRECATED"]
    
    def can_be_archived(self) -> bool:
        """
        Verifica se a entidade pode ser arquivada.
        
        Returns:
            True se pode ser arquivada, False caso contrário
        """
        return self._status.value == "DEPRECATED"
    
    def get_age_in_days(self) -> int:
        """
        Calcula a idade da entidade em dias.
        
        Returns:
            Número de dias desde a criação
        """
        now = Timestamp.now()
        delta = now.value - self._created_at.value
        return delta.days
    
    def was_recently_updated(self, days: int = 7) -> bool:
        """
        Verifica se foi atualizada recentemente.
        
        Args:
            days: Número de dias para considerar "recente"
            
        Returns:
            True se foi atualizada nos últimos N dias
        """
        now = Timestamp.now()
        delta = now.value - self._updated_at.value
        return delta.days <= days
    
    # Métodos de comparação e igualdade
    
    def __eq__(self, other) -> bool:
        """Igualdade baseada no ID."""
        if not isinstance(other, Entity):
            return False
        return self._id == other._id
    
    def __hash__(self) -> int:
        """Hash baseado no ID."""
        return hash(self._id)
    
    def __str__(self) -> str:
        """Representação string da entidade."""
        return f"Entity(id={self._id.value}, name={self._name.value}, type={self._type.value})"
    
    def __repr__(self) -> str:
        """Representação detalhada da entidade."""
        return (
            f"Entity(id={self._id.value}, name={self._name.value}, "
            f"type={self._type.value}, status={self._status.value})"
        )
    
    # Factory methods
    
    @classmethod
    def create_new(
        cls,
        name: EntityName,
        type: EntityType,
        description: Description = Description(""),
        owner: Optional[Email] = None
    ) -> 'Entity':
        """
        Factory method para criar uma nova entidade.
        
        Args:
            name: Nome da entidade
            type: Tipo da entidade
            description: Descrição opcional
            owner: Owner opcional
            
        Returns:
            Nova instância de Entity
        """
        entity_id = EntityId.generate()
        metadata = EntityMetadata()
        
        if owner:
            metadata.owner = owner
        
        return cls(
            id=entity_id,
            name=name,
            type=type,
            description=description,
            metadata=metadata
        )
    
    @classmethod
    def create_table_entity(
        cls,
        name: EntityName,
        schema: Dict[str, Any],
        description: Optional[Description] = None,
        owner: Optional[Email] = None
    ) -> 'Entity':
        """
        Factory method para criar uma entidade do tipo TABLE.
        
        Args:
            name: Nome da tabela
            schema: Schema da tabela
            description: Descrição opcional
            owner: Owner opcional
            
        Returns:
            Nova instância de Entity do tipo TABLE
        """
        # Criar metadata com schema antes da criação da entidade
        metadata = EntityMetadata(
            owner=owner,
            schema_definition=schema
        )
        
        entity = cls(
            id=EntityId.generate(),
            name=name,
            type=EntityType("TABLE"),
            description=description or Description(""),
            metadata=metadata
        )
        
        return entity

