"""
TBR GDP Core v5.0 - PostgreSQL Entity Repository Implementation
Autor: Carlos Morais <carlos.morais@f1rst.com.br>

Implementação concreta do repositório de entidades para PostgreSQL.
Segue os princípios SOLID e implementa as interfaces de domínio.
"""

from typing import List, Optional, Dict, Any
from sqlalchemy import select, delete, update, func, and_, or_
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from ...domain.repositories import EntityRepositoryInterface, SearchCriteria, SearchResult
from ...domain.entities.entity import Entity
from ...domain.value_objects import EntityId, EntityName, EntityType, EntityStatus, Description, Email, Timestamp
from ...domain.exceptions import DatabaseError, EntityNotFoundError
from .models import EntityModel
from .mappers import EntityMapper


class PostgreSQLEntityRepository(EntityRepositoryInterface):
    """
    Implementação PostgreSQL do repositório de entidades.
    
    Implementa a interface de domínio sem vazar detalhes de infraestrutura
    para as camadas superiores.
    """
    
    def __init__(self, session: AsyncSession, mapper: EntityMapper):
        self._session = session
        self._mapper = mapper
    
    async def find_by_id(self, entity_id: EntityId) -> Optional[Entity]:
        """
        Busca uma entidade por ID.
        
        Args:
            entity_id: ID da entidade
            
        Returns:
            Entidade encontrada ou None se não existir
            
        Raises:
            DatabaseError: Se houver erro na consulta
        """
        try:
            # Query com eager loading dos relacionamentos
            stmt = (
                select(EntityModel)
                .where(EntityModel.id == entity_id.value)
                .options(selectinload(EntityModel.tags))
            )
            
            result = await self._session.execute(stmt)
            model = result.scalar_one_or_none()
            
            if model is None:
                return None
            
            # Mapear modelo para entidade de domínio
            entity = self._mapper.model_to_entity(model)
            return entity
            
        except Exception as e:
            raise DatabaseError("find_by_id", e)
    
    async def save(self, entity: Entity) -> Entity:
        """
        Salva uma entidade (create ou update).
        
        Args:
            entity: Entidade a ser salva
            
        Returns:
            Entidade salva com dados atualizados
            
        Raises:
            DatabaseError: Se houver erro na operação
        """
        try:
            # Verificar se é create ou update
            existing_model = await self._session.get(EntityModel, entity.id.value)
            
            if existing_model is None:
                # Create - nova entidade
                model = self._mapper.entity_to_model(entity)
                self._session.add(model)
            else:
                # Update - entidade existente
                self._mapper.update_model_from_entity(existing_model, entity)
            
            # Commit da transação
            await self._session.commit()
            
            # Refresh para obter dados atualizados
            if existing_model is None:
                await self._session.refresh(model)
                return self._mapper.model_to_entity(model)
            else:
                await self._session.refresh(existing_model)
                return self._mapper.model_to_entity(existing_model)
                
        except Exception as e:
            await self._session.rollback()
            raise DatabaseError("save", e)
    
    async def delete(self, entity_id: EntityId) -> None:
        """
        Remove uma entidade por ID.
        
        Args:
            entity_id: ID da entidade a ser removida
            
        Raises:
            EntityNotFoundError: Se a entidade não existir
            DatabaseError: Se houver erro na operação
        """
        try:
            # Verificar se existe
            existing = await self._session.get(EntityModel, entity_id.value)
            if existing is None:
                raise EntityNotFoundError("Entity", entity_id.value)
            
            # Deletar
            stmt = delete(EntityModel).where(EntityModel.id == entity_id.value)
            await self._session.execute(stmt)
            await self._session.commit()
            
        except EntityNotFoundError:
            raise
        except Exception as e:
            await self._session.rollback()
            raise DatabaseError("delete", e)
    
    async def exists(self, entity_id: EntityId) -> bool:
        """
        Verifica se uma entidade existe.
        
        Args:
            entity_id: ID da entidade
            
        Returns:
            True se a entidade existir, False caso contrário
            
        Raises:
            DatabaseError: Se houver erro na consulta
        """
        try:
            stmt = select(func.count(EntityModel.id)).where(EntityModel.id == entity_id.value)
            result = await self._session.execute(stmt)
            count = result.scalar()
            return count > 0
            
        except Exception as e:
            raise DatabaseError("exists", e)
    
    async def find_all(self, criteria: Optional[SearchCriteria] = None) -> SearchResult[Entity]:
        """
        Busca todas as entidades com critérios opcionais.
        
        Args:
            criteria: Critérios de busca opcionais
            
        Returns:
            Resultado da busca com paginação
            
        Raises:
            DatabaseError: Se houver erro na consulta
        """
        try:
            # Query base
            stmt = select(EntityModel).options(selectinload(EntityModel.tags))
            count_stmt = select(func.count(EntityModel.id))
            
            # Aplicar filtros se fornecidos
            if criteria and criteria.filters:
                where_conditions = self._build_where_conditions(criteria.filters)
                if where_conditions:
                    stmt = stmt.where(and_(*where_conditions))
                    count_stmt = count_stmt.where(and_(*where_conditions))
            
            # Aplicar ordenação
            if criteria and criteria.sort_by:
                sort_column = getattr(EntityModel, criteria.sort_by, None)
                if sort_column is not None:
                    if criteria.sort_order == 'desc':
                        stmt = stmt.order_by(sort_column.desc())
                    else:
                        stmt = stmt.order_by(sort_column.asc())
            else:
                # Ordenação padrão por data de criação
                stmt = stmt.order_by(EntityModel.created_at.desc())
            
            # Aplicar paginação
            if criteria:
                if criteria.limit:
                    stmt = stmt.limit(criteria.limit)
                if criteria.offset:
                    stmt = stmt.offset(criteria.offset)
            
            # Executar queries
            result = await self._session.execute(stmt)
            models = result.scalars().all()
            
            count_result = await self._session.execute(count_stmt)
            total_count = count_result.scalar()
            
            # Mapear para entidades de domínio
            entities = [self._mapper.model_to_entity(model) for model in models]
            
            return SearchResult(
                items=entities,
                total_count=total_count,
                offset=criteria.offset if criteria else 0,
                limit=criteria.limit if criteria else None
            )
            
        except Exception as e:
            raise DatabaseError("find_all", e)
    
    async def count(self, filters: Optional[Dict[str, Any]] = None) -> int:
        """
        Conta o número de entidades que atendem aos filtros.
        
        Args:
            filters: Filtros opcionais
            
        Returns:
            Número de entidades
            
        Raises:
            DatabaseError: Se houver erro na consulta
        """
        try:
            stmt = select(func.count(EntityModel.id))
            
            if filters:
                where_conditions = self._build_where_conditions(filters)
                if where_conditions:
                    stmt = stmt.where(and_(*where_conditions))
            
            result = await self._session.execute(stmt)
            return result.scalar()
            
        except Exception as e:
            raise DatabaseError("count", e)
    
    async def find_by_name(self, name: str) -> Optional[Entity]:
        """
        Busca uma entidade por nome.
        
        Args:
            name: Nome da entidade
            
        Returns:
            Entidade encontrada ou None
            
        Raises:
            DatabaseError: Se houver erro na consulta
        """
        try:
            stmt = (
                select(EntityModel)
                .where(EntityModel.name == name)
                .options(selectinload(EntityModel.tags))
            )
            
            result = await self._session.execute(stmt)
            model = result.scalar_one_or_none()
            
            if model is None:
                return None
            
            return self._mapper.model_to_entity(model)
            
        except Exception as e:
            raise DatabaseError("find_by_name", e)
    
    async def find_by_type(self, entity_type: str) -> List[Entity]:
        """
        Busca entidades por tipo.
        
        Args:
            entity_type: Tipo da entidade
            
        Returns:
            Lista de entidades do tipo especificado
            
        Raises:
            DatabaseError: Se houver erro na consulta
        """
        try:
            stmt = (
                select(EntityModel)
                .where(EntityModel.type == entity_type)
                .options(selectinload(EntityModel.tags))
                .order_by(EntityModel.name.asc())
            )
            
            result = await self._session.execute(stmt)
            models = result.scalars().all()
            
            return [self._mapper.model_to_entity(model) for model in models]
            
        except Exception as e:
            raise DatabaseError("find_by_type", e)
    
    async def find_by_status(self, status: str) -> List[Entity]:
        """
        Busca entidades por status.
        
        Args:
            status: Status da entidade
            
        Returns:
            Lista de entidades com o status especificado
            
        Raises:
            DatabaseError: Se houver erro na consulta
        """
        try:
            stmt = (
                select(EntityModel)
                .where(EntityModel.status == status)
                .options(selectinload(EntityModel.tags))
                .order_by(EntityModel.name.asc())
            )
            
            result = await self._session.execute(stmt)
            models = result.scalars().all()
            
            return [self._mapper.model_to_entity(model) for model in models]
            
        except Exception as e:
            raise DatabaseError("find_by_status", e)
    
    async def find_active_entities(self) -> List[Entity]:
        """
        Busca todas as entidades ativas.
        
        Returns:
            Lista de entidades ativas
            
        Raises:
            DatabaseError: Se houver erro na consulta
        """
        return await self.find_by_status("ACTIVE")
    
    def _build_where_conditions(self, filters: Dict[str, Any]) -> List:
        """
        Constrói condições WHERE baseadas nos filtros.
        
        Args:
            filters: Dicionário de filtros
            
        Returns:
            Lista de condições WHERE
        """
        conditions = []
        
        # Filtro por nome (busca parcial)
        if "name" in filters and filters["name"]:
            conditions.append(EntityModel.name.ilike(f"%{filters['name']}%"))
        
        # Filtro por tipo
        if "type" in filters and filters["type"]:
            conditions.append(EntityModel.type == filters["type"])
        
        # Filtro por status
        if "status" in filters and filters["status"]:
            conditions.append(EntityModel.status == filters["status"])
        
        # Filtro por owner
        if "owner" in filters and filters["owner"]:
            conditions.append(EntityModel.owner.ilike(f"%{filters['owner']}%"))
        
        # Filtro por steward
        if "steward" in filters and filters["steward"]:
            conditions.append(EntityModel.steward.ilike(f"%{filters['steward']}%"))
        
        # Filtro por existência de owner
        if "has_owner" in filters:
            if filters["has_owner"]:
                conditions.append(EntityModel.owner.is_not(None))
            else:
                conditions.append(EntityModel.owner.is_(None))
        
        # Filtro por existência de steward
        if "has_steward" in filters:
            if filters["has_steward"]:
                conditions.append(EntityModel.steward.is_not(None))
            else:
                conditions.append(EntityModel.steward.is_(None))
        
        # Filtro por score mínimo de qualidade
        if "min_quality_score" in filters and filters["min_quality_score"] is not None:
            min_score = filters["min_quality_score"]
            # Calcula score geral como média dos scores individuais
            avg_score = (
                EntityModel.completeness_score +
                EntityModel.accuracy_score +
                EntityModel.consistency_score +
                EntityModel.timeliness_score +
                EntityModel.validity_score +
                EntityModel.uniqueness_score
            ) / 6
            conditions.append(avg_score >= min_score)
        
        # Filtro por tags (implementação simplificada)
        if "tags" in filters and filters["tags"]:
            # Para PostgreSQL com array de tags, usaria operadores específicos
            # Aqui implementação simplificada assumindo tags como string JSON
            for tag in filters["tags"]:
                conditions.append(EntityModel.tags_json.contains(f'"{tag}"'))
        
        return conditions


class EntityMapper:
    """
    Mapper entre entidades de domínio e modelos de persistência.
    
    Isola as camadas de domínio e infraestrutura, permitindo que
    mudanças em uma não afetem a outra.
    """
    
    def model_to_entity(self, model: EntityModel) -> Entity:
        """
        Converte modelo de persistência para entidade de domínio.
        
        Args:
            model: Modelo de persistência
            
        Returns:
            Entidade de domínio
        """
        # Criar value objects
        entity_id = EntityId(model.id)
        name = EntityName(model.name)
        entity_type = EntityType(model.type)
        status = EntityStatus(model.status)
        description = Description(model.description or "")
        
        # Criar timestamps
        created_at = Timestamp(model.created_at)
        updated_at = Timestamp(model.updated_at)
        
        # Criar metadata
        from ...domain.entities.entity import EntityMetadata, QualityMetrics
        
        metadata = EntityMetadata(
            owner=Email(model.owner) if model.owner else None,
            steward=Email(model.steward) if model.steward else None,
            tags=model.tags or [],
            properties=model.properties or {},
            schema_definition=model.schema_definition,
            data_source=model.data_source,
            update_frequency=model.update_frequency,
            retention_policy=model.retention_policy
        )
        
        # Criar métricas de qualidade
        quality_metrics = QualityMetrics(
            completeness_score=model.completeness_score or 0.0,
            accuracy_score=model.accuracy_score or 0.0,
            consistency_score=model.consistency_score or 0.0,
            timeliness_score=model.timeliness_score or 0.0,
            validity_score=model.validity_score or 0.0,
            uniqueness_score=model.uniqueness_score or 0.0,
            last_quality_check=Timestamp(model.last_quality_check) if model.last_quality_check else None
        )
        
        # Criar entidade
        entity = Entity(
            id=entity_id,
            name=name,
            type=entity_type,
            description=description,
            status=status,
            metadata=metadata,
            quality_metrics=quality_metrics,
            created_at=created_at,
            updated_at=updated_at
        )
        
        return entity
    
    def entity_to_model(self, entity: Entity) -> EntityModel:
        """
        Converte entidade de domínio para modelo de persistência.
        
        Args:
            entity: Entidade de domínio
            
        Returns:
            Modelo de persistência
        """
        model = EntityModel(
            id=entity.id.value,
            name=entity.name.value,
            type=entity.type.value,
            description=entity.description.value,
            status=entity.status.value,
            owner=entity.metadata.owner.value if entity.metadata.owner else None,
            steward=entity.metadata.steward.value if entity.metadata.steward else None,
            tags=entity.metadata.tags,
            properties=entity.metadata.properties,
            schema_definition=entity.metadata.schema_definition,
            data_source=entity.metadata.data_source,
            update_frequency=entity.metadata.update_frequency,
            retention_policy=entity.metadata.retention_policy,
            completeness_score=entity.quality_metrics.completeness_score,
            accuracy_score=entity.quality_metrics.accuracy_score,
            consistency_score=entity.quality_metrics.consistency_score,
            timeliness_score=entity.quality_metrics.timeliness_score,
            validity_score=entity.quality_metrics.validity_score,
            uniqueness_score=entity.quality_metrics.uniqueness_score,
            last_quality_check=entity.quality_metrics.last_quality_check.value if entity.quality_metrics.last_quality_check else None,
            created_at=entity.created_at.value,
            updated_at=entity.updated_at.value
        )
        
        return model
    
    def update_model_from_entity(self, model: EntityModel, entity: Entity) -> None:
        """
        Atualiza modelo existente com dados da entidade.
        
        Args:
            model: Modelo a ser atualizado
            entity: Entidade com dados atualizados
        """
        model.name = entity.name.value
        model.type = entity.type.value
        model.description = entity.description.value
        model.status = entity.status.value
        model.owner = entity.metadata.owner.value if entity.metadata.owner else None
        model.steward = entity.metadata.steward.value if entity.metadata.steward else None
        model.tags = entity.metadata.tags
        model.properties = entity.metadata.properties
        model.schema_definition = entity.metadata.schema_definition
        model.data_source = entity.metadata.data_source
        model.update_frequency = entity.metadata.update_frequency
        model.retention_policy = entity.metadata.retention_policy
        model.completeness_score = entity.quality_metrics.completeness_score
        model.accuracy_score = entity.quality_metrics.accuracy_score
        model.consistency_score = entity.quality_metrics.consistency_score
        model.timeliness_score = entity.quality_metrics.timeliness_score
        model.validity_score = entity.quality_metrics.validity_score
        model.uniqueness_score = entity.quality_metrics.uniqueness_score
        model.last_quality_check = entity.quality_metrics.last_quality_check.value if entity.quality_metrics.last_quality_check else None
        model.updated_at = entity.updated_at.value

