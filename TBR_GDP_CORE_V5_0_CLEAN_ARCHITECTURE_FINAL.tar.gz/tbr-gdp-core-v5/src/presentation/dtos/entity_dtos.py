"""
TBR GDP Core v5.0 - Entity DTOs
Autor: Carlos Morais <carlos.morais@f1rst.com.br>

Data Transfer Objects para o domínio de Entity.
Responsáveis pela serialização/deserialização entre API e domínio.
"""

from typing import Optional, List, Dict, Any
from datetime import datetime
from pydantic import BaseModel, Field, validator
from enum import Enum

from ...domain.value_objects import EntityId, EntityType, EntityStatus


class EntityTypeDTO(str, Enum):
    """Tipos de entidade disponíveis."""
    TABLE = "TABLE"
    VIEW = "VIEW" 
    DATASET = "DATASET"
    REPORT = "REPORT"
    DASHBOARD = "DASHBOARD"
    API = "API"
    FILE = "FILE"


class EntityStatusDTO(str, Enum):
    """Status possíveis da entidade."""
    DRAFT = "DRAFT"
    ACTIVE = "ACTIVE"
    DEPRECATED = "DEPRECATED"
    ARCHIVED = "ARCHIVED"


class QualityMetricsDTO(BaseModel):
    """DTO para métricas de qualidade."""
    
    completeness_score: float = Field(
        ..., 
        ge=0.0, 
        le=1.0, 
        description="Score de completude (0-1)"
    )
    accuracy_score: float = Field(
        ..., 
        ge=0.0, 
        le=1.0, 
        description="Score de precisão (0-1)"
    )
    consistency_score: float = Field(
        ..., 
        ge=0.0, 
        le=1.0, 
        description="Score de consistência (0-1)"
    )
    validity_score: float = Field(
        ..., 
        ge=0.0, 
        le=1.0, 
        description="Score de validade (0-1)"
    )
    timeliness_score: float = Field(
        ..., 
        ge=0.0, 
        le=1.0, 
        description="Score de pontualidade (0-1)"
    )
    uniqueness_score: float = Field(
        ..., 
        ge=0.0, 
        le=1.0, 
        description="Score de unicidade (0-1)"
    )
    
    @property
    def overall_score(self) -> float:
        """Calcula score geral de qualidade."""
        scores = [
            self.completeness_score,
            self.accuracy_score,
            self.consistency_score,
            self.validity_score,
            self.timeliness_score,
            self.uniqueness_score
        ]
        return sum(scores) / len(scores)


class EntityMetadataDTO(BaseModel):
    """DTO para metadados da entidade."""
    
    tags: List[str] = Field(
        default_factory=list,
        description="Tags para categorização"
    )
    properties: Dict[str, Any] = Field(
        default_factory=dict,
        description="Propriedades customizadas"
    )
    
    @validator('tags')
    def validate_tags(cls, v):
        """Valida tags."""
        if not isinstance(v, list):
            raise ValueError("Tags must be a list")
        
        # Normalizar tags
        normalized_tags = []
        for tag in v:
            if not isinstance(tag, str):
                raise ValueError("All tags must be strings")
            normalized_tag = tag.strip().lower()
            if normalized_tag and normalized_tag not in normalized_tags:
                normalized_tags.append(normalized_tag)
        
        return normalized_tags


class CreateEntityRequestDTO(BaseModel):
    """DTO para criação de entidade."""
    
    name: str = Field(
        ..., 
        min_length=1, 
        max_length=255,
        description="Nome da entidade"
    )
    entity_type: EntityTypeDTO = Field(
        ...,
        description="Tipo da entidade"
    )
    description: Optional[str] = Field(
        None,
        max_length=2000,
        description="Descrição da entidade"
    )
    schema_definition: Optional[Dict[str, Any]] = Field(
        None,
        description="Definição do schema (obrigatório para TABLE)"
    )
    data_owner: Optional[str] = Field(
        None,
        max_length=255,
        description="Proprietário dos dados"
    )
    data_steward: Optional[str] = Field(
        None,
        max_length=255,
        description="Steward dos dados"
    )
    metadata: Optional[EntityMetadataDTO] = Field(
        None,
        description="Metadados adicionais"
    )
    
    @validator('schema_definition')
    def validate_schema_for_table(cls, v, values):
        """Valida schema para entidades TABLE."""
        if values.get('entity_type') == EntityTypeDTO.TABLE and not v:
            raise ValueError("TABLE entities must have schema_definition")
        return v


class UpdateEntityRequestDTO(BaseModel):
    """DTO para atualização de entidade."""
    
    name: Optional[str] = Field(
        None,
        min_length=1,
        max_length=255,
        description="Nome da entidade"
    )
    description: Optional[str] = Field(
        None,
        max_length=2000,
        description="Descrição da entidade"
    )
    schema_definition: Optional[Dict[str, Any]] = Field(
        None,
        description="Definição do schema"
    )
    data_owner: Optional[str] = Field(
        None,
        max_length=255,
        description="Proprietário dos dados"
    )
    data_steward: Optional[str] = Field(
        None,
        max_length=255,
        description="Steward dos dados"
    )
    metadata: Optional[EntityMetadataDTO] = Field(
        None,
        description="Metadados adicionais"
    )


class ChangeEntityStatusRequestDTO(BaseModel):
    """DTO para mudança de status da entidade."""
    
    new_status: EntityStatusDTO = Field(
        ...,
        description="Novo status da entidade"
    )
    reason: Optional[str] = Field(
        None,
        max_length=500,
        description="Motivo da mudança de status"
    )
    retention_policy: Optional[str] = Field(
        None,
        max_length=255,
        description="Política de retenção (obrigatório para DEPRECATED)"
    )
    
    @validator('retention_policy')
    def validate_retention_for_deprecated(cls, v, values):
        """Valida política de retenção para status DEPRECATED."""
        if values.get('new_status') == EntityStatusDTO.DEPRECATED and not v:
            raise ValueError("Retention policy is required when deprecating entity")
        return v


class EntityResponseDTO(BaseModel):
    """DTO para resposta com dados da entidade."""
    
    id: str = Field(..., description="ID único da entidade")
    name: str = Field(..., description="Nome da entidade")
    entity_type: EntityTypeDTO = Field(..., description="Tipo da entidade")
    status: EntityStatusDTO = Field(..., description="Status atual")
    description: Optional[str] = Field(None, description="Descrição")
    schema_definition: Optional[Dict[str, Any]] = Field(None, description="Schema")
    data_owner: Optional[str] = Field(None, description="Proprietário")
    data_steward: Optional[str] = Field(None, description="Steward")
    metadata: EntityMetadataDTO = Field(..., description="Metadados")
    quality_metrics: Optional[QualityMetricsDTO] = Field(None, description="Métricas de qualidade")
    created_at: datetime = Field(..., description="Data de criação")
    updated_at: datetime = Field(..., description="Data de atualização")
    
    class Config:
        """Configuração do Pydantic."""
        from_attributes = True
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }


class EntityListResponseDTO(BaseModel):
    """DTO para lista de entidades."""
    
    entities: List[EntityResponseDTO] = Field(
        ...,
        description="Lista de entidades"
    )
    total: int = Field(
        ...,
        ge=0,
        description="Total de entidades"
    )
    page: int = Field(
        ...,
        ge=1,
        description="Página atual"
    )
    page_size: int = Field(
        ...,
        ge=1,
        le=100,
        description="Tamanho da página"
    )
    
    @property
    def total_pages(self) -> int:
        """Calcula total de páginas."""
        return (self.total + self.page_size - 1) // self.page_size


class SearchEntitiesRequestDTO(BaseModel):
    """DTO para busca de entidades."""
    
    query: Optional[str] = Field(
        None,
        max_length=255,
        description="Termo de busca"
    )
    entity_type: Optional[EntityTypeDTO] = Field(
        None,
        description="Filtrar por tipo"
    )
    status: Optional[EntityStatusDTO] = Field(
        None,
        description="Filtrar por status"
    )
    data_owner: Optional[str] = Field(
        None,
        max_length=255,
        description="Filtrar por proprietário"
    )
    tags: Optional[List[str]] = Field(
        None,
        description="Filtrar por tags"
    )
    page: int = Field(
        1,
        ge=1,
        description="Página (inicia em 1)"
    )
    page_size: int = Field(
        20,
        ge=1,
        le=100,
        description="Tamanho da página"
    )
    
    @validator('tags')
    def validate_search_tags(cls, v):
        """Valida tags de busca."""
        if v is not None:
            if not isinstance(v, list):
                raise ValueError("Tags must be a list")
            return [tag.strip().lower() for tag in v if tag.strip()]
        return v


class ErrorResponseDTO(BaseModel):
    """DTO para respostas de erro."""
    
    error: Dict[str, Any] = Field(
        ...,
        description="Detalhes do erro"
    )
    request_id: Optional[str] = Field(
        None,
        description="ID da requisição"
    )

