"""
TBR GDP Core v5.0 - Entity Controller
Autor: Carlos Morais <carlos.morais@f1rst.com.br>

Controller FastAPI para gerenciamento de entidades.
Implementa endpoints REST seguindo padrões de Clean Architecture.
"""

from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, Path, status
from fastapi.responses import JSONResponse

from ..dtos.entity_dtos import (
    CreateEntityRequestDTO, UpdateEntityRequestDTO, ChangeEntityStatusRequestDTO,
    EntityResponseDTO, EntityListResponseDTO, SearchEntitiesRequestDTO,
    ErrorResponseDTO
)
from ..mappers.entity_mappers import EntityMapper, EntityValidationMapper
from ...domain.use_cases.entity_use_cases import (
    CreateEntityUseCase, UpdateEntityUseCase, ChangeEntityStatusUseCase,
    DeleteEntityUseCase, GetEntityByIdUseCase, SearchEntitiesUseCase
)
from ...domain.exceptions import (
    ValidationError, EntityNotFoundError, EntityAlreadyExistsError,
    BusinessRuleViolationError
)
from ...shared.di_container import DIContainer
from ...shared.logging import get_logger, LogCategory, LogContext
from ...shared.error_handling import handle_error


# Configurar router
router = APIRouter(
    prefix="/api/v1/entities",
    tags=["entities"],
    responses={
        400: {"model": ErrorResponseDTO, "description": "Validation Error"},
        404: {"model": ErrorResponseDTO, "description": "Entity Not Found"},
        409: {"model": ErrorResponseDTO, "description": "Entity Already Exists"},
        422: {"model": ErrorResponseDTO, "description": "Business Rule Violation"},
        500: {"model": ErrorResponseDTO, "description": "Internal Server Error"}
    }
)

# Logger
logger = get_logger(__name__)


def get_use_cases():
    """Dependency injection para use cases."""
    container = DIContainer.get_instance()
    return {
        'create': container.get(CreateEntityUseCase),
        'update': container.get(UpdateEntityUseCase),
        'change_status': container.get(ChangeEntityStatusUseCase),
        'delete': container.get(DeleteEntityUseCase),
        'get_by_id': container.get(GetEntityByIdUseCase),
        'search': container.get(SearchEntitiesUseCase)
    }


@router.post(
    "/",
    response_model=EntityResponseDTO,
    status_code=status.HTTP_201_CREATED,
    summary="Create Entity",
    description="Creates a new entity with the provided data"
)
async def create_entity(
    request: CreateEntityRequestDTO,
    use_cases: dict = Depends(get_use_cases)
) -> EntityResponseDTO:
    """
    Cria uma nova entidade.
    
    Args:
        request: Dados da entidade a ser criada
        use_cases: Use cases injetados
        
    Returns:
        Dados da entidade criada
        
    Raises:
        HTTPException: Em caso de erro de validação ou regra de negócio
    """
    context = LogContext(operation="create_entity")
    logger.info(
        f"Creating entity: {request.name} ({request.entity_type})",
        category=LogCategory.DOMAIN,
        context=context
    )
    
    try:
        # Validações de entrada
        validation_errors = EntityValidationMapper.validate_create_request(request)
        if validation_errors:
            raise ValidationError(validation_errors)
        
        # Converter para comando de domínio
        command = EntityMapper.create_command_from_dto(request)
        
        # Executar use case
        entity = await use_cases['create'].execute(command)
        
        # Converter para DTO de resposta
        response = EntityMapper.entity_to_response_dto(entity)
        
        logger.info(
            f"Entity created successfully: {entity.id}",
            category=LogCategory.DOMAIN,
            context=context,
            entity_id=str(entity.id),
            entity_type=entity.entity_type.value
        )
        
        return response
        
    except Exception as error:
        logger.error(
            f"Failed to create entity: {request.name}",
            category=LogCategory.DOMAIN,
            context=context,
            exception=error
        )
        
        # Converter exceção para resposta HTTP
        error_response = handle_error(error)
        raise HTTPException(
            status_code=error_response.status_code,
            detail=error_response.to_dict()
        )


@router.get(
    "/{entity_id}",
    response_model=EntityResponseDTO,
    summary="Get Entity by ID",
    description="Retrieves an entity by its unique identifier"
)
async def get_entity(
    entity_id: str = Path(..., description="Unique identifier of the entity"),
    use_cases: dict = Depends(get_use_cases)
) -> EntityResponseDTO:
    """
    Obtém uma entidade pelo ID.
    
    Args:
        entity_id: ID único da entidade
        use_cases: Use cases injetados
        
    Returns:
        Dados da entidade encontrada
        
    Raises:
        HTTPException: Se entidade não for encontrada
    """
    context = LogContext(operation="get_entity", entity_id=entity_id)
    logger.info(
        f"Retrieving entity: {entity_id}",
        category=LogCategory.DOMAIN,
        context=context
    )
    
    try:
        # Executar use case
        entity = await use_cases['get_by_id'].execute(entity_id)
        
        # Converter para DTO de resposta
        response = EntityMapper.entity_to_response_dto(entity)
        
        logger.info(
            f"Entity retrieved successfully: {entity_id}",
            category=LogCategory.DOMAIN,
            context=context
        )
        
        return response
        
    except Exception as error:
        logger.error(
            f"Failed to retrieve entity: {entity_id}",
            category=LogCategory.DOMAIN,
            context=context,
            exception=error
        )
        
        error_response = handle_error(error)
        raise HTTPException(
            status_code=error_response.status_code,
            detail=error_response.to_dict()
        )


@router.put(
    "/{entity_id}",
    response_model=EntityResponseDTO,
    summary="Update Entity",
    description="Updates an existing entity with the provided data"
)
async def update_entity(
    entity_id: str = Path(..., description="Unique identifier of the entity"),
    request: UpdateEntityRequestDTO = ...,
    use_cases: dict = Depends(get_use_cases)
) -> EntityResponseDTO:
    """
    Atualiza uma entidade existente.
    
    Args:
        entity_id: ID único da entidade
        request: Dados para atualização
        use_cases: Use cases injetados
        
    Returns:
        Dados da entidade atualizada
        
    Raises:
        HTTPException: Em caso de erro de validação ou entidade não encontrada
    """
    context = LogContext(operation="update_entity", entity_id=entity_id)
    logger.info(
        f"Updating entity: {entity_id}",
        category=LogCategory.DOMAIN,
        context=context
    )
    
    try:
        # Validações de entrada
        validation_errors = EntityValidationMapper.validate_update_request(request)
        if validation_errors:
            raise ValidationError(validation_errors)
        
        # Converter para comando de domínio
        command = EntityMapper.update_command_from_dto(entity_id, request)
        
        # Executar use case
        entity = await use_cases['update'].execute(command)
        
        # Converter para DTO de resposta
        response = EntityMapper.entity_to_response_dto(entity)
        
        logger.info(
            f"Entity updated successfully: {entity_id}",
            category=LogCategory.DOMAIN,
            context=context
        )
        
        return response
        
    except Exception as error:
        logger.error(
            f"Failed to update entity: {entity_id}",
            category=LogCategory.DOMAIN,
            context=context,
            exception=error
        )
        
        error_response = handle_error(error)
        raise HTTPException(
            status_code=error_response.status_code,
            detail=error_response.to_dict()
        )


@router.patch(
    "/{entity_id}/status",
    response_model=EntityResponseDTO,
    summary="Change Entity Status",
    description="Changes the status of an entity (e.g., activate, deprecate, archive)"
)
async def change_entity_status(
    entity_id: str = Path(..., description="Unique identifier of the entity"),
    request: ChangeEntityStatusRequestDTO = ...,
    use_cases: dict = Depends(get_use_cases)
) -> EntityResponseDTO:
    """
    Altera o status de uma entidade.
    
    Args:
        entity_id: ID único da entidade
        request: Dados da mudança de status
        use_cases: Use cases injetados
        
    Returns:
        Dados da entidade com status atualizado
        
    Raises:
        HTTPException: Em caso de erro de validação ou regra de negócio
    """
    context = LogContext(operation="change_entity_status", entity_id=entity_id)
    logger.info(
        f"Changing entity status: {entity_id} -> {request.new_status}",
        category=LogCategory.DOMAIN,
        context=context
    )
    
    try:
        # Validações de entrada
        validation_errors = EntityValidationMapper.validate_status_change_request(request)
        if validation_errors:
            raise ValidationError(validation_errors)
        
        # Converter para comando de domínio
        command = EntityMapper.change_status_command_from_dto(entity_id, request)
        
        # Executar use case
        entity = await use_cases['change_status'].execute(command)
        
        # Converter para DTO de resposta
        response = EntityMapper.entity_to_response_dto(entity)
        
        logger.info(
            f"Entity status changed successfully: {entity_id} -> {request.new_status}",
            category=LogCategory.DOMAIN,
            context=context
        )
        
        return response
        
    except Exception as error:
        logger.error(
            f"Failed to change entity status: {entity_id}",
            category=LogCategory.DOMAIN,
            context=context,
            exception=error
        )
        
        error_response = handle_error(error)
        raise HTTPException(
            status_code=error_response.status_code,
            detail=error_response.to_dict()
        )


@router.delete(
    "/{entity_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete Entity",
    description="Deletes an entity (only if not referenced by other entities)"
)
async def delete_entity(
    entity_id: str = Path(..., description="Unique identifier of the entity"),
    use_cases: dict = Depends(get_use_cases)
) -> None:
    """
    Deleta uma entidade.
    
    Args:
        entity_id: ID único da entidade
        use_cases: Use cases injetados
        
    Raises:
        HTTPException: Se entidade não puder ser deletada
    """
    context = LogContext(operation="delete_entity", entity_id=entity_id)
    logger.info(
        f"Deleting entity: {entity_id}",
        category=LogCategory.DOMAIN,
        context=context
    )
    
    try:
        # Executar use case
        await use_cases['delete'].execute(entity_id)
        
        logger.info(
            f"Entity deleted successfully: {entity_id}",
            category=LogCategory.DOMAIN,
            context=context
        )
        
    except Exception as error:
        logger.error(
            f"Failed to delete entity: {entity_id}",
            category=LogCategory.DOMAIN,
            context=context,
            exception=error
        )
        
        error_response = handle_error(error)
        raise HTTPException(
            status_code=error_response.status_code,
            detail=error_response.to_dict()
        )


@router.get(
    "/",
    response_model=EntityListResponseDTO,
    summary="Search Entities",
    description="Searches entities with optional filters and pagination"
)
async def search_entities(
    query: Optional[str] = Query(None, description="Search term"),
    entity_type: Optional[str] = Query(None, description="Filter by entity type"),
    status: Optional[str] = Query(None, description="Filter by status"),
    data_owner: Optional[str] = Query(None, description="Filter by data owner"),
    tags: Optional[List[str]] = Query(None, description="Filter by tags"),
    page: int = Query(1, ge=1, description="Page number (starts at 1)"),
    page_size: int = Query(20, ge=1, le=100, description="Page size (1-100)"),
    use_cases: dict = Depends(get_use_cases)
) -> EntityListResponseDTO:
    """
    Busca entidades com filtros opcionais.
    
    Args:
        query: Termo de busca
        entity_type: Filtro por tipo
        status: Filtro por status
        data_owner: Filtro por proprietário
        tags: Filtro por tags
        page: Número da página
        page_size: Tamanho da página
        use_cases: Use cases injetados
        
    Returns:
        Lista paginada de entidades
        
    Raises:
        HTTPException: Em caso de erro na busca
    """
    context = LogContext(operation="search_entities")
    logger.info(
        f"Searching entities: query='{query}', type={entity_type}, page={page}",
        category=LogCategory.DOMAIN,
        context=context
    )
    
    try:
        # Criar DTO de busca
        search_dto = SearchEntitiesRequestDTO(
            query=query,
            entity_type=entity_type,
            status=status,
            data_owner=data_owner,
            tags=tags,
            page=page,
            page_size=page_size
        )
        
        # Converter para query de domínio
        search_query = EntityMapper.search_query_from_dto(search_dto)
        
        # Executar use case
        result = await use_cases['search'].execute(search_query)
        
        # Converter para DTO de resposta
        response = EntityMapper.entities_to_list_response_dto(
            result.entities,
            result.total,
            result.page,
            result.page_size
        )
        
        logger.info(
            f"Entities search completed: {len(result.entities)} found, total={result.total}",
            category=LogCategory.DOMAIN,
            context=context
        )
        
        return response
        
    except Exception as error:
        logger.error(
            f"Failed to search entities",
            category=LogCategory.DOMAIN,
            context=context,
            exception=error
        )
        
        error_response = handle_error(error)
        raise HTTPException(
            status_code=error_response.status_code,
            detail=error_response.to_dict()
        )

