"""
TBR GDP Core v5.0 - Entity Mappers
Autor: Carlos Morais <carlos.morais@f1rst.com.br>

Mappers para conversão entre DTOs e objetos de domínio.
Implementa o padrão Mapper para separar camadas.
"""

from typing import Optional, List
from datetime import datetime

from ..dtos.entity_dtos import (
    CreateEntityRequestDTO, UpdateEntityRequestDTO, ChangeEntityStatusRequestDTO,
    EntityResponseDTO, EntityListResponseDTO, SearchEntitiesRequestDTO,
    QualityMetricsDTO, EntityMetadataDTO, EntityTypeDTO, EntityStatusDTO
)
from ...domain.entities.entity import Entity
from ...domain.value_objects import (
    EntityId, EntityType, EntityStatus, QualityScore,
    EntityMetadata, QualityMetrics
)
from ...domain.use_cases.entity_use_cases import (
    CreateEntityCommand, UpdateEntityCommand, ChangeEntityStatusCommand,
    SearchEntitiesQuery
)


class EntityMapper:
    """
    Mapper para conversões entre DTOs e objetos de domínio.
    
    Responsável por traduzir entre a camada de apresentação
    e a camada de domínio, mantendo as responsabilidades separadas.
    """
    
    @staticmethod
    def create_command_from_dto(dto: CreateEntityRequestDTO) -> CreateEntityCommand:
        """Converte DTO de criação para comando de domínio."""
        return CreateEntityCommand(
            name=dto.name,
            entity_type=EntityType(dto.entity_type.value),
            description=dto.description,
            schema_definition=dto.schema_definition,
            data_owner=dto.data_owner,
            data_steward=dto.data_steward,
            metadata=EntityMapper._metadata_from_dto(dto.metadata) if dto.metadata else None
        )
    
    @staticmethod
    def update_command_from_dto(
        entity_id: str, 
        dto: UpdateEntityRequestDTO
    ) -> UpdateEntityCommand:
        """Converte DTO de atualização para comando de domínio."""
        return UpdateEntityCommand(
            entity_id=EntityId(entity_id),
            name=dto.name,
            description=dto.description,
            schema_definition=dto.schema_definition,
            data_owner=dto.data_owner,
            data_steward=dto.data_steward,
            metadata=EntityMapper._metadata_from_dto(dto.metadata) if dto.metadata else None
        )
    
    @staticmethod
    def change_status_command_from_dto(
        entity_id: str,
        dto: ChangeEntityStatusRequestDTO
    ) -> ChangeEntityStatusCommand:
        """Converte DTO de mudança de status para comando de domínio."""
        return ChangeEntityStatusCommand(
            entity_id=EntityId(entity_id),
            new_status=EntityStatus(dto.new_status.value),
            reason=dto.reason,
            retention_policy=dto.retention_policy
        )
    
    @staticmethod
    def search_query_from_dto(dto: SearchEntitiesRequestDTO) -> SearchEntitiesQuery:
        """Converte DTO de busca para query de domínio."""
        return SearchEntitiesQuery(
            query=dto.query,
            entity_type=EntityType(dto.entity_type.value) if dto.entity_type else None,
            status=EntityStatus(dto.status.value) if dto.status else None,
            data_owner=dto.data_owner,
            tags=dto.tags,
            page=dto.page,
            page_size=dto.page_size
        )
    
    @staticmethod
    def entity_to_response_dto(entity: Entity) -> EntityResponseDTO:
        """Converte entidade de domínio para DTO de resposta."""
        return EntityResponseDTO(
            id=str(entity.id),
            name=entity.name,
            entity_type=EntityTypeDTO(entity.entity_type.value),
            status=EntityStatusDTO(entity.status.value),
            description=entity.description,
            schema_definition=entity.schema_definition,
            data_owner=entity.data_owner,
            data_steward=entity.data_steward,
            metadata=EntityMapper._metadata_to_dto(entity.metadata),
            quality_metrics=EntityMapper._quality_metrics_to_dto(entity.quality_metrics) if entity.quality_metrics else None,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )
    
    @staticmethod
    def entities_to_list_response_dto(
        entities: List[Entity],
        total: int,
        page: int,
        page_size: int
    ) -> EntityListResponseDTO:
        """Converte lista de entidades para DTO de resposta."""
        entity_dtos = [
            EntityMapper.entity_to_response_dto(entity) 
            for entity in entities
        ]
        
        return EntityListResponseDTO(
            entities=entity_dtos,
            total=total,
            page=page,
            page_size=page_size
        )
    
    @staticmethod
    def _metadata_from_dto(dto: EntityMetadataDTO) -> EntityMetadata:
        """Converte DTO de metadados para value object de domínio."""
        return EntityMetadata(
            tags=dto.tags,
            properties=dto.properties
        )
    
    @staticmethod
    def _metadata_to_dto(metadata: EntityMetadata) -> EntityMetadataDTO:
        """Converte value object de metadados para DTO."""
        return EntityMetadataDTO(
            tags=metadata.tags,
            properties=metadata.properties
        )
    
    @staticmethod
    def _quality_metrics_to_dto(metrics: QualityMetrics) -> QualityMetricsDTO:
        """Converte métricas de qualidade para DTO."""
        return QualityMetricsDTO(
            completeness_score=metrics.completeness_score.value,
            accuracy_score=metrics.accuracy_score.value,
            consistency_score=metrics.consistency_score.value,
            validity_score=metrics.validity_score.value,
            timeliness_score=metrics.timeliness_score.value,
            uniqueness_score=metrics.uniqueness_score.value
        )


class EntityValidationMapper:
    """
    Mapper especializado para validações de entrada.
    
    Responsável por validações específicas que requerem
    conhecimento de domínio mas são aplicadas na camada de apresentação.
    """
    
    @staticmethod
    def validate_create_request(dto: CreateEntityRequestDTO) -> List[str]:
        """Valida request de criação e retorna lista de erros."""
        errors = []
        
        # Validação específica para TABLE
        if dto.entity_type == EntityTypeDTO.TABLE:
            if not dto.schema_definition:
                errors.append("TABLE entities must have schema_definition")
            elif not isinstance(dto.schema_definition, dict):
                errors.append("schema_definition must be a valid object")
            elif not dto.schema_definition.get('columns'):
                errors.append("TABLE schema_definition must have columns")
        
        # Validação de nome
        if dto.name and not dto.name.strip():
            errors.append("Name cannot be empty or whitespace only")
        
        # Validação de proprietário/steward
        if dto.data_owner and not dto.data_owner.strip():
            errors.append("data_owner cannot be empty if provided")
        
        if dto.data_steward and not dto.data_steward.strip():
            errors.append("data_steward cannot be empty if provided")
        
        return errors
    
    @staticmethod
    def validate_update_request(dto: UpdateEntityRequestDTO) -> List[str]:
        """Valida request de atualização e retorna lista de erros."""
        errors = []
        
        # Pelo menos um campo deve ser fornecido
        fields_provided = [
            dto.name, dto.description, dto.schema_definition,
            dto.data_owner, dto.data_steward, dto.metadata
        ]
        
        if not any(field is not None for field in fields_provided):
            errors.append("At least one field must be provided for update")
        
        # Validação de nome se fornecido
        if dto.name is not None and not dto.name.strip():
            errors.append("Name cannot be empty or whitespace only")
        
        # Validação de proprietário/steward se fornecidos
        if dto.data_owner is not None and not dto.data_owner.strip():
            errors.append("data_owner cannot be empty if provided")
        
        if dto.data_steward is not None and not dto.data_steward.strip():
            errors.append("data_steward cannot be empty if provided")
        
        return errors
    
    @staticmethod
    def validate_status_change_request(dto: ChangeEntityStatusRequestDTO) -> List[str]:
        """Valida request de mudança de status e retorna lista de erros."""
        errors = []
        
        # Validação específica para DEPRECATED
        if dto.new_status == EntityStatusDTO.DEPRECATED:
            if not dto.retention_policy:
                errors.append("retention_policy is required when deprecating entity")
            elif not dto.retention_policy.strip():
                errors.append("retention_policy cannot be empty when deprecating entity")
        
        # Validação de motivo se fornecido
        if dto.reason is not None and not dto.reason.strip():
            errors.append("reason cannot be empty if provided")
        
        return errors

