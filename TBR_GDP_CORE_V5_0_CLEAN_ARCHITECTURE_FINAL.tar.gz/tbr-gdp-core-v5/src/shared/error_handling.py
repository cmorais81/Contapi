"""
TBR GDP Core v5.0 - Error Handling Middleware (Corrigido)
Autor: Carlos Morais <carlos.morais@f1rst.com.br>

Middleware para tratamento estruturado de erros em toda a aplicação.
Converte exceções em respostas HTTP apropriadas com logging.
"""

from typing import Dict, Any, Optional, Callable, Awaitable
from fastapi import Request, Response, status
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError, HTTPException
from starlette.middleware.base import BaseHTTPMiddleware
import traceback
import uuid

from ..domain.exceptions import (
    TBRGDPError, DomainError, ApplicationError, InfrastructureError,
    ValidationError, EntityNotFoundError, EntityAlreadyExistsError,
    BusinessRuleViolationError, DatabaseError
)
from .logging import get_logger, LogCategory, LogContext


class ErrorResponse:
    """
    Resposta padronizada para erros.
    
    Fornece estrutura consistente para todas as respostas de erro
    da API, facilitando o tratamento no frontend.
    """
    
    def __init__(
        self,
        error_code: str,
        message: str,
        details: Optional[Dict[str, Any]] = None,
        request_id: Optional[str] = None,
        status_code: int = status.HTTP_500_INTERNAL_SERVER_ERROR
    ):
        self.error_code = error_code
        self.message = message
        self.details = details or {}
        self.request_id = request_id
        self.status_code = status_code
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte para dicionário para serialização JSON."""
        response = {
            "error": {
                "code": self.error_code,
                "message": self.message,
                "details": self.details
            }
        }
        
        if self.request_id:
            response["request_id"] = self.request_id
        
        return response
    
    def to_json_response(self) -> JSONResponse:
        """Converte para JSONResponse do FastAPI."""
        return JSONResponse(
            status_code=self.status_code,
            content=self.to_dict()
        )


class ErrorHandler:
    """
    Manipulador centralizado de erros.
    
    Converte diferentes tipos de exceções em respostas HTTP
    apropriadas, com logging estruturado.
    """
    
    def __init__(self):
        self._logger = get_logger(__name__)
        self._error_map = self._build_error_map()
    
    def handle_error(
        self, 
        error: Exception, 
        request: Optional[Request] = None
    ) -> ErrorResponse:
        """
        Manipula uma exceção e retorna resposta de erro apropriada.
        
        Args:
            error: Exceção a ser tratada
            request: Request HTTP opcional para contexto
            
        Returns:
            Resposta de erro estruturada
        """
        request_id = self._get_request_id(request)
        context = self._create_log_context(error, request, request_id)
        
        # Mapear exceção para resposta
        if type(error) in self._error_map:
            handler = self._error_map[type(error)]
            error_response = handler(error, request_id)
        else:
            error_response = self._handle_unknown_error(error, request_id)
        
        # Log do erro
        self._log_error(error, error_response, context)
        
        return error_response
    
    def _build_error_map(self) -> Dict[type, Callable]:
        """Constrói mapeamento de exceções para handlers."""
        return {
            # Erros de domínio
            ValidationError: self._handle_validation_error,
            EntityNotFoundError: self._handle_entity_not_found_error,
            EntityAlreadyExistsError: self._handle_entity_already_exists_error,
            BusinessRuleViolationError: self._handle_business_rule_violation_error,
            
            # Erros de infraestrutura
            DatabaseError: self._handle_database_error,
            
            # Erros HTTP do FastAPI
            HTTPException: self._handle_http_exception,
            RequestValidationError: self._handle_request_validation_error,
        }
    
    def _handle_validation_error(
        self, 
        error: ValidationError, 
        request_id: str
    ) -> ErrorResponse:
        """Trata erros de validação."""
        return ErrorResponse(
            error_code="VALIDATION_ERROR",
            message=error.message,
            details=error.details,
            request_id=request_id,
            status_code=status.HTTP_400_BAD_REQUEST
        )
    
    def _handle_entity_not_found_error(
        self, 
        error: EntityNotFoundError, 
        request_id: str
    ) -> ErrorResponse:
        """Trata erros de entidade não encontrada."""
        return ErrorResponse(
            error_code="ENTITY_NOT_FOUND",
            message=error.message,
            details=error.details,
            request_id=request_id,
            status_code=status.HTTP_404_NOT_FOUND
        )
    
    def _handle_entity_already_exists_error(
        self, 
        error: EntityAlreadyExistsError, 
        request_id: str
    ) -> ErrorResponse:
        """Trata erros de entidade já existente."""
        return ErrorResponse(
            error_code="ENTITY_ALREADY_EXISTS",
            message=error.message,
            details=error.details,
            request_id=request_id,
            status_code=status.HTTP_409_CONFLICT
        )
    
    def _handle_business_rule_violation_error(
        self, 
        error: BusinessRuleViolationError, 
        request_id: str
    ) -> ErrorResponse:
        """Trata erros de violação de regra de negócio."""
        return ErrorResponse(
            error_code="BUSINESS_RULE_VIOLATION",
            message=error.message,
            details=error.details,
            request_id=request_id,
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY
        )
    
    def _handle_database_error(
        self, 
        error: DatabaseError, 
        request_id: str
    ) -> ErrorResponse:
        """Trata erros de banco de dados."""
        return ErrorResponse(
            error_code="DATABASE_ERROR",
            message="Database operation failed",
            details={
                "operation": error.operation,
                # Não expor detalhes internos do banco
            },
            request_id=request_id,
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )
    
    def _handle_http_exception(
        self, 
        error: HTTPException, 
        request_id: str
    ) -> ErrorResponse:
        """Trata exceções HTTP do FastAPI."""
        return ErrorResponse(
            error_code="HTTP_ERROR",
            message=error.detail,
            details={},
            request_id=request_id,
            status_code=error.status_code
        )
    
    def _handle_request_validation_error(
        self, 
        error: RequestValidationError, 
        request_id: str
    ) -> ErrorResponse:
        """Trata erros de validação de request."""
        return ErrorResponse(
            error_code="REQUEST_VALIDATION_ERROR",
            message="Request validation failed",
            details={
                "validation_errors": error.errors()
            },
            request_id=request_id,
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY
        )
    
    def _handle_unknown_error(
        self, 
        error: Exception, 
        request_id: str
    ) -> ErrorResponse:
        """Trata erros não mapeados."""
        return ErrorResponse(
            error_code="INTERNAL_SERVER_ERROR",
            message="An unexpected error occurred",
            details={
                "error_type": type(error).__name__
                # Não expor stack trace em produção
            },
            request_id=request_id,
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )
    
    def _get_request_id(self, request: Optional[Request]) -> str:
        """Obtém ou gera ID da requisição."""
        if request and hasattr(request.state, 'request_id'):
            return request.state.request_id
        return str(uuid.uuid4())
    
    def _create_log_context(
        self, 
        error: Exception, 
        request: Optional[Request], 
        request_id: str
    ) -> LogContext:
        """Cria contexto de log para o erro."""
        context = LogContext(request_id=request_id)
        
        if request:
            context.add_data("method", str(request.method))
            context.add_data("url", str(request.url))
            user_agent = request.headers.get("user-agent")
            if user_agent:
                context.add_data("user_agent", str(user_agent))
        
        if isinstance(error, TBRGDPError):
            context.add_data("error_code", error.error_code)
            if hasattr(error, 'details'):
                context.add_data("error_details", error.details)
        
        return context
    
    def _log_error(
        self, 
        error: Exception, 
        error_response: ErrorResponse, 
        context: LogContext
    ) -> None:
        """Registra o erro no log."""
        if error_response.status_code >= 500:
            # Erros críticos (5xx)
            self._logger.critical(
                f"Critical error: {error_response.message}",
                category=LogCategory.APPLICATION,
                context=context,
                exception=error
            )
        elif error_response.status_code >= 400:
            # Erros de cliente (4xx)
            self._logger.warning(
                f"Client error: {error_response.message}",
                category=LogCategory.APPLICATION,
                context=context,
                error_code=error_response.error_code,
                status_code=error_response.status_code
            )


class ErrorHandlingMiddleware(BaseHTTPMiddleware):
    """
    Middleware para captura e tratamento automático de erros.
    
    Intercepta todas as exceções não tratadas e as converte
    em respostas HTTP apropriadas.
    """
    
    def __init__(self, app, debug: bool = False):
        super().__init__(app)
        self._error_handler = ErrorHandler()
        self._debug = debug
        self._logger = get_logger(__name__)
    
    async def dispatch(
        self, 
        request: Request, 
        call_next: Callable[[Request], Awaitable[Response]]
    ) -> Response:
        """
        Processa a requisição com tratamento de erros.
        
        Args:
            request: Requisição HTTP
            call_next: Próximo middleware/handler
            
        Returns:
            Resposta HTTP
        """
        # Gerar ID único para a requisição
        request_id = str(uuid.uuid4())
        request.state.request_id = request_id
        
        # Log da requisição
        context = LogContext(
            request_id=request_id,
            operation=f"{request.method} {request.url.path}"
        )
        
        self._logger.info(
            f"Request started: {request.method} {request.url.path}",
            category=LogCategory.APPLICATION,
            context=context
        )
        
        try:
            # Processar requisição
            response = await call_next(request)
            
            # Log de sucesso
            self._logger.info(
                f"Request completed: {request.method} {request.url.path}",
                category=LogCategory.APPLICATION,
                context=context,
                status_code=response.status_code
            )
            
            return response
            
        except Exception as error:
            # Tratar erro
            error_response = self._error_handler.handle_error(error, request)
            
            # Em modo debug, adicionar stack trace
            if self._debug and error_response.status_code >= 500:
                error_response.details["stack_trace"] = traceback.format_exc()
            
            return error_response.to_json_response()


# Função de conveniência para uso direto
def handle_error(error: Exception, request: Optional[Request] = None) -> ErrorResponse:
    """Função de conveniência para tratar erros."""
    handler = ErrorHandler()
    return handler.handle_error(error, request)

