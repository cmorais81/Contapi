"""
TBR GDP Core v5.0 - Structured Logging System
Autor: Carlos Morais <carlos.morais@f1rst.com.br>

Sistema de logging estruturado para observabilidade e debugging.
Implementa diferentes níveis de log com contexto rico.
"""

import logging
import json
import traceback
from datetime import datetime
from typing import Dict, Any, Optional, Union
from enum import Enum
from dataclasses import dataclass, asdict
from contextlib import contextmanager

from ..domain.exceptions import TBRGDPError


class LogLevel(Enum):
    """Níveis de log disponíveis."""
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"


class LogCategory(Enum):
    """Categorias de log para organização."""
    DOMAIN = "domain"
    APPLICATION = "application"
    INFRASTRUCTURE = "infrastructure"
    PRESENTATION = "presentation"
    SECURITY = "security"
    PERFORMANCE = "performance"
    BUSINESS = "business"
    AUDIT = "audit"


@dataclass
class LogContext:
    """
    Contexto estruturado para logs.
    
    Permite adicionar informações ricas aos logs para facilitar
    debugging e análise posterior.
    """
    user_id: Optional[str] = None
    session_id: Optional[str] = None
    request_id: Optional[str] = None
    entity_id: Optional[str] = None
    entity_type: Optional[str] = None
    operation: Optional[str] = None
    duration_ms: Optional[float] = None
    additional_data: Optional[Dict[str, Any]] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte contexto para dicionário, removendo valores None."""
        data = asdict(self)
        return {k: v for k, v in data.items() if v is not None}
    
    def add_data(self, key: str, value: Any) -> 'LogContext':
        """Adiciona dados adicionais ao contexto."""
        if self.additional_data is None:
            self.additional_data = {}
        self.additional_data[key] = value
        return self


class StructuredLogger:
    """
    Logger estruturado para a aplicação.
    
    Fornece interface consistente para logging com contexto rico
    e formatação estruturada para facilitar análise.
    """
    
    def __init__(self, name: str, level: LogLevel = LogLevel.INFO):
        self._logger = logging.getLogger(name)
        self._logger.setLevel(level.value)
        
        # Configurar handler se não existir
        if not self._logger.handlers:
            handler = logging.StreamHandler()
            formatter = StructuredFormatter()
            handler.setFormatter(formatter)
            self._logger.addHandler(handler)
    
    def debug(
        self, 
        message: str, 
        category: LogCategory = LogCategory.APPLICATION,
        context: Optional[LogContext] = None,
        **kwargs
    ) -> None:
        """Log de debug com contexto."""
        self._log(LogLevel.DEBUG, message, category, context, **kwargs)
    
    def info(
        self, 
        message: str, 
        category: LogCategory = LogCategory.APPLICATION,
        context: Optional[LogContext] = None,
        **kwargs
    ) -> None:
        """Log informativo com contexto."""
        self._log(LogLevel.INFO, message, category, context, **kwargs)
    
    def warning(
        self, 
        message: str, 
        category: LogCategory = LogCategory.APPLICATION,
        context: Optional[LogContext] = None,
        **kwargs
    ) -> None:
        """Log de warning com contexto."""
        self._log(LogLevel.WARNING, message, category, context, **kwargs)
    
    def error(
        self, 
        message: str, 
        category: LogCategory = LogCategory.APPLICATION,
        context: Optional[LogContext] = None,
        exception: Optional[Exception] = None,
        **kwargs
    ) -> None:
        """Log de erro com contexto e exceção opcional."""
        if exception:
            kwargs['exception_type'] = type(exception).__name__
            kwargs['exception_message'] = str(exception)
            if isinstance(exception, TBRGDPError):
                kwargs['error_code'] = exception.error_code
                if hasattr(exception, 'context'):
                    kwargs['error_context'] = exception.context
            kwargs['stack_trace'] = traceback.format_exc()
        
        self._log(LogLevel.ERROR, message, category, context, **kwargs)
    
    def critical(
        self, 
        message: str, 
        category: LogCategory = LogCategory.APPLICATION,
        context: Optional[LogContext] = None,
        exception: Optional[Exception] = None,
        **kwargs
    ) -> None:
        """Log crítico com contexto e exceção opcional."""
        if exception:
            kwargs['exception_type'] = type(exception).__name__
            kwargs['exception_message'] = str(exception)
            if isinstance(exception, TBRGDPError):
                kwargs['error_code'] = exception.error_code
                if hasattr(exception, 'context'):
                    kwargs['error_context'] = exception.context
            kwargs['stack_trace'] = traceback.format_exc()
        
        self._log(LogLevel.CRITICAL, message, category, context, **kwargs)
    
    def audit(
        self, 
        message: str, 
        context: Optional[LogContext] = None,
        **kwargs
    ) -> None:
        """Log de auditoria - sempre INFO level."""
        self._log(LogLevel.INFO, message, LogCategory.AUDIT, context, **kwargs)
    
    def performance(
        self, 
        message: str, 
        duration_ms: float,
        context: Optional[LogContext] = None,
        **kwargs
    ) -> None:
        """Log de performance com duração."""
        if context:
            context.duration_ms = duration_ms
        else:
            context = LogContext(duration_ms=duration_ms)
        
        kwargs['duration_ms'] = duration_ms
        self._log(LogLevel.INFO, message, LogCategory.PERFORMANCE, context, **kwargs)
    
    def business_event(
        self, 
        message: str, 
        context: Optional[LogContext] = None,
        **kwargs
    ) -> None:
        """Log de eventos de negócio importantes."""
        self._log(LogLevel.INFO, message, LogCategory.BUSINESS, context, **kwargs)
    
    def security_event(
        self, 
        message: str, 
        context: Optional[LogContext] = None,
        **kwargs
    ) -> None:
        """Log de eventos de segurança."""
        self._log(LogLevel.WARNING, message, LogCategory.SECURITY, context, **kwargs)
    
    def _log(
        self, 
        level: LogLevel, 
        message: str, 
        category: LogCategory,
        context: Optional[LogContext] = None,
        **kwargs
    ) -> None:
        """Método interno para logging estruturado."""
        log_data = {
            'timestamp': datetime.utcnow().isoformat(),
            'level': level.value,
            'category': category.value,
            'message': message,
        }
        
        # Adicionar contexto se fornecido
        if context:
            log_data['context'] = context.to_dict()
        
        # Adicionar dados extras
        if kwargs:
            log_data['data'] = kwargs
        
        # Usar o nível apropriado do logger padrão
        log_method = getattr(self._logger, level.value.lower())
        log_method(json.dumps(log_data, ensure_ascii=False))


class StructuredFormatter(logging.Formatter):
    """
    Formatter personalizado para logs estruturados.
    
    Formata logs em JSON estruturado para facilitar parsing
    e análise por ferramentas de observabilidade.
    """
    
    def format(self, record: logging.LogRecord) -> str:
        """Formata o record de log em JSON estruturado."""
        try:
            # Tentar parsear como JSON (já estruturado)
            log_data = json.loads(record.getMessage())
            return json.dumps(log_data, ensure_ascii=False, indent=None)
        except (json.JSONDecodeError, ValueError):
            # Fallback para log não estruturado
            return json.dumps({
                'timestamp': datetime.utcnow().isoformat(),
                'level': record.levelname,
                'logger': record.name,
                'message': record.getMessage(),
                'module': record.module,
                'function': record.funcName,
                'line': record.lineno
            }, ensure_ascii=False)


@contextmanager
def log_performance(
    logger: StructuredLogger, 
    operation: str,
    context: Optional[LogContext] = None
):
    """
    Context manager para logging automático de performance.
    
    Usage:
        with log_performance(logger, "create_entity", context):
            # operação a ser medida
            result = create_entity(...)
    """
    start_time = datetime.utcnow()
    
    try:
        if context:
            context.operation = operation
        else:
            context = LogContext(operation=operation)
        
        logger.debug(f"Starting operation: {operation}", context=context)
        yield
        
    except Exception as e:
        duration = (datetime.utcnow() - start_time).total_seconds() * 1000
        logger.error(
            f"Operation failed: {operation}",
            category=LogCategory.PERFORMANCE,
            context=context,
            exception=e,
            duration_ms=duration
        )
        raise
    
    else:
        duration = (datetime.utcnow() - start_time).total_seconds() * 1000
        logger.performance(
            f"Operation completed: {operation}",
            duration_ms=duration,
            context=context
        )


class LoggerFactory:
    """
    Factory para criar loggers estruturados.
    
    Centraliza a configuração de loggers para garantir
    consistência em toda a aplicação.
    """
    
    _loggers: Dict[str, StructuredLogger] = {}
    _default_level: LogLevel = LogLevel.INFO
    
    @classmethod
    def get_logger(cls, name: str, level: Optional[LogLevel] = None) -> StructuredLogger:
        """
        Obtém um logger estruturado.
        
        Args:
            name: Nome do logger (geralmente __name__ do módulo)
            level: Nível de log opcional
            
        Returns:
            Logger estruturado configurado
        """
        if name not in cls._loggers:
            cls._loggers[name] = StructuredLogger(
                name, 
                level or cls._default_level
            )
        
        return cls._loggers[name]
    
    @classmethod
    def set_default_level(cls, level: LogLevel) -> None:
        """Define o nível padrão para novos loggers."""
        cls._default_level = level
    
    @classmethod
    def configure_for_development(cls) -> None:
        """Configuração otimizada para desenvolvimento."""
        cls.set_default_level(LogLevel.DEBUG)
        
        # Configurar logging básico
        logging.basicConfig(
            level=logging.DEBUG,
            format='%(message)s'
        )
    
    @classmethod
    def configure_for_production(cls) -> None:
        """Configuração otimizada para produção."""
        cls.set_default_level(LogLevel.INFO)
        
        # Configurar logging básico
        logging.basicConfig(
            level=logging.INFO,
            format='%(message)s'
        )


# Convenience functions para uso direto
def get_logger(name: str) -> StructuredLogger:
    """Função de conveniência para obter logger."""
    return LoggerFactory.get_logger(name)


def create_context(
    user_id: Optional[str] = None,
    session_id: Optional[str] = None,
    request_id: Optional[str] = None,
    entity_id: Optional[str] = None,
    entity_type: Optional[str] = None,
    operation: Optional[str] = None,
    **kwargs
) -> LogContext:
    """Função de conveniência para criar contexto de log."""
    context = LogContext(
        user_id=user_id,
        session_id=session_id,
        request_id=request_id,
        entity_id=entity_id,
        entity_type=entity_type,
        operation=operation
    )
    
    for key, value in kwargs.items():
        context.add_data(key, value)
    
    return context

