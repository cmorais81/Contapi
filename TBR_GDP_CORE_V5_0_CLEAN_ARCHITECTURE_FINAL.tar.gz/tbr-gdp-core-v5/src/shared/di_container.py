"""
TBR GDP Core v5.0 - Dependency Injection Container
Autor: Carlos Morais <carlos.morais@f1rst.com.br>

Container de injeção de dependência seguindo princípios SOLID.
Implementa o padrão Dependency Inversion Principle (DIP).
"""

import inspect
from typing import Type, TypeVar, Dict, Any, Callable, Optional, get_type_hints
from abc import ABC, abstractmethod
from enum import Enum

from ..exceptions import ConfigurationError


T = TypeVar('T')


class ServiceLifetime(Enum):
    """
    Tempo de vida dos serviços no container.
    """
    SINGLETON = "singleton"  # Uma instância para toda a aplicação
    TRANSIENT = "transient"  # Nova instância a cada resolução
    SCOPED = "scoped"       # Uma instância por escopo (request, etc.)


class ServiceDescriptor:
    """
    Descritor de serviço para o container DI.
    
    Encapsula informações sobre como criar e gerenciar um serviço.
    """
    
    def __init__(
        self,
        service_type: Type,
        implementation_type: Optional[Type] = None,
        factory: Optional[Callable] = None,
        instance: Optional[Any] = None,
        lifetime: ServiceLifetime = ServiceLifetime.TRANSIENT
    ):
        self.service_type = service_type
        self.implementation_type = implementation_type
        self.factory = factory
        self.instance = instance
        self.lifetime = lifetime
        
        # Validações
        if not any([implementation_type, factory, instance]):
            raise ConfigurationError(
                f"service_{service_type.__name__}",
                "Must provide implementation_type, factory, or instance"
            )
        
        if sum(bool(x) for x in [implementation_type, factory, instance]) > 1:
            raise ConfigurationError(
                f"service_{service_type.__name__}",
                "Can only provide one of: implementation_type, factory, or instance"
            )


class DIContainer:
    """
    Container de injeção de dependência.
    
    Implementa o padrão Service Locator com registro automático de dependências.
    Segue o princípio Dependency Inversion (DIP) do SOLID.
    """
    
    def __init__(self):
        self._services: Dict[Type, ServiceDescriptor] = {}
        self._singletons: Dict[Type, Any] = {}
        self._scoped_instances: Dict[str, Dict[Type, Any]] = {}
        self._current_scope: Optional[str] = None
    
    def register_singleton(
        self, 
        service_type: Type[T], 
        implementation_type: Optional[Type[T]] = None,
        factory: Optional[Callable[[], T]] = None,
        instance: Optional[T] = None
    ) -> 'DIContainer':
        """
        Registra um serviço como singleton.
        
        Args:
            service_type: Tipo do serviço (interface)
            implementation_type: Tipo da implementação
            factory: Factory function para criar a instância
            instance: Instância já criada
            
        Returns:
            Self para method chaining
        """
        descriptor = ServiceDescriptor(
            service_type=service_type,
            implementation_type=implementation_type,
            factory=factory,
            instance=instance,
            lifetime=ServiceLifetime.SINGLETON
        )
        
        self._services[service_type] = descriptor
        
        # Se uma instância foi fornecida, armazena como singleton
        if instance is not None:
            self._singletons[service_type] = instance
        
        return self
    
    def register_transient(
        self, 
        service_type: Type[T], 
        implementation_type: Optional[Type[T]] = None,
        factory: Optional[Callable[[], T]] = None
    ) -> 'DIContainer':
        """
        Registra um serviço como transient.
        
        Args:
            service_type: Tipo do serviço (interface)
            implementation_type: Tipo da implementação
            factory: Factory function para criar a instância
            
        Returns:
            Self para method chaining
        """
        descriptor = ServiceDescriptor(
            service_type=service_type,
            implementation_type=implementation_type,
            factory=factory,
            lifetime=ServiceLifetime.TRANSIENT
        )
        
        self._services[service_type] = descriptor
        return self
    
    def register_scoped(
        self, 
        service_type: Type[T], 
        implementation_type: Optional[Type[T]] = None,
        factory: Optional[Callable[[], T]] = None
    ) -> 'DIContainer':
        """
        Registra um serviço como scoped.
        
        Args:
            service_type: Tipo do serviço (interface)
            implementation_type: Tipo da implementação
            factory: Factory function para criar a instância
            
        Returns:
            Self para method chaining
        """
        descriptor = ServiceDescriptor(
            service_type=service_type,
            implementation_type=implementation_type,
            factory=factory,
            lifetime=ServiceLifetime.SCOPED
        )
        
        self._services[service_type] = descriptor
        return self
    
    def resolve(self, service_type: Type[T]) -> T:
        """
        Resolve um serviço do container.
        
        Args:
            service_type: Tipo do serviço a ser resolvido
            
        Returns:
            Instância do serviço
            
        Raises:
            ConfigurationError: Se o serviço não estiver registrado
        """
        if service_type not in self._services:
            raise ConfigurationError(
                f"service_{service_type.__name__}",
                f"Service {service_type.__name__} is not registered"
            )
        
        descriptor = self._services[service_type]
        
        # Singleton
        if descriptor.lifetime == ServiceLifetime.SINGLETON:
            if service_type in self._singletons:
                return self._singletons[service_type]
            
            instance = self._create_instance(descriptor)
            self._singletons[service_type] = instance
            return instance
        
        # Scoped
        elif descriptor.lifetime == ServiceLifetime.SCOPED:
            if self._current_scope is None:
                raise ConfigurationError(
                    "scope",
                    "No active scope for scoped service resolution"
                )
            
            if self._current_scope not in self._scoped_instances:
                self._scoped_instances[self._current_scope] = {}
            
            scope_instances = self._scoped_instances[self._current_scope]
            
            if service_type in scope_instances:
                return scope_instances[service_type]
            
            instance = self._create_instance(descriptor)
            scope_instances[service_type] = instance
            return instance
        
        # Transient
        else:
            return self._create_instance(descriptor)
    
    def _create_instance(self, descriptor: ServiceDescriptor) -> Any:
        """
        Cria uma instância baseada no descritor.
        
        Args:
            descriptor: Descritor do serviço
            
        Returns:
            Nova instância do serviço
        """
        # Instância já fornecida
        if descriptor.instance is not None:
            return descriptor.instance
        
        # Factory function
        if descriptor.factory is not None:
            return descriptor.factory()
        
        # Implementation type
        if descriptor.implementation_type is not None:
            return self._create_instance_from_type(descriptor.implementation_type)
        
        raise ConfigurationError(
            f"service_{descriptor.service_type.__name__}",
            "No valid creation method found"
        )
    
    def _create_instance_from_type(self, implementation_type: Type) -> Any:
        """
        Cria uma instância resolvendo automaticamente as dependências.
        
        Args:
            implementation_type: Tipo da implementação
            
        Returns:
            Nova instância com dependências resolvidas
        """
        # Obtém o construtor
        constructor = implementation_type.__init__
        
        # Obtém os parâmetros do construtor
        signature = inspect.signature(constructor)
        parameters = signature.parameters
        
        # Resolve as dependências
        kwargs = {}
        for param_name, param in parameters.items():
            if param_name == 'self':
                continue
            
            # Tenta obter o tipo da anotação
            param_type = param.annotation
            
            if param_type == inspect.Parameter.empty:
                # Tenta obter do type hints
                type_hints = get_type_hints(constructor)
                if param_name in type_hints:
                    param_type = type_hints[param_name]
                else:
                    raise ConfigurationError(
                        f"parameter_{param_name}",
                        f"Cannot resolve parameter '{param_name}' without type annotation"
                    )
            
            # Verifica se tem valor padrão
            if param.default != inspect.Parameter.empty:
                # Parâmetro opcional, tenta resolver mas não falha se não conseguir
                try:
                    kwargs[param_name] = self.resolve(param_type)
                except ConfigurationError:
                    # Usa o valor padrão
                    pass
            else:
                # Parâmetro obrigatório, deve resolver
                kwargs[param_name] = self.resolve(param_type)
        
        # Cria a instância
        return implementation_type(**kwargs)
    
    def create_scope(self, scope_id: str) -> 'DIScope':
        """
        Cria um novo escopo para serviços scoped.
        
        Args:
            scope_id: Identificador único do escopo
            
        Returns:
            Objeto de escopo para uso em context manager
        """
        return DIScope(self, scope_id)
    
    def _enter_scope(self, scope_id: str) -> None:
        """Entra em um escopo."""
        self._current_scope = scope_id
        if scope_id not in self._scoped_instances:
            self._scoped_instances[scope_id] = {}
    
    def _exit_scope(self, scope_id: str) -> None:
        """Sai de um escopo e limpa as instâncias."""
        if scope_id in self._scoped_instances:
            del self._scoped_instances[scope_id]
        
        if self._current_scope == scope_id:
            self._current_scope = None
    
    def is_registered(self, service_type: Type) -> bool:
        """
        Verifica se um serviço está registrado.
        
        Args:
            service_type: Tipo do serviço
            
        Returns:
            True se estiver registrado, False caso contrário
        """
        return service_type in self._services
    
    def get_registered_services(self) -> Dict[Type, ServiceDescriptor]:
        """
        Retorna todos os serviços registrados.
        
        Returns:
            Dicionário com os serviços registrados
        """
        return self._services.copy()


class DIScope:
    """
    Contexto de escopo para serviços scoped.
    
    Usado como context manager para gerenciar o ciclo de vida
    de serviços com lifetime scoped.
    """
    
    def __init__(self, container: DIContainer, scope_id: str):
        self._container = container
        self._scope_id = scope_id
    
    def __enter__(self) -> 'DIScope':
        """Entra no escopo."""
        self._container._enter_scope(self._scope_id)
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Sai do escopo."""
        self._container._exit_scope(self._scope_id)
    
    def resolve(self, service_type: Type[T]) -> T:
        """
        Resolve um serviço dentro do escopo.
        
        Args:
            service_type: Tipo do serviço
            
        Returns:
            Instância do serviço
        """
        return self._container.resolve(service_type)


# Instância global do container (pode ser substituída por configuração)
_global_container: Optional[DIContainer] = None


def get_container() -> DIContainer:
    """
    Obtém o container global.
    
    Returns:
        Container de DI global
    """
    global _global_container
    if _global_container is None:
        _global_container = DIContainer()
    return _global_container


def set_container(container: DIContainer) -> None:
    """
    Define o container global.
    
    Args:
        container: Novo container a ser usado globalmente
    """
    global _global_container
    _global_container = container


def resolve(service_type: Type[T]) -> T:
    """
    Resolve um serviço do container global.
    
    Args:
        service_type: Tipo do serviço
        
    Returns:
        Instância do serviço
    """
    return get_container().resolve(service_type)

