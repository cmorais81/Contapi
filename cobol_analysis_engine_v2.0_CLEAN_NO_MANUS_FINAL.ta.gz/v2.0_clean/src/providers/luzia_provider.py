
import os
import requests
import httpx
import asyncio
import warnings
import logging
import time
from datetime import datetime
from typing import Dict, Any, Optional
from dotenv import load_dotenv
from .base_provider import BaseProvider, AIRequest, AIResponse
from ..utils.execution_logger import ExecutionLogger

warnings.filterwarnings(action="ignore", message="Unverified HTTPS request is being made to host")
load_dotenv()

class LuziaProvider(BaseProvider):
    """Provider para LuzIA Corporativo - REST API simples."""

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        
        # Tratar caso onde config pode ser string
        if isinstance(config, str):
            config = {}
        
        luzia_config = config.get("luzia", {}) if isinstance(config, dict) else {}

        # Configuração simples baseada no exemplo funcional
        self.client_id = luzia_config.get("client_id", os.getenv("LUZIA_CLIENT_ID", "VISITOR-CHAT-FLOW-SALE-7d7e6f1156"))
        self.client_secret = luzia_config.get("client_secret", os.getenv("LUZIA_CLIENT_SECRET"))
        
        # URLs simplificadas sem SSL complexo
        self.auth_url = "https://luzia.com.br/api/v1/auth/token"
        self.api_url = "https://luzia.com.br/api/v1/chat/send"
        
        self.model = luzia_config.get("model", "luzia-chat")
        self.temperature = luzia_config.get("temperature", 0.1)
        self.timeout = luzia_config.get("timeout", 30.0)
        
        # Sem SSL complexo - usar configuração padrão
        self.ssl_verify = True

        self.logger = self._setup_logging()
        self.last_error = None
        
        log_dir = config.get("logging", {}).get("dir", "logs")
        self.execution_logger = ExecutionLogger(log_dir)

    def _setup_logging(self) -> logging.Logger:
        logger = logging.getLogger("LuziaProvider")
        logger.setLevel(logging.INFO)
        if not logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
            handler.setFormatter(formatter)
            logger.addHandler(handler)
        return logger

    async def _get_token(self) -> Optional[str]:
        """Obter token de acesso da LuzIA de forma simples"""
        payload = {
            "grant_type": "client_credentials",
            "client_id": self.client_id,
            "client_secret": self.client_secret
        }
        
        try:
            async with httpx.AsyncClient(verify=self.ssl_verify, timeout=self.timeout) as client:
                response = await client.post(self.auth_url, json=payload)
                response.raise_for_status()
                return response.json().get("access_token")
        except Exception as e:
            self.last_error = str(e)
            self.logger.error(f"Erro ao obter token: {self.last_error}")
            return None

    async def _submit(self, prompt: str, token: str) -> Dict[str, Any]:
        """Enviar mensagem para LuzIA de forma simples"""
        payload = {
            "message": prompt,
            "conversation_id": None  # Nova conversa a cada chamada
        }

        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }

        try:
            async with httpx.AsyncClient(verify=self.ssl_verify, timeout=self.timeout) as client:
                response = await client.post(self.api_url, headers=headers, json=payload)
                response.raise_for_status()
                return response.json()
        except Exception as e:
            self.logger.error(f"Erro ao enviar mensagem: {e}")
            raise

    async def analyze(self, request: AIRequest) -> AIResponse:
        self.execution_logger.log_provider_prompt(
            provider_name="luzia",
            prompt=request.prompt,
            model=self.model,
            temperature=self.temperature,
            max_tokens=4000
        )
        
        token = await self._get_token()
        if not token:
            self.logger.error("Falha ao obter token de acesso LuzIA")
            return AIResponse(
                success=False,
                content="Falha ao obter token de acesso.",
                provider="luzia",
                model=self.model,
                tokens_used=0,
                error_message="Authentication failed"
            )
        start_time = time.time()
        try:
            self.logger.info("Enviando requisição para LuzIA...")
            response_data = await self._submit(request.prompt, token)
            execution_time = time.time() - start_time
            
            result = AIResponse(
                success=True,
                content=response_data,
                provider="luzia",
                model=self.model,
                tokens_used=0 # LuzIA API não informa tokens
            )
            
            self.execution_logger.log_provider_response(
                provider_name="luzia",
                response=result,
                execution_time=execution_time,
                success=True
            )
            
            self.logger.info("Resposta recebida do LuzIA com sucesso")
            return result
            
        except (httpx.HTTPStatusError, Exception) as e:
            execution_time = time.time() - start_time
            self.last_error = str(e)
            
            result = AIResponse(
                success=False,
                content=f"Erro na chamada da API LuzIA: {self.last_error}",
                provider="luzia",
                model=self.model,
                tokens_used=0,
                error_message=str(e)
            )
            
            self.execution_logger.log_provider_response(
                provider_name="luzia",
                response=result,
                execution_time=execution_time,
                success=False
            )
            
            self.logger.error(f"Erro na análise com LuzIA: {self.last_error}")
            return result

    async def is_available(self) -> bool:
        token = await self._get_token()
        return token is not None

    async def get_status(self) -> Dict[str, Any]:
        token = await self._get_token()
        return {
            "provider": "luzia",
            "available": token is not None,
            "authenticated": token is not None,
            "model": self.model,
            "endpoint": self.api_url,
            "auth_endpoint": self.auth_url,
            "status": "ready" if token else "auth_failed",
            "last_error": self.last_error
        }

    def _format_luzia_query(self, prompt: str) -> list:
        system_prompt = """Você é um especialista em análise de código COBOL.
Responda em português do Brasil.
Se a pergunta for sobre código, responda apenas com o código, sem usar markdown.
Não comece a resposta com a palavra \'python\'."""
        
        return [
            {
                "role": "system",
                "content": system_prompt
            },
            {
                "role": "user",
                "content": prompt
            }
        ]

