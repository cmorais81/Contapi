"""Provedores LLM para Sistema de Análise COBOL v15.0"""

# Imports relativos corretos
try:
    from .base_provider import BaseProvider, AIRequest, AIResponse
except ImportError:
    BaseProvider = AIRequest = AIResponse = None

try:
    from .openai_provider import OpenAIProvider
except ImportError:
    OpenAIProvider = None

try:
    from .copilot_provider import CopilotProvider
except ImportError:
    CopilotProvider = None

try:
    from .luzia_provider import LuziaProvider
except ImportError:
    LuziaProvider = None

try:
    from .enhanced_mock_provider import EnhancedMockProvider
except ImportError:
    EnhancedMockProvider = None

try:
    from .basic_provider import BasicProvider
except ImportError:
    BasicProvider = None

try:
    from .bedrock_provider import BedrockProvider
except ImportError:
    BedrockProvider = None

try:
    from .databricks_provider import DatabricksProvider
except ImportError:
    DatabricksProvider = None

try:
    from .provider_manager import ProviderManager
except ImportError:
    ProviderManager = None

try:
    from .multi_provider_analyzer import MultiProviderAnalyzer
except ImportError:
    MultiProviderAnalyzer = None

__all__ = [
    'BaseProvider', 'AIRequest', 'AIResponse',
    'OpenAIProvider', 'CopilotProvider', 'LuziaProvider',
    'EnhancedMockProvider', 'BasicProvider', 'BedrockProvider',
    'DatabricksProvider', 'ProviderManager', 'MultiProviderAnalyzer'
]

