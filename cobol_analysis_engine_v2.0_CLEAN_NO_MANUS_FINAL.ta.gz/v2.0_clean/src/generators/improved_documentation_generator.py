import logging
from typing import Dict, Any
from datetime import datetime

class ImprovedDocumentationGenerator:
    """Gera documentação técnica rica e precisa, utilizando a análise aprimorada e semântica."""

    def __init__(self):
        self.logger = logging.getLogger(__name__)

    def generate(self, analysis_results: Dict[str, Any], target_language: str = "java") -> str:
        """Gera a documentação completa em Markdown."""
        doc = []
        doc.append(self._generate_header(analysis_results))
        doc.append(self._generate_summary(analysis_results))
        doc.append(self._generate_data_architecture(analysis_results))
        doc.append(self._generate_program_structure(analysis_results))
        doc.append(self._generate_business_logic(analysis_results)) # Atualizado para usar a análise semântica
        doc.append(self._generate_reimplementation_guide(analysis_results, target_language))
        return "\n\n".join(doc)

    def _generate_header(self, data: Dict[str, Any]) -> str:
        program_id = data.get("structural_analysis", {}).get("program_id", "UNKNOWN")
        return f"# Documentação Técnica: {program_id}\n**Data da Análise:** {datetime.now().strftime('%d/%m/%Y %H:%M')}"

    def _generate_summary(self, data: Dict[str, Any]) -> str:
        # Usa o propósito extraído pelo LLM
        purpose = data.get("functional_analysis", {}).get("purpose", "Não foi possível determinar o propósito.")
        return f"## 1. Resumo Funcional\n**Propósito do Programa:** {purpose}"

    def _cobol_pic_to_type(self, picture: str) -> str:
        if not picture:
            return "GRUPO"
        if 'V' in picture:
            return "NUMERICO_DECIMAL"
        if '9' in picture:
            return "NUMERICO"
        if 'X' in picture:
            return "ALFANUMERICO"
        return "DESCONHECIDO"

    def _generate_data_architecture(self, data: Dict[str, Any]) -> str:
        layouts = data.get("record_layouts", {})
        # A informação de arquivos agora pode vir da análise funcional/semântica
        files = data.get("functional_analysis", {}).get("files", []) 
        if not files:
             files = data.get("structural_analysis", {}).get("files", []) # Fallback para análise estrutural

        doc = ["## 2. Arquitetura de Dados"]

        doc.append("### Arquivos")
        if not files:
            doc.append("Nenhum arquivo identificado.")
        else:
            doc.append("| Nome Lógico | Nome Físico | Operação |")
            doc.append("|---|---|---|")
            for f in files:
                doc.append(f"| {f.get('logical_name', 'N/A')} | {f.get('physical_name', 'N/A')} | {f.get('operation', 'N/A')} |")

        doc.append("\n### Layouts de Registro")
        if not layouts:
            doc.append("Nenhum layout de registro extraído.")
        else:
            for record_name, fields in layouts.items():
                doc.append(f"#### Layout: {record_name}")
                doc.append("| Nível | Campo | Posição | Tamanho | Ocorr. | Redef. | Tipo | PIC |")
                doc.append("|---|---|---|---|---|---|---|---|")
                for field in fields:
                    data_type = self._cobol_pic_to_type(field.picture)
                    doc.append(f"| {field.level} | {field.name} | {field.start} | {field.length} | {field.occurs or ''} | {field.redefines or ''} | {data_type} | {field.picture or ''} |")
        return "\n".join(doc)

    def _generate_program_structure(self, data: Dict[str, Any]) -> str:
        structure = data.get("structural_analysis", {})
        doc = ["## 3. Estrutura do Programa"]
        doc.append(f"- **Divisões:** {', '.join(structure.get('divisions', []))}")
        doc.append("- **Seções:**")
        for section, paragraphs in structure.get("sections", {}).items():
            doc.append(f"  - **{section}**: {', '.join(paragraphs)}")
        
        doc.append("- **Fluxo de Controle (Grafo de Execução):**")
        flow = structure.get("control_flow_graph", {})
        if not flow:
            doc.append("  - Fluxo não determinado.")
        else:
            for source, targets in flow.items():
                if targets:
                    doc.append(f"  - `{source}` -> `{'`, `'.join(targets)}`")

        return "\n".join(doc)

    def _generate_business_logic(self, data: Dict[str, Any]) -> str:
        logic = data.get("functional_analysis", {})
        doc = ["## 4. Lógica de Negócio Detalhada"]

        doc.append("### Fluxo de Dados")
        doc.append(logic.get("data_flow", "Não descrito."))

        doc.append("\n### Regras de Negócio")
        business_rules = logic.get("business_rules", [])
        if not business_rules:
            doc.append("Nenhuma regra de negócio específica foi extraída.")
        else:
            for i, rule in enumerate(business_rules):
                doc.append(f"- **Regra {i+1}:** {rule}")

        doc.append("\n### Pontos Críticos da Lógica")
        critical_points = logic.get("critical_logic_points", [])
        if not critical_points:
            doc.append("Nenhum ponto crítico de lógica foi identificado.")
        else:
            for i, point in enumerate(critical_points):
                doc.append(f"- **Ponto Crítico {i+1}:** {point}")

        return "\n".join(doc)

    def _generate_reimplementation_guide(self, data: Dict[str, Any], lang: str) -> str:
        # Esta seção pode ser aprimorada para usar a análise semântica e gerar um código mais fiel
        doc = [f"## 5. Guia de Reimplementação ({lang.title()})"]
        doc.append("_(Esta seção é um exemplo genérico e deve ser aprimorada para refletir a lógica de negócio detalhada.)_")
        code = []
        if lang == 'java':
            code.append("// O código de reimplementação deve ser gerado com base na lógica de negócio detalhada na seção 4.")
            code.append("// Exemplo de esqueleto:")
            program_name = data.get("program_name", "CobolProgram").replace("-", "")
            code.append(f"public class {program_name} {{")
            code.append("    public void process() {")
            code.append("        // 1. Ler registros do arquivo de entrada.")
            code.append("        // 2. Para cada registro, aplicar as validações e regras de negócio descritas na Seção 4.")
            code.append("        // 3. Implementar a lógica de roteamento e particionamento conforme descrito.")
            code.append("        // 4. Gravar nos arquivos de saída apropriados.")
            code.append("        // 5. Tratar erros e gerar logs/relatórios.")
            code.append("    }")
            code.append("}")

        doc.append(f"``` {lang}\n" + "\n".join(code) + "\n```")
        return "\n".join(doc)

