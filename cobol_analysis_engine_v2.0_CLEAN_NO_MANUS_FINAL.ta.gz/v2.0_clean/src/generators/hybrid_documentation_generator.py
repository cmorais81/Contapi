#!/usr/bin/env python3
"""
Hybrid Documentation Generator - Sistema de Análise COBOL v1.0.0
Gera documentação rica baseada em conteúdo real + análise IA quando disponível.
"""

import json
import logging
from typing import Dict, List, Any
from datetime import datetime

class HybridDocumentationGenerator:
    """Gera documentação híbrida combinando conteúdo real e análise IA."""
    
    def __init__(self):
        self.logger = logging.getLogger(self.__class__.__name__)
    
    def generate_documentation(self, 
                             enriched_content: Dict[str, Any],
                             target_audience: str = 'technical',
                             output_format: str = 'markdown') -> str:
        """
        Gera documentação híbrida baseada em conteúdo real e análise IA.
        
        Args:
            enriched_content: Conteúdo enriquecido (real + IA)
            target_audience: Audiência alvo
            output_format: Formato de saída
            
        Returns:
            Documentação formatada
        """
        
        if not enriched_content:
            self.logger.warning("Conteúdo enriquecido está vazio. Retornando documentação vazia.")
            return "# Documentação Vazia\n\nNenhum conteúdo foi fornecido para gerar a documentação."

        if output_format == 'markdown':
            return self._generate_markdown_documentation(enriched_content, target_audience)

        elif output_format == 'json':
            return json.dumps(enriched_content, indent=2, ensure_ascii=False)
        else:
            return self._generate_markdown_documentation(enriched_content, target_audience)
    
    def _generate_markdown_documentation(self, content: Dict, audience: str) -> str:
        """Gera documentação em formato Markdown."""
        
        doc = []
        
        # Cabeçalho
        doc.extend(self._generate_header(content, audience))
        
        # Resumo Executivo
        doc.extend(self._generate_executive_summary(content, audience))
        
        # Programas Analisados
        doc.extend(self._generate_programs_section(content, audience))
        
        # Copybooks
        doc.extend(self._generate_copybooks_section(content, audience))
        
        # Análise Detalhada do Código
        doc.extend(self._generate_detailed_code_analysis(content, audience))
        
        # Estrutura de Dados
        doc.extend(self._generate_data_structure_section(content, audience))
        
        # Fluxo de Processamento
        doc.extend(self._generate_processing_flow_section(content, audience))
        
        # Análise Técnica
        doc.extend(self._generate_technical_analysis(content, audience))
        
        # Regras de Negócio
        doc.extend(self._generate_business_rules_section(content, audience))
        
        # Recomendações
        doc.extend(self._generate_recommendations(content, audience))
        
        # Rodapé
        doc.extend(self._generate_footer(content))
        
        return '\n'.join(doc)
    
    def _generate_header(self, content: Dict, audience: str) -> List[str]:
        """Gera cabeçalho da documentação."""
        
        programs_count = content.get('summary', {}).get('programs_found', 0)
        copybooks_count = content.get('summary', {}).get('copybooks_found', 0)
        
        ai_available = content.get('ai_enhancement', {}).get('available', False)
        analysis_method = content.get('ai_enhancement', {}).get('analysis_method', 'real_content_only')
        
        header = [
            f"# Documentação de Sistemas COBOL - Análise {analysis_method.replace('_', ' ').title()}",
            "",
            f"**Data de Geração:** {datetime.now().strftime('%d/%m/%Y %H:%M')}",
            f"**Audiência:** {audience.title()}",
            f"**Programas Analisados:** {programs_count}",
            f"**Copybooks Analisados:** {copybooks_count}",
            f"**Método de Análise:** {'Híbrido (Conteúdo Real + IA)' if ai_available else 'Conteúdo Real Extraído'}",
            f"**Qualidade do Conteúdo:** {content.get('summary', {}).get('content_quality', 'high').title()}",
            ""
        ]
        
        return header
    
    def _generate_executive_summary(self, content: Dict, audience: str) -> List[str]:
        """Gera resumo executivo adaptado por audiência."""
        
        programs = content.get('programs', [])
        copybooks = content.get('copybooks', [])
        tech_info = content.get('technical_info', {})
        
        summary = ["## Resumo Executivo", ""]
        
        if audience == 'executive':
            summary.extend([
                f"Esta análise apresenta **{len(programs)} sistemas COBOL** e **{len(copybooks)} estruturas de dados** ",
                "relacionados ao processamento de informações do Banco Central do Brasil (BACEN). ",
                "",
                "### Principais Descobertas:",
                "",
                f"- **Sistemas Ativos:** {len(programs)} programas em operação",
                f"- **Estruturas de Dados:** {len(copybooks)} copybooks com definições do BACEN",
                f"- **Autores Identificados:** {len(tech_info.get('authors', []))} desenvolvedores",
                f"- **Arquivos Processados:** {sum(tech_info.get('file_types', {}).values())} arquivos de dados",
                ""
            ])
            
        elif audience == 'technical':
            summary.extend([
                f"Análise técnica detalhada de **{len(programs)} programas COBOL** e **{len(copybooks)} copybooks** ",
                "extraídos dos arquivos fontes.txt e BOOKS.txt. O sistema identificou estruturas complexas ",
                "relacionadas ao processamento de dados do Banco Central.",
                "",
                "### Características Técnicas:",
                "",
                f"- **Linguagem:** COBOL (COBOL-85/2002/2014)",
                f"- **Ambiente:** Mainframe IBM",
                f"- **Divisões COBOL:** {', '.join(tech_info.get('divisions_used', []))}",
                f"- **Tipos de Arquivo:** {tech_info.get('file_types', {})}",
                ""
            ])
            
        elif audience == 'business':
            objectives = [p.get('objective', '') for p in programs if p.get('objective')]
            summary.extend([
                f"Análise de **{len(programs)} sistemas de negócio** relacionados ao Banco Central, ",
                "incluindo funcionalidades de particionamento, validação e transmissão de dados.",
                "",
                "### Funcionalidades Principais:",
                ""
            ])
            
            for obj in objectives[:3]:  # Limitar a 3 objetivos
                if obj:
                    summary.append(f"- {obj}")
            summary.append("")
            
        else:  # implementation
            summary.extend([
                f"Guia de implementação para modernização de **{len(programs)} programas COBOL** ",
                "com foco em preservação de regras de negócio e estruturas de dados.",
                "",
                "### Escopo da Modernização:",
                "",
                f"- **Programas a Migrar:** {len(programs)}",
                f"- **Estruturas de Dados:** {len(copybooks)} copybooks",
                f"- **Complexidade:** {'Alta' if len(programs) > 3 else 'Média'}",
                f"- **Histórico Disponível:** {'Sim' if any(p.get('version_history') for p in programs) else 'Não'}",
                ""
            ])
        
        return summary
    
    def _generate_programs_section(self, content: Dict, audience: str) -> List[str]:
        """Gera seção de programas analisados."""
        
        programs = content.get('programs', [])
        section = ["## Programas Analisados", ""]
        
        for i, program in enumerate(programs, 1):
            section.append(f"### {i}. {program['name']}")
            section.append("")
            
            # Objetivo (sempre importante)
            if program.get('objective'):
                section.append(f"**Objetivo:** {program['objective']}")
                section.append("")
            
            # Informações por audiência
            if audience in ['technical', 'implementation']:
                if program.get('author'):
                    section.append(f"**Autor:** {program['author']}")
                if program.get('date_written'):
                    section.append(f"**Data de Criação:** {program['date_written']}")
                section.append("")
                
                # Arquivos
                if program.get('files'):
                    section.append("**Arquivos Utilizados:**")
                    for file_info in program['files']:
                        section.append(f"- `{file_info['name']}` ({file_info['type']}): {file_info['description']}")
                    section.append("")
            
            # Histórico de versões (importante para todas as audiências)
            if program.get('version_history'):
                section.append("**Histórico de Versões:**")
                for version in program['version_history']:
                    section.append(f"- **v{version['version']}** ({version['date']}) por {version['author']}: {version['description']}")
                section.append("")
            
            # Análise IA se disponível
            if program.get('ai_analysis'):
                ai_analysis = program['ai_analysis']
                if any(ai_analysis.values()):
                    section.append("**Análise Inteligente:**")
                    
                    if ai_analysis.get('structural', {}).get('success'):
                        section.append("- Análise estrutural: Concluída")
                    if ai_analysis.get('business', {}).get('success'):
                        section.append("- Análise de negócio: Concluída")
                    if ai_analysis.get('technical', {}).get('success'):
                        section.append("- Análise técnica: Concluída")
                    if ai_analysis.get('quality', {}).get('success'):
                        section.append("- Análise de qualidade: Concluída")
                    
                    section.append("")
            
            section.append("---")
            section.append("")
        
        return section
    
    def _generate_copybooks_section(self, content: Dict, audience: str) -> List[str]:
        """Gera seção de copybooks."""
        
        copybooks = content.get('copybooks', [])
        if not copybooks:
            return []
        
        section = ["## Estruturas de Dados (Copybooks)", ""]
        
        for i, copybook in enumerate(copybooks, 1):
            section.append(f"### {i}. {copybook['name']}")
            section.append("")
            
            if copybook.get('description'):
                section.append(f"**Descrição:** {copybook['description']}")
                section.append("")
            
            # Tabelas para audiência técnica
            if audience in ['technical', 'implementation'] and copybook.get('tables'):
                section.append("**Tabelas Definidas:**")
                for table in copybook['tables'][:5]:  # Limitar a 5
                    section.append(f"- `{table['name']}` (nível {table['level']})")
                if len(copybook['tables']) > 5:
                    section.append(f"- ... e mais {len(copybook['tables']) - 5} tabelas")
                section.append("")
            
            # Campos principais
            if copybook.get('fields'):
                section.append("**Campos Principais:**")
                field_count = 5 if audience == 'executive' else 10
                for field in copybook['fields'][:field_count]:
                    pic_info = f" PIC {field['pic']}" if field['pic'] else ""
                    section.append(f"- `{field['name']}` (nível {field['level']}){pic_info}")
                if len(copybook['fields']) > field_count:
                    section.append(f"- ... e mais {len(copybook['fields']) - field_count} campos")
                section.append("")
            
            section.append("---")
            section.append("")
        
        return section
    
    def _generate_technical_analysis(self, content: Dict, audience: str) -> List[str]:
        """Gera análise técnica consolidada."""
        
        if audience == 'executive':
            return []  # Executivos não precisam de detalhes técnicos
        
        tech_info = content.get('technical_info', {})
        section = ["## Análise Técnica Consolidada", ""]
        
        section.extend([
            "### Características do Sistema",
            "",
            f"**Linguagem:** COBOL (COBOL-85/2002/2014)",
            f"**Ambiente:** Mainframe IBM",
            f"**Domínio:** Sistema Bancário - Banco Central do Brasil",
            f"**Total de Programas:** {tech_info.get('total_programs', 0)}",
            f"**Total de Copybooks:** {tech_info.get('total_copybooks', 0)}",
            ""
        ])
        
        # Distribuição de arquivos
        file_types = tech_info.get('file_types', {})
        if any(file_types.values()):
            section.extend([
                "### Distribuição de Arquivos",
                "",
                f"- **Arquivos de Entrada:** {file_types.get('input', 0)}",
                f"- **Arquivos de Saída:** {file_types.get('output', 0)}",
                f"- **Arquivos de Trabalho:** {file_types.get('work', 0)}",
                ""
            ])
        
        # Indicadores de complexidade
        complexity = tech_info.get('complexity_indicators', {})
        if any(complexity.values()):
            section.extend([
                "### Indicadores de Complexidade",
                "",
                f"- **Programas com Histórico de Versões:** {complexity.get('has_version_history', 0)}",
                f"- **Programas com Múltiplos Arquivos:** {complexity.get('has_multiple_files', 0)}",
                f"- **Programas com Procedures:** {complexity.get('has_procedures', 0)}",
                ""
            ])
        
        return section
    
    def _generate_business_rules_section(self, content: Dict, audience: str) -> List[str]:
        """Gera seção de regras de negócio."""
        
        business_rules = content.get('business_rules', [])
        if not business_rules:
            return []
        
        section = ["## Regras de Negócio Identificadas", ""]
        
        # Agrupar por tipo
        objectives = [rule for rule in business_rules if rule.get('type') == 'objective']
        logic_rules = [rule for rule in business_rules if rule.get('type') == 'business_logic']
        
        if objectives:
            section.extend(["### Objetivos dos Sistemas", ""])
            for rule in objectives:
                section.append(f"**{rule['source']}:** {rule['description']}")
                section.append("")
        
        if logic_rules and audience in ['business', 'technical', 'implementation']:
            section.extend(["### Lógica de Negócio", ""])
            for rule in logic_rules[:10]:  # Limitar a 10
                section.append(f"- {rule['description']} *(Fonte: {rule['source']})*")
            if len(logic_rules) > 10:
                section.append(f"- ... e mais {len(logic_rules) - 10} regras identificadas")
            section.append("")
        
        return section
    
    def _generate_recommendations(self, content: Dict, audience: str) -> List[str]:
        """Gera recomendações por audiência."""
        
        programs_count = len(content.get('programs', []))
        has_version_history = any(p.get('version_history') for p in content.get('programs', []))
        
        section = ["## Recomendações", ""]
        
        if audience == 'executive':
            section.extend([
                "### Estratégia de Modernização",
                "",
                "1. **Abordagem Gradual:** Migração por módulos funcionais para reduzir riscos",
                "2. **Preservação de Investimento:** Manter lógica de negócio validada ao longo dos anos",
                "3. **Compliance BACEN:** Garantir conformidade com regulamentações bancárias",
                f"4. **Escopo Controlado:** {programs_count} programas identificados para modernização",
                "5. **ROI Previsível:** Documentação detalhada permite estimativas precisas",
                ""
            ])
            
        elif audience == 'technical':
            section.extend([
                "### Recomendações Técnicas",
                "",
                "1. **Análise de Dependências:** Mapear relacionamentos entre programas e copybooks",
                "2. **Testes Abrangentes:** Validar cálculos e processamentos críticos do BACEN",
                "3. **Migração de Dados:** Preservar estruturas de dados complexas identificadas",
                "4. **Performance:** Otimizar processamento de arquivos grandes (particionamento)",
                "5. **Integração:** Planejar interfaces com sistemas modernos",
                ""
            ])
            
        elif audience == 'business':
            section.extend([
                "### Recomendações de Negócio",
                "",
                "1. **Continuidade Operacional:** Manter funcionalidades críticas do BACEN",
                "2. **Validação de Regras:** Confirmar regras de negócio com especialistas",
                "3. **Treinamento:** Capacitar equipe nas novas tecnologias",
                "4. **Documentação:** Expandir documentação de processos específicos",
                "5. **Compliance:** Validar conformidade regulatória pós-migração",
                ""
            ])
            
        else:  # implementation
            section.extend([
                "### Guia de Implementação",
                "",
                "1. **Fase 1:** Análise detalhada de dependências e interfaces",
                "2. **Fase 2:** Migração de copybooks e estruturas de dados",
                "3. **Fase 3:** Conversão de programas por ordem de complexidade",
                "4. **Fase 4:** Testes integrados e validação de resultados",
                "5. **Fase 5:** Deploy gradual com rollback planejado",
                "",
                f"**Vantagem:** {'Histórico de versões disponível' if has_version_history else 'Documentação interna rica'} facilita a migração",
                ""
            ])
        
        return section
    
    def _generate_footer(self, content: Dict) -> List[str]:
        """Gera rodapé da documentação."""
        
        ai_available = content.get('ai_enhancement', {}).get('available', False)
        analysis_method = content.get('ai_enhancement', {}).get('analysis_method', 'real_content_only')
        
        footer = [
            "---",
            "",
            f"*Documentação gerada pelo Sistema de Análise COBOL v1.0.0*",
            f"*Método: {analysis_method.replace('_', ' ').title()}*",
            f"*Qualidade: {content.get('summary', {}).get('content_quality', 'high').title()} (baseado em conteúdo real)*",
            ""
        ]
        
        if ai_available:
            confidence = content.get('ai_enhancement', {}).get('confidence', 0)
            footer.insert(-1, f"*Confiança da Análise IA: {confidence:.1%}*")
        
        return footer


    def _generate_copybooks_section(self, content: Dict, audience: str) -> List[str]:
        """Gera a seção de copybooks da documentação."""
        
        copybooks = content.get('copybooks', [])
        if not copybooks:
            return []

        section = [
            "## Copybooks Utilizados",
            ""
        ]

        for copybook in copybooks:
            section.append(f"### {copybook.get('name', 'N/A')}")
            section.append("```cobol")
            section.append(copybook.get('code', ''))
            section.append("```")
            section.append("")

        return section


    def _generate_detailed_code_analysis(self, content: Dict, audience: str) -> List[str]:
        """Gera análise detalhada do código COBOL."""
        
        programs = content.get('programs', [])
        if not programs:
            return []

        section = [
            "## Análise Detalhada do Código",
            ""
        ]

        for program in programs:
            program_name = program.get('name', 'N/A')
            program_code = program.get('code', '')
            
            section.append(f"### {program_name}")
            section.append("")
            
            # Análise de divisões
            divisions = self._analyze_cobol_divisions(program_code)
            if divisions:
                section.append("#### Divisões Identificadas")
                for division, info in divisions.items():
                    section.append(f"- **{division.upper()}**: {info.get('lines', 0)} linhas")
                section.append("")
            
            # Análise de seções
            sections = self._analyze_cobol_sections(program_code)
            if sections:
                section.append("#### Seções Principais")
                for sect_name, sect_info in sections.items():
                    section.append(f"- **{sect_name}**: {sect_info.get('lines', 0)} linhas")
                section.append("")
            
            # Análise de variáveis
            variables = self._analyze_cobol_variables(program_code)
            if variables:
                section.append("#### Variáveis Principais")
                for var in variables[:10]:  # Mostrar apenas as 10 primeiras
                    section.append(f"- `{var.get('name', 'N/A')}`: {var.get('type', 'N/A')} - {var.get('description', 'Sem descrição')}")
                section.append("")
            
            # Análise de arquivos
            files = self._analyze_cobol_files(program_code)
            if files:
                section.append("#### Arquivos Utilizados")
                for file_info in files:
                    section.append(f"- **{file_info.get('name', 'N/A')}**: {file_info.get('type', 'N/A')} - {file_info.get('description', 'Sem descrição')}")
                section.append("")

        return section

    def _generate_data_structure_section(self, content: Dict, audience: str) -> List[str]:
        """Gera seção de estrutura de dados."""
        
        programs = content.get('programs', [])
        if not programs:
            return []

        section = [
            "## Estrutura de Dados",
            ""
        ]

        for program in programs:
            program_name = program.get('name', 'N/A')
            program_code = program.get('code', '')
            
            section.append(f"### {program_name}")
            section.append("")
            
            # Registros de arquivo
            file_records = self._extract_file_records(program_code)
            if file_records:
                section.append("#### Registros de Arquivo")
                for record in file_records:
                    section.append(f"**{record.get('name', 'N/A')}**")
                    section.append("```cobol")
                    section.append(record.get('definition', ''))
                    section.append("```")
                    section.append("")
            
            # Working Storage
            working_storage = self._extract_working_storage(program_code)
            if working_storage:
                section.append("#### Working Storage")
                for ws_item in working_storage[:5]:  # Mostrar apenas os 5 primeiros
                    section.append(f"- `{ws_item.get('name', 'N/A')}`: {ws_item.get('definition', 'N/A')}")
                section.append("")

        return section

    def _generate_processing_flow_section(self, content: Dict, audience: str) -> List[str]:
        """Gera seção de fluxo de processamento."""
        
        programs = content.get('programs', [])
        if not programs:
            return []

        section = [
            "## Fluxo de Processamento",
            ""
        ]

        for program in programs:
            program_name = program.get('name', 'N/A')
            program_code = program.get('code', '')
            
            section.append(f"### {program_name}")
            section.append("")
            
            # Procedimentos principais
            procedures = self._extract_procedures(program_code)
            if procedures:
                section.append("#### Procedimentos Identificados")
                for i, proc in enumerate(procedures[:10], 1):  # Mostrar apenas os 10 primeiros
                    section.append(f"{i}. **{proc.get('name', 'N/A')}**")
                    if proc.get('description'):
                        section.append(f"   - {proc.get('description')}")
                section.append("")
            
            # Performs
            performs = self._extract_performs(program_code)
            if performs:
                section.append("#### Chamadas PERFORM")
                for perform in performs[:5]:  # Mostrar apenas as 5 primeiras
                    section.append(f"- `{perform}`")
                section.append("")

        return section

    def _analyze_cobol_divisions(self, code: str) -> Dict[str, Dict]:
        """Analisa as divisões do programa COBOL."""
        divisions = {}
        lines = code.split('\n')
        
        for i, line in enumerate(lines):
            line_upper = line.upper().strip()
            if 'DIVISION' in line_upper:
                if 'IDENTIFICATION' in line_upper:
                    divisions['identification'] = {'lines': 0, 'start': i}
                elif 'ENVIRONMENT' in line_upper:
                    divisions['environment'] = {'lines': 0, 'start': i}
                elif 'DATA' in line_upper:
                    divisions['data'] = {'lines': 0, 'start': i}
                elif 'PROCEDURE' in line_upper:
                    divisions['procedure'] = {'lines': 0, 'start': i}
        
        # Calcular número de linhas para cada divisão
        division_names = list(divisions.keys())
        for i, div_name in enumerate(division_names):
            start = divisions[div_name]['start']
            end = divisions[division_names[i + 1]]['start'] if i + 1 < len(division_names) else len(lines)
            divisions[div_name]['lines'] = end - start
        
        return divisions

    def _analyze_cobol_sections(self, code: str) -> Dict[str, Dict]:
        """Analisa as seções do programa COBOL."""
        sections = {}
        lines = code.split('\n')
        
        for i, line in enumerate(lines):
            line_upper = line.upper().strip()
            if 'SECTION' in line_upper and not line_upper.startswith('*'):
                section_name = line_upper.replace('SECTION', '').replace('.', '').strip()
                if section_name:
                    sections[section_name] = {'lines': 10, 'start': i}  # Estimativa
        
        return sections

    def _analyze_cobol_variables(self, code: str) -> List[Dict]:
        """Analisa as variáveis do programa COBOL."""
        variables = []
        lines = code.split('\n')
        
        in_working_storage = False
        for line in lines:
            line_upper = line.upper().strip()
            
            if 'WORKING-STORAGE SECTION' in line_upper:
                in_working_storage = True
                continue
            elif 'PROCEDURE DIVISION' in line_upper:
                in_working_storage = False
                break
            
            if in_working_storage and line.strip() and not line.strip().startswith('*'):
                # Tentar extrair definição de variável
                if 'PIC' in line_upper or 'PICTURE' in line_upper:
                    parts = line.split()
                    if len(parts) >= 2:
                        var_name = parts[1] if parts[0].isdigit() else parts[0]
                        var_type = 'PIC ' + ' '.join([p for p in parts if 'PIC' in p.upper() or any(c in p for c in 'X9VA()')])
                        variables.append({
                            'name': var_name,
                            'type': var_type,
                            'description': 'Variável de trabalho'
                        })
        
        return variables

    def _analyze_cobol_files(self, code: str) -> List[Dict]:
        """Analisa os arquivos utilizados no programa COBOL."""
        files = []
        lines = code.split('\n')
        
        for line in lines:
            line_upper = line.upper().strip()
            if 'SELECT' in line_upper and 'ASSIGN' in line_upper:
                parts = line_upper.split()
                try:
                    select_idx = parts.index('SELECT')
                    assign_idx = parts.index('ASSIGN')
                    
                    if select_idx + 1 < len(parts):
                        file_name = parts[select_idx + 1]
                        file_path = ' '.join(parts[assign_idx + 2:]) if assign_idx + 2 < len(parts) else 'N/A'
                        
                        files.append({
                            'name': file_name,
                            'type': 'Arquivo de dados',
                            'description': f'Atribuído a {file_path}'
                        })
                except ValueError:
                    continue
        
        return files

    def _extract_file_records(self, code: str) -> List[Dict]:
        """Extrai registros de arquivo do código COBOL."""
        records = []
        lines = code.split('\n')
        
        current_record = None
        record_lines = []
        
        for line in lines:
            line_stripped = line.strip()
            if line_stripped.startswith('FD '):
                if current_record:
                    records.append({
                        'name': current_record,
                        'definition': '\n'.join(record_lines)
                    })
                current_record = line_stripped.replace('FD ', '').replace('.', '').strip()
                record_lines = [line]
            elif current_record and (line_stripped.startswith('01 ') or line_stripped.startswith('05 ') or line_stripped.startswith('10 ')):
                record_lines.append(line)
            elif current_record and line_stripped.startswith('PROCEDURE DIVISION'):
                records.append({
                    'name': current_record,
                    'definition': '\n'.join(record_lines)
                })
                break
        
        return records

    def _extract_working_storage(self, code: str) -> List[Dict]:
        """Extrai itens do Working Storage."""
        items = []
        lines = code.split('\n')
        
        in_working_storage = False
        for line in lines:
            line_upper = line.upper().strip()
            
            if 'WORKING-STORAGE SECTION' in line_upper:
                in_working_storage = True
                continue
            elif 'PROCEDURE DIVISION' in line_upper:
                break
            
            if in_working_storage and line.strip().startswith('01 '):
                parts = line.split()
                if len(parts) >= 2:
                    items.append({
                        'name': parts[1],
                        'definition': line.strip()
                    })
        
        return items

    def _extract_procedures(self, code: str) -> List[Dict]:
        """Extrai procedimentos do código COBOL."""
        procedures = []
        lines = code.split('\n')
        
        for i, line in enumerate(lines):
            line_stripped = line.strip()
            # Procurar por labels de procedimento (terminam com .)
            if (line_stripped and 
                not line_stripped.startswith('*') and 
                line_stripped.endswith('.') and 
                not any(keyword in line_stripped.upper() for keyword in ['DIVISION', 'SECTION', 'PIC', 'PICTURE', 'VALUE'])):
                
                proc_name = line_stripped[:-1]  # Remove o ponto final
                description = ''
                
                # Tentar encontrar comentário na linha seguinte
                if i + 1 < len(lines):
                    next_line = lines[i + 1].strip()
                    if next_line.startswith('*'):
                        description = next_line[1:].strip()
                
                procedures.append({
                    'name': proc_name,
                    'description': description
                })
        
        return procedures

    def _extract_performs(self, code: str) -> List[str]:
        """Extrai chamadas PERFORM do código."""
        performs = []
        lines = code.split('\n')
        
        for line in lines:
            line_upper = line.upper().strip()
            if 'PERFORM' in line_upper and not line_upper.startswith('*'):
                # Extrair o nome do procedimento após PERFORM
                parts = line_upper.split()
                try:
                    perform_idx = next(i for i, part in enumerate(parts) if 'PERFORM' in part)
                    if perform_idx + 1 < len(parts):
                        target = parts[perform_idx + 1]
                        if target not in ['UNTIL', 'VARYING', 'TIMES']:
                            performs.append(target)
                except (StopIteration, IndexError):
                    continue
        
        return list(set(performs))  # Remove duplicatas
