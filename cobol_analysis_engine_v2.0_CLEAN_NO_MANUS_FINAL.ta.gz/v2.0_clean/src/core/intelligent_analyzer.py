"""
Analisador inteligente que divide prompts grandes e consolida resultados
"""

import asyncio
import time
from typing import Dict, Any, List, Optional
from .smart_prompt_splitter import SmartPromptSplitter
from ..providers.luzia_provider import LuziaProvider
from ..providers.provider_manager import ProviderManager

class IntelligentAnalyzer:
    """Analisador que divide prompts grandes e consolida resultados"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.splitter = SmartPromptSplitter(max_tokens_per_prompt=3000)
        self.provider_manager = ProviderManager(config)
        self.prompt_history = []
        
    async def analyze_cobol_program_intelligent(
        self, 
        program_name: str, 
        cobol_code: str, 
        copybooks: Dict = None
    ) -> Dict[str, Any]:
        """Analisa programa COBOL dividindo em partes menores se necessário"""
        
        start_time = time.time()
        
        # 1. Dividir programa em seções lógicas
        sections = self.splitter.split_cobol_program(cobol_code, program_name)
        
        # 2. Criar prompts específicos para cada seção
        analysis_prompts = self.splitter.create_analysis_prompts(sections, copybooks)
        
        # 3. Executar análises em paralelo (limitado)
        analysis_results = []
        
        # Processar em lotes de 3 para não sobrecarregar
        batch_size = 3
        for i in range(0, len(analysis_prompts), batch_size):
            batch = analysis_prompts[i:i + batch_size]
            batch_results = await self._process_prompt_batch(batch, program_name)
            analysis_results.extend(batch_results)
        
        # 4. Consolidar resultados
        consolidated_analysis = self.splitter.consolidate_analysis_results(analysis_results)
        
        # 5. Preparar resultado final
        total_time = time.time() - start_time
        
        return {
            'analysis_result': consolidated_analysis,
            'prompt_history': self.prompt_history,
            'sections_analyzed': len(sections),
            'total_prompts': len(analysis_prompts),
            'processing_time': total_time,
            'success': True
        }
    
    async def _process_prompt_batch(self, prompts: List[Dict[str, Any]], program_name: str) -> List[Dict[str, Any]]:
        """Processa um lote de prompts em paralelo"""
        
        tasks = []
        for prompt_data in prompts:
            task = self._analyze_single_section(prompt_data, program_name)
            tasks.append(task)
        
        # Executar em paralelo com timeout
        try:
            results = await asyncio.wait_for(
                asyncio.gather(*tasks, return_exceptions=True),
                timeout=180.0  # 3 minutos timeout total
            )
            
            # Filtrar resultados válidos
            valid_results = []
            for i, result in enumerate(results):
                if isinstance(result, Exception):
                    print(f"⚠️ Erro na análise da seção {prompts[i]['section_title']}: {result}")
                    continue
                
                if result and result.get('success'):
                    valid_results.append(result)
            
            return valid_results
            
        except asyncio.TimeoutError:
            print("⚠️ Timeout na análise - processando sequencialmente")
            return await self._process_prompts_sequentially(prompts, program_name)
    
    async def _process_prompts_sequentially(self, prompts: List[Dict[str, Any]], program_name: str) -> List[Dict[str, Any]]:
        """Processa prompts sequencialmente como fallback"""
        
        results = []
        for prompt_data in prompts:
            try:
                result = await self._analyze_single_section(prompt_data, program_name)
                if result and result.get('success'):
                    results.append(result)
            except Exception as e:
                print(f"⚠️ Erro na seção {prompt_data['section_title']}: {e}")
                continue
        
        return results
    
    async def _analyze_single_section(self, prompt_data: Dict[str, Any], program_name: str) -> Dict[str, Any]:
        """Analisa uma seção específica do programa"""
        
        section_type = prompt_data['section_type']
        section_title = prompt_data['section_title']
        prompt = prompt_data['prompt']
        
        # Registrar prompt
        prompt_entry = {
            'section': section_title,
            'prompt': prompt,
            'timestamp': time.time(),
            'provider': 'LUZIA',
            'model': 'azure-gpt-4o-mini'
        }
        
        try:
            # Tentar usar LuzIA primeiro
            provider = self.provider_manager.get_provider('luzia')
            if provider and hasattr(provider, 'analyze_async'):
                response = await provider.analyze_async(prompt)
                
                if response and response.success:
                    # Parsear resposta baseada no tipo de seção
                    parsed_analysis = self._parse_section_response(
                        response.content, 
                        section_type
                    )
                    
                    prompt_entry.update({
                        'response': response.content,
                        'success': True,
                        'tokens_used': getattr(response, 'tokens_used', 0),
                        'processing_time': getattr(response, 'processing_time', 0)
                    })
                    
                    self.prompt_history.append(prompt_entry)
                    
                    return {
                        'section_type': section_type,
                        'section_title': section_title,
                        'analysis': parsed_analysis,
                        'success': True,
                        'priority': prompt_data.get('priority', 999)
                    }
            
            # Fallback para análise básica se LuzIA falhar
            basic_analysis = self._create_basic_analysis(prompt, section_type)
            
            prompt_entry.update({
                'response': 'Análise básica (LuzIA indisponível)',
                'success': False,
                'error': 'Provider não disponível'
            })
            
            self.prompt_history.append(prompt_entry)
            
            return {
                'section_type': section_type,
                'section_title': section_title,
                'analysis': basic_analysis,
                'success': True,
                'priority': prompt_data.get('priority', 999)
            }
            
        except Exception as e:
            prompt_entry.update({
                'response': f'Erro: {str(e)}',
                'success': False,
                'error': str(e)
            })
            
            self.prompt_history.append(prompt_entry)
            
            # Retornar análise básica mesmo com erro
            basic_analysis = self._create_basic_analysis(prompt, section_type)
            
            return {
                'section_type': section_type,
                'section_title': section_title,
                'analysis': basic_analysis,
                'success': False,
                'priority': prompt_data.get('priority', 999)
            }
    
    def _parse_section_response(self, response_text: str, section_type: str) -> Dict[str, Any]:
        """Parseia resposta da IA baseada no tipo de seção"""
        
        if section_type == 'comments_and_objective':
            return self._parse_objective_response(response_text)
        elif section_type == 'data_structures':
            return self._parse_data_response(response_text)
        elif section_type == 'business_logic':
            return self._parse_logic_response(response_text)
        else:
            return {'raw_response': response_text}
    
    def _parse_objective_response(self, response: str) -> Dict[str, Any]:
        """Parseia resposta sobre objetivo e comentários"""
        
        lines = response.split('\n')
        result = {
            'objective': "",
            'business_rules': [],
            'particularities': []
        }
        
        current_section = None
        
        for line in lines:
            line = line.strip()
            if 'OBJETIVO PRINCIPAL' in line.upper():
                current_section = 'objective'
            elif 'REGRAS DE NEGÓCIO' in line.upper():
                current_section = 'business_rules'
            elif 'PARTICULARIDADES' in line.upper():
                current_section = 'particularities'
            elif line and current_section:
                if current_section == 'objective':
                    result['objective'] += line + " "
                elif line.startswith('-') or line.startswith('•'):
                    item = line.lstrip('-•').strip()
                    if item:
                        result[current_section].append(item)
        
        result['objective'] = result['objective'].strip()
        return result
    
    def _parse_data_response(self, response: str) -> Dict[str, Any]:
        """Parseia resposta sobre estruturas de dados"""
        
        lines = response.split('\n')
        result = {
            'main_files': [],
            'important_fields': [],
            'control_structures': []
        }
        
        current_section = None
        
        for line in lines:
            line = line.strip()
            if 'ARQUIVOS PRINCIPAIS' in line.upper():
                current_section = 'main_files'
            elif 'CAMPOS IMPORTANTES' in line.upper():
                current_section = 'important_fields'
            elif 'ESTRUTURAS DE CONTROLE' in line.upper():
                current_section = 'control_structures'
            elif line and current_section and (line.startswith('-') or line.startswith('•')):
                item = line.lstrip('-•').strip()
                if item:
                    result[current_section].append(item)
        
        return result
    
    def _parse_logic_response(self, response: str) -> Dict[str, Any]:
        """Parseia resposta sobre lógica de negócio"""
        
        lines = response.split('\n')
        result = {
            'main_flow': [],
            'validations': [],
            'processing': []
        }
        
        current_section = None
        
        for line in lines:
            line = line.strip()
            if 'FLUXO PRINCIPAL' in line.upper():
                current_section = 'main_flow'
            elif 'VALIDAÇÕES' in line.upper():
                current_section = 'validations'
            elif 'PROCESSAMENTO' in line.upper():
                current_section = 'processing'
            elif line and current_section and (line.startswith('-') or line.startswith('•')):
                item = line.lstrip('-•').strip()
                if item:
                    result[current_section].append(item)
        
        return result
    
    def _create_basic_analysis(self, prompt: str, section_type: str) -> Dict[str, Any]:
        """Cria análise básica quando IA não está disponível"""
        
        if section_type == 'comments_and_objective':
            return {
                'objective': "Análise de objetivo não disponível (IA indisponível)",
                'business_rules': ["Análise de regras requer IA"],
                'particularities': ["Análise de particularidades requer IA"]
            }
        elif section_type == 'data_structures':
            return {
                'main_files': ["Análise de arquivos requer IA"],
                'important_fields': ["Análise de campos requer IA"],
                'control_structures': ["Análise de estruturas requer IA"]
            }
        elif section_type == 'business_logic':
            return {
                'main_flow': ["Análise de fluxo requer IA"],
                'validations': ["Análise de validações requer IA"],
                'processing': ["Análise de processamento requer IA"]
            }
        else:
            return {'raw_analysis': "Análise básica não disponível"}
