import requests
import json

# Configuração da LuzIA
CLIENT_ID = "VISITOR-CHAT-FLOW-SALE-7d7e6f1156"
CLIENT_SECRET = "gd1vGfGFWRJAQgdGhJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmnopqrstuvwxyz"
API_ENDPOINT = "https://luzia.com.br/api/v1/chat/send"

def get_token():
    response = requests.post(
        "https://luzia.com.br/api/v1/auth/token",
        json={
            "grant_type": "client_credentials",
            "client_id": CLIENT_ID,
            "client_secret": CLIENT_SECRET
        }
    )
    return response.json().get("access_token")

def send_message(message, conversation_id=None):
    token = get_token()
    
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }
    
    payload = {
        "message": message,
        "conversation_id": conversation_id
    }
    
    response = requests.post(API_ENDPOINT, headers=headers, json=payload)
    return response.json()

# Teste
TOKEN = get_token()
print(f"Token: {TOKEN}")

response = send_message("Olá, como você está?")
print(f"Response: {response}")
