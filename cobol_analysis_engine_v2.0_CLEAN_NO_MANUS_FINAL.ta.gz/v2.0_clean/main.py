#!/usr/bin/env python3.11
# -*- coding: utf-8 -*-
"""
COBOL Analysis Engine v1.0 - Sistema Completo de Análise
Suporta análise individual de programas COBOL e processamento em lote de arquivos fontes.txt/BOOKS.txt
"""

import argparse
import asyncio
import logging
import time
import json
import os
import sys
from typing import Dict, Any, List
from pathlib import Path

# Adicionar o diretório src ao sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), 'src')))

# Tentativa de importação para o modo multi_ai
try:
    from core.enhanced_orchestrator import EnhancedMultiAIOrchestrator, ContextExtractor
    from core.simple_ai_analyzer import SimpleAIAnalyzer
    MULTI_AI_AVAILABLE = True
except ImportError as e:
    # Multi-IA não disponível, sistema funcionará no modo básico
    MultiAIOrchestrator = None
    SimpleAIAnalyzer = None
    MULTI_AI_AVAILABLE = False

# Importações principais
from extractors.content_extractor import COBOLContentExtractor
from generators.detailed_report_generator import DetailedReportGenerator
from utils.enhanced_logger import EnhancedAnalysisLogger
from config.config_loader import load_config

# Importações condicionais para funcionalidades extras
try:
    from core.cross_validator import CrossValidator
    CROSS_VALIDATOR_AVAILABLE = True
except ImportError:
    CrossValidator = None
    CROSS_VALIDATOR_AVAILABLE = False

try:
    from core.clarity_engine import ClarityEngine
    CLARITY_ENGINE_AVAILABLE = True
except ImportError:
    ClarityEngine = None
    CLARITY_ENGINE_AVAILABLE = False

# Importações para modo enhanced
try:
    from analyzers.business_logic_parser import COBOLBusinessLogicParser
    from analyzers.data_flow_analyzer import COBOLDataFlowAnalyzer
    from generators.functional_documentation_generator import FunctionalDocumentationGenerator
    from generators.simple_documentation_generator import SimpleDocumentationGenerator
    ENHANCED_MODE_AVAILABLE = True
except ImportError:
    COBOLBusinessLogicParser = None
    COBOLDataFlowAnalyzer = None
    FunctionalDocumentationGenerator = None
    ENHANCED_MODE_AVAILABLE = False

class COBOLAnalysisSystem:
    """Sistema principal de análise COBOL com suporte a processamento individual e em lote."""
    
    def __init__(self, config_path="config/config.yaml"):
        """Inicializa o sistema de análise."""
        self.config = load_config(config_path)
        self.content_extractor = COBOLContentExtractor()
        self.detailed_report_gen = DetailedReportGenerator()
        self.enhanced_logger = EnhancedAnalysisLogger(self.config)
        
        # Inicializar componentes opcionais
        if MULTI_AI_AVAILABLE:
            self.orchestrator = EnhancedMultiAIOrchestrator(self.config)
            self.simple_analyzer = SimpleAIAnalyzer(self.config)
        else:
            self.orchestrator = None
            self.simple_analyzer = None
        if ENHANCED_MODE_AVAILABLE:
            self.business_logic_parser = COBOLBusinessLogicParser()
            self.data_flow_analyzer = COBOLDataFlowAnalyzer()
            self.functional_generator = FunctionalDocumentationGenerator()
            self.simple_generator = SimpleDocumentationGenerator()
            
            # Importar analisador unificado
            try:
                from src.core.unified_analyzer import UnifiedAnalyzer
                from src.generators.clean_documentation_generator import CleanDocumentationGenerator
                self.unified_analyzer = UnifiedAnalyzer(self.config)
                self.clean_generator = CleanDocumentationGenerator()
            except ImportError:
                self.unified_analyzer = None
                self.clean_generator = None
                
            if MULTI_AI_AVAILABLE:
                self.functional_generator.prompt_logger = self.orchestrator.get_prompt_logger()
        
        if CROSS_VALIDATOR_AVAILABLE:
            self.cross_validator = CrossValidator(self.config)
        
        if CLARITY_ENGINE_AVAILABLE:
            self.clarity_engine = ClarityEngine(self.config)
        
        # Inicializar componentes enhanced
        if ENHANCED_MODE_AVAILABLE:
            self.business_logic_parser = COBOLBusinessLogicParser()
            self.data_flow_analyzer = COBOLDataFlowAnalyzer()
            self.functional_generator = FunctionalDocumentationGenerator()
    
    def detect_file_type(self, file_path):
        """Detecta o tipo de arquivo baseado no conteúdo."""
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                first_lines = [f.readline().strip() for _ in range(5)]
            
            # Verificar se é arquivo fontes.txt
            if any('VMEMBER NAME' in line or 'MEMBER NAME' in line for line in first_lines):
                return 'fontes'
            
            # Verificar se é arquivo COBOL individual
            cobol_keywords = ['IDENTIFICATION DIVISION', 'PROGRAM-ID', 'ENVIRONMENT DIVISION']
            if any(keyword in ' '.join(first_lines).upper() for keyword in cobol_keywords):
                return 'cobol'
            
            # Verificar se é arquivo BOOKS.txt
            if any('BOOK' in line or 'COPY' in line for line in first_lines):
                return 'books'
            
            return 'unknown'
        except Exception:
            return 'unknown'
    
    def extract_programs_from_fontes(self, fontes_path):
        """Extrai programas individuais do arquivo fontes.txt"""
        programs = []
        current_program = None
        current_lines = []
        
        with open(fontes_path, 'r', encoding='utf-8', errors='ignore') as f:
            for line in f:
                line = line.rstrip()
                
                # Detectar início de novo programa
                if 'VMEMBER NAME' in line or 'MEMBER NAME' in line:
                    if current_program and current_lines:
                        programs.append({
                            'name': current_program,
                            'content': '\n'.join(current_lines)
                        })
                    
                    # Extrair nome do programa
                    if 'VMEMBER NAME' in line:
                        # Formato: VMEMBER NAME  LHAN0542
                        parts = line.split('VMEMBER NAME')
                        if len(parts) > 1:
                            current_program = parts[1].strip()
                    elif 'MEMBER NAME' in line:
                        # Formato: MEMBER NAME  LHAN0542
                        parts = line.split('MEMBER NAME')
                        if len(parts) > 1:
                            current_program = parts[1].strip()
                    
                    current_lines = []
                
                # Adicionar linha ao programa atual
                if current_program:
                    # Remover prefixo 'V' se presente
                    clean_line = line[1:] if line.startswith('V') else line
                    current_lines.append(clean_line)
        
        # Adicionar último programa
        if current_program and current_lines:
            programs.append({
                'name': current_program,
                'content': '\n'.join(current_lines)
            })
        
        return programs
    
    def extract_copybooks_from_books(self, books_path):
        """Extrai copybooks do arquivo BOOKS.txt"""
        if not books_path or not os.path.exists(books_path):
            return {}
        
        copybooks = {}
        current_book = None
        current_lines = []
        
        with open(books_path, 'r', encoding='utf-8', errors='ignore') as f:
            for line in f:
                line = line.rstrip()
                
                # Detectar início de novo copybook
                if 'MEMBER NAME' in line or 'BOOK' in line:
                    if current_book and current_lines:
                        copybooks[current_book] = '\n'.join(current_lines)
                    
                    # Extrair nome do copybook
                    parts = line.split()
                    for i, part in enumerate(parts):
                        if part == 'NAME' and i + 1 < len(parts):
                            current_book = parts[i + 1].strip()
                            break
                    current_lines = []
                
                # Adicionar linha ao copybook atual
                if current_book:
                    current_lines.append(line)
        
        # Adicionar último copybook
        if current_book and current_lines:
            copybooks[current_book] = '\n'.join(current_lines)
        
        return copybooks
    
    async def analyze_single_program(self, file_path, output_dir, copybooks_path=None, mode='multi_ai'):
        """Analisa um único programa COBOL."""
        
        self.enhanced_logger.start_analysis(os.path.basename(file_path), "single")
        
        try:
            # Extrair dados do programa
            extracted_data = self.content_extractor.extract_from_file(file_path)
            
            # Inicializar copybooks
            copybooks = []
            
            # Processar copybooks se fornecido
            if copybooks_path and os.path.exists(copybooks_path):
                copybooks = self.extract_copybooks_from_file(copybooks_path)
                if copybooks:
                    extracted_data['copybooks'] = copybooks
                    print(f"Integrados {len(copybooks)} copybooks na análise")
            
            # Executar análise baseada no modo
            if ENHANCED_MODE_AVAILABLE and mode == 'enhanced' and hasattr(self, 'unified_analyzer') and self.unified_analyzer:
                # Modo enhanced - usar direct_analyzer
                program_name = os.path.splitext(os.path.basename(file_path))[0]
                report_path = os.path.join(output_dir, f"{program_name}_ENHANCED_ANALYSIS.md")
                
                print(" Iniciando análise contextualizada para", program_name)
                
                # Executar análise unificada com retry e estatísticas
                analysis_result = await self.unified_analyzer.analyze_cobol_program_unified(
                    program_name=program_name,
                    cobol_code=extracted_data.get('content', ''),
                    copybooks=copybooks
                )
                
                # Preparar dados para o gerador
                ai_analyses = {'main_analysis': analysis_result.get('analysis_result', {})}
                prompt_history = analysis_result.get('prompt_history', [])
                
                # Preparar dados extraídos dos arquivos
                file_extracted_data = {
                    'program_name': program_name,
                    'comments': extracted_data.get('comments', {}),
                    'structure': extracted_data.get('structure', {}),
                    'copybooks': copybooks
                }
                
                # Usar gerador inteligente de alta qualidade
                from src.generators.intelligent_documentation_generator import IntelligentDocumentationGenerator
                intelligent_generator = IntelligentDocumentationGenerator()
                
                documentation = intelligent_generator.generate_documentation(
                    extracted_data=file_extracted_data,
                    ai_analyses=ai_analyses,
                    prompt_history=prompt_history,
                    statistics=self.unified_analyzer.stats,
                    output_path=report_path
                )
                
                # Documentação já salva pelo gerador
                
                self.enhanced_logger.finish_analysis("SUCESSO", report_path)
                return report_path
                
            elif MULTI_AI_AVAILABLE and mode == 'multi_ai':
                # Criar contexto de análise
                analysis_context = ContextExtractor.extract_from_fontes_batch([
                    {
                        'name': extracted_data.get('program_name', os.path.splitext(os.path.basename(file_path))[0]),
                        'content': extracted_data.get('content', '')
                    }
                ], copybooks)
                
                orchestration_result = await self.orchestrator.analyze_program_with_context(
                    cobol_code=extracted_data.get('content', ''),
                    context=analysis_context[0],
                    extracted_data=extracted_data
                )

                # Log dos resultados da orquestração
                for domain, result in orchestration_result.get('parallel_results', {}).items():
                    if hasattr(result, 'success'):
                        self.enhanced_logger.log_analysis_result(domain, {
                            'success': result.success,
                            'confidence': getattr(result, 'confidence', 0.0),
                            'analysis': getattr(result, 'analysis', {})
                        })
                
                # Validação cruzada
                if CROSS_VALIDATOR_AVAILABLE and len(orchestration_result.get('parallel_results', {})) > 1:
                    validation_result = await self.cross_validator.validate_analyses(
                        self._convert_results_for_validator(orchestration_result)
                    )
                    self.enhanced_logger.log_validation_results(validation_result)
                
                # Análise de clareza
                if CLARITY_ENGINE_AVAILABLE:
                    clarity_scores = self.clarity_engine.analyze_clarity(orchestration_result, "technical")
                    # Log da análise de clareza (método genérico)
                    self.enhanced_logger.log_analysis_result("clarity", {"scores": clarity_scores})
                
                # Gerar relatório
                program_name = os.path.splitext(os.path.basename(file_path))[0]
                
                # Converter parallel_results para o formato esperado pelo gerador
                analyses_data = {}
                for domain, result in orchestration_result.get('parallel_results', {}).items():
                    if hasattr(result, 'success') and result.success:
                        analyses_data[domain] = getattr(result, 'analysis', {})
                
                # Escolher gerador baseado no modo
                print(f"DEBUG: mode={mode}, ENHANCED_MODE_AVAILABLE={ENHANCED_MODE_AVAILABLE}, has_direct_analyzer={hasattr(self, 'direct_analyzer')}, direct_analyzer_not_none={getattr(self, 'direct_analyzer', None) is not None}")
                
                if mode == 'enhanced' and ENHANCED_MODE_AVAILABLE and hasattr(self, 'direct_analyzer') and self.direct_analyzer:
                    print("DEBUG: Entrando no modo enhanced!")
                    # Modo enhanced com análise direta e captura de prompts
                    report_path = os.path.join(output_dir, f"{program_name}_ENHANCED_ANALYSIS.md")
                    
                    # Executar análise com captura de prompts
                    analysis_result = await self.direct_analyzer.analyze_cobol_program(
                        program_name=program_name,
                        cobol_code=extracted_data.get('content', ''),
                        copybooks=copybooks
                    )
                    
                    # Preparar dados para o gerador
                    ai_analyses = {'main_analysis': analysis_result.get('analysis_result', {})}
                    prompt_history = analysis_result.get('prompt_history', [])
                    
                    documentation = self.simple_generator.generate_documentation(
                        program_name=program_name,
                        cobol_code=extracted_data.get('content', ''),
                        analysis_results=ai_analyses,
                        copybooks=copybooks,
                        prompt_history=prompt_history
                    )
                else:
                    # Modo multi_ai padrão
                    report_path = os.path.join(output_dir, f"{program_name}_MULTI_AI_ANALYSIS.md")
                    documentation = self.detailed_report_gen.generate(
                        extracted_data,
                        analyses_data
                    )
            else:
                # Modo tradicional
                program_name = os.path.splitext(os.path.basename(file_path))[0]
                report_path = os.path.join(output_dir, f"{program_name}_ANALYSIS.md")
                
                documentation = self.detailed_report_gen.generate(
                    extracted_data,
                    {}
                )
            
            # Salvar documentação
            print(f"Salvando documentação em: {report_path}")
            with open(report_path, 'w', encoding='utf-8') as f:
                f.write(documentation)
            
            self.enhanced_logger.finish_analysis(True, report_path)
            
            return {
                'status': 'success',
                'report_path': report_path,
                'program': os.path.basename(file_path)
            }
            
        except Exception as e:
            error_msg = f"Erro na análise: {str(e)}"
            print(f"Erro: {error_msg}")
            self.enhanced_logger.finish_analysis(False)
            return {
                'status': 'error',
                'error': error_msg,
                'program': os.path.basename(file_path)
            }
    
    async def analyze_batch(self, fontes_path, books_path, output_dir, mode='multi_ai'):
        """Processa múltiplos programas do arquivo fontes.txt"""
        
        self.enhanced_logger.start_analysis("batch_processing", "batch")
        
        # Extrair programas e copybooks
        programs = self.extract_programs_from_fontes(fontes_path)
        copybooks = self.extract_copybooks_from_books(books_path) if books_path else {}
        
        print(f"Encontrados {len(programs)} programas para análise")
        if copybooks:
            print(f"Encontrados {len(copybooks)} copybooks")
        
        results = []
        
        for i, program in enumerate(programs, 1):
            print(f"\n{'='*60}")
            print(f"Processando programa {i}/{len(programs)}: {program['name']}")
            print(f"{'='*60}")
            
            try:
                # Extrair dados do programa
                extracted_data = self.content_extractor.extract_from_content(
                    program['content'], 
                    program['name']
                )
                
                # Adicionar copybooks relevantes
                if copybooks:
                    extracted_data['copybooks'] = copybooks
                
                # Executar análise baseada no modo
                if ENHANCED_MODE_AVAILABLE and mode == 'enhanced' and hasattr(self, 'unified_analyzer') and self.unified_analyzer:
                    # Modo enhanced - usar intelligent_analyzer
                    report_path = os.path.join(output_dir, f"{program['name']}_ENHANCED_ANALYSIS.md")
                    
                    print(f" Iniciando análise contextualizada para {program['name']}")
                    
                    # Executar análise unificada com retry e estatísticas
                    analysis_result = await self.unified_analyzer.analyze_cobol_program_unified(
                        program_name=program['name'],
                        cobol_code=extracted_data.get('content', ''),
                        copybooks=copybooks
                    )               
                    # Preparar dados para o gerador
                    ai_analyses = {'main_analysis': analysis_result.get('analysis_result', {})}
                    prompt_history = analysis_result.get('prompt_history', [])
                    
                    # Usar gerador inteligente de alta qualidade
                    from src.generators.intelligent_documentation_generator import IntelligentDocumentationGenerator
                    intelligent_generator = IntelligentDocumentationGenerator()
                    
                    # Preparar dados para o gerador inteligente
                    file_extracted_data = {
                        'program_name': program['name'],
                        'content': extracted_data.get('content', ''),
                        'author': extracted_data.get('author', 'N/A'),
                        'date_written': extracted_data.get('date_written', 'N/A'),
                        'comments': extracted_data.get('comments', {}),
                        'structure': extracted_data.get('structure', {}),
                        'copybooks': copybooks
                    }
                    
                    documentation = intelligent_generator.generate_documentation(
                        extracted_data=file_extracted_data,
                        ai_analyses=ai_analyses,
                        prompt_history=prompt_history,
                        statistics=self.unified_analyzer.stats,
                        output_path=report_path
                    )
                    
                    results.append({
                        'name': program['name'],
                        'status': 'success',
                        'report_path': report_path
                    })
                    
                elif MULTI_AI_AVAILABLE and mode == 'multi_ai':
                    orchestration_result = await self.orchestrator.analyze_program(
                        cobol_code=extracted_data.get('content', ''),
                        copybooks=copybooks,
                        program_name=extracted_data.get('program_name', program['name']),
                        extracted_data=extracted_data
                    )
                    
                    # Converter parallel_results para o formato esperado pelo gerador
                    analyses_data = {}
                    for domain, result in orchestration_result.get('parallel_results', {}).items():
                        if hasattr(result, 'success') and result.success:
                            analyses_data[domain] = getattr(result, 'analysis', {})
                    
                    # Escolher gerador baseado no modo
                    if mode == 'enhanced' and ENHANCED_MODE_AVAILABLE and hasattr(self, 'direct_analyzer') and self.direct_analyzer:
                        # Modo enhanced com análise direta e captura de prompts
                        report_path = os.path.join(output_dir, f"{program['name']}_ENHANCED_ANALYSIS.md")
                        
                        # Executar análise com captura de prompts
                        analysis_result = await self.direct_analyzer.analyze_cobol_program(
                            program_name=program['name'],
                            cobol_code=extracted_data.get('content', ''),
                            copybooks=copybooks
                        )
                        
                        # Preparar dados para o gerador
                        ai_analyses = {'main_analysis': analysis_result.get('analysis_result', {})}
                        prompt_history = analysis_result.get('prompt_history', [])
                        
                        documentation = self.simple_generator.generate_documentation(
                            program_name=program['name'],
                            cobol_code=extracted_data.get('content', ''),
                            analysis_results=ai_analyses,
                            copybooks=copybooks,
                            prompt_history=prompt_history
                        )
                    else:
                        # Modo multi_ai padrão
                        report_path = os.path.join(output_dir, f"{program['name']}_MULTI_AI_ANALYSIS.md")
                        documentation = self.detailed_report_gen.generate(
                            extracted_data,
                            analyses_data
                        )
                else:
                    # Modo tradicional
                    report_path = os.path.join(output_dir, f"{program['name']}_ANALYSIS.md")
                    documentation = self.detailed_report_gen.generate(
                        extracted_data,
                        {}
                    )
                
                # Salvar relatório
                with open(report_path, 'w', encoding='utf-8') as f:
                    f.write(documentation)
                
                results.append({
                    'name': program['name'],
                    'status': 'success',
                    'report_path': report_path
                })
                
                print(f"✓ Análise concluída: {os.path.basename(report_path)}")
                
            except Exception as e:
                error_msg = f"Erro ao processar {program['name']}: {str(e)}"
                print(f"✗ {error_msg}")
                results.append({
                    'name': program['name'],
                    'status': 'error',
                    'error': error_msg
                })
        
        # Gerar relatório de resumo com estatísticas
        self.generate_batch_summary(results, output_dir)
        
        # Exibir estatísticas finais se unified_analyzer disponível
        if hasattr(self, 'unified_analyzer') and self.unified_analyzer:
            stats = self.unified_analyzer.get_final_statistics()
            self._display_final_statistics(stats, output_dir)
        
        self.enhanced_logger.finish_analysis(True, output_dir)
        
        return results
    
    def generate_batch_summary(self, results, output_dir):
        """Gera relatório de resumo do processamento em lote"""
        
        
        summary_path = os.path.join(output_dir, "BATCH_PROCESSING_SUMMARY.md")
        
        successful = [r for r in results if r['status'] == 'success']
        failed = [r for r in results if r['status'] == 'error']
        
        summary = f"""# Relatório de Processamento em Lote - COBOL Analysis Engine

**Data:** {time.strftime('%d/%m/%Y %H:%M:%S')}  
**Total de Programas:** {len(results)}  
**Sucessos:** {len(successful)}  
**Falhas:** {len(failed)}  
**Taxa de Sucesso:** {len(successful)/len(results)*100:.1f}%  

---

## Programas Processados com Sucesso

"""
        
        for result in successful:
            summary += f"- **{result['name']}** → `{os.path.basename(result['report_path'])}`\n"
        
        if failed:
            summary += f"\n## Programas com Falha\n\n"
            for result in failed:
                summary += f"- **{result['name']}**: {result['error']}\n"
        
        summary += f"\n---\n\n*Processamento concluído em {output_dir}*\n"
        
        with open(summary_path, 'w', encoding='utf-8') as f:
            f.write(summary)
        
        print(f"\\n Relatório de resumo salvo em: {summary_path}")
    
    def _display_final_statistics(self, stats: Dict[str, Any], output_dir: str):
        """Exibe estatísticas finais do processamento"""
        from src.utils.statistics_display import display_final_statistics
        display_final_statistics(stats, output_dir)
    
    def _convert_results_for_validator(self, orchestration_result):
        """Converte resultados para o formato esperado pelo validador."""
        converted = []
        analyses = orchestration_result.get('analyses', {})
        
        for domain, result in analyses.items():
            if hasattr(result, '__dict__'):
                result_dict = result.__dict__
            else:
                result_dict = result if isinstance(result, dict) else {}
            
            if result_dict.get('success', False):
                converted.append({
                    'domain': domain,
                    'content': result_dict.get('content', ''),
                    'confidence': result_dict.get('confidence', 0.5)
                })
        
        return converted

async def check_providers_status(config_path: str):
    """Verifica status e conectividade dos provedores de IA de forma robusta."""
    
    try:
        # Importar verificador simples
        import sys
        sys.path.insert(0, 'src')
        from utils.simple_status_checker import SimpleStatusChecker
        
        checker = SimpleStatusChecker()
        await checker.check_all_providers()
        
    except Exception as e:
        print(f" Verificando conectividade com provedores de IA...")
        print("=" * 60)
        print(f" Erro ao verificar status: {e}")
        print()
        print(" Verificação manual:")
        
        # Verificação básica manual
        import os
        
        # LuzIA
        if os.getenv("LUZIA_CLIENT_ID") and os.getenv("LUZIA_CLIENT_SECRET"):
            print(" LUZIA: Credenciais configuradas")
        else:
            print(" LUZIA: Credenciais não configuradas")
            print("   Configure: LUZIA_CLIENT_ID e LUZIA_CLIENT_SECRET")
        
        # OpenAI
        if os.getenv("OPENAI_API_KEY"):
            print(" OPENAI: API Key configurada")
        else:
            print(" OPENAI: API Key não configurada")
            print("   Configure: OPENAI_API_KEY")
        
        print()
        print("=" * 60)
        print(" Sistema sempre funcional no modo traditional")
        print(" Modos avançados requerem configuração de IA")

async def main():
    """Função principal do sistema."""
    
    parser = argparse.ArgumentParser(
        description='COBOL Analysis Engine v1.0 - Sistema Completo de Análise',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Exemplos de uso:

  # Análise de programa individual
  python3.11 main.py programa.cbl -o resultados/ -m multi_ai

  # Processamento em lote com fontes.txt
  python3.11 main.py fontes.txt -o resultados/ -b BOOKS.txt

  # Análise com copybooks
  python3.11 main.py programa.cbl -o resultados/ -b copybooks.txt -m multi_ai
        """
    )
    
    parser.add_argument('input_file', nargs='?',
                       help='Arquivo COBOL (.cbl) ou arquivo fontes.txt para processamento em lote')
    parser.add_argument('-o', '--output',
                       help='Diretório de saída para os relatórios')
    parser.add_argument('-b', '--books', 
                       help='Arquivo BOOKS.txt com copybooks (opcional)')
    parser.add_argument('-m', '--mode', choices=['multi_ai', 'traditional', 'enhanced'], 
                       default='multi_ai',
                       help='Modo de análise (padrão: multi_ai, enhanced=análise funcional completa)')
    parser.add_argument('-c', '--config', default='config/config.yaml',
                       help='Arquivo de configuração (padrão: config/config.yaml)')
    parser.add_argument('-v', '--verbose', action='store_true',
                       help='Saída detalhada')
    parser.add_argument('--status', action='store_true',
                       help='Verificar conectividade com provedores de IA')
    
    args = parser.parse_args()
    
    # Verificar status se solicitado
    if args.status:
        await check_providers_status(args.config)
        return
    
    # Verificar se o arquivo de entrada existe
    if not os.path.exists(args.input_file):
        print(f"Erro: Arquivo {args.input_file} não encontrado")
        sys.exit(1)
    
    # Criar diretório de saída
    os.makedirs(args.output, exist_ok=True)
    
    # Configurar logging
    if args.verbose:
        logging.basicConfig(level=logging.DEBUG)
    
    # Inicializar sistema
    try:
        system = COBOLAnalysisSystem(args.config)
    except Exception as e:
        print(f"Erro ao inicializar sistema: {e}")
        sys.exit(1)
    
    # Detectar tipo de arquivo e processar
    file_type = system.detect_file_type(args.input_file)
    
    start_time = time.time()
    
    if file_type == 'fontes':
        print(f" Detectado arquivo fontes.txt: {args.input_file}")
        print(f" Processamento em lote iniciado...")
        
        results = await system.analyze_batch(args.input_file, args.books, args.output, args.mode)
        
        successful = len([r for r in results if r['status'] == 'success'])
        total = len(results)
        
        print(f"\n Processamento em lote concluído!")
        print(f" {successful}/{total} programas processados com sucesso")
        
    elif file_type == 'cobol':
        print(f" Detectado programa COBOL: {args.input_file}")
        print(f" Análise individual iniciada...")
        
        result = await system.analyze_single_program(args.input_file, args.output, args.books, args.mode)
        
        if result:  # result é o caminho do arquivo gerado
            print(f"\n Análise concluída com sucesso!")
            print(f" Relatório: {os.path.basename(result)}")
            print(f" Tempo total: {time.time() - start_time:.2f}s")
            print(f" Resultados salvos em: {args.output}")
        else:
            print(f"\n Análise falhou")
            sys.exit(1)
    
    else:
        print(f" Tipo de arquivo não reconhecido: {args.input_file}")
        print("Tipos suportados: arquivos COBOL (.cbl) ou fontes.txt")
        sys.exit(1)
    
    elapsed_time = time.time() - start_time
    
    print(f" Tempo total: {elapsed_time:.2f}s")
    print(f" Resultados salvos em: {args.output}")

if __name__ == "__main__":
    asyncio.run(main())
