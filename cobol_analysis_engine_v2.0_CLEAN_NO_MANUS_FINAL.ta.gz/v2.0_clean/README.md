# COBOL Analysis Engine v2.0

Sistema inteligente de análise de código COBOL que explica **o que o programa faz**, **quais são as regras de negócio** e **se há particularidades importantes**.

## 🎯 O que faz

- **Explica o objetivo** de cada programa COBOL de forma clara
- **Identifica regras de negócio** importantes (validações, critérios, limites)
- **Detecta particularidades** que merecem atenção
- **Integra copybooks** para análise completa
- **Captura prompts e respostas** das IAs para transparência total

## 🚀 Uso Rápido

```bash
# 1. Instalar dependências
pip install -r requirements.txt

# 2. Configurar LuzIA (opcional - para análise com IA)
export LUZIA_CLIENT_ID="seu_client_id"
export LUZIA_CLIENT_SECRET="seu_client_secret"

# 3. Analisar um programa
python3.11 main.py examples/LHAN0542_TESTE.cbl

# 4. Análise em lote com copybooks
python3.11 main.py examples/fontes.txt -b examples/BOOKS.txt -o resultados/
```

## 📋 Modos de Análise

| Modo | Descrição | Tempo | Quando Usar |
|------|-----------|-------|-------------|
| **traditional** | Análise básica sem IA | ~0.01s | Estrutura rápida |
| **multi_ai** | Análise estrutural com IA | ~5-10s | Análise completa |
| **enhanced** | Análise funcional + captura de prompts | ~5-15s | Máxima transparência |

## 📁 Exemplos de Uso

### Análise Individual
```bash
# Análise básica
python3.11 main.py examples/LHAN0542_TESTE.cbl -m traditional

# Análise completa com IA
python3.11 main.py examples/LHAN0542_TESTE.cbl -m enhanced -o resultados/
```

### Processamento em Lote
```bash
# Múltiplos programas com copybooks
python3.11 main.py examples/fontes.txt -b examples/BOOKS.txt -o lote/ -m enhanced
```

### Verificar Status
```bash
# Testar conectividade com IAs
python3.11 main.py --status
```

## 📊 Exemplo de Saída

**Entrada:** Programa COBOL que particiona arquivos
**Saída:** Relatório explicativo

```markdown
## 🎯 O que este programa faz
Este programa particiona arquivos do BACEN DOC3040, dividindo-os em 
arquivos menores de até 50.000 registros cada.

## 📋 Regras de Negócio
1. **Limite de registros**: Máximo 50.000 por arquivo
2. **Validação de tipo**: Apenas tipos '01', '02', '03' são válidos
3. **Roteamento automático**: Tipos 01/02 → S1, Tipo 03 → S2

## ⚠️ Particularidades
- Usa particionamento dinâmico
- Requer validação cuidadosa dos tipos de registro
- Gera arquivos de controle automaticamente

## 🔍 Detalhes da Análise com IA
### ✅ Análise 1: Análise Principal
**Provedor:** LUZIA
**Modelo:** azure-gpt-4o-mini
**Tempo:** 2.45s

**📤 Prompt enviado:**
[Prompt completo enviado para a IA]

**📥 Resposta original do LUZIA:**
[Resposta completa recebida da IA]
```

## 🔧 Parâmetros Disponíveis

```bash
python3.11 main.py [arquivo] [opções]

Parâmetros:
  arquivo                 Arquivo .cbl ou fontes.txt
  -o, --output           Diretório de saída
  -b, --books            Arquivo BOOKS.txt com copybooks
  -m, --mode             Modo: traditional, multi_ai, enhanced
  -c, --config           Arquivo de configuração
  -v, --verbose          Saída detalhada
  --status               Testar conectividade
  --help                 Mostrar ajuda
```

## 📁 Estrutura do Projeto

```
v2.0_clean/
├── main.py                    # ← Aplicação principal
├── config/
│   ├── config.yaml           # ← Configuração das IAs
│   └── prompts.yaml          # ← Prompts configuráveis
├── src/                      # ← Código fonte
├── examples/
│   ├── fontes.txt           # ← Programas COBOL reais
│   ├── BOOKS.txt            # ← Copybooks reais
│   └── *.cbl                # ← Programas individuais
├── docs/                     # ← Documentação
└── requirements.txt          # ← Dependências
```

## 🔍 Casos de Uso

### 1. **Documentação de Sistema Legado**
- Analisa programas COBOL antigos
- Explica objetivo e funcionamento
- Identifica regras de negócio críticas

### 2. **Auditoria e Compliance**
- Documenta controles e validações
- Identifica pontos de atenção
- Facilita revisões de auditoria

### 3. **Migração de Sistemas**
- Entende lógica de negócio atual
- Mapeia regras para nova plataforma
- Reduz riscos de migração

### 4. **Treinamento de Equipe**
- Gera material didático sobre programas
- Explica funcionamento de forma clara
- Acelera curva de aprendizado

## 🚨 Solução de Problemas

### Sistema funciona mesmo com erros de importação
- **Modo traditional** sempre disponível
- **Análise básica** sem dependência de IA
- **Estrutura do programa** sempre extraída

### Configuração LuzIA opcional
- Sistema funciona sem credenciais
- Análise com IA requer configuração
- Modo enhanced precisa de conectividade

### Arquivos de exemplo incluídos
- `examples/fontes.txt` - 5 programas reais
- `examples/BOOKS.txt` - 11 copybooks
- Prontos para teste imediato

## 📈 Benefícios

✅ **Compreensão rápida** do que cada programa faz  
✅ **Identificação clara** de regras de negócio  
✅ **Detecção automática** de particularidades importantes  
✅ **Integração completa** com copybooks  
✅ **Transparência total** sobre a análise realizada  
✅ **Funciona offline** no modo tradicional  

## 📝 Documentação Completa

- **`MANUAL_USO_COMPLETO.md`** - Manual detalhado com todos os parâmetros
- **`docs/`** - Documentação técnica e guias
- **`examples/`** - Exemplos práticos e casos de uso

---

**COBOL Analysis Engine v2.0**  
**Status:** ✅ Funcional e Testado  
**Última atualização:** 20/09/2025
