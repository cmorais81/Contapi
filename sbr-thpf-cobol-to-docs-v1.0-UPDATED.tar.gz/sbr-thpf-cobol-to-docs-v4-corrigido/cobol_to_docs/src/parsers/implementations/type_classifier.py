"""
COBOL AI Engine v4.0 - Type Classifier
Classificador inteligente para tipos de conteúdo COBOL.
"""

import re
import logging
from typing import Dict, List

from parsers.interfaces.parser_interface import ITypeClassifier, MemberType


class CobolTypeClassifier(ITypeClassifier):
    """
    Classificador de tipos COBOL.
    
    Responsabilidades:
    - Classificar programas vs copybooks
    - Detectar subtipos específicos
    - Calcular confiança da classificação
    - Fornecer análise detalhada
    """
    
    def __init__(self):
        """Inicializa o classificador de tipos."""
        self.logger = logging.getLogger(__name__)
        
        # Indicadores de programa COBOL
        self.program_indicators = {
            'IDENTIFICATION DIVISION': 3.0,
            'ID DIVISION': 3.0,
            'PROGRAM-ID': 2.5,
            'PROCEDURE DIVISION': 2.5,
            'ENVIRONMENT DIVISION': 2.0,
            'DATA DIVISION': 1.5,
            'WORKING-STORAGE SECTION': 1.0,
            'FILE SECTION': 1.0,
            'LINKAGE SECTION': 1.0,
            'PERFORM': 1.0,
            'CALL': 1.0,
            'GOBACK': 1.5,
            'STOP RUN': 1.5,
            'EXIT PROGRAM': 1.5
        }
        
        # Indicadores de copybook
        self.copybook_indicators = {
            'COPY': 2.0,
            'INCLUDE': 2.0,
            'REPLACING': 1.5,
            '01 ': 1.5,
            '05 ': 1.0,
            '10 ': 1.0,
            '15 ': 0.8,
            '20 ': 0.8,
            'PIC ': 1.5,
            'PICTURE ': 1.5,
            'VALUE ': 1.0,
            'OCCURS ': 1.0,
            'REDEFINES': 1.0,
            'COMP': 0.8,
            'COMP-3': 0.8,
            'USAGE': 0.8
        }
        
        # Indicadores de subtipos
        self.subtype_indicators = {
            'batch_program': ['ACCEPT', 'DISPLAY', 'SORT', 'MERGE'],
            'online_program': ['CICS', 'EXEC CICS', 'DFHCOMMAREA', 'EIBCALEN'],
            'subroutine': ['LINKAGE SECTION', 'USING', 'CALL'],
            'data_structure': ['01 ', '05 ', 'PIC', 'OCCURS'],
            'sql_copybook': ['EXEC SQL', 'SQLCA', 'SQLCODE', 'DECLARE CURSOR'],
            'screen_copybook': ['SCREEN SECTION', 'ACCEPT', 'DISPLAY']
        }
        
        self.logger.info("Type Classifier inicializado")
    
    def classify_member(self, content: str) -> MemberType:
        """
        Classifica o tipo do membro.
        
        Args:
            content: Conteúdo a classificar
            
        Returns:
            MemberType: Tipo classificado
        """
        if not content or not content.strip():
            return MemberType.UNKNOWN
        
        # Calcular pontuações
        program_score = self._calculate_program_score(content)
        copybook_score = self._calculate_copybook_score(content)
        
        self.logger.debug(f"Pontuações - Programa: {program_score:.2f}, Copybook: {copybook_score:.2f}")
        
        # Determinar tipo baseado nas pontuações
        if program_score > copybook_score and program_score >= 3.0:
            return MemberType.PROGRAM
        elif copybook_score > program_score and copybook_score >= 2.0:
            return MemberType.COPYBOOK
        elif program_score >= 1.5 or copybook_score >= 1.5:
            # Se tem alguma pontuação razoável, escolher o maior
            return MemberType.PROGRAM if program_score > copybook_score else MemberType.COPYBOOK
        else:
            return MemberType.UNKNOWN
    
    def get_classification_confidence(self, content: str, member_type: MemberType) -> float:
        """
        Retorna confiança da classificação.
        
        Args:
            content: Conteúdo classificado
            member_type: Tipo classificado
            
        Returns:
            float: Confiança de 0.0 a 1.0
        """
        if member_type == MemberType.UNKNOWN:
            return 0.0
        
        program_score = self._calculate_program_score(content)
        copybook_score = self._calculate_copybook_score(content)
        
        if member_type == MemberType.PROGRAM:
            # Confiança baseada na diferença entre pontuações
            if copybook_score == 0:
                confidence = min(1.0, program_score / 5.0)
            else:
                ratio = program_score / (program_score + copybook_score)
                confidence = max(0.5, ratio)
        else:  # COPYBOOK
            if program_score == 0:
                confidence = min(1.0, copybook_score / 4.0)
            else:
                ratio = copybook_score / (program_score + copybook_score)
                confidence = max(0.5, ratio)
        
        return min(1.0, confidence)
    
    def detect_subtype(self, content: str, member_type: MemberType) -> str:
        """
        Detecta subtipo específico do membro.
        
        Args:
            content: Conteúdo a analisar
            member_type: Tipo principal
            
        Returns:
            str: Subtipo detectado
        """
        if member_type == MemberType.UNKNOWN:
            return 'unknown'
        
        content_upper = content.upper()
        subtype_scores = {}
        
        # Calcular pontuação para cada subtipo
        for subtype, indicators in self.subtype_indicators.items():
            score = 0
            for indicator in indicators:
                if indicator in content_upper:
                    score += 1
            
            if score > 0:
                subtype_scores[subtype] = score
        
        # Retornar subtipo com maior pontuação
        if subtype_scores:
            best_subtype = max(subtype_scores, key=subtype_scores.get)
            
            # Verificar se pontuação é significativa
            if subtype_scores[best_subtype] >= 2:
                return best_subtype
        
        # Subtipos padrão baseado no tipo principal
        if member_type == MemberType.PROGRAM:
            return 'standard_program'
        else:
            return 'data_copybook'
    
    def analyze_content_structure(self, content: str) -> Dict[str, any]:
        """
        Analisa estrutura detalhada do conteúdo.
        
        Args:
            content: Conteúdo a analisar
            
        Returns:
            Dict[str, any]: Análise estrutural
        """
        lines = content.split('\n')
        content_upper = content.upper()
        
        analysis = {
            'total_lines': len(lines),
            'non_empty_lines': len([line for line in lines if line.strip()]),
            'comment_lines': 0,
            'code_lines': 0,
            'divisions_found': [],
            'sections_found': [],
            'data_levels_found': [],
            'keywords_found': {},
            'complexity_indicators': {}
        }
        
        # Analisar linhas
        for line in lines:
            line_stripped = line.strip()
            if not line_stripped:
                continue
            
            if line_stripped.startswith('*') or line_stripped.startswith('//'):
                analysis['comment_lines'] += 1
            else:
                analysis['code_lines'] += 1
        
        # Encontrar divisões
        division_pattern = re.compile(r'^\s*([A-Z]+)\s+DIVISION\.', re.IGNORECASE)
        for line in lines:
            match = division_pattern.match(line)
            if match:
                division = match.group(1).upper()
                if division not in analysis['divisions_found']:
                    analysis['divisions_found'].append(division)
        
        # Encontrar seções
        section_pattern = re.compile(r'^\s*([A-Z0-9\-]+)\s+SECTION\.', re.IGNORECASE)
        for line in lines:
            match = section_pattern.match(line)
            if match:
                section = match.group(1).upper()
                if section not in analysis['sections_found']:
                    analysis['sections_found'].append(section)
        
        # Encontrar níveis de dados
        data_level_pattern = re.compile(r'^\s*(\d{2})\s+', re.IGNORECASE)
        for line in lines:
            match = data_level_pattern.match(line)
            if match:
                level = match.group(1)
                if level not in analysis['data_levels_found']:
                    analysis['data_levels_found'].append(level)
        
        # Contar palavras-chave importantes
        important_keywords = [
            'PERFORM', 'IF', 'ELSE', 'MOVE', 'COMPUTE', 'ADD', 'SUBTRACT',
            'MULTIPLY', 'DIVIDE', 'CALL', 'ACCEPT', 'DISPLAY', 'READ', 'WRITE',
            'OPEN', 'CLOSE', 'PIC', 'PICTURE', 'VALUE', 'OCCURS'
        ]
        
        for keyword in important_keywords:
            count = len(re.findall(r'\b' + keyword + r'\b', content_upper))
            if count > 0:
                analysis['keywords_found'][keyword] = count
        
        # Indicadores de complexidade
        analysis['complexity_indicators'] = {
            'has_nested_programs': 'END PROGRAM' in content_upper,
            'has_sql': 'EXEC SQL' in content_upper,
            'has_cics': 'EXEC CICS' in content_upper,
            'has_file_io': any(kw in content_upper for kw in ['READ', 'WRITE', 'OPEN', 'CLOSE']),
            'has_arithmetic': any(kw in content_upper for kw in ['COMPUTE', 'ADD', 'SUBTRACT', 'MULTIPLY', 'DIVIDE']),
            'has_conditionals': any(kw in content_upper for kw in ['IF', 'ELSE', 'EVALUATE']),
            'has_loops': 'PERFORM' in content_upper,
            'data_structure_complexity': len(analysis['data_levels_found'])
        }
        
        return analysis
    
    def _calculate_program_score(self, content: str) -> float:
        """
        Calcula pontuação para programa COBOL.
        
        Args:
            content: Conteúdo a analisar
            
        Returns:
            float: Pontuação do programa
        """
        content_upper = content.upper()
        score = 0.0
        
        for indicator, weight in self.program_indicators.items():
            if indicator in content_upper:
                score += weight
        
        # Bônus por estrutura completa de programa
        if ('IDENTIFICATION DIVISION' in content_upper or 'ID DIVISION' in content_upper) and \
           'PROCEDURE DIVISION' in content_upper:
            score += 1.0
        
        # Penalizar se tem muitos indicadores de copybook
        copybook_count = sum(1 for indicator in self.copybook_indicators 
                           if indicator in content_upper)
        if copybook_count > 5:
            score *= 0.7
        
        return score
    
    def _calculate_copybook_score(self, content: str) -> float:
        """
        Calcula pontuação para copybook.
        
        Args:
            content: Conteúdo a analisar
            
        Returns:
            float: Pontuação do copybook
        """
        content_upper = content.upper()
        score = 0.0
        
        for indicator, weight in self.copybook_indicators.items():
            count = len(re.findall(r'\b' + re.escape(indicator), content_upper))
            score += count * weight
        
        # Bônus por estrutura típica de copybook
        data_levels = len(re.findall(r'^\s*\d{2}\s+', content, re.MULTILINE))
        if data_levels > 3:
            score += 1.0
        
        # Penalizar se tem divisões de programa
        if any(div in content_upper for div in ['IDENTIFICATION DIVISION', 'PROCEDURE DIVISION']):
            score *= 0.3
        
        return score
    
    def get_classification_report(self, content: str) -> Dict[str, any]:
        """
        Gera relatório completo de classificação.
        
        Args:
            content: Conteúdo a analisar
            
        Returns:
            Dict[str, any]: Relatório de classificação
        """
        member_type = self.classify_member(content)
        confidence = self.get_classification_confidence(content, member_type)
        subtype = self.detect_subtype(content, member_type)
        structure = self.analyze_content_structure(content)
        
        return {
            'classification': {
                'type': member_type.value,
                'subtype': subtype,
                'confidence': confidence
            },
            'scores': {
                'program_score': self._calculate_program_score(content),
                'copybook_score': self._calculate_copybook_score(content)
            },
            'structure': structure,
            'recommendations': self._generate_recommendations(member_type, confidence, structure)
        }
    
    def _generate_recommendations(self, member_type: MemberType, confidence: float, 
                                structure: Dict[str, any]) -> List[str]:
        """
        Gera recomendações baseadas na classificação.
        
        Args:
            member_type: Tipo classificado
            confidence: Confiança da classificação
            structure: Análise estrutural
            
        Returns:
            List[str]: Lista de recomendações
        """
        recommendations = []
        
        if confidence < 0.7:
            recommendations.append("Baixa confiança na classificação - revisar manualmente")
        
        if member_type == MemberType.UNKNOWN:
            recommendations.append("Tipo não identificado - verificar se é código COBOL válido")
        
        if structure['comment_lines'] == 0:
            recommendations.append("Adicionar comentários para melhor documentação")
        
        if member_type == MemberType.PROGRAM:
            if not structure['divisions_found']:
                recommendations.append("Programa sem divisões identificadas - verificar estrutura")
            
            if not structure['complexity_indicators']['has_conditionals']:
                recommendations.append("Programa simples - considerar refatoração se necessário")
        
        if member_type == MemberType.COPYBOOK:
            if not structure['data_levels_found']:
                recommendations.append("Copybook sem níveis de dados - verificar estrutura")
        
        return recommendations
