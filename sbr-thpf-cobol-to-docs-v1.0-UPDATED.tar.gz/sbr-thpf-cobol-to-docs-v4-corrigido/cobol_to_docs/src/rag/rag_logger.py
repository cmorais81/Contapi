"""
Sistema de Logging Transparente para RAG
Implementa logging detalhado de todas as operações do sistema RAG
"""

import os
import json
import logging
import time
from datetime import datetime
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, asdict
import hashlib

@dataclass
class RAGLogEntry:
    """Entrada de log para operações RAG"""
    timestamp: str
    operation: str
    program_name: str
    query: str
    knowledge_items_found: int
    knowledge_items_used: int
    similarity_scores: List[float]
    categories_used: List[str]
    domains_used: List[str]
    execution_time_ms: float
    tokens_saved: Optional[int] = None
    prompt_enhancement_size: Optional[int] = None
    success: bool = True
    error_message: Optional[str] = None

@dataclass
class RAGSessionSummary:
    """Resumo de uma sessão de uso do RAG"""
    session_id: str
    start_time: str
    end_time: str
    total_operations: int
    total_knowledge_items_retrieved: int
    total_knowledge_items_used: int
    average_similarity_score: float
    categories_distribution: Dict[str, int]
    domains_distribution: Dict[str, int]
    total_tokens_saved: int
    total_execution_time_ms: float
    programs_analyzed: List[str]

class RAGTransparentLogger:
    """
    Sistema de logging transparente para operações RAG.
    Registra todas as operações com detalhes completos para auditoria e análise.
    """
    
    def __init__(self, log_dir: str = "logs", enable_console_output: bool = True):
        """
        Inicializa o sistema de logging RAG.
        
        Args:
            log_dir: Diretório para armazenar logs
            enable_console_output: Se deve exibir logs no console
        """
        self.log_dir = log_dir
        self.enable_console_output = enable_console_output
        self.session_id = self._generate_session_id()
        self.session_start = datetime.now()
        self.log_entries: List[RAGLogEntry] = []
        
        # Criar diretório de logs se não existir
        os.makedirs(log_dir, exist_ok=True)
        
        # Configurar logger
        self.logger = logging.getLogger(f"RAG_Logger_{self.session_id}")
        self.logger.setLevel(logging.INFO)
        
        # Handler para arquivo
        log_file = os.path.join(log_dir, f"rag_operations_{self.session_id}.log")
        file_handler = logging.FileHandler(log_file, encoding='utf-8')
        file_handler.setLevel(logging.INFO)
        
        # Handler para console (se habilitado)
        if enable_console_output:
            console_handler = logging.StreamHandler()
            console_handler.setLevel(logging.INFO)
            
            # Formatter
            formatter = logging.Formatter(
                '%(asctime)s - RAG - %(levelname)s - %(message)s',
                datefmt='%Y-%m-%d %H:%M:%S'
            )
            console_handler.setFormatter(formatter)
            self.logger.addHandler(console_handler)
        
        # Formatter para arquivo
        file_formatter = logging.Formatter(
            '%(asctime)s - %(levelname)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        file_handler.setFormatter(file_formatter)
        self.logger.addHandler(file_handler)
        
        self.logger.info(f"=== NOVA SESSÃO RAG INICIADA ===")
        self.logger.info(f"Session ID: {self.session_id}")
        self.logger.info(f"Timestamp: {self.session_start}")
        self.logger.info("=" * 50)
    
    def _generate_session_id(self) -> str:
        """Gera ID único para a sessão"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        hash_part = hashlib.md5(str(time.time()).encode()).hexdigest()[:8]
        return f"{timestamp}_{hash_part}"
    
    def log_knowledge_retrieval(self, 
                               program_name: str,
                               query: str,
                               knowledge_items: List[Any],
                               similarity_scores: List[float],
                               execution_time_ms: float) -> None:
        """
        Registra operação de recuperação de conhecimento.
        
        Args:
            program_name: Nome do programa sendo analisado
            query: Query utilizada para busca
            knowledge_items: Itens de conhecimento encontrados
            similarity_scores: Scores de similaridade
            execution_time_ms: Tempo de execução em milissegundos
        """
        categories = [item.category for item in knowledge_items] if knowledge_items else []
        domains = [item.domain for item in knowledge_items] if knowledge_items else []
        
        log_entry = RAGLogEntry(
            timestamp=datetime.now().isoformat(),
            operation="knowledge_retrieval",
            program_name=program_name,
            query=query,
            knowledge_items_found=len(knowledge_items),
            knowledge_items_used=len(knowledge_items),
            similarity_scores=similarity_scores,
            categories_used=list(set(categories)),
            domains_used=list(set(domains)),
            execution_time_ms=execution_time_ms
        )
        
        self.log_entries.append(log_entry)
        
        # Log detalhado
        self.logger.info(f"*** SISTEMA RAG ATIVO *** RECUPERAÇÃO DE CONHECIMENTO:")
        self.logger.info(f"  Programa: {program_name}")
        self.logger.info(f"  Query: {query}")
        self.logger.info(f"  Itens encontrados: {len(knowledge_items)}")
        self.logger.info(f"  Scores de similaridade: {similarity_scores}")
        self.logger.info(f"  Categorias: {list(set(categories))}")
        self.logger.info(f"  Domínios: {list(set(domains))}")
        self.logger.info(f"  Tempo de execução: {execution_time_ms:.2f}ms")
        
        if knowledge_items:
            self.logger.info("  Itens de conhecimento recuperados:")
            for i, item in enumerate(knowledge_items):
                score = similarity_scores[i] if i < len(similarity_scores) else 0.0
                self.logger.info(f"    [{i+1}] {item.title} (Score: {score:.3f}, Categoria: {item.category})")
        
        self.logger.info("-" * 50)
    
    def log_context_enhancement(self,
                               program_name: str,
                               base_context_size: int,
                               enhanced_context_size: int,
                               knowledge_items_used: int,
                               tokens_saved: Optional[int] = None) -> None:
        """
        Registra operação de enriquecimento de contexto.
        
        Args:
            program_name: Nome do programa
            base_context_size: Tamanho do contexto base
            enhanced_context_size: Tamanho do contexto enriquecido
            knowledge_items_used: Número de itens de conhecimento utilizados
            tokens_saved: Tokens economizados (se calculado)
        """
        log_entry = RAGLogEntry(
            timestamp=datetime.now().isoformat(),
            operation="context_enhancement",
            program_name=program_name,
            query="context_enhancement",
            knowledge_items_found=knowledge_items_used,
            knowledge_items_used=knowledge_items_used,
            similarity_scores=[],
            categories_used=[],
            domains_used=[],
            execution_time_ms=0.0,
            tokens_saved=tokens_saved,
            prompt_enhancement_size=enhanced_context_size - base_context_size
        )
        
        self.log_entries.append(log_entry)
        
        self.logger.info(f"*** SISTEMA RAG ATIVO *** ENRIQUECIMENTO DE CONTEXTO:")
        self.logger.info(f"  Programa: {program_name}")
        self.logger.info(f"  Contexto base: {base_context_size} caracteres")
        self.logger.info(f"  Contexto enriquecido: {enhanced_context_size} caracteres")
        self.logger.info(f"  Aumento: {enhanced_context_size - base_context_size} caracteres")
        self.logger.info(f"  Itens de conhecimento utilizados: {knowledge_items_used}")
        if tokens_saved:
            self.logger.info(f"  Tokens economizados: {tokens_saved}")
        self.logger.info("-" * 50)
    
    def log_prompt_enhancement(self,
                              program_name: str,
                              base_prompt_size: int,
                              enhanced_prompt_size: int,
                              rag_sections_added: List[str]) -> None:
        """
        Registra operação de enriquecimento de prompt.
        
        Args:
            program_name: Nome do programa
            base_prompt_size: Tamanho do prompt base
            enhanced_prompt_size: Tamanho do prompt enriquecido
            rag_sections_added: Seções RAG adicionadas
        """
        self.logger.info(f"ENRIQUECIMENTO DE PROMPT:")
        self.logger.info(f"  Programa: {program_name}")
        self.logger.info(f"  Prompt base: {base_prompt_size} caracteres")
        self.logger.info(f"  Prompt enriquecido: {enhanced_prompt_size} caracteres")
        self.logger.info(f"  Aumento: {enhanced_prompt_size - base_prompt_size} caracteres")
        self.logger.info(f"  Seções RAG adicionadas: {rag_sections_added}")
        self.logger.info("-" * 50)
    
    def log_learning_operation(self,
                              program_name: str,
                              new_knowledge_items: int,
                              updated_knowledge_items: int,
                              learning_source: str) -> None:
        """
        Registra operação de aprendizado automático.
        
        Args:
            program_name: Nome do programa
            new_knowledge_items: Novos itens de conhecimento criados
            updated_knowledge_items: Itens de conhecimento atualizados
            learning_source: Fonte do aprendizado
        """
        self.logger.info(f"APRENDIZADO AUTOMÁTICO:")
        self.logger.info(f"  Programa: {program_name}")
        self.logger.info(f"  Fonte: {learning_source}")
        self.logger.info(f"  Novos itens: {new_knowledge_items}")
        self.logger.info(f"  Itens atualizados: {updated_knowledge_items}")
        self.logger.info("-" * 50)
    
    def log_error(self, operation: str, program_name: str, error_message: str) -> None:
        """
        Registra erro em operação RAG.
        
        Args:
            operation: Operação que falhou
            program_name: Nome do programa
            error_message: Mensagem de erro
        """
        log_entry = RAGLogEntry(
            timestamp=datetime.now().isoformat(),
            operation=operation,
            program_name=program_name,
            query="",
            knowledge_items_found=0,
            knowledge_items_used=0,
            similarity_scores=[],
            categories_used=[],
            domains_used=[],
            execution_time_ms=0.0,
            success=False,
            error_message=error_message
        )
        
        self.log_entries.append(log_entry)
        
        self.logger.error(f"ERRO EM OPERAÇÃO RAG:")
        self.logger.error(f"  Operação: {operation}")
        self.logger.error(f"  Programa: {program_name}")
        self.logger.error(f"  Erro: {error_message}")
        self.logger.error("-" * 50)
    
    def generate_session_summary(self) -> RAGSessionSummary:
        """Gera resumo da sessão RAG"""
        if not self.log_entries:
            return RAGSessionSummary(
                session_id=self.session_id,
                start_time=self.session_start.isoformat(),
                end_time=datetime.now().isoformat(),
                total_operations=0,
                total_knowledge_items_retrieved=0,
                total_knowledge_items_used=0,
                average_similarity_score=0.0,
                categories_distribution={},
                domains_distribution={},
                total_tokens_saved=0,
                total_execution_time_ms=0.0,
                programs_analyzed=[]
            )
        
        # Calcular estatísticas
        total_operations = len(self.log_entries)
        total_knowledge_items_retrieved = sum(entry.knowledge_items_found for entry in self.log_entries)
        total_knowledge_items_used = sum(entry.knowledge_items_used for entry in self.log_entries)
        
        all_scores = []
        for entry in self.log_entries:
            all_scores.extend(entry.similarity_scores)
        average_similarity_score = sum(all_scores) / len(all_scores) if all_scores else 0.0
        
        categories_distribution = {}
        domains_distribution = {}
        for entry in self.log_entries:
            for category in entry.categories_used:
                categories_distribution[category] = categories_distribution.get(category, 0) + 1
            for domain in entry.domains_used:
                domains_distribution[domain] = domains_distribution.get(domain, 0) + 1
        
        total_tokens_saved = sum(entry.tokens_saved or 0 for entry in self.log_entries)
        total_execution_time_ms = sum(entry.execution_time_ms for entry in self.log_entries)
        programs_analyzed = list(set(entry.program_name for entry in self.log_entries))
        
        return RAGSessionSummary(
            session_id=self.session_id,
            start_time=self.session_start.isoformat(),
            end_time=datetime.now().isoformat(),
            total_operations=total_operations,
            total_knowledge_items_retrieved=total_knowledge_items_retrieved,
            total_knowledge_items_used=total_knowledge_items_used,
            average_similarity_score=average_similarity_score,
            categories_distribution=categories_distribution,
            domains_distribution=domains_distribution,
            total_tokens_saved=total_tokens_saved,
            total_execution_time_ms=total_execution_time_ms,
            programs_analyzed=programs_analyzed
        )
    
    def save_session_report(self) -> str:
        """
        Salva relatório completo da sessão.
        
        Returns:
            Caminho do arquivo de relatório gerado
        """
        summary = self.generate_session_summary()
        
        # Salvar resumo JSON
        summary_file = os.path.join(self.log_dir, f"rag_session_summary_{self.session_id}.json")
        with open(summary_file, 'w', encoding='utf-8') as f:
            json.dump(asdict(summary), f, indent=2, ensure_ascii=False)
        
        # Salvar log detalhado JSON
        detailed_log_file = os.path.join(self.log_dir, f"rag_detailed_log_{self.session_id}.json")
        with open(detailed_log_file, 'w', encoding='utf-8') as f:
            json.dump([asdict(entry) for entry in self.log_entries], f, indent=2, ensure_ascii=False)
        
        # Gerar relatório em texto
        report_file = os.path.join(self.log_dir, f"rag_session_report_{self.session_id}.txt")
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write("=" * 80 + "\n")
            f.write("RELATÓRIO DE SESSÃO RAG - COBOL TO DOCS v1.3\n")
            f.write("=" * 80 + "\n\n")
            
            f.write(f"Session ID: {summary.session_id}\n")
            f.write(f"Início: {summary.start_time}\n")
            f.write(f"Fim: {summary.end_time}\n")
            f.write(f"Duração total: {summary.total_execution_time_ms:.2f}ms\n\n")
            
            f.write("ESTATÍSTICAS GERAIS:\n")
            f.write("-" * 40 + "\n")
            f.write(f"Total de operações RAG: {summary.total_operations}\n")
            f.write(f"Itens de conhecimento recuperados: {summary.total_knowledge_items_retrieved}\n")
            f.write(f"Itens de conhecimento utilizados: {summary.total_knowledge_items_used}\n")
            f.write(f"Score médio de similaridade: {summary.average_similarity_score:.3f}\n")
            f.write(f"Tokens economizados: {summary.total_tokens_saved}\n")
            f.write(f"Programas analisados: {len(summary.programs_analyzed)}\n\n")
            
            f.write("PROGRAMAS ANALISADOS:\n")
            f.write("-" * 40 + "\n")
            for program in summary.programs_analyzed:
                f.write(f"- {program}\n")
            f.write("\n")
            
            f.write("DISTRIBUIÇÃO POR CATEGORIA:\n")
            f.write("-" * 40 + "\n")
            for category, count in summary.categories_distribution.items():
                f.write(f"- {category}: {count} itens\n")
            f.write("\n")
            
            f.write("DISTRIBUIÇÃO POR DOMÍNIO:\n")
            f.write("-" * 40 + "\n")
            for domain, count in summary.domains_distribution.items():
                f.write(f"- {domain}: {count} itens\n")
            f.write("\n")
            
            f.write("OPERAÇÕES DETALHADAS:\n")
            f.write("-" * 40 + "\n")
            for i, entry in enumerate(self.log_entries, 1):
                f.write(f"{i}. {entry.operation.upper()} - {entry.program_name}\n")
                f.write(f"   Timestamp: {entry.timestamp}\n")
                f.write(f"   Query: {entry.query}\n")
                f.write(f"   Itens encontrados: {entry.knowledge_items_found}\n")
                f.write(f"   Itens utilizados: {entry.knowledge_items_used}\n")
                if entry.similarity_scores:
                    f.write(f"   Scores: {[f'{s:.3f}' for s in entry.similarity_scores]}\n")
                f.write(f"   Categorias: {entry.categories_used}\n")
                f.write(f"   Domínios: {entry.domains_used}\n")
                f.write(f"   Tempo: {entry.execution_time_ms:.2f}ms\n")
                if entry.tokens_saved:
                    f.write(f"   Tokens economizados: {entry.tokens_saved}\n")
                if not entry.success:
                    f.write(f"   ERRO: {entry.error_message}\n")
                f.write("\n")
        
        self.logger.info(f"=== SESSÃO RAG FINALIZADA ===")
        self.logger.info(f"Relatório salvo em: {report_file}")
        self.logger.info(f"Total de operações: {summary.total_operations}")
        self.logger.info(f"Itens de conhecimento utilizados: {summary.total_knowledge_items_used}")
        self.logger.info("=" * 50)
        
        return report_file
    
    def close_session(self) -> str:
        """
        Finaliza a sessão e gera relatório final.
        
        Returns:
            Caminho do arquivo de relatório gerado
        """
        return self.save_session_report()
