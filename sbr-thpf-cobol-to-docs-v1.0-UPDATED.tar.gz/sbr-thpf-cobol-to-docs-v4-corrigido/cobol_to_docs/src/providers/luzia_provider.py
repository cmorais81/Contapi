import requests
import logging
import time
from typing import Dict, Any, Optional, List
from urllib3.exceptions import InsecureRequestWarning
import warnings

from .base_provider import BaseProvider, AIRequest, AIResponse

# Suprimir warnings de SSL
warnings.filterwarnings("ignore", message="Unverified HTTPS request")
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

class LuziaProvider(BaseProvider):
    """
    Provider LuzIA corrigido com URLs e payload corretos da versão funcionando
    """
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.logger = logging.getLogger("LuziaProvider")
        
        # Obter configurações do LuzIA do config.yaml
        self.auth_url = config.get("auth_url", "https://auth.luzia.com/oauth/token")
        self.api_url = config.get("api_url", "https://api.luzia.com/v1/")
        self.client_id = config.get("client_id")
        self.client_secret = config.get("client_secret")
        self.timeout = config.get("timeout", 300)
        self.access_token = None
        self.token_expires_at = 0
        
        self.logger.info(f"LuziaProvider initialized with client_id: {self.client_id} and client_secret: {self.client_secret}")
    
    def _get_access_token(self) -> str:
        """
        Obtém um token de acesso para a API LuzIA.
        """
        if self.access_token and time.time() < self.token_expires_at:
            return self.access_token

        self.logger.info("Obtendo novo token de acesso para LuzIA...")
        token_url = self.auth_url
        headers = {
            "Content-Type": "application/x-www-form-urlencoded"
        }
        data = {
            "grant_type": "client_credentials",
            "client_id": self.client_id,
            "client_secret": self.client_secret
        }

        try:
            response = requests.post(token_url, headers=headers, data=data, timeout=10, verify=False)
            response.raise_for_status()
            token_data = response.json()
            self.access_token = token_data["access_token"]
            self.token_expires_at = time.time() + token_data["expires_in"] - 60  # 60s de buffer
            self.logger.info("Token de acesso LuzIA obtido com sucesso.")
            return self.access_token
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Erro ao obter token de acesso LuzIA: {e}")
            raise Exception(f"Falha na autenticação com LuzIA: {e}")

    def is_available(self) -> bool:
        """
        Verifica se o LuzIA está disponível tentando obter um token de acesso.
        """
        if not self.client_id or not self.client_secret:
            self.logger.warning("LuzIA client_id ou client_secret não configurado")
            return False
        
        try:
            self._get_access_token()
            return True
        except Exception as e:
            self.logger.error(f"Erro ao autenticar com LuzIA para verificar disponibilidade: {e}")
            return False

    def analyze(self, request: AIRequest) -> AIResponse:
        """
        Implementa o método analyze requerido pela interface BaseProvider.
        """
        if not self.validate_request(request):
            return self.create_error_response("Requisição inválida", request)
        
        start_time = time.time()
        
        try:
            access_token = self._get_access_token()
            
            # Construir payload no formato LuzIA (conforme especificado)
            # O program_code deve ser inlined no prompt do usuário
            user_prompt_content = f"""
Analise o seguinte programa COBOL:

PROGRAMA: {request.program_name}

CÓDIGO:
{request.program_code}

PROMPT DE ANÁLISE:
{request.prompt}

Por favor, forneça uma análise técnica detalhada seguindo as diretrizes do prompt.
"""

            payload = {
                "input": {
                    "query": [
                        {"role": "system", "content": "Você é um especialista em análise de sistemas COBOL."},
                        {"role": "user", "content": user_prompt_content}
                    ]
                },
                "config": {
                    "catena.llm.LLMRouter": {
                        "temperature": request.temperature,
                        "max_tokens": request.max_tokens,
                        "routing_model": request.model # Usar request.model para o routing_model
                    }
                }
            }
            
            self.logger.info(f"Enviando requisição para LuzIA - Programa: {request.program_name}")
            self.logger.info(f"Modelo: {request.model}")
            self.logger.info(f"Tokens máximos: {request.max_tokens}")
            
            # Headers
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {access_token}"
            }
            
            # Fazer requisição
            response = requests.post(
                f"{self.api_url}/chat/completions",
                json=payload,
                headers=headers,
                timeout=self.timeout,
                verify=False
            )
            
            response_time = time.time() - start_time
            self.logger.info(f"Status da resposta: {response.status_code}")
            
            if response.status_code == 200:
                response_data = response.json()
                
                # Extrair conteúdo da resposta
                content = ""
                if "choices" in response_data and len(response_data["choices"]) > 0:
                    content = response_data["choices"][0].get("message", {}).get("content", "")
                elif "content" in response_data:
                    content = response_data["content"]
                
                # Extrair tokens usados
                usage = response_data.get("usage", {})
                total_tokens = usage.get("total_tokens", 0)
                
                self.logger.info(f"Resposta recebida com sucesso. Tokens usados: {total_tokens}")
                
                return self.create_success_response(
                    content=content,
                    tokens_used=total_tokens,
                    request=request,
                    metadata={
                        "response_time": response_time,
                        "raw_response": response_data
                    }
                )
            else:
                error_msg = f"Erro HTTP {response.status_code}: {response.text}"
                self.logger.error(error_msg)
                
                # Atualizar estatísticas
                self._update_statistics(False, 0, response_time)
                
                return self.create_error_response(error_msg, request)
                
        except requests.exceptions.Timeout:
            error_msg = f"Timeout na requisição para LuzIA (>{self.timeout}s)"
            self.logger.error(error_msg)
            self._update_statistics(False, 0, time.time() - start_time)
            return self.create_error_response(error_msg, request)
            
        except requests.exceptions.RequestException as e:
            error_msg = f"Erro de conexão com LuzIA: {str(e)}"
            self.logger.error(error_msg)
            self._update_statistics(False, 0, time.time() - start_time)
            return self.create_error_response(error_msg, request)
            
        except Exception as e:
            error_msg = f"Erro inesperado no LuziaProvider: {str(e)}"
            self.logger.error(error_msg)
            self._update_statistics(False, 0, time.time() - start_time)
            return self.create_error_response(error_msg, request)

    def get_available_models(self) -> Dict[str, Dict[str, Any]]:
        """
        Retorna modelos disponíveis no LuzIA.
        """
        # Implementação para retornar modelos disponíveis do LuzIA
        # Isso pode ser estático ou dinâmico, dependendo da API do LuzIA
        return {
            "aws_claude_3_5_sonnet": {
                "name": "aws-claude-3-5-sonnet",
                "description": "Modelo LLM avançado da AWS Claude, otimizado para tarefas complexas de linguagem natural",
                "max_tokens": 8192,
                "context_window": 200000,
                "capabilities": ["text_generation", "code_analysis", "documentation"]
            },
            "aws_claude_3_5_haiku": {
                "name": "aws-claude-3-5-haiku",
                "description": "Atualização do modelo Anthropic Claude Haiku, baixo custo e suporta apenas texto",
                "max_tokens": 4096,
                "context_window": 200000,
                "capabilities": ["text_generation", "code_analysis"]
            },
            "amazon_nova_pro_v1": {
                "name": "amazon-nova-pro-v1",
                "description": "Modelo LLM robusto da Amazon, voltado para tarefas de linguagem natural de alta complexidade",
                "max_tokens": 8192,
                "context_window": 300000,
                "capabilities": ["text_generation", "code_analysis"]
            },
            "azure_gpt_4o": {
                "name": "azure-gpt-4o-exp",
                "description": "Modelo LLM da Azure baseado no GPT-4, otimizado para tarefas gerais de linguagem natural",
                "max_tokens": 4096,
                "context_window": 128000,
                "capabilities": ["text_generation", "code_analysis"]
            }
        }

    def get_provider_info(self) -> Dict[str, Any]:
        """
        Retorna informações sobre o provedor.
        """
        return {
            "name": "LuzIA",
            "version": "1.0",
            "description": "Provedor de IA para análise de código COBOL via API LuzIA",
            "capabilities": [
                "COBOL code analysis",
                "Technical documentation generation",
                "Business logic extraction"
            ],
            "authentication": "OAuth2 Client Credentials",
            "base_url": self.api_url
        }

