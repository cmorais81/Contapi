# Modo Padrão Avançado - COBOL-to-Docs v3.0

## Configuração Implementada

O sistema agora usa automaticamente o **modo mais avançado** como padrão quando nenhum modo específico é escolhido.

## Modo Padrão Ativado Automaticamente

Quando você executa o sistema sem especificar modos específicos:

```bash
python3 cobol_to_docs/runner/main.py --fontes fontes.txt --books books.txt
```

O sistema automaticamente ativa:

### ✅ Funcionalidades Avançadas Padrão

1. **--consolidado**: Análise sistêmica consolidada
   - Análise de todos os programas simultaneamente
   - Visão arquitetural do sistema completo
   - Identificação de interdependências

2. **--analise-especialista**: Prompts especializados
   - Análise técnica profunda e detalhada
   - Foco em aspectos bancários específicos
   - Recomendações de modernização

3. **--deep-analysis**: Análise detalhada de regras
   - Extração de regras de negócio específicas
   - Análise de valores e constantes
   - Mapeamento de lógica complexa

4. **--prompt-set especialista**: Conjunto avançado
   - Prompts otimizados para análise bancária
   - Contexto expandido com RAG
   - Análise arquitetural sistêmica

## Como Usar

### Modo Padrão Avançado (Automático)
```bash
# Execução simples - ativa modo avançado automaticamente
python3 cobol_to_docs/runner/main.py --fontes fontes.txt --books books.txt

# Resultado: Análise consolidada + especialista + detalhada
```

### Modo Específico (Manual)
```bash
# Para usar apenas análise básica individual
python3 cobol_to_docs/runner/main.py --fontes fontes.txt

# Para usar apenas consolidado simples
python3 cobol_to_docs/runner/main.py --fontes fontes.txt --consolidado

# Para usar apenas análise especialista
python3 cobol_to_docs/runner/main.py --fontes fontes.txt --analise-especialista
```

## Vantagens do Modo Padrão Avançado

### 🎯 **Análise Mais Completa**
- Visão sistêmica + análise individual
- Contexto expandido com RAG
- Recomendações de modernização

### 🚀 **Melhor Qualidade**
- Prompts especializados para sistema bancário
- Análise detalhada de regras de negócio
- Identificação de padrões arquiteturais

### 💡 **Facilidade de Uso**
- Não precisa especificar múltiplos parâmetros
- Configuração otimizada automaticamente
- Resultados profissionais por padrão

## Configurações Avançadas Ativadas

### Sistema RAG
- Base de conhecimento ativa por padrão
- Contexto expandido para análises
- Aprendizado contínuo habilitado

### Modelos de IA
- Enhanced provider como padrão
- Fallback automático para Luzia
- Otimização de custos ativa

### Relatórios
- Geração automática de documentação
- Formatos múltiplos (MD, JSON)
- Metadados detalhados incluídos

## Logs do Modo Padrão

Quando o modo padrão é ativado, você verá:

```
=== NENHUM MODO ESPECÍFICO ESCOLHIDO - ATIVANDO MODO AVANÇADO PADRÃO ===
Ativando: --consolidado + --analise-especialista + --deep-analysis
=== MODO CONSOLIDADO + ANÁLISE ESPECIALIZADA (AVANÇADO) ===
Executando análise consolidada com expertise avançada
Características do modo:
• Análise sistêmica consolidada de todos os programas
• Prompts especializados para análise técnica profunda
• Sistema RAG ativo para contexto expandido
• Análise detalhada de regras de negócio
• Foco em modernização e arquitetura
```

## Personalização

Para voltar ao modo básico ou usar configurações específicas:

```bash
# Desativar modo avançado (usar básico)
python3 cobol_to_docs/runner/main.py --fontes fontes.txt --prompt-set original

# Usar apenas um modo específico
python3 cobol_to_docs/runner/main.py --fontes fontes.txt --procedure-detalhada

# Usar configuração personalizada
python3 cobol_to_docs/runner/main.py --fontes fontes.txt --config-dir /path/custom
```

## Resultado

Com o modo padrão avançado, você obtém automaticamente:

- **Análise sistêmica completa** de todo o sistema COBOL
- **Documentação profissional** com insights técnicos profundos
- **Recomendações de modernização** específicas
- **Visão arquitetural** do sistema bancário
- **Qualidade máxima** sem configuração manual

O sistema agora oferece a melhor experiência possível por padrão!
