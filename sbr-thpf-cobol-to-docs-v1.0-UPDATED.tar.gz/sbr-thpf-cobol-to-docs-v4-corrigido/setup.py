"""
COBOL to Docs v3.0 - Setup para PyPI
Configuração para instalação via pip install cobol-to-docs
"""

from setuptools import setup, find_packages
from pathlib import Path
import os

# Ler README para descrição longa
def read_readme():
    try:
        readme_path = Path(__file__).parent / "README.md"
        return readme_path.read_text(encoding='utf-8')
    except FileNotFoundError:
        return "Ferramenta avançada de análise e documentação automatizada de programas COBOL com IA e RAG"

# Ler versão
def read_version():
    try:
        version_path = Path(__file__).parent / "VERSION"
        return version_path.read_text(encoding='utf-8').strip()
    except FileNotFoundError:
        return "3.0.0"

# Ler requirements
def read_requirements():
    try:
        req_path = Path(__file__).parent / "requirements.txt"
        requirements = []
        for line in req_path.read_text(encoding='utf-8').splitlines():
            line = line.strip()
            if line and not line.startswith('#') and not line.startswith('-'):
                # Remove comentários inline
                if '#' in line:
                    line = line.split('#')[0].strip()
                requirements.append(line)
        return requirements
    except FileNotFoundError:
        return [
            'requests>=2.25.0',
            'pyyaml>=5.4.0',
            'jinja2>=3.0.0',
            'python-dotenv>=0.19.0',
            'scikit-learn>=1.0.0',
            'numpy>=1.21.0',
            'sentence-transformers>=2.2.0',
            'openai>=1.0.0',
            'weasyprint>=54.0',
            'markdown>=3.3.0',
            'colorama>=0.4.4'
        ]

# Encontrar todos os arquivos de dados
def find_data_files():
    data_files = []
    
    # Arquivos de configuração
    config_dir = Path(__file__).parent / "cobol_to_docs" / "config"
    if config_dir.exists():
        config_files = [str(f.relative_to(Path(__file__).parent)) for f in config_dir.rglob("*") if f.is_file()]
        data_files.extend(config_files)
    
    # Arquivos de dados (base RAG)
    data_dir = Path(__file__).parent / "cobol_to_docs" / "data"
    if data_dir.exists():
        data_files_list = [str(f.relative_to(Path(__file__).parent)) for f in data_dir.rglob("*") if f.is_file()]
        data_files.extend(data_files_list)
    
    # Arquivos de exemplo
    for example_file in ["fontes.txt", "BOOKS.txt"]:
        example_path = Path(__file__).parent / example_file
        if example_path.exists():
            data_files.append(example_file)
    
    return data_files

setup(
    name="cobol-to-docs",
    version=read_version(),
    author="COBOL Analyzer Team",
    author_email="cobol-analyzer@example.com",
    description="Ferramenta avançada de análise e documentação automatizada de programas COBOL com IA e RAG",
    long_description=read_readme(),
    long_description_content_type="text/markdown",
    url="https://github.com/cobol-analyzer/cobol-to-docs",
    packages=find_packages(),
    include_package_data=True,
    package_data={
        "cobol_to_docs": [
            "config/*.yaml",
            "config/*.yml", 
            "data/*.json",
            "data/*.pkl",
            "data/README.md",
            "data/backups/*.json",
            "src/*/*.py",
            "src/*/*/*.py",
            "runner/*.py",
        ],
        "": [
            "fontes.txt",
            "BOOKS.txt",
            "README.md",
            "requirements.txt",
            "VERSION",
        ]
    },
    data_files=[
        ("", ["fontes.txt", "BOOKS.txt", "VERSION"]),
        ("cobol_to_docs/config", ["cobol_to_docs/config/config.yaml", "cobol_to_docs/config/prompts.yaml"]),
        ("cobol_to_docs/data", ["cobol_to_docs/data/cobol_knowledge_base.json"]),
    ],
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "Intended Audience :: Information Technology",
        "Intended Audience :: Financial and Insurance Industry",
        "Topic :: Software Development :: Documentation",
        "Topic :: Software Development :: Code Generators",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
    install_requires=read_requirements(),
    extras_require={
        "dev": [
            "pytest>=6.0",
            "black>=21.0",
            "flake8>=3.8",
            "mypy>=0.800",
            "pre-commit>=2.15.0"
        ],
        "jupyter": [
            "jupyter>=1.0.0",
            "ipykernel>=6.0.0",
            "notebook>=6.4.0"
        ],
        "full": [
            "jupyter>=1.0.0",
            "ipykernel>=6.0.0",
            "notebook>=6.4.0",
            "reportlab>=3.6.0",
            "pandas>=1.0.0",
            "openpyxl>=3.0.0",
            "tqdm>=4.62.0"
        ]
    },
    entry_points={
        "console_scripts": [
            "cobol-to-docs=cobol_to_docs.runner.main:main",
            "cobol-docs=cobol_to_docs.runner.main:main",
            "cobol-analyze=cobol_to_docs.runner.main:main",
            "cobol-cli=cobol_to_docs.runner.cli:main",
        ],
    },
    keywords=[
        "cobol", "documentation", "ai", "analysis", "legacy", "mainframe",
        "reverse-engineering", "modernization", "rag", "nlp", "banking"
    ],
    project_urls={
        "Bug Reports": "https://github.com/cobol-analyzer/cobol-to-docs/issues",
        "Source": "https://github.com/cobol-analyzer/cobol-to-docs",
        "Documentation": "https://github.com/cobol-analyzer/cobol-to-docs/wiki",
        "Changelog": "https://github.com/cobol-analyzer/cobol-to-docs/blob/main/CHANGELOG.md",
    },
)
