# Changelog - COBOL AI Engine

Todas as mudanças notáveis neste projeto serão documentadas neste arquivo.

O formato é baseado em [Keep a Changelog](https://keepachangelog.com/pt-BR/1.0.0/),
e este projeto adere ao [Versionamento Semântico](https://semver.org/lang/pt-BR/).

## [1.0.2] - 2025-09-21

### Adicionado
- Configuração unificada em `config/config.yaml` com URLs corretas da LuzIA
- Arquivo `config/prompts.yaml` com prompts organizados por modelo
- URLs de autenticação e endpoint específicos para LuzIA
- Headers customizados incluindo User-Agent
- Configurações de rate limiting e retry por provedor
- Context window configurável por modelo
- Validação de encoding e sanitização de conteúdo
- Configurações de segurança aprimoradas
- Documentação técnica completa (`DOCUMENTACAO_TECNICA_v1.0.2.md`)
- Guia de referência rápida (`GUIA_REFERENCIA_RAPIDA.md`)

### Alterado
- Script principal unificado em um único `main.py`
- Configuração de provedores com URLs específicas
- Estrutura de prompts reorganizada por prioridade
- Documentação completamente atualizada
- Requirements.txt otimizado para Python 3.11+
- Versão atualizada em todos os arquivos

### Removido
- Todos os arquivos `main_*.py` desnecessários
- Arquivos de configuração duplicados (`config_*.yaml`)
- Diretórios de teste e arquivos temporários
- Referências ao Manus em todos os arquivos
- Ícones (emojis) da documentação
- Arquivos de exemplo desnecessários
- Package contents e arquivos de backup

### Corrigido
- URLs da LuzIA agora incluem auth_url e endpoint corretos
- Configuração de modelos padrão funcional
- Compatibilidade com Python 3.11+
- Estrutura de saída consistente
- Logs organizados e informativos
- Pacote final limpo (237KB)

## [1.0.1] - 2025-09-21

### Adicionado
- Suporte a múltiplos modelos de IA simultaneamente
- Análise comparativa automática entre modelos
- Relatórios de transparência com prompts salvos
- Engenharia de prompt avançada
- Análise semântica profunda de comentários COBOL
- Suporte aprimorado a copybooks (BOOKS.txt)
- Geração de relatórios comparativos
- Configuração flexível via YAML

### Alterado
- Arquitetura modular aprimorada
- Sistema de logging melhorado
- Interface de linha de comando expandida
- Documentação técnica completa

### Corrigido
- Tratamento de erros robusto
- Validação de entrada aprimorada
- Performance otimizada

## [1.0.0] - 2025-09-15

### Adicionado
- Versão inicial estável do COBOL AI Engine
- Análise básica de programas COBOL
- Suporte a provedores OpenAI e mock
- Geração de documentação em Markdown
- Sistema de configuração básico
- Análise de estruturas de dados COBOL
- Identificação de regras de negócio
- Documentação técnica e funcional

### Funcionalidades Principais
- Análise de código COBOL com IA
- Geração automática de documentação
- Suporte a copybooks
- Múltiplos formatos de saída
- Sistema de logs
- Configuração via arquivos YAML

## Tipos de Mudanças

- **Adicionado** para novas funcionalidades
- **Alterado** para mudanças em funcionalidades existentes
- **Descontinuado** para funcionalidades que serão removidas
- **Removido** para funcionalidades removidas
- **Corrigido** para correções de bugs
- **Segurança** para vulnerabilidades

## Compatibilidade

### Versão 1.0.2
- **Python**: 3.11+
- **Provedores**: LuzIA, OpenAI, Mock
- **Sistemas**: Windows, Linux, macOS
- **Dependências**: pyyaml>=6.0, requests>=2.31.0

### Versão 1.0.1
- **Python**: 3.11+
- **Provedores**: LuzIA, OpenAI, Mock
- **Sistemas**: Windows, Linux, macOS

### Versão 1.0.0
- **Python**: 3.8+
- **Provedores**: OpenAI, Mock
- **Sistemas**: Windows, Linux, macOS

## Migração entre Versões

### De 1.0.1 para 1.0.2

**Mudanças Necessárias:**
1. Usar apenas `main.py` (remover referências a outros main_*.py)
2. Atualizar configuração para usar `config/config.yaml` e `config/prompts.yaml`
3. Configurar URLs da LuzIA se necessário
4. Verificar variáveis de ambiente (LUZIA_API_KEY)

**Comandos de Migração:**
```bash
# Backup da configuração atual
cp config/config.yaml config/config_backup.yaml

# Usar nova configuração
# (arquivo já atualizado na v1.0.2)

# Testar nova versão
python main.py examples/fontes.txt --models "mock_enhanced"
```

### De 1.0.0 para 1.0.1

**Mudanças Necessárias:**
1. Atualizar Python para 3.11+
2. Instalar novas dependências
3. Configurar novos provedores se desejado
4. Atualizar scripts para usar novos parâmetros

**Comandos de Migração:**
```bash
# Atualizar dependências
pip install -r requirements.txt

# Configurar LuzIA (opcional)
export LUZIA_API_KEY="sua_chave"

# Testar multi-modelo
python main.py examples/fontes.txt --models '["claude_3_5_sonnet","mock_enhanced"]'
```

## Roadmap Futuro

### Versão 1.1.0 (Planejada)
- Suporte a mais provedores de IA
- Interface web opcional
- Análise de performance aprimorada
- Integração com IDEs
- Exportação para mais formatos

### Versão 1.2.0 (Planejada)
- Análise de dependências entre programas
- Geração de diagramas automática
- Suporte a análise de JCL
- Integração com sistemas de versionamento
- API REST para integração

### Versão 2.0.0 (Futura)
- Arquitetura de microserviços
- Interface gráfica completa
- Análise em tempo real
- Suporte a múltiplas linguagens
- Machine Learning para otimização

## Contribuições

### Como Contribuir
1. Fork o repositório
2. Crie uma branch para sua feature (`git checkout -b feature/AmazingFeature`)
3. Commit suas mudanças (`git commit -m 'Add some AmazingFeature'`)
4. Push para a branch (`git push origin feature/AmazingFeature`)
5. Abra um Pull Request

### Diretrizes de Contribuição
- Mantenha compatibilidade com versões anteriores quando possível
- Adicione testes para novas funcionalidades
- Atualize a documentação
- Siga as convenções de código existentes
- Adicione entrada no CHANGELOG.md

### Reportar Bugs
- Use o template de issue para bugs
- Inclua informações do sistema
- Forneça passos para reproduzir
- Anexe logs relevantes

### Solicitar Funcionalidades
- Use o template de issue para features
- Descreva o caso de uso
- Explique o benefício esperado
- Considere implementação alternativa

## Licença

Este projeto está licenciado sob os termos especificados no arquivo LICENSE.

## Agradecimentos

- Comunidade COBOL pela inspiração
- Contribuidores do projeto
- Usuários que forneceram feedback
- Provedores de IA pela infraestrutura

---

**Changelog mantido seguindo [Keep a Changelog](https://keepachangelog.com/pt-BR/1.0.0/)**  
**Última atualização**: 21 de Setembro de 2025
