"""
COBOL AI Engine v2.1.0 - LuzIA Provider
Implementação completa baseada na documentação oficial do LuzIA.
"""

import logging
import time
import json
from typing import Dict, Any, Optional
from datetime import datetime, timedelta

try:
    import requests
    from requests.adapters import HTTPAdapter
    try:
        from urllib3.util.retry import Retry
    except ImportError:
        # Fallback para versões mais antigas
        from requests.packages.urllib3.util.retry import Retry
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False

from .base_provider import BaseAIProvider, AIRequest, AIResponse


class LuziaProvider(BaseAIProvider):
    """
    Provedor LuzIA com implementação completa baseada na documentação oficial.
    
    Funcionalidades implementadas:
    - OAuth2 Client Credentials Flow
    - Refresh automático de tokens
    - Knowledge Base integration
    - Guardrails e compliance
    - Rate limiting corporativo
    - Tratamento robusto de erros
    """
    
    def __init__(self, name: str, config: Dict[str, Any]):
        """
        Inicializa o provedor LuzIA.
        
        Args:
            name: Nome do provedor
            config: Configuração com credenciais e endpoints
        """
        super().__init__(name, config)
        
        # Verificar dependências
        if not REQUESTS_AVAILABLE:
            self.logger.error("Biblioteca 'requests' não encontrada. Execute: pip install requests>=2.31.0")
            self.enabled = False
            return
        
        # Configurações específicas do LuzIA
        self.client_id = config.get('client_id', '')
        self.client_secret = config.get('client_secret', '')
        self.endpoint = config.get('endpoint', 'https://gpt-api.aws.santanderbr.dev.corp/genai_services/v1')
        self.auth_endpoint = config.get('auth_endpoint', 'https://login.azure-ad.santanderbr.dev.corp/oauth2/token')
        self.model = config.get('model', 'aws-claude-1-3-sonnet-exp')
        self.api_version = config.get('api_version', '2023-05-15')
        
        # Knowledge Base e Guardrails (baseado na documentação)
        self.knowledge_base_id = config.get('knowledge_base_id', 'KNOWLEDGE_BASE_COBOL')
        self.guardrail_id = config.get('guardrail_id', 'GUARDRAIL_BANKING')
        self.guardrail_version = config.get('guardrail_version', 'GUARDRAIL_VERSION')
        
        # Configurações de performance
        self.performance_config = config.get('performance_config', 'optimized')
        self.auto_refresh_token = config.get('auto_refresh_token', True)
        self.rate_limit_delay = config.get('rate_limit_delay', 2.0)
        
        # Estado de autenticação
        self.access_token = None
        self.token_expires_at = None
        self.token_type = "Bearer"
        
        # Configurar sessão HTTP com retry
        self.session = requests.Session()
        retry_strategy = Retry(
            total=3,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["HEAD", "GET", "POST"],
            backoff_factor=1
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        self.session.mount("http://", adapter)
        self.session.mount("https://", adapter)
        
        # Headers padrão
        self.session.headers.update({
            'User-Agent': 'COBOL-AI-Engine/2.1.0',
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        })
        
        # Validar configuração
        if not self.client_id or not self.client_secret:
            self.logger.warning("Credenciais LuzIA não configuradas")
            self.enabled = False
        
        self.logger.info(f"LuzIA Provider inicializado - Endpoint: {self.endpoint}")
    
    def is_available(self) -> bool:
        """Verifica se o LuzIA está disponível."""
        if not self.enabled or not REQUESTS_AVAILABLE:
            return False
        
        if not self.client_id or not self.client_secret:
            return False
        
        try:
            # Tentar autenticação
            return self._authenticate()
        except Exception as e:
            self.logger.debug(f"LuzIA não disponível: {str(e)}")
            return False
    
    def analyze(self, request: AIRequest) -> AIResponse:
        """
        Realiza análise usando LuzIA.
        
        Args:
            request: Requisição de análise
            
        Returns:
            Resposta da análise
        """
        if not self._validate_request(request):
            response = self._create_error_response("Requisição inválida")
            self._update_statistics(response)
            return response
        
        try:
            # Garantir autenticação válida
            if not self._ensure_authenticated():
                response = self._create_error_response("Falha na autenticação LuzIA")
                self._update_statistics(response)
                return response
            
            # Aplicar rate limiting
            self._apply_rate_limiting()
            
            # Preparar payload baseado na documentação LuzIA
            payload = self._prepare_luzia_payload(request)
            
            # Fazer requisição
            start_time = time.time()
            response_data = self._make_luzia_request(payload)
            end_time = time.time()
            
            # Processar resposta
            if response_data:
                ai_response = self._process_luzia_response(response_data, end_time - start_time)
                self._update_statistics(ai_response)
                return ai_response
            else:
                response = self._create_error_response("Resposta vazia do LuzIA")
                self._update_statistics(response)
                return response
                
        except Exception as e:
            self.logger.error(f"Erro na análise LuzIA: {str(e)}")
            response = self._create_error_response(f"Erro LuzIA: {str(e)}")
            self._update_statistics(response)
            return response
    
    def _authenticate(self) -> bool:
        """
        Realiza autenticação OAuth2 Client Credentials Flow.
        
        Returns:
            True se autenticação bem-sucedida
        """
        try:
            # Payload OAuth2 baseado na documentação
            auth_payload = {
                'grant_type': 'client_credentials',
                'client_id': self.client_id,
                'client_secret': self.client_secret,
                'scope': 'genai_services'  # Scope específico para LuzIA
            }
            
            # Headers para autenticação
            auth_headers = {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Accept': 'application/json'
            }
            
            self.logger.debug("Iniciando autenticação OAuth2 LuzIA")
            
            response = self.session.post(
                self.auth_endpoint,
                data=auth_payload,
                headers=auth_headers,
                timeout=30
            )
            
            if response.status_code == 200:
                token_data = response.json()
                
                self.access_token = token_data.get('access_token')
                expires_in = token_data.get('expires_in', 3600)  # Default 1 hora
                self.token_type = token_data.get('token_type', 'Bearer')
                
                # Calcular expiração com margem de segurança
                self.token_expires_at = datetime.now() + timedelta(seconds=expires_in - 300)
                
                self.logger.info("Autenticação LuzIA bem-sucedida")
                return True
            else:
                self.logger.error(f"Falha na autenticação LuzIA: {response.status_code} - {response.text}")
                return False
                
        except Exception as e:
            self.logger.error(f"Erro na autenticação LuzIA: {str(e)}")
            return False
    
    def _ensure_authenticated(self) -> bool:
        """Garante que temos token válido."""
        # Verificar se token existe e não expirou
        if (self.access_token and self.token_expires_at and 
            datetime.now() < self.token_expires_at):
            return True
        
        # Token expirado ou inexistente, renovar
        self.logger.debug("Token LuzIA expirado, renovando...")
        return self._authenticate()
    
    def _prepare_luzia_payload(self, request: AIRequest) -> Dict[str, Any]:
        """
        Prepara payload específico para LuzIA baseado na documentação.
        
        Args:
            request: Requisição original
            
        Returns:
            Payload formatado para LuzIA
        """
        
        # Prompt aprimorado com contexto COBOL
        enhanced_prompt = self._enhance_prompt_for_cobol(request.prompt, request.context)
        
        # Payload baseado na documentação LuzIA
        payload = {
            "model": self.model,
            "messages": [
                {
                    "role": "user",
                    "content": enhanced_prompt
                }
            ],
            "max_tokens": min(request.max_tokens, self.max_tokens),
            "temperature": request.temperature,
            "api_version": self.api_version,
            
            # Configurações específicas LuzIA
            "use_knowledge_base": True,
            "knowledge_base_id": self.knowledge_base_id,
            "guardrail_id": self.guardrail_id,
            "guardrail_version": self.guardrail_version,
            "performance_config": self.performance_config,
            "auto_refresh_token": self.auto_refresh_token,
            
            # Metadados para auditoria
            "metadata": {
                "source": "COBOL_AI_Engine_v2.1.0",
                "analysis_type": "cobol_program_analysis",
                "timestamp": datetime.now().isoformat()
            }
        }
        
        return payload
    
    def _enhance_prompt_for_cobol(self, prompt: str, context: Dict[str, Any]) -> str:
        """Aprimora prompt com contexto específico para COBOL."""
        
        cobol_context = """
Você é um especialista em análise de programas COBOL com conhecimento profundo em:
- Sistemas bancários e financeiros
- Mainframe IBM z/OS
- Processamento de dados corporativos
- Regras de negócio do setor financeiro
- Arquiteturas de sistemas legados

Contexto específico:
"""
        
        if context:
            if 'program_name' in context:
                cobol_context += f"- Programa: {context['program_name']}\n"
            if 'line_count' in context:
                cobol_context += f"- Linhas de código: {context['line_count']}\n"
        
        cobol_context += """
Forneça uma análise precisa, técnica e orientada ao negócio.
Foque em aspectos funcionais e de negócio, não apenas estrutura técnica.

"""
        
        return cobol_context + prompt
    
    def _make_luzia_request(self, payload: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        Faz requisição para LuzIA.
        
        Args:
            payload: Dados da requisição
            
        Returns:
            Resposta do LuzIA ou None em caso de erro
        """
        
        # Headers com autenticação
        headers = {
            'Authorization': f'{self.token_type} {self.access_token}',
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'X-API-Version': self.api_version
        }
        
        try:
            response = self.session.post(
                f"{self.endpoint}/chat/completions",
                json=payload,
                headers=headers,
                timeout=self.timeout
            )
            
            if response.status_code == 200:
                return response.json()
            elif response.status_code == 401:
                # Token inválido, tentar renovar uma vez
                self.logger.warning("Token LuzIA inválido, tentando renovar...")
                if self._authenticate():
                    headers['Authorization'] = f'{self.token_type} {self.access_token}'
                    response = self.session.post(
                        f"{self.endpoint}/chat/completions",
                        json=payload,
                        headers=headers,
                        timeout=self.timeout
                    )
                    if response.status_code == 200:
                        return response.json()
                
                self.logger.error("Falha na renovação do token LuzIA")
                return None
            elif response.status_code == 429:
                self.logger.warning("Rate limit LuzIA atingido")
                return None
            else:
                self.logger.error(f"Erro LuzIA: {response.status_code} - {response.text}")
                return None
                
        except Exception as e:
            self.logger.error(f"Erro na requisição LuzIA: {str(e)}")
            return None
    
    def _process_luzia_response(self, response_data: Dict[str, Any], response_time: float) -> AIResponse:
        """
        Processa resposta do LuzIA.
        
        Args:
            response_data: Dados da resposta
            response_time: Tempo de resposta
            
        Returns:
            AIResponse processada
        """
        
        try:
            # Extrair conteúdo da resposta
            choices = response_data.get('choices', [])
            if not choices:
                return self._create_error_response("Resposta LuzIA sem choices")
            
            message = choices[0].get('message', {})
            content = message.get('content', '')
            
            if not content:
                return self._create_error_response("Resposta LuzIA vazia")
            
            # Extrair informações de uso
            usage = response_data.get('usage', {})
            total_tokens = usage.get('total_tokens', 0)
            input_tokens = usage.get('prompt_tokens', 0)
            output_tokens = usage.get('completion_tokens', 0)
            
            # Informações do modelo
            model_used = response_data.get('model', self.model)
            
            # Metadados adicionais do LuzIA
            luzia_metadata = response_data.get('metadata', {})
            knowledge_base_used = luzia_metadata.get('knowledge_base_used', False)
            guardrails_applied = luzia_metadata.get('guardrails_applied', False)
            
            # Adicionar metadados LuzIA ao conteúdo
            if knowledge_base_used or guardrails_applied:
                metadata_info = "\n\n---\n**Metadados LuzIA:**\n"
                if knowledge_base_used:
                    metadata_info += "- Knowledge Base COBOL utilizada\n"
                if guardrails_applied:
                    metadata_info += "- Guardrails corporativos aplicados\n"
                content += metadata_info
            
            return AIResponse(
                content=content,
                tokens_used=total_tokens,
                provider_name=self.name,
                model_name=model_used,
                success=True,
                input_tokens=input_tokens,
                output_tokens=output_tokens
            )
            
        except Exception as e:
            self.logger.error(f"Erro ao processar resposta LuzIA: {str(e)}")
            return self._create_error_response(f"Erro no processamento: {str(e)}")
    
    def _apply_rate_limiting(self):
        """Aplica rate limiting específico para LuzIA."""
        if self.rate_limit_delay > 0:
            time.sleep(self.rate_limit_delay)
    
    def get_provider_info(self) -> Dict[str, Any]:
        """Retorna informações específicas do provedor LuzIA."""
        base_info = self.get_statistics()
        
        luzia_info = {
            "endpoint": self.endpoint,
            "model": self.model,
            "api_version": self.api_version,
            "knowledge_base_id": self.knowledge_base_id,
            "guardrail_id": self.guardrail_id,
            "authenticated": bool(self.access_token),
            "token_expires_at": self.token_expires_at.isoformat() if self.token_expires_at else None,
            "auto_refresh_enabled": self.auto_refresh_token,
            "rate_limit_delay": self.rate_limit_delay
        }
        
        base_info.update(luzia_info)
        return base_info

