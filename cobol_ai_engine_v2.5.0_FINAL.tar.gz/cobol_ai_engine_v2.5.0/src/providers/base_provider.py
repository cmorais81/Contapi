"""
COBOL AI Engine v2.1.0 - Base Provider
Interface base para todos os provedores de IA com validação completa.
"""

import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Dict, Any, Optional
from datetime import datetime


@dataclass
class AIRequest:
    """Requisição para análise de IA."""
    prompt: str
    context: Dict[str, Any] = None
    max_tokens: int = 4000
    temperature: float = 0.7
    
    def __post_init__(self):
        if self.context is None:
            self.context = {}


@dataclass
class AIResponse:
    """Resposta de análise de IA."""
    content: str
    tokens_used: int
    provider_name: str
    model_name: str
    success: bool
    error_message: str = ""
    timestamp: str = ""
    input_tokens: int = 0
    output_tokens: int = 0
    prompt_manager: Any = None  # Referência ao gerenciador de prompts
    
    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = datetime.now().isoformat()
        
        # Se não temos breakdown de tokens, estimar
        if self.tokens_used > 0 and self.input_tokens == 0 and self.output_tokens == 0:
            # Estimativa: 70% output, 30% input
            self.output_tokens = int(self.tokens_used * 0.7)
            self.input_tokens = self.tokens_used - self.output_tokens


class BaseAIProvider(ABC):
    """Interface base para provedores de IA."""
    
    def __init__(self, name: str, config: Dict[str, Any]):
        """
        Inicializa o provedor base.
        
        Args:
            name: Nome do provedor
            config: Configuração do provedor
        """
        self.name = name
        self.config = config
        self.logger = logging.getLogger(f"{__name__}.{name}")
        
        # Configurações básicas
        self.enabled = config.get('enabled', True)
        self.max_tokens = config.get('max_tokens', 4000)
        self.temperature = config.get('temperature', 0.7)
        self.timeout = config.get('timeout', 60)
        
        # Estatísticas
        self.total_requests = 0
        self.successful_requests = 0
        self.total_tokens_used = 0
        
        self.logger.debug(f"Provedor {name} inicializado")
    
    @abstractmethod
    def is_available(self) -> bool:
        """
        Verifica se o provedor está disponível.
        
        Returns:
            True se disponível, False caso contrário
        """
        pass
    
    @abstractmethod
    def analyze(self, request: AIRequest) -> AIResponse:
        """
        Realiza análise usando o provedor.
        
        Args:
            request: Requisição de análise
            
        Returns:
            Resposta da análise
        """
        pass
    
    def get_statistics(self) -> Dict[str, Any]:
        """Retorna estatísticas do provedor."""
        success_rate = 0.0
        if self.total_requests > 0:
            success_rate = (self.successful_requests / self.total_requests) * 100
        
        avg_tokens = 0.0
        if self.successful_requests > 0:
            avg_tokens = self.total_tokens_used / self.successful_requests
        
        return {
            "provider_name": self.name,
            "total_requests": self.total_requests,
            "successful_requests": self.successful_requests,
            "success_rate": success_rate,
            "total_tokens_used": self.total_tokens_used,
            "average_tokens_per_request": avg_tokens,
            "enabled": self.enabled
        }
    
    def _update_statistics(self, response: AIResponse):
        """Atualiza estatísticas internas."""
        self.total_requests += 1
        if response.success:
            self.successful_requests += 1
            self.total_tokens_used += response.tokens_used
    
    def _create_error_response(self, error_message: str) -> AIResponse:
        """Cria resposta de erro padronizada."""
        return AIResponse(
            content="",
            tokens_used=0,
            provider_name=self.name,
            model_name="unknown",
            success=False,
            error_message=error_message
        )
    
    def _validate_request(self, request: AIRequest) -> bool:
        """Valida requisição antes do processamento."""
        if not request.prompt or not request.prompt.strip():
            self.logger.error("Prompt vazio ou inválido")
            return False
        
        if request.max_tokens <= 0:
            self.logger.error("max_tokens deve ser maior que zero")
            return False
        
        if not (0.0 <= request.temperature <= 2.0):
            self.logger.error("temperature deve estar entre 0.0 e 2.0")
            return False
        
        return True

