"""
COBOL AI Engine v2.5.0 - Provider Manager Completo
Gerenciador de provedores de IA com todos os métodos implementados.
"""

import logging
import time
from typing import Dict, List, Any, Optional
from datetime import datetime

from .base_provider import BaseAIProvider, AIRequest, AIResponse
from .luzia_provider import LuziaProvider
from .enhanced_mock_provider import EnhancedMockProvider
from .basic_provider import BasicProvider


class ProviderManager:
    """Gerenciador completo de provedores de IA com todos os métodos implementados."""
    
    def __init__(self, config: Dict[str, Any]):
        """Inicializa o gerenciador de provedores."""
        self.config = config
        self.logger = logging.getLogger(__name__)
        self.providers: Dict[str, BaseAIProvider] = {}
        self.statistics: Dict[str, Dict[str, Any]] = {}
        self.primary_provider = None
        self.fallback_providers = []
        
        # Inicializar provedores
        self._initialize_providers()
        
        self.logger.info(f"Provider Manager inicializado - Primário: {self.primary_provider}")
    
    def _initialize_providers(self) -> None:
        """Inicializa todos os provedores configurados."""
        ai_config = self.config.get('ai', {})
        providers_config = ai_config.get('providers', {})
        
        # Definir provedor primário e fallbacks
        self.primary_provider = ai_config.get('primary_provider', 'enhanced_mock')
        self.fallback_providers = ai_config.get('fallback_providers', ['basic'])
        
        # Inicializar provedores disponíveis
        available_providers = {
            'luzia': LuziaProvider,
            'enhanced_mock': EnhancedMockProvider,
            'basic': BasicProvider
        }
        
        for provider_name, provider_class in available_providers.items():
            try:
                provider_config = providers_config.get(provider_name, {})
                if provider_config.get('enabled', False) or provider_name in ['enhanced_mock', 'basic']:
                    # Passar configuração corretamente para cada provedor
                    if provider_name == 'luzia':
                        provider = provider_class(provider_config)
                    elif provider_name == 'enhanced_mock':
                        provider = provider_class(provider_config)
                    elif provider_name == 'basic':
                        provider = provider_class(provider_config)
                    else:
                        provider = provider_class(provider_config)
                    
                    self.providers[provider_name] = provider
                    
                    # Inicializar estatísticas
                    self.statistics[provider_name] = {
                        'total_requests': 0,
                        'successful_requests': 0,
                        'failed_requests': 0,
                        'total_tokens': 0,
                        'average_response_time': 0.0,
                        'last_used': None,
                        'availability_rate': 100.0
                    }
                    
                    self.logger.info(f"Provedor {provider_name} inicializado com sucesso")
                    
            except Exception as e:
                self.logger.error(f"Erro ao inicializar provedor {provider_name}: {str(e)}")
    
    def get_available_providers(self) -> List[str]:
        """Retorna lista de provedores disponíveis."""
        available = []
        for name, provider in self.providers.items():
            try:
                if provider.is_available():
                    available.append(name)
            except Exception as e:
                self.logger.warning(f"Erro ao verificar disponibilidade do provedor {name}: {str(e)}")
        
        return available
    
    def get_provider_statistics(self) -> Dict[str, Dict[str, Any]]:
        """Retorna estatísticas completas de todos os provedores."""
        return self.statistics.copy()
    
    def analyze(self, request: AIRequest) -> AIResponse:
        """Analisa usando o provedor primário com fallback automático."""
        # Tentar provedor primário primeiro
        if self.primary_provider in self.providers:
            response = self._try_provider(self.primary_provider, request)
            if response.success:
                return response
        
        # Tentar provedores de fallback
        for provider_name in self.fallback_providers:
            if provider_name in self.providers:
                response = self._try_provider(provider_name, request)
                if response.success:
                    return response
        
        # Se todos falharam, retornar erro
        return AIResponse(
            content="Erro: Todos os provedores falharam",
            tokens_used=0,
            provider_name="none",
            model_name="none",
            success=False,
            error_message="Nenhum provedor disponível"
        )
    
    def analyze_with_specific_provider(self, request: AIRequest, provider_name: str) -> AIResponse:
        """Analisa usando um provedor específico."""
        if provider_name not in self.providers:
            return AIResponse(
                content=f"Erro: Provedor {provider_name} não encontrado",
                tokens_used=0,
                provider_name=provider_name,
                model_name="none",
                success=False,
                error_message=f"Provedor {provider_name} não configurado"
            )
        
        return self._try_provider(provider_name, request)
    
    def _try_provider(self, provider_name: str, request: AIRequest) -> AIResponse:
        """Tenta usar um provedor específico e atualiza estatísticas."""
        provider = self.providers[provider_name]
        start_time = time.time()
        
        try:
            self.logger.info(f"Tentando análise com provedor: {provider_name}")
            
            # Verificar disponibilidade
            if not provider.is_available():
                self.logger.warning(f"Provedor {provider_name} não disponível")
                self._update_statistics(provider_name, False, 0, time.time() - start_time)
                return AIResponse(
                    content=f"Provedor {provider_name} não disponível",
                    tokens_used=0,
                    provider_name=provider_name,
                    model_name="none",
                    success=False,
                    error_message=f"Provedor {provider_name} não disponível"
                )
            
            # Fazer análise
            response = provider.analyze(request)
            response_time = time.time() - start_time
            
            # Atualizar estatísticas
            self._update_statistics(provider_name, response.success, response.tokens_used, response_time)
            
            if response.success:
                self.logger.info(f"Análise bem-sucedida com provedor: {provider_name}")
            else:
                self.logger.warning(f"Análise falhou com provedor: {provider_name}")
            
            return response
            
        except Exception as e:
            response_time = time.time() - start_time
            error_msg = str(e)
            
            self.logger.error(f"Erro no provedor {provider_name}: {error_msg}")
            self._update_statistics(provider_name, False, 0, response_time)
            
            return AIResponse(
                content=f"Erro no provedor {provider_name}: {error_msg}",
                tokens_used=0,
                provider_name=provider_name,
                model_name="none",
                success=False,
                error_message=error_msg
            )
    
    def _update_statistics(self, provider_name: str, success: bool, tokens: int, response_time: float) -> None:
        """Atualiza estatísticas do provedor."""
        if provider_name not in self.statistics:
            return
        
        stats = self.statistics[provider_name]
        
        # Atualizar contadores
        stats['total_requests'] += 1
        if success:
            stats['successful_requests'] += 1
        else:
            stats['failed_requests'] += 1
        
        # Atualizar tokens
        stats['total_tokens'] += tokens
        
        # Atualizar tempo de resposta médio
        total_requests = stats['total_requests']
        current_avg = stats['average_response_time']
        stats['average_response_time'] = ((current_avg * (total_requests - 1)) + response_time) / total_requests
        
        # Atualizar última utilização
        stats['last_used'] = datetime.now().isoformat()
        
        # Calcular taxa de disponibilidade
        if stats['total_requests'] > 0:
            stats['availability_rate'] = (stats['successful_requests'] / stats['total_requests']) * 100
    
    def get_provider_status(self, provider_name: str) -> Dict[str, Any]:
        """Retorna status detalhado de um provedor específico."""
        if provider_name not in self.providers:
            return {
                'name': provider_name,
                'exists': False,
                'available': False,
                'error': 'Provedor não encontrado'
            }
        
        provider = self.providers[provider_name]
        stats = self.statistics.get(provider_name, {})
        
        try:
            available = provider.is_available()
        except Exception as e:
            available = False
            error = str(e)
        else:
            error = None
        
        return {
            'name': provider_name,
            'exists': True,
            'available': available,
            'enabled': self.config.get('ai', {}).get('providers', {}).get(provider_name, {}).get('enabled', False),
            'statistics': stats,
            'error': error
        }
    
    def get_system_status(self) -> Dict[str, Any]:
        """Retorna status completo do sistema de provedores."""
        available_providers = self.get_available_providers()
        
        return {
            'timestamp': datetime.now().isoformat(),
            'total_providers': len(self.providers),
            'available_providers': len(available_providers),
            'primary_provider': self.primary_provider,
            'primary_available': self.primary_provider in available_providers,
            'fallback_providers': self.fallback_providers,
            'provider_details': {name: self.get_provider_status(name) for name in self.providers.keys()},
            'statistics': self.get_provider_statistics()
        }
    
    def reset_statistics(self) -> None:
        """Reseta todas as estatísticas dos provedores."""
        for provider_name in self.statistics:
            self.statistics[provider_name] = {
                'total_requests': 0,
                'successful_requests': 0,
                'failed_requests': 0,
                'total_tokens': 0,
                'average_response_time': 0.0,
                'last_used': None,
                'availability_rate': 100.0
            }
        
        self.logger.info("Estatísticas dos provedores resetadas")
    
    def set_primary_provider(self, provider_name: str) -> bool:
        """Define um novo provedor primário."""
        if provider_name not in self.providers:
            self.logger.error(f"Tentativa de definir provedor primário inexistente: {provider_name}")
            return False
        
        old_primary = self.primary_provider
        self.primary_provider = provider_name
        
        self.logger.info(f"Provedor primário alterado de {old_primary} para {provider_name}")
        return True
    
    def add_fallback_provider(self, provider_name: str) -> bool:
        """Adiciona um provedor à lista de fallback."""
        if provider_name not in self.providers:
            self.logger.error(f"Tentativa de adicionar provedor fallback inexistente: {provider_name}")
            return False
        
        if provider_name not in self.fallback_providers:
            self.fallback_providers.append(provider_name)
            self.logger.info(f"Provedor {provider_name} adicionado aos fallbacks")
            return True
        
        return False
    
    def remove_fallback_provider(self, provider_name: str) -> bool:
        """Remove um provedor da lista de fallback."""
        if provider_name in self.fallback_providers:
            self.fallback_providers.remove(provider_name)
            self.logger.info(f"Provedor {provider_name} removido dos fallbacks")
            return True
        
        return False
    
    def health_check(self) -> Dict[str, Any]:
        """Executa verificação de saúde em todos os provedores."""
        health_status = {
            'timestamp': datetime.now().isoformat(),
            'overall_health': 'healthy',
            'providers': {}
        }
        
        healthy_count = 0
        total_count = len(self.providers)
        
        for provider_name, provider in self.providers.items():
            try:
                start_time = time.time()
                is_available = provider.is_available()
                response_time = time.time() - start_time
                
                if is_available:
                    healthy_count += 1
                    status = 'healthy'
                else:
                    status = 'unhealthy'
                
                health_status['providers'][provider_name] = {
                    'status': status,
                    'available': is_available,
                    'response_time': response_time,
                    'last_check': datetime.now().isoformat()
                }
                
            except Exception as e:
                health_status['providers'][provider_name] = {
                    'status': 'error',
                    'available': False,
                    'error': str(e),
                    'last_check': datetime.now().isoformat()
                }
        
        # Determinar saúde geral
        if healthy_count == 0:
            health_status['overall_health'] = 'critical'
        elif healthy_count < total_count / 2:
            health_status['overall_health'] = 'degraded'
        
        health_status['healthy_providers'] = healthy_count
        health_status['total_providers'] = total_count
        health_status['health_percentage'] = (healthy_count / total_count) * 100 if total_count > 0 else 0
        
        return health_status

