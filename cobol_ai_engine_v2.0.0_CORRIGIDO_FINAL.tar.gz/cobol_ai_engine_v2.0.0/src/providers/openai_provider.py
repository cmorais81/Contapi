"""
Provedor OpenAI para COBOL AI Engine.
Integração com OpenAI GPT para análise de código COBOL.
"""

import os
import json
import logging
from typing import Dict, Any, Optional
from datetime import datetime

try:
    import openai
    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False

from .base_provider import BaseProvider, AIRequest, AIResponse
from ..core.exceptions import (
    ProviderError, ProviderNotAvailableError, ProviderAuthenticationError,
    ProviderTimeoutError, ProviderQuotaExceededError, ConfigurationError
)


class OpenAIProvider(BaseProvider):
    """
    Provedor OpenAI com integração completa para GPT.
    
    Funcionalidades implementadas:
    - Autenticação via API Key
    - Suporte a múltiplos modelos GPT
    - Rate limiting e controle de tokens
    - Tratamento robusto de erros
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Inicializa o provedor OpenAI.
        
        Args:
            config: Configuração do provedor
        """
        super().__init__(config)
        
        # Verificar dependências
        if not OPENAI_AVAILABLE:
            raise ConfigurationError(
                "Biblioteca 'openai' não está instalada. Execute: pip install openai",
                missing_key="openai"
            )
        
        # Configurações do OpenAI
        self.api_key = config.get('api_key', os.getenv('OPENAI_API_KEY'))
        self.model_name = config.get('model', 'gpt-4')
        self.temperature = config.get('temperature', 0.1)
        self.max_tokens = config.get('max_tokens', 4000)
        self.timeout = config.get('timeout', 60)
        
        # Validar configuração
        if not self.api_key:
            raise ConfigurationError(
                "API key do OpenAI não configurada. Configure a variável OPENAI_API_KEY ou no arquivo de configuração.",
                missing_key="api_key"
            )
        
        # Configurar cliente OpenAI
        self.client = openai.OpenAI(
            api_key=self.api_key,
            base_url="https://api.openai.com/v1"  # Usar URL oficial da OpenAI
        )
        
        self.logger.info(f"OpenAI Provider inicializado - Modelo: {self.model_name}")
    
    def is_available(self) -> bool:
        """
        Verifica se o provedor está disponível.
        
        Returns:
            True se disponível, False caso contrário
        """
        try:
            # Teste simples de conectividade
            response = self.client.models.list()
            return True
        except openai.AuthenticationError as e:
            self.logger.error(f"OpenAI não disponível: {str(e)}")
            return False
        except openai.RateLimitError as e:
            self.logger.error(f"OpenAI não disponível: {str(e)}")
            return False
        except Exception as e:
            self.logger.error(f"OpenAI não disponível: {str(e)}")
            return False
    
    def analyze(self, request: AIRequest) -> AIResponse:
        """
        Realiza análise usando OpenAI.
        
        Args:
            request: Requisição de análise
            
        Returns:
            Resposta da análise
        """
        try:
            start_time = datetime.now()
            
            # Carregar system prompt do arquivo de configuração
            from ..core.config import ConfigManager
            config_manager = ConfigManager("config/config_unified.yaml")
            system_prompt = config_manager.get_system_prompt()
            
            # Preparar mensagens
            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": request.prompt}
            ]
            
            # Fazer chamada para OpenAI
            response = self.client.chat.completions.create(
                model=self.model_name,
                messages=messages,
                temperature=self.temperature,
                max_tokens=self.max_tokens,
                timeout=self.timeout
            )
            
            # Extrair resposta
            content = response.choices[0].message.content
            tokens_used = response.usage.total_tokens
            
            # Calcular tempo
            processing_time = (datetime.now() - start_time).total_seconds()
            
            # Atualizar estatísticas
            self._update_statistics(tokens_used, processing_time, True)
            
            return AIResponse(
                content=content,
                tokens_used=tokens_used,
                processing_time=processing_time,
                provider_name=self.name,
                model_name=self.model_name,
                success=True,
                metadata={
                    'model': self.model_name,
                    'temperature': self.temperature,
                    'max_tokens': self.max_tokens,
                    'finish_reason': response.choices[0].finish_reason
                }
            )
            
        except openai.AuthenticationError as e:
            self.logger.error(f"Erro de autenticação OpenAI: {str(e)}")
            self._update_statistics(0, 0, False)
            
            raise ProviderAuthenticationError(
                provider_name=self.name,
                auth_error=str(e)
            )
            
        except openai.RateLimitError as e:
            self.logger.error(f"Cota excedida OpenAI: {str(e)}")
            self._update_statistics(0, 0, False)
            
            raise ProviderQuotaExceededError(
                provider_name=self.name,
                quota_type="rate_limit"
            )
            
        except openai.APITimeoutError as e:
            self.logger.error(f"Timeout OpenAI: {str(e)}")
            self._update_statistics(0, 0, False)
            
            raise ProviderTimeoutError(
                provider_name=self.name,
                timeout_seconds=self.timeout
            )
            
        except Exception as e:
            self.logger.error(f"Erro na análise OpenAI: {str(e)}")
            self._update_statistics(0, 0, False)
            
            raise ProviderError(
                message=f"Erro inesperado na análise: {str(e)}",
                provider_name=self.name,
                provider_error=str(e)
            )
    
    def get_status(self) -> Dict[str, Any]:
        """
        Retorna status detalhado do provedor.
        
        Returns:
            Dicionário com informações de status
        """
        base_status = super().get_status()
        
        # Adicionar informações específicas do OpenAI
        base_status.update({
            'model': self.model_name,
            'temperature': self.temperature,
            'max_tokens': self.max_tokens,
            'api_key_configured': bool(self.api_key),
            'client_configured': hasattr(self, 'client')
        })
        
        return base_status
    
    def get_model_info(self) -> Dict[str, Any]:
        """
        Retorna informações sobre o modelo.
        
        Returns:
            Informações do modelo
        """
        return {
            'provider': 'OpenAI',
            'model': self.model_name,
            'type': 'Chat Completion',
            'max_tokens': self.max_tokens,
            'temperature': self.temperature,
            'supports_streaming': True,
            'supports_functions': True
        }

