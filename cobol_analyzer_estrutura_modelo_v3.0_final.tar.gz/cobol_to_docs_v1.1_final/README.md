# COBOL Analyzer

Sistema profissional de análise e documentação de programas COBOL com IA.

## 🚀 Funcionalidades

- **Análise Detalhada Padrão**: Máximo detalhamento técnico por padrão
- **Múltiplos Providers**: Luzia, OpenAI, AWS Bedrock, Databricks
- **Sistema RAG**: Auto-learning com base de conhecimento
- **Relatórios Profissionais**: HTML, Markdown, JSON
- **Análise de Copybooks**: Suporte completo a estruturas de dados
- **Cálculo de Custos**: Estimativas precisas por modelo

## 📦 Instalação

```bash
# Extrair o pacote
tar -xzf cobol_analyzer_v3.0.tar.gz
cd cobol_to_docs_v1.1_final/

# Instalar dependências
pip install -r requirements.txt

# Configurar (opcional)
cp config.yaml.example config.yaml
# Editar config.yaml com suas credenciais
```

## 🎯 Uso Básico

### Comando Principal

```bash
python main.py --fontes programas.txt --books copybooks.txt --output resultado
```

### Parâmetros

- `--fontes`: Arquivo com lista de programas COBOL (obrigatório)
- `--books`: Arquivo com lista de copybooks (opcional)
- `--output`: Diretório de saída (padrão: output)
- `--models`: Modelo específico ou lista JSON (opcional)
- `--pdf`: Gerar relatórios HTML/PDF
- `--status`: Verificar status dos providers

### Exemplos

```bash
# Análise básica
python main.py --fontes exemplos/fontes.txt --output analise

# Com copybooks e PDF
python main.py --fontes fontes.txt --books books.txt --output resultado --pdf

# Modelo específico
python main.py --fontes fontes.txt --models luzia --output resultado

# Verificar status
python main.py --status
```

## 📊 Tipos de Análise

### Análise Detalhada (Padrão)

A aplicação executa automaticamente 6 tipos de análise por programa:

1. **🔧 Análise Funcional**: Funcionalidades e sequência de execução
2. **📋 Regras de Negócio**: Algoritmos e validações específicas
3. **📁 Processamento de Arquivos**: Estruturas e operações
4. **✅ Validações**: Tipos de informação e algoritmos
5. **📄 Análise CADOC**: Funcionalidades específicas
6. **⚠️ Tratamento de Erros**: Códigos e recuperação

### Estrutura de Saída

```
resultado/
├── PROGRAMA1_analise_funcional.md      # Análise padrão
├── PROGRAMA2_analise_funcional.md      # Análise padrão
├── analise_detalhada/                  # Análise detalhada
│   ├── PROGRAMA1_funcional_detalhado.md
│   ├── PROGRAMA1_regras_negocio.md
│   ├── PROGRAMA1_validacoes.md
│   ├── relatorio_consolidado.md
│   └── analise_detalhada_completa.json
├── ai_requests/                        # Requests salvos
├── ai_responses/                       # Responses salvos
└── logs/                              # Logs da execução
```

## 🧠 Sistema RAG

O sistema RAG (Retrieval-Augmented Generation) aprende automaticamente:

- **Auto-learning**: Cada análise adiciona conhecimento à base
- **Contexto Inteligente**: Usa conhecimento prévio em novas análises
- **Base Crescente**: Melhora continuamente com o uso
- **Relatórios de Sessão**: Estatísticas de uso do RAG

## ⚙️ Configuração

### Arquivo config.yaml

```yaml
providers:
  luzia:
    enabled: true
    # Suas credenciais aqui
    
rag:
  enabled: true
  auto_learning: true
  
analysis:
  detailed_analysis_enabled: true
  max_tokens_per_request: 15000
```

### Variáveis de Ambiente

```bash
export LUZIA_CLIENT_SECRET="sua_chave_secreta"
export OPENAI_API_KEY="sua_chave_openai"
export AWS_ACCESS_KEY_ID="sua_chave_aws"
```

## 💰 Custos

O sistema calcula custos automaticamente:

- **Estimativas**: Antes da execução
- **Custos Reais**: Durante a análise
- **Breakdown**: Por modelo e programa
- **Relatórios**: Custos detalhados

## 🔧 Troubleshooting

### Problemas Comuns

1. **Provider não disponível**: Sistema usa fallback automático
2. **Arquivo não encontrado**: Verificar caminhos dos arquivos
3. **Erro de parsing**: Verificar formato dos arquivos COBOL
4. **Timeout**: Aumentar timeout na configuração

### Logs

```bash
# Ver logs da última execução
tail -f logs/cobol_analyzer_*.log

# Verificar status dos providers
python main.py --status
```

## 📈 Performance

- **Análise Padrão**: ~2-5 segundos por programa
- **Análise Detalhada**: ~10-30 segundos por programa
- **Tokens Médios**: 2.000-15.000 por programa
- **Throughput**: 10-50 programas por minuto

## 🤝 Suporte

Para suporte técnico:

1. Verificar logs em `logs/`
2. Executar `python main.py --status`
3. Verificar configuração em `config.yaml`
4. Consultar documentação técnica

## 📝 Changelog

### v3.0
- Análise detalhada como padrão
- Sistema RAG com auto-learning
- Interface simplificada
- Logs organizados
- Estrutura limpa

### v2.0
- Múltiplos providers
- Análise ultra-detalhada
- Sistema de custos

### v1.0
- Análise básica COBOL
- Geração de documentação
