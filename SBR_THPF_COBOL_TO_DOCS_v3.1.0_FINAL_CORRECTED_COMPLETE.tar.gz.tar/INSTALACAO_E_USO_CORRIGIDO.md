# Guia de Instalação e Uso - COBOL Analyzer v3.1.0 Corrigido

## Instalação

### 1. Extrair o Pacote
```bash
tar -xzf SBR_THPF_COBOL_TO_DOCS_v3.1.0_FINAL_CORRECTED.tar.gz
cd sbr-thpf-cobol-to-docs-CORRIGIDO-ORIGINAL
```

### 2. Instalar Dependências
```bash
pip install -r requirements.txt
```

### 3. Verificar Instalação
```bash
python3 cobol_to_docs/runner/main.py --help
```

## Uso Básico

### Analisar um Programa Único
```bash
# Criar arquivo com programa COBOL
echo "programa.cbl" > fontes.txt

# Executar análise
python3 cobol_to_docs/runner/main.py --fontes fontes.txt --models enhanced_mock --output resultado
```

### Analisar Múltiplos Programas
```bash
# Criar arquivo com lista de programas
cat > fontes.txt << EOF
programa1.cbl
programa2.cbl
programa3.cbl
EOF

# Executar análise
python3 cobol_to_docs/runner/main.py --fontes fontes.txt --models enhanced_mock --output resultado
```

### Usar Diferentes Providers
```bash
# Enhanced Mock (para testes)
python3 cobol_to_docs/runner/main.py --fontes fontes.txt --models enhanced_mock

# Luzia (requer configuração)
python3 cobol_to_docs/runner/main.py --fontes fontes.txt --models luzia

# Múltiplos modelos
python3 cobol_to_docs/runner/main.py --fontes fontes.txt --models '["enhanced_mock", "luzia"]'
```

## Estrutura de Saída

A aplicação corrigida gera a seguinte estrutura:

```
output/
├── model_enhanced_mock/              # Diretório por provider
│   ├── PROGRAMA-NOME_analise_funcional.md
│   ├── ai_requests/                  # Requests enviados
│   │   └── PROGRAMA-NOME_ai_request.json
│   └── ai_responses/                 # Respostas recebidas
│       └── PROGRAMA-NOME_ai_response.json
├── models/                           # Estrutura de compatibilidade
│   └── enhanced_mock_enhanced-mock-gpt-4/
└── PROGRAMA-NOME_analise_funcional.md  # Arquivo principal
```

## Principais Correções Implementadas

### ✅ Estrutura de Diretórios Corrigida
- Agora usa `model_{provider}` ao invés de `model_{provider}_{model}`
- Subdiretórios corretos: `ai_requests` e `ai_responses`

### ✅ Prompts Completos nos Requests
- Todos os prompts são salvos corretamente nos arquivos JSON
- Inclui system_prompt, full_prompt, original_prompt, main_prompt

### ✅ Nomes de Programas Corretos
- Extrai PROGRAM-ID do código COBOL
- Cada programa é analisado com seu nome correto

### ✅ Processamento de Múltiplos Programas
- Processa todos os programas listados no arquivo fontes
- Cada programa gera sua própria documentação

## Exemplos de Uso

### Exemplo 1: Programa Simples
```cobol
       IDENTIFICATION DIVISION.
       PROGRAM-ID. CALC-INTEREST.
       
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-PRINCIPAL      PIC 9(7)V99 VALUE ZERO.
       01  WS-RATE           PIC 9V9999 VALUE ZERO.
       01  WS-INTEREST       PIC 9(7)V99 VALUE ZERO.
       
       PROCEDURE DIVISION.
       MAIN-PROCESS.
           MOVE 10000.00 TO WS-PRINCIPAL.
           MOVE 0.0525 TO WS-RATE.
           COMPUTE WS-INTEREST = WS-PRINCIPAL * WS-RATE.
           DISPLAY 'INTEREST: ' WS-INTEREST.
           STOP RUN.
```

### Comando de Análise
```bash
echo "calc-interest.cbl" > fontes.txt
python3 cobol_to_docs/runner/main.py --fontes fontes.txt --models enhanced_mock
```

### Resultado Esperado
```
output/
├── model_enhanced_mock/
│   ├── CALC-INTEREST_analise_funcional.md
│   ├── ai_requests/
│   │   └── CALC-INTEREST_ai_request.json
│   └── ai_responses/
│       └── CALC-INTEREST_ai_response.json
└── CALC-INTEREST_analise_funcional.md
```

## Opções Avançadas

### Análise com RAG Ativo
```bash
python3 cobol_to_docs/runner/main.py --fontes fontes.txt --models enhanced_mock --analise-especialista
```

### Geração de HTML/PDF
```bash
python3 cobol_to_docs/runner/main.py --fontes fontes.txt --models enhanced_mock --pdf
```

### Análise Consolidada
```bash
python3 cobol_to_docs/runner/main.py --fontes fontes.txt --models enhanced_mock --consolidado
```

### Verificar Status dos Providers
```bash
python3 cobol_to_docs/runner/main.py --status
```

## Solução de Problemas

### Provider Luzia Falha
**Problema**: Erro de autenticação com Luzia
**Solução**: Configurar credenciais no arquivo de configuração ou usar enhanced_mock para testes

### Arquivo Não Encontrado
**Problema**: Programa COBOL não encontrado
**Solução**: Verificar se o arquivo existe e o caminho está correto no arquivo fontes.txt

### Encoding de Arquivo
**Problema**: Erro de encoding ao ler arquivo COBOL
**Solução**: O parser ultra-robusto trata automaticamente diferentes encodings

## Suporte

Para problemas ou dúvidas:
1. Verificar o arquivo de log gerado
2. Consultar o relatório de correções implementadas
3. Testar com enhanced_mock primeiro

---

**Versão**: 3.1.0 Corrigida  
**Data**: 10 de outubro de 2025  
**Status**: Totalmente funcional
