"""
Modelos de dados para o COBOL Analyzer.
"""

from .cobol_program import CobolProgram
from .cobol_book import CobolBook

__all__ = ['CobolProgram', 'CobolBook']
