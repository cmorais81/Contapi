import requests
import logging
from typing import Dict, Any, Optional, List
from urllib3.exceptions import InsecureRequestWarning
import warnings

from .base_provider import BaseProvider, AIRequest, AIResponse

# Suprimir warnings de SSL
warnings.filterwarnings('ignore', message='Unverified HTTPS request')
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

class LuziaProvider(BaseProvider):  # v732723
    """Provider LuzIA corrigido com URLs e payload corretos da versão funcionando"""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.logger = logging.getLogger('LuziaProvider')
        
        # Obter configurações do LuzIA do config.yaml
        luzia_config = config.get('providers', {}).get('luzia', {})
        self.base_url = luzia_config.get('base_url', 'https://luzia.chat')
        self.api_key = luzia_config.get('api_key', '')
        self.timeout = luzia_config.get('timeout', 300)
        
        self.logger.info(f"LuziaProvider inicializado com base_url: {self.base_url}")
    
    def send_request(self, request: AIRequest) -> AIResponse:
        """
        Envia requisição para o LuzIA usando o formato correto
        """
        try:
            # Extrair dados da requisição
            program_name = request.data.get('program_name', 'UNKNOWN')
            query = request.data.get('input', {}).get('query', [])
            model_config = request.data.get('config', {})
            
            # Construir payload no formato LuzIA
            payload = {
                "input": {
                    "query": query
                },
                "config": {
                    "catena.llm.LLMRouter": {
                        "temperature": model_config.get('temperature', 0.1),
                        "max_tokens": model_config.get('max_tokens', 8000),
                        "routing_model": request.data.get('model', 'aws-claude-3-5-sonnet')
                    }
                }
            }
            
            self.logger.info(f"Enviando requisição para LuzIA - Programa: {program_name}")
            self.logger.info(f"Modelo: {payload['config']['catena.llm.LLMRouter']['routing_model']}")
            self.logger.info(f"Tokens máximos: {payload['config']['catena.llm.LLMRouter']['max_tokens']}")
            
            # Headers
            headers = {
                'Content-Type': 'application/json',
                'Authorization': f'Bearer {self.api_key}' if self.api_key else None
            }
            
            # Remover header None
            headers = {k: v for k, v in headers.items() if v is not None}
            
            # Fazer requisição
            response = requests.post(
                f"{self.base_url}/api/v1/chat/completions",
                json=payload,
                headers=headers,
                timeout=self.timeout,
                verify=False
            )
            
            self.logger.info(f"Status da resposta: {response.status_code}")
            
            if response.status_code == 200:
                response_data = response.json()
                
                # Extrair tokens usados
                usage = response_data.get('usage', {})
                total_tokens = usage.get('total_tokens', 0)
                
                self.logger.info(f"Resposta recebida com sucesso. Tokens usados: {total_tokens}")
                
                return AIResponse(
                    success=True,
                    data=response_data,
                    error=None,
                    provider="luzia",
                    model=payload['config']['catena.llm.LLMRouter']['routing_model'],
                    tokens_used=total_tokens
                )
            else:
                error_msg = f"Erro HTTP {response.status_code}: {response.text}"
                self.logger.error(error_msg)
                
                return AIResponse(
                    success=False,
                    data=None,
                    error=error_msg,
                    provider="luzia",
                    model=request.data.get('model', 'unknown'),
                    tokens_used=0
                )
                
        except requests.exceptions.Timeout:
            error_msg = f"Timeout na requisição para LuzIA (>{self.timeout}s)"
            self.logger.error(error_msg)
            return AIResponse(
                success=False,
                data=None,
                error=error_msg,
                provider="luzia",
                model=request.data.get('model', 'unknown'),
                tokens_used=0
            )
            
        except requests.exceptions.RequestException as e:
            error_msg = f"Erro de conexão com LuzIA: {str(e)}"
            self.logger.error(error_msg)
            return AIResponse(
                success=False,
                data=None,
                error=error_msg,
                provider="luzia",
                model=request.data.get('model', 'unknown'),
                tokens_used=0
            )
            
        except Exception as e:
            error_msg = f"Erro inesperado no LuziaProvider: {str(e)}"
            self.logger.error(error_msg)
            return AIResponse(
                success=False,
                data=None,
                error=error_msg,
                provider="luzia",
                model=request.data.get('model', 'unknown'),
                tokens_used=0
            )
    
    def is_available(self) -> bool:
        """
        Verifica se o LuzIA está disponível
        """
        try:
            response = requests.get(
                f"{self.base_url}/health",
                timeout=10,
                verify=False
            )
            return response.status_code == 200
        except:
            return False
