# COBOL Analysis Engine v4.0

## 1. Visão Geral

O COBOL Analysis Engine é uma ferramenta de linha de comando para analisar programas COBOL utilizando o poder dos modelos de linguagem grande (LLMs). A aplicação lê um conjunto de programas COBOL e seus respectivos copybooks, gera prompts detalhados para análise e consulta um provedor de LLM para obter uma análise aprofundada de cada programa.

## 2. Funcionalidades

- **Parsing de Arquivos COBOL:** Extrai programas de um arquivo `fontes.txt` e copybooks de um arquivo `BOOKS.txt`.
- **Geração de Prompts Configurável:** Utiliza um arquivo `prompts.yaml` para gerar prompts de análise, permitindo fácil customização.
- **Integração com LLMs:** Suporta múltiplos provedores de LLM (atualmente LuzIA e OpenAI), com a seleção e configuração feitas através de variáveis de ambiente.
- **Geração de Relatórios:** Cria relatórios individuais em formato Markdown para cada programa analisado, incluindo o prompt enviado e a resposta recebida da IA.

## 3. Como Usar

### 3.1. Pré-requisitos

- Python 3.11 ou superior
- As bibliotecas `requests` e `pyyaml` (que podem ser instaladas com `pip install requests pyyaml`)

### 3.2. Configuração

1.  **Configurar Provedor de LLM:**

    A aplicação é configurada para usar provedores de LLM através de variáveis de ambiente. Para usar o **LuzIA**, configure as seguintes variáveis:

    ```bash
    export LUZIA_API_URL="<URL_DA_SUA_API_LUZIA>"
    export LUZIA_CLIENT_ID="<SEU_CLIENT_ID_LUZIA>"
    export LUZIA_CLIENT_SECRET="<SEU_CLIENT_SECRET_LUZIA>"
    ```

    Para usar o **OpenAI**, configure a seguinte variável:

    ```bash
    export OPENAI_API_KEY="<SUA_CHAVE_DE_API_OPENAI>"
    ```

2.  **Customizar Prompts (Opcional):**

    Você pode editar o arquivo `/tmp/v4_simple/config/prompts.yaml` para alterar o prompt padrão ou adicionar novos templates de prompt.

### 3.3. Execução

Execute a aplicação a partir da linha de comando, fornecendo os caminhos para os arquivos `fontes.txt`, `BOOKS.txt` e o diretório de saída para os relatórios.

```bash
python3.11 /tmp/v4_simple/main.py -f /caminho/para/fontes.txt -b /caminho/para/BOOKS.txt -o /caminho/para/diretorio_de_saida
```

## 4. Estrutura do Projeto

```
/tmp/v4_simple/
├── config/
│   └── prompts.yaml      # Arquivo de configuração de prompts
├── reports/              # Diretório de saída para os relatórios
├── src/
│   ├── __init__.py
│   ├── llm_provider.py   # Lógica para consulta a LLMs
│   └── parser.py         # Lógica para parsing dos arquivos de entrada
├── main.py               # Arquivo principal da aplicação
├── README.md             # Esta documentação
└── ...                   # Outros arquivos de teste
```

## 5. Possibilidades de Expansão

- **Suporte a Mais Provedores:** Adicionar suporte para outros provedores de LLM, como Databricks e Bedrock, estendendo a `ProviderFactory`.
- **Análise em Lote:** Implementar o processamento em lote para enviar múltiplos programas para análise de uma só vez, otimizando o tempo de processamento.
- **Interface Gráfica:** Desenvolver uma interface gráfica (GUI) para facilitar o uso da ferramenta por usuários não técnicos.
- **Análise de Métricas:** Coletar e exibir métricas sobre as análises, como o tempo médio de processamento e a taxa de sucesso das consultas à IA.

