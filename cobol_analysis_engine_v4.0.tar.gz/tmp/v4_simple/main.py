# -*- coding: utf-8 -*-
"""
COBOL Analysis Engine v4.0 - Análise de programas COBOL com LLMs
"""

import argparse
import os
import yaml
from src.parser import CobolParser
from src.llm_provider import ProviderFactory
import json

class CobolAnalysisApp:
    def __init__(self, config_path):
        self.config = self.load_config(config_path)

    def load_config(self, config_path):
        """Carrega a configuração do arquivo YAML."""
        with open(config_path, 'r', encoding='utf-8') as f:
            return yaml.safe_load(f)

    def run(self, fontes_path, books_path, output_dir):
        """Executa a análise dos programas COBOL."""
        print("Iniciando a análise...")
        # Faz o parsing dos arquivos de entrada
        parser = CobolParser()
        programs = parser.parse_fontes(fontes_path)
        books = parser.parse_books(books_path)

        print(f"{len(programs)} programas encontrados em {fontes_path}")
        print(f"{len(books)} copybooks encontrados em {books_path}")

        # Itera sobre os programas e realiza a análise
        for program in programs:
            self.analyze_program(program, books, output_dir)

        print("Análise concluída.")

    def analyze_program(self, program, books, output_dir):
        """Analisa um único programa COBOL."""
        program_name = program["name"]
        cobol_code = program["code"]

        print(f"Analisando o programa: {program_name}")

        # Encontra os copybooks relevantes para o programa
        relevant_copybooks = self.find_relevant_copybooks(cobol_code, books)

        # Monta o prompt
        prompt = self.build_prompt(program_name, cobol_code, relevant_copybooks)

        # Consulta o LLM (LuzIA como padrão)
        provider = ProviderFactory.get_provider("luzia")
        try:
            result = provider.query(prompt)
        except ValueError as e:
            result = {"success": False, "response": str(e)}

        # Salva o relatório
        self.save_report(program_name, prompt, result, output_dir)

    def find_relevant_copybooks(self, cobol_code, books):
        """Encontra os copybooks mencionados no código COBOL."""
        import re
        copybook_names = re.findall(r"COPY\s+([\w\d-]+)", cobol_code, re.IGNORECASE)
        
        relevant_copybooks = {}
        for name in copybook_names:
            if name in books:
                relevant_copybooks[name] = books[name]
        
        return relevant_copybooks

    def build_prompt(self, program_name, cobol_code, copybooks):
        """Monta o prompt de análise a partir do template."""
        prompt_template = self.config["default_prompt"]
        
        copybooks_str = "\n".join([f"--- {name} ---\n{content}" for name, content in copybooks.items()])
        
        return prompt_template.format(
            program_name=program_name,
            cobol_code=cobol_code,
            copybooks=copybooks_str
        )

    def save_report(self, program_name, prompt, result, output_dir):
        """Salva o relatório de análise em um formato mais detalhado."""
        report_path = os.path.join(output_dir, f"{program_name}_analysis.md")

        with open(report_path, "w", encoding="utf-8") as f:
            f.write(f"# Análise do Programa: {program_name}\n\n")
            f.write("---\n\n")
            f.write("## 📝 Resumo da Análise\n\n")
            f.write(f"**Status:** {'Sucesso' if result['success'] else 'Falha'}\n")
            if 'processing_time' in result:
                f.write(f"**Tempo de Processamento:** {result['processing_time']:.2f} segundos\n")
            f.write("\n")

            f.write("## 🤖 Resposta da IA\n\n")
            if result['success']:
                # Tenta extrair e formatar a resposta JSON aninhada
                try:
                    response_data = result['response']
                    if isinstance(response_data, str):
                        response_data = json.loads(response_data)
                    
                    if 'analysis' in response_data:
                        analysis = response_data['analysis']
                        for section, content in analysis.items():
                            f.write(f"### {section.replace('_', ' ').title()}\n")
                            if isinstance(content, list):
                                for item in content:
                                    f.write(f"- {item}\n")
                            else:
                                f.write(f"{content}\n")
                            f.write("\n")
                    else:
                        f.write("```json\n")
                        f.write(json.dumps(response_data, indent=4, ensure_ascii=False))
                        f.write("\n```\n")

                except (json.JSONDecodeError, TypeError):
                    f.write("```\n")
                    f.write(str(result['response']))
                    f.write("\n```\n")
            else:
                f.write("A análise da IA falhou. Detalhes do erro:\n")
                f.write("```\n")
                f.write(str(result['response']))
                f.write("\n```\n")

            f.write("---\n\n")
            f.write("## 🔍 Prompt Enviado para a IA\n\n")
            f.write("```yaml\n")
            f.write(prompt)
            f.write("\n```\n")

        print(f"Relatório salvo em: {report_path}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="COBOL Analysis Engine v4.0")
    parser.add_argument("-f", "--fontes", required=True, help="Caminho para o arquivo fontes.txt")
    parser.add_argument("-b", "--books", required=True, help="Caminho para o arquivo BOOKS.txt")
    parser.add_argument("-o", "--output", required=True, help="Diretório de saída para os relatórios")
    parser.add_argument("--config", default="/tmp/v4_simple/config/prompts.yaml", help="Caminho para o arquivo de configuração de prompts")
    args = parser.parse_args()

    app = CobolAnalysisApp(args.config)
    app.run(args.fontes, args.books, args.output)

