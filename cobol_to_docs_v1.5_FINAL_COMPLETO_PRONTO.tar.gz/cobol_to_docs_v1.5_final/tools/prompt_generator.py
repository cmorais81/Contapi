#!/usr/bin/env python3
"""
Gerador de Prompts
Gera prompts especializados para análise de programas COBOL.
"""

import os
import sys
import json
import argparse
import logging
from typing import Dict, List, Any, Optional

# Adicionar diretório pai ao path para importar módulos do projeto
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.parsers.cobol_parser import COBOLParser
from src.analyzers.deep_business_analyzer import DeepBusinessAnalyzer
from src.core.prompt_manager_dual import PromptManagerDual
from src.core.config import ConfigManager
from src.rag.rag_integration import RAGIntegration
from src.rag.cobol_rag_system import CobolRAGSystem

def generate_prompt(cobol_file: str, config_file: str, prompt_type: str = 'detailed', 
                   use_rag: bool = True, output_file: Optional[str] = None) -> str:
    """
    Gera um prompt especializado para análise de programa COBOL.
    
    Args:
        cobol_file: Caminho para o arquivo COBOL
        config_file: Caminho para o arquivo de configuração
        prompt_type: Tipo de prompt ('basic', 'detailed', 'advanced')
        use_rag: Se deve usar RAG para enriquecer o prompt
        output_file: Caminho para o arquivo de saída (opcional)
        
    Returns:
        Prompt gerado
    """
    try:
        # Ler código COBOL
        with open(cobol_file, 'r', encoding='utf-8') as f:
            cobol_code = f.read()
        
        # Carregar configuração
        config_manager = ConfigManager(config_file)
        config = config_manager.get_config()
        
        # Analisar código COBOL
        parser = COBOLParser()
        parsed_code = parser.parse(cobol_code)
        
        # Inicializar gerenciador de prompts
        prompt_manager = PromptManagerDual(config)
        
        # Inicializar sistema RAG se solicitado
        rag_system = None
        if use_rag:
            rag_system = CobolRAGSystem(config)
            rag_integration = RAGIntegration(rag_system)
        
        # Gerar prompt base de acordo com o tipo
        if prompt_type == 'basic':
            prompt = prompt_manager.get_basic_analysis_prompt(parsed_code)
        elif prompt_type == 'detailed':
            analyzer = DeepBusinessAnalyzer(config)
            prompt = analyzer.prepare_detailed_prompt(parsed_code)
        elif prompt_type == 'advanced':
            analyzer = DeepBusinessAnalyzer(config)
            prompt = analyzer.prepare_advanced_prompt(parsed_code)
        else:
            raise ValueError(f"Tipo de prompt desconhecido: {prompt_type}")
        
        # Enriquecer prompt com RAG se solicitado
        if use_rag and rag_system:
            prompt = rag_integration.enrich_prompt(prompt, cobol_code)
        
        # Salvar em arquivo se especificado
        if output_file:
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(prompt)
            print(f"Prompt salvo em: {output_file}")
        
        return prompt
        
    except Exception as e:
        print(f"Erro ao gerar prompt: {e}")
        return ""


if __name__ == "__main__":
    # Configuração de logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Argumentos de linha de comando
    parser = argparse.ArgumentParser(description='Gerar prompt para análise de programa COBOL')
    parser.add_argument('--input', required=True, help='Arquivo COBOL de entrada')
    parser.add_argument('--config', default='config/config.yaml', help='Arquivo de configuração')
    parser.add_argument('--type', default='detailed', choices=['basic', 'detailed', 'advanced'], 
                        help='Tipo de prompt a ser gerado')
    parser.add_argument('--no-rag', action='store_true', help='Desativar enriquecimento RAG')
    parser.add_argument('--output', default=None, help='Arquivo de saída para o prompt')
    
    args = parser.parse_args()
    
    # Determinar arquivo de saída se não especificado
    output_file = args.output
    if not output_file:
        input_base = os.path.basename(args.input).split('.')[0]
        output_file = f"{input_base}_{args.type}_prompt.txt"
    
    # Gerar prompt
    prompt = generate_prompt(
        args.input, 
        args.config, 
        args.type, 
        not args.no_rag, 
        output_file
    )
    
    if prompt:
        print(f"Geração de prompt concluída com sucesso!")
        print(f"Tamanho do prompt: {len(prompt)} caracteres")
    else:
        print(f"Erro na geração do prompt. Verifique os logs para mais detalhes.")
        sys.exit(1)
