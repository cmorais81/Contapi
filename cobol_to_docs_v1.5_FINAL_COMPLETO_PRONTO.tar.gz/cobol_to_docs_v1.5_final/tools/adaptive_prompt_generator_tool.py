#!/usr/bin/env python3
"""
Ferramenta de Geração de Prompts Adaptativos
Gera prompts adaptativos baseados na complexidade e domínio do código COBOL.
"""

import os
import sys
import json
import argparse
import logging
from typing import Dict, List, Any, Optional, Tuple

# Adicionar diretório pai ao path para importar módulos do projeto
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.parsers.cobol_parser import COBOLParser
from src.core.adaptive_prompt_generator import AdaptivePromptGenerator
from src.core.config import ConfigManager
from src.rag.rag_integration import RAGIntegration
from src.rag.cobol_rag_system import CobolRAGSystem

def generate_adaptive_prompt(cobol_file: str, config_file: str, prompt_type: str = 'detailed', 
                           use_rag: bool = True, output_file: Optional[str] = None) -> Tuple[str, Dict[str, Any]]:
    """
    Gera um prompt adaptativo baseado na complexidade e domínio do código COBOL.
    
    Args:
        cobol_file: Caminho para o arquivo COBOL
        config_file: Caminho para o arquivo de configuração
        prompt_type: Tipo de prompt ('basic', 'detailed', 'advanced')
        use_rag: Se deve usar RAG para enriquecer o prompt
        output_file: Caminho para o arquivo de saída (opcional)
        
    Returns:
        Tuple com prompt gerado e metadados
    """
    try:
        # Ler código COBOL
        with open(cobol_file, 'r', encoding='utf-8') as f:
            cobol_code = f.read()
        
        # Carregar configuração
        config_manager = ConfigManager(config_file)
        config = config_manager.get_config()
        
        # Analisar código COBOL
        parser = COBOLParser()
        parsed_code = parser.parse(cobol_code)
        
        # Inicializar gerador de prompts adaptativos
        generator = AdaptivePromptGenerator(config)
        
        # Gerar prompt adaptativo
        prompt, metadata = generator.generate_adaptive_prompt(parsed_code, cobol_code, prompt_type)
        
        # Inicializar sistema RAG se solicitado
        if use_rag:
            rag_system = CobolRAGSystem(config)
            rag_integration = RAGIntegration(rag_system)
            prompt = rag_integration.enrich_prompt(prompt, cobol_code)
            metadata['rag_enriched'] = True
        
        # Salvar em arquivo se especificado
        if output_file:
            # Salvar prompt
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(prompt)
            
            # Salvar metadados
            metadata_file = f"{os.path.splitext(output_file)[0]}_metadata.json"
            with open(metadata_file, 'w', encoding='utf-8') as f:
                json.dump(metadata, f, indent=2)
            
            print(f"Prompt salvo em: {output_file}")
            print(f"Metadados salvos em: {metadata_file}")
        
        return prompt, metadata
        
    except Exception as e:
        print(f"Erro ao gerar prompt adaptativo: {e}")
        return "", {}


if __name__ == "__main__":
    # Configuração de logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Argumentos de linha de comando
    parser = argparse.ArgumentParser(description='Gerar prompt adaptativo para análise de programa COBOL')
    parser.add_argument('--input', required=True, help='Arquivo COBOL de entrada')
    parser.add_argument('--config', default='config/config.yaml', help='Arquivo de configuração')
    parser.add_argument('--type', default='detailed', choices=['basic', 'detailed', 'advanced'], 
                        help='Tipo de prompt a ser gerado')
    parser.add_argument('--no-rag', action='store_true', help='Desativar enriquecimento RAG')
    parser.add_argument('--output', default=None, help='Arquivo de saída para o prompt')
    
    args = parser.parse_args()
    
    # Determinar arquivo de saída se não especificado
    output_file = args.output
    if not output_file:
        input_base = os.path.basename(args.input).split('.')[0]
        output_file = f"{input_base}_adaptive_{args.type}_prompt.txt"
    
    # Gerar prompt adaptativo
    prompt, metadata = generate_adaptive_prompt(
        args.input, 
        args.config, 
        args.type, 
        not args.no_rag, 
        output_file
    )
    
    if prompt:
        print(f"Geração de prompt adaptativo concluída com sucesso!")
        print(f"Tamanho do prompt: {len(prompt)} caracteres")
        print(f"Complexidade: {metadata.get('complexity', 'N/A'):.2f}/10")
        print(f"Domínio: {metadata.get('domain', 'N/A')} (confiança: {metadata.get('domain_confidence', 0):.2f})")
    else:
        print(f"Erro na geração do prompt adaptativo. Verifique os logs para mais detalhes.")
        sys.exit(1)
