#!/usr/bin/env python3
"""
COBOL to Docs v1.5 Professional
Sistema de análise e documentação de programas COBOL com foco em sistemas CADOC.
"""

import os
import sys
import argparse
import logging
import json
import datetime
import time
from typing import Dict, List, Any, Optional, Tuple

# Importar módulos do sistema
from src.core.config import ConfigManager
from src.core.intelligent_model_selector import ModelSelector
from src.core.detailed_prompt_generator import DetailedPromptGenerator
from src.core.adaptive_prompt_manager import AdaptivePromptManager
from src.parsers.cobol_parser import COBOLParser
from src.analyzers.enhanced_cobol_analyzer import EnhancedCOBOLAnalyzer
from src.analyzers.deep_business_analyzer import DeepBusinessAnalyzer
from src.analyzers.professional_analyzer import ProfessionalAnalyzer
from src.analyzers.copybook_analyzer import CopybookAnalyzer
from src.analyzers.interface_analyzer import InterfaceAnalyzer
from src.analyzers.copybook_strategy import CopybookStrategyManager, CopybookStrategy
from src.generators.documentation_generator import DocumentationGenerator
from src.providers.enhanced_provider_manager import EnhancedProviderManager
from src.providers.base_provider import AIRequest, AIResponse
from src.rag.rag_integration import RAGIntegration
from src.rag.cobol_rag_system import CobolRAGSystem
from src.utils.cost_calculator import CostCalculator
from src.utils.technical_style_filter import TechnicalStyleFilter
from src.utils.essential_knowledge_filter import EssentialKnowledgeFilter

# Importar funções de processamento
from process_detailed_analysis import process_detailed_analysis
from process_advanced_consolidated_analysis import process_advanced_consolidated_analysis
from ensure_rag_base import ensure_rag_base_integrity

# Configuração de logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler('cobol_to_docs.log')
    ]
)

logger = logging.getLogger(__name__)

def parse_arguments():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(description='COBOL to Docs v1.5 Professional - Análise e documentação de programas COBOL')
    
    parser.add_argument('--fontes', required=True, help='Arquivo ou diretório com programas COBOL')
    parser.add_argument('--output', default=None, help='Diretório de saída para os resultados')
    parser.add_argument('--config', default='config/config.yaml', help='Arquivo de configuração')
    parser.add_argument('--models', default='enhanced_mock', help='Modelos LLM a serem utilizados (separados por vírgula)')
    parser.add_argument('--auto-model', action='store_true', help='Selecionar modelo automaticamente baseado na complexidade')
    parser.add_argument('--model-comparison', action='store_true', help='Exibir comparação de adequação dos modelos')
    parser.add_argument('--basic-analysis', action='store_true', help='Realizar apenas análise básica (desativa análise aprofundada)')
    parser.add_argument('--extract-formulas', action='store_true', help='Extrair fórmulas matemáticas do código')
    parser.add_argument('--no-rag', action='store_true', help='Desativar sistema RAG')
    parser.add_argument('--verbose', action='store_true', help='Exibir informações detalhadas durante o processamento')
    
    return parser.parse_args()

def process_cobol_files(args):
    """Process COBOL files based on command line arguments."""
    try:
        # Verificar integridade da base RAG
        ensure_rag_base_integrity()
        
        # Carregar configuração
        config_manager = ConfigManager(args.config)
        config = config_manager.get_config()
        
        # Configurar logging
        if args.verbose:
            logging.getLogger().setLevel(logging.DEBUG)
        
        # Determinar diretório de saída
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        output_dir = args.output
        
        # Determinar tipo de análise
        # Por padrão, usar análise aprofundada a menos que --basic-analysis seja especificado
        use_basic_analysis = args.basic_analysis
        use_deep_analysis = not use_basic_analysis
        
        # Inicializar filtros de estilo profissional (sempre ativos por padrão)
        technical_style_filter = TechnicalStyleFilter()
        essential_knowledge_filter = EssentialKnowledgeFilter()
        
        # Inicializar estratégia de copybooks (sempre ativa por padrão)
        copybook_strategy = CopybookStrategyManager(CopybookStrategy.VERIFIED_ONLY)
        
        if use_deep_analysis:
            # Análise detalhada
            output_dir = output_dir or f"analise_detalhada_{timestamp}"
            return process_detailed_analysis(args, config, output_dir, 
                                           technical_style_filter=technical_style_filter,
                                           essential_knowledge_filter=essential_knowledge_filter,
                                           copybook_strategy=copybook_strategy)
        else:
            # Análise básica
            output_dir = output_dir or f"analise_basica_{timestamp}"
            
            # Criar diretório de saída
            os.makedirs(output_dir, exist_ok=True)
            
            # Inicializar calculadora de custos
            cost_calculator = CostCalculator()
            
            # Inicializar gerenciador de provedores
            provider_manager = EnhancedProviderManager(config)
            
            # Inicializar sistema RAG se não estiver desativado
            rag_system = None
            if not args.no_rag:
                rag_system = CobolRAGSystem(config)
                rag_integration = RAGIntegration(rag_system)
            
            # Inicializar analisador profissional (sempre ativo por padrão)
            professional_analyzer = ProfessionalAnalyzer()
            
            # Inicializar seletor de modelos
            model_selector = ModelSelector(config)
            
            # Determinar arquivos COBOL a serem processados
            cobol_files = []
            if os.path.isdir(args.fontes):
                for root, _, files in os.walk(args.fontes):
                    for file in files:
                        if file.lower().endswith(('.cbl', '.cob', '.cobol')):
                            cobol_files.append(os.path.join(root, file))
            else:
                cobol_files = [args.fontes]
            
            # Processar cada arquivo COBOL
            for cobol_file in cobol_files:
                try:
                    # Extrair nome do programa
                    program_name = os.path.basename(cobol_file).split('.')[0]
                    logger.info(f"Processando programa: {program_name}")
                    
                    # Criar diretório para o programa
                    program_dir = os.path.join(output_dir, program_name)
                    os.makedirs(program_dir, exist_ok=True)
                    
                    # Ler código COBOL
                    with open(cobol_file, 'r', encoding='utf-8') as f:
                        cobol_code = f.read()
                    
                    # Analisar código COBOL
                    parser = COBOLParser()
                    parsed_code = parser.parse(cobol_code)
                    
                    # Selecionar modelo automaticamente se solicitado
                    models = args.models.split(',')
                    if args.auto_model:
                        recommended_model = model_selector.select_model(cobol_code)
                        logger.info(f"Modelo recomendado: {recommended_model['model']}")
                        models = [recommended_model['model']]
                        
                        # Salvar justificativa da seleção
                        with open(os.path.join(program_dir, f"{program_name}_model_selection.json"), 'w', encoding='utf-8') as f:
                            json.dump(recommended_model, f, indent=2)
                    
                    # Processar com cada modelo
                    for model in models:
                        model_dir = os.path.join(program_dir, f"model_{model}")
                        os.makedirs(model_dir, exist_ok=True)
                        
                        # Diretórios para requisições e respostas
                        ai_requests_dir = os.path.join(model_dir, "ai_requests")
                        ai_responses_dir = os.path.join(model_dir, "ai_responses")
                        os.makedirs(ai_requests_dir, exist_ok=True)
                        os.makedirs(ai_responses_dir, exist_ok=True)
                        
                        # Criar analisador COBOL
                        analyzer = EnhancedCOBOLAnalyzer(config)
                        
                        # Preparar prompt
                        prompt = analyzer.prepare_prompt(parsed_code)
                        
                        # Enriquecer prompt com RAG se disponível
                        if rag_system:
                            prompt = rag_integration.enrich_prompt(prompt, cobol_code)
                        
                        # Criar requisição AI
                        request = AIRequest(
                            model=model,
                            prompt=prompt,
                            max_tokens=4000,
                            temperature=0.1
                        )
                        
                        # Salvar requisição
                        request_file = os.path.join(ai_requests_dir, f"{program_name}_ai_request.json")
                        with open(request_file, 'w', encoding='utf-8') as f:
                            json.dump(request.to_dict(), f, indent=2)
                        
                        # Enviar requisição ao provedor
                        logger.info(f"Enviando requisição para modelo: {model}")
                        response = provider_manager.analyze_with_model(request)
                        
                        # Registrar custo
                        cost_calculator.add_request(model, request.prompt, response.content)
                        
                        # Salvar resposta
                        response_file = os.path.join(ai_responses_dir, f"{program_name}_ai_response.json")
                        with open(response_file, 'w', encoding='utf-8') as f:
                            json.dump(response.to_dict(), f, indent=2)
                        
                        # Gerar documentação
                        doc_generator = DocumentationGenerator()
                        
                        # Aplicar filtros de estilo profissional (sempre ativos por padrão)
                        analysis_content = response.content
                        
                        # 1. Aplicar filtro de conhecimento essencial
                        analysis_content = essential_knowledge_filter.filter_knowledge_section(analysis_content)
                        
                        # 2. Realizar análise profissional
                        prof_result = professional_analyzer.analyze_program(
                            program_name, 
                            cobol_code, 
                            analysis_content
                        )
                        analysis_content = prof_result['analysis']
                        
                        # 3. Aplicar filtro de estilo técnico
                        analysis_content = technical_style_filter.apply_filter(analysis_content)
                        
                        # 4. Adicionar nota sobre estratégia de copybooks
                        copybook_note = copybook_strategy.get_copybook_documentation_note()
                        if "## Copybooks" not in analysis_content:
                            analysis_content += f"\n\n## Copybooks\n\n{copybook_note}\n"
                        else:
                            analysis_content = analysis_content.replace("## Copybooks", f"## Copybooks\n\n{copybook_note}")
                        
                        # Salvar análise de qualidade
                        quality_file = os.path.join(model_dir, f"{program_name}_quality_validation.json")
                        with open(quality_file, 'w', encoding='utf-8') as f:
                            json.dump(prof_result['quality_validation'], f, indent=2)
                        
                        # Gerar documentação final
                        doc_file = os.path.join(model_dir, f"{program_name}_analise_funcional.md")
                        doc_generator.generate_markdown(program_name, analysis_content, doc_file)
                        
                        logger.info(f"Documentação gerada: {doc_file}")
                    
                    # Gerar relatório de custos
                    cost_report = cost_calculator.generate_report()
                    cost_report_file = os.path.join(output_dir, "relatorio_custos.txt")
                    with open(cost_report_file, 'w', encoding='utf-8') as f:
                        f.write(cost_report)
                    
                except Exception as e:
                    logger.error(f"Erro ao processar {cobol_file}: {e}")
            
            logger.info(f"Processamento concluído. Resultados em: {output_dir}")
            return output_dir
            
    except Exception as e:
        logger.error(f"Erro no processamento: {e}")
        return None

def main():
    """Main function."""
    args = parse_arguments()
    output_dir = process_cobol_files(args)
    
    if output_dir:
        print(f"\nProcessamento concluído com sucesso!")
        print(f"Resultados disponíveis em: {output_dir}")
    else:
        print("\nErro no processamento. Verifique os logs para mais detalhes.")
        sys.exit(1)

if __name__ == "__main__":
    main()
