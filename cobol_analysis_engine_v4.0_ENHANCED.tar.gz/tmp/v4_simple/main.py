# -*- coding: utf-8 -*-
"""
COBOL Analysis Engine v4.0 - Análise de programas COBOL com LLMs
"""

import argparse
import os
import yaml
import json
import logging
from src.parser import CobolParser
from src.providers import ProviderManager

# Configuração de logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class CobolAnalysisApp:
    def __init__(self, config_path):
        self.config = self.load_config(config_path)
        self.provider_manager = ProviderManager(self.config['providers'])
        
    def load_config(self, config_path):
        """Carrega a configuração do arquivo YAML."""
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f)
            
            # Resolve variáveis de ambiente
            config = self._resolve_env_variables(config)
            return config
        except Exception as e:
            logger.error(f"Erro ao carregar configuração: {e}")
            raise

    def _resolve_env_variables(self, obj):
        """Resolve variáveis de ambiente recursivamente."""
        if isinstance(obj, dict):
            return {k: self._resolve_env_variables(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [self._resolve_env_variables(item) for item in obj]
        elif isinstance(obj, str) and obj.startswith('${') and obj.endswith('}'):
            env_var = obj[2:-1]
            return os.environ.get(env_var, '')
        else:
            return obj

    def run(self, fontes_path, books_path, output_dir):
        """Executa a análise dos programas COBOL."""
        logger.info("Iniciando COBOL Analysis Engine v4.0")
        
        # Verifica status dos provedores
        provider_status = self.provider_manager.get_provider_status()
        logger.info(f"Status dos provedores: {provider_status}")
        
        # Cria diretório de saída se não existir
        os.makedirs(output_dir, exist_ok=True)
        
        # Faz o parsing dos arquivos de entrada
        parser = CobolParser()
        programs = parser.parse_fontes(fontes_path)
        books = parser.parse_books(books_path)

        logger.info(f"{len(programs)} programas encontrados em {fontes_path}")
        logger.info(f"{len(books)} copybooks encontrados em {books_path}")

        # Itera sobre os programas e realiza a análise
        successful_analyses = 0
        for i, program in enumerate(programs, 1):
            logger.info(f"Processando programa {i}/{len(programs)}: {program['name']}")
            
            try:
                success = self.analyze_program(program, books, output_dir)
                if success:
                    successful_analyses += 1
            except Exception as e:
                logger.error(f"Erro ao processar {program['name']}: {e}")

        logger.info(f"Análise concluída: {successful_analyses}/{len(programs)} programas processados com sucesso")

    def analyze_program(self, program, books, output_dir):
        """Analisa um único programa COBOL."""
        program_name = program["name"]
        cobol_code = program["code"]

        logger.info(f"Analisando o programa: {program_name}")

        # Encontra os copybooks relevantes para o programa
        relevant_copybooks = self.find_relevant_copybooks(cobol_code, books)
        logger.info(f"Copybooks relevantes encontrados: {list(relevant_copybooks.keys())}")

        # Monta o prompt
        prompt = self.build_prompt(program_name, cobol_code, relevant_copybooks)
        
        # Verifica se deve usar múltiplos modelos LuzIA
        use_multiple_models = self.config.get('analysis', {}).get('use_multiple_models', False)
        
        if use_multiple_models:
            logger.info("Usando múltiplos modelos LuzIA")
            result = self.provider_manager.query_multiple_models(prompt, 'luzia')
        else:
            # Consulta com fallback automático entre provedores
            result = self.provider_manager.query(prompt)

        # Salva o relatório
        self.save_report(program_name, prompt, result, output_dir)
        
        return result['success']

    def find_relevant_copybooks(self, cobol_code, books):
        """Encontra os copybooks mencionados no código COBOL."""
        import re
        copybook_names = re.findall(r"COPY\s+([\w\d-]+)", cobol_code, re.IGNORECASE)
        
        relevant_copybooks = {}
        for name in copybook_names:
            # Busca exata e busca parcial
            if name in books:
                relevant_copybooks[name] = books[name]
            else:
                # Busca parcial (case insensitive)
                for book_name, book_content in books.items():
                    if name.upper() in book_name.upper():
                        relevant_copybooks[book_name] = book_content
                        break
        
        return relevant_copybooks

    def build_prompt(self, program_name, cobol_code, copybooks):
        """Monta o prompt de análise a partir do template."""
        prompt_template = self.config.get("default_prompt", "")
        
        if not prompt_template:
            # Prompt padrão se não configurado
            prompt_template = """
Analise o programa COBOL abaixo:

**PROGRAMA:** {program_name}

**CÓDIGO COBOL:**
```cobol
{cobol_code}
```

**COPYBOOKS:**
```
{copybooks}
```

Forneça uma análise detalhada incluindo objetivo, regras de negócio e aspectos técnicos.
"""
        
        copybooks_str = "\n".join([f"--- {name} ---\n{content}" for name, content in copybooks.items()])
        
        return prompt_template.format(
            program_name=program_name,
            cobol_code=cobol_code,
            copybooks=copybooks_str
        )

    def save_report(self, program_name, prompt, result, output_dir):
        """Salva o relatório de análise em um formato detalhado."""
        report_path = os.path.join(output_dir, f"{program_name}_analysis.md")

        with open(report_path, "w", encoding="utf-8") as f:
            f.write(f"# Análise do Programa: {program_name}\n\n")
            f.write("---\n\n")
            
            # Metadados da análise
            f.write("## Metadados da Análise\n\n")
            f.write(f"**Status:** {'✅ Sucesso' if result['success'] else '❌ Falha'}\n")
            f.write(f"**Provedor:** {result.get('provider', 'N/A')}\n")
            f.write(f"**Modelo:** {result.get('model', 'N/A')}\n")
            
            if 'processing_time' in result:
                f.write(f"**Tempo de Processamento:** {result['processing_time']:.2f} segundos\n")
            
            if 'attempt' in result:
                f.write(f"**Tentativas:** {result['attempt']}\n")
                
            if 'chunks_processed' in result:
                f.write(f"**Chunks Processados:** {result['chunks_processed']}\n")
                f.write(f"**Chunks Bem-sucedidos:** {result['chunks_successful']}\n")
            
            f.write("\n")

            # Resposta da IA
            f.write("## Resposta da IA\n\n")
            if result['success']:
                try:
                    response_data = result['response']
                    
                    # Se é um dict, tenta formatar melhor
                    if isinstance(response_data, dict):
                        if 'analysis' in response_data:
                            f.write(response_data['analysis'])
                        else:
                            f.write("```json\n")
                            f.write(json.dumps(response_data, indent=4, ensure_ascii=False))
                            f.write("\n```\n")
                    else:
                        f.write(str(response_data))
                        
                except Exception as e:
                    f.write(f"Erro ao formatar resposta: {e}\n")
                    f.write("```\n")
                    f.write(str(result['response']))
                    f.write("\n```\n")
            else:
                f.write("A análise falhou. Detalhes do erro:\n\n")
                f.write("```\n")
                f.write(str(result['response']))
                f.write("\n```\n")

            # Prompt enviado
            f.write("\n---\n\n")
            f.write("## Prompt Enviado\n\n")
            f.write("```yaml\n")
            f.write(prompt)
            f.write("\n```\n")
            
            # Informações adicionais se houver
            if 'providers_tried' in result:
                f.write("\n---\n\n")
                f.write("## Provedores Tentados\n\n")
                for provider in result['providers_tried']:
                    f.write(f"- {provider}\n")

        logger.info(f"Relatório salvo em: {report_path}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="COBOL Analysis Engine v4.0")
    parser.add_argument("-f", "--fontes", required=True, help="Caminho para o arquivo fontes.txt")
    parser.add_argument("-b", "--books", required=True, help="Caminho para o arquivo BOOKS.txt")
    parser.add_argument("-o", "--output", required=True, help="Diretório de saída para os relatórios")
    parser.add_argument("--config", default="/tmp/v4_simple/config/config.yaml", help="Caminho para o arquivo de configuração")
    args = parser.parse_args()

    try:
        app = CobolAnalysisApp(args.config)
        app.run(args.fontes, args.books, args.output)
    except Exception as e:
        logger.error(f"Erro na execução: {e}")
        exit(1)
