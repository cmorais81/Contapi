# -*- coding: utf-8 -*-
"""Factory para criar e gerenciar provedores de LLM."""

import logging
from typing import Dict, Any, List, Optional
from .luzia_provider import LuziaProvider
from .openai_provider import OpenAIProvider

logger = logging.getLogger(__name__)

class ProviderFactory:
    """Factory para criar instâncias de provedores de LLM."""
    
    PROVIDER_CLASSES = {
        'luzia': LuziaProvider,
        'openai': OpenAIProvider,
        # Adicionar outros provedores aqui
        # 'databricks': DatabricksProvider,
        # 'bedrock': BedrockProvider,
    }
    
    @classmethod
    def create_provider(cls, provider_name: str, config: Dict[str, Any]):
        """
        Cria uma instância do provedor especificado.
        
        Args:
            provider_name: Nome do provedor (luzia, openai, etc.)
            config: Configuração do provedor
            
        Returns:
            Instância do provedor ou None se não encontrado
        """
        provider_class = cls.PROVIDER_CLASSES.get(provider_name.lower())
        
        if not provider_class:
            logger.error(f"Provedor desconhecido: {provider_name}")
            return None
        
        try:
            provider = provider_class(config)
            logger.info(f"Provedor {provider_name} criado com sucesso")
            return provider
        except Exception as e:
            logger.error(f"Erro ao criar provedor {provider_name}: {e}")
            return None
    
    @classmethod
    def get_available_providers(cls, providers_config: Dict[str, Any]) -> List[str]:
        """
        Retorna lista de provedores disponíveis e habilitados.
        
        Args:
            providers_config: Configuração de todos os provedores
            
        Returns:
            Lista de nomes de provedores disponíveis
        """
        available = []
        
        for provider_name, config in providers_config.items():
            if config.get('enabled', False):
                if provider_name.lower() in cls.PROVIDER_CLASSES:
                    available.append(provider_name)
                else:
                    logger.warning(f"Provedor {provider_name} habilitado mas não implementado")
        
        # Ordena por prioridade
        available.sort(key=lambda x: providers_config[x].get('priority', 999))
        
        return available
    
    @classmethod
    def create_all_enabled_providers(cls, providers_config: Dict[str, Any]) -> Dict[str, Any]:
        """
        Cria instâncias de todos os provedores habilitados.
        
        Args:
            providers_config: Configuração de todos os provedores
            
        Returns:
            Dict com instâncias dos provedores criados
        """
        providers = {}
        available_names = cls.get_available_providers(providers_config)
        
        for provider_name in available_names:
            config = providers_config[provider_name]
            provider = cls.create_provider(provider_name, config)
            
            if provider:
                providers[provider_name] = provider
            else:
                logger.warning(f"Falha ao criar provedor {provider_name}")
        
        logger.info(f"Provedores criados: {list(providers.keys())}")
        return providers

class ProviderManager:
    """Gerenciador de provedores de LLM com fallback automático."""
    
    def __init__(self, providers_config: Dict[str, Any]):
        self.providers_config = providers_config
        self.providers = ProviderFactory.create_all_enabled_providers(providers_config)
        self.provider_order = ProviderFactory.get_available_providers(providers_config)
    
    def query(self, prompt: str, preferred_provider: str = None, model: str = None) -> Dict[str, Any]:
        """
        Consulta provedores com fallback automático.
        
        Args:
            prompt: O prompt para análise
            preferred_provider: Provedor preferido (opcional)
            model: Modelo específico (opcional)
            
        Returns:
            Resultado da consulta
        """
        # Define ordem de tentativa
        if preferred_provider and preferred_provider in self.providers:
            order = [preferred_provider] + [p for p in self.provider_order if p != preferred_provider]
        else:
            order = self.provider_order
        
        last_error = None
        
        for provider_name in order:
            if provider_name not in self.providers:
                continue
                
            provider = self.providers[provider_name]
            logger.info(f"Tentando provedor: {provider_name}")
            
            try:
                # Usa chunking se o prompt for muito grande
                if hasattr(provider, 'analyze_with_chunking'):
                    result = provider.analyze_with_chunking(prompt, model)
                else:
                    result = provider.query(prompt, model)
                
                if result['success']:
                    logger.info(f"Sucesso com provedor: {provider_name}")
                    return result
                else:
                    last_error = result['response']
                    logger.warning(f"Provedor {provider_name} falhou: {last_error}")
                    
            except Exception as e:
                last_error = str(e)
                logger.error(f"Erro no provedor {provider_name}: {last_error}")
        
        # Se todos falharam
        return {
            "success": False,
            "response": f"Todos os provedores falharam. Último erro: {last_error}",
            "processing_time": 0,
            "providers_tried": order
        }
    
    def query_multiple_models(self, prompt: str, provider_name: str = 'luzia') -> Dict[str, Any]:
        """
        Consulta múltiplos modelos de um provedor específico.
        
        Args:
            prompt: O prompt para análise
            provider_name: Nome do provedor
            
        Returns:
            Resultado da consulta
        """
        if provider_name not in self.providers:
            return {
                "success": False,
                "response": f"Provedor {provider_name} não disponível",
                "processing_time": 0
            }
        
        provider = self.providers[provider_name]
        
        # Se o provedor suporta múltiplos modelos
        if hasattr(provider, 'query_with_multiple_models'):
            return provider.query_with_multiple_models(prompt)
        else:
            # Fallback para consulta normal
            return provider.query(prompt)
    
    def get_provider_status(self) -> Dict[str, Any]:
        """Retorna status de todos os provedores."""
        status = {}
        
        for name, provider in self.providers.items():
            try:
                auth_status = provider.authenticate()
                models = provider.get_available_models()
                
                status[name] = {
                    "available": True,
                    "authenticated": auth_status,
                    "models": models,
                    "priority": self.providers_config[name].get('priority', 999)
                }
            except Exception as e:
                status[name] = {
                    "available": False,
                    "error": str(e),
                    "priority": self.providers_config[name].get('priority', 999)
                }
        
        return status
