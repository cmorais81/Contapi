# -*- coding: utf-8 -*-
"""Provedor LuzIA para análise de programas COBOL."""

import os
import requests
import json
import time
import logging
from typing import Dict, Any
from .base_provider import BaseLLMProvider

logger = logging.getLogger(__name__)

class LuziaProvider(BaseLLMProvider):
    """Provedor para a API LuzIA com suporte a múltiplos modelos."""

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.api_url = self._resolve_env_var(config.get('api_url'))
        self.client_id = self._resolve_env_var(config.get('client_id'))
        self.client_secret = self._resolve_env_var(config.get('client_secret'))
        self.token = None
        self.token_expiry = 0
        
    def _resolve_env_var(self, value: str) -> str:
        """Resolve variáveis de ambiente no formato ${VAR_NAME}."""
        if value and value.startswith('${') and value.endswith('}'):
            env_var = value[2:-1]
            return os.environ.get(env_var, '')
        return value or ''
    
    def authenticate(self) -> bool:
        """Obtém ou renova o token de autenticação."""
        try:
            # Verifica se o token ainda é válido
            if time.time() < self.token_expiry and self.token:
                return True
            
            if not all([self.api_url, self.client_id, self.client_secret]):
                logger.error("Credenciais LuzIA não configuradas corretamente")
                return False
            
            token_url = f"{self.api_url}/api/v1/auth/token"
            payload = {
                "client_id": self.client_id,
                "client_secret": self.client_secret,
                "grant_type": "client_credentials"
            }
            headers = {'Content-Type': 'application/x-www-form-urlencoded'}
            
            logger.info(f"Autenticando com LuzIA: {token_url}")
            
            response = requests.post(
                token_url, 
                data=payload, 
                headers=headers, 
                verify=False, 
                timeout=self.timeout
            )
            response.raise_for_status()
            
            token_data = response.json()
            self.token = token_data["access_token"]
            # Define a expiração para 5 minutos antes do tempo real para segurança
            self.token_expiry = time.time() + token_data.get("expires_in", 3600) - 300
            
            logger.info("Autenticação LuzIA realizada com sucesso")
            return True
            
        except Exception as e:
            logger.error(f"Erro na autenticação LuzIA: {e}")
            return False
    
    def _make_request(self, prompt: str, model: str, max_tokens: int) -> Dict[str, Any]:
        """Faz a requisição para a API LuzIA."""
        if not self.token:
            raise Exception("Token de autenticação não disponível")
        
        query_url = f"{self.api_url}/api/v1/analysis"
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json"
        }
        
        # Monta o payload baseado no modelo selecionado
        payload = {
            "prompt": prompt,
            "model": model,
            "max_tokens": max_tokens,
            "temperature": 0.1,
            "stream": False
        }
        
        logger.info(f"Enviando requisição para LuzIA com modelo {model}")
        logger.debug(f"Payload: {json.dumps(payload, indent=2)}")
        
        response = requests.post(
            query_url, 
            json=payload, 
            headers=headers, 
            verify=False, 
            timeout=self.timeout
        )
        response.raise_for_status()
        
        result = response.json()
        logger.info("Resposta recebida da LuzIA com sucesso")
        
        return result
    
    def query_with_multiple_models(self, prompt: str, models: list = None) -> Dict[str, Any]:
        """
        Consulta múltiplos modelos LuzIA e retorna o melhor resultado.
        
        Args:
            prompt: O prompt para análise
            models: Lista de modelos para usar (opcional)
            
        Returns:
            Dict com o melhor resultado obtido
        """
        if not models:
            models = [model['name'] for model in self.config.get('models', [])]
        
        results = []
        
        for model in models:
            logger.info(f"Consultando modelo {model}")
            result = self.query(prompt, model)
            
            if result['success']:
                results.append(result)
                # Se obteve sucesso, pode parar aqui ou continuar para comparar
                break
            else:
                logger.warning(f"Modelo {model} falhou: {result['response']}")
        
        if results:
            # Retorna o primeiro resultado bem-sucedido
            # Aqui poderia implementar lógica para escolher o "melhor" resultado
            return results[0]
        else:
            return {
                "success": False,
                "response": f"Todos os modelos falharam: {models}",
                "processing_time": 0,
                "provider": self.__class__.__name__,
                "models_tried": models
            }
    
    def analyze_with_chunking(self, prompt: str, model: str = None) -> Dict[str, Any]:
        """
        Analisa um prompt grande dividindo-o em chunks se necessário.
        
        Args:
            prompt: O prompt para análise
            model: O modelo a ser usado
            
        Returns:
            Dict com o resultado consolidado
        """
        max_chunk_size = self.config.get('token_management', {}).get('max_tokens_per_request', 6000)
        
        # Se o prompt é pequeno, faz análise normal
        if len(prompt) <= max_chunk_size:
            return self.query(prompt, model)
        
        # Divide o prompt em chunks
        chunks = self.chunk_prompt(prompt, max_chunk_size)
        logger.info(f"Prompt dividido em {len(chunks)} chunks")
        
        chunk_results = []
        total_processing_time = 0
        
        for i, chunk in enumerate(chunks):
            logger.info(f"Processando chunk {i+1}/{len(chunks)}")
            
            # Adiciona contexto ao chunk
            chunk_prompt = f"""
Este é o chunk {i+1} de {len(chunks)} de um programa COBOL maior.
Por favor, analise esta parte e forneça insights específicos:

{chunk}

Foque nos aspectos mais importantes desta seção do código.
"""
            
            result = self.query(chunk_prompt, model)
            chunk_results.append(result)
            total_processing_time += result.get('processing_time', 0)
            
            if not result['success']:
                logger.warning(f"Chunk {i+1} falhou: {result['response']}")
        
        # Consolida os resultados
        successful_chunks = [r for r in chunk_results if r['success']]
        
        if successful_chunks:
            consolidated_response = self._consolidate_chunk_results(successful_chunks)
            return {
                "success": True,
                "response": consolidated_response,
                "processing_time": total_processing_time,
                "provider": self.__class__.__name__,
                "chunks_processed": len(chunks),
                "chunks_successful": len(successful_chunks)
            }
        else:
            return {
                "success": False,
                "response": "Todos os chunks falharam na análise",
                "processing_time": total_processing_time,
                "provider": self.__class__.__name__,
                "chunks_processed": len(chunks),
                "chunks_successful": 0
            }
    
    def _consolidate_chunk_results(self, results: list) -> str:
        """Consolida os resultados de múltiplos chunks."""
        consolidated = "# Análise Consolidada do Programa COBOL\n\n"
        
        for i, result in enumerate(results):
            consolidated += f"## Análise do Segmento {i+1}\n\n"
            
            response = result.get('response', '')
            if isinstance(response, dict):
                response = json.dumps(response, indent=2, ensure_ascii=False)
            
            consolidated += f"{response}\n\n"
        
        consolidated += "## Resumo Geral\n\n"
        consolidated += "Esta análise foi realizada em múltiplos segmentos devido ao tamanho do programa. "
        consolidated += "Cada segmento foi analisado individualmente para garantir uma cobertura completa.\n"
        
        return consolidated
