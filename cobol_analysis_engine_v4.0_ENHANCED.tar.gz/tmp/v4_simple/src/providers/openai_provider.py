# -*- coding: utf-8 -*-
"""Provedor OpenAI para análise de programas COBOL."""

import os
import requests
import json
import logging
from typing import Dict, Any
from .base_provider import BaseLLMProvider

logger = logging.getLogger(__name__)

class OpenAIProvider(BaseLLMProvider):
    """Provedor para a API OpenAI."""

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.api_key = self._resolve_env_var(config.get('api_key'))
        self.api_url = "https://api.openai.com/v1/chat/completions"
        
    def _resolve_env_var(self, value: str) -> str:
        """Resolve variáveis de ambiente no formato ${VAR_NAME}."""
        if value and value.startswith('${') and value.endswith('}'):
            env_var = value[2:-1]
            return os.environ.get(env_var, '')
        return value or ''
    
    def authenticate(self) -> bool:
        """Verifica se a chave da API está configurada."""
        if not self.api_key:
            logger.error("OPENAI_API_KEY não configurada")
            return False
        return True
    
    def _make_request(self, prompt: str, model: str, max_tokens: int) -> Dict[str, Any]:
        """Faz a requisição para a API OpenAI."""
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        payload = {
            "model": model or "gpt-4-turbo",
            "messages": [
                {
                    "role": "system",
                    "content": "Você é um especialista em análise de código COBOL. Forneça análises detalhadas e precisas."
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            "max_tokens": max_tokens,
            "temperature": 0.1
        }
        
        logger.info(f"Enviando requisição para OpenAI com modelo {model}")
        
        response = requests.post(
            self.api_url,
            json=payload,
            headers=headers,
            timeout=self.timeout
        )
        response.raise_for_status()
        
        result = response.json()
        
        # Extrai o conteúdo da resposta
        if 'choices' in result and len(result['choices']) > 0:
            content = result['choices'][0]['message']['content']
            return {
                "analysis": content,
                "usage": result.get('usage', {}),
                "model": result.get('model', model)
            }
        else:
            raise Exception("Resposta inválida da API OpenAI")
    
    def analyze_with_chunking(self, prompt: str, model: str = None) -> Dict[str, Any]:
        """
        Analisa um prompt grande dividindo-o em chunks se necessário.
        
        Args:
            prompt: O prompt para análise
            model: O modelo a ser usado
            
        Returns:
            Dict com o resultado consolidado
        """
        max_chunk_size = self.config.get('token_management', {}).get('max_tokens_per_request', 4000)
        
        # Se o prompt é pequeno, faz análise normal
        if len(prompt) <= max_chunk_size:
            return self.query(prompt, model)
        
        # Divide o prompt em chunks
        chunks = self.chunk_prompt(prompt, max_chunk_size)
        logger.info(f"Prompt dividido em {len(chunks)} chunks para OpenAI")
        
        chunk_results = []
        total_processing_time = 0
        
        for i, chunk in enumerate(chunks):
            logger.info(f"Processando chunk {i+1}/{len(chunks)} com OpenAI")
            
            # Adiciona contexto ao chunk
            chunk_prompt = f"""
Analise esta seção de um programa COBOL (parte {i+1} de {len(chunks)}):

{chunk}

Forneça uma análise focada nos aspectos mais importantes desta seção.
"""
            
            result = self.query(chunk_prompt, model)
            chunk_results.append(result)
            total_processing_time += result.get('processing_time', 0)
            
            if not result['success']:
                logger.warning(f"Chunk {i+1} falhou na OpenAI: {result['response']}")
        
        # Consolida os resultados
        successful_chunks = [r for r in chunk_results if r['success']]
        
        if successful_chunks:
            consolidated_response = self._consolidate_chunk_results(successful_chunks)
            return {
                "success": True,
                "response": consolidated_response,
                "processing_time": total_processing_time,
                "provider": self.__class__.__name__,
                "chunks_processed": len(chunks),
                "chunks_successful": len(successful_chunks)
            }
        else:
            return {
                "success": False,
                "response": "Todos os chunks falharam na análise OpenAI",
                "processing_time": total_processing_time,
                "provider": self.__class__.__name__,
                "chunks_processed": len(chunks),
                "chunks_successful": 0
            }
    
    def _consolidate_chunk_results(self, results: list) -> str:
        """Consolida os resultados de múltiplos chunks."""
        consolidated = "# Análise Consolidada OpenAI - Programa COBOL\n\n"
        
        for i, result in enumerate(results):
            consolidated += f"## Segmento {i+1}\n\n"
            
            response = result.get('response', {})
            if isinstance(response, dict) and 'analysis' in response:
                consolidated += f"{response['analysis']}\n\n"
            else:
                consolidated += f"{response}\n\n"
        
        consolidated += "---\n\n"
        consolidated += "*Análise realizada em múltiplos segmentos pela OpenAI para garantir cobertura completa.*\n"
        
        return consolidated
