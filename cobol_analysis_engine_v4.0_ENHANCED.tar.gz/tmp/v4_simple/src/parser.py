# -*- coding: utf-8 -*-
"""Módulo para parsing de arquivos fontes.txt e BOOKS.txt."""

class CobolParser:
    """Realiza o parsing de arquivos COBOL."""

    def parse_fontes(self, file_path):
        """Faz o parsing do arquivo fontes.txt e extrai os programas."""
        programs = []
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        
        # Expressão regular para encontrar todos os programas no arquivo
        import re
        program_blocks = re.findall(r'MEMBER NAME\s+([\w\d]+)(.*?)(?=MEMBER NAME|$)', content, re.DOTALL)

        for block in program_blocks:
            program_name = block[0]
            program_code = block[1].strip()
            programs.append({
                'name': program_name,
                'code': program_code
            })

        return programs

    def parse_books(self, file_path):
        """Faz o parsing do arquivo BOOKS.txt e extrai os copybooks."""
        books = {}
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()

        # Expressão regular para encontrar todos os copybooks no arquivo
        import re
        book_blocks = re.findall(r'MEMBER NAME\s+([\w\d]+)(.*?)(?=MEMBER NAME|$)', content, re.DOTALL)

        for block in book_blocks:
            book_name = block[0]
            book_content = block[1].strip()
            books[book_name] = book_content

        return books

