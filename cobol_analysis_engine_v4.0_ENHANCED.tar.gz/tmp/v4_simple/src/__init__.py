# -*- coding: utf-8 -*-
"""Módulo principal do COBOL Analysis Engine."""
