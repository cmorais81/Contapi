#!/usr/bin/env python3
"""
Extrator de Informações COBOL
Extrai informações úteis dos arquivos fontes.txt e BOOKS.txt para gerar documentação rica.
"""

import re
import json
from typing import Dict, List, Any
from pathlib import Path

class COBOLInfoExtractor:
    """Extrai informações estruturadas dos arquivos COBOL."""
    
    def __init__(self):
        self.programs = []
        self.copybooks = []
        
    def extract_from_fontes(self, fontes_file: str) -> List[Dict[str, Any]]:
        """Extrai informações dos programas no arquivo fontes.txt."""
        
        with open(fontes_file, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        
        # Dividir por programas usando VMEMBER NAME
        program_sections = re.split(r'VMEMBER NAME\s+(\w+)', content)[1:]
        
        programs = []
        for i in range(0, len(program_sections), 2):
            if i + 1 < len(program_sections):
                program_name = program_sections[i].strip()
                program_content = program_sections[i + 1]
                
                program_info = self._extract_program_info(program_name, program_content)
                programs.append(program_info)
        
        return programs
    
    def extract_from_books(self, books_file: str) -> List[Dict[str, Any]]:
        """Extrai informações dos copybooks no arquivo BOOKS.txt."""
        
        with open(books_file, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        
        # Dividir por copybooks usando VMEMBER NAME
        book_sections = re.split(r'VMEMBER NAME\s+(\w+)', content)[1:]
        
        copybooks = []
        for i in range(0, len(book_sections), 2):
            if i + 1 < len(book_sections):
                book_name = book_sections[i].strip()
                book_content = book_sections[i + 1]
                
                book_info = self._extract_copybook_info(book_name, book_content)
                copybooks.append(book_info)
        
        return copybooks
    
    def _extract_program_info(self, program_name: str, content: str) -> Dict[str, Any]:
        """Extrai informações específicas de um programa."""
        
        info = {
            'name': program_name,
            'type': 'program',
            'objective': '',
            'author': '',
            'date_written': '',
            'version_history': [],
            'files': [],
            'divisions': [],
            'comments': [],
            'business_rules': [],
            'data_structures': []
        }
        
        lines = content.split('\n')
        
        # Extrair informações básicas
        for line in lines:
            # Objetivo do programa
            if 'OBJETIVO DO PROGRAMA' in line:
                idx = lines.index(line)
                objective_lines = []
                for i in range(idx + 1, min(idx + 10, len(lines))):
                    if lines[i].strip().startswith('V') and '**' in lines[i]:
                        obj_text = re.sub(r'^V[^*]*\*+\s*', '', lines[i]).replace('**', '').strip()
                        if obj_text and not obj_text.startswith('*'):
                            objective_lines.append(obj_text)
                info['objective'] = ' '.join(objective_lines)
            
            # Autor
            if 'AUTHOR.' in line:
                author_match = re.search(r'AUTHOR\.\s+(.+)', line)
                if author_match:
                    info['author'] = author_match.group(1).strip()
            
            # Data
            if 'DATE-WRITTEN.' in line:
                date_match = re.search(r'DATE-WRITTEN\.\s+(.+)', line)
                if date_match:
                    info['date_written'] = date_match.group(1).strip()
            
            # Histórico de versões
            if re.search(r'\*\s*\d+\s*\*.*\*.*\*.*\*', line):
                version_match = re.search(r'\*\s*(\d+)\s*\*\s*([^*]+)\s*\*\s*([^*]+)\s*\*\s*([^*]+)\s*\*', line)
                if version_match:
                    info['version_history'].append({
                        'version': version_match.group(1).strip(),
                        'date': version_match.group(2).strip(),
                        'author': version_match.group(3).strip(),
                        'description': version_match.group(4).strip()
                    })
            
            # Arquivos (SELECT statements)
            if 'SELECT' in line and 'ASSIGN' in line:
                select_match = re.search(r'SELECT\s+([A-Z0-9\-]+)\s+ASSIGN', line)
                if select_match:
                    file_name = select_match.group(1)
                    file_type = 'input' if 'E' in file_name else 'output' if 'S' in file_name else 'work'
                    info['files'].append({
                        'name': file_name,
                        'type': file_type,
                        'description': f'Arquivo {file_type} do sistema'
                    })
            
            # Comentários importantes
            if line.strip().startswith('V') and '*' in line:
                comment_text = re.sub(r'^V[^*]*\*+\s*', '', line).strip()
                if comment_text and len(comment_text) > 10 and not comment_text.startswith('*'):
                    info['comments'].append(comment_text)
        
        # Identificar divisões
        for line in lines:
            if 'DIVISION.' in line:
                division_match = re.search(r'(\w+)\s+DIVISION\.', line)
                if division_match:
                    info['divisions'].append(division_match.group(1))
        
        return info
    
    def _extract_copybook_info(self, book_name: str, content: str) -> Dict[str, Any]:
        """Extrai informações específicas de um copybook."""
        
        info = {
            'name': book_name,
            'type': 'copybook',
            'description': '',
            'tables': [],
            'fields': [],
            'comments': [],
            'version_history': []
        }
        
        lines = content.split('\n')
        
        # Extrair descrição principal
        for line in lines:
            if 'BOOK ->' in line:
                desc_match = re.search(r'BOOK\s*->\s*(.+)', line)
                if desc_match:
                    info['description'] = desc_match.group(1).strip()
            
            # Área de tabelas
            if 'AREA DAS TABELAS' in line or 'TABELAS DE CONSISTENCIAS' in line:
                info['description'] = 'Área das tabelas de consistências dos códigos do Banco Central'
            
            # Tabelas (01 level)
            if re.match(r'V\s+01\s+([A-Z0-9\-]+)', line):
                table_match = re.search(r'01\s+([A-Z0-9\-]+)', line)
                if table_match:
                    info['tables'].append({
                        'name': table_match.group(1),
                        'level': '01',
                        'description': 'Tabela de dados'
                    })
            
            # Campos (05, 10 level)
            if re.match(r'V\s+(05|10)\s+([A-Z0-9\-]+)', line):
                field_match = re.search(r'(05|10)\s+([A-Z0-9\-]+)(?:\s+PIC\s+([X9\(\)]+))?', line)
                if field_match:
                    info['fields'].append({
                        'level': field_match.group(1),
                        'name': field_match.group(2),
                        'pic': field_match.group(3) if field_match.group(3) else '',
                        'description': 'Campo de dados'
                    })
            
            # Comentários de versão
            if re.search(r'V[A-Z0-9]+\*.*\d{6}.*-', line):
                version_text = re.sub(r'^V[A-Z0-9]+\*\s*', '', line).strip()
                if version_text:
                    info['version_history'].append(version_text)
            
            # Comentários importantes
            if line.strip().startswith('V') and '*' in line:
                comment_text = re.sub(r'^V[^*]*\*+\s*', '', line).strip()
                if comment_text and len(comment_text) > 10 and not comment_text.startswith('*'):
                    info['comments'].append(comment_text)
        
        return info
    
    def generate_documentation(self, programs: List[Dict], copybooks: List[Dict]) -> str:
        """Gera documentação estruturada baseada nas informações extraídas."""
        
        doc = []
        doc.append("# Documentação dos Sistemas COBOL")
        doc.append("")
        doc.append("## Resumo Executivo")
        doc.append("")
        doc.append(f"Esta documentação apresenta a análise de **{len(programs)} programas COBOL** e **{len(copybooks)} copybooks** ")
        doc.append("extraídos dos arquivos fontes.txt e BOOKS.txt. Os sistemas analisados são relacionados ao ")
        doc.append("processamento de dados do Banco Central (BACEN) e incluem funcionalidades de particionamento, ")
        doc.append("validação e transmissão de arquivos.")
        doc.append("")
        
        # Programas
        doc.append("## Programas Analisados")
        doc.append("")
        
        for i, program in enumerate(programs, 1):
            doc.append(f"### {i}. {program['name']}")
            doc.append("")
            
            if program['objective']:
                doc.append(f"**Objetivo:** {program['objective']}")
                doc.append("")
            
            if program['author']:
                doc.append(f"**Autor:** {program['author']}")
            
            if program['date_written']:
                doc.append(f"**Data de Criação:** {program['date_written']}")
                doc.append("")
            
            if program['files']:
                doc.append("**Arquivos Utilizados:**")
                for file_info in program['files']:
                    doc.append(f"- `{file_info['name']}` ({file_info['type']}): {file_info['description']}")
                doc.append("")
            
            if program['version_history']:
                doc.append("**Histórico de Versões:**")
                for version in program['version_history']:
                    doc.append(f"- **v{version['version']}** ({version['date']}) por {version['author']}: {version['description']}")
                doc.append("")
            
            if program['divisions']:
                doc.append(f"**Divisões COBOL:** {', '.join(program['divisions'])}")
                doc.append("")
            
            doc.append("---")
            doc.append("")
        
        # Copybooks
        doc.append("## Copybooks Analisados")
        doc.append("")
        
        for i, copybook in enumerate(copybooks, 1):
            doc.append(f"### {i}. {copybook['name']}")
            doc.append("")
            
            if copybook['description']:
                doc.append(f"**Descrição:** {copybook['description']}")
                doc.append("")
            
            if copybook['tables']:
                doc.append("**Tabelas Definidas:**")
                for table in copybook['tables']:
                    doc.append(f"- `{table['name']}` (nível {table['level']}): {table['description']}")
                doc.append("")
            
            if copybook['fields']:
                doc.append("**Campos Principais:**")
                field_count = min(10, len(copybook['fields']))  # Limitar a 10 campos
                for field in copybook['fields'][:field_count]:
                    pic_info = f" PIC {field['pic']}" if field['pic'] else ""
                    doc.append(f"- `{field['name']}` (nível {field['level']}){pic_info}: {field['description']}")
                if len(copybook['fields']) > 10:
                    doc.append(f"- ... e mais {len(copybook['fields']) - 10} campos")
                doc.append("")
            
            if copybook['version_history']:
                doc.append("**Histórico de Modificações:**")
                for version in copybook['version_history'][:5]:  # Limitar a 5 versões
                    doc.append(f"- {version}")
                if len(copybook['version_history']) > 5:
                    doc.append(f"- ... e mais {len(copybook['version_history']) - 5} modificações")
                doc.append("")
            
            doc.append("---")
            doc.append("")
        
        # Análise consolidada
        doc.append("## Análise Consolidada")
        doc.append("")
        
        doc.append("### Características Técnicas")
        doc.append("")
        doc.append("**Linguagem:** COBOL (COBOL-85/2002)")
        doc.append("**Ambiente:** Mainframe (IBM)")
        doc.append("**Domínio:** Sistema Bancário - Banco Central do Brasil")
        doc.append("**Funcionalidades Principais:**")
        
        # Extrair funcionalidades dos objetivos
        objectives = [p['objective'] for p in programs if p['objective']]
        if objectives:
            for obj in objectives:
                doc.append(f"- {obj}")
        
        doc.append("")
        
        doc.append("### Arquivos do Sistema")
        doc.append("")
        all_files = []
        for program in programs:
            all_files.extend(program['files'])
        
        if all_files:
            input_files = [f for f in all_files if f['type'] == 'input']
            output_files = [f for f in all_files if f['type'] == 'output']
            
            if input_files:
                doc.append("**Arquivos de Entrada:**")
                for file_info in input_files:
                    doc.append(f"- `{file_info['name']}`: {file_info['description']}")
                doc.append("")
            
            if output_files:
                doc.append("**Arquivos de Saída:**")
                for file_info in output_files:
                    doc.append(f"- `{file_info['name']}`: {file_info['description']}")
                doc.append("")
        
        doc.append("### Recomendações para Modernização")
        doc.append("")
        doc.append("1. **Migração Gradual:** Considerar migração por módulos funcionais")
        doc.append("2. **Preservação de Lógica:** Manter regras de negócio do Banco Central")
        doc.append("3. **Testes Abrangentes:** Validar cálculos e processamentos críticos")
        doc.append("4. **Documentação Técnica:** Expandir documentação de regras específicas")
        doc.append("5. **Integração:** Planejar interfaces com sistemas modernos")
        doc.append("")
        
        doc.append("---")
        doc.append("*Documentação gerada automaticamente pelo Sistema de Análise COBOL v1.0.0*")
        
        return '\n'.join(doc)

def main():
    """Função principal para executar a extração."""
    
    extractor = COBOLInfoExtractor()
    
    # Extrair informações
    print("Extraindo informações dos programas COBOL...")
    programs = extractor.extract_from_fontes('examples/fontes.txt')
    print(f"Encontrados {len(programs)} programas")
    
    print("Extraindo informações dos copybooks...")
    copybooks = extractor.extract_from_books('examples/BOOKS.txt')
    print(f"Encontrados {len(copybooks)} copybooks")
    
    # Gerar documentação
    print("Gerando documentação consolidada...")
    documentation = extractor.generate_documentation(programs, copybooks)
    
    # Salvar resultados
    output_dir = Path('extracted_analysis_results')
    output_dir.mkdir(exist_ok=True)
    
    # Documentação principal
    with open(output_dir / 'DOCUMENTACAO_COBOL_COMPLETA.md', 'w', encoding='utf-8') as f:
        f.write(documentation)
    
    # Dados estruturados
    with open(output_dir / 'programas_extraidos.json', 'w', encoding='utf-8') as f:
        json.dump(programs, f, indent=2, ensure_ascii=False)
    
    with open(output_dir / 'copybooks_extraidos.json', 'w', encoding='utf-8') as f:
        json.dump(copybooks, f, indent=2, ensure_ascii=False)
    
    print(f"Documentação gerada em: {output_dir}")
    print(f"- DOCUMENTACAO_COBOL_COMPLETA.md")
    print(f"- programas_extraidos.json")
    print(f"- copybooks_extraidos.json")
    
    return programs, copybooks, documentation

if __name__ == "__main__":
    main()
