#!/usr/bin/env python3
"""
Content Extractor - Sistema de Análise COBOL v1.0.0
Extrai conteúdo real dos arquivos fontes.txt e BOOKS.txt para enriquecer a análise.
"""

import re
import logging
from typing import Dict, List, Any, Optional
from pathlib import Path

class COBOLContentExtractor:
    """Extrai conteúdo estruturado dos arquivos COBOL para enriquecer análise."""
    
    def __init__(self):
        self.logger = logging.getLogger(self.__class__.__name__)
        
    def extract_from_files(self, input_files: List[str], copybooks_file: str = None) -> Dict[str, Any]:
        """
        Extrai conteúdo real dos arquivos de entrada.
        
        Args:
            input_files: Lista de arquivos de entrada
            copybooks_file: Arquivo de copybooks (opcional)
            
        Returns:
            Dict com conteúdo extraído estruturado
        """
        extracted_content = {
            'programs': [],
            'copybooks': [],
            'summary': {},
            'business_rules': [],
            'technical_info': {}
        }
        
        try:
            # Processar arquivos de entrada
            for file_path in input_files:
                if self._is_multi_program_file(file_path):
                    programs = self._extract_programs_from_file(file_path)
                    extracted_content['programs'].extend(programs)
                else:
                    # Arquivo individual
                    program = self._extract_single_program(file_path)
                    if program:
                        extracted_content['programs'].append(program)
            
            # Processar copybooks se fornecido
            if copybooks_file and Path(copybooks_file).exists():
                if self._is_multi_program_file(copybooks_file):
                    copybooks = self._extract_programs_from_file(copybooks_file)
                    extracted_content["copybooks"].extend(copybooks)
                else:
                    copybooks = self._extract_copybooks_from_file(copybooks_file)
                    extracted_content["copybooks"].extend(copybooks)

            
            # Gerar resumo
            extracted_content['summary'] = self._generate_summary(
                extracted_content['programs'], 
                extracted_content['copybooks']
            )
            
            # Extrair regras de negócio
            extracted_content['business_rules'] = self._extract_business_rules(
                extracted_content['programs']
            )
            
            # Informações técnicas
            extracted_content['technical_info'] = self._extract_technical_info(
                extracted_content['programs'],
                extracted_content['copybooks']
            )
            
            self.logger.info(f"Conteúdo extraído: {len(extracted_content['programs'])} programas, "
                           f"{len(extracted_content['copybooks'])} copybooks")
            
        except Exception as e:
            self.logger.error(f"Erro na extração de conteúdo: {e}")
            
        return extracted_content
    
    def _is_multi_program_file(self, file_path: str) -> bool:
        """Verifica se o arquivo contém múltiplos programas."""
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
                return content.count('VMEMBER NAME') > 1
        except:
            return False
    
    def _extract_programs_from_file(self, file_path: str) -> List[Dict[str, Any]]:
        """Extrai múltiplos programas de um arquivo."""
        programs = []
        
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            # Dividir por programas usando VMEMBER NAME
            program_sections = re.split(r'VMEMBER NAME\s+(\w+)', content)[1:]
            
            for i in range(0, len(program_sections), 2):
                if i + 1 < len(program_sections):
                    program_name = program_sections[i].strip()
                    program_content = program_sections[i + 1]
                    
                    program_info = self._extract_program_info(program_name, program_content)
                    programs.append(program_info)
                    
        except Exception as e:
            self.logger.error(f"Erro ao extrair programas de {file_path}: {e}")
            
        return programs
    
    def _extract_single_program(self, file_path: str) -> Optional[Dict[str, Any]]:
        """Extrai informações de um programa individual."""
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            program_name = Path(file_path).stem
            return self._extract_program_info(program_name, content)
            
        except Exception as e:
            self.logger.error(f"Erro ao extrair programa {file_path}: {e}")
            return None
    
    def _extract_copybooks_from_file(self, file_path: str) -> List[Dict[str, Any]]:
        """Extrai copybooks de um arquivo."""
        copybooks = []
        
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            # Dividir por copybooks usando VMEMBER NAME
            book_sections = re.split(r'VMEMBER NAME\s+(\w+)', content)[1:]
            
            for i in range(0, len(book_sections), 2):
                if i + 1 < len(book_sections):
                    book_name = book_sections[i].strip()
                    book_content = book_sections[i + 1]
                    
                    book_info = self._extract_copybook_info(book_name, book_content)
                    copybooks.append(book_info)
                    
        except Exception as e:
            self.logger.error(f"Erro ao extrair copybooks de {file_path}: {e}")
            
        return copybooks
    
    def _extract_program_info(self, program_name: str, content: str) -> Dict[str, Any]:
        """Extrai informações detalhadas de um programa."""
        
        info = {
            'name': program_name,
            'code': content,
            'type': 'program',
            'objective': '',
            'author': '',
            'date_written': '',
            'version_history': [],
            'files': [],
            'divisions': [],
            'sections': {},
            'paragraphs': [],
            'copybooks_used': [],
            'comments': [],
            'business_rules': [],
            'data_structures': [],
            'procedures': [],
            'content_quality': 'high'
        }
        
        lines = content.split('\n')
        
        # Extrair informações básicas
        for i, line in enumerate(lines):
            # Objetivo do programa
            if 'OBJETIVO DO PROGRAMA' in line:
                objective_lines = []
                for j in range(i + 1, min(i + 10, len(lines))):
                    if lines[j].strip().startswith('V') and '**' in lines[j]:
                        obj_text = re.sub(r'^V[^*]*\*+\s*', '', lines[j]).replace('**', '').strip()
                        if obj_text and not obj_text.startswith('*'):
                            objective_lines.append(obj_text)
                info['objective'] = ' '.join(objective_lines)
            
            # Autor
            if 'AUTHOR.' in line:
                author_match = re.search(r'AUTHOR\.\s+(.+)', line)
                if author_match:
                    info['author'] = author_match.group(1).strip()
            
            # Data
            if 'DATE-WRITTEN.' in line:
                date_match = re.search(r'DATE-WRITTEN\.\s+(.+)', line)
                if date_match:
                    info['date_written'] = date_match.group(1).strip()
            
            # Histórico de versões
            if re.search(r'\*\s*\d+\s*\*.*\*.*\*.*\*', line):
                version_match = re.search(r'\*\s*(\d+)\s*\*\s*([^*]+)\s*\*\s*([^*]+)\s*\*\s*([^*]+)\s*\*', line)
                if version_match:
                    info['version_history'].append({
                        'version': version_match.group(1).strip(),
                        'date': version_match.group(2).strip(),
                        'author': version_match.group(3).strip(),
                        'description': version_match.group(4).strip()
                    })
            
            # Arquivos (SELECT statements)
            if 'SELECT' in line and 'ASSIGN' in line:
                select_match = re.search(r'SELECT\s+([A-Z0-9\-]+)\s+ASSIGN', line)
                if select_match:
                    file_name = select_match.group(1)
                    file_type = 'input' if 'E' in file_name else 'output' if 'S' in file_name else 'work'
                    info['files'].append({
                        'name': file_name,
                        'type': file_type,
                        'description': f'Arquivo {file_type} do sistema'
                    })
            
            # Divisões
            if 'DIVISION.' in line:
                division_match = re.search(r'(\w+)\s+DIVISION\.', line)
                if division_match:
                    info['divisions'].append(division_match.group(1))
            
            # Procedures importantes
            if re.search(r'^\s*[0-9]+-[A-Z0-9\-]+\.', line):
                proc_match = re.search(r'([0-9]+-[A-Z0-9\-]+)\.', line)
                if proc_match:
                    info['procedures'].append(proc_match.group(1))
                  # Seções
            if 'SECTION.' in line:
                section_name = line.split('SECTION.')[0].strip()
                if 'DATA DIVISION' in info['divisions']:
                    if 'data' not in info['sections']:
                        info['sections']['data'] = []
                    info['sections']['data'].append(section_name)
                elif 'PROCEDURE DIVISION' in info['divisions']:
                    if 'procedure' not in info['sections']:
                        info['sections']['procedure'] = []
                    info['sections']['procedure'].append(section_name)

            # Parágrafos
            if re.match(r'^\s*\w+\s*\.\s*$', line) and 'PROCEDURE DIVISION' in info['divisions']:
                paragraph_name = line.strip().replace('.', '')
                info['paragraphs'].append(paragraph_name)

            # Copybooks usados
            if 'COPY' in line:
                copy_match = re.search(r'COPY\s+([\w\-]+)', line)
                if copy_match:
                    info['copybooks_used'].append(copy_match.group(1))

            # Comentários importantes
            if line.strip().startswith('V') and '*' in line:
                comment_text = re.sub(r'^V[^*]*\\*+\\s*', '', line).strip()
                if comment_text and len(comment_text) > 10 and not comment_text.startswith('*'):
                    info['comments'].append(comment_text)
  
        return info
    
    def _extract_copybook_info(self, book_name: str, content: str) -> Dict[str, Any]:
        """Extrai informações detalhadas de um copybook."""
        
        info = {
            'name': book_name,
            'type': 'copybook',
            'description': '',
            'tables': [],
            'fields': [],
            'comments': [],
            'version_history': [],
            'content_quality': 'high'  # Baseado em conteúdo real
        }
        
        lines = content.split('\n')
        
        for line in lines:
            # Descrição principal
            if 'BOOK ->' in line:
                desc_match = re.search(r'BOOK\s*->\s*(.+)', line)
                if desc_match:
                    info['description'] = desc_match.group(1).strip()
            
            # Área de tabelas
            if 'AREA DAS TABELAS' in line or 'TABELAS DE CONSISTENCIAS' in line:
                info['description'] = 'Área das tabelas de consistências dos códigos do Banco Central'
            
            # Tabelas (01 level)
            if re.match(r'V\s+01\s+([A-Z0-9\-]+)', line):
                table_match = re.search(r'01\s+([A-Z0-9\-]+)', line)
                if table_match:
                    info['tables'].append({
                        'name': table_match.group(1),
                        'level': '01',
                        'description': 'Tabela de dados'
                    })
            
            # Campos (05, 10 level)
            if re.match(r'V\s+(05|10)\s+([A-Z0-9\-]+)', line):
                field_match = re.search(r'(05|10)\s+([A-Z0-9\-]+)(?:\s+PIC\s+([X9\(\)]+))?', line)
                if field_match:
                    info['fields'].append({
                        'level': field_match.group(1),
                        'name': field_match.group(2),
                        'pic': field_match.group(3) if field_match.group(3) else '',
                        'description': 'Campo de dados'
                    })
            
            # Comentários de versão
            if re.search(r'V[A-Z0-9]+\*.*\d{6}.*-', line):
                version_text = re.sub(r'^V[A-Z0-9]+\*\s*', '', line).strip()
                if version_text:
                    info['version_history'].append(version_text)
        
        return info
    
    def _extract_business_rules(self, programs: List[Dict]) -> List[Dict[str, Any]]:
        """Extrai regras de negócio dos programas."""
        business_rules = []
        
        for program in programs:
            # Regras do objetivo
            if program.get('objective'):
                business_rules.append({
                    'source': program['name'],
                    'type': 'objective',
                    'description': program['objective'],
                    'confidence': 'high'
                })
            
            # Regras dos comentários
            for comment in program.get('comments', []):
                if any(keyword in comment.upper() for keyword in 
                      ['PARTICION', 'LIMITE', 'CODIGO', 'BACEN', 'VALIDACAO']):
                    business_rules.append({
                        'source': program['name'],
                        'type': 'business_logic',
                        'description': comment,
                        'confidence': 'medium'
                    })
        
        return business_rules
    
    def _extract_technical_info(self, programs: List[Dict], copybooks: List[Dict]) -> Dict[str, Any]:
        """Extrai informações técnicas consolidadas."""
        
        tech_info = {
            'total_programs': len(programs),
            'total_copybooks': len(copybooks),
            'file_types': {'input': 0, 'output': 0, 'work': 0},
            'divisions_used': set(),
            'authors': set(),
            'date_range': {'earliest': None, 'latest': None},
            'complexity_indicators': {
                'has_version_history': 0,
                'has_multiple_files': 0,
                'has_procedures': 0
            }
        }
        
        # Analisar programas
        for program in programs:
            # Contagem de arquivos por tipo
            for file_info in program.get('files', []):
                file_type = file_info.get('type', 'work')
                tech_info['file_types'][file_type] += 1
            
            # Divisões utilizadas
            tech_info['divisions_used'].update(program.get('divisions', []))
            
            # Autores
            if program.get('author'):
                tech_info['authors'].add(program['author'])
            
            # Indicadores de complexidade
            if program.get('version_history'):
                tech_info['complexity_indicators']['has_version_history'] += 1
            
            if len(program.get('files', [])) > 1:
                tech_info['complexity_indicators']['has_multiple_files'] += 1
            
            if program.get('procedures'):
                tech_info['complexity_indicators']['has_procedures'] += 1
        
        # Converter sets para listas para serialização
        tech_info['divisions_used'] = list(tech_info['divisions_used'])
        tech_info['authors'] = list(tech_info['authors'])
        
        return tech_info
    
    def _generate_summary(self, programs: List[Dict], copybooks: List[Dict]) -> Dict[str, Any]:
        """Gera resumo do conteúdo extraído."""
        
        summary = {
            'extraction_method': 'real_content',
            'content_quality': 'high',
            'programs_found': len(programs),
            'copybooks_found': len(copybooks),
            'has_documentation': True,
            'has_version_history': any(p.get('version_history') for p in programs),
            'has_business_rules': any(p.get('objective') for p in programs),
            'extraction_confidence': 0.95  # Alto porque é conteúdo real
        }
        
        return summary

    def enrich_with_ai_analysis(self, extracted_content: Dict, ai_analysis: Dict) -> Dict[str, Any]:
        """
        Enriquece conteúdo extraído com análise de IA quando disponível.
        
        Args:
            extracted_content: Conteúdo real extraído
            ai_analysis: Análise das IAs (quando disponível)
            
        Returns:
            Conteúdo enriquecido combinado
        """
        enriched = extracted_content.copy()
        
        if ai_analysis and ai_analysis.get('success', False):
            # Combinar análises
            enriched['ai_enhancement'] = {
                'available': True,
                'confidence': ai_analysis.get('confidence_level', 0),
                'analysis_method': 'hybrid_real_content_plus_ai'
            }
            
            # Enriquecer programas com análise IA
            ai_results = ai_analysis.get('parallel_results', {})
            
            for program in enriched['programs']:
                program['ai_analysis'] = {
                    'structural': ai_results.get('structural', {}),
                    'business': ai_results.get('business', {}),
                    'technical': ai_results.get('technical', {}),
                    'quality': ai_results.get('quality', {})
                }
        else:
            # Apenas conteúdo real
            enriched['ai_enhancement'] = {
                'available': False,
                'analysis_method': 'real_content_only',
                'note': 'Análise baseada em conteúdo real extraído dos programas'
            }
        
        return enriched
