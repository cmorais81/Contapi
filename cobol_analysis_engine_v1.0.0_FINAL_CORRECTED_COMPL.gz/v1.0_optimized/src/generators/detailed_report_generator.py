import logging
from typing import Dict, Any

class DetailedReportGenerator:
    def __init__(self):
        self.logger = logging.getLogger(self.__class__.__name__)

    def generate(self, program_data: Dict[str, Any], ai_analysis: Dict[str, Any]) -> str:
        report_parts = []
        report_parts.append(self._generate_header(program_data))
        report_parts.append(self._generate_functional_analysis(program_data, ai_analysis))
        report_parts.append(self._generate_technical_analysis(program_data, ai_analysis))
        return "\n".join(report_parts)

    def _generate_header(self, program_data: Dict[str, Any]) -> str:
        return f"# Análise Detalhada do Programa: {program_data.get('name', 'N/A')}\n"

    def _generate_functional_analysis(self, program_data: Dict[str, Any], ai_analysis: Dict[str, Any]) -> str:
        functional_parts = ["## Análise Funcional"]
        functional_parts.append(f"### Objetivo do Programa\n{program_data.get('objective', 'Não especificado.')}")
        functional_parts.append("### Regras de Negócio Identificadas")
        for rule in program_data.get('business_rules', []):
            functional_parts.append(f"- {rule['description']}")
        return "\n".join(functional_parts)

    def _generate_technical_analysis(self, program_data: Dict[str, Any], ai_analysis: Dict[str, Any]) -> str:
        technical_parts = ["## Análise Técnica"]
        technical_parts.append(f"### Estrutura do Programa\n- **Divisões:** {', '.join(program_data.get('divisions', []))}")
        technical_parts.append("### Copybooks Utilizados")
        for copybook in program_data.get('copybooks_used', []):
            technical_parts.append(f"- {copybook}")
        return "\n".join(technical_parts)

