#!/usr/bin/env python3
"""
Execution Logger - Sistema de Análise COBOL v1.0
Sistema de logging detalhado para execução e prompts dos providers.
"""

import os
import json
import logging
from datetime import datetime
from typing import Dict, Any, Optional

class ExecutionLogger:
    """Logger especializado para execução e prompts dos providers."""
    
    def __init__(self, log_dir: str = "logs"):
        self.log_dir = log_dir
        os.makedirs(log_dir, exist_ok=True)
        
        # Configurar logger principal
        self.logger = logging.getLogger("ExecutionLogger")
        
        # Arquivo de log principal de execução
        self.execution_log_file = os.path.join(log_dir, "execution_detailed.log")
        
        # Configurar handler para arquivo de execução
        execution_handler = logging.FileHandler(self.execution_log_file)
        execution_handler.setFormatter(
            logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        )
        self.logger.addHandler(execution_handler)
        self.logger.setLevel(logging.INFO)
    
    def log_provider_prompt(self, provider_name: str, prompt: str, model: str, 
                           temperature: float, max_tokens: int) -> None:
        """Log detalhado do prompt enviado para um provider."""
        
        timestamp = datetime.now().isoformat()
        
        # Arquivo específico do provider
        provider_log_file = os.path.join(self.log_dir, f"{provider_name}_prompts.log")
        
        # Estrutura do log de prompt
        prompt_log = {
            "timestamp": timestamp,
            "provider": provider_name,
            "model": model,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "prompt_length": len(prompt),
            "prompt": prompt
        }
        
        # Salvar no arquivo específico do provider
        with open(provider_log_file, 'a', encoding='utf-8') as f:
            f.write("=" * 80 + "\n")
            f.write(f"TIMESTAMP: {timestamp}\n")
            f.write(f"PROVIDER: {provider_name}\n")
            f.write(f"MODEL: {model}\n")
            f.write(f"TEMPERATURE: {temperature}\n")
            f.write(f"MAX_TOKENS: {max_tokens}\n")
            f.write(f"PROMPT_LENGTH: {len(prompt)} caracteres\n")
            f.write("=" * 80 + "\n")
            f.write("PROMPT ENVIADO:\n")
            f.write(prompt)
            f.write("\n" + "=" * 80 + "\n\n")
        
        # Log resumido no arquivo principal
        self.logger.info(f"Prompt enviado para {provider_name} - Modelo: {model}, "
                        f"Tamanho: {len(prompt)} chars, Temp: {temperature}")
    
    def log_provider_response(self, provider_name: str, response: Dict[str, Any], 
                             execution_time: float, success: bool) -> None:
        """Log da resposta do provider."""
        
        timestamp = datetime.now().isoformat()
        
        # Arquivo específico do provider
        provider_log_file = os.path.join(self.log_dir, f"{provider_name}_responses.log")
        
        # Estrutura do log de resposta
        response_log = {
            "timestamp": timestamp,
            "provider": provider_name,
            "execution_time": execution_time,
            "success": success,
            "response": response
        }
        
        # Salvar no arquivo específico do provider
        with open(provider_log_file, 'a', encoding='utf-8') as f:
            f.write("=" * 80 + "\n")
            f.write(f"TIMESTAMP: {timestamp}\n")
            f.write(f"PROVIDER: {provider_name}\n")
            f.write(f"EXECUTION_TIME: {execution_time:.2f}s\n")
            f.write(f"SUCCESS: {success}\n")
            f.write("=" * 80 + "\n")
            f.write("RESPONSE:\n")
            f.write(json.dumps(response, indent=2, ensure_ascii=False))
            f.write("\n" + "=" * 80 + "\n\n")
        
        # Log resumido no arquivo principal
        status = "SUCCESS" if success else "FAILED"
        self.logger.info(f"Resposta de {provider_name} - Status: {status}, "
                        f"Tempo: {execution_time:.2f}s")
    
    def log_execution_step(self, step: str, details: Dict[str, Any]) -> None:
        """Log de etapas da execução."""
        
        timestamp = datetime.now().isoformat()
        
        self.logger.info(f"STEP: {step}")
        
        # Log detalhado no arquivo de execução
        with open(self.execution_log_file, 'a', encoding='utf-8') as f:
            f.write(f"\n[{timestamp}] EXECUTION STEP: {step}\n")
            f.write(json.dumps(details, indent=2, ensure_ascii=False))
            f.write("\n" + "-" * 50 + "\n")
    
    def log_multi_ai_orchestration(self, program_name: str, providers_used: list, 
                                  results_summary: Dict[str, Any]) -> None:
        """Log específico para orquestração Multi-IA."""
        
        timestamp = datetime.now().isoformat()
        
        # Arquivo específico para Multi-IA
        multi_ai_log_file = os.path.join(self.log_dir, "multi_ai_orchestration.log")
        
        with open(multi_ai_log_file, 'a', encoding='utf-8') as f:
            f.write("=" * 100 + "\n")
            f.write(f"MULTI-IA ORCHESTRATION - {timestamp}\n")
            f.write(f"PROGRAM: {program_name}\n")
            f.write(f"PROVIDERS USED: {', '.join(providers_used)}\n")
            f.write("=" * 100 + "\n")
            f.write("RESULTS SUMMARY:\n")
            f.write(json.dumps(results_summary, indent=2, ensure_ascii=False))
            f.write("\n" + "=" * 100 + "\n\n")
        
        self.logger.info(f"Multi-IA orchestration para {program_name} - "
                        f"Providers: {len(providers_used)}")
    
    def log_analysis_summary(self, total_programs: int, total_time: float, 
                           providers_summary: Dict[str, Any]) -> None:
        """Log do resumo final da análise."""
        
        timestamp = datetime.now().isoformat()
        
        # Arquivo de resumo
        summary_log_file = os.path.join(self.log_dir, "analysis_summary.log")
        
        summary = {
            "timestamp": timestamp,
            "total_programs": total_programs,
            "total_execution_time": total_time,
            "providers_summary": providers_summary
        }
        
        with open(summary_log_file, 'w', encoding='utf-8') as f:
            f.write("ANÁLISE COBOL - RESUMO FINAL\n")
            f.write("=" * 50 + "\n")
            f.write(json.dumps(summary, indent=2, ensure_ascii=False))
            f.write("\n")
        
        self.logger.info(f"Análise finalizada - {total_programs} programas em {total_time:.2f}s")
    
    def get_log_files(self) -> Dict[str, str]:
        """Retorna lista de arquivos de log criados."""
        
        log_files = {}
        
        for file_name in os.listdir(self.log_dir):
            if file_name.endswith('.log'):
                log_files[file_name] = os.path.join(self.log_dir, file_name)
        
        return log_files
