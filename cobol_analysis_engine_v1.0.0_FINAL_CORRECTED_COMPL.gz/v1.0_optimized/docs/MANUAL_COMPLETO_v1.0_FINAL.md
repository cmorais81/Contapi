# Manual Completo - Sistema de Análise COBOL v1.0 FINAL

## Índice
1. [Visão Geral](#visão-geral)
2. [Instalação e Configuração](#instalação-e-configuração)
3. [Provedores de IA Suportados](#provedores-de-ia-suportados)
4. [Formas de Execução](#formas-de-execução)
5. [Configuração Avançada](#configuração-avançada)
6. [Logging e Monitoramento](#logging-e-monitoramento)
7. [Exemplos Práticos](#exemplos-práticos)
8. [Troubleshooting](#troubleshooting)
9. [Referência Completa](#referência-completa)

## Visão Geral

O Sistema de Análise COBOL v1.0 é uma ferramenta completa para análise, documentação e modernização de programas COBOL. Oferece suporte a **11 provedores de IA diferentes** e múltiplas abordagens de análise.

### Características Principais

- **11 Provedores de IA**: OpenAI, LuzIA, Bedrock, Databricks, Anthropic, Gemini, Cohere, HuggingFace, Ollama, Azure OpenAI, Enhanced Mock
- **Análise Multi-IA**: 4 análises especializadas em paralelo
- **Logging Transparente**: Visualização completa dos prompts enviados para cada provider
- **Configuração SSL Global**: Suporte completo a ambientes corporativos
- **Documentação Individual**: Cada programa gera seu próprio arquivo de análise
- **Fallback Inteligente**: Sistema robusto de fallback entre providers
- **Extração de Copybooks**: Processamento completo de BOOKS.txt

## Instalação e Configuração

### Pré-requisitos

```bash
# Python 3.11+
python3 --version

# Dependências básicas
pip3 install httpx pyyaml asyncio pathlib

# Dependências opcionais para providers específicos
pip3 install openai boto3 requests  # Para OpenAI, Bedrock, outros
```

### Estrutura do Projeto

```
cobol_analysis_engine_v1.0/
├── main.py                    # Script principal
├── config/
│   └── config.yaml           # Configuração completa com 11 providers
├── src/
│   ├── core/                 # Núcleo do sistema
│   ├── providers/            # 11 provedores de IA
│   ├── generators/           # Geradores de documentação
│   ├── extractors/           # Extratores de conteúdo
│   └── utils/               # Utilitários
├── examples/                 # Arquivos de exemplo
├── logs/                    # Logs detalhados por provider
└── docs/                    # Documentação
```

## Provedores de IA Suportados

### 1. OpenAI GPT (openai)
```bash
export OPENAI_API_KEY="sua_chave"
export OPENAI_ORG_ID="sua_org"  # Opcional
python3 main.py programa.cbl --provider openai
```

### 2. LuzIA Corporativo (luzia)
```bash
export LUZIA_CLIENT_ID="seu_client_id"
export LUZIA_CLIENT_SECRET="seu_client_secret"
python3 main.py programa.cbl --provider luzia
```

### 3. AWS Bedrock (bedrock)
```bash
export AWS_ACCESS_KEY_ID="sua_chave"
export AWS_SECRET_ACCESS_KEY="seu_secret"
export AWS_REGION="us-east-1"
python3 main.py programa.cbl --provider bedrock
```

### 4. Databricks (databricks)
```bash
export DATABRICKS_HOST="sua_instancia.databricks.com"
export DATABRICKS_TOKEN="seu_token"
export DATABRICKS_ENDPOINT="/serving-endpoints/seu-modelo"
python3 main.py programa.cbl --provider databricks
```

### 5. Anthropic Claude (anthropic)
```bash
export ANTHROPIC_API_KEY="sua_chave"
python3 main.py programa.cbl --provider anthropic
```

### 6. Google Gemini (gemini)
```bash
export GOOGLE_API_KEY="sua_chave"
python3 main.py programa.cbl --provider gemini
```

### 7. Azure OpenAI (azure_openai)
```bash
export AZURE_OPENAI_API_KEY="sua_chave"
export AZURE_OPENAI_ENDPOINT="https://sua-instancia.openai.azure.com"
export AZURE_OPENAI_DEPLOYMENT="seu-deployment"
python3 main.py programa.cbl --provider azure_openai
```

### 8. Cohere (cohere)
```bash
export COHERE_API_KEY="sua_chave"
python3 main.py programa.cbl --provider cohere
```

### 9. HuggingFace (huggingface)
```bash
export HUGGINGFACE_API_KEY="sua_chave"
python3 main.py programa.cbl --provider huggingface
```

### 10. Ollama Local (ollama)
```bash
# Ollama deve estar rodando localmente
python3 main.py programa.cbl --provider ollama
```

### 11. Enhanced Mock (enhanced_mock) - Padrão
```bash
# Não requer configuração - sempre disponível
python3 main.py programa.cbl --provider enhanced_mock
```

## Formas de Execução

### 1. Análise Básica
```bash
# Análise padrão (Enhanced Mock)
python3 main.py programa.cbl

# Provider específico
python3 main.py programa.cbl --provider openai
python3 main.py programa.cbl --provider luzia
python3 main.py programa.cbl --provider bedrock
```

### 2. Análise Multi-IA (Recomendado)
```bash
# Multi-IA com audiência combinada
python3 main.py programa.cbl --mode multi_ai

# Audiências específicas
python3 main.py programa.cbl --mode multi_ai --audience technical
python3 main.py programa.cbl --mode multi_ai --audience executive
python3 main.py programa.cbl --mode multi_ai --audience business
python3 main.py programa.cbl --mode multi_ai --audience implementation
```

### 3. Múltiplos Programas
```bash
# Arquivo com lista de programas
python3 main.py fontes.txt

# Com copybooks
python3 main.py fontes.txt --copybooks BOOKS.txt

# Múltiplos arquivos
python3 main.py fontes.txt BOOKS.txt
```

### 4. Análise com Logging Detalhado
```bash
# Logging verboso
python3 main.py programa.cbl --verbose --provider luzia

# Logging silencioso
python3 main.py programa.cbl --quiet
```

### 5. Status do Sistema
```bash
# Status completo de todos os providers
python3 main.py --status
```

## Configuração Avançada

### Arquivo config.yaml Completo

```yaml
# Configuração SSL Global
ssl:
  verify: true
  cert_path: ${SSL_CERT_PATH}
  ca_bundle: ${SSL_CA_BUNDLE}

# Configuração de Provedores de IA
ai:
  primary_provider: "enhanced_mock"
  fallback_providers: ["openai", "luzia", "bedrock", "databricks"]
  global_max_tokens: 8000
  timeout: 180

  providers:
    # OpenAI GPT
    openai:
      enabled: true
      api_key: ${OPENAI_API_KEY}
      model: "gpt-4"
      temperature: 0.1
      max_tokens: 8000
      organization: ${OPENAI_ORG_ID}

    # Azure OpenAI
    azure_openai:
      enabled: false
      api_key: ${AZURE_OPENAI_API_KEY}
      endpoint: ${AZURE_OPENAI_ENDPOINT}
      deployment_name: ${AZURE_OPENAI_DEPLOYMENT}

    # LuzIA Corporativo
    luzia:
      enabled: true
      client_id: ${LUZIA_CLIENT_ID}
      client_secret: ${LUZIA_CLIENT_SECRET}
      auth_url: "https://login.azure.paas.santanderbr.pre.corp/auth/realms/corp/protocol/openid-connect/token"
      api_url: "https://gut-api-aws.santanderbr.dev.corp/genai_services/v1/"

    # AWS Bedrock
    bedrock:
      enabled: false
      aws_access_key_id: ${AWS_ACCESS_KEY_ID}
      aws_secret_access_key: ${AWS_SECRET_ACCESS_KEY}
      region: ${AWS_REGION}
      model: "anthropic.claude-3-sonnet-20240229-v1:0"

    # Databricks
    databricks:
      enabled: false
      host: ${DATABRICKS_HOST}
      token: ${DATABRICKS_TOKEN}
      endpoint: ${DATABRICKS_ENDPOINT}

    # Anthropic Claude
    anthropic:
      enabled: false
      api_key: ${ANTHROPIC_API_KEY}
      model: "claude-3-sonnet-20240229"

    # Google Gemini
    gemini:
      enabled: false
      api_key: ${GOOGLE_API_KEY}
      model: "gemini-pro"

    # Cohere
    cohere:
      enabled: false
      api_key: ${COHERE_API_KEY}
      model: "command-r-plus"

    # Hugging Face
    huggingface:
      enabled: false
      api_key: ${HUGGINGFACE_API_KEY}
      model: "microsoft/DialoGPT-large"

    # Ollama (Local)
    ollama:
      enabled: false
      base_url: "http://localhost:11434"
      model: "llama2"

    # Enhanced Mock (sempre habilitado)
    enhanced_mock:
      enabled: true
      model: "enhanced-mock-v1.0.0"

# Configuração de Logging
logging:
  level: "INFO"
  dir: "logs"
  prompt_logging: true
  performance_logging: true
```

## Logging e Monitoramento

### Logs Gerados

O sistema gera logs detalhados para cada provider:

```bash
logs/
├── cobol_analysis.log          # Log principal do sistema
├── luzia_prompts.log          # Prompts enviados para LuzIA
├── openai_prompts.log         # Prompts enviados para OpenAI
├── bedrock_prompts.log        # Prompts enviados para Bedrock
├── databricks_prompts.log     # Prompts enviados para Databricks
├── anthropic_prompts.log      # Prompts enviados para Anthropic
└── gemini_prompts.log         # Prompts enviados para Gemini
```

### Exemplo de Log de Prompt

```
================================================================================
TIMESTAMP: 2025-09-19T21:16:19.927348
PROMPT ENVIADO PARA LUZIA:
================================================================================
Modelo: azure-gpt-4o-mini
Temperatura: 0.1
Tamanho do prompt: 666 caracteres
--------------------------------------------------------------------------------
CONTEÚDO DO PROMPT:
--------------------------------------------------------------------------------
Analise o seguinte programa COBOL e forneça uma análise detalhada:
IDENTIFICATION DIVISION.
PROGRAM-ID. TESTE-PROGRAMA.
...
================================================================================
```

### Monitoramento em Tempo Real

```bash
# Acompanhar logs em tempo real
tail -f logs/cobol_analysis.log

# Logs específicos do LuzIA
tail -f logs/luzia_prompts.log

# Verificar status dos providers
python3 main.py --status
```

## Exemplos Práticos

### Cenário 1: Análise Corporativa com LuzIA

```bash
# Configurar ambiente corporativo
export LUZIA_CLIENT_ID="corp_client"
export LUZIA_CLIENT_SECRET="corp_secret"
export SSL_CERT_PATH="/etc/ssl/corp-cert.pem"

# Análise Multi-IA com LuzIA
python3 main.py sistema_completo.txt --mode multi_ai --provider luzia --verbose
```

### Cenário 2: Análise com AWS Bedrock

```bash
# Configurar AWS
export AWS_ACCESS_KEY_ID="AKIA..."
export AWS_SECRET_ACCESS_KEY="..."
export AWS_REGION="us-east-1"

# Análise com Claude via Bedrock
python3 main.py programas_legacy.txt --provider bedrock --audience technical
```

### Cenário 3: Análise com Múltiplos Providers

```bash
# Análise com fallback automático
python3 main.py fontes.txt --mode auto --provider openai

# Se OpenAI falhar, usa automaticamente o próximo provider disponível
```

### Cenário 4: Desenvolvimento Local com Ollama

```bash
# Iniciar Ollama
ollama serve

# Análise local
python3 main.py programa.cbl --provider ollama --verbose
```

## Estrutura de Saída

### Arquivos Gerados por Programa

Para cada programa analisado:

1. **`PROGRAMA_MULTI_AI_ANALYSIS.md`**: Documentação principal
2. **`PROGRAMA_technical_data.json`**: Dados técnicos estruturados
3. **Logs específicos**: Em `logs/provider_prompts.log`

### Exemplo de Estrutura de Resultados

```
analysis_results/
├── LHAN0542_MULTI_AI_ANALYSIS.md
├── LHAN0542_technical_data.json
├── LHAN0705_MULTI_AI_ANALYSIS.md
├── LHAN0705_technical_data.json
├── LHAN0706_MULTI_AI_ANALYSIS.md
└── LHAN0706_technical_data.json
```

## Troubleshooting

### Problemas por Provider

#### 1. OpenAI
```
Erro: Invalid API key
```
**Solução**: Verificar `OPENAI_API_KEY`

#### 2. LuzIA
```
Erro: Name resolution failed
```
**Solução**: Verificar conectividade corporativa e certificados SSL

#### 3. Bedrock
```
Erro: Credentials not found
```
**Solução**: Configurar credenciais AWS corretamente

#### 4. Databricks
```
Erro: Unauthorized
```
**Solução**: Verificar token e endpoint do Databricks

### Verificação de Status

```bash
# Status detalhado de todos os providers
python3 main.py --status

# Logs de erro específicos
grep "ERROR" logs/cobol_analysis.log

# Testar provider específico
python3 main.py examples/LHAN0542_TESTE.cbl --provider luzia --verbose
```

## Referência Completa

### Argumentos da Linha de Comando

| Argumento | Tipo | Descrição | Padrão |
|-----------|------|-----------|--------|
| `input_files` | Posicional | Arquivos COBOL ou lista | Obrigatório |
| `--provider` | Choice | Provider de IA | `enhanced_mock` |
| `--mode` | Choice | Modo de análise | `auto` |
| `--audience` | Choice | Audiência alvo | `combined` |
| `--copybooks` | String | Arquivo de copybooks | Opcional |
| `--output` | String | Diretório de saída | `analysis_results` |
| `--verbose` | Flag | Logging verboso | - |
| `--quiet` | Flag | Saída silenciosa | - |
| `--status` | Flag | Verificar status | - |

### Providers Disponíveis

| Provider | Comando | Configuração Necessária |
|----------|---------|------------------------|
| `openai` | `--provider openai` | `OPENAI_API_KEY` |
| `luzia` | `--provider luzia` | `LUZIA_CLIENT_ID`, `LUZIA_CLIENT_SECRET` |
| `bedrock` | `--provider bedrock` | `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY` |
| `databricks` | `--provider databricks` | `DATABRICKS_HOST`, `DATABRICKS_TOKEN` |
| `anthropic` | `--provider anthropic` | `ANTHROPIC_API_KEY` |
| `gemini` | `--provider gemini` | `GOOGLE_API_KEY` |
| `azure_openai` | `--provider azure_openai` | `AZURE_OPENAI_API_KEY`, `AZURE_OPENAI_ENDPOINT` |
| `cohere` | `--provider cohere` | `COHERE_API_KEY` |
| `huggingface` | `--provider huggingface` | `HUGGINGFACE_API_KEY` |
| `ollama` | `--provider ollama` | Ollama rodando localmente |
| `enhanced_mock` | `--provider enhanced_mock` | Nenhuma (padrão) |

### Variáveis de Ambiente Suportadas

| Variável | Descrição | Provider |
|----------|-----------|----------|
| `OPENAI_API_KEY` | Chave da API OpenAI | OpenAI |
| `OPENAI_ORG_ID` | ID da organização OpenAI | OpenAI |
| `LUZIA_CLIENT_ID` | Client ID do LuzIA | LuzIA |
| `LUZIA_CLIENT_SECRET` | Client Secret do LuzIA | LuzIA |
| `AWS_ACCESS_KEY_ID` | Chave de acesso AWS | Bedrock |
| `AWS_SECRET_ACCESS_KEY` | Chave secreta AWS | Bedrock |
| `AWS_REGION` | Região AWS | Bedrock |
| `DATABRICKS_HOST` | Host do Databricks | Databricks |
| `DATABRICKS_TOKEN` | Token do Databricks | Databricks |
| `ANTHROPIC_API_KEY` | Chave da API Anthropic | Anthropic |
| `GOOGLE_API_KEY` | Chave da API Google | Gemini |
| `SSL_CERT_PATH` | Caminho do certificado SSL | Global |

---

## Suporte e Contato

**Versão**: 1.0 FINAL  
**Data**: 2025-09-19  
**Compatibilidade**: Python 3.11+, COBOL-85/2002/2014  
**Providers Suportados**: 11 diferentes  
**Logging**: Transparente para todos os providers
