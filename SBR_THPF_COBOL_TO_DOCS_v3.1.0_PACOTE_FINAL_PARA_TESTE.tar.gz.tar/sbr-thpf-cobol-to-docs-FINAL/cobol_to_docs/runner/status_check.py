#!/usr/bin/env python3
"""
Script simples para verificar status do COBOL Analyzer
"""

import sys
import os
import argparse

# Configurar paths
script_dir = os.path.dirname(os.path.abspath(__file__))
cobol_to_docs_dir = os.path.dirname(script_dir)
src_dir = os.path.join(cobol_to_docs_dir, 'src')
sys.path.insert(0, src_dir)

def check_status():
    """Verificar status do sistema"""
    print("=== STATUS DO SISTEMA COBOL ANALYZER ===")
    
    # Verificar configuração
    config_path = "config/config.yaml"
    if os.path.exists(config_path):
        print(f"✓ Configuração encontrada: {config_path}")
        
        try:
            from core.config import ConfigManager
            config_manager = ConfigManager(config_path)
            print("✓ ConfigManager inicializado com sucesso")
            
            # Verificar prompts
            prompts_path = "config/prompts_enhanced.yaml"
            if os.path.exists(prompts_path):
                print(f"✓ Prompts encontrados: {prompts_path}")
            else:
                print(f"⚠ Prompts não encontrados: {prompts_path}")
                
        except Exception as e:
            print(f"✗ Erro ao carregar configuração: {e}")
    else:
        print(f"✗ Configuração não encontrada: {config_path}")
    
    # Verificar diretórios
    directories = ['logs', 'output', 'temp', 'config', 'data', 'examples']
    for directory in directories:
        if os.path.exists(directory):
            print(f"✓ Diretório {directory}: OK")
        else:
            print(f"✗ Diretório {directory}: Não encontrado")
    
    # Verificar providers disponíveis
    print("\nModelos Disponíveis:")
    print("Enhanced Mock (Desenvolvimento)")
    
    print("\nSistema pronto para uso!")
    print("Para inicializar projeto: python cobol_to_docs.py --init")
    print("Para análise: python main.py --fontes arquivo.txt --models enhanced_mock")

def main():
    parser = argparse.ArgumentParser(description="Status do COBOL Analyzer")
    parser.add_argument("--status", action="store_true", help="Verificar status do sistema")
    
    args = parser.parse_args()
    
    if args.status or len(sys.argv) == 1:
        check_status()
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
