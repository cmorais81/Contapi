#!/usr/bin/env python3
"""
Purpose Extractor - COBOL AI Engine v14.0
Foca especificamente em extrair e explicar o PROPÓSITO de cada programa COBOL
"""

import re
import logging
from typing import Dict, List, Any, Optional
from dataclasses import dataclass

@dataclass
class ProgramPurpose:
    """Representa o propósito identificado de um programa."""
    program_name: str
    main_purpose: str  # Uma frase explicando o que faz
    action_verb: str   # Verbo principal (quebrar, validar, processar)
    input_files: List[str]
    output_files: List[str]
    business_domain: str  # BACEN, FINANCEIRO, etc.
    confidence: float  # 0.0 a 1.0

class PurposeExtractor:
    """
    Extrator de Propósito Inteligente
    
    Foca em identificar PARA QUE serve cada programa COBOL,
    em linguagem clara e objetiva.
    """

    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
        # Verbos de ação comuns em sistemas COBOL
        self.action_verbs = {
            'PARTICIONAR': ['PARTICIONAR', 'DIVIDIR', 'QUEBRAR', 'SPLIT', 'SEPARAR'],
            'VALIDAR': ['VALIDAR', 'VERIFICAR', 'CHECAR', 'CONFERIR', 'CRITICAR'],
            'PROCESSAR': ['PROCESSAR', 'EXECUTAR', 'RODAR', 'CALCULAR'],
            'GERAR': ['GERAR', 'CRIAR', 'PRODUZIR', 'EMITIR'],
            'CONVERTER': ['CONVERTER', 'TRANSFORMAR', 'TRADUZIR'],
            'CONSOLIDAR': ['CONSOLIDAR', 'AGRUPAR', 'JUNTAR', 'UNIR'],
            'ROTEAR': ['ROTEAR', 'DIRECIONAR', 'ENCAMINHAR', 'DISTRIBUIR'],
            'EXTRAIR': ['EXTRAIR', 'BUSCAR', 'SELECIONAR', 'FILTRAR'],
            'ATUALIZAR': ['ATUALIZAR', 'MODIFICAR', 'ALTERAR', 'CORRIGIR'],
            'RELATORIO': ['RELATORIO', 'LISTAR', 'IMPRIMIR', 'EXIBIR']
        }
        
        # Domínios de negócio
        self.business_domains = {
            'BACEN': ['BACEN', 'BCB', 'BANCO CENTRAL', 'DOC3040', 'STR'],
            'FINANCEIRO': ['FINANCEIRO', 'CONTA', 'SALDO', 'MOVIMENTO'],
            'CONTABIL': ['CONTABIL', 'BALANCETE', 'RAZAO', 'DIARIO'],
            'OPERACIONAL': ['OPERACIONAL', 'BATCH', 'JOB', 'PROCESSO'],
            'REGULATORIO': ['REGULATORIO', 'COMPLIANCE', 'AUDITORIA']
        }
        
        # Padrões de arquivos
        self.file_patterns = {
            'INPUT': [r'([A-Z0-9]+E\d+)', r'INPUT', r'ENTRADA', r'LEITURA'],
            'OUTPUT': [r'([A-Z0-9]+S\d+)', r'OUTPUT', r'SAIDA', r'GRAVACAO'],
            'WORK': [r'([A-Z0-9]+W\d+)', r'WORK', r'TEMP', r'TEMPORARIO'],
            'CONTROL': [r'([A-Z0-9]+C\d+)', r'CONTROL', r'CONTROLE', r'PARAM']
        }

    def extract_purpose(self, program_name: str, code_lines: List[str], 
                       comments: List[str] = None) -> ProgramPurpose:
        """
        Extrai o propósito principal do programa COBOL.
        """
        self.logger.info(f"Extraindo propósito de {program_name}")
        
        # Combina código e comentários
        all_text = '\n'.join(code_lines)
        if comments:
            all_text += '\n' + '\n'.join(comments)
        
        # Identifica verbo de ação principal
        action_verb = self._identify_action_verb(program_name, all_text)
        
        # Identifica domínio de negócio
        business_domain = self._identify_business_domain(program_name, all_text)
        
        # Extrai arquivos de entrada e saída
        input_files = self._extract_files(all_text, 'INPUT')
        output_files = self._extract_files(all_text, 'OUTPUT')
        
        # Gera descrição do propósito
        main_purpose = self._generate_purpose_description(
            program_name, action_verb, business_domain, 
            input_files, output_files, all_text
        )
        
        # Calcula confiança
        confidence = self._calculate_confidence(
            action_verb, business_domain, input_files, output_files
        )
        
        return ProgramPurpose(
            program_name=program_name,
            main_purpose=main_purpose,
            action_verb=action_verb,
            input_files=input_files,
            output_files=output_files,
            business_domain=business_domain,
            confidence=confidence
        )

    def _identify_action_verb(self, program_name: str, text: str) -> str:
        """Identifica o verbo de ação principal."""
        text_upper = text.upper()
        program_upper = program_name.upper()
        
        # Pontuação por categoria
        verb_scores = {}
        
        for category, verbs in self.action_verbs.items():
            score = 0
            for verb in verbs:
                # Busca no nome do programa (peso maior)
                if verb in program_upper:
                    score += 10
                
                # Busca em comentários (peso médio)
                comment_matches = len(re.findall(rf'\*.*{verb}', text_upper))
                score += comment_matches * 5
                
                # Busca no código geral (peso menor)
                code_matches = len(re.findall(rf'{verb}', text_upper))
                score += code_matches * 1
            
            if score > 0:
                verb_scores[category] = score
        
        # Retorna o verbo com maior pontuação
        if verb_scores:
            return max(verb_scores.items(), key=lambda x: x[1])[0]
        
        return 'PROCESSAR'  # Default

    def _identify_business_domain(self, program_name: str, text: str) -> str:
        """Identifica o domínio de negócio."""
        text_upper = text.upper()
        program_upper = program_name.upper()
        
        domain_scores = {}
        
        for domain, keywords in self.business_domains.items():
            score = 0
            for keyword in keywords:
                if keyword in program_upper:
                    score += 10
                if keyword in text_upper:
                    score += text_upper.count(keyword)
            
            if score > 0:
                domain_scores[domain] = score
        
        if domain_scores:
            return max(domain_scores.items(), key=lambda x: x[1])[0]
        
        return 'OPERACIONAL'  # Default

    def _extract_files(self, text: str, file_type: str) -> List[str]:
        """Extrai arquivos do tipo especificado."""
        files = []
        patterns = self.file_patterns.get(file_type, [])
        
        for pattern in patterns:
            matches = re.findall(pattern, text, re.IGNORECASE)
            files.extend(matches)
        
        # Remove duplicatas e ordena
        return sorted(list(set(files)))

    def _generate_purpose_description(self, program_name: str, action_verb: str,
                                    business_domain: str, input_files: List[str],
                                    output_files: List[str], text: str) -> str:
        """Gera descrição clara do propósito."""
        
        # Templates por verbo de ação
        templates = {
            'PARTICIONAR': f"Quebra arquivos {business_domain} em partes menores",
            'VALIDAR': f"Valida dados {business_domain} conforme regras específicas",
            'PROCESSAR': f"Processa informações {business_domain}",
            'GERAR': f"Gera relatórios/arquivos {business_domain}",
            'CONVERTER': f"Converte dados {business_domain} entre formatos",
            'CONSOLIDAR': f"Consolida informações {business_domain}",
            'ROTEAR': f"Roteia dados {business_domain} por tipo/critério",
            'EXTRAIR': f"Extrai informações específicas {business_domain}",
            'ATUALIZAR': f"Atualiza registros {business_domain}",
            'RELATORIO': f"Emite relatórios {business_domain}"
        }
        
        base_description = templates.get(action_verb, f"Processa dados {business_domain}")
        
        # Adiciona detalhes específicos baseados no contexto
        details = []
        
        # Detalhes sobre arquivos
        if len(input_files) > 1:
            details.append(f"múltiplas entradas ({len(input_files)} arquivos)")
        if len(output_files) > 1:
            details.append(f"múltiplas saídas ({len(output_files)} arquivos)")
        
        # Detalhes específicos do domínio
        text_upper = text.upper()
        if 'DOC3040' in text_upper:
            details.append("formato DOC3040")
        if '4000' in text_upper or '4GB' in text_upper:
            details.append("limite de 4GB por arquivo")
        if 'TIPO' in text_upper and 'REGISTRO' in text_upper:
            details.append("por tipo de registro")
        
        # Combina descrição base com detalhes
        if details:
            return f"{base_description} - {', '.join(details)}"
        
        return base_description

    def _calculate_confidence(self, action_verb: str, business_domain: str,
                            input_files: List[str], output_files: List[str]) -> float:
        """Calcula confiança na identificação do propósito."""
        confidence = 0.0
        
        # Confiança base por verbo identificado
        if action_verb != 'PROCESSAR':  # Não é default
            confidence += 0.3
        
        # Confiança por domínio identificado
        if business_domain != 'OPERACIONAL':  # Não é default
            confidence += 0.2
        
        # Confiança por arquivos identificados
        if input_files:
            confidence += 0.2
        if output_files:
            confidence += 0.2
        
        # Bônus por múltiplos arquivos (indica complexidade)
        if len(input_files) > 1 or len(output_files) > 1:
            confidence += 0.1
        
        return min(confidence, 1.0)

    def generate_purpose_report(self, purpose: ProgramPurpose) -> str:
        """Gera relatório do propósito em formato markdown."""
        
        confidence_emoji = "🟢" if purpose.confidence > 0.7 else "🟡" if purpose.confidence > 0.4 else "🔴"
        
        report = [
            f"## 🎯 {purpose.program_name} - {purpose.action_verb}",
            "",
            f"**Propósito:** {purpose.main_purpose}",
            f"**Confiança:** {confidence_emoji} {purpose.confidence:.1%}",
            f"**Domínio:** {purpose.business_domain}",
            "",
            "### 📁 Fluxo de Arquivos",
            ""
        ]
        
        if purpose.input_files:
            report.append("**Entrada:**")
            for file in purpose.input_files:
                report.append(f"- {file}")
            report.append("")
        
        if purpose.output_files:
            report.append("**Saída:**")
            for file in purpose.output_files:
                report.append(f"- {file}")
            report.append("")
        
        if not purpose.input_files and not purpose.output_files:
            report.append("*Arquivos não identificados automaticamente*")
            report.append("")
        
        # Fluxo visual simples
        input_str = " + ".join(purpose.input_files[:3]) if purpose.input_files else "ENTRADA"
        output_str = " + ".join(purpose.output_files[:3]) if purpose.output_files else "SAÍDA"
        
        report.extend([
            "### 🔄 Fluxo Simplificado",
            "",
            f"```",
            f"{input_str} → [{purpose.action_verb}] → {output_str}",
            f"```",
            ""
        ])
        
        return '\n'.join(report)
