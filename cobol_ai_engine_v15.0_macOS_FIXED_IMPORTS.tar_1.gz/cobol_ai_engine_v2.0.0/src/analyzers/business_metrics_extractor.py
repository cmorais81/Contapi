import re
import logging
from typing import Dict, Any, List, Optional
from dataclasses import dataclass
from datetime import datetime

@dataclass
class BusinessMetric:
    """Representa uma métrica de negócio identificada."""
    name: str
    value: Any
    unit: str
    confidence: float  # 0.0 a 1.0
    source_line: int
    description: str

@dataclass
class OperationalWindow:
    """Representa uma janela operacional identificada."""
    name: str
    start_time: Optional[str]
    end_time: Optional[str]
    frequency: str  # DAILY, WEEKLY, MONTHLY
    estimated_duration: Optional[int]  # em minutos
    criticality: str  # HIGH, MEDIUM, LOW

class BusinessMetricsExtractor:
    """
    Extrator de Métricas de Negócio
    
    Identifica métricas operacionais críticas como volume de dados,
    janelas de processamento, dependências e pontos de falha.
    """

    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
        # Padrões para identificar métricas
        self.volume_patterns = [
            r'(\d+)\s*(RECORDS?|REGISTROS?)',
            r'(\d+)\s*(MB|GB|KB)',
            r'(\d+)\s*(MILLION|THOUSAND|MIL|MILHAO)',
            r'(\d+)\s*(LINES?|LINHAS?)',
            r'(\d+)\s*(BYTES?)'
        ]
        
        self.time_patterns = [
            r'(\d{1,2}):(\d{2})',  # HH:MM
            r'(\d{1,2})H(\d{2})',  # HHhMM
            r'(DAILY|DIARIO|DIARIAMENTE)',
            r'(WEEKLY|SEMANAL|SEMANALMENTE)',
            r'(MONTHLY|MENSAL|MENSALMENTE)',
            r'(BATCH|LOTE)',
            r'(OVERNIGHT|NOTURNO)',
            r'(BUSINESS\s+HOURS?|HORARIO\s+COMERCIAL)'
        ]
        
        self.dependency_patterns = [
            r'(CALL\s+[\'"]([^\'"]+)[\'"])',
            r'(COPY\s+([A-Z0-9-]+))',
            r'(SELECT\s+[A-Z0-9-]+\s+ASSIGN\s+TO\s+([A-Z0-9-]+))',
            r'(EXEC\s+SQL)',
            r'(EXEC\s+CICS)'
        ]

    def extract_business_metrics(self, program_name: str, code_lines: List[str], 
                                comments: List[str] = None) -> Dict[str, Any]:
        """
        Extrai métricas de negócio do código COBOL.
        """
        self.logger.info(f"Extraindo métricas de negócio para {program_name}")
        
        code_text = '\n'.join(code_lines)
        comments_text = '\n'.join(comments) if comments else ""
        full_text = code_text + "\n" + comments_text
        
        # Extrai diferentes tipos de métricas
        volume_metrics = self._extract_volume_metrics(full_text, code_lines)
        performance_metrics = self._extract_performance_metrics(full_text, code_lines)
        operational_windows = self._extract_operational_windows(full_text, code_lines)
        dependencies = self._extract_dependencies(code_text, code_lines)
        criticality_indicators = self._extract_criticality_indicators(full_text, code_lines)
        
        # Calcula métricas derivadas
        business_impact = self._calculate_business_impact(
            volume_metrics, performance_metrics, operational_windows, dependencies
        )
        
        # Gera insights operacionais
        operational_insights = self._generate_operational_insights(
            volume_metrics, performance_metrics, operational_windows, dependencies
        )
        
        return {
            "program_name": program_name,
            "volume_metrics": volume_metrics,
            "performance_metrics": performance_metrics,
            "operational_windows": operational_windows,
            "dependencies": dependencies,
            "criticality_indicators": criticality_indicators,
            "business_impact": business_impact,
            "operational_insights": operational_insights,
            "extraction_timestamp": datetime.now().isoformat()
        }

    def _extract_volume_metrics(self, text: str, code_lines: List[str]) -> List[BusinessMetric]:
        """Extrai métricas de volume de dados."""
        metrics = []
        
        for i, line in enumerate(code_lines):
            line_upper = line.upper()
            
            # Procura por padrões de volume
            for pattern in self.volume_patterns:
                matches = re.finditer(pattern, line_upper)
                for match in matches:
                    value = match.group(1)
                    unit = match.group(2) if match.lastindex > 1 else "UNITS"
                    
                    # Determina confiança baseada no contexto
                    confidence = self._calculate_confidence(line, ["RECORDS", "MB", "GB", "VOLUME"])
                    
                    metrics.append(BusinessMetric(
                        name=f"Volume_{unit.lower()}",
                        value=int(value),
                        unit=unit,
                        confidence=confidence,
                        source_line=i + 1,
                        description=f"Volume de {unit.lower()} identificado: {value}"
                    ))
        
        # Procura por indicadores indiretos de volume
        indirect_indicators = [
            ("OCCURS", "array_size", "ELEMENTS"),
            ("BLOCK", "block_size", "RECORDS"),
            ("BUFFER", "buffer_size", "BYTES")
        ]
        
        for keyword, metric_name, unit in indirect_indicators:
            pattern = rf'{keyword}\s+(\d+)'
            matches = re.finditer(pattern, text, re.IGNORECASE)
            for match in matches:
                value = int(match.group(1))
                line_num = text[:match.start()].count('\n') + 1
                
                metrics.append(BusinessMetric(
                    name=metric_name,
                    value=value,
                    unit=unit,
                    confidence=0.7,
                    source_line=line_num,
                    description=f"Tamanho de {keyword.lower()} identificado: {value}"
                ))
        
        return metrics

    def _extract_performance_metrics(self, text: str, code_lines: List[str]) -> List[BusinessMetric]:
        """Extrai métricas de performance."""
        metrics = []
        
        # Procura por indicadores de performance
        performance_keywords = [
            ("SORT", "sort_operation", "OPERATIONS"),
            ("INDEX", "indexed_access", "ACCESSES"),
            ("SEARCH", "search_operation", "SEARCHES"),
            ("COMPUTE", "computation", "CALCULATIONS"),
            ("CALL", "external_call", "CALLS")
        ]
        
        for keyword, metric_name, unit in performance_keywords:
            count = text.upper().count(keyword)
            if count > 0:
                # Encontra primeira ocorrência para linha de referência
                first_occurrence = text.upper().find(keyword)
                line_num = text[:first_occurrence].count('\n') + 1
                
                # Estima impacto na performance
                if keyword in ["SORT", "SEARCH"]:
                    impact = "HIGH" if count > 5 else "MEDIUM"
                elif keyword in ["COMPUTE", "CALL"]:
                    impact = "MEDIUM" if count > 10 else "LOW"
                else:
                    impact = "LOW"
                
                metrics.append(BusinessMetric(
                    name=metric_name,
                    value=count,
                    unit=unit,
                    confidence=0.8,
                    source_line=line_num,
                    description=f"{count} operações {keyword} identificadas (Impacto: {impact})"
                ))
        
        return metrics

    def _extract_operational_windows(self, text: str, code_lines: List[str]) -> List[OperationalWindow]:
        """Extrai janelas operacionais."""
        windows = []
        
        # Procura por padrões de tempo
        time_references = []
        for i, line in enumerate(code_lines):
            line_upper = line.upper()
            
            # Horários específicos
            time_matches = re.finditer(r'(\d{1,2}):(\d{2})', line)
            for match in time_matches:
                hour, minute = match.groups()
                time_references.append({
                    'time': f"{hour}:{minute}",
                    'line': i + 1,
                    'context': line.strip()
                })
            
            # Frequências
            frequency_patterns = [
                (r'(DAILY|DIARIO)', 'DAILY'),
                (r'(WEEKLY|SEMANAL)', 'WEEKLY'),
                (r'(MONTHLY|MENSAL)', 'MONTHLY'),
                (r'(BATCH|LOTE)', 'BATCH'),
                (r'(OVERNIGHT|NOTURNO)', 'OVERNIGHT')
            ]
            
            for pattern, freq_type in frequency_patterns:
                if re.search(pattern, line_upper):
                    windows.append(OperationalWindow(
                        name=f"{freq_type}_PROCESSING",
                        start_time=None,
                        end_time=None,
                        frequency=freq_type,
                        estimated_duration=self._estimate_duration(freq_type),
                        criticality=self._estimate_criticality(line, freq_type)
                    ))
        
        # Analisa padrões de janela de processamento
        if "BATCH" in text.upper() or "OVERNIGHT" in text.upper():
            windows.append(OperationalWindow(
                name="BATCH_WINDOW",
                start_time="22:00",
                end_time="06:00",
                frequency="DAILY",
                estimated_duration=480,  # 8 horas
                criticality="HIGH"
            ))
        
        return windows

    def _extract_dependencies(self, code_text: str, code_lines: List[str]) -> Dict[str, List[str]]:
        """Extrai dependências do programa."""
        dependencies = {
            "external_programs": [],
            "copybooks": [],
            "files": [],
            "databases": [],
            "middleware": []
        }
        
        # Programas externos (CALL)
        call_matches = re.finditer(r'CALL\s+[\'"]([^\'"]+)[\'"]', code_text, re.IGNORECASE)
        for match in call_matches:
            program = match.group(1)
            dependencies["external_programs"].append(program)
        
        # Copybooks (COPY)
        copy_matches = re.finditer(r'COPY\s+([A-Z0-9-]+)', code_text, re.IGNORECASE)
        for match in copy_matches:
            copybook = match.group(1)
            dependencies["copybooks"].append(copybook)
        
        # Arquivos (SELECT/ASSIGN)
        file_matches = re.finditer(r'SELECT\s+([A-Z0-9-]+)\s+ASSIGN\s+TO\s+([A-Z0-9-]+)', code_text, re.IGNORECASE)
        for match in file_matches:
            logical_name, physical_name = match.groups()
            dependencies["files"].append(f"{logical_name} -> {physical_name}")
        
        # SQL (EXEC SQL)
        if "EXEC SQL" in code_text.upper():
            dependencies["databases"].append("DB2/SQL_DATABASE")
        
        # CICS (EXEC CICS)
        if "EXEC CICS" in code_text.upper():
            dependencies["middleware"].append("CICS_TRANSACTION_SERVER")
        
        # MQ/Messaging
        if any(keyword in code_text.upper() for keyword in ["MQ", "QUEUE", "MESSAGE"]):
            dependencies["middleware"].append("MESSAGE_QUEUE")
        
        return dependencies

    def _extract_criticality_indicators(self, text: str, code_lines: List[str]) -> Dict[str, Any]:
        """Extrai indicadores de criticidade do programa."""
        indicators = {
            "error_handling_coverage": 0,
            "backup_procedures": False,
            "monitoring_points": 0,
            "recovery_mechanisms": 0,
            "audit_trail": False,
            "security_controls": 0
        }
        
        # Cobertura de tratamento de erros
        error_keywords = ["FILE STATUS", "INVALID KEY", "AT END", "ERROR", "EXCEPTION"]
        error_count = sum(text.upper().count(keyword) for keyword in error_keywords)
        total_operations = text.upper().count("PERFORM") + text.upper().count("CALL")
        
        if total_operations > 0:
            indicators["error_handling_coverage"] = min(100, (error_count / total_operations) * 100)
        
        # Procedimentos de backup
        backup_keywords = ["BACKUP", "CHECKPOINT", "ROLLBACK", "COMMIT"]
        indicators["backup_procedures"] = any(keyword in text.upper() for keyword in backup_keywords)
        
        # Pontos de monitoramento
        monitor_keywords = ["DISPLAY", "WRITE", "LOG", "TRACE"]
        indicators["monitoring_points"] = sum(text.upper().count(keyword) for keyword in monitor_keywords)
        
        # Mecanismos de recuperação
        recovery_keywords = ["RESTART", "RECOVERY", "RESUME", "CONTINUE"]
        indicators["recovery_mechanisms"] = sum(text.upper().count(keyword) for keyword in recovery_keywords)
        
        # Trilha de auditoria
        audit_keywords = ["AUDIT", "LOG", "TIMESTAMP", "USER-ID"]
        indicators["audit_trail"] = any(keyword in text.upper() for keyword in audit_keywords)
        
        # Controles de segurança
        security_keywords = ["PASSWORD", "SECURITY", "AUTHORIZATION", "ACCESS"]
        indicators["security_controls"] = sum(text.upper().count(keyword) for keyword in security_keywords)
        
        return indicators

    def _calculate_business_impact(self, volume_metrics: List[BusinessMetric], 
                                 performance_metrics: List[BusinessMetric],
                                 operational_windows: List[OperationalWindow],
                                 dependencies: Dict[str, List[str]]) -> Dict[str, Any]:
        """Calcula o impacto no negócio baseado nas métricas."""
        impact = {
            "volume_impact": "LOW",
            "performance_impact": "LOW",
            "operational_impact": "LOW",
            "dependency_risk": "LOW",
            "overall_business_criticality": "LOW"
        }
        
        # Impacto de volume
        max_volume = 0
        for metric in volume_metrics:
            if metric.unit in ["RECORDS", "REGISTROS"]:
                max_volume = max(max_volume, metric.value)
        
        if max_volume > 1000000:  # > 1M registros
            impact["volume_impact"] = "HIGH"
        elif max_volume > 100000:  # > 100K registros
            impact["volume_impact"] = "MEDIUM"
        
        # Impacto de performance
        high_impact_ops = sum(1 for m in performance_metrics 
                             if m.name in ["sort_operation", "search_operation"] and m.value > 5)
        if high_impact_ops > 2:
            impact["performance_impact"] = "HIGH"
        elif high_impact_ops > 0:
            impact["performance_impact"] = "MEDIUM"
        
        # Impacto operacional
        critical_windows = sum(1 for w in operational_windows if w.criticality == "HIGH")
        if critical_windows > 1:
            impact["operational_impact"] = "HIGH"
        elif critical_windows > 0:
            impact["operational_impact"] = "MEDIUM"
        
        # Risco de dependências
        total_deps = sum(len(deps) for deps in dependencies.values())
        if total_deps > 10:
            impact["dependency_risk"] = "HIGH"
        elif total_deps > 5:
            impact["dependency_risk"] = "MEDIUM"
        
        # Criticidade geral
        high_impacts = sum(1 for v in impact.values() if v == "HIGH")
        if high_impacts >= 2:
            impact["overall_business_criticality"] = "HIGH"
        elif high_impacts >= 1 or sum(1 for v in impact.values() if v == "MEDIUM") >= 2:
            impact["overall_business_criticality"] = "MEDIUM"
        
        return impact

    def _generate_operational_insights(self, volume_metrics: List[BusinessMetric],
                                     performance_metrics: List[BusinessMetric],
                                     operational_windows: List[OperationalWindow],
                                     dependencies: Dict[str, List[str]]) -> List[str]:
        """Gera insights operacionais baseados nas métricas."""
        insights = []
        
        # Insights de volume
        high_volume_metrics = [m for m in volume_metrics if m.value > 100000]
        if high_volume_metrics:
            insights.append(
                f"VOLUME: Programa processa alto volume de dados "
                f"({max(m.value for m in high_volume_metrics):,} registros). "
                "Considere otimizações de performance e monitoramento de recursos."
            )
        
        # Insights de performance
        performance_bottlenecks = [m for m in performance_metrics 
                                 if m.name in ["sort_operation", "search_operation"] and m.value > 3]
        if performance_bottlenecks:
            insights.append(
                "PERFORMANCE: Múltiplas operações de ordenação/busca identificadas. "
                "Avalie uso de índices e otimização de algoritmos."
            )
        
        # Insights operacionais
        batch_windows = [w for w in operational_windows if w.frequency in ["BATCH", "OVERNIGHT"]]
        if batch_windows:
            insights.append(
                "OPERACIONAL: Programa executa em janela batch. "
                "Garanta monitoramento adequado e procedimentos de recovery."
            )
        
        # Insights de dependências
        external_deps = len(dependencies.get("external_programs", []))
        if external_deps > 5:
            insights.append(
                f"DEPENDÊNCIAS: Alto acoplamento ({external_deps} programas externos). "
                "Mapeie todas as dependências antes de mudanças."
            )
        
        # Insights de arquivos
        file_deps = len(dependencies.get("files", []))
        if file_deps > 3:
            insights.append(
                f"ARQUIVOS: Programa acessa {file_deps} arquivos diferentes. "
                "Valide integridade e disponibilidade de todos os arquivos."
            )
        
        return insights

    def _calculate_confidence(self, line: str, keywords: List[str]) -> float:
        """Calcula confiança baseada no contexto da linha."""
        base_confidence = 0.5
        
        for keyword in keywords:
            if keyword.upper() in line.upper():
                base_confidence += 0.2
        
        # Reduz confiança se estiver em comentário
        if line.strip().startswith('*'):
            base_confidence *= 0.7
        
        return min(1.0, base_confidence)

    def _estimate_duration(self, frequency_type: str) -> int:
        """Estima duração em minutos baseada no tipo de frequência."""
        duration_map = {
            "DAILY": 60,
            "WEEKLY": 180,
            "MONTHLY": 480,
            "BATCH": 240,
            "OVERNIGHT": 480
        }
        return duration_map.get(frequency_type, 60)

    def _estimate_criticality(self, line: str, frequency_type: str) -> str:
        """Estima criticidade baseada no contexto."""
        critical_keywords = ["CRITICAL", "URGENT", "PRIORITY", "ESSENTIAL"]
        
        if any(keyword in line.upper() for keyword in critical_keywords):
            return "HIGH"
        elif frequency_type in ["DAILY", "BATCH"]:
            return "HIGH"
        elif frequency_type in ["WEEKLY"]:
            return "MEDIUM"
        else:
            return "LOW"

    def generate_business_metrics_report(self, metrics_analysis: Dict[str, Any]) -> str:
        """Gera relatório de métricas de negócio em formato Markdown."""
        program_name = metrics_analysis["program_name"]
        volume_metrics = metrics_analysis["volume_metrics"]
        performance_metrics = metrics_analysis["performance_metrics"]
        operational_windows = metrics_analysis["operational_windows"]
        dependencies = metrics_analysis["dependencies"]
        business_impact = metrics_analysis["business_impact"]
        insights = metrics_analysis["operational_insights"]
        
        report = [
            f"# 📊 Métricas de Negócio - {program_name}",
            "",
            "## 🎯 Impacto no Negócio",
            f"- **Criticidade Geral:** {business_impact['overall_business_criticality']}",
            f"- **Impacto de Volume:** {business_impact['volume_impact']}",
            f"- **Impacto de Performance:** {business_impact['performance_impact']}",
            f"- **Impacto Operacional:** {business_impact['operational_impact']}",
            f"- **Risco de Dependências:** {business_impact['dependency_risk']}",
            "",
            "## 📈 Métricas de Volume",
            ""
        ]
        
        if volume_metrics:
            report.append("| Métrica | Valor | Unidade | Confiança | Linha |")
            report.append("|---------|-------|---------|-----------|-------|")
            for metric in volume_metrics:
                confidence_pct = f"{metric.confidence*100:.0f}%"
                report.append(f"| {metric.name} | {metric.value:,} | {metric.unit} | {confidence_pct} | {metric.source_line} |")
        else:
            report.append("*Nenhuma métrica de volume específica identificada.*")
        
        report.extend([
            "",
            "## ⚡ Métricas de Performance",
            ""
        ])
        
        if performance_metrics:
            report.append("| Operação | Quantidade | Impacto Estimado | Linha |")
            report.append("|----------|------------|------------------|-------|")
            for metric in performance_metrics:
                impact = "ALTO" if metric.value > 10 else "MÉDIO" if metric.value > 5 else "BAIXO"
                report.append(f"| {metric.name} | {metric.value} | {impact} | {metric.source_line} |")
        else:
            report.append("*Nenhuma métrica de performance específica identificada.*")
        
        report.extend([
            "",
            "## 🕐 Janelas Operacionais",
            ""
        ])
        
        if operational_windows:
            report.append("| Janela | Frequência | Duração Est. | Criticidade |")
            report.append("|--------|------------|--------------|-------------|")
            for window in operational_windows:
                duration = f"{window.estimated_duration}min" if window.estimated_duration else "N/A"
                report.append(f"| {window.name} | {window.frequency} | {duration} | {window.criticality} |")
        else:
            report.append("*Nenhuma janela operacional específica identificada.*")
        
        report.extend([
            "",
            "## 🔗 Dependências Críticas",
            ""
        ])
        
        for dep_type, dep_list in dependencies.items():
            if dep_list:
                dep_type_name = dep_type.replace("_", " ").title()
                report.append(f"### {dep_type_name}")
                for dep in dep_list:
                    report.append(f"- {dep}")
                report.append("")
        
        report.extend([
            "",
            "## 💡 Insights Operacionais",
            ""
        ])
        
        for i, insight in enumerate(insights, 1):
            report.append(f"{i}. {insight}")
        
        report.extend([
            "",
            "## 🎯 Recomendações para Especialistas",
            "",
            "### Para Analistas de Negócio:",
            "- Valide as métricas de volume com dados reais de produção",
            "- Confirme janelas operacionais com equipe de operações",
            "- Documente impacto de indisponibilidade do programa",
            "",
            "### Para Especialistas Técnicos:",
            "- Mapeie todas as dependências antes de mudanças",
            "- Monitore métricas de performance em produção",
            "- Implemente logging adequado para troubleshooting",
            "",
            "### Para Arquitetos:",
            "- Considere padrões de alta disponibilidade se criticidade for HIGH",
            "- Avalie necessidade de balanceamento de carga",
            "- Planeje estratégia de disaster recovery apropriada",
            ""
        ])
        
        return "\n".join(report)
