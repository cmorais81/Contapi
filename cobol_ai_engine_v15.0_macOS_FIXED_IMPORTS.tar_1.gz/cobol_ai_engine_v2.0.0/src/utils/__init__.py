"""Utilitários do COBOL AI Engine v15.0"""

try:
    from .extract_programs import extract_programs_from_file
except ImportError:
    extract_programs_from_file = None

try:
    from .extract_books import extract_books_from_file
except ImportError:
    extract_books_from_file = None

__all__ = [
    'extract_programs_from_file',
    'extract_books_from_file'
]
