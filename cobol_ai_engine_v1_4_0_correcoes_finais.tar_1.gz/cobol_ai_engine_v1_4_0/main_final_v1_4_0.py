#!/usr/bin/env python3
"""
COBOL AI Engine v1.4.0 - Sistema Final com Auditoria Completa
Sistema com renovação automática de token, tratamento robusto de respostas HTTP e auditoria completa.
"""

import os
import sys
import json
import time
import argparse
import logging
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, List

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from providers.luzia_provider_enhanced import LuziaProviderEnhanced
from utils.audit_logger import AuditLogger

def setup_comprehensive_logging(log_level: str = "INFO") -> logging.Logger:
    """Configura sistema de logging abrangente."""
    
    # Criar diretório de logs se não existir
    log_dir = Path("logs")
    log_dir.mkdir(exist_ok=True)
    
    # Nome do arquivo de log com timestamp
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_file = log_dir / f"cobol_ai_engine_final_{timestamp}.log"
    
    # Configurar formatação detalhada
    detailed_formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - [%(filename)s:%(lineno)d] - %(message)s'
    )
    
    simple_formatter = logging.Formatter(
        '%(asctime)s - %(levelname)s - %(message)s'
    )
    
    # Handler para console (formato simples)
    console_handler = logging.StreamHandler()
    console_handler.setLevel(getattr(logging, log_level))
    console_handler.setFormatter(simple_formatter)
    
    # Handler para arquivo (formato detalhado)
    file_handler = logging.FileHandler(log_file, encoding='utf-8')
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(detailed_formatter)
    
    # Configurar logger principal
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    logger.addHandler(console_handler)
    logger.addHandler(file_handler)
    
    # Configurar loggers específicos
    logging.getLogger('urllib3').setLevel(logging.WARNING)
    logging.getLogger('requests').setLevel(logging.WARNING)
    
    logger.info(f"Sistema de logging abrangente inicializado - Arquivo: {log_file}")
    return logger

class EnhancedResponseProcessor:
    """Processador de respostas aprimorado com auditoria."""
    
    def __init__(self, audit_logger: AuditLogger):
        self.logger = logging.getLogger('EnhancedResponseProcessor')
        self.audit_logger = audit_logger
    
    def extract_content(self, response_data: Dict[str, Any]) -> str:
        """Extrai conteúdo da resposta da LuzIA de forma robusta."""
        
        if not isinstance(response_data, dict):
            self.logger.warning("Resposta não é um dicionário")
            return str(response_data)
        
        # Tentar diferentes estruturas de resposta da LuzIA
        content_paths = [
            ['output'],
            ['result'],
            ['content'],
            ['choices', 0, 'message', 'content'],
            ['response', 'content'],
            ['data', 'content'],
            ['message', 'content'],
            ['text'],
            ['answer']
        ]
        
        for path in content_paths:
            try:
                current = response_data
                for key in path:
                    if isinstance(key, int):
                        if isinstance(current, list) and len(current) > key:
                            current = current[key]
                        else:
                            break
                    else:
                        current = current.get(key)
                    
                    if current is None:
                        break
                
                if current and isinstance(current, str) and len(current.strip()) > 0:
                    self.logger.info(f"Conteúdo extraído via path: {' -> '.join(map(str, path))}")
                    return current.strip()
                    
            except (KeyError, IndexError, TypeError, AttributeError) as e:
                self.logger.debug(f"Erro ao tentar path {path}: {e}")
                continue
        
        # Se não encontrou conteúdo estruturado, tentar extrair qualquer texto
        def extract_text_recursive(obj, depth=0):
            if depth > 5:  # Evitar recursão infinita
                return None
            
            if isinstance(obj, str) and len(obj.strip()) > 50:  # Texto significativo
                return obj.strip()
            elif isinstance(obj, dict):
                for value in obj.values():
                    result = extract_text_recursive(value, depth + 1)
                    if result:
                        return result
            elif isinstance(obj, list):
                for item in obj:
                    result = extract_text_recursive(item, depth + 1)
                    if result:
                        return result
            return None
        
        extracted_text = extract_text_recursive(response_data)
        if extracted_text:
            self.logger.info("Conteúdo extraído via busca recursiva")
            return extracted_text
        
        # Último recurso: retornar JSON formatado
        self.logger.warning("Conteúdo não encontrado, retornando JSON formatado")
        return json.dumps(response_data, indent=2, ensure_ascii=False)
    
    def process_response(self, analysis_result: Dict[str, Any], program_name: str, 
                        start_time: float) -> Dict[str, Any]:
        """Processa resultado da análise com auditoria completa."""
        
        processing_time_ms = int((time.time() - start_time) * 1000)
        
        processed = {
            "success": analysis_result.get("success", False),
            "provider": analysis_result.get("provider", "unknown"),
            "model": analysis_result.get("model", "unknown"),
            "status_code": analysis_result.get("status_code"),
            "attempt": analysis_result.get("attempt", 1),
            "timestamp": datetime.now().isoformat(),
            "processing_time_ms": processing_time_ms
        }
        
        if processed["success"]:
            # Extrair conteúdo da resposta
            response_data = analysis_result.get("response", {})
            processed["content"] = self.extract_content(response_data)
            processed["raw_response"] = response_data
            
            # Log de auditoria para sucesso
            self.audit_logger.log_analysis_result(
                program_name, True, processing_time_ms
            )
            
            self.logger.info(f"Resposta processada com sucesso para {program_name}")
        else:
            # Processar erro
            error_msg = analysis_result.get("error", "Unknown error")
            processed["error"] = error_msg
            processed["error_details"] = analysis_result.get("details", {})
            
            # Log de auditoria para erro
            self.audit_logger.log_analysis_result(
                program_name, False, processing_time_ms, 
                {"error": error_msg, "details": processed["error_details"]}
            )
            
            self.logger.error(f"Erro na análise de {program_name}: {error_msg}")
        
        return processed

def parse_cobol_file(file_path: str) -> List[Dict[str, Any]]:
    """Parse do arquivo de fontes COBOL com validação aprimorada."""
    logger = logging.getLogger('COBOLParser')
    programs = []
    
    try:
        # Verificar se arquivo existe e é legível
        if not os.path.exists(file_path):
            logger.error(f"Arquivo não encontrado: {file_path}")
            return []
        
        if not os.access(file_path, os.R_OK):
            logger.error(f"Arquivo não é legível: {file_path}")
            return []
        
        # Tentar diferentes encodings
        encodings = ['utf-8', 'latin-1', 'cp1252', 'iso-8859-1']
        content = None
        
        for encoding in encodings:
            try:
                with open(file_path, 'r', encoding=encoding) as f:
                    content = f.read()
                logger.info(f"Arquivo lido com encoding {encoding}: {len(content)} caracteres")
                break
            except UnicodeDecodeError:
                continue
        
        if content is None:
            logger.error("Não foi possível ler o arquivo com nenhum encoding suportado")
            return []
        
        # Dividir por programas (assumindo separação por PROGRAM-ID)
        program_sections = content.split('PROGRAM-ID.')
        logger.info(f"Encontradas {len(program_sections)} seções")
        
        for i, section in enumerate(program_sections[1:], 1):  # Pular primeira seção vazia
            lines = section.strip().split('\n')
            if lines and len(lines) > 1:  # Pelo menos 2 linhas para ser um programa válido
                # Extrair nome do programa da primeira linha
                program_name = lines[0].strip().rstrip('.')
                
                # Limpar nome do programa (remover caracteres especiais)
                program_name = ''.join(c for c in program_name if c.isalnum() or c in '-_')
                
                if not program_name:
                    logger.warning(f"Nome de programa inválido na seção {i}, pulando...")
                    continue
                
                # Reconstruir código completo
                program_code = f"PROGRAM-ID. {section}"
                
                programs.append({
                    'name': program_name,
                    'code': program_code,
                    'lines': len(lines),
                    'size_bytes': len(program_code.encode('utf-8')),
                    'section_index': i
                })
                
                logger.info(f"Programa {i}: {program_name} ({len(lines)} linhas, {len(program_code)} bytes)")
                
        logger.info(f"Total de programas parseados: {len(programs)}")
        return programs
        
    except Exception as e:
        logger.error(f"Erro inesperado ao parsear arquivo {file_path}: {str(e)}")
        return []

def save_comprehensive_results(program_name: str, processed_result: Dict[str, Any], 
                             output_dir: str, program_index: int, total_programs: int):
    """Salva resultados com estrutura abrangente."""
    logger = logging.getLogger('ResultSaver')
    
    # Criar estrutura de diretórios organizada
    output_path = Path(output_dir)
    output_path.mkdir(exist_ok=True)
    
    # Diretórios organizados
    requests_dir = output_path / 'requests'
    responses_dir = output_path / 'responses'
    reports_dir = output_path / 'reports'
    metadata_dir = output_path / 'metadata'
    
    for dir_path in [requests_dir, responses_dir, reports_dir, metadata_dir]:
        dir_path.mkdir(exist_ok=True)
    
    timestamp = processed_result["timestamp"]
    
    # Salvar metadados detalhados
    metadata_file = metadata_dir / f'{program_name}_metadata.json'
    metadata = {
        'program_name': program_name,
        'program_index': program_index,
        'total_programs': total_programs,
        'timestamp': timestamp,
        'provider': processed_result["provider"],
        'model': processed_result["model"],
        'status_code': processed_result["status_code"],
        'attempt': processed_result["attempt"],
        'processing_time_ms': processed_result["processing_time_ms"],
        'success': processed_result["success"],
        'system_version': 'COBOL AI Engine v1.4.0'
    }
    
    with open(metadata_file, 'w', encoding='utf-8') as f:
        json.dump(metadata, f, indent=2, ensure_ascii=False)
    
    # Salvar requisição (se disponível)
    if 'request_payload' in processed_result:
        request_file = requests_dir / f'{program_name}_request.json'
        with open(request_file, 'w', encoding='utf-8') as f:
            json.dump(processed_result['request_payload'], f, indent=2, ensure_ascii=False)
    
    # Salvar resposta completa
    response_file = responses_dir / f'{program_name}_response.json'
    response_data = {
        'program_name': program_name,
        'timestamp': timestamp,
        'success': processed_result["success"],
        'provider': processed_result["provider"],
        'model': processed_result["model"],
        'status_code': processed_result["status_code"],
        'processing_time_ms': processed_result["processing_time_ms"]
    }
    
    if processed_result["success"]:
        response_data['content'] = processed_result["content"]
        response_data['raw_response'] = processed_result.get("raw_response", {})
    else:
        response_data['error'] = processed_result["error"]
        response_data['error_details'] = processed_result["error_details"]
    
    with open(response_file, 'w', encoding='utf-8') as f:
        json.dump(response_data, f, indent=2, ensure_ascii=False)
    
    # Gerar relatório markdown aprimorado
    report_file = reports_dir / f'{program_name}.md'
    
    if processed_result["success"]:
        status_badge = "✅ SUCESSO"
        status_color = "green"
        content = processed_result["content"]
    else:
        status_badge = "❌ ERRO"
        status_color = "red"
        content = f"""## Erro na Análise

**Tipo de Erro**: {processed_result['error']}

**Detalhes Técnicos**:
```json
{json.dumps(processed_result['error_details'], indent=2, ensure_ascii=False)}
```

**Recomendações**:
1. Verificar conectividade com a LuzIA
2. Validar credenciais de autenticação
3. Verificar formato do programa COBOL
4. Consultar logs detalhados para mais informações"""

    # Calcular estatísticas de progresso
    progress_percentage = (program_index / total_programs) * 100
    
    markdown_content = f"""# Análise do Programa COBOL: {program_name}

<div style="background-color: {status_color}; color: white; padding: 10px; border-radius: 5px; margin-bottom: 20px;">
<strong>{status_badge}</strong> - Programa {program_index}/{total_programs} ({progress_percentage:.1f}%)
</div>

## Informações da Análise

| Campo | Valor |
|-------|-------|
| **Data da Análise** | {datetime.fromisoformat(timestamp).strftime('%d/%m/%Y %H:%M:%S')} |
| **Provedor** | {processed_result['provider']} |
| **Modelo** | {processed_result['model']} |
| **Status HTTP** | {processed_result['status_code']} |
| **Tentativas** | {processed_result['attempt']} |
| **Tempo de Processamento** | {processed_result['processing_time_ms']} ms |

---

{content}

---

## Informações Técnicas e Auditoria

### Arquivos Relacionados
- **Metadados**: `metadata/{program_name}_metadata.json`
- **Resposta Completa**: `responses/{program_name}_response.json`
- **Auditoria**: Consultar diretório `audit/`

### Sistema
- **Versão**: COBOL AI Engine v1.4.0
- **Recursos Habilitados**:
  - ✅ Renovação Automática de Token
  - ✅ Tratamento Robusto de Respostas HTTP (200, 201, 202)
  - ✅ Sistema de Auditoria Completo
  - ✅ Retry Automático em Caso de Token Expirado
  - ✅ Logging Detalhado

### Conectividade LuzIA
- **Auth URL**: `https://login.azure.paas.santanderbr.pre.corp/auth/realms/santander/protocol/openid-connect/token`
- **API URL**: `https://gpt-api-aws.santanderbr.dev.corp/genai_services/v1/pipelines/submit`
- **Modelo Utilizado**: aws-claude-3-5-sonnet
- **Temperatura**: 0.1

---
*Relatório gerado pelo COBOL AI Engine v1.4.0 - Sistema com Auditoria Completa*
"""
    
    with open(report_file, 'w', encoding='utf-8') as f:
        f.write(markdown_content)
    
    logger.info(f"Resultados salvos para {program_name}")

def main():
    """Função principal do sistema aprimorado."""
    parser = argparse.ArgumentParser(
        description='COBOL AI Engine v1.4.0 - Sistema com Auditoria Completa',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Exemplos de uso:
  python main_final_v1_4_0.py fontes.txt
  python main_final_v1_4_0.py fontes.txt -o resultados --log-level DEBUG
  python main_final_v1_4_0.py fontes.txt --check-connectivity
        """
    )
    
    parser.add_argument('fonte', help='Arquivo de fontes COBOL')
    parser.add_argument('-o', '--output', default='output_final_v1_4_0', 
                       help='Diretório de saída (default: output_final_v1_4_0)')
    parser.add_argument('--log-level', choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'], 
                       default='INFO', help='Nível de log (default: INFO)')
    parser.add_argument('--check-connectivity', action='store_true',
                       help='Verificar conectividade com LuzIA antes de iniciar')
    parser.add_argument('--max-programs', type=int, 
                       help='Limitar número máximo de programas a analisar')
    
    args = parser.parse_args()
    
    # Configurar logging abrangente
    logger = setup_comprehensive_logging(args.log_level)
    
    logger.info("=" * 60)
    logger.info("COBOL AI ENGINE v1.4.0 - SISTEMA COM AUDITORIA COMPLETA")
    logger.info("=" * 60)
    logger.info(f"Arquivo de fontes: {args.fonte}")
    logger.info(f"Diretório de saída: {args.output}")
    logger.info(f"Nível de log: {args.log_level}")
    
    # Verificar variáveis de ambiente
    client_id = os.getenv("LUZIA_CLIENT_ID")
    client_secret = os.getenv("LUZIA_CLIENT_SECRET")
    
    if not client_id or not client_secret:
        logger.error("Credenciais LuzIA não configuradas!")
        logger.error("Configure as variáveis de ambiente:")
        logger.error("  export LUZIA_CLIENT_ID='seu_client_id'")
        logger.error("  export LUZIA_CLIENT_SECRET='seu_client_secret'")
        return 1
    
    logger.info("Credenciais LuzIA configuradas ✅")
    
    # Inicializar sistema de auditoria
    logger.info("Inicializando sistema de auditoria...")
    audit_logger = AuditLogger(args.output)
    
    # Inicializar provedor LuzIA
    logger.info("Inicializando provedor LuzIA Enhanced...")
    luzia_provider = LuziaProviderEnhanced()
    
    # Verificar conectividade se solicitado
    if args.check_connectivity:
        logger.info("Verificando conectividade com LuzIA...")
        connectivity = luzia_provider.check_connectivity()
        
        print("\n" + "=" * 50)
        print("TESTE DE CONECTIVIDADE LUZIA")
        print("=" * 50)
        print(json.dumps(connectivity, indent=2, ensure_ascii=False))
        print("=" * 50)
        
        if not connectivity["success"]:
            logger.error("❌ Falha na conectividade com LuzIA")
            return 1
        else:
            logger.info("✅ Conectividade com LuzIA OK")
            if not args.fonte or args.fonte == 'test':
                return 0
    
    # Verificar se arquivo existe
    if not os.path.exists(args.fonte):
        logger.error(f"Arquivo de fontes não encontrado: {args.fonte}")
        return 1
    
    # Parsear programas COBOL
    logger.info("Parseando programas COBOL...")
    programs = parse_cobol_file(args.fonte)
    
    if not programs:
        logger.error("Nenhum programa encontrado no arquivo de fontes")
        return 1
    
    # Aplicar limite se especificado
    if args.max_programs and args.max_programs < len(programs):
        logger.info(f"Limitando análise aos primeiros {args.max_programs} programas")
        programs = programs[:args.max_programs]
    
    logger.info(f"Encontrados {len(programs)} programas para análise")
    
    # Iniciar sessão de auditoria
    session_id = audit_logger.start_session(len(programs))
    logger.info(f"Sessão de auditoria iniciada: {session_id}")
    
    # Inicializar processador de respostas
    response_processor = EnhancedResponseProcessor(audit_logger)
    
    # Analisar cada programa
    success_count = 0
    error_count = 0
    total_processing_time = 0
    
    print(f"\n🚀 Iniciando análise de {len(programs)} programas...")
    print("=" * 60)
    
    for i, program in enumerate(programs, 1):
        program_name = program['name']
        program_code = program['code']
        
        logger.info(f"\n{'='*20} PROGRAMA {i}/{len(programs)}: {program_name} {'='*20}")
        logger.info(f"Tamanho: {program['lines']} linhas, {program['size_bytes']} bytes")
        
        print(f"\n[{i:2d}/{len(programs)}] Analisando {program_name}...")
        
        # Marcar início da análise
        start_time = time.time()
        
        # Executar análise
        analysis_result = luzia_provider.analyze_program(program_name, program_code)
        
        # Processar resultado
        processed_result = response_processor.process_response(
            analysis_result, program_name, start_time
        )
        
        # Salvar resultados
        save_comprehensive_results(
            program_name, processed_result, args.output, i, len(programs)
        )
        
        # Atualizar contadores
        processing_time = processed_result["processing_time_ms"]
        total_processing_time += processing_time
        
        if processed_result["success"]:
            success_count += 1
            print(f"        ✅ Sucesso ({processing_time}ms)")
        else:
            error_count += 1
            print(f"        ❌ Erro: {processed_result['error']} ({processing_time}ms)")
        
        # Mostrar progresso
        progress = (i / len(programs)) * 100
        print(f"        📊 Progresso: {progress:.1f}% ({success_count} sucessos, {error_count} erros)")
    
    # Finalizar sessão de auditoria
    session_summary = audit_logger.end_session()
    
    # Relatório final
    avg_time = total_processing_time / len(programs) if programs else 0
    success_rate = (success_count / len(programs)) * 100 if programs else 0
    
    print("\n" + "=" * 60)
    print("📋 RELATÓRIO FINAL")
    print("=" * 60)
    print(f"Total de programas analisados: {len(programs)}")
    print(f"Sucessos: {success_count} ({success_rate:.1f}%)")
    print(f"Erros: {error_count} ({100-success_rate:.1f}%)")
    print(f"Tempo médio por análise: {avg_time:.0f}ms")
    print(f"Tempo total: {total_processing_time/1000:.1f}s")
    print(f"Sessão de auditoria: {session_id}")
    print("=" * 60)
    
    logger.info(f"ANÁLISE CONCLUÍDA - Taxa de sucesso: {success_rate:.1f}%")
    
    print(f"\n📁 Resultados salvos em: {args.output}/")
    print(f"   📄 Relatórios: reports/")
    print(f"   📤 Requisições: requests/")
    print(f"   📥 Respostas: responses/")
    print(f"   📊 Metadados: metadata/")
    print(f"   🔍 Auditoria: audit/")
    print(f"   📝 Logs: logs/")
    
    return 0 if error_count == 0 else 1

if __name__ == "__main__":
    sys.exit(main())
