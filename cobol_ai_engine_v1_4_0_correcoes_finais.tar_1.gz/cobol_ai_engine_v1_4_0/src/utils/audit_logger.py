#!/usr/bin/env python3
"""
Audit Logger v1.4.0
Sistema de auditoria e logging aprimorado para rastreamento completo de interações com APIs.
"""

import os
import json
import logging
import hashlib
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional, List
from dataclasses import dataclass, asdict

@dataclass
class APIRequest:
    """Estrutura para requisições de API."""
    timestamp: str
    program_name: str
    provider: str
    model: str
    endpoint: str
    method: str
    headers_hash: str  # Hash dos headers para segurança
    payload_size: int
    payload_hash: str  # Hash do payload para integridade
    request_id: str

@dataclass
class APIResponse:
    """Estrutura para respostas de API."""
    timestamp: str
    request_id: str
    status_code: int
    response_size: int
    response_hash: str  # Hash da resposta para integridade
    success: bool
    error_message: Optional[str]
    processing_time_ms: int

@dataclass
class AnalysisSession:
    """Estrutura para sessão de análise."""
    session_id: str
    start_time: str
    end_time: Optional[str]
    total_programs: int
    successful_analyses: int
    failed_analyses: int
    total_requests: int
    total_response_size: int
    average_processing_time: float

class AuditLogger:
    """Sistema de auditoria e logging aprimorado."""
    
    def __init__(self, output_dir: str):
        self.output_dir = Path(output_dir)
        self.audit_dir = self.output_dir / 'audit'
        self.audit_dir.mkdir(parents=True, exist_ok=True)
        
        # Configurar logger específico para auditoria
        self.logger = logging.getLogger('AuditLogger')
        
        # Arquivo de auditoria com timestamp
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.audit_file = self.audit_dir / f'audit_{timestamp}.jsonl'
        
        # Listas para rastreamento
        self.requests: List[APIRequest] = []
        self.responses: List[APIResponse] = []
        self.session_data: Optional[AnalysisSession] = None
        
        self.logger.info(f"Sistema de auditoria inicializado - Arquivo: {self.audit_file}")
    
    def _calculate_hash(self, data: Any) -> str:
        """Calcula hash SHA-256 dos dados."""
        if isinstance(data, dict):
            data_str = json.dumps(data, sort_keys=True, ensure_ascii=False)
        else:
            data_str = str(data)
        
        return hashlib.sha256(data_str.encode('utf-8')).hexdigest()[:16]
    
    def _write_audit_entry(self, entry_type: str, data: Dict[str, Any]):
        """Escreve entrada no arquivo de auditoria."""
        audit_entry = {
            'timestamp': datetime.now().isoformat(),
            'type': entry_type,
            'data': data
        }
        
        with open(self.audit_file, 'a', encoding='utf-8') as f:
            f.write(json.dumps(audit_entry, ensure_ascii=False) + '\n')
    
    def start_session(self, total_programs: int) -> str:
        """Inicia uma sessão de análise."""
        session_id = f"session_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        self.session_data = AnalysisSession(
            session_id=session_id,
            start_time=datetime.now().isoformat(),
            end_time=None,
            total_programs=total_programs,
            successful_analyses=0,
            failed_analyses=0,
            total_requests=0,
            total_response_size=0,
            average_processing_time=0.0
        )
        
        self._write_audit_entry('session_start', asdict(self.session_data))
        self.logger.info(f"Sessão de análise iniciada: {session_id}")
        
        return session_id
    
    def log_request(self, program_name: str, provider: str, model: str, 
                   endpoint: str, method: str, headers: Dict[str, str], 
                   payload: Dict[str, Any]) -> str:
        """Registra uma requisição de API."""
        
        request_id = f"req_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}"
        
        # Criar hash dos headers (removendo dados sensíveis)
        safe_headers = {k: v for k, v in headers.items() 
                       if k.lower() not in ['authorization', 'x-api-key']}
        headers_hash = self._calculate_hash(safe_headers)
        
        # Calcular informações do payload
        payload_str = json.dumps(payload, ensure_ascii=False)
        payload_size = len(payload_str.encode('utf-8'))
        payload_hash = self._calculate_hash(payload)
        
        api_request = APIRequest(
            timestamp=datetime.now().isoformat(),
            program_name=program_name,
            provider=provider,
            model=model,
            endpoint=endpoint,
            method=method,
            headers_hash=headers_hash,
            payload_size=payload_size,
            payload_hash=payload_hash,
            request_id=request_id
        )
        
        self.requests.append(api_request)
        self._write_audit_entry('api_request', asdict(api_request))
        
        # Salvar payload completo em arquivo separado
        payload_file = self.audit_dir / f'{request_id}_payload.json'
        with open(payload_file, 'w', encoding='utf-8') as f:
            json.dump(payload, f, indent=2, ensure_ascii=False)
        
        self.logger.debug(f"Requisição registrada: {request_id}")
        return request_id
    
    def log_response(self, request_id: str, status_code: int, response_data: Any,
                    success: bool, error_message: Optional[str], 
                    processing_time_ms: int):
        """Registra uma resposta de API."""
        
        # Calcular informações da resposta
        response_str = json.dumps(response_data, ensure_ascii=False) if response_data else ""
        response_size = len(response_str.encode('utf-8'))
        response_hash = self._calculate_hash(response_data) if response_data else "empty"
        
        api_response = APIResponse(
            timestamp=datetime.now().isoformat(),
            request_id=request_id,
            status_code=status_code,
            response_size=response_size,
            response_hash=response_hash,
            success=success,
            error_message=error_message,
            processing_time_ms=processing_time_ms
        )
        
        self.responses.append(api_response)
        self._write_audit_entry('api_response', asdict(api_response))
        
        # Salvar resposta completa em arquivo separado
        response_file = self.audit_dir / f'{request_id}_response.json'
        with open(response_file, 'w', encoding='utf-8') as f:
            json.dump({
                'status_code': status_code,
                'success': success,
                'error_message': error_message,
                'processing_time_ms': processing_time_ms,
                'response_data': response_data
            }, f, indent=2, ensure_ascii=False)
        
        # Atualizar estatísticas da sessão
        if self.session_data:
            self.session_data.total_requests += 1
            self.session_data.total_response_size += response_size
            
            if success:
                self.session_data.successful_analyses += 1
            else:
                self.session_data.failed_analyses += 1
        
        self.logger.debug(f"Resposta registrada para: {request_id}")
    
    def log_analysis_result(self, program_name: str, success: bool, 
                          processing_time_ms: int, error_details: Optional[Dict] = None):
        """Registra resultado de uma análise."""
        
        analysis_result = {
            'program_name': program_name,
            'success': success,
            'processing_time_ms': processing_time_ms,
            'error_details': error_details
        }
        
        self._write_audit_entry('analysis_result', analysis_result)
        self.logger.info(f"Resultado da análise registrado: {program_name} - {'SUCESSO' if success else 'ERRO'}")
    
    def end_session(self) -> Dict[str, Any]:
        """Finaliza a sessão de análise e gera relatório."""
        
        if not self.session_data:
            self.logger.warning("Nenhuma sessão ativa para finalizar")
            return {}
        
        self.session_data.end_time = datetime.now().isoformat()
        
        # Calcular estatísticas finais
        if self.responses:
            total_time = sum(r.processing_time_ms for r in self.responses)
            self.session_data.average_processing_time = total_time / len(self.responses)
        
        session_summary = asdict(self.session_data)
        self._write_audit_entry('session_end', session_summary)
        
        # Gerar relatório de auditoria
        self._generate_audit_report()
        
        self.logger.info(f"Sessão finalizada: {self.session_data.session_id}")
        return session_summary
    
    def _generate_audit_report(self):
        """Gera relatório detalhado de auditoria."""
        
        if not self.session_data:
            return
        
        report_file = self.audit_dir / f'audit_report_{self.session_data.session_id}.md'
        
        # Calcular estatísticas
        total_payload_size = sum(r.payload_size for r in self.requests)
        total_response_size = sum(r.response_size for r in self.responses)
        
        success_rate = (self.session_data.successful_analyses / 
                       self.session_data.total_programs * 100) if self.session_data.total_programs > 0 else 0
        
        # Estatísticas por status code
        status_codes = {}
        for response in self.responses:
            status_codes[response.status_code] = status_codes.get(response.status_code, 0) + 1
        
        # Gerar relatório markdown
        report_content = f"""# Relatório de Auditoria - {self.session_data.session_id}

## Resumo da Sessão

- **ID da Sessão**: {self.session_data.session_id}
- **Início**: {self.session_data.start_time}
- **Fim**: {self.session_data.end_time}
- **Duração**: {self._calculate_duration()}

## Estatísticas de Análise

- **Total de Programas**: {self.session_data.total_programs}
- **Análises Bem-sucedidas**: {self.session_data.successful_analyses}
- **Análises com Erro**: {self.session_data.failed_analyses}
- **Taxa de Sucesso**: {success_rate:.1f}%

## Estatísticas de API

- **Total de Requisições**: {len(self.requests)}
- **Total de Respostas**: {len(self.responses)}
- **Tamanho Total de Payloads**: {total_payload_size:,} bytes
- **Tamanho Total de Respostas**: {total_response_size:,} bytes
- **Tempo Médio de Processamento**: {self.session_data.average_processing_time:.0f} ms

## Distribuição de Status Codes

{self._format_status_codes(status_codes)}

## Detalhes das Requisições

{self._format_requests_table()}

## Detalhes das Respostas

{self._format_responses_table()}

## Arquivos de Auditoria

- **Log Principal**: `{self.audit_file.name}`
- **Payloads**: `*_payload.json`
- **Respostas**: `*_response.json`

---
*Relatório gerado em {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}*
"""
        
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write(report_content)
        
        self.logger.info(f"Relatório de auditoria gerado: {report_file}")
    
    def _calculate_duration(self) -> str:
        """Calcula duração da sessão."""
        if not self.session_data or not self.session_data.end_time:
            return "N/A"
        
        start = datetime.fromisoformat(self.session_data.start_time)
        end = datetime.fromisoformat(self.session_data.end_time)
        duration = end - start
        
        return str(duration).split('.')[0]  # Remove microsegundos
    
    def _format_status_codes(self, status_codes: Dict[int, int]) -> str:
        """Formata distribuição de status codes."""
        if not status_codes:
            return "Nenhuma resposta registrada."
        
        lines = []
        for code, count in sorted(status_codes.items()):
            percentage = (count / len(self.responses)) * 100
            lines.append(f"- **{code}**: {count} ({percentage:.1f}%)")
        
        return '\n'.join(lines)
    
    def _format_requests_table(self) -> str:
        """Formata tabela de requisições."""
        if not self.requests:
            return "Nenhuma requisição registrada."
        
        lines = ["| Timestamp | Programa | Provider | Modelo | Tamanho | Hash |",
                "| --- | --- | --- | --- | --- | --- |"]
        
        for req in self.requests[-10:]:  # Últimas 10 requisições
            timestamp = req.timestamp.split('T')[1][:8]  # Apenas hora
            lines.append(f"| {timestamp} | {req.program_name} | {req.provider} | {req.model} | {req.payload_size:,} | {req.payload_hash} |")
        
        if len(self.requests) > 10:
            lines.append(f"| ... | ... | ... | ... | ... | ... |")
            lines.append(f"| **Total**: {len(self.requests)} requisições | | | | | |")
        
        return '\n'.join(lines)
    
    def _format_responses_table(self) -> str:
        """Formata tabela de respostas."""
        if not self.responses:
            return "Nenhuma resposta registrada."
        
        lines = ["| Timestamp | Status | Sucesso | Tamanho | Tempo (ms) | Hash |",
                "| --- | --- | --- | --- | --- | --- |"]
        
        for resp in self.responses[-10:]:  # Últimas 10 respostas
            timestamp = resp.timestamp.split('T')[1][:8]  # Apenas hora
            success_icon = "✅" if resp.success else "❌"
            lines.append(f"| {timestamp} | {resp.status_code} | {success_icon} | {resp.response_size:,} | {resp.processing_time_ms} | {resp.response_hash} |")
        
        if len(self.responses) > 10:
            lines.append(f"| ... | ... | ... | ... | ... | ... |")
            lines.append(f"| **Total**: {len(self.responses)} respostas | | | | | |")
        
        return '\n'.join(lines)

def create_audit_logger(output_dir: str) -> AuditLogger:
    """Cria uma instância do sistema de auditoria."""
    return AuditLogger(output_dir)

if __name__ == "__main__":
    # Teste básico
    audit = create_audit_logger("test_audit")
    session_id = audit.start_session(2)
    
    # Simular requisição
    req_id = audit.log_request(
        "TEST_PROGRAM", "luzia", "claude-3.5", 
        "https://api.test.com/analyze", "POST",
        {"Content-Type": "application/json"},
        {"query": "test query"}
    )
    
    # Simular resposta
    audit.log_response(req_id, 200, {"result": "test"}, True, None, 1500)
    
    # Finalizar sessão
    summary = audit.end_session()
    print(json.dumps(summary, indent=2, ensure_ascii=False))
