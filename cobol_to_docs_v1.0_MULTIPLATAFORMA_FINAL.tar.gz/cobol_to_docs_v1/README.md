# COBOL to Docs v1.0

**Sistema de Análise e Documentação Automatizada de Programas COBOL**

**Autor:** Carlos Morais  
**Versão:** 1.0  
**Data:** Setembro 2025

## Descrição

COBOL to Docs é um sistema completo para análise automatizada de programas COBOL usando Inteligência Artificial. O sistema gera documentação técnica profissional, analisa código, identifica regras de negócio e produz relatórios detalhados.

## Características Principais

- **Análise Automatizada**: Usa IA para analisar programas COBOL
- **Múltiplos Modelos**: Suporte a diferentes modelos de IA (Claude, GPT, LuzIA)
- **Prompts Personalizados**: Geração de prompts específicos para diferentes domínios
- **Relatórios Profissionais**: HTML otimizado para PDF com design corporativo
- **Multi-Modelo**: Análise comparativa entre diferentes modelos
- **Configuração Flexível**: Sistema de configuração YAML completo

## Estrutura do Projeto

```
cobol_to_docs_v1/
├── main.py                 # Script principal
├── generate_prompts.py     # Gerador de prompts personalizados
├── handle_prompt_generation.py  # Suporte para geração de prompts
├── README.md              # Este arquivo
├── src/                   # Código fonte
│   ├── core/             # Componentes centrais
│   ├── providers/        # Provedores de IA
│   ├── generators/       # Geradores de documentação
│   ├── parsers/          # Analisadores de código
│   ├── analyzers/        # Analisadores de IA
│   └── utils/            # Utilitários
├── config/               # Arquivos de configuração
│   ├── config.yaml       # Configuração principal
│   ├── prompts_original.yaml  # Prompts padrão
│   └── prompts_doc_legado_pro.yaml  # Prompts especializados
├── examples/             # Exemplos de uso
│   ├── programa_exemplo.cbl  # Programa COBOL de exemplo
│   ├── fontes.txt        # Lista de arquivos
│   └── requisitos_exemplo.txt  # Exemplo para geração de prompts
├── docs/                 # Documentação completa
├── old/                  # Arquivos de teste e desenvolvimento
└── logs/                 # Logs do sistema
```

## Compatibilidade Multiplataforma

**COBOL to Docs v1.0 funciona em qualquer sistema com Python 3.11+:**

- ✅ **Windows**: PowerShell, CMD, Windows Terminal, Git Bash, WSL
- ✅ **Linux**: Bash, Zsh, Fish, qualquer distribuição
- ✅ **macOS**: Terminal, iTerm2, qualquer shell

## Instalação Automática

### Linux/macOS
```bash
# Extrair e instalar automaticamente
tar -xzf cobol_to_docs_v1.0_FINAL.tar.gz
cd cobol_to_docs_v1
./install.sh
```

### Windows PowerShell
```powershell
# Extrair e instalar automaticamente
tar -xzf cobol_to_docs_v1.0_FINAL.tar.gz
cd cobol_to_docs_v1
.\install.ps1
```

### Windows CMD
```cmd
REM Extrair e instalar automaticamente
tar -xzf cobol_to_docs_v1.0_FINAL.tar.gz
cd cobol_to_docs_v1
install.bat
```

## Instalação Manual

### Pré-requisitos
- **Python 3.11+** (qualquer plataforma)
- **Bibliotecas**: `pip install pyyaml requests beautifulsoup4 markdown`

### Configuração

**Linux/macOS:**
```bash
export LUZIA_CLIENT_ID='seu_client_id'
export LUZIA_CLIENT_SECRET='seu_client_secret'
python3 main.py --status
```

**Windows PowerShell:**
```powershell
$env:LUZIA_CLIENT_ID='seu_client_id'
$env:LUZIA_CLIENT_SECRET='seu_client_secret'
python main.py --status
```

**Windows CMD:**
```cmd
set LUZIA_CLIENT_ID=seu_client_id
set LUZIA_CLIENT_SECRET=seu_secret
python main.py --status
```

## Uso Básico

### Análise Simples

**Linux/macOS:**
```bash
python3 main.py --fontes examples/fontes.txt
```

**Windows:**
```powershell
python main.py --fontes examples/fontes.txt
```

### Análise com PDF

**Linux/macOS:**
```bash
python3 main.py --fontes examples/fontes.txt --pdf
```

**Windows:**
```powershell
python main.py --fontes examples/fontes.txt --pdf
```

### Análise Multi-Modelo

**Linux/macOS:**
```bash
python3 main.py --fontes examples/fontes.txt --models '["aws-claude-3.7","gpt-4"]' --pdf
```

**Windows PowerShell:**
```powershell
python main.py --fontes examples/fontes.txt --models '["aws-claude-3.7","gpt-4"]' --pdf
```

**Windows CMD:**
```cmd
python main.py --fontes examples/fontes.txt --models "[\"aws-claude-3.7\",\"gpt-4\"]" --pdf
```

## Geração de Prompts Personalizados

### A partir de Arquivo
```bash
python3 generate_prompts.py --input examples/requisitos_exemplo.txt --output meus_prompts.yaml
```

### Modo Interativo
```bash
python3 generate_prompts.py --interactive
```

### Usar Prompts Personalizados
```bash
python3 main.py --fontes examples/fontes.txt --prompts-file meus_prompts.yaml --pdf
```

## Argumentos Disponíveis

| Argumento | Descrição |
|-----------|-----------|
| `--fontes` | Arquivo com lista de programas COBOL |
| `--output` | Diretório de saída (padrão: output) |
| `--models` | Modelos a usar (único ou lista JSON) |
| `--pdf` | Gerar HTML otimizado para PDF |
| `--prompts-file` | Arquivo de prompts personalizado |
| `--prompt-set` | Conjunto de prompts (original, doc_legado_pro) |
| `--generate-prompts` | Gerar prompts a partir de arquivo |
| `--generate-prompts-interactive` | Gerar prompts interativamente |
| `--status` | Verificar status dos provedores |
| `--log` | Nível de log (DEBUG, INFO, WARNING, ERROR) |

## Exemplos de Uso

### Workflow Completo
```bash
# 1. Verificar status
python3 main.py --status

# 2. Gerar prompts personalizados
python3 main.py --generate-prompts examples/requisitos_exemplo.txt

# 3. Analisar com prompts personalizados
python3 main.py --fontes examples/fontes.txt --prompts-file requisitos_exemplo_prompts.yaml --pdf

# 4. Análise comparativa
python3 main.py --fontes examples/fontes.txt --models '["aws-claude-3.7","gpt-4"]' --pdf
```

### Diferentes Conjuntos de Prompts
```bash
# Análise técnica tradicional
python3 main.py --fontes examples/fontes.txt --prompt-set original

# Documentação de legado especializada
python3 main.py --fontes examples/fontes.txt --prompt-set doc_legado_pro
```

## Saída Gerada

O sistema gera:

- **Documentação Markdown**: Análise detalhada em formato Markdown
- **Relatórios HTML**: Versões HTML otimizadas para PDF
- **Relatório Comparativo**: Comparação entre modelos (modo multi-modelo)
- **Logs Detalhados**: Logs completos do processamento

### Estrutura de Saída
```
output/
├── programa_exemplo/
│   ├── documentacao.md
│   ├── relatorio.html
│   └── analise_detalhada.md
├── relatorio_comparativo_modelos.md  # (se multi-modelo)
└── logs/
```

## Configuração Avançada

### Arquivo config/config.yaml
```yaml
ai:
  primary_provider: "luzia"
  default_models: ["aws-claude-3.7"]
  
providers:
  luzia:
    base_url: "https://api.luzia.com"
    model: "aws-claude-3.7"
    max_tokens: 200000
```

### Prompts Personalizados
O sistema suporta prompts totalmente personalizados via arquivos YAML gerados automaticamente a partir de texto livre.

## Suporte e Documentação

- **Documentação Completa**: Veja pasta `docs/`
- **Exemplos**: Veja pasta `examples/`
- **Logs**: Verificar pasta `logs/` para diagnóstico

## Autor

**Carlos Morais**  
Sistema desenvolvido para análise automatizada de programas COBOL  
Setembro 2025

## Licença

Sistema proprietário - Todos os direitos reservados

---

Para mais informações, consulte a documentação completa na pasta `docs/`.
