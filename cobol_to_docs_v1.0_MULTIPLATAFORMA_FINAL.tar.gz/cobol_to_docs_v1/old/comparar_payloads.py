#!/usr/bin/env python3
"""
Comparador byte-a-byte entre payloads para identificar diferenças sutis
"""

import json
import requests
from unittest.mock import patch
from src.providers.luzia_provider import LuziaProvider
from src.providers.base_provider import AIRequest

def criar_payload_provider():
    """Criar payload como no nosso provider"""
    
    system_prompt = """
Answer all questions in brazilian portuguese.
Answer code question with the code only, without using the brackets.
DON'T start the answer with the word 'python'.
"""
    
    user_prompt = """Diga apenas 'teste ok'"""
    
    payload = {
        "input": {
            "query": [
                {
                    "role": "system",
                    "content": system_prompt
                },
                {
                    "role": "user",
                    "content": user_prompt
                }
            ]
        },
        "config": {
            "type": "catena.llm.LLMRouter",
            "obj_kwargs": {
                "routing_model": "azure-gpt-4o-mini",
                "temperature": 0.1
            }
        }
    }
    
    return payload

def criar_payload_teste_funcionando():
    """Criar payload como no teste.py que funciona"""
    
    system_prompt = """
Answer all questions in brazilian portuguese.
Answer code question with the code only, without using the brackets.
DON'T start the answer with the word 'python'.
"""
    
    user_prompt = """Diga apenas 'teste ok'"""
    
    payload = {
        "input": {
            "query": [
                {
                    "role": "system",
                    "content": system_prompt
                },
                {
                    "role": "user",
                    "content": user_prompt
                }
            ]
        },
        "config": {
            "type": "catena.llm.LLMRouter",
            "obj_kwargs": {
                "routing_model": "azure-gpt-4o-mini",
                "temperature": 0.1
            }
        }
    }
    
    return payload

def comparar_json_strings(json1, json2, nome1="Provider", nome2="Teste"):
    """Comparar strings JSON byte-a-byte"""
    
    print(f"=== COMPARAÇÃO {nome1} vs {nome2} ===")
    
    print(f"\n1. TAMANHOS:")
    print(f"- {nome1}: {len(json1)} bytes")
    print(f"- {nome2}: {len(json2)} bytes")
    
    print(f"\n2. IGUALDADE:")
    print(f"- Strings iguais: {json1 == json2}")
    
    if json1 != json2:
        print(f"\n3. DIFERENÇAS BYTE-A-BYTE:")
        min_len = min(len(json1), len(json2))
        
        for i in range(min_len):
            if json1[i] != json2[i]:
                print(f"- Posição {i}:")
                print(f"  {nome1}: '{json1[i]}' (ord: {ord(json1[i])})")
                print(f"  {nome2}: '{json2[i]}' (ord: {ord(json2[i])})")
                
                # Mostrar contexto
                start = max(0, i-10)
                end = min(len(json1), i+10)
                print(f"  Contexto {nome1}: '{json1[start:end]}'")
                print(f"  Contexto {nome2}: '{json2[start:end]}'")
                break
        
        if len(json1) != len(json2):
            print(f"- Tamanhos diferentes:")
            if len(json1) > len(json2):
                print(f"  {nome1} tem {len(json1) - len(json2)} bytes extras: '{json1[len(json2):]}'")
            else:
                print(f"  {nome2} tem {len(json2) - len(json1)} bytes extras: '{json2[len(json1):]}'")
    
    print(f"\n4. CARACTERES ESPECIAIS:")
    
    def analisar_caracteres(text, nome):
        non_ascii = [c for c in text if ord(c) > 127]
        if non_ascii:
            print(f"- {nome} tem caracteres não-ASCII: {set(non_ascii)}")
        else:
            print(f"- {nome}: apenas ASCII")
        
        # Verificar quebras de linha
        crlf = text.count('\r\n')
        lf = text.count('\n') - crlf
        cr = text.count('\r') - crlf
        
        print(f"- {nome} quebras: CRLF={crlf}, LF={lf}, CR={cr}")
    
    analisar_caracteres(json1, nome1)
    analisar_caracteres(json2, nome2)

def testar_serializacao():
    """Testar diferentes métodos de serialização"""
    
    print("=== TESTE DE SERIALIZAÇÃO ===")
    
    payload = criar_payload_provider()
    
    # Método 1: json.dumps padrão
    json1 = json.dumps(payload)
    
    # Método 2: json.dumps com ensure_ascii=False
    json2 = json.dumps(payload, ensure_ascii=False)
    
    # Método 3: json.dumps com separators
    json3 = json.dumps(payload, separators=(',', ':'))
    
    # Método 4: json.dumps compacto
    json4 = json.dumps(payload, ensure_ascii=False, separators=(',', ':'))
    
    print(f"Método 1 (padrão): {len(json1)} bytes")
    print(f"Método 2 (ensure_ascii=False): {len(json2)} bytes")
    print(f"Método 3 (separators): {len(json3)} bytes")
    print(f"Método 4 (compacto): {len(json4)} bytes")
    
    # Comparar com método que funciona
    comparar_json_strings(json1, json2, "Padrão", "ensure_ascii=False")
    comparar_json_strings(json1, json3, "Padrão", "Separators")

def interceptar_requisicao_real():
    """Interceptar requisição real do provider"""
    
    captured_payload = None
    
    def mock_post(*args, **kwargs):
        nonlocal captured_payload
        
        if 'data' in kwargs:
            captured_payload = kwargs['data']
        elif 'json' in kwargs:
            captured_payload = json.dumps(kwargs['json'])
        
        # Simular resposta de erro
        class MockResponse:
            status_code = 400
            def json(self):
                return {"error": "Input should be a valid list"}
            def text(self):
                return '{"error": "Input should be a valid list"}'
        
        return MockResponse()
    
    # Testar provider real
    provider = LuziaProvider({
        'base_url': 'https://gut-api-aws.santanderbr.dev.corp/genai_services/v1/pipelines/submit',
        'client_id': 'test',
        'client_secret': 'test'
    })
    
    request = AIRequest(
        prompt="Diga apenas 'teste ok'",
        program_name="teste.cbl"
    )
    
    with patch('requests.post', side_effect=mock_post):
        provider._token = "fake_token"
        provider._token_expires_at = 9999999999
        
        try:
            provider.analyze(request)
        except:
            pass
    
    if captured_payload:
        print("\n=== PAYLOAD CAPTURADO DO PROVIDER ===")
        print(f"Tipo: {type(captured_payload)}")
        print(f"Tamanho: {len(captured_payload)}")
        
        # Comparar com teste funcionando
        payload_teste = criar_payload_teste_funcionando()
        json_teste = json.dumps(payload_teste)
        
        comparar_json_strings(captured_payload, json_teste, "Provider Real", "Teste Funcionando")

if __name__ == "__main__":
    print("=== ANÁLISE COMPLETA DE PAYLOADS ===")
    
    testar_serializacao()
    interceptar_requisicao_real()
    
    print("\n=== CONCLUSÃO ===")
    print("Verifique se há diferenças sutis na serialização JSON.")
