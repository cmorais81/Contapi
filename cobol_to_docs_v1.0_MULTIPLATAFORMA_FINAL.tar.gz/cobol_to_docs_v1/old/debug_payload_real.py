#!/usr/bin/env python3
"""
Debug avançado para identificar exatamente o que está sendo enviado para a API LuzIA
"""

import json
import requests
import os
from src.providers.luzia_provider import LuziaProvider
from src.providers.base_provider import AIRequest

def debug_payload_construction():
    """Debug da construção do payload"""
    
    print("=== DEBUG AVANÇADO - CONSTRUÇÃO DO PAYLOAD ===")
    
    # Simular dados como no sistema real
    system_prompt = """
Answer all questions in brazilian portuguese.
Answer code question with the code only, without using the brackets.
DON'T start the answer with the word 'python'.
"""
    
    user_prompt = "Analise este programa COBOL: IDENTIFICATION DIVISION. PROGRAM-ID. TESTE."
    
    # Construir payload exatamente como no provider
    payload = {
        "input": {
            "query": [
                {
                    "role": "system",
                    "content": system_prompt
                },
                {
                    "role": "user", 
                    "content": user_prompt
                }
            ]
        },
        "config": {
            "type": "catena.llm.LLMRouter",
            "obj_kwargs": {
                "routing_model": "azure-gpt-4o-mini",
                "temperature": 0.1
            }
        }
    }
    
    print("1. PAYLOAD CONSTRUÍDO:")
    print(json.dumps(payload, indent=2, ensure_ascii=False))
    
    print("\n2. VALIDAÇÃO DA ESTRUTURA:")
    print(f"- Tipo de 'input': {type(payload['input'])}")
    print(f"- Tipo de 'input.query': {type(payload['input']['query'])}")
    print(f"- Tamanho de 'input.query': {len(payload['input']['query'])}")
    print(f"- Primeiro item da query: {type(payload['input']['query'][0])}")
    
    print("\n3. SERIALIZAÇÃO JSON:")
    json_string = json.dumps(payload)
    print(f"- Tamanho do JSON: {len(json_string)} chars")
    print(f"- Primeiros 200 chars: {json_string[:200]}...")
    
    print("\n4. DESERIALIZAÇÃO (TESTE):")
    try:
        parsed_back = json.loads(json_string)
        print("- Deserialização: SUCESSO")
        print(f"- Estrutura mantida: {type(parsed_back['input']['query'])}")
    except Exception as e:
        print(f"- Deserialização: ERRO - {e}")
    
    print("\n5. COMPARAÇÃO COM TESTE.PY:")
    # Payload do teste.py que funciona
    teste_py_payload = {
        "input": {
            "query": [
                {
                    "role": "system",
                    "content": system_prompt
                },
                {
                    "role": "user",
                    "content": user_prompt
                }
            ]
        },
        "config": {
            "type": "catena.llm.LLMRouter",
            "obj_kwargs": {
                "routing_model": "azure-gpt-4o-mini",
                "temperature": 0.1
            }
        }
    }
    
    print("- Payloads são idênticos:", payload == teste_py_payload)
    
    return payload

def debug_request_simulation():
    """Simular requisição para debug"""
    
    print("\n=== DEBUG SIMULAÇÃO DE REQUISIÇÃO ===")
    
    payload = debug_payload_construction()
    
    # Headers como no provider
    headers = {
        "X-santander-client-id": "test_client_id",
        "Authorization": "Bearer test_token",
        "Content-Type": "application/json"
    }
    
    print("\n6. HEADERS:")
    for key, value in headers.items():
        print(f"- {key}: {value}")
    
    print("\n7. SIMULAÇÃO DE REQUESTS.POST:")
    
    # Método atual (data=json.dumps)
    print("- Método atual: data=json.dumps(payload)")
    data_method = json.dumps(payload)
    print(f"  - Tipo de data: {type(data_method)}")
    print(f"  - Tamanho: {len(data_method)}")
    
    # Método alternativo (json=payload)
    print("- Método alternativo: json=payload")
    print(f"  - Tipo de payload: {type(payload)}")
    
    print("\n8. ANÁLISE DO ERRO:")
    print("- Erro reportado: 'Input should be a valid list'")
    print("- Campo 'input' no payload:", type(payload['input']))
    print("- Campo 'input.query' no payload:", type(payload['input']['query']))
    print("- Conteúdo de 'input.query':")
    for i, item in enumerate(payload['input']['query']):
        print(f"  [{i}] {type(item)}: {list(item.keys())}")

def debug_provider_real():
    """Debug do provider real"""
    
    print("\n=== DEBUG PROVIDER REAL ===")
    
    try:
        # Inicializar provider
        provider = LuziaProvider({
            'base_url': 'https://gut-api-aws.santanderbr.dev.corp/genai_services/v1/pipelines/submit',
            'client_id': 'test',
            'client_secret': 'test'
        })
        
        print("9. PROVIDER INICIALIZADO:")
        print(f"- Classe: {provider.__class__.__name__}")
        print(f"- Base URL: {provider.base_url}")
        
        # Verificar método analyze
        if hasattr(provider, 'analyze'):
            print("- Método analyze: DISPONÍVEL")
            
            # Simular request
            request = AIRequest(
                prompt="Teste de análise COBOL",
                model="azure-gpt-4o-mini",
                max_tokens=1000
            )
            
            print("10. REQUEST SIMULADO:")
            print(f"- Prompt: {request.prompt[:50]}...")
            print(f"- Modelo: {request.model}")
            
        else:
            print("- Método analyze: NÃO ENCONTRADO")
            
    except Exception as e:
        print(f"Erro no provider: {e}")

if __name__ == "__main__":
    debug_payload_construction()
    debug_request_simulation()
    debug_provider_real()
    
    print("\n=== CONCLUSÃO ===")
    print("Execute este debug e compare com o payload do seu teste.py que funciona.")
    print("Identifique exatamente onde está a diferença.")
