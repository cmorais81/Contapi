#!/usr/bin/env python3
"""
Gerador de Prompts Adaptativos
Implementa geração de prompts adaptativos baseados na complexidade e domínio do código.
"""

import os
import re
import json
import logging
from typing import Dict, List, Any, Optional, Tuple

class AdaptivePromptGenerator:
    """
    Gerador de prompts adaptativos que se ajustam à complexidade e domínio do código.
    """
    
    def __init__(self, config):
        """
        Inicializa o gerador de prompts adaptativos.
        
        Args:
            config: Configuração do sistema
        """
        self.logger = logging.getLogger(__name__)
        self.config = config
        
        # Carregar templates de prompts
        self.prompt_templates = self._load_prompt_templates()
        
        # Definir domínios conhecidos
        self.domains = {
            'CADOC': {
                'keywords': ['CADOC', 'DOCUMENTO', 'CLASSIFICACAO', 'CATEGORIA', 'WORKFLOW'],
                'weight': 1.5
            },
            'FINANCEIRO': {
                'keywords': ['JUROS', 'SALDO', 'VALOR', 'TAXA', 'CALCULO', 'MONTANTE'],
                'weight': 1.3
            },
            'CONTABIL': {
                'keywords': ['CONTABIL', 'LANCAMENTO', 'DEBITO', 'CREDITO', 'BALANCO'],
                'weight': 1.2
            },
            'CLIENTE': {
                'keywords': ['CLIENTE', 'CADASTRO', 'PESSOA', 'FISICA', 'JURIDICA', 'CPF', 'CNPJ'],
                'weight': 1.1
            },
            'OPERACIONAL': {
                'keywords': ['OPERACAO', 'TRANSACAO', 'PROCESSO', 'ROTINA', 'BATCH'],
                'weight': 1.0
            }
        }
    
    def _load_prompt_templates(self) -> Dict[str, Dict[str, str]]:
        """
        Carrega templates de prompts.
        
        Returns:
            Dicionário com templates de prompts
        """
        templates = {
            'basic': {
                'default': "Analise o seguinte programa COBOL e forneça uma descrição geral de suas funcionalidades principais.",
                'CADOC': "Analise o seguinte programa COBOL relacionado a sistemas CADOC e forneça uma descrição detalhada de suas funcionalidades principais, focando em processamento documental.",
                'FINANCEIRO': "Analise o seguinte programa COBOL relacionado a sistemas financeiros e forneça uma descrição detalhada de suas funcionalidades principais, focando em cálculos e regras financeiras."
            },
            'detailed': {
                'default': """Analise o seguinte programa COBOL e forneça:
1. Descrição geral do programa
2. Funcionalidades principais
3. Estrutura de dados
4. Regras de negócio implementadas
5. Integrações e interfaces
6. Pontos de atenção e possíveis melhorias""",
                'CADOC': """Analise o seguinte programa COBOL relacionado a sistemas CADOC e forneça:
1. Descrição geral do programa
2. Funcionalidades principais de processamento documental
3. Estrutura de dados e layouts de documentos
4. Regras de negócio específicas para classificação e processamento de documentos
5. Integrações com outros sistemas documentais
6. Fluxos de aprovação e estados de documentos
7. Pontos de atenção e possíveis melhorias"""
            },
            'advanced': {
                'default': """Realize uma análise técnica aprofundada do seguinte programa COBOL:
1. Descrição detalhada do programa e seu propósito
2. Funcionalidades principais com exemplos de uso
3. Estrutura de dados completa com descrição de cada campo
4. Regras de negócio implementadas com valores específicos
5. Algoritmos e cálculos utilizados com exemplos numéricos
6. Integrações e interfaces com outros sistemas
7. Fluxo de execução detalhado
8. Tratamento de erros e exceções
9. Pontos de atenção, riscos técnicos e possíveis melhorias
10. Recomendações para modernização""",
                'CADOC': """Realize uma análise técnica aprofundada do seguinte programa COBOL relacionado a sistemas CADOC:
1. Descrição detalhada do programa e seu propósito no contexto de processamento documental
2. Funcionalidades principais de classificação, indexação e processamento de documentos
3. Estrutura de dados completa com descrição de cada campo de documento
4. Regras de negócio específicas para validação, classificação e roteamento de documentos
5. Algoritmos de processamento documental com exemplos específicos
6. Integrações com sistemas de gestão documental e repositórios
7. Fluxo de processamento documental detalhado
8. Tratamento de exceções documentais e erros de processamento
9. Pontos de atenção, riscos técnicos e possíveis melhorias
10. Recomendações para modernização da gestão documental"""
            }
        }
        
        return templates
    
    def analyze_complexity(self, parsed_code: Dict[str, Any]) -> Tuple[float, Dict[str, Any]]:
        """
        Analisa a complexidade do código COBOL.
        
        Args:
            parsed_code: Código COBOL analisado
            
        Returns:
            Tuple com nível de complexidade (0-10) e métricas detalhadas
        """
        metrics = {}
        
        # Contar divisões
        divisions = parsed_code.get('divisions', {})
        metrics['division_count'] = len(divisions)
        
        # Contar seções
        sections = 0
        for division in divisions.values():
            sections += len(division.get('sections', {}))
        metrics['section_count'] = sections
        
        # Contar parágrafos
        paragraphs = 0
        for division in divisions.values():
            for section in division.get('sections', {}).values():
                paragraphs += len(section.get('paragraphs', {}))
        metrics['paragraph_count'] = paragraphs
        
        # Contar variáveis
        data_division = divisions.get('DATA DIVISION', {})
        working_storage = data_division.get('sections', {}).get('WORKING-STORAGE SECTION', {})
        variables = len(working_storage.get('variables', []))
        metrics['variable_count'] = variables
        
        # Contar arquivos
        file_section = data_division.get('sections', {}).get('FILE SECTION', {})
        files = len(file_section.get('files', []))
        metrics['file_count'] = files
        
        # Calcular complexidade
        complexity = 0
        complexity += min(metrics['division_count'] * 0.5, 2)
        complexity += min(metrics['section_count'] * 0.3, 2)
        complexity += min(metrics['paragraph_count'] * 0.05, 2)
        complexity += min(metrics['variable_count'] * 0.01, 2)
        complexity += min(metrics['file_count'] * 0.2, 2)
        
        # Normalizar para escala 0-10
        complexity = min(max(complexity, 0), 10)
        
        return complexity, metrics
    
    def identify_domain(self, cobol_code: str) -> Tuple[str, float]:
        """
        Identifica o domínio principal do código COBOL.
        
        Args:
            cobol_code: Código COBOL
            
        Returns:
            Tuple com domínio identificado e pontuação de confiança
        """
        # Converter para maiúsculas para comparação
        code_upper = cobol_code.upper()
        
        # Calcular pontuação para cada domínio
        domain_scores = {}
        for domain, info in self.domains.items():
            score = 0
            for keyword in info['keywords']:
                occurrences = code_upper.count(keyword)
                score += occurrences * info['weight']
            domain_scores[domain] = score
        
        # Encontrar domínio com maior pontuação
        if not domain_scores:
            return 'default', 0.0
        
        best_domain = max(domain_scores.items(), key=lambda x: x[1])
        
        # Se a pontuação for muito baixa, usar domínio padrão
        if best_domain[1] < 3:
            return 'default', best_domain[1] / 10
        
        return best_domain[0], min(best_domain[1] / 10, 1.0)
    
    def generate_adaptive_prompt(self, parsed_code: Dict[str, Any], cobol_code: str, 
                               prompt_type: str = 'detailed') -> Tuple[str, Dict[str, Any]]:
        """
        Gera um prompt adaptativo baseado na complexidade e domínio do código.
        
        Args:
            parsed_code: Código COBOL analisado
            cobol_code: Código COBOL original
            prompt_type: Tipo de prompt ('basic', 'detailed', 'advanced')
            
        Returns:
            Tuple com prompt gerado e metadados
        """
        # Analisar complexidade
        complexity, complexity_metrics = self.analyze_complexity(parsed_code)
        
        # Identificar domínio
        domain, domain_confidence = self.identify_domain(cobol_code)
        
        # Selecionar template base
        if prompt_type not in self.prompt_templates:
            prompt_type = 'detailed'
        
        templates = self.prompt_templates[prompt_type]
        
        # Usar template específico do domínio se disponível e com confiança alta
        if domain in templates and domain_confidence > 0.5:
            base_template = templates[domain]
        else:
            base_template = templates['default']
        
        # Ajustar template baseado na complexidade
        if complexity < 3:
            complexity_note = "Este programa parece ter baixa complexidade. "
        elif complexity < 7:
            complexity_note = "Este programa tem complexidade moderada. "
        else:
            complexity_note = "Este programa tem alta complexidade. "
        
        # Construir prompt final
        prompt = f"{complexity_note}{base_template}\n\n"
        
        # Adicionar informações específicas baseadas no domínio
        if domain == 'CADOC':
            prompt += "\nFoque especialmente em aspectos de processamento documental, classificação, indexação e fluxos de aprovação.\n"
        elif domain == 'FINANCEIRO':
            prompt += "\nFoque especialmente em cálculos financeiros, regras de negócio com valores específicos e validações monetárias.\n"
        
        # Adicionar código COBOL
        prompt += f"\n```cobol\n{cobol_code}\n```"
        
        # Metadados
        metadata = {
            'complexity': complexity,
            'complexity_metrics': complexity_metrics,
            'domain': domain,
            'domain_confidence': domain_confidence,
            'prompt_type': prompt_type
        }
        
        return prompt, metadata


# Função auxiliar para uso direto
def generate_adaptive_prompt(parsed_code: Dict[str, Any], cobol_code: str, 
                           config: Dict[str, Any], prompt_type: str = 'detailed') -> Tuple[str, Dict[str, Any]]:
    """
    Gera um prompt adaptativo baseado na complexidade e domínio do código.
    
    Args:
        parsed_code: Código COBOL analisado
        cobol_code: Código COBOL original
        config: Configuração do sistema
        prompt_type: Tipo de prompt ('basic', 'detailed', 'advanced')
        
    Returns:
        Tuple com prompt gerado e metadados
    """
    generator = AdaptivePromptGenerator(config)
    return generator.generate_adaptive_prompt(parsed_code, cobol_code, prompt_type)


if __name__ == "__main__":
    # Teste simples
    import sys
    
    if len(sys.argv) > 1:
        cobol_file = sys.argv[1]
        try:
            with open(cobol_file, 'r', encoding='utf-8') as f:
                cobol_code = f.read()
            
            from src.parsers.cobol_parser import COBOLParser
            parser = COBOLParser()
            parsed_code = parser.parse(cobol_code)
            
            config = {}
            generator = AdaptivePromptGenerator(config)
            prompt, metadata = generator.generate_adaptive_prompt(parsed_code, cobol_code)
            
            print(f"Complexidade: {metadata['complexity']:.2f}/10")
            print(f"Domínio: {metadata['domain']} (confiança: {metadata['domain_confidence']:.2f})")
            print("\nPrompt gerado:")
            print("=" * 80)
            print(prompt[:500] + "..." if len(prompt) > 500 else prompt)
            print("=" * 80)
            
        except Exception as e:
            print(f"Erro: {e}")
    else:
        print("Uso: python adaptive_prompt_generator.py arquivo.cbl")
