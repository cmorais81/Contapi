#!/usr/bin/env python3
"""
Analisador de Códigos Técnicos
Implementa análise detalhada de códigos técnicos específicos em programas COBOL,
como tipos de informação adicional (tipo:14) e códigos de rotina (R100, R200).
"""

import re
import logging
from typing import Dict, List, Any, Optional, Set, Tuple

class TechnicalCodeAnalyzer:
    """
    Analisador especializado em códigos técnicos encontrados em programas COBOL.
    Identifica e documenta códigos como tipos de informação e rotinas.
    """
    
    def __init__(self):
        """Inicializa o analisador de códigos técnicos."""
        self.logger = logging.getLogger(__name__)
        
        # Padrões para identificar códigos técnicos
        self.type_code_pattern = r'(?:tipo|type)[:\s-]+(\d+)'
        self.routine_code_pattern = r'(?:R|r)(\d{3})(?:-[A-Za-z0-9-]+)?'
        
        # Dicionário de tipos de informação conhecidos
        self.known_info_types = {
            '01': 'Código de operação básico',
            '02': 'Identificação de cliente',
            '03': 'Dados de conta',
            '04': 'Valor monetário',
            '05': 'Data de processamento',
            '06': 'Código de agência',
            '07': 'Número de documento',
            '10': 'Status de processamento',
            '11': 'Código de erro',
            '12': 'Tipo de transação',
            '14': 'Operações com benefício compulsório',
            '15': 'Dados de auditoria',
            '16': 'Informações fiscais',
            '17': 'Dados de segurança',
            '18': 'Referência externa',
            '19': 'Código de autorização',
            '24': 'Dados complementares'
        }
        
        # Dicionário de códigos de rotina conhecidos
        self.known_routines = {
            # Rotinas de inicialização (R1xx)
            'R100': 'Inicialização do programa',
            'R110': 'Abertura de arquivos',
            'R120': 'Leitura de parâmetros',
            'R130': 'Validação de ambiente',
            'R150': 'Inicialização de variáveis',
            'R190': 'Finalização de inicialização',
            
            # Rotinas de processamento principal (R2xx)
            'R200': 'Processamento principal',
            'R201': 'Tratamento de registros iguais',
            'R210': 'Leitura de registros',
            'R220': 'Validação de registros',
            'R230': 'Processamento de registros',
            'R240': 'Atualização de contadores',
            'R250': 'Geração de saída',
            'R290': 'Finalização de processamento',
            
            # Rotinas de tratamento de erros (R3xx)
            'R300': 'Tratamento de erros',
            'R310': 'Erro de arquivo',
            'R320': 'Erro de validação',
            'R330': 'Erro de processamento',
            'R340': 'Erro de sistema',
            'R350': 'Recuperação de erro',
            'R390': 'Finalização com erro',
            
            # Rotinas de finalização (R9xx)
            'R900': 'Finalização do programa',
            'R910': 'Fechamento de arquivos',
            'R920': 'Geração de relatórios',
            'R930': 'Atualização de status',
            'R940': 'Limpeza de recursos',
            'R990': 'Término de execução'
        }
    
    def analyze_info_types(self, content: str) -> Dict[str, str]:
        """
        Analisa tipos de informação mencionados no conteúdo.
        
        Args:
            content: Conteúdo a ser analisado
            
        Returns:
            Dicionário com tipos de informação encontrados e suas descrições
        """
        found_types = {}
        
        # Buscar todos os tipos mencionados
        matches = re.finditer(self.type_code_pattern, content, re.IGNORECASE)
        for match in matches:
            type_code = match.group(1)
            if type_code in self.known_info_types:
                found_types[type_code] = self.known_info_types[type_code]
            else:
                found_types[type_code] = "Tipo de informação não documentado"
        
        return found_types
    
    def analyze_routine_codes(self, content: str) -> Dict[str, str]:
        """
        Analisa códigos de rotina mencionados no conteúdo.
        
        Args:
            content: Conteúdo a ser analisado
            
        Returns:
            Dicionário com códigos de rotina encontrados e suas descrições
        """
        found_routines = {}
        
        # Buscar todos os códigos de rotina mencionados
        matches = re.finditer(self.routine_code_pattern, content)
        for match in matches:
            routine_code = f"R{match.group(1)}"
            if routine_code in self.known_routines:
                found_routines[routine_code] = self.known_routines[routine_code]
            else:
                # Tentar inferir o tipo de rotina pelo primeiro dígito
                first_digit = routine_code[1]
                if first_digit == '1':
                    found_routines[routine_code] = "Rotina de inicialização não documentada"
                elif first_digit == '2':
                    found_routines[routine_code] = "Rotina de processamento principal não documentada"
                elif first_digit == '3':
                    found_routines[routine_code] = "Rotina de tratamento de erro não documentada"
                elif first_digit == '9':
                    found_routines[routine_code] = "Rotina de finalização não documentada"
                else:
                    found_routines[routine_code] = "Rotina não documentada"
        
        return found_routines
    
    def generate_technical_codes_documentation(self, content: str) -> str:
        """
        Gera documentação detalhada para códigos técnicos encontrados.
        
        Args:
            content: Conteúdo a ser analisado
            
        Returns:
            Documentação detalhada dos códigos técnicos
        """
        info_types = self.analyze_info_types(content)
        routine_codes = self.analyze_routine_codes(content)
        
        documentation = ""
        
        # Documentar tipos de informação
        if info_types:
            documentation += "\n## Tipos de Informação Adicional\n\n"
            documentation += "| Código | Descrição | Utilização |\n"
            documentation += "|--------|-----------|------------|\n"
            
            for type_code, description in sorted(info_types.items()):
                # Buscar contexto de utilização
                context = self._find_context(content, f"tipo:{type_code}", f"tipo {type_code}")
                documentation += f"| {type_code} | {description} | {context} |\n"
        
        # Documentar códigos de rotina
        if routine_codes:
            documentation += "\n## Códigos de Rotina\n\n"
            documentation += "| Código | Descrição | Função |\n"
            documentation += "|--------|-----------|--------|\n"
            
            for routine_code, description in sorted(routine_codes.items()):
                # Buscar contexto de utilização
                context = self._find_context(content, routine_code)
                documentation += f"| {routine_code} | {description} | {context} |\n"
        
        return documentation
    
    def _find_context(self, content: str, *search_terms) -> str:
        """
        Busca contexto de utilização de um código técnico.
        
        Args:
            content: Conteúdo a ser analisado
            search_terms: Termos a serem buscados
            
        Returns:
            Contexto de utilização encontrado
        """
        for term in search_terms:
            # Buscar linha que contém o termo
            pattern = f".*{re.escape(term)}.*"
            match = re.search(pattern, content, re.IGNORECASE)
            if match:
                context = match.group(0).strip()
                # Limitar tamanho e remover marcações Markdown
                context = re.sub(r'[#*_`]', '', context)
                if len(context) > 100:
                    context = context[:97] + "..."
                return context
        
        return "Não especificado"


# Função auxiliar para uso direto
def enhance_documentation_with_technical_codes(content: str) -> str:
    """
    Melhora a documentação adicionando explicações detalhadas de códigos técnicos.
    
    Args:
        content: Conteúdo da documentação
        
    Returns:
        Documentação aprimorada com explicações de códigos técnicos
    """
    analyzer = TechnicalCodeAnalyzer()
    technical_docs = analyzer.generate_technical_codes_documentation(content)
    
    # Verificar se há documentação técnica para adicionar
    if technical_docs.strip():
        # Verificar se já existe uma seção de códigos técnicos
        if "## Códigos Técnicos" in content:
            # Substituir a seção existente
            pattern = r"## Códigos Técnicos.*?(?=##|$)"
            content = re.sub(pattern, f"## Códigos Técnicos\n\n{technical_docs}\n\n", content, flags=re.DOTALL)
        else:
            # Adicionar nova seção antes da conclusão ou no final
            if "## Conclusão" in content:
                content = content.replace("## Conclusão", f"{technical_docs}\n\n## Conclusão")
            else:
                content += f"\n\n{technical_docs}\n"
    
    return content


if __name__ == "__main__":
    # Teste simples
    import sys
    
    if len(sys.argv) > 1:
        input_file = sys.argv[1]
        try:
            with open(input_file, 'r', encoding='utf-8') as f:
                content = f.read()
            
            enhanced_content = enhance_documentation_with_technical_codes(content)
            
            output_file = input_file.replace('.md', '_enhanced.md')
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(enhanced_content)
            
            print(f"Documentação aprimorada salva em: {output_file}")
            
        except Exception as e:
            print(f"Erro: {e}")
    else:
        print("Uso: python technical_code_analyzer.py arquivo.md")
