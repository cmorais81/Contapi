#!/usr/bin/env python3
"""
Ferramenta de Extração de Regras de Negócio
Extrai regras de negócio de programas COBOL.
"""

import os
import sys
import json
import argparse
import logging
from typing import Dict, List, Any, Optional

# Adicionar diretório pai ao path para importar módulos do projeto
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.parsers.cobol_parser import COBOLParser
from src.analyzers.deep_business_analyzer import DeepBusinessAnalyzer
from src.core.config import ConfigManager

def extract_business_rules(cobol_file: str, config_file: str, output_file: Optional[str] = None) -> List[Dict[str, Any]]:
    """
    Extrai regras de negócio de um programa COBOL.
    
    Args:
        cobol_file: Caminho para o arquivo COBOL
        config_file: Caminho para o arquivo de configuração
        output_file: Caminho para o arquivo JSON de saída (opcional)
        
    Returns:
        Lista de regras de negócio extraídas
    """
    try:
        # Ler código COBOL
        with open(cobol_file, 'r', encoding='utf-8') as f:
            cobol_code = f.read()
        
        # Carregar configuração
        config_manager = ConfigManager(config_file)
        config = config_manager.get_config()
        
        # Analisar código COBOL
        parser = COBOLParser()
        parsed_code = parser.parse(cobol_code)
        
        # Criar analisador de negócios
        analyzer = DeepBusinessAnalyzer(config)
        
        # Extrair regras de negócio
        business_rules = analyzer.extract_business_rules(parsed_code, cobol_code)
        
        # Salvar em arquivo se especificado
        if output_file:
            with open(output_file, 'w', encoding='utf-8') as f:
                json.dump(business_rules, f, indent=2)
            print(f"Regras de negócio salvas em: {output_file}")
        
        return business_rules
        
    except Exception as e:
        print(f"Erro ao extrair regras de negócio: {e}")
        return []


if __name__ == "__main__":
    # Configuração de logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Argumentos de linha de comando
    parser = argparse.ArgumentParser(description='Extrair regras de negócio de programa COBOL')
    parser.add_argument('--input', required=True, help='Arquivo COBOL de entrada')
    parser.add_argument('--config', default='config/config.yaml', help='Arquivo de configuração')
    parser.add_argument('--output', default=None, help='Arquivo JSON de saída')
    
    args = parser.parse_args()
    
    # Determinar arquivo de saída se não especificado
    output_file = args.output
    if not output_file:
        input_base = os.path.basename(args.input).split('.')[0]
        output_file = f"{input_base}_business_rules.json"
    
    # Extrair regras de negócio
    rules = extract_business_rules(args.input, args.config, output_file)
    
    if rules:
        print(f"Extração concluída com sucesso! {len(rules)} regras de negócio encontradas.")
    else:
        print(f"Erro na extração ou nenhuma regra de negócio encontrada.")
        sys.exit(1)
