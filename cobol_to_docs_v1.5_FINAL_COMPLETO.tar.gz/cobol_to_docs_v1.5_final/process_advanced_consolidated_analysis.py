#!/usr/bin/env python3
"""
Processamento de Análise Avançada Consolidada
Implementa análise avançada consolidada de programas COBOL com extração de regras de negócio,
valores específicos, e consolidação de resultados de múltiplos modelos.
"""

import os
import sys
import json
import logging
import datetime
from typing import Dict, List, Any, Optional, Tuple

from src.parsers.cobol_parser import COBOLParser
from src.analyzers.deep_business_analyzer import DeepBusinessAnalyzer
from src.analyzers.professional_analyzer import ProfessionalAnalyzer
from src.analyzers.copybook_analyzer import CopybookAnalyzer
from src.analyzers.interface_analyzer import InterfaceAnalyzer
from src.analyzers.copybook_strategy import CopybookStrategyManager, CopybookStrategy
from src.generators.documentation_generator import DocumentationGenerator
from src.providers.enhanced_provider_manager import EnhancedProviderManager
from src.providers.base_provider import AIRequest, AIResponse
from src.rag.rag_integration import RAGIntegration
from src.rag.cobol_rag_system import CobolRAGSystem
from src.utils.cost_calculator import CostCalculator
from src.utils.technical_style_filter import TechnicalStyleFilter
from src.utils.essential_knowledge_filter import EssentialKnowledgeFilter
from src.utils.technical_code_integration import integrate_technical_code_analysis

logger = logging.getLogger(__name__)

def process_advanced_consolidated_analysis(args, config, output_dir):
    """
    Processa análise avançada consolidada de programas COBOL.
    
    Args:
        args: Argumentos da linha de comando
        config: Configuração do sistema
        output_dir: Diretório de saída
        
    Returns:
        Diretório de saída
    """
    try:
        # Criar diretório de saída
        os.makedirs(output_dir, exist_ok=True)
        
        # Inicializar calculadora de custos
        cost_calculator = CostCalculator()
        
        # Inicializar gerenciador de provedores
        provider_manager = EnhancedProviderManager(config)
        
        # Inicializar sistema RAG se não estiver desativado
        rag_system = None
        if not args.no_rag:
            rag_system = CobolRAGSystem(config)
            rag_integration = RAGIntegration(rag_system)
        
        # Inicializar filtros de estilo profissional
        technical_style_filter = TechnicalStyleFilter()
        essential_knowledge_filter = EssentialKnowledgeFilter()
        
        # Inicializar estratégia de copybooks
        copybook_strategy = CopybookStrategyManager(CopybookStrategy.VERIFIED_ONLY)
        
        # Inicializar analisadores especializados
        professional_analyzer = ProfessionalAnalyzer()
        copybook_analyzer = CopybookAnalyzer()
        interface_analyzer = InterfaceAnalyzer()
        
        # Determinar arquivos COBOL a serem processados
        cobol_files = []
        if os.path.isdir(args.fontes):
            for root, _, files in os.walk(args.fontes):
                for file in files:
                    if file.lower().endswith(('.cbl', '.cob', '.cobol')):
                        cobol_files.append(os.path.join(root, file))
        else:
            cobol_files = [args.fontes]
        
        # Processar cada arquivo COBOL
        for cobol_file in cobol_files:
            try:
                # Extrair nome do programa
                program_name = os.path.basename(cobol_file).split('.')[0]
                logger.info(f"Processando análise avançada consolidada para: {program_name}")
                
                # Ler código COBOL
                with open(cobol_file, 'r', encoding='utf-8') as f:
                    cobol_code = f.read()
                
                # Analisar código COBOL
                parser = COBOLParser()
                parsed_code = parser.parse(cobol_code)
                
                # Analisar copybooks
                copybook_refs = copybook_analyzer.analyze_copybooks(cobol_code)
                
                # Filtrar copybooks conforme estratégia
                filtered_copybook_refs = copybook_strategy.filter_copybook_references(
                    [ref.to_dict() for ref in copybook_refs]
                )
                
                # Analisar interfaces
                interfaces = interface_analyzer.analyze_interfaces(cobol_code)
                
                # Processar com cada modelo
                models = args.models.split(',')
                model_results = {}
                
                for model in models:
                    # Criar diretório para o modelo
                    model_dir = os.path.join(output_dir, f"advanced_analysis_{model}")
                    os.makedirs(model_dir, exist_ok=True)
                    
                    # Diretórios para requisições e respostas
                    ai_requests_dir = os.path.join(model_dir, "ai_requests")
                    ai_responses_dir = os.path.join(model_dir, "ai_responses")
                    os.makedirs(ai_requests_dir, exist_ok=True)
                    os.makedirs(ai_responses_dir, exist_ok=True)
                    
                    # Criar analisador de negócios
                    analyzer = DeepBusinessAnalyzer(config)
                    
                    # Preparar prompt detalhado
                    prompt = analyzer.prepare_detailed_prompt(parsed_code)
                    
                    # Enriquecer prompt com RAG se disponível
                    if rag_system:
                        prompt = rag_integration.enrich_prompt(prompt, cobol_code)
                    
                    # Criar requisição AI
                    request = AIRequest(
                        model=model,
                        prompt=prompt,
                        max_tokens=4000,
                        temperature=0.1
                    )
                    
                    # Salvar requisição
                    request_file = os.path.join(ai_requests_dir, f"{program_name}_ai_request.json")
                    with open(request_file, 'w', encoding='utf-8') as f:
                        json.dump(request.to_dict(), f, indent=2)
                    
                    # Enviar requisição ao provedor
                    logger.info(f"Enviando requisição avançada para modelo: {model}")
                    response = provider_manager.analyze_with_model(request)
                    
                    # Registrar custo
                    cost_calculator.add_request(model, request.prompt, response.content)
                    
                    # Salvar resposta
                    response_file = os.path.join(ai_responses_dir, f"{program_name}_ai_response.json")
                    with open(response_file, 'w', encoding='utf-8') as f:
                        json.dump(response.to_dict(), f, indent=2)
                    
                    # Aplicar filtros de estilo profissional
                    analysis_content = response.content
                    
                    # 1. Aplicar filtro de conhecimento essencial
                    analysis_content = essential_knowledge_filter.filter_knowledge_section(analysis_content)
                    
                    # 2. Realizar análise profissional
                    prof_result = professional_analyzer.analyze_program(
                        program_name, 
                        cobol_code, 
                        analysis_content
                    )
                    analysis_content = prof_result['analysis']
                    
                    # 3. Aplicar filtro de estilo técnico
                    analysis_content = technical_style_filter.apply_filter(analysis_content)
                    
                    # 4. Adicionar nota sobre estratégia de copybooks
                    copybook_note = copybook_strategy.get_copybook_documentation_note()
                    if "## Copybooks" not in analysis_content:
                        analysis_content += f"\n\n## Copybooks\n\n{copybook_note}\n"
                    else:
                        analysis_content = analysis_content.replace("## Copybooks", f"## Copybooks\n\n{copybook_note}")
                    
                    # 5. Adicionar documentação detalhada de códigos técnicos
                    analysis_content = integrate_technical_code_analysis(analysis_content, cobol_code)
                    
                    # Salvar análise de qualidade
                    quality_file = os.path.join(model_dir, f"{program_name}_quality_validation.json")
                    with open(quality_file, 'w', encoding='utf-8') as f:
                        json.dump(prof_result['quality_validation'], f, indent=2)
                    
                    # Gerar documentação final
                    doc_file = os.path.join(model_dir, f"{program_name}_analise_funcional.md")
                    doc_generator = DocumentationGenerator()
                    doc_generator.generate_markdown(program_name, analysis_content, doc_file)
                    
                    # Gerar PDF se solicitado
                    if hasattr(args, 'pdf') and args.pdf:
                        try:
                            pdf_file = os.path.join(model_dir, f"{program_name}_analise_funcional.pdf")
                            os.system(f"manus-md-to-pdf {doc_file} {pdf_file}")
                            logger.info(f"PDF gerado: {pdf_file}")
                        except Exception as e:
                            logger.error(f"Erro ao gerar PDF: {e}")
                    
                    # Armazenar resultado para consolidação
                    model_results[model] = {
                        'content': analysis_content,
                        'quality': prof_result['quality_validation']
                    }
                    
                    logger.info(f"Documentação avançada gerada: {doc_file}")
                
                # Consolidar resultados de todos os modelos
                consolidated_dir = os.path.join(output_dir, "consolidated_analysis")
                os.makedirs(consolidated_dir, exist_ok=True)
                
                # Gerar análise consolidada
                consolidated_content = _consolidate_analyses(model_results, program_name)
                
                # Gerar documentação consolidada
                consolidated_file = os.path.join(consolidated_dir, f"{program_name}_analise_consolidada.md")
                doc_generator = DocumentationGenerator()
                doc_generator.generate_markdown(program_name, consolidated_content, consolidated_file)
                
                # Gerar PDF consolidado se solicitado
                if hasattr(args, 'pdf') and args.pdf:
                    try:
                        pdf_file = os.path.join(consolidated_dir, f"{program_name}_analise_consolidada.pdf")
                        os.system(f"manus-md-to-pdf {consolidated_file} {pdf_file}")
                        logger.info(f"PDF consolidado gerado: {pdf_file}")
                    except Exception as e:
                        logger.error(f"Erro ao gerar PDF consolidado: {e}")
                
                logger.info(f"Análise consolidada gerada: {consolidated_file}")
                
            except Exception as e:
                logger.error(f"Erro ao processar análise avançada para {cobol_file}: {e}")
        
        # Gerar relatório de custos
        cost_report = cost_calculator.generate_report()
        cost_report_file = os.path.join(output_dir, "relatorio_custos_avancado.txt")
        with open(cost_report_file, 'w', encoding='utf-8') as f:
            f.write(cost_report)
        
        logger.info(f"Análise avançada consolidada concluída. Resultados em: {output_dir}")
        return output_dir
        
    except Exception as e:
        logger.error(f"Erro no processamento de análise avançada consolidada: {e}")
        return None


def _consolidate_analyses(model_results, program_name):
    """
    Consolida análises de múltiplos modelos.
    
    Args:
        model_results: Resultados de cada modelo
        program_name: Nome do programa
        
    Returns:
        Conteúdo consolidado
    """
    consolidated = f"# Análise Consolidada: {program_name}\n\n"
    consolidated += f"Data: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
    consolidated += f"Esta análise consolida os resultados de {len(model_results)} modelos diferentes.\n\n"
    
    # Extrair seções comuns
    sections = {}
    for model, result in model_results.items():
        content = result['content']
        
        # Extrair seções usando expressões regulares
        section_pattern = r'##\s+([^\n]+)([^#]*?)(?=##|$)'
        matches = re.finditer(section_pattern, content, re.DOTALL)
        
        for match in matches:
            section_title = match.group(1).strip()
            section_content = match.group(2).strip()
            
            if section_title not in sections:
                sections[section_title] = []
            
            sections[section_title].append({
                'model': model,
                'content': section_content
            })
    
    # Consolidar cada seção
    for section_title, section_contents in sections.items():
        consolidated += f"## {section_title}\n\n"
        
        # Se apenas um modelo tem esta seção, usar diretamente
        if len(section_contents) == 1:
            consolidated += f"{section_contents[0]['content']}\n\n"
        else:
            # Consolidar conteúdo de múltiplos modelos
            consolidated += f"Esta seção foi analisada por {len(section_contents)} modelos diferentes.\n\n"
            
            for content in section_contents:
                consolidated += f"### Análise do modelo {content['model']}\n\n"
                consolidated += f"{content['content']}\n\n"
    
    return consolidated


if __name__ == "__main__":
    # Teste simples
    import argparse
    import re
    from src.core.config import ConfigManager
    
    # Configuração de logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Argumentos de linha de comando
    parser = argparse.ArgumentParser(description='Análise avançada consolidada de programas COBOL')
    parser.add_argument('--fontes', required=True, help='Arquivo ou diretório com programas COBOL')
    parser.add_argument('--output', default=None, help='Diretório de saída para os resultados')
    parser.add_argument('--config', default='config/config.yaml', help='Arquivo de configuração')
    parser.add_argument('--models', default='enhanced_mock,basic', help='Modelos LLM a serem utilizados (separados por vírgula)')
    parser.add_argument('--no-rag', action='store_true', help='Desativar sistema RAG')
    parser.add_argument('--pdf', action='store_true', help='Gerar PDF da análise')
    
    args = parser.parse_args()
    
    # Carregar configuração
    config_manager = ConfigManager(args.config)
    config = config_manager.get_config()
    
    # Determinar diretório de saída
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    output_dir = args.output or f"analise_avancada_{timestamp}"
    
    # Processar análise avançada consolidada
    result_dir = process_advanced_consolidated_analysis(args, config, output_dir)
    
    if result_dir:
        print(f"\nAnálise avançada consolidada concluída com sucesso!")
        print(f"Resultados disponíveis em: {result_dir}")
    else:
        print("\nErro na análise avançada consolidada. Verifique os logs para mais detalhes.")
        sys.exit(1)
