# COBOL to Docs v1.0

**Sistema de Análise e Documentação Automatizada de Programas COBOL usando IA**

**Autor:** Carlos Morais  
**Versão:** 1.0.0

[![PyPI version](https://badge.fury.io/py/cobol-to-docs.svg)](https://badge.fury.io/py/cobol-to-docs)
[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/downloads/)
[![License: Proprietary](https://img.shields.io/badge/License-Proprietary-red.svg)](LICENSE)

## Descrição

COBOL to Docs é um sistema completo para análise automatizada de programas COBOL usando Inteligência Artificial. Desenvolvido por Carlos Morais, o sistema gera documentação técnica profissional, analisa código legado e produz relatórios detalhados.

## Instalação

### Via PyPI (Recomendado)

```bash
pip install cobol-to-docs
```

### Inicializar Configuração (Novos Usuários)

```bash
# Criar arquivos de configuração no diretório atual
cobol-init

# Ou especificar diretório
cobol-init --dir meu_projeto_cobol
```

### Verificar Instalação

```bash
cobol-to-docs --status
```

## Uso Rápido

### Para Novos Usuários

```bash
# 1. Instalar
pip install cobol-to-docs

# 2. Inicializar configuração
cobol-init

# 3. Testar com exemplo
cobol-to-docs --config cobol_to_docs_config/config.yaml --fontes cobol_to_docs_config/examples/fontes.txt --pdf
```

### Análise Básica (Usuários Experientes)

```bash
# Criar arquivo de fontes
echo "meu_programa.cbl" > fontes.txt

# Analisar programa (usa configuração padrão)
cobol-to-docs --fontes fontes.txt --pdf
```

### Gerar Prompts Personalizados

```bash
# Modo interativo
cobol-generate-prompts --interactive

# A partir de arquivo
cobol-generate-prompts --input requisitos.txt --output meus_prompts.yaml
```

### Análise Multi-Modelo

```bash
cobol-to-docs --fontes fontes.txt --models '["aws-claude-3.7","gpt-4"]' --pdf
```

## Funcionalidades

- **🤖 Análise com IA**: Usa modelos avançados (Claude, GPT, LuzIA)
- **📝 Documentação Automática**: Gera Markdown e HTML profissional
- **🎯 Prompts Personalizados**: Cria prompts específicos para diferentes domínios
- **📊 Análise Multi-Modelo**: Compara resultados entre diferentes IAs
- **🖥️ Multiplataforma**: Windows, Linux, macOS
- **⚡ CLI Integrado**: Interface unificada para todas as operações

## Comandos Disponíveis

### Inicialização: `cobol-init`

```bash
# Criar configuração no diretório atual
cobol-init

# Criar em diretório específico
cobol-init --dir meu_projeto

# Sobrescrever configuração existente
cobol-init --force
```

### CLI Principal: `cobol-to-docs`

```bash
# Análise básica
cobol-to-docs --fontes programa.cbl

# Com PDF otimizado
cobol-to-docs --fontes programa.cbl --pdf

# Multi-modelo
cobol-to-docs --fontes programa.cbl --models '["aws-claude-3.7","gpt-4"]'

# Prompts personalizados
cobol-to-docs --fontes programa.cbl --prompts-file custom.yaml

# Status do sistema
cobol-to-docs --status
```

### Gerador de Prompts: `cobol-generate-prompts`

```bash
# Modo interativo
cobol-generate-prompts --interactive

# A partir de arquivo
cobol-generate-prompts --input requisitos.txt --output prompts.yaml

# Validar prompts
cobol-generate-prompts --validate prompts.yaml
```

## Configuração

### Credenciais LuzIA (Opcional)

```bash
# Linux/macOS
export LUZIA_CLIENT_ID='seu_client_id'
export LUZIA_CLIENT_SECRET='seu_client_secret'

# Windows PowerShell
$env:LUZIA_CLIENT_ID='seu_client_id'
$env:LUZIA_CLIENT_SECRET='seu_client_secret'
```

## Exemplos

### Workflow Completo para Novos Usuários

```bash
# 1. Instalar e inicializar
pip install cobol-to-docs
cobol-init

# 2. Verificar status
cobol-to-docs --config cobol_to_docs_config/config.yaml --status

# 3. Gerar prompts específicos para sistema bancário
cobol-generate-prompts --input cobol_to_docs_config/requisitos_exemplo.txt --output requisitos_bancarios_prompts.yaml

# 4. Analisar programa com prompts personalizados
cobol-to-docs --config cobol_to_docs_config/config.yaml --fontes sistema_bancario.cbl --prompts-file requisitos_bancarios_prompts.yaml --pdf

# 5. Análise comparativa multi-modelo
cobol-to-docs --config cobol_to_docs_config/config.yaml --fontes sistema_bancario.cbl --models '["aws-claude-3.7","enhanced_mock"]' --pdf
```

### Uso Programático

```python
import cobol_to_docs

# Configurar sistema
config_manager = cobol_to_docs.ConfigManager('config.yaml')
parser = cobol_to_docs.COBOLParser()
analyzer = cobol_to_docs.EnhancedCOBOLAnalyzer()

# Analisar programa
with open('programa.cbl', 'r') as f:
    codigo = f.read()

parsed = parser.parse_program(codigo, 'programa.cbl')
resultado = analyzer.analyze_program(parsed, 'aws-claude-3.7')
```

## Compatibilidade

### Sistemas Operacionais
- ✅ **Linux**: Ubuntu, CentOS, Debian, Fedora, etc.
- ✅ **Windows**: 10, 11, Server 2019+, WSL
- ✅ **macOS**: 10.15+

### Terminais
- ✅ **Windows**: PowerShell, CMD, Windows Terminal, Git Bash
- ✅ **Linux**: Bash, Zsh, Fish, Dash
- ✅ **macOS**: Terminal, iTerm2

### Python
- **Versão mínima**: Python 3.11+
- **Dependências**: Instaladas automaticamente via pip

## Estrutura de Saída

```
output/
├── programa_exemplo/
│   ├── documentacao.md          # Documentação principal
│   ├── relatorio.html          # Relatório HTML (otimizado para PDF)
│   └── analise_detalhada.md    # Análise técnica
├── relatorio_comparativo_modelos.md  # (se multi-modelo)
└── logs/                       # Logs de processamento
```

## Documentação Completa

- **Guia de Uso**: [docs/GUIA_COMPLETO_USO.md](docs/GUIA_COMPLETO_USO.md)
- **Documentação Técnica**: [docs/DOCUMENTACAO_TECNICA.md](docs/DOCUMENTACAO_TECNICA.md)
- **Compatibilidade**: [docs/COMPATIBILIDADE_MULTIPLATAFORMA.md](docs/COMPATIBILIDADE_MULTIPLATAFORMA.md)

## Migração

### Usuários da Versão Manual

Se você já usa a versão manual (tar.gz), pode continuar usando normalmente ou migrar para PyPI:

```bash
# Continuar usando versão manual
python3 main.py --fontes programa.cbl

# Ou instalar via PyPI
pip install cobol-to-docs
cobol-to-docs --fontes programa.cbl
```

**Ambas as formas são 100% compatíveis!**

## Desenvolvimento

### Instalação para Desenvolvimento

```bash
git clone https://github.com/carlosmorais/cobol-to-docs
cd cobol-to-docs
pip install -e .
```

### Executar Testes

```bash
pip install -e ".[dev]"
pytest tests/
```

## Licença

Sistema proprietário - Todos os direitos reservados  
**Autor:** Carlos Morais

## Suporte

- **Issues**: [GitHub Issues](https://github.com/carlosmorais/cobol-to-docs/issues)
- **Documentação**: [GitHub Wiki](https://github.com/carlosmorais/cobol-to-docs/wiki)
- **Email**: carlos.morais@example.com

## Changelog

### v1.0.0 (2025-09-23)
- 🎉 Lançamento inicial
- ✨ Análise automatizada de COBOL com IA
- ✨ Gerador de prompts personalizados
- ✨ Suporte multi-modelo
- ✨ Relatórios HTML/PDF profissionais
- ✨ CLI integrado e multiplataforma
- ✨ Compatibilidade total com versão manual

---

**Desenvolvido por Carlos Morais - Sistema completo para documentação automatizada de COBOL**
