# Início Rápido - COBOL AI Engine v1.4.0

## Instalação em 5 Minutos

### 1. Extrair o Pacote
```bash
tar -xzf cobol_ai_engine_v1_4_0_completo.tar.gz
cd cobol_ai_engine_v1_4_0
```

### 2. Executar Instalação Automática
```bash
chmod +x install.sh
./install.sh
```

### 3. Configurar Credenciais
```bash
# Copiar arquivo de exemplo
cp config_exemplo.env .env

# Editar com suas credenciais
nano .env
# ou
vim .env
```

Configure no arquivo `.env`:
```bash
LUZIA_CLIENT_ID=seu_client_id_aqui
LUZIA_CLIENT_SECRET=seu_client_secret_aqui
```

### 4. Carregar Configurações
```bash
# Linux/macOS
source .env

# Windows (PowerShell)
Get-Content .env | ForEach-Object { 
    $name, $value = $_.split('=', 2)
    Set-Item -Path "env:$name" -Value $value
}
```

### 5. Teste Rápido
```bash
chmod +x quick_test.sh
./quick_test.sh
```

## Uso Básico

### Testar Conectividade
```bash
python3 luzia_provider_standalone.py
```

### Analisar Programas COBOL
```bash
# Usar arquivo de exemplo
python3 main_final_v1_4_0.py examples/fontes.txt

# Usar seu arquivo
python3 main_final_v1_4_0.py meus_programas.txt -o meus_resultados
```

### Verificar Resultados
```bash
# Ver relatórios
ls output/reports/

# Ver auditoria
cat output/audit/audit_report_*.md
```

## Estrutura de Arquivos

```
cobol_ai_engine_v1_4_0/
├── install.sh                     # Instalação automática
├── quick_test.sh                  # Teste rápido
├── main_final_v1_4_0.py          # Sistema principal
├── luzia_provider_standalone.py   # Teste de conectividade
├── test_enhanced_system.py        # Testes completos
├── requirements_minimal.txt       # Dependências mínimas
├── config_exemplo.env            # Configuração de exemplo
├── examples/
│   └── fontes.txt                # Programas COBOL de exemplo
├── src/
│   ├── providers/
│   │   └── luzia_provider_enhanced.py
│   └── utils/
│       └── audit_logger.py
└── docs/
    ├── README_v1_4_0.md
    ├── GUIA_INSTALACAO_v1_4_0.md
    └── CORRECOES_IMPLEMENTADAS_v1_4_0.md
```

## Comandos Úteis

### Análise com Opções
```bash
# Com verificação de conectividade
python3 main_final_v1_4_0.py fontes.txt --check-connectivity

# Com log detalhado
python3 main_final_v1_4_0.py fontes.txt --log-level DEBUG

# Limitar número de programas
python3 main_final_v1_4_0.py fontes.txt --max-programs 5
```

### Monitoramento
```bash
# Ver logs em tempo real
tail -f logs/cobol_ai_engine_final_*.log

# Verificar status das análises
grep "SUCCESS\|ERROR" output/metadata/*.json
```

## Solução Rápida de Problemas

### Erro de Credenciais
```bash
# Verificar se estão definidas
echo $LUZIA_CLIENT_ID
echo $LUZIA_CLIENT_SECRET

# Redefinir se necessário
export LUZIA_CLIENT_ID="seu_client_id"
export LUZIA_CLIENT_SECRET="seu_client_secret"
```

### Erro de Dependências
```bash
# Instalar dependências mínimas
pip3 install -r requirements_minimal.txt

# Ou instalar manualmente
pip3 install requests urllib3 python-dateutil
```

### Erro de Conectividade
```bash
# Testar conectividade básica
python3 luzia_provider_standalone.py

# Verificar rede
ping google.com
```

## Próximos Passos

1. **Leia a documentação completa**: `README_v1_4_0.md`
2. **Configure para produção**: `GUIA_INSTALACAO_v1_4_0.md`
3. **Entenda as correções**: `CORRECOES_IMPLEMENTADAS_v1_4_0.md`

## Suporte

- **Logs detalhados**: `logs/cobol_ai_engine_final_*.log`
- **Auditoria**: `output/audit/audit_report_*.md`
- **Testes**: `python3 test_enhanced_system.py`

---

**Tempo estimado de configuração**: 5-10 minutos  
**Pré-requisitos**: Python 3.8+, credenciais LuzIA  
**Status**: Pronto para produção
