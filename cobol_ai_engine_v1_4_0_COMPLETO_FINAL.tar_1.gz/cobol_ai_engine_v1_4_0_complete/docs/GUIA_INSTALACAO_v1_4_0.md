# Guia de Instalação - COBOL AI Engine v1.4.0

## Visão Geral

O COBOL AI Engine v1.4.0 é um sistema aprimorado para análise de programas COBOL utilizando inteligência artificial através da API LuzIA. Esta versão inclui correções críticas para autenticação, tratamento de respostas HTTP e sistema de auditoria completo.

## Pré-requisitos

### Sistema Operacional
- Linux (Ubuntu 18.04+ recomendado)
- Windows 10+ (com WSL2 recomendado)
- macOS 10.15+

### Software Necessário
- Python 3.8 ou superior
- pip (gerenciador de pacotes Python)
- Git (para clonagem do repositório)

### Credenciais LuzIA
- Client ID da LuzIA
- Client Secret da LuzIA
- Acesso à rede corporativa Santander (se aplicável)

## Instalação

### 1. Preparação do Ambiente

```bash
# Criar diretório para o projeto
mkdir cobol-ai-engine
cd cobol-ai-engine

# Criar ambiente virtual Python (recomendado)
python3 -m venv venv
source venv/bin/activate  # Linux/macOS
# ou
venv\Scripts\activate     # Windows
```

### 2. Instalação de Dependências

```bash
# Instalar dependências Python
pip install requests urllib3 python-dateutil

# Verificar instalação
python -c "import requests; print('Dependências instaladas com sucesso')"
```

### 3. Configuração de Credenciais

#### Opção A: Variáveis de Ambiente (Recomendado)

```bash
# Linux/macOS
export LUZIA_CLIENT_ID="seu_client_id_aqui"
export LUZIA_CLIENT_SECRET="seu_client_secret_aqui"

# Windows
set LUZIA_CLIENT_ID=seu_client_id_aqui
set LUZIA_CLIENT_SECRET=seu_client_secret_aqui
```

#### Opção B: Arquivo .env

```bash
# Criar arquivo .env na raiz do projeto
cat > .env << EOF
LUZIA_CLIENT_ID=seu_client_id_aqui
LUZIA_CLIENT_SECRET=seu_client_secret_aqui
EOF
```

### 4. Estrutura de Arquivos

Organize os arquivos do sistema conforme a estrutura abaixo:

```
cobol-ai-engine/
├── main_final_v1_4_0.py           # Sistema principal
├── luzia_provider_standalone.py   # Provedor LuzIA standalone
├── test_enhanced_system.py        # Testes do sistema
├── src/
│   ├── providers/
│   │   └── luzia_provider_enhanced.py
│   └── utils/
│       └── audit_logger.py
├── examples/
│   └── fontes.txt                 # Arquivo de exemplo
├── logs/                          # Diretório de logs
├── output/                        # Diretório de saída
└── .env                          # Credenciais (opcional)
```

## Verificação da Instalação

### 1. Teste de Conectividade

```bash
# Testar conectividade com LuzIA
python luzia_provider_standalone.py
```

**Saída Esperada (com credenciais):**
```
============================================================
TESTE DO SISTEMA LUZIA STANDALONE v1.4.0
============================================================
Credenciais configuradas: True
1. Testando conectividade...
   Resultado: True
2. Testando análise de programa...
   Sucesso: True
   Tempo: 1500ms
   Status Code: 200
3. Testando tratamento de status HTTP...
   Status 200: ✅
   Status 201: ✅
   Status 202: ✅
   Status 401: ❌
   Status 500: ❌
============================================================
```

### 2. Teste Completo do Sistema

```bash
# Executar testes abrangentes
python test_enhanced_system.py
```

### 3. Verificação com Arquivo de Exemplo

```bash
# Criar arquivo de exemplo
cat > examples/fontes.txt << 'EOF'
PROGRAM-ID. EXEMPLO-TESTE.
IDENTIFICATION DIVISION.
PROGRAM-ID. EXEMPLO-TESTE.
DATA DIVISION.
WORKING-STORAGE SECTION.
01 WS-CONTADOR PIC 9(3) VALUE 0.
PROCEDURE DIVISION.
MAIN-PARA.
    DISPLAY 'SISTEMA FUNCIONANDO'.
    STOP RUN.
EOF

# Testar análise
python main_final_v1_4_0.py examples/fontes.txt --check-connectivity
```

## Configuração Avançada

### 1. Configuração de Logging

```bash
# Executar com diferentes níveis de log
python main_final_v1_4_0.py fontes.txt --log-level DEBUG    # Máximo detalhe
python main_final_v1_4_0.py fontes.txt --log-level INFO     # Padrão
python main_final_v1_4_0.py fontes.txt --log-level WARNING  # Apenas avisos
```

### 2. Configuração de Saída

```bash
# Especificar diretório de saída personalizado
python main_final_v1_4_0.py fontes.txt -o meus_resultados

# Limitar número de programas (para testes)
python main_final_v1_4_0.py fontes.txt --max-programs 5
```

### 3. Configuração de Rede (Ambiente Corporativo)

Se estiver em ambiente corporativo com proxy:

```bash
# Configurar proxy (se necessário)
export HTTP_PROXY=http://proxy.empresa.com:8080
export HTTPS_PROXY=http://proxy.empresa.com:8080

# Ou desabilitar verificação SSL (não recomendado para produção)
export PYTHONHTTPSVERIFY=0
```

## Uso do Sistema

### 1. Análise Básica

```bash
# Analisar arquivo de fontes COBOL
python main_final_v1_4_0.py meus_programas.txt
```

### 2. Análise com Verificação Prévia

```bash
# Verificar conectividade antes de iniciar
python main_final_v1_4_0.py meus_programas.txt --check-connectivity
```

### 3. Análise com Configurações Personalizadas

```bash
# Análise completa com configurações personalizadas
python main_final_v1_4_0.py meus_programas.txt \
    -o resultados_detalhados \
    --log-level DEBUG \
    --max-programs 10
```

## Estrutura de Resultados

Após a execução, os resultados são organizados da seguinte forma:

```
resultados/
├── reports/                    # Relatórios em Markdown
│   ├── PROGRAMA1.md
│   └── PROGRAMA2.md
├── requests/                   # Metadados das requisições
│   ├── PROGRAMA1_request.json
│   └── PROGRAMA2_request.json
├── responses/                  # Respostas completas
│   ├── PROGRAMA1_response.json
│   └── PROGRAMA2_response.json
├── metadata/                   # Metadados técnicos
│   ├── PROGRAMA1_metadata.json
│   └── PROGRAMA2_metadata.json
├── audit/                      # Auditoria completa
│   ├── audit_20250922_143000.jsonl
│   ├── req_20250922_143001_payload.json
│   ├── req_20250922_143001_response.json
│   └── audit_report_session_20250922_143000.md
└── logs/                       # Logs do sistema
    └── cobol_ai_engine_final_20250922_143000.log
```

## Solução de Problemas

### 1. Erro de Credenciais

**Problema:** `Credentials not configured`

**Solução:**
```bash
# Verificar se as variáveis estão definidas
echo $LUZIA_CLIENT_ID
echo $LUZIA_CLIENT_SECRET

# Redefinir se necessário
export LUZIA_CLIENT_ID="seu_client_id"
export LUZIA_CLIENT_SECRET="seu_client_secret"
```

### 2. Erro de Conectividade

**Problema:** `Failed to obtain token`

**Soluções:**
1. Verificar conectividade de rede
2. Confirmar credenciais válidas
3. Verificar se está na rede corporativa (se aplicável)
4. Verificar configurações de proxy

### 3. Erro de Importação

**Problema:** `ImportError` ou `ModuleNotFoundError`

**Solução:**
```bash
# Usar versão standalone
python luzia_provider_standalone.py

# Ou instalar dependências em falta
pip install requests urllib3
```

### 4. Problemas de Encoding

**Problema:** Erro ao ler arquivos COBOL

**Solução:**
- Verificar encoding do arquivo (UTF-8, Latin-1, etc.)
- O sistema tenta automaticamente diferentes encodings
- Converter arquivo para UTF-8 se necessário

### 5. Timeout de Requisições

**Problema:** Requisições muito lentas

**Configuração:**
- Timeout padrão: 120 segundos
- Para programas muito grandes, considere dividir em partes menores

## Monitoramento e Manutenção

### 1. Logs do Sistema

```bash
# Visualizar logs em tempo real
tail -f logs/cobol_ai_engine_final_*.log

# Buscar erros específicos
grep "ERROR" logs/cobol_ai_engine_final_*.log
```

### 2. Auditoria

```bash
# Visualizar relatório de auditoria
cat output/audit/audit_report_*.md

# Analisar estatísticas de sessão
grep "session_end" output/audit/audit_*.jsonl
```

### 3. Performance

```bash
# Monitorar tempo de processamento
grep "processing_time_ms" output/responses/*.json

# Verificar taxa de sucesso
grep "success" output/metadata/*.json | grep -c "true"
```

## Atualizações e Manutenção

### 1. Backup de Configurações

```bash
# Fazer backup das configurações
cp .env .env.backup
tar -czf config_backup.tar.gz .env logs/ output/
```

### 2. Limpeza de Arquivos Temporários

```bash
# Limpar logs antigos (manter últimos 7 dias)
find logs/ -name "*.log" -mtime +7 -delete

# Limpar resultados antigos
find output/ -name "*.json" -mtime +30 -delete
```

### 3. Atualização do Sistema

```bash
# Fazer backup antes da atualização
cp -r . ../cobol-ai-engine-backup

# Atualizar arquivos do sistema
# (substituir pelos novos arquivos)

# Testar após atualização
python test_enhanced_system.py
```

## Suporte e Documentação

### Arquivos de Referência
- `CORRECOES_IMPLEMENTADAS_v1_4_0.md`: Detalhes das correções
- `test_results_*.json`: Resultados dos testes
- `audit_report_*.md`: Relatórios de auditoria

### Logs Importantes
- `logs/cobol_ai_engine_final_*.log`: Log principal do sistema
- `audit/audit_*.jsonl`: Log estruturado de auditoria
- `output/metadata/`: Metadados técnicos das análises

### Contato e Suporte
Para questões técnicas, consulte os logs detalhados e relatórios de auditoria. O sistema fornece informações abrangentes para diagnóstico e resolução de problemas.

---

**Versão do Guia**: 1.0  
**Data**: 22 de setembro de 2025  
**Sistema**: COBOL AI Engine v1.4.0  
**Status**: Pronto para Produção
