    def _save_ai_request_json(self, response, output_dir):
        """Salva o request enviado ao provedor em formato JSON para auditoria."""
        try:
            # Criar diretório para requests se não existir
            request_dir = os.path.join(output_dir, "ai_requests")
            os.makedirs(request_dir, exist_ok=True)
            
            # Extrair dados do request dos metadados da resposta
            request_data = {
                "program_name": getattr(response, 'program_name', 'unknown'),
                "timestamp": datetime.now().isoformat(),
                "provider": response.provider,
                "model": response.model,
                "request_payload": getattr(response, 'request_payload', {}),
                "prompts_sent": getattr(response, 'prompts_used', {}),
                "headers": getattr(response, 'request_headers', {}),
                "endpoint": getattr(response, 'endpoint_used', ''),
                "method": getattr(response, 'http_method', 'POST'),
                "request_size": len(str(getattr(response, 'request_payload', {}))),
                "configuration": {
                    "temperature": getattr(response, 'temperature', 0.1),
                    "max_tokens": getattr(response, 'max_tokens', 4000),
                    "timeout": getattr(response, 'timeout', 120)
                }
            }
            
            # Salvar JSON do request
            program_name = getattr(response, 'program_name', 'unknown')
            json_filename = f"{program_name}_ai_request.json"
            json_filepath = os.path.join(request_dir, json_filename)
            
            with open(json_filepath, 'w', encoding='utf-8') as f:
                json.dump(request_data, f, indent=2, ensure_ascii=False, default=str)
            
            self.logger.info(f"JSON do request salvo: {json_filename}")
            
        except Exception as e:
            self.logger.error(f"Erro ao salvar JSON do request: {e}")
