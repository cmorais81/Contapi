#!/usr/bin/env python3
"""
LuzIA Provider Enhanced v1.4.0
Provedor LuzIA com renovação automática de token e tratamento robusto de respostas HTTP.
"""

import os
import json
import time
import logging
import requests
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, Tuple
import urllib3

# Desabilitar warnings SSL para ambiente corporativo
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class TokenManager:
    """Gerenciador de tokens com renovação automática."""
    
    def __init__(self, client_id: str, client_secret: str, auth_url: str):
        self.client_id = client_id
        self.client_secret = client_secret
        self.auth_url = auth_url
        self.token = None
        self.token_expires_at = None
        self.logger = logging.getLogger('TokenManager')
        
    def is_token_valid(self) -> bool:
        """Verifica se o token atual é válido."""
        if not self.token or not self.token_expires_at:
            return False
        
        # Considerar token inválido se expira em menos de 5 minutos
        buffer_time = timedelta(minutes=5)
        return datetime.now() < (self.token_expires_at - buffer_time)
    
    def get_valid_token(self) -> Optional[str]:
        """Obtém um token válido, renovando se necessário."""
        if self.is_token_valid():
            self.logger.debug("Token atual ainda é válido")
            return self.token
        
        self.logger.info("Token inválido ou expirado, renovando...")
        return self.refresh_token()
    
    def refresh_token(self) -> Optional[str]:
        """Renova o token de acesso."""
        self.logger.info("=== RENOVANDO TOKEN LUZIA ===")
        
        auth_payload = {
            "grant_type": "client_credentials",
            "client_id": self.client_id,
            "client_secret": self.client_secret
        }
        
        headers = {
            "Content-Type": "application/x-www-form-urlencoded",
            "Accept": "application/json"
        }
        
        try:
            self.logger.info(f"Enviando requisição para: {self.auth_url}")
            
            response = requests.post(
                self.auth_url,
                data=auth_payload,
                headers=headers,
                verify=False,
                timeout=30
            )
            
            self.logger.info(f"Status da autenticação: {response.status_code}")
            
            if response.status_code == 200:
                token_data = response.json()
                self.token = token_data.get("access_token")
                
                # Calcular expiração do token
                expires_in = token_data.get("expires_in", 3600)  # Default 1 hora
                self.token_expires_at = datetime.now() + timedelta(seconds=expires_in)
                
                self.logger.info(f"Token renovado com sucesso. Expira em: {self.token_expires_at}")
                return self.token
            else:
                self.logger.error(f"Erro na renovação do token: {response.status_code}")
                self.logger.error(f"Resposta: {response.text}")
                return None
                
        except Exception as e:
            self.logger.error(f"Exceção na renovação do token: {str(e)}")
            return None

class LuziaProviderEnhanced:
    """Provedor LuzIA aprimorado com renovação automática de token."""
    
    def __init__(self):
        self.logger = logging.getLogger('LuziaProviderEnhanced')
        
        # Configurações da LuzIA
        self.client_id = os.getenv("LUZIA_CLIENT_ID")
        self.client_secret = os.getenv("LUZIA_CLIENT_SECRET")
        
        # URLs conforme documentação
        self.auth_url = "https://login.azure.paas.santanderbr.pre.corp/auth/realms/santander/protocol/openid-connect/token"
        self.api_url = "https://gpt-api-aws.santanderbr.dev.corp/genai_services/v1/"
        
        # Inicializar gerenciador de tokens
        if self.client_id and self.client_secret:
            self.token_manager = TokenManager(
                self.client_id, 
                self.client_secret, 
                self.auth_url
            )
        else:
            self.token_manager = None
            self.logger.error("Credenciais LuzIA não configuradas")
        
        self.logger.info("LuzIA Provider Enhanced inicializado")
    
    def _handle_http_response(self, response: requests.Response) -> Tuple[bool, Dict[str, Any]]:
        """Trata diferentes códigos de status HTTP de forma robusta."""
        
        # Códigos de sucesso
        if response.status_code in [200, 201, 202]:
            try:
                result = response.json()
                self.logger.info(f"Resposta HTTP {response.status_code} processada com sucesso")
                return True, result
            except json.JSONDecodeError as e:
                self.logger.error(f"Erro ao decodificar JSON da resposta: {e}")
                return False, {"error": "Invalid JSON response", "raw_response": response.text}
        
        # Token expirado - tentar renovar
        elif response.status_code == 401:
            self.logger.warning("Token expirado (401), tentando renovar...")
            if self.token_manager:
                new_token = self.token_manager.refresh_token()
                if new_token:
                    return False, {"error": "token_expired", "action": "retry_with_new_token"}
            
            return False, {"error": "Authentication failed", "status_code": 401}
        
        # Outros erros de cliente
        elif 400 <= response.status_code < 500:
            self.logger.error(f"Erro do cliente: {response.status_code}")
            return False, {
                "error": f"Client error {response.status_code}",
                "message": response.text,
                "status_code": response.status_code
            }
        
        # Erros do servidor
        elif response.status_code >= 500:
            self.logger.error(f"Erro do servidor: {response.status_code}")
            return False, {
                "error": f"Server error {response.status_code}",
                "message": response.text,
                "status_code": response.status_code
            }
        
        # Outros códigos
        else:
            self.logger.warning(f"Código de status não esperado: {response.status_code}")
            return False, {
                "error": f"Unexpected status code {response.status_code}",
                "message": response.text,
                "status_code": response.status_code
            }
    
    def analyze_program(self, program_name: str, program_code: str, max_retries: int = 2) -> Dict[str, Any]:
        """Analisa programa COBOL com retry automático em caso de token expirado."""
        
        if not self.token_manager:
            return {
                "success": False,
                "error": "LuzIA credentials not configured",
                "provider": "luzia_enhanced"
            }
        
        self.logger.info(f"=== ANALISANDO PROGRAMA {program_name} ===")
        
        # Preparar prompts
        system_prompt = """Você é um programador COBOL muito experiente com mais de 20 anos de experiência em sistemas mainframe e aplicações críticas de negócio.

Sua tarefa é analisar o programa COBOL fornecido de forma completa e detalhada, considerando:

1. Arquitetura e estrutura técnica
2. Regras de negócio implementadas  
3. Qualidade do código e boas práticas
4. Comentários e documentação inline
5. Fluxos lógicos e complexidade
6. Interfaces e integrações
7. Performance e otimização
8. Manutenibilidade

Forneça uma análise profissional e detalhada que seria útil para outros desenvolvedores e analistas de negócio."""

        user_prompt = f"""Analise este programa COBOL:

Nome do Programa: {program_name}

Código Fonte:
{program_code}

Por favor, forneça uma análise completa incluindo:

1. **Análise Funcional**: O que o programa faz, qual seu propósito no sistema
2. **Estrutura Técnica**: Divisões, seções, variáveis principais, arquivos
3. **Regras de Negócio**: Regras implementadas, validações, cálculos
4. **Comentários e Documentação**: Análise dos comentários encontrados
5. **Qualidade do Código**: Avaliação técnica, pontos de melhoria
6. **Fluxos Lógicos**: Principais fluxos de execução e decisões
7. **Interfaces**: Arquivos de entrada/saída, chamadas para outros programas
8. **Recomendações**: Sugestões de melhoria e manutenção

Seja detalhado e técnico, mas também explique o contexto de negócio quando possível."""

        # Preparar payload para LuzIA usando formato pipelines/submit
        payload = {
            "input": {
                "query": [
                    {
                        "role": "system",
                        "content": system_prompt
                    },
                    {
                        "role": "user", 
                        "content": user_prompt
                    }
                ]
            },
            "config": [
                {
                    "type": "catena.llm.LLMRouter",
                    "obj_kwargs": {
                        "routing_model": "aws-claude-3-5-sonnet",
                        "temperature": 0.1
                    }
                }
            ]
        }
        
        # Tentar análise com retry automático
        for attempt in range(max_retries + 1):
            self.logger.info(f"Tentativa {attempt + 1}/{max_retries + 1}")
            
            # Obter token válido
            token = self.token_manager.get_valid_token()
            if not token:
                return {
                    "success": False,
                    "error": "Failed to obtain valid token",
                    "provider": "luzia_enhanced"
                }
            
            # Preparar headers
            headers = {
                "x-santander-client-id": self.client_id,
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json"
            }
            
            try:
                self.logger.info(f"Enviando requisição para: {self.api_url}pipelines/submit")
                
                response = requests.post(
                    url=f"{self.api_url}pipelines/submit",
                    json=payload,
                    headers=headers,
                    verify=False,
                    timeout=120
                )
                
                # Processar resposta
                success, result = self._handle_http_response(response)
                
                if success:
                    self.logger.info("Análise concluída com sucesso")
                    return {
                        "success": True,
                        "response": result,
                        "request_payload": payload,
                        "status_code": response.status_code,
                        "provider": "luzia_enhanced",
                        "model": "aws-claude-3-5-sonnet",
                        "attempt": attempt + 1
                    }
                
                # Se token expirou, tentar novamente
                elif result.get("error") == "token_expired" and attempt < max_retries:
                    self.logger.info("Token expirado, tentando novamente...")
                    continue
                
                # Outros erros
                else:
                    return {
                        "success": False,
                        "error": result.get("error", "Unknown error"),
                        "details": result,
                        "request_payload": payload,
                        "provider": "luzia_enhanced",
                        "attempt": attempt + 1
                    }
                    
            except Exception as e:
                self.logger.error(f"Exceção na tentativa {attempt + 1}: {str(e)}")
                if attempt == max_retries:
                    return {
                        "success": False,
                        "error": f"Exception after {max_retries + 1} attempts: {str(e)}",
                        "request_payload": payload,
                        "provider": "luzia_enhanced"
                    }
        
        return {
            "success": False,
            "error": f"Failed after {max_retries + 1} attempts",
            "provider": "luzia_enhanced"
        }
    
    def check_connectivity(self) -> Dict[str, Any]:
        """Verifica conectividade com a LuzIA."""
        self.logger.info("=== VERIFICANDO CONECTIVIDADE LUZIA ===")
        
        if not self.token_manager:
            return {
                "success": False,
                "error": "Credentials not configured",
                "details": {
                    "client_id_configured": bool(self.client_id),
                    "client_secret_configured": bool(self.client_secret)
                }
            }
        
        # Tentar obter token
        token = self.token_manager.get_valid_token()
        
        if token:
            return {
                "success": True,
                "message": "LuzIA connectivity OK",
                "details": {
                    "auth_url": self.auth_url,
                    "api_url": self.api_url,
                    "token_valid": True,
                    "token_expires_at": self.token_manager.token_expires_at.isoformat() if self.token_manager.token_expires_at else None
                }
            }
        else:
            return {
                "success": False,
                "error": "Failed to obtain token",
                "details": {
                    "auth_url": self.auth_url,
                    "api_url": self.api_url,
                    "token_valid": False
                }
            }

# Função de conveniência para uso direto
def create_luzia_provider() -> LuziaProviderEnhanced:
    """Cria uma instância do provedor LuzIA aprimorado."""
    return LuziaProviderEnhanced()

if __name__ == "__main__":
    # Teste básico
    provider = create_luzia_provider()
    connectivity = provider.check_connectivity()
    print(json.dumps(connectivity, indent=2, ensure_ascii=False))
