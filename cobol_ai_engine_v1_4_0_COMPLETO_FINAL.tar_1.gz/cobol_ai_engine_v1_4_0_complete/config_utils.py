#!/usr/bin/env python3
"""
COBOL AI Engine v1.0.6 - Config Utils
Utilitários para manipulação de configuração.
"""

from typing import List, Dict, Any

def get_enabled_models_from_config(config: Dict[str, Any]) -> List[str]:
    """
    Extrai lista de modelos dos provedores habilitados na configuração.
    
    Args:
        config: Configuração completa do sistema
        
    Returns:
        Lista de modelos disponíveis nos provedores habilitados
    """
    models = []
    providers_config = config.get('providers', {})
    
    for provider_name, provider_config in providers_config.items():
        # Verificar se o provedor está habilitado
        if not provider_config.get('enabled', False):
            continue
        
        # Extrair modelos do provedor
        provider_models = provider_config.get('models', {})
        
        if provider_models:
            # Adicionar modelos com prefixo do provedor para identificação
            for model_key in provider_models.keys():
                # Usar o nome da chave como identificador do modelo
                models.append(model_key)
    
    return models

def expand_env_vars(text: str) -> str:
    """
    Expande variáveis de ambiente no formato ${VAR_NAME}.
    
    Args:
        text: Texto com possíveis variáveis de ambiente
        
    Returns:
        Texto com variáveis expandidas
    """
    import os
    import re
    
    def replace_var(match):
        var_name = match.group(1)
        return os.getenv(var_name, match.group(0))  # Retorna original se não encontrar
    
    return re.sub(r'\$\{([^}]+)\}', replace_var, text)

def validate_provider_config(provider_name: str, provider_config: Dict[str, Any]) -> Dict[str, Any]:
    """
    Valida e normaliza configuração de um provedor.
    
    Args:
        provider_name: Nome do provedor
        provider_config: Configuração do provedor
        
    Returns:
        Dicionário com resultado da validação
    """
    result = {
        'valid': True,
        'errors': [],
        'warnings': []
    }
    
    # Verificar se está habilitado
    if not provider_config.get('enabled', False):
        result['warnings'].append(f"Provedor {provider_name} está desabilitado")
        return result
    
    # Validações específicas por provedor
    if provider_name == 'luzia':
        # Verificar configurações obrigatórias da LuzIA
        required_fields = ['client_id', 'client_secret', 'auth_url', 'api_url']
        
        for field in required_fields:
            if field not in provider_config:
                result['errors'].append(f"Campo obrigatório '{field}' não encontrado na configuração da LuzIA")
                result['valid'] = False
        
        # Verificar se as variáveis de ambiente estão configuradas
        client_id = provider_config.get('client_id', '')
        client_secret = provider_config.get('client_secret', '')
        
        if '${' in client_id:
            env_var = client_id.replace('${', '').replace('}', '')
            import os
            if not os.getenv(env_var):
                result['errors'].append(f"Variável de ambiente {env_var} não configurada")
                result['valid'] = False
        
        if '${' in client_secret:
            env_var = client_secret.replace('${', '').replace('}', '')
            import os
            if not os.getenv(env_var):
                result['errors'].append(f"Variável de ambiente {env_var} não configurada")
                result['valid'] = False
    
    elif provider_name == 'openai':
        # Verificar API key do OpenAI
        import os
        if not os.getenv('OPENAI_API_KEY'):
            result['errors'].append("Variável de ambiente OPENAI_API_KEY não configurada")
            result['valid'] = False
    
    # Verificar se há modelos configurados
    models = provider_config.get('models', {})
    if not models:
        result['warnings'].append(f"Nenhum modelo configurado para o provedor {provider_name}")
    
    return result
