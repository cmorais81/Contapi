"""
COBOL AI Engine v2.0.0 - Templates de Documentação
Templates profissionais para geração de documentação técnica completa.
"""

from typing import Dict, Any, List
from datetime import datetime


class DocumentationTemplates:
    """
    Classe responsável por fornecer templates profissionais para documentação COBOL.
    """
    
    @staticmethod
    def get_main_template() -> str:
        """Template principal para documentação completa de programa COBOL."""
        return """# Documentação Técnica - {program_name}

**Data da Análise:** {analysis_date}  
**Versão do Sistema:** COBOL AI Engine v2.0.0  
**Status:** {analysis_status}

---

## Resumo Executivo

{executive_summary}

---

## 1. Análise Funcional

### 1.1 Propósito do Programa
{functional_purpose}

### 1.2 Fluxo de Processamento
{processing_flow}

### 1.3 Entradas e Saídas
{inputs_outputs}

### 1.4 Condições de Execução
{execution_conditions}

---

## 2. Regras de Negócio e Compliance

### 2.1 Resumo das Regras de Negócio

**Total de Regras Identificadas:** {total_business_rules}

{business_rules_summary}

### 2.2 Regras Extraídas Automaticamente do Código

{automated_business_rules_detailed}

### 2.3 Regras Identificadas pela Análise Inteligente

{llm_business_rules_detailed}

### 2.4 Categorização das Regras por Tipo

#### 2.4.1 Regras de Validação
{validation_rules_detailed}

#### 2.4.2 Regras de Cálculo
{calculation_rules_detailed}

#### 2.4.3 Regras de Transformação de Dados
{data_transformation_rules_detailed}

#### 2.4.4 Regras de Processamento
{data_processing_rules_detailed}

#### 2.4.5 Regras de Integração
{integration_rules_detailed}

#### 2.4.6 Regras Regulatórias
{regulatory_rules_detailed}

### 2.5 Informações Extraídas dos Comentários
{comments_analysis_detailed}

### 2.6 Regulamentações e Compliance
{regulatory_compliance}

### 2.7 Códigos de Produtos e Operações
{product_operation_codes}

### 2.8 Validações e Controles Adicionais
{validations_controls}

---

## 3. Arquitetura Técnica

### 3.1 Estrutura das Divisões
{division_structure}

### 3.2 Organização de Seções
{section_organization}

### 3.3 Definição de Arquivos
{file_definitions}

### 3.4 Estruturas de Dados
{data_structures}

### 3.5 Fluxo de Controle
{control_flow}

---

## 4. Análise Técnica Detalhada

### 4.1 Trechos de Código Relevantes
{code_analysis}

### 4.2 Algoritmos Implementados
{algorithms}

### 4.3 Padrões de Design
{design_patterns}

---

## 5. Estruturas de Dados

### 5.1 Layouts de Registros
{record_layouts}

### 5.2 Tipos de Dados
{data_types}

### 5.3 Copybooks Utilizados
{copybooks}

### 5.4 Mapeamento de Dados
{data_mapping}

---

## 6. Interfaces e Integrações

### 6.1 Arquivos de Entrada
{input_files}

### 6.2 Arquivos de Saída
{output_files}

### 6.3 Chamadas de Programa
{program_calls}

### 6.4 Acesso a Banco de Dados
{database_access}

### 6.5 Dependências Externas
{external_dependencies}

---

## 7. Considerações de Performance

### 7.1 Pontos Críticos
{performance_critical_points}

### 7.2 Uso de Recursos
{resource_usage}

### 7.3 Oportunidades de Otimização
{optimization_opportunities}

---

## 8. Guia de Manutenção

### 8.1 Pontos de Atenção
{maintenance_attention_points}

### 8.2 Impactos de Mudanças
{change_impacts}

### 8.3 Procedimentos de Teste
{testing_procedures}

### 8.4 Recomendações
{maintenance_recommendations}

---

## 9. Avaliação de Qualidade

### 9.1 Aderência a Padrões
{standards_compliance}

### 9.2 Legibilidade do Código
{code_readability}

### 9.3 Manutenibilidade
{maintainability}

### 9.4 Sugestões de Melhoria
{improvement_suggestions}

---

## 9. Informações Técnicas

### 9.1 Estatísticas do Código
{code_statistics}

### 9.2 Complexidade
{complexity_analysis}

### 9.3 Dependências Identificadas
{identified_dependencies}

---

## 10. Anexos

### 10.1 Trechos de Código Relevantes
{relevant_code_snippets}

### 10.2 Diagramas de Fluxo
{flow_diagrams}

### 10.3 Glossário de Termos
{glossary}

---

**Documento gerado automaticamente pelo COBOL AI Engine v2.0.0**  
**Para questões técnicas, consulte a equipe de desenvolvimento**
"""

    @staticmethod
    def get_consolidated_template() -> str:
        """Template para relatório consolidado de múltiplos programas."""
        return """# Relatório Consolidado de Análise COBOL

**Data da Análise:** {analysis_date}  
**Versão do Sistema:** COBOL AI Engine v2.0.0  
**Total de Programas Analisados:** {total_programs}

---

## Resumo Executivo

{executive_summary}

---

## 1. Visão Geral da Análise

### 1.1 Escopo da Análise
{analysis_scope}

### 1.2 Metodologia Utilizada
{methodology}

### 1.3 Critérios de Avaliação
{evaluation_criteria}

---

## 2. Estatísticas Gerais

### 2.1 Distribuição por Tipo de Programa
{program_type_distribution}

### 2.2 Métricas de Código
{code_metrics}

### 2.3 Complexidade Geral
{overall_complexity}

---

## 3. Análise por Programa

{individual_program_analysis}

---

## 4. Análise de Dependências

### 4.1 Mapa de Relacionamentos
{dependency_map}

### 4.2 Copybooks Compartilhados
{shared_copybooks}

### 4.3 Interfaces Identificadas
{identified_interfaces}

---

## 5. Regras de Negócio Consolidadas

### 5.1 Regras Comuns
{common_business_rules}

### 5.2 Regras Específicas por Domínio
{domain_specific_rules}

### 5.3 Inconsistências Identificadas
{identified_inconsistencies}

---

## 6. Avaliação de Qualidade Geral

### 6.1 Padrões de Codificação
{coding_standards}

### 6.2 Manutenibilidade
{maintainability_assessment}

### 6.3 Pontos de Atenção
{attention_points}

---

## 7. Recomendações

### 7.1 Melhorias Prioritárias
{priority_improvements}

### 7.2 Modernização Sugerida
{modernization_suggestions}

### 7.3 Plano de Ação
{action_plan}

---

## 8. Conclusões

{conclusions}

---

## 9. Anexos

### 9.1 Lista Completa de Programas
{complete_program_list}

### 9.2 Glossário Técnico
{technical_glossary}

### 9.3 Referências
{references}

---

**Relatório gerado automaticamente pelo COBOL AI Engine v2.0.0**  
**Para informações detalhadas de cada programa, consulte os relatórios individuais**
"""

    @staticmethod
    def get_section_templates() -> Dict[str, str]:
        """Templates para seções específicas da documentação."""
        return {
            'executive_summary': """
Este documento apresenta a análise técnica completa do programa COBOL **{program_name}**, 
incluindo sua funcionalidade, arquitetura, regras de negócio e recomendações de manutenção.

**Principais Características:**
- Tipo de programa: {program_type}
- Complexidade: {complexity_level}
- Linhas de código: {lines_of_code}
- Status de qualidade: {quality_status}

**Resumo da Funcionalidade:**
{functional_summary}
""",

            'code_statistics': """
| Métrica | Valor |
|---------|-------|
| Total de linhas | {total_lines} |
| Linhas de código | {code_lines} |
| Linhas de comentário | {comment_lines} |
| Divisões identificadas | {divisions_count} |
| Seções identificadas | {sections_count} |
| Parágrafos identificados | {paragraphs_count} |
| Variáveis definidas | {variables_count} |
| Arquivos utilizados | {files_count} |
| Copybooks incluídos | {copybooks_count} |
""",

            'program_summary_table': """
| Programa | Linhas | Tipo | Complexidade | Status | Observações |
|----------|--------|------|--------------|--------|-------------|
{program_rows}
""",

            'dependency_table': """
| Programa Origem | Programa Destino | Tipo de Dependência | Descrição |
|-----------------|------------------|---------------------|-----------|
{dependency_rows}
""",

            'copybook_table': """
| Copybook | Programas que Utilizam | Função | Observações |
|----------|------------------------|--------|-------------|
{copybook_rows}
""",

            'business_rules_table': """
| Regra | Descrição | Programa(s) | Criticidade | Observações |
|-------|-----------|-------------|-------------|-------------|
{business_rules_rows}
""",

            'file_interface_table': """
| Arquivo | Tipo | Formato | Programa(s) | Descrição |
|---------|------|---------|-------------|-----------|
{file_interface_rows}
"""
        }

    @staticmethod
    def get_quality_assessment_template() -> str:
        """Template para avaliação de qualidade de código."""
        return """
### Avaliação de Qualidade - {program_name}

**Pontuação Geral:** {overall_score}/10

#### Critérios Avaliados:

| Critério | Pontuação | Observações |
|----------|-----------|-------------|
| Estrutura e Organização | {structure_score}/10 | {structure_notes} |
| Nomenclatura | {naming_score}/10 | {naming_notes} |
| Comentários e Documentação | {documentation_score}/10 | {documentation_notes} |
| Complexidade | {complexity_score}/10 | {complexity_notes} |
| Manutenibilidade | {maintainability_score}/10 | {maintainability_notes} |
| Aderência a Padrões | {standards_score}/10 | {standards_notes} |

#### Pontos Fortes:
{strengths}

#### Pontos de Melhoria:
{improvement_areas}

#### Recomendações Específicas:
{specific_recommendations}
"""

    @staticmethod
    def format_template(template: str, data: Dict[str, Any]) -> str:
        """
        Formata um template com os dados fornecidos.
        
        Args:
            template: Template string com placeholders
            data: Dicionário com dados para substituição
            
        Returns:
            String formatada
        """
        try:
            # Adicionar dados padrão se não fornecidos
            default_data = {
                'analysis_date': datetime.now().strftime('%d/%m/%Y %H:%M:%S'),
                'analysis_status': 'Concluída',
                'program_name': data.get('program_name', 'Não especificado'),
                'program_type': 'Não identificado',
                'complexity_level': 'Média',
                'quality_status': 'Em análise',
                'lines_of_code': 'N/A',
                'functional_summary': 'Análise em andamento...'
            }
            
            # Mesclar dados padrão com dados fornecidos
            merged_data = {**default_data, **data}
            
            # Substituir placeholders que não têm dados por mensagens padrão
            for key in merged_data:
                if merged_data[key] is None or merged_data[key] == '':
                    merged_data[key] = 'Informação não disponível'
            
            return template.format(**merged_data)
            
        except KeyError as e:
            return f"Erro na formatação do template: chave {e} não encontrada"
        except Exception as e:
            return f"Erro na formatação do template: {str(e)}"

    @staticmethod
    def get_markdown_formatting_guide() -> str:
        """Guia de formatação Markdown para documentação consistente."""
        return """
# Guia de Formatação Markdown para Documentação COBOL

## Estrutura de Títulos
- # Título Principal (H1) - Usado apenas para o título do documento
- ## Seção Principal (H2) - Seções numeradas (1, 2, 3...)
- ### Subseção (H3) - Subseções numeradas (1.1, 1.2...)
- #### Subsubseção (H4) - Para detalhamentos específicos

## Formatação de Texto
- **Negrito** para termos importantes e nomes de programas
- *Itálico* para ênfase e termos técnicos
- `Código inline` para nomes de variáveis e comandos
- > Citações para destacar informações importantes

## Listas
- Use listas numeradas para sequências e procedimentos
- Use listas com marcadores para itens relacionados
- Mantenha consistência na indentação

## Tabelas
- Use tabelas para dados estruturados
- Inclua cabeçalhos descritivos
- Mantenha alinhamento consistente

## Blocos de Código
```cobol
// Use blocos de código para exemplos COBOL
IDENTIFICATION DIVISION.
PROGRAM-ID. EXEMPLO.
```

## Links e Referências
- [Texto do link](URL) para referências externas
- Use referências internas quando apropriado

## Separadores
- Use --- para separar seções principais
- Use linhas em branco para melhorar legibilidade
"""

