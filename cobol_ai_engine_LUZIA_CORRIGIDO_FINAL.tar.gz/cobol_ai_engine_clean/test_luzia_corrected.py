#!/usr/bin/env python3
"""
Teste do LuziaProvider CORRIGIDO - Validação do formato do teste.py
"""

import os
import sys
import logging
from datetime import datetime

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.providers.luzia_provider import LuziaProvider
from src.providers.base_provider import AIRequest

def setup_logging():
    """Configurar logging para o teste"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(sys.stdout)
        ]
    )

def test_luzia_corrected():
    """Testar o provider LuzIA corrigido com formato do teste.py"""
    
    print("=" * 60)
    print("TESTE DO LUZIA PROVIDER CORRIGIDO")
    print("Formato baseado no teste.py que funciona")
    print("=" * 60)
    
    # Verificar credenciais
    client_id = os.getenv('LUZIA_CLIENT_ID')
    client_secret = os.getenv('LUZIA_CLIENT_SECRET')
    
    if not client_id or not client_secret:
        print("❌ ERRO: Credenciais LuzIA não encontradas!")
        print("   Defina as variáveis de ambiente:")
        print("   export LUZIA_CLIENT_ID='seu_client_id'")
        print("   export LUZIA_CLIENT_SECRET='seu_client_secret'")
        return False
    
    print(f"✅ Credenciais encontradas:")
    print(f"   Client ID: {client_id[:10]}...{client_id[-5:]}")
    print(f"   Client Secret: {'*' * len(client_secret)}")
    print()
    
    # Configuração do provider
    config = {
        'client_id': client_id,
        'client_secret': client_secret
    }
    
    try:
        # Inicializar provider
        print("🔧 Inicializando LuziaProvider corrigido...")
        provider = LuziaProvider(config)
        
        # Testar obtenção de token
        print("🔑 Testando obtenção de token...")
        token = provider.get_token()
        
        if token:
            print(f"✅ Token obtido com sucesso: {token[:20]}...{token[-10:]}")
        else:
            print("❌ Falha ao obter token")
            return False
        
        # Testar disponibilidade
        print("🔍 Testando disponibilidade do provider...")
        available = provider.is_available()
        
        if available:
            print("✅ Provider disponível")
        else:
            print("❌ Provider não disponível")
            return False
        
        # Testar status
        print("📊 Testando status do provider...")
        status = provider.get_status()
        print(f"   Status: {status}")
        
        # Testar análise simples
        print("📝 Testando análise simples...")
        
        test_prompt = """
Você é um analista de sistemas COBOL especializado.

=== PROGRAMA COBOL PARA ANÁLISE APROFUNDADA ===

IDENTIFICATION DIVISION.
PROGRAM-ID. TESTE.

DATA DIVISION.
WORKING-STORAGE SECTION.
01 WS-CONTADOR PIC 9(3) VALUE ZERO.

PROCEDURE DIVISION.
INICIO.
    DISPLAY 'PROGRAMA DE TESTE'.
    MOVE 1 TO WS-CONTADOR.
    DISPLAY 'CONTADOR: ' WS-CONTADOR.
    STOP RUN.

Analise este programa COBOL simples e forneça uma documentação básica.
"""
        
        # Criar request usando a classe AIRequest
        request = AIRequest(
            prompt=test_prompt,
            program_name='TESTE',
            program_code='IDENTIFICATION DIVISION.\nPROGRAM-ID. TESTE.\n...',
            context={'test': True}
        )
        
        print("📤 Enviando requisição para LuzIA...")
        response = provider.analyze(request)
        
        if response and response.success:
            print("✅ Resposta recebida com sucesso!")
            print(f"   Modelo usado: {response.model}")
            print(f"   Tokens utilizados: {response.tokens_used}")
            print(f"   Tempo de resposta: {response.response_time:.2f}s")
            print(f"   Tamanho do conteúdo: {len(response.content)} caracteres")
            
            # Mostrar preview da resposta
            if response.content:
                preview = response.content[:300] + "..." if len(response.content) > 300 else response.content
                print(f"   Preview da resposta: {preview}")
            
            return True
        else:
            print("❌ Falha na análise")
            if response:
                print(f"   Erro: {response.error_message}")
            return False
            
    except Exception as e:
        print(f"❌ ERRO durante o teste: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    """Função principal"""
    setup_logging()
    
    print(f"Iniciando teste em: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print()
    
    success = test_luzia_corrected()
    
    print()
    print("=" * 60)
    if success:
        print("✅ TESTE CONCLUÍDO COM SUCESSO!")
        print("   O LuziaProvider corrigido está funcionando")
        print("   Formato do teste.py aplicado com sucesso")
    else:
        print("❌ TESTE FALHOU!")
        print("   Verifique os logs acima para detalhes do erro")
    print("=" * 60)
    
    return 0 if success else 1

if __name__ == "__main__":
    sys.exit(main())
