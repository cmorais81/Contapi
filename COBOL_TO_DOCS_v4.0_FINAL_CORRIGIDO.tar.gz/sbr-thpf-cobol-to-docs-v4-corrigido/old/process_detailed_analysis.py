#!/usr/bin/env python3
"""
Função para processamento de análise detalhada de regras de negócio
"""

import os
import time
import logging
from typing import List, Dict, Any

def process_detailed_business_analysis(args, config_manager, cost_calculator, parser, models):
    """
    Processa análise detalhada de regras de negócio com extração específica de valores
    """
    logger = logging.getLogger(__name__)
    
    # Importações necessárias
    from core.detailed_prompt_generator import DetailedPromptGenerator
    from analyzers.deep_business_analyzer import DeepBusinessAnalyzer
    from providers.enhanced_provider_manager import EnhancedProviderManager
    from generators.documentation_generator import DocumentationGenerator
    from providers.base_provider import AIResponse
    
    logger.info("=== INICIANDO ANÁLISE DETALHADA DE REGRAS DE NEGÓCIO ===")
    logger.info(f"Modelos selecionados: {models}")
    logger.info(f"Arquivo de fontes: {args.fontes}")
    if args.books:
        logger.info(f"Arquivo de books: {args.books}")
    logger.info(f"Diretório de saída: {args.output}")
    
    start_time = time.time()
    
    try:
        # Parse do arquivo principal
        programs, books = parser.parse_file(args.fontes)
        
        # Parse de copybooks adicionais se especificado
        copybooks_content = ""
        if args.books and os.path.exists(args.books):
            _, additional_books = parser.parse_file(args.books)
            books.extend(additional_books)
            copybooks_content = "\n\n".join([book.content for book in books])
        
        logger.info(f"Programas encontrados: {len(programs)}, Books encontrados: {len(books)}")
        
        if not programs:
            print("Nenhum programa encontrado para análise.")
            return
            
    except Exception as e:
        logger.error(f"Erro ao parsear arquivos: {str(e)}")
        return
    
    # Criar diretório de saída
    os.makedirs(args.output, exist_ok=True)
    
    # Inicializar componentes especializados
    prompt_generator = DetailedPromptGenerator()
    business_analyzer = DeepBusinessAnalyzer()
    provider_manager = EnhancedProviderManager(config_manager.config)
    doc_generator = DocumentationGenerator(args.output)
    
    # Verificar se análise detalhada está disponível
    if not prompt_generator.is_detailed_analysis_available():
        logger.warning("Prompts de análise detalhada não encontrados, usando fallback")
    
    total_tokens = 0
    total_cost = 0.0
    successful_analyses = 0
    
    print(f"\nCOBOL to Docs v1.1 - Análise Detalhada de Regras de Negócio")
    print(f"Programas COBOL: {len(programs)}")
    if books:
        print(f"Copybooks: {len(books)}")
    print(f"Modelos: {', '.join(models)}")
    print(f"Diretório de saída: {args.output}")
    print("=" * 60)
    
    # Processar cada programa
    for i, program in enumerate(programs, 1):
        print(f"Analisando programa {i}/{len(programs)}: {program.name}")
        
        # Análise prévia com analisador especializado
        detailed_analysis = business_analyzer.extract_detailed_rules(
            program.content, 
            copybooks_content
        )
        
        logger.info(f"Análise prévia de {program.name}:")
        logger.info(f"  - Cálculos financeiros: {len(detailed_analysis.get('financial_calculations', []))}")
        logger.info(f"  - Regras de negócio: {len(detailed_analysis.get('business_rules', []))}")
        logger.info(f"  - Validações: {len(detailed_analysis.get('data_validations', []))}")
        
        # Processar com cada modelo
        for model in models:
            try:
                logger.info(f"Processando {program.name} com modelo {model}")
                
                # Gerar prompt detalhado
                if hasattr(args, 'extract_formulas') and args.extract_formulas:
                    detailed_prompt = prompt_generator.generate_financial_calculations_prompt(
                        program.content, copybooks_content
                    )
                    analysis_type = "Extração de Fórmulas Financeiras"
                else:
                    detailed_prompt = prompt_generator.generate_detailed_analysis_prompt(
                        program.content, copybooks_content, False
                    )
                    analysis_type = "Análise Detalhada de Regras de Negócio"
                
                logger.info(f"Tipo de análise: {analysis_type}")
                logger.info(f"Tamanho do prompt: {len(detailed_prompt)} caracteres")
                
                # Executar análise com provider
                from providers.base_provider import AIRequest
                
                ai_request = AIRequest(
                    prompt=detailed_prompt,
                    program_name=program.name,
                    program_code=program.content,
                    context={"analysis_type": analysis_type, "detailed_analysis": True}
                )
                
                analysis_result = provider_manager.analyze_with_model(model, ai_request)
                
                if analysis_result.success:
                    # Calcular custos
                    cost_info = cost_calculator.tokens_analytics(
                        {'usage': [{'total_tokens': analysis_result.tokens_used}]}, 
                        analysis_result.model
                    )
                    cost = cost_info.get('cost', 0.0)
                    
                    # Criar AIResponse
                    ai_response = AIResponse(
                        success=True,
                        content=analysis_result.content,
                        tokens_used=analysis_result.tokens_used,
                        model=model,
                        provider=analysis_result.provider,
                        prompts_used={
                            'analysis_type': analysis_type,
                            'detailed_prompt': detailed_prompt[:500] + "..." if len(detailed_prompt) > 500 else detailed_prompt,
                            'business_rules_found': len(detailed_analysis.get('business_rules', [])),
                            'financial_calculations_found': len(detailed_analysis.get('financial_calculations', [])),
                            'validations_found': len(detailed_analysis.get('data_validations', []))
                        }
                    )
                    
                    # Gerar documentação especializada
                    output_dir = os.path.join(args.output, f"detailed_analysis_{model.replace('-', '_')}")
                    os.makedirs(output_dir, exist_ok=True)
                    
                    # Salvar análise detalhada prévia
                    analysis_file = os.path.join(output_dir, f"{program.name}_detailed_analysis.json")
                    import json
                    with open(analysis_file, 'w', encoding='utf-8') as f:
                        json.dump(detailed_analysis, f, indent=2, ensure_ascii=False, default=str)
                    
                    # Gerar documentação principal
                    from parsers.cobol_parser_original import CobolProgram
                    
                    # Criar objeto CobolProgram se necessário
                    if not isinstance(program, CobolProgram):
                        cobol_program = CobolProgram(program.name, program.content)
                    else:
                        cobol_program = program
                    
                    doc_result = doc_generator.generate_program_documentation(
                        cobol_program, ai_response
                    )
                    
                    total_tokens += analysis_result.tokens_used
                    total_cost += cost
                    successful_analyses += 1
                    
                    logger.info(f"Análise detalhada de {program.name} com {model} bem-sucedida.")
                    logger.info(f"Tokens utilizados: {analysis_result.tokens_used:,}")
                    logger.info(f"Custo: ${cost:.4f}")
                    logger.info(f"Modelo utilizado: {model}")
                    logger.info(f"Análise prévia salva em: {analysis_file}")
                    
                    print(f"  ✓ {model}: {analysis_result.tokens_used:,} tokens, ${cost:.4f}")
                    
                else:
                    logger.error(f"Falha na análise detalhada de {program.name} com {model}: {analysis_result.error_message}")
                    print(f"  ✗ {model}: Falha - {analysis_result.error_message}")
                    
            except Exception as e:
                logger.error(f"Erro na análise detalhada de {program.name} com {model}: {e}")
                print(f"  ✗ {model}: Erro - {str(e)}")
    
    # Gerar relatório de custos
    cost_report = cost_calculator.format_cost_report()
    cost_report_path = os.path.join(args.output, 'relatorio_custos_detalhado.txt')
    with open(cost_report_path, 'w', encoding='utf-8') as f:
        f.write(cost_report)
    
    # Gerar relatório consolidado de análise detalhada
    generate_detailed_analysis_report(args.output, programs, models, detailed_analysis)
    
    # Resumo final
    total_time = time.time() - start_time
    total_analyses = len(programs) * len(models)
    success_rate = (successful_analyses / total_analyses) * 100 if total_analyses > 0 else 0
    
    print("=" * 60)
    print("ANÁLISE DETALHADA DE REGRAS DE NEGÓCIO CONCLUÍDA")
    print(f"Programas processados: {len(programs)}")
    print(f"Modelos utilizados: {len(models)} ({', '.join(models)})")
    print(f"Análises bem-sucedidas: {successful_analyses}/{total_analyses}")
    print(f"Taxa de sucesso geral: {success_rate:.1f}%")
    print(f"Total de tokens utilizados: {total_tokens:,}")
    print(f"Custo total: ${total_cost:.4f}")
    print(f"Tempo total de processamento: {total_time:.2f}s")
    print(f"Documentação gerada em: {args.output}")
    print(f"Relatório de custos: {cost_report_path}")
    print("=" * 60)

def generate_detailed_analysis_report(output_dir: str, programs: List, models: List[str], 
                                    detailed_analysis: Dict[str, Any]) -> None:
    """
    Gera relatório consolidado da análise detalhada
    """
    logger = logging.getLogger(__name__)
    
    try:
        report_path = os.path.join(output_dir, "relatorio_analise_detalhada.md")
        
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write("# Relatório de Análise Detalhada de Regras de Negócio\n\n")
            f.write(f"**Data:** {time.strftime('%d/%m/%Y %H:%M:%S')}\n")
            f.write(f"**Programas Analisados:** {len(programs)}\n")
            f.write(f"**Modelos Utilizados:** {', '.join(models)}\n\n")
            
            f.write("## Resumo da Análise Prévia\n\n")
            
            # Cálculos financeiros
            financial_calcs = detailed_analysis.get('financial_calculations', [])
            f.write(f"### Cálculos Financeiros Identificados: {len(financial_calcs)}\n\n")
            for calc in financial_calcs:
                f.write(f"- **{calc.name}** ({calc.type})\n")
                f.write(f"  - Fórmula: `{calc.formula}`\n")
                f.write(f"  - Variáveis: {', '.join(calc.variables.keys())}\n\n")
            
            # Regras de negócio
            business_rules = detailed_analysis.get('business_rules', [])
            f.write(f"### Regras de Negócio Identificadas: {len(business_rules)}\n\n")
            for rule in business_rules:
                f.write(f"- **{rule.name}**\n")
                f.write(f"  - Localização: {rule.location}\n")
                f.write(f"  - Descrição: {rule.description}\n")
                if rule.formula:
                    f.write(f"  - Fórmula: `{rule.formula}`\n")
                f.write(f"  - Condições: {len(rule.conditions)}\n\n")
            
            # Validações
            validations = detailed_analysis.get('data_validations', [])
            f.write(f"### Validações de Dados Identificadas: {len(validations)}\n\n")
            for validation in validations:
                f.write(f"- **{validation.get('type', 'N/A')}**\n")
                f.write(f"  - Campo: {validation.get('field', 'N/A')}\n")
                f.write(f"  - Localização: {validation.get('location', 'N/A')}\n\n")
            
            # Constantes e tabelas
            constants_tables = detailed_analysis.get('constants_and_tables', {})
            constants = constants_tables.get('constants', {})
            tables = constants_tables.get('tables', {})
            
            f.write(f"### Constantes Identificadas: {len(constants)}\n\n")
            for name, value in constants.items():
                f.write(f"- **{name}**: `{value}`\n")
            
            f.write(f"\n### Tabelas Identificadas: {len(tables)}\n\n")
            for name, info in tables.items():
                f.write(f"- **{name}**: Tamanho {info.get('size', 'N/A')}\n")
            
            f.write("\n## Observações\n\n")
            f.write("Esta análise prévia identifica elementos estruturais do código COBOL.\n")
            f.write("Para detalhes específicos de valores, fórmulas e regras, consulte os relatórios\n")
            f.write("gerados pelos modelos de IA que contêm a análise detalhada completa.\n")
        
        logger.info(f"Relatório de análise detalhada gerado: {report_path}")
        
    except Exception as e:
        logger.error(f"Erro ao gerar relatório de análise detalhada: {e}")
