#!/bin/bash
# Script de Instalação - COBOL to Docs v1.0
# Autor: Carlos Morais
# Compatível com Linux e macOS

echo "=================================================="
echo "COBOL to Docs v1.0 - Instalação Automática"
echo "Autor: Carlos Morais"
echo "=================================================="
echo

# Verificar Python
echo "Verificando Python..."
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 não encontrado!"
    echo "   Instale Python 3.11+ antes de continuar"
    echo
    echo "Ubuntu/Debian: sudo apt install python3.11 python3-pip"
    echo "CentOS/RHEL:   sudo yum install python3.11 python3-pip"
    echo "macOS:         brew install python@3.11"
    exit 1
fi

PYTHON_VERSION=$(python3 --version 2>&1 | cut -d' ' -f2)
echo "✅ Python encontrado: $PYTHON_VERSION"

# Verificar versão mínima (3.11)
PYTHON_MAJOR=$(echo $PYTHON_VERSION | cut -d'.' -f1)
PYTHON_MINOR=$(echo $PYTHON_VERSION | cut -d'.' -f2)

if [ "$PYTHON_MAJOR" -lt 3 ] || ([ "$PYTHON_MAJOR" -eq 3 ] && [ "$PYTHON_MINOR" -lt 11 ]); then
    echo "⚠️  Versão do Python muito antiga: $PYTHON_VERSION"
    echo "   Recomendado: Python 3.11+"
    echo "   Continuando mesmo assim..."
fi

echo

# Instalar dependências
echo "Instalando dependências Python..."
pip3 install pyyaml requests beautifulsoup4 markdown

if [ $? -eq 0 ]; then
    echo "✅ Dependências instaladas com sucesso"
else
    echo "❌ Erro ao instalar dependências"
    echo "   Tente: sudo pip3 install pyyaml requests beautifulsoup4 markdown"
    exit 1
fi

echo

# Verificar se já está extraído
if [ ! -d "cobol_to_docs_v1" ]; then
    # Procurar arquivo tar.gz
    if [ -f "cobol_to_docs_v1.0_FINAL.tar.gz" ]; then
        echo "Extraindo arquivos..."
        tar -xzf cobol_to_docs_v1.0_FINAL.tar.gz
        echo "✅ Arquivos extraídos"
    else
        echo "❌ Arquivo cobol_to_docs_v1.0_FINAL.tar.gz não encontrado"
        echo "   Certifique-se de que o arquivo está no diretório atual"
        exit 1
    fi
else
    echo "✅ Diretório cobol_to_docs_v1 já existe"
fi

echo

# Entrar no diretório
cd cobol_to_docs_v1

# Tornar scripts executáveis
echo "Configurando permissões..."
chmod +x main.py generate_prompts.py
echo "✅ Permissões configuradas"

echo

# Testar instalação
echo "Testando instalação..."
python3 main.py --status

if [ $? -eq 0 ]; then
    echo
    echo "=================================================="
    echo "✅ INSTALAÇÃO CONCLUÍDA COM SUCESSO!"
    echo "=================================================="
    echo
    echo "PRÓXIMOS PASSOS:"
    echo
    echo "1. Testar com exemplo:"
    echo "   python3 main.py --fontes examples/fontes.txt"
    echo
    echo "2. Gerar prompts personalizados:"
    echo "   python3 generate_prompts.py --interactive"
    echo
    echo "3. Ver documentação completa:"
    echo "   cat docs/GUIA_COMPLETO_USO.md"
    echo
    echo "4. Configurar credenciais LuzIA (opcional):"
    echo "   export LUZIA_CLIENT_ID='seu_id'"
    echo "   export LUZIA_CLIENT_SECRET='seu_secret'"
    echo
    echo "Sistema desenvolvido por Carlos Morais"
    echo "=================================================="
else
    echo
    echo "❌ Erro no teste da instalação"
    echo "   Verifique os logs acima para mais detalhes"
    exit 1
fi
