# Changelog

## v2.7.0 (2025-09-10)

### Novas Funcionalidades

- **Provedor Databricks**: Integração completa com Databricks Model Serving para análise de código COBOL usando Foundation Models como Llama 3.1.
- **Provedor AWS Bedrock**: Integração com Amazon Bedrock para análise usando modelos Claude, Llama e outros Foundation Models.
- **Múltiplas Configurações**: Configurações específicas para cada provedor (Databricks, Bedrock, LuzIA, etc.).
- **Suporte a Múltiplos Modelos**: Suporte a diferentes modelos de IA em cada provedor.

### Melhorias

- **Flexibilidade de Provedores**: Sistema agora suporta 6 provedores diferentes (LuzIA Real, Databricks, Bedrock, Enhanced Mock, Basic, LuzIA Mock).
- **Configuração Modular**: Cada provedor pode ser habilitado/desabilitado independentemente.
- **Fallback Robusto**: Sistema de fallback aprimorado com múltiplos provedores.
- **Autenticação Flexível**: Suporte a diferentes métodos de autenticação (OAuth2, Personal Access Token, AWS Credentials).

### Configurações Adicionadas

- **config_databricks.yaml**: Configuração específica para Databricks
- **config_bedrock.yaml**: Configuração específica para AWS Bedrock
- **config_complete.yaml**: Configuração com todos os provedores disponíveis

## v2.6.1 (2025-09-10)

### Correções Críticas

- **Corrigidos erros de inicialização de provedores**: Resolvido problema "missing 1 required positional argument: 'config'" que impedia a execução do sistema.
- **Corrigidos erros no DocumentationGenerator**: Resolvidos problemas com atributos inexistentes ('provider_name', 'input_tokens', 'output_tokens').
- **Corrigido construtor do LuziaProvider**: Ajustado para aceitar apenas o parâmetro 'config', compatível com outros provedores.

### Novas Funcionalidades

- **Configuração Segura**: Adicionada `config/config_safe.yaml` que funciona em qualquer ambiente sem dependências externas.
- **Manual Completo**: Documentação atualizada com todas as formas de execução possíveis e solução de problemas.
- **Guia de Início Rápido**: Criado guia simplificado para facilitar o primeiro uso.

### Melhorias

- **Compatibilidade Aprimorada**: Sistema funciona consistentemente em diferentes ambientes.
- **Documentação Expandida**: Manuais atualizados com exemplos práticos e solução de problemas.
- **Múltiplas Configurações**: Disponibilizadas configurações para diferentes cenários de uso.

## v2.6.0 (2025-09-10)

### Novas Funcionalidades

- **Integração com LuzIA Real**: Implementada a integração com o provedor LuzIA real, utilizando autenticação OAuth2 e o pipeline de análise de código.
- **Sistema de Prompts Customizáveis**: Adicionado um sistema de prompts customizáveis através do arquivo `config/prompts.yaml`, permitindo ao usuário adicionar, remover e modificar as perguntas de análise.
- **Geração de PDF**: Adicionada a capacidade de gerar a documentação em formato PDF utilizando a flag `--pdf`.

### Melhorias

- **Controle de Tokens**: Aprimorado o sistema de controle de tokens para incluir limites por hora e por dia.
- **Sistema de Fallback**: Melhorado o sistema de fallback para garantir que a análise seja concluída mesmo que o provedor primário falhe.
- **Documentação**: Criados manuais de usuário e de configuração detalhados.

### Correções

- Corrigidos vários erros de importação e inicialização de provedores.
- Corrigidos erros no gerador de documentação que impediam a criação dos arquivos de saída.
- Estabilizada a execução do sistema com diferentes configurações.


