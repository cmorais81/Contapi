#!/usr/bin/env python3
"""
COBOL AI Engine v2.7.0 - Script Principal CORRIGIDO
Sistema completo de análise de programas COBOL com IA.
TODOS OS ERROS DAS IMAGENS CORRIGIDOS.
"""

import os
import sys
import argparse
import logging
import time
from datetime import datetime
from pathlib import Path

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.core.config import ConfigManager
from src.core.prompt_manager import PromptManager
from src.providers.provider_manager import ProviderManager
from src.parsers.cobol_parser import COBOLParser
from src.generators.documentation_generator import DocumentationGenerator
from src.utils.pdf_converter import MarkdownToPDFConverter


def setup_logging(log_level: str = "INFO") -> None:
    """Configura o sistema de logging."""
    log_dir = "logs"
    os.makedirs(log_dir, exist_ok=True)
    
    log_file = os.path.join(log_dir, f"cobol_ai_engine_{datetime.now().strftime('%Y%m%d')}.log")
    
    logging.basicConfig(
        level=getattr(logging, log_level.upper()),
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file, encoding='utf-8'),
            logging.StreamHandler(sys.stdout)
        ]
    )


def print_version() -> None:
    """Exibe informações de versão."""
    version_file = os.path.join(os.path.dirname(__file__), 'VERSION')
    try:
        with open(version_file, 'r') as f:
            version = f.read().strip()
    except FileNotFoundError:
        version = "2.7.0"
    
    print(f"COBOL AI Engine v{version}")
    print("Sistema de análise de programas COBOL com IA")
    print("Copyright (c) 2025 - Todos os direitos reservados")


def print_status(config_manager: ConfigManager, provider_manager: ProviderManager) -> None:
    """Exibe status detalhado do sistema."""
    print("=== STATUS DO SISTEMA ===")
    print(f"COBOL AI Engine v2.7.0")
    print(f"Timestamp: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}")
    print()
    
    # Status dos provedores
    system_status = provider_manager.get_system_status()
    
    print("--- PROVEDORES ---")
    print(f"Total de provedores: {system_status['total_providers']}")
    print(f"Provedores disponíveis: {system_status['available_providers']}")
    print(f"Provedor primário: {system_status['primary_provider']}")
    print(f"Primário disponível: {'Sim' if system_status['primary_available'] else 'Não'}")
    print()
    
    print("--- DETALHES DOS PROVEDORES ---")
    for name, details in system_status['provider_details'].items():
        status_icon = "✓" if details['available'] else "✗"
        print(f"{status_icon} {name}")
        print(f"    Habilitado: {'✓' if details.get('enabled', False) else '✗'}")
        print(f"    Disponível: {'Sim' if details['available'] else 'Não'}")
        
        stats = details.get('statistics', {})
        if stats.get('total_requests', 0) > 0:
            print(f"    Uso: {stats['total_requests']} análises")
        else:
            print(f"    Uso: 0 análises")
        
        if details.get('error'):
            print(f"    Erro: {details['error']}")
    
    print()
    
    # Status do conversor PDF
    try:
        pdf_converter = MarkdownToPDFConverter()
        pdf_status = pdf_converter.get_status()
        
        print("--- CONVERSOR PDF ---")
        print(f"Métodos disponíveis: {pdf_status['total_methods']}")
        if pdf_status['preferred_method']:
            print(f"Método preferido: {pdf_status['preferred_method']}")
        
        for method, available in pdf_status['available_methods'].items():
            status_icon = "✓" if available else "✗"
            print(f"  {status_icon} {method}")
    except Exception as e:
        print("--- CONVERSOR PDF ---")
        print(f"Erro ao verificar status: {e}")


def list_questions(prompt_manager: PromptManager) -> None:
    """Lista perguntas configuradas."""
    # CORRIGIDO: Usar método implementado
    questions = prompt_manager.get_analysis_questions()
    
    print("=== PERGUNTAS CONFIGURADAS ===")
    for i, (key, question_data) in enumerate(questions.items(), 1):
        required = "Obrigatória" if question_data.get('required', False) else "Opcional"
        print(f"{i}. {question_data['question']} ({required})")
    
    print()
    print("=== PERGUNTA FUNCIONAL ATUAL ===")
    functional_question = prompt_manager.get_functional_question()
    print(f'"{functional_question}"')


def update_functional_question(prompt_manager: PromptManager, new_question: str) -> None:
    """Atualiza a pergunta funcional."""
    success = prompt_manager.update_functional_question(new_question)
    
    if success:
        print(f'Pergunta funcional atualizada para: "{new_question}"')
    else:
        print("Erro ao atualizar pergunta funcional")


def process_cobol_files(args, config_manager: ConfigManager, 
                       prompt_manager: PromptManager, 
                       provider_manager: ProviderManager) -> None:
    """Processa arquivos COBOL."""
    logger = logging.getLogger(__name__)
    
    # Inicializar componentes
    parser = COBOLParser()
    doc_generator = DocumentationGenerator(args.output)
    
    logger.info("=== INICIANDO PROCESSAMENTO ===")
    logger.info(f"Arquivo de fontes: {args.fontes}")
    if args.books:
        logger.info(f"Arquivo de books: {args.books}")
    if args.prompts:
        logger.info(f"Arquivo de prompts: {args.prompts}")
    logger.info(f"Diretório de saída: {args.output}")
    
    start_time = time.time()
    
    # Parsear arquivos
    print(f"Parseando arquivo de fontes: {args.fontes}")
    logger.info(f"Parseando arquivo de fontes: {args.fontes}")
    
    try:
        programs, books = parser.parse_file(args.fontes)
        
        if args.books and os.path.exists(args.books):
            print(f"Parseando arquivo de books: {args.books}")
            logger.info(f"Parseando arquivo de books: {args.books}")
            _, additional_books = parser.parse_file(args.books)
            books.extend(additional_books)
        
        logger.info(f"Programas encontrados: {len(programs)}")
        logger.info(f"Books encontrados: {len(books)}")
        
        if not programs:
            print("Nenhum programa encontrado para análise")
            return
        
    except Exception as e:
        logger.error(f"Erro ao parsear arquivos: {str(e)}")
        print(f"Erro ao parsear arquivos: {str(e)}")
        return
    
    # Processar cada programa
    successful_analyses = 0
    total_tokens = 0
    
    for i, program in enumerate(programs, 1):
        print(f"Analisando programa {i}/{len(programs)}: {program.name}")
        logger.info(f"Analisando programa {i}/{len(programs)}: {program.name}")
        
        try:
            # Gerar prompt customizável usando o PromptManager
            base_prompt = prompt_manager.generate_base_prompt(
                program.name, 
                program.content,
                {"books": [book.name for book in books]}
            )
            
            # Criar requisição
            from src.providers.base_provider import AIRequest
            request = AIRequest(
                prompt=base_prompt,
                program_name=program.name,
                program_code=program.content,
                context={"books": [book.name for book in books]}
            )
            
            # Analisar com provider manager
            response = provider_manager.analyze(request)
            
            if response.success:
                # Gerar documentação
                doc_generator.generate_program_documentation(
                    program, response, None
                )
                
                successful_analyses += 1
                total_tokens += response.tokens_used
                
                logger.info(f"Análise bem-sucedida: {program.name}")
            else:
                logger.error(f"Análise falhou para {program.name}: {response.error_message}")
                
        except Exception as e:
            logger.error(f"Erro ao processar {program.name}: {str(e)}")
            continue
    
    # Gerar relatório consolidado
    try:
        doc_generator.generate_consolidated_report(
            programs, books, successful_analyses, total_tokens
        )
        
        # Gerar relatório de status do sistema
        system_status = provider_manager.get_system_status()
        doc_generator.generate_system_status_report(system_status)
        
    except Exception as e:
        logger.error(f"Erro ao gerar relatórios: {str(e)}")
    
    # Converter para PDF se solicitado
    if args.pdf:
        convert_to_pdf(args.output)
    
    # Estatísticas finais
    processing_time = time.time() - start_time
    
    print()
    print("=== PROCESSAMENTO CONCLUÍDO ===")
    print(f"Programas processados: {len(programs)}")
    print(f"Copybooks processados: {len(books)}")
    print(f"Análises bem-sucedidas: {successful_analyses}/{len(programs)}")
    print(f"Taxa de sucesso: {(successful_analyses/len(programs)*100):.1f}%")
    print(f"Total de tokens utilizados: {total_tokens}")
    print(f"Tempo de processamento: {processing_time:.2f}s")
    print(f"Arquivos gerados em: {args.output}")
    
    if args.pdf:
        print(f"PDFs gerados em: {args.output}/pdf")


def convert_to_pdf(output_dir: str) -> None:
    """Converte arquivos Markdown para PDF."""
    logger = logging.getLogger(__name__)
    
    print("Convertendo documentação para PDF...")
    logger.info("Iniciando conversão para PDF")
    
    try:
        pdf_converter = MarkdownToPDFConverter()
        pdf_output_dir = os.path.join(output_dir, "pdf")
        
        # Converter todos os arquivos .md
        results = pdf_converter.convert_directory(output_dir, pdf_output_dir, "*.md")
        
        successful_conversions = sum(1 for success in results.values() if success)
        total_files = len(results)
        
        print(f"Conversão PDF: {successful_conversions}/{total_files} arquivos convertidos")
        logger.info(f"Conversão PDF concluída: {successful_conversions}/{total_files}")
        
        if successful_conversions > 0:
            print(f"PDFs salvos em: {pdf_output_dir}")
    except Exception as e:
        logger.error(f"Erro na conversão PDF: {e}")
        print(f"Erro na conversão PDF: {e}")


def main():
    """Função principal."""
    parser = argparse.ArgumentParser(
        description="COBOL AI Engine v2.7.0 - Análise de programas COBOL com IA",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Exemplos de uso:
  python main.py --fontes dados.txt                    # Análise básica
  python main.py --fontes dados.txt --pdf              # Com conversão PDF
  python main.py --status                              # Ver status do sistema
  python main.py --list-questions                      # Listar perguntas
  python main.py --update-question "Nova pergunta"     # Customizar pergunta
  python main.py --version                             # Ver versão
        """
    )
    
    # Argumentos principais
    parser.add_argument('--fontes', type=str, help='Arquivo com programas COBOL')
    parser.add_argument('--books', type=str, help='Arquivo com copybooks')
    parser.add_argument('--output', type=str, default='output', 
                       help='Diretório de saída (padrão: output)')
    
    # Configurações
    parser.add_argument('--config', type=str, default='config/config.yaml',
                       help='Arquivo de configuração (padrão: config/config.yaml)')
    parser.add_argument('--prompts', type=str, default='config/prompts.yaml',
                       help='Arquivo de prompts (padrão: config/prompts.yaml)')
    parser.add_argument('--provider', type=str, 
                       help='Provedor específico a usar')
    
    # Funcionalidades
    parser.add_argument('--pdf', action='store_true',
                       help='Converter documentação para PDF')
    parser.add_argument('--status', action='store_true',
                       help='Exibir status do sistema')
    parser.add_argument('--version', action='store_true',
                       help='Exibir versão')
    parser.add_argument('--list-questions', action='store_true',
                       help='Listar perguntas configuradas')
    parser.add_argument('--update-question', type=str,
                       help='Atualizar pergunta funcional')
    
    # Configurações de debug
    parser.add_argument('--log-level', type=str, default='INFO',
                       choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'],
                       help='Nível de log (padrão: INFO)')
    
    args = parser.parse_args()
    
    # Configurar logging
    setup_logging(args.log_level)
    
    # Comandos que não precisam de configuração completa
    if args.version:
        print_version()
        return
    
    try:
        # Carregar configurações
        config_manager = ConfigManager(args.config)
        prompt_manager = PromptManager(args.prompts)
        provider_manager = ProviderManager(config_manager.config)
        
        # Comandos de informação
        if args.status:
            print_status(config_manager, provider_manager)
            return
        
        if args.list_questions:
            list_questions(prompt_manager)
            return
        
        if args.update_question:
            update_functional_question(prompt_manager, args.update_question)
            return
        
        # Processamento principal
        if args.fontes:
            if not os.path.exists(args.fontes):
                print(f"Erro: Arquivo de fontes não encontrado: {args.fontes}")
                sys.exit(1)
            
            process_cobol_files(args, config_manager, prompt_manager, provider_manager)
        else:
            print("Erro: Especifique --fontes ou use --help para ver opções")
            sys.exit(1)
    
    except KeyboardInterrupt:
        print("\nProcessamento interrompido pelo usuário")
        sys.exit(1)
    except Exception as e:
        logging.getLogger(__name__).error(f"Erro fatal: {str(e)}")
        print(f"Erro: {str(e)}")
        sys.exit(1)


if __name__ == "__main__":
    main()

