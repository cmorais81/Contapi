"""
COBOL AI Engine v2.6.0 - LuzIA Provider Real
Implementação baseada no código real das imagens fornecidas.
Mantém controle de tokens e todas as funcionalidades desenvolvidas.
"""

import os
import json
import time
import logging
import requests
from typing import Dict, Any, Optional
from datetime import datetime

from .base_provider import BaseProvider, AIRequest, AIResponse


class RequestLLM:
    """
    Classe baseada no código real das imagens para integração com LuzIA.
    Implementa autenticação OAuth2 e chamadas à API.
    """
    
    def __init__(self, llm, input_text, context_text, client_id, client_secret):
        """Inicializa requisição LLM baseada no código das imagens."""
        self._llm = llm
        self._input_text = input_text
        self._context_text = context_text
        self._client_id = client_id
        self._client_secret = client_secret
        self._llm_token_response = None
        self._llm_token_status = 400
        self._llm_response = None
        self._llm_status = 400
    
    def generate_luzia_token(self):
        """Gera token LuzIA baseado no código das imagens."""
        url = "https://login.azure.pass.santanderbr.pre.corp/auth/realms/corp/protocol/openid-connect/token"
        
        payload = f"grant_type=client_credentials&client_id={self._client_id}&client_secret={self._client_secret}"
        
        headers = {
            "Content-Type": "application/x-www-form-urlencoded"
        }
        
        try:
            response = requests.request("POST", url, headers=headers, data=payload, verify=False, timeout=180)
            
            self._llm_token_response = response.json()
            self._llm_token_status = response.status_code
            
        except requests.exceptions.RequestException as e:
            print(f"Erro getting token from LuzIA. Status code: {e}")
            self._llm_token_response = e
    
    def call_luzia(self):
        """Chama LuzIA baseado no código das imagens."""
        access_token = self._llm_token_response["access_token"]
        
        url = "https://prd-api-aws.santanderbr.dev.corp/genai_services/v1/pipelines/submit"
        
        payload = {
            "input": {"query": f"{self._input_text}"},
            "config": [
                {
                    "type": "langchain.prompts.PromptTemplate",
                    "method": "from_template",
                    "method_kwargs": {
                        "template": f"{self._context_text}" + " {{query}}",
                        "template_format": "jinja2"
                    }
                },
                {
                    "type": "catena.llm.LLMRouter",
                    "obj_kwargs": {
                        "routing_model": f"{self._llm}",
                        "temperature": 0.0
                    }
                }
            ]
        }
        
        headers = {
            "x-santander-client-id": "1e63be7f-631c-44c1-acbe-5f4f5b26680e",
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json"
        }
        
        try:
            response = requests.request("POST", url, headers=headers, data=json.dumps(payload), verify=False)
            
            # Converter string JSON em dicionário Python
            response_json = response.json()
            self._llm_response = response_json["output"]["content"]
            self._llm_status = 200
            print("LuzIA executed successfully!")
            
        except requests.exceptions.RequestException as e:
            print(f"Error executing LuzIA. Status code: {e}")
            self._llm_response = str(e)
        except Exception as e:
            print(f"Error processing LuzIA response: {e}")
            self._llm_response = str(e)
    
    def return_llm(self):
        """Retorna resposta LLM baseado no código das imagens."""
        self.generate_luzia_token()
        
        print(f"self._llm_token_response: {self._llm_token_response}")
        
        if not self._llm_token_response or self._llm_token_status != 200:
            return self._llm_token_response, self._llm_token_status
        
        self.call_luzia()
        
        print(f"self._llm_response: {self._llm_response}")
        
        return self._llm_response, self._llm_status


class LuziaProviderReal(BaseProvider):
    """
    Provedor LuzIA implementado baseado no código real das imagens.
    Mantém todos os controles de token e funcionalidades desenvolvidas.
    """
    
    def __init__(self, config: Dict[str, Any]):
        """Inicializa o provedor LuzIA."""
        super().__init__(config)
        
        # Configurações específicas do LuzIA
        self.client_id = config.get('client_id') or os.getenv('LUZIA_CLIENT_ID')
        self.client_secret = config.get('client_secret') or os.getenv('LUZIA_CLIENT_SECRET')
        self.model = config.get('model', 'azure-gpt-4o-mini')
        self.api_base = config.get('api_base', 'https://prd-api-aws.santanderbr.dev.corp')
        
        # Controle de tokens (mantido das versões anteriores)
        self.max_tokens_per_request = config.get('max_tokens_per_request', 4000)
        self.max_tokens_per_hour = config.get('max_tokens_per_hour', 50000)
        self.max_tokens_per_day = config.get('max_tokens_per_day', 200000)
        
        # Controle de uso
        self.tokens_used_hour = 0
        self.tokens_used_day = 0
        self.last_hour_reset = datetime.now().hour
        self.last_day_reset = datetime.now().date()
        
        # Context template para COBOL (mantido das versões anteriores)
        self.context_template = config.get('context_template', 
            "Você é um especialista em análise de programas COBOL. "
            "Analise o código fornecido e responda de forma clara e detalhada. "
            "Foque em aspectos funcionais, técnicos e regras de negócio.")
        
        self.logger.info(f"LuzIA Provider Real inicializado - Modelo: {self.model}")
    
    def is_available(self) -> bool:
        """Verifica se o LuzIA está disponível."""
        if not self.enabled:
            return False
        
        if not self.client_id or not self.client_secret:
            self.logger.warning("Credenciais LuzIA não configuradas")
            return False
        
        # Verificar limites de tokens
        if not self._check_token_limits():
            self.logger.warning("Limites de tokens excedidos")
            return False
        
        return True
    
    def analyze(self, request: AIRequest) -> AIResponse:
        """
        Realiza análise usando LuzIA baseado no código das imagens.
        Mantém controle de tokens e faseamento.
        """
        start_time = time.time()
        
        try:
            # Validar requisição
            if not self.validate_request(request):
                return self.create_error_response("Requisição inválida", request)
            
            # Verificar disponibilidade
            if not self.is_available():
                return self.create_error_response("LuzIA não disponível", request)
            
            # Estimar tokens necessários
            estimated_tokens = self._estimate_tokens(request.prompt)
            
            # Verificar se pode processar
            if not self._can_process_tokens(estimated_tokens):
                return self.create_error_response(
                    f"Tokens estimados ({estimated_tokens}) excedem limites", request
                )
            
            # Preparar contexto específico para COBOL
            context_text = self._prepare_cobol_context(request)
            
            # Criar requisição LLM baseada no código das imagens
            llm_request = RequestLLM(
                llm=self.model,
                input_text=request.prompt,
                context_text=context_text,
                client_id=self.client_id,
                client_secret=self.client_secret
            )
            
            # Executar análise
            response_content, status_code = llm_request.return_llm()
            
            # Processar resposta
            if status_code == 200 and response_content:
                # Calcular tokens realmente utilizados
                tokens_used = self._calculate_tokens_used(request.prompt, response_content)
                
                # Atualizar controles de token
                self._update_token_usage(tokens_used)
                
                # Atualizar estatísticas
                response_time = time.time() - start_time
                self._update_statistics(True, tokens_used, response_time)
                
                # Criar resposta de sucesso
                return self.create_success_response(
                    content=response_content,
                    tokens_used=tokens_used,
                    request=request,
                    metadata={
                        'model_used': self.model,
                        'response_time': response_time,
                        'context_template': context_text[:100] + "...",
                        'estimated_tokens': estimated_tokens,
                        'actual_tokens': tokens_used
                    }
                )
            else:
                # Erro na resposta
                error_msg = f"LuzIA retornou erro: {status_code} - {response_content}"
                self.logger.error(error_msg)
                
                response_time = time.time() - start_time
                self._update_statistics(False, 0, response_time)
                
                return self.create_error_response(error_msg, request)
        
        except Exception as e:
            # Erro geral
            error_msg = f"Erro no LuzIA Provider: {str(e)}"
            self.logger.error(error_msg)
            
            response_time = time.time() - start_time
            self._update_statistics(False, 0, response_time)
            
            return self.create_error_response(error_msg, request)
    
    def _prepare_cobol_context(self, request: AIRequest) -> str:
        """Prepara contexto específico para análise COBOL."""
        context = self.context_template
        
        # Adicionar contexto específico do programa
        if request.program_name:
            context += f"\n\nPrograma: {request.program_name}"
        
        # Adicionar informações de copybooks se disponível
        if request.context and request.context.get('books'):
            books = request.context['books']
            if books:
                context += f"\n\nCopybooks relacionados: {', '.join(books[:5])}"
        
        # Adicionar instruções específicas para COBOL
        context += """
        
        Instruções específicas:
        1. Identifique a função principal do programa
        2. Analise a estrutura técnica (divisões, seções, parágrafos)
        3. Identifique regras de negócio implementadas
        4. Destaque trechos de código relevantes
        5. Explique relacionamentos com outros programas/copybooks
        """
        
        return context
    
    def _check_token_limits(self) -> bool:
        """Verifica limites de tokens."""
        current_time = datetime.now()
        
        # Reset contadores se necessário
        if current_time.hour != self.last_hour_reset:
            self.tokens_used_hour = 0
            self.last_hour_reset = current_time.hour
        
        if current_time.date() != self.last_day_reset:
            self.tokens_used_day = 0
            self.last_day_reset = current_time.date()
        
        # Verificar limites
        return (self.tokens_used_hour < self.max_tokens_per_hour and 
                self.tokens_used_day < self.max_tokens_per_day)
    
    def _estimate_tokens(self, text: str) -> int:
        """Estima número de tokens baseado no texto."""
        # Estimativa aproximada: 1 token ≈ 4 caracteres
        return len(text) // 4
    
    def _can_process_tokens(self, estimated_tokens: int) -> bool:
        """Verifica se pode processar a quantidade estimada de tokens."""
        return (estimated_tokens <= self.max_tokens_per_request and
                self.tokens_used_hour + estimated_tokens <= self.max_tokens_per_hour and
                self.tokens_used_day + estimated_tokens <= self.max_tokens_per_day)
    
    def _calculate_tokens_used(self, prompt: str, response: str) -> int:
        """Calcula tokens realmente utilizados."""
        # Estimativa baseada em prompt + resposta
        total_text = prompt + response
        return len(total_text) // 4
    
    def _update_token_usage(self, tokens_used: int) -> None:
        """Atualiza contadores de uso de tokens."""
        self.tokens_used_hour += tokens_used
        self.tokens_used_day += tokens_used
    
    def get_statistics(self) -> Dict[str, Any]:
        """Retorna estatísticas específicas do LuzIA."""
        base_stats = super().get_statistics()
        
        luzia_stats = {
            'provider_type': 'LuzIA_Real',
            'model': self.model,
            'api_base': self.api_base,
            'tokens_used_hour': self.tokens_used_hour,
            'tokens_used_day': self.tokens_used_day,
            'max_tokens_per_hour': self.max_tokens_per_hour,
            'max_tokens_per_day': self.max_tokens_per_day,
            'tokens_remaining_hour': self.max_tokens_per_hour - self.tokens_used_hour,
            'tokens_remaining_day': self.max_tokens_per_day - self.tokens_used_day,
            'credentials_configured': bool(self.client_id and self.client_secret)
        }
        
        base_stats.update(luzia_stats)
        return base_stats

