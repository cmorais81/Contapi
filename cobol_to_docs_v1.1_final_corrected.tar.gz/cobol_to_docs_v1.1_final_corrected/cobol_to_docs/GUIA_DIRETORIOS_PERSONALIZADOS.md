# Guia de Diretórios Personalizados - COBOL Analyzer v3.1.0

## Visão Geral

A versão 3.1.0 do COBOL Analyzer introduz funcionalidades avançadas para personalização de diretórios e inicialização automática do ambiente local. Esta documentação detalha como utilizar essas novas capacidades.

## Funcionalidades Principais

### 1. Inicialização Automática

O COBOL Analyzer agora detecta automaticamente se é a primeira execução e configura o ambiente local necessário:

- **Criação automática de diretórios**: config, data, logs, examples
- **Cópia de arquivos padrão**: configurações, prompts, base de conhecimento RAG
- **Configuração de exemplos**: programas COBOL e copybooks de exemplo
- **Validação de ambiente**: verificação de dependências e permissões

### 2. Diretórios Personalizáveis

Todos os diretórios utilizados pelo sistema podem ser personalizados via parâmetros de linha de comando:

| Diretório | Padrão | Parâmetro | Descrição |
|-----------|--------|-----------|-----------|
| Configurações | `./config` | `--config-dir` | Arquivos de configuração e prompts |
| Dados RAG | `./data` | `--data-dir` | Base de conhecimento e embeddings |
| Logs | `./logs` | `--logs-dir` | Arquivos de log e relatórios de sessão |
| Saída | `./output` | `--output` | Relatórios e documentação gerada |
| Exemplos | `./examples` | - | Programas e copybooks de exemplo |

## Comandos de Uso

### Inicialização Básica

```bash
# Primeira execução - inicialização automática
cobol-to-docs --fontes fontes.txt

# Inicialização manual forçada
cobol-to-docs --init

# Inicialização com diretórios personalizados
cobol-to-docs --init --config-dir ./minha_config --data-dir ./meus_dados
```

### Diretórios Personalizados

```bash
# Usar diretório de configuração personalizado
cobol-to-docs --fontes fontes.txt --config-dir /path/to/config

# Usar múltiplos diretórios personalizados
cobol-to-docs --fontes fontes.txt \
  --config-dir ./config_custom \
  --data-dir ./dados_rag \
  --logs-dir ./logs_custom

# Forçar reinicialização com novos diretórios
cobol-to-docs --init --force-init \
  --config-dir ./nova_config \
  --data-dir ./novos_dados
```

### Comandos de Conveniência

```bash
# Mostrar caminhos configurados
cobol-to-docs --show-paths

# Verificar status dos provedores
cobol-to-docs --status

# Ajuda completa
cobol-to-docs --help-full
```

## Estrutura de Diretórios

### Diretório de Configuração (config)

```
config/
├── config.yaml              # Configuração principal
├── config_enhanced.yaml     # Configuração aprimorada (v3.1.0)
├── prompts_enhanced.yaml    # Prompts aprimorados
└── templates/               # Templates de relatórios
    ├── report_template.html
    └── executive_template.html
```

### Diretório de Dados (data)

```
data/
├── cobol_knowledge_base.json    # Base de conhecimento RAG
├── embeddings/                  # Embeddings para RAG
├── rag_sessions/               # Relatórios de sessões RAG
├── cache/                      # Cache de análises
└── backups/                    # Backups automáticos
```

### Diretório de Logs (logs)

```
logs/
├── cobol_to_docs_YYYYMMDD_HHMMSS.log    # Logs principais
├── rag_session_YYYYMMDD_HHMMSS.log      # Logs de sessões RAG
└── error_reports/                        # Relatórios de erro
```

## Configuração Avançada

### Arquivo config_enhanced.yaml

O novo arquivo de configuração suporta:

```yaml
# Configuração de diretórios
directories:
  config_dir: "config"
  data_dir: "data"
  logs_dir: "logs"
  output_dir: "output"

# Inicialização automática
auto_initialization:
  enabled: true
  create_examples: true
  copy_default_configs: true
  setup_rag_data: true

# Modelos disponíveis
models:
  default: "enhanced_mock"
  enhanced_mock:
    provider: "enhanced_mock"
    model: "enhanced-mock-gpt-4"
    enabled: true
```

### Personalização de Prompts

O arquivo `prompts_enhanced.yaml` oferece conjuntos especializados:

- **original**: Prompts básicos para análise padrão
- **professional**: Análise profissional para documentação empresarial
- **expert**: Análise especializada para modernização
- **ultra_detailed**: Análise microscópica linha por linha

## Cenários de Uso

### 1. Desenvolvimento Local

```bash
# Configuração para desenvolvimento
cobol-to-docs --init \
  --config-dir ./dev_config \
  --data-dir ./dev_data \
  --logs-dir ./dev_logs
```

### 2. Ambiente de Produção

```bash
# Configuração para produção
cobol-to-docs --fontes /prod/fontes.txt \
  --config-dir /etc/cobol_analyzer \
  --data-dir /var/lib/cobol_analyzer \
  --logs-dir /var/log/cobol_analyzer
```

### 3. Análise Isolada por Projeto

```bash
# Cada projeto com seus próprios diretórios
mkdir projeto_a
cd projeto_a
cobol-to-docs --init --config-dir ./config --data-dir ./data

mkdir ../projeto_b
cd ../projeto_b
cobol-to-docs --init --config-dir ./config --data-dir ./data
```

### 4. Configuração Compartilhada

```bash
# Configuração compartilhada, dados isolados
cobol-to-docs --fontes fontes.txt \
  --config-dir /shared/cobol_config \
  --data-dir ./projeto_data \
  --logs-dir ./projeto_logs
```

## Migração de Versões Anteriores

### Migração Automática

O sistema detecta automaticamente instalações anteriores e oferece migração:

```bash
# O sistema perguntará sobre migração na primeira execução
cobol-to-docs --fontes fontes.txt

# Migração forçada
cobol-to-docs --init --force-init
```

### Migração Manual

Para migrar manualmente de versões anteriores:

1. **Backup dos dados existentes**:
   ```bash
   cp -r config config_backup
   cp -r data data_backup
   ```

2. **Inicializar nova estrutura**:
   ```bash
   cobol-to-docs --init --force-init
   ```

3. **Restaurar configurações personalizadas**:
   ```bash
   # Mesclar configurações antigas com novas
   # Copiar base de conhecimento RAG personalizada
   ```

## Resolução de Problemas

### Problemas Comuns

**Erro: Diretório não encontrado**
```bash
# Solução: Criar diretórios manualmente ou usar --init
cobol-to-docs --init --config-dir /path/to/config
```

**Erro: Permissões insuficientes**
```bash
# Solução: Verificar permissões ou usar diretório alternativo
cobol-to-docs --init --data-dir ~/cobol_data
```

**Erro: Configuração inválida**
```bash
# Solução: Validar configuração
cobol-to-docs --show-paths
# Recriar configuração padrão
cobol-to-docs --init --force-init
```

### Logs de Diagnóstico

Para diagnóstico detalhado:

```bash
# Executar com logging verbose
cobol-to-docs --fontes fontes.txt --log-level DEBUG

# Verificar logs
tail -f logs/cobol_to_docs_*.log
```

## Melhores Práticas

### 1. Organização de Projetos

- Use diretórios separados para cada projeto
- Mantenha configurações compartilhadas em local central
- Faça backup regular da base de conhecimento RAG

### 2. Configuração de Ambiente

- Configure variáveis de ambiente para caminhos padrão
- Use scripts de inicialização para projetos recorrentes
- Documente configurações específicas do projeto

### 3. Manutenção

- Execute `--show-paths` regularmente para verificar configuração
- Monitore logs para identificar problemas
- Atualize base de conhecimento RAG periodicamente

## Exemplos Práticos

### Script de Inicialização de Projeto

```bash
#!/bin/bash
# init_project.sh

PROJECT_NAME=$1
if [ -z "$PROJECT_NAME" ]; then
    echo "Uso: $0 <nome_do_projeto>"
    exit 1
fi

mkdir -p "$PROJECT_NAME"
cd "$PROJECT_NAME"

# Inicializar ambiente
cobol-to-docs --init \
  --config-dir ./config \
  --data-dir ./data \
  --logs-dir ./logs

echo "Projeto $PROJECT_NAME inicializado com sucesso!"
```

### Configuração Docker

```dockerfile
# Dockerfile para COBOL Analyzer
FROM python:3.11

WORKDIR /app
COPY . .

# Instalar dependências
RUN pip install -r requirements.txt

# Configurar diretórios
RUN mkdir -p /data/config /data/rag /data/logs

# Inicializar ambiente
RUN python main_enhanced.py --init \
  --config-dir /data/config \
  --data-dir /data/rag \
  --logs-dir /data/logs

ENTRYPOINT ["python", "main_enhanced.py"]
```

## Referência de Parâmetros

### Parâmetros de Diretório

| Parâmetro | Tipo | Descrição | Exemplo |
|-----------|------|-----------|---------|
| `--config-dir` | string | Diretório de configuração | `--config-dir ./config` |
| `--data-dir` | string | Diretório de dados RAG | `--data-dir ./data` |
| `--logs-dir` | string | Diretório de logs | `--logs-dir ./logs` |
| `--output` | string | Diretório de saída | `--output ./output` |

### Parâmetros de Inicialização

| Parâmetro | Tipo | Descrição |
|-----------|------|-----------|
| `--init` | flag | Inicializar ambiente local |
| `--force-init` | flag | Forçar reinicialização |
| `--show-paths` | flag | Mostrar caminhos configurados |

### Parâmetros de Análise

Todos os parâmetros de análise das versões anteriores continuam disponíveis e funcionam com os novos diretórios personalizados.

## Suporte e Documentação

Para mais informações:

- **Documentação completa**: `README.md`
- **Guia de instalação**: `INSTALACAO_PIP.md`
- **Exemplos**: Diretório `examples/`
- **Logs**: Verificar arquivos em `logs/`

Esta funcionalidade mantém total compatibilidade com versões anteriores enquanto oferece flexibilidade avançada para diferentes cenários de uso.
