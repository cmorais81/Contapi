"""
LuziaProvider Enhanced - Versão com Prompt Consolidado Minato
Integra o prompt consolidado no payload enviado para a Luzia
"""

import os
import json
import logging
import yaml
from typing import Dict, Any, Optional
from .luzia_provider import LuziaProvider

class LuziaProviderEnhanced(LuziaProvider):
    """Provider LuzIA aprimorado com prompt consolidado Minato"""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.consolidated_prompts = self._load_consolidated_prompts()
        self.logger.info("LuziaProvider Enhanced inicializado com prompt consolidado Minato")
    
    def _load_consolidated_prompts(self) -> Dict[str, Any]:
        """Carrega os prompts consolidados do arquivo Minato"""
        try:
            prompt_file = "config/prompts_consolidado_minato.yaml"
            if os.path.exists(prompt_file):
                with open(prompt_file, 'r', encoding='utf-8') as f:
                    data = yaml.safe_load(f)
                    return data.get('prompts', {})
            else:
                self.logger.warning(f"Arquivo de prompts consolidados não encontrado: {prompt_file}")
                return {}
        except Exception as e:
            self.logger.error(f"Erro ao carregar prompts consolidados: {e}")
            return {}
    
    def _get_consolidated_prompt(self, system_prompt: str, user_prompt: str) -> Dict[str, str]:
        """
        Obtém o prompt consolidado Minato ou usa os prompts originais como fallback
        """
        try:
            # Verificar se deve usar o prompt consolidado
            luzia_config = self.config.get('providers', {}).get('luzia', {})
            use_consolidated = luzia_config.get('use_consolidated_prompt', True)
            
            if not use_consolidated or not self.consolidated_prompts:
                return {'system': system_prompt, 'user': user_prompt}
            
            # Obter o prompt principal consolidado
            consolidated = self.consolidated_prompts.get('cobol_comprehensive_analysis', {})
            
            if not consolidated:
                self.logger.warning("Prompt consolidado não encontrado, usando prompts originais")
                return {'system': system_prompt, 'user': user_prompt}
            
            # Combinar system prompt consolidado com o original
            consolidated_system = consolidated.get('system', '')
            if consolidated_system:
                # Usar o prompt consolidado como base e adicionar contexto específico se necessário
                enhanced_system = f"{consolidated_system}\n\nCONTEXTO ADICIONAL:\n{system_prompt}"
            else:
                enhanced_system = system_prompt
            
            # Combinar user prompt consolidado com o original
            consolidated_user = consolidated.get('user', '')
            if consolidated_user:
                # Substituir placeholders no prompt consolidado
                enhanced_user = consolidated_user.format(
                    cobol_code="{cobol_code}",  # Será substituído pelo código real
                    copybooks="{copybooks}"     # Será substituído pelos copybooks reais
                )
                
                # Se o user_prompt original contém código COBOL, usar o template consolidado
                if "{cobol_code}" in user_prompt or "COBOL:" in user_prompt:
                    enhanced_user = consolidated_user
                else:
                    # Combinar com o prompt original
                    enhanced_user = f"{consolidated_user}\n\nINSTRUÇÕES ADICIONAIS:\n{user_prompt}"
            else:
                enhanced_user = user_prompt
            
            self.logger.info("Usando prompt consolidado Minato para análise COBOL")
            return {
                'system': enhanced_system,
                'user': enhanced_user
            }
            
        except Exception as e:
            self.logger.error(f"Erro ao processar prompt consolidado: {e}")
            return {'system': system_prompt, 'user': user_prompt}
    
    def _enhance_payload_with_minato_features(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Aprimora o payload com recursos específicos do prompt Minato
        """
        try:
            # Adicionar configurações específicas para análise COBOL detalhada
            if 'config' in payload and len(payload['config']) > 0:
                llm_config = payload['config'][0].get('obj_kwargs', {})
                
                # Configurações otimizadas para análise COBOL com Minato
                llm_config.update({
                    'temperature': 0.1,  # Baixa temperatura para análise técnica precisa
                    'max_tokens': 12000,  # Tokens suficientes para análise completa
                    'top_p': 0.9,
                    'frequency_penalty': 0.1,
                    'presence_penalty': 0.1,
                    'system_prompt': (
                        "Você é um especialista em análise COBOL bancário. "
                        "Forneça análises técnicas detalhadas, específicas e precisas. "
                        "Identifique componentes reutilizáveis e sugira arquitetura BIAN. "
                        "Use valores específicos, fórmulas exatas e exemplos práticos. "
                        "Responda sempre em português brasileiro."
                    )
                })
                
                payload['config'][0]['obj_kwargs'] = llm_config
            
            # Adicionar metadados para rastreamento
            payload['metadata'] = {
                'prompt_version': 'consolidado_minato_v1.0',
                'analysis_type': 'cobol_comprehensive',
                'timestamp': str(int(time.time())),
                'features': [
                    'business_rules_extraction',
                    'financial_calculations', 
                    'component_identification',
                    'bian_mapping',
                    'macro_rules'
                ]
            }
            
            return payload
            
        except Exception as e:
            self.logger.error(f"Erro ao aprimorar payload com recursos Minato: {e}")
            return payload
    
    def analyze(self, content: str, prompt: str, model: str) -> 'AIResponse':
        """
        Análise aprimorada usando prompt consolidado Minato
        """
        try:
            # Log para rastreamento
            self.logger.info(f"Iniciando análise com LuziaProvider Enhanced - Modelo: {model}")
            self.logger.info("Usando prompt consolidado Minato para análise COBOL detalhada")
            
            # Chamar o método pai com os prompts consolidados
            return super().analyze(content, prompt, model)
            
        except Exception as e:
            self.logger.error(f"Erro na análise com LuziaProvider Enhanced: {e}")
            # Fallback para o provider original
            return super().analyze(content, prompt, model)

# Função para substituir o LuziaProvider original
def create_enhanced_luzia_provider(config: Dict[str, Any]) -> LuziaProviderEnhanced:
    """Factory function para criar o provider aprimorado"""
    return LuziaProviderEnhanced(config)
