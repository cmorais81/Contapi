#!/bin/bash

# ========================================
# Script de Instalação - API de Governança de Dados V1.1
# Desenvolvido por: Carlos Morais - F1rst
# ========================================

set -e

echo "=========================================="
echo "API de Governança de Dados V1.1"
echo "Instalação Automática"
echo "=========================================="

# Verificar se está executando como root
if [[ $EUID -eq 0 ]]; then
   echo "Este script não deve ser executado como root"
   exit 1
fi

# Verificar dependências
echo "Verificando dependências..."

# Docker
if ! command -v docker &> /dev/null; then
    echo "Docker não encontrado. Instalando..."
    curl -fsSL https://get.docker.com -o get-docker.sh
    sh get-docker.sh
    sudo usermod -aG docker $USER
    rm get-docker.sh
fi

# Docker Compose
if ! command -v docker-compose &> /dev/null; then
    echo "Docker Compose não encontrado. Instalando..."
    sudo curl -L "https://github.com/docker/compose/releases/download/v2.21.0/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    sudo chmod +x /usr/local/bin/docker-compose
fi

# Python 3.11
if ! command -v python3.11 &> /dev/null; then
    echo "Python 3.11 não encontrado. Instalando..."
    sudo apt update
    sudo apt install -y software-properties-common
    sudo add-apt-repository -y ppa:deadsnakes/ppa
    sudo apt update
    sudo apt install -y python3.11 python3.11-pip python3.11-venv
fi

echo "Dependências verificadas com sucesso!"

# Configurar ambiente
echo "Configurando ambiente..."

# Criar diretório de trabalho
INSTALL_DIR="$HOME/governance-api-v1.1"
mkdir -p $INSTALL_DIR
cd $INSTALL_DIR

# Copiar arquivos do pacote
echo "Copiando arquivos..."
cp -r ../01_CODIGO_FONTE/* .
cp -r ../06_MODELOS_DBML/* .

# Configurar variáveis de ambiente
if [ ! -f .env ]; then
    echo "Criando arquivo de configuração..."
    cat > .env << EOF
# Configuração da API de Governança V1.1
DATABASE_URL=postgresql://governance_user:governance_pass@localhost:5432/governance_db
REDIS_URL=redis://localhost:6379/0
SECRET_KEY=$(openssl rand -hex 32)
JWT_ALGORITHM=HS256
JWT_EXPIRE_MINUTES=30
ENVIRONMENT=production

# Azure (opcional - configure se necessário)
AZURE_CLIENT_ID=
AZURE_CLIENT_SECRET=
AZURE_TENANT_ID=

# Databricks (opcional - configure se necessário)
DATABRICKS_WORKSPACE_URL=
DATABRICKS_TOKEN=

# Monitoramento
PROMETHEUS_ENABLED=true
GRAFANA_ENABLED=true
LOG_LEVEL=INFO

# Email (configure para notificações)
SMTP_HOST=
SMTP_PORT=587
SMTP_USER=
SMTP_PASSWORD=
EOF
fi

# Instalar dependências Python
echo "Instalando dependências Python..."
python3.11 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt

# Configurar banco de dados
echo "Configurando banco de dados..."
docker-compose up -d postgres redis

# Aguardar serviços iniciarem
echo "Aguardando serviços iniciarem..."
sleep 30

# Executar migrações
echo "Executando migrações do banco..."
alembic upgrade head

# Criar usuário administrador
echo "Criando usuário administrador..."
python3.11 << EOF
import asyncio
from app.database.connection import get_db
from app.models.user import User
from app.core.security import get_password_hash

async def create_admin():
    async for db in get_db():
        admin_user = User(
            username="admin",
            email="admin@f1rst.com.br",
            hashed_password=get_password_hash("admin123"),
            is_active=True,
            is_superuser=True
        )
        db.add(admin_user)
        await db.commit()
        print("Usuário administrador criado: admin / admin123")
        break

asyncio.run(create_admin())
EOF

# Iniciar todos os serviços
echo "Iniciando serviços..."
docker-compose up -d

# Aguardar API inicializar
echo "Aguardando API inicializar..."
sleep 60

# Verificar saúde da API
echo "Verificando saúde da API..."
if curl -f http://localhost:8000/health > /dev/null 2>&1; then
    echo "API iniciada com sucesso!"
else
    echo "Erro ao iniciar API. Verificando logs..."
    docker-compose logs api
    exit 1
fi

# Executar testes básicos
echo "Executando testes básicos..."
python3.11 -m pytest tests/test_basic.py -v

# Configurar monitoramento
echo "Configurando monitoramento..."
echo "Grafana disponível em: http://localhost:3000 (admin/admin)"
echo "Prometheus disponível em: http://localhost:9090"

# Criar script de backup
echo "Configurando backup automático..."
cat > backup.sh << 'EOF'
#!/bin/bash
BACKUP_DIR="$HOME/governance-backups"
DATE=$(date +%Y%m%d_%H%M%S)

mkdir -p $BACKUP_DIR

# Backup do banco
docker-compose exec -T postgres pg_dump -U governance_user governance_db > $BACKUP_DIR/db_backup_$DATE.sql

# Backup dos logs
tar -czf $BACKUP_DIR/logs_backup_$DATE.tar.gz logs/

# Manter apenas últimos 30 backups
find $BACKUP_DIR -name "*.sql" -mtime +30 -delete
find $BACKUP_DIR -name "*.tar.gz" -mtime +30 -delete

echo "Backup concluído: $BACKUP_DIR"
EOF

chmod +x backup.sh

# Configurar cron para backup diário
(crontab -l 2>/dev/null; echo "0 2 * * * $INSTALL_DIR/backup.sh") | crontab -

echo "=========================================="
echo "INSTALAÇÃO CONCLUÍDA COM SUCESSO!"
echo "=========================================="
echo ""
echo "Serviços disponíveis:"
echo "- API: http://localhost:8000"
echo "- Documentação: http://localhost:8000/docs"
echo "- Grafana: http://localhost:3000 (admin/admin)"
echo "- Prometheus: http://localhost:9090"
echo ""
echo "Credenciais padrão:"
echo "- Usuário: admin"
echo "- Senha: admin123"
echo ""
echo "Próximos passos:"
echo "1. Altere a senha do administrador"
echo "2. Configure integrações (Azure, Databricks)"
echo "3. Configure notificações por email"
echo "4. Importe seus dados existentes"
echo ""
echo "Suporte: carlos.morais@f1rst.com.br"
echo "=========================================="

