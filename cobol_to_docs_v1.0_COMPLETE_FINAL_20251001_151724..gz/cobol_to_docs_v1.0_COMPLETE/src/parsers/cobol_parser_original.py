"""
COBOL Parser - Parser original para programas COBOL
"""

import re
import logging
from typing import List, Tuple, Dict, Any
from dataclasses import dataclass

@dataclass
class CobolProgram:
    """Representa um programa COBOL"""
    name: str
    content: str
    metadata: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.metadata is None:
            self.metadata = {}

@dataclass  
class CobolCopybook:
    """Representa um copybook COBOL"""
    name: str
    content: str
    metadata: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.metadata is None:
            self.metadata = {}

class COBOLParser:
    """Parser para programas e copybooks COBOL"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
        # Padrões para identificação
        self.program_pattern = re.compile(r'PROGRAM-ID\.\s*([A-Z0-9\-]+)', re.IGNORECASE)
        self.copybook_pattern = re.compile(r'COPY\s+([A-Z0-9\-]+)', re.IGNORECASE)
        
        self.logger.info("COBOL Parser inicializado")
    
    def parse_file(self, file_path: str) -> Tuple[List[CobolProgram], List[CobolCopybook]]:
        """Parse de arquivo contendo programas e/ou copybooks"""
        
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            self.logger.info(f"Parseando arquivo: {file_path}")
            
            # Separar programas e copybooks
            programs = self._extract_programs(content)
            copybooks = self._extract_copybooks(content)
            
            self.logger.info(f"Parseados {len(programs)} programas e {len(copybooks)} books de {file_path}")
            
            return programs, copybooks
            
        except Exception as e:
            self.logger.error(f"Erro ao parsear {file_path}: {e}")
            return [], []
    
    def _extract_programs(self, content: str) -> List[CobolProgram]:
        """Extrai programas do conteúdo"""
        
        programs = []
        
        # Dividir por PROGRAM-ID
        program_sections = re.split(r'(?=PROGRAM-ID\.)', content, flags=re.IGNORECASE)
        
        for section in program_sections:
            if not section.strip():
                continue
                
            # Extrair nome do programa
            match = self.program_pattern.search(section)
            if match:
                program_name = match.group(1).strip()
                
                # Extrair conteúdo até END PROGRAM ou próximo PROGRAM-ID
                program_content = self._extract_program_content(section)
                
                if program_content:
                    program = CobolProgram(
                        name=program_name,
                        content=program_content,
                        metadata={
                            "lines": len(program_content.split('\n')),
                            "size": len(program_content),
                            "extracted_from": "file_parse"
                        }
                    )
                    programs.append(program)
        
        return programs
    
    def _extract_copybooks(self, content: str) -> List[CobolCopybook]:
        """Extrai copybooks do conteúdo"""
        
        copybooks = []
        
        # Procurar por definições de copybook
        # Assumindo que copybooks são seções que não são programas
        lines = content.split('\n')
        current_copybook = []
        copybook_name = None
        
        for line in lines:
            line = line.strip()
            
            # Identificar início de copybook (heurística)
            if (line.startswith('01 ') or line.startswith('05 ') or 
                line.startswith('10 ') or line.startswith('15 ')):
                
                if not copybook_name:
                    # Tentar extrair nome do copybook
                    copybook_name = self._guess_copybook_name(line)
                
                current_copybook.append(line)
                
            elif line.startswith('COPY '):
                # Referência a copybook
                copy_match = self.copybook_pattern.search(line)
                if copy_match:
                    ref_name = copy_match.group(1)
                    if not any(cb.name == ref_name for cb in copybooks):
                        # Criar copybook placeholder
                        copybook = CobolCopybook(
                            name=ref_name,
                            content=f"* Copybook {ref_name} (referenciado)",
                            metadata={"type": "reference", "referenced_in": line}
                        )
                        copybooks.append(copybook)
            
            elif current_copybook and (line.startswith('PROGRAM-ID') or 
                                     line.startswith('PROCEDURE DIVISION')):
                # Fim do copybook
                if copybook_name and current_copybook:
                    copybook_content = '\n'.join(current_copybook)
                    copybook = CobolCopybook(
                        name=copybook_name,
                        content=copybook_content,
                        metadata={
                            "lines": len(current_copybook),
                            "size": len(copybook_content),
                            "type": "definition"
                        }
                    )
                    copybooks.append(copybook)
                
                current_copybook = []
                copybook_name = None
        
        # Processar último copybook se existir
        if copybook_name and current_copybook:
            copybook_content = '\n'.join(current_copybook)
            copybook = CobolCopybook(
                name=copybook_name,
                content=copybook_content,
                metadata={
                    "lines": len(current_copybook),
                    "size": len(copybook_content),
                    "type": "definition"
                }
            )
            copybooks.append(copybook)
        
        return copybooks
    
    def _extract_program_content(self, section: str) -> str:
        """Extrai conteúdo completo do programa"""
        
        lines = section.split('\n')
        content_lines = []
        
        for line in lines:
            content_lines.append(line)
            
            # Parar em END PROGRAM
            if re.match(r'\s*END\s+PROGRAM', line, re.IGNORECASE):
                break
        
        return '\n'.join(content_lines)
    
    def _guess_copybook_name(self, line: str) -> str:
        """Tenta adivinhar nome do copybook"""
        
        # Extrair primeiro campo após nível
        parts = line.split()
        if len(parts) >= 2:
            return parts[1].replace('.', '')
        
        return f"COPYBOOK_{len(line)}"
    
    def parse_content(self, content: str, content_type: str = "auto") -> Tuple[List[CobolProgram], List[CobolCopybook]]:
        """Parse de conteúdo direto"""
        
        if content_type == "auto":
            # Detectar tipo automaticamente
            if "PROGRAM-ID" in content.upper():
                content_type = "program"
            else:
                content_type = "copybook"
        
        if content_type == "program":
            programs = self._extract_programs(content)
            return programs, []
        else:
            copybooks = self._extract_copybooks(content)
            return [], copybooks
    
    def validate_cobol_syntax(self, content: str) -> Dict[str, Any]:
        """Validação básica de sintaxe COBOL"""
        
        validation = {
            "valid": True,
            "errors": [],
            "warnings": [],
            "statistics": {}
        }
        
        lines = content.split('\n')
        
        # Estatísticas básicas
        validation["statistics"] = {
            "total_lines": len(lines),
            "non_empty_lines": len([l for l in lines if l.strip()]),
            "comment_lines": len([l for l in lines if l.strip().startswith('*')]),
            "has_program_id": "PROGRAM-ID" in content.upper(),
            "has_procedure_division": "PROCEDURE DIVISION" in content.upper()
        }
        
        return validation
