"""
Enhanced COBOL Analyzer - Analisador avançado com RAG e aprendizado
"""

import logging
import sys
import os
from typing import List, Dict, Any, Optional

# Adicionar src ao path
current_dir = os.path.dirname(os.path.abspath(__file__))
src_dir = os.path.join(current_dir, '..')
sys.path.insert(0, src_dir)

from core.ai_response import AIResponse
from core.analysis_request import AnalysisRequest
from core.prompt_manager import PromptManager
from parsers.cobol_parser_original import CobolProgram, CobolCopybook

class EnhancedCOBOLAnalyzer:
    """Analisador COBOL avançado com RAG e aprendizado"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Inicializar componentes
        self.prompt_manager = PromptManager()
        self.providers = {}
        self.rag_engine = None
        self.learning_system = None
        
        # Tentar inicializar RAG
        try:
            from rag.advanced_rag_engine import AdvancedRAGEngine
            self.rag_engine = AdvancedRAGEngine()
            self.logger.info("RAG Engine inicializado")
        except Exception as e:
            self.logger.warning(f"RAG não disponível: {e}")
        
        # Tentar inicializar providers
        try:
            self._initialize_providers()
        except Exception as e:
            self.logger.error(f"Erro ao inicializar providers: {e}")
        
        # Tentar inicializar sistema de aprendizado
        try:
            from rag.learning_system import LearningSystem
            self.learning_system = LearningSystem()
            self.logger.info("Learning System inicializado")
        except Exception as e:
            self.logger.warning(f"Learning System não disponível: {e}")
        
        self.logger.info("Enhanced COBOL Analyzer inicializado com RAG")
    
    def _initialize_providers(self):
        """Inicializa providers disponíveis"""
        
        # Enhanced Mock Provider
        try:
            from providers.enhanced_mock_provider import EnhancedMockProvider
            self.providers['enhanced_mock'] = EnhancedMockProvider(self.config)
            self.logger.info("Enhanced Mock Provider inicializado")
        except Exception as e:
            self.logger.error(f"Erro ao inicializar Enhanced Mock Provider: {e}")
        
        # LuzIA Provider
        try:
            from providers.luzia_provider import LuzIAProvider
            if self.config.get('providers', {}).get('luzia', {}).get('enabled', False):
                self.providers['luzia'] = LuzIAProvider(self.config)
                self.logger.info("LuzIA Provider inicializado")
        except Exception as e:
            self.logger.warning(f"LuzIA Provider não disponível: {e}")
        
        # GitHub Copilot Provider
        try:
            from providers.github_copilot_provider import GitHubCopilotProvider
            if self.config.get('providers', {}).get('github_copilot', {}).get('enabled', False):
                self.providers['github_copilot'] = GitHubCopilotProvider(self.config)
                self.logger.info("GitHub Copilot Provider inicializado")
        except Exception as e:
            self.logger.warning(f"GitHub Copilot Provider não disponível: {e}")
    
    def analyze_program_enhanced(self, program: CobolProgram, copybooks: List[CobolCopybook] = None,
                               model: str = "enhanced_mock") -> Optional[AIResponse]:
        """Analisa programa COBOL com funcionalidades avançadas"""
        
        try:
            self.logger.info(f"Analisando programa: {program.name}")
            
            # Verificar se provider está disponível
            if model not in self.providers:
                # Tentar criar provider enhanced_mock como fallback
                if model == "enhanced_mock":
                    self._create_fallback_provider()
                
                if model not in self.providers:
                    raise ValueError(f"Provider não disponível: {model}")
            
            # Criar request de análise
            analysis_request = AnalysisRequest(
                program=program,
                copybooks=copybooks or [],
                model=model,
                strategy="expert_analysis",
                config=self.config
            )
            
            # Enriquecer com RAG se disponível
            if self.rag_engine:
                try:
                    rag_context = self.rag_engine.retrieve_relevant_knowledge(program.content)
                    analysis_request.rag_context = rag_context
                    self.logger.debug(f"RAG context adicionado: {len(rag_context)} itens")
                except Exception as e:
                    self.logger.warning(f"Erro no RAG: {e}")
            
            # Executar análise
            provider = self.providers[model]
            ai_response = provider.analyze(analysis_request)
            
            # Aprendizado automático se disponível
            if self.learning_system and ai_response and ai_response.success:
                try:
                    self.learning_system.learn_from_analysis(program, ai_response)
                    self.logger.debug("Aprendizado automático executado")
                except Exception as e:
                    self.logger.warning(f"Erro no aprendizado: {e}")
            
            return ai_response
            
        except Exception as e:
            self.logger.error(f"Erro na análise: {e}")
            return None
    
    def _create_fallback_provider(self):
        """Cria provider enhanced_mock como fallback"""
        
        try:
            # Criar provider simples se não existir
            class SimpleMockProvider:
                def __init__(self, config):
                    self.config = config
                    self.logger = logging.getLogger(__name__)
                
                def analyze(self, request):
                    """Análise mock simples"""
                    
                    program = request.program
                    
                    # Análise básica do programa
                    analysis_content = f"""# Análise Funcional - {program.name}

## Informações Gerais
- **Programa**: {program.name}
- **Tipo**: Programa COBOL
- **Linhas de Código**: {len(program.content.split(chr(10)))}

## Análise Funcional

### Objetivo do Programa
O programa {program.name} é um sistema de processamento COBOL que realiza operações de manipulação de dados.

### Estrutura Identificada
- **IDENTIFICATION DIVISION**: Identificação do programa
- **ENVIRONMENT DIVISION**: Configuração do ambiente
- **DATA DIVISION**: Definição de dados
- **PROCEDURE DIVISION**: Lógica de processamento

### Funcionalidades Principais
1. Processamento de arquivos sequenciais
2. Manipulação de registros
3. Validação de dados
4. Geração de relatórios

### Arquivos Utilizados
- Arquivos de entrada para processamento
- Arquivos de saída para resultados

### Regras de Negócio
- Validação de campos obrigatórios
- Processamento condicional baseado em status
- Cálculos e totalizações

### Considerações Técnicas
- Utiliza estruturas COBOL padrão
- Implementa controle de fluxo adequado
- Gerenciamento de arquivos apropriado

### Recomendações
- Manter documentação atualizada
- Implementar tratamento de erros robusto
- Considerar otimizações de performance

---
*Análise gerada pelo Enhanced Mock Provider*
"""
                    
                    return AIResponse(
                        content=analysis_content,
                        success=True,
                        provider="enhanced_mock",
                        model="enhanced-mock-basic",
                        tokens_used=1200,
                        processing_time=1.5,
                        metadata={
                            "analysis_type": "functional",
                            "confidence": 0.85,
                            "program_name": program.name
                        }
                    )
            
            self.providers['enhanced_mock'] = SimpleMockProvider(self.config)
            self.logger.info("Fallback Enhanced Mock Provider criado")
            
        except Exception as e:
            self.logger.error(f"Erro ao criar fallback provider: {e}")
    
    def get_available_models(self) -> List[str]:
        """Retorna modelos disponíveis"""
        return list(self.providers.keys())
    
    def get_provider_status(self) -> Dict[str, str]:
        """Retorna status dos providers"""
        
        status = {}
        for name, provider in self.providers.items():
            try:
                # Tentar verificar se provider está funcionando
                status[name] = "disponível"
            except:
                status[name] = "indisponível"
        
        return status
    
    def get_rag_statistics(self) -> Dict[str, Any]:
        """Retorna estatísticas do RAG"""
        
        if self.rag_engine:
            try:
                return self.rag_engine.get_statistics()
            except:
                pass
        
        return {
            "rag_enabled": False,
            "knowledge_base_size": 0,
            "total_interactions": 0
        }
    
    def get_learning_progress(self) -> Dict[str, Any]:
        """Retorna progresso do aprendizado"""
        
        if self.learning_system:
            try:
                return self.learning_system.get_progress()
            except:
                pass
        
        return {
            "learning_enabled": False,
            "patterns_learned": 0,
            "accuracy": 0.0
        }
