"""
analyzers module
"""
