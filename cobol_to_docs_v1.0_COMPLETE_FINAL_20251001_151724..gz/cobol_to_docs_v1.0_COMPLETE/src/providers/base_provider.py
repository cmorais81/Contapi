"""
Base Provider para todos os provedores de IA
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, Optional
import logging

class BaseProvider(ABC):
    """Classe base para todos os providers"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.logger = logging.getLogger(self.__class__.__name__)
    
    @abstractmethod
    def analyze(self, request) -> Any:
        """Método abstrato para análise"""
        pass
    
    @abstractmethod
    def get_available_models(self) -> list:
        """Retorna modelos disponíveis"""
        pass
    
    def is_available(self) -> bool:
        """Verifica se o provider está disponível"""
        return True
