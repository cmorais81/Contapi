"""
LuzIA Provider - Integração Completa com Ambiente Santander
"""

import requests
import json
import logging
import time
from typing import Dict, Any, Optional

from base_provider import BaseProvider
from ..core.ai_response import AIResponse

class LuziaProvider(BaseProvider):
    """Provider para integração com LuzIA"""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.logger = logging.getLogger(__name__)
        
        luzia_config = config.get("providers", {}).get("luzia", {})
        self.client_id = luzia_config.get("client_id")
        self.client_secret = luzia_config.get("client_secret")
        self.auth_url = luzia_config.get("auth_url")
        self.api_url = luzia_config.get("api_url")
        
        self.access_token = None
        self.token_expires_at = 0
        
        self.logger.info("LuzIA Provider inicializado")
    
    def analyze(self, request) -> AIResponse:
        """Análise usando LuzIA"""
        try:
            start_time = time.time()
            
            # Garantir token válido
            if not self._ensure_valid_token():
                return self._create_error_response("Falha na autenticação")
            
            # Preparar payload
            payload = self._prepare_payload(request)
            
            # Fazer requisição
            response = self._make_api_request(payload)
            
            if response and response.get("success"):
                content = response.get("content", "")
                
                return AIResponse(
                    success=True,
                    content=content,
                    analysis_content=content,
                    model_used=request.model,
                    provider="luzia",
                    provider_used="luzia",
                    tokens_used=response.get("tokens_used", 0),
                    processing_time=time.time() - start_time,
                    metadata=response.get("metadata", {})
                )
            else:
                return self._create_error_response("Falha na análise")
                
        except Exception as e:
            self.logger.error(f"Erro na análise LuzIA: {e}")
            return self._create_error_response(str(e))
    
    def _ensure_valid_token(self) -> bool:
        """Garante token válido"""
        if time.time() >= self.token_expires_at:
            return self._authenticate()
        return True
    
    def _authenticate(self) -> bool:
        """Autentica com LuzIA"""
        try:
            payload = {
                "grant_type": "client_credentials",
                "client_id": self.client_id,
                "client_secret": self.client_secret
            }
            
            response = requests.post(self.auth_url, data=payload, timeout=30)
            
            if response.status_code == 200:
                data = response.json()
                self.access_token = data.get("access_token")
                expires_in = data.get("expires_in", 3600)
                self.token_expires_at = time.time() + expires_in - 60  # 1 min buffer
                
                self.logger.info("Autenticação LuzIA bem-sucedida")
                return True
            else:
                self.logger.error(f"Falha na autenticação: {response.status_code}")
                return False
                
        except Exception as e:
            self.logger.error(f"Erro na autenticação: {e}")
            return False
    
    def get_available_models(self):
        return ['aws-claude-3-5-sonnet', 'aws-claude-3-5-haiku', 'amazon-nova-pro']
