"""
COBOL Analysis Library - Biblioteca principal para análise COBOL
"""

import os
import sys
import logging
from typing import List, Dict, Any, Optional, Tuple
from pathlib import Path

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from core.config import load_config
from parsers.cobol_parser_original import COBOLParser, CobolProgram, CobolCopybook
from analyzers.enhanced_cobol_analyzer import EnhancedCOBOLAnalyzer
from generators.documentation_generator import DocumentationGenerator
from core.prompt_manager import PromptManager

class COBOLAnalysisLibrary:
    """Biblioteca principal para análise COBOL"""
    
    def __init__(self, config_path: str = None, output_dir: str = "output"):
        """Inicializa a biblioteca"""
        
        # Configurar logging
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        self.logger = logging.getLogger(__name__)
        
        # Carregar configuração
        self.config = load_config(config_path) if config_path else load_config()
        
        # Inicializar componentes
        self.parser = COBOLParser()
        self.analyzer = EnhancedCOBOLAnalyzer(self.config)
        self.doc_generator = DocumentationGenerator(output_dir)
        self.prompt_manager = PromptManager()
        
        # Estatísticas
        self.stats = {
            "programs_analyzed": 0,
            "successful_analyses": 0,
            "failed_analyses": 0,
            "total_tokens_used": 0,
            "total_processing_time": 0.0
        }
        
        self.logger.info("COBOL Analysis Library inicializada")
    
    def analyze_file(self, file_path: str, model: str = "enhanced_mock", 
                    analysis_strategy: str = "expert_analysis") -> Dict[str, Any]:
        """Analisa arquivo COBOL completo"""
        
        try:
            self.logger.info(f"Analisando arquivo: {file_path}")
            
            # Parse do arquivo
            programs, copybooks = self.parser.parse_file(file_path)
            
            if not programs:
                return {
                    "success": False,
                    "error": "Nenhum programa encontrado no arquivo",
                    "file_path": file_path
                }
            
            # Analisar cada programa
            results = []
            for program in programs:
                result = self.analyze_program(program, copybooks, model, analysis_strategy)
                results.append(result)
            
            # Compilar resultados
            analysis_result = {
                "success": True,
                "file_path": file_path,
                "programs_count": len(programs),
                "copybooks_count": len(copybooks),
                "results": results,
                "summary": self._generate_file_summary(results)
            }
            
            self.logger.info(f"Análise de arquivo concluída: {len(programs)} programas")
            return analysis_result
            
        except Exception as e:
            self.logger.error(f"Erro na análise do arquivo {file_path}: {e}")
            return {
                "success": False,
                "error": str(e),
                "file_path": file_path
            }
    
    def analyze_program(self, program: CobolProgram, copybooks: List[CobolCopybook] = None,
                       model: str = "enhanced_mock", analysis_strategy: str = "expert_analysis") -> Dict[str, Any]:
        """Analisa programa COBOL individual"""
        
        try:
            self.logger.info(f"Analisando programa: {program.name}")
            
            # Executar análise
            ai_response = self.analyzer.analyze_program_enhanced(
                program=program,
                copybooks=copybooks or [],
                model=model
            )
            
            if ai_response and ai_response.success:
                # Gerar documentação
                doc_path = self.doc_generator.generate_program_documentation(
                    program=program,
                    ai_response=ai_response
                )
                
                # Atualizar estatísticas
                self._update_stats(ai_response, success=True)
                
                result = {
                    "success": True,
                    "program_name": program.name,
                    "model_used": model,
                    "analysis_strategy": analysis_strategy,
                    "documentation_path": doc_path,
                    "tokens_used": getattr(ai_response, 'tokens_used', 0),
                    "processing_time": getattr(ai_response, 'processing_time', 0),
                    "provider": getattr(ai_response, 'provider', 'unknown'),
                    "metadata": getattr(ai_response, 'metadata', {})
                }
                
                self.logger.info(f"✅ Análise bem-sucedida: {program.name}")
                return result
                
            else:
                self._update_stats(None, success=False)
                return {
                    "success": False,
                    "program_name": program.name,
                    "error": "Falha na análise do programa"
                }
                
        except Exception as e:
            self.logger.error(f"Erro na análise do programa {program.name}: {e}")
            self._update_stats(None, success=False)
            return {
                "success": False,
                "program_name": program.name,
                "error": str(e)
            }
    
    def analyze_content(self, content: str, program_name: str = "UNKNOWN",
                       model: str = "enhanced_mock", analysis_strategy: str = "expert_analysis") -> Dict[str, Any]:
        """Analisa conteúdo COBOL direto"""
        
        try:
            # Criar programa a partir do conteúdo
            program = CobolProgram(name=program_name, content=content)
            
            # Analisar programa
            return self.analyze_program(program, [], model, analysis_strategy)
            
        except Exception as e:
            self.logger.error(f"Erro na análise de conteúdo: {e}")
            return {
                "success": False,
                "program_name": program_name,
                "error": str(e)
            }
    
    def batch_analyze(self, file_paths: List[str], model: str = "enhanced_mock",
                     analysis_strategy: str = "expert_analysis") -> Dict[str, Any]:
        """Análise em lote de múltiplos arquivos"""
        
        try:
            self.logger.info(f"Iniciando análise em lote: {len(file_paths)} arquivos")
            
            batch_results = []
            
            for file_path in file_paths:
                file_result = self.analyze_file(file_path, model, analysis_strategy)
                batch_results.append(file_result)
            
            # Compilar resultados do lote
            batch_summary = {
                "success": True,
                "total_files": len(file_paths),
                "successful_files": sum(1 for r in batch_results if r.get("success", False)),
                "failed_files": sum(1 for r in batch_results if not r.get("success", False)),
                "results": batch_results,
                "statistics": self.get_statistics()
            }
            
            # Gerar relatório resumo
            summary_path = self.doc_generator.generate_summary_report(batch_results)
            batch_summary["summary_report"] = summary_path
            
            self.logger.info(f"Análise em lote concluída: {len(file_paths)} arquivos")
            return batch_summary
            
        except Exception as e:
            self.logger.error(f"Erro na análise em lote: {e}")
            return {
                "success": False,
                "error": str(e),
                "total_files": len(file_paths)
            }
    
    def get_available_models(self) -> List[str]:
        """Retorna modelos disponíveis"""
        return self.analyzer.get_available_models()
    
    def get_available_strategies(self) -> List[str]:
        """Retorna estratégias de análise disponíveis"""
        return list(self.prompt_manager.list_available_prompts().keys())
    
    def get_provider_status(self) -> Dict[str, str]:
        """Retorna status dos providers"""
        return self.analyzer.get_provider_status()
    
    def get_statistics(self) -> Dict[str, Any]:
        """Retorna estatísticas da biblioteca"""
        
        stats = self.stats.copy()
        
        # Adicionar estatísticas do RAG se disponível
        rag_stats = self.analyzer.get_rag_statistics()
        if rag_stats.get("rag_enabled", False):
            stats["rag_statistics"] = rag_stats
        
        # Adicionar progresso do aprendizado se disponível
        learning_progress = self.analyzer.get_learning_progress()
        if learning_progress.get("learning_enabled", False):
            stats["learning_progress"] = learning_progress
        
        # Adicionar estatísticas de geração
        stats["documentation_stats"] = self.doc_generator.get_generation_stats()
        
        return stats
    
    def _update_stats(self, ai_response, success: bool):
        """Atualiza estatísticas"""
        
        self.stats["programs_analyzed"] += 1
        
        if success:
            self.stats["successful_analyses"] += 1
            if ai_response:
                self.stats["total_tokens_used"] += getattr(ai_response, 'tokens_used', 0)
                self.stats["total_processing_time"] += getattr(ai_response, 'processing_time', 0)
        else:
            self.stats["failed_analyses"] += 1
    
    def _generate_file_summary(self, results: List[Dict]) -> Dict[str, Any]:
        """Gera resumo da análise de arquivo"""
        
        successful = [r for r in results if r.get("success", False)]
        failed = [r for r in results if not r.get("success", False)]
        
        return {
            "total_programs": len(results),
            "successful_analyses": len(successful),
            "failed_analyses": len(failed),
            "success_rate": len(successful) / len(results) * 100 if results else 0,
            "total_tokens": sum(r.get("tokens_used", 0) for r in successful),
            "total_time": sum(r.get("processing_time", 0) for r in successful)
        }
    
    def reset_statistics(self):
        """Reseta estatísticas"""
        
        self.stats = {
            "programs_analyzed": 0,
            "successful_analyses": 0,
            "failed_analyses": 0,
            "total_tokens_used": 0,
            "total_processing_time": 0.0
        }
        
        self.logger.info("Estatísticas resetadas")

# Funções de conveniência para uso direto
def analyze_cobol_file(file_path: str, output_dir: str = "output", 
                      model: str = "enhanced_mock") -> Dict[str, Any]:
    """Função de conveniência para analisar arquivo COBOL"""
    
    library = COBOLAnalysisLibrary(output_dir=output_dir)
    return library.analyze_file(file_path, model)

def analyze_cobol_content(content: str, program_name: str = "UNKNOWN",
                         output_dir: str = "output", model: str = "enhanced_mock") -> Dict[str, Any]:
    """Função de conveniência para analisar conteúdo COBOL"""
    
    library = COBOLAnalysisLibrary(output_dir=output_dir)
    return library.analyze_content(content, program_name, model)

def batch_analyze_files(file_paths: List[str], output_dir: str = "output",
                       model: str = "enhanced_mock") -> Dict[str, Any]:
    """Função de conveniência para análise em lote"""
    
    library = COBOLAnalysisLibrary(output_dir=output_dir)
    return library.batch_analyze(file_paths, model)
