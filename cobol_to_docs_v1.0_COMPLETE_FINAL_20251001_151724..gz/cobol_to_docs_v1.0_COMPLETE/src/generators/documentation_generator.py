"""
Documentation Generator - Gerador de documentação funcional
"""

import os
import sys
import json
import logging
from datetime import datetime
from typing import Dict, Any, Optional

# Adicionar src ao path
current_dir = os.path.dirname(os.path.abspath(__file__))
src_dir = os.path.join(current_dir, "..")
sys.path.insert(0, src_dir)

from parsers.cobol_parser_original import CobolProgram
from core.ai_response import AIResponse

class DocumentationGenerator:
    """Gerador de documentação para análises COBOL"""
    
    def __init__(self, output_dir: str = "output"):
        self.output_dir = output_dir
        self.logger = logging.getLogger(__name__)
        
        # Criar diretórios necessários
        os.makedirs(output_dir, exist_ok=True)
        os.makedirs(os.path.join(output_dir, "ai_responses"), exist_ok=True)
        os.makedirs(os.path.join(output_dir, "ai_requests"), exist_ok=True)
        
        self.stats = {
            "documents_generated": 0,
            "total_size": 0,
            "generation_time": 0.0
        }
        
        self.logger.info(f"Documentation Generator inicializado: {output_dir}")
    
    def generate_program_documentation(self, program: CobolProgram, ai_response: AIResponse) -> str:
        """Gera documentação para um programa"""
        
        try:
            start_time = datetime.now()
            
            # Nome do arquivo
            doc_filename = f"{program.name}_analise_funcional.md"
            doc_path = os.path.join(self.output_dir, doc_filename)
            
            # Gerar conteúdo
            content = self._generate_markdown_content(program, ai_response)
            
            # Salvar arquivo
            with open(doc_path, 'w', encoding='utf-8') as f:
                f.write(content)
            
            # Salvar JSONs de auditoria
            self._save_ai_response_json(program, ai_response)
            self._save_ai_request_json(program, ai_response)
            
            # Atualizar estatísticas
            end_time = datetime.now()
            processing_time = (end_time - start_time).total_seconds()
            
            self.stats["documents_generated"] += 1
            self.stats["total_size"] += len(content)
            self.stats["generation_time"] += processing_time
            
            self.logger.info(f"Documentação gerada: {doc_path}")
            return doc_path
            
        except Exception as e:
            self.logger.error(f"Erro ao gerar documentação: {e}")
            return ""
    
    def _generate_markdown_content(self, program: CobolProgram, ai_response: AIResponse) -> str:
        """Gera conteúdo markdown"""
        
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        content = f"""# Análise Funcional - {program.name}

**Data da Análise**: {timestamp}  
**Provider**: {getattr(ai_response, 'provider', 'N/A')}  
**Modelo**: {getattr(ai_response, 'model', 'N/A')}  
**Tokens Utilizados**: {getattr(ai_response, 'tokens_used', 0)}  
**Tempo de Processamento**: {getattr(ai_response, 'processing_time', 0):.2f}s  

---

{ai_response.content}

---

## Informações Técnicas

### Estatísticas do Programa
- **Nome**: {program.name}
- **Linhas de Código**: {len(program.content.split(chr(10)))}
- **Tamanho**: {len(program.content)} caracteres

### Metadados da Análise
- **Sucesso**: {'✅' if ai_response.success else '❌'}
- **Timestamp**: {getattr(ai_response, 'timestamp', 'N/A')}
- **Confiança**: {getattr(ai_response, 'metadata', {}).get('confidence', 'N/A')}

### Informações de Processamento
- **Provider Utilizado**: {getattr(ai_response, 'provider', 'N/A')}
- **Modelo de IA**: {getattr(ai_response, 'model', 'N/A')}
- **Estratégia de Análise**: {getattr(ai_response, 'metadata', {}).get('analysis_strategy', 'N/A')}

---

*Documentação gerada automaticamente pelo COBOL to Docs v1.0*
"""
        
        return content
    
    def _save_ai_response_json(self, program: CobolProgram, ai_response: AIResponse):
        """Salva resposta da IA em JSON"""
        
        try:
            response_data = {
                "program_name": program.name,
                "timestamp": datetime.now().isoformat(),
                "success": ai_response.success,
                "content": ai_response.content,
                "provider": getattr(ai_response, 'provider', 'N/A'),
                "model": getattr(ai_response, 'model', 'N/A'),
                "tokens_used": getattr(ai_response, 'tokens_used', 0),
                "processing_time": getattr(ai_response, 'processing_time', 0),
                "metadata": getattr(ai_response, 'metadata', {})
            }
            
            json_path = os.path.join(self.output_dir, "ai_responses", f"{program.name}_response.json")
            
            with open(json_path, 'w', encoding='utf-8') as f:
                json.dump(response_data, f, indent=2, ensure_ascii=False)
            
            self.logger.debug(f"AI Response JSON salvo: {json_path}")
            
        except Exception as e:
            self.logger.error(f"Erro ao salvar AI Response JSON: {e}")
    
    def _save_ai_request_json(self, program: CobolProgram, ai_response: AIResponse):
        """Salva request da IA em JSON"""
        
        try:
            request_data = {
                "program_name": program.name,
                "timestamp": datetime.now().isoformat(),
                "program_content": program.content[:1000] + "..." if len(program.content) > 1000 else program.content,
                "program_size": len(program.content),
                "provider": getattr(ai_response, 'provider', 'N/A'),
                "model": getattr(ai_response, 'model', 'N/A'),
                "analysis_strategy": getattr(ai_response, 'metadata', {}).get('analysis_strategy', 'N/A')
            }
            
            json_path = os.path.join(self.output_dir, "ai_requests", f"{program.name}_request.json")
            
            with open(json_path, 'w', encoding='utf-8') as f:
                json.dump(request_data, f, indent=2, ensure_ascii=False)
            
            self.logger.debug(f"AI Request JSON salvo: {json_path}")
            
        except Exception as e:
            self.logger.error(f"Erro ao salvar AI Request JSON: {e}")
    
    def generate_summary_report(self, batch_results: list) -> str:
        """Gera relatório resumo de análise em lote"""
        
        try:
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            
            # Calcular estatísticas
            total_files = len(batch_results)
            successful = sum(1 for r in batch_results if r.get("success", False))
            failed = total_files - successful
            
            # Gerar conteúdo
            content = f"""# Relatório Resumo - Análise em Lote

**Data**: {timestamp}  
**Total de Arquivos**: {total_files}  
**Sucessos**: {successful}  
**Falhas**: {failed}  
**Taxa de Sucesso**: {(successful/total_files*100):.1f}%  

## Resultados por Arquivo

"""
            
            for i, result in enumerate(batch_results, 1):
                status = "✅" if result.get("success", False) else "❌"
                file_path = result.get("file_path", "N/A")
                content += f"{i}. {status} {file_path}\n"
                
                if result.get("success", False):
                    programs = result.get("results", [])
                    for prog in programs:
                        if prog.get("success", False):
                            content += f"   - ✅ {prog.get('program_name', 'N/A')}\n"
                        else:
                            content += f"   - ❌ {prog.get('program_name', 'N/A')}\n"
            
            content += f"""
## Estatísticas Gerais

- **Documentos Gerados**: {self.stats['documents_generated']}
- **Tamanho Total**: {self.stats['total_size']} caracteres
- **Tempo de Geração**: {self.stats['generation_time']:.2f}s

---

*Relatório gerado automaticamente pelo COBOL to Docs v1.0*
"""
            
            # Salvar relatório
            report_path = os.path.join(self.output_dir, f"relatorio_resumo_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md")
            
            with open(report_path, 'w', encoding='utf-8') as f:
                f.write(content)
            
            self.logger.info(f"Relatório resumo gerado: {report_path}")
            return report_path
            
        except Exception as e:
            self.logger.error(f"Erro ao gerar relatório resumo: {e}")
            return ""
    
    def get_generation_stats(self) -> Dict[str, Any]:
        """Retorna estatísticas de geração"""
        return self.stats.copy()
