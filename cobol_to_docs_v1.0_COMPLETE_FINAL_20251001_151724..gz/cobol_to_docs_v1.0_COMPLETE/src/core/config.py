"""
Gerenciador de configuração do sistema
"""

import yaml
import os
import logging
from typing import Dict, Any

def load_config(config_path: str = "config/config.yaml") -> Dict[str, Any]:
    """Carrega configuração do sistema"""
    
    try:
        if os.path.exists(config_path):
            with open(config_path, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f)
            
            logging.info(f"Configuração carregada: {config_path}")
            return config
        else:
            logging.warning(f"Arquivo de configuração não encontrado: {config_path}")
            return get_default_config()
            
    except Exception as e:
        logging.error(f"Erro ao carregar configuração: {e}")
        return get_default_config()

def get_default_config() -> Dict[str, Any]:
    """Retorna configuração padrão"""
    
    return {
        "providers": {
            "enhanced_mock": {"enabled": True},
            "luzia": {"enabled": False},
            "github_copilot": {"enabled": False}
        },
        "primary_providers": "enhanced_mock",
        "fallback_providers": ["enhanced_mock"],
        "analysis": {
            "include_metadata": True,
            "include_business_rules": True,
            "include_technical_details": True,
            "use_rag": True,
            "enable_learning": True
        },
        "rag": {
            "enabled": True,
            "knowledge_base_path": "data/knowledge_base",
            "similarity_threshold": 0.1,
            "max_retrieved_docs": 5
        },
        "learning": {
            "enabled": True,
            "auto_learn": True,
            "feedback_integration": True
        },
        "logging": {
            "level": "INFO",
            "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        }
    }
