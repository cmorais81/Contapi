"""
Classe AnalysisRequest para requisições de análise
"""

from dataclasses import dataclass
from typing import Optional, Dict, Any, List

@dataclass
class AnalysisRequest:
    """Requisição de análise de programa COBOL"""
    program_name: str = ""
    program_content: str = ""
    model: str = "enhanced_mock"
    strategy: str = "expert_analysis"
    prompt: str = ""
    analysis_type: str = "individual"
    context: Optional[Dict[str, Any]] = None
    copybooks: Optional[List] = None
    books_content: str = ""
    cobol_content: str = ""
    temperature: float = 0.1
    max_tokens: int = 4000
    use_rag: bool = True
    learn_from_result: bool = True
    config: Optional[Dict[str, Any]] = None
    rag_context: Optional[List] = None
    
    # Aceitar program como parâmetro para compatibilidade
    program: Optional[Any] = None
    
    def __post_init__(self):
        # Se program foi passado, extrair informações
        if self.program:
            self.program_name = getattr(self.program, 'name', self.program_name)
            self.program_content = getattr(self.program, 'content', self.program_content)
            self.cobol_content = self.program_content
        
        if not self.cobol_content and self.program_content:
            self.cobol_content = self.program_content
        if self.context is None:
            self.context = {}
        if self.copybooks is None:
            self.copybooks = []
        if self.config is None:
            self.config = {}
        if self.rag_context is None:
            self.rag_context = []
