"""
core module
"""
