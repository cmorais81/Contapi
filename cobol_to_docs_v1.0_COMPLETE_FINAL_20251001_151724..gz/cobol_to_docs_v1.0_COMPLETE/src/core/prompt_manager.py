"""
Prompt Manager - Gerenciador de Prompts Funcionais
"""

import yaml
import os
import logging
from typing import Dict, Any, Optional
from string import Template

class PromptManager:
    """Gerenciador de prompts com templates funcionais"""
    
    def __init__(self, prompts_path: str = "data/prompts"):
        self.prompts_path = prompts_path
        self.logger = logging.getLogger(__name__)
        
        # Cache de prompts carregados
        self.prompt_cache = {}
        
        # Carregar prompts disponíveis
        self._load_available_prompts()
        
        self.logger.info("Prompt Manager inicializado")
    
    def _load_available_prompts(self):
        """Carrega prompts disponíveis"""
        
        if not os.path.exists(self.prompts_path):
            self.logger.warning(f"Diretório de prompts não encontrado: {self.prompts_path}")
            return
        
        for filename in os.listdir(self.prompts_path):
            if filename.endswith('.yaml') or filename.endswith('.yml'):
                prompt_name = filename.replace('.yaml', '').replace('.yml', '')
                
                try:
                    prompt_data = self._load_prompt_file(filename)
                    if prompt_data:
                        self.prompt_cache[prompt_name] = prompt_data
                        self.logger.info(f"Prompt carregado: {prompt_name}")
                        
                except Exception as e:
                    self.logger.error(f"Erro ao carregar prompt {filename}: {e}")
    
    def _load_prompt_file(self, filename: str) -> Optional[Dict]:
        """Carrega arquivo de prompt"""
        
        filepath = os.path.join(self.prompts_path, filename)
        
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f)
        except Exception as e:
            self.logger.error(f"Erro ao ler {filepath}: {e}")
            return None
    
    def get_prompt(self, prompt_name: str, context: Dict[str, Any] = None) -> Dict[str, str]:
        """Obtém prompt formatado"""
        
        if prompt_name not in self.prompt_cache:
            self.logger.error(f"Prompt não encontrado: {prompt_name}")
            return self._get_default_prompt()
        
        prompt_data = self.prompt_cache[prompt_name]
        context = context or {}
        
        try:
            # Formatar system prompt
            system_prompt = prompt_data.get("system_prompt", "")
            
            # Formatar user prompt
            user_template = prompt_data.get("user_prompt_template", "")
            user_prompt = self._format_template(user_template, context)
            
            return {
                "system_prompt": system_prompt,
                "user_prompt": user_prompt,
                "parameters": prompt_data.get("parameters", {}),
                "metadata": {
                    "prompt_name": prompt_name,
                    "version": prompt_data.get("version", "1.0"),
                    "description": prompt_data.get("description", "")
                }
            }
            
        except Exception as e:
            self.logger.error(f"Erro ao formatar prompt {prompt_name}: {e}")
            return self._get_default_prompt()
    
    def _format_template(self, template: str, context: Dict[str, Any]) -> str:
        """Formata template com contexto"""
        
        try:
            # Preparar contexto com valores padrão
            safe_context = self._prepare_safe_context(context)
            
            # Usar Template para substituição segura
            template_obj = Template(template)
            return template_obj.safe_substitute(safe_context)
            
        except Exception as e:
            self.logger.error(f"Erro na formatação do template: {e}")
            return template
    
    def _prepare_safe_context(self, context: Dict[str, Any]) -> Dict[str, str]:
        """Prepara contexto seguro para substituição"""
        
        safe_context = {}
        
        # Valores padrão
        defaults = {
            "program_name": "PROGRAMA_DESCONHECIDO",
            "program_size": "0",
            "program_content": "",
            "copybooks_count": "0",
            "copybooks_section": "",
            "rag_knowledge_section": "",
            "rag_patterns": "",
            "rag_business_rules": "",
            "rag_similar_examples": "",
            "analysis_context": ""
        }
        
        # Aplicar valores do contexto
        for key, default_value in defaults.items():
            value = context.get(key, default_value)
            
            # Converter para string se necessário
            if not isinstance(value, str):
                value = str(value)
            
            safe_context[key] = value
        
        # Processar seções especiais
        safe_context = self._process_special_sections(safe_context, context)
        
        return safe_context
    
    def _process_special_sections(self, safe_context: Dict[str, str], 
                                context: Dict[str, Any]) -> Dict[str, str]:
        """Processa seções especiais do contexto"""
        
        # Processar copybooks
        copybooks = context.get("copybooks", [])
        if copybooks:
            copybooks_section = "\nCOPYBOOKS INCLUÍDOS:\n"
            for i, copybook in enumerate(copybooks[:5], 1):  # Máximo 5
                name = getattr(copybook, 'name', f'COPYBOOK_{i}')
                content = getattr(copybook, 'content', '')[:200]  # Primeiros 200 chars
                copybooks_section += f"\n{i}. {name}:\n```cobol\n{content}...\n```\n"
            safe_context["copybooks_section"] = copybooks_section
        
        # Processar conhecimento RAG
        rag_knowledge = context.get("rag_knowledge", {})
        if rag_knowledge and not rag_knowledge.get("error"):
            rag_section = "\nCONHECIMENTO RELEVANTE DA BASE RAG:\n"
            
            # Padrões
            patterns = rag_knowledge.get("patterns", [])
            if patterns:
                rag_section += "\nPADRÕES IDENTIFICADOS:\n"
                for pattern in patterns[:3]:
                    rag_section += f"- {pattern.get('description', 'N/A')}\n"
            
            # Regras de negócio
            rules = rag_knowledge.get("business_rules", [])
            if rules:
                rag_section += "\nREGRAS DE NEGÓCIO CONHECIDAS:\n"
                for rule in rules[:3]:
                    rag_section += f"- {rule.get('description', 'N/A')}\n"
            
            safe_context["rag_knowledge_section"] = rag_section
        
        return safe_context
    
    def _get_default_prompt(self) -> Dict[str, str]:
        """Retorna prompt padrão em caso de erro"""
        
        return {
            "system_prompt": "Você é um analista de sistemas COBOL especializado.",
            "user_prompt": "Analise o programa COBOL fornecido e forneça uma análise técnica detalhada.",
            "parameters": {"temperature": 0.1, "max_tokens": 4096},
            "metadata": {"prompt_name": "default", "version": "1.0", "description": "Prompt padrão"}
        }
    
    def list_available_prompts(self) -> Dict[str, Dict]:
        """Lista prompts disponíveis"""
        
        available = {}
        
        for name, data in self.prompt_cache.items():
            available[name] = {
                "description": data.get("description", ""),
                "version": data.get("version", "1.0"),
                "parameters": data.get("parameters", {})
            }
        
        return available
    
    def validate_prompt(self, prompt_name: str) -> Dict[str, Any]:
        """Valida prompt"""
        
        if prompt_name not in self.prompt_cache:
            return {"valid": False, "error": "Prompt não encontrado"}
        
        prompt_data = self.prompt_cache[prompt_name]
        
        # Verificações básicas
        required_fields = ["system_prompt", "user_prompt_template"]
        missing_fields = [field for field in required_fields if not prompt_data.get(field)]
        
        if missing_fields:
            return {
                "valid": False, 
                "error": f"Campos obrigatórios ausentes: {missing_fields}"
            }
        
        return {"valid": True, "prompt_data": prompt_data}
    
    def reload_prompts(self):
        """Recarrega prompts do disco"""
        
        self.prompt_cache.clear()
        self._load_available_prompts()
        self.logger.info("Prompts recarregados")
