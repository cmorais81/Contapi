"""
RAG Engine - Sistema de Recuperação e Geração Aumentada
"""

import json
import logging
import os
from typing import Dict, List, Any, Optional
from datetime import datetime
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

class RAGEngine:
    """Sistema RAG para análise de COBOL"""
    
    def __init__(self, knowledge_base_path: str = "data/knowledge_base"):
        self.knowledge_base_path = knowledge_base_path
        self.logger = logging.getLogger(__name__)
        
        # Inicializar componentes
        self.vectorizer = TfidfVectorizer(max_features=1000, stop_words='english')
        self.knowledge_base = self._load_knowledge_base()
        self.document_vectors = None
        
        self._initialize_vectors()
        self.logger.info("RAG Engine inicializado")
    
    def _load_knowledge_base(self) -> Dict:
        """Carrega base de conhecimento"""
        kb_file = os.path.join(self.knowledge_base_path, "cobol_knowledge.json")
        
        if os.path.exists(kb_file):
            with open(kb_file, 'r') as f:
                return json.load(f)
        
        # Base inicial
        return {
            "cobol_patterns": [],
            "business_rules": [],
            "cadoc_knowledge": [],
            "learned_examples": [],
            "best_practices": []
        }
    
    def retrieve_relevant_knowledge(self, query: str, top_k: int = 5) -> List[Dict]:
        """Recupera conhecimento relevante"""
        try:
            # Vetorizar query
            query_vector = self.vectorizer.transform([query])
            
            # Calcular similaridades
            similarities = cosine_similarity(query_vector, self.document_vectors)[0]
            
            # Obter top-k mais similares
            top_indices = np.argsort(similarities)[-top_k:][::-1]
            
            relevant_docs = []
            for idx in top_indices:
                if similarities[idx] > 0.1:  # Threshold mínimo
                    relevant_docs.append({
                        "content": self._get_document_by_index(idx),
                        "similarity": float(similarities[idx]),
                        "index": int(idx)
                    })
            
            return relevant_docs
            
        except Exception as e:
            self.logger.error(f"Erro na recuperação: {e}")
            return []
    
    def add_knowledge(self, content: str, category: str, metadata: Dict = None):
        """Adiciona novo conhecimento à base"""
        
        knowledge_item = {
            "content": content,
            "category": category,
            "timestamp": datetime.now().isoformat(),
            "metadata": metadata or {}
        }
        
        # Adicionar à categoria apropriada
        if category not in self.knowledge_base:
            self.knowledge_base[category] = []
        
        self.knowledge_base[category].append(knowledge_item)
        
        # Salvar base atualizada
        self._save_knowledge_base()
        
        # Atualizar vetores
        self._initialize_vectors()
        
        self.logger.info(f"Conhecimento adicionado: {category}")
    
    def learn_from_analysis(self, program_content: str, analysis_result: str, feedback: Dict = None):
        """Aprende com análises realizadas"""
        
        learning_item = {
            "program_snippet": program_content[:500],  # Primeiros 500 chars
            "analysis_quality": analysis_result,
            "feedback": feedback or {},
            "patterns_identified": self._extract_patterns(program_content),
            "timestamp": datetime.now().isoformat()
        }
        
        self.add_knowledge(
            content=f"Programa: {program_content[:200]}... Análise: {analysis_result[:200]}...",
            category="learned_examples",
            metadata=learning_item
        )
    
    def _initialize_vectors(self):
        """Inicializa vetores para busca"""
        try:
            # Coletar todos os documentos
            documents = []
            for category, items in self.knowledge_base.items():
                for item in items:
                    documents.append(item.get("content", ""))
            
            if documents:
                self.document_vectors = self.vectorizer.fit_transform(documents)
                self.logger.info(f"Vetores inicializados: {len(documents)} documentos")
            
        except Exception as e:
            self.logger.error(f"Erro na inicialização de vetores: {e}")
    
    def _save_knowledge_base(self):
        """Salva base de conhecimento"""
        try:
            os.makedirs(self.knowledge_base_path, exist_ok=True)
            kb_file = os.path.join(self.knowledge_base_path, "cobol_knowledge.json")
            
            with open(kb_file, 'w') as f:
                json.dump(self.knowledge_base, f, indent=2, default=str)
                
        except Exception as e:
            self.logger.error(f"Erro ao salvar base: {e}")
    
    def get_knowledge_stats(self) -> Dict:
        """Retorna estatísticas da base de conhecimento"""
        stats = {}
        total_items = 0
        
        for category, items in self.knowledge_base.items():
            count = len(items)
            stats[category] = count
            total_items += count
        
        stats["total"] = total_items
        return stats
