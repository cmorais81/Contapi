"""
Advanced RAG Engine - Sistema de Recuperação e Geração Aumentada Avançado
"""

import json
import logging
import os
import pickle
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime
import numpy as np
from collections import defaultdict

try:
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.metrics.pairwise import cosine_similarity
    from sklearn.cluster import KMeans
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False
    logging.warning("scikit-learn não disponível. Usando implementação básica.")

class AdvancedRAGEngine:
    """Sistema RAG avançado com aprendizado automático"""
    
    def __init__(self, knowledge_base_path: str = "data/knowledge_base"):
        self.knowledge_base_path = knowledge_base_path
        self.logger = logging.getLogger(__name__)
        
        # Garantir diretório
        os.makedirs(knowledge_base_path, exist_ok=True)
        
        # Inicializar componentes
        self.vectorizer = None
        self.document_vectors = None
        self.knowledge_base = self._load_knowledge_base()
        self.learning_history = []
        self.pattern_clusters = {}
        
        if SKLEARN_AVAILABLE:
            self.vectorizer = TfidfVectorizer(
                max_features=2000,
                stop_words='english',
                ngram_range=(1, 3),
                min_df=1,
                max_df=0.95
            )
        
        self._initialize_system()
        self.logger.info("Advanced RAG Engine inicializado")
    
    def _load_knowledge_base(self) -> Dict:
        """Carrega base de conhecimento completa"""
        
        kb_file = os.path.join(self.knowledge_base_path, "advanced_knowledge.json")
        
        if os.path.exists(kb_file):
            try:
                with open(kb_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception as e:
                self.logger.error(f"Erro ao carregar base: {e}")
        
        # Base inicial avançada
        return {
            "cobol_patterns": {
                "file_operations": [],
                "data_structures": [],
                "control_flow": [],
                "business_logic": [],
                "error_handling": []
            },
            "business_rules": {
                "banking": [],
                "cadoc": [],
                "regulatory": [],
                "validation": []
            },
            "learned_examples": [],
            "analysis_feedback": [],
            "pattern_clusters": {},
            "quality_metrics": {
                "total_analyses": 0,
                "successful_analyses": 0,
                "learning_iterations": 0,
                "pattern_discoveries": 0
            }
        }
    
    def retrieve_enhanced_knowledge(self, query: str, context: Dict = None) -> Dict:
        """Recuperação avançada de conhecimento"""
        
        try:
            # Análise multi-dimensional da query
            query_analysis = self._analyze_query(query)
            
            # Recuperação por similaridade semântica
            semantic_results = self._semantic_retrieval(query, query_analysis)
            
            # Recuperação por padrões
            pattern_results = self._pattern_based_retrieval(query, query_analysis)
            
            # Recuperação por contexto
            context_results = self._context_based_retrieval(query, context or {})
            
            # Combinar e ranquear resultados
            combined_results = self._combine_and_rank_results(
                semantic_results, pattern_results, context_results
            )
            
            # Gerar conhecimento aumentado
            enhanced_knowledge = self._generate_enhanced_knowledge(
                query, combined_results, query_analysis
            )
            
            return enhanced_knowledge
            
        except Exception as e:
            self.logger.error(f"Erro na recuperação avançada: {e}")
            return {"error": str(e), "fallback_knowledge": self._get_fallback_knowledge()}
    
    def _analyze_query(self, query: str) -> Dict:
        """Análise avançada da query"""
        
        analysis = {
            "length": len(query),
            "complexity": self._calculate_complexity(query),
            "domain_indicators": self._identify_domain_indicators(query),
            "technical_level": self._assess_technical_level(query),
            "intent": self._classify_intent(query),
            "entities": self._extract_entities(query)
        }
        
        return analysis
    
    def _semantic_retrieval(self, query: str, analysis: Dict) -> List[Dict]:
        """Recuperação por similaridade semântica"""
        
        if not SKLEARN_AVAILABLE or self.document_vectors is None:
            return []
        
        try:
            # Vetorizar query
            query_vector = self.vectorizer.transform([query])
            
            # Calcular similaridades
            similarities = cosine_similarity(query_vector, self.document_vectors)[0]
            
            # Obter resultados relevantes
            threshold = 0.1
            relevant_indices = np.where(similarities > threshold)[0]
            
            results = []
            for idx in relevant_indices:
                similarity_score = float(similarities[idx])
                document = self._get_document_by_index(idx)
                
                results.append({
                    "content": document,
                    "similarity": similarity_score,
                    "retrieval_method": "semantic",
                    "confidence": similarity_score
                })
            
            # Ordenar por similaridade
            results.sort(key=lambda x: x["similarity"], reverse=True)
            
            return results[:10]  # Top 10
            
        except Exception as e:
            self.logger.error(f"Erro na recuperação semântica: {e}")
            return []
    
    def _pattern_based_retrieval(self, query: str, analysis: Dict) -> List[Dict]:
        """Recuperação baseada em padrões"""
        
        results = []
        
        # Buscar padrões COBOL
        for category, patterns in self.knowledge_base["cobol_patterns"].items():
            for pattern in patterns:
                if self._pattern_matches_query(pattern, query, analysis):
                    results.append({
                        "content": pattern,
                        "category": category,
                        "retrieval_method": "pattern",
                        "confidence": self._calculate_pattern_confidence(pattern, query)
                    })
        
        # Buscar regras de negócio
        for domain, rules in self.knowledge_base["business_rules"].items():
            for rule in rules:
                if self._rule_matches_query(rule, query, analysis):
                    results.append({
                        "content": rule,
                        "domain": domain,
                        "retrieval_method": "business_rule",
                        "confidence": self._calculate_rule_confidence(rule, query)
                    })
        
        return results
    
    def learn_from_interaction(self, query: str, response: str, feedback: Dict = None):
        """Aprendizado a partir de interações"""
        
        learning_item = {
            "timestamp": datetime.now().isoformat(),
            "query": query,
            "response": response,
            "feedback": feedback or {},
            "query_analysis": self._analyze_query(query),
            "response_quality": self._assess_response_quality(response, feedback),
            "extracted_patterns": self._extract_patterns_from_interaction(query, response)
        }
        
        # Adicionar ao histórico de aprendizado
        self.learning_history.append(learning_item)
        
        # Atualizar base de conhecimento
        self._update_knowledge_from_learning(learning_item)
        
        # Descobrir novos padrões
        self._discover_new_patterns()
        
        # Atualizar métricas
        self._update_quality_metrics(learning_item)
        
        # Salvar conhecimento atualizado
        self._save_knowledge_base()
        
        self.logger.info("Aprendizado registrado e base atualizada")
    
    def _discover_new_patterns(self):
        """Descobre novos padrões automaticamente"""
        
        if len(self.learning_history) < 5:  # Mínimo para descoberta
            return
        
        # Agrupar interações similares
        recent_interactions = self.learning_history[-20:]  # Últimas 20
        
        # Extrair padrões comuns
        common_patterns = self._find_common_patterns(recent_interactions)
        
        # Validar e adicionar novos padrões
        for pattern in common_patterns:
            if self._validate_new_pattern(pattern):
                self._add_discovered_pattern(pattern)
                self.knowledge_base["quality_metrics"]["pattern_discoveries"] += 1
    
    def _find_common_patterns(self, interactions: List[Dict]) -> List[Dict]:
        """Encontra padrões comuns nas interações"""
        
        patterns = []
        
        # Agrupar por características similares
        query_groups = defaultdict(list)
        
        for interaction in interactions:
            # Agrupar por indicadores de domínio
            domain_key = tuple(sorted(interaction["query_analysis"]["domain_indicators"]))
            query_groups[domain_key].append(interaction)
        
        # Analisar cada grupo
        for domain_key, group in query_groups.items():
            if len(group) >= 3:  # Mínimo para padrão
                pattern = self._extract_group_pattern(group)
                if pattern:
                    patterns.append(pattern)
        
        return patterns
    
    def get_learning_statistics(self) -> Dict:
        """Retorna estatísticas de aprendizado"""
        
        stats = {
            "total_interactions": len(self.learning_history),
            "knowledge_base_size": self._calculate_kb_size(),
            "pattern_categories": len(self.knowledge_base["cobol_patterns"]),
            "business_rule_domains": len(self.knowledge_base["business_rules"]),
            "quality_metrics": self.knowledge_base["quality_metrics"],
            "recent_discoveries": self._get_recent_discoveries(),
            "learning_trends": self._analyze_learning_trends()
        }
        
        return stats
    
    def _save_knowledge_base(self):
        """Salva base de conhecimento atualizada"""
        
        try:
            # Salvar base principal
            kb_file = os.path.join(self.knowledge_base_path, "advanced_knowledge.json")
            with open(kb_file, 'w', encoding='utf-8') as f:
                json.dump(self.knowledge_base, f, indent=2, default=str, ensure_ascii=False)
            
            # Salvar histórico de aprendizado
            history_file = os.path.join(self.knowledge_base_path, "learning_history.json")
            with open(history_file, 'w', encoding='utf-8') as f:
                json.dump(self.learning_history, f, indent=2, default=str, ensure_ascii=False)
            
            # Salvar vetores se disponível
            if SKLEARN_AVAILABLE and self.document_vectors is not None:
                vectors_file = os.path.join(self.knowledge_base_path, "document_vectors.pkl")
                with open(vectors_file, 'wb') as f:
                    pickle.dump({
                        "vectorizer": self.vectorizer,
                        "vectors": self.document_vectors
                    }, f)
            
            self.logger.info("Base de conhecimento salva")
            
        except Exception as e:
            self.logger.error(f"Erro ao salvar base: {e}")
    
    def _initialize_system(self):
        """Inicializa sistema RAG"""
        
        try:
            # Carregar vetores salvos se existirem
            vectors_file = os.path.join(self.knowledge_base_path, "document_vectors.pkl")
            if os.path.exists(vectors_file) and SKLEARN_AVAILABLE:
                with open(vectors_file, 'rb') as f:
                    data = pickle.load(f)
                    self.vectorizer = data["vectorizer"]
                    self.document_vectors = data["vectors"]
            else:
                # Inicializar vetores
                self._initialize_vectors()
            
            # Carregar histórico de aprendizado
            history_file = os.path.join(self.knowledge_base_path, "learning_history.json")
            if os.path.exists(history_file):
                with open(history_file, 'r', encoding='utf-8') as f:
                    self.learning_history = json.load(f)
            
            self.logger.info("Sistema RAG inicializado com sucesso")
            
        except Exception as e:
            self.logger.error(f"Erro na inicialização: {e}")
    
    def _initialize_vectors(self):
        """Inicializa vetores para busca semântica"""
        
        if not SKLEARN_AVAILABLE:
            return
        
        try:
            # Coletar documentos da base
            documents = []
            
            # Adicionar padrões COBOL
            for category, patterns in self.knowledge_base["cobol_patterns"].items():
                for pattern in patterns:
                    doc_text = f"{category}: {pattern.get('description', '')} {pattern.get('examples', [])}"
                    documents.append(doc_text)
            
            # Adicionar regras de negócio
            for domain, rules in self.knowledge_base["business_rules"].items():
                for rule in rules:
                    doc_text = f"{domain}: {rule.get('description', '')} {rule.get('pattern', '')}"
                    documents.append(doc_text)
            
            # Adicionar exemplos aprendidos
            for example in self.knowledge_base["learned_examples"]:
                doc_text = f"Exemplo: {example.get('content', '')}"
                documents.append(doc_text)
            
            if documents:
                self.document_vectors = self.vectorizer.fit_transform(documents)
                self.logger.info(f"Vetores inicializados: {len(documents)} documentos")
            
        except Exception as e:
            self.logger.error(f"Erro na inicialização de vetores: {e}")
