"""
Learning System - Sistema de Aprendizado Automático
"""

import json
import logging
import os
from typing import Dict, List, Any, Tuple
from datetime import datetime, timedelta
from collections import defaultdict, Counter
import re

class LearningSystem:
    """Sistema de aprendizado automático para análise COBOL"""
    
    def __init__(self, knowledge_base_path: str = "data/knowledge_base"):
        self.knowledge_base_path = knowledge_base_path
        self.logger = logging.getLogger(__name__)
        
        # Configurações de aprendizado
        self.learning_config = {
            "min_pattern_frequency": 3,
            "confidence_threshold": 0.7,
            "max_learning_iterations": 100,
            "pattern_validation_threshold": 0.8,
            "feedback_weight": 0.3
        }
        
        # Métricas de aprendizado
        self.learning_metrics = {
            "patterns_learned": 0,
            "successful_predictions": 0,
            "total_predictions": 0,
            "feedback_incorporated": 0,
            "knowledge_base_growth": 0
        }
        
        self.logger.info("Learning System inicializado")
    
    def learn_from_analysis_result(self, program_content: str, analysis_result: str, 
                                 metadata: Dict = None, feedback: Dict = None) -> Dict:
        """Aprende a partir de resultado de análise"""
        
        learning_session = {
            "timestamp": datetime.now().isoformat(),
            "program_content": program_content[:1000],  # Primeiros 1000 chars
            "analysis_result": analysis_result,
            "metadata": metadata or {},
            "feedback": feedback or {},
            "extracted_insights": {}
        }
        
        # Extrair insights do programa
        program_insights = self._extract_program_insights(program_content)
        learning_session["extracted_insights"]["program"] = program_insights
        
        # Extrair insights da análise
        analysis_insights = self._extract_analysis_insights(analysis_result)
        learning_session["extracted_insights"]["analysis"] = analysis_insights
        
        # Correlacionar programa e análise
        correlations = self._correlate_program_analysis(program_insights, analysis_insights)
        learning_session["extracted_insights"]["correlations"] = correlations
        
        # Identificar novos padrões
        new_patterns = self._identify_new_patterns(program_content, analysis_result, correlations)
        learning_session["new_patterns"] = new_patterns
        
        # Validar e incorporar padrões
        validated_patterns = self._validate_and_incorporate_patterns(new_patterns)
        learning_session["validated_patterns"] = validated_patterns
        
        # Incorporar feedback se disponível
        if feedback:
            feedback_insights = self._incorporate_feedback(feedback, learning_session)
            learning_session["feedback_insights"] = feedback_insights
        
        # Atualizar métricas
        self._update_learning_metrics(learning_session)
        
        # Salvar sessão de aprendizado
        self._save_learning_session(learning_session)
        
        return {
            "learning_successful": True,
            "patterns_discovered": len(new_patterns),
            "patterns_validated": len(validated_patterns),
            "insights_extracted": len(program_insights) + len(analysis_insights),
            "session_id": learning_session["timestamp"]
        }
    
    def _extract_program_insights(self, program_content: str) -> List[Dict]:
        """Extrai insights do programa COBOL"""
        
        insights = []
        lines = program_content.split('\n')
        
        # Padrões estruturais
        structural_patterns = self._identify_structural_patterns(lines)
        insights.extend(structural_patterns)
        
        # Padrões de dados
        data_patterns = self._identify_data_patterns(lines)
        insights.extend(data_patterns)
        
        # Padrões de controle
        control_patterns = self._identify_control_patterns(lines)
        insights.extend(control_patterns)
        
        # Padrões de negócio
        business_patterns = self._identify_business_patterns(lines)
        insights.extend(business_patterns)
        
        return insights
    
    def _extract_analysis_insights(self, analysis_result: str) -> List[Dict]:
        """Extrai insights da análise gerada"""
        
        insights = []
        
        # Identificar seções da análise
        sections = self._parse_analysis_sections(analysis_result)
        
        for section_name, section_content in sections.items():
            section_insights = self._extract_section_insights(section_name, section_content)
            insights.extend(section_insights)
        
        return insights
    
    def _correlate_program_analysis(self, program_insights: List[Dict], 
                                  analysis_insights: List[Dict]) -> List[Dict]:
        """Correlaciona insights do programa com insights da análise"""
        
        correlations = []
        
        # Correlação por tipo
        program_by_type = defaultdict(list)
        analysis_by_type = defaultdict(list)
        
        for insight in program_insights:
            program_by_type[insight.get("type", "unknown")].append(insight)
        
        for insight in analysis_insights:
            analysis_by_type[insight.get("type", "unknown")].append(insight)
        
        # Encontrar correlações
        for insight_type in program_by_type.keys():
            if insight_type in analysis_by_type:
                correlation = {
                    "type": insight_type,
                    "program_count": len(program_by_type[insight_type]),
                    "analysis_count": len(analysis_by_type[insight_type]),
                    "correlation_strength": self._calculate_correlation_strength(
                        program_by_type[insight_type], 
                        analysis_by_type[insight_type]
                    ),
                    "examples": {
                        "program": program_by_type[insight_type][:3],
                        "analysis": analysis_by_type[insight_type][:3]
                    }
                }
                correlations.append(correlation)
        
        return correlations
    
    def _identify_new_patterns(self, program_content: str, analysis_result: str, 
                             correlations: List[Dict]) -> List[Dict]:
        """Identifica novos padrões a partir da análise"""
        
        new_patterns = []
        
        # Padrões baseados em correlações fortes
        for correlation in correlations:
            if correlation["correlation_strength"] > self.learning_config["confidence_threshold"]:
                pattern = {
                    "type": "correlation_pattern",
                    "pattern_type": correlation["type"],
                    "strength": correlation["correlation_strength"],
                    "description": f"Padrão correlacionado: {correlation['type']}",
                    "program_indicators": [ex.get("pattern", "") for ex in correlation["examples"]["program"]],
                    "analysis_indicators": [ex.get("content", "") for ex in correlation["examples"]["analysis"]],
                    "discovered_at": datetime.now().isoformat(),
                    "confidence": correlation["correlation_strength"]
                }
                new_patterns.append(pattern)
        
        # Padrões baseados em frequência
        frequency_patterns = self._identify_frequency_patterns(program_content, analysis_result)
        new_patterns.extend(frequency_patterns)
        
        # Padrões baseados em contexto
        context_patterns = self._identify_context_patterns(program_content, analysis_result)
        new_patterns.extend(context_patterns)
        
        return new_patterns
    
    def _validate_and_incorporate_patterns(self, new_patterns: List[Dict]) -> List[Dict]:
        """Valida e incorpora novos padrões à base de conhecimento"""
        
        validated_patterns = []
        
        for pattern in new_patterns:
            # Validar padrão
            validation_score = self._validate_pattern(pattern)
            
            if validation_score >= self.learning_config["pattern_validation_threshold"]:
                # Incorporar à base de conhecimento
                self._incorporate_pattern_to_kb(pattern)
                
                pattern["validation_score"] = validation_score
                pattern["incorporated_at"] = datetime.now().isoformat()
                
                validated_patterns.append(pattern)
                self.learning_metrics["patterns_learned"] += 1
        
        return validated_patterns
    
    def _incorporate_feedback(self, feedback: Dict, learning_session: Dict) -> Dict:
        """Incorpora feedback do usuário ao aprendizado"""
        
        feedback_insights = {
            "feedback_type": feedback.get("type", "general"),
            "rating": feedback.get("rating", 0),
            "comments": feedback.get("comments", ""),
            "corrections": feedback.get("corrections", []),
            "suggestions": feedback.get("suggestions", [])
        }
        
        # Processar correções
        if feedback_insights["corrections"]:
            self._process_corrections(feedback_insights["corrections"], learning_session)
        
        # Processar sugestões
        if feedback_insights["suggestions"]:
            self._process_suggestions(feedback_insights["suggestions"], learning_session)
        
        # Ajustar confiança dos padrões baseado no rating
        if feedback_insights["rating"] > 0:
            self._adjust_pattern_confidence(feedback_insights["rating"], learning_session)
        
        self.learning_metrics["feedback_incorporated"] += 1
        
        return feedback_insights
    
    def get_learning_progress(self) -> Dict:
        """Retorna progresso do aprendizado"""
        
        return {
            "metrics": self.learning_metrics,
            "accuracy": self._calculate_accuracy(),
            "knowledge_growth": self._calculate_knowledge_growth(),
            "recent_discoveries": self._get_recent_discoveries(),
            "learning_trends": self._analyze_learning_trends(),
            "recommendations": self._generate_learning_recommendations()
        }
    
    def _calculate_accuracy(self) -> float:
        """Calcula precisão do sistema"""
        
        if self.learning_metrics["total_predictions"] == 0:
            return 0.0
        
        return self.learning_metrics["successful_predictions"] / self.learning_metrics["total_predictions"]
    
    def _save_learning_session(self, session: Dict):
        """Salva sessão de aprendizado"""
        
        try:
            sessions_dir = os.path.join(self.knowledge_base_path, "learning_sessions")
            os.makedirs(sessions_dir, exist_ok=True)
            
            session_file = os.path.join(sessions_dir, f"session_{session['timestamp']}.json")
            
            with open(session_file, 'w', encoding='utf-8') as f:
                json.dump(session, f, indent=2, default=str, ensure_ascii=False)
            
            self.logger.info(f"Sessão de aprendizado salva: {session_file}")
            
        except Exception as e:
            self.logger.error(f"Erro ao salvar sessão: {e}")
