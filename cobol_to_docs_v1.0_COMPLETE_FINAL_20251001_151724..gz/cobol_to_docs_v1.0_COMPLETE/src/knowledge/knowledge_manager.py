"""
Knowledge Manager - Gerenciador de Base de Conhecimento
"""

import json
import logging
import os
from typing import Dict, List, Any
from datetime import datetime

class KnowledgeManager:
    """Gerenciador da base de conhecimento COBOL"""
    
    def __init__(self, base_path: str = "data/knowledge_base"):
        self.base_path = base_path
        self.logger = logging.getLogger(__name__)
        
        # Garantir diretório existe
        os.makedirs(base_path, exist_ok=True)
        
        # Inicializar bases
        self._initialize_knowledge_bases()
        
        self.logger.info("Knowledge Manager inicializado")
    
    def _initialize_knowledge_bases(self):
        """Inicializa bases de conhecimento"""
        
        # Base de padrões COBOL
        cobol_patterns = {
            "file_operations": [
                {
                    "pattern": "SELECT.*ASSIGN TO",
                    "description": "Definição de arquivo",
                    "category": "FILE_DEFINITION",
                    "examples": ["SELECT CLIENTE-FILE ASSIGN TO CLIENTE"]
                }
            ],
            "data_structures": [
                {
                    "pattern": "01.*PIC",
                    "description": "Definição de estrutura de dados",
                    "category": "DATA_DEFINITION",
                    "examples": ["01 WS-CONTADOR PIC 9(05) VALUE ZERO"]
                }
            ],
            "control_flow": [
                {
                    "pattern": "PERFORM.*UNTIL",
                    "description": "Loop com condição",
                    "category": "CONTROL_STRUCTURE",
                    "examples": ["PERFORM PROCESSAR UNTIL WS-FIM = 'S'"]
                }
            ]
        }
        
        self._save_knowledge_file("cobol_patterns.json", cobol_patterns)
        
        # Base de regras de negócio
        business_rules = {
            "banking_rules": [
                {
                    "rule": "Validação de saldo antes de débito",
                    "pattern": "IF SALDO >= VALOR",
                    "criticality": "HIGH",
                    "domain": "BANKING"
                }
            ],
            "cadoc_rules": [
                {
                    "rule": "Validação de instituição CADOC",
                    "pattern": "IF INSTITUICAO = '0033' OR '1508'",
                    "criticality": "CRITICAL",
                    "domain": "REGULATORY"
                }
            ]
        }
        
        self._save_knowledge_file("business_rules.json", business_rules)
        
        # Base de conhecimento CADOC
        cadoc_knowledge = {
            "institutions": {
                "0033": {"name": "Santander", "type": "BANK"},
                "1508": {"name": "Banco Especial", "type": "BANK"},
                "BNDS": {"name": "BNDES", "type": "DEVELOPMENT_BANK"}
            },
            "document_types": [
                {"code": "DOC001", "description": "Documento de Cliente"},
                {"code": "DOC002", "description": "Documento de Transação"}
            ],
            "validation_rules": [
                {"field": "INSTITUICAO", "required": True, "format": "9999"},
                {"field": "DOCUMENTO", "required": True, "format": "X(20)"}
            ]
        }
        
        self._save_knowledge_file("cadoc_knowledge.json", cadoc_knowledge)
    
    def add_learned_pattern(self, pattern: str, context: str, category: str):
        """Adiciona padrão aprendido"""
        
        learned_pattern = {
            "pattern": pattern,
            "context": context,
            "category": category,
            "learned_at": datetime.now().isoformat(),
            "confidence": 0.8  # Inicial
        }
        
        # Carregar padrões aprendidos
        learned_file = "learned_patterns.json"
        learned_patterns = self._load_knowledge_file(learned_file) or {"patterns": []}
        
        # Adicionar novo padrão
        learned_patterns["patterns"].append(learned_pattern)
        
        # Salvar
        self._save_knowledge_file(learned_file, learned_patterns)
        
        self.logger.info(f"Padrão aprendido adicionado: {category}")
    
    def get_patterns_by_category(self, category: str) -> List[Dict]:
        """Retorna padrões por categoria"""
        
        # Buscar em padrões COBOL
        cobol_patterns = self._load_knowledge_file("cobol_patterns.json") or {}
        patterns = cobol_patterns.get(category, [])
        
        # Buscar em padrões aprendidos
        learned_patterns = self._load_knowledge_file("learned_patterns.json") or {"patterns": []}
        learned = [p for p in learned_patterns["patterns"] if p.get("category") == category]
        
        return patterns + learned
    
    def _save_knowledge_file(self, filename: str, data: Dict):
        """Salva arquivo de conhecimento"""
        try:
            filepath = os.path.join(self.base_path, filename)
            with open(filepath, 'w') as f:
                json.dump(data, f, indent=2, default=str)
        except Exception as e:
            self.logger.error(f"Erro ao salvar {filename}: {e}")
    
    def _load_knowledge_file(self, filename: str) -> Dict:
        """Carrega arquivo de conhecimento"""
        try:
            filepath = os.path.join(self.base_path, filename)
            if os.path.exists(filepath):
                with open(filepath, 'r') as f:
                    return json.load(f)
        except Exception as e:
            self.logger.error(f"Erro ao carregar {filename}: {e}")
        return None
