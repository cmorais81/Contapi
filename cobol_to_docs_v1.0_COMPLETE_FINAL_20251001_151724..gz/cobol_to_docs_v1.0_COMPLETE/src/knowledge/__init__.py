"""
knowledge module
"""
