"""
CLI Client - Cliente de linha de comando para COBOL to Docs
"""

import argparse
import sys
import os
import json
import logging
from pathlib import Path
from typing import List

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from library.cobol_analysis_lib import COBOLAnalysisLibrary

class COBOLAnalysisCLI:
    """Cliente CLI para análise COBOL"""
    
    def __init__(self):
        self.library = None
        self.setup_logging()
    
    def setup_logging(self):
        """Configura logging"""
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
        self.logger = logging.getLogger(__name__)
    
    def run(self):
        """Executa CLI"""
        
        parser = self.create_parser()
        args = parser.parse_args()
        
        # Configurar nível de log
        if args.verbose:
            logging.getLogger().setLevel(logging.DEBUG)
        elif args.quiet:
            logging.getLogger().setLevel(logging.WARNING)
        
        # Inicializar biblioteca
        self.library = COBOLAnalysisLibrary(
            config_path=args.config,
            output_dir=args.output
        )
        
        # Executar comando
        try:
            if args.command == 'analyze':
                self.cmd_analyze(args)
            elif args.command == 'batch':
                self.cmd_batch(args)
            elif args.command == 'status':
                self.cmd_status(args)
            elif args.command == 'stats':
                self.cmd_stats(args)
            else:
                parser.print_help()
                
        except Exception as e:
            self.logger.error(f"Erro na execução: {e}")
            sys.exit(1)
    
    def create_parser(self):
        """Cria parser de argumentos"""
        
        parser = argparse.ArgumentParser(
            description='COBOL to Docs v1.0 - Análise Avançada de Programas COBOL',
            formatter_class=argparse.RawDescriptionHelpFormatter,
            epilog="""
Exemplos de uso:

  # Analisar arquivo único
  python -m client.cli_client analyze programa.cbl
  
  # Analisar com modelo específico
  python -m client.cli_client analyze programa.cbl --model luzia
  
  # Análise em lote
  python -m client.cli_client batch *.cbl --output ./relatorios
  
  # Verificar status dos providers
  python -m client.cli_client status
  
  # Ver estatísticas
  python -m client.cli_client stats
            """
        )
        
        # Argumentos globais
        parser.add_argument('--config', '-c', help='Arquivo de configuração')
        parser.add_argument('--output', '-o', default='output', help='Diretório de saída')
        parser.add_argument('--verbose', '-v', action='store_true', help='Modo verboso')
        parser.add_argument('--quiet', '-q', action='store_true', help='Modo silencioso')
        
        # Subcomandos
        subparsers = parser.add_subparsers(dest='command', help='Comandos disponíveis')
        
        # Comando analyze
        analyze_parser = subparsers.add_parser('analyze', help='Analisar arquivo COBOL')
        analyze_parser.add_argument('file', help='Arquivo COBOL para análise')
        analyze_parser.add_argument('--model', '-m', default='enhanced_mock', 
                                  help='Modelo de IA para análise')
        analyze_parser.add_argument('--strategy', '-s', default='expert_analysis',
                                  help='Estratégia de análise')
        analyze_parser.add_argument('--json', action='store_true',
                                  help='Saída em formato JSON')
        
        # Comando batch
        batch_parser = subparsers.add_parser('batch', help='Análise em lote')
        batch_parser.add_argument('files', nargs='+', help='Arquivos COBOL para análise')
        batch_parser.add_argument('--model', '-m', default='enhanced_mock',
                                help='Modelo de IA para análise')
        batch_parser.add_argument('--strategy', '-s', default='expert_analysis',
                                help='Estratégia de análise')
        batch_parser.add_argument('--json', action='store_true',
                                help='Saída em formato JSON')
        
        # Comando status
        status_parser = subparsers.add_parser('status', help='Status dos providers')
        status_parser.add_argument('--json', action='store_true',
                                 help='Saída em formato JSON')
        
        # Comando stats
        stats_parser = subparsers.add_parser('stats', help='Estatísticas do sistema')
        stats_parser.add_argument('--json', action='store_true',
                                help='Saída em formato JSON')
        
        return parser
    
    def cmd_analyze(self, args):
        """Comando de análise individual"""
        
        if not os.path.exists(args.file):
            self.logger.error(f"Arquivo não encontrado: {args.file}")
            sys.exit(1)
        
        self.logger.info(f"Analisando arquivo: {args.file}")
        
        result = self.library.analyze_file(
            file_path=args.file,
            model=args.model,
            analysis_strategy=args.strategy
        )
        
        if args.json:
            print(json.dumps(result, indent=2, default=str, ensure_ascii=False))
        else:
            self.print_analysis_result(result)
    
    def cmd_batch(self, args):
        """Comando de análise em lote"""
        
        # Expandir wildcards
        files = []
        for pattern in args.files:
            if '*' in pattern or '?' in pattern:
                from glob import glob
                files.extend(glob(pattern))
            else:
                files.append(pattern)
        
        # Verificar arquivos
        existing_files = [f for f in files if os.path.exists(f)]
        if not existing_files:
            self.logger.error("Nenhum arquivo válido encontrado")
            sys.exit(1)
        
        self.logger.info(f"Analisando {len(existing_files)} arquivos em lote")
        
        result = self.library.batch_analyze(
            file_paths=existing_files,
            model=args.model,
            analysis_strategy=args.strategy
        )
        
        if args.json:
            print(json.dumps(result, indent=2, default=str, ensure_ascii=False))
        else:
            self.print_batch_result(result)
    
    def cmd_status(self, args):
        """Comando de status"""
        
        models = self.library.get_available_models()
        strategies = self.library.get_available_strategies()
        provider_status = self.library.get_provider_status()
        
        status_info = {
            "available_models": models,
            "available_strategies": strategies,
            "provider_status": provider_status
        }
        
        if args.json:
            print(json.dumps(status_info, indent=2, ensure_ascii=False))
        else:
            print("\n=== STATUS DO SISTEMA ===\n")
            print("Modelos Disponíveis:")
            for model in models:
                print(f"  - {model}")
            
            print("\nEstratégias Disponíveis:")
            for strategy in strategies:
                print(f"  - {strategy}")
            
            print("\nStatus dos Providers:")
            for provider, status in provider_status.items():
                print(f"  - {provider}: {status}")
    
    def cmd_stats(self, args):
        """Comando de estatísticas"""
        
        stats = self.library.get_statistics()
        
        if args.json:
            print(json.dumps(stats, indent=2, default=str, ensure_ascii=False))
        else:
            print("\n=== ESTATÍSTICAS DO SISTEMA ===\n")
            print(f"Programas Analisados: {stats['programs_analyzed']}")
            print(f"Análises Bem-sucedidas: {stats['successful_analyses']}")
            print(f"Análises Falharam: {stats['failed_analyses']}")
            print(f"Total de Tokens: {stats['total_tokens_used']}")
            print(f"Tempo Total: {stats['total_processing_time']:.2f}s")
            
            if 'rag_statistics' in stats:
                print("\nEstatísticas RAG:")
                rag_stats = stats['rag_statistics']
                print(f"  - Base de Conhecimento: {rag_stats.get('knowledge_base_size', 'N/A')}")
                print(f"  - Interações: {rag_stats.get('total_interactions', 'N/A')}")
    
    def print_analysis_result(self, result):
        """Imprime resultado de análise"""
        
        print("\n=== RESULTADO DA ANÁLISE ===\n")
        
        if result['success']:
            print(f"✅ Análise bem-sucedida!")
            print(f"Arquivo: {result['file_path']}")
            print(f"Programas: {result['programs_count']}")
            print(f"Copybooks: {result['copybooks_count']}")
            
            print("\nResultados por Programa:")
            for i, prog_result in enumerate(result['results'], 1):
                status = "✅" if prog_result['success'] else "❌"
                name = prog_result['program_name']
                print(f"  {i}. {status} {name}")
                
                if prog_result['success']:
                    print(f"     Documentação: {prog_result['documentation_path']}")
                    print(f"     Tokens: {prog_result['tokens_used']}")
                    print(f"     Tempo: {prog_result['processing_time']:.2f}s")
        else:
            print(f"❌ Falha na análise: {result.get('error', 'Erro desconhecido')}")
    
    def print_batch_result(self, result):
        """Imprime resultado de análise em lote"""
        
        print("\n=== RESULTADO DA ANÁLISE EM LOTE ===\n")
        
        if result['success']:
            print(f"✅ Análise em lote concluída!")
            print(f"Total de Arquivos: {result['total_files']}")
            print(f"Sucessos: {result['successful_files']}")
            print(f"Falhas: {result['failed_files']}")
            print(f"Relatório Resumo: {result.get('summary_report', 'N/A')}")
            
            print("\nEstatísticas:")
            stats = result['statistics']
            print(f"  - Programas Analisados: {stats['programs_analyzed']}")
            print(f"  - Total de Tokens: {stats['total_tokens_used']}")
            print(f"  - Tempo Total: {stats['total_processing_time']:.2f}s")
        else:
            print(f"❌ Falha na análise em lote: {result.get('error', 'Erro desconhecido')}")

def main():
    """Função principal"""
    cli = COBOLAnalysisCLI()
    cli.run()

if __name__ == '__main__':
    main()
