"""
API Client - Cliente para integração via API
"""

import requests
import json
import logging
from typing import Dict, Any, Optional, List
from datetime import datetime

class COBOLAnalysisAPIClient:
    """Cliente para API de análise COBOL"""
    
    def __init__(self, base_url: str, api_key: Optional[str] = None):
        self.base_url = base_url.rstrip('/')
        self.api_key = api_key
        self.session = requests.Session()
        
        # Configurar headers
        self.session.headers.update({
            'Content-Type': 'application/json',
            'User-Agent': 'COBOL-to-Docs-Client/1.0'
        })
        
        if api_key:
            self.session.headers.update({
                'Authorization': f'Bearer {api_key}'
            })
        
        self.logger = logging.getLogger(__name__)
        self.logger.info(f"API Client inicializado: {base_url}")
    
    def analyze_content(self, content: str, program_name: str = "UNKNOWN",
                       model: str = "enhanced_mock", strategy: str = "expert_analysis") -> Dict[str, Any]:
        """Analisa conteúdo COBOL via API"""
        
        payload = {
            "content": content,
            "program_name": program_name,
            "model": model,
            "strategy": strategy,
            "timestamp": datetime.now().isoformat()
        }
        
        try:
            response = self.session.post(
                f"{self.base_url}/api/v1/analyze/content",
                json=payload,
                timeout=300
            )
            
            response.raise_for_status()
            return response.json()
            
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Erro na requisição: {e}")
            return {
                "success": False,
                "error": str(e),
                "error_type": "request_error"
            }
    
    def analyze_file(self, file_path: str, model: str = "enhanced_mock",
                    strategy: str = "expert_analysis") -> Dict[str, Any]:
        """Analisa arquivo COBOL via API"""
        
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            program_name = os.path.basename(file_path).replace('.cbl', '').replace('.cob', '')
            
            return self.analyze_content(content, program_name, model, strategy)
            
        except Exception as e:
            self.logger.error(f"Erro ao ler arquivo {file_path}: {e}")
            return {
                "success": False,
                "error": str(e),
                "error_type": "file_error"
            }
    
    def batch_analyze(self, requests_list: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Análise em lote via API"""
        
        payload = {
            "requests": requests_list,
            "timestamp": datetime.now().isoformat()
        }
        
        try:
            response = self.session.post(
                f"{self.base_url}/api/v1/analyze/batch",
                json=payload,
                timeout=600  # Timeout maior para lote
            )
            
            response.raise_for_status()
            return response.json()
            
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Erro na análise em lote: {e}")
            return {
                "success": False,
                "error": str(e),
                "error_type": "batch_error"
            }
    
    def get_status(self) -> Dict[str, Any]:
        """Obtém status da API"""
        
        try:
            response = self.session.get(f"{self.base_url}/api/v1/status")
            response.raise_for_status()
            return response.json()
            
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Erro ao obter status: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    def get_models(self) -> Dict[str, Any]:
        """Obtém modelos disponíveis"""
        
        try:
            response = self.session.get(f"{self.base_url}/api/v1/models")
            response.raise_for_status()
            return response.json()
            
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Erro ao obter modelos: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    def get_statistics(self) -> Dict[str, Any]:
        """Obtém estatísticas da API"""
        
        try:
            response = self.session.get(f"{self.base_url}/api/v1/statistics")
            response.raise_for_status()
            return response.json()
            
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Erro ao obter estatísticas: {e}")
            return {
                "success": False,
                "error": str(e)
            }

# Funções de conveniência
def create_api_client(base_url: str, api_key: Optional[str] = None) -> COBOLAnalysisAPIClient:
    """Cria cliente API"""
    return COBOLAnalysisAPIClient(base_url, api_key)

def quick_analyze(base_url: str, content: str, program_name: str = "UNKNOWN",
                 api_key: Optional[str] = None) -> Dict[str, Any]:
    """Análise rápida via API"""
    
    client = create_api_client(base_url, api_key)
    return client.analyze_content(content, program_name)
