# Relatório Resumo - Análise em Lote

**Data**: 2025-10-01 15:17:05  
**Total de Arquivos**: 5  
**Sucessos**: 5  
**Falhas**: 0  
**Taxa de Sucesso**: 100.0%  

## Resultados por Arquivo

1. ✅ examples/LHAN0542.cbl
   - ✅ LHAN0542
2. ✅ examples/LHAN0543.cbl
   - ✅ LHAN0543
3. ✅ examples/LHAN0544.cbl
   - ✅ LHAN0544
4. ✅ examples/LHAN0545.cbl
   - ✅ LHAN0545
5. ✅ examples/LHAN0546.cbl
   - ✅ LHAN0546

## Estatísticas Gerais

- **Documentos Gerados**: 5
- **Tamanho Total**: 9470 caracteres
- **Tempo de Geração**: 0.00s

---

*Relatório gerado automaticamente pelo COBOL to Docs v1.0*
