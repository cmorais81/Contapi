#!/usr/bin/env python3
"""
COBOL to Docs v1.0 - Sistema Completo de Análise COBOL
Sistema avançado com RAG, aprendizado automático e múltiplos providers
"""

import os
import sys
import logging
import argparse
from pathlib import Path
from typing import List, Dict, Any

# Adicionar src ao path
current_dir = os.path.dirname(os.path.abspath(__file__))
src_dir = os.path.join(current_dir, 'src')
sys.path.insert(0, src_dir)

from src.library.cobol_analysis_lib import COBOLAnalysisLibrary

def setup_logging(verbose: bool = False):
    """Configura sistema de logging"""
    
    level = logging.DEBUG if verbose else logging.INFO
    
    logging.basicConfig(
        level=level,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(),
            logging.FileHandler('logs/cobol_to_docs.log', encoding='utf-8')
        ]
    )
    
    # Criar diretório de logs
    os.makedirs('logs', exist_ok=True)

def main():
    """Função principal"""
    
    parser = argparse.ArgumentParser(
        description='COBOL to Docs v1.0 - Sistema Completo de Análise COBOL',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Sistema avançado com:
- RAG (Retrieval-Augmented Generation)
- Aprendizado automático
- Múltiplos providers (Enhanced Mock, LuzIA, GitHub Copilot)
- Base de conhecimento que evolui
- Análise profissional sênior

Exemplos de uso:

  # Analisar arquivo único
  python main.py examples/LHAN0542.cbl
  
  # Analisar múltiplos arquivos
  python main.py examples/*.cbl
  
  # Usar modelo específico
  python main.py examples/LHAN0542.cbl --model luzia
  
  # Análise com estratégia específica
  python main.py examples/LHAN0542.cbl --strategy comprehensive
  
  # Modo verboso
  python main.py examples/LHAN0542.cbl --verbose
        """
    )
    
    parser.add_argument('files', nargs='+', help='Arquivos COBOL para análise')
    parser.add_argument('--config', '-c', help='Arquivo de configuração personalizado')
    parser.add_argument('--output', '-o', default='output', help='Diretório de saída (padrão: output)')
    parser.add_argument('--model', '-m', default='enhanced_mock', 
                       help='Modelo de IA (padrão: enhanced_mock)')
    parser.add_argument('--strategy', '-s', default='expert_analysis',
                       help='Estratégia de análise (padrão: expert_analysis)')
    parser.add_argument('--verbose', '-v', action='store_true', help='Modo verboso')
    parser.add_argument('--quiet', '-q', action='store_true', help='Modo silencioso')
    parser.add_argument('--stats', action='store_true', help='Mostrar estatísticas ao final')
    
    args = parser.parse_args()
    
    # Configurar logging
    if not args.quiet:
        setup_logging(args.verbose)
    
    logger = logging.getLogger(__name__)
    
    try:
        # Banner do sistema
        if not args.quiet:
            print_banner()
        
        # Expandir wildcards nos arquivos
        files = expand_file_patterns(args.files)
        
        if not files:
            logger.error("Nenhum arquivo válido encontrado")
            sys.exit(1)
        
        logger.info(f"Iniciando análise de {len(files)} arquivo(s)")
        
        # Inicializar biblioteca
        library = COBOLAnalysisLibrary(
            config_path=args.config,
            output_dir=args.output
        )
        
        # Verificar status dos providers
        if not args.quiet:
            print_provider_status(library)
        
        # Executar análise
        if len(files) == 1:
            # Análise individual
            result = library.analyze_file(
                file_path=files[0],
                model=args.model,
                analysis_strategy=args.strategy
            )
            
            if not args.quiet:
                print_single_result(result)
                
        else:
            # Análise em lote
            result = library.batch_analyze(
                file_paths=files,
                model=args.model,
                analysis_strategy=args.strategy
            )
            
            if not args.quiet:
                print_batch_result(result)
        
        # Mostrar estatísticas se solicitado
        if args.stats and not args.quiet:
            print_statistics(library)
        
        # Verificar sucesso
        if result.get('success', False):
            logger.info("✅ Análise concluída com sucesso!")
            if not args.quiet:
                print(f"\n✅ Documentação gerada em: {args.output}")
        else:
            logger.error("❌ Análise falhou")
            sys.exit(1)
            
    except KeyboardInterrupt:
        logger.info("Análise interrompida pelo usuário")
        sys.exit(1)
    except Exception as e:
        logger.error(f"Erro na execução: {e}")
        if args.verbose:
            import traceback
            traceback.print_exc()
        sys.exit(1)

def print_banner():
    """Imprime banner do sistema"""
    
    banner = """
╔══════════════════════════════════════════════════════════════════════════════╗
║                          COBOL to Docs v1.0                                 ║
║                    Sistema Avançado de Análise COBOL                        ║
║                                                                              ║
║  🚀 RAG (Retrieval-Augmented Generation)                                    ║
║  🧠 Aprendizado Automático                                                  ║
║  🔗 Múltiplos Providers (Enhanced Mock, LuzIA, GitHub Copilot)              ║
║  📚 Base de Conhecimento Evolutiva                                          ║
║  👨‍💼 Análise Profissional Sênior                                            ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""
    print(banner)

def print_provider_status(library):
    """Imprime status dos providers"""
    
    print("\n📊 STATUS DOS PROVIDERS:")
    
    models = library.get_available_models()
    provider_status = library.get_provider_status()
    
    for provider, status in provider_status.items():
        status_icon = "✅" if status == "disponível" else "❌"
        print(f"  {status_icon} {provider}: {status}")
    
    print(f"\n🎯 MODELOS DISPONÍVEIS: {', '.join(models)}")
    
    strategies = library.get_available_strategies()
    print(f"📋 ESTRATÉGIAS: {', '.join(strategies)}")

def print_single_result(result):
    """Imprime resultado de análise individual"""
    
    print("\n" + "="*80)
    print("RESULTADO DA ANÁLISE")
    print("="*80)
    
    if result['success']:
        print(f"✅ Análise bem-sucedida!")
        print(f"📁 Arquivo: {result['file_path']}")
        print(f"📊 Programas: {result['programs_count']}")
        print(f"📚 Copybooks: {result['copybooks_count']}")
        
        print("\n📋 PROGRAMAS ANALISADOS:")
        for i, prog_result in enumerate(result['results'], 1):
            status = "✅" if prog_result['success'] else "❌"
            name = prog_result['program_name']
            print(f"  {i}. {status} {name}")
            
            if prog_result['success']:
                print(f"     📄 Documentação: {prog_result['documentation_path']}")
                print(f"     🎯 Tokens: {prog_result['tokens_used']}")
                print(f"     ⏱️  Tempo: {prog_result['processing_time']:.2f}s")
                print(f"     🤖 Provider: {prog_result['provider']}")
    else:
        print(f"❌ Falha na análise: {result.get('error', 'Erro desconhecido')}")

def print_batch_result(result):
    """Imprime resultado de análise em lote"""
    
    print("\n" + "="*80)
    print("RESULTADO DA ANÁLISE EM LOTE")
    print("="*80)
    
    if result['success']:
        print(f"✅ Análise em lote concluída!")
        print(f"📁 Total de Arquivos: {result['total_files']}")
        print(f"✅ Sucessos: {result['successful_files']}")
        print(f"❌ Falhas: {result['failed_files']}")
        
        success_rate = (result['successful_files'] / result['total_files']) * 100
        print(f"📊 Taxa de Sucesso: {success_rate:.1f}%")
        
        if result.get('summary_report'):
            print(f"📋 Relatório Resumo: {result['summary_report']}")
    else:
        print(f"❌ Falha na análise em lote: {result.get('error', 'Erro desconhecido')}")

def print_statistics(library):
    """Imprime estatísticas do sistema"""
    
    stats = library.get_statistics()
    
    print("\n" + "="*80)
    print("ESTATÍSTICAS DO SISTEMA")
    print("="*80)
    
    print(f"📊 Programas Analisados: {stats['programs_analyzed']}")
    print(f"✅ Análises Bem-sucedidas: {stats['successful_analyses']}")
    print(f"❌ Análises Falharam: {stats['failed_analyses']}")
    print(f"🎯 Total de Tokens: {stats['total_tokens_used']}")
    print(f"⏱️  Tempo Total: {stats['total_processing_time']:.2f}s")
    
    if 'rag_statistics' in stats:
        print("\n🧠 ESTATÍSTICAS RAG:")
        rag_stats = stats['rag_statistics']
        print(f"  📚 Base de Conhecimento: {rag_stats.get('knowledge_base_size', 'N/A')}")
        print(f"  🔄 Interações: {rag_stats.get('total_interactions', 'N/A')}")
    
    if 'learning_progress' in stats:
        print("\n🎓 PROGRESSO DO APRENDIZADO:")
        learning = stats['learning_progress']
        print(f"  🔍 Padrões Aprendidos: {learning.get('patterns_learned', 'N/A')}")
        print(f"  📈 Precisão: {learning.get('accuracy', 'N/A')}")

def expand_file_patterns(patterns: List[str]) -> List[str]:
    """Expande padrões de arquivo (wildcards)"""
    
    files = []
    
    for pattern in patterns:
        if '*' in pattern or '?' in pattern:
            from glob import glob
            expanded = glob(pattern)
            files.extend(expanded)
        else:
            if os.path.exists(pattern):
                files.append(pattern)
    
    # Filtrar apenas arquivos COBOL
    cobol_extensions = ['.cbl', '.cob', '.cobol', '.txt']
    cobol_files = []
    
    for file in files:
        if any(file.lower().endswith(ext) for ext in cobol_extensions):
            cobol_files.append(file)
    
    return sorted(list(set(cobol_files)))  # Remover duplicatas e ordenar

if __name__ == "__main__":
    main()
