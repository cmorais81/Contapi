# Guia de Configuração - COBOL to Docs v1.0

## Visão Geral

Este guia detalha todas as opções de configuração disponíveis no sistema COBOL to Docs v1.0.

## Arquivo Principal: config.yaml

### Estrutura Básica

```yaml
providers:          # Configuração de providers de IA
analysis:           # Configurações de análise
rag:               # Configurações do sistema RAG
learning:          # Configurações de aprendizado
logging:           # Configurações de logging
performance:       # Configurações de performance
documentation:     # Configurações de documentação
security:          # Configurações de segurança
```

## Configuração de Providers

### Enhanced Mock Provider

```yaml
providers:
  enhanced_mock:
    enabled: true
    description: "Provider para análises profissionais com RAG"
    models:
      - "enhanced-mock-rag"
      - "enhanced-mock-basic"
    features:
      rag_enabled: true
      learning_enabled: true
      pattern_discovery: true
```

**Parâmetros:**
- `enabled`: Habilita/desabilita o provider
- `models`: Lista de modelos disponíveis
- `features`: Funcionalidades específicas

### LuzIA Provider (Santander)

```yaml
providers:
  luzia:
    enabled: true
    client_id: "${LUZIA_CLIENT_ID}"
    client_secret: "${LUZIA_CLIENT_SECRET}"
    auth_url: "https://login.azure.pass.santander-br-pre.corp/auth/realms/corp/protocol/openid-connect/token"
    api_url: "https://api-dev.pass.santander-br-pre.corp/genai_services/v1/"
    
    models:
      aws_claude_3_5_sonnet:
        name: "aws-claude-3-5-sonnet"
        max_tokens: 8192
        temperature: 0.1
        timeout: 120
        context_window: 200000
        cost_per_token: 0.000015
```

**Variáveis de Ambiente Necessárias:**
```bash
export LUZIA_CLIENT_ID="seu_client_id"
export LUZIA_CLIENT_SECRET="seu_client_secret"
```

### GitHub Copilot Provider

```yaml
providers:
  github_copilot:
    enabled: false
    api_key: "${GITHUB_COPILOT_API_KEY}"
    base_url: "https://api.github.com/copilot"
    models:
      - "github-copilot-code"
      - "github-copilot-chat"
```

**Variável de Ambiente:**
```bash
export GITHUB_COPILOT_API_KEY="seu_api_key"
```

## Configuração de Análise

### Configurações Básicas

```yaml
analysis:
  include_metadata: true
  include_comments: true
  include_business_rules: true
  include_technical_details: true
  use_rag: true
  enable_learning: true
```

### Estratégias de Análise

```yaml
analysis:
  strategies:
    default: "comprehensive"
    quick: "basic_patterns"
    deep: "expert_analysis"
    learning: "rag_enhanced"
  
  prompt_templates:
    expert_analysis: "prompts/expert_analysis.yaml"
    basic_patterns: "prompts/basic_patterns.yaml"
    rag_enhanced: "prompts/rag_enhanced.yaml"
    comprehensive: "prompts/comprehensive.yaml"
```

## Configuração RAG

### Configurações Principais

```yaml
rag:
  enabled: true
  knowledge_base_path: "data/knowledge_base"
  
  retrieval:
    similarity_threshold: 0.1
    max_retrieved_docs: 10
    use_semantic_search: true
    use_pattern_matching: true
    use_context_filtering: true
```

### Vetorização

```yaml
rag:
  vectorization:
    max_features: 2000
    ngram_range: [1, 3]
    min_df: 1
    max_df: 0.95
    use_tfidf: true
```

### Clustering

```yaml
rag:
  clustering:
    enabled: true
    n_clusters: 10
    algorithm: "kmeans"
    update_frequency: 50  # A cada 50 análises
```

## Configuração de Aprendizado

### Parâmetros Principais

```yaml
learning:
  enabled: true
  auto_learn: true
  feedback_integration: true
  
  parameters:
    min_pattern_frequency: 3
    confidence_threshold: 0.7
    max_learning_iterations: 100
    pattern_validation_threshold: 0.8
    feedback_weight: 0.3
```

### Estratégias de Aprendizado

```yaml
learning:
  strategies:
    pattern_discovery: true
    correlation_analysis: true
    feedback_incorporation: true
    quality_improvement: true
```

### Métricas de Qualidade

```yaml
learning:
  quality_metrics:
    track_accuracy: true
    track_user_satisfaction: true
    track_pattern_effectiveness: true
    generate_reports: true
```

## Configuração de Logging

### Configurações Básicas

```yaml
logging:
  level: INFO
  format: '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
  console_output: true
  file_output: true
  file_rotation: true
  max_file_size: 10MB
  backup_count: 5
```

### Logs Específicos

```yaml
logging:
  loggers:
    rag_engine: DEBUG
    learning_system: INFO
    providers: INFO
    analyzers: INFO
```

## Configuração de Performance

### Processamento

```yaml
performance:
  timeout: 300
  
  processing:
    parallel_analysis: false
    max_concurrent: 1
    batch_size: 1
    chunk_size: 4000
    enable_caching: true
```

### Memória

```yaml
performance:
  memory:
    max_memory_usage: "4GB"
    cleanup_interval: 300
    cache_size: "1GB"
```

### Otimização

```yaml
performance:
  optimization:
    enable_profiling: false
    performance_monitoring: true
    resource_tracking: true
```

## Configuração de Documentação

### Formato de Saída

```yaml
documentation:
  output_format: "markdown"
  include_metadata: true
  include_statistics: true
  include_context_info: true
  include_analysis_strategy: true
```

### Templates

```yaml
documentation:
  templates:
    functional_analysis: "templates/functional_analysis.md"
    technical_report: "templates/technical_report.md"
    executive_summary: "templates/executive_summary.md"
```

### Transparência

```yaml
documentation:
  transparency:
    include_rag_sources: true
    include_learning_insights: true
    include_confidence_scores: true
    include_processing_details: true
```

## Configuração de Segurança

```yaml
security:
  encrypt_sensitive_data: true
  audit_logging: true
  access_control: false
  data_retention_days: 90
```

## Configuração de Integrações

### Database

```yaml
integrations:
  database:
    enabled: false
    connection_string: ""
```

### APIs

```yaml
integrations:
  apis:
    enabled: false
    webhook_url: ""
```

### Monitoramento

```yaml
integrations:
  monitoring:
    enabled: false
    metrics_endpoint: ""
```

## Configurações Experimentais

```yaml
experimental:
  enabled: false
  features:
    advanced_clustering: false
    neural_pattern_matching: false
    automated_prompt_optimization: false
    multi_model_ensemble: false
```

## Configuração por Ambiente

### Desenvolvimento

```yaml
# config/dev.yaml
providers:
  enhanced_mock:
    enabled: true
  luzia:
    enabled: false

logging:
  level: DEBUG
  
performance:
  optimization:
    enable_profiling: true
```

### Produção

```yaml
# config/prod.yaml
providers:
  enhanced_mock:
    enabled: false
  luzia:
    enabled: true

logging:
  level: INFO
  
performance:
  optimization:
    enable_profiling: false
    performance_monitoring: true
```

## Validação de Configuração

### Verificar Configuração

```python
from src.core.config import load_config

config = load_config("config/config.yaml")
print("Configuração carregada com sucesso!")
```

### Validar Providers

```bash
python -m src.client.cli_client status
```

## Troubleshooting

### Problemas Comuns

**Provider não disponível:**
- Verificar `enabled: true`
- Verificar credenciais
- Verificar conectividade

**RAG não funcionando:**
- Verificar `rag.enabled: true`
- Verificar `knowledge_base_path`
- Verificar dependências scikit-learn

**Performance baixa:**
- Ajustar `performance.timeout`
- Reduzir `rag.retrieval.max_retrieved_docs`
- Habilitar `performance.processing.enable_caching`

### Debug

```yaml
logging:
  level: DEBUG
  loggers:
    root: DEBUG
```

## Migração de Configuração

### Versão 1.0 → 1.1

```bash
# Backup da configuração atual
cp config/config.yaml config/config.yaml.backup

# Aplicar nova configuração
# (instruções específicas da versão)
```

---

Este guia cobre todas as opções de configuração disponíveis. Para configurações específicas do seu ambiente, consulte a equipe de desenvolvimento.
