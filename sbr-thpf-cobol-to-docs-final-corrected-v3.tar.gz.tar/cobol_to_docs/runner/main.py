
'''
COBOL to Docs v1.0 - Sistema de Análise e Documentação de Programas COBOL
Autor: Carlos Morais
Data: Setembro 2025

Sistema completo para análise automatizada de programas COBOL com geração
de documentação técnica profissional usando IA.

FUNCIONALIDADE COMPLETA RESTAURADA:
- Processamento de múltiplos programas COBOL
- Suporte a múltiplos modelos de IA
- Análise de copybooks complementares
- Geração de relatórios comparativos
- Detecção automática de código COBOL
'''

import argparse
import logging
import os
import sys
import json
import time
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple

# Adicionar o diretório raiz do projeto ao sys.path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from cobol_to_docs.src.core.config import ConfigManager
from cobol_to_docs.src.core.prompt_manager_dual import DualPromptManager
from cobol_to_docs.src.providers.enhanced_provider_manager import EnhancedProviderManager
from cobol_to_docs.src.parsers.cobol_parser import COBOLParser, CobolProgram, CobolBook
from cobol_to_docs.src.analyzers.enhanced_cobol_analyzer import EnhancedCOBOLAnalyzer
from cobol_to_docs.src.analyzers.consolidated_analyzer import ConsolidatedAnalyzer
from cobol_to_docs.src.generators.documentation_generator import DocumentationGenerator
from cobol_to_docs.src.utils.html_generator import HTMLReportGenerator
from cobol_to_docs.src.utils.cost_calculator import CostCalculator
from cobol_to_docs.src.rag.rag_integration import RAGIntegration
from cobol_to_docs.src.core.intelligent_model_selector import IntelligentModelSelector
from cobol_to_docs.src.analytics.consolidated_analysis import (
    process_advanced_consolidated_analysis,
    process_detailed_business_analysis
)

def resolve_file_path(file_path: str) -> str:
    """Resolve um caminho de arquivo, tratando-o como absoluto se não for relativo ao diretório atual."""
    if os.path.isabs(file_path):
        return file_path
    return os.path.abspath(file_path)

def setup_logging(log_level: str = "INFO") -> None:
    """Configura o sistema de logging."""
    log_dir = "logs"
    os.makedirs(log_dir, exist_ok=True)
    
    timestamp_str = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_file = os.path.join(log_dir, f"cobol_to_docs_{timestamp_str}.log") 
    logging.basicConfig(
        level=getattr(logging, log_level.upper()),
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        handlers=[
            logging.FileHandler(log_file, encoding="utf-8"),
            logging.StreamHandler(sys.stdout)
        ]
    )

def parse_models_argument(models_str: str) -> List[str]:
    """Parse do argumento models que pode ser string ou lista JSON."""
    if not models_str:
        return []
    
    models_str = models_str.strip()
    
    if models_str.startswith("["):
        try:
            models = json.loads(models_str)
            return models if isinstance(models, list) else [models]
        except json.JSONDecodeError:
            print(f"Erro: Formato JSON inválido para models: {models_str}")
            sys.exit(1)
    else:
        return [models_str]

def analyze_program_with_model(program: CobolProgram, books: List[CobolBook], model: str, output_dir: str, config_manager: ConfigManager, is_multi_model: bool, prompt_set: str, cost_calculator: CostCalculator, rag_integration=None, args=None, jcl_content: Optional[str] = None, all_copybook_contents: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
    """Analisa um programa COBOL com um modelo específico."""
    logger = logging.getLogger(__name__)
    
    if is_multi_model:
        model_name_sanitized = model.replace("/", "_").replace("-", "_")
        model_output_dir = os.path.join(output_dir, "model_" + model_name_sanitized)
        os.makedirs(model_output_dir, exist_ok=True)
    else:
        model_output_dir = output_dir
    
    try:
        provider_manager = EnhancedProviderManager(config_manager.get_config())
        prompts_path = Path(__file__).resolve().parents[2] / "config" / "prompts"
        prompt_manager = DualPromptManager(config_manager.config, prompt_set, custom_prompts_file=args.custom_prompt_file, prompts_dir=prompts_path)
        doc_generator = DocumentationGenerator(model_output_dir)
        analyzer = EnhancedCOBOLAnalyzer(provider_manager, prompt_manager, rag_integration)
    
        if args:
            from cobol_to_docs.src.utils.cobol_preprocessor import COBOLPreprocessor
            preprocessor = COBOLPreprocessor()
            
            has_many_comments = preprocessor.has_comments(program.content)
            no_comments_arg = getattr(args, "no_comments", False)
            logger.info(f"Verificando comentários em {program.name}: no_comments={no_comments_arg}, has_many_comments={has_many_comments}")
            
            if hasattr(args, "no_comments") and (args.no_comments or has_many_comments):
                if args.no_comments:
                    logger.info(f"Remoção de comentários solicitada para {program.name}")
                else:
                    logger.info(f"Muitos comentários detectados em {program.name} - removendo para análise focada")
                
                original_content = program.content
                program.content, removed_comments = preprocessor.remove_comments(program.content)
                logger.info(f"Removidos {removed_comments} comentários de {program.name}")
            else:
                logger.info(f"Mantendo comentários em {program.name}")
        
        start_time = time.time()
        
        logger.info(f"*** PROVIDER SELECIONADO: {model} ***")
        logger.info(f"Iniciando análise de {program.name} com provider {model}")
        
        analysis_result = analyzer.analyze_program(program, model, books=books, jcl_content=jcl_content, all_copybook_contents=all_copybook_contents)
        analysis_time = time.time() - start_time
        
        provider_usado = getattr(analysis_result, "provider_used", model)
        logger.info(f"*** ANÁLISE CONCLUÍDA COM PROVIDER: {provider_usado} ***")
        
        if not analysis_result.success:
            error_msg = f"ERRO na análise de {program.name} com modelo {model}: {analysis_result.error_message}"
            logger.error(error_msg)
            print(f"\n {error_msg}")
            print(f"   Programa: {program.name}")
            print(f"   Modelo solicitado: {model}")
            print(f"   Tempo decorrido: {analysis_time:.2f}s")
            print(f"   Detalhes do erro: {analysis_result.error_message}")
            return {
                "success": False,
                "program_name": program.name,
                "model": model,
                "error": analysis_result.error_message,
                "tokens_used": 0,
                "analysis_time": analysis_time,
                "output_dir": model_output_dir
            }
        
        cost_info = cost_calculator.tokens_analytics(
            {"usage": [{"total_tokens": analysis_result.tokens_used}]},
            analysis_result.model_used
        )
        
        from cobol_to_docs.src.providers.base_provider import AIResponse
        
        prompts_used = {
            "system_prompt": prompt_manager.get_system_prompt(),
            "original_prompt": getattr(analysis_result, "original_prompt", "Prompt gerado dinamicamente"),
            "main_prompt": getattr(analysis_result, "prompt_used", "Prompt principal não disponível")
        }
        
        ai_response = AIResponse(
            success=True,
            content=analysis_result.content,
            tokens_used=analysis_result.tokens_used,
            model=analysis_result.model_used,
            provider=getattr(analysis_result, "provider_used", "enhanced_mock"),
            prompts_used=prompts_used,
            response_time=analysis_time
        )
        
        doc_result = doc_generator.generate_program_documentation(program, ai_response)
        
        logger.info(f"Análise de {program.name} com {model} bem-sucedida.")
        logger.info(f"Tokens utilizados: {analysis_result.tokens_used:,}")
        logger.info(f"Custo: ${cost_info['cost']:.4f}")
        logger.info(f"Modelo utilizado: {analysis_result.model_used}")
        
        if rag_integration and hasattr(rag_integration, "add_program_analysis_to_knowledge_base"):
            try:
                rag_integration.add_program_analysis_to_knowledge_base(
                    program.name,
                    analysis_result.content,
                    program.content
                )
                logger.info(f"Auto-learning: Conhecimento do programa {program.name} adicionado à base RAG")
            except Exception as e:
                logger.warning(f"Auto-learning falhou para {program.name}: {e}")
        
        return {
            "success": True,
            "program_name": program.name,
            "model": model,
            "tokens_used": analysis_result.tokens_used,
            "analysis_time": analysis_time,
            "output_dir": model_output_dir,
            "files_generated": [doc_result] if doc_result else [],
            "response": analysis_result
        }
        
    except Exception as e:
        logger.error(f"Erro na análise de {program.name} com modelo {model}: {str(e)}")
        return {
            "success": False,
            "program_name": program.name,
            "model": model,
            "error": str(e),
            "tokens_used": 0,
            "analysis_time": 0,
            "output_dir": model_output_dir
        }

def process_programs(program_paths: List[str], copybook_dirs: List[str], output_dir: str, models: List[str], prompt_set: str, config_manager: ConfigManager, args: argparse.Namespace, jcl_content: Optional[str] = None, cobol_parser: COBOLParser = None) -> Tuple[List[Dict[str, Any]], List[CobolProgram]]:
    logger = logging.getLogger(__name__)
    all_results = []
    rag_integration = RAGIntegration(config_manager.get_config()) if args.rag_enabled else None
    cost_calculator = CostCalculator(config_manager.get_ai_config().get("api_costs"))
    parsed_programs: List[CobolProgram] = []
    parsed_books: List[CobolBook] = []

    for p_path in program_paths:
            resolved_path = resolve_file_path(p_path)
            if not os.path.exists(resolved_path):
                logger.error(f"Arquivo de programa COBOL não encontrado: {resolved_path}")
                continue
            
            try:
                programs, books = cobol_parser.parse_file(resolved_path, copybook_dirs=copybook_dirs)
                parsed_programs.extend(programs)
                parsed_books.extend(books)
            except Exception as e:
                logger.error(f"Erro ao processar o arquivo {resolved_path}: {e}")

    if not parsed_programs:
        logger.warning("Nenhum programa COBOL válido encontrado para análise.")
        return [], []

    is_multi_model = len(models) > 1
    all_copybook_contents = {b.name.upper(): b.content for b in parsed_books}

    for program in parsed_programs:
        for model in models:
            result = analyze_program_with_model(
                program, parsed_books, model, output_dir, config_manager, 
                is_multi_model, prompt_set, cost_calculator, rag_integration, 
                args, jcl_content=jcl_content, all_copybook_contents=all_copybook_contents
            )
            all_results.append(result)

    return all_results, parsed_programs

def generate_comparative_report(programs: List[CobolProgram], all_results: List[Dict[str, Any]], output_dir: str) -> None:
    logger = logging.getLogger(__name__)
    try:
        report_path = os.path.join(output_dir, "relatorio_comparativo_modelos.md")
        models_used = sorted(list(set(r["model"] for r in all_results)))
        with open(report_path, "w", encoding="utf-8") as f:
            f.write("# Relatório Comparativo de Modelos\n\n")
            f.write("**Data:** " + datetime.now().strftime("%d/%m/%Y %H:%M:%S") + "\n")
            f.write(f"**Programas Analisados:** {len(programs)}\n")
            f.write(f"**Modelos Utilizados:** {len(models_used)}\n\n")
            for model_name in models_used:
                results = [r for r in all_results if r["model"] == model_name]
                f.write(f"## Modelo: {model_name}\n\n")
                f.write("| Programa | Status | Tempo (s) | Tokens |\n")
                f.write("|----------|--------|-----------|--------|\n")
                for res in results:
                    status = "Sucesso" if res["success"] else "Falha"
                    f.write(f"| {res['program_name']} | {status} | {res['analysis_time']:.2f} | {res['tokens_used']:,} |\n")
                f.write("\n")
        logger.info(f"Relatório comparativo gerado em: {report_path}")
    except Exception as e:
        logger.error(f"Erro ao gerar relatório comparativo: {e}")

def main():
    print("DEBUG: main function started")
    print("DEBUG: Parsing arguments...")
    parser = argparse.ArgumentParser(description="COBOL to Docs - Análise e Documentação de Programas COBOL com IA.")
    parser.add_argument("--fontes", type=str, help="Caminho para um arquivo de texto contendo uma lista de caminhos para programas COBOL.")
    parser.add_argument("--program-path", type=str, help="Caminho para um único programa COBOL a ser analisado.")
    parser.add_argument("--copybook-dirs", type=str, help="Diretórios onde procurar por copybooks, separados por vírgula.")
    parser.add_argument("--output", type=str, default="output", help="Diretório para salvar os resultados.")
    parser.add_argument("--models", type=str, default="enhanced_mock", help="Modelos de IA a serem usados.")
    parser.add_argument("--prompt-set", type=str, default="default", help="Conjunto de prompts a ser utilizado.")
    parser.add_argument("--custom-prompt-file", type=str, help="Caminho para um arquivo JSON com prompts customizados.")
    parser.add_argument("--log-level", type=str, default="INFO", help="Nível de log.")
    parser.add_argument("--jcl-path", type=str, help="Caminho para um arquivo JCL associado.")
    parser.add_argument("--books", type=str, help="Caminho para um arquivo de texto contendo uma lista de caminhos para copybooks.")
    parser.add_argument("--pdf", action="store_true", help="Gera o relatório final em formato PDF.")
    parser.add_argument("--rag-enabled", action="store_true", help="Ativa a integração com RAG.")
    args = parser.parse_args()

    setup_logging(args.log_level)
    logger = logging.getLogger(__name__)

    config_path = Path(__file__).resolve().parents[3] / "config" / "config.yaml"
    config_manager = ConfigManager(config_path=config_path)

    output_dir = args.output
    os.makedirs(output_dir, exist_ok=True)

    models_to_use = parse_models_argument(args.models)
    if not models_to_use:
        logger.error("Nenhum modelo de IA especificado. Use --models.")
        sys.exit(1)

    program_paths = []
    if args.fontes:
        fontes_path = resolve_file_path(args.fontes)
        try:
            with open(fontes_path, "r", encoding="utf-8") as f:
                # Paths inside fontes.txt are relative to the CWD, so we resolve them here
                program_paths.extend([resolve_file_path(line.strip()) for line in f if line.strip()])
        except FileNotFoundError:
            logger.error(f"Arquivo de fontes não encontrado: {fontes_path}")
            sys.exit(1)
    
    if args.program_path:
        program_paths.append(resolve_file_path(args.program_path))

    if not program_paths:
        logger.error("Nenhum programa COBOL fornecido. Use --fontes ou --program-path.")
        sys.exit(1)

    copybook_dirs = [resolve_file_path(d.strip()) for d in args.copybook_dirs.split(",")] if args.copybook_dirs else []

    jcl_content = None
    if args.jcl_path:
        jcl_path = resolve_file_path(args.jcl_path)
        try:
            with open(jcl_path, "r", encoding="utf-8") as f:
                jcl_content = f.read()
        except FileNotFoundError:
            logger.warning(f"Arquivo JCL não encontrado: {jcl_path}")
            jcl_content = None

    cobol_parser = COBOLParser()
    all_results, parsed_programs = process_programs(program_paths, copybook_dirs, output_dir, models_to_use, args.prompt_set, config_manager, args, jcl_content, cobol_parser)

    if len(models_to_use) > 1 and parsed_programs:
        generate_comparative_report(parsed_programs, all_results, output_dir)

    print("DEBUG: Processing complete.")
    logger.info("Processamento concluído.")
    print("DEBUG: main function finished")

if __name__ == "__main__":
    main()

