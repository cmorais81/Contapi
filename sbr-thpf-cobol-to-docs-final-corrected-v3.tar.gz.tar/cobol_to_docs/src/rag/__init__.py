"""
RAG (Retrieval-Augmented Generation) Module for COBOL Analysis
Provides advanced knowledge retrieval and context enhancement for COBOL code analysis.
"""

from .cobol_rag_system import CobolRAGSystem, CobolKnowledgeItem
from .rag_integration import RAGIntegration

__all__ = ['CobolRAGSystem', 'CobolKnowledgeItem', 'RAGIntegration']
