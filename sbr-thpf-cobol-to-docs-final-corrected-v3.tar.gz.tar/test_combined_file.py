
import sys
import os
from pathlib import Path

# Adjust sys.path to include the project root for imports
script_dir = Path(__file__).parent
project_root = script_dir
sys.path.insert(0, str(project_root))
sys.path.insert(0, str(project_root / 'cobol_to_docs'))
sys.path.insert(0, str(project_root / 'cobol_to_docs' / 'src'))

from cobol_to_docs.src.parsers.cobol_parser import COBOLParser

# Path to the combined COBOL file
combined_file_path = project_root / "examples" / "combined_program_copybook.cbl"

def test_combined_file_parsing():
    parser = COBOLParser()
    programs, copybooks = parser.parse_file(str(combined_file_path))

    print(f"\n--- Teste de Parsing de Arquivo Combinado ---")
    print(f"Arquivo: {combined_file_path}")
    print(f"Programas encontrados: {len(programs)}")
    print(f"Copybooks encontrados: {len(copybooks)}")

    assert len(programs) == 1
    assert len(copybooks) == 1

    program = programs[0]
    copybook = copybooks[0]

    print(f"\nPrograma Nome: {program.name}")
    print(f"Programa Conteúdo (primeiras 100 chars): {program.content[:100]}...")
    print(f"Programa File Path: {program.file_path}")
    assert program.name == "COMBINED-TEST"
    assert "MY-DATA-FIELD" in program.content # Check if copybook content was resolved
    assert program.file_path == str(combined_file_path)

    print(f"\nCopybook Nome: {copybook.name}")
    print(f"Copybook Conteúdo (primeiras 100 chars): {copybook.content[:100]}...")
    print(f"Copybook File Path: {copybook.file_path}")
    assert copybook.name == "MYCOPYBK"
    assert "MY-DATA-FIELD" in copybook.content
    assert copybook.file_path == str(combined_file_path)

    print("\n--- Teste de Parsing de Arquivo Combinado CONCLUÍDO COM SUCESSO ---")

if __name__ == "__main__":
    test_combined_file_parsing()

