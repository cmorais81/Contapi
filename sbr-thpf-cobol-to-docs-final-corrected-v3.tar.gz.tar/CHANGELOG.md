# CHANGELOG

## Versão 0.0.2 (2025-10-15)

### Correções e Melhorias

- **Estrutura do Projeto e Instalação:**
    - Corrigido `setup.py` para usar `find_packages()` e incluir corretamente todos os módulos do pacote `cobol_to_docs`.
    - Ajustados os `entry_points` para `cobol_to_docs = cobol_to_docs.runner.main:main`.
    - Garantida a inclusão de arquivos não-Python (como `.yaml`) no pacote através de `include_package_data=True` e `MANIFEST.in`.

- **Imports de Módulos:**
    - Refatorados os imports em todos os arquivos Python dentro de `cobol_to_docs/src/` para usar imports relativos e absolutos baseados na estrutura do pacote (`from cobol_to_docs.src.module import ...`).
    - Adicionados arquivos `__init__.py` em todos os diretórios relevantes para que sejam reconhecidos como pacotes Python.

- **Tratamento de Caminhos de Arquivo:**
    - Implementada a função `resolve_file_path` em `cobol_to_docs/runner/main.py` para lidar com a localização de arquivos de configuração (`config.yaml`), prompts e arquivos de entrada (`fontes.txt`, `BOOKS.txt`).
    - A função `resolve_file_path` agora prioriza caminhos absolutos fornecidos, depois procura no diretório de execução e, por último, dentro do pacote instalado.
    - Removidas as manipulações de `sys.path` que eram necessárias para execução local, mas conflitavam com a instalação via `pip`.

- **Configuração e Provedores de IA:**
    - Corrigido o carregamento de modelos e provedores na classe `EnhancedProviderManager` para garantir que as configurações sejam lidas corretamente do `config.yaml`.
    - Ajustadas as f-strings em `enhanced_provider_manager.py` para evitar erros de sintaxe com aspas aninhadas.
    - Adicionada a configuração do modelo `enhanced-mock-gpt-4` ao `config.yaml` para o provedor `enhanced_mock`.

- **Execução e Testes:**
    - Validada a execução do `main.py` com um programa COBOL de exemplo e o provedor `enhanced_mock`, gerando o payload esperado.
    - Confirmado que a aplicação agora funciona corretamente após a instalação via `pip` e a execução a partir de qualquer diretório.

### Próximos Passos

- **Documentação:**
    - Atualizar o `README.md` com instruções claras de instalação e uso.
    - Detalhar a estrutura do projeto e as opções de configuração.
- **Testes:**
    - Implementar testes unitários e de integração para garantir a estabilidade das correções.
- **Funcionalidades:**
    - Continuar o desenvolvimento das funcionalidades de RAG e análise de COBOL.
