            )
        return self._sync_session_factory
    
    async def get_async_session(self) -> AsyncGenerator[AsyncSession, None]:
        """Gera sessão assíncrona"""
        async with self.async_session_factory() as session:
            try:
                yield session
                await session.commit()
            except Exception:
                await session.rollback()
                raise
            finally:
                await session.close()
    
    def get_sync_session(self):
        """Gera sessão síncrona"""
        with self.sync_session_factory() as session:
            try:
                yield session
                session.commit()
            except Exception:
                session.rollback()
                raise
            finally:
                session.close()
    
    async def create_tables(self):
        """Cria todas as tabelas"""
        async with self.async_engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
    
    async def drop_tables(self):
        """Remove todas as tabelas"""
        async with self.async_engine.begin() as conn:
            await conn.run_sync(Base.metadata.drop_all)
    
    async def close(self):
        """Fecha conexões"""
        if self._async_engine:
            await self._async_engine.dispose()
        if self._sync_engine:
            self._sync_engine.dispose()


# Instância global do gerenciador
db_manager = DatabaseManager()


# Dependency para FastAPI
async def get_db_session() -> AsyncGenerator[AsyncSession, None]:
    """Dependency para obter sessão de banco"""
    async for session in db_manager.get_async_session():
        yield session


# Alias para compatibilidade
async def get_async_session() -> AsyncGenerator[AsyncSession, None]:
    """Alias para get_db_session"""
    async for session in get_db_session():
        yield session


# Configurações para SQLite em testes
def configure_sqlite_for_tests():
    """Configura SQLite para testes"""
    test_engine = create_async_engine(
        "sqlite+aiosqlite:///./test.db",
        poolclass=StaticPool,
        connect_args={"check_same_thread": False},