"""
Configurações da aplicação
"""

import os
from functools import lru_cache
from typing import List, Optional

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    SECRET_KEY: str = "your-secret-key-change-in-production"
    """Configurações da aplicação"""
    
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore"
    )
    
    # Database Configuration
    database_url: str = Field(
        default="postgresql+asyncpg://postgres:password@localhost:5432/governance_db",
        description="URL de conexão com banco de dados"
    )
    database_pool_size: int = Field(default=20, description="Tamanho do pool de conexões")
    database_max_overflow: int = Field(default=30, description="Máximo de conexões extras")
    database_pool_recycle: int = Field(default=3600, description="Tempo para reciclar conexões (segundos)")
    database_echo: bool = Field(default=False, description="Log de queries SQL")
    
    # SQLite Configuration (para desenvolvimento)
    use_sqlite: bool = Field(default=False, description="Usar SQLite em desenvolvimento")
    sqlite_db_path: str = Field(default="./governance_data.db", description="Caminho do arquivo SQLite")
    
    # Mock Data Configuration
    enable_mock_data: bool = Field(default=False, description="Habilitar dados mocados")
    mock_data_size: int = Field(default=100, description="Quantidade de registros mocados")
    
    # Environment
    environment: str = Field(default="development", description="Ambiente de execução")
    
    # Redis Configuration
    redis_url: str = Field(default="redis://localhost:6379/0", description="URL do Redis")
    redis_cache_ttl: int = Field(default=300, description="TTL padrão do cache (segundos)")
    
    # API Configuration
    api_host: str = Field(default="0.0.0.0", description="Host da API")