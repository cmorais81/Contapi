# 📓 Notebooks Databricks - API de Governança de Dados

**Desenvolvido por:** Carlos Morais  
**Versão:** 2.1  
**Data:** Janeiro 2025  

## 🎯 Objetivo

Estes notebooks extraem dados de diferentes fontes para alimentar o modelo de governança de dados com 56 tabelas baseado no ODCS v3.0.2.

## 📚 Notebooks Disponíveis

### 1. 🏛️ Unity Catalog Extractor
**Arquivo:** `notebook_unity_catalog_extractor.py`

#### **Funcionalidades:**
- ✅ Extração de **metadados completos** do Unity Catalog
- ✅ **Catálogos, schemas, tabelas, colunas** com relacionamentos
- ✅ **Volumes, external locations** e configurações
- ✅ **Grants e permissões** detalhadas
- ✅ **Lineage de dados** automático
- ✅ **Qualidade de dados** e estatísticas
- ✅ **Mapeamento direto** para modelo de governança

#### **Dados Extraídos:**
| Categoria | Tabelas | Descrição |
|-----------|---------|-----------|
| **Metadados** | `catalogs`, `schemas`, `tables`, `columns` | Estrutura completa |
| **Volumes** | `volumes`, `volume_files` | Armazenamento |
| **Localizações** | `external_locations` | Configurações externas |
| **Segurança** | `grants`, `permissions` | Controle de acesso |
| **Lineage** | `table_lineage`, `column_lineage` | Rastreabilidade |
| **Qualidade** | `table_statistics`, `column_statistics` | Métricas |

#### **Execução:**
```python
# Configurar parâmetros
TARGET_DATABASE = "governance_data"
EXTRACTION_LEVEL = "full"  # full, metadata, basic

# Executar extração
%run ./notebook_unity_catalog_extractor
```

### 2. ☁️ Azure SPN Extractor  
**Arquivo:** `notebook_azure_spn_extractor.py`

#### **Funcionalidades:**
- ✅ **Autenticação via Service Principal** (SPN)
- ✅ Extração de **18 serviços Azure** diferentes
- ✅ **Resource Groups, Storage, SQL, Data Factory**
- ✅ **Synapse, Monitor, Azure AD** completos
- ✅ **Métricas em tempo real** do Azure Monitor
- ✅ **Integração automática** com Unity Catalog

#### **Serviços Azure Extraídos:**
| Serviço | Dados | Tabelas |
|---------|-------|---------|
| **Resource Manager** | Resource Groups, Resources | 2 tabelas |
| **Storage** | Storage Accounts, Containers | 2 tabelas |
| **SQL Database** | Servers, Databases | 2 tabelas |
| **Data Factory** | Factories, Pipelines, Datasets | 3 tabelas |
| **Synapse** | Workspaces, SQL Pools, Spark Pools | 3 tabelas |
| **Monitor** | Métricas, Logs | 1 tabela |
| **Azure AD** | Usuários, Grupos | 2 tabelas |
| **Integração** | Data Sources, External Locations | 3 tabelas |

#### **Configuração SPN:**
```bash
# Criar scope de secrets no Databricks
databricks secrets create-scope --scope azure-secrets

# Adicionar credenciais
databricks secrets put --scope azure-secrets --key tenant-id
databricks secrets put --scope azure-secrets --key client-id  
databricks secrets put --scope azure-secrets --key client-secret
databricks secrets put --scope azure-secrets --key subscription-id
```

#### **Permissões Necessárias:**
- **Reader** - Listar recursos
- **Storage Blob Data Reader** - Acessar storage
- **SQL DB Contributor** - Acessar databases
- **Data Factory Contributor** - Acessar pipelines
- **Synapse Contributor** - Acessar workspaces
- **Monitoring Reader** - Acessar métricas
- **Directory.Read.All** - Acessar Azure AD

## 🔄 Fluxo de Execução Recomendado

### **1. Execução Sequencial**
```python
# 1. Extrair dados do Unity Catalog
%run ./notebook_unity_catalog_extractor

# 2. Extrair dados do Azure
%run ./notebook_azure_spn_extractor

# 3. Validar integração
%sql
SELECT 
    'Unity Catalog' as source,
    COUNT(*) as total_tables
FROM governance_data.tables
UNION ALL
SELECT 
    'Azure' as source,
    COUNT(*) as total_resources
FROM governance_data.azure_resources
```

### **2. Agendamento Automático**
```python
# Configurar job no Databricks
{
    "name": "Governance Data Extraction",
    "tasks": [
        {
            "task_key": "unity_catalog",
            "notebook_task": {
                "notebook_path": "/notebooks/unity_catalog_extractor"
            }
        },
        {
            "task_key": "azure_extraction",
            "notebook_task": {
                "notebook_path": "/notebooks/azure_spn_extractor"
            },
            "depends_on": [{"task_key": "unity_catalog"}]
        }
    ],
    "schedule": {
        "quartz_cron_expression": "0 0 2 * * ?",  # Diário às 2h
        "timezone_id": "America/Sao_Paulo"
    }
}
```

## 📊 Mapeamento para Modelo de Governança

### **Tabelas Principais Alimentadas:**

#### **🏛️ Do Unity Catalog:**
- `data_contracts` ← `tables` + `table_info`
- `entities` ← `tables` + `columns`
- `data_sources` ← `external_locations` + `volumes`
- `quality_rules` ← `table_constraints` + `column_info`
- `lineage_relationships` ← `table_lineage` + `column_lineage`
- `access_policies` ← `grants` + `effective_permissions`

#### **☁️ Do Azure:**
- `data_sources` ← `azure_storage_accounts` + `azure_sql_databases`
- `processing_systems` ← `azure_data_factories` + `azure_synapse_workspaces`
- `users` ← `azure_ad_users`
- `user_groups` ← `azure_ad_groups`
- `system_metrics` ← `azure_monitor_metrics`
- `infrastructure_resources` ← `azure_resources`

### **Integração Automática:**
```python
# Exemplo de integração
def integrate_sources():
    # Unity Catalog tables → Data Contracts
    uc_tables = spark.sql("SELECT * FROM governance_data.tables")
    
    # Azure SQL databases → Data Sources  
    azure_dbs = spark.sql("SELECT * FROM governance_data.azure_sql_databases")
    
    # Criar mapeamento unificado
    unified_sources = uc_tables.union(azure_dbs.select(...))
    
    # Salvar no modelo de governança
    unified_sources.write.mode("overwrite").saveAsTable("governance_data.unified_data_sources")
```

## 🔧 Configuração e Instalação

### **1. Dependências Python:**
```python
# Instalar no cluster Databricks
%pip install azure-identity azure-mgmt-resource azure-mgmt-storage
%pip install azure-mgmt-sql azure-mgmt-datafactory azure-mgmt-synapse
%pip install azure-mgmt-monitor msal requests pyodbc
```

### **2. Configuração de Cluster:**
```json
{
    "spark_conf": {
        "spark.sql.adaptive.enabled": "true",
        "spark.sql.adaptive.coalescePartitions.enabled": "true"
    },
    "custom_tags": {
        "project": "governance-data-api",
        "environment": "production"
    }
}
```

### **3. Variáveis de Ambiente:**
```python
# Configurar no notebook
TARGET_DATABASE = "governance_data"
BATCH_SIZE = 1000
EXTRACTION_LEVEL = "full"  # full, metadata, basic
ENABLE_LINEAGE = True
ENABLE_STATISTICS = True
```

## 📈 Monitoramento e Logs

### **Métricas Coletadas:**
- ✅ **Tempo de execução** por notebook
- ✅ **Número de registros** extraídos
- ✅ **Taxa de sucesso** por fonte
- ✅ **Erros e warnings** detalhados
- ✅ **Uso de recursos** (CPU, memória)

### **Relatórios Automáticos:**
```python
# Relatório de extração
def generate_extraction_report():
    report = {
        "extraction_date": datetime.now(),
        "unity_catalog_tables": count_records("tables"),
        "azure_resources": count_records("azure_resources"),
        "total_data_sources": count_records("unified_data_sources"),
        "execution_time": calculate_execution_time(),
        "success_rate": calculate_success_rate()
    }
    
    # Salvar relatório
    spark.createDataFrame([report]).write.mode("append").saveAsTable("governance_data.extraction_reports")
```

## 🚀 Próximos Passos

### **1. Expansão de Fontes:**
- **AWS** - S3, RDS, Redshift, Glue
- **GCP** - BigQuery, Cloud Storage, Dataflow
- **On-premises** - SQL Server, Oracle, Hadoop

### **2. Melhorias:**
- **Delta Live Tables** - Pipeline em tempo real
- **Auto Loader** - Ingestão incremental
- **MLflow** - Versionamento de modelos
- **Databricks Workflows** - Orquestração avançada

### **3. Integração API:**
```python
# Conectar com API de Governança
import requests

def sync_with_governance_api():
    # Obter dados extraídos
    data = spark.sql("SELECT * FROM governance_data.unified_data_sources").collect()
    
    # Enviar para API
    for record in data:
        response = requests.post(
            "http://governance-api/api/v1/data-sources",
            json=record.asDict(),
            headers={"Authorization": f"Bearer {api_token}"}
        )
```

## 📚 Documentação Adicional

- 📖 **[Modelo de Dados](modelo_governanca_v21.dbml)** - 56 tabelas ODCS v3.0.2
- 🔖 **[Checkpoint V2.1](🔖5-CHECKPOINT-API-GOVERNANCA-V21-FINAL.md)** - Estado atual
- 🚀 **[API de Governança](DEPLOY_README.md)** - Documentação completa
- 📊 **[Dashboard Databricks](https://databricks.com/governance-dashboard)** - Monitoramento

---

**Desenvolvido por Carlos Morais** 🚀  
**Para uso com API de Governança de Dados V2.1**

