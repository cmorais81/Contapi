# Databricks notebook source
# MAGIC %md
# MAGIC # ☁️ Azure SPN Data Extractor
# MAGIC 
# MAGIC **Desenvolvido por:** Carlos Morais  
# MAGIC **Objetivo:** Extrair dados dos serviços Azure via Service Principal para alimentar a API de Governança de Dados  
# MAGIC **Modelo:** 56 tabelas baseadas no ODCS v3.0.2  
# MAGIC 
# MAGIC ## 🎯 Dados Extraídos do Azure
# MAGIC 
# MAGIC - **Azure Data Factory** → `pipelines`, `datasets`, `activities`
# MAGIC - **Azure Synapse** → `sql_pools`, `spark_pools`, `workspaces`
# MAGIC - **Azure Storage** → `storage_accounts`, `containers`, `blobs`
# MAGIC - **Azure SQL Database** → `databases`, `tables`, `columns`
# MAGIC - **Azure Active Directory** → `users`, `groups`, `applications`
# MAGIC - **Azure Monitor** → `metrics`, `logs`, `alerts`
# MAGIC - **Azure Resource Manager** → `resources`, `resource_groups`
# MAGIC - **Azure Purview** → `data_sources`, `classifications`, `glossary`

# COMMAND ----------

# MAGIC %md
# MAGIC ## 🔧 Configuração e Imports

# COMMAND ----------

import json
import pandas as pd
from datetime import datetime, timedelta
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
import requests
import uuid
from azure.identity import ClientSecretCredential
from azure.mgmt.resource import ResourceManagementClient
from azure.mgmt.storage import StorageManagementClient
from azure.mgmt.sql import SqlManagementClient
from azure.mgmt.datafactory import DataFactoryManagementClient
from azure.mgmt.synapse import SynapseManagementClient
from azure.mgmt.monitor import MonitorManagementClient
import pyodbc

# Configurações Azure SPN
TENANT_ID = dbutils.secrets.get(scope="azure-secrets", key="tenant-id")
CLIENT_ID = dbutils.secrets.get(scope="azure-secrets", key="client-id")
CLIENT_SECRET = dbutils.secrets.get(scope="azure-secrets", key="client-secret")
SUBSCRIPTION_ID = dbutils.secrets.get(scope="azure-secrets", key="subscription-id")

# Configurações do projeto
TARGET_DATABASE = "governance_data"
BATCH_SIZE = 1000
EXTRACTION_DATE = datetime.now()

print(f"☁️ Iniciando extração do Azure via SPN - {EXTRACTION_DATE}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 🔐 Autenticação Azure

# COMMAND ----------

def setup_azure_credentials():
    """Configura credenciais Azure"""
    try:
        credential = ClientSecretCredential(
            tenant_id=TENANT_ID,
            client_id=CLIENT_ID,
            client_secret=CLIENT_SECRET
        )
        
        # Testar autenticação
        resource_client = ResourceManagementClient(credential, SUBSCRIPTION_ID)
        subscription = resource_client.subscriptions.get(SUBSCRIPTION_ID)
        
        print(f"✅ Autenticação Azure bem-sucedida")
        print(f"📋 Subscription: {subscription.display_name}")
        
        return credential
        
    except Exception as e:
        print(f"❌ Erro na autenticação Azure: {str(e)}")
        raise

# Configurar credenciais
azure_credential = setup_azure_credentials()

# COMMAND ----------

# MAGIC %md
# MAGIC ## 🗄️ Funções Auxiliares

# COMMAND ----------

def generate_uuid():
    """Gera UUID único"""
    return str(uuid.uuid4())

def safe_extract(func, default_value=None):
    """Executa função com tratamento de erro"""
    try:
        return func()
    except Exception as e:
        print(f"⚠️ Erro na extração: {str(e)}")
        return default_value

def save_to_table(df, table_name, mode="append"):
    """Salva DataFrame na tabela de destino"""
    try:
        if df and len(df) > 0:
            spark_df = spark.createDataFrame(df)
            spark_df.write.mode(mode).saveAsTable(f"{TARGET_DATABASE}.{table_name}")
            count = len(df)
            print(f"✅ {count} registros salvos em {TARGET_DATABASE}.{table_name}")
            return count
        else:
            print(f"⚠️ Nenhum dado para salvar em {table_name}")
            return 0
    except Exception as e:
        print(f"❌ Erro ao salvar {table_name}: {str(e)}")
        return 0

def get_azure_client(service_type):
    """Retorna cliente Azure para serviço específico"""
    clients = {
        'resource': ResourceManagementClient(azure_credential, SUBSCRIPTION_ID),
        'storage': StorageManagementClient(azure_credential, SUBSCRIPTION_ID),
        'sql': SqlManagementClient(azure_credential, SUBSCRIPTION_ID),
        'datafactory': DataFactoryManagementClient(azure_credential, SUBSCRIPTION_ID),
        'synapse': SynapseManagementClient(azure_credential, SUBSCRIPTION_ID),
        'monitor': MonitorManagementClient(azure_credential, SUBSCRIPTION_ID)
    }
    return clients.get(service_type)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 🏢 1. Extração de Resource Groups e Resources

# COMMAND ----------

def extract_resource_groups():
    """Extrai Resource Groups do Azure"""
    print("🏢 Extraindo Resource Groups...")
    
    resource_groups = []
    resources = []
    
    try:
        resource_client = get_azure_client('resource')
        
        # Extrair Resource Groups
        for rg in resource_client.resource_groups.list():
            rg_info = {
                "id": generate_uuid(),
                "name": rg.name,
                "location": rg.location,
                "subscription_id": SUBSCRIPTION_ID,
                "tags": json.dumps(rg.tags) if rg.tags else "{}",
                "created_at": EXTRACTION_DATE,
                "updated_at": EXTRACTION_DATE,
                "status": "active",
                "resource_type": "resource_group"
            }
            resource_groups.append(rg_info)
            
            # Extrair Resources do Resource Group
            try:
                for resource in resource_client.resources.list_by_resource_group(rg.name):
                    resource_info = {
                        "id": generate_uuid(),
                        "name": resource.name,
                        "resource_group": rg.name,
                        "resource_type": resource.type,
                        "location": resource.location,
                        "subscription_id": SUBSCRIPTION_ID,
                        "tags": json.dumps(resource.tags) if resource.tags else "{}",
                        "created_at": EXTRACTION_DATE,
                        "updated_at": EXTRACTION_DATE,
                        "status": "active",
                        "sku": getattr(resource, 'sku', {}).get('name') if hasattr(resource, 'sku') else None
                    }
                    resources.append(resource_info)
                    
            except Exception as e:
                print(f"⚠️ Erro ao listar recursos do RG {rg.name}: {str(e)}")
    
    except Exception as e:
        print(f"❌ Erro ao extrair Resource Groups: {str(e)}")
    
    # Salvar dados
    save_to_table(resource_groups, "azure_resource_groups")
    save_to_table(resources, "azure_resources")
    
    return len(resource_groups), len(resources)

# Executar extração
rg_count, res_count = extract_resource_groups()
print(f"📊 Extraídos: {rg_count} Resource Groups, {res_count} Resources")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 🗄️ 2. Extração de Storage Accounts

# COMMAND ----------

def extract_storage_accounts():
    """Extrai Storage Accounts do Azure"""
    print("🗄️ Extraindo Storage Accounts...")
    
    storage_accounts = []
    containers = []
    
    try:
        storage_client = get_azure_client('storage')
        
        # Listar todas as Storage Accounts
        for storage_account in storage_client.storage_accounts.list():
            sa_info = {
                "id": generate_uuid(),
                "name": storage_account.name,
                "resource_group": storage_account.id.split('/')[4],  # Extrair RG do ID
                "location": storage_account.location,
                "account_type": storage_account.sku.name,
                "access_tier": getattr(storage_account, 'access_tier', None),
                "https_only": getattr(storage_account, 'enable_https_traffic_only', False),
                "created_at": EXTRACTION_DATE,
                "updated_at": EXTRACTION_DATE,
                "status": "active",
                "replication_type": storage_account.sku.name,
                "tags": json.dumps(storage_account.tags) if storage_account.tags else "{}"
            }
            storage_accounts.append(sa_info)
            
            # Extrair containers (se possível)
            try:
                rg_name = storage_account.id.split('/')[4]
                containers_list = storage_client.blob_containers.list(
                    resource_group_name=rg_name,
                    account_name=storage_account.name
                )
                
                for container in containers_list:
                    container_info = {
                        "id": generate_uuid(),
                        "name": container.name,
                        "storage_account_id": sa_info["id"],
                        "storage_account_name": storage_account.name,
                        "public_access": getattr(container, 'public_access', 'none'),
                        "created_at": EXTRACTION_DATE,
                        "updated_at": EXTRACTION_DATE,
                        "status": "active",
                        "container_type": "blob"
                    }
                    containers.append(container_info)
                    
            except Exception as e:
                print(f"⚠️ Erro ao listar containers de {storage_account.name}: {str(e)}")
    
    except Exception as e:
        print(f"❌ Erro ao extrair Storage Accounts: {str(e)}")
    
    # Salvar dados
    save_to_table(storage_accounts, "azure_storage_accounts")
    save_to_table(containers, "azure_storage_containers")
    
    return len(storage_accounts), len(containers)

# Executar extração
sa_count, cont_count = extract_storage_accounts()
print(f"📊 Extraídos: {sa_count} Storage Accounts, {cont_count} Containers")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 🗃️ 3. Extração de SQL Databases

# COMMAND ----------

def extract_sql_databases():
    """Extrai SQL Databases do Azure"""
    print("🗃️ Extraindo SQL Databases...")
    
    sql_servers = []
    sql_databases = []
    
    try:
        sql_client = get_azure_client('sql')
        
        # Listar SQL Servers
        for server in sql_client.servers.list():
            server_info = {
                "id": generate_uuid(),
                "name": server.name,
                "resource_group": server.id.split('/')[4],
                "location": server.location,
                "version": server.version,
                "admin_login": server.administrator_login,
                "fqdn": server.fully_qualified_domain_name,
                "created_at": EXTRACTION_DATE,
                "updated_at": EXTRACTION_DATE,
                "status": "active",
                "tags": json.dumps(server.tags) if server.tags else "{}"
            }
            sql_servers.append(server_info)
            
            # Listar databases do servidor
            try:
                rg_name = server.id.split('/')[4]
                databases = sql_client.databases.list_by_server(
                    resource_group_name=rg_name,
                    server_name=server.name
                )
                
                for db in databases:
                    if db.name != 'master':  # Pular database master
                        db_info = {
                            "id": generate_uuid(),
                            "name": db.name,
                            "server_id": server_info["id"],
                            "server_name": server.name,
                            "resource_group": rg_name,
                            "location": db.location,
                            "edition": getattr(db, 'edition', None),
                            "service_tier": getattr(db, 'service_level_objective', None),
                            "max_size_bytes": getattr(db, 'max_size_bytes', None),
                            "collation": getattr(db, 'collation', None),
                            "created_at": EXTRACTION_DATE,
                            "updated_at": EXTRACTION_DATE,
                            "status": "active",
                            "tags": json.dumps(db.tags) if db.tags else "{}"
                        }
                        sql_databases.append(db_info)
                        
            except Exception as e:
                print(f"⚠️ Erro ao listar databases do servidor {server.name}: {str(e)}")
    
    except Exception as e:
        print(f"❌ Erro ao extrair SQL Databases: {str(e)}")
    
    # Salvar dados
    save_to_table(sql_servers, "azure_sql_servers")
    save_to_table(sql_databases, "azure_sql_databases")
    
    return len(sql_servers), len(sql_databases)

# Executar extração
srv_count, db_count = extract_sql_databases()
print(f"📊 Extraídos: {srv_count} SQL Servers, {db_count} Databases")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 🏭 4. Extração de Data Factory

# COMMAND ----------

def extract_data_factories():
    """Extrai Data Factories do Azure"""
    print("🏭 Extraindo Data Factories...")
    
    data_factories = []
    pipelines = []
    datasets = []
    
    try:
        df_client = get_azure_client('datafactory')
        
        # Listar Data Factories
        for factory in df_client.factories.list():
            factory_info = {
                "id": generate_uuid(),
                "name": factory.name,
                "resource_group": factory.id.split('/')[4],
                "location": factory.location,
                "version": getattr(factory, 'version', 'V2'),
                "created_at": EXTRACTION_DATE,
                "updated_at": EXTRACTION_DATE,
                "status": "active",
                "tags": json.dumps(factory.tags) if factory.tags else "{}"
            }
            data_factories.append(factory_info)
            
            try:
                rg_name = factory.id.split('/')[4]
                
                # Listar Pipelines
                try:
                    pipelines_list = df_client.pipelines.list_by_factory(
                        resource_group_name=rg_name,
                        factory_name=factory.name
                    )
                    
                    for pipeline in pipelines_list:
                        pipeline_info = {
                            "id": generate_uuid(),
                            "name": pipeline.name,
                            "factory_id": factory_info["id"],
                            "factory_name": factory.name,
                            "description": getattr(pipeline, 'description', ''),
                            "created_at": EXTRACTION_DATE,
                            "updated_at": EXTRACTION_DATE,
                            "status": "active",
                            "pipeline_type": "data_pipeline"
                        }
                        pipelines.append(pipeline_info)
                        
                except Exception as e:
                    print(f"⚠️ Erro ao listar pipelines de {factory.name}: {str(e)}")
                
                # Listar Datasets
                try:
                    datasets_list = df_client.datasets.list_by_factory(
                        resource_group_name=rg_name,
                        factory_name=factory.name
                    )
                    
                    for dataset in datasets_list:
                        dataset_info = {
                            "id": generate_uuid(),
                            "name": dataset.name,
                            "factory_id": factory_info["id"],
                            "factory_name": factory.name,
                            "dataset_type": getattr(dataset, 'type', 'unknown'),
                            "description": getattr(dataset, 'description', ''),
                            "created_at": EXTRACTION_DATE,
                            "updated_at": EXTRACTION_DATE,
                            "status": "active"
                        }
                        datasets.append(dataset_info)
                        
                except Exception as e:
                    print(f"⚠️ Erro ao listar datasets de {factory.name}: {str(e)}")
                    
            except Exception as e:
                print(f"⚠️ Erro ao processar factory {factory.name}: {str(e)}")
    
    except Exception as e:
        print(f"❌ Erro ao extrair Data Factories: {str(e)}")
    
    # Salvar dados
    save_to_table(data_factories, "azure_data_factories")
    save_to_table(pipelines, "azure_pipelines")
    save_to_table(datasets, "azure_datasets")
    
    return len(data_factories), len(pipelines), len(datasets)

# Executar extração
df_count, pipe_count, ds_count = extract_data_factories()
print(f"📊 Extraídos: {df_count} Data Factories, {pipe_count} Pipelines, {ds_count} Datasets")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 🔬 5. Extração de Synapse Workspaces

# COMMAND ----------

def extract_synapse_workspaces():
    """Extrai Synapse Workspaces do Azure"""
    print("🔬 Extraindo Synapse Workspaces...")
    
    workspaces = []
    sql_pools = []
    spark_pools = []
    
    try:
        synapse_client = get_azure_client('synapse')
        
        # Listar Workspaces
        for workspace in synapse_client.workspaces.list():
            workspace_info = {
                "id": generate_uuid(),
                "name": workspace.name,
                "resource_group": workspace.id.split('/')[4],
                "location": workspace.location,
                "default_data_lake_storage": getattr(workspace, 'default_data_lake_storage', {}).get('account_url', ''),
                "sql_admin_login": getattr(workspace, 'sql_administrator_login', ''),
                "created_at": EXTRACTION_DATE,
                "updated_at": EXTRACTION_DATE,
                "status": "active",
                "tags": json.dumps(workspace.tags) if workspace.tags else "{}"
            }
            workspaces.append(workspace_info)
            
            try:
                rg_name = workspace.id.split('/')[4]
                
                # Listar SQL Pools
                try:
                    sql_pools_list = synapse_client.sql_pools.list_by_workspace(
                        resource_group_name=rg_name,
                        workspace_name=workspace.name
                    )
                    
                    for sql_pool in sql_pools_list:
                        pool_info = {
                            "id": generate_uuid(),
                            "name": sql_pool.name,
                            "workspace_id": workspace_info["id"],
                            "workspace_name": workspace.name,
                            "sku": getattr(sql_pool, 'sku', {}).get('name', ''),
                            "max_size_bytes": getattr(sql_pool, 'max_size_bytes', None),
                            "collation": getattr(sql_pool, 'collation', ''),
                            "created_at": EXTRACTION_DATE,
                            "updated_at": EXTRACTION_DATE,
                            "status": "active",
                            "pool_type": "sql"
                        }
                        sql_pools.append(pool_info)
                        
                except Exception as e:
                    print(f"⚠️ Erro ao listar SQL pools de {workspace.name}: {str(e)}")
                
                # Listar Spark Pools
                try:
                    spark_pools_list = synapse_client.big_data_pools.list_by_workspace(
                        resource_group_name=rg_name,
                        workspace_name=workspace.name
                    )
                    
                    for spark_pool in spark_pools_list:
                        pool_info = {
                            "id": generate_uuid(),
                            "name": spark_pool.name,
                            "workspace_id": workspace_info["id"],
                            "workspace_name": workspace.name,
                            "node_size": getattr(spark_pool, 'node_size', ''),
                            "node_count": getattr(spark_pool, 'node_count', 0),
                            "auto_scale": json.dumps(getattr(spark_pool, 'auto_scale', {})),
                            "spark_version": getattr(spark_pool, 'spark_version', ''),
                            "created_at": EXTRACTION_DATE,
                            "updated_at": EXTRACTION_DATE,
                            "status": "active",
                            "pool_type": "spark"
                        }
                        spark_pools.append(pool_info)
                        
                except Exception as e:
                    print(f"⚠️ Erro ao listar Spark pools de {workspace.name}: {str(e)}")
                    
            except Exception as e:
                print(f"⚠️ Erro ao processar workspace {workspace.name}: {str(e)}")
    
    except Exception as e:
        print(f"❌ Erro ao extrair Synapse Workspaces: {str(e)}")
    
    # Salvar dados
    save_to_table(workspaces, "azure_synapse_workspaces")
    save_to_table(sql_pools, "azure_synapse_sql_pools")
    save_to_table(spark_pools, "azure_synapse_spark_pools")
    
    return len(workspaces), len(sql_pools), len(spark_pools)

# Executar extração
ws_count, sql_count, spark_count = extract_synapse_workspaces()
print(f"📊 Extraídos: {ws_count} Workspaces, {sql_count} SQL Pools, {spark_count} Spark Pools")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 📊 6. Extração de Métricas do Azure Monitor

# COMMAND ----------

def extract_azure_monitor_metrics():
    """Extrai métricas do Azure Monitor"""
    print("📊 Extraindo métricas do Azure Monitor...")
    
    metrics_data = []
    
    try:
        monitor_client = get_azure_client('monitor')
        
        # Obter recursos para coletar métricas
        resource_client = get_azure_client('resource')
        
        # Definir período de coleta (últimos 7 dias)
        end_time = datetime.utcnow()
        start_time = end_time - timedelta(days=7)
        
        # Listar alguns recursos principais para métricas
        for resource in resource_client.resources.list():
            if resource.type in [
                'Microsoft.Storage/storageAccounts',
                'Microsoft.Sql/servers/databases',
                'Microsoft.DataFactory/factories'
            ]:
                try:
                    # Obter métricas disponíveis
                    metric_definitions = monitor_client.metric_definitions.list(
                        resource_uri=resource.id
                    )
                    
                    for metric_def in list(metric_definitions)[:5]:  # Limitar a 5 métricas por recurso
                        try:
                            # Obter dados da métrica
                            metrics = monitor_client.metrics.list(
                                resource_uri=resource.id,
                                timespan=f"{start_time.isoformat()}/{end_time.isoformat()}",
                                interval='PT1H',  # Intervalo de 1 hora
                                metricnames=metric_def.name.value
                            )
                            
                            for metric in metrics.value:
                                for timeserie in metric.timeseries:
                                    for data_point in timeserie.data:
                                        if data_point.average is not None:
                                            metric_info = {
                                                "id": generate_uuid(),
                                                "resource_id": resource.id,
                                                "resource_name": resource.name,
                                                "resource_type": resource.type,
                                                "metric_name": metric.name.value,
                                                "metric_value": float(data_point.average),
                                                "unit": metric.unit.value if metric.unit else '',
                                                "timestamp": data_point.time_stamp,
                                                "collected_at": EXTRACTION_DATE,
                                                "aggregation_type": "average"
                                            }
                                            metrics_data.append(metric_info)
                                            
                        except Exception as e:
                            print(f"⚠️ Erro ao coletar métrica {metric_def.name.value}: {str(e)}")
                            
                except Exception as e:
                    print(f"⚠️ Erro ao processar métricas do recurso {resource.name}: {str(e)}")
                    
                # Limitar para não sobrecarregar
                if len(metrics_data) > 1000:
                    break
    
    except Exception as e:
        print(f"❌ Erro ao extrair métricas do Monitor: {str(e)}")
    
    # Salvar dados
    save_to_table(metrics_data, "azure_monitor_metrics")
    
    return len(metrics_data)

# Executar extração
metrics_count = extract_azure_monitor_metrics()
print(f"📊 Extraídos: {metrics_count} pontos de métricas")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 👥 7. Extração de Usuários e Grupos (Azure AD)

# COMMAND ----------

def extract_azure_ad_users():
    """Extrai usuários e grupos do Azure AD"""
    print("👥 Extraindo usuários do Azure AD...")
    
    users_data = []
    groups_data = []
    
    try:
        # Usar Microsoft Graph API para Azure AD
        import msal
        
        # Configurar MSAL
        app = msal.ConfidentialClientApplication(
            CLIENT_ID,
            authority=f"https://login.microsoftonline.com/{TENANT_ID}",
            client_credential=CLIENT_SECRET
        )
        
        # Obter token
        result = app.acquire_token_for_client(scopes=["https://graph.microsoft.com/.default"])
        
        if "access_token" in result:
            headers = {
                'Authorization': f'Bearer {result["access_token"]}',
                'Content-Type': 'application/json'
            }
            
            # Obter usuários
            users_url = "https://graph.microsoft.com/v1.0/users?$top=100"
            users_response = requests.get(users_url, headers=headers)
            
            if users_response.status_code == 200:
                users_json = users_response.json()
                
                for user in users_json.get('value', []):
                    user_info = {
                        "id": generate_uuid(),
                        "azure_id": user.get('id'),
                        "username": user.get('userPrincipalName'),
                        "email": user.get('mail') or user.get('userPrincipalName'),
                        "full_name": user.get('displayName'),
                        "first_name": user.get('givenName'),
                        "last_name": user.get('surname'),
                        "job_title": user.get('jobTitle'),
                        "department": user.get('department'),
                        "office_location": user.get('officeLocation'),
                        "mobile_phone": user.get('mobilePhone'),
                        "business_phones": json.dumps(user.get('businessPhones', [])),
                        "created_at": EXTRACTION_DATE,
                        "updated_at": EXTRACTION_DATE,
                        "status": "active" if user.get('accountEnabled') else "inactive",
                        "user_type": user.get('userType', 'Member')
                    }
                    users_data.append(user_info)
            
            # Obter grupos
            groups_url = "https://graph.microsoft.com/v1.0/groups?$top=100"
            groups_response = requests.get(groups_url, headers=headers)
            
            if groups_response.status_code == 200:
                groups_json = groups_response.json()
                
                for group in groups_json.get('value', []):
                    group_info = {
                        "id": generate_uuid(),
                        "azure_id": group.get('id'),
                        "name": group.get('displayName'),
                        "description": group.get('description'),
                        "group_type": json.dumps(group.get('groupTypes', [])),
                        "mail": group.get('mail'),
                        "mail_enabled": group.get('mailEnabled', False),
                        "security_enabled": group.get('securityEnabled', False),
                        "created_at": EXTRACTION_DATE,
                        "updated_at": EXTRACTION_DATE,
                        "status": "active"
                    }
                    groups_data.append(group_info)
        
        else:
            print(f"❌ Erro ao obter token: {result.get('error_description')}")
    
    except Exception as e:
        print(f"❌ Erro ao extrair dados do Azure AD: {str(e)}")
    
    # Salvar dados
    save_to_table(users_data, "azure_ad_users")
    save_to_table(groups_data, "azure_ad_groups")
    
    return len(users_data), len(groups_data)

# Executar extração
users_count, groups_count = extract_azure_ad_users()
print(f"📊 Extraídos: {users_count} usuários, {groups_count} grupos")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 🔍 8. Mapeamento para Modelo de Governança

# COMMAND ----------

def map_to_governance_model():
    """Mapeia dados extraídos para o modelo de governança"""
    print("🔍 Mapeando dados para modelo de governança...")
    
    mapped_data = []
    
    try:
        # Mapear Storage Accounts para Data Sources
        storage_query = f"""
        SELECT 
            id,
            name,
            location,
            account_type,
            resource_group,
            tags
        FROM {TARGET_DATABASE}.azure_storage_accounts
        """
        
        storage_accounts = spark.sql(storage_query).collect()
        
        for sa in storage_accounts:
            data_source = {
                "id": generate_uuid(),
                "name": sa.name,
                "source_type": "azure_storage",
                "connection_string": f"DefaultEndpointsProtocol=https;AccountName={sa.name}",
                "location": sa.location,
                "description": f"Azure Storage Account - {sa.account_type}",
                "owner": "azure",
                "created_at": EXTRACTION_DATE,
                "updated_at": EXTRACTION_DATE,
                "status": "active",
                "tags": sa.tags,
                "metadata": json.dumps({
                    "resource_group": sa.resource_group,
                    "account_type": sa.account_type,
                    "provider": "azure"
                })
            }
            mapped_data.append(data_source)
        
        # Mapear SQL Databases para Data Sources
        sql_query = f"""
        SELECT 
            d.id,
            d.name,
            d.server_name,
            d.location,
            d.edition,
            d.resource_group,
            s.fqdn
        FROM {TARGET_DATABASE}.azure_sql_databases d
        JOIN {TARGET_DATABASE}.azure_sql_servers s ON d.server_name = s.name
        """
        
        sql_databases = spark.sql(sql_query).collect()
        
        for db in sql_databases:
            data_source = {
                "id": generate_uuid(),
                "name": f"{db.server_name}.{db.name}",
                "source_type": "azure_sql",
                "connection_string": f"Server={db.fqdn};Database={db.name}",
                "location": db.location,
                "description": f"Azure SQL Database - {db.edition}",
                "owner": "azure",
                "created_at": EXTRACTION_DATE,
                "updated_at": EXTRACTION_DATE,
                "status": "active",
                "tags": "{}",
                "metadata": json.dumps({
                    "server_name": db.server_name,
                    "edition": db.edition,
                    "resource_group": db.resource_group,
                    "provider": "azure"
                })
            }
            mapped_data.append(data_source)
        
        # Mapear Data Factories para Processing Systems
        df_query = f"""
        SELECT 
            id,
            name,
            location,
            resource_group,
            tags
        FROM {TARGET_DATABASE}.azure_data_factories
        """
        
        data_factories = spark.sql(df_query).collect()
        
        for df in data_factories:
            processing_system = {
                "id": generate_uuid(),
                "name": df.name,
                "system_type": "azure_data_factory",
                "location": df.location,
                "description": "Azure Data Factory for data processing",
                "owner": "azure",
                "created_at": EXTRACTION_DATE,
                "updated_at": EXTRACTION_DATE,
                "status": "active",
                "tags": df.tags,
                "metadata": json.dumps({
                    "resource_group": df.resource_group,
                    "provider": "azure"
                })
            }
            mapped_data.append(processing_system)
    
    except Exception as e:
        print(f"❌ Erro no mapeamento: {str(e)}")
    
    # Salvar dados mapeados
    save_to_table(mapped_data, "governance_data_sources")
    
    return len(mapped_data)

# Executar mapeamento
mapped_count = map_to_governance_model()
print(f"📊 Mapeados: {mapped_count} data sources para modelo de governança")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 📊 9. Relatório de Extração Azure

# COMMAND ----------

def generate_azure_extraction_report():
    """Gera relatório da extração Azure"""
    print("📊 Gerando relatório de extração Azure...")
    
    report = {
        "extraction_date": EXTRACTION_DATE.isoformat(),
        "extracted_by": "Azure SPN Extractor",
        "subscription_id": SUBSCRIPTION_ID,
        "tenant_id": TENANT_ID,
        "tables_extracted": {}
    }
    
    # Contar registros em cada tabela Azure
    azure_tables = [
        "azure_resource_groups", "azure_resources", "azure_storage_accounts",
        "azure_storage_containers", "azure_sql_servers", "azure_sql_databases",
        "azure_data_factories", "azure_pipelines", "azure_datasets",
        "azure_synapse_workspaces", "azure_synapse_sql_pools", "azure_synapse_spark_pools",
        "azure_monitor_metrics", "azure_ad_users", "azure_ad_groups",
        "governance_data_sources"
    ]
    
    for table_name in azure_tables:
        try:
            count_query = f"SELECT COUNT(*) as count FROM {TARGET_DATABASE}.{table_name}"
            count = spark.sql(count_query).collect()[0].count
            report["tables_extracted"][table_name] = count
            print(f"✅ {table_name}: {count} registros")
        except Exception as e:
            report["tables_extracted"][table_name] = f"Erro: {str(e)}"
            print(f"❌ {table_name}: Erro - {str(e)}")
    
    # Salvar relatório
    report_df = spark.createDataFrame([report])
    save_to_table(report_df, "azure_extraction_reports")
    
    return report

# Gerar relatório
azure_report = generate_azure_extraction_report()

# COMMAND ----------

# MAGIC %md
# MAGIC ## 🔄 10. Integração com Unity Catalog

# COMMAND ----------

def integrate_with_unity_catalog():
    """Integra dados Azure com dados do Unity Catalog"""
    print("🔄 Integrando dados Azure com Unity Catalog...")
    
    integration_data = []
    
    try:
        # Criar mapeamentos entre Azure e Unity Catalog
        
        # 1. Mapear Storage Accounts para External Locations
        storage_query = f"""
        SELECT name, location, account_type 
        FROM {TARGET_DATABASE}.azure_storage_accounts
        """
        
        storage_accounts = spark.sql(storage_query).collect()
        
        for sa in storage_accounts:
            external_location = {
                "id": generate_uuid(),
                "name": f"azure_storage_{sa.name}",
                "location_type": "azure_storage",
                "url": f"abfss://data@{sa.name}.dfs.core.windows.net/",
                "credential_name": f"azure_sp_credential",
                "description": f"External location for Azure Storage {sa.name}",
                "created_at": EXTRACTION_DATE,
                "updated_at": EXTRACTION_DATE,
                "status": "active",
                "owner": "azure_integration"
            }
            integration_data.append(external_location)
        
        # 2. Criar Data Sources integradas
        integrated_sources = []
        
        # Unity Catalog tables
        uc_tables_query = f"""
        SELECT full_name, table_type, owner 
        FROM {TARGET_DATABASE}.tables
        """
        
        uc_tables = spark.sql(uc_tables_query).collect()
        
        for table in uc_tables:
            integrated_source = {
                "id": generate_uuid(),
                "name": table.full_name,
                "source_type": "unity_catalog",
                "platform": "databricks",
                "location": "unity_catalog",
                "description": f"Unity Catalog {table.table_type}",
                "owner": table.owner,
                "created_at": EXTRACTION_DATE,
                "updated_at": EXTRACTION_DATE,
                "status": "active",
                "integration_status": "active"
            }
            integrated_sources.append(integrated_source)
        
        # Azure SQL Databases
        azure_sql_query = f"""
        SELECT name, server_name, edition 
        FROM {TARGET_DATABASE}.azure_sql_databases
        """
        
        azure_dbs = spark.sql(azure_sql_query).collect()
        
        for db in azure_dbs:
            integrated_source = {
                "id": generate_uuid(),
                "name": f"{db.server_name}.{db.name}",
                "source_type": "azure_sql",
                "platform": "azure",
                "location": "azure_cloud",
                "description": f"Azure SQL Database {db.edition}",
                "owner": "azure",
                "created_at": EXTRACTION_DATE,
                "updated_at": EXTRACTION_DATE,
                "status": "active",
                "integration_status": "active"
            }
            integrated_sources.append(integrated_source)
        
        # Salvar dados integrados
        save_to_table(integration_data, "external_locations")
        save_to_table(integrated_sources, "integrated_data_sources")
        
    except Exception as e:
        print(f"❌ Erro na integração: {str(e)}")
    
    return len(integration_data), len(integrated_sources)

# Executar integração
ext_count, int_count = integrate_with_unity_catalog()
print(f"📊 Integração: {ext_count} external locations, {int_count} integrated sources")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 🎉 Conclusão

# COMMAND ----------

print("🎉 Extração do Azure via SPN concluída!")
print("\n📋 Resumo:")
print(f"📅 Data da extração: {EXTRACTION_DATE}")
print(f"🗄️ Database de destino: {TARGET_DATABASE}")
print(f"☁️ Subscription: {SUBSCRIPTION_ID}")

print("\n📊 Dados extraídos do Azure:")
for table, count in azure_report["tables_extracted"].items():
    print(f"  • {table}: {count}")

print("\n🔗 Próximos passos:")
print("1. Validar dados extraídos")
print("2. Configurar pipeline de atualização")
print("3. Integrar com API de Governança")
print("4. Configurar alertas e monitoramento")

print("\n✅ Extração Azure SPN finalizada com sucesso!")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 📚 Documentação
# MAGIC 
# MAGIC ### Serviços Azure Extraídos
# MAGIC 
# MAGIC | Serviço | Tabela | Descrição |
# MAGIC |---------|--------|-----------|
# MAGIC | **Resource Manager** | `azure_resource_groups` | Resource Groups |
# MAGIC | **Resource Manager** | `azure_resources` | Todos os recursos |
# MAGIC | **Storage** | `azure_storage_accounts` | Storage Accounts |
# MAGIC | **Storage** | `azure_storage_containers` | Containers de blob |
# MAGIC | **SQL Database** | `azure_sql_servers` | SQL Servers |
# MAGIC | **SQL Database** | `azure_sql_databases` | SQL Databases |
# MAGIC | **Data Factory** | `azure_data_factories` | Data Factories |
# MAGIC | **Data Factory** | `azure_pipelines` | Pipelines |
# MAGIC | **Data Factory** | `azure_datasets` | Datasets |
# MAGIC | **Synapse** | `azure_synapse_workspaces` | Workspaces |
# MAGIC | **Synapse** | `azure_synapse_sql_pools` | SQL Pools |
# MAGIC | **Synapse** | `azure_synapse_spark_pools` | Spark Pools |
# MAGIC | **Monitor** | `azure_monitor_metrics` | Métricas |
# MAGIC | **Azure AD** | `azure_ad_users` | Usuários |
# MAGIC | **Azure AD** | `azure_ad_groups` | Grupos |
# MAGIC | **Integração** | `governance_data_sources` | Data sources mapeadas |
# MAGIC | **Integração** | `external_locations` | External locations |
# MAGIC | **Integração** | `integrated_data_sources` | Sources integradas |
# MAGIC 
# MAGIC ### Configuração SPN
# MAGIC 
# MAGIC Para usar este notebook, configure os seguintes secrets no Databricks:
# MAGIC 
# MAGIC ```bash
# MAGIC # Criar scope de secrets
# MAGIC databricks secrets create-scope --scope azure-secrets
# MAGIC 
# MAGIC # Adicionar secrets
# MAGIC databricks secrets put --scope azure-secrets --key tenant-id
# MAGIC databricks secrets put --scope azure-secrets --key client-id  
# MAGIC databricks secrets put --scope azure-secrets --key client-secret
# MAGIC databricks secrets put --scope azure-secrets --key subscription-id
# MAGIC ```
# MAGIC 
# MAGIC ### Permissões Necessárias
# MAGIC 
# MAGIC O Service Principal precisa das seguintes permissões:
# MAGIC 
# MAGIC - **Reader** - Para listar recursos
# MAGIC - **Storage Blob Data Reader** - Para acessar storage
# MAGIC - **SQL DB Contributor** - Para acessar SQL databases
# MAGIC - **Data Factory Contributor** - Para acessar Data Factory
# MAGIC - **Synapse Contributor** - Para acessar Synapse
# MAGIC - **Monitoring Reader** - Para acessar métricas
# MAGIC - **Directory.Read.All** - Para acessar Azure AD
# MAGIC 
# MAGIC ### Agendamento
# MAGIC 
# MAGIC Recomenda-se executar este notebook:
# MAGIC - **Diariamente** - Para recursos dinâmicos
# MAGIC - **Semanalmente** - Para metadados estáticos
# MAGIC - **Mensalmente** - Para relatórios completos
# MAGIC 
# MAGIC **Desenvolvido por Carlos Morais** 🚀

