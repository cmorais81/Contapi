# TBR GDP Core - Data Governance API v2.1 - Deploy Package

**Projeto:** tbr-gdpcore-dtgovapi  
**Desenvolvido por:** Carlos Morais  
**Versão:** 2.1 Final  
**Data:** Janeiro 2025  

## 📦 Conteúdo do Pacote

Este pacote contém todos os arquivos necessários para deploy completo do TBR GDP Core Data Governance API em ambiente Windows 11 com Python 3.14.

### 📁 Estrutura do Pacote

```
TBR_GDPCORE_DTGOVAPI_V21_FINAL/
├── tbr-gdpcore-dtgovapi/           # Código fonte completo da API
│   ├── src/                        # Código fonte Python
│   ├── tests/                      # Testes automatizados
│   ├── docs/                       # Documentação técnica
│   ├── scripts/                    # Scripts de deploy Windows
│   ├── requirements.txt            # Dependências Python
│   ├── pyproject.toml             # Configuração do projeto
│   └── README.md                  # Documentação principal
├── notebook_unity_catalog_extractor.py    # Notebook Databricks Unity Catalog
├── notebook_azure_spn_extractor.py        # Notebook Databricks Azure SPN
├── README_NOTEBOOKS.md                    # Documentação dos notebooks
├── Data_Contract.md                       # Documento de estratégia completa
└── DEPLOY_README.md                       # Este arquivo
```

## 🚀 Características Principais

### ✅ **API Completa**
- **65+ endpoints REST** documentados e funcionais
- **Arquitetura hexagonal** com princípios SOLID
- **Autenticação JWT** com roles e permissões
- **Rate limiting** avançado por usuário
- **Auditoria completa** de todas as operações

### ✅ **Modelo de Dados Robusto**
- **56 tabelas** baseadas no ODCS v3.0.2
- **Suporte PostgreSQL** e SQLite para desenvolvimento
- **Migrações Alembic** para versionamento
- **Dados mock** para testes e demonstração

### ✅ **Performance e Escalabilidade**
- **Cache Redis** para otimização
- **Connection pooling** avançado
- **Circuit breakers** para resiliência
- **Métricas Prometheus** para monitoramento

### ✅ **Integrações Avançadas**
- **Unity Catalog** via notebooks Databricks
- **Azure Services** via Service Principal
- **Informatica Axon** (preparado para integração)
- **APIs externas** com retry automático

### ✅ **Monitoramento e Observabilidade**
- **Health checks** detalhados
- **Logs estruturados** com contexto
- **Métricas de negócio** e técnicas
- **Alertas proativos** de problemas

## 🛠️ Instalação Rápida no Windows 11

### Pré-requisitos
- Windows 11 (21H2 ou superior)
- Python 3.14+
- PostgreSQL 15+ (ou SQLite para desenvolvimento)
- Redis 7+ (opcional, mas recomendado)
- Git

### 1. Extração do Pacote
```powershell
# Extrair o pacote em C:\tbr-gdpcore-dtgovapi
cd C:\
# Extrair arquivos aqui
```

### 2. Instalação Automática
```powershell
# Navegar para o diretório do projeto
cd C:\tbr-gdpcore-dtgovapi\tbr-gdpcore-dtgovapi

# Executar script de setup automático
.\scripts\windows\setup.ps1
```

### 3. Configuração do Ambiente
```powershell
# Copiar arquivo de configuração
copy .env.example .env

# Editar configurações conforme necessário
notepad .env
```

### 4. Inicialização da API
```powershell
# Executar a aplicação
.\scripts\windows\run.ps1
```

### 5. Verificação
```powershell
# Testar health check
curl http://localhost:8000/health

# Acessar documentação
# Abrir navegador em: http://localhost:8000/docs
```

## 📊 Endpoints Principais

### 🔐 **Autenticação**
- `POST /api/v1/auth/register` - Registrar usuário
- `POST /api/v1/auth/login` - Login
- `GET /api/v1/auth/me` - Perfil do usuário

### 📋 **Contratos de Dados**
- `GET /contracts/` - Listar contratos
- `POST /contracts/` - Criar contrato
- `GET /contracts/{id}` - Detalhes do contrato
- `PUT /contracts/{id}` - Atualizar contrato

### 🏢 **Entidades**
- `GET /entities/` - Listar entidades
- `POST /entities/` - Criar entidade
- `GET /entities/search` - Buscar entidades
- `GET /entities/{id}/attributes` - Atributos da entidade

### ⚡ **Qualidade**
- `GET /quality/rules` - Regras de qualidade
- `POST /quality/rules` - Criar regra
- `GET /quality/metrics` - Métricas de qualidade
- `POST /quality/execute` - Executar validação

### 📈 **Monitoramento**
- `GET /health` - Status da aplicação
- `GET /metrics` - Métricas Prometheus
- `GET /api/v1/system/status` - Status detalhado

## 🔧 Configurações Importantes

### Banco de Dados
```env
# PostgreSQL (Produção)
DATABASE_URL=postgresql+asyncpg://user:password@localhost:5432/governance_db

# SQLite (Desenvolvimento)
USE_SQLITE=true
SQLITE_DB_PATH=./governance_data.db
```

### Cache Redis
```env
REDIS_URL=redis://localhost:6379/0
REDIS_CACHE_TTL=300
```

### Segurança
```env
SECRET_KEY=your-super-secret-key-change-in-production
JWT_ALGORITHM=HS256
JWT_EXPIRE_MINUTES=30
```

### Performance
```env
DATABASE_POOL_SIZE=20
DATABASE_MAX_OVERFLOW=30
ENABLE_CACHE=true
RATE_LIMIT_ENABLED=true
```

## 📚 Notebooks Databricks

### Unity Catalog Extractor
- **Arquivo:** `notebook_unity_catalog_extractor.py`
- **Função:** Extrai metadados do Unity Catalog
- **Execução:** Agendada a cada 4 horas
- **Saída:** Dados mapeados para modelo ODCS v3.0.2

### Azure SPN Extractor  
- **Arquivo:** `notebook_azure_spn_extractor.py`
- **Função:** Extrai metadados dos serviços Azure
- **Autenticação:** Service Principal
- **Serviços:** Data Factory, SQL, Storage, Synapse, Key Vault

### Configuração dos Notebooks
```python
# Variáveis de ambiente necessárias
DATABRICKS_HOST = "https://your-workspace.cloud.databricks.com"
DATABRICKS_TOKEN = "your-access-token"
AZURE_CLIENT_ID = "your-client-id"
AZURE_CLIENT_SECRET = "your-client-secret"
AZURE_TENANT_ID = "your-tenant-id"
```

## 🧪 Testes

### Executar Testes Unitários
```powershell
# Todos os testes
pytest

# Com cobertura
pytest --cov=src --cov-report=html

# Testes específicos
pytest tests/unit/
pytest tests/integration/
```

### Testes de Endpoints
```powershell
# Executar script de teste
python test_endpoints.py

# Teste com autenticação
python test_with_auth.py
```

## 📈 Monitoramento

### Métricas Disponíveis
- **HTTP Requests:** Total e latência por endpoint
- **Database:** Conexões ativas e performance de queries
- **Cache:** Hit ratio e operações
- **Business:** Contratos ativos, qualidade de dados
- **System:** CPU, memória, disk I/O

### Alertas Configurados
- Latência > 1 segundo
- Taxa de erro > 5%
- Conexões DB > 80% do pool
- Cache hit ratio < 70%
- Falhas de sincronização

## 🔒 Segurança

### Autenticação e Autorização
- JWT tokens com expiração
- Roles baseados em permissões
- Rate limiting por usuário
- Auditoria de todas as operações

### Proteção de Dados
- Criptografia em trânsito (HTTPS)
- Hashing seguro de senhas (bcrypt)
- Sanitização de inputs
- Logs sem dados sensíveis

### Compliance
- Auditoria completa (LGPD/GDPR)
- Retenção de logs configurável
- Mascaramento de dados sensíveis
- Controles de acesso granulares

## 🚨 Troubleshooting

### Problemas Comuns

**1. Erro de Conexão com Banco**
```
Solução: Verificar se PostgreSQL está rodando e configurações estão corretas
```

**2. Falha na Autenticação**
```
Solução: Verificar SECRET_KEY e configurações JWT
```

**3. Performance Lenta**
```
Solução: Verificar Redis, connection pool e índices do banco
```

**4. Falha nos Notebooks**
```
Solução: Verificar credenciais Databricks e Azure
```

### Logs Importantes
```powershell
# Logs da aplicação
tail -f api.log

# Logs do sistema
Get-EventLog -LogName Application -Source "TBR GDP Core"

# Logs de auditoria
# Consultar tabela audit_logs no banco
```

## 📞 Suporte

### Documentação Adicional
- **API Endpoints:** `docs/API_ENDPOINTS.md`
- **Guia de Instalação:** `docs/INSTALLATION_GUIDE.md`
- **Relatório de Testes:** `docs/TESTING_REPORT.md`
- **Data Contract:** `Data_Contract.md`

### Contato
- **Desenvolvedor:** Carlos Morais
- **Email:** carlos.morais@company.com
- **Projeto:** tbr-gdpcore-dtgovapi
- **Versão:** 2.1 Final

## 🎯 Próximos Passos

1. **Deploy em Produção**
   - Configurar ambiente de produção
   - Setup de monitoramento
   - Configurar backups

2. **Integração com Sistemas**
   - Configurar notebooks Databricks
   - Integrar com Unity Catalog
   - Conectar serviços Azure

3. **Treinamento de Usuários**
   - Documentação de usuário
   - Workshops técnicos
   - Suporte inicial

4. **Monitoramento e Otimização**
   - Configurar alertas
   - Otimizar performance
   - Ajustar configurações

---

**🎉 TBR GDP Core Data Governance API v2.1 - Pronto para Produção!**

*Desenvolvido por Carlos Morais - Janeiro 2025*

