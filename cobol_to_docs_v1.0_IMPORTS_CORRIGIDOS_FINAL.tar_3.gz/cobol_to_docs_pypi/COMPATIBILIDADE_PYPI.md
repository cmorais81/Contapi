# Compatibilidade PyPI - COBOL to Docs v1.0

**Autor:** Carlos Morais  
**Versão:** 1.0  
**Data:** Setembro 2025

## Resumo de Compatibilidade

**SIM! O pacote PyPI mantém 100% das funcionalidades existentes!**

O `pip install cobol-to-docs` é uma forma **adicional** de instalação que oferece:
- **Mesmas funcionalidades** que o pacote tar.gz
- **Mesmos comandos** CLI
- **Mesma estrutura** de arquivos
- **Mesma compatibilidade** multiplataforma
- **Instalação mais fácil** via pip

## Formas de Instalação Disponíveis

### 1. **Instalação via PyPI (Nova)**
```bash
# Instalação global via pip
pip install cobol-to-docs

# Usar diretamente
cobol-to-docs --fontes programa.cbl
cobol-generate-prompts --interactive
```

### 2. **Instalação Manual (Existente)**
```bash
# Extrair pacote tar.gz
tar -xzf cobol_to_docs_v1.0_MULTIPLATAFORMA_FINAL.tar.gz
cd cobol_to_docs_v1

# Usar como antes
python3 main.py --fontes examples/fontes.txt
python3 generate_prompts.py --interactive
```

### 3. **Instalação com Scripts (Existente)**
```bash
# Scripts automáticos
./install.sh        # Linux/macOS
install.ps1         # Windows PowerShell
install.bat         # Windows CMD
```

## Comandos Equivalentes

### CLI Principal

**Forma Atual (Mantida):**
```bash
python3 main.py --fontes examples/fontes.txt --pdf
```

**Nova Forma PyPI (Adicional):**
```bash
cobol-to-docs --fontes examples/fontes.txt --pdf
```

### Gerador de Prompts

**Forma Atual (Mantida):**
```bash
python3 generate_prompts.py --interactive
```

**Nova Forma PyPI (Adicional):**
```bash
cobol-generate-prompts --interactive
```

## Funcionalidades Preservadas

### ✅ Todas as Funcionalidades Mantidas
- **Análise COBOL**: Mesma engine de análise
- **Gerador de prompts**: Mesmo sistema de geração
- **Multi-modelo**: Mesma funcionalidade comparativa
- **HTML/PDF**: Mesmos relatórios profissionais
- **Configuração**: Mesmos arquivos YAML
- **Exemplos**: Mesmos arquivos de exemplo

### ✅ Mesma Estrutura de Arquivos
```bash
# Após pip install, você ainda pode acessar:
~/.local/lib/python3.11/site-packages/cobol_to_docs/
├── config/           # Mesmas configurações
├── examples/         # Mesmos exemplos
├── templates/        # Mesmos templates
└── src/             # Mesmo código fonte
```

### ✅ Mesma Compatibilidade
- **Windows**: PowerShell, CMD, WSL
- **Linux**: Bash, Zsh, Fish
- **macOS**: Terminal, iTerm2
- **Python 3.11+**: Mesmos requisitos

## Vantagens do PyPI

### Instalação Simplificada
```bash
# Antes (manual)
wget https://github.com/user/repo/releases/cobol_to_docs_v1.0.tar.gz
tar -xzf cobol_to_docs_v1.0.tar.gz
cd cobol_to_docs_v1
pip install -r requirements.txt
python3 main.py --status

# Agora (PyPI)
pip install cobol-to-docs
cobol-to-docs --status
```

### Gerenciamento de Dependências
```bash
# Dependências instaladas automaticamente
pip install cobol-to-docs
# Instala: pyyaml, requests, beautifulsoup4, markdown

# Atualização fácil
pip install --upgrade cobol-to-docs
```

### Comandos Globais
```bash
# Disponível em qualquer diretório
cd /qualquer/lugar
cobol-to-docs --fontes /caminho/para/programa.cbl

# Não precisa navegar para pasta específica
cobol-generate-prompts --input requisitos.txt
```

## Migração Opcional

### Usuários Atuais
**Não precisam migrar!** Podem continuar usando exatamente como antes:
```bash
# Continua funcionando normalmente
python3 main.py --fontes examples/fontes.txt
python3 generate_prompts.py --interactive
```

### Novos Usuários
**Podem escolher a forma preferida:**
```bash
# Forma tradicional
tar -xzf cobol_to_docs_v1.0.tar.gz
cd cobol_to_docs_v1
python3 main.py --fontes examples/fontes.txt

# Ou forma PyPI
pip install cobol-to-docs
cobol-to-docs --fontes examples/fontes.txt
```

## Exemplos de Uso Equivalentes

### Análise Básica

**Forma Atual:**
```bash
cd cobol_to_docs_v1
python3 main.py --fontes examples/fontes.txt
```

**Forma PyPI:**
```bash
cobol-to-docs --fontes examples/fontes.txt
```

### Prompts Personalizados

**Forma Atual:**
```bash
cd cobol_to_docs_v1
python3 generate_prompts.py --input requisitos.txt
python3 main.py --prompts-file requisitos_prompts.yaml --fontes programa.cbl
```

**Forma PyPI:**
```bash
cobol-generate-prompts --input requisitos.txt
cobol-to-docs --prompts-file requisitos_prompts.yaml --fontes programa.cbl
```

### Multi-Modelo

**Forma Atual:**
```bash
cd cobol_to_docs_v1
python3 main.py --models '["aws-claude-3.7","gpt-4"]' --fontes programa.cbl
```

**Forma PyPI:**
```bash
cobol-to-docs --models '["aws-claude-3.7","gpt-4"]' --fontes programa.cbl
```

## Configuração Preservada

### Credenciais LuzIA
**Mesma forma em ambos os casos:**
```bash
export LUZIA_CLIENT_ID='seu_id'
export LUZIA_CLIENT_SECRET='seu_secret'
```

### Arquivos de Configuração
**PyPI usa mesma estrutura:**
```bash
# Localização após pip install
~/.local/lib/python3.11/site-packages/cobol_to_docs/config/config.yaml

# Ou pode usar arquivo local
cobol-to-docs --config meu_config.yaml --fontes programa.cbl
```

## Desenvolvimento e Contribuição

### Código Fonte Acessível
```bash
# Após pip install, código fica em:
python -c "import cobol_to_docs; print(cobol_to_docs.__file__)"

# Pode modificar e usar localmente
git clone https://github.com/carlosmorais/cobol-to-docs
cd cobol-to-docs
pip install -e .  # Instalação em modo desenvolvimento
```

### Mesma Estrutura de Projeto
```
cobol-to-docs/
├── cobol_to_docs/        # Mesmo código src/
├── config/               # Mesmas configurações
├── examples/             # Mesmos exemplos
├── docs/                 # Mesma documentação
├── setup.py             # Configuração PyPI
└── README.md            # Mesma documentação
```

## Resumo Final

### ✅ **Mantém Tudo**
- **Funcionalidades**: 100% preservadas
- **Comandos**: Todos funcionam igual
- **Arquivos**: Mesma estrutura
- **Compatibilidade**: Mesma multiplataforma
- **Configuração**: Mesmos YAMLs

### ✅ **Adiciona Facilidade**
- **Instalação**: `pip install cobol-to-docs`
- **Comandos globais**: `cobol-to-docs`, `cobol-generate-prompts`
- **Gerenciamento**: Atualizações via pip
- **Distribuição**: Disponível no PyPI

### ✅ **Escolha do Usuário**
- **Atual**: Continua funcionando normalmente
- **PyPI**: Opção adicional mais conveniente
- **Ambos**: Podem coexistir no mesmo sistema

**Desenvolvido por Carlos Morais - Compatibilidade total garantida!**
