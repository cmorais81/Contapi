"""
Utils - COBOL to Docs v1.0
Autor: Carlos Morais
"""

try:
    from .html_generator import HTMLGenerator
    from .file_utils import FileUtils
except ImportError:
    # Durante instalação, imports podem falhar
    pass

__all__ = [
    "HTMLGenerator",
    "FileUtils",
]
