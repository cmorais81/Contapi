"""
Analyzers - COBOL to Docs v1.0
Autor: Carlos Morais
"""

try:
    from .enhanced_cobol_analyzer import EnhancedCOBOLAnalyzer
except ImportError:
    # Durante instalação, imports podem falhar
    pass

__all__ = [
    "EnhancedCOBOLAnalyzer",
]
