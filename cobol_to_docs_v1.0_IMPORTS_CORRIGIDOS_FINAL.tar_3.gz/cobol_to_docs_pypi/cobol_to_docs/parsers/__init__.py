"""
Parsers - COBOL to Docs v1.0
Autor: Carlos Morais
"""

try:
    from .cobol_parser import COBOLParser
except ImportError:
    # Durante instalação, imports podem falhar
    pass

__all__ = [
    "COBOLParser",
]
