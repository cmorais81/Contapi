"""
COBOL AI Engine v2.0.0 - API para Notebooks
Interface programática para análise de código COBOL em Jupyter Notebooks.
"""

import os
import sys
import logging
from typing import Dict, List, Optional, Union, Any
from pathlib import Path
import tempfile
import json

try:
    from ..core.config import ConfigManager
    from ..core.prompt_manager import PromptManager
    from ..core.token_manager import TokenManager
    from ..providers.provider_manager import ProviderManager
    from ..parsers.cobol_parser import COBOLParser
    from ..generators.documentation_generator import DocumentationGenerator
except ImportError:
    from core.config import ConfigManager
    from core.prompt_manager import PromptManager
    from core.token_manager import TokenManager
    from providers.provider_manager import ProviderManager
    from parsers.cobol_parser import COBOLParser
    from generators.documentation_generator import DocumentationGenerator
try:
    from ..utils.pdf_converter import MarkdownToPDFConverter
except ImportError:
    from utils.pdf_converter import MarkdownToPDFConverter


class COBOLAnalyzer:
    """
    Interface principal para análise de código COBOL em notebooks.
    
    Esta classe fornece uma interface simples e intuitiva para analisar
    programas COBOL usando diferentes provedores de IA.
    """
    
    def __init__(self, config_path: Optional[str] = None, provider: str = "enhanced_mock"):
        """
        Inicializa o analisador COBOL.
        
        Args:
            config_path: Caminho para arquivo de configuração (opcional)
            provider: Provedor de IA a usar ("openai", "databricks", "bedrock", "enhanced_mock")
        """
        self.logger = logging.getLogger(__name__)
        
        # Configurar logging básico se não estiver configurado
        if not logging.getLogger().handlers:
            logging.basicConfig(
                level=logging.INFO,
                format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
        
        # Determinar caminho de configuração
        if config_path is None:
            # Usar configuração unificada por padrão
            base_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
            config_path = os.path.join(base_dir, 'config', 'config_unified.yaml')
        
        # Inicializar componentes
        self.config_manager = ConfigManager(config_path)
        self.config = self.config_manager.get_config()
        
        # Configurar provedor se especificado
        if provider != self.config['ai']['primary_provider']:
            self.config['ai']['primary_provider'] = provider
        
        # Inicializar managers
        self.prompt_manager = PromptManager(self.config)
        self.token_manager = TokenManager(self.config['ai']['global_max_tokens'])
        self.provider_manager = ProviderManager(self.config)
        self.cobol_parser = COBOLParser()
        self.doc_generator = DocumentationGenerator()
        
        self.logger.info(f"COBOL Analyzer inicializado com provedor: {provider}")
    
    def analyze_code(self, cobol_code: str, program_name: str = "PROGRAMA") -> Dict[str, Any]:
        """
        Analisa código COBOL fornecido como string.
        
        Args:
            cobol_code: Código COBOL como string
            program_name: Nome do programa (opcional)
            
        Returns:
            Dicionário com resultado da análise
        """
        try:
            # Criar arquivo temporário
            with tempfile.NamedTemporaryFile(mode='w', suffix='.cbl', delete=False) as temp_file:
                temp_file.write(cobol_code)
                temp_path = temp_file.name
            
            try:
                # Analisar arquivo temporário
                result = self.analyze_file(temp_path, program_name)
                return result
            finally:
                # Limpar arquivo temporário
                os.unlink(temp_path)
                
        except Exception as e:
            self.logger.error(f"Erro na análise do código: {str(e)}")
            return {
                "success": False,
                "error": str(e),
                "program_name": program_name
            }
    
    def analyze_file(self, file_path: str, program_name: Optional[str] = None) -> Dict[str, Any]:
        """
        Analisa arquivo COBOL.
        
        Args:
            file_path: Caminho para o arquivo COBOL
            program_name: Nome do programa (opcional, extraído do arquivo se não fornecido)
            
        Returns:
            Dicionário com resultado da análise
        """
        try:
            # Verificar se arquivo existe
            if not os.path.exists(file_path):
                raise FileNotFoundError(f"Arquivo não encontrado: {file_path}")
            
            # Extrair nome do programa se não fornecido
            if program_name is None:
                program_name = os.path.splitext(os.path.basename(file_path))[0]
            
            # Ler conteúdo do arquivo
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            # Analisar usando o provider diretamente
            try:
                from ..providers.base_provider import AIRequest
            except ImportError:
                from providers.base_provider import AIRequest
            
            # Criar request para análise
            request = AIRequest(
                prompt=f"Analise este programa COBOL e forneça documentação completa:\n\n{content}",
                max_tokens=self.config['ai']['global_max_tokens'],
                temperature=0.1
            )
            
            # Obter provedor primário e executar análise
            response = self.provider_manager.analyze(request)
            
            if response.success:
                return {
                    "success": True,
                    "program_name": program_name,
                    "documentation": response.content,
                    "metadata": {
                        "tokens_used": getattr(response, 'tokens_used', 0),
                        "model": getattr(response, 'model_used', 'unknown')
                    },
                    "statistics": {
                        "file_size": len(content),
                        "lines_count": len(content.split('\n'))
                    },
                    "provider_used": getattr(response, 'provider_name', 'unknown')
                }
            else:
                return {
                    "success": False,
                    "error": getattr(response, 'error_message', 'Erro desconhecido'),
                    "program_name": program_name
                }
            
        except Exception as e:
            self.logger.error(f"Erro na análise do arquivo {file_path}: {str(e)}")
            return {
                "success": False,
                "error": str(e),
                "program_name": program_name or "unknown"
            }
    
    def analyze_multiple_files(self, file_paths: List[str]) -> Dict[str, Dict[str, Any]]:
        """
        Analisa múltiplos arquivos COBOL.
        
        Args:
            file_paths: Lista de caminhos para arquivos COBOL
            
        Returns:
            Dicionário com resultados de cada análise
        """
        results = {}
        
        for file_path in file_paths:
            program_name = os.path.splitext(os.path.basename(file_path))[0]
            result = self.analyze_file(file_path, program_name)
            results[program_name] = result
        
        return results
    
    def analyze_directory(self, directory_path: str, extensions: List[str] = None) -> Dict[str, Dict[str, Any]]:
        """
        Analisa todos os arquivos COBOL em um diretório.
        
        Args:
            directory_path: Caminho para o diretório
            extensions: Lista de extensões a considerar (padrão: ['.cbl', '.cob', '.txt'])
            
        Returns:
            Dicionário com resultados de cada análise
        """
        if extensions is None:
            extensions = ['.cbl', '.cob', '.txt']
        
        # Encontrar arquivos COBOL
        cobol_files = []
        for ext in extensions:
            pattern = f"*{ext}"
            cobol_files.extend(Path(directory_path).glob(pattern))
        
        # Converter para strings
        file_paths = [str(f) for f in cobol_files]
        
        return self.analyze_multiple_files(file_paths)
    
    def generate_report(self, analysis_results: Dict[str, Dict[str, Any]], 
                       output_path: str, format: str = "markdown") -> bool:
        """
        Gera relatório consolidado das análises.
        
        Args:
            analysis_results: Resultados das análises
            output_path: Caminho para salvar o relatório
            format: Formato do relatório ("markdown" ou "pdf")
            
        Returns:
            True se sucesso, False caso contrário
        """
        try:
            # Gerar conteúdo do relatório
            report_content = self._generate_report_content(analysis_results)
            
            if format.lower() == "markdown":
                # Salvar como Markdown
                with open(output_path, 'w', encoding='utf-8') as f:
                    f.write(report_content)
                return True
                
            elif format.lower() == "pdf":
                # Salvar como PDF
                # Primeiro salvar como markdown temporário
                temp_md = output_path.replace('.pdf', '_temp.md')
                with open(temp_md, 'w', encoding='utf-8') as f:
                    f.write(report_content)
                
                # Converter para PDF
                pdf_converter = MarkdownToPDFConverter()
                success = pdf_converter.convert_to_pdf(temp_md, output_path)
                
                # Limpar arquivo temporário
                if os.path.exists(temp_md):
                    os.unlink(temp_md)
                
                return success
            
            else:
                raise ValueError(f"Formato não suportado: {format}")
                
        except Exception as e:
            self.logger.error(f"Erro ao gerar relatório: {str(e)}")
            return False
    
    def _generate_report_content(self, analysis_results: Dict[str, Dict[str, Any]]) -> str:
        """Gera conteúdo do relatório consolidado."""
        from datetime import datetime
        
        content = []
        content.append("# Relatório de Análise COBOL")
        content.append(f"\n**Data:** {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}")
        content.append(f"**Total de Programas:** {len(analysis_results)}")
        
        # Estatísticas gerais
        successful = sum(1 for r in analysis_results.values() if r.get('success', False))
        failed = len(analysis_results) - successful
        
        content.append(f"**Análises Bem-sucedidas:** {successful}")
        content.append(f"**Análises com Erro:** {failed}")
        
        # Provedores utilizados
        providers = set()
        for result in analysis_results.values():
            if result.get('success'):
                providers.add(result.get('provider_used', 'unknown'))
        
        content.append(f"**Provedores Utilizados:** {', '.join(providers)}")
        content.append("\n---\n")
        
        # Detalhes de cada programa
        for program_name, result in analysis_results.items():
            content.append(f"## {program_name}")
            
            if result.get('success'):
                content.append(f"**Status:**  Sucesso")
                content.append(f"**Provedor:** {result.get('provider_used', 'N/A')}")
                
                # Adicionar documentação
                documentation = result.get('documentation', '')
                if documentation:
                    content.append("\n### Documentação")
                    content.append(documentation)
                
                # Adicionar metadados se disponíveis
                metadata = result.get('metadata', {})
                if metadata:
                    content.append("\n### Metadados")
                    for key, value in metadata.items():
                        content.append(f"- **{key}:** {value}")
                
            else:
                content.append(f"**Status:**  Erro")
                content.append(f"**Erro:** {result.get('error', 'Erro desconhecido')}")
            
            content.append("\n---\n")
        
        return "\n".join(content)
    
    def get_available_providers(self) -> List[str]:
        """
        Retorna lista de provedores disponíveis.
        
        Returns:
            Lista de nomes dos provedores
        """
        return list(self.config['ai']['providers'].keys())
    
    def get_provider_status(self) -> Dict[str, Dict[str, Any]]:
        """
        Retorna status de todos os provedores.
        
        Returns:
            Dicionário com status de cada provedor
        """
        return self.provider_manager.get_system_status()
    
    def set_provider(self, provider_name: str) -> bool:
        """
        Altera o provedor de IA.
        
        Args:
            provider_name: Nome do provedor
            
        Returns:
            True se sucesso, False caso contrário
        """
        try:
            if provider_name not in self.get_available_providers():
                raise ValueError(f"Provedor '{provider_name}' não disponível")
            
            self.config['ai']['primary_provider'] = provider_name
            
            # Reinicializar provider manager
            self.provider_manager = ProviderManager(
                self.config, self.prompt_manager, self.token_manager
            )
            
            self.logger.info(f"Provedor alterado para: {provider_name}")
            return True
            
        except Exception as e:
            self.logger.error(f"Erro ao alterar provedor: {str(e)}")
            return False
    
    def get_current_provider(self) -> str:
        """
        Retorna o provedor atual.
        
        Returns:
            Nome do provedor atual
        """
        return self.config['ai']['primary_provider']


# Função de conveniência para uso rápido
def analyze_cobol(cobol_code: str, provider: str = "enhanced_mock") -> Dict[str, Any]:
    """
    Função de conveniência para análise rápida de código COBOL.
    
    Args:
        cobol_code: Código COBOL como string
        provider: Provedor de IA a usar
        
    Returns:
        Resultado da análise
    """
    analyzer = COBOLAnalyzer(provider=provider)
    return analyzer.analyze_code(cobol_code)


# Função para análise de arquivo
def analyze_cobol_file(file_path: str, provider: str = "enhanced_mock") -> Dict[str, Any]:
    """
    Função de conveniência para análise de arquivo COBOL.
    
    Args:
        file_path: Caminho para o arquivo COBOL
        provider: Provedor de IA a usar
        
    Returns:
        Resultado da análise
    """
    analyzer = COBOLAnalyzer(provider=provider)
    return analyzer.analyze_file(file_path)

