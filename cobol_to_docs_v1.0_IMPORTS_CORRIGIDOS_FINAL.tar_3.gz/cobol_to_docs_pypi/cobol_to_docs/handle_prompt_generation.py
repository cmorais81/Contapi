"""
Função para lidar com geração de prompts no CLI principal
COBOL to Docs v1.0
Autor: Carlos Morais
"""

import os
import sys
from pathlib import Path

def handle_prompt_generation(args):
    """Lida com comandos de geração de prompts no CLI principal."""
    
    print("GERADOR DE PROMPTS YAML - COBOL TO DOCS v1.0")
    print("Autor: Carlos Morais")
    print("=" * 60)
    print()
    
    # Verificar se o script generate_prompts.py existe
    try:
        from .generate_prompts_original import main as generate_main
        script_path = None  # Usar import direto
    except ImportError:
        script_path = Path("generate_prompts.py")
    if script_path and not script_path.exists():
        print("Erro: Script generate_prompts.py não encontrado")
        print("   Certifique-se de que o arquivo está no diretório atual")
        sys.exit(1)
    
    # Construir comando para executar
    if args.generate_prompts_interactive:
        print("Executando geração de prompts em modo interativo...")
        print()
        cmd = f"python3 generate_prompts.py --interactive"
        
    elif args.generate_prompts:
        input_file = args.generate_prompts
        
        # Verificar se arquivo existe
        if not os.path.exists(input_file):
            print(f"Erro: Arquivo não encontrado: {input_file}")
            sys.exit(1)
        
        print(f"Gerando prompts a partir de: {input_file}")
        print()
        
        # Gerar nome de saída baseado no arquivo de entrada
        input_path = Path(input_file)
        output_file = f"{input_path.stem}_prompts.yaml"
        
        cmd = f"python3 generate_prompts.py --input '{input_file}' --output '{output_file}' --preview"
    
    # Executar comando
    exit_code = os.system(cmd)
    
    if exit_code == 0:
        print()
        print("Geração de prompts concluída com sucesso!")
        print()
        print("PRÓXIMOS PASSOS:")
        print("1. Revise o arquivo YAML gerado")
        print("2. Use na análise: python3 main.py --fontes programa.cbl --prompts-file arquivo_gerado.yaml")
    else:
        print()
        print("Erro na geração de prompts")
        sys.exit(1)
