#!/usr/bin/env python3
"""
CLI de Inicialização - COBOL to Docs v1.0
Autor: Carlos Morais

Comando para inicializar configuração para novos usuários via pip
"""

import os
import sys
import shutil
from pathlib import Path
import argparse

def get_package_path():
    """Obtém o caminho do pacote instalado."""
    try:
        import cobol_to_docs
        return Path(cobol_to_docs.__file__).parent
    except ImportError:
        # Fallback para desenvolvimento
        return Path(__file__).parent

def create_config_directory(target_dir: str = None):
    """Cria diretório de configuração local."""
    if target_dir is None:
        target_dir = os.getcwd()
    
    target_path = Path(target_dir)
    config_dir = target_path / "cobol_to_docs_config"
    
    # Criar diretório se não existir (incluindo pais)
    config_dir.mkdir(parents=True, exist_ok=True)
    
    return config_dir

def copy_config_files(config_dir: Path):
    """Copia arquivos de configuração do pacote."""
    package_path = get_package_path()
    
    # Arquivos a copiar
    files_to_copy = [
        ("config/config.yaml", "config.yaml"),
        ("config/prompts_original.yaml", "prompts_original.yaml"),
        ("config/prompts_doc_legado_pro.yaml", "prompts_doc_legado_pro.yaml"),
    ]
    
    copied_files = []
    
    for source_file, target_file in files_to_copy:
        source_path = package_path / source_file
        target_path = config_dir / target_file
        
        if source_path.exists():
            shutil.copy2(source_path, target_path)
            copied_files.append(target_file)
            print(f"✅ Copiado: {target_file}")
        else:
            print(f"⚠️  Arquivo não encontrado: {source_file}")
    
    return copied_files

def copy_examples(config_dir: Path):
    """Copia arquivos de exemplo."""
    package_path = get_package_path()
    examples_source = package_path / "examples"
    examples_target = config_dir / "examples"
    
    if examples_source.exists():
        if examples_target.exists():
            shutil.rmtree(examples_target)
        shutil.copytree(examples_source, examples_target)
        print(f"✅ Exemplos copiados para: examples/")
        return True
    else:
        print(f"⚠️  Diretório de exemplos não encontrado")
        return False

def create_sample_files(config_dir: Path):
    """Cria arquivos de exemplo para o usuário."""
    
    # Criar arquivo de fontes de exemplo
    fontes_file = config_dir / "fontes_exemplo.txt"
    with open(fontes_file, 'w', encoding='utf-8') as f:
        f.write("""# Lista de arquivos COBOL para análise
# COBOL to Docs v1.0 - Autor: Carlos Morais
# 
# Formato: um arquivo por linha
# Linhas iniciadas com # são comentários

examples/programa_exemplo.cbl
# Adicione seus arquivos COBOL aqui
# /caminho/para/seu_programa.cbl
""")
    
    # Criar arquivo de requisitos de exemplo
    requisitos_file = config_dir / "requisitos_exemplo.txt"
    with open(requisitos_file, 'w', encoding='utf-8') as f:
        f.write("""Análise Personalizada para Sistema COBOL

Preciso de uma análise detalhada focada em:

ASPECTOS TÉCNICOS:
- Estrutura do programa e divisões
- Variáveis e estruturas de dados
- Lógica de processamento
- Arquivos e registros utilizados

REGRAS DE NEGÓCIO:
- Funcionalidades implementadas
- Validações e controles
- Cálculos e fórmulas
- Fluxos de processamento

QUALIDADE E MANUTENÇÃO:
- Padrões de codificação
- Complexidade do código
- Pontos de melhoria
- Documentação necessária

A análise deve ser clara e adequada para desenvolvedores e analistas de sistemas.
""")
    
    print(f"✅ Arquivo de fontes: fontes_exemplo.txt")
    print(f"✅ Arquivo de requisitos: requisitos_exemplo.txt")
    
    return [fontes_file, requisitos_file]

def update_config_paths(config_dir: Path):
    """Atualiza caminhos no arquivo de configuração."""
    config_file = config_dir / "config.yaml"
    
    if not config_file.exists():
        return False
    
    # Ler configuração atual
    with open(config_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Atualizar caminhos relativos
    content = content.replace(
        'prompts_file: "config/prompts_original.yaml"',
        'prompts_file: "prompts_original.yaml"'
    )
    
    # Escrever configuração atualizada
    with open(config_file, 'w', encoding='utf-8') as f:
        f.write(content)
    
    print(f"✅ Configuração atualizada: config.yaml")
    return True

def create_usage_guide(config_dir: Path):
    """Cria guia de uso rápido."""
    guide_file = config_dir / "COMO_USAR.md"
    
    with open(guide_file, 'w', encoding='utf-8') as f:
        f.write(f"""# Como Usar - COBOL to Docs v1.0

**Autor:** Carlos Morais  
**Configuração criada em:** {config_dir.absolute()}

## Arquivos Criados

- **config.yaml**: Configuração principal do sistema
- **prompts_original.yaml**: Prompts técnicos padrão
- **prompts_doc_legado_pro.yaml**: Prompts especializados para legado
- **fontes_exemplo.txt**: Lista de arquivos COBOL para análise
- **requisitos_exemplo.txt**: Exemplo para gerar prompts personalizados
- **examples/**: Programas COBOL de exemplo

## Uso Básico

### 1. Análise Simples
```bash
# Editar fontes_exemplo.txt com seus arquivos COBOL
# Depois executar:
cobol-to-docs --config {config_dir.absolute()}/config.yaml --fontes {config_dir.absolute()}/fontes_exemplo.txt
```

### 2. Análise com PDF
```bash
cobol-to-docs --config {config_dir.absolute()}/config.yaml --fontes {config_dir.absolute()}/fontes_exemplo.txt --pdf
```

### 3. Gerar Prompts Personalizados
```bash
# Editar requisitos_exemplo.txt com suas necessidades
# Depois executar:
cobol-generate-prompts --input {config_dir.absolute()}/requisitos_exemplo.txt --output meus_prompts.yaml

# Usar prompts personalizados:
cobol-to-docs --config {config_dir.absolute()}/config.yaml --fontes {config_dir.absolute()}/fontes_exemplo.txt --prompts-file meus_prompts.yaml --pdf
```

### 4. Análise Multi-Modelo
```bash
cobol-to-docs --config {config_dir.absolute()}/config.yaml --fontes {config_dir.absolute()}/fontes_exemplo.txt --models '[\"aws-claude-3.7\",\"enhanced_mock\"]' --pdf
```

## Configuração de Credenciais

### LuzIA (Opcional)
```bash
# Linux/macOS
export LUZIA_CLIENT_ID='seu_client_id'
export LUZIA_CLIENT_SECRET='seu_client_secret'

# Windows PowerShell
$env:LUZIA_CLIENT_ID='seu_client_id'
$env:LUZIA_CLIENT_SECRET='seu_secret'
```

## Verificar Status
```bash
cobol-to-docs --config {config_dir.absolute()}/config.yaml --status
```

## Próximos Passos

1. **Editar fontes_exemplo.txt** com seus arquivos COBOL
2. **Executar análise básica** para testar
3. **Configurar credenciais LuzIA** se disponível
4. **Gerar prompts personalizados** conforme necessário
5. **Explorar diferentes conjuntos de prompts** (original, doc_legado_pro)

## Comandos Úteis

```bash
# Ajuda geral
cobol-to-docs --help

# Ajuda do gerador de prompts
cobol-generate-prompts --help

# Testar com exemplo incluído
cobol-to-docs --config {config_dir.absolute()}/config.yaml --fontes {config_dir.absolute()}/examples/fontes.txt --pdf
```

---

**Sistema desenvolvido por Carlos Morais**  
**Para suporte, consulte a documentação completa**
""")
    
    print(f"✅ Guia de uso: COMO_USAR.md")
    return guide_file

def main():
    """Função principal do comando de inicialização."""
    parser = argparse.ArgumentParser(
        description='Inicializar configuração do COBOL to Docs v1.0',
        epilog='Autor: Carlos Morais - Cria arquivos de configuração para novos usuários'
    )
    
    parser.add_argument('--dir', '-d', 
                       help='Diretório onde criar a configuração (padrão: diretório atual)')
    parser.add_argument('--force', '-f', action='store_true',
                       help='Sobrescrever arquivos existentes')
    
    args = parser.parse_args()
    
    print("=" * 60)
    print("COBOL to Docs v1.0 - Inicialização de Configuração")
    print("Autor: Carlos Morais")
    print("=" * 60)
    print()
    
    try:
        # Criar diretório de configuração
        config_dir = create_config_directory(args.dir)
        print(f"📁 Diretório de configuração: {config_dir.absolute()}")
        print()
        
        # Verificar se já existe configuração
        if (config_dir / "config.yaml").exists() and not args.force:
            print("⚠️  Configuração já existe!")
            print(f"   Use --force para sobrescrever ou escolha outro diretório")
            print(f"   Diretório atual: {config_dir.absolute()}")
            return
        
        print("📋 Copiando arquivos de configuração...")
        copied_files = copy_config_files(config_dir)
        print()
        
        print("📁 Copiando exemplos...")
        copy_examples(config_dir)
        print()
        
        print("📝 Criando arquivos de exemplo...")
        sample_files = create_sample_files(config_dir)
        print()
        
        print("⚙️  Atualizando configuração...")
        update_config_paths(config_dir)
        print()
        
        print("📖 Criando guia de uso...")
        guide_file = create_usage_guide(config_dir)
        print()
        
        print("=" * 60)
        print("✅ CONFIGURAÇÃO CRIADA COM SUCESSO!")
        print("=" * 60)
        print()
        print("📁 Localização:", config_dir.absolute())
        print()
        print("📋 Arquivos criados:")
        for file in copied_files + [f.name for f in sample_files] + [guide_file.name]:
            print(f"   - {file}")
        print("   - examples/ (diretório)")
        print()
        print("🚀 PRÓXIMOS PASSOS:")
        print()
        print("1. Ler o guia de uso:")
        print(f"   cat '{guide_file.absolute()}'")
        print()
        print("2. Testar com exemplo:")
        print(f"   cobol-to-docs --config '{config_dir.absolute()}/config.yaml' --fontes '{config_dir.absolute()}/examples/fontes.txt'")
        print()
        print("3. Verificar status:")
        print(f"   cobol-to-docs --config '{config_dir.absolute()}/config.yaml' --status")
        print()
        print("4. Editar arquivos conforme necessário:")
        print(f"   - {config_dir.absolute()}/fontes_exemplo.txt")
        print(f"   - {config_dir.absolute()}/requisitos_exemplo.txt")
        print()
        print("Sistema desenvolvido por Carlos Morais")
        print("=" * 60)
        
    except Exception as e:
        print(f"❌ Erro durante inicialização: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
