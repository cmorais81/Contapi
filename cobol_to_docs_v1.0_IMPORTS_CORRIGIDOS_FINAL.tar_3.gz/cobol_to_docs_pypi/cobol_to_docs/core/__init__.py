"""
Core components - COBOL to Docs v1.0
Autor: Carlos Morais
"""

# Importações principais do core
try:
    from .config import ConfigManager
    from .prompt_manager_dual import DualPromptManager
except ImportError:
    # Durante instalação, imports podem falhar
    pass

__all__ = [
    "ConfigManager",
    "DualPromptManager",
]
