"""
Gerador de Prompts YAML - COBOL AI Engine v2.0.0
Converte texto livre em prompts YAML otimizados para análise COBOL
"""

import os
import sys
import yaml
import logging
import re
from datetime import datetime
from typing import Dict, Any, List, Optional
from pathlib import Path

try:
    from ..providers.luzia_provider import LuziaProvider
    from ..core.config import ConfigManager
except ImportError:
    from providers.luzia_provider import LuziaProvider
    from core.config import ConfigManager

logger = logging.getLogger(__name__)

class PromptGenerator:
    """Gerador de prompts YAML usando IA para otimização."""
    
    def __init__(self, config_path: str = "config/config.yaml"):
        """Inicializa o gerador de prompts."""
        self.config_manager = ConfigManager(config_path)
        self.luzia_provider = LuziaProvider(
            self.config_manager.config.get('providers', {}).get('luzia', {})
        )
        
        # Template para geração de prompts
        self.prompt_generation_template = self._get_prompt_generation_template()
        
        logger.info("PromptGenerator inicializado")
    
    def _get_prompt_generation_template(self) -> str:
        """Template para gerar prompts otimizados."""
        return """Você é um especialista em engenharia de prompts e análise de sistemas COBOL com mais de 20 anos de experiência.

Sua tarefa é converter o texto fornecido em um conjunto de prompts YAML otimizados para análise de programas COBOL.

TEXTO FORNECIDO PARA CONVERSÃO:
{input_text}

INSTRUÇÕES PARA GERAÇÃO:

1. ANÁLISE DO TEXTO:
   - Identifique os objetivos principais do texto
   - Extraia requisitos específicos de análise
   - Identifique o foco desejado (técnico, funcional, negócio)
   - Determine o nível de detalhamento necessário

2. BOAS PRÁTICAS DE ENGENHARIA DE PROMPT:
   - Use linguagem clara e específica
   - Evite ambiguidades e termos vagos
   - Inclua contexto suficiente para orientar a IA
   - Estruture perguntas de forma lógica e sequencial
   - Defina expectativas claras de formato de resposta
   - Use exemplos quando necessário para clareza

3. OTIMIZAÇÃO PARA COBOL:
   - Foque em aspectos específicos de COBOL (divisões, seções, copybooks)
   - Inclua terminologia técnica apropriada
   - Considere aspectos de sistemas legados
   - Aborde integração e interfaces de dados
   - Inclua validação de regras de negócio

4. ESTRUTURA YAML REQUERIDA:
   - version: versão do arquivo
   - system_prompt: prompt base do sistema
   - model_prompts: prompts específicos por modelo
   - base_template: template base para análise
   - analysis_questions: perguntas organizadas por categoria

5. CATEGORIAS DE ANÁLISE:
   - functional: análise funcional e de negócio
   - technical_architecture: arquitetura técnica
   - business_rules: regras de negócio
   - data_structures: estruturas de dados
   - integration_interfaces: interfaces e integrações
   - performance: aspectos de performance (se relevante)
   - security: aspectos de segurança (se relevante)
   - maintenance: manutenibilidade (se relevante)

6. SANITIZAÇÃO E LIMPEZA:
   - Remova caracteres especiais que possam quebrar YAML
   - Escape aspas e caracteres especiais adequadamente
   - Use encoding UTF-8 seguro
   - Valide sintaxe YAML
   - Teste compatibilidade com parser YAML

7. PERSONALIZAÇÃO:
   - Adapte o tom e estilo ao contexto fornecido
   - Ajuste o nível técnico conforme necessário
   - Inclua terminologia específica do domínio se mencionada
   - Mantenha consistência com padrões COBOL

FORMATO DE RESPOSTA:
Gere um arquivo YAML completo e válido seguindo exatamente esta estrutura:

```yaml
# [Título baseado no texto fornecido]

version: "2.0.0"

# Prompt de sistema base
system_prompt: |
  [Prompt otimizado baseado no texto]

# Prompts por modelo
model_prompts:
  luzia_standard:
    system_prompt: |
      [Prompt específico para LuzIA]
    persona: "[Persona apropriada]"
    analysis_depth: "[standard/detailed/comprehensive]"
    
  claude_3_5_sonnet:
    system_prompt: |
      [Prompt específico para Claude]
    persona: "[Persona apropriada]"
    analysis_depth: "[standard/detailed/comprehensive]"

# Template base para análise
base_template: |
  [Template completo com placeholders]

# Questões de análise organizadas por prioridade
analysis_questions:
  [categoria1]:
    priority: 1
    required: true
    context: "[Contexto da análise]"
    focus: "[Foco específico]"
    question: |
      [Pergunta detalhada e específica]
  
  [categoria2]:
    priority: 2
    required: true
    context: "[Contexto da análise]"
    focus: "[Foco específico]"
    question: |
      [Pergunta detalhada e específica]
```

IMPORTANTE:
- Gere APENAS o conteúdo YAML válido
- NÃO inclua explicações adicionais
- NÃO use markdown code blocks
- Certifique-se de que o YAML seja válido e parseável
- Mantenha consistência com padrões existentes
- Foque na qualidade e especificidade dos prompts gerados

Gere agora o arquivo YAML otimizado baseado no texto fornecido:"""

    def _sanitize_text(self, text: str) -> str:
        """Sanitiza texto para uso seguro em YAML."""
        # Remover caracteres problemáticos
        text = re.sub(r'[^\w\s\-.,;:!?()\[\]{}/@#$%&*+=<>|\\~`\'"áéíóúâêîôûàèìòùãõçÁÉÍÓÚÂÊÎÔÛÀÈÌÒÙÃÕÇ]', '', text)
        
        # Normalizar espaços
        text = re.sub(r'\s+', ' ', text)
        text = text.strip()
        
        # Escapar aspas se necessário
        text = text.replace('"', '\\"')
        
        return text

    def _validate_yaml(self, yaml_content: str) -> bool:
        """Valida se o conteúdo YAML é válido."""
        try:
            yaml.safe_load(yaml_content)
            return True
        except yaml.YAMLError as e:
            logger.error(f"YAML inválido: {e}")
            return False

    def generate_prompt_yaml(self, input_text: str, output_file: str = None) -> Dict[str, Any]:
        """
        Gera arquivo YAML de prompts a partir de texto livre.
        
        Args:
            input_text: Texto livre para converter em prompts
            output_file: Caminho para salvar o arquivo YAML (opcional)
            
        Returns:
            Dicionário com resultado da geração
        """
        try:
            logger.info("Iniciando geração de prompts YAML")
            
            # Sanitizar texto de entrada
            clean_text = self._sanitize_text(input_text)
            logger.info(f"Texto sanitizado: {len(clean_text)} caracteres")
            
            # Preparar prompt para IA
            generation_prompt = self.prompt_generation_template.format(
                input_text=clean_text
            )
            
            # Criar request para IA
            from ..providers.base_provider import AIRequest
            ai_request = AIRequest(
                prompt=generation_prompt,
                max_tokens=8192,
                temperature=0.1
            )
            
            logger.info("Enviando para LuzIA para geração de prompts...")
            
            # Gerar prompts usando IA
            response = self.luzia_provider.analyze(ai_request)
            
            if not response.success:
                raise Exception(f"Erro na geração: {response.error_message}")
            
            yaml_content = response.content.strip()
            logger.info(f"Prompts gerados: {len(yaml_content)} caracteres")
            
            # Limpar possíveis markdown code blocks
            if yaml_content.startswith('```yaml'):
                yaml_content = yaml_content.replace('```yaml', '').replace('```', '').strip()
            elif yaml_content.startswith('```'):
                yaml_content = yaml_content.replace('```', '').strip()
            
            # Validar YAML gerado
            if not self._validate_yaml(yaml_content):
                raise Exception("YAML gerado é inválido")
            
            # Parse do YAML para verificação
            parsed_yaml = yaml.safe_load(yaml_content)
            
            # Salvar arquivo se especificado
            if output_file:
                output_path = Path(output_file)
                output_path.parent.mkdir(parents=True, exist_ok=True)
                
                with open(output_path, 'w', encoding='utf-8') as f:
                    f.write(yaml_content)
                
                logger.info(f"Arquivo YAML salvo: {output_path}")
            
            return {
                'success': True,
                'yaml_content': yaml_content,
                'parsed_yaml': parsed_yaml,
                'output_file': output_file,
                'tokens_used': response.tokens_used,
                'generation_time': response.response_time,
                'statistics': {
                    'input_length': len(input_text),
                    'clean_length': len(clean_text),
                    'output_length': len(yaml_content),
                    'yaml_sections': len(parsed_yaml.keys()) if isinstance(parsed_yaml, dict) else 0
                }
            }
            
        except Exception as e:
            logger.error(f"Erro na geração de prompts: {e}")
            return {
                'success': False,
                'error': str(e),
                'yaml_content': None,
                'parsed_yaml': None
            }

    def generate_from_file(self, input_file: str, output_file: str = None) -> Dict[str, Any]:
        """
        Gera prompts YAML a partir de arquivo de texto.
        
        Args:
            input_file: Caminho para arquivo de texto
            output_file: Caminho para salvar YAML (opcional)
            
        Returns:
            Resultado da geração
        """
        try:
            # Ler arquivo de entrada
            input_path = Path(input_file)
            if not input_path.exists():
                raise FileNotFoundError(f"Arquivo não encontrado: {input_file}")
            
            with open(input_path, 'r', encoding='utf-8') as f:
                input_text = f.read()
            
            logger.info(f"Arquivo lido: {input_file} ({len(input_text)} caracteres)")
            
            # Gerar nome de saída se não especificado
            if not output_file:
                output_file = input_path.stem + "_prompts.yaml"
            
            # Gerar prompts
            result = self.generate_prompt_yaml(input_text, output_file)
            result['input_file'] = input_file
            
            return result
            
        except Exception as e:
            logger.error(f"Erro ao processar arquivo: {e}")
            return {
                'success': False,
                'error': str(e),
                'input_file': input_file
            }

    def validate_generated_prompts(self, yaml_file: str) -> Dict[str, Any]:
        """
        Valida prompts YAML gerados.
        
        Args:
            yaml_file: Caminho para arquivo YAML
            
        Returns:
            Resultado da validação
        """
        try:
            yaml_path = Path(yaml_file)
            if not yaml_path.exists():
                raise FileNotFoundError(f"Arquivo não encontrado: {yaml_file}")
            
            with open(yaml_path, 'r', encoding='utf-8') as f:
                yaml_content = f.read()
            
            # Parse YAML
            parsed = yaml.safe_load(yaml_content)
            
            # Validações estruturais
            required_sections = ['version', 'system_prompt', 'model_prompts', 'base_template', 'analysis_questions']
            missing_sections = [section for section in required_sections if section not in parsed]
            
            # Validar model_prompts
            model_prompts_valid = True
            if 'model_prompts' in parsed:
                for model, config in parsed['model_prompts'].items():
                    required_fields = ['system_prompt', 'persona', 'analysis_depth']
                    missing_fields = [field for field in required_fields if field not in config]
                    if missing_fields:
                        model_prompts_valid = False
                        break
            
            # Validar analysis_questions
            questions_valid = True
            if 'analysis_questions' in parsed:
                for category, config in parsed['analysis_questions'].items():
                    required_fields = ['priority', 'required', 'context', 'focus', 'question']
                    missing_fields = [field for field in required_fields if field not in config]
                    if missing_fields:
                        questions_valid = False
                        break
            
            is_valid = (
                len(missing_sections) == 0 and
                model_prompts_valid and
                questions_valid
            )
            
            return {
                'valid': is_valid,
                'missing_sections': missing_sections,
                'model_prompts_valid': model_prompts_valid,
                'questions_valid': questions_valid,
                'total_questions': len(parsed.get('analysis_questions', {})),
                'total_models': len(parsed.get('model_prompts', {})),
                'file_size': yaml_path.stat().st_size,
                'yaml_file': yaml_file
            }
            
        except Exception as e:
            logger.error(f"Erro na validação: {e}")
            return {
                'valid': False,
                'error': str(e),
                'yaml_file': yaml_file
            }

    def get_status(self) -> Dict[str, Any]:
        """Retorna status do gerador de prompts."""
        try:
            luzia_available = self.luzia_provider.is_available()
            
            return {
                'available': luzia_available,
                'luzia_provider': luzia_available,
                'config_loaded': bool(self.config_manager.config),
                'template_ready': bool(self.prompt_generation_template),
                'version': '2.0.0'
            }
            
        except Exception as e:
            return {
                'available': False,
                'error': str(e),
                'version': '2.0.0'
            }
