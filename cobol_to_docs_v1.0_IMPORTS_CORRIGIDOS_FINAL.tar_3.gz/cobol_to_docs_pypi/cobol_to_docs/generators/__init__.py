"""
Generators - COBOL to Docs v1.0
Autor: Carlos Morais
"""

try:
    from .documentation_generator import DocumentationGenerator
    from .prompt_generator import PromptGenerator
except ImportError:
    # Durante instalação, imports podem falhar
    pass

__all__ = [
    "DocumentationGenerator",
    "PromptGenerator",
]
