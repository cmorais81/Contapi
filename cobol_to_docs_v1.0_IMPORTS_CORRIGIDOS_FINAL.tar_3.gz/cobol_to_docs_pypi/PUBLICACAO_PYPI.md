# Publicação PyPI - COBOL to Docs v1.0

**Autor:** Carlos Morais  
**Versão:** 1.0  
**Data:** Setembro 2025

## Resumo

Este documento explica como publicar o COBOL to Docs v1.0 no PyPI para permitir instalação via `pip install cobol-to-docs`.

## Estrutura do Pacote PyPI

```
cobol_to_docs_pypi/
├── cobol_to_docs/           # Pacote principal
│   ├── __init__.py         # Metadados do pacote
│   ├── cli.py              # CLI principal (wrapper)
│   ├── prompt_cli.py       # CLI gerador de prompts
│   ├── main_original.py    # main.py original (100% compatível)
│   ├── generate_prompts_original.py  # generate_prompts.py original
│   ├── core/               # Componentes centrais
│   ├── providers/          # Provedores de IA
│   ├── generators/         # Geradores
│   ├── parsers/            # Parsers COBOL
│   ├── analyzers/          # Analisadores
│   ├── utils/              # Utilitários
│   ├── config/             # Configurações YAML
│   └── examples/           # Exemplos
├── docs/                   # Documentação completa
├── tests/                  # Testes (futuro)
├── setup.py               # Setup tradicional
├── pyproject.toml         # Configuração moderna
├── requirements.txt       # Dependências
├── MANIFEST.in           # Arquivos adicionais
├── README.md             # Documentação PyPI
└── build_and_publish.sh  # Script de publicação
```

## Compatibilidade Garantida

### ✅ Mantém 100% das Funcionalidades

**Forma Atual (Preservada):**
```bash
python3 main.py --fontes examples/fontes.txt --pdf
python3 generate_prompts.py --interactive
```

**Nova Forma PyPI (Adicional):**
```bash
cobol-to-docs --fontes examples/fontes.txt --pdf
cobol-generate-prompts --interactive
```

### ✅ Mesma Base de Código

- **cli.py**: Wrapper que chama `main_original.py`
- **prompt_cli.py**: Wrapper que chama `generate_prompts_original.py`
- **Código fonte**: Exatamente o mesmo da versão manual
- **Configurações**: Mesmos arquivos YAML
- **Exemplos**: Mesmos arquivos de exemplo

## Processo de Publicação

### 1. Preparação

```bash
# Instalar dependências de build
pip install --upgrade build twine

# Verificar estrutura
cd cobol_to_docs_pypi
ls -la
```

### 2. Build Automático

```bash
# Executar script de build
./build_and_publish.sh
```

**O script faz:**
- Limpa builds anteriores
- Instala dependências
- Executa testes (se existirem)
- Constrói o pacote
- Verifica integridade
- Oferece opções de publicação

### 3. Build Manual

```bash
# Limpar builds anteriores
rm -rf build/ dist/ *.egg-info/

# Construir pacote
python -m build

# Verificar pacote
twine check dist/*
```

### 4. Publicação Test PyPI

```bash
# Publicar no Test PyPI primeiro
twine upload --repository testpypi dist/*

# Testar instalação
pip install -i https://test.pypi.org/simple/ cobol-to-docs

# Testar funcionamento
cobol-to-docs --status
```

### 5. Publicação PyPI Oficial

```bash
# Após testes no Test PyPI
twine upload dist/*

# Instalação oficial
pip install cobol-to-docs
```

## Configuração de Credenciais

### PyPI Token

```bash
# Criar ~/.pypirc
cat > ~/.pypirc << EOF
[distutils]
index-servers =
    pypi
    testpypi

[pypi]
username = __token__
password = pypi-SEU_TOKEN_AQUI

[testpypi]
repository = https://test.pypi.org/legacy/
username = __token__
password = pypi-SEU_TOKEN_TEST_AQUI
EOF
```

### Obter Tokens

1. **Test PyPI**: https://test.pypi.org/manage/account/token/
2. **PyPI Oficial**: https://pypi.org/manage/account/token/

## Comandos Disponíveis Após Instalação

### CLI Principal

```bash
# Análise básica
cobol-to-docs --fontes programa.cbl

# Com PDF
cobol-to-docs --fontes programa.cbl --pdf

# Multi-modelo
cobol-to-docs --fontes programa.cbl --models '["aws-claude-3.7","gpt-4"]'

# Status
cobol-to-docs --status

# Ajuda
cobol-to-docs --help
```

### Gerador de Prompts

```bash
# Interativo
cobol-generate-prompts --interactive

# A partir de arquivo
cobol-generate-prompts --input requisitos.txt --output prompts.yaml

# Validar
cobol-generate-prompts --validate prompts.yaml

# Ajuda
cobol-generate-prompts --help
```

## Vantagens do PyPI

### Para Usuários

**Instalação Simplificada:**
```bash
# Antes
wget https://releases/cobol_to_docs_v1.0.tar.gz
tar -xzf cobol_to_docs_v1.0.tar.gz
cd cobol_to_docs_v1
pip install -r requirements.txt
python3 main.py --status

# Agora
pip install cobol-to-docs
cobol-to-docs --status
```

**Gerenciamento Automático:**
```bash
# Atualização
pip install --upgrade cobol-to-docs

# Desinstalação
pip uninstall cobol-to-docs

# Informações
pip show cobol-to-docs
```

**Comandos Globais:**
```bash
# Disponível em qualquer diretório
cd /qualquer/lugar
cobol-to-docs --fontes /caminho/programa.cbl
```

### Para Distribuição

- **Descoberta**: Listado no PyPI
- **Instalação**: Um comando simples
- **Dependências**: Gerenciadas automaticamente
- **Atualizações**: Sistema de versionamento
- **Documentação**: Integrada ao PyPI

## Uso Programático

### Importação Direta

```python
import cobol_to_docs

# Verificar versão
print(cobol_to_docs.__version__)  # 1.0.0
print(cobol_to_docs.__author__)   # Carlos Morais

# Usar componentes
config = cobol_to_docs.ConfigManager('config.yaml')
parser = cobol_to_docs.COBOLParser()
analyzer = cobol_to_docs.EnhancedCOBOLAnalyzer()
```

### Análise Programática

```python
import cobol_to_docs

# Configurar
config_manager = cobol_to_docs.ConfigManager()
prompt_manager = cobol_to_docs.DualPromptManager(config_manager.config)
provider_manager = cobol_to_docs.EnhancedProviderManager(config_manager.config)

# Analisar
parser = cobol_to_docs.COBOLParser()
analyzer = cobol_to_docs.EnhancedCOBOLAnalyzer(provider_manager, prompt_manager)

with open('programa.cbl', 'r') as f:
    codigo = f.read()

parsed = parser.parse_program(codigo, 'programa.cbl')
resultado = analyzer.analyze_program(parsed, 'aws-claude-3.7')

print(f"Sucesso: {resultado.success}")
print(f"Tokens: {resultado.tokens_used}")
print(f"Conteúdo: {resultado.content}")
```

## Migração de Usuários

### Usuários Atuais

**Podem continuar usando a forma atual:**
```bash
# Continua funcionando normalmente
cd cobol_to_docs_v1
python3 main.py --fontes examples/fontes.txt
```

**Ou migrar para PyPI:**
```bash
# Instalar via PyPI
pip install cobol-to-docs

# Usar nova forma
cobol-to-docs --fontes examples/fontes.txt
```

### Novos Usuários

**Forma recomendada:**
```bash
pip install cobol-to-docs
cobol-to-docs --fontes programa.cbl
```

## Versionamento

### Esquema de Versões

- **1.0.0**: Lançamento inicial
- **1.0.1**: Correções de bugs
- **1.1.0**: Novas funcionalidades menores
- **2.0.0**: Mudanças significativas

### Atualização de Versão

```bash
# Editar pyproject.toml
version = "1.0.1"

# Editar __init__.py
__version__ = "1.0.1"

# Build e publicar
./build_and_publish.sh
```

## Monitoramento

### Estatísticas PyPI

- **Downloads**: https://pypistats.org/packages/cobol-to-docs
- **Dependentes**: Projetos que usam o pacote
- **Versões**: Histórico de releases

### Feedback

- **Issues**: GitHub Issues
- **Ratings**: PyPI ratings
- **Downloads**: Métricas de uso

## Checklist de Publicação

### Antes da Publicação

- [ ] Código testado e funcionando
- [ ] Documentação atualizada
- [ ] Versão incrementada
- [ ] README.md completo
- [ ] requirements.txt atualizado
- [ ] Exemplos funcionais

### Durante a Publicação

- [ ] Build sem erros
- [ ] Verificação twine OK
- [ ] Test PyPI funcionando
- [ ] Instalação de teste OK
- [ ] Comandos CLI funcionando

### Após a Publicação

- [ ] PyPI oficial funcionando
- [ ] Documentação no GitHub atualizada
- [ ] Release notes criadas
- [ ] Usuários notificados

## Comandos de Referência

### Build e Teste

```bash
# Build completo
python -m build

# Teste local
pip install dist/*.whl
cobol-to-docs --status

# Publicar test
twine upload --repository testpypi dist/*

# Testar test PyPI
pip install -i https://test.pypi.org/simple/ cobol-to-docs

# Publicar oficial
twine upload dist/*
```

### Verificação

```bash
# Verificar pacote
twine check dist/*

# Informações do pacote
pip show cobol-to-docs

# Listar arquivos
pip show -f cobol-to-docs

# Testar importação
python -c "import cobol_to_docs; print(cobol_to_docs.__version__)"
```

---

**COBOL to Docs v1.0**  
**Desenvolvido por Carlos Morais**  
**Pronto para publicação no PyPI!**
