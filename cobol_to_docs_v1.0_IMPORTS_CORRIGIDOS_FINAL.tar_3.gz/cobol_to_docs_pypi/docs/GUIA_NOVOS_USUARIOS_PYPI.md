# Guia para Novos Usuários - COBOL to Docs v1.0 via PyPI

**Autor:** Carlos Morais  
**Versão:** 1.0  
**Data:** Setembro 2025

## Para Quem Nunca Usou o Sistema

Este guia é especialmente para usuários que instalam o COBOL to Docs v1.0 via `pip install` e não têm arquivos de configuração.

## Instalação Completa para Iniciantes

### 1. Instalar o Sistema

```bash
pip install cobol-to-docs
```

### 2. Inicializar Configuração

```bash
# Criar configuração no diretório atual
cobol-init
```

**O que acontece:**
- Cria pasta `cobol_to_docs_config/`
- Copia todos os arquivos de configuração necessários
- Cria exemplos prontos para uso
- Gera guia de uso personalizado

### 3. Verificar Instalação

```bash
cobol-to-docs --config cobol_to_docs_config/config.yaml --status
```

## Estrutura Criada pelo `cobol-init`

```
cobol_to_docs_config/
├── config.yaml                    # Configuração principal
├── prompts_original.yaml          # Prompts técnicos padrão
├── prompts_doc_legado_pro.yaml    # Prompts especializados
├── fontes_exemplo.txt             # Lista de arquivos COBOL
├── requisitos_exemplo.txt         # Exemplo para prompts personalizados
├── COMO_USAR.md                   # Guia personalizado
└── examples/                      # Programas COBOL de exemplo
    ├── programa_exemplo.cbl       # Programa de exemplo
    └── fontes.txt                 # Lista de exemplos
```

## Primeiro Uso - Passo a Passo

### Teste com Exemplo Incluído

```bash
# Analisar programa de exemplo
cobol-to-docs --config cobol_to_docs_config/config.yaml --fontes cobol_to_docs_config/examples/fontes.txt --pdf
```

**Resultado:**
- Pasta `output/` com documentação gerada
- Arquivo HTML otimizado para PDF
- Logs de processamento

### Analisar Seus Próprios Programas

#### 1. Editar Lista de Arquivos

```bash
# Editar arquivo de fontes
nano cobol_to_docs_config/fontes_exemplo.txt
```

**Adicionar seus arquivos:**
```
# Lista de arquivos COBOL para análise
/caminho/para/meu_programa.cbl
/caminho/para/outro_programa.cbl
```

#### 2. Executar Análise

```bash
cobol-to-docs --config cobol_to_docs_config/config.yaml --fontes cobol_to_docs_config/fontes_exemplo.txt --pdf
```

## Configuração de Credenciais (Opcional)

### LuzIA API

Se você tem credenciais da API LuzIA:

**Linux/macOS:**
```bash
export LUZIA_CLIENT_ID='seu_client_id'
export LUZIA_CLIENT_SECRET='seu_client_secret'
```

**Windows PowerShell:**
```powershell
$env:LUZIA_CLIENT_ID='seu_client_id'
$env:LUZIA_CLIENT_SECRET='seu_client_secret'
```

**Windows CMD:**
```cmd
set LUZIA_CLIENT_ID=seu_client_id
set LUZIA_CLIENT_SECRET=seu_secret
```

### Testar Credenciais

```bash
cobol-to-docs --config cobol_to_docs_config/config.yaml --status
```

## Prompts Personalizados

### Gerar Prompts Específicos

#### 1. Editar Requisitos

```bash
# Editar arquivo de requisitos
nano cobol_to_docs_config/requisitos_exemplo.txt
```

**Exemplo de conteúdo:**
```
Análise para Sistema Financeiro

Preciso de análise focada em:
- Cálculos de juros e taxas
- Validações de dados financeiros
- Controles de auditoria
- Regras de negócio bancárias
```

#### 2. Gerar Prompts

```bash
cobol-generate-prompts --input cobol_to_docs_config/requisitos_exemplo.txt --output meus_prompts_financeiros.yaml
```

#### 3. Usar Prompts Personalizados

```bash
cobol-to-docs --config cobol_to_docs_config/config.yaml --fontes cobol_to_docs_config/fontes_exemplo.txt --prompts-file meus_prompts_financeiros.yaml --pdf
```

## Análise Multi-Modelo

### Comparar Diferentes Modelos

```bash
cobol-to-docs --config cobol_to_docs_config/config.yaml --fontes cobol_to_docs_config/fontes_exemplo.txt --models '["aws-claude-3.7","enhanced_mock"]' --pdf
```

**Resultado:**
- Análise separada para cada modelo
- Relatório comparativo automático
- Métricas de performance

## Comandos Úteis para Iniciantes

### Ajuda Geral

```bash
# Ajuda do CLI principal
cobol-to-docs --help

# Ajuda do gerador de prompts
cobol-generate-prompts --help

# Ajuda da inicialização
cobol-init --help
```

### Verificações

```bash
# Status do sistema
cobol-to-docs --config cobol_to_docs_config/config.yaml --status

# Validar prompts gerados
cobol-generate-prompts --validate meus_prompts.yaml

# Informações do pacote
pip show cobol-to-docs
```

### Geração Interativa de Prompts

```bash
# Modo interativo (sem arquivo)
cobol-generate-prompts --interactive
```

## Estrutura de Saída

### Análise Simples

```
output/
├── programa_exemplo/
│   ├── documentacao.md          # Documentação principal
│   ├── relatorio.html          # Relatório HTML (para PDF)
│   └── analise_detalhada.md    # Análise técnica
└── logs/                       # Logs de processamento
```

### Análise Multi-Modelo

```
output/
├── model_aws_claude_3_7/       # Análise do Claude
├── model_enhanced_mock/        # Análise do Mock
├── relatorio_comparativo_modelos.md  # Comparação
└── logs/
```

## Solução de Problemas Comuns

### Erro: "Config file not found"

```bash
# Verificar se inicializou configuração
ls -la cobol_to_docs_config/

# Se não existe, inicializar
cobol-init

# Usar caminho absoluto
cobol-to-docs --config $(pwd)/cobol_to_docs_config/config.yaml --status
```

### Erro: "No COBOL files found"

```bash
# Verificar arquivo de fontes
cat cobol_to_docs_config/fontes_exemplo.txt

# Verificar se arquivos existem
ls -la /caminho/para/programa.cbl

# Usar exemplos incluídos para testar
cobol-to-docs --config cobol_to_docs_config/config.yaml --fontes cobol_to_docs_config/examples/fontes.txt
```

### Erro: "Provider not available"

```bash
# Verificar status
cobol-to-docs --config cobol_to_docs_config/config.yaml --status

# Sistema funciona sem credenciais LuzIA (usa enhanced_mock)
# Para usar LuzIA, configure credenciais
```

## Workflows Recomendados

### Para Análise Única

```bash
# 1. Inicializar (uma vez)
cobol-init

# 2. Editar lista de arquivos
nano cobol_to_docs_config/fontes_exemplo.txt

# 3. Analisar
cobol-to-docs --config cobol_to_docs_config/config.yaml --fontes cobol_to_docs_config/fontes_exemplo.txt --pdf
```

### Para Análise Personalizada

```bash
# 1. Criar requisitos específicos
nano cobol_to_docs_config/requisitos_exemplo.txt

# 2. Gerar prompts
cobol-generate-prompts --input cobol_to_docs_config/requisitos_exemplo.txt --output prompts_personalizados.yaml

# 3. Analisar com prompts personalizados
cobol-to-docs --config cobol_to_docs_config/config.yaml --fontes cobol_to_docs_config/fontes_exemplo.txt --prompts-file prompts_personalizados.yaml --pdf
```

### Para Análise Comparativa

```bash
# Análise com múltiplos modelos
cobol-to-docs --config cobol_to_docs_config/config.yaml --fontes cobol_to_docs_config/fontes_exemplo.txt --models '["aws-claude-3.7","enhanced_mock"]' --pdf
```

## Dicas Importantes

### Caminhos de Arquivos

- **Use caminhos absolutos** para evitar problemas
- **Verifique se arquivos existem** antes de executar
- **Use aspas** em caminhos com espaços

### Configuração

- **Mantenha** `cobol_to_docs_config/` no seu projeto
- **Versione** arquivos de configuração no Git
- **Customize** `config.yaml` conforme necessário

### Performance

- **Comece com exemplos** para testar
- **Use enhanced_mock** para testes rápidos
- **Configure LuzIA** para análises reais

## Próximos Passos

1. **Testar com exemplos** incluídos
2. **Analisar seus programas** COBOL
3. **Gerar prompts personalizados** para seu domínio
4. **Explorar análise multi-modelo**
5. **Configurar credenciais** LuzIA se disponível

## Suporte

- **Guia personalizado**: `cobol_to_docs_config/COMO_USAR.md`
- **Documentação completa**: Pasta `docs/` no repositório
- **Ajuda CLI**: `cobol-to-docs --help`

---

**COBOL to Docs v1.0**  
**Desenvolvido por Carlos Morais**  
**Sistema completo para documentação automatizada de COBOL**
