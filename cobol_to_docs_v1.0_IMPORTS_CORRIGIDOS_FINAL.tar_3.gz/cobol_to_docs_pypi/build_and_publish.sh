#!/bin/bash
# Script de Build e Publicação - COBOL to Docs v1.0
# Autor: Carlos Morais

echo "=================================================="
echo "COBOL to Docs v1.0 - Build e Publicação PyPI"
echo "Autor: Carlos Morais"
echo "=================================================="
echo

# Verificar se está no diretório correto
if [ ! -f "setup.py" ] || [ ! -f "pyproject.toml" ]; then
    echo "❌ Execute este script no diretório raiz do projeto"
    exit 1
fi

# Limpar builds anteriores
echo "🧹 Limpando builds anteriores..."
rm -rf build/ dist/ *.egg-info/
echo "✅ Limpeza concluída"
echo

# Instalar dependências de build
echo "📦 Instalando dependências de build..."
pip install --upgrade build twine
echo "✅ Dependências instaladas"
echo

# Executar testes (se existirem)
if [ -d "tests" ]; then
    echo "🧪 Executando testes..."
    python -m pytest tests/ -v
    if [ $? -ne 0 ]; then
        echo "❌ Testes falharam. Abortando build."
        exit 1
    fi
    echo "✅ Testes passaram"
    echo
fi

# Build do pacote
echo "🔨 Construindo pacote..."
python -m build
if [ $? -ne 0 ]; then
    echo "❌ Erro no build do pacote"
    exit 1
fi
echo "✅ Pacote construído com sucesso"
echo

# Verificar pacote
echo "🔍 Verificando pacote..."
twine check dist/*
if [ $? -ne 0 ]; then
    echo "❌ Erro na verificação do pacote"
    exit 1
fi
echo "✅ Pacote verificado"
echo

# Mostrar arquivos gerados
echo "📁 Arquivos gerados:"
ls -la dist/
echo

# Opções de publicação
echo "🚀 Opções de publicação:"
echo
echo "1. Test PyPI (recomendado primeiro):"
echo "   twine upload --repository testpypi dist/*"
echo
echo "2. PyPI oficial:"
echo "   twine upload dist/*"
echo
echo "3. Instalação local para teste:"
echo "   pip install dist/*.whl"
echo
echo "4. Teste da instalação:"
echo "   pip install -i https://test.pypi.org/simple/ cobol-to-docs"
echo

# Perguntar se quer publicar automaticamente
read -p "Publicar no Test PyPI automaticamente? (s/N): " -n 1 -r
echo
if [[ $REPLY =~ ^[Ss]$ ]]; then
    echo "📤 Publicando no Test PyPI..."
    twine upload --repository testpypi dist/*
    
    if [ $? -eq 0 ]; then
        echo "✅ Publicado no Test PyPI com sucesso!"
        echo
        echo "🧪 Para testar a instalação:"
        echo "pip install -i https://test.pypi.org/simple/ cobol-to-docs"
        echo
        echo "🎯 Se tudo estiver OK, publique no PyPI oficial:"
        echo "twine upload dist/*"
    else
        echo "❌ Erro na publicação no Test PyPI"
    fi
else
    echo "ℹ️  Build concluído. Use os comandos acima para publicar manualmente."
fi

echo
echo "=================================================="
echo "✅ PROCESSO CONCLUÍDO"
echo "=================================================="
