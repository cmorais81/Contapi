#!/usr/bin/env python3.11
# -*- coding: utf-8 -*-
"""
COBOL AI Engine v2.2.2 - Multi-Provider Analysis
Sistema com LuzIA + GitHub Copilot para documentação superior

Autor: Manus AI
Data: 17 de Setembro de 2025
"""

import argparse
import logging
import os
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

# Adicionar o diretório src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.core.config import ConfigManager
from src.core.exceptions import COBOLAIEngineException
from src.core.token_manager import TokenManager
from src.parsers.cobol_parser import COBOLParser
from src.providers.provider_manager import ProviderManager
from src.providers.multi_provider_analyzer import MultiProviderAnalyzer
from src.analyzers.cobol_code_analyzer import COBOLCodeAnalyzer
from src.generators.programmer_documentation_generator import ProgrammerDocumentationGenerator
from src.utils.pdf_converter import MarkdownToPDFConverter
from src.providers.base_provider import AIRequest

def setup_logging(log_level: str = "INFO") -> None:
    """Configurar logging do sistema"""
    logging.basicConfig(
        level=getattr(logging, log_level.upper()),
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler('logs/cobol_multi_provider.log', 'a', encoding='utf-8')
        ]
    )
    
    # Criar diretório de logs se não existir
    os.makedirs('logs', exist_ok=True)

def parse_arguments() -> argparse.Namespace:
    """Parse dos argumentos da linha de comando"""
    parser = argparse.ArgumentParser(
        description='COBOL AI Engine v2.2.2 - Multi-Provider Analysis (LuzIA + Copilot)',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Exemplos de uso:

  # Análise multi-provider básica
  python main_multi_provider.py --fontes examples/fontes.txt

  # Análise completa com LuzIA + Copilot
  python main_multi_provider.py --fontes examples/fontes.txt --books examples/BOOKS.txt --enable-copilot

  # Análise com foco em migração para Java
  python main_multi_provider.py --fontes examples/fontes.txt --target-language java --migration-focus

  # Análise paralela com múltiplos providers
  python main_multi_provider.py --fontes examples/fontes.txt --parallel --max-concurrent 2

  # Análise com estratégia de consenso
  python main_multi_provider.py --fontes examples/fontes.txt --combination-strategy consensus_first
        """
    )
    
    parser.add_argument(
        '--fontes', 
        required=True,
        help='Arquivo contendo lista de programas COBOL para análise'
    )
    
    parser.add_argument(
        '--books', 
        help='Arquivo contendo lista de copybooks COBOL (opcional)'
    )
    
    parser.add_argument(
        '--config',
        default='config/config_unified_multi_provider.yaml',
        help='Arquivo de configuração YAML (padrão: config/config_unified_multi_provider.yaml)'
    )
    
    parser.add_argument(
        '--output',
        default='multi_provider_analysis',
        help='Diretório de saída para a documentação (padrão: multi_provider_analysis)'
    )
    
    parser.add_argument(
        '--target-language',
        choices=['java', 'python', 'csharp', 'javascript', 'typescript', 'go', 'all'],
        default='java',
        help='Linguagem alvo para exemplos de migração (padrão: java)'
    )
    
    parser.add_argument(
        '--enable-copilot',
        action='store_true',
        help='Habilitar GitHub Copilot como provider secundário'
    )
    
    parser.add_argument(
        '--parallel',
        action='store_true',
        help='Executar análises de providers em paralelo (mais rápido)'
    )
    
    parser.add_argument(
        '--max-concurrent',
        type=int,
        default=2,
        help='Máximo de providers executando simultaneamente (padrão: 2)'
    )
    
    parser.add_argument(
        '--combination-strategy',
        choices=['weighted_merge', 'consensus_first', 'primary_enhanced', 'simple_merge'],
        default='primary_enhanced',
        help='Estratégia para combinar resultados dos providers (padrão: primary_enhanced)'
    )
    
    parser.add_argument(
        '--migration-focus',
        action='store_true',
        help='Focar na documentação para migração de sistemas'
    )
    
    parser.add_argument(
        '--include-problems',
        action='store_true',
        help='Incluir análise detalhada de problemas no código'
    )
    
    parser.add_argument(
        '--consensus-threshold',
        type=float,
        default=0.7,
        help='Limiar para consenso entre providers (0.0-1.0, padrão: 0.7)'
    )
    
    parser.add_argument(
        '--provider-weights',
        help='Pesos dos providers no formato "luzia:0.6,copilot:0.4"'
    )
    
    parser.add_argument(
        '--detailed-stats',
        action='store_true',
        help='Incluir estatísticas detalhadas de cada provider'
    )
    
    parser.add_argument(
        '--log-level',
        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'],
        default='INFO',
        help='Nível de logging (padrão: INFO)'
    )
    
    parser.add_argument(
        '--no-pdf',
        action='store_true',
        help='Desabilitar geração de HTML para PDF'
    )
    
    parser.add_argument(
        '--version',
        action='version',
        version='COBOL AI Engine v2.2.2 - Multi-Provider Analysis'
    )
    
    return parser.parse_args()

def update_config_from_args(config: Dict, args: argparse.Namespace) -> Dict:
    """Atualiza configuração com argumentos da linha de comando"""
    
    # Configurações multi-provider
    if 'multi_provider' not in config:
        config['multi_provider'] = {}
    
    mp_config = config['multi_provider']
    
    # Habilitar multi-provider se Copilot foi solicitado
    if args.enable_copilot:
        mp_config['enabled'] = True
        mp_config['secondary_providers'] = ['copilot']
    
    # Configurações de execução
    if args.parallel:
        mp_config['parallel_execution'] = True
    
    mp_config['max_concurrent'] = args.max_concurrent
    mp_config['combination_strategy'] = args.combination_strategy
    mp_config['consensus_threshold'] = args.consensus_threshold
    
    # Pesos dos providers
    if args.provider_weights:
        weights = {}
        for pair in args.provider_weights.split(','):
            provider, weight = pair.split(':')
            weights[provider.strip()] = float(weight.strip())
        mp_config['provider_weights'] = weights
    
    # Configurações de documentação
    if 'programmer_documentation' not in config:
        config['programmer_documentation'] = {}
    
    doc_config = config['programmer_documentation']
    doc_config['target_language'] = args.target_language
    doc_config['migration_focus'] = args.migration_focus
    doc_config['include_problems'] = args.include_problems
    
    return config

def create_multi_provider_context(program_name: str, business_comments: List[str], 
                                business_rules: List, copybooks: List[str],
                                args: argparse.Namespace) -> str:
    """Criar contexto otimizado para análise multi-provider"""
    context_parts = []
    
    # Cabeçalho especializado
    context_parts.append("=== CONTEXTO PARA ANÁLISE MULTI-PROVIDER ===")
    context_parts.append(f"PROGRAMA: {program_name}")
    context_parts.append(f"PROVIDERS: LuzIA (primário) + {'Copilot' if args.enable_copilot else 'Mock'} (secundário)")
    context_parts.append(f"ESTRATÉGIA: {args.combination_strategy}")
    context_parts.append(f"LINGUAGEM ALVO: {args.target_language}")
    
    if args.migration_focus:
        context_parts.append("FOCO ESPECIAL: Migração de sistemas legados")
    
    if args.include_problems:
        context_parts.append("ANÁLISE ESPECIAL: Detecção de problemas e anti-padrões")
    
    context_parts.append("")
    
    # Comentários originais
    if business_comments:
        context_parts.append(f"COMENTÁRIOS ORIGINAIS ({len(business_comments)} encontrados):")
        for i, comment in enumerate(business_comments[:8], 1):
            context_parts.append(f"  {i}. {comment}")
        if len(business_comments) > 8:
            context_parts.append(f"  ... e mais {len(business_comments) - 8} comentários")
    else:
        context_parts.append("COMENTÁRIOS ORIGINAIS: Código sem comentários significativos")
    
    context_parts.append("")
    
    # Regras de negócio com categorização avançada
    if business_rules:
        context_parts.append(f"REGRAS DE NEGÓCIO PRÉ-IDENTIFICADAS ({len(business_rules)} regras):")
        
        # Categorizar regras
        rule_categories = {}
        for rule in business_rules:
            category = getattr(rule, 'rule_type', 'Geral')
            if category not in rule_categories:
                rule_categories[category] = []
            rule_categories[category].append(rule)
        
        for category, rules in rule_categories.items():
            context_parts.append(f"  - {category}: {len(rules)} regras")
            # Exemplos das regras mais importantes
            for rule in rules[:3]:
                description = getattr(rule, 'description', 'Regra identificada')[:80]
                context_parts.append(f"    * {description}...")
    else:
        context_parts.append("REGRAS DE NEGÓCIO: Serão identificadas durante análise multi-provider")
    
    context_parts.append("")
    
    # Copybooks e dependências
    if copybooks:
        context_parts.append(f"COPYBOOKS E DEPENDÊNCIAS ({len(copybooks)} identificados):")
        for copybook in copybooks[:12]:
            context_parts.append(f"  - {copybook}")
        if len(copybooks) > 12:
            context_parts.append(f"  ... e mais {len(copybooks) - 12} copybooks")
    else:
        context_parts.append("COPYBOOKS: Nenhuma dependência externa identificada")
    
    context_parts.append("")
    context_parts.append("=== INSTRUÇÕES PARA ANÁLISE MULTI-PROVIDER ===")
    context_parts.append("1. CADA PROVIDER deve focar em seus pontos fortes:")
    context_parts.append("   - LuzIA: Expertise em COBOL e sistemas bancários")
    context_parts.append("   - Copilot: Padrões modernos e boas práticas de código")
    context_parts.append("2. IDENTIFIQUE aspectos únicos que outros providers podem perder")
    context_parts.append("3. FORNEÇA insights complementares, não redundantes")
    context_parts.append("4. FOQUE em documentação que permita migração completa")
    context_parts.append("5. DETECTE problemas específicos da sua especialidade")
    
    return "\n".join(context_parts)

def analyze_with_multi_provider(program_name: str, program_code: str, 
                              multi_analyzer: MultiProviderAnalyzer, config: Dict,
                              pre_analysis_context: str, args: argparse.Namespace) -> Optional[Dict]:
    """Realizar análise multi-provider"""
    try:
        logging.info(f"Iniciando análise multi-provider: {program_name}")
        
        # Obter prompts da configuração
        system_prompt = config.get('prompts', {}).get('system_prompts', {}).get('comprehensive_cobol_documentation', '')
        user_template = config.get('prompts', {}).get('user_prompts', {}).get('multi_provider_analysis', '')
        
        # Fallback para prompts padrão se não encontrados
        if not system_prompt:
            system_prompt = """
Você é um ESPECIALISTA EM ARQUITETURA DE SOFTWARE com expertise em sistemas mainframe e modernização.

Crie documentação TÉCNICA EXCEPCIONAL que permita:
1. COMPREENSÃO COMPLETA da lógica implementada
2. IDENTIFICAÇÃO de todas as regras de negócio
3. MAPEAMENTO para linguagens modernas
4. DETECÇÃO de problemas e oportunidades
5. REIMPLEMENTAÇÃO em tecnologias atuais

Seja EXTREMAMENTE DETALHADO e DIDÁTICO.
"""
        
        if not user_template:
            user_template = """
Analise o programa COBOL com MÁXIMO DETALHAMENTO:

PROGRAMA: {program_name}

CONTEXTO:
{pre_analysis_context}

CÓDIGO:
{program_code}

Forneça análise completa para migração e modernização.
"""
        
        # Preparar prompt
        try:
            user_prompt = user_template.format(
                program_name=program_name,
                pre_analysis_context=pre_analysis_context,
                program_code=program_code
            )
        except KeyError:
            user_prompt = f"""
Analise o programa COBOL {program_name} com máximo detalhamento:

CONTEXTO:
{pre_analysis_context}

CÓDIGO:
{program_code}

Forneça análise completa para documentação técnica e migração.
"""
        
        # Criar requisição
        full_prompt = f"{system_prompt}\n\n{user_prompt}"
        request = AIRequest(
            prompt=full_prompt,
            max_tokens=config.get('ai', {}).get('global_max_tokens', 8000),
            temperature=config.get('ai', {}).get('global_temperature', 0.02)
        )
        
        # Executar análise multi-provider
        result = multi_analyzer.analyze_with_multiple_providers(request, program_name)
        
        if result.primary_result and result.primary_result.success:
            logging.info(f"Análise multi-provider concluída: {program_name} - "
                        f"{len(result.providers_used)} providers, "
                        f"consenso {result.confidence_score:.2f}")
            
            return {
                'success': True,
                'content': result.combined_analysis,
                'tokens': result.total_tokens,
                'providers_used': result.providers_used,
                'confidence_score': result.confidence_score,
                'consensus_points': result.consensus_points,
                'divergent_points': result.divergent_points,
                'analysis_time': result.analysis_time
            }
        else:
            logging.warning(f"Falha na análise multi-provider de {program_name}")
            return None
            
    except Exception as e:
        logging.error(f"Erro na análise multi-provider de {program_name}: {e}")
        return None

def generate_multi_provider_documentation(program_name: str, analysis_result: Dict, 
                                        business_rules: List, output_dir: str,
                                        args: argparse.Namespace) -> bool:
    """Gerar documentação multi-provider"""
    try:
        doc_generator = ProgrammerDocumentationGenerator()
        
        # Preparar dados com informações multi-provider
        analysis_data = {
            'program_name': program_name,
            'analysis_content': analysis_result['content'],
            'business_rules': business_rules,
            'timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
            'version': 'v2.2.2 Multi-Provider Analysis',
            'target_language': args.target_language,
            'migration_focus': args.migration_focus,
            'include_problems': args.include_problems,
            'providers_used': analysis_result.get('providers_used', []),
            'confidence_score': analysis_result.get('confidence_score', 0.0),
            'consensus_points': analysis_result.get('consensus_points', []),
            'divergent_points': analysis_result.get('divergent_points', []),
            'multi_provider': True
        }
        
        # Gerar documentação
        doc_path = os.path.join(output_dir, f"{program_name}_MULTI_PROVIDER_DOCS.md")
        success = doc_generator.generate_programmer_documentation(analysis_data, doc_path)
        
        if success:
            logging.info(f"Documentação multi-provider gerada: {doc_path}")
        
        return success
        
    except Exception as e:
        logging.error(f"Erro ao gerar documentação multi-provider de {program_name}: {e}")
        return False

def generate_multi_provider_report(results: Dict, output_dir: str, 
                                 config: Dict, args: argparse.Namespace,
                                 multi_analyzer: MultiProviderAnalyzer) -> str:
    """Gerar relatório consolidado multi-provider"""
    try:
        report_path = os.path.join(output_dir, "RELATORIO_MULTI_PROVIDER.md")
        
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write("# Relatório Multi-Provider - LuzIA + GitHub Copilot\n\n")
            f.write(f"**Data de Geração:** {time.strftime('%d/%m/%Y %H:%M:%S')}\n")
            f.write(f"**Versão do Sistema:** COBOL AI Engine v2.2.2 Multi-Provider\n")
            f.write(f"**Providers Utilizados:** {config.get('ai', {}).get('primary_provider', 'luzia')} + {'copilot' if args.enable_copilot else 'mock'}\n")
            f.write(f"**Estratégia de Combinação:** {args.combination_strategy}\n")
            f.write(f"**Execução:** {'Paralela' if args.parallel else 'Sequencial'}\n")
            f.write(f"**Linguagem Alvo:** {args.target_language}\n\n")
            
            # Estatísticas multi-provider
            mp_stats = multi_analyzer.get_statistics()
            total_programs = len(results)
            successful_analyses = sum(1 for r in results.values() if r.get('success', False))
            total_tokens = sum(r.get('tokens', 0) for r in results.values())
            avg_confidence = sum(r.get('confidence_score', 0) for r in results.values()) / max(total_programs, 1)
            
            f.write("## 📊 Estatísticas Multi-Provider\n\n")
            f.write(f"- **Programas Analisados:** {total_programs}\n")
            f.write(f"- **Análises Bem-sucedidas:** {successful_analyses}/{total_programs}\n")
            f.write(f"- **Taxa de Sucesso:** {(successful_analyses/total_programs*100):.1f}%\n")
            f.write(f"- **Confiança Média:** {avg_confidence:.2f}/1.0\n")
            f.write(f"- **Total de Tokens:** {total_tokens:,}\n")
            f.write(f"- **Providers Ativos:** {mp_stats.get('enabled', False)}\n")
            f.write(f"- **Execução Paralela:** {mp_stats.get('parallel_execution', False)}\n\n")
            
            # Uso de providers
            if args.detailed_stats:
                f.write("## 🔧 Estatísticas Detalhadas por Provider\n\n")
                provider_usage = mp_stats.get('provider_usage', {})
                for provider, usage_count in provider_usage.items():
                    f.write(f"### {provider.title()}\n")
                    f.write(f"- **Utilizações:** {usage_count}\n")
                    f.write(f"- **Taxa de Uso:** {(usage_count/total_programs*100):.1f}%\n\n")
            
            # Resumo por programa
            f.write("## 📋 Resumo por Programa\n\n")
            f.write("| Programa | Status | Providers | Confiança | Tokens | Documentação |\n")
            f.write("|----------|--------|-----------|-----------|--------|-------------|\n")
            
            for program_name, result in results.items():
                status = "✅ Sucesso" if result.get('success', False) else "❌ Falha"
                providers = ", ".join(result.get('providers_used', ['N/A']))
                confidence = f"{result.get('confidence_score', 0):.2f}"
                tokens = f"{result.get('tokens', 0):,}"
                doc_link = f"[{program_name}_MULTI_PROVIDER_DOCS.md](./{program_name}_MULTI_PROVIDER_DOCS.md)" if result.get('success') else "N/A"
                
                f.write(f"| {program_name} | {status} | {providers} | {confidence} | {tokens} | {doc_link} |\n")
            
            f.write("\n")
            
            # Análise de consenso
            f.write("## 🤝 Análise de Consenso Multi-Provider\n\n")
            
            consensus_programs = [p for p, r in results.items() if r.get('consensus_points')]
            if consensus_programs:
                f.write("### Programas com Alto Consenso:\n")
                for program_name in consensus_programs[:5]:
                    result = results[program_name]
                    f.write(f"**{program_name}** (Confiança: {result.get('confidence_score', 0):.2f})\n")
                    for point in result.get('consensus_points', [])[:3]:
                        f.write(f"- {point}\n")
                    f.write("\n")
            
            # Pontos divergentes
            divergent_programs = [p for p, r in results.items() if r.get('divergent_points')]
            if divergent_programs:
                f.write("### Pontos de Divergência Identificados:\n")
                for program_name in divergent_programs[:3]:
                    result = results[program_name]
                    f.write(f"**{program_name}:**\n")
                    for point in result.get('divergent_points', [])[:2]:
                        f.write(f"- {point}\n")
                    f.write("\n")
            
            # Vantagens da análise multi-provider
            f.write("## 🚀 Vantagens da Análise Multi-Provider\n\n")
            f.write("### LuzIA (Provider Primário):\n")
            f.write("- Especialização em sistemas COBOL e mainframe\n")
            f.write("- Conhecimento de padrões bancários e regulamentações\n")
            f.write("- Análise contextual de regras de negócio\n\n")
            
            if args.enable_copilot:
                f.write("### GitHub Copilot (Provider Secundário):\n")
                f.write("- Expertise em padrões modernos de desenvolvimento\n")
                f.write("- Sugestões de refatoração e melhores práticas\n")
                f.write("- Conhecimento de linguagens e frameworks atuais\n\n")
            
            f.write("### Benefícios da Combinação:\n")
            f.write("- **Cobertura Completa:** Aspectos técnicos e de negócio\n")
            f.write("- **Validação Cruzada:** Redução de interpretações incorretas\n")
            f.write("- **Insights Únicos:** Cada provider contribui com sua especialidade\n")
            f.write("- **Maior Confiança:** Consenso entre múltiplas análises\n\n")
            
            # Configurações utilizadas
            f.write("## ⚙️ Configurações da Análise\n\n")
            f.write(f"- **Provider Primário:** {config.get('ai', {}).get('primary_provider', 'N/A')}\n")
            f.write(f"- **Providers Secundários:** {', '.join(config.get('multi_provider', {}).get('secondary_providers', []))}\n")
            f.write(f"- **Estratégia de Combinação:** {args.combination_strategy}\n")
            f.write(f"- **Execução:** {'Paralela' if args.parallel else 'Sequencial'}\n")
            f.write(f"- **Max Concurrent:** {args.max_concurrent}\n")
            f.write(f"- **Limiar de Consenso:** {args.consensus_threshold}\n")
            f.write(f"- **Max Tokens:** {config.get('ai', {}).get('global_max_tokens', 'N/A')}\n")
            f.write(f"- **Temperature:** {config.get('ai', {}).get('global_temperature', 'N/A')}\n\n")
            
            f.write("---\n\n")
            f.write("*Relatório gerado automaticamente pelo COBOL AI Engine v2.2.2*\n")
            f.write("*Sistema Multi-Provider com LuzIA + GitHub Copilot*\n")
            
        logging.info(f"Relatório multi-provider gerado: {report_path}")
        return report_path
        
    except Exception as e:
        logging.error(f"Erro ao gerar relatório multi-provider: {e}")
        return ""

def main():
    """Função principal"""
    try:
        # Parse dos argumentos
        args = parse_arguments()
        
        # Setup do logging
        setup_logging(args.log_level)
        
        logging.info("=== INICIANDO COBOL AI ENGINE v2.2.2 - MULTI-PROVIDER ANALYSIS ===")
        logging.info(f"Configuração: {args.config}")
        logging.info(f"Fontes: {args.fontes}")
        logging.info(f"Saída: {args.output}")
        logging.info(f"Copilot: {'Habilitado' if args.enable_copilot else 'Desabilitado'}")
        logging.info(f"Execução: {'Paralela' if args.parallel else 'Sequencial'}")
        logging.info(f"Estratégia: {args.combination_strategy}")
        
        # Carregar configuração
        config_manager = ConfigManager(args.config)
        config = config_manager.get_config()
        
        # Atualizar configuração com argumentos
        config = update_config_from_args(config, args)
        
        # Criar diretório de saída
        os.makedirs(args.output, exist_ok=True)
        
        # Inicializar componentes
        token_manager = TokenManager(config)
        provider_manager = ProviderManager(config)
        multi_analyzer = MultiProviderAnalyzer(config)
        parser = COBOLParser()
        analyzer = COBOLCodeAnalyzer()
        
        # Carregar lista de programas
        logging.info(f"Carregando programas de: {args.fontes}")
        programs, _ = parser.parse_file(args.fontes)
        logging.info(f"Programas identificados: {len(programs)}")
        
        # Carregar copybooks se especificado
        copybooks = []
        if args.books:
            logging.info(f"Carregando copybooks de: {args.books}")
            _, copybooks = parser.parse_file(args.books)
            logging.info(f"Copybooks identificados: {len(copybooks)}")
        
        # Processar cada programa
        results = {}
        start_time = time.time()
        
        for i, program in enumerate(programs, 1):
            program_name = program.name if hasattr(program, 'name') else f'programa_{i}'
            program_code = program.content if hasattr(program, 'content') else ''
            
            logging.info(f"Analisando programa {i}/{len(programs)}: {program_name}")
            
            try:
                # Pré-análise
                logging.info(f"Iniciando pré-análise de {program_name}")
                analysis_result = analyzer.analyze_program(program_code, program_name)
                comments_obj = getattr(analysis_result, 'comments', None)
                business_comments = getattr(comments_obj, 'business_comments', []) if comments_obj else []
                business_rules = getattr(analysis_result, 'business_rules', [])
                logging.info(f"Pré-análise concluída: {len(business_comments)} comentários, {len(business_rules)} regras")
                
                # Criar contexto multi-provider
                pre_analysis_context = create_multi_provider_context(
                    program_name, business_comments, business_rules, 
                    [cb.name if hasattr(cb, 'name') else '' for cb in copybooks],
                    args
                )
                
                # Análise multi-provider
                mp_result = analyze_with_multi_provider(
                    program_name, program_code, multi_analyzer, config, 
                    pre_analysis_context, args
                )
                
                if mp_result:
                    # Gerar documentação multi-provider
                    doc_success = generate_multi_provider_documentation(
                        program_name, mp_result, business_rules, args.output, args
                    )
                    
                    results[program_name] = {
                        **mp_result,
                        'business_rules_count': len(business_rules),
                        'documentation_generated': doc_success
                    }
                else:
                    results[program_name] = {
                        'success': False,
                        'error': 'Falha na análise multi-provider',
                        'tokens': 0,
                        'providers_used': [],
                        'confidence_score': 0.0
                    }
                    
            except Exception as e:
                logging.error(f"Erro na análise de {program_name}: {e}")
                results[program_name] = {
                    'success': False,
                    'error': str(e),
                    'tokens': 0,
                    'providers_used': [],
                    'confidence_score': 0.0
                }
        
        # Gerar relatório consolidado
        logging.info("Gerando relatório consolidado multi-provider...")
        report_path = generate_multi_provider_report(results, args.output, config, args, multi_analyzer)
        
        # Gerar HTML se solicitado
        if not args.no_pdf and report_path:
            try:
                pdf_converter = MarkdownToPDFConverter()
                html_path = report_path.replace('.md', '.html')
                pdf_converter.convert_to_pdf(report_path, html_path)
                logging.info(f"HTML para impressão gerado: {html_path}")
            except Exception as e:
                logging.warning(f"Erro ao gerar HTML: {e}")
        
        # Estatísticas finais
        end_time = time.time()
        total_time = end_time - start_time
        successful_analyses = sum(1 for r in results.values() if r.get('success', False))
        total_tokens = sum(r.get('tokens', 0) for r in results.values())
        avg_confidence = sum(r.get('confidence_score', 0) for r in results.values()) / max(len(results), 1)
        
        logging.info("=== ANÁLISE MULTI-PROVIDER CONCLUÍDA ===")
        logging.info(f"Programas processados: {len(programs)}")
        logging.info(f"Análises bem-sucedidas: {successful_analyses}/{len(programs)}")
        logging.info(f"Taxa de sucesso: {(successful_analyses/len(programs)*100):.1f}%")
        logging.info(f"Confiança média: {avg_confidence:.2f}/1.0")
        logging.info(f"Total de tokens utilizados: {total_tokens:,}")
        logging.info(f"Tempo de processamento: {total_time:.2f}s")
        logging.info(f"Arquivos gerados em: {args.output}")
        
        # Imprimir estatísticas no console
        print("\n" + "="*70)
        print("=== ANÁLISE MULTI-PROVIDER CONCLUÍDA ===")
        print(f"Programas processados: {len(programs)}")
        print(f"Análises bem-sucedidas: {successful_analyses}/{len(programs)}")
        print(f"Taxa de sucesso: {(successful_analyses/len(programs)*100):.1f}%")
        print(f"Confiança média: {avg_confidence:.2f}/1.0")
        print(f"Total de tokens: {total_tokens:,}")
        print(f"Providers: LuzIA + {'Copilot' if args.enable_copilot else 'Mock'}")
        print(f"Estratégia: {args.combination_strategy}")
        print(f"Tempo: {total_time:.2f}s")
        print(f"Arquivos em: {args.output}")
        print("="*70)
        
        return 0 if successful_analyses > 0 else 1
        
    except KeyboardInterrupt:
        logging.info("Análise interrompida pelo usuário")
        return 1
    except Exception as e:
        logging.error(f"Erro fatal: {e}")
        return 1

if __name__ == "__main__":
    sys.exit(main())
