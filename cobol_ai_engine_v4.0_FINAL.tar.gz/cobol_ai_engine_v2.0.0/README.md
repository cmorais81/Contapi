


# COBOL AI Engine v2.0.0

**Análise e documentação inteligente de código COBOL usando IA**

O COBOL AI Engine é uma ferramenta avançada que utiliza modelos de IA para analisar, compreender e documentar automaticamente programas COBOL legados. A versão 2.0.0 introduz múltiplas interfaces de uso para atender diferentes necessidades e fluxos de trabalho.

## Principais Funcionalidades

- **Múltiplas Interfaces de Uso**: CLI Interativo, API Programática e CLI Clássico
- **Análise Inteligente**: Compreensão profunda da estrutura e funcionalidade do código COBOL
- **Documentação Automática**: Geração de documentação técnica e funcional detalhada
- **Múltiplos Provedores de IA**: Suporte a OpenAI, Databricks, AWS Bedrock e LuzIA
- **Controle de Tokens**: Processamento inteligente de arquivos grandes
- **Geração de PDF**: Conversão automática de documentação para PDF
- **Processamento em Lote**: Análise de múltiplos programas e copybooks

## Novidades da Versão 2.0.0

### 🆕 API Programática para Notebooks
```python
import cobol_ai_engine as cae

# Análise simples
resultado = cae.analyze_cobol(codigo_cobol)

# Análise avançada
analyzer = cae.create_analyzer(provider="openai")
resultados = analyzer.analyze_directory("exemplos/")
```

### 🆕 CLI Interativo
Interface amigável com menu guiado para análise rápida:
```bash
python3 cli_interactive.py
```

### 🆕 Configuração Unificada
Arquivo único de configuração com todas as opções centralizadas.

### 🆕 Exceções Customizadas
Sistema de exceções específicas para diagnóstico preciso de problemas.

### 🆕 Testes Automatizados
Suite completa de testes unitários para garantir qualidade.

## Formas de Uso

### 1. CLI Interativo (Recomendado para iniciantes)
```bash
python3 cli_interactive.py
```
Interface guiada por menu com opções para análise de código, arquivos e diretórios.

### 2. API Programática (Para notebooks e scripts)
```python
import cobol_ai_engine as cae

# Guia rápido
cae.quick_start_guide()

# Análise de código
resultado = cae.analyze_cobol("IDENTIFICATION DIVISION...")

# Análise de arquivo
resultado = cae.analyze_cobol_file("programa.cbl")
```

### 3. CLI Clássico (Para automação)
```bash
# Análise de arquivo único
python3 main.py --fontes programa.cbl --output resultado

# Análise em lote com PDF
python3 main.py --fontes fontes.txt --output resultado --pdf --consolidado
```

## Instalação e Configuração

### Pré-requisitos
- Python 3.8+
- Dependências listadas em `requirements.txt`

### Instalação
```bash
# Instalar dependências
pip install -r requirements.txt

# Configurar variáveis de ambiente (opcional)
export OPENAI_API_KEY="sua_chave_aqui"
```

### Configuração
O sistema usa o arquivo `config/config_unified.yaml` por padrão. Você pode:
- Editar o arquivo de configuração diretamente
- Usar um arquivo de configuração personalizado com `--config`
- Configurar variáveis de ambiente para credenciais

## Exemplos de Uso

### Análise Rápida em Notebook
```python
import cobol_ai_engine as cae

# Criar analisador
analyzer = cae.create_analyzer()

# Analisar diretório
resultados = analyzer.analyze_directory("exemplos/")

# Gerar relatório
analyzer.generate_report(resultados, "relatorio.pdf", format="pdf")
```

### Processamento em Lote
```bash
# Analisar todos os programas em fontes.txt
python3 main.py --fontes examples/fontes.txt --output analise_completa --consolidado --pdf

# Verificar status do sistema
python3 main.py --status
```

## Documentação

- **[Documentação da API](docs/API_DOCUMENTATION.md)**: Guia completo da API programática
- **[Documentação do CLI](docs/CLI_DOCUMENTATION.md)**: Referência das interfaces de linha de comando
- **[Exemplos Práticos](docs/EXAMPLES_DOCUMENTATION.md)**: Exemplos de uso em diferentes cenários
- **[Exemplos para Notebooks](examples/notebook_examples.py)**: Código pronto para usar em notebooks

## Estrutura do Projeto

```
cobol_ai_engine_v2.0.0/
├── main.py                    # CLI clássico
├── cli_interactive.py         # CLI interativo
├── cobol_ai_engine.py        # Módulo principal para importação
├── config/
│   └── config_unified.yaml   # Configuração unificada
├── src/
│   ├── api/                  # API programática
│   ├── core/                 # Componentes centrais
│   ├── providers/            # Provedores de IA
│   ├── parsers/              # Analisadores de código
│   ├── generators/           # Geradores de documentação
│   └── utils/                # Utilitários
├── examples/
│   ├── notebook_examples.py  # Exemplos para notebooks
│   ├── fontes.txt            # Lista de programas exemplo
│   └── BOOKS.txt             # Lista de copybooks exemplo
├── docs/                     # Documentação completa
└── tests/                    # Testes unitários
```

## Provedores de IA Suportados

- **OpenAI**: GPT-4 e modelos relacionados
- **Databricks**: Modelos Llama hospedados
- **AWS Bedrock**: Claude e outros modelos
- **LuzIA**: Modelos customizados
- **Enhanced Mock**: Provedor de teste com respostas realistas

## Contribuição

Para contribuir com o projeto:

1. Faça um fork do repositório
2. Crie uma branch para sua feature
3. Execute os testes: `python3 run_tests.py`
4. Faça commit das suas mudanças
5. Abra um Pull Request

## Licença

Este projeto está licenciado sob a licença MIT. Veja o arquivo LICENSE para detalhes.

## Suporte

Para suporte e dúvidas:
- Consulte a documentação em `docs/`
- Execute `python3 cli_interactive.py` e escolha a opção "Ajuda e exemplos"
- Verifique os exemplos em `examples/notebook_examples.py`

---

**COBOL AI Engine v2.0.0** - Transformando a análise de código COBOL com inteligência artificial.


