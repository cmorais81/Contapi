#!/usr/bin/env python3.11
"""
Teste simples para identificar problema na configuração
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.core.config import ConfigManager

try:
    print("Testando ConfigManager...")
    config_manager = ConfigManager("config/config_unified.yaml")
    print("ConfigManager criado com sucesso!")
    
    config = config_manager.get_config()
    print(f"Configuração carregada: {type(config)}")
    
    print("Teste concluído com sucesso!")
    
except Exception as e:
    print(f"Erro no teste: {e}")
    import traceback
    traceback.print_exc()
