#!/usr/bin/env python3
"""
COBOL AI Engine v4.0 Complete
Sistema completo com todas as 4 melhorias críticas implementadas
"""

import os
import sys
import logging
import argparse
from typing import Dict, List, Any, Optional
from pathlib import Path

# Imports dos novos componentes
from src.parsers.record_layout_parser import RecordLayoutParser
from src.parsers.cobol_structure_analyzer import COBOLStructureAnalyzer
from src.analyzers.decision_logic_extractor import DecisionLogicExtractor
from src.generators.functional_code_generator import FunctionalCodeGenerator

# Imports dos componentes existentes
from src.parsers.advanced_cobol_parser import AdvancedCOBOLParser
from src.analyzers.functional_analyzer import FunctionalAnalyzer
from src.analyzers.hybrid_analyzer import HybridAnalyzer
from src.generators.assertive_documentation_generator import AssertiveDocumentationGenerator
from src.providers.provider_manager import ProviderManager
from src.core.config import ConfigManager
from src.core.token_manager import TokenManager
from src.utils.pdf_converter import MarkdownToPDFConverter

class COBOLAnalysisEngineV4:
    """
    Engine completo de análise COBOL v4.0
    Implementa todas as 4 melhorias críticas para documentação 100% completa
    """
    
    def __init__(self, config_path: str):
        """
        Inicializa o engine v4.0
        
        Args:
            config_path: Caminho para arquivo de configuração
        """
        self.logger = self._setup_logging()
        self.logger.info("Inicializando COBOL AI Engine v4.0")
        
        # Carregar configuração
        self.config = ConfigManager(config_path)
        
        # Inicializar componentes principais
        self.token_manager = TokenManager(self.config.get_config())
        self.provider_manager = ProviderManager(self.config.get_config())
        
        # Inicializar novos componentes v4.0
        self.record_layout_parser = RecordLayoutParser()
        self.structure_analyzer = COBOLStructureAnalyzer()
        self.decision_extractor = DecisionLogicExtractor()
        self.code_generator = FunctionalCodeGenerator()
        
        # Componentes existentes
        self.cobol_parser = AdvancedCOBOLParser()
        self.functional_analyzer = FunctionalAnalyzer()
        self.hybrid_analyzer = HybridAnalyzer()
        self.doc_generator = AssertiveDocumentationGenerator(self.config.get_config())
        self.pdf_converter = MarkdownToPDFConverter()
        
        self.logger.info("Engine v4.0 inicializado com sucesso")
    
    def _setup_logging(self) -> logging.Logger:
        """Configura sistema de logging"""
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.StreamHandler(),
                logging.FileHandler('cobol_engine_v4.log')
            ]
        )
        return logging.getLogger(__name__)
    
    def analyze_cobol_program(self, 
                            cobol_files: List[str], 
                            copybook_files: List[str] = None,
                            target_language: str = 'java',
                            generate_code: bool = True) -> Dict[str, Any]:
        """
        Análise completa de programa COBOL com todas as melhorias v4.0
        
        Args:
            cobol_files: Lista de arquivos COBOL
            copybook_files: Lista de copybooks (opcional)
            target_language: Linguagem alvo para geração de código
            generate_code: Se deve gerar código funcional
            
        Returns:
            Análise completa com todas as informações
        """
        self.logger.info(f"Iniciando análise completa v4.0 de {len(cobol_files)} arquivos")
        
        analysis_results = {}
        
        for cobol_file in cobol_files:
            self.logger.info(f"Analisando arquivo: {cobol_file}")
            
            # Ler código COBOL
            with open(cobol_file, 'r', encoding='utf-8', errors='ignore') as f:
                cobol_code = f.read()
            
            program_name = Path(cobol_file).stem
            
            # 1. MELHORIA CRÍTICA: Parser de Layout de Registros Detalhado
            self.logger.info("Executando análise de layouts de registros...")
            record_layouts = self.record_layout_parser.parse_record_layouts(cobol_code)
            
            # 2. MELHORIA CRÍTICA: Analisador de Estrutura COBOL Real
            self.logger.info("Executando análise de estrutura hierárquica...")
            cobol_structure = self.structure_analyzer.analyze_structure(cobol_code)
            
            # 3. Análise funcional existente (melhorada)
            self.logger.info("Executando análise funcional...")
            # Parse código primeiro - criar arquivo temporário
            import tempfile
            with tempfile.NamedTemporaryFile(mode='w', suffix='.cbl', delete=False) as temp_file:
                temp_file.write(cobol_code)
                temp_file_path = temp_file.name
            
            try:
                parsed_data = self.cobol_parser.parse_file(temp_file_path)
                functional_analysis = self.functional_analyzer.analyze_functionality(parsed_data)
            finally:
                os.unlink(temp_file_path)
            
            # 4. MELHORIA CRÍTICA: Extrator de Lógica de Decisão Específica
            self.logger.info("Executando extração de lógica de decisão...")
            file_info = {
                'input_files': functional_analysis.get('input_files', []),
                'output_files': functional_analysis.get('output_files', [])
            }
            decision_logic = self.decision_extractor.extract_decision_logic(cobol_code, file_info)
            
            # 5. Análise híbrida com LLM (quando disponível)
            self.logger.info("Executando análise híbrida...")
            try:
                llm_analysis = self._analyze_with_llm(cobol_code, {
                    'record_layouts': record_layouts,
                    'structure': cobol_structure,
                    'functional': functional_analysis,
                    'decision_logic': decision_logic
                })
            except Exception as e:
                self.logger.warning(f"Análise LLM falhou: {e}")
                llm_analysis = None
            
            # Combinar análises
            hybrid_analysis = self.hybrid_analyzer.combine_analyses(
                internal_analysis={
                    'record_layouts': record_layouts,
                    'structure': cobol_structure,
                    'functional': functional_analysis,
                    'decision_logic': decision_logic
                },
                llm_analysis=llm_analysis
            )
            
            # 6. MELHORIA CRÍTICA: Gerador de Código Funcional
            generated_code = {}
            if generate_code:
                self.logger.info(f"Gerando código funcional em {target_language}...")
                try:
                    code_data = {
                        'record_layouts': {name: [field.to_dict() for field in fields] 
                                         for name, fields in record_layouts.items()},
                        'validation_conditions': [cond.to_dict() for cond in decision_logic.validation_conditions],
                        'routing_rules': [rule.to_dict() for rule in decision_logic.routing_rules],
                        'program_info': {
                            'program_name': program_name,
                            'structure': cobol_structure.to_dict()
                        }
                    }
                    
                    generated_code = self.code_generator.generate_complete_code(
                        code_data, target_language
                    )
                except Exception as e:
                    self.logger.error(f"Erro na geração de código: {e}")
                    generated_code = {}
            
            # Compilar resultado final
            analysis_results[program_name] = {
                'program_name': program_name,
                'source_file': cobol_file,
                'record_layouts': record_layouts,
                'structure_analysis': cobol_structure,
                'functional_analysis': functional_analysis,
                'decision_logic': decision_logic,
                'hybrid_analysis': hybrid_analysis,
                'generated_code': generated_code,
                'analysis_metadata': {
                    'version': '4.0',
                    'timestamp': self._get_timestamp(),
                    'target_language': target_language,
                    'completeness_score': self._calculate_completeness_score({
                        'layouts': len(record_layouts),
                        'structure': len(cobol_structure.divisions),
                        'decisions': decision_logic.complexity_score,
                        'code_generated': len(generated_code)
                    })
                }
            }
            
            self.logger.info(f"Análise completa de {program_name}: "
                           f"{len(record_layouts)} layouts, "
                           f"{cobol_structure.complexity_metrics['total_paragraphs']} parágrafos, "
                           f"{len(decision_logic.routing_rules)} regras de roteamento")
        
        return analysis_results
    
    def generate_complete_documentation(self, 
                                      analysis_results: Dict[str, Any],
                                      output_dir: str,
                                      include_pdf: bool = True) -> Dict[str, str]:
        """
        Gera documentação completa v4.0 com todas as melhorias
        
        Args:
            analysis_results: Resultados da análise completa
            output_dir: Diretório de saída
            include_pdf: Se deve gerar versão PDF
            
        Returns:
            Dict com caminhos dos arquivos gerados
        """
        self.logger.info("Gerando documentação completa v4.0")
        
        os.makedirs(output_dir, exist_ok=True)
        generated_files = {}
        
        for program_name, analysis in analysis_results.items():
            self.logger.info(f"Gerando documentação para {program_name}")
            
            # Gerar documentação principal
            doc_content = self._generate_enhanced_documentation(analysis)
            
            # Salvar documentação markdown
            doc_file = os.path.join(output_dir, f"{program_name}_COMPLETE_v4.0.md")
            with open(doc_file, 'w', encoding='utf-8') as f:
                f.write(doc_content)
            generated_files[f"{program_name}_documentation"] = doc_file
            
            # Gerar código funcional se disponível
            if analysis.get('generated_code'):
                code_dir = os.path.join(output_dir, f"{program_name}_code")
                code_files = self.code_generator.save_generated_code(
                    analysis['generated_code'],
                    code_dir,
                    analysis['analysis_metadata']['target_language']
                )
                generated_files[f"{program_name}_code"] = code_files
            
            # Gerar PDF se solicitado
            if include_pdf:
                try:
                    pdf_file = os.path.join(output_dir, f"{program_name}_COMPLETE_v4.0.pdf")
                    self.pdf_converter.convert_to_pdf(doc_file, pdf_file)
                    generated_files[f"{program_name}_pdf"] = pdf_file
                except Exception as e:
                    self.logger.warning(f"Erro ao gerar PDF: {e}")
        
        # Gerar relatório consolidado
        consolidated_report = self._generate_consolidated_report(analysis_results)
        consolidated_file = os.path.join(output_dir, "RELATORIO_CONSOLIDADO_v4.0.md")
        with open(consolidated_file, 'w', encoding='utf-8') as f:
            f.write(consolidated_report)
        generated_files["consolidated_report"] = consolidated_file
        
        self.logger.info(f"Documentação v4.0 gerada: {len(generated_files)} arquivos")
        return generated_files
    
    def _analyze_with_llm(self, cobol_code: str, context: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Executa análise com LLM usando contexto completo"""
        try:
            # Preparar contexto enriquecido
            enhanced_context = self._prepare_enhanced_context(cobol_code, context)
            
            # Executar análise
            provider = self.provider_manager.get_primary_provider()
            if provider:
                response = provider.analyze(enhanced_context)
                if response and response.success:
                    return response.content
            
            return None
            
        except Exception as e:
            self.logger.error(f"Erro na análise LLM: {e}")
            return None
    
    def _prepare_enhanced_context(self, cobol_code: str, context: Dict[str, Any]) -> str:
        """Prepara contexto enriquecido para análise LLM"""
        context_parts = [
            "=== CÓDIGO COBOL ===",
            cobol_code[:5000],  # Primeiros 5000 caracteres
            "",
            "=== LAYOUTS DE REGISTROS ===",
            self._format_layouts_for_llm(context.get('record_layouts', {})),
            "",
            "=== ESTRUTURA HIERÁRQUICA ===",
            self._format_structure_for_llm(context.get('structure')),
            "",
            "=== LÓGICA DE DECISÃO ===",
            self._format_decision_logic_for_llm(context.get('decision_logic')),
            "",
            "=== ANÁLISE FUNCIONAL ===",
            self._format_functional_for_llm(context.get('functional'))
        ]
        
        return "\\n".join(context_parts)
    
    def _format_layouts_for_llm(self, layouts: Dict[str, Any]) -> str:
        """Formata layouts para contexto LLM"""
        if not layouts:
            return "Nenhum layout identificado"
        
        formatted = []
        for record_name, fields in layouts.items():
            formatted.append(f"Registro {record_name}:")
            for field in fields:
                formatted.append(f"  - {field.name}: {field.data_type} ({field.length} bytes)")
        
        return "\\n".join(formatted)
    
    def _format_structure_for_llm(self, structure) -> str:
        """Formata estrutura para contexto LLM"""
        if not structure:
            return "Estrutura não analisada"
        
        return f"Programa: {structure.program_name}, " \
               f"Divisões: {len(structure.divisions)}, " \
               f"Complexidade: {structure.complexity_metrics.get('cyclomatic_complexity', 0)}"
    
    def _format_decision_logic_for_llm(self, decision_logic) -> str:
        """Formata lógica de decisão para contexto LLM"""
        if not decision_logic:
            return "Lógica de decisão não analisada"
        
        return f"Regras de roteamento: {len(decision_logic.routing_rules)}, " \
               f"Validações: {len(decision_logic.validation_conditions)}, " \
               f"Complexidade: {decision_logic.complexity_score}"
    
    def _format_functional_for_llm(self, functional) -> str:
        """Formata análise funcional para contexto LLM"""
        if not functional:
            return "Análise funcional não disponível"
        
        return f"Arquivos entrada: {len(functional.input_files)}, " \
               f"Arquivos saída: {len(functional.output_files)}, " \
               f"Regras negócio: {len(functional.business_rules)}"
    
    def _generate_enhanced_documentation(self, analysis: Dict[str, Any]) -> str:
        """Gera documentação aprimorada v4.0"""
        program_name = analysis['program_name']
        
        doc = f"# Documentação Completa v4.0: {program_name}\\n\\n"
        doc += f"**Gerado em:** {analysis['analysis_metadata']['timestamp']}\\n"
        doc += f"**Versão do Engine:** {analysis['analysis_metadata']['version']}\\n"
        doc += f"**Score de Completude:** {analysis['analysis_metadata']['completeness_score']}/100\\n\\n"
        
        # 1. Resumo Executivo
        doc += "## 1. Resumo Executivo\\n\\n"
        doc += self._generate_executive_summary(analysis)
        
        # 2. Layouts de Registros Detalhados (MELHORIA 1)
        doc += "## 2. Layouts de Registros Detalhados\\n\\n"
        if analysis['record_layouts']:
            doc += self.record_layout_parser.generate_layout_documentation(
                analysis['record_layouts']
            )
        else:
            doc += "*Nenhum layout de registro identificado*\\n\\n"
        
        # 3. Estrutura Hierárquica Real (MELHORIA 2)
        doc += "## 3. Estrutura Hierárquica do Programa\\n\\n"
        if analysis['structure_analysis']:
            doc += self.structure_analyzer.generate_structure_documentation(
                analysis['structure_analysis']
            )
        else:
            doc += "*Estrutura não analisada*\\n\\n"
        
        # 4. Lógica de Decisão Específica (MELHORIA 3)
        doc += "## 4. Lógica de Decisão e Roteamento\\n\\n"
        if analysis['decision_logic']:
            doc += self.decision_extractor.generate_decision_documentation(
                analysis['decision_logic']
            )
        else:
            doc += "*Lógica de decisão não identificada*\\n\\n"
        
        # 5. Análise Funcional
        doc += "## 5. Análise Funcional\\n\\n"
        doc += self._generate_functional_documentation(analysis['functional_analysis'])
        
        # 6. Código Funcional Gerado (MELHORIA 4)
        doc += "## 6. Código Funcional Gerado\\n\\n"
        if analysis['generated_code']:
            doc += self._generate_code_documentation(
                analysis['generated_code'],
                analysis['analysis_metadata']['target_language']
            )
        else:
            doc += "*Código não gerado*\\n\\n"
        
        # 7. Análise Híbrida
        doc += "## 7. Insights da Análise Híbrida\\n\\n"
        if analysis['hybrid_analysis']:
            doc += self._generate_hybrid_documentation(analysis['hybrid_analysis'])
        else:
            doc += "*Análise híbrida não disponível*\\n\\n"
        
        # 8. Guia de Reimplementação
        doc += "## 8. Guia de Reimplementação\\n\\n"
        doc += self._generate_reimplementation_guide(analysis)
        
        return doc
    
    def _generate_executive_summary(self, analysis: Dict[str, Any]) -> str:
        """Gera resumo executivo"""
        summary = f"O programa **{analysis['program_name']}** foi analisado completamente "
        summary += "usando o COBOL AI Engine v4.0 com todas as melhorias críticas implementadas.\\n\\n"
        
        # Estatísticas
        layouts_count = len(analysis.get('record_layouts', {}))
        structure = analysis.get('structure_analysis')
        decision_logic = analysis.get('decision_logic')
        
        summary += "**Estatísticas da Análise:**\\n"
        summary += f"- Layouts de registros identificados: {layouts_count}\\n"
        
        if structure:
            summary += f"- Divisões COBOL: {len(structure.divisions)}\\n"
            summary += f"- Seções: {structure.complexity_metrics.get('total_sections', 0)}\\n"
            summary += f"- Parágrafos: {structure.complexity_metrics.get('total_paragraphs', 0)}\\n"
        
        if decision_logic:
            summary += f"- Regras de roteamento: {len(decision_logic.routing_rules)}\\n"
            summary += f"- Validações identificadas: {len(decision_logic.validation_conditions)}\\n"
            summary += f"- Score de complexidade: {decision_logic.complexity_score}\\n"
        
        summary += "\\n"
        
        # Propósito identificado
        functional = analysis.get('functional_analysis')
        if functional and hasattr(functional, 'purpose'):
            summary += f"**Propósito do Programa:** {functional.purpose}\\n\\n"
        
        return summary
    
    def _generate_functional_documentation(self, functional_analysis) -> str:
        """Gera documentação da análise funcional"""
        if not functional_analysis:
            return "*Análise funcional não disponível*\\n\\n"
        
        doc = f"**Propósito:** {getattr(functional_analysis, 'purpose', 'Não identificado')}\\n\\n"
        
        # Arquivos
        doc += "**Arquivos de Entrada:**\\n"
        for file in getattr(functional_analysis, 'input_files', []):
            doc += f"- {file}\\n"
        doc += "\\n"
        
        doc += "**Arquivos de Saída:**\\n"
        for file in getattr(functional_analysis, 'output_files', []):
            doc += f"- {file}\\n"
        doc += "\\n"
        
        # Regras de negócio
        business_rules = getattr(functional_analysis, 'business_rules', [])
        if business_rules:
            doc += "**Regras de Negócio:**\\n"
            for i, rule in enumerate(business_rules[:10], 1):  # Primeiras 10
                rule_text = getattr(rule, 'description', str(rule))
                doc += f"{i}. {rule_text}\\n"
            doc += "\\n"
        
        return doc
    
    def _generate_code_documentation(self, generated_code: Dict[str, str], language: str) -> str:
        """Gera documentação do código gerado"""
        doc = f"Código funcional gerado em **{language.upper()}** com {len(generated_code)} arquivos:\\n\\n"
        
        for file_type, code_content in generated_code.items():
            doc += f"### {file_type.replace('_', ' ').title()}\\n\\n"
            doc += f"```{language}\\n"
            doc += code_content[:1000]  # Primeiros 1000 caracteres
            if len(code_content) > 1000:
                doc += "\\n... (código truncado)\\n"
            doc += "```\\n\\n"
        
        return doc
    
    def _generate_hybrid_documentation(self, hybrid_analysis) -> str:
        """Gera documentação da análise híbrida"""
        if not hybrid_analysis:
            return "*Análise híbrida não disponível*\\n\\n"
        
        confidence = getattr(hybrid_analysis, 'confidence_score', 0)
        doc = f"**Score de Confiança:** {confidence:.2f}\\n\\n"
        
        insights = getattr(hybrid_analysis, 'combined_insights', [])
        if insights:
            doc += "**Insights Combinados:**\\n"
            for insight in insights[:5]:  # Primeiros 5
                doc += f"- {insight}\\n"
            doc += "\\n"
        
        return doc
    
    def _generate_reimplementation_guide(self, analysis: Dict[str, Any]) -> str:
        """Gera guia de reimplementação"""
        language = analysis['analysis_metadata']['target_language']
        
        guide = f"### Reimplementação em {language.upper()}\\n\\n"
        guide += "**Passos Recomendados:**\\n\\n"
        
        guide += "1. **Implementar Estruturas de Dados**\\n"
        guide += "   - Use o código gerado na seção 6 como base\\n"
        guide += "   - Adapte os tipos de dados conforme necessário\\n\\n"
        
        guide += "2. **Implementar Validações**\\n"
        guide += "   - Implemente as regras de validação identificadas\\n"
        guide += "   - Use o código de validação gerado como referência\\n\\n"
        
        guide += "3. **Implementar Lógica de Roteamento**\\n"
        guide += "   - Use as regras de decisão documentadas na seção 4\\n"
        guide += "   - Implemente o roteamento conforme código gerado\\n\\n"
        
        guide += "4. **Testar e Validar**\\n"
        guide += "   - Compare resultados com o sistema COBOL original\\n"
        guide += "   - Valide todos os cenários de teste\\n\\n"
        
        # Considerações específicas
        decision_logic = analysis.get('decision_logic')
        if decision_logic and decision_logic.routing_rules:
            guide += "**Considerações Específicas:**\\n"
            for rule in decision_logic.routing_rules:
                guide += f"- {rule.description}\\n"
            guide += "\\n"
        
        return guide
    
    def _generate_consolidated_report(self, analysis_results: Dict[str, Any]) -> str:
        """Gera relatório consolidado"""
        report = "# Relatório Consolidado - COBOL AI Engine v4.0\\n\\n"
        report += f"**Programas Analisados:** {len(analysis_results)}\\n"
        report += f"**Data da Análise:** {self._get_timestamp()}\\n\\n"
        
        # Resumo por programa
        report += "## Resumo por Programa\\n\\n"
        report += "| Programa | Layouts | Divisões | Parágrafos | Regras Roteamento | Score Completude |\\n"
        report += "|----------|---------|----------|------------|-------------------|------------------|\\n"
        
        for program_name, analysis in analysis_results.items():
            layouts_count = len(analysis.get('record_layouts', {}))
            structure = analysis.get('structure_analysis')
            divisions_count = len(structure.divisions) if structure else 0
            paragraphs_count = structure.complexity_metrics.get('total_paragraphs', 0) if structure else 0
            
            decision_logic = analysis.get('decision_logic')
            routing_rules_count = len(decision_logic.routing_rules) if decision_logic else 0
            
            completeness = analysis['analysis_metadata']['completeness_score']
            
            report += f"| {program_name} | {layouts_count} | {divisions_count} | {paragraphs_count} | {routing_rules_count} | {completeness}/100 |\\n"
        
        report += "\\n"
        
        # Estatísticas gerais
        total_layouts = sum(len(a.get('record_layouts', {})) for a in analysis_results.values())
        total_rules = sum(len(a.get('decision_logic', {}).get('routing_rules', [])) for a in analysis_results.values())
        avg_completeness = sum(a['analysis_metadata']['completeness_score'] for a in analysis_results.values()) / len(analysis_results)
        
        report += "## Estatísticas Gerais\\n\\n"
        report += f"- **Total de Layouts:** {total_layouts}\\n"
        report += f"- **Total de Regras de Roteamento:** {total_rules}\\n"
        report += f"- **Score Médio de Completude:** {avg_completeness:.1f}/100\\n\\n"
        
        return report
    
    def _calculate_completeness_score(self, metrics: Dict[str, int]) -> int:
        """Calcula score de completude da análise"""
        score = 0
        
        # Layouts de registros (25 pontos)
        if metrics['layouts'] > 0:
            score += min(25, metrics['layouts'] * 5)
        
        # Estrutura hierárquica (25 pontos)
        if metrics['structure'] > 0:
            score += min(25, metrics['structure'] * 6)
        
        # Lógica de decisão (25 pontos)
        if metrics['decisions'] > 0:
            score += min(25, metrics['decisions'] * 2)
        
        # Código gerado (25 pontos)
        if metrics['code_generated'] > 0:
            score += min(25, metrics['code_generated'] * 6)
        
        return min(100, score)
    
    def _get_timestamp(self) -> str:
        """Retorna timestamp atual"""
        from datetime import datetime
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def main():
    """Função principal do programa"""
    parser = argparse.ArgumentParser(
        description="COBOL AI Engine v4.0 - Análise Completa de Programas COBOL"
    )
    
    parser.add_argument(
        '--fontes',
        required=True,
        help='Arquivo com lista de programas COBOL para análise'
    )
    
    parser.add_argument(
        '--books',
        help='Arquivo com lista de copybooks (opcional)'
    )
    
    parser.add_argument(
        '--config',
        default='config/config_unified.yaml',
        help='Arquivo de configuração (padrão: config/config_unified.yaml)'
    )
    
    parser.add_argument(
        '--output',
        default='output_v4',
        help='Diretório de saída (padrão: output_v4)'
    )
    
    parser.add_argument(
        '--target-language',
        choices=['java', 'python'],
        default='java',
        help='Linguagem alvo para geração de código (padrão: java)'
    )
    
    parser.add_argument(
        '--no-code',
        action='store_true',
        help='Não gerar código funcional'
    )
    
    parser.add_argument(
        '--no-pdf',
        action='store_true',
        help='Não gerar versão PDF'
    )
    
    args = parser.parse_args()
    
    try:
        # Inicializar engine
        engine = COBOLAnalysisEngineV4(args.config)
        
        # Ler lista de arquivos
        with open(args.fontes, 'r') as f:
            cobol_files = [line.strip() for line in f if line.strip() and not line.strip().startswith('#')]
        
        copybook_files = []
        if args.books:
            with open(args.books, 'r') as f:
                copybook_files = [line.strip() for line in f if line.strip()]
        
        # Executar análise completa
        print(f"Iniciando análise v4.0 de {len(cobol_files)} programas...")
        analysis_results = engine.analyze_cobol_program(
            cobol_files=cobol_files,
            copybook_files=copybook_files,
            target_language=args.target_language,
            generate_code=not args.no_code
        )
        
        # Gerar documentação
        print("Gerando documentação completa...")
        generated_files = engine.generate_complete_documentation(
            analysis_results=analysis_results,
            output_dir=args.output,
            include_pdf=not args.no_pdf
        )
        
        # Resumo final
        print("\\n=== ANÁLISE COMPLETA v4.0 ===")
        print(f"Programas analisados: {len(analysis_results)}")
        print(f"Arquivos gerados: {len(generated_files)}")
        print(f"Diretório de saída: {args.output}")
        
        # Score médio de completude
        avg_score = sum(
            a['analysis_metadata']['completeness_score'] 
            for a in analysis_results.values()
        ) / len(analysis_results)
        print(f"Score médio de completude: {avg_score:.1f}/100")
        
        print("\\nAnálise concluída com sucesso!")
        
    except Exception as e:
        print(f"Erro durante a análise: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()
