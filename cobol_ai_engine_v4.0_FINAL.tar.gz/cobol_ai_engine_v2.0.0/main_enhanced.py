#!/usr/bin/env python3
"""
COBOL AI Engine v2.2.0 Enhanced - Script Principal Aprimorado
Sistema de análise inteligente de código COBOL com foco em análises descritivas e aprofundadas.

Melhorias desta versão:
- Integração otimizada com LuzIA Claude 3.5 Sonnet
- Prompts aprimorados para análises descritivas
- Templates de documentação aprimorados
- Configurações específicas para análises detalhadas
- Geração de relatórios extremamente descritivos
"""

import argparse
import logging
import os
import sys
import time
from datetime import datetime
from typing import Dict, List, Any, Optional

# Adicionar src ao path
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

from src.core.config import ConfigManager
from src.core.prompt_manager import PromptManager
from src.core.token_manager import TokenManager
from src.core.exceptions import COBOLAIEngineException
from src.providers.provider_manager import ProviderManager
from src.parsers.cobol_parser import COBOLParser
from src.analyzers.cobol_code_analyzer import COBOLCodeAnalyzer
from src.generators.enhanced_documentation_generator import EnhancedDocumentationGenerator
from src.utils.pdf_converter import MarkdownToPDFConverter


class EnhancedCOBOLAnalysisEngine:
    """
    Engine principal aprimorado para análise de código COBOL com foco em análises descritivas.
    """
    
    def __init__(self, config_file: str = "config/config_luzia_enhanced.yaml", 
                 prompts_file: str = "config/prompts_enhanced.yaml"):
        """
        Inicializa o engine aprimorado.
        
        Args:
            config_file: Arquivo de configuração aprimorada
            prompts_file: Arquivo de prompts aprimorados
        """
        self.logger = self._setup_logging()
        self.logger.info("=== COBOL AI Engine v2.2.0 Enhanced - Iniciando ===")
        
        try:
            # Carregar configurações aprimoradas
            self.config_manager = ConfigManager(config_file)
            self.config = self.config_manager.config
            
            # Carregar prompts aprimorados
            self.prompt_manager = PromptManager(prompts_file)
            
            # Inicializar componentes aprimorados
            self.provider_manager = ProviderManager(self.config)
            self.parser = COBOLParser()
            self.analyzer = COBOLCodeAnalyzer()
            # Obter max_tokens da configuração
            max_tokens = self.config.get('ai', {}).get('global_max_tokens', 8000)
            self.token_manager = TokenManager(max_tokens)
            
            # Configurações específicas para análises descritivas
            self.enhanced_config = self.config.get('luzia_optimizations', {})
            self.detailed_analysis = self.enhanced_config.get('detailed_analysis_mode', True)
            self.business_context = self.enhanced_config.get('business_context_emphasis', True)
            self.technical_depth = self.enhanced_config.get('technical_depth', 'maximum')
            
            self.logger.info(f"Engine aprimorado inicializado com sucesso")
            self.logger.info(f"Configurações: detailed_analysis={self.detailed_analysis}, "
                           f"business_context={self.business_context}, technical_depth={self.technical_depth}")
            
        except Exception as e:
            self.logger.error(f"Erro ao inicializar engine aprimorado: {str(e)}")
            raise COBOLAIEngineException(f"Falha na inicialização: {str(e)}")
    
    def _setup_logging(self) -> logging.Logger:
        """Configura logging aprimorado."""
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler('logs/enhanced_analysis.log'),
                logging.StreamHandler()
            ]
        )
        return logging.getLogger(__name__)
    
    def analyze_programs_enhanced(self, 
                                fontes_file: str, 
                                books_file: Optional[str] = None,
                                output_dir: str = "output_enhanced") -> Dict[str, Any]:
        """
        Realiza análise aprimorada e descritiva de programas COBOL.
        
        Args:
            fontes_file: Arquivo com programas COBOL
            books_file: Arquivo com copybooks (opcional)
            output_dir: Diretório de saída
            
        Returns:
            Resultados da análise aprimorada
        """
        start_time = time.time()
        self.logger.info("=== INICIANDO ANÁLISE APRIMORADA ===")
        
        try:
            # Criar diretório de saída
            os.makedirs(output_dir, exist_ok=True)
            
            # Inicializar gerador de documentação aprimorado
            doc_generator = EnhancedDocumentationGenerator(
                output_dir=output_dir,
                config={
                    'detailed_analysis': self.detailed_analysis,
                    'business_focus': self.business_context,
                    'technical_depth': self.technical_depth,
                    'include_recommendations': True
                }
            )
            
            # Parsear programas
            self.logger.info(f"Parseando programas de: {fontes_file}")
            programs, _ = self.parser.parse_file(fontes_file)
            self.logger.info(f"Programas identificados: {len(programs)}")
            
            # Parsear copybooks se fornecido
            copybooks = []
            if books_file and os.path.exists(books_file):
                self.logger.info(f"Parseando copybooks de: {books_file}")
                _, copybooks = self.parser.parse_file(books_file)
                self.logger.info(f"Copybooks identificados: {len(copybooks)}")
            
            # Resultados da análise
            results = {
                'programs_analyzed': 0,
                'programs_successful': 0,
                'programs_failed': 0,
                'copybooks_analyzed': len(copybooks),
                'total_tokens_used': 0,
                'analysis_details': [],
                'enhanced_features_used': {
                    'detailed_analysis': self.detailed_analysis,
                    'business_context': self.business_context,
                    'technical_depth': self.technical_depth
                }
            }
            
            # Analisar cada programa com análise aprimorada
            for i, program in enumerate(programs, 1):
                self.logger.info(f"Analisando programa {i}/{len(programs)}: {program.name}")
                
                try:
                    # Pré-análise estrutural aprimorada
                    pre_analysis = self.analyzer.analyze_program(program.content, program.name)
                    self.logger.info(f"Pré-análise concluída: {len(pre_analysis.comments.business_comments)} comentários de negócio, "
                                   f"{len(pre_analysis.business_rules)} regras identificadas")
                    
                    # Preparar prompt aprimorado
                    enhanced_prompt = self._prepare_enhanced_prompt(program, pre_analysis)
                    
                    # Análise com IA usando prompts aprimorados
                    ai_response = self._analyze_with_enhanced_ai(enhanced_prompt, program.name)
                    
                    if ai_response:
                        # Gerar documentação aprimorada
                        doc_path = doc_generator.generate_enhanced_program_documentation(
                            program, ai_response, pre_analysis.__dict__
                        )
                        
                        results['programs_successful'] += 1
                        results['total_tokens_used'] += getattr(ai_response, 'tokens_used', 0)
                        
                        # Detalhes da análise
                        analysis_detail = {
                            'program_name': program.name,
                            'status': 'success',
                            'tokens_used': getattr(ai_response, 'tokens_used', 0),
                            'analysis_depth_score': self._calculate_analysis_depth_score(ai_response, pre_analysis),
                            'business_rules_found': len(pre_analysis.business_rules),
                            'documentation_path': doc_path,
                            'enhanced_features': {
                                'detailed_prompts': True,
                                'business_context_analysis': self.business_context,
                                'technical_depth_analysis': self.technical_depth
                            }
                        }
                        results['analysis_details'].append(analysis_detail)
                        
                        self.logger.info(f"Análise aprimorada bem-sucedida: {program.name} "
                                       f"({getattr(ai_response, 'tokens_used', 0)} tokens)")
                    else:
                        results['programs_failed'] += 1
                        self.logger.warning(f"Falha na análise aprimorada: {program.name}")
                        
                except Exception as e:
                    results['programs_failed'] += 1
                    self.logger.error(f"Erro na análise aprimorada de {program.name}: {str(e)}")
                
                results['programs_analyzed'] += 1
            
            # Gerar relatório consolidado aprimorado
            self._generate_enhanced_consolidated_report(results, output_dir, doc_generator)
            
            # Estatísticas finais
            end_time = time.time()
            processing_time = end_time - start_time
            
            self.logger.info("=== ANÁLISE APRIMORADA CONCLUÍDA ===")
            self.logger.info(f"Programas processados: {results['programs_analyzed']}")
            self.logger.info(f"Análises bem-sucedidas: {results['programs_successful']}/{results['programs_analyzed']}")
            self.logger.info(f"Taxa de sucesso: {(results['programs_successful']/results['programs_analyzed']*100):.1f}%")
            self.logger.info(f"Total de tokens utilizados: {results['total_tokens_used']}")
            self.logger.info(f"Tempo de processamento: {processing_time:.2f}s")
            self.logger.info(f"Arquivos gerados em: {output_dir}")
            
            results['processing_time'] = processing_time
            results['success_rate'] = results['programs_successful'] / results['programs_analyzed'] * 100
            
            return results
            
        except Exception as e:
            self.logger.error(f"Erro na análise aprimorada: {str(e)}")
            raise COBOLAIEngineException(f"Falha na análise aprimorada: {str(e)}")
    
    def _prepare_enhanced_prompt(self, program, pre_analysis) -> str:
        """Prepara prompt aprimorado para análise descritiva."""
        
        # Obter system prompt aprimorado
        system_prompt = self.prompt_manager.get_system_prompt()
        
        # Obter perguntas de análise aprimoradas
        questions = self.prompt_manager.get_analysis_questions()
        
        # Preparar contexto da pré-análise
        pre_analysis_context = self._format_pre_analysis_context(pre_analysis)
        
        # Construir prompt aprimorado
        line_count = len(program.content.split('\n'))
        prompt_parts = [
            system_prompt,
            "",
            "=== PROGRAMA COBOL PARA ANÁLISE APROFUNDADA ===",
            "",
            f"NOME DO PROGRAMA: {program.name}",
            f"TAMANHO: {len(program.content)} caracteres",
            f"LINHAS: {line_count} linhas",
            "",
            "=== PRÉ-ANÁLISE ESTRUTURAL DETALHADA ===",
            "",
            pre_analysis_context,
            "",
            "=== CÓDIGO FONTE COMPLETO ===",
            "",
            program.content,
            "",
            "=== INSTRUÇÕES PARA ANÁLISE APRIMORADA ===",
            "",
            "Realize uma análise EXTREMAMENTE DETALHADA e DESCRITIVA deste programa COBOL, respondendo às seguintes perguntas com máxima profundidade e especificidade:",
            "",
            "1. ANÁLISE FUNCIONAL DETALHADA:",
            questions.get('functional_comprehensive', {}).get('question', 'Análise funcional detalhada'),
            "",
            "2. ANÁLISE DE REGRAS DE NEGÓCIO EXAUSTIVA:",
            questions.get('business_rules_exhaustive', {}).get('question', 'Análise de regras de negócio'),
            "",
            "3. ANÁLISE TÉCNICA ARQUITETURAL PROFUNDA:",
            questions.get('technical_architecture_deep', {}).get('question', 'Análise técnica arquitetural'),
            "",
            "IMPORTANTE:",
            "- Seja EXTREMAMENTE específico e detalhado em cada resposta",
            "- Use parágrafos descritivos completos, não bullet points simples",
            "- Relacione aspectos técnicos com impacto de negócio",
            "- Forneça exemplos específicos do código quando relevante",
            "- Inclua insights sobre modernização e melhorias",
            "- Documente riscos e oportunidades identificadas",
            "",
            "FORMATO DE RESPOSTA:",
            "Organize sua análise em seções bem estruturadas com títulos claros e conteúdo extremamente descritivo e aprofundado."
        ]
        
        enhanced_prompt = "\n".join(prompt_parts)
        
        return enhanced_prompt
    
    def _format_pre_analysis_context(self, pre_analysis) -> str:
        """Formata contexto da pré-análise para o prompt."""
        
        context_parts = [
            "ESTRUTURA DO PROGRAMA:",
            f"- Divisões identificadas: {len(pre_analysis.structure.divisions)}",
            f"- Seções identificadas: {len(pre_analysis.structure.sections)}",
            f"- Parágrafos identificados: {len(pre_analysis.structure.paragraphs)}",
            f"- Variáveis identificadas: {len(pre_analysis.structure.variables)}",
            f"- Arquivos referenciados: {len(pre_analysis.structure.files)}",
            f"- Copybooks utilizados: {len(pre_analysis.structure.copybooks)}",
            "",
            "REGRAS DE NEGÓCIO IDENTIFICADAS AUTOMATICAMENTE:",
            f"Total de regras: {len(pre_analysis.business_rules)}"
        ]
        
        # Adicionar detalhes das regras
        for i, rule in enumerate(pre_analysis.business_rules[:10], 1):  # Primeiras 10 regras
            context_parts.append(f"Regra {i}: {rule.type} - {rule.description} (Localização: {rule.location})")
        
        context_parts.extend([
            "",
            "ANÁLISE DE COMENTÁRIOS:",
            f"- Total de comentários: {pre_analysis.comments.total_comments}",
            f"- Comentários de negócio: {len(pre_analysis.comments.business_comments)}",
            f"- Comentários técnicos: {len(pre_analysis.comments.technical_comments)}",
            f"- Referências regulatórias: {len(pre_analysis.comments.regulatory_references)}",
            "",
            "MÉTRICAS DE QUALIDADE:",
            f"- Total de linhas: {pre_analysis.metrics.total_lines}",
            f"- Linhas de código: {pre_analysis.metrics.code_lines}",
            f"- Linhas de comentário: {pre_analysis.metrics.comment_lines}",
            f"- Complexidade estimada: {pre_analysis.metrics.complexity_score}"
        ])
        
        return "\n".join(context_parts)
    
    def _analyze_with_enhanced_ai(self, prompt: str, program_name: str):
        """Realiza análise com IA usando configurações aprimoradas."""
        
        try:
            # Obter provider configurado (LuzIA como primário)
            provider = self.provider_manager.providers.get(self.provider_manager.primary_provider)
            
            # Configurar request para análise aprimorada
            from src.providers.base_provider import AIRequest
            
            request = AIRequest(
                prompt=prompt,
                program_name=program_name,
                max_tokens=self.config.get('ai', {}).get('global_max_tokens', 8000),
                temperature=0.1,  # Baixa para consistência
                context={
                    'analysis_type': 'enhanced_descriptive',
                    'enhanced_features': {
                        'detailed_analysis': self.detailed_analysis,
                        'business_context': self.business_context,
                        'technical_depth': self.technical_depth
                    }
                }
            )
            
            # Executar análise
            response = provider.analyze(request)
            
            if response and response.content:
                self.logger.info(f"Análise aprimorada concluída para {program_name}: "
                               f"{len(response.content)} caracteres gerados")
                return response
            else:
                self.logger.warning(f"Resposta vazia da análise aprimorada para {program_name}")
                return None
                
        except Exception as e:
            self.logger.error(f"Erro na análise aprimorada com IA para {program_name}: {str(e)}")
            return None
    
    def _calculate_analysis_depth_score(self, ai_response, pre_analysis) -> int:
        """Calcula score de profundidade da análise."""
        score = 0
        
        if ai_response and ai_response.content:
            content_length = len(ai_response.content)
            score += min(content_length // 1000, 60)  # Até 60 pontos por conteúdo
        
        if pre_analysis:
            rules_count = len(pre_analysis.business_rules)
            score += min(rules_count * 3, 40)  # Até 40 pontos por regras
        
        return min(score, 100)  # Máximo 100
    
    def _generate_enhanced_consolidated_report(self, results: Dict[str, Any], 
                                             output_dir: str, 
                                             doc_generator: EnhancedDocumentationGenerator):
        """Gera relatório consolidado aprimorado."""
        
        try:
            self.logger.info("Gerando relatório consolidado aprimorado...")
            
            # Preparar dados do relatório
            report_data = {
                'generation_date': datetime.now().strftime("%d/%m/%Y %H:%M:%S"),
                'total_programs': results['programs_analyzed'],
                'successful_analyses': results['programs_successful'],
                'failed_analyses': results['programs_failed'],
                'success_rate': results.get('success_rate', 0),
                'total_tokens': results['total_tokens_used'],
                'processing_time': results.get('processing_time', 0),
                'enhanced_features': results['enhanced_features_used'],
                'analysis_details': results['analysis_details']
            }
            
            # Gerar conteúdo do relatório
            report_content = self._format_enhanced_consolidated_report(report_data)
            
            # Salvar relatório
            report_path = os.path.join(output_dir, "relatorio_consolidado_aprimorado.md")
            with open(report_path, 'w', encoding='utf-8') as f:
                f.write(report_content)
            
            self.logger.info(f"Relatório consolidado aprimorado gerado: {report_path}")
            
        except Exception as e:
            self.logger.error(f"Erro ao gerar relatório consolidado aprimorado: {str(e)}")
    
    def _format_enhanced_consolidated_report(self, data: Dict[str, Any]) -> str:
        """Formata relatório consolidado aprimorado."""
        
        return f"""# Relatório Consolidado Aprimorado - Análise COBOL

**Data de Geração:** {data['generation_date']}  
**Versão do Sistema:** COBOL AI Engine v2.2.0 Enhanced  
**Tipo de Análise:** Análise Descritiva Aprofundada

## Resumo Executivo da Análise Aprimorada

### Estatísticas Gerais
- **Total de Programas Analisados:** {data['total_programs']}
- **Análises Bem-sucedidas:** {data['successful_analyses']}
- **Análises com Falha:** {data['failed_analyses']}
- **Taxa de Sucesso:** {data['success_rate']:.1f}%
- **Total de Tokens Utilizados:** {data['total_tokens']:,}
- **Tempo de Processamento:** {data['processing_time']:.2f} segundos

### Funcionalidades Aprimoradas Utilizadas
- **Análise Detalhada:** {data['enhanced_features']['detailed_analysis']}
- **Contexto de Negócio:** {data['enhanced_features']['business_context']}
- **Profundidade Técnica:** {data['enhanced_features']['technical_depth']}

## Detalhamento por Programa

"""
        
        # Adicionar detalhes de cada programa
        for detail in data['analysis_details']:
            program_section = f"""
### {detail['program_name']}
- **Status:** {detail['status']}
- **Tokens Utilizados:** {detail['tokens_used']:,}
- **Score de Profundidade:** {detail['analysis_depth_score']}/100
- **Regras de Negócio Encontradas:** {detail['business_rules_found']}
- **Documentação:** {detail['documentation_path']}
- **Funcionalidades Aprimoradas:**
  - Prompts Detalhados: {detail['enhanced_features']['detailed_prompts']}
  - Análise de Contexto de Negócio: {detail['enhanced_features']['business_context_analysis']}
  - Análise de Profundidade Técnica: {detail['enhanced_features']['technical_depth_analysis']}

"""
            report_content += program_section
        
        conclusion_section = f"""
## Conclusões da Análise Aprimorada

Esta análise utilizou funcionalidades aprimoradas do COBOL AI Engine v2.2.0 Enhanced, 
incluindo prompts otimizados para o modelo Claude 3.5 Sonnet do LuzIA, templates de 
documentação aprimorados e configurações específicas para análises descritivas e aprofundadas.

### Benefícios das Melhorias Implementadas
- **Análises Mais Descritivas:** Relatórios extremamente detalhados e específicos
- **Contexto de Negócio Aprimorado:** Foco em regras de negócio e impacto operacional
- **Profundidade Técnica Máxima:** Análise arquitetural e técnica aprofundada
- **Integração Otimizada:** Configuração específica para LuzIA Claude 3.5 Sonnet

### Recomendações
- Utilizar os relatórios gerados para documentação técnica e de negócio
- Aproveitar as análises de regras de negócio para compliance e auditoria
- Usar as recomendações técnicas para planejamento de modernização
- Implementar as melhorias sugeridas para otimização de código

---

**Relatório gerado automaticamente pelo COBOL AI Engine v2.2.0 Enhanced**  
**Sistema de Análise Inteligente Aprimorado para Programas COBOL**  
**Data de Geração:** {data['generation_date']}
"""
        
        report_content += conclusion_section
        
        return report_content


def main():
    """Função principal do script aprimorado."""
    parser = argparse.ArgumentParser(
        description="COBOL AI Engine v2.2.0 Enhanced - Análise Descritiva Aprofundada"
    )
    
    parser.add_argument("--fontes", required=True, 
                       help="Arquivo com programas COBOL para análise")
    parser.add_argument("--books", 
                       help="Arquivo com copybooks (opcional)")
    parser.add_argument("--output", default="output_enhanced",
                       help="Diretório de saída (padrão: output_enhanced)")
    parser.add_argument("--config", default="config/config_luzia_enhanced.yaml",
                       help="Arquivo de configuração aprimorada")
    parser.add_argument("--prompts", default="config/prompts_enhanced.yaml",
                       help="Arquivo de prompts aprimorados")
    parser.add_argument("--pdf", action="store_true",
                       help="Gerar versões PDF dos relatórios")
    parser.add_argument("--log-level", choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'],
                       default='INFO', help="Nível de log")
    
    args = parser.parse_args()
    
    # Configurar nível de log
    logging.getLogger().setLevel(getattr(logging, args.log_level))
    
    try:
        # Inicializar engine aprimorado
        engine = EnhancedCOBOLAnalysisEngine(args.config, args.prompts)
        
        # Executar análise aprimorada
        results = engine.analyze_programs_enhanced(
            fontes_file=args.fontes,
            books_file=args.books,
            output_dir=args.output
        )
        
        # Gerar PDFs se solicitado
        if args.pdf:
            print("Convertendo documentação para PDF...")
            pdf_converter = MarkdownToPDFConverter()
            pdf_results = pdf_converter.convert_directory_to_pdf(args.output)
            print(f"Conversão PDF: {pdf_results['successful']}/{pdf_results['total']} arquivos convertidos")
            print(f"PDFs salvos em: {args.output}/pdf")
        
        # Exibir resultados finais
        print("\n=== ANÁLISE APRIMORADA CONCLUÍDA ===")
        print(f"Programas processados: {results['programs_analyzed']}")
        print(f"Análises bem-sucedidas: {results['programs_successful']}/{results['programs_analyzed']}")
        print(f"Taxa de sucesso: {results['success_rate']:.1f}%")
        print(f"Total de tokens utilizados: {results['total_tokens_used']:,}")
        print(f"Tempo de processamento: {results['processing_time']:.2f}s")
        print(f"Arquivos gerados em: {args.output}")
        
        if args.pdf:
            print(f"PDFs gerados em: {args.output}/pdf")
        
        return 0
        
    except Exception as e:
        print(f"Erro na execução: {str(e)}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
