#!/usr/bin/env python3
"""
Script de Debug para LuzIA Provider
Testa especificamente o problema de payload JSON.
"""

import os
import sys
import json
import yaml
import logging

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

# Configurar logging detalhado
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

def test_luzia_payload():
    """Testa criação e validação de payload LuzIA."""
    print("=== TESTE DEBUG LUZIA PAYLOAD ===")
    
    try:
        # Carregar configuração
        with open('config/config_unified.yaml', 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)
        
        # Configuração do LuzIA
        ai_config = config.get('ai', {})
        providers = ai_config.get('providers', {})
        luzia_config = providers.get('luzia', {})
        
        # Adicionar configurações globais
        full_config = {**luzia_config}
        full_config['performance'] = config.get('performance', {})
        
        print("1. Configuração carregada ")
        
        # Importar e inicializar LuzIA
        from src.providers.luzia_provider import LuziaProvider
        
        provider = LuziaProvider(full_config)
        print("2. LuzIA Provider inicializado ")
        
        # Criar payload de teste
        system_prompt = "Você é um especialista em COBOL."
        user_prompt = "Analise este programa COBOL simples: PROGRAM-ID. TESTE."
        
        payload = provider.create_complete_payload(system_prompt, user_prompt)
        print("3. Payload criado ")
        
        # Validar payload
        provider.validate_payload(payload)
        print("4. Payload validado ")
        
        # Mostrar estrutura do payload
        print("\n=== ESTRUTURA DO PAYLOAD ===")
        print(f"Chaves principais: {list(payload.keys())}")
        print(f"Input é dict: {isinstance(payload['input'], dict)}")
        print(f"Query é lista: {isinstance(payload['input']['query'], list)}")
        print(f"Número de mensagens: {len(payload['input']['query'])}")
        print(f"Config é lista: {isinstance(payload['config'], list)}")
        print(f"Config items: {len(payload['config'])}")
        if len(payload['config']) > 0:
            print(f"Config[0] keys: {list(payload['config'][0].keys())}")
        
        # Serializar para JSON
        json_str = json.dumps(payload, ensure_ascii=False, separators=(',', ':'))
        print(f"JSON size: {len(json_str)} chars")
        
        # Mostrar preview do JSON
        preview = json_str[:500] + "..." if len(json_str) > 500 else json_str
        print(f"\nJSON Preview:\n{preview}")
        
        # Testar se consegue fazer parse de volta
        parsed = json.loads(json_str)
        print("5. JSON serialization/deserialization ")
        
        # Verificar se estrutura está correta
        assert 'input' in parsed
        assert isinstance(parsed['input'], dict)
        assert 'query' in parsed['input']
        assert isinstance(parsed['input']['query'], list)
        assert len(parsed['input']['query']) == 2
        assert 'config' in parsed
        assert isinstance(parsed['config'], list)
        assert len(parsed['config']) > 0
        print("6. Estrutura JSON validada ")
        
        print("\n=== TESTE CONCLUÍDO COM SUCESSO ===")
        print("O payload está correto. O problema pode ser:")
        print("1. Credenciais incorretas")
        print("2. URL da API incorreta")
        print("3. Headers incorretos")
        print("4. Problema de rede/firewall")
        
        return True
        
    except Exception as e:
        print(f"\n ERRO: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

def test_luzia_connection():
    """Testa apenas a conexão com LuzIA."""
    print("\n=== TESTE DE CONEXÃO LUZIA ===")
    
    try:
        # Carregar configuração
        with open('config/config_unified.yaml', 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)
        
        # Configuração do LuzIA
        ai_config = config.get('ai', {})
        providers = ai_config.get('providers', {})
        luzia_config = providers.get('luzia', {})
        
        # Adicionar configurações globais
        full_config = {**luzia_config}
        full_config['performance'] = config.get('performance', {})
        
        # Importar e inicializar LuzIA
        from src.providers.luzia_provider import LuziaProvider
        
        provider = LuziaProvider(full_config)
        
        # Testar disponibilidade
        print("Testando disponibilidade...")
        available = provider.is_available()
        print(f"Disponível: {available}")
        
        if available:
            print(" LuzIA está disponível e funcionando!")
        else:
            print(" LuzIA não está disponível")
        
        return available
        
    except Exception as e:
        print(f" ERRO na conexão: {str(e)}")
        return False

if __name__ == "__main__":
    print("COBOL AI Engine - Debug LuzIA Provider")
    print("=" * 50)
    
    # Teste 1: Payload
    payload_ok = test_luzia_payload()
    
    # Teste 2: Conexão (apenas se payload estiver OK)
    if payload_ok:
        connection_ok = test_luzia_connection()
    else:
        connection_ok = False
    
    print("\n" + "=" * 50)
    print("RESULTADO FINAL:")
    print(f"Payload: {' OK' if payload_ok else ' ERRO'}")
    print(f"Conexão: {' OK' if connection_ok else ' ERRO'}")
    
    if payload_ok and connection_ok:
        print("\n LuzIA está funcionando perfeitamente!")
    elif payload_ok:
        print("\n⚠  Payload OK, mas problema de conexão")
    else:
        print("\n Problema no payload - verificar configuração")

