# Relatório Consolidado de Análise COBOL - Enhanced Analysis

**Data de Geração:** 17/09/2025 14:57:15
**Versão do Sistema:** COBOL AI Engine v2.2.0 Enhanced Analysis
**Provider Utilizado:** luzia

## Estatísticas Gerais

- **Programas Processados:** 5
- **Análises Bem-sucedidas:** 0/5
- **Taxa de Sucesso:** 0.0%
- **Total de Tokens Utilizados:** 0

## Detalhes por Programa

### LHAN0542

❌ **Status:** Falha na análise
- **Erro:** Falha na análise aprimorada

### LHAN0705

❌ **Status:** Falha na análise
- **Erro:** Falha na análise aprimorada

### LHAN0706

❌ **Status:** Falha na análise
- **Erro:** Falha na análise aprimorada

### LHBR0700

❌ **Status:** Falha na análise
- **Erro:** Falha na análise aprimorada

### MZAN6056

❌ **Status:** Falha na análise
- **Erro:** Falha na análise aprimorada

## Configurações Utilizadas

- **Provider Primário:** luzia
- **Max Tokens:** 8000
- **Temperature:** 0.05
- **Modelo:** aws-claude-3-5-sonnet

