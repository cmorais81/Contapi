"""
Gerador de Código Funcional
Gera código executável em linguagens modernas baseado na análise COBOL
"""

import logging
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from abc import ABC, abstractmethod

@dataclass
class CodeTemplate:
    """Template de código para uma linguagem específica"""
    language: str
    file_extension: str
    class_template: str
    method_template: str
    field_template: str
    validation_template: str
    routing_template: str

class CodeGenerator(ABC):
    """Interface base para geradores de código"""
    
    @abstractmethod
    def generate_data_structures(self, layouts: Dict[str, Any]) -> str:
        pass
    
    @abstractmethod
    def generate_validation_logic(self, validations: List[Dict[str, Any]]) -> str:
        pass
    
    @abstractmethod
    def generate_routing_logic(self, routing_rules: List[Dict[str, Any]]) -> str:
        pass
    
    @abstractmethod
    def generate_main_program(self, program_info: Dict[str, Any]) -> str:
        pass

class JavaCodeGenerator(CodeGenerator):
    """Gerador de código Java"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
    
    def generate_data_structures(self, layouts: Dict[str, Any]) -> str:
        """Gera classes Java para estruturas de dados COBOL"""
        code = "// Data Structures\n"
        code += "import java.math.BigDecimal;\n"
        code += "import java.util.List;\n"
        code += "import java.util.ArrayList;\n\n"
        
        for record_name, fields in layouts.items():
            code += f"public class {self._to_java_class_name(record_name)} {{\n"
            
            # Gerar campos
            for field in fields:
                java_type = self._cobol_to_java_type(field)
                field_name = self._to_java_field_name(field['name'])
                
                code += f"    private {java_type} {field_name};\n"
            
            code += "\n"
            
            # Gerar construtor
            code += f"    public {self._to_java_class_name(record_name)}() {{\n"
            code += "        // Initialize fields\n"
            code += "    }\n\n"
            
            # Gerar getters e setters
            for field in fields:
                java_type = self._cobol_to_java_type(field)
                field_name = self._to_java_field_name(field['name'])
                method_name = self._to_java_method_name(field['name'])
                
                # Getter
                code += f"    public {java_type} get{method_name}() {{\n"
                code += f"        return {field_name};\n"
                code += "    }\n\n"
                
                # Setter
                code += f"    public void set{method_name}({java_type} {field_name}) {{\n"
                code += f"        this.{field_name} = {field_name};\n"
                code += "    }\n\n"
            
            # Método toString
            code += "    @Override\n"
            code += "    public String toString() {\n"
            code += f"        return \"{record_name}{{\" +\n"
            
            field_strings = []
            for field in fields:
                field_name = self._to_java_field_name(field['name'])
                field_strings.append(f"                \"{field['name']}='\" + {field_name} + '\\'' +")
            
            if field_strings:
                code += "\n".join(field_strings[:-1]) + "\n"
                code += field_strings[-1].replace(" +", "") + "\n"
            
            code += "                '}';\n"
            code += "    }\n"
            code += "}\n\n"
        
        return code
    
    def generate_validation_logic(self, validations: List[Dict[str, Any]]) -> str:
        """Gera lógica de validação em Java"""
        code = "// Validation Logic\n"
        code += "public class RecordValidator {\n\n"
        
        code += "    public static class ValidationResult {\n"
        code += "        private boolean valid;\n"
        code += "        private String errorMessage;\n\n"
        
        code += "        public ValidationResult(boolean valid, String errorMessage) {\n"
        code += "            this.valid = valid;\n"
        code += "            this.errorMessage = errorMessage;\n"
        code += "        }\n\n"
        
        code += "        public boolean isValid() { return valid; }\n"
        code += "        public String getErrorMessage() { return errorMessage; }\n"
        code += "    }\n\n"
        
        # Método principal de validação
        code += "    public static ValidationResult validateRecord(Object record) {\n"
        code += "        List<String> errors = new ArrayList<>();\n\n"
        
        for validation in validations:
            field_name = self._to_java_field_name(validation['field'])
            operator = validation['operator']
            
            code += f"        // Validate {validation['field']}\n"
            
            if operator == "NUMERIC":
                code += f"        if (!isNumeric(get{self._to_java_method_name(validation['field'])}(record))) {{\n"
                code += f"            errors.add(\"{validation['field']} must be numeric\");\n"
                code += "        }\n\n"
            elif operator == "NOT_SPACES":
                code += f"        if (isSpaces(get{self._to_java_method_name(validation['field'])}(record))) {{\n"
                code += f"            errors.add(\"{validation['field']} cannot be spaces\");\n"
                code += "        }\n\n"
            elif operator == "NOT_ZERO":
                code += f"        if (isZero(get{self._to_java_method_name(validation['field'])}(record))) {{\n"
                code += f"            errors.add(\"{validation['field']} cannot be zero\");\n"
                code += "        }\n\n"
        
        code += "        if (errors.isEmpty()) {\n"
        code += "            return new ValidationResult(true, null);\n"
        code += "        } else {\n"
        code += "            return new ValidationResult(false, String.join(\"; \", errors));\n"
        code += "        }\n"
        code += "    }\n\n"
        
        # Métodos auxiliares
        code += "    private static boolean isNumeric(String value) {\n"
        code += "        if (value == null || value.trim().isEmpty()) return false;\n"
        code += "        try {\n"
        code += "            Double.parseDouble(value.trim());\n"
        code += "            return true;\n"
        code += "        } catch (NumberFormatException e) {\n"
        code += "            return false;\n"
        code += "        }\n"
        code += "    }\n\n"
        
        code += "    private static boolean isSpaces(String value) {\n"
        code += "        return value == null || value.trim().isEmpty();\n"
        code += "    }\n\n"
        
        code += "    private static boolean isZero(String value) {\n"
        code += "        return \"0\".equals(value) || \"0.0\".equals(value) || \"0.00\".equals(value);\n"
        code += "    }\n\n"
        
        code += "}\n\n"
        
        return code
    
    def generate_routing_logic(self, routing_rules: List[Dict[str, Any]]) -> str:
        """Gera lógica de roteamento em Java"""
        code = "// Routing Logic\n"
        code += "import java.io.*;\n"
        code += "import java.util.*;\n\n"
        
        code += "public class RecordRouter {\n\n"
        
        code += "    public enum OutputFile {\n"
        for i, rule in enumerate(routing_rules):
            file_name = rule['output_file'].replace('-', '_').upper()
            code += f"        {file_name}(\"{rule['output_file']}\")"
            if i < len(routing_rules) - 1:
                code += ","
            code += "\n"
        
        code += ";\n\n"
        code += "        private final String fileName;\n"
        code += "        OutputFile(String fileName) { this.fileName = fileName; }\n"
        code += "        public String getFileName() { return fileName; }\n"
        code += "    }\n\n"
        
        # Método principal de roteamento
        code += "    public static OutputFile determineOutputFile(Object record) {\n"
        
        for rule in routing_rules:
            file_name = rule['output_file'].replace('-', '_').upper()
            
            if rule['conditions']:
                code += f"        // Route to {rule['output_file']}\n"
                conditions = []
                
                for condition in rule['conditions']:
                    field_getter = f"get{self._to_java_method_name(condition['field'])}(record)"
                    operator = condition['operator']
                    value = condition['value']
                    
                    if operator == "EQUAL":
                        conditions.append(f"\"{value}\".equals({field_getter})")
                    elif operator == "NOT_EQUAL":
                        conditions.append(f"!\"{value}\".equals({field_getter})")
                    elif operator == "GREATER_THAN":
                        conditions.append(f"Integer.parseInt({field_getter}) > {value}")
                    elif operator == "LESS_THAN":
                        conditions.append(f"Integer.parseInt({field_getter}) < {value}")
                
                if conditions:
                    code += f"        if ({' && '.join(conditions)}) {{\n"
                    code += f"            return OutputFile.{file_name};\n"
                    code += "        }\n\n"
        
        # Default case
        if routing_rules:
            default_file = routing_rules[0]['output_file'].replace('-', '_').upper()
            code += f"        // Default routing\n"
            code += f"        return OutputFile.{default_file};\n"
        
        code += "    }\n\n"
        
        # Método para escrever arquivo
        code += "    public static void writeRecord(Object record, OutputFile outputFile, PrintWriter writer) {\n"
        code += "        writer.println(record.toString());\n"
        code += "    }\n\n"
        
        code += "}\n\n"
        
        return code
    
    def generate_main_program(self, program_info: Dict[str, Any]) -> str:
        """Gera programa principal em Java"""
        program_name = program_info.get('program_name', 'COBOLMigration')
        
        code = f"// Main Program - {program_name}\n"
        code += "import java.io.*;\n"
        code += "import java.util.*;\n\n"
        
        code += f"public class {program_name}Processor {{\n\n"
        
        code += "    public static void main(String[] args) {\n"
        code += "        if (args.length < 1) {\n"
        code += "            System.err.println(\"Usage: java \" + \n"
        code += f"                {program_name}Processor.class.getSimpleName() + \" <input-file>\");\n"
        code += "            System.exit(1);\n"
        code += "        }\n\n"
        
        code += "        String inputFile = args[0];\n"
        code += f"        {program_name}Processor processor = new {program_name}Processor();\n"
        code += "        \n"
        code += "        try {\n"
        code += "            processor.processFile(inputFile);\n"
        code += "        } catch (IOException e) {\n"
        code += "            System.err.println(\"Error processing file: \" + e.getMessage());\n"
        code += "            e.printStackTrace();\n"
        code += "        }\n"
        code += "    }\n\n"
        
        # Método de processamento
        code += "    public void processFile(String inputFileName) throws IOException {\n"
        code += "        Map<RecordRouter.OutputFile, PrintWriter> writers = new HashMap<>();\n"
        code += "        \n"
        code += "        // Initialize output writers\n"
        code += "        for (RecordRouter.OutputFile outputFile : RecordRouter.OutputFile.values()) {\n"
        code += "            String outputFileName = outputFile.getFileName();\n"
        code += "            writers.put(outputFile, new PrintWriter(new FileWriter(outputFileName)));\n"
        code += "        }\n\n"
        
        code += "        try (BufferedReader reader = new BufferedReader(new FileReader(inputFileName))) {\n"
        code += "            String line;\n"
        code += "            int recordCount = 0;\n"
        code += "            int validRecords = 0;\n"
        code += "            int invalidRecords = 0;\n\n"
        
        code += "            while ((line = reader.readLine()) != null) {\n"
        code += "                recordCount++;\n"
        code += "                \n"
        code += "                // Parse record (implement based on your record structure)\n"
        code += "                Object record = parseRecord(line);\n"
        code += "                \n"
        code += "                // Validate record\n"
        code += "                RecordValidator.ValidationResult validation = \n"
        code += "                    RecordValidator.validateRecord(record);\n"
        code += "                \n"
        code += "                if (validation.isValid()) {\n"
        code += "                    validRecords++;\n"
        code += "                    \n"
        code += "                    // Determine output file\n"
        code += "                    RecordRouter.OutputFile outputFile = \n"
        code += "                        RecordRouter.determineOutputFile(record);\n"
        code += "                    \n"
        code += "                    // Write to appropriate file\n"
        code += "                    RecordRouter.writeRecord(record, outputFile, writers.get(outputFile));\n"
        code += "                } else {\n"
        code += "                    invalidRecords++;\n"
        code += "                    System.err.println(\"Invalid record at line \" + recordCount + \n"
        code += "                        \": \" + validation.getErrorMessage());\n"
        code += "                }\n"
        code += "            }\n\n"
        
        code += "            // Print summary\n"
        code += "            System.out.println(\"Processing completed:\");\n"
        code += "            System.out.println(\"Total records: \" + recordCount);\n"
        code += "            System.out.println(\"Valid records: \" + validRecords);\n"
        code += "            System.out.println(\"Invalid records: \" + invalidRecords);\n"
        
        code += "        } finally {\n"
        code += "            // Close all writers\n"
        code += "            for (PrintWriter writer : writers.values()) {\n"
        code += "                writer.close();\n"
        code += "            }\n"
        code += "        }\n"
        code += "    }\n\n"
        
        # Método de parsing (placeholder)
        code += "    private Object parseRecord(String line) {\n"
        code += "        // TODO: Implement record parsing based on COBOL layout\n"
        code += "        // This should create and populate your record object\n"
        code += "        // based on the fixed-width format from COBOL\n"
        code += "        return new Object(); // Placeholder\n"
        code += "    }\n\n"
        
        code += "}\n"
        
        return code
    
    def _cobol_to_java_type(self, field: Dict[str, Any]) -> str:
        """Converte tipo COBOL para tipo Java"""
        data_type = field.get('data_type', 'unknown')
        
        type_mapping = {
            'numeric': 'int',
            'signed_numeric': 'int',
            'decimal': 'BigDecimal',
            'signed_decimal': 'BigDecimal',
            'alphanumeric': 'String',
            'alphabetic': 'String',
            'edited_numeric': 'String',
            'group': 'Object',
            'unknown': 'String'
        }
        
        return type_mapping.get(data_type, 'String')
    
    def _to_java_class_name(self, cobol_name: str) -> str:
        """Converte nome COBOL para nome de classe Java"""
        # Remove hífens e converte para PascalCase
        parts = cobol_name.replace('-', '_').split('_')
        return ''.join(word.capitalize() for word in parts)
    
    def _to_java_field_name(self, cobol_name: str) -> str:
        """Converte nome COBOL para nome de campo Java"""
        # Remove hífens e converte para camelCase
        parts = cobol_name.replace('-', '_').split('_')
        if not parts:
            return cobol_name.lower()
        
        return parts[0].lower() + ''.join(word.capitalize() for word in parts[1:])
    
    def _to_java_method_name(self, cobol_name: str) -> str:
        """Converte nome COBOL para nome de método Java"""
        # Similar ao campo, mas primeira letra maiúscula para getters/setters
        field_name = self._to_java_field_name(cobol_name)
        return field_name.capitalize()

class PythonCodeGenerator(CodeGenerator):
    """Gerador de código Python"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
    
    def generate_data_structures(self, layouts: Dict[str, Any]) -> str:
        """Gera classes Python para estruturas de dados COBOL"""
        code = "# Data Structures\n"
        code += "from dataclasses import dataclass\n"
        code += "from typing import Optional\n"
        code += "from decimal import Decimal\n\n"
        
        for record_name, fields in layouts.items():
            class_name = self._to_python_class_name(record_name)
            
            code += "@dataclass\n"
            code += f"class {class_name}:\n"
            code += '    """Data structure for COBOL record ' + record_name + '"""\n'
            
            # Gerar campos
            for field in fields:
                python_type = self._cobol_to_python_type(field)
                field_name = self._to_python_field_name(field['name'])
                
                code += f"    {field_name}: {python_type} = None\n"
            
            code += "\n"
            
            # Método de validação
            code += "    def validate(self) -> tuple[bool, str]:\n"
            code += '        """Validate record fields"""\n'
            code += "        errors = []\n"
            
            for field in fields:
                field_name = self._to_python_field_name(field['name'])
                data_type = field.get('data_type', 'unknown')
                
                if data_type in ['numeric', 'signed_numeric']:
                    code += f"        if self.{field_name} is not None and not isinstance(self.{field_name}, int):\n"
                    code += f"            errors.append(f'{field['name']} must be numeric')\n"
                elif data_type in ['decimal', 'signed_decimal']:
                    code += f"        if self.{field_name} is not None and not isinstance(self.{field_name}, (int, float, Decimal)):\n"
                    code += f"            errors.append(f'{field['name']} must be decimal')\n"
            
            code += "        \n"
            code += "        if errors:\n"
            code += "            return False, '; '.join(errors)\n"
            code += "        return True, ''\n\n"
        
        return code
    
    def generate_validation_logic(self, validations: List[Dict[str, Any]]) -> str:
        """Gera lógica de validação em Python"""
        code = "# Validation Logic\n"
        code += "import re\n"
        code += "from typing import Any, Tuple\n\n"
        
        code += "class RecordValidator:\n"
        code += '    """Validates COBOL records according to business rules"""\n\n'
        
        code += "    @staticmethod\n"
        code += "    def validate_record(record: Any) -> Tuple[bool, str]:\n"
        code += '        """Validate a record and return (is_valid, error_message)"""\n'
        code += "        errors = []\n\n"
        
        for validation in validations:
            field_name = self._to_python_field_name(validation['field'])
            operator = validation['operator']
            
            code += f"        # Validate {validation['field']}\n"
            
            if operator == "NUMERIC":
                code += f"        if not RecordValidator._is_numeric(getattr(record, '{field_name}', None)):\n"
                code += f"            errors.append('{validation['field']} must be numeric')\n\n"
            elif operator == "NOT_SPACES":
                code += f"        if RecordValidator._is_spaces(getattr(record, '{field_name}', None)):\n"
                code += f"            errors.append('{validation['field']} cannot be spaces')\n\n"
            elif operator == "NOT_ZERO":
                code += f"        if RecordValidator._is_zero(getattr(record, '{field_name}', None)):\n"
                code += f"            errors.append('{validation['field']} cannot be zero')\n\n"
        
        code += "        if errors:\n"
        code += "            return False, '; '.join(errors)\n"
        code += "        return True, ''\n\n"
        
        # Métodos auxiliares
        code += "    @staticmethod\n"
        code += "    def _is_numeric(value: Any) -> bool:\n"
        code += "        if value is None:\n"
        code += "            return False\n"
        code += "        try:\n"
        code += "            float(str(value).strip())\n"
        code += "            return True\n"
        code += "        except (ValueError, TypeError):\n"
        code += "            return False\n\n"
        
        code += "    @staticmethod\n"
        code += "    def _is_spaces(value: Any) -> bool:\n"
        code += "        return value is None or str(value).strip() == ''\n\n"
        
        code += "    @staticmethod\n"
        code += "    def _is_zero(value: Any) -> bool:\n"
        code += "        return str(value).strip() in ['0', '0.0', '0.00']\n\n"
        
        return code
    
    def generate_routing_logic(self, routing_rules: List[Dict[str, Any]]) -> str:
        """Gera lógica de roteamento em Python"""
        code = "# Routing Logic\n"
        code += "from enum import Enum\n"
        code += "from typing import Any\n\n"
        
        code += "class OutputFile(Enum):\n"
        code += '    """Output file destinations"""\n'
        
        for rule in routing_rules:
            file_name = rule['output_file'].replace('-', '_').upper()
            code += f"    {file_name} = '{rule['output_file']}'\n"
        
        code += "\n\n"
        
        code += "class RecordRouter:\n"
        code += '    """Routes records to appropriate output files"""\n\n'
        
        code += "    @staticmethod\n"
        code += "    def determine_output_file(record: Any) -> OutputFile:\n"
        code += '        """Determine which output file to use for a record"""\n'
        
        for rule in routing_rules:
            file_name = rule['output_file'].replace('-', '_').upper()
            
            if rule['conditions']:
                code += f"        # Route to {rule['output_file']}\n"
                conditions = []
                
                for condition in rule['conditions']:
                    field_name = self._to_python_field_name(condition['field'])
                    operator = condition['operator']
                    value = condition['value']
                    
                    if operator == "EQUAL":
                        conditions.append(f"getattr(record, '{field_name}', None) == '{value}'")
                    elif operator == "NOT_EQUAL":
                        conditions.append(f"getattr(record, '{field_name}', None) != '{value}'")
                    elif operator == "GREATER_THAN":
                        conditions.append(f"int(getattr(record, '{field_name}', 0)) > {value}")
                    elif operator == "LESS_THAN":
                        conditions.append(f"int(getattr(record, '{field_name}', 0)) < {value}")
                
                if conditions:
                    code += f"        if {' and '.join(conditions)}:\n"
                    code += f"            return OutputFile.{file_name}\n\n"
        
        # Default case
        if routing_rules:
            default_file = routing_rules[0]['output_file'].replace('-', '_').upper()
            code += f"        # Default routing\n"
            code += f"        return OutputFile.{default_file}\n\n"
        
        return code
    
    def generate_main_program(self, program_info: Dict[str, Any]) -> str:
        """Gera programa principal em Python"""
        program_name = program_info.get('program_name', 'cobol_migration')
        
        code = f"# Main Program - {program_name}\n"
        code += "import sys\n"
        code += "from typing import Dict, TextIO\n\n"
        
        code += f"class {program_name.capitalize()}Processor:\n"
        code += f'    """Main processor for {program_name} migration"""\n\n'
        
        code += "    def __init__(self):\n"
        code += "        self.record_count = 0\n"
        code += "        self.valid_records = 0\n"
        code += "        self.invalid_records = 0\n\n"
        
        code += "    def process_file(self, input_filename: str) -> None:\n"
        code += '        """Process input file and generate output files"""\n'
        code += "        output_files: Dict[OutputFile, TextIO] = {}\n"
        code += "        \n"
        code += "        # Open output files\n"
        code += "        try:\n"
        code += "            for output_file in OutputFile:\n"
        code += "                output_files[output_file] = open(output_file.value, 'w')\n"
        code += "            \n"
        code += "            with open(input_filename, 'r') as input_file:\n"
        code += "                for line_num, line in enumerate(input_file, 1):\n"
        code += "                    self.record_count += 1\n"
        code += "                    \n"
        code += "                    # Parse record\n"
        code += "                    record = self.parse_record(line.strip())\n"
        code += "                    \n"
        code += "                    # Validate record\n"
        code += "                    is_valid, error_msg = RecordValidator.validate_record(record)\n"
        code += "                    \n"
        code += "                    if is_valid:\n"
        code += "                        self.valid_records += 1\n"
        code += "                        \n"
        code += "                        # Determine output file\n"
        code += "                        output_file = RecordRouter.determine_output_file(record)\n"
        code += "                        \n"
        code += "                        # Write record\n"
        code += "                        output_files[output_file].write(f'{record}\\n')\n"
        code += "                    else:\n"
        code += "                        self.invalid_records += 1\n"
        code += "                        print(f'Invalid record at line {line_num}: {error_msg}', \n"
        code += "                              file=sys.stderr)\n"
        code += "        \n"
        code += "        finally:\n"
        code += "            # Close output files\n"
        code += "            for file_handle in output_files.values():\n"
        code += "                file_handle.close()\n"
        code += "        \n"
        code += "        # Print summary\n"
        code += "        print(f'Processing completed:')\n"
        code += "        print(f'Total records: {self.record_count}')\n"
        code += "        print(f'Valid records: {self.valid_records}')\n"
        code += "        print(f'Invalid records: {self.invalid_records}')\n\n"
        
        code += "    def parse_record(self, line: str) -> Any:\n"
        code += '        """Parse a line into a record object"""\n'
        code += "        # TODO: Implement record parsing based on COBOL layout\n"
        code += "        # This should create and populate your record object\n"
        code += "        # based on the fixed-width format from COBOL\n"
        code += "        return line  # Placeholder\n\n"
        
        code += "\n"
        code += "def main():\n"
        code += "    if len(sys.argv) < 2:\n"
        code += f"        print(f'Usage: python {{sys.argv[0]}} <input-file>', file=sys.stderr)\n"
        code += "        sys.exit(1)\n"
        code += "    \n"
        code += "    input_file = sys.argv[1]\n"
        code += f"    processor = {program_name.capitalize()}Processor()\n"
        code += "    \n"
        code += "    try:\n"
        code += "        processor.process_file(input_file)\n"
        code += "    except Exception as e:\n"
        code += "        print(f'Error processing file: {e}', file=sys.stderr)\n"
        code += "        sys.exit(1)\n\n"
        
        code += "if __name__ == '__main__':\n"
        code += "    main()\n"
        
        return code
    
    def _cobol_to_python_type(self, field: Dict[str, Any]) -> str:
        """Converte tipo COBOL para tipo Python"""
        data_type = field.get('data_type', 'unknown')
        
        type_mapping = {
            'numeric': 'Optional[int]',
            'signed_numeric': 'Optional[int]',
            'decimal': 'Optional[Decimal]',
            'signed_decimal': 'Optional[Decimal]',
            'alphanumeric': 'Optional[str]',
            'alphabetic': 'Optional[str]',
            'edited_numeric': 'Optional[str]',
            'group': 'Optional[dict]',
            'unknown': 'Optional[str]'
        }
        
        return type_mapping.get(data_type, 'Optional[str]')
    
    def _to_python_class_name(self, cobol_name: str) -> str:
        """Converte nome COBOL para nome de classe Python"""
        # Remove hífens e converte para PascalCase
        parts = cobol_name.replace('-', '_').split('_')
        return ''.join(word.capitalize() for word in parts)
    
    def _to_python_field_name(self, cobol_name: str) -> str:
        """Converte nome COBOL para nome de campo Python"""
        # Remove hífens e converte para snake_case
        return cobol_name.replace('-', '_').lower()

class FunctionalCodeGenerator:
    """Gerador principal que coordena a geração de código funcional"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.generators = {
            'java': JavaCodeGenerator(),
            'python': PythonCodeGenerator()
        }
    
    def generate_complete_code(self, 
                             analysis_data: Dict[str, Any], 
                             target_language: str = 'java') -> Dict[str, str]:
        """
        Gera código completo e funcional baseado na análise COBOL
        
        Args:
            analysis_data: Dados da análise completa do COBOL
            target_language: Linguagem alvo (java, python)
            
        Returns:
            Dict com arquivos de código gerados
        """
        self.logger.info(f"Gerando código funcional em {target_language}")
        
        if target_language not in self.generators:
            raise ValueError(f"Linguagem não suportada: {target_language}")
        
        generator = self.generators[target_language]
        
        # Extrair dados necessários
        layouts = analysis_data.get('record_layouts', {})
        validations = analysis_data.get('validation_conditions', [])
        routing_rules = analysis_data.get('routing_rules', [])
        program_info = analysis_data.get('program_info', {})
        
        # Gerar código
        code_files = {}
        
        # Estruturas de dados
        if layouts:
            code_files['data_structures'] = generator.generate_data_structures(layouts)
        
        # Lógica de validação
        if validations:
            code_files['validation_logic'] = generator.generate_validation_logic(validations)
        
        # Lógica de roteamento
        if routing_rules:
            code_files['routing_logic'] = generator.generate_routing_logic(routing_rules)
        
        # Programa principal
        code_files['main_program'] = generator.generate_main_program(program_info)
        
        self.logger.info(f"Código gerado: {len(code_files)} arquivos")
        return code_files
    
    def save_generated_code(self, code_files: Dict[str, str], 
                          output_dir: str, 
                          target_language: str) -> List[str]:
        """
        Salva os arquivos de código gerados
        
        Args:
            code_files: Arquivos de código gerados
            output_dir: Diretório de saída
            target_language: Linguagem alvo
            
        Returns:
            Lista de caminhos dos arquivos salvos
        """
        import os
        
        # Determinar extensão
        extensions = {
            'java': '.java',
            'python': '.py'
        }
        
        extension = extensions.get(target_language, '.txt')
        
        # Criar diretório se não existir
        os.makedirs(output_dir, exist_ok=True)
        
        saved_files = []
        
        for file_type, code_content in code_files.items():
            filename = f"{file_type}{extension}"
            filepath = os.path.join(output_dir, filename)
            
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(code_content)
            
            saved_files.append(filepath)
            self.logger.info(f"Código salvo: {filepath}")
        
        return saved_files
