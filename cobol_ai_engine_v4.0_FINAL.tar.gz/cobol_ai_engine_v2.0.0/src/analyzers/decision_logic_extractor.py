"""
Extrator de Lógica de Decisão Específica
Identifica critérios exatos de segregação e roteamento de dados
"""

import re
import logging
from typing import Dict, List, Any, Optional, Tuple, Set
from dataclasses import dataclass
from enum import Enum

class DecisionType(Enum):
    IF_CONDITION = "IF"
    EVALUATE_WHEN = "EVALUATE"
    PERFORM_UNTIL = "PERFORM_UNTIL"
    PERFORM_VARYING = "PERFORM_VARYING"
    FILE_ROUTING = "FILE_ROUTING"
    VALIDATION_RULE = "VALIDATION"

@dataclass
class DecisionCondition:
    """Representa uma condição de decisão específica"""
    condition_type: DecisionType
    field_name: str
    operator: str
    value: str
    line_number: int
    context: str
    action_true: str
    action_false: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'type': self.condition_type.value,
            'field': self.field_name,
            'operator': self.operator,
            'value': self.value,
            'line': self.line_number,
            'context': self.context,
            'action_true': self.action_true,
            'action_false': self.action_false
        }

@dataclass
class FileRoutingRule:
    """Regra específica de roteamento para arquivos"""
    output_file: str
    conditions: List[DecisionCondition]
    priority: int
    description: str
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'output_file': self.output_file,
            'conditions': [c.to_dict() for c in self.conditions],
            'priority': self.priority,
            'description': self.description
        }

@dataclass
class DecisionLogicAnalysis:
    """Análise completa da lógica de decisão"""
    routing_rules: List[FileRoutingRule]
    validation_conditions: List[DecisionCondition]
    business_logic_conditions: List[DecisionCondition]
    complexity_score: int
    decision_tree: Dict[str, Any]
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'routing_rules': [r.to_dict() for r in self.routing_rules],
            'validation_conditions': [c.to_dict() for c in self.validation_conditions],
            'business_logic_conditions': [c.to_dict() for c in self.business_logic_conditions],
            'complexity_score': self.complexity_score,
            'decision_tree': self.decision_tree
        }

class DecisionLogicExtractor:
    """Extrator especializado em lógica de decisão e roteamento"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
        # Padrões para identificar condições
        self.if_pattern = re.compile(
            r'IF\s+([A-Z0-9\-_]+)\s*(=|>|<|>=|<=|NOT\s*=|\bIS\b|\bNOT\b)\s*([\'"]?[^\'"\s]+[\'"]?)',
            re.IGNORECASE
        )
        
        self.evaluate_pattern = re.compile(
            r'EVALUATE\s+([A-Z0-9\-_]+)',
            re.IGNORECASE
        )
        
        self.when_pattern = re.compile(
            r'WHEN\s+([\'"]?[^\'"\s]+[\'"]?)',
            re.IGNORECASE
        )
        
        # Padrões para identificar operações de arquivo
        self.write_pattern = re.compile(
            r'WRITE\s+([A-Z0-9\-_]+)',
            re.IGNORECASE
        )
        
        self.open_pattern = re.compile(
            r'OPEN\s+(INPUT|OUTPUT|I-O|EXTEND)\s+([A-Z0-9\-_]+)',
            re.IGNORECASE
        )
        
        # Padrões para validações
        self.validation_patterns = {
            'numeric': re.compile(r'IS\s+NUMERIC', re.IGNORECASE),
            'not_numeric': re.compile(r'NOT\s+NUMERIC', re.IGNORECASE),
            'spaces': re.compile(r'IS\s+SPACES', re.IGNORECASE),
            'not_spaces': re.compile(r'NOT\s+SPACES', re.IGNORECASE),
            'zero': re.compile(r'IS\s+ZERO', re.IGNORECASE),
            'not_zero': re.compile(r'NOT\s+ZERO', re.IGNORECASE),
            'positive': re.compile(r'IS\s+POSITIVE', re.IGNORECASE),
            'negative': re.compile(r'IS\s+NEGATIVE', re.IGNORECASE)
        }
        
        # Operadores de comparação
        self.operators = {
            '=': 'EQUAL',
            '>': 'GREATER_THAN',
            '<': 'LESS_THAN',
            '>=': 'GREATER_EQUAL',
            '<=': 'LESS_EQUAL',
            'NOT =': 'NOT_EQUAL',
            'IS': 'IS',
            'NOT': 'NOT'
        }
    
    def extract_decision_logic(self, cobol_code: str, file_info: Dict[str, Any]) -> DecisionLogicAnalysis:
        """
        Extrai toda a lógica de decisão do código COBOL
        
        Args:
            cobol_code: Código COBOL completo
            file_info: Informações sobre arquivos identificados
            
        Returns:
            DecisionLogicAnalysis com análise completa
        """
        self.logger.info("Iniciando extração de lógica de decisão")
        
        lines = cobol_code.split('\n')
        
        # Extrair diferentes tipos de condições
        validation_conditions = self._extract_validation_conditions(lines)
        business_conditions = self._extract_business_logic_conditions(lines)
        routing_rules = self._extract_file_routing_rules(lines, file_info)
        
        # Calcular complexidade
        complexity_score = self._calculate_decision_complexity(
            validation_conditions + business_conditions
        )
        
        # Construir árvore de decisão
        decision_tree = self._build_decision_tree(routing_rules, validation_conditions)
        
        analysis = DecisionLogicAnalysis(
            routing_rules=routing_rules,
            validation_conditions=validation_conditions,
            business_logic_conditions=business_conditions,
            complexity_score=complexity_score,
            decision_tree=decision_tree
        )
        
        self.logger.info(f"Lógica extraída: {len(routing_rules)} regras de roteamento, "
                        f"{len(validation_conditions)} validações, "
                        f"{len(business_conditions)} condições de negócio")
        
        return analysis
    
    def _extract_validation_conditions(self, lines: List[str]) -> List[DecisionCondition]:
        """Extrai condições de validação de dados"""
        conditions = []
        
        for line_num, line in enumerate(lines, 1):
            if line.strip().startswith('*'):
                continue
            
            # Verificar validações específicas
            for validation_type, pattern in self.validation_patterns.items():
                if pattern.search(line):
                    # Tentar extrair o campo sendo validado
                    field_match = re.search(r'IF\s+([A-Z0-9\-_]+)', line, re.IGNORECASE)
                    if field_match:
                        field_name = field_match.group(1)
                        
                        # Determinar ação baseada no contexto
                        action = self._extract_action_from_context(lines, line_num)
                        
                        condition = DecisionCondition(
                            condition_type=DecisionType.VALIDATION_RULE,
                            field_name=field_name,
                            operator=validation_type.upper(),
                            value="",
                            line_number=line_num,
                            context=line.strip(),
                            action_true=action
                        )
                        conditions.append(condition)
                        
                        self.logger.debug(f"Validação encontrada: {field_name} {validation_type} (linha {line_num})")
        
        return conditions
    
    def _extract_business_logic_conditions(self, lines: List[str]) -> List[DecisionCondition]:
        """Extrai condições de lógica de negócio"""
        conditions = []
        
        for line_num, line in enumerate(lines, 1):
            if line.strip().startswith('*'):
                continue
            
            # Extrair condições IF
            if_matches = self.if_pattern.findall(line)
            for match in if_matches:
                field_name, operator, value = match
                
                # Limpar valor (remover aspas se presentes)
                clean_value = value.strip('\'"')
                
                # Extrair ação
                action = self._extract_action_from_context(lines, line_num)
                
                condition = DecisionCondition(
                    condition_type=DecisionType.IF_CONDITION,
                    field_name=field_name,
                    operator=self.operators.get(operator.upper(), operator.upper()),
                    value=clean_value,
                    line_number=line_num,
                    context=line.strip(),
                    action_true=action
                )
                conditions.append(condition)
                
                self.logger.debug(f"Condição IF: {field_name} {operator} {clean_value} (linha {line_num})")
            
            # Extrair condições EVALUATE
            evaluate_match = self.evaluate_pattern.search(line)
            if evaluate_match:
                field_name = evaluate_match.group(1)
                
                # Procurar cláusulas WHEN subsequentes
                when_conditions = self._extract_when_clauses(lines, line_num)
                conditions.extend(when_conditions)
        
        return conditions
    
    def _extract_when_clauses(self, lines: List[str], evaluate_line: int) -> List[DecisionCondition]:
        """Extrai cláusulas WHEN de um EVALUATE"""
        conditions = []
        evaluate_line_content = lines[evaluate_line - 1]
        
        # Extrair campo do EVALUATE
        evaluate_match = self.evaluate_pattern.search(evaluate_line_content)
        if not evaluate_match:
            return conditions
        
        field_name = evaluate_match.group(1)
        
        # Procurar WHEN nas linhas seguintes
        for i in range(evaluate_line, min(evaluate_line + 20, len(lines))):
            line = lines[i]
            
            # Parar se encontrar END-EVALUATE ou nova estrutura
            if re.search(r'END-EVALUATE|EVALUATE|IF\s+', line, re.IGNORECASE):
                if 'END-EVALUATE' in line.upper():
                    break
                elif i > evaluate_line:  # Nova estrutura
                    break
            
            when_match = self.when_pattern.search(line)
            if when_match:
                value = when_match.group(1).strip('\'"')
                action = self._extract_action_from_context(lines, i + 1)
                
                condition = DecisionCondition(
                    condition_type=DecisionType.EVALUATE_WHEN,
                    field_name=field_name,
                    operator="EQUAL",
                    value=value,
                    line_number=i + 1,
                    context=line.strip(),
                    action_true=action
                )
                conditions.append(condition)
                
                self.logger.debug(f"WHEN encontrado: {field_name} = {value} (linha {i + 1})")
        
        return conditions
    
    def _extract_file_routing_rules(self, lines: List[str], file_info: Dict[str, Any]) -> List[FileRoutingRule]:
        """Extrai regras específicas de roteamento para arquivos"""
        routing_rules = []
        
        # Identificar arquivos de saída
        output_files = file_info.get('output_files', [])
        if not output_files:
            return routing_rules
        
        # Analisar cada arquivo de saída
        for file_idx, output_file in enumerate(output_files):
            conditions = []
            
            # Procurar padrões de escrita para este arquivo
            for line_num, line in enumerate(lines, 1):
                if line.strip().startswith('*'):
                    continue
                
                # Verificar se linha contém WRITE para este arquivo
                write_match = self.write_pattern.search(line)
                if write_match and output_file in line.upper():
                    # Procurar condições que levam a esta escrita
                    preceding_conditions = self._find_preceding_conditions(lines, line_num)
                    conditions.extend(preceding_conditions)
            
            # Criar regra de roteamento se condições foram encontradas
            if conditions:
                description = self._generate_routing_description(output_file, conditions)
                
                rule = FileRoutingRule(
                    output_file=output_file,
                    conditions=conditions,
                    priority=file_idx + 1,
                    description=description
                )
                routing_rules.append(rule)
                
                self.logger.debug(f"Regra de roteamento: {output_file} com {len(conditions)} condições")
        
        # Se não encontrou regras específicas, criar regras baseadas em padrões comuns
        if not routing_rules and len(output_files) >= 2:
            routing_rules = self._infer_routing_rules(output_files, lines)
        
        return routing_rules
    
    def _find_preceding_conditions(self, lines: List[str], write_line: int) -> List[DecisionCondition]:
        """Encontra condições que precedem uma operação de escrita"""
        conditions = []
        
        # Procurar nas 10 linhas anteriores
        start_line = max(0, write_line - 10)
        
        for i in range(start_line, write_line):
            line = lines[i]
            
            # Verificar condições IF
            if_matches = self.if_pattern.findall(line)
            for match in if_matches:
                field_name, operator, value = match
                
                condition = DecisionCondition(
                    condition_type=DecisionType.FILE_ROUTING,
                    field_name=field_name,
                    operator=self.operators.get(operator.upper(), operator.upper()),
                    value=value.strip('\'"'),
                    line_number=i + 1,
                    context=line.strip(),
                    action_true=f"WRITE to output file"
                )
                conditions.append(condition)
        
        return conditions
    
    def _infer_routing_rules(self, output_files: List[str], lines: List[str]) -> List[FileRoutingRule]:
        """Infere regras de roteamento baseadas em padrões comuns"""
        routing_rules = []
        
        # Padrão comum: primeiro arquivo para registros válidos, segundo para inválidos
        if len(output_files) >= 2:
            # Regra para arquivo válido (primeiro)
            valid_rule = FileRoutingRule(
                output_file=output_files[0],
                conditions=[
                    DecisionCondition(
                        condition_type=DecisionType.FILE_ROUTING,
                        field_name="VALIDATION_STATUS",
                        operator="EQUAL",
                        value="VALID",
                        line_number=0,
                        context="Inferido: registros que passam nas validações",
                        action_true="Write to valid records file"
                    )
                ],
                priority=1,
                description="Registros válidos que passaram em todas as validações"
            )
            routing_rules.append(valid_rule)
            
            # Regra para arquivo inválido (segundo)
            invalid_rule = FileRoutingRule(
                output_file=output_files[1],
                conditions=[
                    DecisionCondition(
                        condition_type=DecisionType.FILE_ROUTING,
                        field_name="VALIDATION_STATUS",
                        operator="EQUAL",
                        value="INVALID",
                        line_number=0,
                        context="Inferido: registros que falharam nas validações",
                        action_true="Write to invalid records file"
                    )
                ],
                priority=2,
                description="Registros inválidos que falharam nas validações"
            )
            routing_rules.append(invalid_rule)
        
        return routing_rules
    
    def _extract_action_from_context(self, lines: List[str], line_num: int) -> str:
        """Extrai a ação executada baseada no contexto"""
        # Procurar nas próximas 5 linhas
        end_line = min(line_num + 5, len(lines))
        
        for i in range(line_num, end_line):
            line = lines[i].strip().upper()
            
            if 'WRITE' in line:
                return "Write record to output file"
            elif 'MOVE' in line:
                return "Move data to field"
            elif 'ADD' in line:
                return "Add to counter/accumulator"
            elif 'PERFORM' in line:
                return "Execute subroutine"
            elif 'DISPLAY' in line:
                return "Display message/error"
            elif 'REJECT' in line or 'ERROR' in line:
                return "Reject record"
        
        return "Execute conditional logic"
    
    def _generate_routing_description(self, output_file: str, conditions: List[DecisionCondition]) -> str:
        """Gera descrição da regra de roteamento"""
        if not conditions:
            return f"Records routed to {output_file}"
        
        condition_descriptions = []
        for condition in conditions:
            desc = f"{condition.field_name} {condition.operator} {condition.value}"
            condition_descriptions.append(desc)
        
        return f"Records where {' AND '.join(condition_descriptions)} are routed to {output_file}"
    
    def _calculate_decision_complexity(self, conditions: List[DecisionCondition]) -> int:
        """Calcula score de complexidade das decisões"""
        complexity = 0
        
        # Contar diferentes tipos de decisões
        decision_types = set()
        fields_involved = set()
        
        for condition in conditions:
            decision_types.add(condition.condition_type)
            fields_involved.add(condition.field_name)
            
            # Peso por tipo de decisão
            if condition.condition_type == DecisionType.IF_CONDITION:
                complexity += 1
            elif condition.condition_type == DecisionType.EVALUATE_WHEN:
                complexity += 2
            elif condition.condition_type == DecisionType.VALIDATION_RULE:
                complexity += 1
            elif condition.condition_type == DecisionType.FILE_ROUTING:
                complexity += 3
        
        # Bônus por diversidade
        complexity += len(decision_types) * 2
        complexity += len(fields_involved)
        
        return complexity
    
    def _build_decision_tree(self, routing_rules: List[FileRoutingRule], 
                           validations: List[DecisionCondition]) -> Dict[str, Any]:
        """Constrói árvore de decisão estruturada"""
        tree = {
            "root": "START",
            "validations": {},
            "routing": {},
            "flow": []
        }
        
        # Adicionar validações
        for validation in validations:
            tree["validations"][validation.field_name] = {
                "condition": f"{validation.operator} {validation.value}",
                "action_true": validation.action_true,
                "action_false": validation.action_false or "Continue processing"
            }
        
        # Adicionar roteamento
        for rule in routing_rules:
            tree["routing"][rule.output_file] = {
                "conditions": [
                    f"{c.field_name} {c.operator} {c.value}" 
                    for c in rule.conditions
                ],
                "description": rule.description,
                "priority": rule.priority
            }
        
        # Definir fluxo geral
        tree["flow"] = [
            "1. Read input record",
            "2. Apply validation rules",
            "3. Determine routing based on conditions",
            "4. Write to appropriate output file",
            "5. Continue with next record"
        ]
        
        return tree
    
    def generate_decision_documentation(self, analysis: DecisionLogicAnalysis) -> str:
        """Gera documentação formatada da lógica de decisão"""
        doc = "## Lógica de Decisão e Roteamento\n\n"
        
        # Resumo de complexidade
        doc += f"**Complexidade de Decisão:** {analysis.complexity_score} pontos\n\n"
        
        # Regras de roteamento
        if analysis.routing_rules:
            doc += "### Regras de Roteamento de Arquivos\n\n"
            
            for rule in analysis.routing_rules:
                doc += f"#### {rule.output_file} (Prioridade: {rule.priority})\n"
                doc += f"**Descrição:** {rule.description}\n\n"
                
                if rule.conditions:
                    doc += "**Condições:**\n"
                    for condition in rule.conditions:
                        doc += f"- `{condition.field_name} {condition.operator} {condition.value}`\n"
                    doc += "\n"
        
        # Validações
        if analysis.validation_conditions:
            doc += "### Regras de Validação\n\n"
            doc += "| Campo | Validação | Ação se Verdadeiro | Linha |\n"
            doc += "|-------|-----------|-------------------|-------|\n"
            
            for validation in analysis.validation_conditions:
                doc += f"| {validation.field_name} | {validation.operator} | {validation.action_true} | {validation.line_number} |\n"
            
            doc += "\n"
        
        # Condições de negócio
        if analysis.business_logic_conditions:
            doc += "### Lógica de Negócio\n\n"
            doc += "| Campo | Operador | Valor | Ação | Linha |\n"
            doc += "|-------|----------|-------|------|-------|\n"
            
            for condition in analysis.business_logic_conditions:
                doc += f"| {condition.field_name} | {condition.operator} | {condition.value} | {condition.action_true} | {condition.line_number} |\n"
            
            doc += "\n"
        
        # Árvore de decisão
        if analysis.decision_tree:
            doc += "### Fluxo de Decisão\n\n"
            doc += "```\n"
            for step in analysis.decision_tree.get("flow", []):
                doc += f"{step}\n"
            doc += "```\n\n"
        
        return doc
