import os
import requests

def get_token(client_id, client_secret):
    url = "https://luzia.com.br/api/v1/auth/token"
    payload = {
        "grant_type": "client_credentials",
        "client_id": client_id,
        "client_secret": client_secret
    }
    response = requests.post(url, json=payload, verify=False)
    if response.status_code == 200:
        return response.json().get("access_token")
    else:
        print(f"Erro na autenticação: {response.status_code} - {response.text}")
        return None

def send_message(token, client_id, message):
    url = "https://luzia.com.br/api/v1/chat/send"
    headers = {
        "Authorization": f"Bearer {token}"
    }
    payload = {
        "prompt_type": "application/json-for-structured",
        "client_id": client_id,
        "text_server": message
    }
    response = requests.post(url, headers=headers, json=payload, verify=False)
    if response.status_code == 200:
        return response.json()
    else:
        print(f"Erro ao enviar mensagem: {response.status_code} - {response.text}")
        return None

if __name__ == "__main__":
    client_id = os.getenv("LUZIA_CLIENT_ID", "VISITOR-CHAT-FLOW-SALE-7d7e6f1156")
    client_secret = os.getenv("LUZIA_CLIENT_SECRET")

    if not client_secret:
        print("A variável de ambiente LUZIA_CLIENT_SECRET não está definida.")
    else:
        token = get_token(client_id, client_secret)
        if token:
            print("Token obtido com sucesso!")
            
            # Mensagem de teste
            test_message = "Olá, mundo!"
            
            print(f"Enviando mensagem: {test_message}")
            response = send_message(token, client_id, test_message)
            
            if response:
                print("Resposta recebida:")
                print(response)
            else:
                print("Falha ao receber resposta.")
        else:
            print("Falha ao obter token.")

