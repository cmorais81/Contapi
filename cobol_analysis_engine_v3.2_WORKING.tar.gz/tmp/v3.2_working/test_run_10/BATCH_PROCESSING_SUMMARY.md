# Resumo do Processamento em Lote

- **Total de Programas:** 1
- **Sucesso:** 0
- **Falha:** 1

| Programa | Status | Detalhes |
|---|---|---|
| LHAN0542 | error | Erro ao processar LHAN0542: f-string: unmatched '[' (intelligent_documentation_generator.py, line 295) |
