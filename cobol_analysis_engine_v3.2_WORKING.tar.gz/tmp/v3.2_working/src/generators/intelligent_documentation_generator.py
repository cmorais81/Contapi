# -*- coding: utf-8 -*-
"""
Gerador de documentação inteligente que produz relatórios de alta qualidade
Baseado no padrão do arquivo LHAN0542_DOCUMENTACAO_COMPLETA.md
"""

import time
import re
from typing import Dict, Any, List, Optional

class IntelligentDocumentationGenerator:
    """Gerador que produz documentação de alta qualidade mesmo sem IA"""
    
    def __init__(self):
        self.prompt_history = []
        self.statistics = {}
    
    def generate_documentation(
        self, 
        extracted_data: Dict[str, Any], 
        ai_analyses: Dict[str, Any] = None,
        prompt_history: List[Dict] = None,
        statistics: Dict[str, Any] = None,
        output_path: str = ""
    ) -> str:
        """Gera documentação inteligente de alta qualidade"""
        
        if prompt_history:
            self.prompt_history = prompt_history
        
        if statistics:
            self.statistics = statistics
        
        program_name = extracted_data.get("program_name", "PROGRAMA_DESCONHECIDO")
        
        # Analisar código COBOL para extrair informações
        cobol_analysis = self._analyze_cobol_code(extracted_data.get("content", ""))
        
        # Construir documentação
        doc = self._build_header(program_name, extracted_data)
        doc += self._build_executive_summary(program_name, cobol_analysis, extracted_data)
        doc += self._build_functional_analysis(cobol_analysis, extracted_data)
        doc += self._build_technical_structure(cobol_analysis, extracted_data)
        doc += self._build_business_rules(cobol_analysis, extracted_data)
        doc += self._build_processing_flow(cobol_analysis, extracted_data)
        doc += self._build_technical_aspects(cobol_analysis, extracted_data)
        doc += self._build_metrics_monitoring(cobol_analysis, extracted_data)
        doc += self._build_maintenance_evolution(cobol_analysis, extracted_data)
        
        # Incluir análise de IA se disponível
        if ai_analyses and ai_analyses.get("main_analysis"):
            doc += self._build_ai_enhancement_section(ai_analyses)
        
        # Incluir transparência de prompts
        doc += self._build_prompts_section()

        # Salvar arquivo
        if output_path:
            with open(output_path, "w", encoding="utf-8") as f:
                f.write(doc)
        
        return doc

    def _build_prompts_section(self) -> str:
        """Constrói a seção de transparência de prompts."""
        section = "\n\n---\n\n##  Transparência de Análise\n"

        if self.prompt_history:
            for i, entry in enumerate(self.prompt_history, 1):
                section += f"\n### Interação {i} - {entry.get('provider', 'N/A')}\n"
                section += f"\n**Status**: {'Sucesso' if entry.get('success') else 'Falha'}\n"
                section += f"**Tempo**: {entry.get('processing_time', 0.0):.2f}s\n"
                section += "\n**Prompt enviado**:\n```\n"
                section += entry.get("prompt", "")
                section += "\n```\n"
                section += "\n**Resposta do LUZIA**:\n```\n"
                section += entry.get("response", "")
                section += "\n```\n"
        else:
            section += "\nNenhuma interação com IA registrada.\n"

        return section
    
    def _analyze_cobol_code(self, cobol_code: str) -> Dict[str, Any]:
        """Analisa código COBOL para extrair informações estruturais"""
        
        analysis = {
            "program_id": "",
            "author": "",
            "date_written": "",
            "objective": "",
            "files": {"input": [], "output": []},
            "working_storage": [],
            "procedures": [],
            "copybooks": [],
            "comments": [],
            "business_logic": [],
            "file_operations": [],
            "calculations": [],
            "validations": []
        }
        
        lines = cobol_code.split("\n")
        current_division = ""
        current_section = ""
        
        for line in lines:
            line_clean = line.strip()
            line_upper = line_clean.upper()
            
            # Identificar divisões
            if "DIVISION" in line_upper:
                if "IDENTIFICATION" in line_upper:
                    current_division = "IDENTIFICATION"
                elif "ENVIRONMENT" in line_upper:
                    current_division = "ENVIRONMENT"
                elif "DATA" in line_upper:
                    current_division = "DATA"
                elif "PROCEDURE" in line_upper:
                    current_division = "PROCEDURE"
            
            # Extrair informações básicas
            if current_division == "IDENTIFICATION":
                if line_upper.startswith("PROGRAM-ID"):
                    analysis["program_id"] = self._extract_value(line)
                elif line_upper.startswith("AUTHOR"):
                    analysis["author"] = self._extract_value(line)
                elif line_upper.startswith("DATE-WRITTEN"):
                    analysis["date_written"] = self._extract_value(line)
            
            # Comentários e objetivos
            if line_clean.startswith("*"):
                comment = line_clean[1:].strip()
                if comment and len(comment) > 5:
                    analysis["comments"].append(comment)
                    if "OBJETIVO" in comment.upper() or "PURPOSE" in comment.upper():
                        analysis["objective"] = comment
            
            # Arquivos
            if "SELECT" in line_upper and "ASSIGN" in line_upper:
                file_info = self._extract_file_info(line)
                if file_info:
                    if "E" in file_info["name"] or "INPUT" in file_info["name"]:
                        analysis["files"]["input"].append(file_info)
                    else:
                        analysis["files"]["output"].append(file_info)
            
            # Working Storage
            if current_division == "DATA" and ("01 " in line or "03 " in line or "05 " in line):
                ws_item = self._extract_working_storage_item(line)
                if ws_item:
                    analysis["working_storage"].append(ws_item)
            
            # Copybooks
            if "COPY" in line_upper:
                copybook = self._extract_copybook(line)
                if copybook:
                    analysis["copybooks"].append(copybook)
            
            # Lógica de negócio
            if current_division == "PROCEDURE":
                if any(keyword in line_upper for keyword in ["IF", "WHEN", "EVALUATE"]):
                    analysis["business_logic"].append(line_clean)
                elif any(keyword in line_upper for keyword in ["READ", "WRITE", "OPEN", "CLOSE"]):
                    analysis["file_operations"].append(line_clean)
                elif any(keyword in line_upper for keyword in ["COMPUTE", "ADD", "SUBTRACT", "MULTIPLY", "DIVIDE"]):
                    analysis["calculations"].append(line_clean)
                elif any(keyword in line_upper for keyword in ["VALIDATE", "CHECK", "VERIFY"]):
                    analysis["validations"].append(line_clean)
        
        return analysis
    
    def _extract_value(self, line: str) -> str:
        """Extrai valor após o ponto"""
        if "." in line:
            return line.split(".", 1)[1].strip()
        return ""
    
    def _extract_file_info(self, line: str) -> Optional[Dict[str, str]]:
        """Extrai informações de arquivo"""
        match = re.search(r"SELECT\s+(\S+)\s+ASSIGN\s+TO\s+(\S+)", line.upper())
        if match:
            return {
                "name": match.group(1),
                "assignment": match.group(2),
                "type": "INPUT" if "E" in match.group(1) else "OUTPUT"
            }
        return None
    
    def _extract_working_storage_item(self, line: str) -> Optional[Dict[str, str]]:
        """Extrai item do Working Storage"""
        match = re.search(r"(\d+)\s+(\S+)(?:\s+PIC\s+(\S+))?", line)
        if match:
            return {
                "level": match.group(1),
                "name": match.group(2),
                "picture": match.group(3) if match.group(3) else ""
            }
        return None
    
    def _extract_copybook(self, line: str) -> Optional[str]:
        """Extrai nome do copybook"""
        match = re.search(r"COPY\s+(\S+)", line.upper())
        if match:
            return match.group(1)
        return None
    
    def _build_header(self, program_name: str, extracted_data: Dict[str, Any]) -> str:
        """Constrói cabeçalho profissional"""
        
        timestamp = time.strftime("%d/%m/%Y %H:%M:%S")
        
        return f"""# Documentação Técnica Completa: {program_name}

**Programa**: {program_name}  
**Autor**: {extracted_data.get("author", "N/A")}  
**Data de Criação**: {extracted_data.get("date_written", "N/A")}  
**Gerado por**: Sistema de Análise COBOL v2.0  
**Data de Análise**: {timestamp}  

---

"""
    
    def _build_executive_summary(self, program_name: str, analysis: Dict[str, Any], extracted_data: Dict[str, Any]) -> str:
        """Constrói resumo executivo inteligente"""
        
        section = "##  Resumo Executivo\n\n"
        
        # Determinar objetivo baseado na análise
        objective = analysis.get("objective", "")
        if not objective and analysis["comments"]:
            # Procurar por comentários que indiquem objetivo
            for comment in analysis["comments"]:
                if any(word in comment.upper() for word in ["OBJETIVO", "FINALIDADE", "PROPÓSITO", "FUNÇÃO"]):
                    objective = comment
                    break
        
        if not objective:
            objective = f"Programa {program_name} - Processamento de dados COBOL"
        
        section += f"O programa {program_name} é uma solução para {objective.lower()}. "
        
        # Análise de complexidade baseada nos arquivos
        input_files = len(analysis["files"]["input"])
        output_files = len(analysis["files"]["output"])
        copybooks = len(analysis["copybooks"])
        
        if input_files > 3 or output_files > 2:
            section += "Trata-se de um sistema de alta complexidade que processa múltiplos arquivos de entrada "
            section += f"({input_files} arquivos de input) e gera {output_files} arquivos de saída.\n\n"
        else:
            section += f"O sistema processa {input_files} arquivo(s) de entrada e gera {output_files} arquivo(s) de saída.\n\n"
        
        section += "### Impacto no Negócio\n"
        
        # Determinar criticidade baseada na análise
        if copybooks > 5:
            section += "- **Criticidade**: Sistema de alta criticidade com múltiplas integrações\n"
        elif copybooks > 2:
            section += "- **Criticidade**: Sistema de criticidade média com integrações importantes\n"
        else:
            section += "- **Criticidade**: Sistema de processamento padrão\n"
        
        section += f"- **Integrações**: {copybooks} copybooks utilizados\n"
        section += f"- **Arquivos processados**: {input_files + output_files} arquivos no total\n"
        
        # Análise de operações
        if analysis["calculations"]:
            section += "- **Tipo de processamento**: Inclui cálculos e transformações de dados\n"
        if analysis["validations"]:
            section += "- **Controle de qualidade**: Implementa validações de dados\n"
        
        section += "\n---\n\n"
        return section
    
    def _build_functional_analysis(self, analysis: Dict[str, Any], extracted_data: Dict[str, Any]) -> str:
        """Constrói análise funcional detalhada"""
        
        section = "##  Análise Funcional\n\n"
        
        # Objetivo principal
        objective = analysis.get("objective", "Processamento de dados COBOL")
        section += f"### Objetivo Principal\n{objective}\n\n"
        
        section += "### Funcionalidades Principais\n\n"
        
        # Analisar funcionalidades baseadas nos arquivos e operações
        func_count = 1
        
        if analysis["files"]["input"]:
            section += f"#### {func_count}. **Processamento de Dados de Entrada**\n"
            section += "- Leitura e validação de arquivos de entrada:\n"
            for file_info in analysis["files"]["input"]:
                section += f"  - **{file_info['name']}**: {file_info['assignment']}\n"
            section += "\n"
            func_count += 1
        
        if analysis["calculations"]:
            section += f"#### {func_count}. **Processamento e Cálculos**\n"
            section += "- Execução de cálculos e transformações de dados\n"
            section += f"- {len(analysis['calculations'])} operações matemáticas identificadas\n\n"
            func_count += 1
        
        if analysis["validations"]:
            section += f"#### {func_count}. **Controle de Qualidade**\n"
            section += "- Validação de integridade dos dados\n"
            section += f"- {len(analysis['validations'])} validações implementadas\n\n"
            func_count += 1
        
        if analysis["files"]["output"]:
            section += f"#### {func_count}. **Geração de Saídas**\n"
            section += "- Criação de arquivos de resultado:\n"
            for file_info in analysis["files"]["output"]:
                section += f"  - **{file_info['name']}**: {file_info['assignment']}\n"
            section += "\n"
        
        section += "---\n\n"
        return section
    
    def _build_technical_structure(self, analysis: Dict[str, Any], extracted_data: Dict[str, Any]) -> str:
        """Constrói estrutura técnica"""
        
        section = "##  Estrutura Técnica\n\n"
        
        # Arquivos de entrada
        if analysis["files"]["input"]:
            section += "### Arquivos de Entrada\n"
            for i, file_info in enumerate(analysis["files"]["input"], 1):
                section += f"{i}. **{file_info['name']}**: {file_info['assignment']}\n"
            section += "\n"
        
        # Arquivos de saída
        if analysis["files"]["output"]:
            section += "### Arquivos de Saída\n"
            for i, file_info in enumerate(analysis["files"]["output"], 1):
                section += f"{i}. **{file_info['name']}**: {file_info['assignment']}\n"
            section += "\n"
        
        # Working Storage principal
        if analysis["working_storage"]:
            section += "### Componentes Principais\n\n"
            section += "#### Working Storage\n"
            section += "```cobol\n"
            
            # Mostrar os primeiros itens mais importantes
            for ws_item in analysis["working_storage"][:10]:
                if ws_item["picture"]:
                    section += f"{ws_item['level'].rjust(2)} {ws_item['name'].ljust(30)} PIC {ws_item['picture']}\n"
                else:
                    section += f"{ws_item['level'].rjust(2)} {ws_item['name']}\n"
            
            if len(analysis["working_storage"]) > 10:
                section += f"   ... e mais {len(analysis['working_storage']) - 10} campos\n"
            
            section += "```\n\n"
        
        # Copybooks
        if analysis["copybooks"]:
            section += "#### Copybooks Utilizados\n"
            for copybook in analysis["copybooks"]:
                section += f"- **{copybook}**: Estruturas de dados compartilhadas\n"
            section += "\n"
        
        section += "---\n\n"
        return section
    
    def _build_business_rules(self, analysis: Dict[str, Any], extracted_data: Dict[str, Any]) -> str:
        """Constrói regras de negócio"""
        
        section = "##  Regras de Negócio\n\n"
        
        # Analisar lógica de negócio
        if analysis["business_logic"]:
            section += "### Regras Identificadas\n\n"
            section += "| Tipo | Descrição | Implementação |\n"
            section += "|------|-----------|---------------|\n"
            
            for i, logic in enumerate(analysis["business_logic"][:5], 1):
                logic_type = "Condicional" if "IF" in logic.upper() else "Avaliação"
                section += f"| {logic_type} | Regra {i} | `{logic[:50]}...` |\n"
            
            section += "\n"
        
        # Validações
        if analysis["validations"]:
            section += "### Validações Implementadas\n"
            for i, validation in enumerate(analysis["validations"][:5], 1):
                section += f"{i}. **Validação {i}**: {validation[:60]}...\n"
            section += "\n"
        
        # Cálculos
        if analysis["calculations"]:
            section += "### Cálculos e Transformações\n"
            for i, calc in enumerate(analysis["calculations"][:5], 1):
                section += f"{i}. **Operação {i}**: {calc[:60]}...\n"
            section += "\n"
        
        section += "---\n\n"
        return section
    
    def _build_processing_flow(self, analysis: Dict[str, Any], extracted_data: Dict[str, Any]) -> str:
        """Constrói fluxo de processamento"""
        
        section = "##  Fluxo de Processamento\n\n"
        
        section += "### Fase 1: Inicialização\n"
        section += "1. **Abertura de Arquivos**\n"
        section += "   - Inicialização de variáveis de controle\n\n"
        
        section += "### Fase 2: Processamento Principal\n"
        section += "1. **Leitura de Dados**\n"
        section += "   - Processamento sequencial dos registros\n\n"
        
        section += "### Fase 3: Finalização\n"
        section += "1. **Geração de Resultados**\n"
        section += "   - Gravação dos dados processados\n"
        section += "   - Fechamento de arquivos\n"
        section += "   - Retorno de códigos de status\n\n"
        
        section += "---\n\n"
        return section
    
    def _build_technical_aspects(self, analysis: Dict[str, Any], extracted_data: Dict[str, Any]) -> str:
        """Constrói aspectos técnicos"""
        
        section = "##  Aspectos Técnicos\n\n"
        
        section += "### Performance\n"
        section += "- **Processamento**: Otimizado para processamento sequencial\n"
        section += "- **Memória**: Uso eficiente através de Working Storage estruturado\n\n"
        
        section += "### Manutenibilidade\n"
        section += f"- **Estrutura**: {len(analysis['working_storage'])} campos no Working Storage\n"
        section += "- **Documentação**: Comentários inline para facilitar manutenção\n\n"
        
        section += "### Integração\n"
        section += f"- **Arquivos**: {len(analysis['files']['input']) + len(analysis['files']['output'])} interfaces de dados\n"
        
        section += "\n---\n\n"
        return section
    
    def _build_metrics_monitoring(self, analysis: Dict[str, Any], extracted_data: Dict[str, Any]) -> str:
        """Constrói métricas e monitoramento"""
        
        section = "##  Métricas e Monitoramento\n\n"
        
        section += "### Indicadores de Performance\n"
        section += "- **Throughput**: Dependente do volume de dados de entrada\n"
        section += "- **Utilização de CPU**: Processamento sequencial otimizado\n\n"
        
        section += "### Pontos de Controle\n"
        section += "- Verificação de integridade de dados\n"
        section += "- Controle de códigos de retorno\n\n"
        
        section += "---\n\n"
        return section
    
    def _build_maintenance_evolution(self, analysis: Dict[str, Any], extracted_data: Dict[str, Any]) -> str:
        """Constrói manutenção e evolução"""
        
        section = "##  Manutenção e Evolução\n\n"
        
        section += "### Pontos de Atenção\n"
        section += "1. **Estrutura de dados**: Revisar periodicamente\n"
        section += "2. **Validação de dados**: Manter critérios atualizados\n"
        section += "3. **Performance**: Monitorar com crescimento de volume\n\n"
        
        section += "### Recomendações\n"
        section += "- **Monitoramento**: Implementar alertas de performance\n"
        section += "- **Documentação**: Manter comentários atualizados\n"
        section += "- **Testes**: Validar cenários de erro e volume\n"
        section += "- **Validações**: Considerar implementar mais validações de dados\n\n"
        
        section += "---\n\n"
        return section
    
    def _build_ai_enhancement_section(self, ai_analyses: Dict[str, Any]) -> str:
        """Constrói seção de análise enriquecida por IA"""
        
        section = "##  Análise Enriquecida por IA\n\n"
        
        main_analysis = ai_analyses.get("main_analysis", {})
        
        section += "### Objetivo Identificado pela IA\n"
        section += main_analysis.get("objective", "Análise do programa LHAN0542 realizada com base na estrutura do código COBOL") + "\n\n"
        
        section += "### Regras de Negócio (IA)\n"
        business_rules = main_analysis.get("business_rules", ["Análise de regras de negócio requer configuração de IA"])
        for rule in business_rules:
            section += f"- {rule}\n"
        section += "\n"
        
        section += "### Análise Técnica (IA)\n"
        technical_analysis = main_analysis.get("technical_analysis", ["Análise técnica detalhada requer configuração de IA"])
        for item in technical_analysis:
            section += f"- {item}\n"
        section += "\n"
        
        section += "---\n\n"
        return section

