import logging
from typing import Dict, Any

class DetailedReportGenerator:
    def __init__(self):
        self.logger = logging.getLogger(self.__class__.__name__)

    def generate(self, program_data: Dict[str, Any], ai_analysis: Dict[str, Any]) -> str:
        """Gera relatório detalhado baseado na análise multi-AI."""
        report_parts = []
        report_parts.append(self._generate_header(program_data))
        report_parts.append(self._generate_executive_summary(ai_analysis))
        report_parts.append(self._generate_structural_analysis(ai_analysis))
        report_parts.append(self._generate_business_analysis(ai_analysis))
        report_parts.append(self._generate_technical_analysis(ai_analysis))
        report_parts.append(self._generate_data_model_analysis(ai_analysis))
        report_parts.append(self._generate_quality_analysis(ai_analysis))
        report_parts.append(self._generate_analysis_summary(ai_analysis))
        return "\n".join(report_parts)

    def _generate_header(self, program_data: Dict[str, Any]) -> str:
        """Gera cabeçalho do relatório."""
        program_name = program_data.get('program_name', program_data.get('name', 'N/A'))
        metadata = program_data.get('metadata', {})
        author = metadata.get('author', program_data.get('author', 'N/A'))
        date_written = metadata.get('date_written', program_data.get('date_written', 'N/A'))
        
        header = f"""# Análise Detalhada do Programa: {program_name}

**Autor:** {author}  
**Data de Criação:** {date_written}  
**Tipo:** Programa COBOL  

---
"""
        return header

    def _generate_executive_summary(self, ai_analysis: Dict[str, Any]) -> str:
        """Gera resumo executivo da análise."""
        summary_parts = ["## Resumo Executivo\n"]
        
        # Contar análises bem-sucedidas
        successful_analyses = []
        failed_analyses = []
        
        for domain, analysis in ai_analysis.items():
            if isinstance(analysis, dict):
                if analysis.get('error'):
                    failed_analyses.append(domain)
                else:
                    successful_analyses.append(domain)
        
        summary_parts.append(f"**Análises Realizadas:** {len(successful_analyses)} de {len(ai_analysis)} domínios")
        summary_parts.append(f"**Domínios Analisados com Sucesso:** {', '.join(successful_analyses)}")
        
        if failed_analyses:
            summary_parts.append(f"**Domínios com Falha:** {', '.join(failed_analyses)}")
        
        return "\n".join(summary_parts) + "\n"

    def _generate_structural_analysis(self, ai_analysis: Dict[str, Any]) -> str:
        """Gera análise estrutural."""
        structural_parts = ["## Análise Estrutural\n"]
        structural_data = ai_analysis.get("structural", {})
        
        if structural_data.get('error'):
            structural_parts.append(f"**Erro:** {structural_data['error']}\n")
            return "\n".join(structural_parts)
        
        analysis = structural_data
        
        # Pontuação de organização
        org_score = analysis.get('organization_score', 'N/A')
        structural_parts.append(f"**Pontuação de Organização:** {org_score}/100\n")
        
        # Resumo estrutural
        summary = analysis.get('summary', 'Análise estrutural não disponível.')
        structural_parts.append(f"**Resumo:** {summary}\n")
        
        # Recomendações
        recommendations = analysis.get('recommendations', [])
        if recommendations:
            structural_parts.append("**Recomendações Estruturais:**")
            for rec in recommendations:
                structural_parts.append(f"- {rec}")
        
        return "\n".join(structural_parts) + "\n"

    def _generate_business_analysis(self, ai_analysis: Dict[str, Any]) -> str:
        """Gera análise de negócio."""
        business_parts = ["## Análise de Regras de Negócio\n"]
        business_data = ai_analysis.get("business", {})
        
        if business_data.get('error'):
            business_parts.append(f"**Erro:** {business_data['error']}\n")
            return "\n".join(business_parts)
        
        analysis = business_data
        
        # Objetivo do programa
        objective = analysis.get('business_objective', 'Não especificado.')
        business_parts.append(f"**Objetivo do Programa:** {objective}\n")
        
        # Regras de negócio
        business_rules = analysis.get('business_rules', [])
        if business_rules:
            business_parts.append("**Regras de Negócio Identificadas:**")
            for rule in business_rules:
                business_parts.append(f"- {rule}")
        else:
            business_parts.append("**Regras de Negócio:** Nenhuma regra específica identificada.")
        
        # Fluxo de processamento
        process_flow = analysis.get('process_flow', '')
        if process_flow:
            business_parts.append(f"\n**Fluxo de Processamento:** {process_flow}")
        
        return "\n".join(business_parts) + "\n"

    def _generate_technical_analysis(self, ai_analysis: Dict[str, Any]) -> str:
        """Gera análise técnica."""
        technical_parts = ["## Análise Técnica\n"]
        technical_data = ai_analysis.get("technical", {})
        
        if technical_data.get('error'):
            technical_parts.append(f"**Erro:** {technical_data['error']}\n")
            return "\n".join(technical_parts)
        
        analysis = technical_data
        
        # Qualidade da implementação
        impl_quality = analysis.get('implementation_quality', 'N/A')
        technical_parts.append(f"**Qualidade da Implementação:** {impl_quality}\n")
        
        # Aspectos de performance
        performance = analysis.get('performance_aspects', [])
        if performance:
            technical_parts.append("**Aspectos de Performance:**")
            for aspect in performance:
                technical_parts.append(f"- {aspect}")
        
        # Tratamento de erros
        error_handling = analysis.get('error_handling', 'N/A')
        technical_parts.append(f"\n**Tratamento de Erros:** {error_handling}")
        
        return "\n".join(technical_parts) + "\n"

    def _generate_data_model_analysis(self, ai_analysis: Dict[str, Any]) -> str:
        """Gera análise do modelo de dados."""
        data_parts = ["## Análise do Modelo de Dados\n"]
        data_model_data = ai_analysis.get("data_model", {})
        
        if data_model_data.get('error'):
            data_parts.append(f"**Erro:** {data_model_data['error']}\n")
            return "\n".join(data_parts)
        
        analysis = data_model_data
        
        # Estruturas de dados
        data_structures = analysis.get('data_structures', [])
        if data_structures:
            data_parts.append("**Estruturas de Dados:**")
            for structure in data_structures:
                data_parts.append(f"- {structure}")
        else:
            data_parts.append("**Estruturas de Dados:** Nenhuma estrutura específica identificada.")
        
        # Definições de arquivos
        file_definitions = analysis.get('file_definitions', [])
        if file_definitions:
            data_parts.append("\n**Definições de Arquivos:**")
            for file_def in file_definitions:
                data_parts.append(f"- {file_def}")
        
        return "\n".join(data_parts) + "\n"

    def _generate_quality_analysis(self, ai_analysis: Dict[str, Any]) -> str:
        """Gera análise de qualidade."""
        quality_parts = ["## Análise de Qualidade\n"]
        quality_data = ai_analysis.get("quality", {})
        
        if quality_data.get('error'):
            quality_parts.append(f"**Erro:** {quality_data['error']}\n")
            return "\n".join(quality_parts)
        
        analysis = quality_data
        
        # Pontuação de qualidade
        quality_score = analysis.get('quality_score', 'N/A')
        quality_parts.append(f"**Pontuação de Qualidade:** {quality_score}/100\n")
        
        # Aderência a padrões
        standards = analysis.get('standards_compliance', 'N/A')
        quality_parts.append(f"**Aderência a Padrões:** {standards}\n")
        
        # Manutenibilidade
        maintainability = analysis.get('maintainability', 'N/A')
        quality_parts.append(f"**Manutenibilidade:** {maintainability}\n")
        
        # Oportunidades de melhoria
        improvements = analysis.get('improvement_opportunities', [])
        if improvements:
            quality_parts.append("**Oportunidades de Melhoria:**")
            for improvement in improvements:
                quality_parts.append(f"- {improvement}")
        
        return "\n".join(quality_parts) + "\n"

    def _generate_analysis_summary(self, ai_analysis: Dict[str, Any]) -> str:
        """Gera resumo final da análise."""
        summary_parts = ["## Resumo da Análise\n"]
        
        # Contar sucessos e falhas
        total_analyses = len(ai_analysis)
        successful_count = sum(1 for analysis in ai_analysis.values() 
                             if isinstance(analysis, dict) and not analysis.get('error'))
        
        summary_parts.append(f"**Total de Análises:** {total_analyses}")
        summary_parts.append(f"**Análises Bem-sucedidas:** {successful_count}")
        
        if total_analyses > 0:
            success_rate = (successful_count/total_analyses)*100
        else:
            success_rate = 0.0
        
        summary_parts.append(f"**Taxa de Sucesso:** {success_rate:.1f}%\n")
        
        # Principais insights
        summary_parts.append("**Principais Insights:**")
        for domain, analysis in ai_analysis.items():
            if isinstance(analysis, dict) and not analysis.get('error'):
                domain_summary = analysis.get('summary', f'Análise {domain} concluída.')
                summary_parts.append(f"- **{domain.title()}:** {domain_summary[:200]}...")
        
        summary_parts.append("\n---")
        summary_parts.append("*Relatório gerado pelo Sistema de Análise COBOL Multi-AI*")
        
        return "\n".join(summary_parts)
