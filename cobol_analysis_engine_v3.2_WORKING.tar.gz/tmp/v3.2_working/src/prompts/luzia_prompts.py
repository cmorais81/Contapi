"""
Sistema de Prompts para LuzIA - COBOL Analysis Engine
Gera prompts contextualizados com informações de fontes.txt e BOOKS.txt
"""

from typing import Dict, List, Optional
import logging

class LuziaPromptGenerator:
    """Gerador de prompts contextualizados para análise COBOL com LuzIA"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
    
    def generate_enhanced_prompt(self, 
                               program_name: str,
                               cobol_code: str,
                               program_context: Dict,
                               copybooks: Optional[Dict] = None,
                               related_programs: Optional[List[str]] = None) -> str:
        """Gera prompt enriquecido com contexto completo"""
        
        prompt_sections = []
        
        # Cabeçalho do prompt
        prompt_sections.append(self._generate_header(program_name))
        
        # Contexto do programa
        prompt_sections.append(self._generate_program_context(program_context))
        
        # Informações de copybooks
        if copybooks:
            prompt_sections.append(self._generate_copybooks_context(copybooks))
        
        # Programas relacionados
        if related_programs:
            prompt_sections.append(self._generate_related_programs_context(related_programs))
        
        # Código COBOL
        prompt_sections.append(self._generate_code_section(cobol_code))
        
        # Instruções específicas
        prompt_sections.append(self._generate_analysis_instructions())
        
        return "\n\n".join(prompt_sections)
    
    def _generate_header(self, program_name: str) -> str:
        """Gera cabeçalho do prompt"""
        return f"""# Análise Funcional de Programa COBOL: {program_name}

Você é um especialista em análise de sistemas COBOL com foco em extrair e documentar a lógica de negócio. 
Sua tarefa é analisar o programa {program_name} e gerar uma documentação funcional completa."""
    
    def _generate_program_context(self, context: Dict) -> str:
        """Gera contexto do programa baseado em informações extraídas"""
        
        context_info = []
        context_info.append("## Contexto do Programa")
        
        if context.get('position_in_batch'):
            context_info.append(f"**Posição no Lote**: {context['position_in_batch']}")
        
        if context.get('file_size'):
            context_info.append(f"**Tamanho do Arquivo**: {context['file_size']} linhas")
        
        if context.get('creation_date'):
            context_info.append(f"**Data de Criação**: {context['creation_date']}")
        
        if context.get('last_modified'):
            context_info.append(f"**Última Modificação**: {context['last_modified']}")
        
        if context.get('system_context'):
            context_info.append(f"**Sistema**: {context['system_context']}")
        
        return "\n".join(context_info)
    
    def _generate_copybooks_context(self, copybooks: Dict) -> str:
        """Gera contexto dos copybooks disponíveis"""
        
        copybook_info = []
        copybook_info.append("## Copybooks Disponíveis")
        copybook_info.append("Os seguintes copybooks estão disponíveis no sistema e podem ser referenciados pelo programa:")
        
        for name, content in copybooks.items():
            # Extrair informações básicas do copybook
            lines_count = len(content.split('\n'))
            
            # Tentar identificar o tipo de copybook
            copybook_type = self._identify_copybook_type(content)
            
            copybook_info.append(f"- **{name}** ({lines_count} linhas) - {copybook_type}")
            
            # Extrair campos principais se for um layout de dados
            if 'layout' in copybook_type.lower():
                main_fields = self._extract_main_fields(content)
                if main_fields:
                    copybook_info.append(f"  Campos principais: {', '.join(main_fields[:5])}")
        
        return "\n".join(copybook_info)
    
    def _generate_related_programs_context(self, related_programs: List[str]) -> str:
        """Gera contexto de programas relacionados"""
        
        related_info = []
        related_info.append("## Programas Relacionados no Sistema")
        related_info.append("Os seguintes programas fazem parte do mesmo sistema:")
        
        for program in related_programs:
            related_info.append(f"- {program}")
        
        related_info.append("\nConsidere possíveis interações ou dependências entre estes programas.")
        
        return "\n".join(related_info)
    
    def _generate_code_section(self, cobol_code: str) -> str:
        """Gera seção com o código COBOL"""
        
        return f"""## Código COBOL para Análise

```cobol
{cobol_code}
```"""
    
    def _generate_analysis_instructions(self) -> str:
        """Gera instruções específicas para análise"""
        
        return """## Instruções para Análise

Analise o programa COBOL acima e forneça uma documentação funcional completa seguindo esta estrutura:

### 1. Objetivo do Programa
- Identifique o propósito principal do programa
- Extraia informações de comentários, nomes de seções e lógica do código
- Descreva o contexto de negócio

### 2. Regras de Negócio Críticas
- Identifique todas as validações (IF, WHEN, etc.)
- Documente critérios de roteamento de dados
- Liste controles de processamento e limites

### 3. Fluxo de Processamento
- Descreva o fluxo passo a passo
- Identifique entradas e saídas de cada etapa
- Mapeie transformações de dados

### 4. Arquivos e Estruturas de Dados
- Liste todos os arquivos processados
- Identifique campos-chave e relacionamentos
- Documente formatos e layouts

### 5. Análise de Performance
- Identifique possíveis gargalos
- Documente limites de processamento
- Sugira pontos de atenção

### 6. Dependências e Integrações
- Liste chamadas para outros programas
- Identifique copybooks utilizados
- Documente interfaces externas

Foque em explicar COMO o programa funciona e QUAL a lógica de negócio, não apenas descrever a estrutura do código."""
    
    def _identify_copybook_type(self, content: str) -> str:
        """Identifica o tipo de copybook baseado no conteúdo"""
        
        content_upper = content.upper()
        
        if 'PIC ' in content_upper and ('01 ' in content_upper or '05 ' in content_upper):
            return "Layout de dados"
        elif 'WORKING-STORAGE' in content_upper:
            return "Área de trabalho"
        elif 'LINKAGE' in content_upper:
            return "Interface de comunicação"
        elif 'FILE SECTION' in content_upper:
            return "Definição de arquivo"
        elif 'COPY ' in content_upper:
            return "Include de outros copybooks"
        else:
            return "Copybook genérico"
    
    def _extract_main_fields(self, content: str) -> List[str]:
        """Extrai campos principais de um copybook de layout"""
        
        fields = []
        lines = content.split('\n')
        
        for line in lines:
            line_stripped = line.strip().upper()
            
            # Procurar por definições de campo (01, 05, 10, etc.)
            if line_stripped.startswith(('01 ', '05 ', '10 ', '15 ', '20 ')):
                # Extrair nome do campo
                parts = line_stripped.split()
                if len(parts) >= 2:
                    field_name = parts[1]
                    # Remover caracteres especiais
                    field_name = field_name.replace('.', '').replace(',', '')
                    if field_name and field_name not in ['FILLER', 'REDEFINES']:
                        fields.append(field_name)
        
        return fields[:10]  # Retornar apenas os primeiros 10 campos
    
    def generate_structural_prompt(self, program_name: str, cobol_code: str) -> str:
        """Gera prompt para análise estrutural básica"""
        
        return f"""# Análise Estrutural de Programa COBOL: {program_name}

Analise a estrutura do programa COBOL abaixo e forneça:

1. **Organização Geral**: Avalie a estrutura das divisões (IDENTIFICATION, ENVIRONMENT, DATA, PROCEDURE)
2. **Qualidade do Código**: Comente sobre legibilidade, organização e padrões
3. **Complexidade**: Avalie a complexidade estrutural do programa
4. **Recomendações**: Sugira melhorias estruturais

## Código COBOL:

```cobol
{cobol_code}
```

Foque na ESTRUTURA e ORGANIZAÇÃO do código, não na lógica de negócio."""
    
    def generate_business_rules_prompt(self, program_name: str, cobol_code: str) -> str:
        """Gera prompt específico para extração de regras de negócio"""
        
        return f"""# Extração de Regras de Negócio: {program_name}

Analise o programa COBOL e extraia APENAS as regras de negócio:

1. **Validações**: Todas as condições IF, WHEN, EVALUATE
2. **Roteamentos**: Lógica de direcionamento de dados
3. **Controles**: Limites, contadores, flags de controle
4. **Transformações**: Como os dados são modificados

## Código COBOL:

```cobol
{cobol_code}
```

IMPORTANTE: Foque apenas nas REGRAS DE NEGÓCIO, ignore aspectos técnicos de implementação."""

class PromptResponseLogger:
    """Logger para capturar prompts enviados e respostas recebidas"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.prompt_history = []
    
    def log_prompt_response(self, 
                          provider: str,
                          prompt_type: str,
                          prompt: str,
                          response: str,
                          program_name: str) -> Dict:
        """Registra prompt e resposta para inclusão no relatório final"""
        
        entry = {
            'provider': provider,
            'prompt_type': prompt_type,
            'program_name': program_name,
            'prompt': prompt,
            'response': response,
            'timestamp': self._get_timestamp()
        }
        
        self.prompt_history.append(entry)
        
        return entry
    
    def get_prompts_for_program(self, program_name: str) -> List[Dict]:
        """Retorna todos os prompts e respostas para um programa específico"""
        
        return [entry for entry in self.prompt_history 
                if entry['program_name'] == program_name]
    
    def generate_prompt_appendix(self, program_name: str) -> str:
        """Gera apêndice com prompts e respostas para o relatório final"""
        
        entries = self.get_prompts_for_program(program_name)
        
        if not entries:
            return ""
        
        appendix_sections = []
        appendix_sections.append("## Apêndice: Prompts e Respostas Originais")
        appendix_sections.append("Esta seção contém os prompts enviados para cada provedor de IA e suas respostas originais.")
        
        for i, entry in enumerate(entries, 1):
            section = f"""### {i}. {entry['provider']} - {entry['prompt_type']}

**Timestamp**: {entry['timestamp']}

#### Prompt Enviado:
```
{entry['prompt']}
```

#### Resposta Original:
```
{entry['response']}
```

---"""
            appendix_sections.append(section)
        
        return "\n\n".join(appendix_sections)
    
    def _get_timestamp(self) -> str:
        """Gera timestamp atual"""
        from datetime import datetime
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")
