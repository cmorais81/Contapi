# -*- coding: utf-8 -*-
"""
Content Extractor - Sistema de Análise COBOL v1.0.0
Extrai conteúdo real dos arquivos fontes.txt e BOOKS.txt para enriquecer a análise.
"""

import re
import logging
from typing import Dict, List, Any, Optional
from pathlib import Path

class COBOLContentExtractor:
    """Extrai conteúdo estruturado dos arquivos COBOL para enriquecer análise."""
    
    def __init__(self):
        self.logger = logging.getLogger(self.__class__.__name__)
        
    def extract_from_file(self, file_path: str) -> Dict[str, Any]:
        """Extrai dados de um arquivo COBOL individual."""
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            program_name = Path(file_path).stem
            return self.extract_from_content(content, program_name)
            
        except Exception as e:
            self.logger.error(f"Erro ao extrair dados do arquivo {file_path}: {e}")
            return self._create_empty_extraction(Path(file_path).stem)
    
    def extract_from_content(self, content: str, program_name: str) -> Dict[str, Any]:
        """Extrai dados estruturados do conteúdo COBOL."""
        
        extracted_data = {
            'program_name': program_name,
            'content': content,
            'divisions': self._extract_divisions(content),
            'sections': self._extract_sections(content),
            'paragraphs': self._extract_paragraphs(content),
            'variables': self._extract_variables(content),
            'files': self._extract_files(content),
            'metadata': self._extract_metadata(content),
            'business_rules': self._extract_business_rules(content),
            'technical_info': self._extract_technical_info(content)
        }
        
        return extracted_data
        
    def extract_from_files(self, input_files: List[str], copybooks_file: str = None) -> Dict[str, Any]:
        """
        Extrai conteúdo real dos arquivos de entrada.
        
        Args:
            input_files: Lista de arquivos de entrada
            copybooks_file: Arquivo de copybooks (opcional)
            
        Returns:
            Dict com conteúdo extraído estruturado
        """
        extracted_content = {
            'programs': [],
            'copybooks': [],
            'summary': {},
            'business_rules': [],
            'technical_info': {}
        }
        
        try:
            # Processar arquivos de entrada
            for file_path in input_files:
                if self._is_multi_program_file(file_path):
                    programs = self._extract_programs_from_file(file_path)
                    extracted_content['programs'].extend(programs)
                else:
                    # Arquivo individual
                    program = self._extract_single_program(file_path)
                    if program:
                        extracted_content['programs'].append(program)
            
            # Processar copybooks se fornecido
            if copybooks_file and Path(copybooks_file).exists():
                copybooks = self._extract_copybooks_from_file(copybooks_file)
                extracted_content['copybooks'] = copybooks
                
            # Gerar resumo
            extracted_content['summary'] = self._generate_summary(extracted_content)
            
            return extracted_content
            
        except Exception as e:
            self.logger.error(f"Erro na extração de conteúdo: {e}")
            return extracted_content
    
    def _create_empty_extraction(self, program_name: str) -> Dict[str, Any]:
        """Cria uma estrutura de extração vazia."""
        return {
            'program_name': program_name,
            'content': '',
            'divisions': {},
            'sections': [],
            'paragraphs': [],
            'variables': [],
            'files': [],
            'metadata': {},
            'business_rules': [],
            'technical_info': {}
        }
    
    def _extract_divisions(self, content: str) -> Dict[str, str]:
        """Extrai as divisões COBOL do conteúdo."""
        divisions = {}
        
        # Padrões para identificar divisões
        division_patterns = {
            'identification': r'IDENTIFICATION\s+DIVISION\.(.*?)(?=ENVIRONMENT\s+DIVISION|DATA\s+DIVISION|PROCEDURE\s+DIVISION|$)',
            'environment': r'ENVIRONMENT\s+DIVISION\.(.*?)(?=DATA\s+DIVISION|PROCEDURE\s+DIVISION|$)',
            'data': r'DATA\s+DIVISION\.(.*?)(?=PROCEDURE\s+DIVISION|$)',
            'procedure': r'PROCEDURE\s+DIVISION\.(.*?)$'
        }
        
        for division_name, pattern in division_patterns.items():
            match = re.search(pattern, content, re.DOTALL | re.IGNORECASE)
            if match:
                divisions[division_name] = match.group(1).strip()
        
        return divisions
    
    def _extract_sections(self, content: str) -> List[Dict[str, str]]:
        """Extrai seções do programa COBOL."""
        sections = []
        
        # Padrão para seções
        section_pattern = r'(\w+)\s+SECTION\.(.*?)(?=\w+\s+SECTION\.|$)'
        matches = re.finditer(section_pattern, content, re.DOTALL | re.IGNORECASE)
        
        for match in matches:
            sections.append({
                'name': match.group(1).strip(),
                'content': match.group(2).strip()
            })
        
        return sections
    
    def _extract_paragraphs(self, content: str) -> List[Dict[str, str]]:
        """Extrai parágrafos do programa COBOL."""
        paragraphs = []
        
        # Padrão para parágrafos (linhas que terminam com ponto)
        paragraph_pattern = r'^(\s*)([A-Z0-9][A-Z0-9\-]*)\.\s*$'
        lines = content.split('\n')
        
        current_paragraph = None
        paragraph_content = []
        
        for line in lines:
            match = re.match(paragraph_pattern, line)
            if match:
                # Salvar parágrafo anterior se existir
                if current_paragraph:
                    paragraphs.append({
                        'name': current_paragraph,
                        'content': '\n'.join(paragraph_content)
                    })
                
                # Iniciar novo parágrafo
                current_paragraph = match.group(2)
                paragraph_content = []
            elif current_paragraph:
                paragraph_content.append(line)
        
        # Salvar último parágrafo
        if current_paragraph:
            paragraphs.append({
                'name': current_paragraph,
                'content': '\n'.join(paragraph_content)
            })
        
        return paragraphs
    
    def _extract_variables(self, content: str) -> List[Dict[str, str]]:
        """Extrai variáveis definidas no programa."""
        variables = []
        
        # Padrão para definições de variáveis
        var_pattern = r'^\s*(\d{2})\s+([A-Z0-9\-]+)\s+PIC\s+([X9\(\)V\-]+)'
        lines = content.split('\n')
        
        for line in lines:
            match = re.match(var_pattern, line, re.IGNORECASE)
            if match:
                variables.append({
                    'level': match.group(1),
                    'name': match.group(2),
                    'picture': match.group(3)
                })
        
        return variables
    
    def _extract_files(self, content: str) -> List[Dict[str, str]]:
        """Extrai definições de arquivos."""
        files = []
        
        # Padrão para SELECT statements
        select_pattern = r'SELECT\s+([A-Z0-9\-]+)\s+ASSIGN\s+(?:TO\s+)?([A-Z0-9\-]+)'
        matches = re.finditer(select_pattern, content, re.IGNORECASE)
        
        for match in matches:
            files.append({
                'logical_name': match.group(1),
                'physical_name': match.group(2)
            })
        
        return files
    
    def _extract_metadata(self, content: str) -> Dict[str, str]:
        """Extrai metadados do programa."""
        metadata = {}
        
        # Extrair PROGRAM-ID
        program_id_match = re.search(r'PROGRAM-ID\.\s+([A-Z0-9\-]+)', content, re.IGNORECASE)
        if program_id_match:
            metadata['program_id'] = program_id_match.group(1)
        
        # Extrair AUTHOR
        author_match = re.search(r'AUTHOR\.\s+([^\n]+)', content, re.IGNORECASE)
        if author_match:
            metadata['author'] = author_match.group(1).strip()
        
        # Extrair DATE-WRITTEN
        date_match = re.search(r'DATE-WRITTEN\.\s+([^\n]+)', content, re.IGNORECASE)
        if date_match:
            metadata['date_written'] = date_match.group(1).strip()
        
        return metadata
    
    def _extract_business_rules(self, content: str) -> List[str]:
        """Extrai regras de negócio identificáveis no código."""
        rules = []
        
        # Procurar por comentários que indicam regras de negócio
        comment_pattern = r'^\s*\*.*?(REGRA|RULE|VALIDACAO|VALIDATION|PROCESSO|PROCESS).*$'
        lines = content.split('\n')
        
        for line in lines:
            if re.match(comment_pattern, line, re.IGNORECASE):
                rules.append(line.strip())
        
        return rules
    
    def _extract_technical_info(self, content: str) -> Dict[str, Any]:
        """Extrai informações técnicas do programa."""
        info = {
            'line_count': len(content.split('\n')),
            'has_sql': 'EXEC SQL' in content.upper(),
            'has_cics': 'EXEC CICS' in content.upper(),
            'has_db2': 'EXEC SQL' in content.upper() or 'SQLCA' in content.upper(),
            'complexity_indicators': []
        }
        
        # Indicadores de complexidade
        if 'PERFORM' in content.upper():
            info['complexity_indicators'].append('PERFORM statements')
        if 'CALL' in content.upper():
            info['complexity_indicators'].append('CALL statements')
        if 'GO TO' in content.upper():
            info['complexity_indicators'].append('GO TO statements')
        
        return info
    
    def _is_multi_program_file(self, file_path: str) -> bool:
        """Verifica se o arquivo contém múltiplos programas."""
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                first_lines = [f.readline() for _ in range(10)]
            
            # Verificar se há indicadores de múltiplos programas
            multi_indicators = ['VMEMBER', 'MEMBER NAME', '----+----']
            return any(indicator in ''.join(first_lines) for indicator in multi_indicators)
            
        except Exception:
            return False
    
    def _extract_programs_from_file(self, file_path: str) -> List[Dict[str, Any]]:
        """Extrai múltiplos programas de um arquivo."""
        programs = []
        
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            # Dividir por programas (implementação simplificada)
            # Aqui você implementaria a lógica específica para seu formato
            programs.append({
                'name': Path(file_path).stem,
                'content': content,
                'extracted_data': self.extract_from_content(content, Path(file_path).stem)
            })
            
        except Exception as e:
            self.logger.error(f"Erro ao extrair programas de {file_path}: {e}")
        
        return programs
    
    def _extract_single_program(self, file_path: str) -> Optional[Dict[str, Any]]:
        """Extrai um único programa de um arquivo."""
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            return {
                'name': Path(file_path).stem,
                'content': content,
                'extracted_data': self.extract_from_content(content, Path(file_path).stem)
            }
            
        except Exception as e:
            self.logger.error(f"Erro ao extrair programa de {file_path}: {e}")
            return None
    
    def _extract_copybooks_from_file(self, file_path: str) -> List[Dict[str, Any]]:
        """Extrai copybooks de um arquivo."""
        copybooks = []
        
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            # Implementar lógica de extração de copybooks
            # Por enquanto, retorna uma estrutura básica
            copybooks.append({
                'name': Path(file_path).stem,
                'content': content
            })
            
        except Exception as e:
            self.logger.error(f"Erro ao extrair copybooks de {file_path}: {e}")
        
        return copybooks
    
    def _generate_summary(self, extracted_content: Dict[str, Any]) -> Dict[str, Any]:
        """Gera resumo do conteúdo extraído."""
        return {
            'total_programs': len(extracted_content.get('programs', [])),
            'total_copybooks': len(extracted_content.get('copybooks', [])),
            'extraction_timestamp': Path(__file__).stat().st_mtime
        }


    def extract_comments(self, content: str) -> List[str]:
        """Extrai comentários do código COBOL."""
        comments = []
        for line in content.splitlines():
            if len(line) > 6 and line[6] == '*':
                comments.append(line[7:].strip())
        return comments

    def extract_structure(self, content: str) -> Dict[str, Any]:
        """Extrai a estrutura do programa COBOL."""
        return {
            "divisions": self._extract_divisions(content),
            "sections": self._extract_sections(content),
            "paragraphs": self._extract_paragraphs(content),
        }

