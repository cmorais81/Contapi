"""
Sistema de divisão inteligente de prompts para análise de programas COBOL grandes
"""

import re
from typing import List, Dict, Any

class SmartPromptSplitter:
    """Divide prompts grandes em partes menores e consolida resultados"""
    
    def __init__(self, max_tokens_per_prompt=3000):
        self.max_tokens_per_prompt = max_tokens_per_prompt
        
    def extract_cobol_comments(self, cobol_code: str) -> Dict[str, List[str]]:
        """Extrai comentários importantes do código COBOL"""
        comments = {
            'objective': [],
            'business_rules': [],
            'technical_notes': [],
            'general': []
        }
        
        lines = cobol_code.split('\n')
        
        for line in lines:
            line = line.strip()
            if line.startswith('*') or line.startswith('//'):
                comment = line.lstrip('*').lstrip('/').strip()
                
                # Classificar comentários por tipo
                if any(keyword in comment.upper() for keyword in ['OBJETIVO', 'PURPOSE', 'FUNCTION']):
                    comments['objective'].append(comment)
                elif any(keyword in comment.upper() for keyword in ['REGRA', 'RULE', 'VALIDACAO', 'VALIDATION']):
                    comments['business_rules'].append(comment)
                elif any(keyword in comment.upper() for keyword in ['TECNICO', 'TECHNICAL', 'IMPLEMENTACAO']):
                    comments['technical_notes'].append(comment)
                elif len(comment) > 10:  # Ignorar comentários muito curtos
                    comments['general'].append(comment)
        
        return comments
    
    def split_cobol_program(self, cobol_code: str, program_name: str) -> List[Dict[str, Any]]:
        """Divide programa COBOL em seções lógicas para análise"""
        
        sections = []
        
        # 1. Seção de identificação e comentários
        comments = self.extract_cobol_comments(cobol_code)
        if any(comments.values()):
            sections.append({
                'type': 'comments_and_objective',
                'title': 'Comentários e Objetivo do Programa',
                'content': self._format_comments_section(comments, program_name),
                'priority': 1
            })
        
        # 2. Seção de estruturas de dados
        data_section = self._extract_data_division(cobol_code)
        if data_section:
            sections.append({
                'type': 'data_structures',
                'title': 'Estruturas de Dados e Working Storage',
                'content': data_section,
                'priority': 2
            })
        
        # 3. Seção de lógica principal
        procedure_section = self._extract_procedure_division(cobol_code)
        if procedure_section:
            # Dividir procedure division se muito grande
            procedure_parts = self._split_procedure_division(procedure_section)
            for i, part in enumerate(procedure_parts):
                sections.append({
                    'type': 'business_logic',
                    'title': f'Lógica de Negócio - Parte {i+1}',
                    'content': part,
                    'priority': 3 + i
                })
        
        return sections
    
    def _format_comments_section(self, comments: Dict[str, List[str]], program_name: str) -> str:
        """Formata seção de comentários para análise"""
        content = f"PROGRAMA: {program_name}\n\n"
        
        if comments['objective']:
            content += "OBJETIVO DO PROGRAMA:\n"
            for comment in comments['objective']:
                content += f"- {comment}\n"
            content += "\n"
        
        if comments['business_rules']:
            content += "REGRAS DE NEGÓCIO COMENTADAS:\n"
            for comment in comments['business_rules']:
                content += f"- {comment}\n"
            content += "\n"
        
        if comments['technical_notes']:
            content += "NOTAS TÉCNICAS:\n"
            for comment in comments['technical_notes']:
                content += f"- {comment}\n"
            content += "\n"
        
        if comments['general']:
            content += "OUTROS COMENTÁRIOS IMPORTANTES:\n"
            for comment in comments['general'][:10]:  # Limitar a 10 comentários
                content += f"- {comment}\n"
        
        return content
    
    def _extract_data_division(self, cobol_code: str) -> str:
        """Extrai DATA DIVISION do código COBOL"""
        lines = cobol_code.split('\n')
        data_section = []
        in_data_division = False
        
        for line in lines:
            if 'DATA DIVISION' in line.upper():
                in_data_division = True
            elif 'PROCEDURE DIVISION' in line.upper():
                break
            elif in_data_division:
                data_section.append(line)
        
        return '\n'.join(data_section) if data_section else ""
    
    def _extract_procedure_division(self, cobol_code: str) -> str:
        """Extrai PROCEDURE DIVISION do código COBOL"""
        lines = cobol_code.split('\n')
        procedure_section = []
        in_procedure_division = False
        
        for line in lines:
            if 'PROCEDURE DIVISION' in line.upper():
                in_procedure_division = True
            elif in_procedure_division:
                procedure_section.append(line)
        
        return '\n'.join(procedure_section) if procedure_section else ""
    
    def _split_procedure_division(self, procedure_code: str) -> List[str]:
        """Divide PROCEDURE DIVISION em partes menores se necessário"""
        
        # Estimar tokens (aproximadamente 4 caracteres por token)
        estimated_tokens = len(procedure_code) // 4
        
        if estimated_tokens <= self.max_tokens_per_prompt:
            return [procedure_code]
        
        # Dividir por seções/parágrafos
        lines = procedure_code.split('\n')
        parts = []
        current_part = []
        current_size = 0
        
        for line in lines:
            line_size = len(line) // 4  # Estimativa de tokens
            
            # Se adicionar esta linha exceder o limite, iniciar nova parte
            if current_size + line_size > self.max_tokens_per_prompt and current_part:
                parts.append('\n'.join(current_part))
                current_part = [line]
                current_size = line_size
            else:
                current_part.append(line)
                current_size += line_size
        
        # Adicionar última parte
        if current_part:
            parts.append('\n'.join(current_part))
        
        return parts
    
    def create_analysis_prompts(self, sections: List[Dict[str, Any]], copybooks: Dict = None) -> List[Dict[str, Any]]:
        """Cria prompts específicos para cada seção"""
        
        prompts = []
        
        for section in sections:
            if section['type'] == 'comments_and_objective':
                prompt = self._create_objective_prompt(section, copybooks)
            elif section['type'] == 'data_structures':
                prompt = self._create_data_analysis_prompt(section, copybooks)
            elif section['type'] == 'business_logic':
                prompt = self._create_logic_analysis_prompt(section, copybooks)
            else:
                continue
            
            prompts.append({
                'section_type': section['type'],
                'section_title': section['title'],
                'prompt': prompt,
                'priority': section['priority']
            })
        
        return prompts
    
    def _create_objective_prompt(self, section: Dict[str, Any], copybooks: Dict = None) -> str:
        """Cria prompt para análise de objetivo e comentários"""
        
        copybook_info = ""
        if copybooks:
            copybook_info = f"\n\nCOPYBOOKS DISPONÍVEIS:\n"
            for name, info in list(copybooks.items())[:5]:  # Limitar a 5 copybooks
                copybook_info += f"- {name}: {info.get('description', 'Layout de dados')}\n"
        
        return f"""Analise os comentários e objetivo do programa COBOL abaixo:

{section['content']}
{copybook_info}

RESPONDA APENAS:
1. OBJETIVO PRINCIPAL: (em 1-2 frases claras)
2. REGRAS DE NEGÓCIO: (liste as principais regras identificadas)
3. PARTICULARIDADES: (pontos importantes ou especiais)

Seja conciso e objetivo."""
    
    def _create_data_analysis_prompt(self, section: Dict[str, Any], copybooks: Dict = None) -> str:
        """Cria prompt para análise de estruturas de dados"""
        
        return f"""Analise as estruturas de dados do programa COBOL:

{section['content'][:2000]}  

RESPONDA APENAS:
1. ARQUIVOS PRINCIPAIS: (liste os arquivos de entrada e saída)
2. CAMPOS IMPORTANTES: (principais campos de trabalho)
3. ESTRUTURAS DE CONTROLE: (contadores, flags, etc.)

Seja conciso e foque no essencial."""
    
    def _create_logic_analysis_prompt(self, section: Dict[str, Any], copybooks: Dict = None) -> str:
        """Cria prompt para análise de lógica de negócio"""
        
        return f"""Analise a lógica de negócio do programa COBOL:

{section['content'][:2500]}

RESPONDA APENAS:
1. FLUXO PRINCIPAL: (sequência de processamento)
2. VALIDAÇÕES: (regras de validação identificadas)
3. PROCESSAMENTO: (operações principais realizadas)

Seja conciso e objetivo."""
    
    def consolidate_analysis_results(self, analysis_results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Consolida resultados de múltiplas análises em um relatório único"""
        
        consolidated = {
            'objective': "",
            'business_rules': [],
            'particularities': [],
            'main_files': [],
            'important_fields': [],
            'control_structures': [],
            'main_flow': [],
            'validations': [],
            'processing': []
        }
        
        for result in sorted(analysis_results, key=lambda x: x.get('priority', 999)):
            analysis = result.get('analysis', {})
            
            if result['section_type'] == 'comments_and_objective':
                consolidated['objective'] = analysis.get('objective', "")
                consolidated['business_rules'].extend(analysis.get('business_rules', []))
                consolidated['particularities'].extend(analysis.get('particularities', []))
            
            elif result['section_type'] == 'data_structures':
                consolidated['main_files'].extend(analysis.get('main_files', []))
                consolidated['important_fields'].extend(analysis.get('important_fields', []))
                consolidated['control_structures'].extend(analysis.get('control_structures', []))
            
            elif result['section_type'] == 'business_logic':
                consolidated['main_flow'].extend(analysis.get('main_flow', []))
                consolidated['validations'].extend(analysis.get('validations', []))
                consolidated['processing'].extend(analysis.get('processing', []))
        
        # Remover duplicatas mantendo ordem
        for key in consolidated:
            if isinstance(consolidated[key], list):
                consolidated[key] = list(dict.fromkeys(consolidated[key]))
        
        return consolidated
