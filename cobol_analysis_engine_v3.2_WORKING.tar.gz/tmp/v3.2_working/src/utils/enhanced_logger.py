#!/usr/bin/env python3.11
# -*- coding: utf-8 -*-
"""
Sistema de Logging Aprimorado para Análise COBOL
Fornece logging detalhado e estruturado para todas as operações do sistema.
"""

import logging
import json
import time
from datetime import datetime
from typing import Dict, Any, List
from pathlib import Path


class EnhancedAnalysisLogger:
    """Logger aprimorado para análises COBOL com métricas detalhadas."""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.logger = logging.getLogger(__name__)
        self.analysis_metrics = {}
        self.start_time = None
        
        # Configurar logs estruturados
        self.setup_structured_logging()
    
    def setup_structured_logging(self):
        """Configura logging estruturado com diferentes níveis."""
        log_config = self.config.get("logging", {})
        
        # Criar diretório de logs se não existir
        log_dir = Path(log_config.get("log_dir", "logs"))
        log_dir.mkdir(exist_ok=True)
        
        # Configurar formatadores
        detailed_formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - [%(funcName)s:%(lineno)d] - %(message)s'
        )
        
        simple_formatter = logging.Formatter(
            '%(asctime)s - %(levelname)s - %(message)s'
        )
        
        # Handler para log geral
        general_handler = logging.FileHandler(log_dir / "cobol_analysis.log")
        general_handler.setFormatter(detailed_formatter)
        general_handler.setLevel(logging.INFO)
        
        # Handler para métricas
        metrics_handler = logging.FileHandler(log_dir / "analysis_metrics.log")
        metrics_handler.setFormatter(simple_formatter)
        metrics_handler.setLevel(logging.INFO)
        
        # Handler para erros
        error_handler = logging.FileHandler(log_dir / "analysis_errors.log")
        error_handler.setFormatter(detailed_formatter)
        error_handler.setLevel(logging.ERROR)
        
        # Configurar logger principal
        root_logger = logging.getLogger()
        root_logger.setLevel(logging.DEBUG)
        root_logger.addHandler(general_handler)
        root_logger.addHandler(error_handler)
        
        # Logger específico para métricas
        self.metrics_logger = logging.getLogger("metrics")
        self.metrics_logger.addHandler(metrics_handler)
        self.metrics_logger.setLevel(logging.INFO)
    
    def start_analysis(self, program_name: str, mode: str):
        """Inicia o logging de uma análise."""
        self.start_time = time.time()
        self.analysis_metrics = {
            "program_name": program_name,
            "mode": mode,
            "start_time": datetime.now().isoformat(),
            "providers_used": [],
            "analysis_results": {},
            "performance_metrics": {},
            "errors": []
        }
        
        self.logger.info(f"=== INICIANDO ANÁLISE ===")
        self.logger.info(f"Programa: {program_name}")
        self.logger.info(f"Modo: {mode}")
        self.logger.info(f"Timestamp: {self.analysis_metrics['start_time']}")
    
    def log_provider_usage(self, provider_name: str, domain: str, success: bool, 
                          execution_time: float, tokens_used: int = 0, error_msg: str = None):
        """Registra uso de provedor de IA."""
        provider_info = {
            "provider": provider_name,
            "domain": domain,
            "success": success,
            "execution_time": execution_time,
            "tokens_used": tokens_used,
            "timestamp": datetime.now().isoformat()
        }
        
        if error_msg:
            provider_info["error"] = error_msg
            self.analysis_metrics["errors"].append({
                "provider": provider_name,
                "domain": domain,
                "error": error_msg,
                "timestamp": datetime.now().isoformat()
            })
        
        self.analysis_metrics["providers_used"].append(provider_info)
        
        status = "SUCESSO" if success else "FALHA"
        self.logger.info(f"Provedor {provider_name} ({domain}): {status} - {execution_time:.2f}s - {tokens_used} tokens")
        
        if error_msg:
            self.logger.error(f"Erro no provedor {provider_name} ({domain}): {error_msg}")
    
    def log_analysis_result(self, domain: str, result: Dict[str, Any]):
        """Registra resultado de análise de um domínio."""
        self.analysis_metrics["analysis_results"][domain] = {
            "success": result.get("success", False),
            "confidence": result.get("confidence", 0.0),
            "summary_length": len(str(result.get("summary", ""))),
            "timestamp": datetime.now().isoformat()
        }
        
        self.logger.info(f"Resultado da análise {domain}: {result.get('success', False)}")
    
    def log_copybook_processing(self, copybooks_count: int, processing_time: float):
        """Registra processamento de copybooks."""
        self.analysis_metrics["performance_metrics"]["copybooks"] = {
            "count": copybooks_count,
            "processing_time": processing_time
        }
        
        self.logger.info(f"Processados {copybooks_count} copybooks em {processing_time:.2f}s")
    
    def log_validation_results(self, validation_summary: Any):
        """Registra resultados de validação cruzada."""
        # Converter objeto para dicionário se necessário
        if hasattr(validation_summary, '__dict__'):
            validation_dict = validation_summary.__dict__
        else:
            validation_dict = validation_summary if isinstance(validation_summary, dict) else {}
        
        self.analysis_metrics["validation"] = {
            "executed": True,
            "overall_confidence": validation_dict.get("overall_confidence", 0.0),
            "conflicts_count": len(validation_dict.get("conflicts", [])),
            "timestamp": datetime.now().isoformat()
        }
        
        confidence = validation_dict.get("overall_confidence", 0.0)
        self.logger.info(f"Validação cruzada: confiança {confidence:.2f}")
    
    def log_clarity_analysis(self, clarity_scores: Any):
        """Registra análise de clareza."""
        # Converter objeto para dicionário se necessário
        if hasattr(clarity_scores, '__dict__'):
            clarity_dict = clarity_scores.__dict__
        else:
            clarity_dict = clarity_scores if isinstance(clarity_scores, dict) else {}
        
        self.analysis_metrics["clarity"] = {
            "overall_score": clarity_dict.get("overall_score", 0.0),
            "readability": clarity_dict.get("readability", 0.0),
            "completeness": clarity_dict.get("completeness", 0.0),
            "timestamp": datetime.now().isoformat()
        }
        
        overall_score = clarity_dict.get("overall_score", 0.0)
        self.logger.info(f"Análise de clareza: {overall_score:.2f}")
    
    def finish_analysis(self, success: bool, output_path: str = None):
        """Finaliza o logging da análise."""
        end_time = time.time()
        total_time = end_time - self.start_time if self.start_time else 0
        
        self.analysis_metrics.update({
            "end_time": datetime.now().isoformat(),
            "total_execution_time": total_time,
            "success": success,
            "output_path": output_path
        })
        
        # Calcular estatísticas
        successful_providers = sum(1 for p in self.analysis_metrics["providers_used"] if p["success"])
        total_providers = len(self.analysis_metrics["providers_used"])
        total_tokens = sum(p.get("tokens_used", 0) for p in self.analysis_metrics["providers_used"])
        
        self.analysis_metrics["performance_metrics"].update({
            "successful_providers": successful_providers,
            "total_providers": total_providers,
            "success_rate": (successful_providers / total_providers * 100) if total_providers > 0 else 0,
            "total_tokens_used": total_tokens,
            "avg_execution_time": total_time / total_providers if total_providers > 0 else 0
        })
        
        # Log final
        self.logger.info(f"=== ANÁLISE FINALIZADA ===")
        self.logger.info(f"Status: {'SUCESSO' if success else 'FALHA'}")
        self.logger.info(f"Tempo total: {total_time:.2f}s")
        self.logger.info(f"Provedores bem-sucedidos: {successful_providers}/{total_providers}")
        self.logger.info(f"Tokens utilizados: {total_tokens}")
        
        if output_path:
            self.logger.info(f"Relatório salvo em: {output_path}")
        
        # Métricas incluídas diretamente no relatório final
    
    def get_analysis_summary(self) -> Dict[str, Any]:
        """Retorna resumo da análise atual."""
        if not self.analysis_metrics:
            return {}
        
        return {
            "program": self.analysis_metrics.get("program_name"),
            "mode": self.analysis_metrics.get("mode"),
            "duration": self.analysis_metrics.get("total_execution_time", 0),
            "success_rate": self.analysis_metrics.get("performance_metrics", {}).get("success_rate", 0),
            "total_tokens": self.analysis_metrics.get("performance_metrics", {}).get("total_tokens_used", 0),
            "errors_count": len(self.analysis_metrics.get("errors", []))
        }


class AnalysisReportFormatter:
    """Formatador para relatórios de análise com padrões consistentes."""
    
    def __init__(self):
        self.template_header = """# Análise Detalhada do Programa COBOL

**Programa:** {program_name}  
**Autor:** {author}  
**Data de Criação:** {date_written}  
**Modo de Análise:** {analysis_mode}  
**Data da Análise:** {analysis_date}  

---

"""
    
    def format_header(self, program_data: Dict[str, Any], analysis_mode: str) -> str:
        """Formata cabeçalho padronizado."""
        return self.template_header.format(
            program_name=program_data.get('name', 'N/A'),
            author=program_data.get('author', 'N/A'),
            date_written=program_data.get('date_written', 'N/A'),
            analysis_mode=analysis_mode,
            analysis_date=datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        )
    
    def format_metrics_section(self, metrics: Dict[str, Any]) -> str:
        """Formata seção de métricas da análise."""
        if not metrics:
            return ""
        
        section = "\n## Métricas da Análise\n\n"
        
        perf_metrics = metrics.get("performance_metrics", {})
        section += f"**Tempo Total de Execução:** {metrics.get('total_execution_time', 0):.2f}s  \n"
        section += f"**Provedores Utilizados:** {perf_metrics.get('successful_providers', 0)}/{perf_metrics.get('total_providers', 0)}  \n"
        section += f"**Taxa de Sucesso:** {perf_metrics.get('success_rate', 0):.1f}%  \n"
        section += f"**Tokens Utilizados:** {perf_metrics.get('total_tokens_used', 0)}  \n"
        
        if metrics.get("validation"):
            section += f"**Confiança da Validação:** {metrics['validation'].get('overall_confidence', 0):.2f}  \n"
        
        if metrics.get("clarity"):
            section += f"**Pontuação de Clareza:** {metrics['clarity'].get('overall_score', 0):.2f}  \n"
        
        return section + "\n"
    
    def format_copybooks_section(self, copybooks: List[Dict[str, Any]]) -> str:
        """Formata seção de copybooks utilizados."""
        if not copybooks:
            return ""
        
        section = "\n## Copybooks Relacionados\n\n"
        
        for copybook in copybooks[:5]:  # Limitar a 5 copybooks
            name = copybook.get('name', 'N/A')
            description = copybook.get('description', 'Copybook de dados')
            section += f"**{name}:** {description}  \n"
        
        if len(copybooks) > 5:
            section += f"\n*... e mais {len(copybooks) - 5} copybooks*\n"
        
        return section + "\n"
