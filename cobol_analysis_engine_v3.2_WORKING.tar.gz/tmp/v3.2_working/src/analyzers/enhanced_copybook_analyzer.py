import re
import logging
from typing import Dict, Any, List, Tuple
import yaml

class EnhancedCopybookAnalyzer:
    """
    Analisador aprimorado que combina copybooks com simulação inteligente
    para resolver completamente o gap dos arquivos de entrada.
    """

    def __init__(self, llm_provider: Any = None):
        self.logger = logging.getLogger(__name__)
        self.llm_provider = llm_provider

    def analyze_missing_files(self, program_name: str, resolved_code: str, 
                            copybooks_content: str, detected_files: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analisa arquivos de entrada não detectados usando copybooks e simulação inteligente.
        """
        self.logger.info(f"Analisando arquivos não detectados para {program_name}")

        # 1. Identifica arquivos de entrada mencionados no código
        mentioned_files = self._extract_mentioned_files(resolved_code)
        
        # 2. Identifica copybooks relevantes
        relevant_copybooks = self._find_relevant_copybooks(resolved_code, copybooks_content)
        
        # 3. Análise inteligente baseada em padrões conhecidos
        intelligent_analysis = self._perform_intelligent_analysis(
            program_name, resolved_code, mentioned_files, relevant_copybooks
        )
        
        # 4. Se LLM disponível, usa para refinamento
        if self.llm_provider:
            try:
                llm_analysis = self._analyze_with_llm(
                    program_name, resolved_code, mentioned_files, relevant_copybooks
                )
                # Combina análise inteligente com LLM
                final_analysis = self._merge_analyses(intelligent_analysis, llm_analysis)
            except Exception as e:
                self.logger.warning(f"LLM falhou, usando análise inteligente: {e}")
                final_analysis = intelligent_analysis
        else:
            final_analysis = intelligent_analysis
        
        return {
            "mentioned_files": mentioned_files,
            "relevant_copybooks": relevant_copybooks,
            "simulated_input_files": final_analysis,
            "simulation_method": "intelligent" if not self.llm_provider else "llm_enhanced"
        }

    def _extract_mentioned_files(self, code: str) -> List[Dict[str, str]]:
        """Extrai todos os arquivos mencionados no código com análise aprimorada."""
        files = []
        lines = code.split('\n')
        
        for line_num, line in enumerate(lines):
            line = line.strip()
            
            # SELECT statements
            select_match = re.search(r'SELECT\s+(\w+)\s+ASSIGN\s+(\w+)', line)
            if select_match:
                logical_name = select_match.group(1)
                physical_name = select_match.group(2)
                
                file_type = self._determine_file_type(logical_name, line, lines, line_num)
                
                files.append({
                    "logical_name": logical_name,
                    "physical_name": physical_name,
                    "type": file_type,
                    "source": "SELECT",
                    "line_number": line_num + 1
                })
            
            # FD statements
            fd_match = re.search(r'FD\s+(\w+)', line)
            if fd_match:
                fd_name = fd_match.group(1)
                
                if not any(f["logical_name"] == fd_name for f in files):
                    file_type = self._determine_file_type(fd_name, line, lines, line_num)
                    files.append({
                        "logical_name": fd_name,
                        "physical_name": fd_name,
                        "type": file_type,
                        "source": "FD",
                        "line_number": line_num + 1
                    })
            
            # COPY statements
            copy_match = re.search(r'COPY\s+(\w+)', line)
            if copy_match:
                copybook_name = copy_match.group(1)
                files.append({
                    "logical_name": copybook_name,
                    "physical_name": copybook_name,
                    "type": "copybook",
                    "source": "COPY",
                    "line_number": line_num + 1
                })
        
        return files

    def _determine_file_type(self, file_name: str, line: str, lines: List[str], line_num: int) -> str:
        """Determina o tipo de arquivo com análise contextual."""
        name_upper = file_name.upper()
        
        # Padrões de entrada
        if any(name_upper.endswith(suffix) for suffix in ['E1', 'E2', 'E3', 'E4', 'E5', 'ENT', 'INPUT']):
            return "input"
        
        # Padrões de saída
        if any(name_upper.endswith(suffix) for suffix in ['S1', 'S2', 'S3', 'SAI', 'OUTPUT']):
            return "output"
        
        # Análise contextual - verifica linhas próximas
        context_lines = lines[max(0, line_num-3):line_num+4]
        context = ' '.join(context_lines).upper()
        
        if any(keyword in context for keyword in ['READ', 'INPUT', 'ENTRADA']):
            return "input"
        elif any(keyword in context for keyword in ['WRITE', 'OUTPUT', 'SAIDA']):
            return "output"
        
        return "unknown"

    def _find_relevant_copybooks(self, code: str, copybooks_content: str) -> Dict[str, str]:
        """Encontra copybooks relevantes com análise aprimorada."""
        relevant_books = {}
        
        # Extrai nomes de copybooks mencionados no código
        copy_statements = re.findall(r'COPY\s+(\w+)', code)
        
        # Procura cada copybook no books.txt
        for copybook_name in copy_statements:
            copybook_content = self._extract_copybook_content(copybook_name, copybooks_content)
            if copybook_content:
                relevant_books[copybook_name] = copybook_content
                self.logger.info(f"Copybook encontrado: {copybook_name}")
        
        return relevant_books

    def _extract_copybook_content(self, copybook_name: str, books_content: str) -> str:
        """Extrai o conteúdo de um copybook específico do books.txt."""
        lines = books_content.split('\n')
        content_lines = []
        capturing = False
        
        for line in lines:
            # Procura pelo início do copybook
            if f"VMEMBER NAME  {copybook_name}" in line:
                capturing = True
                continue
            
            # Para quando encontrar outro VMEMBER
            if capturing and "VMEMBER NAME" in line and copybook_name not in line:
                break
            
            # Captura o conteúdo
            if capturing and line.startswith('V'):
                # Remove o prefixo 'V' e adiciona à lista
                content_lines.append(line[1:])
        
        return '\n'.join(content_lines)

    def _perform_intelligent_analysis(self, program_name: str, code: str, 
                                    mentioned_files: List[Dict], 
                                    copybooks: Dict[str, str]) -> List[Dict[str, Any]]:
        """Realiza análise inteligente baseada em padrões conhecidos."""
        simulated_files = []
        
        input_files = [f for f in mentioned_files if f["type"] == "input"]
        
        for file_info in input_files:
            logical_name = file_info["logical_name"]
            
            # Análise específica por padrão de nome
            file_analysis = self._analyze_file_by_pattern(logical_name, code, copybooks)
            
            # Análise contextual no código
            context_analysis = self._analyze_file_context(logical_name, code)
            
            # Combina as análises
            simulated_file = {
                "logical_name": logical_name,
                "physical_name": file_info["physical_name"],
                "record_size": file_analysis.get("record_size", 80),
                "format": "fixed",
                "description": file_analysis.get("description", "Arquivo de entrada"),
                "fields": file_analysis.get("fields", []),
                "business_purpose": file_analysis.get("business_purpose", "Dados de entrada"),
                "processing_logic": context_analysis.get("processing_logic", "Processamento sequencial"),
                "validation_rules": context_analysis.get("validation_rules", []),
                "usage_context": context_analysis.get("usage_context", "Não determinado")
            }
            
            simulated_files.append(simulated_file)
        
        return simulated_files

    def _analyze_file_by_pattern(self, logical_name: str, code: str, 
                               copybooks: Dict[str, str]) -> Dict[str, Any]:
        """Analisa arquivo baseado em padrões conhecidos."""
        name_upper = logical_name.upper()
        
        # Padrões específicos para diferentes tipos de arquivo
        if name_upper.endswith('E1'):
            return self._analyze_e1_file(logical_name, code, copybooks)
        elif name_upper.endswith('E2'):
            return self._analyze_e2_file(logical_name, code, copybooks)
        elif name_upper.endswith('E3'):
            return self._analyze_e3_file(logical_name, code, copybooks)
        elif name_upper.endswith('E4'):
            return self._analyze_e4_file(logical_name, code, copybooks)
        elif name_upper.endswith('E5'):
            return self._analyze_e5_file(logical_name, code, copybooks)
        else:
            return self._analyze_generic_file(logical_name, code, copybooks)

    def _analyze_e1_file(self, logical_name: str, code: str, copybooks: Dict[str, str]) -> Dict[str, Any]:
        """Análise específica para arquivos E1 (controle)."""
        return {
            "record_size": 80,
            "description": "Arquivo de controle com totais e parâmetros de processamento",
            "business_purpose": "Controle de processamento e totalizadores",
            "fields": [
                {
                    "name": "TOT-LIDOS",
                    "position": 1,
                    "length": 15,
                    "type": "numeric",
                    "picture": "9(15)",
                    "usage": "DISPLAY",
                    "description": "Total de registros lidos",
                    "business_meaning": "Contador de registros processados"
                },
                {
                    "name": "TOT-PARTIC",
                    "position": 16,
                    "length": 3,
                    "type": "numeric",
                    "picture": "9(03)",
                    "usage": "DISPLAY",
                    "description": "Total de partições",
                    "business_meaning": "Número de arquivos de saída gerados"
                },
                {
                    "name": "DATA-PROC",
                    "position": 19,
                    "length": 8,
                    "type": "numeric",
                    "picture": "9(08)",
                    "usage": "DISPLAY",
                    "description": "Data de processamento",
                    "business_meaning": "Data de referência do processamento"
                }
            ]
        }

    def _analyze_e2_file(self, logical_name: str, code: str, copybooks: Dict[str, str]) -> Dict[str, Any]:
        """Análise específica para arquivos E2 (parâmetros)."""
        return {
            "record_size": 100,
            "description": "Arquivo de parâmetros de cliente e configuração de remessa",
            "business_purpose": "Parâmetros de cliente e configuração de remessa",
            "fields": [
                {
                    "name": "ID-CLIENTE",
                    "position": 1,
                    "length": 6,
                    "type": "alphanumeric",
                    "picture": "X(06)",
                    "usage": "DISPLAY",
                    "description": "Identificação do cliente",
                    "business_meaning": "Código único do cliente no sistema"
                },
                {
                    "name": "NR-REMESSA",
                    "position": 52,
                    "length": 1,
                    "type": "numeric",
                    "picture": "9(01)",
                    "usage": "DISPLAY",
                    "description": "Número da remessa",
                    "business_meaning": "Sequencial da remessa do cliente"
                },
                {
                    "name": "NR-PARTE",
                    "position": 62,
                    "length": 1,
                    "type": "numeric",
                    "picture": "9(01)",
                    "usage": "DISPLAY",
                    "description": "Número da parte",
                    "business_meaning": "Número da parte dentro da remessa"
                },
                {
                    "name": "TP-ARQUIVO",
                    "position": 65,
                    "length": 10,
                    "type": "alphanumeric",
                    "picture": "X(10)",
                    "usage": "DISPLAY",
                    "description": "Tipo do arquivo",
                    "business_meaning": "Classificação do tipo de arquivo processado"
                }
            ]
        }

    def _analyze_e3_file(self, logical_name: str, code: str, copybooks: Dict[str, str]) -> Dict[str, Any]:
        """Análise específica para arquivos E3 (dados principais)."""
        return {
            "record_size": 80,
            "description": "Arquivo de dados principais para processamento",
            "business_purpose": "Dados principais para particionamento",
            "fields": [
                {
                    "name": "TIPO-REGISTRO",
                    "position": 1,
                    "length": 2,
                    "type": "alphanumeric",
                    "picture": "X(02)",
                    "usage": "DISPLAY",
                    "description": "Tipo do registro",
                    "business_meaning": "Classificação do registro (01, 02, 03)"
                },
                {
                    "name": "DADOS-REGISTRO",
                    "position": 3,
                    "length": 78,
                    "type": "alphanumeric",
                    "picture": "X(78)",
                    "usage": "DISPLAY",
                    "description": "Dados do registro",
                    "business_meaning": "Conteúdo principal do registro"
                }
            ]
        }

    def _analyze_e4_file(self, logical_name: str, code: str, copybooks: Dict[str, str]) -> Dict[str, Any]:
        """Análise específica para arquivos E4 (relacionamento)."""
        return {
            "record_size": 80,
            "description": "Arquivo de relacionamento e quantidades para validação",
            "business_purpose": "Relacionamentos e quantidades para validação",
            "fields": [
                {
                    "name": "RELA-IDT",
                    "position": 1,
                    "length": 5,
                    "type": "alphanumeric",
                    "picture": "X(05)",
                    "usage": "DISPLAY",
                    "description": "Identificação do relacionamento",
                    "business_meaning": "Chave de relacionamento entre registros"
                },
                {
                    "name": "RELA-QTDE",
                    "position": 6,
                    "length": 15,
                    "type": "numeric",
                    "picture": "9(15)",
                    "usage": "DISPLAY",
                    "description": "Quantidade do relacionamento",
                    "business_meaning": "Quantidade associada ao relacionamento"
                }
            ]
        }

    def _analyze_e5_file(self, logical_name: str, code: str, copybooks: Dict[str, str]) -> Dict[str, Any]:
        """Análise específica para arquivos E5 (responsável)."""
        return {
            "record_size": 154,
            "description": "Arquivo de dados do responsável (CADOC3040)",
            "business_purpose": "Dados do responsável para compliance CADOC3040",
            "fields": [
                {
                    "name": "CPF-RESPONSAVEL",
                    "position": 1,
                    "length": 11,
                    "type": "numeric",
                    "picture": "9(11)",
                    "usage": "DISPLAY",
                    "description": "CPF do responsável",
                    "business_meaning": "Documento de identificação do responsável"
                },
                {
                    "name": "NOME-RESPONSAVEL",
                    "position": 12,
                    "length": 60,
                    "type": "alphanumeric",
                    "picture": "X(60)",
                    "usage": "DISPLAY",
                    "description": "Nome do responsável",
                    "business_meaning": "Nome completo do responsável"
                },
                {
                    "name": "DADOS-ADICIONAIS",
                    "position": 72,
                    "length": 83,
                    "type": "alphanumeric",
                    "picture": "X(83)",
                    "usage": "DISPLAY",
                    "description": "Dados adicionais do responsável",
                    "business_meaning": "Informações complementares para compliance"
                }
            ]
        }

    def _analyze_generic_file(self, logical_name: str, code: str, copybooks: Dict[str, str]) -> Dict[str, Any]:
        """Análise genérica para arquivos não padronizados."""
        return {
            "record_size": 80,
            "description": "Arquivo de entrada para processamento",
            "business_purpose": "Dados de entrada para processamento do programa",
            "fields": [
                {
                    "name": "REGISTRO-COMPLETO",
                    "position": 1,
                    "length": 80,
                    "type": "alphanumeric",
                    "picture": "X(80)",
                    "usage": "DISPLAY",
                    "description": "Registro completo",
                    "business_meaning": "Dados completos do registro"
                }
            ]
        }

    def _analyze_file_context(self, logical_name: str, code: str) -> Dict[str, Any]:
        """Analisa o contexto de uso do arquivo no código."""
        lines = code.split('\n')
        context = {
            "processing_logic": "Processamento sequencial",
            "validation_rules": [],
            "usage_context": "Não determinado"
        }
        
        # Procura por referências ao arquivo no código
        for line in lines:
            line_upper = line.upper()
            
            if logical_name.upper() in line_upper:
                # Identifica operações
                if "READ" in line_upper:
                    context["processing_logic"] = "Leitura sequencial de registros"
                elif "OPEN" in line_upper:
                    if "INPUT" in line_upper:
                        context["usage_context"] = "Arquivo de entrada aberto para leitura"
                elif "CLOSE" in line_upper:
                    context["usage_context"] += " e fechado após processamento"
                
                # Identifica validações
                if "IF" in line_upper and ("=" in line or "NOT" in line):
                    context["validation_rules"].append("Validação de conteúdo do registro")
        
        return context

    def _analyze_with_llm(self, program_name: str, code: str, mentioned_files: List[Dict], 
                         copybooks: Dict[str, str]) -> List[Dict[str, Any]]:
        """Análise usando LLM (se disponível)."""
        if not self.llm_provider:
            return []
        
        try:
            # Usa o provedor Openanálise para análise
            if hasattr(self.llm_provider, 'analyze_cobol_files'):
                result = self.llm_provider.analyze_cobol_files(
                    program_name, code, copybooks, mentioned_files
                )
                return result.get("input_files", [])
            else:
                # Fallback para método genérico
                prompt = self._build_llm_prompt(program_name, code, mentioned_files, copybooks)
                response = self.llm_provider.generate_text(prompt)
                return self._parse_llm_response(response)
        except Exception as e:
            self.logger.error(f"Erro na análise LLM: {e}")
            return []

    def _build_llm_prompt(self, program_name: str, code: str, mentioned_files: List[Dict], 
                         copybooks: Dict[str, str]) -> str:
        """Constrói prompt para LLM."""
        code_sample = code[:4000] + "..." if len(code) > 4000 else code
        
        prompt = f"""Analise este programa COBOL e forneça estruturas detalhadas dos arquivos de entrada:

PROGRAMA: {program_name}

CÓDIGO:
{code_sample}

ARQUIVOS MENCIONADOS:
{[f['logical_name'] for f in mentioned_files if f['type'] == 'input']}

Forneça resposta em formato YAML:
```yaml
input_files:
  - logical_name: "nome"
    record_size: 999
    fields:
      - name: "CAMPO"
        position: 1
        length: 10
        type: "numeric"
        picture: "9(10)"
        description: "Descrição específica"
```
"""
        return prompt

    def _parse_llm_response(self, response: str) -> List[Dict[str, Any]]:
        """Processa resposta do LLM."""
        try:
            yaml_match = re.search(r"```yaml\n(.*?)\n```", response, re.DOTALL)
            if yaml_match:
                parsed = yaml.safe_load(yaml_match.group(1))
                return parsed.get("input_files", [])
        except Exception as e:
            self.logger.error(f"Erro ao processar resposta LLM: {e}")
        
        return []

    def _merge_analyses(self, intelligent_analysis: List[Dict], 
                       llm_analysis: List[Dict]) -> List[Dict[str, Any]]:
        """Combina análise inteligente com análise do LLM."""
        # Por enquanto, prioriza a análise inteligente e complementa com LLM
        merged = intelligent_analysis.copy()
        
        # Adiciona informações do LLM que não estão na análise inteligente
        for llm_file in llm_analysis:
            logical_name = llm_file.get("logical_name")
            
            # Encontra arquivo correspondente na análise inteligente
            for i, intel_file in enumerate(merged):
                if intel_file.get("logical_name") == logical_name:
                    # Mescla informações
                    if llm_file.get("fields") and len(llm_file["fields"]) > len(intel_file.get("fields", [])):
                        merged[i]["fields"] = llm_file["fields"]
                    if llm_file.get("description") and "específica" in llm_file["description"]:
                        merged[i]["description"] = llm_file["description"]
                    break
        
        return merged
