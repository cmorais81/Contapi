# Manual Completo - COBOL Analysis Engine v2.0

## 🎯 O que este sistema faz

O **COBOL Analysis Engine v2.0** analisa programas COBOL e explica de forma simples:

- **O que o programa faz** (objetivo principal)
- **Quais são as regras de negócio** importantes
- **Se há particularidades** que merecem atenção

### Exemplo de Entrada e Saída

**Entrada:** Arquivo `fontes.txt` com programas COBOL
```
VMEMBER NAME  LHAN0542
V      ******************** OBJETIVO DO PROGRAMA ***********************
V      *** PARTICIONAR ARQUIVO BACEN DOC3040                          **
V      **  SERAO GERADOS ARQUIVOS PARTICIONADOS DINAMICAMENTE         **
```

**Saída:** Relatório explicativo
```markdown
## 🎯 O que este programa faz
Este programa particiona arquivos do BACEN DOC3040, dividindo-os em 
arquivos menores para facilitar a transmissão.

## 📋 Regras de Negócio
1. Limite máximo de 50.000 registros por partição
2. Validação obrigatória do tipo de registro
3. Roteamento automático baseado no tipo
```

---

## 🚀 Instalação e Configuração

### 1. Instalação Básica

```bash
# Extrair o sistema
tar -xzf cobol_analysis_engine_v2.0_FINAL.tar.gz
cd v2.0_clean

# Instalar dependências
pip install -r requirements.txt
```

### 2. Configurar LuzIA (IA Principal)

```bash
# Configurar credenciais
export LUZIA_CLIENT_ID="seu_client_id"
export LUZIA_CLIENT_SECRET="seu_client_secret"

# Testar conectividade
python3.11 main.py --status
```

**Resultado esperado:**
```
✅ LUZIA: Conectado
   Modelo: azure-gpt-4o-mini
```

---

## 📋 Uso Básico

### Comandos Principais

```bash
# 1. Verificar se está funcionando
python3.11 main.py --status

# 2. Analisar um programa
python3.11 main.py examples/LHAN0542_TESTE.cbl -o resultados/

# 3. Analisar múltiplos programas
python3.11 main.py examples/fontes.txt -o resultados/ -b examples/BOOKS.txt

# 4. Ver ajuda
python3.11 main.py --help
```

### Parâmetros Disponíveis

| Comando | O que faz | Exemplo |
|---------|-----------|---------|
| `--status` | Testa conectividade com IAs | `python3.11 main.py --status` |
| `-o DIR` | Define onde salvar resultados | `-o meus_resultados/` |
| `-b FILE` | Inclui copybooks na análise | `-b examples/BOOKS.txt` |
| `-m MODE` | Escolhe modo de análise | `-m enhanced` |
| `-v` | Mostra detalhes durante execução | `-v` |

---

## 📁 Estrutura dos Arquivos

### Arquivo fontes.txt
Contém múltiplos programas COBOL no formato:

```
VMEMBER NAME  LHAN0542                    ← Nome do programa
 ----+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----8 
V       IDENTIFICATION                  DIVISION.
V       PROGRAM-ID.     LHAN0542.
V       AUTHOR.         EDIVALDO-DEDIC/GPTI.
V      ******************** OBJETIVO DO PROGRAMA ***********************
V      *** PARTICIONAR ARQUIVO BACEN DOC3040                          **
...código COBOL...

VMEMBER NAME  LHAN0705                    ← Próximo programa
V       IDENTIFICATION                  DIVISION.
...
```

### Arquivo BOOKS.txt
Contém copybooks (estruturas de dados compartilhadas):

```
VMEMBER NAME  LHCP3402                    ← Nome do copybook
V      *  BOOK -> LHCP0402
V      *  AREA DAS TABELAS DE CONSISTENCIAS DOS CODIGOS DO BANCO CENTRAL
V       01 TB-ANEXO-01.
V          05 TABELA-01.
V             10 FILLER                  PIC X(080)   VALUE
V                '020 LIMITE DE CREDITO COM VENCIMENTO ATE 360 DIAS'.
...
```

---

## 📄 O que você recebe

### Relatório de Análise
Para cada programa, o sistema gera um arquivo `.md` com:

```markdown
# Análise do Programa COBOL: LHAN0542

## 🎯 O que este programa faz
**Objetivo:** Particionar arquivo BACEN DOC3040
**Explicação:** Este programa divide arquivos grandes em partes menores...

## 📋 Regras de Negócio
1. Limite de 50.000 registros por arquivo
2. Validação de tipo de registro obrigatória
3. Roteamento automático por tipo

## ⚠️ Particularidades
- Usa particionamento dinâmico
- Requer validação cuidadosa da entrada

## 📁 Arquivos processados
- LHS542E1: Entrada principal
- LHS542S1: Saída particionada

## 🔍 Detalhes da Análise
**Prompt enviado para LuzIA:**
```
Analise o programa COBOL: LHAN0542...
```

**Resposta do LuzIA:**
```
Este programa tem como objetivo...
```
```

---

## ⚙️ Configuração Avançada

### Arquivo config/config.yaml

```yaml
# IA principal
ai:
  primary_provider: "luzia"
  
  providers:
    luzia:
      enabled: true
      client_id: ${LUZIA_CLIENT_ID}
      client_secret: ${LUZIA_CLIENT_SECRET}
      model: "azure-gpt-4o-mini"
      temperature: 0.1
      
    # Outras IAs (opcionais)
    openai:
      enabled: false
      api_key: ${OPENAI_API_KEY}

# Logs
logging:
  level: "INFO"
  dir: "logs"
```

### Arquivo config/prompts.yaml

```yaml
# Prompt principal enviado para LuzIA
main_analysis:
  system_prompt: |
    Você é um especialista em análise de código COBOL.
    Explique de forma simples:
    1. O QUE o programa faz
    2. QUAIS são as regras importantes
    3. SE HÁ particularidades
    
  user_prompt_template: |
    Analise o programa: {program_name}
    
    Código COBOL:
    {cobol_code}
    
    Copybooks disponíveis:
    {copybooks_info}
    
    Seja objetivo e use linguagem clara.
```

---

## 🔧 Exemplos Práticos

### 1. Análise Individual

```bash
# Analisar um programa específico
python3.11 main.py examples/LHAN0542_TESTE.cbl -o analise_individual/

# Resultado
🔍 Detectado programa COBOL: examples/LHAN0542_TESTE.cbl
⚙️ Análise individual iniciada...
✅ Análise concluída com sucesso!
📄 Relatório: LHAN0542_TESTE_ENHANCED_ANALYSIS.md
⏱️ Tempo total: 12.5s
```

### 2. Análise com Copybooks

```bash
# Incluir copybooks para análise mais completa
python3.11 main.py examples/LHAN0542_TESTE.cbl -o analise_completa/ -b examples/BOOKS.txt

# O sistema automaticamente:
# 1. Lê o programa COBOL
# 2. Identifica copybooks relacionados no BOOKS.txt
# 3. Inclui informações dos copybooks na análise
# 4. Gera relatório enriquecido
```

### 3. Processamento em Lote

```bash
# Analisar todos os programas do fontes.txt
python3.11 main.py examples/fontes.txt -o lote_completo/ -b examples/BOOKS.txt

# Resultado
🔍 Detectado arquivo fontes.txt: examples/fontes.txt
📁 Processamento em lote iniciado...
🎉 Processamento em lote concluído!
📈 5/5 programas processados com sucesso
Encontrados 11 copybooks integrados
⏱️ Tempo total: 45.2s

# Arquivos gerados:
# - LHAN0542_ENHANCED_ANALYSIS.md
# - LHAN0705_ENHANCED_ANALYSIS.md
# - LHAN0706_ENHANCED_ANALYSIS.md
# - LHBR0700_ENHANCED_ANALYSIS.md
# - MZAN6056_ENHANCED_ANALYSIS.md
# - BATCH_PROCESSING_SUMMARY.md
```

### 4. Verificação de Status

```bash
# Testar todas as IAs configuradas
python3.11 main.py --status

# Resultado detalhado
🔍 Verificando conectividade com provedores de IA...
============================================================
✅ LUZIA: Conectado
   Modelo: azure-gpt-4o-mini
   Endpoint: https://gut-api-aws.santanderbr.dev.corp/genai_services/v1/

⚪ OPENAI: Desabilitado

❌ DATABRICKS: Falha na conexão
   Erro: workspace_url é obrigatório

============================================================
💡 Para configurar um provedor:
   - LuzIA: Configure LUZIA_CLIENT_ID e LUZIA_CLIENT_SECRET
   - OpenAI: Configure OPENAI_API_KEY
```

---

## 🆘 Solução de Problemas

### 1. LuzIA não conecta

```bash
# Verificar variáveis de ambiente
echo $LUZIA_CLIENT_ID
echo $LUZIA_CLIENT_SECRET

# Se estiverem vazias, configurar:
export LUZIA_CLIENT_ID="seu_client_id"
export LUZIA_CLIENT_SECRET="seu_client_secret"

# Testar novamente
python3.11 main.py --status
```

### 2. Arquivo não encontrado

```bash
# Verificar se os arquivos existem
ls -la examples/fontes.txt
ls -la examples/BOOKS.txt
ls -la examples/LHAN0542_TESTE.cbl

# Se não existirem, verificar se está no diretório correto
pwd
cd v2.0_clean
```

### 3. Erro de permissão

```bash
# Criar diretório de saída
mkdir -p resultados/
chmod 755 resultados/

# Verificar permissões
ls -la resultados/
```

### 4. Análise muito lenta

```bash
# Usar modo rápido para teste
python3.11 main.py programa.cbl -o teste/ -m traditional

# Verificar conectividade
python3.11 main.py --status

# Ver logs para identificar problema
tail -f logs/cobol_analysis.log
```

### 5. Erro de SSL/Certificado

```bash
# Desabilitar verificação SSL (apenas para desenvolvimento)
export SSL_VERIFY="false"

# Ou configurar certificado específico
export SSL_CERT_PATH="/caminho/para/certificado.pem"
```

---

## 📊 Modos de Análise

### Enhanced (Recomendado)
- **O que faz**: Análise completa com LuzIA
- **Tempo**: 10-30 segundos por programa
- **Resultado**: Relatório detalhado explicando objetivo, regras e particularidades
- **Quando usar**: Para documentação completa e compreensão do programa

### Multi-AI
- **O que faz**: Análise com múltiplas IAs (se configuradas)
- **Tempo**: 15-45 segundos por programa
- **Resultado**: Análise estrutural detalhada
- **Quando usar**: Quando múltiplas IAs estão disponíveis

### Traditional
- **O que faz**: Análise rápida sem IA
- **Tempo**: < 1 segundo por programa
- **Resultado**: Estrutura básica do programa
- **Quando usar**: Para análise rápida ou quando IAs não estão disponíveis

---

## 🔍 Personalização de Prompts

### Modificar Prompts

Edite o arquivo `config/prompts.yaml`:

```yaml
main_analysis:
  system_prompt: |
    # Personalize aqui o comportamento da IA
    Você é um especialista em sistemas bancários COBOL.
    Foque em aspectos de compliance e auditoria.
    
  user_prompt_template: |
    # Personalize aqui o que é enviado para análise
    Analise este programa bancário: {program_name}
    
    Código: {cobol_code}
    
    Foque em:
    - Controles de auditoria
    - Validações de compliance
    - Riscos operacionais
```

### Prompts por Domínio

```yaml
# Para sistemas bancários
banking_analysis:
  focus_areas:
    - "Regulamentações do BACEN"
    - "Controles de auditoria"
    - "Validações financeiras"
    
# Para sistemas de seguros
insurance_analysis:
  focus_areas:
    - "Regulamentações da SUSEP"
    - "Cálculos atuariais"
    - "Processamento de sinistros"
```

---

## 📈 Integração e Automação

### Script de Automação

```bash
#!/bin/bash
# analise_automatica.sh

# Configurar ambiente
export LUZIA_CLIENT_ID="seu_client_id"
export LUZIA_CLIENT_SECRET="seu_client_secret"

# Data atual para organizar resultados
DATA=$(date +%Y%m%d_%H%M)

# Executar análise
echo "Iniciando análise automática..."
python3.11 main.py fontes.txt -o "resultados_$DATA" -b BOOKS.txt

# Verificar resultados
if [ $? -eq 0 ]; then
    echo "✅ Análise concluída com sucesso!"
    echo "📁 Resultados em: resultados_$DATA"
    ls -la "resultados_$DATA"
else
    echo "❌ Erro na análise"
    exit 1
fi
```

### Integração com CI/CD

```yaml
# .github/workflows/cobol-analysis.yml
name: Análise COBOL Automática
on:
  push:
    paths:
      - '**/*.cbl'
      - 'fontes.txt'

jobs:
  analyze:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout código
        uses: actions/checkout@v3
        
      - name: Setup Python
        uses: actions/setup-python@v4
        with:
          python-version: '3.11'
          
      - name: Instalar dependências
        run: |
          pip install -r requirements.txt
          
      - name: Executar análise
        run: |
          python3.11 main.py fontes.txt -o analysis_results/ -b BOOKS.txt
        env:
          LUZIA_CLIENT_ID: ${{ secrets.LUZIA_CLIENT_ID }}
          LUZIA_CLIENT_SECRET: ${{ secrets.LUZIA_CLIENT_SECRET }}
          
      - name: Upload resultados
        uses: actions/upload-artifact@v3
        with:
          name: cobol-analysis-results
          path: analysis_results/
```

---

## 📞 Suporte e Recursos

### Estrutura de Arquivos

```
v2.0_clean/
├── main.py                    # ← Aplicação principal
├── config/
│   ├── config.yaml           # ← Configuração das IAs
│   └── prompts.yaml          # ← Prompts personalizáveis
├── examples/
│   ├── fontes.txt           # ← Programas de exemplo
│   ├── BOOKS.txt            # ← Copybooks de exemplo
│   └── LHAN0542_TESTE.cbl   # ← Programa individual
├── docs/
│   └── MANUAL_COMPLETO_CONFIGURACAO_USO.md  # ← Este manual
├── src/                      # ← Código fonte do sistema
└── logs/                     # ← Logs de execução
```

### Logs e Debug

```bash
# Ver logs em tempo real
tail -f logs/cobol_analysis.log

# Buscar erros específicos
grep -i "error\|exception" logs/cobol_analysis.log

# Executar com debug detalhado
python3.11 main.py programa.cbl -o debug/ -v
```

### Arquivos de Configuração

- **config/config.yaml**: Configuração principal das IAs
- **config/prompts.yaml**: Personalização dos prompts
- **requirements.txt**: Dependências Python
- **README.md**: Guia de início rápido

---

## 🎯 Casos de Uso Comuns

### 1. Documentação de Sistema Legado
```bash
# Analisar todo o sistema
python3.11 main.py sistema_completo/fontes.txt -o documentacao/ -b sistema_completo/BOOKS.txt

# Resultado: Documentação completa de todos os programas
```

### 2. Auditoria de Código
```bash
# Análise focada em compliance
python3.11 main.py programas_criticos.txt -o auditoria/ -b BOOKS.txt

# Personalizar prompts para focar em controles
```

### 3. Migração de Sistema
```bash
# Análise para planejamento de migração
python3.11 main.py fontes_migracao.txt -o analise_migracao/ -b BOOKS.txt

# Resultado: Entendimento completo para planejar migração
```

### 4. Treinamento de Equipe
```bash
# Gerar documentação educativa
python3.11 main.py exemplos_treinamento.txt -o material_treinamento/ -b BOOKS.txt

# Resultado: Material didático sobre os programas
```

---

**COBOL Analysis Engine v2.0**  
*Manual Completo de Configuração e Uso*  
*Sistema que explica o que programas COBOL fazem de forma simples e clara*
