# Resumo do Processamento em Lote

- **Total de Programas:** 1
- **Sucesso:** 0
- **Falha:** 1

| Programa | Status | Detalhes |
|---|---|---|
| LHAN0542 | error | Erro ao processar LHAN0542: IntelligentDocumentationGenerator._build_prompts_section() takes 1 positional argument but 3 were given |
