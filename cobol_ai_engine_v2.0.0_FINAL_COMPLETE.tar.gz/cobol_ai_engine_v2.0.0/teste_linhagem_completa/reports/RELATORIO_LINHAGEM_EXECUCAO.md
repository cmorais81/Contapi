# Relatório de Linhagem e Fluxo de Execução

**Data de Geração:** 13/09/2025 17:46:39  
**Versão do Sistema:** COBOL AI Engine v2.0.0

---

## Resumo Executivo

Este relatório apresenta a análise completa de linhagem e fluxo de execução dos programas COBOL, 
incluindo sequências de execução, dependências e oportunidades de otimização.

### Estatísticas do Fluxo de Execução

| Métrica | Valor |
|---------|-------|
| **Total de Programas** | 36 |
| **Sequências Identificadas** | 39 |
| **Pontos de Entrada** | 5 |
| **Pontos Terminais** | 31 |
| **Total de Dependências** | 35 |
| **Máx. Dependências por Programa** | 14 |
| **Média de Dependências** | 0.97 |

---

## Pontos de Entrada e Saída

### 🚀 Pontos de Entrada (Programas Iniciais)
- **LHAN0542**
- **MZAN6056**
- **LHBR0700**
- **LHAN0705**
- **LHAN0706**


### 🏁 Pontos Terminais (Programas Finais)
- **LHS542E5**
- **CT-MZ9CV001**
- **LHCP3402**
- **S1DQ0705**
- **S1DQ6056**
- **S1DQ0706**
- **E2DQ6056**
- **CT-DRAM0038**
- **LHS542E2**
- **MZ**
- **S2DQ0705**
- **LHS542E3**
- **MZV5002E**
- **E1DQ0706**
- **E1DQ0705**
- **LHCE0700**
- **CT-DRAM0022**
- **LHS542E4**
- **WDRAM0082**
- **E2DQ0706**
- **CT-LHBR0700**
- **CT-DRAM0018**
- **LHS542S1**
- **S2DQ0706**
- **MZTCM530**
- **LHS542S3**
- **DOS**
- **LHS542S2**
- **E1DQ6056**
- **LHS542E1**
- **CT-DRAM0152**


---

## Ordem de Execução dos Programas

### Sequência Recomendada de Execução

| Ordem | Nível | Programa |
|-------|-------|----------|
| 1 | 0 | **LHAN0542** |
| 2 | 0 | **MZAN6056** |
| 3 | 0 | **LHBR0700** |
| 4 | 0 | **LHAN0705** |
| 5 | 0 | **LHAN0706** |
| 6 | 1 | **LHS542S3** |
| 7 | 1 | **LHS542E5** |
| 8 | 1 | **LHS542E1** |
| 9 | 1 | **LHS542E2** |
| 10 | 1 | **LHS542E3** |
| 11 | 1 | **LHS542E4** |
| 12 | 1 | **MZTCM530** |
| 13 | 1 | **LHS542S1** |
| 14 | 1 | **LHS542S2** |
| 15 | 1 | **WDRAM0082** |
| 16 | 1 | **E1DQ6056** |
| 17 | 1 | **E2DQ6056** |
| 18 | 1 | **S1DQ6056** |
| 19 | 1 | **E1DQ0705** |
| 20 | 1 | **S1DQ0705** |
| 21 | 1 | **S2DQ0705** |
| 22 | 1 | **MZV5002E** |
| 23 | 1 | **LHCP3402** |
| 24 | 1 | **DOS** |
| 25 | 1 | **CT-MZ9CV001** |
| 26 | 1 | **MZ** |
| 27 | 1 | **CT-DRAM0152** |
| 28 | 1 | **CT-DRAM0022** |
| 29 | 1 | **CT-DRAM0038** |
| 30 | 1 | **E1DQ0706** |
| 31 | 1 | **E2DQ0706** |
| 32 | 1 | **S1DQ0706** |
| 33 | 1 | **S2DQ0706** |
| 34 | 1 | **LHCE0700** |
| 35 | 1 | **CT-LHBR0700** |
| 36 | 1 | **CT-DRAM0018** |


---

## Sequências de Execução Identificadas

### Sequência 1: SEQ_LHAN0542_LINEAR_0
**Tipo:** LINEAR
**Ponto de Entrada:** LHAN0542
**Total de Programas:** 2
**Caminho:** LHAN0542 → LHS542S3
**Descrição:** Sequência linear: LHAN0542 -> LHS542S3

### Sequência 2: SEQ_LHAN0542_LINEAR_1
**Tipo:** LINEAR
**Ponto de Entrada:** LHAN0542
**Total de Programas:** 2
**Caminho:** LHAN0542 → LHS542E5
**Descrição:** Sequência linear: LHAN0542 -> LHS542E5

### Sequência 3: SEQ_LHAN0542_LINEAR_2
**Tipo:** LINEAR
**Ponto de Entrada:** LHAN0542
**Total de Programas:** 2
**Caminho:** LHAN0542 → LHS542E1
**Descrição:** Sequência linear: LHAN0542 -> LHS542E1

### Sequência 4: SEQ_LHAN0542_LINEAR_3
**Tipo:** LINEAR
**Ponto de Entrada:** LHAN0542
**Total de Programas:** 2
**Caminho:** LHAN0542 → LHS542E2
**Descrição:** Sequência linear: LHAN0542 -> LHS542E2

### Sequência 5: SEQ_LHAN0542_LINEAR_4
**Tipo:** LINEAR
**Ponto de Entrada:** LHAN0542
**Total de Programas:** 2
**Caminho:** LHAN0542 → LHS542E3
**Descrição:** Sequência linear: LHAN0542 -> LHS542E3

### Sequência 6: SEQ_LHAN0542_LINEAR_5
**Tipo:** LINEAR
**Ponto de Entrada:** LHAN0542
**Total de Programas:** 2
**Caminho:** LHAN0542 → LHS542E4
**Descrição:** Sequência linear: LHAN0542 -> LHS542E4

### Sequência 7: SEQ_LHAN0542_LINEAR_6
**Tipo:** LINEAR
**Ponto de Entrada:** LHAN0542
**Total de Programas:** 2
**Caminho:** LHAN0542 → MZTCM530
**Descrição:** Sequência linear: LHAN0542 -> MZTCM530

### Sequência 8: SEQ_LHAN0542_LINEAR_7
**Tipo:** LINEAR
**Ponto de Entrada:** LHAN0542
**Total de Programas:** 2
**Caminho:** LHAN0542 → LHS542S1
**Descrição:** Sequência linear: LHAN0542 -> LHS542S1

### Sequência 9: SEQ_LHAN0542_LINEAR_8
**Tipo:** LINEAR
**Ponto de Entrada:** LHAN0542
**Total de Programas:** 2
**Caminho:** LHAN0542 → LHS542S2
**Descrição:** Sequência linear: LHAN0542 -> LHS542S2

### Sequência 10: SEQ_LHAN0542_LINEAR_9
**Tipo:** LINEAR
**Ponto de Entrada:** LHAN0542
**Total de Programas:** 2
**Caminho:** LHAN0542 → WDRAM0082
**Descrição:** Sequência linear: LHAN0542 -> WDRAM0082

### Sequência 11: SEQ_LHAN0542_PARALLEL_10
**Tipo:** PARALLEL
**Ponto de Entrada:** LHAN0542
**Total de Programas:** 11
**Caminho:** LHAN0542 → LHS542S3 → LHS542E5 → LHS542E1 → LHS542E2 → LHS542E3 → LHS542E4 → MZTCM530 → LHS542S1 → LHS542S2 → WDRAM0082
**Descrição:** Execução paralela de LHAN0542: LHS542S3, LHS542E5, LHS542E1, LHS542E2, LHS542E3, LHS542E4, MZTCM530, LHS542S1, LHS542S2, WDRAM0082

### Sequência 12: SEQ_MZAN6056_LINEAR_0
**Tipo:** LINEAR
**Ponto de Entrada:** MZAN6056
**Total de Programas:** 2
**Caminho:** MZAN6056 → E1DQ6056
**Descrição:** Sequência linear: MZAN6056 -> E1DQ6056

### Sequência 13: SEQ_MZAN6056_LINEAR_1
**Tipo:** LINEAR
**Ponto de Entrada:** MZAN6056
**Total de Programas:** 2
**Caminho:** MZAN6056 → E2DQ6056
**Descrição:** Sequência linear: MZAN6056 -> E2DQ6056

### Sequência 14: SEQ_MZAN6056_LINEAR_2
**Tipo:** LINEAR
**Ponto de Entrada:** MZAN6056
**Total de Programas:** 2
**Caminho:** MZAN6056 → S1DQ6056
**Descrição:** Sequência linear: MZAN6056 -> S1DQ6056

### Sequência 15: SEQ_MZAN6056_PARALLEL_3
**Tipo:** PARALLEL
**Ponto de Entrada:** MZAN6056
**Total de Programas:** 4
**Caminho:** MZAN6056 → E1DQ6056 → E2DQ6056 → S1DQ6056
**Descrição:** Execução paralela de MZAN6056: E1DQ6056, E2DQ6056, S1DQ6056

### Sequência 16: SEQ_LHBR0700_LINEAR_0
**Tipo:** LINEAR
**Ponto de Entrada:** LHBR0700
**Total de Programas:** 2
**Caminho:** LHBR0700 → LHCE0700
**Descrição:** Sequência linear: LHBR0700 -> LHCE0700

### Sequência 17: SEQ_LHAN0705_LINEAR_0
**Tipo:** LINEAR
**Ponto de Entrada:** LHAN0705
**Total de Programas:** 2
**Caminho:** LHAN0705 → E1DQ0705
**Descrição:** Sequência linear: LHAN0705 -> E1DQ0705

### Sequência 18: SEQ_LHAN0705_LINEAR_1
**Tipo:** LINEAR
**Ponto de Entrada:** LHAN0705
**Total de Programas:** 2
**Caminho:** LHAN0705 → S1DQ0705
**Descrição:** Sequência linear: LHAN0705 -> S1DQ0705

### Sequência 19: SEQ_LHAN0705_LINEAR_2
**Tipo:** LINEAR
**Ponto de Entrada:** LHAN0705
**Total de Programas:** 2
**Caminho:** LHAN0705 → S2DQ0705
**Descrição:** Sequência linear: LHAN0705 -> S2DQ0705

### Sequência 20: SEQ_LHAN0705_LINEAR_3
**Tipo:** LINEAR
**Ponto de Entrada:** LHAN0705
**Total de Programas:** 2
**Caminho:** LHAN0705 → MZV5002E
**Descrição:** Sequência linear: LHAN0705 -> MZV5002E

### Sequência 21: SEQ_LHAN0705_LINEAR_4
**Tipo:** LINEAR
**Ponto de Entrada:** LHAN0705
**Total de Programas:** 2
**Caminho:** LHAN0705 → LHCP3402
**Descrição:** Sequência linear: LHAN0705 -> LHCP3402

### Sequência 22: SEQ_LHAN0705_LINEAR_5
**Tipo:** LINEAR
**Ponto de Entrada:** LHAN0705
**Total de Programas:** 2
**Caminho:** LHAN0705 → LHCE0700
**Descrição:** Sequência linear: LHAN0705 -> LHCE0700

### Sequência 23: SEQ_LHAN0705_LINEAR_6
**Tipo:** LINEAR
**Ponto de Entrada:** LHAN0705
**Total de Programas:** 2
**Caminho:** LHAN0705 → DOS
**Descrição:** Sequência linear: LHAN0705 -> DOS

### Sequência 24: SEQ_LHAN0705_LINEAR_7
**Tipo:** LINEAR
**Ponto de Entrada:** LHAN0705
**Total de Programas:** 2
**Caminho:** LHAN0705 → CT-MZ9CV001
**Descrição:** Sequência linear: LHAN0705 -> CT-MZ9CV001

### Sequência 25: SEQ_LHAN0705_LINEAR_8
**Tipo:** LINEAR
**Ponto de Entrada:** LHAN0705
**Total de Programas:** 2
**Caminho:** LHAN0705 → MZ
**Descrição:** Sequência linear: LHAN0705 -> MZ

### Sequência 26: SEQ_LHAN0705_LINEAR_9
**Tipo:** LINEAR
**Ponto de Entrada:** LHAN0705
**Total de Programas:** 2
**Caminho:** LHAN0705 → CT-LHBR0700
**Descrição:** Sequência linear: LHAN0705 -> CT-LHBR0700

### Sequência 27: SEQ_LHAN0705_LINEAR_10
**Tipo:** LINEAR
**Ponto de Entrada:** LHAN0705
**Total de Programas:** 2
**Caminho:** LHAN0705 → CT-DRAM0152
**Descrição:** Sequência linear: LHAN0705 -> CT-DRAM0152

### Sequência 28: SEQ_LHAN0705_LINEAR_11
**Tipo:** LINEAR
**Ponto de Entrada:** LHAN0705
**Total de Programas:** 2
**Caminho:** LHAN0705 → CT-DRAM0022
**Descrição:** Sequência linear: LHAN0705 -> CT-DRAM0022

### Sequência 29: SEQ_LHAN0705_LINEAR_12
**Tipo:** LINEAR
**Ponto de Entrada:** LHAN0705
**Total de Programas:** 2
**Caminho:** LHAN0705 → CT-DRAM0038
**Descrição:** Sequência linear: LHAN0705 -> CT-DRAM0038

### Sequência 30: SEQ_LHAN0705_LINEAR_13
**Tipo:** LINEAR
**Ponto de Entrada:** LHAN0705
**Total de Programas:** 2
**Caminho:** LHAN0705 → CT-DRAM0018
**Descrição:** Sequência linear: LHAN0705 -> CT-DRAM0018

### Sequência 31: SEQ_LHAN0705_PARALLEL_14
**Tipo:** PARALLEL
**Ponto de Entrada:** LHAN0705
**Total de Programas:** 15
**Caminho:** LHAN0705 → E1DQ0705 → S1DQ0705 → S2DQ0705 → MZV5002E → LHCP3402 → LHCE0700 → DOS → CT-MZ9CV001 → MZ → CT-LHBR0700 → CT-DRAM0152 → CT-DRAM0022 → CT-DRAM0038 → CT-DRAM0018
**Descrição:** Execução paralela de LHAN0705: E1DQ0705, S1DQ0705, S2DQ0705, MZV5002E, LHCP3402, LHCE0700, DOS, CT-MZ9CV001, MZ, CT-LHBR0700, CT-DRAM0152, CT-DRAM0022, CT-DRAM0038, CT-DRAM0018

### Sequência 32: SEQ_LHAN0706_LINEAR_0
**Tipo:** LINEAR
**Ponto de Entrada:** LHAN0706
**Total de Programas:** 2
**Caminho:** LHAN0706 → E1DQ0706
**Descrição:** Sequência linear: LHAN0706 -> E1DQ0706

### Sequência 33: SEQ_LHAN0706_LINEAR_1
**Tipo:** LINEAR
**Ponto de Entrada:** LHAN0706
**Total de Programas:** 2
**Caminho:** LHAN0706 → E2DQ0706
**Descrição:** Sequência linear: LHAN0706 -> E2DQ0706

### Sequência 34: SEQ_LHAN0706_LINEAR_2
**Tipo:** LINEAR
**Ponto de Entrada:** LHAN0706
**Total de Programas:** 2
**Caminho:** LHAN0706 → S1DQ0706
**Descrição:** Sequência linear: LHAN0706 -> S1DQ0706

### Sequência 35: SEQ_LHAN0706_LINEAR_3
**Tipo:** LINEAR
**Ponto de Entrada:** LHAN0706
**Total de Programas:** 2
**Caminho:** LHAN0706 → S2DQ0706
**Descrição:** Sequência linear: LHAN0706 -> S2DQ0706

### Sequência 36: SEQ_LHAN0706_LINEAR_4
**Tipo:** LINEAR
**Ponto de Entrada:** LHAN0706
**Total de Programas:** 2
**Caminho:** LHAN0706 → LHCE0700
**Descrição:** Sequência linear: LHAN0706 -> LHCE0700

### Sequência 37: SEQ_LHAN0706_LINEAR_5
**Tipo:** LINEAR
**Ponto de Entrada:** LHAN0706
**Total de Programas:** 2
**Caminho:** LHAN0706 → CT-LHBR0700
**Descrição:** Sequência linear: LHAN0706 -> CT-LHBR0700

### Sequência 38: SEQ_LHAN0706_LINEAR_6
**Tipo:** LINEAR
**Ponto de Entrada:** LHAN0706
**Total de Programas:** 2
**Caminho:** LHAN0706 → CT-DRAM0018
**Descrição:** Sequência linear: LHAN0706 -> CT-DRAM0018

### Sequência 39: SEQ_LHAN0706_PARALLEL_7
**Tipo:** PARALLEL
**Ponto de Entrada:** LHAN0706
**Total de Programas:** 8
**Caminho:** LHAN0706 → E1DQ0706 → E2DQ0706 → S1DQ0706 → S2DQ0706 → LHCE0700 → CT-LHBR0700 → CT-DRAM0018
**Descrição:** Execução paralela de LHAN0706: E1DQ0706, E2DQ0706, S1DQ0706, S2DQ0706, LHCE0700, CT-LHBR0700, CT-DRAM0018


---

## Caminho Crítico

### Sequência Mais Longa de Execução

**Caminho:** LHAN0705 → E1DQ0705 → S1DQ0705 → S2DQ0705 → MZV5002E → LHCP3402 → LHCE0700 → DOS → CT-MZ9CV001 → MZ → CT-LHBR0700 → CT-DRAM0152 → CT-DRAM0022 → CT-DRAM0038 → CT-DRAM0018

**Total de Programas:** 15

Este é o caminho mais longo de execução identificado no sistema.


---

## Oportunidades de Execução Paralela

### Nível 1
**Programas Paralelos:** LHS542E5, CT-MZ9CV001, LHCP3402, S1DQ0705, S1DQ6056, S1DQ0706, E2DQ6056, CT-DRAM0038, LHS542E2, MZ, S2DQ0705, LHS542E3, MZV5002E, E1DQ0706, E1DQ0705, LHCE0700, CT-DRAM0022, LHS542E4, WDRAM0082, E2DQ0706, CT-LHBR0700, CT-DRAM0018, LHS542S1, S2DQ0706, MZTCM530, LHS542S3, DOS, LHS542S2, E1DQ6056, LHS542E1, CT-DRAM0152
**Fator de Paralelização:** 31x
**Descrição:** Nível 1: 31 programas podem ser executados em paralelo

### Nível 0
**Programas Paralelos:** LHAN0542, MZAN6056, LHBR0700, LHAN0705, LHAN0706
**Fator de Paralelização:** 5x
**Descrição:** Nível 0: 5 programas podem ser executados em paralelo


---

## Linhagem de Dados

### Linhagem de Arquivos
- **LHAN0542** → LHS542S3, LHS542E5, LHS542E1, LHS542E2, LHS542E3, LHS542E4, LHS542E5, LHS542S1, LHS542S2, LHS542S3
- **LHAN0705** → E1DQ0705, S1DQ0705, S2DQ0705, MZV5002E, E1DQ0705, S1DQ0705, S2DQ0705, MZV5002E
- **LHAN0706** → E1DQ0706, E2DQ0706, S1DQ0706, S2DQ0706, E1DQ0706, E2DQ0706, S1DQ0706, S2DQ0706
- **MZAN6056** → E1DQ6056, E2DQ6056, S1DQ6056


### Linhagem de Copybooks
- **LHAN0542** → MZTCM530
- **LHAN0705** → LHCP3402, LHCE0700, DOS
- **LHAN0706** → LHCE0700
- **LHBR0700** → LHCE0700


---

## Distribuição por Tipo de Componente

| Tipo de Componente | Quantidade |
|-------------------|------------|
| PROGRAM | 36 |


---

## Análise Detalhada dos Nós

| Programa | Tipo | Dependências | Dependentes | Ordem | Nível |
|----------|------|--------------|-------------|-------|-------|
| LHS542E5 | PROGRAM | 0 | 1 | 6 | 1 |
| CT-MZ9CV001 | PROGRAM | 0 | 1 | 24 | 1 |
| LHCP3402 | PROGRAM | 0 | 1 | 22 | 1 |
| S1DQ0705 | PROGRAM | 0 | 1 | 19 | 1 |
| LHAN0542 | PROGRAM | 10 | 0 | 0 | 0 |
| MZAN6056 | PROGRAM | 3 | 0 | 1 | 0 |
| S1DQ6056 | PROGRAM | 0 | 1 | 17 | 1 |
| S1DQ0706 | PROGRAM | 0 | 1 | 31 | 1 |
| E2DQ6056 | PROGRAM | 0 | 1 | 16 | 1 |
| CT-DRAM0038 | PROGRAM | 0 | 1 | 28 | 1 |
| LHS542E2 | PROGRAM | 0 | 1 | 8 | 1 |
| MZ | PROGRAM | 0 | 1 | 25 | 1 |
| S2DQ0705 | PROGRAM | 0 | 1 | 20 | 1 |
| LHBR0700 | PROGRAM | 1 | 0 | 2 | 0 |
| LHS542E3 | PROGRAM | 0 | 1 | 9 | 1 |
| MZV5002E | PROGRAM | 0 | 1 | 21 | 1 |
| E1DQ0706 | PROGRAM | 0 | 1 | 29 | 1 |
| E1DQ0705 | PROGRAM | 0 | 1 | 18 | 1 |
| LHCE0700 | PROGRAM | 0 | 3 | 33 | 1 |
| CT-DRAM0022 | PROGRAM | 0 | 1 | 27 | 1 |
| LHS542E4 | PROGRAM | 0 | 1 | 10 | 1 |
| WDRAM0082 | PROGRAM | 0 | 1 | 14 | 1 |
| E2DQ0706 | PROGRAM | 0 | 1 | 30 | 1 |
| CT-LHBR0700 | PROGRAM | 0 | 2 | 34 | 1 |
| CT-DRAM0018 | PROGRAM | 0 | 2 | 35 | 1 |
| LHS542S1 | PROGRAM | 0 | 1 | 12 | 1 |
| S2DQ0706 | PROGRAM | 0 | 1 | 32 | 1 |
| LHAN0705 | PROGRAM | 14 | 0 | 3 | 0 |
| MZTCM530 | PROGRAM | 0 | 1 | 11 | 1 |
| LHS542S3 | PROGRAM | 0 | 1 | 5 | 1 |
| DOS | PROGRAM | 0 | 1 | 23 | 1 |
| LHS542S2 | PROGRAM | 0 | 1 | 13 | 1 |
| E1DQ6056 | PROGRAM | 0 | 1 | 15 | 1 |
| LHS542E1 | PROGRAM | 0 | 1 | 7 | 1 |
| LHAN0706 | PROGRAM | 7 | 0 | 4 | 0 |
| CT-DRAM0152 | PROGRAM | 0 | 1 | 26 | 1 |


---

## Recomendações de Otimização

⚡ **Otimização de Performance:** 2 oportunidades de paralelização identificadas (fator total: 36x)
🔄 **Simplificar Fluxo:** Múltiplas sequências detectadas - considerar consolidação


---

**Relatório gerado automaticamente pelo COBOL AI Engine v2.0.0**  
**Para questões técnicas, consulte a equipe de desenvolvimento**
