"""
Testes para o módulo de exceções customizadas.
"""

import sys
import os
import unittest

# Adicionar o diretório src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from core.exceptions import (
    COBOLAIEngineException, ConfigurationError, ProviderError,
    ProviderNotAvailableError, ProviderAuthenticationError,
    ProviderTimeoutError, ProviderQuotaExceededError,
    FileProcessingError, FileNotFoundError, InvalidFileFormatError,
    COBOLParsingError, DocumentationGenerationError, PDFConversionError,
    ValidationError, TokenLimitExceededError,
    format_error_message, get_user_friendly_message, suggest_solution
)


class TestCOBOLAIEngineExceptions(unittest.TestCase):
    """Testes para as exceções customizadas."""
    
    def test_base_exception(self):
        """Testa a exceção base."""
        exception = COBOLAIEngineException(
            message="Erro de teste",
            error_code="TEST_ERROR",
            details={"key": "value"}
        )
        
        self.assertEqual(exception.message, "Erro de teste")
        self.assertEqual(exception.error_code, "TEST_ERROR")
        self.assertEqual(exception.details, {"key": "value"})
        
        # Testa conversão para dicionário
        error_dict = exception.to_dict()
        self.assertEqual(error_dict["error_type"], "COBOLAIEngineException")
        self.assertEqual(error_dict["error_code"], "TEST_ERROR")
        self.assertEqual(error_dict["message"], "Erro de teste")
        self.assertEqual(error_dict["details"], {"key": "value"})
    
    def test_configuration_error(self):
        """Testa exceção de configuração."""
        exception = ConfigurationError(
            message="Configuração inválida",
            config_file="config.yaml",
            missing_key="api_key"
        )
        
        self.assertEqual(exception.error_code, "CONFIG_ERROR")
        self.assertEqual(exception.details["config_file"], "config.yaml")
        self.assertEqual(exception.details["missing_key"], "api_key")
    
    def test_provider_not_available_error(self):
        """Testa exceção de provedor não disponível."""
        exception = ProviderNotAvailableError(
            provider_name="openai",
            reason="API key inválida"
        )
        
        self.assertEqual(exception.error_code, "PROVIDER_NOT_AVAILABLE")
        self.assertEqual(exception.details["provider_name"], "openai")
        self.assertEqual(exception.details["provider_error"], "API key inválida")
        self.assertIn("openai", exception.message)
        self.assertIn("API key inválida", exception.message)
    
    def test_provider_authentication_error(self):
        """Testa exceção de autenticação."""
        exception = ProviderAuthenticationError(
            provider_name="openai",
            auth_error="Invalid API key"
        )
        
        self.assertEqual(exception.error_code, "PROVIDER_AUTH_ERROR")
        self.assertEqual(exception.details["provider_name"], "openai")
        self.assertEqual(exception.details["provider_error"], "Invalid API key")
    
    def test_provider_timeout_error(self):
        """Testa exceção de timeout."""
        exception = ProviderTimeoutError(
            provider_name="openai",
            timeout_seconds=30
        )
        
        self.assertEqual(exception.error_code, "PROVIDER_TIMEOUT")
        self.assertEqual(exception.details["provider_name"], "openai")
        self.assertIn("30 segundos", exception.message)
    
    def test_provider_quota_exceeded_error(self):
        """Testa exceção de cota excedida."""
        exception = ProviderQuotaExceededError(
            provider_name="openai",
            quota_type="rate_limit"
        )
        
        self.assertEqual(exception.error_code, "PROVIDER_QUOTA_EXCEEDED")
        self.assertEqual(exception.details["provider_name"], "openai")
        self.assertIn("rate_limit", exception.message)
    
    def test_file_not_found_error(self):
        """Testa exceção de arquivo não encontrado."""
        exception = FileNotFoundError(file_path="/path/to/file.txt")
        
        self.assertEqual(exception.error_code, "FILE_NOT_FOUND")
        self.assertEqual(exception.details["file_path"], "/path/to/file.txt")
        self.assertIn("/path/to/file.txt", exception.message)
    
    def test_invalid_file_format_error(self):
        """Testa exceção de formato inválido."""
        exception = InvalidFileFormatError(
            file_path="/path/to/file.txt",
            expected_format="COBOL"
        )
        
        self.assertEqual(exception.error_code, "INVALID_FILE_FORMAT")
        self.assertEqual(exception.details["file_path"], "/path/to/file.txt")
        self.assertEqual(exception.details["file_type"], "COBOL")
    
    def test_cobol_parsing_error(self):
        """Testa exceção de parsing COBOL."""
        exception = COBOLParsingError(
            message="Erro de sintaxe",
            program_name="PROG001",
            line_number=42
        )
        
        self.assertEqual(exception.error_code, "COBOL_PARSING_ERROR")
        self.assertEqual(exception.details["program_name"], "PROG001")
        self.assertEqual(exception.details["line_number"], 42)
    
    def test_pdf_conversion_error(self):
        """Testa exceção de conversão PDF."""
        exception = PDFConversionError(
            message="Falha na conversão",
            input_file="doc.md",
            converter="weasyprint"
        )
        
        self.assertEqual(exception.error_code, "PDF_CONVERSION_ERROR")
        self.assertEqual(exception.details["input_file"], "doc.md")
        self.assertEqual(exception.details["converter"], "weasyprint")
    
    def test_validation_error(self):
        """Testa exceção de validação."""
        exception = ValidationError(
            message="Valor inválido",
            field_name="temperature",
            field_value=2.0
        )
        
        self.assertEqual(exception.error_code, "VALIDATION_ERROR")
        self.assertEqual(exception.details["field_name"], "temperature")
        self.assertEqual(exception.details["field_value"], "2.0")
    
    def test_token_limit_exceeded_error(self):
        """Testa exceção de limite de tokens."""
        exception = TokenLimitExceededError(
            message="Limite excedido",
            current_tokens=5000,
            max_tokens=4000
        )
        
        self.assertEqual(exception.error_code, "TOKEN_LIMIT_EXCEEDED")
        self.assertEqual(exception.details["current_tokens"], 5000)
        self.assertEqual(exception.details["max_tokens"], 4000)
    
    def test_format_error_message(self):
        """Testa formatação de mensagem de erro."""
        exception = ConfigurationError(
            message="Configuração inválida",
            config_file="config.yaml",
            missing_key="api_key"
        )
        
        formatted = format_error_message(exception)
        self.assertIn("[CONFIG_ERROR]", formatted)
        self.assertIn("Configuração inválida", formatted)
        self.assertIn("config_file: config.yaml", formatted)
        self.assertIn("missing_key: api_key", formatted)
    
    def test_get_user_friendly_message(self):
        """Testa mensagem amigável ao usuário."""
        # Testa com exceção customizada
        custom_exception = ConfigurationError("Configuração inválida")
        message = get_user_friendly_message(custom_exception)
        self.assertIn("[CONFIG_ERROR]", message)
        
        # Testa com exceção padrão do Python
        standard_exception = ValueError("Valor inválido")
        message = get_user_friendly_message(standard_exception)
        self.assertIn("[ValueError]", message)
        self.assertIn("Valor inválido fornecido", message)
    
    def test_suggest_solution(self):
        """Testa sugestões de solução."""
        exception = ConfigurationError("Configuração inválida")
        solution = suggest_solution(exception)
        self.assertIsNotNone(solution)
        self.assertIn("arquivo de configuração", solution)
        
        # Testa com código de erro não mapeado
        exception = COBOLAIEngineException("Erro", "UNKNOWN_CODE")
        solution = suggest_solution(exception)
        self.assertIsNone(solution)


def run_tests():
    """Executa todos os testes."""
    print("Executando testes de exceções customizadas...")
    
    # Criar suite de testes
    suite = unittest.TestLoader().loadTestsFromTestCase(TestCOBOLAIEngineExceptions)
    
    # Executar testes
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    # Retornar resultado
    return result.wasSuccessful()


if __name__ == "__main__":
    success = run_tests()
    if success:
        print("\n✅ Todos os testes passaram!")
        sys.exit(0)
    else:
        print("\n❌ Alguns testes falharam!")
        sys.exit(1)

