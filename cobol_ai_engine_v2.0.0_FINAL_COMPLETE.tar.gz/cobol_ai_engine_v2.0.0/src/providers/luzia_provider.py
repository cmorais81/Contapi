"""
Provedor LuzIA para COBOL AI Engine.
Implementação baseada no código funcional fornecido nas imagens.
"""

import os
import json
import logging
import asyncio
import warnings
from typing import Dict, Any, Optional
from datetime import datetime

# Suprimir warnings de SSL
warnings.filterwarnings('ignore', message='Unverified HTTPS request')

try:
    import httpx
    HTTPX_AVAILABLE = True
except ImportError:
    HTTPX_AVAILABLE = False

try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False

from .base_provider import BaseProvider, AIRequest, AIResponse


class LuziaProvider(BaseProvider):
    """
    Provedor LuzIA com implementação baseada no código funcional fornecido.
    
    Implementa:
    - Autenticação OAuth2 client_credentials
    - Headers corretos (x-santander-client-id, Authorization)
    - Payload estruturado conforme API LuzIA
    - Uso de httpx.AsyncClient
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Inicializa o provedor LuzIA.
        
        Args:
            config: Configuração do provedor
        """
        super().__init__(config)
        
        # Verificar dependências
        if not HTTPX_AVAILABLE and not REQUESTS_AVAILABLE:
            raise ImportError("httpx ou requests é necessário para o LuziaProvider")
        
        # Configurações baseadas no código das imagens
        self.client_id = config.get('client_id', os.getenv('LUZIA_CLIENT_ID', '71530749-db0a-424c-8a1c-72bf90315afa'))
        self.client_secret = config.get('client_secret', os.getenv('LUZIA_CLIENT_SECRET', '90a337834c9vH9zXAqc3D0g0031f73'))
        self.sso_endpoint = config.get('auth_url', 'https://login.azure.pass.santanderbr.pre.corp/auth/realms/corp/protocol/openid-connect/token')
        
        # URLs da API baseadas no código das imagens
        self.base_url = "https://prd-api-aws.santanderbr.dev.corp/genai_services/v1"
        self.model = config.get('model', 'azure-gpt-4o-mini')
        
        # Configurações
        self.temperature = config.get('temperature', 0.1)
        self.timeout = config.get('timeout', 120.0)
        
        # Token de acesso
        self._token = None
        
        self.logger = logging.getLogger(self.__class__.__name__)
        self.logger.info(f"LuzIA Provider inicializado - Modelo: {self.model}")
    
    def get_token(self) -> str:
        """
        Obtém token OAuth2 baseado no código das imagens.
        """
        try:
            # Payload OAuth2 conforme código das imagens
            request_body = {
                'grant_type': 'client_credentials',
                'client_id': self.client_id,
                'client_secret': self.client_secret
            }
            
            # Headers conforme código das imagens
            headers = {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Accept': '*/*'
            }
            
            # Fazer requisição
            if REQUESTS_AVAILABLE:
                response = requests.post(
                    self.sso_endpoint,
                    headers=headers,
                    data=request_body,
                    verify=False,
                    timeout=30
                )
                
                if response.status_code == 200:
                    token_data = response.json()
                    access_token = token_data.get('access_token')
                    if access_token:
                        self._token = access_token
                        self.logger.info("Token LuzIA obtido com sucesso")
                        return access_token
                    else:
                        raise Exception("Token não encontrado na resposta")
                else:
                    raise Exception(f"Erro na autenticação: {response.status_code} - {response.text}")
            else:
                raise Exception("requests não disponível")
                
        except Exception as e:
            self.logger.error(f"Erro ao obter token LuzIA: {str(e)}")
            raise
    
    async def submit(self) -> Dict[str, Any]:
        """
        Submete requisição assíncrona baseada no código das imagens.
        """
        if not HTTPX_AVAILABLE:
            raise Exception("httpx não disponível")
        
        # Obter token se necessário
        if not self._token:
            self.get_token()
        
        # Preparar payload baseado no código das imagens
        system_prompt = """
Answer all questions in brazilian portuguese.
Answer the question with the code only, without using the brackets.
DON'T start the answer with the word 'python'.
"""
        
        user_prompt = "O que é COBOL?"
        
        payload = {
            "input": {
                "query": [
                    {
                        "role": "system",
                        "content": system_prompt
                    },
                    {
                        "role": "user",
                        "content": user_prompt
                    }
                ]
            },
            "config": {
                "type": "catena.llm.LLMRouter",
                "obj_kwargs": {
                    "routing_model": self.model,
                    "temperature": self.temperature
                }
            }
        }
        
        # Headers baseados no código das imagens
        headers = {
            "x-santander-client-id": self.client_id,
            "Authorization": f"Bearer {self._token}"
        }
        
        # Fazer requisição assíncrona
        async with httpx.AsyncClient(timeout=self.timeout) as async_client:
            response = await async_client.post(
                f"{self.base_url}/pipelines/submit",
                json=payload,
                headers=headers
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                raise Exception(f"Erro na API LuzIA: {response.status_code} - {response.text}")
    
    def submit_sync(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Versão síncrona da submissão.
        """
        if not REQUESTS_AVAILABLE:
            raise Exception("requests não disponível")
        
        # Obter token se necessário
        if not self._token:
            self.get_token()
        
        # Headers baseados no código das imagens
        headers = {
            "x-santander-client-id": self.client_id,
            "Authorization": f"Bearer {self._token}",
            "Content-Type": "application/json"
        }
        
        # Fazer requisição síncrona
        response = requests.post(
            f"{self.base_url}/pipelines/submit",
            json=payload,
            headers=headers,
            timeout=self.timeout,
            verify=False
        )
        
        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Erro na API LuzIA: {response.status_code} - {response.text}")
    
    def is_available(self) -> bool:
        """
        Verifica se o provedor está disponível.
        """
        try:
            # Verificar credenciais
            if not self.client_id or not self.client_secret:
                self.logger.warning("Credenciais LuzIA não configuradas")
                return False
            
            # Tentar obter token
            self.get_token()
            return True
            
        except Exception as e:
            self.logger.error(f"LuzIA não disponível: {str(e)}")
            return False
    
    def analyze(self, request: AIRequest) -> AIResponse:
        """
        Analisa código COBOL usando LuzIA baseado no código das imagens.
        """
        try:
            # Preparar prompts baseados no código das imagens
            system_prompt = """
Answer all questions in brazilian portuguese.
Answer the question with the code only, without using the brackets.
DON'T start the answer with the word 'python'.
"""
            
            user_prompt = f"""O que é COBOL?

Analise o seguinte programa COBOL:

Nome do programa: {request.program_name}
Código COBOL:

{request.program_code}

{request.prompt}

Por favor, forneça uma análise completa e detalhada em português brasileiro."""
            
            # Payload baseado no código das imagens
            payload = {
                "input": {
                    "query": [
                        {
                            "role": "system",
                            "content": system_prompt
                        },
                        {
                            "role": "user",
                            "content": user_prompt
                        }
                    ]
                },
                "config": {
                    "type": "catena.llm.LLMRouter",
                    "obj_kwargs": {
                        "routing_model": self.model,
                        "temperature": self.temperature
                    }
                }
            }
            
            # Tentar requisição
            if HTTPX_AVAILABLE:
                # Usar asyncio para executar função assíncrona
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                
                async def run_analysis():
                    # Obter token se necessário
                    if not self._token:
                        self.get_token()
                    
                    # Headers
                    headers = {
                        "x-santander-client-id": self.client_id,
                        "Authorization": f"Bearer {self._token}"
                    }
                    
                    # Fazer requisição
                    async with httpx.AsyncClient(timeout=self.timeout) as async_client:
                        response = await async_client.post(
                            f"{self.base_url}/pipelines/submit",
                            json=payload,
                            headers=headers
                        )
                        
                        if response.status_code == 200:
                            return response.json()
                        else:
                            raise Exception(f"Erro na API: {response.status_code} - {response.text}")
                
                result = loop.run_until_complete(run_analysis())
                loop.close()
            else:
                result = self.submit_sync(payload)
                
                # Processar resposta
                response_text = ""
                if isinstance(result, dict):
                    # Extrair texto da resposta
                    if 'output' in result:
                        response_text = str(result['output'])
                    elif 'response' in result:
                        response_text = str(result['response'])
                    elif 'result' in result:
                        response_text = str(result['result'])
                    else:
                        response_text = json.dumps(result, indent=2, ensure_ascii=False)
                else:
                    response_text = str(result)
                
                # Calcular tokens estimados
                estimated_tokens = len(response_text.split()) * 1.3
                
                return AIResponse(
                    success=True,
                    content=response_text,
                    tokens_used=int(estimated_tokens),
                    model=self.model,
                    provider="luzia",
                    prompts_used={
                        'Prompt do Sistema': system_prompt,
                        'Prompt do Usuário': user_prompt,
                        'Payload Completo': json.dumps(payload, indent=2, ensure_ascii=False)
                    },
                    metadata={
                        'client_id': self.client_id[:8] + "...",
                        'model': self.model,
                        'temperature': self.temperature,
                        'api_response': result,
                        'timestamp': datetime.now().isoformat()
                    }
                )
                
        except Exception as e:
            self.logger.error(f"Erro na análise LuzIA: {str(e)}")
            return AIResponse(
                success=False,
                content=f"Erro na análise LuzIA: {str(e)}",
                tokens_used=0,
                model=self.model,
                provider="luzia",
                error_message=str(e),
                prompts_used={
                    'Erro': f"Falha na comunicação com LuzIA: {str(e)}"
                }
            )
    
    def get_usage_stats(self) -> Dict[str, Any]:
        """
        Retorna estatísticas de uso.
        """
        return {
            'provider': 'luzia',
            'model': self.model,
            'available': self.is_available(),
            'client_id': self.client_id[:8] + "..." if self.client_id else None,
            'base_url': self.base_url
        }

