"""
COBOL to Docs v1.1 - Sistema de Análise e Documentação de Programas COBOL
Autor: Carlos Morais

Sistema completo para análise automatizada de programas COBOL usando IA.
"""

__version__ = "1.1.0"
__author__ = "Carlos Morais"
__email__ = "carlos.morais@example.com"
__description__ = "Sistema de Análise e Documentação Automatizada de Programas COBOL usando IA"

# Importações principais para facilitar uso programático
try:
    from .core.config import ConfigManager
    from .core.prompt_manager_dual import DualPromptManager
    from .providers.enhanced_provider_manager import EnhancedProviderManager
    from .parsers.cobol_parser import COBOLParser
    from .generators.documentation_generator import DocumentationGenerator
    from .analyzers.enhanced_cobol_analyzer import EnhancedCOBOLAnalyzer
except ImportError:
    # Importações podem falhar durante instalação
    pass

# Metadados do pacote
__all__ = [
    "__version__",
    "__author__", 
    "__email__",
    "__description__",
    "ConfigManager",
    "DualPromptManager", 
    "EnhancedProviderManager",
    "COBOLParser",
    "DocumentationGenerator",
    "EnhancedCOBOLAnalyzer",
]
