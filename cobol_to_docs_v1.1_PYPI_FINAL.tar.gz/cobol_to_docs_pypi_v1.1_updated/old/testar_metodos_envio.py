#!/usr/bin/env python3
"""
Teste para comparar exatamente json= vs data= com mesmo payload
"""

import json
import requests
from unittest.mock import patch

# Payload exato
payload = {
    "input": {
        "query": [
            {
                "role": "system",
                "content": "\nAnswer all questions in brazilian portuguese.\nAnswer code question with the code only, without using the brackets.\nDON'T start the answer with the word 'python'.\n"
            },
            {
                "role": "user",
                "content": "Diga apenas 'teste ok'"
            }
        ]
    },
    "config": {
        "type": "catena.llm.LLMRouter",
        "obj_kwargs": {
            "routing_model": "azure-gpt-4o-mini",
            "temperature": 0.1
        }
    }
}

headers_base = {
    "X-santander-client-id": "test_client",
    "Authorization": "Bearer fake_token"
}

def interceptar_requisicao(metodo_nome):
    """Interceptar e analisar requisição"""
    
    def mock_post(*args, **kwargs):
        print(f"\n=== MÉTODO: {metodo_nome} ===")
        print(f"URL: {kwargs.get('url', args[0] if args else 'N/A')}")
        
        # Analisar headers
        headers = kwargs.get('headers', {})
        print("HEADERS ENVIADOS:")
        for key, value in headers.items():
            print(f"  {key}: {value}")
        
        # Analisar payload
        if 'json' in kwargs:
            print("USANDO: json=payload")
            payload_enviado = kwargs['json']
            print(f"Tipo do payload: {type(payload_enviado)}")
            
            # requests vai serializar automaticamente
            json_que_sera_enviado = json.dumps(payload_enviado)
            print(f"JSON que será enviado: {len(json_que_sera_enviado)} bytes")
            
        elif 'data' in kwargs:
            print("USANDO: data=json.dumps(payload)")
            data_enviado = kwargs['data']
            print(f"Tipo do data: {type(data_enviado)}")
            print(f"Tamanho do data: {len(data_enviado)} bytes")
            
            # Verificar se é JSON válido
            try:
                parsed = json.loads(data_enviado)
                print("Data é JSON válido: SIM")
            except:
                print("Data é JSON válido: NÃO")
        
        # Simular resposta da API
        class MockResponse:
            def __init__(self, success=True):
                self.status_code = 200 if success else 400
                
            def json(self):
                if self.status_code == 200:
                    return {"result": "sucesso"}
                else:
                    return {
                        "code": 400,
                        "description": "Request validation failed.",
                        "message": "Input should be a valid list"
                    }
            
            def text(self):
                return json.dumps(self.json())
        
        # Simular erro apenas para método data= (para testar)
        if 'data' in kwargs:
            return MockResponse(success=False)
        else:
            return MockResponse(success=True)
    
    return mock_post

def testar_metodo_json():
    """Testar método json=payload (como no teste.py que funciona)"""
    
    with patch('requests.post', side_effect=interceptar_requisicao("json=payload")):
        try:
            response = requests.post(
                url="https://gut-api-aws.santanderbr.dev.corp/genai_services/v1/pipelines/submit",
                json=payload,  # MÉTODO DO TESTE.PY QUE FUNCIONA
                headers=headers_base,
                verify=False,
                timeout=120.0
            )
            
            print(f"Status: {response.status_code}")
            print(f"Resposta: {response.json()}")
            
        except Exception as e:
            print(f"Erro: {e}")

def testar_metodo_data():
    """Testar método data=json.dumps (como no nosso provider)"""
    
    with patch('requests.post', side_effect=interceptar_requisicao("data=json.dumps")):
        try:
            response = requests.post(
                url="https://gut-api-aws.santanderbr.dev.corp/genai_services/v1/pipelines/submit",
                data=json.dumps(payload),  # MÉTODO DO NOSSO PROVIDER
                headers={
                    **headers_base,
                    "Content-Type": "application/json"
                },
                verify=False,
                timeout=120.0
            )
            
            print(f"Status: {response.status_code}")
            print(f"Resposta: {response.json()}")
            
        except Exception as e:
            print(f"Erro: {e}")

def comparar_headers():
    """Comparar headers entre os dois métodos"""
    
    print("\n=== COMPARAÇÃO DE HEADERS ===")
    
    # Headers quando usa json=
    print("MÉTODO json=payload:")
    print("- requests adiciona automaticamente: Content-Type: application/json")
    print("- requests calcula automaticamente: Content-Length")
    
    # Headers quando usa data=
    print("\nMÉTODO data=json.dumps:")
    print("- Precisamos adicionar manualmente: Content-Type: application/json")
    print("- requests calcula automaticamente: Content-Length")
    
    print("\nPOSSÍVEL PROBLEMA:")
    print("- API pode ser sensível a diferenças sutis nos headers")
    print("- Ordem dos headers pode importar")
    print("- Encoding pode ser diferente")

if __name__ == "__main__":
    print("=== TESTE DE MÉTODOS DE ENVIO ===")
    
    testar_metodo_json()
    testar_metodo_data()
    comparar_headers()
    
    print("\n=== CONCLUSÃO ===")
    print("O teste.py que funciona usa json=payload")
    print("Nosso provider usa data=json.dumps(payload)")
    print("Vamos mudar nosso provider para usar json=payload")
