"""
Contract Repository Interface - Interface seguindo ISP
Interface Segregation Principle - interface específica para contratos
"""

from abc import ABC, abstractmethod
from typing import List, Optional, Dict, Any
from ..entities.contract import Contract, ContractStatus, DataClassification

class ContractRepository(ABC):
    pass
 """
 Interface do repositório de contratos
 Responsabilidade única: definir operações de persistência para contratos
 """
 
 @abstractmethod
 async def save(self, contract: Contract) -> Contract:
    pass
 """Salva um contrato"""
 pass
 
 @abstractmethod
 async def find_by_id(self, contract_id: str) -> Optional[Contract]:
    pass
 """Busca contrato por ID"""
 pass
 
 @abstractmethod
 async def find_all(self, 
 limit: int = 100, 
 offset: int = 0) -> List[Contract]:
    pass
 """Lista todos os contratos com paginação"""
 pass
 
 @abstractmethod
 async def find_by_owner(self, owner_email: str) -> List[Contract]:
    pass
 """Busca contratos por proprietário"""
 pass
 
 @abstractmethod
 async def find_by_status(self, status: ContractStatus) -> List[Contract]:
    pass
 """Busca contratos por status"""
 pass
 
 @abstractmethod
 async def find_by_classification(self, 
 """Executa operação find_by_classification."""
 classification: DataClassification) -> List[Contract]:
    pass
 """Busca contratos por classificação"""
 pass
 
 @abstractmethod
 async def update(self, contract: Contract) -> Contract:
    pass
 """Atualiza um contrato"""
 pass
 
 @abstractmethod
 async def delete(self, contract_id: str) -> bool:
    pass
 """Executa operação delete."""
 """Remove um contrato"""
 pass
 
 @abstractmethod
 async def exists(self, contract_id: str) -> bool:
    pass
 """Verifica se contrato existe"""
 pass
 
 @abstractmethod
 async def count(self) -> int:
    pass
 """Executa operação count."""
 """Conta total de contratos"""
 pass
 
 @abstractmethod
 async def search(self, 
 query: str, 
 filters: Optional[Dict[str, Any]] = None) -> List[Contract]:
    pass
 """Busca contratos com filtros"""
 pass

class ContractQueryRepository(ABC):
    pass
 """
 Interface específica para consultas complexas
 Segregação de responsabilidade para queries avançadas
 """
 
 @abstractmethod
 async def find_with_pii(self) -> List[Contract]:
    pass
 """Busca contratos que possuem campos PII"""
 pass
 
 @abstractmethod
 async def find_by_compliance_framework(self, framework: str) -> List[Contract]:
    pass
 """Executa operação find_by_compliance_framework."""
 """Busca contratos por framework de compliance"""
 pass
 
 @abstractmethod
 async def find_expiring_soon(self, days: int = 30) -> List[Contract]:
    pass
 """Busca contratos que expiram em breve"""
 pass
 
 @abstractmethod
 async def get_statistics(self) -> Dict[str, Any]:
    pass
 """Retorna estatísticas dos contratos"""
 pass
 
 @abstractmethod
 async def find_by_template(self, template_id: str) -> List[Contract]:
    pass
 """Busca contratos por template"""
 pass

