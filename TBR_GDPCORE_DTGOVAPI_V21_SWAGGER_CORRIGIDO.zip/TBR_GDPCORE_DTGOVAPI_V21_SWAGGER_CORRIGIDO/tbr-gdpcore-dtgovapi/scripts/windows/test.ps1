# Script para executar testes no Windows
# Compatível com Python 3.14

param(
    [string]$TestType = "all",
    [switch]$Coverage = $false,
    [switch]$Verbose = $false
)

Write-Host "🧪 Executando testes da API de Governança..." -ForegroundColor Green

# Ativar ambiente virtual
if (Test-Path "venv") {
    & "venv\Scripts\Activate.ps1"
} else {
    Write-Host "❌ Ambiente virtual não encontrado. Execute setup.ps1 primeiro." -ForegroundColor Red
    exit 1
}

# Configurar argumentos do pytest
$pytestArgs = @()

switch ($TestType) {
    "unit" { $pytestArgs += "tests/unit" }
    "integration" { $pytestArgs += "tests/integration" }
    "e2e" { $pytestArgs += "tests/e2e" }
    default { $pytestArgs += "tests" }
}

if ($Coverage) {
    $pytestArgs += "--cov=src/governance_api"
    $pytestArgs += "--cov-report=html"
    $pytestArgs += "--cov-report=term-missing"
    $pytestArgs += "--cov-fail-under=90"
}

if ($Verbose) {
    $pytestArgs += "-v"
}

# Executar testes
Write-Host "Executando: pytest $($pytestArgs -join ' ')" -ForegroundColor Blue
python -m pytest @pytestArgs

if ($LASTEXITCODE -eq 0) {
    Write-Host "✅ Todos os testes passaram!" -ForegroundColor Green
    
    if ($Coverage) {
        Write-Host "📊 Relatório de cobertura gerado em htmlcov/index.html" -ForegroundColor Cyan
    }
} else {
    Write-Host "❌ Alguns testes falharam." -ForegroundColor Red
    exit 1
}

