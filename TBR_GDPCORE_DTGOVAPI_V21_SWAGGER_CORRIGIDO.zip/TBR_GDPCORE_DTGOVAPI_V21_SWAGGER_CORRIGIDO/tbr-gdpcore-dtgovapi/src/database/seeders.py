"""
Seeders para popular o banco de dados com dados mocados
"""
import asyncio
from typing import Dict, List, Any
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text

from database.connection import get_async_session
from database.models import (
    User, DataContract, Entity, QualityRule, QualityMetric,
    GovernancePolicy, LineageRelationship, AuditLog
)
from mock_data import MockDataFactory
from config.settings import get_settings


class DatabaseSeeder:
    """Seeder para popular banco de dados"""
    
    def __init__(self, session: AsyncSession):
        self.session = session
        self.settings = get_settings()
    
    async def seed_all(self, size: str = "medium") -> Dict[str, int]:
        """Popula todas as tabelas com dados mocados"""
        print(f"🌱 Iniciando seed do banco com dataset '{size}'...")
        
        # Gerar dados mocados
        dataset = MockDataFactory.create_complete_dataset(size)
        
        # Contar registros inseridos
        counts = {}
        
        # Seed em ordem de dependência
        counts['users'] = await self._seed_users(dataset['users'])
        counts['data_contracts'] = await self._seed_data_contracts(dataset['data_contracts'])
        counts['entities'] = await self._seed_entities(dataset['entities'])
        counts['quality_rules'] = await self._seed_quality_rules(dataset['quality_rules'])
        counts['quality_metrics'] = await self._seed_quality_metrics(dataset['quality_metrics'])
        counts['governance_policies'] = await self._seed_governance_policies(dataset['governance_policies'])
        counts['lineage_relationships'] = await self._seed_lineage_relationships(dataset['lineage_relationships'])
        counts['audit_logs'] = await self._seed_audit_logs(dataset['audit_logs'])
        
        await self.session.commit()
        
        print("✅ Seed concluído com sucesso!")
        return counts
    
    async def _seed_users(self, users_data: List[Dict[str, Any]]) -> int:
        """Popula tabela de usuários"""
        print("👥 Inserindo usuários...")
        
        for user_data in users_data:
            user = User(
                id=user_data['id'],
                username=user_data['username'],
                email=user_data['email'],
                full_name=user_data['full_name'],
                hashed_password="$2b$12$dummy_hash_for_testing",  # Hash dummy
                is_active=user_data['is_active'],
                is_superuser=user_data['is_superuser'],
                created_at=user_data['created_at'],
                updated_at=user_data['updated_at']
            )
            self.session.add(user)
        
        await self.session.flush()
        return len(users_data)
    
    async def _seed_data_contracts(self, contracts_data: List[Dict[str, Any]]) -> int:
        """Popula tabela de contratos de dados"""
        print("📋 Inserindo contratos de dados...")
        
        for contract_data in contracts_data:
            contract = DataContract(
                id=contract_data['id'],
                name=contract_data['name'],
                description=contract_data['description'],
                version=contract_data['version'],
                status=contract_data['status'],
                contract_type=contract_data['contract_type'],
                owner_email=contract_data['owner_email'],
                schema_definition=contract_data['schema_definition'],
                sla_availability=contract_data['sla_availability'],
                sla_response_time=contract_data['sla_response_time'],
                created_at=contract_data['created_at'],
                updated_at=contract_data['updated_at']
            )
            self.session.add(contract)
        
        await self.session.flush()
        return len(contracts_data)
    
    async def _seed_entities(self, entities_data: List[Dict[str, Any]]) -> int:
        """Popula tabela de entidades"""
        print("🏗️ Inserindo entidades...")
        
        for entity_data in entities_data:
            entity = Entity(
                id=entity_data['id'],
                name=entity_data['name'],
                display_name=entity_data['display_name'],
                description=entity_data['description'],
                entity_type=entity_data['entity_type'],
                domain=entity_data['domain'],
                owner_email=entity_data['owner_email'],
                schema_name=entity_data['schema_name'],
                table_name=entity_data['table_name'],
                unity_catalog_path=entity_data['unity_catalog_path'],
                row_count=entity_data['row_count'],
                size_bytes=entity_data['size_bytes'],
                is_active=entity_data['is_active'],
                tags=entity_data['tags'],
                created_at=entity_data['created_at'],
                updated_at=entity_data['updated_at']
            )
            self.session.add(entity)
        
        await self.session.flush()
        return len(entities_data)
    
    async def _seed_quality_rules(self, rules_data: List[Dict[str, Any]]) -> int:
        """Popula tabela de regras de qualidade"""
        print("🎯 Inserindo regras de qualidade...")
        
        for rule_data in rules_data:
            rule = QualityRule(
                id=rule_data['id'],
                name=rule_data['name'],
                description=rule_data['description'],
                rule_type=rule_data['rule_type'],
                column_name=rule_data['column_name'],
                parameters=rule_data['parameters'],
                severity=rule_data['severity'],
                is_active=rule_data['is_active'],
                created_at=rule_data['created_at'],
                updated_at=rule_data['updated_at']
            )
            self.session.add(rule)
        
        await self.session.flush()
        return len(rules_data)
    
    async def _seed_quality_metrics(self, metrics_data: List[Dict[str, Any]]) -> int:
        """Popula tabela de métricas de qualidade"""
        print("📊 Inserindo métricas de qualidade...")
        
        for metric_data in metrics_data:
            metric = QualityMetric(
                id=metric_data['id'],
                metric_type=metric_data['metric_type'],
                value=metric_data['value'],
                threshold=metric_data['threshold'],
                status=metric_data['status'],
                measured_at=metric_data['measured_at'],
                created_at=metric_data['created_at']
            )
            self.session.add(metric)
        
        await self.session.flush()
        return len(metrics_data)
    
    async def _seed_governance_policies(self, policies_data: List[Dict[str, Any]]) -> int:
        """Popula tabela de políticas de governança"""
        print("🛡️ Inserindo políticas de governança...")
        
        for policy_data in policies_data:
            policy = GovernancePolicy(
                id=policy_data['id'],
                name=policy_data['name'],
                description=policy_data['description'],
                policy_type=policy_data['policy_type'],
                rules=policy_data['rules'],
                is_active=policy_data['is_active'],
                created_at=policy_data['created_at'],
                updated_at=policy_data['updated_at']
            )
            self.session.add(policy)
        
        await self.session.flush()
        return len(policies_data)
    
    async def _seed_lineage_relationships(self, lineage_data: List[Dict[str, Any]]) -> int:
        """Popula tabela de relacionamentos de linhagem"""
        print("🔗 Inserindo relacionamentos de linhagem...")
        
        for lineage_item in lineage_data:
            relationship = LineageRelationship(
                id=lineage_item['id'],
                source_entity_id=lineage_item['source_entity_id'],
                target_entity_id=lineage_item['target_entity_id'],
                relationship_type=lineage_item['relationship_type'],
                confidence_score=lineage_item['confidence_score'],
                created_at=lineage_item['created_at']
            )
            self.session.add(relationship)
        
        await self.session.flush()
        return len(lineage_data)
    
    async def _seed_audit_logs(self, logs_data: List[Dict[str, Any]]) -> int:
        """Popula tabela de logs de auditoria"""
        print("📝 Inserindo logs de auditoria...")
        
        for log_data in logs_data:
            log = AuditLog(
                id=log_data['id'],
                user_id=log_data['user_id'],
                action=log_data['action'],
                resource_type=log_data['resource_type'],
                resource_id=log_data['resource_id'],
                details=log_data['details'],
                timestamp=log_data['timestamp']
            )
            self.session.add(log)
        
        await self.session.flush()
        return len(logs_data)
    
    async def clear_all_tables(self) -> None:
        """Limpa todas as tabelas (cuidado!)"""
        print("🗑️ Limpando todas as tabelas...")
        
        # Ordem reversa para respeitar foreign keys
        tables = [
            'audit_logs', 'lineage_relationships', 'governance_policies',
            'quality_metrics', 'quality_rules', 'entities', 'data_contracts', 'users'
        ]
        
        for table in tables:
            await self.session.execute(text(f"DELETE FROM {table}"))
        
        await self.session.commit()
        print("✅ Tabelas limpas!")


async def run_seeder(size: str = "medium", clear_first: bool = False) -> Dict[str, int]:
    """Executa o seeder"""
    async with get_async_session() as session:
        seeder = DatabaseSeeder(session)
        
        if clear_first:
            await seeder.clear_all_tables()
        
        return await seeder.seed_all(size)


# Script para execução direta
if __name__ == "__main__":
    import sys
    
    size = sys.argv[1] if len(sys.argv) > 1 else "medium"
    clear = "--clear" in sys.argv
    
    print(f"🚀 Executando seeder com dataset '{size}'...")
    if clear:
        print("⚠️ Limpando tabelas primeiro...")
    
    counts = asyncio.run(run_seeder(size, clear))
    
    print("\n📊 Resumo dos dados inseridos:")
    for table, count in counts.items():
        print(f"  {table}: {count} registros")
    
    total = sum(counts.values())
    print(f"\n✅ Total: {total} registros inseridos com sucesso!")

