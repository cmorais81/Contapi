"""
Configurações da aplicação
"""

import os
from functools import lru_cache
from typing import List, Optional

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    SECRET_KEY: str = "your-secret-key-change-in-production"
    """Configurações da aplicação"""
    
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore"
    )
    
    # Database Configuration
    database_url: str = Field(
        default="postgresql+asyncpg://postgres:password@localhost:5432/governance_db",
        description="URL de conexão com banco de dados"
    )
    database_pool_size: int = Field(default=20, description="Tamanho do pool de conexões")
    database_max_overflow: int = Field(default=30, description="Máximo de conexões extras")
    database_pool_recycle: int = Field(default=3600, description="Tempo para reciclar conexões (segundos)")
    database_echo: bool = Field(default=False, description="Log de queries SQL")
    
    # SQLite Configuration (para desenvolvimento)
    use_sqlite: bool = Field(default=False, description="Usar SQLite em desenvolvimento")
    sqlite_db_path: str = Field(default="./governance_data.db", description="Caminho do arquivo SQLite")
    
    # Mock Data Configuration
    enable_mock_data: bool = Field(default=False, description="Habilitar dados mocados")
    mock_data_size: int = Field(default=100, description="Quantidade de registros mocados")
    
    # Environment
    environment: str = Field(default="development", description="Ambiente de execução")
    
    # Redis Configuration
    redis_url: str = Field(default="redis://localhost:6379/0", description="URL do Redis")
    redis_cache_ttl: int = Field(default=300, description="TTL padrão do cache (segundos)")
    
    # API Configuration
    api_host: str = Field(default="0.0.0.0", description="Host da API")
    api_port: int = Field(default=8000, description="Porta da API")
    api_debug: bool = Field(default=False, description="Modo debug")
    api_reload: bool = Field(default=False, description="Auto-reload em desenvolvimento")
    api_title: str = Field(default="Governance Data API", description="Título da API")
    api_description: str = Field(
        default="API de Governança de Dados baseada no modelo ODCS v3.0.2",
        description="Descrição da API"
    )
    api_version: str = Field(default="1.0.0", description="Versão da API")
    
    # Security
    secret_key: str = Field(
        default="your-super-secret-key-change-this-in-production",
        description="Chave secreta para JWT"
    )
    algorithm: str = Field(default="HS256", description="Algoritmo de criptografia")
    access_token_expire_minutes: int = Field(
        default=30, 
        description="Tempo de expiração do token (minutos)"
    )
    
    # Rate Limiting
    rate_limit_enabled: bool = Field(default=True, description="Habilitar rate limiting")
    rate_limit_default: str = Field(default="100/minute", description="Limite padrão")
    rate_limit_heavy: str = Field(default="10/minute", description="Limite para operações pesadas")
    
    # Circuit Breaker
    circuit_breaker_failure_threshold: int = Field(
        default=5, 
        description="Threshold de falhas para circuit breaker"
    )
    circuit_breaker_recovery_timeout: int = Field(
        default=60, 
        description="Timeout de recuperação (segundos)"
    )
    
    # Monitoring
    prometheus_enabled: bool = Field(default=True, description="Habilitar Prometheus")
    prometheus_port: int = Field(default=9090, description="Porta do Prometheus")
    grafana_enabled: bool = Field(default=True, description="Habilitar Grafana")
    grafana_port: int = Field(default=3000, description="Porta do Grafana")
    
    # Logging
    log_level: str = Field(default="INFO", description="Nível de log")
    log_format: str = Field(default="json", description="Formato de log")
    sentry_dsn: Optional[str] = Field(default=None, description="DSN do Sentry")
    
    # External Integrations
    unity_catalog_url: Optional[str] = Field(default=None, description="URL do Unity Catalog")
    unity_catalog_token: Optional[str] = Field(default=None, description="Token do Unity Catalog")
    informatica_axon_url: Optional[str] = Field(default=None, description="URL do Informatica Axon")
    informatica_axon_token: Optional[str] = Field(default=None, description="Token do Informatica Axon")
    datahub_url: Optional[str] = Field(default=None, description="URL do DataHub")
    datahub_token: Optional[str] = Field(default=None, description="Token do DataHub")
    
    # Health Checks
    health_check_interval: int = Field(default=30, description="Intervalo de health checks (segundos)")
    health_check_timeout: int = Field(default=10, description="Timeout de health checks (segundos)")
    
    # Windows Specific
    windows_service_name: str = Field(
        default="GovernanceDataAPI", 
        description="Nome do serviço Windows"
    )
    windows_service_display_name: str = Field(
        default="Governance Data API Service",
        description="Nome de exibição do serviço Windows"
    )
    
    # CORS
    cors_origins: List[str] = Field(
        default=["*"],
        description="Origens permitidas para CORS"
    )
    cors_allow_credentials: bool = Field(default=True, description="Permitir credenciais CORS")
    cors_allow_methods: List[str] = Field(
        default=["*"],
        description="Métodos permitidos para CORS"
    )
    cors_allow_headers: List[str] = Field(
        default=["*"],
        description="Headers permitidos para CORS"
    )
    
    # Pagination
    default_page_size: int = Field(default=20, description="Tamanho padrão de página")
    max_page_size: int = Field(default=100, description="Tamanho máximo de página")
    
    # File Upload
    max_file_size: int = Field(default=10 * 1024 * 1024, description="Tamanho máximo de arquivo (bytes)")
    allowed_file_types: List[str] = Field(
        default=[".json", ".yaml", ".yml", ".csv", ".xlsx"],
        description="Tipos de arquivo permitidos"
    )
    
    # Cache
    cache_enabled: bool = Field(default=True, description="Habilitar cache")
    cache_default_ttl: int = Field(default=300, description="TTL padrão do cache (segundos)")
    cache_health_check_ttl: int = Field(default=60, description="TTL para health checks (segundos)")
    cache_metrics_ttl: int = Field(default=30, description="TTL para métricas (segundos)")
    
    # Background Tasks
    background_tasks_enabled: bool = Field(default=True, description="Habilitar tarefas em background")
    background_tasks_max_workers: int = Field(default=4, description="Máximo de workers para tarefas")
    
    # Webhook
    webhook_timeout: int = Field(default=30, description="Timeout para webhooks (segundos)")
    webhook_retry_attempts: int = Field(default=3, description="Tentativas de retry para webhooks")
    webhook_retry_delay: int = Field(default=5, description="Delay entre retries (segundos)")
    
    @property
    def database_url_sync(self) -> str:
        """URL síncrona do banco de dados"""
        return self.database_url.replace("postgresql+asyncpg://", "postgresql+psycopg2://")
    
    @property
    def is_development(self) -> bool:
        """Verifica se está em modo de desenvolvimento"""
        return self.api_debug or self.api_reload
    
    @property
    def is_production(self) -> bool:
        """Verifica se está em modo de produção"""
        return not self.is_development
    
    def get_cors_config(self) -> dict:
        """Retorna configuração CORS"""
        return {
            "allow_origins": self.cors_origins,
            "allow_credentials": self.cors_allow_credentials,
            "allow_methods": self.cors_allow_methods,
            "allow_headers": self.cors_allow_headers,
        }


class TestSettings(Settings):
    """Configurações para testes"""
    
    database_url: str = "sqlite+aiosqlite:///./test.db"
    redis_url: str = "redis://localhost:6379/1"
    api_debug: bool = True
    log_level: str = "DEBUG"
    cache_enabled: bool = False
    prometheus_enabled: bool = False
    grafana_enabled: bool = False
    background_tasks_enabled: bool = False


@lru_cache()
def get_settings() -> Settings:
    """Retorna instância das configurações"""
    env = os.getenv("ENVIRONMENT", "development")
    
    if env == "test":
        return TestSettings()
    
    return Settings()


@lru_cache()
def get_test_settings() -> TestSettings:
    """Retorna configurações de teste"""
    return TestSettings()

