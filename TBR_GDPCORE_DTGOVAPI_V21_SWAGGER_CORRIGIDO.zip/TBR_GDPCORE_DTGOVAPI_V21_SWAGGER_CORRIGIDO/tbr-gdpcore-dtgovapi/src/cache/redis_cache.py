"""
Cache Redis para performance
"""

import json
import pickle
from typing import Any, Optional, Union

import redis.asyncio as redis

from config.settings import get_settings
from domain.exceptions import CacheError

settings = get_settings()


class RedisCache:
    """Cliente Redis para cache"""
    
    def __init__(self):
        self.redis_client = None
        self._connected = False
    
    async def connect(self):
        """Conecta ao Redis"""
        try:
            self.redis_client = redis.from_url(
                settings.redis_url,
                encoding="utf-8",
                decode_responses=False  # Para suportar pickle
            )
            
            # Testar conexão
            await self.redis_client.ping()
            self._connected = True
            
        except Exception as e:
            raise CacheError(f"Failed to connect to Redis: {str(e)}") from e
    
    async def disconnect(self):
        """Desconecta do Redis"""
        if self.redis_client:
            await self.redis_client.close()
            self._connected = False
    
    async def set(
        self,
        key: str,
        value: Any,
        ttl: Optional[int] = None,
        serialize_method: str = "json"
    ) -> bool:
        """Define valor no cache"""
        if not self._connected:
            await self.connect()
        
        try:
            # Serializar valor
            if serialize_method == "json":
                serialized_value = json.dumps(value, default=str)
            elif serialize_method == "pickle":
                serialized_value = pickle.dumps(value)
            else:
                serialized_value = str(value)
            
            # Definir TTL padrão
            if ttl is None:
                ttl = settings.cache_default_ttl
            
            # Armazenar no Redis
            result = await self.redis_client.set(key, serialized_value, ex=ttl)
            return bool(result)
            
        except Exception as e:
            raise CacheError(f"Failed to set cache key {key}: {str(e)}") from e
    
    async def get(
        self,
        key: str,
        serialize_method: str = "json"
    ) -> Optional[Any]:
        """Obtém valor do cache"""
        if not self._connected:
            await self.connect()
        
        try:
            value = await self.redis_client.get(key)
            
            if value is None:
                return None
            
            # Deserializar valor
            if serialize_method == "json":
                return json.loads(value)
            elif serialize_method == "pickle":
                return pickle.loads(value)
            else:
                return value.decode("utf-8") if isinstance(value, bytes) else value
            
        except Exception as e:
            raise CacheError(f"Failed to get cache key {key}: {str(e)}") from e
    
    async def delete(self, key: str) -> bool:
        """Remove valor do cache"""
        if not self._connected:
            await self.connect()
        
        try:
            result = await self.redis_client.delete(key)
            return bool(result)
            
        except Exception as e:
            raise CacheError(f"Failed to delete cache key {key}: {str(e)}") from e
    
    async def exists(self, key: str) -> bool:
        """Verifica se chave existe no cache"""
        if not self._connected:
            await self.connect()
        
        try:
            result = await self.redis_client.exists(key)
            return bool(result)
            
        except Exception as e:
            raise CacheError(f"Failed to check cache key {key}: {str(e)}") from e
    
    async def expire(self, key: str, ttl: int) -> bool:
        """Define TTL para uma chave"""
        if not self._connected:
            await self.connect()
        
        try:
            result = await self.redis_client.expire(key, ttl)
            return bool(result)
            
        except Exception as e:
            raise CacheError(f"Failed to set TTL for cache key {key}: {str(e)}") from e
    
    async def ttl(self, key: str) -> int:
        """Obtém TTL de uma chave"""
        if not self._connected:
            await self.connect()
        
        try:
            return await self.redis_client.ttl(key)
            
        except Exception as e:
            raise CacheError(f"Failed to get TTL for cache key {key}: {str(e)}") from e
    
    async def flush_all(self) -> bool:
        """Limpa todo o cache"""
        if not self._connected:
            await self.connect()
        
        try:
            result = await self.redis_client.flushall()
            return bool(result)
            
        except Exception as e:
            raise CacheError(f"Failed to flush cache: {str(e)}") from e
    
    async def keys(self, pattern: str = "*") -> list:
        """Lista chaves por padrão"""
        if not self._connected:
            await self.connect()
        
        try:
            keys = await self.redis_client.keys(pattern)
            return [key.decode("utf-8") if isinstance(key, bytes) else key for key in keys]
            
        except Exception as e:
            raise CacheError(f"Failed to list cache keys: {str(e)}") from e
    
    async def health_check(self) -> bool:
        """Verifica saúde do Redis"""
        try:
            if not self._connected:
                await self.connect()
            
            await self.redis_client.ping()
            return True
            
        except Exception:
            return False


class CacheManager:
    """Gerenciador de cache com funcionalidades avançadas"""
    
    def __init__(self):
        self.redis_cache = RedisCache()
    
    async def get_or_set(
        self,
        key: str,
        factory_func,
        ttl: Optional[int] = None,
        serialize_method: str = "json"
    ) -> Any:
        """Obtém valor do cache ou executa função para gerar"""
        
        # Tentar obter do cache
        cached_value = await self.redis_cache.get(key, serialize_method)
        
        if cached_value is not None:
            return cached_value
        
        # Executar função para gerar valor
        if callable(factory_func):
            if hasattr(factory_func, '__call__') and hasattr(factory_func, '__await__'):
                # Função assíncrona
                value = await factory_func()
            else:
                # Função síncrona
                value = factory_func()
        else:
            value = factory_func
        
        # Armazenar no cache
        await self.redis_cache.set(key, value, ttl, serialize_method)
        
        return value
    
    async def invalidate_pattern(self, pattern: str) -> int:
        """Invalida chaves por padrão"""
        keys = await self.redis_cache.keys(pattern)
        
        if not keys:
            return 0
        
        deleted_count = 0
        for key in keys:
            if await self.redis_cache.delete(key):
                deleted_count += 1
        
        return deleted_count
    
    async def get_cache_stats(self) -> dict:
        """Obtém estatísticas do cache"""
        try:
            if not self.redis_cache._connected:
                await self.redis_cache.connect()
            
            info = await self.redis_cache.redis_client.info()
            
            return {
                "connected_clients": info.get("connected_clients", 0),
                "used_memory": info.get("used_memory", 0),
                "used_memory_human": info.get("used_memory_human", "0B"),
                "keyspace_hits": info.get("keyspace_hits", 0),
                "keyspace_misses": info.get("keyspace_misses", 0),
                "total_commands_processed": info.get("total_commands_processed", 0),
                "uptime_in_seconds": info.get("uptime_in_seconds", 0)
            }
            
        except Exception as e:
            raise CacheError(f"Failed to get cache stats: {str(e)}") from e


# Instância global do cache
cache_manager = CacheManager()


def cache_key(*args, prefix: str = "governance") -> str:
    """Gera chave de cache padronizada"""
    key_parts = [prefix] + [str(arg) for arg in args]
    return ":".join(key_parts)


def cache(
    ttl: Optional[int] = None,
    key_prefix: str = "governance",
    serialize_method: str = "json"
):
    """Decorator para cache de funções"""
    
    def decorator(func):
        async def async_wrapper(*args, **kwargs):
            # Gerar chave do cache
            key_parts = [func.__name__] + list(args) + [f"{k}={v}" for k, v in sorted(kwargs.items())]
            cache_key_str = cache_key(*key_parts, prefix=key_prefix)
            
            # Usar cache manager
            return await cache_manager.get_or_set(
                cache_key_str,
                lambda: func(*args, **kwargs),
                ttl,
                serialize_method
            )
        
        def sync_wrapper(*args, **kwargs):
            import asyncio
            return asyncio.run(async_wrapper(*args, **kwargs))
        
        if hasattr(func, '__call__') and hasattr(func, '__await__'):
            return async_wrapper
        else:
            return sync_wrapper
    
    return decorator

