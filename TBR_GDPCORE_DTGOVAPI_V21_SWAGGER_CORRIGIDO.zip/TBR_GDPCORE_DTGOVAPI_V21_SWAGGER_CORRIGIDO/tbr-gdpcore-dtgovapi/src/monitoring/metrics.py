"""
Métricas Prometheus para monitoramento
"""

import time
from functools import wraps
from typing import Dict, List, Optional

from prometheus_client import (
    Counter,
    Gauge,
    Histogram,
    Info,
    generate_latest,
    CONTENT_TYPE_LATEST,
    CollectorRegistry,
    multiprocess,
    REGISTRY
)

from config.settings import get_settings

settings = get_settings()

# Registry personalizado para métricas
if settings.is_production:
    # Em produção, usar multiprocess registry
    registry = CollectorRegistry()
    multiprocess.MultiProcessCollector(registry)
else:
    # Em desenvolvimento, usar registry padrão
    registry = REGISTRY

# ========================================
# MÉTRICAS DE APLICAÇÃO
# ========================================

# Informações da aplicação
app_info = Info(
    'governance_api_info',
    'Informações da API de Governança',
    registry=registry
)

app_info.info({
    'version': settings.api_version,
    'environment': 'production' if settings.is_production else 'development'
})

# Métricas de requ# Métricas da aplicação
app_info = Info(
    'tbr_gdpcore_dtgovapi_info',
    'Informações da aplicação TBR GDP Core Data Governance API'
)

# Métricas HTTP
http_requests_total = Counter(
    'tbr_gdpcore_dtgovapi_http_requests_total',
    'Total de requisições HTTP',
    ['method', 'endpoint', 'status_code']
)

http_request_duration = Histogram(
    'tbr_gdpcore_dtgovapi_http_request_duration_seconds',
    'Duração das requisições HTTP em segundos',
    ['method', 'endpoint']
)

# Métricas de usuários
active_users = Gauge(
    'tbr_gdpcore_dtgovapi_active_users',
    'Número de usuários ativos'
)

# Métricas de contratos de dados
data_contracts_total = Gauge(
    'tbr_gdpcore_dtgovapi_data_contracts_total',
    'Total de contratos de dados'
)

data_contract_versions_total = Gauge(
    'tbr_gdpcore_dtgovapi_data_contract_versions_total',
    'Total de versões de contratos de dados'
)

# Métricas de entidades
entities_total = Gauge(
    'tbr_gdpcore_dtgovapi_entities_total',
    'Total de entidades de dados'
)

# Métricas de qualidade
quality_rules_total = Gauge(
    'tbr_gdpcore_dtgovapi_quality_rules_total',
    'Total de regras de qualidade'
)

quality_metrics_total = Gauge(
    'tbr_gdpcore_dtgovapi_quality_metrics_total',
    'Total de métricas de qualidade'
)

quality_score = Gauge(
    'tbr_gdpcore_dtgovapi_quality_score',
    'Score médio de qualidade dos dados'
)

# Métricas de banco de dados
database_connections = Gauge(
    'tbr_gdpcore_dtgovapi_database_connections',
    'Número de conexões ativas com o banco de dados'
)

database_query_duration = Histogram(
    'tbr_gdpcore_dtgovapi_database_query_duration_seconds',
    'Duração das queries do banco de dados em segundos',
    ['operation']
)

# Métricas de cache
cache_operations_total = Counter(
    'tbr_gdpcore_dtgovapi_cache_operations_total',
    'Total de operações de cache',
    ['operation', 'result']
)

cache_hit_ratio = Gauge(
    'tbr_gdpcore_dtgovapi_cache_hit_ratio',
    'Taxa de acerto do cache'
)

# Métricas de integrações externas
external_requests_total = Counter(
    'tbr_gdpcore_dtgovapi_external_requests_total',
    'Total de requisições para sistemas externos',
    ['service', 'status']
)

external_duration = Histogram(
    'tbr_gdpcore_dtgovapi_external_duration_seconds',
    'Duração das requisições para sistemas externos',
    ['service']
)

# Métricas de circuit breaker
circuit_breaker_state = Gauge(
    'tbr_gdpcore_dtgovapi_circuit_breaker_state',
    'Estado do circuit breaker (0=closed, 1=open, 2=half-open)',
    ['service']
)

circuit_breaker_failures = Counter(
    'tbr_gdpcore_dtgovapi_circuit_breaker_failures_total',
    'Total de falhas do circuit breaker',
    ['service']
)

# Métricas de sistema
memory_usage = Gauge(
    'tbr_gdpcore_dtgovapi_memory_usage_bytes',
    'Uso de memória em bytes'
)

cpu_usage = Gauge(
    'tbr_gdpcore_dtgovapi_cpu_usage_percent',
    'Uso de CPU em porcentagem'
)


# ========================================
# FUNÇÕES AUXILIARES PARA MÉTRICAS
# ========================================

def create_counter(name: str, description: str, labels: Optional[List[str]] = None):
    """Cria um contador personalizado"""
    return Counter(
        f'tbr_gdpcore_dtgovapi_{name}',
        description,
        labels or []
    )

def create_gauge(name: str, description: str, labels: Optional[List[str]] = None):
    """Cria um gauge personalizado"""
    return Gauge(
        f'tbr_gdpcore_dtgovapi_{name}',
        description,
        labels or []
    )

def create_histogram(name: str, description: str, labels: Optional[List[str]] = None):
    """Cria um histograma personalizado"""
    return Histogram(
        f'tbr_gdpcore_dtgovapi_{name}',
        description,
        labels or []
    )
            
            # Extrair informações da requisição
            method = getattr(args[0], 'method', 'UNKNOWN') if args else 'UNKNOWN'
            endpoint = getattr(args[0], 'url', {}).get('path', 'unknown') if args else 'unknown'
            status_code = getattr(result, 'status_code', 200)
            
            # Incrementar contador
            http_requests_total.labels(
                method=method,
                endpoint=endpoint,
                status_code=status_code
            ).inc()
            
            # Registrar duração
            duration = time.time() - start_time
            http_request_duration_seconds.labels(
                method=method,
                endpoint=endpoint
            ).observe(duration)
            
            return result
            
        except Exception as e:
            # Registrar erro
            method = getattr(args[0], 'method', 'UNKNOWN') if args else 'UNKNOWN'
            endpoint = getattr(args[0], 'url', {}).get('path', 'unknown') if args else 'unknown'
            
            http_requests_total.labels(
                method=method,
                endpoint=endpoint,
                status_code=500
            ).inc()
            
            raise e
    
    return wrapper


def track_database_query(operation: str):
    """Decorator para rastrear queries de banco"""
    
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            start_time = time.time()
            
            try:
                result = await func(*args, **kwargs)
                
                # Registrar duração
                duration = time.time() - start_time
                database_query_duration_seconds.labels(
                    operation=operation
                ).observe(duration)
                
                return result
                
            except Exception as e:
                # Registrar erro se necessário
                raise e
        
        return wrapper
    return decorator


def track_external_api(service: str):
    """Decorator para rastrear chamadas para APIs externas"""
    
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            start_time = time.time()
            
            try:
                result = await func(*args, **kwargs)
                
                # Incrementar contador de sucesso
                external_api_requests_total.labels(
                    service=service,
                    status='success'
                ).inc()
                
                # Registrar duração
                duration = time.time() - start_time
                external_api_duration_seconds.labels(
                    service=service
                ).observe(duration)
                
                return result
                
            except Exception as e:
                # Incrementar contador de erro
                external_api_requests_total.labels(
                    service=service,
                    status='error'
                ).inc()
                
                raise e
        
        return wrapper
    return decorator


def track_cache_operation(operation: str):
    """Decorator para rastrear operações de cache"""
    
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            try:
                result = await func(*args, **kwargs)
                
                # Determinar resultado da operação
                cache_result = 'hit' if result is not None else 'miss'
                if operation in ['set', 'delete']:
                    cache_result = 'success' if result else 'failure'
                
                # Incrementar contador
                cache_operations_total.labels(
                    operation=operation,
                    result=cache_result
                ).inc()
                
                return result
                
            except Exception as e:
                # Registrar erro
                cache_operations_total.labels(
                    operation=operation,
                    result='error'
                ).inc()
                
                raise e
        
        return wrapper
    return decorator


# ========================================
# FUNÇÕES AUXILIARES
# ========================================

def update_business_metrics(
    contracts_by_status: Dict[str, int],
    entities_by_type: Dict[str, int],
    quality_rules_by_type: Dict[str, int],
    active_users_count: int
):
    """Atualiza métricas de negócio"""
    
    # Atualizar métricas de contratos
    for status, count in contracts_by_status.items():
        data_contracts_total.labels(status=status).set(count)
    
    # Atualizar métricas de entidades
    for entity_type, count in entities_by_type.items():
        entities_total.labels(type=entity_type, classification='internal').set(count)
    
    # Atualizar métricas de qualidade
    for rule_type, count in quality_rules_by_type.items():
        quality_rules_total.labels(rule_type=rule_type, is_active='true').set(count)
    
    # Atualizar usuários ativos
    active_users.set(active_users_count)


def update_system_metrics():
    """Atualiza métricas de sistema"""
    import psutil
    
    # Uso de memória
    memory = psutil.virtual_memory()
    system_memory_usage.set(memory.used)
    
    # Uso de CPU
    cpu_percent = psutil.cpu_percent(interval=1)
    system_cpu_usage.set(cpu_percent)


def update_circuit_breaker_metrics(service: str, state: str, failure_count: int):
    """Atualiza métricas de circuit breaker"""
    
    # Mapear estado para número
    state_mapping = {
        'closed': 0,
        'open': 1,
        'half_open': 2
    }
    
    circuit_breaker_state.labels(service=service).set(
        state_mapping.get(state, 0)
    )
    
    # Atualizar contador de falhas se necessário
    if failure_count > 0:
        circuit_breaker_failures.labels(service=service).inc(failure_count)


def get_metrics() -> str:
    """Retorna métricas no formato Prometheus"""
    return generate_latest(registry)


def get_metrics_content_type() -> str:
    """Retorna content type das métricas"""
    return CONTENT_TYPE_LATEST


# ========================================
# MÉTRICAS CUSTOMIZADAS
# ========================================

class MetricsCollector:
    """Coletor de métricas customizadas"""
    
    def __init__(self):
        self.custom_metrics = {}
    
    def register_gauge(self, name: str, description: str, labels: Optional[List[str]] = None):
        """Registra uma métrica gauge customizada"""
        self.custom_metrics[name] = Gauge(
            f'governance_api_{name}',
            description,
            labels or [],
            registry=registry
        )
    
    def register_counter(self, name: str, description: str, labels: Optional[List[str]] = None):
        """Registra uma métrica counter customizada"""
        self.custom_metrics[name] = Counter(
            f'governance_api_{name}',
            description,
            labels or [],
            registry=registry
        )
    
    def register_histogram(self, name: str, description: str, labels: Optional[List[str]] = None):
        """Registra uma métrica histogram customizada"""
        self.custom_metrics[name] = Histogram(
            f'governance_api_{name}',
            description,
            labels or [],
            registry=registry
        )
    
    def get_metric(self, name: str):
        """Obtém métrica customizada"""
        return self.custom_metrics.get(name)
    
    def set_gauge(self, name: str, value: float, labels: Optional[Dict[str, str]] = None):
        """Define valor de gauge"""
        metric = self.custom_metrics.get(name)
        if metric and hasattr(metric, 'set'):
            if labels:
                metric.labels(**labels).set(value)
            else:
                metric.set(value)
    
    def inc_counter(self, name: str, value: float = 1, labels: Optional[Dict[str, str]] = None):
        """Incrementa counter"""
        metric = self.custom_metrics.get(name)
        if metric and hasattr(metric, 'inc'):
            if labels:
                metric.labels(**labels).inc(value)
            else:
                metric.inc(value)
    
    def observe_histogram(self, name: str, value: float, labels: Optional[Dict[str, str]] = None):
        """Observa valor em histogram"""
        metric = self.custom_metrics.get(name)
        if metric and hasattr(metric, 'observe'):
            if labels:
                metric.labels(**labels).observe(value)
            else:
                metric.observe(value)


# Instância global do coletor
metrics_collector = MetricsCollector()

