"""
Sistema de Load Balancing e Health Checks
Desenvolvido por Carlos Morais
"""

import asyncio
import aiohttp
import time
import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, asdict
from enum import Enum
import hashlib
import random

from database.models import LoadBalancerMetrics
from database.connection import get_async_session
from config.settings import get_settings
from monitoring.audit_logger import audit_logger, EventType, Severity


class InstanceStatus(str, Enum):
    """Status de uma instância"""
    HEALTHY = "healthy"
    UNHEALTHY = "unhealthy"
    DEGRADED = "degraded"
    OFFLINE = "offline"
    MAINTENANCE = "maintenance"


class LoadBalancingStrategy(str, Enum):
    """Estratégias de load balancing"""
    ROUND_ROBIN = "round_robin"
    LEAST_CONNECTIONS = "least_connections"
    WEIGHTED_ROUND_ROBIN = "weighted_round_robin"
    IP_HASH = "ip_hash"
    LEAST_RESPONSE_TIME = "least_response_time"


@dataclass
class InstanceConfig:
    """Configuração de uma instância"""
    id: str
    host: str
    port: int
    weight: int = 1
    max_connections: int = 100
    health_check_path: str = "/health"
    health_check_interval: int = 30
    health_check_timeout: int = 5
    failure_threshold: int = 3
    recovery_threshold: int = 2
    maintenance_mode: bool = False


@dataclass
class InstanceMetrics:
    """Métricas de uma instância"""
    instance_id: str
    status: InstanceStatus
    active_connections: int
    total_requests: int
    failed_requests: int
    avg_response_time_ms: float
    last_health_check: datetime
    consecutive_failures: int
    consecutive_successes: int
    uptime_seconds: int
    cpu_usage_percent: Optional[float] = None
    memory_usage_percent: Optional[float] = None
    disk_usage_percent: Optional[float] = None


class HealthChecker:
    """Verificador de saúde das instâncias"""
    
    def __init__(self):
        self.session: Optional[aiohttp.ClientSession] = None
        self.check_tasks: Dict[str, asyncio.Task] = {}
    
    async def start(self):
        """Inicia o health checker"""
        
        connector = aiohttp.TCPConnector(
            limit=100,
            limit_per_host=10,
            keepalive_timeout=30,
            enable_cleanup_closed=True
        )
        
        timeout = aiohttp.ClientTimeout(total=10, connect=5)
        
        self.session = aiohttp.ClientSession(
            connector=connector,
            timeout=timeout,
            headers={
                "User-Agent": "GovernanceAPI-HealthChecker/1.0",
                "Accept": "application/json"
            }
        )
    
    async def stop(self):
        """Para o health checker"""
        
        # Cancelar todas as tasks
        for task in self.check_tasks.values():
            task.cancel()
        
        # Aguardar cancelamento
        if self.check_tasks:
            await asyncio.gather(*self.check_tasks.values(), return_exceptions=True)
        
        # Fechar sessão
        if self.session:
            await self.session.close()
    
    async def start_monitoring(self, instance: InstanceConfig):
        """Inicia monitoramento de uma instância"""
        
        if instance.id in self.check_tasks:
            return  # Já está sendo monitorada
        
        task = asyncio.create_task(
            self._health_check_loop(instance)
        )
        self.check_tasks[instance.id] = task
    
    async def stop_monitoring(self, instance_id: str):
        """Para monitoramento de uma instância"""
        
        if instance_id in self.check_tasks:
            task = self.check_tasks.pop(instance_id)
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
    
    async def _health_check_loop(self, instance: InstanceConfig):
        """Loop de health check para uma instância"""
        
        while True:
            try:
                await asyncio.sleep(instance.health_check_interval)
                
                if instance.maintenance_mode:
                    continue
                
                # Realizar health check
                is_healthy, response_time_ms, details = await self._perform_health_check(instance)
                
                # Notificar resultado
                await self._handle_health_check_result(
                    instance, is_healthy, response_time_ms, details
                )
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                await audit_logger.log_event(
                    event_type=EventType.SYSTEM_EVENT,
                    resource_type="health_checker",
                    additional_metadata={
                        "instance_id": instance.id,
                        "error": str(e),
                        "action": "health_check_loop_error"
                    },
                    severity=Severity.ERROR,
                    tags=["load_balancer", "health_check", "error"]
                )
    
    async def _perform_health_check(
        self, 
        instance: InstanceConfig
    ) -> Tuple[bool, int, Dict[str, Any]]:
        """Realiza health check em uma instância"""
        
        url = f"http://{instance.host}:{instance.port}{instance.health_check_path}"
        start_time = time.time()
        
        try:
            async with self.session.get(url, timeout=instance.health_check_timeout) as response:
                response_time_ms = int((time.time() - start_time) * 1000)
                
                # Verificar status code
                if response.status == 200:
                    try:
                        data = await response.json()
                        
                        # Verificar se resposta contém informações de saúde
                        if isinstance(data, dict) and data.get("status") == "healthy":
                            return True, response_time_ms, data
                        else:
                            return False, response_time_ms, {"error": "Invalid health response"}
                    
                    except json.JSONDecodeError:
                        # Aceitar resposta de texto simples
                        text = await response.text()
                        if "healthy" in text.lower():
                            return True, response_time_ms, {"status": "healthy", "text": text}
                        else:
                            return False, response_time_ms, {"error": "Invalid health text"}
                else:
                    return False, response_time_ms, {"error": f"HTTP {response.status}"}
        
        except asyncio.TimeoutError:
            response_time_ms = int((time.time() - start_time) * 1000)
            return False, response_time_ms, {"error": "Timeout"}
        
        except Exception as e:
            response_time_ms = int((time.time() - start_time) * 1000)
            return False, response_time_ms, {"error": str(e)}
    
    async def _handle_health_check_result(
        self,
        instance: InstanceConfig,
        is_healthy: bool,
        response_time_ms: int,
        details: Dict[str, Any]
    ):
        """Processa resultado do health check"""
        
        # Notificar load balancer sobre o resultado
        # Isso seria implementado através de um callback ou event system
        
        # Log apenas para mudanças de status ou problemas
        if not is_healthy or response_time_ms > 5000:  # > 5 segundos
            severity = Severity.WARN if is_healthy else Severity.ERROR
            
            await audit_logger.log_event(
                event_type=EventType.SYSTEM_EVENT,
                resource_type="instance_health",
                additional_metadata={
                    "instance_id": instance.id,
                    "instance_host": f"{instance.host}:{instance.port}",
                    "is_healthy": is_healthy,
                    "response_time_ms": response_time_ms,
                    "details": details
                },
                severity=severity,
                tags=["load_balancer", "health_check"]
            )


class LoadBalancer:
    """Load balancer com múltiplas estratégias"""
    
    def __init__(self, strategy: LoadBalancingStrategy = LoadBalancingStrategy.LEAST_CONNECTIONS):
        self.strategy = strategy
        self.instances: Dict[str, InstanceConfig] = {}
        self.metrics: Dict[str, InstanceMetrics] = {}
        self.health_checker = HealthChecker()
        self.current_index = 0  # Para round robin
        self.request_count = 0
        self.started_at = datetime.utcnow()
    
    async def start(self):
        """Inicia o load balancer"""
        
        await self.health_checker.start()
        
        await audit_logger.log_event(
            event_type=EventType.SYSTEM_EVENT,
            resource_type="load_balancer",
            additional_metadata={
                "action": "started",
                "strategy": self.strategy.value,
                "instances_count": len(self.instances)
            },
            severity=Severity.INFO,
            tags=["load_balancer", "startup"]
        )
    
    async def stop(self):
        """Para o load balancer"""
        
        await self.health_checker.stop()
        
        await audit_logger.log_event(
            event_type=EventType.SYSTEM_EVENT,
            resource_type="load_balancer",
            additional_metadata={
                "action": "stopped",
                "uptime_seconds": int((datetime.utcnow() - self.started_at).total_seconds()),
                "total_requests": self.request_count
            },
            severity=Severity.INFO,
            tags=["load_balancer", "shutdown"]
        )
    
    async def add_instance(self, instance: InstanceConfig):
        """Adiciona uma instância ao pool"""
        
        self.instances[instance.id] = instance
        
        # Inicializar métricas
        self.metrics[instance.id] = InstanceMetrics(
            instance_id=instance.id,
            status=InstanceStatus.OFFLINE,
            active_connections=0,
            total_requests=0,
            failed_requests=0,
            avg_response_time_ms=0.0,
            last_health_check=datetime.utcnow(),
            consecutive_failures=0,
            consecutive_successes=0,
            uptime_seconds=0
        )
        
        # Iniciar monitoramento
        await self.health_checker.start_monitoring(instance)
        
        await audit_logger.log_event(
            event_type=EventType.SYSTEM_EVENT,
            resource_type="load_balancer",
            additional_metadata={
                "action": "instance_added",
                "instance_id": instance.id,
                "instance_host": f"{instance.host}:{instance.port}",
                "weight": instance.weight
            },
            severity=Severity.INFO,
            tags=["load_balancer", "instance_management"]
        )
    
    async def remove_instance(self, instance_id: str):
        """Remove uma instância do pool"""
        
        if instance_id in self.instances:
            instance = self.instances.pop(instance_id)
            self.metrics.pop(instance_id, None)
            
            # Parar monitoramento
            await self.health_checker.stop_monitoring(instance_id)
            
            await audit_logger.log_event(
                event_type=EventType.SYSTEM_EVENT,
                resource_type="load_balancer",
                additional_metadata={
                    "action": "instance_removed",
                    "instance_id": instance_id,
                    "instance_host": f"{instance.host}:{instance.port}"
                },
                severity=Severity.INFO,
                tags=["load_balancer", "instance_management"]
            )
    
    async def get_next_instance(self, client_ip: Optional[str] = None) -> Optional[InstanceConfig]:
        """Obtém próxima instância baseada na estratégia"""
        
        # Filtrar apenas instâncias saudáveis
        healthy_instances = [
            instance for instance_id, instance in self.instances.items()
            if self.metrics[instance_id].status == InstanceStatus.HEALTHY
            and not instance.maintenance_mode
        ]
        
        if not healthy_instances:
            return None
        
        self.request_count += 1
        
        # Aplicar estratégia
        if self.strategy == LoadBalancingStrategy.ROUND_ROBIN:
            return self._round_robin(healthy_instances)
        elif self.strategy == LoadBalancingStrategy.LEAST_CONNECTIONS:
            return self._least_connections(healthy_instances)
        elif self.strategy == LoadBalancingStrategy.WEIGHTED_ROUND_ROBIN:
            return self._weighted_round_robin(healthy_instances)
        elif self.strategy == LoadBalancingStrategy.IP_HASH:
            return self._ip_hash(healthy_instances, client_ip)
        elif self.strategy == LoadBalancingStrategy.LEAST_RESPONSE_TIME:
            return self._least_response_time(healthy_instances)
        else:
            return self._round_robin(healthy_instances)
    
    def _round_robin(self, instances: List[InstanceConfig]) -> InstanceConfig:
        """Estratégia round robin"""
        
        instance = instances[self.current_index % len(instances)]
        self.current_index += 1
        return instance
    
    def _least_connections(self, instances: List[InstanceConfig]) -> InstanceConfig:
        """Estratégia least connections"""
        
        return min(
            instances,
            key=lambda inst: self.metrics[inst.id].active_connections
        )
    
    def _weighted_round_robin(self, instances: List[InstanceConfig]) -> InstanceConfig:
        """Estratégia weighted round robin"""
        
        # Criar lista expandida baseada nos pesos
        weighted_instances = []
        for instance in instances:
            weighted_instances.extend([instance] * instance.weight)
        
        if weighted_instances:
            instance = weighted_instances[self.current_index % len(weighted_instances)]
            self.current_index += 1
            return instance
        
        return instances[0]
    
    def _ip_hash(self, instances: List[InstanceConfig], client_ip: Optional[str]) -> InstanceConfig:
        """Estratégia IP hash (sticky sessions)"""
        
        if not client_ip:
            return self._round_robin(instances)
        
        # Hash do IP para determinar instância
        hash_value = int(hashlib.md5(client_ip.encode()).hexdigest(), 16)
        index = hash_value % len(instances)
        return instances[index]
    
    def _least_response_time(self, instances: List[InstanceConfig]) -> InstanceConfig:
        """Estratégia least response time"""
        
        return min(
            instances,
            key=lambda inst: self.metrics[inst.id].avg_response_time_ms
        )
    
    async def update_instance_metrics(
        self,
        instance_id: str,
        active_connections: Optional[int] = None,
        response_time_ms: Optional[float] = None,
        request_success: Optional[bool] = None
    ):
        """Atualiza métricas de uma instância"""
        
        if instance_id not in self.metrics:
            return
        
        metrics = self.metrics[instance_id]
        
        if active_connections is not None:
            metrics.active_connections = active_connections
        
        if response_time_ms is not None:
            # Calcular média móvel do tempo de resposta
            alpha = 0.1  # Fator de suavização
            metrics.avg_response_time_ms = (
                alpha * response_time_ms + 
                (1 - alpha) * metrics.avg_response_time_ms
            )
        
        if request_success is not None:
            metrics.total_requests += 1
            if not request_success:
                metrics.failed_requests += 1
    
    async def get_load_balancer_metrics(self) -> Dict[str, Any]:
        """Obtém métricas do load balancer"""
        
        total_instances = len(self.instances)
        healthy_instances = sum(
            1 for metrics in self.metrics.values()
            if metrics.status == InstanceStatus.HEALTHY
        )
        
        total_connections = sum(
            metrics.active_connections for metrics in self.metrics.values()
        )
        
        total_requests = sum(
            metrics.total_requests for metrics in self.metrics.values()
        )
        
        total_failed_requests = sum(
            metrics.failed_requests for metrics in self.metrics.values()
        )
        
        avg_response_time = (
            sum(metrics.avg_response_time_ms for metrics in self.metrics.values()) /
            max(len(self.metrics), 1)
        )
        
        return {
            "strategy": self.strategy.value,
            "total_instances": total_instances,
            "healthy_instances": healthy_instances,
            "unhealthy_instances": total_instances - healthy_instances,
            "total_active_connections": total_connections,
            "total_requests": total_requests,
            "total_failed_requests": total_failed_requests,
            "success_rate_percent": (
                ((total_requests - total_failed_requests) / max(total_requests, 1)) * 100
            ),
            "avg_response_time_ms": round(avg_response_time, 2),
            "uptime_seconds": int((datetime.utcnow() - self.started_at).total_seconds()),
            "instances": {
                instance_id: asdict(metrics)
                for instance_id, metrics in self.metrics.items()
            }
        }
    
    async def save_metrics_to_db(self):
        """Salva métricas no banco de dados"""
        
        try:
            metrics_data = await self.get_load_balancer_metrics()
            
            async with get_async_session() as session:
                lb_metrics = LoadBalancerMetrics(
                    strategy=self.strategy.value,
                    total_instances=metrics_data["total_instances"],
                    healthy_instances=metrics_data["healthy_instances"],
                    total_active_connections=metrics_data["total_active_connections"],
                    total_requests=metrics_data["total_requests"],
                    total_failed_requests=metrics_data["total_failed_requests"],
                    avg_response_time_ms=metrics_data["avg_response_time_ms"],
                    success_rate_percent=metrics_data["success_rate_percent"],
                    additional_metrics=metrics_data["instances"]
                )
                
                session.add(lb_metrics)
                await session.commit()
                
        except Exception as e:
            print(f"Error saving load balancer metrics: {e}")


# Instância global do load balancer
load_balancer = LoadBalancer()

