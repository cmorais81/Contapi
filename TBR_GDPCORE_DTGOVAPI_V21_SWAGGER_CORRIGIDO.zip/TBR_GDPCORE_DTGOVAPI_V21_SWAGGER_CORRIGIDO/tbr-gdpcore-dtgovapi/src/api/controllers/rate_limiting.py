"""
Controller de Rate Limiting
Desenvolvido por Carlos Morais
"""

from datetime import datetime
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel

from database.connection import get_async_session
from database.models import RateLimitPolicy, RateLimitViolation
from api.controllers.auth import get_current_active_user
from monitoring.rate_limiter import SlidingWindowRateLimiter as RateLimiter

router = APIRouter(prefix="/api/v1/rate-limits", tags=["Rate Limiting"])

# Modelos Pydantic
class RateLimitPolicyResponse(BaseModel):
    id: int
    name: str
    description: Optional[str]
    user_id: Optional[int]
    user_role: Optional[str]
    endpoint_pattern: Optional[str]
    requests_per_minute: int
    requests_per_hour: int
    requests_per_day: int
    burst_limit: int
    is_active: bool
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True

class RateLimitPolicyCreate(BaseModel):
    name: str
    description: Optional[str] = None
    user_id: Optional[int] = None
    user_role: Optional[str] = None
    endpoint_pattern: Optional[str] = None
    requests_per_minute: int = 60
    requests_per_hour: int = 1000
    requests_per_day: int = 10000
    burst_limit: int = 10
    is_active: bool = True

class RateLimitStatus(BaseModel):
    user_id: int
    username: str
    current_limits: dict
    usage_stats: dict
    violations_count: int
    last_violation: Optional[datetime]
    status: str  # "normal", "warning", "limited"

class RateLimitViolationResponse(BaseModel):
    id: int
    user_id: Optional[int]
    ip_address: str
    endpoint: str
    limit_type: str
    limit_value: int
    actual_requests: int
    time_window: str
    blocked_duration: Optional[int]
    created_at: datetime

    class Config:
        from_attributes = True

@router.get("/policies", response_model=List[RateLimitPolicyResponse])
async def get_rate_limit_policies(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    is_active: Optional[bool] = Query(None),
    db: AsyncSession = Depends(get_async_session),
    current_user = Depends(get_current_active_user)
):
    """
    Obter políticas de rate limiting
    """
    query = select(RateLimitPolicy)
    
    if is_active is not None:
        query = query.where(RateLimitPolicy.is_active == is_active)
    
    query = query.offset(skip).limit(limit)
    result = await db.execute(query)
    policies = result.scalars().all()
    
    return policies

@router.post("/policies", response_model=RateLimitPolicyResponse)
async def create_rate_limit_policy(
    policy_data: RateLimitPolicyCreate,
    db: AsyncSession = Depends(get_async_session),
    current_user = Depends(get_current_active_user)
):
    """
    Criar nova política de rate limiting
    """
    # TODO: Verificar se usuário é admin
    
    policy = RateLimitPolicy(
        name=policy_data.name,
        description=policy_data.description,
        user_id=policy_data.user_id,
        user_role=policy_data.user_role,
        endpoint_pattern=policy_data.endpoint_pattern,
        requests_per_minute=policy_data.requests_per_minute,
        requests_per_hour=policy_data.requests_per_hour,
        requests_per_day=policy_data.requests_per_day,
        burst_limit=policy_data.burst_limit,
        is_active=policy_data.is_active
    )
    
    db.add(policy)
    await db.commit()
    await db.refresh(policy)
    
    return policy

@router.get("/policies/{policy_id}", response_model=RateLimitPolicyResponse)
async def get_rate_limit_policy(
    policy_id: int,
    db: AsyncSession = Depends(get_async_session),
    current_user = Depends(get_current_active_user)
):
    """
    Obter política específica
    """
    result = await db.execute(select(RateLimitPolicy).where(RateLimitPolicy.id == policy_id))
    policy = result.scalar_one_or_none()
    
    if not policy:
        raise HTTPException(status_code=404, detail="Rate limit policy not found")
    
    return policy

@router.put("/policies/{policy_id}", response_model=RateLimitPolicyResponse)
async def update_rate_limit_policy(
    policy_id: int,
    policy_data: RateLimitPolicyCreate,
    db: AsyncSession = Depends(get_async_session),
    current_user = Depends(get_current_active_user)
):
    """
    Atualizar política de rate limiting
    """
    # TODO: Verificar se usuário é admin
    
    result = await db.execute(select(RateLimitPolicy).where(RateLimitPolicy.id == policy_id))
    policy = result.scalar_one_or_none()
    
    if not policy:
        raise HTTPException(status_code=404, detail="Rate limit policy not found")
    
    # Atualizar campos
    for field, value in policy_data.dict().items():
        setattr(policy, field, value)
    
    policy.updated_at = datetime.utcnow()
    
    await db.commit()
    await db.refresh(policy)
    
    return policy

@router.delete("/policies/{policy_id}")
async def delete_rate_limit_policy(
    policy_id: int,
    db: AsyncSession = Depends(get_async_session),
    current_user = Depends(get_current_active_user)
):
    """
    Deletar política de rate limiting
    """
    # TODO: Verificar se usuário é admin
    
    result = await db.execute(select(RateLimitPolicy).where(RateLimitPolicy.id == policy_id))
    policy = result.scalar_one_or_none()
    
    if not policy:
        raise HTTPException(status_code=404, detail="Rate limit policy not found")
    
    await db.delete(policy)
    await db.commit()
    
    return {"message": "Rate limit policy deleted successfully"}

@router.get("/status", response_model=RateLimitStatus)
async def get_rate_limit_status(
    user_id: Optional[int] = Query(None),
    db: AsyncSession = Depends(get_async_session),
    current_user = Depends(get_current_active_user)
):
    """
    Obter status de rate limiting para usuário
    """
    target_user_id = user_id or current_user.id
    
    # Buscar políticas aplicáveis
    policies_query = select(RateLimitPolicy).where(
        RateLimitPolicy.is_active == True
    )
    result = await db.execute(policies_query)
    policies = result.scalars().all()
    
    # Buscar violações recentes
    violations_query = select(RateLimitViolation).where(
        RateLimitViolation.user_id == target_user_id
    )
    result = await db.execute(violations_query)
    violations = result.scalars().all()
    
    # Calcular status
    violations_count = len(violations)
    last_violation = max([v.created_at for v in violations]) if violations else None
    
    # Determinar status
    if violations_count == 0:
        status = "normal"
    elif violations_count < 5:
        status = "warning"
    else:
        status = "limited"
    
    # Limites atuais (exemplo)
    current_limits = {
        "requests_per_minute": 60,
        "requests_per_hour": 1000,
        "requests_per_day": 10000,
        "burst_limit": 10
    }
    
    # Estatísticas de uso (exemplo)
    usage_stats = {
        "requests_last_minute": 5,
        "requests_last_hour": 45,
        "requests_last_day": 234,
        "burst_used": 2
    }
    
    return RateLimitStatus(
        user_id=target_user_id,
        username=current_user.username,
        current_limits=current_limits,
        usage_stats=usage_stats,
        violations_count=violations_count,
        last_violation=last_violation,
        status=status
    )

@router.get("/violations", response_model=List[RateLimitViolationResponse])
async def get_rate_limit_violations(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    user_id: Optional[int] = Query(None),
    db: AsyncSession = Depends(get_async_session),
    current_user = Depends(get_current_active_user)
):
    """
    Obter violações de rate limiting
    """
    query = select(RateLimitViolation)
    
    if user_id:
        query = query.where(RateLimitViolation.user_id == user_id)
    
    query = query.offset(skip).limit(limit)
    result = await db.execute(query)
    violations = result.scalars().all()
    
    return violations

@router.post("/reset/{user_id}")
async def reset_rate_limits(
    user_id: int,
    db: AsyncSession = Depends(get_async_session),
    current_user = Depends(get_current_active_user)
):
    """
    Resetar rate limits para usuário (apenas admins)
    """
    # TODO: Verificar se usuário é admin
    
    # Aqui você implementaria a lógica para resetar os contadores
    # no Redis ou sistema de cache
    
    return {
        "message": f"Rate limits reset for user {user_id}",
        "reset_at": datetime.utcnow()
    }

@router.get("/metrics")
async def get_rate_limit_metrics(
    db: AsyncSession = Depends(get_async_session),
    current_user = Depends(get_current_active_user)
):
    """
    Obter métricas de rate limiting
    """
    # Contar políticas ativas
    policies_query = select(RateLimitPolicy).where(RateLimitPolicy.is_active == True)
    result = await db.execute(policies_query)
    active_policies = len(result.scalars().all())
    
    # Contar violações recentes
    violations_query = select(RateLimitViolation)
    result = await db.execute(violations_query)
    total_violations = len(result.scalars().all())
    
    return {
        "active_policies": active_policies,
        "total_violations": total_violations,
        "system_status": "operational",
        "last_updated": datetime.utcnow()
    }

