"""
Value Objects para a API de Governança de Dados
"""

import re
from dataclasses import dataclass
from typing import Optional
from uuid import UUID

from domain.exceptions import ValidationError


@dataclass(frozen=True)
class Version:
    """Value object para versionamento semântico"""
    
    major: int
    minor: int
    patch: int
    pre_release: Optional[str] = None
    
    def __post_init__(self):
        if self.major < 0 or self.minor < 0 or self.patch < 0:
            raise ValidationError("Versão não pode ter números negativos")
        
        if self.pre_release and not re.match(r'^[a-zA-Z0-9\-\.]+$', self.pre_release):
            raise ValidationError("Pre-release deve conter apenas letras, números, hífens e pontos")
    
    def __str__(self) -> str:
        version = f"{self.major}.{self.minor}.{self.patch}"
        if self.pre_release:
            version += f"-{self.pre_release}"
        return version
    
    @classmethod
    def from_string(cls, version_str: str) -> "Version":
        """Cria uma versão a partir de string"""
        pattern = r'^(\d+)\.(\d+)\.(\d+)(?:-([a-zA-Z0-9\-\.]+))?$'
        match = re.match(pattern, version_str)
        
        if not match:
            raise ValidationError(f"Formato de versão inválido: {version_str}")
        
        major, minor, patch, pre_release = match.groups()
        return cls(
            major=int(major),
            minor=int(minor),
            patch=int(patch),
            pre_release=pre_release
        )
    
    def is_compatible_with(self, other: "Version") -> bool:
        """Verifica se a versão é compatível com outra (mesmo major)"""
        return self.major == other.major
    
    def is_newer_than(self, other: "Version") -> bool:
        """Verifica se a versão é mais nova que outra"""
        if self.major != other.major:
            return self.major > other.major
        if self.minor != other.minor:
            return self.minor > other.minor
        if self.patch != other.patch:
            return self.patch > other.patch
        
        # Se ambas têm pre-release, compara lexicograficamente
        if self.pre_release and other.pre_release:
            return self.pre_release > other.pre_release
        
        # Versão sem pre-release é maior que com pre-release
        return not self.pre_release and other.pre_release


@dataclass(frozen=True)
class Email:
    """Value object para email"""
    
    value: str
    
    def __post_init__(self):
        if not self._is_valid_email(self.value):
            raise ValidationError(f"Email inválido: {self.value}")
    
    def _is_valid_email(self, email: str) -> bool:
        """Valida formato de email"""
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return bool(re.match(pattern, email))
    
    def __str__(self) -> str:
        return self.value


@dataclass(frozen=True)
class UnityCatalogPath:
    """Value object para caminho do Unity Catalog"""
    
    catalog: str
    schema: str
    table: str
    
    def __post_init__(self):
        if not all([self.catalog, self.schema, self.table]):
            raise ValidationError("Todos os componentes do path são obrigatórios")
        
        # Validar caracteres permitidos
        pattern = r'^[a-zA-Z0-9_]+$'
        for component in [self.catalog, self.schema, self.table]:
            if not re.match(pattern, component):
                raise ValidationError(f"Componente inválido no path: {component}")
    
    def __str__(self) -> str:
        return f"{self.catalog}.{self.schema}.{self.table}"
    
    @classmethod
    def from_string(cls, path_str: str) -> "UnityCatalogPath":
        """Cria um path a partir de string"""
        parts = path_str.split('.')
        if len(parts) != 3:
            raise ValidationError(f"Path do Unity Catalog deve ter 3 partes: {path_str}")
        
        return cls(catalog=parts[0], schema=parts[1], table=parts[2])


@dataclass(frozen=True)
class QualityThreshold:
    """Value object para threshold de qualidade"""
    
    warning: float
    critical: float
    
    def __post_init__(self):
        if not (0 <= self.warning <= 100):
            raise ValidationError("Threshold de warning deve estar entre 0 e 100")
        
        if not (0 <= self.critical <= 100):
            raise ValidationError("Threshold crítico deve estar entre 0 e 100")
        
        if self.critical >= self.warning:
            raise ValidationError("Threshold crítico deve ser menor que warning")
    
    def evaluate_status(self, value: float) -> str:
        """Avalia o status baseado no valor"""
        if value <= self.critical:
            return "critical"
        elif value <= self.warning:
            return "warning"
        else:
            return "passed"


@dataclass(frozen=True)
class EntityId:
    """Value object para ID de entidade"""
    
    value: UUID
    
    def __str__(self) -> str:
        return str(self.value)


@dataclass(frozen=True)
class DomainPath:
    """Value object para caminho hierárquico de domínio"""
    
    path: str
    
    def __post_init__(self):
        if not self.path:
            raise ValidationError("Path do domínio não pode estar vazio")
        
        # Validar formato hierárquico
        parts = self.path.split('/')
        for part in parts:
            if not part or not re.match(r'^[a-zA-Z0-9_\-]+$', part):
                raise ValidationError(f"Parte inválida no path do domínio: {part}")
    
    def get_parent_path(self) -> Optional[str]:
        """Retorna o path do domínio pai"""
        parts = self.path.split('/')
        if len(parts) <= 1:
            return None
        return '/'.join(parts[:-1])
    
    def get_depth(self) -> int:
        """Retorna a profundidade do domínio"""
        return len(self.path.split('/'))
    
    def __str__(self) -> str:
        return self.path


@dataclass(frozen=True)
class ClassificationLevel:
    """Value object para nível de classificação de dados"""
    
    level: str
    
    VALID_LEVELS = ["public", "internal", "confidential", "restricted"]
    
    def __post_init__(self):
        if self.level not in self.VALID_LEVELS:
            raise ValidationError(f"Nível de classificação inválido: {self.level}")
    
    def get_numeric_level(self) -> int:
        """Retorna o nível numérico (1-4)"""
        return self.VALID_LEVELS.index(self.level) + 1
    
    def is_more_restrictive_than(self, other: "ClassificationLevel") -> bool:
        """Verifica se é mais restritivo que outro nível"""
        return self.get_numeric_level() > other.get_numeric_level()
    
    def __str__(self) -> str:
        return self.level

