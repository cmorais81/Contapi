"""
Serviços de aplicação para orquestração de casos de uso
"""

from typing import Any, Dict, List, Optional
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession

from domain.exceptions import BusinessRuleViolation, EntityNotFoundError
from application.dtos import (
    DataContractCreateDTO,
    DataContractResponseDTO,
    DataContractUpdateDTO,
    DataContractVersionCreateDTO,
    DataContractVersionResponseDTO,
    EntityCreateDTO,
    EntityResponseDTO,
    EntityUpdateDTO,
    PaginatedResponse,
    PaginationParams,
    QualityRuleCreateDTO,
    QualityRuleResponseDTO,
    QualityRuleUpdateDTO,
    SearchParams,
)
from application.use_cases import (
    ActivateDataContractVersionUseCase,
    CreateDataContractUseCase,
    CreateDataContractVersionUseCase,
    CreateEntityUseCase,
    CreateQualityRuleUseCase,
    DeleteDataContractUseCase,
    ExecuteQualityRuleUseCase,
    ExportODCSUseCase,
    GetDataContractUseCase,
    ListDataContractsUseCase,
    SearchEntitiesUseCase,
    UpdateDataContractUseCase,
    UpdateEntityUseCase,
)


class DataContractService:
    """Serviço para gerenciamento de contratos de dados"""
    
    def __init__(self, session: AsyncSession):
        self.session = session
    
    async def create_contract(
        self,
        dto: DataContractCreateDTO,
        created_by: Optional[UUID] = None
    ) -> DataContractResponseDTO:
        """Cria um novo contrato de dados"""
        use_case = CreateDataContractUseCase(self.session)
        return await use_case.execute(dto, created_by)
    
    async def update_contract(
        self,
        contract_id: UUID,
        dto: DataContractUpdateDTO,
        updated_by: Optional[UUID] = None
    ) -> DataContractResponseDTO:
        """Atualiza um contrato de dados"""
        use_case = UpdateDataContractUseCase(self.session)
        return await use_case.execute(contract_id, dto, updated_by)
    
    async def get_contract(self, contract_id: UUID) -> DataContractResponseDTO:
        """Busca um contrato de dados por ID"""
        use_case = GetDataContractUseCase(self.session)
        return await use_case.execute(contract_id)
    
    async def list_contracts(
        self,
        pagination: PaginationParams,
        filters: Optional[Dict[str, Any]] = None
    ) -> PaginatedResponse:
        """Lista contratos de dados com paginação"""
        use_case = ListDataContractsUseCase(self.session)
        return await use_case.execute(pagination, filters)
    
    async def delete_contract(self, contract_id: UUID) -> bool:
        """Remove um contrato de dados"""
        use_case = DeleteDataContractUseCase(self.session)
        return await use_case.execute(contract_id)
    
    async def create_version(
        self,
        contract_id: UUID,
        dto: DataContractVersionCreateDTO,
        created_by: Optional[UUID] = None
    ) -> DataContractVersionResponseDTO:
        """Cria uma nova versão do contrato"""
        use_case = CreateDataContractVersionUseCase(self.session)
        return await use_case.execute(contract_id, dto, created_by)
    
    async def activate_version(
        self,
        contract_id: UUID,
        version: str,
        updated_by: Optional[UUID] = None
    ) -> DataContractVersionResponseDTO:
        """Ativa uma versão específica do contrato"""
        use_case = ActivateDataContractVersionUseCase(self.session)
        return await use_case.execute(contract_id, version, updated_by)
    
    async def export_odcs(
        self,
        contract_id: UUID,
        version: Optional[str] = None
    ) -> Dict[str, Any]:
        """Exporta contrato no formato ODCS v3.0.2"""
        use_case = ExportODCSUseCase(self.session)
        return await use_case.execute(contract_id, version)
    
    async def validate_contract(
        self,
        contract_id: UUID,
        version: Optional[str] = None
    ) -> Dict[str, Any]:
        """Valida um contrato de dados"""
        # Buscar contrato e versão
        odcs_export = await self.export_odcs(contract_id, version)
        
        # Validações básicas
        validation_results = {
            "is_valid": True,
            "errors": [],
            "warnings": [],
            "contract_id": contract_id,
            "version": version or "active"
        }
        
        # Validar estrutura ODCS
        required_fields = ["dataContractSpecification", "id", "info", "schema"]
        for field in required_fields:
            if field not in odcs_export:
                validation_results["errors"].append(f"Campo obrigatório ausente: {field}")
                validation_results["is_valid"] = False
        
        # Validar versão da especificação
        if odcs_export.get("dataContractSpecification") != "3.0.2":
            validation_results["warnings"].append(
                "Versão da especificação ODCS pode não ser a mais recente"
            )
        
        # Validar schema
        schema = odcs_export.get("schema", {})
        if not schema.get("type"):
            validation_results["errors"].append("Tipo do schema não especificado")
            validation_results["is_valid"] = False
        
        if not schema.get("properties"):
            validation_results["warnings"].append("Schema não possui propriedades definidas")
        
        return validation_results


class EntityService:
    """Serviço para gerenciamento de entidades"""
    
    def __init__(self, session: AsyncSession):
        self.session = session
    
    async def create_entity(
        self,
        dto: EntityCreateDTO,
        created_by: Optional[UUID] = None
    ) -> EntityResponseDTO:
        """Cria uma nova entidade"""
        use_case = CreateEntityUseCase(self.session)
        return await use_case.execute(dto, created_by)
    
    async def update_entity(
        self,
        entity_id: UUID,
        dto: EntityUpdateDTO,
        updated_by: Optional[UUID] = None
    ) -> EntityResponseDTO:
        """Atualiza uma entidade"""
        use_case = UpdateEntityUseCase(self.session)
        return await use_case.execute(entity_id, dto, updated_by)
    
    async def search_entities(
        self,
        search_params: SearchParams,
        pagination: PaginationParams
    ) -> PaginatedResponse:
        """Busca entidades por texto"""
        use_case = SearchEntitiesUseCase(self.session)
        return await use_case.execute(
            search_params.query,
            pagination,
            search_params.filters
        )
    
    async def sync_with_unity_catalog(
        self,
        entity_id: UUID,
        force_update: bool = False
    ) -> Dict[str, Any]:
        """Sincroniza entidade com Unity Catalog"""
        # Implementação futura - integração com Unity Catalog
        return {
            "entity_id": entity_id,
            "sync_status": "not_implemented",
            "message": "Sincronização com Unity Catalog será implementada na próxima fase"
        }


class QualityService:
    """Serviço para gerenciamento de qualidade de dados"""
    
    def __init__(self, session: AsyncSession):
        self.session = session
    
    async def create_quality_rule(
        self,
        dto: QualityRuleCreateDTO,
        created_by: Optional[UUID] = None
    ) -> QualityRuleResponseDTO:
        """Cria uma nova regra de qualidade"""
        use_case = CreateQualityRuleUseCase(self.session)
        return await use_case.execute(dto, created_by)
    
    async def execute_quality_rule(self, rule_id: UUID) -> Dict[str, Any]:
        """Executa uma regra de qualidade"""
        use_case = ExecuteQualityRuleUseCase(self.session)
        return await use_case.execute(rule_id)
    
    async def execute_quality_rules_for_entity(
        self,
        entity_id: UUID
    ) -> List[Dict[str, Any]]:
        """Executa todas as regras de qualidade de uma entidade"""
        from database.repositories import QualityRuleRepository
        
        rule_repo = QualityRuleRepository(self.session)
        rules = await rule_repo.get_by_entity(entity_id)
        
        results = []
        for rule in rules:
            if rule.is_active:
                try:
                    result = await self.execute_quality_rule(rule.id)
                    results.append(result)
                except Exception as e:
                    results.append({
                        "rule_id": rule.id,
                        "error": str(e),
                        "status": "failed"
                    })
        
        return results
    
    async def get_quality_dashboard(
        self,
        entity_id: Optional[UUID] = None,
        domain_id: Optional[UUID] = None
    ) -> Dict[str, Any]:
        """Retorna dashboard de qualidade"""
        from database.repositories import QualityMetricRepository
        
        metric_repo = QualityMetricRepository(self.session)
        
        # Buscar métricas mais recentes
        if entity_id:
            metrics = await metric_repo.get_latest_by_entity(entity_id)
        else:
            # Implementar busca por domínio ou geral
            metrics = []
        
        # Calcular estatísticas
        total_metrics = len(metrics)
        passed_metrics = len([m for m in metrics if m.status == "passed"])
        warning_metrics = len([m for m in metrics if m.status == "warning"])
        critical_metrics = len([m for m in metrics if m.status == "critical"])
        
        quality_score = (passed_metrics / total_metrics * 100) if total_metrics > 0 else 0
        
        return {
            "entity_id": entity_id,
            "domain_id": domain_id,
            "quality_score": round(quality_score, 2),
            "total_metrics": total_metrics,
            "passed_metrics": passed_metrics,
            "warning_metrics": warning_metrics,
            "critical_metrics": critical_metrics,
            "status": "critical" if critical_metrics > 0 else "warning" if warning_metrics > 0 else "passed"
        }


class GovernanceService:
    """Serviço para operações gerais de governança"""
    
    def __init__(self, session: AsyncSession):
        self.session = session
    
    async def get_governance_overview(self) -> Dict[str, Any]:
        """Retorna visão geral da governança"""
        from database.repositories import (
            DataContractRepository,
            EntityRepository,
            QualityRuleRepository,
            DomainRepository
        )
        
        # Contar recursos
        contract_repo = DataContractRepository(self.session)
        entity_repo = EntityRepository(self.session)
        rule_repo = QualityRuleRepository(self.session)
        domain_repo = DomainRepository(self.session)
        
        total_contracts = await contract_repo.count()
        active_contracts = await contract_repo.count({"status": "active"})
        total_entities = await entity_repo.count()
        total_rules = await rule_repo.count()
        active_rules = await rule_repo.count({"is_active": True})
        total_domains = await domain_repo.count()
        
        return {
            "contracts": {
                "total": total_contracts,
                "active": active_contracts,
                "draft": await contract_repo.count({"status": "draft"}),
                "deprecated": await contract_repo.count({"status": "deprecated"})
            },
            "entities": {
                "total": total_entities,
                "by_type": {
                    "table": await entity_repo.count({"type": "table"}),
                    "view": await entity_repo.count({"type": "view"}),
                    "dataset": await entity_repo.count({"type": "dataset"})
                }
            },
            "quality": {
                "total_rules": total_rules,
                "active_rules": active_rules,
                "inactive_rules": total_rules - active_rules
            },
            "domains": {
                "total": total_domains
            }
        }
    
    async def get_compliance_status(
        self,
        framework: str = "LGPD"
    ) -> Dict[str, Any]:
        """Retorna status de compliance"""
        # Implementação futura - verificação de compliance
        return {
            "framework": framework,
            "status": "not_implemented",
            "message": "Verificação de compliance será implementada na próxima fase"
        }
    
    async def generate_lineage_graph(
        self,
        entity_id: UUID,
        depth: int = 3
    ) -> Dict[str, Any]:
        """Gera grafo de linhagem de dados"""
        # Implementação futura - linhagem de dados
        return {
            "entity_id": entity_id,
            "depth": depth,
            "status": "not_implemented",
            "message": "Linhagem de dados será implementada na próxima fase"
        }


class IntegrationService:
    """Serviço para integrações externas"""
    
    def __init__(self, session: AsyncSession):
        self.session = session
    
    async def sync_unity_catalog(
        self,
        catalog_name: Optional[str] = None,
        schema_name: Optional[str] = None
    ) -> Dict[str, Any]:
        """Sincroniza com Unity Catalog"""
        # Implementação futura
        return {
            "catalog": catalog_name,
            "schema": schema_name,
            "status": "not_implemented",
            "message": "Sincronização com Unity Catalog será implementada na fase de integrações"
        }
    
    async def import_from_axon(
        self,
        glossary_id: str
    ) -> Dict[str, Any]:
        """Importa glossário do Informatica Axon"""
        # Implementação futura
        return {
            "glossary_id": glossary_id,
            "status": "not_implemented",
            "message": "Importação do Axon será implementada na fase de integrações"
        }
    
    async def export_to_datahub(
        self,
        entity_ids: List[UUID]
    ) -> Dict[str, Any]:
        """Exporta metadados para DataHub"""
        # Implementação futura
        return {
            "entity_ids": entity_ids,
            "status": "not_implemented",
            "message": "Exportação para DataHub será implementada na fase de integrações"
        }

