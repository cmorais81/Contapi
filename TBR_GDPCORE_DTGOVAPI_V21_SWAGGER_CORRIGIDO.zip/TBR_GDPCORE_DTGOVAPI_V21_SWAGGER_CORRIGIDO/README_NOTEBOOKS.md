# Notebooks Databricks para API de Governança de Dados

**Desenvolvido por:** Carlos Morais  
**Versão:** 2.1  
**Data:** Janeiro 2025  

## Visão Geral

Este documento apresenta dois notebooks Databricks especializados para extrair dados de diferentes fontes e alimentar o modelo de governança de dados baseado no ODCS v3.0.2 com 56 tabelas. Os notebooks foram desenvolvidos para integrar perfeitamente com a API de Governança de Dados V2.1, proporcionando uma solução completa de extração, transformação e carregamento de metadados.

## Notebooks Disponíveis

### 1. Unity Catalog Data Extractor (`notebook_unity_catalog_extractor.py`)

O notebook Unity Catalog é responsável por extrair metadados diretamente do Unity Catalog do Databricks, capturando informações essenciais sobre catálogos, schemas, tabelas, colunas, lineage, políticas de acesso e métricas de uso.

#### Funcionalidades Principais

**Extração de Metadados Estruturais:**
- Catálogos e schemas como domínios hierárquicos
- Tabelas e views como entidades de dados
- Colunas com tipos de dados e metadados
- Relacionamentos e dependências entre objetos

**Lineage e Rastreabilidade:**
- Mapeamento completo de lineage entre tabelas
- Identificação de transformações e fluxos de dados
- Rastreamento de origem e destino dos dados
- Confiança e qualidade dos relacionamentos

**Políticas e Segurança:**
- Extração de políticas de acesso (row-level security)
- Políticas de mascaramento de colunas
- Classificações de segurança e privacidade
- Controles de acesso granulares

**Métricas e Uso:**
- Estatísticas de uso das tabelas (leituras/escritas)
- Métricas de performance e volume
- Padrões de acesso e frequência de uso
- Dados históricos de utilização

**Tags e Classificações:**
- Extração de tags aplicadas aos objetos
- Classificações automáticas e manuais
- Categorização por domínio de negócio
- Metadados de contexto e propósito

#### Estrutura do Notebook

O notebook está organizado em 12 seções principais que seguem um fluxo lógico de extração:

1. **Configuração e Imports** - Setup inicial e bibliotecas necessárias
2. **Funções Auxiliares** - Utilitários para API calls e processamento
3. **Extração de Catálogos e Schemas** - Estrutura hierárquica básica
4. **Extração de Tabelas e Metadados** - Entidades principais e atributos
5. **Extração de Tags e Classificações** - Sistema de categorização
6. **Extração de Lineage e Relacionamentos** - Mapeamento de dependências
7. **Extração de Métricas de Uso** - Estatísticas operacionais
8. **Extração de Políticas de Acesso** - Controles de segurança
9. **Consolidação e Preparação dos Dados** - Estruturação final
10. **Envio dos Dados para a API de Governança** - Integração com API
11. **Salvamento Local dos Dados** - Backup e análise
12. **Relatório Final** - Resumo e próximos passos

#### Mapeamento para o Modelo de Governança

O notebook mapeia os dados extraídos para as seguintes tabelas do modelo:

- **domains** - Catálogos e schemas como domínios hierárquicos
- **entities** - Tabelas, views e objetos de dados
- **entity_attributes** - Colunas com metadados detalhados
- **tags** e **entity_tags** - Sistema de classificação
- **lineage_relationships** - Mapeamento de dependências
- **usage_metrics** - Estatísticas de uso e performance
- **access_policies** e **masking_policies** - Controles de segurança
- **external_references** - Referências para Unity Catalog

### 2. Azure Service Principal Data Extractor (`notebook_azure_spn_extractor.py`)

O notebook Azure SPN utiliza autenticação via Service Principal para extrair metadados de diversos serviços Azure, incluindo Data Factory, SQL Database, Storage, Synapse Analytics e Key Vault.

#### Funcionalidades Principais

**Azure Data Factory:**
- Extração de pipelines e suas configurações
- Datasets e linked services
- Metadados de atividades e transformações
- Dependências entre componentes

**Azure SQL Database:**
- Servidores e bancos de dados
- Schemas e estruturas de tabelas (quando acessível)
- Configurações de performance e SKU
- Metadados de conectividade

**Azure Storage:**
- Storage accounts e configurações
- Containers e estrutura hierárquica
- Blobs e metadados de arquivos
- Políticas de acesso e retenção

**Azure Synapse Analytics:**
- Workspaces e configurações
- SQL pools e Spark pools
- Recursos computacionais
- Configurações de performance

**Azure Key Vault:**
- Vaults e configurações de segurança
- Metadados de políticas (sem exposição de secrets)
- Controles de acesso
- Configurações de auditoria

#### Estrutura do Notebook

O notebook Azure SPN está organizado em 12 seções especializadas:

1. **Configuração e Imports** - Setup Azure SDK e credenciais
2. **Autenticação e Clientes Azure** - Configuração Service Principal
3. **Funções Auxiliares** - Utilitários para Azure APIs
4. **Extração de Resource Groups e Recursos** - Estrutura organizacional
5. **Extração de Azure Data Factory** - Pipelines e datasets
6. **Extração de Azure SQL Database** - Bancos e metadados
7. **Extração de Azure Storage** - Contas e containers
8. **Extração de Azure Synapse** - Workspaces e pools
9. **Extração de Azure Key Vault** - Vaults e políticas
10. **Consolidação dos Dados Azure** - Estruturação unificada
11. **Salvamento Local dos Dados** - Backup e análise
12. **Relatório Final** - Resumo e configurações

#### Mapeamento para o Modelo de Governança

O notebook Azure mapeia os recursos para as seguintes tabelas:

- **domains** - Resource Groups como domínios organizacionais
- **entities** - Recursos Azure como entidades de dados
- **tags** e **entity_tags** - Classificação por tipo de serviço
- **external_references** - Referências para portal Azure
- **access_policies** - Políticas de segurança quando disponíveis

## Arquitetura de Integração

### Fluxo de Dados

```
Unity Catalog ──┐
                ├──► Notebooks Databricks ──► API Governança ──► Modelo ODCS v3.0.2
Azure Services ─┘
```

### Componentes da Solução

**Fontes de Dados:**
- Unity Catalog (metadados nativos Databricks)
- Azure Services (via Service Principal)
- Sistemas externos (extensível)

**Camada de Extração:**
- Notebooks Databricks especializados
- Autenticação segura (JWT + SPN)
- Processamento distribuído Spark

**Camada de Transformação:**
- Mapeamento para modelo ODCS v3.0.2
- Normalização e limpeza de dados
- Enriquecimento com metadados

**Camada de Carregamento:**
- API REST de Governança V2.1
- Validação e controle de qualidade
- Auditoria e rastreabilidade

### Benefícios da Arquitetura

**Escalabilidade:**
- Processamento distribuído via Spark
- Extração paralela de múltiplas fontes
- Capacidade de processar grandes volumes

**Flexibilidade:**
- Notebooks modulares e reutilizáveis
- Configuração via variáveis de ambiente
- Extensibilidade para novas fontes

**Confiabilidade:**
- Retry automático em falhas
- Validação de dados extraídos
- Backup local para recuperação

**Segurança:**
- Autenticação robusta (JWT + SPN)
- Não exposição de credenciais
- Auditoria completa de operações

## Configuração e Execução

### Pré-requisitos

**Ambiente Databricks:**
- Cluster com runtime 11.3 LTS ou superior
- Bibliotecas Azure SDK instaladas
- Conectividade com Unity Catalog

**Credenciais Azure:**
- Service Principal registrado
- Permissões adequadas nos recursos
- Tenant ID, Client ID e Client Secret

**API de Governança:**
- Instância V2.1 em execução
- Token JWT válido
- Conectividade de rede

### Variáveis de Ambiente

**Unity Catalog Notebook:**
```bash
API_BASE_URL=http://localhost:8000/api/v1
API_TOKEN=your_jwt_token_here
```

**Azure SPN Notebook:**
```bash
AZURE_TENANT_ID=your-tenant-id
AZURE_CLIENT_ID=your-client-id
AZURE_CLIENT_SECRET=your-client-secret
AZURE_SUBSCRIPTION_ID=your-subscription-id
API_BASE_URL=http://localhost:8000/api/v1
API_TOKEN=your_jwt_token_here
```

### Permissões Necessárias

**Unity Catalog:**
- READ access to system.information_schema
- READ access to system.access.table_lineage
- READ access to system.access.table_usage
- READ access to system.access.policies

**Azure Services:**
- Data Factory Contributor
- SQL DB Contributor
- Storage Account Contributor
- Synapse Contributor
- Key Vault Reader

### Execução dos Notebooks

**Passo 1: Configuração**
1. Importar notebooks no workspace Databricks
2. Configurar variáveis de ambiente
3. Instalar dependências necessárias
4. Validar conectividade com fontes

**Passo 2: Execução Unity Catalog**
1. Executar notebook Unity Catalog
2. Verificar logs de extração
3. Validar dados extraídos
4. Confirmar envio para API

**Passo 3: Execução Azure SPN**
1. Executar notebook Azure SPN
2. Verificar autenticação Azure
3. Validar recursos extraídos
4. Confirmar integração com API

**Passo 4: Validação**
1. Acessar interface web da API
2. Verificar dados importados
3. Validar relacionamentos
4. Confirmar métricas e tags

## Monitoramento e Manutenção

### Logs e Auditoria

**Logs de Execução:**
- Timestamps de início e fim
- Contadores de registros processados
- Erros e exceções capturadas
- Performance e tempo de execução

**Auditoria de Dados:**
- Rastreamento de origem dos dados
- Versionamento de extrações
- Histórico de modificações
- Correlação entre execuções

### Métricas de Performance

**Indicadores Chave:**
- Tempo total de execução
- Throughput de registros/segundo
- Taxa de sucesso/erro
- Utilização de recursos

**Alertas e Notificações:**
- Falhas de execução
- Degradação de performance
- Problemas de conectividade
- Inconsistências de dados

### Manutenção Preventiva

**Atualizações Regulares:**
- Versões das bibliotecas Azure SDK
- Compatibilidade com Unity Catalog
- Ajustes no modelo de dados
- Otimizações de performance

**Validação Contínua:**
- Testes de conectividade
- Validação de credenciais
- Verificação de permissões
- Monitoramento de quotas

## Extensibilidade e Customização

### Adição de Novas Fontes

**Estrutura Padrão:**
1. Seção de configuração específica
2. Funções de autenticação
3. Métodos de extração
4. Mapeamento para modelo
5. Consolidação de dados

**Exemplos de Extensões:**
- Informatica Axon
- Apache Atlas
- AWS Glue Catalog
- Google Cloud Data Catalog

### Customização de Mapeamentos

**Flexibilidade do Modelo:**
- Campos adicionais em schema_definition
- Tags customizadas por organização
- Classificações específicas
- Metadados estendidos

**Configuração via Parâmetros:**
- Filtros de extração
- Regras de mapeamento
- Transformações customizadas
- Validações específicas

## Troubleshooting

### Problemas Comuns

**Erro de Autenticação:**
- Verificar credenciais Azure
- Validar token JWT da API
- Confirmar permissões
- Checar expiração de tokens

**Falhas de Conectividade:**
- Verificar configuração de rede
- Validar URLs e endpoints
- Confirmar firewall rules
- Testar conectividade manual

**Problemas de Performance:**
- Ajustar tamanho do cluster
- Otimizar queries de extração
- Implementar paralelização
- Configurar cache adequado

**Inconsistências de Dados:**
- Validar mapeamentos
- Verificar transformações
- Confirmar tipos de dados
- Analisar logs detalhados

### Suporte e Documentação

**Recursos Disponíveis:**
- Documentação técnica completa
- Exemplos de configuração
- Scripts de troubleshooting
- Comunidade de usuários

**Contato para Suporte:**
- Desenvolvedor: Carlos Morais
- Documentação: README_NOTEBOOKS.md
- Logs: /tmp/extraction_reports/
- Backup: /tmp/extraction_data/

## Conclusão

Os notebooks Databricks para extração de dados representam uma solução robusta e escalável para alimentar o modelo de governança de dados. Com funcionalidades abrangentes de extração, transformação e carregamento, eles proporcionam uma base sólida para implementar governança de dados efetiva em organizações que utilizam Databricks e Azure.

A arquitetura modular permite fácil extensão para novas fontes de dados, enquanto a integração nativa com a API de Governança V2.1 garante consistência e confiabilidade dos dados. Com monitoramento adequado e manutenção preventiva, estes notebooks podem operar de forma autônoma, proporcionando visibilidade contínua sobre o patrimônio de dados da organização.

**Próximos Passos Recomendados:**
1. Implementar execução agendada dos notebooks
2. Configurar alertas e monitoramento
3. Estender para fontes adicionais conforme necessário
4. Desenvolver dashboards de governança baseados nos dados extraídos
5. Implementar workflows de aprovação para mudanças críticas

