# Databricks notebook source
# MAGIC %md
# MAGIC # Unity Catalog Data Extractor para API de Governança de Dados
# MAGIC 
# MAGIC **Desenvolvido por:** Carlos Morais  
# MAGIC **Versão:** 2.1  
# MAGIC **Data:** Janeiro 2025  
# MAGIC 
# MAGIC ## Objetivo
# MAGIC 
# MAGIC Este notebook extrai metadados e dados do Unity Catalog para alimentar o modelo de governança de dados com 56 tabelas baseado no ODCS v3.0.2.
# MAGIC 
# MAGIC ## Funcionalidades
# MAGIC 
# MAGIC - ✅ **Extração de Catálogos, Schemas e Tabelas**
# MAGIC - ✅ **Metadados de Colunas e Tipos de Dados**
# MAGIC - ✅ **Lineage e Relacionamentos**
# MAGIC - ✅ **Políticas de Acesso e Mascaramento**
# MAGIC - ✅ **Tags e Classificações**
# MAGIC - ✅ **Métricas de Uso e Performance**
# MAGIC - ✅ **Qualidade de Dados**
# MAGIC - ✅ **Mapeamento para API de Governança**

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. Configuração e Imports

# COMMAND ----------

import json
import pandas as pd
from datetime import datetime, timedelta
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
import requests
import uuid
import re

# Configurações da API de Governança
API_BASE_URL = "http://localhost:8000/api/v1"
API_TOKEN = "your_jwt_token_here"  # Substituir pelo token real

# Headers para requisições
headers = {
    "Authorization": f"Bearer {API_TOKEN}",
    "Content-Type": "application/json"
}

print("✅ Configuração inicial concluída")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Funções Auxiliares

# COMMAND ----------

def safe_api_call(url, method="GET", data=None, max_retries=3):
    """
    Faz chamadas seguras para a API com retry automático
    """
    for attempt in range(max_retries):
        try:
            if method == "GET":
                response = requests.get(url, headers=headers, timeout=30)
            elif method == "POST":
                response = requests.post(url, headers=headers, json=data, timeout=30)
            elif method == "PUT":
                response = requests.put(url, headers=headers, json=data, timeout=30)
            
            if response.status_code in [200, 201]:
                return response.json()
            elif response.status_code == 401:
                print(f"❌ Erro de autenticação: {response.status_code}")
                return None
            else:
                print(f"⚠️ Tentativa {attempt + 1}: Status {response.status_code}")
                
        except Exception as e:
            print(f"⚠️ Erro na tentativa {attempt + 1}: {str(e)}")
            
        if attempt < max_retries - 1:
            time.sleep(2 ** attempt)  # Backoff exponencial
    
    print(f"❌ Falha após {max_retries} tentativas")
    return None

def generate_uuid():
    """Gera UUID único"""
    return str(uuid.uuid4())

def clean_string(value):
    """Limpa strings para inserção no banco"""
    if value is None:
        return None
    return str(value).strip()[:255] if len(str(value)) > 255 else str(value).strip()

def extract_unity_path_components(full_path):
    """
    Extrai componentes do caminho Unity Catalog
    Formato: catalog.schema.table
    """
    if not full_path or '.' not in full_path:
        return None, None, None
    
    parts = full_path.split('.')
    if len(parts) >= 3:
        return parts[0], parts[1], '.'.join(parts[2:])
    elif len(parts) == 2:
        return parts[0], parts[1], None
    else:
        return parts[0], None, None

print("✅ Funções auxiliares definidas")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. Extração de Catálogos e Schemas

# COMMAND ----------

def extract_catalogs_and_schemas():
    """
    Extrai informações de catálogos e schemas do Unity Catalog
    """
    print("🔍 Extraindo catálogos e schemas...")
    
    # Obter lista de catálogos
    catalogs_df = spark.sql("SHOW CATALOGS")
    catalogs = catalogs_df.collect()
    
    domains_data = []
    entities_data = []
    
    for catalog_row in catalogs:
        catalog_name = catalog_row['catalog']
        
        # Pular catálogos do sistema
        if catalog_name in ['system', 'information_schema']:
            continue
            
        print(f"📁 Processando catálogo: {catalog_name}")
        
        # Criar domínio para o catálogo
        catalog_domain = {
            "id": generate_uuid(),
            "name": catalog_name,
            "description": f"Domínio do catálogo Unity Catalog: {catalog_name}",
            "parent_domain_id": None,
            "steward_id": None,  # Será preenchido posteriormente
            "created_at": datetime.now().isoformat(),
            "updated_at": datetime.now().isoformat()
        }
        domains_data.append(catalog_domain)
        
        try:
            # Obter schemas do catálogo
            schemas_df = spark.sql(f"SHOW SCHEMAS IN {catalog_name}")
            schemas = schemas_df.collect()
            
            for schema_row in schemas:
                schema_name = schema_row['databaseName']
                
                # Pular schemas do sistema
                if schema_name in ['information_schema', 'default']:
                    continue
                
                print(f"  📂 Processando schema: {schema_name}")
                
                # Criar subdomínio para o schema
                schema_domain = {
                    "id": generate_uuid(),
                    "name": f"{catalog_name}.{schema_name}",
                    "description": f"Schema {schema_name} do catálogo {catalog_name}",
                    "parent_domain_id": catalog_domain["id"],
                    "steward_id": None,
                    "created_at": datetime.now().isoformat(),
                    "updated_at": datetime.now().isoformat()
                }
                domains_data.append(schema_domain)
                
        except Exception as e:
            print(f"⚠️ Erro ao processar schemas do catálogo {catalog_name}: {str(e)}")
            continue
    
    print(f"✅ Extraídos {len(domains_data)} domínios (catálogos e schemas)")
    return domains_data

# Executar extração
domains_data = extract_catalogs_and_schemas()

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Extração de Tabelas e Metadados

# COMMAND ----------

def extract_tables_and_metadata():
    """
    Extrai informações detalhadas de tabelas e seus metadados
    """
    print("🔍 Extraindo tabelas e metadados...")
    
    entities_data = []
    attributes_data = []
    external_refs_data = []
    
    # Obter lista de todas as tabelas
    try:
        # Query para obter todas as tabelas do Unity Catalog
        tables_query = """
        SELECT 
            table_catalog,
            table_schema,
            table_name,
            table_type,
            data_source_format,
            location,
            created,
            last_altered,
            comment
        FROM system.information_schema.tables
        WHERE table_catalog NOT IN ('system')
        """
        
        tables_df = spark.sql(tables_query)
        tables = tables_df.collect()
        
        for table_row in tables:
            catalog_name = table_row['table_catalog']
            schema_name = table_row['table_schema']
            table_name = table_row['table_name']
            table_type = table_row['table_type']
            
            full_table_name = f"{catalog_name}.{schema_name}.{table_name}"
            
            print(f"📊 Processando tabela: {full_table_name}")
            
            # Criar entidade para a tabela
            entity_id = generate_uuid()
            entity = {
                "id": entity_id,
                "name": table_name,
                "type": "table",
                "description": clean_string(table_row['comment']) or f"Tabela {table_name} do schema {schema_name}",
                "domain_id": None,  # Será mapeado posteriormente
                "steward_id": None,
                "unity_catalog_path": full_table_name,
                "schema_definition": {
                    "catalog": catalog_name,
                    "schema": schema_name,
                    "table_type": table_type,
                    "data_source_format": table_row['data_source_format'],
                    "location": table_row['location'],
                    "created": str(table_row['created']) if table_row['created'] else None,
                    "last_altered": str(table_row['last_altered']) if table_row['last_altered'] else None
                },
                "business_glossary_id": None,
                "classification": "unclassified",
                "created_at": datetime.now().isoformat(),
                "updated_at": datetime.now().isoformat(),
                "created_by": None,
                "updated_by": None
            }
            entities_data.append(entity)
            
            # Extrair colunas da tabela
            try:
                columns_query = f"""
                SELECT 
                    column_name,
                    data_type,
                    is_nullable,
                    column_default,
                    comment
                FROM system.information_schema.columns
                WHERE table_catalog = '{catalog_name}'
                AND table_schema = '{schema_name}'
                AND table_name = '{table_name}'
                ORDER BY ordinal_position
                """
                
                columns_df = spark.sql(columns_query)
                columns = columns_df.collect()
                
                for column_row in columns:
                    column_name = column_row['column_name']
                    data_type = column_row['data_type']
                    is_nullable = column_row['is_nullable'] == 'YES'
                    
                    attribute = {
                        "id": generate_uuid(),
                        "entity_id": entity_id,
                        "name": column_name,
                        "data_type": data_type,
                        "description": clean_string(column_row['comment']) or f"Coluna {column_name} da tabela {table_name}",
                        "is_nullable": is_nullable,
                        "is_primary_key": False,  # Será detectado posteriormente
                        "is_foreign_key": False,  # Será detectado posteriormente
                        "business_term_id": None,
                        "classification": "unclassified",
                        "masking_policy_id": None,
                        "created_at": datetime.now().isoformat(),
                        "updated_at": datetime.now().isoformat()
                    }
                    attributes_data.append(attribute)
                
            except Exception as e:
                print(f"⚠️ Erro ao extrair colunas da tabela {full_table_name}: {str(e)}")
                continue
            
            # Criar referência externa para Unity Catalog
            external_ref = {
                "id": generate_uuid(),
                "entity_id": entity_id,
                "reference_type": "unity_catalog",
                "external_id": full_table_name,
                "external_url": f"databricks://catalog/{catalog_name}/schema/{schema_name}/table/{table_name}",
                "sync_status": "active",
                "last_synced_at": datetime.now().isoformat(),
                "created_at": datetime.now().isoformat()
            }
            external_refs_data.append(external_ref)
            
    except Exception as e:
        print(f"❌ Erro ao extrair tabelas: {str(e)}")
        return [], [], []
    
    print(f"✅ Extraídas {len(entities_data)} entidades e {len(attributes_data)} atributos")
    return entities_data, attributes_data, external_refs_data

# Executar extração
entities_data, attributes_data, external_refs_data = extract_tables_and_metadata()

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. Extração de Tags e Classificações

# COMMAND ----------

def extract_tags_and_classifications():
    """
    Extrai tags e classificações aplicadas às entidades
    """
    print("🔍 Extraindo tags e classificações...")
    
    tags_data = []
    entity_tags_data = []
    
    try:
        # Query para obter tags do Unity Catalog
        tags_query = """
        SELECT DISTINCT
            tag_name,
            tag_value,
            catalog_name,
            schema_name,
            table_name,
            column_name
        FROM system.information_schema.table_tags
        UNION ALL
        SELECT DISTINCT
            tag_name,
            tag_value,
            catalog_name,
            schema_name,
            table_name,
            column_name
        FROM system.information_schema.column_tags
        """
        
        tags_df = spark.sql(tags_query)
        tags_rows = tags_df.collect()
        
        # Dicionário para evitar tags duplicadas
        unique_tags = {}
        
        for tag_row in tags_rows:
            tag_name = tag_row['tag_name']
            tag_value = tag_row['tag_value']
            
            # Criar tag única
            tag_key = f"{tag_name}:{tag_value}" if tag_value else tag_name
            
            if tag_key not in unique_tags:
                tag_id = generate_uuid()
                tag = {
                    "id": tag_id,
                    "name": tag_key,
                    "description": f"Tag {tag_name}" + (f" com valor {tag_value}" if tag_value else ""),
                    "color": "#007bff",
                    "category": "unity_catalog",
                    "created_at": datetime.now().isoformat()
                }
                tags_data.append(tag)
                unique_tags[tag_key] = tag_id
            
            # Associar tag à entidade (se for tag de tabela)
            if tag_row['table_name'] and not tag_row['column_name']:
                full_table_name = f"{tag_row['catalog_name']}.{tag_row['schema_name']}.{tag_row['table_name']}"
                
                # Encontrar entity_id correspondente
                entity_id = None
                for entity in entities_data:
                    if entity['unity_catalog_path'] == full_table_name:
                        entity_id = entity['id']
                        break
                
                if entity_id:
                    entity_tag = {
                        "id": generate_uuid(),
                        "entity_id": entity_id,
                        "tag_id": unique_tags[tag_key],
                        "created_at": datetime.now().isoformat(),
                        "created_by": None
                    }
                    entity_tags_data.append(entity_tag)
        
    except Exception as e:
        print(f"⚠️ Erro ao extrair tags: {str(e)}")
    
    print(f"✅ Extraídas {len(tags_data)} tags e {len(entity_tags_data)} associações")
    return tags_data, entity_tags_data

# Executar extração
tags_data, entity_tags_data = extract_tags_and_classifications()

# COMMAND ----------

# MAGIC %md
# MAGIC ## 6. Extração de Lineage e Relacionamentos

# COMMAND ----------

def extract_lineage_relationships():
    """
    Extrai relacionamentos de lineage entre entidades
    """
    print("🔍 Extraindo lineage e relacionamentos...")
    
    lineage_data = []
    
    try:
        # Query para obter lineage do Unity Catalog
        lineage_query = """
        SELECT 
            source_table_full_name,
            target_table_full_name,
            source_column_name,
            target_column_name
        FROM system.access.table_lineage
        WHERE source_table_full_name IS NOT NULL
        AND target_table_full_name IS NOT NULL
        """
        
        lineage_df = spark.sql(lineage_query)
        lineage_rows = lineage_df.collect()
        
        for lineage_row in lineage_rows:
            source_table = lineage_row['source_table_full_name']
            target_table = lineage_row['target_table_full_name']
            
            # Encontrar entity_ids correspondentes
            source_entity_id = None
            target_entity_id = None
            
            for entity in entities_data:
                if entity['unity_catalog_path'] == source_table:
                    source_entity_id = entity['id']
                elif entity['unity_catalog_path'] == target_table:
                    target_entity_id = entity['id']
            
            if source_entity_id and target_entity_id:
                relationship = {
                    "id": generate_uuid(),
                    "source_entity_id": source_entity_id,
                    "target_entity_id": target_entity_id,
                    "relationship_type": "data_flow",
                    "transformation_logic": None,
                    "confidence_score": 1.0,
                    "created_at": datetime.now().isoformat(),
                    "updated_at": datetime.now().isoformat()
                }
                lineage_data.append(relationship)
        
    except Exception as e:
        print(f"⚠️ Erro ao extrair lineage: {str(e)}")
    
    print(f"✅ Extraídos {len(lineage_data)} relacionamentos de lineage")
    return lineage_data

# Executar extração
lineage_data = extract_lineage_relationships()

# COMMAND ----------

# MAGIC %md
# MAGIC ## 7. Extração de Métricas de Uso

# COMMAND ----------

def extract_usage_metrics():
    """
    Extrai métricas de uso das tabelas
    """
    print("🔍 Extraindo métricas de uso...")
    
    usage_metrics_data = []
    
    try:
        # Query para obter métricas de uso
        usage_query = """
        SELECT 
            table_catalog,
            table_schema,
            table_name,
            usage_date,
            num_reads,
            num_writes,
            bytes_read,
            bytes_written
        FROM system.access.table_usage
        WHERE usage_date >= current_date() - INTERVAL 30 DAYS
        """
        
        usage_df = spark.sql(usage_query)
        usage_rows = usage_df.collect()
        
        for usage_row in usage_rows:
            full_table_name = f"{usage_row['table_catalog']}.{usage_row['table_schema']}.{usage_row['table_name']}"
            
            # Encontrar entity_id correspondente
            entity_id = None
            for entity in entities_data:
                if entity['unity_catalog_path'] == full_table_name:
                    entity_id = entity['id']
                    break
            
            if entity_id:
                # Métrica de leituras
                if usage_row['num_reads'] and usage_row['num_reads'] > 0:
                    read_metric = {
                        "id": generate_uuid(),
                        "entity_id": entity_id,
                        "metric_type": "reads_count",
                        "metric_value": float(usage_row['num_reads']),
                        "measurement_date": str(usage_row['usage_date']),
                        "additional_data": {
                            "bytes_read": usage_row['bytes_read']
                        },
                        "created_at": datetime.now().isoformat()
                    }
                    usage_metrics_data.append(read_metric)
                
                # Métrica de escritas
                if usage_row['num_writes'] and usage_row['num_writes'] > 0:
                    write_metric = {
                        "id": generate_uuid(),
                        "entity_id": entity_id,
                        "metric_type": "writes_count",
                        "metric_value": float(usage_row['num_writes']),
                        "measurement_date": str(usage_row['usage_date']),
                        "additional_data": {
                            "bytes_written": usage_row['bytes_written']
                        },
                        "created_at": datetime.now().isoformat()
                    }
                    usage_metrics_data.append(write_metric)
        
    except Exception as e:
        print(f"⚠️ Erro ao extrair métricas de uso: {str(e)}")
    
    print(f"✅ Extraídas {len(usage_metrics_data)} métricas de uso")
    return usage_metrics_data

# Executar extração
usage_metrics_data = extract_usage_metrics()

# COMMAND ----------

# MAGIC %md
# MAGIC ## 8. Extração de Políticas de Acesso

# COMMAND ----------

def extract_access_policies():
    """
    Extrai políticas de acesso e mascaramento
    """
    print("🔍 Extraindo políticas de acesso...")
    
    access_policies_data = []
    masking_policies_data = []
    
    try:
        # Query para obter políticas de acesso
        policies_query = """
        SELECT 
            policy_name,
            policy_type,
            table_catalog,
            table_schema,
            table_name,
            column_name,
            policy_definition
        FROM system.access.policies
        """
        
        policies_df = spark.sql(policies_query)
        policies_rows = policies_df.collect()
        
        for policy_row in policies_rows:
            policy_name = policy_row['policy_name']
            policy_type = policy_row['policy_type']
            
            if policy_type == 'ROW_FILTER':
                # Política de acesso a linhas
                full_table_name = f"{policy_row['table_catalog']}.{policy_row['table_schema']}.{policy_row['table_name']}"
                
                # Encontrar entity_id correspondente
                entity_id = None
                for entity in entities_data:
                    if entity['unity_catalog_path'] == full_table_name:
                        entity_id = entity['id']
                        break
                
                if entity_id:
                    access_policy = {
                        "id": generate_uuid(),
                        "name": policy_name,
                        "description": f"Política de filtro de linhas para {full_table_name}",
                        "policy_definition": {
                            "type": "row_filter",
                            "definition": policy_row['policy_definition'],
                            "table": full_table_name
                        },
                        "entity_id": entity_id,
                        "is_active": True,
                        "created_at": datetime.now().isoformat(),
                        "updated_at": datetime.now().isoformat()
                    }
                    access_policies_data.append(access_policy)
            
            elif policy_type == 'COLUMN_MASK':
                # Política de mascaramento de colunas
                masking_policy = {
                    "id": generate_uuid(),
                    "name": policy_name,
                    "description": f"Política de mascaramento para coluna {policy_row['column_name']}",
                    "policy_type": "column_mask",
                    "masking_function": policy_row['policy_definition'],
                    "is_active": True,
                    "created_at": datetime.now().isoformat(),
                    "updated_at": datetime.now().isoformat()
                }
                masking_policies_data.append(masking_policy)
        
    except Exception as e:
        print(f"⚠️ Erro ao extrair políticas: {str(e)}")
    
    print(f"✅ Extraídas {len(access_policies_data)} políticas de acesso e {len(masking_policies_data)} políticas de mascaramento")
    return access_policies_data, masking_policies_data

# Executar extração
access_policies_data, masking_policies_data = extract_access_policies()

# COMMAND ----------

# MAGIC %md
# MAGIC ## 9. Consolidação e Preparação dos Dados

# COMMAND ----------

def consolidate_extracted_data():
    """
    Consolida todos os dados extraídos e prepara para envio à API
    """
    print("🔄 Consolidando dados extraídos...")
    
    # Resumo dos dados extraídos
    summary = {
        "domains": len(domains_data),
        "entities": len(entities_data),
        "attributes": len(attributes_data),
        "tags": len(tags_data),
        "entity_tags": len(entity_tags_data),
        "lineage_relationships": len(lineage_data),
        "usage_metrics": len(usage_metrics_data),
        "access_policies": len(access_policies_data),
        "masking_policies": len(masking_policies_data),
        "external_references": len(external_refs_data)
    }
    
    print("📊 Resumo dos dados extraídos:")
    for key, value in summary.items():
        print(f"  • {key}: {value} registros")
    
    # Criar estrutura consolidada
    consolidated_data = {
        "extraction_metadata": {
            "extracted_at": datetime.now().isoformat(),
            "source": "unity_catalog",
            "extractor_version": "2.1",
            "total_records": sum(summary.values())
        },
        "domains": domains_data,
        "entities": entities_data,
        "entity_attributes": attributes_data,
        "tags": tags_data,
        "entity_tags": entity_tags_data,
        "lineage_relationships": lineage_data,
        "usage_metrics": usage_metrics_data,
        "access_policies": access_policies_data,
        "masking_policies": masking_policies_data,
        "external_references": external_refs_data
    }
    
    return consolidated_data, summary

# Executar consolidação
consolidated_data, extraction_summary = consolidate_extracted_data()

# COMMAND ----------

# MAGIC %md
# MAGIC ## 10. Envio dos Dados para a API de Governança

# COMMAND ----------

def send_data_to_governance_api(data):
    """
    Envia os dados extraídos para a API de Governança
    """
    print("📤 Enviando dados para a API de Governança...")
    
    results = {
        "success": 0,
        "errors": 0,
        "details": []
    }
    
    # Mapear tipos de dados para endpoints da API
    endpoint_mapping = {
        "domains": "/domains",
        "entities": "/entities", 
        "entity_attributes": "/entities/{entity_id}/attributes",
        "tags": "/tags",
        "entity_tags": "/entities/{entity_id}/tags",
        "lineage_relationships": "/lineage",
        "usage_metrics": "/metrics/usage",
        "access_policies": "/policies/access",
        "masking_policies": "/policies/masking",
        "external_references": "/entities/{entity_id}/references"
    }
    
    # Enviar cada tipo de dados
    for data_type, records in data.items():
        if data_type == "extraction_metadata":
            continue
            
        if not records:
            print(f"⏭️ Pulando {data_type} - nenhum registro")
            continue
            
        print(f"📤 Enviando {len(records)} registros de {data_type}...")
        
        endpoint = endpoint_mapping.get(data_type)
        if not endpoint:
            print(f"⚠️ Endpoint não encontrado para {data_type}")
            continue
        
        # Enviar registros em lotes
        batch_size = 50
        for i in range(0, len(records), batch_size):
            batch = records[i:i + batch_size]
            
            try:
                # Para alguns endpoints, precisamos enviar individualmente
                if data_type in ["entity_attributes", "entity_tags", "external_references"]:
                    for record in batch:
                        entity_id = record.get("entity_id")
                        if entity_id:
                            formatted_endpoint = endpoint.format(entity_id=entity_id)
                            url = f"{API_BASE_URL}{formatted_endpoint}"
                            
                            response = safe_api_call(url, "POST", record)
                            if response:
                                results["success"] += 1
                            else:
                                results["errors"] += 1
                else:
                    # Envio em lote
                    url = f"{API_BASE_URL}{endpoint}"
                    response = safe_api_call(url, "POST", {"records": batch})
                    
                    if response:
                        results["success"] += len(batch)
                        print(f"  ✅ Lote {i//batch_size + 1} enviado com sucesso")
                    else:
                        results["errors"] += len(batch)
                        print(f"  ❌ Erro no lote {i//batch_size + 1}")
                        
            except Exception as e:
                print(f"  ❌ Erro ao enviar lote de {data_type}: {str(e)}")
                results["errors"] += len(batch)
        
        results["details"].append({
            "data_type": data_type,
            "total_records": len(records),
            "status": "completed"
        })
    
    return results

# Executar envio (comentado para evitar erros se API não estiver disponível)
# send_results = send_data_to_governance_api(consolidated_data)
# print(f"📊 Resultados do envio: {send_results['success']} sucessos, {send_results['errors']} erros")

print("⚠️ Envio para API comentado - descomente para executar")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 11. Salvamento Local dos Dados

# COMMAND ----------

def save_data_locally(data, summary):
    """
    Salva os dados extraídos localmente para backup e análise
    """
    print("💾 Salvando dados localmente...")
    
    # Salvar dados consolidados em JSON
    import json
    
    # Converter para JSON string
    json_data = json.dumps(data, indent=2, default=str)
    
    # Salvar em arquivo
    with open("/tmp/unity_catalog_extraction.json", "w") as f:
        f.write(json_data)
    
    # Criar relatório de extração
    report = f"""
# Relatório de Extração - Unity Catalog
**Data:** {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}
**Desenvolvido por:** Carlos Morais

## Resumo da Extração

| Tipo de Dados | Quantidade |
|---------------|------------|
"""
    
    for key, value in summary.items():
        report += f"| {key.replace('_', ' ').title()} | {value} |\n"
    
    report += f"""

## Detalhes Técnicos

- **Fonte:** Unity Catalog
- **Versão do Extrator:** 2.1
- **Total de Registros:** {sum(summary.values())}
- **Arquivo de Dados:** unity_catalog_extraction.json

## Próximos Passos

1. Verificar dados extraídos
2. Configurar autenticação da API
3. Executar envio para API de Governança
4. Validar dados na interface web

## Observações

- Dados salvos em formato JSON para facilitar importação
- Estrutura compatível com API de Governança V2.1
- Mapeamento completo para modelo ODCS v3.0.2
"""
    
    # Salvar relatório
    with open("/tmp/unity_catalog_extraction_report.md", "w") as f:
        f.write(report)
    
    print("✅ Dados salvos em:")
    print("  📄 /tmp/unity_catalog_extraction.json")
    print("  📋 /tmp/unity_catalog_extraction_report.md")

# Executar salvamento
save_data_locally(consolidated_data, extraction_summary)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 12. Relatório Final

# COMMAND ----------

print("🎉 EXTRAÇÃO UNITY CATALOG CONCLUÍDA COM SUCESSO!")
print("=" * 60)
print(f"📊 RESUMO FINAL:")
print(f"  • Domínios extraídos: {len(domains_data)}")
print(f"  • Entidades extraídas: {len(entities_data)}")
print(f"  • Atributos extraídos: {len(attributes_data)}")
print(f"  • Tags extraídas: {len(tags_data)}")
print(f"  • Relacionamentos de lineage: {len(lineage_data)}")
print(f"  • Métricas de uso: {len(usage_metrics_data)}")
print(f"  • Políticas de acesso: {len(access_policies_data)}")
print(f"  • Políticas de mascaramento: {len(masking_policies_data)}")
print("=" * 60)
print("✅ Dados prontos para importação na API de Governança V2.1")
print("📁 Arquivos salvos em /tmp/ para backup")
print("🔗 Configure o token JWT e execute o envio para a API")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Configurações Adicionais
# MAGIC 
# MAGIC ### Variáveis de Ambiente Necessárias
# MAGIC 
# MAGIC ```bash
# MAGIC # Configurar no cluster Databricks
# MAGIC API_BASE_URL=http://localhost:8000/api/v1
# MAGIC API_TOKEN=your_jwt_token_here
# MAGIC ```
# MAGIC 
# MAGIC ### Permissões Necessárias
# MAGIC 
# MAGIC - **Unity Catalog:** READ access to system.information_schema
# MAGIC - **Lineage:** READ access to system.access.table_lineage
# MAGIC - **Usage:** READ access to system.access.table_usage
# MAGIC - **Policies:** READ access to system.access.policies
# MAGIC 
# MAGIC ### Próximos Passos
# MAGIC 
# MAGIC 1. **Configurar autenticação** na API de Governança
# MAGIC 2. **Executar notebook** em ambiente Databricks
# MAGIC 3. **Verificar logs** de extração
# MAGIC 4. **Validar dados** na interface web da API
# MAGIC 5. **Configurar execução periódica** para sincronização

