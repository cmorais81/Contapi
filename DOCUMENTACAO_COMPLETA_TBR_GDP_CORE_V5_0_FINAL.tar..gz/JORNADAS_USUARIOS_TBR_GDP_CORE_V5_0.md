# Jornadas de Usuários - TBR GDP Core v5.0

**Autor:** Carlos Morais <carlos.morais@f1rst.com.br>  
**Versão:** 5.0.0  
**Data:** Janeiro 2025  

---

## Introdução às Jornadas de Usuários

As jornadas de usuários do TBR GDP Core v5.0 foram cuidadosamente projetadas para atender às necessidades específicas de diferentes personas dentro de uma organização orientada por dados. Cada jornada reflete cenários reais de uso, desafios comuns e objetivos específicos de cada perfil profissional, proporcionando uma experiência otimizada e intuitiva.

A plataforma reconhece que diferentes usuários têm diferentes necessidades, níveis de expertise técnica e objetivos organizacionais. Por isso, cada jornada foi desenvolvida considerando o contexto de trabalho, ferramentas utilizadas, pressões de tempo e métricas de sucesso específicas de cada perfil.

As jornadas são estruturadas em cenários práticos que os usuários enfrentam no dia a dia, desde tarefas simples de consulta até processos complexos de governança e compliance. Cada cenário inclui passos detalhados, pontos de decisão, possíveis obstáculos e soluções, além de dicas para otimização do fluxo de trabalho.

---

## Jornada do Data Steward

### Perfil e Contexto

O Data Steward é o guardião da qualidade e governança dos dados organizacionais. Este profissional tem a responsabilidade de garantir que os dados atendam aos padrões de qualidade estabelecidos, estejam adequadamente documentados e sigam as políticas organizacionais. Seu trabalho é fundamental para manter a confiabilidade e usabilidade dos ativos de dados.

O Data Steward típico possui conhecimento profundo do negócio, entende os processos organizacionais e tem experiência em identificar problemas de qualidade de dados. Embora possa não ter formação técnica avançada, possui habilidades analíticas sólidas e capacidade de comunicação efetiva com diferentes stakeholders.

### Cenário 1: Catalogação de Nova Entidade de Dados

**Contexto:** Um novo sistema foi implementado na organização e gerou uma nova tabela de dados de clientes que precisa ser catalogada e governada adequadamente.

**Objetivos:**
- Registrar a nova entidade no catálogo
- Definir metadados apropriados
- Estabelecer regras de qualidade
- Configurar monitoramento automático

**Jornada Detalhada:**

O Data Steward inicia sua jornada acessando o TBR GDP Core através do dashboard principal. A interface apresenta um resumo das atividades recentes, alertas de qualidade pendentes e métricas gerais de governança. O profissional navega até a seção "Catálogo de Entidades" e seleciona a opção "Nova Entidade".

O formulário de criação de entidade é intuitivo e guiado, solicitando informações essenciais como nome, tipo, descrição e proprietário dos dados. O sistema oferece sugestões baseadas em padrões organizacionais e valida automaticamente a unicidade do nome. O Data Steward preenche os campos obrigatórios: nome "customer_data_v2", tipo "TABLE", descrição detalhada explicando o propósito da tabela e define o proprietário como "Sistema CRM".

Na etapa de definição de schema, o sistema permite importação automática da estrutura da tabela através de conexão direta com o banco de dados ou upload de arquivo DDL. O Data Steward utiliza a funcionalidade de auto-descoberta, que conecta ao banco e extrai automaticamente a estrutura, tipos de dados e constraints. O sistema identifica 15 campos, incluindo informações pessoais que requerem classificação especial.

O processo de classificação de dados é assistido por algoritmos de machine learning que sugerem classificações baseadas em nomes de campos e padrões de dados. Campos como "cpf", "email" e "telefone" são automaticamente classificados como "PII" (Personally Identifiable Information), enquanto campos como "data_nascimento" recebem classificação "SENSITIVE". O Data Steward revisa e aprova as classificações sugeridas.

A definição de metadados inclui tags para categorização ("customer", "crm", "personal_data"), propriedades customizadas em formato JSON para informações específicas da organização, e links para documentação técnica e de negócio. O sistema sugere tags baseadas em entidades similares já catalogadas, acelerando o processo de categorização.

**Configuração de Regras de Qualidade:**

O Data Steward configura regras de qualidade específicas para a nova entidade. Para o campo "cpf", define uma regra de validade que verifica o formato correto e dígitos verificadores. Para "email", estabelece regra de formato e unicidade. Para "data_nascimento", configura regra de consistência que verifica se a data é anterior à data atual e posterior a 1900.

O sistema oferece templates de regras pré-configuradas para tipos comuns de dados, facilitando a configuração. O Data Steward pode customizar thresholds de qualidade: 95% para completude, 98% para validade de CPF, 90% para formato de email. Alertas são configurados para notificar quando métricas ficam abaixo dos thresholds estabelecidos.

**Configuração de Monitoramento:**

O monitoramento automático é configurado para executar verificações diárias de qualidade, com relatórios semanais enviados por email. O Data Steward define que violações críticas devem gerar alertas imediatos via Slack, enquanto violações menores são consolidadas em relatórios diários.

O sistema permite configuração de janelas de manutenção onde alertas são suprimidos, evitando notificações desnecessárias durante atualizações programadas. Métricas de performance são configuradas para monitorar tempo de resposta de consultas e volume de dados processados.

### Cenário 2: Investigação de Problema de Qualidade

**Contexto:** O Data Steward recebe um alerta indicando que a qualidade dos dados de vendas caiu abaixo do threshold estabelecido.

**Objetivos:**
- Identificar a causa raiz do problema
- Implementar correções necessárias
- Prevenir recorrência do problema
- Comunicar status para stakeholders

**Jornada Detalhada:**

O alerta chega via email às 9:15 da manhã, indicando que a completude da tabela "sales_data" caiu para 87%, abaixo do threshold de 90%. O Data Steward acessa imediatamente o dashboard de qualidade através do link direto no email, que o leva diretamente à análise detalhada do problema.

O dashboard de qualidade apresenta uma visão temporal da métrica, mostrando que a degradação começou às 2:30 da madrugada. O gráfico interativo permite drill-down por período, revelando que o problema afeta especificamente o campo "customer_segment", que apresenta 23% de valores nulos nas últimas 6 horas.

A funcionalidade de análise de causa raiz sugere possíveis causas baseadas em padrões históricos: mudança no processo de ETL, problema na fonte de dados, ou alteração no sistema upstream. O Data Steward utiliza a timeline de eventos para correlacionar o início do problema com atividades do sistema, identificando um deploy do sistema CRM às 2:15 da madrugada.

**Investigação Detalhada:**

O sistema oferece ferramentas de investigação que permitem análise granular dos dados afetados. O Data Steward executa queries de amostragem que mostram exemplos específicos de registros com problemas. A análise revela que registros de um segmento específico de clientes ("Enterprise") não estão sendo classificados corretamente.

A funcionalidade de linhagem de dados mostra que o campo "customer_segment" é derivado de uma regra de negócio que considera o volume de compras anuais. O Data Steward identifica que a regra não foi atualizada para considerar uma nova categoria de produtos introduzida no sistema CRM.

**Implementação de Correções:**

O Data Steward colabora com a equipe de engenharia de dados para atualizar a regra de classificação. Utilizando a funcionalidade de versionamento de regras, uma nova versão é criada e testada em ambiente de desenvolvimento. O sistema permite simulação do impacto da mudança, mostrando que a correção resolverá 95% dos casos problemáticos.

A correção é implementada em produção durante a janela de manutenção noturna. O Data Steward configura monitoramento especial para acompanhar a efetividade da correção, com alertas configurados para notificar se o problema persistir após a implementação.

**Comunicação e Documentação:**

O Data Steward utiliza o sistema de comunicação integrado para notificar stakeholders sobre o problema e sua resolução. Um relatório automático é gerado incluindo timeline do problema, causa raiz identificada, ações tomadas e medidas preventivas implementadas.

A documentação do incidente é armazenada no sistema para referência futura, incluindo lições aprendidas e recomendações para prevenir problemas similares. Esta documentação alimenta a base de conhecimento organizacional sobre qualidade de dados.

### Cenário 3: Auditoria de Compliance

**Contexto:** A organização precisa demonstrar compliance com LGPD para auditoria externa, e o Data Steward deve preparar evidências de governança adequada de dados pessoais.

**Objetivos:**
- Identificar todos os dados pessoais catalogados
- Verificar adequação das políticas de retenção
- Validar controles de acesso
- Gerar relatórios de compliance

**Jornada Detalhada:**

O Data Steward inicia o processo de auditoria acessando o módulo de Compliance do sistema. A interface apresenta um dashboard específico para LGPD, mostrando status geral de conformidade, entidades com dados pessoais catalogadas e políticas aplicáveis.

O sistema identifica automaticamente 47 entidades contendo dados pessoais, classificadas por nível de sensibilidade: 12 com dados altamente sensíveis, 23 com dados pessoais padrão e 12 com dados pseudonimizados. Cada categoria é apresentada com métricas específicas de compliance e ações requeridas.

**Análise de Políticas de Retenção:**

O Data Steward utiliza a funcionalidade de análise de retenção para verificar se todas as entidades com dados pessoais possuem políticas adequadas. O sistema identifica 3 entidades sem política de retenção definida e 2 com políticas que podem estar em desacordo com requisitos LGPD.

Para cada entidade problemática, o sistema apresenta recomendações baseadas em melhores práticas e requisitos regulatórios. O Data Steward revisa cada caso, consultando a documentação legal integrada e definindo políticas apropriadas. Por exemplo, dados de candidatos não selecionados devem ser retidos por no máximo 6 meses, enquanto dados de clientes ativos podem ser mantidos durante o relacionamento comercial.

**Validação de Controles de Acesso:**

O módulo de auditoria de acesso apresenta uma matriz completa de permissões, mostrando quem tem acesso a quais dados pessoais e sob quais condições. O sistema identifica 5 usuários com acesso excessivo e 2 contas de serviço com permissões desnecessárias.

O Data Steward trabalha com a equipe de segurança para revisar e ajustar permissões, aplicando o princípio do menor privilégio. O sistema documenta automaticamente todas as mudanças de permissão, criando trilha de auditoria completa.

**Geração de Relatórios:**

O sistema gera relatórios abrangentes de compliance, incluindo inventário completo de dados pessoais, políticas aplicadas, controles implementados e evidências de monitoramento contínuo. Os relatórios são formatados de acordo com padrões de auditoria e incluem assinaturas digitais para garantir integridade.

O Data Steward revisa todos os relatórios, adiciona comentários explicativos onde necessário e submete o pacote completo para aprovação da equipe jurídica. O sistema mantém versões históricas de todos os relatórios para demonstrar evolução contínua dos controles de compliance.

---

## Jornada do Data Engineer

### Perfil e Contexto

O Data Engineer é responsável pela implementação técnica da infraestrutura de dados, pipelines de processamento e integração entre sistemas. Este profissional possui expertise técnica avançada em tecnologias de dados, programação e arquitetura de sistemas, sendo fundamental para a operacionalização das estratégias de dados organizacionais.

O Data Engineer típico trabalha com múltiplas tecnologias simultaneamente, precisa de informações técnicas detalhadas e valoriza eficiência e automação. Sua interação com o TBR GDP Core foca em aspectos técnicos como APIs, integrações, monitoramento de performance e troubleshooting.

### Cenário 1: Integração de Nova Fonte de Dados

**Contexto:** Uma nova fonte de dados externa precisa ser integrada ao ecossistema organizacional, requerendo catalogação automática e monitoramento de qualidade.

**Objetivos:**
- Configurar conexão com fonte externa
- Implementar catalogação automática
- Estabelecer pipeline de qualidade
- Configurar alertas técnicos

**Jornada Detalhada:**

O Data Engineer acessa o TBR GDP Core através da API REST, utilizando tokens de autenticação JWT para acesso programático. A documentação OpenAPI fornece especificações completas de todos os endpoints, incluindo exemplos de código em Python, curl e outras linguagens.

A primeira etapa envolve registro da nova fonte de dados através do endpoint `/api/v5/entities`. O Data Engineer utiliza um script Python que extrai metadados da fonte externa (um banco PostgreSQL de parceiro comercial) e cria automaticamente as entidades correspondentes no catálogo.

```python
import requests
from tbr_gdp_client import TBRGDPClient

client = TBRGDPClient(base_url="https://api.company.com/gdp", token="jwt_token")

# Descoberta automática de schema
schema_info = client.discover_schema("postgresql://partner_db:5432/sales")

# Criação automática de entidades
for table in schema_info.tables:
    entity_data = {
        "name": f"partner_{table.name}",
        "entity_type": "TABLE",
        "description": f"Dados de {table.name} do parceiro comercial",
        "schema_definition": table.schema,
        "data_owner": "partner_integration_team"
    }
    
    response = client.create_entity(entity_data)
    print(f"Entidade {table.name} criada com ID: {response.id}")
```

**Configuração de Pipeline de Qualidade:**

O Data Engineer implementa verificações de qualidade automatizadas que executam após cada sincronização de dados. Utilizando a API de regras de qualidade, configura validações específicas para dados externos: verificação de formato, completude mínima de 95%, e detecção de duplicatas.

O sistema oferece webhooks que notificam o pipeline de dados quando problemas de qualidade são detectados. O Data Engineer configura integração com o sistema de orquestração (Apache Airflow) para pausar automaticamente pipelines downstream quando a qualidade está abaixo do threshold.

**Monitoramento e Alertas:**

Alertas técnicos são configurados para notificar sobre falhas de conectividade, degradação de performance e violações de SLA. O Data Engineer utiliza a API de métricas para integrar com sistemas de monitoramento existentes (Prometheus, Grafana), criando dashboards técnicos específicos.

O sistema fornece métricas detalhadas sobre performance de APIs, tempo de resposta de queries e utilização de recursos. Estas métricas são essenciais para otimização contínua e planejamento de capacidade.

### Cenário 2: Troubleshooting de Performance

**Contexto:** Consultas ao catálogo de dados estão apresentando lentidão, afetando aplicações downstream que dependem de metadados em tempo real.

**Objetivos:**
- Identificar gargalos de performance
- Implementar otimizações
- Estabelecer monitoramento preventivo
- Documentar soluções para referência futura

**Jornada Detalhada:**

O Data Engineer recebe alertas automáticos indicando que o tempo médio de resposta das APIs subiu de 50ms para 2.3 segundos. Utilizando a API de métricas, acessa dados detalhados de performance para análise:

```python
# Análise de performance via API
metrics = client.get_performance_metrics(
    start_time="2025-01-10T08:00:00Z",
    end_time="2025-01-10T12:00:00Z",
    metric_types=["QUERY_TIME", "API_RESPONSE_TIME"]
)

# Identificação de queries lentas
slow_queries = [m for m in metrics if m.value > 1000]  # > 1 segundo
```

A análise revela que consultas específicas ao endpoint de busca de entidades estão causando o problema. O Data Engineer utiliza ferramentas de profiling integradas para identificar que o problema está relacionado ao crescimento do índice de busca full-text.

**Implementação de Otimizações:**

O Data Engineer implementa várias otimizações: reindexação do banco de dados durante janela de manutenção, implementação de cache Redis para consultas frequentes, e otimização de queries SQL através de hints específicos.

```python
# Configuração de cache via API
cache_config = {
    "entity_search": {
        "ttl": 300,  # 5 minutos
        "max_size": 1000,
        "strategy": "LRU"
    }
}

client.configure_cache(cache_config)
```

O sistema permite configuração de cache granular por tipo de consulta, com invalidação automática quando dados são atualizados. O Data Engineer configura estratégias diferentes para diferentes tipos de consultas: cache longo para metadados estáticos, cache curto para métricas de qualidade.

**Monitoramento Preventivo:**

Alertas preventivos são configurados para detectar degradação de performance antes que afete usuários finais. O sistema monitora tendências de performance e alerta quando métricas se desviam significativamente da baseline histórica.

O Data Engineer implementa health checks automáticos que verificam periodicamente a saúde do sistema e executam ações corretivas automáticas quando possível. Por exemplo, limpeza automática de cache quando utilização de memória excede 80%.

### Cenário 3: Implementação de Integração com Data Lakehouse

**Contexto:** A organização está migrando para arquitetura de Data Lakehouse e precisa integrar o TBR GDP Core com Databricks Unity Catalog para sincronização bidirecional de metadados.

**Objetivos:**
- Configurar sincronização automática de metadados
- Implementar mapeamento de esquemas
- Estabelecer governança unificada
- Garantir consistência entre sistemas

**Jornada Detalhada:**

O Data Engineer utiliza a API de integrações do TBR GDP Core para configurar conexão com Unity Catalog. O sistema oferece conectores pré-construídos para principais plataformas de dados, incluindo Databricks, Snowflake, e AWS Glue.

```python
# Configuração de integração com Unity Catalog
integration_config = {
    "type": "unity_catalog",
    "connection": {
        "workspace_url": "https://company.cloud.databricks.com",
        "token": "databricks_token",
        "catalog": "production"
    },
    "sync_settings": {
        "direction": "bidirectional",
        "frequency": "hourly",
        "conflict_resolution": "tbr_gdp_wins"
    }
}

integration = client.create_integration(integration_config)
```

**Mapeamento de Esquemas:**

O sistema oferece funcionalidades avançadas de mapeamento de esquemas que permitem transformação automática entre diferentes formatos de metadados. O Data Engineer configura regras de mapeamento que convertem esquemas Unity Catalog para formato interno do TBR GDP Core e vice-versa.

Regras de transformação incluem mapeamento de tipos de dados, conversão de anotações e preservação de linhagem de dados. O sistema mantém histórico completo de todas as transformações para auditoria e troubleshooting.

**Sincronização e Monitoramento:**

O processo de sincronização é monitorado através de métricas específicas: número de entidades sincronizadas, conflitos detectados, tempo de sincronização e taxa de erro. O Data Engineer configura alertas para notificar sobre falhas de sincronização ou conflitos que requerem intervenção manual.

O sistema oferece interface de resolução de conflitos que permite ao Data Engineer revisar e resolver discrepâncias entre sistemas. Decisões de resolução são documentadas e podem ser aplicadas automaticamente em situações similares futuras.

---

## Jornada do Data Analyst

### Perfil e Contexto

O Data Analyst é o consumidor principal dos dados organizacionais, responsável por extrair insights, criar relatórios e apoiar decisões de negócio baseadas em dados. Este profissional precisa de acesso fácil e confiável aos dados, com informações claras sobre qualidade, linhagem e contexto de negócio.

O Data Analyst típico possui conhecimento sólido de negócio, habilidades analíticas avançadas e experiência com ferramentas de BI e análise. Sua interação com o TBR GDP Core foca em descoberta de dados, validação de qualidade e compreensão de contexto para análises precisas.

### Cenário 1: Descoberta de Dados para Nova Análise

**Contexto:** O Data Analyst precisa criar um relatório sobre performance de vendas por região, mas não está familiarizado com todas as fontes de dados disponíveis na organização.

**Objetivos:**
- Descobrir fontes de dados relevantes
- Validar qualidade e confiabilidade
- Compreender contexto e linhagem
- Obter acesso aos dados necessários

**Jornada Detalhada:**

O Data Analyst acessa o TBR GDP Core através da interface web intuitiva, projetada especificamente para usuários de negócio. O dashboard principal apresenta uma visão personalizada baseada no perfil do usuário, destacando dados frequentemente utilizados e sugerindo fontes relevantes baseadas em atividades recentes.

A funcionalidade de busca inteligente permite consultas em linguagem natural. O analista digita "dados de vendas por região" e o sistema utiliza processamento de linguagem natural para identificar entidades relevantes. Os resultados são ranqueados por relevância, qualidade e popularidade entre usuários similares.

**Exploração de Resultados:**

O sistema retorna 8 entidades potencialmente relevantes: "sales_data_monthly", "regional_sales_summary", "sales_transactions", "customer_regional_mapping", "sales_targets_by_region", "sales_performance_kpis", "regional_demographics" e "sales_team_assignments".

Para cada entidade, o sistema apresenta informações essenciais: descrição de negócio, proprietário dos dados, última atualização, score de qualidade geral e número de usuários que utilizaram recentemente. O Data Analyst pode visualizar amostras de dados diretamente na interface, facilitando avaliação de adequação.

**Análise de Qualidade e Confiabilidade:**

O Data Analyst seleciona "sales_data_monthly" como fonte principal e acessa o dashboard de qualidade específico. O sistema apresenta métricas detalhadas: completude 97.3%, precisão 94.8%, consistência 99.1%, validade 96.2%, pontualidade 98.7% e unicidade 99.9%.

Gráficos temporais mostram evolução das métricas ao longo do tempo, permitindo identificar tendências e sazonalidades na qualidade. O analista observa que a completude tem pequena queda nos primeiros dias de cada mês, correlacionando com o processo de fechamento mensal.

**Compreensão de Contexto e Linhagem:**

A funcionalidade de linhagem de dados apresenta visualmente como os dados fluem desde as fontes originais até a entidade selecionada. O Data Analyst descobre que "sales_data_monthly" é derivado de "sales_transactions" através de um processo de agregação que executa diariamente às 3:00 AM.

O sistema mostra que os dados originam de 3 sistemas: CRM (60%), ERP (35%) e sistema de e-commerce (5%). Esta informação é crucial para o analista compreender possíveis limitações ou vieses nos dados.

**Solicitação de Acesso:**

O Data Analyst solicita acesso aos dados através do sistema integrado de gestão de acesso. A solicitação é automaticamente roteada para o proprietário dos dados ("Sales Operations Team") com contexto completo sobre o propósito da análise.

O sistema de aprovação é baseado em políticas pré-definidas. Como o analista possui role "Data Analyst" e está solicitando acesso para dados classificados como "Internal", a aprovação é automática. Para dados mais sensíveis, seria necessária aprovação manual com justificativa de negócio.

### Cenário 2: Validação de Anomalias em Dados

**Contexto:** Durante análise de tendências de vendas, o Data Analyst identifica valores que parecem anômalos e precisa validar se representam problemas de qualidade ou eventos de negócio legítimos.

**Objetivos:**
- Investigar anomalias identificadas
- Distinguir entre problemas de qualidade e eventos de negócio
- Documentar achados para referência futura
- Comunicar descobertas para stakeholders apropriados

**Jornada Detalhada:**

O Data Analyst identifica que as vendas da região Sul apresentaram pico de 300% em uma semana específica de dezembro, valor significativamente acima da média histórica. Utilizando a interface de investigação de qualidade do TBR GDP Core, inicia análise detalhada da anomalia.

O sistema oferece ferramentas de análise estatística integradas que calculam automaticamente desvios padrão, percentis e detectam outliers baseados em diferentes algoritmos. A análise confirma que o valor é estatisticamente anômalo, ficando 4.2 desvios padrão acima da média.

**Análise de Contexto Temporal:**

O Data Analyst utiliza a funcionalidade de análise temporal para examinar padrões históricos similares. O sistema identifica que picos similares (embora menores) ocorreram nos mesmos períodos em anos anteriores, sugerindo possível sazonalidade relacionada a campanhas de fim de ano.

A análise de correlação mostra forte correlação com dados de marketing, especificamente com investimento em campanhas promocionais. O sistema sugere que a anomalia pode estar relacionada a evento de negócio legítimo rather than problema de qualidade.

**Investigação de Linhagem:**

O Data Analyst rastreia a linhagem dos dados anômalos até as fontes originais. A investigação revela que o pico origina principalmente do sistema de e-commerce, especificamente de transações processadas em um período de 48 horas durante uma promoção "Black Friday".

O sistema mostra que os dados passaram por todas as validações de qualidade normais e não apresentam inconsistências estruturais. Metadados indicam que a promoção foi devidamente registrada no sistema de campanhas de marketing.

**Documentação e Comunicação:**

O Data Analyst documenta suas descobertas utilizando a funcionalidade de anotações do sistema. As anotações são associadas diretamente aos dados específicos e ficam disponíveis para outros usuários que acessem os mesmos dados no futuro.

Um relatório automático é gerado incluindo análise estatística, contexto de negócio identificado e recomendações para análises futuras. O relatório é compartilhado com a equipe de marketing para confirmação e com outros analistas para conhecimento.

### Cenário 3: Criação de Dashboard de Monitoramento

**Contexto:** O Data Analyst precisa criar um dashboard executivo que monitore KPIs de vendas em tempo real, utilizando dados de múltiplas fontes com diferentes níveis de qualidade.

**Objetivos:**
- Identificar fontes de dados para cada KPI
- Avaliar adequação de qualidade para uso executivo
- Configurar alertas para problemas de qualidade
- Implementar dashboard com indicadores de confiabilidade

**Jornada Detalhada:**

O Data Analyst inicia o projeto identificando os KPIs requeridos: receita total, número de transações, ticket médio, conversão por canal e satisfação do cliente. Para cada KPI, utiliza a funcionalidade de busca do TBR GDP Core para identificar fontes de dados apropriadas.

O sistema sugere automaticamente combinações de entidades que podem atender aos requisitos, baseado em análise semântica dos metadados e histórico de uso por outros analistas. Por exemplo, para "receita total", sugere combinação de "sales_transactions" com "payment_confirmations" para maior precisão.

**Avaliação de Qualidade para Uso Executivo:**

Dashboards executivos requerem alta confiabilidade, então o Data Analyst estabelece critérios rigorosos: completude mínima de 98%, precisão mínima de 97% e pontualidade máxima de 2 horas. O sistema identifica que nem todas as fontes atendem estes critérios.

Para fontes que não atendem os critérios, o sistema sugere alternativas ou combinações que podem melhorar a qualidade geral. Por exemplo, combinar dados de vendas do CRM (alta precisão, baixa pontualidade) com dados do e-commerce (média precisão, alta pontualidade) para balancear qualidade e atualidade.

**Configuração de Alertas de Qualidade:**

O Data Analyst configura alertas específicos para o dashboard executivo. Quando a qualidade de qualquer fonte cai abaixo dos thresholds estabelecidos, o dashboard automaticamente exibe indicadores visuais de alerta e notifica o analista via email.

O sistema permite configuração de diferentes níveis de alerta: amarelo para degradação moderada (dados ainda utilizáveis com ressalvas), vermelho para degradação severa (dados não recomendados para uso executivo). Cada nível tem ações automáticas associadas, como envio de notificações ou ocultação temporária de métricas.

**Implementação com Indicadores de Confiabilidade:**

O dashboard implementado inclui indicadores visuais de confiabilidade para cada KPI. Um sistema de semáforo mostra verde para alta confiabilidade, amarelo para confiabilidade moderada e vermelho para baixa confiabilidade. Usuários podem clicar nos indicadores para ver detalhes sobre qualidade dos dados subjacentes.

O sistema mantém histórico de confiabilidade, permitindo que executivos compreendam a evolução da qualidade dos dados ao longo do tempo. Esta transparência aumenta a confiança nas análises e facilita tomada de decisões baseadas em dados.

---

