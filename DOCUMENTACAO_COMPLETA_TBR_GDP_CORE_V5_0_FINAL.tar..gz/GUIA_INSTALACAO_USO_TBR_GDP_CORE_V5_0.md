# Guia de Instalação e Uso - TBR GDP Core v5.0

**Autor:** Carlos Morais <carlos.morais@f1rst.com.br>  
**Versão:** 5.0.0  
**Data:** Janeiro 2025  
**Arquitetura:** Clean Architecture + Domain-Driven Design + SOLID Principles  

---

## Introdução

Este guia fornece instruções detalhadas para instalação, configuração e uso do TBR GDP Core v5.0. A plataforma foi projetada seguindo princípios de Clean Architecture e pode ser implantada em diversos ambientes, desde desenvolvimento local até clusters Kubernetes em produção.

O TBR GDP Core v5.0 representa uma implementação completamente nova, construída do zero seguindo as melhores práticas de engenharia de software. A arquitetura modular e baseada em containers facilita deployment e manutenção, enquanto a separação clara de responsabilidades permite customização e extensão conforme necessidades organizacionais específicas.

### Pré-requisitos do Sistema

Antes de iniciar a instalação, certifique-se de que o ambiente atende aos requisitos mínimos. Para desenvolvimento local, é necessário Python 3.11 ou superior, PostgreSQL 13 ou superior, e pelo menos 4GB de RAM disponível. Para ambientes de produção, recomenda-se 16GB de RAM, 4 CPUs virtuais e 100GB de armazenamento SSD.

O sistema foi testado extensivamente em Ubuntu 20.04 LTS, CentOS 8, e macOS 12+. Embora possa funcionar em outras distribuições Linux, o suporte oficial é limitado aos sistemas testados. Para ambientes Windows, recomenda-se utilização através de WSL2 ou containers Docker.

As dependências externas incluem Redis para cache (opcional mas recomendado), Elasticsearch para busca avançada (opcional), e SMTP server para notificações por email. Todas as dependências opcionais podem ser configuradas posteriormente sem afetar a funcionalidade básica do sistema.

---

## Instalação Local para Desenvolvimento

### Preparação do Ambiente

A instalação local é ideal para desenvolvimento, testes e avaliação da plataforma. Inicie criando um ambiente virtual Python isolado para evitar conflitos com outras aplicações. O uso de pyenv é recomendado para gerenciamento de versões Python, especialmente em ambientes que requerem múltiplas versões.

```bash
# Instalação do pyenv (se não estiver instalado)
curl https://pyenv.run | bash

# Instalação do Python 3.11
pyenv install 3.11.7
pyenv local 3.11.7

# Criação do ambiente virtual
python -m venv venv_tbr_gdp_v5
source venv_tbr_gdp_v5/bin/activate  # Linux/macOS
# ou
venv_tbr_gdp_v5\Scripts\activate  # Windows
```

### Configuração do Banco de Dados

O PostgreSQL serve como banco de dados principal, armazenando metadados, configurações e logs de auditoria. A configuração adequada do banco é crucial para performance e confiabilidade do sistema. Recomenda-se utilização de PostgreSQL 14 ou superior para aproveitar funcionalidades avançadas como particionamento automático e melhorias em índices JSON.

```bash
# Instalação do PostgreSQL (Ubuntu/Debian)
sudo apt update
sudo apt install postgresql postgresql-contrib

# Criação do banco de dados
sudo -u postgres createdb tbr_gdp_core_v5

# Criação do usuário
sudo -u postgres psql -c "CREATE USER tbr_gdp_user WITH PASSWORD 'secure_password_here';"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE tbr_gdp_core_v5 TO tbr_gdp_user;"
sudo -u postgres psql -c "ALTER USER tbr_gdp_user CREATEDB;"
```

A configuração de performance do PostgreSQL deve ser ajustada baseada nos recursos disponíveis. Para desenvolvimento local, as configurações padrão são adequadas, mas para produção, ajustes em parâmetros como shared_buffers, effective_cache_size e work_mem são essenciais para performance otimizada.

### Instalação da Aplicação

Extraia o pacote TBR_GDP_CORE_V5_0_CLEAN_ARCHITECTURE_FINAL.tar.gz em um diretório apropriado. A estrutura do pacote segue convenções padrão de projetos Python, facilitando navegação e manutenção.

```bash
# Extração do pacote
tar -xzf TBR_GDP_CORE_V5_0_CLEAN_ARCHITECTURE_FINAL.tar.gz
cd tbr-gdp-core-v5

# Instalação das dependências
pip install -r requirements.txt

# Configuração das variáveis de ambiente
cp .env.example .env
# Edite o arquivo .env com suas configurações específicas
```

O arquivo .env deve conter configurações essenciais como string de conexão do banco de dados, chaves secretas para JWT, configurações de email e parâmetros de logging. Mantenha este arquivo seguro e nunca o inclua em sistemas de controle de versão.

### Configuração Inicial

A configuração inicial envolve criação do schema do banco de dados, população com dados iniciais e configuração de usuários administrativos. O sistema inclui scripts automatizados que facilitam este processo.

```bash
# Configuração do PYTHONPATH
export PYTHONPATH=$(pwd)

# Criação do schema do banco
python scripts/create_database_schema.py

# População com dados iniciais
python scripts/populate_initial_data.py

# Criação do usuário administrador
python scripts/create_admin_user.py --email admin@company.com --password admin_password
```

O script de criação de schema utiliza o modelo DBML incluído no pacote para gerar automaticamente todas as tabelas, índices e constraints necessários. O processo é idempotente, permitindo execução múltipla sem efeitos colaterais.

### Execução da Aplicação

Com a configuração completa, a aplicação pode ser iniciada em modo de desenvolvimento. O servidor FastAPI inclui hot-reload automático, facilitando desenvolvimento iterativo.

```bash
# Inicialização do servidor de desenvolvimento
python -m uvicorn src.main:app --host 0.0.0.0 --port 8000 --reload

# Verificação da saúde da aplicação
curl http://localhost:8000/health

# Acesso à documentação da API
# Abra http://localhost:8000/docs no navegador
```

A documentação interativa da API é gerada automaticamente pelo FastAPI baseada nas definições de schemas Pydantic. Esta documentação permite teste direto dos endpoints e serve como referência completa para desenvolvedores.

### Execução dos Testes

O sistema inclui suíte abrangente de testes unitários e de integração. A execução regular dos testes garante que modificações não introduzam regressões.

```bash
# Execução de todos os testes
python -m pytest tests/ -v

# Execução apenas dos testes unitários
python -m pytest tests/unit/ -v

# Execução com cobertura de código
python -m pytest tests/ --cov=src --cov-report=html

# Visualização do relatório de cobertura
# Abra htmlcov/index.html no navegador
```

Os testes são organizados seguindo a estrutura da aplicação, com testes unitários focados em componentes individuais e testes de integração validando fluxos completos. A cobertura de código atual é de 88.8%, com meta de atingir 95% nas próximas iterações.

---

## Instalação em Produção

### Preparação do Ambiente de Produção

Ambientes de produção requerem considerações adicionais de segurança, performance e confiabilidade. A instalação deve seguir princípios de defesa em profundidade, com múltiplas camadas de segurança e redundância apropriada.

O dimensionamento de recursos deve considerar carga esperada, crescimento futuro e requisitos de disponibilidade. Para organizações médias (até 10.000 entidades catalogadas), recomenda-se configuração com 2 instâncias da aplicação, banco de dados com 16GB RAM e 4 CPUs, e cache Redis com 4GB RAM.

```bash
# Criação de usuário dedicado para a aplicação
sudo useradd -r -s /bin/false tbr-gdp-user
sudo mkdir -p /opt/tbr-gdp-core
sudo chown tbr-gdp-user:tbr-gdp-user /opt/tbr-gdp-core

# Configuração de permissões de segurança
sudo chmod 750 /opt/tbr-gdp-core
```

### Configuração de Banco de Dados para Produção

A configuração do PostgreSQL para produção deve incluir otimizações de performance, configuração de backup automático e monitoramento de saúde. Recomenda-se utilização de managed databases quando disponível, como AWS RDS ou Azure Database for PostgreSQL.

```sql
-- Configurações de performance recomendadas
ALTER SYSTEM SET shared_buffers = '4GB';
ALTER SYSTEM SET effective_cache_size = '12GB';
ALTER SYSTEM SET maintenance_work_mem = '1GB';
ALTER SYSTEM SET checkpoint_completion_target = 0.9;
ALTER SYSTEM SET wal_buffers = '16MB';
ALTER SYSTEM SET default_statistics_target = 100;
ALTER SYSTEM SET random_page_cost = 1.1;
ALTER SYSTEM SET effective_io_concurrency = 200;

-- Reinicialização necessária após mudanças
SELECT pg_reload_conf();
```

A configuração de backup deve incluir backups completos diários e WAL archiving contínuo para recovery point-in-time. Scripts automatizados devem verificar integridade dos backups e alertar sobre falhas.

### Deployment com Docker

O deployment via containers Docker oferece consistência entre ambientes e facilita scaling horizontal. O sistema inclui Dockerfile otimizado e docker-compose para orchestração local.

```dockerfile
# Dockerfile de produção (incluído no pacote)
FROM python:3.11-slim

WORKDIR /app

# Instalação de dependências do sistema
RUN apt-get update && apt-get install -y \
    gcc \
    libpq-dev \
    && rm -rf /var/lib/apt/lists/*

# Cópia e instalação de dependências Python
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Cópia do código da aplicação
COPY src/ ./src/
COPY scripts/ ./scripts/

# Criação de usuário não-root
RUN useradd -r -s /bin/false appuser
USER appuser

# Exposição da porta da aplicação
EXPOSE 8000

# Comando de inicialização
CMD ["python", "-m", "uvicorn", "src.main:app", "--host", "0.0.0.0", "--port", "8000"]
```

O docker-compose.yml inclui configuração completa com banco de dados, cache Redis, e volumes persistentes para dados críticos.

```yaml
version: '3.8'

services:
  app:
    build: .
    ports:
      - "8000:8000"
    environment:
      - DATABASE_URL=postgresql://user:password@db:5432/tbr_gdp_core_v5
      - REDIS_URL=redis://redis:6379
    depends_on:
      - db
      - redis
    volumes:
      - ./logs:/app/logs

  db:
    image: postgres:14
    environment:
      - POSTGRES_DB=tbr_gdp_core_v5
      - POSTGRES_USER=user
      - POSTGRES_PASSWORD=password
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./backups:/backups

  redis:
    image: redis:7-alpine
    volumes:
      - redis_data:/data

volumes:
  postgres_data:
  redis_data:
```

### Deployment em Kubernetes

Para ambientes enterprise, deployment em Kubernetes oferece alta disponibilidade, auto-scaling e gerenciamento simplificado. O sistema inclui manifests Kubernetes prontos para uso.

```yaml
# deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: tbr-gdp-core
spec:
  replicas: 3
  selector:
    matchLabels:
      app: tbr-gdp-core
  template:
    metadata:
      labels:
        app: tbr-gdp-core
    spec:
      containers:
      - name: tbr-gdp-core
        image: tbr-gdp-core:v5.0.0
        ports:
        - containerPort: 8000
        env:
        - name: DATABASE_URL
          valueFrom:
            secretKeyRef:
              name: tbr-gdp-secrets
              key: database-url
        resources:
          requests:
            memory: "512Mi"
            cpu: "250m"
          limits:
            memory: "1Gi"
            cpu: "500m"
        livenessProbe:
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /ready
            port: 8000
          initialDelaySeconds: 5
          periodSeconds: 5
```

### Configuração de Monitoramento

Monitoramento abrangente é essencial para operação confiável em produção. O sistema suporta integração com Prometheus, Grafana, e sistemas de logging centralizados como ELK Stack.

```yaml
# prometheus-config.yml
global:
  scrape_interval: 15s

scrape_configs:
  - job_name: 'tbr-gdp-core'
    static_configs:
      - targets: ['tbr-gdp-core:8000']
    metrics_path: '/metrics'
    scrape_interval: 10s
```

Dashboards Grafana pré-configurados estão incluídos no pacote, fornecendo visibilidade sobre performance da aplicação, utilização de recursos, e métricas de negócio como número de entidades catalogadas e qualidade média dos dados.

---

## Configuração e Customização

### Configuração de Autenticação e Autorização

O sistema suporta múltiplos métodos de autenticação: JWT local, LDAP/Active Directory, OAuth2, e SAML. A configuração é flexível e permite combinação de métodos conforme necessidades organizacionais.

```python
# Configuração de autenticação no arquivo .env
AUTH_METHOD=jwt  # jwt, ldap, oauth2, saml
JWT_SECRET_KEY=your-secret-key-here
JWT_ALGORITHM=HS256
JWT_EXPIRATION_HOURS=24

# Para LDAP
LDAP_SERVER=ldap://your-ldap-server.com
LDAP_BASE_DN=dc=company,dc=com
LDAP_USER_DN=ou=users,dc=company,dc=com

# Para OAuth2
OAUTH2_CLIENT_ID=your-client-id
OAUTH2_CLIENT_SECRET=your-client-secret
OAUTH2_AUTHORIZATION_URL=https://provider.com/oauth/authorize
OAUTH2_TOKEN_URL=https://provider.com/oauth/token
```

O sistema de autorização é baseado em roles e permissões granulares. Roles padrão incluem Admin, Data Steward, Data Engineer, Data Analyst e Business User, mas podem ser customizados conforme necessidades organizacionais.

### Configuração de Integrações

O TBR GDP Core v5.0 suporta integrações nativas com principais plataformas de dados. Cada integração é configurada através de conectores específicos que mantêm sincronização automática de metadados.

```python
# Configuração de integração com Databricks Unity Catalog
UNITY_CATALOG_ENABLED=true
UNITY_CATALOG_WORKSPACE_URL=https://your-workspace.cloud.databricks.com
UNITY_CATALOG_TOKEN=your-databricks-token
UNITY_CATALOG_CATALOG=production
UNITY_CATALOG_SYNC_FREQUENCY=hourly

# Configuração de integração com Informatica Axon
INFORMATICA_AXON_ENABLED=true
INFORMATICA_AXON_URL=https://your-axon-instance.com
INFORMATICA_AXON_USERNAME=integration-user
INFORMATICA_AXON_PASSWORD=integration-password
INFORMATICA_AXON_SYNC_FREQUENCY=daily
```

### Personalização de Interface

A interface web pode ser personalizada com branding organizacional, incluindo logos, cores e terminologia específica. Customizações são aplicadas através de arquivos de configuração CSS e JavaScript.

```css
/* custom-theme.css */
:root {
  --primary-color: #1e3a8a;
  --secondary-color: #3b82f6;
  --accent-color: #10b981;
  --background-color: #f8fafc;
  --text-color: #1f2937;
}

.header-logo {
  content: url('/static/images/company-logo.png');
  height: 40px;
}

.app-title::after {
  content: ' - Company Data Governance Platform';
}
```

### Configuração de Notificações

O sistema de notificações suporta múltiplos canais: email, Slack, Microsoft Teams, webhooks e SMS. Configurações permitem personalização de templates e regras de roteamento baseadas em severidade e tipo de evento.

```python
# Configuração de notificações
EMAIL_ENABLED=true
EMAIL_SMTP_HOST=smtp.company.com
EMAIL_SMTP_PORT=587
EMAIL_USERNAME=notifications@company.com
EMAIL_PASSWORD=smtp-password

SLACK_ENABLED=true
SLACK_WEBHOOK_URL=https://hooks.slack.com/services/YOUR/SLACK/WEBHOOK

# Templates de notificação customizáveis
EMAIL_TEMPLATE_QUALITY_ALERT=templates/quality_alert_email.html
SLACK_TEMPLATE_QUALITY_ALERT=templates/quality_alert_slack.json
```

---

## Guia de Uso Prático

### Primeiros Passos

Após instalação e configuração inicial, o primeiro passo é familiarizar-se com a interface e conceitos básicos. Acesse a aplicação através do navegador e faça login com as credenciais de administrador criadas durante a instalação.

O dashboard principal apresenta visão geral do estado da governança de dados organizacional. Métricas principais incluem número total de entidades catalogadas, score médio de qualidade, entidades com problemas de qualidade e atividade recente de usuários.

A navegação é organizada por módulos funcionais: Catálogo (descoberta e gestão de entidades), Qualidade (monitoramento e regras), Contratos (acordos de dados), Políticas (governança organizacional), e Monitoramento (observabilidade e alertas).

### Catalogação da Primeira Entidade

A catalogação de entidades é o ponto de partida para governança efetiva. Inicie com uma entidade simples e bem conhecida para familiarizar-se com o processo.

Navegue até "Catálogo > Nova Entidade" e preencha as informações básicas: nome único e descritivo, tipo apropriado (TABLE, VIEW, DATASET, etc.), descrição detalhada explicando propósito e contexto de negócio, e proprietário responsável pelos dados.

A definição de schema pode ser feita manualmente ou através de importação automática. Para importação automática, configure conexão com o banco de dados fonte e utilize a funcionalidade de descoberta. O sistema extrairá automaticamente estrutura, tipos de dados e constraints.

Metadados adicionais incluem tags para categorização (utilize convenções organizacionais consistentes), propriedades customizadas em formato JSON para informações específicas, e classificação de sensibilidade baseada em políticas de privacidade.

### Configuração de Regras de Qualidade

Regras de qualidade garantem que dados atendam padrões organizacionais. Inicie com regras simples e expanda gradualmente baseado em necessidades identificadas.

Para cada entidade catalogada, defina regras apropriadas: completude para campos obrigatórios, validade para formatos específicos (CPF, email, telefone), consistência para relacionamentos entre campos, e unicidade para chaves primárias e identificadores únicos.

O sistema oferece templates pré-configurados para tipos comuns de validação. Customize thresholds baseado em criticidade dos dados: dados críticos para negócio requerem thresholds mais rigorosos (95-99%), enquanto dados analíticos podem aceitar thresholds menores (85-90%).

Configure alertas apropriados para cada regra: alertas imediatos para violações críticas, consolidação diária para violações menores, e relatórios semanais para análise de tendências.

### Implementação de Contratos de Dados

Contratos de dados formalizam acordos entre produtores e consumidores, estabelecendo expectativas claras sobre estrutura, qualidade e disponibilidade.

Inicie criando contrato para entidade crítica com múltiplos consumidores. Defina schema detalhado incluindo tipos de dados, constraints e descrições de campos. Estabeleça SLAs apropriados: disponibilidade (99.9% para dados críticos), latência (máximo 1 hora para dados batch, tempo real para dados streaming), e qualidade (thresholds específicos por dimensão).

Configure regras de acesso baseadas em classificação de dados e necessidades de negócio. Dados públicos podem ter acesso liberado, dados internos requerem autenticação, dados confidenciais necessitam aprovação específica.

O processo de aprovação deve envolver stakeholders apropriados: proprietário dos dados, consumidores principais, equipe de segurança (para dados sensíveis), e arquiteto de dados (para validação técnica).

### Monitoramento e Alertas

Monitoramento contínuo é essencial para manter governança efetiva. Configure dashboards personalizados para diferentes audiências e necessidades.

Dashboard executivo deve focar em métricas de alto nível: score geral de qualidade, número de violações críticas, tempo médio de resolução de problemas, e tendências de melhoria. Atualize semanalmente e inclua comentários contextuais sobre eventos significativos.

Dashboard operacional deve incluir métricas técnicas: performance de sistemas, utilização de recursos, status de integrações, e alertas ativos. Monitore diariamente e configure alertas automáticos para problemas que requerem intervenção imediata.

Dashboard de qualidade deve apresentar métricas detalhadas por entidade: scores por dimensão, evolução temporal, comparação com benchmarks, e análise de causa raiz para problemas identificados.

### Melhores Práticas de Uso

Estabeleça convenções organizacionais consistentes para nomenclatura, categorização e documentação. Utilize prefixos padronizados para nomes de entidades, taxonomia consistente para tags, e templates para descrições.

Implemente processo de revisão regular para metadados e regras de qualidade. Metadados devem ser revisados trimestralmente para garantir precisão e relevância. Regras de qualidade devem ser avaliadas mensalmente e ajustadas baseado em mudanças de negócio.

Promova cultura de qualidade de dados através de treinamento regular, comunicação de sucessos e melhorias, e reconhecimento de contribuições significativas para governança de dados.

Mantenha documentação atualizada sobre processos, decisões e lições aprendidas. Esta documentação serve como base de conhecimento organizacional e facilita onboarding de novos usuários.

---

