# COBOL AI Engine v2.0.0 - Documentação do CLI

**Data:** 13/09/2025

## Visão Geral

O COBOL AI Engine v2.0.0 oferece duas interfaces de linha de comando (CLI) para atender a diferentes necessidades:

1. **CLI Interativo (`cli_interactive.py`):** Uma interface amigável e guiada, ideal para iniciantes e para quem prefere uma experiência mais visual.
2. **CLI Clássico (`main.py`):** Uma interface poderosa e baseada em argumentos, perfeita para automação, scripts e usuários avançados.

## 1. CLI Interativo (`cli_interactive.py`)

O CLI interativo é a maneira mais fácil de começar a usar o COBOL AI Engine. Ele fornece um menu simples que guia você por todas as funcionalidades.

### Como Iniciar

Para iniciar o CLI interativo, navegue até o diretório do projeto e execute o seguinte comando:

```bash
python3 cli_interactive.py
```

Você será recebido com um banner e um menu de opções:

```
============================================================
    COBOL AI Engine v2.0.0 - Interface Interativa
============================================================

Opções Disponíveis:
1. Analisar código COBOL (digitar/colar)
2. Analisar arquivo COBOL
3. Analisar múltiplos arquivos
4. Analisar diretório
5. Configurar provedor de IA
6. Ver status dos provedores
7. Gerar relatório consolidado
8. Configurações avançadas
9. Ajuda e exemplos
0. Sair

Escolha uma opção (0-9): 
```

### Funcionalidades do Menu

- **1. Analisar código COBOL:** Permite que você digite ou cole um trecho de código COBOL diretamente no terminal para análise. Para finalizar a entrada, digite `END` em uma linha separada.

- **2. Analisar arquivo COBOL:** Solicita o caminho para um único arquivo COBOL e o analisa.

- **3. Analisar múltiplos arquivos:** Permite que você insira os caminhos de vários arquivos COBOL, um por linha. A análise é feita em lote.

- **4. Analisar diretório:** Analisa todos os arquivos com extensões COBOL (padrão: `.cbl`, `.cob`, `.txt`) em um diretório especificado.

- **5. Configurar provedor de IA:** Exibe uma lista de provedores de IA disponíveis e permite que você alterne entre eles. A seleção é mantida durante a sessão.

- **6. Ver status dos provedores:** Verifica a disponibilidade de cada provedor de IA configurado e exibe um resumo.

- **7. Gerar relatório consolidado:** Fornece instruções sobre como gerar relatórios consolidados usando a API programática, pois esta funcionalidade é mais adequada para notebooks.

- **8. Configurações avançadas:** Permite visualizar e ajustar configurações como timeout, máximo de tokens e visualizar logs recentes.

- **9. Ajuda e exemplos:** Exibe um guia rápido com exemplos de uso e dicas de configuração.

- **0. Sair:** Encerra o CLI interativo.

### Vantagens do CLI Interativo

- **Fácil de usar:** Não requer conhecimento prévio dos argumentos de linha de comando.
- **Guiado:** O menu orienta você em cada etapa.
- **Interativo:** Fornece feedback imediato e opções contextuais.
- **Ideal para iniciantes:** A melhor maneira de explorar as funcionalidades do sistema.

## 2. CLI Clássico (`main.py`)

O CLI clássico é a interface original do COBOL AI Engine, projetada para ser poderosa e flexível. É ideal para automação, integração com outros scripts e para usuários que preferem trabalhar com argumentos de linha de comando.

### Como Usar

Todas as funcionalidades são acessadas por meio de argumentos passados na linha de comando. Para ver todas as opções disponíveis, use o comando `--help`:

```bash
python3 main.py --help
```

### Principais Argumentos

- `--fontes <caminho>`: Especifica um único arquivo COBOL ou um arquivo de texto (`fontes.txt`) contendo uma lista de caminhos para arquivos COBOL.
- `--books <caminho>`: Especifica um arquivo de texto (`BOOKS.txt`) contendo uma lista de caminhos para copybooks COBOL.
- `--diretorio <caminho>`: Especifica um diretório para ser analisado. Todos os arquivos com extensões COBOL serão processados.
- `--output <caminho>`: Define o diretório onde os arquivos de documentação gerados serão salvos. O padrão é `output/`.
- `--config <caminho>`: Permite especificar um arquivo de configuração YAML alternativo. O padrão é `config/config.yaml`.
- `--consolidado`: Gera um único arquivo de documentação consolidado para todos os programas analisados.
- `--pdf`: Converte a documentação gerada para o formato PDF.
- `--status`: Exibe um status detalhado do sistema, incluindo a disponibilidade dos provedores de IA e do conversor de PDF.
- `--log <nível>`: Define o nível de log (ex: `DEBUG`, `INFO`, `WARNING`).
- `--verbose`: Ativa o modo verboso, que fornece mais detalhes sobre o processo de análise.
- `--debug`: Ativa o modo de depuração, que é ainda mais detalhado que o verboso.

### Exemplos de Uso

**Analisar um único arquivo e gerar PDF:**
```bash
python3 main.py --fontes examples/programa1.cbl --output analise_unica --pdf
```

**Analisar uma lista de arquivos de `fontes.txt` e gerar documentação consolidada:**
```bash
python3 main.py --fontes examples/fontes.txt --output analise_lote --consolidado
```

**Analisar um diretório completo e usar uma configuração específica:**
```bash
python3 main.py --diretorio examples --output analise_dir --config config/config_openai.yaml
```

**Verificar o status do sistema com log de depuração:**
```bash
python3 main.py --status --log DEBUG
```

### Vantagens do CLI Clássico

- **Automação:** Perfeito para ser chamado a partir de scripts de build, pipelines de CI/CD ou outras ferramentas de automação.
- **Poderoso:** Oferece controle granular sobre todas as opções de análise.
- **Flexível:** Permite combinar diferentes argumentos para criar fluxos de trabalho complexos.
- **Ideal para usuários avançados:** Para quem prefere a eficiência da linha de comando.

## Qual CLI Usar?

- **Para explorar e aprender:** Comece com o **CLI Interativo**.
- **Para análises rápidas e pontuais:** O **CLI Interativo** é uma ótima escolha.
- **Para automação e scripts:** Use o **CLI Clássico**.
- **Para controle total e fluxos de trabalho complexos:** O **CLI Clássico** é a melhor opção.

Ambas as interfaces utilizam o mesmo motor de análise subjacente, garantindo que os resultados sejam consistentes, independentemente da forma como você escolher interage com o sistema.

