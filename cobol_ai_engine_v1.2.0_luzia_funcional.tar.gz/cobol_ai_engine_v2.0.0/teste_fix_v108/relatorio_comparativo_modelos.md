# Relatório Comparativo - Análise Multi-Modelo

**Data:** 22/09/2025 às 10:59:14
**Sistema:** COBOL AI Engine v1.0.2

## Resumo Executivo

**Programas Analisados:** 5
**Modelos Utilizados:** 3 (claude_3_5_sonnet, luzia_standard, mock_enhanced)
**Total de Análises:** 15

## Estatísticas por Modelo

| Modelo | Sucessos | Falhas | Taxa de Sucesso | Tokens Médios |
|--------|----------|--------|-----------------|---------------|
| claude_3_5_sonnet | 5 | 0 | 100.0% | 5191 |
| luzia_standard | 5 | 0 | 100.0% | 5190 |
| mock_enhanced | 5 | 0 | 100.0% | 5190 |

## Detalhes por Programa

### LHAN0542

| Modelo | Status | Tokens | Qualidade | Diretório |
|--------|--------|--------|-----------|----------|
| claude_3_5_sonnet | Sucesso | 6449 | Alta | model_claude_3_5_sonnet |
| luzia_standard | Sucesso | 6448 | Alta | model_luzia_standard |
| mock_enhanced | Sucesso | 6448 | Alta | model_mock_enhanced |

### LHAN0705

| Modelo | Status | Tokens | Qualidade | Diretório |
|--------|--------|--------|-----------|----------|
| claude_3_5_sonnet | Sucesso | 7554 | Alta | model_claude_3_5_sonnet |
| luzia_standard | Sucesso | 7553 | Alta | model_luzia_standard |
| mock_enhanced | Sucesso | 7553 | Alta | model_mock_enhanced |

### LHAN0706

| Modelo | Status | Tokens | Qualidade | Diretório |
|--------|--------|--------|-----------|----------|
| claude_3_5_sonnet | Sucesso | 6182 | Alta | model_claude_3_5_sonnet |
| luzia_standard | Sucesso | 6181 | Alta | model_luzia_standard |
| mock_enhanced | Sucesso | 6181 | Alta | model_mock_enhanced |

### LHBR0700

| Modelo | Status | Tokens | Qualidade | Diretório |
|--------|--------|--------|-----------|----------|
| claude_3_5_sonnet | Sucesso | 2619 | Alta | model_claude_3_5_sonnet |
| luzia_standard | Sucesso | 2618 | Alta | model_luzia_standard |
| mock_enhanced | Sucesso | 2618 | Alta | model_mock_enhanced |

### MZAN6056

| Modelo | Status | Tokens | Qualidade | Diretório |
|--------|--------|--------|-----------|----------|
| claude_3_5_sonnet | Sucesso | 3153 | Alta | model_claude_3_5_sonnet |
| luzia_standard | Sucesso | 3152 | Alta | model_luzia_standard |
| mock_enhanced | Sucesso | 3152 | Alta | model_mock_enhanced |

## Recomendações

**Modelo Recomendado:** luzia_standard (melhor taxa de sucesso)

**Modelo Mais Detalhado:** claude_3_5_sonnet (maior média de tokens)

### Uso Recomendado por Cenário

- **Análise Rápida:** Use o modelo com melhor taxa de sucesso
- **Análise Detalhada:** Use o modelo com maior média de tokens
- **Análise Crítica:** Execute com múltiplos modelos e compare resultados
- **Produção:** Use o modelo mais estável baseado nas estatísticas

---
**Relatório gerado automaticamente pelo COBOL AI Engine v1.0.2**
