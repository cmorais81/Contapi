#!/usr/bin/env python3
"""
COBOL to Docs v1.1 - Gerador de Prompts
Autor: Carlos Morais

Script wrapper para o gerador de prompts YAML.
Segue boas práticas de desenvolvimento com estrutura organizada.
"""

import sys
import os
from pathlib import Path

# Adicionar diretório tools ao path
tools_dir = Path(__file__).parent / "tools"
sys.path.insert(0, str(tools_dir))

def main():
    """Função principal que chama o gerador de prompts."""
    try:
        # Importar e executar o gerador de prompts
        from generate_prompts import main as generate_main
        generate_main()
    except ImportError as e:
        print(f"Erro: Não foi possível importar o gerador de prompts: {e}")
        print("Verifique se o arquivo tools/generate_prompts.py existe.")
        sys.exit(1)
    except Exception as e:
        print(f"Erro inesperado: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
