# Relatório Comparativo de Modelos

**Data:** 24/09/2025 15:42:46
**Programas Analisados:** 5
**Modelos Utilizados:** 2

## Resumo Geral

| Modelo | Sucessos | Falhas | Taxa de Sucesso | Tokens Médios |
|--------|----------|--------|-----------------|---------------|
| enhanced-mock-gpt-4 | 5 | 0 | 100.0% | 1274 |
| aws-claude-3-5-sonnet | 5 | 0 | 100.0% | 1274 |

## Detalhes por Programa

### LHAN0542

| Modelo | Status | Tokens | Qualidade | Diretório |
|--------|--------|--------|-----------|----------|
| aws-claude-3-5-sonnet | Sucesso | 1129 | Média | model_aws_claude_3_5_sonnet |
| enhanced-mock-gpt-4 | Sucesso | 1129 | Média | model_enhanced_mock_gpt_4 |

### LHAN0543

| Modelo | Status | Tokens | Qualidade | Diretório |
|--------|--------|--------|-----------|----------|
| aws-claude-3-5-sonnet | Sucesso | 1258 | Média | model_aws_claude_3_5_sonnet |
| enhanced-mock-gpt-4 | Sucesso | 1258 | Média | model_enhanced_mock_gpt_4 |

### LHAN0544

| Modelo | Status | Tokens | Qualidade | Diretório |
|--------|--------|--------|-----------|----------|
| aws-claude-3-5-sonnet | Sucesso | 1367 | Média | model_aws_claude_3_5_sonnet |
| enhanced-mock-gpt-4 | Sucesso | 1367 | Média | model_enhanced_mock_gpt_4 |

### LHAN0545

| Modelo | Status | Tokens | Qualidade | Diretório |
|--------|--------|--------|-----------|----------|
| aws-claude-3-5-sonnet | Sucesso | 1258 | Média | model_aws_claude_3_5_sonnet |
| enhanced-mock-gpt-4 | Sucesso | 1258 | Média | model_enhanced_mock_gpt_4 |

### LHAN0546

| Modelo | Status | Tokens | Qualidade | Diretório |
|--------|--------|--------|-----------|----------|
| aws-claude-3-5-sonnet | Sucesso | 1359 | Média | model_aws_claude_3_5_sonnet |
| enhanced-mock-gpt-4 | Sucesso | 1359 | Média | model_enhanced_mock_gpt_4 |

## Recomendações

**Modelo Recomendado:** enhanced-mock-gpt-4 (melhor taxa de sucesso)

**Modelo Mais Detalhado:** enhanced-mock-gpt-4 (maior média de tokens)

### Uso Recomendado por Cenário

- **Análise Rápida:** Use o modelo com melhor taxa de sucesso
- **Análise Detalhada:** Use o modelo com maior média de tokens
- **Análise Crítica:** Execute com múltiplos modelos e compare resultados
- **Produção:** Use o modelo mais estável baseado nas estatísticas

---
**Relatório gerado automaticamente pelo COBOL to Docs v1.1**
