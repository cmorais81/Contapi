#!/usr/bin/env python3
"""
Teste do gerador HTML melhorado
Demonstra as melhorias na formatação para PDF
"""

import os
import sys
import tempfile
from pathlib import Path

# Adicionar src ao path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from src.utils.html_generator import HTMLReportGenerator

def criar_markdown_exemplo():
    """Criar um exemplo de Markdown para testar a formatação"""
    markdown_exemplo = """# Análise do Programa COBOL - CALC-JUROS

## Resumo Executivo

Este documento apresenta uma análise detalhada do programa COBOL **CALC-JUROS**, desenvolvido para calcular juros simples em operações bancárias. A análise foi realizada utilizando o **COBOL AI Engine v2.0.0** com modelo `aws-claude-3.7`.

### Informações Gerais

| Campo | Valor |
|-------|-------|
| **Nome do Programa** | CALC-JUROS |
| **Tipo** | Programa de Cálculo |
| **Complexidade** | Baixa |
| **Linhas de Código** | 45 |
| **Data da Análise** | 23/09/2025 |

## Análise Técnica

### Estrutura do Programa

O programa segue a estrutura padrão COBOL com as seguintes divisões:

1. **IDENTIFICATION DIVISION**
   - Define identificação do programa
   - Especifica autor e propósito

2. **DATA DIVISION**
   - Declara variáveis de trabalho
   - Define estruturas de dados

3. **PROCEDURE DIVISION**
   - Implementa lógica de negócio
   - Executa cálculos matemáticos

### Variáveis Principais

```cobol
01 WS-PRINCIPAL        PIC 9(7)V99 VALUE ZEROS.
01 WS-TAXA-JUROS       PIC 9V9999 VALUE ZEROS.
01 WS-TEMPO            PIC 9(3) VALUE ZEROS.
01 WS-JUROS            PIC 9(7)V99 VALUE ZEROS.
01 WS-MONTANTE         PIC 9(8)V99 VALUE ZEROS.
```

### Lógica de Negócio

O programa implementa o cálculo de juros simples utilizando a fórmula:

> **Juros = Principal × Taxa × Tempo**

#### Fluxo de Processamento

1. Inicialização das variáveis
2. Atribuição de valores de teste
3. Cálculo dos juros
4. Cálculo do montante final
5. Exibição dos resultados

### Pontos Fortes

- ✅ **Estrutura Clara**: Código bem organizado e legível
- ✅ **Nomenclatura**: Variáveis com nomes descritivos
- ✅ **Simplicidade**: Lógica direta e fácil de entender
- ✅ **Padrões**: Segue convenções COBOL

### Pontos de Melhoria

- ⚠️ **Validação**: Falta validação de entrada
- ⚠️ **Tratamento de Erro**: Não há tratamento de exceções
- ⚠️ **Flexibilidade**: Valores fixos no código

## Recomendações

### Melhorias Sugeridas

1. **Implementar Validação de Dados**
   ```cobol
   IF WS-PRINCIPAL <= ZERO
       DISPLAY 'ERRO: Principal deve ser maior que zero'
       STOP RUN
   END-IF
   ```

2. **Adicionar Tratamento de Erro**
   - Verificar divisão por zero
   - Validar limites numéricos
   - Implementar mensagens de erro

3. **Tornar Mais Flexível**
   - Aceitar entrada do usuário
   - Parametrizar valores
   - Criar interface interativa

### Próximos Passos

1. Implementar as melhorias sugeridas
2. Realizar testes unitários
3. Documentar casos de uso
4. Criar manual do usuário

## Metadados da Análise

### Informações Técnicas

| Atributo | Valor |
|----------|-------|
| **Modelo de IA** | aws-claude-3.7 |
| **Provider** | LuzIA |
| **Tokens Utilizados** | 1,234 |
| **Tempo de Análise** | 2.3 segundos |
| **Confiança** | 95% |

### Configuração do Sistema

- **Sistema**: COBOL AI Engine v2.0.0
- **Ambiente**: Produção
- **Data/Hora**: 23/09/2025 às 14:30:15
- **Usuário**: Sistema Automatizado

## Conclusão

O programa **CALC-JUROS** apresenta uma implementação funcional e bem estruturada para cálculo de juros simples. Embora atenda aos requisitos básicos, recomenda-se a implementação das melhorias sugeridas para aumentar a robustez e flexibilidade do sistema.

### Classificação Final

| Critério | Nota | Observação |
|----------|------|------------|
| **Funcionalidade** | 8/10 | Atende aos requisitos |
| **Qualidade do Código** | 7/10 | Bem estruturado |
| **Manutenibilidade** | 6/10 | Pode ser melhorada |
| **Robustez** | 5/10 | Falta validação |
| **Documentação** | 4/10 | Comentários limitados |

**Nota Geral: 6.0/10** - Bom programa com potencial de melhoria.

---

*Relatório gerado automaticamente pelo COBOL AI Engine v2.0.0*
"""
    return markdown_exemplo

def testar_html_melhorado():
    """Testar o gerador HTML melhorado"""
    print("🎨 TESTE DO GERADOR HTML MELHORADO")
    print("=" * 60)
    print()
    
    # Criar diretório temporário
    with tempfile.TemporaryDirectory() as temp_dir:
        print(f"✅ Diretório temporário criado: {temp_dir}")
        
        # Criar arquivo Markdown de exemplo
        markdown_content = criar_markdown_exemplo()
        markdown_file = os.path.join(temp_dir, "exemplo_analise.md")
        
        with open(markdown_file, 'w', encoding='utf-8') as f:
            f.write(markdown_content)
        
        print(f"✅ Arquivo Markdown criado: {markdown_file}")
        print()
        
        # Gerar HTML
        print("🔄 Gerando HTML com formatação melhorada...")
        generator = HTMLReportGenerator()
        html_file = generator.generate_html_report(markdown_file, temp_dir)
        
        if html_file:
            print(f"✅ HTML gerado com sucesso: {html_file}")
            
            # Verificar tamanho do arquivo
            file_size = os.path.getsize(html_file)
            print(f"📊 Tamanho do arquivo: {file_size:,} bytes")
            
            # Copiar para diretório atual para visualização
            import shutil
            local_html = "exemplo_relatorio_melhorado.html"
            shutil.copy2(html_file, local_html)
            print(f"📁 Cópia criada: {local_html}")
            
            print()
            print("🎯 MELHORIAS IMPLEMENTADAS:")
            print("✅ CSS profissional otimizado para PDF")
            print("✅ Tipografia melhorada com hierarquia visual")
            print("✅ Tabelas com design moderno e responsivo")
            print("✅ Código COBOL com syntax highlighting")
            print("✅ Cabeçalho e rodapé profissionais")
            print("✅ Quebras de página inteligentes")
            print("✅ Cores e espaçamento otimizados")
            print("✅ Suporte a impressão/PDF nativo")
            
            print()
            print("📋 COMO CONVERTER PARA PDF:")
            print("1. Abra o arquivo HTML no navegador")
            print("2. Pressione Ctrl+P (Windows/Linux) ou Cmd+P (Mac)")
            print("3. Selecione 'Salvar como PDF'")
            print("4. Configure:")
            print("   - Margens: Padrão ou Mínimas")
            print("   - Orientação: Retrato")
            print("   - Escala: 100%")
            print("   - Gráficos de fundo: Ativado")
            print("5. Clique em 'Salvar'")
            
            print()
            print("🎨 CARACTERÍSTICAS DO NOVO DESIGN:")
            print("- Layout profissional com gradientes sutis")
            print("- Tabelas com cabeçalhos coloridos")
            print("- Código com fundo escuro e syntax highlighting")
            print("- Seções bem delimitadas com bordas e sombras")
            print("- Tipografia hierárquica clara")
            print("- Cores consistentes e profissionais")
            print("- Responsivo para diferentes tamanhos")
            
            return True
        else:
            print("❌ Erro ao gerar HTML")
            return False

def comparar_melhorias():
    """Mostrar comparação entre versão antiga e nova"""
    print()
    print("📊 COMPARAÇÃO: ANTES vs DEPOIS")
    print("=" * 60)
    
    print("\n🔴 VERSÃO ANTERIOR:")
    print("- CSS básico sem otimização")
    print("- Tabelas simples sem estilo")
    print("- Código sem highlighting")
    print("- Layout genérico")
    print("- Quebras de página ruins")
    print("- Tipografia padrão")
    
    print("\n🟢 VERSÃO MELHORADA:")
    print("- CSS profissional otimizado para PDF")
    print("- Tabelas modernas com gradientes")
    print("- Syntax highlighting para COBOL")
    print("- Layout corporativo elegante")
    print("- Quebras de página inteligentes")
    print("- Tipografia hierárquica profissional")
    print("- Cabeçalho e rodapé personalizados")
    print("- Cores e espaçamento otimizados")
    print("- Seções destacadas com bordas")
    print("- Suporte completo a impressão")

def main():
    """Executar teste do HTML melhorado"""
    os.chdir(Path(__file__).parent)
    
    success = testar_html_melhorado()
    comparar_melhorias()
    
    print()
    print("=" * 60)
    print("RESULTADO DO TESTE")
    print("=" * 60)
    
    if success:
        print("🎉 GERADOR HTML MELHORADO COM SUCESSO!")
        print()
        print("📁 Arquivo de exemplo gerado: exemplo_relatorio_melhorado.html")
        print("🔍 Abra o arquivo no navegador para ver as melhorias")
        print("📄 Use Ctrl+P para converter para PDF e ver o resultado final")
        print()
        print("✅ O sistema agora gera PDFs com qualidade profissional!")
    else:
        print("❌ Problemas detectados no gerador HTML")

if __name__ == "__main__":
    main()
