#!/usr/bin/env python3.11
# -*- coding: utf-8 -*-
"""
Sistema de Análise COBOL v3.0 - Assertive Documentation Generator
Gerador de documentação técnica assertiva que permite reimplementação

Autor:  análise
Data: 17 de Setembro de 2025
"""

import logging
from typing import Dict, Any, List

import logging

class AssertiveDocumentationGenerator:
    def __init__(self, templates_path: str = "src/templates/documentation_templates_v3.yaml"):
        self.logger = logging.getLogger(__name__)
    """
    Gera documentação técnica completa e assertiva, focada em permitir
    a reimplementação do código COBOL em linguagens modernas.
    """
    
    def __init__(self, config: Dict[str, Any]):
        """Inicializa o gerador de documentação."""
        self.logger = logging.getLogger(__name__)
        self.config = config.get('documentation', {})
        self.templates = self._load_templates()
    
    def _load_templates(self) -> Dict[str, str]:
        """Carrega templates de documentação."""
        # Em uma implementação real, isso viria de arquivos de template
        return {
            'main': """
# Documentação Técnica e Funcional Completa: {program_name}

**Data de Geração**: {generation_date}
**Versão do Sistema**: Sistema de Análise COBOL v3.0

## 1. Funcionalidade Principal

**Padrão de Processamento:** {main_pattern_type}
**Confiança da Análise:** {main_pattern_confidence:.1%}

### 1.1. Descrição Funcional
{main_pattern_description}

### 1.2. Propósito de Negócio
{main_pattern_business_purpose}

### 1.3. Implementação Técnica Resumida
{main_pattern_technical_implementation}

## 2. Arquitetura de Dados

### 2.1. Arquivos de Entrada
{input_files_section}

### 2.2. Arquivos de Saída
{output_files_section}

### 2.3. Fluxo de Dados Principal
{data_flow_section}

## 3. Lógica de Processamento Detalhada

### 3.1. Algoritmo Principal
{algorithm_section}

### 3.2. Regras de Validação
{validation_rules_section}

### 3.3. Lógica de Quebra de Arquivo
{file_splitting_section}

## 4. Guia de Reimplementação ({target_language})

### 4.1. Mapeamento de Estruturas de Dados
{data_mapping_section}

### 4.2. Arquitetura Sugerida
{suggested_architecture}

### 4.3. Exemplo de Código Conceitual
``` {target_language}
{code_example}
```

## 5. Análise Estrutural do Código

### 5.1. Estrutura Hierárquica
{structure_hierarchy}

### 5.2. Métricas de Complexidade
{complexity_metrics}

### 5.3. Pontos de Integração
{integration_points}

""",
            'file_section': """
#### {file_name}
- **Propósito:** {file_purpose}
- **Formato:** {file_format}
- **Layout do Registro:**
```
{record_layout}
```
""",
            'validation_rule_section': """
- **Campo:** `{field_name}`
- **Tipo:** {validation_type}
- **Condição:** {condition}
- **Contexto de Negócio:** {business_context}
- **Ação em Caso de Erro:** {error_action}
- **Linha:** {line_number}
""",
        }

    def generate_documentation(self, full_analysis: Dict[str, Any], llm_response: Dict[str, Any], target_language: str = 'java') -> str:
        """
        Gera a documentação final combinando análise e resposta do LLM.

        Args:
            full_analysis: Análise completa do parser e analisador funcional.
            llm_response: Resposta do LLM com a análise aprofundada.
            target_language: Linguagem alvo para o guia de reimplementação.

        Returns:
            String com a documentação completa em Markdown.
        """
        try:
            self.logger.info(f"Gerando documentação para: {full_analysis.get('name', 'N/A')}")
            self.logger.debug(f"Dados completos da análise: {full_analysis}")
            # Extrair dados da análise funcional
            functional_summary = full_analysis.get('functional_analysis', {}).get('functional_summary', {})
            file_processing = full_analysis.get('functional_analysis', {}).get('file_processing', {})
            
            # Extrair dados da resposta do LLM ou interpretador interno
            llm_response = full_analysis.get('llm_analysis', {})
            
            # Verificar se temos dados reais do interpretador interno
            if llm_response.get('source') == 'internal_cobol_interpreter':
                # Usar dados reais do interpretador
                main_functionality = llm_response.get('main_functionality', {})
                data_architecture = llm_response.get('data_architecture', {})
                processing_logic = llm_response.get('processing_logic', {})
                reimplementation_guide = llm_response.get('reimplementation_guide', {})
            else:
                # Fallback para dados genéricos se nenhuma análise disponível
                main_functionality = {'description': 'Análise não disponível.', 'business_purpose': 'Análise não disponível.', 'technical_implementation': 'Análise não disponível.'}
                data_architecture = {'data_flow': 'Análise não disponível.'}
                processing_logic = {'algorithm': 'Análise não disponível.', 'file_splitting_logic': 'Análise não disponível.'}
                reimplementation_guide = {'data_mapping': 'Análise não disponível.', 'suggested_architecture': 'Análise não disponível.', 'code_example': 'Exemplo não disponível.'}
            
            # Usar análise híbrida quando disponível
            hybrid_analysis = full_analysis.get("hybrid_analysis", {})
            combined_insights = hybrid_analysis.get("combined_insights", {})
            
            if combined_insights:
                # Usar insights combinados da análise híbrida
                main_func = combined_insights.get('main_functionality', {})
                data_arch = combined_insights.get('data_architecture', {})
                proc_logic = combined_insights.get('processing_logic', {})
                reimpl_guide = combined_insights.get('reimplementation_guide', {})
                
                main_functionality = {
                    'description': main_func.get('description', 'Análise não disponível.'),
                    'business_purpose': main_func.get('business_purpose', 'Análise não disponível.'),
                    'technical_implementation': main_func.get('technical_implementation', 'Análise não disponível.')
                }
                data_architecture = {
                    'data_flow': data_arch.get('data_flow', 'Análise não disponível.')
                }
                processing_logic = {
                    'algorithm': proc_logic.get('algorithm', 'Análise não disponível.'),
                    'file_splitting_logic': f"Detectado: {proc_logic.get('file_splitting_detected', False)}, Critérios: {', '.join(proc_logic.get('splitting_criteria', []))}"
                }
                reimplementation_guide = {
                    'data_mapping': reimpl_guide.get('data_mapping', 'Análise não disponível.'),
                    'suggested_architecture': reimpl_guide.get('recommended_approach', 'Análise não disponível.'),
                    'code_example': 'Exemplo baseado em análise interna.'
                }
            elif llm_response:
                # Fallback para LLM direto se híbrida não disponível
                main_functionality = llm_response.get('main_functionality', {
                    'description': 'Análise não disponível.',
                    'business_purpose': 'Análise não disponível.',
                    'technical_implementation': 'Análise não disponível.'
                })
                data_architecture = llm_response.get('data_architecture', {
                    'data_flow': 'Análise não disponível.'
                })
                processing_logic = llm_response.get('processing_logic', {
                    'algorithm': 'Análise não disponível.',
                    'file_splitting_logic': 'Análise não disponível.'
                })
                reimplementation_guide = llm_response.get('reimplementation_guide', {
                    'data_mapping': 'Análise não disponível.',
                    'suggested_architecture': 'Análise não disponível.',
                    'code_example': 'Exemplo não disponível.'
                })            
            # Montar seções
            input_file = getattr(file_processing, 'input_file', 'N/A') if hasattr(file_processing, 'input_file') else 'N/A'
            output_files = getattr(file_processing, 'output_files', []) if hasattr(file_processing, 'output_files') else []
            validation_rules = getattr(file_processing, 'validation_rules', []) if hasattr(file_processing, 'validation_rules') else []
            
            input_files_section = self._format_file_section(input_file, "Entrada de dados principal")
            output_files_section = "\n".join([self._format_file_section(f, "Saída de dados processados") for f in output_files])
            validation_rules_section = self._format_validation_rules(validation_rules)
            
            # Preencher o template principal
            doc = self.templates['main'].format(
                program_name=full_analysis.get('name', 'N/A'),
                generation_date=__import__('datetime').datetime.now().strftime("%d/%m/%Y %H:%M:%S"),
                main_pattern_type=functional_summary.get('primary_function', 'N/A'),
                main_pattern_confidence=functional_summary.get('confidence_level', 0.0),
                main_pattern_description=main_functionality.get('description', 'Análise não disponível.'),
                main_pattern_business_purpose=main_functionality.get('business_purpose', 'Análise não disponível.'),
                main_pattern_technical_implementation=main_functionality.get('technical_implementation', 'Análise não disponível.'),
                input_files_section=input_files_section,
                output_files_section=output_files_section,
                data_flow_section=data_architecture.get('data_flow', 'Análise não disponível.'),
                algorithm_section=processing_logic.get('algorithm', 'Análise não disponível.'),
                validation_rules_section=validation_rules_section,
                file_splitting_section=processing_logic.get('file_splitting_logic', 'Análise não disponível.'),
                target_language=target_language,
                data_mapping_section=reimplementation_guide.get('data_mapping', 'Análise não disponível.'),
                suggested_architecture=reimplementation_guide.get('suggested_architecture', 'Análise não disponível.'),
                code_example=reimplementation_guide.get('code_example', 'Exemplo não disponível.'),
                structure_hierarchy=self._format_structure(full_analysis.get('structural_analysis', {})),
                complexity_metrics=self._format_complexity(full_analysis.get('complexity_metrics', {})),
                integration_points=self._format_integrations(full_analysis.get('integration_points', []))
            )
            
            return doc

        except Exception as e:
            self.logger.error(f"Erro ao gerar documentação: {str(e)}", exc_info=True)
            return f"# Erro na Geração da Documentação\n\nOcorreu um erro inesperado: {str(e)}"

    def _format_file_section(self, file_name: str, purpose: str) -> str:
        # Simulação, dados viriam da análise de dados
        return self.templates['file_section'].format(
            file_name=file_name,
            file_purpose=purpose,
            file_format="Sequencial de tamanho fixo",
            record_layout="01 RECORD-LAYOUT PIC X(260)."
        )

    def _format_validation_rules(self, rules: List[Any]) -> str:
        if not rules:
            return "Nenhuma regra de validação específica foi identificada automaticamente."
        
        formatted_rules = []
        for rule in rules:
            # Converter objeto ValidationRule para dict
            if hasattr(rule, '__dict__'):
                rule_dict = rule.__dict__
            else:
                rule_dict = rule
            
            formatted_rules.append(self.templates['validation_rule_section'].format(**rule_dict))
        return "\n".join(formatted_rules)

    def _format_structure(self, structure: Dict[str, Any]) -> str:
        # Usar dados reais da análise estrutural
        statistics = structure.get('statistics', {})
        divisions = statistics.get('total_divisions', len(structure.get('divisions', {})))
        sections = statistics.get('total_sections', len(structure.get('sections', {})))
        paragraphs = statistics.get('total_paragraphs', len(structure.get('paragraphs', [])))
        
        # Adicionar detalhes das divisões encontradas
        divisions_found = statistics.get('divisions_found', [])
        sections_found = statistics.get('sections_found', [])
        
        details = ""
        if divisions_found:
            details += f"\n- **Divisões Identificadas:** {', '.join(divisions_found)}"
        if sections_found:
            details += f"\n- **Seções Identificadas:** {', '.join(sections_found[:5])}{'...' if len(sections_found) > 5 else ''}"
        
        return f"""
- **Divisões:** {divisions}
- **Seções:** {sections}
- **Parágrafos:** {paragraphs}{details}
"""

    def _format_complexity(self, metrics: Dict[str, Any]) -> str:
        return f"""
- **Complexidade Ciclomática (Estimada):** {metrics.get('cyclomatic_complexity', 'N/A')}
- **Total de Regras de Negócio:** {metrics.get('business_rule_count', 'N/A')}
- **Pontos de Integração:** {metrics.get('integration_points', 'N/A')}
"""

    def _format_integrations(self, integrations: List[Dict[str, Any]]) -> str:
        if not integrations:
            return "Nenhum ponto de integração explícito (CALL) foi identificado."
        
        points = []
        for integration in integrations:
            points.append(f"- **Programa:** `{integration['target']}` (Linha: {integration['line']})")
        return "\n".join(points)


