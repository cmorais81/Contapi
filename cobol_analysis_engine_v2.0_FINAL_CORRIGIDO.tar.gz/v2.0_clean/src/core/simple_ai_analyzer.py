"""
Sistema Simples de Análise com IA - COBOL Analysis Engine v2.0
Captura prompts e respostas para transparência total
"""

import asyncio
import logging
import time
from typing import Dict, Any, List, Optional
from datetime import datetime

from providers.provider_manager import ProviderManager
from providers.base_provider import AIRequest
from core.prompt_response_logger import PromptResponseLogger

class SimpleAIAnalyzer:
    """Analisador simples que captura prompts e respostas das IAs"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.provider_manager = ProviderManager(config)
        self.prompt_logger = PromptResponseLogger()
        self.logger = logging.getLogger(__name__)
        
        # Configurar provedor principal (LuzIA)
        self.primary_provider = config.get('ai', {}).get('primary_provider', 'luzia')
    
    async def analyze_cobol_program(self, 
                                  program_name: str,
                                  cobol_code: str,
                                  copybooks: Optional[Dict] = None) -> Dict[str, Any]:
        """Analisa programa COBOL e captura prompts/respostas"""
        
        self.logger.info(f"Iniciando análise simples de {program_name}")
        
        # Limpar histórico anterior
        self.prompt_logger.clear_history()
        
        # Preparar contexto
        copybooks_info = self._format_copybooks_info(copybooks) if copybooks else "Nenhum copybook disponível"
        
        # Criar prompt principal
        main_prompt = self._create_main_analysis_prompt(program_name, cobol_code, copybooks_info)
        
        # Executar análise com provedor principal
        analysis_result = await self._execute_analysis_with_logging(
            provider_name=self.primary_provider,
            prompt_type="Análise Principal",
            prompt=main_prompt
        )
        
        # Se o provedor principal falhar, tentar outros
        if not analysis_result.get('success', False):
            self.logger.warning(f"Provedor principal {self.primary_provider} falhou, tentando outros...")
            
            for provider_name in self.provider_manager.providers.keys():
                if provider_name != self.primary_provider:
                    analysis_result = await self._execute_analysis_with_logging(
                        provider_name=provider_name,
                        prompt_type="Análise Alternativa",
                        prompt=main_prompt
                    )
                    if analysis_result.get('success', False):
                        break
        
        # Retornar resultado com histórico de prompts
        return {
            'analysis_result': analysis_result,
            'prompt_history': self.prompt_logger.get_prompt_history(),
            'summary': self.prompt_logger.get_summary()
        }
    
    async def _execute_analysis_with_logging(self, 
                                           provider_name: str,
                                           prompt_type: str,
                                           prompt: str) -> Dict[str, Any]:
        """Executa análise com um provedor e registra prompts/respostas"""
        
        try:
            # Obter provedor
            provider = self.provider_manager.get_provider(provider_name)
            if not provider:
                self.logger.error(f"Provedor {provider_name} não disponível")
                return {'success': False, 'error': f'Provedor {provider_name} não disponível'}
            
            # Verificar se provedor está disponível
            if not await provider.is_available():
                self.logger.error(f"Provedor {provider_name} não está disponível")
                return {'success': False, 'error': f'Provedor {provider_name} não conectado'}
            
            # Criar requisição
            request = AIRequest(
                prompt=prompt,
                context={'program_analysis': True},
                max_tokens=2000,
                temperature=0.1
            )
            
            # Executar análise
            start_time = time.time()
            response = await provider.analyze(request)
            execution_time = time.time() - start_time
            
            # Registrar interação
            self.prompt_logger.log_interaction(
                provider_name=provider_name,
                prompt_type=prompt_type,
                prompt_sent=prompt,
                response_received=response.content if response.success else response.error_message,
                success=response.success,
                execution_time=execution_time,
                tokens_used=response.tokens_used,
                model_used=response.model
            )
            
            if response.success:
                self.logger.info(f"Análise com {provider_name} concluída com sucesso")
                return {
                    'success': True,
                    'content': response.content,
                    'provider': provider_name,
                    'model': response.model,
                    'tokens_used': response.tokens_used,
                    'execution_time': execution_time
                }
            else:
                self.logger.error(f"Análise com {provider_name} falhou: {response.error_message}")
                return {
                    'success': False,
                    'error': response.error_message,
                    'provider': provider_name
                }
                
        except Exception as e:
            self.logger.error(f"Erro na análise com {provider_name}: {str(e)}")
            
            # Registrar erro
            self.prompt_logger.log_interaction(
                provider_name=provider_name,
                prompt_type=prompt_type,
                prompt_sent=prompt,
                response_received=f"Erro: {str(e)}",
                success=False,
                execution_time=0,
                tokens_used=0
            )
            
            return {
                'success': False,
                'error': str(e),
                'provider': provider_name
            }
    
    def _create_main_analysis_prompt(self, program_name: str, cobol_code: str, copybooks_info: str) -> str:
        """Cria prompt principal para análise"""
        
        prompt = f"""Analise o programa COBOL abaixo e explique de forma clara e objetiva:

**Nome do Programa:** {program_name}

**Instruções:**
1. O QUE este programa faz (objetivo principal)
2. QUAIS são as regras de negócio importantes (validações, critérios, limites)
3. SE HÁ particularidades ou pontos que merecem atenção especial

**Código COBOL:**
```cobol
{cobol_code[:3000]}{"..." if len(cobol_code) > 3000 else ""}
```

**Copybooks disponíveis:**
{copybooks_info}

**Formato da resposta:**
- Use linguagem simples e direta
- Seja objetivo mas completo
- Foque no que é importante para entender o programa
- Evite jargões técnicos desnecessários
- Explique regras de negócio em linguagem clara"""

        return prompt
    
    def _format_copybooks_info(self, copybooks: Dict[str, str]) -> str:
        """Formata informações dos copybooks"""
        
        if not copybooks:
            return "Nenhum copybook disponível"
        
        info = []
        for name, content in copybooks.items():
            # Extrair informações básicas do copybook
            lines = content.split('\n')
            field_count = sum(1 for line in lines if any(level in line.strip() for level in ['01 ', '05 ', '10 ', '15 ', '20 ']))
            
            info.append(f"- **{name}**: {field_count} campos definidos")
        
        return '\n'.join(info)
    
    def get_prompt_history(self) -> List[Dict[str, Any]]:
        """Retorna histórico de prompts e respostas"""
        return self.prompt_logger.get_prompt_history()
    
    def get_analysis_summary(self) -> Dict[str, Any]:
        """Retorna resumo da análise"""
        return self.prompt_logger.get_summary()
