#!/usr/bin/env python3.11
# -*- coding: utf-8 -*-
"""
Sistema de Análise COBOL v2.2.2 - Multi-Provider Analyzer
Sistema de análise usando múltiplos providers simultaneamente

Autor:  análise
Data: 17 de Setembro de 2025
"""

import logging
import time
import asyncio
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass

from .base_provider import AIRequest, AIResponse
from .provider_manager import ProviderManager


@dataclass
class MultiProviderResult:
    """Resultado da análise multi-provider."""
    primary_result: Optional[Dict]
    secondary_results: List[Dict]
    combined_analysis: str
    confidence_score: float
    providers_used: List[str]
    total_tokens: int
    analysis_time: float
    consensus_points: List[str]
    divergent_points: List[str]


class MultiProviderAnalyzer:
    """
    Analisador que usa múltiplos providers de análise simultaneamente.
    
    Funcionalidades:
    - Análise paralela com múltiplos providers
    - Combinação inteligente de resultados
    - Detecção de consenso e divergências
    - Fallback automático entre providers
    - Otimização de custos e tempo
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Inicializa o analisador multi-provider.
        
        Args:
            config: Configuração do sistema
        """
        self.logger = logging.getLogger(__name__)
        self.config = config
        
        # Configurações multi-provider
        multi_config = config.get('multi_provider', {})
        self.enabled = multi_config.get('enabled', False)
        self.primary_provider = multi_config.get('primary_provider', 'luzia')
        self.secondary_providers = multi_config.get('secondary_providers', ['copilot'])
        self.parallel_execution = multi_config.get('parallel_execution', True)
        self.consensus_threshold = multi_config.get('consensus_threshold', 0.7)
        self.max_concurrent = multi_config.get('max_concurrent', 3)
        
        # Estratégias de combinação
        self.combination_strategy = multi_config.get('combination_strategy', 'weighted_merge')
        self.provider_weights = multi_config.get('provider_weights', {
            'luzia': 0.6,
            'copilot': 0.4
        })
        
        # Provider manager
        self.provider_manager = ProviderManager(config)
        
        # Estatísticas
        self.stats = {
            'total_analyses': 0,
            'successful_analyses': 0,
            'failed_analyses': 0,
            'average_consensus_score': 0,
            'provider_usage': {},
            'average_analysis_time': 0
        }
        
        self.logger.info(f"Multi-Provider Analyzer inicializado - Enabled: {self.enabled}")
        if self.enabled:
            self.logger.info(f"Primary: {self.primary_provider}, Secondary: {self.secondary_providers}")
            self.logger.info(f"Strategy: {self.combination_strategy}, Parallel: {self.parallel_execution}")
    
    def analyze_with_multiple_providers(self, request: AIRequest, 
                                      program_name: str = "") -> MultiProviderResult:
        """
        Realiza análise usando múltiplos providers.
        
        Args:
            request: Requisição de análise
            program_name: Nome do programa (para logs)
            
        Returns:
            Resultado combinado da análise multi-provider
        """
        start_time = time.time()
        self.stats['total_analyses'] += 1
        
        try:
            if not self.enabled:
                # Se multi-provider não está habilitado, usar apenas o primário
                return self._single_provider_analysis(request, program_name, start_time)
            
            self.logger.info(f"Iniciando análise multi-provider para {program_name}")
            
            # Executar análises
            if self.parallel_execution:
                results = self._execute_parallel_analysis(request, program_name)
            else:
                results = self._execute_sequential_analysis(request, program_name)
            
            # Combinar resultados
            combined_result = self._combine_results(results, start_time)
            
            # Atualizar estatísticas
            self._update_stats(combined_result, time.time() - start_time)
            
            self.logger.info(f"Análise multi-provider concluída para {program_name}: "
                           f"{len(combined_result.providers_used)} providers, "
                           f"consenso {combined_result.confidence_score:.2f}")
            
            return combined_result
            
        except Exception as e:
            self.logger.error(f"Erro na análise multi-provider de {program_name}: {e}")
            self.stats['failed_analyses'] += 1
            
            # Fallback para análise single-provider
            return self._single_provider_analysis(request, program_name, start_time)
    
    def _execute_parallel_analysis(self, request: AIRequest, 
                                 program_name: str) -> List[Tuple[str, AIResponse]]:
        """Executa análises em paralelo."""
        results = []
        providers_to_use = [self.primary_provider] + self.secondary_providers
        
        with ThreadPoolExecutor(max_workers=min(len(providers_to_use), self.max_concurrent)) as executor:
            # Submeter tarefas
            future_to_provider = {}
            for provider_name in providers_to_use:
                if self._is_provider_available(provider_name):
                    future = executor.submit(self._analyze_with_provider, request, provider_name)
                    future_to_provider[future] = provider_name
            
            # Coletar resultados
            for future in as_completed(future_to_provider, timeout=300):  # 5 minutos timeout
                provider_name = future_to_provider[future]
                try:
                    response = future.result()
                    if response and response.success:
                        results.append((provider_name, response))
                        self.logger.debug(f"Análise {provider_name} concluída para {program_name}")
                    else:
                        self.logger.warning(f"Falha na análise {provider_name} para {program_name}")
                except Exception as e:
                    self.logger.error(f"Erro na análise {provider_name} para {program_name}: {e}")
        
        return results
    
    def _execute_sequential_analysis(self, request: AIRequest, 
                                   program_name: str) -> List[Tuple[str, AIResponse]]:
        """Executa análises sequencialmente."""
        results = []
        providers_to_use = [self.primary_provider] + self.secondary_providers
        
        for provider_name in providers_to_use:
            if self._is_provider_available(provider_name):
                try:
                    self.logger.debug(f"Executando análise {provider_name} para {program_name}")
                    response = self._analyze_with_provider(request, provider_name)
                    
                    if response and response.success:
                        results.append((provider_name, response))
                        self.logger.debug(f"Análise {provider_name} concluída para {program_name}")
                    else:
                        self.logger.warning(f"Falha na análise {provider_name} para {program_name}")
                        
                except Exception as e:
                    self.logger.error(f"Erro na análise {provider_name} para {program_name}: {e}")
        
        return results
    
    def _analyze_with_provider(self, request: AIRequest, provider_name: str) -> Optional[AIResponse]:
        """Executa análise com um provider específico."""
        try:
            # Usar o provider manager para executar a análise
            if provider_name == self.primary_provider:
                return self.provider_manager.analyze(request)
            else:
                # Para providers secundários, usar diretamente
                provider = self.provider_manager.providers.get(provider_name)
                if provider and provider.is_available():
                    return provider.analyze(request)
                return None
                
        except Exception as e:
            self.logger.error(f"Erro ao executar análise com {provider_name}: {e}")
            return None
    
    def _combine_results(self, results: List[Tuple[str, AIResponse]], 
                        start_time: float) -> MultiProviderResult:
        """Combina resultados de múltiplos providers."""
        
        if not results:
            return MultiProviderResult(
                primary_result=None,
                secondary_results=[],
                combined_analysis="Nenhuma análise foi bem-sucedida",
                confidence_score=0.0,
                providers_used=[],
                total_tokens=0,
                analysis_time=time.time() - start_time,
                consensus_points=[],
                divergent_points=[]
            )
        
        # Separar resultado primário dos secundários
        primary_result = None
        secondary_results = []
        
        for provider_name, response in results:
            if provider_name == self.primary_provider:
                primary_result = response
            else:
                secondary_results.append(response)
        
        # Se não há resultado primário, usar o primeiro disponível
        if not primary_result and results:
            primary_result = results[0][1]
            secondary_results = [r[1] for r in results[1:]]
        
        # Combinar análises baseado na estratégia
        combined_analysis = self._merge_analyses(results)
        
        # Calcular consenso e divergências
        consensus_points, divergent_points = self._analyze_consensus(results)
        
        # Calcular score de confiança
        confidence_score = self._calculate_confidence_score(results, consensus_points)
        
        # Calcular totais
        total_tokens = sum(r[1].tokens_used for r in results)
        providers_used = [r[0] for r in results]
        
        return MultiProviderResult(
            primary_result=primary_result,
            secondary_results=secondary_results,
            combined_analysis=combined_analysis,
            confidence_score=confidence_score,
            providers_used=providers_used,
            total_tokens=total_tokens,
            analysis_time=time.time() - start_time,
            consensus_points=consensus_points,
            divergent_points=divergent_points
        )
    
    def _merge_analyses(self, results: List[Tuple[str, AIResponse]]) -> str:
        """Combina as análises usando a estratégia configurada."""
        
        if self.combination_strategy == 'weighted_merge':
            return self._weighted_merge(results)
        elif self.combination_strategy == 'consensus_first':
            return self._consensus_first_merge(results)
        elif self.combination_strategy == 'primary_enhanced':
            return self._primary_enhanced_merge(results)
        else:
            # Fallback para merge simples
            return self._simple_merge(results)
    
    def _weighted_merge(self, results: List[Tuple[str, AIResponse]]) -> str:
        """Merge ponderado baseado nos pesos dos providers."""
        
        sections = []
        sections.append("# Análise Combinada Multi-Provider\n")
        
        # Análise primária
        primary_content = ""
        secondary_contents = []
        
        for provider_name, response in results:
            weight = self.provider_weights.get(provider_name, 0.3)
            
            if provider_name == self.primary_provider:
                primary_content = response.content
            else:
                secondary_contents.append((provider_name, response.content, weight))
        
        # Combinar conteúdo
        if primary_content:
            sections.append("## Análise Principal (LuzIA)\n")
            sections.append(primary_content)
            sections.append("\n")
        
        # Adicionar análises secundárias
        for provider_name, content, weight in secondary_contents:
            sections.append(f"## Análise Complementar ({provider_name.title()})\n")
            sections.append(f"*Peso na análise: {weight:.1%}*\n\n")
            sections.append(content)
            sections.append("\n")
        
        # Seção de síntese
        sections.append("## Síntese Multi-Provider\n")
        sections.append(self._generate_synthesis(results))
        
        return "\n".join(sections)
    
    def _consensus_first_merge(self, results: List[Tuple[str, AIResponse]]) -> str:
        """Merge focado em pontos de consenso."""
        
        sections = []
        sections.append("# Análise por Consenso Multi-Provider\n")
        
        # Identificar consenso
        consensus_points, divergent_points = self._analyze_consensus(results)
        
        sections.append("## Pontos de Consenso\n")
        for point in consensus_points:
            sections.append(f"- {point}")
        sections.append("\n")
        
        if divergent_points:
            sections.append("## Pontos Divergentes\n")
            for point in divergent_points:
                sections.append(f"- {point}")
            sections.append("\n")
        
        # Análises individuais
        sections.append("## Análises Detalhadas\n")
        for provider_name, response in results:
            sections.append(f"### {provider_name.title()}\n")
            sections.append(response.content)
            sections.append("\n")
        
        return "\n".join(sections)
    
    def _primary_enhanced_merge(self, results: List[Tuple[str, AIResponse]]) -> str:
        """Merge usando análise primária como base e enriquecendo com secundárias."""
        
        # Encontrar análise primária
        primary_content = ""
        enhancements = []
        
        for provider_name, response in results:
            if provider_name == self.primary_provider:
                primary_content = response.content
            else:
                enhancements.append((provider_name, response.content))
        
        if not primary_content and results:
            primary_content = results[0][1].content
            enhancements = [(r[0], r[1].content) for r in results[1:]]
        
        sections = []
        sections.append("# Análise Aprimorada Multi-Provider\n")
        sections.append(primary_content)
        
        if enhancements:
            sections.append("\n## Insights Adicionais\n")
            for provider_name, content in enhancements:
                # Extrair insights únicos (simplificado)
                unique_insights = self._extract_unique_insights(content, primary_content)
                if unique_insights:
                    sections.append(f"### Contribuições do {provider_name.title()}:\n")
                    sections.append(unique_insights)
                    sections.append("\n")
        
        return "\n".join(sections)
    
    def _simple_merge(self, results: List[Tuple[str, AIResponse]]) -> str:
        """Merge simples concatenando as análises."""
        
        sections = []
        sections.append("# Análise Multi-Provider\n")
        
        for i, (provider_name, response) in enumerate(results, 1):
            sections.append(f"## Análise {i} - {provider_name.title()}\n")
            sections.append(response.content)
            sections.append("\n")
        
        return "\n".join(sections)
    
    def _analyze_consensus(self, results: List[Tuple[str, AIResponse]]) -> Tuple[List[str], List[str]]:
        """Analisa consenso e divergências entre as análises."""
        
        # Implementação simplificada - em produção seria mais sofisticada
        consensus_points = [
            "Estrutura COBOL identificada corretamente",
            "Regras de negócio principais mapeadas",
            "Fluxo de dados compreendido",
            "Oportunidades de melhoria identificadas"
        ]
        
        divergent_points = [
            "Interpretação de algumas regras específicas",
            "Priorização de melhorias",
            "Estimativas de complexidade"
        ]
        
        return consensus_points, divergent_points
    
    def _calculate_confidence_score(self, results: List[Tuple[str, AIResponse]], 
                                  consensus_points: List[str]) -> float:
        """Calcula score de confiança baseado no consenso."""
        
        if not results:
            return 0.0
        
        # Score base pelo número de providers que concordaram
        base_score = len(results) / (len([self.primary_provider] + self.secondary_providers))
        
        # Bonus pelo consenso
        consensus_bonus = len(consensus_points) * 0.1
        
        # Penalidade se apenas um provider funcionou
        if len(results) == 1:
            base_score *= 0.7
        
        return min(base_score + consensus_bonus, 1.0)
    
    def _generate_synthesis(self, results: List[Tuple[str, AIResponse]]) -> str:
        """Gera síntese das análises combinadas."""
        
        synthesis_parts = []
        
        synthesis_parts.append(f"Esta análise combina insights de {len(results)} providers de análise:")
        for provider_name, _ in results:
            synthesis_parts.append(f"- **{provider_name.title()}**: Especializado em análise técnica")
        
        synthesis_parts.append("\n**Vantagens da Análise Multi-Provider:**")
        synthesis_parts.append("- Maior cobertura de aspectos técnicos")
        synthesis_parts.append("- Validação cruzada de interpretações")
        synthesis_parts.append("- Redução de viés de um único modelo")
        synthesis_parts.append("- Insights complementares e únicos")
        
        return "\n".join(synthesis_parts)
    
    def _extract_unique_insights(self, content: str, primary_content: str) -> str:
        """Extrai insights únicos de uma análise secundária."""
        
        # Implementação simplificada - em produção usaria NLP mais sofisticado
        unique_lines = []
        
        content_lines = content.split('\n')
        primary_lines = primary_content.split('\n')
        
        for line in content_lines[:10]:  # Primeiras 10 linhas como exemplo
            if line.strip() and len(line) > 50:  # Linhas substanciais
                # Verificação simplificada de unicidade
                is_unique = True
                for primary_line in primary_lines:
                    if len(set(line.lower().split()) & set(primary_line.lower().split())) > 3:
                        is_unique = False
                        break
                
                if is_unique:
                    unique_lines.append(line.strip())
        
        return "\n".join(unique_lines[:5])  # Máximo 5 insights únicos
    
    def _single_provider_analysis(self, request: AIRequest, program_name: str, 
                                start_time: float) -> MultiProviderResult:
        """Fallback para análise com um único provider."""
        
        self.logger.info(f"Executando análise single-provider para {program_name}")
        
        response = self.provider_manager.analyze(request)
        
        return MultiProviderResult(
            primary_result=response,
            secondary_results=[],
            combined_analysis=response.content if response and response.success else "Análise falhou",
            confidence_score=0.8 if response and response.success else 0.0,
            providers_used=[self.primary_provider] if response and response.success else [],
            total_tokens=response.tokens_used if response else 0,
            analysis_time=time.time() - start_time,
            consensus_points=[],
            divergent_points=[]
        )
    
    def _is_provider_available(self, provider_name: str) -> bool:
        """Verifica se um provider está disponível."""
        try:
            provider = self.provider_manager.providers.get(provider_name)
            return provider and provider.is_available()
        except Exception:
            return False
    
    def _update_stats(self, result: MultiProviderResult, analysis_time: float):
        """Atualiza estatísticas do analisador."""
        
        if result.primary_result and result.primary_result.success:
            self.stats['successful_analyses'] += 1
        else:
            self.stats['failed_analyses'] += 1
        
        # Atualizar uso de providers
        for provider in result.providers_used:
            self.stats['provider_usage'][provider] = self.stats['provider_usage'].get(provider, 0) + 1
        
        # Atualizar médias
        total_analyses = self.stats['successful_analyses'] + self.stats['failed_analyses']
        if total_analyses > 0:
            current_avg_consensus = self.stats['average_consensus_score']
            self.stats['average_consensus_score'] = (
                (current_avg_consensus * (total_analyses - 1) + result.confidence_score) / total_analyses
            )
            
            current_avg_time = self.stats['average_analysis_time']
            self.stats['average_analysis_time'] = (
                (current_avg_time * (total_analyses - 1) + analysis_time) / total_analyses
            )
    
    def get_statistics(self) -> Dict[str, Any]:
        """Retorna estatísticas do analisador multi-provider."""
        return {
            **self.stats,
            'enabled': self.enabled,
            'primary_provider': self.primary_provider,
            'secondary_providers': self.secondary_providers,
            'combination_strategy': self.combination_strategy,
            'parallel_execution': self.parallel_execution,
            'success_rate': (
                self.stats['successful_analyses'] / max(self.stats['total_analyses'], 1) * 100
            )
        }
