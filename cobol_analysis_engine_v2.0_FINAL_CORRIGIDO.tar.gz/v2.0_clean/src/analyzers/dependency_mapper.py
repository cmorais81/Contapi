import re
import logging
from typing import Dict, Any, List, Set, Tuple, Optional
from dataclasses import dataclass
from collections import defaultdict, deque

@dataclass
class Dependency:
    """Representa uma dependência identificada."""
    source: str
    target: str
    dependency_type: str  # CALLS, COPIES, READS, WRITES, etc.
    line_number: int
    confidence: float
    bidirectional: bool = False

@dataclass
class DependencyNode:
    """Representa um nó no grafo de dependências."""
    name: str
    node_type: str  # PROGRAM, COPYBOOK, FILE, DATABASE, etc.
    incoming_dependencies: List[Dependency]
    outgoing_dependencies: List[Dependency]
    criticality_score: int
    impact_radius: int  # Quantos nós são afetados por mudanças neste

class DependencyMapper:
    """
    Mapeador de Dependências
    
    Cria um grafo completo de dependências mostrando como programas,
    copybooks, arquivos e sistemas se relacionam.
    """

    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
        # Padrões para diferentes tipos de dependências
        self.dependency_patterns = {
            'program_calls': [
                r'CALL\s+[\'"]([A-Z0-9-]+)[\'"]',
                r'CALL\s+([A-Z0-9-]+)\s+USING',
                r'PERFORM\s+([A-Z0-9-]+)'
            ],
            'copybook_includes': [
                r'COPY\s+([A-Z0-9-]+)',
                r'INCLUDE\s+([A-Z0-9-]+)'
            ],
            'file_operations': [
                r'SELECT\s+([A-Z0-9-]+)\s+ASSIGN\s+TO\s+([A-Z0-9-]+)',
                r'FD\s+([A-Z0-9-]+)',
                r'OPEN\s+(INPUT|OUTPUT|I-O|EXTEND)\s+([A-Z0-9-]+)',
                r'READ\s+([A-Z0-9-]+)',
                r'WRITE\s+([A-Z0-9-]+)',
                r'REWRITE\s+([A-Z0-9-]+)',
                r'DELETE\s+([A-Z0-9-]+)'
            ],
            'database_operations': [
                r'EXEC\s+SQL\s+SELECT.*FROM\s+([A-Z0-9_]+)',
                r'EXEC\s+SQL\s+INSERT\s+INTO\s+([A-Z0-9_]+)',
                r'EXEC\s+SQL\s+UPDATE\s+([A-Z0-9_]+)',
                r'EXEC\s+SQL\s+DELETE\s+FROM\s+([A-Z0-9_]+)'
            ],
            'middleware_calls': [
                r'EXEC\s+CICS\s+([A-Z]+)',
                r'EXEC\s+MQ\s+([A-Z]+)',
                r'CALL\s+[\'"]MQCONN[\'"]',
                r'CALL\s+[\'"]DFHEI1[\'"]'
            ]
        }

    def map_dependencies(self, program_name: str, code_lines: List[str], 
                        available_programs: List[str] = None,
                        available_copybooks: List[str] = None) -> Dict[str, Any]:
        """
        Mapeia todas as dependências do programa.
        """
        self.logger.info(f"Mapeando dependências para {program_name}")
        
        code_text = '\n'.join(code_lines)
        
        # Extrai dependências por tipo
        dependencies = self._extract_all_dependencies(program_name, code_text, code_lines)
        
        # Constrói grafo de dependências
        dependency_graph = self._build_dependency_graph(dependencies, available_programs, available_copybooks)
        
        # Analisa impacto de mudanças
        impact_analysis = self._analyze_change_impact(dependency_graph, program_name)
        
        # Identifica pontos críticos
        critical_points = self._identify_critical_points(dependency_graph)
        
        # Calcula métricas de acoplamento
        coupling_metrics = self._calculate_coupling_metrics(dependency_graph, program_name)
        
        # Gera recomendações
        recommendations = self._generate_dependency_recommendations(
            dependency_graph, impact_analysis, critical_points, coupling_metrics
        )
        
        return {
            "program_name": program_name,
            "dependencies": dependencies,
            "dependency_graph": dependency_graph,
            "impact_analysis": impact_analysis,
            "critical_points": critical_points,
            "coupling_metrics": coupling_metrics,
            "recommendations": recommendations,
            "dependency_summary": self._generate_dependency_summary(dependencies)
        }

    def _extract_all_dependencies(self, program_name: str, code_text: str, 
                                 code_lines: List[str]) -> Dict[str, List[Dependency]]:
        """Extrai todas as dependências por tipo."""
        dependencies = defaultdict(list)
        
        for dep_type, patterns in self.dependency_patterns.items():
            for pattern in patterns:
                matches = re.finditer(pattern, code_text, re.IGNORECASE | re.MULTILINE)
                
                for match in matches:
                    line_num = code_text[:match.start()].count('\n') + 1
                    
                    if dep_type == 'program_calls':
                        target = match.group(1)
                        confidence = self._calculate_call_confidence(code_lines[line_num-1], target)
                        
                        dependencies[dep_type].append(Dependency(
                            source=program_name,
                            target=target,
                            dependency_type="CALLS",
                            line_number=line_num,
                            confidence=confidence
                        ))
                    
                    elif dep_type == 'copybook_includes':
                        target = match.group(1)
                        
                        dependencies[dep_type].append(Dependency(
                            source=program_name,
                            target=target,
                            dependency_type="INCLUDES",
                            line_number=line_num,
                            confidence=0.95  # COPY statements são muito confiáveis
                        ))
                    
                    elif dep_type == 'file_operations':
                        if 'SELECT' in match.group(0).upper():
                            logical_file = match.group(1)
                            physical_file = match.group(2) if match.lastindex > 1 else logical_file
                            
                            dependencies[dep_type].append(Dependency(
                                source=program_name,
                                target=f"{logical_file}({physical_file})",
                                dependency_type="DEFINES_FILE",
                                line_number=line_num,
                                confidence=0.9
                            ))
                        else:
                            file_name = match.group(1)
                            operation = self._extract_file_operation(match.group(0))
                            
                            dependencies[dep_type].append(Dependency(
                                source=program_name,
                                target=file_name,
                                dependency_type=operation,
                                line_number=line_num,
                                confidence=0.85
                            ))
                    
                    elif dep_type == 'database_operations':
                        table_name = match.group(1)
                        operation = self._extract_db_operation(match.group(0))
                        
                        dependencies[dep_type].append(Dependency(
                            source=program_name,
                            target=table_name,
                            dependency_type=operation,
                            line_number=line_num,
                            confidence=0.9
                        ))
                    
                    elif dep_type == 'middleware_calls':
                        middleware_op = match.group(1) if match.lastindex > 0 else "UNKNOWN"
                        middleware_type = "CICS" if "CICS" in match.group(0) else "MQ"
                        
                        dependencies[dep_type].append(Dependency(
                            source=program_name,
                            target=f"{middleware_type}_{middleware_op}",
                            dependency_type="MIDDLEWARE_CALL",
                            line_number=line_num,
                            confidence=0.8
                        ))
        
        return dict(dependencies)

    def _build_dependency_graph(self, dependencies: Dict[str, List[Dependency]], 
                               available_programs: List[str] = None,
                               available_copybooks: List[str] = None) -> Dict[str, DependencyNode]:
        """Constrói o grafo de dependências."""
        graph = {}
        
        # Cria nós para todos os elementos identificados
        all_nodes = set()
        
        for dep_list in dependencies.values():
            for dep in dep_list:
                all_nodes.add(dep.source)
                all_nodes.add(dep.target)
        
        # Inicializa nós
        for node_name in all_nodes:
            node_type = self._determine_node_type(node_name, available_programs, available_copybooks)
            graph[node_name] = DependencyNode(
                name=node_name,
                node_type=node_type,
                incoming_dependencies=[],
                outgoing_dependencies=[],
                criticality_score=0,
                impact_radius=0
            )
        
        # Adiciona dependências aos nós
        for dep_list in dependencies.values():
            for dep in dep_list:
                if dep.source in graph:
                    graph[dep.source].outgoing_dependencies.append(dep)
                if dep.target in graph:
                    graph[dep.target].incoming_dependencies.append(dep)
        
        # Calcula scores de criticidade
        for node in graph.values():
            node.criticality_score = self._calculate_criticality_score(node)
            node.impact_radius = self._calculate_impact_radius(node, graph)
        
        return graph

    def _analyze_change_impact(self, graph: Dict[str, DependencyNode], 
                              program_name: str) -> Dict[str, Any]:
        """Analisa o impacto de mudanças no programa."""
        if program_name not in graph:
            return {"error": "Program not found in dependency graph"}
        
        program_node = graph[program_name]
        
        # Programas que serão afetados se este programa mudar
        downstream_impact = self._find_downstream_dependencies(program_name, graph)
        
        # Programas que podem afetar este programa se mudarem
        upstream_dependencies = self._find_upstream_dependencies(program_name, graph)
        
        # Calcula raio de impacto
        impact_radius = len(downstream_impact)
        
        # Classifica o risco
        if impact_radius > 10:
            risk_level = "CRITICAL"
        elif impact_radius > 5:
            risk_level = "HIGH"
        elif impact_radius > 2:
            risk_level = "MEDIUM"
        else:
            risk_level = "LOW"
        
        return {
            "downstream_impact": downstream_impact,
            "upstream_dependencies": upstream_dependencies,
            "impact_radius": impact_radius,
            "risk_level": risk_level,
            "change_impact_score": self._calculate_change_impact_score(program_node)
        }

    def _find_downstream_dependencies(self, node_name: str, 
                                    graph: Dict[str, DependencyNode]) -> List[str]:
        """Encontra todos os nós que dependem deste nó (direta ou indiretamente)."""
        visited = set()
        downstream = []
        queue = deque([node_name])
        
        while queue:
            current = queue.popleft()
            if current in visited:
                continue
                
            visited.add(current)
            
            if current != node_name:  # Não inclui o nó original
                downstream.append(current)
            
            # Adiciona nós que dependem do atual
            if current in graph:
                for dep in graph[current].incoming_dependencies:
                    if dep.source not in visited:
                        queue.append(dep.source)
        
        return downstream

    def _find_upstream_dependencies(self, node_name: str, 
                                  graph: Dict[str, DependencyNode]) -> List[str]:
        """Encontra todos os nós dos quais este nó depende (direta ou indiretamente)."""
        visited = set()
        upstream = []
        queue = deque([node_name])
        
        while queue:
            current = queue.popleft()
            if current in visited:
                continue
                
            visited.add(current)
            
            if current != node_name:  # Não inclui o nó original
                upstream.append(current)
            
            # Adiciona nós dos quais o atual depende
            if current in graph:
                for dep in graph[current].outgoing_dependencies:
                    if dep.target not in visited:
                        queue.append(dep.target)
        
        return upstream

    def _identify_critical_points(self, graph: Dict[str, DependencyNode]) -> List[Dict[str, Any]]:
        """Identifica pontos críticos no grafo de dependências."""
        critical_points = []
        
        for node_name, node in graph.items():
            # Nós com muitas dependências de entrada (bottlenecks)
            if len(node.incoming_dependencies) > 5:
                critical_points.append({
                    "name": node_name,
                    "type": "BOTTLENECK",
                    "reason": f"Recebe {len(node.incoming_dependencies)} dependências",
                    "impact": "HIGH",
                    "recommendation": "Considere dividir responsabilidades"
                })
            
            # Nós com muitas dependências de saída (high coupling)
            if len(node.outgoing_dependencies) > 8:
                critical_points.append({
                    "name": node_name,
                    "type": "HIGH_COUPLING",
                    "reason": f"Depende de {len(node.outgoing_dependencies)} outros componentes",
                    "impact": "MEDIUM",
                    "recommendation": "Revise arquitetura para reduzir acoplamento"
                })
            
            # Nós críticos por tipo
            if node.node_type == "DATABASE" and len(node.incoming_dependencies) > 3:
                critical_points.append({
                    "name": node_name,
                    "type": "DATABASE_HOTSPOT",
                    "reason": f"Tabela acessada por {len(node.incoming_dependencies)} programas",
                    "impact": "HIGH",
                    "recommendation": "Monitore performance e considere otimizações"
                })
        
        # Ordena por impacto
        critical_points.sort(key=lambda x: {"HIGH": 3, "MEDIUM": 2, "LOW": 1}[x["impact"]], reverse=True)
        
        return critical_points

    def _calculate_coupling_metrics(self, graph: Dict[str, DependencyNode], 
                                  program_name: str) -> Dict[str, Any]:
        """Calcula métricas de acoplamento."""
        if program_name not in graph:
            return {}
        
        program_node = graph[program_name]
        
        # Acoplamento eferente (Ce) - dependências de saída
        efferent_coupling = len(program_node.outgoing_dependencies)
        
        # Acoplamento aferente (Ca) - dependências de entrada
        afferent_coupling = len(program_node.incoming_dependencies)
        
        # Instabilidade (I) = Ce / (Ca + Ce)
        total_coupling = efferent_coupling + afferent_coupling
        instability = efferent_coupling / total_coupling if total_coupling > 0 else 0
        
        # Classifica estabilidade
        if instability < 0.3:
            stability_class = "STABLE"
        elif instability < 0.7:
            stability_class = "SEMI_STABLE"
        else:
            stability_class = "UNSTABLE"
        
        return {
            "efferent_coupling": efferent_coupling,
            "afferent_coupling": afferent_coupling,
            "instability": round(instability, 3),
            "stability_class": stability_class,
            "coupling_score": total_coupling
        }

    def _generate_dependency_recommendations(self, graph: Dict[str, DependencyNode],
                                           impact_analysis: Dict[str, Any],
                                           critical_points: List[Dict[str, Any]],
                                           coupling_metrics: Dict[str, Any]) -> List[str]:
        """Gera recomendações baseadas na análise de dependências."""
        recommendations = []
        
        # Recomendações baseadas no impacto
        risk_level = impact_analysis.get("risk_level", "LOW")
        if risk_level == "CRITICAL":
            recommendations.append(
                "CRÍTICO: Programa tem impacto muito alto. Mudanças devem ser "
                "cuidadosamente planejadas e testadas em ambiente isolado."
            )
        elif risk_level == "HIGH":
            recommendations.append(
                "ALTO RISCO: Mapeie todos os programas afetados antes de fazer mudanças. "
                "Considere implementação em fases."
            )
        
        # Recomendações baseadas em acoplamento
        if coupling_metrics.get("stability_class") == "UNSTABLE":
            recommendations.append(
                "INSTABILIDADE: Programa tem alto acoplamento eferente. "
                "Considere refatoração para reduzir dependências externas."
            )
        
        # Recomendações baseadas em pontos críticos
        bottlenecks = [cp for cp in critical_points if cp["type"] == "BOTTLENECK"]
        if bottlenecks:
            recommendations.append(
                f"GARGALO: {len(bottlenecks)} componentes identificados como gargalos. "
                "Priorize otimização destes pontos."
            )
        
        # Recomendações específicas por tipo de dependência
        db_deps = sum(1 for node in graph.values() if node.node_type == "DATABASE")
        if db_deps > 5:
            recommendations.append(
                f"BANCO DE DADOS: Programa acessa {db_deps} tabelas. "
                "Valide performance e considere cache quando apropriado."
            )
        
        file_deps = sum(1 for node in graph.values() if node.node_type == "FILE")
        if file_deps > 8:
            recommendations.append(
                f"ARQUIVOS: Programa manipula {file_deps} arquivos. "
                "Garanta que todos estão disponíveis e monitore espaço em disco."
            )
        
        return recommendations

    def _generate_dependency_summary(self, dependencies: Dict[str, List[Dependency]]) -> Dict[str, int]:
        """Gera resumo quantitativo das dependências."""
        summary = {}
        
        for dep_type, dep_list in dependencies.items():
            summary[dep_type] = len(dep_list)
        
        # Calcula totais
        summary["total_dependencies"] = sum(summary.values())
        summary["unique_targets"] = len(set(dep.target for dep_list in dependencies.values() for dep in dep_list))
        
        return summary

    def _determine_node_type(self, node_name: str, available_programs: List[str] = None,
                           available_copybooks: List[str] = None) -> str:
        """Determina o tipo do nó baseado no nome e contexto."""
        if available_programs and node_name in available_programs:
            return "PROGRAM"
        elif available_copybooks and node_name in available_copybooks:
            return "COPYBOOK"
        elif "(" in node_name:  # Formato arquivo(físico)
            return "FILE"
        elif "_" in node_name and any(db_word in node_name.upper() 
                                     for db_word in ["TABLE", "VIEW", "TAB"]):
            return "DATABASE"
        elif any(mw_word in node_name.upper() 
                for mw_word in ["CICS", "MQ", "DFHEI"]):
            return "MIDDLEWARE"
        elif node_name.upper().endswith((".CPY", ".COPY")):
            return "COPYBOOK"
        elif len(node_name) <= 8 and node_name.isalnum():
            return "PROGRAM"
        else:
            return "UNKNOWN"

    def _calculate_call_confidence(self, line: str, target: str) -> float:
        """Calcula confiança de uma chamada baseada no contexto."""
        confidence = 0.7  # Base
        
        # Aumenta confiança se tem USING
        if "USING" in line.upper():
            confidence += 0.1
        
        # Aumenta confiança se target parece um programa válido
        if len(target) <= 8 and target.replace("-", "").isalnum():
            confidence += 0.1
        
        # Reduz confiança se está em comentário
        if line.strip().startswith("*"):
            confidence *= 0.3
        
        return min(1.0, confidence)

    def _extract_file_operation(self, operation_text: str) -> str:
        """Extrai o tipo de operação de arquivo."""
        operation_upper = operation_text.upper()
        
        if "OPEN" in operation_upper:
            if "INPUT" in operation_upper:
                return "READS_FILE"
            elif "OUTPUT" in operation_upper:
                return "WRITES_FILE"
            else:
                return "ACCESSES_FILE"
        elif "READ" in operation_upper:
            return "READS_FILE"
        elif "WRITE" in operation_upper:
            return "WRITES_FILE"
        elif "REWRITE" in operation_upper:
            return "UPDATES_FILE"
        elif "DELETE" in operation_upper:
            return "DELETES_FILE"
        else:
            return "ACCESSES_FILE"

    def _extract_db_operation(self, sql_text: str) -> str:
        """Extrai o tipo de operação de banco de dados."""
        sql_upper = sql_text.upper()
        
        if "SELECT" in sql_upper:
            return "READS_TABLE"
        elif "INSERT" in sql_upper:
            return "INSERTS_TABLE"
        elif "UPDATE" in sql_upper:
            return "UPDATES_TABLE"
        elif "DELETE" in sql_upper:
            return "DELETES_TABLE"
        else:
            return "ACCESSES_TABLE"

    def _calculate_criticality_score(self, node: DependencyNode) -> int:
        """Calcula score de criticidade do nó."""
        score = 0
        
        # Pontos por dependências de entrada (outros dependem deste)
        score += len(node.incoming_dependencies) * 2
        
        # Pontos por dependências de saída (este depende de outros)
        score += len(node.outgoing_dependencies)
        
        # Bonus por tipo de nó
        type_bonus = {
            "DATABASE": 5,
            "MIDDLEWARE": 4,
            "FILE": 2,
            "PROGRAM": 1,
            "COPYBOOK": 3
        }
        score += type_bonus.get(node.node_type, 0)
        
        return score

    def _calculate_impact_radius(self, node: DependencyNode, 
                               graph: Dict[str, DependencyNode]) -> int:
        """Calcula quantos nós seriam afetados por mudanças neste nó."""
        # Para simplicidade, usa o número de dependências diretas
        # Uma implementação mais sofisticada faria BFS/DFS
        return len(node.incoming_dependencies)

    def _calculate_change_impact_score(self, node: DependencyNode) -> int:
        """Calcula score de impacto de mudanças."""
        return node.criticality_score + node.impact_radius * 2

    def generate_dependency_report(self, dependency_analysis: Dict[str, Any]) -> str:
        """Gera relatório de dependências em formato Markdown."""
        program_name = dependency_analysis["program_name"]
        dependencies = dependency_analysis["dependencies"]
        impact_analysis = dependency_analysis["impact_analysis"]
        critical_points = dependency_analysis["critical_points"]
        coupling_metrics = dependency_analysis["coupling_metrics"]
        recommendations = dependency_analysis["recommendations"]
        summary = dependency_analysis["dependency_summary"]
        
        report = [
            f"# 🔗 Mapa de Dependências - {program_name}",
            "",
            "##  Resumo Executivo",
            f"- **Total de Dependências:** {summary.get('total_dependencies', 0)}",
            f"- **Componentes Únicos:** {summary.get('unique_targets', 0)}",
            f"- **Risco de Mudança:** {impact_analysis.get('risk_level', 'UNKNOWN')}",
            f"- **Raio de Impacto:** {impact_analysis.get('impact_radius', 0)} programas afetados",
            f"- **Classe de Estabilidade:** {coupling_metrics.get('stability_class', 'UNKNOWN')}",
            "",
            "##  Métricas de Acoplamento",
            f"- **Acoplamento Eferente (Ce):** {coupling_metrics.get('efferent_coupling', 0)} - Dependências de saída",
            f"- **Acoplamento Aferente (Ca):** {coupling_metrics.get('afferent_coupling', 0)} - Dependências de entrada",
            f"- **Instabilidade (I):** {coupling_metrics.get('instability', 0)} - Tendência a mudanças",
            f"- **Score de Acoplamento:** {coupling_metrics.get('coupling_score', 0)}",
            "",
            "##  Dependências por Tipo",
            ""
        ]
        
        for dep_type, dep_list in dependencies.items():
            if dep_list:
                type_name = dep_type.replace("_", " ").title()
                report.append(f"### {type_name} ({len(dep_list)})")
                report.append("| Alvo | Tipo | Linha | Confiança |")
                report.append("|------|------|-------|-----------|")
                
                for dep in dep_list[:10]:  # Top 10 por tipo
                    confidence_pct = f"{dep.confidence*100:.0f}%"
                    report.append(f"| {dep.target} | {dep.dependency_type} | {dep.line_number} | {confidence_pct} |")
                
                if len(dep_list) > 10:
                    report.append(f"*... e mais {len(dep_list) - 10} dependências*")
                report.append("")
        
        report.extend([
            "## ⚠️ Pontos Críticos",
            ""
        ])
        
        if critical_points:
            report.append("| Componente | Tipo | Impacto | Motivo |")
            report.append("|------------|------|---------|--------|")
            for cp in critical_points:
                report.append(f"| {cp['name']} | {cp['type']} | {cp['impact']} | {cp['reason']} |")
        else:
            report.append("*Nenhum ponto crítico identificado.*")
        
        report.extend([
            "",
            "##  Análise de Impacto de Mudanças",
            "",
            f"**Risco:** {impact_analysis.get('risk_level', 'UNKNOWN')}",
            "",
            "### Programas que Serão Afetados (Downstream):"
        ])
        
        downstream = impact_analysis.get("downstream_impact", [])
        if downstream:
            for program in downstream[:10]:  # Top 10
                report.append(f"- {program}")
            if len(downstream) > 10:
                report.append(f"*... e mais {len(downstream) - 10} programas*")
        else:
            report.append("*Nenhum programa será diretamente afetado.*")
        
        report.extend([
            "",
            "### Programas dos Quais Depende (Upstream):"
        ])
        
        upstream = impact_analysis.get("upstream_dependencies", [])
        if upstream:
            for program in upstream[:10]:  # Top 10
                report.append(f"- {program}")
            if len(upstream) > 10:
                report.append(f"*... e mais {len(upstream) - 10} programas*")
        else:
            report.append("*Programa não depende diretamente de outros.*")
        
        report.extend([
            "",
            "##  Recomendações Estratégicas",
            ""
        ])
        
        for i, recommendation in enumerate(recommendations, 1):
            report.append(f"{i}. {recommendation}")
        
        report.extend([
            "",
            "##  Guia para Especialistas",
            "",
            "### Antes de Fazer Mudanças:",
            "1. **Valide todas as dependências** listadas acima",
            "2. **Notifique equipes** responsáveis pelos programas downstream",
            "3. **Prepare ambiente de teste** com todos os componentes",
            "4. **Documente mudanças** para facilitar troubleshooting",
            "",
            "### Durante a Implementação:",
            "1. **Monitore componentes críticos** identificados",
            "2. **Teste integração** com programas upstream",
            "3. **Valide funcionamento** dos programas downstream",
            "",
            "### Após a Implementação:",
            "1. **Atualize documentação** de dependências",
            "2. **Monitore performance** de componentes afetados",
            "3. **Colete feedback** das equipes impactadas",
            ""
        ])
        
        return "\n".join(report)
