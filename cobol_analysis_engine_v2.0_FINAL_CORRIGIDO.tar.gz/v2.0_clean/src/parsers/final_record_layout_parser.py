import re
import logging
from typing import List, Dict, Any
from dataclasses import dataclass

@dataclass
class COBOLField:
    level: int
    name: str
    picture: str
    start: int
    length: int
    occurs: int
    redefines: str

class FinalRecordLayoutParser:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.field_pattern = re.compile(r"^\s*(\d{2})\s+([A-Z0-9\-]+)(\s+PIC\s+([^\s]+))?(\s+OCCURS\s+(\d+)\s+TIMES)?(\s+REDEFINES\s+([A-Z0-9\-]+))?.*\.")

    def parse(self, lines: List[str]) -> Dict[str, List[COBOLField]]:
        self.logger.info("Iniciando o parser de layout de registro final.")
        layouts = {}
        in_fd = False
        current_fd = None
        current_offset = 1

        for line in lines:
            line = line[6:].strip()
            if not line or line.startswith("*"):
                continue

            if line.startswith("FD "):
                in_fd = True
                current_fd = line.split(" ")[1]
                layouts[current_fd] = []
                current_offset = 1
                continue

            if in_fd and line.startswith("01"):
                match = self.field_pattern.match(line)
                if match:
                    level, name, _, picture, _, occurs, _, redefines = match.groups()
                    length = self._calculate_length(picture)
                    field = COBOLField(int(level), name, picture, current_offset, length, int(occurs) if occurs else 0, redefines)
                    layouts[current_fd].append(field)
                    current_offset += length
                else:
                    # Handle 01 level without PIC
                    name = line.split()[1].replace(".","")
                    field = COBOLField(1, name, None, current_offset, 0, 0, None)
                    layouts[current_fd].append(field)

            elif in_fd and (line.startswith("SD ") or line.startswith("SELECT ")):
                in_fd = False
                current_fd = None

            elif in_fd and current_fd:
                match = self.field_pattern.match(line)
                if match:
                    level, name, _, picture, _, occurs, _, redefines = match.groups()
                    length = self._calculate_length(picture)
                    field = COBOLField(int(level), name, picture, current_offset, length, int(occurs) if occurs else 0, redefines)
                    layouts[current_fd].append(field)
                    current_offset += length

        self.logger.info(f"Parser de layout de registro finalizou. {len(layouts)} layouts encontrados.")
        return layouts

    def _calculate_length(self, picture: str) -> int:
        if not picture:
            return 0
        if "(" in picture:
            match = re.search(r"\((\d+)\)", picture)
            if match:
                return int(match.group(1))
        return len(picture.replace("S", "").replace("V", ""))

