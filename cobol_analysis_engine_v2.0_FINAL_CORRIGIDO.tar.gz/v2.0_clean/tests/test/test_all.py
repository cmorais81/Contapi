#!/usr/bin/env python3.11
"""
Script de teste básico para validar funcionalidade do COBOL Analysis Engine
"""

import os
import sys
import tempfile
from pathlib import Path

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

def test_content_extractor():
    """Testa o extrator de conteúdo."""
    print("🔍 Testando COBOLContentExtractor...")
    
    try:
        from extractors.content_extractor import COBOLContentExtractor
        
        extractor = COBOLContentExtractor()
        
        # Teste com conteúdo simples
        test_content = """
        IDENTIFICATION DIVISION.
        PROGRAM-ID. TESTE.
        AUTHOR. SISTEMA.
        
        ENVIRONMENT DIVISION.
        
        DATA DIVISION.
        WORKING-STORAGE SECTION.
        01 WS-CONTADOR PIC 9(03) VALUE ZEROS.
        
        PROCEDURE DIVISION.
        INICIO.
            DISPLAY 'HELLO WORLD'.
            STOP RUN.
        """
        
        result = extractor.extract_from_content(test_content, "TESTE")
        
        assert result['program_name'] == "TESTE"
        assert 'divisions' in result
        assert 'metadata' in result
        
        print("✅ COBOLContentExtractor funcionando")
        return True
        
    except Exception as e:
        print(f"❌ Erro no COBOLContentExtractor: {e}")
        return False

def test_report_generator():
    """Testa o gerador de relatórios."""
    print("📄 Testando DetailedReportGenerator...")
    
    try:
        from generators.detailed_report_generator import DetailedReportGenerator
        
        generator = DetailedReportGenerator()
        
        # Dados de teste
        test_data = {
            'program_name': 'TESTE',
            'author': 'SISTEMA',
            'date_written': '01/01/2025'
        }
        
        test_analysis = {
            'structural': {
                'content': 'Análise estrutural de teste',
                'confidence': 0.8
            }
        }
        
        report = generator.generate(test_data, test_analysis)
        
        assert 'TESTE' in report
        assert 'Análise Detalhada' in report
        
        print("✅ DetailedReportGenerator funcionando")
        return True
        
    except Exception as e:
        print(f"❌ Erro no DetailedReportGenerator: {e}")
        return False

def test_config_loader():
    """Testa o carregador de configuração."""
    print("⚙️ Testando ConfigLoader...")
    
    try:
        from config.config_loader import load_config
        
        config = load_config('config/config.yaml')
        
        assert isinstance(config, dict)
        assert 'ai' in config
        
        print("✅ ConfigLoader funcionando")
        return True
        
    except Exception as e:
        print(f"❌ Erro no ConfigLoader: {e}")
        return False

def test_enhanced_logger():
    """Testa o logger aprimorado."""
    print("📝 Testando EnhancedAnalysisLogger...")
    
    try:
        from utils.enhanced_logger import EnhancedAnalysisLogger
        
        config = {'logging': {'level': 'INFO'}}
        logger = EnhancedAnalysisLogger(config)
        
        logger.start_analysis("TESTE", "test")
        logger.finish_analysis(True)
        
        print("✅ EnhancedAnalysisLogger funcionando")
        return True
        
    except Exception as e:
        print(f"❌ Erro no EnhancedAnalysisLogger: {e}")
        return False

def test_cli_help():
    """Testa se a CLI responde ao --help."""
    print("💻 Testando CLI...")
    
    try:
        import subprocess
        result = subprocess.run([
            sys.executable, 'main.py', '--help'
        ], capture_output=True, text=True, timeout=10)
        
        if result.returncode == 0 and 'COBOL Analysis Engine' in result.stdout:
            print("✅ CLI funcionando")
            return True
        else:
            print(f"❌ CLI falhou: {result.stderr}")
            return False
            
    except Exception as e:
        print(f"❌ Erro na CLI: {e}")
        return False

def create_test_cobol_file():
    """Cria um arquivo COBOL de teste."""
    test_content = """       IDENTIFICATION DIVISION.
       PROGRAM-ID. TESTE-BASICO.
       AUTHOR. SISTEMA-TESTE.
       DATE-WRITTEN. 01/01/2025.
       
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SPECIAL-NAMES.
           DECIMAL-POINT IS COMMA.
       
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01 WS-CONTADOR          PIC 9(03) VALUE ZEROS.
       01 WS-MENSAGEM          PIC X(30) VALUE 'TESTE FUNCIONANDO'.
       
       PROCEDURE DIVISION.
       INICIO.
           DISPLAY WS-MENSAGEM.
           ADD 1 TO WS-CONTADOR.
           IF WS-CONTADOR > 0
               DISPLAY 'CONTADOR: ' WS-CONTADOR
           END-IF.
           STOP RUN.
"""
    
    test_file = Path('test_programa.cbl')
    with open(test_file, 'w', encoding='utf-8') as f:
        f.write(test_content)
    
    return test_file

def test_full_analysis():
    """Testa uma análise completa simples."""
    print("🎯 Testando análise completa...")
    
    try:
        # Criar arquivo de teste
        test_file = create_test_cobol_file()
        
        # Criar diretório de saída temporário
        with tempfile.TemporaryDirectory() as temp_dir:
            # Executar análise
            import subprocess
            result = subprocess.run([
                sys.executable, 'main.py', 
                str(test_file), 
                '-o', temp_dir,
                '-m', 'traditional'
            ], capture_output=True, text=True, timeout=30)
            
            # Verificar se gerou relatório
            output_files = list(Path(temp_dir).glob('*.md'))
            
            if output_files and result.returncode == 0:
                print("✅ Análise completa funcionando")
                success = True
            else:
                print(f"❌ Análise completa falhou: {result.stderr}")
                success = False
        
        # Limpar arquivo de teste
        test_file.unlink()
        return success
        
    except Exception as e:
        print(f"❌ Erro na análise completa: {e}")
        return False

def main():
    """Executa todos os testes."""
    print("🚀 Iniciando testes do COBOL Analysis Engine v1.0\n")
    
    tests = [
        test_config_loader,
        test_content_extractor,
        test_report_generator,
        test_enhanced_logger,
        test_cli_help,
        test_full_analysis
    ]
    
    results = []
    
    for test in tests:
        try:
            result = test()
            results.append(result)
        except Exception as e:
            print(f"❌ Erro inesperado no teste {test.__name__}: {e}")
            results.append(False)
        print()
    
    # Resumo
    passed = sum(results)
    total = len(results)
    
    print("="*60)
    print(f"📊 RESUMO DOS TESTES")
    print(f"✅ Passou: {passed}/{total}")
    print(f"❌ Falhou: {total - passed}/{total}")
    print(f"📈 Taxa de Sucesso: {passed/total*100:.1f}%")
    
    if passed == total:
        print("\n🎉 Todos os testes passaram! Sistema funcionando corretamente.")
        return 0
    else:
        print(f"\n⚠️ {total - passed} teste(s) falharam. Verificar configuração.")
        return 1

if __name__ == "__main__":
    sys.exit(main())
