# COBOL to Docs v1.0 - Sistema Completo de Análise COBOL

Sistema avançado de análise e documentação de programas COBOL com tecnologias de ponta.

## Características Principais

### Tecnologias Avançadas
- **RAG (Retrieval-Augmented Generation)**: Sistema de recuperação e geração aumentada
- **Aprendizado Automático**: Base de conhecimento que evolui com cada análise
- **Múltiplos Providers**: Enhanced Mock, LuzIA (Santander), GitHub Copilot
- **Análise Profissional Sênior**: Baseada em feedback de especialistas COBOL

### Funcionalidades
- Análise individual e em lote de programas COBOL
- Geração automática de documentação técnica
- Sistema de auditoria completo (JSONs de rastreabilidade)
- Interface CLI e biblioteca Python
- Notebook Jupyter para demonstração
- Configuração flexível via YAML

## Estrutura do Projeto

```
cobol_to_docs_v1.0_COMPLETE/
├── config/
│   └── config.yaml                 # Configuração completa do sistema
├── src/
│   ├── core/                       # Componentes principais
│   │   ├── ai_response.py          # Classe de resposta
│   │   ├── analysis_request.py     # Classe de requisição
│   │   ├── config.py               # Gerenciador de configuração
│   │   └── prompt_manager.py       # Gerenciador de prompts
│   ├── parsers/                    # Parsers COBOL
│   │   └── cobol_parser_original.py
│   ├── analyzers/                  # Analisadores
│   │   └── enhanced_cobol_analyzer.py
│   ├── providers/                  # Providers de IA
│   │   ├── base_provider.py
│   │   ├── enhanced_mock_provider.py
│   │   ├── luzia_provider.py
│   │   └── github_copilot_provider.py
│   ├── generators/                 # Geradores de documentação
│   │   └── documentation_generator.py
│   ├── rag/                        # Sistema RAG
│   │   ├── advanced_rag_engine.py
│   │   └── learning_system.py
│   ├── knowledge/                  # Base de conhecimento
│   │   └── knowledge_manager.py
│   ├── client/                     # Clientes
│   │   ├── cli_client.py
│   │   └── api_client.py
│   └── library/                    # Biblioteca principal
│       └── cobol_analysis_lib.py
├── data/
│   ├── prompts/                    # Templates de prompts
│   │   ├── expert_analysis.yaml
│   │   ├── rag_enhanced.yaml
│   │   ├── comprehensive.yaml
│   │   └── basic_patterns.yaml
│   └── knowledge_base/             # Base de conhecimento RAG
├── examples/                       # Arquivos de exemplo
├── notebooks/                      # Notebooks Jupyter
│   └── COBOL_to_Docs_v1.0_Exemplo.ipynb
├── output/                         # Saída padrão
├── logs/                           # Logs do sistema
├── tests/                          # Testes
├── docs/                           # Documentação
├── main.py                         # Aplicação principal
└── README.md                       # Este arquivo
```

## Instalação e Configuração

### Pré-requisitos
- Python 3.11+
- Dependências: `pyyaml`, `requests`, `scikit-learn` (opcional para RAG)

### Instalação
```bash
# Clonar ou extrair o projeto
cd cobol_to_docs_v1.0_COMPLETE

# Instalar dependências (opcional)
pip install pyyaml requests scikit-learn pandas matplotlib seaborn jupyter

# Configurar variáveis de ambiente (se usar LuzIA)
export LUZIA_CLIENT_ID="seu_client_id"
export LUZIA_CLIENT_SECRET="seu_client_secret"
```

### Configuração
Edite `config/config.yaml` para personalizar:
- Providers habilitados
- Configurações de RAG
- Parâmetros de aprendizado
- Configurações de logging

## Uso

### Análise Individual
```bash
# Análise básica
python main.py examples/programa.cbl

# Com modelo específico
python main.py examples/programa.cbl --model luzia

# Com estratégia específica
python main.py examples/programa.cbl --strategy comprehensive

# Modo verboso
python main.py examples/programa.cbl --verbose
```

### Análise em Lote
```bash
# Múltiplos arquivos
python main.py examples/*.cbl

# Com saída personalizada
python main.py examples/*.cbl --output ./relatorios
```

### Via CLI
```bash
# Análise individual
python -m src.client.cli_client analyze programa.cbl

# Análise em lote
python -m src.client.cli_client batch *.cbl

# Status do sistema
python -m src.client.cli_client status

# Estatísticas
python -m src.client.cli_client stats
```

### Via Biblioteca Python
```python
from src.library.cobol_analysis_lib import COBOLAnalysisLibrary

# Inicializar
library = COBOLAnalysisLibrary()

# Analisar arquivo
result = library.analyze_file("programa.cbl")

# Analisar conteúdo
result = library.analyze_content(cobol_code, "PROGRAMA")

# Análise em lote
results = library.batch_analyze(["prog1.cbl", "prog2.cbl"])
```

### Notebook Jupyter
```bash
jupyter notebook notebooks/COBOL_to_Docs_v1.0_Exemplo.ipynb
```

## Providers Disponíveis

### Enhanced Mock Provider
- **Descrição**: Provider para análises profissionais com RAG
- **Características**: Análise sênior, aprendizado automático, padrões CADOC
- **Uso**: Padrão para desenvolvimento e testes

### LuzIA Provider (Santander)
- **Descrição**: Integração com ambiente Santander
- **Modelos**: AWS Claude 3.5 Sonnet, Haiku, Amazon Nova Pro
- **Configuração**: Requer credenciais corporativas

### GitHub Copilot Provider
- **Descrição**: Integração com GitHub Copilot
- **Características**: Análise de código, chat interface
- **Configuração**: Requer API key do GitHub

## Estratégias de Análise

### Expert Analysis
- Análise técnica sênior baseada em feedback de especialistas
- Foco em funcionalidades específicas e regras de negócio
- Evidências concretas com números de linha

### RAG Enhanced
- Análise aprimorada com conhecimento da base RAG
- Identificação de padrões conhecidos
- Correlação com exemplos similares

### Comprehensive
- Análise abrangente cobrindo todos os aspectos
- Funcional, técnico, negócio, qualidade e risco
- Documentação técnica completa

### Basic Patterns
- Análise focada em padrões básicos
- Identificação rápida de estruturas
- Ideal para análises preliminares

## Sistema RAG

### Funcionalidades
- **Recuperação Semântica**: Busca por similaridade de conteúdo
- **Aprendizado Automático**: Descoberta de novos padrões
- **Base Evolutiva**: Conhecimento que cresce com uso
- **Correlação Inteligente**: Relaciona código com análises

### Base de Conhecimento
- Padrões COBOL conhecidos
- Regras de negócio validadas
- Exemplos de análises bem-sucedidas
- Conhecimento específico CADOC e bancário

## Saídas Geradas

### Relatórios Markdown
- Análise funcional detalhada
- Informações técnicas e de processamento
- Metadados e estatísticas

### JSONs de Auditoria
- `ai_responses/`: Respostas completas da IA
- `ai_requests/`: Requisições enviadas
- `statistics/`: Estatísticas detalhadas

### Relatórios Adicionais
- Relatório resumo de análises em lote
- Estatísticas de performance
- Métricas de qualidade

## Monitoramento e Logs

### Logs do Sistema
- Arquivo: `logs/cobol_to_docs.log`
- Níveis: DEBUG, INFO, WARNING, ERROR
- Rotação automática

### Métricas Disponíveis
- Programas analisados
- Taxa de sucesso
- Tokens utilizados
- Tempo de processamento
- Estatísticas RAG
- Progresso do aprendizado

## Desenvolvimento e Extensão

### Adicionando Novos Providers
1. Herdar de `BaseProvider`
2. Implementar métodos obrigatórios
3. Registrar na configuração
4. Testar integração

### Personalizando Prompts
1. Criar template YAML em `data/prompts/`
2. Definir system_prompt e user_prompt_template
3. Configurar parâmetros
4. Registrar estratégia

### Expandindo Base de Conhecimento
1. Adicionar padrões em `data/knowledge_base/`
2. Implementar lógica de descoberta
3. Configurar métricas de qualidade
4. Testar aprendizado

## Troubleshooting

### Problemas Comuns

**Erro de importação**
```bash
# Verificar estrutura de diretórios
python -c "import sys; print(sys.path)"
```

**Provider indisponível**
```bash
# Verificar configuração
python -m src.client.cli_client status
```

**Falha na análise**
```bash
# Modo verboso para debug
python main.py arquivo.cbl --verbose
```

### Logs e Debug
- Verificar `logs/cobol_to_docs.log`
- Usar modo `--verbose` para detalhes
- Verificar JSONs de auditoria

## Contribuição

### Estrutura de Desenvolvimento
- Seguir princípios SOLID
- Documentar mudanças
- Testar funcionalidades
- Manter compatibilidade

### Roadmap
- [ ] Integração com APIs reais
- [ ] Interface web
- [ ] Métricas avançadas
- [ ] Suporte a mais linguagens
- [ ] Integração CI/CD

## Licença

Sistema proprietário - Uso interno autorizado.

## Suporte

Para suporte técnico:
- Verificar documentação em `docs/`
- Consultar logs em `logs/`
- Usar notebook de exemplo
- Contatar equipe de desenvolvimento

---

**COBOL to Docs v1.0** - Sistema Avançado de Análise COBOL com RAG e Aprendizado Automático
