#!/usr/bin/env python3
"""
COBOL to Docs v1.0 - Sistema Principal
Sistema limpo e organizado para análise de programas COBOL
"""

import os
import sys
import argparse
import logging
from datetime import datetime
from typing import List, Optional

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

# Imports do sistema
from src.core.config import load_config
from src.parsers.cobol_parser_original import COBOLParser
from src.analyzers.enhanced_cobol_analyzer import EnhancedCOBOLAnalyzer
from src.generators.documentation_generator import DocumentationGenerator

def setup_logging():
    """Configura logging do sistema"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    return logging.getLogger(__name__)

def parse_arguments():
    """Parse dos argumentos da linha de comando"""
    parser = argparse.ArgumentParser(description='COBOL to Docs v1.0 - Análise de Programas COBOL')
    
    parser.add_argument('--fontes', required=True, help='Arquivo com programas COBOL')
    parser.add_argument('--books', help='Arquivo com copybooks')
    parser.add_argument('--models', default='enhanced_mock', help='Modelo a usar (luzia, enhanced_mock)')
    parser.add_argument('--output', default='output', help='Diretório de saída')
    parser.add_argument('--config', default='config/config.yaml', help='Arquivo de configuração')
    
    return parser.parse_args()

def main():
    """Função principal"""
    logger = setup_logging()
    
    try:
        # Parse dos argumentos
        args = parse_arguments()
        
        logger.info("=== COBOL to Docs v1.0 - Iniciando ===")
        logger.info(f"Fontes: {args.fontes}")
        logger.info(f"Books: {args.books}")
        logger.info(f"Modelo: {args.models}")
        logger.info(f"Output: {args.output}")
        
        # Carregar configuração
        config = load_config(args.config)
        
        # Criar diretório de saída
        os.makedirs(args.output, exist_ok=True)
        
        # Parse dos arquivos COBOL
        parser = COBOLParser()
        programs, books = parser.parse_file(args.fontes)
        
        # Parse dos copybooks se fornecido
        if args.books and os.path.exists(args.books):
            _, additional_books = parser.parse_file(args.books)
            books.extend(additional_books)
        
        logger.info(f"Programas encontrados: {len(programs)}")
        logger.info(f"Copybooks encontrados: {len(books)}")
        
        if not programs:
            logger.error("Nenhum programa COBOL encontrado")
            return 1
        
        # Inicializar componentes
        analyzer = EnhancedCOBOLAnalyzer(config)
        doc_generator = DocumentationGenerator(args.output)
        
        # Processar cada programa
        for program in programs:
            logger.info(f"Processando programa: {program.name}")
            
            try:
                # Análise do programa
                analysis_result = analyzer.analyze_program_enhanced(
                    program=program,
                    copybooks=books,
                    model=args.models
                )
                
                if analysis_result:
                    # Gerar documentação
                    doc_file = doc_generator.generate_program_documentation(
                        program=program,
                        ai_response=analysis_result
                    )
                    
                    if doc_file:
                        logger.info(f"✅ Documentação gerada: {doc_file}")
                    else:
                        logger.error(f"❌ Falha ao gerar documentação para {program.name}")
                else:
                    logger.error(f"❌ Falha na análise de {program.name}")
                    
            except Exception as e:
                logger.error(f"Erro ao processar {program.name}: {e}")
                continue
        
        logger.info("=== Processamento concluído ===")
        return 0
        
    except Exception as e:
        logger.error(f"Erro no sistema: {e}")
        import traceback
        traceback.print_exc()
        return 1

if __name__ == "__main__":
    sys.exit(main())
