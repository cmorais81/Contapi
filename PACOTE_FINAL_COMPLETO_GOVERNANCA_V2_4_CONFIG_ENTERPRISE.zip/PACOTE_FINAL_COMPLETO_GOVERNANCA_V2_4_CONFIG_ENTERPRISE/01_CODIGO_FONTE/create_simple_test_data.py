#!/usr/bin/env python3
"""
Script simplificado para carregar dados de teste na aplicação de governança
Baseado na estrutura real das tabelas
"""
import os
import sys
import psycopg2
from datetime import datetime
import uuid

# Configuração do banco
DB_CONFIG = {
    'host': 'localhost',
    'port': 5432,
    'database': 'governanca_dados',
    'user': 'postgres',
    'password': 'postgres'
}

def get_db_connection():
    """Conecta ao banco de dados"""
    try:
        conn = psycopg2.connect(**DB_CONFIG)
        return conn
    except Exception as e:
        print(f"Erro ao conectar ao banco: {e}")
        return None

def create_simple_test_data():
    """Cria dados de teste simples para demonstração"""
    conn = get_db_connection()
    if not conn:
        return False
    
    try:
        cursor = conn.cursor()
        
        # 1. Criar usuários de teste
        print("Criando usuários de teste...")
        users_data = [
            ('admin@santander.com.br', 'Admin Sistema', True, True),
            ('ana.silva@santander.com.br', 'Ana Silva - Data Steward', True, False),
            ('pedro.santos@santander.com.br', 'Pedro Santos - Data Analyst', True, False),
            ('maria.costa@santander.com.br', 'Maria Costa - Compliance Officer', True, False),
            ('carlos.morais@f1rst.com.br', 'Carlos Morais - Data Engineer', True, False)
        ]
        
        user_ids = {}
        for email, full_name, is_active, is_superuser in users_data:
            user_id = str(uuid.uuid4())
            user_ids[email] = user_id
            password_hash = '$2b$12$dummy.hash.for.testing.only'
            cursor.execute("""
                INSERT INTO users (id, email, password_hash, full_name, is_active, is_superuser, created_at, updated_at)
                VALUES (%s, %s, %s, %s, %s, %s, NOW(), NOW())
                ON CONFLICT (email) DO UPDATE SET
                full_name = EXCLUDED.full_name,
                is_active = EXCLUDED.is_active,
                updated_at = NOW()
            """, (user_id, email, password_hash, full_name, is_active, is_superuser))
        
        # 2. Criar entidades de teste
        print("Criando entidades de teste...")
        entities_data = [
            ('customers', 'table', 'Tabela de clientes pessoa física', 'santander_db', 'customer_schema', 'customers', 'santander_db.customer_schema.customers'),
            ('transactions', 'table', 'Transações financeiras do banco', 'santander_db', 'transaction_schema', 'transactions', 'santander_db.transaction_schema.transactions'),
            ('products', 'table', 'Produtos bancários disponíveis', 'santander_db', 'product_schema', 'products', 'santander_db.product_schema.products'),
            ('accounts', 'table', 'Contas bancárias dos clientes', 'santander_db', 'account_schema', 'accounts', 'santander_db.account_schema.accounts'),
            ('customer_360', 'view', 'Visão 360 graus do cliente', 'santander_db', 'analytics_schema', 'customer_360', 'santander_db.analytics_schema.customer_360')
        ]
        
        entity_ids = {}
        for name, entity_type, description, database_name, schema_name, table_name, full_path in entities_data:
            entity_id = str(uuid.uuid4())
            entity_ids[name] = entity_id
            owner_id = user_ids.get('ana.silva@santander.com.br')  # Ana Silva como owner padrão
            cursor.execute("""
                INSERT INTO entities (id, name, entity_type, description, owner_id, database_name, schema_name, table_name, full_path, is_active, created_at, updated_at)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, NOW(), NOW())
                ON CONFLICT DO NOTHING
            """, (entity_id, name, entity_type, description, owner_id, database_name, schema_name, table_name, full_path, True))
        
        # 3. Inserir dados de configuração do sistema
        print("Configurando sistema...")
        cursor.execute("""
            INSERT INTO system_configurations (config_key, config_value, description, created_at, updated_at)
            VALUES 
            ('sync_interval_minutes', '20', 'Intervalo de sincronização em minutos', NOW(), NOW()),
            ('unity_catalog_enabled', 'true', 'Unity Catalog habilitado', NOW(), NOW()),
            ('axon_enabled', 'true', 'Informatica Axon habilitado', NOW(), NOW()),
            ('datahub_enabled', 'true', 'DataHub habilitado', NOW(), NOW()),
            ('quality_monitoring_enabled', 'true', 'Monitoramento de qualidade habilitado', NOW(), NOW())
            ON CONFLICT (config_key) DO UPDATE SET
            config_value = EXCLUDED.config_value,
            updated_at = NOW()
        """)
        
        # Commit das transações
        conn.commit()
        print("✓ Dados de teste criados com sucesso!")
        
        # Verificar dados criados
        cursor.execute("SELECT COUNT(*) FROM users")
        users_count = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM entities")
        entities_count = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM system_configurations")
        configs_count = cursor.fetchone()[0]
        
        print(f"✓ Usuários: {users_count}")
        print(f"✓ Entidades: {entities_count}")
        print(f"✓ Configurações: {configs_count}")
        
        # Mostrar dados criados
        print("\n=== DADOS CRIADOS ===")
        cursor.execute("SELECT email, full_name FROM users ORDER BY full_name")
        users = cursor.fetchall()
        print("Usuários:")
        for email, name in users:
            print(f"  - {name} ({email})")
        
        cursor.execute("SELECT name, entity_type, description FROM entities ORDER BY name")
        entities = cursor.fetchall()
        print("\nEntidades:")
        for name, entity_type, description in entities:
            print(f"  - {name} ({entity_type}): {description}")
        
        return True
        
    except Exception as e:
        print(f"Erro ao criar dados de teste: {e}")
        conn.rollback()
        return False
    finally:
        cursor.close()
        conn.close()

if __name__ == "__main__":
    print("=== Carregando Dados de Teste Simplificados ===")
    success = create_simple_test_data()
    if success:
        print("\n=== Dados de teste carregados com sucesso! ===")
        print("Agora você pode iniciar a aplicação com: uvicorn src.main:app --host 0.0.0.0 --port 8000")
        sys.exit(0)
    else:
        print("=== Erro ao carregar dados de teste ===")
        sys.exit(1)

