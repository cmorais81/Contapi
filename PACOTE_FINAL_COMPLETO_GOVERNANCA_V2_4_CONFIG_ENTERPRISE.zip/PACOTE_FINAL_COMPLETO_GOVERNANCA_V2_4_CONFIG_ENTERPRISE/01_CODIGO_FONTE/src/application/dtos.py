"""
Data Transfer Objects (DTOs) para a camada de aplicação
"""

from datetime import datetime
from typing import Any, Dict, List, Optional
from uuid import UUID

from pydantic import BaseModel, Field, validator


class BaseDTO(BaseModel):
    """DTO base com configurações comuns"""
    
    class Config:
        from_attributes = True
        use_enum_values = True
        validate_assignment = True


# ========================================
# USER DTOs
# ========================================

class UserCreateDTO(BaseDTO):
    """DTO para criação de usuário"""
    
    username: str = Field(..., min_length=3, max_length=100)
    email: str = Field(..., pattern=r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
    full_name: Optional[str] = Field(None, max_length=255)
    password: str = Field(..., min_length=8)
    is_active: bool = Field(default=True)
    is_superuser: bool = Field(default=False)


class UserUpdateDTO(BaseDTO):
    """DTO para atualização de usuário"""
    
    username: Optional[str] = Field(None, min_length=3, max_length=100)
    email: Optional[str] = Field(None, pattern=r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
    full_name: Optional[str] = Field(None, max_length=255)
    is_active: Optional[bool] = None
    is_superuser: Optional[bool] = None


class UserResponseDTO(BaseDTO):
    """DTO para resposta de usuário"""
    
    id: UUID
    username: str
    email: str
    full_name: Optional[str]
    is_active: bool
    is_superuser: bool
    last_login: Optional[datetime]
    created_at: datetime
    updated_at: datetime


# ========================================
# DOMAIN DTOs
# ========================================

class DomainCreateDTO(BaseDTO):
    """DTO para criação de domínio"""
    
    name: str = Field(..., min_length=1, max_length=255)
    description: Optional[str] = None
    parent_domain_id: Optional[UUID] = None
    steward_id: Optional[UUID] = None
    metadata: Optional[Dict[str, Any]] = None


class DomainUpdateDTO(BaseDTO):
    """DTO para atualização de domínio"""
    
    name: Optional[str] = Field(None, min_length=1, max_length=255)
    description: Optional[str] = None
    parent_domain_id: Optional[UUID] = None
    steward_id: Optional[UUID] = None
    metadata: Optional[Dict[str, Any]] = None


class DomainResponseDTO(BaseDTO):
    """DTO para resposta de domínio"""
    
    id: UUID
    name: str
    description: Optional[str]
    parent_domain_id: Optional[UUID]
    steward_id: Optional[UUID]
    metadata: Optional[Dict[str, Any]]
    created_at: datetime
    updated_at: datetime


# ========================================
# DATA CONTRACT DTOs
# ========================================

class DataContractCreateDTO(BaseDTO):
    """DTO para criação de contrato de dados"""
    
    name: str = Field(..., min_length=1, max_length=255)
    description: Optional[str] = None
    domain_id: Optional[UUID] = None
    steward_id: Optional[UUID] = None
    unity_catalog_path: Optional[str] = Field(None, max_length=500)
    
    @validator('unity_catalog_path')
    def validate_unity_catalog_path(cls, v):
        if v and len(v.split('.')) != 3:
            raise ValueError('Unity Catalog path deve ter formato catalog.schema.table')
        return v


class DataContractUpdateDTO(BaseDTO):
    """DTO para atualização de contrato de dados"""
    
    name: Optional[str] = Field(None, min_length=1, max_length=255)
    description: Optional[str] = None
    domain_id: Optional[UUID] = None
    steward_id: Optional[UUID] = None
    status: Optional[str] = Field(None, pattern=r'^(draft|active|deprecated|archived)$')
    unity_catalog_path: Optional[str] = Field(None, max_length=500)


class DataContractResponseDTO(BaseDTO):
    """DTO para resposta de contrato de dados"""
    
    id: UUID
    name: str
    description: Optional[str]
    domain_id: Optional[UUID]
    steward_id: Optional[UUID]
    status: str
    current_version_id: Optional[UUID]
    unity_catalog_path: Optional[str]
    created_at: datetime
    updated_at: datetime
    created_by: Optional[UUID]
    updated_by: Optional[UUID]


class DataContractVersionCreateDTO(BaseDTO):
    """DTO para criação de versão de contrato"""
    
    version: str = Field(..., pattern=r'^\d+\.\d+\.\d+(-[a-zA-Z0-9\-\.]+)?$')
    description: Optional[str] = None
    schema_definition: Dict[str, Any] = Field(..., min_items=1)
    quality_rules: Optional[Dict[str, Any]] = None
    sla_definition: Optional[Dict[str, Any]] = None
    terms_and_conditions: Optional[str] = None
    
    @validator('schema_definition')
    def validate_schema_definition(cls, v):
        required_fields = ['type', 'properties']
        for field in required_fields:
            if field not in v:
                raise ValueError(f'Campo obrigatório no schema: {field}')
        return v


class DataContractVersionResponseDTO(BaseDTO):
    """DTO para resposta de versão de contrato"""
    
    id: UUID
    contract_id: UUID
    version: str
    description: Optional[str]
    schema_definition: Dict[str, Any]
    quality_rules: Optional[Dict[str, Any]]
    sla_definition: Optional[Dict[str, Any]]
    terms_and_conditions: Optional[str]
    is_active: bool
    odcs_export: Optional[Dict[str, Any]]
    created_at: datetime
    created_by: Optional[UUID]


# ========================================
# ENTITY DTOs
# ========================================

class EntityCreateDTO(BaseDTO):
    """DTO para criação de entidade"""
    
    name: str = Field(..., min_length=1, max_length=255)
    type: str = Field(..., pattern=r'^(table|view|dataset|stream|file)$')
    description: Optional[str] = None
    domain_id: Optional[UUID] = None
    steward_id: Optional[UUID] = None
    unity_catalog_path: Optional[str] = Field(None, max_length=500)
    schema_definition: Optional[Dict[str, Any]] = None
    business_glossary_id: Optional[UUID] = None
    classification: str = Field(default="internal", pattern=r'^(public|internal|confidential|restricted)$')


class EntityUpdateDTO(BaseDTO):
    """DTO para atualização de entidade"""
    
    name: Optional[str] = Field(None, min_length=1, max_length=255)
    type: Optional[str] = Field(None, pattern=r'^(table|view|dataset|stream|file)$')
    description: Optional[str] = None
    domain_id: Optional[UUID] = None
    steward_id: Optional[UUID] = None
    unity_catalog_path: Optional[str] = Field(None, max_length=500)
    schema_definition: Optional[Dict[str, Any]] = None
    business_glossary_id: Optional[UUID] = None
    classification: Optional[str] = Field(None, pattern=r'^(public|internal|confidential|restricted)$')


class EntityResponseDTO(BaseDTO):
    """DTO para resposta de entidade"""
    
    id: UUID
    name: str
    type: str
    description: Optional[str]
    domain_id: Optional[UUID]
    steward_id: Optional[UUID]
    unity_catalog_path: Optional[str]
    schema_definition: Optional[Dict[str, Any]]
    business_glossary_id: Optional[UUID]
    classification: str
    created_at: datetime
    updated_at: datetime
    created_by: Optional[UUID]
    updated_by: Optional[UUID]


class EntityAttributeCreateDTO(BaseDTO):
    """DTO para criação de atributo de entidade"""
    
    name: str = Field(..., min_length=1, max_length=255)
    data_type: str = Field(..., min_length=1, max_length=100)
    description: Optional[str] = None
    is_nullable: bool = Field(default=True)
    is_primary_key: bool = Field(default=False)
    is_foreign_key: bool = Field(default=False)
    business_term_id: Optional[UUID] = None
    classification: Optional[str] = Field(None, pattern=r'^(public|internal|confidential|restricted)$')
    masking_policy_id: Optional[UUID] = None
    
    @validator('is_nullable')
    def validate_nullable_primary_key(cls, v, values):
        if values.get('is_primary_key') and v:
            raise ValueError('Chave primária não pode ser nullable')
        return v


class EntityAttributeResponseDTO(BaseDTO):
    """DTO para resposta de atributo de entidade"""
    
    id: UUID
    entity_id: UUID
    name: str
    data_type: str
    description: Optional[str]
    is_nullable: bool
    is_primary_key: bool
    is_foreign_key: bool
    business_term_id: Optional[UUID]
    classification: Optional[str]
    masking_policy_id: Optional[UUID]
    created_at: datetime
    updated_at: datetime


# ========================================
# QUALITY DTOs
# ========================================

class QualityRuleCreateDTO(BaseDTO):
    """DTO para criação de regra de qualidade"""
    
    name: str = Field(..., min_length=1, max_length=255)
    description: Optional[str] = None
    entity_id: UUID
    attribute_id: Optional[UUID] = None
    dimension_id: UUID
    rule_type: str = Field(..., pattern=r'^(completeness|accuracy|consistency|validity|uniqueness|timeliness|integrity)$')
    rule_definition: Dict[str, Any] = Field(..., min_items=1)
    threshold_warning: Optional[float] = Field(None, ge=0, le=100)
    threshold_critical: Optional[float] = Field(None, ge=0, le=100)
    is_active: bool = Field(default=True)
    
    @validator('threshold_critical')
    def validate_thresholds(cls, v, values):
        warning = values.get('threshold_warning')
        if v is not None and warning is not None and v >= warning:
            raise ValueError('Threshold crítico deve ser menor que warning')
        return v


class QualityRuleUpdateDTO(BaseDTO):
    """DTO para atualização de regra de qualidade"""
    
    name: Optional[str] = Field(None, min_length=1, max_length=255)
    description: Optional[str] = None
    rule_definition: Optional[Dict[str, Any]] = None
    threshold_warning: Optional[float] = Field(None, ge=0, le=100)
    threshold_critical: Optional[float] = Field(None, ge=0, le=100)
    is_active: Optional[bool] = None


class QualityRuleResponseDTO(BaseDTO):
    """DTO para resposta de regra de qualidade"""
    
    id: UUID
    name: str
    description: Optional[str]
    entity_id: UUID
    attribute_id: Optional[UUID]
    dimension_id: UUID
    rule_type: str
    rule_definition: Dict[str, Any]
    threshold_warning: Optional[float]
    threshold_critical: Optional[float]
    is_active: bool
    created_at: datetime
    updated_at: datetime
    created_by: Optional[UUID]
    updated_by: Optional[UUID]


class QualityMetricResponseDTO(BaseDTO):
    """DTO para resposta de métrica de qualidade"""
    
    id: UUID
    rule_id: UUID
    entity_id: UUID
    execution_date: datetime
    metric_value: float
    status: str
    details: Optional[Dict[str, Any]]
    execution_time_ms: Optional[int]
    created_at: datetime


class QualityIncidentCreateDTO(BaseDTO):
    """DTO para criação de incidente de qualidade"""
    
    rule_id: UUID
    entity_id: UUID
    metric_id: UUID
    severity: str = Field(..., pattern=r'^(low|medium|high|critical)$')
    title: str = Field(..., min_length=1, max_length=255)
    description: Optional[str] = None
    assigned_to: Optional[UUID] = None


class QualityIncidentUpdateDTO(BaseDTO):
    """DTO para atualização de incidente de qualidade"""
    
    status: Optional[str] = Field(None, pattern=r'^(open|investigating|resolved|closed)$')
    assigned_to: Optional[UUID] = None
    resolution_notes: Optional[str] = None


class QualityIncidentResponseDTO(BaseDTO):
    """DTO para resposta de incidente de qualidade"""
    
    id: UUID
    rule_id: UUID
    entity_id: UUID
    metric_id: UUID
    severity: str
    status: str
    title: str
    description: Optional[str]
    assigned_to: Optional[UUID]
    resolved_at: Optional[datetime]
    resolution_notes: Optional[str]
    created_at: datetime
    updated_at: datetime


# ========================================
# TAG DTOs
# ========================================

class TagCreateDTO(BaseDTO):
    """DTO para criação de tag"""
    
    name: str = Field(..., min_length=1, max_length=255)
    description: Optional[str] = None
    category: Optional[str] = Field(None, max_length=100)
    parent_tag_id: Optional[UUID] = None
    metadata: Optional[Dict[str, Any]] = None


class TagResponseDTO(BaseDTO):
    """DTO para resposta de tag"""
    
    id: UUID
    name: str
    description: Optional[str]
    category: Optional[str]
    parent_tag_id: Optional[UUID]
    metadata: Optional[Dict[str, Any]]
    created_at: datetime
    updated_at: datetime


# ========================================
# PAGINATION DTOs
# ========================================

class PaginationParams(BaseDTO):
    """Parâmetros de paginação"""
    
    page: int = Field(default=1, ge=1)
    size: int = Field(default=20, ge=1, le=100)
    order_by: Optional[str] = None
    
    @property
    def offset(self) -> int:
        return (self.page - 1) * self.size
    
    @property
    def limit(self) -> int:
        return self.size


class PaginatedResponse(BaseDTO):
    """Resposta paginada"""
    
    items: List[Any]
    total: int
    page: int
    size: int
    pages: int
    
    @validator('pages', pre=True, always=True)
    def calculate_pages(cls, v, values):
        total = values.get('total', 0)
        size = values.get('size', 1)
        return (total + size - 1) // size if total > 0 else 0


# ========================================
# SEARCH DTOs
# ========================================

class SearchParams(BaseDTO):
    """Parâmetros de busca"""
    
    query: str = Field(..., min_length=1)
    fields: Optional[List[str]] = None
    filters: Optional[Dict[str, Any]] = None
    
    class Config:
        json_schema_extra = {
            "example": {
                "query": "customer data",
                "fields": ["name", "description"],
                "filters": {"domain_id": "123e4567-e89b-12d3-a456-426614174000"}
            }
        }


# ========================================
# HEALTH CHECK DTOs
# ========================================

class HealthCheckResponseDTO(BaseDTO):
    """DTO para resposta de health check"""
    
    status: str = Field(..., pattern=r'^(healthy|degraded|unhealthy)$')
    timestamp: datetime
    version: str
    components: Dict[str, Dict[str, Any]]
    
    class Config:
        json_schema_extra = {
            "example": {
                "status": "healthy",
                "timestamp": "2025-01-07T10:00:00Z",
                "version": "1.0.0",
                "components": {
                    "database": {"status": "healthy", "response_time_ms": 15},
                    "redis": {"status": "healthy", "response_time_ms": 5}
                }
            }
        }


# ========================================
# ERROR DTOs
# ========================================

class ErrorResponseDTO(BaseDTO):
    """DTO para resposta de erro"""
    
    error: str
    message: str
    details: Optional[Dict[str, Any]] = None
    timestamp: datetime
    path: Optional[str] = None
    
    class Config:
        json_schema_extra = {
            "example": {
                "error": "ValidationError",
                "message": "Nome do contrato é obrigatório",
                "details": {"field": "name", "value": ""},
                "timestamp": "2025-01-07T10:00:00Z",
                "path": "/api/v1/contracts"
            }
        }

