"""
DTOs para Entidades do Catálogo
API de Governança de Dados V2.3
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from datetime import datetime
from typing import Any, Dict, List, Optional
from uuid import UUID

from pydantic import BaseModel, Field, ConfigDict


class EntityCreateDTO(BaseModel):
    """DTO para criação de entidade"""
    model_config = ConfigDict(
        json_json_schema_extra={
            "example": {
                "name": "customer_data",
                "description": "Dados de clientes",
                "entity_type": "table",
                "schema_name": "sales",
                "database_name": "production",
                "tags": ["pii", "customer"]
            }
        }
    )
    
    name: str = Field(..., description="Nome da entidade")
    description: Optional[str] = Field(None, description="Descrição da entidade")
    entity_type: str = Field(..., description="Tipo da entidade (table, view, etc.)")
    schema_name: Optional[str] = Field(None, description="Nome do schema")
    database_name: Optional[str] = Field(None, description="Nome do banco de dados")
    tags: Optional[List[str]] = Field(default_factory=list, description="Tags da entidade")
    metadata: Optional[Dict[str, Any]] = Field(default_factory=dict, description="Metadados adicionais")


class EntityUpdateDTO(BaseModel):
    """DTO para atualização de entidade"""
    model_config = ConfigDict(
        json_json_schema_extra={
            "example": {
                "description": "Dados atualizados de clientes",
                "tags": ["pii", "customer", "updated"]
            }
        }
    )
    
    description: Optional[str] = Field(None, description="Descrição da entidade")
    tags: Optional[List[str]] = Field(None, description="Tags da entidade")
    metadata: Optional[Dict[str, Any]] = Field(None, description="Metadados adicionais")


class EntityResponseDTO(BaseModel):
    """DTO para resposta de entidade"""
    model_config = ConfigDict(
        json_json_schema_extra={
            "example": {
                "id": "123e4567-e89b-12d3-a456-426614174000",
                "name": "customer_data",
                "description": "Dados de clientes",
                "entity_type": "table",
                "schema_name": "sales",
                "database_name": "production",
                "tags": ["pii", "customer"],
                "created_at": "2025-07-17T23:36:17Z",
                "updated_at": "2025-07-17T23:36:17Z"
            }
        }
    )
    
    id: UUID = Field(..., description="ID único da entidade")
    name: str = Field(..., description="Nome da entidade")
    description: Optional[str] = Field(None, description="Descrição da entidade")
    entity_type: str = Field(..., description="Tipo da entidade")
    schema_name: Optional[str] = Field(None, description="Nome do schema")
    database_name: Optional[str] = Field(None, description="Nome do banco de dados")
    tags: List[str] = Field(default_factory=list, description="Tags da entidade")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Metadados adicionais")
    created_at: datetime = Field(..., description="Data de criação")
    updated_at: datetime = Field(..., description="Data de atualização")


class EntitySearchDTO(BaseModel):
    """DTO para busca de entidades"""
    model_config = ConfigDict(
        json_json_schema_extra={
            "example": {
                "query": "customer",
                "entity_type": "table",
                "tags": ["pii"],
                "schema_name": "sales"
            }
        }
    )
    
    query: Optional[str] = Field(None, description="Termo de busca")
    entity_type: Optional[str] = Field(None, description="Filtro por tipo")
    tags: Optional[List[str]] = Field(None, description="Filtro por tags")
    schema_name: Optional[str] = Field(None, description="Filtro por schema")
    database_name: Optional[str] = Field(None, description="Filtro por banco")


class EntityStatsDTO(BaseModel):
    """DTO para estatísticas de entidades"""
    model_config = ConfigDict(
        json_json_schema_extra={
            "example": {
                "total_entities": 1250,
                "by_type": {"table": 800, "view": 350, "procedure": 100},
                "by_schema": {"sales": 400, "finance": 300, "hr": 200},
                "tagged_entities": 950,
                "untagged_entities": 300
            }
        }
    )
    
    total_entities: int = Field(..., description="Total de entidades")
    by_type: Dict[str, int] = Field(..., description="Entidades por tipo")
    by_schema: Dict[str, int] = Field(..., description="Entidades por schema")
    tagged_entities: int = Field(..., description="Entidades com tags")
    untagged_entities: int = Field(..., description="Entidades sem tags")


# Aliases para compatibilidade
EntityCreateRequest = EntityCreateDTO
EntityUpdateRequest = EntityUpdateDTO
EntityResponse = EntityResponseDTO
EntitySearchRequest = EntitySearchDTO
EntityStats = EntityStatsDTO

