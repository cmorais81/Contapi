"""
DTOs para Contratos de Dados
API de Governança de Dados V2.2
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from typing import Optional, List, Dict, Any
from datetime import datetime
from uuid import UUID
from pydantic import BaseModel, Field
from enum import Enum

from .common import BaseResponseDTO, PaginationParams


class ContractStatus(str, Enum):
    """Status do contrato"""
    DRAFT = "draft"
    ACTIVE = "active"
    INACTIVE = "inactive"
    DEPRECATED = "deprecated"


class ContractType(str, Enum):
    """Tipo do contrato"""
    API = "api"
    DATABASE = "database"
    FILE = "file"
    STREAM = "stream"


class DataContractCreateDTO(BaseModel):
    """DTO para criação de contrato de dados"""
    name: str = Field(..., description="Nome do contrato")
    description: Optional[str] = Field(None, description="Descrição do contrato")
    contract_type: ContractType = Field(..., description="Tipo do contrato")
    version: str = Field("1.0.0", description="Versão do contrato")
    schema_definition: Dict[str, Any] = Field(..., description="Definição do schema")
    quality_rules: Optional[List[Dict[str, Any]]] = Field(None, description="Regras de qualidade")
    sla_requirements: Optional[Dict[str, Any]] = Field(None, description="Requisitos de SLA")
    data_owner: Optional[str] = Field(None, description="Proprietário dos dados")
    steward: Optional[str] = Field(None, description="Steward responsável")
    tags: Optional[List[str]] = Field(None, description="Tags do contrato")
    metadata: Optional[Dict[str, Any]] = Field(None, description="Metadados adicionais")

    class Config:
        json_json_schema_extra = {
            "example": {
                "name": "Customer Data Contract",
                "description": "Contrato para dados de clientes",
                "contract_type": "database",
                "version": "1.0.0",
                "schema_definition": {
                    "type": "object",
                    "properties": {
                        "customer_id": {"type": "string"},
                        "name": {"type": "string"},
                        "email": {"type": "string"}
                    }
                },
                "quality_rules": [
                    {"field": "email", "rule": "email_format"}
                ],
                "data_owner": "carlos.morais@f1rst.com.br",
                "steward": "Data Team"
            }
        }


class DataContractUpdateDTO(BaseModel):
    """DTO para atualização de contrato de dados"""
    name: Optional[str] = Field(None, description="Nome do contrato")
    description: Optional[str] = Field(None, description="Descrição do contrato")
    contract_type: Optional[ContractType] = Field(None, description="Tipo do contrato")
    schema_definition: Optional[Dict[str, Any]] = Field(None, description="Definição do schema")
    quality_rules: Optional[List[Dict[str, Any]]] = Field(None, description="Regras de qualidade")
    sla_requirements: Optional[Dict[str, Any]] = Field(None, description="Requisitos de SLA")
    data_owner: Optional[str] = Field(None, description="Proprietário dos dados")
    steward: Optional[str] = Field(None, description="Steward responsável")
    tags: Optional[List[str]] = Field(None, description="Tags do contrato")
    metadata: Optional[Dict[str, Any]] = Field(None, description="Metadados adicionais")
    status: Optional[ContractStatus] = Field(None, description="Status do contrato")


class DataContractResponseDTO(BaseResponseDTO):
    """DTO para resposta de contrato de dados"""
    id: UUID = Field(..., description="ID único do contrato")
    name: str = Field(..., description="Nome do contrato")
    description: Optional[str] = Field(None, description="Descrição do contrato")
    contract_type: ContractType = Field(..., description="Tipo do contrato")
    version: str = Field(..., description="Versão do contrato")
    status: ContractStatus = Field(..., description="Status do contrato")
    schema_definition: Dict[str, Any] = Field(..., description="Definição do schema")
    quality_rules: Optional[List[Dict[str, Any]]] = Field(None, description="Regras de qualidade")
    sla_requirements: Optional[Dict[str, Any]] = Field(None, description="Requisitos de SLA")
    data_owner: Optional[str] = Field(None, description="Proprietário dos dados")
    steward: Optional[str] = Field(None, description="Steward responsável")
    tags: Optional[List[str]] = Field(None, description="Tags do contrato")
    metadata: Optional[Dict[str, Any]] = Field(None, description="Metadados adicionais")
    created_at: datetime = Field(..., description="Data de criação")
    updated_at: datetime = Field(..., description="Data de atualização")
    created_by: Optional[str] = Field(None, description="Criado por")
    updated_by: Optional[str] = Field(None, description="Atualizado por")


class ContractVersionCreateDTO(BaseModel):
    """DTO para criação de versão de contrato"""
    contract_id: UUID = Field(..., description="ID do contrato")
    version: str = Field(..., description="Versão")
    schema_definition: Dict[str, Any] = Field(..., description="Definição do schema")
    changes_description: Optional[str] = Field(None, description="Descrição das mudanças")
    breaking_changes: bool = Field(False, description="Indica se há mudanças que quebram compatibilidade")
    migration_notes: Optional[str] = Field(None, description="Notas de migração")

    class Config:
        json_json_schema_extra = {
            "example": {
                "contract_id": "123e4567-e89b-12d3-a456-426614174000",
                "version": "2.0.0",
                "schema_definition": {
                    "type": "object",
                    "properties": {
                        "customer_id": {"type": "string"},
                        "name": {"type": "string"},
                        "email": {"type": "string"},
                        "phone": {"type": "string"}
                    }
                },
                "changes_description": "Adicionado campo phone",
                "breaking_changes": False
            }
        }


class ContractVersionResponseDTO(BaseResponseDTO):
    """DTO para resposta de versão de contrato"""
    id: UUID = Field(..., description="ID único da versão")
    contract_id: UUID = Field(..., description="ID do contrato")
    version: str = Field(..., description="Versão")
    schema_definition: Dict[str, Any] = Field(..., description="Definição do schema")
    changes_description: Optional[str] = Field(None, description="Descrição das mudanças")
    breaking_changes: bool = Field(..., description="Indica se há mudanças que quebram compatibilidade")
    migration_notes: Optional[str] = Field(None, description="Notas de migração")
    is_active: bool = Field(..., description="Indica se é a versão ativa")
    created_at: datetime = Field(..., description="Data de criação")
    created_by: Optional[str] = Field(None, description="Criado por")


class ContractApprovalCreateDTO(BaseModel):
    """DTO para criação de aprovação de contrato"""
    contract_id: UUID = Field(..., description="ID do contrato")
    version_id: Optional[UUID] = Field(None, description="ID da versão específica")
    approver_email: str = Field(..., description="Email do aprovador")
    approval_type: str = Field(..., description="Tipo de aprovação")
    comments: Optional[str] = Field(None, description="Comentários da aprovação")

    class Config:
        json_json_schema_extra = {
            "example": {
                "contract_id": "123e4567-e89b-12d3-a456-426614174000",
                "approver_email": "manager@f1rst.com.br",
                "approval_type": "technical_review",
                "comments": "Schema aprovado para produção"
            }
        }


class ContractApprovalResponseDTO(BaseResponseDTO):
    """DTO para resposta de aprovação de contrato"""
    id: UUID = Field(..., description="ID único da aprovação")
    contract_id: UUID = Field(..., description="ID do contrato")
    version_id: Optional[UUID] = Field(None, description="ID da versão específica")
    approver_email: str = Field(..., description="Email do aprovador")
    approval_type: str = Field(..., description="Tipo de aprovação")
    status: str = Field(..., description="Status da aprovação")
    comments: Optional[str] = Field(None, description="Comentários da aprovação")
    approved_at: Optional[datetime] = Field(None, description="Data de aprovação")
    created_at: datetime = Field(..., description="Data de criação")


class ContractSearchDTO(BaseModel):
    """DTO para busca de contratos"""
    name: Optional[str] = Field(None, description="Nome do contrato")
    contract_type: Optional[ContractType] = Field(None, description="Tipo do contrato")
    status: Optional[ContractStatus] = Field(None, description="Status do contrato")
    data_owner: Optional[str] = Field(None, description="Proprietário dos dados")
    steward: Optional[str] = Field(None, description="Steward responsável")
    tags: Optional[List[str]] = Field(None, description="Tags para filtrar")
    created_after: Optional[datetime] = Field(None, description="Criado após")
    created_before: Optional[datetime] = Field(None, description="Criado antes")


class ContractStatsDTO(BaseModel):
    """DTO para estatísticas de contratos"""
    total_contracts: int = Field(..., description="Total de contratos")
    active_contracts: int = Field(..., description="Contratos ativos")
    draft_contracts: int = Field(..., description="Contratos em rascunho")
    deprecated_contracts: int = Field(..., description="Contratos depreciados")
    contracts_by_type: Dict[str, int] = Field(..., description="Contratos por tipo")
    contracts_by_owner: Dict[str, int] = Field(..., description="Contratos por proprietário")
    recent_changes: int = Field(..., description="Mudanças recentes (últimos 30 dias)")

    class Config:
        json_json_schema_extra = {
            "example": {
                "total_contracts": 150,
                "active_contracts": 120,
                "draft_contracts": 20,
                "deprecated_contracts": 10,
                "contracts_by_type": {
                    "database": 80,
                    "api": 50,
                    "file": 20
                },
                "contracts_by_owner": {
                    "carlos.morais@f1rst.com.br": 30,
                    "team@f1rst.com.br": 120
                },
                "recent_changes": 15
            }
        }


# DTOs para entidades relacionadas
class EntityCreateDTO(BaseModel):
    """DTO para criação de entidade"""
    name: str = Field(..., description="Nome da entidade")
    description: Optional[str] = Field(None, description="Descrição da entidade")
    entity_type: str = Field(..., description="Tipo da entidade")
    schema_definition: Optional[Dict[str, Any]] = Field(None, description="Definição do schema")
    data_source: Optional[str] = Field(None, description="Fonte dos dados")
    owner: Optional[str] = Field(None, description="Proprietário")
    steward: Optional[str] = Field(None, description="Steward")
    tags: Optional[List[str]] = Field(None, description="Tags")
    metadata: Optional[Dict[str, Any]] = Field(None, description="Metadados")


class EntityUpdateDTO(BaseModel):
    """DTO para atualização de entidade"""
    name: Optional[str] = Field(None, description="Nome da entidade")
    description: Optional[str] = Field(None, description="Descrição da entidade")
    entity_type: Optional[str] = Field(None, description="Tipo da entidade")
    schema_definition: Optional[Dict[str, Any]] = Field(None, description="Definição do schema")
    data_source: Optional[str] = Field(None, description="Fonte dos dados")
    owner: Optional[str] = Field(None, description="Proprietário")
    steward: Optional[str] = Field(None, description="Steward")
    tags: Optional[List[str]] = Field(None, description="Tags")
    metadata: Optional[Dict[str, Any]] = Field(None, description="Metadados")


class EntityResponseDTO(BaseResponseDTO):
    """DTO para resposta de entidade"""
    id: UUID = Field(..., description="ID único da entidade")
    name: str = Field(..., description="Nome da entidade")
    description: Optional[str] = Field(None, description="Descrição da entidade")
    entity_type: str = Field(..., description="Tipo da entidade")
    schema_definition: Optional[Dict[str, Any]] = Field(None, description="Definição do schema")
    data_source: Optional[str] = Field(None, description="Fonte dos dados")
    owner: Optional[str] = Field(None, description="Proprietário")
    steward: Optional[str] = Field(None, description="Steward")
    tags: Optional[List[str]] = Field(None, description="Tags")
    metadata: Optional[Dict[str, Any]] = Field(None, description="Metadados")
    created_at: datetime = Field(..., description="Data de criação")
    updated_at: datetime = Field(..., description="Data de atualização")


# DTOs para qualidade
class QualityRuleCreateDTO(BaseModel):
    """DTO para criação de regra de qualidade"""
    name: str = Field(..., description="Nome da regra")
    description: Optional[str] = Field(None, description="Descrição da regra")
    rule_type: str = Field(..., description="Tipo da regra")
    entity_id: Optional[UUID] = Field(None, description="ID da entidade")
    field_name: Optional[str] = Field(None, description="Nome do campo")
    rule_definition: Dict[str, Any] = Field(..., description="Definição da regra")
    severity: str = Field("medium", description="Severidade")
    is_active: bool = Field(True, description="Regra ativa")


class QualityRuleUpdateDTO(BaseModel):
    """DTO para atualização de regra de qualidade"""
    name: Optional[str] = Field(None, description="Nome da regra")
    description: Optional[str] = Field(None, description="Descrição da regra")
    rule_type: Optional[str] = Field(None, description="Tipo da regra")
    entity_id: Optional[UUID] = Field(None, description="ID da entidade")
    field_name: Optional[str] = Field(None, description="Nome do campo")
    rule_definition: Optional[Dict[str, Any]] = Field(None, description="Definição da regra")
    severity: Optional[str] = Field(None, description="Severidade")
    is_active: Optional[bool] = Field(None, description="Regra ativa")


class QualityRuleResponseDTO(BaseResponseDTO):
    """DTO para resposta de regra de qualidade"""
    id: UUID = Field(..., description="ID único da regra")
    name: str = Field(..., description="Nome da regra")
    description: Optional[str] = Field(None, description="Descrição da regra")
    rule_type: str = Field(..., description="Tipo da regra")
    entity_id: Optional[UUID] = Field(None, description="ID da entidade")
    field_name: Optional[str] = Field(None, description="Nome do campo")
    rule_definition: Dict[str, Any] = Field(..., description="Definição da regra")
    severity: str = Field(..., description="Severidade")
    is_active: bool = Field(..., description="Regra ativa")
    created_at: datetime = Field(..., description="Data de criação")
    updated_at: datetime = Field(..., description="Data de atualização")


__all__ = [
    # Contratos
    'DataContractCreateDTO',
    'DataContractUpdateDTO', 
    'DataContractResponseDTO',
    'ContractVersionCreateDTO',
    'ContractVersionResponseDTO',
    'ContractApprovalCreateDTO',
    'ContractApprovalResponseDTO',
    'ContractSearchDTO',
    'ContractStatsDTO',
    # Entidades
    'EntityCreateDTO',
    'EntityUpdateDTO',
    'EntityResponseDTO',
    # Qualidade
    'QualityRuleCreateDTO',
    'QualityRuleUpdateDTO',
    'QualityRuleResponseDTO',
    # Enums
    'ContractStatus',
    'ContractType'
]



class DataContractVersionCreateDTO(BaseModel):
    """DTO para criação de versão de contrato"""
    contract_id: UUID = Field(..., description="ID do contrato")
    version: str = Field(..., description="Número da versão")
    schema_definition: Dict[str, Any] = Field(..., description="Definição do schema")
    quality_requirements: Optional[Dict[str, Any]] = Field(default_factory=dict, description="Requisitos de qualidade")
    change_description: Optional[str] = Field(None, description="Descrição das mudanças")
    is_breaking_change: bool = Field(default=False, description="Mudança quebra compatibilidade")

    class Config:
        json_json_schema_extra = {
            "example": {
                "contract_id": "123e4567-e89b-12d3-a456-426614174000",
                "version": "1.3.0",
                "schema_definition": {"type": "object", "properties": {"id": {"type": "string"}}},
                "quality_requirements": {"completeness": 98.0, "accuracy": 99.5},
                "change_description": "Adicionado campo de validação de email"
            }
        }


class DataContractVersionResponseDTO(BaseModel):
    """DTO para resposta de versão de contrato"""
    id: UUID = Field(..., description="ID único da versão")
    contract_id: UUID = Field(..., description="ID do contrato")
    version: str = Field(..., description="Número da versão")
    status: str = Field(..., description="Status da versão")
    schema_definition: Dict[str, Any] = Field(default_factory=dict, description="Definição do schema")
    quality_requirements: Dict[str, Any] = Field(default_factory=dict, description="Requisitos de qualidade")
    change_description: Optional[str] = Field(None, description="Descrição das mudanças")
    is_breaking_change: bool = Field(..., description="Mudança quebra compatibilidade")
    created_at: datetime = Field(..., description="Data de criação")
    activated_at: Optional[datetime] = Field(None, description="Data de ativação")

    class Config:
        json_json_schema_extra = {
            "example": {
                "id": "123e4567-e89b-12d3-a456-426614174000",
                "contract_id": "123e4567-e89b-12d3-a456-426614174000",
                "version": "1.3.0",
                "status": "active",
                "is_breaking_change": False,
                "created_at": "2025-07-17T23:36:17Z",
                "activated_at": "2025-07-17T23:36:17Z"
            }
        }


class ContractVersionCreateDTO(BaseModel):
    """Alias para DataContractVersionCreateDTO"""
    contract_id: UUID = Field(..., description="ID do contrato")
    version: str = Field(..., description="Número da versão")
    schema_definition: Dict[str, Any] = Field(..., description="Definição do schema")
    change_description: Optional[str] = Field(None, description="Descrição das mudanças")

    class Config:
        json_json_schema_extra = {
            "example": {
                "contract_id": "123e4567-e89b-12d3-a456-426614174000",
                "version": "1.3.0",
                "schema_definition": {"type": "object"},
                "change_description": "Nova versão"
            }
        }


class ContractVersionResponseDTO(BaseModel):
    """Alias para DataContractVersionResponseDTO"""
    id: UUID = Field(..., description="ID único da versão")
    contract_id: UUID = Field(..., description="ID do contrato")
    version: str = Field(..., description="Número da versão")
    status: str = Field(..., description="Status da versão")

    class Config:
        json_json_schema_extra = {
            "example": {
                "id": "123e4567-e89b-12d3-a456-426614174000",
                "contract_id": "123e4567-e89b-12d3-a456-426614174000",
                "version": "1.3.0",
                "status": "active"
            }
        }

