from typing import TypeVar
"""
DTOs para Performance e Escalabilidade
"""

from datetime import datetime
from enum import Enum
from typing import Dict, List, Optional, Union
from uuid import UUID

from pydantic import BaseModel, Field


class MetricType(str, Enum):
    """Tipo de métrica"""
    RESPONSE_TIME = "response_time"
    THROUGHPUT = "throughput"
    ERROR_RATE = "error_rate"
    CPU_USAGE = "cpu_usage"
    MEMORY_USAGE = "memory_usage"
    DISK_USAGE = "disk_usage"
    NETWORK_IO = "network_io"
    DATABASE_CONNECTIONS = "database_connections"
    CACHE_HIT_RATE = "cache_hit_rate"
    QUEUE_SIZE = "queue_size"


class BottleneckType(str, Enum):
    """Tipo de gargalo"""
    CPU = "cpu"
    MEMORY = "memory"
    DISK_IO = "disk_io"
    NETWORK_IO = "network_io"
    DATABASE = "database"
    CACHE = "cache"
    QUEUE = "queue"
    EXTERNAL_API = "external_api"
    ALGORITHM = "algorithm"


class OptimizationType(str, Enum):
    """Tipo de otimização"""
    QUERY_OPTIMIZATION = "query_optimization"
    INDEX_CREATION = "index_creation"
    CACHE_TUNING = "cache_tuning"
    CONNECTION_POOLING = "connection_pooling"
    BATCH_PROCESSING = "batch_processing"
    ASYNC_PROCESSING = "async_processing"
    COMPRESSION = "compression"
    PARTITIONING = "partitioning"


class Severity(str, Enum):
    """Severidade"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class PerformanceMetricDTO(BaseModel):
    """DTO para métrica de performance"""
    id: UUID
    metric_type: MetricType
    component: str  # api, database, cache, queue, etc.
    endpoint: Optional[str] = None
    value: float
    unit: str  # ms, req/s, %, MB, etc.
    threshold_warning: Optional[float] = None
    threshold_critical: Optional[float] = None
    is_healthy: bool
    severity: Optional[Severity] = None
    tags: Dict = Field(default_factory=dict)
    timestamp: datetime
    metadata: Dict = Field(default_factory=dict)

    class Config:
        from_attributes = True
        json_json_schema_extra = {
            "example": {
                "id": "123e4567-e89b-12d3-a456-426614174000",
                "metric_type": "response_time",
                "component": "api",
                "endpoint": "/api/v1/entities",
                "value": 245.5,
                "unit": "ms",
                "threshold_warning": 500.0,
                "threshold_critical": 1000.0,
                "is_healthy": True,
                "severity": None,
                "tags": {"method": "GET", "status": "200"},
                "timestamp": "2025-01-15T10:30:00Z",
                "metadata": {"user_count": 15, "data_size": "1.2MB"}
            }
        }


class PerformanceMetricsResponseDTO(BaseModel):
    """DTO para resposta de métricas de performance"""
    summary: Dict = Field(default_factory=dict)
    metrics: List[PerformanceMetricDTO] = Field(default_factory=list)
    trends: Dict = Field(default_factory=dict)
    alerts: List[Dict] = Field(default_factory=list)
    recommendations: List[str] = Field(default_factory=list)
    period_start: datetime
    period_end: datetime
    generated_at: datetime

    class Config:
        json_json_schema_extra = {
            "example": {
                "summary": {
                    "avg_response_time": 245.5,
                    "total_requests": 15420,
                    "error_rate": 0.02,
                    "throughput": 125.5,
                    "availability": 0.9995
                },
                "trends": {
                    "response_time": {"trend": "stable", "change_percent": -2.1},
                    "throughput": {"trend": "increasing", "change_percent": 8.5},
                    "error_rate": {"trend": "decreasing", "change_percent": -15.2}
                },
                "alerts": [
                    {
                        "type": "warning",
                        "metric": "memory_usage",
                        "value": 85.2,
                        "threshold": 80.0,
                        "message": "Memory usage above warning threshold"
                    }
                ],
                "recommendations": [
                    "Consider adding database indexes for frequently queried fields",
                    "Enable response compression for large payloads",
                    "Implement connection pooling for external APIs"
                ],
                "period_start": "2025-01-14T10:30:00Z",
                "period_end": "2025-01-15T10:30:00Z",
                "generated_at": "2025-01-15T10:30:00Z"
            }
        }


class BottleneckAnalysisDTO(BaseModel):
    """DTO para análise de gargalos"""
    id: UUID
    bottleneck_type: BottleneckType
    component: str
    description: str
    impact_score: float = Field(ge=0, le=100)
    severity: Severity
    affected_endpoints: List[str] = Field(default_factory=list)
    root_cause: str
    symptoms: List[str] = Field(default_factory=list)
    metrics: Dict = Field(default_factory=dict)
    recommendations: List[Dict] = Field(default_factory=list)
    estimated_fix_time: str  # "2 hours", "1 day", etc.
    priority: int = Field(ge=1, le=5)
    detected_at: datetime
    last_occurrence: datetime
    occurrence_count: int = Field(default=1)
    is_resolved: bool = Field(default=False)
    resolved_at: Optional[datetime] = None
    metadata: Dict = Field(default_factory=dict)

    class Config:
        from_attributes = True
        json_json_schema_extra = {
            "example": {
                "id": "123e4567-e89b-12d3-a456-426614174000",
                "bottleneck_type": "database",
                "component": "postgresql",
                "description": "Slow query execution on entities table",
                "impact_score": 75.5,
                "severity": "high",
                "affected_endpoints": ["/api/v1/entities", "/api/v1/entities/search"],
                "root_cause": "Missing index on frequently queried columns",
                "symptoms": [
                    "Response time > 2 seconds",
                    "High CPU usage on database server",
                    "Increasing connection pool usage"
                ],
                "metrics": {
                    "avg_query_time": 2.5,
                    "slow_queries_count": 45,
                    "cpu_usage": 85.2
                },
                "recommendations": [
                    {
                        "action": "Create composite index",
                        "details": "CREATE INDEX idx_entities_domain_status ON entities(domain_id, status)",
                        "impact": "Expected 60% improvement in query time"
                    }
                ],
                "estimated_fix_time": "30 minutes",
                "priority": 2,
                "detected_at": "2025-01-15T09:15:00Z",
                "last_occurrence": "2025-01-15T10:25:00Z",
                "occurrence_count": 12,
                "is_resolved": False,
                "resolved_at": None,
                "metadata": {"auto_detected": True}
            }
        }


class OptimizationRecommendationDTO(BaseModel):
    """DTO para recomendação de otimização"""
    id: UUID
    optimization_type: OptimizationType
    title: str
    description: str
    component: str
    priority: int = Field(ge=1, le=5)
    impact_score: float = Field(ge=0, le=100)
    effort_estimate: str  # "low", "medium", "high"
    time_estimate: str  # "1 hour", "2 days", etc.
    cost_estimate: Optional[str] = None
    prerequisites: List[str] = Field(default_factory=list)
    implementation_steps: List[str] = Field(default_factory=list)
    expected_benefits: Dict = Field(default_factory=dict)
    risks: List[str] = Field(default_factory=list)
    rollback_plan: str
    testing_requirements: List[str] = Field(default_factory=list)
    monitoring_metrics: List[str] = Field(default_factory=list)
    status: str = Field(default="pending")  # pending, approved, in_progress, completed, rejected
    assigned_to: Optional[UUID] = None
    created_by: UUID
    created_at: datetime
    updated_at: datetime
    metadata: Dict = Field(default_factory=dict)

    class Config:
        from_attributes = True
        json_json_schema_extra = {
            "example": {
                "id": "123e4567-e89b-12d3-a456-426614174000",
                "optimization_type": "index_creation",
                "title": "Create composite index for entities search",
                "description": "Add composite index to improve search performance on entities table",
                "component": "database",
                "priority": 2,
                "impact_score": 75.0,
                "effort_estimate": "low",
                "time_estimate": "30 minutes",
                "cost_estimate": "minimal",
                "prerequisites": ["Database maintenance window", "Backup verification"],
                "implementation_steps": [
                    "Analyze current query patterns",
                    "Create index in staging environment",
                    "Test performance improvement",
                    "Apply to production during maintenance window"
                ],
                "expected_benefits": {
                    "response_time_improvement": "60%",
                    "cpu_usage_reduction": "25%",
                    "user_experience": "significantly better"
                },
                "risks": ["Temporary table lock during creation", "Increased storage usage"],
                "rollback_plan": "DROP INDEX if performance degrades",
                "testing_requirements": ["Load testing", "Query performance validation"],
                "monitoring_metrics": ["query_execution_time", "index_usage_stats"],
                "status": "pending",
                "assigned_to": None,
                "created_by": "456e7890-e89b-12d3-a456-426614174000",
                "created_at": "2025-01-15T10:30:00Z",
                "updated_at": "2025-01-15T10:30:00Z",
                "metadata": {"auto_generated": True, "confidence": 0.85}
            }
        }


class CapacityPlanningDTO(BaseModel):
    """DTO para planejamento de capacidade"""
    id: UUID
    component: str
    current_usage: Dict = Field(default_factory=dict)
    projected_usage: Dict = Field(default_factory=dict)
    growth_rate: float  # percentage per month
    capacity_threshold: float = Field(default=80.0, ge=0, le=100)
    time_to_threshold: str  # "3 months", "1 year", etc.
    recommendations: List[Dict] = Field(default_factory=list)
    scaling_options: List[Dict] = Field(default_factory=list)
    cost_projections: Dict = Field(default_factory=dict)
    risk_assessment: Dict = Field(default_factory=dict)
    monitoring_alerts: List[Dict] = Field(default_factory=list)
    review_date: datetime
    next_review: datetime
    confidence_level: float = Field(ge=0, le=1)
    assumptions: List[str] = Field(default_factory=list)
    generated_by: UUID
    generated_at: datetime
    metadata: Dict = Field(default_factory=dict)

    class Config:
        from_attributes = True
        json_json_schema_extra = {
            "example": {
                "id": "123e4567-e89b-12d3-a456-426614174000",
                "component": "database",
                "current_usage": {
                    "storage": {"value": 250, "unit": "GB", "percentage": 62.5},
                    "connections": {"value": 45, "unit": "connections", "percentage": 45.0},
                    "cpu": {"value": 35, "unit": "%", "percentage": 35.0}
                },
                "projected_usage": {
                    "3_months": {"storage": 320, "connections": 58, "cpu": 45},
                    "6_months": {"storage": 410, "connections": 75, "cpu": 58},
                    "12_months": {"storage": 650, "connections": 120, "cpu": 92}
                },
                "growth_rate": 15.5,
                "capacity_threshold": 80.0,
                "time_to_threshold": "8 months",
                "recommendations": [
                    {
                        "type": "scaling",
                        "description": "Upgrade to next tier database instance",
                        "timeline": "6 months",
                        "priority": "medium"
                    }
                ],
                "scaling_options": [
                    {
                        "option": "vertical_scaling",
                        "description": "Upgrade current instance",
                        "cost": "$200/month additional",
                        "capacity_increase": "100%"
                    },
                    {
                        "option": "horizontal_scaling",
                        "description": "Add read replicas",
                        "cost": "$150/month per replica",
                        "capacity_increase": "50% per replica"
                    }
                ],
                "cost_projections": {
                    "current_monthly": 500,
                    "projected_6_months": 650,
                    "projected_12_months": 850
                },
                "risk_assessment": {
                    "performance_degradation": "medium",
                    "service_interruption": "low",
                    "data_loss": "very_low"
                },
                "monitoring_alerts": [
                    {
                        "metric": "storage_usage",
                        "threshold": 75,
                        "action": "notify_admin"
                    }
                ],
                "review_date": "2025-01-15T10:30:00Z",
                "next_review": "2025-04-15T10:30:00Z",
                "confidence_level": 0.85,
                "assumptions": [
                    "Current growth rate continues",
                    "No major architectural changes",
                    "User base grows at 10% per quarter"
                ],
                "generated_by": "456e7890-e89b-12d3-a456-426614174000",
                "generated_at": "2025-01-15T10:30:00Z",
                "metadata": {"model_version": "v2.1", "data_points": 90}
            }
        }


class OptimizationRequestDTO(BaseModel):
    """DTO para solicitação de otimização"""
    component: str
    optimization_type: OptimizationType
    description: str
    priority: int = Field(ge=1, le=5, default=3)
    target_improvement: Dict = Field(default_factory=dict)
    constraints: List[str] = Field(default_factory=list)
    deadline: Optional[datetime] = None
    budget_limit: Optional[float] = None
    metadata: Dict = Field(default_factory=dict)

    class Config:
        json_json_schema_extra = {
            "example": {
                "component": "api",
                "optimization_type": "query_optimization",
                "description": "Optimize slow entity search queries",
                "priority": 2,
                "target_improvement": {
                    "response_time": "50% reduction",
                    "throughput": "30% increase"
                },
                "constraints": ["No downtime", "Backward compatibility"],
                "deadline": "2025-02-15T00:00:00Z",
                "budget_limit": 5000.0,
                "metadata": {"business_impact": "high"}
            }
        }


class PerformanceAlertDTO(BaseModel):
    """DTO para alerta de performance"""
    id: UUID
    alert_type: str  # threshold, anomaly, trend
    metric_type: MetricType
    component: str
    severity: Severity
    message: str
    current_value: float
    threshold_value: Optional[float] = None
    deviation_percentage: Optional[float] = None
    duration_minutes: int
    affected_users: int = Field(default=0)
    impact_description: str
    recommended_actions: List[str] = Field(default_factory=list)
    is_acknowledged: bool = Field(default=False)
    acknowledged_by: Optional[UUID] = None
    acknowledged_at: Optional[datetime] = None
    is_resolved: bool = Field(default=False)
    resolved_at: Optional[datetime] = None
    resolution_notes: Optional[str] = None
    triggered_at: datetime
    metadata: Dict = Field(default_factory=dict)

    class Config:
        from_attributes = True

