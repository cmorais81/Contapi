"""
Repository para Domínios de Negócio
"""

from typing import Dict, List, Optional, Tuple
from uuid import UUID

from sqlalchemy import and_, func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from src.application.dtos import PaginationParams
from src.application.dtos.domains import DomainSearchDTO
from src.database.models import Domain as DomainModel, Entity as EntityModel
from src.domain.entities.domain import Domain


class DomainRepository:
    """Repository para operações de domínios"""

    def __init__(self, session: AsyncSession):
        self.session = session

    async def create(self, domain: Domain) -> Domain:
        """Cria um novo domínio"""
        domain_model = DomainModel(
            name=domain.name,
            display_name=domain.display_name,
            description=domain.description,
            parent_domain_id=domain.parent_domain_id,
            domain_type=domain.domain_type,
            business_owner=domain.business_owner,
            technical_owner=domain.technical_owner,
            is_active=domain.is_active,
            created_by=domain.created_by
        )
        
        self.session.add(domain_model)
        await self.session.commit()
        await self.session.refresh(domain_model)
        
        return self._to_entity(domain_model)

    async def get_by_id(self, domain_id: UUID) -> Optional[Domain]:
        """Busca domínio por ID"""
        stmt = select(DomainModel).where(DomainModel.id == domain_id)
        result = await self.session.execute(stmt)
        domain_model = result.scalar_one_or_none()
        
        return self._to_entity(domain_model) if domain_model else None

    async def get_by_name(self, name: str) -> Optional[Domain]:
        """Busca domínio por nome"""
        stmt = select(DomainModel).where(DomainModel.name == name)
        result = await self.session.execute(stmt)
        domain_model = result.scalar_one_or_none()
        
        return self._to_entity(domain_model) if domain_model else None

    async def update(self, domain: Domain) -> Domain:
        """Atualiza um domínio"""
        stmt = select(DomainModel).where(DomainModel.id == domain.id)
        result = await self.session.execute(stmt)
        domain_model = result.scalar_one_or_none()
        
        if not domain_model:
            raise ValueError(f"Domain {domain.id} not found")

        # Atualizar campos
        domain_model.display_name = domain.display_name
        domain_model.description = domain.description
        domain_model.parent_domain_id = domain.parent_domain_id
        domain_model.domain_type = domain.domain_type
        domain_model.business_owner = domain.business_owner
        domain_model.technical_owner = domain.technical_owner
        domain_model.is_active = domain.is_active
        domain_model.updated_by = domain.updated_by

        await self.session.commit()
        await self.session.refresh(domain_model)
        
        return self._to_entity(domain_model)

    async def list_with_filters(self, pagination: PaginationParams, filters: Dict) -> Tuple[List[Domain], int]:
        """Lista domínios com filtros e paginação"""
        # Construir query base
        stmt = select(DomainModel)
        count_stmt = select(func.count(DomainModel.id))

        # Aplicar filtros
        conditions = []
        
        if "domain_type" in filters:
            conditions.append(DomainModel.domain_type == filters["domain_type"])
        
        if "is_active" in filters:
            conditions.append(DomainModel.is_active == filters["is_active"])
        
        if "parent_domain_id" in filters:
            if filters["parent_domain_id"] is None:
                conditions.append(DomainModel.parent_domain_id.is_(None))
            else:
                conditions.append(DomainModel.parent_domain_id == filters["parent_domain_id"])

        if conditions:
            stmt = stmt.where(and_(*conditions))
            count_stmt = count_stmt.where(and_(*conditions))

        # Contar total
        count_result = await self.session.execute(count_stmt)
        total = count_result.scalar()

        # Aplicar paginação e ordenação
        stmt = stmt.order_by(DomainModel.display_name)
        stmt = stmt.offset((pagination.page - 1) * pagination.size).limit(pagination.size)

        # Executar query
        result = await self.session.execute(stmt)
        domain_models = result.scalars().all()

        domains = [self._to_entity(model) for model in domain_models]
        
        return domains, total

    async def get_children(self, domain_id: UUID, include_inactive: bool = False) -> List[Domain]:
        """Busca subdomínios de um domínio"""
        stmt = select(DomainModel).where(DomainModel.parent_domain_id == domain_id)
        
        if not include_inactive:
            stmt = stmt.where(DomainModel.is_active == True)
        
        stmt = stmt.order_by(DomainModel.display_name)
        
        result = await self.session.execute(stmt)
        domain_models = result.scalars().all()
        
        return [self._to_entity(model) for model in domain_models]

    async def get_root_domains(self, include_inactive: bool = False) -> List[Domain]:
        """Busca domínios raiz (sem pai)"""
        stmt = select(DomainModel).where(DomainModel.parent_domain_id.is_(None))
        
        if not include_inactive:
            stmt = stmt.where(DomainModel.is_active == True)
        
        stmt = stmt.order_by(DomainModel.display_name)
        
        result = await self.session.execute(stmt)
        domain_models = result.scalars().all()
        
        return [self._to_entity(model) for model in domain_models]

    async def get_entity_count(self, domain_id: UUID, include_inactive: bool = True) -> int:
        """Conta entidades de um domínio"""
        stmt = select(func.count(EntityModel.id)).where(EntityModel.domain_id == domain_id)
        
        if not include_inactive:
            stmt = stmt.where(EntityModel.is_active == True)
        
        result = await self.session.execute(stmt)
        return result.scalar() or 0

    async def get_subdomain_count(self, domain_id: UUID, include_inactive: bool = True) -> int:
        """Conta subdomínios de um domínio"""
        stmt = select(func.count(DomainModel.id)).where(DomainModel.parent_domain_id == domain_id)
        
        if not include_inactive:
            stmt = stmt.where(DomainModel.is_active == True)
        
        result = await self.session.execute(stmt)
        return result.scalar() or 0

    async def search(self, search_criteria: DomainSearchDTO, pagination: PaginationParams) -> Tuple[List[Domain], int]:
        """Busca avançada de domínios"""
        # Construir query base
        stmt = select(DomainModel)
        count_stmt = select(func.count(DomainModel.id))

        # Aplicar critérios de busca
        conditions = []

        if search_criteria.query:
            query_filter = or_(
                DomainModel.name.ilike(f"%{search_criteria.query}%"),
                DomainModel.display_name.ilike(f"%{search_criteria.query}%"),
                DomainModel.description.ilike(f"%{search_criteria.query}%")
            )
            conditions.append(query_filter)

        if search_criteria.domain_type:
            conditions.append(DomainModel.domain_type == search_criteria.domain_type)

        if search_criteria.is_active is not None:
            conditions.append(DomainModel.is_active == search_criteria.is_active)

        if search_criteria.parent_domain_id:
            conditions.append(DomainModel.parent_domain_id == search_criteria.parent_domain_id)

        if search_criteria.business_owner:
            conditions.append(DomainModel.business_owner.ilike(f"%{search_criteria.business_owner}%"))

        if search_criteria.technical_owner:
            conditions.append(DomainModel.technical_owner.ilike(f"%{search_criteria.technical_owner}%"))

        if conditions:
            stmt = stmt.where(and_(*conditions))
            count_stmt = count_stmt.where(and_(*conditions))

        # Contar total
        count_result = await self.session.execute(count_stmt)
        total = count_result.scalar()

        # Aplicar paginação e ordenação
        stmt = stmt.order_by(DomainModel.display_name)
        stmt = stmt.offset((pagination.page - 1) * pagination.size).limit(pagination.size)

        # Executar query
        result = await self.session.execute(stmt)
        domain_models = result.scalars().all()

        domains = [self._to_entity(model) for model in domain_models]
        
        return domains, total

    async def get_domain_entities(self, domain_id: UUID, pagination: PaginationParams, include_inactive: bool = False):
        """Lista entidades de um domínio com paginação"""
        # Query base para entidades
        stmt = select(EntityModel).where(EntityModel.domain_id == domain_id)
        count_stmt = select(func.count(EntityModel.id)).where(EntityModel.domain_id == domain_id)

        if not include_inactive:
            stmt = stmt.where(EntityModel.is_active == True)
            count_stmt = count_stmt.where(EntityModel.is_active == True)

        # Contar total
        count_result = await self.session.execute(count_stmt)
        total = count_result.scalar()

        # Aplicar paginação
        stmt = stmt.order_by(EntityModel.name)
        stmt = stmt.offset((pagination.page - 1) * pagination.size).limit(pagination.size)

        # Executar query
        result = await self.session.execute(stmt)
        entities = result.scalars().all()

        # Converter para DTOs (simplificado)
        entity_dtos = []
        for entity in entities:
            entity_dtos.append({
                "id": entity.id,
                "name": entity.name,
                "display_name": entity.display_name,
                "entity_type": entity.entity_type,
                "is_active": entity.is_active,
                "created_at": entity.created_at,
                "updated_at": entity.updated_at
            })

        from src.application.dtos import PaginatedResponse
        return PaginatedResponse(
            items=entity_dtos,
            total=total,
            page=pagination.page,
            size=pagination.size,
            pages=(total + pagination.size - 1) // pagination.size
        )

    async def get_domain_stats(self, domain_id: UUID) -> Dict:
        """Obtém estatísticas do domínio"""
        # Contar entidades
        entity_count_stmt = select(func.count(EntityModel.id)).where(
            and_(EntityModel.domain_id == domain_id, EntityModel.is_active == True)
        )
        entity_result = await self.session.execute(entity_count_stmt)
        total_entities = entity_result.scalar() or 0

        # TODO: Implementar contagem de contratos e regras de qualidade
        # quando essas tabelas estiverem disponíveis
        
        stats = {
            "total_entities": total_entities,
            "total_contracts": 0,  # Placeholder
            "total_quality_rules": 0,  # Placeholder
            "quality_score": 85.0,  # Placeholder
            "compliance_score": 90.0,  # Placeholder
            "last_updated": None  # Placeholder
        }

        return stats

    def _to_entity(self, model: DomainModel) -> Domain:
        """Converte modelo SQLAlchemy para entidade de domínio"""
        if not model:
            return None
            
        return Domain(
            id=model.id,
            name=model.name,
            display_name=model.display_name,
            description=model.description,
            parent_domain_id=model.parent_domain_id,
            domain_type=model.domain_type,
            business_owner=model.business_owner,
            technical_owner=model.technical_owner,
            is_active=model.is_active,
            created_by=model.created_by,
            updated_by=model.updated_by,
            created_at=model.created_at,
            updated_at=model.updated_at
        )

