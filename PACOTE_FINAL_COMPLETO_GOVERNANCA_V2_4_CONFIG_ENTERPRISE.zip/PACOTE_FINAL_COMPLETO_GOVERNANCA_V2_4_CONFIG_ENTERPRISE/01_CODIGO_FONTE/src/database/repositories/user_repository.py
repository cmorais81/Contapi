"""
Repositório de Usuários
API de Governança de Dados V1.1
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from typing import List, Optional
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_
from .base import BaseRepository
from ..models.auth import User, Role, UserRole

class UserRepository(BaseRepository):
    """Repositório para operações com usuários"""
    
    def __init__(self, db: Session):
        super().__init__(User, db)
    
    def find_by_email(self, email: str) -> Optional[User]:
        """Busca usuário por email"""
        return self.db.query(User).filter(User.email == email).first()
    
    def find_by_username(self, username: str) -> Optional[User]:
        """Busca usuário por username"""
        return self.db.query(User).filter(User.username == username).first()
    
    def find_active_users(self) -> List[User]:
        """Busca usuários ativos"""
        return self.db.query(User).filter(User.is_active == True).all()
    
    def find_by_role(self, role_name: str) -> List[User]:
        """Busca usuários por role"""
        return (
            self.db.query(User)
            .join(UserRole)
            .join(Role)
            .filter(Role.name == role_name)
            .all()
        )
    
    def find_by_organization(self, organization: str) -> List[User]:
        """Busca usuários por organização"""
        return self.db.query(User).filter(User.organization == organization).all()
    
    def search_users(self, query: str) -> List[User]:
        """Busca usuários por termo de pesquisa"""
        search_term = f"%{query}%"
        return (
            self.db.query(User)
            .filter(
                or_(
                    User.full_name.ilike(search_term),
                    User.email.ilike(search_term),
                    User.username.ilike(search_term),
                    User.organization.ilike(search_term)
                )
            )
            .all()
        )
    
    def get_user_roles(self, user_id: str) -> List[Role]:
        """Obtém roles de um usuário"""
        return (
            self.db.query(Role)
            .join(UserRole)
            .filter(UserRole.user_id == user_id)
            .all()
        )
    
    def add_role_to_user(self, user_id: str, role_id: str) -> bool:
        """Adiciona role a um usuário"""
        try:
            # Verifica se já existe
            existing = (
                self.db.query(UserRole)
                .filter(
                    and_(
                        UserRole.user_id == user_id,
                        UserRole.role_id == role_id
                    )
                )
                .first()
            )
            
            if existing:
                return False
            
            user_role = UserRole(user_id=user_id, role_id=role_id)
            self.db.add(user_role)
            self.db.commit()
            return True
        except Exception:
            self.db.rollback()
            return False
    
    def remove_role_from_user(self, user_id: str, role_id: str) -> bool:
        """Remove role de um usuário"""
        try:
            user_role = (
                self.db.query(UserRole)
                .filter(
                    and_(
                        UserRole.user_id == user_id,
                        UserRole.role_id == role_id
                    )
                )
                .first()
            )
            
            if user_role:
                self.db.delete(user_role)
                self.db.commit()
                return True
            return False
        except Exception:
            self.db.rollback()
            return False
    
    def update_last_login(self, user_id: str) -> bool:
        """Atualiza último login do usuário"""
        try:
            from datetime import datetime
            user = self.get_by_id(user_id)
            if user:
                user.last_login = datetime.utcnow()
                self.db.commit()
                return True
            return False
        except Exception:
            self.db.rollback()
            return False
    
    def deactivate_user(self, user_id: str) -> bool:
        """Desativa um usuário"""
        try:
            user = self.get_by_id(user_id)
            if user:
                user.is_active = False
                self.db.commit()
                return True
            return False
        except Exception:
            self.db.rollback()
            return False
    
    def activate_user(self, user_id: str) -> bool:
        """Ativa um usuário"""
        try:
            user = self.get_by_id(user_id)
            if user:
                user.is_active = True
                self.db.commit()
                return True
            return False
        except Exception:
            self.db.rollback()
            return False

class RoleRepository(BaseRepository):
    """Repositório para operações com roles"""
    
    def __init__(self, db: Session):
        super().__init__(Role, db)
    
    def find_by_name(self, name: str) -> Optional[Role]:
        """Busca role por nome"""
        return self.db.query(Role).filter(Role.name == name).first()
    
    def find_active_roles(self) -> List[Role]:
        """Busca roles ativas"""
        return self.db.query(Role).filter(Role.is_active == True).all()
    
    def get_role_users(self, role_id: str) -> List[User]:
        """Obtém usuários de uma role"""
        return (
            self.db.query(User)
            .join(UserRole)
            .filter(UserRole.role_id == role_id)
            .all()
        )

# Funções de conveniência
def get_user_repository(db: Session) -> UserRepository:
    """Obtém instância do repositório de usuários"""
    return UserRepository(db)

def get_role_repository(db: Session) -> RoleRepository:
    """Obtém instância do repositório de roles"""
    return RoleRepository(db)

__all__ = ['UserRepository', 'RoleRepository', 'get_user_repository', 'get_role_repository']

