"""
Repositório de Qualidade de Dados
API de Governança de Dados V2.0
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from typing import List, Optional, Dict, Any
from sqlalchemy.orm import Session
from sqlalchemy import func, and_, or_, desc, asc
from datetime import datetime, timedelta

from ..models.quality import (
    QualityRule, QualityMetric, QualityIssue, 
    QualityReport, QualityThreshold, QualityProfile
)
from .base import BaseRepository

class QualityRepository(BaseRepository[QualityRule]):
    """Repositório para operações de qualidade de dados"""
    
    def __init__(self, db: Session):
        super().__init__(QualityRule, db)
    
    # Métodos para QualityRule
    def get_rules_by_entity(self, entity_id: str) -> List[QualityRule]:
        """Obtém regras de qualidade por entidade"""
        return self.db.query(QualityRule).filter(
            QualityRule.entity_id == entity_id,
            QualityRule.is_active == True
        ).all()
    
    def get_rules_by_type(self, rule_type: str) -> List[QualityRule]:
        """Obtém regras por tipo"""
        return self.db.query(QualityRule).filter(
            QualityRule.rule_type == rule_type,
            QualityRule.is_active == True
        ).all()
    
    def get_active_rules(self) -> List[QualityRule]:
        """Obtém todas as regras ativas"""
        return self.db.query(QualityRule).filter(
            QualityRule.is_active == True
        ).all()
    
    def create_rule(self, rule_data: Dict[str, Any]) -> QualityRule:
        """Cria nova regra de qualidade"""
        rule = QualityRule(**rule_data)
        self.db.add(rule)
        self.db.commit()
        self.db.refresh(rule)
        return rule
    
    def update_rule(self, rule_id: str, rule_data: Dict[str, Any]) -> Optional[QualityRule]:
        """Atualiza regra de qualidade"""
        rule = self.get_by_id(rule_id)
        if rule:
            for key, value in rule_data.items():
                setattr(rule, key, value)
            rule.updated_at = datetime.utcnow()
            self.db.commit()
            self.db.refresh(rule)
        return rule
    
    def activate_rule(self, rule_id: str) -> bool:
        """Ativa regra de qualidade"""
        rule = self.get_by_id(rule_id)
        if rule:
            rule.is_active = True
            rule.updated_at = datetime.utcnow()
            self.db.commit()
            return True
        return False
    
    def deactivate_rule(self, rule_id: str) -> bool:
        """Desativa regra de qualidade"""
        rule = self.get_by_id(rule_id)
        if rule:
            rule.is_active = False
            rule.updated_at = datetime.utcnow()
            self.db.commit()
            return True
        return False
    
    # Métodos para QualityMetric
    def get_metrics_by_entity(self, entity_id: str, limit: int = 100) -> List[QualityMetric]:
        """Obtém métricas de qualidade por entidade"""
        return self.db.query(QualityMetric).filter(
            QualityMetric.entity_id == entity_id
        ).order_by(desc(QualityMetric.created_at)).limit(limit).all()
    
    def get_metrics_by_rule(self, rule_id: str, limit: int = 100) -> List[QualityMetric]:
        """Obtém métricas por regra"""
        return self.db.query(QualityMetric).filter(
            QualityMetric.rule_id == rule_id
        ).order_by(desc(QualityMetric.created_at)).limit(limit).all()
    
    def get_latest_metrics(self, entity_id: str) -> List[QualityMetric]:
        """Obtém métricas mais recentes por entidade"""
        return self.db.query(QualityMetric).filter(
            QualityMetric.entity_id == entity_id
        ).order_by(desc(QualityMetric.created_at)).limit(10).all()
    
    def create_metric(self, metric_data: Dict[str, Any]) -> QualityMetric:
        """Cria nova métrica de qualidade"""
        metric = QualityMetric(**metric_data)
        self.db.add(metric)
        self.db.commit()
        self.db.refresh(metric)
        return metric
    
    def get_metric_trends(self, entity_id: str, days: int = 30) -> List[QualityMetric]:
        """Obtém tendências de métricas"""
        start_date = datetime.utcnow() - timedelta(days=days)
        return self.db.query(QualityMetric).filter(
            QualityMetric.entity_id == entity_id,
            QualityMetric.created_at >= start_date
        ).order_by(QualityMetric.created_at).all()
    
    # Métodos para QualityIssue
    def get_issues_by_entity(self, entity_id: str) -> List[QualityIssue]:
        """Obtém problemas de qualidade por entidade"""
        return self.db.query(QualityIssue).filter(
            QualityIssue.entity_id == entity_id
        ).order_by(desc(QualityIssue.created_at)).all()
    
    def get_open_issues(self) -> List[QualityIssue]:
        """Obtém problemas em aberto"""
        return self.db.query(QualityIssue).filter(
            QualityIssue.status.in_(['open', 'in_progress'])
        ).order_by(desc(QualityIssue.created_at)).all()
    
    def get_issues_by_severity(self, severity: str) -> List[QualityIssue]:
        """Obtém problemas por severidade"""
        return self.db.query(QualityIssue).filter(
            QualityIssue.severity == severity
        ).order_by(desc(QualityIssue.created_at)).all()
    
    def create_issue(self, issue_data: Dict[str, Any]) -> QualityIssue:
        """Cria novo problema de qualidade"""
        issue = QualityIssue(**issue_data)
        self.db.add(issue)
        self.db.commit()
        self.db.refresh(issue)
        return issue
    
    def update_issue_status(self, issue_id: str, status: str, resolution: str = None) -> Optional[QualityIssue]:
        """Atualiza status do problema"""
        issue = self.db.query(QualityIssue).filter(QualityIssue.id == issue_id).first()
        if issue:
            issue.status = status
            if resolution:
                issue.resolution = resolution
            if status == 'resolved':
                issue.resolved_at = datetime.utcnow()
            issue.updated_at = datetime.utcnow()
            self.db.commit()
            self.db.refresh(issue)
        return issue
    
    # Métodos para QualityReport
    def get_reports_by_entity(self, entity_id: str) -> List[QualityReport]:
        """Obtém relatórios por entidade"""
        return self.db.query(QualityReport).filter(
            QualityReport.entity_id == entity_id
        ).order_by(desc(QualityReport.created_at)).all()
    
    def get_latest_report(self, entity_id: str) -> Optional[QualityReport]:
        """Obtém relatório mais recente"""
        return self.db.query(QualityReport).filter(
            QualityReport.entity_id == entity_id
        ).order_by(desc(QualityReport.created_at)).first()
    
    def create_report(self, report_data: Dict[str, Any]) -> QualityReport:
        """Cria novo relatório de qualidade"""
        report = QualityReport(**report_data)
        self.db.add(report)
        self.db.commit()
        self.db.refresh(report)
        return report
    
    # Métodos para QualityThreshold
    def get_thresholds_by_entity(self, entity_id: str) -> List[QualityThreshold]:
        """Obtém limites por entidade"""
        return self.db.query(QualityThreshold).filter(
            QualityThreshold.entity_id == entity_id,
            QualityThreshold.is_active == True
        ).all()
    
    def create_threshold(self, threshold_data: Dict[str, Any]) -> QualityThreshold:
        """Cria novo limite de qualidade"""
        threshold = QualityThreshold(**threshold_data)
        self.db.add(threshold)
        self.db.commit()
        self.db.refresh(threshold)
        return threshold
    
    # Métodos para QualityProfile
    def get_profiles_by_entity(self, entity_id: str) -> List[QualityProfile]:
        """Obtém perfis por entidade"""
        return self.db.query(QualityProfile).filter(
            QualityProfile.entity_id == entity_id
        ).all()
    
    def create_profile(self, profile_data: Dict[str, Any]) -> QualityProfile:
        """Cria novo perfil de qualidade"""
        profile = QualityProfile(**profile_data)
        self.db.add(profile)
        self.db.commit()
        self.db.refresh(profile)
        return profile
    
    # Métodos de análise
    def get_quality_score(self, entity_id: str) -> float:
        """Calcula score de qualidade da entidade"""
        metrics = self.get_latest_metrics(entity_id)
        if not metrics:
            return 0.0
        
        total_score = sum(metric.score for metric in metrics if metric.score)
        return total_score / len(metrics) if metrics else 0.0
    
    def get_quality_summary(self, entity_id: str) -> Dict[str, Any]:
        """Obtém resumo de qualidade da entidade"""
        rules_count = self.db.query(func.count(QualityRule.id)).filter(
            QualityRule.entity_id == entity_id,
            QualityRule.is_active == True
        ).scalar()
        
        issues_count = self.db.query(func.count(QualityIssue.id)).filter(
            QualityIssue.entity_id == entity_id,
            QualityIssue.status.in_(['open', 'in_progress'])
        ).scalar()
        
        quality_score = self.get_quality_score(entity_id)
        
        return {
            'entity_id': entity_id,
            'quality_score': quality_score,
            'active_rules': rules_count,
            'open_issues': issues_count,
            'last_check': datetime.utcnow().isoformat()
        }
    
    def get_quality_trends_summary(self, days: int = 30) -> Dict[str, Any]:
        """Obtém resumo de tendências de qualidade"""
        start_date = datetime.utcnow() - timedelta(days=days)
        
        total_metrics = self.db.query(func.count(QualityMetric.id)).filter(
            QualityMetric.created_at >= start_date
        ).scalar()
        
        avg_score = self.db.query(func.avg(QualityMetric.score)).filter(
            QualityMetric.created_at >= start_date,
            QualityMetric.score.isnot(None)
        ).scalar()
        
        total_issues = self.db.query(func.count(QualityIssue.id)).filter(
            QualityIssue.created_at >= start_date
        ).scalar()
        
        return {
            'period_days': days,
            'total_metrics': total_metrics or 0,
            'average_score': float(avg_score) if avg_score else 0.0,
            'total_issues': total_issues or 0,
            'generated_at': datetime.utcnow().isoformat()
        }

