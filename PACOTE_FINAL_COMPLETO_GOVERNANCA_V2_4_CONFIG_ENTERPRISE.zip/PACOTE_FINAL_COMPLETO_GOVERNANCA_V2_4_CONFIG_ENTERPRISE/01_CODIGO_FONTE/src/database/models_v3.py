"""
Modelos SQLAlchemy para a API de Governança de Dados V3.0
Padronizações: created_at/updated_at obrigatórios, text, timestamptz
"""

from datetime import datetime
from typing import Any, Dict, List, Optional
from uuid import uuid4

from sqlalchemy import (
    BigInteger,
    UniqueConstraint,
    Index,
    ARRAY,
    Boolean,
    DateTime,
    ForeignKey,
    Integer,
    Numeric,
    Text,
    func,
)
from sqlalchemy.dialects.postgresql import INET, JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from src.database.connection import Base


class TimestampMixin:
    """Mixin para campos de timestamp obrigatórios em V3"""
    
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
        index=True
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
        index=True
    )


class UserTrackingMixin:
    """Mixin para rastreamento de usuário"""
    
    created_by: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id"),
        nullable=True
    )
    updated_by: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id"),
        nullable=True
    )


# ========================================
# AUTENTICAÇÃO E USUÁRIOS
# ========================================

class User(Base, TimestampMixin):
    """Modelo de usuário V3"""
    
    __tablename__ = "users"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    username: Mapped[str] = mapped_column(Text, unique=True, nullable=False)
    email: Mapped[str] = mapped_column(Text, unique=True, nullable=False)
    full_name: Mapped[Optional[str]] = mapped_column(Text)
    hashed_password: Mapped[str] = mapped_column(Text, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    is_admin: Mapped[bool] = mapped_column(Boolean, default=False)
    last_login: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    
    # Indexes
    __table_args__ = (
        Index('idx_users_username', 'username'),
        Index('idx_users_email', 'email'),
        Index('idx_users_is_active', 'is_active'),
        Index('idx_users_created_at', 'created_at'),
        Index('idx_users_updated_at', 'updated_at'),
    )


# ========================================
# AUDIT LOGS DETALHADOS
# ========================================

class AuditLog(Base, TimestampMixin):
    """Logs de auditoria V3"""
    
    __tablename__ = "audit_logs"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    user_id: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id")
    )
    event_type: Mapped[str] = mapped_column(Text, nullable=False)
    resource_type: Mapped[str] = mapped_column(Text, nullable=False)
    resource_id: Mapped[Optional[str]] = mapped_column(Text)
    action: Mapped[str] = mapped_column(Text, nullable=False)
    old_values: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    new_values: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    ip_address: Mapped[Optional[str]] = mapped_column(INET)
    user_agent: Mapped[Optional[str]] = mapped_column(Text)
    endpoint: Mapped[Optional[str]] = mapped_column(Text)
    http_method: Mapped[Optional[str]] = mapped_column(Text)
    status_code: Mapped[Optional[int]] = mapped_column(Integer)
    correlation_id: Mapped[Optional[UUID]] = mapped_column(UUID(as_uuid=True))
    session_id: Mapped[Optional[str]] = mapped_column(Text)
    additional_context: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Indexes
    __table_args__ = (
        Index('idx_audit_logs_user_id', 'user_id'),
        Index('idx_audit_logs_event_type', 'event_type'),
        Index('idx_audit_logs_resource_type', 'resource_type'),
        Index('idx_audit_logs_action', 'action'),
        Index('idx_audit_logs_correlation_id', 'correlation_id'),
        Index('idx_audit_logs_resource_type_id', 'resource_type', 'resource_id'),
        Index('idx_audit_logs_created_at', 'created_at'),
        Index('idx_audit_logs_updated_at', 'updated_at'),
    )


# ========================================
# RATE LIMITING
# ========================================

class RateLimitPolicy(Base, TimestampMixin):
    """Políticas de rate limiting V3"""
    
    __tablename__ = "rate_limit_policies"
    
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(Text, nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)
    user_id: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id")
    )
    user_role: Mapped[Optional[str]] = mapped_column(Text)
    endpoint_pattern: Mapped[Optional[str]] = mapped_column(Text)
    requests_per_minute: Mapped[int] = mapped_column(Integer, default=60)
    requests_per_hour: Mapped[int] = mapped_column(Integer, default=1000)
    requests_per_day: Mapped[int] = mapped_column(Integer, default=10000)
    burst_limit: Mapped[int] = mapped_column(Integer, default=10)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    
    # Indexes
    __table_args__ = (
        Index('idx_rate_limit_policies_user_id', 'user_id'),
        Index('idx_rate_limit_policies_user_role', 'user_role'),
        Index('idx_rate_limit_policies_endpoint_pattern', 'endpoint_pattern'),
        Index('idx_rate_limit_policies_is_active', 'is_active'),
        Index('idx_rate_limit_policies_created_at', 'created_at'),
        Index('idx_rate_limit_policies_updated_at', 'updated_at'),
    )


class RateLimitViolation(Base, TimestampMixin):
    """Violações de rate limiting V3"""
    
    __tablename__ = "rate_limit_violations"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    user_id: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id")
    )
    ip_address: Mapped[str] = mapped_column(INET, nullable=False)
    endpoint: Mapped[str] = mapped_column(Text, nullable=False)
    limit_type: Mapped[str] = mapped_column(Text, nullable=False)
    limit_value: Mapped[int] = mapped_column(Integer, nullable=False)
    actual_requests: Mapped[int] = mapped_column(Integer, nullable=False)
    time_window: Mapped[str] = mapped_column(Text, nullable=False)
    violation_time: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), 
        nullable=False
    )
    blocked_duration_seconds: Mapped[Optional[int]] = mapped_column(Integer)
    
    # Indexes
    __table_args__ = (
        Index('idx_rate_limit_violations_user_id', 'user_id'),
        Index('idx_rate_limit_violations_ip_address', 'ip_address'),
        Index('idx_rate_limit_violations_endpoint', 'endpoint'),
        Index('idx_rate_limit_violations_violation_time', 'violation_time'),
        Index('idx_rate_limit_violations_created_at', 'created_at'),
        Index('idx_rate_limit_violations_updated_at', 'updated_at'),
    )


# ========================================
# DOMÍNIOS DE DADOS
# ========================================

class Domain(Base, TimestampMixin):
    """Domínios funcionais V3"""
    
    __tablename__ = "domains"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    name: Mapped[str] = mapped_column(Text, unique=True, nullable=False)
    display_name: Mapped[str] = mapped_column(Text, nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)
    steward_id: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id")
    )
    parent_domain_id: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("domains.id")
    )
    domain_type: Mapped[str] = mapped_column(Text, default='business')
    status: Mapped[str] = mapped_column(Text, default='active')
    metadata: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Indexes
    __table_args__ = (
        Index('idx_domains_name', 'name'),
        Index('idx_domains_steward_id', 'steward_id'),
        Index('idx_domains_parent_domain_id', 'parent_domain_id'),
        Index('idx_domains_status', 'status'),
        Index('idx_domains_created_at', 'created_at'),
        Index('idx_domains_updated_at', 'updated_at'),
    )


# ========================================
# ENTIDADES DE DADOS
# ========================================

class Entity(Base, TimestampMixin):
    """Entidades de dados V3"""
    
    __tablename__ = "entities"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    name: Mapped[str] = mapped_column(Text, unique=True, nullable=False)
    display_name: Mapped[str] = mapped_column(Text, nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)
    domain_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("domains.id"),
        nullable=False
    )
    owner_id: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id")
    )
    entity_type: Mapped[str] = mapped_column(Text, default='table')
    data_classification: Mapped[str] = mapped_column(Text, default='internal')
    unity_catalog_path: Mapped[Optional[str]] = mapped_column(Text)
    physical_location: Mapped[Optional[str]] = mapped_column(Text)
    schema_definition: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    status: Mapped[str] = mapped_column(Text, default='active')
    last_accessed_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    access_count: Mapped[int] = mapped_column(Integer, default=0)
    size_bytes: Mapped[Optional[int]] = mapped_column(BigInteger)
    row_count: Mapped[Optional[int]] = mapped_column(BigInteger)
    metadata: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Indexes
    __table_args__ = (
        Index('idx_entities_name', 'name'),
        Index('idx_entities_domain_id', 'domain_id'),
        Index('idx_entities_owner_id', 'owner_id'),
        Index('idx_entities_entity_type', 'entity_type'),
        Index('idx_entities_data_classification', 'data_classification'),
        Index('idx_entities_status', 'status'),
        Index('idx_entities_last_accessed_at', 'last_accessed_at'),
        Index('idx_entities_created_at', 'created_at'),
        Index('idx_entities_updated_at', 'updated_at'),
    )


# ========================================
# ATRIBUTOS DAS ENTIDADES
# ========================================

class EntityAttribute(Base, TimestampMixin):
    """Atributos das entidades V3"""
    
    __tablename__ = "entity_attributes"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    entity_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("entities.id"),
        nullable=False
    )
    name: Mapped[str] = mapped_column(Text, nullable=False)
    display_name: Mapped[Optional[str]] = mapped_column(Text)
    description: Mapped[Optional[str]] = mapped_column(Text)
    data_type: Mapped[str] = mapped_column(Text, nullable=False)
    is_nullable: Mapped[bool] = mapped_column(Boolean, default=True)
    is_primary_key: Mapped[bool] = mapped_column(Boolean, default=False)
    is_foreign_key: Mapped[bool] = mapped_column(Boolean, default=False)
    default_value: Mapped[Optional[str]] = mapped_column(Text)
    max_length: Mapped[Optional[int]] = mapped_column(Integer)
    precision_value: Mapped[Optional[int]] = mapped_column(Integer)
    scale_value: Mapped[Optional[int]] = mapped_column(Integer)
    format_pattern: Mapped[Optional[str]] = mapped_column(Text)
    business_rules: Mapped[Optional[str]] = mapped_column(Text)
    data_classification: Mapped[str] = mapped_column(Text, default='internal')
    is_pii: Mapped[bool] = mapped_column(Boolean, default=False)
    position_order: Mapped[Optional[int]] = mapped_column(Integer)
    metadata: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Indexes
    __table_args__ = (
        Index('idx_entity_attributes_entity_id', 'entity_id'),
        Index('idx_entity_attributes_name', 'name'),
        Index('idx_entity_attributes_data_type', 'data_type'),
        Index('idx_entity_attributes_is_primary_key', 'is_primary_key'),
        Index('idx_entity_attributes_is_foreign_key', 'is_foreign_key'),
        Index('idx_entity_attributes_data_classification', 'data_classification'),
        Index('idx_entity_attributes_is_pii', 'is_pii'),
        Index('idx_entity_attributes_created_at', 'created_at'),
        Index('idx_entity_attributes_updated_at', 'updated_at'),
        UniqueConstraint('entity_id', 'name', name='uq_entity_attributes_entity_name'),
    )


# ========================================
# CONTRATOS DE DADOS (ODCS v3.0.2)
# ========================================

class DataContract(Base, TimestampMixin):
    """Contratos de dados V3"""
    
    __tablename__ = "data_contracts"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    name: Mapped[str] = mapped_column(Text, nullable=False)
    display_name: Mapped[Optional[str]] = mapped_column(Text)
    description: Mapped[Optional[str]] = mapped_column(Text)
    version: Mapped[str] = mapped_column(Text, nullable=False)
    entity_id: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("entities.id")
    )
    domain_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("domains.id"),
        nullable=False
    )
    owner_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id"),
        nullable=False
    )
    contract_type: Mapped[str] = mapped_column(Text, default='data_product')
    status: Mapped[str] = mapped_column(Text, default='draft')
    schema_definition: Mapped[Dict[str, Any]] = mapped_column(JSONB, nullable=False)
    quality_requirements: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    sla_requirements: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    usage_restrictions: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    data_classification: Mapped[str] = mapped_column(Text, default='internal')
    retention_policy: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    contact_info: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    tags: Mapped[Optional[List[str]]] = mapped_column(ARRAY(Text))
    metadata: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Indexes
    __table_args__ = (
        Index('idx_data_contracts_name', 'name'),
        Index('idx_data_contracts_version', 'version'),
        Index('idx_data_contracts_entity_id', 'entity_id'),
        Index('idx_data_contracts_domain_id', 'domain_id'),
        Index('idx_data_contracts_owner_id', 'owner_id'),
        Index('idx_data_contracts_contract_type', 'contract_type'),
        Index('idx_data_contracts_status', 'status'),
        Index('idx_data_contracts_data_classification', 'data_classification'),
        Index('idx_data_contracts_created_at', 'created_at'),
        Index('idx_data_contracts_updated_at', 'updated_at'),
        UniqueConstraint('name', 'version', name='uq_data_contracts_name_version'),
    )


# ========================================
# VERSÕES DOS CONTRATOS
# ========================================

class ContractVersion(Base, TimestampMixin):
    """Versões dos contratos V3"""
    
    __tablename__ = "contract_versions"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    contract_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("data_contracts.id"),
        nullable=False
    )
    version: Mapped[str] = mapped_column(Text, nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)
    schema_definition: Mapped[Dict[str, Any]] = mapped_column(JSONB, nullable=False)
    breaking_changes: Mapped[bool] = mapped_column(Boolean, default=False)
    migration_notes: Mapped[Optional[str]] = mapped_column(Text)
    changelog: Mapped[Optional[str]] = mapped_column(Text)
    is_active: Mapped[bool] = mapped_column(Boolean, default=False)
    approved_by: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id")
    )
    approved_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    retirement_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    
    # Indexes
    __table_args__ = (
        Index('idx_contract_versions_contract_id', 'contract_id'),
        Index('idx_contract_versions_version', 'version'),
        Index('idx_contract_versions_is_active', 'is_active'),
        Index('idx_contract_versions_approved_by', 'approved_by'),
        Index('idx_contract_versions_approved_at', 'approved_at'),
        Index('idx_contract_versions_retirement_date', 'retirement_date'),
        Index('idx_contract_versions_created_at', 'created_at'),
        Index('idx_contract_versions_updated_at', 'updated_at'),
        UniqueConstraint('contract_id', 'version', name='uq_contract_versions_contract_version'),
    )


# ========================================
# QUALIDADE DE DADOS
# ========================================

class QualityRule(Base, TimestampMixin):
    """Regras de qualidade V3"""
    
    __tablename__ = "quality_rules"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    name: Mapped[str] = mapped_column(Text, nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)
    entity_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("entities.id"),
        nullable=False
    )
    attribute_id: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("entity_attributes.id")
    )
    rule_type: Mapped[str] = mapped_column(Text, nullable=False)
    rule_definition: Mapped[Dict[str, Any]] = mapped_column(JSONB, nullable=False)
    severity: Mapped[str] = mapped_column(Text, default='medium')
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    schedule_expression: Mapped[Optional[str]] = mapped_column(Text)
    threshold_value: Mapped[Optional[float]] = mapped_column(Numeric)
    created_by: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id")
    )
    metadata: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Indexes
    __table_args__ = (
        Index('idx_quality_rules_name', 'name'),
        Index('idx_quality_rules_entity_id', 'entity_id'),
        Index('idx_quality_rules_attribute_id', 'attribute_id'),
        Index('idx_quality_rules_rule_type', 'rule_type'),
        Index('idx_quality_rules_severity', 'severity'),
        Index('idx_quality_rules_is_active', 'is_active'),
        Index('idx_quality_rules_created_by', 'created_by'),
        Index('idx_quality_rules_created_at', 'created_at'),
        Index('idx_quality_rules_updated_at', 'updated_at'),
    )


class QualityMetric(Base, TimestampMixin):
    """Métricas de qualidade V3"""
    
    __tablename__ = "quality_metrics"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    rule_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("quality_rules.id"),
        nullable=False
    )
    entity_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("entities.id"),
        nullable=False
    )
    metric_value: Mapped[float] = mapped_column(Numeric, nullable=False)
    status: Mapped[str] = mapped_column(Text, nullable=False)
    details: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    measured_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), 
        nullable=False
    )
    execution_time_ms: Mapped[Optional[int]] = mapped_column(Integer)
    records_processed: Mapped[Optional[int]] = mapped_column(BigInteger)
    records_failed: Mapped[Optional[int]] = mapped_column(BigInteger)
    
    # Indexes
    __table_args__ = (
        Index('idx_quality_metrics_rule_id', 'rule_id'),
        Index('idx_quality_metrics_entity_id', 'entity_id'),
        Index('idx_quality_metrics_status', 'status'),
        Index('idx_quality_metrics_measured_at', 'measured_at'),
        Index('idx_quality_metrics_created_at', 'created_at'),
        Index('idx_quality_metrics_updated_at', 'updated_at'),
    )


class QualityIncident(Base, TimestampMixin):
    """Incidentes de qualidade V3"""
    
    __tablename__ = "quality_incidents"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    entity_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("entities.id"),
        nullable=False
    )
    rule_id: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("quality_rules.id")
    )
    incident_type: Mapped[str] = mapped_column(Text, nullable=False)
    severity: Mapped[str] = mapped_column(Text, nullable=False)
    status: Mapped[str] = mapped_column(Text, default='open')
    title: Mapped[str] = mapped_column(Text, nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)
    detected_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), 
        nullable=False
    )
    assigned_to: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id")
    )
    resolved_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    resolution_notes: Mapped[Optional[str]] = mapped_column(Text)
    impact_assessment: Mapped[Optional[str]] = mapped_column(Text)
    root_cause: Mapped[Optional[str]] = mapped_column(Text)
    metadata: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Indexes
    __table_args__ = (
        Index('idx_quality_incidents_entity_id', 'entity_id'),
        Index('idx_quality_incidents_rule_id', 'rule_id'),
        Index('idx_quality_incidents_incident_type', 'incident_type'),
        Index('idx_quality_incidents_severity', 'severity'),
        Index('idx_quality_incidents_status', 'status'),
        Index('idx_quality_incidents_detected_at', 'detected_at'),
        Index('idx_quality_incidents_assigned_to', 'assigned_to'),
        Index('idx_quality_incidents_resolved_at', 'resolved_at'),
        Index('idx_quality_incidents_created_at', 'created_at'),
        Index('idx_quality_incidents_updated_at', 'updated_at'),
    )


# ========================================
# LINEAGE E RELACIONAMENTOS
# ========================================

class LineageRelationship(Base, TimestampMixin):
    """Relacionamentos de lineage V3"""
    
    __tablename__ = "lineage_relationships"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    source_entity_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("entities.id"),
        nullable=False
    )
    target_entity_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("entities.id"),
        nullable=False
    )
    relationship_type: Mapped[str] = mapped_column(Text, nullable=False)
    transformation_logic: Mapped[Optional[str]] = mapped_column(Text)
    pipeline_name: Mapped[Optional[str]] = mapped_column(Text)
    pipeline_id: Mapped[Optional[str]] = mapped_column(Text)
    confidence_score: Mapped[float] = mapped_column(Numeric, default=1.0)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    discovered_method: Mapped[str] = mapped_column(Text, default='manual')
    metadata: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Indexes
    __table_args__ = (
        Index('idx_lineage_relationships_source_entity_id', 'source_entity_id'),
        Index('idx_lineage_relationships_target_entity_id', 'target_entity_id'),
        Index('idx_lineage_relationships_relationship_type', 'relationship_type'),
        Index('idx_lineage_relationships_pipeline_name', 'pipeline_name'),
        Index('idx_lineage_relationships_is_active', 'is_active'),
        Index('idx_lineage_relationships_discovered_method', 'discovered_method'),
        Index('idx_lineage_relationships_created_at', 'created_at'),
        Index('idx_lineage_relationships_updated_at', 'updated_at'),
        UniqueConstraint(
            'source_entity_id', 
            'target_entity_id', 
            'relationship_type', 
            name='uq_lineage_relationships_source_target_type'
        ),
    )


class AttributeLineage(Base, TimestampMixin):
    """Lineage de atributos V3"""
    
    __tablename__ = "attribute_lineage"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    source_attribute_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("entity_attributes.id"),
        nullable=False
    )
    target_attribute_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("entity_attributes.id"),
        nullable=False
    )
    lineage_relationship_id: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("lineage_relationships.id")
    )
    transformation_type: Mapped[Optional[str]] = mapped_column(Text)
    transformation_logic: Mapped[Optional[str]] = mapped_column(Text)
    confidence_score: Mapped[float] = mapped_column(Numeric, default=1.0)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    metadata: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Indexes
    __table_args__ = (
        Index('idx_attribute_lineage_source_attribute_id', 'source_attribute_id'),
        Index('idx_attribute_lineage_target_attribute_id', 'target_attribute_id'),
        Index('idx_attribute_lineage_lineage_relationship_id', 'lineage_relationship_id'),
        Index('idx_attribute_lineage_transformation_type', 'transformation_type'),
        Index('idx_attribute_lineage_is_active', 'is_active'),
        Index('idx_attribute_lineage_created_at', 'created_at'),
        Index('idx_attribute_lineage_updated_at', 'updated_at'),
        UniqueConstraint(
            'source_attribute_id', 
            'target_attribute_id', 
            name='uq_attribute_lineage_source_target'
        ),
    )


# ========================================
# TAGS E CLASSIFICAÇÃO
# ========================================

class Tag(Base, TimestampMixin):
    """Tags para classificação V3"""
    
    __tablename__ = "tags"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    name: Mapped[str] = mapped_column(Text, unique=True, nullable=False)
    display_name: Mapped[Optional[str]] = mapped_column(Text)
    description: Mapped[Optional[str]] = mapped_column(Text)
    tag_type: Mapped[str] = mapped_column(Text, default='business')
    category: Mapped[Optional[str]] = mapped_column(Text)
    color: Mapped[Optional[str]] = mapped_column(Text)
    icon: Mapped[Optional[str]] = mapped_column(Text)
    usage_count: Mapped[int] = mapped_column(Integer, default=0)
    is_system_tag: Mapped[bool] = mapped_column(Boolean, default=False)
    created_by: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id")
    )
    metadata: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Indexes
    __table_args__ = (
        Index('idx_tags_name', 'name'),
        Index('idx_tags_tag_type', 'tag_type'),
        Index('idx_tags_category', 'category'),
        Index('idx_tags_is_system_tag', 'is_system_tag'),
        Index('idx_tags_created_by', 'created_by'),
        Index('idx_tags_usage_count', 'usage_count'),
        Index('idx_tags_created_at', 'created_at'),
        Index('idx_tags_updated_at', 'updated_at'),
    )


class EntityTag(Base, TimestampMixin):
    """Associação entre entidades e tags V3"""
    
    __tablename__ = "entity_tags"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    entity_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("entities.id"),
        nullable=False
    )
    tag_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("tags.id"),
        nullable=False
    )
    tagged_by: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id")
    )
    is_auto_generated: Mapped[bool] = mapped_column(Boolean, default=False)
    confidence_score: Mapped[float] = mapped_column(Numeric, default=1.0)
    metadata: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Indexes
    __table_args__ = (
        Index('idx_entity_tags_entity_id', 'entity_id'),
        Index('idx_entity_tags_tag_id', 'tag_id'),
        Index('idx_entity_tags_tagged_by', 'tagged_by'),
        Index('idx_entity_tags_is_auto_generated', 'is_auto_generated'),
        Index('idx_entity_tags_created_at', 'created_at'),
        Index('idx_entity_tags_updated_at', 'updated_at'),
        UniqueConstraint('entity_id', 'tag_id', name='uq_entity_tags_entity_tag'),
    )


# ========================================
# GLOSSÁRIO DE NEGÓCIO
# ========================================

class BusinessGlossary(Base, TimestampMixin):
    """Glossário de termos de negócio V3"""
    
    __tablename__ = "business_glossary"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    term: Mapped[str] = mapped_column(Text, unique=True, nullable=False)
    definition: Mapped[str] = mapped_column(Text, nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)
    category: Mapped[Optional[str]] = mapped_column(Text)
    domain_id: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("domains.id")
    )
    owner_id: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id")
    )
    status: Mapped[str] = mapped_column(Text, default='active')
    synonyms: Mapped[Optional[List[str]]] = mapped_column(ARRAY(Text))
    related_terms: Mapped[Optional[List[str]]] = mapped_column(ARRAY(Text))
    business_context: Mapped[Optional[str]] = mapped_column(Text)
    technical_context: Mapped[Optional[str]] = mapped_column(Text)
    examples: Mapped[Optional[List[str]]] = mapped_column(ARRAY(Text))
    metadata: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Indexes
    __table_args__ = (
        Index('idx_business_glossary_term', 'term'),
        Index('idx_business_glossary_category', 'category'),
        Index('idx_business_glossary_domain_id', 'domain_id'),
        Index('idx_business_glossary_owner_id', 'owner_id'),
        Index('idx_business_glossary_status', 'status'),
        Index('idx_business_glossary_created_at', 'created_at'),
        Index('idx_business_glossary_updated_at', 'updated_at'),
    )


# ========================================
# MÉTRICAS DE USO
# ========================================

class UsageMetric(Base, TimestampMixin):
    """Métricas de uso V3"""
    
    __tablename__ = "usage_metrics"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    entity_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("entities.id"),
        nullable=False
    )
    user_id: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id")
    )
    access_type: Mapped[str] = mapped_column(Text, nullable=False)
    access_method: Mapped[Optional[str]] = mapped_column(Text)
    query_hash: Mapped[Optional[str]] = mapped_column(Text)
    execution_time_ms: Mapped[Optional[int]] = mapped_column(Integer)
    bytes_transferred: Mapped[Optional[int]] = mapped_column(BigInteger)
    records_returned: Mapped[Optional[int]] = mapped_column(BigInteger)
    success: Mapped[bool] = mapped_column(Boolean, default=True)
    error_message: Mapped[Optional[str]] = mapped_column(Text)
    ip_address: Mapped[Optional[str]] = mapped_column(INET)
    user_agent: Mapped[Optional[str]] = mapped_column(Text)
    session_id: Mapped[Optional[str]] = mapped_column(Text)
    accessed_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), 
        nullable=False
    )
    
    # Indexes
    __table_args__ = (
        Index('idx_usage_metrics_entity_id', 'entity_id'),
        Index('idx_usage_metrics_user_id', 'user_id'),
        Index('idx_usage_metrics_access_type', 'access_type'),
        Index('idx_usage_metrics_accessed_at', 'accessed_at'),
        Index('idx_usage_metrics_success', 'success'),
        Index('idx_usage_metrics_query_hash', 'query_hash'),
        Index('idx_usage_metrics_created_at', 'created_at'),
        Index('idx_usage_metrics_updated_at', 'updated_at'),
    )


# ========================================
# WORKFLOWS E APROVAÇÕES
# ========================================

class Workflow(Base, TimestampMixin):
    """Workflows de aprovação V3"""
    
    __tablename__ = "workflows"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    name: Mapped[str] = mapped_column(Text, nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)
    workflow_type: Mapped[str] = mapped_column(Text, nullable=False)
    definition: Mapped[Dict[str, Any]] = mapped_column(JSONB, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_by: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id")
    )
    metadata: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Indexes
    __table_args__ = (
        Index('idx_workflows_name', 'name'),
        Index('idx_workflows_workflow_type', 'workflow_type'),
        Index('idx_workflows_is_active', 'is_active'),
        Index('idx_workflows_created_by', 'created_by'),
        Index('idx_workflows_created_at', 'created_at'),
        Index('idx_workflows_updated_at', 'updated_at'),
    )


class WorkflowInstance(Base, TimestampMixin):
    """Instâncias de workflow V3"""
    
    __tablename__ = "workflow_instances"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    workflow_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("workflows.id"),
        nullable=False
    )
    resource_type: Mapped[str] = mapped_column(Text, nullable=False)
    resource_id: Mapped[UUID] = mapped_column(UUID(as_uuid=True), nullable=False)
    status: Mapped[str] = mapped_column(Text, default='pending')
    current_step: Mapped[Optional[str]] = mapped_column(Text)
    current_approver: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id")
    )
    started_by: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id"),
        nullable=False
    )
    started_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), 
        nullable=False
    )
    completed_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    data: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    history: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    metadata: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Indexes
    __table_args__ = (
        Index('idx_workflow_instances_workflow_id', 'workflow_id'),
        Index('idx_workflow_instances_resource_type', 'resource_type'),
        Index('idx_workflow_instances_resource_id', 'resource_id'),
        Index('idx_workflow_instances_status', 'status'),
        Index('idx_workflow_instances_current_approver', 'current_approver'),
        Index('idx_workflow_instances_started_by', 'started_by'),
        Index('idx_workflow_instances_started_at', 'started_at'),
        Index('idx_workflow_instances_completed_at', 'completed_at'),
        Index('idx_workflow_instances_created_at', 'created_at'),
        Index('idx_workflow_instances_updated_at', 'updated_at'),
    )


# ========================================
# REFERÊNCIAS EXTERNAS
# ========================================

class ExternalReference(Base, TimestampMixin):
    """Referências externas V3"""
    
    __tablename__ = "external_references"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    name: Mapped[str] = mapped_column(Text, nullable=False)
    reference_type: Mapped[str] = mapped_column(Text, nullable=False)
    connection_string: Mapped[Optional[str]] = mapped_column(Text)
    configuration: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    status: Mapped[str] = mapped_column(Text, default='active')
    last_tested_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    test_result: Mapped[Optional[str]] = mapped_column(Text)
    created_by: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id")
    )
    metadata: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Indexes
    __table_args__ = (
        Index('idx_external_references_name', 'name'),
        Index('idx_external_references_reference_type', 'reference_type'),
        Index('idx_external_references_status', 'status'),
        Index('idx_external_references_last_tested_at', 'last_tested_at'),
        Index('idx_external_references_created_by', 'created_by'),
        Index('idx_external_references_created_at', 'created_at'),
        Index('idx_external_references_updated_at', 'updated_at'),
    )


class IntegrationConfig(Base, TimestampMixin):
    """Configurações de integração V3"""
    
    __tablename__ = "integration_configs"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    integration_name: Mapped[str] = mapped_column(Text, nullable=False)
    integration_type: Mapped[str] = mapped_column(Text, nullable=False)
    endpoint_url: Mapped[Optional[str]] = mapped_column(Text)
    authentication_config: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    sync_frequency: Mapped[Optional[str]] = mapped_column(Text)
    last_sync_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    last_sync_status: Mapped[Optional[str]] = mapped_column(Text)
    error_count: Mapped[int] = mapped_column(Integer, default=0)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_by: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id")
    )
    metadata: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Indexes
    __table_args__ = (
        Index('idx_integration_configs_integration_name', 'integration_name'),
        Index('idx_integration_configs_integration_type', 'integration_type'),
        Index('idx_integration_configs_last_sync_at', 'last_sync_at'),
        Index('idx_integration_configs_last_sync_status', 'last_sync_status'),
        Index('idx_integration_configs_is_active', 'is_active'),
        Index('idx_integration_configs_created_by', 'created_by'),
        Index('idx_integration_configs_created_at', 'created_at'),
        Index('idx_integration_configs_updated_at', 'updated_at'),
    )


# ========================================
# PERFORMANCE E MONITORAMENTO
# ========================================

class PerformanceMetric(Base, TimestampMixin):
    """Métricas de performance V3"""
    
    __tablename__ = "performance_metrics"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    metric_name: Mapped[str] = mapped_column(Text, nullable=False)
    metric_type: Mapped[str] = mapped_column(Text, nullable=False)
    metric_value: Mapped[float] = mapped_column(Numeric, nullable=False)
    unit: Mapped[Optional[str]] = mapped_column(Text)
    entity_id: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("entities.id")
    )
    resource_type: Mapped[Optional[str]] = mapped_column(Text)
    resource_id: Mapped[Optional[str]] = mapped_column(Text)
    measured_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), 
        nullable=False
    )
    tags: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    metadata: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Indexes
    __table_args__ = (
        Index('idx_performance_metrics_metric_name', 'metric_name'),
        Index('idx_performance_metrics_metric_type', 'metric_type'),
        Index('idx_performance_metrics_entity_id', 'entity_id'),
        Index('idx_performance_metrics_resource_type', 'resource_type'),
        Index('idx_performance_metrics_measured_at', 'measured_at'),
        Index('idx_performance_metrics_created_at', 'created_at'),
        Index('idx_performance_metrics_updated_at', 'updated_at'),
    )


class SystemHealth(Base, TimestampMixin):
    """Saúde do sistema V3"""
    
    __tablename__ = "system_health"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    component_name: Mapped[str] = mapped_column(Text, nullable=False)
    component_type: Mapped[str] = mapped_column(Text, nullable=False)
    status: Mapped[str] = mapped_column(Text, nullable=False)
    health_score: Mapped[Optional[float]] = mapped_column(Numeric)
    response_time_ms: Mapped[Optional[int]] = mapped_column(Integer)
    error_rate: Mapped[Optional[float]] = mapped_column(Numeric)
    last_check_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), 
        nullable=False
    )
    details: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    metadata: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Indexes
    __table_args__ = (
        Index('idx_system_health_component_name', 'component_name'),
        Index('idx_system_health_component_type', 'component_type'),
        Index('idx_system_health_status', 'status'),
        Index('idx_system_health_last_check_at', 'last_check_at'),
        Index('idx_system_health_created_at', 'created_at'),
        Index('idx_system_health_updated_at', 'updated_at'),
    )


# ========================================
# CACHE E OTIMIZAÇÃO
# ========================================

class CacheEntry(Base, TimestampMixin):
    """Entradas de cache V3"""
    
    __tablename__ = "cache_entries"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    cache_key: Mapped[str] = mapped_column(Text, unique=True, nullable=False)
    cache_value: Mapped[Dict[str, Any]] = mapped_column(JSONB, nullable=False)
    entity_id: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("entities.id")
    )
    ttl_seconds: Mapped[int] = mapped_column(Integer, default=3600)
    hit_count: Mapped[int] = mapped_column(Integer, default=0)
    last_accessed_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    expires_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), 
        nullable=False
    )
    
    # Indexes
    __table_args__ = (
        Index('idx_cache_entries_cache_key', 'cache_key'),
        Index('idx_cache_entries_entity_id', 'entity_id'),
        Index('idx_cache_entries_expires_at', 'expires_at'),
        Index('idx_cache_entries_last_accessed_at', 'last_accessed_at'),
        Index('idx_cache_entries_created_at', 'created_at'),
        Index('idx_cache_entries_updated_at', 'updated_at'),
    )


class QueryOptimization(Base, TimestampMixin):
    """Otimização de queries V3"""
    
    __tablename__ = "query_optimization"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    query_hash: Mapped[str] = mapped_column(Text, unique=True, nullable=False)
    original_query: Mapped[str] = mapped_column(Text, nullable=False)
    optimized_query: Mapped[Optional[str]] = mapped_column(Text)
    execution_plan: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    avg_execution_time_ms: Mapped[Optional[int]] = mapped_column(Integer)
    optimization_suggestions: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    usage_count: Mapped[int] = mapped_column(Integer, default=1)
    last_used_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), 
        nullable=False
    )
    
    # Indexes
    __table_args__ = (
        Index('idx_query_optimization_query_hash', 'query_hash'),
        Index('idx_query_optimization_avg_execution_time_ms', 'avg_execution_time_ms'),
        Index('idx_query_optimization_usage_count', 'usage_count'),
        Index('idx_query_optimization_last_used_at', 'last_used_at'),
        Index('idx_query_optimization_created_at', 'created_at'),
        Index('idx_query_optimization_updated_at', 'updated_at'),
    )


# ========================================
# NOTIFICAÇÕES E ALERTAS
# ========================================

class Notification(Base, TimestampMixin):
    """Notificações V3"""
    
    __tablename__ = "notifications"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    user_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id"),
        nullable=False
    )
    notification_type: Mapped[str] = mapped_column(Text, nullable=False)
    title: Mapped[str] = mapped_column(Text, nullable=False)
    message: Mapped[str] = mapped_column(Text, nullable=False)
    priority: Mapped[str] = mapped_column(Text, default='medium')
    status: Mapped[str] = mapped_column(Text, default='unread')
    resource_type: Mapped[Optional[str]] = mapped_column(Text)
    resource_id: Mapped[Optional[UUID]] = mapped_column(UUID(as_uuid=True))
    action_url: Mapped[Optional[str]] = mapped_column(Text)
    read_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    expires_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    metadata: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Indexes
    __table_args__ = (
        Index('idx_notifications_user_id', 'user_id'),
        Index('idx_notifications_notification_type', 'notification_type'),
        Index('idx_notifications_status', 'status'),
        Index('idx_notifications_priority', 'priority'),
        Index('idx_notifications_read_at', 'read_at'),
        Index('idx_notifications_expires_at', 'expires_at'),
        Index('idx_notifications_created_at', 'created_at'),
        Index('idx_notifications_updated_at', 'updated_at'),
    )


class AlertRule(Base, TimestampMixin):
    """Regras de alerta V3"""
    
    __tablename__ = "alert_rules"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    name: Mapped[str] = mapped_column(Text, nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)
    rule_type: Mapped[str] = mapped_column(Text, nullable=False)
    condition_expression: Mapped[str] = mapped_column(Text, nullable=False)
    threshold_value: Mapped[Optional[float]] = mapped_column(Numeric)
    severity: Mapped[str] = mapped_column(Text, default='medium')
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    notification_channels: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    created_by: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id")
    )
    metadata: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Indexes
    __table_args__ = (
        Index('idx_alert_rules_name', 'name'),
        Index('idx_alert_rules_rule_type', 'rule_type'),
        Index('idx_alert_rules_severity', 'severity'),
        Index('idx_alert_rules_is_active', 'is_active'),
        Index('idx_alert_rules_created_by', 'created_by'),
        Index('idx_alert_rules_created_at', 'created_at'),
        Index('idx_alert_rules_updated_at', 'updated_at'),
    )


class AlertInstance(Base, TimestampMixin):
    """Instâncias de alerta V3"""
    
    __tablename__ = "alert_instances"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    alert_rule_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("alert_rules.id"),
        nullable=False
    )
    status: Mapped[str] = mapped_column(Text, default='active')
    triggered_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), 
        nullable=False
    )
    resolved_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    current_value: Mapped[Optional[float]] = mapped_column(Numeric)
    threshold_value: Mapped[Optional[float]] = mapped_column(Numeric)
    message: Mapped[Optional[str]] = mapped_column(Text)
    acknowledged_by: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id")
    )
    acknowledged_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    metadata: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Indexes
    __table_args__ = (
        Index('idx_alert_instances_alert_rule_id', 'alert_rule_id'),
        Index('idx_alert_instances_status', 'status'),
        Index('idx_alert_instances_triggered_at', 'triggered_at'),
        Index('idx_alert_instances_resolved_at', 'resolved_at'),
        Index('idx_alert_instances_acknowledged_by', 'acknowledged_by'),
        Index('idx_alert_instances_created_at', 'created_at'),
        Index('idx_alert_instances_updated_at', 'updated_at'),
    )


# ========================================
# CONFIGURAÇÕES DO SISTEMA
# ========================================

class SystemConfiguration(Base, TimestampMixin):
    """Configurações do sistema V3"""
    
    __tablename__ = "system_configurations"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    config_key: Mapped[str] = mapped_column(Text, unique=True, nullable=False)
    config_value: Mapped[Dict[str, Any]] = mapped_column(JSONB, nullable=False)
    config_type: Mapped[str] = mapped_column(Text, nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)
    is_sensitive: Mapped[bool] = mapped_column(Boolean, default=False)
    is_system_config: Mapped[bool] = mapped_column(Boolean, default=False)
    validation_rules: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    created_by: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id")
    )
    metadata: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Indexes
    __table_args__ = (
        Index('idx_system_configurations_config_key', 'config_key'),
        Index('idx_system_configurations_config_type', 'config_type'),
        Index('idx_system_configurations_is_sensitive', 'is_sensitive'),
        Index('idx_system_configurations_is_system_config', 'is_system_config'),
        Index('idx_system_configurations_created_by', 'created_by'),
        Index('idx_system_configurations_created_at', 'created_at'),
        Index('idx_system_configurations_updated_at', 'updated_at'),
    )

