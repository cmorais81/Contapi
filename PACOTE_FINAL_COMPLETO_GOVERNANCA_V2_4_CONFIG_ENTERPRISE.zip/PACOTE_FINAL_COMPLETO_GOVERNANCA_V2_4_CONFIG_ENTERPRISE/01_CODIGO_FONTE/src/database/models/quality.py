"""
Modelos de Qualidade de Dados
API de Governança de Dados V1.9
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from sqlalchemy import Column, String, Text, Boolean, Integer, DateTime, ForeignKey, Enum as SQLEnum, Float
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import relationship
from enum import Enum
from ..base import Base

class RuleType(Enum):
    COMPLETENESS = "completeness"
    UNIQUENESS = "uniqueness"
    VALIDITY = "validity"
    CONSISTENCY = "consistency"
    ACCURACY = "accuracy"
    TIMELINESS = "timeliness"
    CUSTOM = "custom"

class Severity(Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class IssueStatus(Enum):
    OPEN = "open"
    IN_PROGRESS = "in_progress"
    RESOLVED = "resolved"
    CLOSED = "closed"
    IGNORED = "ignored"

class QualityRule(Base):
    """Regras de qualidade de dados"""
    __tablename__ = 'quality_rules'
    __table_args__ = {'extend_existing': True}
    
    name = Column(String(255), nullable=False, comment='Nome da regra de qualidade')
    description = Column(Text, comment='Descrição detalhada da regra')
    rule_type = Column(SQLEnum(RuleType), nullable=False, comment='Tipo da regra')
    
    # Configuração da regra
    rule_definition = Column(JSONB, nullable=False, comment='Definição da regra em JSON')
    sql_expression = Column(Text, comment='Expressão SQL para validação')
    threshold_value = Column(Float, comment='Valor limite para aprovação')
    
    # Escopo de aplicação
    entity_id = Column(UUID(as_uuid=True), ForeignKey('entities.id'), comment='Entidade alvo')
    attribute_name = Column(String(255), comment='Atributo específico (opcional)')
    
    # Configurações de execução
    is_active = Column(Boolean, default=True, comment='Regra ativa')
    severity = Column(SQLEnum(Severity), default=Severity.MEDIUM, comment='Severidade da regra')
    schedule_expression = Column(String(255), comment='Expressão cron para execução')
    
    # Metadados
    created_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), nullable=False)
    tags = Column(JSONB, comment='Tags associadas à regra')
    
    # Relacionamentos
    entity = relationship("Entity")
    creator = relationship("User", foreign_keys=[created_by])
    metrics = relationship("QualityMetric", back_populates="rule", cascade="all, delete-orphan")
    issues = relationship("DataQualityIssue", back_populates="rule", cascade="all, delete-orphan")

class QualityMetric(Base):
    """Métricas de qualidade coletadas"""
    __tablename__ = 'quality_metrics'
    __table_args__ = {'extend_existing': True}
    
    rule_id = Column(UUID(as_uuid=True), ForeignKey('quality_rules.id'), nullable=False)
    entity_id = Column(UUID(as_uuid=True), ForeignKey('entities.id'), nullable=False)
    
    # Resultado da execução
    execution_date = Column(DateTime(timezone=True), nullable=False, comment='Data da execução')
    metric_value = Column(Float, nullable=False, comment='Valor da métrica')
    passed = Column(Boolean, nullable=False, comment='Regra passou na validação')
    
    # Detalhes da execução
    total_records = Column(Integer, comment='Total de registros avaliados')
    failed_records = Column(Integer, comment='Registros que falharam')
    execution_time_ms = Column(Integer, comment='Tempo de execução em ms')
    
    # Contexto adicional
    sample_failed_records = Column(JSONB, comment='Amostra de registros que falharam')
    error_message = Column(Text, comment='Mensagem de erro se houver')
    
    # Relacionamentos
    rule = relationship("QualityRule", back_populates="metrics")
    entity = relationship("Entity")

class DataQualityIssue(Base):
    """Problemas de qualidade identificados"""
    __tablename__ = 'data_quality_issues'
    __table_args__ = {'extend_existing': True}
    
    rule_id = Column(UUID(as_uuid=True), ForeignKey('quality_rules.id'), nullable=False)
    entity_id = Column(UUID(as_uuid=True), ForeignKey('entities.id'), nullable=False)
    
    # Detalhes do problema
    title = Column(String(500), nullable=False, comment='Título do problema')
    description = Column(Text, comment='Descrição detalhada')
    severity = Column(SQLEnum(Severity), nullable=False, comment='Severidade do problema')
    status = Column(SQLEnum(IssueStatus), default=IssueStatus.OPEN, comment='Status do problema')
    
    # Dados do problema
    affected_records = Column(Integer, comment='Número de registros afetados')
    sample_data = Column(JSONB, comment='Amostra de dados problemáticos')
    detection_date = Column(DateTime(timezone=True), nullable=False, comment='Data de detecção')
    
    # Resolução
    assigned_to = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Usuário responsável')
    resolution_notes = Column(Text, comment='Notas sobre a resolução')
    resolved_date = Column(DateTime(timezone=True), comment='Data de resolução')
    
    # Impacto
    business_impact = Column(Text, comment='Impacto no negócio')
    affected_systems = Column(JSONB, comment='Sistemas afetados')
    
    # Relacionamentos
    rule = relationship("QualityRule", back_populates="issues")
    entity = relationship("Entity")
    assignee = relationship("User", foreign_keys=[assigned_to])



class QualityIssue(Base):
    """Issues de qualidade de dados identificados"""
    __tablename__ = 'quality_issues'
    __table_args__ = {'extend_existing': True}
    
    title = Column(String(255), nullable=False, comment='Título do issue')
    description = Column(Text, comment='Descrição detalhada do problema')
    severity = Column(SQLEnum(Severity), nullable=False, comment='Severidade do issue')
    status = Column(SQLEnum(IssueStatus), nullable=False, default=IssueStatus.OPEN, comment='Status do issue')
    
    # Relacionamentos
    rule_id = Column(UUID(as_uuid=True), ForeignKey('quality_rules.id'), comment='Regra que gerou o issue')
    entity_id = Column(UUID(as_uuid=True), ForeignKey('entities.id'), comment='Entidade afetada')
    
    # Detalhes técnicos
    affected_records = Column(Integer, comment='Número de registros afetados')
    error_details = Column(JSONB, comment='Detalhes técnicos do erro')
    
    # Resolução
    resolution_notes = Column(Text, comment='Notas sobre a resolução')
    resolved_at = Column(DateTime, comment='Data de resolução')
    resolved_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Usuário que resolveu')
    
    # Relacionamentos
    rule = relationship("QualityRule", back_populates="issues")
    entity = relationship("Entity", back_populates="quality_issues")
    resolver = relationship("User", foreign_keys=[resolved_by])

# Adicionar relacionamento reverso em QualityRule
QualityRule.issues = relationship("QualityIssue", back_populates="rule")


class QualityReport(Base):
    """Relatórios de qualidade de dados"""
    __tablename__ = 'quality_reports'
    __table_args__ = {'extend_existing': True}
    
    name = Column(String(255), nullable=False, comment='Nome do relatório')
    description = Column(Text, comment='Descrição do relatório')
    report_type = Column(String(50), nullable=False, comment='Tipo de relatório')
    scope = Column(JSONB, comment='Escopo do relatório (entidades, regras, etc.)')
    
    # Período do relatório
    period_start = Column(DateTime, nullable=False, comment='Início do período')
    period_end = Column(DateTime, nullable=False, comment='Fim do período')
    
    # Resultados
    total_entities = Column(Integer, comment='Total de entidades analisadas')
    total_rules = Column(Integer, comment='Total de regras executadas')
    total_issues = Column(Integer, comment='Total de issues encontrados')
    quality_score = Column(Float, comment='Score geral de qualidade (0-100)')
    
    # Detalhes
    summary = Column(JSONB, comment='Resumo executivo')
    metrics = Column(JSONB, comment='Métricas detalhadas')
    recommendations = Column(JSONB, comment='Recomendações')
    
    # Arquivo
    file_path = Column(String(500), comment='Caminho do arquivo gerado')
    file_size = Column(Integer, comment='Tamanho do arquivo em bytes')
    
    # Status
    status = Column(String(20), default='generating', comment='Status da geração')
    generated_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Gerado por')
    
    # Relacionamentos
    generator = relationship("User", foreign_keys=[generated_by])

class QualityTrend(Base):
    """Tendências de qualidade ao longo do tempo"""
    __tablename__ = 'quality_trends'
    __table_args__ = {'extend_existing': True}
    
    entity_id = Column(UUID(as_uuid=True), ForeignKey('entities.id'), comment='Entidade')
    rule_id = Column(UUID(as_uuid=True), ForeignKey('quality_rules.id'), comment='Regra')
    measurement_date = Column(DateTime, nullable=False, comment='Data da medição')
    quality_score = Column(Float, nullable=False, comment='Score de qualidade')
    records_processed = Column(Integer, comment='Registros processados')
    records_passed = Column(Integer, comment='Registros aprovados')
    records_failed = Column(Integer, comment='Registros reprovados')
    execution_time_ms = Column(Float, comment='Tempo de execução em ms')
    
    # Relacionamentos
    entity = relationship("Entity", foreign_keys=[entity_id])
    rule = relationship("QualityRule", foreign_keys=[rule_id])


class QualityThreshold(Base):
    """Limites de qualidade configuráveis"""
    __tablename__ = 'quality_thresholds'
    __table_args__ = {'extend_existing': True}
    
    name = Column(String(255), nullable=False, comment='Nome do threshold')
    description = Column(Text, comment='Descrição do threshold')
    metric_type = Column(String(50), nullable=False, comment='Tipo de métrica')
    
    # Limites
    min_value = Column(Float, comment='Valor mínimo aceitável')
    max_value = Column(Float, comment='Valor máximo aceitável')
    target_value = Column(Float, comment='Valor alvo')
    warning_threshold = Column(Float, comment='Limite para warning')
    critical_threshold = Column(Float, comment='Limite para crítico')
    
    # Configuração
    entity_id = Column(UUID(as_uuid=True), ForeignKey('entities.id'), comment='Entidade específica')
    rule_id = Column(UUID(as_uuid=True), ForeignKey('quality_rules.id'), comment='Regra específica')
    is_active = Column(Boolean, default=True, comment='Status ativo/inativo')
    
    # Relacionamentos
    entity = relationship("Entity", foreign_keys=[entity_id])
    rule = relationship("QualityRule", foreign_keys=[rule_id])

class QualityDashboard(Base):
    """Configurações de dashboard de qualidade"""
    __tablename__ = 'quality_dashboards'
    __table_args__ = {'extend_existing': True}
    
    name = Column(String(255), nullable=False, comment='Nome do dashboard')
    description = Column(Text, comment='Descrição do dashboard')
    owner_id = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Proprietário')
    
    # Configuração
    widgets = Column(JSONB, comment='Configuração dos widgets')
    filters = Column(JSONB, comment='Filtros padrão')
    refresh_interval = Column(Integer, default=300, comment='Intervalo de refresh em segundos')
    
    # Compartilhamento
    is_public = Column(Boolean, default=False, comment='Dashboard público')
    shared_with = Column(JSONB, comment='Usuários com acesso')
    
    # Relacionamentos
    owner = relationship("User", foreign_keys=[owner_id])


class QualityProfile(Base):
    """Perfis de qualidade para diferentes tipos de dados"""
    __tablename__ = 'quality_profiles'
    __table_args__ = {'extend_existing': True}
    
    name = Column(String(255), nullable=False, comment='Nome do perfil')
    description = Column(Text, comment='Descrição do perfil')
    profile_type = Column(String(50), nullable=False, comment='Tipo de perfil (financial, personal, etc.)')
    
    # Configurações
    rules = Column(JSONB, comment='Regras incluídas no perfil')
    thresholds = Column(JSONB, comment='Thresholds específicos')
    validations = Column(JSONB, comment='Validações customizadas')
    
    # Aplicação
    entity_types = Column(JSONB, comment='Tipos de entidades aplicáveis')
    domains = Column(JSONB, comment='Domínios aplicáveis')
    
    # Status
    is_active = Column(Boolean, default=True, comment='Status ativo/inativo')
    is_default = Column(Boolean, default=False, comment='Perfil padrão')
    version = Column(String(20), default='1.0', comment='Versão do perfil')
    
    # Auditoria
    created_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Criado por')
    approved_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Aprovado por')
    approved_at = Column(DateTime, comment='Data de aprovação')
    
    # Relacionamentos
    creator = relationship("User", foreign_keys=[created_by])
    approver = relationship("User", foreign_keys=[approved_by])

