"""
Modelos de Backup e Recuperação
API de Governança de Dados V2.1
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from sqlalchemy import Column, String, Text, Boolean, Integer, DateTime, ForeignKey, Enum as SQLEnum, Float
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import relationship
from enum import Enum
from ..base import Base

class BackupType(Enum):
    FULL = "full"
    INCREMENTAL = "incremental"
    DIFFERENTIAL = "differential"
    METADATA_ONLY = "metadata_only"

class BackupStatus(Enum):
    SCHEDULED = "scheduled"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"

class RecoveryType(Enum):
    FULL_RESTORE = "full_restore"
    PARTIAL_RESTORE = "partial_restore"
    POINT_IN_TIME = "point_in_time"
    METADATA_RESTORE = "metadata_restore"

class RecoveryStatus(Enum):
    PLANNED = "planned"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    TESTED = "tested"

class BackupPolicy(Base):
    """Políticas de backup"""
    __tablename__ = 'backup_policies'
    __table_args__ = {'extend_existing': True}
    
    name = Column(String(255), nullable=False, comment='Nome da política de backup')
    description = Column(Text, comment='Descrição da política')
    
    # Configurações de backup
    backup_type = Column(SQLEnum(BackupType), nullable=False, comment='Tipo de backup')
    schedule_expression = Column(String(255), comment='Expressão cron para agendamento')
    retention_days = Column(Integer, nullable=False, comment='Dias de retenção do backup')
    
    # Escopo do backup
    include_metadata = Column(Boolean, default=True, comment='Incluir metadados')
    include_data = Column(Boolean, default=True, comment='Incluir dados')
    include_configurations = Column(Boolean, default=True, comment='Incluir configurações')
    include_logs = Column(Boolean, default=False, comment='Incluir logs')
    
    # Filtros
    entity_filters = Column(JSONB, comment='Filtros de entidades para backup')
    size_limit_gb = Column(Float, comment='Limite de tamanho em GB')
    
    # Configurações de armazenamento
    storage_location = Column(String(500), comment='Local de armazenamento')
    compression_enabled = Column(Boolean, default=True, comment='Compressão habilitada')
    encryption_enabled = Column(Boolean, default=True, comment='Criptografia habilitada')
    
    # Configurações de notificação
    notify_on_success = Column(Boolean, default=False, comment='Notificar em sucesso')
    notify_on_failure = Column(Boolean, default=True, comment='Notificar em falha')
    notification_recipients = Column(JSONB, comment='Destinatários das notificações')
    
    # Status
    is_active = Column(Boolean, default=True, comment='Política ativa')
    
    # Metadados
    created_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), nullable=False, comment='Criador da política')
    last_execution = Column(DateTime(timezone=True), comment='Última execução')
    next_execution = Column(DateTime(timezone=True), comment='Próxima execução')
    
    # Relacionamentos
    creator = relationship("User", foreign_keys=[created_by])
    executions = relationship("BackupExecution", back_populates="policy", cascade="all, delete-orphan")

class BackupExecution(Base):
    """Execuções de backup"""
    __tablename__ = 'backup_executions'
    __table_args__ = {'extend_existing': True}
    
    policy_id = Column(UUID(as_uuid=True), ForeignKey('backup_policies.id'), nullable=False)
    
    # Identificação
    backup_name = Column(String(255), comment='Nome do backup gerado')
    backup_type = Column(SQLEnum(BackupType), nullable=False, comment='Tipo de backup executado')
    
    # Status e execução
    status = Column(SQLEnum(BackupStatus), default=BackupStatus.SCHEDULED, comment='Status da execução')
    started_at = Column(DateTime(timezone=True), comment='Data de início')
    completed_at = Column(DateTime(timezone=True), comment='Data de conclusão')
    
    # Resultados
    backup_size_bytes = Column(Integer, comment='Tamanho do backup em bytes')
    compressed_size_bytes = Column(Integer, comment='Tamanho comprimido em bytes')
    files_count = Column(Integer, comment='Número de arquivos no backup')
    
    # Estatísticas
    entities_backed_up = Column(Integer, comment='Entidades incluídas no backup')
    records_backed_up = Column(Integer, comment='Registros incluídos no backup')
    duration_seconds = Column(Integer, comment='Duração em segundos')
    
    # Localização
    storage_path = Column(String(500), comment='Caminho do backup no storage')
    checksum = Column(String(255), comment='Checksum do backup')
    
    # Logs e erros
    execution_log = Column(JSONB, comment='Log de execução')
    error_details = Column(Text, comment='Detalhes de erros')
    warnings = Column(JSONB, comment='Avisos durante execução')
    
    # Metadados
    triggered_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Usuário que disparou')
    trigger_type = Column(String(50), comment='Tipo de disparo (scheduled, manual)')
    
    # Relacionamentos
    policy = relationship("BackupPolicy", back_populates="executions")
    trigger_user = relationship("User", foreign_keys=[triggered_by])

class DisasterRecoveryPlan(Base):
    """Planos de recuperação de desastres"""
    __tablename__ = 'disaster_recovery_plans'
    __table_args__ = {'extend_existing': True}
    
    name = Column(String(255), nullable=False, comment='Nome do plano de DR')
    description = Column(Text, comment='Descrição do plano')
    
    # Configurações do plano
    recovery_type = Column(SQLEnum(RecoveryType), nullable=False, comment='Tipo de recuperação')
    priority_level = Column(String(50), comment='Nível de prioridade (critical, high, medium, low)')
    
    # Objetivos de recuperação
    rto_hours = Column(Float, comment='Recovery Time Objective em horas')
    rpo_hours = Column(Float, comment='Recovery Point Objective em horas')
    
    # Procedimentos
    recovery_procedures = Column(JSONB, nullable=False, comment='Procedimentos de recuperação')
    rollback_procedures = Column(JSONB, comment='Procedimentos de rollback')
    validation_steps = Column(JSONB, comment='Passos de validação')
    
    # Recursos necessários
    required_resources = Column(JSONB, comment='Recursos necessários para recuperação')
    contact_list = Column(JSONB, comment='Lista de contatos para emergência')
    
    # Configurações de backup
    backup_sources = Column(JSONB, comment='Fontes de backup para recuperação')
    recovery_location = Column(String(500), comment='Local de recuperação')
    
    # Status e testes
    status = Column(SQLEnum(RecoveryStatus), default=RecoveryStatus.PLANNED, comment='Status do plano')
    last_tested = Column(DateTime(timezone=True), comment='Última data de teste')
    test_results = Column(JSONB, comment='Resultados dos testes')
    
    # Aprovação
    approved_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Aprovador do plano')
    approved_at = Column(DateTime(timezone=True), comment='Data de aprovação')
    
    # Metadados
    created_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), nullable=False, comment='Criador do plano')
    version = Column(String(50), comment='Versão do plano')
    
    # Relacionamentos
    creator = relationship("User", foreign_keys=[created_by])
    approver = relationship("User", foreign_keys=[approved_by])

