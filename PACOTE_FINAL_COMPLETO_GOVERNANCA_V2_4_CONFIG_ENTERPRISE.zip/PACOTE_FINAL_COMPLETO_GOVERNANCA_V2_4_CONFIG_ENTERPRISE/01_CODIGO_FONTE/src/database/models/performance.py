"""
Modelos de Performance e Métricas
API de Governança de Dados V2.2
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from sqlalchemy import Column, String, Text, Boolean, Integer, DateTime, ForeignKey, Enum as SQLEnum, Float
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import relationship
from enum import Enum
from ..base import Base

class MetricType(Enum):
    SYSTEM = "system"
    BUSINESS = "business"
    QUALITY = "quality"
    PERFORMANCE = "performance"
    USAGE = "usage"
    CUSTOM = "custom"

class MetricStatus(Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    DEPRECATED = "deprecated"
    ERROR = "error"

class CalculationMethod(Enum):
    SUM = "sum"
    AVERAGE = "average"
    COUNT = "count"
    MIN = "min"
    MAX = "max"
    PERCENTAGE = "percentage"
    RATIO = "ratio"
    CUSTOM = "custom"

class AlertLevel(Enum):
    INFO = "info"
    WARNING = "warning"
    CRITICAL = "critical"
    EMERGENCY = "emergency"

class PerformanceMetric(Base):
    """Métricas de performance do sistema"""
    __tablename__ = 'performance_metrics'
    __table_args__ = {'extend_existing': True}
    
    name = Column(String(255), nullable=False, comment='Nome da métrica')
    description = Column(Text, comment='Descrição da métrica')
    metric_type = Column(SQLEnum(MetricType), nullable=False, comment='Tipo da métrica')
    
    # Configurações da métrica
    unit = Column(String(50), comment='Unidade de medida (ms, MB, %, etc.)')
    calculation_method = Column(SQLEnum(CalculationMethod), nullable=False, comment='Método de cálculo')
    calculation_formula = Column(Text, comment='Fórmula de cálculo')
    
    # Fonte dos dados
    data_source = Column(String(255), comment='Fonte dos dados')
    query_definition = Column(Text, comment='Query SQL ou definição de coleta')
    collection_frequency = Column(String(100), comment='Frequência de coleta (cron expression)')
    
    # Limites e alertas
    warning_threshold = Column(Float, comment='Limite para alerta de warning')
    critical_threshold = Column(Float, comment='Limite para alerta crítico')
    target_value = Column(Float, comment='Valor alvo da métrica')
    
    # Configurações de agregação
    aggregation_window = Column(String(50), comment='Janela de agregação (1h, 1d, 1w)')
    retention_days = Column(Integer, default=90, comment='Dias de retenção dos dados')
    
    # Status
    status = Column(SQLEnum(MetricStatus), default=MetricStatus.ACTIVE, comment='Status da métrica')
    
    # Metadados
    created_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), nullable=False, comment='Criador da métrica')
    category = Column(String(100), comment='Categoria da métrica')
    tags = Column(JSONB, comment='Tags para organização')
    
    # Última coleta
    last_collected_at = Column(DateTime(timezone=True), comment='Última coleta')
    last_value = Column(Float, comment='Último valor coletado')
    
    # Relacionamentos
    creator = relationship("User", foreign_keys=[created_by])
    calculations = relationship("MetricCalculation", back_populates="metric", cascade="all, delete-orphan")

class BusinessMetric(Base):
    """Métricas de negócio"""
    __tablename__ = 'business_metrics'
    __table_args__ = {'extend_existing': True}
    
    name = Column(String(255), nullable=False, comment='Nome da métrica de negócio')
    description = Column(Text, comment='Descrição da métrica')
    business_definition = Column(Text, comment='Definição de negócio da métrica')
    
    # Configurações da métrica
    unit = Column(String(50), comment='Unidade de medida')
    calculation_method = Column(SQLEnum(CalculationMethod), nullable=False, comment='Método de cálculo')
    business_formula = Column(Text, comment='Fórmula de negócio')
    
    # Responsabilidade
    business_owner = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Dono de negócio')
    technical_owner = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Responsável técnico')
    
    # Configurações de coleta
    data_sources = Column(JSONB, comment='Fontes de dados utilizadas')
    calculation_logic = Column(Text, comment='Lógica de cálculo detalhada')
    update_frequency = Column(String(100), comment='Frequência de atualização')
    
    # Metas e limites
    target_value = Column(Float, comment='Meta da métrica')
    min_acceptable = Column(Float, comment='Valor mínimo aceitável')
    max_acceptable = Column(Float, comment='Valor máximo aceitável')
    
    # Contexto de negócio
    business_context = Column(Text, comment='Contexto de negócio')
    impact_description = Column(Text, comment='Descrição do impacto')
    related_kpis = Column(JSONB, comment='KPIs relacionados')
    
    # Aprovação
    approved_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Aprovador da métrica')
    approved_at = Column(DateTime(timezone=True), comment='Data de aprovação')
    
    # Status
    status = Column(SQLEnum(MetricStatus), default=MetricStatus.ACTIVE, comment='Status da métrica')
    
    # Metadados
    created_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), nullable=False, comment='Criador da métrica')
    department = Column(String(100), comment='Departamento responsável')
    
    # Última atualização
    last_calculated_at = Column(DateTime(timezone=True), comment='Última calculação')
    last_value = Column(Float, comment='Último valor calculado')
    
    # Relacionamentos
    creator = relationship("User", foreign_keys=[created_by])
    business_owner_user = relationship("User", foreign_keys=[business_owner])
    technical_owner_user = relationship("User", foreign_keys=[technical_owner])
    approver = relationship("User", foreign_keys=[approved_by])
    calculations = relationship("MetricCalculation", back_populates="business_metric", cascade="all, delete-orphan")

class MetricCalculation(Base):
    """Cálculos e valores das métricas"""
    __tablename__ = 'metric_calculations'
    __table_args__ = {'extend_existing': True}
    
    # Relacionamento com métricas
    metric_id = Column(UUID(as_uuid=True), ForeignKey('performance_metrics.id'), comment='Métrica de performance')
    business_metric_id = Column(UUID(as_uuid=True), ForeignKey('business_metrics.id'), comment='Métrica de negócio')
    
    # Dados do cálculo
    calculated_at = Column(DateTime(timezone=True), nullable=False, comment='Data/hora do cálculo')
    value = Column(Float, nullable=False, comment='Valor calculado')
    
    # Contexto do cálculo
    calculation_period_start = Column(DateTime(timezone=True), comment='Início do período de cálculo')
    calculation_period_end = Column(DateTime(timezone=True), comment='Fim do período de cálculo')
    
    # Metadados do cálculo
    calculation_details = Column(JSONB, comment='Detalhes do cálculo')
    data_points_count = Column(Integer, comment='Número de pontos de dados utilizados')
    confidence_score = Column(Float, comment='Score de confiança do cálculo')
    
    # Alertas gerados
    alert_level = Column(SQLEnum(AlertLevel), comment='Nível de alerta gerado')
    alert_message = Column(Text, comment='Mensagem de alerta')
    
    # Comparações
    previous_value = Column(Float, comment='Valor anterior')
    change_percentage = Column(Float, comment='Percentual de mudança')
    trend_direction = Column(String(20), comment='Direção da tendência (up, down, stable)')
    
    # Qualidade dos dados
    data_quality_score = Column(Float, comment='Score de qualidade dos dados')
    missing_data_percentage = Column(Float, comment='Percentual de dados faltantes')
    
    # Execução
    execution_time_ms = Column(Integer, comment='Tempo de execução em milissegundos')
    execution_status = Column(String(50), comment='Status da execução')
    error_details = Column(Text, comment='Detalhes de erro se houver')
    
    # Relacionamentos
    metric = relationship("PerformanceMetric", back_populates="calculations")
    business_metric = relationship("BusinessMetric", back_populates="calculations")

