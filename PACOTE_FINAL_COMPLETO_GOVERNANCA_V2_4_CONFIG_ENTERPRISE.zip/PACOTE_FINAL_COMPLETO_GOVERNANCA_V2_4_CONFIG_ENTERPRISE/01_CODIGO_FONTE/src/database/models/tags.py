"""
Modelos de Tags e Classificação
API de Governança de Dados V1.9
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from sqlalchemy import Column, String, Text, Boolean, Integer, ForeignKey, Enum as SQLEnum, Float, DateTime
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import relationship
from enum import Enum
from ..base import Base

class TagType(Enum):
    BUSINESS = "business"
    TECHNICAL = "technical"
    CLASSIFICATION = "classification"
    QUALITY = "quality"
    COMPLIANCE = "compliance"
    CUSTOM = "custom"

class TagScope(Enum):
    GLOBAL = "global"
    DOMAIN = "domain"
    PROJECT = "project"
    TEAM = "team"

class Tag(Base):
    """Tags para classificação e organização de dados"""
    __tablename__ = 'tags'
    __table_args__ = {'extend_existing': True}
    
    name = Column(String(255), nullable=False, unique=True, comment='Nome único da tag')
    display_name = Column(String(255), comment='Nome de exibição amigável')
    description = Column(Text, comment='Descrição da tag')
    
    # Tipo e categoria
    tag_type = Column(SQLEnum(TagType), nullable=False, comment='Tipo da tag')
    category = Column(String(100), comment='Categoria específica')
    scope = Column(SQLEnum(TagScope), default=TagScope.GLOBAL, comment='Escopo de aplicação')
    
    # Configurações visuais
    color = Column(String(7), comment='Cor da tag em hexadecimal')
    icon = Column(String(100), comment='Ícone associado à tag')
    
    # Hierarquia
    parent_tag_id = Column(UUID(as_uuid=True), ForeignKey('tags.id'), comment='Tag pai na hierarquia')
    level = Column(Integer, default=0, comment='Nível na hierarquia')
    path = Column(String(500), comment='Caminho completo na hierarquia')
    
    # Metadados
    created_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), nullable=False, comment='Criador da tag')
    is_system_tag = Column(Boolean, default=False, comment='Tag do sistema (não editável)')
    is_active = Column(Boolean, default=True, comment='Tag ativa')
    
    # Configurações de uso
    auto_apply_rules = Column(JSONB, comment='Regras para aplicação automática')
    validation_rules = Column(JSONB, comment='Regras de validação')
    
    # Estatísticas
    usage_count = Column(Integer, default=0, comment='Número de vezes usada')
    
    # Relacionamentos
    parent_tag = relationship("Tag", remote_side="Tag.id")
    child_tags = relationship("Tag", back_populates="parent_tag")
    creator = relationship("User", foreign_keys=[created_by])
    hierarchies = relationship("TagHierarchy", back_populates="tag", cascade="all, delete-orphan")

class TagHierarchy(Base):
    """Hierarquia estruturada de tags"""
    __tablename__ = 'tag_hierarchies'
    __table_args__ = {'extend_existing': True}
    
    tag_id = Column(UUID(as_uuid=True), ForeignKey('tags.id'), nullable=False)
    parent_id = Column(UUID(as_uuid=True), ForeignKey('tags.id'), comment='Tag pai')
    
    # Posição na hierarquia
    level = Column(Integer, nullable=False, comment='Nível na hierarquia (0 = raiz)')
    position = Column(Integer, comment='Posição entre irmãos')
    
    # Metadados da relação
    relationship_type = Column(String(50), comment='Tipo de relacionamento (parent-child, synonym, related)')
    is_primary = Column(Boolean, default=True, comment='Relacionamento primário')
    
    # Configurações
    inherit_permissions = Column(Boolean, default=True, comment='Herdar permissões do pai')
    inherit_rules = Column(Boolean, default=True, comment='Herdar regras do pai')
    
    # Relacionamentos
    tag = relationship("Tag", foreign_keys=[tag_id], back_populates="hierarchies")
    parent = relationship("Tag", foreign_keys=[parent_id])


class TagCategory(Base):
    """Categorias de tags para organização hierárquica"""
    __tablename__ = 'tag_categories'
    __table_args__ = {'extend_existing': True}
    
    name = Column(String(255), nullable=False, unique=True, comment='Nome único da categoria')
    display_name = Column(String(255), comment='Nome de exibição amigável')
    description = Column(Text, comment='Descrição da categoria')
    
    # Hierarquia
    parent_category_id = Column(UUID(as_uuid=True), ForeignKey('tag_categories.id'), comment='Categoria pai')
    level = Column(Integer, default=0, comment='Nível na hierarquia')
    path = Column(String(500), comment='Caminho completo na hierarquia')
    
    # Configurações
    color = Column(String(7), comment='Cor da categoria em hexadecimal')
    icon = Column(String(100), comment='Ícone associado à categoria')
    is_active = Column(Boolean, default=True, comment='Status ativo/inativo')
    
    # Regras
    allowed_tag_types = Column(JSONB, comment='Tipos de tags permitidos nesta categoria')
    validation_rules = Column(JSONB, comment='Regras de validação para tags')
    
    # Relacionamentos
    parent_category = relationship("TagCategory", remote_side="TagCategory.id")
    child_categories = relationship("TagCategory", back_populates="parent_category")
    tags = relationship("Tag", back_populates="category_ref")

class TagUsage(Base):
    """Estatísticas de uso de tags"""
    __tablename__ = 'tag_usage'
    __table_args__ = {'extend_existing': True}
    
    tag_id = Column(UUID(as_uuid=True), ForeignKey('tags.id'), nullable=False, comment='Tag')
    entity_type = Column(String(50), nullable=False, comment='Tipo de entidade')
    usage_count = Column(Integer, default=0, comment='Número de usos')
    last_used = Column(DateTime, comment='Última vez usada')
    
    # Estatísticas por período
    daily_usage = Column(JSONB, comment='Uso diário (últimos 30 dias)')
    weekly_usage = Column(JSONB, comment='Uso semanal (últimas 12 semanas)')
    monthly_usage = Column(JSONB, comment='Uso mensal (últimos 12 meses)')
    
    # Relacionamentos
    tag = relationship("Tag", foreign_keys=[tag_id])

# Adicionar relacionamento reverso em Tag
Tag.category_ref = relationship("TagCategory", foreign_keys=[Tag.category_id] if hasattr(Tag, 'category_id') else None)

