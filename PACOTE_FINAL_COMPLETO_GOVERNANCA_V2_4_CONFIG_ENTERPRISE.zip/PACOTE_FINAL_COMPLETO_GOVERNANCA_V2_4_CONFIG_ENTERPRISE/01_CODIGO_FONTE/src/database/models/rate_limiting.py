"""
Modelos de Rate Limiting e Controle de Taxa
API de Governança de Dados V1.2
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from sqlalchemy import Column, String, Boolean, Integer, DateTime, Text, ForeignKey, Float
from sqlalchemy.dialects.postgresql import UUID, INET, JSONB
from sqlalchemy.orm import relationship
from ..base import Base

class RateLimitPolicy(Base):
    """Políticas de rate limiting para controle de taxa de requisições"""
    __tablename__ = 'rate_limit_policies'
    __table_args__ = {'extend_existing': True}
    
    name = Column(String(100), unique=True, nullable=False, comment='Nome da política de rate limiting')
    description = Column(Text, comment='Descrição da política')
    endpoint_pattern = Column(String(200), comment='Padrão de endpoint (regex ou glob)')
    method = Column(String(10), comment='Método HTTP (GET, POST, etc)')
    user_type = Column(String(20), default='all', comment='Tipo de usuário (all, authenticated, admin)')
    
    # Limites por tempo
    requests_per_second = Column(Integer, comment='Requisições por segundo')
    requests_per_minute = Column(Integer, default=60, comment='Requisições por minuto')
    requests_per_hour = Column(Integer, default=1000, comment='Requisições por hora')
    requests_per_day = Column(Integer, default=10000, comment='Requisições por dia')
    
    # Configurações avançadas
    burst_limit = Column(Integer, comment='Limite de rajada de requisições')
    window_size = Column(Integer, default=60, comment='Tamanho da janela em segundos')
    block_duration = Column(Integer, default=300, comment='Duração do bloqueio em segundos')
    
    # Status e controle
    is_active = Column(Boolean, default=True, comment='Status ativo/inativo da política')
    priority = Column(Integer, default=100, comment='Prioridade da política (menor = maior prioridade)')
    
    # Ações em caso de violação
    action_on_violation = Column(String(20), default='block', comment='Ação ao violar limite (block, throttle, log)')
    custom_response = Column(JSONB, comment='Resposta customizada para violações')
    
    # Relacionamentos
    violations = relationship("RateLimitViolation", back_populates="policy", cascade="all, delete-orphan")

class RateLimitViolation(Base):
    """Log de violações de rate limiting"""
    __tablename__ = 'rate_limit_violations'
    __table_args__ = {'extend_existing': True}
    
    policy_id = Column(UUID(as_uuid=True), ForeignKey('rate_limit_policies.id'), nullable=False)
    user_id = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Usuário que violou o limite')
    ip_address = Column(INET, nullable=False, comment='IP que violou o limite')
    endpoint = Column(String(200), nullable=False, comment='Endpoint acessado')
    method = Column(String(10), nullable=False, comment='Método HTTP usado')
    user_agent = Column(Text, comment='User agent do cliente')
    
    # Detalhes da violação
    requests_count = Column(Integer, nullable=False, comment='Número de requisições no período')
    limit_exceeded = Column(Integer, nullable=False, comment='Limite que foi excedido')
    window_start = Column(DateTime(timezone=True), nullable=False, comment='Início da janela de tempo')
    window_end = Column(DateTime(timezone=True), nullable=False, comment='Fim da janela de tempo')
    
    # Ação tomada
    action_taken = Column(String(20), nullable=False, comment='Ação tomada (blocked, throttled)')
    block_duration = Column(Integer, comment='Duração do bloqueio em segundos')
    
    # Relacionamentos
    policy = relationship("RateLimitPolicy", back_populates="violations")
    user = relationship("User", foreign_keys=[user_id])

class RateLimitCounter(Base):
    """Contadores de requisições para rate limiting"""
    __tablename__ = 'rate_limit_counters'
    __table_args__ = {'extend_existing': True}
    
    key = Column(String(200), nullable=False, comment='Chave única do contador (IP+endpoint+user)')
    policy_id = Column(UUID(as_uuid=True), ForeignKey('rate_limit_policies.id'), nullable=False)
    user_id = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Usuário associado')
    ip_address = Column(INET, comment='IP associado')
    
    # Contadores por período
    count_second = Column(Integer, default=0, comment='Contador por segundo')
    count_minute = Column(Integer, default=0, comment='Contador por minuto')
    count_hour = Column(Integer, default=0, comment='Contador por hora')
    count_day = Column(Integer, default=0, comment='Contador por dia')
    
    # Timestamps de reset
    reset_second = Column(DateTime(timezone=True), comment='Próximo reset do contador por segundo')
    reset_minute = Column(DateTime(timezone=True), comment='Próximo reset do contador por minuto')
    reset_hour = Column(DateTime(timezone=True), comment='Próximo reset do contador por hora')
    reset_day = Column(DateTime(timezone=True), comment='Próximo reset do contador por dia')
    
    # Status
    is_blocked = Column(Boolean, default=False, comment='Se está atualmente bloqueado')
    blocked_until = Column(DateTime(timezone=True), comment='Bloqueado até quando')
    
    # Relacionamentos
    policy = relationship("RateLimitPolicy", foreign_keys=[policy_id])
    user = relationship("User", foreign_keys=[user_id])

class RateLimitWhitelist(Base):
    """Lista branca para rate limiting"""
    __tablename__ = 'rate_limit_whitelist'
    __table_args__ = {'extend_existing': True}
    
    name = Column(String(100), nullable=False, comment='Nome da entrada na whitelist')
    type = Column(String(20), nullable=False, comment='Tipo (ip, user, api_key)')
    value = Column(String(200), nullable=False, comment='Valor (IP, user ID, etc)')
    reason = Column(Text, comment='Razão para estar na whitelist')
    is_active = Column(Boolean, default=True, comment='Status ativo/inativo')
    expires_at = Column(DateTime(timezone=True), comment='Data de expiração da whitelist')
    
    # Relacionamentos
    created_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Usuário que criou a entrada')
    created_by_user = relationship("User", foreign_keys=[created_by])


class RateLimitUserOverride(Base):
    """Overrides de rate limiting por usuário"""
    __tablename__ = 'rate_limit_user_overrides'
    __table_args__ = {'extend_existing': True}
    
    user_id = Column(UUID(as_uuid=True), ForeignKey('users.id'), nullable=False, comment='Usuário')
    policy_id = Column(UUID(as_uuid=True), ForeignKey('rate_limit_policies.id'), comment='Política base')
    endpoint_pattern = Column(String(255), comment='Padrão de endpoint')
    custom_limit = Column(Integer, nullable=False, comment='Limite customizado')
    custom_window_seconds = Column(Integer, nullable=False, comment='Janela customizada em segundos')
    reason = Column(Text, comment='Motivo do override')
    expires_at = Column(DateTime, comment='Data de expiração do override')
    is_active = Column(Boolean, default=True, comment='Status ativo/inativo')
    created_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Criado por')
    
    # Relacionamentos
    user = relationship("User", foreign_keys=[user_id])
    policy = relationship("RateLimitPolicy", foreign_keys=[policy_id])
    creator = relationship("User", foreign_keys=[created_by])

class RateLimitException(Base):
    """Exceções temporárias de rate limiting"""
    __tablename__ = 'rate_limit_exceptions'
    __table_args__ = {'extend_existing': True}
    
    name = Column(String(100), nullable=False, comment='Nome da exceção')
    description = Column(Text, comment='Descrição da exceção')
    endpoint_patterns = Column(JSONB, comment='Padrões de endpoints')
    user_patterns = Column(JSONB, comment='Padrões de usuários')
    ip_patterns = Column(JSONB, comment='Padrões de IPs')
    start_time = Column(DateTime, nullable=False, comment='Início da exceção')
    end_time = Column(DateTime, nullable=False, comment='Fim da exceção')
    is_active = Column(Boolean, default=True, comment='Status ativo/inativo')
    created_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Criado por')
    
    # Relacionamentos
    creator = relationship("User", foreign_keys=[created_by])

