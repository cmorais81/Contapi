"""
Sistema de Monitoramento Enterprise
API de Governança de Dados V2.5
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

import asyncio
import psutil
import time
from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta
from dataclasses import dataclass
import logging
import json
from prometheus_client import Counter, Histogram, Gauge, generate_latest
import aioredis
from sqlalchemy import text

logger = logging.getLogger(__name__)

@dataclass
class HealthStatus:
    """Status de saúde de um componente"""
    component: str
    status: str  # healthy, degraded, unhealthy
    response_time_ms: float
    last_check: datetime
    details: Dict[str, Any]
    error_message: Optional[str] = None

@dataclass
class SystemMetrics:
    """Métricas do sistema"""
    timestamp: datetime
    cpu_percent: float
    memory_percent: float
    disk_percent: float
    network_io: Dict[str, int]
    active_connections: int
    response_time_avg: float
    error_rate: float
    throughput_rps: float

class EnterpriseMonitoring:
    """
    Sistema de monitoramento enterprise com métricas avançadas,
    alertas inteligentes e dashboards em tempo real.
    """
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.redis_client = None
        self.db_session = None
        
        # Métricas Prometheus
        self.request_counter = Counter(
            'governanca_requests_total',
            'Total de requisições',
            ['method', 'endpoint', 'status']
        )
        
        self.request_duration = Histogram(
            'governanca_request_duration_seconds',
            'Duração das requisições',
            ['method', 'endpoint']
        )
        
        self.active_users = Gauge(
            'governanca_active_users',
            'Usuários ativos'
        )
        
        self.database_connections = Gauge(
            'governanca_database_connections',
            'Conexões ativas do banco'
        )
        
        self.quality_score = Gauge(
            'governanca_quality_score',
            'Score médio de qualidade'
        )
        
        # Cache de métricas
        self.metrics_cache = {}
        self.health_cache = {}
        
        # Configurações
        self.check_interval = config.get('check_interval', 30)  # segundos
        self.alert_thresholds = config.get('alert_thresholds', {
            'cpu_percent': 80,
            'memory_percent': 85,
            'disk_percent': 90,
            'response_time_ms': 5000,
            'error_rate': 0.05
        })
        
        logger.info("Sistema de monitoramento enterprise inicializado")
    
    async def initialize(self):
        """Inicializa conexões e recursos"""
        try:
            # Conectar ao Redis
            redis_url = self.config.get('redis_url', 'redis://localhost:6379')
            self.redis_client = await aioredis.from_url(redis_url)
            
            logger.info("Monitoramento enterprise inicializado com sucesso")
            
        except Exception as e:
            logger.error(f"Erro ao inicializar monitoramento: {e}")
            raise
    
    async def start_monitoring(self):
        """Inicia o loop de monitoramento"""
        logger.info("Iniciando monitoramento contínuo")
        
        while True:
            try:
                # Coletar métricas do sistema
                system_metrics = await self.collect_system_metrics()
                
                # Verificar saúde dos componentes
                health_status = await self.check_components_health()
                
                # Atualizar métricas Prometheus
                await self.update_prometheus_metrics(system_metrics)
                
                # Verificar alertas
                await self.check_alerts(system_metrics, health_status)
                
                # Armazenar métricas
                await self.store_metrics(system_metrics, health_status)
                
                # Aguardar próximo ciclo
                await asyncio.sleep(self.check_interval)
                
            except Exception as e:
                logger.error(f"Erro no loop de monitoramento: {e}")
                await asyncio.sleep(5)  # Aguardar antes de tentar novamente
    
    async def collect_system_metrics(self) -> SystemMetrics:
        """Coleta métricas do sistema"""
        try:
            # Métricas de CPU
            cpu_percent = psutil.cpu_percent(interval=1)
            
            # Métricas de memória
            memory = psutil.virtual_memory()
            memory_percent = memory.percent
            
            # Métricas de disco
            disk = psutil.disk_usage('/')
            disk_percent = disk.percent
            
            # Métricas de rede
            network = psutil.net_io_counters()
            network_io = {
                'bytes_sent': network.bytes_sent,
                'bytes_recv': network.bytes_recv,
                'packets_sent': network.packets_sent,
                'packets_recv': network.packets_recv
            }
            
            # Conexões ativas
            connections = len(psutil.net_connections())
            
            # Métricas da aplicação (do cache)
            response_time_avg = self.metrics_cache.get('response_time_avg', 0)
            error_rate = self.metrics_cache.get('error_rate', 0)
            throughput_rps = self.metrics_cache.get('throughput_rps', 0)
            
            return SystemMetrics(
                timestamp=datetime.now(),
                cpu_percent=cpu_percent,
                memory_percent=memory_percent,
                disk_percent=disk_percent,
                network_io=network_io,
                active_connections=connections,
                response_time_avg=response_time_avg,
                error_rate=error_rate,
                throughput_rps=throughput_rps
            )
            
        except Exception as e:
            logger.error(f"Erro ao coletar métricas do sistema: {e}")
            raise
    
    async def check_components_health(self) -> List[HealthStatus]:
        """Verifica saúde de todos os componentes"""
        health_checks = []
        
        # Verificar banco de dados
        db_health = await self._check_database_health()
        health_checks.append(db_health)
        
        # Verificar Redis
        redis_health = await self._check_redis_health()
        health_checks.append(redis_health)
        
        # Verificar conectores
        connectors_health = await self._check_connectors_health()
        health_checks.extend(connectors_health)
        
        # Verificar engine de qualidade
        quality_health = await self._check_quality_engine_health()
        health_checks.append(quality_health)
        
        return health_checks
    
    async def _check_database_health(self) -> HealthStatus:
        """Verifica saúde do banco de dados"""
        start_time = time.time()
        
        try:
            # TODO: Implementar verificação real do banco
            # Por enquanto, simulação
            await asyncio.sleep(0.01)  # Simular latência
            
            response_time = (time.time() - start_time) * 1000
            
            return HealthStatus(
                component="database",
                status="healthy",
                response_time_ms=response_time,
                last_check=datetime.now(),
                details={
                    "active_connections": 15,
                    "max_connections": 100,
                    "query_performance": "good"
                }
            )
            
        except Exception as e:
            response_time = (time.time() - start_time) * 1000
            
            return HealthStatus(
                component="database",
                status="unhealthy",
                response_time_ms=response_time,
                last_check=datetime.now(),
                details={},
                error_message=str(e)
            )
    
    async def _check_redis_health(self) -> HealthStatus:
        """Verifica saúde do Redis"""
        start_time = time.time()
        
        try:
            if self.redis_client:
                await self.redis_client.ping()
                
                response_time = (time.time() - start_time) * 1000
                
                return HealthStatus(
                    component="redis",
                    status="healthy",
                    response_time_ms=response_time,
                    last_check=datetime.now(),
                    details={
                        "connected": True,
                        "memory_usage": "normal"
                    }
                )
            else:
                return HealthStatus(
                    component="redis",
                    status="unhealthy",
                    response_time_ms=0,
                    last_check=datetime.now(),
                    details={},
                    error_message="Redis client not initialized"
                )
                
        except Exception as e:
            response_time = (time.time() - start_time) * 1000
            
            return HealthStatus(
                component="redis",
                status="unhealthy",
                response_time_ms=response_time,
                last_check=datetime.now(),
                details={},
                error_message=str(e)
            )
    
    async def _check_connectors_health(self) -> List[HealthStatus]:
        """Verifica saúde dos conectores"""
        connectors = [
            {"name": "unity_catalog", "endpoint": "databricks"},
            {"name": "informatica_axon", "endpoint": "axon"}
        ]
        
        health_checks = []
        
        for connector in connectors:
            start_time = time.time()
            
            try:
                # TODO: Implementar verificação real dos conectores
                # Por enquanto, simulação
                await asyncio.sleep(0.05)  # Simular latência
                
                response_time = (time.time() - start_time) * 1000
                
                health_checks.append(HealthStatus(
                    component=f"connector_{connector['name']}",
                    status="healthy",
                    response_time_ms=response_time,
                    last_check=datetime.now(),
                    details={
                        "endpoint": connector['endpoint'],
                        "last_sync": "2025-01-17T10:30:00Z",
                        "sync_status": "success"
                    }
                ))
                
            except Exception as e:
                response_time = (time.time() - start_time) * 1000
                
                health_checks.append(HealthStatus(
                    component=f"connector_{connector['name']}",
                    status="unhealthy",
                    response_time_ms=response_time,
                    last_check=datetime.now(),
                    details={},
                    error_message=str(e)
                ))
        
        return health_checks
    
    async def _check_quality_engine_health(self) -> HealthStatus:
        """Verifica saúde da engine de qualidade"""
        start_time = time.time()
        
        try:
            # TODO: Implementar verificação real da engine
            # Por enquanto, simulação
            await asyncio.sleep(0.02)  # Simular latência
            
            response_time = (time.time() - start_time) * 1000
            
            return HealthStatus(
                component="quality_engine",
                status="healthy",
                response_time_ms=response_time,
                last_check=datetime.now(),
                details={
                    "rules_active": 25,
                    "last_execution": "2025-01-17T10:25:00Z",
                    "average_score": 87.5
                }
            )
            
        except Exception as e:
            response_time = (time.time() - start_time) * 1000
            
            return HealthStatus(
                component="quality_engine",
                status="unhealthy",
                response_time_ms=response_time,
                last_check=datetime.now(),
                details={},
                error_message=str(e)
            )
    
    async def update_prometheus_metrics(self, metrics: SystemMetrics):
        """Atualiza métricas do Prometheus"""
        try:
            # Atualizar gauges
            self.database_connections.set(15)  # TODO: Valor real
            self.active_users.set(42)  # TODO: Valor real
            self.quality_score.set(87.5)  # TODO: Valor real
            
            # Armazenar métricas no cache para próximas coletas
            self.metrics_cache.update({
                'cpu_percent': metrics.cpu_percent,
                'memory_percent': metrics.memory_percent,
                'disk_percent': metrics.disk_percent,
                'response_time_avg': metrics.response_time_avg,
                'error_rate': metrics.error_rate,
                'throughput_rps': metrics.throughput_rps
            })
            
        except Exception as e:
            logger.error(f"Erro ao atualizar métricas Prometheus: {e}")
    
    async def check_alerts(self, metrics: SystemMetrics, health_status: List[HealthStatus]):
        """Verifica condições de alerta"""
        alerts = []
        
        # Alertas de sistema
        if metrics.cpu_percent > self.alert_thresholds['cpu_percent']:
            alerts.append({
                'type': 'system',
                'severity': 'warning',
                'component': 'cpu',
                'message': f'CPU usage high: {metrics.cpu_percent:.1f}%',
                'value': metrics.cpu_percent,
                'threshold': self.alert_thresholds['cpu_percent']
            })
        
        if metrics.memory_percent > self.alert_thresholds['memory_percent']:
            alerts.append({
                'type': 'system',
                'severity': 'warning',
                'component': 'memory',
                'message': f'Memory usage high: {metrics.memory_percent:.1f}%',
                'value': metrics.memory_percent,
                'threshold': self.alert_thresholds['memory_percent']
            })
        
        if metrics.disk_percent > self.alert_thresholds['disk_percent']:
            alerts.append({
                'type': 'system',
                'severity': 'critical',
                'component': 'disk',
                'message': f'Disk usage critical: {metrics.disk_percent:.1f}%',
                'value': metrics.disk_percent,
                'threshold': self.alert_thresholds['disk_percent']
            })
        
        # Alertas de componentes
        for health in health_status:
            if health.status == 'unhealthy':
                alerts.append({
                    'type': 'component',
                    'severity': 'critical',
                    'component': health.component,
                    'message': f'Component {health.component} is unhealthy',
                    'error': health.error_message,
                    'response_time': health.response_time_ms
                })
            elif health.status == 'degraded':
                alerts.append({
                    'type': 'component',
                    'severity': 'warning',
                    'component': health.component,
                    'message': f'Component {health.component} is degraded',
                    'response_time': health.response_time_ms
                })
        
        # Processar alertas
        if alerts:
            await self._process_alerts(alerts)
    
    async def _process_alerts(self, alerts: List[Dict]):
        """Processa e envia alertas"""
        for alert in alerts:
            try:
                # Log do alerta
                logger.warning(f"ALERT: {alert['message']}")
                
                # Armazenar no Redis para dashboard
                if self.redis_client:
                    alert_key = f"alert:{alert['component']}:{int(time.time())}"
                    await self.redis_client.setex(
                        alert_key,
                        3600,  # 1 hora
                        json.dumps({
                            **alert,
                            'timestamp': datetime.now().isoformat()
                        })
                    )
                
                # TODO: Implementar notificações (Slack, email, etc.)
                await self._send_alert_notification(alert)
                
            except Exception as e:
                logger.error(f"Erro ao processar alerta: {e}")
    
    async def _send_alert_notification(self, alert: Dict):
        """Envia notificação de alerta"""
        # TODO: Implementar integração com Slack, email, PagerDuty, etc.
        logger.info(f"Notificação de alerta enviada: {alert['message']}")
    
    async def store_metrics(self, metrics: SystemMetrics, health_status: List[HealthStatus]):
        """Armazena métricas para histórico"""
        try:
            if self.redis_client:
                # Armazenar métricas do sistema
                metrics_key = f"metrics:system:{int(time.time())}"
                await self.redis_client.setex(
                    metrics_key,
                    86400,  # 24 horas
                    json.dumps({
                        'timestamp': metrics.timestamp.isoformat(),
                        'cpu_percent': metrics.cpu_percent,
                        'memory_percent': metrics.memory_percent,
                        'disk_percent': metrics.disk_percent,
                        'network_io': metrics.network_io,
                        'active_connections': metrics.active_connections,
                        'response_time_avg': metrics.response_time_avg,
                        'error_rate': metrics.error_rate,
                        'throughput_rps': metrics.throughput_rps
                    })
                )
                
                # Armazenar status de saúde
                for health in health_status:
                    health_key = f"health:{health.component}:{int(time.time())}"
                    await self.redis_client.setex(
                        health_key,
                        86400,  # 24 horas
                        json.dumps({
                            'component': health.component,
                            'status': health.status,
                            'response_time_ms': health.response_time_ms,
                            'last_check': health.last_check.isoformat(),
                            'details': health.details,
                            'error_message': health.error_message
                        })
                    )
                
        except Exception as e:
            logger.error(f"Erro ao armazenar métricas: {e}")
    
    async def get_dashboard_data(self) -> Dict[str, Any]:
        """Obtém dados para dashboard"""
        try:
            # Métricas atuais
            current_metrics = await self.collect_system_metrics()
            
            # Status de saúde atual
            health_status = await self.check_components_health()
            
            # Métricas históricas (últimas 24h)
            historical_metrics = await self._get_historical_metrics()
            
            # Alertas ativos
            active_alerts = await self._get_active_alerts()
            
            return {
                'current_metrics': {
                    'timestamp': current_metrics.timestamp.isoformat(),
                    'cpu_percent': current_metrics.cpu_percent,
                    'memory_percent': current_metrics.memory_percent,
                    'disk_percent': current_metrics.disk_percent,
                    'network_io': current_metrics.network_io,
                    'active_connections': current_metrics.active_connections,
                    'response_time_avg': current_metrics.response_time_avg,
                    'error_rate': current_metrics.error_rate,
                    'throughput_rps': current_metrics.throughput_rps
                },
                'health_status': [
                    {
                        'component': h.component,
                        'status': h.status,
                        'response_time_ms': h.response_time_ms,
                        'last_check': h.last_check.isoformat(),
                        'details': h.details,
                        'error_message': h.error_message
                    }
                    for h in health_status
                ],
                'historical_metrics': historical_metrics,
                'active_alerts': active_alerts,
                'summary': {
                    'total_components': len(health_status),
                    'healthy_components': len([h for h in health_status if h.status == 'healthy']),
                    'unhealthy_components': len([h for h in health_status if h.status == 'unhealthy']),
                    'degraded_components': len([h for h in health_status if h.status == 'degraded']),
                    'active_alerts_count': len(active_alerts),
                    'overall_health': self._calculate_overall_health(health_status)
                }
            }
            
        except Exception as e:
            logger.error(f"Erro ao obter dados do dashboard: {e}")
            return {}
    
    async def _get_historical_metrics(self) -> List[Dict]:
        """Obtém métricas históricas"""
        try:
            if not self.redis_client:
                return []
            
            # Buscar métricas das últimas 24 horas
            now = int(time.time())
            start_time = now - 86400  # 24 horas atrás
            
            historical = []
            
            # Buscar por intervalos de 1 hora
            for timestamp in range(start_time, now, 3600):
                metrics_key = f"metrics:system:{timestamp}"
                data = await self.redis_client.get(metrics_key)
                
                if data:
                    historical.append(json.loads(data))
            
            return historical
            
        except Exception as e:
            logger.error(f"Erro ao obter métricas históricas: {e}")
            return []
    
    async def _get_active_alerts(self) -> List[Dict]:
        """Obtém alertas ativos"""
        try:
            if not self.redis_client:
                return []
            
            # Buscar alertas da última hora
            now = int(time.time())
            start_time = now - 3600  # 1 hora atrás
            
            alerts = []
            
            # Buscar chaves de alertas
            alert_keys = await self.redis_client.keys("alert:*")
            
            for key in alert_keys:
                data = await self.redis_client.get(key)
                if data:
                    alert = json.loads(data)
                    alerts.append(alert)
            
            return alerts
            
        except Exception as e:
            logger.error(f"Erro ao obter alertas ativos: {e}")
            return []
    
    def _calculate_overall_health(self, health_status: List[HealthStatus]) -> str:
        """Calcula saúde geral do sistema"""
        if not health_status:
            return "unknown"
        
        unhealthy_count = len([h for h in health_status if h.status == 'unhealthy'])
        degraded_count = len([h for h in health_status if h.status == 'degraded'])
        
        if unhealthy_count > 0:
            return "unhealthy"
        elif degraded_count > 0:
            return "degraded"
        else:
            return "healthy"
    
    def get_prometheus_metrics(self) -> str:
        """Retorna métricas no formato Prometheus"""
        return generate_latest()
    
    async def cleanup(self):
        """Limpa recursos"""
        try:
            if self.redis_client:
                await self.redis_client.close()
            
            logger.info("Recursos de monitoramento limpos")
            
        except Exception as e:
            logger.error(f"Erro ao limpar recursos: {e}")

# Instância global do monitoramento
monitoring_instance = None

async def get_monitoring_instance(config: Dict[str, Any] = None) -> EnterpriseMonitoring:
    """Obtém instância singleton do monitoramento"""
    global monitoring_instance
    
    if monitoring_instance is None:
        if config is None:
            config = {}
        
        monitoring_instance = EnterpriseMonitoring(config)
        await monitoring_instance.initialize()
    
    return monitoring_instance

