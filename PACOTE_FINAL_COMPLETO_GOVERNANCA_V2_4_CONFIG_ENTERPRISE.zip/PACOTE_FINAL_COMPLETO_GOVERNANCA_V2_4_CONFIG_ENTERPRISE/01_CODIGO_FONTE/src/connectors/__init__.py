"""
Conectores Funcionais - API de Governança de Dados V2.2
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)

Este módulo contém conectores funcionais para integração com:
- Unity Catalog (Databricks)
- Informatica Axon
- DataHub
- Outras ferramentas de governança
"""

from .unity_catalog_connector import UnityCatalogConnector
from .axon_connector import AxonConnector
from .datahub_connector import DataHubConnector
from .base_connector import BaseConnector

__all__ = [
    'BaseConnector',
    'UnityCatalogConnector', 
    'AxonConnector',
    'DataHubConnector'
]

