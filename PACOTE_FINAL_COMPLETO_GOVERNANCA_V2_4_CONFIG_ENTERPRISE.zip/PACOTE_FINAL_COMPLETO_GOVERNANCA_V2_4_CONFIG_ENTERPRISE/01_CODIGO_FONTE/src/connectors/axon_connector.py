"""
Conector Informatica Axon
API de Governança de Dados V2.3
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

import aiohttp
import asyncio
from typing import Dict, List, Any, Optional
from datetime import datetime
import logging
import xml.etree.ElementTree as ET

from .base_connector import BaseConnector, ConnectorStatus, SyncResult

logger = logging.getLogger(__name__)

class AxonConnector(BaseConnector):
    """Conector para Informatica Axon Data Governance"""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.axon_url = config.get('axon_url')
        self.username = self.auth_config.get('username')
        self.password = self.auth_config.get('password')
        self.domain = self.auth_config.get('domain', 'Native')
        self.session = None
        self.auth_token = None
        
    async def connect(self) -> bool:
        """Estabelece conexão com Informatica Axon"""
        try:
            self.status = ConnectorStatus.AUTHENTICATING
            
            # Criar sessão HTTP
            self.session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=30)
            )
            
            # Autenticar com Axon
            auth_success = await self._authenticate()
            
            if auth_success:
                self.status = ConnectorStatus.CONNECTED
                self.log_success("Conectado ao Informatica Axon com sucesso")
                return True
            else:
                self.status = ConnectorStatus.ERROR
                self.log_error("Falha na autenticação com Informatica Axon")
                return False
                
        except Exception as e:
            self.status = ConnectorStatus.ERROR
            self.log_error(f"Erro ao conectar com Informatica Axon: {str(e)}")
            return False
    
    async def disconnect(self) -> bool:
        """Desconecta do Informatica Axon"""
        try:
            # Logout do Axon
            if self.auth_token:
                await self._logout()
            
            if self.session:
                await self.session.close()
                self.session = None
            
            self.auth_token = None
            self.status = ConnectorStatus.DISCONNECTED
            self.log_success("Desconectado do Informatica Axon")
            return True
            
        except Exception as e:
            self.log_error(f"Erro ao desconectar: {str(e)}")
            return False
    
    async def test_connection(self) -> Dict[str, Any]:
        """Testa conexão com Informatica Axon"""
        try:
            if not self.session:
                await self.connect()
            
            # Testar com endpoint de versão
            url = f"{self.axon_url}/axonapi/v3/version"
            headers = self._get_auth_headers()
            
            async with self.session.get(url, headers=headers) as response:
                if response.status == 200:
                    data = await response.json()
                    return {
                        "success": True,
                        "status_code": response.status,
                        "axon_version": data.get('version', 'unknown'),
                        "message": "Conexão com Informatica Axon bem-sucedida"
                    }
                else:
                    error_text = await response.text()
                    return {
                        "success": False,
                        "status_code": response.status,
                        "error": error_text,
                        "message": "Falha na conexão com Informatica Axon"
                    }
                    
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "message": "Erro ao testar conexão com Informatica Axon"
            }
    
    async def sync_entities(self, entity_filters: Optional[Dict] = None) -> SyncResult:
        """Sincroniza entidades do Informatica Axon"""
        result = SyncResult()
        start_time = datetime.now()
        
        try:
            self.status = ConnectorStatus.SYNCING
            
            if not self.session or not self.auth_token:
                await self.connect()
            
            # Sincronizar diferentes tipos de entidades
            entity_types = [
                'BusinessTerms',
                'DataElements', 
                'DataSets',
                'Policies',
                'DataDomains'
            ]
            
            for entity_type in entity_types:
                try:
                    entities = await self._get_entities_by_type(entity_type, entity_filters)
                    result.entities_processed += len(entities)
                    
                    for entity in entities:
                        try:
                            # Processar entidade
                            await self._process_axon_entity(entity_type, entity)
                            result.entities_created += 1
                            
                        except Exception as e:
                            result.entities_failed += 1
                            result.errors.append(f"Erro ao processar {entity_type} {entity.get('id')}: {str(e)}")
                            
                except Exception as e:
                    result.errors.append(f"Erro ao sincronizar {entity_type}: {str(e)}")
            
            # Calcular tempo de execução
            end_time = datetime.now()
            result.execution_time_seconds = (end_time - start_time).total_seconds()
            
            # Determinar sucesso
            result.success = result.entities_failed == 0
            
            self.status = ConnectorStatus.CONNECTED
            self.last_sync_time = end_time
            
            self.log_success(f"Sincronização concluída: {result.entities_created} entidades criadas")
            
        except Exception as e:
            result.success = False
            result.errors.append(f"Erro geral na sincronização: {str(e)}")
            self.log_error("Erro na sincronização", {"error": str(e)})
            
        return result
    
    async def sync_metadata(self, entity_id: str) -> Dict[str, Any]:
        """Sincroniza metadados de uma entidade específica"""
        try:
            # Obter detalhes da entidade
            entity_details = await self._get_entity_details(entity_id)
            
            # Obter metadados adicionais
            metadata = await self._get_entity_metadata(entity_id)
            
            # Obter relacionamentos
            relationships = await self._get_entity_relationships(entity_id)
            
            return {
                "entity_id": entity_id,
                "details": entity_details,
                "metadata": metadata,
                "relationships": relationships,
                "sync_timestamp": datetime.now().isoformat(),
                "source": "informatica_axon"
            }
            
        except Exception as e:
            self.log_error(f"Erro ao sincronizar metadados de {entity_id}: {str(e)}")
            raise
    
    async def get_entity_lineage(self, entity_id: str) -> Dict[str, Any]:
        """Obtém lineage de uma entidade do Informatica Axon"""
        try:
            # Axon API para lineage
            url = f"{self.axon_url}/axonapi/v3/lineage/{entity_id}"
            headers = self._get_auth_headers()
            
            async with self.session.get(url, headers=headers) as response:
                if response.status == 200:
                    lineage_data = await response.json()
                    
                    # Processar dados de lineage
                    upstream = []
                    downstream = []
                    
                    for link in lineage_data.get('links', []):
                        if link.get('direction') == 'upstream':
                            upstream.append({
                                'entity_id': link.get('sourceId'),
                                'entity_name': link.get('sourceName'),
                                'relationship_type': link.get('linkType')
                            })
                        elif link.get('direction') == 'downstream':
                            downstream.append({
                                'entity_id': link.get('targetId'),
                                'entity_name': link.get('targetName'),
                                'relationship_type': link.get('linkType')
                            })
                    
                    return {
                        "entity_id": entity_id,
                        "upstream_entities": upstream,
                        "downstream_entities": downstream,
                        "lineage_timestamp": datetime.now().isoformat(),
                        "source": "informatica_axon"
                    }
                else:
                    error_text = await response.text()
                    raise Exception(f"Erro ao obter lineage: {error_text}")
                    
        except Exception as e:
            self.log_error(f"Erro ao obter lineage de {entity_id}: {str(e)}")
            raise
    
    async def get_data_quality_metrics(self, entity_id: str) -> Dict[str, Any]:
        """Obtém métricas de qualidade de dados do Axon"""
        try:
            # Axon API para métricas de qualidade
            url = f"{self.axon_url}/axonapi/v3/quality/metrics/{entity_id}"
            headers = self._get_auth_headers()
            
            async with self.session.get(url, headers=headers) as response:
                if response.status == 200:
                    quality_data = await response.json()
                    
                    # Processar métricas
                    metrics = {}
                    for metric in quality_data.get('metrics', []):
                        metric_name = metric.get('name')
                        metrics[metric_name] = {
                            'value': metric.get('value'),
                            'score': metric.get('score'),
                            'threshold': metric.get('threshold'),
                            'status': metric.get('status'),
                            'last_calculated': metric.get('lastCalculated')
                        }
                    
                    return {
                        "entity_id": entity_id,
                        "metrics": metrics,
                        "overall_score": quality_data.get('overallScore', 0),
                        "calculated_at": datetime.now().isoformat(),
                        "source": "informatica_axon"
                    }
                else:
                    # Se não houver métricas específicas, calcular básicas
                    return await self._calculate_basic_quality_metrics(entity_id)
                    
        except Exception as e:
            self.log_error(f"Erro ao obter métricas de qualidade de {entity_id}: {str(e)}")
            # Retornar métricas básicas em caso de erro
            return await self._calculate_basic_quality_metrics(entity_id)
    
    # Métodos auxiliares privados
    
    async def _authenticate(self) -> bool:
        """Autentica com Informatica Axon"""
        try:
            url = f"{self.axon_url}/axonapi/v3/login"
            
            auth_data = {
                "username": self.username,
                "password": self.password,
                "domain": self.domain
            }
            
            async with self.session.post(url, json=auth_data) as response:
                if response.status == 200:
                    auth_response = await response.json()
                    self.auth_token = auth_response.get('token')
                    return True
                else:
                    error_text = await response.text()
                    self.log_error(f"Erro na autenticação: {error_text}")
                    return False
                    
        except Exception as e:
            self.log_error(f"Erro na autenticação: {str(e)}")
            return False
    
    async def _logout(self):
        """Faz logout do Axon"""
        try:
            url = f"{self.axon_url}/axonapi/v3/logout"
            headers = self._get_auth_headers()
            
            async with self.session.post(url, headers=headers) as response:
                if response.status == 200:
                    self.log_success("Logout realizado com sucesso")
                    
        except Exception as e:
            self.log_error(f"Erro no logout: {str(e)}")
    
    def _get_auth_headers(self) -> Dict[str, str]:
        """Retorna headers de autenticação"""
        headers = {
            'Content-Type': 'application/json'
        }
        
        if self.auth_token:
            headers['Authorization'] = f'Bearer {self.auth_token}'
        
        return headers
    
    async def _get_entities_by_type(self, entity_type: str, filters: Optional[Dict] = None) -> List[Dict]:
        """Obtém entidades por tipo"""
        try:
            url = f"{self.axon_url}/axonapi/v3/entities/{entity_type}"
            headers = self._get_auth_headers()
            
            # Aplicar filtros se fornecidos
            params = {}
            if filters:
                params.update(filters)
            
            async with self.session.get(url, headers=headers, params=params) as response:
                if response.status == 200:
                    data = await response.json()
                    return data.get('entities', [])
                else:
                    raise Exception(f"Erro ao obter {entity_type}: {response.status}")
                    
        except Exception as e:
            self.log_error(f"Erro ao obter entidades {entity_type}: {str(e)}")
            return []
    
    async def _get_entity_details(self, entity_id: str) -> Dict[str, Any]:
        """Obtém detalhes de uma entidade"""
        try:
            url = f"{self.axon_url}/axonapi/v3/entities/{entity_id}"
            headers = self._get_auth_headers()
            
            async with self.session.get(url, headers=headers) as response:
                if response.status == 200:
                    return await response.json()
                else:
                    raise Exception(f"Erro ao obter detalhes da entidade: {response.status}")
                    
        except Exception as e:
            self.log_error(f"Erro ao obter detalhes de {entity_id}: {str(e)}")
            return {}
    
    async def _get_entity_metadata(self, entity_id: str) -> Dict[str, Any]:
        """Obtém metadados de uma entidade"""
        try:
            url = f"{self.axon_url}/axonapi/v3/entities/{entity_id}/metadata"
            headers = self._get_auth_headers()
            
            async with self.session.get(url, headers=headers) as response:
                if response.status == 200:
                    return await response.json()
                else:
                    return {}
                    
        except Exception as e:
            self.log_error(f"Erro ao obter metadados de {entity_id}: {str(e)}")
            return {}
    
    async def _get_entity_relationships(self, entity_id: str) -> List[Dict]:
        """Obtém relacionamentos de uma entidade"""
        try:
            url = f"{self.axon_url}/axonapi/v3/entities/{entity_id}/relationships"
            headers = self._get_auth_headers()
            
            async with self.session.get(url, headers=headers) as response:
                if response.status == 200:
                    data = await response.json()
                    return data.get('relationships', [])
                else:
                    return []
                    
        except Exception as e:
            self.log_error(f"Erro ao obter relacionamentos de {entity_id}: {str(e)}")
            return []
    
    async def _process_axon_entity(self, entity_type: str, entity: Dict):
        """Processa uma entidade do Axon para sincronização"""
        # TODO: Implementar criação/atualização da entidade no banco local
        # Por enquanto, apenas log
        entity_name = entity.get('name', entity.get('id', 'unknown'))
        logger.info(f"Processando entidade {entity_type}: {entity_name}")
    
    async def _calculate_basic_quality_metrics(self, entity_id: str) -> Dict[str, Any]:
        """Calcula métricas básicas de qualidade"""
        # TODO: Implementar cálculos reais baseados nos dados
        # Por enquanto, retornar métricas mock
        return {
            "entity_id": entity_id,
            "metrics": {
                "completeness": {
                    "value": 92.5,
                    "score": 92.5,
                    "status": "good"
                },
                "validity": {
                    "value": 87.3,
                    "score": 87.3,
                    "status": "good"
                },
                "consistency": {
                    "value": 94.1,
                    "score": 94.1,
                    "status": "excellent"
                }
            },
            "overall_score": 91.3,
            "calculated_at": datetime.now().isoformat(),
            "source": "informatica_axon"
        }

