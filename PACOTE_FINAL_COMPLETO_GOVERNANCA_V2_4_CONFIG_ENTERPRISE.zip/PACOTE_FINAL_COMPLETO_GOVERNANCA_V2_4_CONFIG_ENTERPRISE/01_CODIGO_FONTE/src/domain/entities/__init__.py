"""
Entidades do domínio
API de Governança de Dados V2.3
"""

from .domain import Domain

__all__ = ['Domain']

