"""
Engine de Qualidade de Dados - API de Governança V2.3
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)

Este módulo contém a engine de qualidade que executa regras de validação
e calcula métricas de qualidade de dados em tempo real.
"""

from .quality_engine import QualityEngine
from .rule_executor import RuleExecutor
from .metric_calculator import MetricCalculator
from .quality_validator import QualityValidator

__all__ = [
    'QualityEngine',
    'RuleExecutor', 
    'MetricCalculator',
    'QualityValidator'
]

