"""
Controller de Lineage de Dados - V2.2 com Banco de Dados
API de Governança de Dados V2.2
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from fastapi import APIRouter, HTTPException, Depends, Query
from typing import List, Optional, Dict, Any
from uuid import UUID
from sqlalchemy.orm import Session
import logging

from src.database.connection import get_database_session
from src.database.models.lineage import DataLineage, LineageAttribute, ImpactAnalysis
from src.database.repositories.base import BaseRepository

logger = logging.getLogger(__name__)

# Criar router
router = APIRouter()

def get_lineage_repository(db: Session = Depends(get_database_session)) -> BaseRepository[DataLineage]:
    """Dependency para obter repository de lineage"""
    return BaseRepository(DataLineage, db)

def get_lineage_attribute_repository(db: Session = Depends(get_database_session)) -> BaseRepository[LineageAttribute]:
    """Dependency para obter repository de lineage de atributos"""
    return BaseRepository(LineageAttribute, db)

def get_impact_analysis_repository(db: Session = Depends(get_database_session)) -> BaseRepository[ImpactAnalysis]:
    """Dependency para obter repository de análise de impacto"""
    return BaseRepository(ImpactAnalysis, db)

# ========================================
# LINEAGE DE DADOS
# ========================================

@router.get("/lineage", summary="Listar relacionamentos de lineage")
async def list_lineage(
    limit: int = Query(100, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    source_entity_id: Optional[UUID] = Query(None, description="Filtrar por entidade origem"),
    target_entity_id: Optional[UUID] = Query(None, description="Filtrar por entidade destino"),
    lineage_type: Optional[str] = Query(None, description="Filtrar por tipo de lineage"),
    confidence_min: Optional[float] = Query(None, description="Confiança mínima"),
    repository: BaseRepository[DataLineage] = Depends(get_lineage_repository)
):
    """
    Lista relacionamentos de lineage de dados.
    
    Tipos de lineage suportados:
    - direct: Lineage direto (ETL, view, etc.)
    - derived: Dados derivados (agregações, cálculos)
    - copy: Cópia de dados
    - reference: Referência a dados
    - transformation: Transformação complexa
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        # Aplicar filtros
        filters = {}
        if source_entity_id:
            filters['source_entity_id'] = source_entity_id
        if target_entity_id:
            filters['target_entity_id'] = target_entity_id
        if lineage_type:
            filters['lineage_type'] = lineage_type
        
        # Buscar lineage
        lineages = repository.search(
            filters=filters,
            limit=limit,
            offset=offset,
            sort_by='created_at',
            sort_order='desc'
        )
        
        # Filtrar por confiança se especificado
        if confidence_min is not None:
            lineages = [l for l in lineages if l.confidence_score and l.confidence_score >= confidence_min]
        
        total = repository.count(filters)
        
        logger.info(f"Listando {len(lineages)} relacionamentos de lineage de {total} total")
        
        return {
            "lineages": [lineage.to_dict() for lineage in lineages],
            "total": total,
            "limit": limit,
            "offset": offset,
            "filters": {
                "source_entity_id": str(source_entity_id) if source_entity_id else None,
                "target_entity_id": str(target_entity_id) if target_entity_id else None,
                "lineage_type": lineage_type,
                "confidence_min": confidence_min
            },
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except Exception as e:
        logger.error(f"Erro ao listar lineage: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.post("/lineage", summary="Criar relacionamento de lineage")
async def create_lineage(
    lineage_data: Dict[str, Any],
    repository: BaseRepository[DataLineage] = Depends(get_lineage_repository)
):
    """
    Cria um novo relacionamento de lineage.
    
    Campos obrigatórios:
    - source_entity_id: ID da entidade origem
    - target_entity_id: ID da entidade destino
    - lineage_type: Tipo do relacionamento
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        # Validar dados obrigatórios
        required_fields = ['source_entity_id', 'target_entity_id', 'lineage_type']
        for field in required_fields:
            if field not in lineage_data:
                raise HTTPException(status_code=400, detail=f"Campo {field} é obrigatório")
        
        # Verificar se já existe relacionamento
        existing = repository.find_one_by(
            source_entity_id=lineage_data['source_entity_id'],
            target_entity_id=lineage_data['target_entity_id'],
            lineage_type=lineage_data['lineage_type']
        )
        if existing:
            raise HTTPException(status_code=409, detail="Relacionamento de lineage já existe")
        
        # Criar lineage
        lineage = repository.create(**lineage_data)
        
        logger.info(f"Lineage criado: {lineage.id}")
        
        return {
            "lineage": lineage.to_dict(),
            "message": "Relacionamento de lineage criado com sucesso",
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao criar lineage: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.get("/lineage/{lineage_id}", summary="Obter lineage específico")
async def get_lineage(
    lineage_id: UUID,
    include_attributes: bool = Query(False, description="Incluir lineage de atributos"),
    repository: BaseRepository[DataLineage] = Depends(get_lineage_repository),
    attr_repository: BaseRepository[LineageAttribute] = Depends(get_lineage_attribute_repository)
):
    """
    Obtém um relacionamento de lineage específico.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        lineage = repository.get_by_id(lineage_id)
        
        if not lineage:
            raise HTTPException(status_code=404, detail="Lineage não encontrado")
        
        result = lineage.to_dict()
        
        # Incluir lineage de atributos se solicitado
        if include_attributes:
            attributes = attr_repository.find_by(lineage_id=lineage_id)
            result['attribute_lineages'] = [attr.to_dict() for attr in attributes]
        
        logger.info(f"Lineage encontrado: {lineage_id}")
        
        return {
            "lineage": result,
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao obter lineage {lineage_id}: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

# ========================================
# LINEAGE DE ATRIBUTOS
# ========================================

@router.get("/lineage/{lineage_id}/attributes", summary="Listar lineage de atributos")
async def list_lineage_attributes(
    lineage_id: UUID,
    limit: int = Query(100, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    repository: BaseRepository[LineageAttribute] = Depends(get_lineage_attribute_repository)
):
    """
    Lista lineage de atributos para um relacionamento específico.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        # Buscar lineage de atributos
        attributes = repository.search(
            filters={'lineage_id': lineage_id},
            limit=limit,
            offset=offset,
            sort_by='source_attribute_name',
            sort_order='asc'
        )
        
        total = repository.count({'lineage_id': lineage_id})
        
        logger.info(f"Listando {len(attributes)} lineages de atributos para lineage {lineage_id}")
        
        return {
            "attribute_lineages": [attr.to_dict() for attr in attributes],
            "total": total,
            "limit": limit,
            "offset": offset,
            "lineage_id": str(lineage_id),
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except Exception as e:
        logger.error(f"Erro ao listar lineage de atributos: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.post("/lineage/{lineage_id}/attributes", summary="Criar lineage de atributo")
async def create_lineage_attribute(
    lineage_id: UUID,
    attribute_data: Dict[str, Any],
    repository: BaseRepository[LineageAttribute] = Depends(get_lineage_attribute_repository)
):
    """
    Cria lineage de atributo para um relacionamento.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        # Validar dados obrigatórios
        required_fields = ['source_attribute_name', 'target_attribute_name']
        for field in required_fields:
            if field not in attribute_data:
                raise HTTPException(status_code=400, detail=f"Campo {field} é obrigatório")
        
        # Adicionar lineage_id
        attribute_data['lineage_id'] = lineage_id
        
        # Verificar se já existe
        existing = repository.find_one_by(
            lineage_id=lineage_id,
            source_attribute_name=attribute_data['source_attribute_name'],
            target_attribute_name=attribute_data['target_attribute_name']
        )
        if existing:
            raise HTTPException(status_code=409, detail="Lineage de atributo já existe")
        
        # Criar lineage de atributo
        attribute = repository.create(**attribute_data)
        
        logger.info(f"Lineage de atributo criado: {attribute.id}")
        
        return {
            "attribute_lineage": attribute.to_dict(),
            "message": "Lineage de atributo criado com sucesso",
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao criar lineage de atributo: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

# ========================================
# ANÁLISE DE IMPACTO
# ========================================

@router.post("/lineage/impact-analysis", summary="Executar análise de impacto")
async def run_impact_analysis(
    analysis_request: Dict[str, Any],
    repository: BaseRepository[ImpactAnalysis] = Depends(get_impact_analysis_repository)
):
    """
    Executa análise de impacto para uma entidade.
    
    Campos obrigatórios:
    - entity_id: ID da entidade para análise
    - analysis_type: Tipo de análise (downstream, upstream, full)
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        # Validar dados obrigatórios
        required_fields = ['entity_id', 'analysis_type']
        for field in required_fields:
            if field not in analysis_request:
                raise HTTPException(status_code=400, detail=f"Campo {field} é obrigatório")
        
        # Criar análise de impacto
        analysis = repository.create(**analysis_request)
        
        # TODO: Implementar lógica de análise de impacto real
        # Por enquanto, criar resultado mock
        analysis.status = "completed"
        analysis.total_entities_analyzed = 10
        analysis.impacted_entities_count = 5
        analysis.analysis_results = {
            "downstream_entities": [
                {"entity_id": "uuid1", "impact_level": "high", "confidence": 0.9},
                {"entity_id": "uuid2", "impact_level": "medium", "confidence": 0.7}
            ],
            "upstream_entities": [
                {"entity_id": "uuid3", "impact_level": "low", "confidence": 0.6}
            ]
        }
        
        repository.update(analysis.id, {
            "status": analysis.status,
            "total_entities_analyzed": analysis.total_entities_analyzed,
            "impacted_entities_count": analysis.impacted_entities_count,
            "analysis_results": analysis.analysis_results
        })
        
        logger.info(f"Análise de impacto executada: {analysis.id}")
        
        return {
            "analysis": analysis.to_dict(),
            "message": "Análise de impacto executada com sucesso",
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao executar análise de impacto: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.get("/lineage/impact-analysis/{analysis_id}", summary="Obter resultado de análise de impacto")
async def get_impact_analysis(
    analysis_id: UUID,
    repository: BaseRepository[ImpactAnalysis] = Depends(get_impact_analysis_repository)
):
    """
    Obtém resultado de uma análise de impacto.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        analysis = repository.get_by_id(analysis_id)
        
        if not analysis:
            raise HTTPException(status_code=404, detail="Análise de impacto não encontrada")
        
        logger.info(f"Análise de impacto encontrada: {analysis_id}")
        
        return {
            "analysis": analysis.to_dict(),
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao obter análise de impacto {analysis_id}: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.get("/lineage/entity/{entity_id}/downstream", summary="Obter entidades downstream")
async def get_downstream_entities(
    entity_id: UUID,
    max_depth: int = Query(5, ge=1, le=10, description="Profundidade máxima"),
    lineage_repository: BaseRepository[DataLineage] = Depends(get_lineage_repository)
):
    """
    Obtém todas as entidades downstream (que dependem) de uma entidade.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        # Buscar lineages onde a entidade é origem
        downstream_lineages = lineage_repository.find_by(source_entity_id=entity_id)
        
        # TODO: Implementar busca recursiva com max_depth
        # Por enquanto, retornar apenas nível 1
        downstream_entities = []
        for lineage in downstream_lineages:
            downstream_entities.append({
                "entity_id": str(lineage.target_entity_id),
                "lineage_type": lineage.lineage_type,
                "confidence": lineage.confidence_score,
                "depth": 1
            })
        
        logger.info(f"Encontradas {len(downstream_entities)} entidades downstream para {entity_id}")
        
        return {
            "entity_id": str(entity_id),
            "downstream_entities": downstream_entities,
            "total_count": len(downstream_entities),
            "max_depth": max_depth,
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except Exception as e:
        logger.error(f"Erro ao obter entidades downstream: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.get("/lineage/entity/{entity_id}/upstream", summary="Obter entidades upstream")
async def get_upstream_entities(
    entity_id: UUID,
    max_depth: int = Query(5, ge=1, le=10, description="Profundidade máxima"),
    lineage_repository: BaseRepository[DataLineage] = Depends(get_lineage_repository)
):
    """
    Obtém todas as entidades upstream (das quais depende) de uma entidade.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        # Buscar lineages onde a entidade é destino
        upstream_lineages = lineage_repository.find_by(target_entity_id=entity_id)
        
        # TODO: Implementar busca recursiva com max_depth
        # Por enquanto, retornar apenas nível 1
        upstream_entities = []
        for lineage in upstream_lineages:
            upstream_entities.append({
                "entity_id": str(lineage.source_entity_id),
                "lineage_type": lineage.lineage_type,
                "confidence": lineage.confidence_score,
                "depth": 1
            })
        
        logger.info(f"Encontradas {len(upstream_entities)} entidades upstream para {entity_id}")
        
        return {
            "entity_id": str(entity_id),
            "upstream_entities": upstream_entities,
            "total_count": len(upstream_entities),
            "max_depth": max_depth,
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except Exception as e:
        logger.error(f"Erro ao obter entidades upstream: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

