"""
Controller de Data Stewardship - V2.3 com Banco de Dados
API de Governança de Dados V2.3
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from fastapi import APIRouter, HTTPException, Depends, Query
from typing import List, Optional, Dict, Any
from uuid import UUID
from sqlalchemy.orm import Session
import logging

from src.database.connection import get_database_session
from src.database.models.stewardship import DataSteward, StewardAssignment, StewardActivity
from src.database.repositories.base import BaseRepository

logger = logging.getLogger(__name__)

# Criar router
router = APIRouter()

def get_steward_repository(db: Session = Depends(get_database_session)) -> BaseRepository[DataSteward]:
    """Dependency para obter repository de stewards"""
    return BaseRepository(DataSteward, db)

def get_assignment_repository(db: Session = Depends(get_database_session)) -> BaseRepository[StewardAssignment]:
    """Dependency para obter repository de atribuições"""
    return BaseRepository(StewardAssignment, db)

def get_activity_repository(db: Session = Depends(get_database_session)) -> BaseRepository[StewardActivity]:
    """Dependency para obter repository de atividades"""
    return BaseRepository(StewardActivity, db)

# ========================================
# DATA STEWARDS
# ========================================

@router.get("/stewards", summary="Listar data stewards")
async def list_stewards(
    limit: int = Query(100, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    department: Optional[str] = Query(None, description="Filtrar por departamento"),
    expertise_area: Optional[str] = Query(None, description="Filtrar por área de expertise"),
    status: Optional[str] = Query(None, description="Filtrar por status"),
    repository: BaseRepository[DataSteward] = Depends(get_steward_repository)
):
    """
    Lista data stewards cadastrados.
    
    Áreas de expertise suportadas:
    - data_quality: Qualidade de dados
    - data_governance: Governança de dados
    - data_privacy: Privacidade de dados
    - data_security: Segurança de dados
    - business_analysis: Análise de negócio
    - technical_analysis: Análise técnica
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        # Aplicar filtros
        filters = {}
        if department:
            filters['department'] = department
        if expertise_area:
            filters['expertise_area'] = expertise_area
        if status:
            filters['status'] = status
        
        # Buscar stewards
        stewards = repository.search(
            filters=filters,
            limit=limit,
            offset=offset,
            sort_by='name',
            sort_order='asc'
        )
        
        total = repository.count(filters)
        
        logger.info(f"Listando {len(stewards)} stewards de {total} total")
        
        return {
            "stewards": [steward.to_dict() for steward in stewards],
            "total": total,
            "limit": limit,
            "offset": offset,
            "filters": {
                "department": department,
                "expertise_area": expertise_area,
                "status": status
            },
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except Exception as e:
        logger.error(f"Erro ao listar stewards: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.post("/stewards", summary="Criar data steward")
async def create_steward(
    steward_data: Dict[str, Any],
    repository: BaseRepository[DataSteward] = Depends(get_steward_repository)
):
    """
    Cria um novo data steward.
    
    Campos obrigatórios:
    - name: Nome do steward
    - email: Email do steward
    - department: Departamento
    - expertise_area: Área de expertise
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        # Validar dados obrigatórios
        required_fields = ['name', 'email', 'department', 'expertise_area']
        for field in required_fields:
            if field not in steward_data:
                raise HTTPException(status_code=400, detail=f"Campo {field} é obrigatório")
        
        # Verificar se já existe steward com mesmo email
        existing = repository.find_one_by(email=steward_data['email'])
        if existing:
            raise HTTPException(status_code=409, detail="Steward com este email já existe")
        
        # Criar steward
        steward = repository.create(**steward_data)
        
        logger.info(f"Steward criado: {steward.id} - {steward.name}")
        
        return {
            "steward": steward.to_dict(),
            "message": "Data steward criado com sucesso",
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao criar steward: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.get("/stewards/{steward_id}", summary="Obter steward específico")
async def get_steward(
    steward_id: UUID,
    include_assignments: bool = Query(False, description="Incluir atribuições"),
    include_activities: bool = Query(False, description="Incluir atividades"),
    repository: BaseRepository[DataSteward] = Depends(get_steward_repository),
    assignment_repository: BaseRepository[StewardAssignment] = Depends(get_assignment_repository),
    activity_repository: BaseRepository[StewardActivity] = Depends(get_activity_repository)
):
    """
    Obtém um data steward específico por ID.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        steward = repository.get_by_id(steward_id)
        
        if not steward:
            raise HTTPException(status_code=404, detail="Data steward não encontrado")
        
        result = steward.to_dict()
        
        # Incluir atribuições se solicitado
        if include_assignments:
            assignments = assignment_repository.find_by(steward_id=steward_id)
            result['assignments'] = [assignment.to_dict() for assignment in assignments]
        
        # Incluir atividades se solicitado
        if include_activities:
            activities = activity_repository.find_by(steward_id=steward_id)
            result['activities'] = [activity.to_dict() for activity in activities]
        
        logger.info(f"Steward encontrado: {steward_id}")
        
        return {
            "steward": result,
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao obter steward {steward_id}: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

# ========================================
# ATRIBUIÇÕES DE STEWARDSHIP
# ========================================

@router.get("/stewards/assignments", summary="Listar atribuições de stewardship")
async def list_assignments(
    limit: int = Query(100, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    steward_id: Optional[UUID] = Query(None, description="Filtrar por steward"),
    entity_id: Optional[UUID] = Query(None, description="Filtrar por entidade"),
    responsibility_type: Optional[str] = Query(None, description="Filtrar por tipo de responsabilidade"),
    status: Optional[str] = Query(None, description="Filtrar por status"),
    repository: BaseRepository[StewardAssignment] = Depends(get_assignment_repository)
):
    """
    Lista atribuições de stewardship.
    
    Tipos de responsabilidade:
    - primary: Responsabilidade primária
    - secondary: Responsabilidade secundária
    - reviewer: Revisor
    - approver: Aprovador
    - consultant: Consultor
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        # Aplicar filtros
        filters = {}
        if steward_id:
            filters['steward_id'] = steward_id
        if entity_id:
            filters['entity_id'] = entity_id
        if responsibility_type:
            filters['responsibility_type'] = responsibility_type
        if status:
            filters['status'] = status
        
        # Buscar atribuições
        assignments = repository.search(
            filters=filters,
            limit=limit,
            offset=offset,
            sort_by='assigned_at',
            sort_order='desc'
        )
        
        total = repository.count(filters)
        
        logger.info(f"Listando {len(assignments)} atribuições de {total} total")
        
        return {
            "assignments": [assignment.to_dict() for assignment in assignments],
            "total": total,
            "limit": limit,
            "offset": offset,
            "filters": {
                "steward_id": str(steward_id) if steward_id else None,
                "entity_id": str(entity_id) if entity_id else None,
                "responsibility_type": responsibility_type,
                "status": status
            },
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except Exception as e:
        logger.error(f"Erro ao listar atribuições: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.post("/stewards/assignments", summary="Criar atribuição de stewardship")
async def create_assignment(
    assignment_data: Dict[str, Any],
    repository: BaseRepository[StewardAssignment] = Depends(get_assignment_repository)
):
    """
    Cria uma nova atribuição de stewardship.
    
    Campos obrigatórios:
    - steward_id: ID do steward
    - entity_id: ID da entidade
    - responsibility_type: Tipo de responsabilidade
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        # Validar dados obrigatórios
        required_fields = ['steward_id', 'entity_id', 'responsibility_type']
        for field in required_fields:
            if field not in assignment_data:
                raise HTTPException(status_code=400, detail=f"Campo {field} é obrigatório")
        
        # Verificar se já existe atribuição similar
        existing = repository.find_one_by(
            steward_id=assignment_data['steward_id'],
            entity_id=assignment_data['entity_id'],
            responsibility_type=assignment_data['responsibility_type']
        )
        if existing and existing.status == 'active':
            raise HTTPException(status_code=409, detail="Atribuição similar já existe e está ativa")
        
        # Criar atribuição
        assignment = repository.create(**assignment_data)
        
        logger.info(f"Atribuição criada: {assignment.id}")
        
        return {
            "assignment": assignment.to_dict(),
            "message": "Atribuição de stewardship criada com sucesso",
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao criar atribuição: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.put("/stewards/assignments/{assignment_id}/activate", summary="Ativar atribuição")
async def activate_assignment(
    assignment_id: UUID,
    repository: BaseRepository[StewardAssignment] = Depends(get_assignment_repository)
):
    """
    Ativa uma atribuição de stewardship.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        assignment = repository.get_by_id(assignment_id)
        
        if not assignment:
            raise HTTPException(status_code=404, detail="Atribuição não encontrada")
        
        # Atualizar status
        updated_assignment = repository.update(assignment_id, {"status": "active"})
        
        logger.info(f"Atribuição ativada: {assignment_id}")
        
        return {
            "assignment": updated_assignment.to_dict(),
            "message": "Atribuição ativada com sucesso",
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao ativar atribuição {assignment_id}: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

# ========================================
# ATIVIDADES DE STEWARDSHIP
# ========================================

@router.get("/stewards/activities", summary="Listar atividades de stewardship")
async def list_activities(
    limit: int = Query(100, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    steward_id: Optional[UUID] = Query(None, description="Filtrar por steward"),
    entity_id: Optional[UUID] = Query(None, description="Filtrar por entidade"),
    activity_type: Optional[str] = Query(None, description="Filtrar por tipo de atividade"),
    status: Optional[str] = Query(None, description="Filtrar por status"),
    repository: BaseRepository[StewardActivity] = Depends(get_activity_repository)
):
    """
    Lista atividades de stewardship.
    
    Tipos de atividade:
    - data_review: Revisão de dados
    - quality_check: Verificação de qualidade
    - metadata_update: Atualização de metadados
    - issue_resolution: Resolução de problemas
    - compliance_check: Verificação de compliance
    - documentation: Documentação
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        # Aplicar filtros
        filters = {}
        if steward_id:
            filters['steward_id'] = steward_id
        if entity_id:
            filters['entity_id'] = entity_id
        if activity_type:
            filters['activity_type'] = activity_type
        if status:
            filters['status'] = status
        
        # Buscar atividades
        activities = repository.search(
            filters=filters,
            limit=limit,
            offset=offset,
            sort_by='activity_date',
            sort_order='desc'
        )
        
        total = repository.count(filters)
        
        logger.info(f"Listando {len(activities)} atividades de {total} total")
        
        return {
            "activities": [activity.to_dict() for activity in activities],
            "total": total,
            "limit": limit,
            "offset": offset,
            "filters": {
                "steward_id": str(steward_id) if steward_id else None,
                "entity_id": str(entity_id) if entity_id else None,
                "activity_type": activity_type,
                "status": status
            },
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except Exception as e:
        logger.error(f"Erro ao listar atividades: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.post("/stewards/activities", summary="Registrar atividade de stewardship")
async def create_activity(
    activity_data: Dict[str, Any],
    repository: BaseRepository[StewardActivity] = Depends(get_activity_repository)
):
    """
    Registra uma nova atividade de stewardship.
    
    Campos obrigatórios:
    - steward_id: ID do steward
    - activity_type: Tipo de atividade
    - description: Descrição da atividade
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        # Validar dados obrigatórios
        required_fields = ['steward_id', 'activity_type', 'description']
        for field in required_fields:
            if field not in activity_data:
                raise HTTPException(status_code=400, detail=f"Campo {field} é obrigatório")
        
        # Criar atividade
        activity = repository.create(**activity_data)
        
        logger.info(f"Atividade registrada: {activity.id}")
        
        return {
            "activity": activity.to_dict(),
            "message": "Atividade de stewardship registrada com sucesso",
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao registrar atividade: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.put("/stewards/activities/{activity_id}/complete", summary="Completar atividade")
async def complete_activity(
    activity_id: UUID,
    completion_data: Dict[str, Any],
    repository: BaseRepository[StewardActivity] = Depends(get_activity_repository)
):
    """
    Completa uma atividade de stewardship.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        activity = repository.get_by_id(activity_id)
        
        if not activity:
            raise HTTPException(status_code=404, detail="Atividade não encontrada")
        
        # Atualizar atividade
        update_data = {
            "status": "completed",
            "completion_notes": completion_data.get("completion_notes"),
            "outcome": completion_data.get("outcome")
        }
        
        updated_activity = repository.update(activity_id, update_data)
        
        logger.info(f"Atividade completada: {activity_id}")
        
        return {
            "activity": updated_activity.to_dict(),
            "message": "Atividade completada com sucesso",
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao completar atividade {activity_id}: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

# ========================================
# RELATÓRIOS E MÉTRICAS
# ========================================

@router.get("/stewards/metrics", summary="Obter métricas de stewardship")
async def get_stewardship_metrics(
    steward_id: Optional[UUID] = Query(None, description="Filtrar por steward"),
    period_days: int = Query(30, description="Período em dias"),
    steward_repository: BaseRepository[DataSteward] = Depends(get_steward_repository),
    assignment_repository: BaseRepository[StewardAssignment] = Depends(get_assignment_repository),
    activity_repository: BaseRepository[StewardActivity] = Depends(get_activity_repository)
):
    """
    Obtém métricas de stewardship.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        # Métricas básicas
        total_stewards = steward_repository.count({})
        total_assignments = assignment_repository.count({})
        total_activities = activity_repository.count({})
        
        # Filtros por steward se especificado
        filters = {}
        if steward_id:
            filters['steward_id'] = steward_id
        
        # Atividades por tipo
        activity_types = {}
        activities = activity_repository.find_by(**filters)
        for activity in activities:
            activity_type = activity.activity_type
            if activity_type not in activity_types:
                activity_types[activity_type] = 0
            activity_types[activity_type] += 1
        
        # Atribuições por status
        assignment_status = {}
        assignments = assignment_repository.find_by(**filters)
        for assignment in assignments:
            status = assignment.status
            if status not in assignment_status:
                assignment_status[status] = 0
            assignment_status[status] += 1
        
        logger.info(f"Métricas de stewardship calculadas")
        
        return {
            "metrics": {
                "total_stewards": total_stewards,
                "total_assignments": total_assignments,
                "total_activities": total_activities,
                "activity_types": activity_types,
                "assignment_status": assignment_status,
                "period_days": period_days
            },
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except Exception as e:
        logger.error(f"Erro ao calcular métricas: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

