"""
Controller de Entidades e Catálogo - V2.1 com Banco de Dados
API de Governança de Dados V2.1
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from fastapi import APIRouter, HTTPException, Depends, Query
from typing import List, Optional, Dict, Any
from uuid import UUID
from sqlalchemy.orm import Session
import logging

from src.database.connection import get_database_session
from src.database.models.entities import Entity, EntityAttribute, EntityRelationship, EntityTag, EntityUsageStats, CatalogEntry
from src.database.repositories.base import BaseRepository

logger = logging.getLogger(__name__)

# Criar router
router = APIRouter()

def get_entity_repository(db: Session = Depends(get_database_session)) -> BaseRepository[Entity]:
    """Dependency para obter repository de entidades"""
    return BaseRepository(Entity, db)

def get_attribute_repository(db: Session = Depends(get_database_session)) -> BaseRepository[EntityAttribute]:
    """Dependency para obter repository de atributos"""
    return BaseRepository(EntityAttribute, db)

def get_relationship_repository(db: Session = Depends(get_database_session)) -> BaseRepository[EntityRelationship]:
    """Dependency para obter repository de relacionamentos"""
    return BaseRepository(EntityRelationship, db)

def get_catalog_repository(db: Session = Depends(get_database_session)) -> BaseRepository[CatalogEntry]:
    """Dependency para obter repository do catálogo"""
    return BaseRepository(CatalogEntry, db)

# ========================================
# ENTIDADES
# ========================================

@router.get("/entities", summary="Listar entidades do catálogo")
async def list_entities(
    limit: int = Query(100, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    entity_type: Optional[str] = Query(None, description="Filtrar por tipo"),
    domain: Optional[str] = Query(None, description="Filtrar por domínio"),
    is_active: Optional[bool] = Query(None, description="Filtrar por ativo"),
    search: Optional[str] = Query(None, description="Buscar por nome ou descrição"),
    repository: BaseRepository[Entity] = Depends(get_entity_repository)
):
    """
    Lista todas as entidades do catálogo de dados.
    
    Suporta filtros por:
    - Tipo de entidade (table, view, dataset, etc.)
    - Domínio de dados
    - Status ativo/inativo
    - Busca textual
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        # Aplicar filtros
        filters = {}
        if entity_type:
            filters['entity_type'] = entity_type
        if domain:
            filters['domain'] = domain
        if is_active is not None:
            filters['is_active'] = is_active
        
        # Buscar entidades
        entities = repository.search(
            filters=filters,
            search_term=search,
            search_fields=['name', 'description'],
            limit=limit,
            offset=offset,
            sort_by='name',
            sort_order='asc'
        )
        
        total = repository.count(filters)
        
        logger.info(f"Listando {len(entities)} entidades de {total} total")
        
        return {
            "entities": [entity.to_dict() for entity in entities],
            "total": total,
            "limit": limit,
            "offset": offset,
            "filters": {
                "entity_type": entity_type,
                "domain": domain,
                "is_active": is_active,
                "search": search
            },
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except Exception as e:
        logger.error(f"Erro ao listar entidades: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.post("/entities", summary="Criar entidade")
async def create_entity(
    entity_data: Dict[str, Any],
    repository: BaseRepository[Entity] = Depends(get_entity_repository)
):
    """
    Cria uma nova entidade no catálogo.
    
    Tipos de entidade suportados:
    - table: Tabela de banco de dados
    - view: View de banco de dados
    - dataset: Dataset/arquivo
    - api: Endpoint de API
    - stream: Stream de dados
    - model: Modelo de ML
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        # Validar dados obrigatórios
        required_fields = ['name', 'entity_type']
        for field in required_fields:
            if field not in entity_data:
                raise HTTPException(status_code=400, detail=f"Campo {field} é obrigatório")
        
        # Verificar se já existe entidade com mesmo nome no mesmo domínio
        filters = {'name': entity_data['name']}
        if 'domain' in entity_data:
            filters['domain'] = entity_data['domain']
        
        existing = repository.find_one_by(**filters)
        if existing:
            raise HTTPException(status_code=409, detail="Entidade com este nome já existe no domínio")
        
        # Criar entidade
        entity = repository.create(**entity_data)
        
        logger.info(f"Entidade criada: {entity.id} - {entity.name}")
        
        return {
            "entity": entity.to_dict(),
            "message": "Entidade criada com sucesso",
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao criar entidade: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.get("/entities/{entity_id}", summary="Obter entidade específica")
async def get_entity(
    entity_id: UUID,
    include_attributes: bool = Query(False, description="Incluir atributos"),
    include_relationships: bool = Query(False, description="Incluir relacionamentos"),
    repository: BaseRepository[Entity] = Depends(get_entity_repository),
    attr_repository: BaseRepository[EntityAttribute] = Depends(get_attribute_repository),
    rel_repository: BaseRepository[EntityRelationship] = Depends(get_relationship_repository)
):
    """
    Obtém uma entidade específica por ID.
    
    Opcionalmente inclui:
    - Atributos da entidade
    - Relacionamentos com outras entidades
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        entity = repository.get_by_id(entity_id)
        
        if not entity:
            raise HTTPException(status_code=404, detail="Entidade não encontrada")
        
        result = entity.to_dict()
        
        # Incluir atributos se solicitado
        if include_attributes:
            attributes = attr_repository.find_by(entity_id=entity_id)
            result['attributes'] = [attr.to_dict() for attr in attributes]
        
        # Incluir relacionamentos se solicitado
        if include_relationships:
            relationships = rel_repository.find_by(source_entity_id=entity_id)
            result['relationships'] = [rel.to_dict() for rel in relationships]
        
        logger.info(f"Entidade encontrada: {entity_id}")
        
        return {
            "entity": result,
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao obter entidade {entity_id}: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

# ========================================
# ATRIBUTOS DE ENTIDADES
# ========================================

@router.get("/entities/{entity_id}/attributes", summary="Listar atributos da entidade")
async def list_entity_attributes(
    entity_id: UUID,
    limit: int = Query(100, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    data_type: Optional[str] = Query(None, description="Filtrar por tipo de dados"),
    is_nullable: Optional[bool] = Query(None, description="Filtrar por nullable"),
    repository: BaseRepository[EntityAttribute] = Depends(get_attribute_repository)
):
    """
    Lista atributos de uma entidade específica.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        # Aplicar filtros
        filters = {'entity_id': entity_id}
        if data_type:
            filters['data_type'] = data_type
        if is_nullable is not None:
            filters['is_nullable'] = is_nullable
        
        # Buscar atributos
        attributes = repository.search(
            filters=filters,
            limit=limit,
            offset=offset,
            sort_by='position',
            sort_order='asc'
        )
        
        total = repository.count(filters)
        
        logger.info(f"Listando {len(attributes)} atributos para entidade {entity_id}")
        
        return {
            "attributes": [attr.to_dict() for attr in attributes],
            "total": total,
            "limit": limit,
            "offset": offset,
            "entity_id": str(entity_id),
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except Exception as e:
        logger.error(f"Erro ao listar atributos: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.post("/entities/{entity_id}/attributes", summary="Criar atributo")
async def create_entity_attribute(
    entity_id: UUID,
    attribute_data: Dict[str, Any],
    repository: BaseRepository[EntityAttribute] = Depends(get_attribute_repository)
):
    """
    Cria um novo atributo para uma entidade.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        # Validar dados obrigatórios
        required_fields = ['name', 'data_type']
        for field in required_fields:
            if field not in attribute_data:
                raise HTTPException(status_code=400, detail=f"Campo {field} é obrigatório")
        
        # Adicionar entity_id
        attribute_data['entity_id'] = entity_id
        
        # Verificar se já existe atributo com mesmo nome na entidade
        existing = repository.find_one_by(entity_id=entity_id, name=attribute_data['name'])
        if existing:
            raise HTTPException(status_code=409, detail="Atributo com este nome já existe na entidade")
        
        # Criar atributo
        attribute = repository.create(**attribute_data)
        
        logger.info(f"Atributo criado: {attribute.id} para entidade {entity_id}")
        
        return {
            "attribute": attribute.to_dict(),
            "message": "Atributo criado com sucesso",
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao criar atributo: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

# ========================================
# RELACIONAMENTOS
# ========================================

@router.get("/entities/{entity_id}/relationships", summary="Listar relacionamentos da entidade")
async def list_entity_relationships(
    entity_id: UUID,
    direction: str = Query("all", description="Direção (source, target, all)"),
    relationship_type: Optional[str] = Query(None, description="Filtrar por tipo"),
    repository: BaseRepository[EntityRelationship] = Depends(get_relationship_repository)
):
    """
    Lista relacionamentos de uma entidade.
    
    Direções suportadas:
    - source: Relacionamentos onde a entidade é origem
    - target: Relacionamentos onde a entidade é destino
    - all: Todos os relacionamentos
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        filters = {}
        if relationship_type:
            filters['relationship_type'] = relationship_type
        
        relationships = []
        
        if direction in ['source', 'all']:
            # Relacionamentos como origem
            source_filters = {**filters, 'source_entity_id': entity_id}
            source_rels = repository.find_by(**source_filters)
            relationships.extend(source_rels)
        
        if direction in ['target', 'all']:
            # Relacionamentos como destino
            target_filters = {**filters, 'target_entity_id': entity_id}
            target_rels = repository.find_by(**target_filters)
            relationships.extend(target_rels)
        
        logger.info(f"Listando {len(relationships)} relacionamentos para entidade {entity_id}")
        
        return {
            "relationships": [rel.to_dict() for rel in relationships],
            "total": len(relationships),
            "entity_id": str(entity_id),
            "direction": direction,
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except Exception as e:
        logger.error(f"Erro ao listar relacionamentos: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

# ========================================
# CATÁLOGO
# ========================================

@router.get("/catalog", summary="Navegar catálogo de dados")
async def browse_catalog(
    limit: int = Query(100, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    category: Optional[str] = Query(None, description="Filtrar por categoria"),
    domain: Optional[str] = Query(None, description="Filtrar por domínio"),
    search: Optional[str] = Query(None, description="Buscar no catálogo"),
    repository: BaseRepository[CatalogEntry] = Depends(get_catalog_repository)
):
    """
    Navega pelo catálogo de dados organizado.
    
    O catálogo organiza entidades por:
    - Categoria (tables, views, datasets, apis, etc.)
    - Domínio de negócio
    - Tags e classificações
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        # Aplicar filtros
        filters = {}
        if category:
            filters['category'] = category
        if domain:
            filters['domain'] = domain
        
        # Buscar entradas do catálogo
        entries = repository.search(
            filters=filters,
            search_term=search,
            search_fields=['title', 'description'],
            limit=limit,
            offset=offset,
            sort_by='title',
            sort_order='asc'
        )
        
        total = repository.count(filters)
        
        logger.info(f"Navegando catálogo: {len(entries)} entradas de {total} total")
        
        return {
            "catalog_entries": [entry.to_dict() for entry in entries],
            "total": total,
            "limit": limit,
            "offset": offset,
            "filters": {
                "category": category,
                "domain": domain,
                "search": search
            },
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except Exception as e:
        logger.error(f"Erro ao navegar catálogo: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

