"""
Controller de Audit Logs
Desenvolvido por Carlos Morais
"""

from datetime import datetime, timedelta
from typing import List, Optional
from fastapi import APIRouter, Depends, Query, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, or_, desc
from pydantic import BaseModel

from src.database.connection import get_async_session
from src.database.models import AuditLog
from src.api.controllers.auth import get_current_active_user
from monitoring.audit_logger import EventType, EventType

router = APIRouter(prefix="/api/v1/audit", tags=["Audit Logs"])

# Modelos Pydantic
class AuditLogResponse(BaseModel):
    id: int
    user_id: Optional[int]
    username: Optional[str]
    event_type: str
    event_description: str
    resource_type: Optional[str]
    resource_id: Optional[str]
    ip_address: Optional[str]
    user_agent: Optional[str]
    request_id: Optional[str]
    severity: str
    additional_metadata: Optional[dict]
    created_at: datetime

    class Config:
        from_attributes = True

class AuditLogSearch(BaseModel):
    user_id: Optional[int] = None
    username: Optional[str] = None
    event_type: Optional[str] = None
    resource_type: Optional[str] = None
    resource_id: Optional[str] = None
    severity: Optional[str] = None
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    ip_address: Optional[str] = None

class AuditLogStats(BaseModel):
    total_events: int
    events_by_type: dict
    events_by_severity: dict
    events_by_user: dict
    recent_events: int
    period_start: datetime
    period_end: datetime

@router.get("/logs", response_model=List[AuditLogResponse])
async def get_audit_logs(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    user_id: Optional[int] = Query(None),
    event_type: Optional[str] = Query(None),
    severity: Optional[str] = Query(None),
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    db: AsyncSession = Depends(get_async_session),
    current_user = Depends(get_current_active_user)
):
    """
    Obter logs de auditoria com filtros
    """
    query = select(AuditLog)
    
    # Aplicar filtros
    conditions = []
    
    if user_id:
        conditions.append(AuditLog.user_id == user_id)
    
    if event_type:
        conditions.append(AuditLog.event_type == event_type)
    
    if severity:
        conditions.append(AuditLog.severity == severity)
    
    if start_date:
        conditions.append(AuditLog.created_at >= start_date)
    
    if end_date:
        conditions.append(AuditLog.created_at <= end_date)
    
    if conditions:
        query = query.where(and_(*conditions))
    
    # Ordenar por data (mais recente primeiro)
    query = query.order_by(desc(AuditLog.created_at))
    
    # Aplicar paginação
    query = query.offset(skip).limit(limit)
    
    result = await db.execute(query)
    logs = result.scalars().all()
    
    return logs

@router.post("/search", response_model=List[AuditLogResponse])
async def search_audit_logs(
    search_params: AuditLogSearch,
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    db: AsyncSession = Depends(get_async_session),
    current_user = Depends(get_current_active_user)
):
    """
    Busca avançada de logs de auditoria
    """
    query = select(AuditLog)
    conditions = []
    
    # Aplicar filtros do modelo de busca
    if search_params.user_id:
        conditions.append(AuditLog.user_id == search_params.user_id)
    
    if search_params.username:
        conditions.append(AuditLog.username.ilike(f"%{search_params.username}%"))
    
    if search_params.event_type:
        conditions.append(AuditLog.event_type == search_params.event_type)
    
    if search_params.resource_type:
        conditions.append(AuditLog.resource_type == search_params.resource_type)
    
    if search_params.resource_id:
        conditions.append(AuditLog.resource_id == search_params.resource_id)
    
    if search_params.severity:
        conditions.append(AuditLog.severity == search_params.severity)
    
    if search_params.start_date:
        conditions.append(AuditLog.created_at >= search_params.start_date)
    
    if search_params.end_date:
        conditions.append(AuditLog.created_at <= search_params.end_date)
    
    if search_params.ip_address:
        conditions.append(AuditLog.ip_address == search_params.ip_address)
    
    if conditions:
        query = query.where(and_(*conditions))
    
    query = query.order_by(desc(AuditLog.created_at)).offset(skip).limit(limit)
    
    result = await db.execute(query)
    logs = result.scalars().all()
    
    return logs

@router.get("/events", response_model=List[str])
async def get_event_types(
    db: AsyncSession = Depends(get_async_session),
    current_user = Depends(get_current_active_user)
):
    """
    Obter tipos de eventos disponíveis
    """
    return [event_type.value for event_type in EventType]

@router.get("/severities", response_model=List[str])
async def get_severities(
    db: AsyncSession = Depends(get_async_session),
    current_user = Depends(get_current_active_user)
):
    """
    Obter níveis de severidade disponíveis
    """
    return [severity.value for severity in EventType]

@router.get("/stats", response_model=AuditLogStats)
async def get_audit_stats(
    days: int = Query(7, ge=1, le=365),
    db: AsyncSession = Depends(get_async_session),
    current_user = Depends(get_current_active_user)
):
    """
    Obter estatísticas de auditoria
    """
    end_date = datetime.utcnow()
    start_date = end_date - timedelta(days=days)
    
    # Query base para o período
    base_query = select(AuditLog).where(
        and_(
            AuditLog.created_at >= start_date,
            AuditLog.created_at <= end_date
        )
    )
    
    # Total de eventos
    result = await db.execute(base_query)
    all_logs = result.scalars().all()
    
    total_events = len(all_logs)
    
    # Eventos por tipo
    events_by_type = {}
    for log in all_logs:
        event_type = log.event_type
        events_by_type[event_type] = events_by_type.get(event_type, 0) + 1
    
    # Eventos por severidade
    events_by_severity = {}
    for log in all_logs:
        severity = log.severity
        events_by_severity[severity] = events_by_severity.get(severity, 0) + 1
    
    # Eventos por usuário
    events_by_user = {}
    for log in all_logs:
        username = log.username or "System"
        events_by_user[username] = events_by_user.get(username, 0) + 1
    
    # Eventos recentes (últimas 24h)
    recent_start = end_date - timedelta(hours=24)
    recent_events = len([log for log in all_logs if log.created_at >= recent_start])
    
    return AuditLogStats(
        total_events=total_events,
        events_by_type=events_by_type,
        events_by_severity=events_by_severity,
        events_by_user=events_by_user,
        recent_events=recent_events,
        period_start=start_date,
        period_end=end_date
    )

@router.get("/logs/{log_id}", response_model=AuditLogResponse)
async def get_audit_log(
    log_id: int,
    db: AsyncSession = Depends(get_async_session),
    current_user = Depends(get_current_active_user)
):
    """
    Obter log de auditoria específico
    """
    result = await db.execute(select(AuditLog).where(AuditLog.id == log_id))
    log = result.scalar_one_or_none()
    
    if not log:
        raise HTTPException(status_code=404, detail="Audit log not found")
    
    return log

@router.delete("/logs/cleanup")
async def cleanup_old_logs(
    days: int = Query(90, ge=30, le=365),
    db: AsyncSession = Depends(get_async_session),
    current_user = Depends(get_current_active_user)
):
    """
    Limpar logs antigos (apenas admins)
    """
    # TODO: Verificar se usuário é admin
    
    cutoff_date = datetime.utcnow() - timedelta(days=days)
    
    # Contar logs que serão removidos
    count_query = select(AuditLog).where(AuditLog.created_at < cutoff_date)
    result = await db.execute(count_query)
    logs_to_delete = len(result.scalars().all())
    
    # Remover logs antigos
    from sqlalchemy import delete
    delete_query = delete(AuditLog).where(AuditLog.created_at < cutoff_date)
    await db.execute(delete_query)
    await db.commit()
    
    return {
        "message": f"Cleaned up {logs_to_delete} audit logs older than {days} days",
        "cutoff_date": cutoff_date,
        "logs_deleted": logs_to_delete
    }

