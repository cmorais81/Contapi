"""
Controller de Métricas Prometheus
Desenvolvido por Carlos Morais
"""

from fastapi import APIRouter, Response
from prometheus_client import Counter, Histogram, Gauge, generate_latest, CONTENT_TYPE_LATEST
import time
import psutil

router = APIRouter(tags=["Metrics"])

# Métricas Prometheus
REQUEST_COUNT = Counter('http_requests_total', 'Total HTTP requests', ['method', 'endpoint', 'status'])
REQUEST_DURATION = Histogram('http_request_duration_seconds', 'HTTP request duration')
ACTIVE_CONNECTIONS = Gauge('database_connections_active', 'Active database connections')
MEMORY_USAGE = Gauge('system_memory_usage_percent', 'System memory usage percentage')
CPU_USAGE = Gauge('system_cpu_usage_percent', 'System CPU usage percentage')
DISK_USAGE = Gauge('system_disk_usage_percent', 'System disk usage percentage')

# Métricas específicas da aplicação
AUDIT_LOGS_TOTAL = Counter('audit_logs_total', 'Total audit logs created', ['event_type'])
RATE_LIMIT_VIOLATIONS = Counter('rate_limit_violations_total', 'Total rate limit violations', ['user_id'])
CACHE_HITS = Counter('cache_hits_total', 'Total cache hits')
CACHE_MISSES = Counter('cache_misses_total', 'Total cache misses')
QUERY_DURATION = Histogram('database_query_duration_seconds', 'Database query duration', ['query_type'])

@router.get("/metrics")
async def get_metrics():
    """
    Endpoint para métricas Prometheus
    """
    # Atualizar métricas do sistema
    try:
        MEMORY_USAGE.set(psutil.virtual_memory().percent)
        CPU_USAGE.set(psutil.cpu_percent())
        disk = psutil.disk_usage('/')
        DISK_USAGE.set((disk.used / disk.total) * 100)
    except Exception:
        pass  # Ignorar erros de coleta de métricas do sistema
    
    # Gerar métricas no formato Prometheus
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)

def record_request_metrics(method: str, endpoint: str, status_code: int, duration: float):
    """
    Registrar métricas de requisição
    """
    REQUEST_COUNT.labels(method=method, endpoint=endpoint, status=status_code).inc()
    REQUEST_DURATION.observe(duration)

def record_audit_log_metric(event_type: str):
    """
    Registrar métrica de audit log
    """
    AUDIT_LOGS_TOTAL.labels(event_type=event_type).inc()

def record_rate_limit_violation(user_id: str):
    """
    Registrar violação de rate limit
    """
    RATE_LIMIT_VIOLATIONS.labels(user_id=user_id).inc()

def record_cache_hit():
    """
    Registrar cache hit
    """
    CACHE_HITS.inc()

def record_cache_miss():
    """
    Registrar cache miss
    """
    CACHE_MISSES.inc()

def record_query_duration(query_type: str, duration: float):
    """
    Registrar duração de query
    """
    QUERY_DURATION.labels(query_type=query_type).observe(duration)

