"""
Error Middleware da API de Governança de Dados V1.4
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

import logging
import traceback
from typing import Callable
from fastapi import Request, Response
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware

logger = logging.getLogger(__name__)

class ErrorHandlingMiddleware(BaseHTTPMiddleware):
    """Middleware para tratamento de erros"""
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """Processa requisição com tratamento de erros"""
        
        try:
            # Processar requisição
            response = await call_next(request)
            return response
            
        except Exception as e:
            # Log detalhado do erro
            logger.error(
                f"Erro não tratado no middleware: {type(e).__name__}: {str(e)} "
                f"- URL: {request.url} - Method: {request.method}",
                exc_info=True
            )
            
            # Retornar resposta de erro padronizada
            return JSONResponse(
                status_code=500,
                content={
                    "error": True,
                    "message": "Erro interno do servidor",
                    "details": "Um erro inesperado ocorreu durante o processamento da requisição",
                    "status_code": 500,
                    "path": str(request.url),
                    "method": request.method,
                    "timestamp": "2025-07-16T13:00:00Z",
                    "error_type": type(e).__name__
                }
            )

class RequestLoggingMiddleware(BaseHTTPMiddleware):
    """Middleware para logging detalhado de requisições"""
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """Processa requisição com logging detalhado"""
        
        # Log da requisição recebida
        logger.info(
            f"Requisição recebida: {request.method} {request.url} "
            f"- Client: {request.client.host if request.client else 'unknown'} "
            f"- User-Agent: {request.headers.get('user-agent', 'unknown')}"
        )
        
        try:
            # Processar requisição
            response = await call_next(request)
            
            # Log da resposta
            logger.info(
                f"Resposta enviada: {request.method} {request.url} "
                f"- Status: {response.status_code} "
                f"- Content-Type: {response.headers.get('content-type', 'unknown')}"
            )
            
            return response
            
        except Exception as e:
            # Log de erro
            logger.error(
                f"Erro durante processamento: {request.method} {request.url} "
                f"- Erro: {type(e).__name__}: {str(e)}"
            )
            raise

class HealthCheckMiddleware(BaseHTTPMiddleware):
    """Middleware para health checks"""
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """Processa requisição com verificação de saúde"""
        
        # Verificar se é uma requisição de health check
        if request.url.path in ["/health", "/healthz", "/ping"]:
            logger.debug(f"Health check requisitado: {request.url.path}")
        
        try:
            response = await call_next(request)
            return response
            
        except Exception as e:
            # Para health checks, retornar erro específico
            if request.url.path in ["/health", "/healthz", "/ping"]:
                logger.error(f"Health check falhou: {str(e)}")
                return JSONResponse(
                    status_code=503,
                    content={
                        "status": "unhealthy",
                        "error": str(e),
                        "timestamp": "2025-07-16T13:00:00Z"
                    }
                )
            raise

