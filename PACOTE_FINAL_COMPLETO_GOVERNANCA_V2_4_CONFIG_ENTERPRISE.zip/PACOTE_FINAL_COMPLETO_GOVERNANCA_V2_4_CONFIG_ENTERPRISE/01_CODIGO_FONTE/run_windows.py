#!/usr/bin/env python3
"""
Script de execução para Windows - API de Governança de Dados V2.1
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
Organização: F1rst
"""

import sys
import os
from pathlib import Path
import subprocess
import platform

def main():
    """Função principal para executar a API no Windows"""
    
    print("=" * 60)
    print("API de Governança de Dados V2.1 - Windows Ready")
    print("Desenvolvido por: Carlos Morais")
    print("Email: carlos.morais@f1rst.com.br")
    print("Organização: F1rst")
    print("=" * 60)
    print()
    
    # Verificar se estamos no Windows
    if platform.system() != "Windows":
        print("⚠️  AVISO: Este script foi otimizado para Windows")
        print("   Mas pode funcionar em outros sistemas também")
        print()
    
    # Verificar Python
    print("🔍 Verificando Python...")
    python_version = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    print(f"   Versão Python: {python_version}")
    print(f"   Plataforma: {platform.system()} {platform.release()}")
    print()
    
    # Verificar diretório atual
    current_dir = Path.cwd()
    src_dir = current_dir / "src"
    
    if not src_dir.exists():
        print("❌ ERRO: Diretório 'src' não encontrado")
        print("   Execute este script a partir do diretório 01_CODIGO_FONTE")
        input("Pressione Enter para sair...")
        sys.exit(1)
    
    # Adicionar src ao PYTHONPATH
    if str(src_dir) not in sys.path:
        sys.path.insert(0, str(src_dir))
    
    print("📁 Configuração de diretórios:")
    print(f"   Diretório atual: {current_dir}")
    print(f"   Diretório src: {src_dir}")
    print(f"   PYTHONPATH atualizado: ✅")
    print()
    
    # Verificar dependências críticas
    print("📦 Verificando dependências críticas...")
    critical_deps = [
        "fastapi", "uvicorn", "sqlalchemy", "pydantic", 
        "python-dotenv", "async_timeout", "PyJWT"
    ]
    
    missing_deps = []
    for dep in critical_deps:
        try:
            __import__(dep.replace("-", "_"))
            print(f"   ✅ {dep}")
        except ImportError:
            print(f"   ❌ {dep} - FALTANDO")
            missing_deps.append(dep)
    
    if missing_deps:
        print()
        print("⚠️  DEPENDÊNCIAS FALTANDO:")
        for dep in missing_deps:
            print(f"   - {dep}")
        print()
        print("💡 SOLUÇÃO:")
        print("   pip install " + " ".join(missing_deps))
        print()
        
        response = input("Deseja instalar as dependências agora? (s/n): ")
        if response.lower() in ['s', 'sim', 'y', 'yes']:
            try:
                subprocess.run([sys.executable, "-m", "pip", "install"] + missing_deps, check=True)
                print("✅ Dependências instaladas com sucesso!")
            except subprocess.CalledProcessError:
                print("❌ Erro ao instalar dependências")
                input("Pressione Enter para continuar mesmo assim...")
        else:
            print("⚠️  Continuando sem instalar dependências...")
    
    print()
    print("🚀 Iniciando servidor...")
    print("   Host: 0.0.0.0")
    print("   Porta: 8000")
    print("   Modo: Desenvolvimento")
    print()
    print("🌐 ACESSO:")
    print("   API Principal: http://localhost:8000")
    print("   Documentação: http://localhost:8000/docs")
    print("   Health Check: http://localhost:8000/health")
    print("   Diagnóstico: http://localhost:8000/diagnostics")
    print()
    print("⏹️  Para parar: Ctrl+C")
    print("=" * 60)
    print()
    
    try:
        # Importar e executar
        import uvicorn
        from src.main import app
        
        # Configurações otimizadas para Windows
        uvicorn.run(
            app,
            host="0.0.0.0",
            port=8000,
            reload=False,  # Desabilitado para melhor performance no Windows
            log_level="info",
            access_log=True,
            use_colors=True,
            loop="asyncio"  # Melhor compatibilidade Windows
        )
        
    except KeyboardInterrupt:
        print()
        print("🛑 Servidor interrompido pelo usuário")
        print("✅ Shutdown realizado com sucesso")
        
    except ImportError as e:
        print(f"❌ ERRO DE IMPORTAÇÃO: {e}")
        print()
        print("💡 POSSÍVEIS SOLUÇÕES:")
        print("1. Verificar se todas as dependências estão instaladas")
        print("2. Executar: pip install -r requirements.txt")
        print("3. Verificar se está no ambiente virtual correto")
        print("4. Verificar estrutura de diretórios")
        
    except Exception as e:
        print(f"❌ ERRO INESPERADO: {e}")
        print()
        print("💡 INFORMAÇÕES PARA DEBUG:")
        print(f"   Python: {python_version}")
        print(f"   Plataforma: {platform.system()}")
        print(f"   Diretório: {current_dir}")
        print(f"   PYTHONPATH: {sys.path[:3]}")
    
    finally:
        print()
        input("Pressione Enter para sair...")

if __name__ == "__main__":
    main()

