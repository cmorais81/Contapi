"""
Sistema de Testes de Carga
Desenvolvido por Carlos Morais
"""

import asyncio
import aiohttp
import time
import json
import statistics
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, asdict
import random
import string

from config.settings import get_settings


@dataclass
class LoadTestConfig:
    """Configuração do teste de carga"""
    base_url: str = "http://localhost:8000"
    concurrent_users: int = 50
    test_duration_seconds: int = 300  # 5 minutos
    ramp_up_seconds: int = 60  # 1 minuto
    endpoints: List[str] = None
    auth_token: Optional[str] = None
    request_timeout: int = 30
    think_time_min: float = 0.1
    think_time_max: float = 2.0


@dataclass
class RequestResult:
    """Resultado de uma requisição"""
    endpoint: str
    method: str
    status_code: int
    response_time_ms: int
    success: bool
    error_message: Optional[str] = None
    timestamp: datetime = None


@dataclass
class LoadTestResults:
    """Resultados do teste de carga"""
    config: LoadTestConfig
    total_requests: int
    successful_requests: int
    failed_requests: int
    avg_response_time_ms: float
    min_response_time_ms: int
    max_response_time_ms: int
    p95_response_time_ms: float
    p99_response_time_ms: float
    requests_per_second: float
    error_rate_percent: float
    start_time: datetime
    end_time: datetime
    duration_seconds: float
    endpoint_stats: Dict[str, Dict[str, Any]]
    errors_by_type: Dict[str, int]


class LoadTestRunner:
    """Executor de testes de carga"""
    
    def __init__(self, config: LoadTestConfig):
        self.config = config
        self.results: List[RequestResult] = []
        self.session: Optional[aiohttp.ClientSession] = None
        self.running = False
        
        # Endpoints padrão se não especificados
        if not self.config.endpoints:
            self.config.endpoints = [
                "/health",
                "/api/v1/contracts",
                "/api/v1/entities",
                "/api/v1/quality/rules",
                "/api/v1/audit/logs",
                "/docs"
            ]
    
    async def setup(self):
        """Configura o teste"""
        
        connector = aiohttp.TCPConnector(
            limit=self.config.concurrent_users * 2,
            limit_per_host=self.config.concurrent_users,
            keepalive_timeout=30,
            enable_cleanup_closed=True
        )
        
        timeout = aiohttp.ClientTimeout(total=self.config.request_timeout)
        
        headers = {
            "User-Agent": "GovernanceAPI-LoadTester/1.0",
            "Accept": "application/json"
        }
        
        if self.config.auth_token:
            headers["Authorization"] = f"Bearer {self.config.auth_token}"
        
        self.session = aiohttp.ClientSession(
            connector=connector,
            timeout=timeout,
            headers=headers
        )
    
    async def cleanup(self):
        """Limpa recursos"""
        
        if self.session:
            await self.session.close()
    
    async def run_load_test(self) -> LoadTestResults:
        """Executa o teste de carga"""
        
        print(f"🚀 Iniciando teste de carga...")
        print(f"   Usuários concorrentes: {self.config.concurrent_users}")
        print(f"   Duração: {self.config.test_duration_seconds}s")
        print(f"   Ramp-up: {self.config.ramp_up_seconds}s")
        print(f"   Endpoints: {len(self.config.endpoints)}")
        
        await self.setup()
        
        start_time = datetime.utcnow()
        self.running = True
        
        # Criar tasks para usuários virtuais
        tasks = []
        for user_id in range(self.config.concurrent_users):
            # Calcular delay de ramp-up
            ramp_delay = (user_id / self.config.concurrent_users) * self.config.ramp_up_seconds
            
            task = asyncio.create_task(
                self._virtual_user(user_id, ramp_delay)
            )
            tasks.append(task)
        
        # Aguardar duração do teste
        await asyncio.sleep(self.config.test_duration_seconds + self.config.ramp_up_seconds)
        
        # Parar teste
        self.running = False
        
        # Aguardar conclusão de todas as tasks
        await asyncio.gather(*tasks, return_exceptions=True)
        
        end_time = datetime.utcnow()
        
        await self.cleanup()
        
        # Calcular resultados
        results = self._calculate_results(start_time, end_time)
        
        print(f"✅ Teste concluído!")
        print(f"   Total de requisições: {results.total_requests}")
        print(f"   Taxa de sucesso: {100 - results.error_rate_percent:.1f}%")
        print(f"   RPS médio: {results.requests_per_second:.1f}")
        print(f"   Tempo médio: {results.avg_response_time_ms:.1f}ms")
        
        return results
    
    async def _virtual_user(self, user_id: int, ramp_delay: float):
        """Simula um usuário virtual"""
        
        # Aguardar ramp-up
        await asyncio.sleep(ramp_delay)
        
        while self.running:
            try:
                # Escolher endpoint aleatório
                endpoint = random.choice(self.config.endpoints)
                
                # Fazer requisição
                await self._make_request(endpoint, user_id)
                
                # Think time (pausa entre requisições)
                think_time = random.uniform(
                    self.config.think_time_min,
                    self.config.think_time_max
                )
                await asyncio.sleep(think_time)
                
            except Exception as e:
                # Log erro mas continua
                print(f"Erro no usuário {user_id}: {e}")
    
    async def _make_request(self, endpoint: str, user_id: int):
        """Faz uma requisição HTTP"""
        
        url = f"{self.config.base_url}{endpoint}"
        start_time = time.time()
        
        try:
            # Determinar método baseado no endpoint
            method = "GET"
            data = None
            
            if endpoint in ["/api/v1/contracts", "/api/v1/entities"]:
                if random.random() < 0.3:  # 30% chance de POST
                    method = "POST"
                    data = self._generate_test_data(endpoint)
            
            # Fazer requisição
            if method == "GET":
                async with self.session.get(url) as response:
                    await response.read()  # Consumir resposta
                    status_code = response.status
            else:
                async with self.session.post(url, json=data) as response:
                    await response.read()
                    status_code = response.status
            
            response_time_ms = int((time.time() - start_time) * 1000)
            success = 200 <= status_code < 400
            
            result = RequestResult(
                endpoint=endpoint,
                method=method,
                status_code=status_code,
                response_time_ms=response_time_ms,
                success=success,
                timestamp=datetime.utcnow()
            )
            
            self.results.append(result)
            
        except Exception as e:
            response_time_ms = int((time.time() - start_time) * 1000)
            
            result = RequestResult(
                endpoint=endpoint,
                method=method,
                status_code=0,
                response_time_ms=response_time_ms,
                success=False,
                error_message=str(e),
                timestamp=datetime.utcnow()
            )
            
            self.results.append(result)
    
    def _generate_test_data(self, endpoint: str) -> Dict[str, Any]:
        """Gera dados de teste para requisições POST"""
        
        if "contracts" in endpoint:
            return {
                "name": f"Test Contract {random.randint(1000, 9999)}",
                "description": "Test contract for load testing",
                "version": "1.0.0",
                "status": "draft",
                "owner_id": f"user_{random.randint(1, 100)}"
            }
        elif "entities" in endpoint:
            return {
                "name": f"Test Entity {random.randint(1000, 9999)}",
                "type": "table",
                "description": "Test entity for load testing",
                "schema_name": "test_schema",
                "table_name": f"test_table_{random.randint(1, 100)}"
            }
        
        return {}
    
    def _calculate_results(self, start_time: datetime, end_time: datetime) -> LoadTestResults:
        """Calcula resultados do teste"""
        
        if not self.results:
            return LoadTestResults(
                config=self.config,
                total_requests=0,
                successful_requests=0,
                failed_requests=0,
                avg_response_time_ms=0.0,
                min_response_time_ms=0,
                max_response_time_ms=0,
                p95_response_time_ms=0.0,
                p99_response_time_ms=0.0,
                requests_per_second=0.0,
                error_rate_percent=0.0,
                start_time=start_time,
                end_time=end_time,
                duration_seconds=0.0,
                endpoint_stats={},
                errors_by_type={}
            )
        
        # Estatísticas gerais
        total_requests = len(self.results)
        successful_requests = sum(1 for r in self.results if r.success)
        failed_requests = total_requests - successful_requests
        
        # Tempos de resposta
        response_times = [r.response_time_ms for r in self.results]
        avg_response_time = statistics.mean(response_times)
        min_response_time = min(response_times)
        max_response_time = max(response_times)
        
        # Percentis
        p95_response_time = statistics.quantiles(response_times, n=20)[18]  # 95th percentile
        p99_response_time = statistics.quantiles(response_times, n=100)[98]  # 99th percentile
        
        # Taxa de requisições
        duration_seconds = (end_time - start_time).total_seconds()
        requests_per_second = total_requests / max(duration_seconds, 1)
        
        # Taxa de erro
        error_rate_percent = (failed_requests / max(total_requests, 1)) * 100
        
        # Estatísticas por endpoint
        endpoint_stats = {}
        for endpoint in self.config.endpoints:
            endpoint_results = [r for r in self.results if r.endpoint == endpoint]
            
            if endpoint_results:
                endpoint_response_times = [r.response_time_ms for r in endpoint_results]
                endpoint_successes = sum(1 for r in endpoint_results if r.success)
                
                endpoint_stats[endpoint] = {
                    "total_requests": len(endpoint_results),
                    "successful_requests": endpoint_successes,
                    "failed_requests": len(endpoint_results) - endpoint_successes,
                    "avg_response_time_ms": statistics.mean(endpoint_response_times),
                    "min_response_time_ms": min(endpoint_response_times),
                    "max_response_time_ms": max(endpoint_response_times),
                    "error_rate_percent": ((len(endpoint_results) - endpoint_successes) / len(endpoint_results)) * 100
                }
        
        # Erros por tipo
        errors_by_type = {}
        for result in self.results:
            if not result.success:
                if result.status_code > 0:
                    error_key = f"HTTP_{result.status_code}"
                else:
                    error_key = result.error_message or "Unknown"
                
                errors_by_type[error_key] = errors_by_type.get(error_key, 0) + 1
        
        return LoadTestResults(
            config=self.config,
            total_requests=total_requests,
            successful_requests=successful_requests,
            failed_requests=failed_requests,
            avg_response_time_ms=round(avg_response_time, 2),
            min_response_time_ms=min_response_time,
            max_response_time_ms=max_response_time,
            p95_response_time_ms=round(p95_response_time, 2),
            p99_response_time_ms=round(p99_response_time, 2),
            requests_per_second=round(requests_per_second, 2),
            error_rate_percent=round(error_rate_percent, 2),
            start_time=start_time,
            end_time=end_time,
            duration_seconds=round(duration_seconds, 2),
            endpoint_stats=endpoint_stats,
            errors_by_type=errors_by_type
        )


class RateLimitTester:
    """Testador de rate limiting"""
    
    def __init__(self, base_url: str = "http://localhost:8000"):
        self.base_url = base_url
        self.session: Optional[aiohttp.ClientSession] = None
    
    async def setup(self):
        """Configura o testador"""
        
        connector = aiohttp.TCPConnector(limit=100)
        timeout = aiohttp.ClientTimeout(total=10)
        
        self.session = aiohttp.ClientSession(
            connector=connector,
            timeout=timeout
        )
    
    async def cleanup(self):
        """Limpa recursos"""
        
        if self.session:
            await self.session.close()
    
    async def test_rate_limiting(
        self,
        endpoint: str = "/api/v1/contracts",
        requests_per_minute: int = 150,  # Acima do limite padrão
        test_duration_minutes: int = 2
    ) -> Dict[str, Any]:
        """Testa rate limiting"""
        
        print(f"🔒 Testando rate limiting...")
        print(f"   Endpoint: {endpoint}")
        print(f"   Requisições/min: {requests_per_minute}")
        print(f"   Duração: {test_duration_minutes} minutos")
        
        await self.setup()
        
        results = {
            "total_requests": 0,
            "successful_requests": 0,
            "rate_limited_requests": 0,
            "other_errors": 0,
            "rate_limit_triggered": False,
            "first_rate_limit_at": None,
            "response_times": []
        }
        
        url = f"{self.base_url}{endpoint}"
        interval = 60 / requests_per_minute  # Intervalo entre requisições
        
        start_time = time.time()
        end_time = start_time + (test_duration_minutes * 60)
        
        while time.time() < end_time:
            request_start = time.time()
            
            try:
                async with self.session.get(url) as response:
                    response_time = int((time.time() - request_start) * 1000)
                    results["response_times"].append(response_time)
                    results["total_requests"] += 1
                    
                    if response.status == 200:
                        results["successful_requests"] += 1
                    elif response.status == 429:  # Too Many Requests
                        results["rate_limited_requests"] += 1
                        if not results["rate_limit_triggered"]:
                            results["rate_limit_triggered"] = True
                            results["first_rate_limit_at"] = time.time() - start_time
                            print(f"   ⚠️  Rate limit ativado após {results['first_rate_limit_at']:.1f}s")
                    else:
                        results["other_errors"] += 1
            
            except Exception as e:
                results["other_errors"] += 1
                print(f"   ❌ Erro: {e}")
            
            # Aguardar próxima requisição
            await asyncio.sleep(interval)
        
        await self.cleanup()
        
        # Calcular estatísticas
        if results["response_times"]:
            results["avg_response_time_ms"] = statistics.mean(results["response_times"])
            results["max_response_time_ms"] = max(results["response_times"])
        
        results["success_rate_percent"] = (
            results["successful_requests"] / max(results["total_requests"], 1)
        ) * 100
        
        results["rate_limit_rate_percent"] = (
            results["rate_limited_requests"] / max(results["total_requests"], 1)
        ) * 100
        
        print(f"✅ Teste de rate limiting concluído!")
        print(f"   Total: {results['total_requests']} requisições")
        print(f"   Sucesso: {results['successful_requests']} ({results['success_rate_percent']:.1f}%)")
        print(f"   Rate limited: {results['rate_limited_requests']} ({results['rate_limit_rate_percent']:.1f}%)")
        
        return results


async def run_comprehensive_load_test():
    """Executa teste de carga abrangente"""
    
    print("🧪 Iniciando Teste de Carga Abrangente")
    print("=" * 50)
    
    # Configurações de teste
    configs = [
        LoadTestConfig(
            concurrent_users=10,
            test_duration_seconds=60,
            ramp_up_seconds=10
        ),
        LoadTestConfig(
            concurrent_users=50,
            test_duration_seconds=180,
            ramp_up_seconds=30
        ),
        LoadTestConfig(
            concurrent_users=100,
            test_duration_seconds=300,
            ramp_up_seconds=60
        )
    ]
    
    all_results = []
    
    for i, config in enumerate(configs, 1):
        print(f"\n📊 Teste {i}/3: {config.concurrent_users} usuários")
        print("-" * 30)
        
        runner = LoadTestRunner(config)
        results = await runner.run_load_test()
        all_results.append(results)
        
        # Pausa entre testes
        if i < len(configs):
            print("⏳ Aguardando 30s antes do próximo teste...")
            await asyncio.sleep(30)
    
    # Teste de rate limiting
    print(f"\n🔒 Teste de Rate Limiting")
    print("-" * 30)
    
    rate_tester = RateLimitTester()
    rate_results = await rate_tester.test_rate_limiting()
    
    # Salvar resultados
    timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    
    with open(f"load_test_results_{timestamp}.json", "w") as f:
        json.dump({
            "load_tests": [asdict(result) for result in all_results],
            "rate_limit_test": rate_results,
            "timestamp": timestamp
        }, f, indent=2, default=str)
    
    print(f"\n✅ Todos os testes concluídos!")
    print(f"📄 Resultados salvos em: load_test_results_{timestamp}.json")
    
    return all_results, rate_results


if __name__ == "__main__":
    asyncio.run(run_comprehensive_load_test())

