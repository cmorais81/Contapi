"""
Testes Específicos para 100% Cobertura de Tratamento de Erros
"""

import pytest
import asyncio
from unittest.mock import Mock, AsyncMock, patch
from datetime import datetime
from uuid import uuid4
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from governance_api.domain.exceptions import (
    BusinessRuleViolation,
    EntityNotFoundError,
    UnauthorizedError,
    ValidationError,
    DuplicateEntityError,
    IntegrationError
)


class TestDomainExceptions:
    """Testes para todas as exceções de domínio"""
    
    def test_business_rule_violation_with_details(self):
        """Testa BusinessRuleViolation com detalhes"""
        details = {"field": "name", "value": "", "constraint": "not_empty"}
        exception = BusinessRuleViolation("Name cannot be empty", details)
        
        assert str(exception) == "Name cannot be empty"
        assert exception.details == details
        assert exception.details["field"] == "name"
    
    def test_entity_not_found_error_with_id(self):
        """Testa EntityNotFoundError com ID específico"""
        entity_id = uuid4()
        entity_type = "DataContract"
        exception = EntityNotFoundError(entity_type, entity_id)
        
        assert entity_type in str(exception)
        assert str(entity_id) in str(exception)
        assert exception.entity_type == entity_type
        assert exception.entity_id == entity_id
    
    def test_unauthorized_error_with_action(self):
        """Testa UnauthorizedError com ação específica"""
        action = "delete_contract"
        resource = "contract_123"
        exception = UnauthorizedError(f"Not authorized to {action} on {resource}")
        
        assert action in str(exception)
        assert resource in str(exception)
    
    def test_validation_error_with_field_errors(self):
        """Testa ValidationError com erros de campo"""
        field_errors = {
            "name": ["Name is required", "Name must be at least 3 characters"],
            "email": ["Invalid email format"],
            "version": ["Version must follow semantic versioning"]
        }
        exception = ValidationError("Validation failed", field_errors)
        
        assert "Validation failed" in str(exception)
        assert exception.field_errors == field_errors
        assert len(exception.field_errors["name"]) == 2
    
    def test_duplicate_entity_error(self):
        """Testa DuplicateEntityError"""
        entity_type = "DataContract"
        identifier = "customer_contract_v1"
        exception = DuplicateEntityError(entity_type, identifier)
        
        assert entity_type in str(exception)
        assert identifier in str(exception)
        assert exception.entity_type == entity_type
        assert exception.identifier == identifier
    
    def test_integration_error_with_system(self):
        """Testa IntegrationError com sistema específico"""
        system = "Unity Catalog"
        operation = "fetch_metadata"
        error_details = {"status_code": 500, "message": "Internal server error"}
        exception = IntegrationError(system, operation, error_details)
        
        assert system in str(exception)
        assert operation in str(exception)
        assert exception.system == system
        assert exception.operation == operation
        assert exception.error_details == error_details


class TestHTTPExceptionHandling:
    """Testes para tratamento de exceções HTTP"""
    
    def test_400_bad_request_handling(self):
        """Testa tratamento de Bad Request (400)"""
        from fastapi import HTTPException, status
        
        # Simula erro de validação
        with pytest.raises(HTTPException) as exc_info:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid request data"
            )
        
        assert exc_info.value.status_code == 400
        assert "Invalid request data" in str(exc_info.value.detail)
    
    def test_401_unauthorized_handling(self):
        """Testa tratamento de Unauthorized (401)"""
        from fastapi import HTTPException, status
        
        with pytest.raises(HTTPException) as exc_info:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Authentication required",
                headers={"WWW-Authenticate": "Bearer"}
            )
        
        assert exc_info.value.status_code == 401
        assert exc_info.value.headers == {"WWW-Authenticate": "Bearer"}
    
    def test_403_forbidden_handling(self):
        """Testa tratamento de Forbidden (403)"""
        from fastapi import HTTPException, status
        
        with pytest.raises(HTTPException) as exc_info:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Insufficient permissions"
            )
        
        assert exc_info.value.status_code == 403
        assert "permissions" in str(exc_info.value.detail).lower()
    
    def test_404_not_found_handling(self):
        """Testa tratamento de Not Found (404)"""
        from fastapi import HTTPException, status
        
        entity_id = uuid4()
        with pytest.raises(HTTPException) as exc_info:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Entity {entity_id} not found"
            )
        
        assert exc_info.value.status_code == 404
        assert str(entity_id) in str(exc_info.value.detail)
    
    def test_409_conflict_handling(self):
        """Testa tratamento de Conflict (409)"""
        from fastapi import HTTPException, status
        
        with pytest.raises(HTTPException) as exc_info:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Entity already exists"
            )
        
        assert exc_info.value.status_code == 409
        assert "already exists" in str(exc_info.value.detail)
    
    def test_422_validation_error_handling(self):
        """Testa tratamento de Validation Error (422)"""
        from fastapi import HTTPException, status
        
        validation_details = [
            {
                "loc": ["body", "name"],
                "msg": "field required",
                "type": "value_error.missing"
            },
            {
                "loc": ["body", "email"],
                "msg": "invalid email format",
                "type": "value_error.email"
            }
        ]
        
        with pytest.raises(HTTPException) as exc_info:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=validation_details
            )
        
        assert exc_info.value.status_code == 422
        assert isinstance(exc_info.value.detail, list)
        assert len(exc_info.value.detail) == 2
    
    def test_500_internal_server_error_handling(self):
        """Testa tratamento de Internal Server Error (500)"""
        from fastapi import HTTPException, status
        
        with pytest.raises(HTTPException) as exc_info:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Internal server error occurred"
            )
        
        assert exc_info.value.status_code == 500
        assert "internal server error" in str(exc_info.value.detail).lower()


class TestDatabaseExceptionHandling:
    """Testes para tratamento de exceções de banco de dados"""
    
    @pytest.mark.asyncio
    async def test_connection_error_handling(self):
        """Testa tratamento de erro de conexão com banco"""
        from sqlalchemy.exc import OperationalError
        
        # Simula erro de conexão
        with pytest.raises(OperationalError):
            raise OperationalError("Connection failed", None, None)
    
    @pytest.mark.asyncio
    async def test_integrity_constraint_error_handling(self):
        """Testa tratamento de erro de constraint de integridade"""
        from sqlalchemy.exc import IntegrityError
        
        with pytest.raises(IntegrityError):
            raise IntegrityError("Duplicate key violation", None, None)
    
    @pytest.mark.asyncio
    async def test_transaction_rollback_handling(self):
        """Testa tratamento de rollback de transação"""
        from sqlalchemy.exc import StatementError
        
        with pytest.raises(StatementError):
            raise StatementError("Transaction rolled back", None, None, None)


class TestExternalServiceExceptionHandling:
    """Testes para tratamento de exceções de serviços externos"""
    
    @pytest.mark.asyncio
    async def test_unity_catalog_connection_error(self):
        """Testa erro de conexão com Unity Catalog"""
        import aiohttp
        
        with pytest.raises(aiohttp.ClientError):
            raise aiohttp.ClientConnectionError("Connection to Unity Catalog failed")
    
    @pytest.mark.asyncio
    async def test_unity_catalog_timeout_error(self):
        """Testa timeout de Unity Catalog"""
        import asyncio
        
        with pytest.raises(asyncio.TimeoutError):
            raise asyncio.TimeoutError("Unity Catalog request timed out")
    
    @pytest.mark.asyncio
    async def test_unity_catalog_authentication_error(self):
        """Testa erro de autenticação com Unity Catalog"""
        import aiohttp
        
        with pytest.raises(aiohttp.ClientResponseError) as exc_info:
            error = aiohttp.ClientResponseError(
                request_info=Mock(),
                history=(),
                status=401,
                message="Unauthorized"
            )
            raise error
        
        assert exc_info.value.status == 401
    
    @pytest.mark.asyncio
    async def test_redis_connection_error(self):
        """Testa erro de conexão com Redis"""
        import redis
        
        with pytest.raises(redis.ConnectionError):
            raise redis.ConnectionError("Redis connection failed")
    
    @pytest.mark.asyncio
    async def test_webhook_delivery_error(self):
        """Testa erro de entrega de webhook"""
        import aiohttp
        
        with pytest.raises(aiohttp.ClientError):
            raise aiohttp.ClientError("Webhook delivery failed")


class TestValidationExceptionHandling:
    """Testes para tratamento de exceções de validação"""
    
    def test_pydantic_validation_error(self):
        """Testa erro de validação Pydantic"""
        from pydantic import ValidationError, BaseModel, Field
        from typing import List
        
        class TestModel(BaseModel):
            name: str = Field(..., min_length=1)
            email: str = Field(..., regex=r'^[^@]+@[^@]+\.[^@]+$')
            age: int = Field(..., ge=0, le=150)
        
        # Testa dados inválidos
        with pytest.raises(ValidationError) as exc_info:
            TestModel(name="", email="invalid-email", age=-1)
        
        errors = exc_info.value.errors()
        assert len(errors) >= 3  # name, email, age
        
        # Verifica tipos de erro
        error_types = [error['type'] for error in errors]
        assert 'value_error.any_str.min_length' in error_types or 'string_too_short' in error_types
        assert any('pattern' in error_type or 'string_pattern_mismatch' in error_type for error_type in error_types)
        assert 'value_error.number.not_ge' in error_types or 'greater_than_equal' in error_types
    
    def test_json_schema_validation_error(self):
        """Testa erro de validação de schema JSON"""
        import jsonschema
        
        schema = {
            "type": "object",
            "properties": {
                "name": {"type": "string", "minLength": 1},
                "age": {"type": "integer", "minimum": 0}
            },
            "required": ["name", "age"]
        }
        
        invalid_data = {
            "name": "",  # Muito curto
            "age": -1    # Negativo
        }
        
        with pytest.raises(jsonschema.ValidationError):
            jsonschema.validate(invalid_data, schema)
    
    def test_custom_validation_error(self):
        """Testa erro de validação customizada"""
        def validate_contract_name(name: str) -> None:
            if not name:
                raise ValidationError("Contract name is required")
            if len(name) < 3:
                raise ValidationError("Contract name must be at least 3 characters")
            if not name.replace('_', '').replace('-', '').isalnum():
                raise ValidationError("Contract name must contain only alphanumeric characters, hyphens, and underscores")
        
        # Testa casos inválidos
        with pytest.raises(ValidationError, match="required"):
            validate_contract_name("")
        
        with pytest.raises(ValidationError, match="at least 3 characters"):
            validate_contract_name("ab")
        
        with pytest.raises(ValidationError, match="alphanumeric"):
            validate_contract_name("invalid@name!")


class TestAsyncExceptionHandling:
    """Testes para tratamento de exceções assíncronas"""
    
    @pytest.mark.asyncio
    async def test_async_timeout_handling(self):
        """Testa tratamento de timeout em operações assíncronas"""
        import asyncio
        
        async def slow_operation():
            await asyncio.sleep(2)
            return "completed"
        
        with pytest.raises(asyncio.TimeoutError):
            await asyncio.wait_for(slow_operation(), timeout=0.1)
    
    @pytest.mark.asyncio
    async def test_async_cancellation_handling(self):
        """Testa tratamento de cancelamento de operações assíncronas"""
        import asyncio
        
        async def cancellable_operation():
            try:
                await asyncio.sleep(1)
                return "completed"
            except asyncio.CancelledError:
                # Cleanup code here
                raise
        
        task = asyncio.create_task(cancellable_operation())
        await asyncio.sleep(0.1)
        task.cancel()
        
        with pytest.raises(asyncio.CancelledError):
            await task
    
    @pytest.mark.asyncio
    async def test_async_exception_propagation(self):
        """Testa propagação de exceções em operações assíncronas"""
        async def failing_operation():
            raise BusinessRuleViolation("Async operation failed")
        
        async def calling_operation():
            try:
                await failing_operation()
            except BusinessRuleViolation:
                # Re-raise with additional context
                raise BusinessRuleViolation("Calling operation failed due to business rule violation")
        
        with pytest.raises(BusinessRuleViolation, match="Calling operation failed"):
            await calling_operation()


class TestErrorRecoveryScenarios:
    """Testes para cenários de recuperação de erros"""
    
    @pytest.mark.asyncio
    async def test_retry_mechanism(self):
        """Testa mecanismo de retry"""
        import asyncio
        
        attempt_count = 0
        max_attempts = 3
        
        async def unreliable_operation():
            nonlocal attempt_count
            attempt_count += 1
            
            if attempt_count < max_attempts:
                raise ConnectionError(f"Attempt {attempt_count} failed")
            
            return f"Success on attempt {attempt_count}"
        
        async def retry_operation():
            for attempt in range(max_attempts):
                try:
                    return await unreliable_operation()
                except ConnectionError:
                    if attempt == max_attempts - 1:
                        raise
                    await asyncio.sleep(0.1)  # Wait before retry
        
        result = await retry_operation()
        assert "Success" in result
        assert attempt_count == max_attempts
    
    @pytest.mark.asyncio
    async def test_circuit_breaker_pattern(self):
        """Testa padrão Circuit Breaker"""
        class CircuitBreaker:
            def __init__(self, failure_threshold=3, timeout=1):
                self.failure_threshold = failure_threshold
                self.timeout = timeout
                self.failure_count = 0
                self.last_failure_time = None
                self.state = "CLOSED"  # CLOSED, OPEN, HALF_OPEN
            
            async def call(self, func):
                if self.state == "OPEN":
                    if datetime.now().timestamp() - self.last_failure_time > self.timeout:
                        self.state = "HALF_OPEN"
                    else:
                        raise Exception("Circuit breaker is OPEN")
                
                try:
                    result = await func()
                    if self.state == "HALF_OPEN":
                        self.state = "CLOSED"
                        self.failure_count = 0
                    return result
                except Exception as e:
                    self.failure_count += 1
                    self.last_failure_time = datetime.now().timestamp()
                    
                    if self.failure_count >= self.failure_threshold:
                        self.state = "OPEN"
                    
                    raise e
        
        circuit_breaker = CircuitBreaker(failure_threshold=2)
        
        async def failing_service():
            raise ConnectionError("Service unavailable")
        
        # First failure
        with pytest.raises(ConnectionError):
            await circuit_breaker.call(failing_service)
        
        # Second failure - should open circuit
        with pytest.raises(ConnectionError):
            await circuit_breaker.call(failing_service)
        
        # Circuit should be open now
        assert circuit_breaker.state == "OPEN"
        
        # Subsequent calls should fail fast
        with pytest.raises(Exception, match="Circuit breaker is OPEN"):
            await circuit_breaker.call(failing_service)


class TestLoggingAndMonitoring:
    """Testes para logging e monitoramento de erros"""
    
    def test_error_logging(self):
        """Testa logging de erros"""
        import logging
        from io import StringIO
        
        # Configura logger para capturar output
        log_stream = StringIO()
        handler = logging.StreamHandler(log_stream)
        logger = logging.getLogger("test_logger")
        logger.addHandler(handler)
        logger.setLevel(logging.ERROR)
        
        try:
            raise BusinessRuleViolation("Test error for logging")
        except BusinessRuleViolation as e:
            logger.error(f"Business rule violation: {e}", exc_info=True)
        
        log_output = log_stream.getvalue()
        assert "Business rule violation" in log_output
        assert "Test error for logging" in log_output
    
    def test_error_metrics_collection(self):
        """Testa coleta de métricas de erro"""
        error_metrics = {
            "total_errors": 0,
            "error_types": {},
            "error_rates": {}
        }
        
        def record_error(error_type: str):
            error_metrics["total_errors"] += 1
            error_metrics["error_types"][error_type] = error_metrics["error_types"].get(error_type, 0) + 1
        
        # Simula diferentes tipos de erro
        record_error("ValidationError")
        record_error("BusinessRuleViolation")
        record_error("ValidationError")
        record_error("EntityNotFoundError")
        
        assert error_metrics["total_errors"] == 4
        assert error_metrics["error_types"]["ValidationError"] == 2
        assert error_metrics["error_types"]["BusinessRuleViolation"] == 1
        assert error_metrics["error_types"]["EntityNotFoundError"] == 1


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])

