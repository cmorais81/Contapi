"""
Fixtures para testes automatizados
"""
import pytest
import asyncio
from typing import AsyncGenerator, Dict, Any
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.pool import StaticPool
from httpx import AsyncClient

from src.main import app
from src.database.connection import get_async_session
from src.database.models import Base
from src.database.mock_data import MockDataFactory
from src.config.settings import get_settings


# Configuração de banco de teste
TEST_DATABASE_URL = "sqlite+aiosqlite:///:memory:"


@pytest.fixture(scope="session")
def event_loop():
    """Cria event loop para testes assíncronos"""
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()


@pytest.fixture(scope="session")
async def test_engine():
    """Cria engine de teste com SQLite em memória"""
    engine = create_async_engine(
        TEST_DATABASE_URL,
        poolclass=StaticPool,
        connect_args={"check_same_thread": False},
        echo=False
    )
    
    # Criar tabelas
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    
    yield engine
    
    # Cleanup
    await engine.dispose()


@pytest.fixture
async def test_session(test_engine) -> AsyncGenerator[AsyncSession, None]:
    """Cria sessão de teste"""
    async with AsyncSession(test_engine, expire_on_commit=False) as session:
        yield session
        await session.rollback()


@pytest.fixture
async def test_client(test_session) -> AsyncGenerator[AsyncClient, None]:
    """Cria cliente de teste HTTP"""
    
    # Override da dependência de sessão
    async def override_get_session():
        yield test_session
    
    app.dependency_overrides[get_async_session] = override_get_session
    
    async with AsyncClient(app=app, base_url="http://test") as client:
        yield client
    
    # Limpar overrides
    app.dependency_overrides.clear()


@pytest.fixture
def mock_user_data():
    """Dados mocados de usuário"""
    return MockDataFactory.create_users(1)[0]


@pytest.fixture
def mock_contract_data():
    """Dados mocados de contrato"""
    return MockDataFactory.create_data_contracts(1)[0]


@pytest.fixture
def mock_entity_data():
    """Dados mocados de entidade"""
    return MockDataFactory.create_entities(1)[0]


@pytest.fixture
def mock_quality_rule_data():
    """Dados mocados de regra de qualidade"""
    return MockDataFactory.create_quality_rules(1)[0]


@pytest.fixture
def mock_quality_metric_data():
    """Dados mocados de métrica de qualidade"""
    return MockDataFactory.create_quality_metrics(1)[0]


@pytest.fixture
def mock_governance_policy_data():
    """Dados mocados de política de governança"""
    return MockDataFactory.create_governance_policies(1)[0]


@pytest.fixture
async def sample_dataset(test_session):
    """Dataset completo para testes"""
    from src.database.seeders import DatabaseSeeder
    
    seeder = DatabaseSeeder(test_session)
    counts = await seeder.seed_all("small")
    await test_session.commit()
    
    return counts


@pytest.fixture
def auth_headers():
    """Headers de autenticação para testes"""
    # Token JWT dummy para testes
    token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoidGVzdC11c2VyIiwiZXhwIjo5OTk5OTk5OTk5fQ.test_signature"
    return {"Authorization": f"Bearer {token}"}


@pytest.fixture
def api_client_authenticated(test_client, auth_headers):
    """Cliente HTTP autenticado"""
    test_client.headers.update(auth_headers)
    return test_client


# Fixtures específicas para cada endpoint

@pytest.fixture
async def created_user(test_session, mock_user_data):
    """Usuário criado no banco de teste"""
    from src.database.models import User
    
    user = User(**mock_user_data)
    test_session.add(user)
    await test_session.commit()
    await test_session.refresh(user)
    
    return user


@pytest.fixture
async def created_contract(test_session, mock_contract_data):
    """Contrato criado no banco de teste"""
    from src.database.models import DataContract
    
    contract = DataContract(**mock_contract_data)
    test_session.add(contract)
    await test_session.commit()
    await test_session.refresh(contract)
    
    return contract


@pytest.fixture
async def created_entity(test_session, mock_entity_data):
    """Entidade criada no banco de teste"""
    from src.database.models import Entity
    
    entity = Entity(**mock_entity_data)
    test_session.add(entity)
    await test_session.commit()
    await test_session.refresh(entity)
    
    return entity


@pytest.fixture
async def created_quality_rule(test_session, mock_quality_rule_data):
    """Regra de qualidade criada no banco de teste"""
    from src.database.models import QualityRule
    
    rule = QualityRule(**mock_quality_rule_data)
    test_session.add(rule)
    await test_session.commit()
    await test_session.refresh(rule)
    
    return rule


# Fixtures para dados de request

@pytest.fixture
def contract_create_request():
    """Dados para criação de contrato"""
    return {
        "name": "Test Contract",
        "description": "Contrato de teste",
        "version": "1.0.0",
        "contract_type": "api",
        "owner_email": "test@example.com",
        "schema_definition": {
            "type": "object",
            "properties": {
                "id": {"type": "string"},
                "name": {"type": "string"}
            }
        },
        "sla_availability": 99.9,
        "sla_response_time": 100
    }


@pytest.fixture
def entity_create_request():
    """Dados para criação de entidade"""
    return {
        "name": "test_entity",
        "display_name": "Test Entity",
        "description": "Entidade de teste",
        "entity_type": "table",
        "domain": "test",
        "owner_email": "test@example.com",
        "schema_name": "test_schema",
        "table_name": "test_table",
        "unity_catalog_path": "catalog.test.test_table"
    }


@pytest.fixture
def quality_rule_create_request():
    """Dados para criação de regra de qualidade"""
    return {
        "name": "Test Rule",
        "description": "Regra de teste",
        "rule_type": "not_null",
        "column_name": "id",
        "parameters": {},
        "severity": "error"
    }


# Fixtures para validação de resposta

@pytest.fixture
def expected_contract_response():
    """Estrutura esperada de resposta de contrato"""
    return {
        "id": str,
        "name": str,
        "description": str,
        "version": str,
        "status": str,
        "contract_type": str,
        "owner_email": str,
        "schema_definition": dict,
        "sla_availability": float,
        "sla_response_time": int,
        "created_at": str,
        "updated_at": str
    }


@pytest.fixture
def expected_entity_response():
    """Estrutura esperada de resposta de entidade"""
    return {
        "id": str,
        "name": str,
        "display_name": str,
        "description": str,
        "entity_type": str,
        "domain": str,
        "owner_email": str,
        "schema_name": str,
        "table_name": str,
        "unity_catalog_path": str,
        "is_active": bool,
        "tags": list,
        "created_at": str,
        "updated_at": str
    }


# Fixtures para performance testing

@pytest.fixture
def performance_dataset():
    """Dataset para testes de performance"""
    return MockDataFactory.create_complete_dataset("large")


# Fixtures para testes de integração

@pytest.fixture
async def integration_environment(test_session):
    """Ambiente completo para testes de integração"""
    from src.database.seeders import DatabaseSeeder
    
    seeder = DatabaseSeeder(test_session)
    
    # Criar dataset médio
    counts = await seeder.seed_all("medium")
    await test_session.commit()
    
    return {
        "session": test_session,
        "counts": counts,
        "settings": get_settings()
    }


# Fixtures para testes de erro

@pytest.fixture
def invalid_contract_data():
    """Dados inválidos para teste de erro"""
    return {
        "name": "",  # Nome vazio
        "version": "invalid-version",  # Versão inválida
        "owner_email": "invalid-email",  # Email inválido
        "sla_availability": 150.0  # Valor impossível
    }


@pytest.fixture
def invalid_entity_data():
    """Dados inválidos de entidade"""
    return {
        "name": "invalid name with spaces",  # Nome inválido
        "entity_type": "invalid_type",  # Tipo inválido
        "owner_email": "not-an-email"  # Email inválido
    }

