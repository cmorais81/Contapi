"""
Script de Setup para Windows - API de Governança de Dados V1.3
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
Organização: F1rst

Este script configura o ambiente completo no Windows.
"""

import sys
import os
import subprocess
import platform
from pathlib import Path

def check_python_version():
    """Verifica se a versão do Python é compatível"""
    
    version = sys.version_info
    print(f"Python {version.major}.{version.minor}.{version.micro} detectado")
    
    if version.major < 3 or (version.major == 3 and version.minor < 9):
        print("ERRO: Python 3.9+ é necessário")
        print("Por favor, atualize sua versão do Python")
        return False
    
    if version.major == 3 and version.minor >= 13:
        print("✓ Python 3.13+ detectado - Totalmente compatível")
    elif version.major == 3 and version.minor >= 11:
        print("✓ Python 3.11+ detectado - Compatível")
    else:
        print("⚠ Python 3.9-3.10 detectado - Compatível com limitações")
    
    return True

def check_platform():
    """Verifica informações da plataforma"""
    
    print(f"Sistema Operacional: {platform.system()} {platform.release()}")
    print(f"Arquitetura: {platform.machine()}")
    print(f"Processador: {platform.processor()}")
    
    if platform.system() != "Windows":
        print("⚠ Este script foi otimizado para Windows")
        print("Para outros sistemas, use os scripts específicos")
    else:
        print("✓ Windows detectado")
    
    return True

def install_dependencies():
    """Instala as dependências necessárias"""
    
    print("\nInstalando dependências...")
    
    try:
        # Atualizar pip
        print("Atualizando pip...")
        subprocess.run([sys.executable, "-m", "pip", "install", "--upgrade", "pip"], 
                      check=True, capture_output=True)
        
        # Instalar wheel e setuptools
        print("Instalando wheel e setuptools...")
        subprocess.run([sys.executable, "-m", "pip", "install", "--upgrade", "wheel", "setuptools"], 
                      check=True, capture_output=True)
        
        # Instalar dependências do requirements.txt
        requirements_file = Path(__file__).parent / "requirements.txt"
        if requirements_file.exists():
            print("Instalando dependências do requirements.txt...")
            subprocess.run([sys.executable, "-m", "pip", "install", "-r", str(requirements_file)], 
                          check=True)
            print("✓ Dependências instaladas com sucesso")
        else:
            print("⚠ Arquivo requirements.txt não encontrado")
            return False
            
    except subprocess.CalledProcessError as e:
        print(f"ERRO: Falha ao instalar dependências: {e}")
        return False
    except Exception as e:
        print(f"ERRO: {e}")
        return False
    
    return True

def setup_environment():
    """Configura o ambiente"""
    
    print("\nConfigurando ambiente...")
    
    # Criar arquivo .env se não existir
    env_file = Path(__file__).parent / ".env"
    if not env_file.exists():
        print("Criando arquivo .env...")
        env_content = """# Configuração da API de Governança V1.3
DATABASE_URL=postgresql://governance_user:governance_pass@localhost:5432/governance_db
REDIS_URL=redis://localhost:6379/0
SECRET_KEY=your-secret-key-change-in-production
JWT_ALGORITHM=HS256
JWT_EXPIRE_MINUTES=30
ENVIRONMENT=development

# Azure (opcional - configure se necessário)
AZURE_CLIENT_ID=
AZURE_CLIENT_SECRET=
AZURE_TENANT_ID=

# Databricks (opcional - configure se necessário)
DATABRICKS_WORKSPACE_URL=
DATABRICKS_TOKEN=

# Monitoramento
PROMETHEUS_ENABLED=true
GRAFANA_ENABLED=true
LOG_LEVEL=INFO

# Email (configure para notificações)
SMTP_HOST=
SMTP_PORT=587
SMTP_USER=
SMTP_PASSWORD=
"""
        env_file.write_text(env_content)
        print("✓ Arquivo .env criado")
    else:
        print("✓ Arquivo .env já existe")
    
    # Configurar PYTHONPATH
    src_dir = Path(__file__).parent / "src"
    current_pythonpath = os.environ.get('PYTHONPATH', '')
    
    if str(src_dir) not in current_pythonpath:
        if current_pythonpath:
            os.environ['PYTHONPATH'] = f"{src_dir}{os.pathsep}{current_pythonpath}"
        else:
            os.environ['PYTHONPATH'] = str(src_dir)
        print(f"✓ PYTHONPATH configurado: {os.environ['PYTHONPATH']}")
    
    return True

def test_import():
    """Testa se os imports funcionam"""
    
    print("\nTestando imports...")
    
    try:
        import fastapi
        print(f"✓ FastAPI {fastapi.__version__}")
    except ImportError:
        print("✗ FastAPI não pôde ser importado")
        return False
    
    try:
        import uvicorn
        print(f"✓ Uvicorn {uvicorn.__version__}")
    except ImportError:
        print("✗ Uvicorn não pôde ser importado")
        return False
    
    try:
        import sqlalchemy
        print(f"✓ SQLAlchemy {sqlalchemy.__version__}")
    except ImportError:
        print("✗ SQLAlchemy não pôde ser importado")
        return False
    
    try:
        import pydantic
        print(f"✓ Pydantic {pydantic.__version__}")
    except ImportError:
        print("✗ Pydantic não pôde ser importado")
        return False
    
    # Testar import do main
    try:
        sys.path.insert(0, str(Path(__file__).parent / "src"))
        import main
        print("✓ Módulo main importado com sucesso")
    except ImportError as e:
        print(f"⚠ Módulo main com problemas: {e}")
        print("Isso é normal se alguns controllers estão faltando")
    
    return True

def create_shortcuts():
    """Cria atalhos para execução"""
    
    print("\nCriando atalhos...")
    
    # Criar script de execução rápida
    quick_start = Path(__file__).parent / "start_api.py"
    quick_start_content = '''"""
Execução rápida da API de Governança de Dados V1.3
"""

import sys
from pathlib import Path

# Adicionar src ao path
sys.path.insert(0, str(Path(__file__).parent / "src"))

# Executar API
if __name__ == "__main__":
    import uvicorn
    from main import app
    
    print("API de Governança de Dados V1.3")
    print("Acesse: http://localhost:8000")
    print("Docs: http://localhost:8000/docs")
    
    uvicorn.run(app, host="0.0.0.0", port=8000, reload=True)
'''
    
    quick_start.write_text(quick_start_content)
    print("✓ Script start_api.py criado")
    
    return True

def main():
    """Função principal do setup"""
    
    print("=" * 60)
    print("SETUP - API de Governança de Dados V1.3")
    print("Desenvolvida por: Carlos Morais")
    print("Email: carlos.morais@f1rst.com.br")
    print("Organização: F1rst")
    print("=" * 60)
    
    # Verificar Python
    if not check_python_version():
        input("Pressione Enter para sair...")
        return
    
    # Verificar plataforma
    check_platform()
    
    # Instalar dependências
    if not install_dependencies():
        input("Pressione Enter para sair...")
        return
    
    # Configurar ambiente
    if not setup_environment():
        input("Pressione Enter para sair...")
        return
    
    # Testar imports
    if not test_import():
        print("⚠ Alguns imports falharam, mas a API pode funcionar parcialmente")
    
    # Criar atalhos
    create_shortcuts()
    
    print("\n" + "=" * 60)
    print("SETUP CONCLUÍDO COM SUCESSO!")
    print("=" * 60)
    print("\nPara executar a API:")
    print("1. Execute: python run_windows.py")
    print("2. Ou execute: run_windows.bat")
    print("3. Ou execute: python start_api.py")
    print("\nAcesse: http://localhost:8000")
    print("Documentação: http://localhost:8000/docs")
    print("\nDesenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)")
    
    input("\nPressione Enter para finalizar...")

if __name__ == "__main__":
    main()

