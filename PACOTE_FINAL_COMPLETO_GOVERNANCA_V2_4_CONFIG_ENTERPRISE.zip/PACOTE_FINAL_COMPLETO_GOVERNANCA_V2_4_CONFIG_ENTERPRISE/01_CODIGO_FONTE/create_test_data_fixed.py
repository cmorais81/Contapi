#!/usr/bin/env python3
"""
Script para criar dados de teste para a aplicação de Governança de Dados
Versão corrigida com foreign keys válidas
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
from src.database.models import *
from src.database.base import Base
import uuid
from datetime import datetime, timedelta
import json

# Configuração do banco
DATABASE_URL = "postgresql://postgres:postgres@localhost:5432/governanca_dados"

def create_test_data():
    """Cria dados de teste completos"""
    try:
        # Conectar ao banco
        engine = create_engine(DATABASE_URL)
        Base.metadata.create_all(engine)
        Session = sessionmaker(bind=engine)
        session = Session()
        
        print("=== Criando Dados de Teste Completos ===")
        
        # 1. Limpar dados existentes
        print("Limpando dados existentes...")
        session.execute(text("TRUNCATE TABLE user_roles, api_keys, user_sessions, users, security_roles CASCADE"))
        session.execute(text("TRUNCATE TABLE contract_approvals, contract_versions, data_contracts CASCADE"))
        session.execute(text("TRUNCATE TABLE entity_usage_stats, entity_tags, entity_relationships, entity_attributes, entities, catalog_entries CASCADE"))
        session.execute(text("TRUNCATE TABLE data_quality_issues, quality_metrics, quality_rules CASCADE"))
        session.execute(text("TRUNCATE TABLE impact_analysis, lineage_attributes, data_lineage CASCADE"))
        session.execute(text("TRUNCATE TABLE compliance_reports, policy_violations, governance_policies CASCADE"))
        session.execute(text("TRUNCATE TABLE steward_activities, steward_assignments, data_stewards CASCADE"))
        session.execute(text("TRUNCATE TABLE tag_hierarchy, tags CASCADE"))
        session.execute(text("TRUNCATE TABLE workflow_steps, workflow_instances, workflow_definitions CASCADE"))
        session.execute(text("TRUNCATE TABLE alert_rules, notification_preferences, notifications CASCADE"))
        session.execute(text("TRUNCATE TABLE sync_jobs, integration_mappings, external_integrations CASCADE"))
        session.execute(text("TRUNCATE TABLE monitoring_dashboards, feature_flags, system_configurations CASCADE"))
        session.commit()
        
        # 2. Configurações do Sistema
        print("Criando configurações do sistema...")
        configs = [
            SystemConfiguration(config_key="sync_interval_minutes", config_value="20", description="Intervalo de sincronização em minutos", config_type="integer", is_active=True),
            SystemConfiguration(config_key="max_concurrent_syncs", config_value="5", description="Máximo de sincronizações simultâneas", config_type="integer", is_active=True),
            SystemConfiguration(config_key="quality_check_interval", config_value="30", description="Intervalo de verificação de qualidade em minutos", config_type="integer", is_active=True),
            SystemConfiguration(config_key="enable_ml_recommendations", config_value="true", description="Habilitar recomendações de ML", config_type="boolean", is_active=True),
        ]
        for config in configs:
            session.add(config)
        session.commit()
        
        # 3. Roles de Segurança
        print("Criando roles de segurança...")
        roles = [
            SecurityRole(role_name="admin", description="Administrador do sistema", permissions='["read", "write", "delete", "admin"]'),
            SecurityRole(role_name="data_steward", description="Responsável pela qualidade dos dados", permissions='["read", "write", "quality_manage"]'),
            SecurityRole(role_name="data_analyst", description="Analista de dados", permissions='["read", "discover", "analyze"]'),
            SecurityRole(role_name="compliance_officer", description="Oficial de compliance", permissions='["read", "compliance_manage", "audit"]'),
            SecurityRole(role_name="data_engineer", description="Engenheiro de dados", permissions='["read", "write", "integrate", "pipeline"]'),
        ]
        for role in roles:
            session.add(role)
        session.commit()
        
        # 4. Usuários
        print("Criando usuários...")
        users_data = [
            {"email": "carlos.morais@f1rst.com", "full_name": "Carlos Morais", "department": "Engenharia de Dados", "role": "admin"},
            {"email": "ana.silva@f1rst.com", "full_name": "Ana Silva", "department": "Governança de Dados", "role": "data_steward"},
            {"email": "pedro.santos@f1rst.com", "full_name": "Pedro Santos", "department": "Analytics", "role": "data_analyst"},
            {"email": "maria.costa@f1rst.com", "full_name": "Maria Costa", "department": "Compliance", "role": "compliance_officer"},
            {"email": "joao.oliveira@f1rst.com", "full_name": "João Oliveira", "department": "Engenharia de Dados", "role": "data_engineer"},
        ]
        
        users = []
        for user_data in users_data:
            user = User(
                email=user_data["email"],
                full_name=user_data["full_name"],
                department=user_data["department"],
                organization="F1rst",
                is_active=True,
                password_hash="$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhM8/PI.B4t9dAuThuS.Em"
            )
            session.add(user)
            users.append(user)
        session.commit()
        
        # 5. Associar roles aos usuários
        print("Associando roles aos usuários...")
        for i, user in enumerate(users):
            role = session.query(SecurityRole).filter_by(role_name=users_data[i]["role"]).first()
            user_role = UserRole(user_id=user.id, role_id=role.id)
            session.add(user_role)
        session.commit()
        
        # 6. Contratos de Dados
        print("Criando contratos de dados...")
        contracts_data = [
            {"name": "Contrato Dados Transações Bancárias", "description": "Contrato para dados de transações do sistema bancário", "owner_email": "ana.silva@f1rst.com", "business_domain": "Banking", "data_domain": "Transactions"},
            {"name": "Contrato Dados Clientes PF", "description": "Contrato para dados de clientes pessoa física", "owner_email": "ana.silva@f1rst.com", "business_domain": "Banking", "data_domain": "Customers"},
            {"name": "Contrato Dados Produtos Financeiros", "description": "Contrato para dados de produtos e serviços financeiros", "owner_email": "ana.silva@f1rst.com", "business_domain": "Banking", "data_domain": "Products"},
        ]
        
        contracts = []
        for contract_data in contracts_data:
            owner = session.query(User).filter_by(email=contract_data["owner_email"]).first()
            contract = DataContract(
                name=contract_data["name"],
                description=contract_data["description"],
                owner_id=owner.id,
                business_domain=contract_data["business_domain"],
                data_domain=contract_data["data_domain"],
                status="active"
            )
            session.add(contract)
            contracts.append(contract)
        session.commit()
        
        # 7. Versões dos Contratos
        print("Criando versões dos contratos...")
        for i, contract in enumerate(contracts):
            version = ContractVersion(
                contract_id=contract.id,
                version_number="1.0",
                schema_definition='{"type": "object", "properties": {"id": {"type": "string"}}}',
                sla_requirements='{"availability": "99.9%", "latency": "< 100ms"}',
                quality_requirements='{"completeness": "> 99%", "accuracy": "> 98%"}',
                status="active"
            )
            session.add(version)
        session.commit()
        
        # 8. Entidades
        print("Criando entidades...")
        entities_data = [
            {"name": "Transações Bancárias", "description": "Tabela principal de transações do sistema bancário", "entity_type": "table", "database_name": "banking_prod", "schema_name": "transactions", "table_name": "tb_transactions", "owner_email": "carlos.morais@f1rst.com"},
            {"name": "Clientes Pessoa Física", "description": "Dados de clientes pessoa física", "entity_type": "table", "database_name": "banking_prod", "schema_name": "customers", "table_name": "tb_customers_pf", "owner_email": "ana.silva@f1rst.com"},
            {"name": "Produtos Financeiros", "description": "Catálogo de produtos e serviços financeiros", "entity_type": "table", "database_name": "banking_prod", "schema_name": "products", "table_name": "tb_products", "owner_email": "pedro.santos@f1rst.com"},
            {"name": "Auditoria LGPD", "description": "Log de auditoria para compliance LGPD", "entity_type": "table", "database_name": "compliance_prod", "schema_name": "audit", "table_name": "tb_lgpd_audit", "owner_email": "maria.costa@f1rst.com"},
            {"name": "Métricas de Negócio", "description": "Métricas e KPIs de negócio", "entity_type": "view", "database_name": "analytics_prod", "schema_name": "metrics", "table_name": "vw_business_metrics", "owner_email": "pedro.santos@f1rst.com"},
        ]
        
        entities = []
        for entity_data in entities_data:
            owner = session.query(User).filter_by(email=entity_data["owner_email"]).first()
            entity = Entity(
                name=entity_data["name"],
                description=entity_data["description"],
                entity_type=entity_data["entity_type"],
                database_name=entity_data["database_name"],
                schema_name=entity_data["schema_name"],
                table_name=entity_data["table_name"],
                owner_id=owner.id,
                business_domain="Banking",
                technical_domain="Core Banking",
                sensitivity_level="high",
                data_classification="confidential"
            )
            session.add(entity)
            entities.append(entity)
        session.commit()
        
        # 9. Tags
        print("Criando tags...")
        tags_data = [
            {"name": "PII", "description": "Informação Pessoal Identificável", "color": "#FF6B6B", "tag_type": "classification"},
            {"name": "LGPD", "description": "Dados sujeitos à LGPD", "color": "#4ECDC4", "tag_type": "compliance"},
            {"name": "Financeiro", "description": "Dados financeiros sensíveis", "color": "#45B7D1", "tag_type": "business"},
            {"name": "Crítico", "description": "Dados críticos para negócio", "color": "#FD79A8", "tag_type": "priority"},
        ]
        
        tags = []
        for tag_data in tags_data:
            tag = Tag(
                name=tag_data["name"],
                description=tag_data["description"],
                color=tag_data["color"],
                tag_type=tag_data["tag_type"],
                is_system_tag=True
            )
            session.add(tag)
            tags.append(tag)
        session.commit()
        
        # 10. Regras de Qualidade
        print("Criando regras de qualidade...")
        quality_rules_data = [
            {"name": "Validação CPF", "description": "Validação de formato e algoritmo do CPF", "rule_type": "format", "entity_name": "Clientes Pessoa Física", "attribute_name": "cpf"},
            {"name": "Email Válido", "description": "Validação de formato de email", "rule_type": "format", "entity_name": "Clientes Pessoa Física", "attribute_name": "email"},
            {"name": "Valor Transação Positivo", "description": "Valor da transação deve ser positivo", "rule_type": "range", "entity_name": "Transações Bancárias", "attribute_name": "amount"},
        ]
        
        for rule_data in quality_rules_data:
            entity = session.query(Entity).filter_by(name=rule_data["entity_name"]).first()
            rule = QualityRule(
                name=rule_data["name"],
                description=rule_data["description"],
                rule_type=rule_data["rule_type"],
                entity_id=entity.id,
                attribute_name=rule_data["attribute_name"],
                rule_definition='{"pattern": "^[0-9]+$"}',
                severity="high",
                is_active=True
            )
            session.add(rule)
        session.commit()
        
        # 11. Integrações Externas
        print("Criando integrações externas...")
        integrations_data = [
            {"name": "Unity Catalog Databricks", "integration_type": "unity_catalog", "endpoint_url": "https://workspace.cloud.databricks.com"},
            {"name": "Informatica Axon", "integration_type": "axon", "endpoint_url": "https://axon.informatica.com/api/v1"},
            {"name": "DataHub LinkedIn", "integration_type": "datahub", "endpoint_url": "https://datahub.f1rst.com/api/v1"},
        ]
        
        for integration_data in integrations_data:
            integration = ExternalIntegration(
                name=integration_data["name"],
                integration_type=integration_data["integration_type"],
                endpoint_url=integration_data["endpoint_url"],
                authentication_config='{"auth_type": "bearer_token"}',
                sync_schedule="*/20 * * * *",
                is_active=True,
                health_status="healthy"
            )
            session.add(integration)
        session.commit()
        
        # 12. Políticas de Governança
        print("Criando políticas de governança...")
        policies_data = [
            {"name": "Política LGPD Dados Pessoais", "description": "Política de proteção de dados pessoais conforme LGPD", "policy_type": "privacy", "compliance_framework": "LGPD"},
            {"name": "Política Qualidade Dados Críticos", "description": "Política de qualidade para dados críticos de negócio", "policy_type": "quality", "compliance_framework": "Internal"},
            {"name": "Política Acesso Dados Sensíveis", "description": "Política de controle de acesso a dados sensíveis", "policy_type": "access", "compliance_framework": "SOX"},
        ]
        
        for policy_data in policies_data:
            policy = GovernancePolicy(
                name=policy_data["name"],
                description=policy_data["description"],
                policy_type=policy_data["policy_type"],
                scope="organization",
                compliance_framework=policy_data["compliance_framework"],
                policy_rules='{"data_retention": "5 years", "consent_required": true}',
                severity="high",
                is_active=True
            )
            session.add(policy)
        session.commit()
        
        print("=== Dados de teste criados com sucesso! ===")
        print(f"Usuários: {len(users)}")
        print(f"Contratos: {len(contracts)}")
        print(f"Entidades: {len(entities)}")
        print(f"Tags: {len(tags)}")
        print(f"Configurações: {len(configs)}")
        
        session.close()
        return True
        
    except Exception as e:
        print(f"Erro ao criar dados de teste: {e}")
        if 'session' in locals():
            session.rollback()
            session.close()
        return False

if __name__ == "__main__":
    success = create_test_data()
    if success:
        print("✓ Dados de teste carregados com sucesso!")
    else:
        print("✗ Erro ao carregar dados de teste")
        sys.exit(1)

