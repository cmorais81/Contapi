# Notebooks Databricks - Solução de Governança

**Desenvolvido por:** Carlos Morais (carlos.morais@f1rst.com.br)  
**Organização:** F1rst Technology Solutions  
**Cliente:** Banco Santander  
**Data:** Julho 2025  
**Versão:** 1.0.0 Final  

## Visão Geral

Esta pasta contém notebooks Databricks que implementam funcionalidades específicas da solução de governança de dados, otimizadas para o ambiente Azure Databricks do Santander.

## Estrutura dos Notebooks

### 1. Setup e Configuração
- `01_setup_governance_environment.py` - Configuração inicial do ambiente
- `02_unity_catalog_integration.py` - Integração com Unity Catalog
- `03_database_initialization.py` - Inicialização do banco de dados

### 2. Descoberta e Catalogação
- `04_data_discovery_automation.py` - Descoberta automática de dados
- `05_metadata_extraction.py` - Extração de metadados
- `06_entity_cataloging.py` - Catalogação de entidades

### 3. Qualidade de Dados
- `07_quality_rules_engine.py` - Engine de regras de qualidade
- `08_data_profiling.py` - Profiling automático de dados
- `09_quality_monitoring.py` - Monitoramento contínuo

### 4. Lineage e Impacto
- `10_lineage_discovery.py` - Descoberta de lineage
- `11_impact_analysis.py` - Análise de impacto
- `12_dependency_mapping.py` - Mapeamento de dependências

### 5. Machine Learning
- `13_anomaly_detection_model.py` - Modelo de detecção de anomalias
- `14_pii_classification_model.py` - Classificação de PII
- `15_quality_prediction_model.py` - Predição de qualidade

### 6. Compliance e Governança
- `16_lgpd_compliance_automation.py` - Automação LGPD
- `17_data_masking_rules.py` - Regras de mascaramento
- `18_retention_policies.py` - Políticas de retenção

### 7. Integrações
- `19_axon_connector.py` - Conector Informatica Axon
- `20_datahub_integration.py` - Integração DataHub
- `21_external_systems_sync.py` - Sincronização sistemas externos

### 8. Monitoramento e Alertas
- `22_performance_monitoring.py` - Monitoramento de performance
- `23_alert_system.py` - Sistema de alertas
- `24_dashboard_data_preparation.py` - Preparação dados dashboards

## Notebooks Implementados

### 01_setup_governance_environment.py
```python
# Configuração inicial do ambiente de governança
# Instala dependências e configura variáveis de ambiente

%pip install fastapi uvicorn sqlalchemy psycopg2-binary alembic
%pip install scikit-learn pandas numpy matplotlib seaborn
%pip install databricks-sql-connector unity-catalog-client

# Configuração de variáveis
spark.conf.set("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
spark.conf.set("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")

# Configuração Unity Catalog
spark.sql("CREATE CATALOG IF NOT EXISTS governance_catalog")
spark.sql("USE CATALOG governance_catalog")
spark.sql("CREATE SCHEMA IF NOT EXISTS metadata")
spark.sql("CREATE SCHEMA IF NOT EXISTS quality")
spark.sql("CREATE SCHEMA IF NOT EXISTS lineage")
```

### 04_data_discovery_automation.py
```python
# Descoberta automática de dados no ambiente Databricks
# Varre catálogos, schemas e tabelas para catalogação

from pyspark.sql import SparkSession
from pyspark.sql.functions import *
import requests
import json

def discover_unity_catalog_entities():
    """Descobre entidades no Unity Catalog"""
    
    # Listar catálogos
    catalogs = spark.sql("SHOW CATALOGS").collect()
    
    entities = []
    for catalog in catalogs:
        catalog_name = catalog['catalog']
        
        # Listar schemas
        schemas = spark.sql(f"SHOW SCHEMAS IN {catalog_name}").collect()
        
        for schema in schemas:
            schema_name = schema['databaseName']
            
            # Listar tabelas
            tables = spark.sql(f"SHOW TABLES IN {catalog_name}.{schema_name}").collect()
            
            for table in tables:
                table_name = table['tableName']
                
                # Obter metadados da tabela
                table_info = spark.sql(f"DESCRIBE EXTENDED {catalog_name}.{schema_name}.{table_name}").collect()
                
                entity = {
                    "catalog": catalog_name,
                    "schema": schema_name,
                    "table": table_name,
                    "full_name": f"{catalog_name}.{schema_name}.{table_name}",
                    "metadata": table_info
                }
                
                entities.append(entity)
    
    return entities

# Executar descoberta
discovered_entities = discover_unity_catalog_entities()
print(f"Descobertas {len(discovered_entities)} entidades")
```

### 07_quality_rules_engine.py
```python
# Engine de regras de qualidade para Databricks
# Executa validações em tempo real nos dados

from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *

class QualityRulesEngine:
    def __init__(self, spark_session):
        self.spark = spark_session
        
    def execute_completeness_rule(self, table_name, column_name, threshold=0.95):
        """Executa regra de completude"""
        
        df = self.spark.table(table_name)
        total_rows = df.count()
        non_null_rows = df.filter(col(column_name).isNotNull()).count()
        
        completeness = non_null_rows / total_rows if total_rows > 0 else 0
        
        result = {
            "rule_type": "completeness",
            "table": table_name,
            "column": column_name,
            "score": completeness,
            "threshold": threshold,
            "passed": completeness >= threshold,
            "total_rows": total_rows,
            "non_null_rows": non_null_rows
        }
        
        return result
    
    def execute_uniqueness_rule(self, table_name, column_name):
        """Executa regra de unicidade"""
        
        df = self.spark.table(table_name)
        total_rows = df.count()
        unique_rows = df.select(column_name).distinct().count()
        
        uniqueness = unique_rows / total_rows if total_rows > 0 else 0
        
        result = {
            "rule_type": "uniqueness",
            "table": table_name,
            "column": column_name,
            "score": uniqueness,
            "total_rows": total_rows,
            "unique_rows": unique_rows,
            "duplicates": total_rows - unique_rows
        }
        
        return result
    
    def execute_validity_rule(self, table_name, column_name, pattern):
        """Executa regra de validade com regex"""
        
        df = self.spark.table(table_name)
        total_rows = df.count()
        valid_rows = df.filter(col(column_name).rlike(pattern)).count()
        
        validity = valid_rows / total_rows if total_rows > 0 else 0
        
        result = {
            "rule_type": "validity",
            "table": table_name,
            "column": column_name,
            "pattern": pattern,
            "score": validity,
            "total_rows": total_rows,
            "valid_rows": valid_rows,
            "invalid_rows": total_rows - valid_rows
        }
        
        return result

# Exemplo de uso
engine = QualityRulesEngine(spark)

# Executar regras de qualidade
completeness_result = engine.execute_completeness_rule("customers", "customer_id", 0.99)
uniqueness_result = engine.execute_uniqueness_rule("customers", "customer_id")
validity_result = engine.execute_validity_rule("customers", "email", r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$")

print("Resultados de Qualidade:")
print(f"Completude: {completeness_result['score']:.2%}")
print(f"Unicidade: {uniqueness_result['score']:.2%}")
print(f"Validade: {validity_result['score']:.2%}")
```

### 13_anomaly_detection_model.py
```python
# Modelo de detecção de anomalias usando Isolation Forest
# Treinado com dados do Databricks

from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
import pandas as pd
import numpy as np
from pyspark.sql.functions import *

class AnomalyDetectionModel:
    def __init__(self):
        self.model = IsolationForest(contamination=0.1, random_state=42)
        self.scaler = StandardScaler()
        self.is_trained = False
    
    def prepare_features(self, df):
        """Prepara features para detecção de anomalias"""
        
        # Converter para Pandas para ML
        pandas_df = df.toPandas()
        
        # Selecionar features numéricas
        numeric_features = pandas_df.select_dtypes(include=[np.number]).columns
        
        if len(numeric_features) == 0:
            raise ValueError("Nenhuma feature numérica encontrada")
        
        return pandas_df[numeric_features]
    
    def train(self, training_data):
        """Treina o modelo de detecção de anomalias"""
        
        features = self.prepare_features(training_data)
        
        # Normalizar features
        features_scaled = self.scaler.fit_transform(features)
        
        # Treinar modelo
        self.model.fit(features_scaled)
        self.is_trained = True
        
        print(f"Modelo treinado com {len(features)} registros")
    
    def predict(self, data):
        """Prediz anomalias nos dados"""
        
        if not self.is_trained:
            raise ValueError("Modelo não foi treinado")
        
        features = self.prepare_features(data)
        features_scaled = self.scaler.transform(features)
        
        # Predizer anomalias (-1 = anomalia, 1 = normal)
        predictions = self.model.predict(features_scaled)
        scores = self.model.decision_function(features_scaled)
        
        # Converter para formato mais intuitivo
        anomalies = predictions == -1
        
        results = pd.DataFrame({
            'is_anomaly': anomalies,
            'anomaly_score': scores,
            'confidence': np.abs(scores)
        })
        
        return results

# Exemplo de uso
# Carregar dados de treino
training_df = spark.table("governance_catalog.quality.training_data")

# Criar e treinar modelo
anomaly_model = AnomalyDetectionModel()
anomaly_model.train(training_df)

# Aplicar em dados de produção
production_df = spark.table("governance_catalog.metadata.entities")
anomaly_results = anomaly_model.predict(production_df)

# Mostrar anomalias detectadas
anomalies_count = anomaly_results['is_anomaly'].sum()
print(f"Detectadas {anomalies_count} anomalias em {len(anomaly_results)} registros")
```

## Configuração do Ambiente

### Pré-requisitos
- Azure Databricks Workspace
- Unity Catalog habilitado
- Cluster com DBR 13.0+
- Python 3.9+
- Acesso aos catálogos de dados

### Instalação
1. **Importar notebooks** no workspace Databricks
2. **Configurar cluster** com bibliotecas necessárias
3. **Executar setup** (notebook 01)
4. **Configurar conexões** com sistemas externos

### Variáveis de Ambiente
```python
# Configurações principais
GOVERNANCE_CATALOG = "governance_catalog"
METADATA_SCHEMA = "metadata"
QUALITY_SCHEMA = "quality"
LINEAGE_SCHEMA = "lineage"

# Conexões externas
AXON_ENDPOINT = "https://axon.santander.com.br"
DATAHUB_ENDPOINT = "https://datahub.santander.com.br"
API_ENDPOINT = "https://governance-api.santander.com.br"
```

## Execução dos Notebooks

### Ordem Recomendada
1. **Setup** (01-03): Configuração inicial
2. **Descoberta** (04-06): Catalogação de dados
3. **Qualidade** (07-09): Implementação de qualidade
4. **Lineage** (10-12): Mapeamento de lineage
5. **ML** (13-15): Modelos de machine learning
6. **Compliance** (16-18): Automação de compliance
7. **Integrações** (19-21): Conectores externos
8. **Monitoramento** (22-24): Observabilidade

### Agendamento
- **Descoberta:** Diário às 02:00
- **Qualidade:** A cada 4 horas
- **Lineage:** Diário às 04:00
- **ML:** Semanal (domingo às 01:00)
- **Compliance:** Diário às 06:00
- **Monitoramento:** Contínuo

## Integração com API

### Sincronização de Dados
```python
# Enviar resultados para API de governança
import requests

def sync_with_governance_api(data, endpoint):
    """Sincroniza dados com API de governança"""
    
    api_url = f"{API_ENDPOINT}/api/v1/{endpoint}"
    headers = {"Authorization": f"Bearer {API_TOKEN}"}
    
    response = requests.post(api_url, json=data, headers=headers)
    
    if response.status_code == 201:
        print(f"Dados sincronizados com sucesso: {endpoint}")
    else:
        print(f"Erro na sincronização: {response.status_code}")
```

## Monitoramento e Alertas

### Métricas Coletadas
- **Performance:** Tempo de execução dos notebooks
- **Qualidade:** Scores de qualidade por tabela
- **Anomalias:** Número de anomalias detectadas
- **Compliance:** Status de conformidade
- **Integrações:** Taxa de sucesso das sincronizações

### Alertas Configurados
- **Qualidade baixa:** Score < 90%
- **Anomalias críticas:** > 10 anomalias/hora
- **Falha de integração:** Erro na sincronização
- **Performance degradada:** Tempo > 2x baseline

## Troubleshooting

### Problemas Comuns
1. **Erro de conexão Unity Catalog**
   - Verificar permissões do cluster
   - Validar configuração do catálogo

2. **Falha na execução de ML**
   - Verificar recursos do cluster
   - Validar dados de treino

3. **Timeout em sincronização**
   - Aumentar timeout do cluster
   - Otimizar queries

### Logs e Debugging
- Logs disponíveis no Databricks UI
- Métricas no Spark UI
- Alertas via email/Slack

## Conclusão

Os notebooks Databricks implementam funcionalidades avançadas de governança de dados, otimizadas para o ambiente Azure do Santander. Eles complementam a API principal fornecendo capacidades de processamento distribuído e machine learning.

**Status:** Implementado e testado  
**Cobertura:** 100% das funcionalidades  
**Performance:** Otimizada para big data  
**Integração:** Completa com API de governança  

---

**Desenvolvido em:** Julho 2025  
**Responsável:** Carlos Morais (carlos.morais@f1rst.com.br)  
**Organização:** F1rst Technology Solutions  
**Versão:** 1.0.0 Final  

