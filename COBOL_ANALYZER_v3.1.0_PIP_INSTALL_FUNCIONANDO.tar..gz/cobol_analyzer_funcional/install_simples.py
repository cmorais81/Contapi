#!/usr/bin/env python3
"""
Instalador Simples e Robusto para COBOL Analyzer
Garante que funcione em qualquer máquina
"""

import os
import sys
import subprocess
import shutil
from pathlib import Path

def print_step(message):
    print(f"\n🔧 {message}")

def run_command(cmd, description):
    """Executa comando e retorna resultado"""
    print(f"💻 {description}")
    try:
        result = subprocess.run(cmd, check=True, capture_output=True, text=True)
        print(f"✅ Sucesso")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Erro: {e}")
        return False

def create_simple_entry_point():
    """Cria entry point simples e funcional"""
    
    script_content = '''#!/usr/bin/env python3
import sys
import os
import subprocess
from pathlib import Path

def main():
    # Se é comando --init, usar main_enhanced.py
    if '--init' in sys.argv:
        # Locais possíveis para main_enhanced.py
        locations = [
            "/usr/local/lib/python3.11/dist-packages/main_enhanced.py",
            "/usr/local/bin/main_enhanced.py",
            "/home/ubuntu/cobol_analyzer_EXCELENCIA/main_enhanced.py",
            "./main_enhanced.py"
        ]
        
        for location in locations:
            if os.path.exists(location):
                # Substituir --init por --init-local
                args = [arg if arg != '--init' else '--init-local' for arg in sys.argv[1:]]
                cmd = [sys.executable, location] + args
                result = subprocess.run(cmd)
                sys.exit(result.returncode)
        
        print("❌ Erro: main_enhanced.py não encontrado")
        print("💡 Tente: python main_enhanced.py --init-local")
        sys.exit(1)
    
    # Para outros comandos, usar main.py
    try:
        sys.path.insert(0, "/usr/local/lib/python3.11/dist-packages")
        from main import main as main_func
        main_func()
    except ImportError:
        locations = [
            "/usr/local/lib/python3.11/dist-packages/main.py",
            "/usr/local/bin/main.py",
            "/home/ubuntu/cobol_analyzer_EXCELENCIA/main.py",
            "./main.py"
        ]
        
        for location in locations:
            if os.path.exists(location):
                cmd = [sys.executable, location] + sys.argv[1:]
                result = subprocess.run(cmd)
                sys.exit(result.returncode)
        
        print("❌ Erro: main.py não encontrado")
        sys.exit(1)

if __name__ == "__main__":
    main()
'''
    
    return script_content

def install_entry_point():
    """Instala entry point"""
    
    # Tentar diferentes locais para bin
    bin_locations = ["/usr/local/bin", "/usr/bin"]
    
    for bin_dir in bin_locations:
        if os.path.exists(bin_dir) and os.access(bin_dir, os.W_OK):
            script_path = os.path.join(bin_dir, "cobol-to-docs")
            
            try:
                with open(script_path, 'w') as f:
                    f.write(create_simple_entry_point())
                
                os.chmod(script_path, 0o755)
                print(f"✅ Entry point criado: {script_path}")
                return True
                
            except Exception as e:
                print(f"❌ Erro ao criar entry point: {e}")
                continue
    
    print("❌ Não foi possível criar entry point")
    return False

def test_installation():
    """Testa instalação"""
    
    print("\n🧪 TESTANDO INSTALAÇÃO")
    
    # Teste 1: Comando disponível
    if not shutil.which('cobol-to-docs'):
        print("❌ Comando cobol-to-docs não encontrado")
        return False
    print("✅ Comando encontrado")
    
    # Teste 2: Help
    try:
        result = subprocess.run(['cobol-to-docs', '--help'], 
                              capture_output=True, timeout=10)
        if result.returncode == 0:
            print("✅ --help funcionando")
        else:
            print("❌ --help falhou")
            return False
    except:
        print("❌ --help falhou")
        return False
    
    # Teste 3: Init
    test_dir = Path("/tmp/test_cobol_simple")
    test_dir.mkdir(exist_ok=True)
    
    original_cwd = os.getcwd()
    try:
        os.chdir(str(test_dir))
        
        result = subprocess.run(['cobol-to-docs', '--init'], 
                              capture_output=True, timeout=30)
        
        if result.returncode == 0:
            print("✅ --init funcionando")
            
            # Verificar diretórios
            expected = ['config', 'data', 'logs', 'examples']
            created = all((test_dir / d).exists() for d in expected)
            
            if created:
                print("✅ Diretórios criados")
                return True
            else:
                print("❌ Diretórios não criados")
                return False
        else:
            print(f"❌ --init falhou: {result.stderr.decode()}")
            return False
            
    finally:
        os.chdir(original_cwd)
        shutil.rmtree(str(test_dir), ignore_errors=True)

def main():
    """Instalação principal"""
    
    print("🚀 COBOL ANALYZER - INSTALAÇÃO SIMPLES")
    print("=" * 50)
    
    # Passo 1: Desinstalar anterior
    print_step("Removendo instalação anterior")
    run_command([sys.executable, '-m', 'pip', 'uninstall', 'cobol-to-docs', '-y'], 
                "Desinstalar")
    
    # Passo 2: Instalar
    print_step("Instalando COBOL Analyzer")
    if not run_command([sys.executable, 'setup_corrigido.py', 'install'], 
                      "Instalar"):
        print("❌ Falha na instalação")
        sys.exit(1)
    
    # Passo 3: Entry point
    print_step("Configurando comando")
    if not install_entry_point():
        print("⚠️  Entry point não criado - use execução direta")
    
    # Passo 4: Testar
    print_step("Testando")
    if test_installation():
        print("\n🎉 INSTALAÇÃO CONCLUÍDA!")
        print("💡 Use: cobol-to-docs --init")
    else:
        print("\n⚠️  INSTALAÇÃO PARCIAL")
        print("💡 Use: python main_enhanced.py --init-local")

if __name__ == "__main__":
    main()
