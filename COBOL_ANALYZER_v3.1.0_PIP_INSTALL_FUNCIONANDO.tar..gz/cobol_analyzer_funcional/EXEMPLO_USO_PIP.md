# Exemplo de Uso - COBOL Analyzer via pip

## Instalação

### 1. Instalar o pacote via pip

```bash
# Instalar diretamente do diretório
pip install .

# Ou instalar em modo desenvolvimento
pip install -e .
```

### 2. Corrigir instalação (IMPORTANTE)

```bash
# Executar script de correção para suporte ao --init
python fix_install.py
```

### 3. Verificar instalação

```bash
# Verificar se o comando está disponível
cobol-to-docs --help

# Testar comando --init
cobol-to-docs --init

# Verificar status dos provedores
cobol-to-docs --status
```

## Uso Básico

### 1. Inicialização do Ambiente (NOVO v3.1.0)

```bash
# Inicializar ambiente local automaticamente
cobol-to-docs --init

# Inicializar com diretórios personalizados
cobol-to-docs --init --config-dir ./minha_config --data-dir ./meus_dados

# Forçar reinicialização
cobol-to-docs --init --force-init
```

### 2. Verificar Configuração

```bash
# Mostrar caminhos configurados
cobol-to-docs --show-paths

# Verificar status dos provedores de IA
cobol-to-docs --status
```

### 3. Análise de Programas COBOL

```bash
# Análise básica
cobol-to-docs --fontes fontes.txt

# Análise com copybooks
cobol-to-docs --fontes fontes.txt --books books.txt

# Análise consolidada
cobol-to-docs --fontes fontes.txt --consolidado

# Análise avançada com relatório HTML
cobol-to-docs --fontes fontes.txt --advanced-analysis
```

## Exemplos Práticos

### Exemplo 1: Configuração Inicial de Projeto

```bash
# Criar diretório do projeto
mkdir meu_projeto_cobol
cd meu_projeto_cobol

# Inicializar ambiente do COBOL Analyzer
cobol-to-docs --init

# Verificar estrutura criada
ls -la
# Resultado esperado:
# config/     - Arquivos de configuração
# data/       - Base de conhecimento RAG
# logs/       - Arquivos de log
# examples/   - Exemplos de programas COBOL
```

### Exemplo 2: Análise com Diretórios Personalizados

```bash
# Criar estrutura personalizada
mkdir -p projeto_corporativo/{config_corp,dados_rag,logs_sistema}
cd projeto_corporativo

# Inicializar com diretórios personalizados
cobol-to-docs --init \
  --config-dir ./config_corp \
  --data-dir ./dados_rag \
  --logs-dir ./logs_sistema

# Executar análise usando a configuração personalizada
cobol-to-docs --fontes ../fontes_sistema.txt \
  --config-dir ./config_corp \
  --data-dir ./dados_rag \
  --logs-dir ./logs_sistema \
  --consolidado
```

### Exemplo 3: Análise Completa de Sistema

```bash
# Preparar arquivos de entrada
echo "PROGRAMA1.CBL" > fontes.txt
echo "PROGRAMA2.CBL" >> fontes.txt
echo "COPYBOOK1.CPY" > books.txt

# Executar análise completa
cobol-to-docs --fontes fontes.txt \
  --books books.txt \
  --consolidado \
  --advanced-analysis \
  --procedure-detalhada \
  --modernizacao \
  --pdf \
  --models enhanced_mock
```

### Exemplo 4: Uso em Ambiente Corporativo

```bash
# Configuração para ambiente corporativo
cobol-to-docs --init \
  --config-dir /etc/cobol_analyzer \
  --data-dir /var/lib/cobol_analyzer \
  --logs-dir /var/log/cobol_analyzer

# Análise de sistema corporativo
cobol-to-docs --fontes /dados/sistemas/fontes.txt \
  --books /dados/sistemas/copybooks.txt \
  --config-dir /etc/cobol_analyzer \
  --data-dir /var/lib/cobol_analyzer \
  --logs-dir /var/log/cobol_analyzer \
  --output /relatorios/analise_sistema \
  --consolidado \
  --models "luzia-gpt-4"
```

## Comandos de Conveniência

### Comandos Rápidos (NOVO v3.1.0)

```bash
# Inicialização rápida
cobol-to-docs --init

# Mostrar configuração atual
cobol-to-docs --show-paths

# Verificar status dos provedores
cobol-to-docs --status

# Ajuda completa
cobol-to-docs --help-full
```

### Análises Especializadas

```bash
# Análise profissional para documentação empresarial
cobol-to-docs --fontes fontes.txt --prompt-set professional

# Análise especializada para modernização
cobol-to-docs --fontes fontes.txt --prompt-set expert

# Análise ultra detalhada linha por linha
cobol-to-docs --fontes fontes.txt --prompt-set ultra_detailed
```

## Estrutura de Arquivos Criada

### Após `cobol-to-docs --init`

```
./
├── config/
│   ├── config.yaml              # Configuração principal
│   └── prompts_enhanced.yaml    # Prompts especializados
├── data/
│   ├── cobol_knowledge_base.json    # Base de conhecimento RAG
│   ├── embeddings/                  # Cache de embeddings
│   └── rag_sessions/               # Relatórios de sessões
├── logs/
│   └── cobol_to_docs_YYYYMMDD_HHMMSS.log
└── examples/
    ├── fontes.txt              # Exemplo de lista de programas
    ├── books.txt               # Exemplo de lista de copybooks
    └── PROGRAMA_EXEMPLO.CBL    # Programa COBOL de exemplo
```

## Integração com Scripts

### Script de Automação

```bash
#!/bin/bash
# analyze_project.sh

PROJECT_NAME=$1
if [ -z "$PROJECT_NAME" ]; then
    echo "Uso: $0 <nome_do_projeto>"
    exit 1
fi

# Criar diretório do projeto
mkdir -p "$PROJECT_NAME"
cd "$PROJECT_NAME"

# Inicializar ambiente
echo "Inicializando ambiente para $PROJECT_NAME..."
cobol-to-docs --init

# Executar análise se arquivos existirem
if [ -f "fontes.txt" ]; then
    echo "Executando análise..."
    cobol-to-docs --fontes fontes.txt --consolidado --advanced-analysis
    echo "Análise concluída! Verifique o diretório output_*"
else
    echo "Ambiente inicializado. Adicione seus programas COBOL em fontes.txt"
fi
```

### Uso do Script

```bash
# Tornar executável
chmod +x analyze_project.sh

# Usar o script
./analyze_project.sh meu_sistema_cobol
```

## Integração com CI/CD

### GitHub Actions

```yaml
name: COBOL Analysis
on: [push, pull_request]

jobs:
  analyze:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v2
    
    - name: Setup Python
      uses: actions/setup-python@v2
      with:
        python-version: '3.11'
    
    - name: Install COBOL Analyzer
      run: |
        pip install cobol-to-docs
    
    - name: Initialize Environment
      run: |
        cobol-to-docs --init
    
    - name: Run Analysis
      run: |
        cobol-to-docs --fontes cobol_sources.txt --consolidado
    
    - name: Upload Results
      uses: actions/upload-artifact@v2
      with:
        name: cobol-analysis
        path: output_*
```

## Solução de Problemas

### Problemas Comuns

**Erro: "unrecognized arguments: --init"**
```bash
# Solução: Reinstalar o pacote
pip uninstall cobol-to-docs -y
pip install .
```

**Erro: "Não foi possível encontrar main.py"**
```bash
# Solução: Verificar instalação
pip show cobol-to-docs
pip install --force-reinstall .
```

**Erro: "Diretório não encontrado"**
```bash
# Solução: Inicializar ambiente
cobol-to-docs --init
```

### Verificação de Instalação

```bash
# Verificar se o comando está disponível
which cobol-to-docs

# Verificar versão
cobol-to-docs --help | head -1

# Testar funcionalidade básica
cobol-to-docs --status
```

## Migração de Versões Anteriores

### Se você já usa uma versão anterior

```bash
# Backup dos dados existentes
cp -r config config_backup
cp -r data data_backup

# Atualizar para v3.1.0
pip install --upgrade .

# Migrar configuração (automático na primeira execução)
cobol-to-docs --fontes fontes.txt
```

## Suporte

Para mais informações:
- **Documentação completa**: `README_ENHANCED.md`
- **Guia de diretórios**: `GUIA_DIRETORIOS_PERSONALIZADOS.md`
- **Logs de diagnóstico**: Verificar `logs/cobol_to_docs_*.log`

---

**Versão**: 3.1.0  
**Data**: Outubro 2025  
**Funcionalidades**: Inicialização automática e diretórios personalizáveis
