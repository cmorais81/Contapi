"""
Data Governance Business Logic Services
Following SOLID principles and detailed project structure

Author: Carlos Morais
"""

from abc import ABC, abstractmethod
from typing import List, Optional, Dict, Any, Union
from datetime import datetime, timedelta
import logging
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, func, desc, asc
import json

from ..models.data_models import (
    DataObject, DataContract, DataLineage, QualityMetric, 
    User, AccessPolicy, AuditLog, SecurityClassificationEnum,
    SensitivityLevelEnum, DataObjectStatusEnum, QualityStatusEnum
)


logger = logging.getLogger(__name__)


class IDataObjectService(ABC):
    """
    Interface for Data Object Service.
    
    Following SOLID principles:
    - ISP: Interface segregation - specific interface for data objects
    - DIP: Dependency inversion - depend on abstraction
    """
    
    @abstractmethod
    async def create_data_object(self, data_object_data: Dict[str, Any]) -> DataObject:
        """Create a new data object."""
        pass
    
    @abstractmethod
    async def get_data_object(self, object_id: int) -> Optional[DataObject]:
        """Get data object by ID."""
        pass
    
    @abstractmethod
    async def update_data_object(self, object_id: int, update_data: Dict[str, Any]) -> Optional[DataObject]:
        """Update data object."""
        pass
    
    @abstractmethod
    async def delete_data_object(self, object_id: int) -> bool:
        """Delete data object."""
        pass
    
    @abstractmethod
    async def search_data_objects(self, search_criteria: Dict[str, Any]) -> List[DataObject]:
        """Search data objects."""
        pass


class DataObjectService(IDataObjectService):
    """
    Data Object Service implementation.
    
    Following SOLID principles:
    - SRP: Single responsibility for data object business logic
    - OCP: Open for extension, closed for modification
    - LSP: Liskov substitution principle compliance
    - DIP: Depends on database abstraction
    """
    
    def __init__(self, db_session: Session, audit_service: 'IAuditService'):
        """
        Initialize service with dependencies.
        
        Args:
            db_session: Database session
            audit_service: Audit service for logging
        """
        self.db = db_session
        self.audit_service = audit_service
        self.logger = logging.getLogger(__name__)
    
    async def create_data_object(self, data_object_data: Dict[str, Any]) -> DataObject:
        """
        Create a new data object.
        
        Following SOLID principles:
        - SRP: Single responsibility for creation
        - OCP: Extensible validation and processing
        
        Args:
            data_object_data: Data object information
            
        Returns:
            DataObject: Created data object
            
        Raises:
            ValidationError: If data is invalid
            BusinessRuleViolationError: If business rules are violated
        """
        try:
            # Validate required fields
            self._validate_data_object_data(data_object_data)
            
            # Check for duplicates
            existing = await self._check_duplicate_data_object(data_object_data)
            if existing:
                raise BusinessRuleViolationError(
                    f"Data object with name '{data_object_data['name']}' already exists"
                )
            
            # Create data object
            data_object = DataObject(**data_object_data)
            
            # Set defaults
            data_object.security_classification = data_object.security_classification or SecurityClassificationEnum.INTERNAL
            data_object.sensitivity_level = data_object.sensitivity_level or SensitivityLevelEnum.LOW
            data_object.status = DataObjectStatusEnum.ACTIVE
            data_object.quality_status = QualityStatusEnum.UNKNOWN
            
            # Save to database
            self.db.add(data_object)
            self.db.commit()
            self.db.refresh(data_object)
            
            # Audit log
            await self.audit_service.log_event(
                event_type="data_object",
                event_action="create",
                resource_type="data_object",
                resource_id=str(data_object.id),
                resource_name=data_object.name,
                event_details=data_object_data,
                success=True
            )
            
            self.logger.info(f"Created data object: {data_object.name} (ID: {data_object.id})")
            return data_object
            
        except Exception as e:
            self.db.rollback()
            self.logger.error(f"Failed to create data object: {str(e)}")
            
            # Audit log for failure
            await self.audit_service.log_event(
                event_type="data_object",
                event_action="create",
                event_details=data_object_data,
                success=False,
                error_message=str(e)
            )
            
            raise
    
    async def get_data_object(self, object_id: int) -> Optional[DataObject]:
        """
        Get data object by ID.
        
        Args:
            object_id: Data object ID
            
        Returns:
            DataObject: Data object if found, None otherwise
        """
        try:
            data_object = self.db.query(DataObject).filter(DataObject.id == object_id).first()
            
            if data_object:
                # Update access count and last accessed
                data_object.access_count += 1
                data_object.last_accessed = datetime.utcnow()
                self.db.commit()
                
                # Audit log
                await self.audit_service.log_event(
                    event_type="data_object",
                    event_action="read",
                    resource_type="data_object",
                    resource_id=str(object_id),
                    resource_name=data_object.name,
                    success=True
                )
            
            return data_object
            
        except Exception as e:
            self.logger.error(f"Failed to get data object {object_id}: {str(e)}")
            raise
    
    async def update_data_object(self, object_id: int, update_data: Dict[str, Any]) -> Optional[DataObject]:
        """
        Update data object.
        
        Args:
            object_id: Data object ID
            update_data: Update data
            
        Returns:
            DataObject: Updated data object if found, None otherwise
        """
        try:
            data_object = self.db.query(DataObject).filter(DataObject.id == object_id).first()
            
            if not data_object:
                return None
            
            # Store before state for audit
            before_state = {
                "name": data_object.name,
                "description": data_object.description,
                "security_classification": data_object.security_classification.value if data_object.security_classification else None,
                "sensitivity_level": data_object.sensitivity_level.value if data_object.sensitivity_level else None,
                "status": data_object.status.value if data_object.status else None
            }
            
            # Validate update data
            self._validate_update_data(update_data)
            
            # Update fields
            for field, value in update_data.items():
                if hasattr(data_object, field):
                    setattr(data_object, field, value)
            
            # Update timestamp
            data_object.data_atualizacao = datetime.utcnow()
            
            self.db.commit()
            self.db.refresh(data_object)
            
            # Store after state for audit
            after_state = {
                "name": data_object.name,
                "description": data_object.description,
                "security_classification": data_object.security_classification.value if data_object.security_classification else None,
                "sensitivity_level": data_object.sensitivity_level.value if data_object.sensitivity_level else None,
                "status": data_object.status.value if data_object.status else None
            }
            
            # Audit log
            await self.audit_service.log_event(
                event_type="data_object",
                event_action="update",
                resource_type="data_object",
                resource_id=str(object_id),
                resource_name=data_object.name,
                event_details=update_data,
                before_state=before_state,
                after_state=after_state,
                success=True
            )
            
            self.logger.info(f"Updated data object: {data_object.name} (ID: {object_id})")
            return data_object
            
        except Exception as e:
            self.db.rollback()
            self.logger.error(f"Failed to update data object {object_id}: {str(e)}")
            
            # Audit log for failure
            await self.audit_service.log_event(
                event_type="data_object",
                event_action="update",
                resource_type="data_object",
                resource_id=str(object_id),
                event_details=update_data,
                success=False,
                error_message=str(e)
            )
            
            raise
    
    async def delete_data_object(self, object_id: int) -> bool:
        """
        Delete data object.
        
        Args:
            object_id: Data object ID
            
        Returns:
            bool: True if deleted, False if not found
        """
        try:
            data_object = self.db.query(DataObject).filter(DataObject.id == object_id).first()
            
            if not data_object:
                return False
            
            # Check for dependencies
            has_contracts = self.db.query(DataContract).filter(DataContract.data_object_id == object_id).first()
            has_lineage = self.db.query(DataLineage).filter(
                or_(
                    DataLineage.upstream_object_id == object_id,
                    DataLineage.downstream_object_id == object_id
                )
            ).first()
            
            if has_contracts or has_lineage:
                # Soft delete - mark as archived
                data_object.status = DataObjectStatusEnum.ARCHIVED
                data_object.data_atualizacao = datetime.utcnow()
                self.db.commit()
                
                action = "archive"
            else:
                # Hard delete
                object_name = data_object.name
                self.db.delete(data_object)
                self.db.commit()
                
                action = "delete"
            
            # Audit log
            await self.audit_service.log_event(
                event_type="data_object",
                event_action=action,
                resource_type="data_object",
                resource_id=str(object_id),
                resource_name=data_object.name if action == "archive" else object_name,
                success=True
            )
            
            self.logger.info(f"{'Archived' if action == 'archive' else 'Deleted'} data object: {object_id}")
            return True
            
        except Exception as e:
            self.db.rollback()
            self.logger.error(f"Failed to delete data object {object_id}: {str(e)}")
            
            # Audit log for failure
            await self.audit_service.log_event(
                event_type="data_object",
                event_action="delete",
                resource_type="data_object",
                resource_id=str(object_id),
                success=False,
                error_message=str(e)
            )
            
            raise
    
    async def search_data_objects(self, search_criteria: Dict[str, Any]) -> List[DataObject]:
        """
        Search data objects based on criteria.
        
        Args:
            search_criteria: Search criteria
            
        Returns:
            List[DataObject]: List of matching data objects
        """
        try:
            query = self.db.query(DataObject)
            
            # Apply filters
            if "name" in search_criteria:
                query = query.filter(DataObject.name.ilike(f"%{search_criteria['name']}%"))
            
            if "object_type" in search_criteria:
                query = query.filter(DataObject.object_type == search_criteria["object_type"])
            
            if "database_name" in search_criteria:
                query = query.filter(DataObject.database_name == search_criteria["database_name"])
            
            if "schema_name" in search_criteria:
                query = query.filter(DataObject.schema_name == search_criteria["schema_name"])
            
            if "security_classification" in search_criteria:
                query = query.filter(DataObject.security_classification == search_criteria["security_classification"])
            
            if "sensitivity_level" in search_criteria:
                query = query.filter(DataObject.sensitivity_level == search_criteria["sensitivity_level"])
            
            if "status" in search_criteria:
                query = query.filter(DataObject.status == search_criteria["status"])
            
            if "owner_id" in search_criteria:
                query = query.filter(DataObject.owner_id == search_criteria["owner_id"])
            
            if "steward_id" in search_criteria:
                query = query.filter(DataObject.steward_id == search_criteria["steward_id"])
            
            # Quality filters
            if "min_quality_score" in search_criteria:
                query = query.filter(DataObject.quality_score >= search_criteria["min_quality_score"])
            
            if "quality_status" in search_criteria:
                query = query.filter(DataObject.quality_status == search_criteria["quality_status"])
            
            # Sorting
            sort_by = search_criteria.get("sort_by", "name")
            sort_order = search_criteria.get("sort_order", "asc")
            
            if hasattr(DataObject, sort_by):
                if sort_order.lower() == "desc":
                    query = query.order_by(desc(getattr(DataObject, sort_by)))
                else:
                    query = query.order_by(asc(getattr(DataObject, sort_by)))
            
            # Pagination
            limit = search_criteria.get("limit", 100)
            offset = search_criteria.get("offset", 0)
            
            query = query.offset(offset).limit(limit)
            
            results = query.all()
            
            # Audit log
            await self.audit_service.log_event(
                event_type="data_object",
                event_action="search",
                event_details=search_criteria,
                success=True
            )
            
            return results
            
        except Exception as e:
            self.logger.error(f"Failed to search data objects: {str(e)}")
            
            # Audit log for failure
            await self.audit_service.log_event(
                event_type="data_object",
                event_action="search",
                event_details=search_criteria,
                success=False,
                error_message=str(e)
            )
            
            raise
    
    def _validate_data_object_data(self, data: Dict[str, Any]) -> None:
        """
        Validate data object data.
        
        Args:
            data: Data to validate
            
        Raises:
            ValidationError: If data is invalid
        """
        required_fields = ["name", "object_type"]
        
        for field in required_fields:
            if field not in data or not data[field]:
                raise ValidationError(f"Field '{field}' is required")
        
        # Validate name length
        if len(data["name"]) > 255:
            raise ValidationError("Name must be 255 characters or less")
        
        # Validate object type
        valid_types = ["table", "view", "file", "api", "stream", "dataset"]
        if data["object_type"] not in valid_types:
            raise ValidationError(f"Object type must be one of: {valid_types}")
    
    def _validate_update_data(self, data: Dict[str, Any]) -> None:
        """
        Validate update data.
        
        Args:
            data: Data to validate
            
        Raises:
            ValidationError: If data is invalid
        """
        # Validate name if provided
        if "name" in data and len(data["name"]) > 255:
            raise ValidationError("Name must be 255 characters or less")
        
        # Validate object type if provided
        if "object_type" in data:
            valid_types = ["table", "view", "file", "api", "stream", "dataset"]
            if data["object_type"] not in valid_types:
                raise ValidationError(f"Object type must be one of: {valid_types}")
    
    async def _check_duplicate_data_object(self, data: Dict[str, Any]) -> Optional[DataObject]:
        """
        Check for duplicate data object.
        
        Args:
            data: Data object data
            
        Returns:
            DataObject: Existing data object if found, None otherwise
        """
        query = self.db.query(DataObject).filter(DataObject.name == data["name"])
        
        # Check for same path if provided
        if all(key in data for key in ["database_name", "schema_name", "table_name"]):
            query = query.filter(
                and_(
                    DataObject.database_name == data["database_name"],
                    DataObject.schema_name == data["schema_name"],
                    DataObject.table_name == data["table_name"]
                )
            )
        
        return query.first()


class IAuditService(ABC):
    """
    Interface for Audit Service.
    
    Following SOLID principles:
    - ISP: Interface segregation for audit functionality
    - DIP: Dependency inversion principle
    """
    
    @abstractmethod
    async def log_event(self, **kwargs) -> None:
        """Log an audit event."""
        pass


class AuditService(IAuditService):
    """
    Audit Service implementation.
    
    Following SOLID principles:
    - SRP: Single responsibility for audit logging
    - OCP: Open for extension with new event types
    """
    
    def __init__(self, db_session: Session):
        """
        Initialize audit service.
        
        Args:
            db_session: Database session
        """
        self.db = db_session
        self.logger = logging.getLogger(__name__)
    
    async def log_event(
        self,
        event_type: str,
        event_action: str,
        event_source: str = "api",
        user_id: Optional[int] = None,
        session_id: Optional[str] = None,
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
        resource_type: Optional[str] = None,
        resource_id: Optional[str] = None,
        resource_name: Optional[str] = None,
        event_details: Optional[Dict[str, Any]] = None,
        before_state: Optional[Dict[str, Any]] = None,
        after_state: Optional[Dict[str, Any]] = None,
        success: bool = True,
        error_message: Optional[str] = None,
        business_context: Optional[str] = None,
        compliance_tags: Optional[List[str]] = None
    ) -> None:
        """
        Log an audit event.
        
        Args:
            event_type: Type of event
            event_action: Action performed
            event_source: Source of event
            user_id: User ID
            session_id: Session ID
            ip_address: IP address
            user_agent: User agent
            resource_type: Type of resource
            resource_id: Resource ID
            resource_name: Resource name
            event_details: Event details
            before_state: State before change
            after_state: State after change
            success: Whether event was successful
            error_message: Error message if failed
            business_context: Business context
            compliance_tags: Compliance tags
        """
        try:
            audit_log = AuditLog(
                event_type=event_type,
                event_action=event_action,
                event_source=event_source,
                user_id=user_id,
                session_id=session_id,
                ip_address=ip_address,
                user_agent=user_agent,
                resource_type=resource_type,
                resource_id=resource_id,
                resource_name=resource_name,
                event_details=event_details,
                before_state=before_state,
                after_state=after_state,
                success=success,
                error_message=error_message,
                business_context=business_context,
                compliance_tags=compliance_tags
            )
            
            self.db.add(audit_log)
            self.db.commit()
            
        except Exception as e:
            self.logger.error(f"Failed to log audit event: {str(e)}")
            # Don't raise exception to avoid breaking main functionality


# Custom Exceptions
class ValidationError(Exception):
    """Validation error exception."""
    pass


class BusinessRuleViolationError(Exception):
    """Business rule violation exception."""
    pass


class EntityNotFoundError(Exception):
    """Entity not found exception."""
    pass


class EntityAlreadyExistsError(Exception):
    """Entity already exists exception."""
    pass

