"""
Global Configuration Module
Following SOLID principles and best practices

Author: Carlos Morais
"""

import os
from typing import List, Optional, Any, Dict
from pydantic import BaseSettings, Field, validator
from functools import lru_cache
import logging


class Settings(BaseSettings):
    """
    Application settings following SOLID principles.
    
    SRP: Single responsibility for configuration management
    OCP: Open for extension with new settings
    DIP: Depends on environment abstractions
    """
    
    # Application Settings
    APP_NAME: str = Field(default="Data Governance API", description="Application name")
    API_VERSION: str = Field(default="1.0.0", description="API version")
    API_V1_STR: str = Field(default="/api/v1", description="API v1 prefix")
    ENVIRONMENT: str = Field(default="development", description="Environment name")
    DEBUG: bool = Field(default=False, description="Debug mode")
    
    # Server Settings
    HOST: str = Field(default="0.0.0.0", description="Server host")
    PORT: int = Field(default=8000, description="Server port")
    WORKERS: int = Field(default=1, description="Number of workers")
    
    # Security Settings
    SECRET_KEY: str = Field(..., description="Secret key for JWT")
    ALGORITHM: str = Field(default="HS256", description="JWT algorithm")
    ACCESS_TOKEN_EXPIRE_MINUTES: int = Field(default=30, description="Token expiration time")
    REFRESH_TOKEN_EXPIRE_DAYS: int = Field(default=7, description="Refresh token expiration")
    
    # CORS Settings
    ALLOWED_HOSTS: List[str] = Field(
        default=["*"], 
        description="Allowed hosts for CORS"
    )
    ALLOWED_ORIGINS: List[str] = Field(
        default=["*"], 
        description="Allowed origins for CORS"
    )
    
    # Database Settings
    DATABASE_URL: str = Field(..., description="Database connection URL")
    DATABASE_POOL_SIZE: int = Field(default=20, description="Database pool size")
    DATABASE_MAX_OVERFLOW: int = Field(default=30, description="Database max overflow")
    DATABASE_POOL_TIMEOUT: int = Field(default=30, description="Database pool timeout")
    DATABASE_POOL_RECYCLE: int = Field(default=3600, description="Database pool recycle time")
    
    # Redis Settings
    REDIS_URL: str = Field(default="redis://localhost:6379/0", description="Redis connection URL")
    REDIS_POOL_SIZE: int = Field(default=10, description="Redis pool size")
    REDIS_TIMEOUT: int = Field(default=5, description="Redis timeout")
    
    # Logging Settings
    LOG_LEVEL: str = Field(default="INFO", description="Logging level")
    LOG_FORMAT: str = Field(
        default="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        description="Log format"
    )
    LOG_FILE: Optional[str] = Field(default=None, description="Log file path")
    LOG_MAX_SIZE: int = Field(default=10485760, description="Max log file size (10MB)")
    LOG_BACKUP_COUNT: int = Field(default=5, description="Log backup count")
    
    # External Services
    UNITY_CATALOG_URL: Optional[str] = Field(default=None, description="Unity Catalog URL")
    UNITY_CATALOG_TOKEN: Optional[str] = Field(default=None, description="Unity Catalog token")
    INFORMATICA_AXON_URL: Optional[str] = Field(default=None, description="Informatica Axon URL")
    INFORMATICA_AXON_TOKEN: Optional[str] = Field(default=None, description="Informatica Axon token")
    
    # Search Settings
    ELASTICSEARCH_URL: Optional[str] = Field(default=None, description="Elasticsearch URL")
    ELASTICSEARCH_INDEX: str = Field(default="data_governance", description="Elasticsearch index")
    SEARCH_TIMEOUT: int = Field(default=30, description="Search timeout")
    
    # Monitoring Settings
    ENABLE_METRICS: bool = Field(default=True, description="Enable metrics collection")
    METRICS_PORT: int = Field(default=9090, description="Metrics server port")
    HEALTH_CHECK_TIMEOUT: int = Field(default=30, description="Health check timeout")
    
    # Cache Settings
    CACHE_TTL: int = Field(default=300, description="Default cache TTL in seconds")
    CACHE_MAX_SIZE: int = Field(default=1000, description="Max cache size")
    
    # Rate Limiting
    RATE_LIMIT_REQUESTS: int = Field(default=100, description="Rate limit requests per minute")
    RATE_LIMIT_WINDOW: int = Field(default=60, description="Rate limit window in seconds")
    
    # File Upload Settings
    MAX_FILE_SIZE: int = Field(default=10485760, description="Max file size (10MB)")
    ALLOWED_FILE_TYPES: List[str] = Field(
        default=[".json", ".csv", ".xlsx", ".yaml", ".yml"],
        description="Allowed file types"
    )
    UPLOAD_DIR: str = Field(default="uploads", description="Upload directory")
    
    # Data Quality Settings
    QUALITY_CHECK_INTERVAL: int = Field(default=3600, description="Quality check interval in seconds")
    QUALITY_THRESHOLD: float = Field(default=0.8, description="Quality threshold (0-1)")
    
    # Governance Settings
    DEFAULT_CLASSIFICATION: str = Field(default="internal", description="Default security classification")
    DEFAULT_SENSITIVITY: str = Field(default="low", description="Default sensitivity level")
    RETENTION_DAYS: int = Field(default=2555, description="Default retention period (7 years)")
    
    class Config:
        """Pydantic configuration."""
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = True
        validate_assignment = True
        
        # Custom environment variable names
        fields = {
            "SECRET_KEY": {"env": ["SECRET_KEY", "JWT_SECRET_KEY"]},
            "DATABASE_URL": {"env": ["DATABASE_URL", "DB_URL"]},
            "REDIS_URL": {"env": ["REDIS_URL", "CACHE_URL"]},
        }
    
    @validator("ENVIRONMENT")
    def validate_environment(cls, v):
        """Validate environment value."""
        allowed_environments = ["development", "testing", "staging", "production"]
        if v not in allowed_environments:
            raise ValueError(f"Environment must be one of: {allowed_environments}")
        return v
    
    @validator("LOG_LEVEL")
    def validate_log_level(cls, v):
        """Validate log level."""
        allowed_levels = ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
        if v.upper() not in allowed_levels:
            raise ValueError(f"Log level must be one of: {allowed_levels}")
        return v.upper()
    
    @validator("SECRET_KEY")
    def validate_secret_key(cls, v):
        """Validate secret key."""
        if len(v) < 32:
            raise ValueError("Secret key must be at least 32 characters long")
        return v
    
    @validator("DATABASE_URL")
    def validate_database_url(cls, v):
        """Validate database URL."""
        if not v.startswith(("postgresql://", "postgresql+asyncpg://", "sqlite:///")):
            raise ValueError("Database URL must be PostgreSQL or SQLite")
        return v
    
    @validator("ALLOWED_HOSTS", pre=True)
    def validate_allowed_hosts(cls, v):
        """Validate allowed hosts."""
        if isinstance(v, str):
            return [host.strip() for host in v.split(",")]
        return v
    
    @validator("ALLOWED_ORIGINS", pre=True)
    def validate_allowed_origins(cls, v):
        """Validate allowed origins."""
        if isinstance(v, str):
            return [origin.strip() for origin in v.split(",")]
        return v
    
    @validator("QUALITY_THRESHOLD")
    def validate_quality_threshold(cls, v):
        """Validate quality threshold."""
        if not 0 <= v <= 1:
            raise ValueError("Quality threshold must be between 0 and 1")
        return v
    
    @property
    def is_development(self) -> bool:
        """Check if running in development mode."""
        return self.ENVIRONMENT == "development"
    
    @property
    def is_production(self) -> bool:
        """Check if running in production mode."""
        return self.ENVIRONMENT == "production"
    
    @property
    def is_testing(self) -> bool:
        """Check if running in testing mode."""
        return self.ENVIRONMENT == "testing"
    
    def get_database_config(self) -> Dict[str, Any]:
        """Get database configuration."""
        return {
            "url": self.DATABASE_URL,
            "pool_size": self.DATABASE_POOL_SIZE,
            "max_overflow": self.DATABASE_MAX_OVERFLOW,
            "pool_timeout": self.DATABASE_POOL_TIMEOUT,
            "pool_recycle": self.DATABASE_POOL_RECYCLE,
            "echo": self.DEBUG,
        }
    
    def get_redis_config(self) -> Dict[str, Any]:
        """Get Redis configuration."""
        return {
            "url": self.REDIS_URL,
            "pool_size": self.REDIS_POOL_SIZE,
            "timeout": self.REDIS_TIMEOUT,
        }
    
    def get_logging_config(self) -> Dict[str, Any]:
        """Get logging configuration."""
        return {
            "level": self.LOG_LEVEL,
            "format": self.LOG_FORMAT,
            "file": self.LOG_FILE,
            "max_size": self.LOG_MAX_SIZE,
            "backup_count": self.LOG_BACKUP_COUNT,
        }
    
    def get_cors_config(self) -> Dict[str, Any]:
        """Get CORS configuration."""
        return {
            "allow_origins": self.ALLOWED_ORIGINS,
            "allow_credentials": True,
            "allow_methods": ["*"],
            "allow_headers": ["*"],
        }
    
    def get_security_config(self) -> Dict[str, Any]:
        """Get security configuration."""
        return {
            "secret_key": self.SECRET_KEY,
            "algorithm": self.ALGORITHM,
            "access_token_expire_minutes": self.ACCESS_TOKEN_EXPIRE_MINUTES,
            "refresh_token_expire_days": self.REFRESH_TOKEN_EXPIRE_DAYS,
        }


class DevelopmentSettings(Settings):
    """Development environment settings."""
    
    DEBUG: bool = True
    LOG_LEVEL: str = "DEBUG"
    WORKERS: int = 1
    
    class Config(Settings.Config):
        env_prefix = "DEV_"


class ProductionSettings(Settings):
    """Production environment settings."""
    
    DEBUG: bool = False
    LOG_LEVEL: str = "INFO"
    WORKERS: int = 4
    
    class Config(Settings.Config):
        env_prefix = "PROD_"


class TestingSettings(Settings):
    """Testing environment settings."""
    
    DEBUG: bool = True
    LOG_LEVEL: str = "DEBUG"
    DATABASE_URL: str = "sqlite:///./test.db"
    REDIS_URL: str = "redis://localhost:6379/1"
    
    class Config(Settings.Config):
        env_prefix = "TEST_"


@lru_cache()
def get_settings() -> Settings:
    """
    Get application settings based on environment.
    
    Following SOLID principles:
    - SRP: Single responsibility for settings creation
    - OCP: Open for extension with new environment types
    - DIP: Depends on environment abstraction
    
    Returns:
        Settings: Application settings instance
    """
    environment = os.getenv("ENVIRONMENT", "development").lower()
    
    settings_map = {
        "development": DevelopmentSettings,
        "production": ProductionSettings,
        "testing": TestingSettings,
    }
    
    settings_class = settings_map.get(environment, DevelopmentSettings)
    
    try:
        settings = settings_class()
        logging.info(f"Loaded {environment} settings successfully")
        return settings
    except Exception as e:
        logging.error(f"Failed to load settings: {e}")
        # Fallback to development settings
        return DevelopmentSettings()


# Global settings instance
settings = get_settings()

