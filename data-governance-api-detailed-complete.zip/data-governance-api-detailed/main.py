#!/usr/bin/env python3
"""
Data Governance API - Main Application Entry Point
Following detailed project structure and SOLID principles

Author: Carlos Morais
"""

import uvicorn
from fastapi import FastAPI, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException
import logging
import sys
import os
from pathlib import Path

# Add src to Python path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from src.app.config.global_config import get_settings
from src.app.config.composer_config import setup_dependency_injection
from src.app.handler.external_requests import setup_external_handlers
from src.app.resources.routers import setup_routers
from src.app.services.hello_world_business_logic import HealthService
from src.utils import setup_logging

# Initialize settings
settings = get_settings()

# Setup logging
setup_logging()
logger = logging.getLogger(__name__)

def create_application() -> FastAPI:
    """
    Create and configure FastAPI application.
    
    Following SOLID principles:
    - SRP: Single responsibility for app creation
    - OCP: Open for extension with middleware and routers
    - DIP: Depends on configuration abstractions
    """
    
    # Create FastAPI instance
    app = FastAPI(
        title="Data Governance API",
        description="""
        Enterprise Data Governance API following SOLID principles.
        
        ## Features
        
        * **Data Objects Management**: Complete CRUD operations
        * **Data Contracts**: Contract definition and validation
        * **Data Lineage**: Tracking and visualization
        * **Quality Metrics**: Data quality monitoring
        * **Access Policies**: Granular access control
        * **Analytics**: Executive dashboards and reports
        * **Search**: Advanced search and discovery
        * **Sync**: External system integration
        
        ## Architecture
        
        Built following Clean Architecture and SOLID principles:
        - **Single Responsibility**: Each component has one reason to change
        - **Open/Closed**: Open for extension, closed for modification
        - **Liskov Substitution**: Implementations are substitutable
        - **Interface Segregation**: Clients depend only on what they use
        - **Dependency Inversion**: Depend on abstractions, not concretions
        """,
        version=settings.API_VERSION,
        openapi_url=f"{settings.API_V1_STR}/openapi.json",
        docs_url="/docs",
        redoc_url="/redoc",
        contact={
            "name": "Data Governance Team",
            "email": "data-governance@company.com",
        },
        license_info={
            "name": "MIT",
            "url": "https://opensource.org/licenses/MIT",
        },
    )
    
    # Setup CORS middleware
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.ALLOWED_HOSTS,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    # Setup trusted host middleware
    app.add_middleware(
        TrustedHostMiddleware,
        allowed_hosts=settings.ALLOWED_HOSTS
    )
    
    # Setup dependency injection
    setup_dependency_injection(app)
    
    # Setup external handlers
    setup_external_handlers(app)
    
    # Setup routers
    setup_routers(app)
    
    # Setup exception handlers
    setup_exception_handlers(app)
    
    # Setup startup and shutdown events
    setup_events(app)
    
    return app


def setup_exception_handlers(app: FastAPI) -> None:
    """
    Setup global exception handlers.
    
    Following SOLID principles:
    - SRP: Single responsibility for exception handling
    - OCP: Open for extension with new exception types
    """
    
    @app.exception_handler(StarletteHTTPException)
    async def http_exception_handler(request: Request, exc: StarletteHTTPException):
        """Handle HTTP exceptions."""
        logger.error(f"HTTP exception: {exc.status_code} - {exc.detail}")
        return JSONResponse(
            status_code=exc.status_code,
            content={
                "detail": exc.detail,
                "status_code": exc.status_code,
                "path": str(request.url),
                "method": request.method
            }
        )
    
    @app.exception_handler(RequestValidationError)
    async def validation_exception_handler(request: Request, exc: RequestValidationError):
        """Handle validation exceptions."""
        logger.error(f"Validation error: {exc.errors()}")
        return JSONResponse(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            content={
                "detail": "Validation error",
                "errors": exc.errors(),
                "status_code": 422,
                "path": str(request.url),
                "method": request.method
            }
        )
    
    @app.exception_handler(Exception)
    async def general_exception_handler(request: Request, exc: Exception):
        """Handle general exceptions."""
        logger.error(f"Unexpected error: {str(exc)}", exc_info=True)
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={
                "detail": "Internal server error",
                "status_code": 500,
                "path": str(request.url),
                "method": request.method
            }
        )


def setup_events(app: FastAPI) -> None:
    """
    Setup application startup and shutdown events.
    
    Following SOLID principles:
    - SRP: Single responsibility for lifecycle management
    """
    
    @app.on_event("startup")
    async def startup_event():
        """Application startup event."""
        logger.info("Starting Data Governance API...")
        logger.info(f"Environment: {settings.ENVIRONMENT}")
        logger.info(f"Debug mode: {settings.DEBUG}")
        logger.info(f"API Version: {settings.API_VERSION}")
        
        # Initialize health service
        health_service = HealthService()
        await health_service.initialize()
        
        logger.info("Data Governance API started successfully!")
    
    @app.on_event("shutdown")
    async def shutdown_event():
        """Application shutdown event."""
        logger.info("Shutting down Data Governance API...")
        
        # Cleanup resources
        health_service = HealthService()
        await health_service.cleanup()
        
        logger.info("Data Governance API shutdown complete!")


# Create application instance
app = create_application()


# Health check endpoint
@app.get("/health", tags=["Health"])
async def health_check():
    """
    Health check endpoint.
    
    Returns:
        dict: Health status information
    """
    health_service = HealthService()
    return await health_service.get_health_status()


@app.get("/", tags=["Root"])
async def root():
    """
    Root endpoint.
    
    Returns:
        dict: API information
    """
    return {
        "message": "Data Governance API",
        "version": settings.API_VERSION,
        "environment": settings.ENVIRONMENT,
        "docs_url": "/docs",
        "redoc_url": "/redoc",
        "health_url": "/health"
    }


if __name__ == "__main__":
    """
    Run the application directly.
    
    For development purposes only.
    In production, use a proper ASGI server like uvicorn or gunicorn.
    """
    uvicorn.run(
        "main:app",
        host=settings.HOST,
        port=settings.PORT,
        reload=settings.DEBUG,
        log_level=settings.LOG_LEVEL.lower(),
        access_log=True,
        use_colors=True,
    )

