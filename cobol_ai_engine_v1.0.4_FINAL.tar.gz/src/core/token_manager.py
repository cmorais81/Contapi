"""
COBOL AI Engine v1.0.4 - Token Manager
Sistema inteligente de controle e divisão de tokens.
"""

import re
import logging
from typing import List, Dict, Any, Tuple, Optional
from dataclasses import dataclass


@dataclass
class TokenChunk:
    """Representa um pedaço do código com informações de tokens."""
    content: str
    estimated_tokens: int
    chunk_type: str  # 'header', 'division', 'section', 'paragraph', 'code'
    start_line: int
    end_line: int
    priority: int  # 1=alta, 2=média, 3=baixa


class TokenManager:
    """Gerenciador inteligente de tokens para análise COBOL."""
    
    def __init__(self, max_tokens: int = 4000):
        """
        Inicializa o gerenciador de tokens.
        
        Args:
            max_tokens: Limite máximo de tokens por prompt
        """
        self.logger = logging.getLogger(__name__)
        self.max_tokens = max_tokens
        self.safety_margin = 500  # Margem de segurança
        self.effective_limit = max_tokens - self.safety_margin
        
        # Padrões COBOL para divisão inteligente
        self.cobol_patterns = {
            'identification_division': r'^\s*IDENTIFICATION\s+DIVISION\.',
            'environment_division': r'^\s*ENVIRONMENT\s+DIVISION\.',
            'data_division': r'^\s*DATA\s+DIVISION\.',
            'procedure_division': r'^\s*PROCEDURE\s+DIVISION\.',
            'working_storage': r'^\s*WORKING-STORAGE\s+SECTION\.',
            'linkage_section': r'^\s*LINKAGE\s+SECTION\.',
            'file_section': r'^\s*FILE\s+SECTION\.',
            'paragraph': r'^\s*[A-Z0-9][A-Z0-9\-]*\s*\.',
            'section': r'^\s*[A-Z0-9][A-Z0-9\-]*\s+SECTION\.',
            'copy_statement': r'^\s*COPY\s+',
            'program_id': r'^\s*PROGRAM-ID\.',
            'end_program': r'^\s*END\s+PROGRAM\s+'
        }
        
    def estimate_tokens(self, text: str) -> int:
        """
        Estima o número de tokens em um texto.
        Usa aproximação: 1 token ≈ 4 caracteres para COBOL.
        """
        if not text:
            return 0
        
        # Remover comentários e linhas vazias para estimativa mais precisa
        lines = text.split('\n')
        content_lines = []
        
        for line in lines:
            line = line.strip()
            if line and not line.startswith('*') and not line.startswith('/'):
                content_lines.append(line)
        
        content = '\n'.join(content_lines)
        
        # Estimativa: 1 token ≈ 4 caracteres para código COBOL
        estimated_tokens = len(content) // 4
        
        # Adicionar tokens para estrutura (palavras-chave, pontuação, etc.)
        keywords = len(re.findall(r'\b(MOVE|PERFORM|IF|ELSE|END-IF|CALL|DISPLAY|ACCEPT|COMPUTE|ADD|SUBTRACT|MULTIPLY|DIVIDE)\b', content, re.IGNORECASE))
        estimated_tokens += keywords * 2  # Palavras-chave contam mais
        
        return max(estimated_tokens, 10)  # Mínimo de 10 tokens
    
    def split_cobol_program(self, program_code: str, program_name: str) -> List[TokenChunk]:
        """
        Divide um programa COBOL em chunks inteligentes baseados na estrutura.
        """
        chunks = []
        lines = program_code.split('\n')
        current_chunk = []
        current_type = 'header'
        current_priority = 1
        start_line = 0
        
        for i, line in enumerate(lines):
            line_stripped = line.strip()
            
            # Detectar mudanças de divisão/seção
            new_type = self._detect_cobol_structure(line)
            if new_type and new_type != current_type:
                # Finalizar chunk atual
                if current_chunk:
                    chunk_content = '\n'.join(current_chunk)
                    if chunk_content.strip():
                        chunks.append(TokenChunk(
                            content=chunk_content,
                            estimated_tokens=self.estimate_tokens(chunk_content),
                            chunk_type=current_type,
                            start_line=start_line,
                            end_line=i-1,
                            priority=current_priority
                        ))
                
                # Iniciar novo chunk
                current_chunk = [line]
                current_type = new_type
                current_priority = self._get_priority(new_type)
                start_line = i
            else:
                current_chunk.append(line)
        
        # Finalizar último chunk
        if current_chunk:
            chunk_content = '\n'.join(current_chunk)
            if chunk_content.strip():
                chunks.append(TokenChunk(
                    content=chunk_content,
                    estimated_tokens=self.estimate_tokens(chunk_content),
                    chunk_type=current_type,
                    start_line=start_line,
                    end_line=len(lines)-1,
                    priority=current_priority
                ))
        
        self.logger.info(f"Programa {program_name} dividido em {len(chunks)} chunks")
        return chunks
    
    def _detect_cobol_structure(self, line: str) -> Optional[str]:
        """Detecta o tipo de estrutura COBOL na linha."""
        line_upper = line.upper().strip()
        
        for structure_type, pattern in self.cobol_patterns.items():
            if re.match(pattern, line_upper):
                return structure_type
        
        return None
    
    def _get_priority(self, chunk_type: str) -> int:
        """Define prioridade do chunk baseado no tipo."""
        high_priority = ['identification_division', 'program_id', 'procedure_division']
        medium_priority = ['data_division', 'working_storage', 'linkage_section']
        
        if chunk_type in high_priority:
            return 1
        elif chunk_type in medium_priority:
            return 2
        else:
            return 3
    
    def create_optimized_prompts(self, program_code: str, program_name: str, 
                                base_prompt: str, questions: List[str]) -> List[Dict[str, Any]]:
        """
        Cria prompts otimizados respeitando o limite de tokens.
        """
        # Estimar tokens do prompt base e perguntas
        base_tokens = self.estimate_tokens(base_prompt)
        questions_tokens = sum(self.estimate_tokens(q) for q in questions)
        overhead_tokens = base_tokens + questions_tokens + 200  # Margem para formatação
        
        available_tokens = self.effective_limit - overhead_tokens
        
        if available_tokens <= 0:
            self.logger.error("Prompt base muito grande, não sobra espaço para código")
            available_tokens = 1000  # Valor mínimo
        
        # Verificar se o programa inteiro cabe
        total_program_tokens = self.estimate_tokens(program_code)
        
        if total_program_tokens <= available_tokens:
            # Programa cabe inteiro
            self.logger.info(f"Programa {program_name} cabe em um único prompt ({total_program_tokens} tokens)")
            return [{
                'prompt': self._build_complete_prompt(base_prompt, program_code, program_name, questions),
                'chunk_info': f"Programa completo ({total_program_tokens} tokens)",
                'is_complete': True,
                'chunk_number': 1,
                'total_chunks': 1
            }]
        
        # Programa precisa ser dividido
        self.logger.info(f"Programa {program_name} muito grande ({total_program_tokens} tokens), dividindo...")
        chunks = self.split_cobol_program(program_code, program_name)
        
        # Agrupar chunks respeitando limite de tokens
        prompt_groups = self._group_chunks_by_tokens(chunks, available_tokens)
        
        # Criar prompts para cada grupo
        prompts = []
        for i, group in enumerate(prompt_groups):
            combined_code = '\n\n'.join([chunk.content for chunk in group])
            chunk_types = [chunk.chunk_type for chunk in group]
            total_tokens = sum(chunk.estimated_tokens for chunk in group)
            
            prompt = self._build_partial_prompt(
                base_prompt, combined_code, program_name, questions, 
                i + 1, len(prompt_groups), chunk_types
            )
            
            prompts.append({
                'prompt': prompt,
                'chunk_info': f"Parte {i+1}/{len(prompt_groups)} - {', '.join(set(chunk_types))} ({total_tokens} tokens)",
                'is_complete': False,
                'chunk_number': i + 1,
                'total_chunks': len(prompt_groups),
                'chunk_types': chunk_types
            })
        
        self.logger.info(f"Programa {program_name} dividido em {len(prompts)} prompts")
        return prompts
    
    def _group_chunks_by_tokens(self, chunks: List[TokenChunk], max_tokens: int) -> List[List[TokenChunk]]:
        """Agrupa chunks respeitando o limite de tokens."""
        groups = []
        current_group = []
        current_tokens = 0
        
        # Ordenar chunks por prioridade
        sorted_chunks = sorted(chunks, key=lambda x: (x.priority, x.start_line))
        
        for chunk in sorted_chunks:
            if current_tokens + chunk.estimated_tokens <= max_tokens:
                current_group.append(chunk)
                current_tokens += chunk.estimated_tokens
            else:
                # Finalizar grupo atual
                if current_group:
                    groups.append(current_group)
                
                # Iniciar novo grupo
                if chunk.estimated_tokens <= max_tokens:
                    current_group = [chunk]
                    current_tokens = chunk.estimated_tokens
                else:
                    # Chunk muito grande, dividir ainda mais
                    sub_chunks = self._split_large_chunk(chunk, max_tokens)
                    for sub_chunk in sub_chunks:
                        groups.append([sub_chunk])
                    current_group = []
                    current_tokens = 0
        
        # Finalizar último grupo
        if current_group:
            groups.append(current_group)
        
        return groups
    
    def _split_large_chunk(self, chunk: TokenChunk, max_tokens: int) -> List[TokenChunk]:
        """Divide um chunk muito grande em pedaços menores."""
        lines = chunk.content.split('\n')
        sub_chunks = []
        current_lines = []
        current_tokens = 0
        
        for i, line in enumerate(lines):
            line_tokens = self.estimate_tokens(line)
            
            if current_tokens + line_tokens <= max_tokens:
                current_lines.append(line)
                current_tokens += line_tokens
            else:
                # Finalizar sub-chunk atual
                if current_lines:
                    sub_chunks.append(TokenChunk(
                        content='\n'.join(current_lines),
                        estimated_tokens=current_tokens,
                        chunk_type=f"{chunk.chunk_type}_part",
                        start_line=chunk.start_line,
                        end_line=chunk.start_line + len(current_lines) - 1,
                        priority=chunk.priority
                    ))
                
                # Iniciar novo sub-chunk
                current_lines = [line]
                current_tokens = line_tokens
        
        # Finalizar último sub-chunk
        if current_lines:
            sub_chunks.append(TokenChunk(
                content='\n'.join(current_lines),
                estimated_tokens=current_tokens,
                chunk_type=f"{chunk.chunk_type}_part",
                start_line=chunk.start_line,
                end_line=chunk.end_line,
                priority=chunk.priority
            ))
        
        return sub_chunks
    
    def _build_complete_prompt(self, base_prompt: str, program_code: str, 
                              program_name: str, questions: List[str]) -> str:
        """Constrói prompt completo para programa que cabe inteiro."""
        prompt = f"{base_prompt}\n\n"
        prompt += f"Nome do programa: {program_name}\n"
        prompt += f"Código completo do programa:\n\n```cobol\n{program_code}\n```\n\n"
        
        if questions:
            prompt += "Por favor, responda às seguintes perguntas específicas:\n\n"
            for i, question in enumerate(questions, 1):
                prompt += f"{i}. {question}\n"
            prompt += "\n"
        
        prompt += "Forneça uma análise completa e detalhada em português brasileiro."
        return prompt
    
    def _build_partial_prompt(self, base_prompt: str, code_chunk: str, program_name: str,
                             questions: List[str], chunk_num: int, total_chunks: int,
                             chunk_types: List[str]) -> str:
        """Constrói prompt para parte do programa."""
        prompt = f"{base_prompt}\n\n"
        prompt += f"Nome do programa: {program_name}\n"
        prompt += f"ATENÇÃO: Esta é a PARTE {chunk_num} de {total_chunks} do programa.\n"
        prompt += f"Seções incluídas nesta parte: {', '.join(set(chunk_types))}\n\n"
        prompt += f"Código desta parte:\n\n```cobol\n{code_chunk}\n```\n\n"
        
        if chunk_num == 1:
            # Primeira parte - perguntas completas
            if questions:
                prompt += "Por favor, responda às seguintes perguntas específicas baseado nesta parte:\n\n"
                for i, question in enumerate(questions, 1):
                    prompt += f"{i}. {question}\n"
                prompt += "\n"
            prompt += f"IMPORTANTE: Esta é a parte {chunk_num} de {total_chunks}. "
            prompt += "Analise esta parte e indique que análise adicional será necessária nas próximas partes."
        else:
            # Partes subsequentes - análise focada
            prompt += f"IMPORTANTE: Esta é a parte {chunk_num} de {total_chunks}. "
            prompt += "Continue a análise do programa baseado nesta parte adicional. "
            prompt += "Complemente as informações já analisadas nas partes anteriores."
        
        prompt += "\n\nForneça uma análise detalhada em português brasileiro."
        return prompt
    
    def combine_partial_results(self, results: List[Dict[str, Any]], program_name: str) -> str:
        """Combina resultados de múltiplas partes em uma análise consolidada."""
        if len(results) == 1:
            return results[0].get('content', '')
        
        combined = f"# Análise Consolidada do Programa {program_name}\n\n"
        combined += f"*Programa analisado em {len(results)} partes devido ao tamanho*\n\n"
        
        # Seção de resumo executivo
        combined += "## Resumo Executivo\n\n"
        combined += "Esta análise foi realizada em múltiplas partes para garantir cobertura completa do programa.\n\n"
        
        # Combinar análises por parte
        for i, result in enumerate(results, 1):
            content = result.get('content', '')
            chunk_info = result.get('chunk_info', f'Parte {i}')
            
            combined += f"## Análise - {chunk_info}\n\n"
            combined += content
            combined += "\n\n---\n\n"
        
        # Seção de conclusão
        combined += "## Conclusão da Análise Consolidada\n\n"
        combined += f"O programa {program_name} foi analisado completamente em {len(results)} partes, "
        combined += "garantindo cobertura total de todas as funcionalidades e estruturas.\n\n"
        
        return combined
    
    def get_token_stats(self) -> Dict[str, Any]:
        """Retorna estatísticas do gerenciador de tokens."""
        return {
            'max_tokens': self.max_tokens,
            'effective_limit': self.effective_limit,
            'safety_margin': self.safety_margin,
            'status': 'active'
        }

