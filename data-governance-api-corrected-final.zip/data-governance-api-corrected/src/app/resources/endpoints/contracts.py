"""
Endpoints FastAPI para contratos de dados
Implementa princípios SOLID e documentação OpenAPI completa
"""

from fastapi import APIRouter, Depends, HTTPException, status, Query, Path
from fastapi.responses import JSONResponse
from sqlalchemy.orm import Session
from typing import List, Optional
from uuid import UUID
import logging

from ...config.database import get_db_session
from ...schemas import (
    DataContractCreate, DataContractUpdate, DataContractResponse,
    ContractFilters, PaginationParams, PaginatedResponse,
    ErrorResponse, ContractStatus, DataClassification
)
from ...services.interfaces import IDataContractService
from ...utils.exceptions import (
    EntityNotFoundError, EntityAlreadyExistsError,
    BusinessRuleViolationError, ValidationError
)
from ...utils.auth import get_current_user
from ...utils.error_handler import handle_api_error

logger = logging.getLogger(__name__)

# Router para contratos
router = APIRouter(
    prefix="/contracts",
    tags=["Data Contracts"],
    responses={
        404: {"model": ErrorResponse, "description": "Contrato não encontrado"},
        422: {"model": ErrorResponse, "description": "Erro de validação"},
        500: {"model": ErrorResponse, "description": "Erro interno do servidor"}
    }
)


@router.post(
    "/",
    response_model=DataContractResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Criar novo contrato de dados",
    description="""
    Cria um novo contrato de dados com validações completas.
    
    **Funcionalidades:**
    - Validação de unicidade de nome e versão
    - Verificação de frameworks de compliance
    - Auditoria automática da criação
    - Suporte a versionamento semântico
    
    **Regras de negócio:**
    - Nome do contrato deve ser único por versão
    - Versão deve seguir padrão semântico (x.y.z)
    - Classificação de dados é obrigatória
    - Frameworks de compliance devem existir
    """,
    responses={
        201: {
            "description": "Contrato criado com sucesso",
            "content": {
                "application/json": {
                    "example": {
                        "id": "123e4567-e89b-12d3-a456-426614174000",
                        "contract_name": "customer_data_v1",
                        "contract_version": "1.0.0",
                        "contract_status": "draft",
                        "data_classification": "confidential",
                        "created_at": "2024-01-15T10:30:00Z"
                    }
                }
            }
        },
        409: {"description": "Contrato já existe com mesmo nome e versão"}
    }
)
async def create_contract(
    contract_data: DataContractCreate,
    current_user: dict = Depends(get_current_user),
    contract_service: IDataContractService = Depends(),
    db: Session = Depends(get_db_session)
) -> DataContractResponse:
    """
    Cria um novo contrato de dados
    Implementa SRP: responsável apenas pela criação via API
    """
    try:
        result = await contract_service.create_contract(
            contract_data=contract_data,
            user_id=current_user["user_id"],
            db=db
        )
        
        logger.info(f"Contrato criado: {result.id} por usuário {current_user['user_id']}")
        return result
        
    except EntityAlreadyExistsError as e:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(e)
        )
    except ValidationError as e:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=str(e)
        )
    except Exception as e:
        return handle_api_error(e, "Erro ao criar contrato")


@router.get(
    "/{contract_id}",
    response_model=DataContractResponse,
    summary="Obter contrato por ID",
    description="""
    Obtém um contrato específico por seu ID único.
    
    **Funcionalidades:**
    - Carregamento otimizado com relacionamentos
    - Informações de auditoria incluídas
    - Frameworks de compliance associados
    - Histórico de aprovações
    """,
    responses={
        200: {
            "description": "Contrato encontrado",
            "content": {
                "application/json": {
                    "example": {
                        "id": "123e4567-e89b-12d3-a456-426614174000",
                        "contract_name": "customer_data_v1",
                        "contract_version": "1.0.0",
                        "contract_status": "active",
                        "created_by": {
                            "id": "user-123",
                            "username": "john.doe",
                            "full_name": "John Doe"
                        },
                        "compliance_frameworks": [
                            {
                                "id": "framework-123",
                                "framework_name": "GDPR",
                                "framework_code": "GDPR"
                            }
                        ]
                    }
                }
            }
        }
    }
)
async def get_contract(
    contract_id: UUID = Path(..., description="ID único do contrato"),
    current_user: dict = Depends(get_current_user),
    contract_service: IDataContractService = Depends(),
    db: Session = Depends(get_db_session)
) -> DataContractResponse:
    """
    Obtém um contrato por ID
    Implementa SRP: responsável apenas pela obtenção via API
    """
    try:
        result = await contract_service.get_contract(
            contract_id=contract_id,
            db=db
        )
        
        if not result:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Contrato {contract_id} não encontrado"
            )
        
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        return handle_api_error(e, f"Erro ao obter contrato {contract_id}")


@router.get(
    "/",
    response_model=PaginatedResponse,
    summary="Listar contratos com filtros",
    description="""
    Lista contratos com suporte a filtros avançados e paginação.
    
    **Filtros disponíveis:**
    - Nome do contrato (busca parcial)
    - Status do contrato
    - Classificação de dados
    - Código do país
    - Período de criação
    - Busca textual (nome, descrição, propósito)
    
    **Ordenação:**
    - Por data de criação, atualização ou nome
    - Ordem crescente ou decrescente
    
    **Paginação:**
    - Tamanho da página configurável (1-100)
    - Navegação por páginas
    """,
    responses={
        200: {
            "description": "Lista de contratos",
            "content": {
                "application/json": {
                    "example": {
                        "items": [
                            {
                                "id": "123e4567-e89b-12d3-a456-426614174000",
                                "contract_name": "customer_data_v1",
                                "contract_version": "1.0.0",
                                "contract_status": "active"
                            }
                        ],
                        "total": 1,
                        "page": 1,
                        "size": 20,
                        "pages": 1
                    }
                }
            }
        }
    }
)
async def list_contracts(
    # Filtros
    contract_name: Optional[str] = Query(None, description="Filtro por nome do contrato"),
    contract_status: Optional[ContractStatus] = Query(None, description="Filtro por status"),
    data_classification: Optional[DataClassification] = Query(None, description="Filtro por classificação"),
    country_code: Optional[str] = Query(None, regex="^[A-Z]{3}$", description="Código do país (ISO 3166-1)"),
    search: Optional[str] = Query(None, min_length=3, description="Busca textual"),
    
    # Paginação
    page: int = Query(1, ge=1, description="Número da página"),
    size: int = Query(20, ge=1, le=100, description="Tamanho da página"),
    sort_by: str = Query("created_at", description="Campo para ordenação"),
    sort_order: str = Query("desc", regex="^(asc|desc)$", description="Ordem de classificação"),
    
    # Dependências
    current_user: dict = Depends(get_current_user),
    contract_service: IDataContractService = Depends(),
    db: Session = Depends(get_db_session)
) -> PaginatedResponse:
    """
    Lista contratos com filtros e paginação
    Implementa SRP: responsável apenas pela listagem via API
    """
    try:
        # Construir filtros
        filters = ContractFilters(
            contract_name=contract_name,
            contract_status=contract_status,
            data_classification=data_classification,
            country_code=country_code,
            search=search
        )
        
        # Construir paginação
        pagination = PaginationParams(
            page=page,
            size=size,
            sort_by=sort_by,
            sort_order=sort_order
        )
        
        # Obter contratos
        contracts, total = await contract_service.get_contracts(
            filters=filters,
            pagination=pagination,
            db=db
        )
        
        # Calcular páginas
        pages = (total + size - 1) // size
        
        return PaginatedResponse(
            items=contracts,
            total=total,
            page=page,
            size=size,
            pages=pages
        )
        
    except Exception as e:
        return handle_api_error(e, "Erro ao listar contratos")


@router.put(
    "/{contract_id}",
    response_model=DataContractResponse,
    summary="Atualizar contrato",
    description="""
    Atualiza um contrato existente com validações de negócio.
    
    **Funcionalidades:**
    - Validação de regras de negócio
    - Controle de breaking changes
    - Auditoria automática das alterações
    - Verificação de permissões
    
    **Regras de negócio:**
    - Contratos arquivados não podem ser atualizados
    - Mudanças em contratos ativos podem requerer aprovação
    - Alterações são registradas para auditoria
    """,
    responses={
        200: {"description": "Contrato atualizado com sucesso"},
        403: {"description": "Sem permissão para atualizar"},
        409: {"description": "Conflito de regras de negócio"}
    }
)
async def update_contract(
    contract_id: UUID = Path(..., description="ID único do contrato"),
    contract_data: DataContractUpdate = ...,
    current_user: dict = Depends(get_current_user),
    contract_service: IDataContractService = Depends(),
    db: Session = Depends(get_db_session)
) -> DataContractResponse:
    """
    Atualiza um contrato existente
    Implementa SRP: responsável apenas pela atualização via API
    """
    try:
        result = await contract_service.update_contract(
            contract_id=contract_id,
            contract_data=contract_data,
            user_id=current_user["user_id"],
            db=db
        )
        
        if not result:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Contrato {contract_id} não encontrado"
            )
        
        logger.info(f"Contrato {contract_id} atualizado por usuário {current_user['user_id']}")
        return result
        
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except BusinessRuleViolationError as e:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(e)
        )
    except Exception as e:
        return handle_api_error(e, f"Erro ao atualizar contrato {contract_id}")


@router.delete(
    "/{contract_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Arquivar contrato",
    description="""
    Arquiva um contrato (soft delete) seguindo regras de negócio.
    
    **Funcionalidades:**
    - Soft delete (não remove fisicamente)
    - Validação de regras de negócio
    - Auditoria automática da operação
    - Verificação de dependências
    
    **Regras de negócio:**
    - Contratos ativos não podem ser arquivados
    - Operação é irreversível via API
    - Registra auditoria completa
    """,
    responses={
        204: {"description": "Contrato arquivado com sucesso"},
        409: {"description": "Contrato não pode ser arquivado"}
    }
)
async def delete_contract(
    contract_id: UUID = Path(..., description="ID único do contrato"),
    current_user: dict = Depends(get_current_user),
    contract_service: IDataContractService = Depends(),
    db: Session = Depends(get_db_session)
):
    """
    Arquiva um contrato (soft delete)
    Implementa SRP: responsável apenas pela remoção via API
    """
    try:
        success = await contract_service.delete_contract(
            contract_id=contract_id,
            user_id=current_user["user_id"],
            db=db
        )
        
        if not success:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Contrato {contract_id} não encontrado"
            )
        
        logger.info(f"Contrato {contract_id} arquivado por usuário {current_user['user_id']}")
        
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except BusinessRuleViolationError as e:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(e)
        )
    except Exception as e:
        return handle_api_error(e, f"Erro ao arquivar contrato {contract_id}")


@router.post(
    "/{contract_id}/approve",
    response_model=DataContractResponse,
    summary="Aprovar contrato",
    description="""
    Aprova um contrato seguindo workflow de aprovação.
    
    **Funcionalidades:**
    - Workflow de aprovação estruturado
    - Validação de permissões de aprovador
    - Ativação automática do contrato
    - Auditoria completa da aprovação
    
    **Regras de negócio:**
    - Apenas administradores podem aprovar
    - Apenas contratos em draft podem ser aprovados
    - Aprovação ativa o contrato automaticamente
    - Define data de vigência se não especificada
    """,
    responses={
        200: {"description": "Contrato aprovado com sucesso"},
        403: {"description": "Sem permissão para aprovar"},
        409: {"description": "Contrato não pode ser aprovado"}
    }
)
async def approve_contract(
    contract_id: UUID = Path(..., description="ID único do contrato"),
    current_user: dict = Depends(get_current_user),
    contract_service: IDataContractService = Depends(),
    db: Session = Depends(get_db_session)
) -> DataContractResponse:
    """
    Aprova um contrato
    Implementa SRP: responsável apenas pela aprovação via API
    """
    try:
        result = await contract_service.approve_contract(
            contract_id=contract_id,
            user_id=current_user["user_id"],
            db=db
        )
        
        if not result:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Contrato {contract_id} não encontrado"
            )
        
        logger.info(f"Contrato {contract_id} aprovado por usuário {current_user['user_id']}")
        return result
        
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except BusinessRuleViolationError as e:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=str(e)
        )
    except Exception as e:
        return handle_api_error(e, f"Erro ao aprovar contrato {contract_id}")


@router.get(
    "/{contract_id}/versions",
    response_model=List[dict],
    summary="Obter versões do contrato",
    description="""
    Obtém todas as versões de um contrato específico.
    
    **Funcionalidades:**
    - Histórico completo de versões
    - Informações de breaking changes
    - Detalhes de migração entre versões
    - Ordenação cronológica
    """,
    responses={
        200: {"description": "Lista de versões do contrato"}
    }
)
async def get_contract_versions(
    contract_id: UUID = Path(..., description="ID único do contrato"),
    current_user: dict = Depends(get_current_user),
    contract_service: IDataContractService = Depends(),
    db: Session = Depends(get_db_session)
) -> List[dict]:
    """
    Obtém versões de um contrato
    Implementa SRP: responsável apenas pela obtenção de versões via API
    """
    try:
        versions = await contract_service.get_contract_versions(
            contract_id=contract_id,
            db=db
        )
        
        return versions
        
    except Exception as e:
        return handle_api_error(e, f"Erro ao obter versões do contrato {contract_id}")


@router.get(
    "/{contract_id}/health",
    summary="Verificar saúde do contrato",
    description="""
    Verifica a saúde e conformidade de um contrato.
    
    **Verificações:**
    - Status de compliance
    - Validade das datas
    - Integridade dos dados
    - Alertas de expiração
    """,
    responses={
        200: {
            "description": "Status de saúde do contrato",
            "content": {
                "application/json": {
                    "example": {
                        "contract_id": "123e4567-e89b-12d3-a456-426614174000",
                        "health_status": "healthy",
                        "compliance_status": "compliant",
                        "warnings": [],
                        "expires_in_days": 90
                    }
                }
            }
        }
    }
)
async def get_contract_health(
    contract_id: UUID = Path(..., description="ID único do contrato"),
    current_user: dict = Depends(get_current_user),
    contract_service: IDataContractService = Depends(),
    db: Session = Depends(get_db_session)
) -> dict:
    """
    Verifica saúde do contrato
    Implementa SRP: responsável apenas pela verificação de saúde via API
    """
    try:
        # Verificar se contrato existe
        contract = await contract_service.get_contract(contract_id, db)
        if not contract:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Contrato {contract_id} não encontrado"
            )
        
        # Calcular status de saúde (implementação básica)
        health_status = "healthy"
        warnings = []
        
        if contract.expiration_date:
            from datetime import datetime, timedelta
            days_until_expiration = (contract.expiration_date - datetime.utcnow()).days
            if days_until_expiration < 30:
                warnings.append(f"Contrato expira em {days_until_expiration} dias")
                health_status = "warning"
        else:
            days_until_expiration = None
        
        return {
            "contract_id": contract_id,
            "health_status": health_status,
            "compliance_status": "compliant",  # Será implementado no ComplianceService
            "warnings": warnings,
            "expires_in_days": days_until_expiration
        }
        
    except HTTPException:
        raise
    except Exception as e:
        return handle_api_error(e, f"Erro ao verificar saúde do contrato {contract_id}")

