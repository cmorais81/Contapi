"""
Serviço de auditoria para Data Governance API
Implementa logging de auditoria e princípios SOLID
"""

from typing import List, Optional, Dict, Any, Tuple
from uuid import UUID
from sqlalchemy.orm import Session, joinedload
from sqlalchemy import and_, or_, desc, func
from datetime import datetime, timedelta
import json
import logging

from .interfaces import IAuditService
from ..models import AuditLog, DataContract, User
from ..schemas import (
    AuditLogResponse, PaginationParams, ActionType
)
from ..utils.exceptions import (
    EntityNotFoundError, ValidationError
)

logger = logging.getLogger(__name__)


class AuditEventProcessor:
    """
    Processador de eventos de auditoria
    Implementa SRP: responsável apenas pelo processamento de eventos
    """
    
    @staticmethod
    def calculate_change_summary(
        old_values: Optional[Dict[str, Any]],
        new_values: Optional[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Calcula resumo das mudanças entre valores antigos e novos
        """
        if not old_values and not new_values:
            return {}
        
        if not old_values:
            return {
                'change_type': 'CREATE',
                'fields_added': list(new_values.keys()) if new_values else [],
                'total_changes': len(new_values) if new_values else 0
            }
        
        if not new_values:
            return {
                'change_type': 'DELETE',
                'fields_removed': list(old_values.keys()),
                'total_changes': len(old_values)
            }
        
        # Comparar valores
        fields_changed = []
        fields_added = []
        fields_removed = []
        
        all_keys = set(old_values.keys()) | set(new_values.keys())
        
        for key in all_keys:
            if key not in old_values:
                fields_added.append(key)
            elif key not in new_values:
                fields_removed.append(key)
            elif old_values[key] != new_values[key]:
                fields_changed.append(key)
        
        return {
            'change_type': 'UPDATE',
            'fields_changed': fields_changed,
            'fields_added': fields_added,
            'fields_removed': fields_removed,
            'total_changes': len(fields_changed) + len(fields_added) + len(fields_removed)
        }
    
    @staticmethod
    def sanitize_sensitive_data(data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Remove dados sensíveis dos logs de auditoria
        """
        sensitive_fields = [
            'password', 'token', 'secret', 'key', 'credential',
            'ssn', 'cpf', 'credit_card', 'bank_account'
        ]
        
        sanitized = {}
        for key, value in data.items():
            key_lower = key.lower()
            
            # Verificar se campo é sensível
            is_sensitive = any(sensitive in key_lower for sensitive in sensitive_fields)
            
            if is_sensitive:
                sanitized[key] = '[REDACTED]'
            elif isinstance(value, dict):
                sanitized[key] = AuditEventProcessor.sanitize_sensitive_data(value)
            elif isinstance(value, list):
                sanitized[key] = [
                    AuditEventProcessor.sanitize_sensitive_data(item) 
                    if isinstance(item, dict) else item 
                    for item in value
                ]
            else:
                sanitized[key] = value
        
        return sanitized
    
    @staticmethod
    def generate_change_description(
        action_type: str,
        resource_type: str,
        change_summary: Dict[str, Any],
        custom_description: Optional[str] = None
    ) -> str:
        """
        Gera descrição automática da mudança
        """
        if custom_description:
            return custom_description
        
        if action_type == ActionType.CREATE:
            return f"{resource_type.title()} criado"
        
        elif action_type == ActionType.DELETE:
            return f"{resource_type.title()} removido"
        
        elif action_type == ActionType.UPDATE:
            total_changes = change_summary.get('total_changes', 0)
            if total_changes == 1:
                changed_field = change_summary.get('fields_changed', ['campo'])[0]
                return f"{resource_type.title()} atualizado: {changed_field} modificado"
            else:
                return f"{resource_type.title()} atualizado: {total_changes} campos modificados"
        
        elif action_type == ActionType.ACCESS:
            return f"{resource_type.title()} acessado"
        
        elif action_type == ActionType.APPROVE:
            return f"{resource_type.title()} aprovado"
        
        else:
            return f"Ação {action_type} executada em {resource_type}"


class AuditService(IAuditService):
    """
    Implementação do serviço de auditoria
    Implementa SRP: responsável apenas pela lógica de auditoria
    """
    
    def __init__(self):
        self._event_processor = AuditEventProcessor()
    
    async def log_action(
        self,
        user_id: UUID,
        contract_id: UUID,
        action_type: str,
        resource_type: str,
        resource_id: Optional[UUID],
        old_values: Optional[Dict[str, Any]],
        new_values: Optional[Dict[str, Any]],
        description: Optional[str],
        ip_address: Optional[str],
        user_agent: Optional[str],
        db: Session
    ) -> None:
        """
        Registra uma ação de auditoria
        Implementa logging estruturado e seguro
        """
        try:
            # Sanitizar dados sensíveis
            sanitized_old = self._event_processor.sanitize_sensitive_data(
                old_values or {}
            )
            sanitized_new = self._event_processor.sanitize_sensitive_data(
                new_values or {}
            )
            
            # Calcular resumo das mudanças
            change_summary = self._event_processor.calculate_change_summary(
                sanitized_old, sanitized_new
            )
            
            # Gerar descrição automática se não fornecida
            auto_description = self._event_processor.generate_change_description(
                action_type, resource_type, change_summary, description
            )
            
            # Criar log de auditoria
            audit_log = AuditLog(
                contract_id=contract_id,
                user_id=user_id,
                action_type=action_type,
                resource_type=resource_type,
                resource_id=resource_id,
                change_description=auto_description,
                old_values=json.dumps(sanitized_old, default=str) if sanitized_old else None,
                new_values=json.dumps(sanitized_new, default=str) if sanitized_new else None,
                change_summary=json.dumps(change_summary, default=str),
                ip_address=ip_address,
                user_agent=user_agent
            )
            
            db.add(audit_log)
            db.flush()  # Para obter o ID sem commit
            
            # Log estruturado para monitoramento
            logger.info(
                f"Audit log created: {audit_log._id}",
                extra={
                    'audit_log_id': str(audit_log._id),
                    'user_id': str(user_id),
                    'contract_id': str(contract_id),
                    'action_type': action_type,
                    'resource_type': resource_type,
                    'resource_id': str(resource_id) if resource_id else None,
                    'change_summary': change_summary
                }
            )
            
        except Exception as e:
            logger.error(f"Erro ao registrar log de auditoria: {e}")
            # Não propagar erro para não afetar operação principal
    
    async def get_audit_logs(
        self,
        contract_id: Optional[UUID],
        user_id: Optional[UUID],
        action_type: Optional[str],
        start_date: Optional[str],
        end_date: Optional[str],
        pagination: PaginationParams,
        db: Session
    ) -> Tuple[List[AuditLogResponse], int]:
        """
        Obtém logs de auditoria com filtros
        Implementa busca otimizada e paginação
        """
        try:
            query = db.query(AuditLog).options(
                joinedload(AuditLog.user),
                joinedload(AuditLog.contract)
            )
            
            # Aplicar filtros
            if contract_id:
                query = query.filter(AuditLog.contract_id == contract_id)
            
            if user_id:
                query = query.filter(AuditLog.user_id == user_id)
            
            if action_type:
                query = query.filter(AuditLog.action_type == action_type)
            
            if start_date:
                start_datetime = datetime.fromisoformat(start_date.replace('Z', '+00:00'))
                query = query.filter(AuditLog.created_at >= start_datetime)
            
            if end_date:
                end_datetime = datetime.fromisoformat(end_date.replace('Z', '+00:00'))
                query = query.filter(AuditLog.created_at <= end_datetime)
            
            # Contar total
            total = query.count()
            
            # Aplicar ordenação
            query = query.order_by(desc(AuditLog.created_at))
            
            # Aplicar paginação
            offset = (pagination.page - 1) * pagination.size
            audit_logs = query.offset(offset).limit(pagination.size).all()
            
            # Converter para response
            log_responses = []
            for log in audit_logs:
                response = await self._build_audit_log_response(log)
                log_responses.append(response)
            
            return log_responses, total
            
        except Exception as e:
            logger.error(f"Erro ao obter logs de auditoria: {e}")
            raise
    
    async def get_user_activity(
        self,
        user_id: UUID,
        days: int,
        db: Session
    ) -> Dict[str, Any]:
        """
        Obtém atividade de um usuário
        Implementa análise de atividade e padrões
        """
        try:
            # Calcular período
            start_date = datetime.utcnow() - timedelta(days=days)
            
            # Buscar logs do usuário
            logs = db.query(AuditLog).filter(
                and_(
                    AuditLog.user_id == user_id,
                    AuditLog.created_at >= start_date
                )
            ).all()
            
            # Analisar atividade
            activity_summary = {
                'user_id': user_id,
                'period_days': days,
                'total_actions': len(logs),
                'actions_by_type': {},
                'actions_by_day': {},
                'contracts_accessed': set(),
                'most_active_day': None,
                'last_activity': None,
                'activity_pattern': {}
            }
            
            # Processar logs
            for log in logs:
                # Contar por tipo de ação
                action_type = log.action_type
                activity_summary['actions_by_type'][action_type] = \
                    activity_summary['actions_by_type'].get(action_type, 0) + 1
                
                # Contar por dia
                day_key = log.created_at.strftime('%Y-%m-%d')
                activity_summary['actions_by_day'][day_key] = \
                    activity_summary['actions_by_day'].get(day_key, 0) + 1
                
                # Contratos acessados
                if log.contract_id:
                    activity_summary['contracts_accessed'].add(str(log.contract_id))
                
                # Última atividade
                if not activity_summary['last_activity'] or \
                   log.created_at > activity_summary['last_activity']:
                    activity_summary['last_activity'] = log.created_at
            
            # Converter set para list
            activity_summary['contracts_accessed'] = list(activity_summary['contracts_accessed'])
            activity_summary['unique_contracts'] = len(activity_summary['contracts_accessed'])
            
            # Encontrar dia mais ativo
            if activity_summary['actions_by_day']:
                most_active_day = max(
                    activity_summary['actions_by_day'].items(),
                    key=lambda x: x[1]
                )
                activity_summary['most_active_day'] = {
                    'date': most_active_day[0],
                    'actions': most_active_day[1]
                }
            
            # Calcular padrão de atividade
            activity_summary['activity_pattern'] = self._analyze_activity_pattern(logs)
            
            return activity_summary
            
        except Exception as e:
            logger.error(f"Erro ao obter atividade do usuário {user_id}: {e}")
            raise
    
    async def get_contract_audit_summary(
        self,
        contract_id: UUID,
        db: Session
    ) -> Dict[str, Any]:
        """
        Obtém resumo de auditoria de um contrato
        """
        try:
            # Buscar logs do contrato
            logs = db.query(AuditLog).filter(
                AuditLog.contract_id == contract_id
            ).order_by(desc(AuditLog.created_at)).all()
            
            if not logs:
                return {
                    'contract_id': contract_id,
                    'total_events': 0,
                    'message': 'Nenhum evento de auditoria encontrado'
                }
            
            # Analisar logs
            summary = {
                'contract_id': contract_id,
                'total_events': len(logs),
                'first_event': logs[-1].created_at,
                'last_event': logs[0].created_at,
                'events_by_type': {},
                'unique_users': set(),
                'timeline': [],
                'risk_indicators': []
            }
            
            # Processar eventos
            for log in logs:
                # Contar por tipo
                action_type = log.action_type
                summary['events_by_type'][action_type] = \
                    summary['events_by_type'].get(action_type, 0) + 1
                
                # Usuários únicos
                summary['unique_users'].add(str(log.user_id))
                
                # Timeline (últimos 10 eventos)
                if len(summary['timeline']) < 10:
                    summary['timeline'].append({
                        'timestamp': log.created_at,
                        'action': log.action_type,
                        'user_id': str(log.user_id),
                        'description': log.change_description
                    })
            
            # Converter set para list
            summary['unique_users'] = list(summary['unique_users'])
            summary['total_unique_users'] = len(summary['unique_users'])
            
            # Identificar indicadores de risco
            summary['risk_indicators'] = self._identify_risk_indicators(logs)
            
            return summary
            
        except Exception as e:
            logger.error(f"Erro ao obter resumo de auditoria do contrato {contract_id}: {e}")
            raise
    
    def _analyze_activity_pattern(self, logs: List[AuditLog]) -> Dict[str, Any]:
        """
        Analisa padrão de atividade do usuário
        Implementa SRP: responsável apenas pela análise de padrões
        """
        if not logs:
            return {}
        
        # Analisar horários de atividade
        hours_activity = {}
        days_of_week = {}
        
        for log in logs:
            hour = log.created_at.hour
            day_of_week = log.created_at.strftime('%A')
            
            hours_activity[hour] = hours_activity.get(hour, 0) + 1
            days_of_week[day_of_week] = days_of_week.get(day_of_week, 0) + 1
        
        # Encontrar padrões
        most_active_hour = max(hours_activity.items(), key=lambda x: x[1]) if hours_activity else None
        most_active_day = max(days_of_week.items(), key=lambda x: x[1]) if days_of_week else None
        
        return {
            'most_active_hour': most_active_hour[0] if most_active_hour else None,
            'most_active_day': most_active_day[0] if most_active_day else None,
            'hours_distribution': hours_activity,
            'days_distribution': days_of_week
        }
    
    def _identify_risk_indicators(self, logs: List[AuditLog]) -> List[Dict[str, Any]]:
        """
        Identifica indicadores de risco nos logs
        Implementa SRP: responsável apenas pela identificação de riscos
        """
        risk_indicators = []
        
        # Verificar atividade suspeita
        recent_logs = [log for log in logs if 
                      (datetime.utcnow() - log.created_at).days <= 1]
        
        if len(recent_logs) > 50:
            risk_indicators.append({
                'type': 'high_activity',
                'severity': 'medium',
                'description': f'Atividade alta detectada: {len(recent_logs)} eventos nas últimas 24h'
            })
        
        # Verificar múltiplas tentativas de acesso
        access_logs = [log for log in recent_logs if log.action_type == ActionType.ACCESS]
        if len(access_logs) > 20:
            risk_indicators.append({
                'type': 'multiple_access',
                'severity': 'low',
                'description': f'Múltiplos acessos detectados: {len(access_logs)} nas últimas 24h'
            })
        
        # Verificar atividade fora do horário comercial
        off_hours_logs = [log for log in recent_logs if 
                         log.created_at.hour < 8 or log.created_at.hour > 18]
        
        if len(off_hours_logs) > 10:
            risk_indicators.append({
                'type': 'off_hours_activity',
                'severity': 'medium',
                'description': f'Atividade fora do horário comercial: {len(off_hours_logs)} eventos'
            })
        
        return risk_indicators
    
    async def _build_audit_log_response(self, log: AuditLog) -> AuditLogResponse:
        """
        Constrói response do log de auditoria
        Implementa SRP: responsável apenas pela construção da resposta
        """
        log_dict = {
            '_id': log._id,
            'contract_id': log.contract_id,
            'user_id': log.user_id,
            'action_type': log.action_type,
            'resource_type': log.resource_type,
            'resource_id': log.resource_id,
            'change_description': log.change_description,
            'ip_address': log.ip_address,
            'user_agent': log.user_agent,
            'created_at': log.created_at,
            'updated_at': log.updated_at
        }
        
        return AuditLogResponse(**log_dict)

