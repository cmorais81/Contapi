"""
Serviço de versionamento de contratos
Implementa versionamento semântico e princípios SOLID
"""

from typing import List, Optional, Dict, Any, Tuple
from uuid import UUID
from sqlalchemy.orm import Session, joinedload
from sqlalchemy import desc, and_
from datetime import datetime
import re
import logging

from .interfaces import IContractVersionService, IAuditService
from ..models import DataContract, ContractVersion, User
from ..schemas import (
    ContractVersionCreate, ContractVersionResponse,
    VersionType
)
from ..utils.exceptions import (
    EntityNotFoundError, ValidationError, 
    BusinessRuleViolationError
)

logger = logging.getLogger(__name__)


class SemanticVersionManager:
    """
    Gerenciador de versionamento semântico
    Implementa SRP: responsável apenas pela lógica de versionamento
    """
    
    @staticmethod
    def parse_version(version: str) -> Tuple[int, int, int]:
        """
        Parseia versão semântica
        Retorna tupla (major, minor, patch)
        """
        pattern = r'^(\d+)\.(\d+)\.(\d+)$'
        match = re.match(pattern, version)
        
        if not match:
            raise ValidationError(f"Versão '{version}' não segue padrão semântico (x.y.z)")
        
        return int(match.group(1)), int(match.group(2)), int(match.group(3))
    
    @staticmethod
    def compare_versions(version1: str, version2: str) -> int:
        """
        Compara duas versões
        Retorna: -1 se v1 < v2, 0 se v1 == v2, 1 se v1 > v2
        """
        v1_parts = SemanticVersionManager.parse_version(version1)
        v2_parts = SemanticVersionManager.parse_version(version2)
        
        for i in range(3):
            if v1_parts[i] < v2_parts[i]:
                return -1
            elif v1_parts[i] > v2_parts[i]:
                return 1
        
        return 0
    
    @staticmethod
    def get_next_version(current_version: str, version_type: VersionType) -> str:
        """
        Calcula próxima versão baseada no tipo
        """
        major, minor, patch = SemanticVersionManager.parse_version(current_version)
        
        if version_type == VersionType.MAJOR:
            return f"{major + 1}.0.0"
        elif version_type == VersionType.MINOR:
            return f"{major}.{minor + 1}.0"
        elif version_type == VersionType.PATCH:
            return f"{major}.{minor}.{patch + 1}"
        else:
            raise ValidationError(f"Tipo de versão inválido: {version_type}")
    
    @staticmethod
    def is_breaking_change(old_version: str, new_version: str) -> bool:
        """
        Determina se mudança de versão é breaking change
        """
        old_major, _, _ = SemanticVersionManager.parse_version(old_version)
        new_major, _, _ = SemanticVersionManager.parse_version(new_version)
        
        return new_major > old_major


class ContractVersionService(IContractVersionService):
    """
    Implementação do serviço de versionamento de contratos
    Implementa SRP: responsável apenas pela lógica de versões
    Implementa DIP: depende de abstrações (interfaces)
    """
    
    def __init__(self, audit_service: IAuditService):
        self._audit_service = audit_service
        self._version_manager = SemanticVersionManager()
    
    async def create_version(
        self,
        version_data: ContractVersionCreate,
        user_id: UUID,
        db: Session
    ) -> ContractVersionResponse:
        """
        Cria uma nova versão de contrato
        Implementa validações de versionamento semântico
        """
        try:
            # Validar contrato existe
            contract = db.query(DataContract).filter(
                DataContract._id == version_data.contract_id
            ).first()
            
            if not contract:
                raise EntityNotFoundError(f"Contrato {version_data.contract_id} não encontrado")
            
            # Validar usuário
            user = db.query(User).filter(User._id == user_id).first()
            if not user:
                raise EntityNotFoundError(f"Usuário {user_id} não encontrado")
            
            # Obter versão atual do contrato
            current_version = contract.contract_version
            
            # Validar sequência de versionamento
            await self._validate_version_sequence(
                version_data.contract_id,
                version_data.version_number,
                db
            )
            
            # Determinar se é breaking change
            is_breaking = self._version_manager.is_breaking_change(
                current_version,
                version_data.version_number
            )
            
            # Criar versão
            version_dict = version_data.dict()
            version_dict.update({
                'created_by_user_id': user_id,
                'is_breaking_change': is_breaking or version_data.is_breaking_change
            })
            
            version = ContractVersion(**version_dict)
            db.add(version)
            db.flush()
            
            # Atualizar contrato com nova versão
            contract.contract_version = version_data.version_number
            contract.previous_version_id = self._get_latest_version_id(
                version_data.contract_id, db
            )
            contract.updated_by_user_id = user_id
            contract.updated_at = datetime.utcnow()
            
            db.commit()
            
            # Log de auditoria
            await self._audit_service.log_action(
                user_id=user_id,
                contract_id=version_data.contract_id,
                action_type="CREATE",
                resource_type="contract_version",
                resource_id=version._id,
                old_values={'version': current_version},
                new_values={'version': version_data.version_number},
                description=f"Nova versão {version_data.version_number} criada",
                ip_address=None,
                user_agent=None,
                db=db
            )
            
            logger.info(f"Versão {version._id} criada para contrato {version_data.contract_id}")
            
            return await self._build_version_response(version, db)
            
        except Exception as e:
            db.rollback()
            logger.error(f"Erro ao criar versão: {e}")
            raise
    
    async def get_version(
        self,
        version_id: UUID,
        db: Session
    ) -> Optional[ContractVersionResponse]:
        """
        Obtém uma versão específica
        """
        try:
            version = db.query(ContractVersion).options(
                joinedload(ContractVersion.created_by)
            ).filter(ContractVersion._id == version_id).first()
            
            if not version:
                return None
            
            return await self._build_version_response(version, db)
            
        except Exception as e:
            logger.error(f"Erro ao obter versão {version_id}: {e}")
            raise
    
    async def get_latest_version(
        self,
        contract_id: UUID,
        db: Session
    ) -> Optional[ContractVersionResponse]:
        """
        Obtém a versão mais recente de um contrato
        """
        try:
            version = db.query(ContractVersion).options(
                joinedload(ContractVersion.created_by)
            ).filter(
                ContractVersion.contract_id == contract_id
            ).order_by(desc(ContractVersion.created_at)).first()
            
            if not version:
                return None
            
            return await self._build_version_response(version, db)
            
        except Exception as e:
            logger.error(f"Erro ao obter versão mais recente do contrato {contract_id}: {e}")
            raise
    
    async def compare_versions(
        self,
        version1_id: UUID,
        version2_id: UUID,
        db: Session
    ) -> Dict[str, Any]:
        """
        Compara duas versões de contrato
        Implementa análise detalhada de diferenças
        """
        try:
            # Obter versões
            version1 = db.query(ContractVersion).filter(
                ContractVersion._id == version1_id
            ).first()
            
            version2 = db.query(ContractVersion).filter(
                ContractVersion._id == version2_id
            ).first()
            
            if not version1:
                raise EntityNotFoundError(f"Versão {version1_id} não encontrada")
            
            if not version2:
                raise EntityNotFoundError(f"Versão {version2_id} não encontrada")
            
            # Validar que são do mesmo contrato
            if version1.contract_id != version2.contract_id:
                raise BusinessRuleViolationError("Versões devem ser do mesmo contrato")
            
            # Comparar versões
            comparison_result = self._version_manager.compare_versions(
                version1.version_number,
                version2.version_number
            )
            
            # Analisar diferenças
            differences = self._analyze_version_differences(version1, version2)
            
            return {
                "version1": {
                    "id": version1._id,
                    "version_number": version1.version_number,
                    "created_at": version1.created_at
                },
                "version2": {
                    "id": version2._id,
                    "version_number": version2.version_number,
                    "created_at": version2.created_at
                },
                "comparison_result": comparison_result,
                "newer_version": version1._id if comparison_result > 0 else version2._id,
                "differences": differences,
                "breaking_changes": version1.is_breaking_change or version2.is_breaking_change
            }
            
        except Exception as e:
            logger.error(f"Erro ao comparar versões {version1_id} e {version2_id}: {e}")
            raise
    
    async def get_version_history(
        self,
        contract_id: UUID,
        db: Session
    ) -> List[ContractVersionResponse]:
        """
        Obtém histórico completo de versões de um contrato
        """
        try:
            versions = db.query(ContractVersion).options(
                joinedload(ContractVersion.created_by)
            ).filter(
                ContractVersion.contract_id == contract_id
            ).order_by(desc(ContractVersion.created_at)).all()
            
            version_responses = []
            for version in versions:
                response = await self._build_version_response(version, db)
                version_responses.append(response)
            
            return version_responses
            
        except Exception as e:
            logger.error(f"Erro ao obter histórico de versões do contrato {contract_id}: {e}")
            raise
    
    async def rollback_to_version(
        self,
        contract_id: UUID,
        target_version_id: UUID,
        user_id: UUID,
        db: Session
    ) -> ContractVersionResponse:
        """
        Faz rollback para uma versão específica
        Implementa rollback seguro com nova versão
        """
        try:
            # Validar contrato
            contract = db.query(DataContract).filter(
                DataContract._id == contract_id
            ).first()
            
            if not contract:
                raise EntityNotFoundError(f"Contrato {contract_id} não encontrado")
            
            # Validar versão alvo
            target_version = db.query(ContractVersion).filter(
                and_(
                    ContractVersion._id == target_version_id,
                    ContractVersion.contract_id == contract_id
                )
            ).first()
            
            if not target_version:
                raise EntityNotFoundError(f"Versão {target_version_id} não encontrada")
            
            # Calcular nova versão (patch increment)
            current_version = contract.contract_version
            new_version = self._version_manager.get_next_version(
                current_version, VersionType.PATCH
            )
            
            # Criar nova versão baseada na versão alvo
            rollback_version_data = ContractVersionCreate(
                contract_id=contract_id,
                version_number=new_version,
                version_type=VersionType.PATCH,
                changelog=f"Rollback para versão {target_version.version_number}",
                is_breaking_change=False,
                migration_script=target_version.migration_script
            )
            
            # Criar versão de rollback
            rollback_version = await self.create_version(
                rollback_version_data, user_id, db
            )
            
            logger.info(f"Rollback executado: contrato {contract_id} para versão {target_version.version_number}")
            
            return rollback_version
            
        except Exception as e:
            logger.error(f"Erro ao fazer rollback: {e}")
            raise
    
    async def _validate_version_sequence(
        self,
        contract_id: UUID,
        new_version: str,
        db: Session
    ) -> None:
        """
        Valida sequência de versionamento
        Implementa SRP: responsável apenas pela validação de sequência
        """
        # Obter versão atual do contrato
        contract = db.query(DataContract).filter(
            DataContract._id == contract_id
        ).first()
        
        if not contract:
            return
        
        current_version = contract.contract_version
        
        # Validar que nova versão é maior que atual
        comparison = self._version_manager.compare_versions(new_version, current_version)
        if comparison <= 0:
            raise ValidationError(
                f"Nova versão {new_version} deve ser maior que versão atual {current_version}"
            )
        
        # Verificar se versão já existe
        existing_version = db.query(ContractVersion).filter(
            and_(
                ContractVersion.contract_id == contract_id,
                ContractVersion.version_number == new_version
            )
        ).first()
        
        if existing_version:
            raise BusinessRuleViolationError(f"Versão {new_version} já existe para este contrato")
    
    def _get_latest_version_id(self, contract_id: UUID, db: Session) -> Optional[UUID]:
        """Obtém ID da versão mais recente"""
        latest_version = db.query(ContractVersion).filter(
            ContractVersion.contract_id == contract_id
        ).order_by(desc(ContractVersion.created_at)).first()
        
        return latest_version._id if latest_version else None
    
    def _analyze_version_differences(
        self, 
        version1: ContractVersion, 
        version2: ContractVersion
    ) -> Dict[str, Any]:
        """
        Analisa diferenças entre duas versões
        Implementa SRP: responsável apenas pela análise de diferenças
        """
        differences = {
            "version_type_changed": version1.version_type != version2.version_type,
            "changelog_changed": version1.changelog != version2.changelog,
            "breaking_change_status": {
                "version1": version1.is_breaking_change,
                "version2": version2.is_breaking_change
            },
            "migration_script_changed": version1.migration_script != version2.migration_script,
            "creation_time_diff": abs((version2.created_at - version1.created_at).total_seconds())
        }
        
        return differences
    
    async def _build_version_response(
        self, 
        version: ContractVersion, 
        db: Session
    ) -> ContractVersionResponse:
        """
        Constrói response da versão
        Implementa SRP: responsável apenas pela construção da resposta
        """
        version_dict = {
            '_id': version._id,
            'contract_id': version.contract_id,
            'version_number': version.version_number,
            'version_type': version.version_type,
            'changelog': version.changelog,
            'is_breaking_change': version.is_breaking_change,
            'migration_script': version.migration_script,
            'created_at': version.created_at,
            'updated_at': version.updated_at,
            'created_by': self._build_user_reference(version.created_by) if version.created_by else None
        }
        
        return ContractVersionResponse(**version_dict)
    
    def _build_user_reference(self, user: User) -> Dict[str, Any]:
        """Constrói referência de usuário"""
        return {
            '_id': user._id,
            'username': user.username,
            'full_name': user.full_name,
            'email': user.email
        }

