"""
Interfaces para services da Data Governance API
Implementa princípios SOLID - Interface Segregation e Dependency Inversion
"""

from abc import ABC, abstractmethod
from typing import List, Optional, Dict, Any, Tuple
from uuid import UUID
from sqlalchemy.orm import Session

from ..schemas import (
    DataContractCreate, DataContractUpdate, DataContractResponse,
    ContractVersionCreate, ContractVersionResponse,
    UserCreate, UserResponse,
    AccessPolicyCreate, AccessPolicyResponse,
    ComplianceFrameworkCreate, ComplianceFrameworkResponse,
    AuditLogResponse, ContractFilters, PaginationParams
)


class IDataContractService(ABC):
    """
    Interface para serviço de contratos de dados
    Implementa ISP: Interface específica para contratos
    """
    
    @abstractmethod
    async def create_contract(
        self, 
        contract_data: DataContractCreate, 
        user_id: UUID,
        db: Session
    ) -> DataContractResponse:
        """Cria um novo contrato de dados"""
        pass
    
    @abstractmethod
    async def get_contract(
        self, 
        contract_id: UUID, 
        db: Session
    ) -> Optional[DataContractResponse]:
        """Obtém um contrato por ID"""
        pass
    
    @abstractmethod
    async def get_contracts(
        self,
        filters: ContractFilters,
        pagination: PaginationParams,
        db: Session
    ) -> Tuple[List[DataContractResponse], int]:
        """Lista contratos com filtros e paginação"""
        pass
    
    @abstractmethod
    async def update_contract(
        self,
        contract_id: UUID,
        contract_data: DataContractUpdate,
        user_id: UUID,
        db: Session
    ) -> Optional[DataContractResponse]:
        """Atualiza um contrato existente"""
        pass
    
    @abstractmethod
    async def delete_contract(
        self,
        contract_id: UUID,
        user_id: UUID,
        db: Session
    ) -> bool:
        """Remove um contrato (soft delete)"""
        pass
    
    @abstractmethod
    async def approve_contract(
        self,
        contract_id: UUID,
        user_id: UUID,
        db: Session
    ) -> Optional[DataContractResponse]:
        """Aprova um contrato"""
        pass
    
    @abstractmethod
    async def get_contract_versions(
        self,
        contract_id: UUID,
        db: Session
    ) -> List[ContractVersionResponse]:
        """Obtém todas as versões de um contrato"""
        pass


class IContractVersionService(ABC):
    """
    Interface para serviço de versionamento de contratos
    Implementa ISP: Interface específica para versionamento
    """
    
    @abstractmethod
    async def create_version(
        self,
        version_data: ContractVersionCreate,
        user_id: UUID,
        db: Session
    ) -> ContractVersionResponse:
        """Cria uma nova versão de contrato"""
        pass
    
    @abstractmethod
    async def get_version(
        self,
        version_id: UUID,
        db: Session
    ) -> Optional[ContractVersionResponse]:
        """Obtém uma versão específica"""
        pass
    
    @abstractmethod
    async def get_latest_version(
        self,
        contract_id: UUID,
        db: Session
    ) -> Optional[ContractVersionResponse]:
        """Obtém a versão mais recente de um contrato"""
        pass
    
    @abstractmethod
    async def compare_versions(
        self,
        version1_id: UUID,
        version2_id: UUID,
        db: Session
    ) -> Dict[str, Any]:
        """Compara duas versões de contrato"""
        pass


class IUserService(ABC):
    """
    Interface para serviço de usuários
    Implementa ISP: Interface específica para usuários
    """
    
    @abstractmethod
    async def create_user(
        self,
        user_data: UserCreate,
        db: Session
    ) -> UserResponse:
        """Cria um novo usuário"""
        pass
    
    @abstractmethod
    async def get_user(
        self,
        user_id: UUID,
        db: Session
    ) -> Optional[UserResponse]:
        """Obtém um usuário por ID"""
        pass
    
    @abstractmethod
    async def get_user_by_email(
        self,
        email: str,
        db: Session
    ) -> Optional[UserResponse]:
        """Obtém um usuário por email"""
        pass
    
    @abstractmethod
    async def authenticate_user(
        self,
        email: str,
        password: str,
        db: Session
    ) -> Optional[UserResponse]:
        """Autentica um usuário"""
        pass
    
    @abstractmethod
    async def update_last_login(
        self,
        user_id: UUID,
        db: Session
    ) -> None:
        """Atualiza último login do usuário"""
        pass


class IAccessPolicyService(ABC):
    """
    Interface para serviço de políticas de acesso
    Implementa ISP: Interface específica para políticas de acesso
    """
    
    @abstractmethod
    async def create_policy(
        self,
        policy_data: AccessPolicyCreate,
        user_id: UUID,
        db: Session
    ) -> AccessPolicyResponse:
        """Cria uma nova política de acesso"""
        pass
    
    @abstractmethod
    async def get_policy(
        self,
        policy_id: UUID,
        db: Session
    ) -> Optional[AccessPolicyResponse]:
        """Obtém uma política por ID"""
        pass
    
    @abstractmethod
    async def get_policies_by_contract(
        self,
        contract_id: UUID,
        db: Session
    ) -> List[AccessPolicyResponse]:
        """Obtém políticas de um contrato"""
        pass
    
    @abstractmethod
    async def get_policies_by_user(
        self,
        user_id: UUID,
        db: Session
    ) -> List[AccessPolicyResponse]:
        """Obtém políticas aplicáveis a um usuário"""
        pass
    
    @abstractmethod
    async def evaluate_access(
        self,
        user_id: UUID,
        contract_id: UUID,
        action: str,
        db: Session
    ) -> Dict[str, Any]:
        """Avalia se um usuário tem acesso a um contrato"""
        pass


class IComplianceService(ABC):
    """
    Interface para serviço de compliance
    Implementa ISP: Interface específica para compliance
    """
    
    @abstractmethod
    async def create_framework(
        self,
        framework_data: ComplianceFrameworkCreate,
        db: Session
    ) -> ComplianceFrameworkResponse:
        """Cria um novo framework de compliance"""
        pass
    
    @abstractmethod
    async def get_framework(
        self,
        framework_id: UUID,
        db: Session
    ) -> Optional[ComplianceFrameworkResponse]:
        """Obtém um framework por ID"""
        pass
    
    @abstractmethod
    async def get_frameworks_by_country(
        self,
        country_code: str,
        db: Session
    ) -> List[ComplianceFrameworkResponse]:
        """Obtém frameworks aplicáveis a um país"""
        pass
    
    @abstractmethod
    async def validate_contract_compliance(
        self,
        contract_id: UUID,
        db: Session
    ) -> Dict[str, Any]:
        """Valida compliance de um contrato"""
        pass
    
    @abstractmethod
    async def generate_compliance_report(
        self,
        contract_id: UUID,
        framework_id: UUID,
        db: Session
    ) -> Dict[str, Any]:
        """Gera relatório de compliance"""
        pass


class IAuditService(ABC):
    """
    Interface para serviço de auditoria
    Implementa ISP: Interface específica para auditoria
    """
    
    @abstractmethod
    async def log_action(
        self,
        user_id: UUID,
        contract_id: UUID,
        action_type: str,
        resource_type: str,
        resource_id: Optional[UUID],
        old_values: Optional[Dict[str, Any]],
        new_values: Optional[Dict[str, Any]],
        description: Optional[str],
        ip_address: Optional[str],
        user_agent: Optional[str],
        db: Session
    ) -> None:
        """Registra uma ação de auditoria"""
        pass
    
    @abstractmethod
    async def get_audit_logs(
        self,
        contract_id: Optional[UUID],
        user_id: Optional[UUID],
        action_type: Optional[str],
        start_date: Optional[str],
        end_date: Optional[str],
        pagination: PaginationParams,
        db: Session
    ) -> Tuple[List[AuditLogResponse], int]:
        """Obtém logs de auditoria com filtros"""
        pass
    
    @abstractmethod
    async def get_user_activity(
        self,
        user_id: UUID,
        days: int,
        db: Session
    ) -> Dict[str, Any]:
        """Obtém atividade de um usuário"""
        pass


class INotificationService(ABC):
    """
    Interface para serviço de notificações
    Implementa ISP: Interface específica para notificações
    """
    
    @abstractmethod
    async def send_contract_approval_notification(
        self,
        contract_id: UUID,
        approver_id: UUID,
        db: Session
    ) -> None:
        """Envia notificação de aprovação de contrato"""
        pass
    
    @abstractmethod
    async def send_contract_expiration_notification(
        self,
        contract_id: UUID,
        days_until_expiration: int,
        db: Session
    ) -> None:
        """Envia notificação de expiração de contrato"""
        pass
    
    @abstractmethod
    async def send_compliance_violation_notification(
        self,
        contract_id: UUID,
        violation_details: Dict[str, Any],
        db: Session
    ) -> None:
        """Envia notificação de violação de compliance"""
        pass


class IMetricsService(ABC):
    """
    Interface para serviço de métricas
    Implementa ISP: Interface específica para métricas
    """
    
    @abstractmethod
    async def get_contract_metrics(
        self,
        contract_id: UUID,
        period: str,
        db: Session
    ) -> Dict[str, Any]:
        """Obtém métricas de um contrato"""
        pass
    
    @abstractmethod
    async def get_usage_metrics(
        self,
        start_date: str,
        end_date: str,
        db: Session
    ) -> Dict[str, Any]:
        """Obtém métricas de uso da API"""
        pass
    
    @abstractmethod
    async def get_compliance_metrics(
        self,
        country_code: Optional[str],
        framework_id: Optional[UUID],
        db: Session
    ) -> Dict[str, Any]:
        """Obtém métricas de compliance"""
        pass


class ISearchService(ABC):
    """
    Interface para serviço de busca
    Implementa ISP: Interface específica para busca
    """
    
    @abstractmethod
    async def search_contracts(
        self,
        query: str,
        filters: Optional[Dict[str, Any]],
        pagination: PaginationParams,
        db: Session
    ) -> Tuple[List[DataContractResponse], int]:
        """Busca contratos por texto"""
        pass
    
    @abstractmethod
    async def get_search_suggestions(
        self,
        query: str,
        db: Session
    ) -> List[str]:
        """Obtém sugestões de busca"""
        pass
    
    @abstractmethod
    async def index_contract(
        self,
        contract_id: UUID,
        db: Session
    ) -> None:
        """Indexa um contrato para busca"""
        pass


class IValidationService(ABC):
    """
    Interface para serviço de validação
    Implementa ISP: Interface específica para validação
    """
    
    @abstractmethod
    async def validate_contract_name_uniqueness(
        self,
        contract_name: str,
        version: str,
        exclude_id: Optional[UUID],
        db: Session
    ) -> bool:
        """Valida unicidade do nome e versão do contrato"""
        pass
    
    @abstractmethod
    async def validate_version_sequence(
        self,
        contract_id: UUID,
        new_version: str,
        db: Session
    ) -> bool:
        """Valida sequência de versionamento"""
        pass
    
    @abstractmethod
    async def validate_breaking_changes(
        self,
        contract_id: UUID,
        new_data: Dict[str, Any],
        db: Session
    ) -> Dict[str, Any]:
        """Valida se há breaking changes"""
        pass
    
    @abstractmethod
    async def validate_compliance_requirements(
        self,
        contract_data: Dict[str, Any],
        framework_ids: List[UUID],
        db: Session
    ) -> Dict[str, Any]:
        """Valida requisitos de compliance"""
        pass

