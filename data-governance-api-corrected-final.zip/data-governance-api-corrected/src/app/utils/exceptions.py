"""
Sistema de exceções customizadas para Data Governance API
Implementa hierarquia estruturada e princípios SOLID
"""

from typing import Optional, Dict, Any
import uuid
from datetime import datetime


class BaseDataGovernanceException(Exception):
    """
    Exceção base para todas as exceções da aplicação
    Implementa SRP: responsável apenas pela estrutura base de exceções
    """
    
    def __init__(
        self,
        message: str,
        error_code: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
        context: Optional[Dict[str, Any]] = None
    ):
        self.message = message
        self.error_code = error_code or self.__class__.__name__
        self.details = details or {}
        self.context = context or {}
        self.error_id = str(uuid.uuid4())
        self.timestamp = datetime.utcnow()
        
        super().__init__(self.message)
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte exceção para dicionário"""
        return {
            'error_id': self.error_id,
            'error_code': self.error_code,
            'message': self.message,
            'details': self.details,
            'context': self.context,
            'timestamp': self.timestamp.isoformat()
        }
    
    def __str__(self) -> str:
        return f"{self.error_code}: {self.message} (ID: {self.error_id})"


class ValidationError(BaseDataGovernanceException):
    """
    Exceção para erros de validação de dados
    Implementa SRP: responsável apenas por erros de validação
    """
    
    def __init__(
        self,
        message: str,
        field: Optional[str] = None,
        value: Optional[Any] = None,
        validation_rule: Optional[str] = None,
        **kwargs
    ):
        details = {
            'field': field,
            'value': value,
            'validation_rule': validation_rule
        }
        details.update(kwargs.get('details', {}))
        
        super().__init__(
            message=message,
            error_code='VALIDATION_ERROR',
            details=details,
            context=kwargs.get('context')
        )


class EntityNotFoundError(BaseDataGovernanceException):
    """
    Exceção para entidades não encontradas
    Implementa SRP: responsável apenas por erros de entidade não encontrada
    """
    
    def __init__(
        self,
        message: str,
        entity_type: Optional[str] = None,
        entity_id: Optional[str] = None,
        **kwargs
    ):
        details = {
            'entity_type': entity_type,
            'entity_id': entity_id
        }
        details.update(kwargs.get('details', {}))
        
        super().__init__(
            message=message,
            error_code='ENTITY_NOT_FOUND',
            details=details,
            context=kwargs.get('context')
        )


class EntityAlreadyExistsError(BaseDataGovernanceException):
    """
    Exceção para entidades que já existem
    Implementa SRP: responsável apenas por erros de duplicação
    """
    
    def __init__(
        self,
        message: str,
        entity_type: Optional[str] = None,
        conflicting_fields: Optional[Dict[str, Any]] = None,
        **kwargs
    ):
        details = {
            'entity_type': entity_type,
            'conflicting_fields': conflicting_fields
        }
        details.update(kwargs.get('details', {}))
        
        super().__init__(
            message=message,
            error_code='ENTITY_ALREADY_EXISTS',
            details=details,
            context=kwargs.get('context')
        )


class BusinessRuleViolationError(BaseDataGovernanceException):
    """
    Exceção para violações de regras de negócio
    Implementa SRP: responsável apenas por erros de regras de negócio
    """
    
    def __init__(
        self,
        message: str,
        rule_name: Optional[str] = None,
        rule_description: Optional[str] = None,
        **kwargs
    ):
        details = {
            'rule_name': rule_name,
            'rule_description': rule_description
        }
        details.update(kwargs.get('details', {}))
        
        super().__init__(
            message=message,
            error_code='BUSINESS_RULE_VIOLATION',
            details=details,
            context=kwargs.get('context')
        )


class AuthenticationError(BaseDataGovernanceException):
    """
    Exceção para erros de autenticação
    Implementa SRP: responsável apenas por erros de autenticação
    """
    
    def __init__(
        self,
        message: str = "Falha na autenticação",
        auth_method: Optional[str] = None,
        **kwargs
    ):
        details = {
            'auth_method': auth_method
        }
        details.update(kwargs.get('details', {}))
        
        super().__init__(
            message=message,
            error_code='AUTHENTICATION_ERROR',
            details=details,
            context=kwargs.get('context')
        )


class AuthorizationError(BaseDataGovernanceException):
    """
    Exceção para erros de autorização
    Implementa SRP: responsável apenas por erros de autorização
    """
    
    def __init__(
        self,
        message: str = "Acesso negado",
        required_permission: Optional[str] = None,
        user_permissions: Optional[list] = None,
        **kwargs
    ):
        details = {
            'required_permission': required_permission,
            'user_permissions': user_permissions
        }
        details.update(kwargs.get('details', {}))
        
        super().__init__(
            message=message,
            error_code='AUTHORIZATION_ERROR',
            details=details,
            context=kwargs.get('context')
        )


class DatabaseError(BaseDataGovernanceException):
    """
    Exceção para erros de banco de dados
    Implementa SRP: responsável apenas por erros de banco
    """
    
    def __init__(
        self,
        message: str,
        operation: Optional[str] = None,
        table: Optional[str] = None,
        original_error: Optional[str] = None,
        **kwargs
    ):
        details = {
            'operation': operation,
            'table': table,
            'original_error': original_error
        }
        details.update(kwargs.get('details', {}))
        
        super().__init__(
            message=message,
            error_code='DATABASE_ERROR',
            details=details,
            context=kwargs.get('context')
        )


class ExternalServiceError(BaseDataGovernanceException):
    """
    Exceção para erros de serviços externos
    Implementa SRP: responsável apenas por erros de serviços externos
    """
    
    def __init__(
        self,
        message: str,
        service_name: Optional[str] = None,
        service_url: Optional[str] = None,
        status_code: Optional[int] = None,
        **kwargs
    ):
        details = {
            'service_name': service_name,
            'service_url': service_url,
            'status_code': status_code
        }
        details.update(kwargs.get('details', {}))
        
        super().__init__(
            message=message,
            error_code='EXTERNAL_SERVICE_ERROR',
            details=details,
            context=kwargs.get('context')
        )


class ConfigurationError(BaseDataGovernanceException):
    """
    Exceção para erros de configuração
    Implementa SRP: responsável apenas por erros de configuração
    """
    
    def __init__(
        self,
        message: str,
        config_key: Optional[str] = None,
        config_value: Optional[str] = None,
        **kwargs
    ):
        details = {
            'config_key': config_key,
            'config_value': config_value
        }
        details.update(kwargs.get('details', {}))
        
        super().__init__(
            message=message,
            error_code='CONFIGURATION_ERROR',
            details=details,
            context=kwargs.get('context')
        )


class ComplianceViolationError(BaseDataGovernanceException):
    """
    Exceção para violações de compliance
    Implementa SRP: responsável apenas por erros de compliance
    """
    
    def __init__(
        self,
        message: str,
        framework: Optional[str] = None,
        violation_type: Optional[str] = None,
        severity: Optional[str] = None,
        **kwargs
    ):
        details = {
            'framework': framework,
            'violation_type': violation_type,
            'severity': severity
        }
        details.update(kwargs.get('details', {}))
        
        super().__init__(
            message=message,
            error_code='COMPLIANCE_VIOLATION',
            details=details,
            context=kwargs.get('context')
        )


class RateLimitExceededError(BaseDataGovernanceException):
    """
    Exceção para limite de taxa excedido
    Implementa SRP: responsável apenas por erros de rate limiting
    """
    
    def __init__(
        self,
        message: str = "Limite de requisições excedido",
        limit: Optional[int] = None,
        window: Optional[str] = None,
        retry_after: Optional[int] = None,
        **kwargs
    ):
        details = {
            'limit': limit,
            'window': window,
            'retry_after': retry_after
        }
        details.update(kwargs.get('details', {}))
        
        super().__init__(
            message=message,
            error_code='RATE_LIMIT_EXCEEDED',
            details=details,
            context=kwargs.get('context')
        )


class CircuitBreakerOpenError(BaseDataGovernanceException):
    """
    Exceção para circuit breaker aberto
    Implementa SRP: responsável apenas por erros de circuit breaker
    """
    
    def __init__(
        self,
        message: str = "Serviço temporariamente indisponível",
        service_name: Optional[str] = None,
        failure_count: Optional[int] = None,
        **kwargs
    ):
        details = {
            'service_name': service_name,
            'failure_count': failure_count
        }
        details.update(kwargs.get('details', {}))
        
        super().__init__(
            message=message,
            error_code='CIRCUIT_BREAKER_OPEN',
            details=details,
            context=kwargs.get('context')
        )


# Mapeamento de exceções para códigos HTTP
HTTP_STATUS_MAP = {
    ValidationError: 422,
    EntityNotFoundError: 404,
    EntityAlreadyExistsError: 409,
    BusinessRuleViolationError: 409,
    AuthenticationError: 401,
    AuthorizationError: 403,
    DatabaseError: 500,
    ExternalServiceError: 502,
    ConfigurationError: 500,
    ComplianceViolationError: 409,
    RateLimitExceededError: 429,
    CircuitBreakerOpenError: 503,
    BaseDataGovernanceException: 500
}


def get_http_status_code(exception: BaseDataGovernanceException) -> int:
    """
    Obtém código HTTP apropriado para uma exceção
    Implementa SRP: responsável apenas pelo mapeamento de códigos
    """
    return HTTP_STATUS_MAP.get(type(exception), 500)


def create_error_context(
    request_id: Optional[str] = None,
    user_id: Optional[str] = None,
    endpoint: Optional[str] = None,
    method: Optional[str] = None,
    ip_address: Optional[str] = None
) -> Dict[str, Any]:
    """
    Cria contexto padrão para exceções
    Implementa Factory Pattern para criação de contexto
    """
    return {
        'request_id': request_id,
        'user_id': user_id,
        'endpoint': endpoint,
        'method': method,
        'ip_address': ip_address,
        'timestamp': datetime.utcnow().isoformat()
    }

