"""
Handler de erros para Data Governance API
Implementa tratamento centralizado e princípios SOLID
"""

from fastapi import HTTPException, Request
from fastapi.responses import JSONResponse
from typing import Dict, Any, Optional
import logging
import traceback

from .exceptions import (
    BaseDataGovernanceException, get_http_status_code,
    ValidationError, EntityNotFoundError, AuthenticationError
)

logger = logging.getLogger(__name__)


class ErrorHandler:
    """
    Handler centralizado de erros
    Implementa SRP: responsável apenas pelo tratamento de erros
    """
    
    @staticmethod
    def handle_api_error(
        error: Exception,
        default_message: str = "Erro interno do servidor",
        request_id: Optional[str] = None
    ) -> JSONResponse:
        """
        Trata erros da API de forma centralizada
        Implementa Strategy Pattern para diferentes tipos de erro
        """
        if isinstance(error, BaseDataGovernanceException):
            return ErrorHandler._handle_custom_exception(error)
        elif isinstance(error, HTTPException):
            return ErrorHandler._handle_http_exception(error)
        else:
            return ErrorHandler._handle_generic_exception(error, default_message, request_id)
    
    @staticmethod
    def _handle_custom_exception(error: BaseDataGovernanceException) -> JSONResponse:
        """Trata exceções customizadas da aplicação"""
        status_code = get_http_status_code(error)
        
        response_data = {
            "error": error.error_code,
            "message": error.message,
            "error_id": error.error_id,
            "timestamp": error.timestamp.isoformat(),
            "details": error.details
        }
        
        # Log baseado na severidade
        if status_code >= 500:
            logger.error(f"Server error: {error}", extra=error.to_dict())
        elif status_code >= 400:
            logger.warning(f"Client error: {error}", extra=error.to_dict())
        else:
            logger.info(f"Handled error: {error}", extra=error.to_dict())
        
        return JSONResponse(
            status_code=status_code,
            content=response_data
        )
    
    @staticmethod
    def _handle_http_exception(error: HTTPException) -> JSONResponse:
        """Trata exceções HTTP do FastAPI"""
        response_data = {
            "error": "HTTP_ERROR",
            "message": error.detail,
            "status_code": error.status_code
        }
        
        logger.warning(f"HTTP error {error.status_code}: {error.detail}")
        
        return JSONResponse(
            status_code=error.status_code,
            content=response_data
        )
    
    @staticmethod
    def _handle_generic_exception(
        error: Exception,
        default_message: str,
        request_id: Optional[str]
    ) -> JSONResponse:
        """Trata exceções genéricas não previstas"""
        error_id = request_id or "unknown"
        
        response_data = {
            "error": "INTERNAL_SERVER_ERROR",
            "message": default_message,
            "error_id": error_id
        }
        
        # Log completo do erro para debugging
        logger.error(
            f"Unhandled exception: {str(error)}",
            extra={
                "error_type": type(error).__name__,
                "error_message": str(error),
                "traceback": traceback.format_exc(),
                "request_id": request_id
            }
        )
        
        return JSONResponse(
            status_code=500,
            content=response_data
        )


# Função de conveniência para uso nos endpoints
def handle_api_error(
    error: Exception,
    default_message: str = "Erro interno do servidor",
    request_id: Optional[str] = None
) -> JSONResponse:
    """
    Função de conveniência para tratamento de erros
    Implementa Facade Pattern para simplificar uso
    """
    return ErrorHandler.handle_api_error(error, default_message, request_id)


# Exception handlers para FastAPI
async def validation_exception_handler(request: Request, exc: ValidationError) -> JSONResponse:
    """Handler específico para erros de validação"""
    return ErrorHandler._handle_custom_exception(exc)


async def not_found_exception_handler(request: Request, exc: EntityNotFoundError) -> JSONResponse:
    """Handler específico para entidades não encontradas"""
    return ErrorHandler._handle_custom_exception(exc)


async def authentication_exception_handler(request: Request, exc: AuthenticationError) -> JSONResponse:
    """Handler específico para erros de autenticação"""
    return ErrorHandler._handle_custom_exception(exc)


async def generic_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    """Handler genérico para exceções não tratadas"""
    request_id = getattr(request.state, 'request_id', None)
    return ErrorHandler._handle_generic_exception(exc, "Erro interno do servidor", request_id)


# Middleware para captura de request ID
class RequestIDMiddleware:
    """
    Middleware para adicionar request ID
    Implementa SRP: responsável apenas pelo tracking de requests
    """
    
    def __init__(self, app):
        self.app = app
    
    async def __call__(self, scope, receive, send):
        if scope["type"] == "http":
            # Gerar request ID único
            import uuid
            request_id = str(uuid.uuid4())
            
            # Adicionar ao scope para acesso posterior
            scope["state"] = getattr(scope, "state", {})
            scope["state"]["request_id"] = request_id
            
            # Adicionar header de resposta
            async def send_wrapper(message):
                if message["type"] == "http.response.start":
                    headers = list(message.get("headers", []))
                    headers.append([b"x-request-id", request_id.encode()])
                    message["headers"] = headers
                await send(message)
            
            await self.app(scope, receive, send_wrapper)
        else:
            await self.app(scope, receive, send)


# Configuração de logging estruturado
def setup_error_logging():
    """
    Configura logging estruturado para erros
    Implementa SRP: responsável apenas pela configuração de logs
    """
    import json
    from datetime import datetime
    
    class StructuredFormatter(logging.Formatter):
        """Formatter para logs estruturados em JSON"""
        
        def format(self, record):
            log_data = {
                "timestamp": datetime.utcnow().isoformat(),
                "level": record.levelname,
                "logger": record.name,
                "message": record.getMessage(),
                "module": record.module,
                "function": record.funcName,
                "line": record.lineno
            }
            
            # Adicionar dados extras se disponíveis
            if hasattr(record, 'extra'):
                log_data.update(record.extra)
            
            # Adicionar traceback se for erro
            if record.exc_info:
                log_data["traceback"] = self.formatException(record.exc_info)
            
            return json.dumps(log_data, default=str)
    
    # Configurar handler
    handler = logging.StreamHandler()
    handler.setFormatter(StructuredFormatter())
    
    # Configurar logger raiz
    root_logger = logging.getLogger()
    root_logger.addHandler(handler)
    root_logger.setLevel(logging.INFO)
    
    # Configurar logger específico para erros
    error_logger = logging.getLogger("data_governance.errors")
    error_logger.setLevel(logging.WARNING)
    
    return error_logger

