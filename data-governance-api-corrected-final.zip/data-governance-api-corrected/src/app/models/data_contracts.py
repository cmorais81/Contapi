"""
Modelos SQLAlchemy para Data Governance API - Contratos de Dados
Baseado no modelo correto do dbdiagram.io
Implementa princípios SOLID e Clean Architecture
"""

from sqlalchemy import (
    Column, String, Text, Boolean, Integer, DateTime, 
    ForeignKey, Table, ARRAY, UUID, Index
)
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import uuid
from datetime import datetime
from typing import List, Optional

Base = declarative_base()

# Tabela de associação para many-to-many entre contratos e frameworks de compliance
contract_compliance_frameworks = Table(
    'contract_compliance_frameworks',
    Base.metadata,
    Column('contract_id', UUID(as_uuid=True), ForeignKey('data_contracts._id'), primary_key=True),
    Column('framework_id', UUID(as_uuid=True), ForeignKey('compliance_frameworks._id'), primary_key=True)
)

# Tabela de associação para many-to-many entre usuários e grupos
user_groups_association = Table(
    'user_groups_association',
    Base.metadata,
    Column('user_id', UUID(as_uuid=True), ForeignKey('users._id'), primary_key=True),
    Column('group_id', UUID(as_uuid=True), ForeignKey('user_groups._id'), primary_key=True)
)


class DataContract(Base):
    """
    Modelo principal para contratos de dados
    Implementa SRP: responsável apenas pela definição de contratos
    """
    __tablename__ = 'data_contracts'

    # Identificação única
    _id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, 
                 comment='Identificador único global do contrato')
    
    # Informações básicas do contrato
    contract_name = Column(String(255), nullable=False, 
                          comment='Nome único do contrato de dados')
    contract_version = Column(String(50), nullable=False, 
                             comment='Versão semântica do contrato (ex: 1.2.3)')
    contract_status = Column(String(50), nullable=False, default='draft',
                            comment='Status: draft, active, deprecated, archived')
    
    # Metadados do contrato
    description = Column(Text, comment='Descrição detalhada do propósito do contrato')
    business_purpose = Column(Text, comment='Justificativa de negócio para o contrato')
    data_classification = Column(String(50), 
                                comment='Classificação: public, internal, confidential, restricted')
    
    # Versionamento
    previous_version_id = Column(UUID(as_uuid=True), ForeignKey('data_contracts._id'),
                                comment='Referência à versão anterior do contrato')
    breaking_changes = Column(Boolean, default=False,
                             comment='Indica se há mudanças que quebram compatibilidade')
    migration_notes = Column(Text, comment='Instruções para migração entre versões')
    
    # Localização e jurisdição
    country_code = Column(String(3), comment='Código do país (ISO 3166-1 alpha-3)')
    region = Column(String(100), comment='Região geográfica específica')
    jurisdiction = Column(String(100), comment='Jurisdição legal aplicável')
    
    # Auditoria e timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), 
                       onupdate=func.now(), nullable=False)
    created_by_user_id = Column(UUID(as_uuid=True), ForeignKey('users._id'), nullable=False)
    updated_by_user_id = Column(UUID(as_uuid=True), ForeignKey('users._id'), nullable=False)
    
    # Aprovação e governança
    approved_at = Column(DateTime(timezone=True), comment='Data de aprovação do contrato')
    approved_by_user_id = Column(UUID(as_uuid=True), ForeignKey('users._id'),
                                comment='Usuário que aprovou o contrato')
    effective_date = Column(DateTime(timezone=True), comment='Data de início da vigência')
    expiration_date = Column(DateTime(timezone=True), comment='Data de expiração do contrato')
    
    # Retenção de dados
    data_retention_days = Column(Integer, comment='Período de retenção em dias')
    
    # Relacionamentos
    previous_version = relationship("DataContract", remote_side=[_id])
    created_by = relationship("User", foreign_keys=[created_by_user_id])
    updated_by = relationship("User", foreign_keys=[updated_by_user_id])
    approved_by = relationship("User", foreign_keys=[approved_by_user_id])
    
    # Relacionamentos com outras entidades
    versions = relationship("ContractVersion", back_populates="contract")
    schemas = relationship("ContractSchema", back_populates="contract")
    access_policies = relationship("AccessPolicy", back_populates="contract")
    audit_logs = relationship("AuditLog", back_populates="contract")
    compliance_frameworks = relationship("ComplianceFramework", 
                                       secondary=contract_compliance_frameworks,
                                       back_populates="contracts")
    
    # Índices para performance
    __table_args__ = (
        Index('idx_contract_name_version', 'contract_name', 'contract_version', unique=True),
        Index('idx_contract_country_status', 'country_code', 'contract_status'),
        Index('idx_contract_classification', 'data_classification'),
        Index('idx_contract_created_at', 'created_at'),
        Index('idx_contract_status', 'contract_status'),
    )

    def __repr__(self):
        return f"<DataContract(name='{self.contract_name}', version='{self.contract_version}')>"


class ContractVersion(Base):
    """
    Modelo para versionamento de contratos
    Implementa SRP: responsável apenas pelo controle de versões
    """
    __tablename__ = 'contract_versions'

    _id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    contract_id = Column(UUID(as_uuid=True), ForeignKey('data_contracts._id'), nullable=False)
    version_number = Column(String(50), nullable=False)
    version_type = Column(String(20), nullable=False, 
                         comment='major, minor, patch')
    changelog = Column(Text, comment='Descrição das mudanças nesta versão')
    is_breaking_change = Column(Boolean, default=False)
    migration_script = Column(Text, comment='Script de migração para esta versão')
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    created_by_user_id = Column(UUID(as_uuid=True), ForeignKey('users._id'), nullable=False)
    
    # Relacionamentos
    contract = relationship("DataContract", back_populates="versions")
    created_by = relationship("User")
    
    __table_args__ = (
        Index('idx_version_contract_number', 'contract_id', 'version_number', unique=True),
    )


class User(Base):
    """
    Modelo para usuários do sistema
    Implementa SRP: responsável apenas pela gestão de usuários
    """
    __tablename__ = 'users'

    _id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    username = Column(String(100), unique=True, nullable=False)
    email = Column(String(255), unique=True, nullable=False)
    full_name = Column(String(255), nullable=False)
    is_active = Column(Boolean, default=True)
    is_admin = Column(Boolean, default=False)
    
    # Informações de localização
    country_code = Column(String(3), comment='País do usuário')
    department = Column(String(100), comment='Departamento do usuário')
    role = Column(String(100), comment='Cargo do usuário')
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), 
                       onupdate=func.now(), nullable=False)
    last_login = Column(DateTime(timezone=True), comment='Último login do usuário')
    
    # Relacionamentos
    groups = relationship("UserGroup", secondary=user_groups_association, back_populates="users")
    
    __table_args__ = (
        Index('idx_user_email', 'email'),
        Index('idx_user_username', 'username'),
        Index('idx_user_active', 'is_active'),
    )


class UserGroup(Base):
    """
    Modelo para grupos de usuários
    Implementa SRP: responsável apenas pela gestão de grupos
    """
    __tablename__ = 'user_groups'

    _id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    group_name = Column(String(100), unique=True, nullable=False)
    description = Column(Text, comment='Descrição do grupo')
    group_type = Column(String(50), comment='Tipo: department, project, role')
    
    # Configurações de acesso
    default_permissions = Column(ARRAY(String), comment='Permissões padrão do grupo')
    country_restrictions = Column(ARRAY(String), comment='Restrições por país')
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), 
                       onupdate=func.now(), nullable=False)
    created_by_user_id = Column(UUID(as_uuid=True), ForeignKey('users._id'), nullable=False)
    
    # Relacionamentos
    users = relationship("User", secondary=user_groups_association, back_populates="groups")
    access_policies = relationship("AccessPolicy", back_populates="group")
    created_by = relationship("User")


class AccessPolicy(Base):
    """
    Modelo para políticas de acesso
    Implementa SRP: responsável apenas pelo controle de acesso
    """
    __tablename__ = 'access_policies'

    _id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    policy_name = Column(String(255), nullable=False)
    contract_id = Column(UUID(as_uuid=True), ForeignKey('data_contracts._id'), nullable=False)
    group_id = Column(UUID(as_uuid=True), ForeignKey('user_groups._id'), nullable=False)
    
    # Configurações de acesso
    access_level = Column(String(50), nullable=False, 
                         comment='read, write, admin, none')
    field_restrictions = Column(ARRAY(String), comment='Campos com restrição de acesso')
    row_level_filters = Column(Text, comment='Filtros de linha em SQL')
    
    # Configurações de mascaramento
    masking_rules = Column(Text, comment='Regras de mascaramento em JSON')
    
    # Validade da política
    effective_date = Column(DateTime(timezone=True), nullable=False)
    expiration_date = Column(DateTime(timezone=True))
    is_active = Column(Boolean, default=True)
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), 
                       onupdate=func.now(), nullable=False)
    created_by_user_id = Column(UUID(as_uuid=True), ForeignKey('users._id'), nullable=False)
    
    # Relacionamentos
    contract = relationship("DataContract", back_populates="access_policies")
    group = relationship("UserGroup", back_populates="access_policies")
    created_by = relationship("User")
    
    __table_args__ = (
        Index('idx_policy_contract_group', 'contract_id', 'group_id', unique=True),
        Index('idx_policy_active', 'is_active'),
    )


class ComplianceFramework(Base):
    """
    Modelo para frameworks de compliance
    Implementa SRP: responsável apenas pela gestão de compliance
    """
    __tablename__ = 'compliance_frameworks'

    _id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    framework_name = Column(String(100), unique=True, nullable=False)
    framework_code = Column(String(20), unique=True, nullable=False, 
                           comment='Código: GDPR, LGPD, HIPAA, SOX')
    description = Column(Text, comment='Descrição do framework')
    
    # Configurações específicas
    applicable_countries = Column(ARRAY(String), comment='Países onde se aplica')
    data_retention_requirements = Column(Text, comment='Requisitos de retenção')
    consent_requirements = Column(Text, comment='Requisitos de consentimento')
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), 
                       onupdate=func.now(), nullable=False)
    
    # Relacionamentos
    contracts = relationship("DataContract", 
                           secondary=contract_compliance_frameworks,
                           back_populates="compliance_frameworks")


class AuditLog(Base):
    """
    Modelo para logs de auditoria
    Implementa SRP: responsável apenas pelo registro de auditoria
    """
    __tablename__ = 'audit_logs'

    _id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    contract_id = Column(UUID(as_uuid=True), ForeignKey('data_contracts._id'), nullable=False)
    user_id = Column(UUID(as_uuid=True), ForeignKey('users._id'), nullable=False)
    
    # Informações da ação
    action_type = Column(String(50), nullable=False, 
                        comment='CREATE, UPDATE, DELETE, ACCESS, APPROVE')
    resource_type = Column(String(50), nullable=False,
                          comment='contract, schema, policy, etc.')
    resource_id = Column(UUID(as_uuid=True), comment='ID do recurso afetado')
    
    # Detalhes da mudança
    old_values = Column(Text, comment='Valores anteriores em JSON')
    new_values = Column(Text, comment='Novos valores em JSON')
    change_description = Column(Text, comment='Descrição da mudança')
    
    # Contexto da ação
    ip_address = Column(String(45), comment='Endereço IP do usuário')
    user_agent = Column(String(500), comment='User agent do navegador')
    session_id = Column(String(255), comment='ID da sessão')
    
    # Timestamp
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    
    # Relacionamentos
    contract = relationship("DataContract", back_populates="audit_logs")
    user = relationship("User")
    
    __table_args__ = (
        Index('idx_audit_contract_action', 'contract_id', 'action_type'),
        Index('idx_audit_user_date', 'user_id', 'created_at'),
        Index('idx_audit_created_at', 'created_at'),
    )


class ContractSchema(Base):
    """
    Modelo para schemas de contratos
    Implementa SRP: responsável apenas pela definição de schemas
    """
    __tablename__ = 'contract_schemas'

    _id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    contract_id = Column(UUID(as_uuid=True), ForeignKey('data_contracts._id'), nullable=False)
    schema_name = Column(String(255), nullable=False)
    schema_version = Column(String(50), nullable=False)
    
    # Definição do schema
    schema_definition = Column(Text, nullable=False, comment='Schema em JSON')
    schema_format = Column(String(50), default='json_schema', 
                          comment='Formato: json_schema, avro, parquet')
    
    # Validação
    is_active = Column(Boolean, default=True)
    validation_rules = Column(Text, comment='Regras de validação em JSON')
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), 
                       onupdate=func.now(), nullable=False)
    created_by_user_id = Column(UUID(as_uuid=True), ForeignKey('users._id'), nullable=False)
    
    # Relacionamentos
    contract = relationship("DataContract", back_populates="schemas")
    created_by = relationship("User")
    
    __table_args__ = (
        Index('idx_schema_contract_name', 'contract_id', 'schema_name', unique=True),
        Index('idx_schema_active', 'is_active'),
    )

