"""
Schemas Pydantic para Data Governance API
Implementa validação robusta e princípios SOLID
"""

from .contract_schemas import (
    # Enums
    ContractStatus,
    DataClassification,
    AccessLevel,
    ActionType,
    VersionType,
    
    # Base schemas
    BaseSchema,
    TimestampMixin,
    UserReference,
    
    # Data Contract schemas
    DataContractBase,
    DataContractCreate,
    DataContractUpdate,
    DataContractResponse,
    
    # Contract Version schemas
    ContractVersionBase,
    ContractVersionCreate,
    ContractVersionResponse,
    
    # User schemas
    UserBase,
    UserCreate,
    UserResponse,
    
    # Access Policy schemas
    AccessPolicyBase,
    AccessPolicyCreate,
    AccessPolicyResponse,
    
    # Compliance Framework schemas
    ComplianceFrameworkBase,
    ComplianceFrameworkCreate,
    ComplianceFrameworkResponse,
    
    # Audit Log schemas
    AuditLogResponse,
    
    # Pagination schemas
    PaginationParams,
    PaginatedResponse,
    
    # Filter schemas
    ContractFilters,
    
    # Error schemas
    ErrorDetail,
    ErrorResponse
)

__all__ = [
    # Enums
    'ContractStatus',
    'DataClassification',
    'AccessLevel',
    'ActionType',
    'VersionType',
    
    # Base schemas
    'BaseSchema',
    'TimestampMixin',
    'UserReference',
    
    # Data Contract schemas
    'DataContractBase',
    'DataContractCreate',
    'DataContractUpdate',
    'DataContractResponse',
    
    # Contract Version schemas
    'ContractVersionBase',
    'ContractVersionCreate',
    'ContractVersionResponse',
    
    # User schemas
    'UserBase',
    'UserCreate',
    'UserResponse',
    
    # Access Policy schemas
    'AccessPolicyBase',
    'AccessPolicyCreate',
    'AccessPolicyResponse',
    
    # Compliance Framework schemas
    'ComplianceFrameworkBase',
    'ComplianceFrameworkCreate',
    'ComplianceFrameworkResponse',
    
    # Audit Log schemas
    'AuditLogResponse',
    
    # Pagination schemas
    'PaginationParams',
    'PaginatedResponse',
    
    # Filter schemas
    'ContractFilters',
    
    # Error schemas
    'ErrorDetail',
    'ErrorResponse'
]

