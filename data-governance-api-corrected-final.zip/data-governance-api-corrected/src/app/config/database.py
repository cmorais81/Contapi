"""
Configuração de banco de dados para Data Governance API
Implementa princípios SOLID e Clean Architecture
"""

from abc import ABC, abstractmethod
from typing import Optional, Generator
from sqlalchemy import create_engine, Engine
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.pool import StaticPool
import os
from contextlib import contextmanager
import logging

logger = logging.getLogger(__name__)


class IDatabaseConfig(ABC):
    """
    Interface para configuração de banco de dados
    Implementa ISP: Interface específica para configuração
    """
    
    @abstractmethod
    def get_database_url(self) -> str:
        """Retorna a URL de conexão com o banco"""
        pass
    
    @abstractmethod
    def get_engine_config(self) -> dict:
        """Retorna configurações do engine SQLAlchemy"""
        pass


class ISessionManager(ABC):
    """
    Interface para gerenciamento de sessões
    Implementa ISP: Interface específica para sessões
    """
    
    @abstractmethod
    def get_session(self) -> Session:
        """Retorna uma nova sessão"""
        pass
    
    @abstractmethod
    def close_session(self, session: Session) -> None:
        """Fecha uma sessão"""
        pass
    
    @abstractmethod
    @contextmanager
    def session_scope(self) -> Generator[Session, None, None]:
        """Context manager para sessões"""
        pass


class PostgreSQLConfig(IDatabaseConfig):
    """
    Configuração específica para PostgreSQL
    Implementa SRP: responsável apenas pela configuração PostgreSQL
    """
    
    def __init__(self):
        self.host = os.getenv('DB_HOST', 'localhost')
        self.port = os.getenv('DB_PORT', '5432')
        self.database = os.getenv('DB_NAME', 'data_governance')
        self.username = os.getenv('DB_USER', 'postgres')
        self.password = os.getenv('DB_PASSWORD', 'postgres')
        self.ssl_mode = os.getenv('DB_SSL_MODE', 'prefer')
    
    def get_database_url(self) -> str:
        """Constrói URL de conexão PostgreSQL"""
        return (
            f"postgresql://{self.username}:{self.password}@"
            f"{self.host}:{self.port}/{self.database}?sslmode={self.ssl_mode}"
        )
    
    def get_engine_config(self) -> dict:
        """Configurações otimizadas para PostgreSQL"""
        return {
            'pool_size': int(os.getenv('DB_POOL_SIZE', '10')),
            'max_overflow': int(os.getenv('DB_MAX_OVERFLOW', '20')),
            'pool_timeout': int(os.getenv('DB_POOL_TIMEOUT', '30')),
            'pool_recycle': int(os.getenv('DB_POOL_RECYCLE', '3600')),
            'pool_pre_ping': True,
            'echo': os.getenv('DB_ECHO', 'false').lower() == 'true'
        }


class SQLiteConfig(IDatabaseConfig):
    """
    Configuração específica para SQLite (desenvolvimento/testes)
    Implementa SRP: responsável apenas pela configuração SQLite
    """
    
    def __init__(self, database_path: Optional[str] = None):
        self.database_path = database_path or os.getenv('SQLITE_PATH', 'data_governance.db')
    
    def get_database_url(self) -> str:
        """Constrói URL de conexão SQLite"""
        if self.database_path == ':memory:':
            return 'sqlite:///:memory:'
        return f'sqlite:///{self.database_path}'
    
    def get_engine_config(self) -> dict:
        """Configurações para SQLite"""
        return {
            'poolclass': StaticPool,
            'connect_args': {
                'check_same_thread': False,
                'timeout': 20
            },
            'echo': os.getenv('DB_ECHO', 'false').lower() == 'true'
        }


class DatabaseSessionManager(ISessionManager):
    """
    Gerenciador de sessões de banco de dados
    Implementa SRP: responsável apenas pelo gerenciamento de sessões
    Implementa DIP: depende de abstrações (IDatabaseConfig)
    """
    
    def __init__(self, config: IDatabaseConfig):
        self._config = config
        self._engine: Optional[Engine] = None
        self._session_factory: Optional[sessionmaker] = None
        self._initialize()
    
    def _initialize(self) -> None:
        """Inicializa engine e session factory"""
        try:
            database_url = self._config.get_database_url()
            engine_config = self._config.get_engine_config()
            
            self._engine = create_engine(database_url, **engine_config)
            self._session_factory = sessionmaker(
                bind=self._engine,
                autocommit=False,
                autoflush=False
            )
            
            logger.info(f"Database initialized successfully: {database_url.split('@')[0]}@***")
            
        except Exception as e:
            logger.error(f"Failed to initialize database: {e}")
            raise
    
    @property
    def engine(self) -> Engine:
        """Retorna o engine SQLAlchemy"""
        if self._engine is None:
            raise RuntimeError("Database not initialized")
        return self._engine
    
    def get_session(self) -> Session:
        """
        Retorna uma nova sessão
        Implementa Factory Pattern
        """
        if self._session_factory is None:
            raise RuntimeError("Session factory not initialized")
        return self._session_factory()
    
    def close_session(self, session: Session) -> None:
        """Fecha uma sessão de forma segura"""
        try:
            session.close()
        except Exception as e:
            logger.warning(f"Error closing session: {e}")
    
    @contextmanager
    def session_scope(self) -> Generator[Session, None, None]:
        """
        Context manager para sessões com commit/rollback automático
        Implementa padrão Context Manager para resource management
        """
        session = self.get_session()
        try:
            yield session
            session.commit()
        except Exception as e:
            session.rollback()
            logger.error(f"Session rollback due to error: {e}")
            raise
        finally:
            self.close_session(session)
    
    def health_check(self) -> bool:
        """Verifica se a conexão com o banco está funcionando"""
        try:
            with self.session_scope() as session:
                session.execute("SELECT 1")
                return True
        except Exception as e:
            logger.error(f"Database health check failed: {e}")
            return False
    
    def close(self) -> None:
        """Fecha todas as conexões"""
        if self._engine:
            self._engine.dispose()
            logger.info("Database connections closed")


class DatabaseFactory:
    """
    Factory para criação de configurações de banco
    Implementa Factory Pattern e OCP: extensível para novos tipos de banco
    """
    
    @staticmethod
    def create_config(db_type: str = None) -> IDatabaseConfig:
        """
        Cria configuração de banco baseada no tipo
        Implementa Factory Method Pattern
        """
        db_type = db_type or os.getenv('DB_TYPE', 'postgresql')
        
        if db_type.lower() == 'postgresql':
            return PostgreSQLConfig()
        elif db_type.lower() == 'sqlite':
            return SQLiteConfig()
        else:
            raise ValueError(f"Unsupported database type: {db_type}")
    
    @staticmethod
    def create_session_manager(db_type: str = None) -> DatabaseSessionManager:
        """
        Cria gerenciador de sessões
        Implementa Abstract Factory Pattern
        """
        config = DatabaseFactory.create_config(db_type)
        return DatabaseSessionManager(config)


# Instância global do gerenciador de sessões
# Implementa Singleton Pattern para compartilhamento de recursos
_session_manager: Optional[DatabaseSessionManager] = None


def get_session_manager() -> DatabaseSessionManager:
    """
    Retorna instância global do gerenciador de sessões
    Implementa Singleton Pattern
    """
    global _session_manager
    if _session_manager is None:
        _session_manager = DatabaseFactory.create_session_manager()
    return _session_manager


def get_db_session() -> Generator[Session, None, None]:
    """
    Dependency injection para FastAPI
    Implementa Dependency Injection Pattern
    """
    session_manager = get_session_manager()
    with session_manager.session_scope() as session:
        yield session


def init_database() -> None:
    """Inicializa o banco de dados criando todas as tabelas"""
    from ..models import Base
    
    session_manager = get_session_manager()
    Base.metadata.create_all(bind=session_manager.engine)
    logger.info("Database tables created successfully")


def close_database() -> None:
    """Fecha conexões com o banco de dados"""
    global _session_manager
    if _session_manager:
        _session_manager.close()
        _session_manager = None

