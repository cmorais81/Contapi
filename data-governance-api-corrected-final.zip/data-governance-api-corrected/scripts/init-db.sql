-- Data Governance API - Inicialização do Banco de Dados
-- Versão: 2.0.0
-- Autor: Carlos Morais
-- Baseado no modelo: https://dbdiagram.io/d/ModelContract-6850352f3cc77757c81274cf

-- Configurações iniciais
SET timezone = 'UTC';
SET client_encoding = 'UTF8';

-- Extensões necessárias
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Função para atualizar timestamp automaticamente
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Tabela de usuários
CREATE TABLE IF NOT EXISTS users (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    full_name VARCHAR(255) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    is_active BOOLEAN DEFAULT true,
    is_superuser BOOLEAN DEFAULT false,
    last_login TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de grupos/roles
CREATE TABLE IF NOT EXISTS user_groups (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    group_name VARCHAR(100) UNIQUE NOT NULL,
    description TEXT,
    permissions JSONB DEFAULT '{}',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de associação usuário-grupo
CREATE TABLE IF NOT EXISTS user_group_memberships (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(_id) ON DELETE CASCADE,
    group_id UUID NOT NULL REFERENCES user_groups(_id) ON DELETE CASCADE,
    assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    assigned_by_user_id UUID REFERENCES users(_id),
    UNIQUE(user_id, group_id)
);

-- Tabela de frameworks de compliance
CREATE TABLE IF NOT EXISTS compliance_frameworks (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    framework_name VARCHAR(255) NOT NULL,
    framework_code VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    applicable_countries TEXT[] DEFAULT '{}',
    data_retention_requirements JSONB DEFAULT '{}',
    consent_requirements JSONB DEFAULT '{}',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela principal de contratos de dados
CREATE TABLE IF NOT EXISTS data_contracts (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    contract_name VARCHAR(255) NOT NULL,
    contract_description TEXT,
    contract_version VARCHAR(50) NOT NULL DEFAULT '1.0.0',
    contract_status VARCHAR(50) NOT NULL DEFAULT 'draft',
    data_classification VARCHAR(50) NOT NULL DEFAULT 'internal',
    
    -- Informações de negócio
    business_owner_id UUID REFERENCES users(_id),
    technical_owner_id UUID REFERENCES users(_id),
    data_steward_id UUID REFERENCES users(_id),
    
    -- Informações geográficas e compliance
    country_code VARCHAR(3),
    jurisdiction VARCHAR(100),
    
    -- Datas importantes
    effective_date TIMESTAMP,
    expiration_date TIMESTAMP,
    review_date TIMESTAMP,
    
    -- Configurações de retenção
    data_retention_days INTEGER DEFAULT 1095,
    purge_after_expiration BOOLEAN DEFAULT false,
    
    -- Metadados de controle
    approved_at TIMESTAMP,
    approved_by_user_id UUID REFERENCES users(_id),
    created_by_user_id UUID NOT NULL REFERENCES users(_id),
    updated_by_user_id UUID REFERENCES users(_id),
    previous_version_id UUID REFERENCES data_contracts(_id),
    
    -- Timestamps
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Constraints
    CONSTRAINT valid_status CHECK (contract_status IN ('draft', 'review', 'approved', 'active', 'deprecated', 'archived')),
    CONSTRAINT valid_classification CHECK (data_classification IN ('public', 'internal', 'confidential', 'restricted')),
    CONSTRAINT valid_dates CHECK (effective_date IS NULL OR expiration_date IS NULL OR effective_date < expiration_date)
);

-- Tabela de versões de contratos
CREATE TABLE IF NOT EXISTS contract_versions (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    contract_id UUID NOT NULL REFERENCES data_contracts(_id) ON DELETE CASCADE,
    version_number VARCHAR(50) NOT NULL,
    version_type VARCHAR(20) NOT NULL DEFAULT 'minor',
    changelog TEXT,
    is_breaking_change BOOLEAN DEFAULT false,
    migration_script TEXT,
    created_by_user_id UUID NOT NULL REFERENCES users(_id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT valid_version_type CHECK (version_type IN ('major', 'minor', 'patch')),
    UNIQUE(contract_id, version_number)
);

-- Tabela de associação contrato-framework
CREATE TABLE IF NOT EXISTS contract_compliance_frameworks (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    contract_id UUID NOT NULL REFERENCES data_contracts(_id) ON DELETE CASCADE,
    framework_id UUID NOT NULL REFERENCES compliance_frameworks(_id) ON DELETE CASCADE,
    compliance_status VARCHAR(50) DEFAULT 'pending',
    last_validation_date TIMESTAMP,
    validation_results JSONB DEFAULT '{}',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT valid_compliance_status CHECK (compliance_status IN ('pending', 'compliant', 'non_compliant', 'warning')),
    UNIQUE(contract_id, framework_id)
);

-- Tabela de objetos de dados
CREATE TABLE IF NOT EXISTS data_objects (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    contract_id UUID NOT NULL REFERENCES data_contracts(_id) ON DELETE CASCADE,
    object_name VARCHAR(255) NOT NULL,
    object_type VARCHAR(100) NOT NULL,
    object_description TEXT,
    
    -- Schema e estrutura
    schema_definition JSONB DEFAULT '{}',
    data_format VARCHAR(100),
    encoding VARCHAR(50),
    
    -- Localização e acesso
    storage_location TEXT,
    access_pattern VARCHAR(100),
    
    -- Qualidade e validação
    quality_rules JSONB DEFAULT '{}',
    validation_rules JSONB DEFAULT '{}',
    
    -- Metadados de negócio
    business_glossary JSONB DEFAULT '{}',
    tags TEXT[] DEFAULT '{}',
    
    -- Configurações de segurança
    encryption_required BOOLEAN DEFAULT false,
    masking_rules JSONB DEFAULT '{}',
    access_controls JSONB DEFAULT '{}',
    
    -- Timestamps
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT valid_object_type CHECK (object_type IN ('table', 'view', 'file', 'stream', 'api', 'dataset'))
);

-- Tabela de campos/colunas dos objetos
CREATE TABLE IF NOT EXISTS data_object_fields (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    data_object_id UUID NOT NULL REFERENCES data_objects(_id) ON DELETE CASCADE,
    field_name VARCHAR(255) NOT NULL,
    field_type VARCHAR(100) NOT NULL,
    field_description TEXT,
    
    -- Propriedades do campo
    is_nullable BOOLEAN DEFAULT true,
    is_primary_key BOOLEAN DEFAULT false,
    is_foreign_key BOOLEAN DEFAULT false,
    default_value TEXT,
    
    -- Validação e qualidade
    validation_rules JSONB DEFAULT '{}',
    quality_checks JSONB DEFAULT '{}',
    
    -- Classificação e segurança
    data_classification VARCHAR(50) DEFAULT 'internal',
    is_pii BOOLEAN DEFAULT false,
    is_sensitive BOOLEAN DEFAULT false,
    masking_type VARCHAR(50),
    
    -- Metadados de negócio
    business_name VARCHAR(255),
    business_description TEXT,
    business_rules TEXT,
    
    -- Ordem e agrupamento
    field_order INTEGER,
    field_group VARCHAR(100),
    
    -- Timestamps
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT valid_field_classification CHECK (data_classification IN ('public', 'internal', 'confidential', 'restricted')),
    CONSTRAINT valid_masking_type CHECK (masking_type IS NULL OR masking_type IN ('hash', 'encrypt', 'tokenize', 'redact', 'partial')),
    UNIQUE(data_object_id, field_name)
);

-- Tabela de políticas de acesso
CREATE TABLE IF NOT EXISTS access_policies (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    contract_id UUID NOT NULL REFERENCES data_contracts(_id) ON DELETE CASCADE,
    policy_name VARCHAR(255) NOT NULL,
    policy_type VARCHAR(50) NOT NULL,
    policy_description TEXT,
    
    -- Configuração da política
    policy_rules JSONB NOT NULL DEFAULT '{}',
    conditions JSONB DEFAULT '{}',
    actions JSONB DEFAULT '{}',
    
    -- Escopo da política
    applies_to_objects TEXT[] DEFAULT '{}',
    applies_to_fields TEXT[] DEFAULT '{}',
    applies_to_users TEXT[] DEFAULT '{}',
    applies_to_groups TEXT[] DEFAULT '{}',
    
    -- Status e vigência
    is_active BOOLEAN DEFAULT true,
    effective_from TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    effective_until TIMESTAMP,
    
    -- Metadados de controle
    created_by_user_id UUID NOT NULL REFERENCES users(_id),
    approved_by_user_id UUID REFERENCES users(_id),
    
    -- Timestamps
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT valid_policy_type CHECK (policy_type IN ('access_control', 'data_masking', 'retention', 'quality', 'compliance')),
    CONSTRAINT valid_effective_dates CHECK (effective_until IS NULL OR effective_from < effective_until)
);

-- Tabela de logs de auditoria
CREATE TABLE IF NOT EXISTS audit_logs (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    contract_id UUID REFERENCES data_contracts(_id),
    user_id UUID REFERENCES users(_id),
    
    -- Informações da ação
    action_type VARCHAR(50) NOT NULL,
    resource_type VARCHAR(100) NOT NULL,
    resource_id UUID,
    
    -- Detalhes da mudança
    change_description TEXT,
    old_values JSONB,
    new_values JSONB,
    change_summary JSONB DEFAULT '{}',
    
    -- Contexto da requisição
    ip_address INET,
    user_agent TEXT,
    session_id VARCHAR(255),
    
    -- Timestamps
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT valid_action_type CHECK (action_type IN ('CREATE', 'READ', 'UPDATE', 'DELETE', 'APPROVE', 'ACCESS', 'EXPORT'))
);

-- Tabela de métricas de qualidade
CREATE TABLE IF NOT EXISTS quality_metrics (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    contract_id UUID NOT NULL REFERENCES data_contracts(_id) ON DELETE CASCADE,
    data_object_id UUID REFERENCES data_objects(_id) ON DELETE CASCADE,
    field_id UUID REFERENCES data_object_fields(_id) ON DELETE CASCADE,
    
    -- Informações da métrica
    metric_name VARCHAR(255) NOT NULL,
    metric_type VARCHAR(100) NOT NULL,
    metric_description TEXT,
    
    -- Configuração da métrica
    metric_definition JSONB NOT NULL DEFAULT '{}',
    thresholds JSONB DEFAULT '{}',
    
    -- Resultados da execução
    last_execution_date TIMESTAMP,
    last_result JSONB,
    execution_status VARCHAR(50),
    
    -- Histórico de resultados
    execution_history JSONB DEFAULT '[]',
    
    -- Status da métrica
    is_active BOOLEAN DEFAULT true,
    
    -- Timestamps
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT valid_metric_type CHECK (metric_type IN ('completeness', 'accuracy', 'consistency', 'validity', 'uniqueness', 'timeliness')),
    CONSTRAINT valid_execution_status CHECK (execution_status IS NULL OR execution_status IN ('pending', 'running', 'success', 'failed', 'warning'))
);

-- Tabela de lineage de dados
CREATE TABLE IF NOT EXISTS data_lineage (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    source_contract_id UUID REFERENCES data_contracts(_id),
    source_object_id UUID REFERENCES data_objects(_id),
    source_field_id UUID REFERENCES data_object_fields(_id),
    
    target_contract_id UUID REFERENCES data_contracts(_id),
    target_object_id UUID REFERENCES data_objects(_id),
    target_field_id UUID REFERENCES data_object_fields(_id),
    
    -- Informações da transformação
    transformation_type VARCHAR(100),
    transformation_logic TEXT,
    transformation_rules JSONB DEFAULT '{}',
    
    -- Metadados do lineage
    lineage_type VARCHAR(50) NOT NULL DEFAULT 'field_to_field',
    confidence_score DECIMAL(3,2) DEFAULT 1.0,
    
    -- Status e validação
    is_verified BOOLEAN DEFAULT false,
    verified_by_user_id UUID REFERENCES users(_id),
    verified_at TIMESTAMP,
    
    -- Timestamps
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT valid_lineage_type CHECK (lineage_type IN ('field_to_field', 'object_to_object', 'contract_to_contract')),
    CONSTRAINT valid_confidence_score CHECK (confidence_score >= 0.0 AND confidence_score <= 1.0),
    CONSTRAINT lineage_source_target_check CHECK (
        (source_contract_id IS NOT NULL OR source_object_id IS NOT NULL OR source_field_id IS NOT NULL) AND
        (target_contract_id IS NOT NULL OR target_object_id IS NOT NULL OR target_field_id IS NOT NULL)
    )
);

-- Tabela de notificações
CREATE TABLE IF NOT EXISTS notifications (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(_id) ON DELETE CASCADE,
    contract_id UUID REFERENCES data_contracts(_id) ON DELETE CASCADE,
    
    -- Conteúdo da notificação
    notification_type VARCHAR(100) NOT NULL,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    
    -- Status da notificação
    is_read BOOLEAN DEFAULT false,
    read_at TIMESTAMP,
    
    -- Prioridade e categoria
    priority VARCHAR(20) DEFAULT 'medium',
    category VARCHAR(100),
    
    -- Metadados adicionais
    metadata JSONB DEFAULT '{}',
    
    -- Timestamps
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT valid_notification_type CHECK (notification_type IN ('contract_expiring', 'compliance_violation', 'quality_issue', 'approval_required', 'system_alert')),
    CONSTRAINT valid_priority CHECK (priority IN ('low', 'medium', 'high', 'critical'))
);

-- Criar triggers para atualização automática de timestamps
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_user_groups_updated_at BEFORE UPDATE ON user_groups FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_compliance_frameworks_updated_at BEFORE UPDATE ON compliance_frameworks FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_data_contracts_updated_at BEFORE UPDATE ON data_contracts FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_contract_versions_updated_at BEFORE UPDATE ON contract_versions FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_contract_compliance_frameworks_updated_at BEFORE UPDATE ON contract_compliance_frameworks FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_data_objects_updated_at BEFORE UPDATE ON data_objects FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_data_object_fields_updated_at BEFORE UPDATE ON data_object_fields FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_access_policies_updated_at BEFORE UPDATE ON access_policies FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_audit_logs_updated_at BEFORE UPDATE ON audit_logs FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_quality_metrics_updated_at BEFORE UPDATE ON quality_metrics FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_data_lineage_updated_at BEFORE UPDATE ON data_lineage FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_notifications_updated_at BEFORE UPDATE ON notifications FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Criar índices para performance
CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_active ON users(is_active);

CREATE INDEX idx_data_contracts_status ON data_contracts(contract_status);
CREATE INDEX idx_data_contracts_classification ON data_contracts(data_classification);
CREATE INDEX idx_data_contracts_country ON data_contracts(country_code);
CREATE INDEX idx_data_contracts_owner ON data_contracts(business_owner_id);
CREATE INDEX idx_data_contracts_created_by ON data_contracts(created_by_user_id);
CREATE INDEX idx_data_contracts_expiration ON data_contracts(expiration_date);

CREATE INDEX idx_contract_versions_contract ON contract_versions(contract_id);
CREATE INDEX idx_contract_versions_number ON contract_versions(version_number);

CREATE INDEX idx_data_objects_contract ON data_objects(contract_id);
CREATE INDEX idx_data_objects_type ON data_objects(object_type);
CREATE INDEX idx_data_objects_name ON data_objects(object_name);

CREATE INDEX idx_data_object_fields_object ON data_object_fields(data_object_id);
CREATE INDEX idx_data_object_fields_name ON data_object_fields(field_name);
CREATE INDEX idx_data_object_fields_pii ON data_object_fields(is_pii);
CREATE INDEX idx_data_object_fields_sensitive ON data_object_fields(is_sensitive);

CREATE INDEX idx_access_policies_contract ON access_policies(contract_id);
CREATE INDEX idx_access_policies_type ON access_policies(policy_type);
CREATE INDEX idx_access_policies_active ON access_policies(is_active);

CREATE INDEX idx_audit_logs_contract ON audit_logs(contract_id);
CREATE INDEX idx_audit_logs_user ON audit_logs(user_id);
CREATE INDEX idx_audit_logs_action ON audit_logs(action_type);
CREATE INDEX idx_audit_logs_resource ON audit_logs(resource_type);
CREATE INDEX idx_audit_logs_created ON audit_logs(created_at);

CREATE INDEX idx_quality_metrics_contract ON quality_metrics(contract_id);
CREATE INDEX idx_quality_metrics_object ON quality_metrics(data_object_id);
CREATE INDEX idx_quality_metrics_type ON quality_metrics(metric_type);
CREATE INDEX idx_quality_metrics_active ON quality_metrics(is_active);

CREATE INDEX idx_data_lineage_source_contract ON data_lineage(source_contract_id);
CREATE INDEX idx_data_lineage_target_contract ON data_lineage(target_contract_id);
CREATE INDEX idx_data_lineage_type ON data_lineage(lineage_type);

CREATE INDEX idx_notifications_user ON notifications(user_id);
CREATE INDEX idx_notifications_contract ON notifications(contract_id);
CREATE INDEX idx_notifications_type ON notifications(notification_type);
CREATE INDEX idx_notifications_read ON notifications(is_read);
CREATE INDEX idx_notifications_priority ON notifications(priority);

-- Comentários nas tabelas
COMMENT ON TABLE users IS 'Usuários do sistema de governança de dados';
COMMENT ON TABLE user_groups IS 'Grupos/roles de usuários para controle de acesso';
COMMENT ON TABLE compliance_frameworks IS 'Frameworks de compliance (GDPR, LGPD, etc.)';
COMMENT ON TABLE data_contracts IS 'Contratos de dados principais';
COMMENT ON TABLE contract_versions IS 'Histórico de versões dos contratos';
COMMENT ON TABLE data_objects IS 'Objetos de dados (tabelas, arquivos, etc.)';
COMMENT ON TABLE data_object_fields IS 'Campos/colunas dos objetos de dados';
COMMENT ON TABLE access_policies IS 'Políticas de acesso e segurança';
COMMENT ON TABLE audit_logs IS 'Logs de auditoria de todas as operações';
COMMENT ON TABLE quality_metrics IS 'Métricas de qualidade de dados';
COMMENT ON TABLE data_lineage IS 'Lineage e relacionamentos entre dados';
COMMENT ON TABLE notifications IS 'Notificações do sistema';

-- Mensagem de sucesso
SELECT 'Schema de Data Governance API criado com sucesso!' as status;

