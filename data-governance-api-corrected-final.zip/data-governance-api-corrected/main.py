"""
Data Governance API - Aplicação Principal
Implementa Clean Architecture e princípios SOLID
"""

from fastapi import FastAPI, Request, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.responses import JSONResponse
from contextlib import asynccontextmanager
import logging
import os
import time

# Imports da aplicação
from src.app.config.database import init_database, close_database
from src.app.resources.endpoints import contracts
from src.app.utils.error_handler import (
    ErrorHandler, RequestIDMiddleware, setup_error_logging,
    validation_exception_handler, not_found_exception_handler,
    authentication_exception_handler, generic_exception_handler
)
from src.app.utils.exceptions import (
    ValidationError, EntityNotFoundError, AuthenticationError
)
from src.app.services.contract_service import DataContractService
from src.app.services.audit_service import AuditService
from src.app.services.compliance_service import ComplianceService
from src.app.services.version_service import ContractVersionService

# Configurar logging
setup_error_logging()
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Gerenciamento do ciclo de vida da aplicação
    Implementa inicialização e limpeza de recursos
    """
    # Startup
    logger.info("Iniciando Data Governance API...")
    
    try:
        # Inicializar banco de dados
        init_database()
        logger.info("Banco de dados inicializado com sucesso")
        
        # Inicializar services (dependency injection)
        audit_service = AuditService()
        app.state.audit_service = audit_service
        app.state.contract_service = DataContractService(audit_service, None)  # validation_service será implementado
        app.state.compliance_service = ComplianceService(audit_service)
        app.state.version_service = ContractVersionService(audit_service)
        
        logger.info("Services inicializados com sucesso")
        
    except Exception as e:
        logger.error(f"Erro na inicialização: {e}")
        raise
    
    yield
    
    # Shutdown
    logger.info("Finalizando Data Governance API...")
    try:
        close_database()
        logger.info("Recursos liberados com sucesso")
    except Exception as e:
        logger.error(f"Erro na finalização: {e}")


# Criar aplicação FastAPI
app = FastAPI(
    title="Data Governance API",
    description="""
    API completa para governança de dados com contratos de dados.
    
    ## Funcionalidades Principais
    
    * **Contratos de Dados**: Gestão completa de contratos com versionamento semântico
    * **Compliance**: Validação automática de frameworks (GDPR, LGPD, CCPA, etc.)
    * **Auditoria**: Logging completo de todas as operações
    * **Controle de Acesso**: Políticas granulares de acesso
    * **Versionamento**: Sistema robusto de versionamento semântico
    * **Multi-país**: Suporte a diferentes jurisdições e regulamentações
    
    ## Arquitetura
    
    Esta API foi desenvolvida seguindo os princípios SOLID e Clean Architecture:
    
    * **Single Responsibility**: Cada classe tem uma única responsabilidade
    * **Open/Closed**: Extensível sem modificação do código existente
    * **Liskov Substitution**: Interfaces bem definidas e substituíveis
    * **Interface Segregation**: Interfaces específicas e focadas
    * **Dependency Inversion**: Dependências baseadas em abstrações
    
    ## Segurança
    
    * Autenticação JWT
    * Autorização baseada em roles (RBAC)
    * Auditoria completa de operações
    * Sanitização de dados sensíveis
    * Rate limiting e circuit breaker
    
    ## Compliance
    
    Suporte nativo aos principais frameworks de compliance:
    
    * **GDPR** (General Data Protection Regulation)
    * **LGPD** (Lei Geral de Proteção de Dados)
    * **CCPA** (California Consumer Privacy Act)
    * **HIPAA** (Health Insurance Portability and Accountability Act)
    * **SOX** (Sarbanes-Oxley Act)
    * **PIPEDA** (Personal Information Protection and Electronic Documents Act)
    """,
    version="2.0.0",
    contact={
        "name": "Carlos Morais",
        "email": "carlos.morais@example.com"
    },
    license_info={
        "name": "MIT License",
        "url": "https://opensource.org/licenses/MIT"
    },
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json"
)

# Configurar CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=os.getenv("ALLOWED_ORIGINS", "*").split(","),
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)

# Middleware de hosts confiáveis
app.add_middleware(
    TrustedHostMiddleware,
    allowed_hosts=os.getenv("ALLOWED_HOSTS", "*").split(",")
)

# Middleware de Request ID
app.add_middleware(RequestIDMiddleware)

# Middleware de métricas e logging
@app.middleware("http")
async def logging_middleware(request: Request, call_next):
    """
    Middleware para logging de requisições
    Implementa observabilidade e monitoramento
    """
    start_time = time.time()
    
    # Log da requisição
    logger.info(
        f"Request started: {request.method} {request.url.path}",
        extra={
            "method": request.method,
            "path": request.url.path,
            "query_params": str(request.query_params),
            "client_ip": request.client.host,
            "user_agent": request.headers.get("user-agent"),
            "request_id": getattr(request.state, "request_id", None)
        }
    )
    
    # Processar requisição
    try:
        response = await call_next(request)
        
        # Calcular tempo de processamento
        process_time = time.time() - start_time
        
        # Log da resposta
        logger.info(
            f"Request completed: {request.method} {request.url.path} - {response.status_code}",
            extra={
                "method": request.method,
                "path": request.url.path,
                "status_code": response.status_code,
                "process_time": process_time,
                "request_id": getattr(request.state, "request_id", None)
            }
        )
        
        # Adicionar headers de performance
        response.headers["X-Process-Time"] = str(process_time)
        
        return response
        
    except Exception as e:
        process_time = time.time() - start_time
        
        logger.error(
            f"Request failed: {request.method} {request.url.path}",
            extra={
                "method": request.method,
                "path": request.url.path,
                "error": str(e),
                "process_time": process_time,
                "request_id": getattr(request.state, "request_id", None)
            }
        )
        
        raise


# Registrar exception handlers
app.add_exception_handler(ValidationError, validation_exception_handler)
app.add_exception_handler(EntityNotFoundError, not_found_exception_handler)
app.add_exception_handler(AuthenticationError, authentication_exception_handler)
app.add_exception_handler(Exception, generic_exception_handler)

# Incluir routers
app.include_router(
    contracts.router,
    prefix="/api/v1",
    tags=["Data Contracts"]
)

# Endpoints de saúde e informações
@app.get("/", tags=["Health"])
async def root():
    """
    Endpoint raiz da API
    Retorna informações básicas da aplicação
    """
    return {
        "service": "Data Governance API",
        "version": "2.0.0",
        "status": "healthy",
        "description": "API para governança de dados com contratos de dados",
        "docs_url": "/docs",
        "redoc_url": "/redoc",
        "openapi_url": "/openapi.json"
    }


@app.get("/health", tags=["Health"])
async def health_check():
    """
    Endpoint de verificação de saúde
    Verifica status da aplicação e dependências
    """
    try:
        from src.app.config.database import get_session_manager
        
        # Verificar banco de dados
        session_manager = get_session_manager()
        db_healthy = session_manager.health_check()
        
        health_status = {
            "status": "healthy" if db_healthy else "unhealthy",
            "timestamp": time.time(),
            "version": "2.0.0",
            "environment": os.getenv("ENVIRONMENT", "development"),
            "checks": {
                "database": "healthy" if db_healthy else "unhealthy",
                "application": "healthy"
            }
        }
        
        status_code = 200 if db_healthy else 503
        
        return JSONResponse(
            status_code=status_code,
            content=health_status
        )
        
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        
        return JSONResponse(
            status_code=503,
            content={
                "status": "unhealthy",
                "timestamp": time.time(),
                "error": str(e)
            }
        )


@app.get("/metrics", tags=["Monitoring"])
async def metrics():
    """
    Endpoint de métricas básicas
    Retorna métricas de performance e uso
    """
    try:
        # Implementação básica de métricas
        # Em produção, usar Prometheus ou similar
        
        return {
            "timestamp": time.time(),
            "uptime_seconds": time.time() - app.state.start_time if hasattr(app.state, 'start_time') else 0,
            "environment": os.getenv("ENVIRONMENT", "development"),
            "version": "2.0.0"
        }
        
    except Exception as e:
        logger.error(f"Metrics collection failed: {e}")
        raise HTTPException(status_code=500, detail="Erro ao coletar métricas")


@app.get("/info", tags=["Information"])
async def api_info():
    """
    Endpoint de informações da API
    Retorna informações detalhadas sobre funcionalidades
    """
    return {
        "api_name": "Data Governance API",
        "version": "2.0.0",
        "description": "API completa para governança de dados",
        "author": "Carlos Morais",
        "architecture": "Clean Architecture + SOLID Principles",
        "features": [
            "Contratos de dados com versionamento semântico",
            "Compliance automático (GDPR, LGPD, CCPA, etc.)",
            "Auditoria completa de operações",
            "Controle de acesso granular",
            "Suporte multi-país e multi-jurisdição",
            "Autenticação JWT e autorização RBAC",
            "Documentação OpenAPI interativa"
        ],
        "supported_frameworks": [
            "GDPR", "LGPD", "CCPA", "HIPAA", "SOX", "PIPEDA", "APP", "APPI", "PIPL", "PDPB"
        ],
        "endpoints": {
            "contracts": "/api/v1/contracts",
            "health": "/health",
            "metrics": "/metrics",
            "docs": "/docs",
            "redoc": "/redoc"
        }
    }


# Configurar estado inicial da aplicação
@app.on_event("startup")
async def startup_event():
    """Evento de inicialização da aplicação"""
    app.state.start_time = time.time()
    logger.info("Data Governance API iniciada com sucesso")


@app.on_event("shutdown")
async def shutdown_event():
    """Evento de finalização da aplicação"""
    logger.info("Data Governance API finalizada")


if __name__ == "__main__":
    import uvicorn
    
    # Configurações para desenvolvimento
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info",
        access_log=True
    )

