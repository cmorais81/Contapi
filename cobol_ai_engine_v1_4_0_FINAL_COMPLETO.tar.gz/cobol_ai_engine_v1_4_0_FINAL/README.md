# COBOL AI Engine v1.4.0 - Pacote Final Completo

## Instalação Rápida (5 minutos)

```bash
# 1. Extrair pacote
tar -xzf cobol_ai_engine_v1_4_0_FINAL_COMPLETO.tar.gz
cd cobol_ai_engine_v1_4_0_FINAL

# 2. Executar instalação
chmod +x install_corrigido.sh
./install_corrigido.sh

# 3. Configurar credenciais
export LUZIA_CLIENT_ID="seu_client_id"
export LUZIA_CLIENT_SECRET="seu_client_secret"

# 4. Testar sistema
python3 main_standalone_v1_4_0.py --status
```

## Uso Básico

### Análise Simples
```bash
python3 main_standalone_v1_4_0.py --fontes examples/fontes.txt --output teste
```

### Análise Completa com Copybooks e PDF
```bash
python3 main_standalone_v1_4_0.py --fontes examples/fontes.txt --books examples/BOOKS.txt --output completa --pdf
```

### Análise de Produção
```bash
python3 main_standalone_v1_4_0.py --fontes examples/exemplo_producao.txt --books examples/copybooks_completos.txt --output producao --pdf
```

## Exemplos Incluídos

- `examples/fontes.txt` - Programas COBOL simples
- `examples/programas_exemplo.txt` - Programas COBOL complexos
- `examples/exemplo_producao.txt` - Programas de produção realistas
- `examples/BOOKS.txt` - Copybooks básicos
- `examples/copybooks_completos.txt` - Copybooks completos e realistas

## Correções Implementadas v1.4.0

✅ **Renovação automática de token** (resolve HTTP 401)
✅ **Tratamento de HTTP 201 e 202** (correção principal)
✅ **Sistema de auditoria completo** (transparência total)
✅ **Interface original mantida** (--fontes, --books, --output, --pdf)

## Documentação

- `INICIO_RAPIDO.md` - Guia de 5 minutos
- `GUIA_PRATICO_BOOKS_PDF.md` - Como usar --books e --pdf
- `docs/README_v1_4_0.md` - Documentação completa
- `docs/CORRECOES_IMPLEMENTADAS_v1_4_0.md` - Detalhes técnicos

## Suporte

- Logs detalhados em `logs/`
- Auditoria completa em `output/audit/`
- Sistema de testes: `./quick_test.sh`

---
**Status**: Pronto para uso em ambiente novo
**Interface**: Original mantida (--fontes, --books, --output, --pdf)
**Correções**: Todas implementadas e validadas
