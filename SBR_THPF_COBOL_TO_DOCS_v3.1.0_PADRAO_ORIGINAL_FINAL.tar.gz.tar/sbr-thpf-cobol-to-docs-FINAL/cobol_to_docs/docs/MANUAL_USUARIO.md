# Manual do Usuário - COBOL Analyzer v3.1.0

## Introdução

O COBOL Analyzer é uma ferramenta profissional de análise automatizada de código COBOL que utiliza Inteligência Artificial para gerar documentação técnica detalhada, extrair regras de negócio e fornecer insights sobre sistemas legados.

## Instalação e Configuração

### Instalação Básica

1. **Extrair o pacote**
   ```bash
   tar -xzf COBOL_ANALYZER_v3.1.0_FINAL.tar.gz
   cd cobol_analyzer_final/
   ```

2. **Instalar via pip**
   ```bash
   pip install .
   ```

3. **Verificar instalação**
   ```bash
   cobol-to-docs --help
   ```

### Configuração Inicial

Execute o comando de inicialização para configurar o ambiente:

```bash
cobol-to-docs --init
```

Este comando cria automaticamente:
- **config/**: Configurações e prompts especializados
- **data/**: Base de conhecimento RAG
- **logs/**: Diretório para logs
- **examples/**: Exemplos e templates

## Configuração de Provedores de IA

### Luzia (Recomendado para ambiente Santander)

```bash
export LUZIA_CLIENT_ID="seu_client_id"
export LUZIA_CLIENT_SECRET="seu_client_secret"
```

### GitHub Copilot

```bash
export GITHUB_TOKEN="seu_github_token"
```

### OpenAI

```bash
export OPENAI_API_KEY="sua_api_key"
```

## Uso Básico

### Preparação dos Arquivos

1. **Criar lista de programas COBOL**
   ```bash
   echo "PROGRAMA1.CBL" > fontes.txt
   echo "PROGRAMA2.CBL" >> fontes.txt
   ```

2. **Criar lista de copybooks (opcional)**
   ```bash
   echo "COPYBOOK1.CPY" > books.txt
   echo "COPYBOOK2.CPY" >> books.txt
   ```

### Comandos Essenciais

#### Análise Básica
```bash
cobol-to-docs --fontes fontes.txt --models luzia
```

#### Análise com Copybooks
```bash
cobol-to-docs --fontes fontes.txt --books books.txt --models luzia
```

#### Análise Consolidada (Sistema Completo)
```bash
cobol-to-docs --fontes fontes.txt --consolidado --models luzia
```

## Tipos de Análise Disponíveis

### 1. Análise Padrão
Análise básica com documentação funcional completa.
```bash
cobol-to-docs --fontes fontes.txt --models luzia
```

### 2. Análise Especialista
Análise técnica profunda com foco em arquitetura e padrões.
```bash
cobol-to-docs --fontes fontes.txt --analise-especialista --models luzia
```

### 3. Análise de Modernização
Identifica oportunidades de modernização e migração.
```bash
cobol-to-docs --fontes fontes.txt --modernizacao --models luzia
```

### 4. Análise Detalhada de Procedures
Foco específico na PROCEDURE DIVISION.
```bash
cobol-to-docs --fontes fontes.txt --procedure-detalhada --models luzia
```

### 5. Análise Consolidada
Análise sistêmica de múltiplos programas simultaneamente.
```bash
cobol-to-docs --fontes fontes.txt --consolidado --models luzia
```

## Modelos de IA Disponíveis

### Luzia (Santander)
- **aws-claude-3-5-sonnet**: Análises complexas e detalhadas
- **aws-claude-3-5-haiku**: Análises rápidas e eficientes
- **amazon-nova-pro-v1**: Análises especializadas

### GitHub Copilot
- **gpt-4o**: Modelo GPT-4 Omni completo
- **gpt-4o-mini**: Versão otimizada para velocidade

### Enhanced Mock (Desenvolvimento)
- **enhanced-mock-gpt-4**: Simulador para testes

## Sistema RAG (Retrieval-Augmented Generation)

O sistema RAG enriquece automaticamente as análises com conhecimento especializado:

### Características
- **Auto-learning**: Aprende com cada análise realizada
- **Base de conhecimento**: Padrões COBOL, melhores práticas, regras bancárias
- **Contexto inteligente**: Enriquece prompts automaticamente
- **Relatórios detalhados**: Rastreia uso da base de conhecimento

### Monitoramento RAG
Os relatórios RAG são salvos em `logs/rag_session_report_*.txt` e contêm:
- Itens de conhecimento utilizados
- Contexto adicionado aos prompts
- Estatísticas de uso

## Estrutura de Saída

Após a execução, os resultados são organizados no diretório `output/`:

```
output/
├── PROGRAMA_analise_funcional.md      # Documentação principal
├── PROGRAMA_ai_response.json          # Resposta completa da IA
├── PROGRAMA_ai_request.json           # Request enviado
├── relatorio_custos.txt               # Relatório de custos
└── logs/
    └── rag_session_report_*.txt       # Relatórios RAG
```

## Monitoramento e Diagnóstico

### Verificar Status dos Provedores
```bash
cobol-to-docs --status
```

### Logs Detalhados
```bash
cobol-to-docs --fontes fontes.txt --log-level DEBUG --models luzia
```

### Verificar Configuração
```bash
# Verificar se ambiente foi inicializado
ls -la config/ data/ logs/ examples/

# Verificar arquivos de configuração
cat config/config.yaml
```

## Exemplos Práticos

### Exemplo 1: Análise de Sistema Bancário

```bash
# 1. Inicializar ambiente
cobol-to-docs --init

# 2. Preparar lista de programas
find /caminho/sistema/cobol -name "*.cbl" > programas_bancarios.txt

# 3. Preparar copybooks
find /caminho/sistema/copy -name "*.cpy" > copybooks_bancarios.txt

# 4. Executar análise completa
cobol-to-docs --fontes programas_bancarios.txt \
              --books copybooks_bancarios.txt \
              --consolidado \
              --analise-especialista \
              --modernizacao \
              --models luzia
```

### Exemplo 2: Análise Comparativa

```bash
# Comparar diferentes modelos de IA
cobol-to-docs --fontes fontes.txt \
              --models "['luzia', 'github_copilot', 'enhanced_mock']" \
              --model-comparison
```

### Exemplo 3: Análise Rápida para Desenvolvimento

```bash
# Usar modelo mock para testes rápidos
cobol-to-docs --fontes fontes.txt --models enhanced_mock
```

## Solução de Problemas

### Problema: Comando não encontrado

**Sintoma**: `cobol-to-docs: command not found`

**Solução**:
```bash
# Verificar instalação
pip list | grep cobol-to-docs

# Reinstalar se necessário
pip uninstall cobol-to-docs -y
pip install .
```

### Problema: Provider não disponível

**Sintoma**: Erro de autenticação ou provider indisponível

**Solução**:
```bash
# Verificar status
cobol-to-docs --status

# Configurar credenciais
export LUZIA_CLIENT_ID="seu_id"
export LUZIA_CLIENT_SECRET="seu_secret"

# Testar com modelo mock
cobol-to-docs --fontes fontes.txt --models enhanced_mock
```

### Problema: Erro de configuração

**Sintoma**: Arquivos de configuração não encontrados

**Solução**:
```bash
# Reinicializar ambiente
rm -rf config/ data/ logs/ examples/
cobol-to-docs --init
```

## Configuração Personalizada

### Arquivo config/config.yaml

Principais configurações que podem ser personalizadas:

```yaml
ai:
  primary_provider: "luzia"
  fallback_providers: ["enhanced_mock", "github_copilot"]
  
analysis:
  depth: "detailed"
  include_comments: true
  include_business_rules: true
  include_technical_details: true

rag:
  enabled: true
  auto_learning: true
  max_context_items: 10
```

### Prompts Personalizados

Os prompts podem ser personalizados editando os arquivos em `config/`:
- `prompts_cadoc_deep_analysis.yaml`: Prompts para análise detalhada
- `prompts_especialista.yaml`: Prompts para análise especialista
- `prompts_enhanced.yaml`: Prompts aprimorados
- `prompts_melhorado_rag.yaml`: Prompts otimizados para RAG

## Limitações e Considerações

### Limitações Técnicas
- **Tamanho de arquivo**: Programas muito grandes podem ser truncados
- **Complexidade**: Lógica muito complexa pode não ser totalmente capturada
- **Dependências**: Análise limitada sem todos os copybooks

### Considerações de Custo
- **Modelos pagos**: Luzia, OpenAI e outros têm custos por token
- **Análise consolidada**: Consome mais tokens que análise individual
- **Múltiplos modelos**: Multiplicam o custo por modelo usado

### Considerações de Segurança
- **Código sensível**: Não envie código com informações confidenciais
- **Credenciais**: Mantenha chaves de API seguras
- **Logs**: Logs podem conter trechos de código

## Suporte

### Documentação Adicional
- `docs/MANUAL_TECNICO.md`: Documentação técnica detalhada
- `docs/GUIA_CONFIGURACAO.md`: Configurações avançadas
- `examples/`: Exemplos práticos de uso

### Logs e Debugging
- **Logs de execução**: `logs/cobol_to_docs_*.log`
- **Relatórios RAG**: `logs/rag_session_report_*.txt`
- **Respostas IA**: `output/*_ai_response.json`
- **Requests IA**: `output/*_ai_request.json`

### Informações de Versão
- **Versão**: 3.1.0
- **Data**: Outubro 2025
- **Compatibilidade**: Python 3.8+
- **Plataformas**: Windows, Linux, macOS
