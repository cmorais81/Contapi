# Guia de Configuração - COBOL Analyzer v3.1.0

## Configuração de Provedores de IA

### Luzia (Santander)

#### Configuração via Variáveis de Ambiente
```bash
export LUZIA_CLIENT_ID="seu_client_id"
export LUZIA_CLIENT_SECRET="seu_client_secret"
```

#### Configuração no arquivo config.yaml
```yaml
providers:
  luzia:
    enabled: true
    base_url: "https://luzia.azure.paas.santanderbr.pre.corp"
    models:
      - "aws-claude-3-5-sonnet"
      - "aws-claude-3-5-haiku"
      - "amazon-nova-pro-v1"
```

### GitHub Copilot

#### Configuração via Variáveis de Ambiente
```bash
export GITHUB_TOKEN="seu_github_token"
```

#### Configuração no arquivo config.yaml
```yaml
providers:
  github_copilot:
    enabled: true
    base_url: "https://api.githubcopilot.com"
    models:
      - "gpt-4o"
      - "gpt-4o-mini"
```

### OpenAI

#### Configuração via Variáveis de Ambiente
```bash
export OPENAI_API_KEY="sua_api_key"
```

#### Configuração no arquivo config.yaml
```yaml
providers:
  openai:
    enabled: true
    api_key: "${OPENAI_API_KEY}"
    base_url: "https://api.openai.com/v1"
    models:
      - "gpt-4"
      - "gpt-4-turbo-preview"
      - "gpt-3.5-turbo"
```

## Configuração do Sistema RAG

### Configuração Básica
```yaml
rag:
  enabled: true
  knowledge_base_path: "data/cobol_knowledge_base.json"
  max_context_items: 10
  similarity_threshold: 0.7
  auto_learning: true
  learning_threshold: 0.8
```

### Configuração Avançada
```yaml
rag:
  enabled: true
  knowledge_base_path: "data/cobol_knowledge_base.json"
  max_context_items: 15
  similarity_threshold: 0.6
  auto_learning: true
  learning_threshold: 0.85
  max_knowledge_items: 1000
  cleanup_interval: 100
  backup_enabled: true
  backup_interval: 50
```

## Configuração de Análise

### Configuração Padrão
```yaml
analysis:
  depth: "detailed"
  include_comments: true
  include_business_rules: true
  include_technical_details: true
  max_program_size: 50000
  timeout: 300
```

### Configuração para Análise Rápida
```yaml
analysis:
  depth: "basic"
  include_comments: false
  include_business_rules: true
  include_technical_details: false
  max_program_size: 30000
  timeout: 180
```

### Configuração para Análise Profunda
```yaml
analysis:
  depth: "expert"
  include_comments: true
  include_business_rules: true
  include_technical_details: true
  include_modernization_hints: true
  max_program_size: 100000
  timeout: 600
```

## Configuração de Prompts

### Prompts Personalizados

Edite os arquivos em `config/` para personalizar prompts:

#### config/prompts_enhanced.yaml
```yaml
analysis_prompts:
  functional_analysis:
    system: "Você é um especialista em análise de sistemas COBOL com 20 anos de experiência..."
    user: "Analise o seguinte programa COBOL e forneça uma documentação funcional completa..."
    
  business_rules:
    system: "Você é um analista de negócios especializado em sistemas bancários..."
    user: "Extraia e documente todas as regras de negócio do programa COBOL..."
```

#### config/prompts_especialista.yaml
```yaml
expert_prompts:
  technical_analysis:
    system: "Você é um arquiteto de software sênior especializado em modernização de sistemas COBOL..."
    user: "Realize uma análise técnica profunda do programa COBOL..."
    
  modernization_analysis:
    system: "Você é um consultor de modernização de sistemas legados..."
    user: "Identifique oportunidades de modernização no programa COBOL..."
```

## Configuração de Logging

### Configuração Básica
```yaml
logging:
  level: "INFO"
  format: "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
  file: "logs/cobol_analyzer.log"
  max_size: "10MB"
  backup_count: 5
```

### Configuração para Debug
```yaml
logging:
  level: "DEBUG"
  format: "%(asctime)s - %(name)s - %(levelname)s - %(funcName)s:%(lineno)d - %(message)s"
  file: "logs/cobol_analyzer_debug.log"
  max_size: "50MB"
  backup_count: 10
  console: true
```

## Configuração de Saída

### Configuração de Documentação
```yaml
output:
  format: "markdown"
  include_metadata: true
  include_statistics: true
  generate_html: false
  generate_pdf: false
  template: "doc_legado_pro"
```

### Configuração para Relatórios HTML
```yaml
output:
  format: "markdown"
  include_metadata: true
  include_statistics: true
  generate_html: true
  generate_pdf: true
  template: "professional_report"
  html_theme: "corporate"
```

## Configuração de Performance

### Configuração para Alta Performance
```yaml
performance:
  parallel_processing: true
  max_workers: 4
  batch_size: 10
  cache_enabled: true
  cache_size: 100
  timeout: 300
```

### Configuração para Baixo Consumo de Recursos
```yaml
performance:
  parallel_processing: false
  max_workers: 1
  batch_size: 1
  cache_enabled: false
  timeout: 180
```

## Configuração de Segurança

### Configuração Segura
```yaml
security:
  sanitize_logs: true
  mask_sensitive_data: true
  secure_temp_files: true
  cleanup_temp_files: true
  max_file_size: "10MB"
  allowed_extensions: [".cbl", ".cpy", ".txt"]
```

## Configuração por Ambiente

### Desenvolvimento
```yaml
# config/config_dev.yaml
ai:
  primary_provider: "enhanced_mock"
  fallback_providers: ["basic"]

analysis:
  depth: "basic"
  timeout: 60

logging:
  level: "DEBUG"
  console: true

rag:
  auto_learning: false
```

### Teste
```yaml
# config/config_test.yaml
ai:
  primary_provider: "enhanced_mock"
  fallback_providers: ["github_copilot"]

analysis:
  depth: "detailed"
  timeout: 180

logging:
  level: "INFO"

rag:
  auto_learning: true
  learning_threshold: 0.9
```

### Produção
```yaml
# config/config_prod.yaml
ai:
  primary_provider: "luzia"
  fallback_providers: ["github_copilot", "enhanced_mock"]

analysis:
  depth: "detailed"
  timeout: 300

logging:
  level: "INFO"
  console: false

rag:
  auto_learning: true
  learning_threshold: 0.8

security:
  sanitize_logs: true
  mask_sensitive_data: true
```

## Configuração de Modelos

### Seleção Automática de Modelo
```yaml
model_selection:
  auto_select: true
  criteria:
    - complexity
    - file_size
    - analysis_type
  
  rules:
    - condition: "file_size > 10000"
      model: "aws-claude-3-5-sonnet"
    - condition: "analysis_type == 'consolidado'"
      model: "aws-claude-3-5-sonnet"
    - condition: "analysis_type == 'basic'"
      model: "aws-claude-3-5-haiku"
```

### Configuração de Fallback
```yaml
fallback:
  enabled: true
  max_retries: 3
  retry_delay: 5
  fallback_sequence:
    - "luzia"
    - "github_copilot"
    - "enhanced_mock"
    - "basic"
```

## Configuração de Custos

### Monitoramento de Custos
```yaml
cost_management:
  enabled: true
  daily_limit: 100.00
  monthly_limit: 2000.00
  currency: "USD"
  alert_threshold: 0.8
  auto_stop: false
```

### Configuração de Preços
```yaml
pricing:
  luzia:
    input_token_cost: 0.0001
    output_token_cost: 0.0002
  
  github_copilot:
    input_token_cost: 0.00001
    output_token_cost: 0.00002
  
  openai:
    gpt-4:
      input_token_cost: 0.00003
      output_token_cost: 0.00006
```

## Configuração de Cache

### Cache de Respostas
```yaml
cache:
  enabled: true
  type: "file"
  location: "cache/"
  ttl: 3600
  max_size: "100MB"
  compression: true
```

### Cache de Tokens
```yaml
token_cache:
  enabled: true
  ttl: 1800
  refresh_threshold: 300
```

## Configuração de Backup

### Backup Automático
```yaml
backup:
  enabled: true
  interval: "daily"
  retention: 30
  location: "backups/"
  compress: true
  include:
    - "config/"
    - "data/"
    - "logs/"
```

## Validação de Configuração

### Comando de Validação
```bash
# Validar configuração atual
cobol-to-docs --validate-config

# Validar configuração específica
cobol-to-docs --validate-config --config config/config_prod.yaml
```

### Teste de Conectividade
```bash
# Testar conectividade com provedores
cobol-to-docs --test-providers

# Testar provider específico
cobol-to-docs --test-provider luzia
```

## Migração de Configuração

### Migração de Versão Anterior
```bash
# Migrar configuração da v3.0 para v3.1
cobol-to-docs --migrate-config --from-version 3.0 --to-version 3.1
```

### Backup antes da Migração
```bash
# Fazer backup da configuração atual
cobol-to-docs --backup-config --output config_backup_$(date +%Y%m%d).tar.gz
```

## Troubleshooting de Configuração

### Problemas Comuns

#### Provider não inicializa
1. Verificar credenciais
2. Verificar conectividade
3. Verificar configuração YAML

#### RAG não funciona
1. Verificar se base de conhecimento existe
2. Verificar permissões de arquivo
3. Verificar configuração RAG

#### Performance baixa
1. Ajustar configurações de performance
2. Verificar recursos do sistema
3. Otimizar configuração de cache

### Comandos de Diagnóstico
```bash
# Diagnóstico completo
cobol-to-docs --diagnose

# Verificar configuração
cobol-to-docs --check-config

# Verificar status do sistema
cobol-to-docs --system-status
```
