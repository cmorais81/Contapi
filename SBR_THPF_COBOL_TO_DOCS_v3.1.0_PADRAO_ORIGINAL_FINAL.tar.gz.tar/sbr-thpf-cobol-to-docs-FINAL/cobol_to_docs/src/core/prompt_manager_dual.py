"""
COBOL AI Engine v2.1.0 - Dual Prompt Manager
Gerenciador de prompts que suporta múltiplos padrões de análise com arquivos separados.
"""

import logging
from typing import Dict, List, Any, Optional
from datetime import datetime
import yaml
import os

class DualPromptManager:
    """
    Gerenciador de prompts que suporta múltiplos padrões de análise:
    - original: Análise técnica tradicional (prompts_original.yaml)
    - doc_legado_pro: Documentação sistêmica especializada (prompts_doc_legado_pro.yaml)
    """
    
    def __init__(self, config: Dict[str, Any], prompt_set: str = None, custom_prompts_file: str = None):
        """
        Inicializa o gerenciador de prompts dual.
        
        Args:
            config: Configuração geral do sistema
            prompt_set: Nome do conjunto de prompts a usar ('original' ou 'doc_legado_pro')
            custom_prompts_file: Arquivo YAML personalizado de prompts (opcional)
        """
        self.logger = logging.getLogger(__name__)
        self.config = config
        self.custom_prompts_file = custom_prompts_file
        
        # Definir conjunto de prompts ativo
        if custom_prompts_file:
            self.active_prompt_set = 'custom'
        else:
            self.active_prompt_set = prompt_set or 'original'
        
        # Carregar configuração de prompts específica
        self.prompts_config = self._load_prompts_config()
        
        # Validar se carregou corretamente
        if not self.prompts_config or 'system_prompt' not in self.prompts_config:
            self.logger.error(f"Falha ao carregar prompts para {self.active_prompt_set}")
            self.active_prompt_set = 'original'
            self.prompts_config = self._load_prompts_config()
        
        self.logger.info(f"Dual Prompt Manager inicializado - Conjunto ativo: {self.active_prompt_set}")
    
    def _load_prompts_config(self) -> Dict[str, Any]:
        """Carrega a configuração de prompts do arquivo YAML específico."""
        try:
            if self.active_prompt_set == 'custom' and self.custom_prompts_file:
                prompts_file = self.custom_prompts_file
            else:
                # Mapear conjunto para arquivo
                prompt_files = {
                    'original': 'prompts_original.yaml',
                    'doc_legado_pro': 'prompts_doc_legado_pro.yaml'
                }
                
                prompts_file = prompt_files.get(self.active_prompt_set, 'prompts_original.yaml')
            
            # Tentar carregar do diretório config
            config_dir = self.config.get('config_dir', 'config')
            full_path = os.path.join(config_dir, prompts_file)
            
            if os.path.exists(full_path):
                with open(full_path, 'r', encoding='utf-8') as f:
                    config = yaml.safe_load(f)
                    self.logger.info(f"Prompts carregados de: {full_path}")
                    return config
            else:
                self.logger.warning(f"Arquivo de prompts não encontrado: {full_path}")
                return self._get_default_prompts()
                
        except Exception as e:
            self.logger.error(f"Erro ao carregar prompts: {e}")
            return self._get_default_prompts()
    
    def _get_default_prompts(self) -> Dict[str, Any]:
        """Retorna prompts padrão se não conseguir carregar do arquivo."""
        return {
            'version': '2.1.0',
            'system_prompt': """Você é um analista de sistemas COBOL especializado.
Sua tarefa é realizar uma análise detalhada e técnica do programa COBOL fornecido.
Responda sempre em português brasileiro.
Forneça análises precisas e detalhadas sobre estrutura, lógica de negócio e aspectos técnicos.""",
            'analysis_questions': {
                'structure': {
                    'question': 'Qual é a estrutura geral do programa?',
                    'description': 'Descreva as divisões, seções e principais componentes'
                },
                'business_logic': {
                    'question': 'Qual é a lógica de negócio implementada?',
                    'description': 'Explique o propósito e funcionamento do programa'
                },
                'data_flow': {
                    'question': 'Como é o fluxo de dados?',
                    'description': 'Descreva entrada, processamento e saída de dados'
                }
            }
        }
    
    def get_available_prompt_sets(self) -> List[Dict[str, str]]:
        """Retorna lista de conjuntos de prompts disponíveis."""
        return [
            {
                'name': 'original',
                'title': 'Análise Técnica Original',
                'description': 'Análise técnica tradicional focada em estrutura e lógica'
            },
            {
                'name': 'doc_legado_pro',
                'title': 'Documentação Sistêmica Especializada',
                'description': 'Documentação profissional para sistemas legados'
            }
        ]
    
    def get_system_prompt(self) -> str:
        """Retorna o prompt de sistema do conjunto ativo."""
        system_prompt = self.prompts_config.get('system_prompt', '')
        
        # Fallback para prompt de sistema padrão
        if not system_prompt:
            system_prompt = """Você é um analista de sistemas COBOL especializado.
Sua tarefa é realizar uma análise detalhada e técnica do programa COBOL fornecido.
Responda sempre em português brasileiro.
Forneça análises precisas e detalhadas sobre estrutura, lógica de negócio e aspectos técnicos."""
        
        return system_prompt
    
    def get_analysis_questions(self) -> Dict[str, Any]:
        """Retorna as questões de análise do conjunto ativo."""
        return self.prompts_config.get('analysis_questions', {})
    
    def generate_base_prompt(self, program_name: str, program_code: str, context: Dict[str, Any] = None) -> str:
        """
        Gera o prompt base para análise do programa no formato compatível com LuziaProvider.
        
        Args:
            program_name: Nome do programa
            program_code: Código do programa
            context: Contexto adicional
            
        Returns:
            Prompt formatado com separador correto
        """
        if context is None:
            context = {}
        
        # Obter configurações
        system_prompt = self.get_system_prompt()
        analysis_questions = self.get_analysis_questions()
        
        # Construir prompt no formato esperado pelo LuziaProvider
        prompt_parts = [system_prompt]
        
        # Adicionar informações de contexto se disponível
        if context.get('books'):
            prompt_parts.append(f"\nCopybooks relacionados: {len(context.get('books', []))}")
        
        # SEPARADOR OBRIGATÓRIO que o LuziaProvider espera
        prompt_parts.append(f"\n=== PROGRAMA COBOL PARA ANÁLISE APROFUNDADA ===")
        
        prompt_parts.append(f"Nome do programa: {program_name}")
        prompt_parts.append(f"Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        prompt_parts.append(f"\nCódigo do programa:\n{program_code}")
        
        # Adicionar perguntas específicas
        if analysis_questions:
            prompt_parts.append(f"\nPor favor, responda às seguintes perguntas específicas:")
            
            for i, (key, question_data) in enumerate(analysis_questions.items(), 1):
                if isinstance(question_data, dict):
                    question = question_data.get('question', str(question_data))
                    description = question_data.get('description', '')
                else:
                    question = str(question_data)
                    description = ''
                
                prompt_parts.append(f"\n{i}. {question}")
                if description:
                    prompt_parts.append(f"   ({description})")
        
        prompt_parts.append(f"\nForneça uma análise completa e detalhada em português brasileiro.")
        
        return '\n'.join(prompt_parts)

    def generate_multiple_programs_prompt(self, programs: Dict[str, str], copybooks: Dict[str, str] = None, context: Dict[str, Any] = None) -> str:
        """
        Gera prompt para análise de múltiplos programas no formato correto.
        
        Args:
            programs: Dicionário {nome_programa: código_programa}
            copybooks: Dicionário {nome_copybook: código_copybook} (opcional)
            context: Contexto adicional
            
        Returns:
            Prompt formatado para múltiplos programas
        """
        if context is None:
            context = {}
        
        # Obter configurações
        system_prompt = self.get_system_prompt()
        
        # Construir prompt para múltiplos programas
        prompt_parts = [system_prompt]
        
        # SEPARADOR OBRIGATÓRIO que o LuziaProvider espera
        prompt_parts.append(f"\n=== PROGRAMAS COBOL PARA ANÁLISE SISTÊMICA ===")
        prompt_parts.append(f"Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        prompt_parts.append(f"Total de programas: {len(programs)}")
        
        # Adicionar cada programa com separador específico
        for prog_name, prog_code in programs.items():
            prompt_parts.append(f"\n--- PROGRAMA {prog_name} ---")
            prompt_parts.append(prog_code)
            prompt_parts.append("")
        
        # Copybooks se existirem
        if copybooks:
            prompt_parts.append("=== COPYBOOKS DO SISTEMA ===")
            for book_name, book_code in copybooks.items():
                prompt_parts.append(f"\n--- COPYBOOK {book_name} ---")
                prompt_parts.append(book_code)
                prompt_parts.append("")
        
        # Instruções para análise sistêmica
        prompt_parts.append("=== INSTRUÇÕES PARA ANÁLISE SISTÊMICA ===")
        prompt_parts.append("")
        prompt_parts.append("Como ARQUITETO DE SISTEMAS COBOL, forneça uma análise técnica DETALHADA que inclua:")
        prompt_parts.append("")
        prompt_parts.append("## 1. ARQUITETURA E DESIGN DO SISTEMA")
        prompt_parts.append("- Padrão arquitetural utilizado")
        prompt_parts.append("- Estratégia de modularização")
        prompt_parts.append("- Acoplamento e coesão entre componentes")
        prompt_parts.append("")
        prompt_parts.append("## 2. FLUXO DE DADOS E INTEGRAÇÃO")
        prompt_parts.append("- Mapeamento do fluxo de dados entre programas")
        prompt_parts.append("- Pontos de integração")
        prompt_parts.append("- Dependências entre programas e copybooks")
        prompt_parts.append("")
        prompt_parts.append("## 3. ANÁLISE TÉCNICA DETALHADA")
        prompt_parts.append("- Qualidade do código")
        prompt_parts.append("- Complexidade e manutenibilidade")
        prompt_parts.append("- Tratamento de erros")
        prompt_parts.append("")
        prompt_parts.append("Forneça uma análise completa e detalhada em português brasileiro.")
        
        return '\n'.join(prompt_parts)
    
    def get_context_template(self, program_type: str = 'default') -> str:
        """Retorna template de contexto para tipo de programa."""
        context_templates = self.prompts_config.get('context_templates', {})
        return context_templates.get(program_type, context_templates.get('default', 'Programa COBOL genérico'))
    
    def get_prompt_info(self) -> Dict[str, Any]:
        """Retorna informações sobre o conjunto de prompts ativo."""
        available_sets = self.get_available_prompt_sets()
        active_info = next((ps for ps in available_sets if ps['name'] == self.active_prompt_set), {})
        
        return {
            'active_set': self.active_prompt_set,
            'title': active_info.get('title', 'Desconhecido'),
            'description': active_info.get('description', ''),
            'version': self.prompts_config.get('version', '2.1.0'),
            'available_sets': available_sets
        }
    
    def validate_prompt_compatibility(self, model_name: str) -> bool:
        """
        Valida se o modelo é compatível com o conjunto de prompts ativo.
        
        Args:
            model_name: Nome do modelo
            
        Returns:
            True se compatível
        """
        # Verificar se há prompts específicos para o modelo
        model_prompts = self.prompts_config.get('model_prompts', {})
        
        # Se não há prompts específicos, usar o padrão (sempre compatível)
        if not model_prompts:
            return True
        
        # Se há prompts específicos, verificar se o modelo está incluído
        return model_name in model_prompts or 'system_prompt' in self.prompts_config
