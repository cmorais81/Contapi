# INSTRUÇÕES PARA WINDOWS - SISTEMA DE GOVERNANÇA v1.1

**Guia completo para executar o Sistema de Governança de Dados em Windows com Python 3.13**

---

## PRÉ-REQUISITOS

### 1. Python 3.13
```bash
# Baixar do site oficial
https://www.python.org/downloads/

# Verificar instalação
python --version
# Deve mostrar: Python 3.13.x
```

### 2. PostgreSQL (Opcional para desenvolvimento)
```bash
# Baixar PostgreSQL 15+
https://www.postgresql.org/download/windows/

# Configuração básica:
# - Usuário: postgres
# - Senha: postgres
# - Porta: 5432
# - Database: governanca
```

### 3. Redis (Opcional para desenvolvimento)
```bash
# Baixar Redis para Windows
https://github.com/microsoftarchive/redis/releases

# Ou usar Docker Desktop:
docker run -d -p 6379:6379 redis:7
```

---

## INSTALAÇÃO RÁPIDA

### 1. Extrair o Sistema
```bash
# Extrair o arquivo sistema-governanca-v1.1-operacional-completo.tar.gz
# Para uma pasta, exemplo: C:\governanca\
```

### 2. Abrir Terminal
```bash
# Abrir PowerShell ou CMD como Administrador
# Navegar para a pasta do sistema
cd C:\governanca\TESTE_PRODUCAO\GOVERNANCA_PRODUCAO
```

### 3. Executar o Sistema
```bash
# Opção 1: Menu interativo (recomendado)
python run_windows.py

# Opção 2: Início rápido (serviços essenciais)
python run_windows.py --quick

# Opção 3: Todos os serviços
python run_windows.py --all

# Opção 4: Serviço específico
python run_windows.py --service api-gateway
```

---

## MODOS DE EXECUÇÃO

### 1. MODO INTERATIVO (Recomendado)
```bash
python run_windows.py
```

**Menu disponível:**
- 🚀 Início Rápido (serviços essenciais)
- 🌟 Iniciar todos os serviços
- 📊 Ver status dos serviços
- 🔧 Iniciar serviço específico
- 🛑 Parar todos os serviços
- 📋 Listar serviços disponíveis
- ❌ Sair

### 2. INÍCIO RÁPIDO
```bash
python run_windows.py --quick
```

**Inicia apenas os serviços essenciais:**
- API Gateway (porta 8000)
- Contract Service (porta 8001)
- Quality Service (porta 8002)
- Identity Service (porta 8005)

### 3. TODOS OS SERVIÇOS
```bash
python run_windows.py --all
```

**Inicia todos os 8 microserviços:**
- API Gateway (8000)
- Contract Service (8001)
- Quality Service (8002)
- Discovery Service (8003)
- Audit Service (8004)
- Identity Service (8005)
- ODCS Compliance (8010)
- ODCS Export (8011)

### 4. SERVIÇO ESPECÍFICO
```bash
# Exemplos:
python run_windows.py --service api-gateway
python run_windows.py --service contract-service
python run_windows.py --service odcs-compliance-service
```

---

## SERVIÇOS DISPONÍVEIS

### SERVIÇOS ESSENCIAIS ⭐

| Serviço | Porta | Descrição | URL |
|---------|-------|-----------|-----|
| **api-gateway** | 8000 | Gateway principal | http://localhost:8000 |
| **contract-service** | 8001 | Contratos ODCS | http://localhost:8001 |
| **quality-service** | 8002 | Qualidade de dados | http://localhost:8002 |
| **identity-service** | 8005 | Autenticação | http://localhost:8005 |

### SERVIÇOS OPCIONAIS

| Serviço | Porta | Descrição | URL |
|---------|-------|-----------|-----|
| **discovery-service** | 8003 | Descoberta de dados | http://localhost:8003 |
| **audit-service** | 8004 | Auditoria | http://localhost:8004 |
| **odcs-compliance-service** | 8010 | Conformidade ODCS | http://localhost:8010 |
| **odcs-export-service** | 8011 | Export/Import ODCS | http://localhost:8011 |

---

## ENDPOINTS PRINCIPAIS

### API Gateway (http://localhost:8000)
```bash
# Health check
GET http://localhost:8000/health

# Documentação Swagger
GET http://localhost:8000/docs

# Roteamento para outros serviços
GET http://localhost:8000/api/v1/contracts
GET http://localhost:8000/api/v1/quality/rules
```

### Contract Service (http://localhost:8001)
```bash
# Listar contratos
GET http://localhost:8001/api/v1/contracts

# Criar contrato
POST http://localhost:8001/api/v1/contracts

# Campos pré-definidos ODCS
GET http://localhost:8001/api/v1/odcs/contracts/{id}/schema/objects/{object}/properties/{property}/valid-values
```

### Quality Service (http://localhost:8002)
```bash
# Dimensões de qualidade ODCS
GET http://localhost:8002/api/v1/odcs/quality/dimensions

# Tipos de regras ODCS
GET http://localhost:8002/api/v1/odcs/quality/rules/types

# Criar regra de qualidade
POST http://localhost:8002/api/v1/quality/rules
```

### ODCS Compliance (http://localhost:8010)
```bash
# Validar conformidade ODCS
POST http://localhost:8010/api/v1/compliance/validate

# Relatório de conformidade
GET http://localhost:8010/api/v1/compliance/report/{contract_id}
```

---

## CONFIGURAÇÃO DE AMBIENTE

### Variáveis Automáticas
O script configura automaticamente:
```bash
DATABASE_URL=postgresql://postgres:postgres@localhost:5432/governanca
REDIS_URL=redis://localhost:6379
JWT_SECRET=dev-secret-key
ENVIRONMENT=development
PYTHONPATH=<caminho_do_projeto>
```

### Personalizar Configuração
Criar arquivo `.env` na pasta raiz:
```bash
# .env
DATABASE_URL=postgresql://seu_usuario:sua_senha@localhost:5432/sua_base
REDIS_URL=redis://localhost:6379
JWT_SECRET=sua-chave-secreta
ENVIRONMENT=production
LOG_LEVEL=INFO
```

---

## LOGS E MONITORAMENTO

### Localização dos Logs
```bash
# Logs são salvos em:
logs/api-gateway.log
logs/contract-service.log
logs/quality-service.log
# ... etc
```

### Ver Logs em Tempo Real
```bash
# Windows PowerShell
Get-Content logs\api-gateway.log -Wait

# CMD
type logs\api-gateway.log
```

### Status dos Serviços
```bash
# Ver status
python run_windows.py --status

# Ou no menu interativo: opção 3
```

---

## TESTES E VALIDAÇÃO

### Testar Endpoints
```bash
# Instalar curl para Windows ou usar PowerShell
# Teste básico do API Gateway
curl http://localhost:8000/health

# PowerShell
Invoke-RestMethod -Uri "http://localhost:8000/health"
```

### Executar Testes Completos
```bash
# Testes de integração
python test_all_endpoints_comprehensive.py

# Validação ODCS
python validate_odcs_implementation.py
```

### Popular Base com Dados de Teste
```bash
# Se tiver PostgreSQL configurado
psql -U postgres -d governanca -f database/scripts/mock_data_complete.sql
```

---

## SOLUÇÃO DE PROBLEMAS

### Erro: "Porta já em uso"
```bash
# Verificar processos usando a porta
netstat -ano | findstr :8000

# Matar processo específico
taskkill /PID <numero_do_pid> /F
```

### Erro: "Módulo não encontrado"
```bash
# Instalar dependências manualmente
pip install fastapi uvicorn psycopg2-binary redis pydantic sqlalchemy requests

# Ou deixar o script instalar automaticamente
python run_windows.py
```

### Erro: "Conexão com banco de dados"
```bash
# Verificar se PostgreSQL está rodando
# Ou usar modo desenvolvimento sem banco:
# O sistema funcionará com dados em memória
```

### Erro: "Permission denied"
```bash
# Executar PowerShell como Administrador
# Ou verificar antivírus bloqueando execução
```

---

## DESENVOLVIMENTO E CUSTOMIZAÇÃO

### Estrutura do Projeto
```
GOVERNANCA_PRODUCAO/
├── apps/                    # Microserviços
│   ├── api-gateway/
│   ├── contract-service/
│   ├── quality-service/
│   └── ...
├── database/               # Scripts de banco
├── docs/                   # Documentação
├── logs/                   # Logs dos serviços
├── run_windows.py         # Script principal
└── run_microservices.py   # Script avançado
```

### Adicionar Novo Serviço
1. Criar pasta em `apps/novo-servico/`
2. Adicionar configuração em `run_windows.py`
3. Definir porta e dependências

### Modificar Configuração
Editar o dicionário `self.services` em `run_windows.py`:
```python
"novo-servico": {
    "name": "Novo Serviço",
    "port": 8012,
    "path": "apps/novo-servico/main.py",
    "essential": False
}
```

---

## COMANDOS ÚTEIS

### Comandos Básicos
```bash
# Menu interativo
python run_windows.py

# Ajuda
python run_windows.py --help

# Status rápido
python run_windows.py --status

# Pular verificação de dependências
python run_windows.py --no-deps
```

### Comandos Avançados
```bash
# Script completo com mais opções
python run_microservices.py --interactive

# Logs específicos
python run_microservices.py --logs contract-service

# Validação de dependências
python run_microservices.py --check-deps
```

---

## PRÓXIMOS PASSOS

### 1. Desenvolvimento
- Configurar IDE (VS Code, PyCharm)
- Instalar extensões Python
- Configurar debugger

### 2. Produção
- Configurar banco PostgreSQL dedicado
- Configurar Redis em cluster
- Implementar load balancer

### 3. Monitoramento
- Configurar Prometheus/Grafana
- Implementar alertas
- Configurar backup automático

---

## SUPORTE

### Documentação
- Swagger UI: http://localhost:8000/docs
- Relatórios: `RELATORIO_FINAL_SISTEMA_OPERACIONAL.md`
- Arquitetura: `docs/ARQUITETURA_SISTEMA_V1.md`

### Logs de Erro
- Verificar arquivos em `logs/`
- Executar com `--debug` para mais detalhes
- Verificar variáveis de ambiente

### Contato
- Documentação técnica completa incluída
- Exemplos de uso em `database/scripts/`
- Testes automatizados disponíveis

---

**Sistema de Governança de Dados v1.1**  
**Compatível com Windows 10/11 + Python 3.13**  
**Execução nativa sem Docker**

