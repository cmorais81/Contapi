# Sistema de Governança de Dados - PRODUÇÃO

## Instalação Rápida

### 1. Pré-requisitos
```bash
# Python 3.13
python3.13 --version

# PostgreSQL
sudo apt install postgresql postgresql-contrib

# Redis
sudo apt install redis-server
```

### 2. Configuração do Banco
```bash
# Criar banco
sudo -u postgres createuser governance_user
sudo -u postgres createdb governance_system
sudo -u postgres psql -c "ALTER USER governance_user WITH PASSWORD 'governance_pass';"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE governance_system TO governance_user;"

# Executar scripts
cd database/scripts
./run_scripts.sh
```

### 3. Instalação
```bash
# Dependências
pip3.13 install -r requirements.txt

# Configuração
cp .env.example .env
# Editar .env conforme necessário
```

### 4. Execução
```bash
# Iniciar sistema
python3.13 main.py

# Verificar
curl http://localhost:8000/health
```

## Estrutura

- **apps/**: 31 microserviços (portas 8000-8030)
- **config/**: Configuração centralizada
- **database/**: Modelo DBML + Scripts SQL
- **main.py**: Executor principal
- **requirements.txt**: Dependências Python 3.13

## Funcionalidades

- 31 microserviços funcionais
- 1042 endpoints REST
- 43 tabelas de dados
- Integração Databricks Unity Catalog
- Integração Informatica Axon
- Compliance LGPD/GDPR/SOX

## Suporte

Sistema validado para Python 3.13
Pronto para produção imediata

