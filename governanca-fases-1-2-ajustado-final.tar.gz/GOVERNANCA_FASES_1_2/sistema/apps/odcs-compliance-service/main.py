"""
ODCS Compliance Service
Microserviço responsável pela validação de conformidade ODCS v3.0.2

Funcionalidades:
- Validação de contratos ODCS
- Verificação de conformidade
- Relatórios de compliance
- Sugestões de correção
- Auditoria de conformidade

Autor: Sistema de Governança v1.1
Data: 2025-08-12
"""

from fastapi import FastAPI, HTTPException, Depends, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field, validator
from typing import List, Optional, Dict, Any, Union
from datetime import datetime, timezone
from uuid import UUID, uuid4
import asyncio
import json
import logging
from enum import Enum

# Configuração de logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Configuração da aplicação
app = FastAPI(
    title="ODCS Compliance Service",
    description="Serviço de validação de conformidade ODCS v3.0.2",
    version="1.1.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# =====================================================
# MODELOS DE DADOS (DOMAIN ENTITIES)
# =====================================================

class ComplianceLevel(str, Enum):
    """Níveis de conformidade ODCS"""
    FULL = "full"
    PARTIAL = "partial"
    NON_COMPLIANT = "non_compliant"
    UNKNOWN = "unknown"

class ValidationSeverity(str, Enum):
    """Severidade das validações"""
    ERROR = "error"
    WARNING = "warning"
    INFO = "info"

class ODCSVersion(str, Enum):
    """Versões ODCS suportadas"""
    V3_0_0 = "v3.0.0"
    V3_0_1 = "v3.0.1"
    V3_0_2 = "v3.0.2"

class ValidationRule(BaseModel):
    """Regra de validação ODCS"""
    id: UUID = Field(default_factory=uuid4)
    name: str = Field(..., description="Nome da regra")
    description: str = Field(..., description="Descrição da regra")
    category: str = Field(..., description="Categoria da regra")
    severity: ValidationSeverity = Field(..., description="Severidade")
    odcs_section: str = Field(..., description="Seção ODCS relacionada")
    validation_logic: Dict[str, Any] = Field(..., description="Lógica de validação")
    is_active: bool = Field(default=True)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class ValidationResult(BaseModel):
    """Resultado de uma validação"""
    rule_id: UUID = Field(..., description="ID da regra aplicada")
    rule_name: str = Field(..., description="Nome da regra")
    status: str = Field(..., description="Status da validação")
    severity: ValidationSeverity = Field(..., description="Severidade")
    message: str = Field(..., description="Mensagem do resultado")
    details: Optional[Dict[str, Any]] = Field(None, description="Detalhes adicionais")
    suggestion: Optional[str] = Field(None, description="Sugestão de correção")
    field_path: Optional[str] = Field(None, description="Caminho do campo com problema")

class ComplianceReport(BaseModel):
    """Relatório de conformidade ODCS"""
    id: UUID = Field(default_factory=uuid4)
    contract_id: UUID = Field(..., description="ID do contrato validado")
    contract_name: str = Field(..., description="Nome do contrato")
    odcs_version: ODCSVersion = Field(..., description="Versão ODCS validada")
    compliance_level: ComplianceLevel = Field(..., description="Nível de conformidade")
    overall_score: float = Field(..., ge=0, le=100, description="Score geral (0-100)")
    total_rules: int = Field(..., ge=0, description="Total de regras aplicadas")
    passed_rules: int = Field(..., ge=0, description="Regras que passaram")
    failed_rules: int = Field(..., ge=0, description="Regras que falharam")
    warnings: int = Field(..., ge=0, description="Número de warnings")
    validation_results: List[ValidationResult] = Field(..., description="Resultados detalhados")
    suggestions: List[str] = Field(default_factory=list, description="Sugestões de melhoria")
    validated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    validated_by: Optional[str] = Field(None, description="Usuário que executou a validação")

class ContractValidationRequest(BaseModel):
    """Request para validação de contrato"""
    contract_id: UUID = Field(..., description="ID do contrato")
    odcs_version: ODCSVersion = Field(default=ODCSVersion.V3_0_2, description="Versão ODCS")
    validation_categories: Optional[List[str]] = Field(None, description="Categorias específicas")
    include_warnings: bool = Field(default=True, description="Incluir warnings")
    deep_validation: bool = Field(default=False, description="Validação profunda")

class BatchValidationRequest(BaseModel):
    """Request para validação em lote"""
    contract_ids: List[UUID] = Field(..., min_items=1, max_items=100, description="IDs dos contratos")
    odcs_version: ODCSVersion = Field(default=ODCSVersion.V3_0_2)
    validation_categories: Optional[List[str]] = Field(None)
    include_warnings: bool = Field(default=True)

class ComplianceMetrics(BaseModel):
    """Métricas de conformidade globais"""
    total_contracts: int = Field(..., ge=0)
    compliant_contracts: int = Field(..., ge=0)
    partially_compliant: int = Field(..., ge=0)
    non_compliant: int = Field(..., ge=0)
    average_score: float = Field(..., ge=0, le=100)
    compliance_percentage: float = Field(..., ge=0, le=100)
    last_updated: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

# =====================================================
# SERVIÇOS DE NEGÓCIO (APPLICATION LAYER)
# =====================================================

class ODCSValidationService:
    """Serviço de validação ODCS - Single Responsibility Principle"""
    
    def __init__(self):
        self.validation_rules = self._load_validation_rules()
    
    def _load_validation_rules(self) -> List[ValidationRule]:
        """Carrega regras de validação ODCS"""
        return [
            # Fundamentals
            ValidationRule(
                name="api_version_required",
                description="Campo apiVersion é obrigatório",
                category="fundamentals",
                severity=ValidationSeverity.ERROR,
                odcs_section="fundamentals",
                validation_logic={"field": "apiVersion", "required": True}
            ),
            ValidationRule(
                name="kind_datacontract",
                description="Campo kind deve ser 'DataContract'",
                category="fundamentals",
                severity=ValidationSeverity.ERROR,
                odcs_section="fundamentals",
                validation_logic={"field": "kind", "value": "DataContract"}
            ),
            ValidationRule(
                name="domain_recommended",
                description="Campo domain é recomendado",
                category="fundamentals",
                severity=ValidationSeverity.WARNING,
                odcs_section="fundamentals",
                validation_logic={"field": "domain", "recommended": True}
            ),
            
            # Schema
            ValidationRule(
                name="schema_objects_required",
                description="Pelo menos um objeto no schema é obrigatório",
                category="schema",
                severity=ValidationSeverity.ERROR,
                odcs_section="schema",
                validation_logic={"field": "schema.objects", "min_items": 1}
            ),
            ValidationRule(
                name="logical_type_valid",
                description="logicalType deve ser um tipo válido ODCS",
                category="schema",
                severity=ValidationSeverity.ERROR,
                odcs_section="schema",
                validation_logic={
                    "field": "schema.objects[].properties[].logicalType",
                    "enum": ["string", "number", "integer", "boolean", "date", "datetime", "timestamp", "array", "object"]
                }
            ),
            
            # Quality
            ValidationRule(
                name="quality_dimension_valid",
                description="Dimensão de qualidade deve ser válida",
                category="quality",
                severity=ValidationSeverity.ERROR,
                odcs_section="quality",
                validation_logic={
                    "field": "quality[].dimension",
                    "enum": ["conformity", "accuracy", "completeness", "consistency", "timeliness", "validity", "uniqueness", "integrity"]
                }
            ),
            
            # Servers
            ValidationRule(
                name="server_type_valid",
                description="Tipo de servidor deve ser válido",
                category="servers",
                severity=ValidationSeverity.ERROR,
                odcs_section="servers",
                validation_logic={
                    "field": "servers[].type",
                    "enum": ["postgres", "mysql", "oracle", "sqlserver", "databricks", "snowflake", "bigquery", "api", "kafka"]
                }
            ),
            
            # Team
            ValidationRule(
                name="team_owner_required",
                description="Pelo menos um owner na equipe é obrigatório",
                category="team",
                severity=ValidationSeverity.ERROR,
                odcs_section="team",
                validation_logic={"field": "team", "required_role": "owner"}
            )
        ]
    
    async def validate_contract(self, contract_data: Dict[str, Any], 
                              odcs_version: ODCSVersion = ODCSVersion.V3_0_2) -> List[ValidationResult]:
        """Valida um contrato contra as regras ODCS"""
        results = []
        
        for rule in self.validation_rules:
            if not rule.is_active:
                continue
                
            try:
                result = await self._apply_validation_rule(contract_data, rule)
                if result:
                    results.append(result)
            except Exception as e:
                logger.error(f"Erro ao aplicar regra {rule.name}: {str(e)}")
                results.append(ValidationResult(
                    rule_id=rule.id,
                    rule_name=rule.name,
                    status="error",
                    severity=ValidationSeverity.ERROR,
                    message=f"Erro interno na validação: {str(e)}"
                ))
        
        return results
    
    async def _apply_validation_rule(self, contract_data: Dict[str, Any], 
                                   rule: ValidationRule) -> Optional[ValidationResult]:
        """Aplica uma regra específica de validação"""
        logic = rule.validation_logic
        
        # Validação de campo obrigatório
        if logic.get("required"):
            field_path = logic["field"]
            value = self._get_nested_value(contract_data, field_path)
            if value is None:
                return ValidationResult(
                    rule_id=rule.id,
                    rule_name=rule.name,
                    status="failed",
                    severity=rule.severity,
                    message=f"Campo obrigatório '{field_path}' não encontrado",
                    field_path=field_path,
                    suggestion=f"Adicione o campo '{field_path}' ao contrato"
                )
        
        # Validação de valor específico
        if logic.get("value"):
            field_path = logic["field"]
            expected_value = logic["value"]
            actual_value = self._get_nested_value(contract_data, field_path)
            if actual_value != expected_value:
                return ValidationResult(
                    rule_id=rule.id,
                    rule_name=rule.name,
                    status="failed",
                    severity=rule.severity,
                    message=f"Campo '{field_path}' deve ter valor '{expected_value}', encontrado '{actual_value}'",
                    field_path=field_path,
                    suggestion=f"Altere o valor do campo '{field_path}' para '{expected_value}'"
                )
        
        # Validação de enum
        if logic.get("enum"):
            field_path = logic["field"]
            valid_values = logic["enum"]
            
            # Suporte para arrays (ex: schema.objects[].properties[].logicalType)
            if "[]" in field_path:
                values = self._get_array_values(contract_data, field_path)
                for value in values:
                    if value not in valid_values:
                        return ValidationResult(
                            rule_id=rule.id,
                            rule_name=rule.name,
                            status="failed",
                            severity=rule.severity,
                            message=f"Valor '{value}' não é válido para '{field_path}'. Valores válidos: {valid_values}",
                            field_path=field_path,
                            suggestion=f"Use um dos valores válidos: {', '.join(valid_values)}"
                        )
            else:
                actual_value = self._get_nested_value(contract_data, field_path)
                if actual_value and actual_value not in valid_values:
                    return ValidationResult(
                        rule_id=rule.id,
                        rule_name=rule.name,
                        status="failed",
                        severity=rule.severity,
                        message=f"Valor '{actual_value}' não é válido para '{field_path}'",
                        field_path=field_path,
                        suggestion=f"Use um dos valores válidos: {', '.join(valid_values)}"
                    )
        
        # Validação de role obrigatória na equipe
        if logic.get("required_role"):
            required_role = logic["required_role"]
            team = contract_data.get("team", [])
            has_role = any(member.get("role") == required_role for member in team)
            if not has_role:
                return ValidationResult(
                    rule_id=rule.id,
                    rule_name=rule.name,
                    status="failed",
                    severity=rule.severity,
                    message=f"Equipe deve ter pelo menos um membro com role '{required_role}'",
                    field_path="team",
                    suggestion=f"Adicione um membro com role '{required_role}' à equipe"
                )
        
        # Se chegou até aqui, a validação passou
        return None
    
    def _get_nested_value(self, data: Dict[str, Any], path: str) -> Any:
        """Obtém valor aninhado usando notação de ponto"""
        keys = path.split(".")
        current = data
        
        for key in keys:
            if isinstance(current, dict) and key in current:
                current = current[key]
            else:
                return None
        
        return current
    
    def _get_array_values(self, data: Dict[str, Any], path: str) -> List[Any]:
        """Obtém valores de arrays aninhados"""
        # Simplificação para o exemplo - implementação completa seria mais robusta
        if "schema.objects[].properties[].logicalType" in path:
            values = []
            schema = data.get("schema", {})
            objects = schema.get("objects", [])
            for obj in objects:
                properties = obj.get("properties", [])
                for prop in properties:
                    logical_type = prop.get("logicalType")
                    if logical_type:
                        values.append(logical_type)
            return values
        
        return []

class ComplianceReportService:
    """Serviço de relatórios de conformidade - Single Responsibility Principle"""
    
    def __init__(self, validation_service: ODCSValidationService):
        self.validation_service = validation_service
    
    async def generate_compliance_report(self, contract_id: UUID, contract_data: Dict[str, Any],
                                       odcs_version: ODCSVersion = ODCSVersion.V3_0_2) -> ComplianceReport:
        """Gera relatório completo de conformidade"""
        
        # Executar validações
        validation_results = await self.validation_service.validate_contract(contract_data, odcs_version)
        
        # Calcular métricas
        total_rules = len(self.validation_service.validation_rules)
        failed_results = [r for r in validation_results if r.status == "failed"]
        failed_rules = len(failed_results)
        passed_rules = total_rules - failed_rules
        warnings = len([r for r in failed_results if r.severity == ValidationSeverity.WARNING])
        
        # Calcular score
        error_weight = 10
        warning_weight = 3
        info_weight = 1
        
        total_points = total_rules * error_weight
        lost_points = sum(
            error_weight if r.severity == ValidationSeverity.ERROR else
            warning_weight if r.severity == ValidationSeverity.WARNING else
            info_weight
            for r in failed_results
        )
        
        score = max(0, ((total_points - lost_points) / total_points) * 100)
        
        # Determinar nível de conformidade
        if score >= 95:
            compliance_level = ComplianceLevel.FULL
        elif score >= 70:
            compliance_level = ComplianceLevel.PARTIAL
        else:
            compliance_level = ComplianceLevel.NON_COMPLIANT
        
        # Gerar sugestões
        suggestions = self._generate_suggestions(failed_results)
        
        return ComplianceReport(
            contract_id=contract_id,
            contract_name=contract_data.get("name", "Unknown"),
            odcs_version=odcs_version,
            compliance_level=compliance_level,
            overall_score=round(score, 2),
            total_rules=total_rules,
            passed_rules=passed_rules,
            failed_rules=failed_rules,
            warnings=warnings,
            validation_results=validation_results,
            suggestions=suggestions
        )
    
    def _generate_suggestions(self, failed_results: List[ValidationResult]) -> List[str]:
        """Gera sugestões de melhoria baseadas nos resultados"""
        suggestions = []
        
        # Agrupar por categoria
        categories = {}
        for result in failed_results:
            if result.severity == ValidationSeverity.ERROR:
                category = result.rule_name.split("_")[0]
                if category not in categories:
                    categories[category] = []
                categories[category].append(result)
        
        # Gerar sugestões por categoria
        if "api" in categories:
            suggestions.append("Verifique os campos fundamentais do ODCS (apiVersion, kind)")
        
        if "schema" in categories:
            suggestions.append("Revise a estrutura do schema e tipos de dados")
        
        if "quality" in categories:
            suggestions.append("Adicione regras de qualidade com dimensões válidas")
        
        if "team" in categories:
            suggestions.append("Configure adequadamente a equipe responsável")
        
        if "server" in categories:
            suggestions.append("Verifique a configuração dos servidores")
        
        return suggestions

# =====================================================
# CONTROLADORES (PRESENTATION LAYER)
# =====================================================

# Dependências
validation_service = ODCSValidationService()
report_service = ComplianceReportService(validation_service)

@app.get("/health")
async def health_check():
    """Health check do serviço"""
    return {"status": "healthy", "service": "odcs-compliance-service", "version": "1.1.0"}

@app.post("/api/v1/compliance/validate/contract", response_model=ComplianceReport)
async def validate_contract(request: ContractValidationRequest):
    """Valida conformidade ODCS de um contrato específico"""
    try:
        # Simular busca do contrato (em produção, viria do banco)
        contract_data = {
            "apiVersion": "v3.0.2",
            "kind": "DataContract",
            "name": f"Contract {request.contract_id}",
            "domain": "finance",
            "schema": {
                "objects": [
                    {
                        "name": "users",
                        "properties": [
                            {"name": "id", "logicalType": "string"},
                            {"name": "email", "logicalType": "string"}
                        ]
                    }
                ]
            },
            "team": [
                {"name": "John Doe", "role": "owner"}
            ]
        }
        
        report = await report_service.generate_compliance_report(
            request.contract_id, 
            contract_data, 
            request.odcs_version
        )
        
        return report
        
    except Exception as e:
        logger.error(f"Erro na validação do contrato {request.contract_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Erro interno: {str(e)}")

@app.get("/api/v1/compliance/status/{contract_id}")
async def get_compliance_status(contract_id: UUID):
    """Obtém status de conformidade de um contrato"""
    try:
        # Simular busca do último relatório
        return {
            "contract_id": contract_id,
            "compliance_level": "partial",
            "last_validation": datetime.now(timezone.utc).isoformat(),
            "score": 85.5,
            "next_validation": datetime.now(timezone.utc).isoformat()
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/v1/compliance/report/{contract_id}")
async def get_compliance_report(contract_id: UUID):
    """Obtém relatório detalhado de conformidade"""
    try:
        # Simular busca do relatório
        return {
            "contract_id": contract_id,
            "report_url": f"/reports/compliance/{contract_id}.pdf",
            "generated_at": datetime.now(timezone.utc).isoformat()
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/v1/compliance/fix/suggestions")
async def get_fix_suggestions(contract_id: UUID):
    """Obtém sugestões de correção para problemas de conformidade"""
    try:
        return {
            "contract_id": contract_id,
            "suggestions": [
                "Adicione o campo 'domain' ao contrato",
                "Configure pelo menos um servidor no ambiente de produção",
                "Defina regras de qualidade para campos críticos"
            ]
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/v1/compliance/standards/odcs")
async def get_odcs_standards():
    """Obtém padrões ODCS suportados"""
    return {
        "supported_versions": ["v3.0.0", "v3.0.1", "v3.0.2"],
        "current_version": "v3.0.2",
        "validation_categories": [
            "fundamentals", "schema", "quality", "servers", "team", "support", "pricing", "examples"
        ]
    }

@app.get("/api/v1/compliance/checklist/{contract_id}")
async def get_compliance_checklist(contract_id: UUID):
    """Obtém checklist de conformidade ODCS"""
    return {
        "contract_id": contract_id,
        "checklist": [
            {"item": "apiVersion definido", "status": "completed"},
            {"item": "kind = DataContract", "status": "completed"},
            {"item": "domain especificado", "status": "pending"},
            {"item": "schema com objetos", "status": "completed"},
            {"item": "equipe configurada", "status": "completed"},
            {"item": "owner definido", "status": "completed"}
        ]
    }

@app.post("/api/v1/compliance/audit/{contract_id}")
async def audit_contract_compliance(contract_id: UUID):
    """Executa auditoria completa de conformidade"""
    try:
        return {
            "audit_id": str(uuid4()),
            "contract_id": contract_id,
            "status": "started",
            "estimated_completion": datetime.now(timezone.utc).isoformat()
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/v1/compliance/metrics/global")
async def get_global_compliance_metrics():
    """Obtém métricas globais de conformidade"""
    return ComplianceMetrics(
        total_contracts=150,
        compliant_contracts=95,
        partially_compliant=40,
        non_compliant=15,
        average_score=82.5,
        compliance_percentage=63.3
    )

@app.get("/api/v1/compliance/trends")
async def get_compliance_trends():
    """Obtém tendências de conformidade ao longo do tempo"""
    return {
        "period": "last_30_days",
        "trend_data": [
            {"date": "2025-07-15", "compliance_percentage": 60.2},
            {"date": "2025-07-22", "compliance_percentage": 61.8},
            {"date": "2025-07-29", "compliance_percentage": 62.5},
            {"date": "2025-08-05", "compliance_percentage": 63.1},
            {"date": "2025-08-12", "compliance_percentage": 63.3}
        ]
    }

@app.post("/api/v1/compliance/batch/validate")
async def validate_contracts_batch(request: BatchValidationRequest, background_tasks: BackgroundTasks):
    """Valida múltiplos contratos em lote"""
    try:
        batch_id = str(uuid4())
        
        # Executar validação em background
        background_tasks.add_task(
            process_batch_validation, 
            batch_id, 
            request.contract_ids, 
            request.odcs_version
        )
        
        return {
            "batch_id": batch_id,
            "status": "started",
            "total_contracts": len(request.contract_ids),
            "estimated_completion": datetime.now(timezone.utc).isoformat()
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

async def process_batch_validation(batch_id: str, contract_ids: List[UUID], odcs_version: ODCSVersion):
    """Processa validação em lote em background"""
    logger.info(f"Iniciando validação em lote {batch_id} para {len(contract_ids)} contratos")
    
    # Simular processamento
    await asyncio.sleep(2)
    
    logger.info(f"Validação em lote {batch_id} concluída")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8010)

