"""
ODCS Export Service
Microserviço responsável por export/import de contratos ODCS v3.0.2

Funcionalidades:
- Export para YAML/JSON ODCS
- Import de contratos ODCS
- Templates ODCS
- Transformação de formatos
- Validação de estrutura

Autor: Sistema de Governança v1.1
Data: 2025-08-12
"""

from fastapi import FastAPI, HTTPException, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response, JSONResponse
from pydantic import BaseModel, Field, validator
from typing import List, Optional, Dict, Any, Union
from datetime import datetime, timezone
from uuid import UUID, uuid4
import yaml
import json
import logging
from enum import Enum
from io import StringIO
import tempfile
import os

# Configuração de logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Configuração da aplicação
app = FastAPI(
    title="ODCS Export Service",
    description="Serviço de export/import ODCS v3.0.2",
    version="1.1.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# =====================================================
# MODELOS DE DADOS (DOMAIN ENTITIES)
# =====================================================

class ExportFormat(str, Enum):
    """Formatos de export suportados"""
    YAML = "yaml"
    JSON = "json"
    XML = "xml"

class ImportStatus(str, Enum):
    """Status de import"""
    SUCCESS = "success"
    PARTIAL = "partial"
    FAILED = "failed"
    VALIDATION_ERROR = "validation_error"

class ODCSTemplate(BaseModel):
    """Template ODCS"""
    id: UUID = Field(default_factory=uuid4)
    name: str = Field(..., description="Nome do template")
    description: str = Field(..., description="Descrição do template")
    category: str = Field(..., description="Categoria do template")
    odcs_version: str = Field(default="v3.0.2", description="Versão ODCS")
    template_data: Dict[str, Any] = Field(..., description="Dados do template")
    is_active: bool = Field(default=True)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class ExportRequest(BaseModel):
    """Request para export de contrato"""
    contract_id: UUID = Field(..., description="ID do contrato")
    format: ExportFormat = Field(..., description="Formato de export")
    include_metadata: bool = Field(default=True, description="Incluir metadados")
    include_examples: bool = Field(default=True, description="Incluir exemplos")
    include_quality_rules: bool = Field(default=True, description="Incluir regras de qualidade")
    template_id: Optional[UUID] = Field(None, description="ID do template a usar")

class BatchExportRequest(BaseModel):
    """Request para export em lote"""
    contract_ids: List[UUID] = Field(..., min_items=1, max_items=50)
    format: ExportFormat = Field(...)
    include_metadata: bool = Field(default=True)
    archive_format: str = Field(default="zip", description="Formato do arquivo (zip, tar)")

class ImportResult(BaseModel):
    """Resultado de import"""
    import_id: UUID = Field(default_factory=uuid4)
    status: ImportStatus = Field(...)
    contract_id: Optional[UUID] = Field(None, description="ID do contrato criado/atualizado")
    contract_name: Optional[str] = Field(None, description="Nome do contrato")
    validation_errors: List[str] = Field(default_factory=list)
    warnings: List[str] = Field(default_factory=list)
    imported_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class TransformationRequest(BaseModel):
    """Request para transformação de formato"""
    source_format: str = Field(..., description="Formato de origem")
    target_format: ExportFormat = Field(..., description="Formato de destino")
    source_data: Dict[str, Any] = Field(..., description="Dados de origem")
    mapping_rules: Optional[Dict[str, str]] = Field(None, description="Regras de mapeamento")

# =====================================================
# SERVIÇOS DE NEGÓCIO (APPLICATION LAYER)
# =====================================================

class ODCSExportService:
    """Serviço de export ODCS - Single Responsibility Principle"""
    
    def __init__(self):
        self.templates = self._load_templates()
    
    def _load_templates(self) -> List[ODCSTemplate]:
        """Carrega templates ODCS padrão"""
        return [
            ODCSTemplate(
                name="Basic Data Contract",
                description="Template básico para contrato de dados",
                category="basic",
                template_data={
                    "apiVersion": "v3.0.2",
                    "kind": "DataContract",
                    "metadata": {
                        "name": "{{contract_name}}",
                        "domain": "{{domain}}",
                        "dataProduct": "{{data_product}}"
                    },
                    "schema": {
                        "objects": [
                            {
                                "name": "{{table_name}}",
                                "logicalType": "object",
                                "physicalType": "table",
                                "properties": []
                            }
                        ]
                    },
                    "team": [
                        {
                            "name": "{{owner_name}}",
                            "role": "owner",
                            "email": "{{owner_email}}"
                        }
                    ]
                }
            ),
            ODCSTemplate(
                name="Advanced Data Contract",
                description="Template avançado com qualidade e servidores",
                category="advanced",
                template_data={
                    "apiVersion": "v3.0.2",
                    "kind": "DataContract",
                    "metadata": {
                        "name": "{{contract_name}}",
                        "domain": "{{domain}}",
                        "dataProduct": "{{data_product}}",
                        "purpose": "{{purpose}}",
                        "tags": ["{{tag1}}", "{{tag2}}"]
                    },
                    "schema": {
                        "objects": [
                            {
                                "name": "{{table_name}}",
                                "logicalType": "object",
                                "physicalType": "table",
                                "description": "{{table_description}}",
                                "properties": []
                            }
                        ]
                    },
                    "quality": [
                        {
                            "dimension": "conformity",
                            "type": "validValues",
                            "severity": "error",
                            "businessImpact": "operational"
                        }
                    ],
                    "servers": [
                        {
                            "name": "{{server_name}}",
                            "type": "{{server_type}}",
                            "environment": "{{environment}}",
                            "host": "{{host}}",
                            "port": "{{port}}"
                        }
                    ],
                    "team": [
                        {
                            "name": "{{owner_name}}",
                            "role": "owner",
                            "email": "{{owner_email}}"
                        }
                    ],
                    "support": [
                        {
                            "type": "email",
                            "contact": "{{support_email}}",
                            "level": "standard"
                        }
                    ]
                }
            ),
            ODCSTemplate(
                name="Financial Data Contract",
                description="Template específico para dados financeiros",
                category="domain_specific",
                template_data={
                    "apiVersion": "v3.0.2",
                    "kind": "DataContract",
                    "metadata": {
                        "name": "{{contract_name}}",
                        "domain": "finance",
                        "dataProduct": "{{data_product}}",
                        "classification": "confidential",
                        "tags": ["finance", "pii", "regulated"]
                    },
                    "schema": {
                        "objects": [
                            {
                                "name": "{{table_name}}",
                                "logicalType": "object",
                                "physicalType": "table",
                                "classification": "confidential",
                                "properties": [
                                    {
                                        "name": "customer_id",
                                        "logicalType": "string",
                                        "physicalType": "varchar",
                                        "required": True,
                                        "primaryKey": True,
                                        "classification": "internal"
                                    },
                                    {
                                        "name": "account_balance",
                                        "logicalType": "number",
                                        "physicalType": "decimal",
                                        "required": True,
                                        "classification": "confidential"
                                    }
                                ]
                            }
                        ]
                    },
                    "quality": [
                        {
                            "dimension": "accuracy",
                            "type": "rangeCheck",
                            "severity": "error",
                            "businessImpact": "financial"
                        },
                        {
                            "dimension": "completeness",
                            "type": "nullCheck",
                            "severity": "error",
                            "businessImpact": "compliance"
                        }
                    ]
                }
            )
        ]
    
    async def export_contract_yaml(self, contract_data: Dict[str, Any], 
                                 include_metadata: bool = True) -> str:
        """Exporta contrato para formato YAML ODCS"""
        try:
            # Transformar dados internos para formato ODCS
            odcs_data = await self._transform_to_odcs(contract_data, include_metadata)
            
            # Converter para YAML
            yaml_content = yaml.dump(
                odcs_data, 
                default_flow_style=False, 
                allow_unicode=True,
                sort_keys=False
            )
            
            return yaml_content
            
        except Exception as e:
            logger.error(f"Erro ao exportar para YAML: {str(e)}")
            raise
    
    async def export_contract_json(self, contract_data: Dict[str, Any], 
                                 include_metadata: bool = True) -> str:
        """Exporta contrato para formato JSON ODCS"""
        try:
            # Transformar dados internos para formato ODCS
            odcs_data = await self._transform_to_odcs(contract_data, include_metadata)
            
            # Converter para JSON
            json_content = json.dumps(
                odcs_data, 
                indent=2, 
                ensure_ascii=False,
                default=str
            )
            
            return json_content
            
        except Exception as e:
            logger.error(f"Erro ao exportar para JSON: {str(e)}")
            raise
    
    async def _transform_to_odcs(self, contract_data: Dict[str, Any], 
                               include_metadata: bool = True) -> Dict[str, Any]:
        """Transforma dados internos para formato ODCS v3.0.2"""
        
        odcs_contract = {
            "apiVersion": contract_data.get("api_version", "v3.0.2"),
            "kind": "DataContract",
            "metadata": {
                "name": contract_data.get("name"),
                "domain": contract_data.get("domain"),
                "dataProduct": contract_data.get("data_product"),
                "description": contract_data.get("description"),
                "purpose": contract_data.get("purpose"),
                "tags": contract_data.get("tags", [])
            }
        }
        
        # Schema
        if "schema" in contract_data:
            odcs_contract["schema"] = self._transform_schema(contract_data["schema"])
        
        # Quality
        if "quality_rules" in contract_data:
            odcs_contract["quality"] = self._transform_quality_rules(contract_data["quality_rules"])
        
        # Servers
        if "servers" in contract_data:
            odcs_contract["servers"] = self._transform_servers(contract_data["servers"])
        
        # Team
        if "team" in contract_data:
            odcs_contract["team"] = self._transform_team(contract_data["team"])
        
        # Support
        if "support_channels" in contract_data:
            odcs_contract["support"] = self._transform_support(contract_data["support_channels"])
        
        # Pricing
        if "pricing" in contract_data:
            odcs_contract["pricing"] = self._transform_pricing(contract_data["pricing"])
        
        # Examples
        if "examples" in contract_data:
            odcs_contract["examples"] = self._transform_examples(contract_data["examples"])
        
        # Custom Properties
        if "custom_properties" in contract_data:
            odcs_contract["customProperties"] = contract_data["custom_properties"]
        
        # Remover campos None
        return self._remove_none_values(odcs_contract)
    
    def _transform_schema(self, schema_data: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Transforma schema interno para formato ODCS"""
        objects = []
        
        # Agrupar campos por objeto/tabela
        objects_dict = {}
        for field in schema_data:
            table_name = field.get("table_name", "default_object")
            if table_name not in objects_dict:
                objects_dict[table_name] = {
                    "name": table_name,
                    "logicalType": "object",
                    "physicalType": "table",
                    "properties": []
                }
            
            property_def = {
                "name": field.get("field_name"),
                "businessName": field.get("business_name"),
                "logicalType": field.get("logical_type", "string"),
                "physicalType": field.get("physical_type", "text"),
                "description": field.get("description"),
                "required": field.get("is_required", False),
                "primaryKey": field.get("primary_key", False),
                "classification": field.get("classification", "internal"),
                "tags": field.get("tags", []),
                "examples": field.get("examples", []),
                "validValues": field.get("valid_values"),
                "defaultValue": field.get("default_value")
            }
            
            objects_dict[table_name]["properties"].append(
                self._remove_none_values(property_def)
            )
        
        return {"objects": list(objects_dict.values())}
    
    def _transform_quality_rules(self, quality_rules: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Transforma regras de qualidade para formato ODCS"""
        odcs_rules = []
        
        for rule in quality_rules:
            odcs_rule = {
                "dimension": rule.get("dimension"),
                "type": rule.get("rule_name", rule.get("rule_type")),
                "severity": rule.get("severity"),
                "businessImpact": rule.get("business_impact"),
                "description": rule.get("description"),
                "config": rule.get("rule_config", {})
            }
            odcs_rules.append(self._remove_none_values(odcs_rule))
        
        return odcs_rules
    
    def _transform_servers(self, servers: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Transforma servidores para formato ODCS"""
        odcs_servers = []
        
        for server in servers:
            odcs_server = {
                "name": server.get("server_name"),
                "type": server.get("server_type"),
                "environment": server.get("environment"),
                "description": server.get("description"),
                "host": server.get("host"),
                "port": server.get("port"),
                "database": server.get("database_name"),
                "roles": server.get("roles", []),
                "customProperties": server.get("custom_properties", {})
            }
            odcs_servers.append(self._remove_none_values(odcs_server))
        
        return odcs_servers
    
    def _transform_team(self, team: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Transforma equipe para formato ODCS"""
        odcs_team = []
        
        for member in team:
            odcs_member = {
                "name": member.get("name"),
                "role": member.get("role"),
                "email": member.get("email"),
                "responsibility": member.get("responsibility"),
                "contact": member.get("contact_info", {})
            }
            odcs_team.append(self._remove_none_values(odcs_member))
        
        return odcs_team
    
    def _transform_support(self, support_channels: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Transforma canais de suporte para formato ODCS"""
        odcs_support = []
        
        for channel in support_channels:
            odcs_channel = {
                "type": channel.get("channel_type"),
                "contact": channel.get("contact_info"),
                "level": channel.get("support_level"),
                "availability": channel.get("availability"),
                "sla": channel.get("response_time_sla")
            }
            odcs_support.append(self._remove_none_values(odcs_channel))
        
        return odcs_support
    
    def _transform_pricing(self, pricing: Dict[str, Any]) -> Dict[str, Any]:
        """Transforma pricing para formato ODCS"""
        return self._remove_none_values({
            "model": pricing.get("cost_model"),
            "tier": pricing.get("pricing_tier"),
            "baseCost": pricing.get("base_cost"),
            "unitCost": pricing.get("unit_cost"),
            "currency": pricing.get("currency"),
            "billingPeriod": pricing.get("billing_period"),
            "usageMetrics": pricing.get("usage_metrics", {})
        })
    
    def _transform_examples(self, examples: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Transforma exemplos para formato ODCS"""
        odcs_examples = []
        
        for example in examples:
            odcs_example = {
                "type": example.get("example_type"),
                "title": example.get("title"),
                "description": example.get("description"),
                "data": example.get("example_data"),
                "code": example.get("code_snippet"),
                "language": example.get("language")
            }
            odcs_examples.append(self._remove_none_values(odcs_example))
        
        return odcs_examples
    
    def _remove_none_values(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Remove valores None do dicionário"""
        return {k: v for k, v in data.items() if v is not None}

class ODCSImportService:
    """Serviço de import ODCS - Single Responsibility Principle"""
    
    async def import_from_yaml(self, yaml_content: str) -> ImportResult:
        """Importa contrato de YAML ODCS"""
        try:
            # Parse YAML
            data = yaml.safe_load(yaml_content)
            return await self._process_import(data, "yaml")
            
        except yaml.YAMLError as e:
            return ImportResult(
                status=ImportStatus.FAILED,
                validation_errors=[f"Erro de sintaxe YAML: {str(e)}"]
            )
        except Exception as e:
            logger.error(f"Erro no import YAML: {str(e)}")
            return ImportResult(
                status=ImportStatus.FAILED,
                validation_errors=[f"Erro interno: {str(e)}"]
            )
    
    async def import_from_json(self, json_content: str) -> ImportResult:
        """Importa contrato de JSON ODCS"""
        try:
            # Parse JSON
            data = json.loads(json_content)
            return await self._process_import(data, "json")
            
        except json.JSONDecodeError as e:
            return ImportResult(
                status=ImportStatus.FAILED,
                validation_errors=[f"Erro de sintaxe JSON: {str(e)}"]
            )
        except Exception as e:
            logger.error(f"Erro no import JSON: {str(e)}")
            return ImportResult(
                status=ImportStatus.FAILED,
                validation_errors=[f"Erro interno: {str(e)}"]
            )
    
    async def _process_import(self, data: Dict[str, Any], source_format: str) -> ImportResult:
        """Processa import de dados ODCS"""
        errors = []
        warnings = []
        
        # Validar estrutura ODCS
        validation_result = await self._validate_odcs_structure(data)
        if validation_result["errors"]:
            return ImportResult(
                status=ImportStatus.VALIDATION_ERROR,
                validation_errors=validation_result["errors"],
                warnings=validation_result["warnings"]
            )
        
        # Transformar para formato interno
        try:
            internal_data = await self._transform_from_odcs(data)
            
            # Simular criação do contrato
            contract_id = uuid4()
            contract_name = data.get("metadata", {}).get("name", "Imported Contract")
            
            return ImportResult(
                status=ImportStatus.SUCCESS,
                contract_id=contract_id,
                contract_name=contract_name,
                warnings=validation_result["warnings"]
            )
            
        except Exception as e:
            return ImportResult(
                status=ImportStatus.FAILED,
                validation_errors=[f"Erro na transformação: {str(e)}"]
            )
    
    async def _validate_odcs_structure(self, data: Dict[str, Any]) -> Dict[str, List[str]]:
        """Valida estrutura ODCS"""
        errors = []
        warnings = []
        
        # Validações obrigatórias
        if not data.get("apiVersion"):
            errors.append("Campo 'apiVersion' é obrigatório")
        elif data["apiVersion"] not in ["v3.0.0", "v3.0.1", "v3.0.2"]:
            warnings.append(f"Versão ODCS '{data['apiVersion']}' pode não ser totalmente suportada")
        
        if data.get("kind") != "DataContract":
            errors.append("Campo 'kind' deve ser 'DataContract'")
        
        if not data.get("metadata", {}).get("name"):
            errors.append("Campo 'metadata.name' é obrigatório")
        
        # Validações recomendadas
        if not data.get("metadata", {}).get("domain"):
            warnings.append("Campo 'metadata.domain' é recomendado")
        
        if not data.get("schema", {}).get("objects"):
            warnings.append("Schema deve conter pelo menos um objeto")
        
        if not data.get("team"):
            warnings.append("Equipe responsável é recomendada")
        
        return {"errors": errors, "warnings": warnings}
    
    async def _transform_from_odcs(self, odcs_data: Dict[str, Any]) -> Dict[str, Any]:
        """Transforma dados ODCS para formato interno"""
        
        internal_data = {
            "api_version": odcs_data.get("apiVersion"),
            "kind": odcs_data.get("kind"),
            "name": odcs_data.get("metadata", {}).get("name"),
            "description": odcs_data.get("metadata", {}).get("description"),
            "domain": odcs_data.get("metadata", {}).get("domain"),
            "data_product": odcs_data.get("metadata", {}).get("dataProduct"),
            "purpose": odcs_data.get("metadata", {}).get("purpose"),
            "tags": odcs_data.get("metadata", {}).get("tags", [])
        }
        
        # Transformar schema
        if "schema" in odcs_data:
            internal_data["schema"] = self._transform_schema_from_odcs(odcs_data["schema"])
        
        # Transformar quality
        if "quality" in odcs_data:
            internal_data["quality_rules"] = self._transform_quality_from_odcs(odcs_data["quality"])
        
        # Transformar servers
        if "servers" in odcs_data:
            internal_data["servers"] = self._transform_servers_from_odcs(odcs_data["servers"])
        
        # Transformar team
        if "team" in odcs_data:
            internal_data["team"] = self._transform_team_from_odcs(odcs_data["team"])
        
        return internal_data
    
    def _transform_schema_from_odcs(self, schema: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Transforma schema ODCS para formato interno"""
        fields = []
        
        for obj in schema.get("objects", []):
            table_name = obj.get("name")
            for prop in obj.get("properties", []):
                field = {
                    "table_name": table_name,
                    "field_name": prop.get("name"),
                    "business_name": prop.get("businessName"),
                    "logical_type": prop.get("logicalType"),
                    "physical_type": prop.get("physicalType"),
                    "description": prop.get("description"),
                    "is_required": prop.get("required", False),
                    "primary_key": prop.get("primaryKey", False),
                    "classification": prop.get("classification"),
                    "tags": prop.get("tags", []),
                    "examples": prop.get("examples", []),
                    "valid_values": prop.get("validValues"),
                    "default_value": prop.get("defaultValue")
                }
                fields.append(field)
        
        return fields
    
    def _transform_quality_from_odcs(self, quality: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Transforma quality ODCS para formato interno"""
        rules = []
        
        for rule in quality:
            internal_rule = {
                "dimension": rule.get("dimension"),
                "rule_name": rule.get("type"),
                "severity": rule.get("severity"),
                "business_impact": rule.get("businessImpact"),
                "description": rule.get("description"),
                "rule_config": rule.get("config", {})
            }
            rules.append(internal_rule)
        
        return rules
    
    def _transform_servers_from_odcs(self, servers: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Transforma servers ODCS para formato interno"""
        internal_servers = []
        
        for server in servers:
            internal_server = {
                "server_name": server.get("name"),
                "server_type": server.get("type"),
                "environment": server.get("environment"),
                "description": server.get("description"),
                "host": server.get("host"),
                "port": server.get("port"),
                "database_name": server.get("database"),
                "roles": server.get("roles", []),
                "custom_properties": server.get("customProperties", {})
            }
            internal_servers.append(internal_server)
        
        return internal_servers
    
    def _transform_team_from_odcs(self, team: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Transforma team ODCS para formato interno"""
        internal_team = []
        
        for member in team:
            internal_member = {
                "name": member.get("name"),
                "role": member.get("role"),
                "email": member.get("email"),
                "responsibility": member.get("responsibility"),
                "contact_info": member.get("contact", {})
            }
            internal_team.append(internal_member)
        
        return internal_team

# =====================================================
# CONTROLADORES (PRESENTATION LAYER)
# =====================================================

# Dependências
export_service = ODCSExportService()
import_service = ODCSImportService()

@app.get("/health")
async def health_check():
    """Health check do serviço"""
    return {"status": "healthy", "service": "odcs-export-service", "version": "1.1.0"}

@app.post("/api/v1/export/yaml/{contract_id}")
async def export_yaml(contract_id: UUID, request: ExportRequest):
    """Exporta contrato para YAML ODCS"""
    try:
        # Simular busca do contrato
        contract_data = {
            "name": f"Contract {contract_id}",
            "description": "Sample contract for export",
            "domain": "finance",
            "data_product": "customer_data",
            "api_version": "v3.0.2",
            "schema": [
                {
                    "table_name": "customers",
                    "field_name": "id",
                    "logical_type": "string",
                    "physical_type": "varchar",
                    "is_required": True,
                    "primary_key": True
                }
            ],
            "team": [
                {"name": "John Doe", "role": "owner", "email": "john@company.com"}
            ]
        }
        
        yaml_content = await export_service.export_contract_yaml(
            contract_data, 
            request.include_metadata
        )
        
        return Response(
            content=yaml_content,
            media_type="application/x-yaml",
            headers={"Content-Disposition": f"attachment; filename=contract_{contract_id}.yaml"}
        )
        
    except Exception as e:
        logger.error(f"Erro no export YAML: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/v1/export/json/{contract_id}")
async def export_json(contract_id: UUID, request: ExportRequest):
    """Exporta contrato para JSON ODCS"""
    try:
        # Simular busca do contrato
        contract_data = {
            "name": f"Contract {contract_id}",
            "description": "Sample contract for export",
            "domain": "finance",
            "data_product": "customer_data",
            "api_version": "v3.0.2"
        }
        
        json_content = await export_service.export_contract_json(
            contract_data, 
            request.include_metadata
        )
        
        return Response(
            content=json_content,
            media_type="application/json",
            headers={"Content-Disposition": f"attachment; filename=contract_{contract_id}.json"}
        )
        
    except Exception as e:
        logger.error(f"Erro no export JSON: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/v1/import/yaml", response_model=ImportResult)
async def import_yaml(file: UploadFile = File(...)):
    """Importa contrato de arquivo YAML ODCS"""
    try:
        content = await file.read()
        yaml_content = content.decode('utf-8')
        
        result = await import_service.import_from_yaml(yaml_content)
        return result
        
    except Exception as e:
        logger.error(f"Erro no import YAML: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/v1/import/json", response_model=ImportResult)
async def import_json(file: UploadFile = File(...)):
    """Importa contrato de arquivo JSON ODCS"""
    try:
        content = await file.read()
        json_content = content.decode('utf-8')
        
        result = await import_service.import_from_json(json_content)
        return result
        
    except Exception as e:
        logger.error(f"Erro no import JSON: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/v1/export/templates/odcs")
async def get_odcs_templates():
    """Obtém templates ODCS disponíveis"""
    return {
        "templates": [
            {
                "id": str(template.id),
                "name": template.name,
                "description": template.description,
                "category": template.category,
                "odcs_version": template.odcs_version
            }
            for template in export_service.templates
        ]
    }

@app.post("/api/v1/export/batch")
async def export_batch(request: BatchExportRequest):
    """Exporta múltiplos contratos em lote"""
    try:
        batch_id = str(uuid4())
        
        return {
            "batch_id": batch_id,
            "status": "started",
            "total_contracts": len(request.contract_ids),
            "format": request.format,
            "download_url": f"/api/v1/export/batch/{batch_id}/download"
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/v1/export/history/{contract_id}")
async def get_export_history(contract_id: UUID):
    """Obtém histórico de exports de um contrato"""
    return {
        "contract_id": contract_id,
        "exports": [
            {
                "export_id": str(uuid4()),
                "format": "yaml",
                "exported_at": datetime.now(timezone.utc).isoformat(),
                "exported_by": "user@company.com",
                "file_size": 2048
            },
            {
                "export_id": str(uuid4()),
                "format": "json",
                "exported_at": datetime.now(timezone.utc).isoformat(),
                "exported_by": "user@company.com",
                "file_size": 1536
            }
        ]
    }

@app.post("/api/v1/transform/legacy-to-odcs")
async def transform_legacy_to_odcs(request: TransformationRequest):
    """Transforma formato legado para ODCS"""
    try:
        # Simular transformação
        transformed_data = {
            "apiVersion": "v3.0.2",
            "kind": "DataContract",
            "metadata": {
                "name": request.source_data.get("name", "Transformed Contract"),
                "domain": request.source_data.get("domain", "general")
            }
        }
        
        return {
            "transformation_id": str(uuid4()),
            "status": "success",
            "source_format": request.source_format,
            "target_format": request.target_format,
            "transformed_data": transformed_data
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/v1/export/formats/supported")
async def get_supported_formats():
    """Obtém formatos de export suportados"""
    return {
        "export_formats": ["yaml", "json", "xml"],
        "import_formats": ["yaml", "json"],
        "transformation_formats": {
            "from": ["legacy_json", "csv", "excel"],
            "to": ["yaml", "json"]
        }
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8011)

