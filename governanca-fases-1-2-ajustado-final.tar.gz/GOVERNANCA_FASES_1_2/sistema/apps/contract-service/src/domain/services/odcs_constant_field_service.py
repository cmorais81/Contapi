"""
ODCS Constant Field Service
Serviço para gerenciar campos com valores constantes conforme ODCS v3.0.2
"""

from typing import List, Dict, Any, Optional, Tuple
from datetime import datetime
import json
import yaml
from dataclasses import asdict

from ..entities.odcs_constant_field import (
    ODCSConstantField, 
    ConstantType, 
    ChangePolicy, 
    QualityRule,
    QualityDimension,
    Severity,
    ChangeHistoryEntry
)


class ODCSConstantFieldService:
    """
    Serviço para gerenciar campos constantes conforme ODCS
    
    Responsabilidades:
    - Criar e validar campos constantes
    - Gerenciar mudanças de valores
    - Aplicar políticas de governança
    - Gerar contratos ODCS completos
    - Validar conformidade com padrão ODCS
    """
    
    def __init__(self):
        self.fields: Dict[str, ODCSConstantField] = {}
        self.approval_workflows: Dict[str, callable] = {}
        self.notification_handlers: Dict[str, callable] = {}
    
    def register_approval_workflow(self, workflow_name: str, handler: callable):
        """Registra um workflow de aprovação"""
        self.approval_workflows[workflow_name] = handler
    
    def register_notification_handler(self, topic: str, handler: callable):
        """Registra um handler de notificação"""
        self.notification_handlers[topic] = handler
    
    def create_field(self, field_config: Dict[str, Any]) -> ODCSConstantField:
        """
        Cria um novo campo constante
        
        Args:
            field_config: Configuração do campo
        
        Returns:
            ODCSConstantField: Campo criado
        """
        field = ODCSConstantField(
            name=field_config["name"],
            business_name=field_config.get("business_name", field_config["name"]),
            logical_type=field_config.get("logical_type", "string"),
            physical_type=field_config.get("physical_type", "varchar"),
            description=field_config.get("description", ""),
            constant_type=ConstantType(field_config.get("constant_type", "DEFAULT_VALUE")),
            default_value=field_config.get("default_value"),
            allowed_values=field_config.get("allowed_values"),
            change_policy=ChangePolicy(field_config.get("change_policy", "CONTROLLED_EVOLUTION")),
            change_approval_required=field_config.get("change_approval_required", True),
            change_notification_required=field_config.get("change_notification_required", True),
            approval_workflow=field_config.get("approval_workflow", "data-governance-committee"),
            classification=field_config.get("classification", "internal"),
            tags=field_config.get("tags", []),
            examples=field_config.get("examples", []),
            transform_logic=field_config.get("transform_logic"),
            dependencies=field_config.get("dependencies", [])
        )
        
        # Adicionar regras de qualidade customizadas
        if "quality_rules" in field_config:
            for rule_config in field_config["quality_rules"]:
                rule = QualityRule(
                    rule=rule_config["rule"],
                    dimension=QualityDimension(rule_config.get("dimension", "conformity")),
                    severity=Severity(rule_config.get("severity", "error")),
                    description=rule_config.get("description", ""),
                    business_impact=rule_config.get("business_impact", "operational"),
                    valid_values=rule_config.get("valid_values"),
                    must_be_less_than=rule_config.get("must_be_less_than"),
                    must_be_greater_than=rule_config.get("must_be_greater_than"),
                    custom_query=rule_config.get("custom_query")
                )
                field.add_quality_rule(rule)
        
        self.fields[field.name] = field
        return field
    
    def get_field(self, field_name: str) -> Optional[ODCSConstantField]:
        """Obtém um campo pelo nome"""
        return self.fields.get(field_name)
    
    def list_fields(self, filter_by: Dict[str, Any] = None) -> List[ODCSConstantField]:
        """
        Lista campos com filtros opcionais
        
        Args:
            filter_by: Filtros a aplicar
        
        Returns:
            List[ODCSConstantField]: Lista de campos
        """
        fields = list(self.fields.values())
        
        if not filter_by:
            return fields
        
        filtered_fields = []
        for field in fields:
            match = True
            
            if "constant_type" in filter_by:
                if field.constant_type != ConstantType(filter_by["constant_type"]):
                    match = False
            
            if "change_policy" in filter_by:
                if field.change_policy != ChangePolicy(filter_by["change_policy"]):
                    match = False
            
            if "classification" in filter_by:
                if field.classification != filter_by["classification"]:
                    match = False
            
            if "tags" in filter_by:
                required_tags = set(filter_by["tags"])
                field_tags = set(field.tags)
                if not required_tags.issubset(field_tags):
                    match = False
            
            if match:
                filtered_fields.append(field)
        
        return filtered_fields
    
    def validate_field_value(self, field_name: str, value: Any) -> Tuple[bool, List[str]]:
        """
        Valida um valor para um campo específico
        
        Args:
            field_name: Nome do campo
            value: Valor a validar
        
        Returns:
            Tuple[bool, List[str]]: (is_valid, error_messages)
        """
        field = self.get_field(field_name)
        if not field:
            return False, [f"Campo '{field_name}' não encontrado"]
        
        return field.validate_value(value)
    
    def change_field_value(self, field_name: str, new_value: Any, 
                          user_context: Dict[str, Any], 
                          change_description: str = "") -> Tuple[bool, str]:
        """
        Altera o valor de um campo seguindo as políticas de governança
        
        Args:
            field_name: Nome do campo
            new_value: Novo valor
            user_context: Contexto do usuário
            change_description: Descrição da mudança
        
        Returns:
            Tuple[bool, str]: (success, message)
        """
        field = self.get_field(field_name)
        if not field:
            return False, f"Campo '{field_name}' não encontrado"
        
        try:
            # Verificar se precisa de aprovação
            if field.change_approval_required:
                approval_result = self._request_approval(field, new_value, user_context)
                if not approval_result:
                    return False, "Aprovação negada para a mudança"
                
                # Adicionar aprovação ao contexto
                user_context["has_approval"] = True
            
            # Realizar a mudança
            field.change_value(new_value, user_context, change_description)
            
            # Enviar notificação se necessário
            if field.change_notification_required:
                self._send_notification(field, new_value, user_context)
            
            return True, f"Valor do campo '{field_name}' alterado com sucesso"
            
        except ValueError as e:
            return False, str(e)
        except Exception as e:
            return False, f"Erro inesperado: {str(e)}"
    
    def _request_approval(self, field: ODCSConstantField, new_value: Any, 
                         user_context: Dict[str, Any]) -> bool:
        """
        Solicita aprovação para mudança de valor
        
        Args:
            field: Campo a ser alterado
            new_value: Novo valor
            user_context: Contexto do usuário
        
        Returns:
            bool: True se aprovado
        """
        workflow_handler = self.approval_workflows.get(field.approval_workflow)
        if not workflow_handler:
            # Se não há workflow configurado, assumir aprovação automática para admin
            return user_context.get("role") == "admin"
        
        approval_request = {
            "field_name": field.name,
            "current_value": field.current_value,
            "new_value": new_value,
            "user_id": user_context.get("user_id"),
            "user_role": user_context.get("role"),
            "change_policy": field.change_policy.value,
            "business_impact": "operational"
        }
        
        return workflow_handler(approval_request)
    
    def _send_notification(self, field: ODCSConstantField, new_value: Any, 
                          user_context: Dict[str, Any]):
        """
        Envia notificação sobre mudança de valor
        
        Args:
            field: Campo alterado
            new_value: Novo valor
            user_context: Contexto do usuário
        """
        if field.change_notification_topic:
            handler = self.notification_handlers.get(field.change_notification_topic)
            if handler:
                notification = {
                    "event_type": "constant_field_changed",
                    "field_name": field.name,
                    "old_value": field.current_value,
                    "new_value": new_value,
                    "changed_by": user_context.get("user_id"),
                    "change_date": datetime.now().isoformat(),
                    "change_policy": field.change_policy.value
                }
                handler(notification)
    
    def generate_odcs_schema(self, object_name: str, 
                           field_names: List[str] = None) -> Dict[str, Any]:
        """
        Gera schema ODCS completo para um objeto
        
        Args:
            object_name: Nome do objeto
            field_names: Lista de campos a incluir (None = todos)
        
        Returns:
            Dict[str, Any]: Schema ODCS
        """
        if field_names is None:
            fields_to_include = list(self.fields.values())
        else:
            fields_to_include = [self.fields[name] for name in field_names if name in self.fields]
        
        properties = []
        for field in fields_to_include:
            properties.append(field.to_odcs_property())
        
        schema_object = {
            "name": object_name,
            "logicalType": "object",
            "physicalType": "table",
            "description": f"Objeto {object_name} com campos constantes gerenciados",
            "properties": properties
        }
        
        return schema_object
    
    def generate_full_odcs_contract(self, contract_config: Dict[str, Any]) -> Dict[str, Any]:
        """
        Gera contrato ODCS completo
        
        Args:
            contract_config: Configuração do contrato
        
        Returns:
            Dict[str, Any]: Contrato ODCS completo
        """
        contract = {
            "apiVersion": "v3.0.2",
            "kind": "DataContract",
            "id": contract_config.get("id", "generated-contract-id"),
            "name": contract_config.get("name", "constant_fields_contract"),
            "version": contract_config.get("version", "1.0.0"),
            "status": contract_config.get("status", "draft"),
            "domain": contract_config.get("domain", "governance"),
            "dataProduct": contract_config.get("data_product", "constant_fields"),
            "tenant": contract_config.get("tenant", "organization"),
            "description": {
                "purpose": contract_config.get("purpose", "Gerenciar campos com valores constantes"),
                "limitations": contract_config.get("limitations"),
                "usage": contract_config.get("usage", "Campos constantes para governança de dados")
            },
            "tags": contract_config.get("tags", ["governance", "constant-fields", "odcs"])
        }
        
        # Adicionar schema
        schema_objects = []
        for object_config in contract_config.get("objects", []):
            schema_obj = self.generate_odcs_schema(
                object_config["name"],
                object_config.get("fields")
            )
            schema_objects.append(schema_obj)
        
        if schema_objects:
            contract["schema"] = schema_objects
        
        # Adicionar servers se especificados
        if "servers" in contract_config:
            contract["servers"] = contract_config["servers"]
        
        # Adicionar propriedades customizadas
        if "custom_properties" in contract_config:
            contract["customProperties"] = contract_config["custom_properties"]
        
        return contract
    
    def export_to_yaml(self, contract_config: Dict[str, Any]) -> str:
        """
        Exporta contrato completo para YAML ODCS
        
        Args:
            contract_config: Configuração do contrato
        
        Returns:
            str: YAML do contrato ODCS
        """
        contract = self.generate_full_odcs_contract(contract_config)
        return yaml.dump(contract, default_flow_style=False, allow_unicode=True, sort_keys=False)
    
    def import_from_odcs_yaml(self, yaml_content: str) -> List[ODCSConstantField]:
        """
        Importa campos constantes de um YAML ODCS
        
        Args:
            yaml_content: Conteúdo YAML do contrato ODCS
        
        Returns:
            List[ODCSConstantField]: Campos importados
        """
        try:
            contract = yaml.safe_load(yaml_content)
            imported_fields = []
            
            if "schema" in contract:
                for schema_obj in contract["schema"]:
                    if "properties" in schema_obj:
                        for prop in schema_obj["properties"]:
                            # Verificar se é um campo constante
                            custom_props = {}
                            if "customProperties" in prop:
                                for cp in prop["customProperties"]:
                                    custom_props[cp["property"]] = cp["value"]
                            
                            if "constantType" in custom_props:
                                field = ODCSConstantField.from_odcs_property(prop)
                                self.fields[field.name] = field
                                imported_fields.append(field)
            
            return imported_fields
            
        except Exception as e:
            raise ValueError(f"Erro ao importar YAML ODCS: {str(e)}")
    
    def validate_odcs_compliance(self, field_name: str) -> Tuple[bool, List[str]]:
        """
        Valida se um campo está em conformidade com ODCS v3.0.2
        
        Args:
            field_name: Nome do campo
        
        Returns:
            Tuple[bool, List[str]]: (is_compliant, issues)
        """
        field = self.get_field(field_name)
        if not field:
            return False, [f"Campo '{field_name}' não encontrado"]
        
        issues = []
        
        # Validações obrigatórias ODCS
        if not field.name:
            issues.append("Campo 'name' é obrigatório")
        
        if not field.logical_type:
            issues.append("Campo 'logicalType' é obrigatório")
        
        # Validações de qualidade
        if field.constant_type == ConstantType.ENUM_VALUES:
            if not field.allowed_values:
                issues.append("Campos ENUM_VALUES devem ter 'allowedValues' definidos")
            
            # Verificar se há regra validValues correspondente
            has_valid_values_rule = any(
                rule.rule == "validValues" for rule in field.quality_rules
            )
            if not has_valid_values_rule:
                issues.append("Campos ENUM_VALUES devem ter regra de qualidade 'validValues'")
        
        # Validações de política de mudança
        if field.change_policy == ChangePolicy.BUSINESS_APPROVAL_REQUIRED:
            if not field.approval_workflow:
                issues.append("Política BUSINESS_APPROVAL_REQUIRED requer 'approvalWorkflow'")
        
        # Validações de rastreabilidade
        if field.change_history_enabled and not field.change_audit_table:
            issues.append("Rastreabilidade habilitada requer 'changeAuditTable'")
        
        return len(issues) == 0, issues
    
    def get_field_statistics(self) -> Dict[str, Any]:
        """
        Obtém estatísticas dos campos constantes
        
        Returns:
            Dict[str, Any]: Estatísticas
        """
        total_fields = len(self.fields)
        
        # Contar por tipo
        type_counts = {}
        for field in self.fields.values():
            type_name = field.constant_type.value
            type_counts[type_name] = type_counts.get(type_name, 0) + 1
        
        # Contar por política de mudança
        policy_counts = {}
        for field in self.fields.values():
            policy_name = field.change_policy.value
            policy_counts[policy_name] = policy_counts.get(policy_name, 0) + 1
        
        # Contar campos com histórico de mudanças
        fields_with_history = sum(
            1 for field in self.fields.values() 
            if field.change_history
        )
        
        # Contar campos com regras de qualidade
        fields_with_quality_rules = sum(
            1 for field in self.fields.values() 
            if field.quality_rules
        )
        
        return {
            "total_fields": total_fields,
            "by_constant_type": type_counts,
            "by_change_policy": policy_counts,
            "fields_with_change_history": fields_with_history,
            "fields_with_quality_rules": fields_with_quality_rules,
            "compliance_rate": self._calculate_compliance_rate()
        }
    
    def _calculate_compliance_rate(self) -> float:
        """Calcula taxa de conformidade ODCS"""
        if not self.fields:
            return 100.0
        
        compliant_fields = 0
        for field_name in self.fields:
            is_compliant, _ = self.validate_odcs_compliance(field_name)
            if is_compliant:
                compliant_fields += 1
        
        return (compliant_fields / len(self.fields)) * 100.0


# Exemplo de uso
if __name__ == "__main__":
    # Criar serviço
    service = ODCSConstantFieldService()
    
    # Registrar workflow de aprovação simples
    def simple_approval_workflow(request):
        # Aprovar automaticamente para admin
        return request.get("user_role") == "admin"
    
    service.register_approval_workflow("data-governance-committee", simple_approval_workflow)
    
    # Criar campo de status
    status_config = {
        "name": "contract_status",
        "business_name": "Status do Contrato",
        "logical_type": "string",
        "physical_type": "varchar(20)",
        "description": "Status atual do contrato de dados",
        "constant_type": "ENUM_VALUES",
        "default_value": "DRAFT",
        "allowed_values": ["DRAFT", "ACTIVE", "DEPRECATED", "RETIRED"],
        "change_policy": "CONTROLLED_EVOLUTION",
        "tags": ["governance", "status"],
        "examples": ["DRAFT", "ACTIVE"]
    }
    
    field = service.create_field(status_config)
    print(f"Campo criado: {field.name}")
    
    # Testar mudança de valor
    user_context = {"user_id": "admin", "role": "admin"}
    success, message = service.change_field_value(
        "contract_status", 
        "ACTIVE", 
        user_context, 
        "Ativando contrato para produção"
    )
    print(f"Mudança de valor: {success}, {message}")
    
    # Gerar contrato ODCS
    contract_config = {
        "name": "governance_contract",
        "version": "1.0.0",
        "purpose": "Contrato para campos de governança",
        "objects": [
            {
                "name": "contract_metadata",
                "fields": ["contract_status"]
            }
        ]
    }
    
    yaml_output = service.export_to_yaml(contract_config)
    print("\nContrato ODCS gerado:")
    print(yaml_output)
    
    # Estatísticas
    stats = service.get_field_statistics()
    print(f"\nEstatísticas: {stats}")

