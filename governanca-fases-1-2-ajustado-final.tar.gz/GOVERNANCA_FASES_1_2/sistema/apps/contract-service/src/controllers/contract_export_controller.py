"""
Contract Export Controller
Funcionalidade de export de contratos em múltiplos formatos
Complementa o contract-service existente sem alterar funcionalidades originais
"""

from fastapi import APIRouter, HTTPException, Query, Response
from typing import List, Optional, Dict, Any
import json
import yaml
import uuid
from datetime import datetime

router = APIRouter(prefix="/api/v1/contracts/export", tags=["Contract Export"])

# Simulação de contratos para export
contracts_data = [
    {
        "contract_id": "contract_001",
        "name": "Customer Data Contract",
        "version": "1.0.0",
        "description": "Contrato para dados de clientes",
        "data_source": "customer_database",
        "schema": {
            "tables": [
                {
                    "name": "customers",
                    "columns": [
                        {"name": "customer_id", "type": "uuid", "required": True},
                        {"name": "email", "type": "varchar(255)", "required": True, "pii": True},
                        {"name": "name", "type": "varchar(100)", "required": True, "pii": True},
                        {"name": "created_at", "type": "timestamp", "required": True}
                    ]
                }
            ]
        },
        "quality_rules": [
            {"field": "email", "rule": "email_format", "description": "Must be valid email format"},
            {"field": "customer_id", "rule": "not_null", "description": "Cannot be null"}
        ],
        "compliance": {
            "gdpr_compliant": True,
            "lgpd_compliant": True,
            "data_classification": "confidential"
        },
        "created_at": "2025-07-30T10:00:00Z",
        "updated_at": "2025-07-30T15:30:00Z",
        "status": "active"
    },
    {
        "contract_id": "contract_002",
        "name": "Financial Transactions Contract",
        "version": "2.1.0",
        "description": "Contrato para transações financeiras",
        "data_source": "financial_system",
        "schema": {
            "tables": [
                {
                    "name": "transactions",
                    "columns": [
                        {"name": "transaction_id", "type": "uuid", "required": True},
                        {"name": "amount", "type": "decimal(15,2)", "required": True},
                        {"name": "currency", "type": "varchar(3)", "required": True},
                        {"name": "transaction_date", "type": "timestamp", "required": True}
                    ]
                }
            ]
        },
        "quality_rules": [
            {"field": "amount", "rule": "positive_value", "description": "Amount must be positive"},
            {"field": "currency", "rule": "iso_currency", "description": "Must be valid ISO currency code"}
        ],
        "compliance": {
            "gdpr_compliant": True,
            "lgpd_compliant": True,
            "data_classification": "restricted"
        },
        "created_at": "2025-07-25T14:00:00Z",
        "updated_at": "2025-07-30T12:15:00Z",
        "status": "active"
    }
]

def filter_contracts(
    """Executa operação filter_contracts."""
    """Executa operação filter_contracts."""
    status: Optional[str] = None,
    created_after: Optional[str] = None,
    classification: Optional[str] = None
) -> List[Dict[str, Any]]:
    """Filtra contratos baseado nos parâmetros"""
    filtered = contracts_data.copy()
    
    if status:
        filtered = [c for c in filtered if c["status"] == status]
    
    if created_after:
        filtered = [c for c in filtered if c["created_at"] >= created_after]
    
    if classification:
        filtered = [c for c in filtered if c["compliance"]["data_classification"] == classification]
    
    return filtered

@router.get("/json")
async def export_contracts_json(
    status: Optional[str] = Query(None, description="Filter by status"),
    created_after: Optional[str] = Query(None, description="Filter by creation date"),
    classification: Optional[str] = Query(None, description="Filter by data classification"),
    pretty: bool = Query(True, description="Pretty print JSON")
):
    """
    Export contratos em formato JSON
    """
    try:
        contracts = filter_contracts(status, created_after, classification)
        
        export_data = {
            "export_metadata": {
                "export_id": str(uuid.uuid4()),
                "export_timestamp": datetime.now().isoformat() + "Z",
                "export_format": "json",
                "total_contracts": len(contracts),
                "filters_applied": {
                    "status": status,
                    "created_after": created_after,
                    "classification": classification
                }
            },
            "contracts": contracts
        }
        
        if pretty:
            json_content = json.dumps(export_data, indent=2, ensure_ascii=False)
        else:
            json_content = json.dumps(export_data, ensure_ascii=False)
        
        return Response(
            content=json_content,
            media_type="application/json",
            headers={
                "Content-Disposition": f"attachment; filename=contracts_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            }
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro ao exportar contratos: {str(e)}")

@router.get("/yaml")
async def export_contracts_yaml(
    status: Optional[str] = Query(None, description="Filter by status"),
    created_after: Optional[str] = Query(None, description="Filter by creation date"),
    classification: Optional[str] = Query(None, description="Filter by data classification")
):
    """
    Export contratos em formato YAML
    """
    try:
        contracts = filter_contracts(status, created_after, classification)
        
        export_data = {
            "export_metadata": {
                "export_id": str(uuid.uuid4()),
                "export_timestamp": datetime.now().isoformat() + "Z",
                "export_format": "yaml",
                "total_contracts": len(contracts),
                "filters_applied": {
                    "status": status,
                    "created_after": created_after,
                    "classification": classification
                }
            },
            "contracts": contracts
        }
        
        yaml_content = yaml.dump(export_data, default_flow_style=False, allow_unicode=True)
        
        return Response(
            content=yaml_content,
            media_type="application/x-yaml",
            headers={
                "Content-Disposition": f"attachment; filename=contracts_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.yaml"
            }
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro ao exportar contratos: {str(e)}")

@router.get("/sql")
async def export_contracts_sql(
    status: Optional[str] = Query(None, description="Filter by status"),
    created_after: Optional[str] = Query(None, description="Filter by creation date"),
    classification: Optional[str] = Query(None, description="Filter by data classification"),
    include_schema: bool = Query(True, description="Include CREATE TABLE statements")
):
    """
    Export contratos em formato SQL
    """
    try:
        contracts = filter_contracts(status, created_after, classification)
        
        sql_statements = []
        
        # Header comment
        sql_statements.append("-- Data Contracts Export")
        sql_statements.append(f"-- Generated at: {datetime.now().isoformat()}Z")
        sql_statements.append(f"-- Total contracts: {len(contracts)}")
        sql_statements.append("")
        
        if include_schema:
            # Create contracts table
            sql_statements.append("-- Create contracts table")
            sql_statements.append("""
CREATE TABLE IF NOT EXISTS data_contracts (
    contract_id UUID PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    version VARCHAR(50) NOT NULL,
    description TEXT,
    data_source VARCHAR(255),
    schema_definition JSONB,
    quality_rules JSONB,
    compliance_info JSONB,
    status VARCHAR(50) DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
""")
            sql_statements.append("")
        
        # Insert statements
        sql_statements.append("-- Insert contract data")
        for contract in contracts:
            schema_json = json.dumps(contract["schema"]).replace("'", "''")
            quality_json = json.dumps(contract["quality_rules"]).replace("'", "''")
            compliance_json = json.dumps(contract["compliance"]).replace("'", "''")
            
            insert_sql = f"""
INSERT INTO data_contracts (
    contract_id, name, version, description, data_source,
    schema_definition, quality_rules, compliance_info,
    status, created_at, updated_at
) VALUES (
    '{contract["contract_id"]}',
    '{contract["name"]}',
    '{contract["version"]}',
    '{contract["description"]}',
    '{contract["data_source"]}',
    '{schema_json}',
    '{quality_json}',
    '{compliance_json}',
    '{contract["status"]}',
    '{contract["created_at"]}',
    '{contract["updated_at"]}'
);"""
            sql_statements.append(insert_sql)
        
        sql_content = "\n".join(sql_statements)
        
        return Response(
            content=sql_content,
            media_type="application/sql",
            headers={
                "Content-Disposition": f"attachment; filename=contracts_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.sql"
            }
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro ao exportar contratos: {str(e)}")

@router.get("/dbml")
async def export_contracts_dbml(
    status: Optional[str] = Query(None, description="Filter by status"),
    created_after: Optional[str] = Query(None, description="Filter by creation date"),
    classification: Optional[str] = Query(None, description="Filter by data classification")
):
    """
    Export contratos em formato DBML (Database Markup Language)
    """
    try:
        contracts = filter_contracts(status, created_after, classification)
        
        dbml_statements = []
        
        # Header
        dbml_statements.append("// Data Contracts Export - DBML Format")
        dbml_statements.append(f"// Generated at: {datetime.now().isoformat()}Z")
        dbml_statements.append(f"// Total contracts: {len(contracts)}")
        dbml_statements.append("")
        
        # Project definition
        dbml_statements.append("Project data_contracts_export {")
        dbml_statements.append("  database_type: 'PostgreSQL'")
        dbml_statements.append("  Note: 'Data contracts schema export'")
        dbml_statements.append("}")
        dbml_statements.append("")
        
        # Contracts table
        dbml_statements.append("Table data_contracts {")
        dbml_statements.append("  contract_id uuid [primary key]")
        dbml_statements.append("  name varchar(255) [not null]")
        dbml_statements.append("  version varchar(50) [not null]")
        dbml_statements.append("  description text")
        dbml_statements.append("  data_source varchar(255)")
        dbml_statements.append("  schema_definition jsonb")
        dbml_statements.append("  quality_rules jsonb")
        dbml_statements.append("  compliance_info jsonb")
        dbml_statements.append("  status varchar(50) [default: 'active']")
        dbml_statements.append("  created_at timestamp [default: `now()`]")
        dbml_statements.append("  updated_at timestamp [default: `now()`]")
        dbml_statements.append("")
        dbml_statements.append("  Note: 'Data contracts registry table'")
        dbml_statements.append("}")
        dbml_statements.append("")
        
        # Generate tables from contract schemas
        for contract in contracts:
            if "schema" in contract and "tables" in contract["schema"]:
                for table in contract["schema"]["tables"]:
                    table_name = table["name"]
                    dbml_statements.append(f"Table {table_name} {{")
                    
                    for column in table["columns"]:
                        col_def = f"  {column['name']} {column['type']}"
                        
                        attributes = []
                        if column.get("required", False):
                            attributes.append("not null")
                        if column.get("pii", False):
                            attributes.append("note: 'PII data'")
                        
                        if attributes:
                            col_def += f" [{', '.join(attributes)}]"
                        
                        dbml_statements.append(col_def)
                    
                    dbml_statements.append("")
                    dbml_statements.append(f"  Note: 'Table from contract: {contract['name']}'")
                    dbml_statements.append("}")
                    dbml_statements.append("")
        
        dbml_content = "\n".join(dbml_statements)
        
        return Response(
            content=dbml_content,
            media_type="text/plain",
            headers={
                "Content-Disposition": f"attachment; filename=contracts_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.dbml"
            }
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro ao exportar contratos: {str(e)}")

@router.get("/formats")
async def get_export_formats():
    """
    Lista formatos de export disponíveis
    """
    return {
        "available_formats": [
            {
                "format": "json",
                "description": "JavaScript Object Notation",
                "endpoint": "/api/v1/contracts/export/json",
                "content_type": "application/json"
            },
            {
                "format": "yaml",
                "description": "YAML Ain't Markup Language",
                "endpoint": "/api/v1/contracts/export/yaml",
                "content_type": "application/x-yaml"
            },
            {
                "format": "sql",
                "description": "Structured Query Language",
                "endpoint": "/api/v1/contracts/export/sql",
                "content_type": "application/sql"
            },
            {
                "format": "dbml",
                "description": "Database Markup Language",
                "endpoint": "/api/v1/contracts/export/dbml",
                "content_type": "text/plain"
            }
        ],
        "common_filters": [
            "status",
            "created_after",
            "classification"
        ]
    }

@router.get("/stats")
async def get_export_stats():
    """
    Estatísticas dos contratos disponíveis para export
    """
    total_contracts = len(contracts_data)
    
    # Estatísticas por status
    status_stats = {}
    for contract in contracts_data:
        status = contract["status"]
        status_stats[status] = status_stats.get(status, 0) + 1
    
    # Estatísticas por classificação
    classification_stats = {}
    for contract in contracts_data:
        classification = contract["compliance"]["data_classification"]
        classification_stats[classification] = classification_stats.get(classification, 0) + 1
    
    # Estatísticas por fonte de dados
    source_stats = {}
    for contract in contracts_data:
        source = contract["data_source"]
        source_stats[source] = source_stats.get(source, 0) + 1
    
    return {
        "total_contracts": total_contracts,
        "statistics": {
            "by_status": status_stats,
            "by_classification": classification_stats,
            "by_data_source": source_stats
        },
        "last_updated": max(contract["updated_at"] for contract in contracts_data) if contracts_data else None
    }

