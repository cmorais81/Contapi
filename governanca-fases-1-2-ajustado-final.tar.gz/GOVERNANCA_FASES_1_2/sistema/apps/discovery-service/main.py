#!/usr/bin/env python3
"""
Discovery Service - Sistema de Governança de Dados
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

app = FastAPI(
    title="Discovery Service - Governança de Dados",
    description="Discovery Service do Sistema de Governança de Dados",
    version="1.1.0"
)

# Configurar CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
async def root():
    """Endpoint raiz"""
    return {
        "message": "Discovery Service - Sistema de Governança de Dados",
        "status": "running"
    }

@app.get("/health")
async def health_check():
    """Health check do serviço"""
    return {"status": "healthy", "service": "discovery-service"}

@app.get("/api/v1/status")
async def get_status():
    """Status do serviço"""
    return {
        "service": "discovery-service",
        "status": "operational",
        "version": "1.1.0"
    }

if __name__ == "__main__":
    print("Iniciando Discovery Service na porta 8009...")
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8009,
        log_level="info"
    )
