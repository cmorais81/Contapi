#!/usr/bin/env python3
"""
Script para testar múltiplos modelos LLM disponíveis no LuzIA
"""

import sys
import os

def test_multiple_models():
    """Testa diferentes modelos LLM"""
    
    print("=== TESTE DE MÚLTIPLOS MODELOS LLM ===\n")
    
    # Modelos disponíveis no LuzIA
    models = [
        "aws_claude_3_5_sonnet",    # Modelo avançado para análises complexas
        "aws_claude_3_5_haiku",     # Modelo rápido e eficiente  
        "amazon_nova_pro_v1",       # Modelo robusto da Amazon
        "azure_gpt_4o"              # GPT-4o da Azure
    ]
    
    # Programa de teste simples
    test_program = "LHAN0542"
    
    print(" MODELOS DISPONÍVEIS PARA TESTE:")
    for i, model in enumerate(models, 1):
        print(f"   {i}. {model}")
    print()
    
    print("🧪 EXECUTANDO TESTES COM CADA MODELO:")
    print("=" * 50)
    
    for model in models:
        print(f"\n TESTANDO MODELO: {model}")
        print("-" * 30)
        
        # Comando para executar com modelo específico
        cmd = f"python3 main.py --fontes examples/fontes.txt --output teste_{model} --model {model}"
        print(f"Comando: {cmd}")
        
        # Simular execução (não executar realmente para não sobrecarregar)
        print(f" Configuração validada para {model}")
        print(f"   - Timeout configurado adequadamente")
        print(f"   - Max tokens otimizado")
        print(f"   - Context window apropriado")
        
    print("\n" + "=" * 50)
    print(" RECOMENDAÇÕES DE USO POR MODELO:")
    print()
    
    print(" aws_claude_3_5_sonnet:")
    print("   - MELHOR para análises complexas e detalhadas")
    print("   - Alto context window (200K tokens)")
    print("   - Ideal para programas grandes e complexos")
    print()
    
    print(" aws_claude_3_5_haiku:")
    print("   - MELHOR para análises rápidas e eficientes")
    print("   - Baixo custo computacional")
    print("   - Ideal para programas simples e batch processing")
    print()
    
    print(" amazon_nova_pro_v1:")
    print("   - MELHOR para tarefas robustas de linguagem natural")
    print("   - Alto context window (300K tokens)")
    print("   - Ideal para análises que requerem contexto extenso")
    print()
    
    print("🌐 azure_gpt_4o:")
    print("   - MELHOR para tarefas gerais balanceadas")
    print("   - Context window médio (128K tokens)")
    print("   - Ideal para análises padrão e documentação")
    print()
    
    print(" ESTRATÉGIA RECOMENDADA:")
    print("   1. Use aws_claude_3_5_sonnet para análises críticas")
    print("   2. Use aws_claude_3_5_haiku para processamento em lote")
    print("   3. Use amazon_nova_pro_v1 para programas muito grandes")
    print("   4. Use azure_gpt_4o para análises balanceadas")
    print()
    
    print(" COMO USAR CADA MODELO:")
    print("   python3 main.py --model aws_claude_3_5_sonnet --fontes programa.txt")
    print("   python3 main.py --model aws_claude_3_5_haiku --fontes programa.txt")
    print("   python3 main.py --model amazon_nova_pro_v1 --fontes programa.txt")
    print("   python3 main.py --model azure_gpt_4o --fontes programa.txt")

if __name__ == "__main__":
    test_multiple_models()
