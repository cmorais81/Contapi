#!/bin/bash

# Sistema de Governança de Dados v3.0
# Script de Inicialização Completa
# Versão: 3.0.0
# Data: 30/07/2025

set -e

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Função para logging
log() {
    echo -e "${BLUE}[$(date +'%Y-%m-%d %H:%M:%S')]${NC} $1"
}

success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Banner
echo "=================================================="
echo "  Sistema de Governança de Dados v3.0"
echo "  Inicialização Completa dos Microserviços"
echo "=================================================="
echo ""

# Verificar pré-requisitos
log "Verificando pré-requisitos..."

# Verificar Docker
if ! command -v docker &> /dev/null; then
    error "Docker não encontrado. Por favor, instale o Docker."
    exit 1
fi

# Verificar Docker Compose
if ! command -v docker-compose &> /dev/null; then
    error "Docker Compose não encontrado. Por favor, instale o Docker Compose."
    exit 1
fi

# Verificar PostgreSQL
if ! command -v psql &> /dev/null; then
    warning "PostgreSQL client não encontrado. Algumas operações podem falhar."
fi

success "Pré-requisitos verificados"

# Configurar variáveis de ambiente
log "Configurando variáveis de ambiente..."

export DATABASE_URL=${DATABASE_URL:-"postgresql://postgres:postgres@localhost:5432/governance_v3_0"}
export REDIS_URL=${REDIS_URL:-"redis://localhost:6379"}
export JWT_SECRET=${JWT_SECRET:-"governance-secret-key-v3-0"}
export LOG_LEVEL=${LOG_LEVEL:-"info"}
export ENV=${ENV:-"development"}

success "Variáveis de ambiente configuradas"

# Verificar banco de dados
log "Verificando banco de dados..."

DB_NAME="governance_v3_0"
if sudo -u postgres psql -lqt | cut -d \| -f 1 | grep -qw $DB_NAME; then
    success "Banco de dados $DB_NAME já existe"
else
    log "Criando banco de dados $DB_NAME..."
    sudo -u postgres createdb $DB_NAME
    success "Banco de dados $DB_NAME criado"
fi

# Aplicar schema
log "Aplicando schema do banco de dados..."
if [ -f "../modelo_dados/schema_v3_0_final.sql" ]; then
    sudo -u postgres psql -d $DB_NAME -f ../modelo_dados/schema_v3_0_final.sql > /dev/null 2>&1
    success "Schema aplicado com sucesso"
else
    warning "Arquivo de schema não encontrado. Continuando sem aplicar schema."
fi

# Navegar para diretório do código fonte
cd "$(dirname "$0")/../codigo_fonte" || exit 1

# Verificar se docker-compose.yml existe
if [ ! -f "docker-compose.yml" ]; then
    error "Arquivo docker-compose.yml não encontrado"
    exit 1
fi

# Parar serviços existentes
log "Parando serviços existentes..."
docker-compose down > /dev/null 2>&1 || true
success "Serviços existentes parados"

# Construir imagens
log "Construindo imagens Docker..."
docker-compose build --no-cache > /dev/null 2>&1
success "Imagens construídas"

# Iniciar serviços
log "Iniciando serviços..."
docker-compose up -d

# Aguardar serviços ficarem prontos
log "Aguardando serviços ficarem prontos..."
sleep 30

# Verificar status dos serviços
log "Verificando status dos serviços..."

services=(
    "api-gateway:8000"
    "contract-service:8001"
    "audit-service:8002"
    "auto-discovery-service:8003"
    "catalog-service:8004"
    "analytics-service:8005"
    "identity-service:8006"
    "quality-service:8007"
    "notification-service:8008"
    "governance-service:8009"
    "workflow-service:8010"
    "lineage-service:8011"
)

healthy_services=0
total_services=${#services[@]}

for service in "${services[@]}"; do
    service_name=$(echo $service | cut -d: -f1)
    port=$(echo $service | cut -d: -f2)
    
    if curl -s http://localhost:$port/health > /dev/null 2>&1; then
        success "$service_name (porta $port) - ONLINE"
        ((healthy_services++))
    else
        error "$service_name (porta $port) - OFFLINE"
    fi
done

# Resumo final
echo ""
echo "=================================================="
echo "  RESUMO DA INICIALIZAÇÃO"
echo "=================================================="
echo "Serviços online: $healthy_services/$total_services"
echo "Taxa de sucesso: $(( healthy_services * 100 / total_services ))%"
echo ""

if [ $healthy_services -eq $total_services ]; then
    success "Todos os serviços estão online!"
    echo ""
    echo "URLs de acesso:"
    echo "- API Gateway: http://localhost:8000"
    echo "- Documentação: http://localhost:8000/docs"
    echo "- Contract Service: http://localhost:8001"
    echo "- Identity Service: http://localhost:8006"
    echo ""
    echo "Para parar os serviços: docker-compose down"
    echo "Para ver logs: docker-compose logs -f"
    echo "Para status: docker-compose ps"
else
    warning "Alguns serviços não iniciaram corretamente"
    echo ""
    echo "Para diagnosticar problemas:"
    echo "- Ver logs: docker-compose logs"
    echo "- Status detalhado: docker-compose ps"
    echo "- Reiniciar: docker-compose restart"
fi

echo ""
echo "=================================================="
echo "  Sistema de Governança de Dados v3.0 - Pronto!"
echo "=================================================="

