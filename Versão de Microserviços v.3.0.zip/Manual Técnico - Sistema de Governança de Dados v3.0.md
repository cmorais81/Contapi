# Manual Técnico - Sistema de Governança de Dados v3.0

## Sumário Executivo

**Versão**: 3.0.0 Final  
**Data**: 30/07/2025  
**Objetivo**: Manual técnico completo para implementação, configuração e manutenção do sistema  
**Público-alvo**: Desenvolvedores, DevOps, Arquitetos de Software, DBAs

## 1. Visão Geral da Arquitetura

### 1.1 Arquitetura de Microserviços

O sistema é composto por **12 microserviços** implementados seguindo os princípios SOLID:

#### Microserviços Core (Implementados)
1. **API Gateway** (porta 8000) - Roteamento e autenticação
2. **Contract Service** (porta 8001) - Gestão de contratos de dados
3. **Identity Service** (porta 8006) - Autenticação e autorização
4. **Audit Service** (porta 8002) - Auditoria e compliance
5. **Quality Service** (porta 8007) - Qualidade de dados
6. **Catalog Service** (porta 8004) - Catálogo de entidades
7. **Lineage Service** (porta 8011) - Rastreamento de linhagem
8. **Governance Service** (porta 8009) - Políticas de governança
9. **Analytics Service** (porta 8005) - Métricas e relatórios
10. **Notification Service** (porta 8008) - Alertas e notificações
11. **Workflow Service** (porta 8010) - Automação de processos
12. **Auto Discovery Service** (porta 8003) - Descoberta automática

### 1.2 Stack Tecnológico

#### Backend
- **Python 3.11+** - Linguagem principal
- **FastAPI** - Framework web assíncrono
- **PostgreSQL 14+** - Banco de dados principal
- **Redis** - Cache e sessões
- **Kafka** - Mensageria e eventos (planejado)

#### Infraestrutura
- **Docker** - Containerização
- **Docker Compose** - Orquestração local
- **Nginx** - Proxy reverso (produção)
- **Azure/AWS** - Cloud providers suportados

#### Monitoramento
- **Prometheus** - Métricas
- **Grafana** - Dashboards
- **ELK Stack** - Logs centralizados

### 1.3 Princípios Arquiteturais

#### SOLID Principles
- **Single Responsibility**: Cada classe tem uma única responsabilidade
- **Open/Closed**: Extensível via interfaces, fechado para modificação
- **Liskov Substitution**: Implementações intercambiáveis
- **Interface Segregation**: Interfaces específicas e focadas
- **Dependency Inversion**: Dependência de abstrações, não implementações

#### Design Patterns Implementados
- **Repository Pattern** - Abstração de acesso a dados
- **Factory Pattern** - Criação de objetos complexos
- **Strategy Pattern** - Algoritmos intercambiáveis
- **Observer Pattern** - Notificações e eventos
- **Dependency Injection** - Inversão de controle

## 2. Modelo de Dados

### 2.1 Estrutura do Banco de Dados

O sistema utiliza **PostgreSQL** com **22 tabelas principais** organizadas em módulos funcionais:

#### Contratos de Dados
- `contracts` - Contratos principais
- `contract_layout_templates` - Templates versionados
- `tenant_contract_config` - Configuração por tenant

#### Usuários e Identidade
- `users` - Usuários do sistema
- `user_sessions` - Sessões ativas

#### Catálogo de Dados
- `data_entities` - Entidades de dados
- `data_fields` - Campos das entidades

#### Linhagem e Qualidade
- `data_lineage` - Rastreamento de linhagem
- `quality_rules` - Regras de qualidade
- `quality_executions` - Execuções de qualidade

#### Auditoria e Compliance
- `audit_events` - Eventos de auditoria
- `compliance_assessments` - Avaliações de compliance

#### Automação
- `workflows` - Definições de workflow
- `workflow_executions` - Execuções de workflow
- `notifications` - Notificações e alertas

#### Analytics
- `analytics_metrics` - Métricas do sistema

### 2.2 Características Técnicas

#### Tipos de Dados Padronizados
- **TEXT** - Todos os campos de texto (substituindo VARCHAR)
- **TIMESTAMPTZ** - Todos os timestamps com timezone
- **JSONB** - Dados estruturados e metadados
- **DECIMAL** - Valores numéricos precisos

#### Índices Otimizados
- **Índices compostos** para consultas frequentes
- **Índices parciais** para dados ativos
- **Índices GIN** para campos JSONB
- **Índices de texto** para busca full-text

#### Constraints e Integridade
- **Foreign Keys** para integridade referencial
- **Check Constraints** para validação de domínio
- **Unique Constraints** para unicidade
- **Not Null** para campos obrigatórios

### 2.3 Multi-Tenancy

#### Isolamento de Dados
- **tenant_id** em todas as tabelas principais
- **Row Level Security (RLS)** para isolamento automático
- **Índices por tenant** para performance
- **Configurações específicas** por organização

## 3. Configuração e Instalação

### 3.1 Pré-requisitos

#### Software Necessário
```bash
# Sistema operacional
Ubuntu 22.04+ / CentOS 8+ / macOS 12+

# Runtime
Python 3.11+
PostgreSQL 14+
Redis 6+
Docker 20.10+
Docker Compose 2.0+

# Ferramentas de desenvolvimento
Git 2.30+
curl
wget
```

#### Recursos de Hardware
```
Desenvolvimento:
- CPU: 4 cores
- RAM: 8GB
- Disco: 50GB SSD

Produção (pequeno):
- CPU: 8 cores
- RAM: 16GB
- Disco: 200GB SSD

Produção (médio):
- CPU: 16 cores
- RAM: 32GB
- Disco: 500GB SSD
```

### 3.2 Instalação Local

#### 1. Clonar Repositório
```bash
# Extrair pacote
unzip sistema-governanca-dados-v3.0-final.zip
cd SISTEMA_GOVERNANCA_V3_0_FINAL/codigo_fonte/
```

#### 2. Configurar Banco de Dados
```bash
# Criar banco PostgreSQL
sudo -u postgres createdb governance_v3_0

# Aplicar schema
sudo -u postgres psql -d governance_v3_0 -f database/schema_v3_0_final.sql

# Verificar instalação
sudo -u postgres psql -d governance_v3_0 -c "\dt"
```

#### 3. Configurar Variáveis de Ambiente
```bash
# Criar arquivo .env
cat > .env << EOF
# Database
DATABASE_URL=postgresql://postgres:password@localhost:5432/governance_v3_0
REDIS_URL=redis://localhost:6379/0

# Security
JWT_SECRET_KEY=your-super-secret-jwt-key-here
ENCRYPTION_KEY=your-32-char-encryption-key-here

# Services
API_GATEWAY_URL=http://localhost:8000
CONTRACT_SERVICE_URL=http://localhost:8001
IDENTITY_SERVICE_URL=http://localhost:8006

# External Services
KAFKA_BOOTSTRAP_SERVERS=localhost:9092
DATABRICKS_HOST=your-databricks-host
DATABRICKS_TOKEN=your-databricks-token

# Monitoring
PROMETHEUS_URL=http://localhost:9090
GRAFANA_URL=http://localhost:3000
EOF
```

#### 4. Instalar Dependências
```bash
# Instalar dependências Python
pip install -r requirements.txt

# Ou usar ambiente virtual
python -m venv venv
source venv/bin/activate  # Linux/Mac
# venv\Scripts\activate   # Windows
pip install -r requirements.txt
```

#### 5. Iniciar Serviços
```bash
# Usando Docker Compose (recomendado)
docker-compose up -d

# Ou iniciar manualmente
./scripts/start_all_services.sh

# Verificar status
curl http://localhost:8000/health
curl http://localhost:8001/health
```

### 3.3 Configuração de Produção

#### 1. Configuração de Banco
```sql
-- Configurações de performance PostgreSQL
ALTER SYSTEM SET shared_buffers = '256MB';
ALTER SYSTEM SET effective_cache_size = '1GB';
ALTER SYSTEM SET maintenance_work_mem = '64MB';
ALTER SYSTEM SET checkpoint_completion_target = 0.9;
ALTER SYSTEM SET wal_buffers = '16MB';
ALTER SYSTEM SET default_statistics_target = 100;
ALTER SYSTEM SET random_page_cost = 1.1;
ALTER SYSTEM SET effective_io_concurrency = 200;

-- Recarregar configuração
SELECT pg_reload_conf();
```

#### 2. Configuração de Segurança
```bash
# Configurar SSL/TLS
openssl req -x509 -newkey rsa:4096 -keyout key.pem -out cert.pem -days 365 -nodes

# Configurar firewall
ufw allow 22/tcp
ufw allow 80/tcp
ufw allow 443/tcp
ufw deny 8000:8011/tcp  # Bloquear acesso direto aos microserviços
ufw enable

# Configurar backup automático
crontab -e
# Adicionar: 0 2 * * * /opt/governance/scripts/backup_database.sh
```

#### 3. Monitoramento
```yaml
# docker-compose.monitoring.yml
version: '3.8'
services:
  prometheus:
    image: prom/prometheus:latest
    ports:
      - "9090:9090"
    volumes:
      - ./monitoring/prometheus.yml:/etc/prometheus/prometheus.yml
      
  grafana:
    image: grafana/grafana:latest
    ports:
      - "3000:3000"
    environment:
      - GF_SECURITY_ADMIN_PASSWORD=admin123
    volumes:
      - grafana-storage:/var/lib/grafana
      
volumes:
  grafana-storage:
```

## 4. APIs e Endpoints

### 4.1 API Gateway (porta 8000)

#### Autenticação
```bash
# Login
POST /auth/login
{
  "email": "user@example.com",
  "password": "password123"
}

# Refresh token
POST /auth/refresh
{
  "refresh_token": "your-refresh-token"
}

# Logout
POST /auth/logout
Authorization: Bearer your-jwt-token
```

#### Roteamento
```bash
# Health check
GET /health

# Documentação
GET /docs

# Métricas
GET /metrics

# Roteamento para serviços
GET /api/v1/contracts/*     -> Contract Service
GET /api/v1/entities/*      -> Catalog Service
GET /api/v1/quality/*       -> Quality Service
```

### 4.2 Contract Service (porta 8001)

#### Wizard de Contratos
```bash
# Página inicial do wizard
GET /api/v1/wizard/

# Templates disponíveis
GET /api/v1/wizard/step1/templates

# Configurar contrato
POST /api/v1/wizard/step2/configure
{
  "name": "Dados de Vendas",
  "description": "Dataset de vendas mensais",
  "owner_email": "vendas@empresa.com",
  "data_classification": "internal"
}

# Configurar schema
POST /api/v1/wizard/step3/schema
{
  "fields": [
    {
      "name": "customer_id",
      "type": "string",
      "description": "ID único do cliente",
      "is_pii": false
    },
    {
      "name": "customer_email",
      "type": "string", 
      "description": "Email do cliente",
      "is_pii": true,
      "pii_type": "email"
    }
  ]
}

# Configurar SLA
POST /api/v1/wizard/step4/sla
{
  "availability": "99.9%",
  "response_time": "< 100ms",
  "data_freshness": "daily"
}

# Gerar contrato final
POST /api/v1/wizard/step5/generate
```

#### CRUD de Contratos
```bash
# Listar contratos
GET /api/v1/contracts?tenant_id=tenant-001&status=active

# Criar contrato
POST /api/v1/contracts
{
  "name": "Novo Contrato",
  "template_id": "template-odc-v2-3-0",
  "owner_email": "owner@empresa.com"
}

# Obter contrato
GET /api/v1/contracts/{contract_id}

# Atualizar contrato
PUT /api/v1/contracts/{contract_id}

# Deletar contrato
DELETE /api/v1/contracts/{contract_id}
```

#### Funcionalidades Avançadas
```bash
# Detectar PII
POST /api/v1/pii/detect
{
  "text": "João Silva, email: joao@email.com, CPF: 123.456.789-00"
}

# Avaliar compliance
POST /api/v1/compliance/assess
{
  "contract_id": "contract-123",
  "framework": "LGPD"
}

# Auditoria de contrato
GET /api/v1/contracts/{contract_id}/audit
```

### 4.3 Identity Service (porta 8006)

#### Gestão de Usuários
```bash
# Criar usuário
POST /api/v1/users
{
  "email": "novo@usuario.com",
  "name": "Novo Usuário",
  "role": "data_steward",
  "tenant_id": "tenant-001"
}

# Listar usuários
GET /api/v1/users?tenant_id=tenant-001&role=data_owner

# Atualizar usuário
PUT /api/v1/users/{user_id}

# Desativar usuário
DELETE /api/v1/users/{user_id}
```

#### Gestão de Sessões
```bash
# Sessões ativas
GET /api/v1/sessions?user_id=user-123

# Invalidar sessão
DELETE /api/v1/sessions/{session_id}

# Invalidar todas as sessões do usuário
DELETE /api/v1/users/{user_id}/sessions
```

### 4.4 Quality Service (porta 8007)

#### Regras de Qualidade
```bash
# Criar regra
POST /api/v1/quality/rules
{
  "name": "Completeness Check",
  "rule_type": "completeness",
  "entity_id": "entity-123",
  "rule_definition": {
    "field": "customer_email",
    "condition": "NOT NULL",
    "threshold": 95.0
  }
}

# Executar regra
POST /api/v1/quality/rules/{rule_id}/execute

# Histórico de execuções
GET /api/v1/quality/executions?rule_id=rule-123&limit=50
```

#### Métricas de Qualidade
```bash
# Dashboard de qualidade
GET /api/v1/quality/dashboard?tenant_id=tenant-001

# Relatório de qualidade
GET /api/v1/quality/report?entity_id=entity-123&period=30d
```

## 5. Configurações Avançadas

### 5.1 Versionamento de Templates

#### Configuração de Templates
```sql
-- Ativar novo template
SELECT activate_layout_template('template-custom-v1', 'tenant-001');

-- Configurar template padrão
UPDATE tenant_contract_config 
SET default_template_id = 'template-odc-v2-3-0'
WHERE tenant_id = 'tenant-001';

-- Múltiplos templates ativos
UPDATE tenant_contract_config 
SET template_ids = '["template-odc-v2-2-2", "template-odc-v2-3-0", "template-lgpd-enhanced"]'
WHERE tenant_id = 'tenant-001';
```

#### Criação de Template Customizado
```json
{
  "name": "Custom LGPD Template",
  "version": "1.0.0",
  "template_type": "custom",
  "schema_structure": {
    "datasetDomain": "string",
    "quantumName": "string",
    "lgpdCompliance": {
      "dataController": "string",
      "legalBasis": "string",
      "retentionPeriod": "string"
    },
    "dataset": [{
      "table": "string",
      "columns": [{
        "column": "string",
        "personalDataStatus": "boolean",
        "piiType": "string",
        "lgpdCategory": "string"
      }]
    }]
  },
  "validation_rules": {
    "required_fields": ["datasetDomain", "quantumName", "lgpdCompliance"],
    "pii_detection": true,
    "lgpd_validation": true
  }
}
```

### 5.2 Multi-Tenancy

#### Configuração de Tenant
```python
# Criar novo tenant
async def create_tenant(tenant_data: TenantCreate):
    tenant = Tenant(
        id=generate_tenant_id(),
        name=tenant_data.name,
        domain=tenant_data.domain,
        settings={
            "compliance_frameworks": ["LGPD"],
            "default_data_classification": "internal",
            "auto_pii_detection": True
        }
    )
    
    # Configurar templates padrão
    config = TenantContractConfig(
        tenant_id=tenant.id,
        template_ids=["template-odc-v2-3-0", "template-lgpd-enhanced"],
        default_template_id="template-odc-v2-3-0"
    )
    
    return tenant, config
```

#### Isolamento de Dados
```sql
-- Habilitar Row Level Security
ALTER TABLE contracts ENABLE ROW LEVEL SECURITY;

-- Política de isolamento por tenant
CREATE POLICY tenant_isolation ON contracts
    FOR ALL TO application_role
    USING (tenant_id = current_setting('app.current_tenant_id'));

-- Configurar tenant na sessão
SET app.current_tenant_id = 'tenant-001';
```

### 5.3 Integração com Kafka

#### Configuração de Eventos
```python
# Producer de eventos
class EventProducer:
    def __init__(self, bootstrap_servers: str):
        self.producer = KafkaProducer(
            bootstrap_servers=bootstrap_servers,
            value_serializer=lambda v: json.dumps(v).encode('utf-8')
        )
    
    async def send_contract_event(self, event_type: str, contract_data: dict):
        event = {
            "event_type": event_type,
            "timestamp": datetime.utcnow().isoformat(),
            "tenant_id": contract_data.get("tenant_id"),
            "contract_id": contract_data.get("id"),
            "data": contract_data
        }
        
        self.producer.send('contract-events', value=event)
```

#### Tópicos de Eventos
```bash
# Criar tópicos Kafka
kafka-topics.sh --create --topic contract-events --bootstrap-server localhost:9092
kafka-topics.sh --create --topic quality-events --bootstrap-server localhost:9092
kafka-topics.sh --create --topic audit-events --bootstrap-server localhost:9092
kafka-topics.sh --create --topic notification-events --bootstrap-server localhost:9092
```

### 5.4 Integração com Databricks

#### Configuração Unity Catalog
```python
# Cliente Databricks
class DatabricksIntegration:
    def __init__(self, host: str, token: str):
        self.client = DatabricksClient(
            host=host,
            token=token
        )
    
    async def sync_catalog(self, tenant_id: str):
        # Sincronizar catálogo
        catalogs = self.client.catalogs.list()
        
        for catalog in catalogs:
            # Criar entidade no sistema
            entity = DataEntity(
                name=catalog.name,
                entity_type="catalog",
                source_system="databricks",
                tenant_id=tenant_id,
                metadata={
                    "catalog_id": catalog.id,
                    "owner": catalog.owner,
                    "created_at": catalog.created_at
                }
            )
            
            await self.entity_service.create(entity)
```

## 6. Monitoramento e Observabilidade

### 6.1 Métricas de Sistema

#### Métricas de Performance
```python
# Métricas customizadas
from prometheus_client import Counter, Histogram, Gauge

# Contadores
contract_created_total = Counter('contracts_created_total', 'Total contracts created', ['tenant_id'])
api_requests_total = Counter('api_requests_total', 'Total API requests', ['method', 'endpoint', 'status'])

# Histogramas
request_duration = Histogram('request_duration_seconds', 'Request duration', ['method', 'endpoint'])
quality_execution_duration = Histogram('quality_execution_duration_seconds', 'Quality rule execution time')

# Gauges
active_users = Gauge('active_users_total', 'Active users', ['tenant_id'])
database_connections = Gauge('database_connections_active', 'Active database connections')
```

#### Dashboard Grafana
```json
{
  "dashboard": {
    "title": "Governança de Dados - Overview",
    "panels": [
      {
        "title": "Contratos por Tenant",
        "type": "stat",
        "targets": [
          {
            "expr": "sum by (tenant_id) (contracts_created_total)"
          }
        ]
      },
      {
        "title": "Performance de APIs",
        "type": "graph",
        "targets": [
          {
            "expr": "rate(api_requests_total[5m])"
          }
        ]
      },
      {
        "title": "Qualidade de Dados",
        "type": "heatmap",
        "targets": [
          {
            "expr": "avg by (rule_type) (quality_pass_rate)"
          }
        ]
      }
    ]
  }
}
```

### 6.2 Logs Estruturados

#### Configuração de Logging
```python
import structlog

# Configurar logging estruturado
structlog.configure(
    processors=[
        structlog.stdlib.filter_by_level,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.add_log_level,
        structlog.stdlib.PositionalArgumentsFormatter(),
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        structlog.processors.UnicodeDecoder(),
        structlog.processors.JSONRenderer()
    ],
    context_class=dict,
    logger_factory=structlog.stdlib.LoggerFactory(),
    wrapper_class=structlog.stdlib.BoundLogger,
    cache_logger_on_first_use=True,
)

# Uso em serviços
logger = structlog.get_logger()

async def create_contract(contract_data: dict):
    logger.info(
        "Creating contract",
        tenant_id=contract_data.get("tenant_id"),
        contract_name=contract_data.get("name"),
        template_id=contract_data.get("template_id")
    )
```

### 6.3 Alertas e Notificações

#### Configuração de Alertas
```yaml
# alertmanager.yml
groups:
- name: governance.rules
  rules:
  - alert: HighErrorRate
    expr: rate(api_requests_total{status=~"5.."}[5m]) > 0.1
    for: 5m
    labels:
      severity: warning
    annotations:
      summary: "High error rate detected"
      
  - alert: QualityRuleFailure
    expr: quality_pass_rate < 0.8
    for: 2m
    labels:
      severity: critical
    annotations:
      summary: "Quality rule failure detected"
      
  - alert: DatabaseConnectionsHigh
    expr: database_connections_active > 80
    for: 1m
    labels:
      severity: warning
    annotations:
      summary: "High database connection usage"
```

## 7. Segurança

### 7.1 Autenticação e Autorização

#### JWT Configuration
```python
# Configuração JWT
JWT_SETTINGS = {
    "algorithm": "HS256",
    "access_token_expire_minutes": 30,
    "refresh_token_expire_days": 7,
    "secret_key": os.getenv("JWT_SECRET_KEY"),
    "issuer": "governance-system",
    "audience": "governance-users"
}

# Middleware de autenticação
class JWTMiddleware:
    async def __call__(self, request: Request, call_next):
        # Verificar token
        token = request.headers.get("Authorization")
        if token and token.startswith("Bearer "):
            try:
                payload = jwt.decode(
                    token[7:], 
                    JWT_SETTINGS["secret_key"], 
                    algorithms=[JWT_SETTINGS["algorithm"]]
                )
                request.state.user = payload
                request.state.tenant_id = payload.get("tenant_id")
            except jwt.InvalidTokenError:
                raise HTTPException(401, "Invalid token")
        
        return await call_next(request)
```

#### RBAC (Role-Based Access Control)
```python
# Definição de papéis
ROLES = {
    "admin": {
        "permissions": ["*"],
        "description": "Acesso total ao sistema"
    },
    "data_owner": {
        "permissions": [
            "contracts:read", "contracts:write", "contracts:delete",
            "entities:read", "entities:write",
            "quality:read", "quality:write"
        ],
        "description": "Proprietário de dados"
    },
    "data_steward": {
        "permissions": [
            "contracts:read", "contracts:write",
            "entities:read", "entities:write",
            "quality:read", "quality:write", "quality:execute"
        ],
        "description": "Administrador de dados"
    },
    "analyst": {
        "permissions": [
            "contracts:read", "entities:read", "quality:read",
            "analytics:read", "reports:read"
        ],
        "description": "Analista de dados"
    },
    "viewer": {
        "permissions": [
            "contracts:read", "entities:read", "quality:read"
        ],
        "description": "Visualizador"
    }
}

# Decorator para verificação de permissões
def require_permission(permission: str):
    def decorator(func):
        async def wrapper(request: Request, *args, **kwargs):
            user_role = request.state.user.get("role")
            user_permissions = ROLES.get(user_role, {}).get("permissions", [])
            
            if "*" not in user_permissions and permission not in user_permissions:
                raise HTTPException(403, "Insufficient permissions")
            
            return await func(request, *args, **kwargs)
        return wrapper
    return decorator
```

### 7.2 Proteção de Dados

#### Criptografia de Dados Sensíveis
```python
from cryptography.fernet import Fernet

class DataEncryption:
    def __init__(self, key: str):
        self.cipher = Fernet(key.encode())
    
    def encrypt_pii(self, data: str) -> str:
        """Criptografar dados PII"""
        return self.cipher.encrypt(data.encode()).decode()
    
    def decrypt_pii(self, encrypted_data: str) -> str:
        """Descriptografar dados PII"""
        return self.cipher.decrypt(encrypted_data.encode()).decode()
    
    def mask_pii(self, data: str, pii_type: str) -> str:
        """Mascarar dados PII para exibição"""
        if pii_type == "email":
            parts = data.split("@")
            return f"{parts[0][:2]}***@{parts[1]}"
        elif pii_type == "cpf":
            return f"***.***.{data[-3:]}-**"
        elif pii_type == "phone":
            return f"({data[:2]}) ****-{data[-4:]}"
        else:
            return "***"
```

#### Auditoria de Acesso
```python
async def log_access_event(
    user_id: str,
    entity_type: str,
    entity_id: str,
    action: str,
    request: Request
):
    """Registrar evento de acesso para auditoria"""
    event = AuditEvent(
        event_type="access",
        entity_type=entity_type,
        entity_id=entity_id,
        user_id=user_id,
        action_description=f"{action} on {entity_type}",
        ip_address=request.client.host,
        user_agent=request.headers.get("user-agent"),
        tenant_id=request.state.tenant_id,
        risk_level=calculate_risk_level(action, entity_type)
    )
    
    await audit_service.create_event(event)
```

## 8. Troubleshooting

### 8.1 Problemas Comuns

#### Erro de Conexão com Banco
```bash
# Verificar status do PostgreSQL
sudo systemctl status postgresql

# Verificar logs
sudo tail -f /var/log/postgresql/postgresql-14-main.log

# Testar conexão
psql -h localhost -U postgres -d governance_v3_0 -c "SELECT version();"

# Verificar configurações
sudo -u postgres psql -c "SHOW config_file;"
```

#### Erro de Autenticação JWT
```python
# Debug de token JWT
import jwt

def debug_jwt_token(token: str):
    try:
        # Decodificar sem verificar assinatura
        payload = jwt.decode(token, options={"verify_signature": False})
        print(f"Payload: {payload}")
        
        # Verificar expiração
        exp = payload.get("exp")
        if exp and datetime.fromtimestamp(exp) < datetime.utcnow():
            print("Token expirado")
        
    except Exception as e:
        print(f"Erro ao decodificar token: {e}")
```

#### Performance de Consultas
```sql
-- Analisar plano de execução
EXPLAIN ANALYZE SELECT * FROM contracts WHERE tenant_id = 'tenant-001';

-- Verificar índices utilizados
SELECT schemaname, tablename, indexname, idx_tup_read, idx_tup_fetch 
FROM pg_stat_user_indexes 
WHERE schemaname = 'public';

-- Estatísticas de tabelas
SELECT schemaname, tablename, n_tup_ins, n_tup_upd, n_tup_del, n_live_tup, n_dead_tup
FROM pg_stat_user_tables 
WHERE schemaname = 'public';
```

### 8.2 Logs de Debug

#### Configuração de Debug
```python
# Configurar nível de log para debug
import logging

logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

# Logger específico para SQL
logging.getLogger('sqlalchemy.engine').setLevel(logging.INFO)
```

#### Análise de Performance
```bash
# Monitorar recursos do sistema
htop
iotop
nethogs

# Monitorar PostgreSQL
sudo -u postgres psql -c "SELECT * FROM pg_stat_activity WHERE state = 'active';"

# Monitorar Redis
redis-cli info memory
redis-cli info stats
```

## 9. Backup e Recuperação

### 9.1 Estratégia de Backup

#### Backup Automático
```bash
#!/bin/bash
# backup_database.sh

DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/opt/governance/backups"
DB_NAME="governance_v3_0"

# Criar diretório se não existir
mkdir -p $BACKUP_DIR

# Backup completo
sudo -u postgres pg_dump $DB_NAME | gzip > $BACKUP_DIR/governance_${DATE}.sql.gz

# Backup apenas schema
sudo -u postgres pg_dump --schema-only $DB_NAME > $BACKUP_DIR/schema_${DATE}.sql

# Remover backups antigos (manter 30 dias)
find $BACKUP_DIR -name "governance_*.sql.gz" -mtime +30 -delete

# Log do backup
echo "$(date): Backup completed - governance_${DATE}.sql.gz" >> $BACKUP_DIR/backup.log
```

#### Backup de Configurações
```bash
#!/bin/bash
# backup_configs.sh

CONFIG_DIR="/opt/governance/configs"
BACKUP_DIR="/opt/governance/backups/configs"
DATE=$(date +%Y%m%d_%H%M%S)

# Backup de configurações
tar -czf $BACKUP_DIR/configs_${DATE}.tar.gz $CONFIG_DIR

# Backup de certificados
tar -czf $BACKUP_DIR/certs_${DATE}.tar.gz /etc/ssl/governance/

# Backup de logs importantes
tar -czf $BACKUP_DIR/logs_${DATE}.tar.gz /var/log/governance/
```

### 9.2 Procedimentos de Recuperação

#### Restauração de Banco
```bash
# Parar serviços
docker-compose down

# Restaurar banco
sudo -u postgres dropdb governance_v3_0
sudo -u postgres createdb governance_v3_0
zcat /opt/governance/backups/governance_20250730_120000.sql.gz | sudo -u postgres psql governance_v3_0

# Verificar integridade
sudo -u postgres psql governance_v3_0 -c "SELECT count(*) FROM contracts;"

# Reiniciar serviços
docker-compose up -d
```

#### Recuperação de Desastre
```bash
# 1. Provisionar nova infraestrutura
# 2. Instalar dependências
# 3. Restaurar configurações
tar -xzf configs_backup.tar.gz -C /

# 4. Restaurar banco de dados
# 5. Restaurar certificados
tar -xzf certs_backup.tar.gz -C /

# 6. Iniciar serviços
systemctl start postgresql
docker-compose up -d

# 7. Verificar funcionamento
curl http://localhost:8000/health
```

## 10. Próximos Passos e Roadmap

### 10.1 Melhorias Planejadas

#### Curto Prazo (1-3 meses)
- **Interface Web** - Dashboard para usuários finais
- **APIs GraphQL** - Consultas complexas e flexíveis
- **Kafka Real** - Implementação completa de eventos
- **Databricks Sync** - Sincronização automática com Unity Catalog

#### Médio Prazo (3-6 meses)
- **Machine Learning** - Classificação automática de dados
- **Data Masking Service** - Mascaramento avançado de PII
- **Privacy Service** - Gestão completa de privacidade
- **Mobile App** - Aplicativo móvel para aprovações

#### Longo Prazo (6-12 meses)
- **AI Assistant** - Assistente para criação de contratos
- **Blockchain** - Imutabilidade de contratos críticos
- **Multi-Cloud** - Suporte a múltiplos provedores
- **Federation** - Federação entre organizações

### 10.2 Arquitetura Futura

#### Microserviços Adicionais
- **Data Masking Service** - Mascaramento de dados sensíveis
- **Privacy Service** - Gestão de privacidade e LGPD
- **Integration Service** - Conectores para sistemas externos
- **ML Service** - Machine Learning para classificação
- **Scheduler Service** - Agendamento de tarefas
- **External API Service** - APIs para integrações

#### Tecnologias Emergentes
- **Kubernetes** - Orquestração em produção
- **Istio** - Service mesh para comunicação
- **Apache Airflow** - Orquestração de workflows
- **Apache Spark** - Processamento de big data
- **TensorFlow** - Machine Learning avançado

---

**Documento mantido por**: Equipe de Desenvolvimento  
**Última atualização**: 30/07/2025  
**Versão do documento**: 3.0.0  
**Próxima revisão**: 30/08/2025

