-- =====================================================
-- SCHEMA SQL - SISTEMA DE GOVERNANÇA DE DADOS v3.0
-- Data: 2025-07-30
-- Versão: 3.0.0 Final
-- =====================================================

-- Extensões necessárias
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- =====================================================
-- TABELAS PRINCIPAIS - CONTRATOS DE DADOS
-- =====================================================

CREATE TABLE contracts (
    id TEXT PRIMARY KEY DEFAULT uuid_generate_v4()::TEXT,
    name TEXT NOT NULL,
    description TEXT,
    version TEXT NOT NULL DEFAULT '1.0.0',
    status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'active', 'deprecated', 'archived')),
    data_classification TEXT NOT NULL CHECK (data_classification IN ('public', 'internal', 'confidential', 'restricted')),
    owner_email TEXT NOT NULL,
    tenant_id TEXT NOT NULL,
    template_id TEXT,
    template_name TEXT,
    template_version TEXT,
    schema_definition JSONB,
    sla_requirements JSONB,
    compliance_requirements JSONB,
    pii_fields JSONB,
    quality_rules JSONB,
    lineage_info JSONB,
    generated_at TIMESTAMPTZ,
    generated_by TEXT,
    approved_at TIMESTAMPTZ,
    approved_by TEXT,
    data_criacao TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    data_atualizacao TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Índices para contracts
CREATE INDEX idx_contracts_owner_email ON contracts(owner_email);
CREATE INDEX idx_contracts_status ON contracts(status);
CREATE INDEX idx_contracts_data_classification ON contracts(data_classification);
CREATE INDEX idx_contracts_template_id ON contracts(template_id);
CREATE INDEX idx_contracts_tenant_id ON contracts(tenant_id);
CREATE INDEX idx_contracts_data_criacao ON contracts(data_criacao);
CREATE INDEX idx_contracts_approved_at ON contracts(approved_at);

-- =====================================================
-- VERSIONAMENTO DE OPEN DATA CONTRACT
-- =====================================================

CREATE TABLE contract_layout_templates (
    id TEXT PRIMARY KEY DEFAULT uuid_generate_v4()::TEXT,
    name TEXT NOT NULL,
    version TEXT NOT NULL,
    description TEXT,
    template_type TEXT NOT NULL CHECK (template_type IN ('open_data_contract', 'lgpd_enhanced', 'custom')),
    schema_structure JSONB NOT NULL,
    field_mappings JSONB,
    validation_rules JSONB,
    compliance_features JSONB,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    is_default BOOLEAN NOT NULL DEFAULT FALSE,
    created_by TEXT NOT NULL,
    data_criacao TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    data_atualizacao TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Índices para contract_layout_templates
CREATE INDEX idx_templates_template_type ON contract_layout_templates(template_type);
CREATE INDEX idx_templates_is_active ON contract_layout_templates(is_active);
CREATE INDEX idx_templates_is_default ON contract_layout_templates(is_default);
CREATE INDEX idx_templates_version ON contract_layout_templates(version);
CREATE INDEX idx_templates_data_criacao ON contract_layout_templates(data_criacao);

CREATE TABLE tenant_contract_config (
    id TEXT PRIMARY KEY DEFAULT uuid_generate_v4()::TEXT,
    tenant_id TEXT NOT NULL,
    template_ids JSONB,
    default_template_id TEXT,
    custom_settings JSONB,
    compliance_requirements JSONB,
    data_criacao TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    data_atualizacao TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Índices para tenant_contract_config
CREATE INDEX idx_tenant_config_tenant_id ON tenant_contract_config(tenant_id);
CREATE INDEX idx_tenant_config_default_template_id ON tenant_contract_config(default_template_id);

-- =====================================================
-- GESTÃO DE USUÁRIOS E IDENTIDADE
-- =====================================================

CREATE TABLE users (
    id TEXT PRIMARY KEY DEFAULT uuid_generate_v4()::TEXT,
    email TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('admin', 'data_owner', 'data_steward', 'analyst', 'viewer')),
    tenant_id TEXT NOT NULL,
    department TEXT,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    last_login TIMESTAMPTZ,
    password_hash TEXT,
    preferences JSONB,
    data_criacao TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    data_atualizacao TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Índices para users
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_tenant_id ON users(tenant_id);
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_users_is_active ON users(is_active);
CREATE INDEX idx_users_last_login ON users(last_login);

CREATE TABLE user_sessions (
    id TEXT PRIMARY KEY DEFAULT uuid_generate_v4()::TEXT,
    user_id TEXT NOT NULL,
    tenant_id TEXT NOT NULL,
    token_hash TEXT NOT NULL,
    expires_at TIMESTAMPTZ NOT NULL,
    ip_address TEXT,
    user_agent TEXT,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    data_criacao TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Índices para user_sessions
CREATE INDEX idx_sessions_user_id ON user_sessions(user_id);
CREATE INDEX idx_sessions_tenant_id ON user_sessions(tenant_id);
CREATE INDEX idx_sessions_token_hash ON user_sessions(token_hash);
CREATE INDEX idx_sessions_expires_at ON user_sessions(expires_at);
CREATE INDEX idx_sessions_is_active ON user_sessions(is_active);

-- =====================================================
-- ENTIDADES DE DADOS E CATÁLOGO
-- =====================================================

CREATE TABLE data_entities (
    id TEXT PRIMARY KEY DEFAULT uuid_generate_v4()::TEXT,
    name TEXT NOT NULL,
    description TEXT,
    entity_type TEXT NOT NULL CHECK (entity_type IN ('table', 'view', 'file', 'api', 'stream')),
    source_system TEXT NOT NULL,
    database_name TEXT,
    schema_name TEXT,
    table_name TEXT,
    file_path TEXT,
    data_classification TEXT NOT NULL CHECK (data_classification IN ('public', 'internal', 'confidential', 'restricted')),
    tenant_id TEXT NOT NULL,
    owner_email TEXT NOT NULL,
    steward_email TEXT,
    tags JSONB,
    schema_definition JSONB,
    sample_data JSONB,
    row_count BIGINT,
    size_bytes BIGINT,
    last_updated TIMESTAMPTZ,
    discovery_method TEXT CHECK (discovery_method IN ('manual', 'auto', 'scan')),
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    data_criacao TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    data_atualizacao TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Índices para data_entities
CREATE INDEX idx_entities_name ON data_entities(name);
CREATE INDEX idx_entities_entity_type ON data_entities(entity_type);
CREATE INDEX idx_entities_source_system ON data_entities(source_system);
CREATE INDEX idx_entities_data_classification ON data_entities(data_classification);
CREATE INDEX idx_entities_tenant_id ON data_entities(tenant_id);
CREATE INDEX idx_entities_owner_email ON data_entities(owner_email);
CREATE INDEX idx_entities_is_active ON data_entities(is_active);
CREATE INDEX idx_entities_last_updated ON data_entities(last_updated);

CREATE TABLE data_fields (
    id TEXT PRIMARY KEY DEFAULT uuid_generate_v4()::TEXT,
    entity_id TEXT NOT NULL,
    field_name TEXT NOT NULL,
    field_type TEXT NOT NULL CHECK (field_type IN ('string', 'integer', 'float', 'boolean', 'date', 'timestamp')),
    description TEXT,
    is_nullable BOOLEAN NOT NULL DEFAULT TRUE,
    is_primary_key BOOLEAN NOT NULL DEFAULT FALSE,
    is_foreign_key BOOLEAN NOT NULL DEFAULT FALSE,
    foreign_entity_id TEXT,
    foreign_field_id TEXT,
    data_classification TEXT CHECK (data_classification IN ('public', 'internal', 'confidential', 'restricted')),
    pii_type TEXT CHECK (pii_type IN ('name', 'email', 'cpf', 'phone', 'address', 'credit_card', 'none')),
    is_sensitive BOOLEAN NOT NULL DEFAULT FALSE,
    masking_rule TEXT,
    business_rules JSONB,
    sample_values JSONB,
    value_distribution JSONB,
    data_criacao TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    data_atualizacao TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Índices para data_fields
CREATE INDEX idx_fields_entity_id ON data_fields(entity_id);
CREATE INDEX idx_fields_field_name ON data_fields(field_name);
CREATE INDEX idx_fields_field_type ON data_fields(field_type);
CREATE INDEX idx_fields_is_primary_key ON data_fields(is_primary_key);
CREATE INDEX idx_fields_is_foreign_key ON data_fields(is_foreign_key);
CREATE INDEX idx_fields_pii_type ON data_fields(pii_type);
CREATE INDEX idx_fields_is_sensitive ON data_fields(is_sensitive);

-- =====================================================
-- LINHAGEM DE DADOS
-- =====================================================

CREATE TABLE data_lineage (
    id TEXT PRIMARY KEY DEFAULT uuid_generate_v4()::TEXT,
    source_entity_id TEXT NOT NULL,
    target_entity_id TEXT NOT NULL,
    source_field_id TEXT,
    target_field_id TEXT,
    transformation_type TEXT NOT NULL CHECK (transformation_type IN ('copy', 'transform', 'aggregate', 'join', 'filter')),
    transformation_logic TEXT,
    process_name TEXT,
    process_type TEXT CHECK (process_type IN ('etl', 'streaming', 'batch', 'manual')),
    tenant_id TEXT NOT NULL,
    confidence_score DECIMAL(3,2) CHECK (confidence_score >= 0.0 AND confidence_score <= 1.0),
    discovery_method TEXT CHECK (discovery_method IN ('auto', 'manual', 'inferred')),
    last_execution TIMESTAMPTZ,
    execution_frequency TEXT CHECK (execution_frequency IN ('daily', 'hourly', 'weekly', 'monthly')),
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    data_criacao TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    data_atualizacao TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Índices para data_lineage
CREATE INDEX idx_lineage_source_entity_id ON data_lineage(source_entity_id);
CREATE INDEX idx_lineage_target_entity_id ON data_lineage(target_entity_id);
CREATE INDEX idx_lineage_transformation_type ON data_lineage(transformation_type);
CREATE INDEX idx_lineage_process_name ON data_lineage(process_name);
CREATE INDEX idx_lineage_tenant_id ON data_lineage(tenant_id);
CREATE INDEX idx_lineage_is_active ON data_lineage(is_active);
CREATE INDEX idx_lineage_last_execution ON data_lineage(last_execution);

-- =====================================================
-- QUALIDADE DE DADOS
-- =====================================================

CREATE TABLE quality_rules (
    id TEXT PRIMARY KEY DEFAULT uuid_generate_v4()::TEXT,
    name TEXT NOT NULL,
    description TEXT,
    rule_type TEXT NOT NULL CHECK (rule_type IN ('completeness', 'accuracy', 'consistency', 'validity', 'uniqueness')),
    entity_id TEXT,
    field_id TEXT,
    rule_definition JSONB NOT NULL,
    threshold_warning DECIMAL(5,2),
    threshold_critical DECIMAL(5,2),
    tenant_id TEXT NOT NULL,
    owner_email TEXT NOT NULL,
    execution_frequency TEXT CHECK (execution_frequency IN ('hourly', 'daily', 'weekly', 'monthly', 'on_demand')),
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    last_execution TIMESTAMPTZ,
    last_result JSONB,
    data_criacao TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    data_atualizacao TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Índices para quality_rules
CREATE INDEX idx_quality_rules_rule_type ON quality_rules(rule_type);
CREATE INDEX idx_quality_rules_entity_id ON quality_rules(entity_id);
CREATE INDEX idx_quality_rules_field_id ON quality_rules(field_id);
CREATE INDEX idx_quality_rules_tenant_id ON quality_rules(tenant_id);
CREATE INDEX idx_quality_rules_owner_email ON quality_rules(owner_email);
CREATE INDEX idx_quality_rules_is_active ON quality_rules(is_active);
CREATE INDEX idx_quality_rules_last_execution ON quality_rules(last_execution);

CREATE TABLE quality_executions (
    id TEXT PRIMARY KEY DEFAULT uuid_generate_v4()::TEXT,
    rule_id TEXT NOT NULL,
    entity_id TEXT,
    execution_date TIMESTAMPTZ NOT NULL,
    records_evaluated BIGINT,
    records_passed BIGINT,
    records_failed BIGINT,
    pass_rate DECIMAL(5,2),
    status TEXT NOT NULL CHECK (status IN ('passed', 'warning', 'critical', 'failed')),
    execution_time_ms INTEGER,
    error_message TEXT,
    detailed_results JSONB,
    tenant_id TEXT NOT NULL,
    data_criacao TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Índices para quality_executions
CREATE INDEX idx_quality_executions_rule_id ON quality_executions(rule_id);
CREATE INDEX idx_quality_executions_entity_id ON quality_executions(entity_id);
CREATE INDEX idx_quality_executions_execution_date ON quality_executions(execution_date);
CREATE INDEX idx_quality_executions_status ON quality_executions(status);
CREATE INDEX idx_quality_executions_tenant_id ON quality_executions(tenant_id);
CREATE INDEX idx_quality_executions_pass_rate ON quality_executions(pass_rate);

-- =====================================================
-- AUDITORIA E COMPLIANCE
-- =====================================================

CREATE TABLE audit_events (
    id TEXT PRIMARY KEY DEFAULT uuid_generate_v4()::TEXT,
    event_type TEXT NOT NULL CHECK (event_type IN ('access', 'create', 'update', 'delete', 'export', 'share')),
    entity_type TEXT NOT NULL CHECK (entity_type IN ('contract', 'entity', 'user', 'rule')),
    entity_id TEXT NOT NULL,
    user_id TEXT,
    user_email TEXT,
    tenant_id TEXT NOT NULL,
    action_description TEXT,
    old_values JSONB,
    new_values JSONB,
    ip_address TEXT,
    user_agent TEXT,
    session_id TEXT,
    compliance_impact TEXT,
    risk_level TEXT CHECK (risk_level IN ('low', 'medium', 'high', 'critical')),
    data_criacao TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Índices para audit_events
CREATE INDEX idx_audit_events_event_type ON audit_events(event_type);
CREATE INDEX idx_audit_events_entity_type ON audit_events(entity_type);
CREATE INDEX idx_audit_events_entity_id ON audit_events(entity_id);
CREATE INDEX idx_audit_events_user_id ON audit_events(user_id);
CREATE INDEX idx_audit_events_tenant_id ON audit_events(tenant_id);
CREATE INDEX idx_audit_events_data_criacao ON audit_events(data_criacao);
CREATE INDEX idx_audit_events_risk_level ON audit_events(risk_level);

CREATE TABLE compliance_assessments (
    id TEXT PRIMARY KEY DEFAULT uuid_generate_v4()::TEXT,
    entity_id TEXT NOT NULL,
    framework TEXT NOT NULL CHECK (framework IN ('LGPD', 'GDPR', 'SOX', 'HIPAA', 'PCI_DSS')),
    assessment_date TIMESTAMPTZ NOT NULL,
    overall_score DECIMAL(5,2),
    compliance_status TEXT NOT NULL CHECK (compliance_status IN ('compliant', 'non_compliant', 'partial', 'unknown')),
    requirements_evaluated JSONB,
    findings JSONB,
    recommendations JSONB,
    assessor_email TEXT,
    tenant_id TEXT NOT NULL,
    next_assessment_date TIMESTAMPTZ,
    remediation_deadline TIMESTAMPTZ,
    data_criacao TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    data_atualizacao TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Índices para compliance_assessments
CREATE INDEX idx_compliance_entity_id ON compliance_assessments(entity_id);
CREATE INDEX idx_compliance_framework ON compliance_assessments(framework);
CREATE INDEX idx_compliance_assessment_date ON compliance_assessments(assessment_date);
CREATE INDEX idx_compliance_status ON compliance_assessments(compliance_status);
CREATE INDEX idx_compliance_tenant_id ON compliance_assessments(tenant_id);
CREATE INDEX idx_compliance_overall_score ON compliance_assessments(overall_score);
CREATE INDEX idx_compliance_next_assessment_date ON compliance_assessments(next_assessment_date);

-- =====================================================
-- NOTIFICAÇÕES E ALERTAS
-- =====================================================

CREATE TABLE notifications (
    id TEXT PRIMARY KEY DEFAULT uuid_generate_v4()::TEXT,
    type TEXT NOT NULL CHECK (type IN ('alert', 'warning', 'info', 'reminder')),
    category TEXT NOT NULL CHECK (category IN ('quality', 'compliance', 'security', 'system')),
    title TEXT NOT NULL,
    message TEXT NOT NULL,
    recipient_email TEXT NOT NULL,
    recipient_role TEXT,
    tenant_id TEXT NOT NULL,
    entity_id TEXT,
    rule_id TEXT,
    priority TEXT NOT NULL DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high', 'urgent')),
    channel TEXT NOT NULL DEFAULT 'email' CHECK (channel IN ('email', 'sms', 'slack', 'teams', 'webhook')),
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'sent', 'delivered', 'failed', 'read')),
    scheduled_for TIMESTAMPTZ,
    sent_at TIMESTAMPTZ,
    read_at TIMESTAMPTZ,
    metadata JSONB,
    retry_count INTEGER NOT NULL DEFAULT 0,
    max_retries INTEGER NOT NULL DEFAULT 3,
    data_criacao TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    data_atualizacao TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Índices para notifications
CREATE INDEX idx_notifications_type ON notifications(type);
CREATE INDEX idx_notifications_category ON notifications(category);
CREATE INDEX idx_notifications_recipient_email ON notifications(recipient_email);
CREATE INDEX idx_notifications_tenant_id ON notifications(tenant_id);
CREATE INDEX idx_notifications_status ON notifications(status);
CREATE INDEX idx_notifications_priority ON notifications(priority);
CREATE INDEX idx_notifications_scheduled_for ON notifications(scheduled_for);
CREATE INDEX idx_notifications_data_criacao ON notifications(data_criacao);

-- =====================================================
-- WORKFLOWS E AUTOMAÇÃO
-- =====================================================

CREATE TABLE workflows (
    id TEXT PRIMARY KEY DEFAULT uuid_generate_v4()::TEXT,
    name TEXT NOT NULL,
    description TEXT,
    workflow_type TEXT NOT NULL CHECK (workflow_type IN ('approval', 'data_processing', 'compliance', 'notification')),
    trigger_type TEXT NOT NULL CHECK (trigger_type IN ('manual', 'scheduled', 'event', 'api')),
    trigger_config JSONB,
    steps_definition JSONB NOT NULL,
    tenant_id TEXT NOT NULL,
    owner_email TEXT NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    version TEXT NOT NULL DEFAULT '1.0.0',
    last_execution TIMESTAMPTZ,
    execution_count INTEGER NOT NULL DEFAULT 0,
    success_rate DECIMAL(5,2),
    data_criacao TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    data_atualizacao TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Índices para workflows
CREATE INDEX idx_workflows_workflow_type ON workflows(workflow_type);
CREATE INDEX idx_workflows_trigger_type ON workflows(trigger_type);
CREATE INDEX idx_workflows_tenant_id ON workflows(tenant_id);
CREATE INDEX idx_workflows_owner_email ON workflows(owner_email);
CREATE INDEX idx_workflows_is_active ON workflows(is_active);
CREATE INDEX idx_workflows_last_execution ON workflows(last_execution);

CREATE TABLE workflow_executions (
    id TEXT PRIMARY KEY DEFAULT uuid_generate_v4()::TEXT,
    workflow_id TEXT NOT NULL,
    execution_date TIMESTAMPTZ NOT NULL,
    trigger_data JSONB,
    status TEXT NOT NULL CHECK (status IN ('running', 'completed', 'failed', 'cancelled')),
    current_step INTEGER,
    total_steps INTEGER,
    execution_time_ms INTEGER,
    error_message TEXT,
    step_results JSONB,
    tenant_id TEXT NOT NULL,
    executed_by TEXT,
    completed_at TIMESTAMPTZ,
    data_criacao TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Índices para workflow_executions
CREATE INDEX idx_workflow_executions_workflow_id ON workflow_executions(workflow_id);
CREATE INDEX idx_workflow_executions_execution_date ON workflow_executions(execution_date);
CREATE INDEX idx_workflow_executions_status ON workflow_executions(status);
CREATE INDEX idx_workflow_executions_tenant_id ON workflow_executions(tenant_id);
CREATE INDEX idx_workflow_executions_completed_at ON workflow_executions(completed_at);

-- =====================================================
-- ANALYTICS E MÉTRICAS
-- =====================================================

CREATE TABLE analytics_metrics (
    id TEXT PRIMARY KEY DEFAULT uuid_generate_v4()::TEXT,
    metric_name TEXT NOT NULL,
    metric_type TEXT NOT NULL CHECK (metric_type IN ('counter', 'gauge', 'histogram', 'summary')),
    category TEXT NOT NULL CHECK (category IN ('usage', 'performance', 'quality', 'compliance')),
    entity_type TEXT,
    entity_id TEXT,
    tenant_id TEXT NOT NULL,
    metric_value DECIMAL(15,4) NOT NULL,
    unit TEXT,
    dimensions JSONB,
    timestamp TIMESTAMPTZ NOT NULL,
    collection_method TEXT CHECK (collection_method IN ('auto', 'manual', 'calculated')),
    data_criacao TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Índices para analytics_metrics
CREATE INDEX idx_analytics_metric_name ON analytics_metrics(metric_name);
CREATE INDEX idx_analytics_metric_type ON analytics_metrics(metric_type);
CREATE INDEX idx_analytics_category ON analytics_metrics(category);
CREATE INDEX idx_analytics_entity_type ON analytics_metrics(entity_type);
CREATE INDEX idx_analytics_tenant_id ON analytics_metrics(tenant_id);
CREATE INDEX idx_analytics_timestamp ON analytics_metrics(timestamp);

-- =====================================================
-- FOREIGN KEYS E RELACIONAMENTOS
-- =====================================================

-- Relacionamentos de Contratos
ALTER TABLE contracts ADD CONSTRAINT fk_contracts_template_id 
    FOREIGN KEY (template_id) REFERENCES contract_layout_templates(id);

ALTER TABLE tenant_contract_config ADD CONSTRAINT fk_tenant_config_default_template_id 
    FOREIGN KEY (default_template_id) REFERENCES contract_layout_templates(id);

-- Relacionamentos de Usuários
ALTER TABLE user_sessions ADD CONSTRAINT fk_sessions_user_id 
    FOREIGN KEY (user_id) REFERENCES users(id);

-- Relacionamentos de Entidades
ALTER TABLE data_fields ADD CONSTRAINT fk_fields_entity_id 
    FOREIGN KEY (entity_id) REFERENCES data_entities(id);

ALTER TABLE data_fields ADD CONSTRAINT fk_fields_foreign_entity_id 
    FOREIGN KEY (foreign_entity_id) REFERENCES data_entities(id);

-- Relacionamentos de Linhagem
ALTER TABLE data_lineage ADD CONSTRAINT fk_lineage_source_entity_id 
    FOREIGN KEY (source_entity_id) REFERENCES data_entities(id);

ALTER TABLE data_lineage ADD CONSTRAINT fk_lineage_target_entity_id 
    FOREIGN KEY (target_entity_id) REFERENCES data_entities(id);

ALTER TABLE data_lineage ADD CONSTRAINT fk_lineage_source_field_id 
    FOREIGN KEY (source_field_id) REFERENCES data_fields(id);

ALTER TABLE data_lineage ADD CONSTRAINT fk_lineage_target_field_id 
    FOREIGN KEY (target_field_id) REFERENCES data_fields(id);

-- Relacionamentos de Qualidade
ALTER TABLE quality_rules ADD CONSTRAINT fk_quality_rules_entity_id 
    FOREIGN KEY (entity_id) REFERENCES data_entities(id);

ALTER TABLE quality_rules ADD CONSTRAINT fk_quality_rules_field_id 
    FOREIGN KEY (field_id) REFERENCES data_fields(id);

ALTER TABLE quality_executions ADD CONSTRAINT fk_quality_executions_rule_id 
    FOREIGN KEY (rule_id) REFERENCES quality_rules(id);

ALTER TABLE quality_executions ADD CONSTRAINT fk_quality_executions_entity_id 
    FOREIGN KEY (entity_id) REFERENCES data_entities(id);

-- Relacionamentos de Auditoria
ALTER TABLE audit_events ADD CONSTRAINT fk_audit_events_user_id 
    FOREIGN KEY (user_id) REFERENCES users(id);

ALTER TABLE audit_events ADD CONSTRAINT fk_audit_events_session_id 
    FOREIGN KEY (session_id) REFERENCES user_sessions(id);

ALTER TABLE compliance_assessments ADD CONSTRAINT fk_compliance_entity_id 
    FOREIGN KEY (entity_id) REFERENCES data_entities(id);

-- Relacionamentos de Notificações
ALTER TABLE notifications ADD CONSTRAINT fk_notifications_entity_id 
    FOREIGN KEY (entity_id) REFERENCES data_entities(id);

ALTER TABLE notifications ADD CONSTRAINT fk_notifications_rule_id 
    FOREIGN KEY (rule_id) REFERENCES quality_rules(id);

-- Relacionamentos de Workflows
ALTER TABLE workflow_executions ADD CONSTRAINT fk_workflow_executions_workflow_id 
    FOREIGN KEY (workflow_id) REFERENCES workflows(id);

-- Relacionamentos de Analytics
ALTER TABLE analytics_metrics ADD CONSTRAINT fk_analytics_entity_id 
    FOREIGN KEY (entity_id) REFERENCES data_entities(id);

-- =====================================================
-- TRIGGERS PARA ATUALIZAÇÃO AUTOMÁTICA
-- =====================================================

-- Função para atualizar data_atualizacao
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.data_atualizacao = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Triggers para todas as tabelas com data_atualizacao
CREATE TRIGGER update_contracts_updated_at BEFORE UPDATE ON contracts 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_templates_updated_at BEFORE UPDATE ON contract_layout_templates 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_tenant_config_updated_at BEFORE UPDATE ON tenant_contract_config 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_entities_updated_at BEFORE UPDATE ON data_entities 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_fields_updated_at BEFORE UPDATE ON data_fields 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_lineage_updated_at BEFORE UPDATE ON data_lineage 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_quality_rules_updated_at BEFORE UPDATE ON quality_rules 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_compliance_updated_at BEFORE UPDATE ON compliance_assessments 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_notifications_updated_at BEFORE UPDATE ON notifications 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_workflows_updated_at BEFORE UPDATE ON workflows 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- =====================================================
-- DADOS INICIAIS E CONFIGURAÇÃO
-- =====================================================

-- Templates padrão de Open Data Contract
INSERT INTO contract_layout_templates (id, name, version, description, template_type, schema_structure, is_active, is_default, created_by) VALUES
('template-odc-v2-2-2', 'Open Data Contract v2.2.2', '2.2.2', 'Template padrão Open Data Contract versão 2.2.2', 'open_data_contract', 
'{"datasetDomain": "string", "quantumName": "string", "userConsumptionMode": "string", "version": "string", "status": "string", "uuid": "string", "sourceSystem": "string", "productDl": "string", "productSlackChannel": "string", "productFeedbackUrl": "string", "productDashboardUrl": "string", "productDescription": "string", "productKeywords": ["string"], "tenant": "string", "pointOfContact": {"email": "string", "slack": "string", "phoneNumber": "string"}, "dataset": [{"table": "string", "sql": "string", "priorTableName": "string", "physicalName": "string", "description": "string", "tags": ["string"], "dataGranularity": "string", "columns": [{"column": "string", "physicalName": "string", "logicalType": "string", "physicalType": "string", "isNullable": true, "description": "string", "partitionStatus": true, "clusterStatus": true, "authoritativeDefinitions": [{"url": "string", "type": "string"}], "encryptedColumnName": "string", "transformSourceTables": [{"tableName": "string", "columnName": "string"}], "sampleValues": ["string"], "criticalDataElementStatus": true, "tags": ["string"], "classification": "string", "authClassification": "string", "personalDataStatus": true, "piiType": "string"}]}], "slaDefaultColumn": "string", "slaProperties": [{"property": "string", "value": "string", "unit": "string", "column": "string"}], "stakeholders": [{"username": "string", "role": "string", "dateIn": "string", "dateOut": "string", "replacedByUsername": "string"}], "roles": [{"role": "string", "access": "string", "firstLevelApprovers": "string", "secondLevelApprovers": "string"}]}', 
true, false, 'system'),

('template-odc-v2-3-0', 'Open Data Contract v2.3.0', '2.3.0', 'Template Open Data Contract versão 2.3.0 com melhorias', 'open_data_contract', 
'{"datasetDomain": "string", "quantumName": "string", "userConsumptionMode": "string", "version": "string", "status": "string", "uuid": "string", "sourceSystem": "string", "productDl": "string", "productSlackChannel": "string", "productFeedbackUrl": "string", "productDashboardUrl": "string", "productDescription": "string", "productKeywords": ["string"], "tenant": "string", "pointOfContact": {"email": "string", "slack": "string", "phoneNumber": "string"}, "dataset": [{"table": "string", "sql": "string", "priorTableName": "string", "physicalName": "string", "description": "string", "tags": ["string"], "dataGranularity": "string", "columns": [{"column": "string", "physicalName": "string", "logicalType": "string", "physicalType": "string", "isNullable": true, "description": "string", "partitionStatus": true, "clusterStatus": true, "authoritativeDefinitions": [{"url": "string", "type": "string"}], "encryptedColumnName": "string", "transformSourceTables": [{"tableName": "string", "columnName": "string"}], "sampleValues": ["string"], "criticalDataElementStatus": true, "tags": ["string"], "classification": "string", "authClassification": "string", "personalDataStatus": true, "piiType": "string"}]}], "slaDefaultColumn": "string", "slaProperties": [{"property": "string", "value": "string", "unit": "string", "column": "string"}], "stakeholders": [{"username": "string", "role": "string", "dateIn": "string", "dateOut": "string", "replacedByUsername": "string"}], "roles": [{"role": "string", "access": "string", "firstLevelApprovers": "string", "secondLevelApprovers": "string"}], "dataQuality": [{"dimension": "string", "type": "string", "weight": "string", "query": "string"}]}', 
true, true, 'system'),

('template-lgpd-enhanced', 'LGPD Enhanced Contract', '1.0.0', 'Template especializado para compliance LGPD', 'lgpd_enhanced', 
'{"datasetDomain": "string", "quantumName": "string", "version": "string", "status": "string", "uuid": "string", "sourceSystem": "string", "lgpdCompliance": {"dataController": "string", "dataProcessor": "string", "legalBasis": "string", "dataSubjectRights": ["string"], "retentionPeriod": "string", "dataMinimization": true, "consentManagement": {"consentRequired": true, "consentType": "string", "withdrawalMechanism": "string"}}, "personalDataInventory": [{"dataCategory": "string", "personalDataTypes": ["string"], "specialCategories": ["string"], "dataSubjects": ["string"], "purposes": ["string"], "recipients": ["string"], "transfers": [{"country": "string", "adequacyDecision": true, "safeguards": "string"}]}], "privacyByDesign": {"dataProtectionImpactAssessment": true, "privacyEnhancingTechnologies": ["string"], "dataAnonymization": "string", "pseudonymization": true}, "dataset": [{"table": "string", "description": "string", "columns": [{"column": "string", "logicalType": "string", "physicalType": "string", "isNullable": true, "description": "string", "personalDataStatus": true, "piiType": "string", "lgpdCategory": "string", "processingPurpose": "string", "legalBasis": "string", "retentionPeriod": "string", "dataSubjectRights": ["string"]}]}]}', 
true, false, 'system');

-- Usuário administrador padrão
INSERT INTO users (id, email, name, role, tenant_id, password_hash) VALUES
('admin-user-001', 'admin@governanca.com', 'Administrador Sistema', 'admin', 'tenant-default', crypt('admin123', gen_salt('bf')));

-- Configuração padrão para tenant
INSERT INTO tenant_contract_config (tenant_id, template_ids, default_template_id, compliance_requirements) VALUES
('tenant-default', '["template-odc-v2-2-2", "template-odc-v2-3-0", "template-lgpd-enhanced"]', 'template-odc-v2-3-0', '["LGPD"]');

-- =====================================================
-- VIEWS ÚTEIS PARA CONSULTAS
-- =====================================================

-- View para contratos com templates
CREATE VIEW contracts_with_templates AS
SELECT 
    c.*,
    t.name as template_display_name,
    t.version as template_version_used,
    t.template_type
FROM contracts c
LEFT JOIN contract_layout_templates t ON c.template_id = t.id;

-- View para métricas de qualidade
CREATE VIEW quality_metrics_summary AS
SELECT 
    qr.tenant_id,
    qr.rule_type,
    COUNT(*) as total_rules,
    COUNT(CASE WHEN qr.is_active THEN 1 END) as active_rules,
    AVG(qe.pass_rate) as avg_pass_rate,
    COUNT(CASE WHEN qe.status = 'passed' THEN 1 END) as passed_executions,
    COUNT(CASE WHEN qe.status = 'failed' THEN 1 END) as failed_executions
FROM quality_rules qr
LEFT JOIN quality_executions qe ON qr.id = qe.rule_id
GROUP BY qr.tenant_id, qr.rule_type;

-- View para status de compliance
CREATE VIEW compliance_status_summary AS
SELECT 
    ca.tenant_id,
    ca.framework,
    COUNT(*) as total_assessments,
    COUNT(CASE WHEN ca.compliance_status = 'compliant' THEN 1 END) as compliant_entities,
    COUNT(CASE WHEN ca.compliance_status = 'non_compliant' THEN 1 END) as non_compliant_entities,
    AVG(ca.overall_score) as avg_compliance_score
FROM compliance_assessments ca
GROUP BY ca.tenant_id, ca.framework;

-- =====================================================
-- FUNÇÕES ÚTEIS
-- =====================================================

-- Função para ativar template
CREATE OR REPLACE FUNCTION activate_layout_template(template_id_param TEXT, tenant_id_param TEXT)
RETURNS BOOLEAN AS $$
BEGIN
    -- Atualizar configuração do tenant para incluir o template
    UPDATE tenant_contract_config 
    SET template_ids = COALESCE(template_ids, '[]'::jsonb) || jsonb_build_array(template_id_param),
        data_atualizacao = NOW()
    WHERE tenant_id = tenant_id_param;
    
    -- Se não existe configuração para o tenant, criar uma nova
    IF NOT FOUND THEN
        INSERT INTO tenant_contract_config (tenant_id, template_ids, default_template_id)
        VALUES (tenant_id_param, jsonb_build_array(template_id_param), template_id_param);
    END IF;
    
    RETURN TRUE;
END;
$$ LANGUAGE plpgsql;

-- Função para criar versão de contrato
CREATE OR REPLACE FUNCTION create_contract_version(
    contract_id_param TEXT,
    new_version TEXT,
    change_description TEXT,
    user_email TEXT
)
RETURNS TEXT AS $$
DECLARE
    new_contract_id TEXT;
BEGIN
    -- Gerar novo ID para a versão
    new_contract_id := uuid_generate_v4()::TEXT;
    
    -- Criar nova versão baseada na anterior
    INSERT INTO contracts (
        id, name, description, version, status, data_classification,
        owner_email, tenant_id, template_id, template_name, template_version,
        schema_definition, sla_requirements, compliance_requirements,
        pii_fields, quality_rules, lineage_info, generated_by
    )
    SELECT 
        new_contract_id, name, description, new_version, 'draft', data_classification,
        owner_email, tenant_id, template_id, template_name, template_version,
        schema_definition, sla_requirements, compliance_requirements,
        pii_fields, quality_rules, lineage_info, user_email
    FROM contracts 
    WHERE id = contract_id_param;
    
    -- Registrar evento de auditoria
    INSERT INTO audit_events (
        event_type, entity_type, entity_id, user_email, tenant_id,
        action_description, new_values
    )
    SELECT 
        'create', 'contract', new_contract_id, user_email, tenant_id,
        'Nova versão criada: ' || change_description,
        jsonb_build_object('new_version', new_version, 'based_on', contract_id_param)
    FROM contracts 
    WHERE id = contract_id_param;
    
    RETURN new_contract_id;
END;
$$ LANGUAGE plpgsql;

-- =====================================================
-- COMENTÁRIOS FINAIS
-- =====================================================

COMMENT ON DATABASE governance_v1_2 IS 'Sistema de Governança de Dados v3.0 - Base de dados completa com suporte a multi-tenancy, versionamento de templates e compliance LGPD nativo';

