-- Schema SQL - Sistema de Governança de Dados v3.0
-- Gerado a partir do modelo DBML v3.0
-- Data: 30/07/2025
-- Correções: VARCHAR → TEXT, TIMESTAMP → TIMESTAMPTZ

-- Extensões necessárias
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- =====================================================
-- CORE ENTITIES - Entidades Principais do Sistema
-- =====================================================

CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  username TEXT NOT NULL UNIQUE,
  email TEXT NOT NULL UNIQUE,
  full_name TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'user',
  department TEXT,
  tenant_id TEXT NOT NULL,
  is_active BOOLEAN DEFAULT true,
  last_login TIMESTAMPTZ,
  preferences JSONB,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

COMMENT ON TABLE users IS 'Tabela central de usuários do sistema com suporte a multi-tenancy';
COMMENT ON COLUMN users.username IS 'Nome único do usuário no sistema';
COMMENT ON COLUMN users.email IS 'Email único para autenticação e notificações';
COMMENT ON COLUMN users.role IS 'Papel do usuário: admin, data_owner, analyst, viewer';
COMMENT ON COLUMN users.tenant_id IS 'Identificador do tenant para multi-tenancy';

CREATE TABLE contracts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  version TEXT NOT NULL DEFAULT '1.0.0',
  status TEXT NOT NULL DEFAULT 'draft',
  data_classification TEXT NOT NULL,
  owner_email TEXT NOT NULL,
  tenant_id TEXT NOT NULL,
  schema_definition JSONB,
  quality_rules JSONB,
  retention_policy JSONB,
  compliance_requirements JSONB,
  tags TEXT[],
  current_version_id UUID,
  layout_template_id INTEGER,
  version_count INTEGER DEFAULT 1,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

COMMENT ON TABLE contracts IS 'Contratos de dados com versionamento e templates flexíveis';
COMMENT ON COLUMN contracts.status IS 'Status: draft, active, deprecated, archived';
COMMENT ON COLUMN contracts.data_classification IS 'Classificação: public, internal, confidential, restricted';

CREATE TABLE entities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  entity_type TEXT NOT NULL,
  database_name TEXT,
  schema_name TEXT,
  table_name TEXT,
  connection_string TEXT,
  data_classification TEXT NOT NULL,
  owner_email TEXT NOT NULL,
  tenant_id TEXT NOT NULL,
  tags TEXT[],
  metadata JSONB,
  is_active BOOLEAN DEFAULT true,
  last_scanned TIMESTAMPTZ,
  row_count BIGINT,
  size_bytes BIGINT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

COMMENT ON TABLE entities IS 'Catálogo central de todas as entidades de dados da organização';
COMMENT ON COLUMN entities.entity_type IS 'Tipo: table, view, file, api, stream';

CREATE TABLE quality_rules (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  rule_type TEXT NOT NULL,
  entity_id UUID NOT NULL,
  column_name TEXT,
  rule_definition JSONB NOT NULL,
  threshold_warning DECIMAL(5,2),
  threshold_critical DECIMAL(5,2),
  is_active BOOLEAN DEFAULT true,
  schedule_cron TEXT,
  owner_email TEXT NOT NULL,
  tenant_id TEXT NOT NULL,
  tags TEXT[],
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

COMMENT ON TABLE quality_rules IS 'Regras de qualidade de dados executadas automaticamente';
COMMENT ON COLUMN quality_rules.rule_type IS 'Tipo: completeness, accuracy, consistency, validity, uniqueness';

-- =====================================================
-- AUDIT & COMPLIANCE - Auditoria e Conformidade
-- =====================================================

CREATE TABLE audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID,
  action TEXT NOT NULL,
  resource_type TEXT NOT NULL,
  resource_id UUID,
  tenant_id TEXT NOT NULL,
  ip_address INET,
  user_agent TEXT,
  details JSONB,
  before_state JSONB,
  after_state JSONB,
  success BOOLEAN NOT NULL DEFAULT true,
  error_message TEXT,
  session_id TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

COMMENT ON TABLE audit_logs IS 'Log completo de auditoria para compliance e segurança';
COMMENT ON COLUMN audit_logs.action IS 'Ação executada: CREATE, READ, UPDATE, DELETE, EXPORT';

CREATE TABLE compliance_assessments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  entity_id UUID NOT NULL,
  framework TEXT NOT NULL,
  assessment_date TIMESTAMPTZ NOT NULL DEFAULT now(),
  overall_score DECIMAL(5,2),
  status TEXT NOT NULL,
  findings JSONB,
  recommendations JSONB,
  assessor_email TEXT NOT NULL,
  tenant_id TEXT NOT NULL,
  next_assessment_date TIMESTAMPTZ,
  remediation_plan JSONB,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

COMMENT ON TABLE compliance_assessments IS 'Avaliações de compliance para diferentes frameworks regulatórios';
COMMENT ON COLUMN compliance_assessments.framework IS 'Framework: LGPD, GDPR, SOX, HIPAA, PCI-DSS';

CREATE TABLE pii_detections (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  entity_id UUID NOT NULL,
  column_name TEXT NOT NULL,
  pii_type TEXT NOT NULL,
  confidence_score DECIMAL(5,2) NOT NULL,
  detection_method TEXT NOT NULL,
  sample_values TEXT[],
  row_count BIGINT,
  percentage DECIMAL(5,2),
  status TEXT DEFAULT 'detected',
  reviewed_by TEXT,
  reviewed_at TIMESTAMPTZ,
  tenant_id TEXT NOT NULL,
  detection_date TIMESTAMPTZ DEFAULT now(),
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

COMMENT ON TABLE pii_detections IS 'Detecção automática de informações pessoais identificáveis (PII)';
COMMENT ON COLUMN pii_detections.pii_type IS 'Tipo: email, phone, cpf, credit_card, address, name';

-- =====================================================
-- DATA LINEAGE - Linhagem de Dados
-- =====================================================

CREATE TABLE lineage_nodes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  entity_id UUID NOT NULL,
  node_type TEXT NOT NULL,
  level INTEGER NOT NULL,
  position_x INTEGER,
  position_y INTEGER,
  metadata JSONB,
  tenant_id TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

COMMENT ON TABLE lineage_nodes IS 'Nós do grafo de linhagem de dados';
COMMENT ON COLUMN lineage_nodes.node_type IS 'Tipo: source, transformation, destination';

CREATE TABLE lineage_edges (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  source_node_id UUID NOT NULL,
  target_node_id UUID NOT NULL,
  relationship_type TEXT NOT NULL,
  transformation_logic TEXT,
  confidence_score DECIMAL(5,2),
  discovery_method TEXT,
  metadata JSONB,
  tenant_id TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

COMMENT ON TABLE lineage_edges IS 'Arestas do grafo de linhagem representando relações entre entidades';
COMMENT ON COLUMN lineage_edges.relationship_type IS 'Tipo: derives_from, transforms_to, copies_to, aggregates_to';

-- =====================================================
-- WORKFLOW & GOVERNANCE - Fluxos e Governança
-- =====================================================

CREATE TABLE workflows (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  workflow_type TEXT NOT NULL,
  trigger_event TEXT NOT NULL,
  status TEXT DEFAULT 'active',
  definition JSONB NOT NULL,
  owner_email TEXT NOT NULL,
  tenant_id TEXT NOT NULL,
  execution_count INTEGER DEFAULT 0,
  last_execution TIMESTAMPTZ,
  success_rate DECIMAL(5,2),
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

COMMENT ON TABLE workflows IS 'Workflows automatizados para governança e processos';
COMMENT ON COLUMN workflows.workflow_type IS 'Tipo: approval, notification, data_processing, compliance_check';

CREATE TABLE workflow_executions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workflow_id UUID NOT NULL,
  trigger_data JSONB,
  status TEXT NOT NULL,
  started_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  completed_at TIMESTAMPTZ,
  duration_seconds INTEGER,
  steps_completed INTEGER DEFAULT 0,
  steps_total INTEGER,
  error_message TEXT,
  output_data JSONB,
  tenant_id TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);

COMMENT ON TABLE workflow_executions IS 'Histórico de execuções de workflows';

CREATE TABLE governance_policies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  policy_type TEXT NOT NULL,
  scope TEXT NOT NULL,
  scope_filter JSONB,
  rules JSONB NOT NULL,
  enforcement_level TEXT NOT NULL,
  is_active BOOLEAN DEFAULT true,
  owner_email TEXT NOT NULL,
  tenant_id TEXT NOT NULL,
  effective_date TIMESTAMPTZ NOT NULL,
  expiry_date TIMESTAMPTZ,
  version TEXT DEFAULT '1.0.0',
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

COMMENT ON TABLE governance_policies IS 'Políticas de governança aplicadas automaticamente';
COMMENT ON COLUMN governance_policies.policy_type IS 'Tipo: data_access, data_retention, data_sharing, data_quality';

-- =====================================================
-- ANALYTICS & METRICS - Analytics e Métricas
-- =====================================================

CREATE TABLE metrics (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  metric_name TEXT NOT NULL,
  metric_type TEXT NOT NULL,
  entity_id UUID,
  value DECIMAL(15,4) NOT NULL,
  unit TEXT,
  dimensions JSONB,
  tenant_id TEXT NOT NULL,
  collected_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_at TIMESTAMPTZ DEFAULT now()
);

COMMENT ON TABLE metrics IS 'Métricas coletadas do sistema para monitoramento e analytics';
COMMENT ON COLUMN metrics.metric_type IS 'Tipo: counter, gauge, histogram, summary';

CREATE TABLE notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  recipient_email TEXT NOT NULL,
  notification_type TEXT NOT NULL,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  channel TEXT NOT NULL,
  priority TEXT DEFAULT 'normal',
  related_entity_type TEXT,
  related_entity_id UUID,
  tenant_id TEXT NOT NULL,
  sent_at TIMESTAMPTZ,
  read_at TIMESTAMPTZ,
  status TEXT DEFAULT 'pending',
  retry_count INTEGER DEFAULT 0,
  error_message TEXT,
  metadata JSONB,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

COMMENT ON TABLE notifications IS 'Sistema de notificações multi-canal';
COMMENT ON COLUMN notifications.channel IS 'Canal: email, slack, teams, webhook';

-- =====================================================
-- TEMPLATES & VERSIONING - Templates e Versionamento
-- =====================================================

CREATE TABLE contract_layout_templates (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  version TEXT NOT NULL,
  description TEXT,
  layout_type TEXT NOT NULL,
  template_schema JSONB NOT NULL,
  is_active BOOLEAN DEFAULT false,
  is_default BOOLEAN DEFAULT false,
  tenant_id TEXT,
  created_by TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

COMMENT ON TABLE contract_layout_templates IS 'Templates para geração de contratos de dados';
COMMENT ON COLUMN contract_layout_templates.layout_type IS 'Tipo: open_data_contract, custom, lgpd_enhanced';

CREATE TABLE tenant_contract_config (
  id SERIAL PRIMARY KEY,
  tenant_id TEXT NOT NULL UNIQUE,
  default_layout_template_id INTEGER,
  auto_versioning_enabled BOOLEAN DEFAULT true,
  settings JSONB,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

COMMENT ON TABLE tenant_contract_config IS 'Configurações específicas por tenant para contratos';

CREATE TABLE contract_versions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  contract_id UUID NOT NULL,
  version_number TEXT NOT NULL,
  changes_summary TEXT,
  schema_definition JSONB,
  created_by TEXT NOT NULL,
  is_current BOOLEAN DEFAULT false,
  migration_notes TEXT,
  tenant_id TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);

COMMENT ON TABLE contract_versions IS 'Versionamento completo de contratos de dados';

-- =====================================================
-- QUALITY & MONITORING - Qualidade e Monitoramento
-- =====================================================

CREATE TABLE quality_executions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  quality_rule_id UUID NOT NULL,
  execution_date TIMESTAMPTZ NOT NULL DEFAULT now(),
  status TEXT NOT NULL,
  score DECIMAL(5,2),
  records_checked BIGINT,
  records_passed BIGINT,
  records_failed BIGINT,
  execution_time_ms INTEGER,
  details JSONB,
  error_message TEXT,
  tenant_id TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);

COMMENT ON TABLE quality_executions IS 'Histórico de execuções de regras de qualidade';

CREATE TABLE data_discovery_scans (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  scan_name TEXT NOT NULL,
  scan_type TEXT NOT NULL,
  target_system TEXT NOT NULL,
  connection_details JSONB,
  status TEXT NOT NULL,
  started_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  completed_at TIMESTAMPTZ,
  entities_discovered INTEGER DEFAULT 0,
  entities_updated INTEGER DEFAULT 0,
  pii_detections INTEGER DEFAULT 0,
  errors_count INTEGER DEFAULT 0,
  scan_summary JSONB,
  tenant_id TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);

COMMENT ON TABLE data_discovery_scans IS 'Histórico de scans de descoberta automática';

-- =====================================================
-- FOREIGN KEYS - Chaves Estrangeiras
-- =====================================================

-- Quality rules
ALTER TABLE quality_rules ADD CONSTRAINT fk_quality_rules_entity 
  FOREIGN KEY (entity_id) REFERENCES entities(id);

-- PII detections
ALTER TABLE pii_detections ADD CONSTRAINT fk_pii_detections_entity 
  FOREIGN KEY (entity_id) REFERENCES entities(id);

-- Compliance assessments
ALTER TABLE compliance_assessments ADD CONSTRAINT fk_compliance_assessments_entity 
  FOREIGN KEY (entity_id) REFERENCES entities(id);

-- Lineage nodes
ALTER TABLE lineage_nodes ADD CONSTRAINT fk_lineage_nodes_entity 
  FOREIGN KEY (entity_id) REFERENCES entities(id);

-- Lineage edges
ALTER TABLE lineage_edges ADD CONSTRAINT fk_lineage_edges_source 
  FOREIGN KEY (source_node_id) REFERENCES lineage_nodes(id);
ALTER TABLE lineage_edges ADD CONSTRAINT fk_lineage_edges_target 
  FOREIGN KEY (target_node_id) REFERENCES lineage_nodes(id);

-- Workflow executions
ALTER TABLE workflow_executions ADD CONSTRAINT fk_workflow_executions_workflow 
  FOREIGN KEY (workflow_id) REFERENCES workflows(id);

-- Quality executions
ALTER TABLE quality_executions ADD CONSTRAINT fk_quality_executions_rule 
  FOREIGN KEY (quality_rule_id) REFERENCES quality_rules(id);

-- Contract versions
ALTER TABLE contract_versions ADD CONSTRAINT fk_contract_versions_contract 
  FOREIGN KEY (contract_id) REFERENCES contracts(id);

-- Contracts current version
ALTER TABLE contracts ADD CONSTRAINT fk_contracts_current_version 
  FOREIGN KEY (current_version_id) REFERENCES contract_versions(id);

-- Contracts layout template
ALTER TABLE contracts ADD CONSTRAINT fk_contracts_layout_template 
  FOREIGN KEY (layout_template_id) REFERENCES contract_layout_templates(id);

-- Tenant config
ALTER TABLE tenant_contract_config ADD CONSTRAINT fk_tenant_config_template 
  FOREIGN KEY (default_layout_template_id) REFERENCES contract_layout_templates(id);

-- Metrics entity
ALTER TABLE metrics ADD CONSTRAINT fk_metrics_entity 
  FOREIGN KEY (entity_id) REFERENCES entities(id);

-- =====================================================
-- INDEXES - Índices para Performance
-- =====================================================

-- Users indexes
CREATE UNIQUE INDEX idx_users_username ON users(username);
CREATE UNIQUE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_tenant ON users(tenant_id);
CREATE INDEX idx_users_tenant_role ON users(tenant_id, role);

-- Contracts indexes
CREATE INDEX idx_contracts_tenant ON contracts(tenant_id);
CREATE INDEX idx_contracts_owner ON contracts(owner_email);
CREATE INDEX idx_contracts_status ON contracts(status);
CREATE INDEX idx_contracts_classification ON contracts(data_classification);
CREATE INDEX idx_contracts_tenant_status ON contracts(tenant_id, status);
CREATE INDEX idx_contracts_created ON contracts(created_at);

-- Entities indexes
CREATE INDEX idx_entities_tenant ON entities(tenant_id);
CREATE INDEX idx_entities_owner ON entities(owner_email);
CREATE INDEX idx_entities_type ON entities(entity_type);
CREATE INDEX idx_entities_classification ON entities(data_classification);
CREATE INDEX idx_entities_location ON entities(database_name, schema_name, table_name);
CREATE INDEX idx_entities_active ON entities(is_active);

-- Quality rules indexes
CREATE INDEX idx_quality_rules_entity ON quality_rules(entity_id);
CREATE INDEX idx_quality_rules_tenant ON quality_rules(tenant_id);
CREATE INDEX idx_quality_rules_active ON quality_rules(is_active);
CREATE INDEX idx_quality_rules_type ON quality_rules(rule_type);

-- Audit logs indexes
CREATE INDEX idx_audit_logs_user ON audit_logs(user_id);
CREATE INDEX idx_audit_logs_tenant ON audit_logs(tenant_id);
CREATE INDEX idx_audit_logs_resource_type ON audit_logs(resource_type);
CREATE INDEX idx_audit_logs_resource_id ON audit_logs(resource_id);
CREATE INDEX idx_audit_logs_created ON audit_logs(created_at);
CREATE INDEX idx_audit_logs_tenant_created ON audit_logs(tenant_id, created_at);

-- PII detections indexes
CREATE INDEX idx_pii_detections_entity ON pii_detections(entity_id);
CREATE INDEX idx_pii_detections_tenant ON pii_detections(tenant_id);
CREATE INDEX idx_pii_detections_type ON pii_detections(pii_type);
CREATE INDEX idx_pii_detections_status ON pii_detections(status);
CREATE INDEX idx_pii_detections_date ON pii_detections(detection_date);

-- Lineage indexes
CREATE INDEX idx_lineage_nodes_entity ON lineage_nodes(entity_id);
CREATE INDEX idx_lineage_nodes_tenant ON lineage_nodes(tenant_id);
CREATE INDEX idx_lineage_nodes_type ON lineage_nodes(node_type);
CREATE INDEX idx_lineage_edges_source ON lineage_edges(source_node_id);
CREATE INDEX idx_lineage_edges_target ON lineage_edges(target_node_id);
CREATE INDEX idx_lineage_edges_tenant ON lineage_edges(tenant_id);

-- Workflows indexes
CREATE INDEX idx_workflows_tenant ON workflows(tenant_id);
CREATE INDEX idx_workflows_type ON workflows(workflow_type);
CREATE INDEX idx_workflows_status ON workflows(status);
CREATE INDEX idx_workflows_trigger ON workflows(trigger_event);

-- Metrics indexes
CREATE INDEX idx_metrics_name ON metrics(metric_name);
CREATE INDEX idx_metrics_tenant ON metrics(tenant_id);
CREATE INDEX idx_metrics_entity ON metrics(entity_id);
CREATE INDEX idx_metrics_collected ON metrics(collected_at);
CREATE INDEX idx_metrics_name_collected ON metrics(metric_name, collected_at);

-- Notifications indexes
CREATE INDEX idx_notifications_recipient ON notifications(recipient_email);
CREATE INDEX idx_notifications_tenant ON notifications(tenant_id);
CREATE INDEX idx_notifications_status ON notifications(status);
CREATE INDEX idx_notifications_created ON notifications(created_at);
CREATE INDEX idx_notifications_recipient_status ON notifications(recipient_email, status);

-- Templates indexes
CREATE INDEX idx_templates_active ON contract_layout_templates(is_active);
CREATE INDEX idx_templates_tenant ON contract_layout_templates(tenant_id);
CREATE INDEX idx_templates_type ON contract_layout_templates(layout_type);
CREATE INDEX idx_templates_active_tenant ON contract_layout_templates(is_active, tenant_id);

-- =====================================================
-- INITIAL DATA - Dados Iniciais
-- =====================================================

-- Templates iniciais
INSERT INTO contract_layout_templates (name, version, description, layout_type, template_schema, is_active, is_default) VALUES
('Open Data Contract v2.2.2', '2.2.2', 'Template padrão Open Data Contract versão 2.2.2', 'open_data_contract', 
 '{"version": "2.2.2", "fields": ["name", "description", "version", "status", "data_classification", "owner_email"]}', 
 true, false),
('Open Data Contract v2.3.0', '2.3.0', 'Template Open Data Contract versão 2.3.0 com melhorias', 'open_data_contract', 
 '{"version": "2.3.0", "fields": ["name", "description", "version", "status", "data_classification", "owner_email", "tags", "quality_rules"]}', 
 true, true),
('LGPD Enhanced Contract', '1.0.0', 'Template especializado para compliance LGPD', 'lgpd_enhanced', 
 '{"version": "1.0.0", "fields": ["name", "description", "version", "status", "data_classification", "owner_email", "pii_fields", "retention_policy", "consent_basis"]}', 
 true, false);

-- Configuração padrão de tenant
INSERT INTO tenant_contract_config (tenant_id, default_layout_template_id, auto_versioning_enabled, settings) VALUES
('default', 2, true, '{"auto_pii_detection": true, "compliance_checks": ["LGPD"], "notification_channels": ["email"]}');

-- Dados de exemplo para testes
INSERT INTO users (username, email, full_name, role, tenant_id) VALUES
('admin', 'admin@empresa.com', 'Administrador do Sistema', 'admin', 'default'),
('data_owner', 'proprietario@empresa.com', 'Proprietário de Dados', 'data_owner', 'default'),
('analyst', 'analista@empresa.com', 'Analista de Dados', 'analyst', 'default');

INSERT INTO entities (name, description, entity_type, data_classification, owner_email, tenant_id) VALUES
('customers', 'Tabela de clientes com dados pessoais', 'table', 'restricted', 'proprietario@empresa.com', 'default'),
('sales', 'Tabela de vendas e faturamento', 'table', 'confidential', 'proprietario@empresa.com', 'default');

INSERT INTO contracts (name, description, version, status, data_classification, owner_email, tenant_id, layout_template_id) VALUES
('Contrato de Dados de Vendas', 'Contrato para dados de vendas e faturamento', '1.0.0', 'active', 'confidential', 'vendas@empresa.com', 'default', 2),
('Contrato de Dados de Clientes', 'Contrato para dados pessoais de clientes', '2.1.0', 'active', 'restricted', 'privacidade@empresa.com', 'default', 3),
('Contrato de Dados de Marketing', 'Contrato para dados de campanhas de marketing', '1.5.0', 'draft', 'internal', 'marketing@empresa.com', 'default', 2);

INSERT INTO quality_rules (name, description, rule_type, entity_id, rule_definition, owner_email, tenant_id) VALUES
('Completude Email Clientes', 'Verifica se todos os clientes têm email preenchido', 'completeness', 
 (SELECT id FROM entities WHERE name = 'customers'), 
 '{"column": "email", "threshold": 95}', 'proprietario@empresa.com', 'default'),
('Unicidade CPF', 'Verifica se não há CPFs duplicados', 'uniqueness', 
 (SELECT id FROM entities WHERE name = 'customers'), 
 '{"column": "cpf", "threshold": 100}', 'proprietario@empresa.com', 'default');

-- =====================================================
-- FUNCTIONS - Funções Auxiliares
-- =====================================================

-- Função para ativar template
CREATE OR REPLACE FUNCTION activate_layout_template(template_id INTEGER, tenant_id_param TEXT DEFAULT NULL)
RETURNS BOOLEAN AS $$
BEGIN
    UPDATE contract_layout_templates 
    SET is_active = true, updated_at = now()
    WHERE id = template_id 
    AND (tenant_id_param IS NULL OR tenant_id = tenant_id_param);
    
    RETURN FOUND;
END;
$$ LANGUAGE plpgsql;

-- Função para criar versão de contrato
CREATE OR REPLACE FUNCTION create_contract_version(
    contract_id_param UUID,
    version_number_param TEXT,
    changes_summary_param TEXT,
    created_by_param TEXT
) RETURNS UUID AS $$
DECLARE
    new_version_id UUID;
    tenant_id_param TEXT;
BEGIN
    -- Buscar tenant_id do contrato
    SELECT tenant_id INTO tenant_id_param FROM contracts WHERE id = contract_id_param;
    
    -- Criar nova versão
    INSERT INTO contract_versions (contract_id, version_number, changes_summary, created_by, tenant_id)
    VALUES (contract_id_param, version_number_param, changes_summary_param, created_by_param, tenant_id_param)
    RETURNING id INTO new_version_id;
    
    -- Atualizar contador de versões
    UPDATE contracts 
    SET version_count = version_count + 1, updated_at = now()
    WHERE id = contract_id_param;
    
    RETURN new_version_id;
END;
$$ LANGUAGE plpgsql;

-- Trigger para atualizar updated_at automaticamente
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Aplicar trigger em todas as tabelas com updated_at
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_contracts_updated_at BEFORE UPDATE ON contracts 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_entities_updated_at BEFORE UPDATE ON entities 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_quality_rules_updated_at BEFORE UPDATE ON quality_rules 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_compliance_assessments_updated_at BEFORE UPDATE ON compliance_assessments 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_pii_detections_updated_at BEFORE UPDATE ON pii_detections 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_workflows_updated_at BEFORE UPDATE ON workflows 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_governance_policies_updated_at BEFORE UPDATE ON governance_policies 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_notifications_updated_at BEFORE UPDATE ON notifications 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_templates_updated_at BEFORE UPDATE ON contract_layout_templates 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_tenant_config_updated_at BEFORE UPDATE ON tenant_contract_config 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- =====================================================
-- VIEWS - Views Úteis
-- =====================================================

-- View de contratos com informações de template
CREATE VIEW contracts_with_templates AS
SELECT 
    c.*,
    t.name as template_name,
    t.version as template_version,
    t.layout_type
FROM contracts c
LEFT JOIN contract_layout_templates t ON c.layout_template_id = t.id;

-- View de métricas de qualidade por entidade
CREATE VIEW quality_metrics_summary AS
SELECT 
    e.name as entity_name,
    e.entity_type,
    COUNT(qr.id) as total_rules,
    COUNT(CASE WHEN qr.is_active THEN 1 END) as active_rules,
    AVG(qe.score) as avg_quality_score,
    MAX(qe.execution_date) as last_execution
FROM entities e
LEFT JOIN quality_rules qr ON e.id = qr.entity_id
LEFT JOIN quality_executions qe ON qr.id = qe.quality_rule_id
GROUP BY e.id, e.name, e.entity_type;

-- View de compliance por entidade
CREATE VIEW compliance_status_summary AS
SELECT 
    e.name as entity_name,
    e.data_classification,
    COUNT(ca.id) as total_assessments,
    COUNT(CASE WHEN ca.status = 'compliant' THEN 1 END) as compliant_count,
    AVG(ca.overall_score) as avg_compliance_score,
    MAX(ca.assessment_date) as last_assessment
FROM entities e
LEFT JOIN compliance_assessments ca ON e.id = ca.entity_id
GROUP BY e.id, e.name, e.data_classification;

COMMENT ON DATABASE governance_v1_2 IS 'Sistema de Governança de Dados v3.0 - Modelo completo com correções aplicadas';

