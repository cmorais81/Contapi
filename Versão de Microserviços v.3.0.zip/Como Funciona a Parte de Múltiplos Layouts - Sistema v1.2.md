# Como Funciona a Parte de Múltiplos Layouts - Sistema v1.2

## Visão Geral do Sistema

O sistema de **múltiplos layouts** permite que você tenha **diferentes templates de contrato de dados ativos simultaneamente**, sem precisar mexer em código. É uma funcionalidade revolucionária que torna o sistema extremamente flexível.

## Arquitetura do Sistema de Layouts

### 1. Estrutura de Dados

```sql
-- Tabela principal que armazena os templates
CREATE TABLE contract_layout_templates (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,                    -- Nome do template
    version VARCHAR(50) NOT NULL,                  -- Versão (ex: 2.2.2, 2.3.0)
    description TEXT,                              -- Descrição do template
    layout_type VARCHAR(100) NOT NULL,             -- Tipo (open_data_contract, custom, etc.)
    template_schema JSONB NOT NULL,                -- Schema JSON do template
    is_active BOOLEAN DEFAULT false,               -- Se está ativo
    is_default BOOLEAN DEFAULT false,              -- Se é o padrão
    tenant_id VARCHAR(100),                        -- Para multi-tenancy
    created_by VARCHAR(255),                       -- Quem criou
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Configuração por tenant
CREATE TABLE tenant_contract_config (
    id SERIAL PRIMARY KEY,
    tenant_id VARCHAR(100) NOT NULL,
    default_layout_template_id INTEGER,            -- Template padrão
    auto_versioning_enabled BOOLEAN DEFAULT true,  -- Versionamento automático
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (default_layout_template_id) REFERENCES contract_layout_templates(id)
);

-- Contratos criados com templates específicos
CREATE TABLE contracts (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    template_id INTEGER NOT NULL,                   -- Qual template foi usado
    template_version VARCHAR(50),                   -- Versão no momento da criação
    contract_data JSONB NOT NULL,                   -- Dados do contrato
    tenant_id VARCHAR(100) NOT NULL,
    status VARCHAR(50) DEFAULT 'draft',
    created_by VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (template_id) REFERENCES contract_layout_templates(id)
);
```

### 2. Como os Templates São Armazenados

Cada template é armazenado como um **schema JSON** na coluna `template_schema`. Exemplo:

```json
{
  "version": "2.3.0",
  "type": "open_data_contract",
  "schema": {
    "dataContractSpecification": "2.3.0",
    "id": "{{contract_id}}",
    "info": {
      "title": "{{contract_title}}",
      "version": "{{contract_version}}",
      "description": "{{contract_description}}",
      "owner": "{{owner_email}}",
      "contact": {
        "name": "{{contact_name}}",
        "email": "{{contact_email}}"
      }
    },
    "servers": {
      "production": {
        "type": "{{server_type}}",
        "host": "{{server_host}}",
        "port": "{{server_port}}"
      }
    },
    "terms": {
      "usage": "{{usage_terms}}",
      "limitations": "{{limitations}}",
      "billing": "{{billing_terms}}"
    },
    "models": {
      "{{model_name}}": {
        "description": "{{model_description}}",
        "type": "table",
        "fields": "{{dynamic_fields}}"
      }
    },
    "quality": {
      "type": "SodaCL",
      "specification": "{{quality_rules}}"
    },
    "servicelevels": {
      "availability": {
        "description": "{{availability_description}}",
        "percentage": "{{availability_percentage}}"
      },
      "retention": {
        "description": "{{retention_description}}",
        "period": "{{retention_period}}"
      }
    }
  },
  "ui_config": {
    "form_sections": [
      {
        "title": "Informações Básicas",
        "fields": ["title", "description", "owner", "contact"]
      },
      {
        "title": "Configuração do Servidor",
        "fields": ["server_type", "server_host", "server_port"]
      },
      {
        "title": "Termos de Uso",
        "fields": ["usage_terms", "limitations", "billing_terms"]
      },
      {
        "title": "Modelos de Dados",
        "fields": ["model_name", "model_description", "dynamic_fields"]
      },
      {
        "title": "Qualidade",
        "fields": ["quality_rules"]
      },
      {
        "title": "SLA",
        "fields": ["availability_description", "availability_percentage", "retention_description", "retention_period"]
      }
    ],
    "validation_rules": {
      "required_fields": ["title", "description", "owner"],
      "email_fields": ["owner", "contact_email"],
      "numeric_fields": ["server_port", "availability_percentage"]
    }
  }
}
```

## Como Funciona na Prática

### 1. Ativação de Múltiplos Templates

```sql
-- Exemplo: Ativar 3 templates diferentes simultaneamente

-- Template Open Data Contract v2.2.2 (padrão)
UPDATE contract_layout_templates 
SET is_active = true, is_default = true 
WHERE name = 'Open Data Contract v2.2.2';

-- Template Open Data Contract v2.3.0 (novo)
UPDATE contract_layout_templates 
SET is_active = true 
WHERE name = 'Open Data Contract v2.3.0';

-- Template LGPD Enhanced (compliance)
UPDATE contract_layout_templates 
SET is_active = true 
WHERE name = 'LGPD Enhanced Contract';

-- Verificar templates ativos
SELECT id, name, version, layout_type, is_active, is_default 
FROM contract_layout_templates 
WHERE is_active = true;
```

**Resultado:**
```
id | name                      | version | layout_type        | is_active | is_default
1  | Open Data Contract v2.2.2 | 2.2.2   | open_data_contract | true      | true
2  | Open Data Contract v2.3.0 | 2.3.0   | open_data_contract | true      | false  
3  | LGPD Enhanced Contract    | 1.0.0   | custom             | true      | false
```

### 2. Configuração por Tenant

```sql
-- Configurar tenant para usar múltiplos templates
INSERT INTO tenant_contract_config (
    tenant_id, 
    default_layout_template_id, 
    auto_versioning_enabled
) VALUES (
    'empresa_exemplo', 
    2,  -- Open Data Contract v2.3.0 como padrão
    true
);
```

### 3. Criação de Contratos com Templates Específicos

#### Via API REST:

```bash
# Criar contrato com template padrão (v2.3.0)
curl -X POST http://localhost:8001/open-data-contract/contracts \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ${JWT_TOKEN}" \
  -d '{
    "name": "Contrato Dados Vendas",
    "description": "Dados de vendas e faturamento",
    "tenant_id": "empresa_exemplo"
  }'

# Criar contrato com template específico (LGPD)
curl -X POST http://localhost:8001/open-data-contract/contracts \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ${JWT_TOKEN}" \
  -d '{
    "name": "Contrato Dados Clientes",
    "description": "Dados pessoais de clientes",
    "template_id": 3,
    "tenant_id": "empresa_exemplo"
  }'

# Criar contrato com template v2.2.2 (legacy)
curl -X POST http://localhost:8001/open-data-contract/contracts \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ${JWT_TOKEN}" \
  -d '{
    "name": "Contrato Dados Legados",
    "description": "Dados de sistemas legados",
    "template_id": 1,
    "tenant_id": "empresa_exemplo"
  }'
```

## Engine de Processamento de Templates

### 1. Serviço de Processamento

```python
class OpenDataContractService:
    def __init__(self, template_repository, contract_repository):
        self.template_repository = template_repository
        self.contract_repository = contract_repository
    
    def create_contract(self, contract_data: dict, tenant_id: str, template_id: int = None):
        """Cria contrato usando template específico ou padrão"""
        
        # 1. Determinar qual template usar
        if template_id:
            template = self.template_repository.get_by_id(template_id)
        else:
            template = self.template_repository.get_default_for_tenant(tenant_id)
        
        if not template or not template.is_active:
            raise ValueError("Template não encontrado ou inativo")
        
        # 2. Processar template com dados fornecidos
        processed_contract = self._process_template(template, contract_data)
        
        # 3. Validar dados conforme regras do template
        self._validate_contract_data(processed_contract, template)
        
        # 4. Salvar contrato
        contract = Contract(
            name=contract_data['name'],
            description=contract_data.get('description'),
            template_id=template.id,
            template_version=template.version,
            contract_data=processed_contract,
            tenant_id=tenant_id,
            status='draft'
        )
        
        return self.contract_repository.save(contract)
    
    def _process_template(self, template, user_data):
        """Processa template substituindo variáveis pelos dados do usuário"""
        template_schema = template.template_schema['schema']
        
        # Substituir variáveis do template
        processed = self._replace_template_variables(template_schema, user_data)
        
        return processed
    
    def _replace_template_variables(self, schema, data):
        """Substitui {{variáveis}} pelos valores reais"""
        import json
        import re
        
        # Converter para string para fazer substituições
        schema_str = json.dumps(schema)
        
        # Encontrar todas as variáveis {{variable}}
        variables = re.findall(r'\{\{(\w+)\}\}', schema_str)
        
        # Substituir cada variável
        for var in variables:
            if var in data:
                schema_str = schema_str.replace(f'{{{{{var}}}}}', str(data[var]))
        
        return json.loads(schema_str)
    
    def _validate_contract_data(self, contract_data, template):
        """Valida dados do contrato conforme regras do template"""
        ui_config = template.template_schema.get('ui_config', {})
        validation_rules = ui_config.get('validation_rules', {})
        
        # Validar campos obrigatórios
        required_fields = validation_rules.get('required_fields', [])
        for field in required_fields:
            if field not in contract_data or not contract_data[field]:
                raise ValueError(f"Campo obrigatório '{field}' não fornecido")
        
        # Validar emails
        email_fields = validation_rules.get('email_fields', [])
        for field in email_fields:
            if field in contract_data:
                if not self._is_valid_email(contract_data[field]):
                    raise ValueError(f"Email inválido no campo '{field}'")
        
        # Validar campos numéricos
        numeric_fields = validation_rules.get('numeric_fields', [])
        for field in numeric_fields:
            if field in contract_data:
                try:
                    float(contract_data[field])
                except ValueError:
                    raise ValueError(f"Valor numérico inválido no campo '{field}'")
```

### 2. Versionamento Automático

```python
class ContractVersioningService:
    def __init__(self, contract_repository):
        self.contract_repository = contract_repository
    
    def upgrade_contract_template(self, contract_id: int, new_template_id: int):
        """Atualiza contrato para nova versão do template"""
        
        # 1. Buscar contrato atual
        contract = self.contract_repository.get_by_id(contract_id)
        
        # 2. Buscar novo template
        new_template = self.template_repository.get_by_id(new_template_id)
        
        # 3. Migrar dados para novo formato
        migrated_data = self._migrate_contract_data(
            contract.contract_data, 
            contract.template_version, 
            new_template.version
        )
        
        # 4. Criar nova versão do contrato
        new_contract = Contract(
            name=contract.name,
            description=contract.description,
            template_id=new_template.id,
            template_version=new_template.version,
            contract_data=migrated_data,
            tenant_id=contract.tenant_id,
            status='draft',
            parent_contract_id=contract.id  # Referência ao contrato original
        )
        
        return self.contract_repository.save(new_contract)
    
    def _migrate_contract_data(self, old_data, old_version, new_version):
        """Migra dados entre versões de template"""
        
        # Mapeamento de campos entre versões
        migration_map = {
            ('2.2.2', '2.3.0'): {
                'info.owner': 'info.contact.email',  # Campo movido
                'terms.usage': 'terms.usageTerms',   # Campo renomeado
                # Novos campos em 2.3.0
                'servicelevels.availability': {'description': '', 'percentage': '99.9'},
                'quality.type': 'SodaCL'
            }
        }
        
        migration_key = (old_version, new_version)
        if migration_key in migration_map:
            return self._apply_migration(old_data, migration_map[migration_key])
        
        return old_data  # Sem migração necessária
```

## Interface de Usuário Dinâmica

### 1. Geração de Formulários

```python
class ContractFormGenerator:
    def generate_form_config(self, template_id: int):
        """Gera configuração de formulário baseada no template"""
        
        template = self.template_repository.get_by_id(template_id)
        ui_config = template.template_schema.get('ui_config', {})
        
        form_config = {
            'template_id': template.id,
            'template_name': template.name,
            'template_version': template.version,
            'sections': []
        }
        
        # Gerar seções do formulário
        for section in ui_config.get('form_sections', []):
            form_section = {
                'title': section['title'],
                'fields': []
            }
            
            for field_name in section['fields']:
                field_config = self._generate_field_config(field_name, ui_config)
                form_section['fields'].append(field_config)
            
            form_config['sections'].append(form_section)
        
        return form_config
    
    def _generate_field_config(self, field_name, ui_config):
        """Gera configuração de campo específico"""
        validation_rules = ui_config.get('validation_rules', {})
        
        field_config = {
            'name': field_name,
            'label': self._generate_label(field_name),
            'type': 'text',  # padrão
            'required': field_name in validation_rules.get('required_fields', []),
            'validation': []
        }
        
        # Determinar tipo do campo
        if field_name in validation_rules.get('email_fields', []):
            field_config['type'] = 'email'
            field_config['validation'].append('email')
        
        if field_name in validation_rules.get('numeric_fields', []):
            field_config['type'] = 'number'
            field_config['validation'].append('numeric')
        
        if 'description' in field_name:
            field_config['type'] = 'textarea'
        
        return field_config
```

### 2. Frontend Dinâmico (React)

```jsx
// Componente que renderiza formulário baseado no template
function DynamicContractForm({ templateId, onSubmit }) {
    const [formConfig, setFormConfig] = useState(null);
    const [formData, setFormData] = useState({});
    
    useEffect(() => {
        // Buscar configuração do formulário
        fetch(`/api/templates/${templateId}/form-config`)
            .then(response => response.json())
            .then(config => setFormConfig(config));
    }, [templateId]);
    
    const renderField = (field) => {
        switch (field.type) {
            case 'email':
                return (
                    <input
                        type="email"
                        name={field.name}
                        placeholder={field.label}
                        required={field.required}
                        value={formData[field.name] || ''}
                        onChange={(e) => setFormData({
                            ...formData,
                            [field.name]: e.target.value
                        })}
                    />
                );
            
            case 'number':
                return (
                    <input
                        type="number"
                        name={field.name}
                        placeholder={field.label}
                        required={field.required}
                        value={formData[field.name] || ''}
                        onChange={(e) => setFormData({
                            ...formData,
                            [field.name]: e.target.value
                        })}
                    />
                );
            
            case 'textarea':
                return (
                    <textarea
                        name={field.name}
                        placeholder={field.label}
                        required={field.required}
                        value={formData[field.name] || ''}
                        onChange={(e) => setFormData({
                            ...formData,
                            [field.name]: e.target.value
                        })}
                    />
                );
            
            default:
                return (
                    <input
                        type="text"
                        name={field.name}
                        placeholder={field.label}
                        required={field.required}
                        value={formData[field.name] || ''}
                        onChange={(e) => setFormData({
                            ...formData,
                            [field.name]: e.target.value
                        })}
                    />
                );
        }
    };
    
    if (!formConfig) return <div>Carregando...</div>;
    
    return (
        <form onSubmit={(e) => {
            e.preventDefault();
            onSubmit(formData);
        }}>
            <h2>Criar Contrato - {formConfig.template_name} v{formConfig.template_version}</h2>
            
            {formConfig.sections.map((section, sectionIndex) => (
                <div key={sectionIndex} className="form-section">
                    <h3>{section.title}</h3>
                    {section.fields.map((field, fieldIndex) => (
                        <div key={fieldIndex} className="form-field">
                            <label>{field.label}</label>
                            {renderField(field)}
                        </div>
                    ))}
                </div>
            ))}
            
            <button type="submit">Criar Contrato</button>
        </form>
    );
}
```

## APIs para Gerenciar Templates

### 1. APIs de Templates

```python
@app.route('/api/templates', methods=['GET'])
def list_templates():
    """Lista todos os templates disponíveis"""
    active_only = request.args.get('active', 'false').lower() == 'true'
    tenant_id = request.args.get('tenant_id')
    
    templates = template_service.list_templates(
        active_only=active_only,
        tenant_id=tenant_id
    )
    
    return jsonify([{
        'id': t.id,
        'name': t.name,
        'version': t.version,
        'layout_type': t.layout_type,
        'is_active': t.is_active,
        'is_default': t.is_default
    } for t in templates])

@app.route('/api/templates/<int:template_id>/activate', methods=['POST'])
def activate_template(template_id):
    """Ativa um template específico"""
    template_service.activate_template(template_id)
    return jsonify({'message': 'Template ativado com sucesso'})

@app.route('/api/templates/<int:template_id>/form-config', methods=['GET'])
def get_form_config(template_id):
    """Retorna configuração do formulário para o template"""
    config = form_generator.generate_form_config(template_id)
    return jsonify(config)
```

### 2. APIs de Contratos

```python
@app.route('/api/contracts', methods=['POST'])
def create_contract():
    """Cria novo contrato"""
    data = request.json
    tenant_id = get_current_tenant_id()
    
    contract = contract_service.create_contract(
        contract_data=data,
        tenant_id=tenant_id,
        template_id=data.get('template_id')
    )
    
    return jsonify({
        'id': contract.id,
        'name': contract.name,
        'template_id': contract.template_id,
        'template_version': contract.template_version,
        'status': contract.status
    })

@app.route('/api/contracts/<int:contract_id>/upgrade', methods=['POST'])
def upgrade_contract(contract_id):
    """Atualiza contrato para nova versão do template"""
    data = request.json
    new_template_id = data['new_template_id']
    
    new_contract = versioning_service.upgrade_contract_template(
        contract_id, new_template_id
    )
    
    return jsonify({
        'id': new_contract.id,
        'message': 'Contrato atualizado com sucesso'
    })
```

## Casos de Uso Práticos

### 1. Empresa com Diferentes Tipos de Dados

```sql
-- Configurar 3 templates para diferentes necessidades
UPDATE contract_layout_templates SET is_active = true WHERE id IN (1, 2, 3);

-- Template 1: Dados públicos (Open Data Contract v2.2.2)
-- Template 2: Dados internos (Open Data Contract v2.3.0)  
-- Template 3: Dados pessoais (LGPD Enhanced)

-- Configurar tenant para usar todos
UPDATE tenant_contract_config 
SET default_layout_template_id = 2  -- v2.3.0 como padrão
WHERE tenant_id = 'empresa_multi';
```

**Uso:**
```bash
# Contrato para dados públicos (template 1)
curl -X POST /api/contracts -d '{
  "name": "Dados Abertos Vendas",
  "template_id": 1,
  "description": "Dados públicos de vendas"
}'

# Contrato para dados internos (template padrão 2)
curl -X POST /api/contracts -d '{
  "name": "Dados Internos Analytics",
  "description": "Dados internos para analytics"
}'

# Contrato para dados pessoais (template 3)
curl -X POST /api/contracts -d '{
  "name": "Dados Clientes PII",
  "template_id": 3,
  "description": "Dados pessoais de clientes"
}'
```

### 2. Migração Gradual Entre Versões

```python
# Listar contratos usando versão antiga
old_contracts = contract_service.list_contracts_by_template_version('2.2.2')

# Migrar cada contrato para nova versão
for contract in old_contracts:
    new_contract = versioning_service.upgrade_contract_template(
        contract.id, 
        new_template_id=2  # v2.3.0
    )
    print(f"Contrato {contract.name} migrado para v2.3.0")
```

## Vantagens do Sistema

### 1. **Flexibilidade Total**
- Múltiplos templates ativos simultaneamente
- Configuração sem mexer em código
- Migração gradual entre versões

### 2. **Multi-Tenancy Avançado**
- Cada tenant pode ter templates específicos
- Configurações independentes
- Isolamento completo

### 3. **Evolução Sem Quebra**
- Novos templates não afetam existentes
- Versionamento automático
- Rollback seguro

### 4. **Interface Dinâmica**
- Formulários gerados automaticamente
- Validação baseada no template
- UX consistente

## Conclusão

O sistema de múltiplos layouts é uma funcionalidade poderosa que permite:

- ✅ **Ter vários templates ativos** ao mesmo tempo
- ✅ **Configurar via tabela** sem mexer em código
- ✅ **Migrar gradualmente** entre versões
- ✅ **Personalizar por tenant** conforme necessidade
- ✅ **Interface dinâmica** que se adapta ao template

**É uma solução enterprise que torna o sistema extremamente flexível e adequado para organizações com necessidades diversas de governança de dados.**

