# Guia Completo - Sistema de Múltiplos Layouts v1.2

## Índice

1. [Visão Geral](#visão-geral)
2. [Conceitos Fundamentais](#conceitos-fundamentais)
3. [Configuração Inicial](#configuração-inicial)
4. [Casos de Uso Práticos](#casos-de-uso-práticos)
5. [APIs e Integrações](#apis-e-integrações)
6. [Administração e Monitoramento](#administração-e-monitoramento)
7. [Troubleshooting](#troubleshooting)
8. [Melhores Práticas](#melhores-práticas)

## Visão Geral

O Sistema de Múltiplos Layouts permite que você tenha **diferentes templates de contrato de dados ativos simultaneamente**, oferecendo flexibilidade total para diferentes necessidades de negócio sem necessidade de alterações no código.

### Principais Benefícios

- **Flexibilidade Total**: Múltiplos templates ativos simultaneamente
- **Zero Código**: Configuração via banco de dados
- **Multi-Tenancy**: Configurações específicas por tenant
- **Versionamento**: Migração segura entre versões
- **Interface Dinâmica**: Formulários adaptáveis por template

## Conceitos Fundamentais

### 1. Template de Layout

Um **template de layout** é uma estrutura JSON que define:
- **Schema do contrato**: Campos e estrutura
- **Regras de validação**: Campos obrigatórios, tipos, etc.
- **Configuração de UI**: Como renderizar formulários
- **Metadados**: Versão, tipo, descrição

### 2. Versionamento

Cada template possui uma **versão** (ex: 2.2.2, 2.3.0) que permite:
- **Evolução gradual**: Novos recursos sem quebrar existentes
- **Compatibilidade**: Suporte a múltiplas versões
- **Migração**: Atualização segura entre versões

### 3. Multi-Tenancy

Cada **tenant** pode ter:
- **Template padrão**: Usado quando não especificado
- **Templates permitidos**: Lista de templates que pode usar
- **Configurações específicas**: Personalizações por cliente

### 4. Estados de Template

- **Ativo**: Disponível para criação de novos contratos
- **Inativo**: Não disponível para novos contratos
- **Padrão**: Usado automaticamente quando não especificado

## Configuração Inicial

### 1. Estrutura do Banco de Dados

```sql
-- Tabela principal de templates
CREATE TABLE contract_layout_templates (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    version VARCHAR(50) NOT NULL,
    description TEXT,
    layout_type VARCHAR(100) NOT NULL,
    template_schema JSONB NOT NULL,
    is_active BOOLEAN DEFAULT false,
    is_default BOOLEAN DEFAULT false,
    tenant_id VARCHAR(100),
    created_by VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Configuração por tenant
CREATE TABLE tenant_contract_config (
    id SERIAL PRIMARY KEY,
    tenant_id VARCHAR(100) NOT NULL,
    default_layout_template_id INTEGER,
    auto_versioning_enabled BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (default_layout_template_id) REFERENCES contract_layout_templates(id)
);

-- Contratos com templates
CREATE TABLE contracts (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    data_classification VARCHAR(50),
    owner_email VARCHAR(255),
    tenant_id VARCHAR(100),
    layout_template_id INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (layout_template_id) REFERENCES contract_layout_templates(id)
);
```

### 2. Inserir Templates Iniciais

```sql
-- Template Open Data Contract v2.2.2
INSERT INTO contract_layout_templates (
    name, version, description, layout_type, template_schema, is_active
) VALUES (
    'Open Data Contract v2.2.2',
    '2.2.2',
    'Template padrão Open Data Contract versão 2.2.2',
    'open_data_contract',
    '{
        "version": "2.2.2",
        "type": "open_data_contract",
        "schema": {
            "dataContractSpecification": "2.2.2",
            "info": {
                "title": "{{contract_title}}",
                "version": "{{contract_version}}",
                "description": "{{contract_description}}",
                "owner": "{{owner_email}}"
            },
            "servers": {
                "production": {
                    "type": "{{server_type}}",
                    "host": "{{server_host}}"
                }
            },
            "terms": {
                "usage": "{{usage_terms}}"
            },
            "models": {
                "{{model_name}}": {
                    "description": "{{model_description}}",
                    "type": "table"
                }
            }
        },
        "ui_config": {
            "form_sections": [
                {
                    "title": "Informações Básicas",
                    "fields": ["contract_title", "contract_description", "owner_email"]
                },
                {
                    "title": "Servidor",
                    "fields": ["server_type", "server_host"]
                },
                {
                    "title": "Modelo",
                    "fields": ["model_name", "model_description"]
                }
            ],
            "validation_rules": {
                "required_fields": ["contract_title", "owner_email"],
                "email_fields": ["owner_email"]
            }
        }
    }',
    true
);

-- Template Open Data Contract v2.3.0
INSERT INTO contract_layout_templates (
    name, version, description, layout_type, template_schema, is_active, is_default
) VALUES (
    'Open Data Contract v2.3.0',
    '2.3.0',
    'Template Open Data Contract versão 2.3.0 com recursos avançados',
    'open_data_contract',
    '{
        "version": "2.3.0",
        "type": "open_data_contract",
        "schema": {
            "dataContractSpecification": "2.3.0",
            "info": {
                "title": "{{contract_title}}",
                "version": "{{contract_version}}",
                "description": "{{contract_description}}",
                "owner": "{{owner_email}}",
                "contact": {
                    "name": "{{contact_name}}",
                    "email": "{{contact_email}}"
                }
            },
            "servers": {
                "production": {
                    "type": "{{server_type}}",
                    "host": "{{server_host}}",
                    "port": "{{server_port}}"
                }
            },
            "terms": {
                "usage": "{{usage_terms}}",
                "limitations": "{{limitations}}",
                "billing": "{{billing_terms}}"
            },
            "models": {
                "{{model_name}}": {
                    "description": "{{model_description}}",
                    "type": "table",
                    "fields": "{{dynamic_fields}}"
                }
            },
            "quality": {
                "type": "SodaCL",
                "specification": "{{quality_rules}}"
            },
            "servicelevels": {
                "availability": {
                    "description": "{{availability_description}}",
                    "percentage": "{{availability_percentage}}"
                },
                "retention": {
                    "description": "{{retention_description}}",
                    "period": "{{retention_period}}"
                }
            }
        },
        "ui_config": {
            "form_sections": [
                {
                    "title": "Informações Básicas",
                    "fields": ["contract_title", "contract_description", "owner_email", "contact_name", "contact_email"]
                },
                {
                    "title": "Configuração do Servidor",
                    "fields": ["server_type", "server_host", "server_port"]
                },
                {
                    "title": "Termos de Uso",
                    "fields": ["usage_terms", "limitations", "billing_terms"]
                },
                {
                    "title": "Modelos de Dados",
                    "fields": ["model_name", "model_description", "dynamic_fields"]
                },
                {
                    "title": "Qualidade",
                    "fields": ["quality_rules"]
                },
                {
                    "title": "SLA",
                    "fields": ["availability_description", "availability_percentage", "retention_description", "retention_period"]
                }
            ],
            "validation_rules": {
                "required_fields": ["contract_title", "contract_description", "owner_email"],
                "email_fields": ["owner_email", "contact_email"],
                "numeric_fields": ["server_port", "availability_percentage"]
            }
        }
    }',
    true,
    true
);

-- Template LGPD Enhanced
INSERT INTO contract_layout_templates (
    name, version, description, layout_type, template_schema, is_active
) VALUES (
    'LGPD Enhanced Contract',
    '1.0.0',
    'Template especializado para compliance LGPD',
    'custom',
    '{
        "version": "1.0.0",
        "type": "lgpd_enhanced",
        "schema": {
            "dataContractSpecification": "LGPD-1.0.0",
            "info": {
                "title": "{{contract_title}}",
                "description": "{{contract_description}}",
                "owner": "{{owner_email}}",
                "dpo_contact": "{{dpo_email}}"
            },
            "lgpd_compliance": {
                "data_subject_categories": "{{data_subject_categories}}",
                "personal_data_categories": "{{personal_data_categories}}",
                "sensitive_data": "{{sensitive_data}}",
                "legal_basis": "{{legal_basis}}",
                "purpose": "{{processing_purpose}}",
                "retention_period": "{{retention_period}}",
                "international_transfer": "{{international_transfer}}"
            },
            "privacy_controls": {
                "consent_mechanism": "{{consent_mechanism}}",
                "opt_out_mechanism": "{{opt_out_mechanism}}",
                "data_portability": "{{data_portability}}",
                "deletion_process": "{{deletion_process}}"
            },
            "security_measures": {
                "encryption": "{{encryption_details}}",
                "access_controls": "{{access_controls}}",
                "audit_logging": "{{audit_logging}}"
            }
        },
        "ui_config": {
            "form_sections": [
                {
                    "title": "Informações Básicas",
                    "fields": ["contract_title", "contract_description", "owner_email", "dpo_email"]
                },
                {
                    "title": "Compliance LGPD",
                    "fields": ["data_subject_categories", "personal_data_categories", "sensitive_data", "legal_basis", "processing_purpose", "retention_period"]
                },
                {
                    "title": "Controles de Privacidade",
                    "fields": ["consent_mechanism", "opt_out_mechanism", "data_portability", "deletion_process"]
                },
                {
                    "title": "Medidas de Segurança",
                    "fields": ["encryption_details", "access_controls", "audit_logging"]
                }
            ],
            "validation_rules": {
                "required_fields": ["contract_title", "contract_description", "owner_email", "dpo_email", "legal_basis"],
                "email_fields": ["owner_email", "dpo_email"],
                "boolean_fields": ["sensitive_data", "international_transfer"]
            }
        }
    }',
    true
);
```

## Casos de Uso Práticos

### Caso 1: Empresa com Diferentes Tipos de Dados

**Cenário**: Empresa precisa de templates diferentes para dados públicos, internos e pessoais.

**Solução**:
```sql
-- Configurar tenant para usar múltiplos templates
INSERT INTO tenant_contract_config (tenant_id, default_layout_template_id, auto_versioning_enabled)
VALUES ('empresa_multi', 2, true);

-- Criar contratos com templates específicos
-- Dados públicos (template v2.2.2 - mais simples)
INSERT INTO contracts (name, description, data_classification, owner_email, tenant_id, layout_template_id)
VALUES ('Dados Abertos Vendas', 'Dados públicos de vendas', 'public', 'vendas@empresa.com', 'empresa_multi', 1);

-- Dados internos (template v2.3.0 - recursos avançados)
INSERT INTO contracts (name, description, data_classification, owner_email, tenant_id, layout_template_id)
VALUES ('Analytics Interno', 'Dados para analytics interno', 'internal', 'analytics@empresa.com', 'empresa_multi', 2);

-- Dados pessoais (template LGPD)
INSERT INTO contracts (name, description, data_classification, owner_email, tenant_id, layout_template_id)
VALUES ('Dados Clientes PII', 'Dados pessoais de clientes', 'confidential', 'dpo@empresa.com', 'empresa_multi', 3);
```

### Caso 2: Migração Gradual Entre Versões

**Cenário**: Empresa quer migrar de v2.2.2 para v2.3.0 gradualmente.

**Estratégia**:
1. **Manter ambas versões ativas**
2. **Criar novos contratos com v2.3.0**
3. **Migrar contratos críticos primeiro**
4. **Desativar v2.2.2 quando todos migrarem**

```sql
-- 1. Ativar ambas versões
UPDATE contract_layout_templates SET is_active = true WHERE version IN ('2.2.2', '2.3.0');

-- 2. Definir v2.3.0 como padrão para novos contratos
UPDATE contract_layout_templates SET is_default = true WHERE version = '2.3.0';
UPDATE contract_layout_templates SET is_default = false WHERE version = '2.2.2';

-- 3. Listar contratos usando versão antiga
SELECT c.id, c.name, t.version 
FROM contracts c 
JOIN contract_layout_templates t ON c.layout_template_id = t.id 
WHERE t.version = '2.2.2';

-- 4. Migrar contrato específico (via API)
-- POST /api/contracts/{id}/upgrade
-- { "new_template_id": 2 }
```

### Caso 3: SaaS Multi-Tenant

**Cenário**: SaaS com clientes de diferentes setores.

**Configuração**:
```sql
-- Cliente financeiro (SOX compliance)
INSERT INTO tenant_contract_config (tenant_id, default_layout_template_id)
VALUES ('cliente_financeiro', 4);  -- Template SOX

-- Cliente saúde (HIPAA compliance)
INSERT INTO tenant_contract_config (tenant_id, default_layout_template_id)
VALUES ('cliente_saude', 5);  -- Template HIPAA

-- Cliente brasileiro (LGPD compliance)
INSERT INTO tenant_contract_config (tenant_id, default_layout_template_id)
VALUES ('cliente_brasil', 3);  -- Template LGPD
```

### Caso 4: A/B Testing de Templates

**Cenário**: Testar novo template com grupo específico de usuários.

**Implementação**:
```sql
-- Criar template experimental
INSERT INTO contract_layout_templates (name, version, layout_type, template_schema, is_active)
VALUES ('Open Data Contract v2.4.0-beta', '2.4.0-beta', 'open_data_contract', '...', true);

-- Configurar usuários beta
UPDATE tenant_contract_config 
SET default_layout_template_id = (SELECT id FROM contract_layout_templates WHERE version = '2.4.0-beta')
WHERE tenant_id IN ('tenant_beta_1', 'tenant_beta_2');

-- Monitorar uso
SELECT 
    t.version,
    COUNT(c.id) as contracts_created,
    AVG(EXTRACT(EPOCH FROM (c.updated_at - c.created_at))) as avg_completion_time
FROM contracts c
JOIN contract_layout_templates t ON c.layout_template_id = t.id
WHERE c.created_at > NOW() - INTERVAL '30 days'
GROUP BY t.version;
```

## APIs e Integrações

### 1. APIs de Templates

#### Listar Templates
```http
GET /api/templates?active=true&tenant_id=empresa_demo
Authorization: Bearer {jwt_token}
```

**Resposta**:
```json
[
  {
    "id": 1,
    "name": "Open Data Contract v2.2.2",
    "version": "2.2.2",
    "layout_type": "open_data_contract",
    "is_active": true,
    "is_default": false
  },
  {
    "id": 2,
    "name": "Open Data Contract v2.3.0",
    "version": "2.3.0",
    "layout_type": "open_data_contract",
    "is_active": true,
    "is_default": true
  }
]
```

#### Obter Configuração de Formulário
```http
GET /api/templates/2/form-config
Authorization: Bearer {jwt_token}
```

#### Ativar/Desativar Template
```http
POST /api/templates/2/activate
Authorization: Bearer {jwt_token}
```

```http
POST /api/templates/1/deactivate
Authorization: Bearer {jwt_token}
```

### 2. APIs de Contratos

#### Criar Contrato com Template Específico
```http
POST /api/contracts
Content-Type: application/json
Authorization: Bearer {jwt_token}

{
  "name": "Contrato Dados Marketing",
  "description": "Dados para campanhas de marketing",
  "template_id": 3,
  "data_classification": "confidential",
  "owner_email": "marketing@empresa.com",
  "tenant_id": "empresa_demo"
}
```

#### Criar Contrato com Template Padrão
```http
POST /api/contracts
Content-Type: application/json
Authorization: Bearer {jwt_token}

{
  "name": "Contrato Dados Analytics",
  "description": "Dados para análises",
  "data_classification": "internal",
  "owner_email": "analytics@empresa.com",
  "tenant_id": "empresa_demo"
}
```

#### Migrar Contrato para Novo Template
```http
POST /api/contracts/5/upgrade
Content-Type: application/json
Authorization: Bearer {jwt_token}

{
  "new_template_id": 2,
  "migration_notes": "Upgrade para v2.3.0"
}
```

### 3. Integração com Frontend

#### React Component Exemplo
```jsx
import React, { useState, useEffect } from 'react';

function ContractForm({ onSubmit }) {
    const [templates, setTemplates] = useState([]);
    const [selectedTemplate, setSelectedTemplate] = useState(null);
    const [formConfig, setFormConfig] = useState(null);
    const [formData, setFormData] = useState({});

    useEffect(() => {
        // Carregar templates disponíveis
        fetch('/api/templates?active=true')
            .then(response => response.json())
            .then(data => {
                setTemplates(data);
                // Selecionar template padrão
                const defaultTemplate = data.find(t => t.is_default);
                if (defaultTemplate) {
                    setSelectedTemplate(defaultTemplate.id);
                }
            });
    }, []);

    useEffect(() => {
        if (selectedTemplate) {
            // Carregar configuração do formulário
            fetch(`/api/templates/${selectedTemplate}/form-config`)
                .then(response => response.json())
                .then(config => setFormConfig(config));
        }
    }, [selectedTemplate]);

    const renderField = (field) => {
        const commonProps = {
            name: field.name,
            required: field.required,
            value: formData[field.name] || '',
            onChange: (e) => setFormData({
                ...formData,
                [field.name]: e.target.value
            })
        };

        switch (field.type) {
            case 'email':
                return <input type="email" {...commonProps} />;
            case 'number':
                return <input type="number" {...commonProps} />;
            case 'textarea':
                return <textarea {...commonProps} />;
            case 'select':
                return (
                    <select {...commonProps}>
                        <option value="">Selecione...</option>
                        {field.options?.map(option => (
                            <option key={option} value={option}>{option}</option>
                        ))}
                    </select>
                );
            default:
                return <input type="text" {...commonProps} />;
        }
    };

    if (!formConfig) return <div>Carregando...</div>;

    return (
        <form onSubmit={(e) => {
            e.preventDefault();
            onSubmit({
                ...formData,
                template_id: selectedTemplate
            });
        }}>
            <div className="template-selector">
                <label>Template:</label>
                <select 
                    value={selectedTemplate} 
                    onChange={(e) => setSelectedTemplate(parseInt(e.target.value))}
                >
                    {templates.map(template => (
                        <option key={template.id} value={template.id}>
                            {template.name} v{template.version}
                        </option>
                    ))}
                </select>
            </div>

            {formConfig.sections.map((section, sectionIndex) => (
                <div key={sectionIndex} className="form-section">
                    <h3>{section.title}</h3>
                    {section.fields.map((field, fieldIndex) => (
                        <div key={fieldIndex} className="form-field">
                            <label>{field.label}</label>
                            {renderField(field)}
                        </div>
                    ))}
                </div>
            ))}

            <button type="submit">Criar Contrato</button>
        </form>
    );
}
```

## Administração e Monitoramento

### 1. Dashboards de Administração

#### Uso por Template
```sql
SELECT 
    t.name,
    t.version,
    COUNT(c.id) as total_contracts,
    COUNT(CASE WHEN c.created_at > NOW() - INTERVAL '30 days' THEN 1 END) as last_30_days,
    COUNT(CASE WHEN c.created_at > NOW() - INTERVAL '7 days' THEN 1 END) as last_7_days
FROM contract_layout_templates t
LEFT JOIN contracts c ON c.layout_template_id = t.id
WHERE t.is_active = true
GROUP BY t.id, t.name, t.version
ORDER BY total_contracts DESC;
```

#### Adoção por Tenant
```sql
SELECT 
    tc.tenant_id,
    dt.name as default_template,
    COUNT(c.id) as total_contracts,
    COUNT(DISTINCT c.layout_template_id) as templates_used
FROM tenant_contract_config tc
LEFT JOIN contract_layout_templates dt ON tc.default_layout_template_id = dt.id
LEFT JOIN contracts c ON c.tenant_id = tc.tenant_id
GROUP BY tc.tenant_id, dt.name
ORDER BY total_contracts DESC;
```

#### Performance por Template
```sql
SELECT 
    t.name,
    t.version,
    AVG(EXTRACT(EPOCH FROM (c.updated_at - c.created_at))) as avg_completion_time_seconds,
    COUNT(CASE WHEN c.updated_at - c.created_at < INTERVAL '5 minutes' THEN 1 END) as quick_completions,
    COUNT(CASE WHEN c.updated_at - c.created_at > INTERVAL '1 hour' THEN 1 END) as slow_completions
FROM contract_layout_templates t
JOIN contracts c ON c.layout_template_id = t.id
WHERE c.created_at > NOW() - INTERVAL '30 days'
GROUP BY t.id, t.name, t.version;
```

### 2. Alertas e Notificações

#### Template Não Utilizado
```sql
-- Templates ativos mas sem uso nos últimos 30 dias
SELECT t.name, t.version, t.created_at
FROM contract_layout_templates t
LEFT JOIN contracts c ON c.layout_template_id = t.id AND c.created_at > NOW() - INTERVAL '30 days'
WHERE t.is_active = true AND c.id IS NULL;
```

#### Migração Pendente
```sql
-- Contratos usando versões antigas
SELECT 
    c.id,
    c.name,
    t.version as current_version,
    nt.version as latest_version
FROM contracts c
JOIN contract_layout_templates t ON c.layout_template_id = t.id
JOIN contract_layout_templates nt ON nt.layout_type = t.layout_type AND nt.is_default = true
WHERE t.version != nt.version;
```

### 3. Métricas de Negócio

#### ROI por Template
```sql
SELECT 
    t.name,
    COUNT(c.id) as contracts_created,
    AVG(CASE WHEN c.data_classification = 'confidential' THEN 1000 
             WHEN c.data_classification = 'internal' THEN 500 
             ELSE 100 END) as estimated_value_per_contract,
    COUNT(c.id) * AVG(CASE WHEN c.data_classification = 'confidential' THEN 1000 
                           WHEN c.data_classification = 'internal' THEN 500 
                           ELSE 100 END) as total_estimated_value
FROM contract_layout_templates t
JOIN contracts c ON c.layout_template_id = t.id
WHERE c.created_at > NOW() - INTERVAL '90 days'
GROUP BY t.id, t.name
ORDER BY total_estimated_value DESC;
```

## Troubleshooting

### Problemas Comuns

#### 1. Template Não Aparece na Lista
**Sintomas**: Template existe no banco mas não aparece na API

**Verificações**:
```sql
-- Verificar se está ativo
SELECT id, name, version, is_active FROM contract_layout_templates WHERE name LIKE '%problema%';

-- Verificar se há erro no JSON
SELECT id, name, template_schema::text FROM contract_layout_templates WHERE id = X;
```

**Soluções**:
```sql
-- Ativar template
UPDATE contract_layout_templates SET is_active = true WHERE id = X;

-- Corrigir JSON inválido
UPDATE contract_layout_templates 
SET template_schema = '{"version": "1.0.0", "type": "fixed"}' 
WHERE id = X;
```

#### 2. Erro ao Criar Contrato
**Sintomas**: API retorna erro 400 ao criar contrato

**Verificações**:
```sql
-- Verificar se template existe e está ativo
SELECT * FROM contract_layout_templates WHERE id = X AND is_active = true;

-- Verificar configuração do tenant
SELECT * FROM tenant_contract_config WHERE tenant_id = 'problema';
```

**Soluções**:
```sql
-- Criar configuração de tenant
INSERT INTO tenant_contract_config (tenant_id, default_layout_template_id)
VALUES ('novo_tenant', 2);
```

#### 3. Formulário Não Renderiza Corretamente
**Sintomas**: Campos não aparecem ou validação falha

**Verificações**:
```sql
-- Verificar ui_config do template
SELECT template_schema->'ui_config' FROM contract_layout_templates WHERE id = X;
```

**Soluções**:
```sql
-- Corrigir ui_config
UPDATE contract_layout_templates 
SET template_schema = jsonb_set(
    template_schema, 
    '{ui_config}', 
    '{"form_sections": [{"title": "Básico", "fields": ["title"]}], "validation_rules": {"required_fields": ["title"]}}'
) 
WHERE id = X;
```

### Logs e Debugging

#### Habilitar Logs Detalhados
```python
import logging

# Configurar logging para templates
logging.getLogger('contract_templates').setLevel(logging.DEBUG)

# Log de criação de contrato
logger.debug(f"Creating contract with template {template_id} for tenant {tenant_id}")

# Log de validação
logger.debug(f"Validating contract data: {contract_data}")

# Log de migração
logger.debug(f"Migrating contract {contract_id} from {old_version} to {new_version}")
```

#### Métricas de Performance
```python
import time
from functools import wraps

def measure_time(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        start = time.time()
        result = func(*args, **kwargs)
        end = time.time()
        logger.info(f"{func.__name__} took {end - start:.2f} seconds")
        return result
    return wrapper

@measure_time
def create_contract_with_template(template_id, contract_data):
    # Implementação
    pass
```

## Melhores Práticas

### 1. Gestão de Templates

#### Versionamento Semântico
- **Major**: Mudanças incompatíveis (2.x.x → 3.x.x)
- **Minor**: Novos recursos compatíveis (2.1.x → 2.2.x)
- **Patch**: Correções de bugs (2.1.1 → 2.1.2)

#### Ciclo de Vida
1. **Desenvolvimento**: Template em desenvolvimento (não ativo)
2. **Beta**: Template ativo para usuários selecionados
3. **Produção**: Template ativo para todos
4. **Deprecated**: Template marcado para remoção
5. **Archived**: Template inativo mas mantido para histórico

```sql
-- Adicionar campos de ciclo de vida
ALTER TABLE contract_layout_templates ADD COLUMN lifecycle_stage VARCHAR(20) DEFAULT 'development';
ALTER TABLE contract_layout_templates ADD COLUMN deprecated_at TIMESTAMP;
ALTER TABLE contract_layout_templates ADD COLUMN end_of_life_at TIMESTAMP;
```

### 2. Segurança

#### Validação de Templates
```python
def validate_template_schema(template_schema):
    """Valida schema do template antes de salvar"""
    required_fields = ['version', 'type', 'schema', 'ui_config']
    
    for field in required_fields:
        if field not in template_schema:
            raise ValueError(f"Campo obrigatório '{field}' não encontrado")
    
    # Validar JSON schema
    try:
        jsonschema.validate(template_schema, TEMPLATE_JSON_SCHEMA)
    except jsonschema.ValidationError as e:
        raise ValueError(f"Schema inválido: {e.message}")
    
    return True
```

#### Controle de Acesso
```python
def check_template_access(user, template_id, action):
    """Verifica se usuário pode executar ação no template"""
    template = get_template(template_id)
    
    # Admin pode tudo
    if user.is_admin:
        return True
    
    # Usuário só pode usar templates do seu tenant
    if action == 'use' and template.tenant_id == user.tenant_id:
        return True
    
    # Apenas admins podem criar/editar templates
    if action in ['create', 'edit', 'delete']:
        return user.is_admin
    
    return False
```

### 3. Performance

#### Cache de Templates
```python
from functools import lru_cache
import redis

redis_client = redis.Redis()

@lru_cache(maxsize=100)
def get_template_cached(template_id):
    """Cache de templates em memória"""
    cache_key = f"template:{template_id}"
    
    # Tentar cache Redis primeiro
    cached = redis_client.get(cache_key)
    if cached:
        return json.loads(cached)
    
    # Buscar no banco
    template = get_template_from_db(template_id)
    
    # Salvar no cache (TTL 1 hora)
    redis_client.setex(cache_key, 3600, json.dumps(template))
    
    return template
```

#### Otimização de Queries
```sql
-- Índices para performance
CREATE INDEX idx_templates_active ON contract_layout_templates(is_active) WHERE is_active = true;
CREATE INDEX idx_templates_tenant ON contract_layout_templates(tenant_id);
CREATE INDEX idx_contracts_template ON contracts(layout_template_id);
CREATE INDEX idx_contracts_tenant_created ON contracts(tenant_id, created_at);
```

### 4. Monitoramento

#### Métricas Importantes
- **Taxa de adoção**: Novos contratos por template
- **Tempo de criação**: Tempo médio para criar contrato
- **Taxa de erro**: Falhas na criação/validação
- **Migração**: Contratos migrados entre versões

#### Alertas Recomendados
- Template não usado por 30 dias
- Taxa de erro > 5%
- Tempo de criação > 5 minutos
- Contratos usando versões antigas

### 5. Documentação

#### Template Documentation
```json
{
  "template_id": 3,
  "name": "LGPD Enhanced Contract",
  "version": "1.0.0",
  "documentation": {
    "description": "Template especializado para compliance LGPD",
    "use_cases": [
      "Dados pessoais de clientes",
      "Dados de funcionários",
      "Dados sensíveis"
    ],
    "required_fields": [
      "contract_title",
      "dpo_email",
      "legal_basis"
    ],
    "examples": {
      "basic_usage": {
        "contract_title": "Dados Clientes E-commerce",
        "legal_basis": "consentimento",
        "retention_period": "5 anos"
      }
    },
    "migration_notes": {
      "from_v2.3.0": "Adicionar campos LGPD obrigatórios",
      "to_v1.1.0": "Novos campos de consentimento"
    }
  }
}
```

## Conclusão

O Sistema de Múltiplos Layouts v1.2 oferece flexibilidade total para gerenciar diferentes tipos de contratos de dados sem necessidade de alterações no código. Com as práticas e exemplos apresentados neste guia, você pode:

- **Configurar múltiplos templates** para diferentes necessidades
- **Migrar gradualmente** entre versões
- **Personalizar por tenant** conforme necessário
- **Monitorar e otimizar** o uso do sistema
- **Manter segurança** e performance

**O sistema está pronto para uso em produção e pode escalar para atender organizações de qualquer porte.**

