#!/usr/bin/env python3
"""
COBOL AI Engine v1.2.0 - Main Funcional
Sistema simplificado que realmente conecta na LuzIA.
"""

import os
import sys
import json
import argparse
import logging
from datetime import datetime
from pathlib import Path

# Adicionar src ao path
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

from luzia_provider_working import LuziaProviderWorking

def setup_logging():
    """Configura logging do sistema."""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(),
            logging.FileHandler('cobol_ai_engine.log')
        ]
    )

def parse_cobol_file(file_path: str) -> list:
    """Parse do arquivo de fontes COBOL."""
    programs = []
    
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Dividir por programas (assumindo separação por PROGRAM-ID)
        program_sections = content.split('PROGRAM-ID.')
        
        for i, section in enumerate(program_sections[1:], 1):  # Pular primeira seção vazia
            lines = section.strip().split('\n')
            if lines:
                # Extrair nome do programa da primeira linha
                program_name = lines[0].strip().rstrip('.')
                
                # Reconstruir código completo
                program_code = f"PROGRAM-ID. {section}"
                
                programs.append({
                    'name': program_name,
                    'code': program_code,
                    'lines': len(lines)
                })
                
        logging.info(f"Parseados {len(programs)} programas de {file_path}")
        return programs
        
    except Exception as e:
        logging.error(f"Erro ao parsear arquivo {file_path}: {str(e)}")
        return []

def parse_books_file(file_path: str) -> list:
    """Parse do arquivo de copybooks."""
    books = []
    
    if not file_path or not os.path.exists(file_path):
        return books
    
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Dividir por copybooks (assumindo separação por padrão)
        book_sections = content.split('COPY ')
        
        for section in book_sections[1:]:  # Pular primeira seção
            lines = section.strip().split('\n')
            if lines:
                book_name = lines[0].strip().rstrip('.')
                books.append({
                    'name': book_name,
                    'content': section
                })
                
        logging.info(f"Parseados {len(books)} copybooks de {file_path}")
        return books
        
    except Exception as e:
        logging.error(f"Erro ao parsear copybooks {file_path}: {str(e)}")
        return []

def save_analysis_results(program_name: str, analysis_result: dict, output_dir: str):
    """Salva resultados da análise em arquivos."""
    
    # Criar diretórios
    os.makedirs(output_dir, exist_ok=True)
    os.makedirs(os.path.join(output_dir, 'ai_requests'), exist_ok=True)
    os.makedirs(os.path.join(output_dir, 'ai_responses'), exist_ok=True)
    
    # Salvar request
    request_file = os.path.join(output_dir, 'ai_requests', f'{program_name}_request.json')
    with open(request_file, 'w', encoding='utf-8') as f:
        json.dump({
            'program_name': program_name,
            'timestamp': datetime.now().isoformat(),
            'request_payload': analysis_result.get('request_payload', {}),
            'model_used': 'aws-claude-3-5-sonnet',
            'provider': 'luzia'
        }, f, indent=2, ensure_ascii=False)
    
    # Salvar response
    response_file = os.path.join(output_dir, 'ai_responses', f'{program_name}_response.json')
    with open(response_file, 'w', encoding='utf-8') as f:
        json.dump({
            'program_name': program_name,
            'timestamp': datetime.now().isoformat(),
            'success': analysis_result.get('success', False),
            'response_data': analysis_result.get('response', {}),
            'error': analysis_result.get('error'),
            'model_used': 'aws-claude-3-5-sonnet',
            'provider': 'luzia'
        }, f, indent=2, ensure_ascii=False)
    
    # Salvar relatório markdown se sucesso
    if analysis_result.get('success') and analysis_result.get('response'):
        report_file = os.path.join(output_dir, f'{program_name}.md')
        
        # Extrair conteúdo da resposta LuzIA
        response_data = analysis_result.get('response', {})
        content = ""
        
        # Tentar extrair conteúdo da estrutura de resposta da LuzIA
        if 'output' in response_data:
            content = response_data['output']
        elif 'result' in response_data:
            content = response_data['result']
        elif 'content' in response_data:
            content = response_data['content']
        else:
            content = json.dumps(response_data, indent=2)
        
        # Criar relatório markdown
        markdown_content = f"""# Análise do Programa COBOL: {program_name}

**Data da Análise**: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}  
**Modelo Utilizado**: aws-claude-3-5-sonnet  
**Provedor**: LuzIA  

## Análise Detalhada

{content}

## Transparência e Auditoria

### Informações da Análise

- **Status da Análise**: {'SUCESSO' if analysis_result.get('success') else 'ERRO'}
- **Provedor Utilizado**: LuzIA
- **Modelo**: aws-claude-3-5-sonnet
- **Timestamp**: {datetime.now().isoformat()}

### Prompts Utilizados na Análise

#### System Prompt
```
Você é um programador COBOL muito experiente com mais de 20 anos de experiência em sistemas mainframe e aplicações críticas de negócio.

Sua tarefa é analisar o programa COBOL fornecido de forma completa e detalhada...
```

#### User Prompt
```
Analise este programa COBOL:

Nome do Programa: {program_name}
[Código fonte completo incluído]
```

### Arquivos de Auditoria

- **Request JSON**: `ai_requests/{program_name}_request.json`
- **Response JSON**: `ai_responses/{program_name}_response.json`

---
*Relatório gerado pelo COBOL AI Engine v1.2.0*
"""
        
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write(markdown_content)
        
        logging.info(f"Relatório salvo: {report_file}")

def check_luzia_status():
    """Verifica status da conexão com LuzIA."""
    print("COBOL AI Engine v1.2.0 - Status da LuzIA")
    print("=" * 50)
    
    # Verificar variáveis de ambiente
    client_id = os.getenv("LUZIA_CLIENT_ID")
    client_secret = os.getenv("LUZIA_CLIENT_SECRET")
    
    print("VARIAVEIS DE AMBIENTE")
    print("-" * 30)
    print(f"LUZIA_CLIENT_ID: {'[OK] Configurada' if client_id else '[ERRO] Não configurada'}")
    print(f"LUZIA_CLIENT_SECRET: {'[OK] Configurada' if client_secret else '[ERRO] Não configurada'}")
    print()
    
    if not client_id or not client_secret:
        print("[ERRO] Configure as variáveis de ambiente antes de usar:")
        print("export LUZIA_CLIENT_ID='seu_client_id'")
        print("export LUZIA_CLIENT_SECRET='seu_client_secret'")
        return False
    
    # Testar conexão
    print("TESTE DE CONECTIVIDADE")
    print("-" * 30)
    
    provider = LuziaProviderWorking()
    token = provider.get_token()
    
    if token:
        print("[OK] Conectividade com LuzIA estabelecida")
        print(f"[OK] Token obtido: {token[:20]}...")
        print("[OK] Pronto para análise")
        return True
    else:
        print("[ERRO] Falha na conectividade com LuzIA")
        print("[ERRO] Verifique credenciais e conectividade de rede")
        return False

def main():
    """Função principal."""
    parser = argparse.ArgumentParser(description='COBOL AI Engine v1.2.0 - Análise com LuzIA')
    parser.add_argument('--fontes', required=False, help='Arquivo de fontes COBOL')
    parser.add_argument('--books', help='Arquivo de copybooks')
    parser.add_argument('--output', default='output', help='Diretório de saída')
    parser.add_argument('--status', action='store_true', help='Verificar status da LuzIA')
    
    args = parser.parse_args()
    
    # Configurar logging
    setup_logging()
    
    # Verificar status se solicitado
    if args.status:
        check_luzia_status()
        return
    
    # Validar argumentos
    if not args.fontes:
        print("Erro: --fontes é obrigatório")
        print("Use: python main_working.py --fontes arquivo.txt")
        print("Ou: python main_working.py --status")
        return
    
    if not os.path.exists(args.fontes):
        print(f"Erro: Arquivo {args.fontes} não encontrado")
        return
    
    # Verificar conectividade
    print("Verificando conectividade com LuzIA...")
    if not check_luzia_status():
        print("Abortando: Problemas de conectividade com LuzIA")
        return
    
    print("\nIniciando análise...")
    
    # Parse dos arquivos
    programs = parse_cobol_file(args.fontes)
    books = parse_books_file(args.books) if args.books else []
    
    if not programs:
        print("Nenhum programa encontrado no arquivo de fontes")
        return
    
    print(f"Encontrados {len(programs)} programas para análise")
    
    # Inicializar provider
    provider = LuziaProviderWorking()
    
    # Analisar cada programa
    for i, program in enumerate(programs, 1):
        program_name = program['name']
        program_code = program['code']
        
        print(f"\nAnalisando programa {i}/{len(programs)}: {program_name}")
        
        # Executar análise
        result = provider.analyze_cobol_program(program_name, program_code, books)
        
        # Salvar resultados
        save_analysis_results(program_name, result, args.output)
        
        if result.get('success'):
            print(f"[OK] {program_name} analisado com sucesso")
        else:
            print(f"[ERRO] Falha na análise de {program_name}: {result.get('error')}")
    
    print(f"\nAnálise concluída. Resultados salvos em: {args.output}")
    print(f"- Relatórios: {args.output}/*.md")
    print(f"- Requests: {args.output}/ai_requests/")
    print(f"- Responses: {args.output}/ai_responses/")

if __name__ == "__main__":
    main()
