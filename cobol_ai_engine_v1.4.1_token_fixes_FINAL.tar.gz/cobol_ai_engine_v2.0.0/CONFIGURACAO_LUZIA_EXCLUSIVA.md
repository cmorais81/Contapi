# Configuração para Uso Exclusivo da LuzIA

## COBOL AI Engine v1.1.0 - Configuração LuzIA

Este documento descreve como configurar o sistema para usar **exclusivamente a LuzIA** com o modelo **aws-claude-3-5-sonnet**.

## Configuração Atual

### Provedores Habilitados
- **LuzIA**: HABILITADO (único provedor ativo)
- **OpenAI**: DESABILITADO
- **Mock**: DESABILITADO

### Modelo Padrão
- **aws_claude_3_5_sonnet**: Modelo principal da LuzIA configurado como padrão

## Variáveis de Ambiente Necessárias

Configure as seguintes variáveis de ambiente antes de usar o sistema:

```bash
export LUZIA_CLIENT_ID="seu_client_id_luzia"
export LUZIA_CLIENT_SECRET="seu_client_secret_luzia"
```

## Verificação da Configuração

Para verificar se a configuração está correta:

```bash
python main.py --status
```

**Saída esperada:**
```
COBOL AI Engine v1.1.0 - Status dos Provedores
============================================================
CONFIGURACAO GERAL
------------------------------
Modelos padrão configurados: 1
  - aws_claude_3_5_sonnet

VARIAVEIS DE AMBIENTE
------------------------------
[OK] LUZIA_CLIENT_ID: Configurada
[OK] LUZIA_CLIENT_SECRET: Configurada

PROVEDORES CONFIGURADOS
------------------------------
[HABILITADO] LUZIA
   [OK] Client ID: Configurado
   [OK] Client Secret: Configurado
   [OK] Auth URL: https://login.azure.paas.santanderbr.pre.corp/...
   [OK] API URL: https://gpt-api-aws.santanderbr.dev.corp/...
   Modelos: aws_claude_3_5_sonnet, claude_3_5_sonnet

[DESABILITADO] OpenAI
[DESABILITADO] Enhanced Mock

TESTE DE CONECTIVIDADE
------------------------------
[TESTE] Testando LuzIA...
   [OK] Conectividade estabelecida
   [OK] Autenticação bem-sucedida
   [OK] Modelo aws-claude-3-5-sonnet disponível
```

## Uso do Sistema

### Análise Básica (usa modelo padrão automaticamente)
```bash
python main.py --fontes seus_programas.txt
```

### Análise Completa com Copybooks
```bash
python main.py --fontes seus_programas.txt --books seus_copybooks.txt
```

### Análise com Geração HTML
```bash
python main.py --fontes seus_programas.txt --pdf --output relatorio_luzia
```

### Especificar Modelo Explicitamente (opcional)
```bash
python main.py --fontes seus_programas.txt --models "aws_claude_3_5_sonnet"
```

## Comportamento do Sistema

### Quando LuzIA Está Disponível
- Sistema usa exclusivamente a LuzIA
- Modelo aws-claude-3-5-sonnet é utilizado
- Análise completa e detalhada é realizada
- Requests e responses são salvos para auditoria

### Quando LuzIA Não Está Disponível
- Sistema retorna erro claro de conectividade
- **NÃO há fallback para mock ou outros provedores**
- Mensagem de erro específica é exibida
- Processo é interrompido para investigação

## Estrutura de Saída

```
output/
├── PROGRAMA1.md                    # Relatório markdown
├── PROGRAMA1.html                  # Versão HTML (se --pdf usado)
├── ai_responses/
│   └── PROGRAMA1_ai_response.json  # Resposta da LuzIA
└── ai_requests/
    └── PROGRAMA1_ai_request.json   # Request enviado à LuzIA
```

## Solução de Problemas

### Erro: "LUZIA_CLIENT_ID não configurado"
```bash
export LUZIA_CLIENT_ID="seu_client_id"
```

### Erro: "Erro de conectividade com LuzIA"
1. Verificar se as credenciais estão corretas
2. Verificar conectividade de rede
3. Verificar se o serviço LuzIA está disponível
4. Usar `python main.py --status` para diagnóstico

### Erro: "Modelo aws-claude-3-5-sonnet não configurado"
- Verificar se o modelo está listado na seção `luzia.models` do config.yaml
- Confirmar que o nome do modelo está correto: "aws-claude-3-5-sonnet"

## Vantagens da Configuração Exclusiva

1. **Performance Otimizada**: Sem overhead de múltiplos provedores
2. **Consistência**: Todos os relatórios usam o mesmo modelo
3. **Auditoria Simplificada**: Apenas um provedor para rastrear
4. **Configuração Limpa**: Menos complexidade de configuração
5. **Erro Claro**: Falhas são imediatamente identificadas

## Logs e Monitoramento

O sistema gera logs detalhados em:
- Console: Informações de progresso
- Arquivos JSON: Requests e responses completos
- Metadados: Informações de timing e qualidade

Para debug adicional, use:
```bash
python main.py --fontes seus_programas.txt --verbose
```
