#!/usr/bin/env python3
"""
Verificação simples das correções implementadas
COBOL AI Engine v1.4.0 - Token Fixes
"""

import os
import sys

def verify_luzia_provider_fixes():
    """Verifica se as correções estão no luzia_provider.py"""
    print("=== VERIFICANDO luzia_provider.py ===")
    
    with open('src/providers/luzia_provider.py', 'r') as f:
        content = f.read()
    
    # Verificar se tem controle de expiração
    if '_token_expires_at' in content:
        print("✓ Controle de expiração de token implementado")
    else:
        print("✗ Controle de expiração de token AUSENTE")
        return False
    
    # Verificar se tem verificação proativa
    if '_is_token_expired' in content:
        print("✓ Verificação proativa de token implementada")
    else:
        print("✗ Verificação proativa de token AUSENTE")
        return False
    
    # Verificar se aceita status 201
    if 'response.status_code in [200, 201]' in content:
        print("✓ Tratamento de status HTTP 201 implementado")
    else:
        print("✗ Tratamento de status HTTP 201 AUSENTE")
        return False
    
    # Verificar tratamento de erro 401
    if 'elif response.status_code == 401:' in content:
        print("✓ Tratamento específico de erro 401 implementado")
    else:
        print("✗ Tratamento específico de erro 401 AUSENTE")
        return False
    
    return True

def verify_main_detailed_fixes():
    """Verifica se as correções estão no main_detailed.py"""
    print("\n=== VERIFICANDO main_detailed.py ===")
    
    with open('main_detailed.py', 'r') as f:
        content = f.read()
    
    # Verificar se tem controle de expiração
    if 'token_expires_at' in content:
        print("✓ Controle de expiração de token implementado")
    else:
        print("✗ Controle de expiração de token AUSENTE")
        return False
    
    # Verificar se tem verificação proativa
    if '_is_token_expired' in content:
        print("✓ Verificação proativa de token implementada")
    else:
        print("✗ Verificação proativa de token AUSENTE")
        return False
    
    # Verificar se aceita status 201
    if 'response.status_code in [200, 201]' in content:
        print("✓ Tratamento de status HTTP 201 implementado")
    else:
        print("✗ Tratamento de status HTTP 201 AUSENTE")
        return False
    
    # Verificar tratamento de erro 401
    if 'elif response.status_code == 401:' in content:
        print("✓ Tratamento específico de erro 401 implementado")
    else:
        print("✗ Tratamento específico de erro 401 AUSENTE")
        return False
    
    return True

def main():
    """Executa verificação das correções."""
    print("🔧 COBOL AI Engine v1.4.0 - Verificação de Correções")
    print("=" * 60)
    
    os.chdir('/home/ubuntu/cobol_ai_engine_v2.0.0')
    
    luzia_ok = verify_luzia_provider_fixes()
    main_detailed_ok = verify_main_detailed_fixes()
    
    print("\n" + "=" * 60)
    
    if luzia_ok and main_detailed_ok:
        print("🎉 TODAS AS CORREÇÕES ESTÃO IMPLEMENTADAS!")
        print("✅ luzia_provider.py: CORRIGIDO")
        print("✅ main_detailed.py: CORRIGIDO")
        print("✅ Sistema pronto para uso")
        return True
    else:
        print("❌ ALGUMAS CORREÇÕES ESTÃO AUSENTES")
        if not luzia_ok:
            print("✗ luzia_provider.py: PROBLEMAS")
        if not main_detailed_ok:
            print("✗ main_detailed.py: PROBLEMAS")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
