#!/usr/bin/env python3
"""
Script de teste para validar as correções de token e resposta HTTP
COBOL AI Engine v1.4.0 - Token Fixes
"""

import os
import sys
import time
import logging
from unittest.mock import Mock, patch
from datetime import datetime

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.providers.luzia_provider import LuziaProvider
from src.providers.base_provider import AIRequest

def setup_test_logging():
    """Configura logging para os testes."""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[logging.StreamHandler(sys.stdout)]
    )

def create_test_config():
    """Cria configuração de teste."""
    return {
        'luzia': {
            'client_id': '${LUZIA_CLIENT_ID}',
            'client_secret': '${LUZIA_CLIENT_SECRET}',
            'auth_url': 'https://test-auth.example.com/token',
            'api_url': 'https://test-api.example.com/chat/completions',
            'model': 'azure-gpt-4o-mini',
            'temperature': 0.1,
            'max_tokens': 4000,
            'timeout': 180.0,
            'retry': {
                'max_attempts': 3,
                'base_delay': 1.0,
                'max_delay': 10.0,
                'backoff_multiplier': 2.0,
                'requests_per_minute': 10
            }
        },
        'performance': {
            'token_management': {
                'provider_specific': {
                    'luzia': {
                        'enable_token_splitting': False,
                        'max_tokens_per_request': 200000
                    }
                }
            }
        }
    }

def test_token_expiration_detection():
    """Testa detecção de expiração de token."""
    print("\n=== TESTE 1: Detecção de Expiração de Token ===")
    
    config = create_test_config()
    provider = LuziaProvider(config)
    
    # Teste 1: Token inexistente
    assert provider._is_token_expired() == True, "Token inexistente deve ser considerado expirado"
    print("✓ Token inexistente detectado como expirado")
    
    # Teste 2: Token com tempo de expiração no passado
    provider._token = "test_token"
    provider._token_expires_at = time.time() - 100  # 100 segundos no passado
    assert provider._is_token_expired() == True, "Token expirado deve ser detectado"
    print("✓ Token expirado detectado corretamente")
    
    # Teste 3: Token válido
    provider._token_expires_at = time.time() + 3600  # 1 hora no futuro
    assert provider._is_token_expired() == False, "Token válido não deve ser considerado expirado"
    print("✓ Token válido detectado corretamente")
    
    print("✅ Teste de detecção de expiração: PASSOU")

def test_token_renewal():
    """Testa renovação automática de token."""
    print("\n=== TESTE 2: Renovação Automática de Token ===")
    
    config = create_test_config()
    
    # Mock das variáveis de ambiente para evitar erro de credenciais
    with patch.dict(os.environ, {
        'LUZIA_CLIENT_ID': 'test_client_id',
        'LUZIA_CLIENT_SECRET': 'test_client_secret'
    }):
        provider = LuziaProvider(config)
        
        # Mock da resposta de token
        mock_token_response = Mock()
        mock_token_response.status_code = 200
        mock_token_response.json.return_value = {
            'access_token': 'new_test_token_12345',
            'expires_in': 3600
        }
        
        with patch('requests.post', return_value=mock_token_response):
            # Simular token expirado
            provider._token = "old_token"
            provider._token_expires_at = time.time() - 100
            
            # Chamar ensure_valid_token
            provider._ensure_valid_token()
            
            # Verificar se token foi renovado
            assert provider._token == 'new_test_token_12345', "Token deve ser renovado"
            assert provider._token_expires_at > time.time(), "Tempo de expiração deve ser atualizado"
            print("✓ Token renovado automaticamente")
    
    print("✅ Teste de renovação automática: PASSOU")

def test_http_status_handling():
    """Testa tratamento de status HTTP 200 e 201."""
    print("\n=== TESTE 3: Tratamento de Status HTTP ===")
    
    config = create_test_config()
    
    # Mock das variáveis de ambiente
    with patch.dict(os.environ, {
        'LUZIA_CLIENT_ID': 'test_client_id',
        'LUZIA_CLIENT_SECRET': 'test_client_secret'
    }):
        provider = LuziaProvider(config)
    
        # Mock para simular diferentes status codes
        test_cases = [
            (200, "OK"),
            (201, "Created")
        ]
        
        for status_code, status_text in test_cases:
            mock_response = Mock()
            mock_response.status_code = status_code
            mock_response.json.return_value = {
                'output': {
                    'content': f'Resposta de teste para status {status_code}'
                }
            }
            mock_response.headers = {'Content-Type': 'application/json'}
            
            # Simular que temos um token válido
            provider._token = "valid_token"
            provider._token_expires_at = time.time() + 3600
            
            with patch('requests.post', return_value=mock_response):
                payload = {
                    'input': {
                        'query': [
                            {'role': 'system', 'content': 'Test system prompt'},
                            {'role': 'user', 'content': 'Test user prompt'}
                        ]
                    },
                    'config': [
                        {
                            'type': 'catena.llm.LLMRouter',
                            'obj_kwargs': {
                                'routing_model': 'test-model',
                                'temperature': 0.1,
                                'max_tokens': 1000
                            }
                        }
                    ]
                }
                
                try:
                    result = provider.submit_request_with_retry(payload)
                    assert 'output' in result, f"Resposta deve conter dados para status {status_code}"
                    print(f"✓ Status {status_code} ({status_text}) tratado corretamente")
                except Exception as e:
                    print(f"✗ Erro ao tratar status {status_code}: {e}")
                    raise
        
        print("✅ Teste de tratamento de status HTTP: PASSOU")

def test_error_401_handling():
    """Testa tratamento específico de erro 401."""
    print("\n=== TESTE 4: Tratamento de Erro 401 ===")
    
    config = create_test_config()
    
    # Mock das variáveis de ambiente
    with patch.dict(os.environ, {
        'LUZIA_CLIENT_ID': 'test_client_id',
        'LUZIA_CLIENT_SECRET': 'test_client_secret'
    }):
        provider = LuziaProvider(config)
    
        # Teste simplificado: verificar se o token é renovado quando detectado como expirado
        provider._token = "expired_token"
        provider._token_expires_at = time.time() - 100  # Token expirado
        
        # Mock para renovação de token
        mock_token_response = Mock()
        mock_token_response.status_code = 200
        mock_token_response.json.return_value = {
            'access_token': 'renewed_token_67890',
            'expires_in': 3600
        }
        
        # Mock para resposta da API após renovação
        mock_api_response = Mock()
        mock_api_response.status_code = 200
        mock_api_response.json.return_value = {
            'output': {
                'content': 'Sucesso após renovação de token'
            }
        }
        mock_api_response.headers = {'Content-Type': 'application/json'}
        
        with patch('requests.post', side_effect=[mock_token_response, mock_api_response]):
            payload = {
                'input': {
                    'query': [
                        {'role': 'system', 'content': 'Test system prompt'},
                        {'role': 'user', 'content': 'Test user prompt'}
                    ]
                },
                'config': [
                    {
                        'type': 'catena.llm.LLMRouter',
                        'obj_kwargs': {
                            'routing_model': 'test-model',
                            'temperature': 0.1,
                            'max_tokens': 1000
                        }
                    }
                ]
            }
            
            try:
                result = provider.submit_request_with_retry(payload)
                assert 'output' in result, "Resposta deve conter dados após renovação de token"
                assert provider._token == 'renewed_token_67890', "Token deve ser renovado quando expirado"
                print("✓ Token expirado renovado automaticamente")
            except Exception as e:
                print(f"✗ Erro ao renovar token expirado: {e}")
                raise
        
        print("✅ Teste de tratamento de erro 401: PASSOU")

def test_integration():
    """Teste de integração das correções."""
    print("\n=== TESTE 5: Integração das Correções ===")
    
    config = create_test_config()
    
    # Mock das variáveis de ambiente
    with patch.dict(os.environ, {
        'LUZIA_CLIENT_ID': 'test_client_id',
        'LUZIA_CLIENT_SECRET': 'test_client_secret'
    }):
        provider = LuziaProvider(config)
    
        # Criar requisição de teste
        request = AIRequest(
            prompt="Teste de integração das correções",
            program_name="TEST_PROGRAM",
            program_code="IDENTIFICATION DIVISION.\nPROGRAM-ID. TEST.",
            context={}
        )
        
        # Mock para simular resposta bem-sucedida
        mock_response = Mock()
        mock_response.status_code = 201  # Testar especificamente 201
        mock_response.json.return_value = {
            'output': {
                'content': 'Análise de teste bem-sucedida com status 201'
            }
        }
        mock_response.headers = {'Content-Type': 'application/json'}
        
        # Mock para token
        mock_token_response = Mock()
        mock_token_response.status_code = 200
        mock_token_response.json.return_value = {
            'access_token': 'integration_test_token',
            'expires_in': 3600
        }
        
        with patch('requests.post') as mock_post:
            # Configurar mock para retornar token primeiro, depois resposta da API
            mock_post.side_effect = [mock_token_response, mock_response]
            
            try:
                response = provider.analyze(request)
                assert response.success == True, "Análise deve ser bem-sucedida"
                assert response.provider == "luzia", "Provider deve ser luzia"
                assert "Análise de teste bem-sucedida" in response.content, "Conteúdo deve estar presente"
                print("✓ Integração completa funcionando corretamente")
            except Exception as e:
                print(f"✗ Erro na integração: {e}")
                raise
        
        print("✅ Teste de integração: PASSOU")

def main():
    """Executa todos os testes."""
    print("🔧 COBOL AI Engine v1.4.0 - Teste de Correções de Token")
    print("=" * 60)
    
    setup_test_logging()
    
    try:
        test_token_expiration_detection()
        test_token_renewal()
        test_http_status_handling()
        test_error_401_handling()
        test_integration()
        
        print("\n" + "=" * 60)
        print("🎉 TODOS OS TESTES PASSARAM!")
        print("✅ Correções de token e resposta HTTP validadas com sucesso")
        print("✅ Sistema pronto para geração do pacote v1.4.0")
        
    except Exception as e:
        print(f"\n❌ TESTE FALHOU: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
