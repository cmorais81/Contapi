"""
COBOL AI Engine - LuzIA Provider Funcional
Baseado no código de exemplo fornecido.
"""

import requests
import json
import os
import logging
from typing import Dict, Any, Optional
from datetime import datetime

class LuziaProviderWorking:
    """Provider funcional para LuzIA baseado no código de exemplo."""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
        # Configurações da LuzIA
        self.client_id = os.getenv("LUZIA_CLIENT_ID")
        self.client_secret = os.getenv("LUZIA_CLIENT_SECRET")
        self.sso_endpoint = "https://login.azure.paas.santanderbr.pre.corp/auth/realms/corp/protocol/openid-connect/token"
        self.api_url = "https://gpt-api-aws.santanderbr.dev.corp/genai_services/v1/"
        
        # Token de acesso
        self.token = None
        
        # Configurar warnings
        import warnings
        warnings.filterwarnings("ignore", message="Unverified HTTPS request is being made to host")
        
    def get_token(self) -> Optional[str]:
        """Obtém token de acesso da LuzIA."""
        try:
            request_body = {
                "grant_type": "client_credentials",
                "client_id": self.client_id,
                "client_secret": self.client_secret
            }
            
            headers = {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Accept': '*/*'
            }
            
            response = requests.post(
                self.sso_endpoint, 
                headers=headers, 
                data=request_body, 
                verify=False
            )
            
            if response.status_code == 200:
                token_data = response.json()
                self.token = token_data.get("access_token")
                self.logger.info("Token obtido com sucesso")
                return self.token
            else:
                self.logger.error(f"Erro ao obter token: {response.status_code} - {response.text}")
                return None
                
        except Exception as e:
            self.logger.error(f"Erro ao obter token: {str(e)}")
            return None
    
    def submit_request(self, system_prompt: str, user_prompt: str, model: str = "aws-claude-3-5-sonnet") -> Dict[str, Any]:
        """Submete requisição para a LuzIA."""
        
        # Garantir que temos token
        if not self.token:
            self.get_token()
        
        if not self.token:
            return {"error": "Não foi possível obter token de acesso"}
        
        # Montar payload conforme exemplo
        payload = {
            "input": {
                "query": [
                    {
                        "role": "system",
                        "content": system_prompt
                    },
                    {
                        "role": "user", 
                        "content": user_prompt
                    }
                ]
            },
            "config": [
                {
                    "type": "catena.llm.LLMRouter",
                    "obj_kwargs": {
                        "routing_model": model,
                        "temperature": 0.1
                    }
                }
            ]
        }
        
        try:
            headers = {
                "x-santander-client-id": self.client_id,
                "Authorization": f"Bearer {self.token}",
                "Content-Type": "application/json"
            }
            
            response = requests.post(
                url=f"{self.api_url}pipelines/submit",
                json=payload,
                headers=headers,
                verify=False,
                timeout=120
            )
            
            if response.status_code == 200:
                result = response.json()
                self.logger.info("Requisição enviada com sucesso para LuzIA")
                return {
                    "success": True,
                    "response": result,
                    "request_payload": payload,
                    "status_code": response.status_code
                }
            else:
                self.logger.error(f"Erro na requisição LuzIA: {response.status_code} - {response.text}")
                return {
                    "success": False,
                    "error": f"HTTP {response.status_code}: {response.text}",
                    "request_payload": payload
                }
                
        except Exception as e:
            self.logger.error(f"Erro ao submeter requisição: {str(e)}")
            return {
                "success": False,
                "error": str(e),
                "request_payload": payload
            }
    
    def analyze_cobol_program(self, program_name: str, program_code: str, books: list = None) -> Dict[str, Any]:
        """Analisa programa COBOL usando LuzIA."""
        
        # System prompt para programador COBOL experiente
        system_prompt = """Você é um programador COBOL muito experiente com mais de 20 anos de experiência em sistemas mainframe e aplicações críticas de negócio.

Sua tarefa é analisar o programa COBOL fornecido de forma completa e detalhada, considerando:

1. Arquitetura e estrutura técnica
2. Regras de negócio implementadas  
3. Qualidade do código e boas práticas
4. Comentários e documentação inline
5. Fluxos lógicos e complexidade
6. Interfaces e integrações
7. Performance e otimização
8. Manutenibilidade

Forneça uma análise profissional e detalhada que seria útil para outros desenvolvedores e analistas de negócio."""

        # User prompt com o programa
        user_prompt = f"""Analise este programa COBOL:

Nome do Programa: {program_name}

Código Fonte:
{program_code}

"""

        if books:
            user_prompt += f"\nCopybooks relacionados:\n"
            for book in books:
                user_prompt += f"- {book.get('name', 'Unknown')}\n"

        user_prompt += """
Por favor, forneça uma análise completa incluindo:

1. **Análise Funcional**: O que o programa faz, qual seu propósito no sistema
2. **Estrutura Técnica**: Divisões, seções, variáveis principais, arquivos
3. **Regras de Negócio**: Regras implementadas, validações, cálculos
4. **Comentários e Documentação**: Análise dos comentários encontrados
5. **Qualidade do Código**: Avaliação técnica, pontos de melhoria
6. **Fluxos Lógicos**: Principais fluxos de execução e decisões
7. **Interfaces**: Arquivos de entrada/saída, chamadas para outros programas
8. **Recomendações**: Sugestões de melhoria e manutenção

Seja detalhado e técnico, mas também explique o contexto de negócio quando possível.
"""

        # Executar análise
        try:
            result = self.submit_request(system_prompt, user_prompt)
            return result
        except Exception as e:
            self.logger.error(f"Erro na análise: {str(e)}")
            return {
                "success": False,
                "error": str(e)
            }

def test_luzia_connection():
    """Testa conexão com LuzIA."""
    provider = LuziaProviderWorking()
    
    # Testar obtenção de token
    token = provider.get_token()
    if token:
        print(f"[OK] Token obtido: {token[:20]}...")
        
        # Testar análise simples
        test_code = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. TESTE.
       
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01 WS-CONTADOR PIC 9(3) VALUE ZERO.
       
       PROCEDURE DIVISION.
       MAIN-PARA.
           DISPLAY 'PROGRAMA DE TESTE'.
           STOP RUN.
        """
        
        result = provider.analyze_cobol_program("TESTE", test_code)
        
        if result.get("success"):
            print("[OK] Análise realizada com sucesso")
            print(f"Response: {json.dumps(result, indent=2)}")
        else:
            print(f"[ERRO] Falha na análise: {result.get('error')}")
    else:
        print("[ERRO] Não foi possível obter token")

if __name__ == "__main__":
    # Configurar logging
    logging.basicConfig(level=logging.INFO)
    
    # Testar conexão
    test_luzia_connection()
