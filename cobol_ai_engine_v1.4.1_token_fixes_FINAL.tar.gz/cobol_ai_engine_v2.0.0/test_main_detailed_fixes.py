#!/usr/bin/env python3
"""
Teste específico para validar correções no main_detailed.py
COBOL AI Engine v1.4.0 - Token Fixes
"""

import os
import sys
import time
import logging
from unittest.mock import Mock, patch
from datetime import datetime

# Adicionar diretório atual ao path
sys.path.insert(0, os.path.dirname(__file__))

# Importar o LuziaConnector do main_detailed
from main_detailed import LuziaConnector, setup_detailed_logging

def test_luzia_connector_token_management():
    """Testa o gerenciamento de token no LuziaConnector."""
    print("=== TESTE: Gerenciamento de Token no LuziaConnector ===")
    
    # Configurar logging
    setup_detailed_logging()
    
    # Mock das variáveis de ambiente
    with patch.dict(os.environ, {
        'LUZIA_CLIENT_ID': 'test_client_id',
        'LUZIA_CLIENT_SECRET': 'test_client_secret'
    }):
        connector = LuziaConnector()
        
        # Teste 1: Token inexistente deve ser considerado expirado
        assert connector._is_token_expired() == True, "Token inexistente deve ser expirado"
        print("✓ Token inexistente detectado como expirado")
        
        # Teste 2: Token expirado
        connector.token = "test_token"
        connector.token_expires_at = time.time() - 100  # 100s no passado
        assert connector._is_token_expired() == True, "Token expirado deve ser detectado"
        print("✓ Token expirado detectado corretamente")
        
        # Teste 3: Token válido
        connector.token_expires_at = time.time() + 3600  # 1h no futuro
        assert connector._is_token_expired() == False, "Token válido não deve ser expirado"
        print("✓ Token válido detectado corretamente")
        
        print("✅ Teste de gerenciamento de token: PASSOU")

def test_luzia_connector_token_renewal():
    """Testa renovação automática de token."""
    print("\n=== TESTE: Renovação Automática de Token ===")
    
    # Mock das variáveis de ambiente
    with patch.dict(os.environ, {
        'LUZIA_CLIENT_ID': 'test_client_id',
        'LUZIA_CLIENT_SECRET': 'test_client_secret'
    }):
        connector = LuziaConnector()
        
        # Mock da resposta de token
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.headers = {'Content-Type': 'application/json'}
        mock_response.json.return_value = {
            'access_token': 'new_test_token_12345',
            'expires_in': 3600
        }
        
        with patch('requests.post', return_value=mock_response):
            # Simular token expirado
            connector.token = "old_token"
            connector.token_expires_at = time.time() - 100
            
            # Chamar ensure_valid_token
            connector._ensure_valid_token()
            
            # Verificar se token foi renovado
            assert connector.token == 'new_test_token_12345', "Token deve ser renovado"
            assert connector.token_expires_at > time.time(), "Tempo de expiração deve ser atualizado"
            print("✓ Token renovado automaticamente")
        
        print("✅ Teste de renovação automática: PASSOU")

def test_luzia_connector_http_status():
    """Testa tratamento de status HTTP 200 e 201."""
    print("\n=== TESTE: Tratamento de Status HTTP ===")
    
    # Mock das variáveis de ambiente
    with patch.dict(os.environ, {
        'LUZIA_CLIENT_ID': 'test_client_id',
        'LUZIA_CLIENT_SECRET': 'test_client_secret'
    }):
        connector = LuziaConnector()
        
        # Simular token válido
        connector.token = "valid_token"
        connector.token_expires_at = time.time() + 3600
        
        test_cases = [
            (200, "OK"),
            (201, "Created")
        ]
        
        for status_code, status_text in test_cases:
            mock_response = Mock()
            mock_response.status_code = status_code
            mock_response.json.return_value = {
                'output': {
                    'content': f'Resposta de teste para status {status_code}'
                }
            }
            mock_response.headers = {'Content-Type': 'application/json'}
            mock_response.text = f'Response text for {status_code}'
            
            with patch('requests.post', return_value=mock_response):
                result = connector.analyze_program("TEST_PROGRAM", "IDENTIFICATION DIVISION.")
                
                assert result['success'] == True, f"Status {status_code} deve ser sucesso"
                assert result['status_code'] == status_code, f"Status code deve ser {status_code}"
                print(f"✓ Status {status_code} ({status_text}) tratado corretamente")
        
        print("✅ Teste de tratamento de status HTTP: PASSOU")

def test_luzia_connector_401_handling():
    """Testa tratamento específico de erro 401."""
    print("\n=== TESTE: Tratamento de Erro 401 ===")
    
    # Mock das variáveis de ambiente
    with patch.dict(os.environ, {
        'LUZIA_CLIENT_ID': 'test_client_id',
        'LUZIA_CLIENT_SECRET': 'test_client_secret'
    }):
        connector = LuziaConnector()
        
        call_count = 0
        
        def mock_post(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            
            # Primeira chamada: erro 401
            if call_count == 1:
                mock_response = Mock()
                mock_response.status_code = 401
                mock_response.headers = {'Content-Type': 'application/json'}
                mock_response.text = "Unauthorized - Token expired"
                return mock_response
            
            # Segunda chamada (renovação de token): sucesso
            elif call_count == 2:
                mock_response = Mock()
                mock_response.status_code = 200
                mock_response.headers = {'Content-Type': 'application/json'}
                mock_response.json.return_value = {
                    'access_token': 'renewed_token_67890',
                    'expires_in': 3600
                }
                return mock_response
            
            # Terceira chamada (retry da análise): sucesso
            else:
                mock_response = Mock()
                mock_response.status_code = 200
                mock_response.json.return_value = {
                    'output': {
                        'content': 'Sucesso após renovação de token'
                    }
                }
                mock_response.headers = {'Content-Type': 'application/json'}
                mock_response.text = 'Success response'
                return mock_response
        
        # Simular token inicial (que será rejeitado com 401)
        connector.token = "expired_token"
        connector.token_expires_at = time.time() + 100  # Ainda não expirado pelo tempo
        
        with patch('requests.post', side_effect=mock_post):
            result = connector.analyze_program("TEST_PROGRAM", "IDENTIFICATION DIVISION.")
            
            assert result['success'] == True, "Análise deve ser bem-sucedida após renovação"
            assert connector.token == 'renewed_token_67890', "Token deve ser renovado após erro 401"
            print("✓ Erro 401 tratado com renovação automática de token")
        
        print("✅ Teste de tratamento de erro 401: PASSOU")

def main():
    """Executa todos os testes."""
    print("🔧 COBOL AI Engine v1.4.0 - Teste de Correções no main_detailed.py")
    print("=" * 70)
    
    try:
        test_luzia_connector_token_management()
        test_luzia_connector_token_renewal()
        test_luzia_connector_http_status()
        test_luzia_connector_401_handling()
        
        print("\n" + "=" * 70)
        print("🎉 TODOS OS TESTES DO main_detailed.py PASSARAM!")
        print("✅ Correções validadas com sucesso")
        print("✅ main_detailed.py pronto para uso")
        
    except Exception as e:
        print(f"\n❌ TESTE FALHOU: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()
