# COBOL to Docs v1.1 - Sistema Completo de Análise COBOL

## Visão Geral

O **COBOL to Docs v1.1** é um sistema completo e profissional para análise automatizada de programas COBOL com geração de documentação técnica usando múltiplos provedores de IA.

### Funcionalidades Principais

- ✅ **Análise Individual**: Análise detalhada programa por programa
- ✅ **Análise Consolidada**: Análise sistêmica de todos os programas simultaneamente
- ✅ **Múltiplos Providers**: LuzIA, enhanced_mock, basic, databricks, openai, bedrock
- ✅ **Sistema de Custos**: Controle e relatórios de custos detalhados
- ✅ **Relatórios HTML/PDF**: Geração de documentação profissional
- ✅ **Análise Especializada**: Prompts técnicos especializados
- ✅ **Suporte a Copybooks**: Análise integrada de copybooks COBOL
- ✅ **Multiplataforma**: Funciona em Windows, Linux e macOS

## Instalação

### Requisitos
- Python 3.11+
- Dependências listadas em `requirements.txt`

### Instalação Rápida
```bash
# Clonar ou extrair o projeto
cd cobol_to_docs_v1.1

# Instalar dependências
pip install -r requirements.txt

# Testar instalação
python main.py --status
```

### Instalação via PyPI (Opcional)
```bash
# Instalar como pacote
pip install -e .

# Usar como comando
cobol-to-docs --help
```

## Como Usar

### Análise Individual (Padrão)
```bash
# Análise básica
python main.py --fontes examples/fontes.txt

# Com copybooks
python main.py --fontes examples/fontes.txt --books examples/books.txt

# Com modelo específico
python main.py --fontes examples/fontes.txt --models enhanced_mock
```

### Análise Consolidada (NOVA!)
```bash
# Análise consolidada básica
python main.py --fontes examples/fontes.txt --consolidado

# Análise consolidada completa
python main.py --fontes examples/fontes.txt --books examples/books.txt --consolidado --models enhanced_mock --output sistema_bancario
```

### Análise Especializada
```bash
# Análise técnica profunda
python main.py --fontes examples/fontes.txt --analise-especialista

# Foco na PROCEDURE DIVISION
python main.py --fontes examples/fontes.txt --procedure-detalhada

# Análise de modernização
python main.py --fontes examples/fontes.txt --modernizacao
```

### Relatórios e Documentação
```bash
# Gerar relatórios HTML/PDF
python main.py --fontes examples/fontes.txt --pdf

# Relatório único consolidado
python main.py --fontes examples/fontes.txt --relatorio-unico
```

### Verificação do Sistema
```bash
# Status dos providers
python main.py --status

# Ajuda completa
python main.py --help
```

## Opções Disponíveis

| Opção | Descrição | Exemplo |
|-------|-----------|---------|
| `--fontes` | Arquivo com programas COBOL (obrigatório) | `examples/fontes.txt` |
| `--books` | Arquivo com copybooks COBOL | `examples/books.txt` |
| `--output` | Diretório de saída | `output` |
| `--models` | Modelos de IA a usar | `enhanced_mock` |
| `--consolidado` | **Análise consolidada sistêmica** | - |
| `--analise-especialista` | Análise técnica profunda | - |
| `--procedure-detalhada` | Foco na PROCEDURE DIVISION | - |
| `--modernizacao` | Análise de modernização | - |
| `--relatorio-unico` | Relatório único consolidado | - |
| `--pdf` | Gerar relatórios HTML/PDF | - |
| `--log-level` | Nível de log | `INFO` |
| `--status` | Status dos providers | - |

## Providers Suportados

### LuzIA (Principal)
- Modelo padrão: `aws-claude-3-5-sonnet`
- Requer credenciais: `LUZIA_CLIENT_ID`, `LUZIA_CLIENT_SECRET`
- URLs corrigidas e payload otimizado

### Enhanced Mock
- Modelo de teste avançado
- Sempre disponível
- Ideal para desenvolvimento e testes

### Basic Provider
- Fallback final garantido
- Respostas estruturadas básicas
- Sempre funcional

### Outros Providers
- **Databricks**: Requer `access_token`
- **OpenAI**: Requer instalação da biblioteca `openai`
- **Bedrock**: Requer instalação do `boto3`

## Estrutura do Projeto

```
cobol_to_docs_v1.1/
├── main.py                 # Arquivo principal
├── requirements.txt        # Dependências
├── setup.py               # Configuração PyPI
├── README.md              # Documentação
├── config/                # Configurações
│   ├── config.yaml        # Configuração principal
│   └── prompts_*.yaml     # Prompts especializados
├── src/                   # Código fonte
│   ├── core/              # Núcleo do sistema
│   ├── providers/         # Providers de IA
│   ├── parsers/           # Parsers COBOL
│   ├── analyzers/         # Analisadores
│   ├── generators/        # Geradores de documentação
│   └── utils/             # Utilitários
├── examples/              # Exemplos
│   ├── fontes.txt         # Programas COBOL de exemplo
│   └── books.txt          # Copybooks de exemplo
├── docs/                  # Documentação técnica
├── logs/                  # Logs do sistema
└── tools/                 # Ferramentas auxiliares
```

## Exemplos Práticos

### 1. Análise Rápida do Sistema
```bash
python main.py --fontes sistema.txt --consolidado
```

### 2. Análise Completa para Documentação
```bash
python main.py --fontes sistema.txt --books copybooks.txt --consolidado --pdf --output documentacao_completa
```

### 3. Análise Técnica Especializada
```bash
python main.py --fontes sistema.txt --analise-especialista --procedure-detalhada --modernizacao
```

### 4. Análise com Múltiplos Modelos
```bash
python main.py --fontes sistema.txt --models '["enhanced_mock", "aws-claude-3-5-sonnet"]'
```

### 5. Análise para Auditoria
```bash
python main.py --fontes sistema.txt --consolidado --log-level DEBUG --output auditoria_sistema
```

## Configuração

### Arquivo config.yaml
```yaml
ai:
  primary_provider: "luzia"
  fallback_providers: ["enhanced_mock", "basic"]
  enable_fallback: true
  
  providers:
    luzia:
      enabled: true
      default_model: "aws-claude-3-5-sonnet"
    
    enhanced_mock:
      enabled: true
      default_model: "enhanced-mock-gpt-4"
```

### Variáveis de Ambiente
```bash
# LuzIA
export LUZIA_CLIENT_ID="seu_client_id"
export LUZIA_CLIENT_SECRET="seu_client_secret"

# OpenAI (opcional)
export OPENAI_API_KEY="sua_api_key"

# Databricks (opcional)
export DATABRICKS_ACCESS_TOKEN="seu_token"
```

## Saídas Geradas

### Análise Individual
- `PROGRAMA_analise_funcional.md` - Análise de cada programa
- `relatorio_custos.txt` - Relatório de custos
- `ai_requests/` e `ai_responses/` - Arquivos de auditoria

### Análise Consolidada
- `ANALISE_CONSOLIDADA_SISTEMA_BANCARIO.md` - Análise sistêmica
- `metadados_sistema.json` - Metadados estruturados
- `relatorio_custos_consolidado.txt` - Custos consolidados

### Relatórios HTML/PDF
- `PROGRAMA.html` - Versões HTML dos relatórios
- Conversão automática para PDF (se solicitado)

## Troubleshooting

### Problemas Comuns

**Provider não disponível:**
```bash
python main.py --status  # Verificar status
```

**Erro de credenciais:**
```bash
# Verificar variáveis de ambiente
echo $LUZIA_CLIENT_ID
echo $LUZIA_CLIENT_SECRET
```

**Erro de dependências:**
```bash
pip install -r requirements.txt
```

### Logs e Debugging

Os logs são salvos automaticamente em `logs/`:
```bash
# Ver logs recentes
ls -la logs/

# Debug detalhado
python main.py --fontes examples/fontes.txt --log-level DEBUG
```

## Novidades da v1.1

### Análise Consolidada
- **Nova funcionalidade**: `--consolidado`
- Análise sistêmica de todos os programas simultaneamente
- Visão integrada e abrangente do sistema
- Ideal para especialistas COBOL

### Melhorias Gerais
- LuzIA provider corrigido e otimizado
- Sistema de custos aprimorado
- Documentação técnica completa
- Interface unificada e profissional
- Suporte multiplataforma melhorado

### Correções
- URLs do LuzIA corrigidas
- Payload e headers otimizados
- Logs organizados na pasta correta
- Estrutura de projeto limpa

## Suporte e Contribuição

### Documentação Técnica
- `docs/DOCUMENTACAO_TECNICA.md` - Documentação técnica completa
- `docs/GUIA_COMPLETO_USO.md` - Guia detalhado de uso
- `docs/ANALISE_CONSOLIDADA_GUIA.md` - Guia da análise consolidada

### Licença
Este projeto está licenciado sob os termos especificados no arquivo LICENSE.

### Versão
**v1.1** - Sistema completo com análise consolidada integrada

---

**Desenvolvido por:** Carlos Morais  
**Data:** Setembro 2025  
**Status:** Produção - Totalmente funcional
