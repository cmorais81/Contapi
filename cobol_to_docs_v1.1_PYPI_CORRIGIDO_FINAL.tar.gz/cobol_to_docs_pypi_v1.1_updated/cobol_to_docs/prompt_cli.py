#!/usr/bin/env python3
"""
CLI Gerador de Prompts - COBOL to Docs v1.0 (PyPI Version)
Autor: Carlos Morais

Wrapper que mantém 100% de compatibilidade com generate_prompts.py original
"""

import sys
import os
from pathlib import Path

def main():
    """
    Função principal que importa e executa o generate_prompts.py original
    Mantém 100% de compatibilidade
    """
    
    # Adicionar diretório do pacote ao path
    package_dir = Path(__file__).parent
    sys.path.insert(0, str(package_dir))
    
    # Importar e executar generate_prompts original
    try:
        # Importação relativa
        from .generate_prompts_original import main as main_func
        main_func()
    except ImportError:
        try:
            # Importação absoluta
            from cobol_to_docs.generate_prompts_original import main as main_func
            main_func()
        except ImportError:
            # Fallback direto
            import generate_prompts_original
            generate_prompts_original.main()

if __name__ == "__main__":
    main()
