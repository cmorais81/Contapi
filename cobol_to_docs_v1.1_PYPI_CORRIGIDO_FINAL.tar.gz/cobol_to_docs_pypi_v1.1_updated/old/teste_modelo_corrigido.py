#!/usr/bin/env python3
"""
Teste da correção do modelo aws-claude-3-haiku no sistema COBOL AI Engine
Validar se o erro "Model not found" foi resolvido
"""

import os
import sys
import logging
from pathlib import Path

# Adicionar o diretório src ao path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from providers.luzia_provider import LuziaProvider
from providers.base_provider import AIRequest

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

def test_modelo_corrigido():
    """Testar se o modelo aws-claude-3-haiku funciona corretamente"""
    
    print("=== TESTE DE CORREÇÃO DO MODELO ===")
    print("Testando modelo: aws-claude-3-haiku")
    print()
    
    # Verificar variáveis de ambiente
    client_id = os.getenv('LUZIA_CLIENT_ID')
    client_secret = os.getenv('LUZIA_CLIENT_SECRET')
    
    if not client_id or not client_secret:
        print(" ERRO: Variáveis de ambiente LUZIA_CLIENT_ID e LUZIA_CLIENT_SECRET não configuradas")
        return False
    
    print(f" Client ID configurado: {client_id[:10]}...")
    print(f" Client Secret configurado: {'*' * len(client_secret)}")
    print()
    
    # Configuração do provider
    config = {
        'client_id': client_id,
        'client_secret': client_secret,
        'enabled': True
    }
    
    try:
        # Inicializar provider
        print("📡 Inicializando LuziaProvider...")
        provider = LuziaProvider(config)
        
        # Verificar status
        print(" Verificando status do provider...")
        status = provider.get_status()
        print(f"Status: {status}")
        print()
        
        # Verificar disponibilidade
        print("🔌 Testando disponibilidade...")
        available = provider.is_available()
        print(f"Disponível: {available}")
        
        if not available:
            print(" Provider não está disponível")
            return False
        
        print(" Provider disponível!")
        print()
        
        # Testar análise simples
        print("🧪 Testando análise com modelo corrigido...")
        
        # Prompt de teste simples
        test_prompt = """
Você é um analista de sistemas COBOL especializado.

=== PROGRAMA COBOL PARA ANÁLISE APROFUNDADA ===

       IDENTIFICATION DIVISION.
       PROGRAM-ID. TESTE-SIMPLES.
       
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01 WS-CONTADOR PIC 9(3) VALUE 0.
       
       PROCEDURE DIVISION.
       MAIN-PROCESS.
           DISPLAY 'PROGRAMA DE TESTE'.
           STOP RUN.
"""
        
        request = AIRequest(
            prompt=test_prompt,
            model="aws-claude-3-haiku",
            temperature=0.1,
            max_tokens=1000
        )
        
        print("📤 Enviando requisição...")
        response = provider.analyze(request)
        
        print(f"📥 Resposta recebida:")
        print(f"  - Sucesso: {response.success}")
        print(f"  - Modelo: {response.model}")
        print(f"  - Provider: {response.provider}")
        print(f"  - Tempo: {response.response_time:.2f}s")
        print(f"  - Tokens: {response.tokens_used}")
        
        if response.success:
            print(" TESTE PASSOU! Modelo aws-claude-3-haiku funcionando")
            print()
            print("📄 Conteúdo da resposta:")
            print("-" * 50)
            print(response.content[:500] + "..." if len(response.content) > 500 else response.content)
            print("-" * 50)
            return True
        else:
            print(f" TESTE FALHOU: {response.error_message}")
            return False
            
    except Exception as e:
        print(f" ERRO DURANTE TESTE: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = test_modelo_corrigido()
    
    print()
    print("=== RESULTADO FINAL ===")
    if success:
        print(" CORREÇÃO VALIDADA: Modelo aws-claude-3-haiku funcionando corretamente")
        print(" O erro 'Model not found' foi resolvido!")
    else:
        print(" CORREÇÃO FALHOU: Ainda há problemas com o modelo")
        print(" Verificar logs acima para detalhes do erro")
    
    sys.exit(0 if success else 1)
