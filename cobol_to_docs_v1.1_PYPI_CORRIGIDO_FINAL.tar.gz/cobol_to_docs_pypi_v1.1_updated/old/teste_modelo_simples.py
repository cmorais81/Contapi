#!/usr/bin/env python3
"""
Teste simplificado da correção do modelo aws-claude-3-haiku
Teste direto do provider sem dependências complexas
"""

import os
import json
import logging
import time
import warnings
import requests
from datetime import datetime
from urllib3.exceptions import InsecureRequestWarning

# Suprimir warnings de SSL
warnings.filterwarnings('ignore', message='Unverified HTTPS request')
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger('TesteModelo')

def test_modelo_aws_claude_haiku():
    """Teste direto do modelo aws-claude-3-haiku"""
    
    print("=== TESTE DIRETO DO MODELO aws-claude-3.7 ===")
    print()
    
    # Verificar credenciais
    client_id = os.getenv('LUZIA_CLIENT_ID')
    client_secret = os.getenv('LUZIA_CLIENT_SECRET')
    
    if not client_id or not client_secret:
        print(" ERRO: Variáveis de ambiente não configuradas")
        print("Configure LUZIA_CLIENT_ID e LUZIA_CLIENT_SECRET")
        return False
    
    print(f" Client ID: {client_id[:10]}...")
    print(f" Client Secret: configurado")
    print()
    
    # URLs da API
    auth_url = "https://login.azure.paas.santanderbr.pre.corp/auth/realms/corp/protocol/openid-connect/token"
    api_url = "https://gut-api-aws.santanderbr.dev.corp/genai_services/v1/pipelines/submit"
    
    try:
        # 1. Obter token
        print("🔑 Obtendo token OAuth2...")
        
        auth_payload = {
            "grant_type": "client_credentials",
            "client_id": client_id,
            "client_secret": client_secret
        }
        
        auth_headers = {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Accept': '*/*'
        }
        
        auth_response = requests.post(
            auth_url,
            headers=auth_headers,
            data=auth_payload,
            verify=False,
            timeout=120
        )
        
        if auth_response.status_code != 200:
            print(f" Erro na autenticação: {auth_response.status_code}")
            print(f"Resposta: {auth_response.text}")
            return False
        
        token_data = auth_response.json()
        access_token = token_data.get('access_token')
        
        if not access_token:
            print(" Token não encontrado na resposta")
            return False
        
        print(f" Token obtido: {access_token[:20]}...")
        print()
        
        # 2. Testar requisição com modelo aws-claude-3.7
        print("🧪 Testando modelo aws-claude-3.7...")
        
        # Payload com modelo corrigido
        payload = {
            "input": {
                "query": [
                    {
                        "role": "system",
                        "content": "Você é um analista de sistemas COBOL. Responda em português."
                    },
                    {
                        "role": "user", 
                        "content": "Analise este programa COBOL simples:\n\nIDENTIFICATION DIVISION.\nPROGRAM-ID. TESTE.\nPROCEDURE DIVISION.\nDISPLAY 'HELLO WORLD'.\nSTOP RUN."
                    }
                ]
            },
            "config": [
                {
                    "type": "catena.llm.LLMRouter",
                    "obj_kwargs": {
                        "routing_model": "aws-claude-3.7",  # MODELO ATUALIZADO
                        "temperature": 0.1,
                        "system_prompt": "Responda apenas em português"
                    }
                }
            ]
        }
        
        headers = {
            "X-santander-client-id": client_id,
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json"
        }
        
        print("📤 Enviando requisição...")
        print(f"Modelo: aws-claude-3.7")
        print(f"URL: {api_url}")
        
        start_time = time.time()
        
        response = requests.post(
            url=api_url,
            json=payload,
            headers=headers,
            verify=False,
            timeout=120
        )
        
        response_time = time.time() - start_time
        
        print(f"📥 Resposta recebida em {response_time:.2f}s")
        print(f"Status: {response.status_code}")
        
        if response.status_code in [200, 201]:
            print(f" SUCESSO! Modelo aws-claude-3.7 funcionando (HTTP {response.status_code})")
            
            try:
                response_data = response.json()
                print()
                print("📄 Resposta da API:")
                print(json.dumps(response_data, indent=2, ensure_ascii=False)[:1000])
                
                # Extrair conteúdo baseado na estrutura real da API (conforme imagem)
                content = ""
                if 'output' in response_data:
                    output = response_data['output']
                    if isinstance(output, dict) and 'content' in output:
                        content = output['content']
                    elif isinstance(output, str):
                        content = output
                    else:
                        content = str(output)
                elif 'result' in response_data:
                    content = response_data['result']
                else:
                    content = str(response_data)
                
                if content:
                    print()
                    print("💬 Conteúdo da análise:")
                    print("-" * 50)
                    print(content[:500] + "..." if len(content) > 500 else content)
                    print("-" * 50)
                else:
                    print()
                    print("  Conteúdo não encontrado na resposta")
                    print("Estrutura da resposta:")
                    print(list(response_data.keys()) if isinstance(response_data, dict) else type(response_data))
                
            except Exception as e:
                print(f"  Erro ao processar resposta JSON: {e}")
                print(f"Resposta raw: {response.text[:500]}")
            
            return True
            
        else:
            print(f" ERRO HTTP {response.status_code}")
            print(f"Resposta: {response.text}")
            
            # Verificar se é erro de modelo não encontrado
            if "model" in response.text.lower() and "not found" in response.text.lower():
                print(" ERRO IDENTIFICADO: Modelo não encontrado")
                print("Possíveis causas:")
                print("- Nome do modelo incorreto")
                print("- Modelo não disponível na região")
                print("- Permissões insuficientes")
            
            return False
            
    except requests.exceptions.Timeout:
        print(" Timeout na requisição")
        return False
    except Exception as e:
        print(f" Erro durante teste: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = test_modelo_aws_claude_haiku()
    
    print()
    print("=== RESULTADO FINAL ===")
    if success:
        print(" CORREÇÃO VALIDADA!")
        print(" Modelo aws-claude-3.7 funcionando corretamente")
        print(" Erro 'Model not found' resolvido")
    else:
        print(" CORREÇÃO AINDA NECESSÁRIA")
        print(" Modelo aws-claude-3.7 ainda apresenta problemas")
    
    print()
    exit(0 if success else 1)
