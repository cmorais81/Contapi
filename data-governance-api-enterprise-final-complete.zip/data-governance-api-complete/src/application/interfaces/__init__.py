"""
Application Layer Interfaces.
Following Dependency Inversion Principle (DIP) from SOLID.

These interfaces define contracts for external services and infrastructure,
allowing the application layer to remain independent of implementation details.

Author: Carlos Morais
"""

from abc import ABC, abstractmethod
from datetime import datetime
from typing import Any, Dict, List, Optional, Union
from uuid import UUID

from ..dtos import (
    DataObjectResponseDTO, DataLineageResponseDTO, AccessPolicyResponseDTO,
    QualityMetricResponseDTO, SearchRequestDTO, PaginatedResponseDTO,
    LineageGraphDTO, QualitySummaryDTO, AnalyticsSummaryDTO, SyncResultDTO,
    HealthCheckDTO
)


class ILogger(ABC):
    """Interface for logging service."""
    
    @abstractmethod
    async def debug(self, message: str, **kwargs) -> None:
        """Log debug message."""
        pass
    
    @abstractmethod
    async def info(self, message: str, **kwargs) -> None:
        """Log info message."""
        pass
    
    @abstractmethod
    async def warning(self, message: str, **kwargs) -> None:
        """Log warning message."""
        pass
    
    @abstractmethod
    async def error(self, message: str, **kwargs) -> None:
        """Log error message."""
        pass
    
    @abstractmethod
    async def critical(self, message: str, **kwargs) -> None:
        """Log critical message."""
        pass


class IEventPublisher(ABC):
    """Interface for event publishing service."""
    
    @abstractmethod
    async def publish(self, event_type: str, event_data: Dict[str, Any], **kwargs) -> str:
        """Publish an event and return event ID."""
        pass
    
    @abstractmethod
    async def publish_batch(self, events: List[Dict[str, Any]], **kwargs) -> List[str]:
        """Publish multiple events and return event IDs."""
        pass


class INotificationService(ABC):
    """Interface for notification service."""
    
    @abstractmethod
    async def send_email(
        self,
        to: Union[str, List[str]],
        subject: str,
        body: str,
        html_body: Optional[str] = None,
        **kwargs
    ) -> str:
        """Send email notification and return notification ID."""
        pass
    
    @abstractmethod
    async def send_slack(
        self,
        channel: str,
        message: str,
        **kwargs
    ) -> str:
        """Send Slack notification and return notification ID."""
        pass
    
    @abstractmethod
    async def send_webhook(
        self,
        url: str,
        payload: Dict[str, Any],
        **kwargs
    ) -> str:
        """Send webhook notification and return notification ID."""
        pass


class IMetricsCollector(ABC):
    """Interface for metrics collection service."""
    
    @abstractmethod
    async def increment_counter(self, name: str, value: int = 1, tags: Optional[Dict[str, str]] = None) -> None:
        """Increment a counter metric."""
        pass
    
    @abstractmethod
    async def record_gauge(self, name: str, value: float, tags: Optional[Dict[str, str]] = None) -> None:
        """Record a gauge metric."""
        pass
    
    @abstractmethod
    async def record_histogram(self, name: str, value: float, tags: Optional[Dict[str, str]] = None) -> None:
        """Record a histogram metric."""
        pass
    
    @abstractmethod
    async def record_timing(self, name: str, duration_ms: float, tags: Optional[Dict[str, str]] = None) -> None:
        """Record a timing metric."""
        pass


class ICacheService(ABC):
    """Interface for caching service."""
    
    @abstractmethod
    async def get(self, key: str) -> Optional[Any]:
        """Get value from cache."""
        pass
    
    @abstractmethod
    async def set(self, key: str, value: Any, ttl: Optional[int] = None) -> None:
        """Set value in cache with optional TTL."""
        pass
    
    @abstractmethod
    async def delete(self, key: str) -> None:
        """Delete value from cache."""
        pass
    
    @abstractmethod
    async def exists(self, key: str) -> bool:
        """Check if key exists in cache."""
        pass
    
    @abstractmethod
    async def clear(self, pattern: Optional[str] = None) -> None:
        """Clear cache entries matching pattern."""
        pass


class IHealthChecker(ABC):
    """Interface for health checking service."""
    
    @abstractmethod
    async def check_database(self) -> Dict[str, Any]:
        """Check database health."""
        pass
    
    @abstractmethod
    async def check_external_service(self, service_name: str) -> Dict[str, Any]:
        """Check external service health."""
        pass
    
    @abstractmethod
    async def check_cache(self) -> Dict[str, Any]:
        """Check cache health."""
        pass
    
    @abstractmethod
    async def get_overall_health(self) -> HealthCheckDTO:
        """Get overall system health."""
        pass


class ISecurityService(ABC):
    """Interface for security service."""
    
    @abstractmethod
    async def hash_password(self, password: str) -> str:
        """Hash a password."""
        pass
    
    @abstractmethod
    async def verify_password(self, password: str, hashed: str) -> bool:
        """Verify a password against hash."""
        pass
    
    @abstractmethod
    async def create_access_token(self, data: Dict[str, Any], expires_delta: Optional[int] = None) -> str:
        """Create access token."""
        pass
    
    @abstractmethod
    async def verify_token(self, token: str) -> Dict[str, Any]:
        """Verify and decode token."""
        pass
    
    @abstractmethod
    async def encrypt_sensitive_data(self, data: str) -> str:
        """Encrypt sensitive data."""
        pass
    
    @abstractmethod
    async def decrypt_sensitive_data(self, encrypted_data: str) -> str:
        """Decrypt sensitive data."""
        pass


class IDataQualityEngine(ABC):
    """Interface for data quality engine."""
    
    @abstractmethod
    async def run_quality_checks(self, object_id: UUID, rules: List[Dict[str, Any]]) -> List[QualityMetricResponseDTO]:
        """Run quality checks on a data object."""
        pass
    
    @abstractmethod
    async def calculate_quality_score(self, object_id: UUID) -> float:
        """Calculate overall quality score for an object."""
        pass
    
    @abstractmethod
    async def get_quality_trends(self, object_id: UUID, days: int = 30) -> Dict[str, List[float]]:
        """Get quality trends for an object."""
        pass
    
    @abstractmethod
    async def suggest_quality_rules(self, object_id: UUID) -> List[Dict[str, Any]]:
        """Suggest quality rules based on data profiling."""
        pass


class ILineageDiscoveryEngine(ABC):
    """Interface for lineage discovery engine."""
    
    @abstractmethod
    async def discover_lineage_from_logs(self, job_id: Optional[str] = None) -> List[DataLineageResponseDTO]:
        """Discover lineage from execution logs."""
        pass
    
    @abstractmethod
    async def discover_lineage_from_sql(self, sql_query: str) -> List[DataLineageResponseDTO]:
        """Discover lineage from SQL query."""
        pass
    
    @abstractmethod
    async def build_lineage_graph(self, object_id: UUID, max_depth: int = 3) -> LineageGraphDTO:
        """Build lineage graph for an object."""
        pass
    
    @abstractmethod
    async def calculate_impact_analysis(self, object_id: UUID) -> Dict[str, Any]:
        """Calculate impact analysis for changes to an object."""
        pass


class IUnityCatalogClient(ABC):
    """Interface for Unity Catalog client."""
    
    @abstractmethod
    async def list_catalogs(self) -> List[Dict[str, Any]]:
        """List all catalogs."""
        pass
    
    @abstractmethod
    async def list_schemas(self, catalog_name: str) -> List[Dict[str, Any]]:
        """List schemas in a catalog."""
        pass
    
    @abstractmethod
    async def list_tables(self, catalog_name: str, schema_name: str) -> List[Dict[str, Any]]:
        """List tables in a schema."""
        pass
    
    @abstractmethod
    async def get_table_info(self, catalog_name: str, schema_name: str, table_name: str) -> Dict[str, Any]:
        """Get detailed table information."""
        pass
    
    @abstractmethod
    async def get_table_lineage(self, catalog_name: str, schema_name: str, table_name: str) -> List[Dict[str, Any]]:
        """Get table lineage information."""
        pass
    
    @abstractmethod
    async def sync_metadata(self, catalogs: Optional[List[str]] = None) -> SyncResultDTO:
        """Sync metadata from Unity Catalog."""
        pass


class IDatabricksJobsClient(ABC):
    """Interface for Databricks Jobs client."""
    
    @abstractmethod
    async def list_jobs(self) -> List[Dict[str, Any]]:
        """List all jobs."""
        pass
    
    @abstractmethod
    async def get_job_runs(self, job_id: str, limit: int = 100) -> List[Dict[str, Any]]:
        """Get job runs for a specific job."""
        pass
    
    @abstractmethod
    async def get_job_metrics(self, job_id: str) -> Dict[str, Any]:
        """Get job metrics and statistics."""
        pass
    
    @abstractmethod
    async def get_cluster_metrics(self, cluster_id: str) -> Dict[str, Any]:
        """Get cluster metrics and statistics."""
        pass


class IPolicyEngine(ABC):
    """Interface for policy engine."""
    
    @abstractmethod
    async def evaluate_policy(self, policy_id: UUID, context: Dict[str, Any]) -> Dict[str, Any]:
        """Evaluate a policy against a context."""
        pass
    
    @abstractmethod
    async def test_policy(self, policy_definition: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
        """Test a policy definition against a context."""
        pass
    
    @abstractmethod
    async def apply_data_masking(self, object_id: UUID, data: Any, user_context: Dict[str, Any]) -> Any:
        """Apply data masking based on policies."""
        pass
    
    @abstractmethod
    async def check_access_permissions(self, object_id: UUID, user_context: Dict[str, Any]) -> bool:
        """Check if user has access to an object."""
        pass


class IAnalyticsEngine(ABC):
    """Interface for analytics engine."""
    
    @abstractmethod
    async def calculate_usage_statistics(self, object_id: Optional[UUID] = None) -> Dict[str, Any]:
        """Calculate usage statistics."""
        pass
    
    @abstractmethod
    async def get_popular_objects(self, limit: int = 10) -> List[Dict[str, Any]]:
        """Get most popular data objects."""
        pass
    
    @abstractmethod
    async def get_cost_analysis(self, time_period: str = "30d") -> Dict[str, Any]:
        """Get cost analysis for data operations."""
        pass
    
    @abstractmethod
    async def generate_insights(self) -> List[Dict[str, Any]]:
        """Generate data governance insights."""
        pass
    
    @abstractmethod
    async def get_compliance_report(self, framework: str) -> Dict[str, Any]:
        """Generate compliance report for a framework."""
        pass


class ISearchEngine(ABC):
    """Interface for search engine."""
    
    @abstractmethod
    async def index_object(self, object_data: Dict[str, Any]) -> None:
        """Index a data object for search."""
        pass
    
    @abstractmethod
    async def remove_from_index(self, object_id: UUID) -> None:
        """Remove object from search index."""
        pass
    
    @abstractmethod
    async def search_objects(self, search_request: SearchRequestDTO) -> PaginatedResponseDTO:
        """Search for data objects."""
        pass
    
    @abstractmethod
    async def suggest_completions(self, query: str, limit: int = 10) -> List[str]:
        """Suggest query completions."""
        pass
    
    @abstractmethod
    async def get_facets(self, query: Optional[str] = None) -> Dict[str, List[Dict[str, Any]]]:
        """Get search facets for filtering."""
        pass


class IWorkflowEngine(ABC):
    """Interface for workflow engine."""
    
    @abstractmethod
    async def start_workflow(self, workflow_type: str, parameters: Dict[str, Any]) -> str:
        """Start a workflow and return workflow ID."""
        pass
    
    @abstractmethod
    async def get_workflow_status(self, workflow_id: str) -> Dict[str, Any]:
        """Get workflow status."""
        pass
    
    @abstractmethod
    async def cancel_workflow(self, workflow_id: str) -> None:
        """Cancel a running workflow."""
        pass
    
    @abstractmethod
    async def schedule_workflow(self, workflow_type: str, cron_expression: str, parameters: Dict[str, Any]) -> str:
        """Schedule a recurring workflow."""
        pass


class IAlertingService(ABC):
    """Interface for alerting service."""
    
    @abstractmethod
    async def create_alert(self, alert_type: str, severity: str, message: str, metadata: Dict[str, Any]) -> str:
        """Create an alert and return alert ID."""
        pass
    
    @abstractmethod
    async def resolve_alert(self, alert_id: str, resolution_note: Optional[str] = None) -> None:
        """Resolve an alert."""
        pass
    
    @abstractmethod
    async def get_active_alerts(self, filters: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """Get active alerts with optional filters."""
        pass
    
    @abstractmethod
    async def configure_alert_rules(self, rules: List[Dict[str, Any]]) -> None:
        """Configure alert rules."""
        pass


class IDataCatalogClient(ABC):
    """Interface for external data catalog client."""
    
    @abstractmethod
    async def sync_to_catalog(self, objects: List[DataObjectResponseDTO]) -> SyncResultDTO:
        """Sync objects to external catalog."""
        pass
    
    @abstractmethod
    async def sync_from_catalog(self, catalog_filters: Optional[Dict[str, Any]] = None) -> SyncResultDTO:
        """Sync objects from external catalog."""
        pass
    
    @abstractmethod
    async def enrich_metadata(self, object_id: UUID) -> Dict[str, Any]:
        """Enrich object metadata from external catalog."""
        pass


class IMLModelRegistry(ABC):
    """Interface for ML model registry."""
    
    @abstractmethod
    async def register_model_lineage(self, model_id: str, training_data: List[UUID]) -> None:
        """Register lineage between model and training data."""
        pass
    
    @abstractmethod
    async def get_model_dependencies(self, model_id: str) -> List[UUID]:
        """Get data dependencies for a model."""
        pass
    
    @abstractmethod
    async def track_model_usage(self, model_id: str, inference_data: List[UUID]) -> None:
        """Track model usage with inference data."""
        pass


class IDataProfiler(ABC):
    """Interface for data profiling service."""
    
    @abstractmethod
    async def profile_object(self, object_id: UUID) -> Dict[str, Any]:
        """Profile a data object and return statistics."""
        pass
    
    @abstractmethod
    async def detect_schema_changes(self, object_id: UUID) -> List[Dict[str, Any]]:
        """Detect schema changes in a data object."""
        pass
    
    @abstractmethod
    async def identify_sensitive_columns(self, object_id: UUID) -> List[str]:
        """Identify potentially sensitive columns."""
        pass
    
    @abstractmethod
    async def calculate_data_drift(self, object_id: UUID, baseline_date: datetime) -> Dict[str, Any]:
        """Calculate data drift compared to baseline."""
        pass


# Service locator interface for dependency injection
class IServiceLocator(ABC):
    """Interface for service locator pattern."""
    
    @abstractmethod
    def get_logger(self) -> ILogger:
        """Get logger service."""
        pass
    
    @abstractmethod
    def get_event_publisher(self) -> IEventPublisher:
        """Get event publisher service."""
        pass
    
    @abstractmethod
    def get_notification_service(self) -> INotificationService:
        """Get notification service."""
        pass
    
    @abstractmethod
    def get_metrics_collector(self) -> IMetricsCollector:
        """Get metrics collector service."""
        pass
    
    @abstractmethod
    def get_cache_service(self) -> ICacheService:
        """Get cache service."""
        pass
    
    @abstractmethod
    def get_health_checker(self) -> IHealthChecker:
        """Get health checker service."""
        pass
    
    @abstractmethod
    def get_security_service(self) -> ISecurityService:
        """Get security service."""
        pass
    
    @abstractmethod
    def get_data_quality_engine(self) -> IDataQualityEngine:
        """Get data quality engine."""
        pass
    
    @abstractmethod
    def get_lineage_discovery_engine(self) -> ILineageDiscoveryEngine:
        """Get lineage discovery engine."""
        pass
    
    @abstractmethod
    def get_unity_catalog_client(self) -> IUnityCatalogClient:
        """Get Unity Catalog client."""
        pass
    
    @abstractmethod
    def get_databricks_jobs_client(self) -> IDatabricksJobsClient:
        """Get Databricks Jobs client."""
        pass
    
    @abstractmethod
    def get_policy_engine(self) -> IPolicyEngine:
        """Get policy engine."""
        pass
    
    @abstractmethod
    def get_analytics_engine(self) -> IAnalyticsEngine:
        """Get analytics engine."""
        pass
    
    @abstractmethod
    def get_search_engine(self) -> ISearchEngine:
        """Get search engine."""
        pass
    
    @abstractmethod
    def get_workflow_engine(self) -> IWorkflowEngine:
        """Get workflow engine."""
        pass
    
    @abstractmethod
    def get_alerting_service(self) -> IAlertingService:
        """Get alerting service."""
        pass
    
    @abstractmethod
    def get_data_catalog_client(self) -> IDataCatalogClient:
        """Get data catalog client."""
        pass
    
    @abstractmethod
    def get_ml_model_registry(self) -> IMLModelRegistry:
        """Get ML model registry."""
        pass
    
    @abstractmethod
    def get_data_profiler(self) -> IDataProfiler:
        """Get data profiler."""
        pass

