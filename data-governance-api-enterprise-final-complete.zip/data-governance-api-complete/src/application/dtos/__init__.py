"""
Data Transfer Objects (DTOs) for Application Layer.
Following Clean Architecture principles for data transfer between layers.

Author: Carlos Morais
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List, Optional, Any, Set, Union
from uuid import UUID

from ..domain.value_objects import (
    SecurityClassification, ObjectType, DataFormat,
    QualityDimension, LineageType, PolicyType
)


class BaseDTO(ABC):
    """Base class for all DTOs."""
    
    @abstractmethod
    def validate(self) -> None:
        """Validate DTO data."""
        pass
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert DTO to dictionary."""
        result = {}
        for key, value in self.__dict__.items():
            if isinstance(value, Enum):
                result[key] = value.value
            elif isinstance(value, (list, set)):
                result[key] = list(value)
            elif isinstance(value, datetime):
                result[key] = value.isoformat()
            elif isinstance(value, UUID):
                result[key] = str(value)
            else:
                result[key] = value
        return result


@dataclass
class DataObjectPropertyDTO(BaseDTO):
    """DTO for Data Object Property."""
    name: str
    data_type: str
    is_nullable: bool = True
    is_primary_key: bool = False
    is_foreign_key: bool = False
    description: Optional[str] = None
    default_value: Optional[str] = None
    constraints: List[str] = field(default_factory=list)
    tags: Set[str] = field(default_factory=set)
    security_classification: Optional[str] = None
    
    def validate(self) -> None:
        """Validate property DTO."""
        if not self.name or not self.name.strip():
            raise ValueError("Property name is required")
        if not self.data_type or not self.data_type.strip():
            raise ValueError("Property data type is required")
        
        # Validate security classification if provided
        if self.security_classification:
            try:
                SecurityClassification(self.security_classification)
            except ValueError:
                raise ValueError(f"Invalid security classification: {self.security_classification}")


@dataclass
class DataObjectCreateDTO(BaseDTO):
    """DTO for creating a Data Object."""
    object_name: str
    object_type: str
    catalog_name: str
    schema_name: str
    object_owner: str
    description: Optional[str] = None
    location: Optional[str] = None
    format: Optional[str] = None
    size_bytes: Optional[int] = None
    row_count: Optional[int] = None
    tags: Set[str] = field(default_factory=set)
    security_classification: str = "internal"
    retention_policy: Optional[str] = None
    business_owner: Optional[str] = None
    steward: Optional[str] = None
    properties: List[DataObjectPropertyDTO] = field(default_factory=list)
    
    def validate(self) -> None:
        """Validate create DTO."""
        # Required fields
        if not self.object_name or not self.object_name.strip():
            raise ValueError("Object name is required")
        if not self.object_type or not self.object_type.strip():
            raise ValueError("Object type is required")
        if not self.catalog_name or not self.catalog_name.strip():
            raise ValueError("Catalog name is required")
        if not self.schema_name or not self.schema_name.strip():
            raise ValueError("Schema name is required")
        if not self.object_owner or not self.object_owner.strip():
            raise ValueError("Object owner is required")
        
        # Validate enums
        try:
            ObjectType(self.object_type)
        except ValueError:
            raise ValueError(f"Invalid object type: {self.object_type}")
        
        try:
            SecurityClassification(self.security_classification)
        except ValueError:
            raise ValueError(f"Invalid security classification: {self.security_classification}")
        
        if self.format:
            try:
                DataFormat(self.format)
            except ValueError:
                raise ValueError(f"Invalid data format: {self.format}")
        
        # Validate numeric fields
        if self.size_bytes is not None and self.size_bytes < 0:
            raise ValueError("Size bytes cannot be negative")
        if self.row_count is not None and self.row_count < 0:
            raise ValueError("Row count cannot be negative")
        
        # Validate properties
        for prop in self.properties:
            prop.validate()
        
        # Check for duplicate property names
        property_names = [prop.name.lower() for prop in self.properties]
        if len(property_names) != len(set(property_names)):
            raise ValueError("Duplicate property names are not allowed")


@dataclass
class DataObjectUpdateDTO(BaseDTO):
    """DTO for updating a Data Object."""
    description: Optional[str] = None
    location: Optional[str] = None
    format: Optional[str] = None
    size_bytes: Optional[int] = None
    row_count: Optional[int] = None
    tags: Optional[Set[str]] = None
    security_classification: Optional[str] = None
    retention_policy: Optional[str] = None
    business_owner: Optional[str] = None
    steward: Optional[str] = None
    
    def validate(self) -> None:
        """Validate update DTO."""
        # Validate enums if provided
        if self.security_classification:
            try:
                SecurityClassification(self.security_classification)
            except ValueError:
                raise ValueError(f"Invalid security classification: {self.security_classification}")
        
        if self.format:
            try:
                DataFormat(self.format)
            except ValueError:
                raise ValueError(f"Invalid data format: {self.format}")
        
        # Validate numeric fields
        if self.size_bytes is not None and self.size_bytes < 0:
            raise ValueError("Size bytes cannot be negative")
        if self.row_count is not None and self.row_count < 0:
            raise ValueError("Row count cannot be negative")


@dataclass
class DataObjectResponseDTO(BaseDTO):
    """DTO for Data Object response."""
    object_id: str
    object_name: str
    object_type: str
    catalog_name: str
    schema_name: str
    full_name: str
    object_owner: str
    description: Optional[str] = None
    location: Optional[str] = None
    format: Optional[str] = None
    size_bytes: Optional[int] = None
    row_count: Optional[int] = None
    column_count: int = 0
    is_active: bool = True
    tags: Set[str] = field(default_factory=set)
    security_classification: str = "internal"
    retention_policy: Optional[str] = None
    business_owner: Optional[str] = None
    steward: Optional[str] = None
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    version: int = 1
    quality_score: Optional[float] = None
    properties: List[DataObjectPropertyDTO] = field(default_factory=list)
    
    def validate(self) -> None:
        """Validate response DTO."""
        # Basic validation for response DTOs
        if not self.object_id:
            raise ValueError("Object ID is required")
        if not self.object_name:
            raise ValueError("Object name is required")


@dataclass
class DataLineageCreateDTO(BaseDTO):
    """DTO for creating Data Lineage."""
    source_object_id: str
    target_object_id: str
    lineage_type: str
    transformation_logic: Optional[str] = None
    job_id: Optional[str] = None
    job_name: Optional[str] = None
    confidence_score: float = 1.0
    discovered_by: str = "manual"
    
    def validate(self) -> None:
        """Validate lineage create DTO."""
        if not self.source_object_id:
            raise ValueError("Source object ID is required")
        if not self.target_object_id:
            raise ValueError("Target object ID is required")
        if self.source_object_id == self.target_object_id:
            raise ValueError("Source and target objects cannot be the same")
        if not self.lineage_type:
            raise ValueError("Lineage type is required")
        
        # Validate lineage type
        try:
            LineageType(self.lineage_type)
        except ValueError:
            raise ValueError(f"Invalid lineage type: {self.lineage_type}")
        
        # Validate confidence score
        if not (0 <= self.confidence_score <= 1):
            raise ValueError("Confidence score must be between 0 and 1")


@dataclass
class DataLineageResponseDTO(BaseDTO):
    """DTO for Data Lineage response."""
    lineage_id: str
    source_object_id: str
    target_object_id: str
    lineage_type: str
    transformation_logic: Optional[str] = None
    job_id: Optional[str] = None
    job_name: Optional[str] = None
    confidence_score: float = 1.0
    discovered_by: str = "manual"
    is_active: bool = True
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    
    def validate(self) -> None:
        """Validate lineage response DTO."""
        if not self.lineage_id:
            raise ValueError("Lineage ID is required")


@dataclass
class AccessPolicyCreateDTO(BaseDTO):
    """DTO for creating Access Policy."""
    policy_name: str
    policy_type: str
    policy_scope: str
    conditions: Dict[str, Any]
    actions: Dict[str, Any]
    priority: int = 100
    description: Optional[str] = None
    compliance_frameworks: List[str] = field(default_factory=list)
    object_id: Optional[str] = None
    created_by: Optional[str] = None
    
    def validate(self) -> None:
        """Validate policy create DTO."""
        if not self.policy_name or not self.policy_name.strip():
            raise ValueError("Policy name is required")
        if not self.policy_type or not self.policy_type.strip():
            raise ValueError("Policy type is required")
        if not self.policy_scope or not self.policy_scope.strip():
            raise ValueError("Policy scope is required")
        if not self.conditions:
            raise ValueError("Policy conditions are required")
        if not self.actions:
            raise ValueError("Policy actions are required")
        
        # Validate policy type
        try:
            PolicyType(self.policy_type)
        except ValueError:
            raise ValueError(f"Invalid policy type: {self.policy_type}")
        
        # Validate priority
        if not (1 <= self.priority <= 1000):
            raise ValueError("Priority must be between 1 and 1000")


@dataclass
class AccessPolicyResponseDTO(BaseDTO):
    """DTO for Access Policy response."""
    policy_id: str
    policy_name: str
    policy_type: str
    policy_scope: str
    conditions: Dict[str, Any]
    actions: Dict[str, Any]
    priority: int = 100
    description: Optional[str] = None
    compliance_frameworks: List[str] = field(default_factory=list)
    object_id: Optional[str] = None
    created_by: Optional[str] = None
    is_active: bool = True
    is_enforced: bool = True
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    
    def validate(self) -> None:
        """Validate policy response DTO."""
        if not self.policy_id:
            raise ValueError("Policy ID is required")


@dataclass
class QualityMetricCreateDTO(BaseDTO):
    """DTO for creating Quality Metric."""
    object_id: str
    dimension: str
    metric_value: float
    rule_name: Optional[str] = None
    rule_definition: Optional[str] = None
    threshold_value: Optional[float] = None
    measurement_timestamp: Optional[datetime] = None
    
    def validate(self) -> None:
        """Validate quality metric create DTO."""
        if not self.object_id:
            raise ValueError("Object ID is required")
        if not self.dimension:
            raise ValueError("Quality dimension is required")
        
        # Validate dimension
        try:
            QualityDimension(self.dimension)
        except ValueError:
            raise ValueError(f"Invalid quality dimension: {self.dimension}")
        
        # Validate metric value
        if not (0 <= self.metric_value <= 100):
            raise ValueError("Metric value must be between 0 and 100")
        
        # Validate threshold if provided
        if self.threshold_value is not None and not (0 <= self.threshold_value <= 100):
            raise ValueError("Threshold value must be between 0 and 100")


@dataclass
class QualityMetricResponseDTO(BaseDTO):
    """DTO for Quality Metric response."""
    metric_id: str
    object_id: str
    dimension: str
    metric_value: float
    rule_name: Optional[str] = None
    rule_definition: Optional[str] = None
    threshold_value: Optional[float] = None
    is_passing: bool = True
    measurement_timestamp: datetime = field(default_factory=datetime.utcnow)
    created_at: datetime = field(default_factory=datetime.utcnow)
    
    def validate(self) -> None:
        """Validate quality metric response DTO."""
        if not self.metric_id:
            raise ValueError("Metric ID is required")


@dataclass
class SearchRequestDTO(BaseDTO):
    """DTO for search requests."""
    query: Optional[str] = None
    filters: Optional[Dict[str, Any]] = None
    page: int = 1
    limit: int = 20
    sort_by: Optional[str] = None
    sort_order: str = "asc"
    
    def validate(self) -> None:
        """Validate search request DTO."""
        if self.page < 1:
            raise ValueError("Page must be greater than 0")
        if not (1 <= self.limit <= 100):
            raise ValueError("Limit must be between 1 and 100")
        if self.sort_order not in ["asc", "desc"]:
            raise ValueError("Sort order must be 'asc' or 'desc'")


@dataclass
class PaginatedResponseDTO(BaseDTO):
    """DTO for paginated responses."""
    items: List[Any]
    total: int
    page: int
    size: int
    pages: int
    has_next: bool
    has_prev: bool
    
    def validate(self) -> None:
        """Validate paginated response DTO."""
        if self.total < 0:
            raise ValueError("Total cannot be negative")
        if self.page < 1:
            raise ValueError("Page must be greater than 0")
        if self.size < 1:
            raise ValueError("Size must be greater than 0")


@dataclass
class LineageGraphDTO(BaseDTO):
    """DTO for lineage graph response."""
    nodes: List[Dict[str, Any]]
    edges: List[Dict[str, Any]]
    metadata: Dict[str, Any]
    
    def validate(self) -> None:
        """Validate lineage graph DTO."""
        if not isinstance(self.nodes, list):
            raise ValueError("Nodes must be a list")
        if not isinstance(self.edges, list):
            raise ValueError("Edges must be a list")


@dataclass
class QualitySummaryDTO(BaseDTO):
    """DTO for quality summary response."""
    object_id: str
    overall_score: float
    dimensions: Dict[str, float]
    total_metrics: int
    passing_metrics: int
    failing_metrics: int
    last_assessment: datetime
    trend: str  # "improving", "stable", "declining"
    
    def validate(self) -> None:
        """Validate quality summary DTO."""
        if not self.object_id:
            raise ValueError("Object ID is required")
        if not (0 <= self.overall_score <= 100):
            raise ValueError("Overall score must be between 0 and 100")
        if self.trend not in ["improving", "stable", "declining"]:
            raise ValueError("Trend must be 'improving', 'stable', or 'declining'")


@dataclass
class AnalyticsSummaryDTO(BaseDTO):
    """DTO for analytics summary response."""
    total_objects: int
    objects_by_type: Dict[str, int]
    objects_by_classification: Dict[str, int]
    total_lineage_relationships: int
    total_policies: int
    active_policies: int
    quality_metrics: Dict[str, float]
    top_accessed_objects: List[Dict[str, Any]]
    recent_activities: List[Dict[str, Any]]
    
    def validate(self) -> None:
        """Validate analytics summary DTO."""
        if self.total_objects < 0:
            raise ValueError("Total objects cannot be negative")


@dataclass
class SyncResultDTO(BaseDTO):
    """DTO for synchronization results."""
    sync_id: str
    status: str  # "success", "partial", "failed"
    started_at: datetime
    completed_at: Optional[datetime] = None
    objects_processed: int = 0
    objects_created: int = 0
    objects_updated: int = 0
    objects_failed: int = 0
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    
    def validate(self) -> None:
        """Validate sync result DTO."""
        if not self.sync_id:
            raise ValueError("Sync ID is required")
        if self.status not in ["success", "partial", "failed"]:
            raise ValueError("Status must be 'success', 'partial', or 'failed'")


@dataclass
class HealthCheckDTO(BaseDTO):
    """DTO for health check response."""
    status: str  # "healthy", "unhealthy", "degraded"
    timestamp: datetime
    version: str
    services: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    
    def validate(self) -> None:
        """Validate health check DTO."""
        if self.status not in ["healthy", "unhealthy", "degraded"]:
            raise ValueError("Status must be 'healthy', 'unhealthy', or 'degraded'")


@dataclass
class ErrorResponseDTO(BaseDTO):
    """DTO for error responses."""
    detail: str
    error_code: str
    timestamp: datetime
    request_id: Optional[str] = None
    errors: Optional[List[Dict[str, str]]] = None
    
    def validate(self) -> None:
        """Validate error response DTO."""
        if not self.detail:
            raise ValueError("Error detail is required")
        if not self.error_code:
            raise ValueError("Error code is required")


# Factory functions for creating DTOs
def create_data_object_response_dto(entity) -> DataObjectResponseDTO:
    """Create DataObjectResponseDTO from entity."""
    return DataObjectResponseDTO(
        object_id=str(entity.id),
        object_name=entity.object_name.value,
        object_type=entity.object_type.value,
        catalog_name=entity.catalog_name.value,
        schema_name=entity.schema_name.value,
        full_name=entity.full_name,
        object_owner=entity.object_owner,
        description=entity.description,
        location=entity.location,
        format=entity.format.value if entity.format else None,
        size_bytes=entity.size_bytes,
        row_count=entity.row_count,
        column_count=entity.column_count,
        is_active=entity.is_active,
        tags=entity.tags,
        security_classification=entity.security_classification.value,
        retention_policy=entity.retention_policy,
        business_owner=entity.business_owner,
        steward=entity.steward,
        created_at=entity.created_at,
        updated_at=entity.updated_at,
        version=entity.version,
        quality_score=entity.quality_score.value if entity.quality_score else None,
        properties=[
            DataObjectPropertyDTO(
                name=prop.name,
                data_type=prop.data_type,
                is_nullable=prop.is_nullable,
                is_primary_key=prop.is_primary_key,
                is_foreign_key=prop.is_foreign_key,
                description=prop.description,
                default_value=prop.default_value,
                constraints=prop.constraints,
                tags=prop.tags,
                security_classification=prop.security_classification.value if prop.security_classification else None
            )
            for prop in entity.properties
        ]
    )


def create_paginated_response_dto(items: List[Any], total: int, page: int, limit: int) -> PaginatedResponseDTO:
    """Create PaginatedResponseDTO."""
    pages = (total + limit - 1) // limit  # Ceiling division
    return PaginatedResponseDTO(
        items=items,
        total=total,
        page=page,
        size=len(items),
        pages=pages,
        has_next=page < pages,
        has_prev=page > 1
    )

