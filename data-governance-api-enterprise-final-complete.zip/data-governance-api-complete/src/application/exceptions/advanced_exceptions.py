"""
Advanced Exception System for Data Governance API.
Following SOLID principles and enterprise error handling patterns.

Author: Carlos Morais
"""

import logging
import time
import traceback
from abc import ABC, abstractmethod
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional, Type, Union
from uuid import uuid4

from pydantic import BaseModel, Field


# ============================================================================
# BASE EXCEPTION HIERARCHY (SRP + OCP)
# ============================================================================

class ErrorSeverity(str, Enum):
    """Error severity levels."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class ErrorCategory(str, Enum):
    """Error categories for classification."""
    VALIDATION = "validation"
    BUSINESS_RULE = "business_rule"
    AUTHENTICATION = "authentication"
    AUTHORIZATION = "authorization"
    NOT_FOUND = "not_found"
    CONFLICT = "conflict"
    DATABASE = "database"
    EXTERNAL_SERVICE = "external_service"
    NETWORK = "network"
    TIMEOUT = "timeout"
    RATE_LIMIT = "rate_limit"
    INTERNAL = "internal"


class ErrorContext(BaseModel):
    """Error context information."""
    request_id: Optional[str] = None
    user_id: Optional[str] = None
    operation: Optional[str] = None
    resource_id: Optional[str] = None
    resource_type: Optional[str] = None
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    additional_data: Dict[str, Any] = Field(default_factory=dict)


class BaseApplicationError(Exception):
    """
    Base exception for all application errors.
    
    Follows SRP: Single responsibility for error representation
    Follows OCP: Open for extension via inheritance
    """
    
    def __init__(
        self,
        message: str,
        error_code: str,
        category: ErrorCategory,
        severity: ErrorSeverity = ErrorSeverity.MEDIUM,
        context: Optional[ErrorContext] = None,
        cause: Optional[Exception] = None,
        user_message: Optional[str] = None,
        retry_after: Optional[int] = None
    ):
        super().__init__(message)
        self.message = message
        self.error_code = error_code
        self.category = category
        self.severity = severity
        self.context = context or ErrorContext()
        self.cause = cause
        self.user_message = user_message or message
        self.retry_after = retry_after
        self.error_id = str(uuid4())
        self.timestamp = datetime.utcnow()
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert error to dictionary representation."""
        return {
            "error_id": self.error_id,
            "error_code": self.error_code,
            "category": self.category.value,
            "severity": self.severity.value,
            "message": self.message,
            "user_message": self.user_message,
            "timestamp": self.timestamp.isoformat(),
            "context": self.context.dict() if self.context else None,
            "retry_after": self.retry_after,
            "cause": str(self.cause) if self.cause else None
        }
    
    def __str__(self) -> str:
        return f"[{self.error_code}] {self.message}"


# ============================================================================
# DOMAIN ERRORS (SRP)
# ============================================================================

class DomainError(BaseApplicationError):
    """Base class for domain-related errors."""
    
    def __init__(self, message: str, error_code: str, **kwargs):
        super().__init__(
            message=message,
            error_code=error_code,
            category=ErrorCategory.BUSINESS_RULE,
            **kwargs
        )


class ValidationError(DomainError):
    """Validation errors with detailed field information."""
    
    def __init__(
        self,
        message: str,
        field_errors: Optional[List[Dict[str, Any]]] = None,
        **kwargs
    ):
        super().__init__(
            message=message,
            error_code="VALIDATION_ERROR",
            category=ErrorCategory.VALIDATION,
            **kwargs
        )
        self.field_errors = field_errors or []
    
    def add_field_error(self, field: str, error: str, value: Any = None):
        """Add a field-specific validation error."""
        self.field_errors.append({
            "field": field,
            "error": error,
            "value": value
        })
    
    def to_dict(self) -> Dict[str, Any]:
        result = super().to_dict()
        result["field_errors"] = self.field_errors
        return result


class BusinessRuleViolationError(DomainError):
    """Business rule violation errors."""
    
    def __init__(self, message: str, rule_name: str, **kwargs):
        super().__init__(
            message=message,
            error_code=f"BUSINESS_RULE_VIOLATION_{rule_name.upper()}",
            **kwargs
        )
        self.rule_name = rule_name


class EntityNotFoundError(DomainError):
    """Entity not found errors."""
    
    def __init__(self, entity_type: str, entity_id: str, **kwargs):
        message = f"{entity_type} with ID '{entity_id}' not found"
        super().__init__(
            message=message,
            error_code="ENTITY_NOT_FOUND",
            category=ErrorCategory.NOT_FOUND,
            **kwargs
        )
        self.entity_type = entity_type
        self.entity_id = entity_id


class EntityAlreadyExistsError(DomainError):
    """Entity already exists errors."""
    
    def __init__(self, entity_type: str, identifier: str, **kwargs):
        message = f"{entity_type} with identifier '{identifier}' already exists"
        super().__init__(
            message=message,
            error_code="ENTITY_ALREADY_EXISTS",
            category=ErrorCategory.CONFLICT,
            **kwargs
        )
        self.entity_type = entity_type
        self.identifier = identifier


# ============================================================================
# INFRASTRUCTURE ERRORS (SRP)
# ============================================================================

class InfrastructureError(BaseApplicationError):
    """Base class for infrastructure-related errors."""
    
    def __init__(self, message: str, error_code: str, **kwargs):
        super().__init__(
            message=message,
            error_code=error_code,
            category=ErrorCategory.INTERNAL,
            severity=ErrorSeverity.HIGH,
            **kwargs
        )


class DatabaseError(InfrastructureError):
    """Database-related errors."""
    
    def __init__(self, message: str, operation: str, **kwargs):
        super().__init__(
            message=message,
            error_code="DATABASE_ERROR",
            category=ErrorCategory.DATABASE,
            **kwargs
        )
        self.operation = operation


class ExternalServiceError(InfrastructureError):
    """External service errors."""
    
    def __init__(
        self,
        message: str,
        service_name: str,
        status_code: Optional[int] = None,
        **kwargs
    ):
        super().__init__(
            message=message,
            error_code=f"EXTERNAL_SERVICE_ERROR_{service_name.upper()}",
            category=ErrorCategory.EXTERNAL_SERVICE,
            **kwargs
        )
        self.service_name = service_name
        self.status_code = status_code


class NetworkError(InfrastructureError):
    """Network-related errors."""
    
    def __init__(self, message: str, **kwargs):
        super().__init__(
            message=message,
            error_code="NETWORK_ERROR",
            category=ErrorCategory.NETWORK,
            **kwargs
        )


class TimeoutError(InfrastructureError):
    """Timeout errors."""
    
    def __init__(self, message: str, timeout_seconds: int, **kwargs):
        super().__init__(
            message=message,
            error_code="TIMEOUT_ERROR",
            category=ErrorCategory.TIMEOUT,
            **kwargs
        )
        self.timeout_seconds = timeout_seconds


# ============================================================================
# SECURITY ERRORS (SRP)
# ============================================================================

class SecurityError(BaseApplicationError):
    """Base class for security-related errors."""
    
    def __init__(self, message: str, error_code: str, **kwargs):
        super().__init__(
            message=message,
            error_code=error_code,
            severity=ErrorSeverity.HIGH,
            **kwargs
        )


class AuthenticationError(SecurityError):
    """Authentication errors."""
    
    def __init__(self, message: str = "Authentication failed", **kwargs):
        super().__init__(
            message=message,
            error_code="AUTHENTICATION_ERROR",
            category=ErrorCategory.AUTHENTICATION,
            **kwargs
        )


class AuthorizationError(SecurityError):
    """Authorization errors."""
    
    def __init__(
        self,
        message: str = "Access denied",
        required_permission: Optional[str] = None,
        **kwargs
    ):
        super().__init__(
            message=message,
            error_code="AUTHORIZATION_ERROR",
            category=ErrorCategory.AUTHORIZATION,
            **kwargs
        )
        self.required_permission = required_permission


class RateLimitError(SecurityError):
    """Rate limiting errors."""
    
    def __init__(
        self,
        message: str = "Rate limit exceeded",
        retry_after: int = 60,
        **kwargs
    ):
        super().__init__(
            message=message,
            error_code="RATE_LIMIT_ERROR",
            category=ErrorCategory.RATE_LIMIT,
            retry_after=retry_after,
            **kwargs
        )


# ============================================================================
# ERROR HANDLER INTERFACE (ISP + DIP)
# ============================================================================

class IErrorHandler(ABC):
    """
    Interface for error handlers.
    
    Follows ISP: Interface segregation - specific to error handling
    Follows DIP: Dependency inversion - abstractions don't depend on details
    """
    
    @abstractmethod
    async def handle_error(
        self,
        error: BaseApplicationError,
        context: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Handle an application error."""
        pass
    
    @abstractmethod
    def can_handle(self, error: BaseApplicationError) -> bool:
        """Check if this handler can handle the given error."""
        pass


class IErrorLogger(ABC):
    """Interface for error logging."""
    
    @abstractmethod
    async def log_error(
        self,
        error: BaseApplicationError,
        context: Optional[Dict[str, Any]] = None
    ) -> None:
        """Log an error."""
        pass


class IErrorNotifier(ABC):
    """Interface for error notifications."""
    
    @abstractmethod
    async def notify_error(
        self,
        error: BaseApplicationError,
        context: Optional[Dict[str, Any]] = None
    ) -> None:
        """Send error notification."""
        pass


# ============================================================================
# CONCRETE ERROR HANDLERS (LSP + SRP)
# ============================================================================

class ValidationErrorHandler(IErrorHandler):
    """
    Handler for validation errors.
    
    Follows SRP: Single responsibility for validation error handling
    Follows LSP: Substitutable for IErrorHandler
    """
    
    def __init__(self, logger: IErrorLogger):
        self.logger = logger
    
    async def handle_error(
        self,
        error: BaseApplicationError,
        context: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        await self.logger.log_error(error, context)
        
        response = {
            "detail": error.user_message,
            "error_code": error.error_code,
            "error_id": error.error_id,
            "timestamp": error.timestamp.isoformat()
        }
        
        if isinstance(error, ValidationError) and error.field_errors:
            response["field_errors"] = error.field_errors
        
        return response
    
    def can_handle(self, error: BaseApplicationError) -> bool:
        return isinstance(error, ValidationError)


class DatabaseErrorHandler(IErrorHandler):
    """Handler for database errors."""
    
    def __init__(self, logger: IErrorLogger, notifier: IErrorNotifier):
        self.logger = logger
        self.notifier = notifier
    
    async def handle_error(
        self,
        error: BaseApplicationError,
        context: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        await self.logger.log_error(error, context)
        
        # Notify for critical database errors
        if error.severity == ErrorSeverity.CRITICAL:
            await self.notifier.notify_error(error, context)
        
        return {
            "detail": "A database error occurred. Please try again later.",
            "error_code": error.error_code,
            "error_id": error.error_id,
            "timestamp": error.timestamp.isoformat(),
            "retry_after": 30  # Suggest retry after 30 seconds
        }
    
    def can_handle(self, error: BaseApplicationError) -> bool:
        return isinstance(error, DatabaseError)


class ExternalServiceErrorHandler(IErrorHandler):
    """Handler for external service errors."""
    
    def __init__(self, logger: IErrorLogger):
        self.logger = logger
    
    async def handle_error(
        self,
        error: BaseApplicationError,
        context: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        await self.logger.log_error(error, context)
        
        return {
            "detail": f"External service temporarily unavailable: {error.message}",
            "error_code": error.error_code,
            "error_id": error.error_id,
            "timestamp": error.timestamp.isoformat(),
            "retry_after": error.retry_after or 60
        }
    
    def can_handle(self, error: BaseApplicationError) -> bool:
        return isinstance(error, ExternalServiceError)


# ============================================================================
# ERROR HANDLER FACTORY (OCP + DIP)
# ============================================================================

class ErrorHandlerFactory:
    """
    Factory for creating error handlers.
    
    Follows OCP: Open for extension with new handlers
    Follows DIP: Depends on abstractions (IErrorHandler)
    """
    
    def __init__(self):
        self._handlers: List[IErrorHandler] = []
    
    def register_handler(self, handler: IErrorHandler) -> None:
        """Register a new error handler."""
        self._handlers.append(handler)
    
    def get_handler(self, error: BaseApplicationError) -> Optional[IErrorHandler]:
        """Get the appropriate handler for an error."""
        for handler in self._handlers:
            if handler.can_handle(error):
                return handler
        return None
    
    def get_all_handlers(self) -> List[IErrorHandler]:
        """Get all registered handlers."""
        return self._handlers.copy()


# ============================================================================
# CIRCUIT BREAKER PATTERN (OCP + SRP)
# ============================================================================

class CircuitBreakerState(str, Enum):
    """Circuit breaker states."""
    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


class CircuitBreakerConfig(BaseModel):
    """Circuit breaker configuration."""
    failure_threshold: int = 5
    recovery_timeout: int = 60
    expected_exception: Type[Exception] = Exception


class CircuitBreaker:
    """
    Circuit breaker implementation.
    
    Follows SRP: Single responsibility for circuit breaking
    Follows OCP: Extensible for different failure conditions
    """
    
    def __init__(self, config: CircuitBreakerConfig):
        self.config = config
        self.failure_count = 0
        self.last_failure_time: Optional[float] = None
        self.state = CircuitBreakerState.CLOSED
    
    async def call(self, func, *args, **kwargs):
        """Execute function with circuit breaker protection."""
        if self.state == CircuitBreakerState.OPEN:
            if self._should_attempt_reset():
                self.state = CircuitBreakerState.HALF_OPEN
            else:
                raise ExternalServiceError(
                    message="Circuit breaker is open",
                    service_name="external_service",
                    retry_after=self.config.recovery_timeout
                )
        
        try:
            result = await func(*args, **kwargs)
            self._on_success()
            return result
        except self.config.expected_exception as e:
            self._on_failure()
            raise
    
    def _should_attempt_reset(self) -> bool:
        """Check if circuit breaker should attempt reset."""
        if self.last_failure_time is None:
            return True
        return time.time() - self.last_failure_time >= self.config.recovery_timeout
    
    def _on_success(self) -> None:
        """Handle successful call."""
        self.failure_count = 0
        self.state = CircuitBreakerState.CLOSED
    
    def _on_failure(self) -> None:
        """Handle failed call."""
        self.failure_count += 1
        self.last_failure_time = time.time()
        
        if self.failure_count >= self.config.failure_threshold:
            self.state = CircuitBreakerState.OPEN


# ============================================================================
# RETRY POLICY (SRP + OCP)
# ============================================================================

class RetryPolicy:
    """
    Retry policy with exponential backoff.
    
    Follows SRP: Single responsibility for retry logic
    Follows OCP: Extensible for different retry strategies
    """
    
    def __init__(
        self,
        max_attempts: int = 3,
        base_delay: float = 1.0,
        max_delay: float = 60.0,
        exponential_base: float = 2.0,
        jitter: bool = True
    ):
        self.max_attempts = max_attempts
        self.base_delay = base_delay
        self.max_delay = max_delay
        self.exponential_base = exponential_base
        self.jitter = jitter
    
    async def execute(self, func, *args, **kwargs):
        """Execute function with retry policy."""
        last_exception = None
        
        for attempt in range(self.max_attempts):
            try:
                return await func(*args, **kwargs)
            except Exception as e:
                last_exception = e
                
                if attempt == self.max_attempts - 1:
                    break
                
                delay = self._calculate_delay(attempt)
                await asyncio.sleep(delay)
        
        raise last_exception
    
    def _calculate_delay(self, attempt: int) -> float:
        """Calculate delay for retry attempt."""
        import random
        
        delay = self.base_delay * (self.exponential_base ** attempt)
        delay = min(delay, self.max_delay)
        
        if self.jitter:
            delay *= (0.5 + random.random() * 0.5)
        
        return delay


# ============================================================================
# ERROR TRACKING SERVICE (SRP + DIP)
# ============================================================================

class IErrorTracker(ABC):
    """Interface for error tracking services."""
    
    @abstractmethod
    async def track_error(
        self,
        error: BaseApplicationError,
        context: Optional[Dict[str, Any]] = None
    ) -> str:
        """Track an error and return tracking ID."""
        pass


class ErrorTrackingService:
    """
    Service for tracking and analyzing errors.
    
    Follows SRP: Single responsibility for error tracking
    Follows DIP: Depends on IErrorTracker abstraction
    """
    
    def __init__(self, tracker: IErrorTracker, logger: IErrorLogger):
        self.tracker = tracker
        self.logger = logger
    
    async def track_and_log_error(
        self,
        error: BaseApplicationError,
        context: Optional[Dict[str, Any]] = None
    ) -> str:
        """Track and log an error."""
        tracking_id = await self.tracker.track_error(error, context)
        await self.logger.log_error(error, context)
        return tracking_id


# ============================================================================
# STRUCTURED LOGGER (SRP)
# ============================================================================

class StructuredErrorLogger(IErrorLogger):
    """
    Structured logger for errors.
    
    Follows SRP: Single responsibility for structured logging
    """
    
    def __init__(self, logger_name: str = "data_governance_api"):
        self.logger = logging.getLogger(logger_name)
    
    async def log_error(
        self,
        error: BaseApplicationError,
        context: Optional[Dict[str, Any]] = None
    ) -> None:
        """Log error with structured format."""
        log_data = {
            "error_id": error.error_id,
            "error_code": error.error_code,
            "category": error.category.value,
            "severity": error.severity.value,
            "message": error.message,
            "timestamp": error.timestamp.isoformat(),
            "context": error.context.dict() if error.context else None,
            "additional_context": context or {},
            "stack_trace": traceback.format_exc() if error.cause else None
        }
        
        # Log at appropriate level based on severity
        if error.severity == ErrorSeverity.CRITICAL:
            self.logger.critical("Critical error occurred", extra=log_data)
        elif error.severity == ErrorSeverity.HIGH:
            self.logger.error("High severity error occurred", extra=log_data)
        elif error.severity == ErrorSeverity.MEDIUM:
            self.logger.warning("Medium severity error occurred", extra=log_data)
        else:
            self.logger.info("Low severity error occurred", extra=log_data)


# ============================================================================
# ERROR RESPONSE MODELS (SRP)
# ============================================================================

class ErrorResponseModel(BaseModel):
    """Standard error response model."""
    detail: str
    error_code: str
    error_id: str
    timestamp: str
    category: str
    severity: str
    retry_after: Optional[int] = None
    field_errors: Optional[List[Dict[str, Any]]] = None
    context: Optional[Dict[str, Any]] = None


class ValidationErrorResponseModel(ErrorResponseModel):
    """Validation error response model."""
    field_errors: List[Dict[str, Any]]


class RateLimitErrorResponseModel(ErrorResponseModel):
    """Rate limit error response model."""
    retry_after: int
    limit: Optional[int] = None
    remaining: Optional[int] = None

