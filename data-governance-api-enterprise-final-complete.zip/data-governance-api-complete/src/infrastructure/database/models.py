"""
SQLAlchemy Models for Data Governance API.
Database models following the domain entities structure.

Author: Carlos Morais
"""

from datetime import datetime
from typing import List, Optional
from uuid import UUID, uuid4

from sqlalchemy import (
    Column, String, Text, Integer, Float, Boolean, DateTime, 
    ForeignKey, JSON, ARRAY, Index, UniqueConstraint, CheckConstraint
)
from sqlalchemy.dialects.postgresql import UUID as PostgresUUID
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship, Mapped, mapped_column
from sqlalchemy.sql import func

Base = declarative_base()


class TimestampMixin:
    """Mixin for timestamp fields."""
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())


class DataObjectModel(Base, TimestampMixin):
    """SQLAlchemy model for DataObject entity."""
    
    __tablename__ = "data_objects"
    
    # Primary key
    id: Mapped[UUID] = mapped_column(PostgresUUID(as_uuid=True), primary_key=True, default=uuid4)
    
    # Core attributes
    object_name: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    object_type: Mapped[str] = mapped_column(String(50), nullable=False, index=True)
    catalog_name: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    schema_name: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    full_name: Mapped[str] = mapped_column(String(767), nullable=False, index=True)  # catalog.schema.object
    object_owner: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    
    # Optional attributes
    description: Mapped[Optional[str]] = mapped_column(Text)
    location: Mapped[Optional[str]] = mapped_column(Text)
    format: Mapped[Optional[str]] = mapped_column(String(50))
    size_bytes: Mapped[Optional[int]] = mapped_column(Integer)
    row_count: Mapped[Optional[int]] = mapped_column(Integer)
    column_count: Mapped[int] = mapped_column(Integer, default=0)
    
    # Status and metadata
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
    tags: Mapped[Optional[List[str]]] = mapped_column(ARRAY(String), default=list)
    security_classification: Mapped[str] = mapped_column(String(50), default="internal", index=True)
    retention_policy: Mapped[Optional[str]] = mapped_column(String(255))
    business_owner: Mapped[Optional[str]] = mapped_column(String(255), index=True)
    steward: Mapped[Optional[str]] = mapped_column(String(255), index=True)
    
    # Quality and versioning
    quality_score: Mapped[Optional[float]] = mapped_column(Float)
    version: Mapped[int] = mapped_column(Integer, default=1)
    
    # Relationships
    properties: Mapped[List["DataObjectPropertyModel"]] = relationship(
        "DataObjectPropertyModel", 
        back_populates="data_object",
        cascade="all, delete-orphan",
        lazy="selectin"
    )
    
    source_lineages: Mapped[List["DataLineageModel"]] = relationship(
        "DataLineageModel",
        foreign_keys="DataLineageModel.source_object_id",
        back_populates="source_object",
        cascade="all, delete-orphan"
    )
    
    target_lineages: Mapped[List["DataLineageModel"]] = relationship(
        "DataLineageModel",
        foreign_keys="DataLineageModel.target_object_id",
        back_populates="target_object",
        cascade="all, delete-orphan"
    )
    
    quality_metrics: Mapped[List["QualityMetricModel"]] = relationship(
        "QualityMetricModel",
        back_populates="data_object",
        cascade="all, delete-orphan"
    )
    
    access_policies: Mapped[List["AccessPolicyModel"]] = relationship(
        "AccessPolicyModel",
        back_populates="data_object"
    )
    
    # Constraints and indexes
    __table_args__ = (
        UniqueConstraint('catalog_name', 'schema_name', 'object_name', name='uq_data_object_full_name'),
        Index('ix_data_object_full_name', 'full_name'),
        Index('ix_data_object_type_classification', 'object_type', 'security_classification'),
        Index('ix_data_object_owner_steward', 'object_owner', 'business_owner', 'steward'),
        Index('ix_data_object_active_type', 'is_active', 'object_type'),
        CheckConstraint('size_bytes >= 0', name='ck_data_object_size_positive'),
        CheckConstraint('row_count >= 0', name='ck_data_object_rows_positive'),
        CheckConstraint('column_count >= 0', name='ck_data_object_columns_positive'),
        CheckConstraint('quality_score >= 0 AND quality_score <= 100', name='ck_data_object_quality_range'),
        CheckConstraint('version >= 1', name='ck_data_object_version_positive'),
    )
    
    def __repr__(self) -> str:
        return f"<DataObject(id={self.id}, full_name='{self.full_name}', type='{self.object_type}')>"


class DataObjectPropertyModel(Base, TimestampMixin):
    """SQLAlchemy model for DataObjectProperty value object."""
    
    __tablename__ = "data_object_properties"
    
    # Primary key
    id: Mapped[UUID] = mapped_column(PostgresUUID(as_uuid=True), primary_key=True, default=uuid4)
    
    # Foreign key
    object_id: Mapped[UUID] = mapped_column(PostgresUUID(as_uuid=True), ForeignKey("data_objects.id"), nullable=False, index=True)
    
    # Property attributes
    name: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    data_type: Mapped[str] = mapped_column(String(100), nullable=False)
    is_nullable: Mapped[bool] = mapped_column(Boolean, default=True)
    is_primary_key: Mapped[bool] = mapped_column(Boolean, default=False)
    is_foreign_key: Mapped[bool] = mapped_column(Boolean, default=False)
    description: Mapped[Optional[str]] = mapped_column(Text)
    default_value: Mapped[Optional[str]] = mapped_column(String(255))
    constraints: Mapped[Optional[List[str]]] = mapped_column(ARRAY(String), default=list)
    tags: Mapped[Optional[List[str]]] = mapped_column(ARRAY(String), default=list)
    security_classification: Mapped[Optional[str]] = mapped_column(String(50))
    
    # Relationships
    data_object: Mapped["DataObjectModel"] = relationship("DataObjectModel", back_populates="properties")
    
    # Constraints and indexes
    __table_args__ = (
        UniqueConstraint('object_id', 'name', name='uq_property_object_name'),
        Index('ix_property_object_name', 'object_id', 'name'),
        Index('ix_property_type_classification', 'data_type', 'security_classification'),
        Index('ix_property_keys', 'is_primary_key', 'is_foreign_key'),
    )
    
    def __repr__(self) -> str:
        return f"<DataObjectProperty(id={self.id}, name='{self.name}', type='{self.data_type}')>"


class DataLineageModel(Base, TimestampMixin):
    """SQLAlchemy model for DataLineage entity."""
    
    __tablename__ = "data_lineage"
    
    # Primary key
    id: Mapped[UUID] = mapped_column(PostgresUUID(as_uuid=True), primary_key=True, default=uuid4)
    
    # Foreign keys
    source_object_id: Mapped[UUID] = mapped_column(PostgresUUID(as_uuid=True), ForeignKey("data_objects.id"), nullable=False, index=True)
    target_object_id: Mapped[UUID] = mapped_column(PostgresUUID(as_uuid=True), ForeignKey("data_objects.id"), nullable=False, index=True)
    
    # Lineage attributes
    lineage_type: Mapped[str] = mapped_column(String(50), nullable=False, index=True)
    transformation_logic: Mapped[Optional[str]] = mapped_column(Text)
    job_id: Mapped[Optional[str]] = mapped_column(String(255), index=True)
    job_name: Mapped[Optional[str]] = mapped_column(String(255))
    confidence_score: Mapped[float] = mapped_column(Float, default=1.0)
    discovered_by: Mapped[str] = mapped_column(String(50), default="manual")
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
    
    # Relationships
    source_object: Mapped["DataObjectModel"] = relationship(
        "DataObjectModel",
        foreign_keys=[source_object_id],
        back_populates="source_lineages"
    )
    
    target_object: Mapped["DataObjectModel"] = relationship(
        "DataObjectModel",
        foreign_keys=[target_object_id],
        back_populates="target_lineages"
    )
    
    # Constraints and indexes
    __table_args__ = (
        UniqueConstraint('source_object_id', 'target_object_id', 'lineage_type', name='uq_lineage_source_target_type'),
        Index('ix_lineage_source_target', 'source_object_id', 'target_object_id'),
        Index('ix_lineage_type_confidence', 'lineage_type', 'confidence_score'),
        Index('ix_lineage_job', 'job_id', 'job_name'),
        Index('ix_lineage_active_type', 'is_active', 'lineage_type'),
        CheckConstraint('confidence_score >= 0 AND confidence_score <= 1', name='ck_lineage_confidence_range'),
        CheckConstraint('source_object_id != target_object_id', name='ck_lineage_different_objects'),
    )
    
    def __repr__(self) -> str:
        return f"<DataLineage(id={self.id}, type='{self.lineage_type}', confidence={self.confidence_score})>"


class AccessPolicyModel(Base, TimestampMixin):
    """SQLAlchemy model for AccessPolicy entity."""
    
    __tablename__ = "access_policies"
    
    # Primary key
    id: Mapped[UUID] = mapped_column(PostgresUUID(as_uuid=True), primary_key=True, default=uuid4)
    
    # Policy attributes
    policy_name: Mapped[str] = mapped_column(String(255), nullable=False, unique=True, index=True)
    policy_type: Mapped[str] = mapped_column(String(50), nullable=False, index=True)
    policy_scope: Mapped[str] = mapped_column(String(50), nullable=False, index=True)
    conditions: Mapped[dict] = mapped_column(JSON, nullable=False)
    actions: Mapped[dict] = mapped_column(JSON, nullable=False)
    priority: Mapped[int] = mapped_column(Integer, default=100, index=True)
    description: Mapped[Optional[str]] = mapped_column(Text)
    compliance_frameworks: Mapped[Optional[List[str]]] = mapped_column(ARRAY(String), default=list)
    
    # Optional object association
    object_id: Mapped[Optional[UUID]] = mapped_column(PostgresUUID(as_uuid=True), ForeignKey("data_objects.id"), index=True)
    
    # Metadata
    created_by: Mapped[Optional[str]] = mapped_column(String(255), index=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
    is_enforced: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
    
    # Relationships
    data_object: Mapped[Optional["DataObjectModel"]] = relationship("DataObjectModel", back_populates="access_policies")
    
    # Constraints and indexes
    __table_args__ = (
        Index('ix_policy_type_scope', 'policy_type', 'policy_scope'),
        Index('ix_policy_priority_active', 'priority', 'is_active'),
        Index('ix_policy_object_type', 'object_id', 'policy_type'),
        Index('ix_policy_enforced_active', 'is_enforced', 'is_active'),
        CheckConstraint('priority >= 1 AND priority <= 1000', name='ck_policy_priority_range'),
    )
    
    def __repr__(self) -> str:
        return f"<AccessPolicy(id={self.id}, name='{self.policy_name}', type='{self.policy_type}')>"


class QualityMetricModel(Base, TimestampMixin):
    """SQLAlchemy model for QualityMetric entity."""
    
    __tablename__ = "quality_metrics"
    
    # Primary key
    id: Mapped[UUID] = mapped_column(PostgresUUID(as_uuid=True), primary_key=True, default=uuid4)
    
    # Foreign key
    object_id: Mapped[UUID] = mapped_column(PostgresUUID(as_uuid=True), ForeignKey("data_objects.id"), nullable=False, index=True)
    
    # Metric attributes
    dimension: Mapped[str] = mapped_column(String(50), nullable=False, index=True)
    metric_value: Mapped[float] = mapped_column(Float, nullable=False)
    rule_name: Mapped[Optional[str]] = mapped_column(String(255), index=True)
    rule_definition: Mapped[Optional[str]] = mapped_column(Text)
    threshold_value: Mapped[Optional[float]] = mapped_column(Float)
    is_passing: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
    measurement_timestamp: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=func.now(), index=True)
    
    # Relationships
    data_object: Mapped["DataObjectModel"] = relationship("DataObjectModel", back_populates="quality_metrics")
    
    # Constraints and indexes
    __table_args__ = (
        Index('ix_quality_object_dimension', 'object_id', 'dimension'),
        Index('ix_quality_dimension_passing', 'dimension', 'is_passing'),
        Index('ix_quality_timestamp_dimension', 'measurement_timestamp', 'dimension'),
        Index('ix_quality_value_threshold', 'metric_value', 'threshold_value'),
        CheckConstraint('metric_value >= 0 AND metric_value <= 100', name='ck_quality_metric_range'),
        CheckConstraint('threshold_value IS NULL OR (threshold_value >= 0 AND threshold_value <= 100)', name='ck_quality_threshold_range'),
    )
    
    def __repr__(self) -> str:
        return f"<QualityMetric(id={self.id}, dimension='{self.dimension}', value={self.metric_value})>"


class DataContractModel(Base, TimestampMixin):
    """SQLAlchemy model for DataContract entity."""
    
    __tablename__ = "data_contracts"
    
    # Primary key
    id: Mapped[UUID] = mapped_column(PostgresUUID(as_uuid=True), primary_key=True, default=uuid4)
    
    # Contract attributes
    contract_name: Mapped[str] = mapped_column(String(255), nullable=False, unique=True, index=True)
    version: Mapped[str] = mapped_column(String(50), nullable=False)
    status: Mapped[str] = mapped_column(String(50), default="draft", index=True)
    description: Mapped[Optional[str]] = mapped_column(Text)
    
    # Contract definition
    schema_definition: Mapped[dict] = mapped_column(JSON, nullable=False)
    quality_requirements: Mapped[Optional[dict]] = mapped_column(JSON)
    sla_requirements: Mapped[Optional[dict]] = mapped_column(JSON)
    
    # Ownership and approval
    owner: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    approved_by: Mapped[Optional[str]] = mapped_column(String(255))
    approved_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    
    # Validity period
    valid_from: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    valid_until: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    
    # Constraints and indexes
    __table_args__ = (
        UniqueConstraint('contract_name', 'version', name='uq_contract_name_version'),
        Index('ix_contract_status_owner', 'status', 'owner'),
        Index('ix_contract_validity', 'valid_from', 'valid_until'),
        CheckConstraint("status IN ('draft', 'active', 'deprecated', 'retired')", name='ck_contract_status'),
    )
    
    def __repr__(self) -> str:
        return f"<DataContract(id={self.id}, name='{self.contract_name}', version='{self.version}')>"


class JobMetricModel(Base, TimestampMixin):
    """SQLAlchemy model for JobMetric entity."""
    
    __tablename__ = "job_metrics"
    
    # Primary key
    id: Mapped[UUID] = mapped_column(PostgresUUID(as_uuid=True), primary_key=True, default=uuid4)
    
    # Job identification
    job_id: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    job_name: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    run_id: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    
    # Execution metrics
    start_time: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)
    end_time: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), index=True)
    duration_seconds: Mapped[Optional[int]] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(String(50), nullable=False, index=True)
    
    # Resource metrics
    cluster_id: Mapped[Optional[str]] = mapped_column(String(255), index=True)
    driver_cores: Mapped[Optional[int]] = mapped_column(Integer)
    driver_memory_gb: Mapped[Optional[float]] = mapped_column(Float)
    executor_cores: Mapped[Optional[int]] = mapped_column(Integer)
    executor_memory_gb: Mapped[Optional[float]] = mapped_column(Float)
    executor_count: Mapped[Optional[int]] = mapped_column(Integer)
    
    # Cost and usage
    dbu_consumed: Mapped[Optional[float]] = mapped_column(Float)
    cost_usd: Mapped[Optional[float]] = mapped_column(Float)
    
    # Data processed
    input_records: Mapped[Optional[int]] = mapped_column(Integer)
    output_records: Mapped[Optional[int]] = mapped_column(Integer)
    input_bytes: Mapped[Optional[int]] = mapped_column(Integer)
    output_bytes: Mapped[Optional[int]] = mapped_column(Integer)
    
    # Error information
    error_message: Mapped[Optional[str]] = mapped_column(Text)
    error_type: Mapped[Optional[str]] = mapped_column(String(100))
    
    # Constraints and indexes
    __table_args__ = (
        UniqueConstraint('job_id', 'run_id', name='uq_job_run'),
        Index('ix_job_start_time', 'start_time'),
        Index('ix_job_status_duration', 'status', 'duration_seconds'),
        Index('ix_job_cluster_cost', 'cluster_id', 'cost_usd'),
        Index('ix_job_name_status', 'job_name', 'status'),
        CheckConstraint('duration_seconds >= 0', name='ck_job_duration_positive'),
        CheckConstraint('dbu_consumed >= 0', name='ck_job_dbu_positive'),
        CheckConstraint('cost_usd >= 0', name='ck_job_cost_positive'),
        CheckConstraint('input_records >= 0', name='ck_job_input_records_positive'),
        CheckConstraint('output_records >= 0', name='ck_job_output_records_positive'),
    )
    
    def __repr__(self) -> str:
        return f"<JobMetric(id={self.id}, job_name='{self.job_name}', run_id='{self.run_id}')>"


class AlertModel(Base, TimestampMixin):
    """SQLAlchemy model for Alert entity."""
    
    __tablename__ = "alerts"
    
    # Primary key
    id: Mapped[UUID] = mapped_column(PostgresUUID(as_uuid=True), primary_key=True, default=uuid4)
    
    # Alert attributes
    alert_type: Mapped[str] = mapped_column(String(50), nullable=False, index=True)
    severity: Mapped[str] = mapped_column(String(20), nullable=False, index=True)
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    message: Mapped[str] = mapped_column(Text, nullable=False)
    status: Mapped[str] = mapped_column(String(20), default="active", index=True)
    
    # Associated entities
    object_id: Mapped[Optional[UUID]] = mapped_column(PostgresUUID(as_uuid=True), ForeignKey("data_objects.id"), index=True)
    job_id: Mapped[Optional[str]] = mapped_column(String(255), index=True)
    policy_id: Mapped[Optional[UUID]] = mapped_column(PostgresUUID(as_uuid=True), ForeignKey("access_policies.id"), index=True)
    
    # Metadata
    metadata: Mapped[Optional[dict]] = mapped_column(JSON)
    triggered_by: Mapped[Optional[str]] = mapped_column(String(255))
    resolved_by: Mapped[Optional[str]] = mapped_column(String(255))
    resolved_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    resolution_note: Mapped[Optional[str]] = mapped_column(Text)
    
    # Constraints and indexes
    __table_args__ = (
        Index('ix_alert_type_severity', 'alert_type', 'severity'),
        Index('ix_alert_status_created', 'status', 'created_at'),
        Index('ix_alert_object_type', 'object_id', 'alert_type'),
        CheckConstraint("severity IN ('low', 'medium', 'high', 'critical')", name='ck_alert_severity'),
        CheckConstraint("status IN ('active', 'acknowledged', 'resolved', 'suppressed')", name='ck_alert_status'),
    )
    
    def __repr__(self) -> str:
        return f"<Alert(id={self.id}, type='{self.alert_type}', severity='{self.severity}')>"


# Create all indexes for performance optimization
def create_performance_indexes(engine):
    """Create additional performance indexes."""
    from sqlalchemy import text
    
    # Additional composite indexes for common queries
    indexes = [
        # Data objects - common search patterns
        "CREATE INDEX CONCURRENTLY IF NOT EXISTS ix_data_object_search ON data_objects USING gin(to_tsvector('english', coalesce(object_name, '') || ' ' || coalesce(description, '')))",
        "CREATE INDEX CONCURRENTLY IF NOT EXISTS ix_data_object_tags ON data_objects USING gin(tags)",
        
        # Quality metrics - time series queries
        "CREATE INDEX CONCURRENTLY IF NOT EXISTS ix_quality_time_series ON quality_metrics (object_id, dimension, measurement_timestamp DESC)",
        
        # Lineage - graph traversal
        "CREATE INDEX CONCURRENTLY IF NOT EXISTS ix_lineage_graph ON data_lineage (source_object_id, target_object_id, is_active)",
        
        # Job metrics - time-based analytics
        "CREATE INDEX CONCURRENTLY IF NOT EXISTS ix_job_time_analytics ON job_metrics (start_time DESC, status, cost_usd)",
        
        # Alerts - operational queries
        "CREATE INDEX CONCURRENTLY IF NOT EXISTS ix_alert_operational ON alerts (status, severity, created_at DESC)",
    ]
    
    with engine.connect() as conn:
        for index_sql in indexes:
            try:
                conn.execute(text(index_sql))
                conn.commit()
            except Exception as e:
                print(f"Warning: Could not create index: {e}")
                conn.rollback()

