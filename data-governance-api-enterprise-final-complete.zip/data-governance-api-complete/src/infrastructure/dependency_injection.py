"""
Dependency Injection Container and SOLID Principles Implementation.
Following enterprise patterns and best practices.

Author: Carlos Morais
"""

import asyncio
from abc import ABC, abstractmethod
from typing import Any, Dict, Type, TypeVar, Generic, Optional, Callable, List
from dataclasses import dataclass
from enum import Enum
import inspect
from functools import wraps

# ============================================================================
# DEPENDENCY INJECTION INTERFACES (ISP + DIP)
# ============================================================================

T = TypeVar('T')


class ServiceLifetime(Enum):
    """Service lifetime management."""
    SINGLETON = "singleton"
    SCOPED = "scoped"
    TRANSIENT = "transient"


class IServiceContainer(ABC):
    """
    Interface for dependency injection container.
    
    Follows ISP: Interface segregation - specific to DI container
    Follows DIP: Dependency inversion - abstractions don't depend on details
    """
    
    @abstractmethod
    def register_singleton(self, interface: Type[T], implementation: Type[T]) -> None:
        """Register a singleton service."""
        pass
    
    @abstractmethod
    def register_scoped(self, interface: Type[T], implementation: Type[T]) -> None:
        """Register a scoped service."""
        pass
    
    @abstractmethod
    def register_transient(self, interface: Type[T], implementation: Type[T]) -> None:
        """Register a transient service."""
        pass
    
    @abstractmethod
    def register_factory(self, interface: Type[T], factory: Callable[[], T]) -> None:
        """Register a factory function."""
        pass
    
    @abstractmethod
    async def resolve(self, interface: Type[T]) -> T:
        """Resolve a service instance."""
        pass
    
    @abstractmethod
    def create_scope(self) -> 'IServiceScope':
        """Create a new service scope."""
        pass


class IServiceScope(ABC):
    """Interface for service scope management."""
    
    @abstractmethod
    async def resolve(self, interface: Type[T]) -> T:
        """Resolve a service within this scope."""
        pass
    
    @abstractmethod
    async def dispose(self) -> None:
        """Dispose of scoped services."""
        pass


# ============================================================================
# SERVICE REGISTRATION (SRP + OCP)
# ============================================================================

@dataclass
class ServiceDescriptor:
    """
    Service descriptor for registration.
    
    Follows SRP: Single responsibility for service description
    """
    interface: Type
    implementation: Optional[Type] = None
    factory: Optional[Callable] = None
    lifetime: ServiceLifetime = ServiceLifetime.TRANSIENT
    instance: Optional[Any] = None


class ServiceRegistry:
    """
    Service registry for managing service descriptors.
    
    Follows SRP: Single responsibility for service registration
    Follows OCP: Open for extension with new service types
    """
    
    def __init__(self):
        self._services: Dict[Type, ServiceDescriptor] = {}
    
    def register(self, descriptor: ServiceDescriptor) -> None:
        """Register a service descriptor."""
        self._services[descriptor.interface] = descriptor
    
    def get_descriptor(self, interface: Type) -> Optional[ServiceDescriptor]:
        """Get service descriptor by interface."""
        return self._services.get(interface)
    
    def get_all_descriptors(self) -> List[ServiceDescriptor]:
        """Get all registered service descriptors."""
        return list(self._services.values())


# ============================================================================
# DEPENDENCY INJECTION CONTAINER (SOLID Implementation)
# ============================================================================

class ServiceContainer(IServiceContainer):
    """
    Dependency injection container implementation.
    
    Follows all SOLID principles:
    - SRP: Single responsibility for dependency resolution
    - OCP: Open for extension with new service types
    - LSP: Substitutable for IServiceContainer
    - ISP: Implements specific DI interface
    - DIP: Depends on abstractions, not concretions
    """
    
    def __init__(self):
        self._registry = ServiceRegistry()
        self._singletons: Dict[Type, Any] = {}
    
    def register_singleton(self, interface: Type[T], implementation: Type[T]) -> None:
        """Register a singleton service."""
        descriptor = ServiceDescriptor(
            interface=interface,
            implementation=implementation,
            lifetime=ServiceLifetime.SINGLETON
        )
        self._registry.register(descriptor)
    
    def register_scoped(self, interface: Type[T], implementation: Type[T]) -> None:
        """Register a scoped service."""
        descriptor = ServiceDescriptor(
            interface=interface,
            implementation=implementation,
            lifetime=ServiceLifetime.SCOPED
        )
        self._registry.register(descriptor)
    
    def register_transient(self, interface: Type[T], implementation: Type[T]) -> None:
        """Register a transient service."""
        descriptor = ServiceDescriptor(
            interface=interface,
            implementation=implementation,
            lifetime=ServiceLifetime.TRANSIENT
        )
        self._registry.register(descriptor)
    
    def register_factory(self, interface: Type[T], factory: Callable[[], T]) -> None:
        """Register a factory function."""
        descriptor = ServiceDescriptor(
            interface=interface,
            factory=factory,
            lifetime=ServiceLifetime.TRANSIENT
        )
        self._registry.register(descriptor)
    
    def register_instance(self, interface: Type[T], instance: T) -> None:
        """Register a specific instance."""
        descriptor = ServiceDescriptor(
            interface=interface,
            instance=instance,
            lifetime=ServiceLifetime.SINGLETON
        )
        self._registry.register(descriptor)
        self._singletons[interface] = instance
    
    async def resolve(self, interface: Type[T]) -> T:
        """Resolve a service instance."""
        descriptor = self._registry.get_descriptor(interface)
        if not descriptor:
            raise ValueError(f"Service {interface} not registered")
        
        if descriptor.lifetime == ServiceLifetime.SINGLETON:
            return await self._resolve_singleton(descriptor)
        elif descriptor.lifetime == ServiceLifetime.TRANSIENT:
            return await self._create_instance(descriptor)
        else:
            raise ValueError(f"Cannot resolve scoped service outside of scope")
    
    def create_scope(self) -> 'ServiceScope':
        """Create a new service scope."""
        return ServiceScope(self)
    
    async def _resolve_singleton(self, descriptor: ServiceDescriptor) -> Any:
        """Resolve singleton service."""
        if descriptor.interface in self._singletons:
            return self._singletons[descriptor.interface]
        
        instance = await self._create_instance(descriptor)
        self._singletons[descriptor.interface] = instance
        return instance
    
    async def _create_instance(self, descriptor: ServiceDescriptor) -> Any:
        """Create service instance."""
        if descriptor.instance is not None:
            return descriptor.instance
        
        if descriptor.factory is not None:
            if asyncio.iscoroutinefunction(descriptor.factory):
                return await descriptor.factory()
            else:
                return descriptor.factory()
        
        if descriptor.implementation is not None:
            return await self._instantiate_class(descriptor.implementation)
        
        raise ValueError(f"Cannot create instance for {descriptor.interface}")
    
    async def _instantiate_class(self, cls: Type) -> Any:
        """Instantiate class with dependency injection."""
        # Get constructor signature
        signature = inspect.signature(cls.__init__)
        parameters = signature.parameters
        
        # Skip 'self' parameter
        param_names = [name for name in parameters.keys() if name != 'self']
        
        # Resolve dependencies
        dependencies = {}
        for param_name in param_names:
            param = parameters[param_name]
            if param.annotation != inspect.Parameter.empty:
                dependency = await self.resolve(param.annotation)
                dependencies[param_name] = dependency
        
        # Create instance
        return cls(**dependencies)


# ============================================================================
# SERVICE SCOPE (SRP + LSP)
# ============================================================================

class ServiceScope(IServiceScope):
    """
    Service scope implementation.
    
    Follows SRP: Single responsibility for scope management
    Follows LSP: Substitutable for IServiceScope
    """
    
    def __init__(self, container: ServiceContainer):
        self._container = container
        self._scoped_instances: Dict[Type, Any] = {}
        self._disposed = False
    
    async def resolve(self, interface: Type[T]) -> T:
        """Resolve a service within this scope."""
        if self._disposed:
            raise RuntimeError("Cannot resolve services from disposed scope")
        
        descriptor = self._container._registry.get_descriptor(interface)
        if not descriptor:
            raise ValueError(f"Service {interface} not registered")
        
        if descriptor.lifetime == ServiceLifetime.SINGLETON:
            return await self._container._resolve_singleton(descriptor)
        elif descriptor.lifetime == ServiceLifetime.SCOPED:
            return await self._resolve_scoped(descriptor)
        elif descriptor.lifetime == ServiceLifetime.TRANSIENT:
            return await self._container._create_instance(descriptor)
        else:
            raise ValueError(f"Unknown service lifetime: {descriptor.lifetime}")
    
    async def _resolve_scoped(self, descriptor: ServiceDescriptor) -> Any:
        """Resolve scoped service."""
        if descriptor.interface in self._scoped_instances:
            return self._scoped_instances[descriptor.interface]
        
        instance = await self._container._create_instance(descriptor)
        self._scoped_instances[descriptor.interface] = instance
        return instance
    
    async def dispose(self) -> None:
        """Dispose of scoped services."""
        if self._disposed:
            return
        
        # Dispose services that implement IDisposable
        for instance in self._scoped_instances.values():
            if hasattr(instance, 'dispose'):
                if asyncio.iscoroutinefunction(instance.dispose):
                    await instance.dispose()
                else:
                    instance.dispose()
        
        self._scoped_instances.clear()
        self._disposed = True


# ============================================================================
# DECORATORS FOR DEPENDENCY INJECTION (OCP + DIP)
# ============================================================================

def injectable(lifetime: ServiceLifetime = ServiceLifetime.TRANSIENT):
    """
    Decorator to mark classes as injectable services.
    
    Follows OCP: Open for extension with new service configurations
    Follows DIP: Depends on abstractions for service registration
    """
    def decorator(cls):
        cls._service_lifetime = lifetime
        return cls
    return decorator


def inject(container: IServiceContainer):
    """
    Decorator to inject dependencies into function parameters.
    
    Follows DIP: Depends on container abstraction
    """
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            # Get function signature
            signature = inspect.signature(func)
            
            # Resolve dependencies for parameters without values
            for param_name, param in signature.parameters.items():
                if param_name not in kwargs and param.annotation != inspect.Parameter.empty:
                    if hasattr(param.annotation, '__origin__'):
                        # Skip generic types
                        continue
                    try:
                        dependency = await container.resolve(param.annotation)
                        kwargs[param_name] = dependency
                    except ValueError:
                        # Parameter not registered as service, skip
                        pass
            
            if asyncio.iscoroutinefunction(func):
                return await func(*args, **kwargs)
            else:
                return func(*args, **kwargs)
        return wrapper
    return decorator


# ============================================================================
# SERVICE LOCATOR PATTERN (SRP + DIP)
# ============================================================================

class ServiceLocator:
    """
    Service locator for global service access.
    
    Follows SRP: Single responsibility for service location
    Follows DIP: Depends on container abstraction
    """
    
    _container: Optional[IServiceContainer] = None
    
    @classmethod
    def set_container(cls, container: IServiceContainer) -> None:
        """Set the global service container."""
        cls._container = container
    
    @classmethod
    async def get_service(cls, interface: Type[T]) -> T:
        """Get service from global container."""
        if cls._container is None:
            raise RuntimeError("Service container not configured")
        return await cls._container.resolve(interface)
    
    @classmethod
    def create_scope(cls) -> IServiceScope:
        """Create a new service scope."""
        if cls._container is None:
            raise RuntimeError("Service container not configured")
        return cls._container.create_scope()


# ============================================================================
# CONFIGURATION BUILDER (OCP + SRP)
# ============================================================================

class ServiceConfigurationBuilder:
    """
    Builder for service container configuration.
    
    Follows SRP: Single responsibility for configuration building
    Follows OCP: Open for extension with new configuration methods
    """
    
    def __init__(self):
        self._container = ServiceContainer()
    
    def add_singleton(self, interface: Type[T], implementation: Type[T]) -> 'ServiceConfigurationBuilder':
        """Add singleton service."""
        self._container.register_singleton(interface, implementation)
        return self
    
    def add_scoped(self, interface: Type[T], implementation: Type[T]) -> 'ServiceConfigurationBuilder':
        """Add scoped service."""
        self._container.register_scoped(interface, implementation)
        return self
    
    def add_transient(self, interface: Type[T], implementation: Type[T]) -> 'ServiceConfigurationBuilder':
        """Add transient service."""
        self._container.register_transient(interface, implementation)
        return self
    
    def add_factory(self, interface: Type[T], factory: Callable[[], T]) -> 'ServiceConfigurationBuilder':
        """Add factory service."""
        self._container.register_factory(interface, factory)
        return self
    
    def add_instance(self, interface: Type[T], instance: T) -> 'ServiceConfigurationBuilder':
        """Add instance service."""
        self._container.register_instance(interface, instance)
        return self
    
    def configure_data_access(self) -> 'ServiceConfigurationBuilder':
        """Configure data access services."""
        # This would be implemented with actual repository interfaces
        # Example configuration:
        # self.add_scoped(IDataObjectRepository, PostgreSQLDataObjectRepository)
        # self.add_scoped(ILineageRepository, PostgreSQLLineageRepository)
        return self
    
    def configure_external_services(self) -> 'ServiceConfigurationBuilder':
        """Configure external services."""
        # Example configuration:
        # self.add_singleton(INotificationService, EmailNotificationService)
        # self.add_singleton(IEventPublisher, EventBusPublisher)
        return self
    
    def configure_application_services(self) -> 'ServiceConfigurationBuilder':
        """Configure application services."""
        # Example configuration:
        # self.add_transient(CreateDataObjectUseCase, CreateDataObjectUseCase)
        # self.add_transient(GetDataObjectUseCase, GetDataObjectUseCase)
        return self
    
    def build(self) -> IServiceContainer:
        """Build the configured service container."""
        return self._container


# ============================================================================
# FACTORY PATTERN IMPLEMENTATION (OCP + SRP)
# ============================================================================

class IServiceFactory(ABC, Generic[T]):
    """
    Interface for service factories.
    
    Follows ISP: Interface segregation for factory pattern
    Follows OCP: Open for extension with new factory types
    """
    
    @abstractmethod
    async def create(self) -> T:
        """Create service instance."""
        pass


class RepositoryFactory(IServiceFactory):
    """
    Factory for repository services.
    
    Follows SRP: Single responsibility for repository creation
    Follows OCP: Open for extension with new repository types
    """
    
    def __init__(self, container: IServiceContainer):
        self._container = container
    
    async def create_data_object_repository(self):
        """Create data object repository."""
        # Implementation would resolve actual repository
        pass
    
    async def create_lineage_repository(self):
        """Create lineage repository."""
        # Implementation would resolve actual repository
        pass


# ============================================================================
# ASPECT-ORIENTED PROGRAMMING SUPPORT (OCP + SRP)
# ============================================================================

class IAspect(ABC):
    """Interface for cross-cutting concerns."""
    
    @abstractmethod
    async def before(self, context: Dict[str, Any]) -> None:
        """Execute before method call."""
        pass
    
    @abstractmethod
    async def after(self, context: Dict[str, Any], result: Any) -> Any:
        """Execute after method call."""
        pass
    
    @abstractmethod
    async def on_exception(self, context: Dict[str, Any], exception: Exception) -> None:
        """Execute on exception."""
        pass


class LoggingAspect(IAspect):
    """
    Logging aspect for method calls.
    
    Follows SRP: Single responsibility for logging
    """
    
    def __init__(self, logger):
        self._logger = logger
    
    async def before(self, context: Dict[str, Any]) -> None:
        """Log method entry."""
        method_name = context.get('method_name', 'unknown')
        self._logger.info(f"Entering method: {method_name}")
    
    async def after(self, context: Dict[str, Any], result: Any) -> Any:
        """Log method exit."""
        method_name = context.get('method_name', 'unknown')
        self._logger.info(f"Exiting method: {method_name}")
        return result
    
    async def on_exception(self, context: Dict[str, Any], exception: Exception) -> None:
        """Log exception."""
        method_name = context.get('method_name', 'unknown')
        self._logger.error(f"Exception in method {method_name}: {str(exception)}")


def with_aspects(*aspects: IAspect):
    """
    Decorator to apply aspects to methods.
    
    Follows OCP: Open for extension with new aspects
    """
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            context = {
                'method_name': func.__name__,
                'args': args,
                'kwargs': kwargs
            }
            
            try:
                # Execute before aspects
                for aspect in aspects:
                    await aspect.before(context)
                
                # Execute method
                if asyncio.iscoroutinefunction(func):
                    result = await func(*args, **kwargs)
                else:
                    result = func(*args, **kwargs)
                
                # Execute after aspects
                for aspect in aspects:
                    result = await aspect.after(context, result)
                
                return result
            
            except Exception as e:
                # Execute exception aspects
                for aspect in aspects:
                    await aspect.on_exception(context, e)
                raise
        
        return wrapper
    return decorator

