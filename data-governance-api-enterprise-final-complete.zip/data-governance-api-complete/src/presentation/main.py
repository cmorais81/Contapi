"""
Main FastAPI Application for Data Governance API.
Following OpenAPI standards and best practices.

Author: Carlos Morais
"""

import asyncio
import logging
import time
from contextlib import asynccontextmanager
from typing import Dict, Any

from fastapi import FastAPI, Request, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import JSONResponse
from fastapi.openapi.docs import get_swagger_ui_html, get_redoc_html
from fastapi.openapi.utils import get_openapi
from fastapi.staticfiles import StaticFiles
from starlette.middleware.base import BaseHTTPMiddleware

from ..api.v1.endpoints import (
    data_objects, data_lineage, access_policies, quality_metrics,
    analytics, monitoring, health, sync, search
)
from ...application.exceptions import (
    BaseApplicationError, EntityNotFoundError, ValidationError,
    DatabaseError, PermissionError, BusinessRuleViolationError
)
from ...infrastructure.config import get_settings
from ...infrastructure.database import get_database_engine, create_tables
from ...infrastructure.logging import setup_logging


# Application lifespan management
@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan management."""
    # Startup
    logger = logging.getLogger(__name__)
    logger.info("Starting Data Governance API...")
    
    # Initialize database
    try:
        engine = get_database_engine()
        await create_tables(engine)
        logger.info("Database initialized successfully")
    except Exception as e:
        logger.error(f"Failed to initialize database: {e}")
        raise
    
    # Initialize other services
    try:
        # Initialize cache, metrics, etc.
        logger.info("Services initialized successfully")
    except Exception as e:
        logger.error(f"Failed to initialize services: {e}")
        raise
    
    logger.info("Data Governance API started successfully")
    
    yield
    
    # Shutdown
    logger.info("Shutting down Data Governance API...")
    # Cleanup resources
    logger.info("Data Governance API shutdown complete")


# Create FastAPI application
def create_application() -> FastAPI:
    """Create and configure FastAPI application."""
    settings = get_settings()
    
    # Setup logging
    setup_logging(settings.log_level)
    
    # Create FastAPI app
    app = FastAPI(
        title="Data Governance API",
        description="""
        **Enterprise Data Governance API** for managing data objects, lineage, quality, and policies.
        
        This API provides comprehensive data governance capabilities including:
        
        * **Data Catalog**: Manage data objects, schemas, and metadata
        * **Data Lineage**: Track data flow and dependencies
        * **Data Quality**: Monitor and measure data quality metrics
        * **Access Policies**: Define and enforce data access controls
        * **Analytics**: Generate insights and reports
        * **Monitoring**: Track system health and performance
        
        ## Authentication
        
        This API uses JWT tokens for authentication. Include the token in the Authorization header:
        ```
        Authorization: Bearer <your-jwt-token>
        ```
        
        ## Rate Limiting
        
        API requests are rate limited to ensure fair usage:
        - **Standard users**: 1000 requests per hour
        - **Premium users**: 5000 requests per hour
        - **Admin users**: Unlimited
        
        ## Error Handling
        
        The API follows RFC 7807 Problem Details for HTTP APIs standard for error responses.
        All errors include:
        - `detail`: Human-readable error description
        - `error_code`: Machine-readable error code
        - `timestamp`: When the error occurred
        - `request_id`: Unique request identifier for tracking
        
        ## Versioning
        
        This API uses URL path versioning. Current version is v1.
        Future versions will be available at `/api/v2/`, etc.
        """,
        version="2.0.0",
        contact={
            "name": "Data Governance Team",
            "email": "data-governance@empresa.com",
            "url": "https://docs.data-governance.com"
        },
        license_info={
            "name": "MIT License",
            "url": "https://opensource.org/licenses/MIT"
        },
        terms_of_service="https://empresa.com/terms",
        openapi_url="/api/v1/openapi.json",
        docs_url=None,  # We'll create custom docs
        redoc_url=None,  # We'll create custom redoc
        lifespan=lifespan,
        servers=[
            {
                "url": "https://api.data-governance.com",
                "description": "Production server"
            },
            {
                "url": "https://staging-api.data-governance.com",
                "description": "Staging server"
            },
            {
                "url": "http://localhost:8000",
                "description": "Development server"
            }
        ]
    )
    
    # Add middleware
    setup_middleware(app, settings)
    
    # Add exception handlers
    setup_exception_handlers(app)
    
    # Include routers
    setup_routers(app)
    
    # Setup custom OpenAPI
    setup_custom_openapi(app)
    
    return app


def setup_middleware(app: FastAPI, settings) -> None:
    """Setup application middleware."""
    
    # CORS middleware
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.allowed_origins,
        allow_credentials=True,
        allow_methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"],
        allow_headers=["*"],
        expose_headers=["X-Request-ID", "X-Rate-Limit-Remaining"]
    )
    
    # Compression middleware
    app.add_middleware(GZipMiddleware, minimum_size=1000)
    
    # Custom middleware
    app.add_middleware(RequestLoggingMiddleware)
    app.add_middleware(RequestIDMiddleware)
    app.add_middleware(RateLimitMiddleware)
    app.add_middleware(SecurityHeadersMiddleware)


def setup_exception_handlers(app: FastAPI) -> None:
    """Setup global exception handlers."""
    
    @app.exception_handler(EntityNotFoundError)
    async def entity_not_found_handler(request: Request, exc: EntityNotFoundError):
        return JSONResponse(
            status_code=status.HTTP_404_NOT_FOUND,
            content={
                "detail": str(exc),
                "error_code": "ENTITY_NOT_FOUND",
                "timestamp": time.time(),
                "request_id": getattr(request.state, "request_id", None)
            }
        )
    
    @app.exception_handler(ValidationError)
    async def validation_error_handler(request: Request, exc: ValidationError):
        return JSONResponse(
            status_code=status.HTTP_400_BAD_REQUEST,
            content={
                "detail": str(exc),
                "error_code": "VALIDATION_ERROR",
                "timestamp": time.time(),
                "request_id": getattr(request.state, "request_id", None),
                "errors": getattr(exc, "errors", None)
            }
        )
    
    @app.exception_handler(PermissionError)
    async def permission_error_handler(request: Request, exc: PermissionError):
        return JSONResponse(
            status_code=status.HTTP_403_FORBIDDEN,
            content={
                "detail": str(exc),
                "error_code": "PERMISSION_DENIED",
                "timestamp": time.time(),
                "request_id": getattr(request.state, "request_id", None)
            }
        )
    
    @app.exception_handler(BusinessRuleViolationError)
    async def business_rule_violation_handler(request: Request, exc: BusinessRuleViolationError):
        return JSONResponse(
            status_code=status.HTTP_409_CONFLICT,
            content={
                "detail": str(exc),
                "error_code": "BUSINESS_RULE_VIOLATION",
                "timestamp": time.time(),
                "request_id": getattr(request.state, "request_id", None)
            }
        )
    
    @app.exception_handler(DatabaseError)
    async def database_error_handler(request: Request, exc: DatabaseError):
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={
                "detail": "A database error occurred",
                "error_code": "DATABASE_ERROR",
                "timestamp": time.time(),
                "request_id": getattr(request.state, "request_id", None)
            }
        )
    
    @app.exception_handler(Exception)
    async def general_exception_handler(request: Request, exc: Exception):
        logger = logging.getLogger(__name__)
        logger.error(f"Unhandled exception: {exc}", exc_info=True)
        
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={
                "detail": "An unexpected error occurred",
                "error_code": "INTERNAL_SERVER_ERROR",
                "timestamp": time.time(),
                "request_id": getattr(request.state, "request_id", None)
            }
        )


def setup_routers(app: FastAPI) -> None:
    """Setup API routers."""
    
    # API v1 routes
    api_v1_prefix = "/api/v1"
    
    app.include_router(data_objects.router, prefix=api_v1_prefix)
    app.include_router(data_lineage.router, prefix=api_v1_prefix)
    app.include_router(access_policies.router, prefix=api_v1_prefix)
    app.include_router(quality_metrics.router, prefix=api_v1_prefix)
    app.include_router(analytics.router, prefix=api_v1_prefix)
    app.include_router(monitoring.router, prefix=api_v1_prefix)
    app.include_router(health.router, prefix=api_v1_prefix)
    app.include_router(sync.router, prefix=api_v1_prefix)
    app.include_router(search.router, prefix=api_v1_prefix)
    
    # Custom documentation routes
    @app.get("/docs", include_in_schema=False)
    async def custom_swagger_ui_html():
        return get_swagger_ui_html(
            openapi_url="/api/v1/openapi.json",
            title="Data Governance API - Swagger UI",
            swagger_js_url="https://cdn.jsdelivr.net/npm/swagger-ui-dist@5.9.0/swagger-ui-bundle.js",
            swagger_css_url="https://cdn.jsdelivr.net/npm/swagger-ui-dist@5.9.0/swagger-ui.css",
            swagger_favicon_url="https://fastapi.tiangolo.com/img/favicon.png"
        )
    
    @app.get("/redoc", include_in_schema=False)
    async def redoc_html():
        return get_redoc_html(
            openapi_url="/api/v1/openapi.json",
            title="Data Governance API - ReDoc",
            redoc_js_url="https://cdn.jsdelivr.net/npm/redoc@2.1.3/bundles/redoc.standalone.js"
        )
    
    # Root endpoint
    @app.get("/", include_in_schema=False)
    async def root():
        return {
            "message": "Data Governance API",
            "version": "2.0.0",
            "docs": "/docs",
            "redoc": "/redoc",
            "openapi": "/api/v1/openapi.json"
        }


def setup_custom_openapi(app: FastAPI) -> None:
    """Setup custom OpenAPI schema."""
    
    def custom_openapi():
        if app.openapi_schema:
            return app.openapi_schema
        
        openapi_schema = get_openapi(
            title=app.title,
            version=app.version,
            description=app.description,
            routes=app.routes,
            servers=app.servers
        )
        
        # Add custom security schemes
        openapi_schema["components"]["securitySchemes"] = {
            "BearerAuth": {
                "type": "http",
                "scheme": "bearer",
                "bearerFormat": "JWT",
                "description": "JWT token for authentication"
            },
            "ApiKeyAuth": {
                "type": "apiKey",
                "in": "header",
                "name": "X-API-Key",
                "description": "API key for service-to-service authentication"
            }
        }
        
        # Add global security requirement
        openapi_schema["security"] = [
            {"BearerAuth": []},
            {"ApiKeyAuth": []}
        ]
        
        # Add custom response schemas
        openapi_schema["components"]["schemas"]["ErrorResponse"] = {
            "type": "object",
            "properties": {
                "detail": {"type": "string", "description": "Error description"},
                "error_code": {"type": "string", "description": "Machine-readable error code"},
                "timestamp": {"type": "number", "description": "Error timestamp"},
                "request_id": {"type": "string", "description": "Request ID for tracking"},
                "errors": {
                    "type": "array",
                    "items": {"type": "object"},
                    "description": "Detailed validation errors"
                }
            },
            "required": ["detail", "error_code", "timestamp"]
        }
        
        # Add rate limiting headers
        for path in openapi_schema["paths"].values():
            for method in path.values():
                if isinstance(method, dict) and "responses" in method:
                    for response in method["responses"].values():
                        if "headers" not in response:
                            response["headers"] = {}
                        response["headers"].update({
                            "X-Rate-Limit-Remaining": {
                                "description": "Number of requests remaining in the current window",
                                "schema": {"type": "integer"}
                            },
                            "X-Request-ID": {
                                "description": "Unique request identifier",
                                "schema": {"type": "string"}
                            }
                        })
        
        app.openapi_schema = openapi_schema
        return app.openapi_schema
    
    app.openapi = custom_openapi


# Custom middleware classes
class RequestLoggingMiddleware(BaseHTTPMiddleware):
    """Middleware for request/response logging."""
    
    async def dispatch(self, request: Request, call_next):
        start_time = time.time()
        logger = logging.getLogger("api.requests")
        
        # Log request
        logger.info(f"Request: {request.method} {request.url}")
        
        response = await call_next(request)
        
        # Log response
        process_time = time.time() - start_time
        logger.info(f"Response: {response.status_code} - {process_time:.3f}s")
        
        response.headers["X-Process-Time"] = str(process_time)
        return response


class RequestIDMiddleware(BaseHTTPMiddleware):
    """Middleware for adding request IDs."""
    
    async def dispatch(self, request: Request, call_next):
        import uuid
        request_id = str(uuid.uuid4())
        request.state.request_id = request_id
        
        response = await call_next(request)
        response.headers["X-Request-ID"] = request_id
        return response


class RateLimitMiddleware(BaseHTTPMiddleware):
    """Middleware for rate limiting."""
    
    async def dispatch(self, request: Request, call_next):
        # Implement rate limiting logic here
        # For now, just pass through
        response = await call_next(request)
        response.headers["X-Rate-Limit-Remaining"] = "999"
        return response


class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    """Middleware for adding security headers."""
    
    async def dispatch(self, request: Request, call_next):
        response = await call_next(request)
        
        # Add security headers
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["X-XSS-Protection"] = "1; mode=block"
        response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        
        return response


# Create the application instance
app = create_application()


# Health check endpoint
@app.get("/health", tags=["Health"], include_in_schema=False)
async def health_check():
    """Simple health check endpoint."""
    return {"status": "healthy", "timestamp": time.time()}


if __name__ == "__main__":
    import uvicorn
    
    settings = get_settings()
    uvicorn.run(
        "main:app",
        host=settings.host,
        port=settings.port,
        reload=settings.debug,
        log_level=settings.log_level.lower()
    )

