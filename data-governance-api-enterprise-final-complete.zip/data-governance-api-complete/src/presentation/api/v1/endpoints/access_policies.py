"""
FastAPI Endpoints for Access Policies Management.
Following SOLID principles and enterprise patterns.

Author: Carlos Morais
"""

from typing import List, Optional, Dict, Any
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status, Query, Body, Path
from fastapi.responses import JSONResponse

from ....application.use_cases.policies import (
    CreatePolicyUseCase, GetPolicyUseCase, UpdatePolicyUseCase,
    DeletePolicyUseCase, GetPoliciesUseCase, EvaluateAccessUseCase,
    GetComplianceReportUseCase, EnforcePoliciesUseCase,
    GetViolationsUseCase, SimulatePolicyUseCase
)
from ....application.dtos.policies import (
    PolicyCreateDTO, PolicyUpdateDTO, PolicyResponseDTO,
    AccessEvaluationRequestDTO, AccessEvaluationResponseDTO,
    ComplianceReportDTO, PolicyEnforcementDTO,
    PolicyViolationDTO, PolicySimulationDTO
)
from ....application.exceptions.advanced_exceptions import (
    EntityNotFoundError, ValidationError, BusinessRuleViolationError,
    AuthorizationError
)
from ...dependencies import (
    get_create_policy_use_case, get_get_policy_use_case,
    get_update_policy_use_case, get_delete_policy_use_case,
    get_policies_use_case, get_current_user
)


router = APIRouter(
    prefix="/policies",
    tags=["Access Policies"],
    responses={
        400: {"description": "Bad Request"},
        401: {"description": "Unauthorized"},
        403: {"description": "Forbidden"},
        404: {"description": "Not Found"},
        409: {"description": "Conflict"},
        500: {"description": "Internal Server Error"}
    }
)


@router.post(
    "/",
    response_model=PolicyResponseDTO,
    status_code=status.HTTP_201_CREATED,
    summary="Create Access Policy",
    description="""
    Creates a new access policy for data governance.
    
    **Policy Types:**
    - Row-level security policies
    - Column masking policies
    - Data classification policies
    - Retention policies
    - Access control policies
    
    **Features:**
    - RBAC integration
    - ABAC support
    - Dynamic policy evaluation
    - Compliance framework mapping
    - Audit trail
    """,
    operation_id="create_access_policy"
)
async def create_access_policy(
    policy_dto: PolicyCreateDTO = Body(
        ...,
        description="Access policy data",
        example={
            "name": "PII Data Masking Policy",
            "description": "Masks PII data for non-privileged users",
            "policy_type": "column_masking",
            "scope": "table",
            "target_objects": ["customer_table", "employee_table"],
            "conditions": {
                "user_roles": ["analyst", "developer"],
                "data_classification": ["PII", "sensitive"]
            },
            "actions": {
                "mask_type": "partial",
                "mask_pattern": "***-**-{last_4}",
                "columns": ["ssn", "phone", "email"]
            },
            "compliance_frameworks": ["GDPR", "LGPD"],
            "is_active": True,
            "priority": 100
        }
    ),
    use_case: CreatePolicyUseCase = Depends(get_create_policy_use_case),
    current_user: dict = Depends(get_current_user)
) -> PolicyResponseDTO:
    """Create a new access policy."""
    try:
        policy_dto.created_by = current_user.get("user_id")
        created_policy = await use_case.execute(policy_dto)
        return created_policy
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except BusinessRuleViolationError as e:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(e))
    except AuthorizationError as e:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=str(e))


@router.get(
    "/{policy_id}",
    response_model=PolicyResponseDTO,
    summary="Get Access Policy",
    description="Retrieves a specific access policy by its ID.",
    operation_id="get_access_policy"
)
async def get_access_policy(
    policy_id: UUID = Path(..., description="Unique ID of the access policy"),
    use_case: GetPolicyUseCase = Depends(get_get_policy_use_case)
) -> PolicyResponseDTO:
    """Get an access policy by ID."""
    try:
        policy = await use_case.execute(policy_id)
        return policy
    except EntityNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))


@router.put(
    "/{policy_id}",
    response_model=PolicyResponseDTO,
    summary="Update Access Policy",
    description="Updates an existing access policy.",
    operation_id="update_access_policy"
)
async def update_access_policy(
    policy_id: UUID = Path(..., description="Unique ID of the access policy"),
    update_dto: PolicyUpdateDTO = Body(..., description="Updated policy data"),
    use_case: UpdatePolicyUseCase = Depends(get_update_policy_use_case),
    current_user: dict = Depends(get_current_user)
) -> PolicyResponseDTO:
    """Update an access policy."""
    try:
        updated_policy = await use_case.execute(policy_id, update_dto, current_user)
        return updated_policy
    except EntityNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except AuthorizationError as e:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=str(e))


@router.delete(
    "/{policy_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete Access Policy",
    description="Deletes an access policy (soft delete).",
    operation_id="delete_access_policy"
)
async def delete_access_policy(
    policy_id: UUID = Path(..., description="Unique ID of the access policy"),
    use_case: DeletePolicyUseCase = Depends(get_delete_policy_use_case),
    current_user: dict = Depends(get_current_user)
) -> None:
    """Delete an access policy."""
    try:
        await use_case.execute(policy_id, current_user)
    except EntityNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except AuthorizationError as e:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=str(e))


@router.get(
    "/",
    response_model=List[PolicyResponseDTO],
    summary="Get Access Policies",
    description="""
    Retrieves access policies with filtering and pagination.
    
    **Filtering options:**
    - Policy type
    - Compliance framework
    - Active status
    - Target objects
    - Priority range
    """,
    operation_id="get_access_policies"
)
async def get_access_policies(
    policy_type: Optional[str] = Query(None, description="Filter by policy type"),
    compliance_framework: Optional[str] = Query(None, description="Filter by compliance framework"),
    is_active: Optional[bool] = Query(None, description="Filter by active status"),
    target_object: Optional[str] = Query(None, description="Filter by target object"),
    min_priority: Optional[int] = Query(None, description="Minimum priority"),
    max_priority: Optional[int] = Query(None, description="Maximum priority"),
    limit: int = Query(100, ge=1, le=1000, description="Maximum number of results"),
    offset: int = Query(0, ge=0, description="Number of results to skip"),
    use_case: GetPoliciesUseCase = Depends(get_policies_use_case)
) -> List[PolicyResponseDTO]:
    """Get access policies with filtering."""
    try:
        policies = await use_case.execute(
            policy_type=policy_type,
            compliance_framework=compliance_framework,
            is_active=is_active,
            target_object=target_object,
            min_priority=min_priority,
            max_priority=max_priority,
            limit=limit,
            offset=offset
        )
        return policies
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))


@router.post(
    "/evaluate",
    response_model=AccessEvaluationResponseDTO,
    summary="Evaluate Access Request",
    description="""
    Evaluates an access request against all applicable policies.
    
    **Evaluation process:**
    1. Policy discovery based on context
    2. Condition evaluation
    3. Action determination
    4. Conflict resolution
    5. Decision rendering
    
    **Response includes:**
    - Access decision (allow/deny/conditional)
    - Applied policies
    - Required actions (masking, filtering)
    - Audit information
    """,
    operation_id="evaluate_access_request"
)
async def evaluate_access_request(
    evaluation_request: AccessEvaluationRequestDTO = Body(
        ...,
        description="Access evaluation request",
        example={
            "user_id": "user123",
            "user_roles": ["analyst", "data_scientist"],
            "user_attributes": {
                "department": "marketing",
                "clearance_level": "standard"
            },
            "resource_type": "table",
            "resource_id": "customer_table",
            "action": "select",
            "context": {
                "time": "2024-12-01T10:00:00Z",
                "location": "office",
                "purpose": "analytics"
            }
        }
    ),
    use_case: EvaluateAccessUseCase = Depends(get_evaluate_access_use_case)
) -> AccessEvaluationResponseDTO:
    """Evaluate access request against policies."""
    try:
        evaluation_result = await use_case.execute(evaluation_request)
        return evaluation_result
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except AuthorizationError as e:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=str(e))


@router.get(
    "/compliance",
    response_model=ComplianceReportDTO,
    summary="Get Compliance Report",
    description="""
    Generates a comprehensive compliance report.
    
    **Report includes:**
    - Policy coverage analysis
    - Compliance framework mapping
    - Gap analysis
    - Risk assessment
    - Remediation recommendations
    """,
    operation_id="get_compliance_report"
)
async def get_compliance_report(
    framework: Optional[str] = Query(None, description="Specific compliance framework"),
    scope: str = Query("organization", description="Report scope"),
    include_details: bool = Query(True, description="Include detailed analysis"),
    use_case: GetComplianceReportUseCase = Depends(get_compliance_report_use_case)
) -> ComplianceReportDTO:
    """Get compliance report."""
    try:
        report = await use_case.execute(
            framework=framework,
            scope=scope,
            include_details=include_details
        )
        return report
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))


@router.post(
    "/enforce",
    response_model=PolicyEnforcementDTO,
    summary="Enforce Policies",
    description="""
    Triggers policy enforcement across the data platform.
    
    **Enforcement actions:**
    - Apply masking rules
    - Update access controls
    - Sync with external systems
    - Generate audit logs
    """,
    operation_id="enforce_policies"
)
async def enforce_policies(
    policy_ids: Optional[List[UUID]] = Body(None, description="Specific policies to enforce"),
    scope: str = Body("all", description="Enforcement scope"),
    dry_run: bool = Body(False, description="Perform dry run without changes"),
    use_case: EnforcePoliciesUseCase = Depends(get_enforce_policies_use_case),
    current_user: dict = Depends(get_current_user)
) -> PolicyEnforcementDTO:
    """Enforce policies."""
    try:
        enforcement_result = await use_case.execute(
            policy_ids=policy_ids,
            scope=scope,
            dry_run=dry_run,
            current_user=current_user
        )
        return enforcement_result
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except AuthorizationError as e:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=str(e))


@router.get(
    "/violations",
    response_model=List[PolicyViolationDTO],
    summary="Get Policy Violations",
    description="""
    Retrieves policy violations and compliance issues.
    
    **Violation types:**
    - Access violations
    - Data usage violations
    - Retention violations
    - Classification violations
    """,
    operation_id="get_policy_violations"
)
async def get_policy_violations(
    severity: Optional[str] = Query(None, description="Filter by severity"),
    policy_id: Optional[UUID] = Query(None, description="Filter by policy"),
    resource_id: Optional[str] = Query(None, description="Filter by resource"),
    status: Optional[str] = Query("open", description="Filter by violation status"),
    days_back: int = Query(30, ge=1, le=365, description="Days to look back"),
    limit: int = Query(100, ge=1, le=1000, description="Maximum number of results"),
    use_case: GetViolationsUseCase = Depends(get_violations_use_case)
) -> List[PolicyViolationDTO]:
    """Get policy violations."""
    try:
        violations = await use_case.execute(
            severity=severity,
            policy_id=policy_id,
            resource_id=resource_id,
            status=status,
            days_back=days_back,
            limit=limit
        )
        return violations
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))


@router.post(
    "/simulate",
    response_model=PolicySimulationDTO,
    summary="Simulate Policy",
    description="""
    Simulates the impact of a policy before implementation.
    
    **Simulation includes:**
    - Affected resources analysis
    - Impact assessment
    - Performance implications
    - Conflict detection
    - Rollback planning
    """,
    operation_id="simulate_policy"
)
async def simulate_policy(
    policy_dto: PolicyCreateDTO = Body(..., description="Policy to simulate"),
    simulation_scope: str = Body("limited", description="Simulation scope"),
    include_performance: bool = Body(True, description="Include performance analysis"),
    use_case: SimulatePolicyUseCase = Depends(get_simulate_policy_use_case),
    current_user: dict = Depends(get_current_user)
) -> PolicySimulationDTO:
    """Simulate policy impact."""
    try:
        simulation_result = await use_case.execute(
            policy_dto=policy_dto,
            simulation_scope=simulation_scope,
            include_performance=include_performance,
            current_user=current_user
        )
        return simulation_result
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except AuthorizationError as e:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=str(e))

