"""
FastAPI Endpoints for Data Lineage Management.
Following SOLID principles and enterprise patterns.

Author: Carlos Morais
"""

from typing import List, Optional, Dict, Any
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status, Query, Body, Path
from fastapi.responses import JSONResponse

from ....application.use_cases.lineage import (
    CreateLineageUseCase, GetLineageUseCase, UpdateLineageUseCase,
    DeleteLineageUseCase, GetLineageGraphUseCase, GetUpstreamLineageUseCase,
    GetDownstreamLineageUseCase, AnalyzeImpactUseCase, BulkCreateLineageUseCase,
    GetLineageByJobUseCase, DiscoverLineageUseCase, GetLineageByConfidenceUseCase,
    GetLineageTypesUseCase, ValidateLineageUseCase, GetLineageStatisticsUseCase
)
from ....application.dtos.lineage import (
    LineageCreateDTO, LineageUpdateDTO, LineageResponseDTO,
    LineageGraphDTO, ImpactAnalysisDTO, BulkLineageCreateDTO,
    LineageDiscoveryRequestDTO, LineageStatisticsDTO
)
from ....application.exceptions.advanced_exceptions import (
    EntityNotFoundError, ValidationError, BusinessRuleViolationError,
    AuthorizationError
)
from ...dependencies import (
    get_create_lineage_use_case, get_get_lineage_use_case,
    get_update_lineage_use_case, get_delete_lineage_use_case,
    get_lineage_graph_use_case, get_current_user
)


router = APIRouter(
    prefix="/lineage",
    tags=["Data Lineage"],
    responses={
        400: {"description": "Bad Request"},
        401: {"description": "Unauthorized"},
        403: {"description": "Forbidden"},
        404: {"description": "Not Found"},
        409: {"description": "Conflict"},
        500: {"description": "Internal Server Error"}
    }
)


@router.post(
    "/",
    response_model=LineageResponseDTO,
    status_code=status.HTTP_201_CREATED,
    summary="Create Data Lineage Relationship",
    description="""
    Creates a new data lineage relationship between source and target objects.
    
    **Features:**
    - Validates source and target objects exist
    - Calculates confidence score if not provided
    - Prevents circular dependencies
    - Supports various lineage types (table-to-table, column-to-column, etc.)
    
    **Business Rules:**
    - Source and target must be different objects
    - Confidence score must be between 0.0 and 1.0
    - Lineage type must be valid for the object types
    """,
    operation_id="create_lineage_relationship"
)
async def create_lineage_relationship(
    lineage_dto: LineageCreateDTO = Body(
        ...,
        description="Lineage relationship data",
        example={
            "source_object_id": "123e4567-e89b-12d3-a456-426614174000",
            "target_object_id": "123e4567-e89b-12d3-a456-426614174001",
            "lineage_type": "table_to_table",
            "transformation_logic": "SELECT * FROM source_table WHERE active = true",
            "job_id": "job_123",
            "job_name": "ETL Pipeline",
            "confidence_score": 0.95,
            "discovered_by": "automated"
        }
    ),
    use_case: CreateLineageUseCase = Depends(get_create_lineage_use_case),
    current_user: dict = Depends(get_current_user)
) -> LineageResponseDTO:
    """Create a new data lineage relationship."""
    try:
        # Add user context
        lineage_dto.created_by = current_user.get("user_id")
        
        created_lineage = await use_case.execute(lineage_dto)
        return created_lineage
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except BusinessRuleViolationError as e:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(e))
    except AuthorizationError as e:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=str(e))


@router.get(
    "/{lineage_id}",
    response_model=LineageResponseDTO,
    summary="Get Lineage Relationship",
    description="Retrieves a specific lineage relationship by its ID.",
    operation_id="get_lineage_relationship"
)
async def get_lineage_relationship(
    lineage_id: UUID = Path(..., description="Unique ID of the lineage relationship"),
    use_case: GetLineageUseCase = Depends(get_get_lineage_use_case)
) -> LineageResponseDTO:
    """Get a lineage relationship by ID."""
    try:
        lineage = await use_case.execute(lineage_id)
        return lineage
    except EntityNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))


@router.put(
    "/{lineage_id}",
    response_model=LineageResponseDTO,
    summary="Update Lineage Relationship",
    description="Updates an existing lineage relationship.",
    operation_id="update_lineage_relationship"
)
async def update_lineage_relationship(
    lineage_id: UUID = Path(..., description="Unique ID of the lineage relationship"),
    update_dto: LineageUpdateDTO = Body(..., description="Updated lineage data"),
    use_case: UpdateLineageUseCase = Depends(get_update_lineage_use_case),
    current_user: dict = Depends(get_current_user)
) -> LineageResponseDTO:
    """Update a lineage relationship."""
    try:
        updated_lineage = await use_case.execute(lineage_id, update_dto, current_user)
        return updated_lineage
    except EntityNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except AuthorizationError as e:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=str(e))


@router.delete(
    "/{lineage_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete Lineage Relationship",
    description="Deletes a lineage relationship (soft delete).",
    operation_id="delete_lineage_relationship"
)
async def delete_lineage_relationship(
    lineage_id: UUID = Path(..., description="Unique ID of the lineage relationship"),
    use_case: DeleteLineageUseCase = Depends(get_delete_lineage_use_case),
    current_user: dict = Depends(get_current_user)
) -> None:
    """Delete a lineage relationship."""
    try:
        await use_case.execute(lineage_id, current_user)
    except EntityNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except AuthorizationError as e:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=str(e))


@router.get(
    "/graph/{object_id}",
    response_model=LineageGraphDTO,
    summary="Get Lineage Graph",
    description="""
    Retrieves the complete lineage graph for a data object.
    
    **Features:**
    - Configurable depth for upstream and downstream
    - Interactive graph representation
    - Node and edge metadata
    - Performance optimized for large graphs
    """,
    operation_id="get_lineage_graph"
)
async def get_lineage_graph(
    object_id: UUID = Path(..., description="Data object ID to get lineage for"),
    max_depth: int = Query(3, ge=1, le=10, description="Maximum depth to traverse"),
    include_upstream: bool = Query(True, description="Include upstream lineage"),
    include_downstream: bool = Query(True, description="Include downstream lineage"),
    min_confidence: float = Query(0.0, ge=0.0, le=1.0, description="Minimum confidence score"),
    use_case: GetLineageGraphUseCase = Depends(get_lineage_graph_use_case)
) -> LineageGraphDTO:
    """Get lineage graph for a data object."""
    try:
        graph = await use_case.execute(
            object_id=object_id,
            max_depth=max_depth,
            include_upstream=include_upstream,
            include_downstream=include_downstream,
            min_confidence=min_confidence
        )
        return graph
    except EntityNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))


@router.get(
    "/upstream/{object_id}",
    response_model=List[LineageResponseDTO],
    summary="Get Upstream Lineage",
    description="Retrieves all upstream lineage relationships for a data object.",
    operation_id="get_upstream_lineage"
)
async def get_upstream_lineage(
    object_id: UUID = Path(..., description="Data object ID"),
    max_depth: int = Query(5, ge=1, le=10, description="Maximum depth to traverse"),
    use_case: GetUpstreamLineageUseCase = Depends(get_upstream_lineage_use_case)
) -> List[LineageResponseDTO]:
    """Get upstream lineage for a data object."""
    try:
        upstream_lineage = await use_case.execute(object_id, max_depth)
        return upstream_lineage
    except EntityNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))


@router.get(
    "/downstream/{object_id}",
    response_model=List[LineageResponseDTO],
    summary="Get Downstream Lineage",
    description="Retrieves all downstream lineage relationships for a data object.",
    operation_id="get_downstream_lineage"
)
async def get_downstream_lineage(
    object_id: UUID = Path(..., description="Data object ID"),
    max_depth: int = Query(5, ge=1, le=10, description="Maximum depth to traverse"),
    use_case: GetDownstreamLineageUseCase = Depends(get_downstream_lineage_use_case)
) -> List[LineageResponseDTO]:
    """Get downstream lineage for a data object."""
    try:
        downstream_lineage = await use_case.execute(object_id, max_depth)
        return downstream_lineage
    except EntityNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))


@router.get(
    "/impact/{object_id}",
    response_model=ImpactAnalysisDTO,
    summary="Analyze Impact",
    description="""
    Performs impact analysis for changes to a data object.
    
    **Analysis includes:**
    - Affected downstream objects
    - Impact severity assessment
    - Recommended actions
    - Risk assessment
    """,
    operation_id="analyze_impact"
)
async def analyze_impact(
    object_id: UUID = Path(..., description="Data object ID to analyze"),
    change_type: str = Query("schema_change", description="Type of change"),
    use_case: AnalyzeImpactUseCase = Depends(get_analyze_impact_use_case)
) -> ImpactAnalysisDTO:
    """Analyze impact of changes to a data object."""
    try:
        impact_analysis = await use_case.execute(object_id, change_type)
        return impact_analysis
    except EntityNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))


@router.post(
    "/bulk",
    response_model=List[LineageResponseDTO],
    status_code=status.HTTP_201_CREATED,
    summary="Bulk Create Lineage",
    description="Creates multiple lineage relationships in a single operation.",
    operation_id="bulk_create_lineage"
)
async def bulk_create_lineage(
    bulk_dto: BulkLineageCreateDTO = Body(..., description="Bulk lineage creation data"),
    use_case: BulkCreateLineageUseCase = Depends(get_bulk_create_lineage_use_case),
    current_user: dict = Depends(get_current_user)
) -> List[LineageResponseDTO]:
    """Create multiple lineage relationships."""
    try:
        created_lineages = await use_case.execute(bulk_dto, current_user)
        return created_lineages
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except BusinessRuleViolationError as e:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(e))


@router.get(
    "/jobs/{job_id}",
    response_model=List[LineageResponseDTO],
    summary="Get Lineage by Job",
    description="Retrieves all lineage relationships created by a specific job.",
    operation_id="get_lineage_by_job"
)
async def get_lineage_by_job(
    job_id: str = Path(..., description="Job ID"),
    use_case: GetLineageByJobUseCase = Depends(get_lineage_by_job_use_case)
) -> List[LineageResponseDTO]:
    """Get lineage relationships by job ID."""
    try:
        job_lineages = await use_case.execute(job_id)
        return job_lineages
    except EntityNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))


@router.post(
    "/discover",
    response_model=List[LineageResponseDTO],
    summary="Discover Lineage",
    description="""
    Automatically discovers lineage relationships from execution logs and metadata.
    
    **Discovery methods:**
    - SQL query parsing
    - Job execution logs
    - Metadata analysis
    - Pattern recognition
    """,
    operation_id="discover_lineage"
)
async def discover_lineage(
    discovery_request: LineageDiscoveryRequestDTO = Body(..., description="Discovery parameters"),
    use_case: DiscoverLineageUseCase = Depends(get_discover_lineage_use_case),
    current_user: dict = Depends(get_current_user)
) -> List[LineageResponseDTO]:
    """Discover lineage relationships automatically."""
    try:
        discovered_lineages = await use_case.execute(discovery_request, current_user)
        return discovered_lineages
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))


@router.get(
    "/confidence/{threshold}",
    response_model=List[LineageResponseDTO],
    summary="Get Lineage by Confidence",
    description="Retrieves lineage relationships above a confidence threshold.",
    operation_id="get_lineage_by_confidence"
)
async def get_lineage_by_confidence(
    threshold: float = Path(..., ge=0.0, le=1.0, description="Minimum confidence score"),
    limit: int = Query(100, ge=1, le=1000, description="Maximum number of results"),
    use_case: GetLineageByConfidenceUseCase = Depends(get_lineage_by_confidence_use_case)
) -> List[LineageResponseDTO]:
    """Get lineage relationships by confidence threshold."""
    try:
        high_confidence_lineages = await use_case.execute(threshold, limit)
        return high_confidence_lineages
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))


@router.get(
    "/types",
    response_model=List[str],
    summary="Get Lineage Types",
    description="Retrieves all available lineage types in the system.",
    operation_id="get_lineage_types"
)
async def get_lineage_types(
    use_case: GetLineageTypesUseCase = Depends(get_lineage_types_use_case)
) -> List[str]:
    """Get all available lineage types."""
    try:
        lineage_types = await use_case.execute()
        return lineage_types
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))


@router.post(
    "/validate",
    response_model=Dict[str, Any],
    summary="Validate Lineage",
    description="""
    Validates lineage relationships for consistency and accuracy.
    
    **Validation checks:**
    - Circular dependency detection
    - Orphaned relationships
    - Confidence score validation
    - Business rule compliance
    """,
    operation_id="validate_lineage"
)
async def validate_lineage(
    object_ids: List[UUID] = Body(..., description="Object IDs to validate"),
    use_case: ValidateLineageUseCase = Depends(get_validate_lineage_use_case)
) -> Dict[str, Any]:
    """Validate lineage relationships."""
    try:
        validation_result = await use_case.execute(object_ids)
        return validation_result
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))


@router.get(
    "/statistics",
    response_model=LineageStatisticsDTO,
    summary="Get Lineage Statistics",
    description="""
    Retrieves comprehensive statistics about lineage in the system.
    
    **Statistics include:**
    - Total lineage relationships
    - Coverage by object type
    - Confidence distribution
    - Discovery method breakdown
    """,
    operation_id="get_lineage_statistics"
)
async def get_lineage_statistics(
    use_case: GetLineageStatisticsUseCase = Depends(get_lineage_statistics_use_case)
) -> LineageStatisticsDTO:
    """Get lineage statistics."""
    try:
        statistics = await use_case.execute()
        return statistics
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

