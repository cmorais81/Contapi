"""
FastAPI Endpoints for Analytics & Reporting.
Following SOLID principles and enterprise patterns.

Author: Carlos Morais
"""

from typing import List, Optional, Dict, Any
from uuid import UUID
from datetime import datetime, date

from fastapi import APIRouter, Depends, HTTPException, status, Query, Body, Path
from fastapi.responses import JSONResponse, StreamingResponse

from ....application.use_cases.analytics import (
    GetDashboardUseCase, GetUsageAnalyticsUseCase, GetCostAnalyticsUseCase,
    GetPerformanceAnalyticsUseCase, GetAdoptionAnalyticsUseCase,
    GetQualityTrendsAnalyticsUseCase, GetLineageCoverageUseCase,
    GetComplianceStatusUseCase, GenerateReportUseCase, GetReportUseCase,
    GetReportTemplatesUseCase, ScheduleReportUseCase, GetScheduledReportsUseCase,
    ExportAnalyticsUseCase, GetGovernanceKPIsUseCase
)
from ....application.dtos.analytics import (
    DashboardDTO, UsageAnalyticsDTO, CostAnalyticsDTO,
    PerformanceAnalyticsDTO, AdoptionAnalyticsDTO, QualityTrendsAnalyticsDTO,
    LineageCoverageDTO, ComplianceStatusDTO, ReportGenerationRequestDTO,
    ReportResponseDTO, ReportTemplateDTO, ReportScheduleDTO,
    ExportRequestDTO, GovernanceKPIsDTO
)
from ....application.exceptions.advanced_exceptions import (
    EntityNotFoundError, ValidationError, BusinessRuleViolationError,
    AuthorizationError
)
from ...dependencies import (
    get_dashboard_use_case, get_usage_analytics_use_case,
    get_cost_analytics_use_case, get_performance_analytics_use_case,
    get_current_user
)


router = APIRouter(
    prefix="/analytics",
    tags=["Analytics & Reporting"],
    responses={
        400: {"description": "Bad Request"},
        401: {"description": "Unauthorized"},
        403: {"description": "Forbidden"},
        404: {"description": "Not Found"},
        500: {"description": "Internal Server Error"}
    }
)


@router.get(
    "/dashboard",
    response_model=DashboardDTO,
    summary="Get Executive Dashboard",
    description="""
    Retrieves the executive dashboard with key governance metrics.
    
    **Dashboard includes:**
    - Data quality overview
    - Lineage coverage metrics
    - Compliance status
    - Usage statistics
    - Cost optimization insights
    - Trend indicators
    - Alert summaries
    """,
    operation_id="get_executive_dashboard"
)
async def get_executive_dashboard(
    time_period: str = Query("last_30_days", description="Time period for metrics"),
    include_trends: bool = Query(True, description="Include trend analysis"),
    dashboard_type: str = Query("executive", description="Dashboard type"),
    use_case: GetDashboardUseCase = Depends(get_dashboard_use_case)
) -> DashboardDTO:
    """Get executive dashboard."""
    try:
        dashboard = await use_case.execute(
            time_period=time_period,
            include_trends=include_trends,
            dashboard_type=dashboard_type
        )
        return dashboard
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))


@router.get(
    "/usage",
    response_model=UsageAnalyticsDTO,
    summary="Get Usage Analytics",
    description="""
    Retrieves comprehensive usage analytics for data assets.
    
    **Analytics include:**
    - Data access patterns
    - User activity metrics
    - Popular datasets
    - Query frequency
    - Peak usage times
    - Geographic distribution
    """,
    operation_id="get_usage_analytics"
)
async def get_usage_analytics(
    start_date: Optional[date] = Query(None, description="Start date for analysis"),
    end_date: Optional[date] = Query(None, description="End date for analysis"),
    granularity: str = Query("daily", description="Data granularity"),
    object_type: Optional[str] = Query(None, description="Filter by object type"),
    user_segment: Optional[str] = Query(None, description="Filter by user segment"),
    use_case: GetUsageAnalyticsUseCase = Depends(get_usage_analytics_use_case)
) -> UsageAnalyticsDTO:
    """Get usage analytics."""
    try:
        analytics = await use_case.execute(
            start_date=start_date,
            end_date=end_date,
            granularity=granularity,
            object_type=object_type,
            user_segment=user_segment
        )
        return analytics
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))


@router.get(
    "/costs",
    response_model=CostAnalyticsDTO,
    summary="Get Cost Analytics",
    description="""
    Retrieves cost analytics and optimization recommendations.
    
    **Cost analysis includes:**
    - Storage costs by data type
    - Compute costs by workload
    - Data transfer costs
    - Optimization opportunities
    - Cost trends and forecasts
    - ROI analysis
    """,
    operation_id="get_cost_analytics"
)
async def get_cost_analytics(
    time_period: str = Query("last_30_days", description="Time period for analysis"),
    cost_center: Optional[str] = Query(None, description="Filter by cost center"),
    include_forecasts: bool = Query(True, description="Include cost forecasts"),
    include_recommendations: bool = Query(True, description="Include optimization recommendations"),
    use_case: GetCostAnalyticsUseCase = Depends(get_cost_analytics_use_case)
) -> CostAnalyticsDTO:
    """Get cost analytics."""
    try:
        analytics = await use_case.execute(
            time_period=time_period,
            cost_center=cost_center,
            include_forecasts=include_forecasts,
            include_recommendations=include_recommendations
        )
        return analytics
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))


@router.get(
    "/performance",
    response_model=PerformanceAnalyticsDTO,
    summary="Get Performance Analytics",
    description="""
    Retrieves performance analytics for data operations.
    
    **Performance metrics include:**
    - Query execution times
    - Data pipeline performance
    - System resource utilization
    - Bottleneck identification
    - Performance trends
    - SLA compliance
    """,
    operation_id="get_performance_analytics"
)
async def get_performance_analytics(
    metric_type: str = Query("all", description="Type of performance metrics"),
    time_window: str = Query("last_24_hours", description="Time window for analysis"),
    include_details: bool = Query(True, description="Include detailed breakdowns"),
    use_case: GetPerformanceAnalyticsUseCase = Depends(get_performance_analytics_use_case)
) -> PerformanceAnalyticsDTO:
    """Get performance analytics."""
    try:
        analytics = await use_case.execute(
            metric_type=metric_type,
            time_window=time_window,
            include_details=include_details
        )
        return analytics
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))


@router.get(
    "/adoption",
    response_model=AdoptionAnalyticsDTO,
    summary="Get Adoption Analytics",
    description="""
    Retrieves data adoption and engagement analytics.
    
    **Adoption metrics include:**
    - User onboarding rates
    - Feature adoption
    - Data discovery patterns
    - Self-service usage
    - Training effectiveness
    - Engagement scores
    """,
    operation_id="get_adoption_analytics"
)
async def get_adoption_analytics(
    segment: str = Query("all_users", description="User segment for analysis"),
    time_period: str = Query("last_90_days", description="Time period for analysis"),
    include_cohorts: bool = Query(True, description="Include cohort analysis"),
    use_case: GetAdoptionAnalyticsUseCase = Depends(get_adoption_analytics_use_case)
) -> AdoptionAnalyticsDTO:
    """Get adoption analytics."""
    try:
        analytics = await use_case.execute(
            segment=segment,
            time_period=time_period,
            include_cohorts=include_cohorts
        )
        return analytics
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))


@router.get(
    "/quality-trends",
    response_model=QualityTrendsAnalyticsDTO,
    summary="Get Quality Trends Analytics",
    description="""
    Retrieves quality trends and patterns across the data estate.
    
    **Quality analytics include:**
    - Quality score trends
    - Dimension-specific analysis
    - Anomaly detection
    - Improvement opportunities
    - Quality forecasts
    """,
    operation_id="get_quality_trends_analytics"
)
async def get_quality_trends_analytics(
    time_range: str = Query("last_6_months", description="Time range for trends"),
    dimension: Optional[str] = Query(None, description="Specific quality dimension"),
    object_type: Optional[str] = Query(None, description="Filter by object type"),
    use_case: GetQualityTrendsAnalyticsUseCase = Depends(get_quality_trends_analytics_use_case)
) -> QualityTrendsAnalyticsDTO:
    """Get quality trends analytics."""
    try:
        analytics = await use_case.execute(
            time_range=time_range,
            dimension=dimension,
            object_type=object_type
        )
        return analytics
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))


@router.get(
    "/lineage-coverage",
    response_model=LineageCoverageDTO,
    summary="Get Lineage Coverage Analytics",
    description="""
    Retrieves lineage coverage analytics and gap analysis.
    
    **Coverage analytics include:**
    - Overall coverage percentage
    - Coverage by data domain
    - Gap identification
    - Confidence distribution
    - Discovery opportunities
    """,
    operation_id="get_lineage_coverage_analytics"
)
async def get_lineage_coverage_analytics(
    scope: str = Query("organization", description="Analysis scope"),
    include_gaps: bool = Query(True, description="Include gap analysis"),
    use_case: GetLineageCoverageUseCase = Depends(get_lineage_coverage_use_case)
) -> LineageCoverageDTO:
    """Get lineage coverage analytics."""
    try:
        coverage = await use_case.execute(
            scope=scope,
            include_gaps=include_gaps
        )
        return coverage
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))


@router.get(
    "/compliance-status",
    response_model=ComplianceStatusDTO,
    summary="Get Compliance Status Analytics",
    description="""
    Retrieves compliance status and regulatory analytics.
    
    **Compliance analytics include:**
    - Framework compliance scores
    - Policy coverage analysis
    - Violation trends
    - Risk assessment
    - Remediation tracking
    """,
    operation_id="get_compliance_status_analytics"
)
async def get_compliance_status_analytics(
    framework: Optional[str] = Query(None, description="Specific compliance framework"),
    include_trends: bool = Query(True, description="Include trend analysis"),
    use_case: GetComplianceStatusUseCase = Depends(get_compliance_status_use_case)
) -> ComplianceStatusDTO:
    """Get compliance status analytics."""
    try:
        status = await use_case.execute(
            framework=framework,
            include_trends=include_trends
        )
        return status
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))


@router.get(
    "/kpis",
    response_model=GovernanceKPIsDTO,
    summary="Get Governance KPIs",
    description="""
    Retrieves key performance indicators for data governance.
    
    **KPIs include:**
    - Data quality score
    - Lineage coverage
    - Policy compliance
    - User adoption
    - Cost efficiency
    - Time to insight
    """,
    operation_id="get_governance_kpis"
)
async def get_governance_kpis(
    time_period: str = Query("current_month", description="Time period for KPIs"),
    include_targets: bool = Query(True, description="Include target comparisons"),
    use_case: GetGovernanceKPIsUseCase = Depends(get_governance_kpis_use_case)
) -> GovernanceKPIsDTO:
    """Get governance KPIs."""
    try:
        kpis = await use_case.execute(
            time_period=time_period,
            include_targets=include_targets
        )
        return kpis
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))


# ============================================================================
# REPORTING ENDPOINTS
# ============================================================================

@router.post(
    "/reports/generate",
    response_model=ReportResponseDTO,
    status_code=status.HTTP_201_CREATED,
    summary="Generate Report",
    description="""
    Generates a custom report based on specified parameters.
    
    **Report types:**
    - Executive summary
    - Detailed analytics
    - Compliance reports
    - Quality assessments
    - Usage reports
    """,
    operation_id="generate_report"
)
async def generate_report(
    report_request: ReportGenerationRequestDTO = Body(
        ...,
        description="Report generation parameters",
        example={
            "report_type": "executive_summary",
            "title": "Monthly Data Governance Report",
            "time_period": "last_30_days",
            "sections": ["quality", "lineage", "compliance", "usage"],
            "format": "pdf",
            "include_charts": True,
            "recipients": ["executive@company.com"],
            "schedule": None
        }
    ),
    use_case: GenerateReportUseCase = Depends(get_generate_report_use_case),
    current_user: dict = Depends(get_current_user)
) -> ReportResponseDTO:
    """Generate a custom report."""
    try:
        report = await use_case.execute(report_request, current_user)
        return report
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except AuthorizationError as e:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=str(e))


@router.get(
    "/reports/{report_id}",
    response_model=ReportResponseDTO,
    summary="Get Report",
    description="Retrieves a generated report by its ID.",
    operation_id="get_report"
)
async def get_report(
    report_id: UUID = Path(..., description="Report ID"),
    use_case: GetReportUseCase = Depends(get_get_report_use_case)
) -> ReportResponseDTO:
    """Get a report by ID."""
    try:
        report = await use_case.execute(report_id)
        return report
    except EntityNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))


@router.get(
    "/reports/templates",
    response_model=List[ReportTemplateDTO],
    summary="Get Report Templates",
    description="Retrieves available report templates.",
    operation_id="get_report_templates"
)
async def get_report_templates(
    category: Optional[str] = Query(None, description="Filter by template category"),
    use_case: GetReportTemplatesUseCase = Depends(get_report_templates_use_case)
) -> List[ReportTemplateDTO]:
    """Get report templates."""
    try:
        templates = await use_case.execute(category=category)
        return templates
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))


@router.post(
    "/reports/schedule",
    response_model=ReportScheduleDTO,
    status_code=status.HTTP_201_CREATED,
    summary="Schedule Report",
    description="Schedules a report for automatic generation.",
    operation_id="schedule_report"
)
async def schedule_report(
    schedule_request: ReportScheduleDTO = Body(..., description="Report schedule parameters"),
    use_case: ScheduleReportUseCase = Depends(get_schedule_report_use_case),
    current_user: dict = Depends(get_current_user)
) -> ReportScheduleDTO:
    """Schedule a report."""
    try:
        schedule = await use_case.execute(schedule_request, current_user)
        return schedule
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except AuthorizationError as e:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=str(e))


@router.get(
    "/reports/scheduled",
    response_model=List[ReportScheduleDTO],
    summary="Get Scheduled Reports",
    description="Retrieves scheduled reports.",
    operation_id="get_scheduled_reports"
)
async def get_scheduled_reports(
    is_active: Optional[bool] = Query(None, description="Filter by active status"),
    use_case: GetScheduledReportsUseCase = Depends(get_scheduled_reports_use_case),
    current_user: dict = Depends(get_current_user)
) -> List[ReportScheduleDTO]:
    """Get scheduled reports."""
    try:
        schedules = await use_case.execute(is_active=is_active, current_user=current_user)
        return schedules
    except AuthorizationError as e:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=str(e))


@router.post(
    "/export",
    response_class=StreamingResponse,
    summary="Export Analytics Data",
    description="""
    Exports analytics data in various formats.
    
    **Supported formats:**
    - CSV
    - Excel
    - JSON
    - Parquet
    """,
    operation_id="export_analytics_data"
)
async def export_analytics_data(
    export_request: ExportRequestDTO = Body(..., description="Export parameters"),
    use_case: ExportAnalyticsUseCase = Depends(get_export_analytics_use_case),
    current_user: dict = Depends(get_current_user)
) -> StreamingResponse:
    """Export analytics data."""
    try:
        export_stream = await use_case.execute(export_request, current_user)
        
        # Determine content type based on format
        content_types = {
            "csv": "text/csv",
            "excel": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "json": "application/json",
            "parquet": "application/octet-stream"
        }
        
        content_type = content_types.get(export_request.format, "application/octet-stream")
        filename = f"analytics_export.{export_request.format}"
        
        return StreamingResponse(
            export_stream,
            media_type=content_type,
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except AuthorizationError as e:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=str(e))

