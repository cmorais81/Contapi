"""
FastAPI Endpoints for Quality Metrics Management.
Following SOLID principles and enterprise patterns.

Author: Carlos Morais
"""

from typing import List, Optional, Dict, Any
from uuid import UUID
from datetime import datetime, date

from fastapi import APIRouter, Depends, HTTPException, status, Query, Body, Path
from fastapi.responses import JSONResponse

from ....application.use_cases.quality import (
    CreateQualityMetricUseCase, GetQualityMetricUseCase, UpdateQualityMetricUseCase,
    DeleteQualityMetricUseCase, GetQualitySummaryUseCase, GetQualityTrendsUseCase,
    CreateQualityRuleUseCase, GetQualityRulesUseCase, ExecuteQualityRuleUseCase,
    GetQualityAlertsUseCase, GetQualityScorecardUseCase, BulkCreateMetricsUseCase
)
from ....application.dtos.quality import (
    QualityMetricCreateDTO, QualityMetricUpdateDTO, QualityMetricResponseDTO,
    QualitySummaryDTO, QualityTrendsDTO, QualityRuleCreateDTO, QualityRuleResponseDTO,
    QualityAlertDTO, QualityScorecardDTO, BulkQualityMetricsDTO
)
from ....application.exceptions.advanced_exceptions import (
    EntityNotFoundError, ValidationError, BusinessRuleViolationError,
    AuthorizationError
)
from ...dependencies import (
    get_create_quality_metric_use_case, get_get_quality_metric_use_case,
    get_update_quality_metric_use_case, get_delete_quality_metric_use_case,
    get_quality_summary_use_case, get_current_user
)


router = APIRouter(
    prefix="/quality",
    tags=["Quality Metrics"],
    responses={
        400: {"description": "Bad Request"},
        401: {"description": "Unauthorized"},
        403: {"description": "Forbidden"},
        404: {"description": "Not Found"},
        409: {"description": "Conflict"},
        500: {"description": "Internal Server Error"}
    }
)


@router.post(
    "/metrics",
    response_model=QualityMetricResponseDTO,
    status_code=status.HTTP_201_CREATED,
    summary="Create Quality Metric",
    description="""
    Creates a new quality metric for a data object.
    
    **Supported Metrics:**
    - Completeness: Percentage of non-null values
    - Accuracy: Percentage of correct values
    - Consistency: Data consistency across sources
    - Validity: Adherence to business rules
    - Uniqueness: Percentage of unique values
    - Timeliness: Data freshness metrics
    
    **Features:**
    - Automatic threshold validation
    - Historical trend tracking
    - Alert configuration
    - Custom metric definitions
    """,
    operation_id="create_quality_metric"
)
async def create_quality_metric(
    metric_dto: QualityMetricCreateDTO = Body(
        ...,
        description="Quality metric data",
        example={
            "data_object_id": "123e4567-e89b-12d3-a456-426614174000",
            "metric_name": "completeness",
            "metric_type": "percentage",
            "value": 95.5,
            "threshold_min": 90.0,
            "threshold_max": 100.0,
            "measurement_date": "2024-12-01T10:00:00Z",
            "dimension": "completeness",
            "rule_id": "rule_123",
            "metadata": {
                "column_name": "customer_email",
                "total_records": 10000,
                "null_records": 450
            }
        }
    ),
    use_case: CreateQualityMetricUseCase = Depends(get_create_quality_metric_use_case),
    current_user: dict = Depends(get_current_user)
) -> QualityMetricResponseDTO:
    """Create a new quality metric."""
    try:
        metric_dto.created_by = current_user.get("user_id")
        created_metric = await use_case.execute(metric_dto)
        return created_metric
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except BusinessRuleViolationError as e:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(e))
    except AuthorizationError as e:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=str(e))


@router.get(
    "/metrics/{metric_id}",
    response_model=QualityMetricResponseDTO,
    summary="Get Quality Metric",
    description="Retrieves a specific quality metric by its ID.",
    operation_id="get_quality_metric"
)
async def get_quality_metric(
    metric_id: UUID = Path(..., description="Unique ID of the quality metric"),
    use_case: GetQualityMetricUseCase = Depends(get_get_quality_metric_use_case)
) -> QualityMetricResponseDTO:
    """Get a quality metric by ID."""
    try:
        metric = await use_case.execute(metric_id)
        return metric
    except EntityNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))


@router.put(
    "/metrics/{metric_id}",
    response_model=QualityMetricResponseDTO,
    summary="Update Quality Metric",
    description="Updates an existing quality metric.",
    operation_id="update_quality_metric"
)
async def update_quality_metric(
    metric_id: UUID = Path(..., description="Unique ID of the quality metric"),
    update_dto: QualityMetricUpdateDTO = Body(..., description="Updated metric data"),
    use_case: UpdateQualityMetricUseCase = Depends(get_update_quality_metric_use_case),
    current_user: dict = Depends(get_current_user)
) -> QualityMetricResponseDTO:
    """Update a quality metric."""
    try:
        updated_metric = await use_case.execute(metric_id, update_dto, current_user)
        return updated_metric
    except EntityNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except AuthorizationError as e:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=str(e))


@router.delete(
    "/metrics/{metric_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete Quality Metric",
    description="Deletes a quality metric (soft delete).",
    operation_id="delete_quality_metric"
)
async def delete_quality_metric(
    metric_id: UUID = Path(..., description="Unique ID of the quality metric"),
    use_case: DeleteQualityMetricUseCase = Depends(get_delete_quality_metric_use_case),
    current_user: dict = Depends(get_current_user)
) -> None:
    """Delete a quality metric."""
    try:
        await use_case.execute(metric_id, current_user)
    except EntityNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except AuthorizationError as e:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=str(e))


@router.get(
    "/summary/{object_id}",
    response_model=QualitySummaryDTO,
    summary="Get Quality Summary",
    description="""
    Retrieves a comprehensive quality summary for a data object.
    
    **Summary includes:**
    - Overall quality score
    - Dimension-specific scores
    - Trend indicators
    - Alert status
    - Recommendations
    """,
    operation_id="get_quality_summary"
)
async def get_quality_summary(
    object_id: UUID = Path(..., description="Data object ID"),
    include_history: bool = Query(False, description="Include historical data"),
    days_back: int = Query(30, ge=1, le=365, description="Days of history to include"),
    use_case: GetQualitySummaryUseCase = Depends(get_quality_summary_use_case)
) -> QualitySummaryDTO:
    """Get quality summary for a data object."""
    try:
        summary = await use_case.execute(
            object_id=object_id,
            include_history=include_history,
            days_back=days_back
        )
        return summary
    except EntityNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))


@router.get(
    "/trends/{object_id}",
    response_model=QualityTrendsDTO,
    summary="Get Quality Trends",
    description="""
    Retrieves quality trends and patterns for a data object.
    
    **Trend analysis includes:**
    - Time series data
    - Seasonal patterns
    - Anomaly detection
    - Forecast projections
    """,
    operation_id="get_quality_trends"
)
async def get_quality_trends(
    object_id: UUID = Path(..., description="Data object ID"),
    start_date: Optional[date] = Query(None, description="Start date for trends"),
    end_date: Optional[date] = Query(None, description="End date for trends"),
    metric_types: Optional[List[str]] = Query(None, description="Specific metric types"),
    use_case: GetQualityTrendsUseCase = Depends(get_quality_trends_use_case)
) -> QualityTrendsDTO:
    """Get quality trends for a data object."""
    try:
        trends = await use_case.execute(
            object_id=object_id,
            start_date=start_date,
            end_date=end_date,
            metric_types=metric_types
        )
        return trends
    except EntityNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))


@router.post(
    "/rules",
    response_model=QualityRuleResponseDTO,
    status_code=status.HTTP_201_CREATED,
    summary="Create Quality Rule",
    description="""
    Creates a new quality rule for automated quality assessment.
    
    **Rule Types:**
    - Range checks (min/max values)
    - Pattern matching (regex validation)
    - Reference data validation
    - Cross-field validation
    - Custom SQL rules
    
    **Features:**
    - Automated execution scheduling
    - Alert configuration
    - Severity levels
    - Business context
    """,
    operation_id="create_quality_rule"
)
async def create_quality_rule(
    rule_dto: QualityRuleCreateDTO = Body(
        ...,
        description="Quality rule data",
        example={
            "name": "Email Format Validation",
            "description": "Validates email format using regex",
            "rule_type": "pattern_match",
            "rule_definition": {
                "pattern": "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$",
                "column": "email"
            },
            "severity": "high",
            "is_active": True,
            "schedule": "0 2 * * *",
            "alert_threshold": 95.0
        }
    ),
    use_case: CreateQualityRuleUseCase = Depends(get_create_quality_rule_use_case),
    current_user: dict = Depends(get_current_user)
) -> QualityRuleResponseDTO:
    """Create a new quality rule."""
    try:
        rule_dto.created_by = current_user.get("user_id")
        created_rule = await use_case.execute(rule_dto)
        return created_rule
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except BusinessRuleViolationError as e:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(e))


@router.get(
    "/rules",
    response_model=List[QualityRuleResponseDTO],
    summary="Get Quality Rules",
    description="Retrieves quality rules with filtering and pagination.",
    operation_id="get_quality_rules"
)
async def get_quality_rules(
    object_id: Optional[UUID] = Query(None, description="Filter by data object ID"),
    rule_type: Optional[str] = Query(None, description="Filter by rule type"),
    is_active: Optional[bool] = Query(None, description="Filter by active status"),
    severity: Optional[str] = Query(None, description="Filter by severity"),
    limit: int = Query(100, ge=1, le=1000, description="Maximum number of results"),
    offset: int = Query(0, ge=0, description="Number of results to skip"),
    use_case: GetQualityRulesUseCase = Depends(get_quality_rules_use_case)
) -> List[QualityRuleResponseDTO]:
    """Get quality rules with filtering."""
    try:
        rules = await use_case.execute(
            object_id=object_id,
            rule_type=rule_type,
            is_active=is_active,
            severity=severity,
            limit=limit,
            offset=offset
        )
        return rules
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))


@router.post(
    "/execute/{rule_id}",
    response_model=QualityMetricResponseDTO,
    summary="Execute Quality Rule",
    description="""
    Executes a quality rule and returns the resulting metric.
    
    **Execution modes:**
    - Immediate execution
    - Scheduled execution
    - Batch execution
    """,
    operation_id="execute_quality_rule"
)
async def execute_quality_rule(
    rule_id: UUID = Path(..., description="Quality rule ID to execute"),
    execution_mode: str = Query("immediate", description="Execution mode"),
    use_case: ExecuteQualityRuleUseCase = Depends(get_execute_quality_rule_use_case),
    current_user: dict = Depends(get_current_user)
) -> QualityMetricResponseDTO:
    """Execute a quality rule."""
    try:
        metric = await use_case.execute(rule_id, execution_mode, current_user)
        return metric
    except EntityNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except AuthorizationError as e:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=str(e))


@router.get(
    "/alerts",
    response_model=List[QualityAlertDTO],
    summary="Get Quality Alerts",
    description="""
    Retrieves quality alerts based on threshold violations.
    
    **Alert Types:**
    - Threshold violations
    - Trend anomalies
    - Rule failures
    - Data freshness issues
    """,
    operation_id="get_quality_alerts"
)
async def get_quality_alerts(
    severity: Optional[str] = Query(None, description="Filter by severity"),
    status: Optional[str] = Query("open", description="Filter by alert status"),
    object_id: Optional[UUID] = Query(None, description="Filter by data object"),
    days_back: int = Query(7, ge=1, le=90, description="Days to look back"),
    limit: int = Query(100, ge=1, le=1000, description="Maximum number of results"),
    use_case: GetQualityAlertsUseCase = Depends(get_quality_alerts_use_case)
) -> List[QualityAlertDTO]:
    """Get quality alerts."""
    try:
        alerts = await use_case.execute(
            severity=severity,
            status=status,
            object_id=object_id,
            days_back=days_back,
            limit=limit
        )
        return alerts
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))


@router.get(
    "/scorecard",
    response_model=QualityScorecardDTO,
    summary="Get Quality Scorecard",
    description="""
    Retrieves executive quality scorecard with KPIs and metrics.
    
    **Scorecard includes:**
    - Overall quality score
    - Dimension breakdown
    - Trend indicators
    - Benchmark comparisons
    - Action items
    """,
    operation_id="get_quality_scorecard"
)
async def get_quality_scorecard(
    scope: str = Query("organization", description="Scorecard scope"),
    time_period: str = Query("last_30_days", description="Time period"),
    include_trends: bool = Query(True, description="Include trend analysis"),
    use_case: GetQualityScorecardUseCase = Depends(get_quality_scorecard_use_case)
) -> QualityScorecardDTO:
    """Get quality scorecard."""
    try:
        scorecard = await use_case.execute(
            scope=scope,
            time_period=time_period,
            include_trends=include_trends
        )
        return scorecard
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))


@router.post(
    "/bulk-metrics",
    response_model=List[QualityMetricResponseDTO],
    status_code=status.HTTP_201_CREATED,
    summary="Bulk Create Quality Metrics",
    description="""
    Creates multiple quality metrics in a single operation.
    
    **Features:**
    - Batch processing
    - Transaction safety
    - Validation across metrics
    - Performance optimization
    """,
    operation_id="bulk_create_quality_metrics"
)
async def bulk_create_quality_metrics(
    bulk_dto: BulkQualityMetricsDTO = Body(..., description="Bulk metrics data"),
    use_case: BulkCreateMetricsUseCase = Depends(get_bulk_create_metrics_use_case),
    current_user: dict = Depends(get_current_user)
) -> List[QualityMetricResponseDTO]:
    """Create multiple quality metrics."""
    try:
        created_metrics = await use_case.execute(bulk_dto, current_user)
        return created_metrics
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except BusinessRuleViolationError as e:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(e))

