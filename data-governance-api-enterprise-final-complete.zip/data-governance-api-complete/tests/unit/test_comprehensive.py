"""
Comprehensive Unit Test Suite for Data Governance API.
Following testing best practices and ensuring high code coverage.

Author: Carlos Morais
"""

import pytest
import asyncio
from datetime import datetime, timedelta
from typing import List, Dict, Any
from uuid import uuid4, UUID
from unittest.mock import Mock, AsyncMock, patch, MagicMock

import pytest_asyncio
from fastapi.testclient import TestClient
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.pool import StaticPool

# Domain imports
from src.domain.entities import DataObject, DataLineage, AccessPolicy, QualityMetric
from src.domain.value_objects import (
    DataObjectId, DataObjectName, CatalogName, SchemaName,
    SecurityClassification, ObjectType, DataFormat, QualityScore,
    LineageConfidence, PolicyPriority
)
from src.domain.repositories import IDataObjectRepository

# Application imports
from src.application.use_cases import (
    CreateDataObjectUseCase, GetDataObjectUseCase, UpdateDataObjectUseCase,
    DeleteDataObjectUseCase, SearchDataObjectsUseCase
)
from src.application.dtos import (
    DataObjectCreateDTO, DataObjectUpdateDTO, DataObjectResponseDTO,
    SearchRequestDTO, PaginatedResponseDTO
)
from src.application.exceptions import (
    EntityNotFoundError, ValidationError, DatabaseError,
    PermissionError, BusinessRuleViolationError
)

# Infrastructure imports
from src.infrastructure.repositories import DataObjectRepository
from src.infrastructure.database.models import DataObjectModel, Base

# Presentation imports
from src.presentation.main import create_application


# Test Configuration
@pytest.fixture(scope="session")
def event_loop():
    """Create an instance of the default event loop for the test session."""
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()


@pytest.fixture
async def async_session():
    """Create async database session for testing."""
    # Use in-memory SQLite for testing
    engine = create_async_engine(
        "sqlite+aiosqlite:///:memory:",
        poolclass=StaticPool,
        connect_args={"check_same_thread": False}
    )
    
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    
    async with AsyncSession(engine) as session:
        yield session
    
    await engine.dispose()


@pytest.fixture
def mock_logger():
    """Mock logger for testing."""
    return Mock()


@pytest.fixture
def mock_event_publisher():
    """Mock event publisher for testing."""
    publisher = AsyncMock()
    publisher.publish.return_value = "event-id-123"
    return publisher


@pytest.fixture
def sample_data_object_create_dto():
    """Sample DataObjectCreateDTO for testing."""
    return DataObjectCreateDTO(
        object_name="test_table",
        object_type="table",
        catalog_name="test_catalog",
        schema_name="test_schema",
        object_owner="test_owner",
        description="Test table description",
        security_classification="internal",
        tags={"test", "sample"}
    )


@pytest.fixture
def sample_data_object():
    """Sample DataObject entity for testing."""
    return DataObject(
        object_name=DataObjectName("test_table"),
        object_type=ObjectType.TABLE,
        catalog_name=CatalogName("test_catalog"),
        schema_name=SchemaName("test_schema"),
        object_owner="test_owner",
        description="Test table description",
        security_classification=SecurityClassification.INTERNAL,
        tags={"test", "sample"}
    )


# Domain Entity Tests
class TestDataObject:
    """Test cases for DataObject entity."""
    
    def test_create_data_object_with_valid_data(self):
        """Test creating a DataObject with valid data."""
        data_object = DataObject(
            object_name=DataObjectName("test_table"),
            object_type=ObjectType.TABLE,
            catalog_name=CatalogName("test_catalog"),
            schema_name=SchemaName("test_schema"),
            object_owner="test_owner"
        )
        
        assert data_object.object_name.value == "test_table"
        assert data_object.object_type == ObjectType.TABLE
        assert data_object.catalog_name.value == "test_catalog"
        assert data_object.schema_name.value == "test_schema"
        assert data_object.object_owner == "test_owner"
        assert data_object.is_active is True
        assert data_object.security_classification == SecurityClassification.INTERNAL
        assert isinstance(data_object.id, UUID)
    
    def test_create_data_object_with_invalid_name(self):
        """Test creating a DataObject with invalid name."""
        with pytest.raises(ValueError, match="DataObjectName cannot be empty"):
            DataObject(
                object_name=DataObjectName(""),
                object_type=ObjectType.TABLE,
                catalog_name=CatalogName("test_catalog"),
                schema_name=SchemaName("test_schema"),
                object_owner="test_owner"
            )
    
    def test_create_data_object_with_invalid_owner(self):
        """Test creating a DataObject with invalid owner."""
        with pytest.raises(ValueError, match="Object owner is required"):
            DataObject(
                object_name=DataObjectName("test_table"),
                object_type=ObjectType.TABLE,
                catalog_name=CatalogName("test_catalog"),
                schema_name=SchemaName("test_schema"),
                object_owner=""
            )
    
    def test_data_object_full_name(self):
        """Test DataObject full name generation."""
        data_object = DataObject(
            object_name=DataObjectName("test_table"),
            object_type=ObjectType.TABLE,
            catalog_name=CatalogName("test_catalog"),
            schema_name=SchemaName("test_schema"),
            object_owner="test_owner"
        )
        
        assert data_object.full_name == "test_catalog.test_schema.test_table"
    
    def test_add_tag_to_data_object(self, sample_data_object):
        """Test adding a tag to a DataObject."""
        initial_events = len(sample_data_object._domain_events)
        sample_data_object.add_tag("new_tag")
        
        assert "new_tag" in sample_data_object.tags
        assert len(sample_data_object._domain_events) == initial_events + 1
    
    def test_remove_tag_from_data_object(self, sample_data_object):
        """Test removing a tag from a DataObject."""
        sample_data_object.add_tag("temp_tag")
        initial_events = len(sample_data_object._domain_events)
        sample_data_object.remove_tag("temp_tag")
        
        assert "temp_tag" not in sample_data_object.tags
        assert len(sample_data_object._domain_events) == initial_events + 1
    
    def test_update_security_classification(self, sample_data_object):
        """Test updating security classification."""
        initial_events = len(sample_data_object._domain_events)
        sample_data_object.update_security_classification(SecurityClassification.CONFIDENTIAL)
        
        assert sample_data_object.security_classification == SecurityClassification.CONFIDENTIAL
        assert len(sample_data_object._domain_events) == initial_events + 1
    
    def test_data_object_has_sensitive_data(self):
        """Test checking if DataObject has sensitive data."""
        # Test with sensitive tag
        data_object = DataObject(
            object_name=DataObjectName("test_table"),
            object_type=ObjectType.TABLE,
            catalog_name=CatalogName("test_catalog"),
            schema_name=SchemaName("test_schema"),
            object_owner="test_owner",
            tags={"pii"}
        )
        assert data_object.has_sensitive_data() is True
        
        # Test with confidential classification
        data_object2 = DataObject(
            object_name=DataObjectName("test_table2"),
            object_type=ObjectType.TABLE,
            catalog_name=CatalogName("test_catalog"),
            schema_name=SchemaName("test_schema"),
            object_owner="test_owner",
            security_classification=SecurityClassification.CONFIDENTIAL
        )
        assert data_object2.has_sensitive_data() is True
        
        # Test with no sensitive data
        data_object3 = DataObject(
            object_name=DataObjectName("test_table3"),
            object_type=ObjectType.TABLE,
            catalog_name=CatalogName("test_catalog"),
            schema_name=SchemaName("test_schema"),
            object_owner="test_owner"
        )
        assert data_object3.has_sensitive_data() is False


class TestValueObjects:
    """Test cases for Value Objects."""
    
    def test_data_object_name_validation(self):
        """Test DataObjectName validation."""
        # Valid names
        valid_name = DataObjectName("valid_table_name")
        assert valid_name.value == "valid_table_name"
        
        # Invalid names
        with pytest.raises(ValueError):
            DataObjectName("")
        
        with pytest.raises(ValueError):
            DataObjectName("invalid name with spaces")
        
        with pytest.raises(ValueError):
            DataObjectName("invalid@name")
    
    def test_quality_score_validation(self):
        """Test QualityScore validation."""
        # Valid scores
        score = QualityScore(85.5)
        assert score.value == 85.5
        assert score.get_grade() == "B"
        assert score.is_passing() is True
        
        # Invalid scores
        with pytest.raises(ValueError):
            QualityScore(-1)
        
        with pytest.raises(ValueError):
            QualityScore(101)
    
    def test_lineage_confidence_validation(self):
        """Test LineageConfidence validation."""
        # Valid confidence
        confidence = LineageConfidence(0.85)
        assert confidence.value == 0.85
        assert confidence.is_high_confidence() is True
        assert confidence.get_level() == "high"
        
        # Invalid confidence
        with pytest.raises(ValueError):
            LineageConfidence(-0.1)
        
        with pytest.raises(ValueError):
            LineageConfidence(1.1)


# Application Use Cases Tests
class TestCreateDataObjectUseCase:
    """Test cases for CreateDataObjectUseCase."""
    
    @pytest.mark.asyncio
    async def test_create_data_object_success(self, sample_data_object_create_dto):
        """Test successful data object creation."""
        # Mock repository
        mock_repository = AsyncMock(spec=IDataObjectRepository)
        mock_repository.get_by_name.return_value = None  # Object doesn't exist
        mock_repository.save.return_value = Mock()  # Return saved object
        
        # Mock services
        mock_logger = Mock()
        mock_event_publisher = AsyncMock()
        
        # Create use case
        use_case = CreateDataObjectUseCase(
            repository=mock_repository,
            logger=mock_logger,
            event_publisher=mock_event_publisher
        )
        
        # Execute
        result = await use_case.execute(sample_data_object_create_dto)
        
        # Assertions
        mock_repository.get_by_name.assert_called_once()
        mock_repository.save.assert_called_once()
        mock_event_publisher.publish.assert_called_once()
        assert result is not None
    
    @pytest.mark.asyncio
    async def test_create_data_object_already_exists(self, sample_data_object_create_dto, sample_data_object):
        """Test creating a data object that already exists."""
        # Mock repository
        mock_repository = AsyncMock(spec=IDataObjectRepository)
        mock_repository.get_by_name.return_value = sample_data_object  # Object exists
        
        # Mock services
        mock_logger = Mock()
        mock_event_publisher = AsyncMock()
        
        # Create use case
        use_case = CreateDataObjectUseCase(
            repository=mock_repository,
            logger=mock_logger,
            event_publisher=mock_event_publisher
        )
        
        # Execute and expect exception
        with pytest.raises(BusinessRuleViolationError, match="already exists"):
            await use_case.execute(sample_data_object_create_dto)
    
    @pytest.mark.asyncio
    async def test_create_data_object_validation_error(self):
        """Test creating a data object with invalid data."""
        # Invalid DTO
        invalid_dto = DataObjectCreateDTO(
            object_name="",  # Invalid empty name
            object_type="table",
            catalog_name="test_catalog",
            schema_name="test_schema",
            object_owner="test_owner"
        )
        
        # Mock repository
        mock_repository = AsyncMock(spec=IDataObjectRepository)
        mock_logger = Mock()
        mock_event_publisher = AsyncMock()
        
        # Create use case
        use_case = CreateDataObjectUseCase(
            repository=mock_repository,
            logger=mock_logger,
            event_publisher=mock_event_publisher
        )
        
        # Execute and expect validation error
        with pytest.raises(ValidationError):
            await use_case.execute(invalid_dto)


class TestGetDataObjectUseCase:
    """Test cases for GetDataObjectUseCase."""
    
    @pytest.mark.asyncio
    async def test_get_data_object_success(self, sample_data_object):
        """Test successful data object retrieval."""
        object_id = DataObjectId(sample_data_object.id)
        
        # Mock repository
        mock_repository = AsyncMock(spec=IDataObjectRepository)
        mock_repository.get_by_id.return_value = sample_data_object
        
        # Mock services
        mock_logger = Mock()
        
        # Create use case
        use_case = GetDataObjectUseCase(
            repository=mock_repository,
            logger=mock_logger
        )
        
        # Execute
        result = await use_case.execute(object_id)
        
        # Assertions
        mock_repository.get_by_id.assert_called_once_with(object_id)
        assert result is not None
        assert result.object_id == str(sample_data_object.id)
    
    @pytest.mark.asyncio
    async def test_get_data_object_not_found(self):
        """Test getting a data object that doesn't exist."""
        object_id = DataObjectId(uuid4())
        
        # Mock repository
        mock_repository = AsyncMock(spec=IDataObjectRepository)
        mock_repository.get_by_id.return_value = None
        
        # Mock services
        mock_logger = Mock()
        
        # Create use case
        use_case = GetDataObjectUseCase(
            repository=mock_repository,
            logger=mock_logger
        )
        
        # Execute and expect exception
        with pytest.raises(EntityNotFoundError):
            await use_case.execute(object_id)


# Infrastructure Repository Tests
class TestDataObjectRepository:
    """Test cases for DataObjectRepository."""
    
    @pytest.mark.asyncio
    async def test_save_data_object(self, async_session, sample_data_object):
        """Test saving a data object to database."""
        repository = DataObjectRepository(async_session)
        
        # Save object
        saved_object = await repository.save(sample_data_object)
        
        # Assertions
        assert saved_object.id == sample_data_object.id
        assert saved_object.object_name.value == sample_data_object.object_name.value
    
    @pytest.mark.asyncio
    async def test_get_by_id(self, async_session, sample_data_object):
        """Test getting a data object by ID."""
        repository = DataObjectRepository(async_session)
        
        # Save object first
        await repository.save(sample_data_object)
        
        # Get object
        retrieved_object = await repository.get_by_id(DataObjectId(sample_data_object.id))
        
        # Assertions
        assert retrieved_object is not None
        assert retrieved_object.id == sample_data_object.id
        assert retrieved_object.object_name.value == sample_data_object.object_name.value
    
    @pytest.mark.asyncio
    async def test_get_by_name(self, async_session, sample_data_object):
        """Test getting a data object by name."""
        repository = DataObjectRepository(async_session)
        
        # Save object first
        await repository.save(sample_data_object)
        
        # Get object by name
        retrieved_object = await repository.get_by_name(
            sample_data_object.catalog_name,
            sample_data_object.schema_name,
            sample_data_object.object_name
        )
        
        # Assertions
        assert retrieved_object is not None
        assert retrieved_object.id == sample_data_object.id
    
    @pytest.mark.asyncio
    async def test_search_data_objects(self, async_session):
        """Test searching data objects."""
        repository = DataObjectRepository(async_session)
        
        # Create and save multiple objects
        objects = []
        for i in range(5):
            obj = DataObject(
                object_name=DataObjectName(f"test_table_{i}"),
                object_type=ObjectType.TABLE,
                catalog_name=CatalogName("test_catalog"),
                schema_name=SchemaName("test_schema"),
                object_owner="test_owner",
                description=f"Test table {i}"
            )
            await repository.save(obj)
            objects.append(obj)
        
        # Search with pagination
        search_request = SearchRequestDTO(
            query="test",
            page=1,
            limit=3
        )
        
        result = await repository.search(search_request)
        
        # Assertions
        assert result.total >= 5
        assert len(result.items) <= 3
        assert result.page == 1
        assert result.has_next is True


# Presentation Layer Tests
class TestDataObjectEndpoints:
    """Test cases for Data Object API endpoints."""
    
    @pytest.fixture
    def client(self):
        """Create test client."""
        app = create_application()
        return TestClient(app)
    
    def test_create_data_object_endpoint(self, client):
        """Test POST /api/v1/data-objects endpoint."""
        payload = {
            "object_name": "test_table",
            "object_type": "table",
            "catalog_name": "test_catalog",
            "schema_name": "test_schema",
            "object_owner": "test_owner",
            "description": "Test table"
        }
        
        with patch('src.presentation.dependencies.get_create_data_object_use_case') as mock_dep:
            mock_use_case = AsyncMock()
            mock_use_case.execute.return_value = DataObjectResponseDTO(
                object_id=str(uuid4()),
                object_name="test_table",
                object_type="table",
                catalog_name="test_catalog",
                schema_name="test_schema",
                full_name="test_catalog.test_schema.test_table",
                object_owner="test_owner",
                description="Test table"
            )
            mock_dep.return_value = mock_use_case
            
            response = client.post("/api/v1/data-objects/", json=payload)
            
            assert response.status_code == 201
            data = response.json()
            assert data["object_name"] == "test_table"
            assert data["object_type"] == "table"
    
    def test_get_data_object_endpoint(self, client):
        """Test GET /api/v1/data-objects/{id} endpoint."""
        object_id = str(uuid4())
        
        with patch('src.presentation.dependencies.get_get_data_object_use_case') as mock_dep:
            mock_use_case = AsyncMock()
            mock_use_case.execute.return_value = DataObjectResponseDTO(
                object_id=object_id,
                object_name="test_table",
                object_type="table",
                catalog_name="test_catalog",
                schema_name="test_schema",
                full_name="test_catalog.test_schema.test_table",
                object_owner="test_owner"
            )
            mock_dep.return_value = mock_use_case
            
            response = client.get(f"/api/v1/data-objects/{object_id}")
            
            assert response.status_code == 200
            data = response.json()
            assert data["object_id"] == object_id
    
    def test_get_data_object_not_found(self, client):
        """Test GET /api/v1/data-objects/{id} endpoint with non-existent ID."""
        object_id = str(uuid4())
        
        with patch('src.presentation.dependencies.get_get_data_object_use_case') as mock_dep:
            mock_use_case = AsyncMock()
            mock_use_case.execute.side_effect = EntityNotFoundError("Data object not found")
            mock_dep.return_value = mock_use_case
            
            response = client.get(f"/api/v1/data-objects/{object_id}")
            
            assert response.status_code == 404
            data = response.json()
            assert "not found" in data["detail"].lower()
    
    def test_search_data_objects_endpoint(self, client):
        """Test POST /api/v1/data-objects/search endpoint."""
        payload = {
            "query": "test",
            "page": 1,
            "limit": 10
        }
        
        with patch('src.presentation.dependencies.get_search_data_objects_use_case') as mock_dep:
            mock_use_case = AsyncMock()
            mock_use_case.execute.return_value = PaginatedResponseDTO(
                items=[],
                total=0,
                page=1,
                size=0,
                pages=0,
                has_next=False,
                has_prev=False
            )
            mock_dep.return_value = mock_use_case
            
            response = client.post("/api/v1/data-objects/search", json=payload)
            
            assert response.status_code == 200
            data = response.json()
            assert "items" in data
            assert "total" in data


# Integration Tests
class TestIntegration:
    """Integration test cases."""
    
    @pytest.mark.asyncio
    async def test_full_data_object_lifecycle(self, async_session):
        """Test complete data object lifecycle."""
        # Setup
        repository = DataObjectRepository(async_session)
        mock_logger = Mock()
        mock_event_publisher = AsyncMock()
        
        create_use_case = CreateDataObjectUseCase(
            repository=repository,
            logger=mock_logger,
            event_publisher=mock_event_publisher
        )
        
        get_use_case = GetDataObjectUseCase(
            repository=repository,
            logger=mock_logger
        )
        
        # Create data object
        create_dto = DataObjectCreateDTO(
            object_name="integration_test_table",
            object_type="table",
            catalog_name="test_catalog",
            schema_name="test_schema",
            object_owner="test_owner",
            description="Integration test table"
        )
        
        created_object = await create_use_case.execute(create_dto)
        assert created_object is not None
        
        # Get data object
        retrieved_object = await get_use_case.execute(DataObjectId(UUID(created_object.object_id)))
        assert retrieved_object is not None
        assert retrieved_object.object_name == "integration_test_table"


# Performance Tests
class TestPerformance:
    """Performance test cases."""
    
    @pytest.mark.asyncio
    async def test_bulk_data_object_creation(self, async_session):
        """Test creating multiple data objects for performance."""
        repository = DataObjectRepository(async_session)
        
        # Create multiple objects
        objects = []
        for i in range(100):
            obj = DataObject(
                object_name=DataObjectName(f"perf_test_table_{i}"),
                object_type=ObjectType.TABLE,
                catalog_name=CatalogName("perf_catalog"),
                schema_name=SchemaName("perf_schema"),
                object_owner="perf_owner"
            )
            objects.append(obj)
        
        # Measure time
        import time
        start_time = time.time()
        
        for obj in objects:
            await repository.save(obj)
        
        end_time = time.time()
        duration = end_time - start_time
        
        # Assert reasonable performance (adjust threshold as needed)
        assert duration < 10.0  # Should complete in less than 10 seconds
        print(f"Created 100 objects in {duration:.2f} seconds")


# Test Utilities
class TestUtilities:
    """Utility functions for testing."""
    
    @staticmethod
    def create_sample_data_object(name_suffix: str = "") -> DataObject:
        """Create a sample data object for testing."""
        return DataObject(
            object_name=DataObjectName(f"test_table{name_suffix}"),
            object_type=ObjectType.TABLE,
            catalog_name=CatalogName("test_catalog"),
            schema_name=SchemaName("test_schema"),
            object_owner="test_owner"
        )
    
    @staticmethod
    def assert_data_object_equals(obj1: DataObject, obj2: DataObject) -> None:
        """Assert that two data objects are equal."""
        assert obj1.id == obj2.id
        assert obj1.object_name.value == obj2.object_name.value
        assert obj1.object_type == obj2.object_type
        assert obj1.catalog_name.value == obj2.catalog_name.value
        assert obj1.schema_name.value == obj2.schema_name.value
        assert obj1.object_owner == obj2.object_owner


# Pytest configuration
def pytest_configure(config):
    """Configure pytest."""
    config.addinivalue_line(
        "markers", "unit: mark test as a unit test"
    )
    config.addinivalue_line(
        "markers", "integration: mark test as an integration test"
    )
    config.addinivalue_line(
        "markers", "performance: mark test as a performance test"
    )


# Test markers
pytestmark = pytest.mark.unit

