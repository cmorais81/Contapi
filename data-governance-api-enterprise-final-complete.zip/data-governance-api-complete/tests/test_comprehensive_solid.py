"""
Comprehensive Test Suite for Data Governance API.
Testing SOLID principles, error handling, and all functionalities.

Author: Carlos Morais
"""

import pytest
import asyncio
from unittest.mock import Mock, AsyncMock, patch, MagicMock
from typing import List, Dict, Any, Optional
from uuid import uuid4, UUID
from datetime import datetime, date
import json

# Test framework imports
from fastapi.testclient import TestClient
from httpx import AsyncClient
import pytest_asyncio

# Application imports (these would be actual imports in real implementation)
from src.domain.entities import DataObject, DataLineage, QualityMetric, AccessPolicy
from src.domain.value_objects import DataObjectId, QualityScore, LineageConfidence
from src.application.use_cases.data_objects import CreateDataObjectUseCase
from src.application.use_cases.lineage import CreateLineageUseCase
from src.application.use_cases.quality import CreateQualityMetricUseCase
from src.application.use_cases.policies import CreatePolicyUseCase
from src.application.dtos.data_objects import DataObjectCreateDTO, DataObjectResponseDTO
from src.application.exceptions.advanced_exceptions import (
    ValidationError, EntityNotFoundError, BusinessRuleViolationError,
    DatabaseError, ExternalServiceError, AuthenticationError, AuthorizationError
)
from src.infrastructure.dependency_injection import ServiceContainer, ServiceScope
from src.presentation.main import app


# ============================================================================
# TEST CONFIGURATION AND FIXTURES
# ============================================================================

@pytest.fixture
def test_client():
    """Create test client for FastAPI application."""
    return TestClient(app)


@pytest.fixture
async def async_client():
    """Create async test client."""
    async with AsyncClient(app=app, base_url="http://test") as client:
        yield client


@pytest.fixture
def service_container():
    """Create service container for testing."""
    container = ServiceContainer()
    # Configure test services
    return container


@pytest.fixture
def mock_repository():
    """Create mock repository for testing."""
    repository = AsyncMock()
    return repository


@pytest.fixture
def sample_data_object():
    """Create sample data object for testing."""
    return DataObject(
        id=DataObjectId(str(uuid4())),
        name="test_table",
        object_type="table",
        description="Test table for unit tests",
        schema_definition={"columns": [{"name": "id", "type": "int"}]},
        created_by="test_user",
        created_at=datetime.utcnow()
    )


@pytest.fixture
def sample_lineage():
    """Create sample lineage for testing."""
    return DataLineage(
        id=str(uuid4()),
        source_object_id=str(uuid4()),
        target_object_id=str(uuid4()),
        lineage_type="table_to_table",
        confidence_score=LineageConfidence(0.95),
        created_by="test_user",
        created_at=datetime.utcnow()
    )


@pytest.fixture
def sample_quality_metric():
    """Create sample quality metric for testing."""
    return QualityMetric(
        id=str(uuid4()),
        data_object_id=str(uuid4()),
        metric_name="completeness",
        metric_type="percentage",
        value=95.5,
        quality_score=QualityScore(95.5),
        measurement_date=datetime.utcnow(),
        created_by="test_user"
    )


# ============================================================================
# DOMAIN LAYER TESTS (Testing Business Logic and SOLID Principles)
# ============================================================================

class TestDomainEntities:
    """Test domain entities following SOLID principles."""
    
    def test_data_object_creation_follows_srp(self, sample_data_object):
        """Test that DataObject follows Single Responsibility Principle."""
        # SRP: DataObject should only handle data object business logic
        assert sample_data_object.name == "test_table"
        assert sample_data_object.object_type == "table"
        assert sample_data_object.is_valid()
        
        # Should not handle persistence, validation, or external concerns
        assert not hasattr(sample_data_object, 'save')
        assert not hasattr(sample_data_object, 'send_notification')
    
    def test_data_object_immutability_follows_ocp(self, sample_data_object):
        """Test that DataObject follows Open/Closed Principle."""
        # OCP: Should be open for extension but closed for modification
        original_name = sample_data_object.name
        
        # Should be able to extend behavior without modifying the class
        updated_object = sample_data_object.update_metadata({"new_field": "value"})
        
        # Original object should remain unchanged
        assert sample_data_object.name == original_name
        assert updated_object.metadata.get("new_field") == "value"
    
    def test_value_objects_equality_follows_lsp(self):
        """Test that value objects follow Liskov Substitution Principle."""
        # LSP: Value objects should be substitutable
        id1 = DataObjectId("123e4567-e89b-12d3-a456-426614174000")
        id2 = DataObjectId("123e4567-e89b-12d3-a456-426614174000")
        id3 = DataObjectId("123e4567-e89b-12d3-a456-426614174001")
        
        # Should follow equality contract
        assert id1 == id2
        assert id1 != id3
        assert hash(id1) == hash(id2)
        assert hash(id1) != hash(id3)
    
    def test_quality_score_validation_follows_isp(self):
        """Test that QualityScore follows Interface Segregation Principle."""
        # ISP: Should only implement necessary interfaces
        score = QualityScore(95.5)
        
        # Should implement value object behavior
        assert score.value == 95.5
        assert score.is_valid()
        
        # Should not implement unnecessary interfaces
        assert not hasattr(score, 'save')
        assert not hasattr(score, 'update')
    
    def test_lineage_confidence_follows_dip(self):
        """Test that LineageConfidence follows Dependency Inversion Principle."""
        # DIP: Should depend on abstractions, not concretions
        confidence = LineageConfidence(0.95)
        
        # Should work with any validation strategy
        assert confidence.is_high_confidence()
        assert not confidence.is_low_confidence()


class TestDomainServices:
    """Test domain services and business rules."""
    
    @pytest.mark.asyncio
    async def test_lineage_calculator_business_rules(self):
        """Test lineage calculation business rules."""
        # Mock dependencies
        lineage_repo = AsyncMock()
        calculator = LineageCalculator(lineage_repo)
        
        # Test circular dependency detection
        source_id = str(uuid4())
        target_id = str(uuid4())
        
        # Mock existing lineage that would create circular dependency
        lineage_repo.get_downstream_lineage.return_value = [
            Mock(target_object_id=source_id)
        ]
        
        with pytest.raises(BusinessRuleViolationError, match="circular dependency"):
            await calculator.validate_lineage(source_id, target_id)
    
    @pytest.mark.asyncio
    async def test_quality_analyzer_aggregation(self):
        """Test quality metric aggregation logic."""
        analyzer = QualityAnalyzer()
        
        metrics = [
            Mock(dimension="completeness", value=95.0),
            Mock(dimension="accuracy", value=90.0),
            Mock(dimension="consistency", value=85.0)
        ]
        
        overall_score = await analyzer.calculate_overall_score(metrics)
        
        # Should calculate weighted average
        assert 85.0 <= overall_score <= 95.0
        assert isinstance(overall_score, float)


# ============================================================================
# APPLICATION LAYER TESTS (Testing Use Cases and SOLID Principles)
# ============================================================================

class TestUseCases:
    """Test application use cases following SOLID principles."""
    
    @pytest.mark.asyncio
    async def test_create_data_object_use_case_srp(self):
        """Test CreateDataObjectUseCase follows SRP."""
        # SRP: Use case should only handle data object creation logic
        mock_repo = AsyncMock()
        mock_publisher = AsyncMock()
        
        use_case = CreateDataObjectUseCase(
            repository=mock_repo,
            event_publisher=mock_publisher
        )
        
        dto = DataObjectCreateDTO(
            name="test_table",
            object_type="table",
            description="Test table",
            schema_definition={"columns": []}
        )
        
        # Mock repository response
        mock_repo.create.return_value = Mock(id="123", name="test_table")
        
        result = await use_case.execute(dto)
        
        # Should only handle creation logic
        mock_repo.create.assert_called_once()
        mock_publisher.publish.assert_called_once()
        assert result.name == "test_table"
    
    @pytest.mark.asyncio
    async def test_use_case_error_handling_follows_solid(self):
        """Test use case error handling follows SOLID principles."""
        mock_repo = AsyncMock()
        mock_repo.create.side_effect = DatabaseError("Connection failed", "DB_ERROR")
        
        use_case = CreateDataObjectUseCase(
            repository=mock_repo,
            event_publisher=AsyncMock()
        )
        
        dto = DataObjectCreateDTO(
            name="test_table",
            object_type="table",
            description="Test table",
            schema_definition={"columns": []}
        )
        
        # Should propagate domain errors without modification
        with pytest.raises(DatabaseError):
            await use_case.execute(dto)
    
    @pytest.mark.asyncio
    async def test_use_case_dependency_injection_follows_dip(self):
        """Test use case dependency injection follows DIP."""
        # DIP: Use case should depend on abstractions
        mock_repo = AsyncMock()
        mock_publisher = AsyncMock()
        
        # Should accept any implementation of the interface
        use_case = CreateDataObjectUseCase(
            repository=mock_repo,  # Could be any IDataObjectRepository
            event_publisher=mock_publisher  # Could be any IEventPublisher
        )
        
        # Should work with different implementations
        assert use_case._repository == mock_repo
        assert use_case._event_publisher == mock_publisher


class TestDTOs:
    """Test Data Transfer Objects."""
    
    def test_dto_validation_follows_isp(self):
        """Test DTOs follow Interface Segregation Principle."""
        # ISP: DTOs should only contain necessary fields
        dto = DataObjectCreateDTO(
            name="test_table",
            object_type="table",
            description="Test table",
            schema_definition={"columns": []}
        )
        
        # Should only have creation-specific fields
        assert hasattr(dto, 'name')
        assert hasattr(dto, 'object_type')
        assert not hasattr(dto, 'id')  # Not needed for creation
        assert not hasattr(dto, 'created_at')  # Set by system
    
    def test_dto_immutability_follows_ocp(self):
        """Test DTOs follow Open/Closed Principle."""
        dto = DataObjectCreateDTO(
            name="test_table",
            object_type="table",
            description="Test table",
            schema_definition={"columns": []}
        )
        
        # Should be immutable (using dataclass frozen=True)
        with pytest.raises(AttributeError):
            dto.name = "modified_name"


# ============================================================================
# INFRASTRUCTURE LAYER TESTS (Testing Repositories and External Services)
# ============================================================================

class TestRepositories:
    """Test repository implementations."""
    
    @pytest.mark.asyncio
    async def test_repository_follows_lsp(self):
        """Test repository implementations follow LSP."""
        # LSP: All repository implementations should be substitutable
        
        # Mock different repository implementations
        postgres_repo = AsyncMock()
        redis_repo = AsyncMock()
        
        # Both should implement the same interface
        test_id = str(uuid4())
        expected_result = Mock(id=test_id, name="test")
        
        postgres_repo.get_by_id.return_value = expected_result
        redis_repo.get_by_id.return_value = expected_result
        
        # Should be substitutable
        async def test_with_repo(repo):
            result = await repo.get_by_id(test_id)
            return result.name
        
        postgres_result = await test_with_repo(postgres_repo)
        redis_result = await test_with_repo(redis_repo)
        
        assert postgres_result == redis_result == "test"
    
    @pytest.mark.asyncio
    async def test_repository_error_handling(self):
        """Test repository error handling."""
        mock_db = AsyncMock()
        mock_db.execute.side_effect = Exception("Database connection failed")
        
        repository = PostgreSQLDataObjectRepository(mock_db)
        
        # Should convert infrastructure errors to domain errors
        with pytest.raises(DatabaseError):
            await repository.create(Mock())


class TestExternalServices:
    """Test external service integrations."""
    
    @pytest.mark.asyncio
    async def test_external_service_circuit_breaker(self):
        """Test circuit breaker pattern in external services."""
        mock_client = AsyncMock()
        mock_client.get.side_effect = ExternalServiceError(
            "Service unavailable", "DATABRICKS_ERROR"
        )
        
        service = DatabricksClient(mock_client)
        
        # Should implement circuit breaker
        with pytest.raises(ExternalServiceError):
            await service.get_tables()
        
        # After multiple failures, should open circuit
        for _ in range(5):
            with pytest.raises(ExternalServiceError):
                await service.get_tables()
        
        # Circuit should be open
        assert service._circuit_breaker.state == "open"


# ============================================================================
# PRESENTATION LAYER TESTS (Testing API Endpoints)
# ============================================================================

class TestDataObjectEndpoints:
    """Test data object API endpoints."""
    
    @pytest.mark.asyncio
    async def test_create_data_object_endpoint(self, async_client):
        """Test create data object endpoint."""
        payload = {
            "name": "test_table",
            "object_type": "table",
            "description": "Test table",
            "schema_definition": {"columns": []}
        }
        
        response = await async_client.post("/api/v1/data-objects/", json=payload)
        
        assert response.status_code == 201
        data = response.json()
        assert data["name"] == "test_table"
        assert data["object_type"] == "table"
    
    @pytest.mark.asyncio
    async def test_get_data_object_endpoint(self, async_client):
        """Test get data object endpoint."""
        object_id = str(uuid4())
        
        response = await async_client.get(f"/api/v1/data-objects/{object_id}")
        
        # Should handle not found gracefully
        if response.status_code == 404:
            assert "not found" in response.json()["detail"].lower()
    
    @pytest.mark.asyncio
    async def test_endpoint_validation_error_handling(self, async_client):
        """Test endpoint validation error handling."""
        # Invalid payload
        payload = {
            "name": "",  # Empty name should fail validation
            "object_type": "invalid_type",
            "description": "Test"
        }
        
        response = await async_client.post("/api/v1/data-objects/", json=payload)
        
        assert response.status_code == 400
        error_data = response.json()
        assert "error_code" in error_data
        assert "field_errors" in error_data


class TestLineageEndpoints:
    """Test lineage API endpoints."""
    
    @pytest.mark.asyncio
    async def test_create_lineage_endpoint(self, async_client):
        """Test create lineage endpoint."""
        payload = {
            "source_object_id": str(uuid4()),
            "target_object_id": str(uuid4()),
            "lineage_type": "table_to_table",
            "confidence_score": 0.95
        }
        
        response = await async_client.post("/api/v1/lineage/", json=payload)
        
        # Should handle creation or validation error
        assert response.status_code in [201, 400, 409]
    
    @pytest.mark.asyncio
    async def test_get_lineage_graph_endpoint(self, async_client):
        """Test get lineage graph endpoint."""
        object_id = str(uuid4())
        
        response = await async_client.get(
            f"/api/v1/lineage/graph/{object_id}",
            params={"max_depth": 3, "include_upstream": True}
        )
        
        # Should return graph structure or not found
        assert response.status_code in [200, 404]


class TestQualityEndpoints:
    """Test quality metrics API endpoints."""
    
    @pytest.mark.asyncio
    async def test_create_quality_metric_endpoint(self, async_client):
        """Test create quality metric endpoint."""
        payload = {
            "data_object_id": str(uuid4()),
            "metric_name": "completeness",
            "metric_type": "percentage",
            "value": 95.5,
            "measurement_date": datetime.utcnow().isoformat()
        }
        
        response = await async_client.post("/api/v1/quality/metrics", json=payload)
        
        assert response.status_code in [201, 400]
    
    @pytest.mark.asyncio
    async def test_get_quality_summary_endpoint(self, async_client):
        """Test get quality summary endpoint."""
        object_id = str(uuid4())
        
        response = await async_client.get(f"/api/v1/quality/summary/{object_id}")
        
        assert response.status_code in [200, 404]


# ============================================================================
# ERROR HANDLING TESTS (Testing Exception System)
# ============================================================================

class TestErrorHandling:
    """Test comprehensive error handling system."""
    
    def test_exception_hierarchy_follows_solid(self):
        """Test exception hierarchy follows SOLID principles."""
        # SRP: Each exception has single responsibility
        validation_error = ValidationError("Invalid input", "VALIDATION_ERROR")
        business_error = BusinessRuleViolationError("Rule violated", "BUSINESS_RULE")
        
        assert validation_error.category.value == "validation"
        assert business_error.category.value == "business_rule"
        
        # LSP: All exceptions should be substitutable
        def handle_error(error: BaseApplicationError):
            return error.to_dict()
        
        validation_dict = handle_error(validation_error)
        business_dict = handle_error(business_error)
        
        assert "error_code" in validation_dict
        assert "error_code" in business_dict
    
    @pytest.mark.asyncio
    async def test_error_handler_factory_follows_ocp(self):
        """Test error handler factory follows OCP."""
        from src.application.exceptions.advanced_exceptions import ErrorHandlerFactory
        
        factory = ErrorHandlerFactory()
        
        # Should be open for extension with new handlers
        custom_handler = AsyncMock()
        custom_handler.can_handle.return_value = True
        
        factory.register_handler(custom_handler)
        
        error = ValidationError("Test error", "TEST_ERROR")
        handler = factory.get_handler(error)
        
        assert handler == custom_handler
    
    @pytest.mark.asyncio
    async def test_circuit_breaker_follows_solid(self):
        """Test circuit breaker follows SOLID principles."""
        from src.application.exceptions.advanced_exceptions import CircuitBreaker, CircuitBreakerConfig
        
        config = CircuitBreakerConfig(failure_threshold=3, recovery_timeout=60)
        circuit_breaker = CircuitBreaker(config)
        
        # SRP: Only handles circuit breaking logic
        async def failing_function():
            raise ExternalServiceError("Service down", "SERVICE_ERROR")
        
        # Should track failures
        for _ in range(3):
            with pytest.raises(ExternalServiceError):
                await circuit_breaker.call(failing_function)
        
        # Should open circuit after threshold
        with pytest.raises(ExternalServiceError, match="Circuit breaker is open"):
            await circuit_breaker.call(failing_function)


# ============================================================================
# DEPENDENCY INJECTION TESTS (Testing DI Container)
# ============================================================================

class TestDependencyInjection:
    """Test dependency injection system."""
    
    @pytest.mark.asyncio
    async def test_service_container_follows_solid(self):
        """Test service container follows SOLID principles."""
        from src.infrastructure.dependency_injection import ServiceContainer
        
        container = ServiceContainer()
        
        # SRP: Only handles service resolution
        # OCP: Open for extension with new service types
        # LSP: Implements IServiceContainer interface
        # ISP: Specific interface for DI
        # DIP: Depends on abstractions
        
        # Mock service interfaces
        class ITestService:
            pass
        
        class TestService(ITestService):
            def __init__(self):
                self.value = "test"
        
        # Should register and resolve services
        container.register_singleton(ITestService, TestService)
        service = await container.resolve(ITestService)
        
        assert isinstance(service, TestService)
        assert service.value == "test"
    
    @pytest.mark.asyncio
    async def test_service_scope_lifecycle(self):
        """Test service scope lifecycle management."""
        from src.infrastructure.dependency_injection import ServiceContainer
        
        container = ServiceContainer()
        
        class ITestService:
            pass
        
        class TestService(ITestService):
            def __init__(self):
                self.disposed = False
            
            def dispose(self):
                self.disposed = True
        
        container.register_scoped(ITestService, TestService)
        
        # Create scope and resolve service
        scope = container.create_scope()
        service = await scope.resolve(ITestService)
        
        assert not service.disposed
        
        # Dispose scope
        await scope.dispose()
        
        assert service.disposed


# ============================================================================
# INTEGRATION TESTS (Testing Full System Integration)
# ============================================================================

class TestSystemIntegration:
    """Test full system integration."""
    
    @pytest.mark.asyncio
    async def test_end_to_end_data_object_workflow(self, async_client):
        """Test complete data object workflow."""
        # Create data object
        create_payload = {
            "name": "integration_test_table",
            "object_type": "table",
            "description": "Integration test table",
            "schema_definition": {"columns": [{"name": "id", "type": "int"}]}
        }
        
        create_response = await async_client.post(
            "/api/v1/data-objects/", 
            json=create_payload
        )
        
        if create_response.status_code == 201:
            object_data = create_response.json()
            object_id = object_data["id"]
            
            # Get data object
            get_response = await async_client.get(f"/api/v1/data-objects/{object_id}")
            assert get_response.status_code == 200
            
            # Update data object
            update_payload = {
                "description": "Updated description"
            }
            update_response = await async_client.put(
                f"/api/v1/data-objects/{object_id}",
                json=update_payload
            )
            assert update_response.status_code in [200, 404]
    
    @pytest.mark.asyncio
    async def test_cross_domain_integration(self, async_client):
        """Test integration across different domains."""
        # This would test interactions between data objects, lineage, quality, etc.
        # Create data object, add lineage, create quality metrics, apply policies
        pass


# ============================================================================
# PERFORMANCE TESTS (Testing System Performance)
# ============================================================================

class TestPerformance:
    """Test system performance characteristics."""
    
    @pytest.mark.asyncio
    async def test_concurrent_requests_handling(self, async_client):
        """Test handling of concurrent requests."""
        import asyncio
        
        async def make_request():
            response = await async_client.get("/api/v1/health")
            return response.status_code
        
        # Create multiple concurrent requests
        tasks = [make_request() for _ in range(10)]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Should handle concurrent requests without errors
        successful_requests = [r for r in results if r == 200]
        assert len(successful_requests) > 0
    
    @pytest.mark.asyncio
    async def test_large_payload_handling(self, async_client):
        """Test handling of large payloads."""
        # Create large schema definition
        large_schema = {
            "columns": [
                {"name": f"column_{i}", "type": "varchar"}
                for i in range(1000)
            ]
        }
        
        payload = {
            "name": "large_table",
            "object_type": "table",
            "description": "Table with large schema",
            "schema_definition": large_schema
        }
        
        response = await async_client.post("/api/v1/data-objects/", json=payload)
        
        # Should handle large payloads or return appropriate error
        assert response.status_code in [201, 400, 413]


# ============================================================================
# SECURITY TESTS (Testing Security Features)
# ============================================================================

class TestSecurity:
    """Test security features."""
    
    @pytest.mark.asyncio
    async def test_authentication_required(self, async_client):
        """Test that authentication is required for protected endpoints."""
        # Try to access protected endpoint without authentication
        response = await async_client.post("/api/v1/data-objects/", json={})
        
        # Should require authentication
        assert response.status_code in [401, 403]
    
    @pytest.mark.asyncio
    async def test_input_validation_security(self, async_client):
        """Test input validation for security."""
        # Test SQL injection attempt
        malicious_payload = {
            "name": "'; DROP TABLE users; --",
            "object_type": "table",
            "description": "Malicious input"
        }
        
        response = await async_client.post("/api/v1/data-objects/", json=malicious_payload)
        
        # Should validate and reject malicious input
        assert response.status_code in [400, 401, 403]


# ============================================================================
# TEST UTILITIES AND HELPERS
# ============================================================================

class TestUtilities:
    """Utility functions for testing."""
    
    @staticmethod
    def create_test_data_object(**kwargs) -> Dict[str, Any]:
        """Create test data object payload."""
        default_data = {
            "name": "test_table",
            "object_type": "table",
            "description": "Test table",
            "schema_definition": {"columns": []}
        }
        default_data.update(kwargs)
        return default_data
    
    @staticmethod
    def create_test_lineage(**kwargs) -> Dict[str, Any]:
        """Create test lineage payload."""
        default_data = {
            "source_object_id": str(uuid4()),
            "target_object_id": str(uuid4()),
            "lineage_type": "table_to_table",
            "confidence_score": 0.95
        }
        default_data.update(kwargs)
        return default_data
    
    @staticmethod
    def assert_error_response(response, expected_status: int, expected_error_code: str):
        """Assert error response format."""
        assert response.status_code == expected_status
        error_data = response.json()
        assert "error_code" in error_data
        assert error_data["error_code"] == expected_error_code
        assert "error_id" in error_data
        assert "timestamp" in error_data


# ============================================================================
# TEST CONFIGURATION
# ============================================================================

# Pytest configuration
pytest_plugins = ["pytest_asyncio"]

# Test markers
pytestmark = [
    pytest.mark.asyncio,
    pytest.mark.timeout(30)  # 30 second timeout for all tests
]

# Test coverage configuration
def pytest_configure(config):
    """Configure pytest with custom settings."""
    config.addinivalue_line(
        "markers", "unit: mark test as unit test"
    )
    config.addinivalue_line(
        "markers", "integration: mark test as integration test"
    )
    config.addinivalue_line(
        "markers", "performance: mark test as performance test"
    )
    config.addinivalue_line(
        "markers", "security: mark test as security test"
    )

