# Sistema de Análise COBOL v2.7.0 - Guia de Início Rápido

##  Instalação e Execução em 3 Passos

### Passo 1: Extrair e Instalar
```bash
# Extrair o pacote
tar -xzf cobol_analysis_engine_v2.7.0_FINAL.tar.gz
cd cobol_analysis_engine_v2.7.0

# Instalar dependências
pip install -r requirements.txt
```

### Passo 2: Verificar se Funciona
```bash
# Verificar versão
python main.py --version

# Verificar status (configuração segura)
python main.py --config config/config_safe.yaml --status
```

### Passo 3: Executar Análise
```bash
# Análise básica (sempre funciona)
python main.py --config config/config_safe.yaml --fontes examples/fontes.txt --output resultado

# Análise completa com PDF
python main.py --config config/config_safe.yaml --fontes examples/fontes.txt --books examples/BOOKS.txt --output resultado --pdf
```

##  Provedores Disponíveis

### 1. Configuração Segura (Recomendada)
```bash
python main.py --config config/config_safe.yaml --fontes examples/fontes.txt --output resultado
```
-  **Sempre funciona** (Enhanced Mock + Basic)
-  **Não requer credenciais**
-  **Ideal para testes**

### 2. Databricks
```bash
# Configurar credenciais
export DATABRICKS_WORKSPACE_URL="https://seu-workspace.cloud.databricks.com"
export DATABRICKS_ACCESS_TOKEN="seu_token"

# Executar análise
python main.py --config config/config_databricks.yaml --fontes examples/fontes.txt --output resultado
```

### 3. AWS Bedrock
```bash
# Configurar credenciais AWS
export AWS_REGION="us-east-1"
export AWS_ACCESS_KEY_ID="seu_access_key"
export AWS_SECRET_ACCESS_KEY="seu_secret_key"

# Executar análise
python main.py --config config/config_bedrock.yaml --fontes examples/fontes.txt --output resultado
```

### 4. Luzanálise Real (Santander)
```bash
# Configurar credenciais corporativas
export LUZIA_CLIENT_ID="seu_client_id"
export LUZIA_CLIENT_SECRET="seu_client_secret"

# Executar análise
python main.py --config config/config_luzia_real.yaml --fontes examples/fontes.txt --output resultado
```

##  Configurações Disponíveis

| Configuração | Provedor Primário | Uso Recomendado | Credenciais |
|--------------|-------------------|-----------------|-------------|
| `config_safe.yaml` | Enhanced Mock | **Testes/Iniciantes** |  Não requer |
| `config_databricks.yaml` | Databricks | **Análise Avançada** |  Token Databricks |
| `config_bedrock.yaml` | AWS Bedrock | **Foundation Models** |  AWS Credentials |
| `config_luzia_real.yaml` | Luzanálise Real | **Ambiente Corporativo** |  OAuth2 Santander |
| `config_complete.yaml` | Enhanced Mock | **Configuração Completa** |  Customizável |

## 🆘 Solução de Problemas

### Se der erro de credenciais:
```bash
# Use sempre a configuração segura primeiro
python main.py --config config/config_safe.yaml --fontes examples/fontes.txt --output teste
```

### Se der erro de dependências:
```bash
# Instalar dependências específicas
pip install boto3  # Para AWS Bedrock
pip install databricks-sdk  # Para Databricks
pip install requests  # Para LuzIA
```

### Verificar status dos provedores:
```bash
# Ver todos os provedores disponíveis
python main.py --config config/config_complete.yaml --status

# Ver apenas provedores habilitados
python main.py --config config/config_safe.yaml --status
```

##  Comandos Úteis

```bash
# Ver ajuda completa
python main.py --help

# Verificar versão
python main.py --version

# Status detalhado
python main.py --config config/config_safe.yaml --status

# Listar perguntas disponíveis
python main.py --list-questions

# Análise com logs detalhados
python main.py --config config/config_safe.yaml --fontes examples/fontes.txt --output debug --log-level DEBUG

# Análise com PDF
python main.py --config config/config_safe.yaml --fontes examples/fontes.txt --output resultado --pdf
```

##  Sistema de Fallback

O sistema implementa fallback automático:

1. **Provedor Primário** tenta primeiro
2. **Provedores de Fallback** são tentados em ordem
3. **Enhanced Mock + Basic** sempre funcionam como último recurso

Exemplo de execução com fallback:
```bash
# Se Databricks falhar, tenta Enhanced Mock, depois Basic
python main.py --config config/config_databricks.yaml --fontes examples/fontes.txt --output resultado
```

## 🆕 Novidades da v2.7.0

-  **Provedor Databricks**: Foundation Models via Databricks
-  **Provedor AWS Bedrock**: Claude, Llama e outros modelos
-  **6 Provedores Disponíveis**: Máxima flexibilidade
-  **Configurações Específicas**: Para cada provedor
-  **Fallback Robusto**: Sistema nunca falha
-  **Autenticação Flexível**: Múltiplos métodos

##  Documentação Completa

- `docs/MANUAL_USUARIO.md`: Manual completo do usuário
- `docs/MANUAL_CONFIGURACAO.md`: Manual de configuração
- `docs/MANUAL_PROVEDORES.md`: Manual detalhado dos provedores
- `CHANGELOG.md`: Histórico de mudanças

##  Casos de Uso

### Desenvolvimento/Testes
```bash
python main.py --config config/config_safe.yaml --fontes examples/fontes.txt --output teste
```

### Análise Corporativa (Santander)
```bash
python main.py --config config/config_luzia_real.yaml --fontes examples/fontes.txt --output corporativo
```

### Análise com análise Avançada
```bash
python main.py --config config/config_databricks.yaml --fontes examples/fontes.txt --output avancado
```

### Análise com Foundation Models
```bash
python main.py --config config/config_bedrock.yaml --fontes examples/fontes.txt --output foundation
```

**Esta versão é 100% funcional e inclui suporte a múltiplos provedores de análise!**

