# Sistema de Análise COBOL v1.0.1

Sistema avançado de análise de programas COBOL com orquestração Multi-análise, validação cruzada e garantia de clareza na documentação.

## Características Principais

### Análise Multi-análise Orquestrada
- **4 análises especializadas** trabalhando em paralelo
- **Validação cruzada** automática entre resultados
- **Resolução de conflitos** inteligente
- **Garantia de clareza** na documentação gerada

### Especializações por Domínio
1. **Análise Estrutural**: Divisões COBOL, seções, organização
2. **Análise de Negócio**: Regras comerciais, processos, compliance
3. **Análise Técnica**: Algoritmos, performance, padrões
4. **Análise de Qualidade**: Validação, síntese, métricas

### Garantia de Clareza
- **5 métricas de clareza**: Legibilidade, compreensão, completude, consistência, acionabilidade
- **Adaptação por audiência**: Executiva, técnica, negócio, implementação
- **Refinamento automático** quando necessário
- **Certificação profissional** da documentação

## Instalação

### Requisitos
- Python 3.11+
- Dependências listadas em `requirements.txt`

### Instalação Rápida
```bash
# Extrair o pacote
tar -xzf cobol_analysis_engine_v1.0.1.tar.gz
cd cobol_analysis_engine_v2.0.0

# Instalar dependências
pip install -r requirements.txt

# Testar instalação
python main.py --help
```

## Uso

### Análise Multi-análise Completa
```bash
python main.py programa.cbl --copybooks copybooks.txt --output resultados/
```

### Opções Avançadas
```bash
# Análise para audiência específica
python main.py programa.cbl --audience executive --output exec_results/

# Com configuração personalizada
python main.py programa.cbl --config config/custom.yaml --verbose

# Análise técnica detalhada
python main.py programa.cbl --audience technical --output tech_analysis/
```

### Análise Tradicional (Compatibilidade)
```bash
# Usar script tradicional se necessário
python main.py fontes.txt books.txt --output traditional_results/
```

## Configuração

### Arquivo de Configuração Principal
O sistema usa `config/config.yaml` para configuração:

```yaml
# Configuração Multi-análise
multi_ai:
  enabled: true
  parallel_execution: true
  cross_validation: true
  clarity_validation: true

# análises Especializadas
specialized_ais:
  structural_ai:
    provider: openai
    model: gpt-4
    temperature: 0.1
  business_ai:
    provider: luzia
    model: claude-3-5-sonnet
    temperature: 0.2
  technical_ai:
    provider: copilot
    model: gpt-4
    temperature: 0.1
  quality_ai:
    provider: enhanced_mock
    model: mock-model
    temperature: 0.1

# Validação Cruzada
cross_validation:
  consensus_threshold: 0.75
  conflict_threshold: 0.3
  min_agreement_ratio: 0.6

# Garantia de Clareza
clarity:
  minimum_score: 0.8
  target_audiences: [technical, business, executive, implementation]
```

### Provedores Suportados
- **OpenAI GPT-4**: Análise estrutural (recomendado)
- **GitHub Copilot**: Análise técnica
- **LuzIA**: Análise de negócio
- **Enhanced Mock**: Testes e desenvolvimento

## Estrutura do Projeto

```
cobol_analysis_engine_v2.0.0/
├── README.md                    # Este arquivo
├── main.py            # Script Multi-análise principal
├── main.py                     # Script tradicional (compatibilidade)
├── main_demo.py                # Demonstração rápida
├── requirements.txt            # Dependências Python
├── config/
│   ├── config.yaml            # Configuração principal
│   └── prompts.yaml           # Templates de prompts
├── src/
│   ├── core/                  # Componentes principais
│   │   ├── multi_ai_orchestrator.py
│   │   ├── cross_validator.py
│   │   └── clarity_engine.py
│   ├── providers/             # Provedores de análise
│   ├── analyzers/             # Analisadores especializados
│   ├── generators/            # Geradores de documentação
│   └── utils/                 # Utilitários
├── examples/                  # Arquivos de exemplo
└── docs/                      # Documentação completa
```

## Resultados da Análise

### Documentação Gerada
- **Resumo Executivo**: Visão geral para gestores
- **Análise Detalhada**: Resultados por domínio de especialização
- **Recomendações**: Próximos passos baseados na análise
- **Relatório de Validação**: Métricas de consenso e confiança
- **Guia de Implementação**: Orientações para modernização

### Métricas de Qualidade
- **Confiança da Validação**: Consenso entre análises (0-100%)
- **Score de Clareza**: Qualidade da documentação (0-100%)
- **Tempo de Execução**: Performance do sistema
- **análises Utilizadas**: Número de análises bem-sucedidas

## Casos de Uso

### Modernização de Sistemas Legacy
```bash
# Análise completa para modernização
python main.py sistema_legacy.cbl --audience implementation --output modernization/
```

### Auditoria de Código
```bash
# Análise focada em qualidade
python main.py programa.cbl --audience technical --output auditoria/
```

### Documentação para Gestores
```bash
# Relatório executivo
python main.py sistema.cbl --audience executive --output relatorio_executivo/
```

### Análise de Regras de Negócio
```bash
# Foco em processos comerciais
python main.py programa.cbl --audience business --output regras_negocio/
```

## Solução de Problemas

### Problemas Comuns

**Erro de configuração de provedor:**
```bash
# Verificar configuração
python -c "import yaml; print(yaml.safe_load(open('config/config.yaml')))"
```

**Baixa confiança na validação:**
- Verificar se múltiplos provedores estão configurados
- Ajustar thresholds de consenso no config.yaml
- Revisar qualidade do código COBOL de entrada

**Score de clareza baixo:**
- Verificar audiência alvo especificada
- Ajustar configurações de clareza
- Usar refinamento automático (habilitado por padrão)

### Logs e Depuração
```bash
# Executar com logging detalhado
python main.py programa.cbl --verbose

# Verificar logs
tail -f cobol_analysis.log
```

## Compatibilidade

### Versões COBOL Suportadas
- COBOL-85
- COBOL-2002  
- COBOL-2014
- Dialetos mainframe (IBM, Micro Focus)

### Sistemas Operacionais
- Linux (testado)
- macOS (Intel + Apple Silicon)
- Windows (compatível)

### Versões Python
- Python 3.11+ (recomendado)
- Python 3.10+ (compatível)

## Desenvolvimento

### Executar Testes
```bash
# Testes da implementação Multi-análise
python test_multi_ai_implementation.py

# Testes tradicionais
python -m pytest tests/ -v
```

### Contribuição
1. Fork do repositório
2. Criar branch para feature
3. Implementar mudanças
4. Executar testes
5. Submeter pull request

## Licença

Sistema de Análise COBOL v1.0.1
Todos os direitos reservados.

## Suporte

Para suporte técnico e dúvidas:
- Consultar documentação em `docs/`
- Verificar logs de execução
- Revisar configurações do sistema

---

**Sistema de Análise COBOL v1.0.1** - Análise Multi-análise com Garantia de Clareza
