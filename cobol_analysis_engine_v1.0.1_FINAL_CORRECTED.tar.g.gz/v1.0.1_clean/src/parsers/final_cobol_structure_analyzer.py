import re
import logging
from typing import List, Dict, Any, Set

class FinalCOBOLStructureAnalyzer:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.division_pattern = re.compile(r"^([A-Z\-]+)\s+DIVISION\.", re.IGNORECASE)
        self.section_pattern = re.compile(r"^([A-Z0-9\-]+)\s+SECTION\.", re.IGNORECASE)
        self.paragraph_pattern = re.compile(r"^([A-Z0-9\-]+)\.")
        self.perform_pattern = re.compile(r"PERFORM\s+([A-Z0-9\-]+)", re.IGNORECASE)
        self.go_to_pattern = re.compile(r"GO\s+TO\s+([A-Z0-9\-]+)", re.IGNORECASE)

    def analyze(self, lines: List[str]) -> Dict[str, Any]:
        self.logger.info("Iniciando o analisador de estrutura final.")
        
        divisions: List[str] = []
        sections: Dict[str, List[str]] = {}
        paragraphs: Dict[str, int] = {}
        control_flow: Dict[str, Set[str]] = {}
        program_id = "UNKNOWN"

        current_division = None
        current_section = None

        for i, line in enumerate(lines):
            clean_line = line[6:].strip()
            if not clean_line or clean_line.startswith("*"):
                continue

            if "PROGRAM-ID." in line:
                program_id = line.split("PROGRAM-ID.")[1].strip().split()[0]

            div_match = self.division_pattern.match(clean_line)
            if div_match:
                current_division = div_match.group(1).upper()
                divisions.append(current_division)
                current_section = None # Reset section on new division
                continue

            if current_division == "PROCEDURE":
                sec_match = self.section_pattern.match(clean_line)
                if sec_match:
                    current_section = sec_match.group(1)
                    sections[current_section] = []
                    control_flow[current_section] = set()
                    continue

                para_match = self.paragraph_pattern.match(clean_line)
                if para_match:
                    paragraph_name = para_match.group(1)
                    if paragraph_name.upper() not in ["SECTION", "DIVISION"]:
                        paragraphs[paragraph_name] = i
                        if current_section:
                            sections[current_section].append(paragraph_name)
                        if paragraph_name not in control_flow:
                            control_flow[paragraph_name] = set()

                        # Analyze control flow within the paragraph
                        self._analyze_paragraph_flow(lines, i, paragraph_name, control_flow)

        self.logger.info(f"Análise estrutural finalizada para {program_id}.")
        return {
            "program_id": program_id,
            "divisions": divisions,
            "sections": sections,
            "paragraphs": list(paragraphs.keys()),
            "control_flow_graph": {k: list(v) for k, v in control_flow.items()}
        }

    def _analyze_paragraph_flow(self, lines: List[str], start_line: int, current_para: str, control_flow: Dict[str, Set[str]]):
        for i in range(start_line, len(lines)):
            line = lines[i][6:].strip()
            if not line or line.startswith("*"):
                continue

            # Stop at the next paragraph/section/division
            if self.paragraph_pattern.match(line) and i > start_line:
                break
            if self.section_pattern.match(line):
                break
            if self.division_pattern.match(line):
                break

            perf_match = self.perform_pattern.search(line)
            if perf_match:
                target = perf_match.group(1)
                control_flow[current_para].add(target)

            go_match = self.go_to_pattern.search(line)
            if go_match:
                target = go_match.group(1)
                control_flow[current_para].add(target)

