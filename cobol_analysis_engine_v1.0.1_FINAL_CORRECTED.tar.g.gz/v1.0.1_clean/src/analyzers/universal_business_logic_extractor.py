"""
Sistema de Análise COBOL v15.0 - Universal Business Logic Extractor
Extrator universal de lógica de negócio que funciona com qualquer programa COBOL.
"""

import re
import logging
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass


@dataclass
class BusinessRule:
    """Representa uma regra de negócio identificada."""
    id: str
    description: str
    condition: str
    action: str
    context: str
    line_number: int
    confidence: float = 0.0
    category: str = "general"


@dataclass
class DecisionPoint:
    """Representa um ponto de decisão no programa."""
    name: str
    type: str  # "IF", "EVALUATE", "PERFORM"
    conditions: List[str]
    actions: List[str]
    line_number: int
    complexity: int = 1


@dataclass
class DataFlow:
    """Representa fluxo de dados entre variáveis/arquivos."""
    source: str
    target: str
    operation: str  # "READ", "WRITE", "MOVE", "COMPUTE"
    context: str
    line_number: int


class UniversalBusinessLogicExtractor:
    """
    Extrator universal de lógica de negócio COBOL.
    Funciona com qualquer programa COBOL, identificando padrões universais.
    """
    
    def __init__(self):
        self.logger = logging.getLogger(self.__class__.__name__)
        
        # Padrões universais COBOL
        self.if_pattern = re.compile(r'^\s*IF\s+(.+?)(?:\s+THEN)?$', re.IGNORECASE | re.MULTILINE)
        self.evaluate_pattern = re.compile(r'^\s*EVALUATE\s+(.+?)$', re.IGNORECASE)
        self.when_pattern = re.compile(r'^\s*WHEN\s+(.+?)$', re.IGNORECASE)
        self.perform_pattern = re.compile(r'^\s*PERFORM\s+([A-Z0-9\-]+)', re.IGNORECASE)
        self.move_pattern = re.compile(r'^\s*MOVE\s+(.+?)\s+TO\s+(.+?)(?:\s|$)', re.IGNORECASE)
        self.compute_pattern = re.compile(r'^\s*COMPUTE\s+(.+?)\s*=\s*(.+?)(?:\s|$)', re.IGNORECASE)
        self.read_pattern = re.compile(r'^\s*READ\s+([A-Z0-9\-]+)', re.IGNORECASE)
        self.write_pattern = re.compile(r'^\s*WRITE\s+([A-Z0-9\-]+)', re.IGNORECASE)
        self.call_pattern = re.compile(r'^\s*CALL\s+["\']([^"\']+)["\']', re.IGNORECASE)
        
        # Padrões para identificar tipos de lógica
        self.validation_keywords = ['INVALID', 'ERROR', 'ERRO', 'VALIDA', 'CHECK', 'VERIFICA']
        self.calculation_keywords = ['COMPUTE', 'ADD', 'SUBTRACT', 'MULTIPLY', 'DIVIDE', 'SOMA', 'CALCULA']
        self.control_keywords = ['COUNTER', 'CONTADOR', 'LIMIT', 'LIMITE', 'MAX', 'MIN']
        self.business_keywords = ['CLIENTE', 'CONTA', 'VALOR', 'SALDO', 'TAXA', 'JUROS', 'MULTA']
        
    def extract(self, program_lines: List[str], program_name: str = "UNKNOWN") -> Dict[str, Any]:
        """
        Extrai lógica de negócio de qualquer programa COBOL.
        
        Args:
            program_lines: Linhas do programa COBOL
            program_name: Nome do programa (opcional)
            
        Returns:
            Dict com lógica de negócio extraída
        """
        self.logger.info(f"Extraindo lógica de negócio universal do programa {program_name}")
        
        try:
            # Extração de regras de negócio
            business_rules = self._extract_business_rules(program_lines)
            
            # Extração de pontos de decisão
            decision_points = self._extract_decision_points(program_lines)
            
            # Extração de fluxo de dados
            data_flows = self._extract_data_flows(program_lines)
            
            # Extração de validações
            validations = self._extract_validations(program_lines)
            
            # Extração de cálculos
            calculations = self._extract_calculations(program_lines)
            
            # Extração de controles
            controls = self._extract_controls(program_lines)
            
            # Análise de complexidade
            complexity_analysis = self._analyze_complexity(decision_points, business_rules)
            
            # Identificação de padrões
            patterns = self._identify_patterns(program_lines, business_rules, decision_points)
            
            result = {
                'program_name': program_name,
                'business_rules': [self._rule_to_dict(rule) for rule in business_rules],
                'decision_points': [self._decision_to_dict(dp) for dp in decision_points],
                'data_flows': [self._flow_to_dict(flow) for flow in data_flows],
                'validations': validations,
                'calculations': calculations,
                'controls': controls,
                'complexity_analysis': complexity_analysis,
                'patterns': patterns,
                'statistics': {
                    'total_business_rules': len(business_rules),
                    'total_decision_points': len(decision_points),
                    'total_data_flows': len(data_flows),
                    'total_validations': len(validations),
                    'total_calculations': len(calculations),
                    'complexity_score': complexity_analysis.get('total_complexity', 0)
                }
            }
            
            self.logger.info(f"Extração concluída: {len(business_rules)} regras, {len(decision_points)} decisões")
            return result
            
        except Exception as e:
            self.logger.error(f"Erro na extração de lógica: {str(e)}")
            return {
                'program_name': program_name,
                'error': str(e),
                'business_rules': [],
                'decision_points': [],
                'data_flows': [],
                'validations': [],
                'calculations': [],
                'controls': [],
                'complexity_analysis': {},
                'patterns': []
            }
    
    def _extract_business_rules(self, lines: List[str]) -> List[BusinessRule]:
        """Extrai regras de negócio do programa."""
        rules = []
        rule_counter = 1
        
        for i, line in enumerate(lines):
            line_clean = line.strip()
            if not line_clean or line_clean.startswith('*'):
                continue
            
            # Regras baseadas em IF
            if_match = self.if_pattern.match(line_clean)
            if if_match:
                condition = if_match.group(1).strip()
                
                # Procura a ação correspondente
                action = self._find_corresponding_action(lines, i)
                
                rule = BusinessRule(
                    id=f"RN{rule_counter:03d}",
                    description=self._generate_rule_description(condition, action),
                    condition=condition,
                    action=action,
                    context="conditional_logic",
                    line_number=i + 1,
                    confidence=self._calculate_rule_confidence(condition, action),
                    category=self._categorize_rule(condition, action)
                )
                rules.append(rule)
                rule_counter += 1
            
            # Regras baseadas em EVALUATE
            elif self.evaluate_pattern.match(line_clean):
                evaluate_rules = self._extract_evaluate_rules(lines, i)
                for rule in evaluate_rules:
                    rule.id = f"RN{rule_counter:03d}"
                    rules.append(rule)
                    rule_counter += 1
        
        return rules
    
    def _extract_decision_points(self, lines: List[str]) -> List[DecisionPoint]:
        """Extrai pontos de decisão do programa."""
        decision_points = []
        
        for i, line in enumerate(lines):
            line_clean = line.strip()
            
            # IF statements
            if_match = self.if_pattern.match(line_clean)
            if if_match:
                condition = if_match.group(1).strip()
                actions = self._extract_if_actions(lines, i)
                
                dp = DecisionPoint(
                    name=f"IF-{i+1}",
                    type="IF",
                    conditions=[condition],
                    actions=actions,
                    line_number=i + 1,
                    complexity=self._calculate_if_complexity(condition, actions)
                )
                decision_points.append(dp)
            
            # EVALUATE statements
            elif self.evaluate_pattern.match(line_clean):
                evaluate_dp = self._extract_evaluate_decision(lines, i)
                if evaluate_dp:
                    decision_points.append(evaluate_dp)
            
            # PERFORM statements
            elif self.perform_pattern.match(line_clean):
                perform_match = self.perform_pattern.match(line_clean)
                paragraph_name = perform_match.group(1)
                
                dp = DecisionPoint(
                    name=f"PERFORM-{paragraph_name}",
                    type="PERFORM",
                    conditions=[],
                    actions=[f"Execute {paragraph_name}"],
                    line_number=i + 1,
                    complexity=1
                )
                decision_points.append(dp)
        
        return decision_points
    
    def _extract_data_flows(self, lines: List[str]) -> List[DataFlow]:
        """Extrai fluxos de dados do programa."""
        data_flows = []
        
        for i, line in enumerate(lines):
            line_clean = line.strip()
            
            # MOVE statements
            move_match = self.move_pattern.match(line_clean)
            if move_match:
                source = move_match.group(1).strip()
                target = move_match.group(2).strip()
                
                flow = DataFlow(
                    source=source,
                    target=target,
                    operation="MOVE",
                    context="data_transfer",
                    line_number=i + 1
                )
                data_flows.append(flow)
            
            # COMPUTE statements
            compute_match = self.compute_pattern.match(line_clean)
            if compute_match:
                target = compute_match.group(1).strip()
                expression = compute_match.group(2).strip()
                
                flow = DataFlow(
                    source=expression,
                    target=target,
                    operation="COMPUTE",
                    context="calculation",
                    line_number=i + 1
                )
                data_flows.append(flow)
            
            # READ statements
            read_match = self.read_pattern.match(line_clean)
            if read_match:
                file_name = read_match.group(1)
                
                flow = DataFlow(
                    source=file_name,
                    target="program_memory",
                    operation="READ",
                    context="file_input",
                    line_number=i + 1
                )
                data_flows.append(flow)
            
            # WRITE statements
            write_match = self.write_pattern.match(line_clean)
            if write_match:
                file_name = write_match.group(1)
                
                flow = DataFlow(
                    source="program_memory",
                    target=file_name,
                    operation="WRITE",
                    context="file_output",
                    line_number=i + 1
                )
                data_flows.append(flow)
        
        return data_flows
    
    def _extract_validations(self, lines: List[str]) -> List[Dict[str, Any]]:
        """Extrai validações do programa."""
        validations = []
        
        for i, line in enumerate(lines):
            line_upper = line.upper()
            
            # Procura por palavras-chave de validação
            for keyword in self.validation_keywords:
                if keyword in line_upper:
                    validation = {
                        'type': 'validation',
                        'keyword': keyword,
                        'line': i + 1,
                        'content': line.strip(),
                        'description': self._generate_validation_description(line, keyword)
                    }
                    validations.append(validation)
                    break
        
        return validations
    
    def _extract_calculations(self, lines: List[str]) -> List[Dict[str, Any]]:
        """Extrai cálculos do programa."""
        calculations = []
        
        for i, line in enumerate(lines):
            line_upper = line.upper()
            
            # Procura por palavras-chave de cálculo
            for keyword in self.calculation_keywords:
                if keyword in line_upper:
                    calculation = {
                        'type': 'calculation',
                        'keyword': keyword,
                        'line': i + 1,
                        'content': line.strip(),
                        'description': self._generate_calculation_description(line, keyword)
                    }
                    calculations.append(calculation)
                    break
        
        return calculations
    
    def _extract_controls(self, lines: List[str]) -> List[Dict[str, Any]]:
        """Extrai controles do programa."""
        controls = []
        
        for i, line in enumerate(lines):
            line_upper = line.upper()
            
            # Procura por palavras-chave de controle
            for keyword in self.control_keywords:
                if keyword in line_upper:
                    control = {
                        'type': 'control',
                        'keyword': keyword,
                        'line': i + 1,
                        'content': line.strip(),
                        'description': self._generate_control_description(line, keyword)
                    }
                    controls.append(control)
                    break
        
        return controls
    
    def _find_corresponding_action(self, lines: List[str], if_line: int) -> str:
        """Encontra a ação correspondente a um IF."""
        # Procura nas próximas linhas por ações
        for i in range(if_line + 1, min(if_line + 5, len(lines))):
            line = lines[i].strip()
            if line and not line.startswith('*'):
                if any(keyword in line.upper() for keyword in ['MOVE', 'PERFORM', 'COMPUTE', 'WRITE', 'READ']):
                    return line
                elif line.upper().startswith('ELSE'):
                    break
        
        return "Ação não identificada"
    
    def _extract_if_actions(self, lines: List[str], if_line: int) -> List[str]:
        """Extrai ações de um IF statement."""
        actions = []
        
        for i in range(if_line + 1, min(if_line + 10, len(lines))):
            line = lines[i].strip()
            if not line or line.startswith('*'):
                continue
            
            if line.upper().startswith(('ELSE', 'END-IF')):
                break
            
            if any(keyword in line.upper() for keyword in ['MOVE', 'PERFORM', 'COMPUTE', 'WRITE', 'READ', 'CALL']):
                actions.append(line)
        
        return actions
    
    def _extract_evaluate_rules(self, lines: List[str], evaluate_line: int) -> List[BusinessRule]:
        """Extrai regras de um EVALUATE statement."""
        rules = []
        evaluate_var = self.evaluate_pattern.match(lines[evaluate_line]).group(1)
        
        for i in range(evaluate_line + 1, len(lines)):
            line = lines[i].strip()
            if not line or line.startswith('*'):
                continue
            
            if line.upper().startswith('END-EVALUATE'):
                break
            
            when_match = self.when_pattern.match(line)
            if when_match:
                when_value = when_match.group(1)
                action = self._find_corresponding_action(lines, i)
                
                rule = BusinessRule(
                    id="",  # Will be set by caller
                    description=f"Quando {evaluate_var} = {when_value}, então {action}",
                    condition=f"{evaluate_var} = {when_value}",
                    action=action,
                    context="evaluate_logic",
                    line_number=i + 1,
                    confidence=0.8,
                    category="conditional"
                )
                rules.append(rule)
        
        return rules
    
    def _extract_evaluate_decision(self, lines: List[str], evaluate_line: int) -> Optional[DecisionPoint]:
        """Extrai ponto de decisão de um EVALUATE."""
        evaluate_match = self.evaluate_pattern.match(lines[evaluate_line])
        if not evaluate_match:
            return None
        
        evaluate_var = evaluate_match.group(1)
        conditions = []
        actions = []
        
        for i in range(evaluate_line + 1, len(lines)):
            line = lines[i].strip()
            if not line or line.startswith('*'):
                continue
            
            if line.upper().startswith('END-EVALUATE'):
                break
            
            when_match = self.when_pattern.match(line)
            if when_match:
                when_value = when_match.group(1)
                conditions.append(f"{evaluate_var} = {when_value}")
                
                # Procura ação correspondente
                action = self._find_corresponding_action(lines, i)
                actions.append(action)
        
        return DecisionPoint(
            name=f"EVALUATE-{evaluate_var}",
            type="EVALUATE",
            conditions=conditions,
            actions=actions,
            line_number=evaluate_line + 1,
            complexity=len(conditions)
        )
    
    def _generate_rule_description(self, condition: str, action: str) -> str:
        """Gera descrição inteligente para regra de negócio."""
        # Simplifica condição e ação para descrição mais clara
        condition_clean = condition.replace('NOT', 'não').replace('AND', 'e').replace('OR', 'ou')
        
        if 'INVALID' in condition.upper() or 'ERROR' in condition.upper():
            return f"Validação: Se {condition_clean}, então {action}"
        elif any(kw in condition.upper() for kw in self.business_keywords):
            return f"Regra de negócio: Se {condition_clean}, então {action}"
        else:
            return f"Condição: Se {condition_clean}, então {action}"
    
    def _categorize_rule(self, condition: str, action: str) -> str:
        """Categoriza regra de negócio."""
        condition_upper = condition.upper()
        action_upper = action.upper()
        
        if any(kw in condition_upper for kw in self.validation_keywords):
            return "validation"
        elif any(kw in condition_upper for kw in self.calculation_keywords):
            return "calculation"
        elif any(kw in condition_upper for kw in self.control_keywords):
            return "control"
        elif any(kw in condition_upper for kw in self.business_keywords):
            return "business"
        else:
            return "general"
    
    def _calculate_rule_confidence(self, condition: str, action: str) -> float:
        """Calcula confiança da regra baseada na clareza."""
        confidence = 0.5  # Base
        
        # Aumenta confiança se tiver palavras-chave específicas
        if any(kw in condition.upper() for kw in self.business_keywords):
            confidence += 0.2
        
        if any(kw in action.upper() for kw in ['MOVE', 'COMPUTE', 'PERFORM']):
            confidence += 0.2
        
        # Diminui se for muito genérica
        if 'não identificada' in action.lower():
            confidence -= 0.3
        
        return max(0.1, min(1.0, confidence))
    
    def _calculate_if_complexity(self, condition: str, actions: List[str]) -> int:
        """Calcula complexidade de um IF statement."""
        complexity = 1
        
        # Aumenta por operadores lógicos
        complexity += condition.upper().count('AND')
        complexity += condition.upper().count('OR')
        complexity += condition.upper().count('NOT')
        
        # Aumenta por número de ações
        complexity += len(actions)
        
        return complexity
    
    def _analyze_complexity(self, decision_points: List[DecisionPoint], business_rules: List[BusinessRule]) -> Dict[str, Any]:
        """Analisa complexidade geral do programa."""
        total_complexity = sum(dp.complexity for dp in decision_points)
        
        complexity_by_type = {}
        for dp in decision_points:
            if dp.type not in complexity_by_type:
                complexity_by_type[dp.type] = 0
            complexity_by_type[dp.type] += dp.complexity
        
        return {
            'total_complexity': total_complexity,
            'average_complexity': total_complexity / max(1, len(decision_points)),
            'complexity_by_type': complexity_by_type,
            'high_complexity_points': [dp.name for dp in decision_points if dp.complexity > 5],
            'total_decision_points': len(decision_points),
            'total_business_rules': len(business_rules)
        }
    
    def _identify_patterns(self, lines: List[str], business_rules: List[BusinessRule], decision_points: List[DecisionPoint]) -> List[Dict[str, Any]]:
        """Identifica padrões no programa."""
        patterns = []
        
        # Padrão de validação
        validation_rules = [rule for rule in business_rules if rule.category == "validation"]
        if len(validation_rules) > 2:
            patterns.append({
                'name': 'Padrão de Validação',
                'type': 'validation_pattern',
                'description': f'Programa implementa {len(validation_rules)} validações',
                'confidence': 0.8,
                'elements': len(validation_rules)
            })
        
        # Padrão de processamento sequencial
        read_count = sum(1 for line in lines if 'READ' in line.upper())
        write_count = sum(1 for line in lines if 'WRITE' in line.upper())
        if read_count > 0 and write_count > 0:
            patterns.append({
                'name': 'Padrão de Processamento Sequencial',
                'type': 'sequential_processing',
                'description': f'Lê de {read_count} fontes e escreve em {write_count} destinos',
                'confidence': 0.9,
                'elements': read_count + write_count
            })
        
        # Padrão de controle
        control_keywords_found = sum(1 for line in lines if any(kw in line.upper() for kw in self.control_keywords))
        if control_keywords_found > 3:
            patterns.append({
                'name': 'Padrão de Controle',
                'type': 'control_pattern',
                'description': f'Implementa {control_keywords_found} controles',
                'confidence': 0.7,
                'elements': control_keywords_found
            })
        
        return patterns
    
    def _generate_validation_description(self, line: str, keyword: str) -> str:
        """Gera descrição para validação."""
        return f"Validação identificada: {keyword} - {line.strip()}"
    
    def _generate_calculation_description(self, line: str, keyword: str) -> str:
        """Gera descrição para cálculo."""
        return f"Cálculo identificado: {keyword} - {line.strip()}"
    
    def _generate_control_description(self, line: str, keyword: str) -> str:
        """Gera descrição para controle."""
        return f"Controle identificado: {keyword} - {line.strip()}"
    
    def _rule_to_dict(self, rule: BusinessRule) -> Dict[str, Any]:
        """Converte BusinessRule para dicionário."""
        return {
            'id': rule.id,
            'description': rule.description,
            'condition': rule.condition,
            'action': rule.action,
            'context': rule.context,
            'line_number': rule.line_number,
            'confidence': rule.confidence,
            'category': rule.category
        }
    
    def _decision_to_dict(self, dp: DecisionPoint) -> Dict[str, Any]:
        """Converte DecisionPoint para dicionário."""
        return {
            'name': dp.name,
            'type': dp.type,
            'conditions': dp.conditions,
            'actions': dp.actions,
            'line_number': dp.line_number,
            'complexity': dp.complexity
        }
    
    def _flow_to_dict(self, flow: DataFlow) -> Dict[str, Any]:
        """Converte DataFlow para dicionário."""
        return {
            'source': flow.source,
            'target': flow.target,
            'operation': flow.operation,
            'context': flow.context,
            'line_number': flow.line_number
        }
