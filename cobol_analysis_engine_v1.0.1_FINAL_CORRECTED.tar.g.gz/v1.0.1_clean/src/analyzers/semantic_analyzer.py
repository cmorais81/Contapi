import logging
import re
from typing import Dict, Any, List

class SemanticAnalyzer:
    """Analisa o código COBOL para extrair a semântica e a lógica de negócio usando um provedor de LLM."""

    def __init__(self, provider_manager: Any):
        self.logger = logging.getLogger(__name__)
        self.provider_manager = provider_manager

    def analyze(self, program_name: str, resolved_code: str, structural_analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Gera um prompt, envia para o provedor e processa a resposta."""
        self.logger.info(f"Iniciando análise semântica para o programa: {program_name}")

        prompt = self._generate_prompt(program_name, resolved_code, structural_analysis)

        # Em um cenário real, aqui seria a chamada para o provider_manager
        response = self.provider_manager.generate_text(prompt)

        return self._parse_llm_response(response)

    def _generate_prompt(self, program_name: str, resolved_code: str, structural_analysis: Dict[str, Any]) -> str:
        """Gera um prompt detalhado para o LLM analisar o programa COBOL."""
        prompt = f"""Análise de Programa COBOL: {program_name}

# Código-Fonte COBOL Completo (com copybooks resolvidos):

```cobol
{resolved_code}
```

# Análise Estrutural Preliminar:

- **Divisões:** {", ".join(structural_analysis.get("divisions", []))}
- **Seções:** {", ".join(structural_analysis.get("sections", {}).keys())}
- **Parágrafos:** {", ".join(structural_analysis.get("paragraphs", []))}

# Tarefa:

Com base no código-fonte e na análise estrutural, forneça uma análise semântica detalhada deste programa. Sua resposta deve ser em formato YAML e conter as seguintes seções:

1.  **purpose**: Uma descrição clara e concisa do propósito principal do programa (ex: "Particiona um arquivo de entrada em múltiplos arquivos de saída com base em um critério de tipo de registro").
2.  **business_rules**:
    - Uma lista de todas as regras de negócio implementadas no programa.
    - Para cada regra, explique a condição e a ação resultante.
    - Exemplo: "Se o tipo de registro for '01' ou '02', o registro é gravado no arquivo de saída S1DQ0705."
3.  **data_flow**:
    - Descreva o fluxo de dados do programa, desde os arquivos de entrada até os arquivos de saída.
    - Mencione quaisquer transformações ou validações que ocorrem nos dados.
4.  **critical_logic_points**:
    - Identifique e explique os pontos mais críticos ou complexos da lógica do programa.
    - Exemplo: "A lógica de particionamento dinâmico na seção 2210-GRAVAR-S1, que fecha e reabre o arquivo de saída a cada 50.000 registros."

**Formato da Resposta (YAML):**

```yaml
purpose: "..."
business_rules:
  - "..."
  - "..."
data_flow: "..."
critical_logic_points:
  - "..."
```
"""
        return prompt

    def _parse_llm_response(self, response: str) -> Dict[str, Any]:
        """Faz o parsing da resposta YAML do LLM."""
        try:
            # Extrai o conteúdo do bloco de código YAML
            yaml_content = re.search(r"```yaml\n(.*?)\n```", response, re.DOTALL)
            if yaml_content:
                import yaml
                return yaml.safe_load(yaml_content.group(1))
            else:
                return {"error": "Formato de resposta inválido."}
        except Exception as e:
            self.logger.error(f"Erro ao fazer o parsing da resposta do LLM: {e}")
            return {"error": str(e)}

