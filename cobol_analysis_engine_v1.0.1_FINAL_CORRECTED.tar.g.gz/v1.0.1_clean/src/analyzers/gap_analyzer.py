import re
import logging
from typing import Dict, Any, List

class GapAnalyzer:
    """
    Analisador de lacunas que identifica especificamente o que está faltando
    na documentação para permitir reimplementação completa.
    """

    def __init__(self):
        self.logger = logging.getLogger(__name__)

    def analyze_gaps(self, program_name: str, documentation: str, 
                    original_code: str, analysis_results: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analisa as lacunas críticas na documentação que impedem reimplementação.
        """
        self.logger.info(f"Analisando lacunas críticas para {program_name}")

        gaps = {
            "business_logic_gaps": self._identify_business_logic_gaps(original_code, documentation),
            "decision_logic_gaps": self._identify_decision_logic_gaps(original_code, documentation),
            "validation_gaps": self._identify_validation_gaps(original_code, documentation),
            "error_handling_gaps": self._identify_error_handling_gaps(original_code, documentation),
            "data_flow_gaps": self._identify_data_flow_gaps(original_code, documentation),
            "performance_gaps": self._identify_performance_gaps(original_code, documentation),
            "code_generation_gaps": self._identify_code_generation_gaps(documentation)
        }

        # Prioriza as lacunas por criticidade
        prioritized_gaps = self._prioritize_gaps(gaps)

        return {
            "program_name": program_name,
            "gaps_identified": gaps,
            "prioritized_gaps": prioritized_gaps,
            "total_gaps": sum(len(gap_list) for gap_list in gaps.values()),
            "critical_gaps": len(prioritized_gaps.get("critical", [])),
            "reimplementation_blockers": self._identify_reimplementation_blockers(gaps)
        }

    def _identify_business_logic_gaps(self, code: str, documentation: str) -> List[Dict[str, str]]:
        """Identifica lacunas na lógica de negócio."""
        gaps = []

        # Procura por EVALUATE statements não documentados adequadamente
        evaluate_matches = re.findall(r'EVALUATE\s+([^\n]+)', code, re.IGNORECASE)
        for match in evaluate_matches:
            if "Condições específicas" in documentation:
                gaps.append({
                    "type": "evaluate_logic",
                    "description": f"EVALUATE {match} não documentado especificamente",
                    "impact": "critical",
                    "missing_info": "Condições exatas e ações para cada caso"
                })

        # Procura por IF statements complexos
        if_matches = re.findall(r'IF\s+([^THEN]+)THEN', code, re.IGNORECASE)
        for match in if_matches:
            if len(match.strip()) > 20:  # IF complexo
                gaps.append({
                    "type": "complex_condition",
                    "description": f"Condição complexa não detalhada: {match[:50]}...",
                    "impact": "high",
                    "missing_info": "Lógica específica da condição"
                })

        # Procura por PERFORM statements com lógica específica
        perform_matches = re.findall(r'PERFORM\s+([^\n]+)', code, re.IGNORECASE)
        for match in perform_matches:
            if "UNTIL" in match.upper() or "TIMES" in match.upper():
                gaps.append({
                    "type": "loop_logic",
                    "description": f"Lógica de loop não especificada: {match}",
                    "impact": "high",
                    "missing_info": "Condições de parada e iteração"
                })

        return gaps

    def _identify_decision_logic_gaps(self, code: str, documentation: str) -> List[Dict[str, str]]:
        """Identifica lacunas na lógica de decisão."""
        gaps = []

        # Procura por roteamento de arquivos
        file_routing = re.findall(r'WRITE\s+([^\s]+)', code, re.IGNORECASE)
        if len(set(file_routing)) > 1:  # Múltiplos arquivos de saída
            gaps.append({
                "type": "file_routing",
                "description": "Critérios de roteamento entre arquivos de saída não especificados",
                "impact": "critical",
                "missing_info": "Regras exatas para decidir qual arquivo usar"
            })

        # Procura por particionamento dinâmico
        if "4000" in code or "MB" in code.upper():
            gaps.append({
                "type": "dynamic_partitioning",
                "description": "Lógica de particionamento dinâmico não detalhada",
                "impact": "critical",
                "missing_info": "Como e quando criar novos arquivos particionados"
            })

        return gaps

    def _identify_validation_gaps(self, code: str, documentation: str) -> List[Dict[str, str]]:
        """Identifica lacunas nas validações."""
        gaps = []

        # Procura por validações de campos
        validation_patterns = [
            r'IF\s+[^=]*=\s*SPACES',
            r'IF\s+[^=]*=\s*ZEROS',
            r'IF\s+[^=]*NOT\s*=',
            r'IF\s+[^<]*<\s*[0-9]',
            r'IF\s+[^>]*>\s*[0-9]'
        ]

        for pattern in validation_patterns:
            matches = re.findall(pattern, code, re.IGNORECASE)
            if matches and "Verificar status" in documentation:
                gaps.append({
                    "type": "field_validation",
                    "description": "Validações de campos não especificadas adequadamente",
                    "impact": "high",
                    "missing_info": "Critérios exatos de validação e ações em caso de falha"
                })
                break

        return gaps

    def _identify_error_handling_gaps(self, code: str, documentation: str) -> List[Dict[str, str]]:
        """Identifica lacunas no tratamento de erros."""
        gaps = []

        # Procura por tratamento de file status
        if "FILE STATUS" in code.upper():
            if "tomar ação apropriada" in documentation:
                gaps.append({
                    "type": "file_status_handling",
                    "description": "Tratamento específico de file status não documentado",
                    "impact": "high",
                    "missing_info": "Ações específicas para cada código de erro"
                })

        # Procura por parágrafos de erro
        error_paragraphs = re.findall(r'([0-9]+-[^.\n]*(?:ERRO|FIM-ANORMAL|ABEND)[^.\n]*)', code, re.IGNORECASE)
        if error_paragraphs:
            gaps.append({
                "type": "error_procedures",
                "description": "Procedimentos de erro não detalhados",
                "impact": "medium",
                "missing_info": "Ações específicas em cada procedimento de erro"
            })

        return gaps

    def _identify_data_flow_gaps(self, code: str, documentation: str) -> List[Dict[str, str]]:
        """Identifica lacunas no fluxo de dados."""
        gaps = []

        # Procura por movimentação de dados complexa
        move_matches = re.findall(r'MOVE\s+([^\n]+)', code, re.IGNORECASE)
        complex_moves = [m for m in move_matches if "(" in m or ":" in m]
        
        if complex_moves:
            gaps.append({
                "type": "data_transformation",
                "description": "Transformações de dados não documentadas",
                "impact": "medium",
                "missing_info": "Como os dados são transformados entre entrada e saída"
            })

        return gaps

    def _identify_performance_gaps(self, code: str, documentation: str) -> List[Dict[str, str]]:
        """Identifica lacunas nas considerações de performance."""
        gaps = []

        # Procura por otimizações específicas
        if "BLOCK" in code.upper() and "otimizado" in documentation:
            gaps.append({
                "type": "blocking_strategy",
                "description": "Estratégia de bloqueamento não especificada",
                "impact": "low",
                "missing_info": "Configurações específicas de bloqueamento"
            })

        return gaps

    def _identify_code_generation_gaps(self, documentation: str) -> List[Dict[str, str]]:
        """Identifica lacunas na geração de código."""
        gaps = []

        # Verifica código Java inválido
        if "private static final String 05" in documentation:
            gaps.append({
                "type": "invalid_java_syntax",
                "description": "Código Java gerado contém sintaxe inválida",
                "impact": "critical",
                "missing_info": "Código Java funcional e compilável"
            })

        # Verifica lógica genérica
        if "Processamento específico" in documentation:
            gaps.append({
                "type": "generic_logic",
                "description": "Lógica de processamento muito genérica",
                "impact": "critical",
                "missing_info": "Implementação específica de cada função"
            })

        return gaps

    def _prioritize_gaps(self, gaps: Dict[str, List[Dict]]) -> Dict[str, List[Dict]]:
        """Prioriza as lacunas por criticidade."""
        prioritized = {"critical": [], "high": [], "medium": [], "low": []}

        for gap_category, gap_list in gaps.items():
            for gap in gap_list:
                impact = gap.get("impact", "medium")
                prioritized[impact].append({
                    "category": gap_category,
                    "gap": gap
                })

        return prioritized

    def _identify_reimplementation_blockers(self, gaps: Dict[str, List[Dict]]) -> List[str]:
        """Identifica os principais bloqueadores para reimplementação."""
        blockers = []

        # Verifica lacunas críticas
        for gap_category, gap_list in gaps.items():
            critical_gaps = [g for g in gap_list if g.get("impact") == "critical"]
            if critical_gaps:
                blockers.append(f"{gap_category}: {len(critical_gaps)} lacunas críticas")

        return blockers

    def generate_llm_prompt_for_gaps(self, gap_analysis: Dict[str, Any], 
                                   original_code: str, documentation: str) -> str:
        """
        Gera um prompt específico para LLM resolver as lacunas identificadas.
        """
        program_name = gap_analysis.get("program_name", "UNKNOWN")
        critical_gaps = gap_analysis.get("prioritized_gaps", {}).get("critical", [])
        
        # Limita o código para não exceder limites do modelo
        code_sample = original_code[:6000] + "..." if len(original_code) > 6000 else original_code
        
        prompt = f"""# ANÁLISE DE LACUNAS CRÍTICAS - PROGRAMA {program_name}

Você é um especialista sênior em COBOL com 30 anos de experiência. Sua tarefa é resolver as lacunas críticas identificadas na documentação deste programa para permitir reimplementação COMPLETA e FUNCIONAL.

## CÓDIGO ORIGINAL COMPLETO:
```cobol
{code_sample}
```

## LACUNAS CRÍTICAS IDENTIFICADAS:
"""
        
        for i, critical_gap in enumerate(critical_gaps, 1):
            gap_info = critical_gap.get("gap", {})
            prompt += f"""
### LACUNA {i}: {gap_info.get('type', 'unknown').upper()}
**Descrição:** {gap_info.get('description', 'N/A')}
**Informação Faltante:** {gap_info.get('missing_info', 'N/A')}
"""

        prompt += f"""

## TAREFA ESPECÍFICA:

Analise o código COBOL e forneça as informações EXATAS que estão faltando:

```json
{{
  "business_logic_details": {{
    "evaluate_conditions": [
      {{
        "condition": "WHEN '01'",
        "action": "Rotear para arquivo S1",
        "business_rule": "Registros tipo 01 são dados de cliente"
      }}
    ],
    "decision_rules": [
      {{
        "if_condition": "IF WS-SIZE > 4000000000",
        "then_action": "Criar novo arquivo particionado",
        "else_action": "Continuar no arquivo atual",
        "business_logic": "Particionamento automático por tamanho"
      }}
    ]
  }},
  "validation_rules": [
    {{
      "field": "TIPO-REGISTRO",
      "validation": "MUST BE '01', '02', OR '03'",
      "error_action": "PERFORM 9-FIM-ANORMAL",
      "business_meaning": "Tipos válidos de registro para processamento"
    }}
  ],
  "error_handling": [
    {{
      "error_condition": "FILE STATUS = '35'",
      "specific_action": "Display 'Arquivo não encontrado' and STOP RUN",
      "recovery_possible": false
    }}
  ],
  "data_transformations": [
    {{
      "source": "LHS542E3",
      "target": "LHS542S1 or LHS542S2",
      "transformation_logic": "Copy entire record if TIPO-REGISTRO = '01' or '02', route to S2 if '03'",
      "business_rule": "Segregação por tipo de registro"
    }}
  ],
  "functional_java_code": {{
    "main_class": "public class LHAN0542 {{ ... }}",
    "key_methods": [
      "public void processFile(String inputFile)",
      "public void routeRecord(String recordType, String record)",
      "public void partitionFile(long currentSize)"
    ],
    "complete_implementation": "// Código Java FUNCIONAL e COMPILÁVEL aqui"
  }}
}}
```

## INSTRUÇÕES CRÍTICAS:

1. **SEJA ESPECÍFICO:** Baseie-se EXATAMENTE no código COBOL fornecido
2. **ANALISE CADA EVALUATE:** Documente cada WHEN e sua ação específica
3. **MAPEIE CADA IF:** Explique a condição e as ações THEN/ELSE
4. **IDENTIFIQUE VALIDAÇÕES:** Encontre todas as verificações de dados
5. **DOCUMENTE ERROS:** Especifique ações para cada tipo de erro
6. **GERE CÓDIGO FUNCIONAL:** Java que compila e executa corretamente

**OBJETIVO:** Fornecer informações SUFICIENTES para reimplementação 100% FUNCIONAL.
"""

        return prompt
