"""
Analisador Funcional Real COBOL
Identifica propósito, arquivos de entrada/saída e lógica de negócio específica
"""

import re
import logging
from typing import Dict, List, Any, Optional, Set, Tuple
from dataclasses import dataclass
from enum import Enum

class FileOperation(Enum):
    INPUT = "INPUT"
    OUTPUT = "OUTPUT"
    UPDATE = "UPDATE"
    WORK = "WORK"

@dataclass
class FileInfo:
    """Informações sobre um arquivo usado pelo programa"""
    name: str
    operation: FileOperation
    record_name: str
    organization: str  # SEQUENTIAL, INDEXED, RELATIVE
    access_mode: str   # SEQUENTIAL, RANDOM, DYNAMIC
    status_field: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'name': self.name,
            'operation': self.operation.value,
            'record_name': self.record_name,
            'organization': self.organization,
            'access_mode': self.access_mode,
            'status_field': self.status_field
        }

@dataclass
class BusinessLogic:
    """Lógica de negócio identificada no programa"""
    purpose: str
    main_process: str
    input_validation: List[str]
    business_rules: List[str]
    output_generation: List[str]
    error_handling: List[str]
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'purpose': self.purpose,
            'main_process': self.main_process,
            'input_validation': self.input_validation,
            'business_rules': self.business_rules,
            'output_generation': self.output_generation,
            'error_handling': self.error_handling
        }

@dataclass
class FunctionalAnalysis:
    """Análise funcional completa do programa COBOL"""
    program_purpose: str
    business_context: str
    files: List[FileInfo]
    business_logic: BusinessLogic
    data_flow: List[str]
    key_variables: Dict[str, str]
    processing_patterns: List[str]
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'program_purpose': self.program_purpose,
            'business_context': self.business_context,
            'files': [f.to_dict() for f in self.files],
            'business_logic': self.business_logic.to_dict(),
            'data_flow': self.data_flow,
            'key_variables': self.key_variables,
            'processing_patterns': self.processing_patterns
        }

class RealFunctionalAnalyzer:
    """Analisador funcional que extrai informações reais do código COBOL"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
        # Padrões para identificar arquivos
        self.select_pattern = re.compile(
            r'SELECT\s+([A-Z0-9\-_]+)\s+ASSIGN\s+TO\s+([A-Z0-9\-_\'\"]+)',
            re.IGNORECASE
        )
        
        self.fd_pattern = re.compile(
            r'FD\s+([A-Z0-9\-_]+)',
            re.IGNORECASE
        )
        
        # Padrões para operações de arquivo
        self.file_operations = {
            'OPEN INPUT': FileOperation.INPUT,
            'OPEN OUTPUT': FileOperation.OUTPUT,
            'OPEN I-O': FileOperation.UPDATE,
            'OPEN EXTEND': FileOperation.OUTPUT
        }
        
        # Padrões para identificar propósito
        self.purpose_indicators = {
            'split': ['SPLIT', 'DIVIDE', 'BREAK', 'SEPARATE'],
            'merge': ['MERGE', 'COMBINE', 'JOIN', 'CONSOLIDATE'],
            'sort': ['SORT', 'ORDER', 'SEQUENCE'],
            'validate': ['VALIDATE', 'CHECK', 'VERIFY', 'EDIT'],
            'convert': ['CONVERT', 'TRANSFORM', 'FORMAT'],
            'report': ['REPORT', 'PRINT', 'LIST', 'SUMMARY'],
            'update': ['UPDATE', 'MODIFY', 'CHANGE', 'MAINTAIN'],
            'extract': ['EXTRACT', 'SELECT', 'FILTER', 'SUBSET']
        }
        
        # Padrões para lógica de negócio
        self.business_patterns = [
            re.compile(r'IF\s+([A-Z0-9\-_]+)\s*=\s*([\'\"A-Z0-9\-_]+)', re.IGNORECASE),
            re.compile(r'EVALUATE\s+([A-Z0-9\-_]+)', re.IGNORECASE),
            re.compile(r'WHEN\s+([A-Z0-9\-_\'\"]+)', re.IGNORECASE),
            re.compile(r'MOVE\s+([A-Z0-9\-_\'\"]+)\s+TO\s+([A-Z0-9\-_]+)', re.IGNORECASE)
        ]
    
    def analyze_functional_aspects(self, cobol_code: str) -> FunctionalAnalysis:
        """
        Analisa aspectos funcionais do programa COBOL
        
        Args:
            cobol_code: Código COBOL completo
            
        Returns:
            FunctionalAnalysis com análise completa
        """
        self.logger.info("Iniciando análise funcional real")
        
        lines = cobol_code.split('\n')
        
        # Analisar arquivos
        files = self._analyze_files(lines)
        
        # Identificar propósito
        purpose = self._identify_purpose(lines, files)
        
        # Analisar contexto de negócio
        business_context = self._analyze_business_context(lines, purpose)
        
        # Extrair lógica de negócio
        business_logic = self._extract_business_logic(lines)
        
        # Analisar fluxo de dados
        data_flow = self._analyze_data_flow(lines, files)
        
        # Identificar variáveis-chave
        key_variables = self._identify_key_variables(lines)
        
        # Identificar padrões de processamento
        processing_patterns = self._identify_processing_patterns(lines)
        
        analysis = FunctionalAnalysis(
            program_purpose=purpose,
            business_context=business_context,
            files=files,
            business_logic=business_logic,
            data_flow=data_flow,
            key_variables=key_variables,
            processing_patterns=processing_patterns
        )
        
        self.logger.info(f"Análise funcional concluída: {len(files)} arquivos, "
                        f"{len(business_logic.business_rules)} regras de negócio")
        
        return analysis
    
    def _analyze_files(self, lines: List[str]) -> List[FileInfo]:
        """Analisa definições de arquivos no programa"""
        files = []
        file_assignments = {}
        file_descriptions = {}
        file_operations_found = {}
        
        # Primeira passada: coletar SELECT e FD
        for line in lines:
            # SELECT statements
            select_match = self.select_pattern.search(line)
            if select_match:
                logical_name = select_match.group(1)
                physical_name = select_match.group(2).strip('\'"')
                file_assignments[logical_name] = physical_name
            
            # FD statements
            fd_match = self.fd_pattern.search(line)
            if fd_match:
                file_name = fd_match.group(1)
                file_descriptions[file_name] = self._extract_file_details(line)
            
            # Operações de arquivo
            for operation, file_op in self.file_operations.items():
                if operation in line.upper():
                    # Extrair nome do arquivo da operação
                    match = re.search(f'{operation}\\s+([A-Z0-9\\-_]+)', line, re.IGNORECASE)
                    if match:
                        file_name = match.group(1)
                        file_operations_found[file_name] = file_op
        
        # Segunda passada: combinar informações
        for logical_name in file_assignments:
            physical_name = file_assignments[logical_name]
            operation = file_operations_found.get(logical_name, FileOperation.INPUT)
            
            # Encontrar registro associado
            record_name = self._find_record_for_file(lines, logical_name)
            
            file_info = FileInfo(
                name=physical_name,
                operation=operation,
                record_name=record_name,
                organization="SEQUENTIAL",  # Padrão, pode ser refinado
                access_mode="SEQUENTIAL",   # Padrão, pode ser refinado
                status_field=self._find_status_field(lines, logical_name)
            )
            
            files.append(file_info)
        
        return files
    
    def _identify_purpose(self, lines: List[str], files: List[FileInfo]) -> str:
        """Identifica o propósito principal do programa"""
        code_text = ' '.join(lines).upper()
        
        # Analisar padrões de arquivos
        input_files = [f for f in files if f.operation == FileOperation.INPUT]
        output_files = [f for f in files if f.operation == FileOperation.OUTPUT]
        
        # Heurísticas baseadas em arquivos
        if len(input_files) == 1 and len(output_files) > 1:
            return f"Programa que divide arquivo de entrada ({input_files[0].name}) em múltiplos arquivos de saída"
        elif len(input_files) > 1 and len(output_files) == 1:
            return f"Programa que consolida múltiplos arquivos de entrada em um arquivo de saída ({output_files[0].name})"
        
        # Analisar indicadores de propósito no código
        for purpose_type, indicators in self.purpose_indicators.items():
            for indicator in indicators:
                if indicator in code_text:
                    if purpose_type == 'split':
                        return "Programa que segrega dados em diferentes categorias para processamento"
                    elif purpose_type == 'merge':
                        return "Programa que consolida dados de múltiplas fontes"
                    elif purpose_type == 'validate':
                        return "Programa que valida e verifica integridade de dados"
                    elif purpose_type == 'convert':
                        return "Programa que converte formato ou estrutura de dados"
                    elif purpose_type == 'report':
                        return "Programa que gera relatórios e listagens"
                    elif purpose_type == 'update':
                        return "Programa que atualiza e mantém arquivos de dados"
                    elif purpose_type == 'extract':
                        return "Programa que extrai subconjunto de dados baseado em critérios"
        
        # Fallback baseado em análise de comentários
        purpose_from_comments = self._extract_purpose_from_comments(lines)
        if purpose_from_comments:
            return purpose_from_comments
        
        return "Programa de processamento de dados com propósito específico de negócio"
    
    def _analyze_business_context(self, lines: List[str], purpose: str) -> str:
        """Analisa o contexto de negócio do programa"""
        # Analisar comentários iniciais
        business_context = []
        
        for line in lines[:50]:  # Primeiras 50 linhas
            if line.strip().startswith('*'):
                comment = line.strip()[1:].strip()
                if any(word in comment.upper() for word in ['BUSINESS', 'PROCESS', 'FUNCTION', 'PURPOSE']):
                    business_context.append(comment)
        
        if business_context:
            return ' '.join(business_context)
        
        # Inferir contexto baseado no propósito
        if 'divide' in purpose.lower() or 'split' in purpose.lower():
            return "Processamento de dados para segregação e distribuição por categorias de negócio"
        elif 'consolida' in purpose.lower() or 'merge' in purpose.lower():
            return "Integração de dados de múltiplas fontes para visão unificada"
        elif 'valida' in purpose.lower():
            return "Controle de qualidade e integridade de dados críticos"
        
        return "Processamento de dados para suporte a operações de negócio"
    
    def _extract_business_logic(self, lines: List[str]) -> BusinessLogic:
        """Extrai lógica de negócio específica do programa"""
        input_validation = []
        business_rules = []
        output_generation = []
        error_handling = []
        main_process = ""
        
        in_procedure_division = False
        current_paragraph = ""
        
        for line in lines:
            if 'PROCEDURE DIVISION' in line.upper():
                in_procedure_division = True
                continue
            
            if not in_procedure_division:
                continue
            
            stripped = line.strip()
            if not stripped or stripped.startswith('*'):
                continue
            
            # Identificar parágrafo atual
            if stripped.endswith('.') and not any(keyword in stripped.upper() for keyword in ['MOVE', 'IF', 'PERFORM', 'ADD']):
                current_paragraph = stripped.rstrip('.').strip()
                if not main_process and current_paragraph:
                    main_process = f"Processamento principal iniciado em {current_paragraph}"
                continue
            
            # Analisar validações de entrada
            if any(keyword in stripped.upper() for keyword in ['IF', 'WHEN']) and any(field in stripped.upper() for field in ['SPACE', 'ZERO', 'NUMERIC']):
                input_validation.append(f"Validação: {stripped}")
            
            # Analisar regras de negócio
            if 'IF' in stripped.upper() and '=' in stripped:
                business_rules.append(f"Regra condicional: {stripped}")
            elif 'EVALUATE' in stripped.upper():
                business_rules.append(f"Lógica de decisão: {stripped}")
            elif 'WHEN' in stripped.upper():
                business_rules.append(f"Condição de negócio: {stripped}")
            
            # Analisar geração de saída
            if any(keyword in stripped.upper() for keyword in ['WRITE', 'DISPLAY']) and current_paragraph:
                output_generation.append(f"Geração de saída em {current_paragraph}: {stripped}")
            
            # Analisar tratamento de erro
            if any(keyword in stripped.upper() for keyword in ['ERROR', 'INVALID', 'NOT FOUND', 'FILE STATUS']):
                error_handling.append(f"Tratamento de erro: {stripped}")
        
        return BusinessLogic(
            purpose=main_process or "Processamento sequencial de dados",
            main_process=main_process,
            input_validation=input_validation,
            business_rules=business_rules,
            output_generation=output_generation,
            error_handling=error_handling
        )
    
    def _analyze_data_flow(self, lines: List[str], files: List[FileInfo]) -> List[str]:
        """Analisa o fluxo de dados no programa"""
        flow_steps = []
        
        # Identificar sequência de operações
        operations_found = []
        
        for line in lines:
            stripped = line.strip().upper()
            
            if 'OPEN INPUT' in stripped:
                file_match = re.search(r'OPEN INPUT\s+([A-Z0-9\-_]+)', stripped)
                if file_match:
                    operations_found.append(f"1. Abertura de arquivo de entrada: {file_match.group(1)}")
            
            elif 'OPEN OUTPUT' in stripped:
                file_match = re.search(r'OPEN OUTPUT\s+([A-Z0-9\-_]+)', stripped)
                if file_match:
                    operations_found.append(f"2. Abertura de arquivo de saída: {file_match.group(1)}")
            
            elif 'READ' in stripped:
                file_match = re.search(r'READ\s+([A-Z0-9\-_]+)', stripped)
                if file_match:
                    operations_found.append(f"3. Leitura de registro: {file_match.group(1)}")
            
            elif 'WRITE' in stripped:
                file_match = re.search(r'WRITE\s+([A-Z0-9\-_]+)', stripped)
                if file_match:
                    operations_found.append(f"4. Escrita de registro: {file_match.group(1)}")
            
            elif 'CLOSE' in stripped:
                file_match = re.search(r'CLOSE\s+([A-Z0-9\-_]+)', stripped)
                if file_match:
                    operations_found.append(f"5. Fechamento de arquivo: {file_match.group(1)}")
        
        # Remover duplicatas mantendo ordem
        seen = set()
        for op in operations_found:
            if op not in seen:
                flow_steps.append(op)
                seen.add(op)
        
        if not flow_steps:
            flow_steps = [
                "1. Leitura sequencial de arquivo de entrada",
                "2. Aplicação de validações e regras de negócio",
                "3. Escrita em arquivo(s) de saída conforme critérios",
                "4. Fechamento de arquivos e finalização"
            ]
        
        return flow_steps
    
    def _identify_key_variables(self, lines: List[str]) -> Dict[str, str]:
        """Identifica variáveis-chave e seus propósitos"""
        key_vars = {}
        
        # Padrões para identificar variáveis importantes
        important_patterns = [
            (r'WS-([A-Z0-9\-_]*TYPE[A-Z0-9\-_]*)', 'Campo de tipo/categoria'),
            (r'WS-([A-Z0-9\-_]*STATUS[A-Z0-9\-_]*)', 'Campo de status'),
            (r'WS-([A-Z0-9\-_]*CODE[A-Z0-9\-_]*)', 'Campo de código'),
            (r'WS-([A-Z0-9\-_]*FLAG[A-Z0-9\-_]*)', 'Flag de controle'),
            (r'WS-([A-Z0-9\-_]*COUNT[A-Z0-9\-_]*)', 'Contador'),
            (r'([A-Z0-9\-_]*)-FILE-STATUS', 'Status de arquivo'),
            (r'([A-Z0-9\-_]*)-EOF', 'Indicador fim de arquivo')
        ]
        
        for line in lines:
            for pattern, description in important_patterns:
                matches = re.findall(pattern, line.upper())
                for match in matches:
                    var_name = match if isinstance(match, str) else match[0]
                    key_vars[var_name] = description
        
        return key_vars
    
    def _identify_processing_patterns(self, lines: List[str]) -> List[str]:
        """Identifica padrões de processamento no código"""
        patterns = []
        
        code_text = ' '.join(lines).upper()
        
        # Padrões comuns
        if 'PERFORM UNTIL' in code_text:
            patterns.append("Loop de processamento com condição de parada")
        
        if 'EVALUATE' in code_text and 'WHEN' in code_text:
            patterns.append("Lógica de decisão múltipla (EVALUATE/WHEN)")
        
        if re.search(r'IF.*=.*MOVE.*TO', code_text):
            patterns.append("Roteamento condicional de dados")
        
        if 'READ' in code_text and 'WRITE' in code_text:
            patterns.append("Processamento sequencial com transformação")
        
        if re.search(r'OPEN.*INPUT.*OPEN.*OUTPUT', code_text):
            patterns.append("Processamento de arquivo entrada para saída")
        
        return patterns
    
    def _extract_file_details(self, fd_line: str) -> Dict[str, str]:
        """Extrai detalhes da definição FD"""
        details = {}
        
        if 'RECORDING MODE' in fd_line.upper():
            details['recording_mode'] = 'F'  # Fixed
        
        if 'BLOCK CONTAINS' in fd_line.upper():
            match = re.search(r'BLOCK CONTAINS\s+(\d+)', fd_line, re.IGNORECASE)
            if match:
                details['block_size'] = match.group(1)
        
        return details
    
    def _find_record_for_file(self, lines: List[str], file_name: str) -> str:
        """Encontra o registro associado a um arquivo"""
        # Procurar por definições 01 após FD
        found_fd = False
        
        for line in lines:
            if f'FD {file_name}' in line.upper():
                found_fd = True
                continue
            
            if found_fd and line.strip().startswith('01'):
                match = re.search(r'01\s+([A-Z0-9\-_]+)', line, re.IGNORECASE)
                if match:
                    return match.group(1)
            
            # Parar se encontrar outro FD
            if found_fd and line.strip().upper().startswith('FD '):
                break
        
        return f"{file_name}-RECORD"
    
    def _find_status_field(self, lines: List[str], file_name: str) -> Optional[str]:
        """Encontra campo de status associado ao arquivo"""
        for line in lines:
            if f'{file_name}' in line.upper() and 'STATUS' in line.upper():
                match = re.search(r'STATUS\s+IS\s+([A-Z0-9\-_]+)', line, re.IGNORECASE)
                if match:
                    return match.group(1)
        
        return None
    
    def _extract_purpose_from_comments(self, lines: List[str]) -> Optional[str]:
        """Extrai propósito dos comentários iniciais"""
        purpose_keywords = ['PURPOSE', 'FUNCTION', 'OBJECTIVE', 'GOAL']
        
        for line in lines[:30]:  # Primeiras 30 linhas
            if line.strip().startswith('*'):
                comment = line.strip()[1:].strip()
                for keyword in purpose_keywords:
                    if keyword in comment.upper():
                        return comment
        
        return None
