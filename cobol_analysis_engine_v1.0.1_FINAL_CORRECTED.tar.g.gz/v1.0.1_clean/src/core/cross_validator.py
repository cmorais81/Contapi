#!/usr/bin/env python3.11
# -*- coding: utf-8 -*-
"""
Sistema de Análise COBOL - Cross Validator
Sistema de validação cruzada e resolução de conflitos entre análises.
"""

import logging
import re
import json
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass
from collections import Counter
import difflib


@dataclass
class ValidationResult:
    """Resultado da validação cruzada."""
    consensus_scores: Dict[str, float]
    conflicts: List[Dict[str, Any]]
    resolved_conflicts: List[Dict[str, Any]]
    overall_confidence: float
    validation_summary: Dict[str, Any]


@dataclass
class ConflictResolution:
    """Resultado da resolução de um conflito."""
    conflict_id: str
    original_conflict: Dict[str, Any]
    resolution_method: str
    resolved_value: Any
    confidence: float
    reasoning: str


class CrossValidator:
    """Sistema de validação cruzada entre análises."""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Configurações de validação
        validation_config = config.get('cross_validation', {})
        self.consensus_threshold = validation_config.get('consensus_threshold', 0.75)
        self.conflict_threshold = validation_config.get('conflict_threshold', 0.3)
        self.min_agreement_ratio = validation_config.get('min_agreement_ratio', 0.6)
        
        # Pesos por domínio de análise
        self.domain_weights = validation_config.get('domain_weights', {
            'structural': 0.25,
            'business': 0.35,
            'technical': 0.25,
            'quality': 0.15
        })
        
        # Resolver de conflitos
        self.conflict_resolver = ConflictResolver(config)
        
        self.logger.info("Cross Validator inicializado")
    
    async def validate_analyses(self, analysis_results: Dict[str, Any]) -> ValidationResult:
        """
        Valida consistência entre análises das análises.
        
        Args:
            analysis_results: Resultados das análises das análises
            
        Returns:
            Resultado da validação cruzada
        """
        try:
            self.logger.info("Iniciando validação cruzada entre análises")
            
            # Filtrar apenas resultados bem-sucedidos
            successful_results = {
                k: v for k, v in analysis_results.items() 
                if hasattr(v, 'success') and v.success
            }
            
            if len(successful_results) < 2:
                return self._create_insufficient_data_result(successful_results)
            
            # Calcular scores de consenso
            consensus_scores = self._calculate_consensus_scores(successful_results)
            
            # Identificar conflitos
            conflicts = self._identify_conflicts(successful_results, consensus_scores)
            
            # Resolver conflitos
            resolved_conflicts = await self._resolve_conflicts(conflicts, successful_results)
            
            # Calcular confiança geral
            overall_confidence = self._calculate_overall_confidence(
                consensus_scores, resolved_conflicts, successful_results
            )
            
            # Criar resumo de validação
            validation_summary = self._create_validation_summary(
                successful_results, consensus_scores, conflicts, resolved_conflicts
            )
            
            result = ValidationResult(
                consensus_scores=consensus_scores,
                conflicts=conflicts,
                resolved_conflicts=resolved_conflicts,
                overall_confidence=overall_confidence,
                validation_summary=validation_summary
            )
            
            self.logger.info(f"Validação cruzada concluída - Confiança: {overall_confidence:.2%}")
            return result
            
        except Exception as e:
            self.logger.error(f"Erro na validação cruzada: {str(e)}")
            return self._create_error_result(str(e))
    
    def _calculate_consensus_scores(self, results: Dict[str, Any]) -> Dict[str, float]:
        """Calcula scores de consenso entre as análises."""
        
        consensus_scores = {}
        
        # Extrair elementos comparáveis de cada análise
        comparable_elements = self._extract_comparable_elements(results)
        
        # Calcular consenso para cada elemento
        for element_type, element_data in comparable_elements.items():
            if len(element_data) >= 2:  # Precisa de pelo menos 2 análises para consenso
                consensus_score = self._calculate_element_consensus(element_data)
                consensus_scores[element_type] = consensus_score
            else:
                consensus_scores[element_type] = 0.5  # Consenso neutro
        
        return consensus_scores
    
    def _extract_comparable_elements(self, results: Dict[str, Any]) -> Dict[str, List]:
        """Extrai elementos comparáveis das análises."""
        
        comparable_elements = {
            'program_structure': [],
            'business_rules': [],
            'technical_complexity': [],
            'quality_assessment': [],
            'confidence_levels': []
        }
        
        for ai_name, result in results.items():
            analysis = result.analysis if hasattr(result, 'analysis') else result
            
            # Extrair estrutura do programa
            if 'divisions_identified' in analysis:
                comparable_elements['program_structure'].append({
                    'ai': ai_name,
                    'value': analysis['divisions_identified']
                })
            
            # Extrair regras de negócio
            if 'business_rules_count' in analysis:
                comparable_elements['business_rules'].append({
                    'ai': ai_name,
                    'value': analysis['business_rules_count']
                })
            
            # Extrair complexidade técnica
            if 'algorithm_complexity' in analysis:
                comparable_elements['technical_complexity'].append({
                    'ai': ai_name,
                    'value': analysis['algorithm_complexity']
                })
            
            # Extrair avaliação de qualidade
            quality_scores = []
            for key in ['structural_quality', 'overall_quality', 'performance_score']:
                if key in analysis:
                    quality_scores.append(analysis[key])
            
            if quality_scores:
                comparable_elements['quality_assessment'].append({
                    'ai': ai_name,
                    'value': sum(quality_scores) / len(quality_scores)
                })
            
            # Extrair níveis de confiança
            if hasattr(result, 'confidence'):
                comparable_elements['confidence_levels'].append({
                    'ai': ai_name,
                    'value': result.confidence
                })
        
        return comparable_elements
    
    def _calculate_element_consensus(self, element_data: List[Dict]) -> float:
        """Calcula consenso para um elemento específico."""
        
        if len(element_data) < 2:
            return 0.5
        
        values = [item['value'] for item in element_data]
        
        # Para valores numéricos
        if all(isinstance(v, (int, float)) for v in values):
            return self._calculate_numeric_consensus(values)
        
        # Para listas (como divisões COBOL)
        elif all(isinstance(v, list) for v in values):
            return self._calculate_list_consensus(values)
        
        # Para strings
        elif all(isinstance(v, str) for v in values):
            return self._calculate_string_consensus(values)
        
        # Para valores mistos, usar comparação de string
        else:
            str_values = [str(v) for v in values]
            return self._calculate_string_consensus(str_values)
    
    def _calculate_numeric_consensus(self, values: List[float]) -> float:
        """Calcula consenso para valores numéricos."""
        
        if not values:
            return 0.0
        
        # Calcular coeficiente de variação
        mean_val = sum(values) / len(values)
        if mean_val == 0:
            return 1.0 if all(v == 0 for v in values) else 0.0
        
        variance = sum((v - mean_val) ** 2 for v in values) / len(values)
        std_dev = variance ** 0.5
        cv = std_dev / abs(mean_val)
        
        # Converter para score de consenso (0-1)
        # CV baixo = consenso alto
        consensus_score = max(0.0, 1.0 - cv)
        return min(1.0, consensus_score)
    
    def _calculate_list_consensus(self, lists: List[List]) -> float:
        """Calcula consenso para listas."""
        
        if not lists:
            return 0.0
        
        # Calcular interseção e união
        all_items = set()
        common_items = set(lists[0]) if lists else set()
        
        for lst in lists:
            lst_set = set(lst)
            all_items.update(lst_set)
            common_items.intersection_update(lst_set)
        
        if not all_items:
            return 1.0
        
        # Jaccard similarity
        jaccard = len(common_items) / len(all_items)
        return jaccard
    
    def _calculate_string_consensus(self, strings: List[str]) -> float:
        """Calcula consenso para strings."""
        
        if not strings:
            return 0.0
        
        if len(strings) == 1:
            return 1.0
        
        # Calcular similaridade média entre todas as strings
        similarities = []
        
        for i in range(len(strings)):
            for j in range(i + 1, len(strings)):
                similarity = difflib.SequenceMatcher(None, strings[i], strings[j]).ratio()
                similarities.append(similarity)
        
        return sum(similarities) / len(similarities) if similarities else 0.0
    
    def _identify_conflicts(self, results: Dict[str, Any], 
                          consensus_scores: Dict[str, float]) -> List[Dict[str, Any]]:
        """Identifica conflitos significativos."""
        
        conflicts = []
        
        for element_type, consensus_score in consensus_scores.items():
            if consensus_score < self.conflict_threshold:
                
                # Extrair valores conflitantes
                conflicting_values = self._extract_conflicting_values(
                    results, element_type
                )
                
                conflict = {
                    'id': f"conflict_{len(conflicts) + 1}",
                    'element_type': element_type,
                    'consensus_score': consensus_score,
                    'severity': self._determine_conflict_severity(consensus_score),
                    'conflicting_values': conflicting_values,
                    'affected_ais': list(conflicting_values.keys()) if conflicting_values else []
                }
                
                conflicts.append(conflict)
        
        return conflicts
    
    def _extract_conflicting_values(self, results: Dict[str, Any], 
                                  element_type: str) -> Dict[str, Any]:
        """Extrai valores conflitantes para um elemento específico."""
        
        conflicting_values = {}
        
        for ai_name, result in results.items():
            analysis = result.analysis if hasattr(result, 'analysis') else result
            
            # Mapear tipos de elementos para campos da análise
            field_mapping = {
                'program_structure': 'divisions_identified',
                'business_rules': 'business_rules_count',
                'technical_complexity': 'algorithm_complexity',
                'quality_assessment': ['structural_quality', 'overall_quality', 'performance_score'],
                'confidence_levels': 'confidence'
            }
            
            field = field_mapping.get(element_type)
            
            if field:
                if isinstance(field, list):
                    # Para múltiplos campos, calcular média
                    values = []
                    for f in field:
                        if f in analysis:
                            values.append(analysis[f])
                    if values:
                        conflicting_values[ai_name] = sum(values) / len(values)
                elif field == 'confidence':
                    if hasattr(result, 'confidence'):
                        conflicting_values[ai_name] = result.confidence
                else:
                    if field in analysis:
                        conflicting_values[ai_name] = analysis[field]
        
        return conflicting_values
    
    def _determine_conflict_severity(self, consensus_score: float) -> str:
        """Determina severidade do conflito."""
        
        if consensus_score < 0.1:
            return 'critical'
        elif consensus_score < 0.2:
            return 'high'
        elif consensus_score < 0.3:
            return 'medium'
        else:
            return 'low'
    
    async def _resolve_conflicts(self, conflicts: List[Dict[str, Any]], 
                               results: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Resolve conflitos identificados."""
        
        resolved_conflicts = []
        
        for conflict in conflicts:
            try:
                resolution = await self.conflict_resolver.resolve_conflict(conflict, results)
                resolved_conflicts.append({
                    'conflict_id': conflict['id'],
                    'original_conflict': conflict,
                    'resolution': resolution.__dict__ if resolution else None,
                    'status': 'resolved' if resolution else 'unresolved'
                })
            except Exception as e:
                self.logger.error(f"Erro ao resolver conflito {conflict['id']}: {str(e)}")
                resolved_conflicts.append({
                    'conflict_id': conflict['id'],
                    'original_conflict': conflict,
                    'resolution': None,
                    'status': 'error',
                    'error': str(e)
                })
        
        return resolved_conflicts
    
    def _calculate_overall_confidence(self, consensus_scores: Dict[str, float],
                                    resolved_conflicts: List[Dict[str, Any]],
                                    results: Dict[str, Any]) -> float:
        """Calcula confiança geral baseada no consenso e resolução de conflitos."""
        
        if not consensus_scores:
            return 0.0
        
        # Score base do consenso ponderado
        weighted_consensus = 0.0
        total_weight = 0.0
        
        for element_type, consensus_score in consensus_scores.items():
            weight = self.domain_weights.get(element_type, 0.25)
            weighted_consensus += consensus_score * weight
            total_weight += weight
        
        base_confidence = weighted_consensus / total_weight if total_weight > 0 else 0.0
        
        # Penalidade por conflitos não resolvidos
        unresolved_conflicts = sum(
            1 for rc in resolved_conflicts 
            if rc.get('status') != 'resolved'
        )
        
        conflict_penalty = unresolved_conflicts * 0.05  # 5% por conflito não resolvido
        
        # Bonus por número de análises que concordaram
        num_successful_ais = len(results)
        agreement_bonus = min(0.1, (num_successful_ais - 1) * 0.02)  # Max 10% bonus
        
        final_confidence = base_confidence - conflict_penalty + agreement_bonus
        return max(0.0, min(1.0, final_confidence))
    
    def _create_validation_summary(self, results: Dict[str, Any],
                                 consensus_scores: Dict[str, float],
                                 conflicts: List[Dict[str, Any]],
                                 resolved_conflicts: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Cria resumo da validação."""
        
        return {
            'total_ais_analyzed': len(results),
            'consensus_elements': len(consensus_scores),
            'high_consensus_elements': sum(1 for score in consensus_scores.values() if score > 0.8),
            'conflicts_identified': len(conflicts),
            'conflicts_resolved': sum(1 for rc in resolved_conflicts if rc.get('status') == 'resolved'),
            'average_consensus': sum(consensus_scores.values()) / len(consensus_scores) if consensus_scores else 0.0,
            'validation_quality': 'high' if len(conflicts) <= 2 else 'medium' if len(conflicts) <= 5 else 'low'
        }
    
    def _create_insufficient_data_result(self, results: Dict[str, Any]) -> ValidationResult:
        """Cria resultado para dados insuficientes."""
        
        return ValidationResult(
            consensus_scores={},
            conflicts=[],
            resolved_conflicts=[],
            overall_confidence=0.5 if results else 0.0,
            validation_summary={
                'total_ais_analyzed': len(results),
                'validation_status': 'insufficient_data',
                'message': 'Dados insuficientes para validação cruzada'
            }
        )
    
    def _create_error_result(self, error_message: str) -> ValidationResult:
        """Cria resultado de erro."""
        
        return ValidationResult(
            consensus_scores={},
            conflicts=[],
            resolved_conflicts=[],
            overall_confidence=0.0,
            validation_summary={
                'validation_status': 'error',
                'error_message': error_message
            }
        )


class ConflictResolver:
    """Resolvedor automático de conflitos entre análises."""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Estratégias de resolução
        self.resolution_strategies = {
            'specialist_priority': self._resolve_by_specialist_priority,
            'weighted_average': self._resolve_by_weighted_average,
            'majority_vote': self._resolve_by_majority_vote,
            'confidence_based': self._resolve_by_confidence
        }
        
        # Prioridades por domínio
        self.domain_priorities = {
            'program_structure': 'structural',
            'business_rules': 'business',
            'technical_complexity': 'technical',
            'quality_assessment': 'quality'
        }
    
    async def resolve_conflict(self, conflict: Dict[str, Any], 
                             results: Dict[str, Any]) -> Optional[ConflictResolution]:
        """Resolve um conflito específico."""
        
        try:
            element_type = conflict['element_type']
            conflicting_values = conflict['conflicting_values']
            
            # Determinar estratégia de resolução
            strategy = self._determine_resolution_strategy(conflict, results)
            
            # Aplicar estratégia
            if strategy in self.resolution_strategies:
                resolution_func = self.resolution_strategies[strategy]
                resolved_value, confidence, reasoning = await resolution_func(
                    conflict, results
                )
                
                return ConflictResolution(
                    conflict_id=conflict['id'],
                    original_conflict=conflict,
                    resolution_method=strategy,
                    resolved_value=resolved_value,
                    confidence=confidence,
                    reasoning=reasoning
                )
            else:
                self.logger.warning(f"Estratégia de resolução desconhecida: {strategy}")
                return None
                
        except Exception as e:
            self.logger.error(f"Erro ao resolver conflito: {str(e)}")
            return None
    
    def _determine_resolution_strategy(self, conflict: Dict[str, Any], 
                                     results: Dict[str, Any]) -> str:
        """Determina a melhor estratégia de resolução para o conflito."""
        
        element_type = conflict['element_type']
        severity = conflict['severity']
        
        # Para conflitos críticos, usar prioridade de especialista
        if severity == 'critical':
            return 'specialist_priority'
        
        # Para elementos que têm especialista claro, usar prioridade
        if element_type in self.domain_priorities:
            specialist_domain = self.domain_priorities[element_type]
            if specialist_domain in results:
                return 'specialist_priority'
        
        # Para valores numéricos, usar média ponderada
        conflicting_values = conflict.get('conflicting_values', {})
        if conflicting_values and all(isinstance(v, (int, float)) for v in conflicting_values.values()):
            return 'weighted_average'
        
        # Fallback para voto majoritário
        return 'majority_vote'
    
    async def _resolve_by_specialist_priority(self, conflict: Dict[str, Any], 
                                            results: Dict[str, Any]) -> Tuple[Any, float, str]:
        """Resolve conflito dando prioridade ao especialista do domínio."""
        
        element_type = conflict['element_type']
        conflicting_values = conflict['conflicting_values']
        
        # Identificar especialista
        specialist_domain = self.domain_priorities.get(element_type)
        
        if specialist_domain and specialist_domain in conflicting_values:
            resolved_value = conflicting_values[specialist_domain]
            confidence = 0.85
            reasoning = f"Resolução baseada na prioridade do especialista {specialist_domain}"
        else:
            # Fallback: usar análise com maior confiança
            best_ai = max(results.keys(), key=lambda ai: getattr(results[ai], 'confidence', 0))
            resolved_value = conflicting_values.get(best_ai, list(conflicting_values.values())[0])
            confidence = 0.65
            reasoning = f"Resolução baseada na análise com maior confiança: {best_ai}"
        
        return resolved_value, confidence, reasoning
    
    async def _resolve_by_weighted_average(self, conflict: Dict[str, Any], 
                                         results: Dict[str, Any]) -> Tuple[Any, float, str]:
        """Resolve conflito usando média ponderada por confiança."""
        
        conflicting_values = conflict['conflicting_values']
        
        # Calcular média ponderada
        weighted_sum = 0.0
        total_weight = 0.0
        
        for ai_name, value in conflicting_values.items():
            if isinstance(value, (int, float)):
                weight = getattr(results.get(ai_name), 'confidence', 0.5)
                weighted_sum += value * weight
                total_weight += weight
        
        if total_weight > 0:
            resolved_value = weighted_sum / total_weight
            confidence = min(0.9, total_weight / len(conflicting_values))
            reasoning = f"Média ponderada de {len(conflicting_values)} valores"
        else:
            resolved_value = sum(conflicting_values.values()) / len(conflicting_values)
            confidence = 0.5
            reasoning = "Média simples (pesos indisponíveis)"
        
        return resolved_value, confidence, reasoning
    
    async def _resolve_by_majority_vote(self, conflict: Dict[str, Any], 
                                      results: Dict[str, Any]) -> Tuple[Any, float, str]:
        """Resolve conflito por voto majoritário."""
        
        conflicting_values = conflict['conflicting_values']
        
        # Contar ocorrências de cada valor
        value_counts = Counter(conflicting_values.values())
        
        # Encontrar valor mais comum
        most_common_value, count = value_counts.most_common(1)[0]
        
        confidence = count / len(conflicting_values)
        reasoning = f"Voto majoritário: {count}/{len(conflicting_values)} análises concordaram"
        
        return most_common_value, confidence, reasoning
    
    async def _resolve_by_confidence(self, conflict: Dict[str, Any], 
                                   results: Dict[str, Any]) -> Tuple[Any, float, str]:
        """Resolve conflito baseado na análise com maior confiança."""
        
        conflicting_values = conflict['conflicting_values']
        
        # Encontrar análise com maior confiança
        best_ai = max(
            conflicting_values.keys(),
            key=lambda ai: getattr(results.get(ai), 'confidence', 0)
        )
        
        resolved_value = conflicting_values[best_ai]
        confidence = getattr(results.get(best_ai), 'confidence', 0.5)
        reasoning = f"Baseado na análise com maior confiança: {best_ai} ({confidence:.2%})"
        
        return resolved_value, confidence, reasoning
