#!/usr/bin/env python3.11
# -*- coding: utf-8 -*-
"""
Sistema de Análise COBOL - Clarity Engine
Engines de garantia de clareza na documentação gerada.
"""

import re
import logging
import statistics
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass
from collections import Counter
import difflib


@dataclass
class ClarityMetrics:
    """Métricas de clareza de um documento."""
    readability_score: float
    comprehension_score: float
    completeness_score: float
    consistency_score: float
    actionability_score: float
    overall_clarity_score: float
    issues: List[str]
    suggestions: List[str]


@dataclass
class AudienceProfile:
    """Perfil de uma audiência específica."""
    name: str
    knowledge_level: str  # 'basic', 'intermediate', 'advanced'
    primary_objectives: List[str]
    preferred_structure: str
    max_sentence_length: int
    technical_depth: str  # 'minimal', 'moderate', 'detailed'


class ReadabilityAnalyzer:
    """Analisador de legibilidade do texto técnico."""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
    
    def analyze(self, text: str) -> Dict[str, Any]:
        """Analisa legibilidade usando múltiplas métricas."""
        
        metrics = {
            'sentence_length': self._analyze_sentence_length(text),
            'technical_density': self._analyze_technical_density(text),
            'paragraph_structure': self._analyze_paragraph_structure(text),
            'terminology_consistency': self._analyze_terminology(text)
        }
        
        # Calcular score de legibilidade
        readability_score = self._calculate_readability_score(metrics)
        
        # Identificar problemas
        issues = self._identify_readability_issues(metrics)
        
        # Gerar sugestões
        suggestions = self._generate_readability_suggestions(issues)
        
        return {
            'score': readability_score,
            'metrics': metrics,
            'issues': issues,
            'suggestions': suggestions
        }
    
    def _analyze_sentence_length(self, text: str) -> Dict[str, Any]:
        """Analisa comprimento das sentenças."""
        sentences = re.split(r'[.!?]+', text)
        sentences = [s.strip() for s in sentences if s.strip()]
        
        if not sentences:
            return {'score': 0.0, 'average_length': 0, 'max_length': 0}
        
        lengths = [len(sentence.split()) for sentence in sentences]
        avg_length = statistics.mean(lengths)
        max_length = max(lengths)
        
        # Sentenças ideais: 15-25 palavras
        if 15 <= avg_length <= 25:
            score = 1.0
        else:
            score = max(0.0, 1.0 - abs(avg_length - 20) / 20)
        
        return {
            'score': score,
            'average_length': avg_length,
            'max_length': max_length,
            'total_sentences': len(sentences),
            'recommendation': 'Ideal' if score > 0.8 else 'Needs improvement'
        }
    
    def _analyze_technical_density(self, text: str) -> Dict[str, Any]:
        """Analisa densidade de termos técnicos."""
        
        # Termos técnicos COBOL comuns
        technical_terms = [
            'COBOL', 'DIVISION', 'SECTION', 'PARAGRAPH', 'PERFORM', 'MOVE',
            'COMPUTE', 'READ', 'WRITE', 'OPEN', 'CLOSE', 'VSAM', 'KSDS',
            'WORKING-STORAGE', 'FILE-CONTROL', 'SELECT', 'ASSIGN'
        ]
        
        words = text.upper().split()
        total_words = len(words)
        
        if total_words == 0:
            return {'score': 1.0, 'density': 0.0}
        
        technical_count = sum(1 for word in words if any(term in word for term in technical_terms))
        density = technical_count / total_words
        
        # Densidade ideal: 5-15%
        if 0.05 <= density <= 0.15:
            score = 1.0
        elif density < 0.05:
            score = 0.7  # Muito pouco técnico
        else:
            score = max(0.0, 1.0 - (density - 0.15) / 0.15)
        
        return {
            'score': score,
            'density': density,
            'technical_terms_found': technical_count,
            'total_words': total_words
        }
    
    def _analyze_paragraph_structure(self, text: str) -> Dict[str, Any]:
        """Analisa estrutura dos parágrafos."""
        
        paragraphs = [p.strip() for p in text.split('\n\n') if p.strip()]
        
        if not paragraphs:
            return {'score': 0.0, 'paragraph_count': 0}
        
        # Analisar comprimento dos parágrafos
        paragraph_lengths = [len(p.split()) for p in paragraphs]
        avg_paragraph_length = statistics.mean(paragraph_lengths)
        
        # Parágrafos ideais: 50-150 palavras
        if 50 <= avg_paragraph_length <= 150:
            length_score = 1.0
        else:
            length_score = max(0.0, 1.0 - abs(avg_paragraph_length - 100) / 100)
        
        # Verificar variação no comprimento
        if len(paragraph_lengths) > 1:
            length_variation = statistics.stdev(paragraph_lengths) / avg_paragraph_length
            variation_score = max(0.0, 1.0 - length_variation)
        else:
            variation_score = 1.0
        
        overall_score = (length_score + variation_score) / 2
        
        return {
            'score': overall_score,
            'paragraph_count': len(paragraphs),
            'average_length': avg_paragraph_length,
            'length_variation': length_variation if len(paragraph_lengths) > 1 else 0.0
        }
    
    def _analyze_terminology(self, text: str) -> Dict[str, Any]:
        """Analisa consistência da terminologia."""
        
        # Extrair termos técnicos
        technical_pattern = r'\b[A-Z][A-Z0-9-]{2,}\b'
        technical_terms = re.findall(technical_pattern, text)
        
        if not technical_terms:
            return {'score': 1.0, 'consistency': 1.0}
        
        # Contar ocorrências
        term_counts = Counter(technical_terms)
        
        # Verificar variações do mesmo termo
        consistency_issues = 0
        total_terms = len(set(technical_terms))
        
        # Procurar por variações similares
        terms_list = list(term_counts.keys())
        for i, term1 in enumerate(terms_list):
            for term2 in terms_list[i+1:]:
                similarity = difflib.SequenceMatcher(None, term1, term2).ratio()
                if 0.7 <= similarity < 1.0:  # Termos similares mas não idênticos
                    consistency_issues += 1
        
        consistency_score = max(0.0, 1.0 - (consistency_issues / max(1, total_terms)))
        
        return {
            'score': consistency_score,
            'unique_terms': total_terms,
            'consistency_issues': consistency_issues,
            'most_common_terms': term_counts.most_common(5)
        }
    
    def _calculate_readability_score(self, metrics: Dict[str, Any]) -> float:
        """Calcula score geral de legibilidade."""
        
        weights = {
            'sentence_length': 0.3,
            'technical_density': 0.25,
            'paragraph_structure': 0.25,
            'terminology_consistency': 0.2
        }
        
        weighted_score = sum(
            metrics[metric]['score'] * weight 
            for metric, weight in weights.items()
            if metric in metrics
        )
        
        return weighted_score
    
    def _identify_readability_issues(self, metrics: Dict[str, Any]) -> List[str]:
        """Identifica problemas de legibilidade."""
        
        issues = []
        
        # Problemas de comprimento de sentença
        sentence_metrics = metrics.get('sentence_length', {})
        if sentence_metrics.get('average_length', 0) > 30:
            issues.append("Sentenças muito longas (média > 30 palavras)")
        elif sentence_metrics.get('average_length', 0) < 10:
            issues.append("Sentenças muito curtas (média < 10 palavras)")
        
        # Problemas de densidade técnica
        density_metrics = metrics.get('technical_density', {})
        if density_metrics.get('density', 0) > 0.2:
            issues.append("Densidade técnica muito alta (> 20%)")
        elif density_metrics.get('density', 0) < 0.03:
            issues.append("Densidade técnica muito baixa (< 3%)")
        
        # Problemas de estrutura
        structure_metrics = metrics.get('paragraph_structure', {})
        if structure_metrics.get('average_length', 0) > 200:
            issues.append("Parágrafos muito longos (média > 200 palavras)")
        
        # Problemas de terminologia
        terminology_metrics = metrics.get('terminology_consistency', {})
        if terminology_metrics.get('consistency_issues', 0) > 3:
            issues.append("Inconsistências na terminologia técnica")
        
        return issues
    
    def _generate_readability_suggestions(self, issues: List[str]) -> List[str]:
        """Gera sugestões para melhorar legibilidade."""
        
        suggestions = []
        
        for issue in issues:
            if "muito longas" in issue:
                suggestions.append("Dividir sentenças longas em múltiplas sentenças menores")
            elif "muito curtas" in issue:
                suggestions.append("Combinar sentenças relacionadas para melhor fluxo")
            elif "densidade técnica muito alta" in issue:
                suggestions.append("Adicionar explicações para termos técnicos")
            elif "densidade técnica muito baixa" in issue:
                suggestions.append("Incluir mais detalhes técnicos específicos")
            elif "Parágrafos muito longos" in issue:
                suggestions.append("Dividir parágrafos longos em seções menores")
            elif "terminologia" in issue:
                suggestions.append("Padronizar uso de termos técnicos")
        
        return suggestions


class ComprehensionAnalyzer:
    """Analisador de facilidade de compreensão do conteúdo."""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
    
    def analyze(self, documentation: Dict[str, Any]) -> Dict[str, Any]:
        """Analisa compreensibilidade do conteúdo."""
        
        # Extrair texto principal
        main_text = self._extract_main_text(documentation)
        
        comprehension_factors = {
            'concept_progression': self._analyze_concept_progression(main_text),
            'example_quality': self._analyze_examples(main_text),
            'context_provision': self._analyze_context(main_text),
            'assumption_clarity': self._analyze_assumptions(main_text)
        }
        
        comprehension_score = self._calculate_comprehension_score(comprehension_factors)
        
        return {
            'score': comprehension_score,
            'factors': comprehension_factors,
            'suggestions': self._generate_comprehension_suggestions(comprehension_factors)
        }
    
    def _extract_main_text(self, documentation: Dict[str, Any]) -> str:
        """Extrai texto principal da documentação."""
        
        text_parts = []
        
        # Extrair de diferentes seções
        if isinstance(documentation, dict):
            for key, value in documentation.items():
                if isinstance(value, str):
                    text_parts.append(value)
                elif isinstance(value, dict):
                    text_parts.append(self._extract_main_text(value))
        elif isinstance(documentation, str):
            text_parts.append(documentation)
        
        return ' '.join(text_parts)
    
    def _analyze_concept_progression(self, text: str) -> Dict[str, Any]:
        """Analisa progressão lógica de conceitos."""
        
        # Identificar conceitos COBOL básicos vs avançados
        basic_concepts = ['DIVISION', 'SECTION', 'PARAGRAPH', 'MOVE', 'DISPLAY']
        advanced_concepts = ['VSAM', 'KSDS', 'SORT', 'MERGE', 'CALL']
        
        # Encontrar posições dos conceitos no texto
        basic_positions = []
        advanced_positions = []
        
        words = text.upper().split()
        for i, word in enumerate(words):
            if any(concept in word for concept in basic_concepts):
                basic_positions.append(i)
            elif any(concept in word for concept in advanced_concepts):
                advanced_positions.append(i)
        
        # Verificar se conceitos básicos aparecem antes dos avançados
        if basic_positions and advanced_positions:
            avg_basic_pos = statistics.mean(basic_positions)
            avg_advanced_pos = statistics.mean(advanced_positions)
            
            if avg_basic_pos < avg_advanced_pos:
                progression_score = 1.0
            else:
                progression_score = 0.6
        else:
            progression_score = 0.8  # Neutro se não há ambos os tipos
        
        return {
            'score': progression_score,
            'basic_concepts_found': len(basic_positions),
            'advanced_concepts_found': len(advanced_positions),
            'logical_progression': avg_basic_pos < avg_advanced_pos if basic_positions and advanced_positions else True
        }
    
    def _analyze_examples(self, text: str) -> Dict[str, Any]:
        """Analisa qualidade dos exemplos fornecidos."""
        
        # Procurar por indicadores de exemplos
        example_indicators = ['exemplo', 'example', 'por exemplo', 'como:', 'veja:']
        code_blocks = len(re.findall(r'```[\s\S]*?```', text, re.MULTILINE))
        
        example_count = 0
        for indicator in example_indicators:
            example_count += text.lower().count(indicator)
        
        total_examples = example_count + code_blocks
        
        # Calcular densidade de exemplos (exemplos por 1000 palavras)
        word_count = len(text.split())
        if word_count > 0:
            example_density = (total_examples / word_count) * 1000
        else:
            example_density = 0
        
        # Densidade ideal: 2-5 exemplos por 1000 palavras
        if 2 <= example_density <= 5:
            score = 1.0
        elif example_density < 2:
            score = example_density / 2
        else:
            score = max(0.5, 1.0 - (example_density - 5) / 10)
        
        return {
            'score': score,
            'total_examples': total_examples,
            'code_blocks': code_blocks,
            'example_density': example_density
        }
    
    def _analyze_context(self, text: str) -> Dict[str, Any]:
        """Analisa provisão de contexto."""
        
        # Procurar por indicadores de contexto
        context_indicators = [
            'porque', 'razão', 'objetivo', 'propósito', 'contexto',
            'background', 'histórico', 'situação', 'cenário'
        ]
        
        context_count = 0
        for indicator in context_indicators:
            context_count += text.lower().count(indicator)
        
        # Verificar explicações causais
        causal_patterns = [r'devido a', r'por causa de', r'resulta em', r'leva a']
        causal_count = sum(len(re.findall(pattern, text, re.IGNORECASE)) for pattern in causal_patterns)
        
        total_context = context_count + causal_count
        
        # Calcular score baseado na densidade de contexto
        word_count = len(text.split())
        if word_count > 0:
            context_density = (total_context / word_count) * 1000
        else:
            context_density = 0
        
        # Densidade ideal: 1-3 indicadores por 1000 palavras
        if 1 <= context_density <= 3:
            score = 1.0
        elif context_density < 1:
            score = context_density
        else:
            score = max(0.5, 1.0 - (context_density - 3) / 5)
        
        return {
            'score': score,
            'context_indicators': context_count,
            'causal_explanations': causal_count,
            'context_density': context_density
        }
    
    def _analyze_assumptions(self, text: str) -> Dict[str, Any]:
        """Analisa clareza das suposições."""
        
        # Procurar por indicadores de suposições
        assumption_indicators = [
            'assume', 'supõe', 'pressupõe', 'considera', 'dado que',
            'partindo do princípio', 'levando em conta'
        ]
        
        assumption_count = 0
        for indicator in assumption_indicators:
            assumption_count += text.lower().count(indicator)
        
        # Procurar por definições explícitas
        definition_patterns = [r'é definido como', r'significa', r'refere-se a']
        definition_count = sum(len(re.findall(pattern, text, re.IGNORECASE)) for pattern in definition_patterns)
        
        # Score baseado na proporção de definições vs suposições
        if assumption_count == 0:
            score = 1.0  # Sem suposições é bom
        else:
            definition_ratio = definition_count / assumption_count
            score = min(1.0, definition_ratio)
        
        return {
            'score': score,
            'assumptions_found': assumption_count,
            'definitions_provided': definition_count,
            'definition_ratio': definition_count / max(1, assumption_count)
        }
    
    def _calculate_comprehension_score(self, factors: Dict[str, Any]) -> float:
        """Calcula score geral de compreensão."""
        
        weights = {
            'concept_progression': 0.3,
            'example_quality': 0.3,
            'context_provision': 0.25,
            'assumption_clarity': 0.15
        }
        
        weighted_score = sum(
            factors[factor]['score'] * weight 
            for factor, weight in weights.items()
            if factor in factors
        )
        
        return weighted_score
    
    def _generate_comprehension_suggestions(self, factors: Dict[str, Any]) -> List[str]:
        """Gera sugestões para melhorar compreensão."""
        
        suggestions = []
        
        # Sugestões baseadas nos fatores
        if factors.get('concept_progression', {}).get('score', 1) < 0.7:
            suggestions.append("Reorganizar conteúdo para apresentar conceitos básicos antes dos avançados")
        
        if factors.get('example_quality', {}).get('score', 1) < 0.7:
            suggestions.append("Adicionar mais exemplos práticos e blocos de código")
        
        if factors.get('context_provision', {}).get('score', 1) < 0.7:
            suggestions.append("Fornecer mais contexto e explicações causais")
        
        if factors.get('assumption_clarity', {}).get('score', 1) < 0.7:
            suggestions.append("Definir explicitamente termos e conceitos assumidos")
        
        return suggestions


class ClarityEngine:
    """Engine principal de garantia de clareza."""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Inicializar analisadores
        self.readability_analyzer = ReadabilityAnalyzer()
        self.comprehension_analyzer = ComprehensionAnalyzer()
        
        # Configurações de clareza
        clarity_config = config.get('clarity', {})
        self.minimum_clarity_score = clarity_config.get('minimum_score', 0.8)
        self.target_audiences = clarity_config.get('target_audiences', ['technical'])
        
        # Perfis de audiência
        self.audience_profiles = self._initialize_audience_profiles()
        
        self.logger.info("Clarity Engine inicializado")
    
    def _initialize_audience_profiles(self) -> Dict[str, AudienceProfile]:
        """Inicializa perfis de audiência."""
        
        return {
            'executive': AudienceProfile(
                name='executive',
                knowledge_level='basic',
                primary_objectives=['business_impact', 'roi', 'timeline'],
                preferred_structure='summary_first',
                max_sentence_length=20,
                technical_depth='minimal'
            ),
            'technical': AudienceProfile(
                name='technical',
                knowledge_level='advanced',
                primary_objectives=['implementation', 'architecture', 'performance'],
                preferred_structure='detailed_technical',
                max_sentence_length=30,
                technical_depth='detailed'
            ),
            'business': AudienceProfile(
                name='business',
                knowledge_level='intermediate',
                primary_objectives=['business_rules', 'processes', 'compliance'],
                preferred_structure='process_focused',
                max_sentence_length=25,
                technical_depth='moderate'
            ),
            'implementation': AudienceProfile(
                name='implementation',
                knowledge_level='advanced',
                primary_objectives=['migration', 'testing', 'deployment'],
                preferred_structure='step_by_step',
                max_sentence_length=25,
                technical_depth='detailed'
            )
        }
    
    def analyze_clarity(self, documentation: Dict[str, Any], 
                       target_audience: str = 'technical') -> ClarityMetrics:
        """
        Analisa clareza da documentação para uma audiência específica.
        
        Args:
            documentation: Documentação a ser analisada
            target_audience: Audiência alvo ('executive', 'technical', 'business', 'implementation')
            
        Returns:
            Métricas de clareza
        """
        
        try:
            self.logger.info(f"Analisando clareza para audiência: {target_audience}")
            
            # Extrair texto principal
            main_text = self._extract_text_from_documentation(documentation)
            
            # Analisar legibilidade
            readability_result = self.readability_analyzer.analyze(main_text)
            
            # Analisar compreensão
            comprehension_result = self.comprehension_analyzer.analyze(documentation)
            
            # Analisar completude (simplificado)
            completeness_score = self._analyze_completeness(documentation)
            
            # Analisar consistência (simplificado)
            consistency_score = self._analyze_consistency(main_text)
            
            # Analisar acionabilidade (simplificado)
            actionability_score = self._analyze_actionability(main_text)
            
            # Calcular score geral
            overall_score = self._calculate_overall_clarity_score({
                'readability': readability_result['score'],
                'comprehension': comprehension_result['score'],
                'completeness': completeness_score,
                'consistency': consistency_score,
                'actionability': actionability_score
            })
            
            # Consolidar issues e sugestões
            all_issues = readability_result.get('issues', []) + \
                        comprehension_result.get('suggestions', [])
            
            all_suggestions = readability_result.get('suggestions', []) + \
                            comprehension_result.get('suggestions', [])
            
            return ClarityMetrics(
                readability_score=readability_result['score'],
                comprehension_score=comprehension_result['score'],
                completeness_score=completeness_score,
                consistency_score=consistency_score,
                actionability_score=actionability_score,
                overall_clarity_score=overall_score,
                issues=all_issues,
                suggestions=all_suggestions
            )
            
        except Exception as e:
            self.logger.error(f"Erro na análise de clareza: {str(e)}")
            return ClarityMetrics(
                readability_score=0.0,
                comprehension_score=0.0,
                completeness_score=0.0,
                consistency_score=0.0,
                actionability_score=0.0,
                overall_clarity_score=0.0,
                issues=[f"Erro na análise: {str(e)}"],
                suggestions=["Verificar formato da documentação"]
            )
    
    def _extract_text_from_documentation(self, documentation: Dict[str, Any]) -> str:
        """Extrai texto da documentação."""
        
        text_parts = []
        
        def extract_recursive(obj):
            if isinstance(obj, str):
                text_parts.append(obj)
            elif isinstance(obj, dict):
                for value in obj.values():
                    extract_recursive(value)
            elif isinstance(obj, list):
                for item in obj:
                    extract_recursive(item)
        
        extract_recursive(documentation)
        return ' '.join(text_parts)
    
    def _analyze_completeness(self, documentation: Dict[str, Any]) -> float:
        """Analisa completude da documentação (simplificado)."""
        
        # Seções esperadas em documentação COBOL
        expected_sections = [
            'purpose', 'structure', 'business_rules', 'technical_details',
            'recommendations', 'summary'
        ]
        
        # Verificar presença de seções (busca por palavras-chave)
        doc_text = str(documentation).lower()
        
        sections_found = 0
        for section in expected_sections:
            if section in doc_text or section.replace('_', ' ') in doc_text:
                sections_found += 1
        
        return sections_found / len(expected_sections)
    
    def _analyze_consistency(self, text: str) -> float:
        """Analisa consistência do texto (simplificado)."""
        
        # Verificar consistência na terminologia
        technical_terms = re.findall(r'\b[A-Z][A-Z0-9-]{2,}\b', text)
        
        if not technical_terms:
            return 1.0
        
        # Contar variações de termos similares
        term_counts = Counter(technical_terms)
        unique_terms = len(term_counts)
        
        # Procurar por inconsistências (termos muito similares)
        inconsistencies = 0
        terms_list = list(term_counts.keys())
        
        for i, term1 in enumerate(terms_list):
            for term2 in terms_list[i+1:]:
                similarity = difflib.SequenceMatcher(None, term1, term2).ratio()
                if 0.7 <= similarity < 1.0:
                    inconsistencies += 1
        
        consistency_score = max(0.0, 1.0 - (inconsistencies / max(1, unique_terms)))
        return consistency_score
    
    def _analyze_actionability(self, text: str) -> float:
        """Analisa acionabilidade do texto (simplificado)."""
        
        # Procurar por indicadores de ações
        action_indicators = [
            'deve', 'precisa', 'recomenda', 'implementar', 'executar',
            'configurar', 'instalar', 'testar', 'validar', 'verificar'
        ]
        
        action_count = 0
        for indicator in action_indicators:
            action_count += text.lower().count(indicator)
        
        # Procurar por próximos passos
        next_steps_patterns = [
            r'próximos? passos?', r'next steps?', r'ações? necessárias?',
            r'recomendações?', r'implementação'
        ]
        
        next_steps_count = sum(
            len(re.findall(pattern, text, re.IGNORECASE)) 
            for pattern in next_steps_patterns
        )
        
        total_actionable = action_count + next_steps_count
        
        # Calcular densidade de ações
        word_count = len(text.split())
        if word_count > 0:
            action_density = (total_actionable / word_count) * 1000
        else:
            action_density = 0
        
        # Densidade ideal: 3-8 ações por 1000 palavras
        if 3 <= action_density <= 8:
            score = 1.0
        elif action_density < 3:
            score = action_density / 3
        else:
            score = max(0.5, 1.0 - (action_density - 8) / 10)
        
        return score
    
    def _calculate_overall_clarity_score(self, scores: Dict[str, float]) -> float:
        """Calcula score geral de clareza."""
        
        weights = {
            'readability': 0.25,
            'comprehension': 0.30,
            'completeness': 0.20,
            'consistency': 0.15,
            'actionability': 0.10
        }
        
        weighted_score = sum(
            scores[metric] * weight 
            for metric, weight in weights.items()
            if metric in scores
        )
        
        return weighted_score
    
    def meets_clarity_standards(self, clarity_metrics: ClarityMetrics) -> bool:
        """Verifica se a documentação atende aos padrões de clareza."""
        
        return clarity_metrics.overall_clarity_score >= self.minimum_clarity_score
    
    def get_improvement_recommendations(self, clarity_metrics: ClarityMetrics) -> List[str]:
        """Gera recomendações de melhoria baseadas nas métricas."""
        
        recommendations = []
        
        if clarity_metrics.readability_score < 0.8:
            recommendations.append("Melhorar legibilidade: simplificar sentenças e estrutura")
        
        if clarity_metrics.comprehension_score < 0.8:
            recommendations.append("Melhorar compreensão: adicionar exemplos e contexto")
        
        if clarity_metrics.completeness_score < 0.8:
            recommendations.append("Melhorar completude: adicionar seções faltantes")
        
        if clarity_metrics.consistency_score < 0.8:
            recommendations.append("Melhorar consistência: padronizar terminologia")
        
        if clarity_metrics.actionability_score < 0.8:
            recommendations.append("Melhorar acionabilidade: adicionar próximos passos claros")
        
        return recommendations
