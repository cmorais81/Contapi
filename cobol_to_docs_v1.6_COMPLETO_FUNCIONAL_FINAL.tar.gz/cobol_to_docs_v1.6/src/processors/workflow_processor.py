"""
COBOL AI Engine v1.6 - Workflow Processor
Processador de workflows integrado que substitui scripts individuais.
Implementa padrões de design para máxima flexibilidade e extensibilidade.
"""

import logging
import os
import json
from typing import Dict, List, Any, Optional
from abc import ABC, abstractmethod
from enum import Enum

from .advanced_processor import ProcessorFactory, IAdvancedProcessor
from ..core.config import ConfigManager
from ..parsers.cobol_parser_original import COBOLParser


class WorkflowType(Enum):
    """Tipos de workflow disponíveis."""
    BASIC_ANALYSIS = "basic_analysis"
    DETAILED_ANALYSIS = "detailed_analysis"
    CONSOLIDATED_ANALYSIS = "consolidated_analysis"
    COMPARATIVE_ANALYSIS = "comparative_analysis"
    BUSINESS_RULES_EXTRACTION = "business_rules_extraction"
    TECHNICAL_CODE_ANALYSIS = "technical_code_analysis"
    PROMPT_GENERATION = "prompt_generation"
    FULL_PIPELINE = "full_pipeline"


class IWorkflowStep(ABC):
    """Interface para passos de workflow (Interface Segregation Principle)."""
    
    @abstractmethod
    def execute(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Executa o passo do workflow."""
        pass
    
    @abstractmethod
    def validate_input(self, context: Dict[str, Any]) -> bool:
        """Valida entrada do passo."""
        pass


class ProgramDiscoveryStep(IWorkflowStep):
    """Passo de descoberta de programas COBOL."""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
    
    def validate_input(self, context: Dict[str, Any]) -> bool:
        """Valida se as fontes estão especificadas."""
        return 'sources' in context and context['sources']
    
    def execute(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Descobre programas COBOL nas fontes especificadas."""
        if not self.validate_input(context):
            return {'success': False, 'error': 'Fontes não especificadas'}
        
        try:
            parser = COBOLParser()
            programs = []
            
            for source in context['sources']:
                if os.path.isfile(source):
                    program, books = parser.parse_file(source)
                    if program:
                        programs.append((source, program, books))
                elif os.path.isdir(source):
                    # Descobrir arquivos COBOL no diretório
                    for ext in ['.cbl', '.cob', '.cobol', '.txt']:
                        for file_path in Path(source).rglob(f'*{ext}'):
                            try:
                                program, books = parser.parse_file(str(file_path))
                                if program:
                                    programs.append((str(file_path), program, books))
                            except Exception as e:
                                self.logger.warning(f"Erro ao parsear {file_path}: {e}")
            
            context['programs'] = programs
            context['total_programs'] = len(programs)
            
            self.logger.info(f"Descobertos {len(programs)} programas COBOL")
            return {'success': True, 'programs_found': len(programs)}
            
        except Exception as e:
            self.logger.error(f"Erro na descoberta de programas: {e}")
            return {'success': False, 'error': str(e)}


class AnalysisStep(IWorkflowStep):
    """Passo de análise usando processadores avançados."""
    
    def __init__(self, processor_type: str):
        self.processor_type = processor_type
        self.logger = logging.getLogger(__name__)
    
    def validate_input(self, context: Dict[str, Any]) -> bool:
        """Valida se programas e configurações estão disponíveis."""
        return (
            'programs' in context and 
            'config_manager' in context and 
            'output_dir' in context
        )
    
    def execute(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Executa análise usando processador específico."""
        if not self.validate_input(context):
            return {'success': False, 'error': 'Contexto inválido para análise'}
        
        try:
            # Criar processador
            processor = ProcessorFactory.create_processor(
                self.processor_type,
                context['config_manager'],
                context['output_dir']
            )
            
            if not processor:
                return {'success': False, 'error': f'Processador {self.processor_type} não encontrado'}
            
            # Executar processamento
            options = context.get('options', {})
            results = processor.process_programs(context['programs'], options)
            
            # Atualizar contexto
            context['analysis_results'] = results
            
            return results
            
        except Exception as e:
            self.logger.error(f"Erro na análise {self.processor_type}: {e}")
            return {'success': False, 'error': str(e)}


class ReportGenerationStep(IWorkflowStep):
    """Passo de geração de relatórios."""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
    
    def validate_input(self, context: Dict[str, Any]) -> bool:
        """Valida se resultados de análise estão disponíveis."""
        return 'analysis_results' in context and 'output_dir' in context
    
    def execute(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Gera relatórios consolidados."""
        if not self.validate_input(context):
            return {'success': False, 'error': 'Resultados de análise não disponíveis'}
        
        try:
            output_dir = context['output_dir']
            results = context['analysis_results']
            
            # Relatório de resumo
            summary_report = self._generate_summary_report(results, output_dir)
            
            # Relatório detalhado
            detailed_report = self._generate_detailed_report(results, output_dir)
            
            context['reports'] = {
                'summary': summary_report,
                'detailed': detailed_report
            }
            
            return {
                'success': True,
                'reports_generated': 2,
                'summary_report': summary_report,
                'detailed_report': detailed_report
            }
            
        except Exception as e:
            self.logger.error(f"Erro na geração de relatórios: {e}")
            return {'success': False, 'error': str(e)}
    
    def _generate_summary_report(self, results: Dict[str, Any], output_dir: str) -> str:
        """Gera relatório de resumo."""
        summary_file = os.path.join(output_dir, "relatorio_resumo.json")
        
        summary_data = {
            'success': results.get('success', False),
            'total_programs': len(results.get('results', {})),
            'statistics': results.get('statistics', {}),
            'output_directory': results.get('output_directory', output_dir)
        }
        
        with open(summary_file, 'w', encoding='utf-8') as f:
            json.dump(summary_data, f, indent=2, ensure_ascii=False)
        
        return summary_file
    
    def _generate_detailed_report(self, results: Dict[str, Any], output_dir: str) -> str:
        """Gera relatório detalhado."""
        detailed_file = os.path.join(output_dir, "relatorio_detalhado.json")
        
        with open(detailed_file, 'w', encoding='utf-8') as f:
            json.dump(results, f, indent=2, ensure_ascii=False)
        
        return detailed_file


class WorkflowBuilder:
    """
    Builder para construção de workflows (Builder Pattern).
    Permite composição flexível de passos de workflow.
    """
    
    def __init__(self):
        self.steps: List[IWorkflowStep] = []
        self.logger = logging.getLogger(__name__)
    
    def add_discovery_step(self) -> 'WorkflowBuilder':
        """Adiciona passo de descoberta de programas."""
        self.steps.append(ProgramDiscoveryStep())
        return self
    
    def add_analysis_step(self, processor_type: str) -> 'WorkflowBuilder':
        """Adiciona passo de análise."""
        self.steps.append(AnalysisStep(processor_type))
        return self
    
    def add_report_step(self) -> 'WorkflowBuilder':
        """Adiciona passo de geração de relatórios."""
        self.steps.append(ReportGenerationStep())
        return self
    
    def add_custom_step(self, step: IWorkflowStep) -> 'WorkflowBuilder':
        """Adiciona passo customizado."""
        self.steps.append(step)
        return self
    
    def build(self) -> 'Workflow':
        """Constrói o workflow."""
        return Workflow(self.steps)


class Workflow:
    """
    Executor de workflow (Command Pattern).
    Executa sequência de passos com contexto compartilhado.
    """
    
    def __init__(self, steps: List[IWorkflowStep]):
        self.steps = steps
        self.logger = logging.getLogger(__name__)
    
    def execute(self, initial_context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Executa workflow completo.
        
        Args:
            initial_context: Contexto inicial
            
        Returns:
            Resultado final do workflow
        """
        context = initial_context.copy()
        results = []
        
        self.logger.info(f"Iniciando workflow com {len(self.steps)} passos")
        
        for i, step in enumerate(self.steps):
            step_name = step.__class__.__name__
            self.logger.info(f"Executando passo {i+1}/{len(self.steps)}: {step_name}")
            
            try:
                step_result = step.execute(context)
                results.append({
                    'step': step_name,
                    'result': step_result
                })
                
                if not step_result.get('success', False):
                    self.logger.error(f"Passo {step_name} falhou: {step_result.get('error', 'Erro desconhecido')}")
                    break
                
            except Exception as e:
                self.logger.error(f"Erro no passo {step_name}: {e}")
                results.append({
                    'step': step_name,
                    'result': {'success': False, 'error': str(e)}
                })
                break
        
        return {
            'success': all(r['result'].get('success', False) for r in results),
            'steps_executed': len(results),
            'step_results': results,
            'final_context': context
        }


class WorkflowProcessor:
    """
    Processador principal de workflows (Facade Pattern).
    Interface simplificada para execução de workflows predefinidos.
    """
    
    def __init__(self, config_path: str = "config/config.yaml"):
        """Inicializa o processador de workflows."""
        self.config_manager = ConfigManager(config_path)
        self.logger = logging.getLogger(__name__)
    
    def execute_workflow(self, workflow_type: WorkflowType, sources: List[str], 
                        output_dir: str, options: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Executa workflow predefinido.
        
        Args:
            workflow_type: Tipo de workflow
            sources: Fontes de programas COBOL
            output_dir: Diretório de saída
            options: Opções adicionais
            
        Returns:
            Resultado do workflow
        """
        if options is None:
            options = {}
        
        # Preparar contexto inicial
        context = {
            'sources': sources,
            'output_dir': output_dir,
            'config_manager': self.config_manager,
            'options': options
        }
        
        # Construir workflow baseado no tipo
        workflow = self._build_workflow_by_type(workflow_type)
        
        if not workflow:
            return {
                'success': False,
                'error': f'Tipo de workflow não suportado: {workflow_type}'
            }
        
        # Executar workflow
        os.makedirs(output_dir, exist_ok=True)
        return workflow.execute(context)
    
    def _build_workflow_by_type(self, workflow_type: WorkflowType) -> Optional[Workflow]:
        """Constrói workflow baseado no tipo especificado."""
        builder = WorkflowBuilder()
        
        if workflow_type == WorkflowType.BASIC_ANALYSIS:
            return (builder
                   .add_discovery_step()
                   .add_analysis_step('consolidated')
                   .add_report_step()
                   .build())
        
        elif workflow_type == WorkflowType.DETAILED_ANALYSIS:
            return (builder
                   .add_discovery_step()
                   .add_analysis_step('detailed')
                   .add_report_step()
                   .build())
        
        elif workflow_type == WorkflowType.CONSOLIDATED_ANALYSIS:
            return (builder
                   .add_discovery_step()
                   .add_analysis_step('consolidated')
                   .add_report_step()
                   .build())
        
        elif workflow_type == WorkflowType.FULL_PIPELINE:
            return (builder
                   .add_discovery_step()
                   .add_analysis_step('consolidated')
                   .add_analysis_step('detailed')
                   .add_report_step()
                   .build())
        
        else:
            self.logger.error(f"Tipo de workflow não implementado: {workflow_type}")
            return None
    
    def get_available_workflows(self) -> List[str]:
        """Retorna lista de workflows disponíveis."""
        return [wf.value for wf in WorkflowType]


# Função de conveniência para uso direto
def execute_workflow(workflow_type: str, sources: List[str], output_dir: str, 
                    config_path: str = "config/config.yaml", 
                    options: Dict[str, Any] = None) -> Dict[str, Any]:
    """
    Executa workflow de forma simplificada.
    
    Args:
        workflow_type: Tipo de workflow (string)
        sources: Fontes de programas
        output_dir: Diretório de saída
        config_path: Caminho da configuração
        options: Opções adicionais
        
    Returns:
        Resultado do workflow
    """
    try:
        wf_type = WorkflowType(workflow_type)
        processor = WorkflowProcessor(config_path)
        return processor.execute_workflow(wf_type, sources, output_dir, options)
    except ValueError:
        return {
            'success': False,
            'error': f'Tipo de workflow inválido: {workflow_type}'
        }
