#!/usr/bin/env python3
"""
Integração de Análise de Códigos Técnicos
Implementa funções para integrar análise de códigos técnicos no fluxo principal.
"""

import logging
from src.analyzers.technical_code_analyzer import enhance_documentation_with_technical_codes

logger = logging.getLogger(__name__)

def integrate_technical_code_analysis(analysis_content, cobol_code):
    """
    Integra análise de códigos técnicos no conteúdo da análise.
    
    Args:
        analysis_content: Conteúdo da análise
        cobol_code: Código COBOL original
        
    Returns:
        Conteúdo da análise com documentação de códigos técnicos
    """
    try:
        # Adicionar documentação de códigos técnicos
        enhanced_content = enhance_documentation_with_technical_codes(analysis_content)
        return enhanced_content
    except Exception as e:
        logger.error(f"Erro ao integrar análise de códigos técnicos: {e}")
        # Em caso de erro, retornar o conteúdo original sem modificações
        return analysis_content
