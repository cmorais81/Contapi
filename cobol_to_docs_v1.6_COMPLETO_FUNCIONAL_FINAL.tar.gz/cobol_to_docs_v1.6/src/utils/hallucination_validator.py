#!/usr/bin/env python3
"""
Validador Anti-Alucinação
Implementa verificações para evitar alucinações nas análises geradas.
"""

import re
import logging
from typing import Dict, List, Any, Optional, Set, Tuple

class HallucinationValidator:
    """
    Validador que verifica e corrige possíveis alucinações nas análises geradas.
    Garante que todas as informações técnicas sejam baseadas apenas no código fonte.
    """
    
    def __init__(self):
        """Inicializa o validador anti-alucinação."""
        self.logger = logging.getLogger(__name__)
        
        # Padrões para identificar possíveis alucinações
        self.hallucination_patterns = [
            # Afirmações absolutas sem evidência
            r'(?:certamente|definitivamente|absolutamente|sem dúvida)[^.]*(?:melhor|pior|único|exclusivo)',
            # Especulações sobre intenção do desenvolvedor
            r'(?:o desenvolvedor|o programador)[^.]*(?:quis|pretendeu|tentou|objetivou)',
            # Afirmações sobre comportamento não verificável no código
            r'(?:sempre|nunca)[^.]*(?:funciona|falha|executa)',
            # Referências a funcionalidades não presentes no código
            r'implementa[^.]*(?:criptografia|autenticação|autorização)',
            # Afirmações sobre performance sem evidência
            r'(?:alta performance|baixa latência|extremamente rápido|muito eficiente)',
            # Afirmações sobre segurança sem evidência
            r'(?:altamente seguro|protegido contra|previne ataques)',
            # Afirmações sobre qualidade sem evidência
            r'(?:alta qualidade|bem projetado|excelente design|arquitetura robusta)',
            # Afirmações sobre uso de padrões sem evidência
            r'(?:segue o padrão|implementa o padrão|baseado no padrão)[^.]*(?:MVC|MVP|MVVM|Factory|Singleton)'
        ]
        
        # Frases de substituição para alucinações
        self.replacement_phrases = [
            "O código fonte não contém evidências suficientes para esta afirmação.",
            "Esta conclusão não pode ser verificada apenas com o código disponível.",
            "Não há evidências no código que suportem esta afirmação.",
            "Esta funcionalidade não está explicitamente implementada no código analisado.",
            "A análise deve se limitar ao que está explicitamente no código fonte."
        ]
    
    def validate_analysis(self, analysis_content: str, cobol_code: str) -> Tuple[str, List[Dict[str, Any]]]:
        """
        Valida a análise para identificar e corrigir possíveis alucinações.
        
        Args:
            analysis_content: Conteúdo da análise a ser validado
            cobol_code: Código COBOL original para verificação
            
        Returns:
            Tupla contendo o conteúdo validado e lista de alucinações encontradas
        """
        hallucinations_found = []
        validated_content = analysis_content
        
        # Verificar cada padrão de alucinação
        for pattern in self.hallucination_patterns:
            matches = re.finditer(pattern, analysis_content, re.IGNORECASE)
            for match in matches:
                hallucination = match.group(0)
                context = self._get_context(analysis_content, match.start(), match.end())
                
                # Verificar se a afirmação tem base no código
                if not self._verify_in_code(hallucination, cobol_code):
                    # Registrar alucinação encontrada
                    hallucinations_found.append({
                        'hallucination': hallucination,
                        'context': context,
                        'pattern': pattern
                    })
                    
                    # Substituir por frase de aviso
                    import random
                    replacement = f"[NOTA: {random.choice(self.replacement_phrases)}]"
                    validated_content = validated_content.replace(hallucination, replacement)
        
        # Verificar referências a linhas de código
        validated_content = self._validate_line_references(validated_content, cobol_code, hallucinations_found)
        
        # Verificar referências a variáveis
        validated_content = self._validate_variable_references(validated_content, cobol_code, hallucinations_found)
        
        return validated_content, hallucinations_found
    
    def _get_context(self, content: str, start_pos: int, end_pos: int, context_size: int = 100) -> str:
        """
        Obtém o contexto de uma alucinação no texto.
        
        Args:
            content: Conteúdo completo
            start_pos: Posição inicial da alucinação
            end_pos: Posição final da alucinação
            context_size: Tamanho do contexto em caracteres
            
        Returns:
            Contexto da alucinação
        """
        start = max(0, start_pos - context_size // 2)
        end = min(len(content), end_pos + context_size // 2)
        
        context = content[start:end]
        if start > 0:
            context = "..." + context
        if end < len(content):
            context = context + "..."
            
        return context
    
    def _verify_in_code(self, statement: str, cobol_code: str) -> bool:
        """
        Verifica se uma afirmação tem base no código COBOL.
        
        Args:
            statement: Afirmação a ser verificada
            cobol_code: Código COBOL original
            
        Returns:
            True se a afirmação tem base no código, False caso contrário
        """
        # Extrair termos significativos da afirmação
        terms = re.findall(r'\b[A-Z0-9-]{2,}\b', statement.upper())
        
        # Verificar se pelo menos alguns termos estão presentes no código
        matches = 0
        for term in terms:
            if term in cobol_code.upper():
                matches += 1
        
        # Considerar válido se pelo menos 30% dos termos estão no código
        return matches >= max(1, len(terms) * 0.3)
    
    def _validate_line_references(self, content: str, cobol_code: str, hallucinations_found: List[Dict[str, Any]]) -> str:
        """
        Valida referências a linhas de código.
        
        Args:
            content: Conteúdo da análise
            cobol_code: Código COBOL original
            hallucinations_found: Lista de alucinações encontradas
            
        Returns:
            Conteúdo com referências a linhas validadas
        """
        # Buscar referências a linhas específicas
        line_refs = re.finditer(r'linha[s]?\s+(\d+)(?:\s*-\s*(\d+))?', content, re.IGNORECASE)
        
        # Contar linhas do código COBOL
        cobol_lines = cobol_code.count('\n') + 1
        
        for match in line_refs:
            start_line = int(match.group(1))
            end_line = int(match.group(2)) if match.group(2) else start_line
            
            # Verificar se as linhas estão dentro do intervalo válido
            if start_line > cobol_lines or end_line > cobol_lines:
                # Registrar alucinação
                hallucinations_found.append({
                    'hallucination': match.group(0),
                    'context': self._get_context(content, match.start(), match.end()),
                    'pattern': 'referência a linha inexistente'
                })
                
                # Substituir por aviso
                replacement = f"[NOTA: Referência a linha fora do intervalo válido (código tem {cobol_lines} linhas)]"
                content = content.replace(match.group(0), replacement)
        
        return content
    
    def _validate_variable_references(self, content: str, cobol_code: str, hallucinations_found: List[Dict[str, Any]]) -> str:
        """
        Valida referências a variáveis COBOL.
        
        Args:
            content: Conteúdo da análise
            cobol_code: Código COBOL original
            hallucinations_found: Lista de alucinações encontradas
            
        Returns:
            Conteúdo com referências a variáveis validadas
        """
        # Buscar referências a variáveis COBOL (formato típico: letras, números e hífens)
        var_refs = re.finditer(r'\b([A-Z][A-Z0-9-]{2,})\b', content, re.IGNORECASE)
        
        for match in var_refs:
            var_name = match.group(1).upper()
            
            # Ignorar palavras-chave COBOL comuns
            if var_name in {'IDENTIFICATION', 'DIVISION', 'PROGRAM-ID', 'ENVIRONMENT', 'DATA', 'PROCEDURE', 
                           'SECTION', 'WORKING-STORAGE', 'FILE', 'CONFIGURATION', 'INPUT-OUTPUT'}:
                continue
            
            # Verificar se a variável existe no código
            if var_name not in cobol_code.upper():
                # Verificar se é uma variável composta (pode ter partes no código)
                parts = var_name.split('-')
                found = False
                
                for part in parts:
                    if len(part) > 2 and part in cobol_code.upper():
                        found = True
                        break
                
                if not found:
                    # Registrar alucinação
                    hallucinations_found.append({
                        'hallucination': match.group(0),
                        'context': self._get_context(content, match.start(), match.end()),
                        'pattern': 'referência a variável inexistente'
                    })
                    
                    # Não substituir diretamente, apenas adicionar nota após a primeira ocorrência
                    if f"{match.group(0)} [NOTA: Variável não encontrada no código fonte]" not in content:
                        first_occurrence = content.find(match.group(0))
                        if first_occurrence >= 0:
                            content = content[:first_occurrence + len(match.group(0))] + \
                                     " [NOTA: Variável não encontrada no código fonte]" + \
                                     content[first_occurrence + len(match.group(0)):]
        
        return content


# Função auxiliar para uso direto
def validate_analysis_content(analysis_content: str, cobol_code: str) -> Tuple[str, List[Dict[str, Any]]]:
    """
    Valida o conteúdo da análise para evitar alucinações.
    
    Args:
        analysis_content: Conteúdo da análise a ser validado
        cobol_code: Código COBOL original para verificação
        
    Returns:
        Tupla contendo o conteúdo validado e lista de alucinações encontradas
    """
    validator = HallucinationValidator()
    return validator.validate_analysis(analysis_content, cobol_code)


if __name__ == "__main__":
    # Teste simples
    import sys
    
    if len(sys.argv) > 2:
        analysis_file = sys.argv[1]
        cobol_file = sys.argv[2]
        
        try:
            with open(analysis_file, 'r', encoding='utf-8') as f:
                analysis_content = f.read()
            
            with open(cobol_file, 'r', encoding='utf-8') as f:
                cobol_code = f.read()
            
            validator = HallucinationValidator()
            validated_content, hallucinations = validator.validate_analysis(analysis_content, cobol_code)
            
            output_file = analysis_file.replace('.md', '_validated.md')
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(validated_content)
            
            print(f"Conteúdo validado salvo em: {output_file}")
            print(f"Alucinações encontradas: {len(hallucinations)}")
            
            for i, h in enumerate(hallucinations, 1):
                print(f"\n{i}. Alucinação: {h['hallucination']}")
                print(f"   Contexto: {h['context']}")
            
        except Exception as e:
            print(f"Erro: {e}")
    else:
        print("Uso: python hallucination_validator.py analise.md programa.cbl")
