"""
COBOL to Docs v1.1 - Cost Calculator
Sistema de cálculo de custos para consultas de IA.
Baseado na documentação: https://confluence.santanderbr.corp/x/6sAdP
"""

import logging
from typing import Dict, Any, List


class CostCalculator:
    """
    Calculadora de custos para consultas de IA.
    Suporta múltiplos modelos com preços diferenciados.
    """
    
    def __init__(self):
        """Inicializa a calculadora de custos."""
        self.logger = logging.getLogger(__name__)
        
        # Documentação de custo https://confluence.santanderbr.corp/x/6sAdP
        self.MODEL_COSTS = {
            "azure-gpt-4o-mini": {"prompt": 0.2640, "completion": 1.0560},
            "azure-gpt-4o": {"prompt": 5.0000, "completion": 15.0000},
            "azure-o1-preview": {"prompt": 0.0165, "completion": 0.066},
            "azure-text-embedding-3-large": {"prompt": 0.00013, "completion": 0},
            "azure-text-embedding-3-small": {"prompt": 0.00002, "completion": 0},
            "dall-e-3": {"prompt": 0.0064, "completion": 0},    
            "aws-claude-3-5-sonnet": {"prompt": 3.0000, "completion": 15.0000},
            "aws-claude-3-haiku": {"prompt": 0.2500, "completion": 1.2500},
            "amazon-titan-embed-text-v2": {"prompt": 0.0008, "completion": 0},
            "amazon-titan-embed-image-v1": {"prompt": 0.00006, "completion": 0},
            "amazon-nova-micro-v1": {"prompt": 0.000035, "completion": 0.00014},
            "amazon-nova-lite-v1": {"prompt": 0.00006, "completion": 0.00024},
            "amazon-nova-pro-v1": {"prompt": 0.0008, "completion": 0.0032},
            # Modelos mock para testes
            "enhanced-mock-gpt-4": {"prompt": 0.0000, "completion": 0.0000},
            "basic-mock": {"prompt": 0.0000, "completion": 0.0000}
        }
        
        # Tracking de custos
        self.total_costs = {}
        self.total_tokens = {}
        
    def tokens_analytics(self, response: Dict[str, Any], model: str) -> Dict[str, Any]:
        """ 
        Analyzes and calculates token information and costs for API calls.
        
        Args:
            response (Dict[str, Any]): API response containing usage information
            model (str): Model name used for the request
            
        Returns:
            Dict[str, Any]: Dictionary containing:
                - prompt_tokens (int): Total number of prompt tokens used
                - completion_tokens (int): Total number of completion tokens used  
                - total_tokens (int): Total number of tokens used
                - cost (float): Calculated cost for the API call
                - model (str): Model name used
        """
        # Extrair informações de uso da resposta
        usage_info = self._extract_usage_info(response)
        
        tokens_info = {
            "prompt_tokens": usage_info["prompt_tokens"],
            "completion_tokens": usage_info["completion_tokens"],
            "total_tokens": usage_info["total_tokens"],
            "model": model
        }
        
        # Calcular custo
        tokens_info["cost"] = self.calculate_cost(tokens_info, model)
        
        # Atualizar tracking
        self._update_tracking(model, tokens_info)
        
        self.logger.info(f"Modelo: {model} | Tokens: {tokens_info['total_tokens']} | Custo: ${tokens_info['cost']:.4f}")
        
        return tokens_info

    def _extract_usage_info(self, response: Dict[str, Any]) -> Dict[str, int]:
        """
        Extrai informações de uso de tokens da resposta da API.
        
        Args:
            response: Resposta da API
            
        Returns:
            Dict com informações de tokens
        """
        # Tentar extrair do metadata (formato LuzIA)
        if isinstance(response, dict):
            metadata = response.get("metadata", {})
            if "usage" in metadata:
                usage = metadata["usage"]
                if isinstance(usage, list) and len(usage) > 0:
                    usage_item = usage[0]
                    return {
                        "prompt_tokens": usage_item.get("prompt_tokens", 0),
                        "completion_tokens": usage_item.get("completion_tokens", 0),
                        "total_tokens": usage_item.get("total_tokens", 0)
                    }
            
            # Tentar formato direto de usage
            if "usage" in response:
                usage = response["usage"]
                if isinstance(usage, list):
                    return {
                        "prompt_tokens": sum(item.get("prompt_tokens", 0) for item in usage),
                        "completion_tokens": sum(item.get("completion_tokens", 0) for item in usage),
                        "total_tokens": sum(item.get("total_tokens", 0) for item in usage)
                    }
                elif isinstance(usage, dict):
                    return {
                        "prompt_tokens": usage.get("prompt_tokens", 0),
                        "completion_tokens": usage.get("completion_tokens", 0),
                        "total_tokens": usage.get("total_tokens", 0)
                    }
        
        # Fallback para casos onde não há informação de uso
        return {
            "prompt_tokens": 0,
            "completion_tokens": 0,
            "total_tokens": 0
        }

    def calculate_cost(self, tokens: Dict[str, int], model: str) -> float:
        """
        Calculate the cost of using a specific AI model based on token usage.
        
        Args:
            tokens (Dict[str, int]): Dictionary containing token counts
            model (str): Name of the AI model used
            
        Returns:
            float: Total cost in USD
        """
        if model not in self.MODEL_COSTS:
            self.logger.warning(f"Modelo {model} não encontrado na tabela de custos. Custo = $0.00")
            return 0.0
        
        costs = self.MODEL_COSTS[model]
        prompt_cost = (tokens["prompt_tokens"] / 1000) * costs["prompt"]
        completion_cost = (tokens["completion_tokens"] / 1000) * costs["completion"]
        
        return prompt_cost + completion_cost

    def _update_tracking(self, model: str, tokens_info: Dict[str, Any]) -> None:
        """
        Atualiza o tracking de custos e tokens por modelo.
        
        Args:
            model: Nome do modelo
            tokens_info: Informações de tokens e custo
        """
        if model not in self.total_costs:
            self.total_costs[model] = 0.0
            self.total_tokens[model] = {
                "prompt_tokens": 0,
                "completion_tokens": 0,
                "total_tokens": 0,
                "requests": 0
            }
        
        self.total_costs[model] += tokens_info["cost"]
        self.total_tokens[model]["prompt_tokens"] += tokens_info["prompt_tokens"]
        self.total_tokens[model]["completion_tokens"] += tokens_info["completion_tokens"]
        self.total_tokens[model]["total_tokens"] += tokens_info["total_tokens"]
        self.total_tokens[model]["requests"] += 1

    def get_cost_summary(self) -> Dict[str, Any]:
        """
        Retorna um resumo completo dos custos.
        
        Returns:
            Dict com resumo de custos por modelo e total
        """
        total_cost = sum(self.total_costs.values())
        total_tokens_all = sum(tokens["total_tokens"] for tokens in self.total_tokens.values())
        total_requests = sum(tokens["requests"] for tokens in self.total_tokens.values())
        
        summary = {
            "total_cost": total_cost,
            "total_tokens": total_tokens_all,
            "total_requests": total_requests,
            "models": {}
        }
        
        for model in self.total_costs:
            summary["models"][model] = {
                "cost": self.total_costs[model],
                "tokens": self.total_tokens[model],
                "cost_per_token": self.total_costs[model] / max(self.total_tokens[model]["total_tokens"], 1)
            }
        
        return summary

    def format_cost_report(self) -> str:
        """
        Formata um relatório de custos legível.
        
        Returns:
            String com relatório formatado
        """
        summary = self.get_cost_summary()
        
        report = []
        report.append("=" * 60)
        report.append("RELATÓRIO DE CUSTOS - COBOL to Docs v1.1")
        report.append("=" * 60)
        report.append("")
        
        # Resumo geral
        report.append(f"CUSTO TOTAL: ${summary['total_cost']:.4f}")
        report.append(f"TOKENS TOTAIS: {summary['total_tokens']:,}")
        report.append(f"REQUISIÇÕES TOTAIS: {summary['total_requests']}")
        report.append("")
        
        # Detalhes por modelo
        report.append("DETALHES POR MODELO:")
        report.append("-" * 40)
        
        for model, data in summary["models"].items():
            report.append(f"Modelo: {model}")
            report.append(f"  Custo: ${data['cost']:.4f}")
            report.append(f"  Tokens: {data['tokens']['total_tokens']:,}")
            report.append(f"  Requisições: {data['tokens']['requests']}")
            report.append(f"  Custo/Token: ${data['cost_per_token']:.6f}")
            report.append("")
        
        return "\n".join(report)

    def reset_tracking(self) -> None:
        """Reset do tracking de custos."""
        self.total_costs.clear()
        self.total_tokens.clear()

    def calculate_total_costs(self, results: Dict[str, Any]) -> Dict[str, Any]:
        """
        Calcula custos totais de um conjunto de resultados.
        
        Args:
            results: Resultados de análises
            
        Returns:
            Informações de custo total
        """
        total_cost = 0.0
        total_tokens = 0
        cost_breakdown = {}
        
        try:
            for program_name, program_results in results.items():
                if isinstance(program_results, dict):
                    for model_name, model_results in program_results.items():
                        if isinstance(model_results, dict):
                            cost_info = model_results.get('cost', {})
                            if isinstance(cost_info, dict):
                                model_cost = cost_info.get('total_cost', 0.0)
                                model_tokens = cost_info.get('total_tokens', 0)
                                
                                total_cost += model_cost
                                total_tokens += model_tokens
                                
                                if model_name not in cost_breakdown:
                                    cost_breakdown[model_name] = {'cost': 0.0, 'tokens': 0}
                                
                                cost_breakdown[model_name]['cost'] += model_cost
                                cost_breakdown[model_name]['tokens'] += model_tokens
            
            return {
                'total_cost': total_cost,
                'total_tokens': total_tokens,
                'cost_breakdown': cost_breakdown,
                'currency': 'USD'
            }
            
        except Exception as e:
            self.logger.error(f"Erro ao calcular custos totais: {e}")
            return {
                'total_cost': 0.0,
                'total_tokens': 0,
                'cost_breakdown': {},
                'currency': 'USD',
                'error': str(e)
            }
