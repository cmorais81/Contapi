"""
COBOL AI Engine v1.6 - Advanced Report Generator
Gerador de relatórios avançados consolidados.
"""

import logging
import os
import json
from datetime import datetime
from typing import Dict, List, Any, Tuple

from ..parsers.cobol_parser_original import CobolProgram, CobolBook


class AdvancedReportGenerator:
    """Gerador de relatórios avançados e consolidados."""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
    
    def generate_consolidated_report(self, programs: List[Tuple], results: Dict[str, Any], 
                                   business_rules: Dict[str, Any], output_dir: str) -> str:
        """
        Gera relatório consolidado avançado.
        
        Args:
            programs: Lista de programas analisados
            results: Resultados das análises
            business_rules: Regras de negócio extraídas
            output_dir: Diretório de saída
            
        Returns:
            Caminho do relatório gerado
        """
        try:
            report_data = {
                'metadata': {
                    'generated_at': datetime.now().isoformat(),
                    'total_programs': len(programs),
                    'generator_version': '1.6'
                },
                'programs_summary': self._generate_programs_summary(programs),
                'analysis_results': results,
                'business_rules_summary': self._generate_business_rules_summary(business_rules),
                'statistics': self._calculate_statistics(results)
            }
            
            # Salvar relatório
            report_file = os.path.join(output_dir, "relatorio_consolidado_avancado.json")
            with open(report_file, 'w', encoding='utf-8') as f:
                json.dump(report_data, f, indent=2, ensure_ascii=False)
            
            self.logger.info(f"Relatório consolidado gerado: {report_file}")
            return report_file
            
        except Exception as e:
            self.logger.error(f"Erro na geração do relatório consolidado: {e}")
            return ""
    
    def generate_consolidated_report(self, report_data: Dict[str, Any], output_dir: str) -> str:
        """
        Gera relatório consolidado a partir de dados estruturados.
        
        Args:
            report_data: Dados do relatório
            output_dir: Diretório de saída
            
        Returns:
            Caminho do relatório gerado
        """
        try:
            report_file = os.path.join(output_dir, "relatorio_final_consolidado.json")
            
            with open(report_file, 'w', encoding='utf-8') as f:
                json.dump(report_data, f, indent=2, ensure_ascii=False)
            
            self.logger.info(f"Relatório final gerado: {report_file}")
            return report_file
            
        except Exception as e:
            self.logger.error(f"Erro na geração do relatório final: {e}")
            return ""
    
    def _generate_programs_summary(self, programs: List[Tuple]) -> List[Dict[str, Any]]:
        """Gera resumo dos programas analisados."""
        summary = []
        
        for file_path, program, books in programs:
            summary.append({
                'name': program.name,
                'file_path': file_path,
                'size_bytes': len(program.content),
                'lines_count': len(program.content.split('\n')),
                'copybooks_count': len(books),
                'copybooks': [book.name for book in books] if books else []
            })
        
        return summary
    
    def _generate_business_rules_summary(self, business_rules: Dict[str, Any]) -> Dict[str, Any]:
        """Gera resumo das regras de negócio."""
        total_rules = 0
        rules_by_type = {}
        
        for program_name, rules in business_rules.items():
            if isinstance(rules, list):
                total_rules += len(rules)
                for rule in rules:
                    rule_type = rule.get('type', 'unknown')
                    if rule_type not in rules_by_type:
                        rules_by_type[rule_type] = 0
                    rules_by_type[rule_type] += 1
        
        return {
            'total_rules': total_rules,
            'rules_by_type': rules_by_type,
            'programs_with_rules': len([p for p, r in business_rules.items() if r])
        }
    
    def _calculate_statistics(self, results: Dict[str, Any]) -> Dict[str, Any]:
        """Calcula estatísticas dos resultados."""
        total_analyses = 0
        successful_analyses = 0
        total_tokens = 0
        
        for program_results in results.values():
            if isinstance(program_results, dict):
                for model_results in program_results.values():
                    if isinstance(model_results, dict):
                        for analysis in model_results.values():
                            if isinstance(analysis, dict):
                                total_analyses += 1
                                if analysis.get('success', False):
                                    successful_analyses += 1
                                    total_tokens += analysis.get('tokens_used', 0)
        
        return {
            'total_analyses': total_analyses,
            'successful_analyses': successful_analyses,
            'success_rate': (successful_analyses / total_analyses * 100) if total_analyses > 0 else 0,
            'total_tokens': total_tokens,
            'average_tokens': (total_tokens / successful_analyses) if successful_analyses > 0 else 0
        }
