#!/usr/bin/env python3
"""
Ferramenta de Conversão de COBOL para JSON
Converte programas COBOL em representação JSON estruturada.
"""

import os
import sys
import json
import argparse
import logging
from typing import Dict, List, Any, Optional

# Adicionar diretório pai ao path para importar módulos do projeto
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.parsers.cobol_parser import COBOLParser

def convert_cobol_to_json(cobol_file: str, output_file: Optional[str] = None) -> Dict[str, Any]:
    """
    Converte um programa COBOL em representação JSON estruturada.
    
    Args:
        cobol_file: Caminho para o arquivo COBOL
        output_file: Caminho para o arquivo JSON de saída (opcional)
        
    Returns:
        Representação JSON do programa COBOL
    """
    try:
        # Ler código COBOL
        with open(cobol_file, 'r', encoding='utf-8') as f:
            cobol_code = f.read()
        
        # Analisar código COBOL
        parser = COBOLParser()
        parsed_code = parser.parse(cobol_code)
        
        # Converter para JSON
        json_representation = {
            'program_name': os.path.basename(cobol_file).split('.')[0],
            'file_path': cobol_file,
            'parsed_structure': parsed_code
        }
        
        # Salvar em arquivo se especificado
        if output_file:
            with open(output_file, 'w', encoding='utf-8') as f:
                json.dump(json_representation, f, indent=2)
            print(f"Representação JSON salva em: {output_file}")
        
        return json_representation
        
    except Exception as e:
        print(f"Erro ao converter COBOL para JSON: {e}")
        return {}


if __name__ == "__main__":
    # Configuração de logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Argumentos de linha de comando
    parser = argparse.ArgumentParser(description='Converter programa COBOL em JSON')
    parser.add_argument('--input', required=True, help='Arquivo COBOL de entrada')
    parser.add_argument('--output', default=None, help='Arquivo JSON de saída')
    
    args = parser.parse_args()
    
    # Determinar arquivo de saída se não especificado
    output_file = args.output
    if not output_file:
        input_base = os.path.basename(args.input).split('.')[0]
        output_file = f"{input_base}_structure.json"
    
    # Converter COBOL para JSON
    result = convert_cobol_to_json(args.input, output_file)
    
    if result:
        print(f"Conversão concluída com sucesso!")
    else:
        print(f"Erro na conversão. Verifique os logs para mais detalhes.")
        sys.exit(1)
