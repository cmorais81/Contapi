"""
COBOL to Docs v1.6 - Interface de Biblioteca Python
Interface principal para uso como biblioteca Python.
"""

__version__ = "1.6.0"
__author__ = "Carlos Morais"
__description__ = "Sistema completo para análise automatizada de programas COBOL usando IA"

import logging
import os
import sys
from typing import Dict, List, Any, Optional, Union
from pathlib import Path

# Adicionar src ao path para importações
current_dir = Path(__file__).parent.parent
src_dir = current_dir / "src"
sys.path.insert(0, str(src_dir))

# Importações principais
from src.core.config import ConfigManager
from src.core.enhanced_model_selector import EnhancedModelSelector
from src.providers.provider_manager import ProviderManager
from src.rag.rag_integration import RAGIntegration
from src.generators.documentation_generator import DocumentationGenerator
from src.utils.intelligent_cache import cache_manager
from src.utils.parallel_processor import parallel_processor
from src.utils.dependency_manager import dependency_manager

logger = logging.getLogger(__name__)

class COBOLAnalyzer:
    """
    Classe principal para análise de programas COBOL.
    
    Interface simplificada para uso como biblioteca Python.
    """
    
    def __init__(self, config_path: Optional[str] = None, **kwargs):
        """
        Inicializa o analisador COBOL.
        
        Args:
            config_path: Caminho para arquivo de configuração (opcional)
            **kwargs: Configurações adicionais
        """
        # Configurar logging se não estiver configurado
        if not logging.getLogger().handlers:
            logging.basicConfig(
                level=logging.INFO,
                format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
        
        # Carregar configuração
        if config_path:
            self.config_manager = ConfigManager(config_path)
        else:
            # Usar configuração padrão
            default_config_path = current_dir / "config" / "config.yaml"
            self.config_manager = ConfigManager(str(default_config_path))
        
        self.config = self.config_manager.config
        
        # Aplicar configurações adicionais
        if kwargs:
            self._apply_kwargs(kwargs)
        
        # Inicializar componentes
        self.provider_manager = None
        self.model_selector = None
        self.rag_integration = None
        self.doc_generator = None
        
        self._initialize_components()
        
        logger.info(f"COBOL Analyzer v{__version__} inicializado")
    
    def _apply_kwargs(self, kwargs: Dict[str, Any]):
        """
        Aplica configurações adicionais do kwargs.
        
        Args:
            kwargs: Configurações adicionais
        """
        # Configurações de IA
        if 'models' in kwargs:
            if 'ai' not in self.config:
                self.config['ai'] = {}
            self.config['ai']['models'] = kwargs['models']
        
        if 'primary_provider' in kwargs:
            if 'ai' not in self.config:
                self.config['ai'] = {}
            self.config['ai']['primary_provider'] = kwargs['primary_provider']
        
        # Configurações de RAG
        if 'rag_enabled' in kwargs:
            if 'rag' not in self.config:
                self.config['rag'] = {}
            self.config['rag']['enabled'] = kwargs['rag_enabled']
        
        # Configurações de cache
        if 'cache_enabled' in kwargs:
            if 'performance' not in self.config:
                self.config['performance'] = {}
            self.config['performance']['cache_enabled'] = kwargs['cache_enabled']
        
        # Configurações de paralelização
        if 'parallel_processing' in kwargs:
            if 'performance' not in self.config:
                self.config['performance'] = {}
            self.config['performance']['parallel_analysis'] = kwargs['parallel_processing']
    
    def _initialize_components(self):
        """Inicializa componentes do sistema."""
        try:
            # Provider Manager
            self.provider_manager = ProviderManager(self.config)            
            # Model Selector
            self.model_selector = EnhancedModelSelector(self.config)
            
            # RAG Integration
            if self.config.get('rag', {}).get('enabled', True):
                self.rag_integration = RAGIntegration(self.config)
            
            # Documentation Generator
            self.doc_generator = DocumentationGenerator(self.config)
            
            logger.info("Componentes inicializados com sucesso")
            
        except Exception as e:
            logger.error(f"Erro ao inicializar componentes: {e}")
            raise
    
    def analyze_file(self, file_path: str, **kwargs) -> Dict[str, Any]:
        """
        Analisa um arquivo COBOL.
        
        Args:
            file_path: Caminho para o arquivo COBOL
            **kwargs: Opções de análise
            
        Returns:
            Resultado da análise
        """
        try:
            # Ler arquivo
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                cobol_code = f.read()
            
            return self.analyze_code(cobol_code, program_name=Path(file_path).stem, **kwargs)
            
        except Exception as e:
            logger.error(f"Erro ao analisar arquivo {file_path}: {e}")
            raise
    
    def analyze_code(self, cobol_code: str, program_name: str = "PROGRAMA", **kwargs) -> Dict[str, Any]:
        """
        Analisa código COBOL.
        
        Args:
            cobol_code: Código COBOL para análise
            program_name: Nome do programa
            **kwargs: Opções de análise
            
        Returns:
            Resultado da análise
        """
        try:
            # Seleção de modelo
            model_name = kwargs.get('model')
            if not model_name:
                available_models = self.provider_manager.get_available_providers()
                if available_models:
                    recommendation = self.model_selector.recommend_model(cobol_code, available_models)
                    model_name = recommendation.get('recommended_model')
                else:
                    raise RuntimeError("Nenhum modelo disponível")
            
            # Preparar contexto RAG
            rag_context = ""
            if self.rag_integration:
                rag_results = self.rag_integration.search_knowledge_base(cobol_code)
                rag_context = rag_results.get('context', '')
            
            # Executar análise
            import sys
            import os
            sys.path.append(os.path.dirname(os.path.dirname(__file__)))
            from src.models import AIRequest
            
            request = AIRequest(
                prompt=f"Analise o programa COBOL {program_name}:\n\n{cobol_code}\n\n{rag_context}",
                program_name=program_name,
                cobol_code=cobol_code
            )
            
            result = self.provider_manager.analyze_with_model(model_name, request)
            
            # Adicionar conhecimento ao RAG se habilitado
            if self.rag_integration and kwargs.get('auto_learn', True):
                self.rag_integration.add_analysis_to_knowledge_base(
                    program_name, cobol_code, result.get('content', '')
                )
            
            return result
            
        except Exception as e:
            logger.error(f"Erro ao analisar código: {e}")
            raise
    
    def analyze_multiple_files(self, file_paths: List[str], **kwargs) -> Dict[str, Any]:
        """
        Analisa múltiplos arquivos COBOL.
        
        Args:
            file_paths: Lista de caminhos para arquivos COBOL
            **kwargs: Opções de análise
            
        Returns:
            Resultados das análises
        """
        try:
            # Verificar se deve usar processamento paralelo
            use_parallel = kwargs.get('parallel', self.config.get('performance', {}).get('parallel_analysis', False))
            
            if use_parallel and len(file_paths) > 1:
                return self._analyze_parallel(file_paths, **kwargs)
            else:
                return self._analyze_sequential(file_paths, **kwargs)
                
        except Exception as e:
            logger.error(f"Erro ao analisar múltiplos arquivos: {e}")
            raise
    
    def _analyze_sequential(self, file_paths: List[str], **kwargs) -> Dict[str, Any]:
        """
        Análise sequencial de arquivos.
        
        Args:
            file_paths: Lista de arquivos
            **kwargs: Opções de análise
            
        Returns:
            Resultados das análises
        """
        results = {}
        errors = {}
        
        for file_path in file_paths:
            try:
                result = self.analyze_file(file_path, **kwargs)
                results[file_path] = result
                logger.info(f"Arquivo analisado: {Path(file_path).name}")
                
            except Exception as e:
                errors[file_path] = str(e)
                logger.error(f"Erro ao analisar {file_path}: {e}")
        
        return {
            'results': results,
            'errors': errors,
            'statistics': {
                'total_files': len(file_paths),
                'successful': len(results),
                'failed': len(errors),
                'success_rate': len(results) / len(file_paths) * 100 if file_paths else 0
            }
        }
    
    def _analyze_parallel(self, file_paths: List[str], **kwargs) -> Dict[str, Any]:
        """
        Análise paralela de arquivos.
        
        Args:
            file_paths: Lista de arquivos
            **kwargs: Opções de análise
            
        Returns:
            Resultados das análises
        """
        def analyze_single_file(file_path: str) -> Dict[str, Any]:
            return self.analyze_file(file_path, **kwargs)
        
        return parallel_processor.process_files_parallel(
            file_paths, analyze_single_file, **kwargs
        )
    
    def generate_documentation(self, analysis_result: Dict[str, Any], output_path: str, **kwargs) -> str:
        """
        Gera documentação a partir do resultado da análise.
        
        Args:
            analysis_result: Resultado da análise
            output_path: Caminho para salvar documentação
            **kwargs: Opções de geração
            
        Returns:
            Caminho do arquivo gerado
        """
        try:
            return self.doc_generator.generate_documentation(
                analysis_result, output_path, **kwargs
            )
            
        except Exception as e:
            logger.error(f"Erro ao gerar documentação: {e}")
            raise
    
    def get_available_models(self) -> List[str]:
        """
        Obtém lista de modelos disponíveis.
        
        Returns:
            Lista de modelos disponíveis
        """
        if self.provider_manager:
            return self.provider_manager.get_available_providers()
        return []
    
    def get_provider_status(self) -> Dict[str, Any]:
        """
        Obtém status dos provedores.
        
        Returns:
            Status dos provedores
        """
        if self.provider_manager:
            # Retornar status de todos os providers disponíveis
            status = {}
            for provider_name in self.provider_manager.get_available_providers():
                try:
                    status[provider_name] = self.provider_manager.get_provider_status(provider_name)
                except Exception as e:
                    status[provider_name] = {'error': str(e)}
            return status
        return {}
    
    def get_performance_metrics(self) -> Dict[str, Any]:
        """
        Obtém métricas de performance.
        
        Returns:
            Métricas de performance
        """
        metrics = {}
        
        if self.model_selector:
            metrics['model_selector'] = self.model_selector.get_performance_metrics()
        
        if self.provider_manager:
            metrics['providers'] = self.provider_manager.get_performance_metrics()
        
        # Métricas de cache
        metrics['cache'] = cache_manager.get_cache_stats()
        
        return metrics
    
    def cleanup_cache(self) -> int:
        """
        Limpa cache expirado.
        
        Returns:
            Número de arquivos removidos
        """
        return cache_manager.cleanup_expired()
    
    def install_optional_dependencies(self, packages: List[str] = None) -> Dict[str, Any]:
        """
        Instala dependências opcionais.
        
        Args:
            packages: Lista de pacotes (None = todos)
            
        Returns:
            Resultado da instalação
        """
        if packages is None:
            packages = list(dependency_manager.optional_dependencies.keys())
        
        return dependency_manager.install_dependencies(packages)
    
    def get_dependency_status(self) -> Dict[str, Any]:
        """
        Obtém status das dependências.
        
        Returns:
            Status das dependências
        """
        return dependency_manager.get_installation_status()

# Funções de conveniência para uso direto
def analyze_cobol_file(file_path: str, **kwargs) -> Dict[str, Any]:
    """
    Função de conveniência para analisar um arquivo COBOL.
    
    Args:
        file_path: Caminho para o arquivo COBOL
        **kwargs: Opções de análise
        
    Returns:
        Resultado da análise
    """
    analyzer = COBOLAnalyzer(**kwargs)
    return analyzer.analyze_file(file_path, **kwargs)

def analyze_cobol_code(cobol_code: str, **kwargs) -> Dict[str, Any]:
    """
    Função de conveniência para analisar código COBOL.
    
    Args:
        cobol_code: Código COBOL
        **kwargs: Opções de análise
        
    Returns:
        Resultado da análise
    """
    analyzer = COBOLAnalyzer(**kwargs)
    return analyzer.analyze_code(cobol_code, **kwargs)

def get_available_models(**kwargs) -> List[str]:
    """
    Função de conveniência para obter modelos disponíveis.
    
    Args:
        **kwargs: Opções de configuração
        
    Returns:
        Lista de modelos disponíveis
    """
    analyzer = COBOLAnalyzer(**kwargs)
    return analyzer.get_available_models()

def check_system_status(**kwargs) -> Dict[str, Any]:
    """
    Função de conveniência para verificar status do sistema.
    
    Args:
        **kwargs: Opções de configuração
        
    Returns:
        Status do sistema
    """
    analyzer = COBOLAnalyzer(**kwargs)
    return {
        'providers': analyzer.get_provider_status(),
        'dependencies': analyzer.get_dependency_status(),
        'performance': analyzer.get_performance_metrics()
    }

# Exportar classes e funções principais
__all__ = [
    'COBOLAnalyzer',
    'analyze_cobol_file',
    'analyze_cobol_code',
    'get_available_models',
    'check_system_status',
    '__version__',
    '__author__',
    '__description__'
]
