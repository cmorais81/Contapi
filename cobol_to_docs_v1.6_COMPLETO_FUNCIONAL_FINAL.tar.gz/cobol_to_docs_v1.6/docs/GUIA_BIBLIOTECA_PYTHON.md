# Guia da Biblioteca Python - COBOL to Docs v1.6

Documentação completa para uso do COBOL to Docs v1.6 como biblioteca Python em seus projetos.

## Visão Geral

A biblioteca Python do COBOL to Docs v1.6 oferece uma interface programática completa para:
- Integração em aplicações Python existentes
- Análise automatizada de código COBOL
- Processamento em lote de arquivos
- Acesso a todas as funcionalidades avançadas (RAG, cache, processamento paralelo)
- Gerenciamento de dependências e provedores

## Instalação

### Instalação Básica
```bash
pip install -e ./cobol_to_docs_v1.6/
```

### Instalação com Dependências Completas
```bash
cd cobol_to_docs_v1.6
pip install -r requirements-full.txt
pip install -e .
```

### Verificação da Instalação
```python
import cobol_to_docs
print(f"Versão: {cobol_to_docs.__version__}")
print(f"Autor: {cobol_to_docs.__author__}")
```

## Importações Principais

```python
# Classe principal
from cobol_to_docs import COBOLAnalyzer

# Funções de conveniência
from cobol_to_docs import (
    analyze_cobol_file,
    analyze_cobol_code,
    get_available_models,
    check_system_status
)

# Informações da biblioteca
from cobol_to_docs import __version__, __author__, __description__
```

## Classe Principal: COBOLAnalyzer

### Inicialização

```python
from cobol_to_docs import COBOLAnalyzer

# Inicialização básica
analyzer = COBOLAnalyzer()

# Inicialização com configuração personalizada
analyzer = COBOLAnalyzer(
    config_path="config/custom_config.yaml",
    cache_enabled=True,
    parallel_processing=True,
    rag_enabled=True
)

# Inicialização com parâmetros específicos
analyzer = COBOLAnalyzer(
    models=['aws_claude_3_5_sonnet', 'gpt_4_turbo'],
    primary_provider='openai',
    rag_enabled=True,
    cache_enabled=True
)
```

### Parâmetros de Inicialização

- `config_path`: Caminho para arquivo de configuração YAML
- `cache_enabled`: Habilitar cache inteligente (padrão: True)
- `parallel_processing`: Habilitar processamento paralelo (padrão: False)
- `rag_enabled`: Habilitar sistema RAG (padrão: True)
- `models`: Lista de modelos específicos
- `primary_provider`: Provider principal a usar

## Análise de Código COBOL

### 1. Análise de Arquivo

```python
# Análise básica
result = analyzer.analyze_file('programa.cbl')
print(result['content'])

# Análise com opções
result = analyzer.analyze_file(
    'programa_complexo.cbl',
    model='aws_claude_3_5_sonnet',
    auto_learn=True,
    generate_technical_codes=True
)

print(f"Modelo usado: {result['model']}")
print(f"Tokens: {result['tokens_used']}")
print(f"Custo: ${result['cost']}")
print(f"Tempo: {result['response_time']}s")
```

### 2. Análise de Código Direto

```python
cobol_code = """
IDENTIFICATION DIVISION.
PROGRAM-ID. CALCULO-JUROS.
DATA DIVISION.
WORKING-STORAGE SECTION.
01 WS-PRINCIPAL    PIC 9(7)V99.
01 WS-TAXA         PIC 9V9999.
01 WS-TEMPO        PIC 99.
01 WS-JUROS        PIC 9(7)V99.

PROCEDURE DIVISION.
MAIN-LOGIC.
    MOVE 10000.00 TO WS-PRINCIPAL
    MOVE 0.0525 TO WS-TAXA
    MOVE 12 TO WS-TEMPO
    
    COMPUTE WS-JUROS = WS-PRINCIPAL * WS-TAXA * WS-TEMPO / 12
    
    DISPLAY 'PRINCIPAL: ' WS-PRINCIPAL
    DISPLAY 'TAXA: ' WS-TAXA
    DISPLAY 'JUROS: ' WS-JUROS
    
    STOP RUN.
"""

result = analyzer.analyze_code(
    cobol_code=cobol_code,
    program_name='CALCULO-JUROS',
    model='aws_claude_3_5_sonnet'
)

print(result['content'])
```

### 3. Análise em Lote

```python
# Lista de arquivos
files = [
    'programa1.cbl',
    'programa2.cbl',
    'programa3.cbl',
    'programa4.cbl'
]

# Análise sequencial
results = analyzer.analyze_multiple_files(files)

# Análise paralela
results = analyzer.analyze_multiple_files(
    files,
    parallel=True,
    max_workers=4
)

# Processar resultados
for file_path, result in results['results'].items():
    print(f"\n=== {file_path} ===")
    print(f"Modelo: {result['model']}")
    print(f"Tokens: {result['tokens_used']}")
    print(f"Status: Sucesso")

# Verificar erros
for file_path, error in results['errors'].items():
    print(f"\n=== ERRO: {file_path} ===")
    print(f"Erro: {error}")

# Estatísticas
stats = results['statistics']
print(f"\nEstatísticas:")
print(f"Total: {stats['total_files']}")
print(f"Sucesso: {stats['successful']}")
print(f"Falhas: {stats['failed']}")
print(f"Taxa de sucesso: {stats['success_rate']:.1f}%")
```

## Funcionalidades Avançadas

### 1. Gerenciamento de Modelos

```python
# Listar modelos disponíveis
models = analyzer.get_available_models()
print("Modelos disponíveis:", models)

# Status dos provedores
status = analyzer.get_provider_status()
for provider, info in status.items():
    print(f"{provider}: {'✓' if info['available'] else '✗'}")
    if info['available']:
        print(f"  Modelos: {info.get('models', [])}")
```

### 2. Sistema RAG

```python
# O RAG é usado automaticamente, mas você pode acessar diretamente
if analyzer.rag_integration:
    # Buscar conhecimento relevante
    rag_results = analyzer.rag_integration.get_relevant_knowledge(cobol_code)
    print(f"Conhecimento encontrado: {len(rag_results['items'])} itens")
    
    # Adicionar conhecimento personalizado
    analyzer.rag_integration.add_knowledge_item({
        'id': 'custom_001',
        'title': 'Padrão Específico da Empresa',
        'content': 'Descrição do padrão...',
        'category': 'patterns',
        'tags': ['empresa', 'padrao']
    })
```

### 3. Cache Inteligente

```python
# Verificar estatísticas do cache
cache_stats = analyzer.get_performance_metrics()['cache']
print(f"Taxa de acerto: {cache_stats['hit_rate']}%")
print(f"Tamanho: {cache_stats['cache_size_mb']} MB")

# Limpar cache expirado
removed = analyzer.cleanup_cache()
print(f"Arquivos removidos: {removed}")
```

### 4. Dependências Opcionais

```python
# Verificar status das dependências
deps_status = analyzer.get_dependency_status()
print(f"Instaladas: {deps_status['installed_count']}/{deps_status['total_dependencies']}")

# Instalar dependências específicas
result = analyzer.install_optional_dependencies(['openai', 'boto3'])
print(result['summary'])

# Instalar todas as dependências
result = analyzer.install_optional_dependencies()
if result['success']:
    print("Todas as dependências instaladas!")
```

### 5. Métricas de Performance

```python
# Obter métricas detalhadas
metrics = analyzer.get_performance_metrics()

# Métricas do seletor de modelo
model_metrics = metrics['model_selector']
print(f"Cache hit rate: {model_metrics['cache_hit_rate']}%")
print(f"Tempo médio de análise: {model_metrics['avg_analysis_time']}s")

# Métricas dos provedores
for provider, provider_metrics in metrics['providers'].items():
    print(f"\n{provider}:")
    print(f"  Requisições: {provider_metrics['requests_made']}")
    print(f"  Tempo médio: {provider_metrics['avg_response_time']}s")
    print(f"  Custo total: ${provider_metrics['total_cost']}")
```

## Funções de Conveniência

### 1. Análise Rápida

```python
from cobol_to_docs import analyze_cobol_file, analyze_cobol_code

# Análise rápida de arquivo
result = analyze_cobol_file('programa.cbl')
print(result['content'])

# Análise rápida de código
result = analyze_cobol_code(cobol_code, program_name='TESTE')
print(result['content'])
```

### 2. Verificação de Sistema

```python
from cobol_to_docs import check_system_status, get_available_models

# Status completo do sistema
status = check_system_status()
print("Provedores disponíveis:", len([p for p in status['providers'].values() if p.get('available')]))

# Modelos disponíveis
models = get_available_models()
print("Modelos:", models)
```

## Integração em Aplicações

### 1. Aplicação Web Flask

```python
from flask import Flask, request, jsonify
from cobol_to_docs import COBOLAnalyzer

app = Flask(__name__)
analyzer = COBOLAnalyzer()

@app.route('/analyze', methods=['POST'])
def analyze_cobol():
    try:
        data = request.get_json()
        cobol_code = data['code']
        program_name = data.get('program_name', 'PROGRAMA')
        
        result = analyzer.analyze_code(cobol_code, program_name)
        
        return jsonify({
            'success': True,
            'analysis': result['content'],
            'metadata': {
                'model': result['model'],
                'tokens': result['tokens_used'],
                'cost': result['cost']
            }
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
```

### 2. Script de Processamento em Lote

```python
#!/usr/bin/env python3
"""
Script para processamento em lote de programas COBOL
"""

import os
import sys
import argparse
from pathlib import Path
from cobol_to_docs import COBOLAnalyzer

def process_directory(directory_path, output_dir, parallel=True):
    """Processa todos os arquivos COBOL em um diretório."""
    
    # Inicializar analisador
    analyzer = COBOLAnalyzer(parallel_processing=parallel)
    
    # Encontrar arquivos COBOL
    cobol_files = []
    for ext in ['.cbl', '.cob', '.cobol']:
        cobol_files.extend(Path(directory_path).glob(f'**/*{ext}'))
    
    print(f"Encontrados {len(cobol_files)} arquivos COBOL")
    
    # Processar arquivos
    results = analyzer.analyze_multiple_files(
        [str(f) for f in cobol_files],
        parallel=parallel
    )
    
    # Salvar resultados
    output_path = Path(output_dir)
    output_path.mkdir(exist_ok=True)
    
    for file_path, result in results['results'].items():
        file_name = Path(file_path).stem
        output_file = output_path / f"{file_name}_analysis.md"
        
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(result['content'])
        
        print(f"Análise salva: {output_file}")
    
    # Relatório final
    stats = results['statistics']
    print(f"\nRelatório Final:")
    print(f"Arquivos processados: {stats['successful']}/{stats['total_files']}")
    print(f"Taxa de sucesso: {stats['success_rate']:.1f}%")
    
    return results

def main():
    parser = argparse.ArgumentParser(description='Processamento em lote COBOL')
    parser.add_argument('directory', help='Diretório com arquivos COBOL')
    parser.add_argument('--output', '-o', default='output', help='Diretório de saída')
    parser.add_argument('--sequential', action='store_true', help='Processamento sequencial')
    
    args = parser.parse_args()
    
    if not os.path.exists(args.directory):
        print(f"Erro: Diretório {args.directory} não encontrado")
        sys.exit(1)
    
    try:
        process_directory(
            args.directory,
            args.output,
            parallel=not args.sequential
        )
    except Exception as e:
        print(f"Erro no processamento: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()
```

### 3. Integração com Jupyter Notebook

```python
# Célula 1: Configuração
from cobol_to_docs import COBOLAnalyzer
import pandas as pd
import matplotlib.pyplot as plt

# Inicializar analisador
analyzer = COBOLAnalyzer()

# Célula 2: Análise de múltiplos programas
programs = {
    'PROGRAMA1': open('programa1.cbl').read(),
    'PROGRAMA2': open('programa2.cbl').read(),
    'PROGRAMA3': open('programa3.cbl').read()
}

results = []
for name, code in programs.items():
    result = analyzer.analyze_code(code, program_name=name)
    results.append({
        'programa': name,
        'modelo': result['model'],
        'tokens': result['tokens_used'],
        'custo': result['cost'],
        'tempo': result['response_time']
    })

# Célula 3: Análise dos resultados
df = pd.DataFrame(results)
print(df)

# Gráfico de custos
plt.figure(figsize=(10, 6))
plt.bar(df['programa'], df['custo'])
plt.title('Custo por Programa')
plt.ylabel('Custo (USD)')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# Célula 4: Métricas do sistema
metrics = analyzer.get_performance_metrics()
print("Métricas do Sistema:")
print(f"Cache hit rate: {metrics['cache']['hit_rate']}%")
print(f"Análises realizadas: {metrics['model_selector']['recommendations_made']}")
```

### 4. Classe Wrapper Personalizada

```python
class COBOLDocumentationGenerator:
    """Wrapper personalizado para geração de documentação COBOL."""
    
    def __init__(self, config_path=None):
        self.analyzer = COBOLAnalyzer(config_path=config_path)
        self.results_cache = {}
    
    def analyze_program(self, file_path, force_refresh=False):
        """Analisa um programa com cache personalizado."""
        
        if not force_refresh and file_path in self.results_cache:
            return self.results_cache[file_path]
        
        result = self.analyzer.analyze_file(file_path)
        self.results_cache[file_path] = result
        
        return result
    
    def generate_system_documentation(self, program_files, output_dir):
        """Gera documentação completa de um sistema."""
        
        from pathlib import Path
        import json
        
        output_path = Path(output_dir)
        output_path.mkdir(exist_ok=True)
        
        # Analisar todos os programas
        system_results = {}
        for file_path in program_files:
            print(f"Analisando {file_path}...")
            result = self.analyze_program(file_path)
            system_results[file_path] = result
        
        # Gerar documentação individual
        for file_path, result in system_results.items():
            program_name = Path(file_path).stem
            doc_file = output_path / f"{program_name}.md"
            
            with open(doc_file, 'w', encoding='utf-8') as f:
                f.write(result['content'])
        
        # Gerar índice do sistema
        index_content = "# Documentação do Sistema\\n\\n"
        for file_path in system_results.keys():
            program_name = Path(file_path).stem
            index_content += f"- [{program_name}]({program_name}.md)\\n"
        
        with open(output_path / "README.md", 'w', encoding='utf-8') as f:
            f.write(index_content)
        
        # Gerar relatório de métricas
        metrics_summary = {
            'total_programs': len(system_results),
            'total_tokens': sum(r['tokens_used'] for r in system_results.values()),
            'total_cost': sum(r['cost'] for r in system_results.values()),
            'models_used': list(set(r['model'] for r in system_results.values()))
        }
        
        with open(output_path / "metrics.json", 'w') as f:
            json.dump(metrics_summary, f, indent=2)
        
        print(f"Documentação gerada em: {output_path}")
        return metrics_summary
    
    def get_system_metrics(self):
        """Obtém métricas do sistema."""
        return self.analyzer.get_performance_metrics()

# Uso da classe personalizada
doc_generator = COBOLDocumentationGenerator()

programs = ['prog1.cbl', 'prog2.cbl', 'prog3.cbl']
metrics = doc_generator.generate_system_documentation(programs, 'docs_sistema')

print(f"Programas documentados: {metrics['total_programs']}")
print(f"Custo total: ${metrics['total_cost']:.4f}")
```

## Configuração Programática

### 1. Configuração Dinâmica

```python
# Configurar analyzer programaticamente
config = {
    'ai': {
        'primary_provider': 'openai',
        'models': {
            'gpt_4_turbo': {
                'provider': 'openai',
                'name': 'gpt-4-turbo',
                'max_tokens': 4096,
                'temperature': 0.1
            }
        }
    },
    'rag': {
        'enabled': True,
        'auto_learning': True,
        'similarity_threshold': 0.8
    },
    'performance': {
        'cache_enabled': True,
        'parallel_analysis': True,
        'max_workers': 8
    }
}

# Salvar configuração temporária
import tempfile
import yaml

with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
    yaml.dump(config, f)
    config_path = f.name

# Usar configuração
analyzer = COBOLAnalyzer(config_path=config_path)
```

### 2. Configuração de Logging

```python
import logging

# Configurar logging detalhado
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('cobol_analysis.log'),
        logging.StreamHandler()
    ]
)

# Usar analyzer com logging detalhado
analyzer = COBOLAnalyzer()
result = analyzer.analyze_file('programa.cbl')
```

## Tratamento de Erros

### 1. Captura de Erros Específicos

```python
from cobol_to_docs import COBOLAnalyzer

analyzer = COBOLAnalyzer()

try:
    result = analyzer.analyze_file('programa_inexistente.cbl')
except FileNotFoundError:
    print("Arquivo não encontrado")
except RuntimeError as e:
    if "não disponível" in str(e):
        print("Nenhum provider disponível")
    else:
        print(f"Erro de runtime: {e}")
except Exception as e:
    print(f"Erro inesperado: {e}")
```

### 2. Validação de Entrada

```python
def safe_analyze_code(analyzer, cobol_code, program_name):
    """Análise segura com validação."""
    
    # Validar entrada
    if not cobol_code or not cobol_code.strip():
        raise ValueError("Código COBOL não pode estar vazio")
    
    if len(cobol_code) > 1000000:  # 1MB
        raise ValueError("Código muito grande")
    
    if not program_name or not program_name.strip():
        program_name = "PROGRAMA"
    
    try:
        return analyzer.analyze_code(cobol_code, program_name)
    except Exception as e:
        print(f"Erro na análise de {program_name}: {e}")
        return None

# Uso
result = safe_analyze_code(analyzer, cobol_code, "TESTE")
if result:
    print(result['content'])
```

## Testes e Validação

### 1. Teste Básico

```python
def test_cobol_analyzer():
    """Teste básico do analisador."""
    
    from cobol_to_docs import COBOLAnalyzer
    
    # Inicializar
    analyzer = COBOLAnalyzer()
    
    # Verificar inicialização
    assert analyzer is not None
    
    # Verificar modelos
    models = analyzer.get_available_models()
    assert len(models) > 0
    
    # Teste de análise simples
    simple_code = """
    IDENTIFICATION DIVISION.
    PROGRAM-ID. TESTE.
    PROCEDURE DIVISION.
    DISPLAY 'HELLO'.
    STOP RUN.
    """
    
    result = analyzer.analyze_code(simple_code, "TESTE")
    
    # Verificar resultado
    assert 'content' in result
    assert 'model' in result
    assert 'tokens_used' in result
    assert len(result['content']) > 0
    
    print("Teste básico passou!")

# Executar teste
test_cobol_analyzer()
```

### 2. Teste de Performance

```python
import time

def benchmark_analyzer():
    """Benchmark do analisador."""
    
    from cobol_to_docs import COBOLAnalyzer
    
    analyzer = COBOLAnalyzer()
    
    # Código de teste
    test_code = """
    IDENTIFICATION DIVISION.
    PROGRAM-ID. BENCHMARK.
    DATA DIVISION.
    WORKING-STORAGE SECTION.
    01 WS-COUNTER PIC 9(5).
    PROCEDURE DIVISION.
    PERFORM VARYING WS-COUNTER FROM 1 BY 1 UNTIL WS-COUNTER > 100
        DISPLAY 'COUNTER: ' WS-COUNTER
    END-PERFORM.
    STOP RUN.
    """
    
    # Benchmark
    start_time = time.time()
    
    for i in range(5):
        result = analyzer.analyze_code(test_code, f"BENCHMARK_{i}")
        print(f"Análise {i+1}: {result['tokens_used']} tokens, {result['response_time']:.2f}s")
    
    total_time = time.time() - start_time
    print(f"Tempo total: {total_time:.2f}s")
    print(f"Tempo médio por análise: {total_time/5:.2f}s")
    
    # Métricas do cache
    metrics = analyzer.get_performance_metrics()
    print(f"Cache hit rate: {metrics['cache']['hit_rate']}%")

# Executar benchmark
benchmark_analyzer()
```

## Exemplos Avançados

### 1. Análise Comparativa de Modelos

```python
def compare_models(cobol_code, program_name):
    """Compara análise entre diferentes modelos."""
    
    from cobol_to_docs import COBOLAnalyzer
    
    analyzer = COBOLAnalyzer()
    models = analyzer.get_available_models()
    
    results = {}
    
    for model in models:
        try:
            print(f"Analisando com {model}...")
            result = analyzer.analyze_code(
                cobol_code, 
                program_name, 
                model=model
            )
            
            results[model] = {
                'tokens': result['tokens_used'],
                'cost': result['cost'],
                'time': result['response_time'],
                'content_length': len(result['content'])
            }
            
        except Exception as e:
            print(f"Erro com {model}: {e}")
            results[model] = {'error': str(e)}
    
    # Comparar resultados
    print("\\nComparação de Modelos:")
    print("-" * 60)
    
    for model, data in results.items():
        if 'error' in data:
            print(f"{model}: ERRO - {data['error']}")
        else:
            print(f"{model}:")
            print(f"  Tokens: {data['tokens']}")
            print(f"  Custo: ${data['cost']:.4f}")
            print(f"  Tempo: {data['time']:.2f}s")
            print(f"  Tamanho: {data['content_length']} chars")
    
    return results

# Uso
cobol_code = """
IDENTIFICATION DIVISION.
PROGRAM-ID. CALCULO-FOLHA.
DATA DIVISION.
WORKING-STORAGE SECTION.
01 WS-SALARIO-BASE    PIC 9(7)V99.
01 WS-DESCONTO-INSS   PIC 9(5)V99.
01 WS-DESCONTO-IR     PIC 9(5)V99.
01 WS-SALARIO-LIQUIDO PIC 9(7)V99.

PROCEDURE DIVISION.
MAIN-LOGIC.
    MOVE 5000.00 TO WS-SALARIO-BASE
    
    IF WS-SALARIO-BASE <= 1212.00
        COMPUTE WS-DESCONTO-INSS = WS-SALARIO-BASE * 0.075
    ELSE
        IF WS-SALARIO-BASE <= 2427.35
            COMPUTE WS-DESCONTO-INSS = WS-SALARIO-BASE * 0.09
        ELSE
            COMPUTE WS-DESCONTO-INSS = WS-SALARIO-BASE * 0.12
        END-IF
    END-IF
    
    IF WS-SALARIO-BASE > 1903.98
        COMPUTE WS-DESCONTO-IR = (WS-SALARIO-BASE - 1903.98) * 0.075
    ELSE
        MOVE ZERO TO WS-DESCONTO-IR
    END-IF
    
    COMPUTE WS-SALARIO-LIQUIDO = WS-SALARIO-BASE - WS-DESCONTO-INSS - WS-DESCONTO-IR
    
    DISPLAY 'SALARIO BASE: ' WS-SALARIO-BASE
    DISPLAY 'DESCONTO INSS: ' WS-DESCONTO-INSS
    DISPLAY 'DESCONTO IR: ' WS-DESCONTO-IR
    DISPLAY 'SALARIO LIQUIDO: ' WS-SALARIO-LIQUIDO
    
    STOP RUN.
"""

comparison = compare_models(cobol_code, "CALCULO-FOLHA")
```

### 2. Monitoramento Contínuo

```python
import threading
import time
import json
from datetime import datetime

class COBOLAnalysisMonitor:
    """Monitor contínuo de análises COBOL."""
    
    def __init__(self, analyzer):
        self.analyzer = analyzer
        self.metrics_history = []
        self.monitoring = False
        self.monitor_thread = None
    
    def start_monitoring(self, interval=60):
        """Inicia monitoramento."""
        self.monitoring = True
        self.monitor_thread = threading.Thread(
            target=self._monitor_loop,
            args=(interval,)
        )
        self.monitor_thread.start()
        print(f"Monitoramento iniciado (intervalo: {interval}s)")
    
    def stop_monitoring(self):
        """Para monitoramento."""
        self.monitoring = False
        if self.monitor_thread:
            self.monitor_thread.join()
        print("Monitoramento parado")
    
    def _monitor_loop(self, interval):
        """Loop de monitoramento."""
        while self.monitoring:
            try:
                metrics = self.analyzer.get_performance_metrics()
                
                # Adicionar timestamp
                metrics['timestamp'] = datetime.now().isoformat()
                
                # Salvar histórico
                self.metrics_history.append(metrics)
                
                # Manter apenas últimas 100 entradas
                if len(self.metrics_history) > 100:
                    self.metrics_history.pop(0)
                
                # Log métricas
                cache_hit_rate = metrics.get('cache', {}).get('hit_rate', 0)
                print(f"[{datetime.now().strftime('%H:%M:%S')}] Cache: {cache_hit_rate}%")
                
            except Exception as e:
                print(f"Erro no monitoramento: {e}")
            
            time.sleep(interval)
    
    def get_metrics_summary(self):
        """Obtém resumo das métricas."""
        if not self.metrics_history:
            return {}
        
        # Calcular médias
        cache_rates = [m.get('cache', {}).get('hit_rate', 0) for m in self.metrics_history]
        avg_cache_rate = sum(cache_rates) / len(cache_rates) if cache_rates else 0
        
        return {
            'monitoring_duration': len(self.metrics_history),
            'avg_cache_hit_rate': avg_cache_rate,
            'last_update': self.metrics_history[-1]['timestamp'] if self.metrics_history else None
        }
    
    def save_metrics_report(self, filename):
        """Salva relatório de métricas."""
        report = {
            'summary': self.get_metrics_summary(),
            'history': self.metrics_history
        }
        
        with open(filename, 'w') as f:
            json.dump(report, f, indent=2)
        
        print(f"Relatório salvo: {filename}")

# Uso do monitor
from cobol_to_docs import COBOLAnalyzer

analyzer = COBOLAnalyzer()
monitor = COBOLAnalysisMonitor(analyzer)

# Iniciar monitoramento
monitor.start_monitoring(interval=30)

# Fazer algumas análises
test_code = "IDENTIFICATION DIVISION.\\nPROGRAM-ID. TESTE.\\nPROCEDURE DIVISION.\\nSTOP RUN."

for i in range(5):
    result = analyzer.analyze_code(test_code, f"TESTE_{i}")
    print(f"Análise {i+1} concluída")
    time.sleep(10)

# Parar monitoramento e gerar relatório
monitor.stop_monitoring()
summary = monitor.get_metrics_summary()
print("Resumo do monitoramento:", summary)

monitor.save_metrics_report('metrics_report.json')
```

---

**COBOL to Docs v1.6** - Guia Completo da Biblioteca Python
