# Guia Completo de Instalação - COBOL to Docs v1.6

## Pré-requisitos

### Sistema Operacional
- **Linux**: Ubuntu 18.04+ (recomendado), CentOS 7+, RHEL 7+
- **Windows**: Windows 10+ com WSL2 ou Python nativo
- **macOS**: macOS 10.14+ com Homebrew

### Python
- **Versão**: Python 3.8 ou superior (recomendado: Python 3.11)
- **Gerenciador de Pacotes**: pip 21.0+ ou conda

### Dependências do Sistema
```bash
# Ubuntu/Debian
sudo apt update
sudo apt install -y python3 python3-pip python3-venv git

# CentOS/RHEL
sudo yum install -y python3 python3-pip git

# macOS
brew install python3 git
```

## Métodos de Instalação

### 1. Instalação via Código Fonte (Recomendado)

#### Passo 1: Clonar ou Extrair o Projeto
```bash
# Se usando Git
git clone <repositorio> cobol_to_docs_v1.6
cd cobol_to_docs_v1.6

# Se usando arquivo compactado
tar -xzf cobol_to_docs_v1.6_FINAL.tar.gz
cd cobol_to_docs_v1.6
```

#### Passo 2: Criar Ambiente Virtual (Recomendado)
```bash
# Criar ambiente virtual
python3 -m venv venv

# Ativar ambiente virtual
# Linux/macOS:
source venv/bin/activate
# Windows:
venv\Scripts\activate
```

#### Passo 3: Instalação Básica
```bash
# Instalação mínima (funcionalidades core)
pip install -e .

# Verificar instalação
cobol-to-docs --help
```

#### Passo 4: Instalação com Dependências Opcionais
```bash
# Instalação completa (todas as funcionalidades)
pip install -e .[full]

# Ou instalar dependências específicas:
pip install -e .[openai]      # Suporte OpenAI
pip install -e .[bedrock]     # Suporte AWS Bedrock
pip install -e .[github]      # Suporte GitHub Copilot
pip install -e .[anthropic]   # Suporte Anthropic Claude
```

### 2. Instalação Direta via pip

#### Para Desenvolvimento
```bash
# Instalação em modo desenvolvimento
pip install -e /caminho/para/cobol_to_docs_v1.6

# Com dependências opcionais
pip install -e /caminho/para/cobol_to_docs_v1.6[full]
```

#### Para Produção
```bash
# Instalação fixa (quando disponível no PyPI)
pip install cobol-to-docs==1.6.0

# Com dependências específicas
pip install cobol-to-docs[openai,bedrock]
```

### 3. Instalação via Docker (Futuro)

```dockerfile
# Dockerfile exemplo
FROM python:3.11-slim

WORKDIR /app
COPY . .
RUN pip install -e .[full]

CMD ["cobol-to-docs", "--help"]
```

## Configuração Inicial

### 1. Verificar Instalação
```bash
# Testar comando CLI
cobol-to-docs --help

# Testar biblioteca Python
python -c "from cobol_to_docs import COBOLAnalyzer; print('OK')"

# Testar main.py diretamente
python main.py --help
```

### 2. Configurar Variáveis de Ambiente

#### Arquivo .env (Recomendado)
```bash
# Criar arquivo .env na raiz do projeto
cat > .env << 'EOF'
# LuzIA Configuration
LUZIA_API_KEY=sua_chave_luzia_aqui
LUZIA_BASE_URL=https://luzia-api.example.com

# GitHub Copilot Configuration
GITHUB_TOKEN=seu_token_github_aqui

# OpenAI Configuration (opcional)
OPENAI_API_KEY=sua_chave_openai_aqui

# AWS Bedrock Configuration (opcional)
AWS_ACCESS_KEY_ID=sua_chave_aws_aqui
AWS_SECRET_ACCESS_KEY=sua_chave_secreta_aws_aqui
AWS_DEFAULT_REGION=us-east-1

# Anthropic Configuration (opcional)
ANTHROPIC_API_KEY=sua_chave_anthropic_aqui
EOF

# Carregar variáveis
source .env
```

#### Configuração do Sistema
```bash
# Adicionar ao ~/.bashrc ou ~/.zshrc
echo 'export LUZIA_API_KEY="sua_chave_luzia"' >> ~/.bashrc
echo 'export GITHUB_TOKEN="seu_token_github"' >> ~/.bashrc
source ~/.bashrc
```

### 3. Configurar Arquivo config.yaml

#### Configuração Mínima
```yaml
# config/config.yaml
providers:
  primary: "luzia"
  fallback: ["enhanced_mock", "basic"]
  
  luzia:
    base_url: "${LUZIA_BASE_URL}"
    api_key: "${LUZIA_API_KEY}"
    timeout: 30
    
  enhanced_mock:
    enabled: true
    mode: "enhanced"

rag:
  enabled: true
  knowledge_base_path: "data/cobol_knowledge_base_cadoc_expanded.json"
  auto_learning: true

cache:
  enabled: true
  max_age_hours: 24

logging:
  level: "INFO"
  file: "logs/cobol_to_docs.log"
```

#### Configuração Completa
```yaml
# config/config.yaml
providers:
  primary: "luzia"
  fallback: ["github_copilot", "enhanced_mock", "basic"]
  
  luzia:
    base_url: "${LUZIA_BASE_URL}"
    api_key: "${LUZIA_API_KEY}"
    timeout: 30
    models:
      - "aws_claude_3_5_sonnet"
      - "amazon_nova_pro_v1"
  
  github_copilot:
    api_key: "${GITHUB_TOKEN}"
    model: "gpt-4"
    timeout: 30
  
  openai:
    api_key: "${OPENAI_API_KEY}"
    models:
      - "gpt-4"
      - "gpt-3.5-turbo"
  
  bedrock:
    region: "${AWS_DEFAULT_REGION}"
    models:
      - "anthropic.claude-3-sonnet-20240229-v1:0"

rag:
  enabled: true
  knowledge_base_path: "data/cobol_knowledge_base_cadoc_expanded.json"
  auto_learning: true
  max_context_items: 10
  embedding_model: "sentence-transformers/all-MiniLM-L6-v2"

cache:
  enabled: true
  cache_dir: "cache"
  max_age_hours: 24
  cleanup_interval: 3600

parallel:
  enabled: true
  max_workers: 4
  chunk_size: 10

validation:
  anti_hallucination: true
  consistency_check: true
  confidence_threshold: 0.7

logging:
  level: "INFO"
  file: "logs/cobol_to_docs.log"
  max_size: "10MB"
  backup_count: 5
```

## Teste da Instalação

### 1. Teste Básico
```bash
# Criar arquivo de teste
echo 'IDENTIFICATION DIVISION.
PROGRAM-ID. TESTE-INSTALACAO.
PROCEDURE DIVISION.
DISPLAY "HELLO WORLD".
STOP RUN.' > teste.cbl

# Executar análise básica
cobol-to-docs --file teste.cbl --model enhanced_mock
```

### 2. Teste Completo
```bash
# Teste com todas as funcionalidades
python main.py --fontes teste.cbl --models enhanced_mock \
  --advanced --generate-prompts --validate --output teste_completo

# Verificar saídas
ls -la teste_completo/
```

### 3. Teste da Biblioteca Python
```python
# teste_biblioteca.py
from cobol_to_docs import COBOLAnalyzer

def test_biblioteca():
    # Inicializar
    analyzer = COBOLAnalyzer()
    
    # Verificar status
    status = analyzer.get_provider_status()
    print(f"Provedores disponíveis: {list(status.keys())}")
    
    # Testar análise
    codigo = '''IDENTIFICATION DIVISION.
PROGRAM-ID. TESTE-LIB.
PROCEDURE DIVISION.
DISPLAY "TESTE BIBLIOTECA".
STOP RUN.'''
    
    result = analyzer.analyze_code(codigo, model='enhanced_mock')
    print(f"Análise bem-sucedida: {result.get('success', False)}")
    
    return result.get('success', False)

if __name__ == '__main__':
    success = test_biblioteca()
    print(f"Teste da biblioteca: {'PASSOU' if success else 'FALHOU'}")
```

```bash
# Executar teste
python teste_biblioteca.py
```

## Resolução de Problemas

### Problemas Comuns

#### 1. Comando cobol-to-docs não encontrado
```bash
# Verificar se está no PATH
which cobol-to-docs

# Se não estiver, reinstalar
pip uninstall cobol-to-docs
pip install -e .

# Ou usar caminho completo
python -m cobol_to_docs.cli --help
```

#### 2. Erro de importação de módulos
```bash
# Verificar instalação
pip list | grep cobol-to-docs

# Verificar PYTHONPATH
python -c "import sys; print('\n'.join(sys.path))"

# Reinstalar com dependências
pip install -e .[full] --force-reinstall
```

#### 3. Problemas de permissão
```bash
# Instalar sem sudo (recomendado)
pip install --user -e .

# Ou usar ambiente virtual
python -m venv venv
source venv/bin/activate
pip install -e .
```

#### 4. Dependências não encontradas
```bash
# Instalar dependências manualmente
pip install pyyaml requests beautifulsoup4 lark markdown

# Ou instalar versão completa
pip install -e .[full]
```

#### 5. Problemas com providers
```bash
# Testar sem providers externos
python main.py --fontes teste.cbl --models enhanced_mock --no-rag

# Verificar configuração
python -c "
from src.core.config import ConfigManager
config = ConfigManager()
print('Configuração carregada com sucesso')
"
```

### Logs e Debugging

#### Ativar Logs Detalhados
```bash
# Executar com debug
python main.py --fontes teste.cbl --models enhanced_mock --log-level DEBUG

# Verificar logs
tail -f logs/cobol_to_docs_*.log
```

#### Verificar Status do Sistema
```python
# status_sistema.py
from cobol_to_docs import COBOLAnalyzer

analyzer = COBOLAnalyzer()

# Status dos provedores
print("=== STATUS DOS PROVEDORES ===")
status = analyzer.get_provider_status()
for provider, info in status.items():
    print(f"{provider}: {info}")

# Métricas de performance
print("\n=== MÉTRICAS DE PERFORMANCE ===")
metrics = analyzer.get_performance_metrics()
for metric, value in metrics.items():
    print(f"{metric}: {value}")

# Status das dependências
print("\n=== STATUS DAS DEPENDÊNCIAS ===")
deps = analyzer.get_dependency_status()
for dep, available in deps.items():
    print(f"{dep}: {'✓' if available else '✗'}")
```

## Configuração para Produção

### 1. Configuração de Segurança
```bash
# Criar usuário específico
sudo useradd -m -s /bin/bash cobol-docs
sudo su - cobol-docs

# Configurar permissões
chmod 600 .env
chmod 755 /opt/cobol-to-docs/
```

### 2. Configuração de Performance
```yaml
# config/production.yaml
cache:
  enabled: true
  max_age_hours: 168  # 1 semana
  cleanup_interval: 3600

parallel:
  enabled: true
  max_workers: 8  # Ajustar conforme CPU

rag:
  enabled: true
  max_context_items: 20  # Mais contexto em produção
```

### 3. Monitoramento
```bash
# Script de monitoramento
#!/bin/bash
# monitor.sh

LOG_FILE="/var/log/cobol-to-docs/monitor.log"
ERROR_COUNT=$(grep -c "ERROR" $LOG_FILE)

if [ $ERROR_COUNT -gt 10 ]; then
    echo "Muitos erros detectados: $ERROR_COUNT" | mail -s "COBOL to Docs Alert" admin@empresa.com
fi
```

## Atualizações

### Atualizar Sistema
```bash
# Backup da configuração
cp config/config.yaml config/config.yaml.bak

# Atualizar código
git pull origin main
# ou extrair nova versão

# Reinstalar
pip install -e .[full] --force-reinstall

# Restaurar configuração se necessário
cp config/config.yaml.bak config/config.yaml
```

### Migração de Versões
```bash
# Backup completo
tar -czf backup_cobol_to_docs_$(date +%Y%m%d).tar.gz \
  config/ data/ cache/ logs/

# Verificar compatibilidade
python -c "from cobol_to_docs import COBOLAnalyzer; print('Compatível')"
```

## Suporte

### Recursos de Ajuda
- **Documentação**: `docs/` directory
- **Exemplos**: `examples/` directory
- **Logs**: `logs/` directory
- **Configuração**: `config/` directory

### Comandos Úteis
```bash
# Ajuda geral
cobol-to-docs --help
python main.py --help

# Versão
python -c "from cobol_to_docs import __version__; print(__version__)"

# Status do sistema
python -c "
from cobol_to_docs import COBOLAnalyzer
analyzer = COBOLAnalyzer()
print('Sistema funcionando corretamente')
"
```

---

**Instalação concluída com sucesso!** O COBOL to Docs v1.6 está pronto para uso.
