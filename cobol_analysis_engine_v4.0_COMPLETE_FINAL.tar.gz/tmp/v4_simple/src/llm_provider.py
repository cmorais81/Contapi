# -*- coding: utf-8 -*-
"""Módulo para consulta a provedores de LLM."""

import os
import requests
import json
import time
from abc import ABC, abstractmethod

class BaseLLMProvider(ABC):
    """Classe base abstrata para provedores de LLM."""

    @abstractmethod
    def query(self, prompt, max_tokens=4096):
        """Envia um prompt para o LLM e retorna a resposta."""
        pass

class LuziaProvider(BaseLLMProvider):
    """Provedor para a API LuzIA."""

    def __init__(self):
        self.api_url = os.environ.get("LUZIA_API_URL")
        self.client_id = os.environ.get("LUZIA_CLIENT_ID")
        self.client_secret = os.environ.get("LUZIA_CLIENT_SECRET")
        self.token = None
        self.token_expiry = 0

    def _get_token(self):
        """Obtém ou renova o token de autenticação."""
        if time.time() < self.token_expiry:
            return self.token

        if not self.api_url or not self.client_id or not self.client_secret:
            raise ValueError("As variáveis de ambiente LUZIA_API_URL, LUZIA_CLIENT_ID e LUZIA_CLIENT_SECRET são necessárias.")

        token_url = f"{self.api_url}/api/v1/auth/token"
        payload = {
            "client_id": self.client_id,
            "client_secret": self.client_secret,
            "grant_type": "client_credentials"
        }
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}

        try:
            response = requests.post(token_url, data=payload, headers=headers, verify=False, timeout=30)
            response.raise_for_status()
            token_data = response.json()
            self.token = token_data["access_token"]
            # Define a expiração para 5 minutos antes do tempo real para segurança
            self.token_expiry = time.time() + token_data.get("expires_in", 3600) - 300
            return self.token
        except requests.exceptions.RequestException as e:
            print(f"Erro ao obter token do LuzIA: {e}")
            return None

    def query(self, prompt, max_tokens=8192):
        """Consulta a API LuzIA."""
        token = self._get_token()
        if not token:
            return {"success": False, "response": "Falha ao obter token de autenticação."}

        query_url = f"{self.api_url}/api/v1/analysis"
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }
        payload = {
            "prompt": prompt,
            "max_tokens": max_tokens
            # Adicionar outros parâmetros específicos do LuzIA se necessário
        }

        start_time = time.time()
        try:
            response = requests.post(query_url, json=payload, headers=headers, verify=False, timeout=120)
            response.raise_for_status()
            processing_time = time.time() - start_time
            return {
                "success": True, 
                "response": response.json(), 
                "processing_time": processing_time
            }
        except requests.exceptions.RequestException as e:
            processing_time = time.time() - start_time
            return {
                "success": False, 
                "response": f"Erro na chamada da API LuzIA: {e}",
                "processing_time": processing_time
            }

class OpenAIProvider(BaseLLMProvider):
    """Provedor para a API OpenAI."""

    def __init__(self):
        self.api_key = os.environ.get("OPENAI_API_KEY")
        self.api_url = "https://api.openai.com/v1/chat/completions"

    def query(self, prompt, model="gpt-4-turbo", max_tokens=4096):
        """Consulta a API OpenAI."""
        if not self.api_key:
            raise ValueError("A variável de ambiente OPENAI_API_KEY é necessária.")

        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        payload = {
            "model": model,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": max_tokens
        }

        start_time = time.time()
        try:
            response = requests.post(self.api_url, json=payload, headers=headers, timeout=120)
            response.raise_for_status()
            processing_time = time.time() - start_time
            return {
                "success": True, 
                "response": response.json()['choices'][0]['message']['content'],
                "processing_time": processing_time
            }
        except requests.exceptions.RequestException as e:
            processing_time = time.time() - start_time
            return {
                "success": False, 
                "response": f"Erro na chamada da API OpenAI: {e}",
                "processing_time": processing_time
            }

class ProviderFactory:
    """Fábrica para criar instâncias de provedores de LLM."""

    @staticmethod
    def get_provider(provider_name):
        """Retorna uma instância do provedor solicitado."""
        if provider_name.lower() == 'luzia':
            return LuziaProvider()
        elif provider_name.lower() == 'openai':
            return OpenAIProvider()
        # Adicionar outros provedores aqui (Databricks, Bedrock)
        else:
            raise ValueError(f"Provedor desconhecido: {provider_name}")

