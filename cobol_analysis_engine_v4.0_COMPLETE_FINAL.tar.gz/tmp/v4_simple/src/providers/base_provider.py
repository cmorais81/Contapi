# -*- coding: utf-8 -*-
"""Classe base abstrata para provedores de LLM."""

import time
import logging
from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional

logger = logging.getLogger(__name__)

class BaseLLMProvider(ABC):
    """Classe base abstrata para provedores de LLM."""

    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.max_retries = config.get('max_retries', 3)
        self.retry_delay = config.get('retry_delay', 2)
        self.timeout = config.get('timeout', 120)
        
    @abstractmethod
    def authenticate(self) -> bool:
        """Autentica com o provedor de LLM."""
        pass
    
    @abstractmethod
    def _make_request(self, prompt: str, model: str, max_tokens: int) -> Dict[str, Any]:
        """Faz a requisição para o provedor de LLM."""
        pass
    
    def query(self, prompt: str, model: str = None, max_tokens: int = 4096) -> Dict[str, Any]:
        """
        Consulta o LLM com retry automático.
        
        Args:
            prompt: O prompt para enviar ao LLM
            model: O modelo a ser usado (opcional)
            max_tokens: Número máximo de tokens na resposta
            
        Returns:
            Dict com success, response, processing_time e metadata
        """
        start_time = time.time()
        
        # Seleciona o modelo padrão se não especificado
        if not model and self.config.get('models'):
            model = self.config['models'][0]['name']
        
        last_error = None
        
        for attempt in range(self.max_retries):
            try:
                logger.info(f"Tentativa {attempt + 1}/{self.max_retries} para {self.__class__.__name__}")
                
                # Autentica se necessário
                if not self.authenticate():
                    raise Exception("Falha na autenticação")
                
                # Faz a requisição
                result = self._make_request(prompt, model, max_tokens)
                
                processing_time = time.time() - start_time
                
                return {
                    "success": True,
                    "response": result,
                    "processing_time": processing_time,
                    "provider": self.__class__.__name__,
                    "model": model,
                    "attempt": attempt + 1
                }
                
            except Exception as e:
                last_error = str(e)
                logger.warning(f"Tentativa {attempt + 1} falhou: {last_error}")
                
                if attempt < self.max_retries - 1:
                    time.sleep(self.retry_delay)
        
        processing_time = time.time() - start_time
        
        return {
            "success": False,
            "response": f"Falha após {self.max_retries} tentativas: {last_error}",
            "processing_time": processing_time,
            "provider": self.__class__.__name__,
            "model": model,
            "attempt": self.max_retries
        }
    
    def chunk_prompt(self, prompt: str, max_chunk_size: int = 6000, overlap_size: int = 200) -> List[str]:
        """
        Divide um prompt grande em chunks menores.
        
        Args:
            prompt: O prompt original
            max_chunk_size: Tamanho máximo de cada chunk
            overlap_size: Tamanho da sobreposição entre chunks
            
        Returns:
            Lista de chunks do prompt
        """
        if len(prompt) <= max_chunk_size:
            return [prompt]
        
        chunks = []
        start = 0
        
        while start < len(prompt):
            end = start + max_chunk_size
            
            # Se não é o último chunk, tenta quebrar em uma quebra de linha
            if end < len(prompt):
                # Procura por quebra de linha próxima ao final
                newline_pos = prompt.rfind('\n', start + max_chunk_size - 200, end)
                if newline_pos > start:
                    end = newline_pos
            
            chunk = prompt[start:end]
            chunks.append(chunk)
            
            # Move o início para o próximo chunk com sobreposição
            start = end - overlap_size if end < len(prompt) else end
        
        return chunks
    
    def get_available_models(self) -> List[str]:
        """Retorna lista de modelos disponíveis para este provedor."""
        return [model['name'] for model in self.config.get('models', [])]
