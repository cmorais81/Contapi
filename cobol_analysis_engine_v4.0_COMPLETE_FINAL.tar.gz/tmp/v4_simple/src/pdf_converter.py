# -*- coding: utf-8 -*-
"""Módulo para conversão de relatórios Markdown para PDF."""

import os
import tempfile
import subprocess
import logging
import re
from pathlib import Path
from typing import Optional, List

logger = logging.getLogger(__name__)

class PDFConverter:
    """Converte relatórios Markdown para PDF usando navegador."""
    
    def __init__(self):
        self.html_template = """
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
        }}
        
        h1 {{
            color: #2c3e50;
            border-bottom: 3px solid #3498db;
            padding-bottom: 10px;
            margin-bottom: 30px;
        }}
        
        h2 {{
            color: #34495e;
            border-bottom: 2px solid #ecf0f1;
            padding-bottom: 8px;
            margin-top: 30px;
            margin-bottom: 20px;
        }}
        
        h3 {{
            color: #2c3e50;
            margin-top: 25px;
            margin-bottom: 15px;
        }}
        
        pre {{
            background-color: #f8f9fa;
            border: 1px solid #e9ecef;
            border-radius: 4px;
            padding: 15px;
            overflow-x: auto;
            font-family: 'Courier New', monospace;
            font-size: 12px;
            line-height: 1.4;
        }}
        
        code {{
            background-color: #f8f9fa;
            padding: 2px 4px;
            border-radius: 3px;
            font-family: 'Courier New', monospace;
            font-size: 90%;
        }}
        
        table {{
            border-collapse: collapse;
            width: 100%;
            margin: 20px 0;
        }}
        
        th, td {{
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }}
        
        th {{
            background-color: #f2f2f2;
            font-weight: bold;
        }}
        
        .metadata {{
            background-color: #e8f4fd;
            border-left: 4px solid #3498db;
            padding: 15px;
            margin: 20px 0;
        }}
        
        .success {{
            color: #27ae60;
            font-weight: bold;
        }}
        
        .failure {{
            color: #e74c3c;
            font-weight: bold;
        }}
        
        .section-divider {{
            border-top: 2px solid #bdc3c7;
            margin: 30px 0;
        }}
        
        ul, ol {{
            margin: 15px 0;
            padding-left: 30px;
        }}
        
        li {{
            margin: 8px 0;
        }}
        
        blockquote {{
            border-left: 4px solid #3498db;
            margin: 20px 0;
            padding: 10px 20px;
            background-color: #f8f9fa;
            font-style: italic;
        }}
        
        .page-break {{
            page-break-before: always;
        }}
        
        @media print {{
            body {{
                font-size: 12px;
            }}
            
            h1 {{
                font-size: 18px;
            }}
            
            h2 {{
                font-size: 16px;
            }}
            
            h3 {{
                font-size: 14px;
            }}
            
            pre {{
                font-size: 10px;
                page-break-inside: avoid;
            }}
            
            table {{
                page-break-inside: avoid;
            }}
        }}
    </style>
</head>
<body>
{content}
</body>
</html>
"""
    
    def convert_markdown_to_pdf(self, markdown_file: str, output_pdf: str = None) -> Optional[str]:
        """
        Converte arquivo Markdown para PDF.
        
        Args:
            markdown_file: Caminho para o arquivo Markdown
            output_pdf: Caminho para o PDF de saída (opcional)
            
        Returns:
            Caminho para o PDF gerado ou None se falhou
        """
        try:
            # Define arquivo de saída se não especificado
            if not output_pdf:
                output_pdf = markdown_file.replace('.md', '.pdf')
            
            # Lê o arquivo Markdown
            with open(markdown_file, 'r', encoding='utf-8') as f:
                markdown_content = f.read()
            
            # Converte Markdown para HTML
            html_content = self._markdown_to_html(markdown_content)
            
            # Extrai título do arquivo
            title = Path(markdown_file).stem
            
            # Gera HTML completo
            full_html = self.html_template.format(
                title=title,
                content=html_content
            )
            
            # Salva HTML temporário
            with tempfile.NamedTemporaryFile(mode='w', suffix='.html', delete=False, encoding='utf-8') as temp_html:
                temp_html.write(full_html)
                temp_html_path = temp_html.name
            
            try:
                # Converte HTML para PDF usando navegador
                success = self._html_to_pdf_browser(temp_html_path, output_pdf)
                
                if success:
                    logger.info(f"PDF gerado com sucesso: {output_pdf}")
                    return output_pdf
                else:
                    # Fallback: tenta usar weasyprint se disponível
                    return self._html_to_pdf_weasyprint(temp_html_path, output_pdf)
                    
            finally:
                # Remove arquivo HTML temporário
                try:
                    os.unlink(temp_html_path)
                except:
                    pass
                    
        except Exception as e:
            logger.error(f"Erro ao converter {markdown_file} para PDF: {e}")
            return None
    
    def _markdown_to_html(self, markdown_content: str) -> str:
        """Converte Markdown básico para HTML."""
        html = markdown_content
        
        # Headers
        html = re.sub(r'^### (.*$)', r'<h3>\1</h3>', html, flags=re.MULTILINE)
        html = re.sub(r'^## (.*$)', r'<h2>\1</h2>', html, flags=re.MULTILINE)
        html = re.sub(r'^# (.*$)', r'<h1>\1</h1>', html, flags=re.MULTILINE)
        
        # Code blocks
        html = re.sub(r'```(\w+)?\n(.*?)\n```', r'<pre><code>\2</code></pre>', html, flags=re.DOTALL)
        html = re.sub(r'```\n(.*?)\n```', r'<pre><code>\1</code></pre>', html, flags=re.DOTALL)
        
        # Inline code
        html = re.sub(r'`([^`]+)`', r'<code>\1</code>', html)
        
        # Bold and italic
        html = re.sub(r'\*\*(.*?)\*\*', r'<strong>\1</strong>', html)
        html = re.sub(r'\*(.*?)\*', r'<em>\1</em>', html)
        
        # Links
        html = re.sub(r'\[([^\]]+)\]\(([^)]+)\)', r'<a href="\2">\1</a>', html)
        
        # Lists
        html = re.sub(r'^- (.*$)', r'<li>\1</li>', html, flags=re.MULTILINE)
        html = re.sub(r'(<li>.*</li>)', r'<ul>\1</ul>', html, flags=re.DOTALL)
        
        # Horizontal rules
        html = re.sub(r'^---$', r'<hr class="section-divider">', html, flags=re.MULTILINE)
        
        # Paragraphs
        paragraphs = html.split('\n\n')
        html_paragraphs = []
        
        for para in paragraphs:
            para = para.strip()
            if para and not any(para.startswith(tag) for tag in ['<h', '<pre', '<ul', '<hr', '<table']):
                # Adiciona classe especial para metadados
                if '**Status:**' in para or '**Provedor:**' in para:
                    html_paragraphs.append(f'<div class="metadata">{para}</div>')
                else:
                    html_paragraphs.append(f'<p>{para}</p>')
            elif para:
                html_paragraphs.append(para)
        
        return '\n'.join(html_paragraphs)
    
    def _html_to_pdf_browser(self, html_file: str, output_pdf: str) -> bool:
        """Converte HTML para PDF usando navegador (Chrome/Chromium)."""
        try:
            # Tenta diferentes comandos de navegador
            browsers = [
                'google-chrome',
                'chromium-browser', 
                'chromium',
                'chrome'
            ]
            
            for browser in browsers:
                try:
                    cmd = [
                        browser,
                        '--headless',
                        '--disable-gpu',
                        '--no-sandbox',
                        '--disable-dev-shm-usage',
                        '--print-to-pdf=' + output_pdf,
                        '--print-to-pdf-no-header',
                        '--run-all-compositor-stages-before-draw',
                        '--virtual-time-budget=5000',
                        f'file://{os.path.abspath(html_file)}'
                    ]
                    
                    result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
                    
                    if result.returncode == 0 and os.path.exists(output_pdf):
                        logger.info(f"PDF gerado usando {browser}")
                        return True
                        
                except (subprocess.TimeoutExpired, FileNotFoundError):
                    continue
            
            return False
            
        except Exception as e:
            logger.error(f"Erro ao converter HTML para PDF com navegador: {e}")
            return False
    
    def _html_to_pdf_weasyprint(self, html_file: str, output_pdf: str) -> Optional[str]:
        """Fallback: converte HTML para PDF usando WeasyPrint."""
        try:
            import weasyprint
            
            weasyprint.HTML(filename=html_file).write_pdf(output_pdf)
            logger.info(f"PDF gerado usando WeasyPrint: {output_pdf}")
            return output_pdf
            
        except ImportError:
            logger.warning("WeasyPrint não disponível. Tentando comando weasyprint...")
            
            try:
                cmd = ['weasyprint', html_file, output_pdf]
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
                
                if result.returncode == 0 and os.path.exists(output_pdf):
                    logger.info(f"PDF gerado usando comando weasyprint")
                    return output_pdf
                    
            except (subprocess.TimeoutExpired, FileNotFoundError):
                pass
        
        except Exception as e:
            logger.error(f"Erro ao usar WeasyPrint: {e}")
        
        return None
    
    def convert_all_reports_to_pdf(self, reports_dir: str) -> List[str]:
        """
        Converte todos os relatórios Markdown de um diretório para PDF.
        
        Args:
            reports_dir: Diretório contendo os relatórios .md
            
        Returns:
            Lista de caminhos dos PDFs gerados
        """
        pdf_files = []
        
        try:
            reports_path = Path(reports_dir)
            
            for md_file in reports_path.glob('*.md'):
                pdf_file = str(md_file).replace('.md', '.pdf')
                
                logger.info(f"Convertendo {md_file.name} para PDF...")
                
                result = self.convert_markdown_to_pdf(str(md_file), pdf_file)
                
                if result:
                    pdf_files.append(result)
                else:
                    logger.warning(f"Falha ao converter {md_file.name}")
            
            logger.info(f"Conversão concluída: {len(pdf_files)} PDFs gerados")
            
        except Exception as e:
            logger.error(f"Erro ao converter relatórios: {e}")
        
        return pdf_files


