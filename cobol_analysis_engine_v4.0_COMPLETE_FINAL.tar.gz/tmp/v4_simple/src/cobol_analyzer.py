# -*- coding: utf-8 -*-
"""Módulo de pré-análise COBOL sem IA."""

import re
import logging
from typing import Dict, Any, List, Optional

logger = logging.getLogger(__name__)

class CobolPreAnalyzer:
    """Realiza pré-análise de programas COBOL extraindo informações estruturais."""
    
    def __init__(self):
        self.divisions = ['IDENTIFICATION', 'ENVIRONMENT', 'DATA', 'PROCEDURE']
        
    def analyze(self, program_name: str, cobol_code: str, copybooks: Dict[str, str] = None) -> Dict[str, Any]:
        """
        Realiza análise completa do programa COBOL.
        
        Args:
            program_name: Nome do programa
            cobol_code: Código fonte COBOL
            copybooks: Dicionário com copybooks relacionados
            
        Returns:
            Dict com análise estrutural completa
        """
        logger.info(f"Iniciando pré-análise do programa {program_name}")
        
        analysis = {
            "program_name": program_name,
            "identification": self._analyze_identification(cobol_code),
            "environment": self._analyze_environment(cobol_code),
            "data_division": self._analyze_data_division(cobol_code),
            "procedure_division": self._analyze_procedure_division(cobol_code),
            "comments": self._extract_comments(cobol_code),
            "business_rules": self._extract_business_rules(cobol_code),
            "file_operations": self._extract_file_operations(cobol_code),
            "calculations": self._extract_calculations(cobol_code),
            "validations": self._extract_validations(cobol_code),
            "copybooks_analysis": self._analyze_copybooks(copybooks or {}),
            "complexity_metrics": self._calculate_complexity(cobol_code),
            "summary": {}
        }
        
        # Gera resumo
        analysis["summary"] = self._generate_summary(analysis)
        
        logger.info(f"Pré-análise concluída para {program_name}")
        return analysis
    
    def _analyze_identification(self, code: str) -> Dict[str, Any]:
        """Analisa a IDENTIFICATION DIVISION."""
        identification = {
            "program_id": "",
            "author": "",
            "date_written": "",
            "date_compiled": "",
            "installation": "",
            "remarks": []
        }
        
        lines = code.split('\n')
        in_identification = False
        
        for line in lines:
            line_clean = line.strip()
            line_upper = line_clean.upper()
            
            if 'IDENTIFICATION DIVISION' in line_upper:
                in_identification = True
                continue
            elif any(div in line_upper for div in ['ENVIRONMENT DIVISION', 'DATA DIVISION', 'PROCEDURE DIVISION']):
                in_identification = False
                continue
                
            if in_identification and line_clean:
                if line_upper.startswith('PROGRAM-ID'):
                    identification["program_id"] = self._extract_value_after_dot(line)
                elif line_upper.startswith('AUTHOR'):
                    identification["author"] = self._extract_value_after_dot(line)
                elif line_upper.startswith('DATE-WRITTEN'):
                    identification["date_written"] = self._extract_value_after_dot(line)
                elif line_upper.startswith('DATE-COMPILED'):
                    identification["date_compiled"] = self._extract_value_after_dot(line)
                elif line_upper.startswith('INSTALLATION'):
                    identification["installation"] = self._extract_value_after_dot(line)
                elif line_upper.startswith('REMARKS'):
                    identification["remarks"].append(self._extract_value_after_dot(line))
        
        return identification
    
    def _analyze_environment(self, code: str) -> Dict[str, Any]:
        """Analisa a ENVIRONMENT DIVISION."""
        environment = {
            "configuration_section": {},
            "input_output_section": {
                "file_control": [],
                "io_control": []
            }
        }
        
        lines = code.split('\n')
        in_environment = False
        current_section = None
        
        for line in lines:
            line_clean = line.strip()
            line_upper = line_clean.upper()
            
            if 'ENVIRONMENT DIVISION' in line_upper:
                in_environment = True
                continue
            elif any(div in line_upper for div in ['DATA DIVISION', 'PROCEDURE DIVISION']):
                in_environment = False
                continue
                
            if in_environment and line_clean:
                if 'CONFIGURATION SECTION' in line_upper:
                    current_section = 'configuration'
                elif 'INPUT-OUTPUT SECTION' in line_upper:
                    current_section = 'input_output'
                elif 'FILE-CONTROL' in line_upper:
                    current_section = 'file_control'
                elif line_upper.startswith('SELECT'):
                    file_info = self._parse_select_statement(line)
                    if file_info:
                        environment["input_output_section"]["file_control"].append(file_info)
        
        return environment
    
    def _analyze_data_division(self, code: str) -> Dict[str, Any]:
        """Analisa a DATA DIVISION."""
        data_division = {
            "file_section": [],
            "working_storage_section": [],
            "linkage_section": [],
            "local_storage_section": []
        }
        
        lines = code.split('\n')
        in_data = False
        current_section = None
        
        for line in lines:
            line_clean = line.strip()
            line_upper = line_clean.upper()
            
            if 'DATA DIVISION' in line_upper:
                in_data = True
                continue
            elif 'PROCEDURE DIVISION' in line_upper:
                in_data = False
                continue
                
            if in_data and line_clean:
                if 'FILE SECTION' in line_upper:
                    current_section = 'file_section'
                elif 'WORKING-STORAGE SECTION' in line_upper:
                    current_section = 'working_storage_section'
                elif 'LINKAGE SECTION' in line_upper:
                    current_section = 'linkage_section'
                elif 'LOCAL-STORAGE SECTION' in line_upper:
                    current_section = 'local_storage_section'
                elif re.match(r'^\s*\d+\s+', line):
                    # É uma definição de campo
                    field_info = self._parse_field_definition(line)
                    if field_info and current_section:
                        data_division[current_section].append(field_info)
        
        return data_division
    
    def _analyze_procedure_division(self, code: str) -> Dict[str, Any]:
        """Analisa a PROCEDURE DIVISION."""
        procedure = {
            "paragraphs": [],
            "sections": [],
            "performs": [],
            "calls": [],
            "gotos": []
        }
        
        lines = code.split('\n')
        in_procedure = False
        
        for line in lines:
            line_clean = line.strip()
            line_upper = line_clean.upper()
            
            if 'PROCEDURE DIVISION' in line_upper:
                in_procedure = True
                continue
                
            if in_procedure and line_clean:
                # Identifica parágrafos e seções
                if re.match(r'^[A-Z0-9-]+\s*\.$', line_upper):
                    if 'SECTION' in line_upper:
                        procedure["sections"].append(line_clean.replace('.', '').strip())
                    else:
                        procedure["paragraphs"].append(line_clean.replace('.', '').strip())
                
                # Identifica PERFORMs
                if 'PERFORM' in line_upper:
                    perform_info = self._parse_perform_statement(line)
                    if perform_info:
                        procedure["performs"].append(perform_info)
                
                # Identifica CALLs
                if 'CALL' in line_upper:
                    call_info = self._parse_call_statement(line)
                    if call_info:
                        procedure["calls"].append(call_info)
                
                # Identifica GOTOs
                if 'GO TO' in line_upper or 'GOTO' in line_upper:
                    goto_info = self._parse_goto_statement(line)
                    if goto_info:
                        procedure["gotos"].append(goto_info)
        
        return procedure
    
    def _extract_comments(self, code: str) -> List[Dict[str, Any]]:
        """Extrai todos os comentários do código."""
        comments = []
        lines = code.split('\n')
        
        for i, line in enumerate(lines, 1):
            if line.strip().startswith('*'):
                comment_text = line.strip()[1:].strip()
                if comment_text:  # Ignora linhas vazias
                    comments.append({
                        "line_number": i,
                        "text": comment_text,
                        "type": self._classify_comment(comment_text)
                    })
        
        return comments
    
    def _extract_business_rules(self, code: str) -> List[Dict[str, Any]]:
        """Extrai regras de negócio do código."""
        rules = []
        lines = code.split('\n')
        
        for i, line in enumerate(lines, 1):
            line_clean = line.strip()
            line_upper = line_clean.upper()
            
            # Identifica estruturas condicionais
            if any(keyword in line_upper for keyword in ['IF', 'WHEN', 'EVALUATE']):
                rules.append({
                    "line_number": i,
                    "type": "conditional",
                    "statement": line_clean,
                    "complexity": self._assess_condition_complexity(line_clean)
                })
            
            # Identifica validações
            elif any(keyword in line_upper for keyword in ['VALIDATE', 'CHECK', 'VERIFY']):
                rules.append({
                    "line_number": i,
                    "type": "validation",
                    "statement": line_clean,
                    "field": self._extract_validated_field(line_clean)
                })
        
        return rules
    
    def _extract_file_operations(self, code: str) -> List[Dict[str, Any]]:
        """Extrai operações de arquivo."""
        operations = []
        lines = code.split('\n')
        
        for i, line in enumerate(lines, 1):
            line_clean = line.strip()
            line_upper = line_clean.upper()
            
            for operation in ['OPEN', 'CLOSE', 'READ', 'WRITE', 'REWRITE', 'DELETE']:
                if operation in line_upper:
                    operations.append({
                        "line_number": i,
                        "operation": operation.lower(),
                        "statement": line_clean,
                        "file": self._extract_file_name(line_clean, operation)
                    })
        
        return operations
    
    def _extract_calculations(self, code: str) -> List[Dict[str, Any]]:
        """Extrai cálculos e operações matemáticas."""
        calculations = []
        lines = code.split('\n')
        
        for i, line in enumerate(lines, 1):
            line_clean = line.strip()
            line_upper = line_clean.upper()
            
            for operation in ['COMPUTE', 'ADD', 'SUBTRACT', 'MULTIPLY', 'DIVIDE']:
                if operation in line_upper:
                    calculations.append({
                        "line_number": i,
                        "operation": operation.lower(),
                        "statement": line_clean,
                        "variables": self._extract_calculation_variables(line_clean)
                    })
        
        return calculations
    
    def _extract_validations(self, code: str) -> List[Dict[str, Any]]:
        """Extrai validações de dados."""
        validations = []
        lines = code.split('\n')
        
        for i, line in enumerate(lines, 1):
            line_clean = line.strip()
            line_upper = line_clean.upper()
            
            # Validações explícitas
            if any(keyword in line_upper for keyword in ['VALIDATE', 'CHECK', 'VERIFY', 'INSPECT']):
                validations.append({
                    "line_number": i,
                    "type": "explicit",
                    "statement": line_clean
                })
            
            # Validações implícitas (condições IF com validação)
            elif 'IF' in line_upper and any(op in line_upper for op in ['=', '>', '<', 'NOT', 'EQUAL']):
                if any(keyword in line_upper for keyword in ['SPACE', 'ZERO', 'NULL', 'EMPTY']):
                    validations.append({
                        "line_number": i,
                        "type": "implicit",
                        "statement": line_clean
                    })
        
        return validations
    
    def _analyze_copybooks(self, copybooks: Dict[str, str]) -> Dict[str, Any]:
        """Analisa copybooks relacionados."""
        analysis = {}
        
        for name, content in copybooks.items():
            analysis[name] = {
                "fields": self._extract_copybook_fields(content),
                "size": len(content),
                "lines": len(content.split('\n')),
                "complexity": self._assess_copybook_complexity(content)
            }
        
        return analysis
    
    def _calculate_complexity(self, code: str) -> Dict[str, Any]:
        """Calcula métricas de complexidade."""
        lines = code.split('\n')
        
        metrics = {
            "total_lines": len(lines),
            "code_lines": len([l for l in lines if l.strip() and not l.strip().startswith('*')]),
            "comment_lines": len([l for l in lines if l.strip().startswith('*')]),
            "blank_lines": len([l for l in lines if not l.strip()]),
            "cyclomatic_complexity": self._calculate_cyclomatic_complexity(code),
            "nesting_depth": self._calculate_max_nesting_depth(code),
            "paragraph_count": len(re.findall(r'^[A-Z0-9-]+\s*\.$', code, re.MULTILINE)),
            "perform_count": len(re.findall(r'\bPERFORM\b', code, re.IGNORECASE)),
            "call_count": len(re.findall(r'\bCALL\b', code, re.IGNORECASE))
        }
        
        # Classifica complexidade
        if metrics["cyclomatic_complexity"] <= 5:
            metrics["complexity_level"] = "baixa"
        elif metrics["cyclomatic_complexity"] <= 10:
            metrics["complexity_level"] = "média"
        else:
            metrics["complexity_level"] = "alta"
        
        return metrics
    
    def _generate_summary(self, analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Gera resumo da análise."""
        return {
            "program_type": self._classify_program_type(analysis),
            "main_purpose": self._infer_main_purpose(analysis),
            "key_features": self._identify_key_features(analysis),
            "complexity_assessment": analysis["complexity_metrics"]["complexity_level"],
            "file_count": len(analysis["environment"]["input_output_section"]["file_control"]),
            "copybook_count": len(analysis["copybooks_analysis"]),
            "business_rule_count": len(analysis["business_rules"]),
            "validation_count": len(analysis["validations"])
        }
    
    # Métodos auxiliares
    def _extract_value_after_dot(self, line: str) -> str:
        """Extrai valor após o ponto em uma linha COBOL."""
        if '.' in line:
            return line.split('.', 1)[1].strip()
        return ""
    
    def _parse_select_statement(self, line: str) -> Optional[Dict[str, str]]:
        """Analisa statement SELECT."""
        match = re.search(r'SELECT\s+(\S+)\s+ASSIGN\s+TO\s+(\S+)', line.upper())
        if match:
            return {
                "file_name": match.group(1),
                "assignment": match.group(2),
                "access_mode": self._extract_access_mode(line),
                "organization": self._extract_organization(line)
            }
        return None
    
    def _parse_field_definition(self, line: str) -> Optional[Dict[str, Any]]:
        """Analisa definição de campo."""
        match = re.match(r'^\s*(\d+)\s+([A-Z0-9-]+)(?:\s+PIC\s+([X9V\(\)S]+))?(?:\s+VALUE\s+(.+?))?\.?$', line.upper())
        if match:
            return {
                "level": int(match.group(1)),
                "name": match.group(2),
                "picture": match.group(3) or "",
                "value": match.group(4) or "",
                "type": self._classify_field_type(match.group(3) or "")
            }
        return None
    
    def _classify_comment(self, comment: str) -> str:
        """Classifica tipo de comentário."""
        comment_upper = comment.upper()
        if any(word in comment_upper for word in ['OBJETIVO', 'PURPOSE', 'FINALIDADE']):
            return "objective"
        elif any(word in comment_upper for word in ['AUTOR', 'AUTHOR', 'CRIADO']):
            return "authorship"
        elif any(word in comment_upper for word in ['MODIFICADO', 'ALTERADO', 'CHANGED']):
            return "modification"
        elif any(word in comment_upper for word in ['TODO', 'FIXME', 'BUG']):
            return "todo"
        else:
            return "general"
    
    def _calculate_cyclomatic_complexity(self, code: str) -> int:
        """Calcula complexidade ciclomática."""
        decision_points = len(re.findall(r'\b(IF|WHEN|PERFORM|UNTIL|WHILE)\b', code, re.IGNORECASE))
        return decision_points + 1
    
    def _calculate_max_nesting_depth(self, code: str) -> int:
        """Calcula profundidade máxima de aninhamento."""
        max_depth = 0
        current_depth = 0
        
        for line in code.split('\n'):
            line_upper = line.strip().upper()
            if 'IF' in line_upper or 'PERFORM' in line_upper:
                current_depth += 1
                max_depth = max(max_depth, current_depth)
            elif 'END-IF' in line_upper or 'END-PERFORM' in line_upper:
                current_depth = max(0, current_depth - 1)
        
        return max_depth
    
    def _classify_program_type(self, analysis: Dict[str, Any]) -> str:
        """Classifica o tipo do programa."""
        file_count = len(analysis["environment"]["input_output_section"]["file_control"])
        call_count = analysis["complexity_metrics"]["call_count"]
        
        if file_count > 3:
            return "batch_processing"
        elif call_count > 5:
            return "service_program"
        elif file_count == 0:
            return "utility"
        else:
            return "standard_processing"
    
    def _infer_main_purpose(self, analysis: Dict[str, Any]) -> str:
        """Infere o propósito principal do programa."""
        comments = analysis["comments"]
        
        # Procura por comentários que indiquem o propósito
        for comment in comments:
            if comment["type"] == "objective":
                return comment["text"]
        
        # Inferência baseada na estrutura
        file_ops = analysis["file_operations"]
        calculations = analysis["calculations"]
        
        if len(file_ops) > len(calculations):
            return "Processamento de arquivos e dados"
        elif len(calculations) > 0:
            return "Cálculos e transformações de dados"
        else:
            return "Processamento geral"
    
    def _identify_key_features(self, analysis: Dict[str, Any]) -> List[str]:
        """Identifica características principais."""
        features = []
        
        if analysis["complexity_metrics"]["call_count"] > 0:
            features.append("Chamadas a subprogramas")
        
        if len(analysis["file_operations"]) > 0:
            features.append("Operações de arquivo")
        
        if len(analysis["calculations"]) > 0:
            features.append("Cálculos matemáticos")
        
        if len(analysis["validations"]) > 0:
            features.append("Validações de dados")
        
        if len(analysis["copybooks_analysis"]) > 0:
            features.append("Uso de copybooks")
        
        return features
    
    # Métodos auxiliares adicionais (implementação básica)
    def _extract_access_mode(self, line: str) -> str:
        if 'SEQUENTIAL' in line.upper():
            return 'sequential'
        elif 'RANDOM' in line.upper():
            return 'random'
        elif 'DYNAMIC' in line.upper():
            return 'dynamic'
        return 'sequential'
    
    def _extract_organization(self, line: str) -> str:
        if 'INDEXED' in line.upper():
            return 'indexed'
        elif 'RELATIVE' in line.upper():
            return 'relative'
        return 'sequential'
    
    def _classify_field_type(self, picture: str) -> str:
        if not picture:
            return 'group'
        elif 'X' in picture:
            return 'alphanumeric'
        elif '9' in picture:
            return 'numeric'
        return 'unknown'
    
    def _assess_condition_complexity(self, condition: str) -> str:
        operators = len(re.findall(r'\b(AND|OR|NOT)\b', condition.upper()))
        if operators == 0:
            return 'simple'
        elif operators <= 2:
            return 'medium'
        else:
            return 'complex'
    
    def _extract_validated_field(self, line: str) -> str:
        # Implementação básica - pode ser melhorada
        words = line.split()
        for word in words:
            if word.startswith('WS-') or word.startswith('W-'):
                return word
        return ''
    
    def _extract_file_name(self, line: str, operation: str) -> str:
        # Implementação básica - pode ser melhorada
        words = line.upper().split()
        try:
            op_index = words.index(operation.upper())
            if op_index + 1 < len(words):
                return words[op_index + 1]
        except ValueError:
            pass
        return ''
    
    def _extract_calculation_variables(self, line: str) -> List[str]:
        # Implementação básica - pode ser melhorada
        variables = []
        words = line.split()
        for word in words:
            if word.startswith('WS-') or word.startswith('W-'):
                variables.append(word)
        return variables
    
    def _extract_copybook_fields(self, content: str) -> List[Dict[str, Any]]:
        fields = []
        for line in content.split('\n'):
            field = self._parse_field_definition(line)
            if field:
                fields.append(field)
        return fields
    
    def _assess_copybook_complexity(self, content: str) -> str:
        field_count = len(self._extract_copybook_fields(content))
        if field_count <= 10:
            return 'simple'
        elif field_count <= 30:
            return 'medium'
        else:
            return 'complex'
    
    def _parse_perform_statement(self, line: str) -> Optional[Dict[str, str]]:
        match = re.search(r'PERFORM\s+([A-Z0-9-]+)', line.upper())
        if match:
            return {
                "target": match.group(1),
                "type": "paragraph" if not "SECTION" in line.upper() else "section"
            }
        return None
    
    def _parse_call_statement(self, line: str) -> Optional[Dict[str, str]]:
        match = re.search(r'CALL\s+[\'"]([^\'"]+)[\'"]', line.upper())
        if match:
            return {
                "program": match.group(1),
                "type": "external"
            }
        return None
    
    def _parse_goto_statement(self, line: str) -> Optional[Dict[str, str]]:
        match = re.search(r'GO\s*TO\s+([A-Z0-9-]+)', line.upper())
        if match:
            return {
                "target": match.group(1),
                "type": "unconditional"
            }
        return None
