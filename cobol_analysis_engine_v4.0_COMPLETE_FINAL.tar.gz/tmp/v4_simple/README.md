# COBOL Analysis Engine v4.0

## 1. Visão Geral

O COBOL Analysis Engine v4.0 é uma ferramenta avançada de linha de comando para analisar programas COBOL utilizando múltiplos provedores de LLM. A aplicação oferece suporte robusto a chunking de prompts, retry automático, fallback entre provedores e configuração flexível através de arquivos YAML e variáveis de ambiente.

## 2. Funcionalidades Principais

### 2.1. Múltiplos Provedores de LLM
- **LuzIA** (provedor principal) com suporte a múltiplos modelos
- **OpenAI** como provedor secundário
- **Fallback automático** entre provedores em caso de falha
- **Extensibilidade** para adicionar novos provedores (Databricks, Bedrock)

### 2.2. Gerenciamento Inteligente de Tokens
- **Chunking automático** de prompts grandes
- **Controle de sobreposição** entre chunks
- **Consolidação** de resultados de múltiplos chunks

### 2.3. Robustez e Confiabilidade
- **Retry automático** com backoff exponencial
- **Timeout configurável** para requisições
- **Logging detalhado** para debugging
- **Tratamento de erros** abrangente

### 2.4. Configuração Flexível
- **Arquivo de configuração YAML** para todas as opções
- **Variáveis de ambiente** para credenciais sensíveis
- **Prompts configuráveis** através de templates
- **Habilitação/desabilitação** de provedores individuais

## 3. Estrutura do Projeto

```
/tmp/v4_simple/
├── config/
│   ├── config.yaml           # Configuração principal
│   └── prompts.yaml          # Templates de prompts
├── src/
│   ├── providers/
│   │   ├── __init__.py
│   │   ├── base_provider.py      # Classe base para provedores
│   │   ├── luzia_provider.py     # Provedor LuzIA
│   │   ├── openai_provider.py    # Provedor OpenAI
│   │   └── provider_factory.py   # Factory e gerenciador
│   ├── __init__.py
│   └── parser.py             # Parser de arquivos COBOL
├── .env.example              # Exemplo de variáveis de ambiente
├── main.py                   # Aplicação principal
├── README.md                 # Esta documentação
├── fontes.txt               # Arquivo de exemplo
└── BOOKS.txt                # Arquivo de exemplo
```

## 4. Configuração

### 4.1. Variáveis de Ambiente

Copie o arquivo `.env.example` para `.env` e configure suas credenciais:

```bash
cp .env.example .env
```

Edite o arquivo `.env` com suas credenciais:

```bash
# LuzIA (Provedor Principal)
LUZIA_API_URL=https://api.luzia.com.br
LUZIA_CLIENT_ID=seu_client_id_aqui
LUZIA_CLIENT_SECRET=seu_client_secret_aqui

# OpenAI (Provedor Secundário)
OPENAI_API_KEY=sk-sua_chave_openai_aqui

# Outros provedores (opcionais)
DATABRICKS_WORKSPACE_URL=https://sua-workspace.databricks.com
DATABRICKS_ACCESS_TOKEN=seu_token_databricks_aqui

AWS_ACCESS_KEY_ID=sua_access_key_id_aqui
AWS_SECRET_ACCESS_KEY=sua_secret_access_key_aqui
AWS_REGION=us-east-1
```

### 4.2. Configuração de Provedores

Edite o arquivo `config/config.yaml` para:

- **Habilitar/desabilitar provedores**: Altere `enabled: true/false`
- **Definir prioridades**: Ajuste o campo `priority`
- **Configurar modelos**: Adicione/remova modelos na lista `models`
- **Ajustar limites de tokens**: Modifique `max_tokens_per_request`

### 4.3. Personalização de Prompts

Edite o arquivo `config/prompts.yaml` para customizar os prompts enviados aos LLMs:

```yaml
default_prompt: |
  Seu prompt personalizado aqui...
  
  **PROGRAMA:** {program_name}
  **CÓDIGO COBOL:**
  ```cobol
  {cobol_code}
  ```
  
  Suas instruções específicas...
```

## 5. Como Usar

### 5.1. Instalação de Dependências

```bash
pip install requests pyyaml
```

### 5.2. Configuração das Credenciais

```bash
# Carregue as variáveis de ambiente
source .env

# Ou exporte manualmente
export LUZIA_API_URL="sua_url_aqui"
export LUZIA_CLIENT_ID="seu_client_id_aqui"
export LUZIA_CLIENT_SECRET="seu_client_secret_aqui"
```

### 5.3. Execução Básica

```bash
python3.11 main.py -f fontes.txt -b BOOKS.txt -o reports/
```

### 5.4. Opções Avançadas

```bash
# Usar configuração personalizada
python3.11 main.py -f fontes.txt -b BOOKS.txt -o reports/ --config minha_config.yaml

# Com logging detalhado
LOG_LEVEL=DEBUG python3.11 main.py -f fontes.txt -b BOOKS.txt -o reports/
```

## 6. Funcionalidades Avançadas

### 6.1. Múltiplos Modelos LuzIA

Para usar múltiplos modelos LuzIA simultaneamente, configure no `config.yaml`:

```yaml
analysis:
  use_multiple_models: true
```

### 6.2. Chunking Automático

Para programas grandes, o sistema automaticamente divide o prompt:

```yaml
analysis:
  prompt_chunking:
    enabled: true
    max_chunk_size: 6000
    overlap_size: 200
```

### 6.3. Processamento Paralelo

Configure processamento paralelo de múltiplos programas:

```yaml
analysis:
  parallel_processing:
    enabled: true
    max_workers: 3
```

## 7. Monitoramento e Debugging

### 7.1. Logs Detalhados

Configure o nível de log através da variável de ambiente:

```bash
export LOG_LEVEL=DEBUG  # DEBUG, INFO, WARNING, ERROR
```

### 7.2. Status dos Provedores

O sistema automaticamente verifica e reporta o status de todos os provedores configurados no início da execução.

### 7.3. Relatórios Detalhados

Cada relatório inclui:
- **Metadados** da análise (provedor usado, tempo, tentativas)
- **Resposta completa** da IA
- **Prompt exato** enviado
- **Informações de chunking** (se aplicável)
- **Provedores tentados** em caso de fallback

## 8. Extensibilidade

### 8.1. Adicionando Novos Provedores

1. Crie uma nova classe herdando de `BaseLLMProvider`
2. Implemente os métodos `authenticate()` e `_make_request()`
3. Adicione à `PROVIDER_CLASSES` no `provider_factory.py`
4. Configure no `config.yaml`

### 8.2. Customização de Prompts

- Edite `config/prompts.yaml` para diferentes tipos de análise
- Use variáveis `{program_name}`, `{cobol_code}`, `{copybooks}`
- Adicione novos templates para diferentes cenários

## 9. Solução de Problemas

### 9.1. Problemas de Autenticação

- Verifique se as variáveis de ambiente estão configuradas
- Confirme se as credenciais estão corretas
- Verifique os logs para detalhes do erro

### 9.2. Timeouts

- Aumente o valor de `timeout` no `config.yaml`
- Reduza o `max_chunk_size` para prompts menores
- Verifique a conectividade de rede

### 9.3. Falhas de Análise

- O sistema automaticamente tenta provedores alternativos
- Verifique os logs para identificar o provedor que falhou
- Ajuste as configurações de retry no `config.yaml`

## 10. Próximos Passos

- **Interface Web**: Desenvolvimento de uma interface web para facilitar o uso
- **Cache Inteligente**: Implementação de cache para evitar reprocessamento
- **Métricas Avançadas**: Coleta de métricas de performance e qualidade
- **Integração CI/CD**: Automação para análise contínua de código COBOL
