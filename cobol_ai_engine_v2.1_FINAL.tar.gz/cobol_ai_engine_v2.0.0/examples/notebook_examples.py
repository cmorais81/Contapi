"""
COBOL AI Engine v2.0.0 - Exemplos para Notebooks
Exemplos práticos de uso da API em Jupyter Notebooks.
"""

# ============================================================================
# EXEMPLO 1: ANÁLISE SIMPLES DE CÓDIGO COBOL
# ============================================================================

def exemplo_analise_simples():
    """Exemplo básico de análise de código COBOL."""
    
    # Importar o módulo
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(__file__)))
    import cobol_ai_engine as cae
    
    # Código COBOL de exemplo
    codigo_cobol = '''
    IDENTIFICATION DIVISION.
    PROGRAM-ID. CALCULO-SALARIO.
    
    DATA DIVISION.
    WORKING-STORAGE SECTION.
    01 WS-SALARIO-BASE    PIC 9(6)V99.
    01 WS-BONUS           PIC 9(4)V99.
    01 WS-SALARIO-TOTAL   PIC 9(7)V99.
    
    PROCEDURE DIVISION.
    MAIN-PROCESS.
        MOVE 5000.00 TO WS-SALARIO-BASE
        MOVE 500.00 TO WS-BONUS
        COMPUTE WS-SALARIO-TOTAL = WS-SALARIO-BASE + WS-BONUS
        DISPLAY 'Salário Total: ' WS-SALARIO-TOTAL
        STOP RUN.
    '''
    
    # Analisar o código
    resultado = cae.analyze_cobol(codigo_cobol, provider='enhanced_mock')
    
    # Exibir resultado
    if resultado['success']:
        print("✅ Análise bem-sucedida!")
        print(f"Programa: {resultado['program_name']}")
        print(f"Provedor: {resultado['provider_used']}")
        print("\n📄 DOCUMENTAÇÃO:")
        print("-" * 50)
        print(resultado['documentation'])
    else:
        print(f"❌ Erro: {resultado['error']}")
    
    return resultado


# ============================================================================
# EXEMPLO 2: ANÁLISE DE ARQUIVO
# ============================================================================

def exemplo_analise_arquivo():
    """Exemplo de análise de arquivo COBOL."""
    
    import cobol_ai_engine as cae
    
    # Caminho do arquivo (ajuste conforme necessário)
    arquivo_cobol = "examples/programa_exemplo.cbl"
    
    # Verificar se arquivo existe
    if not os.path.exists(arquivo_cobol):
        print(f"❌ Arquivo não encontrado: {arquivo_cobol}")
        return None
    
    # Analisar arquivo
    resultado = cae.analyze_cobol_file(arquivo_cobol, provider='enhanced_mock')
    
    # Exibir resultado
    if resultado['success']:
        print("✅ Análise de arquivo bem-sucedida!")
        print(f"Arquivo: {arquivo_cobol}")
        print(f"Programa: {resultado['program_name']}")
        print("\n📄 DOCUMENTAÇÃO:")
        print("-" * 50)
        print(resultado['documentation'])
    else:
        print(f"❌ Erro: {resultado['error']}")
    
    return resultado


# ============================================================================
# EXEMPLO 3: USO AVANÇADO COM CLASSE
# ============================================================================

def exemplo_uso_avancado():
    """Exemplo de uso avançado com a classe COBOLAnalyzer."""
    
    import cobol_ai_engine as cae
    
    # Criar analisador
    analyzer = cae.create_analyzer(provider='enhanced_mock')
    
    # Ver provedores disponíveis
    print("🔧 Provedores disponíveis:")
    providers = analyzer.get_available_providers()
    for provider in providers:
        print(f"  • {provider}")
    
    # Ver status dos provedores
    print("\n📊 Status dos provedores:")
    status = analyzer.get_provider_status()
    for name, details in status.get('providers', {}).items():
        available = "✅" if details.get('available', False) else "❌"
        print(f"  {available} {name}")
    
    # Código COBOL mais complexo
    codigo_complexo = '''
    IDENTIFICATION DIVISION.
    PROGRAM-ID. PROCESSAMENTO-VENDAS.
    
    DATA DIVISION.
    FILE SECTION.
    FD ARQUIVO-VENDAS.
    01 REG-VENDA.
        05 CODIGO-PRODUTO    PIC X(10).
        05 QUANTIDADE        PIC 9(5).
        05 PRECO-UNITARIO    PIC 9(6)V99.
    
    WORKING-STORAGE SECTION.
    01 WS-TOTAL-VENDAS      PIC 9(10)V99.
    01 WS-CONTADOR          PIC 9(5).
    01 WS-VALOR-VENDA       PIC 9(8)V99.
    
    PROCEDURE DIVISION.
    MAIN-PROCESS.
        OPEN INPUT ARQUIVO-VENDAS
        MOVE ZERO TO WS-TOTAL-VENDAS
        MOVE ZERO TO WS-CONTADOR
        
        PERFORM UNTIL EOF
            READ ARQUIVO-VENDAS
                AT END
                    SET EOF TO TRUE
                NOT AT END
                    PERFORM PROCESSAR-VENDA
            END-READ
        END-PERFORM
        
        CLOSE ARQUIVO-VENDAS
        
        DISPLAY 'Total de vendas processadas: ' WS-CONTADOR
        DISPLAY 'Valor total das vendas: ' WS-TOTAL-VENDAS
        
        STOP RUN.
    
    PROCESSAR-VENDA.
        COMPUTE WS-VALOR-VENDA = QUANTIDADE * PRECO-UNITARIO
        ADD WS-VALOR-VENDA TO WS-TOTAL-VENDAS
        ADD 1 TO WS-CONTADOR.
    '''
    
    # Analisar código complexo
    resultado = analyzer.analyze_code(codigo_complexo, "PROCESSAMENTO-VENDAS")
    
    if resultado['success']:
        print("\n✅ Análise de código complexo bem-sucedida!")
        print(f"Programa: {resultado['program_name']}")
        print("\n📄 DOCUMENTAÇÃO:")
        print("-" * 50)
        print(resultado['documentation'])
        
        # Mostrar metadados se disponíveis
        metadata = resultado.get('metadata', {})
        if metadata:
            print("\n📊 METADADOS:")
            print("-" * 50)
            for key, value in metadata.items():
                print(f"• {key}: {value}")
    
    return analyzer, resultado


# ============================================================================
# EXEMPLO 4: ANÁLISE DE MÚLTIPLOS ARQUIVOS
# ============================================================================

def exemplo_multiplos_arquivos():
    """Exemplo de análise de múltiplos arquivos."""
    
    import cobol_ai_engine as cae
    
    # Criar analisador
    analyzer = cae.create_analyzer(provider='enhanced_mock')
    
    # Lista de arquivos (ajuste conforme necessário)
    arquivos = [
        "examples/programa1.cbl",
        "examples/programa2.cbl",
        "examples/programa3.cbl"
    ]
    
    # Filtrar apenas arquivos que existem
    arquivos_existentes = [arq for arq in arquivos if os.path.exists(arq)]
    
    if not arquivos_existentes:
        print("❌ Nenhum arquivo de exemplo encontrado.")
        print("Criando arquivos de exemplo...")
        
        # Criar arquivos de exemplo
        os.makedirs("examples", exist_ok=True)
        
        exemplos = {
            "examples/programa1.cbl": '''
IDENTIFICATION DIVISION.
PROGRAM-ID. HELLO-WORLD.
PROCEDURE DIVISION.
DISPLAY 'Hello, World!'.
STOP RUN.
            ''',
            "examples/programa2.cbl": '''
IDENTIFICATION DIVISION.
PROGRAM-ID. CONTADOR.
DATA DIVISION.
WORKING-STORAGE SECTION.
01 WS-CONTADOR PIC 9(3).
PROCEDURE DIVISION.
PERFORM VARYING WS-CONTADOR FROM 1 BY 1 UNTIL WS-CONTADOR > 10
    DISPLAY 'Contador: ' WS-CONTADOR
END-PERFORM.
STOP RUN.
            ''',
            "examples/programa3.cbl": '''
IDENTIFICATION DIVISION.
PROGRAM-ID. CALCULADORA.
DATA DIVISION.
WORKING-STORAGE SECTION.
01 WS-NUM1 PIC 9(3).
01 WS-NUM2 PIC 9(3).
01 WS-RESULTADO PIC 9(5).
PROCEDURE DIVISION.
MOVE 10 TO WS-NUM1.
MOVE 20 TO WS-NUM2.
COMPUTE WS-RESULTADO = WS-NUM1 + WS-NUM2.
DISPLAY 'Resultado: ' WS-RESULTADO.
STOP RUN.
            '''
        }
        
        for arquivo, conteudo in exemplos.items():
            with open(arquivo, 'w', encoding='utf-8') as f:
                f.write(conteudo.strip())
        
        arquivos_existentes = list(exemplos.keys())
    
    # Analisar múltiplos arquivos
    print(f"🔄 Analisando {len(arquivos_existentes)} arquivos...")
    resultados = analyzer.analyze_multiple_files(arquivos_existentes)
    
    # Exibir resumo
    sucessos = sum(1 for r in resultados.values() if r.get('success', False))
    total = len(resultados)
    
    print(f"\n📊 RESUMO DA ANÁLISE:")
    print(f"Total de arquivos: {total}")
    print(f"Análises bem-sucedidas: {sucessos}")
    print(f"Análises com erro: {total - sucessos}")
    
    # Exibir detalhes de cada programa
    print(f"\n📄 DETALHES:")
    print("-" * 60)
    
    for programa, resultado in resultados.items():
        status = "✅" if resultado.get('success') else "❌"
        provider = resultado.get('provider_used', 'N/A')
        
        print(f"\n{status} {programa} (Provedor: {provider})")
        
        if resultado.get('success'):
            doc = resultado.get('documentation', '')
            if doc:
                # Mostrar apenas as primeiras linhas da documentação
                linhas = doc.split('\n')[:3]
                preview = '\n'.join(linhas)
                print(f"   Documentação: {preview}...")
        else:
            print(f"   Erro: {resultado.get('error', 'Erro desconhecido')}")
    
    return resultados


# ============================================================================
# EXEMPLO 5: ANÁLISE DE DIRETÓRIO
# ============================================================================

def exemplo_analise_diretorio():
    """Exemplo de análise de diretório completo."""
    
    import cobol_ai_engine as cae
    
    # Criar analisador
    analyzer = cae.create_analyzer(provider='enhanced_mock')
    
    # Diretório de exemplos
    diretorio = "examples"
    
    # Garantir que o diretório existe com alguns arquivos
    if not os.path.exists(diretorio):
        print("Criando diretório de exemplos...")
        exemplo_multiplos_arquivos()  # Isso criará os arquivos de exemplo
    
    # Analisar diretório
    print(f"🔄 Analisando diretório: {diretorio}")
    resultados = analyzer.analyze_directory(diretorio, extensions=['.cbl', '.cob'])
    
    if not resultados:
        print("❌ Nenhum arquivo COBOL encontrado no diretório.")
        return None
    
    # Exibir resultados
    print(f"\n📊 Encontrados {len(resultados)} programas COBOL:")
    
    for programa, resultado in resultados.items():
        status = "✅" if resultado.get('success') else "❌"
        print(f"  {status} {programa}")
    
    return resultados


# ============================================================================
# EXEMPLO 6: GERAÇÃO DE RELATÓRIO
# ============================================================================

def exemplo_relatorio():
    """Exemplo de geração de relatório consolidado."""
    
    import cobol_ai_engine as cae
    
    # Analisar alguns programas primeiro
    print("🔄 Executando análises para gerar relatório...")
    resultados = exemplo_analise_diretorio()
    
    if not resultados:
        print("❌ Nenhum resultado para gerar relatório.")
        return
    
    # Criar analisador
    analyzer = cae.create_analyzer(provider='enhanced_mock')
    
    # Gerar relatório em Markdown
    relatorio_md = "relatorio_cobol.md"
    print(f"📄 Gerando relatório Markdown: {relatorio_md}")
    
    sucesso_md = analyzer.generate_report(resultados, relatorio_md, format='markdown')
    
    if sucesso_md:
        print(f"✅ Relatório Markdown gerado: {relatorio_md}")
        
        # Mostrar preview do relatório
        with open(relatorio_md, 'r', encoding='utf-8') as f:
            linhas = f.readlines()[:20]  # Primeiras 20 linhas
            print("\n📄 PREVIEW DO RELATÓRIO:")
            print("-" * 50)
            for linha in linhas:
                print(linha.rstrip())
            if len(f.readlines()) > 20:
                print("... (conteúdo truncado)")
    
    # Tentar gerar relatório em PDF
    relatorio_pdf = "relatorio_cobol.pdf"
    print(f"\n📄 Tentando gerar relatório PDF: {relatorio_pdf}")
    
    sucesso_pdf = analyzer.generate_report(resultados, relatorio_pdf, format='pdf')
    
    if sucesso_pdf:
        print(f"✅ Relatório PDF gerado: {relatorio_pdf}")
    else:
        print("❌ Erro ao gerar relatório PDF (WeasyPrint pode não estar disponível)")
    
    return relatorio_md, relatorio_pdf if sucesso_pdf else None


# ============================================================================
# EXEMPLO 7: CONFIGURAÇÃO DE PROVEDORES
# ============================================================================

def exemplo_configuracao_provedores():
    """Exemplo de configuração e troca de provedores."""
    
    import cobol_ai_engine as cae
    
    # Listar provedores disponíveis
    print("🔧 Provedores disponíveis:")
    cae.list_providers()
    
    # Criar analisador com provedor padrão
    analyzer = cae.create_analyzer(provider='enhanced_mock')
    
    print(f"\n📊 Provedor atual: {analyzer.get_current_provider()}")
    
    # Ver status detalhado
    status = analyzer.get_provider_status()
    print(f"Total de provedores: {status.get('total_providers', 0)}")
    print(f"Provedores disponíveis: {status.get('available_providers', 0)}")
    
    # Tentar trocar para OpenAI (se configurado)
    print("\n🔄 Tentando configurar OpenAI...")
    if analyzer.set_provider('openai'):
        print("✅ OpenAI configurado com sucesso!")
        
        # Testar análise com OpenAI
        codigo_teste = '''
        IDENTIFICATION DIVISION.
        PROGRAM-ID. TESTE-OPENAI.
        PROCEDURE DIVISION.
        DISPLAY 'Testando OpenAI'.
        STOP RUN.
        '''
        
        resultado = analyzer.analyze_code(codigo_teste, "TESTE-OPENAI")
        if resultado['success']:
            print("✅ Análise com OpenAI bem-sucedida!")
        else:
            print(f"❌ Erro com OpenAI: {resultado['error']}")
            # Voltar para enhanced_mock
            analyzer.set_provider('enhanced_mock')
            print("🔄 Voltando para enhanced_mock")
    else:
        print("❌ Não foi possível configurar OpenAI (verifique credenciais)")
    
    return analyzer


# ============================================================================
# EXEMPLO 8: WORKFLOW COMPLETO
# ============================================================================

def exemplo_workflow_completo():
    """Exemplo de workflow completo de análise."""
    
    print("🚀 COBOL AI Engine v2.0.0 - Workflow Completo")
    print("=" * 60)
    
    # 1. Configurar ambiente
    print("\n1️⃣ Configurando ambiente...")
    analyzer = exemplo_configuracao_provedores()
    
    # 2. Análise simples
    print("\n2️⃣ Executando análise simples...")
    resultado_simples = exemplo_analise_simples()
    
    # 3. Análise avançada
    print("\n3️⃣ Executando análise avançada...")
    analyzer_avancado, resultado_avancado = exemplo_uso_avancado()
    
    # 4. Análise de múltiplos arquivos
    print("\n4️⃣ Analisando múltiplos arquivos...")
    resultados_multiplos = exemplo_multiplos_arquivos()
    
    # 5. Análise de diretório
    print("\n5️⃣ Analisando diretório...")
    resultados_diretorio = exemplo_analise_diretorio()
    
    # 6. Geração de relatório
    print("\n6️⃣ Gerando relatórios...")
    relatorio_md, relatorio_pdf = exemplo_relatorio()
    
    # 7. Resumo final
    print("\n7️⃣ Resumo final:")
    print("=" * 60)
    print("✅ Workflow completo executado com sucesso!")
    print(f"📄 Relatório Markdown: {relatorio_md}")
    if relatorio_pdf:
        print(f"📄 Relatório PDF: {relatorio_pdf}")
    
    print("\n🎉 Todos os exemplos foram executados!")
    print("Verifique os arquivos gerados no diretório atual.")
    
    return {
        'analyzer': analyzer,
        'resultado_simples': resultado_simples,
        'resultado_avancado': resultado_avancado,
        'resultados_multiplos': resultados_multiplos,
        'resultados_diretorio': resultados_diretorio,
        'relatorio_md': relatorio_md,
        'relatorio_pdf': relatorio_pdf
    }


# ============================================================================
# FUNÇÃO PRINCIPAL PARA NOTEBOOKS
# ============================================================================

def executar_todos_exemplos():
    """Executa todos os exemplos em sequência."""
    
    print("🚀 Executando todos os exemplos do COBOL AI Engine v2.0.0")
    print("=" * 70)
    
    try:
        # Executar workflow completo
        resultados = exemplo_workflow_completo()
        
        print("\n✅ Todos os exemplos foram executados com sucesso!")
        print("\nArquivos gerados:")
        
        # Listar arquivos gerados
        arquivos_gerados = []
        
        if os.path.exists("examples"):
            for arquivo in os.listdir("examples"):
                if arquivo.endswith(('.cbl', '.cob')):
                    arquivos_gerados.append(f"examples/{arquivo}")
        
        if os.path.exists("relatorio_cobol.md"):
            arquivos_gerados.append("relatorio_cobol.md")
        
        if os.path.exists("relatorio_cobol.pdf"):
            arquivos_gerados.append("relatorio_cobol.pdf")
        
        for arquivo in arquivos_gerados:
            print(f"  📄 {arquivo}")
        
        return resultados
        
    except Exception as e:
        print(f"❌ Erro durante execução: {str(e)}")
        return None


# ============================================================================
# INSTRUÇÕES PARA USO EM NOTEBOOK
# ============================================================================

def mostrar_instrucoes_notebook():
    """Mostra instruções para uso em Jupyter Notebook."""
    
    print("""
📓 INSTRUÇÕES PARA USO EM JUPYTER NOTEBOOK
==========================================

1. INSTALAÇÃO E CONFIGURAÇÃO:
   
   # Navegar para o diretório do COBOL AI Engine
   import os
   os.chdir('/caminho/para/cobol_ai_engine_v2.0.0')
   
   # Importar o módulo
   import cobol_ai_engine as cae

2. ANÁLISE SIMPLES:
   
   codigo = '''
   IDENTIFICATION DIVISION.
   PROGRAM-ID. MEU-PROGRAMA.
   PROCEDURE DIVISION.
   DISPLAY 'Hello COBOL!'.
   STOP RUN.
   '''
   
   resultado = cae.analyze_cobol(codigo)
   print(resultado['documentation'])

3. USO AVANÇADO:
   
   analyzer = cae.create_analyzer(provider='enhanced_mock')
   resultado = analyzer.analyze_file('meu_arquivo.cbl')

4. MÚLTIPLOS ARQUIVOS:
   
   resultados = analyzer.analyze_directory('/caminho/cobol/')
   analyzer.generate_report(resultados, 'relatorio.pdf', format='pdf')

5. EXECUTAR TODOS OS EXEMPLOS:
   
   # Execute esta função para ver todos os exemplos
   executar_todos_exemplos()

6. CONFIGURAR PROVEDORES:
   
   # Para usar OpenAI (configure a chave primeiro)
   import os
   os.environ['OPENAI_API_KEY'] = 'sua_chave_aqui'
   analyzer = cae.create_analyzer(provider='openai')

7. AJUDA:
   
   cae.quick_start_guide()  # Mostra guia rápido
   cae.list_providers()     # Lista provedores disponíveis

DICAS:
- Use 'enhanced_mock' para testes (sempre funciona)
- Configure credenciais para provedores reais
- Salve resultados em arquivos para análise posterior
- Use a função executar_todos_exemplos() para ver tudo funcionando
    """)


if __name__ == "__main__":
    # Se executado diretamente, mostrar instruções
    mostrar_instrucoes_notebook()
    
    # Perguntar se quer executar exemplos
    resposta = input("\nDeseja executar todos os exemplos? (s/N): ").strip().lower()
    if resposta in ['s', 'sim', 'y', 'yes']:
        executar_todos_exemplos()

