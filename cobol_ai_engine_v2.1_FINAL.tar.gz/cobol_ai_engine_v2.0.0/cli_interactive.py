#!/usr/bin/env python3
"""
COBOL AI Engine v2.0.0 - CLI Interativo
Interface de linha de comando interativa e amigável.
"""

import os
import sys
import argparse
import json
from pathlib import Path
from typing import List, Dict, Any

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.api.cobol_analyzer import COBOLAnalyzer


class InteractiveCLI:
    """Interface de linha de comando interativa."""
    
    def __init__(self):
        self.analyzer = None
        self.current_provider = "enhanced_mock"
        
    def show_banner(self):
        """Exibe banner do sistema."""
        print("=" * 60)
        print("    COBOL AI Engine v2.0.0 - Interface Interativa")
        print("=" * 60)
        print()
    
    def show_menu(self):
        """Exibe menu principal."""
        print("Opções Disponíveis:")
        print("1. Analisar código COBOL (digitar/colar)")
        print("2. Analisar arquivo COBOL")
        print("3. Analisar múltiplos arquivos")
        print("4. Analisar diretório")
        print("5. Configurar provedor de IA")
        print("6. Ver status dos provedores")
        print("7. Gerar relatório consolidado")
        print("8. Configurações avançadas")
        print("9. Ajuda e exemplos")
        print("0. Sair")
        print()
    
    def initialize_analyzer(self):
        """Inicializa o analisador se necessário."""
        if self.analyzer is None:
            print(f"Inicializando com provedor: {self.current_provider}")
            try:
                self.analyzer = COBOLAnalyzer(provider=self.current_provider)
                print("✅ Analisador inicializado com sucesso!")
            except Exception as e:
                print(f"❌ Erro ao inicializar: {str(e)}")
                return False
        return True
    
    def analyze_code_input(self):
        """Analisa código COBOL digitado pelo usuário."""
        if not self.initialize_analyzer():
            return
        
        print("\n--- Análise de Código COBOL ---")
        print("Digite ou cole seu código COBOL abaixo.")
        print("Para finalizar, digite uma linha contendo apenas 'END' e pressione Enter:")
        print()
        
        lines = []
        while True:
            try:
                line = input()
                if line.strip().upper() == 'END':
                    break
                lines.append(line)
            except KeyboardInterrupt:
                print("\n❌ Operação cancelada.")
                return
        
        if not lines:
            print("❌ Nenhum código fornecido.")
            return
        
        cobol_code = '\n'.join(lines)
        program_name = input("\nNome do programa (opcional): ").strip() or "PROGRAMA_USUARIO"
        
        print(f"\n🔄 Analisando programa '{program_name}'...")
        
        try:
            result = self.analyzer.analyze_code(cobol_code, program_name)
            self.display_analysis_result(result)
        except Exception as e:
            print(f"❌ Erro na análise: {str(e)}")
    
    def analyze_file(self):
        """Analisa arquivo COBOL."""
        if not self.initialize_analyzer():
            return
        
        print("\n--- Análise de Arquivo COBOL ---")
        file_path = input("Caminho do arquivo: ").strip()
        
        if not file_path:
            print("❌ Caminho não fornecido.")
            return
        
        if not os.path.exists(file_path):
            print(f"❌ Arquivo não encontrado: {file_path}")
            return
        
        print(f"🔄 Analisando arquivo '{file_path}'...")
        
        try:
            result = self.analyzer.analyze_file(file_path)
            self.display_analysis_result(result)
        except Exception as e:
            print(f"❌ Erro na análise: {str(e)}")
    
    def analyze_multiple_files(self):
        """Analisa múltiplos arquivos COBOL."""
        if not self.initialize_analyzer():
            return
        
        print("\n--- Análise de Múltiplos Arquivos ---")
        print("Digite os caminhos dos arquivos, um por linha.")
        print("Para finalizar, digite uma linha vazia e pressione Enter:")
        
        file_paths = []
        while True:
            try:
                path = input("Arquivo: ").strip()
                if not path:
                    break
                if os.path.exists(path):
                    file_paths.append(path)
                    print(f"✅ Adicionado: {path}")
                else:
                    print(f"❌ Arquivo não encontrado: {path}")
            except KeyboardInterrupt:
                print("\n❌ Operação cancelada.")
                return
        
        if not file_paths:
            print("❌ Nenhum arquivo válido fornecido.")
            return
        
        print(f"\n🔄 Analisando {len(file_paths)} arquivo(s)...")
        
        try:
            results = self.analyzer.analyze_multiple_files(file_paths)
            self.display_multiple_results(results)
        except Exception as e:
            print(f"❌ Erro na análise: {str(e)}")
    
    def analyze_directory(self):
        """Analisa diretório com arquivos COBOL."""
        if not self.initialize_analyzer():
            return
        
        print("\n--- Análise de Diretório ---")
        dir_path = input("Caminho do diretório: ").strip()
        
        if not dir_path:
            print("❌ Caminho não fornecido.")
            return
        
        if not os.path.isdir(dir_path):
            print(f"❌ Diretório não encontrado: {dir_path}")
            return
        
        # Opções de extensões
        print("\nExtensões de arquivo (padrão: .cbl,.cob,.txt):")
        extensions_input = input("Extensões (separadas por vírgula): ").strip()
        
        if extensions_input:
            extensions = [ext.strip() for ext in extensions_input.split(',')]
            extensions = [ext if ext.startswith('.') else f'.{ext}' for ext in extensions]
        else:
            extensions = ['.cbl', '.cob', '.txt']
        
        print(f"🔄 Analisando diretório '{dir_path}' com extensões: {extensions}")
        
        try:
            results = self.analyzer.analyze_directory(dir_path, extensions)
            if not results:
                print("❌ Nenhum arquivo COBOL encontrado no diretório.")
                return
            
            self.display_multiple_results(results)
        except Exception as e:
            print(f"❌ Erro na análise: {str(e)}")
    
    def configure_provider(self):
        """Configura provedor de IA."""
        print("\n--- Configuração de Provedor ---")
        
        if self.analyzer:
            providers = self.analyzer.get_available_providers()
        else:
            providers = ["enhanced_mock", "basic", "openai", "databricks", "bedrock", "luzia"]
        
        print("Provedores disponíveis:")
        for i, provider in enumerate(providers, 1):
            marker = "✓" if provider == self.current_provider else " "
            print(f"{i}. [{marker}] {provider}")
        
        try:
            choice = input(f"\nEscolha um provedor (1-{len(providers)}): ").strip()
            if not choice.isdigit():
                print("❌ Escolha inválida.")
                return
            
            index = int(choice) - 1
            if 0 <= index < len(providers):
                new_provider = providers[index]
                
                if self.analyzer:
                    success = self.analyzer.set_provider(new_provider)
                    if success:
                        self.current_provider = new_provider
                        print(f"✅ Provedor alterado para: {new_provider}")
                    else:
                        print(f"❌ Erro ao alterar provedor para: {new_provider}")
                else:
                    self.current_provider = new_provider
                    print(f"✅ Provedor configurado para: {new_provider}")
            else:
                print("❌ Escolha inválida.")
                
        except ValueError:
            print("❌ Escolha inválida.")
    
    def show_provider_status(self):
        """Mostra status dos provedores."""
        if not self.initialize_analyzer():
            return
        
        print("\n--- Status dos Provedores ---")
        
        try:
            status = self.analyzer.get_provider_status()
            
            print(f"Total de provedores: {status.get('total_providers', 0)}")
            print(f"Provedores disponíveis: {status.get('available_providers', 0)}")
            print(f"Provedor primário: {status.get('primary_provider', 'N/A')}")
            print()
            
            providers_detail = status.get('providers', {})
            for name, details in providers_detail.items():
                available = "✅" if details.get('available', False) else "❌"
                enabled = "✓" if details.get('enabled', False) else "✗"
                usage = details.get('usage', 0)
                
                print(f"{available} {name}")
                print(f"   Habilitado: {enabled}")
                print(f"   Uso: {usage} análises")
                print()
                
        except Exception as e:
            print(f"❌ Erro ao obter status: {str(e)}")
    
    def generate_report(self):
        """Gera relatório consolidado."""
        print("\n--- Geração de Relatório ---")
        print("Esta função requer resultados de análises anteriores.")
        print("Execute análises primeiro e depois use a API programática para gerar relatórios.")
        print("\nExemplo de uso em notebook:")
        print("""
import cobol_ai_engine as cae

analyzer = cae.create_analyzer()
results = analyzer.analyze_directory('/caminho/para/cobol/')
analyzer.generate_report(results, 'relatorio.pdf', format='pdf')
        """)
    
    def advanced_settings(self):
        """Configurações avançadas."""
        print("\n--- Configurações Avançadas ---")
        print("1. Ver configuração atual")
        print("2. Alterar timeout")
        print("3. Alterar max tokens")
        print("4. Ver logs")
        print("0. Voltar")
        
        choice = input("\nEscolha uma opção: ").strip()
        
        if choice == "1":
            self.show_current_config()
        elif choice == "2":
            self.change_timeout()
        elif choice == "3":
            self.change_max_tokens()
        elif choice == "4":
            self.show_logs()
        elif choice == "0":
            return
        else:
            print("❌ Opção inválida.")
    
    def show_current_config(self):
        """Mostra configuração atual."""
        if not self.initialize_analyzer():
            return
        
        print("\n--- Configuração Atual ---")
        config = self.analyzer.config
        
        print(f"Provedor primário: {config['ai']['primary_provider']}")
        print(f"Fallback habilitado: {config['ai']['enable_fallback']}")
        print(f"Timeout global: {config['ai']['global_timeout']}s")
        print(f"Max tokens: {config['ai']['global_max_tokens']}")
        print(f"Max retries: {config['ai']['max_retries']}")
    
    def change_timeout(self):
        """Altera timeout."""
        if not self.initialize_analyzer():
            return
        
        current = self.analyzer.config['ai']['global_timeout']
        print(f"\nTimeout atual: {current}s")
        
        try:
            new_timeout = input("Novo timeout (segundos): ").strip()
            if new_timeout:
                timeout_value = int(new_timeout)
                if timeout_value > 0:
                    self.analyzer.config['ai']['global_timeout'] = timeout_value
                    print(f"✅ Timeout alterado para: {timeout_value}s")
                else:
                    print("❌ Timeout deve ser maior que 0.")
        except ValueError:
            print("❌ Valor inválido.")
    
    def change_max_tokens(self):
        """Altera max tokens."""
        if not self.initialize_analyzer():
            return
        
        current = self.analyzer.config['ai']['global_max_tokens']
        print(f"\nMax tokens atual: {current}")
        
        try:
            new_tokens = input("Novo max tokens: ").strip()
            if new_tokens:
                tokens_value = int(new_tokens)
                if tokens_value > 0:
                    self.analyzer.config['ai']['global_max_tokens'] = tokens_value
                    print(f"✅ Max tokens alterado para: {tokens_value}")
                else:
                    print("❌ Max tokens deve ser maior que 0.")
        except ValueError:
            print("❌ Valor inválido.")
    
    def show_logs(self):
        """Mostra logs recentes."""
        log_file = "logs/cobol_ai_engine.log"
        
        if os.path.exists(log_file):
            print(f"\n--- Últimas 20 linhas do log ---")
            try:
                with open(log_file, 'r', encoding='utf-8') as f:
                    lines = f.readlines()
                    for line in lines[-20:]:
                        print(line.rstrip())
            except Exception as e:
                print(f"❌ Erro ao ler log: {str(e)}")
        else:
            print("❌ Arquivo de log não encontrado.")
    
    def show_help(self):
        """Mostra ajuda e exemplos."""
        print("\n--- Ajuda e Exemplos ---")
        print("""
COBOL AI Engine v2.0.0 - Guia de Uso

1. ANÁLISE SIMPLES:
   - Escolha opção 1 para digitar código COBOL
   - Cole seu código e digite 'END' para finalizar
   
2. ANÁLISE DE ARQUIVO:
   - Escolha opção 2
   - Digite o caminho completo do arquivo
   
3. PROVEDORES:
   - enhanced_mock: Sempre funciona, para testes
   - openai: Requer OPENAI_API_KEY configurada
   - databricks: Requer credenciais Databricks
   - bedrock: Requer credenciais AWS
   
4. CONFIGURAÇÃO DE CREDENCIAIS:
   export OPENAI_API_KEY="sua_chave_aqui"
   export DATABRICKS_WORKSPACE_URL="sua_url"
   export DATABRICKS_ACCESS_TOKEN="seu_token"
   
5. USO EM NOTEBOOKS:
   import cobol_ai_engine as cae
   resultado = cae.analyze_cobol(codigo_cobol)
   
6. RELATÓRIOS:
   Use a API programática para gerar relatórios PDF
   
Para mais informações, consulte a documentação completa.
        """)
    
    def display_analysis_result(self, result: Dict[str, Any]):
        """Exibe resultado de uma análise."""
        print("\n" + "=" * 60)
        print("RESULTADO DA ANÁLISE")
        print("=" * 60)
        
        if result.get('success'):
            print(f"✅ Programa: {result.get('program_name', 'N/A')}")
            print(f"🤖 Provedor: {result.get('provider_used', 'N/A')}")
            print()
            
            documentation = result.get('documentation', '')
            if documentation:
                print("📄 DOCUMENTAÇÃO:")
                print("-" * 40)
                print(documentation)
            
            metadata = result.get('metadata', {})
            if metadata:
                print("\n📊 METADADOS:")
                print("-" * 40)
                for key, value in metadata.items():
                    print(f"• {key}: {value}")
        else:
            print(f"❌ Erro na análise de '{result.get('program_name', 'N/A')}'")
            print(f"Erro: {result.get('error', 'Erro desconhecido')}")
        
        print("\n" + "=" * 60)
        
        # Opção de salvar
        save = input("\nDeseja salvar o resultado? (s/N): ").strip().lower()
        if save in ['s', 'sim', 'y', 'yes']:
            self.save_result(result)
    
    def display_multiple_results(self, results: Dict[str, Dict[str, Any]]):
        """Exibe resultados de múltiplas análises."""
        print("\n" + "=" * 60)
        print("RESULTADOS DAS ANÁLISES")
        print("=" * 60)
        
        successful = sum(1 for r in results.values() if r.get('success', False))
        total = len(results)
        
        print(f"📊 Total: {total} programas")
        print(f"✅ Sucesso: {successful}")
        print(f"❌ Erro: {total - successful}")
        print()
        
        for program_name, result in results.items():
            status = "✅" if result.get('success') else "❌"
            provider = result.get('provider_used', 'N/A')
            print(f"{status} {program_name} ({provider})")
        
        print("\n" + "=" * 60)
        
        # Opções
        print("\nOpções:")
        print("1. Ver detalhes de um programa")
        print("2. Salvar todos os resultados")
        print("3. Continuar")
        
        choice = input("Escolha uma opção (1-3): ").strip()
        
        if choice == "1":
            self.show_program_details(results)
        elif choice == "2":
            self.save_multiple_results(results)
    
    def show_program_details(self, results: Dict[str, Dict[str, Any]]):
        """Mostra detalhes de um programa específico."""
        programs = list(results.keys())
        
        print("\nProgramas disponíveis:")
        for i, program in enumerate(programs, 1):
            status = "✅" if results[program].get('success') else "❌"
            print(f"{i}. {status} {program}")
        
        try:
            choice = input(f"\nEscolha um programa (1-{len(programs)}): ").strip()
            if choice.isdigit():
                index = int(choice) - 1
                if 0 <= index < len(programs):
                    program_name = programs[index]
                    result = results[program_name]
                    self.display_analysis_result(result)
        except ValueError:
            print("❌ Escolha inválida.")
    
    def save_result(self, result: Dict[str, Any]):
        """Salva resultado individual."""
        program_name = result.get('program_name', 'programa')
        filename = f"{program_name}_analise.md"
        
        try:
            content = self._format_result_for_save(result)
            with open(filename, 'w', encoding='utf-8') as f:
                f.write(content)
            print(f"✅ Resultado salvo em: {filename}")
        except Exception as e:
            print(f"❌ Erro ao salvar: {str(e)}")
    
    def save_multiple_results(self, results: Dict[str, Dict[str, Any]]):
        """Salva múltiplos resultados."""
        filename = "analise_multipla.md"
        
        try:
            content = self._format_multiple_results_for_save(results)
            with open(filename, 'w', encoding='utf-8') as f:
                f.write(content)
            print(f"✅ Resultados salvos em: {filename}")
        except Exception as e:
            print(f"❌ Erro ao salvar: {str(e)}")
    
    def _format_result_for_save(self, result: Dict[str, Any]) -> str:
        """Formata resultado para salvamento."""
        from datetime import datetime
        
        content = []
        content.append(f"# Análise COBOL - {result.get('program_name', 'N/A')}")
        content.append(f"\n**Data:** {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}")
        content.append(f"**Provedor:** {result.get('provider_used', 'N/A')}")
        content.append(f"**Status:** {'✅ Sucesso' if result.get('success') else '❌ Erro'}")
        
        if result.get('success'):
            documentation = result.get('documentation', '')
            if documentation:
                content.append("\n## Documentação")
                content.append(documentation)
            
            metadata = result.get('metadata', {})
            if metadata:
                content.append("\n## Metadados")
                for key, value in metadata.items():
                    content.append(f"- **{key}:** {value}")
        else:
            content.append(f"\n## Erro")
            content.append(result.get('error', 'Erro desconhecido'))
        
        return "\n".join(content)
    
    def _format_multiple_results_for_save(self, results: Dict[str, Dict[str, Any]]) -> str:
        """Formata múltiplos resultados para salvamento."""
        from datetime import datetime
        
        content = []
        content.append("# Análise COBOL - Múltiplos Programas")
        content.append(f"\n**Data:** {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}")
        content.append(f"**Total de Programas:** {len(results)}")
        
        successful = sum(1 for r in results.values() if r.get('success', False))
        content.append(f"**Análises Bem-sucedidas:** {successful}")
        content.append(f"**Análises com Erro:** {len(results) - successful}")
        
        content.append("\n---\n")
        
        for program_name, result in results.items():
            content.append(f"## {program_name}")
            
            if result.get('success'):
                content.append(f"**Status:** ✅ Sucesso")
                content.append(f"**Provedor:** {result.get('provider_used', 'N/A')}")
                
                documentation = result.get('documentation', '')
                if documentation:
                    content.append("\n### Documentação")
                    content.append(documentation)
            else:
                content.append(f"**Status:** ❌ Erro")
                content.append(f"**Erro:** {result.get('error', 'Erro desconhecido')}")
            
            content.append("\n---\n")
        
        return "\n".join(content)
    
    def run(self):
        """Executa o CLI interativo."""
        self.show_banner()
        
        while True:
            try:
                self.show_menu()
                choice = input("Escolha uma opção (0-9): ").strip()
                
                if choice == "0":
                    print("\n👋 Obrigado por usar o COBOL AI Engine!")
                    break
                elif choice == "1":
                    self.analyze_code_input()
                elif choice == "2":
                    self.analyze_file()
                elif choice == "3":
                    self.analyze_multiple_files()
                elif choice == "4":
                    self.analyze_directory()
                elif choice == "5":
                    self.configure_provider()
                elif choice == "6":
                    self.show_provider_status()
                elif choice == "7":
                    self.generate_report()
                elif choice == "8":
                    self.advanced_settings()
                elif choice == "9":
                    self.show_help()
                else:
                    print("❌ Opção inválida. Tente novamente.")
                
                input("\nPressione Enter para continuar...")
                print("\n" + "=" * 60 + "\n")
                
            except KeyboardInterrupt:
                print("\n\n👋 Saindo do COBOL AI Engine...")
                break
            except Exception as e:
                print(f"\n❌ Erro inesperado: {str(e)}")
                input("Pressione Enter para continuar...")


def main():
    """Função principal."""
    parser = argparse.ArgumentParser(
        description="COBOL AI Engine v2.0.0 - CLI Interativo",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    parser.add_argument(
        '--provider', 
        default='enhanced_mock',
        help='Provedor de IA inicial (padrão: enhanced_mock)'
    )
    
    args = parser.parse_args()
    
    cli = InteractiveCLI()
    cli.current_provider = args.provider
    cli.run()


if __name__ == "__main__":
    main()

