# COBOL to Docs v1.0

Sistema de análise profissional de programas COBOL.

## Uso

```bash
# Análise básica
python main.py --fontes programa.cbl --output resultado

# Múltiplos arquivos
python main.py --fontes "*.cbl" --output analises

# Com copybooks
python main.py --fontes programa.cbl --books copybooks.txt --output resultado
```

## Características

- Análise profissional aprofundada por padrão
- Extração de funcionalidades específicas
- Identificação de regras de negócio concretas
- Mapeamento de estruturas técnicas
- Linguagem profissional (nível sênior)

## Exemplo

```bash
python main.py --fontes examples/LHAN0542.cbl --output teste
```

Resultado: `teste/LHAN0542_analise_funcional.md`
