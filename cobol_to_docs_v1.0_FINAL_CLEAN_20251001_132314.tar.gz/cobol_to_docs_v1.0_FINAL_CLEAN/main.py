#!/usr/bin/env python3
"""
COBOL to Docs v1.0 - Sistema de Análise Profissional
"""

import os
import sys
import argparse
import logging
from datetime import datetime
from pathlib import Path

def setup_logging(verbose: bool = False):
    """Configura logging"""
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(level=level, format='%(asctime)s - %(levelname)s - %(message)s')
    return logging.getLogger(__name__)

def parse_arguments():
    """Parse argumentos"""
    parser = argparse.ArgumentParser(description='COBOL to Docs v1.0 - Análise Profissional')
    
    parser.add_argument('--fontes', required=True, help='Arquivo(s) COBOL para análise')
    parser.add_argument('--books', help='Arquivo com lista de copybooks (opcional)')
    parser.add_argument('--models', default='enhanced_mock', help='Modelo de IA (padrão: enhanced_mock)')
    parser.add_argument('--output', default='analise_resultado', help='Diretório de saída')
    parser.add_argument('--pdf', action='store_true', help='Gerar PDF')
    parser.add_argument('--verbose', '-v', action='store_true', help='Modo verboso')
    
    return parser.parse_args()

def load_cobol_files(fontes_pattern: str) -> list:
    """Carrega arquivos COBOL"""
    import glob
    
    if '*' in fontes_pattern or '?' in fontes_pattern:
        files = glob.glob(fontes_pattern)
    else:
        files = [fontes_pattern] if os.path.exists(fontes_pattern) else []
    
    if not files:
        raise FileNotFoundError(f"Nenhum arquivo encontrado: {fontes_pattern}")
    
    return sorted(files)

def analyze_cobol_professional(program_content: str, program_name: str) -> str:
    """Análise profissional de programa COBOL"""
    
    lines = program_content.split('\n')
    
    # Extrair elementos técnicos
    file_operations = []
    business_rules = []
    data_structures = []
    procedures = []
    copybooks = []
    validations = []
    calculations = []
    
    for i, line in enumerate(lines, 1):
        line_upper = line.upper().strip()
        
        # File operations
        if 'SELECT ' in line_upper and 'ASSIGN' in line_upper:
            import re
            match = re.search(r'SELECT\s+(\S+)\s+ASSIGN\s+TO\s+"([^"]+)"', line_upper)
            if match:
                file_operations.append(f"- {match.group(1)}: {match.group(2)}")
        
        # Business rules
        if 'IF ' in line_upper:
            if any(inst in line_upper for inst in ['"0033"', '"1508"', '"BNDS"']):
                business_rules.append(f"- Linha {i}: {line.strip()}")
            elif any(term in line_upper for term in ['LIMITE', 'MAXIMO', 'CAPACIDADE']):
                business_rules.append(f"- Linha {i}: {line.strip()}")
        
        # Data structures
        if line.strip().startswith('FD '):
            data_structures.append(f"- {line.strip().split()[1].rstrip('.')}")
        elif line.strip().startswith('01 '):
            data_structures.append(f"- {line.strip().split()[1].rstrip('.')}")
        
        # Procedures
        if line.strip() and line.strip()[0].isdigit() and '-' in line.strip():
            proc_name = line.strip().split('.')[0]
            procedures.append(f"- {proc_name}")
        
        # Copybooks
        if 'COPY ' in line_upper:
            import re
            match = re.search(r'COPY\s+(\S+)', line_upper)
            if match:
                copybook = match.group(1).rstrip('.')
                copybooks.append(f"- {copybook}")
        
        # Validations
        if 'NOT NUMERIC' in line_upper or 'NOT =' in line_upper:
            validations.append(f"- Linha {i}: {line.strip()}")
        
        # Calculations
        if 'ADD ' in line_upper or 'COMPUTE ' in line_upper:
            calculations.append(f"- Linha {i}: {line.strip()}")
    
    # Gerar análise profissional
    analysis = f"""# {program_name} - Análise Técnica

## Funcionalidades Implementadas

**Gestão de Arquivos:**
{chr(10).join(file_operations[:10]) if file_operations else "- Nenhuma operação de arquivo identificada"}

**Procedimentos Principais:**
{chr(10).join(procedures[:10]) if procedures else "- Nenhum procedimento identificado"}

## Regras de Negócio

**Regras Institucionais:**
{chr(10).join(business_rules[:10]) if business_rules else "- Nenhuma regra institucional identificada"}

## Estruturas de Dados

**Descritores e Registros:**
{chr(10).join(data_structures[:15]) if data_structures else "- Nenhuma estrutura identificada"}

## Integrações

**Copybooks:**
{chr(10).join(copybooks[:10]) if copybooks else "- Nenhum copybook identificado"}

## Controles e Validações

**Validações Implementadas:**
{chr(10).join(validations[:10]) if validations else "- Nenhuma validação identificada"}

## Algoritmos

**Cálculos e Processamento:**
{chr(10).join(calculations[:10]) if calculations else "- Nenhum cálculo identificado"}

---

**Análise gerada em:** {datetime.now().strftime('%d/%m/%Y às %H:%M:%S')}  
**Modelo:** enhanced_mock  
**Tipo:** Análise Profissional Aprofundada
"""
    
    return analysis

def main():
    """Função principal"""
    try:
        args = parse_arguments()
        logger = setup_logging(args.verbose)
        
        logger.info("=== COBOL to Docs v1.0 - Análise Profissional ===")
        
        # Carregar arquivos COBOL
        cobol_files = load_cobol_files(args.fontes)
        logger.info(f"Arquivos encontrados: {len(cobol_files)}")
        
        # Criar diretório de saída
        output_dir = Path(args.output)
        output_dir.mkdir(parents=True, exist_ok=True)
        
        # Processar cada arquivo
        for cobol_file in cobol_files:
            logger.info(f"Processando: {cobol_file}")
            
            try:
                # Ler arquivo
                with open(cobol_file, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                
                # Análise profissional
                program_name = Path(cobol_file).stem
                analysis = analyze_cobol_professional(content, program_name)
                
                # Salvar análise
                output_file = output_dir / f"{program_name}_analise_funcional.md"
                with open(output_file, 'w', encoding='utf-8') as f:
                    f.write(analysis)
                
                logger.info(f"Análise gerada: {output_file}")
                
                # Criar diretórios de auditoria
                requests_dir = output_dir / "ai_requests"
                responses_dir = output_dir / "ai_responses"
                requests_dir.mkdir(exist_ok=True)
                responses_dir.mkdir(exist_ok=True)
                
                # Salvar request
                request_data = {
                    "program_name": program_name,
                    "model": "enhanced_mock",
                    "timestamp": datetime.now().isoformat(),
                    "program_content": content[:1000] + "..." if len(content) > 1000 else content
                }
                
                import json
                with open(requests_dir / f"{program_name}_ai_request.json", 'w', encoding='utf-8') as f:
                    json.dump(request_data, f, indent=2, ensure_ascii=False)
                
                # Salvar response
                response_data = {
                    "program_name": program_name,
                    "model": "enhanced_mock",
                    "timestamp": datetime.now().isoformat(),
                    "analysis": analysis,
                    "success": True,
                    "tokens_used": len(analysis.split()),
                    "analysis_type": "professional_deep"
                }
                
                with open(responses_dir / f"{program_name}_ai_response.json", 'w', encoding='utf-8') as f:
                    json.dump(response_data, f, indent=2, ensure_ascii=False)
                
            except Exception as e:
                logger.error(f"Erro ao processar {cobol_file}: {e}")
                continue
        
        logger.info("=== Análise concluída ===")
        logger.info(f"Resultados em: {output_dir}")
        
    except Exception as e:
        print(f"Erro: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
