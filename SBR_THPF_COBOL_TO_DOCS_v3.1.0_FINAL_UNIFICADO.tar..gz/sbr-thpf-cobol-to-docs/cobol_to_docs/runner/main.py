#!/usr/bin/env python3
"""
COBOL to Docs v3.1.0 - Sistema de Análise e Documentação de Programas COBOL
Autor: Carlos Morais
Data: Setembro 2025

Sistema completo para análise automatizada de programas COBOL com geração
de documentação técnica profissional usando IA.

FUNCIONALIDADE COMPLETA RESTAURADA:
- Processamento de múltiplos programas COBOL
- Suporte a múltiplos modelos de IA
- Análise de copybooks complementares
- Geração de relatórios comparativos
- Detecção automática de código COBOL
"""

import argparse
import logging
import os
import sys
import json
import time
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple

# Adicionar src ao path
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(current_dir)
src_dir = os.path.join(project_root, 'src')
sys.path.insert(0, project_root)

from src.core.config import ConfigManager
from src.core.prompt_manager_dual import DualPromptManager
from src.providers.enhanced_provider_manager import EnhancedProviderManager
from src.parsers.cobol_parser_original import COBOLParser, CobolProgram, CobolBook
from src.analyzers.enhanced_cobol_analyzer import EnhancedCOBOLAnalyzer
from src.analyzers.consolidated_analyzer import ConsolidatedAnalyzer
from src.generators.documentation_generator import DocumentationGenerator
from src.utils.html_generator import HTMLReportGenerator
from src.utils.cost_calculator import CostCalculator
from src.rag.rag_integration import RAGIntegration
from src.core.intelligent_model_selector import IntelligentModelSelector
from src.analytics.consolidated_analysis import (
    process_advanced_consolidated_analysis,
    process_detailed_business_analysis
)

def setup_logging(log_level: str = "INFO") -> None:
    """Configura o sistema de logging."""
    log_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "logs")
    os.makedirs(log_dir, exist_ok=True)
    
    log_file = os.path.join(log_dir, f"cobol_to_docs_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
    
    logging.basicConfig(
        level=getattr(logging, log_level.upper()),
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file, encoding='utf-8'),
            logging.StreamHandler(sys.stdout)
        ]
    )

def parse_models_argument(models_str: str) -> List[str]:
    """Parse do argumento models que pode ser string ou lista JSON."""
    if not models_str:
        return []
    
    models_str = models_str.strip()
    
    # Se começa com [ é uma lista JSON
    if models_str.startswith('['):
        try:
            models = json.loads(models_str)
            return models if isinstance(models, list) else [models]
        except json.JSONDecodeError:
            print(f"Erro: Formato JSON inválido para models: {models_str}")
            sys.exit(1)
    else:
        # String simples
        return [models_str]

def main():
    """Função principal do sistema."""
    parser = argparse.ArgumentParser(
        description="COBOL to Docs v3.1.0 - Análise automatizada de código COBOL",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Exemplos de uso:
  %(prog)s --fontes programas.txt --models luzia
  %(prog)s --fontes programas.txt --books copybooks.txt --models enhanced_mock
  %(prog)s --fontes programas.txt --consolidado --models luzia
  %(prog)s --status
        """
    )
    
    # Argumentos principais
    parser.add_argument("--fontes", help="Arquivo com lista de programas COBOL ou código COBOL direto")
    parser.add_argument("--books", help="Arquivo com lista de copybooks")
    parser.add_argument("--models", help="Modelo(s) de IA a usar (string ou JSON array)")
    parser.add_argument("--output", default="output", help="Diretório de saída (padrão: output)")
    
    # Modos de análise
    parser.add_argument("--consolidado", action="store_true", help="Análise consolidada sistêmica")
    parser.add_argument("--relatorio-unico", action="store_true", help="Relatório único consolidado")
    parser.add_argument("--analise-especialista", action="store_true", help="Análise especializada")
    parser.add_argument("--procedure-detalhada", action="store_true", help="Análise detalhada da PROCEDURE DIVISION")
    parser.add_argument("--modernizacao", action="store_true", help="Análise para modernização")
    
    # Configurações
    parser.add_argument("--prompt-set", default="original", help="Conjunto de prompts a usar")
    parser.add_argument("--no-comments", action="store_true", help="Remover comentários do código")
    parser.add_argument("--pdf", action="store_true", help="Gerar relatórios HTML/PDF")
    parser.add_argument("--log-level", default="INFO", help="Nível de logging")
    
    # Utilitários
    parser.add_argument("--status", action="store_true", help="Verificar status do sistema")
    parser.add_argument("--init", action="store_true", help="Inicializar configuração local")
    
    args = parser.parse_args()
    
    # Configurar logging
    setup_logging(args.log_level)
    logger = logging.getLogger(__name__)
    
    try:
        # Verificar status do sistema
        if args.status:
            print("COBOL to Docs v3.1.0 - Status do Sistema")
            print("=" * 50)
            
            # Verificar configuração
            config_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config", "config.yaml")
            if os.path.exists(config_path):
                print("✓ Configuração encontrada")
                config_manager = ConfigManager(config_path)
                
                # Verificar providers
                providers_config = config_manager.config.get('providers', {})
                for provider_name, provider_config in providers_config.items():
                    if provider_config.get('enabled', False):
                        print(f"✓ Provider {provider_name}: Habilitado")
                    else:
                        print(f"- Provider {provider_name}: Desabilitado")
            else:
                print("✗ Configuração não encontrada")
            
            print("Sistema pronto para uso")
            return
        
        # Inicializar configuração local
        if args.init:
            print("Inicializando configuração local...")
            # Criar diretórios necessários
            base_dir = os.path.dirname(os.path.dirname(__file__))
            for dir_name in ["logs", "output", "temp"]:
                dir_path = os.path.join(base_dir, dir_name)
                os.makedirs(dir_path, exist_ok=True)
                print(f"✓ Diretório criado: {dir_path}")
            
            print("✓ Configuração local inicializada com sucesso!")
            print("Para começar a usar:")
            print("1. Configure suas credenciais de IA no arquivo config/config.yaml")
            print("2. Execute: python runner/main.py --fontes seus_programas.txt --models luzia")
            return
        
        # Inicializar componentes
        config_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config", "config.yaml")
        config_manager = ConfigManager(config_path)
        cost_calculator = CostCalculator()
        
        # Inicializar RAG
        rag_integration = RAGIntegration(config_manager.config)
        if rag_integration.is_enabled():
            logger.info("Sistema RAG inicializado e ativo")
        else:
            logger.info("Sistema RAG desabilitado ou indisponível")
        
        # Validar argumentos
        if not args.fontes:
            print("Erro: --fontes é obrigatório")
            parser.print_help()
            return
        
        if not os.path.exists(args.fontes):
            print(f"Erro: Arquivo não encontrado: {args.fontes}")
            return
        
        # Processar arquivos COBOL
        from src.core.main_processor import process_cobol_files
        process_cobol_files(args, config_manager, cost_calculator, rag_integration)
        
        # Finalizar sessão RAG e gerar relatório
        if rag_integration.is_enabled():
            try:
                rag_report = rag_integration.finalize_session()
                if rag_report:
                    logger.info(f"Relatório de uso do RAG gerado: {rag_report}")
                    print(f"\n=== RELATÓRIO RAG DISPONÍVEL ===")
                    print(f"Arquivo: {rag_report}")
                    
                    # Exibir resumo da sessão
                    session_summary = rag_integration.get_session_summary()
                    if session_summary:
                        print(f"Operações RAG realizadas: {session_summary.get('total_operations', 0)}")
                        print(f"Programas analisados: {len(session_summary.get('programs_analyzed', []))}")
                        print(f"Itens de conhecimento utilizados: {session_summary.get('knowledge_items_used', 0)}")
                        print("=" * 40)
            except Exception as e:
                logger.warning(f"Erro ao finalizar sessão RAG: {e}")
        
    except KeyboardInterrupt:
        print("\nProcessamento interrompido pelo usuário.")
    except Exception as e:
        import traceback
        logger.error(f"Erro fatal: {str(e)}")
        logger.error(f"Traceback: {traceback.format_exc()}")
        print(f"Erro: {str(e)}")
        print("Traceback completo:")
        traceback.print_exc()

if __name__ == "__main__":
    main()
