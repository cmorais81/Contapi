"""
COBOL AI Engine v3.0.0 - Main Processor
Processador principal para análise de arquivos COBOL
"""

import logging
import os
import time
from typing import List, Dict, Any, Optional

from .config import ConfigManager
from .prompt_manager_dual import DualPromptManager
from ..providers.enhanced_provider_manager import EnhancedProviderManager
from ..parsers.cobol_parser_original import COBOLParser, CobolProgram, CobolBook
from ..analyzers.enhanced_cobol_analyzer import EnhancedCOBOLAnalyzer
from ..analyzers.consolidated_analyzer import ConsolidatedAnalyzer
from ..generators.documentation_generator import DocumentationGenerator
from ..utils.html_generator import HTMLReportGenerator
from ..utils.cost_calculator import CostCalculator
from ..rag.rag_integration import RAGIntegration
from .intelligent_model_selector import IntelligentModelSelector


def process_cobol_files(args, config_manager: ConfigManager, cost_calculator: CostCalculator, rag_integration) -> None:
    """Processa arquivos COBOL com funcionalidade completa restaurada."""
    logger = logging.getLogger(__name__)
    
    # Inicializar seletor inteligente de modelos
    model_selector = IntelligentModelSelector()
    
    # Determinar modelos a usar
    if hasattr(args, 'models') and args.models:
        models = parse_models_argument(args.models)
        logger.info(f"Modelos especificados pelo usuário: {models}")
    else:
        # Obter modelos dos providers configurados
        models = get_models_from_providers(config_manager)
        logger.info(f"Modelos obtidos dos providers: {models}")
    
    # Inicializar parser
    parser = COBOLParser()
    
    # Verificar modo de operação
    if args.consolidado:
        logger.info("=== MODO ANÁLISE CONSOLIDADA SISTÊMICA ===")
        process_consolidated_analysis(args, config_manager, cost_calculator, parser, models, rag_integration)
        return
    
    if args.relatorio_unico:
        logger.info("=== MODO RELATÓRIO ÚNICO CONSOLIDADO ===")
        process_consolidated_report(args, config_manager, cost_calculator, parser, models)
        return
    
    # Verificar se deve usar análise especializada
    if args.analise_especialista or args.procedure_detalhada or args.modernizacao:
        logger.info("=== MODO ANÁLISE ESPECIALIZADA ===")
        process_expert_analysis(args, config_manager, cost_calculator, parser, models)
        return
    
    # Processamento padrão
    logger.info("=== MODO ANÁLISE PADRÃO ===")
    process_standard_analysis(args, config_manager, cost_calculator, parser, models, rag_integration)


def parse_models_argument(models_str: str) -> List[str]:
    """Parse do argumento models que pode ser string ou lista JSON."""
    import json
    
    if not models_str:
        return []
    
    models_str = models_str.strip()
    
    # Se começa com [ é uma lista JSON
    if models_str.startswith('['):
        try:
            models = json.loads(models_str)
            return models if isinstance(models, list) else [models]
        except json.JSONDecodeError:
            print(f"Erro: Formato JSON inválido para models: {models_str}")
            return []
    else:
        # String simples
        return [models_str]


def get_models_from_providers(config_manager: ConfigManager) -> List[str]:
    """Obtém lista de modelos dos providers configurados."""
    models = []
    providers_config = config_manager.config.get('providers', {})
    
    # Iterar pelos providers habilitados
    for provider_name, provider_config in providers_config.items():
        if provider_config.get('enabled', False):
            provider_models = provider_config.get('models', {})
            
            # Adicionar modelos do provider
            for model_key, model_config in provider_models.items():
                model_name = model_config.get('name')
                if model_name:
                    models.append(model_name)
    
    # Se nenhum modelo encontrado, usar fallback
    if not models:
        logger = logging.getLogger(__name__)
        logger.warning("Nenhum modelo encontrado nos providers, usando fallback")
        models = ['enhanced_mock']  # Fallback seguro
    
    return models


def process_standard_analysis(args, config_manager, cost_calculator, parser, models, rag_integration):
    """Processa análise padrão de programas COBOL."""
    logger = logging.getLogger(__name__)
    
    logger.info(f"Modelos selecionados: {models}")
    logger.info(f"Arquivo de fontes: {args.fontes}")
    logger.info(f"Diretório de saída: {args.output}")
    
    start_time = time.time()
    
    # Criar diretório de saída
    os.makedirs(args.output, exist_ok=True)
    
    # Carregar programas COBOL
    logger.info("Carregando programas COBOL...")
    programs, _ = parser.parse_file(args.fontes)
    logger.info(f"Programas carregados: {len(programs)}")
    
    # Carregar copybooks se especificado
    books = []
    if args.books:
        logger.info("Carregando copybooks...")
        _, books_result = parser.parse_file(args.books)
        books = books_result
        logger.info(f"Copybooks carregados: {len(books)}")
    
    # Processar cada programa
    all_results = []
    successful_analyses = 0
    total_tokens = 0
    total_cost = 0.0
    
    is_multi_model = len(models) > 1
    
    for program in programs:
        for model in models:
            logger.info(f"Analisando {program.name} com {model}")
            
            result = analyze_program_with_model(
                program, books, model, args.output, config_manager, 
                is_multi_model, args.prompt_set, cost_calculator, 
                rag_integration, args
            )
            
            all_results.append(result)
            
            if result['success']:
                successful_analyses += 1
                total_tokens += result['tokens_used']
                total_cost += cost_calculator.calculate_cost(model, result['tokens_used'])
    
    # Gerar relatório de custos
    cost_report = cost_calculator.format_cost_report()
    cost_report_file = os.path.join(args.output, "relatorio_custos.txt")
    with open(cost_report_file, 'w', encoding='utf-8') as f:
        f.write(cost_report)
    
    # Gerar relatório comparativo se multi-modelo
    if is_multi_model:
        generate_comparative_report(programs, all_results, args.output)
    
    # Estatísticas finais
    total_time = time.time() - start_time
    total_analyses = len(programs) * len(models)
    success_rate = (successful_analyses / total_analyses) * 100 if total_analyses > 0 else 0
    
    print("=" * 60)
    print("PROCESSAMENTO CONCLUÍDO")
    print(f"Programas processados: {len(programs)}")
    print(f"Modelos utilizados: {len(models)} ({', '.join(models)})")
    print(f"Análises bem-sucedidas: {successful_analyses}/{total_analyses}")
    print(f"Taxa de sucesso geral: {success_rate:.1f}%")
    print(f"Total de tokens utilizados: {total_tokens:,}")
    print(f"Custo total: ${total_cost:.4f}")
    print(f"Tempo total de processamento: {total_time:.2f}s")
    print(f"Documentação gerada em: {args.output}")
    print("=" * 60)


def analyze_program_with_model(program, books, model, output_dir, config_manager, 
                             is_multi_model, prompt_set, cost_calculator, 
                             rag_integration=None, args=None):
    """Analisa um programa COBOL com um modelo específico."""
    logger = logging.getLogger(__name__)
    
    # Criar diretório específico do modelo se multi-modelo
    if is_multi_model:
        model_output_dir = os.path.join(output_dir, f"model_{model.replace('/', '_').replace('-', '_')}")
        os.makedirs(model_output_dir, exist_ok=True)
    else:
        model_output_dir = output_dir
    
    try:
        # Inicializar componentes específicos para o modelo
        prompt_manager = DualPromptManager(config_manager.config, prompt_set)
        provider_manager = EnhancedProviderManager(config_manager.config)
        doc_generator = DocumentationGenerator(model_output_dir)
        
        # Inicializar analisador
        analyzer = EnhancedCOBOLAnalyzer(provider_manager, prompt_manager, rag_integration)
        
        start_time = time.time()
        
        # Log do provider que será usado
        logger.info(f"*** PROVIDER SELECIONADO: {model} ***")
        logger.info(f"Iniciando análise de {program.name} com provider {model}")
        
        analysis_result = analyzer.analyze_program(program, model)
        analysis_time = time.time() - start_time
        
        if not analysis_result.success:
            error_msg = f"ERRO na análise de {program.name} com modelo {model}: {analysis_result.error_message}"
            logger.error(error_msg)
            return {
                'success': False,
                'program_name': program.name,
                'model': model,
                'error': analysis_result.error_message,
                'tokens_used': 0,
                'analysis_time': analysis_time,
                'output_dir': model_output_dir
            }
        
        # Calcular custos
        cost_info = cost_calculator.tokens_analytics(
            {'usage': [{'total_tokens': analysis_result.tokens_used}]}, 
            analysis_result.model_used
        )
        
        # Gerar documentação
        from ..providers.base_provider import AIResponse
        
        prompts_used = {
            'system_prompt': prompt_manager.get_system_prompt(),
            'original_prompt': getattr(analysis_result, 'original_prompt', 'Prompt gerado dinamicamente'),
            'main_prompt': getattr(analysis_result, 'prompt_used', 'Prompt principal não disponível')
        }
        
        ai_response = AIResponse(
            success=True,
            content=analysis_result.content,
            tokens_used=analysis_result.tokens_used,
            model=analysis_result.model_used,
            provider=getattr(analysis_result, 'provider_used', 'enhanced_mock'),
            prompts_used=prompts_used,
            response_time=analysis_time
        )
        
        doc_result = doc_generator.generate_program_documentation(program, ai_response)
        
        logger.info(f"Análise de {program.name} com {model} bem-sucedida.")
        logger.info(f"Tokens utilizados: {analysis_result.tokens_used:,}")
        logger.info(f"Custo: ${cost_info['cost']:.4f}")
        logger.info(f"Modelo utilizado: {analysis_result.model_used}")
        
        return {
            'success': True,
            'program_name': program.name,
            'model': model,
            'tokens_used': analysis_result.tokens_used,
            'analysis_time': analysis_time,
            'output_dir': model_output_dir,
            'files_generated': [doc_result] if doc_result else [],
            'response': analysis_result
        }
        
    except Exception as e:
        logger.error(f"Erro na análise de {program.name} com modelo {model}: {str(e)}")
        return {
            'success': False,
            'program_name': program.name,
            'model': model,
            'error': str(e),
            'tokens_used': 0,
            'analysis_time': 0,
            'output_dir': model_output_dir
        }


def generate_comparative_report(programs, all_results, output_dir):
    """Gera relatório comparativo entre modelos."""
    logger = logging.getLogger(__name__)
    
    try:
        report_path = os.path.join(output_dir, "relatorio_comparativo_modelos.md")
        
        # Agrupar resultados por modelo
        models_used = list(set(r['model'] for r in all_results))
        results_by_model = {model: [r for r in all_results if r['model'] == model] for model in models_used}
        
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write("# Relatório Comparativo de Modelos\n\n")
            f.write(f"**Data:** {time.strftime('%d/%m/%Y %H:%M:%S')}\n")
            f.write(f"**Programas Analisados:** {len(programs)}\n")
            f.write(f"**Modelos Utilizados:** {len(models_used)}\n\n")
            
            # Resumo geral
            f.write("## Resumo Geral\n\n")
            f.write("| Modelo | Sucessos | Falhas | Taxa de Sucesso | Tokens Médios |\n")
            f.write("|--------|----------|--------|-----------------|---------------|\n")
            
            for model in models_used:
                model_results = results_by_model[model]
                successes = sum(1 for r in model_results if r['success'])
                failures = len(model_results) - successes
                success_rate = (successes / len(model_results)) * 100 if model_results else 0
                avg_tokens = sum(r.get('tokens_used', 0) for r in model_results if r['success']) / max(successes, 1)
                
                f.write(f"| {model} | {successes} | {failures} | {success_rate:.1f}% | {avg_tokens:.0f} |\n")
        
        logger.info(f"Relatório comparativo gerado: {report_path}")
        
    except Exception as e:
        logger.error(f"Erro ao gerar relatório comparativo: {e}")


def process_consolidated_analysis(args, config_manager, cost_calculator, parser, models, rag_integration):
    """Processa análise consolidada sistêmica."""
    logger = logging.getLogger(__name__)
    logger.info("Processamento consolidado não implementado nesta versão")
    

def process_consolidated_report(args, config_manager, cost_calculator, parser, models):
    """Processa relatório único consolidado."""
    logger = logging.getLogger(__name__)
    logger.info("Relatório consolidado não implementado nesta versão")


def process_expert_analysis(args, config_manager, cost_calculator, parser, models):
    """Processa análise especializada."""
    logger = logging.getLogger(__name__)
    logger.info("Análise especializada não implementada nesta versão")
