#!/usr/bin/env python3
"""
COBOL to Docs v1.1 - Inicializador de Projeto
Comando: cobol-init

Cria estrutura inicial para uso após pip install
"""

import os
import sys
import shutil
import logging
from pathlib import Path

def setup_logging():
    """Configurar logging básico"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    return logging.getLogger(__name__)

def create_project_structure(project_dir: str) -> bool:
    """
    Cria estrutura inicial do projeto COBOL to Docs
    
    Args:
        project_dir: Diretório do projeto
        
    Returns:
        True se sucesso, False caso contrário
    """
    logger = setup_logging()
    
    try:
        # Criar diretório principal
        os.makedirs(project_dir, exist_ok=True)
        logger.info(f"Criando projeto em: {project_dir}")
        
        # Estrutura de diretórios
        dirs_to_create = [
            "config",
            "examples", 
            "output",
            "docs"
        ]
        
        for dir_name in dirs_to_create:
            dir_path = os.path.join(project_dir, dir_name)
            os.makedirs(dir_path, exist_ok=True)
            logger.info(f"Criado diretório: {dir_name}")
        
        # Copiar arquivos de configuração do pacote instalado
        try:
            import pkg_resources
            
            # Copiar config.yaml
            config_content = pkg_resources.resource_string('cobol_to_docs', 'config/config.yaml')
            with open(os.path.join(project_dir, 'config', 'config.yaml'), 'wb') as f:
                f.write(config_content)
            
            # Copiar prompts
            prompts_content = pkg_resources.resource_string('cobol_to_docs', 'config/prompts_original.yaml')
            with open(os.path.join(project_dir, 'config', 'prompts_original.yaml'), 'wb') as f:
                f.write(prompts_content)
                
            # Copiar exemplos
            examples = ['fontes.txt', 'books.txt', 'programa_exemplo.cbl']
            for example in examples:
                try:
                    example_content = pkg_resources.resource_string('cobol_to_docs', f'examples/{example}')
                    with open(os.path.join(project_dir, 'examples', example), 'wb') as f:
                        f.write(example_content)
                except:
                    logger.warning(f"Exemplo {example} não encontrado no pacote")
                    
        except ImportError:
            logger.warning("pkg_resources não disponível - criando arquivos básicos")
            
            # Criar config.yaml básico
            basic_config = """# COBOL to Docs v1.1 - Configuração
providers:
  luzia:
    enabled: true
    client_id: "${LUZIA_CLIENT_ID}"
    client_secret: "${LUZIA_CLIENT_SECRET}"
    auth_url: "https://auth.luzia.com/oauth/token"
    api_url: "https://api.luzia.com/v1/chat/completions"
    models:
      aws_claude_3_5:
        name: "aws-claude-3-5-sonnet"
        max_tokens: 8192
        temperature: 0.1
        timeout: 120
        context_window: 200000
        retry: 3

  enhanced_mock:
    enabled: true
    models:
      enhanced_mock:
        name: "enhanced-mock-gpt-4"
"""
            with open(os.path.join(project_dir, 'config', 'config.yaml'), 'w', encoding='utf-8') as f:
                f.write(basic_config)
        
        # Criar README do projeto
        readme_content = f"""# Projeto COBOL to Docs

Este projeto foi inicializado com `cobol-init`.

## Como usar:

1. Coloque seus arquivos COBOL em `examples/`
2. Configure credenciais em `config/config.yaml`
3. Execute: `cobol-to-docs --fontes examples/seu_arquivo.txt`

## Estrutura:
- `config/` - Configurações e prompts
- `examples/` - Arquivos COBOL de exemplo
- `output/` - Relatórios gerados
- `docs/` - Documentação adicional

## Comandos disponíveis:
- `cobol-to-docs` - Análise principal
- `cobol-generate-prompts` - Gerador de prompts
- `cobol-init` - Este inicializador

Criado em: {project_dir}
"""
        
        with open(os.path.join(project_dir, 'README.md'), 'w', encoding='utf-8') as f:
            f.write(readme_content)
        
        logger.info(" Projeto inicializado com sucesso!")
        logger.info(f" Diretório: {project_dir}")
        logger.info(" Execute: cobol-to-docs --status para verificar configuração")
        
        return True
        
    except Exception as e:
        logger.error(f"Erro ao criar projeto: {e}")
        return False

def main():
    """Função principal do cobol-init"""
    logger = setup_logging()
    
    # Verificar argumentos
    if len(sys.argv) > 1:
        project_dir = sys.argv[1]
    else:
        project_dir = "cobol_project"
    
    logger.info("=== COBOL to Docs v1.1 - Inicializador ===")
    logger.info("Autor: Carlos Morais")
    
    # Verificar se diretório já existe
    if os.path.exists(project_dir) and os.listdir(project_dir):
        response = input(f"Diretório '{project_dir}' já existe e não está vazio. Continuar? (y/N): ")
        if response.lower() != 'y':
            logger.info("Operação cancelada pelo usuário")
            return
    
    # Criar projeto
    success = create_project_structure(project_dir)
    
    if success:
        print(f"""
 COBOL to Docs v1.1 inicializado com sucesso!

 Projeto criado em: {project_dir}

 Próximos passos:
1. cd {project_dir}
2. Edite config/config.yaml com suas credenciais
3. Coloque arquivos COBOL em examples/
4. Execute: cobol-to-docs --fontes examples/fontes.txt

📖 Comandos disponíveis:
- cobol-to-docs --status          # Verificar configuração
- cobol-to-docs --fontes arquivo  # Análise principal  
- cobol-generate-prompts --help   # Gerador de prompts

✨ Sistema pronto para uso!
""")
    else:
        print(" Erro na inicialização. Verifique os logs acima.")
        sys.exit(1)

if __name__ == "__main__":
    main()
