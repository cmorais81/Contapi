# O que faz o comando `cobol-to-docs --init`

## Resumo Rápido

O comando `cobol-to-docs --init` **configura automaticamente** todo o ambiente necessário para usar o COBOL Analyzer, criando diretórios e copiando arquivos de configuração.

## Passo a Passo Detalhado

### 1. Verificação Inicial
```
🔍 Verifica se já foi inicializado (arquivo .cobol_analyzer_init)
🔍 Verifica permissões do diretório atual
🔍 Identifica se é primeira execução
```

### 2. Criação de Diretórios
```
📁 config/     - Arquivos de configuração
📁 data/       - Base de conhecimento RAG e dados
📁 logs/       - Arquivos de log do sistema
📁 examples/   - Exemplos de programas COBOL
```

### 3. Cópia de Arquivos de Configuração (8 arquivos)
```
⚙️ config/config.yaml                      - Configuração principal
⚙️ config/config_enhanced.yaml             - Configuração v3.1.0
⚙️ config/prompts_enhanced.yaml            - Prompts especializados
⚙️ config/prompts_cadoc_deep_analysis.yaml - Prompts análise profunda
⚙️ config/prompts_deep_business_rules.yaml - Prompts regras de negócio
⚙️ config/prompts_doc_legado_pro.yaml      - Prompts documentação legado
⚙️ config/prompts_especialista.yaml        - Prompts especialista
⚙️ config/prompts_melhorado_rag.yaml       - Prompts RAG melhorado
```

### 4. Configuração da Base de Conhecimento RAG (7 itens)
```
📊 data/cobol_knowledge_base.json                - Base principal
📊 data/cobol_knowledge_base_backup.json         - Backup da base
📊 data/cobol_knowledge_base_cadoc_expanded.json - Base expandida
📊 data/cobol_knowledge_base_consolidated.json   - Base consolidada
📊 data/embeddings/                              - Cache de embeddings
📊 data/knowledge_base/                          - Base de conhecimento
📊 data/sessions/                                - Relatórios de sessões
```

### 5. Criação de Exemplos
```
📋 examples/fontes.txt              - Lista de programas exemplo
📋 examples/books.txt               - Lista de copybooks exemplo
📋 examples/PROGRAMA_EXEMPLO.CBL    - Programa COBOL de exemplo
```

### 6. Arquivo de Controle
```
🏷️ .cobol_analyzer_init - Marca que o ambiente foi inicializado
```

## Exemplo Visual do Resultado

### Antes do `--init`
```
meu_projeto/
└── (vazio)
```

### Depois do `--init`
```
meu_projeto/
├── .cobol_analyzer_init           # Arquivo de controle
├── config/                        # 8 arquivos de configuração
│   ├── config.yaml
│   ├── config_enhanced.yaml
│   ├── prompts_enhanced.yaml
│   ├── prompts_cadoc_deep_analysis.yaml
│   ├── prompts_deep_business_rules.yaml
│   ├── prompts_doc_legado_pro.yaml
│   ├── prompts_especialista.yaml
│   └── prompts_melhorado_rag.yaml
├── data/                          # Base de conhecimento RAG
│   ├── cobol_knowledge_base.json
│   ├── cobol_knowledge_base_backup.json
│   ├── cobol_knowledge_base_cadoc_expanded.json
│   ├── cobol_knowledge_base_consolidated.json
│   ├── embeddings/
│   ├── knowledge_base/
│   └── sessions/
├── logs/                          # Diretório para logs
└── examples/                      # Exemplos prontos
    ├── fontes.txt
    ├── books.txt
    └── PROGRAMA_EXEMPLO.CBL
```

## Mensagens que Você Vê

### Durante a Execução
```
🚀 Configurando ambiente local do COBOL Analyzer...
✅ Ambiente configurado com sucesso!
📁 Configurações: /caminho/para/config
📊 Dados RAG: /caminho/para/data
📝 Logs: /caminho/para/logs
📋 Exemplos: /caminho/para/examples
📂 Diretórios criados: 4
Ambiente local inicializado com sucesso!
```

## Variações do Comando

### Inicialização Básica
```bash
cobol-to-docs --init
# Cria tudo no diretório atual
```

### Com Diretórios Personalizados
```bash
cobol-to-docs --init --config-dir ./minha_config --data-dir ./meus_dados
# Cria com nomes personalizados
```

### Forçar Reinicialização
```bash
cobol-to-docs --init --force-init
# Recria tudo mesmo se já existir
```

## O que Cada Arquivo Faz

### Arquivos de Configuração
- **config.yaml**: Configuração principal com provedores de IA
- **config_enhanced.yaml**: Configuração v3.1.0 com novos recursos
- **prompts_*.yaml**: Diferentes conjuntos de prompts para análises especializadas

### Base de Conhecimento RAG
- **cobol_knowledge_base.json**: Conhecimento sobre COBOL para melhorar análises
- **embeddings/**: Cache de vetores para busca semântica
- **sessions/**: Histórico de análises anteriores

### Exemplos
- **fontes.txt**: Lista exemplo de programas COBOL para analisar
- **books.txt**: Lista exemplo de copybooks
- **PROGRAMA_EXEMPLO.CBL**: Programa COBOL de demonstração

## Depois da Inicialização

### Você pode usar imediatamente:
```bash
# Analisar programas COBOL
cobol-to-docs --fontes examples/fontes.txt

# Análise consolidada
cobol-to-docs --fontes examples/fontes.txt --consolidado

# Verificar status
cobol-to-docs --status

# Mostrar caminhos configurados
cobol-to-docs --show-paths
```

### Personalizar configurações:
```bash
# Editar configuração principal
nano config/config.yaml

# Editar prompts especializados
nano config/prompts_enhanced.yaml
```

## Benefícios da Inicialização

### 1. **Zero Configuração Manual**
- Não precisa criar diretórios manualmente
- Não precisa copiar arquivos de configuração
- Não precisa configurar base de conhecimento

### 2. **Ambiente Completo**
- Todas as configurações necessárias
- Base de conhecimento RAG pronta
- Exemplos para começar imediatamente

### 3. **Personalização Flexível**
- Diretórios podem ser personalizados
- Configurações podem ser editadas
- Prompts podem ser adaptados

### 4. **Isolamento por Projeto**
- Cada projeto pode ter sua configuração
- Não interfere com outros projetos
- Configurações independentes

## Resumo Final

**O comando `cobol-to-docs --init` transforma um diretório vazio em um ambiente completo e pronto para análise de programas COBOL, com:**

- ✅ **4 diretórios** organizados
- ✅ **8 arquivos de configuração** especializados
- ✅ **Base de conhecimento RAG** completa
- ✅ **Exemplos prontos** para uso
- ✅ **Zero configuração manual** necessária

**Em resumo**: É como ter um "assistente de configuração" que prepara tudo automaticamente para você começar a analisar programas COBOL imediatamente!

---

**Comando**: `cobol-to-docs --init`  
**Tempo**: ~5 segundos  
**Resultado**: Ambiente completo pronto para uso
