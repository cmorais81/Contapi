# Manual Técnico - COBOL Analyzer v3.1.0

## Arquitetura do Sistema

### Visão Geral

O COBOL Analyzer é construído com uma arquitetura modular que separa responsabilidades em componentes especializados:

```
COBOL Analyzer
├── Core (Núcleo)
│   ├── Configuration Management
│   ├── Logging System
│   └── Local Setup
├── Providers (Provedores de IA)
│   ├── Luzia Provider
│   ├── GitHub Copilot Provider
│   ├── OpenAI Provider
│   ├── AWS Bedrock Provider
│   └── Enhanced Mock Provider
├── Analyzers (Analisadores)
│   ├── Enhanced COBOL Analyzer
│   ├── Professional Analyzer
│   └── Business Rules Extractor
├── RAG System (Sistema RAG)
│   ├── Knowledge Base
│   ├── Auto Learning
│   └── Context Enhancement
├── Parsers (Analisadores Sintáticos)
│   └── COBOL Parser
├── Generators (Geradores)
│   ├── Documentation Generator
│   └── Report Generator
└── Utils (Utilitários)
    ├── Cost Calculator
    ├── HTML Generator
    └── PDF Converter
```

### Componentes Principais

#### 1. Core System (`src/core/`)

**ConfigManager** (`config.py`)
- Gerenciamento centralizado de configurações
- Suporte a múltiplos arquivos de configuração
- Validação de configurações

**LocalSetup** (`local_setup.py`)
- Inicialização automática do ambiente
- Cópia de arquivos de configuração
- Criação de estrutura de diretórios

#### 2. Provider System (`src/providers/`)

**EnhancedProviderManager** (`enhanced_provider_manager.py`)
- Gerenciamento de múltiplos provedores de IA
- Fallback automático entre provedores
- Load balancing e rate limiting

**Provedores Implementados**:
- **LuziaProvider**: Integração com plataforma Luzia (Santander)
- **GitHubCopilotProvider**: Integração com GitHub Copilot
- **OpenAIProvider**: Integração com OpenAI GPT
- **BedrockProvider**: Integração com AWS Bedrock
- **EnhancedMockProvider**: Simulador para desenvolvimento

#### 3. RAG System (`src/rag/`)

**RAGIntegration** (`rag_integration.py`)
- Sistema de Retrieval-Augmented Generation
- Base de conhecimento COBOL especializada
- Enriquecimento automático de contexto

**AutoLearningEnhancement** (`auto_learning_enhancement.py`)
- Aprendizado contínuo a partir das análises
- Atualização automática da base de conhecimento
- Métricas de qualidade do aprendizado

#### 4. Analysis Engine (`src/analyzers/`)

**EnhancedCOBOLAnalyzer** (`enhanced_cobol_analyzer.py`)
- Motor principal de análise COBOL
- Integração com sistema RAG
- Suporte a múltiplos tipos de análise

## Fluxo de Execução

### 1. Inicialização

```python
# main.py
def main():
    # 1. Parse de argumentos
    args = parse_arguments()
    
    # 2. Configuração de logging
    setup_logging(args.log_level)
    
    # 3. Inicialização automática (se necessário)
    if not config_exists():
        auto_initialize()
    
    # 4. Carregamento de configuração
    config_manager = ConfigManager()
    
    # 5. Inicialização do sistema RAG
    rag_system = RAGIntegration()
    
    # 6. Inicialização dos provedores
    provider_manager = EnhancedProviderManager(config_manager)
```

### 2. Processamento

```python
# Fluxo principal de análise
def process_analysis():
    # 1. Parse dos programas COBOL
    programs = cobol_parser.parse_programs(source_files)
    
    # 2. Enriquecimento com RAG
    enriched_context = rag_system.enrich_context(programs)
    
    # 3. Seleção do modelo de IA
    model = provider_manager.select_model(args.models)
    
    # 4. Geração de prompts
    prompts = prompt_manager.generate_prompts(programs, enriched_context)
    
    # 5. Execução da análise
    results = analyzer.analyze_programs(programs, prompts, model)
    
    # 6. Geração de documentação
    documentation = doc_generator.generate_docs(results)
    
    # 7. Auto-learning
    rag_system.learn_from_analysis(results)
```

## Configuração Técnica

### Arquivo de Configuração Principal

**config/config.yaml**:
```yaml
# Configuração de IA
ai:
  primary_provider: "luzia"
  fallback_providers: ["enhanced_mock", "github_copilot"]
  temperature: 0.1
  max_tokens: 8000
  timeout: 300

# Configuração de análise
analysis:
  depth: "detailed"
  include_comments: true
  include_business_rules: true
  include_technical_details: true
  max_program_size: 50000

# Configuração RAG
rag:
  enabled: true
  knowledge_base_path: "data/cobol_knowledge_base.json"
  max_context_items: 10
  similarity_threshold: 0.7
  auto_learning: true
  learning_threshold: 0.8

# Configuração de provedores
providers:
  luzia:
    enabled: true
    base_url: "https://luzia.azure.paas.santanderbr.pre.corp"
    models:
      - "aws-claude-3-5-sonnet"
      - "aws-claude-3-5-haiku"
      - "amazon-nova-pro-v1"
    
  github_copilot:
    enabled: true
    base_url: "https://api.githubcopilot.com"
    models:
      - "gpt-4o"
      - "gpt-4o-mini"
    
  enhanced_mock:
    enabled: true
    models:
      - "enhanced-mock-gpt-4"
      - "basic-fallback"
```

### Configuração de Prompts

Os prompts são organizados em arquivos YAML especializados:

**config/prompts_enhanced.yaml**:
```yaml
analysis_prompts:
  functional_analysis:
    system: "Você é um especialista em análise de sistemas COBOL..."
    user: "Analise o seguinte programa COBOL..."
    
  business_rules:
    system: "Você é um analista de negócios especializado..."
    user: "Extraia as regras de negócio do programa..."
    
  modernization:
    system: "Você é um arquiteto de modernização..."
    user: "Identifique oportunidades de modernização..."
```

## Sistema RAG Detalhado

### Base de Conhecimento

A base de conhecimento é estruturada em JSON com os seguintes tipos:

```json
{
  "knowledge_items": [
    {
      "id": "cobol_pattern_001",
      "type": "pattern",
      "category": "file_handling",
      "title": "Padrão de Leitura Sequencial",
      "content": "Padrão comum para leitura sequencial...",
      "keywords": ["READ", "SEQUENTIAL", "FILE"],
      "confidence": 0.95,
      "usage_count": 150
    },
    {
      "id": "business_rule_001",
      "type": "business_rule",
      "category": "banking",
      "title": "Cálculo de Juros Compostos",
      "content": "Regra para cálculo de juros...",
      "keywords": ["JUROS", "CALCULO", "BANKING"],
      "confidence": 0.90,
      "usage_count": 75
    }
  ]
}
```

### Algoritmo de Enriquecimento

```python
def enrich_context(self, program_content, max_items=10):
    # 1. Extração de keywords do programa
    keywords = self.extract_keywords(program_content)
    
    # 2. Busca semântica na base de conhecimento
    relevant_items = self.semantic_search(keywords, max_items)
    
    # 3. Ranking por relevância
    ranked_items = self.rank_by_relevance(relevant_items, program_content)
    
    # 4. Formatação do contexto enriquecido
    enriched_context = self.format_context(ranked_items)
    
    return enriched_context
```

### Auto-Learning

```python
def learn_from_analysis(self, analysis_result):
    # 1. Extração de novos padrões
    new_patterns = self.extract_patterns(analysis_result)
    
    # 2. Validação de qualidade
    validated_patterns = self.validate_patterns(new_patterns)
    
    # 3. Atualização da base de conhecimento
    for pattern in validated_patterns:
        if pattern.confidence > self.learning_threshold:
            self.knowledge_base.add_item(pattern)
    
    # 4. Atualização de estatísticas
    self.update_usage_statistics(analysis_result)
```

## Provedores de IA

### Interface Base

Todos os provedores implementam a interface `BaseProvider`:

```python
class BaseProvider:
    def __init__(self, config):
        self.config = config
        self.client = None
        
    def initialize(self):
        """Inicializa o cliente do provedor"""
        pass
        
    def is_available(self):
        """Verifica se o provedor está disponível"""
        pass
        
    def generate_response(self, prompt, model=None):
        """Gera resposta usando o modelo especificado"""
        pass
        
    def get_available_models(self):
        """Retorna lista de modelos disponíveis"""
        pass
        
    def calculate_cost(self, tokens_used):
        """Calcula custo baseado nos tokens utilizados"""
        pass
```

### Implementação do Luzia Provider

```python
class LuziaProvider(BaseProvider):
    def __init__(self, config):
        super().__init__(config)
        self.base_url = config.get('base_url')
        self.client_id = os.getenv('LUZIA_CLIENT_ID')
        self.client_secret = os.getenv('LUZIA_CLIENT_SECRET')
        self.access_token = None
        
    def initialize(self):
        """Obtém token OAuth2 e inicializa cliente"""
        self.access_token = self._get_oauth_token()
        self.client = self._create_client()
        
    def _get_oauth_token(self):
        """Implementa fluxo OAuth2 para Luzia"""
        # Implementação do OAuth2
        pass
        
    def generate_response(self, prompt, model="aws-claude-3-5-sonnet"):
        """Gera resposta usando modelo Luzia"""
        # Implementação da chamada para Luzia
        pass
```

## Sistema de Análise

### Enhanced COBOL Analyzer

O analisador principal implementa múltiplos tipos de análise:

```python
class EnhancedCOBOLAnalyzer:
    def __init__(self, provider_manager, config_manager):
        self.provider_manager = provider_manager
        self.config_manager = config_manager
        self.rag_system = RAGIntegration()
        
    def analyze_program(self, program_content, program_name, **kwargs):
        # 1. Pré-processamento
        processed_content = self.preprocess_program(program_content)
        
        # 2. Enriquecimento RAG
        enriched_context = self.rag_system.enrich_context(processed_content)
        
        # 3. Seleção de prompt baseado no tipo de análise
        prompt_type = kwargs.get('analysis_type', 'functional')
        prompt = self.get_analysis_prompt(prompt_type, processed_content, enriched_context)
        
        # 4. Execução da análise
        model = kwargs.get('model', self.config_manager.get_primary_model())
        response = self.provider_manager.generate_response(prompt, model)
        
        # 5. Pós-processamento
        analysis_result = self.postprocess_response(response, program_name)
        
        # 6. Auto-learning
        self.rag_system.learn_from_analysis(analysis_result)
        
        return analysis_result
```

### Tipos de Análise Implementados

1. **Análise Funcional**: Documentação básica do programa
2. **Análise Especialista**: Análise técnica profunda
3. **Análise de Modernização**: Identificação de oportunidades
4. **Análise de Procedures**: Foco na PROCEDURE DIVISION
5. **Análise Consolidada**: Análise sistêmica de múltiplos programas

## Geração de Documentação

### Documentation Generator

```python
class DocumentationGenerator:
    def __init__(self, template_manager):
        self.template_manager = template_manager
        
    def generate_functional_doc(self, analysis_result):
        """Gera documentação funcional em Markdown"""
        template = self.template_manager.get_template('functional_analysis')
        return template.render(analysis_result)
        
    def generate_html_report(self, analysis_results):
        """Gera relatório HTML consolidado"""
        template = self.template_manager.get_template('html_report')
        return template.render(analysis_results)
        
    def generate_pdf_report(self, html_content):
        """Converte HTML para PDF"""
        return self.pdf_converter.convert(html_content)
```

### Templates de Documentação

Os templates são definidos em `src/templates/documentation_templates_enhanced.py`:

```python
FUNCTIONAL_ANALYSIS_TEMPLATE = """
# Análise Funcional - {program_name}

## Visão Geral
{overview}

## Estrutura do Programa
{structure}

## Lógica de Negócio
{business_logic}

## Dados e Arquivos
{data_structures}

## Fluxo de Execução
{execution_flow}

## Observações Técnicas
{technical_notes}
"""
```

## Monitoramento e Logging

### Sistema de Logging

```python
# Configuração de logging hierárquico
LOGGING_CONFIG = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'detailed': {
            'format': '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        }
    },
    'handlers': {
        'file': {
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': 'logs/cobol_analyzer.log',
            'maxBytes': 10485760,  # 10MB
            'backupCount': 5,
            'formatter': 'detailed'
        }
    },
    'loggers': {
        'cobol_analyzer': {
            'handlers': ['file'],
            'level': 'INFO',
            'propagate': False
        }
    }
}
```

### Métricas e Monitoramento

```python
class MetricsCollector:
    def __init__(self):
        self.metrics = {
            'analyses_performed': 0,
            'tokens_consumed': 0,
            'cost_accumulated': 0.0,
            'rag_items_used': 0,
            'provider_usage': {}
        }
        
    def record_analysis(self, provider, tokens, cost, rag_items):
        self.metrics['analyses_performed'] += 1
        self.metrics['tokens_consumed'] += tokens
        self.metrics['cost_accumulated'] += cost
        self.metrics['rag_items_used'] += rag_items
        
        if provider not in self.metrics['provider_usage']:
            self.metrics['provider_usage'][provider] = 0
        self.metrics['provider_usage'][provider] += 1
```

## Extensibilidade

### Adicionando Novos Provedores

1. **Criar classe do provedor**:
```python
class NovoProvider(BaseProvider):
    def __init__(self, config):
        super().__init__(config)
        # Inicialização específica
        
    def generate_response(self, prompt, model=None):
        # Implementação específica
        pass
```

2. **Registrar no ProviderManager**:
```python
# Em enhanced_provider_manager.py
from .novo_provider import NovoProvider

class EnhancedProviderManager:
    def _initialize_providers(self):
        # ... outros provedores
        if self.config.get('providers.novo.enabled', False):
            self.providers['novo'] = NovoProvider(self.config)
```

3. **Adicionar configuração**:
```yaml
# Em config.yaml
providers:
  novo:
    enabled: true
    api_key: "${NOVO_API_KEY}"
    models:
      - "novo-model-1"
      - "novo-model-2"
```

### Adicionando Novos Tipos de Análise

1. **Criar prompt especializado**:
```yaml
# Em config/prompts_novo_tipo.yaml
novo_analysis:
  system: "Você é um especialista em..."
  user: "Realize análise específica..."
```

2. **Implementar no analisador**:
```python
def analyze_novo_tipo(self, program_content, **kwargs):
    prompt = self.get_prompt('novo_analysis')
    # Implementação específica
    return analysis_result
```

## Segurança e Boas Práticas

### Segurança de Credenciais

- Todas as credenciais são obtidas via variáveis de ambiente
- Nunca armazenar credenciais em arquivos de configuração
- Usar tokens com escopo limitado quando possível

### Tratamento de Dados Sensíveis

- Logs não devem conter código COBOL completo
- Respostas de IA são sanitizadas antes do armazenamento
- Opção de executar análise sem persistir dados

### Performance

- Cache de tokens OAuth2 para reduzir latência
- Pool de conexões para provedores HTTP
- Processamento assíncrono para múltiplos programas
- Compressão de dados RAG para reduzir uso de memória

## Troubleshooting Técnico

### Problemas Comuns

1. **Provider não inicializa**:
   - Verificar credenciais de ambiente
   - Verificar conectividade de rede
   - Verificar logs detalhados

2. **RAG não funciona**:
   - Verificar se base de conhecimento existe
   - Verificar permissões de arquivo
   - Verificar configuração RAG

3. **Análise incompleta**:
   - Verificar limites de token do modelo
   - Verificar timeout de requisição
   - Verificar qualidade do prompt

### Debugging

```bash
# Ativar logs detalhados
export COBOL_ANALYZER_LOG_LEVEL=DEBUG

# Executar com debugging
cobol-to-docs --fontes fontes.txt --log-level DEBUG --models enhanced_mock

# Verificar logs
tail -f logs/cobol_analyzer.log
```

## Informações de Versão

- **Versão**: 3.1.0
- **Python**: 3.8+
- **Dependências principais**: requests, pyyaml, jinja2
- **Arquitetura**: Modular, extensível
- **Licença**: Proprietária
