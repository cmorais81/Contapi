# COBOL AI Engine v2.1.0

Sistema de análise automatizada de programas COBOL com suporte a múltiplos padrões de prompt.

## Funcionalidades

- **Análise Técnica Original**: Prompt focado em análise técnica detalhada de COBOL
- **DOC-LEGADO PRO**: Especialista em documentação sistêmica para código legado
- **Múltiplos Providers**: Suporte a LuzIA, Claude, OpenAI e fallbacks
- **Documentação Automática**: Geração de documentação funcional e técnica
- **Interface CLI**: Linha de comando e modo interativo

## Instalação

```bash
pip install -r requirements.txt
```

## Uso Básico

### Análise com Prompt Original
```bash
python main.py --fontes programas.txt --models luzia --prompt-set original
```

### Análise com DOC-LEGADO PRO
```bash
python main.py --fontes programas.txt --models luzia --prompt-set doc_legado_pro
```

### Modo Interativo
```bash
python cli_interactive.py
```

## Configuração

### Variáveis de Ambiente (LuzIA)
```bash
export LUZIA_CLIENT_ID="seu_client_id"
export LUZIA_CLIENT_SECRET="seu_client_secret"
```

### Arquivo de Fontes
Crie um arquivo texto com os caminhos dos programas COBOL:
```
programa1.cbl
programa2.cbl
```

## Prompts Disponíveis

### original
- Foco em análise técnica tradicional
- Documentação para desenvolvedores e arquitetos
- Estrutura de questões priorizadas

### doc_legado_pro
- Especialista em documentação sistêmica
- Foco em rastreabilidade e evidências
- Documentação funcional e técnica completa

## Saída

A documentação é gerada no diretório `output/` em formato Markdown:
- `PROGRAMA_analise_funcional.md`: Documentação principal
- `PROGRAMA_ai_response.json`: Resposta completa da IA
- `PROGRAMA_ai_request.json`: Requisição enviada

## Estrutura do Projeto

```
cobol_ai_engine_clean/
├── main.py                 # Entrada principal
├── cli_interactive.py      # Interface interativa
├── config/
│   ├── config.yaml                # Configuração geral
│   ├── prompts_original.yaml      # Prompts para análise técnica original
│   └── prompts_doc_legado_pro.yaml # Prompts para DOC-LEGADO PRO
├── src/
│   ├── core/              # Componentes principais
│   ├── providers/         # Integrações com APIs
│   ├── parsers/           # Analisadores de código
│   ├── generators/        # Geradores de documentação
│   └── analyzers/         # Analisadores especializados
└── requirements.txt       # Dependências
```

## Comandos Úteis

```bash
# Verificar status dos providers
python main.py --status

# Análise com múltiplos modelos
python main.py --fontes programas.txt --models '["luzia","claude"]'

# Gerar relatórios HTML
python main.py --fontes programas.txt --pdf

# Logs detalhados
python main.py --fontes programas.txt --log DEBUG
```
