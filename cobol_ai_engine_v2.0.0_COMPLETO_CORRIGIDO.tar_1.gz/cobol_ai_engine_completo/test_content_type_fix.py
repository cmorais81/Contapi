#!/usr/bin/env python3
"""
Teste para corrigir problema de Content-Type
"""

import os
import sys
import json
import requests
import logging

# Configurar logging
logging.basicConfig(level=logging.INFO)

def test_content_type_fix():
    """Testar diferentes formatos de Content-Type"""
    
    print("=" * 80)
    print("TESTE: CORREÇÃO DO CONTENT-TYPE")
    print("=" * 80)
    
    # Verificar credenciais
    client_id = os.getenv('LUZIA_CLIENT_ID')
    client_secret = os.getenv('LUZIA_CLIENT_SECRET')
    
    if not client_id or not client_secret:
        print("❌ Credenciais não definidas")
        return False
    
    print(f"✅ Credenciais definidas")
    
    # URLs
    auth_url = "https://login.azure.paas.santanderbr.pre.corp/auth/realms/corp/protocol/openid-connect/token"
    api_url = "https://gut-api-aws.santanderbr.dev.corp/genai_services/v1/pipelines/submit"
    
    try:
        # 1. Obter token
        print("\n1. OBTENDO TOKEN")
        print("-" * 50)
        
        auth_data = {
            "grant_type": "client_credentials",
            "client_id": client_id,
            "client_secret": client_secret
        }
        
        auth_headers = {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Accept': '*/*'
        }
        
        auth_response = requests.post(
            auth_url,
            headers=auth_headers,
            data=auth_data,
            verify=False,
            timeout=30
        )
        
        if auth_response.status_code != 200:
            print(f"❌ Erro na autenticação: {auth_response.status_code}")
            return False
        
        token_data = auth_response.json()
        access_token = token_data.get('access_token')
        
        print(f"✅ Token obtido: {access_token[:20]}...")
        
        # 2. Payload simples
        payload = {
            "input": {
                "query": [
                    {
                        "role": "system",
                        "content": "Answer all questions in brazilian portuguese."
                    },
                    {
                        "role": "user",
                        "content": "Diga apenas 'teste ok'"
                    }
                ]
            },
            "config": {
                "type": "catena.llm.LLMRouter",
                "obj_kwargs": {
                    "routing_model": "azure-gpt-4o-mini",
                    "temperature": 0.1
                }
            }
        }
        
        print("\n2. TESTANDO DIFERENTES CONTENT-TYPES")
        print("-" * 50)
        
        # Teste 1: requests.post com json= (automático)
        print("\nTESTE 1: requests.post(json=payload) - Content-Type automático")
        
        headers1 = {
            "X-santander-client-id": client_id,
            "Authorization": f"Bearer {access_token}"
        }
        
        response1 = requests.post(
            api_url,
            json=payload,  # Content-Type: application/json automático
            headers=headers1,
            verify=False,
            timeout=30
        )
        
        print(f"Status: {response1.status_code}")
        print(f"Response: {response1.text[:200]}...")
        
        # Teste 2: Content-Type explícito
        print("\nTESTE 2: Content-Type explícito application/json")
        
        headers2 = {
            "X-santander-client-id": client_id,
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json"
        }
        
        response2 = requests.post(
            api_url,
            data=json.dumps(payload),  # Serializar manualmente
            headers=headers2,
            verify=False,
            timeout=30
        )
        
        print(f"Status: {response2.status_code}")
        print(f"Response: {response2.text[:200]}...")
        
        # Teste 3: Content-Type com charset
        print("\nTESTE 3: Content-Type com charset UTF-8")
        
        headers3 = {
            "X-santander-client-id": client_id,
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json; charset=utf-8"
        }
        
        response3 = requests.post(
            api_url,
            data=json.dumps(payload, ensure_ascii=False).encode('utf-8'),
            headers=headers3,
            verify=False,
            timeout=30
        )
        
        print(f"Status: {response3.status_code}")
        print(f"Response: {response3.text[:200]}...")
        
        # Teste 4: Como no seu teste.py (sem Content-Type explícito)
        print("\nTESTE 4: Exatamente como no teste.py")
        
        headers4 = {
            "X-santander-client-id": client_id,
            "Authorization": f"Bearer {access_token}"
        }
        
        # Verificar se requests adiciona Content-Type automaticamente
        import requests.models
        
        # Preparar request
        req = requests.Request(
            'POST',
            api_url,
            json=payload,
            headers=headers4
        )
        
        prepared = req.prepare()
        
        print(f"Headers preparados: {dict(prepared.headers)}")
        print(f"Body: {prepared.body[:200]}...")
        
        # Enviar
        session = requests.Session()
        response4 = session.send(prepared, verify=False, timeout=30)
        
        print(f"Status: {response4.status_code}")
        print(f"Response: {response4.text[:200]}...")
        
        print("\n3. ANÁLISE DOS RESULTADOS")
        print("-" * 50)
        
        responses = [
            ("Automático", response1),
            ("Explícito", response2),
            ("Com charset", response3),
            ("Como teste.py", response4)
        ]
        
        for name, resp in responses:
            if resp.status_code == 200:
                print(f"✅ {name}: SUCESSO!")
                return True
            else:
                print(f"❌ {name}: Erro {resp.status_code}")
        
        return False
        
    except Exception as e:
        print(f"❌ Erro durante teste: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = test_content_type_fix()
    
    print("\n" + "=" * 80)
    if success:
        print("✅ PROBLEMA RESOLVIDO!")
    else:
        print("❌ PROBLEMA PERSISTE")
        print("   Pode ser necessário verificar versão da API ou outros headers")
    print("=" * 80)
