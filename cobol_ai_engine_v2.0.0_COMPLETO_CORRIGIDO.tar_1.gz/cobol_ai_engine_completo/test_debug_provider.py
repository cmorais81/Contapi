#!/usr/bin/env python3
"""
Teste do provider de debug para identificar problema do payload
"""

import os
import sys
import logging

# Configurar logging detalhado
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

def test_debug_provider():
    """Testar provider de debug"""
    
    print("=" * 80)
    print("TESTE: PROVIDER DEBUG PARA IDENTIFICAR PROBLEMA DO PAYLOAD")
    print("=" * 80)
    
    # Verificar credenciais
    client_id = os.getenv('LUZIA_CLIENT_ID')
    client_secret = os.getenv('LUZIA_CLIENT_SECRET')
    
    if not client_id or not client_secret:
        print("❌ Credenciais não definidas")
        print("   Execute:")
        print("   export LUZIA_CLIENT_ID='seu_client_id'")
        print("   export LUZIA_CLIENT_SECRET='seu_client_secret'")
        return False
    
    print(f"✅ Credenciais definidas")
    
    try:
        # Importar provider de debug
        from src.providers.luzia_provider_debug import LuziaProviderDebug
        from src.providers.base_provider import AIRequest
        
        print("\n1. CRIANDO PROVIDER DE DEBUG")
        print("-" * 50)
        
        # Configuração
        config = {
            'client_id': client_id,
            'client_secret': client_secret,
            'timeout': 30.0
        }
        
        # Criar provider
        provider = LuziaProviderDebug(config)
        
        print(f"✅ Provider criado")
        print(f"   Auth URL: {provider.auth_url}")
        print(f"   API URL: {provider.base_url}")
        
        print("\n2. TESTANDO COM PAYLOAD SIMPLES")
        print("-" * 50)
        
        # Criar request simples
        request = AIRequest(
            prompt="teste simples",
            program_name="TESTE",
            program_code="IDENTIFICATION DIVISION.",
            context={}
        )
        
        print("📤 Enviando requisição de teste...")
        print("   (Veja logs detalhados acima)")
        
        # Executar análise
        response = provider.analyze(request)
        
        print("\n3. RESULTADO DO TESTE")
        print("-" * 50)
        
        if response.success:
            print("✅ TESTE BEM-SUCEDIDO!")
            print(f"   Modelo: {response.model}")
            print(f"   Tempo: {response.response_time:.2f}s")
            print(f"   Conteúdo: {response.content[:200]}...")
            return True
        else:
            print("❌ TESTE FALHOU")
            print(f"   Erro: {response.content}")
            print(f"   Raw response: {response.raw_response}")
            return False
            
    except Exception as e:
        print(f"❌ Erro durante teste: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = test_debug_provider()
    
    print("\n" + "=" * 80)
    if success:
        print("✅ PAYLOAD FUNCIONANDO CORRETAMENTE!")
    else:
        print("❌ PROBLEMA IDENTIFICADO NOS LOGS ACIMA")
        print("   Analise os logs detalhados para identificar o problema")
    print("=" * 80)
