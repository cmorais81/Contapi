#!/usr/bin/env python3
"""
HTML Generator - COBOL AI Engine v1.0.2
Gerador de HTML para relatórios que podem ser convertidos para PDF via navegador.
"""

import os
import re
import logging
from datetime import datetime
from typing import List, Dict, Any

logger = logging.getLogger(__name__)

class MarkdownToHTMLConverter:
    """Conversor de Markdown para HTML otimizado para impressão."""
    
    def __init__(self):
        """Inicializa o conversor."""
        self.css_styles = self._get_print_css()
    
    def _get_print_css(self) -> str:
        """Retorna CSS otimizado para impressão."""
        return """
        <style>
        /* Reset e configurações básicas */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 210mm;
            margin: 0 auto;
            padding: 20mm;
            background: white;
        }
        
        /* Configurações para impressão */
        @media print {
            body {
                margin: 0;
                padding: 15mm;
                font-size: 11pt;
            }
            
            .page-break {
                page-break-before: always;
            }
            
            .no-print {
                display: none !important;
            }
            
            h1, h2, h3 {
                page-break-after: avoid;
            }
            
            pre, code {
                page-break-inside: avoid;
            }
            
            table {
                page-break-inside: avoid;
            }
        }
        
        /* Tipografia */
        h1 {
            color: #2c3e50;
            font-size: 2.2em;
            margin-bottom: 0.5em;
            border-bottom: 3px solid #3498db;
            padding-bottom: 0.3em;
        }
        
        h2 {
            color: #34495e;
            font-size: 1.8em;
            margin-top: 1.5em;
            margin-bottom: 0.8em;
            border-bottom: 2px solid #ecf0f1;
            padding-bottom: 0.2em;
        }
        
        h3 {
            color: #2c3e50;
            font-size: 1.4em;
            margin-top: 1.2em;
            margin-bottom: 0.6em;
        }
        
        h4 {
            color: #34495e;
            font-size: 1.2em;
            margin-top: 1em;
            margin-bottom: 0.5em;
        }
        
        p {
            margin-bottom: 1em;
            text-align: justify;
        }
        
        /* Listas */
        ul, ol {
            margin-bottom: 1em;
            padding-left: 2em;
        }
        
        li {
            margin-bottom: 0.3em;
        }
        
        /* Código */
        code {
            background-color: #f8f9fa;
            padding: 0.2em 0.4em;
            border-radius: 3px;
            font-family: 'Courier New', monospace;
            font-size: 0.9em;
            border: 1px solid #e9ecef;
        }
        
        pre {
            background-color: #f8f9fa;
            padding: 1em;
            border-radius: 5px;
            overflow-x: auto;
            margin-bottom: 1em;
            border: 1px solid #e9ecef;
            font-family: 'Courier New', monospace;
            font-size: 0.85em;
            line-height: 1.4;
        }
        
        pre code {
            background: none;
            padding: 0;
            border: none;
        }
        
        /* Tabelas */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 1.5em;
            font-size: 0.9em;
        }
        
        th, td {
            border: 1px solid #ddd;
            padding: 0.8em;
            text-align: left;
        }
        
        th {
            background-color: #f2f2f2;
            font-weight: bold;
            color: #2c3e50;
        }
        
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        
        /* Blockquotes */
        blockquote {
            border-left: 4px solid #3498db;
            padding-left: 1em;
            margin: 1em 0;
            font-style: italic;
            color: #555;
            background-color: #f8f9fa;
            padding: 1em;
            border-radius: 0 5px 5px 0;
        }
        
        /* Links */
        a {
            color: #3498db;
            text-decoration: none;
        }
        
        a:hover {
            text-decoration: underline;
        }
        
        /* Separadores */
        hr {
            border: none;
            height: 2px;
            background-color: #ecf0f1;
            margin: 2em 0;
        }
        
        /* Metadados */
        .metadata {
            background-color: #ecf0f1;
            padding: 1em;
            border-radius: 5px;
            margin-bottom: 2em;
            font-size: 0.9em;
        }
        
        .metadata strong {
            color: #2c3e50;
        }
        
        /* Botões de ação (não imprimem) */
        .print-actions {
            position: fixed;
            top: 20px;
            right: 20px;
            background: white;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border: 1px solid #ddd;
        }
        
        .btn {
            display: inline-block;
            padding: 10px 20px;
            margin: 5px;
            background-color: #3498db;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
            cursor: pointer;
            border: none;
            font-size: 14px;
        }
        
        .btn:hover {
            background-color: #2980b9;
        }
        
        .btn-success {
            background-color: #27ae60;
        }
        
        .btn-success:hover {
            background-color: #229954;
        }
        
        /* Seção de transparência */
        .transparency-section {
            background-color: #f8f9fa;
            border: 1px solid #e9ecef;
            border-radius: 8px;
            padding: 1.5em;
            margin: 2em 0;
        }
        
        .transparency-section h3 {
            color: #495057;
            margin-top: 0;
        }
        
        /* Destaque para informações importantes */
        .highlight {
            background-color: #fff3cd;
            border: 1px solid #ffeaa7;
            border-radius: 5px;
            padding: 1em;
            margin: 1em 0;
        }
        
        .warning {
            background-color: #f8d7da;
            border: 1px solid #f5c6cb;
            border-radius: 5px;
            padding: 1em;
            margin: 1em 0;
        }
        
        .info {
            background-color: #d1ecf1;
            border: 1px solid #bee5eb;
            border-radius: 5px;
            padding: 1em;
            margin: 1em 0;
        }
        </style>
        """
    
    def _markdown_to_html(self, markdown_content: str) -> str:
        """Converte markdown básico para HTML."""
        html = markdown_content
        
        # Headers
        html = re.sub(r'^# (.*?)$', r'<h1>\1</h1>', html, flags=re.MULTILINE)
        html = re.sub(r'^## (.*?)$', r'<h2>\1</h2>', html, flags=re.MULTILINE)
        html = re.sub(r'^### (.*?)$', r'<h3>\1</h3>', html, flags=re.MULTILINE)
        html = re.sub(r'^#### (.*?)$', r'<h4>\1</h4>', html, flags=re.MULTILINE)
        
        # Bold e Italic
        html = re.sub(r'\*\*(.*?)\*\*', r'<strong>\1</strong>', html)
        html = re.sub(r'\*(.*?)\*', r'<em>\1</em>', html)
        
        # Code blocks
        html = re.sub(r'```(.*?)```', r'<pre><code>\1</code></pre>', html, flags=re.DOTALL)
        html = re.sub(r'`(.*?)`', r'<code>\1</code>', html)
        
        # Links
        html = re.sub(r'\[([^\]]+)\]\(([^)]+)\)', r'<a href="\2">\1</a>', html)
        
        # Listas
        lines = html.split('\n')
        in_list = False
        result_lines = []
        
        for line in lines:
            if re.match(r'^\s*[-*+]\s+', line):
                if not in_list:
                    result_lines.append('<ul>')
                    in_list = True
                item = re.sub(r'^\s*[-*+]\s+', '', line)
                result_lines.append(f'<li>{item}</li>')
            elif re.match(r'^\s*\d+\.\s+', line):
                if not in_list:
                    result_lines.append('<ol>')
                    in_list = True
                item = re.sub(r'^\s*\d+\.\s+', '', line)
                result_lines.append(f'<li>{item}</li>')
            else:
                if in_list:
                    result_lines.append('</ul>' if result_lines[-2].startswith('<ul>') else '</ol>')
                    in_list = False
                if line.strip():
                    result_lines.append(f'<p>{line}</p>')
                else:
                    result_lines.append('<br>')
        
        if in_list:
            result_lines.append('</ul>')
        
        # Tabelas (básico)
        html = '\n'.join(result_lines)
        
        # Blockquotes
        html = re.sub(r'^> (.*?)$', r'<blockquote>\1</blockquote>', html, flags=re.MULTILINE)
        
        # Separadores
        html = re.sub(r'^---$', r'<hr>', html, flags=re.MULTILINE)
        
        return html
    
    def _create_print_instructions(self) -> str:
        """Cria instruções para impressão."""
        return """
        <div class="print-actions no-print">
            <h4>Converter para PDF</h4>
            <p><strong>Instruções:</strong></p>
            <ol>
                <li>Pressione <kbd>Ctrl+P</kbd> (Windows/Linux) ou <kbd>Cmd+P</kbd> (Mac)</li>
                <li>Selecione "Salvar como PDF" como destino</li>
                <li>Configure margens como "Mínimas"</li>
                <li>Marque "Gráficos de fundo" se disponível</li>
                <li>Clique em "Salvar"</li>
            </ol>
            <button class="btn btn-success" onclick="window.print()">🖨️ Imprimir/Salvar PDF</button>
            <button class="btn" onclick="document.querySelector('.print-actions').style.display='none'">✖️ Fechar</button>
        </div>
        """
    
    def convert_file(self, markdown_file: str, output_file: str = None) -> str:
        """
        Converte um arquivo markdown para HTML.
        
        Args:
            markdown_file: Caminho para o arquivo markdown
            output_file: Caminho para o arquivo HTML de saída (opcional)
            
        Returns:
            Caminho do arquivo HTML gerado
        """
        try:
            # Ler arquivo markdown
            with open(markdown_file, 'r', encoding='utf-8') as f:
                markdown_content = f.read()
            
            # Definir arquivo de saída
            if not output_file:
                base_name = os.path.splitext(markdown_file)[0]
                output_file = f"{base_name}.html"
            
            # Converter para HTML
            html_content = self._markdown_to_html(markdown_content)
            
            # Extrair título do documento
            title_match = re.search(r'<h1>(.*?)</h1>', html_content)
            title = title_match.group(1) if title_match else "Relatório COBOL AI Engine"
            
            # Criar HTML completo
            full_html = f"""<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    {self.css_styles}
</head>
<body>
    {self._create_print_instructions()}
    
    <div class="metadata">
        <strong>Documento:</strong> {title}<br>
        <strong>Gerado em:</strong> {datetime.now().strftime('%d/%m/%Y às %H:%M:%S')}<br>
        <strong>Sistema:</strong> COBOL AI Engine v1.0.2<br>
        <strong>Formato:</strong> HTML para conversão PDF via navegador
    </div>
    
    {html_content}
    
    <hr>
    <div class="metadata">
        <p><strong>Como converter para PDF:</strong></p>
        <ol>
            <li>Pressione <kbd>Ctrl+P</kbd> (Windows/Linux) ou <kbd>Cmd+P</kbd> (Mac)</li>
            <li>Selecione "Salvar como PDF" como impressora/destino</li>
            <li>Configure margens como "Mínimas" para melhor aproveitamento</li>
            <li>Marque "Gráficos de fundo" se a opção estiver disponível</li>
            <li>Clique em "Salvar" e escolha o local para salvar o PDF</li>
        </ol>
        <p><em>Este documento foi otimizado para impressão e conversão PDF via navegador.</em></p>
    </div>
</body>
</html>"""
            
            # Salvar arquivo HTML
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(full_html)
            
            logger.info(f"HTML gerado: {output_file}")
            return output_file
            
        except Exception as e:
            logger.error(f"Erro ao converter {markdown_file} para HTML: {e}")
            raise
    
    def convert_directory(self, directory: str) -> List[str]:
        """
        Converte todos os arquivos .md de um diretório para HTML.
        
        Args:
            directory: Diretório contendo arquivos markdown
            
        Returns:
            Lista de arquivos HTML gerados
        """
        html_files = []
        
        try:
            if not os.path.exists(directory):
                logger.warning(f"Diretório não encontrado: {directory}")
                return html_files
            
            # Encontrar todos os arquivos .md
            md_files = []
            for file in os.listdir(directory):
                if file.endswith('.md'):
                    md_files.append(os.path.join(directory, file))
            
            if not md_files:
                logger.info(f"Nenhum arquivo .md encontrado em {directory}")
                return html_files
            
            # Converter cada arquivo
            for md_file in md_files:
                try:
                    html_file = self.convert_file(md_file)
                    html_files.append(html_file)
                except Exception as e:
                    logger.error(f"Erro ao converter {md_file}: {e}")
            
            # Criar arquivo índice se múltiplos arquivos
            if len(html_files) > 1:
                index_file = self._create_index_file(directory, html_files)
                html_files.insert(0, index_file)
            
            logger.info(f"Conversão concluída: {len(html_files)} arquivo(s) HTML gerado(s)")
            return html_files
            
        except Exception as e:
            logger.error(f"Erro ao converter diretório {directory}: {e}")
            return html_files
    
    def _create_index_file(self, directory: str, html_files: List[str]) -> str:
        """Cria um arquivo índice para múltiplos relatórios."""
        index_file = os.path.join(directory, "index.html")
        
        # Criar lista de arquivos
        file_list = ""
        for html_file in html_files:
            file_name = os.path.basename(html_file)
            display_name = os.path.splitext(file_name)[0]
            file_list += f'<li><a href="{file_name}">{display_name}</a></li>\n'
        
        index_html = f"""<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Índice de Relatórios - COBOL AI Engine</title>
    {self.css_styles}
</head>
<body>
    <h1>Índice de Relatórios COBOL AI Engine</h1>
    
    <div class="metadata">
        <strong>Gerado em:</strong> {datetime.now().strftime('%d/%m/%Y às %H:%M:%S')}<br>
        <strong>Sistema:</strong> COBOL AI Engine v1.0.2<br>
        <strong>Total de relatórios:</strong> {len(html_files)}
    </div>
    
    <h2>Relatórios Disponíveis</h2>
    <ul>
        {file_list}
    </ul>
    
    <div class="info">
        <h3>Como usar:</h3>
        <ol>
            <li>Clique em qualquer relatório acima para visualizá-lo</li>
            <li>Em cada relatório, use <kbd>Ctrl+P</kbd> para converter para PDF</li>
            <li>Configure a impressora como "Salvar como PDF"</li>
            <li>Ajuste as margens para "Mínimas" para melhor resultado</li>
        </ol>
    </div>
</body>
</html>"""
        
        with open(index_file, 'w', encoding='utf-8') as f:
            f.write(index_html)
        
        logger.info(f"Arquivo índice criado: {index_file}")
        return index_file


class HTMLReportGenerator:
    """Gerador de relatórios HTML para o COBOL AI Engine."""
    
    def __init__(self):
        """Inicializa o gerador."""
        self.converter = MarkdownToHTMLConverter()
    
    def generate_html_reports(self, output_dir: str) -> List[str]:
        """
        Gera relatórios HTML a partir dos arquivos markdown.
        
        Args:
            output_dir: Diretório contendo os relatórios markdown
            
        Returns:
            Lista de arquivos HTML gerados
        """
        return self.converter.convert_directory(output_dir)
    
    def generate_single_html(self, markdown_file: str) -> str:
        """
        Gera um único relatório HTML.
        
        Args:
            markdown_file: Arquivo markdown a ser convertido
            
        Returns:
            Caminho do arquivo HTML gerado
        """
        return self.converter.convert_file(markdown_file)


if __name__ == "__main__":
    # Teste do conversor
    import sys
    
    if len(sys.argv) < 2:
        print("Uso: python html_generator.py <arquivo.md ou diretório>")
        sys.exit(1)
    
    path = sys.argv[1]
    converter = MarkdownToHTMLConverter()
    
    if os.path.isfile(path):
        html_file = converter.convert_file(path)
        print(f"HTML gerado: {html_file}")
    elif os.path.isdir(path):
        html_files = converter.convert_directory(path)
        print(f"HTMLs gerados: {len(html_files)}")
        for file in html_files:
            print(f"  - {file}")
    else:
        print(f"Caminho não encontrado: {path}")
