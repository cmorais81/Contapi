#!/usr/bin/env python3
"""
Teste dos dois sistemas de prompts disponíveis
"""

import os
import sys
import logging
import shutil

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

def test_prompts_dual():
    """Testar os dois sistemas de prompts"""
    
    print("=" * 70)
    print("TESTE DOS SISTEMAS DE PROMPTS DUAL")
    print("Comparando: Prompts Originais vs DOC-LEGADO PRO")
    print("=" * 70)
    
    # Configurar logging
    logging.basicConfig(level=logging.WARNING)
    
    # Importar componentes
    from src.core.config import ConfigManager
    from src.providers.enhanced_provider_manager import EnhancedProviderManager
    from src.providers.base_provider import AIRequest
    
    # Programa de teste
    test_program = """
IDENTIFICATION DIVISION.
PROGRAM-ID. CALC-JUROS.

DATA DIVISION.
WORKING-STORAGE SECTION.
01 WS-CAPITAL        PIC 9(7)V99 VALUE ZERO.
01 WS-TAXA           PIC 9(3)V99 VALUE ZERO.
01 WS-TEMPO          PIC 9(3)    VALUE ZERO.
01 WS-JUROS          PIC 9(7)V99 VALUE ZERO.
01 WS-MONTANTE       PIC 9(8)V99 VALUE ZERO.

PROCEDURE DIVISION.
INICIO.
    DISPLAY 'CALCULO DE JUROS SIMPLES'.
    
    DISPLAY 'DIGITE O CAPITAL: '.
    ACCEPT WS-CAPITAL.
    
    DISPLAY 'DIGITE A TAXA (%): '.
    ACCEPT WS-TAXA.
    
    DISPLAY 'DIGITE O TEMPO (MESES): '.
    ACCEPT WS-TEMPO.
    
    COMPUTE WS-JUROS = WS-CAPITAL * WS-TAXA * WS-TEMPO / 100.
    COMPUTE WS-MONTANTE = WS-CAPITAL + WS-JUROS.
    
    DISPLAY 'CAPITAL: ' WS-CAPITAL.
    DISPLAY 'TAXA: ' WS-TAXA '%'.
    DISPLAY 'TEMPO: ' WS-TEMPO ' MESES'.
    DISPLAY 'JUROS: ' WS-JUROS.
    DISPLAY 'MONTANTE: ' WS-MONTANTE.
    
    STOP RUN.
"""
    
    results = {}
    
    # Testar ambos os sistemas
    prompt_systems = [
        {
            'name': 'Prompts Originais',
            'file': 'config/prompts_original.yaml',
            'description': 'Análise técnica tradicional'
        },
        {
            'name': 'DOC-LEGADO PRO', 
            'file': 'config/prompts_doc_legado_pro.yaml',
            'description': 'Metodologia de modernização'
        }
    ]
    
    for i, prompt_system in enumerate(prompt_systems, 1):
        print(f"\n{i}. TESTANDO: {prompt_system['name']}")
        print(f"   Arquivo: {prompt_system['file']}")
        print(f"   Descrição: {prompt_system['description']}")
        print("-" * 50)
        
        try:
            # Fazer backup da configuração atual
            config_backup = 'config/config.yaml.backup'
            shutil.copy('config/config.yaml', config_backup)
            
            # Atualizar configuração para usar o sistema de prompts
            with open('config/config.yaml', 'r') as f:
                config_content = f.read()
            
            # Substituir a linha do prompts_file
            lines = config_content.split('\n')
            for j, line in enumerate(lines):
                if 'prompts_file:' in line:
                    lines[j] = f'    prompts_file: "{prompt_system["file"]}"'
                    break
            
            # Salvar configuração atualizada
            with open('config/config.yaml', 'w') as f:
                f.write('\n'.join(lines))
            
            print(f"   ✅ Configuração atualizada para {prompt_system['name']}")
            
            # Inicializar sistema
            config_manager = ConfigManager()
            provider_manager = EnhancedProviderManager(config_manager.config)
            
            # Criar request
            request = AIRequest(
                prompt=f"Analise este programa COBOL:\n\n{test_program}",
                program_name='CALC-JUROS',
                program_code=test_program,
                context={'test_system': prompt_system['name']}
            )
            
            print("   📤 Enviando para análise...")
            
            # Analisar
            response = provider_manager.analyze(request)
            
            if response.success:
                print(f"   ✅ Análise concluída!")
                print(f"   Provider: {response.model}")
                print(f"   Tokens: {response.tokens_used}")
                print(f"   Tamanho: {len(response.content)} chars")
                
                # Preview da resposta
                preview = response.content[:300] + "..." if len(response.content) > 300 else response.content
                print(f"   Preview: {preview}")
                
                results[prompt_system['name']] = {
                    'success': True,
                    'provider': response.model,
                    'tokens': response.tokens_used,
                    'content_size': len(response.content),
                    'preview': preview
                }
            else:
                print(f"   ❌ Falha na análise: {response.error_message}")
                results[prompt_system['name']] = {
                    'success': False,
                    'error': response.error_message
                }
            
            # Restaurar configuração
            shutil.move(config_backup, 'config/config.yaml')
            
        except Exception as e:
            print(f"   ❌ ERRO: {e}")
            results[prompt_system['name']] = {
                'success': False,
                'error': str(e)
            }
            
            # Restaurar configuração em caso de erro
            if os.path.exists(config_backup):
                shutil.move(config_backup, 'config/config.yaml')
    
    # Resumo comparativo
    print("\n" + "=" * 70)
    print("RESUMO COMPARATIVO")
    print("=" * 70)
    
    print("| Sistema | Status | Provider | Tokens | Tamanho |")
    print("|---------|--------|----------|--------|---------|")
    
    for system_name, result in results.items():
        if result['success']:
            status = "✅ Sucesso"
            provider = result['provider']
            tokens = result['tokens']
            size = result['content_size']
        else:
            status = "❌ Falha"
            provider = "N/A"
            tokens = "N/A"
            size = "N/A"
        
        print(f"| {system_name} | {status} | {provider} | {tokens} | {size} |")
    
    print("\n📋 COMO ESCOLHER:")
    print("• Prompts Originais: Documentação técnica completa")
    print("• DOC-LEGADO PRO: Modernização e extração de regras")
    
    print("\n⚙️ COMO ALTERAR:")
    print("Edite config/config.yaml e altere a linha:")
    print("prompts_file: \"config/prompts_original.yaml\"")
    print("ou")
    print("prompts_file: \"config/prompts_doc_legado_pro.yaml\"")
    
    return all(result['success'] for result in results.values())

if __name__ == "__main__":
    success = test_prompts_dual()
    
    print("\n" + "=" * 70)
    if success:
        print("✅ TESTE CONCLUÍDO COM SUCESSO!")
        print("Ambos os sistemas de prompts estão funcionando")
    else:
        print("❌ ALGUNS TESTES FALHARAM!")
        print("Verifique os logs acima")
    print("=" * 70)
    
    sys.exit(0 if success else 1)
