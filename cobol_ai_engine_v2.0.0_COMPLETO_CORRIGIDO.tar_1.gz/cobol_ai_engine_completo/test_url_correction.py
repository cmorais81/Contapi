#!/usr/bin/env python3
"""
Teste específico para verificar se a correção da URL resolveu o problema
"""

import os
import sys
import json
import logging

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

def test_url_correction():
    """Testar se a correção da URL resolveu"""
    
    print("=" * 80)
    print("TESTE: CORREÇÃO DA URL DE AUTENTICAÇÃO")
    print("=" * 80)
    
    # Verificar credenciais
    client_id = os.getenv('LUZIA_CLIENT_ID')
    client_secret = os.getenv('LUZIA_CLIENT_SECRET')
    
    if not client_id or not client_secret:
        print("❌ Credenciais não definidas")
        print("   Execute:")
        print("   export LUZIA_CLIENT_ID='seu_client_id'")
        print("   export LUZIA_CLIENT_SECRET='seu_client_secret'")
        return False
    
    print(f"✅ Credenciais definidas")
    print(f"   Client ID: {client_id[:10]}...{client_id[-5:]}")
    
    try:
        # Importar provider corrigido
        from src.providers.luzia_provider import LuziaProvider
        from src.providers.base_provider import AIRequest
        
        print("\n1. TESTANDO PROVIDER CORRIGIDO")
        print("-" * 50)
        
        # Configuração
        config = {
            'client_id': client_id,
            'client_secret': client_secret,
            'timeout': 30.0
        }
        
        # Criar provider
        provider = LuziaProvider(config)
        
        print(f"URL de autenticação: {provider.auth_url}")
        print(f"URL da API: {provider.base_url}")
        
        # Testar obtenção de token
        print("\n2. TESTANDO OBTENÇÃO DE TOKEN")
        print("-" * 50)
        
        try:
            token = provider.get_token()
            print(f"✅ Token obtido com sucesso!")
            print(f"   Tamanho: {len(token)} chars")
            print(f"   Início: {token[:20]}...")
            print(f"   Fim: ...{token[-10:]}")
            
            # Testar análise simples
            print("\n3. TESTANDO ANÁLISE SIMPLES")
            print("-" * 50)
            
            request = AIRequest(
                prompt="Diga apenas 'teste ok'",
                program_name="TESTE",
                program_code="IDENTIFICATION DIVISION.",
                context={}
            )
            
            print("📤 Enviando requisição de teste...")
            
            response = provider.analyze(request)
            
            if response.success:
                print("✅ ANÁLISE BEM-SUCEDIDA!")
                print(f"   Modelo: {response.model}")
                print(f"   Tokens: {response.tokens_used}")
                print(f"   Tempo: {response.response_time:.2f}s")
                print(f"   Conteúdo: {response.content[:100]}...")
                return True
            else:
                print("❌ ANÁLISE FALHOU")
                print(f"   Erro: {response.content}")
                return False
                
        except Exception as e:
            print(f"❌ Erro durante teste: {e}")
            import traceback
            traceback.print_exc()
            return False
            
    except Exception as e:
        print(f"❌ Erro ao importar provider: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = test_url_correction()
    
    print("\n" + "=" * 80)
    if success:
        print("✅ CORREÇÃO DA URL FUNCIONOU!")
        print("   O provider LuzIA está operacional")
    else:
        print("❌ AINDA HÁ PROBLEMAS")
        print("   Verificar logs acima para detalhes")
    print("=" * 80)
