#!/usr/bin/env python3
"""
Data Governance API - Main Application
Following SOLID principles and implementing comprehensive data governance

Author: Carlos Morais
"""

import uvicorn
from fastapi import FastAPI, HTTPException, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.responses import JSONResponse
from fastapi.openapi.docs import get_swagger_ui_html
from fastapi.openapi.utils import get_openapi
import logging
import time
from typing import Dict, Any

# Import configurations
from src.app.config.global_config import settings

# Import utilities
from src.app.utils.exceptions import (
    BaseDataGovernanceException, 
    EXCEPTION_STATUS_MAP
)
from src.app.utils.database import create_tables

# Import routers
from src.app.resources.routers import api_router

# Configure logging
logging.basicConfig(
    level=getattr(logging, settings.LOG_LEVEL),
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

# Create FastAPI application
app = FastAPI(
    title="Data Governance API",
    description="Enterprise Data Governance API following SOLID principles",
    version="1.0.0",
    docs_url="/docs" if settings.ENVIRONMENT != "production" else None,
    redoc_url="/redoc" if settings.ENVIRONMENT != "production" else None,
    openapi_url="/openapi.json"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_HOSTS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Add trusted host middleware
if settings.ALLOWED_HOSTS:
    app.add_middleware(
        TrustedHostMiddleware,
        allowed_hosts=settings.ALLOWED_HOSTS
    )


@app.middleware("http")
async def add_process_time_header(request: Request, call_next):
    """
    Add process time header to responses.
    
    Following SOLID principles:
    - SRP: Single responsibility for timing middleware
    """
    start_time = time.time()
    response = await call_next(request)
    process_time = time.time() - start_time
    response.headers["X-Process-Time"] = str(process_time)
    return response


@app.exception_handler(BaseDataGovernanceException)
async def data_governance_exception_handler(request: Request, exc: BaseDataGovernanceException):
    """
    Handle custom data governance exceptions.
    
    Following SOLID principles:
    - SRP: Single responsibility for exception handling
    - OCP: Open for extension with new exception types
    """
    status_code = EXCEPTION_STATUS_MAP.get(type(exc), 500)
    
    logger.error(f"Data governance error: {exc.error_id} - {exc.message}", extra={
        "error_id": exc.error_id,
        "error_code": exc.error_code,
        "details": exc.details
    })
    
    return JSONResponse(
        status_code=status_code,
        content=exc.to_dict()
    )


@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception):
    """
    Handle general exceptions.
    
    Following SOLID principles:
    - SRP: Single responsibility for general exception handling
    """
    logger.error(f"Unhandled exception: {str(exc)}", exc_info=True)
    
    return JSONResponse(
        status_code=500,
        content={
            "error_code": "INTERNAL_SERVER_ERROR",
            "message": "An internal server error occurred",
            "user_message": "Something went wrong. Please try again later."
        }
    )


@app.on_event("startup")
async def startup_event():
    """
    Application startup event.
    
    Following SOLID principles:
    - SRP: Single responsibility for startup tasks
    """
    logger.info("Starting Data Governance API...")
    
    # Create database tables
    try:
        create_tables()
        logger.info("Database tables created successfully")
    except Exception as e:
        logger.error(f"Failed to create database tables: {str(e)}")
        raise
    
    logger.info("Data Governance API started successfully")


@app.on_event("shutdown")
async def shutdown_event():
    """
    Application shutdown event.
    
    Following SOLID principles:
    - SRP: Single responsibility for shutdown tasks
    """
    logger.info("Shutting down Data Governance API...")


@app.get("/", tags=["Health"])
async def root():
    """
    Root endpoint.
    
    Following SOLID principles:
    - SRP: Single responsibility for root response
    """
    return {
        "message": "Data Governance API",
        "version": "1.0.0",
        "status": "healthy",
        "environment": settings.ENVIRONMENT
    }


@app.get("/health", tags=["Health"])
async def health_check():
    """
    Health check endpoint.
    
    Following SOLID principles:
    - SRP: Single responsibility for health checking
    """
    return {
        "status": "healthy",
        "timestamp": time.time(),
        "version": "1.0.0",
        "environment": settings.ENVIRONMENT,
        "database": "connected"  # In real app, check actual DB connection
    }


@app.get("/metrics", tags=["Monitoring"])
async def get_metrics():
    """
    Get application metrics.
    
    Following SOLID principles:
    - SRP: Single responsibility for metrics collection
    """
    # In a real application, you would collect actual metrics
    return {
        "requests_total": 0,
        "requests_per_second": 0,
        "response_time_avg": 0,
        "error_rate": 0,
        "active_connections": 0
    }


# Custom OpenAPI schema
def custom_openapi():
    """
    Custom OpenAPI schema generation.
    
    Following SOLID principles:
    - SRP: Single responsibility for OpenAPI schema
    """
    if app.openapi_schema:
        return app.openapi_schema
    
    openapi_schema = get_openapi(
        title="Data Governance API",
        version="1.0.0",
        description="""
        ## Enterprise Data Governance API
        
        This API provides comprehensive data governance capabilities following SOLID principles:
        
        ### Features
        - **Data Objects Management**: Complete CRUD operations for data objects
        - **Data Contracts**: Define and manage data contracts
        - **Quality Metrics**: Monitor and track data quality
        - **Data Lineage**: Track data flow and dependencies
        - **Access Policies**: Manage data access and security
        - **Audit Logging**: Complete audit trail for all operations
        - **Analytics & Reporting**: Governance dashboards and insights
        
        ### Architecture
        - **SOLID Principles**: Single Responsibility, Open/Closed, Liskov Substitution, Interface Segregation, Dependency Inversion
        - **Clean Architecture**: Separation of concerns with clear layers
        - **Error Handling**: Structured exception handling with detailed error responses
        - **Authentication**: JWT-based authentication with role-based access control
        - **Validation**: Comprehensive input validation and business rule enforcement
        
        ### Integration
        - **Unity Catalog**: Native integration with Databricks Unity Catalog
        - **Informatica Axon**: Support for Informatica Axon integration
        - **External Systems**: Extensible integration framework
        """,
        routes=app.routes,
    )
    
    # Add security schemes
    openapi_schema["components"]["securitySchemes"] = {
        "BearerAuth": {
            "type": "http",
            "scheme": "bearer",
            "bearerFormat": "JWT"
        }
    }
    
    # Add global security
    openapi_schema["security"] = [{"BearerAuth": []}]
    
    app.openapi_schema = openapi_schema
    return app.openapi_schema


app.openapi = custom_openapi

# Include API routers
app.include_router(api_router, prefix="/api/v1")


if __name__ == "__main__":
    """
    Run the application.
    
    Following SOLID principles:
    - SRP: Single responsibility for application execution
    """
    uvicorn.run(
        "main:app",
        host=settings.HOST,
        port=settings.PORT,
        reload=settings.ENVIRONMENT == "development",
        log_level=settings.LOG_LEVEL.lower(),
        access_log=True
    )

