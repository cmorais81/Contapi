"""
Abstract Interfaces for Data Governance Services
Following SOLID principles - Interface Segregation and Dependency Inversion

Author: Carlos Morais
"""

from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional, Union
from datetime import datetime


class IDataObjectRepository(ABC):
    """
    Interface for Data Object Repository.
    
    Following SOLID principles:
    - ISP: Interface segregation - specific to data objects
    - DIP: Dependency inversion - abstract interface
    """
    
    @abstractmethod
    async def create(self, data_object: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new data object."""
        pass
    
    @abstractmethod
    async def get_by_id(self, object_id: int) -> Optional[Dict[str, Any]]:
        """Get data object by ID."""
        pass
    
    @abstractmethod
    async def update(self, object_id: int, data_object: Dict[str, Any]) -> Dict[str, Any]:
        """Update data object."""
        pass
    
    @abstractmethod
    async def delete(self, object_id: int) -> bool:
        """Delete data object."""
        pass
    
    @abstractmethod
    async def list_with_filters(self, filters: Dict[str, Any], page: int, size: int) -> Dict[str, Any]:
        """List data objects with filters and pagination."""
        pass


class IDataContractRepository(ABC):
    """
    Interface for Data Contract Repository.
    
    Following SOLID principles:
    - ISP: Interface segregation - specific to contracts
    - DIP: Dependency inversion - abstract interface
    """
    
    @abstractmethod
    async def create(self, contract: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new data contract."""
        pass
    
    @abstractmethod
    async def get_by_id(self, contract_id: int) -> Optional[Dict[str, Any]]:
        """Get contract by ID."""
        pass
    
    @abstractmethod
    async def validate_contract(self, contract_id: int) -> Dict[str, Any]:
        """Validate contract against data object."""
        pass


class IQualityMetricsRepository(ABC):
    """
    Interface for Quality Metrics Repository.
    
    Following SOLID principles:
    - ISP: Interface segregation - specific to quality metrics
    - DIP: Dependency inversion - abstract interface
    """
    
    @abstractmethod
    async def create_metric(self, metric: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new quality metric."""
        pass
    
    @abstractmethod
    async def get_metrics_for_object(self, object_id: int, days: int = 30) -> List[Dict[str, Any]]:
        """Get quality metrics for a data object."""
        pass
    
    @abstractmethod
    async def get_aggregated_metrics(self, object_id: int) -> Dict[str, Any]:
        """Get aggregated quality metrics."""
        pass


class ILineageRepository(ABC):
    """
    Interface for Data Lineage Repository.
    
    Following SOLID principles:
    - ISP: Interface segregation - specific to lineage
    - DIP: Dependency inversion - abstract interface
    """
    
    @abstractmethod
    async def create_lineage(self, lineage: Dict[str, Any]) -> Dict[str, Any]:
        """Create lineage relationship."""
        pass
    
    @abstractmethod
    async def get_upstream_lineage(self, object_id: int, depth: int = 5) -> List[Dict[str, Any]]:
        """Get upstream lineage."""
        pass
    
    @abstractmethod
    async def get_downstream_lineage(self, object_id: int, depth: int = 5) -> List[Dict[str, Any]]:
        """Get downstream lineage."""
        pass


class IAccessPolicyRepository(ABC):
    """
    Interface for Access Policy Repository.
    
    Following SOLID principles:
    - ISP: Interface segregation - specific to access policies
    - DIP: Dependency inversion - abstract interface
    """
    
    @abstractmethod
    async def create_policy(self, policy: Dict[str, Any]) -> Dict[str, Any]:
        """Create access policy."""
        pass
    
    @abstractmethod
    async def get_policies_for_object(self, object_id: int) -> List[Dict[str, Any]]:
        """Get access policies for data object."""
        pass
    
    @abstractmethod
    async def evaluate_access(self, object_id: int, user_id: int, action: str) -> bool:
        """Evaluate access permission."""
        pass


class IAuditLogger(ABC):
    """
    Interface for Audit Logging.
    
    Following SOLID principles:
    - ISP: Interface segregation - specific to audit logging
    - DIP: Dependency inversion - abstract interface
    """
    
    @abstractmethod
    async def log_event(self, event: Dict[str, Any]) -> None:
        """Log audit event."""
        pass
    
    @abstractmethod
    async def get_audit_trail(self, resource_id: str, resource_type: str) -> List[Dict[str, Any]]:
        """Get audit trail for resource."""
        pass


class INotificationService(ABC):
    """
    Interface for Notification Service.
    
    Following SOLID principles:
    - ISP: Interface segregation - specific to notifications
    - DIP: Dependency inversion - abstract interface
    """
    
    @abstractmethod
    async def send_notification(self, notification: Dict[str, Any]) -> None:
        """Send notification."""
        pass
    
    @abstractmethod
    async def send_quality_alert(self, object_id: int, metric: Dict[str, Any]) -> None:
        """Send quality alert."""
        pass


class IMetadataService(ABC):
    """
    Interface for Metadata Management Service.
    
    Following SOLID principles:
    - ISP: Interface segregation - specific to metadata
    - DIP: Dependency inversion - abstract interface
    """
    
    @abstractmethod
    async def extract_metadata(self, object_id: int) -> Dict[str, Any]:
        """Extract metadata from data object."""
        pass
    
    @abstractmethod
    async def update_metadata(self, object_id: int, metadata: Dict[str, Any]) -> Dict[str, Any]:
        """Update metadata for data object."""
        pass
    
    @abstractmethod
    async def get_metadata_history(self, object_id: int) -> List[Dict[str, Any]]:
        """Get metadata change history."""
        pass


class IExternalIntegrationService(ABC):
    """
    Interface for External Integration Service.
    
    Following SOLID principles:
    - ISP: Interface segregation - specific to external integrations
    - DIP: Dependency inversion - abstract interface
    """
    
    @abstractmethod
    async def sync_with_unity_catalog(self, catalog_name: str) -> Dict[str, Any]:
        """Sync with Unity Catalog."""
        pass
    
    @abstractmethod
    async def sync_with_informatica_axon(self) -> Dict[str, Any]:
        """Sync with Informatica Axon."""
        pass
    
    @abstractmethod
    async def export_to_external_system(self, system: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """Export data to external system."""
        pass


class ISearchService(ABC):
    """
    Interface for Search Service.
    
    Following SOLID principles:
    - ISP: Interface segregation - specific to search
    - DIP: Dependency inversion - abstract interface
    """
    
    @abstractmethod
    async def search_data_objects(self, query: str, filters: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Search data objects."""
        pass
    
    @abstractmethod
    async def get_search_suggestions(self, partial_query: str) -> List[str]:
        """Get search suggestions."""
        pass
    
    @abstractmethod
    async def index_data_object(self, object_id: int) -> None:
        """Index data object for search."""
        pass


class IAnalyticsService(ABC):
    """
    Interface for Analytics Service.
    
    Following SOLID principles:
    - ISP: Interface segregation - specific to analytics
    - DIP: Dependency inversion - abstract interface
    """
    
    @abstractmethod
    async def get_governance_dashboard(self) -> Dict[str, Any]:
        """Get governance dashboard data."""
        pass
    
    @abstractmethod
    async def get_quality_trends(self, days: int = 30) -> Dict[str, Any]:
        """Get quality trends."""
        pass
    
    @abstractmethod
    async def get_usage_analytics(self, object_id: Optional[int] = None) -> Dict[str, Any]:
        """Get usage analytics."""
        pass


class IValidationService(ABC):
    """
    Interface for Validation Service.
    
    Following SOLID principles:
    - ISP: Interface segregation - specific to validation
    - SRP: Single responsibility for validation logic
    """
    
    @abstractmethod
    async def validate_data_object(self, data_object: Dict[str, Any]) -> Dict[str, Any]:
        """Validate data object."""
        pass
    
    @abstractmethod
    async def validate_schema(self, schema: Dict[str, Any]) -> Dict[str, Any]:
        """Validate schema definition."""
        pass
    
    @abstractmethod
    async def validate_contract(self, contract: Dict[str, Any]) -> Dict[str, Any]:
        """Validate data contract."""
        pass


class ICacheService(ABC):
    """
    Interface for Cache Service.
    
    Following SOLID principles:
    - ISP: Interface segregation - specific to caching
    - DIP: Dependency inversion - abstract interface
    """
    
    @abstractmethod
    async def get(self, key: str) -> Optional[Any]:
        """Get value from cache."""
        pass
    
    @abstractmethod
    async def set(self, key: str, value: Any, ttl: int = 3600) -> None:
        """Set value in cache."""
        pass
    
    @abstractmethod
    async def delete(self, key: str) -> None:
        """Delete value from cache."""
        pass
    
    @abstractmethod
    async def clear_pattern(self, pattern: str) -> None:
        """Clear cache entries matching pattern."""
        pass

