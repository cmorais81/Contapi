"""
Data Objects Service Implementation
Following SOLID principles rigorously

Author: Carlos Morais
"""

from typing import Dict, Any, List, Optional
from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, desc, func

from .interfaces import (
    IDataObjectRepository, 
    IAuditLogger, 
    INotificationService,
    IValidationService,
    ICacheService
)
from ..models.data_models import DataObject, User, QualityMetric
from ..utils.exceptions import (
    EntityNotFoundError, 
    ValidationError, 
    BusinessRuleViolationError
)


class DataObjectsService:
    """
    Data Objects Service implementing business logic.
    
    Following SOLID principles:
    - SRP: Single responsibility for data object business logic
    - OCP: Open for extension through dependency injection
    - LSP: Liskov substitution through interface implementation
    - ISP: Interface segregation through specific interfaces
    - DIP: Dependency inversion through constructor injection
    """
    
    def __init__(
        self,
        db: Session,
        audit_logger: Optional[IAuditLogger] = None,
        notification_service: Optional[INotificationService] = None,
        validation_service: Optional[IValidationService] = None,
        cache_service: Optional[ICacheService] = None
    ):
        """
        Initialize service with dependencies.
        
        Following SOLID principles:
        - DIP: Dependency injection of abstractions
        """
        self.db = db
        self.audit_logger = audit_logger
        self.notification_service = notification_service
        self.validation_service = validation_service
        self.cache_service = cache_service
    
    async def create_object(self, data_object: Dict[str, Any], user_id: int) -> Dict[str, Any]:
        """
        Create a new data object.
        
        Following SOLID principles:
        - SRP: Single responsibility for object creation
        - OCP: Open for extension with new validation rules
        """
        # Validate input
        if self.validation_service:
            validation_result = await self.validation_service.validate_data_object(data_object)
            if not validation_result.get("valid", False):
                raise ValidationError(f"Validation failed: {validation_result.get('errors')}")
        
        # Check for duplicates
        existing = self.db.query(DataObject).filter(
            and_(
                DataObject.name == data_object.get("name"),
                DataObject.catalog_name == data_object.get("catalog_name"),
                DataObject.database_name == data_object.get("database_name"),
                DataObject.table_name == data_object.get("table_name")
            )
        ).first()
        
        if existing:
            raise BusinessRuleViolationError("Data object with this name and location already exists")
        
        # Create object
        db_object = DataObject(
            name=data_object["name"],
            description=data_object.get("description"),
            object_type=data_object["object_type"],
            catalog_name=data_object.get("catalog_name"),
            database_name=data_object.get("database_name"),
            schema_name=data_object.get("schema_name"),
            table_name=data_object.get("table_name"),
            full_path=data_object.get("full_path"),
            source_system=data_object.get("source_system"),
            unity_catalog_id=data_object.get("unity_catalog_id"),
            unity_catalog_metastore=data_object.get("unity_catalog_metastore"),
            unity_catalog_workspace=data_object.get("unity_catalog_workspace"),
            owner_id=data_object.get("owner_id", user_id),
            steward_id=data_object.get("steward_id"),
            security_classification=data_object.get("security_classification", "internal"),
            sensitivity_level=data_object.get("sensitivity_level", "low"),
            schema_definition=data_object.get("schema_definition"),
            business_metadata=data_object.get("business_metadata"),
            technical_metadata=data_object.get("technical_metadata"),
            retention_days=data_object.get("retention_days", 2555),
            size_bytes=data_object.get("size_bytes"),
            row_count=data_object.get("row_count"),
            column_count=data_object.get("column_count")
        )
        
        self.db.add(db_object)
        self.db.commit()
        self.db.refresh(db_object)
        
        # Log audit event
        if self.audit_logger:
            await self.audit_logger.log_event({
                "event_type": "data_object",
                "event_action": "create",
                "user_id": user_id,
                "resource_type": "data_object",
                "resource_id": str(db_object.id),
                "resource_name": db_object.name,
                "event_details": data_object,
                "success": True
            })
        
        # Clear cache
        if self.cache_service:
            await self.cache_service.clear_pattern("data_objects:*")
        
        return self._object_to_dict(db_object)
    
    async def get_object(
        self, 
        object_id: int, 
        include_lineage: bool = False,
        include_quality: bool = False,
        include_contracts: bool = False,
        include_policies: bool = False
    ) -> Dict[str, Any]:
        """
        Get data object by ID with optional related data.
        
        Following SOLID principles:
        - SRP: Single responsibility for object retrieval
        - OCP: Open for extension with new include options
        """
        # Check cache first
        cache_key = f"data_object:{object_id}:{include_lineage}:{include_quality}:{include_contracts}:{include_policies}"
        if self.cache_service:
            cached_result = await self.cache_service.get(cache_key)
            if cached_result:
                return cached_result
        
        # Get object from database
        db_object = self.db.query(DataObject).filter(DataObject.id == object_id).first()
        if not db_object:
            raise EntityNotFoundError(f"Data object with ID {object_id} not found")
        
        result = self._object_to_dict(db_object)
        
        # Include related data if requested
        if include_quality:
            result["quality_metrics"] = await self._get_quality_metrics(object_id)
        
        if include_lineage:
            result["lineage"] = await self._get_lineage(object_id)
        
        if include_contracts:
            result["contracts"] = await self._get_contracts(object_id)
        
        if include_policies:
            result["access_policies"] = await self._get_access_policies(object_id)
        
        # Cache result
        if self.cache_service:
            await self.cache_service.set(cache_key, result, ttl=300)  # 5 minutes
        
        return result
    
    async def update_object(self, object_id: int, data_object: Dict[str, Any], user_id: int) -> Dict[str, Any]:
        """
        Update data object.
        
        Following SOLID principles:
        - SRP: Single responsibility for object updates
        - OCP: Open for extension with new update fields
        """
        # Get existing object
        db_object = self.db.query(DataObject).filter(DataObject.id == object_id).first()
        if not db_object:
            raise EntityNotFoundError(f"Data object with ID {object_id} not found")
        
        # Store before state for audit
        before_state = self._object_to_dict(db_object)
        
        # Validate update
        if self.validation_service:
            validation_result = await self.validation_service.validate_data_object(data_object)
            if not validation_result.get("valid", False):
                raise ValidationError(f"Validation failed: {validation_result.get('errors')}")
        
        # Update fields
        for field, value in data_object.items():
            if hasattr(db_object, field) and field not in ["id", "data_criacao"]:
                setattr(db_object, field, value)
        
        self.db.commit()
        self.db.refresh(db_object)
        
        # Log audit event
        if self.audit_logger:
            await self.audit_logger.log_event({
                "event_type": "data_object",
                "event_action": "update",
                "user_id": user_id,
                "resource_type": "data_object",
                "resource_id": str(object_id),
                "resource_name": db_object.name,
                "before_state": before_state,
                "after_state": self._object_to_dict(db_object),
                "success": True
            })
        
        # Clear cache
        if self.cache_service:
            await self.cache_service.clear_pattern(f"data_object:{object_id}:*")
            await self.cache_service.clear_pattern("data_objects:*")
        
        return self._object_to_dict(db_object)
    
    async def delete_object(self, object_id: int, force: bool = False, user_id: int = None) -> None:
        """
        Delete data object.
        
        Following SOLID principles:
        - SRP: Single responsibility for object deletion
        """
        # Get existing object
        db_object = self.db.query(DataObject).filter(DataObject.id == object_id).first()
        if not db_object:
            raise EntityNotFoundError(f"Data object with ID {object_id} not found")
        
        # Check dependencies if not force delete
        if not force:
            # Check for active contracts
            active_contracts = self.db.query(DataContract).filter(
                and_(
                    DataContract.data_object_id == object_id,
                    DataContract.status == "active"
                )
            ).count()
            
            if active_contracts > 0:
                raise BusinessRuleViolationError(
                    f"Cannot delete data object with {active_contracts} active contracts. Use force=true to override."
                )
        
        # Store state for audit
        before_state = self._object_to_dict(db_object)
        
        # Delete object
        self.db.delete(db_object)
        self.db.commit()
        
        # Log audit event
        if self.audit_logger:
            await self.audit_logger.log_event({
                "event_type": "data_object",
                "event_action": "delete",
                "user_id": user_id,
                "resource_type": "data_object",
                "resource_id": str(object_id),
                "resource_name": before_state.get("name"),
                "before_state": before_state,
                "event_details": {"force": force},
                "success": True
            })
        
        # Clear cache
        if self.cache_service:
            await self.cache_service.clear_pattern(f"data_object:{object_id}:*")
            await self.cache_service.clear_pattern("data_objects:*")
    
    async def list_objects(self, page: int = 1, size: int = 20, filters: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        List data objects with filtering and pagination.
        
        Following SOLID principles:
        - SRP: Single responsibility for object listing
        - OCP: Open for extension with new filters
        """
        if filters is None:
            filters = {}
        
        # Build query
        query = self.db.query(DataObject)
        
        # Apply filters
        if filters.get("object_type"):
            query = query.filter(DataObject.object_type == filters["object_type"])
        
        if filters.get("catalog_name"):
            query = query.filter(DataObject.catalog_name == filters["catalog_name"])
        
        if filters.get("database_name"):
            query = query.filter(DataObject.database_name == filters["database_name"])
        
        if filters.get("security_classification"):
            query = query.filter(DataObject.security_classification == filters["security_classification"])
        
        if filters.get("quality_status"):
            query = query.filter(DataObject.quality_status == filters["quality_status"])
        
        if filters.get("owner_id"):
            query = query.filter(DataObject.owner_id == filters["owner_id"])
        
        if filters.get("steward_id"):
            query = query.filter(DataObject.steward_id == filters["steward_id"])
        
        if filters.get("search"):
            search_term = f"%{filters['search']}%"
            query = query.filter(
                or_(
                    DataObject.name.ilike(search_term),
                    DataObject.description.ilike(search_term)
                )
            )
        
        # Get total count
        total = query.count()
        
        # Apply pagination
        offset = (page - 1) * size
        objects = query.offset(offset).limit(size).all()
        
        # Convert to dict
        items = [self._object_to_dict(obj) for obj in objects]
        
        return {
            "items": items,
            "total": total,
            "page": page,
            "size": size,
            "pages": (total + size - 1) // size
        }
    
    async def update_schema(
        self, 
        object_id: int, 
        schema_definition: Dict[str, Any], 
        validate_compatibility: bool = True,
        user_id: int = None
    ) -> Dict[str, Any]:
        """
        Update data object schema.
        
        Following SOLID principles:
        - SRP: Single responsibility for schema updates
        """
        # Get existing object
        db_object = self.db.query(DataObject).filter(DataObject.id == object_id).first()
        if not db_object:
            raise EntityNotFoundError(f"Data object with ID {object_id} not found")
        
        # Validate schema compatibility if requested
        if validate_compatibility and db_object.schema_definition:
            compatibility_result = await self._validate_schema_compatibility(
                db_object.schema_definition, 
                schema_definition
            )
            if not compatibility_result.get("compatible", False):
                raise ValidationError(f"Schema incompatible: {compatibility_result.get('issues')}")
        
        # Update schema
        old_schema = db_object.schema_definition
        db_object.schema_definition = schema_definition
        
        # Update column count if provided
        if "columns" in schema_definition:
            db_object.column_count = len(schema_definition["columns"])
        
        self.db.commit()
        self.db.refresh(db_object)
        
        # Log audit event
        if self.audit_logger:
            await self.audit_logger.log_event({
                "event_type": "data_object",
                "event_action": "schema_update",
                "user_id": user_id,
                "resource_type": "data_object",
                "resource_id": str(object_id),
                "resource_name": db_object.name,
                "before_state": {"schema": old_schema},
                "after_state": {"schema": schema_definition},
                "success": True
            })
        
        return {
            "object_id": object_id,
            "schema_definition": schema_definition,
            "compatibility_checked": validate_compatibility,
            "updated_at": datetime.utcnow().isoformat()
        }
    
    async def get_schema(self, object_id: int, version: Optional[str] = None) -> Dict[str, Any]:
        """
        Get data object schema.
        
        Following SOLID principles:
        - SRP: Single responsibility for schema retrieval
        """
        db_object = self.db.query(DataObject).filter(DataObject.id == object_id).first()
        if not db_object:
            raise EntityNotFoundError(f"Data object with ID {object_id} not found")
        
        return {
            "object_id": object_id,
            "schema_definition": db_object.schema_definition,
            "column_count": db_object.column_count,
            "last_updated": db_object.data_atualizacao.isoformat() if db_object.data_atualizacao else None
        }
    
    async def classify_object(
        self, 
        object_id: int, 
        classification: Dict[str, Any], 
        auto_classify: bool = False,
        user_id: int = None
    ) -> Dict[str, Any]:
        """
        Classify data object for security and sensitivity.
        
        Following SOLID principles:
        - SRP: Single responsibility for classification
        """
        db_object = self.db.query(DataObject).filter(DataObject.id == object_id).first()
        if not db_object:
            raise EntityNotFoundError(f"Data object with ID {object_id} not found")
        
        # Auto-classify if requested
        if auto_classify:
            classification = await self._auto_classify_object(db_object)
        
        # Update classification
        old_classification = {
            "security_classification": db_object.security_classification,
            "sensitivity_level": db_object.sensitivity_level
        }
        
        if "security_classification" in classification:
            db_object.security_classification = classification["security_classification"]
        
        if "sensitivity_level" in classification:
            db_object.sensitivity_level = classification["sensitivity_level"]
        
        self.db.commit()
        self.db.refresh(db_object)
        
        # Log audit event
        if self.audit_logger:
            await self.audit_logger.log_event({
                "event_type": "data_object",
                "event_action": "classify",
                "user_id": user_id,
                "resource_type": "data_object",
                "resource_id": str(object_id),
                "resource_name": db_object.name,
                "before_state": old_classification,
                "after_state": classification,
                "event_details": {"auto_classify": auto_classify},
                "success": True
            })
        
        return {
            "object_id": object_id,
            "classification": {
                "security_classification": db_object.security_classification,
                "sensitivity_level": db_object.sensitivity_level
            },
            "auto_classified": auto_classify,
            "updated_at": datetime.utcnow().isoformat()
        }
    
    def _object_to_dict(self, db_object: DataObject) -> Dict[str, Any]:
        """
        Convert SQLAlchemy object to dictionary.
        
        Following SOLID principles:
        - SRP: Single responsibility for object conversion
        """
        return {
            "id": db_object.id,
            "name": db_object.name,
            "description": db_object.description,
            "object_type": db_object.object_type,
            "catalog_name": db_object.catalog_name,
            "database_name": db_object.database_name,
            "schema_name": db_object.schema_name,
            "table_name": db_object.table_name,
            "full_path": db_object.full_path,
            "source_system": db_object.source_system,
            "unity_catalog_id": db_object.unity_catalog_id,
            "unity_catalog_metastore": db_object.unity_catalog_metastore,
            "unity_catalog_workspace": db_object.unity_catalog_workspace,
            "owner_id": db_object.owner_id,
            "steward_id": db_object.steward_id,
            "security_classification": db_object.security_classification.value if db_object.security_classification else None,
            "sensitivity_level": db_object.sensitivity_level.value if db_object.sensitivity_level else None,
            "status": db_object.status.value if db_object.status else None,
            "quality_score": db_object.quality_score,
            "quality_status": db_object.quality_status.value if db_object.quality_status else None,
            "schema_definition": db_object.schema_definition,
            "business_metadata": db_object.business_metadata,
            "technical_metadata": db_object.technical_metadata,
            "access_count": db_object.access_count,
            "last_accessed": db_object.last_accessed.isoformat() if db_object.last_accessed else None,
            "popularity_score": db_object.popularity_score,
            "retention_days": db_object.retention_days,
            "expiration_date": db_object.expiration_date.isoformat() if db_object.expiration_date else None,
            "lifecycle_stage": db_object.lifecycle_stage,
            "size_bytes": db_object.size_bytes,
            "row_count": db_object.row_count,
            "column_count": db_object.column_count,
            "data_criacao": db_object.data_criacao.isoformat() if db_object.data_criacao else None,
            "data_atualizacao": db_object.data_atualizacao.isoformat() if db_object.data_atualizacao else None
        }
    
    async def _validate_schema_compatibility(self, old_schema: Dict[str, Any], new_schema: Dict[str, Any]) -> Dict[str, Any]:
        """
        Validate schema compatibility.
        
        Following SOLID principles:
        - SRP: Single responsibility for schema validation
        """
        # Simple compatibility check - can be extended
        issues = []
        
        if "columns" in old_schema and "columns" in new_schema:
            old_columns = {col["name"]: col for col in old_schema["columns"]}
            new_columns = {col["name"]: col for col in new_schema["columns"]}
            
            # Check for removed columns
            removed_columns = set(old_columns.keys()) - set(new_columns.keys())
            if removed_columns:
                issues.append(f"Removed columns: {list(removed_columns)}")
            
            # Check for type changes
            for col_name in old_columns:
                if col_name in new_columns:
                    old_type = old_columns[col_name].get("type")
                    new_type = new_columns[col_name].get("type")
                    if old_type != new_type:
                        issues.append(f"Type change for column {col_name}: {old_type} -> {new_type}")
        
        return {
            "compatible": len(issues) == 0,
            "issues": issues
        }
    
    async def _auto_classify_object(self, db_object: DataObject) -> Dict[str, Any]:
        """
        Auto-classify data object based on content analysis.
        
        Following SOLID principles:
        - SRP: Single responsibility for auto-classification
        """
        # Simple auto-classification logic - can be extended with ML
        classification = {
            "security_classification": "internal",
            "sensitivity_level": "low"
        }
        
        # Check for sensitive patterns in schema
        if db_object.schema_definition and "columns" in db_object.schema_definition:
            sensitive_patterns = ["email", "phone", "ssn", "credit_card", "password", "personal"]
            
            for column in db_object.schema_definition["columns"]:
                column_name = column.get("name", "").lower()
                if any(pattern in column_name for pattern in sensitive_patterns):
                    classification["sensitivity_level"] = "high"
                    classification["security_classification"] = "confidential"
                    break
        
        return classification
    
    async def _get_quality_metrics(self, object_id: int) -> List[Dict[str, Any]]:
        """Get quality metrics for object."""
        # Placeholder - would be implemented with actual quality metrics logic
        return []
    
    async def _get_lineage(self, object_id: int) -> Dict[str, Any]:
        """Get lineage for object."""
        # Placeholder - would be implemented with actual lineage logic
        return {"upstream": [], "downstream": []}
    
    async def _get_contracts(self, object_id: int) -> List[Dict[str, Any]]:
        """Get contracts for object."""
        # Placeholder - would be implemented with actual contracts logic
        return []
    
    async def _get_access_policies(self, object_id: int) -> List[Dict[str, Any]]:
        """Get access policies for object."""
        # Placeholder - would be implemented with actual policies logic
        return []

