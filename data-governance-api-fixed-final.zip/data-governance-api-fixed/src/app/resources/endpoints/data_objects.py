"""
Data Objects API Endpoints
Following SOLID principles and implementing ALL CRUD operations

Author: Carlos Morais
"""

from fastapi import APIRouter, Depends, HTTPException, Query, Path, Body
from sqlalchemy.orm import Session
from typing import List, Optional, Dict, Any
from datetime import datetime

from ...services.data_objects_service import DataObjectsService
from ...utils.database import get_db
from ...utils.exceptions import EntityNotFoundError, ValidationError
from ...utils.pagination import PaginationParams, PaginatedResponse
from ...utils.auth import get_current_user

router = APIRouter()


@router.get("/", response_model=PaginatedResponse)
async def list_data_objects(
    pagination: PaginationParams = Depends(),
    object_type: Optional[str] = Query(None, description="Filter by object type"),
    catalog_name: Optional[str] = Query(None, description="Filter by Unity Catalog catalog"),
    database_name: Optional[str] = Query(None, description="Filter by database/schema"),
    security_classification: Optional[str] = Query(None, description="Filter by security classification"),
    quality_status: Optional[str] = Query(None, description="Filter by quality status"),
    owner_id: Optional[int] = Query(None, description="Filter by owner"),
    steward_id: Optional[int] = Query(None, description="Filter by steward"),
    search: Optional[str] = Query(None, description="Search in name and description"),
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    List all data objects with filtering and pagination.
    
    Following SOLID principles:
    - SRP: Single responsibility for listing objects
    - DIP: Depends on abstraction (service)
    """
    service = DataObjectsService(db)
    
    filters = {
        "object_type": object_type,
        "catalog_name": catalog_name,
        "database_name": database_name,
        "security_classification": security_classification,
        "quality_status": quality_status,
        "owner_id": owner_id,
        "steward_id": steward_id,
        "search": search
    }
    
    # Remove None values
    filters = {k: v for k, v in filters.items() if v is not None}
    
    return await service.list_objects(
        page=pagination.page,
        size=pagination.size,
        filters=filters
    )


@router.post("/", response_model=Dict[str, Any])
async def create_data_object(
    data_object: Dict[str, Any] = Body(..., description="Data object to create"),
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    Create a new data object.
    
    Following SOLID principles:
    - SRP: Single responsibility for object creation
    - OCP: Open for extension with new object types
    """
    service = DataObjectsService(db)
    
    try:
        return await service.create_object(data_object, current_user.id)
    except ValidationError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to create data object: {str(e)}")


@router.get("/{object_id}", response_model=Dict[str, Any])
async def get_data_object(
    object_id: int = Path(..., description="Data object ID"),
    include_lineage: bool = Query(False, description="Include lineage information"),
    include_quality: bool = Query(False, description="Include quality metrics"),
    include_contracts: bool = Query(False, description="Include data contracts"),
    include_policies: bool = Query(False, description="Include access policies"),
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    Get a specific data object by ID with optional related data.
    
    Following SOLID principles:
    - SRP: Single responsibility for object retrieval
    - OCP: Open for extension with new include options
    """
    service = DataObjectsService(db)
    
    try:
        return await service.get_object(
            object_id,
            include_lineage=include_lineage,
            include_quality=include_quality,
            include_contracts=include_contracts,
            include_policies=include_policies
        )
    except EntityNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))


@router.put("/{object_id}", response_model=Dict[str, Any])
async def update_data_object(
    object_id: int = Path(..., description="Data object ID"),
    data_object: Dict[str, Any] = Body(..., description="Updated data object"),
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    Update a data object.
    
    Following SOLID principles:
    - SRP: Single responsibility for object updates
    - OCP: Open for extension with new update fields
    """
    service = DataObjectsService(db)
    
    try:
        return await service.update_object(object_id, data_object, current_user.id)
    except EntityNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except ValidationError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.delete("/{object_id}")
async def delete_data_object(
    object_id: int = Path(..., description="Data object ID"),
    force: bool = Query(False, description="Force delete even with dependencies"),
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    Delete a data object.
    
    Following SOLID principles:
    - SRP: Single responsibility for object deletion
    """
    service = DataObjectsService(db)
    
    try:
        await service.delete_object(object_id, force=force, user_id=current_user.id)
        return {"message": "Data object deleted successfully"}
    except EntityNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except ValidationError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/{object_id}/schema", response_model=Dict[str, Any])
async def update_object_schema(
    object_id: int = Path(..., description="Data object ID"),
    schema_definition: Dict[str, Any] = Body(..., description="Schema definition"),
    validate_compatibility: bool = Query(True, description="Validate schema compatibility"),
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    Update data object schema.
    
    Following SOLID principles:
    - SRP: Single responsibility for schema updates
    """
    service = DataObjectsService(db)
    
    try:
        return await service.update_schema(
            object_id, 
            schema_definition, 
            validate_compatibility=validate_compatibility,
            user_id=current_user.id
        )
    except EntityNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except ValidationError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.get("/{object_id}/schema", response_model=Dict[str, Any])
async def get_object_schema(
    object_id: int = Path(..., description="Data object ID"),
    version: Optional[str] = Query(None, description="Schema version"),
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    Get data object schema.
    
    Following SOLID principles:
    - SRP: Single responsibility for schema retrieval
    """
    service = DataObjectsService(db)
    
    try:
        return await service.get_schema(object_id, version=version)
    except EntityNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))


@router.post("/{object_id}/classify", response_model=Dict[str, Any])
async def classify_data_object(
    object_id: int = Path(..., description="Data object ID"),
    classification: Dict[str, Any] = Body(..., description="Classification details"),
    auto_classify: bool = Query(False, description="Use automatic classification"),
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    Classify data object for security and sensitivity.
    
    Following SOLID principles:
    - SRP: Single responsibility for classification
    """
    service = DataObjectsService(db)
    
    try:
        return await service.classify_object(
            object_id, 
            classification, 
            auto_classify=auto_classify,
            user_id=current_user.id
        )
    except EntityNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except ValidationError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.get("/{object_id}/usage", response_model=Dict[str, Any])
async def get_object_usage(
    object_id: int = Path(..., description="Data object ID"),
    days: int = Query(30, description="Number of days for usage statistics"),
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    Get data object usage statistics.
    
    Following SOLID principles:
    - SRP: Single responsibility for usage tracking
    """
    service = DataObjectsService(db)
    
    try:
        return await service.get_usage_statistics(object_id, days=days)
    except EntityNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))


@router.post("/{object_id}/access", response_model=Dict[str, Any])
async def record_object_access(
    object_id: int = Path(..., description="Data object ID"),
    access_details: Dict[str, Any] = Body(..., description="Access details"),
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    Record data object access for usage tracking.
    
    Following SOLID principles:
    - SRP: Single responsibility for access recording
    """
    service = DataObjectsService(db)
    
    try:
        return await service.record_access(
            object_id, 
            access_details, 
            user_id=current_user.id
        )
    except EntityNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))


@router.get("/{object_id}/popularity", response_model=Dict[str, Any])
async def get_object_popularity(
    object_id: int = Path(..., description="Data object ID"),
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    Get data object popularity metrics.
    
    Following SOLID principles:
    - SRP: Single responsibility for popularity calculation
    """
    service = DataObjectsService(db)
    
    try:
        return await service.calculate_popularity(object_id)
    except EntityNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))


@router.post("/{object_id}/tags", response_model=Dict[str, Any])
async def add_object_tags(
    object_id: int = Path(..., description="Data object ID"),
    tags: List[str] = Body(..., description="Tags to add"),
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    Add tags to data object.
    
    Following SOLID principles:
    - SRP: Single responsibility for tag management
    """
    service = DataObjectsService(db)
    
    try:
        return await service.add_tags(object_id, tags, user_id=current_user.id)
    except EntityNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))


@router.delete("/{object_id}/tags", response_model=Dict[str, Any])
async def remove_object_tags(
    object_id: int = Path(..., description="Data object ID"),
    tags: List[str] = Body(..., description="Tags to remove"),
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    Remove tags from data object.
    
    Following SOLID principles:
    - SRP: Single responsibility for tag management
    """
    service = DataObjectsService(db)
    
    try:
        return await service.remove_tags(object_id, tags, user_id=current_user.id)
    except EntityNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))


@router.get("/catalog/{catalog_name}", response_model=PaginatedResponse)
async def list_objects_by_catalog(
    catalog_name: str = Path(..., description="Unity Catalog name"),
    pagination: PaginationParams = Depends(),
    database_name: Optional[str] = Query(None, description="Filter by database"),
    object_type: Optional[str] = Query(None, description="Filter by object type"),
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    List data objects by Unity Catalog.
    
    Following SOLID principles:
    - SRP: Single responsibility for catalog-based listing
    """
    service = DataObjectsService(db)
    
    filters = {
        "catalog_name": catalog_name,
        "database_name": database_name,
        "object_type": object_type
    }
    
    # Remove None values
    filters = {k: v for k, v in filters.items() if v is not None}
    
    return await service.list_objects(
        page=pagination.page,
        size=pagination.size,
        filters=filters
    )


@router.get("/popular", response_model=List[Dict[str, Any]])
async def get_popular_objects(
    limit: int = Query(10, description="Number of popular objects to return"),
    days: int = Query(30, description="Time period for popularity calculation"),
    object_type: Optional[str] = Query(None, description="Filter by object type"),
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    Get most popular data objects.
    
    Following SOLID principles:
    - SRP: Single responsibility for popularity ranking
    """
    service = DataObjectsService(db)
    
    return await service.get_popular_objects(
        limit=limit,
        days=days,
        object_type=object_type
    )


@router.get("/recent", response_model=List[Dict[str, Any]])
async def get_recent_objects(
    limit: int = Query(10, description="Number of recent objects to return"),
    object_type: Optional[str] = Query(None, description="Filter by object type"),
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    Get recently created data objects.
    
    Following SOLID principles:
    - SRP: Single responsibility for recent objects listing
    """
    service = DataObjectsService(db)
    
    return await service.get_recent_objects(
        limit=limit,
        object_type=object_type
    )

