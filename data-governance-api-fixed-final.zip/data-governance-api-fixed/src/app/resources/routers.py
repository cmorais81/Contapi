"""
Main API Router
Following SOLID principles and implementing ALL endpoints

Author: Carlos Morais
"""

from fastapi import APIRouter
from .endpoints import (
    data_objects,
    data_contracts,
    data_lineage,
    quality_metrics,
    quality_rules,
    access_policies,
    users,
    audit_logs,
    metadata_management,
    analytics,
    search,
    sync_integration,
    health
)

# Main API router
api_router = APIRouter()

# Include all endpoint routers
api_router.include_router(
    health.router,
    prefix="/health",
    tags=["Health & Status"]
)

api_router.include_router(
    data_objects.router,
    prefix="/data-objects",
    tags=["Data Objects"]
)

api_router.include_router(
    data_contracts.router,
    prefix="/data-contracts",
    tags=["Data Contracts"]
)

api_router.include_router(
    data_lineage.router,
    prefix="/data-lineage",
    tags=["Data Lineage"]
)

api_router.include_router(
    quality_metrics.router,
    prefix="/quality-metrics",
    tags=["Quality Metrics"]
)

api_router.include_router(
    quality_rules.router,
    prefix="/quality-rules",
    tags=["Quality Rules"]
)

api_router.include_router(
    access_policies.router,
    prefix="/access-policies",
    tags=["Access Policies"]
)

api_router.include_router(
    users.router,
    prefix="/users",
    tags=["Users & Governance Roles"]
)

api_router.include_router(
    audit_logs.router,
    prefix="/audit-logs",
    tags=["Audit & Compliance"]
)

api_router.include_router(
    metadata_management.router,
    prefix="/metadata",
    tags=["Metadata Management"]
)

api_router.include_router(
    analytics.router,
    prefix="/analytics",
    tags=["Analytics & Reporting"]
)

api_router.include_router(
    search.router,
    prefix="/search",
    tags=["Search & Discovery"]
)

api_router.include_router(
    sync_integration.router,
    prefix="/sync",
    tags=["Sync & Integration"]
)

