"""
Global Configuration Module
Following SOLID principles and clean architecture

Author: Carlos Morais
"""

from pydantic_settings import BaseSettings
from typing import List, Optional
import os
from pathlib import Path


class Settings(BaseSettings):
    """
    Application settings.
    
    Following SOLID principles:
    - SRP: Single responsibility for configuration
    - OCP: Open for extension through environment variables
    """
    
    # Application
    PROJECT_NAME: str = "Data Governance API"
    VERSION: str = "2.0.0"
    DESCRIPTION: str = "Enterprise Data Governance API"
    API_V1_STR: str = "/api/v1"
    
    # Environment
    ENVIRONMENT: str = "development"
    DEBUG: bool = True
    LOG_LEVEL: str = "INFO"
    
    # Security
    SECRET_KEY: str = "your-super-secret-key-change-in-production"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    
    # CORS
    ALLOWED_HOSTS: List[str] = ["*"]
    
    # Database
    DATABASE_URL: str = "postgresql://postgres:postgres@localhost:5432/data_governance"
    DATABASE_POOL_SIZE: int = 20
    DATABASE_MAX_OVERFLOW: int = 30
    DATABASE_ECHO: bool = False
    
    # Redis
    REDIS_URL: str = "redis://localhost:6379/0"
    REDIS_POOL_SIZE: int = 10
    
    # External Services
    UNITY_CATALOG_URL: Optional[str] = None
    UNITY_CATALOG_TOKEN: Optional[str] = None
    INFORMATICA_AXON_URL: Optional[str] = None
    INFORMATICA_AXON_TOKEN: Optional[str] = None
    
    # Monitoring
    ENABLE_METRICS: bool = True
    METRICS_PORT: int = 9090
    
    # File Storage
    UPLOAD_DIR: str = "uploads"
    MAX_FILE_SIZE: int = 10 * 1024 * 1024  # 10MB
    
    # Pagination
    DEFAULT_PAGE_SIZE: int = 20
    MAX_PAGE_SIZE: int = 100
    
    # Quality Rules
    DEFAULT_QUALITY_THRESHOLD: float = 0.8
    QUALITY_CHECK_INTERVAL: int = 3600  # 1 hour
    
    # Data Retention
    DEFAULT_RETENTION_DAYS: int = 2555  # 7 years
    AUDIT_LOG_RETENTION_DAYS: int = 2555  # 7 years
    
    class Config:
        env_file = ".env"
        case_sensitive = True


# Global settings instance
settings = Settings()


class DatabaseConfig:
    """
    Database configuration.
    
    Following SOLID principles:
    - SRP: Single responsibility for database config
    """
    
    @staticmethod
    def get_database_url() -> str:
        """Get database URL."""
        return settings.DATABASE_URL
    
    @staticmethod
    def get_pool_config() -> dict:
        """Get connection pool configuration."""
        return {
            "pool_size": settings.DATABASE_POOL_SIZE,
            "max_overflow": settings.DATABASE_MAX_OVERFLOW,
            "echo": settings.DATABASE_ECHO
        }


class SecurityConfig:
    """
    Security configuration.
    
    Following SOLID principles:
    - SRP: Single responsibility for security config
    """
    
    @staticmethod
    def get_jwt_config() -> dict:
        """Get JWT configuration."""
        return {
            "secret_key": settings.SECRET_KEY,
            "algorithm": settings.ALGORITHM,
            "expire_minutes": settings.ACCESS_TOKEN_EXPIRE_MINUTES
        }
    
    @staticmethod
    def get_cors_config() -> dict:
        """Get CORS configuration."""
        return {
            "allow_origins": settings.ALLOWED_HOSTS,
            "allow_credentials": True,
            "allow_methods": ["*"],
            "allow_headers": ["*"]
        }


class ExternalServicesConfig:
    """
    External services configuration.
    
    Following SOLID principles:
    - SRP: Single responsibility for external services config
    """
    
    @staticmethod
    def get_unity_catalog_config() -> Optional[dict]:
        """Get Unity Catalog configuration."""
        if settings.UNITY_CATALOG_URL and settings.UNITY_CATALOG_TOKEN:
            return {
                "url": settings.UNITY_CATALOG_URL,
                "token": settings.UNITY_CATALOG_TOKEN
            }
        return None
    
    @staticmethod
    def get_informatica_axon_config() -> Optional[dict]:
        """Get Informatica Axon configuration."""
        if settings.INFORMATICA_AXON_URL and settings.INFORMATICA_AXON_TOKEN:
            return {
                "url": settings.INFORMATICA_AXON_URL,
                "token": settings.INFORMATICA_AXON_TOKEN
            }
        return None


class QualityConfig:
    """
    Quality configuration.
    
    Following SOLID principles:
    - SRP: Single responsibility for quality config
    """
    
    @staticmethod
    def get_default_threshold() -> float:
        """Get default quality threshold."""
        return settings.DEFAULT_QUALITY_THRESHOLD
    
    @staticmethod
    def get_check_interval() -> int:
        """Get quality check interval."""
        return settings.QUALITY_CHECK_INTERVAL


class RetentionConfig:
    """
    Data retention configuration.
    
    Following SOLID principles:
    - SRP: Single responsibility for retention config
    """
    
    @staticmethod
    def get_default_retention_days() -> int:
        """Get default retention days."""
        return settings.DEFAULT_RETENTION_DAYS
    
    @staticmethod
    def get_audit_retention_days() -> int:
        """Get audit log retention days."""
        return settings.AUDIT_LOG_RETENTION_DAYS

