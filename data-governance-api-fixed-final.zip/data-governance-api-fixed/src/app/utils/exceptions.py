"""
Custom Exceptions for Data Governance API
Following SOLID principles and providing structured error handling

Author: Carlos Morais
"""

from typing import Optional, Dict, Any, List
import uuid
from datetime import datetime


class BaseDataGovernanceException(Exception):
    """
    Base exception for all data governance errors.
    
    Following SOLID principles:
    - SRP: Single responsibility for base exception behavior
    - OCP: Open for extension by specific exception types
    """
    
    def __init__(
        self, 
        message: str, 
        error_code: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
        user_message: Optional[str] = None
    ):
        super().__init__(message)
        self.message = message
        self.error_code = error_code or self.__class__.__name__
        self.details = details or {}
        self.user_message = user_message or message
        self.error_id = str(uuid.uuid4())
        self.timestamp = datetime.utcnow()
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert exception to dictionary for API responses."""
        return {
            "error_id": self.error_id,
            "error_code": self.error_code,
            "message": self.message,
            "user_message": self.user_message,
            "details": self.details,
            "timestamp": self.timestamp.isoformat()
        }


class ValidationError(BaseDataGovernanceException):
    """Exception for validation errors."""
    
    def __init__(
        self, 
        message: str, 
        field: Optional[str] = None,
        value: Optional[Any] = None,
        validation_rules: Optional[Dict[str, Any]] = None
    ):
        details = {
            "field": field,
            "value": value,
            "validation_rules": validation_rules
        }
        super().__init__(
            message=message,
            error_code="VALIDATION_ERROR",
            details=details,
            user_message=f"Validation failed: {message}"
        )


class EntityNotFoundError(BaseDataGovernanceException):
    """Exception for entity not found errors."""
    
    def __init__(
        self, 
        message: str, 
        entity_type: Optional[str] = None,
        entity_id: Optional[str] = None
    ):
        details = {
            "entity_type": entity_type,
            "entity_id": entity_id
        }
        super().__init__(
            message=message,
            error_code="ENTITY_NOT_FOUND",
            details=details,
            user_message=f"The requested {entity_type or 'resource'} was not found"
        )


class BusinessRuleViolationError(BaseDataGovernanceException):
    """Exception for business rule violations."""
    
    def __init__(
        self, 
        message: str, 
        rule_name: Optional[str] = None,
        rule_details: Optional[Dict[str, Any]] = None
    ):
        details = {
            "rule_name": rule_name,
            "rule_details": rule_details
        }
        super().__init__(
            message=message,
            error_code="BUSINESS_RULE_VIOLATION",
            details=details,
            user_message=f"Business rule violation: {message}"
        )


# Exception mapping for HTTP status codes
EXCEPTION_STATUS_MAP = {
    ValidationError: 400,
    EntityNotFoundError: 404,
    BusinessRuleViolationError: 422,
    BaseDataGovernanceException: 500
}

