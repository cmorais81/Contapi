"""
Modelo ExternalMetadata para Unity Catalog External Lineage
Implementa suporte completo para objetos de metadados externos
Autor: Manus AI
"""

from sqlalchemy import Column, Text, Boolean, ForeignKey
from sqlalchemy.dialects.postgresql import UUID, JSONB, TIMESTAMP
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from typing import Dict, Any, Optional, List

from .base import BaseEntity


class ExternalMetadata(BaseEntity):
    """
    Objetos de metadados externos para Unity Catalog External Lineage
    Representa entidades em sistemas externos (Tableau, PowerBI, Salesforce, etc.)
    """
    
    __tablename__ = "external_metadata"
    
    # Chave primária UUID
    external_metadata_id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        default=func.gen_random_uuid(),
        nullable=False,
        comment='Identificador único do objeto de metadados externo'
    )
    
    # Campos obrigatórios conforme Unity Catalog External Lineage
    name = Column(
        Text,
        nullable=False,
        comment='Nome human-readable do objeto externo (sem espaços)'
    )
    
    system_type = Column(
        Text,
        nullable=False,
        comment='Tipo do sistema externo (tableau, powerbi, salesforce, mysql, custom, etc.)'
    )
    
    entity_type = Column(
        Text,
        nullable=False,
        comment='Tipo da entidade (table, dashboard, report, dataset, etc.)'
    )
    
    # Campos opcionais
    external_url = Column(
        Text,
        comment='URL do objeto externo para navegação direta'
    )
    
    description = Column(
        Text,
        comment='Descrição detalhada do objeto externo'
    )
    
    # Propriedades customizadas em JSON
    properties = Column(
        JSONB,
        comment='Propriedades customizadas específicas do sistema em formato JSON'
    )
    
    # Metadados de integração Unity Catalog
    unity_catalog_metastore_id = Column(
        UUID(as_uuid=True),
        comment='ID do metastore Unity Catalog associado'
    )
    
    unity_catalog_external_id = Column(
        Text,
        comment='ID do objeto no Unity Catalog External Lineage'
    )
    
    # Status e validação
    is_active = Column(
        Boolean,
        default=True,
        nullable=False,
        comment='Indica se o objeto externo está ativo'
    )
    
    validation_status = Column(
        Text,
        default='pending',
        comment='Status de validação (validated, pending, failed, deprecated)'
    )
    
    last_validated_at = Column(
        TIMESTAMP(timezone=True),
        comment='Timestamp da última validação'
    )
    
    validated_by = Column(
        UUID(as_uuid=True),
        ForeignKey('users.user_id'),
        comment='Usuário que validou o objeto'
    )
    
    # Metadados de sincronização
    last_synced_at = Column(
        TIMESTAMP(timezone=True),
        comment='Timestamp da última sincronização com sistema externo'
    )
    
    sync_status = Column(
        Text,
        default='pending',
        comment='Status da sincronização (synced, pending, failed, conflict)'
    )
    
    sync_error_message = Column(
        Text,
        comment='Mensagem de erro da última tentativa de sincronização'
    )
    
    # Relacionamentos
    validator = relationship("Users", back_populates="validated_external_metadata")
    column_mappings = relationship("ExternalColumnMappings", back_populates="external_metadata")
    lineage_relationships = relationship("ExternalLineageRelationships", back_populates="external_metadata")
    
    def __repr__(self):
        return f"<ExternalMetadata(id={self.external_metadata_id}, name={self.name}, system={self.system_type})>"
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte objeto para dicionário para serialização JSON"""
        return {
            'external_metadata_id': str(self.external_metadata_id),
            'name': self.name,
            'system_type': self.system_type,
            'entity_type': self.entity_type,
            'external_url': self.external_url,
            'description': self.description,
            'properties': self.properties,
            'unity_catalog_metastore_id': str(self.unity_catalog_metastore_id) if self.unity_catalog_metastore_id else None,
            'unity_catalog_external_id': self.unity_catalog_external_id,
            'is_active': self.is_active,
            'validation_status': self.validation_status,
            'last_validated_at': self.last_validated_at.isoformat() if self.last_validated_at else None,
            'validated_by': str(self.validated_by) if self.validated_by else None,
            'last_synced_at': self.last_synced_at.isoformat() if self.last_synced_at else None,
            'sync_status': self.sync_status,
            'sync_error_message': self.sync_error_message,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
    
    @classmethod
    def get_supported_system_types(cls) -> List[str]:
        """Retorna lista de tipos de sistema suportados"""
        return [
            'tableau',
            'powerbi',
            'salesforce',
            'mysql',
            'postgresql',
            'oracle',
            'sqlserver',
            'snowflake',
            'redshift',
            'bigquery',
            'looker',
            'qlik',
            'custom'
        ]
    
    @classmethod
    def get_supported_entity_types(cls) -> List[str]:
        """Retorna lista de tipos de entidade suportados"""
        return [
            'table',
            'view',
            'dashboard',
            'report',
            'dataset',
            'workbook',
            'datasource',
            'model',
            'pipeline',
            'job',
            'custom'
        ]
    
    def validate_system_type(self) -> bool:
        """Valida se system_type é suportado"""
        return self.system_type in self.get_supported_system_types()
    
    def validate_entity_type(self) -> bool:
        """Valida se entity_type é suportado"""
        return self.entity_type in self.get_supported_entity_types()
    
    def validate_name_format(self) -> bool:
        """Valida formato do nome (sem espaços conforme Unity Catalog)"""
        return ' ' not in self.name if self.name else False
    
    def is_valid(self) -> tuple[bool, List[str]]:
        """Valida objeto completo e retorna erros se houver"""
        errors = []
        
        if not self.name:
            errors.append("Nome é obrigatório")
        elif not self.validate_name_format():
            errors.append("Nome não pode conter espaços")
        
        if not self.system_type:
            errors.append("System type é obrigatório")
        elif not self.validate_system_type():
            errors.append(f"System type '{self.system_type}' não é suportado")
        
        if not self.entity_type:
            errors.append("Entity type é obrigatório")
        elif not self.validate_entity_type():
            errors.append(f"Entity type '{self.entity_type}' não é suportado")
        
        return len(errors) == 0, errors


class ExternalColumnMappings(BaseEntity):
    """
    Mapeamentos column-level entre objetos externos e Unity Catalog
    """
    
    __tablename__ = "external_column_mappings"
    
    # Chave primária UUID
    mapping_id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        default=func.gen_random_uuid(),
        nullable=False,
        comment='Identificador único do mapeamento'
    )
    
    # Relacionamento com external metadata
    external_metadata_id = Column(
        UUID(as_uuid=True),
        ForeignKey('external_metadata.external_metadata_id'),
        nullable=False,
        comment='Referência ao objeto de metadados externo'
    )
    
    # Coluna no sistema externo
    source_column_name = Column(
        Text,
        nullable=False,
        comment='Nome da coluna no sistema externo'
    )
    
    source_column_type = Column(
        Text,
        comment='Tipo de dados da coluna no sistema externo'
    )
    
    source_column_description = Column(
        Text,
        comment='Descrição da coluna no sistema externo'
    )
    
    # Relacionamento com Unity Catalog
    target_property_id = Column(
        UUID(as_uuid=True),
        ForeignKey('data_object_properties.property_id'),
        comment='Propriedade Unity Catalog de destino'
    )
    
    target_column_name = Column(
        Text,
        comment='Nome da coluna Unity Catalog de destino'
    )
    
    # Metadados de transformação
    transformation_type = Column(
        Text,
        comment='Tipo de transformação aplicada (direct, calculated, aggregated, etc.)'
    )
    
    transformation_description = Column(
        Text,
        comment='Descrição da transformação aplicada'
    )
    
    transformation_metadata = Column(
        JSONB,
        comment='Metadados adicionais da transformação em JSON'
    )
    
    # Validação de compatibilidade
    compatibility_status = Column(
        Text,
        default='pending',
        comment='Status de compatibilidade (compatible, incompatible, warning, pending)'
    )
    
    compatibility_notes = Column(
        Text,
        comment='Notas sobre compatibilidade de tipos'
    )
    
    # Relacionamentos
    external_metadata = relationship("ExternalMetadata", back_populates="column_mappings")
    target_property = relationship("DataObjectProperties", back_populates="external_mappings")
    
    def __repr__(self):
        return f"<ExternalColumnMappings(id={self.mapping_id}, source={self.source_column_name}, target={self.target_column_name})>"


class ExternalLineageRelationships(BaseEntity):
    """
    Relacionamentos de linhagem entre objetos externos e Unity Catalog
    """
    
    __tablename__ = "external_lineage_relationships"
    
    # Chave primária UUID
    relationship_id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        default=func.gen_random_uuid(),
        nullable=False,
        comment='Identificador único do relacionamento'
    )
    
    # Objeto externo
    external_metadata_id = Column(
        UUID(as_uuid=True),
        ForeignKey('external_metadata.external_metadata_id'),
        nullable=False,
        comment='Objeto de metadados externo'
    )
    
    # Objeto Unity Catalog de destino
    target_object_type = Column(
        Text,
        nullable=False,
        comment='Tipo do objeto Unity Catalog (table, model, path, external_metadata)'
    )
    
    target_object_id = Column(
        Text,
        nullable=False,
        comment='Identificador do objeto Unity Catalog'
    )
    
    target_object_name = Column(
        Text,
        comment='Nome completo do objeto Unity Catalog'
    )
    
    # Direção do relacionamento
    relationship_direction = Column(
        Text,
        nullable=False,
        comment='Direção do relacionamento (upstream, downstream)'
    )
    
    # Metadados do relacionamento
    relationship_metadata = Column(
        JSONB,
        comment='Metadados adicionais do relacionamento em JSON'
    )
    
    relationship_description = Column(
        Text,
        comment='Descrição do relacionamento'
    )
    
    # Status e validação
    is_active = Column(
        Boolean,
        default=True,
        nullable=False,
        comment='Indica se o relacionamento está ativo'
    )
    
    validation_status = Column(
        Text,
        default='pending',
        comment='Status de validação do relacionamento'
    )
    
    validated_by = Column(
        UUID(as_uuid=True),
        ForeignKey('users.user_id'),
        comment='Usuário que validou o relacionamento'
    )
    
    validated_at = Column(
        TIMESTAMP(timezone=True),
        comment='Timestamp da validação'
    )
    
    # Relacionamentos
    external_metadata = relationship("ExternalMetadata", back_populates="lineage_relationships")
    validator = relationship("Users", back_populates="validated_external_relationships")
    
    def __repr__(self):
        return f"<ExternalLineageRelationships(id={self.relationship_id}, direction={self.relationship_direction}, target={self.target_object_name})>"
    
    @classmethod
    def get_supported_target_types(cls) -> List[str]:
        """Retorna tipos de objeto Unity Catalog suportados"""
        return ['table', 'model', 'path', 'external_metadata']
    
    @classmethod
    def get_supported_directions(cls) -> List[str]:
        """Retorna direções de relacionamento suportadas"""
        return ['upstream', 'downstream']
    
    def validate_target_type(self) -> bool:
        """Valida se target_object_type é suportado"""
        return self.target_object_type in self.get_supported_target_types()
    
    def validate_direction(self) -> bool:
        """Valida se relationship_direction é suportado"""
        return self.relationship_direction in self.get_supported_directions()

