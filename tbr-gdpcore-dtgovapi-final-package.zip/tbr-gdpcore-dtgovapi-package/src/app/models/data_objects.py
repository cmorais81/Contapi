"""
Modelo DataObjects para Data Governance API
Seguindo exatamente o modelo_estendido.dbml original
Autor: Carlos Morais
"""

from sqlalchemy import BigInteger, Boolean, Column, ForeignKey, Numeric, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship

from .base import BaseEntity


class DataObjects(BaseEntity):
    """
    Objetos de dados individuais com políticas de ciclo de vida e integração com plataforma
    """
    
    __tablename__ = "DataObjects"
    
    # Chave primária UUID conforme modelo original
    data_object_id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        default=func.gen_random_uuid(),
        nullable=False,
        comment='Identificador único do objeto de dados'
    )
    
    # Relacionamento com schema
    schema_definition_id = Column(
        UUID(as_uuid=True),
        ForeignKey('ContractSchemaDefinitions.schema_definition_id'),
        nullable=False,
        comment='Referência à definição de schema'
    )
    
    # Informações básicas do objeto
    object_name = Column(
        Text,
        nullable=False,
        comment='Nome do objeto de dados (tabela, view, stream, conjunto de arquivos)'
    )
    
    object_type = Column(
        Text,
        comment='Tipo do objeto de dados (table, view, stream, file_set, api_endpoint)'
    )
    
    object_description = Column(
        Text,
        comment='Descrição do objeto de dados'
    )
    
    # Políticas de ciclo de vida dos dados
    retention_policy = Column(
        Text,
        comment='Política de retenção de dados (7 anos, indefinidamente, 30 dias após inatividade)'
    )
    
    purge_policy = Column(
        Text,
        comment='Método e cronograma de purga de dados (exclusão permanente, arquivamento, anonimização)'
    )
    
    backup_policy = Column(
        Text,
        comment='Política de backup e recuperação'
    )
    
    archival_policy = Column(
        Text,
        comment='Política e procedimentos de arquivamento de dados'
    )
    
    # Integração com Plataforma de Dados
    unity_catalog_table_id = Column(
        UUID(as_uuid=True),
        comment='Referência da tabela do Unity Catalog'
    )
    
    delta_table_path = Column(
        Text,
        comment='Caminho da tabela Delta'
    )
    
    iceberg_table_uuid = Column(
        UUID(as_uuid=True),
        comment='UUID da tabela Iceberg'
    )
    
    liquid_clustering_enabled = Column(
        Boolean,
        default=False,
        comment='Liquid clustering habilitado'
    )
    
    predictive_optimization_enabled = Column(
        Boolean,
        default=False,
        comment='Otimização preditiva habilitada'
    )
    
    # Performance e armazenamento
    estimated_size_gb = Column(
        Numeric,
        comment='Tamanho estimado em GB'
    )
    
    row_count_estimate = Column(
        BigInteger,
        comment='Estimativa de contagem de linhas'
    )
    
    update_frequency = Column(
        Text,
        comment='Frequência de atualização (tempo real, horário, diário, semanal)'
    )
    
    # Relacionamentos
    schema_definition = relationship("ContractSchemaDefinitions", back_populates="data_objects")
    properties = relationship("DataObjectProperties", back_populates="data_object")
    
    def __repr__(self):
        return f"<DataObjects(data_object_id={self.data_object_id}, name={self.object_name})>"

