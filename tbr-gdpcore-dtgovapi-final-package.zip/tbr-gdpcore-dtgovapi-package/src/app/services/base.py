"""
Service base para Data Governance API
Seguindo exatamente o modelo_estendido.dbml original
Autor: Carlos Morais
"""

from typing import Any, Dict, Generic, List, Optional, Type, TypeVar
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession

from ..models.base import BaseEntity
from ..repositories.base import BaseRepository
from ..schemas.base import PaginatedResponse, PaginationParams
from ..utils.exceptions import EntityNotFoundError, ValidationError

ModelType = TypeVar("ModelType", bound=BaseEntity)
RepositoryType = TypeVar("RepositoryType", bound=BaseRepository)


class BaseService(Generic[ModelType, RepositoryType]):
    """Service base com lógica de negócio padrão"""
    
    def __init__(self, repository: RepositoryType):
        self.repository = repository
    
    async def get_by_id(self, id: UUID) -> ModelType:
        """Busca entidade por ID"""
        entity = await self.repository.get_by_id(id)
        if not entity:
            raise EntityNotFoundError(f"Entidade com ID {id} não encontrada")
        return entity
    
    async def get_all_paginated(
        self,
        pagination: PaginationParams,
        filters: Optional[Dict[str, Any]] = None,
        order_by: Optional[str] = None
    ) -> PaginatedResponse:
        """Busca todas as entidades com paginação"""
        
        # Validar filtros
        if filters:
            await self._validate_filters(filters)
        
        # Buscar entidades
        entities = await self.repository.get_all(
            skip=pagination.offset,
            limit=pagination.size,
            filters=filters,
            order_by=order_by
        )
        
        # Contar total
        total = await self.repository.count(filters)
        
        return PaginatedResponse.create(
            items=entities,
            total=total,
            page=pagination.page,
            size=pagination.size
        )
    
    async def create(self, data: Dict[str, Any]) -> ModelType:
        """Cria nova entidade"""
        
        # Validar dados
        await self._validate_create_data(data)
        
        # Criar entidade
        return await self.repository.create(data)
    
    async def update(self, id: UUID, data: Dict[str, Any]) -> ModelType:
        """Atualiza entidade existente"""
        
        # Verificar se existe
        existing = await self.repository.get_by_id(id)
        if not existing:
            raise EntityNotFoundError(f"Entidade com ID {id} não encontrada")
        
        # Validar dados
        await self._validate_update_data(id, data)
        
        # Atualizar entidade
        updated = await self.repository.update(id, data)
        if not updated:
            raise EntityNotFoundError(f"Falha ao atualizar entidade com ID {id}")
        
        return updated
    
    async def delete(self, id: UUID) -> bool:
        """Remove entidade"""
        
        # Verificar se existe
        existing = await self.repository.get_by_id(id)
        if not existing:
            raise EntityNotFoundError(f"Entidade com ID {id} não encontrada")
        
        # Validar se pode ser removida
        await self._validate_delete(id)
        
        # Remover entidade
        return await self.repository.delete(id)
    
    async def search(
        self,
        search_term: str,
        pagination: PaginationParams,
        search_fields: Optional[List[str]] = None
    ) -> PaginatedResponse:
        """Busca textual em múltiplos campos"""
        
        if not search_fields:
            search_fields = self._get_default_search_fields()
        
        # Buscar entidades
        entities = await self.repository.search(
            search_term=search_term,
            search_fields=search_fields,
            skip=pagination.offset,
            limit=pagination.size
        )
        
        # Para busca, não fazemos count exato por performance
        # Estimamos baseado no resultado
        total = len(entities)
        if len(entities) == pagination.size:
            total = pagination.offset + pagination.size + 1
        
        return PaginatedResponse.create(
            items=entities,
            total=total,
            page=pagination.page,
            size=pagination.size
        )
    
    async def exists(self, **kwargs) -> bool:
        """Verifica se entidade existe"""
        return await self.repository.exists(**kwargs)
    
    # Métodos para override em services específicos
    
    async def _validate_filters(self, filters: Dict[str, Any]) -> None:
        """Valida filtros de busca"""
        pass
    
    async def _validate_create_data(self, data: Dict[str, Any]) -> None:
        """Valida dados para criação"""
        pass
    
    async def _validate_update_data(self, id: UUID, data: Dict[str, Any]) -> None:
        """Valida dados para atualização"""
        pass
    
    async def _validate_delete(self, id: UUID) -> None:
        """Valida se entidade pode ser removida"""
        pass
    
    def _get_default_search_fields(self) -> List[str]:
        """Retorna campos padrão para busca textual"""
        return []
    
    # Métodos utilitários
    
    def _validate_required_fields(self, data: Dict[str, Any], required_fields: List[str]) -> None:
        """Valida campos obrigatórios"""
        missing_fields = [field for field in required_fields if field not in data or data[field] is None]
        if missing_fields:
            raise ValidationError(f"Campos obrigatórios ausentes: {', '.join(missing_fields)}")
    
    def _validate_field_values(self, data: Dict[str, Any], field_validations: Dict[str, Any]) -> None:
        """Valida valores de campos específicos"""
        for field, validation in field_validations.items():
            if field in data:
                value = data[field]
                if 'choices' in validation and value not in validation['choices']:
                    raise ValidationError(f"Valor inválido para {field}: {value}. Opções válidas: {validation['choices']}")
                if 'min_length' in validation and isinstance(value, str) and len(value) < validation['min_length']:
                    raise ValidationError(f"Campo {field} deve ter pelo menos {validation['min_length']} caracteres")
                if 'max_length' in validation and isinstance(value, str) and len(value) > validation['max_length']:
                    raise ValidationError(f"Campo {field} deve ter no máximo {validation['max_length']} caracteres")

