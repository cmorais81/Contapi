"""
Serviços para External Metadata
Lógica de negócio para Unity Catalog External Lineage
Autor: Manus AI
"""

import logging
from typing import List, Optional, Dict, Any, Tuple
from uuid import UUID
from datetime import datetime
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, func

from ..models.external_metadata import (
    ExternalMetadata, 
    ExternalColumnMappings, 
    ExternalLineageRelationships
)
from ..schemas.external_metadata import (
    ExternalMetadataCreate,
    ExternalMetadataUpdate,
    ExternalMetadataFilter,
    ExternalColumnMappingCreate,
    ExternalLineageRelationshipCreate
)
from ..utils.exceptions import (
    ValidationError,
    NotFoundError,
    ConflictError,
    UnauthorizedError
)
from .base import BaseService

logger = logging.getLogger(__name__)


class ExternalMetadataService(BaseService):
    """Serviço para gerenciamento de External Metadata"""
    
    def __init__(self, db: Session, current_user_id: Optional[UUID] = None):
        super().__init__(db, current_user_id)
        self.model = ExternalMetadata
    
    async def create_external_metadata(
        self, 
        data: ExternalMetadataCreate,
        unity_catalog_privileges: Optional[Dict[str, Any]] = None
    ) -> ExternalMetadata:
        """
        Cria novo objeto de metadados externo
        
        Args:
            data: Dados para criação
            unity_catalog_privileges: Privilégios Unity Catalog do usuário
            
        Returns:
            Objeto ExternalMetadata criado
            
        Raises:
            ValidationError: Se dados são inválidos
            UnauthorizedError: Se usuário não tem privilégios necessários
            ConflictError: Se objeto com mesmo nome já existe
        """
        try:
            # Validar privilégios Unity Catalog
            await self._validate_create_privileges(unity_catalog_privileges)
            
            # Verificar se nome já existe no mesmo sistema
            existing = self.db.query(ExternalMetadata).filter(
                and_(
                    ExternalMetadata.name == data.name,
                    ExternalMetadata.system_type == data.system_type,
                    ExternalMetadata.is_active == True
                )
            ).first()
            
            if existing:
                raise ConflictError(
                    f"Objeto externo '{data.name}' já existe no sistema '{data.system_type}'"
                )
            
            # Criar objeto
            external_metadata = ExternalMetadata(
                name=data.name,
                system_type=data.system_type,
                entity_type=data.entity_type,
                external_url=data.external_url,
                description=data.description,
                properties=data.properties,
                unity_catalog_metastore_id=data.unity_catalog_metastore_id,
                validation_status='pending',
                sync_status='pending'
            )
            
            # Validar objeto
            is_valid, errors = external_metadata.is_valid()
            if not is_valid:
                raise ValidationError(f"Dados inválidos: {', '.join(errors)}")
            
            self.db.add(external_metadata)
            self.db.commit()
            self.db.refresh(external_metadata)
            
            logger.info(
                f"External metadata criado: {external_metadata.external_metadata_id} "
                f"({external_metadata.name})"
            )
            
            return external_metadata
            
        except Exception as e:
            self.db.rollback()
            logger.error(f"Erro ao criar external metadata: {e}")
            raise
    
    async def get_external_metadata(self, external_metadata_id: UUID) -> ExternalMetadata:
        """
        Obtém objeto de metadados externo por ID
        
        Args:
            external_metadata_id: ID do objeto
            
        Returns:
            Objeto ExternalMetadata
            
        Raises:
            NotFoundError: Se objeto não existe
        """
        external_metadata = self.db.query(ExternalMetadata).filter(
            ExternalMetadata.external_metadata_id == external_metadata_id
        ).first()
        
        if not external_metadata:
            raise NotFoundError(f"External metadata {external_metadata_id} não encontrado")
        
        return external_metadata
    
    async def list_external_metadata(
        self,
        filters: Optional[ExternalMetadataFilter] = None,
        page: int = 1,
        size: int = 50,
        order_by: str = "created_at",
        order_desc: bool = True
    ) -> Tuple[List[ExternalMetadata], int]:
        """
        Lista objetos de metadados externos com filtros e paginação
        
        Args:
            filters: Filtros a aplicar
            page: Página (1-based)
            size: Tamanho da página
            order_by: Campo para ordenação
            order_desc: Ordenação descendente
            
        Returns:
            Tupla com (lista de objetos, total de registros)
        """
        query = self.db.query(ExternalMetadata)
        
        # Aplicar filtros
        if filters:
            if filters.system_type:
                query = query.filter(ExternalMetadata.system_type == filters.system_type)
            
            if filters.entity_type:
                query = query.filter(ExternalMetadata.entity_type == filters.entity_type)
            
            if filters.is_active is not None:
                query = query.filter(ExternalMetadata.is_active == filters.is_active)
            
            if filters.validation_status:
                query = query.filter(ExternalMetadata.validation_status == filters.validation_status)
            
            if filters.sync_status:
                query = query.filter(ExternalMetadata.sync_status == filters.sync_status)
            
            if filters.search:
                search_term = f"%{filters.search}%"
                query = query.filter(
                    or_(
                        ExternalMetadata.name.ilike(search_term),
                        ExternalMetadata.description.ilike(search_term)
                    )
                )
        
        # Contar total
        total = query.count()
        
        # Aplicar ordenação
        order_column = getattr(ExternalMetadata, order_by, ExternalMetadata.created_at)
        if order_desc:
            query = query.order_by(order_column.desc())
        else:
            query = query.order_by(order_column.asc())
        
        # Aplicar paginação
        offset = (page - 1) * size
        items = query.offset(offset).limit(size).all()
        
        return items, total
    
    async def update_external_metadata(
        self,
        external_metadata_id: UUID,
        data: ExternalMetadataUpdate,
        unity_catalog_privileges: Optional[Dict[str, Any]] = None
    ) -> ExternalMetadata:
        """
        Atualiza objeto de metadados externo
        
        Args:
            external_metadata_id: ID do objeto
            data: Dados para atualização
            unity_catalog_privileges: Privilégios Unity Catalog do usuário
            
        Returns:
            Objeto ExternalMetadata atualizado
            
        Raises:
            NotFoundError: Se objeto não existe
            UnauthorizedError: Se usuário não tem privilégios necessários
            ValidationError: Se dados são inválidos
        """
        try:
            # Obter objeto existente
            external_metadata = await self.get_external_metadata(external_metadata_id)
            
            # Validar privilégios Unity Catalog
            await self._validate_modify_privileges(external_metadata, unity_catalog_privileges)
            
            # Aplicar atualizações
            update_data = data.dict(exclude_unset=True)
            for field, value in update_data.items():
                setattr(external_metadata, field, value)
            
            # Validar objeto atualizado
            is_valid, errors = external_metadata.is_valid()
            if not is_valid:
                raise ValidationError(f"Dados inválidos: {', '.join(errors)}")
            
            # Verificar conflito de nome se nome foi alterado
            if 'name' in update_data:
                existing = self.db.query(ExternalMetadata).filter(
                    and_(
                        ExternalMetadata.name == data.name,
                        ExternalMetadata.system_type == external_metadata.system_type,
                        ExternalMetadata.external_metadata_id != external_metadata_id,
                        ExternalMetadata.is_active == True
                    )
                ).first()
                
                if existing:
                    raise ConflictError(
                        f"Objeto externo '{data.name}' já existe no sistema '{external_metadata.system_type}'"
                    )
            
            self.db.commit()
            self.db.refresh(external_metadata)
            
            logger.info(f"External metadata atualizado: {external_metadata_id}")
            
            return external_metadata
            
        except Exception as e:
            self.db.rollback()
            logger.error(f"Erro ao atualizar external metadata {external_metadata_id}: {e}")
            raise
    
    async def delete_external_metadata(
        self,
        external_metadata_id: UUID,
        unity_catalog_privileges: Optional[Dict[str, Any]] = None,
        force: bool = False
    ) -> bool:
        """
        Remove objeto de metadados externo
        
        Args:
            external_metadata_id: ID do objeto
            unity_catalog_privileges: Privilégios Unity Catalog do usuário
            force: Forçar remoção mesmo com relacionamentos
            
        Returns:
            True se removido com sucesso
            
        Raises:
            NotFoundError: Se objeto não existe
            UnauthorizedError: Se usuário não tem privilégios necessários
            ConflictError: Se objeto tem relacionamentos e force=False
        """
        try:
            # Obter objeto existente
            external_metadata = await self.get_external_metadata(external_metadata_id)
            
            # Validar privilégios Unity Catalog
            await self._validate_modify_privileges(external_metadata, unity_catalog_privileges)
            
            # Verificar relacionamentos existentes
            relationships_count = self.db.query(ExternalLineageRelationships).filter(
                ExternalLineageRelationships.external_metadata_id == external_metadata_id
            ).count()
            
            mappings_count = self.db.query(ExternalColumnMappings).filter(
                ExternalColumnMappings.external_metadata_id == external_metadata_id
            ).count()
            
            if (relationships_count > 0 or mappings_count > 0) and not force:
                raise ConflictError(
                    f"Objeto tem {relationships_count} relacionamentos e {mappings_count} "
                    f"mapeamentos. Use force=True para remover"
                )
            
            # Remover relacionamentos e mapeamentos se force=True
            if force:
                self.db.query(ExternalLineageRelationships).filter(
                    ExternalLineageRelationships.external_metadata_id == external_metadata_id
                ).delete()
                
                self.db.query(ExternalColumnMappings).filter(
                    ExternalColumnMappings.external_metadata_id == external_metadata_id
                ).delete()
            
            # Remover objeto (soft delete)
            external_metadata.is_active = False
            external_metadata.updated_at = datetime.utcnow()
            
            self.db.commit()
            
            logger.info(f"External metadata removido: {external_metadata_id}")
            
            return True
            
        except Exception as e:
            self.db.rollback()
            logger.error(f"Erro ao remover external metadata {external_metadata_id}: {e}")
            raise
    
    async def create_lineage_relationship(
        self,
        data: ExternalLineageRelationshipCreate,
        unity_catalog_privileges: Optional[Dict[str, Any]] = None
    ) -> ExternalLineageRelationships:
        """
        Cria relacionamento de linhagem entre objeto externo e Unity Catalog
        
        Args:
            data: Dados do relacionamento
            unity_catalog_privileges: Privilégios Unity Catalog do usuário
            
        Returns:
            Objeto ExternalLineageRelationships criado
            
        Raises:
            ValidationError: Se dados são inválidos
            UnauthorizedError: Se usuário não tem privilégios necessários
            NotFoundError: Se objeto externo não existe
        """
        try:
            # Verificar se external metadata existe
            external_metadata = await self.get_external_metadata(data.external_metadata_id)
            
            # Validar privilégios baseado na direção do relacionamento
            await self._validate_relationship_privileges(
                data.relationship_direction,
                data.target_object_type,
                data.target_object_id,
                unity_catalog_privileges
            )
            
            # Criar relacionamento
            relationship = ExternalLineageRelationships(
                external_metadata_id=data.external_metadata_id,
                target_object_type=data.target_object_type,
                target_object_id=data.target_object_id,
                target_object_name=data.target_object_name,
                relationship_direction=data.relationship_direction,
                relationship_metadata=data.relationship_metadata,
                relationship_description=data.relationship_description,
                validation_status='pending'
            )
            
            self.db.add(relationship)
            
            # Criar mapeamentos de colunas se fornecidos
            if data.column_mappings:
                for mapping_data in data.column_mappings:
                    mapping = ExternalColumnMappings(
                        external_metadata_id=data.external_metadata_id,
                        source_column_name=mapping_data.source_column_name,
                        source_column_type=mapping_data.source_column_type,
                        source_column_description=mapping_data.source_column_description,
                        target_property_id=mapping_data.target_property_id,
                        target_column_name=mapping_data.target_column_name,
                        transformation_type=mapping_data.transformation_type,
                        transformation_description=mapping_data.transformation_description,
                        transformation_metadata=mapping_data.transformation_metadata,
                        compatibility_status='pending'
                    )
                    self.db.add(mapping)
            
            self.db.commit()
            self.db.refresh(relationship)
            
            logger.info(
                f"Relacionamento de linhagem criado: {relationship.relationship_id} "
                f"({data.relationship_direction})"
            )
            
            return relationship
            
        except Exception as e:
            self.db.rollback()
            logger.error(f"Erro ao criar relacionamento de linhagem: {e}")
            raise
    
    async def get_statistics(self) -> Dict[str, Any]:
        """
        Obtém estatísticas de External Metadata
        
        Returns:
            Dicionário com estatísticas
        """
        try:
            # Total de objetos
            total_objects = self.db.query(ExternalMetadata).filter(
                ExternalMetadata.is_active == True
            ).count()
            
            # Por tipo de sistema
            by_system_type = dict(
                self.db.query(
                    ExternalMetadata.system_type,
                    func.count(ExternalMetadata.external_metadata_id)
                ).filter(
                    ExternalMetadata.is_active == True
                ).group_by(ExternalMetadata.system_type).all()
            )
            
            # Por tipo de entidade
            by_entity_type = dict(
                self.db.query(
                    ExternalMetadata.entity_type,
                    func.count(ExternalMetadata.external_metadata_id)
                ).filter(
                    ExternalMetadata.is_active == True
                ).group_by(ExternalMetadata.entity_type).all()
            )
            
            # Por status de validação
            by_validation_status = dict(
                self.db.query(
                    ExternalMetadata.validation_status,
                    func.count(ExternalMetadata.external_metadata_id)
                ).filter(
                    ExternalMetadata.is_active == True
                ).group_by(ExternalMetadata.validation_status).all()
            )
            
            # Por status de sincronização
            by_sync_status = dict(
                self.db.query(
                    ExternalMetadata.sync_status,
                    func.count(ExternalMetadata.external_metadata_id)
                ).filter(
                    ExternalMetadata.is_active == True
                ).group_by(ExternalMetadata.sync_status).all()
            )
            
            # Total de relacionamentos
            total_relationships = self.db.query(ExternalLineageRelationships).filter(
                ExternalLineageRelationships.is_active == True
            ).count()
            
            # Total de mapeamentos de colunas
            total_column_mappings = self.db.query(ExternalColumnMappings).count()
            
            return {
                'total_objects': total_objects,
                'by_system_type': by_system_type,
                'by_entity_type': by_entity_type,
                'by_validation_status': by_validation_status,
                'by_sync_status': by_sync_status,
                'total_relationships': total_relationships,
                'total_column_mappings': total_column_mappings
            }
            
        except Exception as e:
            logger.error(f"Erro ao obter estatísticas: {e}")
            raise
    
    async def _validate_create_privileges(
        self, 
        unity_catalog_privileges: Optional[Dict[str, Any]]
    ) -> None:
        """Valida privilégios para criação de external metadata"""
        if not unity_catalog_privileges:
            raise UnauthorizedError("Privilégios Unity Catalog não fornecidos")
        
        # Verificar privilégio CREATE EXTERNAL METADATA no metastore
        metastore_privileges = unity_catalog_privileges.get('metastore', [])
        if 'CREATE EXTERNAL METADATA' not in metastore_privileges:
            raise UnauthorizedError(
                "Usuário não possui privilégio 'CREATE EXTERNAL METADATA' no metastore"
            )
    
    async def _validate_modify_privileges(
        self,
        external_metadata: ExternalMetadata,
        unity_catalog_privileges: Optional[Dict[str, Any]]
    ) -> None:
        """Valida privilégios para modificação de external metadata"""
        if not unity_catalog_privileges:
            raise UnauthorizedError("Privilégios Unity Catalog não fornecidos")
        
        # Verificar privilégio MODIFY no objeto external metadata
        object_privileges = unity_catalog_privileges.get('external_metadata', {})
        object_id = str(external_metadata.external_metadata_id)
        
        if object_id not in object_privileges or 'MODIFY' not in object_privileges[object_id]:
            raise UnauthorizedError(
                f"Usuário não possui privilégio 'MODIFY' no objeto {object_id}"
            )
    
    async def _validate_relationship_privileges(
        self,
        direction: str,
        target_type: str,
        target_id: str,
        unity_catalog_privileges: Optional[Dict[str, Any]]
    ) -> None:
        """Valida privilégios para criação de relacionamentos"""
        if not unity_catalog_privileges:
            raise UnauthorizedError("Privilégios Unity Catalog não fornecidos")
        
        # Privilégios necessários baseados na direção
        if direction == 'downstream':
            # Relacionamento downstream requer privilégios de leitura no objeto target
            required_privilege = 'SELECT' if target_type == 'table' else 'READ'
        else:
            # Relacionamento upstream requer privilégios de escrita no objeto target
            required_privilege = 'MODIFY'
        
        # Verificar privilégios no objeto target
        target_privileges = unity_catalog_privileges.get(target_type, {})
        if target_id not in target_privileges or required_privilege not in target_privileges[target_id]:
            raise UnauthorizedError(
                f"Usuário não possui privilégio '{required_privilege}' no objeto {target_type}:{target_id}"
            )

