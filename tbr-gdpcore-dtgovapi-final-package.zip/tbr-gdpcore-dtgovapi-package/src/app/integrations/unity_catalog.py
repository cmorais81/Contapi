"""
Integração com Unity Catalog
Autor: Carlos Morais

Integração completa com Databricks Unity Catalog para
sincronização de metadados e governança.
"""

import json
import requests
from typing import Dict, List, Optional, Any
from datetime import datetime
from dataclasses import dataclass

from ..utils.exceptions import DataGovernanceException
from ..utils.observability import trace_operation
from ..utils.audit import audit_logger, AuditEventType


@dataclass
class UnityCatalogConfig:
    """Configuração do Unity Catalog"""
    workspace_url: str
    access_token: str
    catalog_name: str
    schema_name: str
    timeout: int = 30
    max_retries: int = 3


class UnityCatalogIntegration:
    """Integração com Databricks Unity Catalog"""
    
    def __init__(self, config: UnityCatalogConfig):
        self.config = config
        self.base_url = f"{config.workspace_url}/api/2.1/unity-catalog"
        self.headers = {
            "Authorization": f"Bearer {config.access_token}",
            "Content-Type": "application/json"
        }
    
    @trace_operation("unity_catalog.sync_metadata", "integration")
    def sync_metadata(self) -> Dict[str, Any]:
        """
        Sincroniza metadados do Unity Catalog
        
        Returns:
            Resultado da sincronização
        """
        try:
            # Buscar catálogos
            catalogs = self._get_catalogs()
            
            # Buscar schemas
            schemas = self._get_schemas()
            
            # Buscar tabelas
            tables = self._get_tables()
            
            # Buscar colunas
            columns = self._get_columns()
            
            sync_result = {
                "timestamp": datetime.utcnow().isoformat(),
                "catalogs_count": len(catalogs),
                "schemas_count": len(schemas),
                "tables_count": len(tables),
                "columns_count": len(columns),
                "status": "success"
            }
            
            # Registrar auditoria
            audit_logger.log_event({
                "event_type": AuditEventType.SYNC,
                "resource_type": "unity_catalog",
                "action": "metadata_sync",
                "details": sync_result
            })
            
            return sync_result
            
        except Exception as e:
            raise DataGovernanceException(f"Erro na sincronização Unity Catalog: {str(e)}")
    
    def _get_catalogs(self) -> List[Dict[str, Any]]:
        """Busca catálogos do Unity Catalog"""
        try:
            response = requests.get(
                f"{self.base_url}/catalogs",
                headers=self.headers,
                timeout=self.config.timeout
            )
            response.raise_for_status()
            
            data = response.json()
            return data.get("catalogs", [])
            
        except requests.RequestException as e:
            raise DataGovernanceException(f"Erro ao buscar catálogos: {str(e)}")
    
    def _get_schemas(self) -> List[Dict[str, Any]]:
        """Busca schemas do Unity Catalog"""
        try:
            response = requests.get(
                f"{self.base_url}/schemas",
                headers=self.headers,
                params={"catalog_name": self.config.catalog_name},
                timeout=self.config.timeout
            )
            response.raise_for_status()
            
            data = response.json()
            return data.get("schemas", [])
            
        except requests.RequestException as e:
            raise DataGovernanceException(f"Erro ao buscar schemas: {str(e)}")
    
    def _get_tables(self) -> List[Dict[str, Any]]:
        """Busca tabelas do Unity Catalog"""
        try:
            response = requests.get(
                f"{self.base_url}/tables",
                headers=self.headers,
                params={
                    "catalog_name": self.config.catalog_name,
                    "schema_name": self.config.schema_name
                },
                timeout=self.config.timeout
            )
            response.raise_for_status()
            
            data = response.json()
            return data.get("tables", [])
            
        except requests.RequestException as e:
            raise DataGovernanceException(f"Erro ao buscar tabelas: {str(e)}")
    
    def _get_columns(self) -> List[Dict[str, Any]]:
        """Busca colunas das tabelas"""
        columns = []
        tables = self._get_tables()
        
        for table in tables:
            try:
                response = requests.get(
                    f"{self.base_url}/tables/{table['full_name']}",
                    headers=self.headers,
                    timeout=self.config.timeout
                )
                response.raise_for_status()
                
                table_info = response.json()
                table_columns = table_info.get("columns", [])
                
                for column in table_columns:
                    column["table_name"] = table["name"]
                    column["table_full_name"] = table["full_name"]
                    columns.append(column)
                    
            except requests.RequestException:
                continue  # Pular tabelas com erro
        
        return columns
    
    @trace_operation("unity_catalog.create_table", "integration")
    def create_table(self, table_definition: Dict[str, Any]) -> Dict[str, Any]:
        """
        Cria tabela no Unity Catalog
        
        Args:
            table_definition: Definição da tabela
            
        Returns:
            Resultado da criação
        """
        try:
            response = requests.post(
                f"{self.base_url}/tables",
                headers=self.headers,
                json=table_definition,
                timeout=self.config.timeout
            )
            response.raise_for_status()
            
            result = response.json()
            
            # Registrar auditoria
            audit_logger.log_event({
                "event_type": AuditEventType.CREATE,
                "resource_type": "unity_catalog_table",
                "resource_id": result.get("full_name"),
                "action": "table_created",
                "details": {"table_name": table_definition.get("name")}
            })
            
            return result
            
        except requests.RequestException as e:
            raise DataGovernanceException(f"Erro ao criar tabela: {str(e)}")
    
    @trace_operation("unity_catalog.update_table_tags", "integration")
    def update_table_tags(self, table_name: str, tags: Dict[str, str]) -> Dict[str, Any]:
        """
        Atualiza tags de uma tabela
        
        Args:
            table_name: Nome da tabela
            tags: Tags para aplicar
            
        Returns:
            Resultado da atualização
        """
        try:
            full_name = f"{self.config.catalog_name}.{self.config.schema_name}.{table_name}"
            
            response = requests.patch(
                f"{self.base_url}/tables/{full_name}",
                headers=self.headers,
                json={"tags": tags},
                timeout=self.config.timeout
            )
            response.raise_for_status()
            
            result = response.json()
            
            # Registrar auditoria
            audit_logger.log_event({
                "event_type": AuditEventType.UPDATE,
                "resource_type": "unity_catalog_table",
                "resource_id": full_name,
                "action": "tags_updated",
                "details": {"tags": tags}
            })
            
            return result
            
        except requests.RequestException as e:
            raise DataGovernanceException(f"Erro ao atualizar tags: {str(e)}")
    
    @trace_operation("unity_catalog.get_lineage", "integration")
    def get_lineage(self, table_name: str) -> Dict[str, Any]:
        """
        Obtém linhagem de uma tabela
        
        Args:
            table_name: Nome da tabela
            
        Returns:
            Informações de linhagem
        """
        try:
            full_name = f"{self.config.catalog_name}.{self.config.schema_name}.{table_name}"
            
            response = requests.get(
                f"{self.base_url}/lineage-events",
                headers=self.headers,
                params={"table_name": full_name},
                timeout=self.config.timeout
            )
            response.raise_for_status()
            
            return response.json()
            
        except requests.RequestException as e:
            raise DataGovernanceException(f"Erro ao obter linhagem: {str(e)}")
    
    @trace_operation("unity_catalog.apply_data_contract", "integration")
    def apply_data_contract(self, contract_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Aplica contrato de dados no Unity Catalog
        
        Args:
            contract_data: Dados do contrato
            
        Returns:
            Resultado da aplicação
        """
        try:
            table_name = contract_data.get("table_name")
            schema_definition = contract_data.get("schema")
            quality_rules = contract_data.get("quality_rules", [])
            
            # Criar/atualizar tabela com schema
            table_def = {
                "name": table_name,
                "catalog_name": self.config.catalog_name,
                "schema_name": self.config.schema_name,
                "table_type": "MANAGED",
                "columns": schema_definition,
                "comment": f"Tabela gerenciada por contrato de dados - {contract_data.get('contract_name')}"
            }
            
            # Aplicar tags de governança
            governance_tags = {
                "data_contract": contract_data.get("contract_id"),
                "governance_level": contract_data.get("governance_level", "managed"),
                "data_classification": contract_data.get("classification", "internal"),
                "quality_tier": contract_data.get("quality_tier", "bronze")
            }
            
            # Criar tabela
            table_result = self.create_table(table_def)
            
            # Aplicar tags
            tags_result = self.update_table_tags(table_name, governance_tags)
            
            return {
                "table_created": table_result,
                "tags_applied": tags_result,
                "quality_rules_count": len(quality_rules),
                "status": "success"
            }
            
        except Exception as e:
            raise DataGovernanceException(f"Erro ao aplicar contrato: {str(e)}")
    
    @trace_operation("unity_catalog.validate_compliance", "integration")
    def validate_compliance(self, table_name: str) -> Dict[str, Any]:
        """
        Valida compliance de uma tabela
        
        Args:
            table_name: Nome da tabela
            
        Returns:
            Resultado da validação
        """
        try:
            full_name = f"{self.config.catalog_name}.{self.config.schema_name}.{table_name}"
            
            # Buscar informações da tabela
            response = requests.get(
                f"{self.base_url}/tables/{full_name}",
                headers=self.headers,
                timeout=self.config.timeout
            )
            response.raise_for_status()
            
            table_info = response.json()
            
            # Validar compliance
            compliance_checks = {
                "has_data_contract": "data_contract" in table_info.get("tags", {}),
                "has_classification": "data_classification" in table_info.get("tags", {}),
                "has_owner": table_info.get("owner") is not None,
                "has_description": bool(table_info.get("comment")),
                "schema_documented": len(table_info.get("columns", [])) > 0
            }
            
            compliance_score = sum(compliance_checks.values()) / len(compliance_checks) * 100
            
            return {
                "table_name": table_name,
                "compliance_score": compliance_score,
                "checks": compliance_checks,
                "status": "compliant" if compliance_score >= 80 else "non_compliant",
                "recommendations": self._generate_compliance_recommendations(compliance_checks)
            }
            
        except requests.RequestException as e:
            raise DataGovernanceException(f"Erro na validação de compliance: {str(e)}")
    
    def _generate_compliance_recommendations(self, checks: Dict[str, bool]) -> List[str]:
        """Gera recomendações de compliance"""
        recommendations = []
        
        if not checks.get("has_data_contract"):
            recommendations.append("Associar tabela a um contrato de dados")
        
        if not checks.get("has_classification"):
            recommendations.append("Definir classificação de dados")
        
        if not checks.get("has_owner"):
            recommendations.append("Definir proprietário da tabela")
        
        if not checks.get("has_description"):
            recommendations.append("Adicionar descrição da tabela")
        
        if not checks.get("schema_documented"):
            recommendations.append("Documentar schema das colunas")
        
        return recommendations
    
    @trace_operation("unity_catalog.get_usage_metrics", "integration")
    def get_usage_metrics(self, table_name: str, days: int = 30) -> Dict[str, Any]:
        """
        Obtém métricas de uso de uma tabela
        
        Args:
            table_name: Nome da tabela
            days: Número de dias para análise
            
        Returns:
            Métricas de uso
        """
        try:
            full_name = f"{self.config.catalog_name}.{self.config.schema_name}.{table_name}"
            
            # Simular métricas de uso (em produção, usar APIs reais)
            usage_metrics = {
                "table_name": table_name,
                "period_days": days,
                "total_queries": 1247,
                "unique_users": 23,
                "avg_daily_queries": 41.6,
                "peak_usage_hour": 14,
                "data_volume_gb": 156.7,
                "last_accessed": datetime.utcnow().isoformat(),
                "top_users": [
                    {"user": "data_analyst_1", "query_count": 89},
                    {"user": "data_scientist_2", "query_count": 67},
                    {"user": "business_user_3", "query_count": 45}
                ],
                "query_patterns": {
                    "select_only": 78.2,
                    "aggregations": 15.6,
                    "joins": 6.2
                }
            }
            
            return usage_metrics
            
        except Exception as e:
            raise DataGovernanceException(f"Erro ao obter métricas de uso: {str(e)}")
    
    def health_check(self) -> Dict[str, Any]:
        """
        Verifica conectividade com Unity Catalog
        
        Returns:
            Status da conexão
        """
        try:
            response = requests.get(
                f"{self.base_url}/catalogs",
                headers=self.headers,
                timeout=5
            )
            response.raise_for_status()
            
            return {
                "status": "healthy",
                "response_time_ms": response.elapsed.total_seconds() * 1000,
                "workspace_url": self.config.workspace_url,
                "catalog_name": self.config.catalog_name
            }
            
        except Exception as e:
            return {
                "status": "unhealthy",
                "error": str(e),
                "workspace_url": self.config.workspace_url
            }

