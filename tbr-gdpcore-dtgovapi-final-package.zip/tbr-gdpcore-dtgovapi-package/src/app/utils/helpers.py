"""
Helpers para Data Governance API
Autor: Carlos Morais

Módulo com funções auxiliares para operações comuns,
manipulação de dados e utilitários gerais.
"""

import hashlib
import uuid
import json
import re
from typing import Any, Dict, List, Optional, Union, Tuple
from datetime import datetime, timedelta
from collections import defaultdict
import copy


def generate_uuid() -> str:
    """
    Gera UUID único
    
    Returns:
        String UUID
    """
    return str(uuid.uuid4())


def calculate_hash(data: Union[str, Dict[str, Any]], algorithm: str = "sha256") -> str:
    """
    Calcula hash de dados
    
    Args:
        data: Dados para hash
        algorithm: Algoritmo (md5, sha1, sha256, sha512)
        
    Returns:
        Hash hexadecimal
    """
    if isinstance(data, dict):
        data_str = json.dumps(data, sort_keys=True, default=str)
    else:
        data_str = str(data)
    
    if algorithm == "md5":
        return hashlib.md5(data_str.encode()).hexdigest()
    elif algorithm == "sha1":
        return hashlib.sha1(data_str.encode()).hexdigest()
    elif algorithm == "sha256":
        return hashlib.sha256(data_str.encode()).hexdigest()
    elif algorithm == "sha512":
        return hashlib.sha512(data_str.encode()).hexdigest()
    else:
        raise ValueError(f"Algoritmo não suportado: {algorithm}")


def deep_merge_dict(dict1: Dict[str, Any], dict2: Dict[str, Any]) -> Dict[str, Any]:
    """
    Faz merge profundo de dicionários
    
    Args:
        dict1: Dicionário base
        dict2: Dicionário para merge
        
    Returns:
        Dicionário merged
    """
    result = copy.deepcopy(dict1)
    
    for key, value in dict2.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = deep_merge_dict(result[key], value)
        else:
            result[key] = copy.deepcopy(value)
    
    return result


def flatten_dict(data: Dict[str, Any], separator: str = ".", prefix: str = "") -> Dict[str, Any]:
    """
    Achata dicionário aninhado
    
    Args:
        data: Dicionário para achatar
        separator: Separador para chaves
        prefix: Prefixo para chaves
        
    Returns:
        Dicionário achatado
    """
    result = {}
    
    for key, value in data.items():
        new_key = f"{prefix}{separator}{key}" if prefix else key
        
        if isinstance(value, dict):
            result.update(flatten_dict(value, separator, new_key))
        elif isinstance(value, list):
            for i, item in enumerate(value):
                if isinstance(item, dict):
                    result.update(flatten_dict(item, separator, f"{new_key}[{i}]"))
                else:
                    result[f"{new_key}[{i}]"] = item
        else:
            result[new_key] = value
    
    return result


def unflatten_dict(data: Dict[str, Any], separator: str = ".") -> Dict[str, Any]:
    """
    Reconstrói dicionário aninhado a partir de chaves achatadas
    
    Args:
        data: Dicionário achatado
        separator: Separador usado nas chaves
        
    Returns:
        Dicionário aninhado
    """
    result = {}
    
    for key, value in data.items():
        keys = key.split(separator)
        current = result
        
        for k in keys[:-1]:
            if k not in current:
                current[k] = {}
            current = current[k]
        
        current[keys[-1]] = value
    
    return result


def sanitize_string(text: str, allow_special: bool = False) -> str:
    """
    Sanitiza string removendo caracteres perigosos
    
    Args:
        text: Texto para sanitizar
        allow_special: Se permite caracteres especiais básicos
        
    Returns:
        String sanitizada
    """
    if allow_special:
        # Remove apenas caracteres realmente perigosos
        sanitized = re.sub(r'[<>"\';\\]', '', text)
    else:
        # Mantém apenas alfanuméricos, espaços e alguns especiais
        sanitized = re.sub(r'[^a-zA-Z0-9\s\-_\.]', '', text)
    
    # Remove espaços extras
    sanitized = re.sub(r'\s+', ' ', sanitized).strip()
    
    return sanitized


def extract_keywords(text: str, min_length: int = 3) -> List[str]:
    """
    Extrai palavras-chave de um texto
    
    Args:
        text: Texto para análise
        min_length: Comprimento mínimo das palavras
        
    Returns:
        Lista de palavras-chave
    """
    # Remove pontuação e converte para minúsculas
    clean_text = re.sub(r'[^\w\s]', ' ', text.lower())
    
    # Divide em palavras
    words = clean_text.split()
    
    # Filtra palavras muito curtas e stop words básicas
    stop_words = {
        'a', 'an', 'and', 'are', 'as', 'at', 'be', 'by', 'for', 'from',
        'has', 'he', 'in', 'is', 'it', 'its', 'of', 'on', 'that', 'the',
        'to', 'was', 'will', 'with', 'o', 'a', 'os', 'as', 'um', 'uma',
        'de', 'do', 'da', 'dos', 'das', 'em', 'no', 'na', 'nos', 'nas',
        'para', 'por', 'com', 'sem', 'que', 'se', 'é', 'são', 'foi', 'foram'
    }
    
    keywords = [
        word for word in words 
        if len(word) >= min_length and word not in stop_words
    ]
    
    # Remove duplicatas mantendo ordem
    seen = set()
    unique_keywords = []
    for keyword in keywords:
        if keyword not in seen:
            seen.add(keyword)
            unique_keywords.append(keyword)
    
    return unique_keywords


def calculate_similarity(text1: str, text2: str) -> float:
    """
    Calcula similaridade entre dois textos (Jaccard)
    
    Args:
        text1: Primeiro texto
        text2: Segundo texto
        
    Returns:
        Score de similaridade (0-1)
    """
    words1 = set(extract_keywords(text1))
    words2 = set(extract_keywords(text2))
    
    if not words1 and not words2:
        return 1.0
    
    intersection = words1.intersection(words2)
    union = words1.union(words2)
    
    return len(intersection) / len(union) if union else 0.0


def group_by_key(items: List[Dict[str, Any]], key: str) -> Dict[str, List[Dict[str, Any]]]:
    """
    Agrupa lista de dicionários por chave
    
    Args:
        items: Lista de dicionários
        key: Chave para agrupamento
        
    Returns:
        Dicionário agrupado
    """
    grouped = defaultdict(list)
    
    for item in items:
        if key in item:
            grouped[item[key]].append(item)
    
    return dict(grouped)


def sort_by_multiple_keys(items: List[Dict[str, Any]], keys: List[Tuple[str, bool]]) -> List[Dict[str, Any]]:
    """
    Ordena lista por múltiplas chaves
    
    Args:
        items: Lista para ordenar
        keys: Lista de tuplas (chave, reverso)
        
    Returns:
        Lista ordenada
    """
    sorted_items = items.copy()
    
    # Ordena por cada chave em ordem reversa
    for key, reverse in reversed(keys):
        sorted_items.sort(
            key=lambda x: x.get(key, ''), 
            reverse=reverse
        )
    
    return sorted_items


def paginate_list(items: List[Any], page: int, page_size: int) -> Tuple[List[Any], Dict[str, Any]]:
    """
    Pagina lista de itens
    
    Args:
        items: Lista para paginar
        page: Número da página (1-based)
        page_size: Tamanho da página
        
    Returns:
        Tupla com (itens_paginados, metadados_paginacao)
    """
    total_items = len(items)
    total_pages = (total_items + page_size - 1) // page_size
    
    start_index = (page - 1) * page_size
    end_index = start_index + page_size
    
    paginated_items = items[start_index:end_index]
    
    metadata = {
        "page": page,
        "page_size": page_size,
        "total_items": total_items,
        "total_pages": total_pages,
        "has_next": page < total_pages,
        "has_previous": page > 1
    }
    
    return paginated_items, metadata


def filter_dict_by_keys(data: Dict[str, Any], allowed_keys: List[str]) -> Dict[str, Any]:
    """
    Filtra dicionário mantendo apenas chaves permitidas
    
    Args:
        data: Dicionário para filtrar
        allowed_keys: Chaves permitidas
        
    Returns:
        Dicionário filtrado
    """
    return {key: value for key, value in data.items() if key in allowed_keys}


def remove_none_values(data: Dict[str, Any], recursive: bool = True) -> Dict[str, Any]:
    """
    Remove valores None de dicionário
    
    Args:
        data: Dicionário para limpar
        recursive: Se deve limpar recursivamente
        
    Returns:
        Dicionário sem valores None
    """
    cleaned = {}
    
    for key, value in data.items():
        if value is not None:
            if recursive and isinstance(value, dict):
                cleaned_value = remove_none_values(value, recursive)
                if cleaned_value:  # Só adiciona se não estiver vazio
                    cleaned[key] = cleaned_value
            elif recursive and isinstance(value, list):
                cleaned_list = [
                    remove_none_values(item, recursive) if isinstance(item, dict) else item
                    for item in value if item is not None
                ]
                if cleaned_list:  # Só adiciona se não estiver vazio
                    cleaned[key] = cleaned_list
            else:
                cleaned[key] = value
    
    return cleaned


def convert_keys_to_snake_case(data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Converte chaves de dicionário para snake_case
    
    Args:
        data: Dicionário para converter
        
    Returns:
        Dicionário com chaves em snake_case
    """
    def to_snake_case(name: str) -> str:
        # Converte CamelCase para snake_case
        s1 = re.sub('(.)([A-Z][a-z]+)', r'\1_\2', name)
        return re.sub('([a-z0-9])([A-Z])', r'\1_\2', s1).lower()
    
    converted = {}
    
    for key, value in data.items():
        snake_key = to_snake_case(key)
        
        if isinstance(value, dict):
            converted[snake_key] = convert_keys_to_snake_case(value)
        elif isinstance(value, list):
            converted[snake_key] = [
                convert_keys_to_snake_case(item) if isinstance(item, dict) else item
                for item in value
            ]
        else:
            converted[snake_key] = value
    
    return converted


def convert_keys_to_camel_case(data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Converte chaves de dicionário para camelCase
    
    Args:
        data: Dicionário para converter
        
    Returns:
        Dicionário com chaves em camelCase
    """
    def to_camel_case(name: str) -> str:
        components = name.split('_')
        return components[0] + ''.join(word.capitalize() for word in components[1:])
    
    converted = {}
    
    for key, value in data.items():
        camel_key = to_camel_case(key)
        
        if isinstance(value, dict):
            converted[camel_key] = convert_keys_to_camel_case(value)
        elif isinstance(value, list):
            converted[camel_key] = [
                convert_keys_to_camel_case(item) if isinstance(item, dict) else item
                for item in value
            ]
        else:
            converted[camel_key] = value
    
    return converted


def calculate_percentage_change(old_value: float, new_value: float) -> float:
    """
    Calcula mudança percentual entre dois valores
    
    Args:
        old_value: Valor antigo
        new_value: Valor novo
        
    Returns:
        Mudança percentual
    """
    if old_value == 0:
        return 100.0 if new_value > 0 else 0.0
    
    return ((new_value - old_value) / old_value) * 100


def chunk_list(items: List[Any], chunk_size: int) -> List[List[Any]]:
    """
    Divide lista em chunks menores
    
    Args:
        items: Lista para dividir
        chunk_size: Tamanho de cada chunk
        
    Returns:
        Lista de chunks
    """
    chunks = []
    for i in range(0, len(items), chunk_size):
        chunks.append(items[i:i + chunk_size])
    return chunks


def retry_operation(operation, max_retries: int = 3, delay: float = 1.0):
    """
    Executa operação com retry automático
    
    Args:
        operation: Função para executar
        max_retries: Número máximo de tentativas
        delay: Delay entre tentativas (segundos)
        
    Returns:
        Resultado da operação
        
    Raises:
        Exception: Se todas as tentativas falharem
    """
    import time
    
    last_exception = None
    
    for attempt in range(max_retries + 1):
        try:
            return operation()
        except Exception as e:
            last_exception = e
            if attempt < max_retries:
                time.sleep(delay * (2 ** attempt))  # Exponential backoff
            else:
                raise last_exception


def validate_json_structure(data: Dict[str, Any], required_fields: List[str]) -> bool:
    """
    Valida se JSON tem estrutura esperada
    
    Args:
        data: Dados para validar
        required_fields: Campos obrigatórios
        
    Returns:
        True se estrutura válida
        
    Raises:
        ValueError: Se estrutura inválida
    """
    missing_fields = []
    
    for field in required_fields:
        if '.' in field:
            # Campo aninhado
            keys = field.split('.')
            current = data
            
            for key in keys:
                if not isinstance(current, dict) or key not in current:
                    missing_fields.append(field)
                    break
                current = current[key]
        else:
            # Campo simples
            if field not in data:
                missing_fields.append(field)
    
    if missing_fields:
        raise ValueError(f"Campos obrigatórios ausentes: {', '.join(missing_fields)}")
    
    return True


def generate_correlation_id() -> str:
    """
    Gera ID de correlação para rastreamento
    
    Returns:
        ID de correlação único
    """
    timestamp = datetime.utcnow().strftime("%Y%m%d%H%M%S")
    random_part = str(uuid.uuid4())[:8]
    return f"{timestamp}-{random_part}"


def safe_divide(numerator: float, denominator: float, default: float = 0.0) -> float:
    """
    Divisão segura que evita divisão por zero
    
    Args:
        numerator: Numerador
        denominator: Denominador
        default: Valor padrão se denominador for zero
        
    Returns:
        Resultado da divisão ou valor padrão
    """
    return numerator / denominator if denominator != 0 else default

