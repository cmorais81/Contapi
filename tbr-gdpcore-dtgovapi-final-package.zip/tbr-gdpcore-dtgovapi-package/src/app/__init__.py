"""
Pacote principal da API de Governança de Dados
"""

__version__ = "2.1.0"

