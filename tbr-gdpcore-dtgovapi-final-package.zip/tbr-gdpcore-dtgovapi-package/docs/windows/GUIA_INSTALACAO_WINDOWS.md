# Guia de Instalação - tbr-gdpcore-dtgovapi para Windows

Este guia fornece instruções detalhadas para instalar e executar a API de Governança de Dados (tbr-gdpcore-dtgovapi) em um ambiente Windows usando PowerShell.

## Requisitos de Sistema

- Windows 10/11 (64-bit)
- Python 3.9+ (recomendado: Python 3.11)
- PostgreSQL 13+
- PowerShell 5.1+
- Git

## 1. Preparação do Ambiente

### 1.1. Instalação do Python

1. Baixe o instalador do Python 3.11 do [site oficial](https://www.python.org/downloads/windows/)
2. Execute o instalador e marque a opção "Add Python to PATH"
3. Marque também a opção "Install pip"
4. Conclua a instalação

Verifique a instalação abrindo o PowerShell e executando:

```powershell
python --version
pip --version
```

### 1.2. Instalação do PostgreSQL

1. Baixe o instalador do PostgreSQL 13 do [site oficial](https://www.postgresql.org/download/windows/)
2. Execute o instalador e siga as instruções
3. Anote a senha do usuário postgres definida durante a instalação
4. Mantenha a porta padrão (5432)
5. Conclua a instalação

### 1.3. Instalação do Git

1. Baixe o instalador do Git do [site oficial](https://git-scm.com/download/win)
2. Execute o instalador com as opções padrão
3. Conclua a instalação

### 1.4. Configuração do PowerShell

Por padrão, o PowerShell pode ter restrições de execução de scripts. Para permitir a execução dos scripts do projeto, abra o PowerShell como administrador e execute:

```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

## 2. Clonagem do Repositório

Abra o PowerShell e execute:

```powershell
cd C:\Projetos
git clone https://github.com/sua-empresa/tbr-gdpcore-dtgovapi.git
cd tbr-gdpcore-dtgovapi
```

## 3. Configuração e Execução

### 3.1. Usando os Scripts PowerShell Automatizados

O projeto inclui scripts PowerShell que automatizam a configuração e execução da aplicação:

1. **Configuração do Banco de Dados**:
   ```powershell
   .\deployment\windows\Setup-Database.ps1
   ```
   Este script irá:
   - Criar o banco de dados e o usuário necessários
   - Executar o script de criação de tabelas
   - Configurar o arquivo .env com as credenciais do banco de dados

2. **Inicialização da Aplicação**:
   ```powershell
   .\deployment\windows\Start-Application.ps1
   ```
   Este script irá:
   - Criar e ativar um ambiente virtual Python
   - Instalar as dependências necessárias
   - Iniciar a aplicação

3. **Execução de Testes**:
   ```powershell
   .\deployment\windows\Run-Tests.ps1
   ```
   Este script irá:
   - Ativar o ambiente virtual
   - Apresentar um menu para selecionar o tipo de teste a ser executado

### 3.2. Configuração Manual

Se preferir configurar manualmente, siga estes passos:

1. **Criação do Ambiente Virtual**:
   ```powershell
   python -m venv venv
   .\venv\Scripts\Activate.ps1
   ```

2. **Instalação das Dependências**:
   ```powershell
   pip install -r requirements.txt
   ```

3. **Configuração do Banco de Dados**:
   - Abra o SQL Shell (psql) ou pgAdmin
   - Crie um banco de dados chamado `tbr_gdpcore_dtgovapi`
   - Crie um usuário chamado `tbr_gdpcore_user` com senha `sua_senha_segura`
   - Conceda todos os privilégios no banco de dados ao usuário
   - Execute o script `database/create_tables.sql`

4. **Configuração do Arquivo .env**:
   Crie um arquivo `.env` na raiz do projeto com o seguinte conteúdo:
   ```
   DATABASE_URL=postgresql://tbr_gdpcore_user:sua_senha_segura@localhost:5432/tbr_gdpcore_dtgovapi
   SECRET_KEY=temporario_substituir_em_producao
   DEBUG=True
   ENVIRONMENT=development
   ```

5. **Execução da Aplicação**:
   ```powershell
   cd src
   python -m uvicorn main:app --reload --host 0.0.0.0 --port 8000
   ```

## 4. Acesso à Aplicação

Após iniciar a aplicação, você pode acessá-la através do navegador:

- Interface Swagger: http://localhost:8000/docs
- Interface ReDoc: http://localhost:8000/redoc
- API Root: http://localhost:8000/api/v1

## 5. Solução de Problemas Comuns

### 5.1. Erro de Execução de Scripts PowerShell

**Problema**: Mensagem de erro indicando que a execução de scripts está desabilitada.

**Solução**: Execute o PowerShell como administrador e execute:
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

### 5.2. Erro de Conexão com o Banco de Dados

**Problema**: A aplicação não consegue se conectar ao banco de dados.

**Solução**:
- Verifique se o PostgreSQL está em execução
- Verifique as credenciais no arquivo `.env`
- Verifique se o firewall não está bloqueando a porta 5432

### 5.3. Erro de Dependências

**Problema**: Erros ao instalar dependências.

**Solução**:
```powershell
pip install --upgrade pip
pip install -r requirements.txt --force-reinstall
```

### 5.4. Erro de Importação de Módulos

**Problema**: Erros como "ModuleNotFoundError" ao executar a aplicação.

**Solução**:
- Certifique-se de que o ambiente virtual está ativado
- Execute a aplicação a partir do diretório raiz do projeto
- Defina a variável de ambiente PYTHONPATH:
  ```powershell
  $env:PYTHONPATH = "src"
  ```

## 6. Próximos Passos

Após a instalação bem-sucedida:

1. Explore a documentação da API em http://localhost:8000/docs
2. Revise o modelo de dados em `models/modelo_completo_v2.1.dbml`
3. Consulte `docs/RESUMO_ALTERACOES_MODELO_V2.1.md` para entender as últimas atualizações

## 7. Suporte

Para obter suporte, entre em contato com a equipe de desenvolvimento em support@sua-empresa.com

