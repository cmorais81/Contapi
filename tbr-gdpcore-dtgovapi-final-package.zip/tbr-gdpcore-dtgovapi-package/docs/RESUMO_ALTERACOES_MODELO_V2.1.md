# Resumo de Alterações - Modelo de Dados v2.1

## Visão Geral

O modelo de dados da API de Governança de Dados (tbr-gdpcore-dtgovapi) foi atualizado para a versão 2.1, incorporando suporte completo ao Unity Catalog External Lineage. Esta atualização permite a integração avançada com sistemas externos e fornece rastreabilidade completa de dados entre diferentes plataformas.

## Alterações Principais

### Novas Entidades

1. **external_metadata**
   - Armazena informações sobre objetos em sistemas externos
   - Suporta 13 tipos de sistemas externos (vs. 6 do Unity Catalog padrão)
   - Inclui validação e sincronização avançadas

2. **external_column_mappings**
   - Mapeia colunas entre sistemas externos e Unity Catalog
   - Suporta transformações e validação de compatibilidade de tipos
   - Permite rastreamento granular de dados em nível de coluna

3. **external_lineage_relationships**
   - Define relacionamentos de linhagem entre objetos externos e Unity Catalog
   - Suporta relacionamentos bidirecionais (upstream/downstream)
   - Inclui metadados enriquecidos e validação

### Novos Índices

Foram adicionados 10 novos índices otimizados para as entidades de External Lineage:

- 6 índices para `external_metadata`
- 2 índices para `external_column_mappings`
- 4 índices para `external_lineage_relationships`

### Novos Relacionamentos

Foram adicionados 3 novos relacionamentos:

- `external_metadata.validated_by > users.id`
- `external_column_mappings.target_property_id > data_object_properties.id`
- `external_lineage_relationships.validated_by > users.id`

## Benefícios

1. **Integração Ampliada**
   - Suporte para 13 sistemas externos (vs. 6 do Unity Catalog padrão)
   - Compatibilidade com ferramentas de BI, ETL, bancos de dados e sistemas customizados

2. **Rastreabilidade Aprimorada**
   - Linhagem completa entre sistemas heterogêneos
   - Mapeamento granular em nível de coluna
   - Validação de compatibilidade de tipos

3. **Governança Unificada**
   - Visão única de metadados em toda a organização
   - Políticas de governança consistentes entre sistemas
   - Auditoria centralizada de alterações

4. **Experiência de Usuário Melhorada**
   - Navegação direta para sistemas externos via URLs
   - Validação de metadados com feedback de status
   - Sincronização automática com sistemas de origem

## Compatibilidade

O modelo atualizado mantém 100% de compatibilidade com a versão anterior (v2.0) e adiciona as novas funcionalidades de forma não disruptiva. Todas as aplicações existentes continuarão funcionando sem modificações.

## Próximos Passos

1. Implementar as novas entidades no esquema do banco de dados
2. Atualizar os modelos SQLAlchemy correspondentes
3. Desenvolver os endpoints REST para as novas entidades
4. Configurar a sincronização automática com Unity Catalog

