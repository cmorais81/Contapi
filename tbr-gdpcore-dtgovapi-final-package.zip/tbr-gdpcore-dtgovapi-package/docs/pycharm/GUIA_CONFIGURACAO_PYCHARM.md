# Guia de Configuração do PyCharm para tbr-gdpcore-dtgovapi

Este guia fornece instruções detalhadas para configurar e executar a API de Governança de Dados (tbr-gdpcore-dtgovapi) no PyCharm em um ambiente Windows.

## Requisitos

- Windows 10/11 (64-bit)
- Python 3.9+ (recomendado: Python 3.11)
- PostgreSQL 13+
- PyCharm (Community ou Professional)
- Git

## 1. Instalação do PyCharm

1. Baixe o PyCharm Community Edition (gratuito) ou Professional Edition do [site oficial da JetBrains](https://www.jetbrains.com/pycharm/download/)
2. Execute o instalador e siga as instruções para completar a instalação
3. Inicie o PyCharm após a instalação

## 2. Clonagem do Repositório

1. Abra o PyCharm
2. Selecione "Get from VCS" na tela inicial ou vá para `File > New > Project from Version Control`
3. Insira a URL do repositório Git
4. Escolha o diretório de destino
5. Clique em "Clone"

## 3. Configuração do Ambiente Virtual

1. Após a clonagem, o PyCharm deve detectar o arquivo `requirements.txt` e sugerir a criação de um ambiente virtual
2. Se isso não acontecer automaticamente, vá para `File > Settings > Project > Python Interpreter`
3. Clique no ícone de engrenagem e selecione "Add..."
4. Escolha "Virtualenv Environment" e selecione "New environment"
5. Certifique-se de que o Python 3.9+ está selecionado como base interpreter
6. Clique em "OK" para criar o ambiente virtual

## 4. Instalação das Dependências

1. Abra o terminal integrado do PyCharm (`View > Tool Windows > Terminal`)
2. Certifique-se de que o ambiente virtual está ativado (você deve ver `(venv)` no início da linha de comando)
3. Execute o comando:
   ```
   pip install -r requirements.txt
   ```

## 5. Configuração do Banco de Dados

### 5.1. Configuração do PostgreSQL

1. Certifique-se de que o PostgreSQL está instalado e em execução
2. Abra o pgAdmin ou outro cliente SQL
3. Crie um novo banco de dados chamado `tbr_gdpcore_dtgovapi`
4. Crie um novo usuário chamado `tbr_gdpcore_user` com senha `sua_senha_segura`
5. Conceda todos os privilégios no banco de dados `tbr_gdpcore_dtgovapi` ao usuário `tbr_gdpcore_user`

### 5.2. Execução do Script de Criação de Tabelas

1. No PyCharm, navegue até o arquivo `database/create_tables.sql`
2. Clique com o botão direito no arquivo e selecione "Run 'create_tables.sql'"
3. Configure a conexão com o banco de dados PostgreSQL:
   - Host: localhost
   - Port: 5432
   - Database: tbr_gdpcore_dtgovapi
   - User: postgres (ou seu usuário administrador)
   - Password: (sua senha do PostgreSQL)
4. Clique em "OK" para executar o script

## 6. Configuração das Variáveis de Ambiente

1. Crie um arquivo `.env` na raiz do projeto com o seguinte conteúdo:
   ```
   DATABASE_URL=postgresql://tbr_gdpcore_user:sua_senha_segura@localhost:5432/tbr_gdpcore_dtgovapi
   SECRET_KEY=temporario_substituir_em_producao
   DEBUG=True
   ENVIRONMENT=development
   ```

2. Ajuste as credenciais conforme necessário

## 7. Configuração da Execução

### 7.1. Configuração do Run/Debug

1. Vá para `Run > Edit Configurations...`
2. Clique no botão "+" e selecione "Python"
3. Configure os seguintes parâmetros:
   - Name: tbr-gdpcore-dtgovapi
   - Script path: Selecione o arquivo `src/main.py`
   - Working directory: Selecione o diretório raiz do projeto
   - Python interpreter: Selecione o ambiente virtual criado anteriormente
4. Na seção "Environment variables", adicione:
   ```
   PYTHONPATH=src
   ```
5. Clique em "OK" para salvar a configuração

### 7.2. Configuração Alternativa com Uvicorn

1. Vá para `Run > Edit Configurations...`
2. Clique no botão "+" e selecione "Python"
3. Configure os seguintes parâmetros:
   - Name: tbr-gdpcore-dtgovapi (Uvicorn)
   - Script path: Selecione o caminho para o executável uvicorn no ambiente virtual (geralmente em `venv/Scripts/uvicorn.exe` no Windows)
   - Parameters: `main:app --reload --host 0.0.0.0 --port 8000`
   - Working directory: Selecione o diretório `src` do projeto
   - Python interpreter: Selecione o ambiente virtual criado anteriormente
4. Clique em "OK" para salvar a configuração

## 8. Execução da Aplicação

1. Selecione a configuração "tbr-gdpcore-dtgovapi" ou "tbr-gdpcore-dtgovapi (Uvicorn)" na barra de ferramentas
2. Clique no botão de execução (ícone de play verde)
3. A aplicação será iniciada e estará disponível em `http://localhost:8000`
4. Acesse a documentação da API em `http://localhost:8000/docs`

## 9. Execução dos Testes

### 9.1. Configuração dos Testes

1. Vá para `Run > Edit Configurations...`
2. Clique no botão "+" e selecione "Python tests > pytest"
3. Configure os seguintes parâmetros:
   - Name: All Tests
   - Target: Script path
   - Script path: Selecione o diretório `tests` do projeto
   - Working directory: Selecione o diretório raiz do projeto
   - Python interpreter: Selecione o ambiente virtual criado anteriormente
4. Na seção "Environment variables", adicione:
   ```
   PYTHONPATH=src
   ```
5. Clique em "OK" para salvar a configuração

### 9.2. Execução dos Testes

1. Selecione a configuração "All Tests" na barra de ferramentas
2. Clique no botão de execução (ícone de play verde)
3. Os resultados dos testes serão exibidos na janela "Run" do PyCharm

## 10. Depuração

1. Defina pontos de interrupção (breakpoints) clicando na margem esquerda do editor, ao lado do número da linha
2. Selecione a configuração de execução desejada
3. Clique no botão de depuração (ícone de inseto) na barra de ferramentas
4. A aplicação será iniciada em modo de depuração
5. Quando a execução atingir um ponto de interrupção, o PyCharm mostrará o estado atual das variáveis e permitirá a execução passo a passo

## 11. Recursos Adicionais do PyCharm

### 11.1. Database Tool Window

O PyCharm Professional oferece uma ferramenta integrada para gerenciamento de banco de dados:

1. Vá para `View > Tool Windows > Database`
2. Clique no botão "+" e selecione "Data Source > PostgreSQL"
3. Configure a conexão com o banco de dados:
   - Host: localhost
   - Port: 5432
   - Database: tbr_gdpcore_dtgovapi
   - User: tbr_gdpcore_user
   - Password: sua_senha_segura
4. Teste a conexão e clique em "OK"
5. Agora você pode explorar o banco de dados, executar consultas e visualizar dados diretamente no PyCharm

### 11.2. HTTP Client

O PyCharm Professional também oferece um cliente HTTP integrado para testar APIs:

1. Crie um novo arquivo com extensão `.http` ou `.rest`
2. Adicione requisições HTTP, por exemplo:
   ```
   ### Listar contratos de dados
   GET http://localhost:8000/api/v1/data-contracts
   Accept: application/json
   
   ### Obter contrato específico
   GET http://localhost:8000/api/v1/data-contracts/123e4567-e89b-12d3-a456-426614174000
   Accept: application/json
   ```
3. Clique no ícone de play ao lado de cada requisição para executá-la

## 12. Solução de Problemas Comuns

### 12.1. Erro de Importação de Módulos

Se você encontrar erros como "ModuleNotFoundError", verifique:

1. Se o PYTHONPATH está configurado corretamente nas configurações de execução
2. Se o ambiente virtual está ativado
3. Se todas as dependências foram instaladas corretamente

Solução: Marque o diretório `src` como "Sources Root" clicando com o botão direito no diretório e selecionando `Mark Directory as > Sources Root`.

### 12.2. Erro de Conexão com o Banco de Dados

Se você encontrar erros de conexão com o banco de dados:

1. Verifique se o PostgreSQL está em execução
2. Verifique as credenciais no arquivo `.env`
3. Verifique se o usuário tem permissões suficientes no banco de dados

### 12.3. Erro de Execução de Scripts

Se você encontrar erros ao executar scripts Python:

1. Verifique se o ambiente virtual está configurado corretamente
2. Verifique se o Python Interpreter está configurado nas configurações do projeto

## 13. Próximos Passos

Após configurar o ambiente com sucesso:

1. Explore a documentação da API em `http://localhost:8000/docs`
2. Revise o modelo de dados em `models/modelo_completo_v2.1.dbml`
3. Consulte `docs/RESUMO_ALTERACOES_MODELO_V2.1.md` para entender as últimas atualizações

