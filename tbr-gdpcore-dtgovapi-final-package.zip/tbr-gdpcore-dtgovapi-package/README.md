# tbr-gdpcore-dtgovapi

API de Governança de Dados para contratos de dados, qualidade de dados e linhagem de dados com suporte ao Unity Catalog External Lineage.

## 📋 Visão Geral

O tbr-gdpcore-dtgovapi é uma API completa para governança de dados que permite gerenciar contratos de dados, monitorar qualidade de dados, rastrear linhagem de dados e integrar com o Unity Catalog External Lineage do Databricks.

### Principais Funcionalidades

- **Contratos de Dados**: Defina, versione e gerencie contratos de dados
- **Qualidade de Dados**: Configure regras de qualidade e monitore resultados
- **Linhagem de Dados**: Rastreie a origem e o fluxo dos dados
- **Unity Catalog External Lineage**: Integração completa com o Unity Catalog do Databricks
- **Segurança**: Controle de acesso baseado em papéis (RBAC) e atributos (ABAC)

## 🚀 Início Rápido

### Pré-requisitos

- Python 3.9+
- PostgreSQL 13+
- Git

### Instalação

#### Windows com PowerShell

1. Clone o repositório:
   ```powershell
   git clone https://github.com/sua-empresa/tbr-gdpcore-dtgovapi.git
   cd tbr-gdpcore-dtgovapi
   ```

2. Execute o script de configuração:
   ```powershell
   .\deployment\windows\Setup-Database.ps1
   ```

3. Inicie a aplicação:
   ```powershell
   .\deployment\windows\Start-Application.ps1
   ```

Para instruções detalhadas, consulte [Guia de Instalação para Windows](docs/windows/GUIA_INSTALACAO_WINDOWS.md).

#### PyCharm

1. Clone o repositório:
   ```
   git clone https://github.com/sua-empresa/tbr-gdpcore-dtgovapi.git
   ```

2. Abra o projeto no PyCharm

3. Execute o script de configuração:
   ```
   .\deployment\pycharm\Setup-PyCharm.ps1  # Windows
   ```
   ou
   ```
   ./deployment/pycharm/setup_pycharm.sh  # Linux/macOS
   ```

Para instruções detalhadas, consulte [Guia de Configuração do PyCharm](docs/pycharm/GUIA_CONFIGURACAO_PYCHARM.md).

## 📊 Modelo de Dados

O modelo de dados completo está disponível em formato DBML em `models/modelo_completo_v2.1.dbml`. Este modelo inclui:

- 36 tabelas principais para governança de dados
- 3 novas tabelas para suporte ao Unity Catalog External Lineage
- Relacionamentos completos entre todas as entidades

Para visualizar o modelo, recomendamos o uso do [dbdiagram.io](https://dbdiagram.io).

## 📚 Documentação

- [Guia de Instalação para Windows](docs/windows/GUIA_INSTALACAO_WINDOWS.md)
- [Guia de Configuração do PyCharm](docs/pycharm/GUIA_CONFIGURACAO_PYCHARM.md)
- [Resumo de Alterações do Modelo v2.1](docs/RESUMO_ALTERACOES_MODELO_V2.1.md)
- [Validação do Modelo v2.1](docs/validacao_modelo_v2.1.md)

## 🧪 Testes

Para executar os testes:

```powershell
# Windows
.\deployment\windows\Run-Tests.ps1

# PyCharm
# Use as configurações de teste predefinidas
```

## 🤝 Contribuição

Para contribuir com o projeto:

1. Faça um fork do repositório
2. Crie uma branch para sua feature (`git checkout -b feature/nova-feature`)
3. Faça commit das suas alterações (`git commit -m 'Adiciona nova feature'`)
4. Faça push para a branch (`git push origin feature/nova-feature`)
5. Abra um Pull Request

## 📄 Licença

Este projeto está licenciado sob a licença MIT - veja o arquivo LICENSE para detalhes.

## 📞 Contato

Para suporte ou dúvidas, entre em contato com a equipe de desenvolvimento em support@sua-empresa.com.

