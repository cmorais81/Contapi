-- Script de criação do banco de dados para tbr-gdpcore-dtgovapi
-- Versão: 2.1.0
-- Data: Julho 2025

-- Extensões necessárias
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Tabelas do Unity Catalog External Lineage
CREATE TABLE IF NOT EXISTS external_metadata (
    external_metadata_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    system_type TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    external_url TEXT,
    description TEXT,
    properties JSONB,
    unity_catalog_metastore_id UUID,
    unity_catalog_external_id TEXT,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    validation_status TEXT DEFAULT 'pending',
    last_validated_at TIMESTAMPTZ,
    validated_by UUID,
    last_synced_at TIMESTAMPTZ,
    sync_status TEXT DEFAULT 'pending',
    sync_error_message TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS external_column_mappings (
    mapping_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    external_metadata_id UUID NOT NULL REFERENCES external_metadata(external_metadata_id),
    source_column_name TEXT NOT NULL,
    source_column_type TEXT,
    source_column_description TEXT,
    target_property_id UUID REFERENCES data_object_properties(id),
    target_column_name TEXT,
    transformation_type TEXT,
    transformation_description TEXT,
    transformation_metadata JSONB,
    compatibility_status TEXT DEFAULT 'pending',
    compatibility_notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS external_lineage_relationships (
    relationship_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    external_metadata_id UUID NOT NULL REFERENCES external_metadata(external_metadata_id),
    target_object_type TEXT NOT NULL,
    target_object_id TEXT NOT NULL,
    target_object_name TEXT,
    relationship_direction TEXT NOT NULL,
    relationship_metadata JSONB,
    relationship_description TEXT,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    validation_status TEXT DEFAULT 'pending',
    validated_by UUID,
    validated_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Tabelas principais
CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    username TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE NOT NULL,
    full_name TEXT,
    role TEXT,
    department TEXT,
    password_hash TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    is_superuser BOOLEAN DEFAULT FALSE,
    last_login TIMESTAMPTZ,
    login_count INTEGER DEFAULT 0,
    failed_login_attempts INTEGER DEFAULT 0,
    locked_until TIMESTAMPTZ,
    password_changed_at TIMESTAMPTZ,
    profile_data JSONB,
    preferences JSONB,
    timezone TEXT DEFAULT 'UTC',
    language TEXT DEFAULT 'pt-BR',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS groups (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT UNIQUE NOT NULL,
    description TEXT,
    group_type TEXT DEFAULT 'role',
    is_active BOOLEAN DEFAULT TRUE,
    parent_group_id UUID REFERENCES groups(id),
    level INTEGER DEFAULT 0,
    member_count INTEGER DEFAULT 0,
    permissions_inherited BOOLEAN DEFAULT TRUE,
    metadata JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS user_groups (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id),
    group_id UUID NOT NULL REFERENCES groups(id),
    role_in_group TEXT,
    joined_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    joined_by UUID REFERENCES users(id),
    is_active BOOLEAN DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS permissions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT UNIQUE NOT NULL,
    description TEXT,
    resource_type TEXT NOT NULL,
    action TEXT NOT NULL,
    scope TEXT DEFAULT 'all',
    condition_expression TEXT,
    is_system_permission BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS group_permission_assignments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    group_id UUID NOT NULL REFERENCES groups(id),
    permission_id UUID NOT NULL REFERENCES permissions(id),
    granted_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    granted_by UUID REFERENCES users(id),
    expires_at TIMESTAMPTZ,
    is_active BOOLEAN DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS data_contracts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    description TEXT,
    version TEXT NOT NULL DEFAULT '1.0.0',
    status TEXT NOT NULL DEFAULT 'draft',
    schema_definition JSONB,
    data_classification TEXT DEFAULT 'internal',
    owner_id UUID REFERENCES users(id),
    steward_id UUID REFERENCES users(id),
    business_domain TEXT,
    tags TEXT[],
    metadata JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by UUID REFERENCES users(id),
    updated_by UUID REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS contract_versions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    contract_id UUID NOT NULL REFERENCES data_contracts(id),
    version_number TEXT NOT NULL,
    schema_definition JSONB NOT NULL,
    changelog TEXT,
    compatibility_mode TEXT DEFAULT 'backward',
    is_active BOOLEAN DEFAULT FALSE,
    activation_date TIMESTAMPTZ,
    deprecation_date TIMESTAMPTZ,
    migration_guide TEXT,
    breaking_changes TEXT[],
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by UUID REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS contract_layouts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    contract_id UUID NOT NULL REFERENCES data_contracts(id),
    country_code TEXT NOT NULL,
    region_code TEXT,
    layout_name TEXT NOT NULL,
    layout_config JSONB NOT NULL,
    field_mappings JSONB,
    validation_rules JSONB,
    formatting_rules JSONB,
    compliance_requirements TEXT[],
    is_active BOOLEAN DEFAULT TRUE,
    priority INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS data_objects (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    description TEXT,
    object_type TEXT NOT NULL,
    data_source TEXT,
    schema_name TEXT,
    table_name TEXT,
    full_path TEXT,
    contract_id UUID REFERENCES data_contracts(id),
    business_domain TEXT,
    data_classification TEXT DEFAULT 'internal',
    contains_pii BOOLEAN DEFAULT FALSE,
    record_count BIGINT,
    data_size_bytes BIGINT,
    last_updated TIMESTAMPTZ,
    update_frequency TEXT,
    retention_period TEXT,
    tags TEXT[],
    metadata JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS data_object_properties (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    data_object_id UUID NOT NULL REFERENCES data_objects(id),
    property_name TEXT NOT NULL,
    property_type TEXT NOT NULL,
    property_description TEXT,
    is_nullable BOOLEAN DEFAULT TRUE,
    is_primary_key BOOLEAN DEFAULT FALSE,
    is_foreign_key BOOLEAN DEFAULT FALSE,
    is_indexed BOOLEAN DEFAULT FALSE,
    is_pii BOOLEAN DEFAULT FALSE,
    data_classification TEXT,
    sample_values TEXT[],
    distinct_count BIGINT,
    null_count BIGINT,
    min_value TEXT,
    max_value TEXT,
    avg_length NUMERIC,
    pattern_analysis JSONB,
    quality_score NUMERIC,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS data_lineage (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    source_object_id UUID NOT NULL REFERENCES data_objects(id),
    target_object_id UUID NOT NULL REFERENCES data_objects(id),
    lineage_type TEXT NOT NULL,
    transformation_logic TEXT,
    transformation_tool TEXT,
    job_name TEXT,
    job_id TEXT,
    execution_frequency TEXT,
    last_execution TIMESTAMPTZ,
    confidence_score NUMERIC DEFAULT 1.0,
    detection_method TEXT,
    business_process TEXT,
    data_flow_direction TEXT DEFAULT 'downstream',
    impact_level TEXT,
    lineage_metadata JSONB,
    tags TEXT[],
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS quality_rules (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    description TEXT,
    rule_type TEXT NOT NULL,
    data_object_id UUID REFERENCES data_objects(id),
    contract_id UUID REFERENCES data_contracts(id),
    rule_definition JSONB NOT NULL,
    rule_parameters JSONB,
    threshold_warning NUMERIC DEFAULT 80,
    threshold_critical NUMERIC DEFAULT 95,
    is_active BOOLEAN DEFAULT TRUE,
    execution_frequency TEXT DEFAULT 'daily',
    execution_schedule TEXT,
    dimension TEXT NOT NULL,
    weight NUMERIC DEFAULT 1.0,
    business_impact TEXT,
    remediation_guide TEXT,
    owner_id UUID REFERENCES users(id),
    tags TEXT[],
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Índices para External Metadata
CREATE INDEX IF NOT EXISTS external_metadata_name_idx ON external_metadata(name);
CREATE INDEX IF NOT EXISTS external_metadata_system_idx ON external_metadata(system_type);
CREATE INDEX IF NOT EXISTS external_metadata_entity_idx ON external_metadata(entity_type);
CREATE INDEX IF NOT EXISTS external_metadata_active_idx ON external_metadata(is_active) WHERE is_active = TRUE;
CREATE INDEX IF NOT EXISTS external_metadata_validation_idx ON external_metadata(validation_status);
CREATE INDEX IF NOT EXISTS external_metadata_sync_idx ON external_metadata(sync_status);

-- Índices para External Column Mappings
CREATE INDEX IF NOT EXISTS external_column_mappings_metadata_idx ON external_column_mappings(external_metadata_id);
CREATE INDEX IF NOT EXISTS external_column_mappings_property_idx ON external_column_mappings(target_property_id);

-- Índices para External Lineage Relationships
CREATE INDEX IF NOT EXISTS external_lineage_relationships_metadata_idx ON external_lineage_relationships(external_metadata_id);
CREATE INDEX IF NOT EXISTS external_lineage_relationships_target_idx ON external_lineage_relationships(target_object_type, target_object_id);
CREATE INDEX IF NOT EXISTS external_lineage_relationships_direction_idx ON external_lineage_relationships(relationship_direction);
CREATE INDEX IF NOT EXISTS external_lineage_relationships_active_idx ON external_lineage_relationships(is_active) WHERE is_active = TRUE;

-- Índices para Data Contracts
CREATE INDEX IF NOT EXISTS data_contracts_name_idx ON data_contracts(name);
CREATE INDEX IF NOT EXISTS data_contracts_status_idx ON data_contracts(status);
CREATE INDEX IF NOT EXISTS data_contracts_owner_idx ON data_contracts(owner_id);
CREATE INDEX IF NOT EXISTS data_contracts_domain_idx ON data_contracts(business_domain);
CREATE INDEX IF NOT EXISTS data_contracts_created_idx ON data_contracts(created_at DESC);

-- Índices para Contract Versions
CREATE INDEX IF NOT EXISTS contract_versions_contract_idx ON contract_versions(contract_id);
CREATE INDEX IF NOT EXISTS contract_versions_active_idx ON contract_versions(contract_id, is_active) WHERE is_active = TRUE;

-- Índices para Data Objects
CREATE INDEX IF NOT EXISTS data_objects_name_idx ON data_objects(name);
CREATE INDEX IF NOT EXISTS data_objects_type_idx ON data_objects(object_type);
CREATE INDEX IF NOT EXISTS data_objects_contract_idx ON data_objects(contract_id);
CREATE INDEX IF NOT EXISTS data_objects_domain_idx ON data_objects(business_domain);
CREATE INDEX IF NOT EXISTS data_objects_pii_idx ON data_objects(contains_pii) WHERE contains_pii = TRUE;
CREATE INDEX IF NOT EXISTS data_objects_updated_idx ON data_objects(last_updated DESC);

-- Índices para Quality Rules
CREATE INDEX IF NOT EXISTS quality_rules_object_idx ON quality_rules(data_object_id);
CREATE INDEX IF NOT EXISTS quality_rules_contract_idx ON quality_rules(contract_id);
CREATE INDEX IF NOT EXISTS quality_rules_type_idx ON quality_rules(rule_type);
CREATE INDEX IF NOT EXISTS quality_rules_active_idx ON quality_rules(is_active) WHERE is_active = TRUE;

-- Índices para Data Lineage
CREATE INDEX IF NOT EXISTS data_lineage_source_idx ON data_lineage(source_object_id);
CREATE INDEX IF NOT EXISTS data_lineage_target_idx ON data_lineage(target_object_id);
CREATE INDEX IF NOT EXISTS data_lineage_type_idx ON data_lineage(lineage_type);
CREATE INDEX IF NOT EXISTS data_lineage_active_idx ON data_lineage(is_active) WHERE is_active = TRUE;

-- Índices para Users & Permissions
CREATE UNIQUE INDEX IF NOT EXISTS users_username_idx ON users(username);
CREATE UNIQUE INDEX IF NOT EXISTS users_email_idx ON users(email);
CREATE INDEX IF NOT EXISTS users_active_idx ON users(is_active) WHERE is_active = TRUE;
CREATE UNIQUE INDEX IF NOT EXISTS groups_name_idx ON groups(name);
CREATE INDEX IF NOT EXISTS user_groups_user_idx ON user_groups(user_id);
CREATE INDEX IF NOT EXISTS user_groups_group_idx ON user_groups(group_id);
CREATE UNIQUE INDEX IF NOT EXISTS permissions_name_idx ON permissions(name);

-- Inserção de dados iniciais
INSERT INTO users (id, username, email, full_name, role, is_active, is_superuser, password_hash)
VALUES (
    gen_random_uuid(),
    'admin',
    'admin@example.com',
    'Administrador',
    'admin',
    TRUE,
    TRUE,
    crypt('admin', gen_salt('bf'))
) ON CONFLICT DO NOTHING;

-- Inserção de permissões básicas
INSERT INTO permissions (name, description, resource_type, action, scope, is_system_permission)
VALUES 
    ('data_contracts:create', 'Criar contratos de dados', 'data_contracts', 'create', 'all', TRUE),
    ('data_contracts:read', 'Ler contratos de dados', 'data_contracts', 'read', 'all', TRUE),
    ('data_contracts:update', 'Atualizar contratos de dados', 'data_contracts', 'update', 'all', TRUE),
    ('data_contracts:delete', 'Excluir contratos de dados', 'data_contracts', 'delete', 'all', TRUE),
    ('external_metadata:create', 'Criar metadados externos', 'external_metadata', 'create', 'all', TRUE),
    ('external_metadata:read', 'Ler metadados externos', 'external_metadata', 'read', 'all', TRUE),
    ('external_metadata:update', 'Atualizar metadados externos', 'external_metadata', 'update', 'all', TRUE),
    ('external_metadata:delete', 'Excluir metadados externos', 'external_metadata', 'delete', 'all', TRUE)
ON CONFLICT DO NOTHING;

