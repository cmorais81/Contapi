# Script de execução de testes para tbr-gdpcore-dtgovapi em ambiente Windows com PowerShell
# Versão: 1.0.0
# Data: Julho 2025

Write-Host "===================================================" -ForegroundColor Cyan
Write-Host "Executando testes para tbr-gdpcore-dtgovapi" -ForegroundColor Cyan
Write-Host "===================================================" -ForegroundColor Cyan

# Verificando se o ambiente virtual existe
if (-not (Test-Path -Path ".\venv")) {
    Write-Host "Criando ambiente virtual..." -ForegroundColor Cyan
    python -m venv venv
    if (-not $?) {
        Write-Host "ERRO: Falha ao criar ambiente virtual." -ForegroundColor Red
        pause
        exit
    }
}

# Ativando o ambiente virtual
Write-Host "Ativando ambiente virtual..." -ForegroundColor Cyan
& .\venv\Scripts\Activate.ps1
if (-not $?) {
    Write-Host "ERRO: Falha ao ativar ambiente virtual." -ForegroundColor Red
    Write-Host "Se você estiver recebendo um erro de execução de scripts, execute o seguinte comando como administrador:" -ForegroundColor Yellow
    Write-Host "Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser" -ForegroundColor Yellow
    pause
    exit
}

# Instalando dependências de teste
Write-Host "Instalando dependências de teste..." -ForegroundColor Cyan
pip install pytest pytest-asyncio pytest-cov
if (-not $?) {
    Write-Host "AVISO: Algumas dependências podem não ter sido instaladas corretamente." -ForegroundColor Yellow
}

# Menu de opções de teste
Write-Host ""
Write-Host "Selecione o tipo de teste a ser executado:" -ForegroundColor Cyan
Write-Host "1. Testes unitários" -ForegroundColor White
Write-Host "2. Testes de integração" -ForegroundColor White
Write-Host "3. Todos os testes" -ForegroundColor White
Write-Host "4. Testes com cobertura" -ForegroundColor White
Write-Host "0. Sair" -ForegroundColor White
Write-Host ""

$option = Read-Host "Digite a opção desejada"

switch ($option) {
    "1" {
        Write-Host "Executando testes unitários..." -ForegroundColor Cyan
        pytest tests/unit/ -v
    }
    "2" {
        Write-Host "Executando testes de integração..." -ForegroundColor Cyan
        pytest tests/integration/ -v
    }
    "3" {
        Write-Host "Executando todos os testes..." -ForegroundColor Cyan
        pytest tests/ -v
    }
    "4" {
        Write-Host "Executando testes com cobertura..." -ForegroundColor Cyan
        pytest tests/ --cov=app -v
    }
    "0" {
        Write-Host "Saindo..." -ForegroundColor Cyan
    }
    default {
        Write-Host "Opção inválida." -ForegroundColor Red
    }
}

# Desativando o ambiente virtual
deactivate

Write-Host ""
Write-Host "===================================================" -ForegroundColor Cyan
Write-Host "Execução de testes concluída" -ForegroundColor Cyan
Write-Host "===================================================" -ForegroundColor Cyan
pause

