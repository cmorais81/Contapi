# Script de configuração do banco de dados para tbr-gdpcore-dtgovapi em ambiente Windows com PowerShell
# Versão: 1.0.0
# Data: Julho 2025

Write-Host "===================================================" -ForegroundColor Cyan
Write-Host "Configurando banco de dados para tbr-gdpcore-dtgovapi" -ForegroundColor Cyan
Write-Host "===================================================" -ForegroundColor Cyan

# Configurações do banco de dados
$DB_NAME = "tbr_gdpcore_dtgovapi"
$DB_USER = "tbr_gdpcore_user"
$DB_PASSWORD = "sua_senha_segura"
$DB_HOST = "localhost"
$DB_PORT = "5432"

Write-Host "Configurações do banco de dados:" -ForegroundColor Cyan
Write-Host "- Nome do banco: $DB_NAME" -ForegroundColor White
Write-Host "- Usuário: $DB_USER" -ForegroundColor White
Write-Host "- Host: $DB_HOST`:$DB_PORT" -ForegroundColor White
Write-Host ""

# Verificando se o PostgreSQL está instalado
try {
    $pgVersion = psql --version
    Write-Host "PostgreSQL detectado: $pgVersion" -ForegroundColor Green
} catch {
    Write-Host "ERRO: PostgreSQL não encontrado. Certifique-se de que o PostgreSQL está instalado e no PATH." -ForegroundColor Red
    Write-Host "Você pode baixar o PostgreSQL em: https://www.postgresql.org/download/windows/" -ForegroundColor Yellow
    pause
    exit
}

# Solicitando senha do usuário postgres
$pgPassword = Read-Host "Digite a senha do usuário postgres" -AsSecureString
$PGPASSWORD = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($pgPassword))

# Definindo variável de ambiente PGPASSWORD para autenticação
$env:PGPASSWORD = $PGPASSWORD

# Verificando se o banco de dados já existe
$dbExists = $false
try {
    $result = psql -h $DB_HOST -p $DB_PORT -U postgres -t -c "SELECT 1 FROM pg_database WHERE datname='$DB_NAME'"
    if ($result -match "1") {
        $dbExists = $true
        Write-Host "Banco de dados '$DB_NAME' já existe." -ForegroundColor Yellow
        $dropDb = Read-Host "Deseja recriar o banco de dados? Todos os dados serão perdidos! (S/N)"
        if ($dropDb -eq "S" -or $dropDb -eq "s") {
            psql -h $DB_HOST -p $DB_PORT -U postgres -c "DROP DATABASE $DB_NAME"
            $dbExists = $false
            Write-Host "Banco de dados '$DB_NAME' removido." -ForegroundColor Yellow
        }
    }
} catch {
    Write-Host "Erro ao verificar banco de dados: $_" -ForegroundColor Red
}

# Criando banco de dados e usuário se necessário
if (-not $dbExists) {
    Write-Host "Criando banco de dados e usuário..." -ForegroundColor Cyan
    
    # Criando banco de dados
    psql -h $DB_HOST -p $DB_PORT -U postgres -c "CREATE DATABASE $DB_NAME"
    if (-not $?) {
        Write-Host "ERRO: Falha ao criar banco de dados." -ForegroundColor Red
        $env:PGPASSWORD = ""
        pause
        exit
    }
    
    # Verificando se o usuário já existe
    $userExists = $false
    $result = psql -h $DB_HOST -p $DB_PORT -U postgres -t -c "SELECT 1 FROM pg_roles WHERE rolname='$DB_USER'"
    if ($result -match "1") {
        $userExists = $true
        Write-Host "Usuário '$DB_USER' já existe." -ForegroundColor Yellow
    }
    
    # Criando usuário se não existir
    if (-not $userExists) {
        psql -h $DB_HOST -p $DB_PORT -U postgres -c "CREATE USER $DB_USER WITH PASSWORD '$DB_PASSWORD'"
        if (-not $?) {
            Write-Host "ERRO: Falha ao criar usuário." -ForegroundColor Red
            $env:PGPASSWORD = ""
            pause
            exit
        }
    }
    
    # Concedendo privilégios
    psql -h $DB_HOST -p $DB_PORT -U postgres -c "GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_USER"
    if (-not $?) {
        Write-Host "ERRO: Falha ao conceder privilégios." -ForegroundColor Red
        $env:PGPASSWORD = ""
        pause
        exit
    }
}

# Executando script de criação de tabelas
Write-Host "Executando script de criação de tabelas..." -ForegroundColor Cyan
$scriptPath = Join-Path -Path (Get-Location) -ChildPath "..\database\create_tables.sql"
psql -h $DB_HOST -p $DB_PORT -U postgres -d $DB_NAME -f $scriptPath
if (-not $?) {
    Write-Host "AVISO: Podem ter ocorrido erros durante a execução do script de criação de tabelas." -ForegroundColor Yellow
}

# Limpando variável de ambiente PGPASSWORD
$env:PGPASSWORD = ""

# Atualizando arquivo .env com as configurações do banco de dados
$envPath = Join-Path -Path (Get-Location) -ChildPath "..\.env"
if (Test-Path -Path $envPath) {
    $envContent = Get-Content -Path $envPath -Raw
    $envContent = $envContent -replace "DATABASE_URL=.*", "DATABASE_URL=postgresql://$DB_USER`:$DB_PASSWORD@$DB_HOST`:$DB_PORT/$DB_NAME"
    $envContent | Out-File -FilePath $envPath -Encoding utf8
    Write-Host "Arquivo .env atualizado com as configurações do banco de dados." -ForegroundColor Green
}

Write-Host ""
Write-Host "===================================================" -ForegroundColor Cyan
Write-Host "Banco de dados configurado com sucesso!" -ForegroundColor Green
Write-Host "===================================================" -ForegroundColor Cyan
pause

