# Script de inicialização para tbr-gdpcore-dtgovapi em ambiente Windows com PowerShell
# Versão: 1.0.0
# Data: Julho 2025

Write-Host "===================================================" -ForegroundColor Cyan
Write-Host "Inicializando tbr-gdpcore-dtgovapi em ambiente local" -ForegroundColor Cyan
Write-Host "===================================================" -ForegroundColor Cyan

# Verificando se o PowerShell está em modo de administrador
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host "AVISO: Algumas operações podem requerer privilégios de administrador." -ForegroundColor Yellow
    Write-Host "Considere reiniciar este script como administrador se encontrar erros de permissão." -ForegroundColor Yellow
    Write-Host ""
}

# Verificando se o Python está instalado
try {
    $pythonVersion = python --version
    Write-Host "Python detectado: $pythonVersion" -ForegroundColor Green
} catch {
    Write-Host "ERRO: Python não encontrado. Por favor, instale o Python 3.9+ e adicione-o ao PATH." -ForegroundColor Red
    Write-Host "Você pode baixar o Python em: https://www.python.org/downloads/windows/" -ForegroundColor Yellow
    Write-Host "Certifique-se de marcar a opção 'Add Python to PATH' durante a instalação." -ForegroundColor Yellow
    pause
    exit
}

# Verificando se o ambiente virtual existe
if (-not (Test-Path -Path ".\venv")) {
    Write-Host "Criando ambiente virtual..." -ForegroundColor Cyan
    python -m venv venv
    if (-not $?) {
        Write-Host "ERRO: Falha ao criar ambiente virtual." -ForegroundColor Red
        pause
        exit
    }
}

# Ativando o ambiente virtual
Write-Host "Ativando ambiente virtual..." -ForegroundColor Cyan
& .\venv\Scripts\Activate.ps1
if (-not $?) {
    Write-Host "ERRO: Falha ao ativar ambiente virtual." -ForegroundColor Red
    Write-Host "Se você estiver recebendo um erro de execução de scripts, execute o seguinte comando como administrador:" -ForegroundColor Yellow
    Write-Host "Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser" -ForegroundColor Yellow
    pause
    exit
}

# Instalando dependências
Write-Host "Verificando dependências..." -ForegroundColor Cyan
pip install -r requirements.txt
if (-not $?) {
    Write-Host "AVISO: Algumas dependências podem não ter sido instaladas corretamente." -ForegroundColor Yellow
}

# Verificando variáveis de ambiente
if (-not (Test-Path -Path ".\.env")) {
    Write-Host "Criando arquivo .env padrão..." -ForegroundColor Cyan
    @"
DATABASE_URL=postgresql://tbr_gdpcore_user:sua_senha_segura@localhost:5432/tbr_gdpcore_dtgovapi
SECRET_KEY=temporario_substituir_em_producao
DEBUG=True
ENVIRONMENT=development
"@ | Out-File -FilePath ".\.env" -Encoding utf8
    
    Write-Host ""
    Write-Host "ATENÇÃO: Edite o arquivo .env com suas configurações corretas!" -ForegroundColor Yellow
    Write-Host ""
    pause
}

# Verificando se o PostgreSQL está instalado
try {
    $pgVersion = psql --version
    Write-Host "PostgreSQL detectado: $pgVersion" -ForegroundColor Green
} catch {
    Write-Host "AVISO: PostgreSQL não detectado no PATH." -ForegroundColor Yellow
    Write-Host "Certifique-se de que o PostgreSQL está instalado e configurado corretamente." -ForegroundColor Yellow
    Write-Host "Você pode baixar o PostgreSQL em: https://www.postgresql.org/download/windows/" -ForegroundColor Yellow
    Write-Host ""
    $setupDb = Read-Host "Deseja executar o script de configuração do banco de dados? (S/N)"
    if ($setupDb -eq "S" -or $setupDb -eq "s") {
        & .\deployment\windows\Setup-Database.ps1
    }
}

# Iniciando a aplicação
Write-Host ""
Write-Host "Iniciando a aplicação..." -ForegroundColor Cyan
Write-Host "Pressione Ctrl+C para encerrar a aplicação." -ForegroundColor Yellow
Write-Host ""

Set-Location -Path ".\src"
python -m uvicorn main:app --reload --host 0.0.0.0 --port 8000

# Retornando ao diretório original e desativando o ambiente virtual
Set-Location -Path ".."
deactivate

Write-Host ""
Write-Host "===================================================" -ForegroundColor Cyan
Write-Host "Aplicação encerrada" -ForegroundColor Cyan
Write-Host "===================================================" -ForegroundColor Cyan
pause

