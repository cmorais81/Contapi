# Script de inicialização para tbr-gdpcore-dtgovapi no PyCharm (Windows)
# Versão: 1.0.0
# Data: Julho 2025

Write-Host "===================================================" -ForegroundColor Cyan
Write-Host "Configurando ambiente para tbr-gdpcore-dtgovapi no PyCharm" -ForegroundColor Cyan
Write-Host "===================================================" -ForegroundColor Cyan

# Verificando se o Python está instalado
try {
    $pythonVersion = python --version
    Write-Host "Python detectado: $pythonVersion" -ForegroundColor Green
} catch {
    Write-Host "ERRO: Python não encontrado. Por favor, instale o Python 3.9+ e adicione-o ao PATH." -ForegroundColor Red
    Write-Host "Você pode baixar o Python em: https://www.python.org/downloads/windows/" -ForegroundColor Yellow
    Write-Host "Certifique-se de marcar a opção 'Add Python to PATH' durante a instalação." -ForegroundColor Yellow
    pause
    exit
}

# Verificando se o ambiente virtual existe
if (-not (Test-Path -Path ".\venv")) {
    Write-Host "Criando ambiente virtual..." -ForegroundColor Cyan
    python -m venv venv
    if (-not $?) {
        Write-Host "ERRO: Falha ao criar ambiente virtual." -ForegroundColor Red
        pause
        exit
    }
}

# Ativando o ambiente virtual
Write-Host "Ativando ambiente virtual..." -ForegroundColor Cyan
& .\venv\Scripts\Activate.ps1
if (-not $?) {
    Write-Host "ERRO: Falha ao ativar ambiente virtual." -ForegroundColor Red
    Write-Host "Se você estiver recebendo um erro de execução de scripts, execute o seguinte comando como administrador:" -ForegroundColor Yellow
    Write-Host "Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser" -ForegroundColor Yellow
    pause
    exit
}

# Instalando dependências
Write-Host "Instalando dependências..." -ForegroundColor Cyan
pip install -r requirements.txt
if (-not $?) {
    Write-Host "AVISO: Algumas dependências podem não ter sido instaladas corretamente." -ForegroundColor Yellow
}

# Verificando variáveis de ambiente
if (-not (Test-Path -Path ".\.env")) {
    Write-Host "Criando arquivo .env padrão..." -ForegroundColor Cyan
    @"
DATABASE_URL=postgresql://tbr_gdpcore_user:sua_senha_segura@localhost:5432/tbr_gdpcore_dtgovapi
SECRET_KEY=temporario_substituir_em_producao
DEBUG=True
ENVIRONMENT=development
"@ | Out-File -FilePath ".\.env" -Encoding utf8
    
    Write-Host ""
    Write-Host "ATENÇÃO: Edite o arquivo .env com suas configurações corretas!" -ForegroundColor Yellow
    Write-Host ""
    pause
}

# Copiando configuração do PyCharm
Write-Host "Copiando configuração do PyCharm..." -ForegroundColor Cyan
if (-not (Test-Path -Path ".\.idea\runConfigurations")) {
    New-Item -Path ".\.idea\runConfigurations" -ItemType Directory -Force | Out-Null
}
Copy-Item -Path ".\deployment\pycharm\pycharm_config.json" -Destination ".\.idea\runConfigurations\" -Force

Write-Host ""
Write-Host "===================================================" -ForegroundColor Cyan
Write-Host "Ambiente configurado com sucesso!" -ForegroundColor Green
Write-Host "Agora você pode abrir o projeto no PyCharm." -ForegroundColor Green
Write-Host "===================================================" -ForegroundColor Cyan

# Desativando o ambiente virtual
deactivate

pause

