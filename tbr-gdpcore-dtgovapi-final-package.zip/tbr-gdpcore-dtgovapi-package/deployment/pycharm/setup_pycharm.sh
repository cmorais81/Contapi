#!/bin/bash
# Script de inicialização para tbr-gdpcore-dtgovapi no PyCharm
# Versão: 1.0.0
# Data: Julho 2025

echo "==================================================="
echo "Configurando ambiente para tbr-gdpcore-dtgovapi no PyCharm"
echo "==================================================="

# Verificando se o Python está instalado
if ! command -v python &> /dev/null; then
    echo "ERRO: Python não encontrado. Por favor, instale o Python 3.9+ e adicione-o ao PATH."
    echo "Você pode baixar o Python em: https://www.python.org/downloads/"
    exit 1
fi

# Verificando se o ambiente virtual existe
if [ ! -d "venv" ]; then
    echo "Criando ambiente virtual..."
    python -m venv venv
    if [ $? -ne 0 ]; then
        echo "ERRO: Falha ao criar ambiente virtual."
        exit 1
    fi
fi

# Ativando o ambiente virtual
echo "Ativando ambiente virtual..."
source venv/bin/activate
if [ $? -ne 0 ]; then
    echo "ERRO: Falha ao ativar ambiente virtual."
    exit 1
fi

# Instalando dependências
echo "Instalando dependências..."
pip install -r requirements.txt
if [ $? -ne 0 ]; then
    echo "AVISO: Algumas dependências podem não ter sido instaladas corretamente."
fi

# Verificando variáveis de ambiente
if [ ! -f ".env" ]; then
    echo "Criando arquivo .env padrão..."
    cat > .env << EOL
DATABASE_URL=postgresql://tbr_gdpcore_user:sua_senha_segura@localhost:5432/tbr_gdpcore_dtgovapi
SECRET_KEY=temporario_substituir_em_producao
DEBUG=True
ENVIRONMENT=development
EOL
    
    echo ""
    echo "ATENÇÃO: Edite o arquivo .env com suas configurações corretas!"
    echo ""
    read -p "Pressione Enter para continuar..."
fi

# Copiando configuração do PyCharm
echo "Copiando configuração do PyCharm..."
mkdir -p .idea/runConfigurations
cp deployment/pycharm/pycharm_config.json .idea/runConfigurations/

echo ""
echo "==================================================="
echo "Ambiente configurado com sucesso!"
echo "Agora você pode abrir o projeto no PyCharm."
echo "==================================================="

# Desativando o ambiente virtual
deactivate

