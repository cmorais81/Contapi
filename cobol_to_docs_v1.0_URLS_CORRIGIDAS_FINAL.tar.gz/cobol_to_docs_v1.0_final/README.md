# COBOL to Docs v1.0

Sistema avançado de análise e documentação automatizada de programas COBOL com inteligência artificial.

## Visão Geral

O COBOL to Docs é uma ferramenta profissional que utiliza inteligência artificial para analisar código COBOL legado e gerar documentação técnica abrangente. O sistema incorpora tecnologia RAG (Retrieval Augmented Generation) com base de conhecimento especializada em padrões COBOL, sistemas bancários e engenharia reversa.

## Principais Funcionalidades

### Análise Inteligente de Código
- Análise automatizada de programas COBOL com IA
- Suporte a múltiplos providers de IA (LuzIA, OpenAI, Enhanced Mock)
- Sistema RAG com 22 itens de conhecimento especializado
- Detecção automática de padrões e estruturas COBOL

### Processamento Abrangente
- Análise de copybooks e dependências
- Processamento em lote de múltiplos programas
- Análise consolidada de sistemas completos
- Extração de regras de negócio implícitas

### Documentação Profissional
- Geração de documentação funcional detalhada
- Relatórios HTML e PDF
- Análise de impacto e dependências
- Documentação de interfaces e fluxos de dados

### Transparência e Auditoria
- Logging completo de todas as operações
- Relatórios de sessão RAG detalhados
- Métricas de performance e custos
- Rastreabilidade total do processo

## Instalação

### Instalação Automática (Recomendada)
```bash
# Extrair o pacote
tar -xzf cobol_to_docs_v1.0.tar.gz
cd cobol_to_docs_v1.0_final/

# Executar instalador automático
python3 install.py
```

### Instalação Manual
```bash
# Instalar dependências essenciais
pip install -r requirements-lite.txt

# Ou instalar dependências completas
pip install -r requirements.txt

# Configurar credenciais
cp .env.example .env
# Editar .env com suas credenciais
```

### Instalação via pip
```bash
# Instalação local
pip install ./cobol_to_docs_v1.0_final/

# Instalação em modo desenvolvimento
pip install -e ./cobol_to_docs_v1.0_final/
```

## Configuração

### Arquivo de Configuração
O sistema utiliza `config/config.yaml` para configurações principais:
- Providers de IA disponíveis
- Configurações do sistema RAG
- Parâmetros de análise
- Configurações de logging

### Variáveis de Ambiente
Configure suas credenciais no arquivo `.env`:
```bash
# LuzIA Configuration
LUZIA_CLIENT_ID=your_client_id_here
LUZIA_CLIENT_SECRET=your_client_secret_here

# OpenAI Configuration (opcional)
OPENAI_API_KEY=your_openai_api_key_here
```

## Uso

### Análise Básica
```bash
# Analisar programas COBOL
python3 main.py --fontes examples/fontes.txt --books examples/books.txt

# Usar provider específico
python3 main.py --fontes examples/fontes.txt --models luzia

# Análise consolidada do sistema
python3 main.py --fontes examples/fontes.txt --consolidado
```

### Comandos Disponíveis (após instalação pip)
```bash
cobol-to-docs --fontes examples/fontes.txt
cobol-docs --fontes examples/fontes.txt
cobol-analyze --fontes examples/fontes.txt
```

### Verificar Status
```bash
python3 main.py --status
```

## Sistema RAG

### Base de Conhecimento
O sistema inclui 22 itens especializados de conhecimento:
- Estruturas e padrões COBOL
- Manipulação de arquivos e dados
- Regras bancárias e financeiras
- Técnicas de engenharia reversa
- Estratégias de modernização
- Integração com tecnologias modernas

### Funcionalidades RAG
- Enriquecimento automático de prompts
- Recuperação de conhecimento contextual
- Aprendizado contínuo do sistema
- Otimização de tokens e custos

## Arquitetura

### Componentes Principais
- **Core**: Gerenciamento de configuração e prompts
- **Providers**: Integração com diferentes IAs
- **Analyzers**: Análise de código COBOL
- **RAG System**: Sistema de recuperação de conhecimento
- **Generators**: Geração de documentação

### Fluxo de Processamento
1. Carregamento de programas COBOL e copybooks
2. Enriquecimento de contexto via RAG
3. Análise com IA selecionada
4. Geração de documentação estruturada
5. Relatórios de auditoria e métricas

## Requisitos

### Sistema
- Python 3.8 ou superior
- Sistema operacional: Linux, Windows, macOS
- Memória: 4GB RAM (8GB recomendado)
- Espaço em disco: 500MB

### Dependências
- requests, pyyaml, jinja2 (essenciais)
- scikit-learn, numpy (RAG básico)
- sentence-transformers (RAG completo)
- openai (provider OpenAI)
- weasyprint (geração PDF)

## Estrutura do Projeto

```
cobol_to_docs_v1.0_final/
├── main.py                 # Script principal
├── install.py              # Instalador automático
├── setup.py                # Configuração pip
├── requirements.txt        # Dependências completas
├── requirements-lite.txt   # Dependências essenciais
├── config/
│   └── config.yaml        # Configuração principal
├── data/
│   └── cobol_knowledge_base.json  # Base RAG
├── src/                   # Código fonte
├── examples/              # Exemplos de uso
└── docs/                  # Documentação
```

## Exemplos

### Arquivo de Fontes (fontes.txt)
```
PROGRAMA: LHAN0542
IDENTIFICACAO: Sistema de Validação de Contas
CODIGO:
       IDENTIFICATION DIVISION.
       PROGRAM-ID. LHAN0542.
       ...
```

### Arquivo de Copybooks (books.txt)
```
COPYBOOK: CONTA-LAYOUT
CODIGO:
       01  WS-CONTA-REGISTRO.
           05  WS-CONTA-NUMERO    PIC 9(10).
           05  WS-CONTA-DIGITO    PIC 9(01).
           ...
```

## Suporte e Documentação

### Documentação Adicional
- `docs/GUIA_COMPLETO_USO.md`: Guia detalhado de uso
- `docs/DOCUMENTACAO_TECNICA.md`: Documentação técnica
- `INSTALL.md`: Guia de instalação
- `CHANGELOG.md`: Histórico de versões

### Logs e Auditoria
- `logs/`: Logs de execução
- Relatórios RAG automáticos
- Métricas de performance
- Arquivos de auditoria JSON

## Licença

Este projeto está licenciado sob a Licença MIT - veja o arquivo LICENSE para detalhes.

## Autor

**Carlos Morais**  
Especialista em Sistemas Legados e Modernização COBOL

---

**COBOL to Docs v1.0** - Transformando análise de código COBOL com inteligência artificial
