from setuptools import setup, find_packages\n\nsetup(name='cobol_to_docs', version='1.0', packages=find_packages())
