import os
import shutil
from pathlib import Path
from typing import List, Tuple, Optional

from .file_utils import resolve_file_path

class InputProcessor:
    def __init__(self, input_path: str, temp_dir: str = "temp_cobol_members"):
        self.input_path = Path(input_path)
        self.temp_dir = Path(temp_dir)
        self.extracted_files: List[Path] = []

    def is_vmember_file(self, file_path: Path) -> bool:
        """Verifica se o arquivo é um V-MEMBER (V-MEMBER.COB ou V-MEMBER.CPY)"""
        return file_path.name.upper() in ["V-MEMBER.COB", "V-MEMBER.CPY"]

    def extract_vmember_files(self) -> List[Path]:
        """
        Extrai arquivos V-MEMBER do diretório de entrada para um diretório temporário.
        Retorna a lista de caminhos dos arquivos extraídos.
        """
        if self.temp_dir.exists():
            shutil.rmtree(self.temp_dir)
        self.temp_dir.mkdir(exist_ok=True)

        for root, _, files in os.walk(self.input_path):
            root_path = Path(root)
            for file_name in files:
                file_path = root_path / file_name
                if self.is_vmember_file(file_path):
                    # O nome do arquivo extraído será o nome do diretório pai
                    parent_dir_name = file_path.parent.name
                    new_file_name = f"{parent_dir_name}_{file_name}"
                    new_file_path = self.temp_dir / new_file_name
                    shutil.copy2(file_path, new_file_path)
                    self.extracted_files.append(new_file_path)

        return self.extracted_files

    def get_copybook_paths(self, copybook_name: str) -> Optional[Path]:
        """
        Resolve o caminho completo para um copybook.
        Prioriza o diretório temporário de V-MEMBERs e depois o diretório de entrada.
        """
        # 1. Tenta encontrar no diretório temporário de V-MEMBERs
        for extracted_file in self.extracted_files:
            if copybook_name.upper() in extracted_file.name.upper():
                return extracted_file

        # 2. Tenta encontrar no diretório de entrada (e subdiretórios)
        resolved_path = resolve_file_path(self.input_path, copybook_name)
        
        if resolved_path:
            return resolved_path
            
        return None

    def cleanup(self):
        """Remove o diretório temporário."""
        if self.temp_dir.exists():
            shutil.rmtree(self.temp_dir)

    def process_inputs(self) -> Tuple[List[Path], Path]:
        """
        Orquestra a extração de V-MEMBERs e retorna o caminho de entrada.
        """
        # 1. Extrai V-MEMBERs
        self.extract_vmember_files()

        # 2. Retorna a lista de arquivos extraídos (para processamento) e o caminho de entrada
        return self.extracted_files, self.input_path

