#!/usr/bin/env python3
"""
Enhanced Config Manager v3.1.0 - Gerenciador de configuração aprimorado
Suporte completo para diretórios personalizados e inicialização automática
"""

import os
import yaml
import logging
from pathlib import Path
from typing import Dict, Any, Optional, Union
from dataclasses import dataclass, field

@dataclass
class DirectoryConfig:
    """Configuração de diretórios personalizáveis"""
    config_dir: str = "config"
    data_dir: str = "data"
    logs_dir: str = "logs"
    output_dir: str = "output"
    examples_dir: str = "examples"
    temp_dir: str = "temp"
    cache_dir: str = "data/cache"
    
    def to_dict(self) -> Dict[str, str]:
        """Converte para dicionário"""
        return {
            'config_dir': self.config_dir,
            'data_dir': self.data_dir,
            'logs_dir': self.logs_dir,
            'output_dir': self.output_dir,
            'examples_dir': self.examples_dir,
            'temp_dir': self.temp_dir,
            'cache_dir': self.cache_dir
        }
    
    def create_directories(self) -> None:
        """Cria todos os diretórios se não existirem"""
        for dir_path in self.to_dict().values():
            Path(dir_path).mkdir(parents=True, exist_ok=True)

class EnhancedConfigManager:
    """
    Gerenciador de configuração aprimorado com suporte a:
    - Diretórios personalizados via parâmetros
    - Inicialização automática
    - Múltiplos arquivos de configuração
    - Validação de configuração
    - Fallback para configurações padrão
    """
    
    def __init__(self, 
                 config_dir: Optional[str] = None,
                 data_dir: Optional[str] = None,
                 logs_dir: Optional[str] = None,
                 config_file: str = "config.yaml"):
        """
        Inicializa o gerenciador de configuração
        
        Args:
            config_dir: Diretório personalizado para configurações
            data_dir: Diretório personalizado para dados
            logs_dir: Diretório personalizado para logs
            config_file: Nome do arquivo de configuração principal
        """
        self.logger = logging.getLogger(__name__)
        
        # Configurar diretórios
        self.directories = DirectoryConfig(
            config_dir=config_dir or "config",
            data_dir=data_dir or "data", 
            logs_dir=logs_dir or "logs"
        )
        
        # Criar diretórios se necessário
        self.directories.create_directories()
        
        # Carregar configuração
        self.config_file = config_file
        self.config = self._load_configuration()
        
        # Atualizar configuração com diretórios personalizados
        self._update_config_with_directories()
        
        self.logger.info(f"Configuração carregada de: {self.get_config_path()}")
        self.logger.info(f"Diretórios configurados: {self.directories.to_dict()}")
    
    def get_config_path(self) -> str:
        """Retorna o caminho completo do arquivo de configuração"""
        return os.path.join(self.directories.config_dir, self.config_file)
    
    def _load_configuration(self) -> Dict[str, Any]:
        """Carrega a configuração de múltiplas fontes com fallback"""
        config = {}
        
        # 1. Tentar carregar configuração enhanced
        enhanced_config_path = os.path.join(self.directories.config_dir, "config_enhanced.yaml")
        if os.path.exists(enhanced_config_path):
            try:
                with open(enhanced_config_path, 'r', encoding='utf-8') as f:
                    config = yaml.safe_load(f) or {}
                self.logger.info(f"Configuração enhanced carregada: {enhanced_config_path}")
                return config
            except Exception as e:
                self.logger.warning(f"Erro ao carregar config enhanced: {e}")
        
        # 2. Tentar carregar configuração principal
        main_config_path = self.get_config_path()
        if os.path.exists(main_config_path):
            try:
                with open(main_config_path, 'r', encoding='utf-8') as f:
                    config = yaml.safe_load(f) or {}
                self.logger.info(f"Configuração principal carregada: {main_config_path}")
                return config
            except Exception as e:
                self.logger.warning(f"Erro ao carregar configuração principal: {e}")
        
        # 3. Tentar carregar de locais alternativos
        alternative_paths = [
            "config.yaml",
            "config/config.yaml", 
            "../config/config.yaml",
            os.path.join(os.path.dirname(__file__), "../../config/config.yaml")
        ]
        
        for alt_path in alternative_paths:
            if os.path.exists(alt_path):
                try:
                    with open(alt_path, 'r', encoding='utf-8') as f:
                        config = yaml.safe_load(f) or {}
                    self.logger.info(f"Configuração alternativa carregada: {alt_path}")
                    return config
                except Exception as e:
                    self.logger.warning(f"Erro ao carregar configuração alternativa {alt_path}: {e}")
        
        # 4. Usar configuração padrão
        self.logger.warning("Usando configuração padrão - nenhum arquivo encontrado")
        return self._get_default_config()
    
    def _get_default_config(self) -> Dict[str, Any]:
        """Retorna configuração padrão quando nenhum arquivo é encontrado"""
        return {
            'directories': self.directories.to_dict(),
            'models': {
                'default': 'enhanced_mock',
                'enhanced_mock': {
                    'provider': 'enhanced_mock',
                    'model': 'enhanced-mock-gpt-4',
                    'enabled': True,
                    'cost_per_token': 0.0,
                    'max_tokens': 8192
                }
            },
            'output': {
                'default_format': 'markdown',
                'generate_html': True,
                'generate_pdf': False,
                'generate_json': True
            },
            'rag': {
                'enabled': True,
                'knowledge_base_file': os.path.join(self.directories.data_dir, 'cobol_knowledge_base.json'),
                'max_items': 10,
                'similarity_threshold': 0.7
            },
            'logging': {
                'level': 'INFO',
                'file': os.path.join(self.directories.logs_dir, 'cobol_analyzer.log')
            },
            'analysis': {
                'default_options': {
                    'procedure_detalhada': False,
                    'modernizacao': False,
                    'deep_analysis': False,
                    'extract_formulas': False,
                    'no_comments': False
                }
            },
            'auto_initialization': {
                'enabled': True,
                'create_examples': True,
                'copy_default_configs': True,
                'setup_rag_data': True
            }
        }
    
    def _update_config_with_directories(self) -> None:
        """Atualiza a configuração com os diretórios personalizados"""
        # Atualizar seção de diretórios
        if 'directories' not in self.config:
            self.config['directories'] = {}
        
        self.config['directories'].update(self.directories.to_dict())
        
        # Atualizar caminhos dependentes de diretórios
        if 'rag' in self.config:
            if 'knowledge_base_file' in self.config['rag']:
                # Atualizar caminho da base de conhecimento se for relativo
                kb_file = self.config['rag']['knowledge_base_file']
                if not os.path.isabs(kb_file):
                    self.config['rag']['knowledge_base_file'] = os.path.join(
                        self.directories.data_dir, 
                        os.path.basename(kb_file)
                    )
            
            if 'embeddings_dir' in self.config['rag']:
                self.config['rag']['embeddings_dir'] = os.path.join(
                    self.directories.data_dir, 'embeddings'
                )
            
            if 'sessions_dir' in self.config['rag']:
                self.config['rag']['sessions_dir'] = os.path.join(
                    self.directories.data_dir, 'rag_sessions'
                )
        
        # Atualizar caminhos de logging
        if 'logging' in self.config:
            if 'file' in self.config['logging']:
                log_file = self.config['logging']['file']
                if not os.path.isabs(log_file):
                    self.config['logging']['file'] = os.path.join(
                        self.directories.logs_dir,
                        os.path.basename(log_file)
                    )
        
        # Atualizar cache directory
        if 'cache' in self.config:
            if 'cache_dir' in self.config['cache']:
                self.config['cache']['cache_dir'] = os.path.join(
                    self.directories.data_dir, 'cache'
                )
    
    def get_model_config(self, model_name: str) -> Dict[str, Any]:
        """
        Obtém configuração de um modelo específico
        
        Args:
            model_name: Nome do modelo
            
        Returns:
            Configuração do modelo ou configuração padrão
        """
        models = self.config.get('models', {})
        
        if model_name in models:
            return models[model_name]
        
        # Fallback para modelo padrão
        default_model = models.get('default', 'enhanced_mock')
        if default_model in models:
            self.logger.warning(f"Modelo {model_name} não encontrado, usando {default_model}")
            return models[default_model]
        
        # Último fallback
        self.logger.warning(f"Modelo {model_name} não encontrado, usando configuração básica")
        return {
            'provider': 'enhanced_mock',
            'model': 'enhanced-mock-gpt-4',
            'enabled': True,
            'cost_per_token': 0.0,
            'max_tokens': 8192
        }
    
    def get_rag_config(self) -> Dict[str, Any]:
        """Obtém configuração do sistema RAG"""
        return self.config.get('rag', {
            'enabled': True,
            'knowledge_base_file': os.path.join(self.directories.data_dir, 'cobol_knowledge_base.json'),
            'max_items': 10,
            'similarity_threshold': 0.7
        })
    
    def get_output_config(self) -> Dict[str, Any]:
        """Obtém configuração de saída"""
        return self.config.get('output', {
            'default_format': 'markdown',
            'generate_html': True,
            'generate_pdf': False,
            'generate_json': True
        })
    
    def get_logging_config(self) -> Dict[str, Any]:
        """Obtém configuração de logging"""
        return self.config.get('logging', {
            'level': 'INFO',
            'file': os.path.join(self.directories.logs_dir, 'cobol_analyzer.log')
        })
    
    def get_analysis_config(self) -> Dict[str, Any]:
        """Obtém configuração de análise"""
        return self.config.get('analysis', {
            'default_options': {
                'procedure_detalhada': False,
                'modernizacao': False,
                'deep_analysis': False,
                'extract_formulas': False,
                'no_comments': False
            }
        })
    
    def get_directory_config(self) -> DirectoryConfig:
        """Retorna configuração de diretórios"""
        return self.directories
    
    def save_config(self, config_file: Optional[str] = None) -> None:
        """
        Salva a configuração atual em arquivo
        
        Args:
            config_file: Arquivo de destino (opcional)
        """
        output_file = config_file or self.get_config_path()
        
        try:
            # Criar diretório se necessário
            os.makedirs(os.path.dirname(output_file), exist_ok=True)
            
            with open(output_file, 'w', encoding='utf-8') as f:
                yaml.dump(self.config, f, default_flow_style=False, allow_unicode=True)
            
            self.logger.info(f"Configuração salva em: {output_file}")
            
        except Exception as e:
            self.logger.error(f"Erro ao salvar configuração: {e}")
            raise
    
    def validate_config(self) -> bool:
        """
        Valida a configuração atual
        
        Returns:
            True se válida, False caso contrário
        """
        try:
            # Validar seções obrigatórias
            required_sections = ['models', 'output', 'rag', 'logging']
            for section in required_sections:
                if section not in self.config:
                    self.logger.error(f"Seção obrigatória ausente: {section}")
                    return False
            
            # Validar modelo padrão
            models = self.config.get('models', {})
            default_model = models.get('default')
            if default_model and default_model not in models:
                self.logger.error(f"Modelo padrão não encontrado: {default_model}")
                return False
            
            # Validar diretórios
            for dir_name, dir_path in self.directories.to_dict().items():
                if not os.path.exists(dir_path):
                    self.logger.warning(f"Diretório não existe: {dir_name} = {dir_path}")
            
            self.logger.info("Configuração validada com sucesso")
            return True
            
        except Exception as e:
            self.logger.error(f"Erro na validação da configuração: {e}")
            return False
    
    def get_config_summary(self) -> Dict[str, Any]:
        """Retorna resumo da configuração atual"""
        return {
            'config_file': self.get_config_path(),
            'directories': self.directories.to_dict(),
            'models_available': list(self.config.get('models', {}).keys()),
            'default_model': self.config.get('models', {}).get('default'),
            'rag_enabled': self.config.get('rag', {}).get('enabled', False),
            'output_formats': self.config.get('output', {}),
            'logging_level': self.config.get('logging', {}).get('level', 'INFO')
        }

# Manter compatibilidade com código existente
ConfigManager = EnhancedConfigManager
