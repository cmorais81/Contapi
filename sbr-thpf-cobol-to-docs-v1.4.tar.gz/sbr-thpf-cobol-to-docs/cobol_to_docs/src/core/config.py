"""
COBOL AI Engine v2.1.0 - Configuration Manager
Gerenciador de configuração unificado.
"""

import os
import yaml
import logging
from typing import Dict, Any


class ConfigManager:
    """
    Gerenciador de configuração unificado.
    
    Funcionalidades:
    - Carregamento de arquivos YAML
    - Substituição de variáveis de ambiente
    - Validação de configuração
    - Configuração padrão
    """
    
    def __init__(self, config_path: str = "config/config.yaml"):
        """
        Inicializa o gerenciador de configuração.
        
        Args:
            config_path: Caminho para o arquivo de configuração
        """
        self.config_path = config_path
        self.logger = logging.getLogger(__name__)
        self.config = self._load_config()
        
        # Carregar configuração de prompts
        self.prompts_config = self._load_prompts_config()
    
    def _load_prompts_config(self) -> Dict[str, Any]:
        """Carrega configuração de prompts do arquivo especificado na configuração."""
        
        # Obter arquivo de prompts da configuração (padrão: prompts.yaml)
        prompts_file = self.config.get('ai', {}).get('prompt', {}).get('prompts_file', 'config/prompts.yaml')
        
        # Se o caminho não for absoluto, assumir que é relativo ao diretório do config_path
        if not os.path.isabs(prompts_file):
            # O prompts_file deve ser resolvido a partir do diretório onde o config.yaml está.
            # O config_path é o caminho completo para config.yaml.
            # Se prompts_file for um caminho relativo (ex: config/prompts.yaml),
            # precisamos ir para o diretório pai do diretório do config.yaml (que é o diretório 'config')
            # e então juntar com o prompts_file.
            
            # Ex: self.config_path = /.../cobol_to_docs/config/config.yaml
            # Ex: prompts_file = config/prompts.yaml
            # os.path.dirname(self.config_path) = /.../cobol_to_docs/config
            # os.path.join(os.path.dirname(self.config_path), prompts_file) = /.../cobol_to_docs/config/config/prompts.yaml (ERRADO)
            
            # O correto é usar o diretório pai do diretório do config.yaml como base.
            # Ex: base_dir = /.../cobol_to_docs
            base_dir = os.path.dirname(os.path.dirname(self.config_path))
            prompts_path = os.path.join(base_dir, prompts_file)
        else:
            prompts_path = prompts_file
        
        try:
            if os.path.exists(prompts_path):
                with open(prompts_path, 'r', encoding='utf-8') as f:
                    prompts_config = yaml.safe_load(f)
                
                self.logger.info(f"Configuração de prompts carregada de: {prompts_path}")
                return prompts_config
            else:
                self.logger.warning(f"Arquivo de prompts não encontrado: {prompts_path}")
                # Fallback para prompts.yaml padrão
                fallback_path = os.path.join(os.path.dirname(self.config_path), "prompts.yaml")
                if os.path.exists(fallback_path):
                    with open(fallback_path, 'r', encoding='utf-8') as f:
                        prompts_config = yaml.safe_load(f)
                    self.logger.info(f"Usando arquivo de prompts padrão: {fallback_path}")
                    return prompts_config
                return self._get_default_prompts_config()
                
        except Exception as e:
            self.logger.error(f"Erro ao carregar prompts: {e}")
            return self._get_default_prompts_config()
    
    def _get_default_prompts_config(self) -> Dict[str, Any]:
        """Retorna configuração padrão de prompts."""
        return {
            "prompts": {
                "system_prompt": """
Você é um especialista em análise de código COBOL com mais de 20 anos de experiência em sistemas mainframe.
Responda todas as perguntas em português brasileiro de forma clara, técnica e detalhada.

Analise o código fornecido identificando:
- Estrutura e organização do programa
- Lógica de negócio implementada
- Dependências e relacionamentos
- Pontos críticos e considerações técnicas
- Fluxo de dados e processamento

Seja direto e objetivo nas explicações, sem usar formatação especial.
Organize a resposta de forma estruturada e fácil de entender.
""".strip()
            }
        }
    
    def get_system_prompt(self) -> str:
        """
        Retorna o system prompt configurado.
        
        Returns:
            str: System prompt do arquivo prompts.yaml ou padrão
        """
        try:
            return self.prompts_config.get("prompts", {}).get("system_prompt", 
                self._get_default_prompts_config()["prompts"]["system_prompt"])
        except Exception as e:
            self.logger.error(f"Erro ao obter system prompt: {e}")
            return self._get_default_prompts_config()["prompts"]["system_prompt"]
    
    def _load_config(self) -> Dict[str, Any]:
        """Carrega configuração do arquivo YAML."""
        
        try:
            if os.path.exists(self.config_path):
                with open(self.config_path, 'r', encoding='utf-8') as f:
                    config = yaml.safe_load(f)
                
                # Substituir variáveis de ambiente
                config = self._substitute_env_vars(config)
                
                self.logger.info(f"Configuração carregada de: {self.config_path}")
                return config
            else:
                self.logger.warning(f"Arquivo de configuração não encontrado: {self.config_path}")
                return self._get_default_config()
                
        except Exception as e:
            self.logger.error(f"Erro ao carregar configuração: {str(e)}")
            return self._get_default_config()
    
    def _substitute_env_vars(self, obj):
        """Substitui variáveis de ambiente recursivamente."""
        
        if isinstance(obj, dict):
            return {key: self._substitute_env_vars(value) for key, value in obj.items()}
        elif isinstance(obj, list):
            return [self._substitute_env_vars(item) for item in obj]
        elif isinstance(obj, str) and obj.startswith('${') and obj.endswith('}'):
            # Extrair nome da variável
            var_name = obj[2:-1]
            return os.getenv(var_name, obj)
        else:
            return obj
    
    def _get_default_config(self) -> Dict[str, Any]:
        """Retorna configuração padrão."""
        
        return {
            'ai': {
                'primary_provider': 'enhanced_mock',
                'fallback_providers': ['basic'],
                'enable_fallback': True,
                'global_timeout': 120,
                'global_max_tokens': 4000,
                'providers': {
                    'enhanced_mock': {
                        'enabled': True,
                        'response_delay': 0.1,
                        'enable_phasing': True,
                        'max_tokens_per_phase': 2000,
                        'simulate_realistic_tokens': True,
                        'models': {
                            'enhanced-mock-gpt-4': {
                                'name': 'enhanced-mock-gpt-4',
                                'description': 'Modelo mock aprimorado para simulação de GPT-4',
                                'context_window': 8192,
                                'input_cost_per_million_tokens': 0.0,
                                'output_cost_per_million_tokens': 0.0,
                                'default': True
                            }
                        }
                    },
                    'basic': {
                        'enabled': True,
                        'max_tokens': 1000,
                        'models': {
                            'basic-fallback': {
                                'name': 'basic-fallback',
                                'description': 'Modelo básico de fallback',
                                'context_window': 1000,
                                'input_cost_per_million_tokens': 0.0,
                                'output_cost_per_million_tokens': 0.0,
                                'default': True
                            }
                        }
                    }
                }
            }
        }
    
    def get_config(self) -> Dict[str, Any]:
        """Retorna configuração completa."""
        return self.config.copy()
    
    def get_ai_config(self) -> Dict[str, Any]:
        """Retorna configuração de IA."""
        return self.config.get('ai', {})
    
    def get_provider_config(self, provider_name: str) -> Dict[str, Any]:
        """Retorna configuração de um provedor específico."""
        providers = self.config.get('ai', {}).get('providers', {})
        return providers.get(provider_name, {})
    
    def is_provider_enabled(self, provider_name: str) -> bool:
        """Verifica se um provedor está habilitado."""
        provider_config = self.get_provider_config(provider_name)
        return provider_config.get('enabled', False)
    
    def update_config(self, new_config: Dict[str, Any]):
        """Atualiza configuração em memória."""
        self.config.update(new_config)
    
    def save_config(self, output_path: str = None):
        """Salva configuração atual em arquivo."""
        
        output_path = output_path or self.config_path
        
        try:
            os.makedirs(os.path.dirname(output_path), exist_ok=True)
            
            with open(output_path, 'w', encoding='utf-8') as f:
                yaml.dump(self.config, f, default_flow_style=False, allow_unicode=True)
            
            self.logger.info(f"Configuração salva em: {output_path}")
            
        except Exception as e:
            self.logger.error(f"Erro ao salvar configuração: {str(e)}")
    
    def validate_config(self) -> bool:
        """Valida configuração atual."""
        
        try:
            # Verificar estrutura básica
            if 'ai' not in self.config:
                self.logger.error("Seção 'ai' não encontrada na configuração")
                return False
            
            ai_config = self.config['ai']
            
            # Verificar provedor primário
            primary_provider = ai_config.get('primary_provider')
            if not primary_provider:
                self.logger.error("Provedor primário não especificado")
                return False
            
            # Verificar provedores
            providers = ai_config.get('providers', {})
            if not providers:
                self.logger.error("Nenhum provedor configurado")
                return False
            
            # Verificar se provedor primário existe
            if primary_provider not in providers:
                self.logger.error(f"Provedor primário '{primary_provider}' não encontrado")
                return False
            
            self.logger.info("Configuração validada com sucesso")
            return True
            
        except Exception as e:
            self.logger.error(f"Erro na validação da configuração: {str(e)}")
            return False

