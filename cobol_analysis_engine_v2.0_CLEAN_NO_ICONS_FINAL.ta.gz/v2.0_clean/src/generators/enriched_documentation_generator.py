"""
Gerador de Documentação Enriquecida
Mostra claramente a origem das informações: programas COBOL, copybooks e análises de IA
"""

import logging
from datetime import datetime
from typing import Dict, Any, Optional, List
from dataclasses import dataclass

@dataclass
class InformationSource:
    """Representa a origem de uma informação"""
    source_type: str  # 'cobol_program', 'copybook', 'ai_analysis'
    source_name: str  # Nome do arquivo/provedor
    content: str      # Conteúdo extraído
    confidence: float = 1.0  # Confiança na informação

class EnrichedDocumentationGenerator:
    """Gerador que mostra a origem e enriquecimento de cada informação"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.extracted_info = {}
        self.ai_enrichments = {}
    
    def generate_enriched_documentation(self,
                                      program_name: str,
                                      cobol_code: str,
                                      extracted_data: Dict,
                                      copybooks: Optional[Dict] = None,
                                      ai_analyses: Optional[Dict] = None,
                                      prompt_history: Optional[List] = None) -> str:
        """Gera documentação mostrando origem e enriquecimento das informações"""
        
        self.logger.info(f"Gerando documentação enriquecida para {program_name}")
        
        # Extrair informações do programa COBOL
        cobol_info = self._extract_cobol_information(cobol_code, extracted_data)
        
        # Extrair informações dos copybooks
        copybook_info = self._extract_copybook_information(copybooks or {})
        
        # Processar enriquecimentos das IAs
        ai_enrichments = self._process_ai_enrichments(ai_analyses or {})
        
        # Gerar documentação estruturada
        doc_sections = []
        
        # Cabeçalho
        doc_sections.append(self._generate_header(program_name))
        
        # Seção 1: Informações Extraídas do Programa COBOL
        doc_sections.append(self._generate_cobol_extraction_section(cobol_info))
        
        # Seção 2: Informações Extraídas dos Copybooks
        if copybook_info:
            doc_sections.append(self._generate_copybook_extraction_section(copybook_info))
        
        # Seção 3: Análise Enriquecida com IA
        doc_sections.append(self._generate_ai_enrichment_section(ai_enrichments))
        
        # Seção 4: Síntese Final (Combinação de todas as fontes)
        doc_sections.append(self._generate_synthesis_section(cobol_info, copybook_info, ai_enrichments))
        
        # Seção 5: Rastreabilidade das Informações
        doc_sections.append(self._generate_traceability_section(prompt_history or []))
        
        # Rodapé
        doc_sections.append(self._generate_footer())
        
        return '\n\n'.join(doc_sections)
    
    def _extract_cobol_information(self, cobol_code: str, extracted_data: Dict) -> Dict:
        """Extrai informações estruturadas do programa COBOL"""
        
        cobol_info = {
            'program_structure': {
                'source': InformationSource('cobol_program', 'Estrutura do Programa', ''),
                'divisions': self._extract_divisions(cobol_code),
                'sections': self._extract_sections(cobol_code),
                'paragraphs': self._extract_paragraphs(cobol_code)
            },
            'business_elements': {
                'source': InformationSource('cobol_program', 'Elementos de Negócio', ''),
                'objectives': self._extract_objectives(cobol_code),
                'business_rules': self._extract_business_rules_from_code(cobol_code),
                'validations': self._extract_validations(cobol_code)
            },
            'technical_elements': {
                'source': InformationSource('cobol_program', 'Elementos Técnicos', ''),
                'file_operations': self._extract_file_operations(cobol_code),
                'data_movements': self._extract_data_movements(cobol_code),
                'calculations': self._extract_calculations(cobol_code)
            },
            'data_structures': {
                'source': InformationSource('cobol_program', 'Estruturas de Dados', ''),
                'working_storage': self._extract_working_storage(cobol_code),
                'file_definitions': self._extract_file_definitions(cobol_code),
                'linkage_section': self._extract_linkage_section(cobol_code)
            }
        }
        
        return cobol_info
    
    def _extract_copybook_information(self, copybooks: Dict) -> Dict:
        """Extrai informações estruturadas dos copybooks"""
        
        copybook_info = {}
        
        for name, content in copybooks.items():
            copybook_info[name] = {
                'source': InformationSource('copybook', name, content[:200] + '...'),
                'data_layouts': self._extract_data_layouts(content),
                'field_definitions': self._extract_field_definitions(content),
                'constants': self._extract_constants(content),
                'includes': self._extract_includes(content)
            }
        
        return copybook_info
    
    def _process_ai_enrichments(self, ai_analyses: Dict) -> Dict:
        """Processa enriquecimentos fornecidos pelas IAs"""
        
        enrichments = {}
        
        for provider, analysis in ai_analyses.items():
            if hasattr(analysis, 'analysis'):
                enrichments[provider] = {
                    'source': InformationSource('ai_analysis', provider, str(analysis.analysis)[:200] + '...'),
                    'insights': self._extract_ai_insights(analysis.analysis),
                    'recommendations': self._extract_ai_recommendations(analysis.analysis),
                    'confidence': getattr(analysis, 'confidence', 0.8)
                }
        
        return enrichments
    
    def _generate_header(self, program_name: str) -> str:
        """Gera cabeçalho da documentação enriquecida"""
        
        return f"""# Documentação Enriquecida: {program_name}

**Data de Geração:** {datetime.now().strftime('%d/%m/%Y às %H:%M')}  
**Tipo de Análise:** Análise Enriquecida com Múltiplas Fontes  

## Visão Geral

Esta documentação apresenta uma análise completa do programa COBOL **{program_name}**, mostrando claramente:

- **Informações extraídas diretamente do código COBOL**
- **Dados obtidos dos copybooks relacionados**  
- **Enriquecimentos fornecidos por análises de IA**
- **Síntese final combinando todas as fontes**

Cada seção indica claramente a **origem** das informações apresentadas."""
    
    def _generate_cobol_extraction_section(self, cobol_info: Dict) -> str:
        """Gera seção com informações extraídas do programa COBOL"""
        
        sections = []
        sections.append("##  Informações Extraídas do Programa COBOL")
        sections.append("*Fonte: Análise direta do código fonte*")
        
        # Estrutura do Programa
        sections.append("### Estrutura do Programa")
        structure = cobol_info['program_structure']
        
        if structure['divisions']:
            sections.append("**Divisões Identificadas:**")
            for division in structure['divisions']:
                sections.append(f"- {division}")
        
        if structure['sections']:
            sections.append("**Seções Encontradas:**")
            for section in structure['sections'][:5]:  # Limitar a 5
                sections.append(f"- {section}")
        
        # Elementos de Negócio
        sections.append("### Elementos de Negócio Identificados")
        business = cobol_info['business_elements']
        
        if business['objectives']:
            sections.append("**Objetivos Extraídos dos Comentários:**")
            for obj in business['objectives'][:3]:
                sections.append(f"- {obj}")
        
        if business['business_rules']:
            sections.append("**Regras de Negócio Detectadas:**")
            for rule in business['business_rules'][:5]:
                sections.append(f"- {rule}")
        
        # Elementos Técnicos
        sections.append("### Elementos Técnicos Detectados")
        technical = cobol_info['technical_elements']
        
        if technical['file_operations']:
            sections.append("**Operações de Arquivo:**")
            for op in technical['file_operations'][:5]:
                sections.append(f"- {op}")
        
        # Estruturas de Dados
        sections.append("### Estruturas de Dados Encontradas")
        data_struct = cobol_info['data_structures']
        
        if data_struct['working_storage']:
            sections.append("**Working Storage:**")
            for ws in data_struct['working_storage'][:5]:
                sections.append(f"- {ws}")
        
        return '\n\n'.join(sections)
    
    def _generate_copybook_extraction_section(self, copybook_info: Dict) -> str:
        """Gera seção com informações extraídas dos copybooks"""
        
        sections = []
        sections.append("## 📚 Informações Extraídas dos Copybooks")
        sections.append("*Fonte: Análise dos arquivos BOOKS.txt*")
        
        for name, info in copybook_info.items():
            sections.append(f"### Copybook: {name}")
            
            if info['data_layouts']:
                sections.append("**Layouts de Dados:**")
                for layout in info['data_layouts'][:3]:
                    sections.append(f"- {layout}")
            
            if info['field_definitions']:
                sections.append("**Definições de Campos:**")
                for field in info['field_definitions'][:5]:
                    sections.append(f"- {field}")
            
            if info['constants']:
                sections.append("**Constantes Definidas:**")
                for const in info['constants'][:3]:
                    sections.append(f"- {const}")
        
        return '\n\n'.join(sections)
    
    def _generate_ai_enrichment_section(self, ai_enrichments: Dict) -> str:
        """Gera seção com enriquecimentos das IAs"""
        
        sections = []
        sections.append("##  Análise Enriquecida com Inteligência Artificial")
        sections.append("*Fonte: Análises de múltiplos provedores de IA*")
        
        for provider, enrichment in ai_enrichments.items():
            sections.append(f"### Análise do Provedor: {provider}")
            sections.append(f"**Confiança:** {enrichment['confidence']:.1%}")
            
            if enrichment['insights']:
                sections.append("**Insights Identificados:**")
                for insight in enrichment['insights'][:5]:
                    sections.append(f"- {insight}")
            
            if enrichment['recommendations']:
                sections.append("**Recomendações:**")
                for rec in enrichment['recommendations'][:3]:
                    sections.append(f"- {rec}")
        
        return '\n\n'.join(sections)
    
    def _generate_synthesis_section(self, cobol_info: Dict, copybook_info: Dict, ai_enrichments: Dict) -> str:
        """Gera síntese final combinando todas as fontes"""
        
        sections = []
        sections.append("## 🔄 Síntese Final: Combinação de Todas as Fontes")
        sections.append("*Esta seção combina informações do COBOL, copybooks e análises de IA*")
        
        # Objetivo Consolidado
        sections.append("### Objetivo Consolidado do Programa")
        
        # Combinar objetivos do COBOL com insights da IA
        cobol_objectives = cobol_info['business_elements']['objectives']
        ai_insights = []
        for provider, enrichment in ai_enrichments.items():
            ai_insights.extend(enrichment['insights'])
        
        if cobol_objectives:
            sections.append("**Baseado no código COBOL:**")
            sections.append(f"- {cobol_objectives[0] if cobol_objectives else 'Não identificado'}")
        
        if ai_insights:
            sections.append("**Enriquecido pela análise de IA:**")
            sections.append(f"- {ai_insights[0] if ai_insights else 'Não disponível'}")
        
        # Regras de Negócio Consolidadas
        sections.append("### Regras de Negócio Consolidadas")
        
        cobol_rules = cobol_info['business_elements']['business_rules']
        sections.append(f"**Regras extraídas do código:** {len(cobol_rules)} identificadas")
        sections.append(f"**Validações pela IA:** Confirmadas e enriquecidas")
        
        # Estruturas de Dados Consolidadas
        sections.append("### Estruturas de Dados Consolidadas")
        
        cobol_structures = len(cobol_info['data_structures']['working_storage'])
        copybook_structures = sum(len(info['field_definitions']) for info in copybook_info.values())
        
        sections.append(f"**Do programa COBOL:** {cobol_structures} estruturas")
        sections.append(f"**Dos copybooks:** {copybook_structures} definições de campo")
        sections.append(f"**Total consolidado:** {cobol_structures + copybook_structures} elementos de dados")
        
        return '\n\n'.join(sections)
    
    def _generate_traceability_section(self, prompt_history: List) -> str:
        """Gera seção de rastreabilidade das informações"""
        
        sections = []
        sections.append("##  Rastreabilidade das Informações")
        sections.append("*Esta seção mostra como cada informação foi obtida*")
        
        sections.append("### Fontes de Dados Utilizadas")
        sections.append("1. **Programa COBOL Principal:** Análise direta do código fonte")
        sections.append("2. **Copybooks:** Estruturas de dados complementares")
        sections.append("3. **Análises de IA:** Enriquecimento e validação")
        
        if prompt_history:
            sections.append("### Histórico de Prompts Enviados para IA")
            for i, entry in enumerate(prompt_history[:3], 1):
                sections.append(f"**{i}. {entry.get('provider', 'Unknown')} - {entry.get('prompt_type', 'Unknown')}**")
                sections.append(f"- Timestamp: {entry.get('timestamp', 'N/A')}")
                sections.append(f"- Tipo de análise: {entry.get('prompt_type', 'N/A')}")
        
        return '\n\n'.join(sections)
    
    def _generate_footer(self) -> str:
        """Gera rodapé da documentação"""
        
        return f"""---

## Metodologia de Análise

Esta documentação foi gerada utilizando uma metodologia híbrida que combina:

1. **Extração Estruturada:** Análise direta do código COBOL e copybooks
2. **Enriquecimento com IA:** Validação e insights adicionais
3. **Síntese Inteligente:** Combinação de todas as fontes de informação

**Legenda de Fontes:**
-  Informações extraídas diretamente do código COBOL
- 📚 Dados obtidos dos copybooks (BOOKS.txt)
-  Enriquecimentos fornecidos por análises de IA
- 🔄 Síntese combinando múltiplas fontes

---

*Documentação gerada automaticamente pelo COBOL Analysis Engine v2.0*  
*Data: {datetime.now().strftime('%d/%m/%Y às %H:%M')}*  
*Modo: Análise Enriquecida com Múltiplas Fontes*"""
    
    # Métodos auxiliares para extração de informações
    
    def _extract_divisions(self, code: str) -> List[str]:
        """Extrai divisões do código COBOL"""
        divisions = []
        for line in code.split('\n'):
            if 'DIVISION' in line.upper():
                divisions.append(line.strip())
        return divisions
    
    def _extract_sections(self, code: str) -> List[str]:
        """Extrai seções do código COBOL"""
        sections = []
        for line in code.split('\n'):
            if 'SECTION' in line.upper() and 'DIVISION' not in line.upper():
                sections.append(line.strip())
        return sections
    
    def _extract_paragraphs(self, code: str) -> List[str]:
        """Extrai parágrafos do código COBOL"""
        paragraphs = []
        for line in code.split('\n'):
            line = line.strip()
            if line and line.endswith('.') and not any(kw in line.upper() for kw in ['DIVISION', 'SECTION', 'PIC', 'VALUE']):
                paragraphs.append(line)
        return paragraphs[:10]  # Limitar a 10
    
    def _extract_objectives(self, code: str) -> List[str]:
        """Extrai objetivos dos comentários"""
        objectives = []
        for line in code.split('\n'):
            line = line.strip()
            if line.startswith('*') and any(kw in line.upper() for kw in ['OBJETIVO', 'PROPOSITO', 'FUNCAO']):
                objectives.append(line[1:].strip())
        return objectives
    
    def _extract_business_rules_from_code(self, code: str) -> List[str]:
        """Extrai regras de negócio do código"""
        rules = []
        for line in code.split('\n'):
            line = line.strip()
            if any(kw in line.upper() for kw in ['IF ', 'WHEN ', 'EVALUATE']):
                rules.append(line)
        return rules[:10]  # Limitar a 10
    
    def _extract_validations(self, code: str) -> List[str]:
        """Extrai validações do código"""
        validations = []
        for line in code.split('\n'):
            line = line.strip()
            if 'IF ' in line.upper() and any(kw in line.upper() for kw in ['=', '>', '<', 'NOT']):
                validations.append(line)
        return validations[:5]  # Limitar a 5
    
    def _extract_file_operations(self, code: str) -> List[str]:
        """Extrai operações de arquivo"""
        operations = []
        for line in code.split('\n'):
            line = line.strip()
            if any(kw in line.upper() for kw in ['OPEN', 'CLOSE', 'READ', 'WRITE']):
                operations.append(line)
        return operations
    
    def _extract_data_movements(self, code: str) -> List[str]:
        """Extrai movimentações de dados"""
        movements = []
        for line in code.split('\n'):
            line = line.strip()
            if line.upper().startswith('MOVE '):
                movements.append(line)
        return movements[:10]  # Limitar a 10
    
    def _extract_calculations(self, code: str) -> List[str]:
        """Extrai cálculos"""
        calculations = []
        for line in code.split('\n'):
            line = line.strip()
            if any(kw in line.upper() for kw in ['ADD ', 'SUBTRACT', 'MULTIPLY', 'DIVIDE', 'COMPUTE']):
                calculations.append(line)
        return calculations
    
    def _extract_working_storage(self, code: str) -> List[str]:
        """Extrai definições do working storage"""
        ws_items = []
        in_ws = False
        for line in code.split('\n'):
            line = line.strip()
            if 'WORKING-STORAGE SECTION' in line.upper():
                in_ws = True
                continue
            if in_ws and ('SECTION' in line.upper() or 'DIVISION' in line.upper()):
                break
            if in_ws and line and any(level in line for level in ['01 ', '05 ', '10 ']):
                ws_items.append(line)
        return ws_items[:10]  # Limitar a 10
    
    def _extract_file_definitions(self, code: str) -> List[str]:
        """Extrai definições de arquivo"""
        file_defs = []
        for line in code.split('\n'):
            line = line.strip()
            if any(kw in line.upper() for kw in ['FD ', 'SELECT']):
                file_defs.append(line)
        return file_defs
    
    def _extract_linkage_section(self, code: str) -> List[str]:
        """Extrai itens da linkage section"""
        linkage_items = []
        in_linkage = False
        for line in code.split('\n'):
            line = line.strip()
            if 'LINKAGE SECTION' in line.upper():
                in_linkage = True
                continue
            if in_linkage and ('SECTION' in line.upper() or 'DIVISION' in line.upper()):
                break
            if in_linkage and line and any(level in line for level in ['01 ', '05 ', '10 ']):
                linkage_items.append(line)
        return linkage_items
    
    def _extract_data_layouts(self, content: str) -> List[str]:
        """Extrai layouts de dados do copybook"""
        layouts = []
        for line in content.split('\n'):
            line = line.strip()
            if line.startswith('01 '):
                layouts.append(line)
        return layouts
    
    def _extract_field_definitions(self, content: str) -> List[str]:
        """Extrai definições de campo do copybook"""
        fields = []
        for line in content.split('\n'):
            line = line.strip()
            if any(level in line for level in ['05 ', '10 ', '15 ', '20 ']) and 'PIC' in line.upper():
                fields.append(line)
        return fields[:10]  # Limitar a 10
    
    def _extract_constants(self, content: str) -> List[str]:
        """Extrai constantes do copybook"""
        constants = []
        for line in content.split('\n'):
            line = line.strip()
            if 'VALUE' in line.upper() and any(level in line for level in ['01 ', '05 ', '10 ']):
                constants.append(line)
        return constants
    
    def _extract_includes(self, content: str) -> List[str]:
        """Extrai includes do copybook"""
        includes = []
        for line in content.split('\n'):
            line = line.strip()
            if line.upper().startswith('COPY '):
                includes.append(line)
        return includes
    
    def _extract_ai_insights(self, analysis: Any) -> List[str]:
        """Extrai insights da análise de IA"""
        insights = []
        if isinstance(analysis, dict):
            # Procurar por campos comuns de insights
            for key in ['insights', 'observations', 'findings', 'summary']:
                if key in analysis and isinstance(analysis[key], (list, str)):
                    if isinstance(analysis[key], list):
                        insights.extend(analysis[key])
                    else:
                        insights.append(analysis[key])
        return insights[:5]  # Limitar a 5
    
    def _extract_ai_recommendations(self, analysis: Any) -> List[str]:
        """Extrai recomendações da análise de IA"""
        recommendations = []
        if isinstance(analysis, dict):
            # Procurar por campos comuns de recomendações
            for key in ['recommendations', 'suggestions', 'improvements']:
                if key in analysis and isinstance(analysis[key], (list, str)):
                    if isinstance(analysis[key], list):
                        recommendations.extend(analysis[key])
                    else:
                        recommendations.append(analysis[key])
        return recommendations[:3]  # Limitar a 3
