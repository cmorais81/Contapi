import re
import os

def extract_books_from_file(books_path, output_dir):
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    with open(books_path, 'r', encoding='latin-1') as f:
        content = f.read()

    # Regex to find book boundaries
    book_pattern = re.compile(r"VMEMBER NAME\s+([A-Z0-9]+)")
    books = book_pattern.split(content)

    if len(books) > 1:
        book_names = book_pattern.findall(content)
        book_contents = books[1:]

        for i, book_name in enumerate(book_names):
            book_file_path = os.path.join(output_dir, f"{book_name}.cpy")
            with open(book_file_path, 'w', encoding='latin-1') as bf:
                # Remove the first character of each line
                cleaned_content = "\n".join([line[1:] for line in book_contents[i].splitlines()])
                bf.write(cleaned_content)
            print(f"Book {book_name} extraído para {book_file_path}")

def extract_books_from_file(books_path):
    """
    Extrai copybooks do arquivo BOOKS.txt e retorna como lista de dicionários.
    
    Args:
        books_path: Caminho para o arquivo BOOKS.txt
        
    Returns:
        Lista de dicionários com 'name' e 'content' de cada copybook
    """
    books = []
    
    with open(books_path, 'r', encoding='latin-1') as f:
        content = f.read()

    # Regex to find book boundaries
    book_pattern = re.compile(r"VMEMBER NAME\s+([A-Z0-9]+)")
    book_sections = book_pattern.split(content)

    if len(book_sections) > 1:
        book_names = book_pattern.findall(content)
        book_contents = book_sections[1:]

        for i, book_name in enumerate(book_names):
            # Remove the first character of each line
            cleaned_content = "\n".join([line[1:] for line in book_contents[i].splitlines()])
            books.append({
                'name': book_name,
                'content': cleaned_content
            })
            print(f"Copybook {book_name} extraído")
    
    print(f"Total de {len(books)} copybooks extraídos")
    return books


if __name__ == "__main__":
    extract_books_from_file("/home/ubuntu/cobol_analysis_engine_v2.0.0/examples/BOOKS.txt", "/home/ubuntu/cobol_analysis_engine_v2.0.0/extracted_books")

