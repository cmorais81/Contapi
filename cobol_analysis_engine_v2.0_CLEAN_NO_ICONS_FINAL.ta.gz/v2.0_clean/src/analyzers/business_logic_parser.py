# -*- coding: utf-8 -*-
"""
Business Logic Parser - Extrai lógica de negócio de programas COBOL
Versão otimizada para performance
"""

import re
import logging
from typing import Dict, List, Any
from dataclasses import dataclass

@dataclass
class ProgramObjective:
    """Representa o objetivo principal do programa"""
    main_purpose: str
    detailed_description: str
    business_context: str
    processing_strategy: str
    volume_limits: Dict[str, Any]

@dataclass
class BusinessRule:
    """Representa uma regra de negócio identificada"""
    type: str  # validation, routing, control
    description: str
    condition: str
    action: str
    priority: str

@dataclass
class ProcessingFlow:
    """Representa um fluxo de processamento"""
    step_number: int
    description: str
    input_data: str
    output_data: str
    conditions: List[str]

class BusinessLogicParser:
    """Parser otimizado para extrair lógica de negócio de programas COBOL"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
        # Padrões otimizados para performance
        self.objective_patterns = [
            r'\*.*OBJETIVO.*:',
            r'\*.*PURPOSE.*:',
            r'\*.*FUNCAO.*:',
            r'\*.*PROGRAMA.*:'
        ]
        
        self.validation_patterns = [
            r'IF\s+(\w+)\s*(=|>|<|NOT)',
            r'WHEN\s+(\w+)',
            r'EVALUATE\s+(\w+)'
        ]
        
        self.routing_patterns = [
            r'MOVE.*TO\s+(\w+)',
            r'WRITE\s+(\w+)',
            r'READ\s+(\w+)'
        ]

    def generate_business_documentation(self, cobol_code: str) -> Dict:
        """Gera documentação completa de lógica de negócio - versão otimizada"""
        
        self.logger.info("Iniciando análise de lógica de negócio")
        
        # OTIMIZAÇÃO: Limitar análise para performance
        lines = cobol_code.split('\n')
        if len(lines) > 300:  # Reduzido de 500 para 300
            self.logger.info(f"Programa grande ({len(lines)} linhas), limitando análise às primeiras 300 linhas")
            limited_code = '\n'.join(lines[:300])
        else:
            limited_code = cobol_code
        
        try:
            # Extrair componentes básicos
            objective = self._extract_basic_objective(limited_code)
            business_rules = self._extract_basic_rules(limited_code)
            processing_flow = self._extract_basic_flow(limited_code)
            
        except Exception as e:
            self.logger.error(f"Erro na análise de lógica de negócio: {e}")
            return self._generate_fallback_documentation(cobol_code)
        
        # Organizar documentação
        return {
            'objective': {
                'main_purpose': objective.get('main_purpose', 'Processamento de dados COBOL'),
                'detailed_description': objective.get('description', 'Análise detalhada em progresso'),
                'business_context': objective.get('context', 'Sistema mainframe'),
                'processing_strategy': objective.get('strategy', 'Processamento sequencial'),
                'volume_limits': objective.get('limits', {})
            },
            'business_rules': {
                'validation_rules': business_rules.get('validation', []),
                'routing_rules': business_rules.get('routing', []),
                'control_rules': business_rules.get('control', [])
            },
            'processing_flow': processing_flow,
            'summary': {
                'total_rules': len(business_rules.get('validation', [])) + len(business_rules.get('routing', [])),
                'complexity_score': self._calculate_complexity(business_rules),
                'main_operations': self._extract_main_operations(limited_code),
                'critical_validations': business_rules.get('validation', [])[:3],
                'processing_steps': len(processing_flow) if isinstance(processing_flow, list) else 3
            }
        }

    def _extract_basic_objective(self, cobol_code: str) -> Dict:
        """Extrai objetivo básico do programa"""
        
        lines = cobol_code.split('\n')
        objective_text = ""
        
        # Procurar por comentários de objetivo nas primeiras 50 linhas
        for i, line in enumerate(lines[:50]):
            if any(pattern in line.upper() for pattern in ['OBJETIVO', 'PURPOSE', 'FUNCAO']):
                # Coletar próximas 5 linhas de comentário
                for j in range(i, min(i+5, len(lines))):
                    if lines[j].strip().startswith('*'):
                        clean_line = re.sub(r'^\*+\s*', '', lines[j]).strip()
                        if clean_line:
                            objective_text += clean_line + " "
                break
        
        # Extrair nome do programa
        program_name = "Programa COBOL"
        for line in lines[:20]:
            if 'PROGRAM-ID' in line.upper():
                match = re.search(r'PROGRAM-ID\.\s*(\w+)', line, re.IGNORECASE)
                if match:
                    program_name = match.group(1)
                break
        
        return {
            'main_purpose': objective_text or f"Processamento de dados - {program_name}",
            'description': objective_text or "Programa COBOL para processamento de dados",
            'context': "Sistema mainframe",
            'strategy': "Processamento sequencial",
            'limits': {}
        }

    def _extract_basic_rules(self, cobol_code: str) -> Dict:
        """Extrai regras básicas de negócio"""
        
        validation_rules = []
        routing_rules = []
        control_rules = []
        
        lines = cobol_code.split('\n')
        
        # Procurar por validações simples
        for line in lines:
            line_upper = line.upper().strip()
            
            # Validações
            if 'IF ' in line_upper and ('=' in line or '>' in line or '<' in line):
                validation_rules.append({
                    'description': f"Validação condicional: {line.strip()[:50]}...",
                    'condition': line.strip(),
                    'type': 'validation'
                })
            
            # Roteamento
            elif 'MOVE ' in line_upper and ' TO ' in line_upper:
                routing_rules.append({
                    'description': f"Movimentação de dados: {line.strip()[:50]}...",
                    'condition': line.strip(),
                    'type': 'routing'
                })
            
            # Controles
            elif any(keyword in line_upper for keyword in ['PERFORM', 'CALL', 'STOP']):
                control_rules.append({
                    'description': f"Controle de fluxo: {line.strip()[:50]}...",
                    'condition': line.strip(),
                    'type': 'control'
                })
        
        return {
            'validation': validation_rules[:5],  # Limitar a 5 regras
            'routing': routing_rules[:5],
            'control': control_rules[:5]
        }

    def _extract_basic_flow(self, cobol_code: str) -> List[Dict]:
        """Extrai fluxo básico de processamento"""
        
        flow_steps = []
        lines = cobol_code.split('\n')
        
        # Identificar seções principais
        current_section = ""
        step_number = 1
        
        for line in lines:
            line_upper = line.upper().strip()
            
            # Identificar seções
            if 'PROCEDURE DIVISION' in line_upper:
                current_section = "Início do processamento"
                flow_steps.append({
                    'step_number': step_number,
                    'description': current_section,
                    'input_data': 'Arquivos de entrada',
                    'output_data': 'Processamento iniciado',
                    'conditions': []
                })
                step_number += 1
            
            elif any(keyword in line_upper for keyword in ['OPEN ', 'READ ', 'WRITE ', 'CLOSE ']):
                operation = line_upper.split()[0] if line_upper.split() else 'OPERAÇÃO'
                flow_steps.append({
                    'step_number': step_number,
                    'description': f"{operation} - {line.strip()[:40]}...",
                    'input_data': 'Dados do arquivo',
                    'output_data': 'Dados processados',
                    'conditions': []
                })
                step_number += 1
                
                if step_number > 10:  # Limitar a 10 passos
                    break
        
        return flow_steps

    def _calculate_complexity(self, business_rules: Dict) -> str:
        """Calcula complexidade básica"""
        total_rules = sum(len(rules) for rules in business_rules.values())
        
        if total_rules > 15:
            return 'Alta'
        elif total_rules > 5:
            return 'Média'
        else:
            return 'Baixa'

    def _extract_main_operations(self, cobol_code: str) -> List[str]:
        """Extrai operações principais"""
        operations = []
        lines = cobol_code.split('\n')
        
        for line in lines:
            line_upper = line.upper().strip()
            if any(op in line_upper for op in ['READ ', 'WRITE ', 'MOVE ', 'PERFORM ', 'CALL ']):
                operation = line_upper.split()[0] if line_upper.split() else 'OPERAÇÃO'
                if operation not in operations:
                    operations.append(operation)
                    if len(operations) >= 5:  # Limitar a 5 operações
                        break
        
        return operations or ['Processamento básico']

    def _generate_fallback_documentation(self, cobol_code: str) -> Dict:
        """Gera documentação básica em caso de erro"""
        
        lines = cobol_code.split('\n')
        program_name = "Programa COBOL"
        
        # Tentar extrair nome do programa
        for line in lines[:20]:
            if 'PROGRAM-ID' in line.upper():
                match = re.search(r'PROGRAM-ID\.\s*(\w+)', line, re.IGNORECASE)
                if match:
                    program_name = match.group(1)
                break
        
        return {
            'objective': {
                'main_purpose': f"Processamento de dados COBOL - {program_name}",
                'detailed_description': "Análise detalhada não disponível devido a limitações de performance",
                'business_context': "Contexto de negócio não identificado",
                'processing_strategy': "Estratégia de processamento não determinada",
                'volume_limits': {}
            },
            'business_rules': {
                'validation_rules': [],
                'routing_rules': [],
                'control_rules': []
            },
            'processing_flow': [],
            'summary': {
                'total_rules': 0,
                'complexity_score': 'Baixa',
                'main_operations': ['Processamento básico'],
                'critical_validations': []
            }
        }

# Alias para compatibilidade
COBOLBusinessLogicParser = BusinessLogicParser
