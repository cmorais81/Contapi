"""
Provedor AWS Bedrock para Sistema de Análise COBOL.
Integração com Amazon Bedrock para análise de código COBOL.
"""

import os
import json
import logging
from typing import Dict, Any, Optional
from datetime import datetime

try:
    import boto3
    from botocore.exceptions import ClientError, NoCredentialsError
    BOTO3_AVAILABLE = True
except ImportError:
    BOTO3_AVAILABLE = False

from .base_provider import BaseProvider, AIRequest, AIResponse


class BedrockProvider(BaseProvider):
    """
    Provedor AWS Bedrock com integração completa.
    
    Funcionalidades implementadas:
    - Autenticação via AWS credentials
    - Suporte a múltiplos modelos Foundation (Claude, Llama, etc.)
    - Integração com Amazon Bedrock Runtime
    - Rate limiting e controle de tokens
    - Tratamento robusto de erros
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Inicializa o provedor Bedrock.
        
        Args:
            config: Configuração do provedor
        """
        super().__init__(config)
        
        # Verificar dependências
        if not BOTO3_AVAILABLE:
            raise ImportError("boto3 é necessário para o BedrockProvider")
        
        # Configurações AWS
        self.region = config.get("region", os.getenv("AWS_REGION", "us-east-1"))
        self.access_key_id = config.get("access_key_id", os.getenv("AWS_ACCESS_KEY_ID"))
        self.secret_access_key = config.get("secret_access_key", os.getenv("AWS_SECRET_ACCESS_KEY"))
        self.session_token = config.get("session_token", os.getenv("AWS_SESSION_TOKEN"))
        
        # Configurações do modelo
        self.model_id = config.get("model_id", "anthropic.claude-3-sonnet-20240229-v1:0")
        self.model_name = config.get("model", "claude-3-sonnet")
        
        # Parâmetros do modelo
        self.temperature = config.get("temperature", 0.1)
        self.max_tokens = config.get("max_tokens", 4000)
        self.timeout = config.get("timeout", 120)
        
        # Controle de tokens
        self.max_tokens_per_request = config.get("max_tokens_per_request", 4000)
        self.max_tokens_per_hour = config.get("max_tokens_per_hour", 100000)
        self.max_tokens_per_day = config.get("max_tokens_per_day", 500000)
        
        # Configurar logger
        self.logger = logging.getLogger(f"BedrockProvider")
        
        # Configurar cliente Bedrock
        try:
            session_kwargs = {"region_name": self.region}
            
            if self.access_key_id and self.secret_access_key:
                session_kwargs.update({
                    "aws_access_key_id": self.access_key_id,
                    "aws_secret_access_key": self.secret_access_key
                })
                if self.session_token:
                    session_kwargs["aws_session_token"] = self.session_token
            
            session = boto3.Session(**session_kwargs)
            self.bedrock_client = session.client("bedrock-runtime")
            
            self.logger.info(f"Bedrock Provider inicializado - Modelo: {self.model_name} - Região: {self.region}")
            
        except Exception as e:
            self.logger.error(f"Erro ao inicializar cliente Bedrock: {e}")
            raise
    
    async def is_available(self) -> bool:
        """
        Verifica se o provedor está disponível.
        
        Returns:
            True se disponível, False caso contrário
        """
        return self.enabled
    
    async def analyze(self, request: AIRequest) -> AIResponse:
        """
        Realiza análise usando o modelo Bedrock.
        
        Args:
            request: Requisição de análise
            
        Returns:
            Resposta da análise
        """
        try:
            # Preparar prompt
            prompt = self._prepare_prompt(request)
            
            # Preparar payload baseado no modelo
            if "claude" in self.model_id.lower():
                payload = self._prepare_claude_payload(prompt)
            elif "llama" in self.model_id.lower():
                payload = self._prepare_llama_payload(prompt)
            else:
                payload = self._prepare_generic_payload(prompt)
            
            self.logger.debug(f"Enviando requisição para Bedrock: {self.model_id}")
            
            # Fazer requisição
            response = self.bedrock_client.invoke_model(
                modelId=self.model_id,
                body=json.dumps(payload),
                contentType="application/json",
                accept="application/json"
            )
            
            # Processar resposta
            response_body = json.loads(response["body"].read())
            
            # Extrair conteúdo baseado no modelo
            if "claude" in self.model_id.lower():
                content = self._extract_claude_content(response_body)
                tokens_used = response_body.get("usage", {}).get("input_tokens", 0) + \
                             response_body.get("usage", {}).get("output_tokens", 0)
            elif "llama" in self.model_id.lower():
                content = self._extract_llama_content(response_body)
                tokens_used = self._estimate_tokens(prompt + content)
            else:
                content = self._extract_generic_content(response_body)
                tokens_used = self._estimate_tokens(prompt + content)
            
            return AIResponse(
                success=True,
                content=content,
                tokens_used=tokens_used,
                model=self.model_name,
                provider="bedrock",
                timestamp=datetime.now(),
                metadata={
                    "model_id": self.model_id,
                    "region": self.region,
                    "temperature": self.temperature,
                    "max_tokens": self.max_tokens
                }
            )
                
        except ClientError as e:
            error_msg = f"Erro AWS Bedrock: {e.response['Error']['Message']}"
            self.logger.error(error_msg)
            
            return AIResponse(
                success=False,
                content="",
                tokens_used=0,
                model=self.model_name,
                provider="bedrock",
                timestamp=datetime.now(),
                error_message=error_msg
            )
            
        except Exception as e:
            error_msg = f"Erro no BedrockProvider: {str(e)}"
            self.logger.error(error_msg)
            
            return AIResponse(
                success=False,
                content="",
                tokens_used=0,
                model=self.model_name,
                provider="bedrock",
                timestamp=datetime.now(),
                error_message=error_msg
            )
    
    def _prepare_prompt(self, request: AIRequest) -> str:
        """
        Prepara o prompt para o modelo Bedrock.
        
        Args:
            request: Requisição de análise
            
        Returns:
            Prompt formatado
        """
        prompt = f"""Você é um especialista em análise de código COBOL. Analise o seguinte programa COBOL e forneça uma análise detalhada.

PROGRAMA: {request.program_name}

CÓDIGO COBOL:
```cobol
{request.program_code}
```

PERGUNTA: {request.prompt}

Por favor, forneça uma análise técnica detalhada, incluindo:
1. Funcionalidade principal do programa
2. Estruturas de dados utilizadas
3. Lógica de negócio implementada
4. Arquivos e datasets manipulados
5. Possíveis melhorias ou observações

Responda em português brasileiro de forma clara e estruturada."""

        return prompt
    
    def _prepare_claude_payload(self, prompt: str) -> Dict[str, Any]:
        """Prepara payload para modelos Claude."""
        return {
            "messages": [
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            "max_tokens": min(self.max_tokens, self.max_tokens_per_request),
            "temperature": self.temperature,
            "anthropic_version": "bedrock-2023-05-31"
        }
    
    def _prepare_llama_payload(self, prompt: str) -> Dict[str, Any]:
        """Prepara payload para modelos Llama."""
        return {
            "prompt": prompt,
            "max_gen_len": min(self.max_tokens, self.max_tokens_per_request),
            "temperature": self.temperature,
            "top_p": 0.9
        }
    
    def _prepare_generic_payload(self, prompt: str) -> Dict[str, Any]:
        """Prepara payload genérico."""
        return {
            "inputText": prompt,
            "textGenerationConfig": {
                "maxTokenCount": min(self.max_tokens, self.max_tokens_per_request),
                "temperature": self.temperature,
                "topP": 0.9
            }
        }
    
    def _extract_claude_content(self, response_body: Dict[str, Any]) -> str:
        """Extrai conteúdo de resposta Claude."""
        if "content" in response_body and len(response_body["content"]) > 0:
            return response_body["content"][0]["text"]
        return ""
    
    def _extract_llama_content(self, response_body: Dict[str, Any]) -> str:
        """Extrai conteúdo de resposta Llama."""
        return response_body.get("generation", "")
    
    def _extract_generic_content(self, response_body: Dict[str, Any]) -> str:
        """Extrai conteúdo de resposta genérica."""
        if "results" in response_body and len(response_body["results"]) > 0:
            return response_body["results"][0]["outputText"]
        return response_body.get("outputText", "")
    
    def _estimate_tokens(self, text: str) -> int:
        """
        Estima o número de tokens em um texto.
        
        Args:
            text: Texto para estimar
            
        Returns:
            Número estimado de tokens
        """
        # Estimativa simples: ~4 caracteres por token
        return len(text) // 4
    
    def get_model_info(self) -> Dict[str, Any]:
        """
        Retorna informações sobre o modelo.
        
        Returns:
            Informações do modelo
        """
        return {
            "provider": "bedrock",
            "model": self.model_name,
            "model_id": self.model_id,
            "region": self.region,
            "max_tokens": self.max_tokens,
            "temperature": self.temperature,
            "timeout": self.timeout
        }

