#!/usr/bin/env python3.11
# -*- coding: utf-8 -*-
"""
Sistema de Análise COBOL v3.0 - Advanced COBOL Parser
Parser COBOL completamente refatorado para análise precisa e detalhada

Autor:  análise
Data: 17 de Setembro de 2025
"""

import re
import logging
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass
from enum import Enum


class COBOLDivision(Enum):
    """Divisões do programa COBOL."""
    IDENTIFICATION = "IDENTIFICATION"
    ENVIRONMENT = "ENVIRONMENT"
    DATA = "DATA"
    PROCEDURE = "PROCEDURE"


class COBOLSection(Enum):
    """Seções do programa COBOL."""
    PROGRAM_ID = "PROGRAM-ID"
    CONFIGURATION = "CONFIGURATION"
    INPUT_OUTPUT = "INPUT-OUTPUT"
    FILE_CONTROL = "FILE-CONTROL"
    FILE_SECTION = "FILE SECTION"
    WORKING_STORAGE = "WORKING-STORAGE SECTION"
    LINKAGE = "LINKAGE SECTION"


@dataclass
class COBOLField:
    """Representa um campo COBOL."""
    level: int
    name: str
    picture: Optional[str]
    value: Optional[str]
    occurs: Optional[int]
    redefines: Optional[str]
    usage: Optional[str]
    line_number: int
    parent: Optional[str] = None
    children: List[str] = None
    
    def __post_init__(self):
        if self.children is None:
            self.children = []


@dataclass
class COBOLFile:
    """Representa um arquivo COBOL."""
    name: str
    fd_name: str
    assign_to: str
    organization: Optional[str]
    access_mode: Optional[str]
    record_key: Optional[str]
    file_status: Optional[str]
    record_size: Optional[int]
    block_size: Optional[int]
    record_format: str
    line_number: int


@dataclass
class COBOLParagraph:
    """Representa um parágrafo COBOL."""
    name: str
    section: Optional[str]
    line_start: int
    line_end: int
    statements: List[str]
    calls_to: List[str]
    called_by: List[str]
    
    def __post_init__(self):
        if self.statements is None:
            self.statements = []
        if self.calls_to is None:
            self.calls_to = []
        if self.called_by is None:
            self.called_by = []


@dataclass
class COBOLSection:
    """Representa uma seção COBOL."""
    name: str
    division: str
    line_start: int
    line_end: int
    paragraphs: List[COBOLParagraph]
    
    def __post_init__(self):
        if self.paragraphs is None:
            self.paragraphs = []


@dataclass
class BusinessLogic:
    """Representa lógica de negócio identificada."""
    type: str  # validation, calculation, file_operation, integration, etc.
    description: str
    code_snippet: str
    line_numbers: List[int]
    complexity: str  # simple, medium, complex
    business_impact: str
    technical_details: str


@dataclass
class FileOperation:
    """Representa operação de arquivo."""
    operation: str  # READ, WRITE, OPEN, CLOSE, etc.
    file_name: str
    conditions: List[str]
    line_number: int
    context: str


class AdvancedCOBOLParser:
    """
    Parser COBOL avançado que identifica corretamente:
    - Estrutura hierárquica do programa
    - Lógica de negócio específica
    - Operações de arquivo e quebra de dados
    - Fluxo de processamento
    - Integrações e chamadas externas
    """
    
    def __init__(self):
        """Inicializa o parser avançado."""
        self.logger = logging.getLogger(__name__)
        self._setup_patterns()
    
    def _setup_patterns(self):
        """Configura padrões regex para análise."""
        
        # Padrões para identificar divisões
        self.division_patterns = {
            'IDENTIFICATION': re.compile(r'^\s*IDENTIFICATION\s+DIVISION\s*\.', re.IGNORECASE),
            'ENVIRONMENT': re.compile(r'^\s*ENVIRONMENT\s+DIVISION\s*\.', re.IGNORECASE),
            'DATA': re.compile(r'^\s*DATA\s+DIVISION\s*\.', re.IGNORECASE),
            'PROCEDURE': re.compile(r'^\s*PROCEDURE\s+DIVISION\s*\.', re.IGNORECASE)
        }
        
        # Padrões para seções
        self.section_patterns = {
            'PROGRAM-ID': re.compile(r'^\s*PROGRAM-ID\s*\.', re.IGNORECASE),
            'CONFIGURATION': re.compile(r'^\s*CONFIGURATION\s+SECTION\s*\.', re.IGNORECASE),
            'INPUT-OUTPUT': re.compile(r'^\s*INPUT-OUTPUT\s+SECTION\s*\.', re.IGNORECASE),
            'FILE-CONTROL': re.compile(r'^\s*FILE-CONTROL\s*\.', re.IGNORECASE),
            'FILE SECTION': re.compile(r'^\s*FILE\s+SECTION\s*\.', re.IGNORECASE),
            'WORKING-STORAGE': re.compile(r'^\s*WORKING-STORAGE\s+SECTION\s*\.', re.IGNORECASE),
            'LINKAGE': re.compile(r'^\s*LINKAGE\s+SECTION\s*\.', re.IGNORECASE)
        }
        
        # Padrões para campos de dados
        self.field_pattern = re.compile(
            r'^\s*(\d{2})\s+([A-Z0-9\-]+)(?:\s+PIC\s+([X9V\(\)\-\+\.]+))?(?:\s+VALUE\s+([^\.]+))?(?:\s+OCCURS\s+(\d+))?',
            re.IGNORECASE
        )
        
        # Padrões para arquivos
        self.file_patterns = {
            'SELECT': re.compile(r'^\s*SELECT\s+([A-Z0-9\-]+)\s+ASSIGN\s+TO\s+([A-Z0-9\-]+)', re.IGNORECASE),
            'FD': re.compile(r'^\s*FD\s+([A-Z0-9\-]+)', re.IGNORECASE),
            'RECORD_SIZE': re.compile(r'RECORD\s+CONTAINS\s+(\d+)', re.IGNORECASE),
            'BLOCK_SIZE': re.compile(r'BLOCK\s+CONTAINS\s+(\d+)', re.IGNORECASE)
        }
        
        # Padrões para parágrafos
        self.paragraph_pattern = re.compile(r'^\s*([A-Z0-9\-]+)\s*\.?\s*$', re.IGNORECASE)
        self.section_name_pattern = re.compile(r'^\s*([A-Z0-9\-]+)\s+SECTION\s*\.', re.IGNORECASE)
        
        # Padrões para operações de arquivo
        self.file_operation_patterns = {
            'OPEN': re.compile(r'OPEN\s+(INPUT|OUTPUT|I-O|EXTEND)\s+([A-Z0-9\-\s]+)', re.IGNORECASE),
            'CLOSE': re.compile(r'CLOSE\s+([A-Z0-9\-\s]+)', re.IGNORECASE),
            'READ': re.compile(r'READ\s+([A-Z0-9\-]+)', re.IGNORECASE),
            'WRITE': re.compile(r'WRITE\s+([A-Z0-9\-]+)', re.IGNORECASE),
            'REWRITE': re.compile(r'REWRITE\s+([A-Z0-9\-]+)', re.IGNORECASE)
        }
        
        # Padrões para lógica de negócio
        self.business_logic_patterns = {
            'IF_CONDITION': re.compile(r'IF\s+(.+?)\s+THEN', re.IGNORECASE | re.DOTALL),
            'PERFORM': re.compile(r'PERFORM\s+([A-Z0-9\-]+)(?:\s+THRU\s+([A-Z0-9\-]+))?', re.IGNORECASE),
            'CALL': re.compile(r'CALL\s+[\'"]([A-Z0-9\-]+)[\'"]', re.IGNORECASE),
            'COMPUTE': re.compile(r'COMPUTE\s+([A-Z0-9\-]+)\s*=\s*(.+)', re.IGNORECASE),
            'MOVE': re.compile(r'MOVE\s+(.+?)\s+TO\s+(.+)', re.IGNORECASE),
            'ADD': re.compile(r'ADD\s+(.+?)\s+TO\s+(.+)', re.IGNORECASE),
            'SUBTRACT': re.compile(r'SUBTRACT\s+(.+?)\s+FROM\s+(.+)', re.IGNORECASE)
        }
        
        # Padrões para comentários
        self.comment_patterns = [
            re.compile(r'^\s*\*.*$'),  # Comentários com *
            re.compile(r'^.{6}\*.*$'),  # Comentários na coluna 7
            re.compile(r'^\s*V\s*\|\|.*$'),  # Comentários específicos do código analisado
            re.compile(r'^\s*V\s*\*.*$'),  # Outros comentários com V
        ]
    
    def parse_file(self, file_path: str) -> Dict[str, Any]:
        """
        Analisa um arquivo COBOL completo.
        
        Args:
            file_path: Caminho para o arquivo COBOL
            
        Returns:
            Dicionário com análise completa do programa
        """
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                lines = f.readlines()
            
            # Limpar e preparar linhas
            cleaned_lines = self._clean_lines(lines)
            
            # Análise estrutural
            structure = self._analyze_structure(cleaned_lines)
            
            # Análise de dados
            data_analysis = self._analyze_data_structures(cleaned_lines, structure)
            
            # Análise de arquivos
            file_analysis = self._analyze_files(cleaned_lines)
            
            # Análise de lógica de negócio
            business_logic = self._analyze_business_logic(cleaned_lines)
            
            # Análise de fluxo
            flow_analysis = self._analyze_program_flow(cleaned_lines, structure)
            
            # Identificar funcionalidade principal
            main_functionality = self._identify_main_functionality(
                cleaned_lines, file_analysis, business_logic, flow_analysis
            )
            
            return {
                'name': self._extract_program_name(cleaned_lines),
                'file_path': file_path,
                'total_lines': len(lines),
                'code_lines': len(cleaned_lines),
                'structure': structure,
                'data_structures': data_analysis,
                'files': file_analysis,
                'business_logic': business_logic,
                'program_flow': flow_analysis,
                'main_functionality': main_functionality,
                'complexity_metrics': self._calculate_complexity(structure, business_logic),
                'integration_points': self._identify_integrations(cleaned_lines),
                'raw_lines': lines,
                'cleaned_lines': cleaned_lines
            }
            
        except Exception as e:
            self.logger.error(f"Erro ao analisar arquivo {file_path}: {str(e)}")
            return {
                'name': 'UNKNOWN',
                'file_path': file_path,
                'error': str(e),
                'total_lines': 0,
                'code_lines': 0
            }
    
    def _clean_lines(self, lines: List[str]) -> List[Tuple[int, str]]:
        """
        Limpa linhas removendo comentários e linhas vazias.
        
        Args:
            lines: Linhas originais do arquivo
            
        Returns:
            Lista de tuplas (número_linha, linha_limpa) apenas com código
        """
        cleaned = []
        
        for i, line in enumerate(lines, 1):
            # Verificar se é comentário
            is_comment = any(pattern.match(line) for pattern in self.comment_patterns)
            
            if not is_comment and line.strip():
                # Remover prefixos de versionamento (V, VSPRT, etc.)
                clean_line = re.sub(r'^[A-Z0-9]*\s*', '', line).strip()
                if clean_line:
                    cleaned.append((i, clean_line))
        
        return cleaned
    
    def _analyze_structure(self, lines: List[Tuple[int, str]]) -> Dict[str, Any]:
        """Analisa a estrutura hierárquica completa do programa."""
        structure = {
            'divisions': {},
            'sections': {},
            'paragraphs': [],
            'hierarchy': [],
            'statistics': {}
        }
        
        current_division = None
        current_section = None
        paragraph_count = 0
        
        for line_num, line in lines:
            line_clean = line.strip()
            
            # Verificar divisões
            for div_name, pattern in self.division_patterns.items():
                if pattern.match(line):
                    current_division = div_name
                    structure['divisions'][div_name] = {
                        'line_start': line_num,
                        'sections': [],
                        'content_lines': 0
                    }
                    current_section = None
                    self.logger.debug(f"Divisão identificada: {div_name} na linha {line_num}")
                    break
            
            # Contar linhas de conteúdo por divisão
            if current_division and line_clean and not line_clean.startswith('*'):
                structure['divisions'][current_division]['content_lines'] += 1
            
            # Verificar seções
            for sect_name, pattern in self.section_patterns.items():
                if pattern.match(line):
                    current_section = sect_name
                    structure['sections'][sect_name] = {
                        'division': current_division,
                        'line_start': line_num,
                        'paragraphs': [],
                        'content_lines': 0
                    }
                    if current_division:
                        structure['divisions'][current_division]['sections'].append(sect_name)
                    self.logger.debug(f"Seção identificada: {sect_name} na linha {line_num}")
                    break
            
            # Contar linhas de conteúdo por seção
            if current_section and line_clean and not line_clean.startswith('*'):
                structure['sections'][current_section]['content_lines'] += 1
            
            # Verificar parágrafos (apenas na PROCEDURE DIVISION)
            if current_division == 'PROCEDURE':
                section_match = self.section_name_pattern.match(line)
                if section_match:
                    para_name = section_match.group(1)
                    paragraph = COBOLParagraph(
                        name=para_name,
                        section=current_section,
                        line_start=line_num,
                        line_end=line_num,
                        statements=[],
                        calls_to=[],
                        called_by=[]
                    )
                    structure['paragraphs'].append(paragraph)
                    paragraph_count += 1
                    if current_section and current_section in structure['sections']:
                        structure['sections'][current_section]['paragraphs'].append(para_name)
                    self.logger.debug(f"Parágrafo/Seção identificado: {para_name} na linha {line_num}")
                
                elif (self.paragraph_pattern.match(line) and 
                      not any(pattern.match(line) for pattern in self.section_patterns.values()) and
                      not any(pattern.match(line) for pattern in self.division_patterns.values())):
                    
                    para_name = line_clean.split('.')[0].strip()
                    if (para_name and 
                        not para_name.startswith(('IF', 'ELSE', 'END', 'WHEN', 'EVALUATE')) and
                        not re.match(r'^\d+$', para_name) and  # Não é apenas número
                        len(para_name) > 1):  # Nome significativo
                        
                        paragraph = COBOLParagraph(
                            name=para_name,
                            section=current_section,
                            line_start=line_num,
                            line_end=line_num,
                            statements=[],
                            calls_to=[],
                            called_by=[]
                        )
                        structure['paragraphs'].append(paragraph)
                        paragraph_count += 1
                        if current_section and current_section in structure['sections']:
                            structure['sections'][current_section]['paragraphs'].append(para_name)
                        self.logger.debug(f"Parágrafo identificado: {para_name} na linha {line_num}")
        
        # Calcular estatísticas
        structure['statistics'] = {
            'total_divisions': len(structure['divisions']),
            'total_sections': len(structure['sections']),
            'total_paragraphs': len(structure['paragraphs']),
            'divisions_found': list(structure['divisions'].keys()),
            'sections_found': list(structure['sections'].keys()),
            'paragraphs_found': [p.name for p in structure['paragraphs'][:10]]  # Primeiros 10
        }
        
        self.logger.info(f"Estrutura extraída: {structure['statistics']['total_divisions']} divisões, "
                        f"{structure['statistics']['total_sections']} seções, "
                        f"{structure['statistics']['total_paragraphs']} parágrafos")
        
        return structure
    
    def _analyze_data_structures(self, lines: List[Tuple[int, str]], structure: Dict) -> Dict[str, Any]:
        """Analisa estruturas de dados do programa."""
        data_structures = {
            'fields': [],
            'records': [],
            'constants': [],
            'working_storage': [],
            'file_records': []
        }
        
        current_section = None
        current_fd = None
        
        for line_num, line in lines:
            # Identificar seção atual
            for sect_name, pattern in self.section_patterns.items():
                if pattern.match(line):
                    current_section = sect_name
                    break
            
            # Identificar FD
            fd_match = self.file_patterns['FD'].match(line)
            if fd_match:
                current_fd = fd_match.group(1)
            
            # Analisar campos
            field_match = self.field_pattern.match(line)
            if field_match:
                level = int(field_match.group(1))
                name = field_match.group(2)
                picture = field_match.group(3)
                value = field_match.group(4)
                occurs = field_match.group(5)
                
                field = COBOLField(
                    level=level,
                    name=name,
                    picture=picture,
                    value=value,
                    occurs=int(occurs) if occurs else None,
                    redefines=None,
                    usage=None,
                    line_number=line_num
                )
                
                data_structures['fields'].append(field)
                
                # Categorizar por seção
                if current_section == 'WORKING-STORAGE':
                    data_structures['working_storage'].append(field)
                elif current_fd:
                    data_structures['file_records'].append(field)
                
                # Identificar constantes
                if value and level == 5:
                    data_structures['constants'].append(field)
        
        return data_structures
    
    def _analyze_files(self, lines: List[Tuple[int, str]]) -> Dict[str, Any]:
        """Analisa definições e operações de arquivos."""
        files = {
            'definitions': [],
            'operations': [],
            'file_flow': []
        }
        
        current_files = {}
        
        for line_num, line in lines:
            # SELECT statements
            select_match = self.file_patterns['SELECT'].match(line)
            if select_match:
                file_name = select_match.group(1)
                assign_to = select_match.group(2)
                
                file_def = COBOLFile(
                    name=file_name,
                    fd_name=file_name,
                    assign_to=assign_to,
                    organization=None,
                    access_mode=None,
                    record_key=None,
                    file_status=None,
                    record_size=None,
                    block_size=None,
                    record_format='F',
                    line_number=line_num
                )
                
                files['definitions'].append(file_def)
                current_files[file_name] = file_def
            
            # Operações de arquivo
            for op_name, pattern in self.file_operation_patterns.items():
                match = pattern.search(line)
                if match:
                    if op_name in ['OPEN']:
                        mode = match.group(1)
                        file_names = match.group(2).split()
                        for fname in file_names:
                            fname = fname.strip()
                            if fname:
                                operation = FileOperation(
                                    operation=f"{op_name} {mode}",
                                    file_name=fname,
                                    conditions=[],
                                    line_number=line_num,
                                    context=line
                                )
                                files['operations'].append(operation)
                    else:
                        file_name = match.group(1)
                        operation = FileOperation(
                            operation=op_name,
                            file_name=file_name,
                            conditions=[],
                            line_number=line_num,
                            context=line
                        )
                        files['operations'].append(operation)
        
        return files
    
    def _analyze_business_logic(self, lines: List[Tuple[int, str]]) -> List[BusinessLogic]:
        """Analisa lógica de negócio específica."""
        business_logic = []
        
        for line_num, line in lines:
            # Validações condicionais
            if_match = self.business_logic_patterns['IF_CONDITION'].search(line)
            if if_match:
                condition = if_match.group(1)
                logic = BusinessLogic(
                    type='validation',
                    description=f"Validação condicional: {condition}",
                    code_snippet=line,
                    line_numbers=[line_num],
                    complexity='medium',
                    business_impact='Controla fluxo de processamento baseado em condições específicas',
                    technical_details=f"Implementa validação usando IF com condição: {condition}"
                )
                business_logic.append(logic)
            
            # Chamadas de programa
            call_match = self.business_logic_patterns['CALL'].search(line)
            if call_match:
                program = call_match.group(1)
                logic = BusinessLogic(
                    type='integration',
                    description=f"Integração com programa externo: {program}",
                    code_snippet=line,
                    line_numbers=[line_num],
                    complexity='high',
                    business_impact='Integração com sistema externo para processamento específico',
                    technical_details=f"Chama programa externo {program} para funcionalidade especializada"
                )
                business_logic.append(logic)
            
            # Cálculos
            compute_match = self.business_logic_patterns['COMPUTE'].search(line)
            if compute_match:
                variable = compute_match.group(1)
                expression = compute_match.group(2)
                logic = BusinessLogic(
                    type='calculation',
                    description=f"Cálculo de negócio: {variable} = {expression}",
                    code_snippet=line,
                    line_numbers=[line_num],
                    complexity='medium',
                    business_impact='Realiza cálculo específico para regra de negócio',
                    technical_details=f"Calcula {variable} usando expressão: {expression}"
                )
                business_logic.append(logic)
            
            # Movimentações de dados
            move_match = self.business_logic_patterns['MOVE'].search(line)
            if move_match:
                source = move_match.group(1)
                target = move_match.group(2)
                logic = BusinessLogic(
                    type='data_movement',
                    description=f"Movimentação de dados: {source} -> {target}",
                    code_snippet=line,
                    line_numbers=[line_num],
                    complexity='simple',
                    business_impact='Transfere dados entre campos para processamento',
                    technical_details=f"Move dados de {source} para {target}"
                )
                business_logic.append(logic)
        
        return business_logic
    
    def _analyze_program_flow(self, lines: List[Tuple[int, str]], structure: Dict) -> Dict[str, Any]:
        """Analisa fluxo de execução do programa."""
        flow = {
            'main_flow': [],
            'perform_calls': [],
            'decision_points': [],
            'loops': [],
            'error_handling': []
        }
        
        for line_num, line in lines:
            # PERFORM statements
            perform_match = self.business_logic_patterns['PERFORM'].search(line)
            if perform_match:
                target = perform_match.group(1)
                thru = perform_match.group(2) if perform_match.group(2) else None
                
                flow['perform_calls'].append({
                    'line': line_num,
                    'target': target,
                    'thru': thru,
                    'context': line
                })
            
            # Pontos de decisão
            if 'IF' in line.upper():
                flow['decision_points'].append({
                    'line': line_num,
                    'condition': line,
                    'type': 'conditional'
                })
            
            # Loops
            if 'PERFORM' in line.upper() and ('UNTIL' in line.upper() or 'TIMES' in line.upper()):
                flow['loops'].append({
                    'line': line_num,
                    'type': 'perform_loop',
                    'condition': line
                })
        
        return flow
    
    def _identify_main_functionality(self, lines: List[Tuple[int, str]], 
                                   file_analysis: Dict, business_logic: List, 
                                   flow_analysis: Dict) -> Dict[str, Any]:
        """Identifica a funcionalidade principal do programa."""
        
        # Analisar padrões de processamento de arquivo
        input_files = [f for f in file_analysis['definitions'] if 'E1' in f.name or 'INPUT' in f.assign_to]
        output_files = [f for f in file_analysis['definitions'] if 'S1' in f.name or 'S2' in f.name or 'OUTPUT' in f.assign_to]
        
        # Identificar operações de leitura/escrita
        read_operations = [op for op in file_analysis['operations'] if op.operation == 'READ']
        write_operations = [op for op in file_analysis['operations'] if op.operation == 'WRITE']
        
        # Analisar lógica de validação
        validations = [bl for bl in business_logic if bl.type == 'validation']
        integrations = [bl for bl in business_logic if bl.type == 'integration']
        
        # Determinar funcionalidade principal
        functionality_type = "unknown"
        description = "Funcionalidade não identificada"
        
        if len(input_files) > 0 and len(output_files) > 1:
            functionality_type = "file_splitter"
            description = "Programa que lê arquivo de entrada, aplica validações e divide em múltiplos arquivos de saída"
        elif len(read_operations) > 0 and len(write_operations) > 0:
            functionality_type = "file_processor"
            description = "Programa que processa arquivos aplicando transformações e validações"
        elif len(validations) > 10:
            functionality_type = "validator"
            description = "Programa focado em validação de dados com múltiplas regras"
        
        return {
            'type': functionality_type,
            'description': description,
            'input_files': [f.name for f in input_files],
            'output_files': [f.name for f in output_files],
            'validation_count': len(validations),
            'integration_count': len(integrations),
            'complexity_indicators': {
                'decision_points': len(flow_analysis['decision_points']),
                'perform_calls': len(flow_analysis['perform_calls']),
                'business_rules': len(business_logic)
            }
        }
    
    def _calculate_complexity(self, structure: Dict, business_logic: List) -> Dict[str, Any]:
        """Calcula métricas de complexidade."""
        return {
            'cyclomatic_complexity': len([bl for bl in business_logic if bl.type == 'validation']),
            'paragraph_count': len(structure['paragraphs']),
            'division_count': len(structure['divisions']),
            'section_count': len(structure['sections']),
            'business_rule_count': len(business_logic),
            'integration_points': len([bl for bl in business_logic if bl.type == 'integration'])
        }
    
    def _identify_integrations(self, lines: List[Tuple[int, str]]) -> List[Dict[str, Any]]:
        """Identifica pontos de integração com outros sistemas."""
        integrations = []
        
        for line_num, line in lines:
            # CALL statements
            call_match = self.business_logic_patterns['CALL'].search(line)
            if call_match:
                program = call_match.group(1)
                integrations.append({
                    'type': 'program_call',
                    'target': program,
                    'line': line_num,
                    'context': line
                })
        
        return integrations
    
    def _extract_program_name(self, lines: List[Tuple[int, str]]) -> str:
        """Extrai o nome do programa."""
        for line_num, line in lines:
            if 'PROGRAM-ID' in line.upper():
                # Extrair nome após PROGRAM-ID
                parts = line.split()
                if len(parts) > 1:
                    return parts[1].rstrip('.')
        
        return "UNKNOWN"
