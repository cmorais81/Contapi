#!/usr/bin/env python3
"""
COBOL Analyzer CLI - Interface de linha de comando
Wrapper para o main.py existente mantendo compatibilidade total
"""

import sys
import subprocess
import os

def main():
    """Ponto de entrada CLI que chama o main.py original"""
    # Obter o diretório do script atual
    script_dir = os.path.dirname(os.path.abspath(__file__))
    main_py_path = os.path.join(script_dir, 'main.py')
    
    # Chamar o main.py com todos os argumentos passados
    cmd = [sys.executable, main_py_path] + sys.argv[1:]
    
    try:
        result = subprocess.run(cmd, check=False)
        sys.exit(result.returncode)
    except KeyboardInterrupt:
        print("\nOperação cancelada pelo usuário.")
        sys.exit(1)
    except Exception as e:
        print(f"Erro ao executar a aplicação: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()
