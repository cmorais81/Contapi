#!/usr/bin/env python3
"""
Script para expandir a base de conhecimento RAG com foco em sistemas CADOC
Adiciona conhecimento especializado em gestão documental bancária
"""

import os
import sys
import json
import logging
from datetime import datetime
from typing import Dict, List, Any

def setup_logging():
    """Configura logging para o script"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s'
    )
    return logging.getLogger(__name__)

def load_current_knowledge_base():
    """Carrega a base de conhecimento atual"""
    kb_path = "/home/ubuntu/cobol_to_docs_v1.0_final/data/cobol_knowledge_base.json"
    
    if os.path.exists(kb_path):
        with open(kb_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    else:
        return []

def create_cadoc_specialized_knowledge():
    """Cria conhecimento especializado em sistemas CADOC"""
    
    cadoc_knowledge = [
        {
            "id": "cadoc_architecture_001",
            "title": "Arquitetura de Sistemas CADOC Bancários",
            "content": "Sistemas CADOC (Cadastro de Documentos) implementam arquitetura em camadas com módulos especializados: captura documental (scanning/upload), classificação automática (OCR/AI), indexação estruturada (metadados), armazenamento seguro (repositório), workflow de aprovação, controles de acesso e auditoria completa. Utilizam padrões bancários de segurança, backup e disaster recovery.",
            "category": "Arquitetura CADOC",
            "keywords": ["arquitetura", "cadoc", "módulos", "camadas", "segurança"],
            "cobol_constructs": ["PROGRAM-ID", "CONFIGURATION SECTION", "FILE-CONTROL"],
            "domain": "Arquitetura de Sistemas",
            "complexity_level": "avancado",
            "created_at": datetime.now().isoformat()
        },
        {
            "id": "cadoc_workflow_001",
            "title": "Workflows de Processamento Documental CADOC",
            "content": "Workflows CADOC seguem padrões rigorosos: recepção → validação inicial → classificação automática → extração de metadados → indexação → aprovação → armazenamento final. Incluem tratamento de exceções, reprocessamento automático, escalação por timeout e notificações. Implementam SLA específicos por tipo documental e criticidade.",
            "category": "Workflows CADOC",
            "keywords": ["workflow", "processamento", "aprovação", "sla", "exceções"],
            "cobol_constructs": ["PERFORM", "EVALUATE", "IF-THEN-ELSE", "CALL"],
            "domain": "Processos de Negócio",
            "complexity_level": "intermediario",
            "created_at": datetime.now().isoformat()
        },
        {
            "id": "cadoc_compliance_001",
            "title": "Compliance e Regulamentações CADOC",
            "content": "Sistemas CADOC atendem regulamentações bancárias específicas: BACEN, SOX, LGPD, Basel III. Implementam controles de retenção documental (7-10 anos), trilhas de auditoria imutáveis, assinatura digital certificada ICP-Brasil, criptografia em trânsito e repouso, controles de acesso baseados em perfis e segregação de funções.",
            "category": "Compliance CADOC",
            "keywords": ["compliance", "regulamentação", "bacen", "lgpd", "auditoria"],
            "cobol_constructs": ["SECURITY", "AUDIT-TRAIL", "ENCRYPTION"],
            "domain": "Compliance e Auditoria",
            "complexity_level": "avancado",
            "created_at": datetime.now().isoformat()
        },
        {
            "id": "cadoc_integration_001",
            "title": "Integrações CADOC com Core Banking",
            "content": "Integrações CADOC com sistemas core banking utilizam APIs REST/SOAP, mensageria MQ, batch ETL e real-time streaming. Sincronizam dados de clientes, produtos, transações e contratos. Implementam padrões de retry, circuit breaker, timeout configurável e monitoramento de SLA. Garantem consistência transacional e recuperação de falhas.",
            "category": "Integrações CADOC",
            "keywords": ["integração", "core banking", "api", "mensageria", "etl"],
            "cobol_constructs": ["CALL", "LINKAGE SECTION", "COMMUNICATION SECTION"],
            "domain": "Integrações de Sistemas",
            "complexity_level": "avancado",
            "created_at": datetime.now().isoformat()
        },
        {
            "id": "cadoc_metadata_001",
            "title": "Estruturas de Metadados CADOC",
            "content": "Metadados CADOC seguem taxonomia padronizada: identificação (ID único, hash), classificação (tipo, subtipo, categoria), temporal (data criação, validade, retenção), origem (canal, usuário, sistema), conteúdo (palavras-chave, resumo, índices), técnico (formato, tamanho, versão), jurídico (assinatura, certificação, status legal).",
            "category": "Metadados CADOC",
            "keywords": ["metadados", "taxonomia", "classificação", "indexação"],
            "cobol_constructs": ["01 LEVEL", "OCCURS", "REDEFINES", "PIC"],
            "domain": "Estruturas de Dados",
            "complexity_level": "intermediario",
            "created_at": datetime.now().isoformat()
        },
        {
            "id": "cadoc_security_001",
            "title": "Segurança e Controles de Acesso CADOC",
            "content": "Segurança CADOC implementa múltiplas camadas: autenticação forte (2FA/biometria), autorização baseada em perfis (RBAC), criptografia AES-256, tokenização de dados sensíveis, mascaramento dinâmico, logs de acesso detalhados, detecção de anomalias, prevenção de vazamentos (DLP) e controles de exportação.",
            "category": "Segurança CADOC",
            "keywords": ["segurança", "criptografia", "rbac", "tokenização", "dlp"],
            "cobol_constructs": ["SECURITY", "PASSWORD", "ENCRYPTION", "ACCESS-CONTROL"],
            "domain": "Segurança da Informação",
            "complexity_level": "avancado",
            "created_at": datetime.now().isoformat()
        },
        {
            "id": "cadoc_performance_001",
            "title": "Otimização de Performance CADOC",
            "content": "Performance CADOC otimizada através de: indexação inteligente (B-tree, hash, bitmap), cache distribuído (Redis/Hazelcast), compressão adaptativa, CDN para documentos, processamento paralelo, particionamento temporal, arquivamento automático (hot/warm/cold), otimização de queries e monitoramento proativo de recursos.",
            "category": "Performance CADOC",
            "keywords": ["performance", "indexação", "cache", "compressão", "particionamento"],
            "cobol_constructs": ["INDEXED", "KEY", "SORT", "MERGE", "SEARCH"],
            "domain": "Otimização de Performance",
            "complexity_level": "avancado",
            "created_at": datetime.now().isoformat()
        },
        {
            "id": "cadoc_business_rules_001",
            "title": "Regras de Negócio Específicas CADOC",
            "content": "Regras CADOC específicas por tipo documental: contratos (validação jurídica, vigência, renovação), comprovantes (autenticidade, rastreabilidade), extratos (integridade, assinatura digital), correspondências (classificação, prazo resposta), formulários (completude, validação cruzada). Incluem regras de rejeição automática e escalação.",
            "category": "Regras de Negócio CADOC",
            "keywords": ["regras negócio", "validação", "contratos", "comprovantes"],
            "cobol_constructs": ["IF", "EVALUATE", "PERFORM", "VALIDATE"],
            "domain": "Regras de Negócio",
            "complexity_level": "intermediario",
            "created_at": datetime.now().isoformat()
        },
        {
            "id": "cadoc_analytics_001",
            "title": "Analytics e Relatórios CADOC",
            "content": "Analytics CADOC fornecem insights operacionais: volume documental por período, taxa de processamento automático vs manual, SLA de aprovação por tipo, distribuição por canal de entrada, análise de rejeições, tendências de crescimento, utilização de storage, performance de classificadores automáticos e ROI de automação.",
            "category": "Analytics CADOC",
            "keywords": ["analytics", "relatórios", "sla", "performance", "roi"],
            "cobol_constructs": ["COMPUTE", "SORT", "REPORT SECTION", "SUM"],
            "domain": "Business Intelligence",
            "complexity_level": "intermediario",
            "created_at": datetime.now().isoformat()
        },
        {
            "id": "cadoc_modernization_001",
            "title": "Modernização de Sistemas CADOC Legacy",
            "content": "Modernização CADOC legacy envolve: migração gradual de mainframe para cloud, refatoração de COBOL para microserviços, implementação de APIs REST, adoção de containers (Docker/Kubernetes), integração com AI/ML para classificação, migração de dados históricos, manutenção de compatibilidade e treinamento de equipes.",
            "category": "Modernização CADOC",
            "keywords": ["modernização", "cloud", "microserviços", "containers", "ai/ml"],
            "cobol_constructs": ["PROGRAM-ID", "LINKAGE", "CALL", "COPY"],
            "domain": "Modernização de Sistemas",
            "complexity_level": "avancado",
            "created_at": datetime.now().isoformat()
        },
        {
            "id": "cadoc_disaster_recovery_001",
            "title": "Disaster Recovery e Continuidade CADOC",
            "content": "DR CADOC implementa estratégias robustas: backup incremental contínuo, replicação geográfica, RTO/RPO otimizados (RTO<4h, RPO<1h), testes regulares de recuperação, planos de contingência por cenário, comunicação de crise, recursos alternativos e procedimentos de rollback. Garante disponibilidade 99.9% conforme SLA bancário.",
            "category": "Disaster Recovery CADOC",
            "keywords": ["disaster recovery", "backup", "replicação", "rto", "rpo"],
            "cobol_constructs": ["BACKUP", "RECOVERY", "CHECKPOINT", "RESTART"],
            "domain": "Continuidade de Negócios",
            "complexity_level": "avancado",
            "created_at": datetime.now().isoformat()
        },
        {
            "id": "cadoc_ai_integration_001",
            "title": "Integração de IA em Sistemas CADOC",
            "content": "IA em CADOC revoluciona processamento: OCR inteligente com 99%+ precisão, classificação automática por ML, extração de entidades (NER), análise de sentimento, detecção de fraudes, processamento de linguagem natural, automação de workflows, predição de volumes e otimização de recursos. Reduz intervenção manual em 80%+.",
            "category": "IA em CADOC",
            "keywords": ["inteligência artificial", "ocr", "machine learning", "nlp", "automação"],
            "cobol_constructs": ["CALL", "FUNCTION", "API-INTEGRATION"],
            "domain": "Inteligência Artificial",
            "complexity_level": "avancado",
            "created_at": datetime.now().isoformat()
        },
        {
            "id": "cadoc_cobol_patterns_001",
            "title": "Padrões COBOL Específicos para CADOC",
            "content": "Padrões COBOL CADOC incluem: estruturas de dados hierárquicas para metadados (01-49 levels), rotinas de validação padronizadas (88 levels), tratamento de arquivos indexados (ISAM/VSAM), processamento batch otimizado (SORT/MERGE), integração com CICS/IMS, copybooks padronizados e tratamento robusto de erros com logging detalhado.",
            "category": "Padrões COBOL CADOC",
            "keywords": ["padrões cobol", "estruturas dados", "validação", "batch", "cics"],
            "cobol_constructs": ["01 LEVEL", "88 LEVEL", "COPY", "ISAM", "VSAM", "CICS"],
            "domain": "Desenvolvimento COBOL",
            "complexity_level": "intermediario",
            "created_at": datetime.now().isoformat()
        },
        {
            "id": "cadoc_data_governance_001",
            "title": "Governança de Dados em Sistemas CADOC",
            "content": "Governança CADOC estabelece políticas rigorosas: classificação de dados por sensibilidade, ciclo de vida documental automatizado, políticas de retenção por regulamentação, controles de qualidade de dados, lineage tracking, data stewardship, métricas de qualidade, processos de purga segura e compliance contínuo com regulamentações.",
            "category": "Governança de Dados CADOC",
            "keywords": ["governança dados", "classificação", "retenção", "qualidade", "compliance"],
            "cobol_constructs": ["DATA DIVISION", "WORKING-STORAGE", "FILE SECTION"],
            "domain": "Governança de Dados",
            "complexity_level": "avancado",
            "created_at": datetime.now().isoformat()
        },
        {
            "id": "cadoc_testing_001",
            "title": "Estratégias de Teste para Sistemas CADOC",
            "content": "Testes CADOC abrangem múltiplas dimensões: testes funcionais por tipo documental, testes de performance com volumes reais, testes de segurança (penetration testing), testes de integração com sistemas core, testes de disaster recovery, testes de compliance regulatório, automação de testes regressivos e validação de migração de dados.",
            "category": "Testes CADOC",
            "keywords": ["testes", "performance", "segurança", "integração", "automação"],
            "cobol_constructs": ["TEST", "ASSERT", "MOCK", "STUB"],
            "domain": "Qualidade de Software",
            "complexity_level": "intermediario",
            "created_at": datetime.now().isoformat()
        }
    ]
    
    return cadoc_knowledge

def create_cobol_cadoc_patterns():
    """Cria padrões específicos de COBOL para sistemas CADOC"""
    
    cobol_patterns = [
        {
            "id": "cobol_cadoc_file_structure_001",
            "title": "Estruturas de Arquivo COBOL para CADOC",
            "content": "Estruturas de arquivo CADOC em COBOL utilizam organização INDEXED com múltiplas chaves: chave primária (ID documento), chaves alternativas (tipo, data, cliente, status). Implementam RECORD VARYING para documentos de tamanhos diferentes, controle de versioning e soft delete. Exemplo: SELECT CADOC-FILE ASSIGN TO 'CADOC.DAT' ORGANIZATION IS INDEXED ACCESS MODE IS DYNAMIC RECORD KEY IS DOC-ID ALTERNATE RECORD KEY IS DOC-TYPE-DATE.",
            "category": "Estruturas de Arquivo COBOL",
            "keywords": ["file structure", "indexed", "keys", "vsam", "record"],
            "cobol_constructs": ["SELECT", "ORGANIZATION INDEXED", "RECORD KEY", "ALTERNATE KEY"],
            "domain": "Estruturas de Dados COBOL",
            "complexity_level": "intermediario",
            "created_at": datetime.now().isoformat()
        },
        {
            "id": "cobol_cadoc_validation_001",
            "title": "Rotinas de Validação CADOC em COBOL",
            "content": "Validações CADOC implementam verificações em cascata: validação de formato (PIC clauses), validação de domínio (88 levels), validação de integridade referencial, validação de regras de negócio específicas. Utilizam EVALUATE para múltiplas condições e PERFORM para modularização. Exemplo: 88 VALID-DOC-TYPE VALUE 'CONT' 'COMP' 'EXTR' 'FORM'. IF NOT VALID-DOC-TYPE PERFORM ERROR-INVALID-TYPE.",
            "category": "Validação COBOL",
            "keywords": ["validação", "88 level", "evaluate", "business rules"],
            "cobol_constructs": ["88 LEVEL", "EVALUATE", "IF", "PERFORM", "PIC"],
            "domain": "Validação de Dados COBOL",
            "complexity_level": "intermediario",
            "created_at": datetime.now().isoformat()
        },
        {
            "id": "cobol_cadoc_batch_processing_001",
            "title": "Processamento Batch CADOC em COBOL",
            "content": "Processamento batch CADOC otimizado para alto volume: leitura sequencial com buffer, processamento em chunks, checkpoint/restart automático, logging detalhado, tratamento de erros robusto. Utiliza SORT/MERGE para ordenação eficiente e COPY para reutilização de código. Implementa controle de transações e rollback em caso de falhas.",
            "category": "Processamento Batch COBOL",
            "keywords": ["batch processing", "sort", "merge", "checkpoint", "restart"],
            "cobol_constructs": ["SORT", "MERGE", "CHECKPOINT", "RESTART", "COPY"],
            "domain": "Processamento Batch COBOL",
            "complexity_level": "avancado",
            "created_at": datetime.now().isoformat()
        },
        {
            "id": "cobol_cadoc_error_handling_001",
            "title": "Tratamento de Erros CADOC em COBOL",
            "content": "Tratamento de erros CADOC implementa estratégia em camadas: captura de erros de I/O (FILE STATUS), validação de dados (condition names), erros de lógica de negócio (custom codes), logging estruturado com severidade, notificação automática para erros críticos. Utiliza DECLARATIVES para tratamento centralizado e CALL para logging externo.",
            "category": "Tratamento de Erros COBOL",
            "keywords": ["error handling", "file status", "declaratives", "logging"],
            "cobol_constructs": ["FILE STATUS", "DECLARATIVES", "CALL", "CONDITION NAMES"],
            "domain": "Tratamento de Erros COBOL",
            "complexity_level": "intermediario",
            "created_at": datetime.now().isoformat()
        },
        {
            "id": "cobol_cadoc_integration_001",
            "title": "Integrações COBOL CADOC com Sistemas Externos",
            "content": "Integrações COBOL CADOC utilizam múltiplos padrões: CALL para subprogramas, CICS LINK para transações online, MQ para mensageria assíncrona, arquivos de interface para batch ETL. Implementam timeout configurável, retry automático, circuit breaker pattern e monitoramento de SLA. Garantem transações ACID e recuperação de falhas.",
            "category": "Integrações COBOL",
            "keywords": ["integration", "cics", "mq", "call", "linkage"],
            "cobol_constructs": ["CALL", "CICS LINK", "LINKAGE SECTION", "COMMUNICATION SECTION"],
            "domain": "Integrações COBOL",
            "complexity_level": "avancado",
            "created_at": datetime.now().isoformat()
        }
    ]
    
    return cobol_patterns

def merge_and_deduplicate_knowledge(current_kb: List[Dict], new_knowledge: List[Dict]) -> List[Dict]:
    """Mescla e remove duplicatas da base de conhecimento"""
    logger = logging.getLogger(__name__)
    
    # Criar índice de IDs existentes
    existing_ids = {item.get('id') for item in current_kb if item.get('id')}
    
    # Filtrar conhecimento novo (apenas itens não existentes)
    new_items = []
    duplicates = 0
    
    for item in new_knowledge:
        if item.get('id') not in existing_ids:
            new_items.append(item)
        else:
            duplicates += 1
    
    logger.info(f"Itens novos a adicionar: {len(new_items)}")
    logger.info(f"Duplicatas evitadas: {duplicates}")
    
    # Mesclar conhecimento
    merged_kb = current_kb + new_items
    
    return merged_kb

def update_knowledge_base_metadata(kb: List[Dict]) -> List[Dict]:
    """Atualiza metadados da base de conhecimento"""
    
    # Adicionar metadados de expansão CADOC
    metadata_item = {
        "id": "metadata_cadoc_expansion",
        "title": "Expansão CADOC da Base de Conhecimento",
        "content": f"Base de conhecimento expandida com {len([item for item in kb if 'cadoc' in item.get('id', '').lower()])} itens especializados em sistemas CADOC. Inclui arquitetura, workflows, compliance, integrações, segurança, performance, regras de negócio, analytics, modernização, disaster recovery, IA, padrões COBOL, governança de dados e estratégias de teste. Atualizada em {datetime.now().isoformat()}.",
        "category": "Metadados",
        "keywords": ["metadata", "cadoc", "expansão", "especialização"],
        "cobol_constructs": ["METADATA"],
        "domain": "Sistema",
        "complexity_level": "informativo",
        "created_at": datetime.now().isoformat()
    }
    
    # Remover metadados antigos se existirem
    kb_filtered = [item for item in kb if item.get('id') != 'metadata_cadoc_expansion']
    
    # Adicionar novos metadados
    kb_filtered.append(metadata_item)
    
    return kb_filtered

def save_expanded_knowledge_base(kb: List[Dict]):
    """Salva a base de conhecimento expandida"""
    logger = logging.getLogger(__name__)
    
    kb_path = "/home/ubuntu/cobol_to_docs_v1.0_final/data/cobol_knowledge_base.json"
    backup_path = "/home/ubuntu/cobol_to_docs_v1.0_final/data/cobol_knowledge_base_backup_cadoc.json"
    
    # Fazer backup da versão atual
    if os.path.exists(kb_path):
        import shutil
        shutil.copy2(kb_path, backup_path)
        logger.info(f"Backup criado: {backup_path}")
    
    # Salvar nova versão
    with open(kb_path, 'w', encoding='utf-8') as f:
        json.dump(kb, f, indent=2, ensure_ascii=False)
    
    logger.info(f"Base de conhecimento expandida salva: {kb_path}")
    logger.info(f"Total de itens: {len(kb)}")

def generate_expansion_report(original_count: int, final_count: int, cadoc_items: int):
    """Gera relatório da expansão da base de conhecimento"""
    logger = logging.getLogger(__name__)
    
    report_path = "/home/ubuntu/cobol_to_docs_v1.0_final/data/cadoc_expansion_report.txt"
    
    report_content = f"""
RELATÓRIO DE EXPANSÃO DA BASE DE CONHECIMENTO CADOC
==================================================

Data: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

ESTATÍSTICAS:
- Itens originais: {original_count}
- Itens adicionados: {final_count - original_count}
- Total final: {final_count}
- Itens específicos CADOC: {cadoc_items}
- Crescimento: {((final_count - original_count) / original_count * 100):.1f}%

CATEGORIAS ADICIONADAS:
- Arquitetura CADOC
- Workflows CADOC  
- Compliance CADOC
- Integrações CADOC
- Metadados CADOC
- Segurança CADOC
- Performance CADOC
- Regras de Negócio CADOC
- Analytics CADOC
- Modernização CADOC
- Disaster Recovery CADOC
- IA em CADOC
- Padrões COBOL CADOC
- Governança de Dados CADOC
- Testes CADOC
- Estruturas de Arquivo COBOL
- Validação COBOL
- Processamento Batch COBOL
- Tratamento de Erros COBOL
- Integrações COBOL

IMPACTO ESPERADO:
- Análises mais profundas de sistemas CADOC
- Melhor identificação de regras de negócio
- Reconhecimento de padrões específicos bancários
- Sugestões de modernização mais precisas
- Compliance automático com regulamentações

PRÓXIMOS PASSOS:
1. Testar análises com a base expandida
2. Validar qualidade das análises CADOC
3. Ajustar prompts para aproveitar novo conhecimento
4. Monitorar performance do sistema RAG
"""
    
    with open(report_path, 'w', encoding='utf-8') as f:
        f.write(report_content)
    
    logger.info(f"Relatório de expansão gerado: {report_path}")

def main():
    """Função principal do script de expansão"""
    logger = setup_logging()
    
    logger.info("=== EXPANDINDO BASE DE CONHECIMENTO RAG COM FOCO EM CADOC ===")
    
    try:
        # 1. Carregar base atual
        logger.info("1. Carregando base de conhecimento atual...")
        current_kb = load_current_knowledge_base()
        original_count = len(current_kb)
        logger.info(f"Base atual: {original_count} itens")
        
        # 2. Criar conhecimento CADOC especializado
        logger.info("2. Criando conhecimento especializado em CADOC...")
        cadoc_knowledge = create_cadoc_specialized_knowledge()
        logger.info(f"Conhecimento CADOC criado: {len(cadoc_knowledge)} itens")
        
        # 3. Criar padrões COBOL específicos
        logger.info("3. Criando padrões COBOL para CADOC...")
        cobol_patterns = create_cobol_cadoc_patterns()
        logger.info(f"Padrões COBOL criados: {len(cobol_patterns)} itens")
        
        # 4. Mesclar conhecimento
        logger.info("4. Mesclando conhecimento...")
        all_new_knowledge = cadoc_knowledge + cobol_patterns
        merged_kb = merge_and_deduplicate_knowledge(current_kb, all_new_knowledge)
        
        # 5. Atualizar metadados
        logger.info("5. Atualizando metadados...")
        final_kb = update_knowledge_base_metadata(merged_kb)
        
        # 6. Salvar base expandida
        logger.info("6. Salvando base de conhecimento expandida...")
        save_expanded_knowledge_base(final_kb)
        
        # 7. Gerar relatório
        final_count = len(final_kb)
        cadoc_items = len([item for item in final_kb if 'cadoc' in item.get('id', '').lower()])
        
        logger.info("7. Gerando relatório de expansão...")
        generate_expansion_report(original_count, final_count, cadoc_items)
        
        logger.info("=== EXPANSÃO CONCLUÍDA COM SUCESSO ===")
        
        print("\n🎉 BASE DE CONHECIMENTO CADOC EXPANDIDA COM SUCESSO!")
        print("=" * 60)
        print(f"\n📊 ESTATÍSTICAS:")
        print(f"   • Itens originais: {original_count}")
        print(f"   • Itens adicionados: {final_count - original_count}")
        print(f"   • Total final: {final_count}")
        print(f"   • Itens CADOC específicos: {cadoc_items}")
        print(f"   • Crescimento: {((final_count - original_count) / original_count * 100):.1f}%")
        
        print(f"\n🎯 MELHORIAS ESPERADAS:")
        print("   • Análises mais profundas de sistemas CADOC")
        print("   • Melhor identificação de regras de negócio bancárias")
        print("   • Reconhecimento de padrões específicos de gestão documental")
        print("   • Sugestões de modernização mais precisas")
        print("   • Compliance automático com regulamentações")
        
        print(f"\n📄 ARQUIVOS GERADOS:")
        print("   • Base expandida: data/cobol_knowledge_base.json")
        print("   • Backup: data/cobol_knowledge_base_backup_cadoc.json")
        print("   • Relatório: data/cadoc_expansion_report.txt")
        
    except Exception as e:
        logger.error(f"Erro durante expansão: {e}")
        raise

if __name__ == "__main__":
    main()
