#!/usr/bin/env python3
"""
Utilitário para exibir informações detalhadas dos modelos LLM configurados
"""

import sys
import os
import yaml
from typing import Dict, Any

def load_config():
    """Carrega configuração do sistema"""
    config_path = "config/config.yaml"
    
    if not os.path.exists(config_path):
        print("Erro: Arquivo de configuração não encontrado")
        sys.exit(1)
    
    with open(config_path, 'r', encoding='utf-8') as f:
        return yaml.safe_load(f)

def display_model_details(config: Dict[str, Any]):
    """Exibe detalhes completos dos modelos"""
    print("🤖 INFORMAÇÕES DETALHADAS DOS MODELOS LLM")
    print("=" * 60)
    
    # Modelos LuzIA
    luzia_config = config.get('providers', {}).get('luzia', {})
    luzia_models = luzia_config.get('models', {})
    
    if luzia_models:
        print("\n🚀 MODELOS LUZIA:")
        print("-" * 30)
        
        for model_key, model_config in luzia_models.items():
            print(f"\n📋 {model_key.upper()}")
            print(f"   Nome: {model_config.get('name', 'N/A')}")
            print(f"   Descrição: {model_config.get('description', 'Sem descrição')}")
            print(f"   Max Tokens: {model_config.get('max_tokens', 'N/A'):,}")
            print(f"   Context Window: {model_config.get('context_window', 'N/A'):,}")
            print(f"   Temperature: {model_config.get('temperature', 'N/A')}")
            print(f"   Timeout: {model_config.get('timeout', 'N/A')}s")
            
            # Recomendações de uso
            model_name = model_config.get('name', '').lower()
            if 'sonnet' in model_name:
                print("   💡 Recomendado para: Análises complexas e detalhadas")
            elif 'haiku' in model_name:
                print("   💡 Recomendado para: Análises rápidas e eficientes")
            elif 'nova' in model_name:
                print("   💡 Recomendado para: Contexto extenso e análises robustas")
            elif 'gpt' in model_name:
                print("   💡 Recomendado para: Análises balanceadas e gerais")
    
    # Configurações gerais do LuzIA
    if luzia_config:
        print("\n🔧 CONFIGURAÇÕES LUZIA:")
        print("-" * 25)
        print(f"   Status: {'Habilitado' if luzia_config.get('enabled', False) else 'Desabilitado'}")
        print(f"   URL Auth: {luzia_config.get('auth_url', 'N/A')[:50]}...")
        print(f"   URL API: {luzia_config.get('api_url', 'N/A')[:50]}...")
        
        retry_config = luzia_config.get('retry', {})
        print(f"   Max Tentativas: {retry_config.get('max_attempts', 'N/A')}")
        
        rate_limit = luzia_config.get('rate_limit', {})
        print(f"   Rate Limit: {rate_limit.get('requests_per_minute', 'N/A')} req/min")
    
    # Outros provedores
    other_providers = ['enhanced_mock', 'openai', 'bedrock', 'databricks']
    for provider_name in other_providers:
        provider_config = config.get('providers', {}).get(provider_name, {})
        if provider_config.get('enabled', False):
            models = provider_config.get('models', {})
            if models:
                print(f"\n🔧 MODELOS {provider_name.upper()}:")
                print("-" * 30)
                
                for model_key, model_config in models.items():
                    print(f"   • {model_config.get('name', model_key)}")
                    print(f"     Max Tokens: {model_config.get('max_tokens', 'N/A'):,}")
                    print(f"     Context: {model_config.get('context_window', 'N/A'):,}")

def display_usage_recommendations():
    """Exibe recomendações de uso por cenário"""
    print("\n" + "=" * 60)
    print("💡 RECOMENDAÇÕES DE USO POR CENÁRIO")
    print("=" * 60)
    
    scenarios = [
        {
            'title': '🎯 ANÁLISE CRÍTICA DE SISTEMAS CADOC',
            'model': 'aws-claude-3-5-sonnet',
            'reason': 'Máxima qualidade e profundidade de análise',
            'command': 'python3 main.py --fontes programa.txt --model aws-claude-3-5-sonnet'
        },
        {
            'title': '⚡ PROCESSAMENTO EM LOTE RÁPIDO',
            'model': 'aws-claude-3-5-haiku',
            'reason': 'Velocidade e eficiência para múltiplos programas',
            'command': 'python3 main.py --fontes lote.txt --model aws-claude-3-5-haiku'
        },
        {
            'title': '📚 PROGRAMAS MUITO GRANDES (>100KB)',
            'model': 'amazon-nova-pro-v1',
            'reason': 'Context window de 300K tokens',
            'command': 'python3 main.py --fontes programa_grande.txt --model amazon-nova-pro-v1'
        },
        {
            'title': '🔄 ANÁLISE BALANCEADA GERAL',
            'model': 'azure-gpt-4o-exp',
            'reason': 'Equilíbrio entre qualidade e velocidade',
            'command': 'python3 main.py --fontes programa.txt --model azure-gpt-4o-exp'
        },
        {
            'title': '🧪 TESTE E DESENVOLVIMENTO',
            'model': 'enhanced_mock',
            'reason': 'Sem custos, resposta imediata',
            'command': 'python3 main.py --fontes programa.txt --model enhanced_mock'
        }
    ]
    
    for scenario in scenarios:
        print(f"\n{scenario['title']}")
        print(f"   Modelo: {scenario['model']}")
        print(f"   Motivo: {scenario['reason']}")
        print(f"   Comando: {scenario['command']}")

def main():
    """Função principal"""
    # Carregar configuração
    config = load_config()
    
    # Exibir informações dos modelos
    display_model_details(config)
    
    # Exibir recomendações de uso
    display_usage_recommendations()
    
    print("\n" + "=" * 60)
    print("📖 Para mais informações, consulte a documentação do sistema")

if __name__ == "__main__":
    main()
