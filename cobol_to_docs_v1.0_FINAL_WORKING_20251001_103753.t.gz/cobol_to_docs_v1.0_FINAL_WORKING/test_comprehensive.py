#!/usr/bin/env python3
"""
Teste abrangente das correções aplicadas
"""

import os
import sys
import subprocess
import json
from datetime import datetime

def test_system_comprehensive():
    """Teste abrangente do sistema corrigido"""
    
    print("🧪 TESTE ABRANGENTE DAS CORREÇÕES")
    print("=" * 50)
    
    # Criar programa de teste mais complexo
    test_program = """       IDENTIFICATION DIVISION.
       PROGRAM-ID. TESTECOMPLETO.
       
       ENVIRONMENT DIVISION.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           SELECT ENTRADA-FILE ASSIGN TO 'ENTRADA.DAT'
               ORGANIZATION IS SEQUENTIAL.
       
       DATA DIVISION.
       FILE SECTION.
       FD  ENTRADA-FILE.
       01  REG-ENTRADA.
           05  ENT-CODIGO      PIC X(10).
           05  ENT-TIPO-DOC    PIC X(03).
           05  ENT-NUMERO      PIC X(20).
       
       WORKING-STORAGE SECTION.
       COPY CADOC-VALIDACOES.
       COPY CADOC-CONSTANTES.
       ++INCLUDE CADOC-FUNCOES.
       
       01  WS-CONTADOR         PIC 9(05) VALUE ZEROS.
       01  WS-STATUS           PIC X(02) VALUE SPACES.
       01  WS-TABELA-TIPOS.
           05  WS-QTD-TIPOS    PIC 9(02) VALUE 05.
           05  WS-TIPO-ITEM    OCCURS 1 TO 50 TIMES
                               DEPENDING ON WS-QTD-TIPOS.
               10  WS-CODIGO-TIPO    PIC X(03).
               10  WS-DESC-TIPO      PIC X(30).
       
       PROCEDURE DIVISION.
       0000-PRINCIPAL.
           PERFORM 1000-INICIALIZAR
           PERFORM 2000-PROCESSAR-ARQUIVO
           PERFORM 3000-FINALIZAR
           STOP RUN.
       
       1000-INICIALIZAR.
           OPEN INPUT ENTRADA-FILE
           MOVE 'DOC' TO WS-CODIGO-TIPO(1)
           MOVE 'Documento Geral' TO WS-DESC-TIPO(1).
       
       2000-PROCESSAR-ARQUIVO.
           PERFORM UNTIL WS-STATUS = '10'
               READ ENTRADA-FILE
                   AT END MOVE '10' TO WS-STATUS
                   NOT AT END PERFORM 2100-VALIDAR-REGISTRO
               END-READ
           END-PERFORM.
       
       2100-VALIDAR-REGISTRO.
           IF ENT-TIPO-DOC = SPACES
               DISPLAY 'ERRO E001: Tipo documento em branco'
           ELSE
               IF ENT-NUMERO = SPACES
                   DISPLAY 'ERRO E002: Número documento em branco'
               ELSE
                   ADD 1 TO WS-CONTADOR
                   DISPLAY 'REGISTRO VALIDADO: ' ENT-CODIGO
               END-IF
           END-IF.
       
       3000-FINALIZAR.
           CLOSE ENTRADA-FILE
           DISPLAY 'PROCESSAMENTO CONCLUIDO - TOTAL: ' WS-CONTADOR.
"""
    
    test_file = "TESTECOMPLETO.cbl"
    with open(test_file, 'w', encoding='utf-8') as f:
        f.write(test_program)
    
    print(f"✅ Programa de teste criado: {test_file}")
    
    # Executar análise
    cmd = [
        'python3', 'main.py',
        '--fontes', test_file,
        '--models', 'enhanced_mock',
        '--output', 'teste_completo'
    ]
    
    try:
        print(f"🚀 Executando: {' '.join(cmd)}")
        
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=180
        )
        
        success = result.returncode == 0
        
        print(f"📊 Resultado da execução:")
        print(f"   • Código de retorno: {result.returncode}")
        print(f"   • Sucesso: {'✅' if success else '❌'}")
        
        if not success:
            print(f"   • Erro: {result.stderr[:500]}")
        
        # Verificar arquivos gerados
        expected_files = [
            "teste_completo/TESTECOMPLETO_analise_funcional.md",
            "teste_completo/ai_requests/TESTECOMPLETO_ai_request.json",
            "teste_completo/ai_responses/TESTECOMPLETO_ai_response.json"
        ]
        
        files_found = []
        for expected_file in expected_files:
            if os.path.exists(expected_file):
                files_found.append(expected_file)
                
                # Verificar conteúdo básico
                if expected_file.endswith('.md'):
                    with open(expected_file, 'r', encoding='utf-8') as f:
                        content = f.read()
                        sections = len([line for line in content.split('\n') if line.startswith('#')])
                        print(f"   • {expected_file}: {len(content)} chars, {sections} seções")
                
                elif expected_file.endswith('.json'):
                    with open(expected_file, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                        print(f"   • {expected_file}: {len(data)} campos")
        
        print(f"\n📁 Arquivos gerados: {len(files_found)}/{len(expected_files)}")
        for file_found in files_found:
            print(f"   ✅ {file_found}")
        
        for expected_file in expected_files:
            if expected_file not in files_found:
                print(f"   ❌ {expected_file} (não encontrado)")
        
        # Verificar qualidade da análise
        if files_found:
            md_file = next((f for f in files_found if f.endswith('.md')), None)
            if md_file:
                with open(md_file, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                quality_checks = {
                    'Copybooks identificados': any(copybook in content.upper() for copybook in ['CADOC-VALIDACOES', 'CADOC-CONSTANTES', 'CADOC-FUNCOES']),
                    'Regras de negócio': 'REGRAS DE NEGÓCIO' in content.upper(),
                    'Códigos de erro': any(code in content for code in ['E001', 'E002']),
                    'Estruturas de dados': 'ESTRUTURAS DE DADOS' in content.upper(),
                    'Evidências documentadas': any(term in content.lower() for term in ['evidência', 'baseado em', 'inferido']),
                    'Foco CADOC': 'CADOC' in content.upper()
                }
                
                print(f"\n🎯 Qualidade da análise:")
                for check, passed in quality_checks.items():
                    print(f"   {'✅' if passed else '❌'} {check}")
        
        # Resultado final
        overall_success = success and len(files_found) >= 2
        
        print(f"\n==================================================")
        if overall_success:
            print("🎉 TESTE ABRANGENTE: ✅ SUCESSO COMPLETO!")
            print("   • Sistema executa sem erros")
            print("   • Análise aprimorada funcionando")
            print("   • Arquivos de debug gerados")
            print("   • Qualidade da análise validada")
        else:
            print("⚠️  TESTE ABRANGENTE: ❌ NECESSITA AJUSTES")
            print("   • Verifique logs para detalhes")
        
        # Limpeza
        if os.path.exists(test_file):
            os.remove(test_file)
        
        return overall_success
        
    except Exception as e:
        print(f"❌ Erro no teste: {e}")
        return False

if __name__ == "__main__":
    success = test_system_comprehensive()
    sys.exit(0 if success else 1)
