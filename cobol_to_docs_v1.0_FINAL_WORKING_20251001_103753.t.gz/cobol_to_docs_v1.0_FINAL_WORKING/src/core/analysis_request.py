"""
Classe para requisições de análise
"""

from typing import Dict, Any, Optional
from datetime import datetime

class AnalysisRequest:
    """Requisição de análise de programa COBOL"""
    
    def __init__(self, program_content: str, program_name: str, model: str,
                 prompt: str, analysis_type: str = 'individual', **kwargs):
        self.program_content = program_content
        self.program_name = program_name
        self.model = model
        self.prompt = prompt
        self.analysis_type = analysis_type
        self.timestamp = datetime.now()
        self.metadata = kwargs
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte para dicionário"""
        return {
            'program_content': self.program_content,
            'program_name': self.program_name,
            'model': self.model,
            'prompt': self.prompt,
            'analysis_type': self.analysis_type,
            'timestamp': self.timestamp.isoformat(),
            'metadata': self.metadata
        }
