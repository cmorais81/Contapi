"""
COBOL AI Engine v2.6.0 - Enhanced Prompt Manager
Gerenciador avançado de prompts com suporte a YAML customizado.
"""

import logging
from typing import Dict, Any, Optional


class EnhancedPromptManager:
    """
    Gerenciador avançado de prompts para análise COBOL.
    Trabalha diretamente com configuração de prompts carregada.
    """
    
    def __init__(self, prompt_config: Dict[str, Any]):
        """
        Inicializa o gerenciador com configuração de prompts já carregada.
        
        Args:
            prompt_config: Dicionário com configuração de prompts do ConfigManager
        """
        self.logger = logging.getLogger(__name__)
        self.prompt_config = prompt_config
        
        if not prompt_config:
            self.logger.error("Configuração de prompts não fornecida")
            raise ValueError("Configuração de prompts é obrigatória")
            
        self.logger.info(f"Enhanced Prompt Manager inicializado com prompt de {len(prompt_config.get('full_prompt', ''))} caracteres")
    
    def create_complete_analysis_prompt(self, program_name: str, cobol_code: str, copybooks_content: str = "") -> str:
        """
        Cria o prompt completo para análise do programa COBOL usando o prompt BIAN.
        
        Args:
            program_name: Nome do programa COBOL
            cobol_code: Código fonte do programa
            copybooks_content: Conteúdo dos copybooks relacionados
            
        Returns:
            Prompt completo formatado com estrutura BIAN
        """
        try:
            # Obter o prompt BIAN do usuário
            user_prompt = self.prompt_config.get('user_prompt', self.prompt_config.get('full_prompt', ''))
            
            if not user_prompt:
                self.logger.error("Prompt BIAN não encontrado na configuração")
                raise ValueError("Prompt BIAN não encontrado")
            
            # Preparar informações do programa para substituição
            program_info = f"""
=== INFORMAÇÕES DO PROGRAMA ===
Nome do Programa: {program_name}
Tamanho do Código: {len(cobol_code)} caracteres
Copybooks Disponíveis: {len(copybooks_content)} caracteres

=== CÓDIGO COBOL ===
{cobol_code}

=== COPYBOOKS ===
{copybooks_content}
"""
            
            # Substituir placeholders no prompt BIAN
            formatted_prompt = user_prompt.replace('{program_name}', program_name)
            formatted_prompt = formatted_prompt.replace('{cobol_code}', cobol_code)
            formatted_prompt = formatted_prompt.replace('{copybooks}', copybooks_content)
            
            # Construir prompt final com estrutura correta:
            # 1. Prompt BIAN (instruções de análise)
            # 2. Informações do programa (dados para análise)
            final_prompt = f"""{formatted_prompt}

{program_info}"""
            
            self.logger.info(f"Prompt BIAN completo criado para {program_name}: {len(final_prompt)} caracteres")
            return final_prompt
            
        except Exception as e:
            self.logger.error(f"Erro ao criar prompt BIAN completo: {e}")
            raise
    
    def get_system_prompt(self) -> str:
        """
        Retorna o prompt do sistema BIAN.
        
        Returns:
            Prompt do sistema BIAN
        """
        system_prompt = self.prompt_config.get('system_prompt', '')
        if not system_prompt:
            # Fallback para prompt padrão se não houver system_prompt específico
            return 'Você é um especialista em análise de sistemas COBOL com foco em arquitetura BIAN (Banking Industry Architecture Network).'
        return system_prompt
    
    def get_user_prompt_template(self) -> str:
        """
        Retorna o template do prompt BIAN do usuário.
        
        Returns:
            Template do prompt BIAN do usuário
        """
        return self.prompt_config.get('user_prompt', self.prompt_config.get('full_prompt', ''))
    
    def get_prompt_metadata(self) -> Dict[str, Any]:
        """
        Retorna metadados do prompt carregado.
        
        Returns:
            Dicionário com metadados do prompt
        """
        return {
            'yaml_file': self.prompt_config.get('yaml_file', 'N/A'),
            'system_prompt_length': len(self.prompt_config.get('system_prompt', '')),
            'user_prompt_length': len(self.prompt_config.get('user_prompt', '')),
            'full_prompt_length': len(self.prompt_config.get('full_prompt', '')),
            'has_bian_structure': 'BIAN' in self.prompt_config.get('full_prompt', '').upper()
        }
    
    def validate_prompt_structure(self) -> bool:
        """
        Valida se o prompt tem a estrutura BIAN esperada.
        
        Returns:
            True se a estrutura está correta, False caso contrário
        """
        user_prompt = self.get_user_prompt_template()
        
        # Verificar se contém elementos essenciais do prompt BIAN
        bian_elements = [
            'RESUMO EXECUTIVO',
            'ANÁLISE TÉCNICA',
            'ANÁLISE DE INTEGRAÇÃO',
            'ANÁLISE DE QUALIDADE',
            'IMPACTO NO NEGÓCIO',
            'RECOMENDAÇÕES'
        ]
        
        found_elements = sum(1 for element in bian_elements if element in user_prompt.upper())
        
        self.logger.info(f"Elementos BIAN encontrados: {found_elements}/{len(bian_elements)}")
        
        return found_elements >= 4  # Pelo menos 4 dos 6 elementos essenciais
